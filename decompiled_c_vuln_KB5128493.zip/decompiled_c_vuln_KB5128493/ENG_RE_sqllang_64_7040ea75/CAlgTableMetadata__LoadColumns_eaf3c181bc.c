
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,undefined param_3)

{
  longlong lVar1;
  undefined2 uVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong lVar11;
  uint uVar12;
  longlong unaff_GS_OFFSET;
  undefined auStack_128 [32];
  undefined uStack_108;
  undefined uStack_100;
  longlong lStack_f8;
  longlong *plStack_f0;
  undefined uStack_e8;
  undefined uStack_e0;
  undefined uStack_d8;
  undefined2 uStack_d6;
  undefined2 uStack_d4;
  longlong *plStack_d0;
  undefined8 uStack_c8;
  longlong lStack_c0;
  undefined4 uStack_b0;
  undefined8 *puStack_a8;
  longlong lStack_a0;
  longlong *plStack_98;
  longlong lStack_90;
  undefined8 uStack_88;
  longlong lStack_80;
  ulonglong uStack_48;
  
  uStack_88 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_128;
  lVar1 = param_2[5];
  lVar11 = param_2[0x30];
  uStack_d8 = param_3;
  lStack_a0 = lVar1;
  lStack_80 = lVar1;
  plVar8 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x18) + 0x78))();
  uStack_d4 = *(undefined2 *)
               (*(longlong *)
                 (*(longlong *)
                   ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) + 0x50)
               + 8);
  if (*(int *)(param_1 + 0x10) == 5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_d6 = *(undefined2 *)(param_1 + 0x80);
  lStack_90 = *(longlong *)(param_1 + 0x118);
  plStack_98 = plVar8;
  if (lStack_90 == 0) {
    uVar4 = (**(code **)(*plVar8 + 0xd0))(plVar8,0);
    *(undefined4 *)(param_1 + 0x114) = uVar4;
    iVar5 = (**(code **)(*plVar8 + 0xd0))(plVar8,1);
    *(int *)(param_1 + 0x120) = iVar5 - *(int *)(param_1 + 0x114);
    if ((*(int *)(param_1 + 0x10) == 0) &&
       (iVar5 = (**(code **)(*plVar8 + 0xa8))(plVar8), iVar5 != -1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(byte *)(param_1 + 0x21e) = *(byte *)(param_1 + 0x21e) & 0xfb;
    *(undefined *)(param_1 + 0x21e) = *(undefined *)(param_1 + 0x21e);
    uStack_b0 = 0xa51;
    uStack_108 = 3;
    puVar9 = (undefined8 *)(*_DAT_)(0x40,lVar1,0x21709a0,0xa51);
    if (puVar9 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar12 = 0x400;
    if (*(uint *)(param_1 + 0x114) < 0x400) {
      uVar12 = *(uint *)(param_1 + 0x114);
    }
    puStack_a8 = puVar9;
    func_0x(puVar9,lVar1,uVar12);
    *puVar9 = 0x2170f90;
    *(undefined8 **)(param_1 + 0x118) = puVar9;
    uStack_b0 = 0xa54;
    uStack_108 = 3;
    lVar10 = (*_DAT_)(0x38,lVar1,0x21709a0,0xa54);
    puStack_a8 = (undefined8 *)lVar10;
    if (lVar10 != 0) {
      uVar12 = 0x400;
      if (*(uint *)(param_1 + 0x114) < 0x400) {
        uVar12 = *(uint *)(param_1 + 0x114);
      }
      lVar10 = func_0x(lVar10,lVar1,uVar12);
    }
    *(longlong *)(param_1 + 0x1c0) = lVar10;
    if (*(int *)(param_1 + 0x120) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  iVar5 = (**(code **)(*param_2 + 0x18))(param_2);
  cVar3 = func_0x(*(undefined8 *)(lVar11 + 0x80));
  if (cVar3 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lStack_c0 = 0;
  uStack_c8 = 1;
  plStack_d0 = plVar8;
  iVar6 = (**(code **)(*plVar8 + 0xa8))(plVar8);
  lVar1 = lStack_a0;
  uVar2 = uStack_d6;
  if (iVar6 != -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar12 = 0;
  while( true ) {
    if (lStack_c0 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar7 = (**(code **)(*plStack_d0 + 0xd0))(plStack_d0,uStack_c8 & 0xffffffff);
    if (uVar7 <= uStack_c8._4_4_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar11 = (**(code **)(*plStack_d0 + 0xe0))
                       (plStack_d0,uStack_c8._4_4_ + 1,uStack_c8 & 0xffffffff);
    if (lVar11 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_e0 = 0;
    uStack_e8 = uStack_d8;
    lStack_f8 = lVar1;
    uStack_100 = 0;
    uStack_108 = iVar5 == 0xfd;
    plStack_f0 = param_2;
    func_0x(param_1,lVar11,uStack_d4,uVar2);
    if (lStack_c0 != 0) break;
    uVar7 = (**(code **)(*plStack_d0 + 0xd0))(plStack_d0,uStack_c8 & 0xffffffff);
    if (uStack_c8._4_4_ < uVar7) {
      uStack_c8 = CONCAT44(uStack_c8._4_4_ + 1,(undefined4)uStack_c8);
    }
    uVar12 = uVar12 + 1;
    if ((uVar12 & 0x7f) == 0) {
      cVar3 = func_0x((longlong)param_2 + 0x22c);
      if (cVar3 != '\0') {
        func_0x(0x5c);
      }
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

