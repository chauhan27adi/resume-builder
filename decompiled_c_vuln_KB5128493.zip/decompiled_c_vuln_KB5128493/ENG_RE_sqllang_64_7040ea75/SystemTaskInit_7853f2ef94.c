
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(void)

{
  longlong lVar1;
  undefined8 unaff_RBX;
  undefined8 unaff_RBP;
  undefined8 auStackX_10 [3];
  
  lVar1 = func_0x();
  lVar1 = -lVar1;
  *(undefined8 *)((longlong)auStackX_10 + lVar1) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00001260 + lVar1) = unaff_RBX;
  *(undefined8 *)(&stack0x00001268 + lVar1) = unaff_RBP;
  *(ulonglong *)(&stack0x00001228 + lVar1) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffe8 + lVar1);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

