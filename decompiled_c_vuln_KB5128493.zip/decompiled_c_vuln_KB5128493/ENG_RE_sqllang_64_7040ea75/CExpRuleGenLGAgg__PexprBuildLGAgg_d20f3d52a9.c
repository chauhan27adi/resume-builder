
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00132ba3) */
/* WARNING: Removing unreachable block (ram,0x0168a7b5) */
/* WARNING: Removing unreachable block (ram,0x00100ca7) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,undefined8 *param_3,undefined8 param_4,
                 longlong param_5)

{
  undefined8 *puVar1;
  undefined uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  int iVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  int iVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  undefined8 *puStackX_18;
  undefined8 uStack_d8;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined8 uStack_a8;
  undefined uStack_a0;
  uint uStack_9c;
  uint uStack_98;
  longlong lStack_90;
  longlong *plStack_88;
  longlong lStack_80;
  longlong lStack_78;
  undefined8 *puStack_70;
  longlong lStack_68;
  longlong lStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  
  uStack_48 = 0xfffffffffffffffe;
  plVar4 = (longlong *)param_3[2];
  lStack_60 = *(longlong *)param_3[4];
  lVar5 = ((longlong *)param_3[4])[1];
  puStackX_18 = param_3;
  plStack_88 = plVar4;
  puStack_70 = (undefined8 *)param_1;
  lVar8 = (**(code **)(*plVar4 + 0x420))(plVar4);
  lStack_78 = lVar8;
  lVar9 = (**(code **)(*plVar4 + 0x2b0))(plVar4);
  lStack_68 = plVar4[9];
  uVar15 = 0;
  if (*(uint *)(lVar5 + 0x18) != 0) {
    do {
      if ((*(byte *)(*(longlong *)
                      (**(longlong **)
                         (*(longlong *)(*(longlong *)(lVar5 + 0x20) + (longlong)(int)uVar15 * 8) +
                         0x20) + 0x10) + 0x50) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar15 = uVar15 + 1;
    } while (uVar15 < *(uint *)(lVar5 + 0x18));
  }
  if (lStack_68 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_d8 = 0;
  lStack_80 = 0;
  (**(code **)(*plStack_88 + 0x2b0))();
  func_0x(param_1,lVar5);
  uStack_58 = 0;
  uStack_50 = 0;
  uStack_a0 = 0;
  uStack_9c = 0;
  uStack_98 = 4;
  lStack_90 = 0;
  uStack_b0 = 1;
  uStack_b8 = 0x210b858;
  uStack_a8 = param_1;
  puVar10 = (undefined8 *)func_0x(param_1,lVar5);
  lVar5 = lStack_78;
  uVar15 = *(uint *)(lVar8 + 0x1c);
  uVar16 = 0;
  if (uVar15 != 0) {
    lVar8 = 0;
    uVar14 = uStack_9c;
    do {
      if (*(uint *)(lVar5 + 0x1c) <= uVar16) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar6 = *(undefined8 *)(lVar8 + *(longlong *)(lVar5 + 0x28));
      iVar7 = func_0x(lVar9,uVar6,0);
      if ((iVar7 == -1) && (iVar7 = func_0x(puVar10,uVar6,0), iVar7 == -1)) {
        if (lStack_90 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (uStack_98 <= uVar14) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined8 *)(lStack_90 + (ulonglong)uVar14 * 8) = uVar6;
        uVar14 = uStack_9c + 1;
        uStack_9c = uVar14;
      }
      uVar16 = uVar16 + 1;
      lVar8 = lVar8 + 8;
      uStack_d8 = uStack_58;
      param_1 = puStack_70;
    } while (uVar16 < uVar15);
  }
  puVar11 = puVar10 + 1;
  *(int *)puVar11 = *(int *)puVar11 + -1;
  if (*(int *)puVar11 == 0) {
    (**(code **)*puVar10)(puVar10,1);
  }
  uVar3 = *(undefined4 *)((longlong)plStack_88 + 0x5c);
  lVar5 = plStack_88[0xc];
  puVar10 = (undefined8 *)func_0x(param_1,uStack_d8);
  puVar11 = (undefined8 *)(*_DAT_)(0x30,param_1,0x210f600,0x192b,1);
  if (puVar11 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar13 = *(int *)((longlong)puVar10 + 0x1c) + *(int *)(lVar9 + 0x1c) + uStack_9c;
  puVar11[2] = param_1;
  *(undefined *)(puVar11 + 3) = 0;
  *(undefined4 *)((longlong)puVar11 + 0x1c) = 0;
  iVar7 = 1;
  if (iVar13 != 0) {
    iVar7 = iVar13;
  }
  *(int *)(puVar11 + 4) = iVar7;
  puVar11[5] = 0;
  *puVar11 = 0x2046530;
  *(undefined4 *)(puVar11 + 1) = 1;
  *puVar11 = 0x210b858;
  puStack_70 = puVar11;
  func_0x(puVar11,puVar10);
  puVar1 = puVar10 + 1;
  *(int *)puVar1 = *(int *)puVar1 + -1;
  if (*(int *)puVar1 == 0) {
    (**(code **)*puVar10)(puVar10,1);
  }
  func_0x(puVar11,lVar9);
  func_0x(puVar11,&uStack_b8);
  *(int *)(lVar9 + 8) = *(int *)(lVar9 + 8) + 1;
  if (lStack_68 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(param_2 + 0x6a) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (lVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar10 = (undefined8 *)(*_DAT_)(0x68,param_1,0x210f600,0x1945,1);
  lVar5 = lStack_60;
  if (puVar10 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar10 = 0x2046530;
  *(undefined4 *)(puVar10 + 1) = 1;
  *puVar10 = 0x1fc1920;
  puVar10[2] = param_1;
  *puVar10 = 0x1f97448;
  *puVar10 = 0x1f3df78;
  puVar10[3] = puVar11;
  puVar10[4] = lVar9;
  puVar10[5] = 0;
  *(undefined *)(puVar10 + 6) = 0;
  *puVar10 = 0x1f3e470;
  *(undefined *)(puVar10 + 7) = 0;
  *(undefined4 *)((longlong)puVar10 + 0x3c) = 1;
  *(undefined2 *)(puVar10 + 8) = 0;
  puVar10[9] = lStack_68;
  puVar10[10] = 0;
  *(undefined *)(puVar10 + 0xb) = 0;
  *(undefined4 *)((longlong)puVar10 + 0x5c) = uVar3;
  puVar10[0xc] = 0;
  *(int *)(lStack_60 + 8) = *(int *)(lStack_60 + 8) + 1;
  puVar11 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x210f600,0x1952,1);
  lVar8 = lStack_78;
  if (puVar11 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar11 = 0x2046530;
  *(undefined4 *)(puVar11 + 1) = 1;
  *puVar11 = 0x210b6a0;
  puVar11[0xc] = 0;
  puVar11[0xd] = 0;
  puVar11[0xe] = 0;
  puVar11[0xf] = 0;
  puVar11[0x11] = _DAT_;
  puVar11[0x12] = 0;
  puVar11[0x13] = 0;
  puVar11[0x14] = 0;
  *(undefined4 *)(puVar11 + 3) = 2;
  puVar11[4] = puVar11 + 5;
  puVar11[5] = lVar5;
  *(undefined8 *)(puVar11[4] + 8) = uStack_58;
  puVar11[2] = puVar10;
  puVar11[10] = 0;
  puVar11[0xb] = 0;
  puVar11[0x10] = 0;
  if (param_5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (lStack_80 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(int *)(lStack_78 + 8) = *(int *)(lStack_78 + 8) + 1;
  *(int *)(lVar9 + 8) = *(int *)(lVar9 + 8) + 1;
  iVar7 = 2;
  if ((*(int *)((longlong)plStack_88 + 0x3c) - 1U & 0xfffffffd) == 0) {
    iVar7 = *(int *)((longlong)plStack_88 + 0x3c);
  }
  puVar10 = (undefined8 *)(*_DAT_)(0x68,param_1,0x210f600,0x1976,1);
  if (puVar10 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = *(undefined *)(plStack_88 + 7);
  *puVar10 = 0x2046530;
  *(undefined4 *)(puVar10 + 1) = 1;
  *puVar10 = 0x1fc1920;
  puVar10[2] = param_1;
  *puVar10 = 0x1f97448;
  *puVar10 = 0x1f3df78;
  puVar10[3] = lVar8;
  puVar10[4] = lVar9;
  puVar10[5] = 0;
  *(undefined *)(puVar10 + 6) = 0;
  *puVar10 = 0x1f3e470;
  *(undefined *)(puVar10 + 7) = uVar2;
  *(int *)((longlong)puVar10 + 0x3c) = iVar7;
  *(undefined2 *)(puVar10 + 8) = 0;
  puVar10[9] = 0;
  puVar10[10] = 0;
  *(undefined *)(puVar10 + 0xb) = 0;
  *(undefined4 *)((longlong)puVar10 + 0x5c) = uVar3;
  puVar10[0xc] = 0;
  puVar12 = (undefined8 *)(*_DAT_)(0xa8,param_1,0x210f600,0x1983,1);
  puVar1 = puStackX_18;
  if (puVar12 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar12 = 0x2046530;
  *(undefined4 *)(puVar12 + 1) = 1;
  *puVar12 = 0x210b6a0;
  puVar12[0xc] = 0;
  puVar12[0xd] = 0;
  puVar12[0xe] = 0;
  puVar12[0xf] = 0;
  puVar12[0x11] = _DAT_;
  puVar12[0x12] = 0;
  puVar12[0x13] = 0;
  puVar12[0x14] = 0;
  *(undefined4 *)(puVar12 + 3) = 2;
  puVar12[4] = puVar12 + 5;
  puVar12[5] = puVar11;
  *(undefined8 *)(puVar12[4] + 8) = uStack_50;
  puVar12[2] = puVar10;
  puVar12[10] = 0;
  puVar12[0xb] = 0;
  puVar12[0x10] = 0;
  func_0x(puVar12,puStackX_18[0xe]);
  plVar4 = *(longlong **)(puVar1[10] + 0x108);
  if (plVar4 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  (**(code **)(*plVar4 + 8))(plVar4,&puStackX_18);
  puVar12[0x11] = puStackX_18;
  func_0x(param_1,puVar12,lStack_78);
  uStack_b8 = 0x2046530;
  puStackX_18 = &uStack_a8;
  func_0x(&uStack_a8);
  if (lStack_90 != 0) {
    (*_DAT_)();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

