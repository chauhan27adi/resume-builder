
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00100486) */
/* WARNING: Removing unreachable block (ram,0x0166be9f) */
/* WARNING: Removing unreachable block (ram,0x001004a0) */
/* WARNING: Removing unreachable block (ram,0x0166beb1) */
/* WARNING: Removing unreachable block (ram,0x001004ae) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  uint *puVar1;
  undefined8 **ppuVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  uint *puVar5;
  uint *puVar6;
  undefined8 **ppuVar7;
  int *piVar8;
  char cVar9;
  ulonglong uVar10;
  int iVar11;
  uint uVar12;
  undefined8 **ppuVar13;
  bool bVar15;
  undefined8 **ppuVar16;
  ulonglong uVar17;
  int *piVar18;
  uint uVar19;
  undefined8 **ppuVar20;
  int iVar21;
  int iVar22;
  int iVar23;
  longlong lVar24;
  uint uVar25;
  longlong lVar26;
  ulonglong uVar27;
  undefined8 uVar28;
  undefined8 extraout_XMM0_Qa;
  undefined8 uVar29;
  undefined8 extraout_XMM0_Qa_00;
  undefined auStack_208 [32];
  uint uStack_1e8;
  undefined auStack_1e4 [4];
  undefined8 **ppuStack_1e0;
  undefined8 uStack_1d8;
  uint uStack_1d0;
  uint uStack_1cc;
  longlong lStack_1c8;
  longlong lStack_1c0;
  undefined8 **ppuStack_1b8;
  undefined8 uStack_1b0;
  longlong lStack_1a8;
  int *piStack_1a0;
  undefined4 uStack_198;
  undefined8 uStack_190;
  undefined8 *apuStack_188 [6];
  undefined8 uStack_158;
  undefined8 *apuStack_150 [6];
  undefined8 uStack_120;
  undefined8 *apuStack_118 [6];
  undefined8 uStack_e8;
  undefined8 *apuStack_e0 [6];
  undefined8 uStack_b0;
  undefined8 *apuStack_a8 [6];
  undefined8 uStack_78;
  longlong lStack_70;
  uint uStack_68;
  uint auStack_64 [9];
  undefined8 uStack_40;
  ulonglong uStack_38;
  ulonglong uVar14;
  
  uStack_190 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_208;
  lVar26 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 0xa8) + 8);
  lStack_1c8 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x40) + 0xa8) + 8);
  uVar29 = *(undefined8 *)(param_1 + 0x10);
  lStack_1c0 = param_1;
  lStack_1a8 = lVar26;
  func_0x(&lStack_70);
  uStack_1e8 = 0;
  uVar19 = *(uint *)(lVar26 + 0xc);
  uStack_40 = uVar29;
  if (uVar19 != 0) {
    do {
      uVar25 = uStack_1e8;
      uVar10 = 0;
      if (uVar19 <= uStack_1e8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar5 = *(uint **)(*(longlong *)(lVar26 + 0x18) + (ulonglong)uStack_1e8 * 8);
      uVar29 = *(undefined8 *)(param_1 + 0x10);
      func_0x(apuStack_188);
      uVar28 = *(undefined8 *)(param_1 + 0x10);
      uStack_158 = uVar29;
      func_0x(apuStack_e0);
      uVar29 = *(undefined8 *)(param_1 + 0x10);
      uStack_b0 = uVar28;
      func_0x(apuStack_118);
      uStack_e8 = uVar29;
      func_0x(apuStack_118,uVar29,*puVar5);
      uVar19 = *(uint *)(lStack_1c8 + 0xc);
      if (uVar19 != 0) {
        do {
          uVar17 = 0;
          uVar12 = (uint)uVar10;
          if ((ulonglong)uStack_68 + 0x100 <= uVar10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((uVar12 < uStack_68) ||
             ((auStack_64[uVar12 - uStack_68 >> 5] & 1 << ((byte)(uVar12 - uStack_68) & 0x1f)) == 0)
             ) {
            if (uVar19 <= uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            puVar6 = *(uint **)(*(longlong *)(lStack_1c8 + 0x18) + uVar10 * 8);
            uVar29 = *(undefined8 *)(param_1 + 0x10);
            uVar28 = func_0x(apuStack_150);
            uVar14 = uVar17;
            uVar27 = uVar17;
            uStack_120 = uVar29;
            do {
              puVar3 = (undefined8 *)(*(longlong *)(puVar5 + 2) + uVar17 * 0x18);
              puVar4 = (undefined8 *)(*(longlong *)(puVar6 + 2) + uVar14 * 0x18);
              iVar22 = (int)((ulonglong)*puVar4 >> 0x20);
              iVar23 = (int)((ulonglong)*puVar3 >> 0x20);
              if (iVar23 != iVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              iVar11 = (int)*puVar4;
              iVar21 = (int)*puVar3;
              if (iVar21 != iVar11) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              if (*(int *)(puVar3 + 1) != *(int *)(puVar4 + 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              if ((ulonglong)puVar3[2] < (ulonglong)puVar4[2]) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              if ((((iVar23 == iVar22) && (iVar21 == iVar11)) &&
                  (*(int *)(puVar3 + 1) == *(int *)(puVar4 + 1))) && (puVar3[2] == puVar4[2])) {
                uVar28 = func_0x(apuStack_150,uStack_120,uVar17);
                uVar27 = (ulonglong)((int)uVar27 + 1);
                uVar17 = (ulonglong)((int)uVar17 + 1);
              }
              param_1 = lStack_1c0;
              uVar19 = (int)uVar14 + 1;
              uVar14 = (ulonglong)uVar19;
            } while ((uVar19 < *puVar6) && ((uint)uVar17 < *puVar5));
            uVar29 = *(undefined8 *)(lStack_1c0 + 0x20);
            ppuStack_1b8 = apuStack_150;
            uStack_1b0 = 0;
            cVar9 = func_0x(uVar28,&ppuStack_1b8,&uStack_1d0);
            while (cVar9 != '\0') {
              uVar28 = func_0x(uVar29,uVar10,
                                       *(longlong *)(puVar5 + 2) + (ulonglong)uStack_1d0 * 0x18);
              cVar9 = func_0x(uVar28,&ppuStack_1b8,&uStack_1d0);
            }
            func_0x(apuStack_e0,uStack_b0,apuStack_150);
            if ((uint)uVar27 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            puVar3 = apuStack_150[0];
            if (*puVar6 != (uint)uVar27) goto joined_r0x001006a0;
            func_0x(apuStack_188,uStack_158,uVar10);
            uVar19 = func_0x(apuStack_e0);
            puVar3 = apuStack_150[0];
            if (*puVar5 == uVar19) {
              uVar25 = uStack_1e8;
              if (apuStack_150[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                halt_baddata();
              }
              break;
            }
            while (apuStack_150[0] = puVar3, puVar3 != (undefined8 *)0x0) {
              apuStack_150[0] = (undefined8 *)*puVar3;
              (*_DAT_)(puVar3,0x30);
              puVar3 = apuStack_150[0];
            }
          }
          uVar10 = (ulonglong)(uVar12 + 1);
          uVar19 = *(uint *)(lStack_1c8 + 0xc);
          uVar25 = uStack_1e8;
        } while (uVar12 + 1 < uVar19);
      }
      param_1 = lStack_1c0;
      ppuVar16 = apuStack_188;
      do {
        piVar18 = (int *)((longlong)ppuVar16 + 0xc);
        ppuVar13 = (undefined8 **)0x0;
        do {
          if (*piVar18 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar19 = (int)ppuVar13 + 1;
          ppuVar13 = (undefined8 **)(ulonglong)uVar19;
          piVar18 = piVar18 + 1;
        } while (uVar19 < 8);
        ppuVar16 = (undefined8 **)*ppuVar16;
      } while (ppuVar16 != (undefined8 **)0x0);
      ppuVar16 = apuStack_e0;
      bVar15 = false;
      ppuVar13 = (undefined8 **)0x0;
      ppuVar20 = apuStack_118;
      do {
        if (ppuVar16 == (undefined8 **)0x0) break;
        if (*(uint *)(ppuVar16 + 1) < *(uint *)(ppuVar20 + 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((ppuVar16 != (undefined8 **)0x0) && (*(uint *)(ppuVar20 + 1) == *(uint *)(ppuVar16 + 1))
           ) {
          *(uint *)((longlong)ppuVar20 + 0xc) =
               *(uint *)((longlong)ppuVar20 + 0xc) & ~*(uint *)((longlong)ppuVar16 + 0xc);
          *(uint *)(ppuVar20 + 2) = *(uint *)(ppuVar20 + 2) & ~*(uint *)(ppuVar16 + 2);
          puVar6 = (uint *)((longlong)ppuVar20 + 0x14);
          *puVar6 = *puVar6 & ~*(uint *)((longlong)ppuVar16 + 0x14);
          ppuVar7 = ppuVar20 + 3;
          *(uint *)ppuVar7 = *(uint *)ppuVar7 & ~*(uint *)(ppuVar16 + 3);
          puVar1 = (uint *)((longlong)ppuVar20 + 0x1c);
          *puVar1 = *puVar1 & ~*(uint *)((longlong)ppuVar16 + 0x1c);
          ppuVar2 = ppuVar20 + 4;
          *(uint *)ppuVar2 = *(uint *)ppuVar2 & ~*(uint *)(ppuVar16 + 4);
          bVar15 = *(uint *)ppuVar2 != 0 ||
                   (*puVar1 != 0 ||
                   (*(uint *)ppuVar7 != 0 ||
                   (*puVar6 != 0 ||
                   (*(int *)(ppuVar20 + 2) != 0 || *(int *)((longlong)ppuVar20 + 0xc) != 0))));
          *(uint *)((longlong)ppuVar20 + 0x24) =
               *(uint *)((longlong)ppuVar20 + 0x24) & ~*(uint *)((longlong)ppuVar16 + 0x24);
          *(uint *)(ppuVar20 + 5) = *(uint *)(ppuVar20 + 5) & ~*(uint *)(ppuVar16 + 5);
          ppuVar16 = (undefined8 **)*ppuVar16;
        }
        if (ppuVar13 != (undefined8 **)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        ppuVar7 = (undefined8 **)*ppuVar20;
        ppuVar13 = ppuVar20;
        ppuVar20 = ppuVar7;
      } while (ppuVar7 != (undefined8 **)0x0);
      ppuStack_1e0 = apuStack_118;
      uStack_1d8 = 0;
      uVar29 = *(undefined8 *)(lStack_1c0 + 0x10);
      uVar28 = func_0x(apuStack_a8,bVar15);
      uStack_78 = uVar29;
      cVar9 = func_0x(uVar28,&ppuStack_1e0,&uStack_1cc);
      uVar29 = extraout_XMM0_Qa;
      while (cVar9 != '\0') {
        uVar10 = (ulonglong)uStack_1cc;
        piVar18 = (int *)(*(longlong *)(puVar5 + 2) + uVar10 * 0x18);
        lVar26 = *(longlong *)(param_1 + 0x40);
        lVar24 = *(longlong *)(*(longlong *)(lVar26 + 0xa8) + 0x18);
        uStack_198 = 0xffffffff;
        piStack_1a0 = piVar18;
        uVar19 = func_0x();
        lVar24 = *(longlong *)
                  (*(longlong *)(lVar24 + 0x10) +
                  ((ulonglong)uVar19 % (ulonglong)*(uint *)(lVar24 + 0xc)) * 8);
        if (lVar24 == 0) {
LAB_:
          if (apuStack_a8[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (apuStack_118[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          puVar3 = apuStack_188[0];
          if (apuStack_e0[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          while (apuStack_188[0] = puVar3, puVar3 != (undefined8 *)0x0) {
            apuStack_188[0] = (undefined8 *)*puVar3;
            (*_DAT_)(puVar3,0x30);
            puVar3 = apuStack_188[0];
          }
          goto LAB_;
        }
        if (uVar19 != *(uint *)(lVar24 + 0x18)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        piVar8 = *(int **)(lVar24 + 8);
        if (piVar18[1] != piVar8[1]) {
          return;
        }
        if (*piVar18 != *piVar8) {
          return;
        }
        if (piVar18[2] != piVar8[2]) {
          return;
        }
        if (*(longlong *)(piVar18 + 4) != *(longlong *)(piVar8 + 4)) {
          return;
        }
        if ((int **)(lVar24 + 8) == (int **)0x0) goto LAB_;
        uVar17 = *(ulonglong *)(lVar24 + 0x10);
        if ((int)uVar17 == -1) goto LAB_;
        lVar26 = *(longlong *)(lVar26 + 0x98);
        uVar19 = *(uint *)(lVar26 + 0x1c);
        if (uVar19 == 0) goto LAB_;
        uVar14 = 0;
        while (*(int *)(*(longlong *)(lVar26 + 0x28) + uVar14 * 4) != (int)uVar17) {
          uVar12 = (int)uVar14 + 1;
          uVar14 = (ulonglong)uVar12;
          if (uVar19 <= uVar12) goto LAB_;
        }
        if ((int)uVar14 == -1) goto LAB_;
        func_0x(apuStack_a8,uStack_78,uVar17 & 0xffffffff);
        param_1 = lStack_1c0;
        uVar29 = func_0x(*(undefined8 *)(lStack_1c0 + 0x20),uVar17 & 0xffffffff,
                                 *(longlong *)(puVar5 + 2) + uVar10 * 0x18);
        cVar9 = func_0x(uVar29,&ppuStack_1e0,&uStack_1cc);
        uVar29 = extraout_XMM0_Qa_00;
      }
      ppuStack_1e0 = apuStack_a8;
      uStack_1d8 = 0;
      cVar9 = func_0x(uVar29,&ppuStack_1e0,auStack_1e4);
      if (cVar9 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(&lStack_70,uStack_40,apuStack_188);
      if (apuStack_a8[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (apuStack_118[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (apuStack_e0[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (apuStack_188[0] != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uStack_1e8 = uVar25 + 1;
      uVar19 = *(uint *)(lStack_1a8 + 0xc);
      lVar26 = lStack_1a8;
    } while (uStack_1e8 < uVar19);
  }
  func_0x(&lStack_70);
LAB_:
  if (lStack_70 == 0) {
    func_0x(uStack_38 ^ (ulonglong)auStack_208);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
joined_r0x001006a0:
  while (puVar3 != (undefined8 *)0x0) {
    apuStack_150[0] = (undefined8 *)*puVar3;
    (*_DAT_)(puVar3,0x30);
    puVar3 = apuStack_150[0];
  }
  apuStack_150[0] = (undefined8 *)0x0;
  puVar3 = apuStack_118[0];
  while (puVar3 != (undefined8 *)0x0) {
    apuStack_118[0] = (undefined8 *)*puVar3;
    (*_DAT_)(puVar3,0x30);
    puVar3 = apuStack_118[0];
  }
  apuStack_118[0] = (undefined8 *)0x0;
  puVar3 = apuStack_e0[0];
  while (puVar3 != (undefined8 *)0x0) {
    apuStack_e0[0] = (undefined8 *)*puVar3;
    (*_DAT_)(puVar3,0x30);
    puVar3 = apuStack_e0[0];
  }
  apuStack_e0[0] = (undefined8 *)0x0;
  puVar3 = apuStack_188[0];
  while (apuStack_188[0] = puVar3, puVar3 != (undefined8 *)0x0) {
    apuStack_188[0] = (undefined8 *)*puVar3;
    (*_DAT_)(puVar3,0x30);
    puVar3 = apuStack_188[0];
  }
  goto LAB_;
}

