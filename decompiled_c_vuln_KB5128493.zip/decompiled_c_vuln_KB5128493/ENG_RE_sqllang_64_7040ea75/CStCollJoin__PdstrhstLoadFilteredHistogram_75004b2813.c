
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 *param_4)

{
  uint uVar1;
  longlong *plVar2;
  undefined8 uVar3;
  bool bVar4;
  
  if (param_4 != (undefined8 *)0x0) {
    *param_4 = _DAT_;
  }
  uVar1 = func_0x();
  if (uVar1 < 2) {
    bVar4 = uVar1 == 0;
    switch(*(undefined4 *)(param_1 + 0x48)) {
    case 1:
    case 6:
    case 7:
    case 8:
      goto code_r0x0010006f;
    case 2:
    case 4:
      break;
    case 3:
    case 5:
      bVar4 = !bVar4;
      break;
    default:
      goto code_r0x001000a9;
    }
    if (bVar4) {
code_r0x0010006f:
      plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x50 + (ulonglong)uVar1 * 8) + 0x108);
      if (plVar2 == (longlong *)0x0) {
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar2 = (longlong *)(**(code **)(*plVar2 + 0xa8))();
      }
      uVar3 = (**(code **)(*plVar2 + 0x128))(plVar2,param_2,param_3,param_4);
      return uVar3;
    }
  }
code_r0x001000a9:
  return 0;
}

