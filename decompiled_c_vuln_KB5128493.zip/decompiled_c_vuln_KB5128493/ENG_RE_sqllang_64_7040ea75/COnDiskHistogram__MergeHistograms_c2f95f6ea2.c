
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x01678788) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,uint param_3,undefined param_4)

{
  byte *pbVar1;
  byte bVar2;
  int iVar3;
  char *pcVar4;
  undefined auVar5 [16];
  undefined auVar6 [16];
  undefined auVar7 [16];
  char cVar8;
  undefined8 uVar9;
  undefined8 *puVar10;
  undefined8 uVar11;
  longlong *plVar12;
  double *pdVar13;
  longlong lVar14;
  int iVar15;
  char *pcVar16;
  longlong lVar17;
  longlong *plVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  int aiStackX_10 [2];
  char cStackX_18;
  undefined uStackX_20;
  char *pcVar21;
  ulonglong in_stack_fffffffffffffe68;
  double dStack_100;
  longlong *plStack_f8;
  uint uStack_f0;
  byte *pbStack_e8;
  longlong *plStack_e0;
  undefined8 *puStack_d8;
  undefined8 uStack_d0;
  longlong lStack_c8;
  undefined auStack_c0 [128];
  
  uStack_d0 = 0xfffffffffffffffe;
  uVar20 = (ulonglong)param_3;
  pbVar1 = (byte *)(param_1 + 0x18);
  if (*pbVar1 == 0x7f) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*pbVar1 < 0x39) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  cStackX_18 = '\0';
  uVar19 = (ulonglong)(int)param_3;
  if (0 < (int)param_3) {
    lVar14 = 0;
    iVar15 = *(int *)(param_1 + 0xf8);
    do {
      iVar15 = iVar15 + *(int *)(param_2[lVar14] + 0xf4);
      *(int *)(param_1 + 0xf8) = iVar15;
      lVar14 = lVar14 + 1;
    } while (lVar14 < (longlong)uVar19);
  }
  uStackX_20 = param_4;
  (**(code **)(*(longlong *)(param_1 + 0x138) + 8))
            ((longlong *)(param_1 + 0x138),*(undefined8 *)(param_1 + 0x10),pbVar1);
  lVar14 = param_1 + 0xa0;
  lVar17 = 2;
  do {
    func_0x(lVar14,*(undefined8 *)(param_1 + 0x10),pbVar1);
    lVar14 = lVar14 + 0x28;
    lVar17 = lVar17 + -1;
  } while (lVar17 != 0);
  *(undefined4 *)(param_1 + 0xf0) = 0x10000;
  *(byte *)(param_1 + 0x130) = *(byte *)(param_1 + 0x130) & 0xfd;
  *(byte *)(param_1 + 0x130) =
       *(byte *)(param_1 + 0x130) |
       -(*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar1 + 0x1e8ce70) + 0x1ec1e38) != '\0') & 2U;
  auVar5._8_8_ = 0;
  auVar5._0_8_ = (longlong)*(int *)(param_1 + 0xf8);
  uVar9 = SUB168(ZEXT816(8) * auVar5,0);
  if (SUB168(ZEXT816(8) * auVar5,8) != 0) {
    uVar9 = 0xffffffffffffffff;
  }
  uVar9 = (*_DAT_)(uVar9,*(undefined8 *)(param_1 + 0x10),0x1fade28,0x796,1);
  *(undefined8 *)(param_1 + 0x90) = uVar9;
  iVar15 = 0;
  if (0 < *(int *)(param_1 + 0xf8)) {
    do {
      aiStackX_10[0] = 0x79a;
      puVar10 = (undefined8 *)
                (*_DAT_)(0x28,*(undefined8 *)(param_1 + 0x10),0x1fade28,0x79a,1);
      if (puVar10 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *puVar10 = 0;
      puVar10[1] = 0;
      *(undefined *)(puVar10 + 2) = 0;
      puVar10[3] = 0;
      puVar10[4] = 0;
      *(undefined *)(puVar10 + 2) = 0;
      iVar3 = *(int *)(param_1 + 0x98);
      *(int *)(param_1 + 0x98) = iVar3 + 1;
      *(undefined8 **)(*(longlong *)(param_1 + 0x90) + 8 + (longlong)iVar3 * 8) = puVar10;
      func_0x(puVar10,*(undefined8 *)(param_1 + 0x10),pbVar1);
      iVar15 = iVar15 + 1;
    } while (iVar15 < *(int *)(param_1 + 0xf8));
  }
  *(byte *)(param_1 + 0x130) = *(byte *)(param_1 + 0x130) & 0xfe;
  bVar2 = *pbVar1;
  if ((byte)(bVar2 + 0x9e) < 0x19) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (bVar2 < 0x3f) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((0x3e < (byte)(bVar2 - 0x7f)) ||
     ((0x4001414000000001U >> ((ulonglong)(bVar2 - 0x7f) & 0x3f) & 1) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(undefined *)(param_1 + 0x120) = 1;
  *(undefined8 *)(param_1 + 0x128) = *(undefined8 *)(*param_2 + 0x128);
  plVar12 = param_2;
  if (0 < (int)param_3) {
    do {
      func_0x(*plVar12);
      lVar14 = *plVar12;
      puVar10 = *(undefined8 **)(lVar14 + 0x70);
      if (puVar10 != (undefined8 *)0x0) {
        (*_DAT_)(*puVar10);
        (*_DAT_)(puVar10,0x20);
        *(undefined8 *)(*plVar12 + 0x70) = 0;
        lVar14 = *plVar12;
      }
      *(longlong *)(param_1 + 0x100) =
           *(longlong *)(param_1 + 0x100) + *(longlong *)(lVar14 + 0x100);
      *(longlong *)(param_1 + 0x108) =
           *(longlong *)(param_1 + 0x108) + *(longlong *)(*plVar12 + 0x108);
      uVar20 = uVar20 - 1;
      plVar12 = plVar12 + 1;
    } while (uVar20 != 0);
  }
  uVar9 = *(undefined8 *)(param_1 + 0x10);
  auVar6._8_8_ = 0;
  auVar6._0_8_ = uVar19;
  uVar11 = SUB168(ZEXT816(0x10) * auVar6,0);
  if (SUB168(ZEXT816(0x10) * auVar6,8) != 0) {
    uVar11 = 0xffffffffffffffff;
  }
  plStack_f8 = param_2;
  uStack_f0 = param_3;
  pbStack_e8 = pbVar1;
  plVar12 = (longlong *)(*_DAT_)(uVar11,uVar9,0x1fade28,0x6d1,1);
  plStack_e0 = plVar12;
  puVar10 = (undefined8 *)(*_DAT_)(0x18,uVar9,0x1fade28,0x6d2,1);
  if (puVar10 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *puVar10 = 0;
  *(undefined4 *)(puVar10 + 1) = 0;
  *(uint *)((longlong)puVar10 + 0xc) = param_3;
  puVar10[2] = pbVar1;
  if (param_3 + 1 < param_3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  auVar5 = ZEXT816(8) * ZEXT416(param_3 + 1);
  uVar11 = auVar5._0_8_;
  if (auVar5._8_8_ != 0) {
    uVar11 = 0xffffffffffffffff;
  }
  uVar9 = (*_DAT_)(uVar11,uVar9,0x1fadcc0,0x32,1);
  *puVar10 = uVar9;
  iVar15 = 0;
  plVar18 = plVar12;
  puStack_d8 = puVar10;
  if (0 < (int)param_3) {
    do {
      lVar14 = *(longlong *)(*param_2 + 0x78);
      *(longlong *)(*param_2 + 0x88) = lVar14;
      *plVar12 = lVar14;
      if (lVar14 != 0) {
        *(int *)(plVar12 + 1) = iVar15;
        func_0x(puVar10,plVar18);
      }
      iVar15 = iVar15 + 1;
      param_2 = param_2 + 1;
      plVar12 = plVar12 + 2;
      plVar18 = plVar18 + 2;
    } while (iVar15 < (int)param_3);
  }
  auVar7._8_8_ = 0;
  auVar7._0_8_ = uVar19;
  uVar9 = SUB168(ZEXT816(8) * auVar7,0);
  if (SUB168(ZEXT816(8) * auVar7,8) != 0) {
    uVar9 = 0xffffffffffffffff;
  }
  lVar14 = (*_DAT_)(uVar9,*(undefined8 *)(param_1 + 0x10),0x1fade28,0x7c6,1);
  if (0 < (int)param_3) {
    lStack_c8 = lVar14;
    func_0x(lVar14,0,uVar19 << 3);
    lVar17 = func_0x(&plStack_f8,aiStackX_10);
    if (lVar17 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(param_1,lVar17);
    *(undefined8 *)(lVar14 + (longlong)aiStackX_10[0] * 8) = *(undefined8 *)(param_1 + 0x88);
    plVar12 = (longlong *)func_0x(&plStack_f8,aiStackX_10);
    if (plVar12 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar17 = *plVar12;
    if ((longlong *)plVar12[4] == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    pcVar16 = *(char **)(*(longlong *)plVar12[4] + 0x10);
    plVar18 = *(longlong **)(*(longlong *)(lVar14 + (longlong)aiStackX_10[0] * 8) + 0x18);
    if (plVar18 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    while( true ) {
      lVar14 = *plVar18;
      pcVar4 = *(char **)(*plVar12 + 0x10);
      pcVar21 = *(char **)(lVar14 + 0x10);
      if (pcVar21[1] != pcVar16[1]) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (pcVar21[1] != pcVar4[1]) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((*pcVar16 == '\x03') || (*pcVar21 == '\x03')) || (*pcVar4 == '\x03')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar20 = (*_DAT_)(pcVar4,pbVar1,pbVar1,pcVar21);
      if ((uVar20 & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar20 = (*_DAT_)(pcVar16,pbVar1,pbVar1,pcVar21);
      if ((uVar20 & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      cVar8 = (*_DAT_)(pcVar21[1]);
      if (cVar8 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      pdVar13 = (double *)
                func_0x
                          (auStack_c0,pbVar1,param_1 + 0x38,pcVar16,pcVar21,pcVar4,
                           in_stack_fffffffffffffe68 & 0xffffffffffffff00,0,0);
      dStack_100 = *pdVar13;
      if (dStack_100 < 0.0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      pcVar16 = *(char **)(*plVar18 + 0x10);
      if (cStackX_18 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((longlong *)plVar18[3] == (longlong *)0x0) break;
      in_stack_fffffffffffffe68 = 0xffffffffffffffff;
      func_0x(lVar14,lVar17,&dStack_100,0,(ulonglong)pcVar21 & 0xffffffffffffff00,
                      0xffffffffffffffff,0xffffffffffffffff,uStackX_20);
      plVar18 = (longlong *)plVar18[3];
      if (plVar18 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

