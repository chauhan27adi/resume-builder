
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,undefined8 param_3,longlong param_4)

{
  uint uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  code *UNRECOVERED_JUMPTABLE;
  longlong lVar7;
  int iVar8;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_1f8;
  undefined uStack_1f0;
  undefined8 uStack_1e8;
  undefined8 uStack_1e0;
  undefined2 uStack_1d8;
  undefined8 uStack_1d4;
  undefined4 uStack_1cc;
  undefined8 uStack_48;
  longlong *plStack_40;
  
  uStack_48 = 0xfffffffffffffffe;
  lVar7 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar3 = *(longlong *)(lVar7 + 0x100);
  if (lVar3 == 0) {
    (*_DAT_)(0);
    lVar3 = *(longlong *)(lVar7 + 0x100);
  }
  lVar3 = *(longlong *)(lVar3 + 0x3e0);
  uVar4 = (*_DAT_)();
  lVar7 = (*_DAT_)(uVar4,*(undefined2 *)(lVar3 + 0xa0));
  (*_DAT_)();
  lVar3 = *(longlong *)(lVar7 + 0x30) + 0x40;
  if (*(longlong *)(lVar7 + 0x30) == 0) {
    lVar3 = 0;
  }
  plVar5 = (longlong *)(*_DAT_)(0x5c,1,lVar3,8,0x80);
  if (plVar5 == (longlong *)0x0) {
    func_0x(0x41);
  }
  *(undefined4 *)(param_4 + 8) = 1;
  uStack_1f0 = 4;
  uStack_1f8 = 0x1e6f668;
  uStack_1e8 = 0;
  uStack_1e0 = 0;
  uStack_1d8 = 0;
  uStack_1d4 = 0;
  uStack_1cc = 0;
  plStack_40 = plVar5;
  func_0x(&uStack_1f8,plVar5,param_3);
  plVar6 = (longlong *)func_0x(uStack_1e8 & 0xffffffff,4,1);
  if (uStack_1e8._4_4_ != 0x20) {
    uVar1 = (uStack_1e8._4_4_ & 0x1f) - 1;
    if (uVar1 < 0x20) {
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)uVar1 + 0x10074c) * 4 + 0x10073c)
                   - 0x4c7c80);
                    /* WARNING: Could not recover jumptable at 0x0010017c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
    goto LAB_;
  }
  iVar8 = (int)uStack_1d4;
  if ((int)uStack_1d4 < 1) {
LAB_:
    iVar8 = 1;
  }
  else {
    iVar2 = (**(code **)(*plVar6 + 0x28))(plVar6,0x20);
    if (iVar2 < iVar8) goto LAB_;
  }
  (**(code **)(*plVar6 + 0x48))(plVar6,0x1c,iVar8);
  *(undefined4 *)(param_4 + 8) = 0;
LAB_:
  uStack_1f8 = 0x1e6f668;
  (*_DAT_)(uStack_1e0);
  uStack_1f8 = 0x1b8fb40;
  (**(code **)(*plVar5 + 0x10))(plVar5);
  return;
}

