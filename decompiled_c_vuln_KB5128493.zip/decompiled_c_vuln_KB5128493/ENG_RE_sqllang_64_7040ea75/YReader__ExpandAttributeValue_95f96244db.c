
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,longlong *param_2,longlong param_3,longlong *param_4)

{
  uint uVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  
  lVar3 = func_0x(param_1,param_3,1);
  if (lVar3 != 0) {
    uVar1 = *(uint *)(param_2 + 1);
    if (0xffffffff < (ulonglong)uVar1 * 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(char *)(lVar3 + 0x84) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(int *)(param_2 + 1) = *(int *)(param_2 + 1) + (*(int *)(lVar3 + 0x68) - *(int *)(param_3 + 8))
    ;
    lVar4 = func_0x(param_1 + 0x1a0,*param_2,(ulonglong)uVar1 * 2 & 0xffffffff);
    *param_4 = lVar4;
    *param_2 = lVar4;
    if (*(int *)(param_2 + 1) - *(uint *)(param_4 + 1) < *(uint *)(lVar3 + 0x68)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar2 = (ulonglong)*(uint *)(lVar3 + 0x68) * 2;
    if (0xffffffff < uVar2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x
              (*param_4 + (ulonglong)*(uint *)(param_4 + 1) * 2,*(undefined8 *)(lVar3 + 0x60),
               uVar2 & 0xffffffff);
    *(int *)(param_4 + 1) = *(int *)(param_4 + 1) + *(int *)(lVar3 + 0x68);
  }
  return;
}

