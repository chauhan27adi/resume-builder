
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,longlong param_2,ulonglong param_3)

{
  longlong lVar1;
  
  if ((param_3 & 1) != 0) {
    if ((param_2 == 0) || (lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x360) + 0x18), lVar1 == 0)
       ) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(lVar1,*(undefined4 *)(param_2 + 8));
    lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x370) + 0x18);
    if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x
              (lVar1,*(undefined8 *)(*(longlong *)(param_1 + 0x370) + 0x10),
               *(undefined4 *)(param_2 + 8));
  }
  if ((param_3 & 2) == 0) {
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

