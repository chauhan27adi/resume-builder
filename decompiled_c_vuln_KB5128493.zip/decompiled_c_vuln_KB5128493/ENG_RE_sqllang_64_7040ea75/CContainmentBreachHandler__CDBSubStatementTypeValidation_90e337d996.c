
void FUN_(undefined4 param_1,int param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  bool bVar2;
  
  switch(param_1) {
  case 0xcd:
    if (param_2 != 0x18) {
      if (param_2 == 0x19) {
        func_0x(param_3,param_4,0xc,0);
        return;
      }
      if (param_2 == 0x1a) {
        func_0x(param_3,param_4,0xd,0);
        return;
      }
      if (param_2 != 0x1c) {
        if (param_2 != 0x1d) {
          return;
        }
        func_0x(param_3,param_4,0xe,0);
        return;
      }
    }
    func_0x(param_3,param_4,0xb,0);
    return;
  case 0xf5:
    if (param_2 == 1) {
      func_0x(param_3,param_4,0x46,0);
    }
    else {
      if (param_2 == 2) {
        func_0x(param_3,param_4,0x45,0);
        return;
      }
      if (param_2 == 4) {
        func_0x(param_3,param_4,0x47,0);
        return;
      }
    }
    break;
  case 0xfa:
    if (param_2 == 0) {
      func_0x(param_3,param_4,0xf,0);
      return;
    }
    if (param_2 == 0x80000) {
      func_0x(param_3,param_4,0x13,0);
      return;
    }
    if (param_2 == 0x2000000) {
      func_0x(param_3,param_4,0x12,0);
      return;
    }
    if (param_2 == 0x4000000) {
      func_0x(param_3,param_4,0x10,0);
      return;
    }
    if (param_2 == 0x8000000) {
      func_0x(param_3,param_4,0x11,0);
      return;
    }
    break;
  case 0x10f:
    if (param_2 == 2) {
      func_0x(param_3,param_4,0x40,0);
      return;
    }
    if (param_2 == 3) {
      func_0x(param_3,param_4,0x41,0);
      return;
    }
    break;
  case 0x13c:
    iVar1 = 0x32;
    bVar2 = param_2 == 2;
    goto code_r0x00100214;
  case 0x158:
    if (param_2 == 2) {
      func_0x(param_3,param_4,0x36,0);
      return;
    }
    if (param_2 == 4) {
      func_0x(param_3,param_4,0x37,0);
      return;
    }
    if (param_2 == 8) {
      func_0x(param_3,param_4,0x38,0);
      return;
    }
    break;
  case 0x175:
    bVar2 = param_2 == 5;
    iVar1 = 0x1e;
code_r0x00100214:
    if (!bVar2) {
      iVar1 = 0;
    }
    if (iVar1 != 0) {
      func_0x(param_3,param_4,iVar1,0);
      return;
    }
  }
  return;
}

