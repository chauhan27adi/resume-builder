
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  uint uVar5;
  ulonglong uVar7;
  ulonglong uVar6;
  
  lVar1 = *(longlong *)(*(longlong *)(param_2 + 0x20) + 8);
  uVar6 = 0;
  if ((*(byte *)(param_1 + 0x30) & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar7 = uVar6;
  if (0 < *(int *)(lVar1 + 0x18)) {
    do {
      if ((*(byte *)(*(longlong *)
                      (*(longlong *)(*(longlong *)(*(longlong *)(lVar1 + 0x20) + uVar7) + 0x10) +
                      0x40) + 0x88) & 2) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar5 = (int)uVar6 + 1;
      uVar6 = (ulonglong)uVar5;
      uVar7 = uVar7 + 8;
    } while ((int)uVar5 < *(int *)(lVar1 + 0x18));
  }
  *(undefined4 *)(lVar1 + 0x18) = 0;
  uVar2 = *(undefined8 *)(param_3 + 0x160);
  if ((*(byte *)(param_1 + 0x30) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar4 = (undefined8 *)(*_DAT_)(0x20,uVar2,0x218db78,0x1033,1);
  if (puVar4 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar3 = *(undefined8 *)(param_1 + 0x28);
  *puVar4 = 0x20c7010;
  *(undefined4 *)(puVar4 + 1) = 1;
  *puVar4 = 0x2042400;
  puVar4[2] = uVar2;
  *puVar4 = 0x2017f28;
  *puVar4 = 0x1fbf940;
  puVar4[3] = uVar3;
  *(undefined8 **)(param_2 + 0x10) = puVar4;
  return;
}

