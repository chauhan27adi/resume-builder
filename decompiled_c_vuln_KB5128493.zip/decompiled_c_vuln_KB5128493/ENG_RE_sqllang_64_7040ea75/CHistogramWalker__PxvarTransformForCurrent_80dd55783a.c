
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1)

{
  int *piVar1;
  
  if (*(char *)(param_1 + 0x28) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x10) == 0) {
    piVar1 = (int *)(*(longlong *)(*(longlong *)(*(longlong *)(param_1 + 8) + 0x20) + 0x28) + 0x20);
    *piVar1 = *piVar1 + 1;
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

