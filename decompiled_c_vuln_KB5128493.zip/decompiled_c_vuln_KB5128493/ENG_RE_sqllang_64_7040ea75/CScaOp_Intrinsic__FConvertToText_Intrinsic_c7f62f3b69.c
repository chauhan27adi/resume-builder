
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00a8e15c) */
/* WARNING: Removing unreachable block (ram,0x00196bb2) */
/* WARNING: Removing unreachable block (ram,0x00a8e0c6) */
/* WARNING: Removing unreachable block (ram,0x00115ecb) */
/* WARNING: Removing unreachable block (ram,0x00a8e197) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 *param_1,longlong param_2,longlong param_3,longlong **param_4)

{
  short sVar1;
  undefined8 uVar2;
  short *psVar3;
  longlong lVar4;
  longlong *plVar5;
  int *piVar6;
  longlong *plVar7;
  undefined auVar8 [16];
  bool bVar9;
  bool bVar10;
  short *psVar11;
  char cVar12;
  int iVar13;
  uint uVar14;
  int iVar15;
  undefined8 uVar16;
  longlong **pplVar17;
  ulonglong uVar18;
  short **ppsVar19;
  ulonglong uVar20;
  
  uVar2 = *param_1;
  uVar14 = *(uint *)(param_3 + 0x18);
  iVar13 = (**(code **)(**(longlong **)(param_3 + 0x10) + 0x18))();
  if (iVar13 == 0x58) {
    ppsVar19 = *(short ***)(*(longlong *)(param_3 + 0x10) + 0x40);
  }
  else {
    ppsVar19 = *(short ***)(*(longlong *)(param_3 + 0x10) + 0x50);
  }
  if ((*(uint *)(param_2 + 0x90) & 0x202) == 0) {
    bVar9 = false;
LAB_:
    bVar10 = false;
  }
  else {
    bVar9 = true;
    bVar10 = true;
    if ((*(uint *)(ppsVar19 + 2) >> 0x13 & 1) == 0) goto LAB_;
  }
  if ((*(uint *)(param_2 + 0x90) >> 5 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar13 = 0;
  if (*(int *)((longlong)ppsVar19 + 0xc) - 0x30U < 0xf) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)((longlong)ppsVar19 + 0xc) == 0x43) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar20 = CONCAT44(0,uVar14);
  auVar8._8_8_ = 0;
  auVar8._0_8_ = uVar20;
  uVar16 = SUB168(ZEXT816(8) * auVar8,0);
  if (SUB168(ZEXT816(8) * auVar8,8) != 0) {
    uVar16 = 0xffffffffffffffff;
  }
  pplVar17 = (longlong **)(*_DAT_)(uVar16,uVar2,0x20ee368,0x1c9b,3);
  func_0x(pplVar17,0);
  psVar3 = *ppsVar19;
  if (*(int *)((longlong)ppsVar19 + 0xc) != 0x1a7) {
    if (*(int *)((longlong)ppsVar19 + 0xc) == 0xa3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (!bVar9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(param_2 + 0x90) >> 9 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (uVar14 != 0) {
      iVar15 = *(int *)((longlong)ppsVar19 + 0xc);
      if (iVar15 == 0xdd) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (iVar15 - 0x96U < 0x32) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (iVar15 == 0x240) {
        return;
      }
      if (!bVar10) {
        lVar4 = **(longlong **)(param_3 + 0x20);
        uVar18 = func_0x();
        if (uVar18 < 0x34e20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        plVar5 = *(longlong **)(lVar4 + 0x10);
        cVar12 = (**(code **)(*plVar5 + 0x1b8))(plVar5,param_1,param_2,lVar4,pplVar17,0);
        if (cVar12 == '\0') {
          return;
        }
      }
      if (1 < uVar14) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    piVar6 = *(int **)(param_2 + 200);
    if (*piVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar5 = *(longlong **)(piVar6 + 4);
    *piVar6 = *piVar6 + -1;
    *(longlong **)(piVar6 + 4) = plVar5 + 3;
    *plVar5 = 0;
    plVar5[1] = 0;
    *(undefined4 *)(plVar5 + 2) = 0;
    *param_4 = plVar5;
    if ((*(uint *)(ppsVar19 + 2) >> 0x11 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    sVar1 = *psVar3;
    psVar11 = psVar3;
    while (sVar1 != 0) {
      psVar11 = psVar11 + 1;
      iVar13 = iVar13 + 1;
      sVar1 = *psVar11;
    }
    func_0x(*param_4,uVar2,psVar3,iVar13);
    if (*psVar3 == 0x40) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(*param_4,uVar2,0x2035bc4,1);
    if (*(int *)((longlong)ppsVar19 + 0xc) == 0x59) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)((longlong)ppsVar19 + 0xc) == 0x221) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    bVar9 = false;
    if (uVar14 != 0) {
      do {
        plVar5 = *pplVar17;
        if ((plVar5 != (longlong *)0x0) && (*(int *)(plVar5 + 2) != 0)) {
          if (bVar9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          plVar7 = *param_4;
          if (*plVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(longlong *)(plVar7[1] + 0x10) = *plVar5;
          plVar7[1] = plVar5[1];
          *(int *)(plVar7 + 2) = *(int *)(plVar7 + 2) + *(int *)(plVar5 + 2);
          bVar9 = true;
        }
        pplVar17 = pplVar17 + 1;
        uVar20 = uVar20 - 1;
      } while (uVar20 != 0);
    }
    func_0x(*param_4,uVar2,0x2035bc0,1);
    uVar14 = *(uint *)(ppsVar19 + 2) >> 0x11;
    if ((uVar14 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
LAB_:
    return CONCAT71((uint7)(uint3)(uVar14 >> 8),1);
  }
  lVar4 = **(longlong **)(param_3 + 0x20);
  uVar20 = func_0x();
  if (uVar20 < 0x34e20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  plVar5 = *(longlong **)(lVar4 + 0x10);
  cVar12 = (**(code **)(*plVar5 + 0x1b8))(plVar5,param_1,param_2,lVar4,pplVar17,0);
  if (cVar12 != '\0') {
    lVar4 = *(longlong *)(*(longlong *)(param_3 + 0x20) + 8);
    uVar20 = func_0x();
    if (uVar20 < 0x34e20) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar5 = *(longlong **)(lVar4 + 0x10);
    cVar12 = (**(code **)(*plVar5 + 0x1b8))(plVar5,param_1,param_2,lVar4,pplVar17 + 1,0);
    if (cVar12 != '\0') {
      if ((((2 < uVar14) &&
           (lVar4 = *(longlong *)(*(longlong *)(param_3 + 0x20) + 0x10), lVar4 != 0)) &&
          (iVar15 = (**(code **)(**(longlong **)(lVar4 + 0x10) + 0x18))(), iVar15 == 0x62)) &&
         ((*(char *)(*(longlong *)(*(longlong *)(*(longlong *)(param_3 + 0x20) + 0x10) + 0x10) +
                    0x40) + 1U & 0xfb) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(int *)(param_2 + 0x8c) - 3U < 5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      piVar6 = *(int **)(param_2 + 200);
      if (*piVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar5 = *(longlong **)(piVar6 + 4);
      *piVar6 = *piVar6 + -1;
      *(longlong **)(piVar6 + 4) = plVar5 + 3;
      *plVar5 = 0;
      plVar5[1] = 0;
      *(undefined4 *)(plVar5 + 2) = 0;
      *param_4 = plVar5;
      plVar7 = *pplVar17;
      if (*plVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *plVar5 = *plVar7;
      plVar5[1] = plVar7[1];
      *(int *)(plVar5 + 2) = *(int *)(plVar5 + 2) + *(int *)(plVar7 + 2);
      func_0x(*param_4,uVar2,0x2036138,1);
      sVar1 = *psVar3;
      psVar11 = psVar3;
      while (sVar1 != 0) {
        psVar11 = psVar11 + 1;
        iVar13 = iVar13 + 1;
        sVar1 = *psVar11;
      }
      func_0x(*param_4,uVar2,psVar3,iVar13);
      func_0x(*param_4,uVar2,0x2036138,1);
      plVar5 = *param_4;
      plVar7 = pplVar17[1];
      if (*plVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(longlong *)(plVar5[1] + 0x10) = *plVar7;
      plVar5[1] = plVar7[1];
      uVar14 = *(uint *)(plVar7 + 2);
      *(uint *)(plVar5 + 2) = *(int *)(plVar5 + 2) + uVar14;
      goto LAB_;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

