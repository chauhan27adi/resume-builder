
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2)

{
  longlong lVar1;
  code *pcVar2;
  longlong lVar3;
  longlong lVar4;
  longlong unaff_GS_OFFSET;
  undefined8 auStackX_8 [3];
  
  lVar4 = *(longlong *)(param_1 + 0x20);
  if (((DAT_ != '\0') || ((*(byte *)(_DAT_ + 0x5c4) & 8) != 0)) &&
     (*(longlong *)(param_1 + 0x18) != 0)) {
    func_0x(0x65e7,(int)*(short *)(*(longlong *)(param_1 + 0x18) + 0x10));
  }
  lVar1 = *(longlong *)(lVar4 + 0x30);
  if ((lVar1 == 0) || (*(longlong *)(lVar4 + 0x28) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar3 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  *(longlong *)(lVar3 + 8) = lVar1;
  *(longlong *)(*(longlong *)(*(longlong *)(lVar3 + 0x100) + 0x40) + 8) = lVar1;
  func_0x(*(undefined8 *)(lVar4 + 0x28));
  lVar1 = *(longlong *)
           (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            0x50 + (ulonglong)*_DAT_);
  (*_DAT_)(auStackX_8,0,0);
  *(undefined8 *)(lVar1 + 0xe8) = auStackX_8[0];
  if ((_DAT_ & 0x20000) != 0) {
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
  }
  if ((*_DAT_ != '\0') && ((*(uint *)(_DAT_ + 0x3c) & 0x10000) != 0)) {
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
  }
  func_0x(*(undefined8 *)(lVar4 + 0x28));
  lVar4 = (ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  *(undefined8 *)(lVar4 + 8) = 0;
  *(undefined8 *)(*(longlong *)(*(longlong *)(lVar4 + 0x100) + 0x40) + 8) = 0;
  if (*_DAT_ != '\0') {
    (*_DAT_)(_DAT_,0xf,0x40,1,0);
  }
  *(undefined8 *)(param_2 + 0x2a0) = 0;
  return;
}

