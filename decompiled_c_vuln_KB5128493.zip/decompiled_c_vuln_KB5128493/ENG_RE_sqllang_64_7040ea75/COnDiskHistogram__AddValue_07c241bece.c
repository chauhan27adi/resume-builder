
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,char *param_2,char param_3)

{
  undefined4 uVar1;
  longlong *plVar2;
  undefined auStack_108 [80];
  undefined8 uStack_b8;
  ulonglong uStack_38;
  
  uStack_b8 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_108;
  if (*(longlong *)(param_1 + 0x60) != 0) {
    plVar2 = (longlong *)(param_2 + 8);
    if (*(char *)((ulonglong)*(byte *)((ulonglong)(byte)param_2[1] + 0x1eb10c0) + 0x1ee6088) != '\0'
       ) {
      plVar2 = (longlong *)*plVar2;
    }
    uVar1 = (*_DAT_)(param_2,param_1 + 0x18);
    if (*param_2 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(param_1 + 0x6c) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(*(undefined8 *)(param_1 + 0x60),plVar2,uVar1,param_3);
  }
  if (*param_2 == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(char *)(param_1 + 0x120) != '\0') && (2 < *(int *)(param_1 + 0xf8))) {
    if (param_3 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(char *)(param_1 + 0xb0 + (ulonglong)*(ushort *)(param_1 + 0xf2) * 0x28) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar2 = (longlong *)
             (*(longlong *)(param_1 + 0xa0 + (ulonglong)*(ushort *)(param_1 + 0xf2) * 0x28) + 0x28);
    *plVar2 = *plVar2 + 1;
  }
  *(longlong *)(param_1 + 0x108) = *(longlong *)(param_1 + 0x108) + 1;
  func_0x(uStack_38 ^ (ulonglong)auStack_108);
  return;
}

