
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  uint *puVar1;
  longlong lVar2;
  int iVar3;
  longlong unaff_GS_OFFSET;
  
  switch(*(undefined4 *)(*(longlong *)(param_1 + 0x28) + 0x71c)) {
  case 6:
  case 7:
  case 8:
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x19:
  case 0x1a:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
  case 0x22:
    break;
  default:
    puVar1 = (uint *)(*(longlong *)
                       (*(longlong *)
                         (*(longlong *)
                           (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
                          8 + (ulonglong)*_DAT_) + 0x70) + 0x18);
    *puVar1 = *puVar1 | 1;
  }
  lVar2 = *(longlong *)(param_1 + 0xb8);
  if (lVar2 != 0) {
    if (*(int *)(lVar2 + 0x2c) != 0) {
      *(undefined4 *)(lVar2 + 0x2c) = 0;
      if ((*(longlong **)(lVar2 + 8) == (longlong *)0x0) ||
         (iVar3 = (**(code **)(**(longlong **)(lVar2 + 8) + 0x38))(), iVar3 != 0)) {
        func_0x(lVar2);
      }
      else {
        (**(code **)(**(longlong **)(lVar2 + 8) + 0x28))(*(longlong **)(lVar2 + 8),1,1);
      }
    }
    *(undefined8 *)(param_1 + 0xb8) = 0;
  }
  *(byte *)(param_1 + 0xb0) = *(byte *)(param_1 + 0xb0) & 0xef;
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

