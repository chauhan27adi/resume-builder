
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,uint param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  *param_1 = 0x1ecf610;
  puVar2 = (undefined8 *)param_1[6];
  if (*(int *)((longlong)puVar2 + 0x1c) == 0) {
    if (puVar2 != (undefined8 *)0x0) {
      puVar1 = puVar2 + 1;
      *(int *)puVar1 = *(int *)puVar1 + -1;
      if (*(int *)puVar1 == 0) {
        (**(code **)*puVar2)(puVar2,1,puVar2,param_4,0xfffffffffffffffe);
      }
    }
    *param_1 = 0x1de3500;
    if ((param_2 & 1) != 0) {
      (*_DAT_)(param_1,0x38);
    }
    return param_1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

