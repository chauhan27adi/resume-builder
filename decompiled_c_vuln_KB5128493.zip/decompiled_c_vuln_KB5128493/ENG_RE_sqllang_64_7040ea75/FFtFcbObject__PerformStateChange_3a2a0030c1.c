
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_(longlong param_1,int param_2,int param_3,char param_4,longlong param_5,
                undefined *param_6)

{
  undefined8 *puVar1;
  longlong *plVar2;
  int *piVar3;
  uint uVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined *puVar8;
  int iVar9;
  int iVar10;
  int *piVar11;
  longlong lVar12;
  int iVar13;
  longlong lVar14;
  ulonglong uVar15;
  longlong lVar16;
  int iVar17;
  longlong lVar18;
  longlong unaff_GS_OFFSET;
  bool bVar19;
  bool bVar20;
  bool bVar21;
  undefined8 uStackX_8;
  undefined8 uStack_d8;
  undefined8 uStack_d0;
  longlong lStack_c0;
  longlong lStack_b0;
  ulonglong uStack_a0;
  int *piStack_98;
  ulonglong uStack_90;
  uint uStack_88;
  longlong lStack_80;
  longlong lStack_78;
  undefined4 auStack_70 [2];
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  
  puVar8 = param_6;
  uStack_48 = 0xfffffffffffffffe;
  iVar13 = 0;
  lStack_c0 = 0;
  lStack_b0 = 0;
  bVar21 = false;
  bVar20 = false;
  lStack_78 = param_1 + 0xa8;
  auStack_70[0] = 0x4004af;
  uStack_68 = 0;
  uStack_58 = 0;
  uStack_60 = 0;
  uStack_50 = 0;
  uStack_88 = 0;
  lVar16 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar14 = *(longlong *)(lVar16 + 0x100);
  if (lVar14 == 0) {
    (*_DAT_)(0);
    lVar14 = *(longlong *)(lVar16 + 0x100);
  }
  lVar12 = lStack_78;
  uStack_88 = *(uint *)(lVar14 + 0x268) & 1 ^ 1;
  *(uint *)(lVar14 + 0x268) = *(uint *)(lVar14 + 0x268) | 1;
  lVar18 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar16 = *(longlong *)(lVar18 + 0x100);
  lStack_80 = lVar14;
  if (lVar16 == 0) {
    (*_DAT_)();
    lVar16 = *(longlong *)(lVar18 + 0x100);
  }
  if (lVar16 == *(longlong *)(lVar12 + 0x20)) {
    *(longlong *)(lVar12 + 0x38) = *(longlong *)(lVar12 + 0x38) + 1;
  }
  else {
    func_0x(lVar12,lVar16,0xffffffff,auStack_70);
  }
  piVar3 = (int *)(param_1 + 0xec);
  piStack_98 = (int *)(param_1 + 0xe8);
  piVar11 = piVar3;
  if (param_2 != 1) {
    piVar11 = piStack_98;
  }
  iVar9 = *piVar11;
  piVar11 = piStack_98;
  if (param_2 != 1) {
    piVar11 = piVar3;
  }
  iVar10 = *piVar11;
  iVar17 = iVar13;
  switch(param_3) {
  case 0:
    if ((iVar10 == 1) && (iVar9 == 1)) {
      LOCK();
      UNLOCK();
      bVar21 = *(longlong *)(param_1 + 0xf0) != 0;
    }
    else {
      LOCK();
      UNLOCK();
      plVar6 = *(longlong **)(*(longlong *)(param_1 + 0xf0) + 0x110);
      uVar7 = *(undefined8 *)(*(longlong *)(*(longlong *)(param_1 + 0x28) + 0x48) + 0x10);
      lVar16 = plVar6[3];
      uStack_d0._0_4_ = (int)lVar16;
      while ((-1 < (int)uStack_d0 && (uStack_d0._0_4_ = (int)lVar16, (int)uStack_d0 != 0))) {
        uStack_d0._0_4_ = (int)uStack_d0 + 1;
        uVar4 = *(uint *)(plVar6 + 0xf);
        uStack_d0 = CONCAT44(uVar4,(int)uStack_d0);
        if (uVar4 < *(uint *)((longlong)plVar6 + 0x7c)) {
          if (uVar4 == 0) {
            uStack_d0 = CONCAT44(1,(int)uStack_d0);
          }
          else {
            uStack_d0 = CONCAT44(uVar4 * 2,(int)uStack_d0);
          }
        }
        LOCK();
        bVar20 = lVar16 == plVar6[3];
        if (bVar20) {
          plVar6[3] = uStack_d0;
        }
        UNLOCK();
        if (bVar20) {
          uStack_d8._4_4_ = (uint)((ulonglong)lVar16 >> 0x20);
          if (uStack_d8._4_4_ < *(uint *)((longlong)plVar6 + 0x7c)) {
            *(undefined4 *)(plVar6 + 0xf) = uStack_d0._4_4_;
          }
          uVar15 = _DAT_;
          if (*_DAT_ != 0) {
            (*_DAT_)(&uStack_a0);
            uVar15 = uStack_a0;
          }
          if (uVar15 == 0xffffffffffffffff) {
            uVar15 = 0xffffffffffffffff;
          }
          else if (*_DAT_ == 0) {
            uVar15 = uVar15 / 10000;
          }
          else {
            uVar15 = (uVar15 * 1000) / *_DAT_;
          }
          plVar6[8] = uVar15;
          if ((*_DAT_ != 0) && (iVar13 = (**(code **)(*plVar6 + 8))(plVar6), iVar13 != 0)) {
            func_0x(plVar6);
          }
          (*_DAT_)(uVar7);
          iVar13 = (iVar10 != 1) + 2;
          goto code_r0x00100250;
        }
        lVar16 = plVar6[3];
        uStack_d0._0_4_ = (int)lVar16;
      }
      (*_DAT_)(uVar7);
      bVar21 = true;
    }
    iVar13 = 1;
code_r0x00100250:
    iVar17 = 4;
    if (iVar10 != 4) {
      iVar17 = 2;
    }
    break;
  case 1:
    param_4 = '\0';
  case 2:
    if (param_2 == 1) {
      lVar16 = *(longlong *)(param_1 + 0x98);
    }
    else {
      lVar16 = *(longlong *)(param_1 + 0xa0);
    }
    if (lVar16 == 0) {
      if ((param_4 == '\0') || (iVar10 == 4)) {
        iVar17 = 1;
        if (iVar9 == 1) {
          iVar13 = 5;
          bVar20 = param_3 == 1;
          bVar21 = !bVar20;
        }
        else {
          LOCK();
          UNLOCK();
          if (param_2 == 1) {
            lStack_c0 = *(longlong *)(*(longlong *)(param_1 + 0xf0) + 0x118);
            LOCK();
            UNLOCK();
            *(undefined8 *)(*(longlong *)(param_1 + 0xf0) + 0x118) = 0;
          }
          else {
            lStack_c0 = *(longlong *)(*(longlong *)(param_1 + 0xf0) + 0x120);
            LOCK();
            UNLOCK();
            *(undefined8 *)(*(longlong *)(param_1 + 0xf0) + 0x120) = 0;
          }
          iVar13 = 2;
        }
      }
      else {
        iVar17 = 3;
        iVar13 = 4;
      }
      if ((*(byte *)(param_1 + 0x110) & 1) != 0) {
        if (param_2 == 2) {
          if (0 < *(longlong *)(param_1 + 0x98)) {
            LOCK();
            UNLOCK();
            *(longlong *)(*(longlong *)(param_1 + 0xf0) + 0x120) = lStack_c0;
            lStack_c0 = 0;
            iVar13 = 3;
            iVar17 = iVar10;
          }
          bVar19 = iVar9 == 3;
        }
        else {
          if (param_2 != 1) goto code_r0x0010046e;
          bVar19 = *(longlong *)(param_1 + 0xa0) == 0;
        }
        if (bVar19) {
          if (lStack_c0 != 0) {
            LOCK();
            UNLOCK();
            if (param_2 == 1) {
              *(longlong *)(*(longlong *)(param_1 + 0xf0) + 0x118) = lStack_c0;
            }
            else {
              *(longlong *)(*(longlong *)(param_1 + 0xf0) + 0x120) = lStack_c0;
            }
            lStack_c0 = 0;
          }
          bVar21 = true;
          iVar17 = 1;
          *piStack_98 = 1;
          *piVar3 = 1;
          iVar13 = 5;
        }
      }
code_r0x0010046e:
      if (bVar20) break;
    }
    else {
      iVar13 = 3;
      iVar17 = iVar10;
    }
    LOCK();
    UNLOCK();
    puVar5 = *(undefined8 **)(*(longlong *)(param_1 + 0xf0) + 0x110);
    lVar16 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x28) + 0x48) + 0x10);
    (*_DAT_)(lVar16);
    iVar9 = *(int *)(lVar16 + 0x8b0);
    do {
      uVar15 = puVar5[3];
      uStack_d8._0_4_ = (uint)uVar15;
      iVar10 = (uint)uStack_d8 + -1;
      uStack_d8._4_4_ = (uint)(uVar15 >> 0x20);
      uStack_d8 = CONCAT44(uStack_d8._4_4_,iVar10);
      if (iVar10 == 1) {
        uStack_d8 = CONCAT44(*(undefined4 *)(puVar5 + 0xf),iVar9 << 0x1f) | 1;
      }
      LOCK();
      bVar20 = uVar15 == puVar5[3];
      if (bVar20) {
        puVar5[3] = uStack_d8;
      }
      UNLOCK();
    } while (!bVar20);
    if (((int)(uint)uStack_d8 < 0) && (((uint)uStack_d8 & 0x7fffffff) == 1)) {
      LOCK();
      puVar1 = puVar5 + 0xe;
      iVar9 = *(int *)puVar1;
      *(int *)puVar1 = *(int *)puVar1 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        if (puVar5[0xc] != 0) {
          func_0x(puVar5[0xd]);
        }
        (**(code **)*puVar5)(puVar5);
      }
    }
    break;
  case 3:
    if (((iVar10 - 2U & 0xfffffffd) == 0) || ((iVar9 - 2U & 0xfffffffd) == 0)) {
      iVar13 = 6;
      iVar17 = iVar10;
      goto LAB_;
    }
    if ((iVar10 == 1) && (iVar9 == 1)) {
      iVar13 = 7;
      LOCK();
      UNLOCK();
      bVar21 = *(longlong *)(param_1 + 0xf0) != 0;
      iVar17 = iVar10;
    }
    else {
      bVar21 = true;
      iVar17 = 1;
      *piStack_98 = 1;
      *piVar3 = 1;
      iVar13 = 5;
    }
    break;
  case 4:
    if (param_5 == *(longlong *)(param_1 + 0xf8)) {
      if ((iVar10 - 2U & 0xfffffffd) == 0) {
        iVar13 = 8;
        iVar17 = 4;
      }
      else if (iVar10 == 1) {
        iVar13 = 7;
        iVar17 = iVar10;
      }
      else {
        iVar17 = 1;
        if (iVar9 == 1) {
          bVar21 = true;
          iVar13 = 5;
          break;
        }
        LOCK();
        UNLOCK();
        if (param_2 == 1) {
          lStack_c0 = *(longlong *)(*(longlong *)(param_1 + 0xf0) + 0x118);
          LOCK();
          UNLOCK();
          *(undefined8 *)(*(longlong *)(param_1 + 0xf0) + 0x118) = 0;
          iVar13 = 2;
        }
        else {
          lStack_c0 = *(longlong *)(*(longlong *)(param_1 + 0xf0) + 0x120);
          LOCK();
          UNLOCK();
          *(undefined8 *)(*(longlong *)(param_1 + 0xf0) + 0x120) = 0;
          iVar13 = 2;
        }
      }
    }
    else {
      iVar13 = 7;
      iVar17 = iVar10;
    }
  default:
LAB_:
    bVar21 = false;
    break;
  case 5:
    if ((iVar10 == 1) && (iVar9 == 1)) {
      iVar13 = 7;
      iVar17 = iVar10;
    }
    else {
      *piStack_98 = 1;
      *piVar3 = 1;
      iVar13 = 5;
      iVar17 = 1;
    }
    goto LAB_;
  }
  piVar11 = piStack_98;
  if (param_2 != 1) {
    piVar11 = piVar3;
  }
  *piVar11 = iVar17;
  if (param_6 != (undefined *)0x0) {
    *param_6 = 0;
  }
  LOCK();
  UNLOCK();
  lVar16 = *(longlong *)(param_1 + 0xf0);
  if (bVar21) {
    plVar6 = *(longlong **)(lVar16 + 0x110);
    uVar7 = *(undefined8 *)(*(longlong *)(*(longlong *)(param_1 + 0x28) + 0x48) + 0x10);
    param_6 = (undefined *)plVar6[3];
    if (-1 < (int)param_6) {
LAB_:
      lVar12 = (longlong)param_6;
      if ((int)param_6 != 0) {
        param_6._0_4_ = (int)param_6 + 1;
        uVar4 = *(uint *)(plVar6 + 0xf);
        param_6 = (undefined *)CONCAT44(uVar4,(int)param_6);
        if (uVar4 < *(uint *)((longlong)plVar6 + 0x7c)) {
          if (uVar4 == 0) {
            param_6 = (undefined *)CONCAT44(1,(int)param_6);
          }
          else {
            param_6 = (undefined *)CONCAT44(uVar4 * 2,(int)param_6);
          }
        }
        LOCK();
        bVar21 = lVar12 == plVar6[3];
        if (bVar21) {
          plVar6[3] = (longlong)param_6;
        }
        UNLOCK();
        if (!bVar21) goto code_r0x0010074b;
        uStackX_8._4_4_ = (uint)((ulonglong)lVar12 >> 0x20);
        if (uStackX_8._4_4_ < *(uint *)((longlong)plVar6 + 0x7c)) {
          *(undefined4 *)(plVar6 + 0xf) = param_6._4_4_;
        }
        uVar15 = _DAT_;
        if (*_DAT_ != 0) {
          (*_DAT_)(&uStack_90);
          uVar15 = uStack_90;
        }
        if (uVar15 == 0xffffffffffffffff) {
          uVar15 = 0xffffffffffffffff;
        }
        else if (*_DAT_ == 0) {
          uVar15 = uVar15 / 10000;
        }
        else {
          uVar15 = (uVar15 * 1000) / *_DAT_;
        }
        plVar6[8] = uVar15;
        if ((*_DAT_ != 0) && (iVar9 = (**(code **)(*plVar6 + 8))(plVar6), iVar9 != 0)) {
          func_0x(plVar6);
        }
        (*_DAT_)(uVar7);
        (*_DAT_)(*(undefined8 *)(*(longlong *)(*(longlong *)(param_1 + 0x28) + 0x48) + 0x10)
                         ,plVar6);
        lVar12 = *(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x28) + 0x48) + 0x10);
        (*_DAT_)(lVar12);
        iVar9 = *(int *)(lVar12 + 0x8b0);
        do {
          uVar15 = plVar6[3];
          uStackX_8._0_4_ = (uint)uVar15;
          iVar10 = (uint)uStackX_8 + -1;
          uStackX_8._4_4_ = (uint)(uVar15 >> 0x20);
          uStackX_8 = CONCAT44(uStackX_8._4_4_,iVar10);
          if (iVar10 == 1) {
            uStackX_8 = CONCAT44(*(undefined4 *)(plVar6 + 0xf),iVar9 << 0x1f) | 1;
          }
          LOCK();
          bVar21 = uVar15 == plVar6[3];
          if (bVar21) {
            plVar6[3] = uStackX_8;
          }
          UNLOCK();
        } while (!bVar21);
        if (((int)(uint)uStackX_8 < 0) && (((uint)uStackX_8 & 0x7fffffff) == 1)) {
          LOCK();
          plVar2 = plVar6 + 0xe;
          iVar9 = *(int *)plVar2;
          *(int *)plVar2 = *(int *)plVar2 + -1;
          UNLOCK();
          if (iVar9 == 1) {
            if (plVar6[0xc] != 0) {
              func_0x(plVar6[0xd],plVar6);
            }
            (**(code **)*plVar6)(plVar6);
          }
        }
        goto LAB_;
      }
    }
LAB_:
    (*_DAT_)(uVar7);
    *(uint *)(plVar6 + 0x13) = *(uint *)(plVar6 + 0x13) & 0xfffffffe;
LAB_:
    do {
      lVar18 = plVar6[1];
      LOCK();
      lVar12 = plVar6[1];
      if (lVar18 == lVar12) {
        plVar6[1] = 0;
        lVar12 = lVar18;
      }
      UNLOCK();
    } while (lVar18 != lVar12);
    if (lVar18 != 0) {
      lStack_c0 = *(longlong *)(lVar16 + 0x118);
      *(undefined8 *)(lVar16 + 0x118) = 0;
      lStack_b0 = *(longlong *)(lVar16 + 0x120);
      *(undefined8 *)(lVar16 + 0x120) = 0;
      func_0x(lVar16);
    }
    LOCK();
    bVar21 = *(int *)(lVar16 + 0x128) == 0;
    if (bVar21) {
      *(int *)(lVar16 + 0x128) = 2;
    }
    UNLOCK();
    if (bVar21) {
      func_0x(param_1);
      goto LAB_;
    }
    if (puVar8 != (undefined *)0x0) {
      *puVar8 = 1;
    }
  }
  lVar16 = lStack_78;
  if (*(longlong *)
       ((ulonglong)*_DAT_ +
        *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 0x100
       ) == 0) {
    (*_DAT_)(0);
  }
  plVar6 = (longlong *)(lVar16 + 0x38);
  *plVar6 = *plVar6 + -1;
  if (*plVar6 == 0) {
    *(undefined8 *)(lVar16 + 0x28) = 0;
    *(undefined8 *)(lVar16 + 0x30) = 0;
    *(undefined8 *)(lVar16 + 0x20) = 0;
    func_0x(lVar16);
  }
LAB_:
  if (lStack_c0 != 0) {
    plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x28) + 0x50);
    (**(code **)(*plVar6 + 0x40))(plVar6,lStack_c0);
  }
  if (lStack_b0 != 0) {
    plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x28) + 0x50);
    (**(code **)(*plVar6 + 0x40))(plVar6,lStack_b0);
  }
  *(uint *)(lVar14 + 0x268) = *(uint *)(lVar14 + 0x268) & ~uStack_88;
  return iVar13;
code_r0x0010074b:
  param_6 = (undefined *)plVar6[3];
  if ((int)param_6 < 0) goto LAB_;
  goto LAB_;
}

