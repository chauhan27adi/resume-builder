
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined (*param_2) [16],undefined (**param_3) [16],
                 undefined4 param_4)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong *plVar3;
  code *pcVar4;
  uint uVar5;
  char cVar6;
  byte bVar7;
  int iVar8;
  longlong lVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined *puVar14;
  undefined *puVar15;
  byte *pbVar16;
  longlong *plVar17;
  undefined8 uStack_3b0;
  undefined auStack_3a8 [32];
  undefined8 uStack_388;
  ulonglong uStack_380;
  undefined4 uStack_378;
  uint uStack_370;
  undefined uStack_368;
  uint uStack_360;
  undefined uStack_358;
  undefined8 uStack_350;
  undefined8 uStack_348;
  undefined auStack_340 [4];
  undefined auStack_33c [12];
  undefined4 uStack_330;
  undefined4 uStack_32c;
  undefined4 uStack_328;
  undefined4 uStack_324;
  undefined (*apauStack_320 [2]) [16];
  uint uStack_310;
  undefined8 uStack_30c;
  undefined4 uStack_304;
  longlong *plStack_300;
  longlong *plStack_2f8;
  longlong *plStack_2f0;
  undefined (*apauStack_2e8 [2]) [16];
  undefined2 uStack_2d8;
  undefined4 uStack_2d4;
  undefined (*pauStack_2c8) [16];
  undefined8 uStack_2c0;
  undefined (**ppauStack_2b8) [16];
  undefined8 uStack_2b0;
  undefined8 uStack_2a8;
  undefined8 uStack_2a0;
  longlong *plStack_298;
  undefined8 uStack_290;
  undefined8 uStack_278;
  undefined4 uStack_270;
  undefined8 uStack_268;
  undefined4 *puStack_260;
  undefined auStack_258 [16];
  longlong *plStack_248;
  undefined auStack_208 [176];
  undefined auStack_158 [256];
  ulonglong uStack_58;
  
  puVar14 = auStack_3a8;
  uStack_2b0 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)&uStack_348;
  uStack_3b0 = 0x100055;
  uStack_348._0_4_ = param_4;
  func_0x(apauStack_2e8,0xe7,0x3c);
  if ((byte)apauStack_2e8[0] == 0x62) {
    uStack_2d8 = 2;
  }
  if ((*(char *)((ulonglong)*(byte *)((ulonglong)(byte)apauStack_2e8[0] + 0xd7f760) + 0xdbc230) !=
       '\0') || (((byte)apauStack_2e8[0] - 0x23 & 0xbf) == 0)) {
    uStack_3b0 = 0x100093;
    cVar6 = func_0x(apauStack_2e8);
    if (cVar6 != '\0') {
      uStack_2d4 = 0xffffffff;
    }
  }
  bVar7 = *(byte *)param_3;
  uVar11 = (ulonglong)bVar7;
  plVar17 = (longlong *)0x0;
  if ((((bVar7 == 0x28) || (bVar7 == 0x29)) || (bVar7 == 0x2a)) || (bVar7 == 0x2b)) {
    apauStack_320[0] = *param_3;
    apauStack_320[1] = param_3[1];
    uStack_310 = *(uint *)(param_3 + 2);
    uStack_30c = *(undefined8 *)((longlong)param_3 + 0x14);
    uStack_304 = *(undefined4 *)((longlong)param_3 + 0x1c);
    uStack_330 = *(undefined4 *)param_2[1];
    uStack_32c = *(undefined4 *)(param_2[1] + 4);
    uStack_328 = *(undefined4 *)(param_2[1] + 8);
    uStack_324 = *(undefined4 *)(param_2[1] + 0xc);
    auStack_33c = SUB1612(*param_2,4);
    auStack_340 = (undefined  [4])(SUB164(*param_2,0) & 0xfffeffff);
    uVar5 = (uint)auStack_340;
    auStack_340[0] = (undefined)uVar5;
    auStack_340[1] = bVar7;
    if (*(char *)((ulonglong)*(byte *)(uVar11 + 0xd7f760) + 0xdb4030) != '\0') {
      uStack_3b0 = 0x1001ce;
      (*_DAT_)(apauStack_320,auStack_340);
    }
    uStack_360 = uStack_310 >> 0x18;
    if (*(char *)((ulonglong)*(byte *)(((ulonglong)apauStack_320[0] & 0xff) + 0xd7f760) + 0xdb4030)
        == '\0') {
      uStack_360 = 0;
    }
    uStack_358 = 0;
    uStack_368 = 0;
    uStack_370 = 0x7e;
    uStack_378 = 0;
    uStack_380 = uStack_380 & 0xffffffffffff0000;
    uStack_388 = uStack_388 & 0xffffffff00000000;
    uStack_3b0 = 0x10022d;
    iVar8 = (*_DAT_)(auStack_340,bVar7,auStack_158,0x100);
    if (iVar8 != 0) {
      uStack_3b0 = 0x100239;
      uVar11 = (*_DAT_)(0xe7);
      uStack_3b0 = 0x100246;
      uStack_388 = (*_DAT_)(bVar7);
      uStack_3b0 = 0x100266;
      uStack_380 = uVar11;
      (*_DAT_)(0x51,0xe,0x10,0x47);
      param_4 = (uint)uStack_348;
    }
    uVar11 = 0xe7;
    param_3 = apauStack_2e8;
LAB_:
    param_2 = (undefined (*) [16])auStack_340;
  }
  else if (bVar7 == 0xbd) {
    uStack_330 = *(undefined4 *)param_2[1];
    uStack_32c = *(undefined4 *)(param_2[1] + 4);
    uStack_328 = *(undefined4 *)(param_2[1] + 8);
    uStack_324 = *(undefined4 *)(param_2[1] + 0xc);
    uStack_350 = 0;
    uStack_358 = 0;
    uStack_360 = uStack_360 & 0xffffff00;
    uStack_368 = 0;
    auStack_33c = SUB1612(*param_2,4);
    auStack_340 = (undefined  [4])(SUB164(*param_2,0) & 0xfffeffff);
    uStack_370 = uStack_370 & 0xffffff00;
    uStack_378 = 0;
    uStack_380 = 0;
    if (*(char *)(param_1 + 0x21) == '\0') {
      uStack_388 = (ulonglong)uStack_388._4_4_ << 0x20;
      uStack_3b0 = 0x10016a;
      (*_DAT_)(auStack_340,param_3,0x185de50,0);
      uVar11 = 0x7f;
    }
    else {
      uStack_388 = CONCAT44(uStack_388._4_4_,0x100);
      uStack_3b0 = 0x10014d;
      (*_DAT_)(auStack_340,param_3,0x19b4ef0,auStack_158);
      uVar11 = 0xa5;
    }
    goto LAB_;
  }
  pbVar16 = (byte *)(uVar11 + 0xd7f760);
  bVar7 = *pbVar16;
  if ((*(short *)(param_3 + 2) != -1) &&
     (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)param_3 + 0xd7f760) + 0x18436e8) == '\0'))
  {
    if (bVar7 == 0x1b) {
      bVar7 = 0xf;
    }
    goto LAB_;
  }
  if (bVar7 == 0xf) {
LAB_:
    bVar7 = 0x17;
  }
  else {
    if (bVar7 == 0x10) {
      bVar7 = 0x16;
      goto LAB_;
    }
    if (bVar7 != 0x11) {
      if (bVar7 == 0x1b) goto LAB_;
      if (bVar7 != 0x1d) goto LAB_;
    }
    bVar7 = 0x18;
  }
LAB_:
  uStack_348._0_4_ = CONCAT31(uStack_348._1_3_,(byte)param_4 & 0xe0 | bVar7);
  uStack_3b0 = 0x100305;
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
            (*(longlong **)(param_1 + 0x10),&uStack_348,1);
  plVar12 = (longlong *)0x0;
  plStack_300 = (longlong *)0x0;
  plVar13 = plVar17;
  if ((*(short *)(param_3 + 2) == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)param_3 + 0xd7f760) + 0x18436e8) != '\0'))
  {
    if (*(byte *)param_3 == 0xf1) {
      uVar10 = *(undefined8 *)(param_1 + 0x50);
      uStack_3b0 = 0x100556;
      lVar9 = func_0x();
      lVar9 = -lVar9;
      puVar14 = auStack_3a8 + lVar9;
      plVar13 = (longlong *)((longlong)&uStack_348 + lVar9);
      *(undefined8 *)(auStack_3a8 + lVar9 + -8) = 0x10056c;
      (*_DAT_)(plVar13,0,uVar10);
      uStack_2c0 = 0;
      uStack_2a0 = 0;
      uStack_290 = 0;
      uStack_278 = 0x18824b0;
      uStack_270 = 0;
      uStack_268 = 0;
      apauStack_320[0] = (undefined (*) [16])0x0;
      apauStack_320[1] = (undefined (*) [16])0x0;
      uStack_30c = 0;
      uStack_310 = (uint)*(byte *)(param_1 + 0x20);
      lVar2 = *(longlong *)(param_1 + 0x48);
      plStack_300 = plVar13;
      pauStack_2c8 = param_2;
      ppauStack_2b8 = param_3;
      uStack_2a8 = uVar10;
      plStack_298 = plVar13;
      puStack_260 = (undefined4 *)&uStack_348;
      if (lVar2 == 0) {
        *(undefined8 *)(auStack_3a8 + lVar9 + -8) = 0x10060c;
        uVar10 = func_0x(auStack_208,0);
        *(undefined8 *)(auStack_3a8 + lVar9 + -8) = 0x100627;
        func_0x(uVar10,&pauStack_2c8,&uStack_2a8,apauStack_320);
        *(undefined8 *)(auStack_3a8 + lVar9 + -8) = 0x100634;
        func_0x(auStack_208);
      }
      else {
        *(undefined8 *)(auStack_3a8 + lVar9 + -8) = 0x1005fc;
        func_0x(lVar2,&pauStack_2c8,&uStack_2a8,apauStack_320);
      }
      pcVar4 = *(code **)(*plVar13 + 0x58);
      *(undefined8 *)(auStack_3a8 + lVar9 + -8) = 0x10063d;
      (*pcVar4)(plVar13);
      pcVar4 = *(code **)(*plVar13 + 0x18);
      *(undefined8 *)(auStack_3a8 + lVar9 + -8) = 0x100646;
      (*pcVar4)(plVar13);
      param_2 = *(undefined (**) [16])((longlong)apauStack_320 + lVar9);
      param_3 = (undefined (**) [16])0x18a0cd0;
    }
    plStack_2f8 = (longlong *)0x0;
    plVar12 = *(longlong **)(*param_2 + 8);
    pcVar4 = *(code **)(*plVar12 + 8);
    *(undefined8 *)(puVar14 + -8) = 0x100664;
    plVar12 = (longlong *)(*pcVar4)(plVar12,0x10);
    plStack_2f8 = plVar12;
    if ((*pbVar16 == 0x10) || (*pbVar16 == 0x16)) {
      uVar1 = *(undefined4 *)((longlong)param_3 + 0x14);
      *(undefined8 *)(puVar14 + -8) = 0x100683;
      uStack_348._0_4_ = (*_DAT_)(uVar1);
      plVar3 = *(longlong **)(param_1 + 0x10);
      pcVar4 = *(code **)(*plVar3 + 0x40);
      *(undefined8 *)(puVar14 + -8) = 0x10069a;
      (*pcVar4)(plVar3,&uStack_348,4);
    }
    pcVar4 = *(code **)(*plVar12 + 0x48);
    *(undefined8 *)(puVar14 + -8) = 0x1006ad;
    iVar8 = (*pcVar4)(plVar12,auStack_258,0);
    plStack_2f0 = plVar17;
    if (iVar8 == 0) {
      plStack_2f0 = plStack_248;
    }
    plVar17 = *(longlong **)(param_1 + 0x10);
    pcVar4 = *(code **)(*plVar17 + 0x40);
    *(undefined8 *)(puVar14 + -8) = 0x1006cf;
    (*pcVar4)(plVar17,&plStack_2f0,4);
    uVar10 = *(undefined8 *)(param_1 + 0x10);
    *(undefined8 *)(puVar14 + -8) = 0x1006dc;
    (*_DAT_)(uVar10,plVar12);
    pcVar4 = *(code **)(*plVar12 + 0x10);
    *(undefined8 *)(puVar14 + -8) = 0x1006e6;
    (*pcVar4)(plVar12);
    puVar15 = puVar14;
  }
  else {
    puVar15 = auStack_3a8;
    switch(*pbVar16) {
    case 1:
    case 2:
    case 3:
    case 4:
    case 7:
    case 0x14:
      uStack_3b0 = 0x10036a;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),*param_2 + 8,*(short *)(param_3 + 2));
      plVar13 = plVar12;
      puVar15 = auStack_3a8;
      break;
    case 5:
    case 0x12:
      uStack_348._4_4_ = *(undefined4 *)(*param_2 + 8);
      uStack_348._0_4_ = *(uint *)(*param_2 + 0xc);
      uStack_3b0 = 0x10038f;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,8);
      plVar13 = plVar12;
      puVar15 = auStack_3a8;
      break;
    case 6:
      uStack_348._0_4_ = CONCAT31(uStack_348._1_3_,(*param_2)[8]);
      uStack_3b0 = 0x100438;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,1);
      plVar13 = plVar12;
      puVar15 = auStack_3a8;
      break;
    case 8:
      uStack_3b0 = 0x100451;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),*param_2 + 8,8);
      plVar13 = plVar12;
      puVar15 = auStack_3a8;
      break;
    case 9:
      uStack_348._0_4_ = CONCAT31(uStack_348._1_3_,0x10);
      uStack_3b0 = 0x10046e;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,1);
      uStack_3b0 = 0x100482;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),*param_2 + 8,0x10);
      plVar13 = plVar12;
      puVar15 = auStack_3a8;
      break;
    case 10:
    case 0xb:
      uStack_348._0_1_ = (*param_2)[9];
      uStack_3b0 = 0x1003d1;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,1);
      uStack_348._0_1_ = (*param_2)[10];
      uStack_3b0 = 0x1003ec;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,1);
      uStack_348._0_4_ = CONCAT31(uStack_348._1_3_,0x11);
      uStack_3b0 = 0x100404;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,1);
      uStack_3b0 = 0x100418;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),*param_2 + 0xb,0x11);
      plVar13 = plVar12;
      puVar15 = auStack_3a8;
      break;
    case 0xd:
    case 0x10:
      uStack_3b0 = 0x100492;
      uStack_348._0_4_ = (*_DAT_)(*(undefined4 *)((longlong)param_3 + 0x14));
      uStack_3b0 = 0x1004a9;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,4);
    case 0xc:
    case 0xe:
    case 0xf:
    case 0x11:
      uStack_348._0_4_ = CONCAT22(uStack_348._2_2_,*(undefined2 *)param_2[1]);
      uStack_3b0 = 0x1004c5;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,2);
      uStack_3b0 = 0x1004d7;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),*(undefined8 *)(*param_2 + 8),
                 *(undefined4 *)param_2[1]);
      plVar13 = plVar12;
      puVar15 = auStack_3a8;
      break;
    case 0x13:
      uStack_348._0_4_ = *(uint *)(*param_2 + 8) << 0x10 | *(uint *)(*param_2 + 8) >> 0x10;
      uStack_3b0 = 0x1003b1;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,4);
      plVar13 = plVar12;
      puVar15 = auStack_3a8;
      break;
    case 0x15:
      break;
    default:
      uStack_388 = 0xeb4bb0;
      uStack_3b0 = 0x100538;
      (*_DAT_)(1,0x1272970,0x1271120,0xa20);
      puVar15 = auStack_3a8;
      break;
    case 0x1b:
      uStack_348._0_4_ = *(uint *)param_2[1];
      uStack_3b0 = 0x1004f6;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),&uStack_348,4);
      uStack_3b0 = 0x100508;
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))
                (*(longlong **)(param_1 + 0x10),*(undefined8 *)(*param_2 + 8),(uint)uStack_348);
      plVar13 = plVar12;
      puVar15 = auStack_3a8;
    }
  }
  if (plVar13 != (longlong *)0x0) {
    pcVar4 = *(code **)(*plVar13 + 0x10);
    *(undefined8 *)(puVar15 + -8) = 0x1006f7;
    (*pcVar4)(plVar13,0);
  }
  uVar11 = uStack_58 ^ (ulonglong)&uStack_348;
  *(undefined8 *)(puVar15 + -8) = 0x100706;
  func_0x(uVar11);
  return;
}

