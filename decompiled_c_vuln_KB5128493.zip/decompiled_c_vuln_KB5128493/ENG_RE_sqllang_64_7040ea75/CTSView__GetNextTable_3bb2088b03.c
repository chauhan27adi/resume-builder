
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1)

{
  if (*(int *)(param_1 + 0x50) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x50) == 2) {
    if (*(int *)(param_1 + 0x58) !=
        *(int *)(*(longlong *)(param_1 + 0x38) + (longlong)*(int *)(param_1 + 0x54) * 4)) {
      (**(code **)(**(longlong **)
                     (*(longlong *)(param_1 + 0x30) + (longlong)*(int *)(param_1 + 0x54) * 8) + 0x18
                  ))();
      *(int *)(param_1 + 0x58) = *(int *)(param_1 + 0x58) + 1;
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

