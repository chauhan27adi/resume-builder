
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong param_3,longlong param_4)

{
  ushort uVar1;
  char *pcVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  char cVar5;
  uint uVar6;
  int iVar7;
  longlong lVar8;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  undefined uVar15;
  undefined8 uVar16;
  undefined8 *puVar17;
  undefined8 *puVar18;
  undefined4 uVar19;
  longlong unaff_GS_OFFSET;
  bool bVar20;
  undefined auStack_bd8 [32];
  undefined8 uStack_bb8;
  undefined8 uStack_bb0;
  undefined8 uStack_ba8;
  undefined8 *puStack_ba0;
  undefined8 uStack_b98;
  undefined8 uStack_b90;
  undefined8 uStack_b88;
  ulonglong uStack_b80;
  undefined8 uStack_b78;
  undefined4 uStack_b70;
  undefined4 auStack_b68 [2];
  undefined4 uStack_b60;
  uint uStack_b5c;
  undefined2 uStack_b58;
  undefined uStack_b56;
  undefined4 uStack_b54;
  undefined8 uStack_b50;
  undefined8 uStack_b48;
  undefined8 uStack_b40;
  undefined4 uStack_b38;
  undefined auStack_b30 [16];
  longlong lStack_b20;
  longlong lStack_b18;
  undefined8 *puStack_b08;
  undefined4 uStack_b00;
  undefined4 uStack_afc;
  longlong lStack_af8;
  longlong lStack_af0;
  longlong lStack_ae8;
  longlong lStack_ae0;
  undefined8 *puStack_ad8;
  undefined4 uStack_ad0;
  undefined4 uStack_acc;
  undefined8 *puStack_ac8;
  undefined8 uStack_ac0;
  undefined8 uStack_ab8;
  undefined8 uStack_ab0;
  char cStack_aa0;
  longlong lStack_a98;
  undefined8 uStack_a90;
  undefined4 uStack_a88;
  undefined8 uStack_a80;
  undefined auStack_a78 [16];
  undefined4 uStack_a68;
  undefined8 uStack_a60;
  undefined auStack_a58 [16];
  undefined4 uStack_a44;
  uint uStack_a40;
  undefined8 uStack_a38;
  undefined8 *puStack_a28;
  undefined4 uStack_a20;
  undefined8 uStack_a18;
  longlong *plStack_a10;
  undefined8 *puStack_a08;
  undefined auStack_a00 [48];
  undefined auStack_9d0 [16];
  longlong lStack_9c0;
  longlong lStack_9b8;
  undefined auStack_9b0 [16];
  undefined auStack_998 [141];
  undefined uStack_90b;
  byte bStack_902;
  undefined8 uStack_8a8;
  undefined uStack_894;
  undefined8 uStack_878;
  undefined8 *puStack_870;
  undefined8 uStack_868;
  undefined8 uStack_860;
  undefined8 uStack_858;
  undefined auStack_848 [2048];
  ulonglong uStack_48;
  ulonglong uVar9;
  
  auStack_9d0._8_8_ = auStack_9d0._0_8_;
  uStack_a18 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_bd8;
  lStack_b20 = param_1;
  cVar5 = func_0x(0x1dce4b0,1);
  if (cVar5 == '\0') {
LAB_:
    *(undefined4 *)(param_4 + 8) = 0xb737;
    (*_DAT_)(0x1d5,3,0x10,3);
  }
  else {
    cVar5 = (*_DAT_)();
    if (cVar5 == '\0') {
      lVar8 = _DAT_ + 0x3a10;
    }
    else {
      lVar8 = _DAT_ + 0x6f68;
    }
    if (*(char *)(lVar8 + 0x354d) == '\0') goto LAB_;
  }
  uStack_878 = 0x170e258;
  puStack_870 = (undefined8 *)0x170e278;
  uStack_868 = 0x170e2a0;
  uStack_860 = 0x170e2c0;
  uStack_858 = 0x170e2e8;
  if (param_3 == 0) {
    uVar9 = 0;
code_r0x00100138:
    *(undefined4 *)(param_4 + 8) = 0xc9;
    puStack_ba0 = (undefined8 *)(&uStack_878)[uVar9];
    lVar8 = -1;
    do {
      lVar8 = lVar8 + 1;
    } while (*(short *)((longlong)puStack_ba0 + lVar8 * 2) != 0);
    uStack_ba8 = CONCAT44(uStack_ba8._4_4_,(int)lVar8 * 2);
    uStack_bb0 = _DAT_;
    uStack_bb8 = (longlong *)CONCAT44(uStack_bb8._4_4_,(uint)_DAT_);
    (*_DAT_)(2,1,0x10,0x21);
  }
  else {
    uVar6 = *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28);
    uVar9 = (ulonglong)uVar6;
    if (uVar6 < 5) goto code_r0x00100138;
    if (5 < uVar6) {
      *(undefined4 *)(param_4 + 8) = 0x1fd0;
      uStack_bb0 = _DAT_;
      uStack_bb8 = (longlong *)CONCAT44(uStack_bb8._4_4_,(uint)_DAT_);
      (*_DAT_)(0x51,0x2c,0x10,0xd);
    }
  }
  iVar7 = *(int *)(param_3 + 0x28);
  lVar10 = *(longlong *)(param_3 + 0x10);
  lVar8 = *(longlong *)(lVar10 + (longlong)iVar7 * 8);
  uStack_b48 = *(char **)(lVar8 + 8);
  if ((*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(lVar8 + 0x18) + 0x12efd40) + 0x13e90b0)
       == '\0') || (*uStack_b48 == '\x03')) {
    *(undefined4 *)(param_4 + 8) = 0xb73f;
    uStack_bb0 = 0x170d548;
    uStack_bb8 = (longlong *)0x170e258;
    (*_DAT_)(0x1d5,0xb,0x10,10);
    iVar7 = *(int *)(param_3 + 0x28);
    lVar10 = *(longlong *)(param_3 + 0x10);
  }
  lStack_af8 = *(longlong *)(lVar10 + 8 + (longlong)iVar7 * 8);
  if (*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(lStack_af8 + 0x18) + 0x12efd40) +
               0x13e90b0) == '\0') {
    *(undefined4 *)(param_4 + 8) = 0xb73f;
    uStack_bb0 = 0x1407138;
    uStack_bb8 = (longlong *)0x170e278;
    (*_DAT_)(0x1d5,0xb,0x10,0xb);
    iVar7 = *(int *)(param_3 + 0x28);
    lVar10 = *(longlong *)(param_3 + 0x10);
  }
  lStack_af0 = *(longlong *)(lVar10 + 0x10 + (longlong)iVar7 * 8);
  if (*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(lStack_af0 + 0x18) + 0x12efd40) +
               0x13e90b0) == '\0') {
    *(undefined4 *)(param_4 + 8) = 0xb73f;
    uStack_bb0 = 0x1407138;
    uStack_bb8 = (longlong *)0x170e2a0;
    (*_DAT_)(0x1d5,0xb,0x10,0xc);
    iVar7 = *(int *)(param_3 + 0x28);
    lVar10 = *(longlong *)(param_3 + 0x10);
  }
  lStack_ae8 = *(longlong *)(lVar10 + 0x18 + (longlong)iVar7 * 8);
  pcVar2 = *(char **)(lStack_ae8 + 8);
  if (*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(lStack_ae8 + 0x18) + 0x12efd40) +
               0x13ed428) == '\0') {
    *(undefined4 *)(param_4 + 8) = 0xb73f;
    uStack_bb0 = 0x13ef4c0;
    uStack_bb8 = (longlong *)0x170e2c0;
    uVar16 = 0xb;
    uVar19 = 0xd;
  }
  else {
    if ((*pcVar2 == '\x03') || (0 < *(int *)(pcVar2 + 8))) goto LAB_;
    *(undefined4 *)(param_4 + 8) = 0xb751;
    uStack_bb0 = 0x170e2c0;
    uStack_bb8 = (longlong *)CONCAT44(uStack_bb8._4_4_,*(undefined4 *)(pcVar2 + 8));
    uVar16 = 0x1d;
    uVar19 = 0xe;
  }
  (*_DAT_)(0x1d5,uVar16,0x10,uVar19);
LAB_:
  lStack_ae0 = *(longlong *)
                (*(longlong *)(param_3 + 0x10) + 0x20 + (longlong)*(int *)(param_3 + 0x28) * 8);
  if (*(char *)((ulonglong)*(byte *)((ulonglong)**(byte **)(lStack_ae0 + 0x18) + 0x12efd40) +
               0x13e90b0) == '\0') {
    *(undefined4 *)(param_4 + 8) = 0xb73f;
    uStack_bb0 = 0x170d548;
    uStack_bb8 = (longlong *)0x170e2e8;
    (*_DAT_)(0x1d5,0xb,0x10,0xf);
  }
  func_0x(auStack_848,0,0x800);
  auStack_9b0 = ZEXT816(0);
  func_0x(auStack_848,0x400,0,auStack_9b0);
  func_0x(&lStack_9c0,auStack_9b0);
  lVar8 = lStack_b20;
  plVar3 = *(longlong **)(lStack_b20 + 0x90);
  if (plVar3 == (longlong *)0x0) {
    lVar10 = 0;
  }
  else {
    lVar10 = (**(code **)(*plVar3 + 0x1b0))(plVar3);
  }
  uVar1 = _DAT_;
  uVar9 = _DAT_;
  uStack_b40 = 0;
  uStack_b38 = 1;
  auStack_b30 = ZEXT816(0);
  if (lVar10 == 0) {
    uStack_b38 = 1;
    auStack_b30._0_8_ =
         *(longlong **)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
          0x90);
    auStack_b30._8_8_ = 0;
    cVar5 = (**(code **)(*(longlong *)auStack_b30._0_8_ + 0x1d0))();
    if (cVar5 == '\0') {
      uStack_b98 = uStack_b98 & 0xffffffff00000000;
      puStack_ba0 = (undefined8 *)0x0;
      uStack_ba8 = uStack_ba8 & 0xffffffffffffff00;
      uStack_bb0 = CONCAT44(uStack_bb0._4_4_,2);
      uStack_bb8 = (longlong *)CONCAT44(uStack_bb8._4_4_,1);
      (**(code **)(*(longlong *)auStack_b30._0_8_ + 8))(auStack_b30._0_8_,uVar9,uVar1,1);
      uStack_b40 = CONCAT44(uStack_b40._4_4_,2);
    }
    else {
      (**(code **)(*(longlong *)auStack_b30._0_8_ + 0xe8))
                (auStack_b30._0_8_,1,1,(longlong)&uStack_b40 + 4);
      uStack_b38 = 1;
      uStack_b40 = CONCAT44(uStack_b40._4_4_,4);
    }
    lVar10 = (**(code **)(*(longlong *)auStack_b30._0_8_ + 0x1b0))();
  }
  uVar1 = *(ushort *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x50) + 8);
  puVar4 = *(undefined8 **)(*(longlong *)(lVar8 + 0x48) + 0x58);
  auStack_9d0._0_8_ = puVar4;
  plVar11 = (longlong *)(**_DAT_)(puVar4,lVar10,0x170cd38,0x292d);
  puVar13 = *(undefined8 **)(uStack_b48 + 8);
  auStack_b68[0] = *(undefined4 *)(uStack_b48 + 0x10);
  puStack_b08 = puVar13;
  puStack_a28 = puVar13;
  uStack_a20 = auStack_b68[0];
  plStack_a10 = plVar11;
  plVar12 = (longlong *)(**(code **)(*plVar11 + 0x100))(plVar11,&puStack_a28,uVar1,0);
  if (plVar12 == (longlong *)0x0) {
    *(undefined4 *)(param_4 + 8) = 0x3b2f;
    uStack_ba8 = CONCAT44(uStack_ba8._4_4_,auStack_b68[0]);
    uStack_bb0 = CONCAT44(uStack_bb0._4_4_,0x8aaa);
    uStack_bb8 = (longlong *)CONCAT44(uStack_bb8._4_4_,0x333e);
    puStack_ba0 = puVar13;
    (*_DAT_)(0x97,0x33,0x10,0xf);
  }
  cVar5 = (**(code **)(*plVar12 + 0x60))(plVar12);
  if ((((cVar5 == '\0') || (cVar5 = (**(code **)(*plVar12 + 0xa0))(plVar12), cVar5 != '\0')) ||
      (cVar5 = (**(code **)(*plVar12 + 0xa8))(plVar12), cVar5 != '\0')) ||
     (cVar5 = (**(code **)(*plVar12 + 0xb0))(), cVar5 != '\0')) {
    *(undefined4 *)(param_4 + 8) = 0xb750;
    (*_DAT_)(0x1d5,0x1c,0x10,1);
  }
  uStack_bb0 = uStack_bb0 & 0xffffffff00000000;
  uStack_bb8 = (longlong *)((ulonglong)uStack_bb8 & 0xffffffff00000000);
  uVar16 = (**(code **)(*plVar11 + 0x38))(plVar11,uVar1,0,0);
  uStack_b48 = (char *)CONCAT44(uStack_b48._4_4_,0x294b);
  uStack_bb8 = (longlong *)CONCAT71(uStack_bb8._1_7_,3);
  lStack_b18 = (*_DAT_)(0x30,puVar4,0x170cd38,0x294b);
  if (lStack_b18 == 0) {
    puVar13 = (undefined8 *)0x0;
  }
  else {
    uStack_b98 = CONCAT44(uStack_b98._4_4_,4);
    uStack_ba8 = 0;
    uStack_bb0 = 0;
    uStack_bb8 = (longlong *)0x0;
    puStack_ba0 = puVar4;
    puVar13 = (undefined8 *)func_0x(lStack_b18,uVar16,plVar11,plVar12);
  }
  puStack_a08 = puVar13;
  (**(code **)(*(longlong *)puVar13[1] + 0x10))();
  func_0x(puVar13[1]);
  lStack_b18 = *(longlong *)(puVar13[1] + 0x440);
  uVar15 = 0;
  uStack_bb8 = plVar3;
  func_0x(auStack_998,0,puStack_b08,auStack_b68[0]);
  uStack_bb8 = (longlong *)CONCAT71(uStack_bb8._1_7_,uVar15);
  func_0x(auStack_998,puVar4,0x1768350,auStack_848);
  bStack_902 = bStack_902 | 2;
  uStack_90b = 1;
  uStack_b60 = 0xffffffff;
  uVar6 = (uint)uVar1;
  uStack_b58 = 0;
  uStack_b56 = 0;
  puVar14 = (undefined8 *)0x0;
  uStack_b54 = 0;
  uStack_b50 = 0;
  uStack_b80 = 0;
  uStack_b88 = 0;
  uStack_b90 = (undefined8 **)CONCAT71(uStack_b90._1_7_,1);
  uStack_b98 = CONCAT71(uStack_b98._1_7_,1);
  puStack_ba0 = (undefined8 *)((ulonglong)puStack_ba0 & 0xffffffff00000000);
  uStack_ba8._0_4_ = 0xffffffff;
  uStack_bb0 = uStack_bb0 & 0xffffffff00000000;
  uStack_bb8 = (longlong *)CONCAT44(uStack_bb8._4_4_,uVar6);
  uStack_b5c = uVar6;
  cVar5 = func_0x(0x41534445,puVar4,plVar11,uVar6);
  bVar20 = cVar5 != '\0';
  uStack_b60 = 0x41534445;
  uStack_b54 = 0;
  uStack_b56 = 1;
  uStack_b58._1_1_ = bVar20;
  if (cVar5 == '\0') {
    puStack_b08 = (undefined8 *)CONCAT44(uRam00000000012e2d5c,_DAT_);
    uStack_b00 = uRam00000000012e2d60;
    uStack_afc = uRam00000000012e2d64;
    uStack_b70 = 0xffffffff;
    uStack_b78 = 0;
    uStack_b80 = uStack_b80 & 0xffffffff00000000;
    uStack_b88 = 0;
    uStack_b90 = &puStack_b08;
    uStack_b98 = 0;
    puStack_ba0 = (undefined8 *)0x0;
    uStack_ba8._0_4_ = 0;
    uStack_bb0 = CONCAT44(uStack_bb0._4_4_,(uint)bVar20);
    uStack_bb8 = (longlong *)((ulonglong)uStack_bb8 & 0xffffffff00000000);
    func_0x(0x41534445,0,plVar11,uVar6);
    uStack_b58._0_1_ = 1;
    *(undefined4 *)(param_4 + 8) = 0x3b8f;
    (*_DAT_)(0x98,0x2f,0x10,0x14);
  }
  auStack_b68[0] = 5;
  uStack_b48 = (char *)CONCAT44(uStack_b48._4_4_,0x297a);
  uStack_bb8 = (longlong *)CONCAT71(uStack_bb8._1_7_,3);
  puStack_b08 = (undefined8 *)(*_DAT_)(0x88,puVar4,0x170cd38,0x297a);
  puVar18 = puVar14;
  if (puStack_b08 != (undefined8 *)0x0) {
    *puStack_b08 = 0;
    puStack_b08[1] = 0;
    puStack_b08[2] = 0;
    puStack_b08[3] = 0;
    puStack_b08[4] = 0;
    *(undefined4 *)(puStack_b08 + 5) = 0;
    puStack_b08[6] = puVar4;
    *(undefined4 *)(puStack_b08 + 7) = 1;
    *(undefined2 *)((longlong)puStack_b08 + 0x3c) = 0;
    puStack_b08[8] = 0;
    *(undefined *)(puStack_b08 + 9) = 0;
    puStack_b08[10] = 0;
    *(undefined4 *)(puStack_b08 + 0xb) = 0;
    *(undefined2 *)((longlong)puStack_b08 + 0x5c) = 0;
    puStack_b08[0xc] = 0;
    puStack_b08[0xd] = 0;
    puStack_b08[0xe] = 0;
    *(undefined2 *)(puStack_b08 + 0xf) = 0;
    *(undefined4 *)((longlong)puStack_b08 + 0x7c) = 0;
    *(undefined *)(puStack_b08 + 0x10) = 0;
    puVar18 = puStack_b08;
  }
  puStack_ad8 = puVar18;
  func_0x(puVar18,5);
  uStack_ba8 = lStack_b18 + 0x28;
  puVar17 = (undefined8 *)(lStack_b18 + 8);
  if (lStack_b18 == 0) {
    puVar17 = puVar14;
  }
  uStack_bb0 = uStack_bb0 & 0xffffffff00000000;
  uStack_bb8 = (longlong *)((ulonglong)uStack_bb8 & 0xffffffffffff0000);
  func_0x(puVar18,puVar17,0,0);
  func_0x(puVar18,lStack_af8);
  func_0x(puVar18,lStack_af0);
  func_0x(puVar18,lStack_ae8);
  func_0x(puVar18,lStack_ae0);
  uStack_bb8 = (longlong *)auStack_b68;
  func_0x(auStack_998,puVar18);
  func_0x(auStack_a00,0x170e308,0x1e);
  uStack_bb8 = (longlong *)((ulonglong)uStack_bb8 & 0xffffffffffffff00);
  func_0x(auStack_998,puVar4,auStack_a00,auStack_b68[0]);
  uStack_a90 = 0;
  uStack_a88 = 1;
  uStack_a80 = 0;
  auStack_a78 = ZEXT816(0);
  uStack_a68 = 0;
  uStack_a60 = 0;
  auStack_a58 = ZEXT816(0);
  uStack_a44 = 0;
  uStack_a40 = 0;
  uStack_a38 = 0;
  lStack_a98 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 0x20);
  func_0x(&lStack_a98,
                  CONCAT71((int7)((ulonglong)*(longlong *)(unaff_GS_OFFSET + 0x58) >> 8),1));
  if (((uStack_a40 & 1) == 0) && (lStack_a98 != 0)) {
    puVar14 = (undefined8 *)(**(code **)**(undefined8 **)(lStack_a98 + 0x48))();
  }
  uStack_878._0_4_ = 0x40012c;
  uStack_860 = 0;
  uStack_868 = 0;
  uStack_858 = 0;
  uStack_ad0 = 0x400000;
  puStack_ac8 = (undefined8 *)0x0;
  uStack_ab8 = 0;
  uStack_ac0 = 0;
  uStack_ab0 = 0;
  cStack_aa0 = '\0';
  lVar10 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar8 = *(longlong *)(lVar10 + 0x100);
  puStack_870 = puVar14;
  if (lVar8 == 0) {
    (*_DAT_)(0);
    lVar8 = *(longlong *)(lVar10 + 0x100);
  }
  if (*(longlong *)(lVar8 + 600) != 0) {
    uStack_ad0 = (undefined4)uStack_878;
    uStack_acc = uStack_878._4_4_;
    puStack_ac8 = puStack_870;
    uStack_ac0 = uStack_868;
    uStack_ab8 = uStack_860;
    uStack_ab0 = uStack_858;
    iVar7 = (*_DAT_)(*(longlong *)(lVar8 + 600),&uStack_ad0);
    cStack_aa0 = iVar7 == 0;
  }
  uStack_bb8 = (longlong *)0x0;
  func_0x(auStack_998,puVar4,0,lStack_b20);
  if ((uStack_a40 & 1) != 0) {
    func_0x(&lStack_a98);
  }
  if (cStack_aa0 != '\0') {
    lVar10 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar8 = *(longlong *)(lVar10 + 0x100);
    if (lVar8 == 0) {
      (*_DAT_)();
      lVar8 = *(longlong *)(lVar10 + 0x100);
    }
    (*_DAT_)(*(undefined8 *)(lVar8 + 600));
  }
  if ((uStack_a40 & 1) != 0) {
    func_0x(&lStack_a98);
  }
  func_0x(&uStack_a60);
  func_0x(&uStack_a80);
  func_0x(uStack_8a8);
  uStack_894 = 0;
  if (puVar18 != (undefined8 *)0x0) {
    if (((*(uint *)(puVar18 + 4) >> 8 & 1) == 0) && (*(int *)(puVar18 + 3) != 0)) {
      (*_DAT_)(*(undefined8 *)puVar18[2]);
      (*_DAT_)(puVar18[2]);
      (*_DAT_)(puVar18[10]);
      if (puVar18[0xc] != 0) {
        (*_DAT_)();
      }
    }
    (*_DAT_)(puVar18,0x88);
  }
  func_0x(&uStack_b60);
  func_0x(auStack_998);
  *puVar13 = 0x16ab798;
  puStack_ad8 = puVar13;
  if (puVar13[5] != 0) {
    (*_DAT_)();
  }
  *puVar13 = 0x1323d38;
  puVar4 = (undefined8 *)puVar13[1];
  if (puVar4 != (undefined8 *)0x0) {
    (**(code **)*puVar4)(puVar4,1);
  }
  (*_DAT_)(puVar13,0x30);
  (**(code **)*plVar11)(plVar11,1);
  if ((int)uStack_b40 != 0) {
    func_0x(&uStack_b40,0);
  }
  auStack_9d0 = ZEXT816(0);
  if ((DAT_ != '\0') && ((lStack_9c0 != 0 || (lStack_9b8 != 0)))) {
    func_0x(0x1f66d38,&lStack_9c0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_bd8);
  return;
}

