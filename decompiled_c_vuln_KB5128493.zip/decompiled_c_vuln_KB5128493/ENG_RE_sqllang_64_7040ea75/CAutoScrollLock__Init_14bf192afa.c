
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong *param_1,longlong *param_2,int param_3,int param_4,longlong param_5)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(*param_2 + 0xf8))(param_2);
  param_1[3] = param_5;
  *param_1 = lVar2;
  *(undefined4 *)(param_1 + 2) = 0;
  if (((lVar2 != 0) && (param_4 == 0)) &&
     ((param_3 != 0 || (iVar1 = (**(code **)(*param_2 + 0x30))(param_2,0xe), iVar1 != 0)))) {
    *(undefined4 *)(param_1 + 1) = 1;
    if (((param_3 == 0) && (lVar2 = *param_1, lVar2 != 0)) && (*(int *)(lVar2 + 100) != 0)) {
      *(undefined4 *)((longlong)param_1 + 0xc) = 1;
      *(undefined4 *)((longlong)param_1 + 0x14) = *(undefined4 *)(lVar2 + 0x88);
      *(undefined4 *)(lVar2 + 0xd8) = 1;
      *(longlong *)(param_1[3] + 0x40) = *param_1;
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

