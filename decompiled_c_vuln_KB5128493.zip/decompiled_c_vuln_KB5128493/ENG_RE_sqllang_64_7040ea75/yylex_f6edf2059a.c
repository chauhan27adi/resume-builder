
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_(int *param_1,longlong param_2)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  longlong unaff_GS_OFFSET;
  
  if ((*(byte *)(param_2 + 0x5b0) & 4) != 0) {
    *(undefined2 *)(param_2 + 0x120) = 0;
    *(byte *)(param_2 + 0x5b0) = *(byte *)(param_2 + 0x5b0) & 0xfb;
    iVar3 = *(int *)(param_2 + 0x1c);
    *param_1 = iVar3;
    return iVar3;
  }
  if (*(int *)(param_2 + 0x124) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(int *)(param_2 + 0x5e4) = *(int *)(param_2 + 0x25c) + *(int *)(param_2 + 600);
  if (*(char *)(param_2 + 0x121) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(char *)(param_2 + 0x120) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar3 = func_0x(param_1,param_2,param_2 + 0x130);
  if (*(int *)(param_2 + 0x14) == 4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar3 != 0) {
    *(undefined4 *)(param_2 + 0x588) = *(undefined4 *)(param_2 + 0x248);
    *(undefined4 *)
     (*(longlong *)
       (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
         0xa0) + 8) + 0x1d4) = *(undefined4 *)(param_2 + 0x248);
  }
  func_0x(param_2,iVar3,param_2 + 0x130,0);
  iVar2 = *(int *)(param_2 + 0x14);
  if (iVar2 == 4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar2 != 10) {
    *(undefined4 *)(param_2 + 0x14) = 0;
  }
  bVar1 = *(byte *)(param_2 + 0x5b0);
  if (((bVar1 & 1) != 0) || (iVar2 == 9)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((iVar3 == 0x3b) || (iVar3 == 0x152)) || (iVar3 == 0x134)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *(byte *)(param_2 + 0x5b0) = ((bVar1 * '\x02' ^ bVar1) & 2 ^ bVar1) & 0xfe;
  if (iVar3 == 0x1aa) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar3 != 0x175) {
    if (iVar3 == 0x1a6) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar3 == 0x134) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(int *)(*(longlong *)(param_2 + 0x110) + 0x1c) - 6U & 0xfffffffd) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (((DAT_ != '\0') && (-1 < *(char *)(_DAT_ + 0x56c))) &&
       (*(int *)(*(longlong *)(param_2 + 0x110) + 0x1c) == 6)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (iVar3 != 0x10f) {
      return iVar3;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

