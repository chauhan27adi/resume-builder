
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong param_3,char param_4)

{
  uint *puVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  ulonglong uVar10;
  undefined *puVar11;
  undefined *puVar12;
  undefined *puVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  longlong *plVar16;
  undefined8 uStack_b0;
  undefined auStack_a8 [32];
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  longlong lStack_50;
  longlong lStack_48;
  undefined8 uStack_40;
  longlong lStack_38;
  ulonglong uStack_30;
  
  puVar11 = auStack_a8;
  puVar12 = auStack_a8;
  puVar13 = auStack_a8;
  uStack_40 = 0xfffffffffffffffe;
  uStack_30 = _DAT_ ^ (ulonglong)auStack_68;
  uStack_b0 = 0x10005a;
  iVar4 = func_0x(*param_2,*(undefined4 *)(param_2 + 1),0x1f5e970);
  if (iVar4 < 0) {
    uStack_b0 = 0x100077;
    iVar4 = func_0x(*param_2,*(undefined4 *)(param_2 + 1),0x1f0d160);
    if (iVar4 < 0) {
      uStack_b0 = 0x100091;
      iVar4 = func_0x(*param_2,*(undefined4 *)(param_2 + 1),0x1f5ec20);
      if (iVar4 < 0) {
        if (param_4 != '\0') {
          uStack_80 = CONCAT44(uStack_80._4_4_,0x12);
          uStack_88 = 0x1810888;
          uStack_b0 = 0x1000c7;
          iVar4 = (*_DAT_)(1,0,*param_2,(ulonglong)(longlong)*(int *)(param_2 + 1) >> 1);
          if (iVar4 == 2) goto LAB_;
        }
        uStack_78 = 0x32ee;
        uStack_80 = *param_2;
        uStack_88 = CONCAT44(uStack_88._4_4_,*(undefined4 *)(param_2 + 1));
        uStack_b0 = 0x1000fd;
        func_0x(1,0x5f,*(undefined4 *)(param_2 + 3));
        puVar13 = auStack_a8;
        goto LAB_;
      }
    }
LAB_:
    uStack_80 = *param_2;
    uVar14 = *(undefined4 *)(param_2 + 3);
    uVar15 = 4;
    uStack_88 = CONCAT44(uStack_88._4_4_,*(undefined4 *)(param_2 + 1));
    puVar12 = auStack_a8;
  }
  else {
    lVar7 = *(longlong *)(*(longlong *)(param_1 + 8) + 0xa0);
    iVar5 = *(int *)(lVar7 + 0x30);
    if (iVar5 == 0) {
      uStack_b0 = 0x10011d;
      cVar3 = func_0x(lVar7);
      iVar5 = 2 - (uint)(cVar3 != '\0');
      *(int *)(lVar7 + 0x30) = iVar5;
    }
    if ((iVar5 == 1) && (param_4 == '\0')) {
      uStack_b0 = 0x100144;
      func_0x(0x5a,2,*(undefined4 *)(param_2 + 3),*param_2);
      goto LAB_;
    }
    auStack_68[0] = 0;
    uStack_b0 = 0x10015d;
    cVar3 = func_0x(*(undefined8 *)(param_1 + 8),auStack_68);
    if (cVar3 != '\0') {
      iVar5 = *(int *)(param_2 + 3);
      switch(iVar4) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 6:
      case 7:
      case 9:
        break;
      default:
        uStack_b0 = 0x10019d;
        lVar7 = func_0x(*param_2,(ulonglong)(longlong)*(int *)(param_2 + 1) >> 1,0);
        uStack_60 = _DAT_;
        uStack_5c = uRam00000000015233b4;
        uStack_58 = uRam00000000015233b8;
        uStack_54 = uRam00000000015233bc;
        lStack_50 = _DAT_;
        lStack_48 = lRam00000000015233c8;
        uStack_88 = _DAT_;
        if (lVar7 != 0) {
          uStack_88 = lVar7;
        }
        lStack_38 = lVar7;
        if (iVar5 < 0) {
          uStack_88 = lRam00000000015233c8;
          uStack_b0 = 0x10020b;
          func_0x(uRam00000000015233b4,uRam00000000015233b8,1);
        }
        else {
          uStack_80 = lRam00000000015233c8;
          uStack_b0 = 0x1001f6;
          func_0x(uRam00000000015233b4,uRam00000000015233b8,iVar5,1);
        }
        uStack_b0 = 0x100215;
        (*_DAT_)(lVar7);
        puVar13 = auStack_a8;
        goto LAB_;
      }
    }
    if ((param_4 != '\0') && (2 < iVar4 - 1U)) goto LAB_;
    uStack_b0 = 0x100239;
    iVar5 = (**(code **)(**(longlong **)(param_3 + 0x10) + 0x18))();
    plVar9 = *(longlong **)(param_3 + 0x10);
    plVar16 = (longlong *)0x0;
    if ((iVar5 != 0x62) || (plVar16 = plVar9 + 8, plVar16 == (longlong *)0x0)) {
      uStack_b0 = 0x100259;
      iVar5 = (**(code **)(*plVar9 + 0x18))(plVar9);
      if ((iVar5 != 99) || (*(char *)(plVar9[8] + 0xc) != '\n')) goto LAB_;
      plVar9 = *(longlong **)(param_3 + 0x10);
    }
    if (iVar4 == 5) {
      if (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(plVar9 + 3) + 0x14049a0) + 0x14414a0)
          == '\0') goto LAB_;
      lVar7 = *(longlong *)(*(longlong *)(param_1 + 8) + 0xa0);
      puVar1 = (uint *)(*(longlong *)(lVar7 + 8) + 0x240);
      *puVar1 = *puVar1 | 0x400;
      lVar7 = *(longlong *)(lVar7 + 8);
      plVar9 = *(longlong **)(lVar7 + 0x48);
      if ((plVar9 == (longlong *)0x0) &&
         (lVar7 = *(longlong *)(lVar7 + 0x1a0), plVar9 = (longlong *)0x0, lVar7 != 0)) {
        plVar9 = *(longlong **)(lVar7 + 0x58);
      }
      uStack_b0 = 0x1003b9;
      func_0x(plVar9,0x1c,3);
      uStack_b0 = 0x1003dd;
      lVar8 = func_0x();
      lVar8 = -lVar8;
      puVar11 = auStack_a8 + lVar8;
      puVar12 = auStack_a8 + lVar8;
      lVar7 = (longlong)auStack_68 + lVar8;
      uVar14 = *(undefined4 *)(param_1 + 0x90);
      *(undefined8 *)(auStack_a8 + lVar8 + -8) = 0x1003f1;
      uVar15 = (*_DAT_)(uVar14);
      uVar14 = *(undefined4 *)(plVar16 + 2);
      *(undefined4 *)((longlong)&uStack_88 + lVar8) = uVar14;
      lVar2 = plVar16[1];
      *(undefined8 *)(auStack_a8 + lVar8 + -8) = 0x100409;
      iVar5 = (*_DAT_)(uVar15,lVar2,uVar14,lVar7);
      *(undefined8 *)(auStack_a8 + lVar8 + -8) = 0x10041e;
      iVar6 = func_0x(lVar7,iVar5 * 2,0x1f66800);
      if (-1 < iVar6) {
        *(int *)(**(longlong **)(*(longlong *)(param_1 + 8) + 0x40) + 0x50) = iVar6;
        goto LAB_;
      }
      *(longlong *)((longlong)&uStack_80 + lVar8) = lVar7;
      *(int *)((longlong)&uStack_88 + lVar8) = iVar5 * 2;
      uVar15 = 3;
      uVar14 = *(undefined4 *)(param_1 + 0x588);
    }
    else if (iVar4 == 6) {
      if (*(char *)(plVar9 + 3) == '8') {
        uStack_b0 = 0x1002fc;
        lVar7 = func_0x();
        *(longlong *)(lVar7 + 0x10) = param_3;
        uStack_88 = 0;
        uStack_b0 = 0x100315;
        lVar7 = func_0x(0,lVar7,0,0);
        *(undefined2 *)(lVar7 + 0x62) = 6;
        puVar13 = auStack_a8;
        goto LAB_;
      }
      uStack_80 = 0x158d948;
      uStack_88 = 0x18;
      uVar15 = 3;
      uVar14 = *(undefined4 *)(param_1 + 0x588);
    }
    else {
      if (iVar4 != 7) {
LAB_:
        *(undefined8 *)(puVar11 + -8) = 0x100452;
        lVar7 = func_0x();
        *(longlong *)(lVar7 + 0x10) = param_3;
        *(undefined8 *)(puVar11 + 0x20) = 0;
        *(undefined8 *)(puVar11 + -8) = 0x10046b;
        lVar7 = func_0x(0,lVar7,0,0);
        *(ushort *)(lVar7 + 0x62) = (ushort)iVar4 & 0xff;
        puVar13 = puVar11;
        goto LAB_;
      }
      if ((*(char *)(plVar9 + 3) == '8') || (*(char *)(plVar9 + 3) == 'l')) {
        uStack_b0 = 0x1002c4;
        lVar7 = func_0x();
        *(longlong *)(lVar7 + 0x10) = param_3;
        uStack_88 = 0;
        uStack_b0 = 0x1002dd;
        lVar7 = func_0x(0,lVar7,0,0);
        *(undefined2 *)(lVar7 + 0x62) = 7;
        puVar13 = auStack_a8;
        goto LAB_;
      }
      uStack_80 = 0x158d968;
      uStack_88 = 0x32;
      uVar15 = 3;
      uVar14 = *(undefined4 *)(param_1 + 0x588);
      puVar12 = auStack_a8;
    }
  }
  *(undefined8 *)(puVar12 + -8) = 0x1004a1;
  func_0x(1,2,uVar14,uVar15);
  puVar13 = puVar12;
LAB_:
  uVar10 = uStack_30 ^ (ulonglong)auStack_68;
  *(undefined8 *)(puVar13 + -8) = 0x1004af;
  func_0x(uVar10);
  return;
}

