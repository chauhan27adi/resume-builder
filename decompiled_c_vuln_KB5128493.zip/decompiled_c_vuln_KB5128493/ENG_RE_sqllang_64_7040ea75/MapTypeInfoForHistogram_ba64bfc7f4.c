
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(char *param_1,uint *param_2)

{
  char cVar1;
  char cVar2;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint uStack_10;
  uint uStack_c;
  
  cVar1 = *param_1;
  cVar2 = (*_DAT_)(cVar1);
  if (cVar2 == cVar1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (cVar2 == '>') {
    func_0x(&uStack_28,0x3e);
    if ((~param_1[1] & 1U) == 0) {
      uStack_28 = uStack_28 | 0x100;
    }
    *param_2 = uStack_28;
    param_2[1] = uStack_24;
    param_2[2] = uStack_20;
    param_2[3] = uStack_1c;
    param_2[4] = uStack_18;
    param_2[5] = uStack_14;
    param_2[6] = uStack_10;
    param_2[7] = uStack_c;
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

