
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x0179020c) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2,longlong param_3,undefined8 param_4)

{
  int *piVar1;
  longlong *plVar2;
  undefined8 uVar3;
  int iVar4;
  undefined8 uVar5;
  uint uVar6;
  ulonglong uVar7;
  uint uVar8;
  uint uVar9;
  undefined8 uStackX_10;
  undefined8 uStackX_18;
  undefined8 uStackX_20;
  longlong lStack_108;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  undefined8 uStack_f0;
  undefined uStack_e8;
  uint uStack_e4;
  uint uStack_e0;
  longlong lStack_d8;
  undefined8 *puStack_d0;
  longlong *plStack_c8;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined8 uStack_a8;
  undefined uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_90;
  undefined8 uStack_70;
  longlong lStack_68;
  ulonglong uVar10;
  
  uStack_70 = 0xfffffffffffffffe;
  uStackX_10 = (undefined8 *)param_2;
  uStackX_20 = param_4;
  plStack_c8 = (longlong *)(**(code **)(**(longlong **)(param_2 + 0x108) + 0xa8))();
  puStack_d0 = &uStack_a8;
  uStack_a0 = 0;
  uVar7 = 0;
  uStack_9c = 0;
  uStack_98 = 1;
  uStack_90 = 0;
  uStack_b0 = 1;
  uStack_b8 = 0x1f8bbb0;
  uStack_a8 = param_1;
  func_0x(&uStack_a8,&uStackX_10);
  uStackX_18 = CONCAT44(uStackX_18._4_4_,0x1123);
  lStack_108 = (*_DAT_)(0x68,param_1,0x1fb2fd8,0x1123,1);
  if (lStack_108 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar5 = func_0x(lStack_108,param_1);
  uStackX_10 = &uStack_f0;
  uStack_e8 = 0;
  uStack_e4 = 0;
  uStack_e0 = 1;
  if (*(uint *)(param_3 + 0x18) != 0) {
    uStack_e0 = *(uint *)(param_3 + 0x18);
  }
  lStack_d8 = 0;
  uStack_f8 = 1;
  uStack_100 = 0x1f8b5f8;
  plVar2 = *(longlong **)(param_3 + 0x10);
  uStack_f0 = param_1;
  puStack_d0 = (undefined8 *)param_3;
  iVar4 = (**(code **)(*plVar2 + 0x18))(plVar2);
  uVar9 = uStack_e0;
  if ((iVar4 != 0x59) || (*(int *)(plVar2 + 8) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar10 = uVar7;
  if (*(int *)(param_3 + 0x18) < 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  do {
    uVar3 = *(undefined8 *)(uVar7 + *(longlong *)(param_3 + 0x20));
    if (lStack_d8 == 0) {
      uStack_e0 = uVar9;
      lStack_d8 = func_0x(&uStack_f0,uVar9);
    }
    if (uVar9 <= uStack_e4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)(lStack_d8 + (ulonglong)uStack_e4 * 8) = uVar3;
    uVar6 = uStack_e4 + 1;
    uVar8 = (int)uVar10 + 1;
    uVar7 = uVar7 + 8;
    uVar10 = (ulonglong)uVar8;
    uStack_e4 = uVar6;
  } while ((int)uVar8 < *(int *)(param_3 + 0x18));
  uVar10 = 0;
  uStackX_10 = (undefined8 *)CONCAT44(uStackX_10._4_4_,uVar6);
  uVar7 = uVar10;
  uStack_e0 = uVar9;
  if (uVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  do {
    if (uStack_e4 <= (uint)uVar10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    plVar2 = *(longlong **)(*(longlong *)(uVar7 + lStack_d8) + 0x10);
    lStack_108 = 0;
    uStackX_18 = 0;
    iVar4 = (**(code **)(*plVar2 + 0x510))
                      (plVar2,param_1,*(longlong *)(uVar7 + lStack_d8),&uStack_b8,&lStack_108,
                       &uStackX_18);
    if (iVar4 != 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lStack_68 = (**(code **)(*plStack_c8 + 200))(plStack_c8,lStack_108);
    if (lStack_68 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(uVar5,lStack_108,uStackX_18);
    if (uStackX_18 != 0) {
      piVar1 = (int *)(uStackX_18 + 8);
      *piVar1 = *piVar1 + -1;
      if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    uVar9 = (uint)uVar10 + 1;
    uVar10 = (ulonglong)uVar9;
    uVar7 = uVar7 + 8;
  } while (uVar9 < uVar6);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

