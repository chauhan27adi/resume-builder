
/* WARNING: Control flow encountered bad instruction data */

ulonglong FUN_(undefined8 param_1,longlong param_2,longlong param_3)

{
  int iVar1;
  ulonglong uVar2;
  
  if (*(int *)(param_3 + 0x2f8) < 100) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar1 = (**(code **)(**(longlong **)(param_2 + 0x10) + 0x18))(*(longlong **)(param_2 + 0x10));
  if (iVar1 == 0x59) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar1 = (**(code **)(**(longlong **)(param_2 + 0x10) + 0x18))(*(longlong **)(param_2 + 0x10));
  if (iVar1 == 0x59) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = (**(code **)(**(longlong **)(param_2 + 0x10) + 0x18))();
  if ((int)uVar2 != 100) {
    return uVar2 & 0xffffffffffffff00;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

