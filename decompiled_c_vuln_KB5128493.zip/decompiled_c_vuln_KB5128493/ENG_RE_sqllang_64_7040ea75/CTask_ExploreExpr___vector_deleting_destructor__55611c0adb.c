
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(undefined8 *param_1,uint param_2,undefined8 param_3,undefined8 param_4)

{
  int *piVar1;
  
  *param_1 = 0x205e570;
  if ((*(char *)(param_1 + 7) != '\0') && (param_1[6] != 0)) {
    piVar1 = (int *)(param_1[6] + 8);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  *param_1 = 0x21313d8;
  piVar1 = (int *)(param_1[2] + 8);
  *piVar1 = *piVar1 + -1;
  if (*piVar1 != 0) {
    if ((param_2 & 1) != 0) {
      (*_DAT_)(param_1,0x40,param_3,param_4,0xfffffffffffffffe);
    }
    return param_1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

