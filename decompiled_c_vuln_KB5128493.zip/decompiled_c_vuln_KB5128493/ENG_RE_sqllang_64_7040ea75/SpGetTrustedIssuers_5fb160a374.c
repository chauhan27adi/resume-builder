
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong **param_2,longlong param_3,undefined *param_4)

{
  ushort uVar1;
  undefined2 uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  char cVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong lVar11;
  int iVar12;
  uint uVar13;
  longlong lVar14;
  longlong lVar15;
  undefined4 *puVar16;
  longlong unaff_GS_OFFSET;
  undefined auStack_1e8 [32];
  undefined8 uStack_1c8;
  undefined8 uStack_1c0;
  ulonglong uStack_1b8;
  short *psStack_1b0;
  undefined4 uStack_1a8;
  undefined4 auStack_198 [2];
  int aiStack_190 [4];
  longlong lStack_180;
  uint uStack_178;
  uint uStack_174;
  int aiStack_170 [4];
  longlong lStack_160;
  uint uStack_158;
  uint uStack_154;
  undefined8 uStack_150;
  undefined4 uStack_148;
  undefined auStack_140 [16];
  longlong *plStack_130;
  undefined8 uStack_128;
  undefined auStack_118 [144];
  short asStack_88 [32];
  ulonglong uStack_48;
  
  uStack_128 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1e8;
  *(undefined4 *)(param_4 + 8) = 1;
  uVar3 = **param_2;
  uVar1 = *(ushort *)(*param_2 + 1);
  iVar12 = 0;
  if (param_3 != 0) {
    iVar12 = *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28);
  }
  uStack_150 = 0;
  uVar4 = **param_2;
  uVar2 = *(undefined2 *)(*param_2 + 1);
  uStack_148 = 1;
  auStack_140._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_140._8_8_ = 0;
  cVar5 = (**(code **)(*(longlong *)auStack_140._0_8_ + 0x1d0))();
  if (cVar5 == '\0') {
    uStack_1a8 = 0;
    psStack_1b0 = (short *)0x0;
    uStack_1b8 = uStack_1b8 & 0xffffffffffffff00;
    uStack_1c0 = CONCAT44(uStack_1c0._4_4_,2);
    uStack_1c8 = CONCAT44(uStack_1c8._4_4_,1);
    (**(code **)(*(longlong *)auStack_140._0_8_ + 8))(auStack_140._0_8_,uVar4,uVar2,1);
    uStack_150 = CONCAT44(uStack_150._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_140._0_8_ + 0xe8))
              (auStack_140._0_8_,1,1,(longlong)&uStack_150 + 4);
    uStack_148 = 1;
    uStack_150 = CONCAT44(uStack_150._4_4_,4);
  }
  if (iVar12 == 0) {
    uVar7 = (**(code **)(*(longlong *)auStack_140._0_8_ + 0x1b0))();
    lVar14 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar11 = *(longlong *)(lVar14 + 0x100);
    if (lVar11 == 0) {
      (*_DAT_)();
      lVar11 = *(longlong *)(lVar14 + 0x100);
    }
    plVar8 = (longlong *)(**_DAT_)(*(undefined8 *)(lVar11 + 1000),uVar7,0x14dd7e8,0xca3);
    uStack_1c0 = uStack_1c0 & 0xffffffff00000000;
    uStack_1c8 = uStack_1c8 & 0xffffffff00000000;
    plStack_130 = plVar8;
    plVar9 = (longlong *)
             (**(code **)(*plVar8 + 0x38))
                       (plVar8,*(undefined2 *)
                                (*(longlong *)
                                  (*(longlong *)
                                    ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8)) + 0x50) + 8),0,0);
    auStack_198[0] = 0;
    (*_DAT_)(auStack_118,0,2,0);
    (*_DAT_)(auStack_118,0x14ddb00,7,0);
    (*_DAT_)(auStack_118,0x14ddaf0,0xd,0x1fc);
    cVar5 = (**(code **)(*plVar9 + 0x340))(plVar9,auStack_198);
    while (cVar5 != '\0') {
      plVar10 = (longlong *)(**(code **)(*plVar9 + 0x328))(plVar9,auStack_198[0],0);
      lVar14 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar11 = *(longlong *)(lVar14 + 0x100);
      if (lVar11 == 0) {
        (*_DAT_)(0);
        lVar11 = *(longlong *)(lVar14 + 0x100);
      }
      func_0x(aiStack_190,*(undefined8 *)(lVar11 + 1000),0,8);
      lVar14 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar11 = *(longlong *)(lVar14 + 0x100);
      if (lVar11 == 0) {
        (*_DAT_)(0);
        lVar11 = *(longlong *)(lVar14 + 0x100);
      }
      func_0x(aiStack_170,*(undefined8 *)(lVar11 + 1000),0,4);
      lVar14 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar11 = *(longlong *)(lVar14 + 0x100);
      if (lVar11 == 0) {
        (*_DAT_)(0);
        lVar11 = *(longlong *)(lVar14 + 0x100);
      }
      uVar6 = (**(code **)(*plVar10 + 200))
                        (plVar10,*(undefined8 *)(lVar11 + 1000),aiStack_190,aiStack_170);
      uVar13 = 0;
      if (uVar6 != 0) {
        do {
          uVar7 = (*_DAT_)(auStack_118);
          (*_DAT_)(uVar7,auStack_198[0]);
          if (uStack_154 <= uVar13) {
            if (uStack_158 <= uVar13) {
              func_0x(aiStack_170,uVar13 + 1);
            }
            uStack_154 = uVar13 + 1;
          }
          if (uStack_174 <= uVar13) {
            if (uStack_178 <= uVar13) {
              func_0x(aiStack_190,uVar13 + 1);
            }
            uStack_174 = uVar13 + 1;
          }
          (*_DAT_)(uVar7,*(undefined8 *)((ulonglong)(aiStack_190[0] * uVar13) + lStack_180))
          ;
          (*_DAT_)(auStack_118,uVar7);
          if (uStack_174 <= uVar13) {
            if (uStack_178 <= uVar13) {
              func_0x(aiStack_190,uVar13 + 1);
            }
            uStack_174 = uVar13 + 1;
          }
          (*_DAT_)(*(undefined8 *)((ulonglong)(aiStack_190[0] * uVar13) + lStack_180));
          uVar13 = uVar13 + 1;
        } while (uVar13 < uVar6);
      }
      if (lStack_160 != 0) {
        (*_DAT_)();
      }
      if (lStack_180 != 0) {
        (*_DAT_)();
      }
      cVar5 = (**(code **)(*plVar9 + 0x340))(plVar9,auStack_198);
    }
    (*_DAT_)(auStack_118,0);
    (*_DAT_)(auStack_118);
    (**(code **)*plVar8)(plVar8,1);
  }
  else if (iVar12 == 1) {
    lVar11 = *(longlong *)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(lVar11 + 0x18) == '8') {
      if (**(char **)(lVar11 + 8) == '\x03') {
        uStack_1b8 = 0x14ddb78;
        uStack_1c0 = CONCAT44(uStack_1c0._4_4_,0x1e);
        uStack_1c8 = 0x1080c98;
        (*_DAT_)(2,0x19,0x10,1);
      }
    }
    else {
      uStack_1c0 = (*_DAT_)(CONCAT71((int7)(int3)((uint)*(int *)(param_3 + 0x28) >> 8),0x38)
                                   );
      uStack_1c8 = 0x14ddb78;
      (*_DAT_)(2,0xe,0x10,0xd4);
    }
    uVar7 = (**(code **)(*(longlong *)auStack_140._0_8_ + 0x1b0))();
    lVar15 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar14 = *(longlong *)(lVar15 + 0x100);
    if (lVar14 == 0) {
      (*_DAT_)();
      lVar14 = *(longlong *)(lVar15 + 0x100);
    }
    plVar8 = (longlong *)(**_DAT_)(*(undefined8 *)(lVar14 + 1000),uVar7,0x14dd7e8,0xcdc);
    uStack_1c0 = uStack_1c0 & 0xffffffff00000000;
    uStack_1c8 = uStack_1c8 & 0xffffffff00000000;
    plStack_130 = plVar8;
    plVar9 = (longlong *)
             (**(code **)(*plVar8 + 0x38))
                       (plVar8,*(undefined2 *)
                                (*(longlong *)
                                  (*(longlong *)
                                    ((ulonglong)*_DAT_ +
                                    *(longlong *)
                                     (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                     (ulonglong)*_DAT_ * 8)) + 0x50) + 8),0,0);
    plVar9 = (longlong *)
             (**(code **)(*plVar9 + 0x328))(plVar9,*(undefined4 *)(*(longlong *)(lVar11 + 8) + 8),0)
    ;
    if (plVar9 == (longlong *)0x0) {
      asStack_88[0] = 0;
      func_0x
                (asStack_88,0x20,0x10ca8b8,*(undefined4 *)(*(longlong *)(lVar11 + 8) + 8));
      *(undefined4 *)(param_4 + 8) = 0x3b2f;
      lVar14 = -1;
      do {
        lVar14 = lVar14 + 1;
      } while (asStack_88[lVar14] != 0);
      uStack_1b8 = lVar14 * 2;
      psStack_1b0 = asStack_88;
      uStack_1c0 = CONCAT44(uStack_1c0._4_4_,0x8ac9);
      uStack_1c8 = CONCAT44(uStack_1c8._4_4_,0x333e);
      (*_DAT_)(0x97,0x33,0x10,1);
    }
    lVar15 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar14 = *(longlong *)(lVar15 + 0x100);
    if (lVar14 == 0) {
      (*_DAT_)(0);
      lVar14 = *(longlong *)(lVar15 + 0x100);
    }
    func_0x(aiStack_190,*(undefined8 *)(lVar14 + 1000),0,8);
    lVar15 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar14 = *(longlong *)(lVar15 + 0x100);
    if (lVar14 == 0) {
      (*_DAT_)(0);
      lVar14 = *(longlong *)(lVar15 + 0x100);
    }
    func_0x(aiStack_170,*(undefined8 *)(lVar14 + 1000),0,4);
    lVar15 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar14 = *(longlong *)(lVar15 + 0x100);
    if (lVar14 == 0) {
      (*_DAT_)(0);
      lVar14 = *(longlong *)(lVar15 + 0x100);
    }
    uVar6 = (**(code **)(*plVar9 + 200))
                      (plVar9,*(undefined8 *)(lVar14 + 1000),aiStack_190,aiStack_170);
    (*_DAT_)(auStack_118,0,2);
    (*_DAT_)(auStack_118,0x14ddb00,7);
    (*_DAT_)(auStack_118,0x14ddaf0,0xd,0x1fc);
    uVar13 = 0;
    if (uVar6 != 0) {
      do {
        uVar7 = (*_DAT_)(auStack_118);
        (*_DAT_)(uVar7,*(undefined4 *)(*(longlong *)(lVar11 + 8) + 8));
        if (uStack_154 <= uVar13) {
          if (uStack_158 <= uVar13) {
            func_0x(aiStack_170,uVar13 + 1);
          }
          uStack_154 = uVar13 + 1;
        }
        puVar16 = (undefined4 *)((ulonglong)(aiStack_170[0] * uVar13) + lStack_160);
        if (uStack_174 <= uVar13) {
          if (uStack_178 <= uVar13) {
            func_0x(aiStack_190,uVar13 + 1);
          }
          uStack_174 = uVar13 + 1;
        }
        (*_DAT_)(uVar7,*(undefined8 *)((ulonglong)(aiStack_190[0] * uVar13) + lStack_180),
                         *puVar16);
        (*_DAT_)(auStack_118,uVar7);
        if (uStack_174 <= uVar13) {
          if (uStack_178 <= uVar13) {
            func_0x(aiStack_190,uVar13 + 1);
          }
          uStack_174 = uVar13 + 1;
        }
        (*_DAT_)(*(undefined8 *)((ulonglong)(aiStack_190[0] * uVar13) + lStack_180));
        uVar13 = uVar13 + 1;
      } while (uVar13 < uVar6);
    }
    (*_DAT_)(auStack_118,0);
    (*_DAT_)(auStack_118);
    if (lStack_160 != 0) {
      (*_DAT_)();
    }
    if (lStack_180 != 0) {
      (*_DAT_)();
    }
    (**(code **)*plVar8)(plVar8,1);
  }
  else if (1 < iVar12) {
    *(undefined4 *)(param_4 + 8) = 0x1fd0;
    uStack_1c8 = CONCAT44(uStack_1c8._4_4_,(uint)uVar1);
    uStack_1c0 = uVar3;
    (*_DAT_)(0x51,0x2c,0x10,1);
  }
  func_0x(&uStack_150,0);
  *(undefined4 *)(param_4 + 8) = 0;
  *param_4 = 0;
  if ((int)uStack_150 != 0) {
    func_0x(&uStack_150,0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_1e8);
  return;
}

