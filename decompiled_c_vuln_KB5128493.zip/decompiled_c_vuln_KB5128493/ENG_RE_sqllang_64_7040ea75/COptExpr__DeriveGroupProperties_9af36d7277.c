
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong param_1,undefined8 param_2,undefined param_3)

{
  char cVar1;
  ulonglong uVar2;
  uint *puVar3;
  
  uVar2 = func_0x();
  if (uVar2 < 0x18000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar3 = (uint *)func_0x(0x2bbc7f8);
  *puVar3 = *puVar3 + 1;
  if (9 < *puVar3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(param_1 + 0x50) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x40))
                    (*(longlong **)(param_1 + 0x50),param_3);
  if (cVar1 == '\0') {
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

