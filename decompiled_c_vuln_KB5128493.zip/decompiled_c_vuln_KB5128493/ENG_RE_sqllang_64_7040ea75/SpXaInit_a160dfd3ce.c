
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong *param_2,longlong param_3)

{
  byte *pbVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  
  uVar4 = 0;
  if (((param_3 == 0) || (1 < (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28)) - 2U)) &&
     ((*_DAT_)(0x1d8,2,0x10,1,2,3), param_3 == 0)) {
    (*_DAT_)(1,0x171c264,0x1712910,0x1ea,0);
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0xe,0x15d9f38);
    uVar2 = uVar4;
    if (param_3 != 0) goto LAB_;
LAB_:
    (*_DAT_)(2,1,0x10,1,*(undefined2 *)((undefined8 *)*param_2 + 1),*(undefined8 *)*param_2,
                     0x1c,0x1654d70);
    uVar3 = uVar4;
    if (param_3 == 0) goto LAB_;
  }
  else {
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 1) goto LAB_;
    pbVar1 = *(byte **)(*(longlong *)(param_3 + 0x10) + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar1 + 0x18) != DAT_) {
      uVar2 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x15d9f38,uVar2);
    }
    if ((**(char **)(pbVar1 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar2 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x15d9f38,uVar2);
    }
    if ((*pbVar1 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x15d9f38);
    }
    uVar2 = *(undefined8 *)(pbVar1 + 8);
LAB_:
    if (*(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28) < 2) goto LAB_;
    pbVar1 = *(byte **)(*(longlong *)(param_3 + 0x10) + 8 + (longlong)*(int *)(param_3 + 0x28) * 8);
    if (**(char **)(pbVar1 + 0x18) != DAT_) {
      uVar3 = (*_DAT_)();
      (*_DAT_)(2,0xe,0x10,1,0x1654d70,uVar3);
    }
    if ((**(char **)(pbVar1 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar3 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1654d70,uVar3);
    }
    if ((*pbVar1 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1654d70);
    }
    uVar3 = *(undefined8 *)(pbVar1 + 8);
  }
  if (2 < *(int *)(param_3 + 0x1c) - *(int *)(param_3 + 0x28)) {
    pbVar1 = *(byte **)(*(longlong *)(param_3 + 0x10) + 0x10 +
                       (longlong)*(int *)(param_3 + 0x28) * 8);
    if ((**(char **)(pbVar1 + 0x18) != DAT_) && (**(char **)(pbVar1 + 0x18) != '\x1f')) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1654d58,uVar4);
    }
    if ((**(char **)(pbVar1 + 8) == '\x03') && ((~DAT_ & 1) == 0)) {
      uVar4 = (*_DAT_)(DAT_);
      (*_DAT_)(2,0xe,0x10,1,0x1654d58,uVar4);
    }
    if ((*pbVar1 & 1) == 0) {
      (*_DAT_)(5,0x5b,0x10,1,*(undefined8 *)*param_2,0x1654d58);
    }
    uVar4 = *(undefined8 *)(pbVar1 + 8);
  }
LAB_:
                    /* WARNING: Could not recover jumptable at 0x001003b8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*_DAT_)(uVar2,uVar3,uVar4,*(uint *)(param_3 + 0x20) >> 8 & 0xffffff01);
  return;
}

