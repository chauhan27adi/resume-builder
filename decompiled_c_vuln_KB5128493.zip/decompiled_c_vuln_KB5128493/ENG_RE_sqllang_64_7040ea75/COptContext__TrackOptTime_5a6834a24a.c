
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x01942a14) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong *param_2,double *param_3,double *param_4,
                 double *param_5,double *param_6,char param_7)

{
  int *piVar1;
  double dVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong unaff_GS_OFFSET;
  ulonglong uStackX_8;
  
  if (*_DAT_ == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  (*_DAT_)(&uStackX_8);
  uVar3 = uStackX_8;
  lVar8 = *(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
           0x100);
  if (lVar8 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar8 = *(longlong *)(lVar8 + 600);
  if (*_DAT_ == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  (*_DAT_)(&uStackX_8);
  piVar1 = _DAT_;
  lVar7 = *(longlong *)(lVar8 + 0x98);
  uVar9 = *(ulonglong *)(lVar8 + 0x178);
  uVar5 = *(ulonglong *)(lVar7 + 0xc18);
  uVar6 = *(ulonglong *)(lVar7 + 0x330);
  lVar7 = 0;
  lVar8 = uStackX_8 - uVar6;
  if (uStackX_8 < uVar6) {
    lVar8 = lVar7;
  }
  uVar6 = 0xffffffffffffffff;
  lVar4 = uVar5 - uVar9;
  if (uVar5 < uVar9) {
    lVar4 = lVar7;
  }
  uVar9 = lVar8 + lVar4;
  if ((*(byte *)(param_1 + 0xb3) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*_DAT_ == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*_DAT_ == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar3 < *(ulonglong *)(param_1 + 0x440)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar8 = uVar3 - *(ulonglong *)(param_1 + 0x440);
  if (lVar8 == -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*_DAT_ == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar5 = (ulonglong)(lVar8 * 1000) / *_DAT_;
  *param_2 = uVar5;
  dVar2 = _DAT_;
  if ((longlong)uVar5 < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *param_3 = (double)uVar5 / _DAT_;
  if (uVar9 < *(ulonglong *)(param_1 + 0x450)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar8 = uVar9 - *(ulonglong *)(param_1 + 0x450);
  if (lVar8 == -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar5 = (ulonglong)(lVar8 * 1000) / *_DAT_;
  if ((longlong)uVar5 < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *param_5 = (double)uVar5 / dVar2;
  uVar5 = *(ulonglong *)(param_1 + 0x448);
  if (uVar5 == *(ulonglong *)(param_1 + 0x440)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar5 <= uVar3) {
    if (uVar3 - uVar5 == -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar5 = ((uVar3 - uVar5) * 1000) / *_DAT_;
    if ((longlong)uVar5 < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *param_4 = (double)uVar5 / dVar2;
    if ((uVar9 < *(ulonglong *)(param_1 + 0x458)) ||
       (lVar7 = uVar9 - *(ulonglong *)(param_1 + 0x458), lVar7 != -1)) {
      if (*piVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar6 = (ulonglong)(lVar7 * 1000) / *_DAT_;
    }
    if ((longlong)uVar6 < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *param_6 = (double)uVar6 / dVar2;
    if (param_7 != '\0') {
      *(ulonglong *)(param_1 + 0x448) = uVar3;
      *(ulonglong *)(param_1 + 0x458) = uVar9;
    }
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

