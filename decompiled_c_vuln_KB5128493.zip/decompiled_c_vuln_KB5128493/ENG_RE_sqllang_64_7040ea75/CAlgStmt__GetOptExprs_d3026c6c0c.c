
/* WARNING: Control flow encountered bad instruction data */

undefined8 FUN_(longlong param_1,undefined4 *param_2)

{
  *param_2 = 0;
  if (*(longlong *)(param_1 + 0x18) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(longlong *)(param_1 + 0x10) == 0) && (*(longlong *)(param_1 + 0xf0) == 0)) {
    return 0;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

