
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_(undefined4 param_1,int param_2)

{
  char cVar1;
  bool bVar2;
  
  bVar2 = DAT_ != '\0';
  if (((*(char *)(_DAT_ + 0x4b5) != '\0') ||
      ((*(byte *)(_DAT_ + 0x6b0) & 0x10) != 0)) || (bVar2)) {
    switch(param_1) {
    case 0:
      if (cRam0000000001e5e8ac == '\0') {
        return false;
      }
      break;
    case 1:
    case 2:
      if (param_2 == 5) {
        return true;
      }
      if (((*(char *)(_DAT_ + 0x4b5) != '\0') ||
          ((*(byte *)(_DAT_ + 0x6b0) & 0x10) != 0)) &&
         (cVar1 = func_0x(), cVar1 == '\0')) {
        return false;
      }
      break;
    case 3:
    case 4:
    case 5:
      return param_2 == 6;
    default:
      goto LAB_;
    }
    if (bVar2) {
LAB_:
      return false;
    }
  }
  return true;
}

