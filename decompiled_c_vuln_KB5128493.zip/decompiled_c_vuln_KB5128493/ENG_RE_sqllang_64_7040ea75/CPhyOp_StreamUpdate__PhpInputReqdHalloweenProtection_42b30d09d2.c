
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00105f59) */
/* WARNING: Removing unreachable block (ram,0x0144842e) */
/* WARNING: Removing unreachable block (ram,0x00172997) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(longlong param_1,longlong param_2,undefined8 param_3,longlong param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  bool bVar6;
  char cVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 *puVar10;
  longlong lVar11;
  undefined8 *puVar12;
  int *piVar13;
  uint uVar14;
  longlong lVar15;
  longlong unaff_GS_OFFSET;
  
  lVar15 = param_2;
  lVar8 = func_0x(param_2);
  lVar9 = func_0x(lVar15);
  if (*(longlong *)(lVar15 + 8) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar15 = *(longlong *)(**(longlong **)(*(longlong *)(lVar15 + 8) + 0x20) + 0x50);
  puVar10 = (undefined8 *)(*_DAT_)(0x38,*(undefined8 *)(param_1 + 0x10),0x1fe6808,0x454,1);
  if (puVar10 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar5 = *(undefined8 *)(param_1 + 0x10);
  *puVar10 = 0x1f1ea80;
  *(undefined4 *)(puVar10 + 1) = 1;
  *puVar10 = 0x1fe4388;
  _DAT_ = _DAT_ + 1;
  puVar10[2] = uVar5;
  puVar10[3] = 0;
  *(undefined *)(puVar10 + 4) = 2;
  puVar10[5] = 0;
  puVar10[6] = 0;
  func_0x(puVar10,param_4);
  *(byte *)(puVar10 + 4) = *(byte *)(puVar10 + 4) & 0xdf;
  lVar11 = func_0x();
  if (lVar11 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(*(longlong *)(param_1 + 0x98) + 0xd2) & 1) != 0) {
    return puVar10;
  }
  if (*(longlong *)(param_1 + 0xe0) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (_DAT_ < *(double *)(lVar9 + 0x20)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong *)(param_1 + 0xa8) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(char *)(*(longlong *)(param_1 + 0x98) + 0xd5) < '\0') ||
     ((*(byte *)(*(longlong *)(param_1 + 0x98) + 0xd9) & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x40) - 1U < 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x40) - 1U < 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar9 = *(longlong *)(param_1 + 0x90);
  bVar6 = false;
  if ((*(longlong *)(lVar9 + 0x28) != 0) &&
     (bVar6 = false, *(int *)(*(longlong *)(lVar9 + 0x28) + 0x24) == 2)) {
    bVar6 = true;
  }
  if (!bVar6) {
    iVar1 = *(int *)(*(longlong *)(param_1 + 0x98) + 0x304);
    if (iVar1 == 5) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(uint *)(lVar9 + 0x20) < 2) {
      if ((*(byte *)(*(longlong *)(param_1 + 0x98) + 0xd8) & 6) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      iVar2 = *(int *)(param_1 + 0x40);
      if (iVar2 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (iVar2 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (iVar2 == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((iVar2 == 4) && ((*(uint *)(lVar8 + 0x5c) >> 0xc & 1) == 0)) && (iVar1 != 1)) {
        uVar3 = *(undefined4 *)(lVar9 + 0x1c);
        uVar4 = *(undefined4 *)(lVar9 + 0x18);
        puVar12 = (undefined8 *)(*_DAT_)(0x48,puVar10[2],0x1fe42b0,0x644,1);
        if (puVar12 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *puVar12 = 0x1f1ea80;
        *(undefined4 *)(puVar12 + 1) = 1;
        *puVar12 = 0x1fe6838;
        puVar12[3] = 0;
        puVar12[4] = 0;
        *(undefined4 *)(puVar12 + 8) = uVar4;
        *(undefined4 *)((longlong)puVar12 + 0x44) = uVar3;
        puVar12[2] = 0;
        *(undefined4 *)((longlong)puVar12 + 0x3c) = 0;
        puVar12[5] = 0;
        puVar12[6] = 0;
        *(byte *)(puVar12 + 7) = *(byte *)(puVar12 + 7) & 0x80;
        *(undefined4 *)((longlong)puVar12 + 0x3c) = 4;
        func_0x(puVar10);
        *(byte *)(puVar10 + 4) = *(byte *)(puVar10 + 4) & 0xfe | 2;
      }
      if ((*(byte *)(_DAT_ + 0x43e) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar9 = *(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
      ;
      if ((lVar9 != 0) && (**(longlong **)(lVar9 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((*(longlong *)(lVar15 + 0xd0) == 0) ||
          (*(int *)(*(longlong *)(lVar15 + 0xd0) + 0x1c) == 0)) &&
         (((*(byte *)(lVar15 + 0x2c) & 1) == 0 && ((*(uint *)(lVar15 + 0x2c) >> 2 & 1) == 0)))) {
        if (*(longlong *)(param_4 + 0x18) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (*(int *)(*(longlong *)(param_1 + 0x98) + 0x304) == 8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        cVar7 = func_0x
                          (puVar10,param_2,lVar15 + 0x68,*(undefined8 *)(lVar15 + 0xd0),0);
        if (cVar7 != '\0') {
          return puVar10;
        }
        puVar12 = puVar10 + 1;
        *(int *)puVar12 = *(int *)puVar12 + -1;
        if (*(int *)puVar12 == 0) {
          (**(code **)*puVar10)(puVar10,1);
        }
        puVar10 = (undefined8 *)
                  (*_DAT_)(0x38,*(undefined8 *)(param_1 + 0x10),0x1fe6808,0x63c,1);
        if (puVar10 != (undefined8 *)0x0) {
          uVar5 = *(undefined8 *)(param_1 + 0x10);
          *puVar10 = 0x1f1ea80;
          *(undefined4 *)(puVar10 + 1) = 1;
          *puVar10 = 0x1fe4388;
          _DAT_ = _DAT_ + 1;
          puVar10[2] = uVar5;
          puVar10[3] = 0;
          *(undefined *)(puVar10 + 4) = 2;
          puVar10[5] = 0;
          puVar10[6] = 0;
          func_0x(puVar10);
          *(byte *)(puVar10 + 4) = *(byte *)(puVar10 + 4) | 2;
          return puVar10;
        }
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(uint *)(lVar8 + 100) >> 0xd & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)(*(longlong *)(param_1 + 0x98) + 0xd6) & 8) == 0) {
        func_0x();
      }
      for (puVar10 = *(undefined8 **)(*(longlong *)(param_1 + 0x98) + 0x140);
          puVar10 != (undefined8 *)0x0; puVar10 = (undefined8 *)*puVar10) {
        uVar14 = 0;
        piVar13 = (int *)((longlong)puVar10 + 0xc);
        do {
          if (*piVar13 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar14 = uVar14 + 1;
          piVar13 = piVar13 + 1;
        } while (uVar14 < 8);
      }
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

