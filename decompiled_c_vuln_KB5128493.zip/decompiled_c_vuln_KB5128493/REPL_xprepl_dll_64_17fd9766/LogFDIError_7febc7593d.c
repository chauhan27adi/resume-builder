
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  longlong lVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong lVar7;
  undefined8 uVar8;
  uint uVar9;
  undefined8 uVar10;
  undefined auStack_1a8 [32];
  undefined8 uStack_188;
  uint uStack_180;
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined4 uStack_168;
  undefined4 uStack_158;
  undefined auStack_154 [12];
  int iStack_148;
  ulonglong uStack_38;
  
  uStack_38 = _DAT_ ^ (ulonglong)auStack_1a8;
  lVar7 = 0;
  uStack_168 = 0;
  switch(*(undefined4 *)((longlong)param_2 + 0x24)) {
  case 0:
    goto code_r0x0010050b;
  case 1:
    uVar8 = *param_2;
    uVar1 = *(undefined4 *)((longlong)param_2 + 0x54);
    uStack_180 = 0;
    lVar4 = 0;
    uStack_188 = 0;
    uVar2 = (*pcRam0000000000108e48)(uVar1,1,uVar8);
    if ((uVar2 == 0) || (lVar4 = (*pcRam0000000000109068)((longlong)(int)(uVar2 * 2)), lVar4 == 0))
    goto code_r0x001003af;
    uStack_188 = lVar4;
    uStack_180 = uVar2;
    iVar3 = (*pcRam0000000000108e48)(uVar1,1,uVar8);
    if (iVar3 == 0) goto code_r0x001003a3;
    *(undefined2 *)(lVar4 + (longlong)(int)(uVar2 - 1) * 2) = 0;
    uVar8 = 0x405;
    lVar5 = (*_DAT_)(_DAT_);
    if (lVar5 == 0) {
code_r0x00100362:
      uStack_188 = CONCAT44(uStack_188._4_4_,0x5b);
      (*_DAT_)(param_1,0xbb9,0x10,0x109c10);
      (*_DAT_)(param_1,3,0);
      (*pcRam0000000000109060)(lVar4);
      goto code_r0x0010050b;
    }
    func_0x(auStack_154,0,0x110);
    uStack_158 = 0x114;
    iVar3 = (*pcRam0000000000108e40)(&uStack_158);
    if ((iVar3 != 0) && (iStack_148 == 2)) {
      uVar8 = (*_DAT_)(_DAT_);
      func_0x(uVar8,0x405,0x90a5,lVar4);
      (*pcRam0000000000109060)(lVar4);
      goto code_r0x0010050b;
    }
    uStack_170 = 0;
    uStack_178 = 0;
    uStack_180 = 0;
    uStack_188 = 0;
    uVar2 = (*pcRam0000000000108e50)(0,0,lVar4,0xffffffff);
    if ((uVar2 != 0) && (uVar9 = uVar2 + 1, uVar2 <= uVar9)) {
      lVar7 = func_0x(uVar9);
      uStack_170 = 0;
      uStack_178 = 0;
      uStack_188 = lVar7;
      uStack_180 = uVar9;
      (*pcRam0000000000108e50)(0,0,lVar4,0xffffffff);
    }
    uVar6 = (*_DAT_)(_DAT_);
    uVar10 = 0x90a5;
code_r0x00100336:
    func_0x(uVar6,uVar8,uVar10,lVar7);
    if (lVar7 != 0) {
      func_0x(lVar7);
      (*pcRam0000000000109060)(lVar4);
      goto code_r0x0010050b;
    }
    goto code_r0x0010041f;
  case 2:
  case 3:
  case 4:
  case 10:
    uVar8 = *param_2;
    uVar1 = *(undefined4 *)((longlong)param_2 + 0x54);
    uStack_180 = 0;
    uStack_188 = 0;
    uVar2 = (*pcRam0000000000108e48)(uVar1,1,uVar8);
    lVar4 = lVar7;
    if ((uVar2 != 0) && (lVar4 = (*pcRam0000000000109068)((longlong)(int)(uVar2 * 2)), lVar4 != 0))
    {
      uStack_188 = lVar4;
      uStack_180 = uVar2;
      iVar3 = (*pcRam0000000000108e48)(uVar1,1,uVar8);
      if (iVar3 != 0) {
        *(undefined2 *)(lVar4 + (longlong)(int)(uVar2 - 1) * 2) = 0;
        uVar8 = 0x406;
        lVar5 = (*_DAT_)(_DAT_);
        if (lVar5 == 0) goto code_r0x00100362;
        func_0x(auStack_154,0,0x110);
        uStack_158 = 0x114;
        iVar3 = (*pcRam0000000000108e40)(&uStack_158);
        if ((iVar3 != 0) && (iStack_148 == 2)) {
          uVar8 = (*_DAT_)(_DAT_);
          func_0x(uVar8,0x406,0x90a6,lVar4);
          (*pcRam0000000000109060)(lVar4);
          goto code_r0x0010050b;
        }
        uStack_170 = 0;
        uStack_178 = 0;
        uStack_180 = 0;
        uStack_188 = 0;
        uVar2 = (*pcRam0000000000108e50)(0,0,lVar4,0xffffffff);
        if ((uVar2 != 0) && (uVar9 = uVar2 + 1, uVar2 <= uVar9)) {
          lVar7 = func_0x(uVar9);
          uStack_170 = 0;
          uStack_178 = 0;
          uStack_188 = lVar7;
          uStack_180 = uVar9;
          (*pcRam0000000000108e50)(0,0,lVar4,0xffffffff);
        }
        uVar6 = (*_DAT_)(_DAT_);
        uVar10 = 0x90a6;
        goto code_r0x00100336;
      }
code_r0x001003a3:
      (*pcRam0000000000109060)(lVar4);
      lVar4 = 0;
    }
code_r0x001003af:
    lVar7 = (*_DAT_)(_DAT_);
    if (lVar7 == 0) {
      uStack_188 = CONCAT44(uStack_188._4_4_,0x5b);
      (*_DAT_)(param_1,0xbb9,0x10,0x109c10);
      (*_DAT_)(param_1,3,0);
    }
    else {
      uVar8 = (*_DAT_)(_DAT_);
      func_0x(uVar8,0x40e,0x90ae);
    }
    if (lVar4 == 0) goto code_r0x0010050b;
code_r0x0010041f:
    (*pcRam0000000000109060)(lVar4);
    goto code_r0x0010050b;
  case 5:
    lVar7 = (*_DAT_)(_DAT_);
    if (lVar7 != 0) {
      uVar8 = (*_DAT_)(_DAT_);
      func_0x(uVar8,0x403,0x90a3);
      goto code_r0x0010050b;
    }
    break;
  case 6:
    goto code_r0x0010050b;
  default:
    lVar7 = (*_DAT_)(_DAT_);
    if (lVar7 != 0) {
      uVar8 = (*_DAT_)(_DAT_);
      func_0x(uVar8,0x407,0x90a7);
      goto code_r0x0010050b;
    }
    break;
  case 8:
  case 0xb:
    lVar7 = (*_DAT_)(_DAT_);
    if (lVar7 != 0) {
      uVar8 = (*_DAT_)(_DAT_);
      func_0x(uVar8,*(undefined4 *)(param_2 + 6));
      goto code_r0x0010050b;
    }
  }
  uStack_188 = CONCAT44(uStack_188._4_4_,0x5b);
  (*_DAT_)(param_1,0xbb9,0x10,0x109c10);
  (*_DAT_)(param_1,3,0);
code_r0x0010050b:
  func_0x(uStack_38 ^ (ulonglong)auStack_1a8);
  return;
}

