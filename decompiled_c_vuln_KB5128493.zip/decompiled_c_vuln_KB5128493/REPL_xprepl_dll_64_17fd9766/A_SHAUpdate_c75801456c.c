
void FUN_(longlong param_1,longlong param_2,uint param_3)

{
  uint uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x58) + param_3;
  uVar4 = *(uint *)(param_1 + 0x58) & 0x3f;
  uVar2 = (ulonglong)param_3;
  *(uint *)(param_1 + 0x58) = uVar1;
  if (uVar1 < param_3) {
    *(int *)(param_1 + 0x54) = *(int *)(param_1 + 0x54) + 1;
  }
  if ((uVar4 != 0) && (0x3f < uVar4 + param_3)) {
    func_0x((ulonglong)uVar4 + param_1,param_2,0x40 - uVar4);
    param_2 = param_2 + (ulonglong)(0x40 - uVar4);
    uVar2 = (ulonglong)((uVar4 + param_3) - 0x40);
    func_0x(param_1 + 0x40,param_1);
    uVar4 = 0;
  }
  uVar1 = (uint)uVar2;
  if (0x3f < uVar1) {
    uVar3 = uVar2 >> 6;
    do {
      func_0x(param_1 + 0x40,param_2);
      param_2 = param_2 + 0x40;
      uVar1 = (int)uVar2 - 0x40;
      uVar2 = (ulonglong)uVar1;
      uVar3 = uVar3 - 1;
    } while (uVar3 != 0);
  }
  if (uVar1 != 0) {
    func_0x((ulonglong)uVar4 + param_1,param_2,uVar1);
  }
  return;
}

