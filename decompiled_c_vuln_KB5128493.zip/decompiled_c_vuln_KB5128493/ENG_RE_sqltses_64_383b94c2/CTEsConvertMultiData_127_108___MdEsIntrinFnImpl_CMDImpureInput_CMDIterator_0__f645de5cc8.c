
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,ushort **param_2,longlong *param_3,longlong *param_4)

{
  short sVar1;
  byte *pbVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined auVar5 [16];
  byte bVar6;
  byte bVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  undefined8 uVar11;
  longlong lVar12;
  ushort *puVar13;
  ulonglong uVar14;
  byte bVar15;
  bool bVar16;
  uint uVar17;
  short *psVar18;
  longlong lVar19;
  ushort uVar20;
  ushort uVar21;
  int iVar22;
  longlong lVar23;
  longlong *plVar24;
  char cVar25;
  ulonglong uVar26;
  byte bVar27;
  uint uVar28;
  uint uVar29;
  undefined8 in_R11;
  uint uVar30;
  longlong *plVar31;
  short sVar32;
  ushort uVar33;
  short asStack_10858 [32640];
  undefined auStack_958 [32];
  ulonglong uStack_938;
  undefined4 uStack_930;
  uint uStack_928;
  uint uStack_920;
  uint uStack_918;
  uint uStack_910;
  longlong *plStack_908;
  longlong *plStack_900;
  longlong *plStack_8f8;
  ushort **ppuStack_8f0;
  uint auStack_8e8 [2];
  char cStack_8e0;
  undefined uStack_8df;
  ushort uStack_8de;
  undefined uStack_8d8;
  undefined uStack_8d7;
  undefined uStack_8d6;
  undefined uStack_8d5;
  undefined4 uStack_8d4;
  undefined4 uStack_8d0;
  undefined4 uStack_8cc;
  undefined4 uStack_8c8;
  undefined4 uStack_8c4;
  longlong lStack_8c0;
  undefined4 uStack_8b8;
  undefined8 uStack_8b0;
  undefined8 uStack_8a8;
  undefined4 uStack_8a0;
  undefined4 uStack_89c;
  undefined8 uStack_898;
  longlong *plStack_890;
  undefined8 uStack_888;
  undefined8 uStack_880;
  undefined8 auStack_878 [2];
  ushort auStack_868 [4];
  short *psStack_860;
  short asStack_858 [1024];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_958;
  pbVar2 = (byte *)param_3[1];
  cVar25 = '\0';
  uVar26 = 0;
  auStack_8e8[0] = (uint)CONCAT71((int7)((ulonglong)in_R11 >> 8),1);
  lVar23 = 0x7fffffffffffffff;
  bVar6 = *pbVar2;
  if ((byte)(bVar6 + 0x10) < 2) {
    bVar15 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x191da0) * 4 + 0x191f33);
    uVar17 = (uint)bVar15;
    bVar27 = *(byte *)(*(longlong *)(*param_1 + 0x20) + 0xc);
    uVar28 = (uint)bVar27;
    if ((bVar6 == 0xf0) || (bVar6 == 0xf1)) {
      bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x191da0) * 4 + 0x191f32);
    }
    else {
      bVar6 = pbVar2[0x12];
    }
  }
  else {
    bVar15 = pbVar2[0x13];
    uVar17 = (uint)bVar15;
    bVar6 = pbVar2[0x12];
    bVar27 = *(byte *)(*(longlong *)(*param_1 + 0x20) + 0xc);
    uVar28 = (uint)bVar27;
  }
  iVar22 = (bVar6 - uVar17) + uVar28;
  pbVar2 = (byte *)param_4[2];
  bVar6 = *pbVar2;
  if ((byte)(bVar6 + 0x10) < 2) {
    bVar7 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x191da0) * 4 + 0x191f32);
  }
  else {
    bVar7 = pbVar2[0x12];
  }
  if (bVar7 < 0x13) {
    if ((byte)(bVar6 + 0x10) < 2) {
      bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x191da0) * 4 + 0x191f32);
    }
    else {
      bVar6 = pbVar2[0x12];
    }
    uVar30 = (uint)bVar6;
  }
  else {
    uVar30 = 0x12;
  }
  plStack_908 = param_3;
  plStack_900 = param_1;
  plStack_8f8 = param_4;
  ppuStack_8f0 = param_2;
  if (bVar27 < bVar15) {
    (**(code **)*_DAT_)(_DAT_,&uStack_898);
    uVar11 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_898);
    iVar8 = func_0x(uVar11);
    uVar29 = auStack_8e8[0] & 0xff;
    if (iVar8 != 0) {
      uVar29 = 0;
    }
    if (((int)(uVar17 - uVar28) < 0x13) && (0 < iVar22 + 1)) {
      uVar26 = *(ulonglong *)((ulonglong)(uVar17 - uVar28) * 8 + 0x1d8230);
      cVar25 = ((int)uVar30 < iVar22 + 1) + '\x05';
      bVar16 = false;
    }
    else {
      bVar16 = false;
      cVar25 = '\x04';
    }
  }
  else {
    uVar29 = auStack_8e8[0];
    if (bVar15 < bVar27) {
      if ((int)(uVar28 - uVar17) < 0x13) {
        uVar26 = *(ulonglong *)((ulonglong)(uVar28 - uVar17) * 8 + 0x1d8230);
        if ((int)uVar30 < iVar22) {
          cVar25 = (0x12 < iVar22) + '\x02';
          bVar16 = false;
        }
        else {
          bVar16 = false;
          cVar25 = '\x01';
        }
      }
      else {
        bVar16 = false;
        uVar29 = 0;
      }
    }
    else {
      cVar25 = '\0';
      if ((int)uVar30 < iVar22) {
        cVar25 = '\a';
      }
      bVar16 = iVar22 <= (int)uVar30;
    }
  }
  plVar31 = plStack_900;
  bVar6 = *(byte *)(*(longlong *)(*plStack_900 + 0x20) + 0xd);
  if (bVar6 < 0x13) {
    lVar23 = *(longlong *)((ulonglong)bVar6 * 8 + 0x1d8190);
  }
  auStack_868[0] = 0;
  if (bVar16) {
    uVar21 = **param_2;
    lVar23 = *plStack_8f8;
    if (0 < (short)uVar21) {
      uVar26 = (ulonglong)uVar21;
      psVar18 = *(short **)(*param_2 + 4);
      lVar3 = *plStack_908;
      do {
        sVar32 = *psVar18;
        psVar18 = psVar18 + 1;
        *(undefined8 *)(lVar23 + (longlong)sVar32 * 8) =
             *(undefined8 *)(lVar3 + (longlong)sVar32 * 8);
        uVar26 = uVar26 - 1;
      } while (uVar26 != 0);
    }
    *param_2 = auStack_868;
  }
  else if ((char)uVar29 != '\0') {
    auStack_868[0] = 0xffff;
    uVar20 = 0;
    uVar21 = 0;
    psStack_860 = (short *)0x0;
    lVar3 = *plStack_8f8;
    switch(cVar25) {
    case '\x01':
      puVar13 = *param_2;
      sVar32 = 0;
      if (0 < (short)*puVar13) {
        lVar23 = *plStack_908;
        uVar21 = uVar20;
        do {
          sVar1 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar32 * 2);
          uVar4 = *(ulonglong *)(lVar23 + (longlong)sVar1 * 8);
          *(ulonglong *)(lVar3 + (longlong)sVar1 * 8) = uVar4 * uVar26;
          if ((uVar4 & 1) != 0) {
            lVar12 = (longlong)(short)uVar21;
            uVar21 = uVar21 + 1;
            asStack_858[lVar12] = sVar1;
          }
          sVar32 = sVar32 + 1;
        } while (sVar32 < (short)*puVar13);
      }
      break;
    case '\x02':
      sVar32 = 0;
      puVar13 = *param_2;
      uVar21 = uVar20;
      if (0 < (short)*puVar13) {
        lVar12 = *plStack_908;
        do {
          sVar1 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar32 * 2);
          uVar4 = *(ulonglong *)(lVar12 + (longlong)sVar1 * 8);
          lVar19 = uVar4 * uVar26;
          if ((lVar19 - lVar23 != 0 && lVar23 <= lVar19) || (bVar16 = false, lVar19 < -lVar23)) {
            bVar16 = true;
          }
          *(longlong *)((longlong)sVar1 * 8 + lVar3) = lVar19;
          if (((uVar4 & 1) != 0) || (bVar16)) {
            lVar19 = (longlong)(short)uVar21;
            uVar21 = uVar21 + 1;
            asStack_858[lVar19] = sVar1;
          }
          sVar32 = sVar32 + 1;
          plVar31 = plStack_900;
        } while (sVar32 < (short)*puVar13);
      }
      break;
    case '\x03':
      puVar13 = *param_2;
      sVar32 = 0;
      param_2 = ppuStack_8f0;
      if (0 < (short)*puVar13) {
        lVar12 = *plStack_908;
        uVar21 = uVar20;
        do {
          sVar1 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar32 * 2);
          uVar4 = *(ulonglong *)(lVar12 + (longlong)sVar1 * 8);
          uVar14 = uVar26 * uVar4;
          bVar6 = 0;
          if ((uVar14 - lVar23 != 0 && lVar23 <= (longlong)uVar14) ||
             (SBORROW8(uVar14,-lVar23) != (longlong)(uVar14 + lVar23) < 0)) {
            bVar6 = 1;
          }
          *(ulonglong *)((longlong)sVar1 * 8 + lVar3) = uVar14;
          if (((uVar4 & 1) != 0) ||
             ((bool)(bVar6 | 1 < (SUB168(SEXT816((longlong)uVar26) * SEXT816((longlong)uVar4),8) <<
                                  1 | uVar14 >> 0x3f) + 1))) {
            lVar19 = (longlong)(short)uVar21;
            uVar21 = uVar21 + 1;
            asStack_858[lVar19] = sVar1;
          }
          sVar32 = sVar32 + 1;
          plVar31 = plStack_900;
          param_2 = ppuStack_8f0;
        } while (sVar32 < (short)*puVar13);
      }
      break;
    case '\x04':
      puVar13 = *param_2;
      sVar32 = 0;
      if (0 < (short)*puVar13) {
        lVar23 = *plStack_908;
        do {
          sVar1 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar32 * 2);
          bVar6 = *(byte *)(lVar23 + (longlong)sVar1 * 8);
          *(undefined8 *)(lVar3 + (longlong)sVar1 * 8) = 0;
          if ((bVar6 & 1) != 0) {
            lVar12 = (longlong)(short)uVar20;
            uVar20 = uVar20 + 1;
            asStack_858[lVar12] = sVar1;
          }
          sVar32 = sVar32 + 1;
          uVar21 = uVar20;
        } while (sVar32 < (short)*puVar13);
      }
      break;
    case '\x05':
      puVar13 = *param_2;
      sVar32 = 0;
      if (0 < (short)*puVar13) {
        lVar23 = *plStack_908;
        uVar21 = uVar20;
        do {
          sVar1 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar32 * 2);
          uVar4 = *(ulonglong *)(lVar23 + (longlong)sVar1 * 8);
          uVar14 = (longlong)uVar4 / (longlong)uVar26;
          *(ulonglong *)((longlong)sVar1 * 8 + lVar3) =
               (uVar14 >> 0x3f ^ 1) + uVar14 & 0xfffffffffffffffe;
          if ((uVar4 & 1) != 0) {
            lVar12 = (longlong)(short)uVar21;
            uVar21 = uVar21 + 1;
            asStack_858[lVar12] = sVar1;
          }
          sVar32 = sVar32 + 1;
        } while (sVar32 < (short)*puVar13);
      }
      break;
    case '\x06':
      puVar13 = *param_2;
      sVar32 = 0;
      uVar21 = uVar20;
      if (0 < (short)*puVar13) {
        lVar12 = *plStack_908;
        do {
          sVar1 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar32 * 2);
          uVar4 = *(ulonglong *)(lVar12 + (longlong)sVar1 * 8);
          if ((longlong)uVar4 < 1) {
            if (uVar4 == 0x8000000000000000) {
              auVar5._8_8_ = 0;
              auVar5._0_8_ = uVar26;
              lVar19 = SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x8000000000000000)) / auVar5,0);
            }
            else {
              lVar19 = -((longlong)uVar4 / (longlong)uVar26);
            }
            uVar14 = -(lVar19 + 1U & 0xfffffffffffffffe);
          }
          else {
            uVar14 = (longlong)uVar4 / (longlong)uVar26 + 1U & 0xfffffffffffffffe;
          }
          if ((lVar23 < (longlong)uVar14) || (bVar16 = false, (longlong)uVar14 < -lVar23)) {
            bVar16 = true;
          }
          *(ulonglong *)((longlong)sVar1 * 8 + lVar3) = uVar14;
          if (((uVar4 & 1) != 0) || (bVar16)) {
            lVar19 = (longlong)(short)uVar21;
            uVar21 = uVar21 + 1;
            asStack_858[lVar19] = sVar1;
          }
          sVar32 = sVar32 + 1;
          plVar31 = plStack_900;
          param_2 = ppuStack_8f0;
        } while (sVar32 < (short)*puVar13);
      }
      break;
    case '\a':
      puVar13 = *param_2;
      sVar32 = 0;
      uVar21 = uVar20;
      if (0 < (short)*puVar13) {
        lVar12 = *plStack_908;
        do {
          sVar1 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar32 * 2);
          uVar26 = *(ulonglong *)(lVar12 + (longlong)sVar1 * 8);
          if ((lVar23 < (longlong)uVar26) ||
             (bVar16 = false, SBORROW8(uVar26,-lVar23) != (longlong)(uVar26 + lVar23) < 0)) {
            bVar16 = true;
          }
          *(ulonglong *)((longlong)sVar1 * 8 + lVar3) = uVar26;
          if (((uVar26 & 1) != 0) || (bVar16)) {
            lVar19 = (longlong)(short)uVar21;
            uVar21 = uVar21 + 1;
            asStack_858[lVar19] = sVar1;
          }
          sVar32 = sVar32 + 1;
          plVar31 = plStack_900;
        } while (sVar32 < (short)*puVar13);
      }
      break;
    default:
      puVar13 = *param_2;
      uVar21 = uVar20;
      uVar33 = uVar20;
      if (0 < (short)*puVar13) {
        do {
          sVar32 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)(short)uVar33 * 2);
          lVar23 = (longlong)sVar32 * 8;
          uVar26 = *(ulonglong *)(lVar23 + *plStack_908);
          uStack_938 = 0x1db208;
          (*_DAT_)(1,0x1da900,0x1daa78,0xdd);
          *(longlong *)(lVar23 + lVar3) = lStack_8c0;
          uVar21 = uVar20;
          if ((uVar26 & 1) != 0) {
            uVar21 = uVar20 + 1;
            asStack_858[(short)uVar20] = sVar32;
          }
          puVar13 = *param_2;
          uVar33 = uVar33 + 1;
          plVar31 = plStack_900;
          uVar20 = uVar21;
        } while ((short)uVar33 < (short)*puVar13);
      }
    }
    *param_2 = auStack_868;
    auStack_868[0] = uVar21;
  }
  puVar13 = *param_2;
  psStack_860 = asStack_858;
  if (0 < (short)*puVar13) {
    lVar23 = *plStack_8f8;
    uStack_8d8 = 0;
    uStack_8d7 = 0;
    uStack_8d6 = 0;
    uStack_8d5 = 0;
    uStack_8d4 = 0;
    uStack_8d0 = 0;
    uStack_8cc = 0;
    sVar32 = 0;
    uStack_8de = 0;
    uStack_8c8 = 0;
    plVar24 = plStack_8f8;
    lStack_8c0 = lVar23;
    do {
      lVar3 = (longlong)*(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar32 * 2) * 8;
      uVar26 = *(ulonglong *)(lVar3 + *plStack_908);
      lVar12 = *plVar31;
      uStack_8df = 0x7f;
      cStack_8e0 = '\0';
      if ((uVar26 & 1) == 0) {
        lVar19 = (longlong)uVar26 >> 1;
      }
      else {
        (**(code **)**(undefined8 **)(lVar12 + 0x80))
                  (*(undefined8 **)(lVar12 + 0x80),uVar26,&plStack_890,auStack_8e8);
        lVar19 = *plStack_890;
        lVar12 = *plVar31;
      }
      uStack_8d8 = (undefined)lVar19;
      uStack_8d7 = (undefined)((ulonglong)lVar19 >> 8);
      uStack_8d6 = (undefined)((ulonglong)lVar19 >> 0x10);
      uStack_8d5 = (undefined)((ulonglong)lVar19 >> 0x18);
      uStack_8d4 = (undefined4)((ulonglong)lVar19 >> 0x20);
      if (cStack_8e0 == '\0') {
        uStack_8b8 = 0x6c00;
        uStack_8b0 = 0;
        uStack_8a8 = 0;
        uStack_8a0 = 0;
        iVar22 = func_0x(&uStack_8b0);
        cStack_8e0 = (char)uStack_8b8;
        uStack_8df = (undefined)((uint)uStack_8b8 >> 8);
        uStack_8d8 = (undefined)uStack_8b0;
        uStack_8d7 = (undefined)((ulonglong)uStack_8b0 >> 8);
        uStack_8d6 = (undefined)((ulonglong)uStack_8b0 >> 0x10);
        uStack_8d5 = (undefined)((ulonglong)uStack_8b0 >> 0x18);
        uStack_8d4 = (undefined4)((ulonglong)uStack_8b0 >> 0x20);
        uStack_8d0 = (undefined4)uStack_8a8;
        uStack_8cc = uStack_8a8._4_4_;
        uStack_8c8 = uStack_8a0;
        uStack_8c4 = uStack_89c;
        uStack_8de = (ushort)((uint)uStack_8b8 >> 0x10) & 0xfffe;
        plVar31 = plStack_900;
        if (iVar22 != 0) {
          (**(code **)*_DAT_)(_DAT_,&uStack_888);
          uVar11 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_888);
          iVar8 = func_0x(uVar11,0x800);
          (**(code **)*_DAT_)(_DAT_,&uStack_880);
          uVar11 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_880);
          iVar9 = func_0x(uVar11,0x10000000);
          (**(code **)*_DAT_)(_DAT_,auStack_878);
          uVar11 = (**(code **)(*_DAT_ + 8))(_DAT_,auStack_878[0]);
          iVar10 = func_0x(uVar11,0x1000);
          uStack_910 = (uint)(iVar8 != 0);
          uStack_918 = (uint)(iVar9 != 0);
          uStack_920 = (uint)(iVar10 != 0);
          uStack_928 = *(byte *)(*(longlong *)(*plStack_900 + 0x20) + 0x11) & 0x80;
          uStack_930 = 0;
          uStack_938 = uStack_938 & 0xffffffff00000000;
          func_0x(iVar22,&cStack_8e0,0x6c,0x7f);
          lVar23 = lStack_8c0;
          plVar24 = plStack_8f8;
          plVar31 = plStack_900;
        }
      }
      else {
        uStack_8d8 = 5;
        uStack_8d4 = 0;
        uStack_8d0 = 0;
        uStack_8cc = 0;
        uStack_8c8 = 0;
        uStack_8d5 = 1;
        uStack_8d7 = *(undefined *)(*(longlong *)(lVar12 + 0x20) + 0xd);
        uStack_8d6 = *(undefined *)(*(longlong *)(lVar12 + 0x20) + 0xc);
      }
      if (cStack_8e0 == '\x03') {
        ppuStack_8f0 = (ushort **)0x1;
      }
      else {
        uStack_938 = uStack_938 & 0xffffffff00000000;
        func_0x
                  (&cStack_8e0,&ppuStack_8f0,plVar24[2],*(undefined8 *)(*plVar31 + 0x80));
      }
      *(ushort ***)(lVar23 + lVar3) = ppuStack_8f0;
      sVar32 = sVar32 + 1;
      puVar13 = *param_2;
    } while (sVar32 < (short)*puVar13);
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_958);
  return;
}

