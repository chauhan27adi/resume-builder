
undefined8
FUN_(longlong param_1,longlong param_2,uint param_3,ulonglong *param_4,ulonglong *param_5,
            ushort **param_6,short *param_7,int param_8,int param_9,uint *param_10,uint *param_11,
            uint *param_12,int *param_13,int param_14,longlong param_15,undefined *param_16,
            undefined *param_17,ulonglong *param_18,ulonglong *param_19,longlong *param_20,
            ulonglong *param_21,longlong *param_22)

{
  ushort *puVar1;
  ushort *puVar2;
  ushort uVar3;
  int iVar4;
  ushort *puVar5;
  undefined *puVar6;
  bool bVar7;
  undefined uVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  ushort uVar14;
  ulonglong uVar15;
  short sVar16;
  int iVar17;
  uint uVar18;
  undefined4 uStackX_20;
  undefined auStack_38 [4];
  undefined uStack_34;
  byte bStack_33;
  byte bStack_32;
  
  uVar15 = *param_4;
  switch(uVar15 >> 0x28 & 0xff) {
  case 1:
    if (param_8 == 0) {
      if ((*param_18 < param_15 + 2U) && (*(byte *)(*param_18 - 2) < 0x15)) {
        bVar7 = true;
      }
      else {
        bVar7 = false;
      }
      if (((param_3 & 2) == 0) || (!bVar7)) {
        puVar6 = (undefined *)*param_19;
        if (puVar6 <= param_16) {
          *puVar6 = (char)uVar15;
          *param_19 = (ulonglong)(puVar6 + 1);
          return 0;
        }
        uVar11 = ((uint)uVar15 & 0xff) + (uint)(byte)puVar6[-1];
        if (0xff < uVar11) {
          uVar11 = 0xff;
        }
        puVar6[-1] = (char)uVar11;
        return 0;
      }
    }
    break;
  case 2:
    puVar1 = (ushort *)((longlong)param_6 + 0xe);
    uVar15 = (uVar15 >> 8 & 0xff) << 8 | uVar15 >> 0x20 & 0xff;
    uVar14 = *(ushort *)(*(longlong *)(param_1 + 0xa8) + uVar15 * 4);
    uVar3 = *(ushort *)(*(longlong *)(param_1 + 0xa8) + 2 + uVar15 * 4);
    puVar2 = (ushort *)((longlong)param_6 + 0xc);
    if (*param_6 == puVar1) {
      puVar5 = param_6[2];
      param_6[2] = (ushort *)0x0;
      *param_6 = puVar5;
      *puVar2 = uVar14;
      *puVar1 = uVar3;
    }
    else {
      *param_6 = *param_6 + 1;
      *puVar2 = uVar14;
      *puVar1 = uVar3;
      if (param_6[2] != (ushort *)0x0) goto code_r0x00100158;
    }
    param_6[2] = *param_6;
code_r0x00100158:
    *param_6 = puVar2;
    *(int *)(param_6 + 1) = *(int *)(param_6 + 1) + 1;
    uVar11 = *(uint *)(*(longlong *)(param_2 + 8) + (ulonglong)uVar14 * 4);
    *param_4 = ((ulonglong)uVar11 & 0xffff) << 0x20 | (ulonglong)(uVar11 >> 0x10);
    return 1;
  case 3:
    uStackX_20 = 0;
    func_0x(param_4,param_5,&uStackX_20);
    if (param_8 != 0) {
      return 1;
    }
    if (uStackX_20 == 0) {
      return 1;
    }
    puVar6 = (undefined *)*param_20;
    *puVar6 = (char)uStackX_20;
    puVar6[param_14] = uStackX_20._1_1_;
    if ((param_3 >> 0x10 & 1) == 0) {
      puVar6[param_14 * 2] = uStackX_20._2_1_;
    }
    if ((param_3 >> 0x11 & 1) == 0) {
      puVar6[param_14 * 3] = uStackX_20._3_1_;
    }
    *param_20 = (longlong)(puVar6 + 1);
    return 1;
  case 4:
    *param_5 = 0;
    if ((0x115f < **param_6) ||
       (iVar9 = func_0x(param_1,param_2,param_6,&uStackX_20,&uStack_34,3,auStack_38),
       iVar9 < 1)) {
      uVar15 = *param_4;
      *param_4 = (uVar15 & 0xff) << 0x20 |
                 (uVar15 >> 0x20 & 0xff) << 0x28 | uVar15 & 0xffff0000ffffff02 | 2;
      return 1;
    }
    iVar13 = 0;
    uVar8 = (undefined)((ushort)(undefined2)uStackX_20 >> 8);
    if (param_8 == 0) {
      puVar6 = (undefined *)*param_18;
      *puVar6 = uVar8;
      puVar6[1] = (char)(undefined2)uStackX_20;
      puVar6[2] = 0xff;
      puVar6[3] = uStack_34;
      *param_18 = (ulonglong)(puVar6 + 4);
      goto code_r0x001004cc;
    }
    iVar4 = *param_13;
    *(undefined *)((longlong)iVar4 + (longlong)param_12) = uVar8;
    *(char *)((longlong)iVar4 + 1 + (longlong)param_12) = (char)(undefined2)uStackX_20;
    iVar17 = iVar4 + 2;
    if (iVar4 + 2 == 4) {
      uVar11 = *param_12;
      uVar12 = *param_10;
      uVar14 = (ushort)uVar11;
      sVar16 = (short)(uVar11 >> 0x10);
      if (param_9 == 0) {
        uVar18 = uVar12 << 3 | uVar12 >> 0x1d;
        uVar10 = uVar18 ^ uVar11;
        *param_10 = uVar10;
        iVar17 = iVar13;
        if (sVar16 == 0x207) {
          if (uVar14 != 0x207) {
            *param_11 = ((uVar11 & 0xff ^ uVar18) << 3 | (uVar12 << 3) >> 0x1d) ^
                        (uVar11 & 0xffff) >> 8;
          }
        }
        else {
          *param_11 = uVar10;
        }
      }
      else {
        iVar13 = uVar12 * 0x820 + (uVar12 >> 2);
        uVar10 = iVar13 + uVar11 ^ uVar12;
        iVar17 = 0;
        *param_10 = uVar10;
        if (sVar16 == 0x207) {
          if (uVar14 != 0x207) {
            uVar12 = (uVar11 & 0xff) + iVar13 ^ uVar12;
            *param_11 = uVar12 * 0x820 + (uVar12 >> 2) + (uint)(uVar14 >> 8) ^ uVar12;
          }
        }
        else {
          *param_11 = uVar10;
        }
      }
    }
    *(undefined *)((longlong)iVar17 + (longlong)param_12) = 0xff;
    *(undefined *)((longlong)iVar17 + 1 + (longlong)param_12) = uStack_34;
    *param_13 = iVar17 + 2;
    if (iVar17 + 2 == 4) {
      uVar11 = *param_12;
      uVar12 = *param_10;
      *param_13 = 0;
      uVar14 = (ushort)uVar11;
      sVar16 = (short)(uVar11 >> 0x10);
      if (param_9 == 0) {
        uVar18 = uVar12 << 3 | uVar12 >> 0x1d;
        uVar10 = uVar18 ^ uVar11;
        *param_10 = uVar10;
        if (sVar16 == 0x207) {
          if (uVar14 != 0x207) {
            uVar12 = ((uVar11 & 0xff ^ uVar18) << 3 | (uVar12 << 3) >> 0x1d) ^
                     (uVar11 & 0xffff) >> 8;
code_r0x0010047f:
            *param_11 = uVar12;
          }
        }
        else {
          *param_11 = uVar10;
        }
      }
      else {
        iVar13 = uVar12 * 0x820 + (uVar12 >> 2);
        uVar10 = iVar13 + uVar11 ^ uVar12;
        *param_10 = uVar10;
        if (sVar16 == 0x207) {
          if (uVar14 != 0x207) {
            uVar12 = (uVar11 & 0xff) + iVar13 ^ uVar12;
            uVar12 = uVar12 * 0x820 + (uVar12 >> 2) + (uint)(uVar14 >> 8) ^ uVar12;
            goto code_r0x0010047f;
          }
        }
        else {
          *param_11 = uVar10;
        }
      }
    }
    *param_7 = *param_7 + 2;
code_r0x001004cc:
    *param_4 = ((ulonglong)bStack_33 << 0x10 | (ulonglong)bStack_32) << 0x10 | 0xff00ff000202;
    if (1 < iVar9) {
      if (*param_6 != (ushort *)((longlong)param_6 + 0xe)) {
        *param_6 = *param_6 + (iVar9 - 1U);
        *(uint *)(param_6 + 1) = *(int *)(param_6 + 1) - (iVar9 - 1U);
        return 1;
      }
      *param_6 = param_6[2];
      *(int *)(param_6 + 1) = *(int *)(param_6 + 1) + -1;
      param_6[2] = (ushort *)0x0;
    }
    return 1;
  case 5:
    uVar15 = ((uVar15 >> 0x20 & 0xff) << 8 | uVar15 & 0xff) << 0x10 | 0xfdff00000202;
    *param_4 = uVar15;
    *param_5 = uVar15;
    return 1;
  case 6:
    if (param_8 == 0) {
      puVar6 = (undefined *)*param_22;
      uVar14 = (short)(*param_18 << 2) + (short)param_15 * -4 | 0x8003;
      *puVar6 = (char)(uVar14 >> 8);
      puVar6[1] = (char)uVar14;
      puVar6[2] = (char)(*param_4 >> 0x28);
      puVar6[3] = (char)(*param_4 >> 0x20);
      *param_22 = (longlong)(puVar6 + 4);
      return 0;
    }
    break;
  case 0x15:
    if (param_8 == 0) {
      puVar6 = (undefined *)*param_21;
      uVar8 = (undefined)(uVar15 >> 0x20);
      if (param_17 < puVar6) {
        puVar6[-1] = uVar8;
        return 0;
      }
      *puVar6 = uVar8;
      *param_21 = (ulonglong)(puVar6 + 1);
    }
  }
  return 0;
}

