
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,char *param_2,ulonglong **param_3,ulonglong **param_4)

{
  ulonglong *puVar1;
  ulonglong *puVar2;
  undefined auVar3 [16];
  bool bVar4;
  bool bVar5;
  byte bVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  longlong lVar13;
  byte bVar14;
  uint uVar15;
  ulonglong uVar16;
  byte bVar17;
  uint uVar18;
  short sVar19;
  int iVar20;
  longlong *plVar21;
  short sVar22;
  longlong lVar23;
  ulonglong **ppuVar24;
  byte bVar25;
  ulonglong uVar26;
  undefined8 in_R11;
  short sVar27;
  uint uVar28;
  char cVar29;
  undefined2 auStack_10858 [32656];
  undefined auStack_938 [32];
  ulonglong uStack_918;
  undefined4 uStack_910;
  uint uStack_908;
  uint uStack_900;
  uint uStack_8f8;
  uint uStack_8f0;
  undefined8 uStack_8e8;
  ulonglong **ppuStack_8e0;
  undefined8 uStack_8d8;
  longlong *plStack_8d0;
  char cStack_8c8;
  undefined uStack_8c7;
  ushort uStack_8c6;
  undefined4 uStack_8c0;
  undefined4 uStack_8bc;
  undefined4 uStack_8b8;
  undefined4 uStack_8b4;
  undefined4 uStack_8b0;
  undefined4 uStack_8ac;
  ulonglong **ppuStack_8a8;
  undefined4 uStack_8a0;
  undefined8 uStack_898;
  undefined8 uStack_890;
  undefined4 uStack_888;
  undefined4 uStack_884;
  undefined8 uStack_880;
  undefined8 uStack_878;
  undefined8 uStack_870;
  short sStack_868;
  undefined2 *puStack_860;
  undefined2 auStack_858 [1024];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_938;
  uVar26 = CONCAT71((int7)((ulonglong)in_R11 >> 8),1);
  uStack_8d8 = CONCAT44(uStack_8d8._4_4_,(int)uVar26);
  cVar29 = '\0';
  uVar11 = 0;
  lVar23 = 0x7fffffffffffffff;
  bVar14 = *(byte *)param_3[1];
  if ((byte)(bVar14 + 0x10) < 2) {
    bVar17 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar14 + 0x195db0) * 4 + 0x195f43);
    uVar18 = (uint)bVar17;
    bVar25 = *(byte *)(*(longlong *)(*param_1 + 0x20) + 0xc);
    uVar28 = (uint)bVar25;
    if ((bVar14 == 0xf0) || (bVar14 == 0xf1)) {
      bVar14 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar14 + 0x195db0) * 4 + 0x195f42);
    }
    else {
      bVar14 = *(byte *)((longlong)param_3[1] + 0x12);
    }
  }
  else {
    bVar17 = *(byte *)((longlong)param_3[1] + 0x13);
    uVar18 = (uint)bVar17;
    bVar25 = *(byte *)(*(longlong *)(*param_1 + 0x20) + 0xc);
    bVar14 = *(byte *)((longlong)param_3[1] + 0x12);
    uVar28 = (uint)bVar25;
  }
  iVar20 = (bVar14 - uVar18) + uVar28;
  puVar1 = param_4[2];
  bVar14 = *(byte *)puVar1;
  if ((byte)(bVar14 + 0x10) < 2) {
    bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar14 + 0x195db0) * 4 + 0x195f42);
  }
  else {
    bVar6 = *(byte *)((longlong)puVar1 + 0x12);
  }
  if (bVar6 < 0x13) {
    if ((byte)(bVar14 + 0x10) < 2) {
      bVar14 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar14 + 0x195db0) * 4 + 0x195f42);
    }
    else {
      bVar14 = *(byte *)((longlong)puVar1 + 0x12);
    }
    uVar15 = (uint)bVar14;
  }
  else {
    uVar15 = 0x12;
  }
  uStack_8e8 = CONCAT44((int)((ulonglong)puVar1 >> 0x20),uVar15);
  ppuStack_8e0 = param_4;
  plStack_8d0 = param_1;
  ppuStack_8a8 = param_3;
  if (bVar25 < bVar17) {
    (**(code **)*_DAT_)(_DAT_,&uStack_880);
    uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_880);
    iVar7 = func_0x(uVar10);
    uVar26 = (ulonglong)((uint)uStack_8d8 & 0xff);
    if (iVar7 != 0) {
      uVar26 = uVar11;
    }
    if (((int)(uVar18 - uVar28) < 0x13) && (0 < iVar20 + 1)) {
      uVar11 = *(ulonglong *)((ulonglong)(uVar18 - uVar28) * 8 + 0x1dc240);
      cVar29 = ((int)uStack_8e8 < iVar20 + 1) + '\x05';
      bVar4 = false;
      goto LAB_;
    }
    cVar29 = '\x04';
  }
  else if (bVar17 < bVar25) {
    if ((int)(uVar28 - uVar18) < 0x13) {
      uVar11 = *(ulonglong *)((ulonglong)(uVar28 - uVar18) * 8 + 0x1dc240);
      if ((int)uVar15 < iVar20) {
        cVar29 = (0x12 < iVar20) + '\x02';
        bVar4 = false;
        goto LAB_;
      }
      cVar29 = '\x01';
    }
    else {
      uVar26 = 0;
      cVar29 = '\0';
    }
  }
  else {
    if (iVar20 <= (int)uVar15) {
      bVar4 = true;
      goto LAB_;
    }
    cVar29 = '\a';
  }
  bVar4 = false;
LAB_:
  ppuVar24 = ppuStack_8a8;
  bVar5 = false;
  bVar14 = *(byte *)(*(longlong *)(*plStack_8d0 + 0x20) + 0xd);
  if (bVar14 < 0x13) {
    lVar23 = *(longlong *)((ulonglong)bVar14 * 8 + 0x1dc1a0);
  }
  sVar27 = 0;
  sStack_868 = 0;
  puStack_860 = auStack_858;
  if (bVar4) {
    uVar11 = (ulonglong)(*param_2 == '\0');
    puVar1 = *ppuStack_8e0;
    if (*param_2 == '\0') {
      uVar26 = **param_3;
      do {
        *puVar1 = uVar26;
        uVar11 = uVar11 - 1;
      } while (uVar11 != 0);
    }
    *param_2 = '\x01';
  }
  else {
    if ((char)uVar26 == '\0') {
      cVar29 = *param_2;
    }
    else {
      puStack_860 = (undefined2 *)0x0;
      sStack_868 = 0xffff;
      sVar19 = 0;
      puVar1 = *ppuStack_8e0;
      switch(cVar29) {
      case '\x01':
        uVar26 = (ulonglong)(*param_2 == '\0');
        if (*param_2 == '\0') {
          puVar2 = *param_3;
          sVar19 = sVar27;
          do {
            uVar12 = *puVar2;
            if ((uVar12 & 1) != 0) {
              lVar23 = (longlong)sVar19;
              sVar19 = sVar19 + 1;
              auStack_858[lVar23] = 0;
            }
            uVar26 = uVar26 - 1;
          } while (uVar26 != 0);
          *puVar1 = uVar12 * uVar11;
        }
        break;
      case '\x02':
        uVar26 = (ulonglong)(*param_2 == '\0');
        if (*param_2 == '\0') {
          puVar2 = *param_3;
          sVar19 = sVar27;
          do {
            uVar12 = *puVar2 * uVar11;
            if ((uVar12 - lVar23 != 0 && lVar23 <= (longlong)uVar12) ||
               (bVar4 = bVar5, (longlong)uVar12 < -lVar23)) {
              bVar4 = true;
            }
            if (((*puVar2 & 1) != 0) || (bVar4)) {
              lVar13 = (longlong)sVar19;
              sVar19 = sVar19 + 1;
              auStack_858[lVar13] = 0;
            }
            uVar26 = uVar26 - 1;
          } while (uVar26 != 0);
          *puVar1 = uVar12;
        }
        break;
      case '\x03':
        uVar26 = (ulonglong)(*param_2 == '\0');
        if (*param_2 == '\0') {
          puVar2 = *param_3;
          sVar19 = sVar27;
          do {
            uVar12 = *puVar2;
            uVar16 = uVar11 * uVar12;
            if ((uVar16 - lVar23 != 0 && lVar23 <= (longlong)uVar16) ||
               (bVar4 = bVar5, (longlong)uVar16 < -lVar23)) {
              bVar4 = true;
            }
            if (((uVar12 & 1) != 0) ||
               ((bool)(bVar4 | 1 < (SUB168(SEXT816((longlong)uVar11) * SEXT816((longlong)uVar12),8)
                                    << 1 | uVar16 >> 0x3f) + 1))) {
              lVar13 = (longlong)sVar19;
              sVar19 = sVar19 + 1;
              auStack_858[lVar13] = 0;
            }
            uVar26 = uVar26 - 1;
          } while (uVar26 != 0);
          *puVar1 = uVar16;
        }
        break;
      case '\x04':
        uVar11 = (ulonglong)(*param_2 == '\0');
        if (*param_2 == '\0') {
          puVar2 = *param_3;
          sVar19 = sVar27;
          do {
            if ((*(byte *)puVar2 & 1) != 0) {
              lVar23 = (longlong)sVar19;
              sVar19 = sVar19 + 1;
              auStack_858[lVar23] = 0;
            }
            uVar11 = uVar11 - 1;
          } while (uVar11 != 0);
          *puVar1 = 0;
        }
        break;
      case '\x05':
        uVar26 = (ulonglong)(*param_2 == '\0');
        sVar19 = sVar27;
        if (*param_2 == '\0') {
          puVar2 = *param_3;
          do {
            uVar12 = (longlong)*puVar2 / (longlong)uVar11;
            if ((*puVar2 & 1) != 0) {
              lVar23 = (longlong)sVar19;
              sVar19 = sVar19 + 1;
              auStack_858[lVar23] = 0;
            }
            uVar26 = uVar26 - 1;
          } while (uVar26 != 0);
          *puVar1 = (uVar12 >> 0x3f ^ 1) + uVar12 & 0xfffffffffffffffe;
        }
        break;
      case '\x06':
        uVar26 = (ulonglong)(*param_2 == '\0');
        sVar19 = sVar27;
        if (*param_2 == '\0') {
          puVar2 = *param_3;
          do {
            uVar12 = *puVar2;
            if ((longlong)uVar12 < 1) {
              if (uVar12 == 0x8000000000000000) {
                auVar3._8_8_ = 0;
                auVar3._0_8_ = uVar11;
                lVar13 = SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x8000000000000000)) / auVar3,0);
              }
              else {
                lVar13 = -((longlong)uVar12 / (longlong)uVar11);
              }
              uVar16 = -(lVar13 + 1U & 0xfffffffffffffffe);
            }
            else {
              uVar16 = (longlong)uVar12 / (longlong)uVar11 + 1U & 0xfffffffffffffffe;
            }
            if ((lVar23 < (longlong)uVar16) || (bVar4 = bVar5, (longlong)uVar16 < -lVar23)) {
              bVar4 = true;
            }
            if (((uVar12 & 1) != 0) || (bVar4)) {
              lVar13 = (longlong)sVar27;
              sVar27 = sVar27 + 1;
              auStack_858[lVar13] = 0;
            }
            uVar26 = uVar26 - 1;
          } while (uVar26 != 0);
          *puVar1 = uVar16;
          sVar19 = sVar27;
        }
        break;
      case '\a':
        uVar11 = (ulonglong)(*param_2 == '\0');
        sVar19 = sVar27;
        if (*param_2 == '\0') {
          puVar2 = *param_3;
          do {
            uVar26 = *puVar2;
            if ((lVar23 < (longlong)uVar26) ||
               (bVar4 = bVar5, SBORROW8(uVar26,-lVar23) != (longlong)(uVar26 + lVar23) < 0)) {
              bVar4 = true;
            }
            if (((uVar26 & 1) != 0) || (bVar4)) {
              lVar13 = (longlong)sVar27;
              sVar27 = sVar27 + 1;
              auStack_858[lVar13] = 0;
            }
            uVar11 = uVar11 - 1;
          } while (uVar11 != 0);
          *puVar1 = uVar26;
          sVar19 = sVar27;
        }
        break;
      default:
        sVar22 = 0;
        sVar19 = sVar27;
        if (*param_2 == '\0') {
          do {
            uVar11 = **param_3;
            uStack_918 = 0x1df218;
            (*_DAT_)(1,0x1de910,0x1dea88,0xdd);
            *puVar1 = (ulonglong)ppuVar24;
            sVar19 = sVar27;
            if ((uVar11 & 1) != 0) {
              sVar19 = sVar27 + 1;
              auStack_858[sVar27] = 0;
            }
            sVar22 = sVar22 + 1;
            sVar27 = sVar19;
          } while (sVar22 < (short)(ushort)(*param_2 == '\0'));
        }
      }
      cVar29 = sVar19 == 0;
      *param_2 = cVar29;
      sStack_868 = sVar19;
    }
    puStack_860 = auStack_858;
    sVar27 = 0;
    if (cVar29 == '\0') {
      cStack_8c8 = '\0';
      uStack_8c7 = 0x38;
      uStack_8c6 = 0;
      uStack_8c0 = 0;
      uStack_8bc = 0;
      uStack_8b8 = 0;
      uStack_8b4 = 0;
      uStack_8b0 = 0;
      puVar1 = *ppuStack_8e0;
      plVar21 = plStack_8d0;
      ppuVar24 = ppuStack_8e0;
      do {
        if (**param_3 == 1) {
          *puVar1 = 1;
        }
        else {
          cStack_8c8 = '\0';
          uStack_8c7 = 0x38;
          lVar23 = (longlong)**param_3 >> 1;
          uStack_8c0 = (undefined4)lVar23;
          uStack_8a0 = 0x6c00;
          uStack_898 = 0;
          uStack_890 = 0;
          uStack_888 = 0;
          iVar20 = func_0x
                             (&uStack_898,lVar23,
                              *(undefined *)(*(longlong *)(*plVar21 + 0x20) + 0xd),
                              *(undefined *)(*(longlong *)(*plVar21 + 0x20) + 0xc));
          cStack_8c8 = (char)uStack_8a0;
          uStack_8c7 = (undefined)((uint)uStack_8a0 >> 8);
          uStack_8c0 = (undefined4)uStack_898;
          uStack_8bc = (undefined4)((ulonglong)uStack_898 >> 0x20);
          uStack_8b8 = (undefined4)uStack_890;
          uStack_8b4 = uStack_890._4_4_;
          uStack_8b0 = uStack_888;
          uStack_8ac = uStack_884;
          uStack_8c6 = (ushort)((uint)uStack_8a0 >> 0x10) & 0xfffe;
          if (iVar20 != 0) {
            (**(code **)*_DAT_)(_DAT_,&uStack_8e8);
            uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_8e8);
            iVar7 = func_0x(uVar10,0x800);
            (**(code **)*_DAT_)(_DAT_,&uStack_878);
            uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_878);
            iVar8 = func_0x(uVar10,0x10000000);
            (**(code **)*_DAT_)(_DAT_,&uStack_870);
            uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_870);
            iVar9 = func_0x(uVar10,0x1000);
            uStack_8f0 = (uint)(iVar7 != 0);
            uStack_8f8 = (uint)(iVar8 != 0);
            uStack_900 = (uint)(iVar9 != 0);
            uStack_908 = *(byte *)(*(longlong *)(*plStack_8d0 + 0x20) + 0x11) & 0x80;
            uStack_910 = 0;
            uStack_918 = uStack_918 & 0xffffffff00000000;
            func_0x(iVar20,&cStack_8c8,0x6c,0x38);
            plVar21 = plStack_8d0;
            ppuVar24 = ppuStack_8e0;
          }
          if (cStack_8c8 == '\x03') {
            uStack_8d8 = 1;
          }
          else {
            uStack_918 = uStack_918 & 0xffffffff00000000;
            func_0x
                      (&cStack_8c8,&uStack_8d8,ppuVar24[2],*(undefined8 *)(*plVar21 + 0x80));
          }
          *puVar1 = uStack_8d8;
          param_3 = ppuStack_8a8;
        }
        sVar27 = sVar27 + 1;
      } while (sVar27 < (short)(ushort)(*param_2 == '\0'));
    }
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_938);
  return;
}

