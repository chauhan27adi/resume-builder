
undefined8 FUN_(undefined8 param_1,int *param_2,longlong param_3,ulonglong *param_4)

{
  byte bVar1;
  ushort uVar2;
  longlong **pplVar3;
  longlong *plVar4;
  bool bVar5;
  undefined8 *puVar6;
  int iVar7;
  ulonglong uVar8;
  int *piVar9;
  uint uVar10;
  undefined8 uStackX_8;
  
  uStackX_8 = param_1;
  if ((*param_2 == 0) && (*(ulonglong *)(param_2 + 4) < *(longlong *)(param_2 + 6) + 9U)) {
    func_0x(param_2);
  }
  uVar10 = param_2[4] - param_2[6];
  piVar9 = (int *)(*(longlong *)(param_2 + 2) + *(longlong *)(param_2 + 6) * 2);
  if (uVar10 < 2) {
    return 0;
  }
  bVar5 = false;
  if (((*(int *)(param_3 + 0x18) != 0) && (bVar5 = false, 2 < uVar10)) &&
     (((*(uint *)(*(longlong *)(param_3 + 8) + (ulonglong)*(ushort *)((longlong)piVar9 + 2) * 4) ^
       *(uint *)(*(longlong *)(param_3 + 8) + (ulonglong)*(ushort *)piVar9 * 4)) & 0xe7ffffff) == 0)
     ) {
    piVar9 = (int *)((longlong)piVar9 + 2);
    bVar5 = true;
    uVar10 = uVar10 - 1;
  }
  pplVar3 = *(longlong ***)(param_3 + 0x30);
  uStackX_8 = CONCAT44(uStackX_8._4_4_,0x3020800);
  bVar1 = *(byte *)((longlong)&uStackX_8 +
                   (ulonglong)(byte)((byte)((uint)*(undefined4 *)param_4 >> 8) >> 6));
  if (bVar1 <= uVar10) {
    uVar10 = (uint)bVar1;
  }
  switch(uVar10) {
  case 2:
    goto code_r0x0010019f;
  case 3:
    goto code_r0x00100181;
  case 4:
    goto code_r0x00100160;
  case 5:
    goto code_r0x0010013f;
  case 6:
    goto code_r0x0010011e;
  case 7:
    break;
  case 8:
    if (pplVar3[6] != (longlong *)0x0) {
      uVar10 = func_0x();
      uVar8 = (ulonglong)uVar10;
      if (uVar10 != 0) {
        iVar7 = 8;
        goto code_r0x0010020a;
      }
    }
    break;
  default:
    goto code_r0x001001e5;
  }
  if (pplVar3[5] != (longlong *)0x0) {
    uVar10 = func_0x();
    uVar8 = (ulonglong)uVar10;
    if (uVar10 != 0) {
      iVar7 = 7;
      goto code_r0x0010020a;
    }
  }
code_r0x0010011e:
  if (pplVar3[4] != (longlong *)0x0) {
    uVar10 = func_0x();
    uVar8 = (ulonglong)uVar10;
    if (uVar10 != 0) {
      iVar7 = 6;
      goto code_r0x0010020a;
    }
  }
code_r0x0010013f:
  if (pplVar3[3] != (longlong *)0x0) {
    uVar10 = func_0x();
    uVar8 = (ulonglong)uVar10;
    if (uVar10 != 0) {
      iVar7 = 5;
      goto code_r0x0010020a;
    }
  }
code_r0x00100160:
  if (pplVar3[2] != (longlong *)0x0) {
    uVar10 = func_0x();
    uVar8 = (ulonglong)uVar10;
    if (uVar10 != 0) {
      iVar7 = 4;
      goto code_r0x0010020a;
    }
  }
code_r0x00100181:
  if (pplVar3[1] != (longlong *)0x0) {
    uVar10 = func_0x();
    uVar8 = (ulonglong)uVar10;
    if (uVar10 != 0) {
      iVar7 = 3;
code_r0x0010020a:
      if (!bVar5) {
        func_0x(param_2,iVar7 + -1);
      }
      *param_4 = (uVar8 & 0xffff) << 0x20 | uVar8 >> 0x10;
      return 1;
    }
  }
code_r0x0010019f:
  plVar4 = *pplVar3;
  if (plVar4 != (longlong *)0x0) {
    uVar2 = *(ushort *)piVar9;
    for (puVar6 = (undefined8 *)
                  (((ulonglong)
                    ((uint)(uVar2 >> 2) +
                     (uint)*(ushort *)((longlong)piVar9 + 2) + (uint)uVar2 * 0x820 ^ (uint)uVar2) %
                   (ulonglong)*(uint *)(plVar4 + 1)) * 0x10 + *plVar4); puVar6 != (undefined8 *)0x0;
        puVar6 = (undefined8 *)*puVar6) {
      if (*(int *)((longlong)puVar6 + 0xc) == *piVar9) {
        uVar8 = (ulonglong)*(uint *)(puVar6 + 1);
        if (*(uint *)(puVar6 + 1) == 0) {
          return 0;
        }
        iVar7 = 2;
        goto code_r0x0010020a;
      }
    }
  }
code_r0x001001e5:
  return 0;
}

