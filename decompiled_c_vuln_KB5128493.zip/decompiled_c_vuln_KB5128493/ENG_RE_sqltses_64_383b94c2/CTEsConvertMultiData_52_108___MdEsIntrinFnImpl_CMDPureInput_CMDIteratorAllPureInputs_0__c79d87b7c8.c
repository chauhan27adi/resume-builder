
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,char *param_2,ulonglong **param_3,ulonglong **param_4)

{
  ulonglong *puVar1;
  ulonglong *puVar2;
  undefined auVar3 [16];
  bool bVar4;
  byte bVar5;
  byte bVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  longlong lVar13;
  short sVar14;
  int iVar15;
  longlong *plVar16;
  short sVar17;
  longlong lVar18;
  ulonglong **ppuVar19;
  byte bVar20;
  ulonglong uVar21;
  byte bVar22;
  uint uVar23;
  undefined8 in_R11;
  uint uVar24;
  uint uVar25;
  short sVar26;
  char cVar27;
  undefined2 auStack_10858 [32656];
  undefined auStack_938 [32];
  ulonglong uStack_918;
  undefined4 uStack_910;
  uint uStack_908;
  uint uStack_900;
  uint uStack_8f8;
  uint uStack_8f0;
  ulonglong **ppuStack_8e8;
  ulonglong **ppuStack_8e0;
  undefined8 uStack_8d8;
  longlong *plStack_8d0;
  char cStack_8c8;
  undefined uStack_8c7;
  ushort uStack_8c6;
  short sStack_8c0;
  undefined6 uStack_8be;
  undefined4 uStack_8b8;
  undefined4 uStack_8b4;
  undefined4 uStack_8b0;
  undefined4 uStack_8ac;
  ulonglong uStack_8a8;
  undefined4 uStack_8a0;
  undefined8 uStack_898;
  undefined8 uStack_890;
  undefined4 uStack_888;
  undefined4 uStack_884;
  undefined8 uStack_880;
  undefined8 uStack_878;
  undefined8 uStack_870;
  short sStack_868;
  undefined2 *puStack_860;
  undefined2 auStack_858 [1024];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_938;
  uVar11 = 0;
  cVar27 = '\0';
  uVar21 = CONCAT71((int7)((ulonglong)in_R11 >> 8),1);
  uStack_8d8 = CONCAT44(uStack_8d8._4_4_,(int)uVar21);
  puVar1 = param_3[1];
  lVar18 = 0x7fffffffffffffff;
  bVar5 = *(byte *)puVar1;
  if ((byte)(bVar5 + 0x10) < 2) {
    bVar20 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar5 + 0x197870) * 4 + 0x197a03);
    uVar24 = (uint)bVar20;
    bVar22 = *(byte *)(*(longlong *)(*param_1 + 0x20) + 0xc);
    uVar23 = (uint)bVar22;
    if ((bVar5 == 0xf0) || (bVar5 == 0xf1)) {
      bVar5 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar5 + 0x197870) * 4 + 0x197a02);
    }
    else {
      bVar5 = *(byte *)((longlong)puVar1 + 0x12);
    }
  }
  else {
    bVar20 = *(byte *)((longlong)puVar1 + 0x13);
    uVar24 = (uint)bVar20;
    bVar5 = *(byte *)((longlong)puVar1 + 0x12);
    bVar22 = *(byte *)(*(longlong *)(*param_1 + 0x20) + 0xc);
    uVar23 = (uint)bVar22;
  }
  iVar15 = (bVar5 - uVar24) + uVar23;
  puVar1 = param_4[2];
  bVar5 = *(byte *)puVar1;
  if ((byte)(bVar5 + 0x10) < 2) {
    bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar5 + 0x197870) * 4 + 0x197a02);
  }
  else {
    bVar6 = *(byte *)((longlong)puVar1 + 0x12);
  }
  if (bVar6 < 0x13) {
    if ((byte)(bVar5 + 0x10) < 2) {
      bVar5 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar5 + 0x197870) * 4 + 0x197a02);
    }
    else {
      bVar5 = *(byte *)((longlong)puVar1 + 0x12);
    }
    uVar25 = (uint)bVar5;
  }
  else {
    uVar25 = 0x12;
  }
  ppuStack_8e8 = param_3;
  ppuStack_8e0 = param_4;
  plStack_8d0 = param_1;
  if (bVar22 < bVar20) {
    (**(code **)*_DAT_)(_DAT_,&uStack_880);
    uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_880);
    iVar7 = func_0x(uVar10,0x800);
    uVar21 = (ulonglong)((uint)uStack_8d8 & 0xff);
    if (iVar7 != 0) {
      uVar21 = uVar11;
    }
    if (((int)(uVar24 - uVar23) < 0x13) && (0 < iVar15 + 1)) {
      uVar11 = *(ulonglong *)((ulonglong)(uVar24 - uVar23) * 8 + 0x1ddd00);
      cVar27 = ((int)uVar25 < iVar15 + 1) + '\x05';
      bVar4 = false;
      goto LAB_;
    }
    cVar27 = '\x04';
  }
  else if (bVar20 < bVar22) {
    if ((int)(uVar23 - uVar24) < 0x13) {
      uVar11 = *(ulonglong *)((ulonglong)(uVar23 - uVar24) * 8 + 0x1ddd00);
      if ((int)uVar25 < iVar15) {
        cVar27 = (0x12 < iVar15) + '\x02';
        bVar4 = false;
        goto LAB_;
      }
      cVar27 = '\x01';
    }
    else {
      uVar21 = 0;
      uVar11 = 0;
      cVar27 = '\0';
    }
  }
  else {
    if (iVar15 <= (int)uVar25) {
      bVar4 = true;
      goto LAB_;
    }
    cVar27 = '\a';
  }
  bVar4 = false;
LAB_:
  uVar12 = uStack_8a8;
  bVar5 = *(byte *)(*(longlong *)(*plStack_8d0 + 0x20) + 0xd);
  if (bVar5 < 0x13) {
    lVar18 = *(longlong *)((ulonglong)bVar5 * 8 + 0x1ddc60);
  }
  sVar26 = 0;
  sStack_868 = 0;
  puStack_860 = auStack_858;
  if (bVar4) {
    uVar11 = (ulonglong)(*param_2 == '\0');
    puVar1 = *ppuStack_8e0;
    if (*param_2 == '\0') {
      uVar21 = **ppuStack_8e8;
      do {
        *puVar1 = uVar21;
        uVar11 = uVar11 - 1;
      } while (uVar11 != 0);
    }
    *param_2 = '\x01';
  }
  else {
    if ((char)uVar21 == '\0') {
      cVar27 = *param_2;
    }
    else {
      puStack_860 = (undefined2 *)0x0;
      sStack_868 = 0xffff;
      sVar14 = 0;
      puVar1 = *ppuStack_8e0;
      switch(cVar27) {
      case '\x01':
        uVar21 = (ulonglong)(*param_2 == '\0');
        if (*param_2 == '\0') {
          uVar12 = **ppuStack_8e8;
          do {
            *puVar1 = uVar11 * uVar12;
            uVar21 = uVar21 - 1;
          } while (uVar21 != 0);
        }
        break;
      case '\x02':
        uVar21 = (ulonglong)(*param_2 == '\0');
        if (*param_2 == '\0') {
          puVar2 = *ppuStack_8e8;
          sVar14 = sVar26;
          do {
            uVar12 = uVar11 * *puVar2;
            if ((uVar12 - lVar18 != 0 && lVar18 <= (longlong)uVar12) || ((longlong)uVar12 < -lVar18)
               ) {
              lVar13 = (longlong)sVar14;
              sVar14 = sVar14 + 1;
              auStack_858[lVar13] = 0;
            }
            uVar21 = uVar21 - 1;
          } while (uVar21 != 0);
          *puVar1 = uVar12;
        }
        break;
      case '\x03':
        uVar21 = (ulonglong)(*param_2 == '\0');
        if (*param_2 == '\0') {
          puVar2 = *ppuStack_8e8;
          sVar14 = sVar26;
          do {
            uVar12 = uVar11 * *puVar2;
            if ((uVar12 - lVar18 != 0 && lVar18 <= (longlong)uVar12) ||
               (bVar5 = 0, (longlong)uVar12 < -lVar18)) {
              bVar5 = 1;
            }
            if ((bool)(bVar5 | 1 < (SUB168(SEXT816((longlong)uVar11) * SEXT816((longlong)*puVar2),8)
                                    << 1 | uVar12 >> 0x3f) + 1)) {
              lVar13 = (longlong)sVar14;
              sVar14 = sVar14 + 1;
              auStack_858[lVar13] = 0;
            }
            uVar21 = uVar21 - 1;
          } while (uVar21 != 0);
          *puVar1 = uVar12;
        }
        break;
      case '\x04':
        uVar11 = (ulonglong)(*param_2 == '\0');
        if (*param_2 == '\0') {
          do {
            *puVar1 = 0;
            uVar11 = uVar11 - 1;
          } while (uVar11 != 0);
        }
        break;
      case '\x05':
        uVar21 = (ulonglong)(*param_2 == '\0');
        if (*param_2 == '\0') {
          uVar12 = **ppuStack_8e8;
          do {
            *puVar1 = ((ulonglong)((longlong)uVar12 / (longlong)uVar11) >> 0x3f ^ 1) +
                      (longlong)uVar12 / (longlong)uVar11 & 0xfffffffffffffffe;
            uVar21 = uVar21 - 1;
          } while (uVar21 != 0);
        }
        break;
      case '\x06':
        uVar21 = (ulonglong)(*param_2 == '\0');
        sVar14 = sVar26;
        if (*param_2 == '\0') {
          puVar2 = *ppuStack_8e8;
          do {
            uVar12 = *puVar2;
            if ((longlong)uVar12 < 1) {
              if (uVar12 == 0x8000000000000000) {
                auVar3._8_8_ = 0;
                auVar3._0_8_ = uVar11;
                lVar13 = SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x8000000000000000)) / auVar3,0);
              }
              else {
                lVar13 = -((longlong)uVar12 / (longlong)uVar11);
              }
              uVar12 = -(lVar13 + 1U & 0xfffffffffffffffe);
            }
            else {
              uVar12 = (longlong)uVar12 / (longlong)uVar11 + 1U & 0xfffffffffffffffe;
            }
            if ((lVar18 < (longlong)uVar12) || ((longlong)uVar12 < -lVar18)) {
              lVar13 = (longlong)sVar14;
              sVar14 = sVar14 + 1;
              auStack_858[lVar13] = 0;
            }
            uVar21 = uVar21 - 1;
          } while (uVar21 != 0);
          *puVar1 = uVar12;
        }
        break;
      case '\a':
        uVar11 = (ulonglong)(*param_2 == '\0');
        sVar14 = sVar26;
        if (*param_2 == '\0') {
          puVar2 = *ppuStack_8e8;
          do {
            uVar21 = *puVar2;
            if ((lVar18 < (longlong)uVar21) ||
               (SBORROW8(uVar21,-lVar18) != (longlong)(uVar21 + lVar18) < 0)) {
              lVar13 = (longlong)sVar14;
              sVar14 = sVar14 + 1;
              auStack_858[lVar13] = 0;
            }
            uVar11 = uVar11 - 1;
          } while (uVar11 != 0);
          *puVar1 = uVar21;
        }
        break;
      default:
        sVar14 = sVar26;
        sVar17 = sVar26;
        if (*param_2 == '\0') {
          do {
            uStack_918 = 0x1e0cd8;
            (*_DAT_)(1,0x1e03d0,0x1e0548,0xdd);
            sVar17 = sVar17 + 1;
            *puVar1 = uVar12;
          } while (sVar17 < (short)(ushort)(*param_2 == '\0'));
        }
      }
      cVar27 = sVar14 == 0;
      *param_2 = cVar27;
      sStack_868 = sVar14;
    }
    puStack_860 = auStack_858;
    if (cVar27 == '\0') {
      uStack_8c6 = 0;
      uStack_8be = 0;
      uStack_8b8 = 0;
      uStack_8b4 = 0;
      uStack_8b0 = 0;
      puVar1 = *ppuStack_8e0;
      plVar16 = plStack_8d0;
      ppuVar19 = ppuStack_8e0;
      do {
        uStack_8a0 = 0x6c00;
        uStack_898 = 0;
        uStack_890 = 0;
        uStack_888 = 0;
        cStack_8c8 = '\0';
        uStack_8c7 = 0x34;
        sStack_8c0 = (short)((longlong)**ppuStack_8e8 >> 1);
        iVar15 = func_0x
                           (&uStack_898,(int)sStack_8c0,
                            *(undefined *)(*(longlong *)(*plVar16 + 0x20) + 0xd),
                            *(undefined *)(*(longlong *)(*plVar16 + 0x20) + 0xc));
        cStack_8c8 = (char)uStack_8a0;
        uStack_8c7 = (undefined)((uint)uStack_8a0 >> 8);
        sStack_8c0 = (short)uStack_898;
        uStack_8be = (undefined6)((ulonglong)uStack_898 >> 0x10);
        uStack_8b8 = (undefined4)uStack_890;
        uStack_8b4 = uStack_890._4_4_;
        uStack_8b0 = uStack_888;
        uStack_8ac = uStack_884;
        uStack_8c6 = (ushort)((uint)uStack_8a0 >> 0x10) & 0xfffe;
        if (iVar15 != 0) {
          (**(code **)*_DAT_)(_DAT_,&uStack_878);
          uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_878);
          iVar7 = func_0x(uVar10,0x800);
          (**(code **)*_DAT_)(_DAT_,&uStack_870);
          uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_870);
          iVar8 = func_0x(uVar10,0x10000000);
          (**(code **)*_DAT_)(_DAT_,&uStack_8a8);
          uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_8a8);
          iVar9 = func_0x(uVar10,0x1000);
          uStack_8f0 = (uint)(iVar7 != 0);
          uStack_8f8 = (uint)(iVar8 != 0);
          uStack_900 = (uint)(iVar9 != 0);
          uStack_908 = *(byte *)(*(longlong *)(*plStack_8d0 + 0x20) + 0x11) & 0x80;
          uStack_910 = 0;
          uStack_918 = uStack_918 & 0xffffffff00000000;
          func_0x(iVar15,&cStack_8c8,0x6c,0x34);
          plVar16 = plStack_8d0;
          ppuVar19 = ppuStack_8e0;
        }
        if (cStack_8c8 == '\x03') {
          uStack_8d8 = 1;
        }
        else {
          uStack_918 = uStack_918 & 0xffffffff00000000;
          func_0x
                    (&cStack_8c8,&uStack_8d8,ppuVar19[2],*(undefined8 *)(*plVar16 + 0x80));
        }
        sVar26 = sVar26 + 1;
        *puVar1 = uStack_8d8;
      } while (sVar26 < (short)(ushort)(*param_2 == '\0'));
    }
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_938);
  return;
}

