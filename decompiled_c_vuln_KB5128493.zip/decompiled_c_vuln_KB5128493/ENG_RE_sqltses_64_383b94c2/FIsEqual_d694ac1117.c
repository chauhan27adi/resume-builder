
bool FUN_(short *param_1,short *param_2)

{
  int iVar1;
  int iVar2;
  
  if (*param_1 == *param_2) {
    switch(*param_1) {
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 0xb:
    case 0x10:
    case 0x11:
    case 0x12:
    case 0x13:
      return true;
    case 5:
    case 0x14:
    case 0x15:
      return !NAN(*(double *)(param_1 + 4));
    case 8:
      if ((*(longlong *)(param_1 + 4) == 0) == (*(longlong *)(param_2 + 4) == 0)) {
        if (*(longlong *)(param_1 + 4) == 0) {
          return true;
        }
        iVar1 = (*pcRam00000000004b5df8)();
        iVar2 = (*pcRam00000000004b5df8)(*(undefined8 *)(param_2 + 4));
        if (iVar1 == iVar2) {
          iVar1 = func_0x(*(undefined8 *)(param_1 + 4),*(undefined8 *)(param_2 + 4),
                                  (longlong)iVar1 * 2);
          return iVar1 == 0;
        }
      }
    }
  }
  return false;
}

