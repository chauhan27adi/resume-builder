
/* WARNING: Control flow encountered bad instruction data */

int FUN_(byte *param_1,undefined8 param_2,ulonglong param_3,undefined8 param_4,uint param_5)

{
  char cVar1;
  int iVar2;
  
  if (*(char *)((ulonglong)*(byte *)((ulonglong)*param_1 + 0x559860) + 0x559960) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(int *)((ulonglong)(*(uint *)(param_1 + 0x14) & 0x7f) * 0x20 + 0x5554a0) == 0x409) &&
     ((*(uint *)(param_1 + 0x14) >> 0xc & 1) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  cVar1 = func_0x(param_1);
  if (cVar1 != '\0') {
    iVar2 = func_0x(0x8000000,param_2,param_3 >> 1 & 0x7fffffff,param_4,param_5 >> 1);
    return iVar2 + -2;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

