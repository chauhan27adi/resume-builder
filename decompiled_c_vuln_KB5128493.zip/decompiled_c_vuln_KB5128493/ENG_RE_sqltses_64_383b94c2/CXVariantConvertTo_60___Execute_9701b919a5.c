
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(char *param_1,char param_2)

{
  ulonglong uVar1;
  undefined auStack_68 [48];
  ulonglong uStack_38;
  
  uVar1 = _DAT_;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_68;
  if ((*param_1 + 1U & 0xfb) != 0) {
    if (param_2 == 'b') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    switch(param_2) {
    default:
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case '0':
    case 'h':
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case '4':
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case '8':
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case ':':
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case ';':
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case '<':
      break;
    case '=':
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case '>':
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case 'j':
    case 'l':
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case 'z':
      *(longlong *)(param_1 + 8) = (longlong)*(int *)(param_1 + 8);
      break;
    case '\x7f':
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case -0x5b:
    case -0x53:
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case -0x59:
    case -0x51:
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case -0x43:
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    case -0x19:
    case -0x11:
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  param_1[1] = '<';
  func_0x(uVar1);
  return;
}

