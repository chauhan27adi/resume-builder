
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong param_2,undefined param_3)

{
  undefined8 *puVar1;
  longlong unaff_GS_OFFSET;
  undefined auStackX_18 [8];
  undefined8 *puStackX_20;
  undefined auStack_28 [8];
  undefined8 uStack_20;
  
  if (*(longlong *)
       (*(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 0x100
       + (ulonglong)*_DAT_) == 0) {
    (*_DAT_)(0);
  }
  puVar1 = (undefined8 *)((longlong)param_2 >> 1);
  switch(param_3) {
  case 0x30:
  case 0x68:
    uStack_20 = (undefined8 *)CONCAT71(uStack_20._1_7_,(char)(param_2 >> 1));
    break;
  default:
    (*_DAT_)(0x62,0x24,0x10,0xe);
    break;
  case 0x34:
    uStack_20 = (undefined8 *)CONCAT62(uStack_20._2_6_,(short)puVar1);
    break;
  case 0x38:
  case 0x7a:
    uStack_20 = (undefined8 *)CONCAT44(uStack_20._4_4_,(int)puVar1);
    break;
  case 0x3b:
    uStack_20 = (undefined8 *)CONCAT44(uStack_20._4_4_,(int)(param_2 >> 1));
    break;
  case 0x3c:
  case 0x7f:
    uStack_20 = puVar1;
    if ((param_2 & 1) != 0) {
      (**ppcRam0000000000000000)(0,param_2,&puStackX_20,auStackX_18);
      uStack_20 = (undefined8 *)*puStackX_20;
    }
    break;
  case 0x3e:
    if ((param_2 & 1) == 0) {
      puStackX_20 = (undefined8 *)((param_2 >> 1 ^ param_2) & 0x1fffffffffffffff ^ param_2);
      uStack_20 = puStackX_20;
    }
    else {
      (**ppcRam0000000000000000)(0,param_2,&puStackX_20,auStackX_18);
      uStack_20 = (undefined8 *)*puStackX_20;
    }
  }
  func_0x(param_1,auStack_28,param_3);
  return;
}

