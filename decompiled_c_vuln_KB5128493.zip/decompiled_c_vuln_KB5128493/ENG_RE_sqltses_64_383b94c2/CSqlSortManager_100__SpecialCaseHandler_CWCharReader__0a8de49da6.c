
undefined8
FUN_(longlong param_1,longlong param_2,uint param_3,ulonglong *param_4,ulonglong *param_5,
            longlong param_6,short *param_7,int param_8,int param_9,uint *param_10,uint *param_11,
            uint *param_12,int *param_13,int param_14,longlong param_15,undefined *param_16,
            ulonglong *param_17,ulonglong *param_18,longlong *param_19,longlong *param_20)

{
  undefined *puVar1;
  bool bVar2;
  int iVar3;
  uint uVar4;
  undefined uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  ushort uVar9;
  ulonglong uVar10;
  short sVar11;
  int iVar12;
  uint uVar13;
  undefined4 uStackX_20;
  undefined auStack_38 [4];
  undefined uStack_34;
  byte bStack_33;
  byte bStack_32;
  undefined4 uStack_30;
  
  uVar10 = *param_4;
  switch(uVar10 >> 0x28 & 0xff) {
  case 1:
    if (param_8 == 0) {
      if ((*param_17 < param_15 + 2U) && (*(byte *)(*param_17 - 2) < 0x15)) {
        bVar2 = true;
      }
      else {
        bVar2 = false;
      }
      if (((param_3 & 2) == 0) || (!bVar2)) {
        puVar1 = (undefined *)*param_18;
        if (puVar1 <= param_16) {
          *puVar1 = (char)uVar10;
          *param_18 = (ulonglong)(puVar1 + 1);
          return 0;
        }
        uVar6 = ((uint)uVar10 & 0xff) + (uint)(byte)puVar1[-1];
        if (0xff < uVar6) {
          uVar6 = 0xff;
        }
        puVar1[-1] = (char)uVar6;
        return 0;
      }
    }
    break;
  case 2:
    uVar10 = (uVar10 >> 8 & 0xff) << 8 | uVar10 >> 0x20 & 0xff;
    uVar9 = *(ushort *)(*(longlong *)(param_1 + 0xa8) + uVar10 * 4);
    uStackX_20 = *(undefined4 *)(*(longlong *)(param_1 + 0xa8) + uVar10 * 4);
    func_0x(param_6,1);
    *(undefined2 *)(param_6 + 0x3e) = uStackX_20._2_2_;
    *(ushort *)(param_6 + 0x3c) = uVar9;
    *(undefined4 *)(param_6 + 0x40) = 0;
    uVar6 = *(uint *)(*(longlong *)(param_2 + 8) + (ulonglong)uVar9 * 4);
    *param_4 = ((ulonglong)uVar6 & 0xffff) << 0x20 | (ulonglong)(uVar6 >> 0x10);
    return 1;
  case 3:
    uStack_30 = 0;
    func_0x(param_4,param_5,&uStack_30);
    if (param_8 != 0) {
      return 1;
    }
    if (uStack_30 == 0) {
      return 1;
    }
    puVar1 = (undefined *)*param_19;
    *puVar1 = (char)uStack_30;
    puVar1[param_14] = uStack_30._1_1_;
    if ((param_3 >> 0x10 & 1) == 0) {
      puVar1[param_14 * 2] = uStack_30._2_1_;
    }
    if ((param_3 >> 0x11 & 1) == 0) {
      puVar1[param_14 * 3] = uStack_30._3_1_;
    }
    *param_19 = (longlong)(puVar1 + 1);
    return 1;
  case 4:
    *param_5 = 0;
    if (*(int *)(param_6 + 0x40) < 0) {
      uVar10 = *(ulonglong *)(param_6 + 0x18);
      if (*(ulonglong *)(param_6 + 0x10) <= uVar10) {
        func_0x(param_6);
        uVar10 = *(ulonglong *)(param_6 + 0x18);
      }
      uVar9 = *(ushort *)(*(longlong *)(param_6 + 8) + uVar10 * 2);
    }
    else {
      uVar9 = *(ushort *)(param_6 + 0x3c + (longlong)*(int *)(param_6 + 0x40) * 2);
    }
    if ((0x115f < uVar9) ||
       (iVar3 = func_0x(param_1,param_2,param_6,&uStackX_20,&uStack_34,3,auStack_38),
       iVar3 < 1)) {
      uVar10 = *param_4;
      *param_4 = (uVar10 & 0xff) << 0x20 |
                 (uVar10 >> 0x20 & 0xff) << 0x28 | uVar10 & 0xffff0000ffffff02 | 2;
      return 1;
    }
    uVar5 = (undefined)((ushort)(undefined2)uStackX_20 >> 8);
    if (param_8 == 0) {
      puVar1 = (undefined *)*param_17;
      *puVar1 = uVar5;
      puVar1[1] = (char)(undefined2)uStackX_20;
      puVar1[2] = 0xff;
      puVar1[3] = uStack_34;
      *param_17 = (ulonglong)(puVar1 + 4);
      goto code_r0x001004b7;
    }
    iVar12 = *param_13;
    *(undefined *)((longlong)iVar12 + (longlong)param_12) = uVar5;
    *(char *)((longlong)iVar12 + 1 + (longlong)param_12) = (char)(undefined2)uStackX_20;
    iVar12 = iVar12 + 2;
    if (iVar12 == 4) {
      uVar6 = *param_12;
      uVar8 = *param_10;
      uVar9 = (ushort)uVar6;
      sVar11 = (short)(uVar6 >> 0x10);
      if (param_9 == 0) {
        uVar13 = uVar8 << 3 | uVar8 >> 0x1d;
        uVar4 = uVar13 ^ uVar6;
        *param_10 = uVar4;
        if (sVar11 == 0x207) {
          if (uVar9 != 0x207) {
            *param_11 = ((uVar6 & 0xff ^ uVar13) << 3 | (uVar8 << 3) >> 0x1d) ^
                        (uVar6 & 0xffff) >> 8;
          }
          iVar12 = 0;
        }
        else {
          *param_11 = uVar4;
          iVar12 = 0;
        }
      }
      else {
        iVar7 = uVar8 * 0x820 + (uVar8 >> 2);
        uVar4 = iVar7 + uVar6 ^ uVar8;
        *param_10 = uVar4;
        if (sVar11 == 0x207) {
          iVar12 = 0;
          if (uVar9 != 0x207) {
            uVar8 = (uVar6 & 0xff) + iVar7 ^ uVar8;
            *param_11 = uVar8 * 0x820 + (uVar8 >> 2) + (uint)(uVar9 >> 8) ^ uVar8;
          }
        }
        else {
          *param_11 = uVar4;
          iVar12 = 0;
        }
      }
    }
    *(undefined *)((longlong)iVar12 + (longlong)param_12) = 0xff;
    *(undefined *)((longlong)iVar12 + 1 + (longlong)param_12) = uStack_34;
    *param_13 = iVar12 + 2;
    if (iVar12 + 2 == 4) {
      uVar6 = *param_12;
      uVar8 = *param_10;
      uVar9 = (ushort)uVar6;
      *param_13 = 0;
      sVar11 = (short)(uVar6 >> 0x10);
      if (param_9 == 0) {
        uVar13 = uVar8 << 3 | uVar8 >> 0x1d;
        uVar4 = uVar13 ^ uVar6;
        *param_10 = uVar4;
        if (sVar11 == 0x207) {
          if (uVar9 != 0x207) {
            uVar8 = ((uVar6 & 0xff ^ uVar13) << 3 | (uVar8 << 3) >> 0x1d) ^ (uVar6 & 0xffff) >> 8;
code_r0x0010046a:
            *param_11 = uVar8;
          }
        }
        else {
          *param_11 = uVar4;
        }
      }
      else {
        iVar12 = uVar8 * 0x820 + (uVar8 >> 2);
        uVar4 = iVar12 + uVar6 ^ uVar8;
        *param_10 = uVar4;
        if (sVar11 == 0x207) {
          if (uVar9 != 0x207) {
            uVar8 = (uVar6 & 0xff) + iVar12 ^ uVar8;
            uVar8 = uVar8 * 0x820 + (uVar8 >> 2) + (uint)(uVar9 >> 8) ^ uVar8;
            goto code_r0x0010046a;
          }
        }
        else {
          *param_11 = uVar4;
        }
      }
    }
    *param_7 = *param_7 + 2;
code_r0x001004b7:
    *param_4 = ((ulonglong)bStack_33 << 0x10 | (ulonglong)bStack_32) << 0x10 | 0xff00ff000202;
    if (1 < iVar3) {
      func_0x(param_6,iVar3 + -1);
    }
    return 1;
  case 5:
    uVar10 = ((uVar10 >> 0x20 & 0xff) << 8 | uVar10 & 0xff) << 0x10 | 0xfdff00000202;
    *param_4 = uVar10;
    *param_5 = uVar10;
    return 1;
  case 6:
    if (param_8 == 0) {
      puVar1 = (undefined *)*param_20;
      uVar9 = (short)(*param_17 << 2) + (short)param_15 * -4 | 0x8003;
      *puVar1 = (char)(uVar9 >> 8);
      puVar1[1] = (char)uVar9;
      puVar1[2] = (char)(*param_4 >> 0x28);
      puVar1[3] = (char)(*param_4 >> 0x20);
      *param_20 = (longlong)(puVar1 + 4);
    }
  }
  return 0;
}

