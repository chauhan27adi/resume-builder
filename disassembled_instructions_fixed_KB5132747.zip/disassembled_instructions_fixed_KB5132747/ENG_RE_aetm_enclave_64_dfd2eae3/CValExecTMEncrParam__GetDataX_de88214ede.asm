; CValExecTMEncrParam::GetDataX
; aetm_enclave.dll, primary RVA 0x14ba0, 3392 bytes in 7 chunk(s)

; chunk at RVA 0x14ba0 (88 bytes)
00014ba0  4056                     push rsi
00014ba2  57                       push rdi
00014ba3  4156                     push r14
00014ba5  4881ec80000000           sub rsp, 0x80
00014bac  488b0555640900           mov rax, qword ptr [rip + 0x96455]
00014bb3  4833c4                   xor rax, rsp
00014bb6  4889442450               mov qword ptr [rsp + 0x50], rax
00014bbb  4d8bf0                   mov r14, r8
00014bbe  488bf1                   mov rsi, rcx
00014bc1  4c8b02                   mov r8, qword ptr [rdx]
00014bc4  4d85c0                   test r8, r8
00014bc7  0f8438090000             je 0x15505
00014bcd  8b4908                   mov ecx, dword ptr [rcx + 8]
00014bd0  ffc1                     inc ecx
00014bd2  48c1e105                 shl rcx, 5
00014bd6  4903c8                   add rcx, r8
00014bd9  493bc8                   cmp rcx, r8
00014bdc  0f8223090000             jb 0x15505
00014be2  483b0d4f0e4600           cmp rcx, qword ptr [rip + 0x460e4f]
00014be9  760d                     jbe 0x14bf8
00014beb  4c3b053e0e4600           cmp r8, qword ptr [rip + 0x460e3e]
00014bf2  0f820d090000             jb 0x15505

; chunk at RVA 0x14bf8 (81 bytes)
00014bf8  48899c24b8000000         mov qword ptr [rsp + 0xb8], rbx
00014c00  48896c2478               mov qword ptr [rsp + 0x78], rbp
00014c05  4c897c2460               mov qword ptr [rsp + 0x60], r15
00014c0a  0faee8                   lfence
00014c0d  448b7e08                 mov r15d, dword ptr [rsi + 8]
00014c11  498d5e08                 lea rbx, [r14 + 8]
00014c15  0fb64630                 movzx eax, byte ptr [rsi + 0x30]
00014c19  33ff                     xor edi, edi
00014c1b  48893b                   mov qword ptr [rbx], rdi
00014c1e  48897b08                 mov qword ptr [rbx + 8], rdi
00014c22  897b10                   mov dword ptr [rbx + 0x10], edi
00014c25  49c1e705                 shl r15, 5
00014c29  6641897e02               mov word ptr [r14 + 2], di
00014c2e  41884601                 mov byte ptr [r14 + 1], al
00014c32  41883e                   mov byte ptr [r14], dil
00014c35  43803c0703               cmp byte ptr [r15 + r8], 3
00014c3a  88442440                 mov byte ptr [rsp + 0x40], al
00014c3e  7509                     jne 0x14c49
00014c40  41c60603                 mov byte ptr [r14], 3
00014c44  e9b6010000               jmp 0x14dff

; chunk at RVA 0x14c49 (438 bytes)
00014c49  4c89642470               mov qword ptr [rsp + 0x70], r12
00014c4e  478b640710               mov r12d, dword ptr [r15 + r8 + 0x10]
00014c53  4f8b7c0708               mov r15, qword ptr [r15 + r8 + 8]
00014c58  4c896c2468               mov qword ptr [rsp + 0x68], r13
00014c5d  897c2448                 mov dword ptr [rsp + 0x48], edi
00014c61  4d85ff                   test r15, r15
00014c64  0f84b30b0000             je 0x1581d
00014c6a  4b8d0427                 lea rax, [r15 + r12]
00014c6e  493bc7                   cmp rax, r15
00014c71  0f82a60b0000             jb 0x1581d
00014c77  483b05ba0d4600           cmp rax, qword ptr [rip + 0x460dba]
00014c7e  760d                     jbe 0x14c8d
00014c80  4c3b3da90d4600           cmp r15, qword ptr [rip + 0x460da9]
00014c87  0f82900b0000             jb 0x1581d
00014c8d  0faee8                   lfence
00014c90  f605b12e450001           test byte ptr [rip + 0x452eb1], 1
00014c97  7549                     jne 0x14ce2
00014c99  4183fc08                 cmp r12d, 8
00014c9d  0f8284080000             jb 0x15527
00014ca3  488b86f0000000           mov rax, qword ptr [rsi + 0xf0]
00014caa  493907                   cmp qword ptr [r15], rax
00014cad  7533                     jne 0x14ce2
00014caf  83bef800000002           cmp dword ptr [rsi + 0xf8], 2
00014cb6  722a                     jb 0x14ce2
00014cb8  4439a61c010000           cmp dword ptr [rsi + 0x11c], r12d
00014cbf  7521                     jne 0x14ce2
00014cc1  488b8e10010000           mov rcx, qword ptr [rsi + 0x110]
00014cc8  4d8bc4                   mov r8, r12
00014ccb  498bd7                   mov rdx, r15
00014cce  e834950400               call 0x5e207
00014cd3  85c0                     test eax, eax
00014cd5  750b                     jne 0x14ce2
00014cd7  8bbe20010000             mov edi, dword ptr [rsi + 0x120]
00014cdd  e9e4000000               jmp 0x14dc6
00014ce2  4c8b8ee0000000           mov r9, qword ptr [rsi + 0xe0]
00014ce9  488d442448               lea rax, [rsp + 0x48]
00014cee  40887c2430               mov byte ptr [rsp + 0x30], dil
00014cf3  488d4e50                 lea rcx, [rsi + 0x50]
00014cf7  4889442428               mov qword ptr [rsp + 0x28], rax
00014cfc  458bc4                   mov r8d, r12d
00014cff  8b86e8000000             mov eax, dword ptr [rsi + 0xe8]
00014d05  498bd7                   mov rdx, r15
00014d08  89442420                 mov dword ptr [rsp + 0x20], eax
00014d0c  e89f540000               call 0x1a1b0
00014d11  f605302e450001           test byte ptr [rip + 0x452e30], 1
00014d18  0f85a4000000             jne 0x14dc2
00014d1e  4183fc08                 cmp r12d, 8
00014d22  0f8223080000             jb 0x1554b
00014d28  498b07                   mov rax, qword ptr [r15]
00014d2b  483b86f0000000           cmp rax, qword ptr [rsi + 0xf0]
00014d32  757d                     jne 0x14db1
00014d34  8b8ef8000000             mov ecx, dword ptr [rsi + 0xf8]
00014d3a  83f902                   cmp ecx, 2
00014d3d  7372                     jae 0x14db1
00014d3f  8d4101                   lea eax, [rcx + 1]
00014d42  8986f8000000             mov dword ptr [rsi + 0xf8], eax
00014d48  83f802                   cmp eax, 2
00014d4b  7575                     jne 0x14dc2
00014d4d  448b8618010000           mov r8d, dword ptr [rsi + 0x118]
00014d54  488b8e10010000           mov rcx, qword ptr [rsi + 0x110]
00014d5b  4585e4                   test r12d, r12d
00014d5e  743e                     je 0x14d9e
00014d60  4885c9                   test rcx, rcx
00014d63  750e                     jne 0x14d73
00014d65  ff152de40400             call qword ptr [rip + 0x4e42d]
00014d6b  c70016000000             mov dword ptr [rax], 0x16
00014d71  eb25                     jmp 0x14d98
00014d73  4d3bc4                   cmp r8, r12
00014d76  720d                     jb 0x14d85
00014d78  4d8bc4                   mov r8, r12
00014d7b  498bd7                   mov rdx, r15
00014d7e  e890940400               call 0x5e213
00014d83  eb19                     jmp 0x14d9e
00014d85  33d2                     xor edx, edx
00014d87  e89f940400               call 0x5e22b
00014d8c  ff1506e40400             call qword ptr [rip + 0x4e406]
00014d92  c70022000000             mov dword ptr [rax], 0x22
00014d98  ff1502e40400             call qword ptr [rip + 0x4e402]
00014d9e  8b7c2448                 mov edi, dword ptr [rsp + 0x48]
00014da2  89be20010000             mov dword ptr [rsi + 0x120], edi
00014da8  4489a61c010000           mov dword ptr [rsi + 0x11c], r12d
00014daf  eb15                     jmp 0x14dc6
00014db1  c786f800000001000000     mov dword ptr [rsi + 0xf8], 1
00014dbb  488986f0000000           mov qword ptr [rsi + 0xf0], rax
00014dc2  8b7c2448                 mov edi, dword ptr [rsp + 0x48]
00014dc6  0fb65630                 movzx edx, byte ptr [rsi + 0x30]
00014dca  4c8d3d2fb2feff           lea r15, [rip - 0x14dd1]
00014dd1  460fb6843a405a0600       movzx r8d, byte ptr [rdx + r15 + 0x65a40]
00014dda  4380bc38405b060001       cmp byte ptr [r8 + r15 + 0x65b40], 1
00014de3  7545                     jne 0x14e2a
00014de5  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
00014dec  488903                   mov qword ptr [rbx], rax
00014def  8bc7                     mov eax, edi
00014df1  49894610                 mov qword ptr [r14 + 0x10], rax
00014df5  4c8b6c2468               mov r13, qword ptr [rsp + 0x68]
00014dfa  4c8b642470               mov r12, qword ptr [rsp + 0x70]

; chunk at RVA 0x14dff (43 bytes)
00014dff  488b6c2478               mov rbp, qword ptr [rsp + 0x78]
00014e04  488b9c24b8000000         mov rbx, qword ptr [rsp + 0xb8]
00014e0c  4c8b7c2460               mov r15, qword ptr [rsp + 0x60]
00014e11  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00014e16  4833cc                   xor rcx, rsp
00014e19  e8b27f0400               call 0x5cdd0
00014e1e  4881c480000000           add rsp, 0x80
00014e25  415e                     pop r14
00014e27  5f                       pop rdi
00014e28  5e                       pop rsi
00014e29  c3                       ret

; chunk at RVA 0x14e2a (1755 bytes)
00014e2a  0fb6442440               movzx eax, byte ptr [rsp + 0x40]
00014e2f  83c0dc                   add eax, -0x24
00014e32  83f85b                   cmp eax, 0x5b
00014e35  77be                     ja 0x14df5
00014e37  4898                     cdqe
00014e39  410fb6840784580100       movzx eax, byte ptr [r15 + rax + 0x15884]
00014e42  418b8c8740580100         mov ecx, dword ptr [r15 + rax*4 + 0x15840]
00014e4a  4903cf                   add rcx, r15
00014e4d  ffe1                     jmp rcx
00014e4f  488b05120c4600           mov rax, qword ptr [rip + 0x460c12]
00014e56  83ff08                   cmp edi, 8
00014e59  740d                     je 0x14e68
00014e5b  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00014e62  0f8507070000             jne 0x1556f
00014e68  488bbee0000000           mov rdi, qword ptr [rsi + 0xe0]
00014e6f  4885ff                   test rdi, rdi
00014e72  0f8493010000             je 0x1500b
00014e78  488b3f                   mov rdi, qword ptr [rdi]
00014e7b  4881ffff000000           cmp rdi, 0xff
00014e82  0f8697010000             jbe 0x1501f
00014e88  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00014e8f  0f85f4060000             jne 0x15589
00014e95  e985010000               jmp 0x1501f
00014e9a  488b0dc70b4600           mov rcx, qword ptr [rip + 0x460bc7]
00014ea1  83ff08                   cmp edi, 8
00014ea4  740d                     je 0x14eb3
00014ea6  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014ead  0f85f0060000             jne 0x155a3
00014eb3  488bbee0000000           mov rdi, qword ptr [rsi + 0xe0]
00014eba  4885ff                   test rdi, rdi
00014ebd  743d                     je 0x14efc
00014ebf  488b3f                   mov rdi, qword ptr [rdi]
00014ec2  4885ff                   test rdi, rdi
00014ec5  791d                     jns 0x14ee4
00014ec7  488bc7                   mov rax, rdi
00014eca  48f7d8                   neg rax
00014ecd  483d00800000             cmp rax, 0x8000
00014ed3  7639                     jbe 0x14f0e
00014ed5  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014edc  0f85db060000             jne 0x155bd
00014ee2  eb2a                     jmp 0x14f0e
00014ee4  4881ff00800000           cmp rdi, 0x8000
00014eeb  7221                     jb 0x14f0e
00014eed  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014ef4  0f85dd060000             jne 0x155d7
00014efa  eb12                     jmp 0x14f0e
00014efc  ff1596e20400             call qword ptr [rip + 0x4e296]
00014f02  c70016000000             mov dword ptr [rax], 0x16
00014f08  ff1592e20400             call qword ptr [rip + 0x4e292]
00014f0e  66893b                   mov word ptr [rbx], di
00014f11  e9dffeffff               jmp 0x14df5
00014f16  488b0d4b0b4600           mov rcx, qword ptr [rip + 0x460b4b]
00014f1d  83ff08                   cmp edi, 8
00014f20  740d                     je 0x14f2f
00014f22  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014f29  0f85c2060000             jne 0x155f1
00014f2f  488bbee0000000           mov rdi, qword ptr [rsi + 0xe0]
00014f36  4885ff                   test rdi, rdi
00014f39  743b                     je 0x14f76
00014f3b  488b3f                   mov rdi, qword ptr [rdi]
00014f3e  ba00000080               mov edx, 0x80000000
00014f43  4885ff                   test rdi, rdi
00014f46  791a                     jns 0x14f62
00014f48  488bc7                   mov rax, rdi
00014f4b  48f7d8                   neg rax
00014f4e  483bc2                   cmp rax, rdx
00014f51  7635                     jbe 0x14f88
00014f53  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014f5a  0f85ab060000             jne 0x1560b
00014f60  eb26                     jmp 0x14f88
00014f62  483bfa                   cmp rdi, rdx
00014f65  7221                     jb 0x14f88
00014f67  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014f6e  0f85b1060000             jne 0x15625
00014f74  eb12                     jmp 0x14f88
00014f76  ff151ce20400             call qword ptr [rip + 0x4e21c]
00014f7c  c70016000000             mov dword ptr [rax], 0x16
00014f82  ff1518e20400             call qword ptr [rip + 0x4e218]
00014f88  893b                     mov dword ptr [rbx], edi
00014f8a  e966feffff               jmp 0x14df5
00014f8f  83ff08                   cmp edi, 8
00014f92  7414                     je 0x14fa8
00014f94  488b05cd0a4600           mov rax, qword ptr [rip + 0x460acd]
00014f9b  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00014fa2  0f8595060000             jne 0x1563d
00014fa8  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
00014faf  4885c0                   test rax, rax
00014fb2  740b                     je 0x14fbf
00014fb4  488b38                   mov rdi, qword ptr [rax]
00014fb7  48893b                   mov qword ptr [rbx], rdi
00014fba  e936feffff               jmp 0x14df5
00014fbf  33ff                     xor edi, edi
00014fc1  ff15d1e10400             call qword ptr [rip + 0x4e1d1]
00014fc7  c70016000000             mov dword ptr [rax], 0x16
00014fcd  ff15cde10400             call qword ptr [rip + 0x4e1cd]
00014fd3  48893b                   mov qword ptr [rbx], rdi
00014fd6  e91afeffff               jmp 0x14df5
00014fdb  83ff08                   cmp edi, 8
00014fde  7414                     je 0x14ff4
00014fe0  488b05810a4600           mov rax, qword ptr [rip + 0x460a81]
00014fe7  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00014fee  0f8561060000             jne 0x15655
00014ff4  488bbee0000000           mov rdi, qword ptr [rsi + 0xe0]
00014ffb  4885ff                   test rdi, rdi
00014ffe  740b                     je 0x1500b
00015000  488b3f                   mov rdi, qword ptr [rdi]
00015003  40883b                   mov byte ptr [rbx], dil
00015006  e9eafdffff               jmp 0x14df5
0001500b  33ff                     xor edi, edi
0001500d  ff1585e10400             call qword ptr [rip + 0x4e185]
00015013  c70016000000             mov dword ptr [rax], 0x16
00015019  ff1581e10400             call qword ptr [rip + 0x4e181]
0001501f  40883b                   mov byte ptr [rbx], dil
00015022  e9cefdffff               jmp 0x14df5
00015027  83ff04                   cmp edi, 4
0001502a  7414                     je 0x15040
0001502c  488b05350a4600           mov rax, qword ptr [rip + 0x460a35]
00015033  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001503a  0f852d060000             jne 0x1566d
00015040  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
00015047  4885c0                   test rax, rax
0001504a  7415                     je 0x15061
0001504c  8b00                     mov eax, dword ptr [rax]
0001504e  89442448                 mov dword ptr [rsp + 0x48], eax
00015052  f30f10442448             movss xmm0, dword ptr [rsp + 0x48]
00015058  f30f1103                 movss dword ptr [rbx], xmm0
0001505c  e994fdffff               jmp 0x14df5
00015061  89442448                 mov dword ptr [rsp + 0x48], eax
00015065  ff152de10400             call qword ptr [rip + 0x4e12d]
0001506b  c70016000000             mov dword ptr [rax], 0x16
00015071  ff1529e10400             call qword ptr [rip + 0x4e129]
00015077  f30f10442448             movss xmm0, dword ptr [rsp + 0x48]
0001507d  f30f1103                 movss dword ptr [rbx], xmm0
00015081  e96ffdffff               jmp 0x14df5
00015086  83ff08                   cmp edi, 8
00015089  7414                     je 0x1509f
0001508b  488b05d6094600           mov rax, qword ptr [rip + 0x4609d6]
00015092  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00015099  0f85e6050000             jne 0x15685
0001509f  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
000150a6  4885c0                   test rax, rax
000150a9  7417                     je 0x150c2
000150ab  488b00                   mov rax, qword ptr [rax]
000150ae  4889442448               mov qword ptr [rsp + 0x48], rax
000150b3  f20f10442448             movsd xmm0, qword ptr [rsp + 0x48]
000150b9  f20f1103                 movsd qword ptr [rbx], xmm0
000150bd  e933fdffff               jmp 0x14df5
000150c2  4889442448               mov qword ptr [rsp + 0x48], rax
000150c7  ff15cbe00400             call qword ptr [rip + 0x4e0cb]
000150cd  c70016000000             mov dword ptr [rax], 0x16
000150d3  ff15c7e00400             call qword ptr [rip + 0x4e0c7]
000150d9  f20f10442448             movsd xmm0, qword ptr [rsp + 0x48]
000150df  f20f1103                 movsd qword ptr [rbx], xmm0
000150e3  e90dfdffff               jmp 0x14df5
000150e8  83ff08                   cmp edi, 8
000150eb  0f845f030000             je 0x15450
000150f1  488b0570094600           mov rax, qword ptr [rip + 0x460970]
000150f8  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000150ff  0f8598050000             jne 0x1569d
00015105  e946030000               jmp 0x15450
0001510a  83ff08                   cmp edi, 8
0001510d  7414                     je 0x15123
0001510f  488b0552094600           mov rax, qword ptr [rip + 0x460952]
00015116  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001511d  0f8592050000             jne 0x156b5
00015123  488b8ee0000000           mov rcx, qword ptr [rsi + 0xe0]
0001512a  4c8d4630                 lea r8, [rsi + 0x30]
0001512e  4c8bcb                   mov r9, rbx
00015131  897c2420                 mov dword ptr [rsp + 0x20], edi
00015135  8bd7                     mov edx, edi
00015137  e814240000               call 0x17550
0001513c  488d4e30                 lea rcx, [rsi + 0x30]
00015140  448bc0                   mov r8d, eax
00015143  e8f8eeffff               call 0x14040
00015148  488b1519094600           mov rdx, qword ptr [rip + 0x460919]
0001514f  3c07                     cmp al, 7
00015151  760d                     jbe 0x15160
00015153  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
0001515a  0f856d050000             jne 0x156cd
00015160  0fb6c8                   movzx ecx, al
00015163  410fb6c0                 movzx eax, r8b
00015167  664139848fc8410600       cmp word ptr [r15 + rcx*4 + 0x641c8], ax
00015170  0f8463020000             je 0x153d9
00015176  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
0001517d  0f8562050000             jne 0x156e5
00015183  e951020000               jmp 0x153d9
00015188  488d4e30                 lea rcx, [rsi + 0x30]
0001518c  e8cf2cffff               call 0x7e60
00015191  440fb7c0                 movzx r8d, ax
00015195  413bf8                   cmp edi, r8d
00015198  7414                     je 0x151ae
0001519a  488b05c7084600           mov rax, qword ptr [rip + 0x4608c7]
000151a1  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000151a8  0f854f050000             jne 0x156fd
000151ae  4c8bbee0000000           mov r15, qword ptr [rsi + 0xe0]
000151b5  498bf0                   mov rsi, r8
000151b8  8bef                     mov ebp, edi
000151ba  85ff                     test edi, edi
000151bc  7467                     je 0x15225
000151be  4885db                   test rbx, rbx
000151c1  751b                     jne 0x151de
000151c3  ff15cfdf0400             call qword ptr [rip + 0x4dfcf]
000151c9  c70016000000             mov dword ptr [rax], 0x16
000151cf  ff15cbdf0400             call qword ptr [rip + 0x4dfcb]
000151d5  41887e1b                 mov byte ptr [r14 + 0x1b], dil
000151d9  e917fcffff               jmp 0x14df5
000151de  4d85ff                   test r15, r15
000151e1  741c                     je 0x151ff
000151e3  483bf5                   cmp rsi, rbp
000151e6  7217                     jb 0x151ff
000151e8  4c8bc5                   mov r8, rbp
000151eb  498bd7                   mov rdx, r15
000151ee  488bcb                   mov rcx, rbx
000151f1  e81d900400               call 0x5e213
000151f6  41887e1b                 mov byte ptr [r14 + 0x1b], dil
000151fa  e9f6fbffff               jmp 0x14df5
000151ff  33d2                     xor edx, edx
00015201  488bcb                   mov rcx, rbx
00015204  e822900400               call 0x5e22b
00015209  4d85ff                   test r15, r15
0001520c  74b5                     je 0x151c3
0001520e  483bf5                   cmp rsi, rbp
00015211  7312                     jae 0x15225
00015213  ff157fdf0400             call qword ptr [rip + 0x4df7f]
00015219  c70022000000             mov dword ptr [rax], 0x22
0001521f  ff157bdf0400             call qword ptr [rip + 0x4df7b]
00015225  41887e1b                 mov byte ptr [r14 + 0x1b], dil
00015229  e9c7fbffff               jmp 0x14df5
0001522e  488d4e30                 lea rcx, [rsi + 0x30]
00015232  e8292cffff               call 0x7e60
00015237  440fb7c0                 movzx r8d, ax
0001523b  488b0526084600           mov rax, qword ptr [rip + 0x460826]
00015242  413bf8                   cmp edi, r8d
00015245  740d                     je 0x15254
00015247  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001524e  0f85c1040000             jne 0x15715
00015254  83ff04                   cmp edi, 4
00015257  740d                     je 0x15266
00015259  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00015260  0f85c7040000             jne 0x1572d
00015266  488b8ee0000000           mov rcx, qword ptr [rsi + 0xe0]
0001526d  8bc7                     mov eax, edi
0001526f  85ff                     test edi, edi
00015271  746a                     je 0x152dd
00015273  4885db                   test rbx, rbx
00015276  751e                     jne 0x15296
00015278  ff151adf0400             call qword ptr [rip + 0x4df1a]
0001527e  c70016000000             mov dword ptr [rax], 0x16
00015284  ff1516df0400             call qword ptr [rip + 0x4df16]
0001528a  8b03                     mov eax, dword ptr [rbx]
0001528c  c1c010                   rol eax, 0x10
0001528f  8903                     mov dword ptr [rbx], eax
00015291  e95ffbffff               jmp 0x14df5
00015296  4885c9                   test rcx, rcx
00015299  7420                     je 0x152bb
0001529b  4883f808                 cmp rax, 8
0001529f  771a                     ja 0x152bb
000152a1  488bd1                   mov rdx, rcx
000152a4  4c8bc0                   mov r8, rax
000152a7  488bcb                   mov rcx, rbx
000152aa  e8648f0400               call 0x5e213
000152af  8b03                     mov eax, dword ptr [rbx]
000152b1  c1c010                   rol eax, 0x10
000152b4  8903                     mov dword ptr [rbx], eax
000152b6  e93afbffff               jmp 0x14df5
000152bb  33d2                     xor edx, edx
000152bd  488913                   mov qword ptr [rbx], rdx
000152c0  4885c9                   test rcx, rcx
000152c3  74b3                     je 0x15278
000152c5  4883f808                 cmp rax, 8
000152c9  7612                     jbe 0x152dd
000152cb  ff15c7de0400             call qword ptr [rip + 0x4dec7]
000152d1  c70022000000             mov dword ptr [rax], 0x22
000152d7  ff15c3de0400             call qword ptr [rip + 0x4dec3]
000152dd  8b03                     mov eax, dword ptr [rbx]
000152df  c1c010                   rol eax, 0x10
000152e2  8903                     mov dword ptr [rbx], eax
000152e4  e90cfbffff               jmp 0x14df5
000152e9  83ff05                   cmp edi, 5
000152ec  7414                     je 0x15302
000152ee  488b0573074600           mov rax, qword ptr [rip + 0x460773]
000152f5  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000152fc  0f8543040000             jne 0x15745
00015302  488b8ee0000000           mov rcx, qword ptr [rsi + 0xe0]
00015309  4c8d4630                 lea r8, [rsi + 0x30]
0001530d  4c8bcb                   mov r9, rbx
00015310  897c2420                 mov dword ptr [rsp + 0x20], edi
00015314  8bd7                     mov edx, edi
00015316  e835220000               call 0x17550
0001531b  488d4e30                 lea rcx, [rsi + 0x30]
0001531f  448bc0                   mov r8d, eax
00015322  e819edffff               call 0x14040
00015327  488b153a074600           mov rdx, qword ptr [rip + 0x46073a]
0001532e  3c07                     cmp al, 7
00015330  760d                     jbe 0x1533f
00015332  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
00015339  0f851e040000             jne 0x1575d
0001533f  0fb6c8                   movzx ecx, al
00015342  410fb6c0                 movzx eax, r8b
00015346  664139848f40420600       cmp word ptr [r15 + rcx*4 + 0x64240], ax
0001534f  0f8484000000             je 0x153d9
00015355  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
0001535c  0f8513040000             jne 0x15775
00015362  eb75                     jmp 0x153d9
00015364  83ff0a                   cmp edi, 0xa
00015367  7414                     je 0x1537d
00015369  488b05f8064600           mov rax, qword ptr [rip + 0x4606f8]
00015370  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00015377  0f8510040000             jne 0x1578d
0001537d  488b8ee0000000           mov rcx, qword ptr [rsi + 0xe0]
00015384  4c8d4630                 lea r8, [rsi + 0x30]
00015388  4c8bcb                   mov r9, rbx
0001538b  897c2420                 mov dword ptr [rsp + 0x20], edi
0001538f  8bd7                     mov edx, edi
00015391  e8ba210000               call 0x17550
00015396  488d4e30                 lea rcx, [rsi + 0x30]
0001539a  448bc0                   mov r8d, eax
0001539d  e89eecffff               call 0x14040
000153a2  488b15bf064600           mov rdx, qword ptr [rip + 0x4606bf]
000153a9  3c07                     cmp al, 7
000153ab  760d                     jbe 0x153ba
000153ad  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
000153b4  0f85eb030000             jne 0x157a5
000153ba  0fb6c8                   movzx ecx, al
000153bd  410fb6c0                 movzx eax, r8b
000153c1  664139848fb0420600       cmp word ptr [r15 + rcx*4 + 0x642b0], ax
000153ca  740d                     je 0x153d9
000153cc  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
000153d3  0f85e4030000             jne 0x157bd
000153d9  4588461b                 mov byte ptr [r14 + 0x1b], r8b
000153dd  e913faffff               jmp 0x14df5
000153e2  83ff11                   cmp edi, 0x11
000153e5  7414                     je 0x153fb
000153e7  488b057a064600           mov rax, qword ptr [rip + 0x46067a]
000153ee  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000153f5  0f85da030000             jne 0x157d5
000153fb  80c210                   add dl, 0x10
000153fe  80fa01                   cmp dl, 1
00015401  7607                     jbe 0x1540a
00015403  440fb64e42               movzx r9d, byte ptr [rsi + 0x42]
00015408  eb09                     jmp 0x15413
0001540a  470fb68c87725b0600       movzx r9d, byte ptr [r15 + r8*4 + 0x65b72]
00015413  488d4e30                 lea rcx, [rsi + 0x30]
00015417  e824ecffff               call 0x14040
0001541c  488b96e0000000           mov rdx, qword ptr [rsi + 0xe0]
00015423  488bcb                   mov rcx, rbx
00015426  448bc7                   mov r8d, edi
00015429  88442420                 mov byte ptr [rsp + 0x20], al
0001542d  e89eebffff               call 0x13fd0
00015432  e9bef9ffff               jmp 0x14df5
00015437  83ff08                   cmp edi, 8
0001543a  7414                     je 0x15450
0001543c  488b0525064600           mov rax, qword ptr [rip + 0x460625]
00015443  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001544a  0f859d030000             jne 0x157ed
00015450  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
00015457  4885db                   test rbx, rbx
0001545a  741d                     je 0x15479
0001545c  4885c0                   test rax, rax
0001545f  7415                     je 0x15476
00015461  488b00                   mov rax, qword ptr [rax]
00015464  488903                   mov qword ptr [rbx], rax
00015467  8bc8                     mov ecx, eax
00015469  8b4304                   mov eax, dword ptr [rbx + 4]
0001546c  8903                     mov dword ptr [rbx], eax
0001546e  894b04                   mov dword ptr [rbx + 4], ecx
00015471  e97ff9ffff               jmp 0x14df5
00015476  488903                   mov qword ptr [rbx], rax
00015479  ff1519dd0400             call qword ptr [rip + 0x4dd19]
0001547f  c70016000000             mov dword ptr [rax], 0x16
00015485  ff1515dd0400             call qword ptr [rip + 0x4dd15]
0001548b  8b0b                     mov ecx, dword ptr [rbx]
0001548d  8b4304                   mov eax, dword ptr [rbx + 4]
00015490  8903                     mov dword ptr [rbx], eax
00015492  894b04                   mov dword ptr [rbx + 4], ecx
00015495  e95bf9ffff               jmp 0x14df5
0001549a  488d4e30                 lea rcx, [rsi + 0x30]
0001549e  e8bd29ffff               call 0x7e60
000154a3  440fb7c0                 movzx r8d, ax
000154a7  413bf8                   cmp edi, r8d
000154aa  7414                     je 0x154c0
000154ac  488b05b5054600           mov rax, qword ptr [rip + 0x4605b5]
000154b3  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000154ba  0f8545030000             jne 0x15805
000154c0  488b96e0000000           mov rdx, qword ptr [rsi + 0xe0]
000154c7  448bc7                   mov r8d, edi
000154ca  85ff                     test edi, edi
000154cc  0f8423f9ffff             je 0x14df5
000154d2  4885db                   test rbx, rbx
000154d5  7417                     je 0x154ee
000154d7  488bcb                   mov rcx, rbx
000154da  4885d2                   test rdx, rdx
000154dd  740a                     je 0x154e9
000154df  e82f8d0400               call 0x5e213
000154e4  e90cf9ffff               jmp 0x14df5
000154e9  e83d8d0400               call 0x5e22b
000154ee  ff15a4dc0400             call qword ptr [rip + 0x4dca4]
000154f4  c70016000000             mov dword ptr [rax], 0x16
000154fa  ff15a0dc0400             call qword ptr [rip + 0x4dca0]
00015500  e9f0f8ffff               jmp 0x14df5

; chunk at RVA 0x15505 (34 bytes)
00015505  33ff                     xor edi, edi
00015507  4c8d0512980800           lea r8, [rip + 0x89812]
0001550e  488d15fb960800           lea rdx, [rip + 0x896fb]
00015515  48897c2420               mov qword ptr [rsp + 0x20], rdi
0001551a  448d4f68                 lea r9d, [rdi + 0x68]
0001551e  8d4f01                   lea ecx, [rdi + 1]
00015521  e85a3e0000               call 0x19380
00015526  cc                       int3

; chunk at RVA 0x15527 (953 bytes)
00015527  41b91e010000             mov r9d, 0x11e
0001552d  48897c2420               mov qword ptr [rsp + 0x20], rdi
00015532  4c8d05e7970800           lea r8, [rip + 0x897e7]
00015539  b901000000               mov ecx, 1
0001553e  488d1593a20800           lea rdx, [rip + 0x8a293]
00015545  e8363e0000               call 0x19380
0001554a  cc                       int3
0001554b  41b91e010000             mov r9d, 0x11e
00015551  48897c2420               mov qword ptr [rsp + 0x20], rdi
00015556  4c8d05c3970800           lea r8, [rip + 0x897c3]
0001555d  b901000000               mov ecx, 1
00015562  488d156fa20800           lea rdx, [rip + 0x8a26f]
00015569  e8123e0000               call 0x19380
0001556e  cc                       int3
0001556f  ba32000000               mov edx, 0x32
00015574  b94f010000               mov ecx, 0x14f
00015579  41b9c8000000             mov r9d, 0xc8
0001557f  448d42de                 lea r8d, [rdx - 0x22]
00015583  e8183e0000               call 0x193a0
00015588  cc                       int3
00015589  ba32000000               mov edx, 0x32
0001558e  b94f010000               mov ecx, 0x14f
00015593  41b9c9000000             mov r9d, 0xc9
00015599  448d42de                 lea r8d, [rdx - 0x22]
0001559d  e8fe3d0000               call 0x193a0
000155a2  cc                       int3
000155a3  ba32000000               mov edx, 0x32
000155a8  b94f010000               mov ecx, 0x14f
000155ad  41b9ca000000             mov r9d, 0xca
000155b3  448d42de                 lea r8d, [rdx - 0x22]
000155b7  e8e43d0000               call 0x193a0
000155bc  cc                       int3
000155bd  ba32000000               mov edx, 0x32
000155c2  b94f010000               mov ecx, 0x14f
000155c7  41b9cb000000             mov r9d, 0xcb
000155cd  448d42de                 lea r8d, [rdx - 0x22]
000155d1  e8ca3d0000               call 0x193a0
000155d6  cc                       int3
000155d7  ba32000000               mov edx, 0x32
000155dc  b94f010000               mov ecx, 0x14f
000155e1  41b9cc000000             mov r9d, 0xcc
000155e7  448d42de                 lea r8d, [rdx - 0x22]
000155eb  e8b03d0000               call 0x193a0
000155f0  cc                       int3
000155f1  ba32000000               mov edx, 0x32
000155f6  b94f010000               mov ecx, 0x14f
000155fb  41b9cd000000             mov r9d, 0xcd
00015601  448d42de                 lea r8d, [rdx - 0x22]
00015605  e8963d0000               call 0x193a0
0001560a  cc                       int3
0001560b  ba32000000               mov edx, 0x32
00015610  b94f010000               mov ecx, 0x14f
00015615  41b9ce000000             mov r9d, 0xce
0001561b  448d42de                 lea r8d, [rdx - 0x22]
0001561f  e87c3d0000               call 0x193a0
00015624  cc                       int3
00015625  ba32000000               mov edx, 0x32
0001562a  b94f010000               mov ecx, 0x14f
0001562f  448d4980                 lea r9d, [rcx - 0x80]
00015633  448d42de                 lea r8d, [rdx - 0x22]
00015637  e8643d0000               call 0x193a0
0001563c  cc                       int3
0001563d  ba32000000               mov edx, 0x32
00015642  b94f010000               mov ecx, 0x14f
00015647  448d4981                 lea r9d, [rcx - 0x7f]
0001564b  448d42de                 lea r8d, [rdx - 0x22]
0001564f  e84c3d0000               call 0x193a0
00015654  cc                       int3
00015655  ba32000000               mov edx, 0x32
0001565a  b94f010000               mov ecx, 0x14f
0001565f  448d4982                 lea r9d, [rcx - 0x7e]
00015663  448d42de                 lea r8d, [rdx - 0x22]
00015667  e8343d0000               call 0x193a0
0001566c  cc                       int3
0001566d  ba32000000               mov edx, 0x32
00015672  b94f010000               mov ecx, 0x14f
00015677  448d4983                 lea r9d, [rcx - 0x7d]
0001567b  448d42de                 lea r8d, [rdx - 0x22]
0001567f  e81c3d0000               call 0x193a0
00015684  cc                       int3
00015685  ba32000000               mov edx, 0x32
0001568a  b94f010000               mov ecx, 0x14f
0001568f  448d4984                 lea r9d, [rcx - 0x7c]
00015693  448d42de                 lea r8d, [rdx - 0x22]
00015697  e8043d0000               call 0x193a0
0001569c  cc                       int3
0001569d  ba32000000               mov edx, 0x32
000156a2  b94f010000               mov ecx, 0x14f
000156a7  448d4985                 lea r9d, [rcx - 0x7b]
000156ab  448d42de                 lea r8d, [rdx - 0x22]
000156af  e8ec3c0000               call 0x193a0
000156b4  cc                       int3
000156b5  ba32000000               mov edx, 0x32
000156ba  b94f010000               mov ecx, 0x14f
000156bf  448d4986                 lea r9d, [rcx - 0x7a]
000156c3  448d42de                 lea r8d, [rdx - 0x22]
000156c7  e8d43c0000               call 0x193a0
000156cc  cc                       int3
000156cd  ba32000000               mov edx, 0x32
000156d2  b94f010000               mov ecx, 0x14f
000156d7  448d4987                 lea r9d, [rcx - 0x79]
000156db  448d42de                 lea r8d, [rdx - 0x22]
000156df  e8bc3c0000               call 0x193a0
000156e4  cc                       int3
000156e5  ba32000000               mov edx, 0x32
000156ea  b94f010000               mov ecx, 0x14f
000156ef  448d4988                 lea r9d, [rcx - 0x78]
000156f3  448d42de                 lea r8d, [rdx - 0x22]
000156f7  e8a43c0000               call 0x193a0
000156fc  cc                       int3
000156fd  ba32000000               mov edx, 0x32
00015702  b94f010000               mov ecx, 0x14f
00015707  448d4989                 lea r9d, [rcx - 0x77]
0001570b  448d42de                 lea r8d, [rdx - 0x22]
0001570f  e88c3c0000               call 0x193a0
00015714  cc                       int3
00015715  ba32000000               mov edx, 0x32
0001571a  b94f010000               mov ecx, 0x14f
0001571f  448d498a                 lea r9d, [rcx - 0x76]
00015723  448d42de                 lea r8d, [rdx - 0x22]
00015727  e8743c0000               call 0x193a0
0001572c  cc                       int3
0001572d  ba32000000               mov edx, 0x32
00015732  b94f010000               mov ecx, 0x14f
00015737  448d498b                 lea r9d, [rcx - 0x75]
0001573b  448d42de                 lea r8d, [rdx - 0x22]
0001573f  e85c3c0000               call 0x193a0
00015744  cc                       int3
00015745  ba32000000               mov edx, 0x32
0001574a  b94f010000               mov ecx, 0x14f
0001574f  448d498c                 lea r9d, [rcx - 0x74]
00015753  448d42de                 lea r8d, [rdx - 0x22]
00015757  e8443c0000               call 0x193a0
0001575c  cc                       int3
0001575d  ba32000000               mov edx, 0x32
00015762  b94f010000               mov ecx, 0x14f
00015767  448d498d                 lea r9d, [rcx - 0x73]
0001576b  448d42de                 lea r8d, [rdx - 0x22]
0001576f  e82c3c0000               call 0x193a0
00015774  cc                       int3
00015775  ba32000000               mov edx, 0x32
0001577a  b94f010000               mov ecx, 0x14f
0001577f  448d498e                 lea r9d, [rcx - 0x72]
00015783  448d42de                 lea r8d, [rdx - 0x22]
00015787  e8143c0000               call 0x193a0
0001578c  cc                       int3
0001578d  ba32000000               mov edx, 0x32
00015792  b94f010000               mov ecx, 0x14f
00015797  448d498f                 lea r9d, [rcx - 0x71]
0001579b  448d42de                 lea r8d, [rdx - 0x22]
0001579f  e8fc3b0000               call 0x193a0
000157a4  cc                       int3
000157a5  ba32000000               mov edx, 0x32
000157aa  b94f010000               mov ecx, 0x14f
000157af  448d4990                 lea r9d, [rcx - 0x70]
000157b3  448d42de                 lea r8d, [rdx - 0x22]
000157b7  e8e43b0000               call 0x193a0
000157bc  cc                       int3
000157bd  ba32000000               mov edx, 0x32
000157c2  b94f010000               mov ecx, 0x14f
000157c7  448d4991                 lea r9d, [rcx - 0x6f]
000157cb  448d42de                 lea r8d, [rdx - 0x22]
000157cf  e8cc3b0000               call 0x193a0
000157d4  cc                       int3
000157d5  ba32000000               mov edx, 0x32
000157da  b94f010000               mov ecx, 0x14f
000157df  448d4992                 lea r9d, [rcx - 0x6e]
000157e3  448d42de                 lea r8d, [rdx - 0x22]
000157e7  e8b43b0000               call 0x193a0
000157ec  cc                       int3
000157ed  ba32000000               mov edx, 0x32
000157f2  b94f010000               mov ecx, 0x14f
000157f7  448d4993                 lea r9d, [rcx - 0x6d]
000157fb  448d42de                 lea r8d, [rdx - 0x22]
000157ff  e89c3b0000               call 0x193a0
00015804  cc                       int3
00015805  ba32000000               mov edx, 0x32
0001580a  b94f010000               mov ecx, 0x14f
0001580f  448d4994                 lea r9d, [rcx - 0x6c]
00015813  448d42de                 lea r8d, [rdx - 0x22]
00015817  e8843b0000               call 0x193a0
0001581c  cc                       int3
0001581d  41b968000000             mov r9d, 0x68
00015823  48897c2420               mov qword ptr [rsp + 0x20], rdi
00015828  4c8d0599940800           lea r8, [rip + 0x89499]
0001582f  488d15da930800           lea rdx, [rip + 0x893da]
00015836  418d4999                 lea ecx, [r9 - 0x67]
0001583a  e8413b0000               call 0x19380
0001583f  cc                       int3
