; ex_raise
; aetm_enclave.dll, primary RVA 0x193a0, 791 bytes in 1 chunk(s)

; chunk at RVA 0x193a0 (791 bytes)
000193a0  44894c2420               mov dword ptr [rsp + 0x20], r9d
000193a5  55                       push rbp
000193a6  53                       push rbx
000193a7  56                       push rsi
000193a8  57                       push rdi
000193a9  4156                     push r14
000193ab  4157                     push r15
000193ad  488dac24b8f7ffff         lea rbp, [rsp - 0x848]
000193b5  4881ec48090000           sub rsp, 0x948
000193bc  488b05451c0900           mov rax, qword ptr [rip + 0x91c45]
000193c3  4833c4                   xor rax, rsp
000193c6  48898530080000           mov qword ptr [rbp + 0x830], rax
000193cd  418bd8                   mov ebx, r8d
000193d0  4c8dbda0080000           lea r15, [rbp + 0x8a0]
000193d7  8bf2                     mov esi, edx
000193d9  448bf1                   mov r14d, ecx
000193dc  33d2                     xor edx, edx
000193de  488d8db0030000           lea rcx, [rbp + 0x3b0]
000193e5  41b880040000             mov r8d, 0x480
000193eb  418bf9                   mov edi, r9d
000193ee  e8384e0400               call 0x5e22b
000193f3  488d8520040000           lea rax, [rbp + 0x420]
000193fa  4489b5b4030000           mov dword ptr [rbp + 0x3b4], r14d
00019401  48898520080000           mov qword ptr [rbp + 0x820], rax
00019408  418bce                   mov ecx, r14d
0001940b  89b5b8030000             mov dword ptr [rbp + 0x3b8], esi
00019411  488d8520080000           lea rax, [rbp + 0x820]
00019418  48898528080000           mov qword ptr [rbp + 0x828], rax
0001941f  899dbc030000             mov dword ptr [rbp + 0x3bc], ebx
00019425  89bdc0030000             mov dword ptr [rbp + 0x3c0], edi
0001942b  c785b003000004000000     mov dword ptr [rbp + 0x3b0], 4
00019435  81e94b010000             sub ecx, 0x14b
0001943b  0f84d8000000             je 0x19519
00019441  83e904                   sub ecx, 4
00019444  0f8483000000             je 0x194cd
0001944a  83f906                   cmp ecx, 6
0001944d  0f8554010000             jne 0x195a7
00019453  8bce                     mov ecx, esi
00019455  83e901                   sub ecx, 1
00019458  7450                     je 0x194aa
0001945a  83e901                   sub ecx, 1
0001945d  7409                     je 0x19468
0001945f  83f901                   cmp ecx, 1
00019462  0f853f010000             jne 0x195a7
00019468  418b17                   mov edx, dword ptr [r15]
0001946b  488d8db0030000           lea rcx, [rbp + 0x3b0]
00019472  e8e995feff               call 0x2a60
00019477  418b5708                 mov edx, dword ptr [r15 + 8]
0001947b  488d8db0030000           lea rcx, [rbp + 0x3b0]
00019482  e8d995feff               call 0x2a60
00019487  488d95b0030000           lea rdx, [rbp + 0x3b0]
0001948e  488d4c2430               lea rcx, [rsp + 0x30]
00019493  e84896feff               call 0x2ae0
00019498  488d1559f70800           lea rdx, [rip + 0x8f759]
0001949f  488d4c2430               lea rcx, [rsp + 0x30]
000194a4  e85f4b0400               call 0x5e008
000194a9  cc                       int3
000194aa  488d95b0030000           lea rdx, [rbp + 0x3b0]
000194b1  488d4c2430               lea rcx, [rsp + 0x30]
000194b6  e82596feff               call 0x2ae0
000194bb  488d1536f70800           lea rdx, [rip + 0x8f736]
000194c2  488d4c2430               lea rcx, [rsp + 0x30]
000194c7  e83c4b0400               call 0x5e008
000194cc  cc                       int3
000194cd  8d46db                   lea eax, [rsi - 0x25]
000194d0  83f834                   cmp eax, 0x34
000194d3  0f87ce000000             ja 0x195a7
000194d9  488d15206bfeff           lea rdx, [rip - 0x194e0]
000194e0  4898                     cdqe
000194e2  0fb6840214960100         movzx eax, byte ptr [rdx + rax + 0x19614]
000194ea  8b8c820c960100           mov ecx, dword ptr [rdx + rax*4 + 0x1960c]
000194f1  4803ca                   add rcx, rdx
000194f4  ffe1                     jmp rcx
000194f6  488d95b0030000           lea rdx, [rbp + 0x3b0]
000194fd  488d4c2430               lea rcx, [rsp + 0x30]
00019502  e8d995feff               call 0x2ae0
00019507  488d15eaf60800           lea rdx, [rip + 0x8f6ea]
0001950e  488d4c2430               lea rcx, [rsp + 0x30]
00019513  e8f04a0400               call 0x5e008
00019518  cc                       int3
00019519  8d46ff                   lea eax, [rsi - 1]
0001951c  83f85e                   cmp eax, 0x5e
0001951f  0f8782000000             ja 0x195a7
00019525  488d15d46afeff           lea rdx, [rip - 0x1952c]
0001952c  4898                     cdqe
0001952e  0fb6840258960100         movzx eax, byte ptr [rdx + rax + 0x19658]
00019536  8b8c824c960100           mov ecx, dword ptr [rdx + rax*4 + 0x1964c]
0001953d  4803ca                   add rcx, rdx
00019540  ffe1                     jmp rcx
00019542  498b17                   mov rdx, qword ptr [r15]
00019545  488d8db0030000           lea rcx, [rbp + 0x3b0]
0001954c  e81ffeffff               call 0x19370
00019551  418b5708                 mov edx, dword ptr [r15 + 8]
00019555  488d8db0030000           lea rcx, [rbp + 0x3b0]
0001955c  e8ff94feff               call 0x2a60
00019561  488d95b0030000           lea rdx, [rbp + 0x3b0]
00019568  488d4c2430               lea rcx, [rsp + 0x30]
0001956d  e86e95feff               call 0x2ae0
00019572  488d157ff60800           lea rdx, [rip + 0x8f67f]
00019579  488d4c2430               lea rcx, [rsp + 0x30]
0001957e  e8854a0400               call 0x5e008
00019583  cc                       int3
00019584  488d95b0030000           lea rdx, [rbp + 0x3b0]
0001958b  488d4c2430               lea rcx, [rsp + 0x30]
00019590  e84b95feff               call 0x2ae0
00019595  488d155cf60800           lea rdx, [rip + 0x8f65c]
0001959c  488d4c2430               lea rcx, [rsp + 0x30]
000195a1  e8624a0400               call 0x5e008
000195a6  cc                       int3
000195a7  41b910000000             mov r9d, 0x10
000195ad  c744242001000000         mov dword ptr [rsp + 0x20], 1
000195b5  ba4b010000               mov edx, 0x14b
000195ba  488d8db0030000           lea rcx, [rbp + 0x3b0]
000195c1  458d414c                 lea r8d, [r9 + 0x4c]
000195c5  e846fdffff               call 0x19310
000195ca  488d8db0030000           lea rcx, [rbp + 0x3b0]
000195d1  418bd6                   mov edx, r14d
000195d4  e88794feff               call 0x2a60
000195d9  8bd6                     mov edx, esi
000195db  488d8db0030000           lea rcx, [rbp + 0x3b0]
000195e2  e87994feff               call 0x2a60
000195e7  488d95b0030000           lea rdx, [rbp + 0x3b0]
000195ee  488d4c2430               lea rcx, [rsp + 0x30]
000195f3  e8e894feff               call 0x2ae0
000195f8  488d15f9f50800           lea rdx, [rip + 0x8f5f9]
000195ff  488d4c2430               lea rcx, [rsp + 0x30]
00019604  e8ff490400               call 0x5e008
00019609  cc                       int3
0001960a  6690                     nop
0001960c  f6940100a79501           not byte ptr [rcx + rax + 0x195a700]
00019613  0000                     add byte ptr [rax], al
00019615  0101                     add dword ptr [rcx], eax
00019617  0101                     add dword ptr [rcx], eax
00019619  0101                     add dword ptr [rcx], eax
0001961b  0101                     add dword ptr [rcx], eax
0001961d  0001                     add byte ptr [rcx], al
0001961f  0000                     add byte ptr [rax], al
00019621  0000                     add byte ptr [rax], al
00019623  0101                     add dword ptr [rcx], eax
00019625  0101                     add dword ptr [rcx], eax
00019627  0101                     add dword ptr [rcx], eax
00019629  0101                     add dword ptr [rcx], eax
0001962b  0101                     add dword ptr [rcx], eax
0001962d  0101                     add dword ptr [rcx], eax
0001962f  0101                     add dword ptr [rcx], eax
00019631  0101                     add dword ptr [rcx], eax
00019633  0101                     add dword ptr [rcx], eax
00019635  0101                     add dword ptr [rcx], eax
00019637  0101                     add dword ptr [rcx], eax
00019639  0101                     add dword ptr [rcx], eax
0001963b  0101                     add dword ptr [rcx], eax
0001963d  0101                     add dword ptr [rcx], eax
0001963f  0101                     add dword ptr [rcx], eax
00019641  0101                     add dword ptr [rcx], eax
00019643  0101                     add dword ptr [rcx], eax
00019645  0101                     add dword ptr [rcx], eax
00019647  0000                     add byte ptr [rax], al
00019649  0f1f00                   nop dword ptr [rax]
0001964c  4295                     xchg ebp, eax
0001964e  0100                     add dword ptr [rax], eax
00019650  84950100a795             test byte ptr [rbp - 0x6a58ffff], dl
00019656  0100                     add dword ptr [rax], eax
00019658  0002                     add byte ptr [rdx], al
0001965a  0202                     add al, byte ptr [rdx]
0001965c  0202                     add al, byte ptr [rdx]
0001965e  0202                     add al, byte ptr [rdx]
00019660  0202                     add al, byte ptr [rdx]
00019662  0202                     add al, byte ptr [rdx]
00019664  0202                     add al, byte ptr [rdx]
00019666  0202                     add al, byte ptr [rdx]
00019668  0202                     add al, byte ptr [rdx]
0001966a  0202                     add al, byte ptr [rdx]
0001966c  0202                     add al, byte ptr [rdx]
0001966e  0202                     add al, byte ptr [rdx]
00019670  0202                     add al, byte ptr [rdx]
00019672  0202                     add al, byte ptr [rdx]
00019674  0202                     add al, byte ptr [rdx]
00019676  0202                     add al, byte ptr [rdx]
00019678  0202                     add al, byte ptr [rdx]
0001967a  0202                     add al, byte ptr [rdx]
0001967c  0202                     add al, byte ptr [rdx]
0001967e  0202                     add al, byte ptr [rdx]
00019680  0202                     add al, byte ptr [rdx]
00019682  0202                     add al, byte ptr [rdx]
00019684  0202                     add al, byte ptr [rdx]
00019686  0202                     add al, byte ptr [rdx]
00019688  0202                     add al, byte ptr [rdx]
0001968a  0202                     add al, byte ptr [rdx]
0001968c  0202                     add al, byte ptr [rdx]
0001968e  0202                     add al, byte ptr [rdx]
00019690  0202                     add al, byte ptr [rdx]
00019692  0202                     add al, byte ptr [rdx]
00019694  0202                     add al, byte ptr [rdx]
00019696  0202                     add al, byte ptr [rdx]
00019698  0202                     add al, byte ptr [rdx]
0001969a  0202                     add al, byte ptr [rdx]
0001969c  0202                     add al, byte ptr [rdx]
0001969e  0202                     add al, byte ptr [rdx]
000196a0  0202                     add al, byte ptr [rdx]
000196a2  0202                     add al, byte ptr [rdx]
000196a4  0202                     add al, byte ptr [rdx]
000196a6  0202                     add al, byte ptr [rdx]
000196a8  0202                     add al, byte ptr [rdx]
000196aa  0202                     add al, byte ptr [rdx]
000196ac  0202                     add al, byte ptr [rdx]
000196ae  0102                     add dword ptr [rdx], eax
000196b0  0101                     add dword ptr [rcx], eax
000196b2  0202                     add al, byte ptr [rdx]
000196b4  0200                     add al, byte ptr [rax]
