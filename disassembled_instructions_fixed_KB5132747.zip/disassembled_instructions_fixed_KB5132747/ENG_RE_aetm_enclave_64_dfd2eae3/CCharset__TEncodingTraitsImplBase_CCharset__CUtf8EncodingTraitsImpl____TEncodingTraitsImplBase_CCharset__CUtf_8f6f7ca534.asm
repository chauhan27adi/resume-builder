; CCharset::TEncodingTraitsImplBase<CCharset::CUtf8EncodingTraitsImpl>::~TEncodingTraitsImplBase<CCharset::CUtf8EncodingTraitsImpl>
; aetm_enclave.dll, primary RVA 0x34cf0, 32 bytes in 1 chunk(s)

; chunk at RVA 0x34cf0 (32 bytes)
00034cf0  48894c2408               mov qword ptr [rsp + 8], rcx
00034cf5  4883ec18                 sub rsp, 0x18
00034cf9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00034d01  488d0558010300           lea rax, [rip + 0x30158]
00034d08  488901                   mov qword ptr [rcx], rax
00034d0b  4883c418                 add rsp, 0x18
00034d0f  c3                       ret
