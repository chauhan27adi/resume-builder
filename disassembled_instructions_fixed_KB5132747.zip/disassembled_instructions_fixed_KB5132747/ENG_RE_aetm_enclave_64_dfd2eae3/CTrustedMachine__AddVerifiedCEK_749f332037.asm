; CTrustedMachine::AddVerifiedCEK
; aetm_enclave.dll, primary RVA 0xedb0, 925 bytes in 1 chunk(s)

; chunk at RVA 0xedb0 (925 bytes)
0000edb0  488bc4                   mov rax, rsp
0000edb3  57                       push rdi
0000edb4  4154                     push r12
0000edb6  4155                     push r13
0000edb8  4156                     push r14
0000edba  4157                     push r15
0000edbc  4881ec80000000           sub rsp, 0x80
0000edc3  48c740a0feffffff         mov qword ptr [rax - 0x60], 0xfffffffffffffffe
0000edcb  48895810                 mov qword ptr [rax + 0x10], rbx
0000edcf  48896818                 mov qword ptr [rax + 0x18], rbp
0000edd3  48897020                 mov qword ptr [rax + 0x20], rsi
0000edd7  488b052ac20900           mov rax, qword ptr [rip + 0x9c22a]
0000edde  4833c4                   xor rax, rsp
0000ede1  4889442470               mov qword ptr [rsp + 0x70], rax
0000ede6  4d8be9                   mov r13, r9
0000ede9  4489442424               mov dword ptr [rsp + 0x24], r8d
0000edee  440fb7ca                 movzx r9d, dx
0000edf2  6689542420               mov word ptr [rsp + 0x20], dx
0000edf7  4c8be1                   mov r12, rcx
0000edfa  4c8bbc24d0000000         mov r15, qword ptr [rsp + 0xd0]
0000ee02  488da9c0da4700           lea rbp, [rcx + 0x47dac0]
0000ee09  488bc5                   mov rax, rbp
0000ee0c  4c8d91c0da5000           lea r10, [rcx + 0x50dac0]
0000ee13  90                       nop
0000ee14  0fb68900db4700           movzx ecx, byte ptr [rcx + 0x47db00]
0000ee1b  493bea                   cmp rbp, r10
0000ee1e  7312                     jae 0xee32
0000ee20  84c9                     test cl, cl
0000ee22  750e                     jne 0xee32
0000ee24  4883c048                 add rax, 0x48
0000ee28  90                       nop
0000ee29  0fb64840                 movzx ecx, byte ptr [rax + 0x40]
0000ee2d  493bc2                   cmp rax, r10
0000ee30  72ee                     jb 0xee20
0000ee32  488bd0                   mov rdx, rax
0000ee35  90                       nop
0000ee36  410fb64a40               movzx ecx, byte ptr [r10 + 0x40]
0000ee3b  493bc2                   cmp rax, r10
0000ee3e  0f849b000000             je 0xeedf
0000ee44  66443908                 cmp word ptr [rax], r9w
0000ee48  750c                     jne 0xee56
0000ee4a  44394004                 cmp dword ptr [rax + 4], r8d
0000ee4e  7506                     jne 0xee56
0000ee50  4c396808                 cmp qword ptr [rax + 8], r13
0000ee54  742e                     je 0xee84
0000ee56  4883c048                 add rax, 0x48
0000ee5a  493bd2                   cmp rdx, r10
0000ee5d  480f43c2                 cmovae rax, rdx
0000ee61  90                       nop
0000ee62  0fb64840                 movzx ecx, byte ptr [rax + 0x40]
0000ee66  493bc2                   cmp rax, r10
0000ee69  73c7                     jae 0xee32
0000ee6b  0f1f440000               nop dword ptr [rax + rax]
0000ee70  84c9                     test cl, cl
0000ee72  75be                     jne 0xee32
0000ee74  4883c048                 add rax, 0x48
0000ee78  90                       nop
0000ee79  0fb64840                 movzx ecx, byte ptr [rax + 0x40]
0000ee7d  493bc2                   cmp rax, r10
0000ee80  72ee                     jb 0xee70
0000ee82  ebae                     jmp 0xee32
0000ee84  90                       nop
0000ee85  0fb64840                 movzx ecx, byte ptr [rax + 0x40]
0000ee89  482bd5                   sub rdx, rbp
0000ee8c  48c1fa03                 sar rdx, 3
0000ee90  48b9398ee3388ee3388e     movabs rcx, 0x8e38e38e38e38e39
0000ee9a  480fafd1                 imul rdx, rcx
0000ee9e  90                       nop
0000ee9f  488b4838                 mov rcx, qword ptr [rax + 0x38]
0000eea3  4863c2                   movsxd rax, edx
0000eea6  48c1e020                 shl rax, 0x20
0000eeaa  48c1e920                 shr rcx, 0x20
0000eeae  480bc1                   or rax, rcx
0000eeb1  488b4c2470               mov rcx, qword ptr [rsp + 0x70]
0000eeb6  4833cc                   xor rcx, rsp
0000eeb9  e812df0400               call 0x5cdd0
0000eebe  4c8d9c2480000000         lea r11, [rsp + 0x80]
0000eec6  498b5b38                 mov rbx, qword ptr [r11 + 0x38]
0000eeca  498b6b40                 mov rbp, qword ptr [r11 + 0x40]
0000eece  498b7348                 mov rsi, qword ptr [r11 + 0x48]
0000eed2  498be3                   mov rsp, r11
0000eed5  415f                     pop r15
0000eed7  415e                     pop r14
0000eed9  415d                     pop r13
0000eedb  415c                     pop r12
0000eedd  5f                       pop rdi
0000eede  c3                       ret
0000eedf  48638d00800900           movsxd rcx, dword ptr [rbp + 0x98000]
0000eee6  48c7c3ffffffff           mov rbx, 0xffffffffffffffff
0000eeed  85c9                     test ecx, ecx
0000eeef  7505                     jne 0xeef6
0000eef1  488bfb                   mov rdi, rbx
0000eef4  eb2b                     jmp 0xef21
0000eef6  8d41ff                   lea eax, [rcx - 1]
0000eef9  898500800900             mov dword ptr [rbp + 0x98000], eax
0000eeff  4863bc8dfcff0800         movsxd rdi, dword ptr [rbp + rcx*4 + 0x8fffc]
0000ef07  488d04ff                 lea rax, [rdi + rdi*8]
0000ef0b  c644c54101               mov byte ptr [rbp + rax*8 + 0x41], 1
0000ef10  90                       nop
0000ef11  488b4cc538               mov rcx, qword ptr [rbp + rax*8 + 0x38]
0000ef16  48c1e720                 shl rdi, 0x20
0000ef1a  48c1e920                 shr rcx, 0x20
0000ef1e  480bf9                   or rdi, rcx
0000ef21  48896c2428               mov qword ptr [rsp + 0x28], rbp
0000ef26  48897c2430               mov qword ptr [rsp + 0x30], rdi
0000ef2b  498db424b85a4100         lea rsi, [r12 + 0x415ab8]
0000ef33  48638e00800600           movsxd rcx, dword ptr [rsi + 0x68000]
0000ef3a  85c9                     test ecx, ecx
0000ef3c  742e                     je 0xef6c
0000ef3e  8d41ff                   lea eax, [rcx - 1]
0000ef41  898600800600             mov dword ptr [rsi + 0x68000], eax
0000ef47  48639c8efcff0500         movsxd rbx, dword ptr [rsi + rcx*4 + 0x5fffc]
0000ef4f  488d045b                 lea rax, [rbx + rbx*2]
0000ef53  4803c0                   add rax, rax
0000ef56  c644c62901               mov byte ptr [rsi + rax*8 + 0x29], 1
0000ef5b  90                       nop
0000ef5c  488b44c620               mov rax, qword ptr [rsi + rax*8 + 0x20]
0000ef61  48c1e320                 shl rbx, 0x20
0000ef65  48c1e820                 shr rax, 0x20
0000ef69  480bd8                   or rbx, rax
0000ef6c  4889742438               mov qword ptr [rsp + 0x38], rsi
0000ef71  48895c2440               mov qword ptr [rsp + 0x40], rbx
0000ef76  4883ffff                 cmp rdi, -1
0000ef7a  0f84b5010000             je 0xf135
0000ef80  4d85ff                   test r15, r15
0000ef83  7415                     je 0xef9a
0000ef85  410f1007                 movups xmm0, xmmword ptr [r15]
0000ef89  0f11442450               movups xmmword ptr [rsp + 0x50], xmm0
0000ef8e  410f104f10               movups xmm1, xmmword ptr [r15 + 0x10]
0000ef93  0f114c2460               movups xmmword ptr [rsp + 0x60], xmm1
0000ef98  eb1f                     jmp 0xefb9
0000ef9a  0f57c0                   xorps xmm0, xmm0
0000ef9d  0f11442450               movups xmmword ptr [rsp + 0x50], xmm0
0000efa2  0f11442460               movups xmmword ptr [rsp + 0x60], xmm0
0000efa7  ff15eb410500             call qword ptr [rip + 0x541eb]
0000efad  c70016000000             mov dword ptr [rax], 0x16
0000efb3  ff15e7410500             call qword ptr [rip + 0x541e7]
0000efb9  488bc3                   mov rax, rbx
0000efbc  48c1e820                 shr rax, 0x20
0000efc0  25ff1f0000               and eax, 0x1fff
0000efc5  4c8d3440                 lea r14, [rax + rax*2]
0000efc9  49c1e604                 shl r14, 4
0000efcd  4903f6                   add rsi, r14
0000efd0  90                       nop
0000efd1  0fb64e29                 movzx ecx, byte ptr [rsi + 0x29]
0000efd5  90                       nop
0000efd6  488b4620                 mov rax, qword ptr [rsi + 0x20]
0000efda  48c1e820                 shr rax, 0x20
0000efde  3bc3                     cmp eax, ebx
0000efe0  0f8537010000             jne 0xf11d
0000efe6  84c9                     test cl, cl
0000efe8  0f842f010000             je 0xf11d
0000efee  4d8b4c2408               mov r9, qword ptr [r12 + 8]
0000eff3  41b802000000             mov r8d, 2
0000eff9  488d542450               lea rdx, [rsp + 0x50]
0000effe  488bce                   mov rcx, rsi
0000f001  e84aa3ffff               call 0x9350
0000f006  4d8b4c2408               mov r9, qword ptr [r12 + 8]
0000f00b  41b802000000             mov r8d, 2
0000f011  488d542450               lea rdx, [rsp + 0x50]
0000f016  488bce                   mov rcx, rsi
0000f019  e832a3ffff               call 0x9350
0000f01e  488bc7                   mov rax, rdi
0000f021  48c1e820                 shr rax, 0x20
0000f025  8bf0                     mov esi, eax
0000f027  25ff1f0000               and eax, 0x1fff
0000f02c  488d04c0                 lea rax, [rax + rax*8]
0000f030  4c8d24c500000000         lea r12, [rax*8]
0000f038  90                       nop
0000f039  410fb64c2c41             movzx ecx, byte ptr [r12 + rbp + 0x41]
0000f03f  90                       nop
0000f040  498b442c38               mov rax, qword ptr [r12 + rbp + 0x38]
0000f045  48c1e820                 shr rax, 0x20
0000f049  3bc7                     cmp eax, edi
0000f04b  0f85cc000000             jne 0xf11d
0000f051  84c9                     test cl, cl
0000f053  0f84c4000000             je 0xf11d
0000f059  0fb7442420               movzx eax, word ptr [rsp + 0x20]
0000f05e  664189042c               mov word ptr [r12 + rbp], ax
0000f063  8b442424                 mov eax, dword ptr [rsp + 0x24]
0000f067  4189442c04               mov dword ptr [r12 + rbp + 4], eax
0000f06c  4d896c2c08               mov qword ptr [r12 + rbp + 8], r13
0000f071  49895c2c30               mov qword ptr [r12 + rbp + 0x30], rbx
0000f076  488d4510                 lea rax, [rbp + 0x10]
0000f07a  4903c4                   add rax, r12
0000f07d  7421                     je 0xf0a0
0000f07f  4d85ff                   test r15, r15
0000f082  7412                     je 0xf096
0000f084  410f1007                 movups xmm0, xmmword ptr [r15]
0000f088  0f1100                   movups xmmword ptr [rax], xmm0
0000f08b  410f104f10               movups xmm1, xmmword ptr [r15 + 0x10]
0000f090  0f114810                 movups xmmword ptr [rax + 0x10], xmm1
0000f094  eb1c                     jmp 0xf0b2
0000f096  0f57c0                   xorps xmm0, xmm0
0000f099  0f1100                   movups xmmword ptr [rax], xmm0
0000f09c  0f114010                 movups xmmword ptr [rax + 0x10], xmm0
0000f0a0  ff15f2400500             call qword ptr [rip + 0x540f2]
0000f0a6  c70016000000             mov dword ptr [rax], 0x16
0000f0ac  ff15ee400500             call qword ptr [rip + 0x540ee]
0000f0b2  48ff058f684600           inc qword ptr [rip + 0x46688f]
0000f0b9  4883fbff                 cmp rbx, -1
0000f0bd  7424                     je 0xf0e3
0000f0bf  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
0000f0c4  90                       nop
0000f0c5  420fb6543129             movzx edx, byte ptr [rcx + r14 + 0x29]
0000f0cb  90                       nop
0000f0cc  4a8b443120               mov rax, qword ptr [rcx + r14 + 0x20]
0000f0d1  48c1e820                 shr rax, 0x20
0000f0d5  3bc3                     cmp eax, ebx
0000f0d7  750a                     jne 0xf0e3
0000f0d9  84d2                     test dl, dl
0000f0db  7406                     je 0xf0e3
0000f0dd  42c644312801             mov byte ptr [rcx + r14 + 0x28], 1
0000f0e3  488b442428               mov rax, qword ptr [rsp + 0x28]
0000f0e8  90                       nop
0000f0e9  410fb6540441             movzx edx, byte ptr [r12 + rax + 0x41]
0000f0ef  90                       nop
0000f0f0  498b4c0438               mov rcx, qword ptr [r12 + rax + 0x38]
0000f0f5  48c1e920                 shr rcx, 0x20
0000f0f9  3bcf                     cmp ecx, edi
0000f0fb  7518                     jne 0xf115
0000f0fd  84d2                     test dl, dl
0000f0ff  7414                     je 0xf115
0000f101  81e6ff1f0000             and esi, 0x1fff
0000f107  488d14f6                 lea rdx, [rsi + rsi*8]
0000f10b  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
0000f110  c644d14001               mov byte ptr [rcx + rdx*8 + 0x40], 1
0000f115  488bc7                   mov rax, rdi
0000f118  e994fdffff               jmp 0xeeb1
0000f11d  ba5f000000               mov edx, 0x5f
0000f122  b94b010000               mov ecx, 0x14b
0000f127  448d4aa2                 lea r9d, [rdx - 0x5e]
0000f12b  448d42b2                 lea r8d, [rdx - 0x4e]
0000f12f  e86ca20000               call 0x193a0
0000f134  cc                       int3
0000f135  ba59000000               mov edx, 0x59
0000f13a  b94b010000               mov ecx, 0x14b
0000f13f  448d4aa9                 lea r9d, [rdx - 0x57]
0000f143  448d42b7                 lea r8d, [rdx - 0x49]
0000f147  e854a20000               call 0x193a0
0000f14c  cc                       int3
