; CSqlSortManager_90::DBCompareStringWFast
; aetm_enclave.dll, primary RVA 0x4a3b0, 6192 bytes in 3 chunk(s)

; chunk at RVA 0x4a3b0 (141 bytes)
0004a3b0  4489442418               mov dword ptr [rsp + 0x18], r8d
0004a3b5  4889542410               mov qword ptr [rsp + 0x10], rdx
0004a3ba  48894c2408               mov qword ptr [rsp + 8], rcx
0004a3bf  55                       push rbp
0004a3c0  56                       push rsi
0004a3c1  4154                     push r12
0004a3c3  4156                     push r14
0004a3c5  4157                     push r15
0004a3c7  488d6c24d0               lea rbp, [rsp - 0x30]
0004a3cc  4881ec30010000           sub rsp, 0x130
0004a3d3  448bb580000000           mov r14d, dword ptr [rbp + 0x80]
0004a3da  4533d2                   xor r10d, r10d
0004a3dd  4c8bbd88000000           mov r15, qword ptr [rbp + 0x88]
0004a3e4  4d8be1                   mov r12, r9
0004a3e7  448955b8                 mov dword ptr [rbp - 0x48], r10d
0004a3eb  458bc8                   mov r9d, r8d
0004a3ee  448955a0                 mov dword ptr [rbp - 0x60], r10d
0004a3f2  488bf2                   mov rsi, rdx
0004a3f5  448955b0                 mov dword ptr [rbp - 0x50], r10d
0004a3f9  458bc2                   mov r8d, r10d
0004a3fc  c745fc08000000           mov dword ptr [rbp - 4], 8
0004a403  448955e0                 mov dword ptr [rbp - 0x20], r10d
0004a407  4585f6                   test r14d, r14d
0004a40a  7405                     je 0x4a411
0004a40c  4d85e4                   test r12, r12
0004a40f  741a                     je 0x4a42b
0004a411  448b9d90000000           mov r11d, dword ptr [rbp + 0x90]
0004a418  4585db                   test r11d, r11d
0004a41b  7405                     je 0x4a422
0004a41d  4d85ff                   test r15, r15
0004a420  7409                     je 0x4a42b
0004a422  41f7c1f8effc77           test r9d, 0x77fceff8
0004a429  7412                     je 0x4a43d
0004a42b  33c0                     xor eax, eax
0004a42d  4881c430010000           add rsp, 0x130
0004a434  415f                     pop r15
0004a436  415e                     pop r14
0004a438  415c                     pop r12
0004a43a  5e                       pop rsi
0004a43b  5d                       pop rbp
0004a43c  c3                       ret

; chunk at RVA 0x4a43d (5947 bytes)
0004a43d  4889bc2420010000         mov qword ptr [rsp + 0x120], rdi
0004a445  4585f6                   test r14d, r14d
0004a448  7911                     jns 0x4a45b
0004a44a  498bcc                   mov rcx, r12
0004a44d  e85ed4ffff               call 0x478b0
0004a452  448bf0                   mov r14d, eax
0004a455  898580000000             mov dword ptr [rbp + 0x80], eax
0004a45b  4585db                   test r11d, r11d
0004a45e  7911                     jns 0x4a471
0004a460  498bcf                   mov rcx, r15
0004a463  e848d4ffff               call 0x478b0
0004a468  448bd8                   mov r11d, eax
0004a46b  898590000000             mov dword ptr [rbp + 0x90], eax
0004a471  418bc9                   mov ecx, r9d
0004a474  48899c2428010000         mov qword ptr [rsp + 0x128], rbx
0004a47c  c1e910                   shr ecx, 0x10
0004a47f  418bc1                   mov eax, r9d
0004a482  83e103                   and ecx, 3
0004a485  4c89ac2418010000         mov qword ptr [rsp + 0x118], r13
0004a48d  83e003                   and eax, 3
0004a490  bf07000000               mov edi, 7
0004a495  897d88                   mov dword ptr [rbp - 0x78], edi
0004a498  8d0c88                   lea ecx, [rax + rcx*4]
0004a49b  488d055e5bfbff           lea rax, [rip - 0x4a4a2]
0004a4a2  8b848830050900           mov eax, dword ptr [rax + rcx*4 + 0x90530]
0004a4a9  448d4ffa                 lea r9d, [rdi - 6]
0004a4ad  418bca                   mov ecx, r10d
0004a4b0  894590                   mov dword ptr [rbp - 0x70], eax
0004a4b3  0fb702                   movzx eax, word ptr [rdx]
0004a4b6  ba12040000               mov edx, 0x412
0004a4bb  663bc2                   cmp ax, dx
0004a4be  668945a4                 mov word ptr [rbp - 0x5c], ax
0004a4c2  498bd2                   mov rdx, r10
0004a4c5  0f94c1                   sete cl
0004a4c8  488955d0                 mov qword ptr [rbp - 0x30], rdx
0004a4cc  894df8                   mov dword ptr [rbp - 8], ecx
0004a4cf  498bca                   mov rcx, r10
0004a4d2  48894de8                 mov qword ptr [rbp - 0x18], rcx
0004a4d6  448d57fc                 lea r10d, [rdi - 4]
0004a4da  4585f6                   test r14d, r14d
0004a4dd  7467                     je 0x4a546
0004a4df  4585db                   test r11d, r11d
0004a4e2  7462                     je 0x4a546
0004a4e4  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004a4e8  410fb70424               movzx eax, word ptr [r12]
0004a4ed  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004a4f0  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004a4f4  410fb707                 movzx eax, word ptr [r15]
0004a4f8  4423ef                   and r13d, edi
0004a4fb  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004a4ff  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
0004a502  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a508  8b8d80000000             mov ecx, dword ptr [rbp + 0x80]
0004a50e  8945e4                   mov dword ptr [rbp - 0x1c], eax
0004a511  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a517  8945c8                   mov dword ptr [rbp - 0x38], eax
0004a51a  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a520  8945c4                   mov dword ptr [rbp - 0x3c], eax
0004a523  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a529  8945bc                   mov dword ptr [rbp - 0x44], eax
0004a52c  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a532  8945c0                   mov dword ptr [rbp - 0x40], eax
0004a535  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004a53b  8945b4                   mov dword ptr [rbp - 0x4c], eax
0004a53e  894d8c                   mov dword ptr [rbp - 0x74], ecx
0004a541  e9ee000000               jmp 0x4a634
0004a546  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a54c  8b5d84                   mov ebx, dword ptr [rbp - 0x7c]
0004a54f  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004a555  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004a559  8945e4                   mov dword ptr [rbp - 0x1c], eax
0004a55c  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a562  8945c8                   mov dword ptr [rbp - 0x38], eax
0004a565  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a56b  8945c4                   mov dword ptr [rbp - 0x3c], eax
0004a56e  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a574  8945bc                   mov dword ptr [rbp - 0x44], eax
0004a577  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a57d  8945c0                   mov dword ptr [rbp - 0x40], eax
0004a580  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004a586  8945b4                   mov dword ptr [rbp - 0x4c], eax
0004a589  895d98                   mov dword ptr [rbp - 0x68], ebx
0004a58c  89558c                   mov dword ptr [rbp - 0x74], edx
0004a58f  eb0d                     jmp 0x4a59e
0004a591  488b4de8                 mov rcx, qword ptr [rbp - 0x18]
0004a595  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004a598  41ba03000000             mov r10d, 3
0004a59e  f7457000000008           test dword ptr [rbp + 0x70], 0x8000000
0004a5a5  0f84e2140000             je 0x4ba8d
0004a5ab  4585f6                   test r14d, r14d
0004a5ae  7547                     jne 0x4a5f7
0004a5b0  4585db                   test r11d, r11d
0004a5b3  0f848a150000             je 0x4bb43
0004a5b9  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004a5bd  4c8d65d8                 lea r12, [rbp - 0x28]
0004a5c1  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004a5c4  b820000000               mov eax, 0x20
0004a5c9  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
0004a5cd  458bf1                   mov r14d, r9d
0004a5d0  668945d8                 mov word ptr [rbp - 0x28], ax
0004a5d4  448ba980000000           mov r13d, dword ptr [rcx + 0x80]
0004a5db  4423ef                   and r13d, edi
0004a5de  44898d80000000           mov dword ptr [rbp + 0x80], r9d
0004a5e5  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004a5e9  4585c0                   test r8d, r8d
0004a5ec  754e                     jne 0x4a63c
0004a5ee  410fb707                 movzx eax, word ptr [r15]
0004a5f2  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
0004a5f5  eb3d                     jmp 0x4a634
0004a5f7  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004a5fb  b820000000               mov eax, 0x20
0004a600  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004a603  4c8d7ddc                 lea r15, [rbp - 0x24]
0004a607  668945dc                 mov word ptr [rbp - 0x24], ax
0004a60b  458bd9                   mov r11d, r9d
0004a60e  44898d90000000           mov dword ptr [rbp + 0x90], r9d
0004a615  4585c0                   test r8d, r8d
0004a618  7510                     jne 0x4a62a
0004a61a  410fb70424               movzx eax, word ptr [r12]
0004a61f  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004a623  4423ef                   and r13d, edi
0004a626  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004a62a  8b9980000000             mov ebx, dword ptr [rcx + 0x80]
0004a630  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
0004a634  23df                     and ebx, edi
0004a636  895d84                   mov dword ptr [rbp - 0x7c], ebx
0004a639  895d98                   mov dword ptr [rbp - 0x68], ebx
0004a63c  4533d2                   xor r10d, r10d
0004a63f  90                       nop
0004a640  837e1400                 cmp dword ptr [rsi + 0x14], 0
0004a644  448955a8                 mov dword ptr [rbp - 0x58], r10d
0004a648  448955f0                 mov dword ptr [rbp - 0x10], r10d
0004a64c  0f84e5020000             je 0x4a937
0004a652  4885d2                   test rdx, rdx
0004a655  0f856d010000             jne 0x4a7c8
0004a65b  418bc5                   mov eax, r13d
0004a65e  c1e818                   shr eax, 0x18
0004a661  a8c0                     test al, 0xc0
0004a663  0f845f010000             je 0x4a7c8
0004a669  395618                   cmp dword ptr [rsi + 0x18], edx
0004a66c  7438                     je 0x4a6a6
0004a66e  4183fe01                 cmp r14d, 1
0004a672  7e2e                     jle 0x4a6a2
0004a674  410fb74c2402             movzx ecx, word ptr [r12 + 2]
0004a67a  418bd5                   mov edx, r13d
0004a67d  488b4608                 mov rax, qword ptr [rsi + 8]
0004a681  331488                   xor edx, dword ptr [rax + rcx*4]
0004a684  23d7                     and edx, edi
0004a686  f7c2ffffffe7             test edx, 0xe7ffffff
0004a68c  7514                     jne 0x4a6a2
0004a68e  4983c402                 add r12, 2
0004a692  44894db8                 mov dword ptr [rbp - 0x48], r9d
0004a696  41ffce                   dec r14d
0004a699  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004a6a0  eb04                     jmp 0x4a6a6
0004a6a2  448955b8                 mov dword ptr [rbp - 0x48], r10d
0004a6a6  33d2                     xor edx, edx
0004a6a8  418bce                   mov ecx, r14d
0004a6ab  440fb7ca                 movzx r9d, dx
0004a6af  83e901                   sub ecx, 1
0004a6b2  7411                     je 0x4a6c5
0004a6b4  83f901                   cmp ecx, 1
0004a6b7  7406                     je 0x4a6bf
0004a6b9  450fb7542404             movzx r10d, word ptr [r12 + 4]
0004a6bf  450fb74c2402             movzx r9d, word ptr [r12 + 2]
0004a6c5  4c8b4620                 mov r8, qword ptr [rsi + 0x20]
0004a6c9  410fb70c24               movzx ecx, word ptr [r12]
0004a6ce  410fb74004               movzx eax, word ptr [r8 + 4]
0004a6d3  85c0                     test eax, eax
0004a6d5  0f84d0000000             je 0x4a7ab
0004a6db  0f1f440000               nop dword ptr [rax + rax]
0004a6e0  6641394806               cmp word ptr [r8 + 6], cx
0004a6e5  760e                     jbe 0x4a6f5
0004a6e7  4983c010                 add r8, 0x10
0004a6eb  83e801                   sub eax, 1
0004a6ee  75f0                     jne 0x4a6e0
0004a6f0  e9b6000000               jmp 0x4a7ab
0004a6f5  0f85b0000000             jne 0x4a7ab
0004a6fb  66453b480c               cmp r9w, word ptr [r8 + 0xc]
0004a700  0f82a5000000             jb 0x4a7ab
0004a706  66453b480e               cmp r9w, word ptr [r8 + 0xe]
0004a70b  0f879a000000             ja 0x4a7ab
0004a711  488b4628                 mov rax, qword ptr [rsi + 0x28]
0004a715  410fb74808               movzx ecx, word ptr [r8 + 8]
0004a71a  488d14c8                 lea rdx, [rax + rcx*8]
0004a71e  410fb7400a               movzx eax, word ptr [r8 + 0xa]
0004a723  85c0                     test eax, eax
0004a725  0f8480000000             je 0x4a7ab
0004a72b  0f1f440000               nop dword ptr [rax + rax]
0004a730  6644390a                 cmp word ptr [rdx], r9w
0004a734  760f                     jbe 0x4a745
0004a736  4883c208                 add rdx, 8
0004a73a  83e801                   sub eax, 1
0004a73d  75f1                     jne 0x4a730
0004a73f  eb6a                     jmp 0x4a7ab
0004a741  6644390a                 cmp word ptr [rdx], r9w
0004a745  7564                     jne 0x4a7ab
0004a747  0fb74a02                 movzx ecx, word ptr [rdx + 2]
0004a74b  6685c9                   test cx, cx
0004a74e  742c                     je 0x4a77c
0004a750  66413bca                 cmp cx, r10w
0004a754  740b                     je 0x4a761
0004a756  4883c208                 add rdx, 8
0004a75a  83e801                   sub eax, 1
0004a75d  75e2                     jne 0x4a741
0004a75f  eb4a                     jmp 0x4a7ab
0004a761  837db800                 cmp dword ptr [rbp - 0x48], 0
0004a765  750f                     jne 0x4a776
0004a767  4983c404                 add r12, 4
0004a76b  4183ee02                 sub r14d, 2
0004a76f  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004a776  410fb7ca                 movzx ecx, r10w
0004a77a  eb18                     jmp 0x4a794
0004a77c  837db800                 cmp dword ptr [rbp - 0x48], 0
0004a780  750e                     jne 0x4a790
0004a782  4983c402                 add r12, 2
0004a786  41ffce                   dec r14d
0004a789  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004a790  410fb7c9                 movzx ecx, r9w
0004a794  488b4608                 mov rax, qword ptr [rsi + 8]
0004a798  448b6a04                 mov r13d, dword ptr [rdx + 4]
0004a79c  4423ef                   and r13d, edi
0004a79f  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004a7a3  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004a7a6  23c7                     and eax, edi
0004a7a8  8945a0                   mov dword ptr [rbp - 0x60], eax
0004a7ab  837db800                 cmp dword ptr [rbp - 0x48], 0
0004a7af  41b901000000             mov r9d, 1
0004a7b5  740e                     je 0x4a7c5
0004a7b7  4983ec02                 sub r12, 2
0004a7bb  41ffc6                   inc r14d
0004a7be  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004a7c5  4533d2                   xor r10d, r10d
0004a7c8  48837de800               cmp qword ptr [rbp - 0x18], 0
0004a7cd  0f8564010000             jne 0x4a937
0004a7d3  f64587c0                 test byte ptr [rbp - 0x79], 0xc0
0004a7d7  0f845a010000             je 0x4a937
0004a7dd  837e1800                 cmp dword ptr [rsi + 0x18], 0
0004a7e1  743b                     je 0x4a81e
0004a7e3  4183fb01                 cmp r11d, 1
0004a7e7  7e2f                     jle 0x4a818
0004a7e9  410fb74f02               movzx ecx, word ptr [r15 + 2]
0004a7ee  8bd3                     mov edx, ebx
0004a7f0  488b4608                 mov rax, qword ptr [rsi + 8]
0004a7f4  331488                   xor edx, dword ptr [rax + rcx*4]
0004a7f7  23d7                     and edx, edi
0004a7f9  f7c2ffffffe7             test edx, 0xe7ffffff
0004a7ff  7517                     jne 0x4a818
0004a801  4983c702                 add r15, 2
0004a805  44894db8                 mov dword ptr [rbp - 0x48], r9d
0004a809  41ffcb                   dec r11d
0004a80c  458bd1                   mov r10d, r9d
0004a80f  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004a816  eb0a                     jmp 0x4a822
0004a818  448955b8                 mov dword ptr [rbp - 0x48], r10d
0004a81c  eb04                     jmp 0x4a822
0004a81e  448b55b8                 mov r10d, dword ptr [rbp - 0x48]
0004a822  33c0                     xor eax, eax
0004a824  418bcb                   mov ecx, r11d
0004a827  440fb7c8                 movzx r9d, ax
0004a82b  440fb7c0                 movzx r8d, ax
0004a82f  83e901                   sub ecx, 1
0004a832  740f                     je 0x4a843
0004a834  83f901                   cmp ecx, 1
0004a837  7405                     je 0x4a83e
0004a839  450fb74f04               movzx r9d, word ptr [r15 + 4]
0004a83e  450fb74702               movzx r8d, word ptr [r15 + 2]
0004a843  488b5620                 mov rdx, qword ptr [rsi + 0x20]
0004a847  410fb70f                 movzx ecx, word ptr [r15]
0004a84b  0fb74204                 movzx eax, word ptr [rdx + 4]
0004a84f  85c0                     test eax, eax
0004a851  0f84cd000000             je 0x4a924
0004a857  66394a06                 cmp word ptr [rdx + 6], cx
0004a85b  760e                     jbe 0x4a86b
0004a85d  4883c210                 add rdx, 0x10
0004a861  83e801                   sub eax, 1
0004a864  75f1                     jne 0x4a857
0004a866  e9b9000000               jmp 0x4a924
0004a86b  0f85b3000000             jne 0x4a924
0004a871  66443b420c               cmp r8w, word ptr [rdx + 0xc]
0004a876  0f82a8000000             jb 0x4a924
0004a87c  66443b420e               cmp r8w, word ptr [rdx + 0xe]
0004a881  0f879d000000             ja 0x4a924
0004a887  0fb74a08                 movzx ecx, word ptr [rdx + 8]
0004a88b  488b4628                 mov rax, qword ptr [rsi + 0x28]
0004a88f  488d04c8                 lea rax, [rax + rcx*8]
0004a893  0fb74a0a                 movzx ecx, word ptr [rdx + 0xa]
0004a897  85c9                     test ecx, ecx
0004a899  0f8485000000             je 0x4a924
0004a89f  90                       nop
0004a8a0  66443900                 cmp word ptr [rax], r8w
0004a8a4  760f                     jbe 0x4a8b5
0004a8a6  4883c008                 add rax, 8
0004a8aa  83e901                   sub ecx, 1
0004a8ad  75f1                     jne 0x4a8a0
0004a8af  eb73                     jmp 0x4a924
0004a8b1  66443900                 cmp word ptr [rax], r8w
0004a8b5  756d                     jne 0x4a924
0004a8b7  0fb75002                 movzx edx, word ptr [rax + 2]
0004a8bb  6685d2                   test dx, dx
0004a8be  7436                     je 0x4a8f6
0004a8c0  66413bd1                 cmp dx, r9w
0004a8c4  740b                     je 0x4a8d1
0004a8c6  4883c008                 add rax, 8
0004a8ca  83e901                   sub ecx, 1
0004a8cd  75e2                     jne 0x4a8b1
0004a8cf  eb53                     jmp 0x4a924
0004a8d1  4585d2                   test r10d, r10d
0004a8d4  750f                     jne 0x4a8e5
0004a8d6  4983c704                 add r15, 4
0004a8da  4183eb02                 sub r11d, 2
0004a8de  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004a8e5  8b5004                   mov edx, dword ptr [rax + 4]
0004a8e8  23d7                     and edx, edi
0004a8ea  410fb7c9                 movzx ecx, r9w
0004a8ee  895598                   mov dword ptr [rbp - 0x68], edx
0004a8f1  895584                   mov dword ptr [rbp - 0x7c], edx
0004a8f4  eb22                     jmp 0x4a918
0004a8f6  4585d2                   test r10d, r10d
0004a8f9  750e                     jne 0x4a909
0004a8fb  4983c702                 add r15, 2
0004a8ff  41ffcb                   dec r11d
0004a902  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004a909  8b4004                   mov eax, dword ptr [rax + 4]
0004a90c  23c7                     and eax, edi
0004a90e  410fb7c8                 movzx ecx, r8w
0004a912  894598                   mov dword ptr [rbp - 0x68], eax
0004a915  894584                   mov dword ptr [rbp - 0x7c], eax
0004a918  488b4608                 mov rax, qword ptr [rsi + 8]
0004a91c  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004a91f  23c7                     and eax, edi
0004a921  8945b0                   mov dword ptr [rbp - 0x50], eax
0004a924  4585d2                   test r10d, r10d
0004a927  740e                     je 0x4a937
0004a929  4983ef02                 sub r15, 2
0004a92d  41ffc3                   inc r11d
0004a930  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004a937  440fb74d80               movzx r9d, word ptr [rbp - 0x80]
0004a93c  440fb75584               movzx r10d, word ptr [rbp - 0x7c]
0004a941  410fb7f9                 movzx edi, r9w
0004a945  410fb7da                 movzx ebx, r10w
0004a949  66c1ef08                 shr di, 8
0004a94d  66c1eb08                 shr bx, 8
0004a951  6644898d88000000         mov word ptr [rbp + 0x88], r9w
0004a959  6644895578               mov word ptr [rbp + 0x78], r10w
0004a95e  4080ff0b                 cmp dil, 0xb
0004a962  7614                     jbe 0x4a978
0004a964  80fb0b                   cmp bl, 0xb
0004a967  7649                     jbe 0x4a9b2
0004a969  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004a96c  895db0                   mov dword ptr [rbp - 0x50], ebx
0004a96f  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004a973  e9490f0000               jmp 0x4b8c1
0004a978  4084ff                   test dil, dil
0004a97b  7535                     jne 0x4a9b2
0004a97d  448b4590                 mov r8d, dword ptr [rbp - 0x70]
0004a981  4983c402                 add r12, 2
0004a985  4183ee01                 sub r14d, 1
0004a989  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004a990  7414                     je 0x4a9a6
0004a992  410fb70c24               movzx ecx, word ptr [r12]
0004a997  488b4608                 mov rax, qword ptr [rsi + 8]
0004a99b  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004a99f  4523e8                   and r13d, r8d
0004a9a2  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004a9a6  ba01000000               mov edx, 1
0004a9ab  8bc2                     mov eax, edx
0004a9ad  8955a8                   mov dword ptr [rbp - 0x58], edx
0004a9b0  eb0c                     jmp 0x4a9be
0004a9b2  448b4590                 mov r8d, dword ptr [rbp - 0x70]
0004a9b6  ba01000000               mov edx, 1
0004a9bb  8b45a8                   mov eax, dword ptr [rbp - 0x58]
0004a9be  84db                     test bl, bl
0004a9c0  752a                     jne 0x4a9ec
0004a9c2  4983c702                 add r15, 2
0004a9c6  4183eb01                 sub r11d, 1
0004a9ca  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004a9d1  7414                     je 0x4a9e7
0004a9d3  410fb70f                 movzx ecx, word ptr [r15]
0004a9d7  488b4608                 mov rax, qword ptr [rsi + 8]
0004a9db  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004a9de  4123c0                   and eax, r8d
0004a9e1  894598                   mov dword ptr [rbp - 0x68], eax
0004a9e4  894584                   mov dword ptr [rbp - 0x7c], eax
0004a9e7  8bc2                     mov eax, edx
0004a9e9  8955a8                   mov dword ptr [rbp - 0x58], edx
0004a9ec  8b7570                   mov esi, dword ptr [rbp + 0x70]
0004a9ef  83e602                   and esi, 2
0004a9f2  7467                     je 0x4aa5b
0004a9f4  4080ff01                 cmp dil, 1
0004a9f8  752e                     jne 0x4aa28
0004a9fa  4983c402                 add r12, 2
0004a9fe  4183ee01                 sub r14d, 1
0004aa02  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004aa09  7418                     je 0x4aa23
0004aa0b  4c8b6d68                 mov r13, qword ptr [rbp + 0x68]
0004aa0f  410fb70c24               movzx ecx, word ptr [r12]
0004aa14  498b4508                 mov rax, qword ptr [r13 + 8]
0004aa18  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004aa1c  4523e8                   and r13d, r8d
0004aa1f  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004aa23  8bc2                     mov eax, edx
0004aa25  8955a8                   mov dword ptr [rbp - 0x58], edx
0004aa28  80fb01                   cmp bl, 1
0004aa2b  752e                     jne 0x4aa5b
0004aa2d  4983c702                 add r15, 2
0004aa31  4183eb01                 sub r11d, 1
0004aa35  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004aa3c  7418                     je 0x4aa56
0004aa3e  488b4568                 mov rax, qword ptr [rbp + 0x68]
0004aa42  410fb70f                 movzx ecx, word ptr [r15]
0004aa46  488b4008                 mov rax, qword ptr [rax + 8]
0004aa4a  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004aa4d  4123c0                   and eax, r8d
0004aa50  894598                   mov dword ptr [rbp - 0x68], eax
0004aa53  894584                   mov dword ptr [rbp - 0x7c], eax
0004aa56  8bc2                     mov eax, edx
0004aa58  8955a8                   mov dword ptr [rbp - 0x58], edx
0004aa5b  498bd7                   mov rdx, r15
0004aa5e  4d8bc4                   mov r8, r12
0004aa61  4080ff02                 cmp dil, 2
0004aa65  756a                     jne 0x4aad1
0004aa67  0fb64580                 movzx eax, byte ptr [rbp - 0x80]
0004aa6b  4c8d2d8e55fbff           lea r13, [rip - 0x4aa72]
0004aa72  41ffc6                   inc r14d
0004aa75  c745e402000000           mov dword ptr [rbp - 0x1c], 2
0004aa7c  4c8d65d8                 lea r12, [rbp - 0x28]
0004aa80  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004aa87  410fb78c85c0992d00       movzx ecx, word ptr [r13 + rax*4 + 0x2d99c0]
0004aa90  410fb78485c2992d00       movzx eax, word ptr [r13 + rax*4 + 0x2d99c2]
0004aa99  668945da                 mov word ptr [rbp - 0x26], ax
0004aa9d  488b4568                 mov rax, qword ptr [rbp + 0x68]
0004aaa1  66894dd8                 mov word ptr [rbp - 0x28], cx
0004aaa5  488b4008                 mov rax, qword ptr [rax + 8]
0004aaa9  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004aaad  33c0                     xor eax, eax
0004aaaf  488b4dd0                 mov rcx, qword ptr [rbp - 0x30]
0004aab3  44236d90                 and r13d, dword ptr [rbp - 0x70]
0004aab7  4885c9                   test rcx, rcx
0004aaba  8945a0                   mov dword ptr [rbp - 0x60], eax
0004aabd  b801000000               mov eax, 1
0004aac2  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004aac6  4c0f45c1                 cmovne r8, rcx
0004aaca  8945a8                   mov dword ptr [rbp - 0x58], eax
0004aacd  4c8945d0                 mov qword ptr [rbp - 0x30], r8
0004aad1  80fb02                   cmp bl, 2
0004aad4  7574                     jne 0x4ab4a
0004aad6  0fb64584                 movzx eax, byte ptr [rbp - 0x7c]
0004aada  4c8d051f55fbff           lea r8, [rip - 0x4aae1]
0004aae1  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004aae5  4c8d7ddc                 lea r15, [rbp - 0x24]
0004aae9  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004aaec  41ffc3                   inc r11d
0004aaef  4533d2                   xor r10d, r10d
0004aaf2  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004aaf9  410fb78c80c0992d00       movzx ecx, word ptr [r8 + rax*4 + 0x2d99c0]
0004ab02  41b901000000             mov r9d, 1
0004ab08  410fb78480c2992d00       movzx eax, word ptr [r8 + rax*4 + 0x2d99c2]
0004ab11  458bc1                   mov r8d, r9d
0004ab14  66894ddc                 mov word ptr [rbp - 0x24], cx
0004ab18  668945de                 mov word ptr [rbp - 0x22], ax
0004ab1c  488b4608                 mov rax, qword ptr [rsi + 8]
0004ab20  c745c802000000           mov dword ptr [rbp - 0x38], 2
0004ab27  448955b0                 mov dword ptr [rbp - 0x50], r10d
0004ab2b  8b1c88                   mov ebx, dword ptr [rax + rcx*4]
0004ab2e  488b4de8                 mov rcx, qword ptr [rbp - 0x18]
0004ab32  23df                     and ebx, edi
0004ab34  4885c9                   test rcx, rcx
0004ab37  895d98                   mov dword ptr [rbp - 0x68], ebx
0004ab3a  895d84                   mov dword ptr [rbp - 0x7c], ebx
0004ab3d  480f45d1                 cmovne rdx, rcx
0004ab41  488bca                   mov rcx, rdx
0004ab44  488955e8                 mov qword ptr [rbp - 0x18], rdx
0004ab48  eb1f                     jmp 0x4ab69
0004ab4a  85c0                     test eax, eax
0004ab4c  7439                     je 0x4ab87
0004ab4e  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004ab51  41b901000000             mov r9d, 1
0004ab57  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004ab5b  4533d2                   xor r10d, r10d
0004ab5e  448b45a8                 mov r8d, dword ptr [rbp - 0x58]
0004ab62  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004ab65  488b4de8                 mov rcx, qword ptr [rbp - 0x18]
0004ab69  8b558c                   mov edx, dword ptr [rbp - 0x74]
0004ab6c  4585f6                   test r14d, r14d
0004ab6f  0f8420faffff             je 0x4a595
0004ab75  4585db                   test r11d, r11d
0004ab78  0f8417faffff             je 0x4a595
0004ab7e  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
0004ab82  e9b9faffff               jmp 0x4a640
0004ab87  400fb6c7                 movzx eax, dil
0004ab8b  83f806                   cmp eax, 6
0004ab8e  0f8700030000             ja 0x4ae94
0004ab94  488d156554fbff           lea rdx, [rip - 0x4ab9b]
0004ab9b  8b8c8278bb0400           mov ecx, dword ptr [rdx + rax*4 + 0x4bb78]
0004aba2  4803ca                   add rcx, rdx
0004aba5  ffe1                     jmp rcx
0004aba7  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
0004abab  403adf                   cmp bl, dil
0004abae  0f84e8020000             je 0x4ae9c
0004abb4  837d8800                 cmp dword ptr [rbp - 0x78], 0
0004abb8  7f07                     jg 0x4abc1
0004abba  4183781000               cmp dword ptr [r8 + 0x10], 0
0004abbf  740c                     je 0x4abcd
0004abc1  33c0                     xor eax, eax
0004abc3  c7458c03000000           mov dword ptr [rbp - 0x74], 3
0004abca  894588                   mov dword ptr [rbp - 0x78], eax
0004abcd  418d46ff                 lea eax, [r14 - 1]
0004abd1  85c0                     test eax, eax
0004abd3  7427                     je 0x4abfc
0004abd5  498b5008                 mov rdx, qword ptr [r8 + 8]
0004abd9  0f1f8000000000           nop dword ptr [rax]
0004abe0  410fb7442402             movzx eax, word ptr [r12 + 2]
0004abe6  807c820101               cmp byte ptr [rdx + rax*4 + 1], 1
0004abeb  750f                     jne 0x4abfc
0004abed  41ffce                   dec r14d
0004abf0  4983c402                 add r12, 2
0004abf4  418d46ff                 lea eax, [r14 - 1]
0004abf8  85c0                     test eax, eax
0004abfa  75e4                     jne 0x4abe0
0004abfc  4983c402                 add r12, 2
0004ac00  4183ee01                 sub r14d, 1
0004ac04  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004ac0b  7415                     je 0x4ac22
0004ac0d  498b4008                 mov rax, qword ptr [r8 + 8]
0004ac11  410fb70c24               movzx ecx, word ptr [r12]
0004ac16  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004ac1a  44236d90                 and r13d, dword ptr [rbp - 0x70]
0004ac1e  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004ac22  c745a801000000           mov dword ptr [rbp - 0x58], 1
0004ac29  e96a020000               jmp 0x4ae98
0004ac2e  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004ac32  80fb06                   cmp bl, 6
0004ac35  0f845d020000             je 0x4ae98
0004ac3b  8b4d88                   mov ecx, dword ptr [rbp - 0x78]
0004ac3e  83f906                   cmp ecx, 6
0004ac41  7f08                     jg 0x4ac4b
0004ac43  7527                     jne 0x4ac6c
0004ac45  837dc400                 cmp dword ptr [rbp - 0x3c], 0
0004ac49  7521                     jne 0x4ac6c
0004ac4b  33c0                     xor eax, eax
0004ac4d  c745c401000000           mov dword ptr [rbp - 0x3c], 1
0004ac54  83f906                   cmp ecx, 6
0004ac57  c7458c03000000           mov dword ptr [rbp - 0x74], 3
0004ac5e  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004ac65  0f4e45bc                 cmovle eax, dword ptr [rbp - 0x44]
0004ac69  8945bc                   mov dword ptr [rbp - 0x44], eax
0004ac6c  4983c402                 add r12, 2
0004ac70  4183ee01                 sub r14d, 1
0004ac74  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004ac7b  74a5                     je 0x4ac22
0004ac7d  488b4568                 mov rax, qword ptr [rbp + 0x68]
0004ac81  488b4008                 mov rax, qword ptr [rax + 8]
0004ac85  eb8a                     jmp 0x4ac11
0004ac87  80fb06                   cmp bl, 6
0004ac8a  0f8408020000             je 0x4ae98
0004ac90  80fb01                   cmp bl, 1
0004ac93  0f84ff010000             je 0x4ae98
0004ac99  8b45b0                   mov eax, dword ptr [rbp - 0x50]
0004ac9c  4c8d8d80000000           lea r9, [rbp + 0x80]
0004aca3  488b5568                 mov rdx, qword ptr [rbp + 0x68]
0004aca7  4c8d4598                 lea r8, [rbp - 0x68]
0004acab  33c9                     xor ecx, ecx
0004acad  4c896598                 mov qword ptr [rbp - 0x68], r12
0004acb1  894da0                   mov dword ptr [rbp - 0x60], ecx
0004acb4  80fb04                   cmp bl, 4
0004acb7  4c897d00                 mov qword ptr [rbp], r15
0004acbb  0f44c1                   cmove eax, ecx
0004acbe  c745f001000000           mov dword ptr [rbp - 0x10], 1
0004acc5  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0004acc9  8945b0                   mov dword ptr [rbp - 0x50], eax
0004accc  8b45f8                   mov eax, dword ptr [rbp - 8]
0004accf  89442478                 mov dword ptr [rsp + 0x78], eax
0004acd3  488d45e0                 lea rax, [rbp - 0x20]
0004acd7  4889442470               mov qword ptr [rsp + 0x70], rax
0004acdc  488d45fc                 lea rax, [rbp - 4]
0004ace0  4889442468               mov qword ptr [rsp + 0x68], rax
0004ace5  488d4578                 lea rax, [rbp + 0x78]
0004ace9  4889442460               mov qword ptr [rsp + 0x60], rax
0004acee  488d8588000000           lea rax, [rbp + 0x88]
0004acf5  4889442458               mov qword ptr [rsp + 0x58], rax
0004acfa  488d4584                 lea rax, [rbp - 0x7c]
0004acfe  4889442448               mov qword ptr [rsp + 0x48], rax
0004ad03  488d8590000000           lea rax, [rbp + 0x90]
0004ad0a  44895c2440               mov dword ptr [rsp + 0x40], r11d
0004ad0f  4889442438               mov qword ptr [rsp + 0x38], rax
0004ad14  488d4500                 lea rax, [rbp]
0004ad18  4889442430               mov qword ptr [rsp + 0x30], rax
0004ad1d  488d4580                 lea rax, [rbp - 0x80]
0004ad21  4889442428               mov qword ptr [rsp + 0x28], rax
0004ad26  4489742420               mov dword ptr [rsp + 0x20], r14d
0004ad2b  e8705b0000               call 0x508a0
0004ad30  8bc8                     mov ecx, eax
0004ad32  8945a8                   mov dword ptr [rbp - 0x58], eax
0004ad35  8b45e0                   mov eax, dword ptr [rbp - 0x20]
0004ad38  83f802                   cmp eax, 2
0004ad3b  0f850f0e0000             jne 0x4bb50
0004ad41  4c8b6598                 mov r12, qword ptr [rbp - 0x68]
0004ad45  4c8b7d00                 mov r15, qword ptr [rbp]
0004ad49  448bb580000000           mov r14d, dword ptr [rbp + 0x80]
0004ad50  448b9d90000000           mov r11d, dword ptr [rbp + 0x90]
0004ad57  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
0004ad5b  440fb78d88000000         movzx r9d, word ptr [rbp + 0x88]
0004ad63  440fb75578               movzx r10d, word ptr [rbp + 0x78]
0004ad68  85c9                     test ecx, ecx
0004ad6a  7434                     je 0x4ada0
0004ad6c  4585f6                   test r14d, r14d
0004ad6f  7e2f                     jle 0x4ada0
0004ad71  4585db                   test r11d, r11d
0004ad74  7e2a                     jle 0x4ada0
0004ad76  498b4808                 mov rcx, qword ptr [r8 + 8]
0004ad7a  410fb70424               movzx eax, word ptr [r12]
0004ad7f  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004ad83  44236d90                 and r13d, dword ptr [rbp - 0x70]
0004ad87  410fb707                 movzx eax, word ptr [r15]
0004ad8b  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004ad8f  8b1481                   mov edx, dword ptr [rcx + rax*4]
0004ad92  235590                   and edx, dword ptr [rbp - 0x70]
0004ad95  895598                   mov dword ptr [rbp - 0x68], edx
0004ad98  895584                   mov dword ptr [rbp - 0x7c], edx
0004ad9b  e9ff000000               jmp 0x4ae9f
0004ada0  8b5584                   mov edx, dword ptr [rbp - 0x7c]
0004ada3  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004ada7  895598                   mov dword ptr [rbp - 0x68], edx
0004adaa  e9f0000000               jmp 0x4ae9f
0004adaf  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
0004adb3  410fb70424               movzx eax, word ptr [r12]
0004adb8  498b4808                 mov rcx, qword ptr [r8 + 8]
0004adbc  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004adc0  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004adc4  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004adc8  80fb05                   cmp bl, 5
0004adcb  7560                     jne 0x4ae2d
0004adcd  410fb707                 movzx eax, word ptr [r15]
0004add1  450fb6cd                 movzx r9d, r13b
0004add5  6641c1e108               shl r9w, 8
0004adda  8b1481                   mov edx, dword ptr [rcx + rax*4]
0004addd  8bc2                     mov eax, edx
0004addf  c1e810                   shr eax, 0x10
0004ade2  418bcd                   mov ecx, r13d
0004ade5  440fb6d0                 movzx r10d, al
0004ade9  0fb6c2                   movzx eax, dl
0004adec  66c1e008                 shl ax, 8
0004adf0  66440bd0                 or r10w, ax
0004adf4  c1e910                   shr ecx, 0x10
0004adf7  0fb6c1                   movzx eax, cl
0004adfa  66440bc8                 or r9w, ax
0004adfe  895598                   mov dword ptr [rbp - 0x68], edx
0004ae01  b812040000               mov eax, 0x412
0004ae06  895584                   mov dword ptr [rbp - 0x7c], edx
0004ae09  6644895578               mov word ptr [rbp + 0x78], r10w
0004ae0e  6644898d88000000         mov word ptr [rbp + 0x88], r9w
0004ae16  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004ae1a  743d                     je 0x4ae59
0004ae1c  b8fffe0000               mov eax, 0xfeff
0004ae21  668945a0                 mov word ptr [rbp - 0x60], ax
0004ae25  8b45a0                   mov eax, dword ptr [rbp - 0x60]
0004ae28  8945a0                   mov dword ptr [rbp - 0x60], eax
0004ae2b  eb72                     jmp 0x4ae9f
0004ae2d  8b5598                   mov edx, dword ptr [rbp - 0x68]
0004ae30  b812040000               mov eax, 0x412
0004ae35  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004ae39  753e                     jne 0x4ae79
0004ae3b  450fb68846010000         movzx r9d, byte ptr [r8 + 0x146]
0004ae43  b8ff000000               mov eax, 0xff
0004ae48  6641c1e108               shl r9w, 8
0004ae4d  66440bc8                 or r9w, ax
0004ae51  6644898d88000000         mov word ptr [rbp + 0x88], r9w
0004ae59  410fb68046010000         movzx eax, byte ptr [r8 + 0x146]
0004ae61  b9ff000000               mov ecx, 0xff
0004ae66  66c1e008                 shl ax, 8
0004ae6a  660bc1                   or ax, cx
0004ae6d  668945a0                 mov word ptr [rbp - 0x60], ax
0004ae71  8b45a0                   mov eax, dword ptr [rbp - 0x60]
0004ae74  8945a0                   mov dword ptr [rbp - 0x60], eax
0004ae77  eb26                     jmp 0x4ae9f
0004ae79  b8fffe0000               mov eax, 0xfeff
0004ae7e  668945a0                 mov word ptr [rbp - 0x60], ax
0004ae82  448bc8                   mov r9d, eax
0004ae85  66898588000000           mov word ptr [rbp + 0x88], ax
0004ae8c  8b45a0                   mov eax, dword ptr [rbp - 0x60]
0004ae8f  8945a0                   mov dword ptr [rbp - 0x60], eax
0004ae92  eb0b                     jmp 0x4ae9f
0004ae94  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004ae98  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
0004ae9c  8b5598                   mov edx, dword ptr [rbp - 0x68]
0004ae9f  0fb6c3                   movzx eax, bl
0004aea2  83f806                   cmp eax, 6
0004aea5  0f876d040000             ja 0x4b318
0004aeab  488d0d4e51fbff           lea rcx, [rip - 0x4aeb2]
0004aeb2  8b8c8194bb0400           mov ecx, dword ptr [rcx + rax*4 + 0x4bb94]
0004aeb9  488d054051fbff           lea rax, [rip - 0x4aec0]
0004aec0  4803c8                   add rcx, rax
0004aec3  ffe1                     jmp rcx
0004aec5  403adf                   cmp bl, dil
0004aec8  0f844d040000             je 0x4b31b
0004aece  837d8800                 cmp dword ptr [rbp - 0x78], 0
0004aed2  7f07                     jg 0x4aedb
0004aed4  4183781000               cmp dword ptr [r8 + 0x10], 0
0004aed9  7411                     je 0x4aeec
0004aedb  41b901000000             mov r9d, 1
0004aee1  33c0                     xor eax, eax
0004aee3  44894d8c                 mov dword ptr [rbp - 0x74], r9d
0004aee7  894588                   mov dword ptr [rbp - 0x78], eax
0004aeea  eb06                     jmp 0x4aef2
0004aeec  41b901000000             mov r9d, 1
0004aef2  418d43ff                 lea eax, [r11 - 1]
0004aef6  85c0                     test eax, eax
0004aef8  7421                     je 0x4af1b
0004aefa  498b5008                 mov rdx, qword ptr [r8 + 8]
0004aefe  6690                     nop
0004af00  410fb74702               movzx eax, word ptr [r15 + 2]
0004af05  807c820101               cmp byte ptr [rdx + rax*4 + 1], 1
0004af0a  750f                     jne 0x4af1b
0004af0c  41ffcb                   dec r11d
0004af0f  4983c702                 add r15, 2
0004af13  418d43ff                 lea eax, [r11 - 1]
0004af17  85c0                     test eax, eax
0004af19  75e5                     jne 0x4af00
0004af1b  4983c702                 add r15, 2
0004af1f  4183eb01                 sub r11d, 1
0004af23  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004af2a  7414                     je 0x4af40
0004af2c  410fb70f                 movzx ecx, word ptr [r15]
0004af30  498b4008                 mov rax, qword ptr [r8 + 8]
0004af34  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004af37  235590                   and edx, dword ptr [rbp - 0x70]
0004af3a  895598                   mov dword ptr [rbp - 0x68], edx
0004af3d  895584                   mov dword ptr [rbp - 0x7c], edx
0004af40  458bc1                   mov r8d, r9d
0004af43  e9e6030000               jmp 0x4b32e
0004af48  8955b0                   mov dword ptr [rbp - 0x50], edx
0004af4b  4080ff06                 cmp dil, 6
0004af4f  743e                     je 0x4af8f
0004af51  8b4d88                   mov ecx, dword ptr [rbp - 0x78]
0004af54  83f906                   cmp ecx, 6
0004af57  7f10                     jg 0x4af69
0004af59  0f8546010000             jne 0x4b0a5
0004af5f  837dbc00                 cmp dword ptr [rbp - 0x44], 0
0004af63  0f853c010000             jne 0x4b0a5
0004af69  33c0                     xor eax, eax
0004af6b  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004af72  41b901000000             mov r9d, 1
0004af78  83f906                   cmp ecx, 6
0004af7b  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004af7f  0f4e45c4                 cmovle eax, dword ptr [rbp - 0x3c]
0004af83  8945c4                   mov dword ptr [rbp - 0x3c], eax
0004af86  44894d8c                 mov dword ptr [rbp - 0x74], r9d
0004af8a  e91c010000               jmp 0x4b0ab
0004af8f  837d8806                 cmp dword ptr [rbp - 0x78], 6
0004af93  7f5b                     jg 0x4aff0
0004af95  0f85d9000000             jne 0x4b074
0004af9b  837dc400                 cmp dword ptr [rbp - 0x3c], 0
0004af9f  7428                     je 0x4afc9
0004afa1  837dbc00                 cmp dword ptr [rbp - 0x44], 0
0004afa5  41b901000000             mov r9d, 1
0004afab  0f85c9000000             jne 0x4b07a
0004afb1  44894d8c                 mov dword ptr [rbp - 0x74], r9d
0004afb5  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004afb9  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004afbd  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004afc4  e9b1000000               jmp 0x4b07a
0004afc9  837dbc00                 cmp dword ptr [rbp - 0x44], 0
0004afcd  7421                     je 0x4aff0
0004afcf  41b901000000             mov r9d, 1
0004afd5  c7458c03000000           mov dword ptr [rbp - 0x74], 3
0004afdc  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004afe0  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004afe4  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004afeb  e98a000000               jmp 0x4b07a
0004aff0  0fb64584                 movzx eax, byte ptr [rbp - 0x7c]
0004aff4  384580                   cmp byte ptr [rbp - 0x80], al
0004aff7  7551                     jne 0x4b04a
0004aff9  0fb64d83                 movzx ecx, byte ptr [rbp - 0x7d]
0004affd  8bc2                     mov eax, edx
0004afff  c1e818                   shr eax, 0x18
0004b002  80e13f                   and cl, 0x3f
0004b005  243f                     and al, 0x3f
0004b007  3ac8                     cmp cl, al
0004b009  731b                     jae 0x4b026
0004b00b  41b901000000             mov r9d, 1
0004b011  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004b018  44894d8c                 mov dword ptr [rbp - 0x74], r9d
0004b01c  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004b020  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004b024  eb54                     jmp 0x4b07a
0004b026  0f86ef020000             jbe 0x4b31b
0004b02c  41b901000000             mov r9d, 1
0004b032  c7458c03000000           mov dword ptr [rbp - 0x74], 3
0004b039  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004b03d  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004b041  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004b048  eb30                     jmp 0x4b07a
0004b04a  0fb64584                 movzx eax, byte ptr [rbp - 0x7c]
0004b04e  41b901000000             mov r9d, 1
0004b054  384580                   cmp byte ptr [rbp - 0x80], al
0004b057  b903000000               mov ecx, 3
0004b05c  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004b060  410f42c9                 cmovb ecx, r9d
0004b064  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004b068  894d8c                   mov dword ptr [rbp - 0x74], ecx
0004b06b  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004b072  eb06                     jmp 0x4b07a
0004b074  41b901000000             mov r9d, 1
0004b07a  4983c402                 add r12, 2
0004b07e  4183ee01                 sub r14d, 1
0004b082  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004b089  7420                     je 0x4b0ab
0004b08b  410fb70c24               movzx ecx, word ptr [r12]
0004b090  498b4008                 mov rax, qword ptr [r8 + 8]
0004b094  448b5590                 mov r10d, dword ptr [rbp - 0x70]
0004b098  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004b09c  4523ea                   and r13d, r10d
0004b09f  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004b0a3  eb0a                     jmp 0x4b0af
0004b0a5  41b901000000             mov r9d, 1
0004b0ab  448b5590                 mov r10d, dword ptr [rbp - 0x70]
0004b0af  4983c702                 add r15, 2
0004b0b3  4183eb01                 sub r11d, 1
0004b0b7  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004b0be  7414                     je 0x4b0d4
0004b0c0  410fb70f                 movzx ecx, word ptr [r15]
0004b0c4  498b4008                 mov rax, qword ptr [r8 + 8]
0004b0c8  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004b0cb  4123d2                   and edx, r10d
0004b0ce  895598                   mov dword ptr [rbp - 0x68], edx
0004b0d1  895584                   mov dword ptr [rbp - 0x7c], edx
0004b0d4  458bc1                   mov r8d, r9d
0004b0d7  e952020000               jmp 0x4b32e
0004b0dc  448b45a8                 mov r8d, dword ptr [rbp - 0x58]
0004b0e0  4585c0                   test r8d, r8d
0004b0e3  0f853f020000             jne 0x4b328
0004b0e9  33d2                     xor edx, edx
0004b0eb  8955b0                   mov dword ptr [rbp - 0x50], edx
0004b0ee  3955f0                   cmp dword ptr [rbp - 0x10], edx
0004b0f1  0f8511010000             jne 0x4b208
0004b0f7  8b45f8                   mov eax, dword ptr [rbp - 8]
0004b0fa  4c8d8d80000000           lea r9, [rbp + 0x80]
0004b101  488b5568                 mov rdx, qword ptr [rbp + 0x68]
0004b105  4c8d4500                 lea r8, [rbp]
0004b109  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0004b10d  89442478                 mov dword ptr [rsp + 0x78], eax
0004b111  488d45e0                 lea rax, [rbp - 0x20]
0004b115  4889442470               mov qword ptr [rsp + 0x70], rax
0004b11a  488d45fc                 lea rax, [rbp - 4]
0004b11e  4889442468               mov qword ptr [rsp + 0x68], rax
0004b123  488d4578                 lea rax, [rbp + 0x78]
0004b127  4889442460               mov qword ptr [rsp + 0x60], rax
0004b12c  488d8588000000           lea rax, [rbp + 0x88]
0004b133  4889442458               mov qword ptr [rsp + 0x58], rax
0004b138  488d4584                 lea rax, [rbp - 0x7c]
0004b13c  4889442448               mov qword ptr [rsp + 0x48], rax
0004b141  488d8590000000           lea rax, [rbp + 0x90]
0004b148  44895c2440               mov dword ptr [rsp + 0x40], r11d
0004b14d  4889442438               mov qword ptr [rsp + 0x38], rax
0004b152  488d45f0                 lea rax, [rbp - 0x10]
0004b156  4889442430               mov qword ptr [rsp + 0x30], rax
0004b15b  488d4580                 lea rax, [rbp - 0x80]
0004b15f  4889442428               mov qword ptr [rsp + 0x28], rax
0004b164  4489742420               mov dword ptr [rsp + 0x20], r14d
0004b169  4c896500                 mov qword ptr [rbp], r12
0004b16d  4c897df0                 mov qword ptr [rbp - 0x10], r15
0004b171  e82a570000               call 0x508a0
0004b176  448bc0                   mov r8d, eax
0004b179  8945a8                   mov dword ptr [rbp - 0x58], eax
0004b17c  8b45e0                   mov eax, dword ptr [rbp - 0x20]
0004b17f  83f802                   cmp eax, 2
0004b182  0f85c8090000             jne 0x4bb50
0004b188  4c8b6500                 mov r12, qword ptr [rbp]
0004b18c  4c8b7df0                 mov r15, qword ptr [rbp - 0x10]
0004b190  448bb580000000           mov r14d, dword ptr [rbp + 0x80]
0004b197  448b9d90000000           mov r11d, dword ptr [rbp + 0x90]
0004b19e  4585c0                   test r8d, r8d
0004b1a1  744c                     je 0x4b1ef
0004b1a3  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b1a7  448d48ff                 lea r9d, [rax - 1]
0004b1ab  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004b1ae  4585f6                   test r14d, r14d
0004b1b1  7e2d                     jle 0x4b1e0
0004b1b3  4585db                   test r11d, r11d
0004b1b6  7e28                     jle 0x4b1e0
0004b1b8  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004b1bc  410fb70424               movzx eax, word ptr [r12]
0004b1c1  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004b1c5  410fb707                 movzx eax, word ptr [r15]
0004b1c9  4423ef                   and r13d, edi
0004b1cc  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004b1d0  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
0004b1d3  23df                     and ebx, edi
0004b1d5  895d98                   mov dword ptr [rbp - 0x68], ebx
0004b1d8  895d84                   mov dword ptr [rbp - 0x7c], ebx
0004b1db  e958010000               jmp 0x4b338
0004b1e0  8b5d84                   mov ebx, dword ptr [rbp - 0x7c]
0004b1e3  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004b1e7  895d98                   mov dword ptr [rbp - 0x68], ebx
0004b1ea  e949010000               jmp 0x4b338
0004b1ef  8b5584                   mov edx, dword ptr [rbp - 0x7c]
0004b1f2  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004b1f6  440fb78d88000000         movzx r9d, word ptr [rbp + 0x88]
0004b1fe  440fb75578               movzx r10d, word ptr [rbp + 0x78]
0004b203  895598                   mov dword ptr [rbp - 0x68], edx
0004b206  33d2                     xor edx, edx
0004b208  4080ff03                 cmp dil, 3
0004b20c  0f8539030000             jne 0x4b54b
0004b212  488b4568                 mov rax, qword ptr [rbp + 0x68]
0004b216  458bc5                   mov r8d, r13d
0004b219  41c1e818                 shr r8d, 0x18
0004b21d  807d8001                 cmp byte ptr [rbp - 0x80], 1
0004b221  8955ac                   mov dword ptr [rbp - 0x54], edx
0004b224  0fb74840                 movzx ecx, word ptr [rax + 0x40]
0004b228  0f87db010000             ja 0x4b409
0004b22e  b8ffff0000               mov eax, 0xffff
0004b233  8bd0                     mov edx, eax
0004b235  8945c0                   mov dword ptr [rbp - 0x40], eax
0004b238  8b45a0                   mov eax, dword ptr [rbp - 0x60]
0004b23b  85c0                     test eax, eax
0004b23d  0f84c2010000             je 0x4b405
0004b243  8b5590                   mov edx, dword ptr [rbp - 0x70]
0004b246  23d0                     and edx, eax
0004b248  0fb7c2                   movzx eax, dx
0004b24b  8955c0                   mov dword ptr [rbp - 0x40], edx
0004b24e  66c1e808                 shr ax, 8
0004b252  899580000000             mov dword ptr [rbp + 0x80], edx
0004b258  403ac7                   cmp al, dil
0004b25b  0f83f5000000             jae 0x4b356
0004b261  b8ffff0000               mov eax, 0xffff
0004b266  8bd0                     mov edx, eax
0004b268  8945c0                   mov dword ptr [rbp - 0x40], eax
0004b26b  e9e7010000               jmp 0x4b457
0004b270  4080ff05                 cmp dil, 5
0004b274  7454                     je 0x4b2ca
0004b276  498b4008                 mov rax, qword ptr [r8 + 8]
0004b27a  410fb70f                 movzx ecx, word ptr [r15]
0004b27e  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004b281  b812040000               mov eax, 0x412
0004b286  895598                   mov dword ptr [rbp - 0x68], edx
0004b289  895584                   mov dword ptr [rbp - 0x7c], edx
0004b28c  899588000000             mov dword ptr [rbp + 0x88], edx
0004b292  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b296  7518                     jne 0x4b2b0
0004b298  450fb69046010000         movzx r10d, byte ptr [r8 + 0x146]
0004b2a0  b8ff000000               mov eax, 0xff
0004b2a5  6641c1e208               shl r10w, 8
0004b2aa  66440bd0                 or r10w, ax
0004b2ae  eb2b                     jmp 0x4b2db
0004b2b0  b8fffe0000               mov eax, 0xfeff
0004b2b5  448bd0                   mov r10d, eax
0004b2b8  66898588000000           mov word ptr [rbp + 0x88], ax
0004b2bf  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004b2c5  8945b0                   mov dword ptr [rbp - 0x50], eax
0004b2c8  eb51                     jmp 0x4b31b
0004b2ca  b812040000               mov eax, 0x412
0004b2cf  899588000000             mov dword ptr [rbp + 0x88], edx
0004b2d5  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b2d9  7526                     jne 0x4b301
0004b2db  410fb68046010000         movzx eax, byte ptr [r8 + 0x146]
0004b2e3  b9ff000000               mov ecx, 0xff
0004b2e8  66c1e008                 shl ax, 8
0004b2ec  660bc1                   or ax, cx
0004b2ef  66898588000000           mov word ptr [rbp + 0x88], ax
0004b2f6  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004b2fc  8945b0                   mov dword ptr [rbp - 0x50], eax
0004b2ff  eb1a                     jmp 0x4b31b
0004b301  b8fffe0000               mov eax, 0xfeff
0004b306  66898588000000           mov word ptr [rbp + 0x88], ax
0004b30d  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004b313  8945b0                   mov dword ptr [rbp - 0x50], eax
0004b316  eb03                     jmp 0x4b31b
0004b318  8955b0                   mov dword ptr [rbp - 0x50], edx
0004b31b  448b45a8                 mov r8d, dword ptr [rbp - 0x58]
0004b31f  4585c0                   test r8d, r8d
0004b322  0f84defeffff             je 0x4b206
0004b328  41b901000000             mov r9d, 1
0004b32e  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004b331  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b335  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b338  8b558c                   mov edx, dword ptr [rbp - 0x74]
0004b33b  4585f6                   test r14d, r14d
0004b33e  0f844df2ffff             je 0x4a591
0004b344  4585db                   test r11d, r11d
0004b347  0f8444f2ffff             je 0x4a591
0004b34d  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
0004b351  e9e6f2ffff               jmp 0x4a63c
0004b356  0f859a000000             jne 0x4b3f6
0004b35c  80fa01                   cmp dl, 1
0004b35f  770f                     ja 0x4b370
0004b361  b8ffff0000               mov eax, 0xffff
0004b366  8bd0                     mov edx, eax
0004b368  8945c0                   mov dword ptr [rbp - 0x40], eax
0004b36b  e9e7000000               jmp 0x4b457
0004b370  b812040000               mov eax, 0x412
0004b375  0fb6d2                   movzx edx, dl
0004b378  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b37c  0fb7c2                   movzx eax, dx
0004b37f  750a                     jne 0x4b38b
0004b381  4c8b6d68                 mov r13, qword ptr [rbp + 0x68]
0004b385  420fb64c2948             movzx ecx, byte ptr [rcx + r13 + 0x48]
0004b38b  66c1e108                 shl cx, 8
0004b38f  660bc1                   or ax, cx
0004b392  660bca                   or cx, dx
0004b395  0fb69583000000           movzx edx, byte ptr [rbp + 0x83]
0004b39c  66898580000000           mov word ptr [rbp + 0x80], ax
0004b3a3  80e23f                   and dl, 0x3f
0004b3a6  0fb6c2                   movzx eax, dl
0004b3a9  24c6                     and al, 0xc6
0004b3ab  8845ac                   mov byte ptr [rbp - 0x54], al
0004b3ae  0fb6c2                   movzx eax, dl
0004b3b1  24e4                     and al, 0xe4
0004b3b3  807d8000                 cmp byte ptr [rbp - 0x80], 0
0004b3b7  8845ae                   mov byte ptr [rbp - 0x52], al
0004b3ba  b8ffff0000               mov eax, 0xffff
0004b3bf  751c                     jne 0x4b3dd
0004b3c1  80e2c5                   and dl, 0xc5
0004b3c4  c645ad04                 mov byte ptr [rbp - 0x53], 4
0004b3c8  8855af                   mov byte ptr [rbp - 0x51], dl
0004b3cb  440fb7c9                 movzx r9d, cx
0004b3cf  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004b3d5  8955c0                   mov dword ptr [rbp - 0x40], edx
0004b3d8  e980000000               jmp 0x4b45d
0004b3dd  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004b3e3  41b987ff0000             mov r9d, 0xff87
0004b3e9  664423c9                 and r9w, cx
0004b3ed  c645ad05                 mov byte ptr [rbp - 0x53], 5
0004b3f1  8955c0                   mov dword ptr [rbp - 0x40], edx
0004b3f4  eb59                     jmp 0x4b44f
0004b3f6  440fb78d80000000         movzx r9d, word ptr [rbp + 0x80]
0004b3fe  b8ffff0000               mov eax, 0xffff
0004b403  eb52                     jmp 0x4b457
0004b405  8bc2                     mov eax, edx
0004b407  eb4e                     jmp 0x4b457
0004b409  0fb65580                 movzx edx, byte ptr [rbp - 0x80]
0004b40d  b812040000               mov eax, 0x412
0004b412  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004b416  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b41a  750a                     jne 0x4b426
0004b41c  4c8b6d68                 mov r13, qword ptr [rbp + 0x68]
0004b420  420fb64c2948             movzx ecx, byte ptr [rcx + r13 + 0x48]
0004b426  410fb6c0                 movzx eax, r8b
0004b42a  66c1e108                 shl cx, 8
0004b42e  2406                     and al, 6
0004b430  c645ad03                 mov byte ptr [rbp - 0x53], 3
0004b434  8845ac                   mov byte ptr [rbp - 0x54], al
0004b437  660bca                   or cx, dx
0004b43a  8b55c0                   mov edx, dword ptr [rbp - 0x40]
0004b43d  410fb6c0                 movzx eax, r8b
0004b441  2424                     and al, 0x24
0004b443  440fb7c9                 movzx r9d, cx
0004b447  8845ae                   mov byte ptr [rbp - 0x52], al
0004b44a  b8ffff0000               mov eax, 0xffff
0004b44f  4180e005                 and r8b, 5
0004b453  448845af                 mov byte ptr [rbp - 0x51], r8b
0004b457  807d8001                 cmp byte ptr [rbp - 0x80], 1
0004b45b  7717                     ja 0x4b474
0004b45d  3bd0                     cmp edx, eax
0004b45f  7513                     jne 0x4b474
0004b461  440fb7c8                 movzx r9d, ax
0004b465  894580                   mov dword ptr [rbp - 0x80], eax
0004b468  448be8                   mov r13d, eax
0004b46b  33c0                     xor eax, eax
0004b46d  8bc8                     mov ecx, eax
0004b46f  8945ac                   mov dword ptr [rbp - 0x54], eax
0004b472  eb10                     jmp 0x4b484
0004b474  8b4dac                   mov ecx, dword ptr [rbp - 0x54]
0004b477  6644894d80               mov word ptr [rbp - 0x80], r9w
0004b47c  c6458302                 mov byte ptr [rbp - 0x7d], 2
0004b480  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004b484  837d8802                 cmp dword ptr [rbp - 0x78], 2
0004b488  0f8ebd000000             jle 0x4b54b
0004b48e  80fb03                   cmp bl, 3
0004b491  0f84bd000000             je 0x4b554
0004b497  807dac00                 cmp byte ptr [rbp - 0x54], 0
0004b49b  7420                     je 0x4b4bd
0004b49d  85f6                     test esi, esi
0004b49f  751c                     jne 0x4b4bd
0004b4a1  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b4a4  ba03000000               mov edx, 3
0004b4a9  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b4ad  bf02000000               mov edi, 2
0004b4b2  89558c                   mov dword ptr [rbp - 0x74], edx
0004b4b5  897d88                   mov dword ptr [rbp - 0x78], edi
0004b4b8  e90c040000               jmp 0x4b8c9
0004b4bd  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004b4c0  83ff03                   cmp edi, 3
0004b4c3  7e7a                     jle 0x4b53f
0004b4c5  8bc1                     mov eax, ecx
0004b4c7  c1e808                   shr eax, 8
0004b4ca  84c0                     test al, al
0004b4cc  741d                     je 0x4b4eb
0004b4ce  85f6                     test esi, esi
0004b4d0  7519                     jne 0x4b4eb
0004b4d2  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b4d5  ba03000000               mov edx, 3
0004b4da  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b4de  8bfa                     mov edi, edx
0004b4e0  89558c                   mov dword ptr [rbp - 0x74], edx
0004b4e3  895588                   mov dword ptr [rbp - 0x78], edx
0004b4e6  e9de030000               jmp 0x4b8c9
0004b4eb  83ff04                   cmp edi, 4
0004b4ee  7e4f                     jle 0x4b53f
0004b4f0  8bc1                     mov eax, ecx
0004b4f2  c1e810                   shr eax, 0x10
0004b4f5  84c0                     test al, al
0004b4f7  741c                     je 0x4b515
0004b4f9  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b4fc  ba03000000               mov edx, 3
0004b501  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b505  bf04000000               mov edi, 4
0004b50a  89558c                   mov dword ptr [rbp - 0x74], edx
0004b50d  897d88                   mov dword ptr [rbp - 0x78], edi
0004b510  e9b4030000               jmp 0x4b8c9
0004b515  83ff05                   cmp edi, 5
0004b518  7e25                     jle 0x4b53f
0004b51a  8bc1                     mov eax, ecx
0004b51c  c1e818                   shr eax, 0x18
0004b51f  84c0                     test al, al
0004b521  741c                     je 0x4b53f
0004b523  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b526  ba03000000               mov edx, 3
0004b52b  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b52f  bf05000000               mov edi, 5
0004b534  89558c                   mov dword ptr [rbp - 0x74], edx
0004b537  897d88                   mov dword ptr [rbp - 0x78], edi
0004b53a  e98a030000               jmp 0x4b8c9
0004b53f  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b542  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b546  e979030000               jmp 0x4b8c4
0004b54b  80fb03                   cmp bl, 3
0004b54e  0f8566030000             jne 0x4b8ba
0004b554  8b4598                   mov eax, dword ptr [rbp - 0x68]
0004b557  33d2                     xor edx, edx
0004b559  488b5d68                 mov rbx, qword ptr [rbp + 0x68]
0004b55d  448bc0                   mov r8d, eax
0004b560  41c1e818                 shr r8d, 0x18
0004b564  807d8401                 cmp byte ptr [rbp - 0x7c], 1
0004b568  899580000000             mov dword ptr [rbp + 0x80], edx
0004b56e  0fb74b40                 movzx ecx, word ptr [rbx + 0x40]
0004b572  0f87f6000000             ja 0x4b66e
0004b578  b8ffff0000               mov eax, 0xffff
0004b57d  8945b4                   mov dword ptr [rbp - 0x4c], eax
0004b580  8b45b0                   mov eax, dword ptr [rbp - 0x50]
0004b583  85c0                     test eax, eax
0004b585  0f84de000000             je 0x4b669
0004b58b  8b5d90                   mov ebx, dword ptr [rbp - 0x70]
0004b58e  23d8                     and ebx, eax
0004b590  8bc3                     mov eax, ebx
0004b592  895db4                   mov dword ptr [rbp - 0x4c], ebx
0004b595  66c1e808                 shr ax, 8
0004b599  899d88000000             mov dword ptr [rbp + 0x88], ebx
0004b59f  488b5d68                 mov rbx, qword ptr [rbp + 0x68]
0004b5a3  3c03                     cmp al, 3
0004b5a5  730f                     jae 0x4b5b6
0004b5a7  b9ffff0000               mov ecx, 0xffff
0004b5ac  8bc1                     mov eax, ecx
0004b5ae  894db4                   mov dword ptr [rbp - 0x4c], ecx
0004b5b1  e912010000               jmp 0x4b6c8
0004b5b6  8b45b4                   mov eax, dword ptr [rbp - 0x4c]
0004b5b9  0f85a0000000             jne 0x4b65f
0004b5bf  3c01                     cmp al, 1
0004b5c1  770f                     ja 0x4b5d2
0004b5c3  b9ffff0000               mov ecx, 0xffff
0004b5c8  8bc1                     mov eax, ecx
0004b5ca  894db4                   mov dword ptr [rbp - 0x4c], ecx
0004b5cd  e9f6000000               jmp 0x4b6c8
0004b5d2  0fb6d0                   movzx edx, al
0004b5d5  b812040000               mov eax, 0x412
0004b5da  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b5de  0fb7c2                   movzx eax, dx
0004b5e1  7505                     jne 0x4b5e8
0004b5e3  0fb64c1948               movzx ecx, byte ptr [rcx + rbx + 0x48]
0004b5e8  66c1e108                 shl cx, 8
0004b5ec  660bc1                   or ax, cx
0004b5ef  660bca                   or cx, dx
0004b5f2  0fb6958b000000           movzx edx, byte ptr [rbp + 0x8b]
0004b5f9  66898588000000           mov word ptr [rbp + 0x88], ax
0004b600  80e23f                   and dl, 0x3f
0004b603  0fb6c2                   movzx eax, dl
0004b606  24c6                     and al, 0xc6
0004b608  888580000000             mov byte ptr [rbp + 0x80], al
0004b60e  0fb6c2                   movzx eax, dl
0004b611  24e4                     and al, 0xe4
0004b613  807d8400                 cmp byte ptr [rbp - 0x7c], 0
0004b617  888582000000             mov byte ptr [rbp + 0x82], al
0004b61d  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004b623  8945b4                   mov dword ptr [rbp - 0x4c], eax
0004b626  7524                     jne 0x4b64c
0004b628  80e2c5                   and dl, 0xc5
0004b62b  c6858100000004           mov byte ptr [rbp + 0x81], 4
0004b632  889583000000             mov byte ptr [rbp + 0x83], dl
0004b638  440fb7d1                 movzx r10d, cx
0004b63c  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004b642  b9ffff0000               mov ecx, 0xffff
0004b647  e982000000               jmp 0x4b6ce
0004b64c  41ba87ff0000             mov r10d, 0xff87
0004b652  c6858100000005           mov byte ptr [rbp + 0x81], 5
0004b659  664423d1                 and r10w, cx
0004b65d  eb53                     jmp 0x4b6b2
0004b65f  440fb79588000000         movzx r10d, word ptr [rbp + 0x88]
0004b667  eb5a                     jmp 0x4b6c3
0004b669  8b45b4                   mov eax, dword ptr [rbp - 0x4c]
0004b66c  eb55                     jmp 0x4b6c3
0004b66e  0fb65584                 movzx edx, byte ptr [rbp - 0x7c]
0004b672  8945b0                   mov dword ptr [rbp - 0x50], eax
0004b675  b812040000               mov eax, 0x412
0004b67a  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b67e  7505                     jne 0x4b685
0004b680  0fb64c1948               movzx ecx, byte ptr [rcx + rbx + 0x48]
0004b685  410fb6c0                 movzx eax, r8b
0004b689  66c1e108                 shl cx, 8
0004b68d  2406                     and al, 6
0004b68f  c6858100000003           mov byte ptr [rbp + 0x81], 3
0004b696  888580000000             mov byte ptr [rbp + 0x80], al
0004b69c  660bca                   or cx, dx
0004b69f  410fb6c0                 movzx eax, r8b
0004b6a3  440fb7d1                 movzx r10d, cx
0004b6a7  2424                     and al, 0x24
0004b6a9  888582000000             mov byte ptr [rbp + 0x82], al
0004b6af  8b45b4                   mov eax, dword ptr [rbp - 0x4c]
0004b6b2  4180e005                 and r8b, 5
0004b6b6  44888583000000           mov byte ptr [rbp + 0x83], r8b
0004b6bd  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004b6c3  b9ffff0000               mov ecx, 0xffff
0004b6c8  807d8401                 cmp byte ptr [rbp - 0x7c], 1
0004b6cc  771c                     ja 0x4b6ea
0004b6ce  3bc1                     cmp eax, ecx
0004b6d0  7518                     jne 0x4b6ea
0004b6d2  33c0                     xor eax, eax
0004b6d4  894d98                   mov dword ptr [rbp - 0x68], ecx
0004b6d7  8bd0                     mov edx, eax
0004b6d9  898580000000             mov dword ptr [rbp + 0x80], eax
0004b6df  440fb7d1                 movzx r10d, cx
0004b6e3  894d84                   mov dword ptr [rbp - 0x7c], ecx
0004b6e6  8bd9                     mov ebx, ecx
0004b6e8  eb0f                     jmp 0x4b6f9
0004b6ea  6644895584               mov word ptr [rbp - 0x7c], r10w
0004b6ef  c6458702                 mov byte ptr [rbp - 0x79], 2
0004b6f3  8b5d84                   mov ebx, dword ptr [rbp - 0x7c]
0004b6f6  895d98                   mov dword ptr [rbp - 0x68], ebx
0004b6f9  837d8802                 cmp dword ptr [rbp - 0x78], 2
0004b6fd  0f8eba010000             jle 0x4b8bd
0004b703  4080ff03                 cmp dil, 3
0004b707  0f84bb000000             je 0x4b7c8
0004b70d  80bd8000000000           cmp byte ptr [rbp + 0x80], 0
0004b714  7420                     je 0x4b736
0004b716  85f6                     test esi, esi
0004b718  751c                     jne 0x4b736
0004b71a  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b71e  b801000000               mov eax, 1
0004b723  bf02000000               mov edi, 2
0004b728  89458c                   mov dword ptr [rbp - 0x74], eax
0004b72b  897d88                   mov dword ptr [rbp - 0x78], edi
0004b72e  8d5002                   lea edx, [rax + 2]
0004b731  e998010000               jmp 0x4b8ce
0004b736  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004b739  83ff03                   cmp edi, 3
0004b73c  0f8e00feffff             jle 0x4b542
0004b742  8bc2                     mov eax, edx
0004b744  c1e808                   shr eax, 8
0004b747  84c0                     test al, al
0004b749  741f                     je 0x4b76a
0004b74b  85f6                     test esi, esi
0004b74d  751b                     jne 0x4b76a
0004b74f  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b753  ba03000000               mov edx, 3
0004b758  b801000000               mov eax, 1
0004b75d  895588                   mov dword ptr [rbp - 0x78], edx
0004b760  89458c                   mov dword ptr [rbp - 0x74], eax
0004b763  8bfa                     mov edi, edx
0004b765  e964010000               jmp 0x4b8ce
0004b76a  83ff04                   cmp edi, 4
0004b76d  0f8ecffdffff             jle 0x4b542
0004b773  8bc2                     mov eax, edx
0004b775  c1e810                   shr eax, 0x10
0004b778  84c0                     test al, al
0004b77a  741c                     je 0x4b798
0004b77c  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b780  b801000000               mov eax, 1
0004b785  bf04000000               mov edi, 4
0004b78a  89458c                   mov dword ptr [rbp - 0x74], eax
0004b78d  897d88                   mov dword ptr [rbp - 0x78], edi
0004b790  8d5002                   lea edx, [rax + 2]
0004b793  e936010000               jmp 0x4b8ce
0004b798  83ff05                   cmp edi, 5
0004b79b  0f8ea1fdffff             jle 0x4b542
0004b7a1  c1ea18                   shr edx, 0x18
0004b7a4  84d2                     test dl, dl
0004b7a6  0f8496fdffff             je 0x4b542
0004b7ac  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b7b0  b801000000               mov eax, 1
0004b7b5  bf05000000               mov edi, 5
0004b7ba  89458c                   mov dword ptr [rbp - 0x74], eax
0004b7bd  897d88                   mov dword ptr [rbp - 0x78], edi
0004b7c0  8d5002                   lea edx, [rax + 2]
0004b7c3  e906010000               jmp 0x4b8ce
0004b7c8  0fb645ac                 movzx eax, byte ptr [rbp - 0x54]
0004b7cc  0fb68d80000000           movzx ecx, byte ptr [rbp + 0x80]
0004b7d3  3ac1                     cmp al, cl
0004b7d5  742c                     je 0x4b803
0004b7d7  85f6                     test esi, esi
0004b7d9  7528                     jne 0x4b803
0004b7db  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b7df  3ac1                     cmp al, cl
0004b7e1  ba03000000               mov edx, 3
0004b7e6  b801000000               mov eax, 1
0004b7eb  448bc2                   mov r8d, edx
0004b7ee  bf02000000               mov edi, 2
0004b7f3  440f42c0                 cmovb r8d, eax
0004b7f7  897d88                   mov dword ptr [rbp - 0x78], edi
0004b7fa  4489458c                 mov dword ptr [rbp - 0x74], r8d
0004b7fe  e9cb000000               jmp 0x4b8ce
0004b803  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004b806  83ff03                   cmp edi, 3
0004b809  0f8e33fdffff             jle 0x4b542
0004b80f  448b45ac                 mov r8d, dword ptr [rbp - 0x54]
0004b813  8bca                     mov ecx, edx
0004b815  418bc0                   mov eax, r8d
0004b818  c1e908                   shr ecx, 8
0004b81b  c1e808                   shr eax, 8
0004b81e  3ac1                     cmp al, cl
0004b820  7429                     je 0x4b84b
0004b822  85f6                     test esi, esi
0004b824  7525                     jne 0x4b84b
0004b826  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b82a  ba03000000               mov edx, 3
0004b82f  3ac1                     cmp al, cl
0004b831  895588                   mov dword ptr [rbp - 0x78], edx
0004b834  448bc2                   mov r8d, edx
0004b837  b801000000               mov eax, 1
0004b83c  440f42c0                 cmovb r8d, eax
0004b840  8bfa                     mov edi, edx
0004b842  4489458c                 mov dword ptr [rbp - 0x74], r8d
0004b846  e983000000               jmp 0x4b8ce
0004b84b  83ff04                   cmp edi, 4
0004b84e  0f8eeefcffff             jle 0x4b542
0004b854  418bc0                   mov eax, r8d
0004b857  8bca                     mov ecx, edx
0004b859  c1e810                   shr eax, 0x10
0004b85c  c1e910                   shr ecx, 0x10
0004b85f  3ac1                     cmp al, cl
0004b861  7423                     je 0x4b886
0004b863  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b867  ba03000000               mov edx, 3
0004b86c  448bc2                   mov r8d, edx
0004b86f  b801000000               mov eax, 1
0004b874  440f42c0                 cmovb r8d, eax
0004b878  bf04000000               mov edi, 4
0004b87d  4489458c                 mov dword ptr [rbp - 0x74], r8d
0004b881  897d88                   mov dword ptr [rbp - 0x78], edi
0004b884  eb48                     jmp 0x4b8ce
0004b886  83ff05                   cmp edi, 5
0004b889  0f8eb3fcffff             jle 0x4b542
0004b88f  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b893  418bc0                   mov eax, r8d
0004b896  c1e818                   shr eax, 0x18
0004b899  c1ea18                   shr edx, 0x18
0004b89c  3ac2                     cmp al, dl
0004b89e  b801000000               mov eax, 1
0004b8a3  8d5002                   lea edx, [rax + 2]
0004b8a6  7426                     je 0x4b8ce
0004b8a8  8bca                     mov ecx, edx
0004b8aa  bf05000000               mov edi, 5
0004b8af  0f42c8                   cmovb ecx, eax
0004b8b2  897d88                   mov dword ptr [rbp - 0x78], edi
0004b8b5  894d8c                   mov dword ptr [rbp - 0x74], ecx
0004b8b8  eb14                     jmp 0x4b8ce
0004b8ba  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b8bd  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b8c1  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004b8c4  ba03000000               mov edx, 3
0004b8c9  b801000000               mov eax, 1
0004b8ce  66453bca                 cmp r9w, r10w
0004b8d2  0f85ad010000             jne 0x4ba85
0004b8d8  f6457002                 test byte ptr [rbp + 0x70], 2
0004b8dc  0f85d1000000             jne 0x4b9b3
0004b8e2  85ff                     test edi, edi
0004b8e4  7f0a                     jg 0x4b8f0
0004b8e6  837e1000                 cmp dword ptr [rsi + 0x10], 0
0004b8ea  0f84c3000000             je 0x4b9b3
0004b8f0  48837dd000               cmp qword ptr [rbp - 0x30], 0
0004b8f5  440fb64582               movzx r8d, byte ptr [rbp - 0x7e]
0004b8fa  440fb64d86               movzx r9d, byte ptr [rbp - 0x7a]
0004b8ff  753d                     jne 0x4b93e
0004b901  418d46ff                 lea eax, [r14 - 1]
0004b905  85c0                     test eax, eax
0004b907  7435                     je 0x4b93e
0004b909  4c8b5608                 mov r10, qword ptr [rsi + 8]
0004b90d  0f1f00                   nop dword ptr [rax]
0004b910  410fb7442402             movzx eax, word ptr [r12 + 2]
0004b916  418b0c82                 mov ecx, dword ptr [r10 + rax*4]
0004b91a  0fb7c1                   movzx eax, cx
0004b91d  66c1e808                 shr ax, 8
0004b921  3c01                     cmp al, 1
0004b923  7519                     jne 0x4b93e
0004b925  c1e910                   shr ecx, 0x10
0004b928  41ffce                   dec r14d
0004b92b  0fb6c1                   movzx eax, cl
0004b92e  4983c402                 add r12, 2
0004b932  664403c0                 add r8w, ax
0004b936  418d46ff                 lea eax, [r14 - 1]
0004b93a  85c0                     test eax, eax
0004b93c  75d2                     jne 0x4b910
0004b93e  48837de800               cmp qword ptr [rbp - 0x18], 0
0004b943  7548                     jne 0x4b98d
0004b945  418d43ff                 lea eax, [r11 - 1]
0004b949  85c0                     test eax, eax
0004b94b  7440                     je 0x4b98d
0004b94d  4c8b5608                 mov r10, qword ptr [rsi + 8]
0004b951  0f1f4000                 nop dword ptr [rax]
0004b955  6666660f1f840000000000   nop word ptr [rax + rax]
0004b960  410fb74702               movzx eax, word ptr [r15 + 2]
0004b965  418b0c82                 mov ecx, dword ptr [r10 + rax*4]
0004b969  0fb7c1                   movzx eax, cx
0004b96c  66c1e808                 shr ax, 8
0004b970  3c01                     cmp al, 1
0004b972  7519                     jne 0x4b98d
0004b974  c1e910                   shr ecx, 0x10
0004b977  41ffcb                   dec r11d
0004b97a  0fb6c1                   movzx eax, cl
0004b97d  4983c702                 add r15, 2
0004b981  664403c8                 add r9w, ax
0004b985  418d43ff                 lea eax, [r11 - 1]
0004b989  85c0                     test eax, eax
0004b98b  75d3                     jne 0x4b960
0004b98d  41ba03000000             mov r10d, 3
0004b993  66453bc1                 cmp r8w, r9w
0004b997  458d4afe                 lea r9d, [r10 - 2]
0004b99b  7420                     je 0x4b9bd
0004b99d  418bd2                   mov edx, r10d
0004b9a0  410f42d1                 cmovb edx, r9d
0004b9a4  4533c0                   xor r8d, r8d
0004b9a7  418bf8                   mov edi, r8d
0004b9aa  44894588                 mov dword ptr [rbp - 0x78], r8d
0004b9ae  89558c                   mov dword ptr [rbp - 0x74], edx
0004b9b1  eb10                     jmp 0x4b9c3
0004b9b3  41ba03000000             mov r10d, 3
0004b9b9  458d4afe                 lea r9d, [r10 - 2]
0004b9bd  8b558c                   mov edx, dword ptr [rbp - 0x74]
0004b9c0  4533c0                   xor r8d, r8d
0004b9c3  8b4570                   mov eax, dword ptr [rbp + 0x70]
0004b9c6  2501000200               and eax, 0x20001
0004b9cb  3d01000200               cmp eax, 0x20001
0004b9d0  7427                     je 0x4b9f9
0004b9d2  83ff01                   cmp edi, 1
0004b9d5  7e22                     jle 0x4b9f9
0004b9d7  0fb64587                 movzx eax, byte ptr [rbp - 0x79]
0004b9db  0fb64d83                 movzx ecx, byte ptr [rbp - 0x7d]
0004b9df  243f                     and al, 0x3f
0004b9e1  80e13f                   and cl, 0x3f
0004b9e4  3ac8                     cmp cl, al
0004b9e6  7411                     je 0x4b9f9
0004b9e8  418bd2                   mov edx, r10d
0004b9eb  44894d88                 mov dword ptr [rbp - 0x78], r9d
0004b9ef  410f42d1                 cmovb edx, r9d
0004b9f3  418bf9                   mov edi, r9d
0004b9f6  89558c                   mov dword ptr [rbp - 0x74], edx
0004b9f9  488b45d0                 mov rax, qword ptr [rbp - 0x30]
0004b9fd  4885c0                   test rax, rax
0004ba00  7411                     je 0x4ba13
0004ba02  836de401                 sub dword ptr [rbp - 0x1c], 1
0004ba06  750b                     jne 0x4ba13
0004ba08  4c8be0                   mov r12, rax
0004ba0b  4c8945d0                 mov qword ptr [rbp - 0x30], r8
0004ba0f  448945a0                 mov dword ptr [rbp - 0x60], r8d
0004ba13  488b4de8                 mov rcx, qword ptr [rbp - 0x18]
0004ba17  4885c9                   test rcx, rcx
0004ba1a  7414                     je 0x4ba30
0004ba1c  836dc801                 sub dword ptr [rbp - 0x38], 1
0004ba20  750e                     jne 0x4ba30
0004ba22  4c8bf9                   mov r15, rcx
0004ba25  448945b0                 mov dword ptr [rbp - 0x50], r8d
0004ba29  498bc8                   mov rcx, r8
0004ba2c  48894de8                 mov qword ptr [rbp - 0x18], rcx
0004ba30  448b45a8                 mov r8d, dword ptr [rbp - 0x58]
0004ba34  458d5bff                 lea r11d, [r11 - 1]
0004ba38  4983c402                 add r12, 2
0004ba3c  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004ba43  4983c702                 add r15, 2
0004ba47  4183ee01                 sub r14d, 1
0004ba4b  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004ba52  0f8446ebffff             je 0x4a59e
0004ba58  4585db                   test r11d, r11d
0004ba5b  7423                     je 0x4ba80
0004ba5d  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004ba61  410fb70424               movzx eax, word ptr [r12]
0004ba66  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004ba69  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004ba6d  410fb707                 movzx eax, word ptr [r15]
0004ba71  4423ef                   and r13d, edi
0004ba74  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004ba78  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
0004ba7b  e9b0ebffff               jmp 0x4a630
0004ba80  e919ebffff               jmp 0x4a59e
0004ba85  0f42d0                   cmovb edx, eax
0004ba88  e9c1000000               jmp 0x4bb4e
0004ba8d  4585f6                   test r14d, r14d
0004ba90  7544                     jne 0x4bad6
0004ba92  4585db                   test r11d, r11d
0004ba95  0f84a8000000             je 0x4bb43
0004ba9b  448b5570                 mov r10d, dword ptr [rbp + 0x70]
0004ba9f  4585d2                   test r10d, r10d
0004baa2  791f                     jns 0x4bac3
0004baa4  4885c9                   test rcx, rcx
0004baa7  0f8496000000             je 0x4bb43
0004baad  443975c8                 cmp dword ptr [rbp - 0x38], r14d
0004bab1  0f848c000000             je 0x4bb43
0004bab7  83ff07                   cmp edi, 7
0004baba  410f44d1                 cmove edx, r9d
0004babe  e98b000000               jmp 0x4bb4e
0004bac3  4585c0                   test r8d, r8d
0004bac6  4d8be7                   mov r12, r15
0004bac9  458bf3                   mov r14d, r11d
0004bacc  440f45eb                 cmovne r13d, ebx
0004bad0  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004bad4  eb07                     jmp 0x4badd
0004bad6  458bca                   mov r9d, r10d
0004bad9  448b5570                 mov r10d, dword ptr [rbp + 0x70]
0004badd  4585f6                   test r14d, r14d
0004bae0  7461                     je 0x4bb43
0004bae2  4c8d1d1745fbff           lea r11, [rip - 0x4bae9]
0004bae9  0f1f8000000000           nop dword ptr [rax]
0004baf0  4585c0                   test r8d, r8d
0004baf3  7407                     je 0x4bafc
0004baf5  33c0                     xor eax, eax
0004baf7  448bc0                   mov r8d, eax
0004bafa  eb0f                     jmp 0x4bb0b
0004bafc  410fb70c24               movzx ecx, word ptr [r12]
0004bb01  488b4608                 mov rax, qword ptr [rsi + 8]
0004bb05  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004bb08  894d80                   mov dword ptr [rbp - 0x80], ecx
0004bb0b  0fb74580                 movzx eax, word ptr [rbp - 0x80]
0004bb0f  c1e808                   shr eax, 8
0004bb12  83f80b                   cmp eax, 0xb
0004bb15  7717                     ja 0x4bb2e
0004bb17  418b8c83b0bb0400         mov ecx, dword ptr [r11 + rax*4 + 0x4bbb0]
0004bb1f  4903cb                   add rcx, r11
0004bb22  ffe1                     jmp rcx
0004bb24  41f6c202                 test r10b, 2
0004bb28  750f                     jne 0x4bb39
0004bb2a  85ff                     test edi, edi
0004bb2c  7e0b                     jle 0x4bb39
0004bb2e  418bc1                   mov eax, r9d
0004bb31  eb1d                     jmp 0x4bb50
0004bb33  41f6c204                 test r10b, 4
0004bb37  74f5                     je 0x4bb2e
0004bb39  4983c402                 add r12, 2
0004bb3d  4183ee01                 sub r14d, 1
0004bb41  75ad                     jne 0x4baf0
0004bb43  83ff07                   cmp edi, 7
0004bb46  b802000000               mov eax, 2
0004bb4b  0f44d0                   cmove edx, eax
0004bb4e  8bc2                     mov eax, edx
0004bb50  488b9c2428010000         mov rbx, qword ptr [rsp + 0x128]
0004bb58  4c8bac2418010000         mov r13, qword ptr [rsp + 0x118]
0004bb60  488bbc2420010000         mov rdi, qword ptr [rsp + 0x120]
0004bb68  4881c430010000           add rsp, 0x130
0004bb6f  415f                     pop r15
0004bb71  415e                     pop r14
0004bb73  415c                     pop r12
0004bb75  5e                       pop rsi
0004bb76  5d                       pop rbp
0004bb77  c3                       ret

; chunk at RVA 0x4bb78 (104 bytes)
0004bb78  98                       cwde
0004bb79  ae                       scasb al, byte ptr [rdi]
0004bb7a  0400                     add al, 0
0004bb7c  a7                       cmpsd dword ptr [rsi], dword ptr [rdi]
0004bb7d  ab                       stosd dword ptr [rdi], eax
0004bb7e  0400                     add al, 0
0004bb80  94                       xchg esp, eax
0004bb81  ae                       scasb al, byte ptr [rdi]
0004bb82  0400                     add al, 0
0004bb84  98                       cwde
0004bb85  ae                       scasb al, byte ptr [rdi]
0004bb86  0400                     add al, 0
0004bb88  87ac0400afad04           xchg dword ptr [rsp + rax + 0x4adaf00], ebp
0004bb8f  002e                     add byte ptr [rsi], ch
0004bb91  ac                       lodsb al, byte ptr [rsi]
0004bb92  0400                     add al, 0
0004bb94  1bb30400c5ae             sbb esi, dword ptr [rbx - 0x513afffc]
0004bb9a  0400                     add al, 0
0004bb9c  1bb304001bb3             sbb esi, dword ptr [rbx - 0x4ce4fffc]
0004bba2  0400                     add al, 0
0004bba4  dcb0040070b2             fdiv qword ptr [rax - 0x4d8ffffc]
0004bbaa  0400                     add al, 0
0004bbac  48af                     scasq rax, qword ptr [rdi]
0004bbae  0400                     add al, 0
0004bbb0  39bb040024bb             cmp dword ptr [rbx - 0x44dbfffc], edi
0004bbb6  0400                     add al, 0
0004bbb8  2ebb04002ebb             mov ebx, 0xbb2e0004
0004bbbe  0400                     add al, 0
0004bbc0  2ebb04002ebb             mov ebx, 0xbb2e0004
0004bbc6  0400                     add al, 0
0004bbc8  33bb040033bb             xor edi, dword ptr [rbx - 0x44ccfffc]
0004bbce  0400                     add al, 0
0004bbd0  33bb040033bb             xor edi, dword ptr [rbx - 0x44ccfffc]
0004bbd6  0400                     add al, 0
0004bbd8  33bb040033bb             xor edi, dword ptr [rbx - 0x44ccfffc]
0004bbde  0400                     add al, 0
