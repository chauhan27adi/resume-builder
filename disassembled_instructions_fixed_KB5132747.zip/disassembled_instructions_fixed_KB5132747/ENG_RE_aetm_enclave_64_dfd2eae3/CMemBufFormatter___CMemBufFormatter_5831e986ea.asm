; CMemBufFormatter::~CMemBufFormatter
; aetm_enclave.dll, primary RVA 0x40bf0, 173 bytes in 3 chunk(s)

; chunk at RVA 0x40bf0 (30 bytes)
00040bf0  4889742418               mov qword ptr [rsp + 0x18], rsi
00040bf5  57                       push rdi
00040bf6  4883ec20                 sub rsp, 0x20
00040bfa  488b5118                 mov rdx, qword ptr [rcx + 0x18]
00040bfe  488d7910                 lea rdi, [rcx + 0x10]
00040c02  488bf1                   mov rsi, rcx
00040c05  483bd7                   cmp rdx, rdi
00040c08  0f8484000000             je 0x40c92

; chunk at RVA 0x40c0e (132 bytes)
00040c0e  48895c2430               mov qword ptr [rsp + 0x30], rbx
00040c13  48896c2438               mov qword ptr [rsp + 0x38], rbp
00040c18  33ed                     xor ebp, ebp
00040c1a  660f1f440000             nop word ptr [rax + rax]
00040c20  4885d2                   test rdx, rdx
00040c23  488d42f8                 lea rax, [rdx - 8]
00040c27  488bdd                   mov rbx, rbp
00040c2a  480f45d8                 cmovne rbx, rax
00040c2e  488b4308                 mov rax, qword ptr [rbx + 8]
00040c32  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
00040c36  48894808                 mov qword ptr [rax + 8], rcx
00040c3a  488901                   mov qword ptr [rcx], rax
00040c3d  48896b10                 mov qword ptr [rbx + 0x10], rbp
00040c41  48896b08                 mov qword ptr [rbx + 8], rbp
00040c45  40386e28                 cmp byte ptr [rsi + 0x28], bpl
00040c49  741f                     je 0x40c6a
00040c4b  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00040c4f  488b01                   mov rax, qword ptr [rcx]
00040c52  ff5050                   call qword ptr [rax + 0x50]
00040c55  41b801000000             mov r8d, 1
00040c5b  488bd3                   mov rdx, rbx
00040c5e  488bc8                   mov rcx, rax
00040c61  4c8b08                   mov r9, qword ptr [rax]
00040c64  41ff5110                 call qword ptr [r9 + 0x10]
00040c68  eb15                     jmp 0x40c7f
00040c6a  488b0b                   mov rcx, qword ptr [rbx]
00040c6d  e8cac10100               call 0x5ce3c
00040c72  ba18000000               mov edx, 0x18
00040c77  488bcb                   mov rcx, rbx
00040c7a  e8d1c20100               call 0x5cf50
00040c7f  488b5708                 mov rdx, qword ptr [rdi + 8]
00040c83  483bd7                   cmp rdx, rdi
00040c86  7598                     jne 0x40c20
00040c88  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
00040c8d  488b5c2430               mov rbx, qword ptr [rsp + 0x30]

; chunk at RVA 0x40c92 (11 bytes)
00040c92  488b742440               mov rsi, qword ptr [rsp + 0x40]
00040c97  4883c420                 add rsp, 0x20
00040c9b  5f                       pop rdi
00040c9c  c3                       ret
