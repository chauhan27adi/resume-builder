; `CTrustedMachine::Init'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x5fcf0, 34 bytes in 1 chunk(s)

; chunk at RVA 0x5fcf0 (34 bytes)
0005fcf0  4055                     push rbp
0005fcf2  4883ec20                 sub rsp, 0x20
0005fcf6  488bea                   mov rbp, rdx
0005fcf9  488b5558                 mov rdx, qword ptr [rbp + 0x58]
0005fcfd  488b12                   mov rdx, qword ptr [rdx]
0005fd00  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
0005fd07  e8d49bfbff               call 0x198e0
0005fd0c  4883c420                 add rsp, 0x20
0005fd10  5d                       pop rbp
0005fd11  c3                       ret
