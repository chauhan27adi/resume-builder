; CTrustedMachine::ClearKey
; aetm_enclave.dll, primary RVA 0xdf20, 845 bytes in 6 chunk(s)

; chunk at RVA 0xdf20 (215 bytes)
0000df20  4053                     push rbx
0000df22  55                       push rbp
0000df23  57                       push rdi
0000df24  4883ec30                 sub rsp, 0x30
0000df28  488da9c0da4700           lea rbp, [rcx + 0x47dac0]
0000df2f  90                       nop
0000df30  440fb69900db4700         movzx r11d, byte ptr [rcx + 0x47db00]
0000df38  4c8d91c0da5000           lea r10, [rcx + 0x50dac0]
0000df3f  0fb7da                   movzx ebx, dx
0000df42  488bf9                   mov rdi, rcx
0000df45  488bc5                   mov rax, rbp
0000df48  493bea                   cmp rbp, r10
0000df4b  7317                     jae 0xdf64
0000df4d  0f1f00                   nop dword ptr [rax]
0000df50  4584db                   test r11b, r11b
0000df53  750f                     jne 0xdf64
0000df55  4883c048                 add rax, 0x48
0000df59  90                       nop
0000df5a  440fb65840               movzx r11d, byte ptr [rax + 0x40]
0000df5f  493bc2                   cmp rax, r10
0000df62  72ec                     jb 0xdf50
0000df64  90                       nop
0000df65  410fb64a40               movzx ecx, byte ptr [r10 + 0x40]
0000df6a  488bd0                   mov rdx, rax
0000df6d  493bc2                   cmp rax, r10
0000df70  0f84d7020000             je 0xe24d
0000df76  663918                   cmp word ptr [rax], bx
0000df79  750c                     jne 0xdf87
0000df7b  44394004                 cmp dword ptr [rax + 4], r8d
0000df7f  7506                     jne 0xdf87
0000df81  4c394808                 cmp qword ptr [rax + 8], r9
0000df85  742d                     je 0xdfb4
0000df87  4883c048                 add rax, 0x48
0000df8b  90                       nop
0000df8c  493bd2                   cmp rdx, r10
0000df8f  480f43c2                 cmovae rax, rdx
0000df93  0fb64840                 movzx ecx, byte ptr [rax + 0x40]
0000df97  493bc2                   cmp rax, r10
0000df9a  73c8                     jae 0xdf64
0000df9c  0f1f4000                 nop dword ptr [rax]
0000dfa0  84c9                     test cl, cl
0000dfa2  75c0                     jne 0xdf64
0000dfa4  4883c048                 add rax, 0x48
0000dfa8  90                       nop
0000dfa9  0fb64840                 movzx ecx, byte ptr [rax + 0x40]
0000dfad  493bc2                   cmp rax, r10
0000dfb0  72ee                     jb 0xdfa0
0000dfb2  ebb0                     jmp 0xdf64
0000dfb4  90                       nop
0000dfb5  482bd5                   sub rdx, rbp
0000dfb8  0fb64840                 movzx ecx, byte ptr [rax + 0x40]
0000dfbc  90                       nop
0000dfbd  48b9398ee3388ee3388e     movabs rcx, 0x8e38e38e38e38e39
0000dfc7  48c1fa03                 sar rdx, 3
0000dfcb  480fafd1                 imul rdx, rcx
0000dfcf  488b4838                 mov rcx, qword ptr [rax + 0x38]
0000dfd3  48c1e920                 shr rcx, 0x20
0000dfd7  4863c2                   movsxd rax, edx
0000dfda  48c1e020                 shl rax, 0x20
0000dfde  480bc1                   or rax, rcx
0000dfe1  4889442450               mov qword ptr [rsp + 0x50], rax
0000dfe6  4883f8ff                 cmp rax, -1
0000dfea  0f845d020000             je 0xe24d
0000dff0  4c8d8fc85a5100           lea r9, [rdi + 0x515ac8]

; chunk at RVA 0xdff7 (12 bytes)
0000dff7  4889742458               mov qword ptr [rsp + 0x58], rsi
0000dffc  4c8d87c85a5600           lea r8, [rdi + 0x565ac8]

; chunk at RVA 0xe003 (409 bytes)
0000e003  4c89742460               mov qword ptr [rsp + 0x60], r14
0000e008  4c897c2468               mov qword ptr [rsp + 0x68], r15
0000e00d  90                       nop
0000e00e  0fb687e85a5100           movzx eax, byte ptr [rdi + 0x515ae8]
0000e015  498bd1                   mov rdx, r9
0000e018  4d3bc8                   cmp r9, r8
0000e01b  7315                     jae 0xe032
0000e01d  0f1f00                   nop dword ptr [rax]
0000e020  84c0                     test al, al
0000e022  750e                     jne 0xe032
0000e024  4883c228                 add rdx, 0x28
0000e028  90                       nop
0000e029  0fb64220                 movzx eax, byte ptr [rdx + 0x20]
0000e02d  493bd0                   cmp rdx, r8
0000e030  72ee                     jb 0xe020
0000e032  48be00000000ffffffff     movabs rsi, 0xffffffff00000000
0000e03c  49bfcdcccccccccccccc     movabs r15, 0xcccccccccccccccd
0000e046  49be0000000001000000     movabs r14, 0x100000000
0000e050  90                       nop
0000e051  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000e056  4c8bd2                   mov r10, rdx
0000e059  493bd0                   cmp rdx, r8
0000e05c  0f84f9000000             je 0xe15b
0000e062  488b442450               mov rax, qword ptr [rsp + 0x50]
0000e067  483902                   cmp qword ptr [rdx], rax
0000e06a  0f85b0000000             jne 0xe120
0000e070  90                       nop
0000e071  488bca                   mov rcx, rdx
0000e074  0fb64220                 movzx eax, byte ptr [rdx + 0x20]
0000e078  492bc9                   sub rcx, r9
0000e07b  90                       nop
0000e07c  48c1f903                 sar rcx, 3
0000e080  488b4218                 mov rax, qword ptr [rdx + 0x18]
0000e084  90                       nop
0000e085  48c1e820                 shr rax, 0x20
0000e089  490fafcf                 imul rcx, r15
0000e08d  4863d1                   movsxd rdx, ecx
0000e090  48c1e220                 shl rdx, 0x20
0000e094  480bd0                   or rdx, rax
0000e097  488bc2                   mov rax, rdx
0000e09a  48c1e820                 shr rax, 0x20
0000e09e  8bc8                     mov ecx, eax
0000e0a0  25ff1f0000               and eax, 0x1fff
0000e0a5  8bd8                     mov ebx, eax
0000e0a7  488d0480                 lea rax, [rax + rax*4]
0000e0ab  450fb65cc121             movzx r11d, byte ptr [r9 + rax*8 + 0x21]
0000e0b1  90                       nop
0000e0b2  498b44c118               mov rax, qword ptr [r9 + rax*8 + 0x18]
0000e0b7  48c1e820                 shr rax, 0x20
0000e0bb  3bc2                     cmp eax, edx
0000e0bd  755a                     jne 0xe119
0000e0bf  4584db                   test r11b, r11b
0000e0c2  7455                     je 0xe119
0000e0c4  81e1ff1f0000             and ecx, 0x1fff
0000e0ca  90                       nop
0000e0cb  488d0489                 lea rax, [rcx + rcx*4]
0000e0cf  498d14c1                 lea rdx, [r9 + rax*8]
0000e0d3  498b44c118               mov rax, qword ptr [r9 + rax*8 + 0x18]
0000e0d8  85c0                     test eax, eax
0000e0da  753d                     jne 0xe119
0000e0dc  488bc8                   mov rcx, rax
0000e0df  4823ce                   and rcx, rsi
0000e0e2  4903ce                   add rcx, r14
0000e0e5  f0480fb14a18             lock cmpxchg qword ptr [rdx + 0x18], rcx
0000e0eb  752c                     jne 0xe119
0000e0ed  c6422000                 mov byte ptr [rdx + 0x20], 0
0000e0f1  c6422100                 mov byte ptr [rdx + 0x21], 0
0000e0f5  90                       nop
0000e0f6  488b4218                 mov rax, qword ptr [rdx + 0x18]
0000e0fa  48c1e820                 shr rax, 0x20
0000e0fe  83f8ff                   cmp eax, -1
0000e101  7416                     je 0xe119
0000e103  49638100800500           movsxd rax, dword ptr [r9 + 0x58000]
0000e10a  41899c8100000500         mov dword ptr [r9 + rax*4 + 0x50000], ebx
0000e112  41ff8100800500           inc dword ptr [r9 + 0x58000]
0000e119  48ff0d30784600           dec qword ptr [rip + 0x467830]
0000e120  4d3bd0                   cmp r10, r8
0000e123  498d5228                 lea rdx, [r10 + 0x28]
0000e127  90                       nop
0000e128  490f43d2                 cmovae rdx, r10
0000e12c  0fb64220                 movzx eax, byte ptr [rdx + 0x20]
0000e130  493bd0                   cmp rdx, r8
0000e133  0f8317ffffff             jae 0xe050
0000e139  0f1f8000000000           nop dword ptr [rax]
0000e140  84c0                     test al, al
0000e142  0f8508ffffff             jne 0xe050
0000e148  4883c228                 add rdx, 0x28
0000e14c  90                       nop
0000e14d  0fb64220                 movzx eax, byte ptr [rdx + 0x20]
0000e151  493bd0                   cmp rdx, r8
0000e154  72ea                     jb 0xe140
0000e156  e9f5feffff               jmp 0xe050
0000e15b  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
0000e160  90                       nop
0000e161  4c8b7c2468               mov r15, qword ptr [rsp + 0x68]
0000e166  4c8b742460               mov r14, qword ptr [rsp + 0x60]
0000e16b  48c1e920                 shr rcx, 0x20
0000e16f  488bc1                   mov rax, rcx
0000e172  25ff1f0000               and eax, 0x1fff
0000e177  488d04c0                 lea rax, [rax + rax*8]
0000e17b  488d34c500000000         lea rsi, [rax*8]
0000e183  0fb6542e41               movzx edx, byte ptr [rsi + rbp + 0x41]
0000e188  90                       nop
0000e189  488b442e38               mov rax, qword ptr [rsi + rbp + 0x38]
0000e18e  48c1e820                 shr rax, 0x20
0000e192  3b442450                 cmp eax, dword ptr [rsp + 0x50]
0000e196  0f85b9000000             jne 0xe255

; chunk at RVA 0xe19c (177 bytes)
0000e19c  84d2                     test dl, dl
0000e19e  0f84b1000000             je 0xe255
0000e1a4  81e1ff1f0000             and ecx, 0x1fff
0000e1aa  4881c7b85a4100           add rdi, 0x415ab8
0000e1b1  488d04c9                 lea rax, [rcx + rcx*8]
0000e1b5  488d1cc500000000         lea rbx, [rax*8]
0000e1bd  488b4c2b30               mov rcx, qword ptr [rbx + rbp + 0x30]
0000e1c2  90                       nop
0000e1c3  488bc1                   mov rax, rcx
0000e1c6  48c1e820                 shr rax, 0x20
0000e1ca  25ff1f0000               and eax, 0x1fff
0000e1cf  488d0440                 lea rax, [rax + rax*2]
0000e1d3  4803c0                   add rax, rax
0000e1d6  0fb654c729               movzx edx, byte ptr [rdi + rax*8 + 0x29]
0000e1db  90                       nop
0000e1dc  488b44c720               mov rax, qword ptr [rdi + rax*8 + 0x20]
0000e1e1  48c1e820                 shr rax, 0x20
0000e1e5  3bc1                     cmp eax, ecx
0000e1e7  756c                     jne 0xe255
0000e1e9  84d2                     test dl, dl
0000e1eb  7468                     je 0xe255
0000e1ed  488b442b30               mov rax, qword ptr [rbx + rbp + 0x30]
0000e1f2  48c1e820                 shr rax, 0x20
0000e1f6  25ff1f0000               and eax, 0x1fff
0000e1fb  488d0c40                 lea rcx, [rax + rax*2]
0000e1ff  48c1e104                 shl rcx, 4
0000e203  4803cf                   add rcx, rdi
0000e206  e8d5b0ffff               call 0x92e0
0000e20b  90                       nop
0000e20c  0fb6542e41               movzx edx, byte ptr [rsi + rbp + 0x41]
0000e211  90                       nop
0000e212  488b442e38               mov rax, qword ptr [rsi + rbp + 0x38]
0000e217  48c1e820                 shr rax, 0x20
0000e21b  3b442450                 cmp eax, dword ptr [rsp + 0x50]
0000e21f  7534                     jne 0xe255
0000e221  84d2                     test dl, dl
0000e223  7430                     je 0xe255
0000e225  488d5530                 lea rdx, [rbp + 0x30]
0000e229  488bcf                   mov rcx, rdi
0000e22c  4803d3                   add rdx, rbx
0000e22f  e8ec210000               call 0x10420
0000e234  488d542450               lea rdx, [rsp + 0x50]
0000e239  488bcd                   mov rcx, rbp
0000e23c  e81f210000               call 0x10360
0000e241  48ff0d00774600           dec qword ptr [rip + 0x467700]
0000e248  488b742458               mov rsi, qword ptr [rsp + 0x58]

; chunk at RVA 0xe24d (8 bytes)
0000e24d  4883c430                 add rsp, 0x30
0000e251  5f                       pop rdi
0000e252  5d                       pop rbp
0000e253  5b                       pop rbx
0000e254  c3                       ret

; chunk at RVA 0xe255 (24 bytes)
0000e255  ba5f000000               mov edx, 0x5f
0000e25a  b94b010000               mov ecx, 0x14b
0000e25f  448d4aa2                 lea r9d, [rdx - 0x5e]
0000e263  448d42b2                 lea r8d, [rdx - 0x4e]
0000e267  e834b10000               call 0x193a0
0000e26c  cc                       int3
