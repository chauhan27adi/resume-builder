; CBCryptRSAProvider::~CBCryptRSAProvider
; aetm_enclave.dll, primary RVA 0x18dc0, 81 bytes in 1 chunk(s)

; chunk at RVA 0x18dc0 (81 bytes)
00018dc0  48894c2408               mov qword ptr [rsp + 8], rcx
00018dc5  53                       push rbx
00018dc6  4883ec30                 sub rsp, 0x30
00018dca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00018dd3  488bd9                   mov rbx, rcx
00018dd6  488d4108                 lea rax, [rcx + 8]
00018dda  4889442448               mov qword ptr [rsp + 0x48], rax
00018ddf  488d0dfaba0400           lea rcx, [rip + 0x4bafa]
00018de6  488908                   mov qword ptr [rax], rcx
00018de9  4883c008                 add rax, 8
00018ded  4889442450               mov qword ptr [rsp + 0x50], rax
00018df2  488b08                   mov rcx, qword ptr [rax]
00018df5  4885c9                   test rcx, rcx
00018df8  7407                     je 0x18e01
00018dfa  ff15d8a20400             call qword ptr [rip + 0x4a2d8]
00018e00  90                       nop
00018e01  488d05f0ba0400           lea rax, [rip + 0x4baf0]
00018e08  488903                   mov qword ptr [rbx], rax
00018e0b  4883c430                 add rsp, 0x30
00018e0f  5b                       pop rbx
00018e10  c3                       ret
