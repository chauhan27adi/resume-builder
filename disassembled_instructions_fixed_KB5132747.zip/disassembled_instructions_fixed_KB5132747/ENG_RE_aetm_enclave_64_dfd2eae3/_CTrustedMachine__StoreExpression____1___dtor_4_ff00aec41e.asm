; `CTrustedMachine::StoreExpression'::`1'::dtor$4
; aetm_enclave.dll, primary RVA 0x5ff20, 28 bytes in 1 chunk(s)

; chunk at RVA 0x5ff20 (28 bytes)
0005ff20  4055                     push rbp
0005ff22  4883ec20                 sub rsp, 0x20
0005ff26  488bea                   mov rbp, rdx
0005ff29  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0005ff2d  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
0005ff31  e8aa99fbff               call 0x198e0
0005ff36  4883c420                 add rsp, 0x20
0005ff3a  5d                       pop rbp
0005ff3b  c3                       ret
