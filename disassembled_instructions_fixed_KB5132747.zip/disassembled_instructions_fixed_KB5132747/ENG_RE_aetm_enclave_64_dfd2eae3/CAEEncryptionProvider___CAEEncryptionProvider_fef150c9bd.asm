; CAEEncryptionProvider::~CAEEncryptionProvider
; aetm_enclave.dll, primary RVA 0x19d80, 71 bytes in 1 chunk(s)

; chunk at RVA 0x19d80 (71 bytes)
00019d80  4053                     push rbx
00019d82  4883ec20                 sub rsp, 0x20
00019d86  488bd9                   mov rbx, rcx
00019d89  488b4970                 mov rcx, qword ptr [rcx + 0x70]
00019d8d  4885c9                   test rcx, rcx
00019d90  7413                     je 0x19da5
00019d92  488b01                   mov rax, qword ptr [rcx]
00019d95  ba01000000               mov edx, 1
00019d9a  ff5010                   call qword ptr [rax + 0x10]
00019d9d  48c7437000000000         mov qword ptr [rbx + 0x70], 0
00019da5  488b4b78                 mov rcx, qword ptr [rbx + 0x78]
00019da9  4885c9                   test rcx, rcx
00019dac  7413                     je 0x19dc1
00019dae  488b01                   mov rax, qword ptr [rcx]
00019db1  ba01000000               mov edx, 1
00019db6  ff5010                   call qword ptr [rax + 0x10]
00019db9  48c7437800000000         mov qword ptr [rbx + 0x78], 0
00019dc1  4883c420                 add rsp, 0x20
00019dc5  5b                       pop rbx
00019dc6  c3                       ret
