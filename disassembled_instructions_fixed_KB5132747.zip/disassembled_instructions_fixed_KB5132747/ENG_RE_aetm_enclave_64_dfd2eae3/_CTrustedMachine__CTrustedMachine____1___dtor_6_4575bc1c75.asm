; `CTrustedMachine::CTrustedMachine'::`1'::dtor$6
; aetm_enclave.dll, primary RVA 0x5faa0, 42 bytes in 1 chunk(s)

; chunk at RVA 0x5faa0 (42 bytes)
0005faa0  4055                     push rbp
0005faa2  4883ec20                 sub rsp, 0x20
0005faa6  488bea                   mov rbp, rdx
0005faa9  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
0005faad  4c8d0d2ca0faff           lea r9, [rip - 0x55fd4]
0005fab4  41b800080000             mov r8d, 0x800
0005faba  ba30000000               mov edx, 0x30
0005fabf  e8bcd3ffff               call 0x5ce80
0005fac4  4883c420                 add rsp, 0x20
0005fac8  5d                       pop rbp
0005fac9  c3                       ret
