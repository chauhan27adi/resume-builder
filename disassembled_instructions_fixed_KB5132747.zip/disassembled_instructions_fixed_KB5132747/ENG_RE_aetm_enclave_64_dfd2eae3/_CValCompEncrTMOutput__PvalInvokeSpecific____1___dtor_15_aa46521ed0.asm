; `CValCompEncrTMOutput::PvalInvokeSpecific'::`1'::dtor$15
; aetm_enclave.dll, primary RVA 0x60b60, 38 bytes in 1 chunk(s)

; chunk at RVA 0x60b60 (38 bytes)
00060b60  4055                     push rbp
00060b62  4883ec20                 sub rsp, 0x20
00060b66  488bea                   mov rbp, rdx
00060b69  8b4530                   mov eax, dword ptr [rbp + 0x30]
00060b6c  83e004                   and eax, 4
00060b6f  85c0                     test eax, eax
00060b71  740d                     je 0x60b80
00060b73  836530fb                 and dword ptr [rbp + 0x30], 0xfffffffb
00060b77  488d4d50                 lea rcx, [rbp + 0x50]
00060b7b  e80092fbff               call 0x19d80
00060b80  4883c420                 add rsp, 0x20
00060b84  5d                       pop rbp
00060b85  c3                       ret
