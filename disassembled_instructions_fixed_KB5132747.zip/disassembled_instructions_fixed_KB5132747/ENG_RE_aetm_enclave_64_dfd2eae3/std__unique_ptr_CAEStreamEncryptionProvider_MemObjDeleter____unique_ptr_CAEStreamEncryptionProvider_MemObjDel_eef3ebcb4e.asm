; std::unique_ptr<CAEStreamEncryptionProvider,MemObjDeleter>::~unique_ptr<CAEStreamEncryptionProvider,MemObjDeleter>
; aetm_enclave.dll, primary RVA 0x172b0, 106 bytes in 1 chunk(s)

; chunk at RVA 0x172b0 (106 bytes)
000172b0  4057                     push rdi
000172b2  4883ec30                 sub rsp, 0x30
000172b6  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000172bf  48895c2440               mov qword ptr [rsp + 0x40], rbx
000172c4  488bf9                   mov rdi, rcx
000172c7  488b5908                 mov rbx, qword ptr [rcx + 8]
000172cb  4885db                   test rbx, rbx
000172ce  743f                     je 0x1730f
000172d0  488d05d1d60400           lea rax, [rip + 0x4d6d1]
000172d7  488903                   mov qword ptr [rbx], rax
000172da  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
000172de  4885c9                   test rcx, rcx
000172e1  740b                     je 0x172ee
000172e3  488b01                   mov rax, qword ptr [rcx]
000172e6  ba01000000               mov edx, 1
000172eb  ff5010                   call qword ptr [rax + 0x10]
000172ee  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
000172f2  4885c9                   test rcx, rcx
000172f5  740b                     je 0x17302
000172f7  488b01                   mov rax, qword ptr [rcx]
000172fa  ba01000000               mov edx, 1
000172ff  ff5010                   call qword ptr [rax + 0x10]
00017302  488b0f                   mov rcx, qword ptr [rdi]
00017305  488b01                   mov rax, qword ptr [rcx]
00017308  488bd3                   mov rdx, rbx
0001730b  ff5028                   call qword ptr [rax + 0x28]
0001730e  90                       nop
0001730f  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00017314  4883c430                 add rsp, 0x30
00017318  5f                       pop rdi
00017319  c3                       ret
