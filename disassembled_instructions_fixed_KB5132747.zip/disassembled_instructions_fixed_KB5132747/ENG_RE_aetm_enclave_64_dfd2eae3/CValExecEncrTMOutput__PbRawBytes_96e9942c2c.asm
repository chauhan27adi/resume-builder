; CValExecEncrTMOutput::PbRawBytes
; aetm_enclave.dll, primary RVA 0x16560, 1004 bytes in 18 chunk(s)

; chunk at RVA 0x16560 (53 bytes)
00016560  4883ec38                 sub rsp, 0x38
00016564  0fb681a8000000           movzx eax, byte ptr [rcx + 0xa8]
0001656b  4c8d0d8e9afeff           lea r9, [rip - 0x16572]
00016572  4c8bd2                   mov r10, rdx
00016575  4c8bc1                   mov r8, rcx
00016578  420fb69408405a0600       movzx edx, byte ptr [rax + r9 + 0x65a40]
00016581  4280bc0a405b060001       cmp byte ptr [rdx + r9 + 0x65b40], 1
0001658a  7509                     jne 0x16595
0001658c  498b4208                 mov rax, qword ptr [r10 + 8]
00016590  4883c438                 add rsp, 0x38
00016594  c3                       ret

; chunk at RVA 0x16595 (103 bytes)
00016595  48895c2430               mov qword ptr [rsp + 0x30], rbx
0001659a  83c0dc                   add eax, -0x24
0001659d  488d9990000000           lea rbx, [rcx + 0x90]
000165a4  c60300                   mov byte ptr [rbx], 0
000165a7  48c7819100000000000000   mov qword ptr [rcx + 0x91], 0
000165b2  48c7819900000000000000   mov qword ptr [rcx + 0x99], 0
000165bd  83f85b                   cmp eax, 0x5b
000165c0  0f87e9020000             ja 0x168af
000165c6  4898                     cdqe
000165c8  410fb68401f0680100       movzx eax, byte ptr [r9 + rax + 0x168f0]
000165d1  418b8c81bc680100         mov ecx, dword ptr [r9 + rax*4 + 0x168bc]
000165d9  4903c9                   add rcx, r9
000165dc  ffe1                     jmp rcx
000165de  410fb64208               movzx eax, byte ptr [r10 + 8]
000165e3  4885db                   test rbx, rbx
000165e6  0f84b1020000             je 0x1689d
000165ec  488903                   mov qword ptr [rbx], rax
000165ef  488bc3                   mov rax, rbx
000165f2  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000165f7  4883c438                 add rsp, 0x38
000165fb  c3                       ret

; chunk at RVA 0x165fc (30 bytes)
000165fc  490fbf4208               movsx rax, word ptr [r10 + 8]
00016601  4885db                   test rbx, rbx
00016604  0f8493020000             je 0x1689d
0001660a  488903                   mov qword ptr [rbx], rax
0001660d  488bc3                   mov rax, rbx
00016610  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016615  4883c438                 add rsp, 0x38
00016619  c3                       ret

; chunk at RVA 0x1661a (29 bytes)
0001661a  49634208                 movsxd rax, dword ptr [r10 + 8]
0001661e  4885db                   test rbx, rbx
00016621  0f8476020000             je 0x1689d
00016627  488903                   mov qword ptr [rbx], rax
0001662a  488bc3                   mov rax, rbx
0001662d  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016632  4883c438                 add rsp, 0x38
00016636  c3                       ret

; chunk at RVA 0x16637 (29 bytes)
00016637  498b4208                 mov rax, qword ptr [r10 + 8]
0001663b  4885db                   test rbx, rbx
0001663e  0f8459020000             je 0x1689d
00016644  488903                   mov qword ptr [rbx], rax
00016647  488bc3                   mov rax, rbx
0001664a  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0001664f  4883c438                 add rsp, 0x38
00016653  c3                       ret

; chunk at RVA 0x16654 (40 bytes)
00016654  f3410f104208             movss xmm0, dword ptr [r10 + 8]
0001665a  f30f11442440             movss dword ptr [rsp + 0x40], xmm0
00016660  4885db                   test rbx, rbx
00016663  0f8434020000             je 0x1689d
00016669  8b442440                 mov eax, dword ptr [rsp + 0x40]
0001666d  8903                     mov dword ptr [rbx], eax
0001666f  488bc3                   mov rax, rbx
00016672  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016677  4883c438                 add rsp, 0x38
0001667b  c3                       ret

; chunk at RVA 0x1667c (42 bytes)
0001667c  f2410f104208             movsd xmm0, qword ptr [r10 + 8]
00016682  f20f11442450             movsd qword ptr [rsp + 0x50], xmm0
00016688  4885db                   test rbx, rbx
0001668b  0f840c020000             je 0x1689d
00016691  488b442450               mov rax, qword ptr [rsp + 0x50]
00016696  488903                   mov qword ptr [rbx], rax
00016699  488bc3                   mov rax, rbx
0001669c  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000166a1  4883c438                 add rsp, 0x38
000166a5  c3                       ret

; chunk at RVA 0x166a6 (43 bytes)
000166a6  498d4208                 lea rax, [r10 + 8]
000166aa  4885db                   test rbx, rbx
000166ad  7422                     je 0x166d1
000166af  4885c0                   test rax, rax
000166b2  741d                     je 0x166d1
000166b4  488b00                   mov rax, qword ptr [rax]
000166b7  488903                   mov qword ptr [rbx], rax
000166ba  8bc8                     mov ecx, eax
000166bc  8b4304                   mov eax, dword ptr [rbx + 4]
000166bf  8903                     mov dword ptr [rbx], eax
000166c1  488bc3                   mov rax, rbx
000166c4  894b04                   mov dword ptr [rbx + 4], ecx
000166c7  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000166cc  4883c438                 add rsp, 0x38
000166d0  c3                       ret

; chunk at RVA 0x166d1 (41 bytes)
000166d1  ff15c1ca0400             call qword ptr [rip + 0x4cac1]
000166d7  c70016000000             mov dword ptr [rax], 0x16
000166dd  ff15bdca0400             call qword ptr [rip + 0x4cabd]
000166e3  8b4304                   mov eax, dword ptr [rbx + 4]
000166e6  8b0b                     mov ecx, dword ptr [rbx]
000166e8  8903                     mov dword ptr [rbx], eax
000166ea  488bc3                   mov rax, rbx
000166ed  894b04                   mov dword ptr [rbx + 4], ecx
000166f0  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000166f5  4883c438                 add rsp, 0x38
000166f9  c3                       ret

; chunk at RVA 0x166fa (45 bytes)
000166fa  410fb6521b               movzx edx, byte ptr [r10 + 0x1b]
000166ff  498d4a08                 lea rcx, [r10 + 8]
00016703  4c8bcb                   mov r9, rbx
00016706  c744242011000000         mov dword ptr [rsp + 0x20], 0x11
0001670e  4981c0a8000000           add r8, 0xa8
00016715  e8f6100000               call 0x17810
0001671a  488bc3                   mov rax, rbx
0001671d  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016722  4883c438                 add rsp, 0x38
00016726  c3                       ret

; chunk at RVA 0x16727 (31 bytes)
00016727  ff156bca0400             call qword ptr [rip + 0x4ca6b]
0001672d  c70022000000             mov dword ptr [rax], 0x22
00016733  ff1567ca0400             call qword ptr [rip + 0x4ca67]
00016739  488bc3                   mov rax, rbx
0001673c  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016741  4883c438                 add rsp, 0x38
00016745  c3                       ret

; chunk at RVA 0x16746 (69 bytes)
00016746  498bd2                   mov rdx, r10
00016749  498bc8                   mov rcx, r8
0001674c  e80f020000               call 0x16960
00016751  448bc0                   mov r8d, eax
00016754  498d5208                 lea rdx, [r10 + 8]
00016758  85c0                     test eax, eax
0001675a  7467                     je 0x167c3
0001675c  4885db                   test rbx, rbx
0001675f  7450                     je 0x167b1
00016761  4885d2                   test rdx, rdx
00016764  744b                     je 0x167b1
00016766  4983f811                 cmp r8, 0x11
0001676a  771f                     ja 0x1678b
0001676c  0faee8                   lfence
0001676f  488bcb                   mov rcx, rbx
00016772  e89c7a0400               call 0x5e213
00016777  8b03                     mov eax, dword ptr [rbx]
00016779  c1c010                   rol eax, 0x10
0001677c  8903                     mov dword ptr [rbx], eax
0001677e  488bc3                   mov rax, rbx
00016781  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016786  4883c438                 add rsp, 0x38
0001678a  c3                       ret

; chunk at RVA 0x1678b (38 bytes)
0001678b  ff1507ca0400             call qword ptr [rip + 0x4ca07]
00016791  c70022000000             mov dword ptr [rax], 0x22
00016797  ff1503ca0400             call qword ptr [rip + 0x4ca03]
0001679d  8b03                     mov eax, dword ptr [rbx]
0001679f  c1c010                   rol eax, 0x10
000167a2  8903                     mov dword ptr [rbx], eax
000167a4  488bc3                   mov rax, rbx
000167a7  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000167ac  4883c438                 add rsp, 0x38
000167b0  c3                       ret

; chunk at RVA 0x167b1 (38 bytes)
000167b1  ff15e1c90400             call qword ptr [rip + 0x4c9e1]
000167b7  c70016000000             mov dword ptr [rax], 0x16
000167bd  ff15ddc90400             call qword ptr [rip + 0x4c9dd]
000167c3  8b03                     mov eax, dword ptr [rbx]
000167c5  c1c010                   rol eax, 0x10
000167c8  8903                     mov dword ptr [rbx], eax
000167ca  488bc3                   mov rax, rbx
000167cd  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000167d2  4883c438                 add rsp, 0x38
000167d6  c3                       ret

; chunk at RVA 0x167d7 (100 bytes)
000167d7  410fb780b8000000         movzx eax, word ptr [r8 + 0xb8]
000167df  b9ffff0000               mov ecx, 0xffff
000167e4  663bc1                   cmp ax, cx
000167e7  740b                     je 0x167f4
000167e9  4280bc0a9073460000       cmp byte ptr [rdx + r9 + 0x467390], 0
000167f2  7405                     je 0x167f9
000167f4  b8a41f0000               mov eax, 0x1fa4
000167f9  440fb7c0                 movzx r8d, ax
000167fd  498d520b                 lea rdx, [r10 + 0xb]
00016801  4d85c0                   test r8, r8
00016804  0f84a5000000             je 0x168af
0001680a  4885db                   test rbx, rbx
0001680d  0f848a000000             je 0x1689d
00016813  4885d2                   test rdx, rdx
00016816  0f8481000000             je 0x1689d
0001681c  4983f811                 cmp r8, 0x11
00016820  0f8701ffffff             ja 0x16727
00016826  488bcb                   mov rcx, rbx
00016829  e8e5790400               call 0x5e213
0001682e  488bc3                   mov rax, rbx
00016831  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016836  4883c438                 add rsp, 0x38
0001683a  c3                       ret

; chunk at RVA 0x1683b (98 bytes)
0001683b  4983c208                 add r10, 8
0001683f  4885db                   test rbx, rbx
00016842  0f8489feffff             je 0x166d1
00016848  4d85d2                   test r10, r10
0001684b  0f8480feffff             je 0x166d1
00016851  418b02                   mov eax, dword ptr [r10]
00016854  8903                     mov dword ptr [rbx], eax
00016856  e988feffff               jmp 0x166e3
0001685b  498bd2                   mov rdx, r10
0001685e  498bc8                   mov rcx, r8
00016861  e8fa000000               call 0x16960
00016866  448bc0                   mov r8d, eax
00016869  498d5208                 lea rdx, [r10 + 8]
0001686d  85c0                     test eax, eax
0001686f  743e                     je 0x168af
00016871  4885db                   test rbx, rbx
00016874  7427                     je 0x1689d
00016876  4885d2                   test rdx, rdx
00016879  7422                     je 0x1689d
0001687b  4983f811                 cmp r8, 0x11
0001687f  0f87a2feffff             ja 0x16727
00016885  0faee8                   lfence
00016888  488bcb                   mov rcx, rbx
0001688b  e883790400               call 0x5e213
00016890  488bc3                   mov rax, rbx
00016893  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016898  4883c438                 add rsp, 0x38
0001689c  c3                       ret

; chunk at RVA 0x1689d (31 bytes)
0001689d  ff15f5c80400             call qword ptr [rip + 0x4c8f5]
000168a3  c70016000000             mov dword ptr [rax], 0x16
000168a9  ff15f1c80400             call qword ptr [rip + 0x4c8f1]
000168af  488bc3                   mov rax, rbx
000168b2  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000168b7  4883c438                 add rsp, 0x38
000168bb  c3                       ret

; chunk at RVA 0x168bc (144 bytes)
000168bc  5b                       pop rbx
000168bd  680100fa66               push 0x66fa0001
000168c2  0100                     add dword ptr [rax], eax
000168c4  de6501                   fisub word ptr [rbp + 1]
000168c7  00fc                     add ah, bh
000168c9  650100                   add dword ptr gs:[rax], eax
000168cc  1a6601                   sbb ah, byte ptr [rsi + 1]
000168cf  004667                   add byte ptr [rsi + 0x67], al
000168d2  0100                     add dword ptr [rax], eax
000168d4  54                       push rsp
000168d5  660100                   add word ptr [rax], ax
000168d8  a6                       cmpsb byte ptr [rsi], byte ptr [rdi]
000168d9  660100                   add word ptr [rax], ax
000168dc  7c66                     jl 0x16944
000168de  0100                     add dword ptr [rax], eax
000168e0  d7                       xlatb
000168e1  670100                   add dword ptr [eax], eax
000168e4  3b6801                   cmp ebp, dword ptr [rax + 1]
000168e7  0037                     add byte ptr [rdi], dh
000168e9  660100                   add word ptr [rax], ax
000168ec  af                       scasd eax, dword ptr [rdi]
000168ed  680100000c               push 0xc000001
000168f2  0c0c                     or al, 0xc
000168f4  0001                     add byte ptr [rcx], al
000168f6  0101                     add dword ptr [rcx], eax
000168f8  0c0c                     or al, 0xc
000168fa  0c0c                     or al, 0xc
000168fc  020c0c                   add cl, byte ptr [rsp + rcx]
000168ff  0c03                     or al, 3
00016901  0c0c                     or al, 0xc
00016903  0c04                     or al, 4
00016905  0c05                     or al, 5
