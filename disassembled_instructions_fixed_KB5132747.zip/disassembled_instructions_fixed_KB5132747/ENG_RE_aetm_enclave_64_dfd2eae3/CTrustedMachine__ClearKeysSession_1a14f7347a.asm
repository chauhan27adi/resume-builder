; CTrustedMachine::ClearKeysSession
; aetm_enclave.dll, primary RVA 0xb8a0, 720 bytes in 3 chunk(s)

; chunk at RVA 0xb8a0 (17 bytes)
0000b8a0  4889742420               mov qword ptr [rsp + 0x20], rsi
0000b8a5  57                       push rdi
0000b8a6  4156                     push r14
0000b8a8  4157                     push r15
0000b8aa  4c8d91d0da5600           lea r10, [rcx + 0x56dad0]

; chunk at RVA 0xb8b1 (399 bytes)
0000b8b1  48896c2430               mov qword ptr [rsp + 0x30], rbp
0000b8b6  4c8d89d05a5800           lea r9, [rcx + 0x585ad0]
0000b8bd  90                       nop
0000b8be  0fb681f8da5600           movzx eax, byte ptr [rcx + 0x56daf8]
0000b8c5  488bf2                   mov rsi, rdx
0000b8c8  488bf9                   mov rdi, rcx
0000b8cb  4d8bc2                   mov r8, r10
0000b8ce  4d3bd1                   cmp r10, r9
0000b8d1  7313                     jae 0xb8e6
0000b8d3  84c0                     test al, al
0000b8d5  750f                     jne 0xb8e6
0000b8d7  4983c030                 add r8, 0x30
0000b8db  90                       nop
0000b8dc  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000b8e1  4d3bc1                   cmp r8, r9
0000b8e4  72ed                     jb 0xb8d3
0000b8e6  48bdabaaaaaaaaaaaaaa     movabs rbp, 0xaaaaaaaaaaaaaaab
0000b8f0  48895c2428               mov qword ptr [rsp + 0x28], rbx
0000b8f5  49be00000000ffffffff     movabs r14, 0xffffffff00000000
0000b8ff  49bf0000000001000000     movabs r15, 0x100000000
0000b909  0f1f8000000000           nop dword ptr [rax]
0000b910  90                       nop
0000b911  410fb64128               movzx eax, byte ptr [r9 + 0x28]
0000b916  4d8bd8                   mov r11, r8
0000b919  4d3bc1                   cmp r8, r9
0000b91c  0f84fa000000             je 0xba1c
0000b922  493930                   cmp qword ptr [r8], rsi
0000b925  0f85b6000000             jne 0xb9e1
0000b92b  90                       nop
0000b92c  498bc8                   mov rcx, r8
0000b92f  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000b934  492bca                   sub rcx, r10
0000b937  90                       nop
0000b938  48c1f904                 sar rcx, 4
0000b93c  498b4020                 mov rax, qword ptr [r8 + 0x20]
0000b940  90                       nop
0000b941  48c1e820                 shr rax, 0x20
0000b945  480fafcd                 imul rcx, rbp
0000b949  4863d1                   movsxd rdx, ecx
0000b94c  48c1e220                 shl rdx, 0x20
0000b950  480bd0                   or rdx, rax
0000b953  488bc2                   mov rax, rdx
0000b956  48c1e820                 shr rax, 0x20
0000b95a  8bc8                     mov ecx, eax
0000b95c  25ff070000               and eax, 0x7ff
0000b961  8bd8                     mov ebx, eax
0000b963  488d0440                 lea rax, [rax + rax*2]
0000b967  4803c0                   add rax, rax
0000b96a  450fb644c229             movzx r8d, byte ptr [r10 + rax*8 + 0x29]
0000b970  90                       nop
0000b971  498b44c220               mov rax, qword ptr [r10 + rax*8 + 0x20]
0000b976  48c1e820                 shr rax, 0x20
0000b97a  3bc2                     cmp eax, edx
0000b97c  755c                     jne 0xb9da
0000b97e  4584c0                   test r8b, r8b
0000b981  7457                     je 0xb9da
0000b983  81e1ff070000             and ecx, 0x7ff
0000b989  90                       nop
0000b98a  488d1449                 lea rdx, [rcx + rcx*2]
0000b98e  48c1e204                 shl rdx, 4
0000b992  4903d2                   add rdx, r10
0000b995  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000b999  85c0                     test eax, eax
0000b99b  753d                     jne 0xb9da
0000b99d  488bc8                   mov rcx, rax
0000b9a0  4923ce                   and rcx, r14
0000b9a3  4903cf                   add rcx, r15
0000b9a6  f0480fb14a20             lock cmpxchg qword ptr [rdx + 0x20], rcx
0000b9ac  752c                     jne 0xb9da
0000b9ae  c6422800                 mov byte ptr [rdx + 0x28], 0
0000b9b2  c6422900                 mov byte ptr [rdx + 0x29], 0
0000b9b6  90                       nop
0000b9b7  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000b9bb  48c1e820                 shr rax, 0x20
0000b9bf  83f8ff                   cmp eax, -1
0000b9c2  7416                     je 0xb9da
0000b9c4  49638200a00100           movsxd rax, dword ptr [r10 + 0x1a000]
0000b9cb  41899c8200800100         mov dword ptr [r10 + rax*4 + 0x18000], ebx
0000b9d3  41ff8200a00100           inc dword ptr [r10 + 0x1a000]
0000b9da  48ff0d779f4600           dec qword ptr [rip + 0x469f77]
0000b9e1  4d3bd9                   cmp r11, r9
0000b9e4  4d8d4330                 lea r8, [r11 + 0x30]
0000b9e8  90                       nop
0000b9e9  4d0f43c3                 cmovae r8, r11
0000b9ed  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000b9f2  4d3bc1                   cmp r8, r9
0000b9f5  0f8315ffffff             jae 0xb910
0000b9fb  0f1f440000               nop dword ptr [rax + rax]
0000ba00  84c0                     test al, al
0000ba02  0f8508ffffff             jne 0xb910
0000ba08  4983c030                 add r8, 0x30
0000ba0c  90                       nop
0000ba0d  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000ba12  4d3bc1                   cmp r8, r9
0000ba15  72e9                     jb 0xba00
0000ba17  e9f4feffff               jmp 0xb910
0000ba1c  488b6c2430               mov rbp, qword ptr [rsp + 0x30]
0000ba21  4c8d97c85a5100           lea r10, [rdi + 0x515ac8]
0000ba28  4c8d8fc85a5600           lea r9, [rdi + 0x565ac8]
0000ba2f  90                       nop
0000ba30  0fb68fe85a5100           movzx ecx, byte ptr [rdi + 0x515ae8]
0000ba37  498bc2                   mov rax, r10
0000ba3a  4d3bd1                   cmp r10, r9
0000ba3d  7313                     jae 0xba52
0000ba3f  90                       nop

; chunk at RVA 0xba40 (304 bytes)
0000ba40  84c9                     test cl, cl
0000ba42  750e                     jne 0xba52
0000ba44  4883c028                 add rax, 0x28
0000ba48  90                       nop
0000ba49  0fb64820                 movzx ecx, byte ptr [rax + 0x20]
0000ba4d  493bc1                   cmp rax, r9
0000ba50  72ee                     jb 0xba40
0000ba52  48bfcdcccccccccccccc     movabs rdi, 0xcccccccccccccccd
0000ba5c  0f1f4000                 nop dword ptr [rax]
0000ba60  90                       nop
0000ba61  410fb64920               movzx ecx, byte ptr [r9 + 0x20]
0000ba66  4c8bd8                   mov r11, rax
0000ba69  493bc1                   cmp rax, r9
0000ba6c  0f84ee000000             je 0xbb60
0000ba72  48397008                 cmp qword ptr [rax + 8], rsi
0000ba76  0f85b0000000             jne 0xbb2c
0000ba7c  488bd0                   mov rdx, rax
0000ba7f  90                       nop
0000ba80  0fb64820                 movzx ecx, byte ptr [rax + 0x20]
0000ba84  492bd2                   sub rdx, r10
0000ba87  90                       nop
0000ba88  48c1fa03                 sar rdx, 3
0000ba8c  488b4818                 mov rcx, qword ptr [rax + 0x18]
0000ba90  90                       nop
0000ba91  480fafd7                 imul rdx, rdi
0000ba95  48c1e920                 shr rcx, 0x20
0000ba99  4c63c2                   movsxd r8, edx
0000ba9c  49c1e020                 shl r8, 0x20
0000baa0  4c0bc1                   or r8, rcx
0000baa3  498bc0                   mov rax, r8
0000baa6  48c1e820                 shr rax, 0x20
0000baaa  8bc8                     mov ecx, eax
0000baac  25ff1f0000               and eax, 0x1fff
0000bab1  8bd8                     mov ebx, eax
0000bab3  488d0480                 lea rax, [rax + rax*4]
0000bab7  410fb654c221             movzx edx, byte ptr [r10 + rax*8 + 0x21]
0000babd  90                       nop
0000babe  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000bac3  48c1e820                 shr rax, 0x20
0000bac7  413bc0                   cmp eax, r8d
0000baca  7559                     jne 0xbb25
0000bacc  84d2                     test dl, dl
0000bace  7455                     je 0xbb25
0000bad0  81e1ff1f0000             and ecx, 0x1fff
0000bad6  90                       nop
0000bad7  488d0489                 lea rax, [rcx + rcx*4]
0000badb  498d14c2                 lea rdx, [r10 + rax*8]
0000badf  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000bae4  85c0                     test eax, eax
0000bae6  753d                     jne 0xbb25
0000bae8  488bc8                   mov rcx, rax
0000baeb  4923ce                   and rcx, r14
0000baee  4903cf                   add rcx, r15
0000baf1  f0480fb14a18             lock cmpxchg qword ptr [rdx + 0x18], rcx
0000baf7  752c                     jne 0xbb25
0000baf9  c6422000                 mov byte ptr [rdx + 0x20], 0
0000bafd  c6422100                 mov byte ptr [rdx + 0x21], 0
0000bb01  90                       nop
0000bb02  488b4218                 mov rax, qword ptr [rdx + 0x18]
0000bb06  48c1e820                 shr rax, 0x20
0000bb0a  83f8ff                   cmp eax, -1
0000bb0d  7416                     je 0xbb25
0000bb0f  49638200800500           movsxd rax, dword ptr [r10 + 0x58000]
0000bb16  41899c8200000500         mov dword ptr [r10 + rax*4 + 0x50000], ebx
0000bb1e  41ff8200800500           inc dword ptr [r10 + 0x58000]
0000bb25  48ff0d249e4600           dec qword ptr [rip + 0x469e24]
0000bb2c  4d3bd9                   cmp r11, r9
0000bb2f  498d4328                 lea rax, [r11 + 0x28]
0000bb33  90                       nop
0000bb34  490f43c3                 cmovae rax, r11
0000bb38  0fb64820                 movzx ecx, byte ptr [rax + 0x20]
0000bb3c  493bc1                   cmp rax, r9
0000bb3f  0f831bffffff             jae 0xba60
0000bb45  84c9                     test cl, cl
0000bb47  0f8513ffffff             jne 0xba60
0000bb4d  4883c028                 add rax, 0x28
0000bb51  90                       nop
0000bb52  0fb64820                 movzx ecx, byte ptr [rax + 0x20]
0000bb56  493bc1                   cmp rax, r9
0000bb59  72ea                     jb 0xbb45
0000bb5b  e900ffffff               jmp 0xba60
0000bb60  488b5c2428               mov rbx, qword ptr [rsp + 0x28]
0000bb65  488b742438               mov rsi, qword ptr [rsp + 0x38]
0000bb6a  415f                     pop r15
0000bb6c  415e                     pop r14
0000bb6e  5f                       pop rdi
0000bb6f  c3                       ret
