; `CTrustedMachine::Init'::`1'::dtor$5
; aetm_enclave.dll, primary RVA 0x5fdc0, 28 bytes in 1 chunk(s)

; chunk at RVA 0x5fdc0 (28 bytes)
0005fdc0  4055                     push rbp
0005fdc2  4883ec20                 sub rsp, 0x20
0005fdc6  488bea                   mov rbp, rdx
0005fdc9  488b5540                 mov rdx, qword ptr [rbp + 0x40]
0005fdcd  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
0005fdd1  e80a9bfbff               call 0x198e0
0005fdd6  4883c420                 add rsp, 0x20
0005fdda  5d                       pop rbp
0005fddb  c3                       ret
