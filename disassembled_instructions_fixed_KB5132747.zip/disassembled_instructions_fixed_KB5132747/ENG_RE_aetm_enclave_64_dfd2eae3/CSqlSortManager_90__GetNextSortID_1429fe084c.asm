; CSqlSortManager_90::GetNextSortID
; aetm_enclave.dll, primary RVA 0x4bbf0, 3551 bytes in 1 chunk(s)

; chunk at RVA 0x4bbf0 (3551 bytes)
0004bbf0  44894c2420               mov dword ptr [rsp + 0x20], r9d
0004bbf5  48894c2408               mov qword ptr [rsp + 8], rcx
0004bbfa  53                       push rbx
0004bbfb  55                       push rbp
0004bbfc  56                       push rsi
0004bbfd  57                       push rdi
0004bbfe  4154                     push r12
0004bc00  4155                     push r13
0004bc02  4156                     push r14
0004bc04  4157                     push r15
0004bc06  4881ec98000000           sub rsp, 0x98
0004bc0d  498bd8                   mov rbx, r8
0004bc10  4c8be2                   mov r12, rdx
0004bc13  33d2                     xor edx, edx
0004bc15  41b812040000             mov r8d, 0x412
0004bc1b  8bca                     mov ecx, edx
0004bc1d  8954245c                 mov dword ptr [rsp + 0x5c], edx
0004bc21  8bf2                     mov esi, edx
0004bc23  89542450                 mov dword ptr [rsp + 0x50], edx
0004bc27  410fb70424               movzx eax, word ptr [r12]
0004bc2c  8bfa                     mov edi, edx
0004bc2e  448b5b10                 mov r11d, dword ptr [rbx + 0x10]
0004bc32  66413bc0                 cmp ax, r8w
0004bc36  66898424f0000000         mov word ptr [rsp + 0xf0], ax
0004bc3e  448bca                   mov r9d, edx
0004bc41  8b8388000000             mov eax, dword ptr [rbx + 0x88]
0004bc47  0f94c1                   sete cl
0004bc4a  41c1eb1a                 shr r11d, 0x1a
0004bc4e  4180e301                 and r11b, 1
0004bc52  89542458                 mov dword ptr [rsp + 0x58], edx
0004bc56  89542454                 mov dword ptr [rsp + 0x54], edx
0004bc5a  898c2484000000           mov dword ptr [rsp + 0x84], ecx
0004bc61  44895c2460               mov dword ptr [rsp + 0x60], r11d
0004bc66  398384000000             cmp dword ptr [rbx + 0x84], eax
0004bc6c  0f8c670c0000             jl 0x4c8d9
0004bc72  488b842418010000         mov rax, qword ptr [rsp + 0x118]
0004bc7a  4885c0                   test rax, rax
0004bc7d  7402                     je 0x4bc81
0004bc7f  8810                     mov byte ptr [rax], dl
0004bc81  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004bc88  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004bc90  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
0004bc93  4c8d733c                 lea r14, [rbx + 0x3c]
0004bc97  41bf01000000             mov r15d, 1
0004bc9d  83f904                   cmp ecx, 4
0004bca0  0f8d86000000             jge 0x4bd2c
0004bca6  488b4330                 mov rax, qword ptr [rbx + 0x30]
0004bcaa  660f1f440000             nop word ptr [rax + rax]
0004bcb0  4885c0                   test rax, rax
0004bcb3  7458                     je 0x4bd0d
0004bcb5  488b4318                 mov rax, qword ptr [rbx + 0x18]
0004bcb9  4885c0                   test rax, rax
0004bcbc  740b                     je 0x4bcc9
0004bcbe  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
0004bcc2  ffd0                     call rax
0004bcc4  0fb7c8                   movzx ecx, ax
0004bcc7  eb12                     jmp 0x4bcdb
0004bcc9  48635338                 movsxd rdx, dword ptr [rbx + 0x38]
0004bccd  488b4328                 mov rax, qword ptr [rbx + 0x28]
0004bcd1  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
0004bcd5  8d4201                   lea eax, [rdx + 1]
0004bcd8  894338                   mov dword ptr [rbx + 0x38], eax
0004bcdb  4863435c                 movsxd rax, dword ptr [rbx + 0x5c]
0004bcdf  66894c433c               mov word ptr [rbx + rax*2 + 0x3c], cx
0004bce4  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
0004bce7  48ff4b30                 dec qword ptr [rbx + 0x30]
0004bceb  ffc1                     inc ecx
0004bced  488b4330                 mov rax, qword ptr [rbx + 0x30]
0004bcf1  894b5c                   mov dword ptr [rbx + 0x5c], ecx
0004bcf4  83f904                   cmp ecx, 4
0004bcf7  7cb7                     jl 0x4bcb0
0004bcf9  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004bcfe  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004bd03  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004bd0b  eb27                     jmp 0x4bd34
0004bd0d  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004bd12  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004bd17  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004bd1f  4863c1                   movsxd rax, ecx
0004bd22  33c9                     xor ecx, ecx
0004bd24  66894c433c               mov word ptr [rbx + rax*2 + 0x3c], cx
0004bd29  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
0004bd2c  85c9                     test ecx, ecx
0004bd2e  0f84840b0000             je 0x4c8b8
0004bd34  837b0400                 cmp dword ptr [rbx + 4], 0
0004bd38  7413                     je 0x4bd4d
0004bd3a  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
0004bd3e  6639433c                 cmp word ptr [rbx + 0x3c], ax
0004bd42  7509                     jne 0x4bd4d
0004bd44  413bcf                   cmp ecx, r15d
0004bd47  0f845d0b0000             je 0x4c8aa
0004bd4d  4c638388000000           movsxd r8, dword ptr [rbx + 0x88]
0004bd54  443b8380000000           cmp r8d, dword ptr [rbx + 0x80]
0004bd5b  0f8d500b0000             jge 0x4c8b1
0004bd61  498b442408               mov rax, qword ptr [r12 + 8]
0004bd66  0fb74b3c                 movzx ecx, word ptr [rbx + 0x3c]
0004bd6a  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004bd6d  235314                   and edx, dword ptr [rbx + 0x14]
0004bd70  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004bd74  42891480                 mov dword ptr [rax + r8*4], edx
0004bd78  33d2                     xor edx, edx
0004bd7a  85ed                     test ebp, ebp
0004bd7c  740e                     je 0x4bd8c
0004bd7e  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004bd85  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004bd89  891488                   mov dword ptr [rax + rcx*4], edx
0004bd8c  4032ed                   xor bpl, bpl
0004bd8f  4585c9                   test r9d, r9d
0004bd92  0f8532020000             jne 0x4bfca
0004bd98  44394b04                 cmp dword ptr [rbx + 4], r9d
0004bd9c  0f8480000000             je 0x4be22
0004bda2  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
0004bda6  6639433c                 cmp word ptr [rbx + 0x3c], ax
0004bdaa  7576                     jne 0x4be22
0004bdac  44397b5c                 cmp dword ptr [rbx + 0x5c], r15d
0004bdb0  7e70                     jle 0x4be22
0004bdb2  488d533e                 lea rdx, [rbx + 0x3e]
0004bdb6  458d411e                 lea r8d, [r9 + 0x1e]
0004bdba  488d4b3c                 lea rcx, [rbx + 0x3c]
0004bdbe  e85c240100               call 0x5e21f
0004bdc3  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004bdc6  0fb74b3c                 movzx ecx, word ptr [rbx + 0x3c]
0004bdca  498b442408               mov rax, qword ptr [r12 + 8]
0004bdcf  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004bdd2  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004bdd9  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004bddd  235314                   and edx, dword ptr [rbx + 0x14]
0004bde0  891488                   mov dword ptr [rax + rcx*4], edx
0004bde3  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004bde8  33c9                     xor ecx, ecx
0004bdea  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004bdf1  8bf1                     mov esi, ecx
0004bdf3  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
0004bdf7  450fb71490               movzx r10d, word ptr [r8 + rdx*4]
0004bdfc  4d8d0c90                 lea r9, [r8 + rdx*4]
0004be00  418bc2                   mov eax, r10d
0004be03  c1e808                   shr eax, 8
0004be06  83f80b                   cmp eax, 0xb
0004be09  0f872e090000             ja 0x4c73d
0004be0f  488d3dea41fbff           lea rdi, [rip - 0x4be16]
0004be16  8b8c8734c90400           mov ecx, dword ptr [rdi + rax*4 + 0x4c934]
0004be1d  4803cf                   add rcx, rdi
0004be20  ffe1                     jmp rcx
0004be22  4585d2                   test r10d, r10d
0004be25  7408                     je 0x4be2f
0004be27  85ff                     test edi, edi
0004be29  0f859b010000             jne 0x4bfca
0004be2f  41837c241400             cmp dword ptr [r12 + 0x14], 0
0004be35  0f848f010000             je 0x4bfca
0004be3b  448b535c                 mov r10d, dword ptr [rbx + 0x5c]
0004be3f  453bd7                   cmp r10d, r15d
0004be42  0f8e82010000             jle 0x4bfca
0004be48  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004be4f  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004be53  f6448803c0               test byte ptr [rax + rcx*4 + 3], 0xc0
0004be58  4c8d0c88                 lea r9, [rax + rcx*4]
0004be5c  0f8468010000             je 0x4bfca
0004be62  41837c241800             cmp dword ptr [r12 + 0x18], 0
0004be68  743d                     je 0x4bea7
0004be6a  8954245c                 mov dword ptr [rsp + 0x5c], edx
0004be6e  8bf2                     mov esi, edx
0004be70  4183fa02                 cmp r10d, 2
0004be74  7e31                     jle 0x4bea7
0004be76  0fb7433e                 movzx eax, word ptr [rbx + 0x3e]
0004be7a  663b430c                 cmp ax, word ptr [rbx + 0xc]
0004be7e  7427                     je 0x4bea7
0004be80  8bc8                     mov ecx, eax
0004be82  498b442408               mov rax, qword ptr [r12 + 8]
0004be87  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004be8a  235314                   and edx, dword ptr [rbx + 0x14]
0004be8d  413311                   xor edx, dword ptr [r9]
0004be90  f7c2ffffffe7             test edx, 0xe7ffffff
0004be96  750f                     jne 0x4bea7
0004be98  418bf7                   mov esi, r15d
0004be9b  44897c245c               mov dword ptr [rsp + 0x5c], r15d
0004bea0  4c8d733e                 lea r14, [rbx + 0x3e]
0004bea4  41ffca                   dec r10d
0004bea7  450fb74e02               movzx r9d, word ptr [r14 + 2]
0004beac  66443b4b0c               cmp r9w, word ptr [rbx + 0xc]
0004beb1  0f8404010000             je 0x4bfbb
0004beb7  498b542420               mov rdx, qword ptr [r12 + 0x20]
0004bebc  0fb74204                 movzx eax, word ptr [rdx + 4]
0004bec0  85c0                     test eax, eax
0004bec2  0f84f3000000             je 0x4bfbb
0004bec8  410fb70e                 movzx ecx, word ptr [r14]
0004becc  0f1f4000                 nop dword ptr [rax]
0004bed0  66394a06                 cmp word ptr [rdx + 6], cx
0004bed4  761b                     jbe 0x4bef1
0004bed6  4883c210                 add rdx, 0x10
0004beda  412bc7                   sub eax, r15d
0004bedd  75f1                     jne 0x4bed0
0004bedf  498d46fe                 lea rax, [r14 - 2]
0004bee3  85f6                     test esi, esi
0004bee5  490f44c6                 cmove rax, r14
0004bee9  4c8bf0                   mov r14, rax
0004beec  e90e010000               jmp 0x4bfff
0004bef1  0f85c4000000             jne 0x4bfbb
0004bef7  66443b4a0c               cmp r9w, word ptr [rdx + 0xc]
0004befc  0f82b9000000             jb 0x4bfbb
0004bf02  66443b4a0e               cmp r9w, word ptr [rdx + 0xe]
0004bf07  0f87ae000000             ja 0x4bfbb
0004bf0d  0fb74a08                 movzx ecx, word ptr [rdx + 8]
0004bf11  498b442428               mov rax, qword ptr [r12 + 0x28]
0004bf16  440fb7420a               movzx r8d, word ptr [rdx + 0xa]
0004bf1b  488d3cc8                 lea rdi, [rax + rcx*8]
0004bf1f  4585c0                   test r8d, r8d
0004bf22  0f848f000000             je 0x4bfb7
0004bf28  6644390f                 cmp word ptr [rdi], r9w
0004bf2c  7616                     jbe 0x4bf44
0004bf2e  4883c708                 add rdi, 8
0004bf32  452bc7                   sub r8d, r15d
0004bf35  75f1                     jne 0x4bf28
0004bf37  eb7e                     jmp 0x4bfb7
0004bf39  0f1f8000000000           nop dword ptr [rax]
0004bf40  6644390f                 cmp word ptr [rdi], r9w
0004bf44  7571                     jne 0x4bfb7
0004bf46  0fb74f02                 movzx ecx, word ptr [rdi + 2]
0004bf4a  6685c9                   test cx, cx
0004bf4d  743c                     je 0x4bf8b
0004bf4f  4183fa02                 cmp r10d, 2
0004bf53  7e10                     jle 0x4bf65
0004bf55  410fb74604               movzx eax, word ptr [r14 + 4]
0004bf5a  663bc8                   cmp cx, ax
0004bf5d  7506                     jne 0x4bf65
0004bf5f  6639430c                 cmp word ptr [rbx + 0xc], ax
0004bf63  750b                     jne 0x4bf70
0004bf65  4883c708                 add rdi, 8
0004bf69  452bc7                   sub r8d, r15d
0004bf6c  75d2                     jne 0x4bf40
0004bf6e  eb47                     jmp 0x4bfb7
0004bf70  85f6                     test esi, esi
0004bf72  752f                     jne 0x4bfa3
0004bf74  488d5340                 lea rdx, [rbx + 0x40]
0004bf78  448d461c                 lea r8d, [rsi + 0x1c]
0004bf7c  488d4b3c                 lea rcx, [rbx + 0x3c]
0004bf80  e89a220100               call 0x5e21f
0004bf85  83435cfe                 add dword ptr [rbx + 0x5c], -2
0004bf89  eb18                     jmp 0x4bfa3
0004bf8b  85f6                     test esi, esi
0004bf8d  7514                     jne 0x4bfa3
0004bf8f  488d533e                 lea rdx, [rbx + 0x3e]
0004bf93  448d461e                 lea r8d, [rsi + 0x1e]
0004bf97  488d4b3c                 lea rcx, [rbx + 0x3c]
0004bf9b  e87f220100               call 0x5e21f
0004bfa0  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004bfa3  8b5704                   mov edx, dword ptr [rdi + 4]
0004bfa6  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004bfad  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004bfb1  235314                   and edx, dword ptr [rbx + 0x14]
0004bfb4  891488                   mov dword ptr [rax + rcx*4], edx
0004bfb7  8b7c2450                 mov edi, dword ptr [rsp + 0x50]
0004bfbb  498d46fe                 lea rax, [r14 - 2]
0004bfbf  85f6                     test esi, esi
0004bfc1  490f44c6                 cmove rax, r14
0004bfc5  4c8bf0                   mov r14, rax
0004bfc8  eb35                     jmp 0x4bfff
0004bfca  4584db                   test r11b, r11b
0004bfcd  7430                     je 0x4bfff
0004bfcf  b800280000               mov eax, 0x2800
0004bfd4  b9ff030000               mov ecx, 0x3ff
0004bfd9  6603433c                 add ax, word ptr [rbx + 0x3c]
0004bfdd  663bc1                   cmp ax, cx
0004bfe0  771d                     ja 0x4bfff
0004bfe2  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004bfe9  4c8bc3                   mov r8, rbx
0004bfec  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004bff0  498bd4                   mov rdx, r12
0004bff3  4c8d0c88                 lea r9, [rax + rcx*4]
0004bff7  e8842a0000               call 0x4ea80
0004bffc  0fb6e8                   movzx ebp, al
0004bfff  837b0400                 cmp dword ptr [rbx + 4], 0
0004c003  0f84dafdffff             je 0x4bde3
0004c009  837c245400               cmp dword ptr [rsp + 0x54], 0
0004c00e  0f85cffdffff             jne 0x4bde3
0004c014  410fb706                 movzx eax, word ptr [r14]
0004c018  ff442458                 inc dword ptr [rsp + 0x58]
0004c01c  83c0df                   add eax, -0x21
0004c01f  83f83e                   cmp eax, 0x3e
0004c022  0f87bbfdffff             ja 0x4bde3
0004c028  488d15d13ffbff           lea rdx, [rip - 0x4c02f]
0004c02f  4898                     cdqe
0004c031  0fb6840290c90400         movzx eax, byte ptr [rdx + rax + 0x4c990]
0004c039  8b8c8264c90400           mov ecx, dword ptr [rdx + rax*4 + 0x4c964]
0004c040  4803ca                   add rcx, rdx
0004c043  ffe1                     jmp rcx
0004c045  85ff                     test edi, edi
0004c047  0f8596fdffff             jne 0x4bde3
0004c04d  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c054  bafcff0000               mov edx, 0xfffc
0004c059  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c05d  458bdf                   mov r11d, r15d
0004c060  44897c2450               mov dword ptr [rsp + 0x50], r15d
0004c065  4533ff                   xor r15d, r15d
0004c068  44897c2458               mov dword ptr [rsp + 0x58], r15d
0004c06d  66891488                 mov word ptr [rax + rcx*4], dx
0004c071  33c9                     xor ecx, ecx
0004c073  898c24f8000000           mov dword ptr [rsp + 0xf8], ecx
0004c07a  e96bfdffff               jmp 0x4bdea
0004c07f  85ff                     test edi, edi
0004c081  0f845cfdffff             je 0x4bde3
0004c087  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c08e  bafbff0000               mov edx, 0xfffb
0004c093  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c097  66891488                 mov word ptr [rax + rcx*4], dx
0004c09b  33c9                     xor ecx, ecx
0004c09d  448bd9                   mov r11d, ecx
0004c0a0  894c2450                 mov dword ptr [rsp + 0x50], ecx
0004c0a4  e941fdffff               jmp 0x4bdea
0004c0a9  85ff                     test edi, edi
0004c0ab  0f8432fdffff             je 0x4bde3
0004c0b1  44397c2458               cmp dword ptr [rsp + 0x58], r15d
0004c0b6  0f8527fdffff             jne 0x4bde3
0004c0bc  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
0004c0c3  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c0c8  0f841afdffff             je 0x4bde8
0004c0ce  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c0d5  baf9ff0000               mov edx, 0xfff9
0004c0da  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c0de  66891488                 mov word ptr [rax + rcx*4], dx
0004c0e2  33c9                     xor ecx, ecx
0004c0e4  894c2458                 mov dword ptr [rsp + 0x58], ecx
0004c0e8  e9fdfcffff               jmp 0x4bdea
0004c0ed  85ff                     test edi, edi
0004c0ef  0f84eefcffff             je 0x4bde3
0004c0f5  44397c2458               cmp dword ptr [rsp + 0x58], r15d
0004c0fa  0f85e3fcffff             jne 0x4bde3
0004c100  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
0004c107  ebba                     jmp 0x4c0c3
0004c109  85ff                     test edi, edi
0004c10b  0f84d2fcffff             je 0x4bde3
0004c111  44397c2458               cmp dword ptr [rsp + 0x58], r15d
0004c116  0f84c7fcffff             je 0x4bde3
0004c11c  44397b5c                 cmp dword ptr [rbx + 0x5c], r15d
0004c120  0f8ebdfcffff             jle 0x4bde3
0004c126  6641837e025d             cmp word ptr [r14 + 2], 0x5d
0004c12c  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c131  0f84b1fcffff             je 0x4bde8
0004c137  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c13e  bafaff0000               mov edx, 0xfffa
0004c143  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c147  66891488                 mov word ptr [rax + rcx*4], dx
0004c14b  33c9                     xor ecx, ecx
0004c14d  448bf9                   mov r15d, ecx
0004c150  e995fcffff               jmp 0x4bdea
0004c155  85ff                     test edi, edi
0004c157  0f8586fcffff             jne 0x4bde3
0004c15d  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
0004c164  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c169  0f8479fcffff             je 0x4bde8
0004c16f  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c176  baf7ff0000               mov edx, 0xfff7
0004c17b  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c17f  66891488                 mov word ptr [rax + rcx*4], dx
0004c183  e960fcffff               jmp 0x4bde8
0004c188  85ff                     test edi, edi
0004c18a  0f8553fcffff             jne 0x4bde3
0004c190  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
0004c197  ebcb                     jmp 0x4c164
0004c199  85ff                     test edi, edi
0004c19b  0f8542fcffff             jne 0x4bde3
0004c1a1  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
0004c1a8  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c1ad  0f8435fcffff             je 0x4bde8
0004c1b3  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c1ba  bafdff0000               mov edx, 0xfffd
0004c1bf  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c1c3  66891488                 mov word ptr [rax + rcx*4], dx
0004c1c7  e91cfcffff               jmp 0x4bde8
0004c1cc  85ff                     test edi, edi
0004c1ce  0f850ffcffff             jne 0x4bde3
0004c1d4  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
0004c1db  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c1e0  0f8402fcffff             je 0x4bde8
0004c1e6  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c1ed  bafeff0000               mov edx, 0xfffe
0004c1f2  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c1f6  66891488                 mov word ptr [rax + rcx*4], dx
0004c1fa  e9e9fbffff               jmp 0x4bde8
0004c1ff  85ff                     test edi, edi
0004c201  0f85dcfbffff             jne 0x4bde3
0004c207  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
0004c20e  ebcb                     jmp 0x4c1db
0004c210  8b4310                   mov eax, dword ptr [rbx + 0x10]
0004c213  a802                     test al, 2
0004c215  751e                     jne 0x4c235
0004c217  0fbae01e                 bt eax, 0x1e
0004c21b  0f8366010000             jae 0x4c387
0004c221  8b435c                   mov eax, dword ptr [rbx + 0x5c]
0004c224  394338                   cmp dword ptr [rbx + 0x38], eax
0004c227  0f855a010000             jne 0x4c387
0004c22d  85d2                     test edx, edx
0004c22f  0f8552010000             jne 0x4c387
0004c235  488d533e                 lea rdx, [rbx + 0x3e]
0004c239  41b81e000000             mov r8d, 0x1e
0004c23f  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c243  e8d71f0100               call 0x5e21f
0004c248  488b8c2420010000         mov rcx, qword ptr [rsp + 0x120]
0004c250  be01000000               mov esi, 1
0004c255  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004c258  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c260  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c267  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c26f  4885c9                   test rcx, rcx
0004c272  0f8426010000             je 0x4c39e
0004c278  48ff01                   inc qword ptr [rcx]
0004c27b  e91e010000               jmp 0x4c39e
0004c280  498b442408               mov rax, qword ptr [r12 + 8]
0004c285  410fb70e                 movzx ecx, word ptr [r14]
0004c289  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c28c  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c294  8908                     mov dword ptr [rax], ecx
0004c296  f6431004                 test byte ptr [rbx + 0x10], 4
0004c29a  0f84ef000000             je 0x4c38f
0004c2a0  eb93                     jmp 0x4c235
0004c2a2  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c2aa  33d2                     xor edx, edx
0004c2ac  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c2b4  8910                     mov dword ptr [rax], edx
0004c2b6  4585d2                   test r10d, r10d
0004c2b9  7412                     je 0x4c2cd
0004c2bb  395308                   cmp dword ptr [rbx + 8], edx
0004c2be  0f84cd040000             je 0x4c791
0004c2c4  4585db                   test r11d, r11d
0004c2c7  0f85c4040000             jne 0x4c791
0004c2cd  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c2d1  498bd6                   mov rdx, r14
0004c2d4  48638388000000           movsxd rax, dword ptr [rbx + 0x88]
0004c2db  4c63435c                 movsxd r8, dword ptr [rbx + 0x5c]
0004c2df  4d03c0                   add r8, r8
0004c2e2  0fb63c81                 movzx edi, byte ptr [rcx + rax*4]
0004c2e6  498d4e02                 lea rcx, [r14 + 2]
0004c2ea  e8301f0100               call 0x5e21f
0004c2ef  8344245403               add dword ptr [rsp + 0x54], 3
0004c2f4  488d0cbd00000000         lea rcx, [rdi*4]
0004c2fc  488d15fd3cfbff           lea rdx, [rip - 0x4c303]
0004c303  0fb78411c0992d00         movzx eax, word ptr [rcx + rdx + 0x2d99c0]
0004c30b  66418906                 mov word ptr [r14], ax
0004c30f  0fb78411c2992d00         movzx eax, word ptr [rcx + rdx + 0x2d99c2]
0004c317  6641894602               mov word ptr [r14 + 2], ax
0004c31c  8b535c                   mov edx, dword ptr [rbx + 0x5c]
0004c31f  c7436001000000           mov dword ptr [rbx + 0x60], 1
0004c326  ffc2                     inc edx
0004c328  89535c                   mov dword ptr [rbx + 0x5c], edx
0004c32b  410fb74e02               movzx ecx, word ptr [r14 + 2]
0004c330  498b442408               mov rax, qword ptr [r12 + 8]
0004c335  807c880102               cmp byte ptr [rax + rcx*4 + 1], 2
0004c33a  488d2c88                 lea rbp, [rax + rcx*4]
0004c33e  7542                     jne 0x4c382
0004c340  4c63c2                   movsxd r8, edx
0004c343  498d4e04                 lea rcx, [r14 + 4]
0004c347  4d03c0                   add r8, r8
0004c34a  498d5602                 lea rdx, [r14 + 2]
0004c34e  e8cc1e0100               call 0x5e21f
0004c353  0fb64d00                 movzx ecx, byte ptr [rbp]
0004c357  488d15a23cfbff           lea rdx, [rip - 0x4c35e]
0004c35e  0fb7848ac0992d00         movzx eax, word ptr [rdx + rcx*4 + 0x2d99c0]
0004c366  6641894602               mov word ptr [r14 + 2], ax
0004c36b  0fb7848ac2992d00         movzx eax, word ptr [rdx + rcx*4 + 0x2d99c2]
0004c373  6641894604               mov word ptr [r14 + 4], ax
0004c378  ff435c                   inc dword ptr [rbx + 0x5c]
0004c37b  ff4360                   inc dword ptr [rbx + 0x60]
0004c37e  ff442454                 inc dword ptr [rsp + 0x54]
0004c382  be01000000               mov esi, 1
0004c387  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c38f  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c396  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c39e  33d2                     xor edx, edx
0004c3a0  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004c3a5  4585c9                   test r9d, r9d
0004c3a8  7e0a                     jle 0x4c3b4
0004c3aa  41ffc9                   dec r9d
0004c3ad  8910                     mov dword ptr [rax], edx
0004c3af  44894c2454               mov dword ptr [rsp + 0x54], r9d
0004c3b4  8b7c2450                 mov edi, dword ptr [rsp + 0x50]
0004c3b8  85f6                     test esi, esi
0004c3ba  8b74245c                 mov esi, dword ptr [rsp + 0x5c]
0004c3be  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004c3c3  0f85c7f8ffff             jne 0x4bc90
0004c3c9  488d533e                 lea rdx, [rbx + 0x3e]
0004c3cd  41b81e000000             mov r8d, 0x1e
0004c3d3  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c3d7  4585c9                   test r9d, r9d
0004c3da  0f84bd030000             je 0x4c79d
0004c3e0  e83a1e0100               call 0x5e21f
0004c3e5  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004c3e8  ff8388000000             inc dword ptr [rbx + 0x88]
0004c3ee  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004c3f3  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004c3f8  e98bf8ffff               jmp 0x4bc88
0004c3fd  488b842418010000         mov rax, qword ptr [rsp + 0x118]
0004c405  4885c0                   test rax, rax
0004c408  7413                     je 0x4c41d
0004c40a  4180fa01                 cmp r10b, 1
0004c40e  770d                     ja 0x4c41d
0004c410  c60001                   mov byte ptr [rax], 1
0004c413  8b9388000000             mov edx, dword ptr [rbx + 0x88]
0004c419  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
0004c41d  4863c2                   movsxd rax, edx
0004c420  41803c8001               cmp byte ptr [r8 + rax*4], 1
0004c425  7620                     jbe 0x4c447
0004c427  498b442408               mov rax, qword ptr [r12 + 8]
0004c42c  410fb70e                 movzx ecx, word ptr [r14]
0004c430  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c433  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c43b  8908                     mov dword ptr [rax], ecx
0004c43d  8b9388000000             mov edx, dword ptr [rbx + 0x88]
0004c443  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
0004c447  4863c2                   movsxd rax, edx
0004c44a  4c8d8c24f8000000         lea r9, [rsp + 0xf8]
0004c452  4c89642438               mov qword ptr [rsp + 0x38], r12
0004c457  488d54247c               lea rdx, [rsp + 0x7c]
0004c45c  498d0c80                 lea rcx, [r8 + rax*4]
0004c460  8b842484000000           mov eax, dword ptr [rsp + 0x84]
0004c467  448b4314                 mov r8d, dword ptr [rbx + 0x14]
0004c46b  89442430                 mov dword ptr [rsp + 0x30], eax
0004c46f  410fb7442440             movzx eax, word ptr [r12 + 0x40]
0004c475  6689442428               mov word ptr [rsp + 0x28], ax
0004c47a  488d842488000000         lea rax, [rsp + 0x88]
0004c482  4889442420               mov qword ptr [rsp + 0x20], rax
0004c487  e83476ffff               call 0x43ac0
0004c48c  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c493  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c49b  85ed                     test ebp, ebp
0004c49d  7415                     je 0x4c4b4
0004c49f  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004c4a6  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
0004c4aa  8b842488000000           mov eax, dword ptr [rsp + 0x88]
0004c4b1  890491                   mov dword ptr [rcx + rdx*4], eax
0004c4b4  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c4bc  e9ddfeffff               jmp 0x4c39e
0004c4c1  498b442408               mov rax, qword ptr [r12 + 8]
0004c4c6  410fb70e                 movzx ecx, word ptr [r14]
0004c4ca  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004c4cd  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c4d5  418911                   mov dword ptr [r9], edx
0004c4d8  8910                     mov dword ptr [rax], edx
0004c4da  e9b0feffff               jmp 0x4c38f
0004c4df  b860110000               mov eax, 0x1160
0004c4e4  66413906                 cmp word ptr [r14], ax
0004c4e8  0f83bb010000             jae 0x4c6a9
0004c4ee  448b4b5c                 mov r9d, dword ptr [rbx + 0x5c]
0004c4f2  488d842480000000         lea rax, [rsp + 0x80]
0004c4fa  488b8c24e0000000         mov rcx, qword ptr [rsp + 0xe0]
0004c502  4d8bc6                   mov r8, r14
0004c505  4889442438               mov qword ptr [rsp + 0x38], rax
0004c50a  498bd4                   mov rdx, r12
0004c50d  488d442464               lea rax, [rsp + 0x64]
0004c512  c744243003000000         mov dword ptr [rsp + 0x30], 3
0004c51a  4889442428               mov qword ptr [rsp + 0x28], rax
0004c51f  488d8424e8000000         lea rax, [rsp + 0xe8]
0004c527  4889442420               mov qword ptr [rsp + 0x20], rax
0004c52c  e85f470000               call 0x50c90
0004c531  8bf8                     mov edi, eax
0004c533  85c0                     test eax, eax
0004c535  0f8e6e010000             jle 0x4c6a9
0004c53b  0faee8                   lfence
0004c53e  0fb78424e8000000         movzx eax, word ptr [rsp + 0xe8]
0004c546  4533c0                   xor r8d, r8d
0004c549  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004c550  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c554  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c55b  668944246c               mov word ptr [rsp + 0x6c], ax
0004c560  66c744246e0202           mov word ptr [rsp + 0x6e], 0x202
0004c567  8b44246c                 mov eax, dword ptr [rsp + 0x6c]
0004c56b  890491                   mov dword ptr [rcx + rdx*4], eax
0004c56e  85ed                     test ebp, ebp
0004c570  740f                     je 0x4c581
0004c572  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c579  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c57d  44890488                 mov dword ptr [rax + rcx*4], r8d
0004c581  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c588  41b900ff0000             mov r9d, 0xff00
0004c58e  488bd1                   mov rdx, rcx
0004c591  66c74424720202           mov word ptr [rsp + 0x72], 0x202
0004c598  8d4101                   lea eax, [rcx + 1]
0004c59b  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c59f  898388000000             mov dword ptr [rbx + 0x88], eax
0004c5a5  0fb6442464               movzx eax, byte ptr [rsp + 0x64]
0004c5aa  66410bc1                 or ax, r9w
0004c5ae  6689442470               mov word ptr [rsp + 0x70], ax
0004c5b3  8b442470                 mov eax, dword ptr [rsp + 0x70]
0004c5b7  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
0004c5bb  85ed                     test ebp, ebp
0004c5bd  740f                     je 0x4c5ce
0004c5bf  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c5c6  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c5ca  44890488                 mov dword ptr [rax + rcx*4], r8d
0004c5ce  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c5d5  488bd1                   mov rdx, rcx
0004c5d8  66c74424760202           mov word ptr [rsp + 0x76], 0x202
0004c5df  8d4101                   lea eax, [rcx + 1]
0004c5e2  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c5e6  898388000000             mov dword ptr [rbx + 0x88], eax
0004c5ec  0fb6442465               movzx eax, byte ptr [rsp + 0x65]
0004c5f1  66410bc1                 or ax, r9w
0004c5f5  6689442474               mov word ptr [rsp + 0x74], ax
0004c5fa  8b442474                 mov eax, dword ptr [rsp + 0x74]
0004c5fe  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
0004c602  85ed                     test ebp, ebp
0004c604  740f                     je 0x4c615
0004c606  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c60d  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c611  44890488                 mov dword ptr [rax + rcx*4], r8d
0004c615  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c61c  488bd1                   mov rdx, rcx
0004c61f  66c744247a0202           mov word ptr [rsp + 0x7a], 0x202
0004c626  8d4101                   lea eax, [rcx + 1]
0004c629  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c62d  898388000000             mov dword ptr [rbx + 0x88], eax
0004c633  0fb6442466               movzx eax, byte ptr [rsp + 0x66]
0004c638  66410bc1                 or ax, r9w
0004c63c  6689442478               mov word ptr [rsp + 0x78], ax
0004c641  8b442478                 mov eax, dword ptr [rsp + 0x78]
0004c645  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
0004c649  85ed                     test ebp, ebp
0004c64b  740f                     je 0x4c65c
0004c64d  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c654  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c658  44890488                 mov dword ptr [rax + rcx*4], r8d
0004c65c  ffcf                     dec edi
0004c65e  4863c7                   movsxd rax, edi
0004c661  488d1400                 lea rdx, [rax + rax]
0004c665  498b442408               mov rax, qword ptr [r12 + 8]
0004c66a  420fb70c32               movzx ecx, word ptr [rdx + r14]
0004c66f  4883c23c                 add rdx, 0x3c
0004c673  4803d3                   add rdx, rbx
0004c676  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c679  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c681  8908                     mov dword ptr [rax], ecx
0004c683  b810000000               mov eax, 0x10
0004c688  2bc7                     sub eax, edi
0004c68a  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c68e  4c63c0                   movsxd r8, eax
0004c691  4d03c0                   add r8, r8
0004c694  e8861b0100               call 0x5e21f
0004c699  297b5c                   sub dword ptr [rbx + 0x5c], edi
0004c69c  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c6a4  e9edfcffff               jmp 0x4c396
0004c6a9  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c6b1  4585d2                   test r10d, r10d
0004c6b4  7565                     jne 0x4c71b
0004c6b6  498b442408               mov rax, qword ptr [r12 + 8]
0004c6bb  410fb70e                 movzx ecx, word ptr [r14]
0004c6bf  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004c6c2  b812040000               mov eax, 0x412
0004c6c7  89542468                 mov dword ptr [rsp + 0x68], edx
0004c6cb  440fb6c2                 movzx r8d, dl
0004c6cf  c1ea10                   shr edx, 0x10
0004c6d2  66398424f0000000         cmp word ptr [rsp + 0xf0], ax
0004c6da  7518                     jne 0x4c6f4
0004c6dc  0fb6c2                   movzx eax, dl
0004c6df  420fb64c2048             movzx ecx, byte ptr [rax + r12 + 0x48]
0004c6e5  66c1e108                 shl cx, 8
0004c6e9  66410bc8                 or cx, r8w
0004c6ed  66894c2468               mov word ptr [rsp + 0x68], cx
0004c6f2  eb10                     jmp 0x4c704
0004c6f4  0fb6c2                   movzx eax, dl
0004c6f7  66c1e008                 shl ax, 8
0004c6fb  66410bc0                 or ax, r8w
0004c6ff  6689442468               mov word ptr [rsp + 0x68], ax
0004c704  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004c70b  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c70f  c644246a02               mov byte ptr [rsp + 0x6a], 2
0004c714  8b442468                 mov eax, dword ptr [rsp + 0x68]
0004c718  890491                   mov dword ptr [rcx + rdx*4], eax
0004c71b  498b442408               mov rax, qword ptr [r12 + 8]
0004c720  410fb70e                 movzx ecx, word ptr [r14]
0004c724  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c72b  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c72e  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c736  8908                     mov dword ptr [rax], ecx
0004c738  e961fcffff               jmp 0x4c39e
0004c73d  498b442408               mov rax, qword ptr [r12 + 8]
0004c742  410fb70e                 movzx ecx, word ptr [r14]
0004c746  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c749  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c751  8908                     mov dword ptr [rax], ecx
0004c753  4084ed                   test bpl, bpl
0004c756  0f8433fcffff             je 0x4c38f
0004c75c  48638388000000           movsxd rax, dword ptr [rbx + 0x88]
0004c763  4c8d048500000000         lea r8, [rax*4]
0004c76b  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c76f  418b1400                 mov edx, dword ptr [r8 + rax]
0004c773  8bc2                     mov eax, edx
0004c775  c1ea18                   shr edx, 0x18
0004c778  48c1e810                 shr rax, 0x10
0004c77c  0fb6c8                   movzx ecx, al
0004c77f  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c783  c1e108                   shl ecx, 8
0004c786  0bca                     or ecx, edx
0004c788  41890c00                 mov dword ptr [r8 + rax], ecx
0004c78c  e9f6fbffff               jmp 0x4c387
0004c791  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c798  e903fcffff               jmp 0x4c3a0
0004c79d  e87d1a0100               call 0x5e21f
0004c7a2  8b435c                   mov eax, dword ptr [rbx + 0x5c]
0004c7a5  ffc8                     dec eax
0004c7a7  89435c                   mov dword ptr [rbx + 0x5c], eax
0004c7aa  4585ff                   test r15d, r15d
0004c7ad  0f84de000000             je 0x4c891
0004c7b3  33ed                     xor ebp, ebp
0004c7b5  85c0                     test eax, eax
0004c7b7  7543                     jne 0x4c7fc
0004c7b9  48396b30                 cmp qword ptr [rbx + 0x30], rbp
0004c7bd  0f84c7000000             je 0x4c88a
0004c7c3  488b4318                 mov rax, qword ptr [rbx + 0x18]
0004c7c7  4885c0                   test rax, rax
0004c7ca  740e                     je 0x4c7da
0004c7cc  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
0004c7d0  ffd0                     call rax
0004c7d2  0fb7c8                   movzx ecx, ax
0004c7d5  8b435c                   mov eax, dword ptr [rbx + 0x5c]
0004c7d8  eb14                     jmp 0x4c7ee
0004c7da  48635338                 movsxd rdx, dword ptr [rbx + 0x38]
0004c7de  488b4328                 mov rax, qword ptr [rbx + 0x28]
0004c7e2  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
0004c7e6  8d4201                   lea eax, [rdx + 1]
0004c7e9  894338                   mov dword ptr [rbx + 0x38], eax
0004c7ec  8bc5                     mov eax, ebp
0004c7ee  4898                     cdqe
0004c7f0  6641890c46               mov word ptr [r14 + rax*2], cx
0004c7f5  ff435c                   inc dword ptr [rbx + 0x5c]
0004c7f8  48ff4b30                 dec qword ptr [rbx + 0x30]
0004c7fc  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c803  41baf7ff0000             mov r10d, 0xfff7
0004c809  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c80d  440fb70488               movzx r8d, word ptr [rax + rcx*4]
0004c812  4c8d0c88                 lea r9, [rax + rcx*4]
0004c816  66453bc2                 cmp r8w, r10w
0004c81a  7525                     jne 0x4c841
0004c81c  6641833e25               cmp word ptr [r14], 0x25
0004c821  751e                     jne 0x4c841
0004c823  41b81e000000             mov r8d, 0x1e
0004c829  488d533e                 lea rdx, [rbx + 0x3e]
0004c82d  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c831  e8e9190100               call 0x5e21f
0004c836  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004c839  8b435c                   mov eax, dword ptr [rbx + 0x5c]
0004c83c  e974ffffff               jmp 0x4c7b5
0004c841  410fb7c0                 movzx eax, r8w
0004c845  66c1e808                 shr ax, 8
0004c849  3c05                     cmp al, 5
0004c84b  743d                     je 0x4c88a
0004c84d  498b442408               mov rax, qword ptr [r12 + 8]
0004c852  410fb70e                 movzx ecx, word ptr [r14]
0004c856  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004c859  0fb7c2                   movzx eax, dx
0004c85c  66c1e808                 shr ax, 8
0004c860  3c01                     cmp al, 1
0004c862  7526                     jne 0x4c88a
0004c864  66453bc2                 cmp r8w, r10w
0004c868  73b9                     jae 0x4c823
0004c86a  410fb64102               movzx eax, byte ptr [r9 + 2]
0004c86f  c1ea10                   shr edx, 0x10
0004c872  0fb6ca                   movzx ecx, dl
0004c875  6603c8                   add cx, ax
0004c878  b8ff000000               mov eax, 0xff
0004c87d  663bc8                   cmp cx, ax
0004c880  7602                     jbe 0x4c884
0004c882  8bc8                     mov ecx, eax
0004c884  41884902                 mov byte ptr [r9 + 2], cl
0004c888  eb99                     jmp 0x4c823
0004c88a  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c891  ff8388000000             inc dword ptr [rbx + 0x88]
0004c897  85ff                     test edi, edi
0004c899  743e                     je 0x4c8d9
0004c89b  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004c8a0  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004c8a5  e9def3ffff               jmp 0x4bc88
0004c8aa  b803000000               mov eax, 3
0004c8af  eb2a                     jmp 0x4c8db
0004c8b1  b802000000               mov eax, 2
0004c8b6  eb23                     jmp 0x4c8db
0004c8b8  48638388000000           movsxd rax, dword ptr [rbx + 0x88]
0004c8bf  85ff                     test edi, edi
0004c8c1  742c                     je 0x4c8ef
0004c8c3  488bc8                   mov rcx, rax
0004c8c6  bafbff0000               mov edx, 0xfffb
0004c8cb  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c8cf  66891488                 mov word ptr [rax + rcx*4], dx
0004c8d3  ff8388000000             inc dword ptr [rbx + 0x88]
0004c8d9  33c0                     xor eax, eax
0004c8db  4881c498000000           add rsp, 0x98
0004c8e2  415f                     pop r15
0004c8e4  415e                     pop r14
0004c8e6  415d                     pop r13
0004c8e8  415c                     pop r12
0004c8ea  5f                       pop rdi
0004c8eb  5e                       pop rsi
0004c8ec  5d                       pop rbp
0004c8ed  5b                       pop rbx
0004c8ee  c3                       ret
0004c8ef  398384000000             cmp dword ptr [rbx + 0x84], eax
0004c8f5  75e2                     jne 0x4c8d9
0004c8f7  f7431000000008           test dword ptr [rbx + 0x10], 0x8000000
0004c8fe  742c                     je 0x4c92c
0004c900  498b4c2408               mov rcx, qword ptr [r12 + 8]
0004c905  448b8180000000           mov r8d, dword ptr [rcx + 0x80]
0004c90c  44234314                 and r8d, dword ptr [rbx + 0x14]
0004c910  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c914  44890481                 mov dword ptr [rcx + rax*4], r8d
0004c918  85ed                     test ebp, ebp
0004c91a  7410                     je 0x4c92c
0004c91c  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004c923  33c0                     xor eax, eax
0004c925  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
0004c929  890491                   mov dword ptr [rcx + rdx*4], eax
0004c92c  418bc7                   mov eax, r15d
0004c92f  ebaa                     jmp 0x4c8db
0004c931  0f1f00                   nop dword ptr [rax]
0004c934  35c2040010               xor eax, 0x100004c2
0004c939  c20400                   ret 4
0004c93c  a2c20400fdc30400df       movabs byte ptr [0xdf0004c3fd0004c2], al
