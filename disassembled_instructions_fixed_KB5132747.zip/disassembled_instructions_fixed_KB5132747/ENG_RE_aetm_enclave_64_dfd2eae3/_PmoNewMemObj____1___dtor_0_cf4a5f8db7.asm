; `PmoNewMemObj'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x606f0, 28 bytes in 1 chunk(s)

; chunk at RVA 0x606f0 (28 bytes)
000606f0  4055                     push rbp
000606f2  4883ec20                 sub rsp, 0x20
000606f6  488bea                   mov rbp, rdx
000606f9  488b5540                 mov rdx, qword ptr [rbp + 0x40]
000606fd  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
00060701  e8da91fbff               call 0x198e0
00060706  4883c420                 add rsp, 0x20
0006070a  5d                       pop rbp
0006070b  c3                       ret
