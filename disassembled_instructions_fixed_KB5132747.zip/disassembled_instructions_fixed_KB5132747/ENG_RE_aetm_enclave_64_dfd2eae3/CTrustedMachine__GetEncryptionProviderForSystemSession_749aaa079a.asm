; CTrustedMachine::GetEncryptionProviderForSystemSession
; aetm_enclave.dll, primary RVA 0xbfd0, 725 bytes in 1 chunk(s)

; chunk at RVA 0xbfd0 (725 bytes)
0000bfd0  488bc4                   mov rax, rsp
0000bfd3  57                       push rdi
0000bfd4  4154                     push r12
0000bfd6  4155                     push r13
0000bfd8  4156                     push r14
0000bfda  4157                     push r15
0000bfdc  4883ec50                 sub rsp, 0x50
0000bfe0  48c740b8feffffff         mov qword ptr [rax - 0x48], 0xfffffffffffffffe
0000bfe8  48895810                 mov qword ptr [rax + 0x10], rbx
0000bfec  48896818                 mov qword ptr [rax + 0x18], rbp
0000bff0  48897020                 mov qword ptr [rax + 0x20], rsi
0000bff4  498be8                   mov rbp, r8
0000bff7  4c63e2                   movsxd r12, edx
0000bffa  4c8bf1                   mov r14, rcx
0000bffd  4c8db9c0da4700           lea r15, [rcx + 0x47dac0]
0000c004  498bdf                   mov rbx, r15
0000c007  498db700000900           lea rsi, [r15 + 0x90000]
0000c00e  4533ed                   xor r13d, r13d
0000c011  4c3bfe                   cmp r15, rsi
0000c014  7345                     jae 0xc05b
0000c016  66660f1f840000000000     nop word ptr [rax + rax]
0000c020  4c89ac2480000000         mov qword ptr [rsp + 0x80], r13
0000c028  48899c2480000000         mov qword ptr [rsp + 0x80], rbx
0000c030  f048ff4338               lock inc qword ptr [rbx + 0x38]
0000c035  90                       nop
0000c036  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000c03a  84c0                     test al, al
0000c03c  7518                     jne 0xc056
0000c03e  4883c348                 add rbx, 0x48
0000c042  488b842480000000         mov rax, qword ptr [rsp + 0x80]
0000c04a  f048ff4838               lock dec qword ptr [rax + 0x38]
0000c04f  483bde                   cmp rbx, rsi
0000c052  72cc                     jb 0xc020
0000c054  eb05                     jmp 0xc05b
0000c056  f048ff4b38               lock dec qword ptr [rbx + 0x38]
0000c05b  48ba398ee3388ee3388e     movabs rdx, 0x8e38e38e38e38e39
0000c065  483bde                   cmp rbx, rsi
0000c068  0f841f020000             je 0xc28d
0000c06e  4c897c2438               mov qword ptr [rsp + 0x38], r15
0000c073  4c896c2420               mov qword ptr [rsp + 0x20], r13
0000c078  48895c2420               mov qword ptr [rsp + 0x20], rbx
0000c07d  f048ff4338               lock inc qword ptr [rbx + 0x38]
0000c082  90                       nop
0000c083  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000c087  488bcb                   mov rcx, rbx
0000c08a  492bcf                   sub rcx, r15
0000c08d  48c1f903                 sar rcx, 3
0000c091  480fafca                 imul rcx, rdx
0000c095  90                       nop
0000c096  488b4338                 mov rax, qword ptr [rbx + 0x38]
0000c09a  4863d1                   movsxd rdx, ecx
0000c09d  48c1e220                 shl rdx, 0x20
0000c0a1  48c1e820                 shr rax, 0x20
0000c0a5  480bd0                   or rdx, rax
0000c0a8  f048ff4b38               lock dec qword ptr [rbx + 0x38]
0000c0ad  4889542440               mov qword ptr [rsp + 0x40], rdx
0000c0b2  0faee8                   lfence
0000c0b5  48c1ea20                 shr rdx, 0x20
0000c0b9  81e2ff1f0000             and edx, 0x1fff
0000c0bf  488d0cd2                 lea rcx, [rdx + rdx*8]
0000c0c3  488b442438               mov rax, qword ptr [rsp + 0x38]
0000c0c8  f048ff44c838             lock inc qword ptr [rax + rcx*8 + 0x38]
0000c0ce  4c8b4c2440               mov r9, qword ptr [rsp + 0x40]
0000c0d3  498bd1                   mov rdx, r9
0000c0d6  48c1ea20                 shr rdx, 0x20
0000c0da  488bc2                   mov rax, rdx
0000c0dd  25ff1f0000               and eax, 0x1fff
0000c0e2  488d0cc0                 lea rcx, [rax + rax*8]
0000c0e6  488b442438               mov rax, qword ptr [rsp + 0x38]
0000c0eb  4c8d04c8                 lea r8, [rax + rcx*8]
0000c0ef  90                       nop
0000c0f0  410fb64840               movzx ecx, byte ptr [r8 + 0x40]
0000c0f5  90                       nop
0000c0f6  498b4038                 mov rax, qword ptr [r8 + 0x38]
0000c0fa  48c1e820                 shr rax, 0x20
0000c0fe  413bc1                   cmp eax, r9d
0000c101  7569                     jne 0xc16c
0000c103  84c9                     test cl, cl
0000c105  7465                     je 0xc16c
0000c107  90                       nop
0000c108  410fb64841               movzx ecx, byte ptr [r8 + 0x41]
0000c10d  90                       nop
0000c10e  498b4038                 mov rax, qword ptr [r8 + 0x38]
0000c112  48c1e820                 shr rax, 0x20
0000c116  413bc1                   cmp eax, r9d
0000c119  0f8556010000             jne 0xc275
0000c11f  84c9                     test cl, cl
0000c121  0f844e010000             je 0xc275
0000c127  81e2ff1f0000             and edx, 0x1fff
0000c12d  488d0cd2                 lea rcx, [rdx + rdx*8]
0000c131  488b442438               mov rax, qword ptr [rsp + 0x38]
0000c136  488d3cc8                 lea rdi, [rax + rcx*8]
0000c13a  488b4508                 mov rax, qword ptr [rbp + 8]
0000c13e  48394708                 cmp qword ptr [rdi + 8], rax
0000c142  7523                     jne 0xc167
0000c144  0fb74518                 movzx eax, word ptr [rbp + 0x18]
0000c148  663907                   cmp word ptr [rdi], ax
0000c14b  751a                     jne 0xc167
0000c14d  0fb75502                 movzx edx, word ptr [rbp + 2]
0000c151  395704                   cmp dword ptr [rdi + 4], edx
0000c154  0f8488000000             je 0xc1e2
0000c15a  498bce                   mov rcx, r14
0000c15d  e8be110000               call 0xd320
0000c162  394704                   cmp dword ptr [rdi + 4], eax
0000c165  747b                     je 0xc1e2
0000c167  0faee8                   lfence
0000c16a  eb16                     jmp 0xc182
0000c16c  0faee8                   lfence
0000c16f  81e2ff1f0000             and edx, 0x1fff
0000c175  488d0cd2                 lea rcx, [rdx + rdx*8]
0000c179  488b442438               mov rax, qword ptr [rsp + 0x38]
0000c17e  488d3cc8                 lea rdi, [rax + rcx*8]
0000c182  f048ff4f38               lock dec qword ptr [rdi + 0x38]
0000c187  483bde                   cmp rbx, rsi
0000c18a  48ba398ee3388ee3388e     movabs rdx, 0x8e38e38e38e38e39
0000c194  0f83cefeffff             jae 0xc068
0000c19a  4883c348                 add rbx, 0x48
0000c19e  483bde                   cmp rbx, rsi
0000c1a1  0f83c1feffff             jae 0xc068
0000c1a7  660f1f840000000000       nop word ptr [rax + rax]
0000c1b0  4c896c2428               mov qword ptr [rsp + 0x28], r13
0000c1b5  48895c2428               mov qword ptr [rsp + 0x28], rbx
0000c1ba  488d4b38                 lea rcx, [rbx + 0x38]
0000c1be  f048ff01                 lock inc qword ptr [rcx]
0000c1c2  90                       nop
0000c1c3  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000c1c7  84c0                     test al, al
0000c1c9  7512                     jne 0xc1dd
0000c1cb  4883c348                 add rbx, 0x48
0000c1cf  f048ff09                 lock dec qword ptr [rcx]
0000c1d3  483bde                   cmp rbx, rsi
0000c1d6  72d8                     jb 0xc1b0
0000c1d8  e97efeffff               jmp 0xc05b
0000c1dd  e974feffff               jmp 0xc056
0000c1e2  498d96b85a4100           lea rdx, [r14 + 0x415ab8]
0000c1e9  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
0000c1ed  488bc1                   mov rax, rcx
0000c1f0  48c1e820                 shr rax, 0x20
0000c1f4  25ff1f0000               and eax, 0x1fff
0000c1f9  488d0440                 lea rax, [rax + rax*2]
0000c1fd  4803c0                   add rax, rax
0000c200  90                       nop
0000c201  440fb644c229             movzx r8d, byte ptr [rdx + rax*8 + 0x29]
0000c207  90                       nop
0000c208  488b44c220               mov rax, qword ptr [rdx + rax*8 + 0x20]
0000c20d  48c1e820                 shr rax, 0x20
0000c211  3bc1                     cmp eax, ecx
0000c213  7560                     jne 0xc275
0000c215  4584c0                   test r8b, r8b
0000c218  745b                     je 0xc275
0000c21a  488b4730                 mov rax, qword ptr [rdi + 0x30]
0000c21e  48c1e820                 shr rax, 0x20
0000c222  25ff1f0000               and eax, 0x1fff
0000c227  488d0c40                 lea rcx, [rax + rax*2]
0000c22b  48c1e104                 shl rcx, 4
0000c22f  4803ca                   add rcx, rdx
0000c232  4a8b04e1                 mov rax, qword ptr [rcx + r12*8]
0000c236  488b4c2440               mov rcx, qword ptr [rsp + 0x40]
0000c23b  48c1e920                 shr rcx, 0x20
0000c23f  0faee8                   lfence
0000c242  81e1ff1f0000             and ecx, 0x1fff
0000c248  488d14c9                 lea rdx, [rcx + rcx*8]
0000c24c  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
0000c251  f048ff4cd138             lock dec qword ptr [rcx + rdx*8 + 0x38]
0000c257  4c8d5c2450               lea r11, [rsp + 0x50]
0000c25c  498b5b38                 mov rbx, qword ptr [r11 + 0x38]
0000c260  498b6b40                 mov rbp, qword ptr [r11 + 0x40]
0000c264  498b7348                 mov rsi, qword ptr [r11 + 0x48]
0000c268  498be3                   mov rsp, r11
0000c26b  415f                     pop r15
0000c26d  415e                     pop r14
0000c26f  415d                     pop r13
0000c271  415c                     pop r12
0000c273  5f                       pop rdi
0000c274  c3                       ret
0000c275  ba5f000000               mov edx, 0x5f
0000c27a  b94b010000               mov ecx, 0x14b
0000c27f  448d4aa2                 lea r9d, [rdx - 0x5e]
0000c283  448d42b2                 lea r8d, [rdx - 0x4e]
0000c287  e814d10000               call 0x193a0
0000c28c  90                       nop
0000c28d  ba2e000000               mov edx, 0x2e
0000c292  b94f010000               mov ecx, 0x14f
0000c297  448d4ad7                 lea r9d, [rdx - 0x29]
0000c29b  448d42e2                 lea r8d, [rdx - 0x1e]
0000c29f  e8fcd00000               call 0x193a0
0000c2a4  cc                       int3
