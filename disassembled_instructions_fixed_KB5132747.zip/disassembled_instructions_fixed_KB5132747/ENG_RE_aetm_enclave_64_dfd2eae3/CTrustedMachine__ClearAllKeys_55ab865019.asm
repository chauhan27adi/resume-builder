; CTrustedMachine::ClearAllKeys
; aetm_enclave.dll, primary RVA 0xe7a0, 1156 bytes in 1 chunk(s)

; chunk at RVA 0xe7a0 (1156 bytes)
0000e7a0  48895c2410               mov qword ptr [rsp + 0x10], rbx
0000e7a5  48896c2418               mov qword ptr [rsp + 0x18], rbp
0000e7aa  4889742420               mov qword ptr [rsp + 0x20], rsi
0000e7af  57                       push rdi
0000e7b0  4156                     push r14
0000e7b2  4c8d89d0da5600           lea r9, [rcx + 0x56dad0]
0000e7b9  90                       nop
0000e7ba  0fb681f8da5600           movzx eax, byte ptr [rcx + 0x56daf8]
0000e7c1  4c8d81d05a5800           lea r8, [rcx + 0x585ad0]
0000e7c8  488bf9                   mov rdi, rcx
0000e7cb  498bd1                   mov rdx, r9
0000e7ce  4d3bc8                   cmp r9, r8
0000e7d1  7312                     jae 0xe7e5
0000e7d3  84c0                     test al, al
0000e7d5  750e                     jne 0xe7e5
0000e7d7  4883c230                 add rdx, 0x30
0000e7db  90                       nop
0000e7dc  0fb64228                 movzx eax, byte ptr [rdx + 0x28]
0000e7e0  493bd0                   cmp rdx, r8
0000e7e3  72ee                     jb 0xe7d3
0000e7e5  48beabaaaaaaaaaaaaaa     movabs rsi, 0xaaaaaaaaaaaaaaab
0000e7ef  48bd00000000ffffffff     movabs rbp, 0xffffffff00000000
0000e7f9  49be0000000001000000     movabs r14, 0x100000000
0000e803  90                       nop
0000e804  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000e809  90                       nop
0000e80a  4c8bd2                   mov r10, rdx
0000e80d  493bd0                   cmp rdx, r8
0000e810  0f84e8000000             je 0xe8fe
0000e816  0fb64228                 movzx eax, byte ptr [rdx + 0x28]
0000e81a  488bca                   mov rcx, rdx
0000e81d  90                       nop
0000e81e  492bc9                   sub rcx, r9
0000e821  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000e825  90                       nop
0000e826  48c1e820                 shr rax, 0x20
0000e82a  48c1f904                 sar rcx, 4
0000e82e  480fafce                 imul rcx, rsi
0000e832  4863d1                   movsxd rdx, ecx
0000e835  48c1e220                 shl rdx, 0x20
0000e839  480bd0                   or rdx, rax
0000e83c  488bc2                   mov rax, rdx
0000e83f  48c1e820                 shr rax, 0x20
0000e843  8bc8                     mov ecx, eax
0000e845  25ff070000               and eax, 0x7ff
0000e84a  8bd8                     mov ebx, eax
0000e84c  488d0440                 lea rax, [rax + rax*2]
0000e850  4803c0                   add rax, rax
0000e853  450fb65cc129             movzx r11d, byte ptr [r9 + rax*8 + 0x29]
0000e859  90                       nop
0000e85a  498b44c120               mov rax, qword ptr [r9 + rax*8 + 0x20]
0000e85f  48c1e820                 shr rax, 0x20
0000e863  3bc2                     cmp eax, edx
0000e865  755c                     jne 0xe8c3
0000e867  4584db                   test r11b, r11b
0000e86a  7457                     je 0xe8c3
0000e86c  81e1ff070000             and ecx, 0x7ff
0000e872  90                       nop
0000e873  488d1449                 lea rdx, [rcx + rcx*2]
0000e877  48c1e204                 shl rdx, 4
0000e87b  4903d1                   add rdx, r9
0000e87e  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000e882  85c0                     test eax, eax
0000e884  753d                     jne 0xe8c3
0000e886  488bc8                   mov rcx, rax
0000e889  4823cd                   and rcx, rbp
0000e88c  4903ce                   add rcx, r14
0000e88f  f0480fb14a20             lock cmpxchg qword ptr [rdx + 0x20], rcx
0000e895  752c                     jne 0xe8c3
0000e897  c6422800                 mov byte ptr [rdx + 0x28], 0
0000e89b  c6422900                 mov byte ptr [rdx + 0x29], 0
0000e89f  90                       nop
0000e8a0  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000e8a4  48c1e820                 shr rax, 0x20
0000e8a8  83f8ff                   cmp eax, -1
0000e8ab  7416                     je 0xe8c3
0000e8ad  49638100a00100           movsxd rax, dword ptr [r9 + 0x1a000]
0000e8b4  41899c8100800100         mov dword ptr [r9 + rax*4 + 0x18000], ebx
0000e8bc  41ff8100a00100           inc dword ptr [r9 + 0x1a000]
0000e8c3  48ff0d8e704600           dec qword ptr [rip + 0x46708e]
0000e8ca  498d5230                 lea rdx, [r10 + 0x30]
0000e8ce  4d3bd0                   cmp r10, r8
0000e8d1  90                       nop
0000e8d2  490f43d2                 cmovae rdx, r10
0000e8d6  0fb64228                 movzx eax, byte ptr [rdx + 0x28]
0000e8da  493bd0                   cmp rdx, r8
0000e8dd  0f8320ffffff             jae 0xe803
0000e8e3  84c0                     test al, al
0000e8e5  0f8518ffffff             jne 0xe803
0000e8eb  4883c230                 add rdx, 0x30
0000e8ef  90                       nop
0000e8f0  0fb64228                 movzx eax, byte ptr [rdx + 0x28]
0000e8f4  493bd0                   cmp rdx, r8
0000e8f7  72ea                     jb 0xe8e3
0000e8f9  e905ffffff               jmp 0xe803
0000e8fe  0fb687e85a5100           movzx eax, byte ptr [rdi + 0x515ae8]
0000e905  4c8d8fc85a5100           lea r9, [rdi + 0x515ac8]
0000e90c  4c8d87c85a5600           lea r8, [rdi + 0x565ac8]
0000e913  498bd1                   mov rdx, r9
0000e916  4d3bc8                   cmp r9, r8
0000e919  7317                     jae 0xe932
0000e91b  0f1f440000               nop dword ptr [rax + rax]
0000e920  84c0                     test al, al
0000e922  750e                     jne 0xe932
0000e924  4883c228                 add rdx, 0x28
0000e928  90                       nop
0000e929  0fb64220                 movzx eax, byte ptr [rdx + 0x20]
0000e92d  493bd0                   cmp rdx, r8
0000e930  72ee                     jb 0xe920
0000e932  48becdcccccccccccccc     movabs rsi, 0xcccccccccccccccd
0000e93c  0f1f4000                 nop dword ptr [rax]
0000e940  90                       nop
0000e941  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000e946  90                       nop
0000e947  4c8bd2                   mov r10, rdx
0000e94a  493bd0                   cmp rdx, r8
0000e94d  0f84e8000000             je 0xea3b
0000e953  0fb64220                 movzx eax, byte ptr [rdx + 0x20]
0000e957  488bca                   mov rcx, rdx
0000e95a  90                       nop
0000e95b  492bc9                   sub rcx, r9
0000e95e  488b4218                 mov rax, qword ptr [rdx + 0x18]
0000e962  90                       nop
0000e963  48c1e820                 shr rax, 0x20
0000e967  48c1f903                 sar rcx, 3
0000e96b  480fafce                 imul rcx, rsi
0000e96f  4863d1                   movsxd rdx, ecx
0000e972  48c1e220                 shl rdx, 0x20
0000e976  480bd0                   or rdx, rax
0000e979  488bc2                   mov rax, rdx
0000e97c  48c1e820                 shr rax, 0x20
0000e980  8bc8                     mov ecx, eax
0000e982  25ff1f0000               and eax, 0x1fff
0000e987  8bd8                     mov ebx, eax
0000e989  488d0480                 lea rax, [rax + rax*4]
0000e98d  450fb65cc121             movzx r11d, byte ptr [r9 + rax*8 + 0x21]
0000e993  90                       nop
0000e994  498b44c118               mov rax, qword ptr [r9 + rax*8 + 0x18]
0000e999  48c1e820                 shr rax, 0x20
0000e99d  3bc2                     cmp eax, edx
0000e99f  755a                     jne 0xe9fb
0000e9a1  4584db                   test r11b, r11b
0000e9a4  7455                     je 0xe9fb
0000e9a6  81e1ff1f0000             and ecx, 0x1fff
0000e9ac  90                       nop
0000e9ad  488d0489                 lea rax, [rcx + rcx*4]
0000e9b1  498d14c1                 lea rdx, [r9 + rax*8]
0000e9b5  498b44c118               mov rax, qword ptr [r9 + rax*8 + 0x18]
0000e9ba  85c0                     test eax, eax
0000e9bc  753d                     jne 0xe9fb
0000e9be  488bc8                   mov rcx, rax
0000e9c1  4823cd                   and rcx, rbp
0000e9c4  4903ce                   add rcx, r14
0000e9c7  f0480fb14a18             lock cmpxchg qword ptr [rdx + 0x18], rcx
0000e9cd  752c                     jne 0xe9fb
0000e9cf  c6422000                 mov byte ptr [rdx + 0x20], 0
0000e9d3  c6422100                 mov byte ptr [rdx + 0x21], 0
0000e9d7  90                       nop
0000e9d8  488b4218                 mov rax, qword ptr [rdx + 0x18]
0000e9dc  48c1e820                 shr rax, 0x20
0000e9e0  83f8ff                   cmp eax, -1
0000e9e3  7416                     je 0xe9fb
0000e9e5  49638100800500           movsxd rax, dword ptr [r9 + 0x58000]
0000e9ec  41899c8100000500         mov dword ptr [r9 + rax*4 + 0x50000], ebx
0000e9f4  41ff8100800500           inc dword ptr [r9 + 0x58000]
0000e9fb  48ff0d4e6f4600           dec qword ptr [rip + 0x466f4e]
0000ea02  498d5228                 lea rdx, [r10 + 0x28]
0000ea06  4d3bd0                   cmp r10, r8
0000ea09  90                       nop
0000ea0a  490f43d2                 cmovae rdx, r10
0000ea0e  0fb64220                 movzx eax, byte ptr [rdx + 0x20]
0000ea12  493bd0                   cmp rdx, r8
0000ea15  0f8325ffffff             jae 0xe940
0000ea1b  0f1f440000               nop dword ptr [rax + rax]
0000ea20  84c0                     test al, al
0000ea22  0f8518ffffff             jne 0xe940
0000ea28  4883c228                 add rdx, 0x28
0000ea2c  90                       nop
0000ea2d  0fb64220                 movzx eax, byte ptr [rdx + 0x20]
0000ea31  493bd0                   cmp rdx, r8
0000ea34  72ea                     jb 0xea20
0000ea36  e905ffffff               jmp 0xe940
0000ea3b  0fb68700db4700           movzx eax, byte ptr [rdi + 0x47db00]
0000ea42  4c8d9fc0da4700           lea r11, [rdi + 0x47dac0]
0000ea49  4c8d87c0da5000           lea r8, [rdi + 0x50dac0]
0000ea50  498bcb                   mov rcx, r11
0000ea53  4d3bd8                   cmp r11, r8
0000ea56  7312                     jae 0xea6a
0000ea58  84c0                     test al, al
0000ea5a  750e                     jne 0xea6a
0000ea5c  4883c148                 add rcx, 0x48
0000ea60  90                       nop
0000ea61  0fb64140                 movzx eax, byte ptr [rcx + 0x40]
0000ea65  493bc8                   cmp rcx, r8
0000ea68  72ee                     jb 0xea58
0000ea6a  48be398ee3388ee3388e     movabs rsi, 0x8e38e38e38e38e39
0000ea74  90                       nop
0000ea75  410fb64040               movzx eax, byte ptr [r8 + 0x40]
0000ea7a  488bd9                   mov rbx, rcx
0000ea7d  493bc8                   cmp rcx, r8
0000ea80  0f848b010000             je 0xec11
0000ea86  488b5130                 mov rdx, qword ptr [rcx + 0x30]
0000ea8a  4c8d97b85a4100           lea r10, [rdi + 0x415ab8]
0000ea91  90                       nop
0000ea92  488bc2                   mov rax, rdx
0000ea95  48c1e820                 shr rax, 0x20
0000ea99  25ff1f0000               and eax, 0x1fff
0000ea9e  488d0440                 lea rax, [rax + rax*2]
0000eaa2  4803c0                   add rax, rax
0000eaa5  450fb64cc229             movzx r9d, byte ptr [r10 + rax*8 + 0x29]
0000eaab  90                       nop
0000eaac  498b44c220               mov rax, qword ptr [r10 + rax*8 + 0x20]
0000eab1  48c1e820                 shr rax, 0x20
0000eab5  3bc2                     cmp eax, edx
0000eab7  7573                     jne 0xeb2c
0000eab9  4584c9                   test r9b, r9b
0000eabc  746e                     je 0xeb2c
0000eabe  488b4130                 mov rax, qword ptr [rcx + 0x30]
0000eac2  90                       nop
0000eac3  48c1e820                 shr rax, 0x20
0000eac7  25ff1f0000               and eax, 0x1fff
0000eacc  4c8d0c40                 lea r9, [rax + rax*2]
0000ead0  49c1e104                 shl r9, 4
0000ead4  4d03ca                   add r9, r10
0000ead7  498b4120                 mov rax, qword ptr [r9 + 0x20]
0000eadb  85c0                     test eax, eax
0000eadd  754d                     jne 0xeb2c
0000eadf  488bd0                   mov rdx, rax
0000eae2  4823d5                   and rdx, rbp
0000eae5  4903d6                   add rdx, r14
0000eae8  f0490fb15120             lock cmpxchg qword ptr [r9 + 0x20], rdx
0000eaee  753c                     jne 0xeb2c
0000eaf0  41c6412800               mov byte ptr [r9 + 0x28], 0
0000eaf5  41c6412900               mov byte ptr [r9 + 0x29], 0
0000eafa  90                       nop
0000eafb  498b4120                 mov rax, qword ptr [r9 + 0x20]
0000eaff  48c1e820                 shr rax, 0x20
0000eb03  83f8ff                   cmp eax, -1
0000eb06  7424                     je 0xeb2c
0000eb08  488b5130                 mov rdx, qword ptr [rcx + 0x30]
0000eb0c  49638200800600           movsxd rax, dword ptr [r10 + 0x68000]
0000eb13  48c1ea20                 shr rdx, 0x20
0000eb17  81e2ff1f0000             and edx, 0x1fff
0000eb1d  4189948200000600         mov dword ptr [r10 + rax*4 + 0x60000], edx
0000eb25  41ff8200800600           inc dword ptr [r10 + 0x68000]
0000eb2c  90                       nop
0000eb2d  488bd1                   mov rdx, rcx
0000eb30  0fb64140                 movzx eax, byte ptr [rcx + 0x40]
0000eb34  492bd3                   sub rdx, r11
0000eb37  90                       nop
0000eb38  48c1fa03                 sar rdx, 3
0000eb3c  488b4138                 mov rax, qword ptr [rcx + 0x38]
0000eb40  90                       nop
0000eb41  48c1e820                 shr rax, 0x20
0000eb45  480fafd6                 imul rdx, rsi
0000eb49  4863ca                   movsxd rcx, edx
0000eb4c  48c1e120                 shl rcx, 0x20
0000eb50  480bc8                   or rcx, rax
0000eb53  488bc1                   mov rax, rcx
0000eb56  48c1e820                 shr rax, 0x20
0000eb5a  8bd0                     mov edx, eax
0000eb5c  25ff1f0000               and eax, 0x1fff
0000eb61  448bd0                   mov r10d, eax
0000eb64  488d04c0                 lea rax, [rax + rax*8]
0000eb68  450fb64cc341             movzx r9d, byte ptr [r11 + rax*8 + 0x41]
0000eb6e  90                       nop
0000eb6f  498b44c338               mov rax, qword ptr [r11 + rax*8 + 0x38]
0000eb74  48c1e820                 shr rax, 0x20
0000eb78  3bc1                     cmp eax, ecx
0000eb7a  755a                     jne 0xebd6
0000eb7c  4584c9                   test r9b, r9b
0000eb7f  7455                     je 0xebd6
0000eb81  81e2ff1f0000             and edx, 0x1fff
0000eb87  90                       nop
0000eb88  488d04d2                 lea rax, [rdx + rdx*8]
0000eb8c  498d14c3                 lea rdx, [r11 + rax*8]
0000eb90  498b44c338               mov rax, qword ptr [r11 + rax*8 + 0x38]
0000eb95  85c0                     test eax, eax
0000eb97  753d                     jne 0xebd6
0000eb99  488bc8                   mov rcx, rax
0000eb9c  4823cd                   and rcx, rbp
0000eb9f  4903ce                   add rcx, r14
0000eba2  f0480fb14a38             lock cmpxchg qword ptr [rdx + 0x38], rcx
0000eba8  752c                     jne 0xebd6
0000ebaa  c6424000                 mov byte ptr [rdx + 0x40], 0
0000ebae  c6424100                 mov byte ptr [rdx + 0x41], 0
0000ebb2  90                       nop
0000ebb3  488b4238                 mov rax, qword ptr [rdx + 0x38]
0000ebb7  48c1e820                 shr rax, 0x20
0000ebbb  83f8ff                   cmp eax, -1
0000ebbe  7416                     je 0xebd6
0000ebc0  49638300800900           movsxd rax, dword ptr [r11 + 0x98000]
0000ebc7  4589948300000900         mov dword ptr [r11 + rax*4 + 0x90000], r10d
0000ebcf  41ff8300800900           inc dword ptr [r11 + 0x98000]
0000ebd6  48ff0d6b6d4600           dec qword ptr [rip + 0x466d6b]
0000ebdd  488d4b48                 lea rcx, [rbx + 0x48]
0000ebe1  493bd8                   cmp rbx, r8
0000ebe4  90                       nop
0000ebe5  480f43cb                 cmovae rcx, rbx
0000ebe9  0fb64140                 movzx eax, byte ptr [rcx + 0x40]
0000ebed  493bc8                   cmp rcx, r8
0000ebf0  0f837efeffff             jae 0xea74
0000ebf6  84c0                     test al, al
0000ebf8  0f8576feffff             jne 0xea74
0000ebfe  4883c148                 add rcx, 0x48
0000ec02  90                       nop
0000ec03  0fb64140                 movzx eax, byte ptr [rcx + 0x40]
0000ec07  493bc8                   cmp rcx, r8
0000ec0a  72ea                     jb 0xebf6
0000ec0c  e963feffff               jmp 0xea74
0000ec11  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0000ec16  488b6c2428               mov rbp, qword ptr [rsp + 0x28]
0000ec1b  488b742430               mov rsi, qword ptr [rsp + 0x30]
0000ec20  415e                     pop r14
0000ec22  5f                       pop rdi
0000ec23  c3                       ret
