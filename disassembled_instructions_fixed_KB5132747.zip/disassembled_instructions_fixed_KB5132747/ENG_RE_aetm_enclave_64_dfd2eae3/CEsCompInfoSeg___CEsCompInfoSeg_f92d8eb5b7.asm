; CEsCompInfoSeg::~CEsCompInfoSeg
; aetm_enclave.dll, primary RVA 0x2c1c0, 86 bytes in 3 chunk(s)

; chunk at RVA 0x2c1c0 (17 bytes)
0002c1c0  4057                     push rdi
0002c1c2  4883ec20                 sub rsp, 0x20
0002c1c6  488bf9                   mov rdi, rcx
0002c1c9  488b09                   mov rcx, qword ptr [rcx]
0002c1cc  4885c9                   test rcx, rcx
0002c1cf  743f                     je 0x2c210

; chunk at RVA 0x2c1d1 (63 bytes)
0002c1d1  48895c2430               mov qword ptr [rsp + 0x30], rbx
0002c1d6  33db                     xor ebx, ebx
0002c1d8  395f08                   cmp dword ptr [rdi + 8], ebx
0002c1db  7629                     jbe 0x2c206
0002c1dd  488bd1                   mov rdx, rcx
0002c1e0  4c8b04d9                 mov r8, qword ptr [rcx + rbx*8]
0002c1e4  4d85c0                   test r8, r8
0002c1e7  7413                     je 0x2c1fc
0002c1e9  498b00                   mov rax, qword ptr [r8]
0002c1ec  ba01000000               mov edx, 1
0002c1f1  498bc8                   mov rcx, r8
0002c1f4  ff10                     call qword ptr [rax]
0002c1f6  488b0f                   mov rcx, qword ptr [rdi]
0002c1f9  488bd1                   mov rdx, rcx
0002c1fc  ffc3                     inc ebx
0002c1fe  3b5f08                   cmp ebx, dword ptr [rdi + 8]
0002c201  72dd                     jb 0x2c1e0
0002c203  488bca                   mov rcx, rdx
0002c206  e8310c0300               call 0x5ce3c
0002c20b  488b5c2430               mov rbx, qword ptr [rsp + 0x30]

; chunk at RVA 0x2c210 (6 bytes)
0002c210  4883c420                 add rsp, 0x20
0002c214  5f                       pop rdi
0002c215  c3                       ret
