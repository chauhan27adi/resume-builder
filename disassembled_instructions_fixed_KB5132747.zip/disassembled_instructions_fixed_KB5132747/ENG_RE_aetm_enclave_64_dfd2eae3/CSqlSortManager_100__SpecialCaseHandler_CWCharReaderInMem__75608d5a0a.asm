; CSqlSortManager_100::SpecialCaseHandler<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x56cb0, 1640 bytes in 1 chunk(s)

; chunk at RVA 0x56cb0 (1640 bytes)
00056cb0  48895c2418               mov qword ptr [rsp + 0x18], rbx
00056cb5  55                       push rbp
00056cb6  56                       push rsi
00056cb7  57                       push rdi
00056cb8  4154                     push r12
00056cba  4155                     push r13
00056cbc  4156                     push r14
00056cbe  4157                     push r15
00056cc0  4881ec80000000           sub rsp, 0x80
00056cc7  488b8424f0000000         mov rax, qword ptr [rsp + 0xf0]
00056ccf  488bfa                   mov rdi, rdx
00056cd2  488b9c24e8000000         mov rbx, qword ptr [rsp + 0xe8]
00056cda  458be8                   mov r13d, r8d
00056cdd  4c8bb42418010000         mov r14, qword ptr [rsp + 0x118]
00056ce5  4c8b9c24e0000000         mov r11, qword ptr [rsp + 0xe0]
00056ced  4c8bbc2410010000         mov r15, qword ptr [rsp + 0x110]
00056cf5  488bac2420010000         mov rbp, qword ptr [rsp + 0x120]
00056cfd  488bb42440010000         mov rsi, qword ptr [rsp + 0x140]
00056d05  4c8b942448010000         mov r10, qword ptr [rsp + 0x148]
00056d0d  4c8ba42450010000         mov r12, qword ptr [rsp + 0x150]
00056d15  4c8b842458010000         mov r8, qword ptr [rsp + 0x158]
00056d1d  4889442468               mov qword ptr [rsp + 0x68], rax
00056d22  488b842408010000         mov rax, qword ptr [rsp + 0x108]
00056d2a  4889442458               mov qword ptr [rsp + 0x58], rax
00056d2f  8b842428010000           mov eax, dword ptr [rsp + 0x128]
00056d36  48894c2450               mov qword ptr [rsp + 0x50], rcx
00056d3b  89442444                 mov dword ptr [rsp + 0x44], eax
00056d3f  498b01                   mov rax, qword ptr [r9]
00056d42  488bc8                   mov rcx, rax
00056d45  4889542448               mov qword ptr [rsp + 0x48], rdx
00056d4a  48c1e928                 shr rcx, 0x28
00056d4e  0fb6d1                   movzx edx, cl
00056d51  4c894c2460               mov qword ptr [rsp + 0x60], r9
00056d56  83fa06                   cmp edx, 6
00056d59  0f877d050000             ja 0x572dc
00056d5f  8bca                     mov ecx, edx
00056d61  488d159892faff           lea rdx, [rip - 0x56d68]
00056d68  8b948afc720500           mov edx, dword ptr [rdx + rcx*4 + 0x572fc]
00056d6f  488d0d8a92faff           lea rcx, [rip - 0x56d76]
00056d76  4803d1                   add rdx, rcx
00056d79  ffe2                     jmp rdx
00056d7b  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
00056d83  0f8553050000             jne 0x572dc
00056d89  488b8c2430010000         mov rcx, qword ptr [rsp + 0x130]
00056d91  4183e502                 and r13d, 2
00056d95  488b16                   mov rdx, qword ptr [rsi]
00056d98  4883c102                 add rcx, 2
00056d9c  483bd1                   cmp rdx, rcx
00056d9f  730d                     jae 0x56dae
00056da1  807afe14                 cmp byte ptr [rdx - 2], 0x14
00056da5  7707                     ja 0x56dae
00056da7  bf01000000               mov edi, 1
00056dac  eb02                     jmp 0x56db0
00056dae  33ff                     xor edi, edi
00056db0  4585ed                   test r13d, r13d
00056db3  7408                     je 0x56dbd
00056db5  85ff                     test edi, edi
00056db7  0f851f050000             jne 0x572dc
00056dbd  498b12                   mov rdx, qword ptr [r10]
00056dc0  483b942438010000         cmp rdx, qword ptr [rsp + 0x138]
00056dc8  761b                     jbe 0x56de5
00056dca  0fb6c8                   movzx ecx, al
00056dcd  0fb642ff                 movzx eax, byte ptr [rdx - 1]
00056dd1  03c8                     add ecx, eax
00056dd3  b8ff000000               mov eax, 0xff
00056dd8  3bc8                     cmp ecx, eax
00056dda  0f47c8                   cmova ecx, eax
00056ddd  884aff                   mov byte ptr [rdx - 1], cl
00056de0  e9f7040000               jmp 0x572dc
00056de5  8802                     mov byte ptr [rdx], al
00056de7  49ff02                   inc qword ptr [r10]
00056dea  e9ed040000               jmp 0x572dc
00056def  448b5b08                 mov r11d, dword ptr [rbx + 8]
00056df3  4c8d530e                 lea r10, [rbx + 0xe]
00056df7  488bc8                   mov rcx, rax
00056dfa  48c1e820                 shr rax, 0x20
00056dfe  48c1e908                 shr rcx, 8
00056e02  0fb6d1                   movzx edx, cl
00056e05  0fb6c8                   movzx ecx, al
00056e08  48c1e208                 shl rdx, 8
00056e0c  480bd1                   or rdx, rcx
00056e0f  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00056e14  488b81a8000000           mov rax, qword ptr [rcx + 0xa8]
00056e1b  440fb70490               movzx r8d, word ptr [rax + rdx*4]
00056e20  0fb7749002               movzx esi, word ptr [rax + rdx*4 + 2]
00056e25  488d530c                 lea rdx, [rbx + 0xc]
00056e29  488b03                   mov rax, qword ptr [rbx]
00056e2c  493bc2                   cmp rax, r10
00056e2f  741a                     je 0x56e4b
00056e31  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
00056e35  4883c002                 add rax, 2
00056e39  488903                   mov qword ptr [rbx], rax
00056e3c  66448902                 mov word ptr [rdx], r8w
00056e40  66418932                 mov word ptr [r10], si
00056e44  4885c9                   test rcx, rcx
00056e47  7523                     jne 0x56e6c
00056e49  eb1a                     jmp 0x56e65
00056e4b  488b4310                 mov rax, qword ptr [rbx + 0x10]
00056e4f  33ff                     xor edi, edi
00056e51  48897b10                 mov qword ptr [rbx + 0x10], rdi
00056e55  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
00056e5a  488903                   mov qword ptr [rbx], rax
00056e5d  66448902                 mov word ptr [rdx], r8w
00056e61  66418932                 mov word ptr [r10], si
00056e65  488b03                   mov rax, qword ptr [rbx]
00056e68  48894310                 mov qword ptr [rbx + 0x10], rax
00056e6c  488913                   mov qword ptr [rbx], rdx
00056e6f  418d4301                 lea eax, [r11 + 1]
00056e73  894308                   mov dword ptr [rbx + 8], eax
00056e76  488b4708                 mov rax, qword ptr [rdi + 8]
00056e7a  428b1480                 mov edx, dword ptr [rax + r8*4]
00056e7e  0fb7c2                   movzx eax, dx
00056e81  48c1e020                 shl rax, 0x20
00056e85  48c1ea10                 shr rdx, 0x10
00056e89  480bc2                   or rax, rdx
00056e8c  498901                   mov qword ptr [r9], rax
00056e8f  b801000000               mov eax, 1
00056e94  e945040000               jmp 0x572de
00056e99  33ff                     xor edi, edi
00056e9b  4c8d442470               lea r8, [rsp + 0x70]
00056ea0  498bd3                   mov rdx, r11
00056ea3  897c2470                 mov dword ptr [rsp + 0x70], edi
00056ea7  498bc9                   mov rcx, r9
00056eaa  e8e1b1ffff               call 0x52090
00056eaf  39bc24f8000000           cmp dword ptr [rsp + 0xf8], edi
00056eb6  0f8535030000             jne 0x571f1
00056ebc  8b4c2470                 mov ecx, dword ptr [rsp + 0x70]
00056ec0  85c9                     test ecx, ecx
00056ec2  0f8429030000             je 0x571f1
00056ec8  498b0424                 mov rax, qword ptr [r12]
00056ecc  4c63442444               movsxd r8, dword ptr [rsp + 0x44]
00056ed1  8808                     mov byte ptr [rax], cl
00056ed3  498b0c24                 mov rcx, qword ptr [r12]
00056ed7  0fb6442471               movzx eax, byte ptr [rsp + 0x71]
00056edc  41880408                 mov byte ptr [r8 + rcx], al
00056ee0  410fbae510               bt r13d, 0x10
00056ee5  7213                     jb 0x56efa
00056ee7  498b0c24                 mov rcx, qword ptr [r12]
00056eeb  438d0400                 lea eax, [r8 + r8]
00056eef  4863d0                   movsxd rdx, eax
00056ef2  0fb6442472               movzx eax, byte ptr [rsp + 0x72]
00056ef7  88040a                   mov byte ptr [rdx + rcx], al
00056efa  410fbae511               bt r13d, 0x11
00056eff  7213                     jb 0x56f14
00056f01  498b0c24                 mov rcx, qword ptr [r12]
00056f05  438d0440                 lea eax, [r8 + r8*2]
00056f09  4863d0                   movsxd rdx, eax
00056f0c  0fb6442473               movzx eax, byte ptr [rsp + 0x73]
00056f11  88040a                   mov byte ptr [rdx + rcx], al
00056f14  49ff0424                 inc qword ptr [r12]
00056f18  b801000000               mov eax, 1
00056f1d  e9bc030000               jmp 0x572de
00056f22  33ff                     xor edi, edi
00056f24  b960110000               mov ecx, 0x1160
00056f29  49893b                   mov qword ptr [r11], rdi
00056f2c  488b03                   mov rax, qword ptr [rbx]
00056f2f  663908                   cmp word ptr [rax], cx
00056f32  0f83c8020000             jae 0x57200
00056f38  488b542448               mov rdx, qword ptr [rsp + 0x48]
00056f3d  488d442444               lea rax, [rsp + 0x44]
00056f42  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00056f47  4c8d4c2440               lea r9, [rsp + 0x40]
00056f4c  4889442430               mov qword ptr [rsp + 0x30], rax
00056f51  4c8bc3                   mov r8, rbx
00056f54  488d442470               lea rax, [rsp + 0x70]
00056f59  c744242803000000         mov dword ptr [rsp + 0x28], 3
00056f61  4889442420               mov qword ptr [rsp + 0x20], rax
00056f66  e805a8ffff               call 0x51770
00056f6b  448be8                   mov r13d, eax
00056f6e  85c0                     test eax, eax
00056f70  0f8e85020000             jle 0x571fb
00056f76  39bc24f8000000           cmp dword ptr [rsp + 0xf8], edi
00056f7d  0f84d2010000             je 0x57155
00056f83  48634d00                 movsxd rcx, dword ptr [rbp]
00056f87  41bc07020000             mov r12d, 0x207
00056f8d  440fb7442440             movzx r8d, word ptr [rsp + 0x40]
00056f93  8bb42400010000           mov esi, dword ptr [rsp + 0x100]
00056f9a  410fb7d0                 movzx edx, r8w
00056f9e  4c8b4c2458               mov r9, qword ptr [rsp + 0x58]
00056fa3  66c1ea08                 shr dx, 8
00056fa7  42881431                 mov byte ptr [rcx + r14], dl
00056fab  48634d00                 movsxd rcx, dword ptr [rbp]
00056faf  8d4101                   lea eax, [rcx + 1]
00056fb2  894500                   mov dword ptr [rbp], eax
00056fb5  4688443101               mov byte ptr [rcx + r14 + 1], r8b
00056fba  ff4500                   inc dword ptr [rbp]
00056fbd  837d0004                 cmp dword ptr [rbp], 4
00056fc1  0f8599000000             jne 0x57060
00056fc7  897d00                   mov dword ptr [rbp], edi
00056fca  458b01                   mov r8d, dword ptr [r9]
00056fcd  418b16                   mov edx, dword ptr [r14]
00056fd0  85f6                     test esi, esi
00056fd2  7537                     jne 0x5700b
00056fd4  41c1c003                 rol r8d, 3
00056fd8  418bc0                   mov eax, r8d
00056fdb  33c2                     xor eax, edx
00056fdd  418901                   mov dword ptr [r9], eax
00056fe0  6645396602               cmp word ptr [r14 + 2], r12w
00056fe5  7405                     je 0x56fec
00056fe7  418907                   mov dword ptr [r15], eax
00056fea  eb74                     jmp 0x57060
00056fec  410fb706                 movzx eax, word ptr [r14]
00056ff0  66413bc4                 cmp ax, r12w
00056ff4  746a                     je 0x57060
00056ff6  0fb6c8                   movzx ecx, al
00056ff9  4133c8                   xor ecx, r8d
00056ffc  41890f                   mov dword ptr [r15], ecx
00056fff  410fb64601               movzx eax, byte ptr [r14 + 1]
00057004  c1c103                   rol ecx, 3
00057007  33c8                     xor ecx, eax
00057009  eb52                     jmp 0x5705d
0005700b  4569d020080000           imul r10d, r8d, 0x820
00057012  418bc0                   mov eax, r8d
00057015  c1e802                   shr eax, 2
00057018  4403d0                   add r10d, eax
0005701b  418d0412                 lea eax, [r10 + rdx]
0005701f  4133c0                   xor eax, r8d
00057022  418901                   mov dword ptr [r9], eax
00057025  6645396602               cmp word ptr [r14 + 2], r12w
0005702a  7405                     je 0x57031
0005702c  418907                   mov dword ptr [r15], eax
0005702f  eb2f                     jmp 0x57060
00057031  410fb706                 movzx eax, word ptr [r14]
00057035  66413bc4                 cmp ax, r12w
00057039  7425                     je 0x57060
0005703b  0fb6d0                   movzx edx, al
0005703e  4103d2                   add edx, r10d
00057041  4133d0                   xor edx, r8d
00057044  69c220080000             imul eax, edx, 0x820
0005704a  418917                   mov dword ptr [r15], edx
0005704d  410fb64e01               movzx ecx, byte ptr [r14 + 1]
00057052  03c8                     add ecx, eax
00057054  8bc2                     mov eax, edx
00057056  c1e802                   shr eax, 2
00057059  03c8                     add ecx, eax
0005705b  33ca                     xor ecx, edx
0005705d  41890f                   mov dword ptr [r15], ecx
00057060  4c8b5c2468               mov r11, qword ptr [rsp + 0x68]
00057065  b800ff0000               mov eax, 0xff00
0005706a  0fb6542470               movzx edx, byte ptr [rsp + 0x70]
0005706f  660bd0                   or dx, ax
00057072  0fb7ca                   movzx ecx, dx
00057075  6641ff03                 inc word ptr [r11]
00057079  48634500                 movsxd rax, dword ptr [rbp]
0005707d  66c1e908                 shr cx, 8
00057081  42880c30                 mov byte ptr [rax + r14], cl
00057085  48634d00                 movsxd rcx, dword ptr [rbp]
00057089  8d4101                   lea eax, [rcx + 1]
0005708c  894500                   mov dword ptr [rbp], eax
0005708f  4288543101               mov byte ptr [rcx + r14 + 1], dl
00057094  ff4500                   inc dword ptr [rbp]
00057097  837d0004                 cmp dword ptr [rbp], 4
0005709b  0f85ae000000             jne 0x5714f
000570a1  897d00                   mov dword ptr [rbp], edi
000570a4  458b01                   mov r8d, dword ptr [r9]
000570a7  418b16                   mov edx, dword ptr [r14]
000570aa  85f6                     test esi, esi
000570ac  7548                     jne 0x570f6
000570ae  41c1c003                 rol r8d, 3
000570b2  418bc0                   mov eax, r8d
000570b5  33c2                     xor eax, edx
000570b7  418901                   mov dword ptr [r9], eax
000570ba  6645396602               cmp word ptr [r14 + 2], r12w
000570bf  740c                     je 0x570cd
000570c1  418907                   mov dword ptr [r15], eax
000570c4  6641ff03                 inc word ptr [r11]
000570c8  e9ba000000               jmp 0x57187
000570cd  410fb706                 movzx eax, word ptr [r14]
000570d1  66413bc4                 cmp ax, r12w
000570d5  7478                     je 0x5714f
000570d7  0fb6c8                   movzx ecx, al
000570da  4133c8                   xor ecx, r8d
000570dd  41890f                   mov dword ptr [r15], ecx
000570e0  410fb64601               movzx eax, byte ptr [r14 + 1]
000570e5  c1c103                   rol ecx, 3
000570e8  33c8                     xor ecx, eax
000570ea  41890f                   mov dword ptr [r15], ecx
000570ed  6641ff03                 inc word ptr [r11]
000570f1  e991000000               jmp 0x57187
000570f6  4569d020080000           imul r10d, r8d, 0x820
000570fd  418bc0                   mov eax, r8d
00057100  c1e802                   shr eax, 2
00057103  4403d0                   add r10d, eax
00057106  418d0412                 lea eax, [r10 + rdx]
0005710a  4133c0                   xor eax, r8d
0005710d  418901                   mov dword ptr [r9], eax
00057110  6645396602               cmp word ptr [r14 + 2], r12w
00057115  7409                     je 0x57120
00057117  418907                   mov dword ptr [r15], eax
0005711a  6641ff03                 inc word ptr [r11]
0005711e  eb67                     jmp 0x57187
00057120  410fb706                 movzx eax, word ptr [r14]
00057124  66413bc4                 cmp ax, r12w
00057128  7425                     je 0x5714f
0005712a  0fb6d0                   movzx edx, al
0005712d  4103d2                   add edx, r10d
00057130  4133d0                   xor edx, r8d
00057133  69c220080000             imul eax, edx, 0x820
00057139  418917                   mov dword ptr [r15], edx
0005713c  410fb64e01               movzx ecx, byte ptr [r14 + 1]
00057141  03c8                     add ecx, eax
00057143  8bc2                     mov eax, edx
00057145  c1e802                   shr eax, 2
00057148  03c8                     add ecx, eax
0005714a  33ca                     xor ecx, edx
0005714c  41890f                   mov dword ptr [r15], ecx
0005714f  6641ff03                 inc word ptr [r11]
00057153  eb32                     jmp 0x57187
00057155  488b06                   mov rax, qword ptr [rsi]
00057158  0fb7542440               movzx edx, word ptr [rsp + 0x40]
0005715d  0fb7ca                   movzx ecx, dx
00057160  66c1e908                 shr cx, 8
00057164  8808                     mov byte ptr [rax], cl
00057166  48ff06                   inc qword ptr [rsi]
00057169  488b06                   mov rax, qword ptr [rsi]
0005716c  8810                     mov byte ptr [rax], dl
0005716e  48ff06                   inc qword ptr [rsi]
00057171  488b06                   mov rax, qword ptr [rsi]
00057174  c600ff                   mov byte ptr [rax], 0xff
00057177  48ff06                   inc qword ptr [rsi]
0005717a  488b0e                   mov rcx, qword ptr [rsi]
0005717d  0fb6442470               movzx eax, byte ptr [rsp + 0x70]
00057182  8801                     mov byte ptr [rcx], al
00057184  48ff06                   inc qword ptr [rsi]
00057187  0fb64c2471               movzx ecx, byte ptr [rsp + 0x71]
0005718c  0fb6442472               movzx eax, byte ptr [rsp + 0x72]
00057191  c1e110                   shl ecx, 0x10
00057194  480bc8                   or rcx, rax
00057197  48b8020200ff00ff0000     movabs rax, 0xff00ff000202
000571a1  48c1e110                 shl rcx, 0x10
000571a5  480bc8                   or rcx, rax
000571a8  488b442460               mov rax, qword ptr [rsp + 0x60]
000571ad  488908                   mov qword ptr [rax], rcx
000571b0  4183fd01                 cmp r13d, 1
000571b4  7e3b                     jle 0x571f1
000571b6  488b0b                   mov rcx, qword ptr [rbx]
000571b9  488d430e                 lea rax, [rbx + 0xe]
000571bd  8b5308                   mov edx, dword ptr [rbx + 8]
000571c0  458d45ff                 lea r8d, [r13 - 1]
000571c4  483bc8                   cmp rcx, rax
000571c7  7417                     je 0x571e0
000571c9  4a8d0c41                 lea rcx, [rcx + r8*2]
000571cd  412bd0                   sub edx, r8d
000571d0  48890b                   mov qword ptr [rbx], rcx
000571d3  b801000000               mov eax, 1
000571d8  895308                   mov dword ptr [rbx + 8], edx
000571db  e9fe000000               jmp 0x572de
000571e0  488b4310                 mov rax, qword ptr [rbx + 0x10]
000571e4  488903                   mov qword ptr [rbx], rax
000571e7  8d42ff                   lea eax, [rdx - 1]
000571ea  894308                   mov dword ptr [rbx + 8], eax
000571ed  48897b10                 mov qword ptr [rbx + 0x10], rdi
000571f1  b801000000               mov eax, 1
000571f6  e9e3000000               jmp 0x572de
000571fb  4c8b4c2460               mov r9, qword ptr [rsp + 0x60]
00057200  498b09                   mov rcx, qword ptr [r9]
00057203  488bc1                   mov rax, rcx
00057206  48c1e820                 shr rax, 0x20
0005720a  0fb6d0                   movzx edx, al
0005720d  48b8ffffffffff00ffff     movabs rax, 0xffff00ffffffffff
00057217  4823c8                   and rcx, rax
0005721a  48c1e228                 shl rdx, 0x28
0005721e  480bd1                   or rdx, rcx
00057221  48b902ffffff00ffffff     movabs rcx, 0xffffff00ffffff02
0005722b  0fb6c2                   movzx eax, dl
0005722e  4823d1                   and rdx, rcx
00057231  48c1e020                 shl rax, 0x20
00057235  480bc2                   or rax, rdx
00057238  4883c802                 or rax, 2
0005723c  498901                   mov qword ptr [r9], rax
0005723f  b801000000               mov eax, 1
00057244  e995000000               jmp 0x572de
00057249  488bc8                   mov rcx, rax
0005724c  48c1e920                 shr rcx, 0x20
00057250  0fb6d1                   movzx edx, cl
00057253  48c1e208                 shl rdx, 8
00057257  0fb6c8                   movzx ecx, al
0005725a  48b802020000fffd0000     movabs rax, 0xfdff00000202
00057264  480bd1                   or rdx, rcx
00057267  48c1e210                 shl rdx, 0x10
0005726b  480bd0                   or rdx, rax
0005726e  b801000000               mov eax, 1
00057273  498911                   mov qword ptr [r9], rdx
00057276  498913                   mov qword ptr [r11], rdx
00057279  eb63                     jmp 0x572de
0005727b  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
00057283  7557                     jne 0x572dc
00057285  488b16                   mov rdx, qword ptr [rsi]
00057288  488b842430010000         mov rax, qword ptr [rsp + 0x130]
00057290  48c1e202                 shl rdx, 2
00057294  488d048500000000         lea rax, [rax*4]
0005729c  662bd0                   sub dx, ax
0005729f  b803800000               mov eax, 0x8003
000572a4  660bd0                   or dx, ax
000572a7  498b00                   mov rax, qword ptr [r8]
000572aa  0fb7ca                   movzx ecx, dx
000572ad  66c1e908                 shr cx, 8
000572b1  8808                     mov byte ptr [rax], cl
000572b3  49ff00                   inc qword ptr [r8]
000572b6  498b00                   mov rax, qword ptr [r8]
000572b9  8810                     mov byte ptr [rax], dl
000572bb  49ff00                   inc qword ptr [r8]
000572be  498b08                   mov rcx, qword ptr [r8]
000572c1  498b01                   mov rax, qword ptr [r9]
000572c4  48c1e828                 shr rax, 0x28
000572c8  8801                     mov byte ptr [rcx], al
000572ca  49ff00                   inc qword ptr [r8]
000572cd  498b01                   mov rax, qword ptr [r9]
000572d0  498b08                   mov rcx, qword ptr [r8]
000572d3  48c1e820                 shr rax, 0x20
000572d7  8801                     mov byte ptr [rcx], al
000572d9  49ff00                   inc qword ptr [r8]
000572dc  33c0                     xor eax, eax
000572de  488b9c24d0000000         mov rbx, qword ptr [rsp + 0xd0]
000572e6  4881c480000000           add rsp, 0x80
000572ed  415f                     pop r15
000572ef  415e                     pop r14
000572f1  415d                     pop r13
000572f3  415c                     pop r12
000572f5  5f                       pop rdi
000572f6  5e                       pop rsi
000572f7  5d                       pop rbp
000572f8  c3                       ret
000572f9  0f1f00                   nop dword ptr [rax]
000572fc  dc7205                   fdiv qword ptr [rdx + 5]
000572ff  007b6d                   add byte ptr [rbx + 0x6d], bh
00057302  0500ef6d05               add eax, 0x56def00
00057307  00996e050022             add byte ptr [rcx + 0x2200056e], bl
0005730d  6f                       outsd dx, dword ptr [rsi]
0005730e  0500497205               add eax, 0x5724900
00057313  007b72                   add byte ptr [rbx + 0x72], bh
