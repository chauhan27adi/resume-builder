; `CValCompEncrTMOutput::PvalInvokeSpecific'::`1'::dtor$10
; aetm_enclave.dll, primary RVA 0x60b10, 38 bytes in 1 chunk(s)

; chunk at RVA 0x60b10 (38 bytes)
00060b10  4055                     push rbp
00060b12  4883ec20                 sub rsp, 0x20
00060b16  488bea                   mov rbp, rdx
00060b19  8b4530                   mov eax, dword ptr [rbp + 0x30]
00060b1c  83e001                   and eax, 1
00060b1f  85c0                     test eax, eax
00060b21  740d                     je 0x60b30
00060b23  836530fe                 and dword ptr [rbp + 0x30], 0xfffffffe
00060b27  488d4d50                 lea rcx, [rbp + 0x50]
00060b2b  e85092fbff               call 0x19d80
00060b30  4883c420                 add rsp, 0x20
00060b34  5d                       pop rbp
00060b35  c3                       ret
