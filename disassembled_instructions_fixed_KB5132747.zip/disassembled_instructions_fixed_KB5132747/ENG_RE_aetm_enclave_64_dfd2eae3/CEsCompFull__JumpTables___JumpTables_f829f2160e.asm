; CEsCompFull::JumpTables::~JumpTables
; aetm_enclave.dll, primary RVA 0x1ef10, 109 bytes in 5 chunk(s)

; chunk at RVA 0x1ef10 (17 bytes)
0001ef10  4053                     push rbx
0001ef12  4883ec20                 sub rsp, 0x20
0001ef16  488bd9                   mov rbx, rcx
0001ef19  488b09                   mov rcx, qword ptr [rcx]
0001ef1c  4885c9                   test rcx, rcx
0001ef1f  7456                     je 0x1ef77

; chunk at RVA 0x1ef21 (13 bytes)
0001ef21  4889742430               mov qword ptr [rsp + 0x30], rsi
0001ef26  33f6                     xor esi, esi
0001ef28  40387308                 cmp byte ptr [rbx + 8], sil
0001ef2c  7634                     jbe 0x1ef62

; chunk at RVA 0x1ef2e (52 bytes)
0001ef2e  48897c2438               mov qword ptr [rsp + 0x38], rdi
0001ef33  33ff                     xor edi, edi
0001ef35  6666660f1f840000000000   nop word ptr [rax + rax]
0001ef40  488b0b                   mov rcx, qword ptr [rbx]
0001ef43  488b0c0f                 mov rcx, qword ptr [rdi + rcx]
0001ef47  e8f0de0300               call 0x5ce3c
0001ef4c  0fb64308                 movzx eax, byte ptr [rbx + 8]
0001ef50  488d7f08                 lea rdi, [rdi + 8]
0001ef54  ffc6                     inc esi
0001ef56  3bf0                     cmp esi, eax
0001ef58  7ce6                     jl 0x1ef40
0001ef5a  488b0b                   mov rcx, qword ptr [rbx]
0001ef5d  488b7c2438               mov rdi, qword ptr [rsp + 0x38]

; chunk at RVA 0x1ef62 (21 bytes)
0001ef62  e8d5de0300               call 0x5ce3c
0001ef67  488b742430               mov rsi, qword ptr [rsp + 0x30]
0001ef6c  48c70300000000           mov qword ptr [rbx], 0
0001ef73  c6430800                 mov byte ptr [rbx + 8], 0

; chunk at RVA 0x1ef77 (6 bytes)
0001ef77  4883c420                 add rsp, 0x20
0001ef7b  5b                       pop rbx
0001ef7c  c3                       ret
