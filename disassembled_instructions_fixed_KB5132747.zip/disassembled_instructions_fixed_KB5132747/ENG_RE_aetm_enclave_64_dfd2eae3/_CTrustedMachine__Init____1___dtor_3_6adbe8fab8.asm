; `CTrustedMachine::Init'::`1'::dtor$3
; aetm_enclave.dll, primary RVA 0x5fd70, 42 bytes in 1 chunk(s)

; chunk at RVA 0x5fd70 (42 bytes)
0005fd70  4055                     push rbp
0005fd72  4883ec20                 sub rsp, 0x20
0005fd76  488bea                   mov rbp, rdx
0005fd79  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0005fd7d  4c8d0dace6fcff           lea r9, [rip - 0x31954]
0005fd84  41b809000000             mov r8d, 9
0005fd8a  ba28000000               mov edx, 0x28
0005fd8f  e8ecd0ffff               call 0x5ce80
0005fd94  4883c420                 add rsp, 0x20
0005fd98  5d                       pop rbp
0005fd99  c3                       ret
