; CSqlSortManager_140::GetNextSortID
; aetm_enclave.dll, primary RVA 0x58560, 4384 bytes in 1 chunk(s)

; chunk at RVA 0x58560 (4384 bytes)
00058560  48895c2408               mov qword ptr [rsp + 8], rbx
00058565  4889742410               mov qword ptr [rsp + 0x10], rsi
0005856a  48897c2418               mov qword ptr [rsp + 0x18], rdi
0005856f  55                       push rbp
00058570  4154                     push r12
00058572  4155                     push r13
00058574  4156                     push r14
00058576  4157                     push r15
00058578  488d6c24e0               lea rbp, [rsp - 0x20]
0005857d  4881ec20010000           sub rsp, 0x120
00058584  488b057d2a0500           mov rax, qword ptr [rip + 0x52a7d]
0005858b  4833c4                   xor rax, rsp
0005858e  48894510                 mov qword ptr [rbp + 0x10], rax
00058592  418b4010                 mov eax, dword ptr [r8 + 0x10]
00058596  4533e4                   xor r12d, r12d
00058599  44894d88                 mov dword ptr [rbp - 0x78], r9d
0005859d  498bf8                   mov rdi, r8
000585a0  448bc8                   mov r9d, eax
000585a3  48894d98                 mov qword ptr [rbp - 0x68], rcx
000585a7  8bc8                     mov ecx, eax
000585a9  41c1e91a                 shr r9d, 0x1a
000585ad  c1e803                   shr eax, 3
000585b0  4180e101                 and r9b, 1
000585b4  2401                     and al, 1
000585b6  d1e9                     shr ecx, 1
000585b8  80e101                   and cl, 1
000585bb  894594                   mov dword ptr [rbp - 0x6c], eax
000585be  418b8088000000           mov eax, dword ptr [r8 + 0x88]
000585c5  4c8bd2                   mov r10, rdx
000585c8  458bdc                   mov r11d, r12d
000585cb  4889542450               mov qword ptr [rsp + 0x50], rdx
000585d0  4489642444               mov dword ptr [rsp + 0x44], r12d
000585d5  4489642474               mov dword ptr [rsp + 0x74], r12d
000585da  448964245c               mov dword ptr [rsp + 0x5c], r12d
000585df  894d90                   mov dword ptr [rbp - 0x70], ecx
000585e2  44894c2468               mov dword ptr [rsp + 0x68], r9d
000585e7  c644244801               mov byte ptr [rsp + 0x48], 1
000585ec  413b8084000000           cmp eax, dword ptr [r8 + 0x84]
000585f3  0f855c0f0000             jne 0x59555
000585f9  488b8588000000           mov rax, qword ptr [rbp + 0x88]
00058600  4885c0                   test rax, rax
00058603  7403                     je 0x58608
00058605  448818                   mov byte ptr [rax], r11b
00058608  0fb744246c               movzx eax, word ptr [rsp + 0x6c]
0005860d  4d8d703c                 lea r14, [r8 + 0x3c]
00058611  8b9d80000000             mov ebx, dword ptr [rbp + 0x80]
00058617  6689442464               mov word ptr [rsp + 0x64], ax
0005861c  eb12                     jmp 0x58630
0005861e  6690                     nop
00058620  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00058625  4533e4                   xor r12d, r12d
00058628  448b4c2468               mov r9d, dword ptr [rsp + 0x68]
0005862d  0f1f00                   nop dword ptr [rax]
00058630  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
00058634  418bf3                   mov esi, r11d
00058637  4183f801                 cmp r8d, 1
0005863b  7d60                     jge 0x5869d
0005863d  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058641  4885c0                   test rax, rax
00058644  7e48                     jle 0x5868e
00058646  488b4718                 mov rax, qword ptr [rdi + 0x18]
0005864a  4885c0                   test rax, rax
0005864d  740b                     je 0x5865a
0005864f  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00058653  ffd0                     call rax
00058655  0fb7c8                   movzx ecx, ax
00058658  eb12                     jmp 0x5866c
0005865a  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
0005865e  488b4728                 mov rax, qword ptr [rdi + 0x28]
00058662  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00058666  8d4201                   lea eax, [rdx + 1]
00058669  894738                   mov dword ptr [rdi + 0x38], eax
0005866c  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00058670  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00058675  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
00058679  48ff4f30                 dec qword ptr [rdi + 0x30]
0005867d  41ffc0                   inc r8d
00058680  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058684  4489475c                 mov dword ptr [rdi + 0x5c], r8d
00058688  4183f801                 cmp r8d, 1
0005868c  7cb3                     jl 0x58641
0005868e  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00058693  448b4c2468               mov r9d, dword ptr [rsp + 0x68]
00058698  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
0005869d  4585c0                   test r8d, r8d
000586a0  0f84ec0e0000             je 0x59592
000586a6  8b8780000000             mov eax, dword ptr [rdi + 0x80]
000586ac  398788000000             cmp dword ptr [rdi + 0x88], eax
000586b2  0f8dd30e0000             jge 0x5958b
000586b8  498b4208                 mov rax, qword ptr [r10 + 8]
000586bc  41bd01000000             mov r13d, 1
000586c2  410fb70e                 movzx ecx, word ptr [r14]
000586c6  4489642460               mov dword ptr [rsp + 0x60], r12d
000586cb  4532e4                   xor r12b, r12b
000586ce  c644245800               mov byte ptr [rsp + 0x58], 0
000586d3  448b3c88                 mov r15d, dword ptr [rax + rcx*4]
000586d7  418bc7                   mov eax, r15d
000586da  44897c2440               mov dword ptr [rsp + 0x40], r15d
000586df  c1e818                   shr eax, 0x18
000586e2  837f0400                 cmp dword ptr [rdi + 4], 0
000586e6  0f84a9000000             je 0x58795
000586ec  663b4f0c                 cmp cx, word ptr [rdi + 0xc]
000586f0  0f859f000000             jne 0x58795
000586f6  4183f802                 cmp r8d, 2
000586fa  7d51                     jge 0x5874d
000586fc  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058700  4885c0                   test rax, rax
00058703  7e48                     jle 0x5874d
00058705  488b4718                 mov rax, qword ptr [rdi + 0x18]
00058709  4885c0                   test rax, rax
0005870c  740b                     je 0x58719
0005870e  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00058712  ffd0                     call rax
00058714  0fb7c8                   movzx ecx, ax
00058717  eb12                     jmp 0x5872b
00058719  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
0005871d  488b4728                 mov rax, qword ptr [rdi + 0x28]
00058721  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00058725  8d4201                   lea eax, [rdx + 1]
00058728  894738                   mov dword ptr [rdi + 0x38], eax
0005872b  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
0005872f  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00058734  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
00058738  48ff4f30                 dec qword ptr [rdi + 0x30]
0005873c  41ffc0                   inc r8d
0005873f  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058743  4489475c                 mov dword ptr [rdi + 0x5c], r8d
00058747  4183f802                 cmp r8d, 2
0005874b  7cb3                     jl 0x58700
0005874d  453bc5                   cmp r8d, r13d
00058750  0f842e0e0000             je 0x59584
00058756  418d40ff                 lea eax, [r8 - 1]
0005875a  498bce                   mov rcx, r14
0005875d  4c63c0                   movsxd r8, eax
00058760  488d573e                 lea rdx, [rdi + 0x3e]
00058764  4d03c0                   add r8, r8
00058767  e8b35a0000               call 0x5e21f
0005876c  ff4f5c                   dec dword ptr [rdi + 0x5c]
0005876f  4c8d058a78faff           lea r8, [rip - 0x58776]
00058776  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0005877b  410fb70e                 movzx ecx, word ptr [r14]
0005877f  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058783  488b4308                 mov rax, qword ptr [rbx + 8]
00058787  448b3c88                 mov r15d, dword ptr [rax + rcx*4]
0005878b  44897c2440               mov dword ptr [rsp + 0x40], r15d
00058790  e95a040000               jmp 0x58bef
00058795  32db                     xor bl, bl
00058797  41837a1400               cmp dword ptr [r10 + 0x14], 0
0005879c  0f842a010000             je 0x588cc
000587a2  8b4c245c                 mov ecx, dword ptr [rsp + 0x5c]
000587a6  a8c0                     test al, 0xc0
000587a8  0f849f010000             je 0x5894d
000587ae  49837a3000               cmp qword ptr [r10 + 0x30], 0
000587b3  0f8494010000             je 0x5894d
000587b9  85c9                     test ecx, ecx
000587bb  0f858c010000             jne 0x5894d
000587c1  4585db                   test r11d, r11d
000587c4  0f8583010000             jne 0x5894d
000587ca  4183f808                 cmp r8d, 8
000587ce  7d56                     jge 0x58826
000587d0  488b4730                 mov rax, qword ptr [rdi + 0x30]
000587d4  4885c0                   test rax, rax
000587d7  7e48                     jle 0x58821
000587d9  488b4718                 mov rax, qword ptr [rdi + 0x18]
000587dd  4885c0                   test rax, rax
000587e0  740b                     je 0x587ed
000587e2  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000587e6  ffd0                     call rax
000587e8  0fb7c8                   movzx ecx, ax
000587eb  eb12                     jmp 0x587ff
000587ed  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000587f1  488b4728                 mov rax, qword ptr [rdi + 0x28]
000587f5  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
000587f9  8d4201                   lea eax, [rdx + 1]
000587fc  894738                   mov dword ptr [rdi + 0x38], eax
000587ff  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00058803  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00058808  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
0005880c  48ff4f30                 dec qword ptr [rdi + 0x30]
00058810  41ffc0                   inc r8d
00058813  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058817  4489475c                 mov dword ptr [rdi + 0x5c], r8d
0005881b  4183f808                 cmp r8d, 8
0005881f  7cb3                     jl 0x587d4
00058821  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00058826  33c0                     xor eax, eax
00058828  4c8975b0                 mov qword ptr [rbp - 0x50], r14
0005882c  488945c0                 mov qword ptr [rbp - 0x40], rax
00058830  4c8d4da0                 lea r9, [rbp - 0x60]
00058834  410fbaf01f               btr r8d, 0x1f
00058839  410fb7c7                 movzx eax, r15w
0005883d  48c1e020                 shl rax, 0x20
00058841  488d55b0                 lea rdx, [rbp - 0x50]
00058845  448945b8                 mov dword ptr [rbp - 0x48], r8d
00058849  498bcf                   mov rcx, r15
0005884c  48c1e910                 shr rcx, 0x10
00058850  4d8bc2                   mov r8, r10
00058853  480bc1                   or rax, rcx
00058856  4c8975c8                 mov qword ptr [rbp - 0x38], r14
0005885a  488945a0                 mov qword ptr [rbp - 0x60], rax
0005885e  e8cdd5ffff               call 0x55e30
00058863  85c0                     test eax, eax
00058865  7450                     je 0x588b7
00058867  8b475c                   mov eax, dword ptr [rdi + 0x5c]
0005886a  498bce                   mov rcx, r14
0005886d  488b5db0                 mov rbx, qword ptr [rbp - 0x50]
00058871  482b5dc8                 sub rbx, qword ptr [rbp - 0x38]
00058875  48d1fb                   sar rbx, 1
00058878  2bc3                     sub eax, ebx
0005887a  4c63c0                   movsxd r8, eax
0005887d  4863c3                   movsxd rax, ebx
00058880  4d03c0                   add r8, r8
00058883  4883c01e                 add rax, 0x1e
00058887  488d1447                 lea rdx, [rdi + rax*2]
0005888b  e88f590000               call 0x5e21f
00058890  488b45a0                 mov rax, qword ptr [rbp - 0x60]
00058894  295f5c                   sub dword ptr [rdi + 0x5c], ebx
00058897  4c8bf8                   mov r15, rax
0005889a  488bc8                   mov rcx, rax
0005889d  49c1ef20                 shr r15, 0x20
000588a1  48c1e110                 shl rcx, 0x10
000588a5  410fb6dd                 movzx ebx, r13b
000588a9  440bf9                   or r15d, ecx
000588ac  48c1e810                 shr rax, 0x10
000588b0  0fb7d0                   movzx edx, ax
000588b3  89542460                 mov dword ptr [rsp + 0x60], edx
000588b7  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000588bc  4181e7ffffff3f           and r15d, 0x3fffffff
000588c3  44897c2440               mov dword ptr [rsp + 0x40], r15d
000588c8  84db                     test bl, bl
000588ca  7533                     jne 0x588ff
000588cc  4438642468               cmp byte ptr [rsp + 0x68], r12b
000588d1  742c                     je 0x588ff
000588d3  b800280000               mov eax, 0x2800
000588d8  b9ff030000               mov ecx, 0x3ff
000588dd  66410306                 add ax, word ptr [r14]
000588e1  663bc1                   cmp ax, cx
000588e4  7719                     ja 0x588ff
000588e6  4c8d4c2440               lea r9, [rsp + 0x40]
000588eb  4c8bc7                   mov r8, rdi
000588ee  498bd2                   mov rdx, r10
000588f1  e88a61ffff               call 0x4ea80
000588f6  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
000588fb  440fb6e0                 movzx r12d, al
000588ff  837f0400                 cmp dword ptr [rdi + 4], 0
00058903  0f84d6020000             je 0x58bdf
00058909  837c245c00               cmp dword ptr [rsp + 0x5c], 0
0005890e  0f85cb020000             jne 0x58bdf
00058914  8b5c2474                 mov ebx, dword ptr [rsp + 0x74]
00058918  4c8d05e176faff           lea r8, [rip - 0x5891f]
0005891f  410fb706                 movzx eax, word ptr [r14]
00058923  ffc3                     inc ebx
00058925  83c0db                   add eax, -0x25
00058928  895c2474                 mov dword ptr [rsp + 0x74], ebx
0005892c  83f83a                   cmp eax, 0x3a
0005892f  0f87a4020000             ja 0x58bd9
00058935  4898                     cdqe
00058937  410fb684002c960500       movzx eax, byte ptr [r8 + rax + 0x5962c]
00058940  418b8c8010960500         mov ecx, dword ptr [r8 + rax*4 + 0x59610]
00058948  4903c8                   add rcx, r8
0005894b  ffe1                     jmp rcx
0005894d  410fb7c7                 movzx eax, r15w
00058951  66c1e808                 shr ax, 8
00058955  3cfe                     cmp al, 0xfe
00058957  0f855fffffff             jne 0x588bc
0005895d  49837a3800               cmp qword ptr [r10 + 0x38], 0
00058962  0f8454ffffff             je 0x588bc
00058968  85c9                     test ecx, ecx
0005896a  0f854cffffff             jne 0x588bc
00058970  4585db                   test r11d, r11d
00058973  7409                     je 0x5897e
00058975  4584c9                   test r9b, r9b
00058978  0f843effffff             je 0x588bc
0005897e  4183f802                 cmp r8d, 2
00058982  7d56                     jge 0x589da
00058984  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058988  4885c0                   test rax, rax
0005898b  7e48                     jle 0x589d5
0005898d  488b4718                 mov rax, qword ptr [rdi + 0x18]
00058991  4885c0                   test rax, rax
00058994  740b                     je 0x589a1
00058996  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0005899a  ffd0                     call rax
0005899c  0fb7c8                   movzx ecx, ax
0005899f  eb12                     jmp 0x589b3
000589a1  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000589a5  488b4728                 mov rax, qword ptr [rdi + 0x28]
000589a9  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
000589ad  8d4201                   lea eax, [rdx + 1]
000589b0  894738                   mov dword ptr [rdi + 0x38], eax
000589b3  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
000589b7  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
000589bc  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
000589c0  48ff4f30                 dec qword ptr [rdi + 0x30]
000589c4  41ffc0                   inc r8d
000589c7  488b4730                 mov rax, qword ptr [rdi + 0x30]
000589cb  4489475c                 mov dword ptr [rdi + 0x5c], r8d
000589cf  4183f802                 cmp r8d, 2
000589d3  7cb3                     jl 0x58988
000589d5  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000589da  410fb716                 movzx edx, word ptr [r14]
000589de  418bc8                   mov ecx, r8d
000589e1  4d8b4a38                 mov r9, qword ptr [r10 + 0x38]
000589e5  b8c0270000               mov eax, 0x27c0
000589ea  0fbaf11f                 btr ecx, 0x1f
000589ee  03c2                     add eax, edx
000589f0  6683f829                 cmp ax, 0x29
000589f4  7723                     ja 0x58a19
000589f6  488d45fe                 lea rax, [rbp - 2]
000589fa  4c3bf0                   cmp r14, rax
000589fd  742b                     je 0x58a2a
000589ff  413bcd                   cmp ecx, r13d
00058a02  760d                     jbe 0x58a11
00058a04  450fb75e02               movzx r11d, word ptr [r14 + 2]
00058a09  6644895c2464             mov word ptr [rsp + 0x64], r11w
00058a0f  eb06                     jmp 0x58a17
00058a11  440fb75c2464             movzx r11d, word ptr [rsp + 0x64]
00058a17  7722                     ja 0x58a3b
00058a19  4181e7ffffff3f           and r15d, 0x3fffffff
00058a20  44897c2440               mov dword ptr [rsp + 0x40], r15d
00058a25  e9a2feffff               jmp 0x588cc
00058a2a  413bcd                   cmp ecx, r13d
00058a2d  76ea                     jbe 0x58a19
00058a2f  33c0                     xor eax, eax
00058a31  440fb718                 movzx r11d, word ptr [rax]
00058a35  6644895c2464             mov word ptr [rsp + 0x64], r11w
00058a3b  b800240000               mov eax, 0x2400
00058a40  b9ff030000               mov ecx, 0x3ff
00058a45  4103c3                   add eax, r11d
00058a48  663bc1                   cmp ax, cx
00058a4b  77cc                     ja 0x58a19
00058a4d  b8c9270000               mov eax, 0x27c9
00058a52  6603d0                   add dx, ax
00058a55  b800040000               mov eax, 0x400
00058a5a  0fb7ca                   movzx ecx, dx
00058a5d  0fafc8                   imul ecx, eax
00058a60  664103cb                 add cx, r11w
00058a64  0fb7c1                   movzx eax, cx
00058a67  6641833c8100             cmp word ptr [r9 + rax*4], 0
00058a6d  74aa                     je 0x58a19
00058a6f  418b0481                 mov eax, dword ptr [r9 + rax*4]
00058a73  488d573e                 lea rdx, [rdi + 0x3e]
00058a77  0fb7d8                   movzx ebx, ax
00058a7a  498bce                   mov rcx, r14
00058a7d  48c1e810                 shr rax, 0x10
00058a81  48c1e320                 shl rbx, 0x20
00058a85  480bd8                   or rbx, rax
00058a88  418d40ff                 lea eax, [r8 - 1]
00058a8c  4c63c0                   movsxd r8, eax
00058a8f  4d03c0                   add r8, r8
00058a92  e888570000               call 0x5e21f
00058a97  ff4f5c                   dec dword ptr [rdi + 0x5c]
00058a9a  488bc3                   mov rax, rbx
00058a9d  48c1e810                 shr rax, 0x10
00058aa1  0fb7d0                   movzx edx, ax
00058aa4  488bc3                   mov rax, rbx
00058aa7  48c1e820                 shr rax, 0x20
00058aab  48c1e310                 shl rbx, 0x10
00058aaf  0bc3                     or eax, ebx
00058ab1  89542460                 mov dword ptr [rsp + 0x60], edx
00058ab5  25ffffff3f               and eax, 0x3fffffff
00058aba  448bf8                   mov r15d, eax
00058abd  89442440                 mov dword ptr [rsp + 0x40], eax
00058ac1  e939feffff               jmp 0x588ff
00058ac6  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058aca  33db                     xor ebx, ebx
00058acc  85d2                     test edx, edx
00058ace  751d                     jne 0x58aed
00058ad0  b8fcff0000               mov eax, 0xfffc
00058ad5  895c2474                 mov dword ptr [rsp + 0x74], ebx
00058ad9  418bd5                   mov edx, r13d
00058adc  6689442440               mov word ptr [rsp + 0x40], ax
00058ae1  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058ae6  89542444                 mov dword ptr [rsp + 0x44], edx
00058aea  895d88                   mov dword ptr [rbp - 0x78], ebx
00058aed  85f6                     test esi, esi
00058aef  448beb                   mov r13d, ebx
00058af2  410f95c5                 setne r13b
00058af6  e9ef000000               jmp 0x58bea
00058afb  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058aff  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058b04  85d2                     test edx, edx
00058b06  0f84e3000000             je 0x58bef
00058b0c  b8fbff0000               mov eax, 0xfffb
00058b11  33d2                     xor edx, edx
00058b13  6689442440               mov word ptr [rsp + 0x40], ax
00058b18  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058b1d  89542444                 mov dword ptr [rsp + 0x44], edx
00058b21  e9c9000000               jmp 0x58bef
00058b26  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058b2a  85d2                     test edx, edx
00058b2c  0f84b8000000             je 0x58bea
00058b32  413bdd                   cmp ebx, r13d
00058b35  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058b3a  0f85af000000             jne 0x58bef
00058b40  b8f9ff0000               mov eax, 0xfff9
00058b45  6689442440               mov word ptr [rsp + 0x40], ax
00058b4a  33c0                     xor eax, eax
00058b4c  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058b51  89442474                 mov dword ptr [rsp + 0x74], eax
00058b55  e995000000               jmp 0x58bef
00058b5a  ba02000000               mov edx, 2
00058b5f  488bcf                   mov rcx, rdi
00058b62  e8d917ffff               call 0x4a340
00058b67  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058b6b  85d2                     test edx, edx
00058b6d  7474                     je 0x58be3
00058b6f  413bdd                   cmp ebx, r13d
00058b72  7e6f                     jle 0x58be3
00058b74  4c8d058574faff           lea r8, [rip - 0x58b7b]
00058b7b  44396f5c                 cmp dword ptr [rdi + 0x5c], r13d
00058b7f  7e69                     jle 0x58bea
00058b81  6641837e025d             cmp word ptr [r14 + 2], 0x5d
00058b87  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058b8c  7461                     je 0x58bef
00058b8e  b8faff0000               mov eax, 0xfffa
00058b93  4533ed                   xor r13d, r13d
00058b96  6689442440               mov word ptr [rsp + 0x40], ax
00058b9b  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058ba0  eb4d                     jmp 0x58bef
00058ba2  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058ba6  85d2                     test edx, edx
00058ba8  7540                     jne 0x58bea
00058baa  b8f7ff0000               mov eax, 0xfff7
00058baf  6689442440               mov word ptr [rsp + 0x40], ax
00058bb4  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058bb9  eb2f                     jmp 0x58bea
00058bbb  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058bbf  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058bc4  85d2                     test edx, edx
00058bc6  7527                     jne 0x58bef
00058bc8  b8feff0000               mov eax, 0xfffe
00058bcd  6689442440               mov word ptr [rsp + 0x40], ax
00058bd2  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058bd7  eb16                     jmp 0x58bef
00058bd9  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058bdd  eb0b                     jmp 0x58bea
00058bdf  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058be3  4c8d051674faff           lea r8, [rip - 0x58bea]
00058bea  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058bef  0fb7442440               movzx eax, word ptr [rsp + 0x40]
00058bf4  4533f6                   xor r14d, r14d
00058bf7  c1e808                   shr eax, 8
00058bfa  83f805                   cmp eax, 5
00058bfd  0f8792060000             ja 0x59295
00058c03  418b8c8068960500         mov ecx, dword ptr [r8 + rax*4 + 0x59668]
00058c0b  4903c8                   add rcx, r8
00058c0e  ffe1                     jmp rcx
00058c10  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00058c13  488d573e                 lea rdx, [rdi + 0x3e]
00058c17  ffc8                     dec eax
00058c19  488d4f3c                 lea rcx, [rdi + 0x3c]
00058c1d  4c63c0                   movsxd r8, eax
00058c20  4d03c0                   add r8, r8
00058c23  e8f7550000               call 0x5e21f
00058c28  488b8590000000           mov rax, qword ptr [rbp + 0x90]
00058c2f  41be01000000             mov r14d, 1
00058c35  ff4f5c                   dec dword ptr [rdi + 0x5c]
00058c38  4885c0                   test rax, rax
00058c3b  7403                     je 0x58c40
00058c3d  48ff00                   inc qword ptr [rax]
00058c40  8b742460                 mov esi, dword ptr [rsp + 0x60]
00058c44  33db                     xor ebx, ebx
00058c46  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00058c4a  448b64245c               mov r12d, dword ptr [rsp + 0x5c]
00058c4f  4585e4                   test r12d, r12d
00058c52  7e0a                     jle 0x58c5e
00058c54  41ffcc                   dec r12d
00058c57  8919                     mov dword ptr [rcx], ebx
00058c59  448964245c               mov dword ptr [rsp + 0x5c], r12d
00058c5e  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
00058c63  4585f6                   test r14d, r14d
00058c66  8b9d80000000             mov ebx, dword ptr [rbp + 0x80]
00058c6c  4c8d773c                 lea r14, [rdi + 0x3c]
00058c70  0f85aaf9ffff             jne 0x58620
00058c76  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00058c79  4c8d773c                 lea r14, [rdi + 0x3c]
00058c7d  ffc8                     dec eax
00058c7f  488d573e                 lea rdx, [rdi + 0x3e]
00058c83  4c63c0                   movsxd r8, eax
00058c86  498bce                   mov rcx, r14
00058c89  4d03c0                   add r8, r8
00058c8c  e88e550000               call 0x5e21f
00058c91  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00058c94  ffc8                     dec eax
00058c96  89475c                   mov dword ptr [rdi + 0x5c], eax
00058c99  4585e4                   test r12d, r12d
00058c9c  0f8462060000             je 0x59304
00058ca2  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00058ca9  488b4768                 mov rax, qword ptr [rdi + 0x68]
00058cad  44893c88                 mov dword ptr [rax + rcx*4], r15d
00058cb1  85db                     test ebx, ebx
00058cb3  7422                     je 0x58cd7
00058cb5  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00058cbc  488b4770                 mov rax, qword ptr [rdi + 0x70]
00058cc0  893488                   mov dword ptr [rax + rcx*4], esi
00058cc3  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
00058cc7  4885c9                   test rcx, rcx
00058cca  740b                     je 0x58cd7
00058ccc  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
00058cd3  c6040800                 mov byte ptr [rax + rcx], 0
00058cd7  ff8788000000             inc dword ptr [rdi + 0x88]
00058cdd  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
00058ce2  e939f9ffff               jmp 0x58620
00058ce7  44387590                 cmp byte ptr [rbp - 0x70], r14b
00058ceb  7411                     je 0x58cfe
00058ced  4438742448               cmp byte ptr [rsp + 0x48], r14b
00058cf2  740a                     je 0x58cfe
00058cf4  44397710                 cmp dword ptr [rdi + 0x10], r14d
00058cf8  0f8d12ffffff             jge 0x58c10
00058cfe  f7471000000040           test dword ptr [rdi + 0x10], 0x40000000
00058d05  0f8435ffffff             je 0x58c40
00058d0b  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00058d0e  394738                   cmp dword ptr [rdi + 0x38], eax
00058d11  0f8529ffffff             jne 0x58c40
00058d17  4439b788000000           cmp dword ptr [rdi + 0x88], r14d
00058d1e  0f851cffffff             jne 0x58c40
00058d24  e9e7feffff               jmp 0x58c10
00058d29  488b4570                 mov rax, qword ptr [rbp + 0x70]
00058d2d  448930                   mov dword ptr [rax], r14d
00058d30  44397578                 cmp dword ptr [rbp + 0x78], r14d
00058d34  7412                     je 0x58d48
00058d36  44397708                 cmp dword ptr [rdi + 8], r14d
00058d3a  0f8400ffffff             je 0x58c40
00058d40  85d2                     test edx, edx
00058d42  0f85f8feffff             jne 0x58c40
00058d48  4c63475c                 movsxd r8, dword ptr [rdi + 0x5c]
00058d4c  418bcf                   mov ecx, r15d
00058d4f  4d03c0                   add r8, r8
00058d52  48c1e910                 shr rcx, 0x10
00058d56  418bc7                   mov eax, r15d
00058d59  48c1e020                 shl rax, 0x20
00058d5d  480bc1                   or rax, rcx
00058d60  488bc8                   mov rcx, rax
00058d63  48c1e820                 shr rax, 0x20
00058d67  6681e100ff               and cx, 0xff00
00058d6c  0fb7d1                   movzx edx, cx
00058d6f  0fb6c8                   movzx ecx, al
00058d72  488b4598                 mov rax, qword ptr [rbp - 0x68]
00058d76  480bd1                   or rdx, rcx
00058d79  488d4f3e                 lea rcx, [rdi + 0x3e]
00058d7d  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00058d84  8b1c90                   mov ebx, dword ptr [rax + rdx*4]
00058d87  488d573c                 lea rdx, [rdi + 0x3c]
00058d8b  e88f540000               call 0x5e21f
00058d90  488b442450               mov rax, qword ptr [rsp + 0x50]
00058d95  8344245c03               add dword ptr [rsp + 0x5c], 3
00058d9a  66895f3c                 mov word ptr [rdi + 0x3c], bx
00058d9e  c1eb10                   shr ebx, 0x10
00058da1  66895f3e                 mov word ptr [rdi + 0x3e], bx
00058da5  8b575c                   mov edx, dword ptr [rdi + 0x5c]
00058da8  c7476001000000           mov dword ptr [rdi + 0x60], 1
00058daf  ffc2                     inc edx
00058db1  89575c                   mov dword ptr [rdi + 0x5c], edx
00058db4  0fb74f3e                 movzx ecx, word ptr [rdi + 0x3e]
00058db8  488b4008                 mov rax, qword ptr [rax + 8]
00058dbc  807c880102               cmp byte ptr [rax + rcx*4 + 1], 2
00058dc1  4c8d3488                 lea r14, [rax + rcx*4]
00058dc5  755b                     jne 0x58e22
00058dc7  4c63c2                   movsxd r8, edx
00058dca  488d4f40                 lea rcx, [rdi + 0x40]
00058dce  4d03c0                   add r8, r8
00058dd1  488d573e                 lea rdx, [rdi + 0x3e]
00058dd5  e845540000               call 0x5e21f
00058dda  418b0e                   mov ecx, dword ptr [r14]
00058ddd  8bc1                     mov eax, ecx
00058ddf  48c1e910                 shr rcx, 0x10
00058de3  48c1e020                 shl rax, 0x20
00058de7  480bc1                   or rax, rcx
00058dea  488bc8                   mov rcx, rax
00058ded  48c1e820                 shr rax, 0x20
00058df1  6681e100ff               and cx, 0xff00
00058df6  0fb7d1                   movzx edx, cx
00058df9  0fb6c8                   movzx ecx, al
00058dfc  488b4598                 mov rax, qword ptr [rbp - 0x68]
00058e00  480bd1                   or rdx, rcx
00058e03  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00058e0a  8b0490                   mov eax, dword ptr [rax + rdx*4]
00058e0d  6689473e                 mov word ptr [rdi + 0x3e], ax
00058e11  c1e810                   shr eax, 0x10
00058e14  66894740                 mov word ptr [rdi + 0x40], ax
00058e18  ff475c                   inc dword ptr [rdi + 0x5c]
00058e1b  ff4760                   inc dword ptr [rdi + 0x60]
00058e1e  ff44245c                 inc dword ptr [rsp + 0x5c]
00058e22  41be01000000             mov r14d, 1
00058e28  e913feffff               jmp 0x58c40
00058e2d  807c244001               cmp byte ptr [rsp + 0x40], 1
00058e32  770f                     ja 0x58e43
00058e34  488b8588000000           mov rax, qword ptr [rbp + 0x88]
00058e3b  4885c0                   test rax, rax
00058e3e  7403                     je 0x58e43
00058e40  c60001                   mov byte ptr [rax], 1
00058e43  33db                     xor ebx, ebx
00058e45  418bc7                   mov eax, r15d
00058e48  48c1e810                 shr rax, 0x10
00058e4c  8bcb                     mov ecx, ebx
00058e4e  410fb7d7                 movzx edx, r15w
00058e52  48c1e220                 shl rdx, 0x20
00058e56  480bd0                   or rdx, rax
00058e59  395d88                   cmp dword ptr [rbp - 0x78], ebx
00058e5c  7440                     je 0x58e9e
00058e5e  488b4570                 mov rax, qword ptr [rbp + 0x70]
00058e62  448b00                   mov r8d, dword ptr [rax]
00058e65  410fb7c8                 movzx ecx, r8w
00058e69  418bc0                   mov eax, r8d
00058e6c  48c1e120                 shl rcx, 0x20
00058e70  48c1e810                 shr rax, 0x10
00058e74  480bc8                   or rcx, rax
00058e77  6641c1e808               shr r8w, 8
00058e7c  4180f822                 cmp r8b, 0x22
00058e80  741c                     je 0x58e9e
00058e82  399d80000000             cmp dword ptr [rbp + 0x80], ebx
00058e88  7414                     je 0x58e9e
00058e8a  4c638788000000           movsxd r8, dword ptr [rdi + 0x88]
00058e91  488b4770                 mov rax, qword ptr [rdi + 0x70]
00058e95  460fb74c80fc             movzx r9d, word ptr [rax + r8*4 - 4]
00058e9b  490bc9                   or rcx, r9
00058e9e  4c8bd2                   mov r10, rdx
00058ea1  895c2440                 mov dword ptr [rsp + 0x40], ebx
00058ea5  49c1ea20                 shr r10, 0x20
00058ea9  8bf3                     mov esi, ebx
00058eab  4180fa01                 cmp r10b, 1
00058eaf  0f879e000000             ja 0x58f53
00058eb5  4c8bc1                   mov r8, rcx
00058eb8  49c1e828                 shr r8, 0x28
00058ebc  4180f803                 cmp r8b, 3
00058ec0  770f                     ja 0x58ed1
00058ec2  48b800000000ffff0000     movabs rax, 0xffff00000000
00058ecc  e9dc000000               jmp 0x58fad
00058ed1  488bc1                   mov rax, rcx
00058ed4  48c1e810                 shr rax, 0x10
00058ed8  4180f822                 cmp r8b, 0x22
00058edc  7568                     jne 0x58f46
00058ede  4c8bc9                   mov r9, rcx
00058ee1  49c1e908                 shr r9, 8
00058ee5  450fb6c1                 movzx r8d, r9b
00058ee9  4180e0c6                 and r8b, 0xc6
00058eed  4488442440               mov byte ptr [rsp + 0x40], r8b
00058ef2  450fb6c1                 movzx r8d, r9b
00058ef6  4180e0e4                 and r8b, 0xe4
00058efa  4488442442               mov byte ptr [rsp + 0x42], r8b
00058eff  440fb7c2                 movzx r8d, dx
00058f03  4584d2                   test r10b, r10b
00058f06  751a                     jne 0x58f22
00058f08  48c1e010                 shl rax, 0x10
00058f0c  490bc0                   or rax, r8
00058f0f  c644244104               mov byte ptr [rsp + 0x41], 4
00058f14  4180e1c5                 and r9b, 0xc5
00058f18  44884c2443               mov byte ptr [rsp + 0x43], r9b
00058f1d  e97c000000               jmp 0x58f9e
00058f22  ba000087ff               mov edx, 0xff870000
00058f27  c644244105               mov byte ptr [rsp + 0x41], 5
00058f2c  4823c2                   and rax, rdx
00058f2f  48c1e010                 shl rax, 0x10
00058f33  490bc0                   or rax, r8
00058f36  488bd0                   mov rdx, rax
00058f39  48c1ea08                 shr rdx, 8
00058f3d  80e2c5                   and dl, 0xc5
00058f40  88542443                 mov byte ptr [rsp + 0x43], dl
00058f44  eb58                     jmp 0x58f9e
00058f46  440fb6c2                 movzx r8d, dl
00058f4a  48c1e010                 shl rax, 0x10
00058f4e  490bc0                   or rax, r8
00058f51  eb4f                     jmp 0x58fa2
00058f53  488bc2                   mov rax, rdx
00058f56  c644244103               mov byte ptr [rsp + 0x41], 3
00058f5b  48b9ffffffffff22ffff     movabs rcx, 0xffff22ffffffffff
00058f65  4823c1                   and rax, rcx
00058f68  48b90000000000220000     movabs rcx, 0x220000000000
00058f72  480bc1                   or rax, rcx
00058f75  4c8bc0                   mov r8, rax
00058f78  488bc8                   mov rcx, rax
00058f7b  49c1e808                 shr r8, 8
00058f7f  410fb6d0                 movzx edx, r8b
00058f83  80e2c6                   and dl, 0xc6
00058f86  88542440                 mov byte ptr [rsp + 0x40], dl
00058f8a  410fb6d0                 movzx edx, r8b
00058f8e  80e2e4                   and dl, 0xe4
00058f91  4180e0c5                 and r8b, 0xc5
00058f95  88542442                 mov byte ptr [rsp + 0x42], dl
00058f99  4488442443               mov byte ptr [rsp + 0x43], r8b
00058f9e  8b742440                 mov esi, dword ptr [rsp + 0x40]
00058fa2  4825ff02ffff             and rax, 0xffffffffffff02ff
00058fa8  480fbae809               bts rax, 9
00058fad  488bd0                   mov rdx, rax
00058fb0  48c1ea28                 shr rdx, 0x28
00058fb4  80fa22                   cmp dl, 0x22
00058fb7  740a                     je 0x58fc3
00058fb9  488bd0                   mov rdx, rax
00058fbc  48c1ea10                 shr rdx, 0x10
00058fc0  0fb7f2                   movzx esi, dx
00058fc3  488bd0                   mov rdx, rax
00058fc6  48c1e010                 shl rax, 0x10
00058fca  48c1ea20                 shr rdx, 0x20
00058fce  0bd0                     or edx, eax
00058fd0  89542440                 mov dword ptr [rsp + 0x40], edx
00058fd4  448bfa                   mov r15d, edx
00058fd7  80fa01                   cmp dl, 1
00058fda  0f8666fcffff             jbe 0x58c46
00058fe0  488bc1                   mov rax, rcx
00058fe3  48c1e110                 shl rcx, 0x10
00058fe7  48c1e820                 shr rax, 0x20
00058feb  0bc1                     or eax, ecx
00058fed  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00058ff1  8901                     mov dword ptr [rcx], eax
00058ff3  e952fcffff               jmp 0x58c4a
00058ff8  4c8d673c                 lea r12, [rdi + 0x3c]
00058ffc  b860110000               mov eax, 0x1160
00059001  6641390424               cmp word ptr [r12], ax
00059006  0f831f020000             jae 0x5922b
0005900c  8b475c                   mov eax, dword ptr [rdi + 0x5c]
0005900f  83f803                   cmp eax, 3
00059012  7d4d                     jge 0x59061
00059014  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00059018  4885c9                   test rcx, rcx
0005901b  7e44                     jle 0x59061
0005901d  488b4718                 mov rax, qword ptr [rdi + 0x18]
00059021  4885c0                   test rax, rax
00059024  740b                     je 0x59031
00059026  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0005902a  ffd0                     call rax
0005902c  0fb7c8                   movzx ecx, ax
0005902f  eb12                     jmp 0x59043
00059031  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
00059035  488b4728                 mov rax, qword ptr [rdi + 0x28]
00059039  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
0005903d  8d4201                   lea eax, [rdx + 1]
00059040  894738                   mov dword ptr [rdi + 0x38], eax
00059043  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00059047  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
0005904c  8b475c                   mov eax, dword ptr [rdi + 0x5c]
0005904f  48ff4f30                 dec qword ptr [rdi + 0x30]
00059053  ffc0                     inc eax
00059055  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00059059  89475c                   mov dword ptr [rdi + 0x5c], eax
0005905c  83f803                   cmp eax, 3
0005905f  7cb7                     jl 0x59018
00059061  488b4d98                 mov rcx, qword ptr [rbp - 0x68]
00059065  4c8d4c246c               lea r9, [rsp + 0x6c]
0005906a  0fbaf01f                 btr eax, 0x1f
0005906e  4c8965d0                 mov qword ptr [rbp - 0x30], r12
00059072  8945d8                   mov dword ptr [rbp - 0x28], eax
00059075  4c8d45d0                 lea r8, [rbp - 0x30]
00059079  488d458c                 lea rax, [rbp - 0x74]
0005907d  4c8965e8                 mov qword ptr [rbp - 0x18], r12
00059081  4889442430               mov qword ptr [rsp + 0x30], rax
00059086  4533ff                   xor r15d, r15d
00059089  488d442470               lea rax, [rsp + 0x70]
0005908e  c744242803000000         mov dword ptr [rsp + 0x28], 3
00059096  488bd3                   mov rdx, rbx
00059099  4889442420               mov qword ptr [rsp + 0x20], rax
0005909e  4c897de0                 mov qword ptr [rbp - 0x20], r15
000590a2  e8c986ffff               call 0x51770
000590a7  8bf0                     mov esi, eax
000590a9  85c0                     test eax, eax
000590ab  0f8e7a010000             jle 0x5922b
000590b1  0faee8                   lfence
000590b4  0fb744246c               movzx eax, word ptr [rsp + 0x6c]
000590b9  48639788000000           movsxd rdx, dword ptr [rdi + 0x88]
000590c0  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
000590c4  448b8580000000           mov r8d, dword ptr [rbp + 0x80]
000590cb  6689442478               mov word ptr [rsp + 0x78], ax
000590d0  66c744247a0202           mov word ptr [rsp + 0x7a], 0x202
000590d7  8b442478                 mov eax, dword ptr [rsp + 0x78]
000590db  890491                   mov dword ptr [rcx + rdx*4], eax
000590de  4585c0                   test r8d, r8d
000590e1  7423                     je 0x59106
000590e3  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000590ea  488b4770                 mov rax, qword ptr [rdi + 0x70]
000590ee  44893c88                 mov dword ptr [rax + rcx*4], r15d
000590f2  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
000590f6  4885c9                   test rcx, rcx
000590f9  740b                     je 0x59106
000590fb  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
00059102  44883408                 mov byte ptr [rax + rcx], r14b
00059106  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005910d  41b900ff0000             mov r9d, 0xff00
00059113  488bd1                   mov rdx, rcx
00059116  66c744247e0202           mov word ptr [rsp + 0x7e], 0x202
0005911d  8d4101                   lea eax, [rcx + 1]
00059120  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
00059124  898788000000             mov dword ptr [rdi + 0x88], eax
0005912a  0fb6442470               movzx eax, byte ptr [rsp + 0x70]
0005912f  66410bc1                 or ax, r9w
00059133  668944247c               mov word ptr [rsp + 0x7c], ax
00059138  8b44247c                 mov eax, dword ptr [rsp + 0x7c]
0005913c  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
00059140  4585c0                   test r8d, r8d
00059143  7423                     je 0x59168
00059145  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005914c  488b4770                 mov rax, qword ptr [rdi + 0x70]
00059150  44893c88                 mov dword ptr [rax + rcx*4], r15d
00059154  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
00059158  4885c9                   test rcx, rcx
0005915b  740b                     je 0x59168
0005915d  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
00059164  44883408                 mov byte ptr [rax + rcx], r14b
00059168  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005916f  488bd1                   mov rdx, rcx
00059172  66c745820202             mov word ptr [rbp - 0x7e], 0x202
00059178  8d4101                   lea eax, [rcx + 1]
0005917b  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
0005917f  898788000000             mov dword ptr [rdi + 0x88], eax
00059185  0fb6442471               movzx eax, byte ptr [rsp + 0x71]
0005918a  66410bc1                 or ax, r9w
0005918e  66894580                 mov word ptr [rbp - 0x80], ax
00059192  8b4580                   mov eax, dword ptr [rbp - 0x80]
00059195  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
00059199  4585c0                   test r8d, r8d
0005919c  7423                     je 0x591c1
0005919e  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000591a5  488b4770                 mov rax, qword ptr [rdi + 0x70]
000591a9  44893c88                 mov dword ptr [rax + rcx*4], r15d
000591ad  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
000591b1  4885c9                   test rcx, rcx
000591b4  740b                     je 0x591c1
000591b6  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
000591bd  44883408                 mov byte ptr [rax + rcx], r14b
000591c1  0fb6442472               movzx eax, byte ptr [rsp + 0x72]
000591c6  488d573c                 lea rdx, [rdi + 0x3c]
000591ca  ff8788000000             inc dword ptr [rdi + 0x88]
000591d0  66410bc1                 or ax, r9w
000591d4  66894584                 mov word ptr [rbp - 0x7c], ax
000591d8  ffce                     dec esi
000591da  4863c6                   movsxd rax, esi
000591dd  498bcc                   mov rcx, r12
000591e0  66c745860202             mov word ptr [rbp - 0x7a], 0x202
000591e6  448b7d84                 mov r15d, dword ptr [rbp - 0x7c]
000591ea  44897c2440               mov dword ptr [rsp + 0x40], r15d
000591ef  488d1c00                 lea rbx, [rax + rax]
000591f3  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000591f6  2bc6                     sub eax, esi
000591f8  4803d3                   add rdx, rbx
000591fb  4c63c0                   movsxd r8, eax
000591fe  4d03c0                   add r8, r8
00059201  e819500000               call 0x5e21f
00059206  29775c                   sub dword ptr [rdi + 0x5c], esi
00059209  420fb70c23               movzx ecx, word ptr [rbx + r12]
0005920e  33db                     xor ebx, ebx
00059210  488b442450               mov rax, qword ptr [rsp + 0x50]
00059215  8b742460                 mov esi, dword ptr [rsp + 0x60]
00059219  488b4008                 mov rax, qword ptr [rax + 8]
0005921d  8b1488                   mov edx, dword ptr [rax + rcx*4]
00059220  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00059224  8911                     mov dword ptr [rcx], edx
00059226  e91ffaffff               jmp 0x58c4a
0005922b  410fb70c24               movzx ecx, word ptr [r12]
00059230  488b4308                 mov rax, qword ptr [rbx + 8]
00059234  8b742460                 mov esi, dword ptr [rsp + 0x60]
00059238  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005923b  8bc2                     mov eax, edx
0005923d  c1e810                   shr eax, 0x10
00059240  0fb6c8                   movzx ecx, al
00059243  89542440                 mov dword ptr [rsp + 0x40], edx
00059247  c644244202               mov byte ptr [rsp + 0x42], 2
0005924c  0fb6c2                   movzx eax, dl
0005924f  66c1e008                 shl ax, 8
00059253  660bc8                   or cx, ax
00059256  66894c2440               mov word ptr [rsp + 0x40], cx
0005925b  33db                     xor ebx, ebx
0005925d  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00059261  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00059266  8911                     mov dword ptr [rcx], edx
00059268  e9ddf9ffff               jmp 0x58c4a
0005926d  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00059271  410fb6f7                 movzx esi, r15b
00059275  c1e608                   shl esi, 8
00059278  c7442440fffd0202         mov dword ptr [rsp + 0x40], 0x202fdff
00059280  448939                   mov dword ptr [rcx], r15d
00059283  0fb64102                 movzx eax, byte ptr [rcx + 2]
00059287  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
0005928c  0bf0                     or esi, eax
0005928e  33db                     xor ebx, ebx
00059290  e9b5f9ffff               jmp 0x58c4a
00059295  488b4570                 mov rax, qword ptr [rbp + 0x70]
00059299  410fb7cf                 movzx ecx, r15w
0005929d  48c1e120                 shl rcx, 0x20
000592a1  448938                   mov dword ptr [rax], r15d
000592a4  418bc7                   mov eax, r15d
000592a7  48c1e810                 shr rax, 0x10
000592ab  480bc8                   or rcx, rax
000592ae  488bc1                   mov rax, rcx
000592b1  440fb6c9                 movzx r9d, cl
000592b5  48c1e828                 shr rax, 0x28
000592b9  0440                     add al, 0x40
000592bb  3c30                     cmp al, 0x30
000592bd  7724                     ja 0x592e3
000592bf  448b03                   mov r8d, dword ptr [rbx]
000592c2  41b9ff030000             mov r9d, 0x3ff
000592c8  418bc0                   mov eax, r8d
000592cb  0fb6d1                   movzx edx, cl
000592ce  4123c1                   and eax, r9d
000592d1  83f804                   cmp eax, 4
000592d4  741a                     je 0x592f0
000592d6  440fb6c9                 movzx r9d, cl
000592da  4181f811040400           cmp r8d, 0x40411
000592e1  740d                     je 0x592f0
000592e3  410fb6d1                 movzx edx, r9b
000592e7  4584e4                   test r12b, r12b
000592ea  0f8450f9ffff             je 0x58c40
000592f0  48c1e908                 shr rcx, 8
000592f4  0fb6c2                   movzx eax, dl
000592f7  0fb6f1                   movzx esi, cl
000592fa  c1e008                   shl eax, 8
000592fd  0bf0                     or esi, eax
000592ff  e940f9ffff               jmp 0x58c44
00059304  4585ed                   test r13d, r13d
00059307  0f84f6010000             je 0x59503
0005930d  c644244801               mov byte ptr [rsp + 0x48], 1
00059312  8bc8                     mov ecx, eax
00059314  83f801                   cmp eax, 1
00059317  7d50                     jge 0x59369
00059319  488b4730                 mov rax, qword ptr [rdi + 0x30]
0005931d  0f1f00                   nop dword ptr [rax]
00059320  4885c0                   test rax, rax
00059323  7e44                     jle 0x59369
00059325  488b4718                 mov rax, qword ptr [rdi + 0x18]
00059329  4885c0                   test rax, rax
0005932c  740b                     je 0x59339
0005932e  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00059332  ffd0                     call rax
00059334  0fb7c8                   movzx ecx, ax
00059337  eb12                     jmp 0x5934b
00059339  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
0005933d  488b4728                 mov rax, qword ptr [rdi + 0x28]
00059341  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00059345  8d4201                   lea eax, [rdx + 1]
00059348  894738                   mov dword ptr [rdi + 0x38], eax
0005934b  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
0005934f  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00059354  8b4f5c                   mov ecx, dword ptr [rdi + 0x5c]
00059357  48ff4f30                 dec qword ptr [rdi + 0x30]
0005935b  ffc1                     inc ecx
0005935d  488b4730                 mov rax, qword ptr [rdi + 0x30]
00059361  894f5c                   mov dword ptr [rdi + 0x5c], ecx
00059364  83f901                   cmp ecx, 1
00059367  7cb7                     jl 0x59320
00059369  85c9                     test ecx, ecx
0005936b  0f848b010000             je 0x594fc
00059371  41b9f7ff0000             mov r9d, 0xfff7
00059377  6644394c2440             cmp word ptr [rsp + 0x40], r9w
0005937d  7527                     jne 0x593a6
0005937f  6641833e25               cmp word ptr [r14], 0x25
00059384  7520                     jne 0x593a6
00059386  8d41ff                   lea eax, [rcx - 1]
00059389  4c63c0                   movsxd r8, eax
0005938c  488d573e                 lea rdx, [rdi + 0x3e]
00059390  4d03c0                   add r8, r8
00059393  498bce                   mov rcx, r14
00059396  e8844e0000               call 0x5e21f
0005939b  ff4f5c                   dec dword ptr [rdi + 0x5c]
0005939e  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000593a1  e96cffffff               jmp 0x59312
000593a6  410fb706                 movzx eax, word ptr [r14]
000593aa  ba40db0000               mov edx, 0xdb40
000593af  663bc2                   cmp ax, dx
000593b2  757f                     jne 0x59433
000593b4  83f902                   cmp ecx, 2
000593b7  7d56                     jge 0x5940f
000593b9  488b4730                 mov rax, qword ptr [rdi + 0x30]
000593bd  0f1f00                   nop dword ptr [rax]
000593c0  4885c0                   test rax, rax
000593c3  7e44                     jle 0x59409
000593c5  488b4718                 mov rax, qword ptr [rdi + 0x18]
000593c9  4885c0                   test rax, rax
000593cc  740b                     je 0x593d9
000593ce  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000593d2  ffd0                     call rax
000593d4  0fb7c8                   movzx ecx, ax
000593d7  eb12                     jmp 0x593eb
000593d9  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000593dd  488b4728                 mov rax, qword ptr [rdi + 0x28]
000593e1  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
000593e5  8d4201                   lea eax, [rdx + 1]
000593e8  894738                   mov dword ptr [rdi + 0x38], eax
000593eb  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
000593ef  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
000593f4  8b4f5c                   mov ecx, dword ptr [rdi + 0x5c]
000593f7  48ff4f30                 dec qword ptr [rdi + 0x30]
000593fb  ffc1                     inc ecx
000593fd  488b4730                 mov rax, qword ptr [rdi + 0x30]
00059401  894f5c                   mov dword ptr [rdi + 0x5c], ecx
00059404  83f902                   cmp ecx, 2
00059407  7cb7                     jl 0x593c0
00059409  41b9f7ff0000             mov r9d, 0xfff7
0005940f  83f901                   cmp ecx, 1
00059412  7e1b                     jle 0x5942f
00059414  0fb7573e                 movzx edx, word ptr [rdi + 0x3e]
00059418  b800230000               mov eax, 0x2300
0005941d  03c2                     add eax, edx
0005941f  41b8ef000000             mov r8d, 0xef
00059425  66413bc0                 cmp ax, r8w
00059429  0f868e000000             jbe 0x594bd
0005942f  410fb706                 movzx eax, word ptr [r14]
00059433  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00059438  440fb7c0                 movzx r8d, ax
0005943c  498b4208                 mov rax, qword ptr [r10 + 8]
00059440  428b1480                 mov edx, dword ptr [rax + r8*4]
00059444  8bc2                     mov eax, edx
00059446  c1e810                   shr eax, 0x10
00059449  66c1ea08                 shr dx, 8
0005944d  84d2                     test dl, dl
0005944f  753b                     jne 0x5948c
00059451  38542468                 cmp byte ptr [rsp + 0x68], dl
00059455  0f84a1000000             je 0x594fc
0005945b  b800280000               mov eax, 0x2800
00059460  664403c0                 add r8w, ax
00059464  b8ff030000               mov eax, 0x3ff
00059469  66443bc0                 cmp r8w, ax
0005946d  0f8789000000             ja 0x594fc
00059473  4c8d4da8                 lea r9, [rbp - 0x58]
00059477  4c8bc7                   mov r8, rdi
0005947a  498bd2                   mov rdx, r10
0005947d  e8fe55ffff               call 0x4ea80
00059482  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00059485  ffc8                     dec eax
00059487  e9fdfeffff               jmp 0x59389
0005948c  80fa01                   cmp dl, 1
0005948f  756b                     jne 0x594fc
00059491  6644394c2440             cmp word ptr [rsp + 0x40], r9w
00059497  0f83e9feffff             jae 0x59386
0005949d  0fb6d0                   movzx edx, al
000594a0  0fb6442442               movzx eax, byte ptr [rsp + 0x42]
000594a5  6603d0                   add dx, ax
000594a8  b8ff000000               mov eax, 0xff
000594ad  663bd0                   cmp dx, ax
000594b0  7602                     jbe 0x594b4
000594b2  8bd0                     mov edx, eax
000594b4  88542442                 mov byte ptr [rsp + 0x42], dl
000594b8  e9c9feffff               jmp 0x59386
000594bd  807d9400                 cmp byte ptr [rbp - 0x6c], 0
000594c1  7507                     jne 0x594ca
000594c3  8d4202                   lea eax, [rdx + 2]
000594c6  88442458                 mov byte ptr [rsp + 0x58], al
000594ca  8d41ff                   lea eax, [rcx - 1]
000594cd  498bce                   mov rcx, r14
000594d0  4c63c0                   movsxd r8, eax
000594d3  488d573e                 lea rdx, [rdi + 0x3e]
000594d7  4d03c0                   add r8, r8
000594da  e8404d0000               call 0x5e21f
000594df  ff4f5c                   dec dword ptr [rdi + 0x5c]
000594e2  488d573e                 lea rdx, [rdi + 0x3e]
000594e6  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000594e9  498bce                   mov rcx, r14
000594ec  ffc8                     dec eax
000594ee  4c63c0                   movsxd r8, eax
000594f1  4d03c0                   add r8, r8
000594f4  e8264d0000               call 0x5e21f
000594f9  ff4f5c                   dec dword ptr [rdi + 0x5c]
000594fc  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00059501  eb05                     jmp 0x59508
00059503  c644244800               mov byte ptr [rsp + 0x48], 0
00059508  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005950f  488b4768                 mov rax, qword ptr [rdi + 0x68]
00059513  44893c88                 mov dword ptr [rax + rcx*4], r15d
00059517  85db                     test ebx, ebx
00059519  7426                     je 0x59541
0005951b  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00059522  488b4770                 mov rax, qword ptr [rdi + 0x70]
00059526  893488                   mov dword ptr [rax + rcx*4], esi
00059529  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
0005952d  4885c9                   test rcx, rcx
00059530  740f                     je 0x59541
00059532  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
00059539  0fb6542458               movzx edx, byte ptr [rsp + 0x58]
0005953e  881408                   mov byte ptr [rax + rcx], dl
00059541  ff8788000000             inc dword ptr [rdi + 0x88]
00059547  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
0005954c  4585db                   test r11d, r11d
0005954f  0f85cbf0ffff             jne 0x58620
00059555  33c0                     xor eax, eax
00059557  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
0005955b  4833cc                   xor rcx, rsp
0005955e  e86d380000               call 0x5cdd0
00059563  4c8d9c2420010000         lea r11, [rsp + 0x120]
0005956b  498b5b30                 mov rbx, qword ptr [r11 + 0x30]
0005956f  498b7338                 mov rsi, qword ptr [r11 + 0x38]
00059573  498b7b40                 mov rdi, qword ptr [r11 + 0x40]
00059577  498be3                   mov rsp, r11
0005957a  415f                     pop r15
0005957c  415e                     pop r14
0005957e  415d                     pop r13
00059580  415c                     pop r12
00059582  5d                       pop rbp
00059583  c3                       ret
00059584  b803000000               mov eax, 3
00059589  ebcc                     jmp 0x59557
0005958b  b802000000               mov eax, 2
00059590  ebc5                     jmp 0x59557
00059592  4585db                   test r11d, r11d
00059595  741a                     je 0x595b1
00059597  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005959e  bafbff0000               mov edx, 0xfffb
000595a3  488b4768                 mov rax, qword ptr [rdi + 0x68]
000595a7  66891488                 mov word ptr [rax + rcx*4], dx
000595ab  ff8788000000             inc dword ptr [rdi + 0x88]
000595b1  8b8f88000000             mov ecx, dword ptr [rdi + 0x88]
000595b7  3b8f84000000             cmp ecx, dword ptr [rdi + 0x84]
000595bd  7596                     jne 0x59555
000595bf  f7471000000008           test dword ptr [rdi + 0x10], 0x8000000
000595c6  743b                     je 0x59603
000595c8  498b4208                 mov rax, qword ptr [r10 + 8]
000595cc  4863d1                   movsxd rdx, ecx
000595cf  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
000595d3  8b8080000000             mov eax, dword ptr [rax + 0x80]
000595d9  890491                   mov dword ptr [rcx + rdx*4], eax
000595dc  85db                     test ebx, ebx
000595de  7423                     je 0x59603
000595e0  48639788000000           movsxd rdx, dword ptr [rdi + 0x88]
000595e7  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
000595eb  44892491                 mov dword ptr [rcx + rdx*4], r12d
000595ef  488b5778                 mov rdx, qword ptr [rdi + 0x78]
000595f3  4885d2                   test rdx, rdx
000595f6  740b                     je 0x59603
000595f8  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000595ff  c6041100                 mov byte ptr [rcx + rdx], 0
00059603  b801000000               mov eax, 1
00059608  e94affffff               jmp 0x59557
0005960d  0f1f00                   nop dword ptr [rax]
00059610  a28b05005a8b0500c6       movabs byte ptr [0xc600058b5a00058b], al
00059619  8a0500fb8a05             mov al, byte ptr [rip + 0x58afb00]
0005961f  0026                     add byte ptr [rsi], ah
00059621  8b0500bb8b05             mov eax, dword ptr [rip + 0x58bbb00]
00059627  00d9                     add cl, bl
00059629  8b0500000606             mov eax, dword ptr [rip + 0x6060000]
