; std::unique_ptr<CAEEncryptionProvider,MemObjDeleter>::~unique_ptr<CAEEncryptionProvider,MemObjDeleter>
; aetm_enclave.dll, primary RVA 0x10080, 112 bytes in 1 chunk(s)

; chunk at RVA 0x10080 (112 bytes)
00010080  4057                     push rdi
00010082  4883ec30                 sub rsp, 0x30
00010086  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0001008f  48895c2440               mov qword ptr [rsp + 0x40], rbx
00010094  488bf9                   mov rdi, rcx
00010097  488b5908                 mov rbx, qword ptr [rcx + 8]
0001009b  4885db                   test rbx, rbx
0001009e  7445                     je 0x100e5
000100a0  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
000100a4  4885c9                   test rcx, rcx
000100a7  7413                     je 0x100bc
000100a9  488b01                   mov rax, qword ptr [rcx]
000100ac  ba01000000               mov edx, 1
000100b1  ff5010                   call qword ptr [rax + 0x10]
000100b4  48c7437000000000         mov qword ptr [rbx + 0x70], 0
000100bc  488b4b78                 mov rcx, qword ptr [rbx + 0x78]
000100c0  4885c9                   test rcx, rcx
000100c3  7413                     je 0x100d8
000100c5  488b01                   mov rax, qword ptr [rcx]
000100c8  ba01000000               mov edx, 1
000100cd  ff5010                   call qword ptr [rax + 0x10]
000100d0  48c7437800000000         mov qword ptr [rbx + 0x78], 0
000100d8  488b0f                   mov rcx, qword ptr [rdi]
000100db  488b01                   mov rax, qword ptr [rcx]
000100de  488bd3                   mov rdx, rbx
000100e1  ff5028                   call qword ptr [rax + 0x28]
000100e4  90                       nop
000100e5  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
000100ea  4883c430                 add rsp, 0x30
000100ee  5f                       pop rdi
000100ef  c3                       ret
