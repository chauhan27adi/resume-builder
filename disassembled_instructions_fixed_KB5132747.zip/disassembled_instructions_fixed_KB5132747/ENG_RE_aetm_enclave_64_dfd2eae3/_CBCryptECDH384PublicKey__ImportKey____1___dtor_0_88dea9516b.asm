; `CBCryptECDH384PublicKey::ImportKey'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x61510, 38 bytes in 1 chunk(s)

; chunk at RVA 0x61510 (38 bytes)
00061510  4055                     push rbp
00061512  4883ec20                 sub rsp, 0x20
00061516  488bea                   mov rbp, rdx
00061519  8b4540                   mov eax, dword ptr [rbp + 0x40]
0006151c  83e001                   and eax, 1
0006151f  85c0                     test eax, eax
00061521  740d                     je 0x61530
00061523  836540fe                 and dword ptr [rbp + 0x40], 0xfffffffe
00061527  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
0006152b  e8f078fbff               call 0x18e20
00061530  4883c420                 add rsp, 0x20
00061534  5d                       pop rbp
00061535  c3                       ret
