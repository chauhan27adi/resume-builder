; CTrustedMachine::GetPrimaryDBFromReplicaDB
; aetm_enclave.dll, primary RVA 0xd320, 543 bytes in 1 chunk(s)

; chunk at RVA 0xd320 (543 bytes)
0000d320  4055                     push rbp
0000d322  56                       push rsi
0000d323  57                       push rdi
0000d324  4883ec40                 sub rsp, 0x40
0000d328  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0000d331  48895c2468               mov qword ptr [rsp + 0x68], rbx
0000d336  8bfa                     mov edi, edx
0000d338  488d99d87a5800           lea rbx, [rcx + 0x587ad8]
0000d33f  488bc3                   mov rax, rbx
0000d342  4c8d8b00300000           lea r9, [rbx + 0x3000]
0000d349  33f6                     xor esi, esi
0000d34b  493bd9                   cmp rbx, r9
0000d34e  7332                     jae 0xd382
0000d350  4889742460               mov qword ptr [rsp + 0x60], rsi
0000d355  4889442460               mov qword ptr [rsp + 0x60], rax
0000d35a  f048ff4008               lock inc qword ptr [rax + 8]
0000d35f  90                       nop
0000d360  0fb64810                 movzx ecx, byte ptr [rax + 0x10]
0000d364  84c9                     test cl, cl
0000d366  7515                     jne 0xd37d
0000d368  4883c018                 add rax, 0x18
0000d36c  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
0000d371  f048ff4908               lock dec qword ptr [rcx + 8]
0000d376  493bc1                   cmp rax, r9
0000d379  72d5                     jb 0xd350
0000d37b  eb05                     jmp 0xd382
0000d37d  f048ff4808               lock dec qword ptr [rax + 8]
0000d382  48bdabaaaaaaaaaaaaaa     movabs rbp, 0xaaaaaaaaaaaaaaab
0000d38c  0f1f4000                 nop dword ptr [rax]
0000d390  493bc1                   cmp rax, r9
0000d393  0f847f010000             je 0xd518
0000d399  48895c2428               mov qword ptr [rsp + 0x28], rbx
0000d39e  4889742470               mov qword ptr [rsp + 0x70], rsi
0000d3a3  4889442470               mov qword ptr [rsp + 0x70], rax
0000d3a8  f048ff4008               lock inc qword ptr [rax + 8]
0000d3ad  90                       nop
0000d3ae  0fb64810                 movzx ecx, byte ptr [rax + 0x10]
0000d3b2  488bd0                   mov rdx, rax
0000d3b5  482bd3                   sub rdx, rbx
0000d3b8  48c1fa03                 sar rdx, 3
0000d3bc  480fafd5                 imul rdx, rbp
0000d3c0  90                       nop
0000d3c1  488b4808                 mov rcx, qword ptr [rax + 8]
0000d3c5  4c63c2                   movsxd r8, edx
0000d3c8  49c1e020                 shl r8, 0x20
0000d3cc  48c1e920                 shr rcx, 0x20
0000d3d0  4c0bc1                   or r8, rcx
0000d3d3  f048ff4808               lock dec qword ptr [rax + 8]
0000d3d8  4c89442430               mov qword ptr [rsp + 0x30], r8
0000d3dd  0faee8                   lfence
0000d3e0  49c1e820                 shr r8, 0x20
0000d3e4  4181e0ff010000           and r8d, 0x1ff
0000d3eb  4b8d1440                 lea rdx, [r8 + r8*2]
0000d3ef  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
0000d3f4  f048ff44d108             lock inc qword ptr [rcx + rdx*8 + 8]
0000d3fa  4c8b5c2430               mov r11, qword ptr [rsp + 0x30]
0000d3ff  4d8bc3                   mov r8, r11
0000d402  49c1e820                 shr r8, 0x20
0000d406  498bc8                   mov rcx, r8
0000d409  81e1ff010000             and ecx, 0x1ff
0000d40f  488d1449                 lea rdx, [rcx + rcx*2]
0000d413  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
0000d418  4c8d14d1                 lea r10, [rcx + rdx*8]
0000d41c  90                       nop
0000d41d  410fb65210               movzx edx, byte ptr [r10 + 0x10]
0000d422  90                       nop
0000d423  498b4a08                 mov rcx, qword ptr [r10 + 8]
0000d427  48c1e920                 shr rcx, 0x20
0000d42b  413bcb                   cmp ecx, r11d
0000d42e  7543                     jne 0xd473
0000d430  84d2                     test dl, dl
0000d432  743f                     je 0xd473
0000d434  90                       nop
0000d435  410fb65211               movzx edx, byte ptr [r10 + 0x11]
0000d43a  90                       nop
0000d43b  498b4a08                 mov rcx, qword ptr [r10 + 8]
0000d43f  48c1e920                 shr rcx, 0x20
0000d443  413bcb                   cmp ecx, r11d
0000d446  0f85db000000             jne 0xd527
0000d44c  84d2                     test dl, dl
0000d44e  0f84d3000000             je 0xd527
0000d454  4181e0ff010000           and r8d, 0x1ff
0000d45b  4b8d1440                 lea rdx, [r8 + r8*2]
0000d45f  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
0000d464  4c8d04d1                 lea r8, [rcx + rdx*8]
0000d468  41397804                 cmp dword ptr [r8 + 4], edi
0000d46c  7479                     je 0xd4e7
0000d46e  0faee8                   lfence
0000d471  eb17                     jmp 0xd48a
0000d473  0faee8                   lfence
0000d476  4181e0ff010000           and r8d, 0x1ff
0000d47d  4b8d1440                 lea rdx, [r8 + r8*2]
0000d481  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
0000d486  4c8d04d1                 lea r8, [rcx + rdx*8]
0000d48a  f049ff4808               lock dec qword ptr [r8 + 8]
0000d48f  493bc1                   cmp rax, r9
0000d492  0f83fbfeffff             jae 0xd393
0000d498  4883c018                 add rax, 0x18
0000d49c  493bc1                   cmp rax, r9
0000d49f  0f83eefeffff             jae 0xd393
0000d4a5  6666660f1f840000000000   nop word ptr [rax + rax]
0000d4b0  4889742478               mov qword ptr [rsp + 0x78], rsi
0000d4b5  4889442478               mov qword ptr [rsp + 0x78], rax
0000d4ba  488d5008                 lea rdx, [rax + 8]
0000d4be  f048ff02                 lock inc qword ptr [rdx]
0000d4c2  90                       nop
0000d4c3  0fb64810                 movzx ecx, byte ptr [rax + 0x10]
0000d4c7  84c9                     test cl, cl
0000d4c9  7512                     jne 0xd4dd
0000d4cb  4883c018                 add rax, 0x18
0000d4cf  f048ff0a                 lock dec qword ptr [rdx]
0000d4d3  493bc1                   cmp rax, r9
0000d4d6  72d8                     jb 0xd4b0
0000d4d8  e9b3feffff               jmp 0xd390
0000d4dd  f048ff4808               lock dec qword ptr [rax + 8]
0000d4e2  e9a9feffff               jmp 0xd390
0000d4e7  418b00                   mov eax, dword ptr [r8]
0000d4ea  488b4c2430               mov rcx, qword ptr [rsp + 0x30]
0000d4ef  48c1e920                 shr rcx, 0x20
0000d4f3  0faee8                   lfence
0000d4f6  81e1ff010000             and ecx, 0x1ff
0000d4fc  488d1449                 lea rdx, [rcx + rcx*2]
0000d500  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
0000d505  f048ff4cd108             lock dec qword ptr [rcx + rdx*8 + 8]
0000d50b  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0000d510  4883c440                 add rsp, 0x40
0000d514  5f                       pop rdi
0000d515  5e                       pop rsi
0000d516  5d                       pop rbp
0000d517  c3                       ret
0000d518  33c0                     xor eax, eax
0000d51a  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0000d51f  4883c440                 add rsp, 0x40
0000d523  5f                       pop rdi
0000d524  5e                       pop rsi
0000d525  5d                       pop rbp
0000d526  c3                       ret
0000d527  ba5f000000               mov edx, 0x5f
0000d52c  448d4aa2                 lea r9d, [rdx - 0x5e]
0000d530  448d42b2                 lea r8d, [rdx - 0x4e]
0000d534  b94b010000               mov ecx, 0x14b
0000d539  e862be0000               call 0x193a0
0000d53e  cc                       int3
