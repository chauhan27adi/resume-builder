; CSqlSortManager_100::PerformCompression<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x55e30, 1480 bytes in 1 chunk(s)

; chunk at RVA 0x55e30 (1480 bytes)
00055e30  48895c2410               mov qword ptr [rsp + 0x10], rbx
00055e35  48896c2418               mov qword ptr [rsp + 0x18], rbp
00055e3a  4889742420               mov qword ptr [rsp + 0x20], rsi
00055e3f  48894c2408               mov qword ptr [rsp + 8], rcx
00055e44  57                       push rdi
00055e45  4156                     push r14
00055e47  4157                     push r15
00055e49  4883ec20                 sub rsp, 0x20
00055e4d  8b7208                   mov esi, dword ptr [rdx + 8]
00055e50  4d8bf9                   mov r15, r9
00055e53  4c8b32                   mov r14, qword ptr [rdx]
00055e56  498bd8                   mov rbx, r8
00055e59  4d8bd6                   mov r10, r14
00055e5c  488bfa                   mov rdi, rdx
00055e5f  448bde                   mov r11d, esi
00055e62  83fe02                   cmp esi, 2
00055e65  0f8279040000             jb 0x562e4
00055e6b  33ed                     xor ebp, ebp
00055e6d  41396818                 cmp dword ptr [r8 + 0x18], ebp
00055e71  742e                     je 0x55ea1
00055e73  83fe03                   cmp esi, 3
00055e76  7229                     jb 0x55ea1
00055e78  4d8b4008                 mov r8, qword ptr [r8 + 8]
00055e7c  410fb70e                 movzx ecx, word ptr [r14]
00055e80  410fb74602               movzx eax, word ptr [r14 + 2]
00055e85  418b1488                 mov edx, dword ptr [r8 + rcx*4]
00055e89  41331480                 xor edx, dword ptr [r8 + rax*4]
00055e8d  f7c2ffffffe7             test edx, 0xe7ffffff
00055e93  750c                     jne 0x55ea1
00055e95  bd01000000               mov ebp, 1
00055e9a  4d8d5602                 lea r10, [r14 + 2]
00055e9e  41ffcb                   dec r11d
00055ea1  418b01                   mov eax, dword ptr [r9]
00055ea4  33d2                     xor edx, edx
00055ea6  488b5b30                 mov rbx, qword ptr [rbx + 0x30]
00055eaa  48c1e808                 shr rax, 8
00055eae  0fb6c8                   movzx ecx, al
00055eb1  48c1e906                 shr rcx, 6
00055eb5  c744244000080203         mov dword ptr [rsp + 0x40], 0x3020800
00055ebd  0fb6440c40               movzx eax, byte ptr [rsp + rcx + 0x40]
00055ec2  413bc3                   cmp eax, r11d
00055ec5  440f46d8                 cmovbe r11d, eax
00055ec9  4183c3fe                 add r11d, -2
00055ecd  4183fb06                 cmp r11d, 6
00055ed1  0f870d040000             ja 0x562e4
00055ed7  4c8d0522a1faff           lea r8, [rip - 0x55ede]
00055ede  438b8c98dc630500         mov ecx, dword ptr [r8 + r11*4 + 0x563dc]
00055ee6  4903c8                   add rcx, r8
00055ee9  ffe1                     jmp rcx
00055eeb  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00055eef  4d85db                   test r11, r11
00055ef2  743d                     je 0x55f31
00055ef4  498bd2                   mov rdx, r10
00055ef7  e814b4feff               call 0x41310
00055efc  33d2                     xor edx, edx
00055efe  41f77308                 div dword ptr [r11 + 8]
00055f02  8bca                     mov ecx, edx
00055f04  48c1e105                 shl rcx, 5
00055f08  49030b                   add rcx, qword ptr [r11]
00055f0b  7422                     je 0x55f2f
00055f0d  0f1f00                   nop dword ptr [rax]
00055f10  488b410c                 mov rax, qword ptr [rcx + 0xc]
00055f14  493b02                   cmp rax, qword ptr [r10]
00055f17  750e                     jne 0x55f27
00055f19  488b4114                 mov rax, qword ptr [rcx + 0x14]
00055f1d  493b4208                 cmp rax, qword ptr [r10 + 8]
00055f21  0f84d8030000             je 0x562ff
00055f27  488b09                   mov rcx, qword ptr [rcx]
00055f2a  4885c9                   test rcx, rcx
00055f2d  75e1                     jne 0x55f10
00055f2f  33d2                     xor edx, edx
00055f31  4c8b4b28                 mov r9, qword ptr [rbx + 0x28]
00055f35  4d85c9                   test r9, r9
00055f38  0f84dd000000             je 0x5601b
00055f3e  450fb702                 movzx r8d, word ptr [r10]
00055f42  410fb7520a               movzx edx, word ptr [r10 + 0xa]
00055f47  418bc0                   mov eax, r8d
00055f4a  c1e802                   shr eax, 2
00055f4d  4169c820080000           imul ecx, r8d, 0x820
00055f54  03c8                     add ecx, eax
00055f56  410fb74202               movzx eax, word ptr [r10 + 2]
00055f5b  03c8                     add ecx, eax
00055f5d  4433c1                   xor r8d, ecx
00055f60  410fb74a04               movzx ecx, word ptr [r10 + 4]
00055f65  4169c020080000           imul eax, r8d, 0x820
00055f6c  03c8                     add ecx, eax
00055f6e  418bc0                   mov eax, r8d
00055f71  c1e802                   shr eax, 2
00055f74  03c8                     add ecx, eax
00055f76  4433c1                   xor r8d, ecx
00055f79  410fb74a06               movzx ecx, word ptr [r10 + 6]
00055f7e  4169c020080000           imul eax, r8d, 0x820
00055f85  03c8                     add ecx, eax
00055f87  418bc0                   mov eax, r8d
00055f8a  c1e802                   shr eax, 2
00055f8d  03c8                     add ecx, eax
00055f8f  4433c1                   xor r8d, ecx
00055f92  410fb74a08               movzx ecx, word ptr [r10 + 8]
00055f97  4169c020080000           imul eax, r8d, 0x820
00055f9e  03c8                     add ecx, eax
00055fa0  418bc0                   mov eax, r8d
00055fa3  c1e802                   shr eax, 2
00055fa6  03c8                     add ecx, eax
00055fa8  4433c1                   xor r8d, ecx
00055fab  4169c020080000           imul eax, r8d, 0x820
00055fb2  418bc8                   mov ecx, r8d
00055fb5  c1e902                   shr ecx, 2
00055fb8  03d0                     add edx, eax
00055fba  03d1                     add edx, ecx
00055fbc  4433c2                   xor r8d, edx
00055fbf  410fb7520c               movzx edx, word ptr [r10 + 0xc]
00055fc4  4169c020080000           imul eax, r8d, 0x820
00055fcb  418bc8                   mov ecx, r8d
00055fce  c1e902                   shr ecx, 2
00055fd1  03c2                     add eax, edx
00055fd3  33d2                     xor edx, edx
00055fd5  03c1                     add eax, ecx
00055fd7  4133c0                   xor eax, r8d
00055fda  41f77108                 div dword ptr [r9 + 8]
00055fde  8bca                     mov ecx, edx
00055fe0  48c1e105                 shl rcx, 5
00055fe4  490309                   add rcx, qword ptr [r9]
00055fe7  7430                     je 0x56019
00055fe9  0f1f8000000000           nop dword ptr [rax]
00055ff0  488b410c                 mov rax, qword ptr [rcx + 0xc]
00055ff4  493b02                   cmp rax, qword ptr [r10]
00055ff7  7518                     jne 0x56011
00055ff9  8b4114                   mov eax, dword ptr [rcx + 0x14]
00055ffc  413b4208                 cmp eax, dword ptr [r10 + 8]
00056000  750f                     jne 0x56011
00056002  0fb74118                 movzx eax, word ptr [rcx + 0x18]
00056006  66413b420c               cmp ax, word ptr [r10 + 0xc]
0005600b  0f8400030000             je 0x56311
00056011  488b09                   mov rcx, qword ptr [rcx]
00056014  4885c9                   test rcx, rcx
00056017  75d7                     jne 0x55ff0
00056019  33d2                     xor edx, edx
0005601b  4c8b4b20                 mov r9, qword ptr [rbx + 0x20]
0005601f  4d85c9                   test r9, r9
00056022  0f84b8000000             je 0x560e0
00056028  450fb702                 movzx r8d, word ptr [r10]
0005602c  410fb75208               movzx edx, word ptr [r10 + 8]
00056031  418bc0                   mov eax, r8d
00056034  c1e802                   shr eax, 2
00056037  4169c820080000           imul ecx, r8d, 0x820
0005603e  03c8                     add ecx, eax
00056040  410fb74202               movzx eax, word ptr [r10 + 2]
00056045  03c8                     add ecx, eax
00056047  4433c1                   xor r8d, ecx
0005604a  410fb74a04               movzx ecx, word ptr [r10 + 4]
0005604f  4169c020080000           imul eax, r8d, 0x820
00056056  03c8                     add ecx, eax
00056058  418bc0                   mov eax, r8d
0005605b  c1e802                   shr eax, 2
0005605e  03c8                     add ecx, eax
00056060  4433c1                   xor r8d, ecx
00056063  410fb74a06               movzx ecx, word ptr [r10 + 6]
00056068  4169c020080000           imul eax, r8d, 0x820
0005606f  03c8                     add ecx, eax
00056071  418bc0                   mov eax, r8d
00056074  c1e802                   shr eax, 2
00056077  03c8                     add ecx, eax
00056079  4433c1                   xor r8d, ecx
0005607c  4169c020080000           imul eax, r8d, 0x820
00056083  418bc8                   mov ecx, r8d
00056086  c1e902                   shr ecx, 2
00056089  03d0                     add edx, eax
0005608b  03d1                     add edx, ecx
0005608d  4433c2                   xor r8d, edx
00056090  410fb7520a               movzx edx, word ptr [r10 + 0xa]
00056095  4169c020080000           imul eax, r8d, 0x820
0005609c  418bc8                   mov ecx, r8d
0005609f  c1e902                   shr ecx, 2
000560a2  03c2                     add eax, edx
000560a4  33d2                     xor edx, edx
000560a6  03c1                     add eax, ecx
000560a8  4133c0                   xor eax, r8d
000560ab  41f77108                 div dword ptr [r9 + 8]
000560af  498b01                   mov rax, qword ptr [r9]
000560b2  488d1452                 lea rdx, [rdx + rdx*2]
000560b6  488d0cd0                 lea rcx, [rax + rdx*8]
000560ba  4885c9                   test rcx, rcx
000560bd  741f                     je 0x560de
000560bf  90                       nop
000560c0  488b410c                 mov rax, qword ptr [rcx + 0xc]
000560c4  493b02                   cmp rax, qword ptr [r10]
000560c7  750d                     jne 0x560d6
000560c9  8b4114                   mov eax, dword ptr [rcx + 0x14]
000560cc  413b4208                 cmp eax, dword ptr [r10 + 8]
000560d0  0f844d020000             je 0x56323
000560d6  488b09                   mov rcx, qword ptr [rcx]
000560d9  4885c9                   test rcx, rcx
000560dc  75e2                     jne 0x560c0
000560de  33d2                     xor edx, edx
000560e0  4c8b4b18                 mov r9, qword ptr [rbx + 0x18]
000560e4  4d85c9                   test r9, r9
000560e7  0f84a5000000             je 0x56192
000560ed  450fb702                 movzx r8d, word ptr [r10]
000560f1  410fb74a02               movzx ecx, word ptr [r10 + 2]
000560f6  410fb75206               movzx edx, word ptr [r10 + 6]
000560fb  4169c020080000           imul eax, r8d, 0x820
00056102  03c8                     add ecx, eax
00056104  418bc0                   mov eax, r8d
00056107  c1e802                   shr eax, 2
0005610a  03c8                     add ecx, eax
0005610c  4433c1                   xor r8d, ecx
0005610f  410fb74a04               movzx ecx, word ptr [r10 + 4]
00056114  4169c020080000           imul eax, r8d, 0x820
0005611b  03c8                     add ecx, eax
0005611d  418bc0                   mov eax, r8d
00056120  c1e802                   shr eax, 2
00056123  03c8                     add ecx, eax
00056125  4433c1                   xor r8d, ecx
00056128  4169c020080000           imul eax, r8d, 0x820
0005612f  418bc8                   mov ecx, r8d
00056132  c1e902                   shr ecx, 2
00056135  03d0                     add edx, eax
00056137  03d1                     add edx, ecx
00056139  4433c2                   xor r8d, edx
0005613c  410fb75208               movzx edx, word ptr [r10 + 8]
00056141  4169c020080000           imul eax, r8d, 0x820
00056148  418bc8                   mov ecx, r8d
0005614b  c1e902                   shr ecx, 2
0005614e  03c2                     add eax, edx
00056150  33d2                     xor edx, edx
00056152  03c1                     add eax, ecx
00056154  4133c0                   xor eax, r8d
00056157  41f77108                 div dword ptr [r9 + 8]
0005615b  498b01                   mov rax, qword ptr [r9]
0005615e  488d1452                 lea rdx, [rdx + rdx*2]
00056162  488d0cd0                 lea rcx, [rax + rdx*8]
00056166  4885c9                   test rcx, rcx
00056169  7425                     je 0x56190
0005616b  0f1f440000               nop dword ptr [rax + rax]
00056170  488b410c                 mov rax, qword ptr [rcx + 0xc]
00056174  493b02                   cmp rax, qword ptr [r10]
00056177  750f                     jne 0x56188
00056179  0fb74114                 movzx eax, word ptr [rcx + 0x14]
0005617d  66413b4208               cmp ax, word ptr [r10 + 8]
00056182  0f84ad010000             je 0x56335
00056188  488b09                   mov rcx, qword ptr [rcx]
0005618b  4885c9                   test rcx, rcx
0005618e  75e0                     jne 0x56170
00056190  33d2                     xor edx, edx
00056192  4c8b4b10                 mov r9, qword ptr [rbx + 0x10]
00056196  4d85c9                   test r9, r9
00056199  747c                     je 0x56217
0005619b  450fb702                 movzx r8d, word ptr [r10]
0005619f  410fb75204               movzx edx, word ptr [r10 + 4]
000561a4  418bc0                   mov eax, r8d
000561a7  c1e802                   shr eax, 2
000561aa  4169c820080000           imul ecx, r8d, 0x820
000561b1  03c8                     add ecx, eax
000561b3  410fb74202               movzx eax, word ptr [r10 + 2]
000561b8  03c8                     add ecx, eax
000561ba  4433c1                   xor r8d, ecx
000561bd  4169c020080000           imul eax, r8d, 0x820
000561c4  418bc8                   mov ecx, r8d
000561c7  c1e902                   shr ecx, 2
000561ca  03d0                     add edx, eax
000561cc  03d1                     add edx, ecx
000561ce  4433c2                   xor r8d, edx
000561d1  410fb75206               movzx edx, word ptr [r10 + 6]
000561d6  4169c020080000           imul eax, r8d, 0x820
000561dd  418bc8                   mov ecx, r8d
000561e0  c1e902                   shr ecx, 2
000561e3  03c2                     add eax, edx
000561e5  33d2                     xor edx, edx
000561e7  03c1                     add eax, ecx
000561e9  4133c0                   xor eax, r8d
000561ec  41f77108                 div dword ptr [r9 + 8]
000561f0  498b01                   mov rax, qword ptr [r9]
000561f3  488d1452                 lea rdx, [rdx + rdx*2]
000561f7  488d0cd0                 lea rcx, [rax + rdx*8]
000561fb  4885c9                   test rcx, rcx
000561fe  7415                     je 0x56215
00056200  488b410c                 mov rax, qword ptr [rcx + 0xc]
00056204  493b02                   cmp rax, qword ptr [r10]
00056207  0f843a010000             je 0x56347
0005620d  488b09                   mov rcx, qword ptr [rcx]
00056210  4885c9                   test rcx, rcx
00056213  75eb                     jne 0x56200
00056215  33d2                     xor edx, edx
00056217  4c8b4b08                 mov r9, qword ptr [rbx + 8]
0005621b  4d85c9                   test r9, r9
0005621e  7471                     je 0x56291
00056220  450fb702                 movzx r8d, word ptr [r10]
00056224  4169d020080000           imul edx, r8d, 0x820
0005622b  418bc8                   mov ecx, r8d
0005622e  c1e902                   shr ecx, 2
00056231  03d1                     add edx, ecx
00056233  410fb74a02               movzx ecx, word ptr [r10 + 2]
00056238  03d1                     add edx, ecx
0005623a  4433c2                   xor r8d, edx
0005623d  410fb75204               movzx edx, word ptr [r10 + 4]
00056242  4169c020080000           imul eax, r8d, 0x820
00056249  418bc8                   mov ecx, r8d
0005624c  c1e902                   shr ecx, 2
0005624f  03c2                     add eax, edx
00056251  33d2                     xor edx, edx
00056253  03c1                     add eax, ecx
00056255  4133c0                   xor eax, r8d
00056258  41f77108                 div dword ptr [r9 + 8]
0005625c  498b01                   mov rax, qword ptr [r9]
0005625f  488d1452                 lea rdx, [rdx + rdx*2]
00056263  488d0cd0                 lea rcx, [rax + rdx*8]
00056267  4885c9                   test rcx, rcx
0005626a  7423                     je 0x5628f
0005626c  0f1f4000                 nop dword ptr [rax]
00056270  8b410c                   mov eax, dword ptr [rcx + 0xc]
00056273  413b02                   cmp eax, dword ptr [r10]
00056276  750f                     jne 0x56287
00056278  0fb74110                 movzx eax, word ptr [rcx + 0x10]
0005627c  66413b4204               cmp ax, word ptr [r10 + 4]
00056281  0f84d2000000             je 0x56359
00056287  488b09                   mov rcx, qword ptr [rcx]
0005628a  4885c9                   test rcx, rcx
0005628d  75e1                     jne 0x56270
0005628f  33d2                     xor edx, edx
00056291  4c8b0b                   mov r9, qword ptr [rbx]
00056294  4d85c9                   test r9, r9
00056297  0f84e0000000             je 0x5637d
0005629d  450fb702                 movzx r8d, word ptr [r10]
000562a1  410fb75202               movzx edx, word ptr [r10 + 2]
000562a6  418bc8                   mov ecx, r8d
000562a9  c1e902                   shr ecx, 2
000562ac  4169c020080000           imul eax, r8d, 0x820
000562b3  03c2                     add eax, edx
000562b5  33d2                     xor edx, edx
000562b7  03c1                     add eax, ecx
000562b9  4133c0                   xor eax, r8d
000562bc  41f77108                 div dword ptr [r9 + 8]
000562c0  8bca                     mov ecx, edx
000562c2  48c1e104                 shl rcx, 4
000562c6  490309                   add rcx, qword ptr [r9]
000562c9  7419                     je 0x562e4
000562cb  0f1f440000               nop dword ptr [rax + rax]
000562d0  8b410c                   mov eax, dword ptr [rcx + 0xc]
000562d3  413b02                   cmp eax, dword ptr [r10]
000562d6  0f848f000000             je 0x5636b
000562dc  488b09                   mov rcx, qword ptr [rcx]
000562df  4885c9                   test rcx, rcx
000562e2  75ec                     jne 0x562d0
000562e4  33c0                     xor eax, eax
000562e6  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000562eb  488b6c2450               mov rbp, qword ptr [rsp + 0x50]
000562f0  488b742458               mov rsi, qword ptr [rsp + 0x58]
000562f5  4883c420                 add rsp, 0x20
000562f9  415f                     pop r15
000562fb  415e                     pop r14
000562fd  5f                       pop rdi
000562fe  c3                       ret
000562ff  8b5108                   mov edx, dword ptr [rcx + 8]
00056302  85d2                     test edx, edx
00056304  0f8427fcffff             je 0x55f31
0005630a  b808000000               mov eax, 8
0005630f  eb78                     jmp 0x56389
00056311  8b5108                   mov edx, dword ptr [rcx + 8]
00056314  85d2                     test edx, edx
00056316  0f84fffcffff             je 0x5601b
0005631c  b807000000               mov eax, 7
00056321  eb66                     jmp 0x56389
00056323  8b5108                   mov edx, dword ptr [rcx + 8]
00056326  85d2                     test edx, edx
00056328  0f84b2fdffff             je 0x560e0
0005632e  b806000000               mov eax, 6
00056333  eb54                     jmp 0x56389
00056335  8b5108                   mov edx, dword ptr [rcx + 8]
00056338  85d2                     test edx, edx
0005633a  0f8452feffff             je 0x56192
00056340  b805000000               mov eax, 5
00056345  eb42                     jmp 0x56389
00056347  8b5108                   mov edx, dword ptr [rcx + 8]
0005634a  85d2                     test edx, edx
0005634c  0f84c5feffff             je 0x56217
00056352  b804000000               mov eax, 4
00056357  eb30                     jmp 0x56389
00056359  8b5108                   mov edx, dword ptr [rcx + 8]
0005635c  85d2                     test edx, edx
0005635e  0f842dffffff             je 0x56291
00056364  b803000000               mov eax, 3
00056369  eb1e                     jmp 0x56389
0005636b  8b5108                   mov edx, dword ptr [rcx + 8]
0005636e  85d2                     test edx, edx
00056370  0f846effffff             je 0x562e4
00056376  b802000000               mov eax, 2
0005637b  eb0c                     jmp 0x56389
0005637d  85d2                     test edx, edx
0005637f  0f845fffffff             je 0x562e4
00056385  8b442440                 mov eax, dword ptr [rsp + 0x40]
00056389  85ed                     test ebp, ebp
0005638b  7531                     jne 0x563be
0005638d  448d40ff                 lea r8d, [rax - 1]
00056391  488d470e                 lea rax, [rdi + 0xe]
00056395  4c3bf0                   cmp r14, rax
00056398  740f                     je 0x563a9
0005639a  4b8d0c46                 lea rcx, [r14 + r8*2]
0005639e  412bf0                   sub esi, r8d
000563a1  48890f                   mov qword ptr [rdi], rcx
000563a4  897708                   mov dword ptr [rdi + 8], esi
000563a7  eb15                     jmp 0x563be
000563a9  488b4710                 mov rax, qword ptr [rdi + 0x10]
000563ad  8d4eff                   lea ecx, [rsi - 1]
000563b0  488907                   mov qword ptr [rdi], rax
000563b3  894f08                   mov dword ptr [rdi + 8], ecx
000563b6  48c7471000000000         mov qword ptr [rdi + 0x10], 0
000563be  0fb7ca                   movzx ecx, dx
000563c1  b801000000               mov eax, 1
000563c6  48c1e120                 shl rcx, 0x20
000563ca  48c1ea10                 shr rdx, 0x10
000563ce  480bca                   or rcx, rdx
000563d1  49890f                   mov qword ptr [r15], rcx
000563d4  e90dffffff               jmp 0x562e6
000563d9  0f1f00                   nop dword ptr [rax]
000563dc  91                       xchg ecx, eax
