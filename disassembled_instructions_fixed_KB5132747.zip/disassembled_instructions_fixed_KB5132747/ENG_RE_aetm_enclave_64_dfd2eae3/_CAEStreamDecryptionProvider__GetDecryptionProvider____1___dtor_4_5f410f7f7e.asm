; `CAEStreamDecryptionProvider::GetDecryptionProvider'::`1'::dtor$4
; aetm_enclave.dll, primary RVA 0x61310, 28 bytes in 1 chunk(s)

; chunk at RVA 0x61310 (28 bytes)
00061310  4055                     push rbp
00061312  4883ec20                 sub rsp, 0x20
00061316  488bea                   mov rbp, rdx
00061319  488b5558                 mov rdx, qword ptr [rbp + 0x58]
0006131d  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00061321  e8ba85fbff               call 0x198e0
00061326  4883c420                 add rsp, 0x20
0006132a  5d                       pop rbp
0006132b  c3                       ret
