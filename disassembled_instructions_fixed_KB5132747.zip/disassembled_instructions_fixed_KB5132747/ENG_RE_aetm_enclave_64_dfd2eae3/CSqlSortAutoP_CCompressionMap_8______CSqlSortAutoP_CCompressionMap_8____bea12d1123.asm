; CSqlSortAutoP<CCompressionMap<8> >::~CSqlSortAutoP<CCompressionMap<8> >
; aetm_enclave.dll, primary RVA 0x42700, 136 bytes in 5 chunk(s)

; chunk at RVA 0x42700 (30 bytes)
00042700  4889742418               mov qword ptr [rsp + 0x18], rsi
00042705  4156                     push r14
00042707  4883ec20                 sub rsp, 0x20
0004270b  488b31                   mov rsi, qword ptr [rcx]
0004270e  4c8bf1                   mov r14, rcx
00042711  4885f6                   test rsi, rsi
00042714  7466                     je 0x4277c
00042716  488b06                   mov rax, qword ptr [rsi]
00042719  4885c0                   test rax, rax
0004271c  7456                     je 0x42774

; chunk at RVA 0x4271e (12 bytes)
0004271e  48897c2438               mov qword ptr [rsp + 0x38], rdi
00042723  33ff                     xor edi, edi
00042725  397e08                   cmp dword ptr [rsi + 8], edi
00042728  763d                     jbe 0x42767

; chunk at RVA 0x4272a (61 bytes)
0004272a  48895c2430               mov qword ptr [rsp + 0x30], rbx
0004272f  90                       nop
00042730  8bcf                     mov ecx, edi
00042732  488bd0                   mov rdx, rax
00042735  48c1e105                 shl rcx, 5
00042739  488b0c01                 mov rcx, qword ptr [rcx + rax]
0004273d  4885c9                   test rcx, rcx
00042740  7416                     je 0x42758
00042742  488b19                   mov rbx, qword ptr [rcx]
00042745  e852b80100               call 0x5df9c
0004274a  488bcb                   mov rcx, rbx
0004274d  4885db                   test rbx, rbx
00042750  75f0                     jne 0x42742
00042752  488b06                   mov rax, qword ptr [rsi]
00042755  488bd0                   mov rdx, rax
00042758  ffc7                     inc edi
0004275a  3b7e08                   cmp edi, dword ptr [rsi + 8]
0004275d  72d1                     jb 0x42730
0004275f  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00042764  488bc2                   mov rax, rdx

; chunk at RVA 0x42767 (13 bytes)
00042767  488bc8                   mov rcx, rax
0004276a  e82db80100               call 0x5df9c
0004276f  488b7c2438               mov rdi, qword ptr [rsp + 0x38]

; chunk at RVA 0x42774 (20 bytes)
00042774  498b0e                   mov rcx, qword ptr [r14]
00042777  e820b80100               call 0x5df9c
0004277c  488b742440               mov rsi, qword ptr [rsp + 0x40]
00042781  4883c420                 add rsp, 0x20
00042785  415e                     pop r14
00042787  c3                       ret
