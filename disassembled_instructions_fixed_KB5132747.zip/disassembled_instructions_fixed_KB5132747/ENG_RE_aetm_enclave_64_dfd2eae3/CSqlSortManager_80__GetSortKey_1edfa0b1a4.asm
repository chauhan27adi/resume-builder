; CSqlSortManager_80::GetSortKey
; aetm_enclave.dll, primary RVA 0x47990, 5424 bytes in 8 chunk(s)

; chunk at RVA 0x47990 (140 bytes)
00047990  4c894c2420               mov qword ptr [rsp + 0x20], r9
00047995  4889542410               mov qword ptr [rsp + 0x10], rdx
0004799a  55                       push rbp
0004799b  53                       push rbx
0004799c  56                       push rsi
0004799d  4154                     push r12
0004799f  4155                     push r13
000479a1  4157                     push r15
000479a3  488d6c24f9               lea rbp, [rsp - 7]
000479a8  4881ec98000000           sub rsp, 0x98
000479af  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
000479b3  33c0                     xor eax, eax
000479b5  448bf8                   mov r15d, eax
000479b8  488945bf                 mov qword ptr [rbp - 0x41], rax
000479bc  448be8                   mov r13d, eax
000479bf  488945b7                 mov qword ptr [rbp - 0x49], rax
000479c3  448bd0                   mov r10d, eax
000479c6  488945af                 mov qword ptr [rbp - 0x51], rax
000479ca  488945cf                 mov qword ptr [rbp - 0x31], rax
000479ce  8bd8                     mov ebx, eax
000479d0  488945df                 mov qword ptr [rbp - 0x21], rax
000479d4  498bf1                   mov rsi, r9
000479d7  89458f                   mov dword ptr [rbp - 0x71], eax
000479da  458be0                   mov r12d, r8d
000479dd  b801000000               mov eax, 1
000479e2  66894593                 mov word ptr [rbp - 0x6d], ax
000479e6  418bc3                   mov eax, r11d
000479e9  f7d8                     neg eax
000479eb  1bd2                     sbb edx, edx
000479ed  81e2a5b0b912             and edx, 0x12b9b0a5
000479f3  41f7c000030000           test r8d, 0x300
000479fa  0f8581140000             jne 0x48e81
00047a00  418bc0                   mov eax, r8d
00047a03  25f8effc3e               and eax, 0x3efceff8
00047a08  3d00040000               cmp eax, 0x400
00047a0d  0f856e140000             jne 0x48e81
00047a13  4d85c9                   test r9, r9
00047a16  0f8465140000             je 0x48e81

; chunk at RVA 0x47a1c (8 bytes)
00047a1c  4889bc24d0000000         mov qword ptr [rsp + 0xd0], rdi

; chunk at RVA 0x47a24 (4926 bytes)
00047a24  4c89b42490000000         mov qword ptr [rsp + 0x90], r14
00047a2c  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00047a30  4585f6                   test r14d, r14d
00047a33  7547                     jne 0x47a7c
00047a35  488b85a7000000           mov rax, qword ptr [rbp + 0xa7]
00047a3c  4c8bbd8f000000           mov r15, qword ptr [rbp + 0x8f]
00047a43  4c8bad97000000           mov r13, qword ptr [rbp + 0x97]
00047a4a  4c8b959f000000           mov r10, qword ptr [rbp + 0x9f]
00047a51  488b00                   mov rax, qword ptr [rax]
00047a54  488b8daf000000           mov rcx, qword ptr [rbp + 0xaf]
00047a5b  4d8b3f                   mov r15, qword ptr [r15]
00047a5e  4d8b6d00                 mov r13, qword ptr [r13]
00047a62  4d8b12                   mov r10, qword ptr [r10]
00047a65  488945cf                 mov qword ptr [rbp - 0x31], rax
00047a69  488b01                   mov rax, qword ptr [rcx]
00047a6c  488945df                 mov qword ptr [rbp - 0x21], rax
00047a70  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00047a74  4c896db7                 mov qword ptr [rbp - 0x49], r13
00047a78  4c8955af                 mov qword ptr [rbp - 0x51], r10
00047a7c  8b7d5f                   mov edi, dword ptr [rbp + 0x5f]
00047a7f  85ff                     test edi, edi
00047a81  790e                     jns 0x47a91
00047a83  488bce                   mov rcx, rsi
00047a86  e825feffff               call 0x478b0
00047a8b  8d7801                   lea edi, [rax + 1]
00047a8e  897d5f                   mov dword ptr [rbp + 0x5f], edi
00047a91  41f6c401                 test r12b, 1
00047a95  4889759f                 mov qword ptr [rbp - 0x61], rsi
00047a99  b8ff000000               mov eax, 0xff
00047a9e  c7459701000000           mov dword ptr [rbp - 0x69], 1
00047aa5  b9e7000000               mov ecx, 0xe7
00047aaa  0f44c8                   cmove ecx, eax
00047aad  440fb6c9                 movzx r9d, cl
00047ab1  410fb6c9                 movzx ecx, r9b
00047ab5  80e1df                   and cl, 0xdf
00047ab8  4181e000000100           and r8d, 0x10000
00047abf  0fb6c1                   movzx eax, cl
00047ac2  418bcc                   mov ecx, r12d
00047ac5  410f44c1                 cmove eax, r9d
00047ac9  448bca                   mov r9d, edx
00047acc  440fb6c0                 movzx r8d, al
00047ad0  410fb6c0                 movzx eax, r8b
00047ad4  24fe                     and al, 0xfe
00047ad6  0fb6c0                   movzx eax, al
00047ad9  81e100000200             and ecx, 0x20000
00047adf  410f44c0                 cmove eax, r8d
00047ae3  8945a7                   mov dword ptr [rbp - 0x59], eax
00047ae6  418bc4                   mov eax, r12d
00047ae9  2500100000               and eax, 0x1000
00047aee  4183e404                 and r12d, 4
00047af2  8945e7                   mov dword ptr [rbp - 0x19], eax
00047af5  b807020000               mov eax, 0x207
00047afa  4489654f                 mov dword ptr [rbp + 0x4f], r12d
00047afe  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00047b03  83ff01                   cmp edi, 1
00047b06  0f8c41120000             jl 0x48d4d
00047b0c  8d047f                   lea eax, [rdi + rdi*2]
00047b0f  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047b13  4898                     cdqe
00047b15  488945d7                 mov qword ptr [rbp - 0x29], rax
00047b19  0f1f8000000000           nop dword ptr [rax]
00047b20  0fb706                   movzx eax, word ptr [rsi]
00047b23  488b4d47                 mov rcx, qword ptr [rbp + 0x47]
00047b27  488945ef                 mov qword ptr [rbp - 0x11], rax
00047b2b  4c8b7108                 mov r14, qword ptr [rcx + 8]
00047b2f  458b1c86                 mov r11d, dword ptr [r14 + rax*4]
00047b33  458bd3                   mov r10d, r11d
00047b36  44895dc7                 mov dword ptr [rbp - 0x39], r11d
00047b3a  418bf3                   mov esi, r11d
00047b3d  41c1ea18                 shr r10d, 0x18
00047b41  450fb7c3                 movzx r8d, r11w
00047b45  c1ee10                   shr esi, 0x10
00047b48  6641c1e808               shr r8w, 8
00047b4d  4180f80b                 cmp r8b, 0xb
00047b51  0f86c6090000             jbe 0x4851d
00047b57  488bc1                   mov rax, rcx
00047b5a  83781400                 cmp dword ptr [rax + 0x14], 0
00047b5e  0f8562010000             jne 0x47cc6
00047b64  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00047b68  410fb7cb                 movzx ecx, r11w
00047b6c  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00047b70  4c63c3                   movsxd r8, ebx
00047b73  66c1e908                 shr cx, 8
00047b77  4585f6                   test r14d, r14d
00047b7a  0f84c7000000             je 0x47c47
00047b80  42884c058f               mov byte ptr [rbp + r8 - 0x71], cl
00047b85  83c302                   add ebx, 2
00047b88  46885c0590               mov byte ptr [rbp + r8 - 0x70], r11b
00047b8d  4983c002                 add r8, 2
00047b91  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00047b96  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047b9a  4983f804                 cmp r8, 4
00047b9e  0f859d000000             jne 0x47c41
00047ba4  33c0                     xor eax, eax
00047ba6  8bd8                     mov ebx, eax
00047ba8  448bc0                   mov r8d, eax
00047bab  39456f                   cmp dword ptr [rbp + 0x6f], eax
00047bae  753f                     jne 0x47bef
00047bb0  41c1c103                 rol r9d, 3
00047bb4  b907020000               mov ecx, 0x207
00047bb9  418bc1                   mov eax, r9d
00047bbc  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00047bc0  66394d91                 cmp word ptr [rbp - 0x6f], cx
00047bc4  740c                     je 0x47bd2
00047bc6  66ff4593                 inc word ptr [rbp - 0x6d]
00047bca  418bd1                   mov edx, r9d
00047bcd  e9a9000000               jmp 0x47c7b
00047bd2  663bf9                   cmp di, cx
00047bd5  746a                     je 0x47c41
00047bd7  418bd4                   mov edx, r12d
00047bda  33d0                     xor edx, eax
00047bdc  8bc7                     mov eax, edi
00047bde  c1e808                   shr eax, 8
00047be1  c1c203                   rol edx, 3
00047be4  33d0                     xor edx, eax
00047be6  66ff4593                 inc word ptr [rbp - 0x6d]
00047bea  e98c000000               jmp 0x47c7b
00047bef  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00047bf2  418bc1                   mov eax, r9d
00047bf5  4569d120080000           imul r10d, r9d, 0x820
00047bfc  458bd9                   mov r11d, r9d
00047bff  c1e802                   shr eax, 2
00047c02  4403d0                   add r10d, eax
00047c05  4103ca                   add ecx, r10d
00047c08  4433c9                   xor r9d, ecx
00047c0b  b907020000               mov ecx, 0x207
00047c10  66394d91                 cmp word ptr [rbp - 0x6f], cx
00047c14  7409                     je 0x47c1f
00047c16  66ff4593                 inc word ptr [rbp - 0x6d]
00047c1a  418bd1                   mov edx, r9d
00047c1d  eb5c                     jmp 0x47c7b
00047c1f  663bf9                   cmp di, cx
00047c22  741d                     je 0x47c41
00047c24  438d1422                 lea edx, [r10 + r12]
00047c28  8bcf                     mov ecx, edi
00047c2a  4133d3                   xor edx, r11d
00047c2d  c1e908                   shr ecx, 8
00047c30  69c220080000             imul eax, edx, 0x820
00047c36  03c8                     add ecx, eax
00047c38  8bc2                     mov eax, edx
00047c3a  c1e802                   shr eax, 2
00047c3d  03c8                     add ecx, eax
00047c3f  33d1                     xor edx, ecx
00047c41  66ff4593                 inc word ptr [rbp - 0x6d]
00047c45  eb34                     jmp 0x47c7b
00047c47  0fb645a7                 movzx eax, byte ptr [rbp - 0x59]
00047c4b  41880f                   mov byte ptr [r15], cl
00047c4e  4122c2                   and al, r10b
00047c51  488b4daf                 mov rcx, qword ptr [rbp - 0x51]
00047c55  243f                     and al, 0x3f
00047c57  45885f01                 mov byte ptr [r15 + 1], r11b
00047c5b  4983c702                 add r15, 2
00047c5f  41c1eb10                 shr r11d, 0x10
00047c63  45885d00                 mov byte ptr [r13], r11b
00047c67  49ffc5                   inc r13
00047c6a  8801                     mov byte ptr [rcx], al
00047c6c  48ffc1                   inc rcx
00047c6f  48894daf                 mov qword ptr [rbp - 0x51], rcx
00047c73  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00047c77  4c896db7                 mov qword ptr [rbp - 0x49], r13
00047c7b  448b5597                 mov r10d, dword ptr [rbp - 0x69]
00047c7f  4883c602                 add rsi, 2
00047c83  41ffc2                   inc r10d
00047c86  4889759f                 mov qword ptr [rbp - 0x61], rsi
00047c8a  44895597                 mov dword ptr [rbp - 0x69], r10d
00047c8e  443b555f                 cmp r10d, dword ptr [rbp + 0x5f]
00047c92  0f8fa6100000             jg 0x48d3e
00047c98  0fb70e                   movzx ecx, word ptr [rsi]
00047c9b  488b4547                 mov rax, qword ptr [rbp + 0x47]
00047c9f  488b4008                 mov rax, qword ptr [rax + 8]
00047ca3  448b1c88                 mov r11d, dword ptr [rax + rcx*4]
00047ca7  458bd3                   mov r10d, r11d
00047caa  410fb7c3                 movzx eax, r11w
00047cae  41c1ea18                 shr r10d, 0x18
00047cb2  66c1e808                 shr ax, 8
00047cb6  418bcb                   mov ecx, r11d
00047cb9  3c0b                     cmp al, 0xb
00047cbb  0f87b2feffff             ja 0x47b73
00047cc1  e96c100000               jmp 0x48d32
00047cc6  4533c0                   xor r8d, r8d
00047cc9  458be8                   mov r13d, r8d
00047ccc  41f6c2c0                 test r10b, 0xc0
00047cd0  0f84ca000000             je 0x47da0
00047cd6  8b4d5f                   mov ecx, dword ptr [rbp + 0x5f]
00047cd9  410fb7f0                 movzx esi, r8w
00047cdd  448b5597                 mov r10d, dword ptr [rbp - 0x69]
00047ce1  450fb7f8                 movzx r15d, r8w
00047ce5  66448945c7               mov word ptr [rbp - 0x39], r8w
00047cea  4c8b459f                 mov r8, qword ptr [rbp - 0x61]
00047cee  412bca                   sub ecx, r10d
00047cf1  741d                     je 0x47d10
00047cf3  83e901                   sub ecx, 1
00047cf6  7413                     je 0x47d0b
00047cf8  83f901                   cmp ecx, 1
00047cfb  7405                     je 0x47d02
00047cfd  410fb77006               movzx esi, word ptr [r8 + 6]
00047d02  410fb74004               movzx eax, word ptr [r8 + 4]
00047d07  668945c7                 mov word ptr [rbp - 0x39], ax
00047d0b  450fb77802               movzx r15d, word ptr [r8 + 2]
00047d10  488b4547                 mov rax, qword ptr [rbp + 0x47]
00047d14  44396818                 cmp dword ptr [rax + 0x18], r13d
00047d18  743f                     je 0x47d59
00047d1a  443b555f                 cmp r10d, dword ptr [rbp + 0x5f]
00047d1e  7d39                     jge 0x47d59
00047d20  410fb74002               movzx eax, word ptr [r8 + 2]
00047d25  418bcb                   mov ecx, r11d
00047d28  41330c86                 xor ecx, dword ptr [r14 + rax*4]
00047d2c  f7c1ffffffe7             test ecx, 0xe7ffffff
00047d32  7525                     jne 0x47d59
00047d34  488b4547                 mov rax, qword ptr [rbp + 0x47]
00047d38  4c8b5020                 mov r10, qword ptr [rax + 0x20]
00047d3c  410fb74204               movzx eax, word ptr [r10 + 4]
00047d41  85c0                     test eax, eax
00047d43  7414                     je 0x47d59
00047d45  6645397a06               cmp word ptr [r10 + 6], r15w
00047d4a  0f86c5000000             jbe 0x47e15
00047d50  4983c210                 add r10, 0x10
00047d54  83e801                   sub eax, 1
00047d57  75ec                     jne 0x47d45
00047d59  440fb775c7               movzx r14d, word ptr [rbp - 0x39]
00047d5e  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00047d62  4c8b4547                 mov r8, qword ptr [rbp + 0x47]
00047d66  4d8b5020                 mov r10, qword ptr [r8 + 0x20]
00047d6a  410fb74204               movzx eax, word ptr [r10 + 4]
00047d6f  85c0                     test eax, eax
00047d71  7421                     je 0x47d94
00047d73  488b4def                 mov rcx, qword ptr [rbp - 0x11]
00047d77  660f1f840000000000       nop word ptr [rax + rax]
00047d80  6641394a06               cmp word ptr [r10 + 6], cx
00047d85  0f8684040000             jbe 0x4820f
00047d8b  4983c210                 add r10, 0x10
00047d8f  83e801                   sub eax, 1
00047d92  75ec                     jne 0x47d80
00047d94  4585ed                   test r13d, r13d
00047d97  0f85890f0000             jne 0x48d26
00047d9d  4533c0                   xor r8d, r8d
00047da0  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00047da4  4585f6                   test r14d, r14d
00047da7  0f840d070000             je 0x484ba
00047dad  4863c3                   movsxd rax, ebx
00047db0  410fb7cb                 movzx ecx, r11w
00047db4  ffc3                     inc ebx
00047db6  66c1e908                 shr cx, 8
00047dba  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
00047dbe  4863c3                   movsxd rax, ebx
00047dc1  ffc3                     inc ebx
00047dc3  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
00047dc8  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00047dcd  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047dd1  83fb04                   cmp ebx, 4
00047dd4  0f85d2060000             jne 0x484ac
00047dda  837d6f00                 cmp dword ptr [rbp + 0x6f], 0
00047dde  418bd8                   mov ebx, r8d
00047de1  0f856b060000             jne 0x48452
00047de7  41c1c103                 rol r9d, 3
00047deb  b907020000               mov ecx, 0x207
00047df0  418bc1                   mov eax, r9d
00047df3  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00047df7  66394d91                 cmp word ptr [rbp - 0x6f], cx
00047dfb  0f842c060000             je 0x4842d
00047e01  66ff4593                 inc word ptr [rbp - 0x6d]
00047e05  418bd1                   mov edx, r9d
00047e08  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
00047e0c  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00047e10  e9ef060000               jmp 0x48504
00047e15  85c0                     test eax, eax
00047e17  0f843cffffff             je 0x47d59
00047e1d  440fb775c7               movzx r14d, word ptr [rbp - 0x39]
00047e22  6645397a06               cmp word ptr [r10 + 6], r15w
00047e27  0f8531ffffff             jne 0x47d5e
00047e2d  66453b720c               cmp r14w, word ptr [r10 + 0xc]
00047e32  0f8226ffffff             jb 0x47d5e
00047e38  66453b720e               cmp r14w, word ptr [r10 + 0xe]
00047e3d  0f871bffffff             ja 0x47d5e
00047e43  488b4547                 mov rax, qword ptr [rbp + 0x47]
00047e47  410fb74a08               movzx ecx, word ptr [r10 + 8]
00047e4c  488b4028                 mov rax, qword ptr [rax + 0x28]
00047e50  4c8d04c8                 lea r8, [rax + rcx*8]
00047e54  410fb7420a               movzx eax, word ptr [r10 + 0xa]
00047e59  85c0                     test eax, eax
00047e5b  0f84fdfeffff             je 0x47d5e
00047e61  66453930                 cmp word ptr [r8], r14w
00047e65  760e                     jbe 0x47e75
00047e67  4983c008                 add r8, 8
00047e6b  83e801                   sub eax, 1
00047e6e  75f1                     jne 0x47e61
00047e70  e9e9feffff               jmp 0x47d5e
00047e75  85c0                     test eax, eax
00047e77  0f84e1feffff             je 0x47d5e
00047e7d  0f1f00                   nop dword ptr [rax]
00047e80  66453930                 cmp word ptr [r8], r14w
00047e84  0f85d4feffff             jne 0x47d5e
00047e8a  410fb74802               movzx ecx, word ptr [r8 + 2]
00047e8f  6685c9                   test cx, cx
00047e92  0f84c2020000             je 0x4815a
00047e98  663bce                   cmp cx, si
00047e9b  740e                     je 0x47eab
00047e9d  4983c008                 add r8, 8
00047ea1  83e801                   sub eax, 1
00047ea4  75da                     jne 0x47e80
00047ea6  e9b3feffff               jmp 0x47d5e
00047eab  458b5804                 mov r11d, dword ptr [r8 + 4]
00047eaf  418bcb                   mov ecx, r11d
00047eb2  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00047eb6  450fb7c3                 movzx r8d, r11w
00047eba  83459704                 add dword ptr [rbp - 0x69], 4
00047ebe  4883c608                 add rsi, 8
00047ec2  c1e918                   shr ecx, 0x18
00047ec5  6641c1e808               shr r8w, 8
00047eca  4889759f                 mov qword ptr [rbp - 0x61], rsi
00047ece  44396d67                 cmp dword ptr [rbp + 0x67], r13d
00047ed2  0f842c020000             je 0x48104
00047ed8  448b6d6f                 mov r13d, dword ptr [rbp + 0x6f]
00047edc  450fb6e0                 movzx r12d, r8b
00047ee0  4863c3                   movsxd rax, ebx
00047ee3  ffc3                     inc ebx
00047ee5  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00047eea  4863c3                   movsxd rax, ebx
00047eed  ffc3                     inc ebx
00047eef  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
00047ef4  83fb04                   cmp ebx, 4
00047ef7  0f8504010000             jne 0x48001
00047efd  33db                     xor ebx, ebx
00047eff  4585ed                   test r13d, r13d
00047f02  756f                     jne 0x47f73
00047f04  41c1c103                 rol r9d, 3
00047f08  41bd07020000             mov r13d, 0x207
00047f0e  418bc9                   mov ecx, r9d
00047f11  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00047f15  6644396d91               cmp word ptr [rbp - 0x6f], r13w
00047f1a  7421                     je 0x47f3d
00047f1c  bb02000000               mov ebx, 2
00047f21  4488458f                 mov byte ptr [rbp - 0x71], r8b
00047f25  66015d93                 add word ptr [rbp - 0x6d], bx
00047f29  418bd1                   mov edx, r9d
00047f2c  44885d90                 mov byte ptr [rbp - 0x70], r11b
00047f30  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047f34  448d6bff                 lea r13d, [rbx - 1]
00047f38  e925feffff               jmp 0x47d62
00047f3d  0fb7458f                 movzx eax, word ptr [rbp - 0x71]
00047f41  66413bc5                 cmp ax, r13w
00047f45  740e                     je 0x47f55
00047f47  0fb6558f                 movzx edx, byte ptr [rbp - 0x71]
00047f4b  33d1                     xor edx, ecx
00047f4d  c1e808                   shr eax, 8
00047f50  c1c203                   rol edx, 3
00047f53  33d0                     xor edx, eax
00047f55  bb02000000               mov ebx, 2
00047f5a  4488458f                 mov byte ptr [rbp - 0x71], r8b
00047f5e  66015d93                 add word ptr [rbp - 0x6d], bx
00047f62  44885d90                 mov byte ptr [rbp - 0x70], r11b
00047f66  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047f6a  448d6bff                 lea r13d, [rbx - 1]
00047f6e  e9effdffff               jmp 0x47d62
00047f73  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00047f76  418bc1                   mov eax, r9d
00047f79  4569d120080000           imul r10d, r9d, 0x820
00047f80  418bf9                   mov edi, r9d
00047f83  c1e802                   shr eax, 2
00047f86  4403d0                   add r10d, eax
00047f89  4103ca                   add ecx, r10d
00047f8c  4433c9                   xor r9d, ecx
00047f8f  b907020000               mov ecx, 0x207
00047f94  66394d91                 cmp word ptr [rbp - 0x6f], cx
00047f98  7421                     je 0x47fbb
00047f9a  418bd1                   mov edx, r9d
00047f9d  bb02000000               mov ebx, 2
00047fa2  4488458f                 mov byte ptr [rbp - 0x71], r8b
00047fa6  66015d93                 add word ptr [rbp - 0x6d], bx
00047faa  44885d90                 mov byte ptr [rbp - 0x70], r11b
00047fae  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047fb2  448d6bff                 lea r13d, [rbx - 1]
00047fb6  e9a7fdffff               jmp 0x47d62
00047fbb  0fb7458f                 movzx eax, word ptr [rbp - 0x71]
00047fbf  663bc1                   cmp ax, cx
00047fc2  7442                     je 0x48006
00047fc4  0fb6558f                 movzx edx, byte ptr [rbp - 0x71]
00047fc8  8bc8                     mov ecx, eax
00047fca  4103d2                   add edx, r10d
00047fcd  c1e908                   shr ecx, 8
00047fd0  33d7                     xor edx, edi
00047fd2  4488458f                 mov byte ptr [rbp - 0x71], r8b
00047fd6  69c220080000             imul eax, edx, 0x820
00047fdc  bb02000000               mov ebx, 2
00047fe1  44885d90                 mov byte ptr [rbp - 0x70], r11b
00047fe5  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047fe9  448d6bff                 lea r13d, [rbx - 1]
00047fed  03c8                     add ecx, eax
00047fef  8bc2                     mov eax, edx
00047ff1  c1e802                   shr eax, 2
00047ff4  03c8                     add ecx, eax
00047ff6  33d1                     xor edx, ecx
00047ff8  66015d93                 add word ptr [rbp - 0x6d], bx
00047ffc  e961fdffff               jmp 0x47d62
00048001  b907020000               mov ecx, 0x207
00048006  4863c3                   movsxd rax, ebx
00048009  ffc3                     inc ebx
0004800b  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048010  4863c3                   movsxd rax, ebx
00048013  ffc3                     inc ebx
00048015  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
0004801a  83fb04                   cmp ebx, 4
0004801d  0f85c8000000             jne 0x480eb
00048023  33db                     xor ebx, ebx
00048025  4585ed                   test r13d, r13d
00048028  7544                     jne 0x4806e
0004802a  41c1c103                 rol r9d, 3
0004802e  418bc1                   mov eax, r9d
00048031  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00048035  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048039  0f85a9000000             jne 0x480e8
0004803f  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048043  663bf9                   cmp di, cx
00048046  0f8487000000             je 0x480d3
0004804c  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048051  448d6b01                 lea r13d, [rbx + 1]
00048055  418bd4                   mov edx, r12d
00048058  33d0                     xor edx, eax
0004805a  8bc7                     mov eax, edi
0004805c  c1e808                   shr eax, 8
0004805f  c1c203                   rol edx, 3
00048062  33d0                     xor edx, eax
00048064  6683459302               add word ptr [rbp - 0x6d], 2
00048069  e9f4fcffff               jmp 0x47d62
0004806e  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00048071  418bc1                   mov eax, r9d
00048074  4569c120080000           imul r8d, r9d, 0x820
0004807b  458bd1                   mov r10d, r9d
0004807e  c1e802                   shr eax, 2
00048081  41bd07020000             mov r13d, 0x207
00048087  4403c0                   add r8d, eax
0004808a  4103c8                   add ecx, r8d
0004808d  4433c9                   xor r9d, ecx
00048090  6644396d91               cmp word ptr [rbp - 0x6f], r13w
00048095  7551                     jne 0x480e8
00048097  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
0004809b  66413bfd                 cmp di, r13w
0004809f  7432                     je 0x480d3
000480a1  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
000480a6  8bcf                     mov ecx, edi
000480a8  c1e908                   shr ecx, 8
000480ab  41bd01000000             mov r13d, 1
000480b1  438d1420                 lea edx, [r8 + r12]
000480b5  4133d2                   xor edx, r10d
000480b8  69c220080000             imul eax, edx, 0x820
000480be  03c8                     add ecx, eax
000480c0  8bc2                     mov eax, edx
000480c2  c1e802                   shr eax, 2
000480c5  03c8                     add ecx, eax
000480c7  33d1                     xor edx, ecx
000480c9  6683459302               add word ptr [rbp - 0x6d], 2
000480ce  e98ffcffff               jmp 0x47d62
000480d3  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
000480d8  41bd01000000             mov r13d, 1
000480de  6683459302               add word ptr [rbp - 0x6d], 2
000480e3  e97afcffff               jmp 0x47d62
000480e8  418bd1                   mov edx, r9d
000480eb  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
000480f0  41bd01000000             mov r13d, 1
000480f6  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
000480fa  6683459302               add word ptr [rbp - 0x6d], 2
000480ff  e95efcffff               jmp 0x47d62
00048104  488b45bf                 mov rax, qword ptr [rbp - 0x41]
00048108  41bd01000000             mov r13d, 1
0004810e  224da7                   and cl, byte ptr [rbp - 0x59]
00048111  80e13f                   and cl, 0x3f
00048114  448800                   mov byte ptr [rax], r8b
00048117  44885801                 mov byte ptr [rax + 1], r11b
0004811b  44884002                 mov byte ptr [rax + 2], r8b
0004811f  4c8b45b7                 mov r8, qword ptr [rbp - 0x49]
00048123  44885803                 mov byte ptr [rax + 3], r11b
00048127  4883c004                 add rax, 4
0004812b  488945bf                 mov qword ptr [rbp - 0x41], rax
0004812f  418bc3                   mov eax, r11d
00048132  c1e810                   shr eax, 0x10
00048135  418800                   mov byte ptr [r8], al
00048138  41884001                 mov byte ptr [r8 + 1], al
0004813c  4983c002                 add r8, 2
00048140  488b45af                 mov rax, qword ptr [rbp - 0x51]
00048144  4c8945b7                 mov qword ptr [rbp - 0x49], r8
00048148  8808                     mov byte ptr [rax], cl
0004814a  884801                   mov byte ptr [rax + 1], cl
0004814d  4883c002                 add rax, 2
00048151  488945af                 mov qword ptr [rbp - 0x51], rax
00048155  e908fcffff               jmp 0x47d62
0004815a  458b5804                 mov r11d, dword ptr [r8 + 4]
0004815e  418bcb                   mov ecx, r11d
00048161  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00048165  450fb7c3                 movzx r8d, r11w
00048169  83459703                 add dword ptr [rbp - 0x69], 3
0004816d  4883c606                 add rsi, 6
00048171  c1e918                   shr ecx, 0x18
00048174  6641c1e808               shr r8w, 8
00048179  4889759f                 mov qword ptr [rbp - 0x61], rsi
0004817d  44396d67                 cmp dword ptr [rbp + 0x67], r13d
00048181  7481                     je 0x48104
00048183  448b6d6f                 mov r13d, dword ptr [rbp + 0x6f]
00048187  450fb6e0                 movzx r12d, r8b
0004818b  4863c3                   movsxd rax, ebx
0004818e  ffc3                     inc ebx
00048190  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048195  4863c3                   movsxd rax, ebx
00048198  ffc3                     inc ebx
0004819a  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
0004819f  83fb04                   cmp ebx, 4
000481a2  0f8559feffff             jne 0x48001
000481a8  33db                     xor ebx, ebx
000481aa  4585ed                   test r13d, r13d
000481ad  0f8451fdffff             je 0x47f04
000481b3  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
000481b6  418bc1                   mov eax, r9d
000481b9  4569d120080000           imul r10d, r9d, 0x820
000481c0  418bf9                   mov edi, r9d
000481c3  c1e802                   shr eax, 2
000481c6  4403d0                   add r10d, eax
000481c9  4103ca                   add ecx, r10d
000481cc  4433c9                   xor r9d, ecx
000481cf  b907020000               mov ecx, 0x207
000481d4  66394d91                 cmp word ptr [rbp - 0x6f], cx
000481d8  0f85bcfdffff             jne 0x47f9a
000481de  0fb7458f                 movzx eax, word ptr [rbp - 0x71]
000481e2  663bc1                   cmp ax, cx
000481e5  0f841bfeffff             je 0x48006
000481eb  0fb6558f                 movzx edx, byte ptr [rbp - 0x71]
000481ef  8bc8                     mov ecx, eax
000481f1  c1e908                   shr ecx, 8
000481f4  4103d2                   add edx, r10d
000481f7  33d7                     xor edx, edi
000481f9  69c220080000             imul eax, edx, 0x820
000481ff  03c8                     add ecx, eax
00048201  8bc2                     mov eax, edx
00048203  c1e802                   shr eax, 2
00048206  03c8                     add ecx, eax
00048208  33d1                     xor edx, ecx
0004820a  e98efdffff               jmp 0x47f9d
0004820f  0f857ffbffff             jne 0x47d94
00048215  66453b7a0c               cmp r15w, word ptr [r10 + 0xc]
0004821a  0f8274fbffff             jb 0x47d94
00048220  66453b7a0e               cmp r15w, word ptr [r10 + 0xe]
00048225  0f8769fbffff             ja 0x47d94
0004822b  488b4547                 mov rax, qword ptr [rbp + 0x47]
0004822f  410fb74a08               movzx ecx, word ptr [r10 + 8]
00048234  488b4028                 mov rax, qword ptr [rax + 0x28]
00048238  4c8d04c8                 lea r8, [rax + rcx*8]
0004823c  410fb7420a               movzx eax, word ptr [r10 + 0xa]
00048241  85c0                     test eax, eax
00048243  0f844bfbffff             je 0x47d94
00048249  0f1f8000000000           nop dword ptr [rax]
00048250  66453938                 cmp word ptr [r8], r15w
00048254  7612                     jbe 0x48268
00048256  4983c008                 add r8, 8
0004825a  83e801                   sub eax, 1
0004825d  75f1                     jne 0x48250
0004825f  e930fbffff               jmp 0x47d94
00048264  66453938                 cmp word ptr [r8], r15w
00048268  0f8526fbffff             jne 0x47d94
0004826e  410fb74802               movzx ecx, word ptr [r8 + 2]
00048273  6685c9                   test cx, cx
00048276  0f844a010000             je 0x483c6
0004827c  66413bce                 cmp cx, r14w
00048280  740e                     je 0x48290
00048282  4983c008                 add r8, 8
00048286  83e801                   sub eax, 1
00048289  75d9                     jne 0x48264
0004828b  e904fbffff               jmp 0x47d94
00048290  418b4804                 mov ecx, dword ptr [r8 + 4]
00048294  4883c606                 add rsi, 6
00048298  83459703                 add dword ptr [rbp - 0x69], 3
0004829c  448bd1                   mov r10d, ecx
0004829f  448b7567                 mov r14d, dword ptr [rbp + 0x67]
000482a3  440fb7c1                 movzx r8d, cx
000482a7  41c1ea18                 shr r10d, 0x18
000482ab  6641c1e808               shr r8w, 8
000482b0  4889759f                 mov qword ptr [rbp - 0x61], rsi
000482b4  4585f6                   test r14d, r14d
000482b7  0f84c9000000             je 0x48386
000482bd  4863c3                   movsxd rax, ebx
000482c0  ffc3                     inc ebx
000482c2  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
000482c7  4863c3                   movsxd rax, ebx
000482ca  ffc3                     inc ebx
000482cc  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
000482d0  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
000482d5  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
000482d9  83fb04                   cmp ebx, 4
000482dc  0f859b000000             jne 0x4837d
000482e2  33db                     xor ebx, ebx
000482e4  395d6f                   cmp dword ptr [rbp + 0x6f], ebx
000482e7  753f                     jne 0x48328
000482e9  41c1c103                 rol r9d, 3
000482ed  b907020000               mov ecx, 0x207
000482f2  418bc1                   mov eax, r9d
000482f5  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
000482f9  66394d91                 cmp word ptr [rbp - 0x6f], cx
000482fd  740c                     je 0x4830b
000482ff  66ff4593                 inc word ptr [rbp - 0x6d]
00048303  418bd1                   mov edx, r9d
00048306  e91f0a0000               jmp 0x48d2a
0004830b  663bf9                   cmp di, cx
0004830e  746d                     je 0x4837d
00048310  418bd4                   mov edx, r12d
00048313  33d0                     xor edx, eax
00048315  8bc7                     mov eax, edi
00048317  c1e808                   shr eax, 8
0004831a  c1c203                   rol edx, 3
0004831d  33d0                     xor edx, eax
0004831f  66ff4593                 inc word ptr [rbp - 0x6d]
00048323  e9020a0000               jmp 0x48d2a
00048328  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
0004832b  418bc1                   mov eax, r9d
0004832e  4569c120080000           imul r8d, r9d, 0x820
00048335  458bd1                   mov r10d, r9d
00048338  c1e802                   shr eax, 2
0004833b  4403c0                   add r8d, eax
0004833e  4103c8                   add ecx, r8d
00048341  4433c9                   xor r9d, ecx
00048344  b907020000               mov ecx, 0x207
00048349  66394d91                 cmp word ptr [rbp - 0x6f], cx
0004834d  740c                     je 0x4835b
0004834f  66ff4593                 inc word ptr [rbp - 0x6d]
00048353  418bd1                   mov edx, r9d
00048356  e9cf090000               jmp 0x48d2a
0004835b  663bf9                   cmp di, cx
0004835e  741d                     je 0x4837d
00048360  438d1420                 lea edx, [r8 + r12]
00048364  8bcf                     mov ecx, edi
00048366  4133d2                   xor edx, r10d
00048369  c1e908                   shr ecx, 8
0004836c  69c220080000             imul eax, edx, 0x820
00048372  03c8                     add ecx, eax
00048374  8bc2                     mov eax, edx
00048376  c1e802                   shr eax, 2
00048379  03c8                     add ecx, eax
0004837b  33d1                     xor edx, ecx
0004837d  66ff4593                 inc word ptr [rbp - 0x6d]
00048381  e9a4090000               jmp 0x48d2a
00048386  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
0004838a  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
0004838e  0fb645a7                 movzx eax, byte ptr [rbp - 0x59]
00048392  4122c2                   and al, r10b
00048395  458807                   mov byte ptr [r15], r8b
00048398  243f                     and al, 0x3f
0004839a  41884f01                 mov byte ptr [r15 + 1], cl
0004839e  4983c702                 add r15, 2
000483a2  c1e910                   shr ecx, 0x10
000483a5  41884d00                 mov byte ptr [r13], cl
000483a9  49ffc5                   inc r13
000483ac  488b4daf                 mov rcx, qword ptr [rbp - 0x51]
000483b0  4c897dbf                 mov qword ptr [rbp - 0x41], r15
000483b4  4c896db7                 mov qword ptr [rbp - 0x49], r13
000483b8  8801                     mov byte ptr [rcx], al
000483ba  48ffc1                   inc rcx
000483bd  48894daf                 mov qword ptr [rbp - 0x51], rcx
000483c1  e96c090000               jmp 0x48d32
000483c6  418b4804                 mov ecx, dword ptr [r8 + 4]
000483ca  4883c604                 add rsi, 4
000483ce  83459702                 add dword ptr [rbp - 0x69], 2
000483d2  8bc1                     mov eax, ecx
000483d4  448b7567                 mov r14d, dword ptr [rbp + 0x67]
000483d8  440fb7c1                 movzx r8d, cx
000483dc  c1e818                   shr eax, 0x18
000483df  6641c1e808               shr r8w, 8
000483e4  4889759f                 mov qword ptr [rbp - 0x61], rsi
000483e8  4585f6                   test r14d, r14d
000483eb  0f85ccfeffff             jne 0x482bd
000483f1  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
000483f5  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
000483f9  2245a7                   and al, byte ptr [rbp - 0x59]
000483fc  243f                     and al, 0x3f
000483fe  458807                   mov byte ptr [r15], r8b
00048401  41884f01                 mov byte ptr [r15 + 1], cl
00048405  4983c702                 add r15, 2
00048409  c1e910                   shr ecx, 0x10
0004840c  41884d00                 mov byte ptr [r13], cl
00048410  49ffc5                   inc r13
00048413  488b4daf                 mov rcx, qword ptr [rbp - 0x51]
00048417  4c897dbf                 mov qword ptr [rbp - 0x41], r15
0004841b  4c896db7                 mov qword ptr [rbp - 0x49], r13
0004841f  8801                     mov byte ptr [rcx], al
00048421  48ffc1                   inc rcx
00048424  48894daf                 mov qword ptr [rbp - 0x51], rcx
00048428  e905090000               jmp 0x48d32
0004842d  663bf9                   cmp di, cx
00048430  747a                     je 0x484ac
00048432  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
00048436  418bd4                   mov edx, r12d
00048439  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
0004843d  33d0                     xor edx, eax
0004843f  c1c203                   rol edx, 3
00048442  8bc7                     mov eax, edi
00048444  c1e808                   shr eax, 8
00048447  33d0                     xor edx, eax
00048449  66ff4593                 inc word ptr [rbp - 0x6d]
0004844d  e9b2000000               jmp 0x48504
00048452  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00048455  418bc1                   mov eax, r9d
00048458  4569c120080000           imul r8d, r9d, 0x820
0004845f  458bd1                   mov r10d, r9d
00048462  c1e802                   shr eax, 2
00048465  4403c0                   add r8d, eax
00048468  4103c8                   add ecx, r8d
0004846b  4433c9                   xor r9d, ecx
0004846e  b907020000               mov ecx, 0x207
00048473  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048477  7411                     je 0x4848a
00048479  66ff4593                 inc word ptr [rbp - 0x6d]
0004847d  418bd1                   mov edx, r9d
00048480  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
00048484  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00048488  eb7a                     jmp 0x48504
0004848a  663bf9                   cmp di, cx
0004848d  741d                     je 0x484ac
0004848f  438d1420                 lea edx, [r8 + r12]
00048493  8bcf                     mov ecx, edi
00048495  4133d2                   xor edx, r10d
00048498  c1e908                   shr ecx, 8
0004849b  69c220080000             imul eax, edx, 0x820
000484a1  03c8                     add ecx, eax
000484a3  8bc2                     mov eax, edx
000484a5  c1e802                   shr eax, 2
000484a8  03c8                     add ecx, eax
000484aa  33d1                     xor edx, ecx
000484ac  66ff4593                 inc word ptr [rbp - 0x6d]
000484b0  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
000484b4  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
000484b8  eb4a                     jmp 0x48504
000484ba  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
000484be  410fb7c3                 movzx eax, r11w
000484c2  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
000484c6  66c1e808                 shr ax, 8
000484ca  418807                   mov byte ptr [r15], al
000484cd  418bc3                   mov eax, r11d
000484d0  45885f01                 mov byte ptr [r15 + 1], r11b
000484d4  4983c702                 add r15, 2
000484d8  c1e810                   shr eax, 0x10
000484db  41884500                 mov byte ptr [r13], al
000484df  49ffc5                   inc r13
000484e2  488b45af                 mov rax, qword ptr [rbp - 0x51]
000484e6  41c1eb18                 shr r11d, 0x18
000484ea  44225da7                 and r11b, byte ptr [rbp - 0x59]
000484ee  4180e33f                 and r11b, 0x3f
000484f2  4c897dbf                 mov qword ptr [rbp - 0x41], r15
000484f6  448818                   mov byte ptr [rax], r11b
000484f9  48ffc0                   inc rax
000484fc  488945af                 mov qword ptr [rbp - 0x51], rax
00048500  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048504  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00048508  8b4597                   mov eax, dword ptr [rbp - 0x69]
0004850b  4883c602                 add rsi, 2
0004850f  ffc0                     inc eax
00048511  4889759f                 mov qword ptr [rbp - 0x61], rsi
00048515  894597                   mov dword ptr [rbp - 0x69], eax
00048518  e918080000               jmp 0x48d35
0004851d  410fb6c0                 movzx eax, r8b
00048521  ffc8                     dec eax
00048523  83f80a                   cmp eax, 0xa
00048526  0f87e0070000             ja 0x48d0c
0004852c  4898                     cdqe
0004852e  488d0dcb7afbff           lea rcx, [rip - 0x48535]
00048535  8b8c81948e0400           mov ecx, dword ptr [rcx + rax*4 + 0x48e94]
0004853c  488d05bd7afbff           lea rax, [rip - 0x48543]
00048543  4803c8                   add rcx, rax
00048546  ffe1                     jmp rcx
00048548  448b7567                 mov r14d, dword ptr [rbp + 0x67]
0004854c  4585f6                   test r14d, r14d
0004854f  0f85bb070000             jne 0x48d10
00048555  4c3bad87000000           cmp r13, qword ptr [rbp + 0x87]
0004855c  7609                     jbe 0x48567
0004855e  410075ff                 add byte ptr [r13 - 1], sil
00048562  e9a9070000               jmp 0x48d10
00048567  41c1eb10                 shr r11d, 0x10
0004856b  45885d00                 mov byte ptr [r13], r11b
0004856f  49ffc5                   inc r13
00048572  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048576  e995070000               jmp 0x48d10
0004857b  837d6700                 cmp dword ptr [rbp + 0x67], 0
0004857f  4c8d157a7afbff           lea r10, [rip - 0x48586]
00048586  410fb6c3                 movzx eax, r11b
0004858a  410fb6f3                 movzx esi, r11b
0004858e  410fb7848270a43500       movzx eax, word ptr [r10 + rax*4 + 0x35a470]
00048597  498d0c86                 lea rcx, [r14 + rax*4]
0004859b  0f84f3000000             je 0x48694
000485a1  440fb701                 movzx r8d, word ptr [rcx]
000485a5  4863c3                   movsxd rax, ebx
000485a8  410fb7c8                 movzx ecx, r8w
000485ac  ffc3                     inc ebx
000485ae  66c1e908                 shr cx, 8
000485b2  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
000485b6  4863c3                   movsxd rax, ebx
000485b9  ffc3                     inc ebx
000485bb  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
000485c0  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
000485c5  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
000485c9  83fb04                   cmp ebx, 4
000485cc  0f85b8000000             jne 0x4868a
000485d2  33c0                     xor eax, eax
000485d4  8bd8                     mov ebx, eax
000485d6  39456f                   cmp dword ptr [rbp + 0x6f], eax
000485d9  754b                     jne 0x48626
000485db  41c1c103                 rol r9d, 3
000485df  b907020000               mov ecx, 0x207
000485e4  418bc1                   mov eax, r9d
000485e7  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
000485eb  66394d91                 cmp word ptr [rbp - 0x6f], cx
000485ef  7410                     je 0x48601
000485f1  66ff4593                 inc word ptr [rbp - 0x6d]
000485f5  418bd1                   mov edx, r9d
000485f8  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
000485fc  e9d7000000               jmp 0x486d8
00048601  663bf9                   cmp di, cx
00048604  0f8480000000             je 0x4868a
0004860a  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
0004860e  418bd4                   mov edx, r12d
00048611  33d0                     xor edx, eax
00048613  8bc7                     mov eax, edi
00048615  c1e808                   shr eax, 8
00048618  c1c203                   rol edx, 3
0004861b  33d0                     xor edx, eax
0004861d  66ff4593                 inc word ptr [rbp - 0x6d]
00048621  e9b2000000               jmp 0x486d8
00048626  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00048629  418bc1                   mov eax, r9d
0004862c  4569c120080000           imul r8d, r9d, 0x820
00048633  458bd1                   mov r10d, r9d
00048636  c1e802                   shr eax, 2
00048639  4403c0                   add r8d, eax
0004863c  4103c8                   add ecx, r8d
0004863f  4433c9                   xor r9d, ecx
00048642  b907020000               mov ecx, 0x207
00048647  66394d91                 cmp word ptr [rbp - 0x6f], cx
0004864b  7414                     je 0x48661
0004864d  66ff4593                 inc word ptr [rbp - 0x6d]
00048651  4c8d15a879fbff           lea r10, [rip - 0x48658]
00048658  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
0004865c  418bd1                   mov edx, r9d
0004865f  eb77                     jmp 0x486d8
00048661  663bf9                   cmp di, cx
00048664  741d                     je 0x48683
00048666  438d1420                 lea edx, [r8 + r12]
0004866a  8bcf                     mov ecx, edi
0004866c  4133d2                   xor edx, r10d
0004866f  c1e908                   shr ecx, 8
00048672  69c220080000             imul eax, edx, 0x820
00048678  03c8                     add ecx, eax
0004867a  8bc2                     mov eax, edx
0004867c  c1e802                   shr eax, 2
0004867f  03c8                     add ecx, eax
00048681  33d1                     xor edx, ecx
00048683  4c8d157679fbff           lea r10, [rip - 0x4868a]
0004868a  66ff4593                 inc word ptr [rbp - 0x6d]
0004868e  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
00048692  eb44                     jmp 0x486d8
00048694  0fb64101                 movzx eax, byte ptr [rcx + 1]
00048698  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
0004869c  418807                   mov byte ptr [r15], al
0004869f  0fb601                   movzx eax, byte ptr [rcx]
000486a2  41884701                 mov byte ptr [r15 + 1], al
000486a6  4983c702                 add r15, 2
000486aa  0fb64102                 movzx eax, byte ptr [rcx + 2]
000486ae  41884500                 mov byte ptr [r13], al
000486b2  49ffc5                   inc r13
000486b5  0fb64103                 movzx eax, byte ptr [rcx + 3]
000486b9  2245a7                   and al, byte ptr [rbp - 0x59]
000486bc  243f                     and al, 0x3f
000486be  4c897dbf                 mov qword ptr [rbp - 0x41], r15
000486c2  418803                   mov byte ptr [r11], al
000486c5  49ffc3                   inc r11
000486c8  488b4547                 mov rax, qword ptr [rbp + 0x47]
000486cc  4c896db7                 mov qword ptr [rbp - 0x49], r13
000486d0  4c895daf                 mov qword ptr [rbp - 0x51], r11
000486d4  4c8b7008                 mov r14, qword ptr [rax + 8]
000486d8  410fb784b272a43500       movzx eax, word ptr [r10 + rsi*4 + 0x35a472]
000486e1  450fb70486               movzx r8d, word ptr [r14 + rax*4]
000486e6  498d0c86                 lea rcx, [r14 + rax*4]
000486ea  410fb7c0                 movzx eax, r8w
000486ee  66c1e808                 shr ax, 8
000486f2  3c02                     cmp al, 2
000486f4  0f8574010000             jne 0x4886e
000486fa  4c63d3                   movsxd r10, ebx
000486fd  0f1f00                   nop dword ptr [rax]
00048700  837d6700                 cmp dword ptr [rbp + 0x67], 0
00048704  488d05f578fbff           lea rax, [rip - 0x4870b]
0004870b  0fb631                   movzx esi, byte ptr [rcx]
0004870e  0fb784b070a43500         movzx eax, word ptr [rax + rsi*4 + 0x35a470]
00048716  410fb70c86               movzx ecx, word ptr [r14 + rax*4]
0004871b  4d8d0486                 lea r8, [r14 + rax*4]
0004871f  0f84de000000             je 0x48803
00048725  0fb7c1                   movzx eax, cx
00048728  83c302                   add ebx, 2
0004872b  66c1e808                 shr ax, 8
0004872f  428844158f               mov byte ptr [rbp + r10 - 0x71], al
00048734  42884c1590               mov byte ptr [rbp + r10 - 0x70], cl
00048739  4983c202                 add r10, 2
0004873d  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048742  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048746  4983fa04                 cmp r10, 4
0004874a  0f85a9000000             jne 0x487f9
00048750  33c0                     xor eax, eax
00048752  8bd8                     mov ebx, eax
00048754  448bd0                   mov r10d, eax
00048757  39456f                   cmp dword ptr [rbp + 0x6f], eax
0004875a  7547                     jne 0x487a3
0004875c  41c1c103                 rol r9d, 3
00048760  b907020000               mov ecx, 0x207
00048765  418bc1                   mov eax, r9d
00048768  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
0004876c  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048770  7410                     je 0x48782
00048772  66ff4593                 inc word ptr [rbp - 0x6d]
00048776  418bd1                   mov edx, r9d
00048779  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
0004877d  e9bc000000               jmp 0x4883e
00048782  663bf9                   cmp di, cx
00048785  7472                     je 0x487f9
00048787  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
0004878b  418bd4                   mov edx, r12d
0004878e  33d0                     xor edx, eax
00048790  8bc7                     mov eax, edi
00048792  c1e808                   shr eax, 8
00048795  c1c203                   rol edx, 3
00048798  33d0                     xor edx, eax
0004879a  66ff4593                 inc word ptr [rbp - 0x6d]
0004879e  e99b000000               jmp 0x4883e
000487a3  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
000487a6  418bc1                   mov eax, r9d
000487a9  4569c120080000           imul r8d, r9d, 0x820
000487b0  458bd9                   mov r11d, r9d
000487b3  c1e802                   shr eax, 2
000487b6  4403c0                   add r8d, eax
000487b9  4103c8                   add ecx, r8d
000487bc  4433c9                   xor r9d, ecx
000487bf  b907020000               mov ecx, 0x207
000487c4  66394d91                 cmp word ptr [rbp - 0x6f], cx
000487c8  740d                     je 0x487d7
000487ca  66ff4593                 inc word ptr [rbp - 0x6d]
000487ce  418bd1                   mov edx, r9d
000487d1  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
000487d5  eb67                     jmp 0x4883e
000487d7  663bf9                   cmp di, cx
000487da  741d                     je 0x487f9
000487dc  438d1420                 lea edx, [r8 + r12]
000487e0  8bcf                     mov ecx, edi
000487e2  4133d3                   xor edx, r11d
000487e5  c1e908                   shr ecx, 8
000487e8  69c220080000             imul eax, edx, 0x820
000487ee  03c8                     add ecx, eax
000487f0  8bc2                     mov eax, edx
000487f2  c1e802                   shr eax, 2
000487f5  03c8                     add ecx, eax
000487f7  33d1                     xor edx, ecx
000487f9  66ff4593                 inc word ptr [rbp - 0x6d]
000487fd  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
00048801  eb3b                     jmp 0x4883e
00048803  66c1e908                 shr cx, 8
00048807  41880f                   mov byte ptr [r15], cl
0004880a  410fb600                 movzx eax, byte ptr [r8]
0004880e  41884701                 mov byte ptr [r15 + 1], al
00048812  4983c702                 add r15, 2
00048816  410fb64002               movzx eax, byte ptr [r8 + 2]
0004881b  41884500                 mov byte ptr [r13], al
0004881f  49ffc5                   inc r13
00048822  410fb64003               movzx eax, byte ptr [r8 + 3]
00048827  2245a7                   and al, byte ptr [rbp - 0x59]
0004882a  243f                     and al, 0x3f
0004882c  418803                   mov byte ptr [r11], al
0004882f  49ffc3                   inc r11
00048832  488b4547                 mov rax, qword ptr [rbp + 0x47]
00048836  4c895daf                 mov qword ptr [rbp - 0x51], r11
0004883a  4c8b7008                 mov r14, qword ptr [rax + 8]
0004883e  488d05bb77fbff           lea rax, [rip - 0x48845]
00048845  0fb784b072a43500         movzx eax, word ptr [rax + rsi*4 + 0x35a472]
0004884d  450fb70486               movzx r8d, word ptr [r14 + rax*4]
00048852  498d0c86                 lea rcx, [r14 + rax*4]
00048856  410fb7c0                 movzx eax, r8w
0004885a  66c1e808                 shr ax, 8
0004885e  3c02                     cmp al, 2
00048860  0f849afeffff             je 0x48700
00048866  4c896db7                 mov qword ptr [rbp - 0x49], r13
0004886a  4c897dbf                 mov qword ptr [rbp - 0x41], r15
0004886e  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048872  4585f6                   test r14d, r14d
00048875  7460                     je 0x488d7
00048877  4863c3                   movsxd rax, ebx
0004887a  410fb7c8                 movzx ecx, r8w
0004887e  ffc3                     inc ebx
00048880  66c1e908                 shr cx, 8
00048884  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
00048888  4863c3                   movsxd rax, ebx
0004888b  ffc3                     inc ebx
0004888d  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048892  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048897  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
0004889b  83fb04                   cmp ebx, 4
0004889e  0f8562040000             jne 0x48d06
000488a4  33c0                     xor eax, eax
000488a6  8bd8                     mov ebx, eax
000488a8  39456f                   cmp dword ptr [rbp + 0x6f], eax
000488ab  0f8503040000             jne 0x48cb4
000488b1  41c1c103                 rol r9d, 3
000488b5  b907020000               mov ecx, 0x207
000488ba  418bc1                   mov eax, r9d
000488bd  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
000488c1  66394d91                 cmp word ptr [rbp - 0x6f], cx
000488c5  0f84cf030000             je 0x48c9a
000488cb  66ff4593                 inc word ptr [rbp - 0x6d]
000488cf  418bd1                   mov edx, r9d
000488d2  e939040000               jmp 0x48d10
000488d7  6641c1e808               shr r8w, 8
000488dc  458807                   mov byte ptr [r15], r8b
000488df  0fb601                   movzx eax, byte ptr [rcx]
000488e2  41884701                 mov byte ptr [r15 + 1], al
000488e6  4983c702                 add r15, 2
000488ea  0fb64102                 movzx eax, byte ptr [rcx + 2]
000488ee  41884500                 mov byte ptr [r13], al
000488f2  49ffc5                   inc r13
000488f5  0fb64103                 movzx eax, byte ptr [rcx + 3]
000488f9  2245a7                   and al, byte ptr [rbp - 0x59]
000488fc  243f                     and al, 0x3f
000488fe  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00048902  418803                   mov byte ptr [r11], al
00048905  49ffc3                   inc r11
00048908  4c895daf                 mov qword ptr [rbp - 0x51], r11
0004890c  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048910  e9fb030000               jmp 0x48d10
00048915  837de700                 cmp dword ptr [rbp - 0x19], 0
00048919  7542                     jne 0x4895d
0004891b  448b7567                 mov r14d, dword ptr [rbp + 0x67]
0004891f  4585f6                   test r14d, r14d
00048922  0f85e8030000             jne 0x48d10
00048928  4c8b55df                 mov r10, qword ptr [rbp - 0x21]
0004892c  0fb74d93                 movzx ecx, word ptr [rbp - 0x6d]
00048930  0fb7c1                   movzx eax, cx
00048933  66c1e806                 shr ax, 6
00048937  0c80                     or al, 0x80
00048939  418802                   mov byte ptr [r10], al
0004893c  0fb6c1                   movzx eax, cl
0004893f  c0e002                   shl al, 2
00048942  0c03                     or al, 3
00048944  45884202                 mov byte ptr [r10 + 2], r8b
00048948  41884201                 mov byte ptr [r10 + 1], al
0004894c  45885a03                 mov byte ptr [r10 + 3], r11b
00048950  4983c204                 add r10, 4
00048954  4c8955df                 mov qword ptr [rbp - 0x21], r10
00048958  e9b3030000               jmp 0x48d10
0004895d  837d4f00                 cmp dword ptr [rbp + 0x4f], 0
00048961  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048965  0f85a5030000             jne 0x48d10
0004896b  4585f6                   test r14d, r14d
0004896e  7459                     je 0x489c9
00048970  4863c3                   movsxd rax, ebx
00048973  ffc3                     inc ebx
00048975  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
0004897a  4863c3                   movsxd rax, ebx
0004897d  ffc3                     inc ebx
0004897f  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
00048984  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048989  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
0004898d  83fb04                   cmp ebx, 4
00048990  0f8570030000             jne 0x48d06
00048996  33c0                     xor eax, eax
00048998  8bd8                     mov ebx, eax
0004899a  39456f                   cmp dword ptr [rbp + 0x6f], eax
0004899d  0f8511030000             jne 0x48cb4
000489a3  41c1c103                 rol r9d, 3
000489a7  b907020000               mov ecx, 0x207
000489ac  418bc1                   mov eax, r9d
000489af  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
000489b3  66394d91                 cmp word ptr [rbp - 0x6f], cx
000489b7  0f84dd020000             je 0x48c9a
000489bd  66ff4593                 inc word ptr [rbp - 0x6d]
000489c1  418bd1                   mov edx, r9d
000489c4  e947030000               jmp 0x48d10
000489c9  418bc3                   mov eax, r11d
000489cc  458807                   mov byte ptr [r15], r8b
000489cf  45885f01                 mov byte ptr [r15 + 1], r11b
000489d3  4983c702                 add r15, 2
000489d7  c1e810                   shr eax, 0x10
000489da  41884500                 mov byte ptr [r13], al
000489de  49ffc5                   inc r13
000489e1  488b45af                 mov rax, qword ptr [rbp - 0x51]
000489e5  41c1eb18                 shr r11d, 0x18
000489e9  44225da7                 and r11b, byte ptr [rbp - 0x59]
000489ed  4180e33f                 and r11b, 0x3f
000489f1  4c897dbf                 mov qword ptr [rbp - 0x41], r15
000489f5  448818                   mov byte ptr [rax], r11b
000489f8  48ffc0                   inc rax
000489fb  488945af                 mov qword ptr [rbp - 0x51], rax
000489ff  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048a03  e908030000               jmp 0x48d10
00048a08  0fb675a7                 movzx esi, byte ptr [rbp - 0x59]
00048a0c  4122f2                   and sil, r10b
00048a0f  4080cec4                 or sil, 0xc4
00048a13  4180fb01                 cmp r11b, 1
00048a17  0f87f1010000             ja 0x48c0e
00048a1d  4c8b459f                 mov r8, qword ptr [rbp - 0x61]
00048a21  4983c0fe                 add r8, -2
00048a25  4c3b4557                 cmp r8, qword ptr [rbp + 0x57]
00048a29  7223                     jb 0x48a4e
00048a2b  0f1f440000               nop dword ptr [rax + rax]
00048a30  410fb700                 movzx eax, word ptr [r8]
00048a34  418b0c86                 mov ecx, dword ptr [r14 + rax*4]
00048a38  448bd1                   mov r10d, ecx
00048a3b  0fb7c1                   movzx eax, cx
00048a3e  41c1ea18                 shr r10d, 0x18
00048a42  66c1e808                 shr ax, 8
00048a46  3c03                     cmp al, 3
00048a48  736a                     jae 0x48ab4
00048a4a  3c02                     cmp al, 2
00048a4c  7571                     jne 0x48abf
00048a4e  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048a52  4585f6                   test r14d, r14d
00048a55  0f84a0010000             je 0x48bfb
00048a5b  4863c3                   movsxd rax, ebx
00048a5e  ffc3                     inc ebx
00048a60  c644058fff               mov byte ptr [rbp + rax - 0x71], 0xff
00048a65  4863c3                   movsxd rax, ebx
00048a68  ffc3                     inc ebx
00048a6a  c644058fff               mov byte ptr [rbp + rax - 0x71], 0xff
00048a6f  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048a74  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048a78  83fb04                   cmp ebx, 4
00048a7b  0f8585020000             jne 0x48d06
00048a81  33c0                     xor eax, eax
00048a83  8bd8                     mov ebx, eax
00048a85  39456f                   cmp dword ptr [rbp + 0x6f], eax
00048a88  0f8526020000             jne 0x48cb4
00048a8e  41c1c103                 rol r9d, 3
00048a92  b907020000               mov ecx, 0x207
00048a97  418bc1                   mov eax, r9d
00048a9a  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00048a9e  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048aa2  0f84f2010000             je 0x48c9a
00048aa8  66ff4593                 inc word ptr [rbp - 0x6d]
00048aac  418bd1                   mov edx, r9d
00048aaf  e95c020000               jmp 0x48d10
00048ab4  0f85c0000000             jne 0x48b7a
00048aba  80f901                   cmp cl, 1
00048abd  7713                     ja 0x48ad2
00048abf  4983c0fe                 add r8, -2
00048ac3  4c3b4557                 cmp r8, qword ptr [rbp + 0x57]
00048ac7  0f8363ffffff             jae 0x48a30
00048acd  e97cffffff               jmp 0x48a4e
00048ad2  488b4547                 mov rax, qword ptr [rbp + 0x47]
00048ad6  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048ada  440fb64040               movzx r8d, byte ptr [rax + 0x40]
00048adf  0fb6c1                   movzx eax, cl
00048ae2  0fb64da7                 movzx ecx, byte ptr [rbp - 0x59]
00048ae6  4122ca                   and cl, r10b
00048ae9  6641c1e008               shl r8w, 8
00048aee  4c8b55cf                 mov r10, qword ptr [rbp - 0x31]
00048af2  80c9c4                   or cl, 0xc4
00048af5  66440bc0                 or r8w, ax
00048af9  4585f6                   test r14d, r14d
00048afc  7519                     jne 0x48b17
00048afe  4c8b6dd7                 mov r13, qword ptr [rbp - 0x29]
00048b02  0fb6c1                   movzx eax, cl
00048b05  24c6                     and al, 0xc6
00048b07  418802                   mov byte ptr [r10], al
00048b0a  0fb6c1                   movzx eax, cl
00048b0d  24e4                     and al, 0xe4
00048b0f  4388046a                 mov byte ptr [r10 + r13*2], al
00048b13  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00048b17  4584db                   test r11b, r11b
00048b1a  752a                     jne 0x48b46
00048b1c  4585f6                   test r14d, r14d
00048b1f  7548                     jne 0x48b69
00048b21  4c8b5dd7                 mov r11, qword ptr [rbp - 0x29]
00048b25  80e1c5                   and cl, 0xc5
00048b28  4585f6                   test r14d, r14d
00048b2b  4b8d045a                 lea rax, [r10 + r11*2]
00048b2f  43c6041304               mov byte ptr [r11 + r10], 4
00048b34  41880c03                 mov byte ptr [r11 + rax], cl
00048b38  498d4201                 lea rax, [r10 + 1]
00048b3c  490f45c2                 cmovne rax, r10
00048b40  488945cf                 mov qword ptr [rbp - 0x31], rax
00048b44  eb3c                     jmp 0x48b82
00048b46  b887ff0000               mov eax, 0xff87
00048b4b  664423c0                 and r8w, ax
00048b4f  4585f6                   test r14d, r14d
00048b52  7515                     jne 0x48b69
00048b54  488b4dd7                 mov rcx, qword ptr [rbp - 0x29]
00048b58  4080e6c5                 and sil, 0xc5
00048b5c  498d044a                 lea rax, [r10 + rcx*2]
00048b60  42c6041105               mov byte ptr [rcx + r10], 5
00048b65  40883401                 mov byte ptr [rcx + rax], sil
00048b69  4585f6                   test r14d, r14d
00048b6c  498d4201                 lea rax, [r10 + 1]
00048b70  490f45c2                 cmovne rax, r10
00048b74  488945cf                 mov qword ptr [rbp - 0x31], rax
00048b78  eb08                     jmp 0x48b82
00048b7a  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048b7e  440fb7c1                 movzx r8d, cx
00048b82  b8ffff0000               mov eax, 0xffff
00048b87  66443bc0                 cmp r8w, ax
00048b8b  0f84c1feffff             je 0x48a52
00048b91  410fb6c8                 movzx ecx, r8b
00048b95  4585f6                   test r14d, r14d
00048b98  0f84c9000000             je 0x48c67
00048b9e  4863c3                   movsxd rax, ebx
00048ba1  ffc3                     inc ebx
00048ba3  6641c1e808               shr r8w, 8
00048ba8  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048bad  4863c3                   movsxd rax, ebx
00048bb0  ffc3                     inc ebx
00048bb2  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
00048bb6  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048bbb  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048bbf  83fb04                   cmp ebx, 4
00048bc2  0f853e010000             jne 0x48d06
00048bc8  33c0                     xor eax, eax
00048bca  8bd8                     mov ebx, eax
00048bcc  39456f                   cmp dword ptr [rbp + 0x6f], eax
00048bcf  0f85df000000             jne 0x48cb4
00048bd5  41c1c103                 rol r9d, 3
00048bd9  b907020000               mov ecx, 0x207
00048bde  418bc1                   mov eax, r9d
00048be1  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00048be5  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048be9  0f84ab000000             je 0x48c9a
00048bef  66ff4593                 inc word ptr [rbp - 0x6d]
00048bf3  418bd1                   mov edx, r9d
00048bf6  e915010000               jmp 0x48d10
00048bfb  6641c707ffff             mov word ptr [r15], 0xffff
00048c01  4983c702                 add r15, 2
00048c05  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00048c09  e902010000               jmp 0x48d10
00048c0e  488b4547                 mov rax, qword ptr [rbp + 0x47]
00048c12  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048c16  440fb64040               movzx r8d, byte ptr [rax + 0x40]
00048c1b  6641c1e008               shl r8w, 8
00048c20  410fb6c3                 movzx eax, r11b
00048c24  66440bc0                 or r8w, ax
00048c28  4585f6                   test r14d, r14d
00048c2b  0f8560ffffff             jne 0x48b91
00048c31  488b4dcf                 mov rcx, qword ptr [rbp - 0x31]
00048c35  400fb6c6                 movzx eax, sil
00048c39  4c8b55d7                 mov r10, qword ptr [rbp - 0x29]
00048c3d  24c6                     and al, 0xc6
00048c3f  8801                     mov byte ptr [rcx], al
00048c41  400fb6c6                 movzx eax, sil
00048c45  41c6040a03               mov byte ptr [r10 + rcx], 3
00048c4a  24e4                     and al, 0xe4
00048c4c  42880451                 mov byte ptr [rcx + r10*2], al
00048c50  4080e6c5                 and sil, 0xc5
00048c54  4a8d0451                 lea rax, [rcx + r10*2]
00048c58  48ffc1                   inc rcx
00048c5b  48894dcf                 mov qword ptr [rbp - 0x31], rcx
00048c5f  410fb6c8                 movzx ecx, r8b
00048c63  41883402                 mov byte ptr [r10 + rax], sil
00048c67  0fb645c9                 movzx eax, byte ptr [rbp - 0x37]
00048c6b  6641c1e808               shr r8w, 8
00048c70  458807                   mov byte ptr [r15], r8b
00048c73  41884f01                 mov byte ptr [r15 + 1], cl
00048c77  4983c702                 add r15, 2
00048c7b  41884500                 mov byte ptr [r13], al
00048c7f  49ffc5                   inc r13
00048c82  488b45af                 mov rax, qword ptr [rbp - 0x51]
00048c86  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00048c8a  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048c8e  c60002                   mov byte ptr [rax], 2
00048c91  48ffc0                   inc rax
00048c94  488945af                 mov qword ptr [rbp - 0x51], rax
00048c98  eb76                     jmp 0x48d10
00048c9a  663bf9                   cmp di, cx
00048c9d  7467                     je 0x48d06
00048c9f  418bd4                   mov edx, r12d
00048ca2  33d0                     xor edx, eax
00048ca4  8bc7                     mov eax, edi
00048ca6  c1e808                   shr eax, 8
00048ca9  c1c203                   rol edx, 3
00048cac  33d0                     xor edx, eax
00048cae  66ff4593                 inc word ptr [rbp - 0x6d]
00048cb2  eb5c                     jmp 0x48d10
00048cb4  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00048cb7  418bc1                   mov eax, r9d
00048cba  4569c120080000           imul r8d, r9d, 0x820
00048cc1  458bd1                   mov r10d, r9d
00048cc4  c1e802                   shr eax, 2
00048cc7  4403c0                   add r8d, eax
00048cca  4103c8                   add ecx, r8d
00048ccd  4433c9                   xor r9d, ecx
00048cd0  b907020000               mov ecx, 0x207
00048cd5  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048cd9  7409                     je 0x48ce4
00048cdb  66ff4593                 inc word ptr [rbp - 0x6d]
00048cdf  418bd1                   mov edx, r9d
00048ce2  eb2c                     jmp 0x48d10
00048ce4  663bf9                   cmp di, cx
00048ce7  741d                     je 0x48d06
00048ce9  438d1420                 lea edx, [r8 + r12]
00048ced  8bcf                     mov ecx, edi
00048cef  4133d2                   xor edx, r10d
00048cf2  c1e908                   shr ecx, 8
00048cf5  69c220080000             imul eax, edx, 0x820
00048cfb  03c8                     add ecx, eax
00048cfd  8bc2                     mov eax, edx
00048cff  c1e802                   shr eax, 2
00048d02  03c8                     add ecx, eax
00048d04  33d1                     xor edx, ecx
00048d06  66ff4593                 inc word ptr [rbp - 0x6d]
00048d0a  eb04                     jmp 0x48d10
00048d0c  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048d10  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00048d14  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048d17  4883c602                 add rsi, 2
00048d1b  ffc0                     inc eax
00048d1d  4889759f                 mov qword ptr [rbp - 0x61], rsi
00048d21  894597                   mov dword ptr [rbp - 0x69], eax
00048d24  eb0f                     jmp 0x48d35
00048d26  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048d2a  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
00048d2e  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00048d32  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048d35  3b455f                   cmp eax, dword ptr [rbp + 0x5f]
00048d38  0f8ee2edffff             jle 0x47b20
00048d3e  4c8b55af                 mov r10, qword ptr [rbp - 0x51]
00048d42  b807020000               mov eax, 0x207
00048d47  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00048d4b  eb04                     jmp 0x48d51
00048d4d  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048d51  4585f6                   test r14d, r14d
00048d54  4c8bb42490000000         mov r14, qword ptr [rsp + 0x90]
00048d5c  0f84c9000000             je 0x48e2b

; chunk at RVA 0x48d62 (79 bytes)
00048d62  85db                     test ebx, ebx
00048d64  0f849c000000             je 0x48e06
00048d6a  663bf8                   cmp di, ax
00048d6d  0f8493000000             je 0x48e06
00048d73  4585db                   test r11d, r11d
00048d76  7539                     jne 0x48db1
00048d78  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00048d80  41c1c103                 rol r9d, 3
00048d84  410fb6c4                 movzx eax, r12b
00048d88  4433c8                   xor r9d, eax
00048d8b  0fb64590                 movzx eax, byte ptr [rbp - 0x70]
00048d8f  41c1c103                 rol r9d, 3
00048d93  4433c8                   xor r9d, eax
00048d96  488b4577                 mov rax, qword ptr [rbp + 0x77]
00048d9a  448908                   mov dword ptr [rax], r9d
00048d9d  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048da0  4881c498000000           add rsp, 0x98
00048da7  415f                     pop r15
00048da9  415d                     pop r13
00048dab  415c                     pop r12
00048dad  5e                       pop rsi
00048dae  5b                       pop rbx
00048daf  5d                       pop rbp
00048db0  c3                       ret

; chunk at RVA 0x48db1 (85 bytes)
00048db1  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00048db9  418bc1                   mov eax, r9d
00048dbc  c1e802                   shr eax, 2
00048dbf  4169c920080000           imul ecx, r9d, 0x820
00048dc6  03c8                     add ecx, eax
00048dc8  410fb6c4                 movzx eax, r12b
00048dcc  03c8                     add ecx, eax
00048dce  4133c9                   xor ecx, r9d
00048dd1  448bc9                   mov r9d, ecx
00048dd4  69c920080000             imul ecx, ecx, 0x820
00048dda  418bc1                   mov eax, r9d
00048ddd  c1e802                   shr eax, 2
00048de0  03c8                     add ecx, eax
00048de2  0fb64590                 movzx eax, byte ptr [rbp - 0x70]
00048de6  03c8                     add ecx, eax
00048de8  488b4577                 mov rax, qword ptr [rbp + 0x77]
00048dec  4433c9                   xor r9d, ecx
00048def  448908                   mov dword ptr [rax], r9d
00048df2  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048df5  4881c498000000           add rsp, 0x98
00048dfc  415f                     pop r15
00048dfe  415d                     pop r13
00048e00  415c                     pop r12
00048e02  5e                       pop rsi
00048e03  5b                       pop rbx
00048e04  5d                       pop rbp
00048e05  c3                       ret

; chunk at RVA 0x48e06 (37 bytes)
00048e06  488b4577                 mov rax, qword ptr [rbp + 0x77]
00048e0a  448bca                   mov r9d, edx
00048e0d  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00048e15  8910                     mov dword ptr [rax], edx
00048e17  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048e1a  4881c498000000           add rsp, 0x98
00048e21  415f                     pop r15
00048e23  415d                     pop r13
00048e25  415c                     pop r12
00048e27  5e                       pop rsi
00048e28  5b                       pop rbx
00048e29  5d                       pop rbp
00048e2a  c3                       ret

; chunk at RVA 0x48e2b (86 bytes)
00048e2b  488b858f000000           mov rax, qword ptr [rbp + 0x8f]
00048e32  488b8da7000000           mov rcx, qword ptr [rbp + 0xa7]
00048e39  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00048e41  4c8938                   mov qword ptr [rax], r15
00048e44  488b8597000000           mov rax, qword ptr [rbp + 0x97]
00048e4b  4c8928                   mov qword ptr [rax], r13
00048e4e  488b859f000000           mov rax, qword ptr [rbp + 0x9f]
00048e55  4c8910                   mov qword ptr [rax], r10
00048e58  488b45cf                 mov rax, qword ptr [rbp - 0x31]
00048e5c  488901                   mov qword ptr [rcx], rax
00048e5f  488b45df                 mov rax, qword ptr [rbp - 0x21]
00048e63  488b8daf000000           mov rcx, qword ptr [rbp + 0xaf]
00048e6a  488901                   mov qword ptr [rcx], rax
00048e6d  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048e70  4881c498000000           add rsp, 0x98
00048e77  415f                     pop r15
00048e79  415d                     pop r13
00048e7b  415c                     pop r12
00048e7d  5e                       pop rsi
00048e7e  5b                       pop rbx
00048e7f  5d                       pop rbp
00048e80  c3                       ret

; chunk at RVA 0x48e81 (63 bytes)
00048e81  33c0                     xor eax, eax
00048e83  4881c498000000           add rsp, 0x98
00048e8a  415f                     pop r15
00048e8c  415d                     pop r13
00048e8e  415c                     pop r12
00048e90  5e                       pop rsi
00048e91  5b                       pop rbx
00048e92  5d                       pop rbp
00048e93  c3                       ret
00048e94  48850400                 test qword ptr [rax + rax], rax
00048e98  7b85                     jnp 0x48e1f
00048e9a  0400                     add al, 0
00048e9c  088a04000c8d             or byte ptr [rdx - 0x72f3fffc], cl
00048ea2  0400                     add al, 0
00048ea4  0c8d                     or al, 0x8d
00048ea6  0400                     add al, 0
00048ea8  158904005d               adc eax, 0x5d000489
00048ead  890400                   mov dword ptr [rax + rax], eax
00048eb0  5d                       pop rbp
00048eb1  890400                   mov dword ptr [rax + rax], eax
00048eb4  5d                       pop rbp
00048eb5  890400                   mov dword ptr [rax + rax], eax
00048eb8  5d                       pop rbp
00048eb9  890400                   mov dword ptr [rax + rax], eax
00048ebc  5d                       pop rbp
00048ebd  890400                   mov dword ptr [rax + rax], eax
