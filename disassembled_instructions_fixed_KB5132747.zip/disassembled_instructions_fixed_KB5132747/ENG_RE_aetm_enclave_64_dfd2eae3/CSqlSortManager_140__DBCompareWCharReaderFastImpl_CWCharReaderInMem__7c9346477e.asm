; CSqlSortManager_140::DBCompareWCharReaderFastImpl<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x59df0, 6858 bytes in 1 chunk(s)

; chunk at RVA 0x59df0 (6858 bytes)
00059df0  4489442418               mov dword ptr [rsp + 0x18], r8d
00059df5  4889542410               mov qword ptr [rsp + 0x10], rdx
00059dfa  48894c2408               mov qword ptr [rsp + 8], rcx
00059dff  55                       push rbp
00059e00  53                       push rbx
00059e01  56                       push rsi
00059e02  57                       push rdi
00059e03  4154                     push r12
00059e05  4155                     push r13
00059e07  4156                     push r14
00059e09  4157                     push r15
00059e0b  488d6c24e9               lea rbp, [rsp - 0x17]
00059e10  4881ece8000000           sub rsp, 0xe8
00059e17  4c8b7d7f                 mov r15, qword ptr [rbp + 0x7f]
00059e1b  33c0                     xor eax, eax
00059e1d  8bd8                     mov ebx, eax
00059e1f  488945af                 mov qword ptr [rbp - 0x51], rax
00059e23  8bf8                     mov edi, eax
00059e25  488945a7                 mov qword ptr [rbp - 0x59], rax
00059e29  448bf0                   mov r14d, eax
00059e2c  894593                   mov dword ptr [rbp - 0x6d], eax
00059e2f  8bf0                     mov esi, eax
00059e31  89459f                   mov dword ptr [rbp - 0x61], eax
00059e34  41bb08000000             mov r11d, 8
00059e3a  4d8be1                   mov r12, r9
00059e3d  448bc8                   mov r9d, eax
00059e40  44895d8f                 mov dword ptr [rbp - 0x71], r11d
00059e44  418bc0                   mov eax, r8d
00059e47  44895def                 mov dword ptr [rbp - 0x11], r11d
00059e4b  83e001                   and eax, 1
00059e4e  418bc8                   mov ecx, r8d
00059e51  894503                   mov dword ptr [rbp + 3], eax
00059e54  41ba01000000             mov r10d, 1
00059e5a  c1e910                   shr ecx, 0x10
00059e5d  418bc0                   mov eax, r8d
00059e60  83e002                   and eax, 2
00059e63  448955f3                 mov dword ptr [rbp - 0xd], r10d
00059e67  8945f7                   mov dword ptr [rbp - 9], eax
00059e6a  83e103                   and ecx, 3
00059e6d  418bc0                   mov eax, r8d
00059e70  4c8bea                   mov r13, rdx
00059e73  2500000100               and eax, 0x10000
00059e78  8945df                   mov dword ptr [rbp - 0x21], eax
00059e7b  418bc0                   mov eax, r8d
00059e7e  2500000200               and eax, 0x20000
00059e83  8945cb                   mov dword ptr [rbp - 0x35], eax
00059e86  418bc0                   mov eax, r8d
00059e89  4123c3                   and eax, r11d
00059e8c  8945c3                   mov dword ptr [rbp - 0x3d], eax
00059e8f  418bc0                   mov eax, r8d
00059e92  83e003                   and eax, 3
00059e95  8d0c88                   lea ecx, [rax + rcx*4]
00059e98  488d056161faff           lea rax, [rip - 0x59e9f]
00059e9f  0fb6848833050900         movzx eax, byte ptr [rax + rcx*4 + 0x90533]
00059ea7  8845bc                   mov byte ptr [rbp - 0x44], al
00059eaa  0c18                     or al, 0x18
00059eac  8845bb                   mov byte ptr [rbp - 0x45], al
00059eaf  418b442408               mov eax, dword ptr [r12 + 8]
00059eb4  85c0                     test eax, eax
00059eb6  0f8483000000             je 0x59f3f
00059ebc  41395f08                 cmp dword ptr [r15 + 8], ebx
00059ec0  747d                     je 0x59f3f
00059ec2  488b5208                 mov rdx, qword ptr [rdx + 8]
00059ec6  498b0424                 mov rax, qword ptr [r12]
00059eca  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
00059ece  448945bf                 mov dword ptr [rbp - 0x41], r8d
00059ed2  0fb708                   movzx ecx, word ptr [rax]
00059ed5  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00059ed8  0fb7d8                   movzx ebx, ax
00059edb  48c1e810                 shr rax, 0x10
00059edf  48c1e320                 shl rbx, 0x20
00059ee3  480bd8                   or rbx, rax
00059ee6  498b07                   mov rax, qword ptr [r15]
00059ee9  48895daf                 mov qword ptr [rbp - 0x51], rbx
00059eed  0fb708                   movzx ecx, word ptr [rax]
00059ef0  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00059ef3  0fb64d96                 movzx ecx, byte ptr [rbp - 0x6a]
00059ef7  0fb65595                 movzx edx, byte ptr [rbp - 0x6b]
00059efb  48894de7                 mov qword ptr [rbp - 0x19], rcx
00059eff  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
00059f03  884d77                   mov byte ptr [rbp + 0x77], cl
00059f06  410fb6c9                 movzx ecx, r9b
00059f0a  0fb7f8                   movzx edi, ax
00059f0d  884d9b                   mov byte ptr [rbp - 0x65], cl
00059f10  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00059f13  48c1e810                 shr rax, 0x10
00059f17  48c1e720                 shl rdi, 0x20
00059f1b  894d97                   mov dword ptr [rbp - 0x69], ecx
00059f1e  480bf8                   or rdi, rax
00059f21  0fb74d6f                 movzx ecx, word ptr [rbp + 0x6f]
00059f25  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00059f28  88559c                   mov byte ptr [rbp - 0x64], dl
00059f2b  0fb7556f                 movzx edx, word ptr [rbp + 0x6f]
00059f2f  66894db7                 mov word ptr [rbp - 0x49], cx
00059f33  8945c7                   mov dword ptr [rbp - 0x39], eax
00059f36  668955b9                 mov word ptr [rbp - 0x47], dx
00059f3a  e9ef000000               jmp 0x5a02e
00059f3f  0fb64d96                 movzx ecx, byte ptr [rbp - 0x6a]
00059f43  0fb65595                 movzx edx, byte ptr [rbp - 0x6b]
00059f47  48894de7                 mov qword ptr [rbp - 0x19], rcx
00059f4b  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
00059f4f  884d77                   mov byte ptr [rbp + 0x77], cl
00059f52  0fb64d93                 movzx ecx, byte ptr [rbp - 0x6d]
00059f56  884d9b                   mov byte ptr [rbp - 0x65], cl
00059f59  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00059f5c  894d97                   mov dword ptr [rbp - 0x69], ecx
00059f5f  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00059f62  894dc7                   mov dword ptr [rbp - 0x39], ecx
00059f65  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00059f68  894dbf                   mov dword ptr [rbp - 0x41], ecx
00059f6b  0fb74d6f                 movzx ecx, word ptr [rbp + 0x6f]
00059f6f  88559c                   mov byte ptr [rbp - 0x64], dl
00059f72  0fb7556f                 movzx edx, word ptr [rbp + 0x6f]
00059f76  66894db7                 mov word ptr [rbp - 0x49], cx
00059f7a  668955b9                 mov word ptr [rbp - 0x47], dx
00059f7e  33d2                     xor edx, edx
00059f80  410fbae01b               bt r8d, 0x1b
00059f85  0f83e1150000             jae 0x5b56c
00059f8b  85c0                     test eax, eax
00059f8d  7550                     jne 0x59fdf
00059f8f  41394708                 cmp dword ptr [r15 + 8], eax
00059f93  0f84d3150000             je 0x5b56c
00059f99  488d0df42b0400           lea rcx, [rip + 0x42bf4]
00059fa0  4589542408               mov dword ptr [r12 + 8], r10d
00059fa5  49890c24                 mov qword ptr [r12], rcx
00059fa9  49894c2418               mov qword ptr [r12 + 0x18], rcx
00059fae  4989542410               mov qword ptr [r12 + 0x10], rdx
00059fb3  498b5508                 mov rdx, qword ptr [r13 + 8]
00059fb7  8b8280000000             mov eax, dword ptr [rdx + 0x80]
00059fbd  0fb7d8                   movzx ebx, ax
00059fc0  48c1e320                 shl rbx, 0x20
00059fc4  48c1e810                 shr rax, 0x10
00059fc8  480bd8                   or rbx, rax
00059fcb  48895daf                 mov qword ptr [rbp - 0x51], rbx
00059fcf  4585c9                   test r9d, r9d
00059fd2  755e                     jne 0x5a032
00059fd4  498b07                   mov rax, qword ptr [r15]
00059fd7  0fb708                   movzx ecx, word ptr [rax]
00059fda  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00059fdd  eb41                     jmp 0x5a020
00059fdf  45895708                 mov dword ptr [r15 + 8], r10d
00059fe3  488d05aa2b0400           lea rax, [rip + 0x42baa]
00059fea  498907                   mov qword ptr [r15], rax
00059fed  49894718                 mov qword ptr [r15 + 0x18], rax
00059ff1  49895710                 mov qword ptr [r15 + 0x10], rdx
00059ff5  498b5508                 mov rdx, qword ptr [r13 + 8]
00059ff9  4585c9                   test r9d, r9d
00059ffc  751c                     jne 0x5a01a
00059ffe  498b0424                 mov rax, qword ptr [r12]
0005a002  0fb708                   movzx ecx, word ptr [rax]
0005a005  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005a008  0fb7d8                   movzx ebx, ax
0005a00b  48c1e320                 shl rbx, 0x20
0005a00f  48c1e810                 shr rax, 0x10
0005a013  480bd8                   or rbx, rax
0005a016  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a01a  8b8280000000             mov eax, dword ptr [rdx + 0x80]
0005a020  0fb7f8                   movzx edi, ax
0005a023  48c1e720                 shl rdi, 0x20
0005a027  48c1e810                 shr rax, 0x10
0005a02b  480bf8                   or rdi, rax
0005a02e  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a032  4533c9                   xor r9d, r9d
0005a035  6666660f1f840000000000   nop word ptr [rax + rax]
0005a040  41837d1400               cmp dword ptr [r13 + 0x14], 0
0005a045  44894d9f                 mov dword ptr [rbp - 0x61], r9d
0005a049  0f84a3000000             je 0x5a0f2
0005a04f  4d8b4538                 mov r8, qword ptr [r13 + 0x38]
0005a053  488bc3                   mov rax, rbx
0005a056  4d85c0                   test r8, r8
0005a059  7439                     je 0x5a094
0005a05b  48c1e828                 shr rax, 0x28
0005a05f  3cfe                     cmp al, 0xfe
0005a061  7510                     jne 0x5a073
0005a063  4c8d4daf                 lea r9, [rbp - 0x51]
0005a067  498bd4                   mov rdx, r12
0005a06a  e891c3ffff               call 0x56400
0005a06f  488b5daf                 mov rbx, qword ptr [rbp - 0x51]
0005a073  488bc7                   mov rax, rdi
0005a076  48c1e828                 shr rax, 0x28
0005a07a  3cfe                     cmp al, 0xfe
0005a07c  7574                     jne 0x5a0f2
0005a07e  4d8b4538                 mov r8, qword ptr [r13 + 0x38]
0005a082  4c8d4da7                 lea r9, [rbp - 0x59]
0005a086  498bd7                   mov rdx, r15
0005a089  e872c3ffff               call 0x56400
0005a08e  488b7da7                 mov rdi, qword ptr [rbp - 0x59]
0005a092  eb5e                     jmp 0x5a0f2
0005a094  48c1e808                 shr rax, 8
0005a098  a8c0                     test al, 0xc0
0005a09a  741b                     je 0x5a0b7
0005a09c  49837c241000             cmp qword ptr [r12 + 0x10], 0
0005a0a2  7513                     jne 0x5a0b7
0005a0a4  4c8d4daf                 lea r9, [rbp - 0x51]
0005a0a8  4d8bc5                   mov r8, r13
0005a0ab  498bd4                   mov rdx, r12
0005a0ae  e87dbdffff               call 0x55e30
0005a0b3  488b5daf                 mov rbx, qword ptr [rbp - 0x51]
0005a0b7  488bc7                   mov rax, rdi
0005a0ba  48c1e808                 shr rax, 8
0005a0be  a8c0                     test al, 0xc0
0005a0c0  741a                     je 0x5a0dc
0005a0c2  49837f1000               cmp qword ptr [r15 + 0x10], 0
0005a0c7  7513                     jne 0x5a0dc
0005a0c9  4c8d4da7                 lea r9, [rbp - 0x59]
0005a0cd  4d8bc5                   mov r8, r13
0005a0d0  498bd7                   mov rdx, r15
0005a0d3  e858bdffff               call 0x55e30
0005a0d8  488b7da7                 mov rdi, qword ptr [rbp - 0x59]
0005a0dc  4881e3ff3fffff           and rbx, 0xffffffffffff3fff
0005a0e3  4881e7ff3fffff           and rdi, 0xffffffffffff3fff
0005a0ea  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a0ee  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a0f2  498b0c24                 mov rcx, qword ptr [r12]
0005a0f6  41bd40db0000             mov r13d, 0xdb40
0005a0fc  66443929                 cmp word ptr [rcx], r13w
0005a100  7527                     jne 0x5a129
0005a102  418b542408               mov edx, dword ptr [r12 + 8]
0005a107  4d8d44240e               lea r8, [r12 + 0xe]
0005a10c  493bc8                   cmp rcx, r8
0005a10f  7455                     je 0x5a166
0005a111  83fa01                   cmp edx, 1
0005a114  760c                     jbe 0x5a122
0005a116  440fb74902               movzx r9d, word ptr [rcx + 2]
0005a11b  6644894db7               mov word ptr [rbp - 0x49], r9w
0005a120  eb05                     jmp 0x5a127
0005a122  440fb74db7               movzx r9d, word ptr [rbp - 0x49]
0005a127  7750                     ja 0x5a179
0005a129  448b55c3                 mov r10d, dword ptr [rbp - 0x3d]
0005a12d  4533db                   xor r11d, r11d
0005a130  498b0f                   mov rcx, qword ptr [r15]
0005a133  66443929                 cmp word ptr [rcx], r13w
0005a137  0f8520010000             jne 0x5a25d
0005a13d  418b5708                 mov edx, dword ptr [r15 + 8]
0005a141  4d8d470e                 lea r8, [r15 + 0xe]
0005a145  493bc8                   cmp rcx, r8
0005a148  0f84a4000000             je 0x5a1f2
0005a14e  83fa01                   cmp edx, 1
0005a151  0f8692000000             jbe 0x5a1e9
0005a157  440fb74902               movzx r9d, word ptr [rcx + 2]
0005a15c  6644894db9               mov word ptr [rbp - 0x47], r9w
0005a161  e988000000               jmp 0x5a1ee
0005a166  83fa01                   cmp edx, 1
0005a169  76be                     jbe 0x5a129
0005a16b  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a170  440fb708                 movzx r9d, word ptr [rax]
0005a174  6644894db7               mov word ptr [rbp - 0x49], r9w
0005a179  41baef000000             mov r10d, 0xef
0005a17f  b800230000               mov eax, 0x2300
0005a184  4103c1                   add eax, r9d
0005a187  4533db                   xor r11d, r11d
0005a18a  66413bc2                 cmp ax, r10w
0005a18e  448b55c3                 mov r10d, dword ptr [rbp - 0x3d]
0005a192  779c                     ja 0x5a130
0005a194  418bdb                   mov ebx, r11d
0005a197  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a19b  4585d2                   test r10d, r10d
0005a19e  751c                     jne 0x5a1bc
0005a1a0  418d4102                 lea eax, [r9 + 2]
0005a1a4  0fb6d8                   movzx ebx, al
0005a1a7  48b80000000000150000     movabs rax, 0x150000000000
0005a1b1  48c1e320                 shl rbx, 0x20
0005a1b5  480bd8                   or rbx, rax
0005a1b8  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a1bc  8d42ff                   lea eax, [rdx - 1]
0005a1bf  4189442408               mov dword ptr [r12 + 8], eax
0005a1c4  493bc8                   cmp rcx, r8
0005a1c7  740d                     je 0x5a1d6
0005a1c9  488d4102                 lea rax, [rcx + 2]
0005a1cd  49890424                 mov qword ptr [r12], rax
0005a1d1  e95affffff               jmp 0x5a130
0005a1d6  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a1db  49890424                 mov qword ptr [r12], rax
0005a1df  4d895c2410               mov qword ptr [r12 + 0x10], r11
0005a1e4  e947ffffff               jmp 0x5a130
0005a1e9  440fb74db9               movzx r9d, word ptr [rbp - 0x47]
0005a1ee  766d                     jbe 0x5a25d
0005a1f0  eb12                     jmp 0x5a204
0005a1f2  83fa01                   cmp edx, 1
0005a1f5  7666                     jbe 0x5a25d
0005a1f7  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a1fb  440fb708                 movzx r9d, word ptr [rax]
0005a1ff  6644894db9               mov word ptr [rbp - 0x47], r9w
0005a204  b800230000               mov eax, 0x2300
0005a209  41bdef000000             mov r13d, 0xef
0005a20f  4103c1                   add eax, r9d
0005a212  66413bc5                 cmp ax, r13w
0005a216  7745                     ja 0x5a25d
0005a218  4c895da7                 mov qword ptr [rbp - 0x59], r11
0005a21c  498bfb                   mov rdi, r11
0005a21f  4585d2                   test r10d, r10d
0005a222  751c                     jne 0x5a240
0005a224  418d4102                 lea eax, [r9 + 2]
0005a228  0fb6f8                   movzx edi, al
0005a22b  48b80000000000150000     movabs rax, 0x150000000000
0005a235  48c1e720                 shl rdi, 0x20
0005a239  480bf8                   or rdi, rax
0005a23c  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a240  8d42ff                   lea eax, [rdx - 1]
0005a243  41894708                 mov dword ptr [r15 + 8], eax
0005a247  493bc8                   cmp rcx, r8
0005a24a  7406                     je 0x5a252
0005a24c  488d4102                 lea rax, [rcx + 2]
0005a250  eb08                     jmp 0x5a25a
0005a252  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a256  4d895f10                 mov qword ptr [r15 + 0x10], r11
0005a25a  498907                   mov qword ptr [r15], rax
0005a25d  4c8bdb                   mov r11, rbx
0005a260  4c8bef                   mov r13, rdi
0005a263  49c1eb28                 shr r11, 0x28
0005a267  49c1ed28                 shr r13, 0x28
0005a26b  4c895dcf                 mov qword ptr [rbp - 0x31], r11
0005a26f  4c896dd7                 mov qword ptr [rbp - 0x29], r13
0005a273  4180fb06                 cmp r11b, 6
0005a277  0f861f010000             jbe 0x5a39c
0005a27d  4180fd06                 cmp r13b, 6
0005a281  0f867f010000             jbe 0x5a406
0005a287  4180fb15                 cmp r11b, 0x15
0005a28b  0f8475010000             je 0x5a406
0005a291  4180fd15                 cmp r13b, 0x15
0005a295  0f846b010000             je 0x5a406
0005a29b  4c8bf3                   mov r14, rbx
0005a29e  488bf7                   mov rsi, rdi
0005a2a1  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005a2a5  b803000000               mov eax, 3
0005a2aa  41b901000000             mov r9d, 1
0005a2b0  488bd3                   mov rdx, rbx
0005a2b3  4c8bc7                   mov r8, rdi
0005a2b6  48c1ea10                 shr rdx, 0x10
0005a2ba  49c1e810                 shr r8, 0x10
0005a2be  413bd0                   cmp edx, r8d
0005a2c1  0f8592120000             jne 0x5b559
0005a2c7  33c0                     xor eax, eax
0005a2c9  4c8beb                   mov r13, rbx
0005a2cc  49c1ed28                 shr r13, 0x28
0005a2d0  4180fd14                 cmp r13b, 0x14
0005a2d4  0f96c0                   setbe al
0005a2d7  8945f3                   mov dword ptr [rbp - 0xd], eax
0005a2da  483bdf                   cmp rbx, rdi
0005a2dd  0f848c000000             je 0x5a36f
0005a2e3  4c8b5567                 mov r10, qword ptr [rbp + 0x67]
0005a2e7  418d4540                 lea eax, [r13 + 0x40]
0005a2eb  3c30                     cmp al, 0x30
0005a2ed  0f87bc100000             ja 0x5b3af
0005a2f3  418b0a                   mov ecx, dword ptr [r10]
0005a2f6  8bc1                     mov eax, ecx
0005a2f8  25ff030000               and eax, 0x3ff
0005a2fd  83f804                   cmp eax, 4
0005a300  740c                     je 0x5a30e
0005a302  81f911040400             cmp ecx, 0x40411
0005a308  0f85a1100000             jne 0x5b3af
0005a30e  0fb6cb                   movzx ecx, bl
0005a311  c1e108                   shl ecx, 8
0005a314  48c1eb08                 shr rbx, 8
0005a318  0fb6db                   movzx ebx, bl
0005a31b  480bd9                   or rbx, rcx
0005a31e  8bc2                     mov eax, edx
0005a320  400fb6cf                 movzx ecx, dil
0005a324  480bd8                   or rbx, rax
0005a327  48c1ef08                 shr rdi, 8
0005a32b  400fb6ff                 movzx edi, dil
0005a32f  c1e108                   shl ecx, 8
0005a332  480bf9                   or rdi, rcx
0005a335  418bc0                   mov eax, r8d
0005a338  480bf8                   or rdi, rax
0005a33b  48c1e310                 shl rbx, 0x10
0005a33f  4881cb02020000           or rbx, 0x202
0005a346  48c1e710                 shl rdi, 0x10
0005a34a  4881cf02020000           or rdi, 0x202
0005a351  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a355  488bcf                   mov rcx, rdi
0005a358  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a35c  488bc3                   mov rax, rbx
0005a35f  48c1e910                 shr rcx, 0x10
0005a363  48c1e810                 shr rax, 0x10
0005a367  3bc1                     cmp eax, ecx
0005a369  0f85dc110000             jne 0x5b54b
0005a36f  41ba01000000             mov r10d, 1
0005a375  4d8b442410               mov r8, qword ptr [r12 + 0x10]
0005a37a  418b442408               mov eax, dword ptr [r12 + 8]
0005a37f  4d85c0                   test r8, r8
0005a382  0f85f7100000             jne 0x5b47f
0005a388  4983042402               add qword ptr [r12], 2
0005a38d  ffc8                     dec eax
0005a38f  4189442408               mov dword ptr [r12 + 8], eax
0005a394  4533c9                   xor r9d, r9d
0005a397  e911110000               jmp 0x5b4ad
0005a39c  4584db                   test r11b, r11b
0005a39f  7565                     jne 0x5a406
0005a3a1  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005a3a6  498d44240e               lea rax, [r12 + 0xe]
0005a3ab  498b1424                 mov rdx, qword ptr [r12]
0005a3af  ffc9                     dec ecx
0005a3b1  483bd0                   cmp rdx, rax
0005a3b4  7406                     je 0x5a3bc
0005a3b6  488d4202                 lea rax, [rdx + 2]
0005a3ba  eb0e                     jmp 0x5a3ca
0005a3bc  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a3c1  49c744241000000000       mov qword ptr [r12 + 0x10], 0
0005a3ca  49890424                 mov qword ptr [r12], rax
0005a3ce  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005a3d2  41894c2408               mov dword ptr [r12 + 8], ecx
0005a3d7  85c9                     test ecx, ecx
0005a3d9  741c                     je 0x5a3f7
0005a3db  0fb708                   movzx ecx, word ptr [rax]
0005a3de  498b4008                 mov rax, qword ptr [r8 + 8]
0005a3e2  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a3e5  0fb7da                   movzx ebx, dx
0005a3e8  48c1e320                 shl rbx, 0x20
0005a3ec  48c1ea10                 shr rdx, 0x10
0005a3f0  480bda                   or rbx, rdx
0005a3f3  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a3f7  41ba01000000             mov r10d, 1
0005a3fd  458bca                   mov r9d, r10d
0005a400  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a404  eb0e                     jmp 0x5a414
0005a406  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005a40a  41ba01000000             mov r10d, 1
0005a410  448b4d9f                 mov r9d, dword ptr [rbp - 0x61]
0005a414  4584ed                   test r13b, r13b
0005a417  7552                     jne 0x5a46b
0005a419  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005a41d  498d470e                 lea rax, [r15 + 0xe]
0005a421  498b17                   mov rdx, qword ptr [r15]
0005a424  ffc9                     dec ecx
0005a426  483bd0                   cmp rdx, rax
0005a429  7406                     je 0x5a431
0005a42b  488d4202                 lea rax, [rdx + 2]
0005a42f  eb0c                     jmp 0x5a43d
0005a431  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a435  49c7471000000000         mov qword ptr [r15 + 0x10], 0
0005a43d  498907                   mov qword ptr [r15], rax
0005a440  41894f08                 mov dword ptr [r15 + 8], ecx
0005a444  85c9                     test ecx, ecx
0005a446  741c                     je 0x5a464
0005a448  0fb708                   movzx ecx, word ptr [rax]
0005a44b  498b4008                 mov rax, qword ptr [r8 + 8]
0005a44f  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a452  0fb7fa                   movzx edi, dx
0005a455  48c1e720                 shl rdi, 0x20
0005a459  48c1ea10                 shr rdx, 0x10
0005a45d  480bfa                   or rdi, rdx
0005a460  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a464  458bca                   mov r9d, r10d
0005a467  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a46b  837df700                 cmp dword ptr [rbp - 9], 0
0005a46f  0f84c1000000             je 0x5a536
0005a475  837df300                 cmp dword ptr [rbp - 0xd], 0
0005a479  0f84b7000000             je 0x5a536
0005a47f  4180fb01                 cmp r11b, 1
0005a483  7559                     jne 0x5a4de
0005a485  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005a48a  498d44240e               lea rax, [r12 + 0xe]
0005a48f  498b1424                 mov rdx, qword ptr [r12]
0005a493  ffc9                     dec ecx
0005a495  483bd0                   cmp rdx, rax
0005a498  7406                     je 0x5a4a0
0005a49a  488d4202                 lea rax, [rdx + 2]
0005a49e  eb0e                     jmp 0x5a4ae
0005a4a0  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a4a5  49c744241000000000       mov qword ptr [r12 + 0x10], 0
0005a4ae  49890424                 mov qword ptr [r12], rax
0005a4b2  41894c2408               mov dword ptr [r12 + 8], ecx
0005a4b7  85c9                     test ecx, ecx
0005a4b9  741c                     je 0x5a4d7
0005a4bb  0fb708                   movzx ecx, word ptr [rax]
0005a4be  498b4008                 mov rax, qword ptr [r8 + 8]
0005a4c2  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a4c5  0fb7da                   movzx ebx, dx
0005a4c8  48c1e320                 shl rbx, 0x20
0005a4cc  48c1ea10                 shr rdx, 0x10
0005a4d0  480bda                   or rbx, rdx
0005a4d3  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a4d7  458bca                   mov r9d, r10d
0005a4da  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a4de  4180fd01                 cmp r13b, 1
0005a4e2  7552                     jne 0x5a536
0005a4e4  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005a4e8  498d470e                 lea rax, [r15 + 0xe]
0005a4ec  498b17                   mov rdx, qword ptr [r15]
0005a4ef  ffc9                     dec ecx
0005a4f1  483bd0                   cmp rdx, rax
0005a4f4  7406                     je 0x5a4fc
0005a4f6  488d4202                 lea rax, [rdx + 2]
0005a4fa  eb0c                     jmp 0x5a508
0005a4fc  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a500  49c7471000000000         mov qword ptr [r15 + 0x10], 0
0005a508  498907                   mov qword ptr [r15], rax
0005a50b  41894f08                 mov dword ptr [r15 + 8], ecx
0005a50f  85c9                     test ecx, ecx
0005a511  741c                     je 0x5a52f
0005a513  0fb708                   movzx ecx, word ptr [rax]
0005a516  498b4008                 mov rax, qword ptr [r8 + 8]
0005a51a  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a51d  0fb7fa                   movzx edi, dx
0005a520  48c1e720                 shl rdi, 0x20
0005a524  48c1ea10                 shr rdx, 0x10
0005a528  480bfa                   or rdi, rdx
0005a52b  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a52f  458bca                   mov r9d, r10d
0005a532  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a536  4180fb02                 cmp r11b, 2
0005a53a  0f85c8000000             jne 0x5a608
0005a540  458b5c2408               mov r11d, dword ptr [r12 + 8]
0005a545  4d8d4c240e               lea r9, [r12 + 0xe]
0005a54a  488bc3                   mov rax, rbx
0005a54d  498d54240c               lea rdx, [r12 + 0xc]
0005a552  48c1e808                 shr rax, 8
0005a556  0fb6c8                   movzx ecx, al
0005a559  48c1eb20                 shr rbx, 0x20
0005a55d  48c1e108                 shl rcx, 8
0005a561  0fb6c3                   movzx eax, bl
0005a564  480bc8                   or rcx, rax
0005a567  488b455f                 mov rax, qword ptr [rbp + 0x5f]
0005a56b  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
0005a572  448b0488                 mov r8d, dword ptr [rax + rcx*4]
0005a576  440fb71488               movzx r10d, word ptr [rax + rcx*4]
0005a57b  498b0424                 mov rax, qword ptr [r12]
0005a57f  41c1e810                 shr r8d, 0x10
0005a583  493bc1                   cmp rax, r9
0005a586  741c                     je 0x5a5a4
0005a588  498b4c2410               mov rcx, qword ptr [r12 + 0x10]
0005a58d  4883c002                 add rax, 2
0005a591  49890424                 mov qword ptr [r12], rax
0005a595  66448912                 mov word ptr [rdx], r10w
0005a599  66458901                 mov word ptr [r9], r8w
0005a59d  4885c9                   test rcx, rcx
0005a5a0  7523                     jne 0x5a5c5
0005a5a2  eb18                     jmp 0x5a5bc
0005a5a4  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a5a9  33c9                     xor ecx, ecx
0005a5ab  49894c2410               mov qword ptr [r12 + 0x10], rcx
0005a5b0  49890424                 mov qword ptr [r12], rax
0005a5b4  66448912                 mov word ptr [rdx], r10w
0005a5b8  66458901                 mov word ptr [r9], r8w
0005a5bc  498b0424                 mov rax, qword ptr [r12]
0005a5c0  4989442410               mov qword ptr [r12 + 0x10], rax
0005a5c5  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005a5c9  418d4301                 lea eax, [r11 + 1]
0005a5cd  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005a5d1  49891424                 mov qword ptr [r12], rdx
0005a5d5  4189442408               mov dword ptr [r12 + 8], eax
0005a5da  498b4008                 mov rax, qword ptr [r8 + 8]
0005a5de  428b1490                 mov edx, dword ptr [rax + r10*4]
0005a5e2  41ba01000000             mov r10d, 1
0005a5e8  0fb7da                   movzx ebx, dx
0005a5eb  458bca                   mov r9d, r10d
0005a5ee  48c1e320                 shl rbx, 0x20
0005a5f2  48c1ea10                 shr rdx, 0x10
0005a5f6  480bda                   or rbx, rdx
0005a5f9  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a5fd  33d2                     xor edx, edx
0005a5ff  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a603  448bf2                   mov r14d, edx
0005a606  eb06                     jmp 0x5a60e
0005a608  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005a60c  33d2                     xor edx, edx
0005a60e  4180fd02                 cmp r13b, 2
0005a612  0f85b9000000             jne 0x5a6d1
0005a618  458b5f08                 mov r11d, dword ptr [r15 + 8]
0005a61c  4d8d4f0e                 lea r9, [r15 + 0xe]
0005a620  488bc7                   mov rax, rdi
0005a623  48c1ef20                 shr rdi, 0x20
0005a627  48c1e808                 shr rax, 8
0005a62b  0fb6c8                   movzx ecx, al
0005a62e  48c1e108                 shl rcx, 8
0005a632  400fb6c7                 movzx eax, dil
0005a636  480bc8                   or rcx, rax
0005a639  488b455f                 mov rax, qword ptr [rbp + 0x5f]
0005a63d  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
0005a644  448b0488                 mov r8d, dword ptr [rax + rcx*4]
0005a648  440fb71488               movzx r10d, word ptr [rax + rcx*4]
0005a64d  498b07                   mov rax, qword ptr [r15]
0005a650  41c1e810                 shr r8d, 0x10
0005a654  493bc1                   cmp rax, r9
0005a657  741e                     je 0x5a677
0005a659  498b4f10                 mov rcx, qword ptr [r15 + 0x10]
0005a65d  498d570c                 lea rdx, [r15 + 0xc]
0005a661  4883c002                 add rax, 2
0005a665  498907                   mov qword ptr [r15], rax
0005a668  66448912                 mov word ptr [rdx], r10w
0005a66c  66458901                 mov word ptr [r9], r8w
0005a670  4885c9                   test rcx, rcx
0005a673  7520                     jne 0x5a695
0005a675  eb17                     jmp 0x5a68e
0005a677  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a67b  49895710                 mov qword ptr [r15 + 0x10], rdx
0005a67f  498d570c                 lea rdx, [r15 + 0xc]
0005a683  498907                   mov qword ptr [r15], rax
0005a686  66448912                 mov word ptr [rdx], r10w
0005a68a  66458901                 mov word ptr [r9], r8w
0005a68e  498b07                   mov rax, qword ptr [r15]
0005a691  49894710                 mov qword ptr [r15 + 0x10], rax
0005a695  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005a699  418d4301                 lea eax, [r11 + 1]
0005a69d  498917                   mov qword ptr [r15], rdx
0005a6a0  41894708                 mov dword ptr [r15 + 8], eax
0005a6a4  498b4508                 mov rax, qword ptr [r13 + 8]
0005a6a8  428b1490                 mov edx, dword ptr [rax + r10*4]
0005a6ac  41ba01000000             mov r10d, 1
0005a6b2  0fb7fa                   movzx edi, dx
0005a6b5  458bca                   mov r9d, r10d
0005a6b8  48c1e720                 shl rdi, 0x20
0005a6bc  48c1ea10                 shr rdx, 0x10
0005a6c0  480bfa                   or rdi, rdx
0005a6c3  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a6c7  33d2                     xor edx, edx
0005a6c9  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a6cd  8bf2                     mov esi, edx
0005a6cf  eb09                     jmp 0x5a6da
0005a6d1  4585c9                   test r9d, r9d
0005a6d4  7425                     je 0x5a6fb
0005a6d6  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005a6da  418b442408               mov eax, dword ptr [r12 + 8]
0005a6df  85c0                     test eax, eax
0005a6e1  740b                     je 0x5a6ee
0005a6e3  41837f0800               cmp dword ptr [r15 + 8], 0
0005a6e8  0f8544f9ffff             jne 0x5a032
0005a6ee  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005a6f2  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
0005a6f6  e985f8ffff               jmp 0x59f80
0005a6fb  410fb6c3                 movzx eax, r11b
0005a6ff  83f815                   cmp eax, 0x15
0005a702  0f87d5030000             ja 0x5aadd
0005a708  488d0df158faff           lea rcx, [rip - 0x5a70f]
0005a70f  8b8c81e0b70500           mov ecx, dword ptr [rcx + rax*4 + 0x5b7e0]
0005a716  488d05e358faff           lea rax, [rip - 0x5a71d]
0005a71d  4803c8                   add rcx, rax
0005a720  ffe1                     jmp rcx
0005a722  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005a726  4d8bc4                   mov r8, r12
0005a729  e892110000               call 0x5b8c0
0005a72e  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005a732  440fb7e8                 movzx r13d, ax
0005a736  33d2                     xor edx, edx
0005a738  0fb6c3                   movzx eax, bl
0005a73b  664403e8                 add r13w, ax
0005a73f  440fb7c2                 movzx r8d, dx
0005a743  44385dd7                 cmp byte ptr [rbp - 0x29], r11b
0005a747  7571                     jne 0x5a7ba
0005a749  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005a74d  4d8bc7                   mov r8, r15
0005a750  e86b110000               call 0x5b8c0
0005a755  498b0f                   mov rcx, qword ptr [r15]
0005a758  440fb7c0                 movzx r8d, ax
0005a75c  400fb6c7                 movzx eax, dil
0005a760  664403c0                 add r8w, ax
0005a764  498d470e                 lea rax, [r15 + 0xe]
0005a768  483bc8                   cmp rcx, rax
0005a76b  740c                     je 0x5a779
0005a76d  41ff4f08                 dec dword ptr [r15 + 8]
0005a771  488d4102                 lea rax, [rcx + 2]
0005a775  33d2                     xor edx, edx
0005a777  eb0e                     jmp 0x5a787
0005a779  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a77d  33d2                     xor edx, edx
0005a77f  41ff4f08                 dec dword ptr [r15 + 8]
0005a783  49895710                 mov qword ptr [r15 + 0x10], rdx
0005a787  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005a78b  4c8b4d67                 mov r9, qword ptr [rbp + 0x67]
0005a78f  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005a793  498907                   mov qword ptr [r15], rax
0005a796  85c9                     test ecx, ecx
0005a798  7424                     je 0x5a7be
0005a79a  0fb708                   movzx ecx, word ptr [rax]
0005a79d  498b4108                 mov rax, qword ptr [r9 + 8]
0005a7a1  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a7a4  0fb7fa                   movzx edi, dx
0005a7a7  48c1e720                 shl rdi, 0x20
0005a7ab  48c1ea10                 shr rdx, 0x10
0005a7af  480bfa                   or rdi, rdx
0005a7b2  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a7b6  33d2                     xor edx, edx
0005a7b8  eb04                     jmp 0x5a7be
0005a7ba  4c8b4d67                 mov r9, qword ptr [rbp + 0x67]
0005a7be  66453be8                 cmp r13w, r8w
0005a7c2  742a                     je 0x5a7ee
0005a7c4  837d8f00                 cmp dword ptr [rbp - 0x71], 0
0005a7c8  7f07                     jg 0x5a7d1
0005a7ca  4183791000               cmp dword ptr [r9 + 0x10], 0
0005a7cf  741d                     je 0x5a7ee
0005a7d1  41ba01000000             mov r10d, 1
0005a7d7  89558f                   mov dword ptr [rbp - 0x71], edx
0005a7da  66453be8                 cmp r13w, r8w
0005a7de  418bc2                   mov eax, r10d
0005a7e1  b903000000               mov ecx, 3
0005a7e6  0f47c1                   cmova eax, ecx
0005a7e9  894597                   mov dword ptr [rbp - 0x69], eax
0005a7ec  eb06                     jmp 0x5a7f4
0005a7ee  41ba01000000             mov r10d, 1
0005a7f4  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005a7f9  498d44240e               lea rax, [r12 + 0xe]
0005a7fe  498b1424                 mov rdx, qword ptr [r12]
0005a802  ffc9                     dec ecx
0005a804  483bd0                   cmp rdx, rax
0005a807  7406                     je 0x5a80f
0005a809  488d4202                 lea rax, [rdx + 2]
0005a80d  eb0c                     jmp 0x5a81b
0005a80f  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a814  33d2                     xor edx, edx
0005a816  4989542410               mov qword ptr [r12 + 0x10], rdx
0005a81b  49890424                 mov qword ptr [r12], rax
0005a81f  41894c2408               mov dword ptr [r12 + 8], ecx
0005a824  85c9                     test ecx, ecx
0005a826  741c                     je 0x5a844
0005a828  0fb708                   movzx ecx, word ptr [rax]
0005a82b  498b4108                 mov rax, qword ptr [r9 + 8]
0005a82f  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a832  0fb7da                   movzx ebx, dx
0005a835  48c1e320                 shl rbx, 0x20
0005a839  48c1ea10                 shr rdx, 0x10
0005a83d  480bda                   or rbx, rdx
0005a840  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a844  4c8b6dd7                 mov r13, qword ptr [rbp - 0x29]
0005a848  458bca                   mov r9d, r10d
0005a84b  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a84f  e98c020000               jmp 0x5aae0
0005a854  488bc2                   mov rax, rdx
0005a857  453aeb                   cmp r13b, r11b
0005a85a  754c                     jne 0x5a8a8
0005a85c  498b17                   mov rdx, qword ptr [r15]
0005a85f  498d4f0e                 lea rcx, [r15 + 0xe]
0005a863  488bc7                   mov rax, rdi
0005a866  483bd1                   cmp rdx, rcx
0005a869  7406                     je 0x5a871
0005a86b  488d4a02                 lea rcx, [rdx + 2]
0005a86f  eb0a                     jmp 0x5a87b
0005a871  498b4f10                 mov rcx, qword ptr [r15 + 0x10]
0005a875  33d2                     xor edx, edx
0005a877  49895710                 mov qword ptr [r15 + 0x10], rdx
0005a87b  41ff4f08                 dec dword ptr [r15 + 8]
0005a87f  418b5708                 mov edx, dword ptr [r15 + 8]
0005a883  49890f                   mov qword ptr [r15], rcx
0005a886  85d2                     test edx, edx
0005a888  741e                     je 0x5a8a8
0005a88a  0fb711                   movzx edx, word ptr [rcx]
0005a88d  498b4808                 mov rcx, qword ptr [r8 + 8]
0005a891  448b0491                 mov r8d, dword ptr [rcx + rdx*4]
0005a895  410fb7f8                 movzx edi, r8w
0005a899  48c1e720                 shl rdi, 0x20
0005a89d  49c1e810                 shr r8, 0x10
0005a8a1  490bf8                   or rdi, r8
0005a8a4  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a8a8  837d8f06                 cmp dword ptr [rbp - 0x71], 6
0005a8ac  7e22                     jle 0x5a8d0
0005a8ae  488bcb                   mov rcx, rbx
0005a8b1  48c1e810                 shr rax, 0x10
0005a8b5  48c1e910                 shr rcx, 0x10
0005a8b9  3bc8                     cmp ecx, eax
0005a8bb  7413                     je 0x5a8d0
0005a8bd  ba03000000               mov edx, 3
0005a8c2  c7458f06000000           mov dword ptr [rbp - 0x71], 6
0005a8c9  410f42d2                 cmovb edx, r10d
0005a8cd  895597                   mov dword ptr [rbp - 0x69], edx
0005a8d0  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005a8d5  498d44240e               lea rax, [r12 + 0xe]
0005a8da  498b1424                 mov rdx, qword ptr [r12]
0005a8de  ffc9                     dec ecx
0005a8e0  483bd0                   cmp rdx, rax
0005a8e3  7406                     je 0x5a8eb
0005a8e5  488d4202                 lea rax, [rdx + 2]
0005a8e9  eb0c                     jmp 0x5a8f7
0005a8eb  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a8f0  33d2                     xor edx, edx
0005a8f2  4989542410               mov qword ptr [r12 + 0x10], rdx
0005a8f7  49890424                 mov qword ptr [r12], rax
0005a8fb  41894c2408               mov dword ptr [r12 + 8], ecx
0005a900  85c9                     test ecx, ecx
0005a902  7420                     je 0x5a924
0005a904  0fb708                   movzx ecx, word ptr [rax]
0005a907  488b4567                 mov rax, qword ptr [rbp + 0x67]
0005a90b  488b4008                 mov rax, qword ptr [rax + 8]
0005a90f  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a912  0fb7da                   movzx ebx, dx
0005a915  48c1e320                 shl rbx, 0x20
0005a919  48c1ea10                 shr rdx, 0x10
0005a91d  480bda                   or rbx, rdx
0005a920  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a924  458bca                   mov r9d, r10d
0005a927  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a92b  e9b0010000               jmp 0x5aae0
0005a930  4c8bf3                   mov r14, rbx
0005a933  4180fd06                 cmp r13b, 6
0005a937  0f84a3010000             je 0x5aae0
0005a93d  837d8f07                 cmp dword ptr [rbp - 0x71], 7
0005a941  7f0a                     jg 0x5a94d
0005a943  758b                     jne 0x5a8d0
0005a945  837dc700                 cmp dword ptr [rbp - 0x39], 0
0005a949  7585                     jne 0x5a8d0
0005a94b  eb03                     jmp 0x5a950
0005a94d  8955bf                   mov dword ptr [rbp - 0x41], edx
0005a950  448955c7                 mov dword ptr [rbp - 0x39], r10d
0005a954  c7459703000000           mov dword ptr [rbp - 0x69], 3
0005a95b  c7458f07000000           mov dword ptr [rbp - 0x71], 7
0005a962  e969ffffff               jmp 0x5a8d0
0005a967  4180fd06                 cmp r13b, 6
0005a96b  0f846f010000             je 0x5aae0
0005a971  4180fd01                 cmp r13b, 1
0005a975  0f8465010000             je 0x5aae0
0005a97b  89542450                 mov dword ptr [rsp + 0x50], edx
0005a97f  488bc7                   mov rax, rdi
0005a982  488bcb                   mov rcx, rbx
0005a985  4c8bf2                   mov r14, rdx
0005a988  4180fd04                 cmp r13b, 4
0005a98c  4d8bcf                   mov r9, r15
0005a98f  4d8bc4                   mov r8, r12
0005a992  480f44f2                 cmove rsi, rdx
0005a996  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005a99a  48c1e820                 shr rax, 0x20
0005a99e  6689459f                 mov word ptr [rbp - 0x61], ax
0005a9a2  48c1e920                 shr rcx, 0x20
0005a9a6  66894d93                 mov word ptr [rbp - 0x6d], cx
0005a9aa  48c1e710                 shl rdi, 0x10
0005a9ae  0bf8                     or edi, eax
0005a9b0  48c1e310                 shl rbx, 0x10
0005a9b4  0bd9                     or ebx, ecx
0005a9b6  897da7                   mov dword ptr [rbp - 0x59], edi
0005a9b9  488b4d5f                 mov rcx, qword ptr [rbp + 0x5f]
0005a9bd  488d45fb                 lea rax, [rbp - 5]
0005a9c1  4889442448               mov qword ptr [rsp + 0x48], rax
0005a9c6  488d45ef                 lea rax, [rbp - 0x11]
0005a9ca  4889442440               mov qword ptr [rsp + 0x40], rax
0005a9cf  488d459f                 lea rax, [rbp - 0x61]
0005a9d3  4889442438               mov qword ptr [rsp + 0x38], rax
0005a9d8  488d4593                 lea rax, [rbp - 0x6d]
0005a9dc  4889442430               mov qword ptr [rsp + 0x30], rax
0005a9e1  488d45a7                 lea rax, [rbp - 0x59]
0005a9e5  4889442428               mov qword ptr [rsp + 0x28], rax
0005a9ea  488d45d7                 lea rax, [rbp - 0x29]
0005a9ee  4889442420               mov qword ptr [rsp + 0x20], rax
0005a9f3  895dd7                   mov dword ptr [rbp - 0x29], ebx
0005a9f6  e84569ffff               call 0x51340
0005a9fb  448bc8                   mov r9d, eax
0005a9fe  89459f                   mov dword ptr [rbp - 0x61], eax
0005aa01  8b45fb                   mov eax, dword ptr [rbp - 5]
0005aa04  83f802                   cmp eax, 2
0005aa07  0f85bc0d0000             jne 0x5b7c9
0005aa0d  8b45a7                   mov eax, dword ptr [rbp - 0x59]
0005aa10  41ba01000000             mov r10d, 1
0005aa16  8b4dd7                   mov ecx, dword ptr [rbp - 0x29]
0005aa19  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005aa1d  0fb7d9                   movzx ebx, cx
0005aa20  0fb7f8                   movzx edi, ax
0005aa23  48c1e320                 shl rbx, 0x20
0005aa27  48c1e720                 shl rdi, 0x20
0005aa2b  48c1e910                 shr rcx, 0x10
0005aa2f  48c1e810                 shr rax, 0x10
0005aa33  480bd9                   or rbx, rcx
0005aa36  480bf8                   or rdi, rax
0005aa39  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005aa3d  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005aa41  4585c9                   test r9d, r9d
0005aa44  0f8496000000             je 0x5aae0
0005aa4a  41837c240800             cmp dword ptr [r12 + 8], 0
0005aa50  0f848a000000             je 0x5aae0
0005aa56  41837f0800               cmp dword ptr [r15 + 8], 0
0005aa5b  49b802020000fffd0000     movabs r8, 0xfdff00000202
0005aa65  0f847f000000             je 0x5aaea
0005aa6b  488b4567                 mov rax, qword ptr [rbp + 0x67]
0005aa6f  488b5008                 mov rdx, qword ptr [rax + 8]
0005aa73  498b0424                 mov rax, qword ptr [r12]
0005aa77  0fb708                   movzx ecx, word ptr [rax]
0005aa7a  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005aa7d  0fb7d8                   movzx ebx, ax
0005aa80  48c1e810                 shr rax, 0x10
0005aa84  48c1e320                 shl rbx, 0x20
0005aa88  480bd8                   or rbx, rax
0005aa8b  498b07                   mov rax, qword ptr [r15]
0005aa8e  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005aa92  0fb708                   movzx ecx, word ptr [rax]
0005aa95  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005aa98  0fb7f8                   movzx edi, ax
0005aa9b  48c1e720                 shl rdi, 0x20
0005aa9f  48c1e810                 shr rax, 0x10
0005aaa3  480bf8                   or rdi, rax
0005aaa6  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005aaaa  eb3e                     jmp 0x5aaea
0005aaac  488bc3                   mov rax, rbx
0005aaaf  49b802020000fffd0000     movabs r8, 0xfdff00000202
0005aab9  48c1e820                 shr rax, 0x20
0005aabd  0fb6c8                   movzx ecx, al
0005aac0  0fb6c3                   movzx eax, bl
0005aac3  48c1e108                 shl rcx, 8
0005aac7  488bd9                   mov rbx, rcx
0005aaca  480bd8                   or rbx, rax
0005aacd  48c1e310                 shl rbx, 0x10
0005aad1  490bd8                   or rbx, r8
0005aad4  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005aad8  4c8bf3                   mov r14, rbx
0005aadb  eb0d                     jmp 0x5aaea
0005aadd  4c8bf3                   mov r14, rbx
0005aae0  49b802020000fffd0000     movabs r8, 0xfdff00000202
0005aaea  410fb6c5                 movzx eax, r13b
0005aaee  83f815                   cmp eax, 0x15
0005aaf1  0f87ab030000             ja 0x5aea2
0005aaf7  488d150255faff           lea rdx, [rip - 0x5aafe]
0005aafe  8b8c8238b80500           mov ecx, dword ptr [rdx + rax*4 + 0x5b838]
0005ab05  4803ca                   add rcx, rdx
0005ab08  ffe1                     jmp rcx
0005ab0a  453add                   cmp r11b, r13b
0005ab0d  0f8492030000             je 0x5aea5
0005ab13  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005ab17  4d8bc7                   mov r8, r15
0005ab1a  498bd5                   mov rdx, r13
0005ab1d  e89e0d0000               call 0x5b8c0
0005ab22  440fb7c0                 movzx r8d, ax
0005ab26  400fb6c7                 movzx eax, dil
0005ab2a  4403c0                   add r8d, eax
0005ab2d  837d8f00                 cmp dword ptr [rbp - 0x71], 0
0005ab31  7f07                     jg 0x5ab3a
0005ab33  41837d1000               cmp dword ptr [r13 + 0x10], 0
0005ab38  7418                     je 0x5ab52
0005ab3a  41ba01000000             mov r10d, 1
0005ab40  4585c0                   test r8d, r8d
0005ab43  7413                     je 0x5ab58
0005ab45  4533c0                   xor r8d, r8d
0005ab48  44895597                 mov dword ptr [rbp - 0x69], r10d
0005ab4c  4489458f                 mov dword ptr [rbp - 0x71], r8d
0005ab50  eb09                     jmp 0x5ab5b
0005ab52  41ba01000000             mov r10d, 1
0005ab58  4533c0                   xor r8d, r8d
0005ab5b  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005ab5f  498d470e                 lea rax, [r15 + 0xe]
0005ab63  498b17                   mov rdx, qword ptr [r15]
0005ab66  ffc9                     dec ecx
0005ab68  483bd0                   cmp rdx, rax
0005ab6b  7406                     je 0x5ab73
0005ab6d  488d4202                 lea rax, [rdx + 2]
0005ab71  eb08                     jmp 0x5ab7b
0005ab73  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005ab77  4d894710                 mov qword ptr [r15 + 0x10], r8
0005ab7b  498907                   mov qword ptr [r15], rax
0005ab7e  41894f08                 mov dword ptr [r15 + 8], ecx
0005ab82  85c9                     test ecx, ecx
0005ab84  741c                     je 0x5aba2
0005ab86  0fb708                   movzx ecx, word ptr [rax]
0005ab89  498b4508                 mov rax, qword ptr [r13 + 8]
0005ab8d  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005ab90  0fb7fa                   movzx edi, dx
0005ab93  48c1e720                 shl rdi, 0x20
0005ab97  48c1ea10                 shr rdx, 0x10
0005ab9b  480bfa                   or rdi, rdx
0005ab9e  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005aba2  458bca                   mov r9d, r10d
0005aba5  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005aba9  e900030000               jmp 0x5aeae
0005abae  453add                   cmp r11b, r13b
0005abb1  0f84ee020000             je 0x5aea5
0005abb7  837d8f06                 cmp dword ptr [rbp - 0x71], 6
0005abbb  7e0b                     jle 0x5abc8
0005abbd  44895597                 mov dword ptr [rbp - 0x69], r10d
0005abc1  c7458f06000000           mov dword ptr [rbp - 0x71], 6
0005abc8  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005abcc  498d470e                 lea rax, [r15 + 0xe]
0005abd0  498b17                   mov rdx, qword ptr [r15]
0005abd3  ffc9                     dec ecx
0005abd5  483bd0                   cmp rdx, rax
0005abd8  7406                     je 0x5abe0
0005abda  488d4202                 lea rax, [rdx + 2]
0005abde  eb0a                     jmp 0x5abea
0005abe0  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005abe4  33d2                     xor edx, edx
0005abe6  49895710                 mov qword ptr [r15 + 0x10], rdx
0005abea  498907                   mov qword ptr [r15], rax
0005abed  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005abf1  41894f08                 mov dword ptr [r15 + 8], ecx
0005abf5  85c9                     test ecx, ecx
0005abf7  74a9                     je 0x5aba2
0005abf9  0fb708                   movzx ecx, word ptr [rax]
0005abfc  458bca                   mov r9d, r10d
0005abff  498b4508                 mov rax, qword ptr [r13 + 8]
0005ac03  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005ac07  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005ac0a  0fb7fa                   movzx edi, dx
0005ac0d  48c1e720                 shl rdi, 0x20
0005ac11  48c1ea10                 shr rdx, 0x10
0005ac15  480bfa                   or rdi, rdx
0005ac18  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005ac1c  e98d020000               jmp 0x5aeae
0005ac21  488bf7                   mov rsi, rdi
0005ac24  4180fb06                 cmp r11b, 6
0005ac28  7447                     je 0x5ac71
0005ac2a  837d8f07                 cmp dword ptr [rbp - 0x71], 7
0005ac2e  7f2b                     jg 0x5ac5b
0005ac30  7506                     jne 0x5ac38
0005ac32  837dbf00                 cmp dword ptr [rbp - 0x41], 0
0005ac36  7428                     je 0x5ac60
0005ac38  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005ac3c  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005ac40  498d470e                 lea rax, [r15 + 0xe]
0005ac44  498b17                   mov rdx, qword ptr [r15]
0005ac47  ffc9                     dec ecx
0005ac49  483bd0                   cmp rdx, rax
0005ac4c  0f84f9000000             je 0x5ad4b
0005ac52  488d4202                 lea rax, [rdx + 2]
0005ac56  e920ffffff               jmp 0x5ab7b
0005ac5b  33c0                     xor eax, eax
0005ac5d  8945c7                   mov dword ptr [rbp - 0x39], eax
0005ac60  448955bf                 mov dword ptr [rbp - 0x41], r10d
0005ac64  44895597                 mov dword ptr [rbp - 0x69], r10d
0005ac68  c7458f07000000           mov dword ptr [rbp - 0x71], 7
0005ac6f  ebc7                     jmp 0x5ac38
0005ac71  837d8f07                 cmp dword ptr [rbp - 0x71], 7
0005ac75  7f23                     jg 0x5ac9a
0005ac77  7575                     jne 0x5acee
0005ac79  837dc700                 cmp dword ptr [rbp - 0x39], 0
0005ac7d  740c                     je 0x5ac8b
0005ac7f  837dbf00                 cmp dword ptr [rbp - 0x41], 0
0005ac83  7569                     jne 0x5acee
0005ac85  44895597                 mov dword ptr [rbp - 0x69], r10d
0005ac89  eb54                     jmp 0x5acdf
0005ac8b  837dbf00                 cmp dword ptr [rbp - 0x41], 0
0005ac8f  7409                     je 0x5ac9a
0005ac91  c7459703000000           mov dword ptr [rbp - 0x69], 3
0005ac98  eb45                     jmp 0x5acdf
0005ac9a  488bc3                   mov rax, rbx
0005ac9d  488bcf                   mov rcx, rdi
0005aca0  48c1e820                 shr rax, 0x20
0005aca4  48c1e920                 shr rcx, 0x20
0005aca8  3ac1                     cmp al, cl
0005acaa  7527                     jne 0x5acd3
0005acac  488bc3                   mov rax, rbx
0005acaf  488bcf                   mov rcx, rdi
0005acb2  48c1e808                 shr rax, 8
0005acb6  48c1e908                 shr rcx, 8
0005acba  3ac1                     cmp al, cl
0005acbc  7306                     jae 0x5acc4
0005acbe  44895597                 mov dword ptr [rbp - 0x69], r10d
0005acc2  eb1b                     jmp 0x5acdf
0005acc4  0f86db010000             jbe 0x5aea5
0005acca  c7459703000000           mov dword ptr [rbp - 0x69], 3
0005acd1  eb0c                     jmp 0x5acdf
0005acd3  ba03000000               mov edx, 3
0005acd8  410f42d2                 cmovb edx, r10d
0005acdc  895597                   mov dword ptr [rbp - 0x69], edx
0005acdf  448955bf                 mov dword ptr [rbp - 0x41], r10d
0005ace3  448955c7                 mov dword ptr [rbp - 0x39], r10d
0005ace7  c7458f07000000           mov dword ptr [rbp - 0x71], 7
0005acee  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005acf3  498d44240e               lea rax, [r12 + 0xe]
0005acf8  498b1424                 mov rdx, qword ptr [r12]
0005acfc  ffc9                     dec ecx
0005acfe  483bd0                   cmp rdx, rax
0005ad01  7406                     je 0x5ad09
0005ad03  488d4202                 lea rax, [rdx + 2]
0005ad07  eb0c                     jmp 0x5ad15
0005ad09  498b442410               mov rax, qword ptr [r12 + 0x10]
0005ad0e  33d2                     xor edx, edx
0005ad10  4989542410               mov qword ptr [r12 + 0x10], rdx
0005ad15  49890424                 mov qword ptr [r12], rax
0005ad19  41894c2408               mov dword ptr [r12 + 8], ecx
0005ad1e  85c9                     test ecx, ecx
0005ad20  0f8412ffffff             je 0x5ac38
0005ad26  0fb708                   movzx ecx, word ptr [rax]
0005ad29  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005ad2d  498b4508                 mov rax, qword ptr [r13 + 8]
0005ad31  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005ad34  0fb7da                   movzx ebx, dx
0005ad37  48c1e320                 shl rbx, 0x20
0005ad3b  48c1ea10                 shr rdx, 0x10
0005ad3f  480bda                   or rbx, rdx
0005ad42  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005ad46  e9f1feffff               jmp 0x5ac3c
0005ad4b  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005ad4f  33d2                     xor edx, edx
0005ad51  49895710                 mov qword ptr [r15 + 0x10], rdx
0005ad55  e921feffff               jmp 0x5ab7b
0005ad5a  4585c9                   test r9d, r9d
0005ad5d  0f8547010000             jne 0x5aeaa
0005ad63  33c0                     xor eax, eax
0005ad65  8bf0                     mov esi, eax
0005ad67  4180fb04                 cmp r11b, 4
0005ad6b  0f8463030000             je 0x5b0d4
0005ad71  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005ad75  488bc7                   mov rax, rdi
0005ad78  48c1e820                 shr rax, 0x20
0005ad7c  488bcb                   mov rcx, rbx
0005ad7f  66894593                 mov word ptr [rbp - 0x6d], ax
0005ad83  4d8bcf                   mov r9, r15
0005ad86  48c1e920                 shr rcx, 0x20
0005ad8a  4d8bc4                   mov r8, r12
0005ad8d  66894d9f                 mov word ptr [rbp - 0x61], cx
0005ad91  48c1e710                 shl rdi, 0x10
0005ad95  0bf8                     or edi, eax
0005ad97  48c1e310                 shl rbx, 0x10
0005ad9b  33c0                     xor eax, eax
0005ad9d  897dd7                   mov dword ptr [rbp - 0x29], edi
0005ada0  89442450                 mov dword ptr [rsp + 0x50], eax
0005ada4  0bd9                     or ebx, ecx
0005ada6  488b4d5f                 mov rcx, qword ptr [rbp + 0x5f]
0005adaa  488d45ff                 lea rax, [rbp - 1]
0005adae  4889442448               mov qword ptr [rsp + 0x48], rax
0005adb3  488d45ef                 lea rax, [rbp - 0x11]
0005adb7  4889442440               mov qword ptr [rsp + 0x40], rax
0005adbc  488d4593                 lea rax, [rbp - 0x6d]
0005adc0  4889442438               mov qword ptr [rsp + 0x38], rax
0005adc5  488d459f                 lea rax, [rbp - 0x61]
0005adc9  4889442430               mov qword ptr [rsp + 0x30], rax
0005adce  488d45d7                 lea rax, [rbp - 0x29]
0005add2  4889442428               mov qword ptr [rsp + 0x28], rax
0005add7  488d45a7                 lea rax, [rbp - 0x59]
0005addb  4889442420               mov qword ptr [rsp + 0x20], rax
0005ade0  895da7                   mov dword ptr [rbp - 0x59], ebx
0005ade3  e85865ffff               call 0x51340
0005ade8  448bc8                   mov r9d, eax
0005adeb  89459f                   mov dword ptr [rbp - 0x61], eax
0005adee  8b45ff                   mov eax, dword ptr [rbp - 1]
0005adf1  83f802                   cmp eax, 2
0005adf4  0f85cf090000             jne 0x5b7c9
0005adfa  8b45a7                   mov eax, dword ptr [rbp - 0x59]
0005adfd  0fb7d8                   movzx ebx, ax
0005ae00  48c1e810                 shr rax, 0x10
0005ae04  48c1e320                 shl rbx, 0x20
0005ae08  480bd8                   or rbx, rax
0005ae0b  8b45d7                   mov eax, dword ptr [rbp - 0x29]
0005ae0e  0fb7f8                   movzx edi, ax
0005ae11  48c1e720                 shl rdi, 0x20
0005ae15  48c1e810                 shr rax, 0x10
0005ae19  480bf8                   or rdi, rax
0005ae1c  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005ae20  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005ae24  4585c9                   test r9d, r9d
0005ae27  0f84a2000000             je 0x5aecf
0005ae2d  448d5601                 lea r10d, [rsi + 1]
0005ae31  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005ae35  4139742408               cmp dword ptr [r12 + 8], esi
0005ae3a  7472                     je 0x5aeae
0005ae3c  41397708                 cmp dword ptr [r15 + 8], esi
0005ae40  746c                     je 0x5aeae
0005ae42  498b0424                 mov rax, qword ptr [r12]
0005ae46  498b5508                 mov rdx, qword ptr [r13 + 8]
0005ae4a  0fb708                   movzx ecx, word ptr [rax]
0005ae4d  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005ae50  0fb7d8                   movzx ebx, ax
0005ae53  48c1e810                 shr rax, 0x10
0005ae57  48c1e320                 shl rbx, 0x20
0005ae5b  480bd8                   or rbx, rax
0005ae5e  498b07                   mov rax, qword ptr [r15]
0005ae61  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005ae65  0fb708                   movzx ecx, word ptr [rax]
0005ae68  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005ae6b  0fb7f8                   movzx edi, ax
0005ae6e  48c1e720                 shl rdi, 0x20
0005ae72  48c1e810                 shr rax, 0x10
0005ae76  480bf8                   or rdi, rax
0005ae79  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005ae7d  eb2f                     jmp 0x5aeae
0005ae7f  488bc7                   mov rax, rdi
0005ae82  48c1e820                 shr rax, 0x20
0005ae86  0fb6c8                   movzx ecx, al
0005ae89  400fb6c7                 movzx eax, dil
0005ae8d  48c1e108                 shl rcx, 8
0005ae91  488bf9                   mov rdi, rcx
0005ae94  480bf8                   or rdi, rax
0005ae97  48c1e710                 shl rdi, 0x10
0005ae9b  490bf8                   or rdi, r8
0005ae9e  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005aea2  488bf7                   mov rsi, rdi
0005aea5  4585c9                   test r9d, r9d
0005aea8  7429                     je 0x5aed3
0005aeaa  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005aeae  418b442408               mov eax, dword ptr [r12 + 8]
0005aeb3  85c0                     test eax, eax
0005aeb5  740b                     je 0x5aec2
0005aeb7  41837f0800               cmp dword ptr [r15 + 8], 0
0005aebc  0f8570f1ffff             jne 0x5a032
0005aec2  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005aec6  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
0005aeca  e9aff0ffff               jmp 0x59f7e
0005aecf  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005aed3  33c0                     xor eax, eax
0005aed5  4180fb03                 cmp r11b, 3
0005aed9  0f85f5010000             jne 0x5b0d4
0005aedf  4c8bc3                   mov r8, rbx
0005aee2  894593                   mov dword ptr [rbp - 0x6d], eax
0005aee5  49c1e820                 shr r8, 0x20
0005aee9  4180f801                 cmp r8b, 1
0005aeed  0f87cc000000             ja 0x5afbf
0005aef3  498bd6                   mov rdx, r14
0005aef6  48c1ea28                 shr rdx, 0x28
0005aefa  413ad3                   cmp dl, r11b
0005aefd  772e                     ja 0x5af2d
0005aeff  440fb64d95               movzx r9d, byte ptr [rbp - 0x6b]
0005af04  48b900000000ffff0000     movabs rcx, 0xffff00000000
0005af0e  0fb65596                 movzx edx, byte ptr [rbp - 0x6a]
0005af12  488bd9                   mov rbx, rcx
0005af15  48894daf                 mov qword ptr [rbp - 0x51], rcx
0005af19  440fb6d0                 movzx r10d, al
0005af1d  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
0005af21  44884d9c                 mov byte ptr [rbp - 0x64], r9b
0005af25  88459b                   mov byte ptr [rbp - 0x65], al
0005af28  e9e7000000               jmp 0x5b014
0005af2d  498bce                   mov rcx, r14
0005af30  48c1e910                 shr rcx, 0x10
0005af34  8bc9                     mov ecx, ecx
0005af36  80fa22                   cmp dl, 0x22
0005af39  755e                     jne 0x5af99
0005af3b  498bd6                   mov rdx, r14
0005af3e  48c1ea08                 shr rdx, 8
0005af42  440fb6d2                 movzx r10d, dl
0005af46  440fb6ca                 movzx r9d, dl
0005af4a  4180e2c6                 and r10b, 0xc6
0005af4e  4180e1e4                 and r9b, 0xe4
0005af52  4488559b                 mov byte ptr [rbp - 0x65], r10b
0005af56  44884d9c                 mov byte ptr [rbp - 0x64], r9b
0005af5a  4584c0                   test r8b, r8b
0005af5d  7517                     jne 0x5af76
0005af5f  48c1e110                 shl rcx, 0x10
0005af63  0fb7c3                   movzx eax, bx
0005af66  488bd9                   mov rbx, rcx
0005af69  480bd8                   or rbx, rax
0005af6c  b104                     mov cl, 4
0005af6e  80e2c5                   and dl, 0xc5
0005af71  e98c000000               jmp 0x5b002
0005af76  b8000087ff               mov eax, 0xff870000
0005af7b  4823c8                   and rcx, rax
0005af7e  0fb7c3                   movzx eax, bx
0005af81  48c1e110                 shl rcx, 0x10
0005af85  488bd9                   mov rbx, rcx
0005af88  b105                     mov cl, 5
0005af8a  480bd8                   or rbx, rax
0005af8d  488bd3                   mov rdx, rbx
0005af90  48c1ea08                 shr rdx, 8
0005af94  80e2c5                   and dl, 0xc5
0005af97  eb69                     jmp 0x5b002
0005af99  0fb65596                 movzx edx, byte ptr [rbp - 0x6a]
0005af9d  440fb64d95               movzx r9d, byte ptr [rbp - 0x6b]
0005afa2  440fb65593               movzx r10d, byte ptr [rbp - 0x6d]
0005afa7  48c1e110                 shl rcx, 0x10
0005afab  0fb6c3                   movzx eax, bl
0005afae  488bd9                   mov rbx, rcx
0005afb1  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
0005afb5  480bd8                   or rbx, rax
0005afb8  480fbaeb09               bts rbx, 9
0005afbd  eb3b                     jmp 0x5affa
0005afbf  48b8ffffffffff22ffff     movabs rax, 0xffff22ffffffffff
0005afc9  b103                     mov cl, 3
0005afcb  4823d8                   and rbx, rax
0005afce  48b80000000000220000     movabs rax, 0x220000000000
0005afd8  480bd8                   or rbx, rax
0005afdb  488bc3                   mov rax, rbx
0005afde  4c8bf3                   mov r14, rbx
0005afe1  48c1e808                 shr rax, 8
0005afe5  440fb6d0                 movzx r10d, al
0005afe9  440fb6c8                 movzx r9d, al
0005afed  4180e2c6                 and r10b, 0xc6
0005aff1  4180e1e4                 and r9b, 0xe4
0005aff5  24c5                     and al, 0xc5
0005aff7  0fb6d0                   movzx edx, al
0005affa  44884d9c                 mov byte ptr [rbp - 0x64], r9b
0005affe  4488559b                 mov byte ptr [rbp - 0x65], r10b
0005b002  4881e3ff02ffff           and rbx, 0xffffffffffff02ff
0005b009  480fbaeb09               bts rbx, 9
0005b00e  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005b012  33c0                     xor eax, eax
0005b014  837d8f02                 cmp dword ptr [rbp - 0x71], 2
0005b018  884d77                   mov byte ptr [rbp + 0x77], cl
0005b01b  488955e7                 mov qword ptr [rbp - 0x19], rdx
0005b01f  0f8eaf000000             jle 0x5b0d4
0005b025  4180fd03                 cmp r13b, 3
0005b029  0f84af000000             je 0x5b0de
0005b02f  4584d2                   test r10b, r10b
0005b032  7417                     je 0x5b04b
0005b034  b803000000               mov eax, 3
0005b039  41bb02000000             mov r11d, 2
0005b03f  894597                   mov dword ptr [rbp - 0x69], eax
0005b042  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b046  e95ff2ffff               jmp 0x5a2aa
0005b04b  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b04f  4183fb03                 cmp r11d, 3
0005b053  0f8e4cf2ffff             jle 0x5a2a5
0005b059  84c9                     test cl, cl
0005b05b  7413                     je 0x5b070
0005b05d  b803000000               mov eax, 3
0005b062  894597                   mov dword ptr [rbp - 0x69], eax
0005b065  448bd8                   mov r11d, eax
0005b068  89458f                   mov dword ptr [rbp - 0x71], eax
0005b06b  e93af2ffff               jmp 0x5a2aa
0005b070  4183fb04                 cmp r11d, 4
0005b074  0f8e2bf2ffff             jle 0x5a2a5
0005b07a  837ddf00                 cmp dword ptr [rbp - 0x21], 0
0005b07e  0f8521f2ffff             jne 0x5a2a5
0005b084  b803000000               mov eax, 3
0005b089  4584c9                   test r9b, r9b
0005b08c  7412                     je 0x5b0a0
0005b08e  41bb04000000             mov r11d, 4
0005b094  894597                   mov dword ptr [rbp - 0x69], eax
0005b097  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b09b  e90af2ffff               jmp 0x5a2aa
0005b0a0  41b901000000             mov r9d, 1
0005b0a6  4183fb05                 cmp r11d, 5
0005b0aa  0f8e00f2ffff             jle 0x5a2b0
0005b0b0  837dcb00                 cmp dword ptr [rbp - 0x35], 0
0005b0b4  0f85f6f1ffff             jne 0x5a2b0
0005b0ba  84d2                     test dl, dl
0005b0bc  0f84eef1ffff             je 0x5a2b0
0005b0c2  41bb05000000             mov r11d, 5
0005b0c8  894597                   mov dword ptr [rbp - 0x69], eax
0005b0cb  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b0cf  e9dcf1ffff               jmp 0x5a2b0
0005b0d4  4180fd03                 cmp r13b, 3
0005b0d8  0f85c3f1ffff             jne 0x5a2a1
0005b0de  4c8bd7                   mov r10, rdi
0005b0e1  894593                   mov dword ptr [rbp - 0x6d], eax
0005b0e4  49c1ea20                 shr r10, 0x20
0005b0e8  4180fa01                 cmp r10b, 1
0005b0ec  0f87c0000000             ja 0x5b1b2
0005b0f2  488bd6                   mov rdx, rsi
0005b0f5  48c1ea28                 shr rdx, 0x28
0005b0f9  80fa03                   cmp dl, 3
0005b0fc  7728                     ja 0x5b126
0005b0fe  440fb64596               movzx r8d, byte ptr [rbp - 0x6a]
0005b103  48b800000000ffff0000     movabs rax, 0xffff00000000
0005b10d  440fb64d95               movzx r9d, byte ptr [rbp - 0x6b]
0005b112  488bf8                   mov rdi, rax
0005b115  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
0005b119  0fb65593                 movzx edx, byte ptr [rbp - 0x6d]
0005b11d  488945a7                 mov qword ptr [rbp - 0x59], rax
0005b121  e9d6000000               jmp 0x5b1fc
0005b126  488bce                   mov rcx, rsi
0005b129  48c1e910                 shr rcx, 0x10
0005b12d  8bc9                     mov ecx, ecx
0005b12f  80fa22                   cmp dl, 0x22
0005b132  7557                     jne 0x5b18b
0005b134  4c8bc6                   mov r8, rsi
0005b137  49c1e808                 shr r8, 8
0005b13b  410fb6d0                 movzx edx, r8b
0005b13f  450fb6c8                 movzx r9d, r8b
0005b143  80e2c6                   and dl, 0xc6
0005b146  4180e1e4                 and r9b, 0xe4
0005b14a  4584d2                   test r10b, r10b
0005b14d  7518                     jne 0x5b167
0005b14f  48c1e110                 shl rcx, 0x10
0005b153  0fb7c7                   movzx eax, di
0005b156  488bf9                   mov rdi, rcx
0005b159  480bf8                   or rdi, rax
0005b15c  b104                     mov cl, 4
0005b15e  4180e0c5                 and r8b, 0xc5
0005b162  e985000000               jmp 0x5b1ec
0005b167  b8000087ff               mov eax, 0xff870000
0005b16c  4823c8                   and rcx, rax
0005b16f  0fb7c7                   movzx eax, di
0005b172  48c1e110                 shl rcx, 0x10
0005b176  488bf9                   mov rdi, rcx
0005b179  b105                     mov cl, 5
0005b17b  480bf8                   or rdi, rax
0005b17e  4c8bc7                   mov r8, rdi
0005b181  49c1e808                 shr r8, 8
0005b185  4180e0c5                 and r8b, 0xc5
0005b189  eb61                     jmp 0x5b1ec
0005b18b  440fb64596               movzx r8d, byte ptr [rbp - 0x6a]
0005b190  440fb64d95               movzx r9d, byte ptr [rbp - 0x6b]
0005b195  0fb65593                 movzx edx, byte ptr [rbp - 0x6d]
0005b199  48c1e110                 shl rcx, 0x10
0005b19d  400fb6c7                 movzx eax, dil
0005b1a1  488bf9                   mov rdi, rcx
0005b1a4  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
0005b1a8  480bf8                   or rdi, rax
0005b1ab  480fbaef09               bts rdi, 9
0005b1b0  eb3a                     jmp 0x5b1ec
0005b1b2  48b8ffffffffff22ffff     movabs rax, 0xffff22ffffffffff
0005b1bc  b103                     mov cl, 3
0005b1be  4823f8                   and rdi, rax
0005b1c1  48b80000000000220000     movabs rax, 0x220000000000
0005b1cb  480bf8                   or rdi, rax
0005b1ce  488bc7                   mov rax, rdi
0005b1d1  488bf7                   mov rsi, rdi
0005b1d4  48c1e808                 shr rax, 8
0005b1d8  0fb6d0                   movzx edx, al
0005b1db  440fb6c8                 movzx r9d, al
0005b1df  80e2c6                   and dl, 0xc6
0005b1e2  4180e1e4                 and r9b, 0xe4
0005b1e6  24c5                     and al, 0xc5
0005b1e8  440fb6c0                 movzx r8d, al
0005b1ec  4881e7ff02ffff           and rdi, 0xffffffffffff02ff
0005b1f3  480fbaef09               bts rdi, 9
0005b1f8  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005b1fc  837d8f02                 cmp dword ptr [rbp - 0x71], 2
0005b200  0f8e9bf0ffff             jle 0x5a2a1
0005b206  4180fb03                 cmp r11b, 3
0005b20a  0f84b9000000             je 0x5b2c9
0005b210  84d2                     test dl, dl
0005b212  741d                     je 0x5b231
0005b214  41b901000000             mov r9d, 1
0005b21a  41bb02000000             mov r11d, 2
0005b220  44894d97                 mov dword ptr [rbp - 0x69], r9d
0005b224  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b228  418d4102                 lea eax, [r9 + 2]
0005b22c  e97ff0ffff               jmp 0x5a2b0
0005b231  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b235  4183fb03                 cmp r11d, 3
0005b239  0f8e66f0ffff             jle 0x5a2a5
0005b23f  84c9                     test cl, cl
0005b241  741a                     je 0x5b25d
0005b243  b803000000               mov eax, 3
0005b248  41b901000000             mov r9d, 1
0005b24e  44894d97                 mov dword ptr [rbp - 0x69], r9d
0005b252  448bd8                   mov r11d, eax
0005b255  89458f                   mov dword ptr [rbp - 0x71], eax
0005b258  e953f0ffff               jmp 0x5a2b0
0005b25d  4183fb04                 cmp r11d, 4
0005b261  0f8e3ef0ffff             jle 0x5a2a5
0005b267  4584c9                   test r9b, r9b
0005b26a  7423                     je 0x5b28f
0005b26c  837ddf00                 cmp dword ptr [rbp - 0x21], 0
0005b270  751d                     jne 0x5b28f
0005b272  41b901000000             mov r9d, 1
0005b278  41bb04000000             mov r11d, 4
0005b27e  44894d97                 mov dword ptr [rbp - 0x69], r9d
0005b282  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b286  418d4102                 lea eax, [r9 + 2]
0005b28a  e921f0ffff               jmp 0x5a2b0
0005b28f  41b901000000             mov r9d, 1
0005b295  418d4102                 lea eax, [r9 + 2]
0005b299  4183fb05                 cmp r11d, 5
0005b29d  0f8e0df0ffff             jle 0x5a2b0
0005b2a3  4584c0                   test r8b, r8b
0005b2a6  0f8404f0ffff             je 0x5a2b0
0005b2ac  837dcb00                 cmp dword ptr [rbp - 0x35], 0
0005b2b0  0f85faefffff             jne 0x5a2b0
0005b2b6  41bb05000000             mov r11d, 5
0005b2bc  44894d97                 mov dword ptr [rbp - 0x69], r9d
0005b2c0  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b2c4  e9e7efffff               jmp 0x5a2b0
0005b2c9  38559b                   cmp byte ptr [rbp - 0x65], dl
0005b2cc  7425                     je 0x5b2f3
0005b2ce  b803000000               mov eax, 3
0005b2d3  41b901000000             mov r9d, 1
0005b2d9  448bd0                   mov r10d, eax
0005b2dc  41bb02000000             mov r11d, 2
0005b2e2  450f42d1                 cmovb r10d, r9d
0005b2e6  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b2ea  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b2ee  e9bdefffff               jmp 0x5a2b0
0005b2f3  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b2f7  4183fb03                 cmp r11d, 3
0005b2fb  0f8ea4efffff             jle 0x5a2a5
0005b301  384d77                   cmp byte ptr [rbp + 0x77], cl
0005b304  7421                     je 0x5b327
0005b306  b803000000               mov eax, 3
0005b30b  41b901000000             mov r9d, 1
0005b311  448bd0                   mov r10d, eax
0005b314  89458f                   mov dword ptr [rbp - 0x71], eax
0005b317  450f42d1                 cmovb r10d, r9d
0005b31b  448bd8                   mov r11d, eax
0005b31e  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b322  e989efffff               jmp 0x5a2b0
0005b327  4183fb04                 cmp r11d, 4
0005b32b  0f8e74efffff             jle 0x5a2a5
0005b331  0fb64d9c                 movzx ecx, byte ptr [rbp - 0x64]
0005b335  413ac9                   cmp cl, r9b
0005b338  742e                     je 0x5b368
0005b33a  837ddf00                 cmp dword ptr [rbp - 0x21], 0
0005b33e  7528                     jne 0x5b368
0005b340  413ac9                   cmp cl, r9b
0005b343  b803000000               mov eax, 3
0005b348  448bd0                   mov r10d, eax
0005b34b  41b901000000             mov r9d, 1
0005b351  450f42d1                 cmovb r10d, r9d
0005b355  41bb04000000             mov r11d, 4
0005b35b  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b35f  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b363  e948efffff               jmp 0x5a2b0
0005b368  4183fb05                 cmp r11d, 5
0005b36c  0f8e33efffff             jle 0x5a2a5
0005b372  488b4de7                 mov rcx, qword ptr [rbp - 0x19]
0005b376  413ac8                   cmp cl, r8b
0005b379  0f8426efffff             je 0x5a2a5
0005b37f  837dcb00                 cmp dword ptr [rbp - 0x35], 0
0005b383  b803000000               mov eax, 3
0005b388  448d48fe                 lea r9d, [rax - 2]
0005b38c  0f851eefffff             jne 0x5a2b0
0005b392  413ac8                   cmp cl, r8b
0005b395  448bd0                   mov r10d, eax
0005b398  41bb05000000             mov r11d, 5
0005b39e  450f42d1                 cmovb r10d, r9d
0005b3a2  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b3a6  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b3aa  e901efffff               jmp 0x5a2b0
0005b3af  837df700                 cmp dword ptr [rbp - 9], 0
0005b3b3  7406                     je 0x5b3bb
0005b3b5  4180fd14                 cmp r13b, 0x14
0005b3b9  765b                     jbe 0x5b416
0005b3bb  4585db                   test r11d, r11d
0005b3be  7f07                     jg 0x5b3c7
0005b3c0  41837a1000               cmp dword ptr [r10 + 0x10], 0
0005b3c5  744f                     je 0x5b416
0005b3c7  4d8bc4                   mov r8, r12
0005b3ca  498bd2                   mov rdx, r10
0005b3cd  e8ee040000               call 0x5b8c0
0005b3d2  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005b3d6  4d8bc7                   mov r8, r15
0005b3d9  0fb6cb                   movzx ecx, bl
0005b3dc  6603c1                   add ax, cx
0005b3df  66894593                 mov word ptr [rbp - 0x6d], ax
0005b3e3  e8d8040000               call 0x5b8c0
0005b3e8  400fb6cf                 movzx ecx, dil
0005b3ec  6603c1                   add ax, cx
0005b3ef  66394593                 cmp word ptr [rbp - 0x6d], ax
0005b3f3  741d                     je 0x5b412
0005b3f5  b801000000               mov eax, 1
0005b3fa  41ba03000000             mov r10d, 3
0005b400  440f42d0                 cmovb r10d, eax
0005b404  33c0                     xor eax, eax
0005b406  448bd8                   mov r11d, eax
0005b409  89458f                   mov dword ptr [rbp - 0x71], eax
0005b40c  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b410  eb04                     jmp 0x5b416
0005b412  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b416  837dcb00                 cmp dword ptr [rbp - 0x35], 0
0005b41a  7410                     je 0x5b42c
0005b41c  837d0300                 cmp dword ptr [rbp + 3], 0
0005b420  740a                     je 0x5b42c
0005b422  4180fd14                 cmp r13b, 0x14
0005b426  0f8643efffff             jbe 0x5a36f
0005b42c  4183fb01                 cmp r11d, 1
0005b430  0f8e39efffff             jle 0x5a36f
0005b436  0fb645bc                 movzx eax, byte ptr [rbp - 0x44]
0005b43a  4180fd14                 cmp r13b, 0x14
0005b43e  0fb64dbb                 movzx ecx, byte ptr [rbp - 0x45]
0005b442  488bd7                   mov rdx, rdi
0005b445  0f46c8                   cmovbe ecx, eax
0005b448  48c1ea08                 shr rdx, 8
0005b44c  488bc3                   mov rax, rbx
0005b44f  22d1                     and dl, cl
0005b451  48c1e808                 shr rax, 8
0005b455  22c1                     and al, cl
0005b457  3ac2                     cmp al, dl
0005b459  0f8410efffff             je 0x5a36f
0005b45f  41ba01000000             mov r10d, 1
0005b465  41bd03000000             mov r13d, 3
0005b46b  450f42ea                 cmovb r13d, r10d
0005b46f  4489558f                 mov dword ptr [rbp - 0x71], r10d
0005b473  44896d97                 mov dword ptr [rbp - 0x69], r13d
0005b477  458bda                   mov r11d, r10d
0005b47a  e9f6eeffff               jmp 0x5a375
0005b47f  498b1424                 mov rdx, qword ptr [r12]
0005b483  498d4c240e               lea rcx, [r12 + 0xe]
0005b488  4533c9                   xor r9d, r9d
0005b48b  ffc8                     dec eax
0005b48d  458bf1                   mov r14d, r9d
0005b490  4189442408               mov dword ptr [r12 + 8], eax
0005b495  483bd1                   cmp rdx, rcx
0005b498  740a                     je 0x5b4a4
0005b49a  488d4202                 lea rax, [rdx + 2]
0005b49e  49890424                 mov qword ptr [r12], rax
0005b4a2  eb09                     jmp 0x5b4ad
0005b4a4  4d890424                 mov qword ptr [r12], r8
0005b4a8  4d894c2410               mov qword ptr [r12 + 0x10], r9
0005b4ad  4d8b4710                 mov r8, qword ptr [r15 + 0x10]
0005b4b1  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005b4b5  4d85c0                   test r8, r8
0005b4b8  750f                     jne 0x5b4c9
0005b4ba  49830702                 add qword ptr [r15], 2
0005b4be  4d8b07                   mov r8, qword ptr [r15]
0005b4c1  ffc9                     dec ecx
0005b4c3  41894f08                 mov dword ptr [r15 + 8], ecx
0005b4c7  eb22                     jmp 0x5b4eb
0005b4c9  498b17                   mov rdx, qword ptr [r15]
0005b4cc  498d470e                 lea rax, [r15 + 0xe]
0005b4d0  ffc9                     dec ecx
0005b4d2  498bf1                   mov rsi, r9
0005b4d5  41894f08                 mov dword ptr [r15 + 8], ecx
0005b4d9  483bd0                   cmp rdx, rax
0005b4dc  7406                     je 0x5b4e4
0005b4de  4c8d4202                 lea r8, [rdx + 2]
0005b4e2  eb04                     jmp 0x5b4e8
0005b4e4  4d894f10                 mov qword ptr [r15 + 0x10], r9
0005b4e8  4d8907                   mov qword ptr [r15], r8
0005b4eb  418b442408               mov eax, dword ptr [r12 + 8]
0005b4f0  85c0                     test eax, eax
0005b4f2  7446                     je 0x5b53a
0005b4f4  85c9                     test ecx, ecx
0005b4f6  7442                     je 0x5b53a
0005b4f8  498b0424                 mov rax, qword ptr [r12]
0005b4fc  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005b500  0fb708                   movzx ecx, word ptr [rax]
0005b503  498b5508                 mov rdx, qword ptr [r13 + 8]
0005b507  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005b50a  0fb7d8                   movzx ebx, ax
0005b50d  48c1e810                 shr rax, 0x10
0005b511  48c1e320                 shl rbx, 0x20
0005b515  480bd8                   or rbx, rax
0005b518  410fb700                 movzx eax, word ptr [r8]
0005b51c  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005b520  8b0c82                   mov ecx, dword ptr [rdx + rax*4]
0005b523  0fb7f9                   movzx edi, cx
0005b526  48c1e720                 shl rdi, 0x20
0005b52a  48c1e910                 shr rcx, 0x10
0005b52e  480bf9                   or rdi, rcx
0005b531  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005b535  e906ebffff               jmp 0x5a040
0005b53a  448b4d9f                 mov r9d, dword ptr [rbp - 0x61]
0005b53e  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005b542  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
0005b546  e933eaffff               jmp 0x59f7e
0005b54b  b803000000               mov eax, 3
0005b550  410f42c1                 cmovb eax, r9d
0005b554  e970020000               jmp 0x5b7c9
0005b559  48c1ef10                 shr rdi, 0x10
0005b55d  48c1eb10                 shr rbx, 0x10
0005b561  3bdf                     cmp ebx, edi
0005b563  410f42c1                 cmovb eax, r9d
0005b567  e95d020000               jmp 0x5b7c9
0005b56c  85c0                     test eax, eax
0005b56e  0f85e7000000             jne 0x5b65b
0005b574  458b4708                 mov r8d, dword ptr [r15 + 8]
0005b578  4585c0                   test r8d, r8d
0005b57b  0f8434020000             je 0x5b7b5
0005b581  39456f                   cmp dword ptr [rbp + 0x6f], eax
0005b584  0f8dc0000000             jge 0x5b64a
0005b58a  498b17                   mov rdx, qword ptr [r15]
0005b58d  b840db0000               mov eax, 0xdb40
0005b592  663902                   cmp word ptr [rdx], ax
0005b595  0f8579000000             jne 0x5b614
0005b59b  4d8d4f0e                 lea r9, [r15 + 0xe]
0005b59f  493bd1                   cmp rdx, r9
0005b5a2  7414                     je 0x5b5b8
0005b5a4  4183f801                 cmp r8d, 1
0005b5a8  7606                     jbe 0x5b5b0
0005b5aa  0fb74a02                 movzx ecx, word ptr [rdx + 2]
0005b5ae  eb04                     jmp 0x5b5b4
0005b5b0  0fb74d6f                 movzx ecx, word ptr [rbp + 0x6f]
0005b5b4  765e                     jbe 0x5b614
0005b5b6  eb0d                     jmp 0x5b5c5
0005b5b8  4183f801                 cmp r8d, 1
0005b5bc  7656                     jbe 0x5b614
0005b5be  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005b5c2  0fb708                   movzx ecx, word ptr [rax]
0005b5c5  b800230000               mov eax, 0x2300
0005b5ca  beef000000               mov esi, 0xef
0005b5cf  03c1                     add eax, ecx
0005b5d1  663bc6                   cmp ax, si
0005b5d4  773e                     ja 0x5b614
0005b5d6  33f6                     xor esi, esi
0005b5d8  8bfe                     mov edi, esi
0005b5da  3975c3                   cmp dword ptr [rbp - 0x3d], esi
0005b5dd  7517                     jne 0x5b5f6
0005b5df  80c102                   add cl, 2
0005b5e2  48b80000000000150000     movabs rax, 0x150000000000
0005b5ec  0fb6f9                   movzx edi, cl
0005b5ef  48c1e720                 shl rdi, 0x20
0005b5f3  480bf8                   or rdi, rax
0005b5f6  418d40ff                 lea eax, [r8 - 1]
0005b5fa  41894708                 mov dword ptr [r15 + 8], eax
0005b5fe  493bd1                   cmp rdx, r9
0005b601  7406                     je 0x5b609
0005b603  488d4202                 lea rax, [rdx + 2]
0005b607  eb08                     jmp 0x5b611
0005b609  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005b60d  49897710                 mov qword ptr [r15 + 0x10], rsi
0005b611  498907                   mov qword ptr [r15], rax
0005b614  48c1eb28                 shr rbx, 0x28
0005b618  80fb15                   cmp bl, 0x15
0005b61b  7412                     je 0x5b62f
0005b61d  48c1ef28                 shr rdi, 0x28
0005b621  4080ff15                 cmp dil, 0x15
0005b625  7508                     jne 0x5b62f
0005b627  418bc2                   mov eax, r10d
0005b62a  e99a010000               jmp 0x5b7c9
0005b62f  49837f1000               cmp qword ptr [r15 + 0x10], 0
0005b634  0f847b010000             je 0x5b7b5
0005b63a  8b4597                   mov eax, dword ptr [rbp - 0x69]
0005b63d  4183fb08                 cmp r11d, 8
0005b641  410f44c2                 cmove eax, r10d
0005b645  e97f010000               jmp 0x5b7c9
0005b64a  4585c9                   test r9d, r9d
0005b64d  4d8be7                   mov r12, r15
0005b650  be01000000               mov esi, 1
0005b655  480f45df                 cmovne rbx, rdi
0005b659  eb05                     jmp 0x5b660
0005b65b  be03000000               mov esi, 3
0005b660  458b442408               mov r8d, dword ptr [r12 + 8]
0005b665  4585c0                   test r8d, r8d
0005b668  0f8447010000             je 0x5b7b5
0005b66e  440fb7556f               movzx r10d, word ptr [rbp + 0x6f]
0005b673  498d7c240e               lea rdi, [r12 + 0xe]
0005b678  448b75c3                 mov r14d, dword ptr [rbp - 0x3d]
0005b67c  41bf00dd0000             mov r15d, 0xdd00
0005b682  4585c9                   test r9d, r9d
0005b685  458bc8                   mov r9d, r8d
0005b688  7408                     je 0x5b692
0005b68a  89559f                   mov dword ptr [rbp - 0x61], edx
0005b68d  e9af000000               jmp 0x5b741
0005b692  498b4508                 mov rax, qword ptr [r13 + 8]
0005b696  4d8b1c24                 mov r11, qword ptr [r12]
0005b69a  410fb713                 movzx edx, word ptr [r11]
0005b69e  8b0c90                   mov ecx, dword ptr [rax + rdx*4]
0005b6a1  b840db0000               mov eax, 0xdb40
0005b6a6  0fb7d9                   movzx ebx, cx
0005b6a9  48c1e320                 shl rbx, 0x20
0005b6ad  48c1e910                 shr rcx, 0x10
0005b6b1  480bd9                   or rbx, rcx
0005b6b4  663bd0                   cmp dx, ax
0005b6b7  0f857e000000             jne 0x5b73b
0005b6bd  4c3bdf                   cmp r11, rdi
0005b6c0  740d                     je 0x5b6cf
0005b6c2  4183f801                 cmp r8d, 1
0005b6c6  7673                     jbe 0x5b73b
0005b6c8  450fb75302               movzx r10d, word ptr [r11 + 2]
0005b6cd  eb0f                     jmp 0x5b6de
0005b6cf  4183f801                 cmp r8d, 1
0005b6d3  7666                     jbe 0x5b73b
0005b6d5  498b442410               mov rax, qword ptr [r12 + 0x10]
0005b6da  440fb710                 movzx r10d, word ptr [rax]
0005b6de  33d2                     xor edx, edx
0005b6e0  458bc8                   mov r9d, r8d
0005b6e3  66453bd7                 cmp r10w, r15w
0005b6e7  7254                     jb 0x5b73d
0005b6e9  b8efdd0000               mov eax, 0xddef
0005b6ee  66443bd0                 cmp r10w, ax
0005b6f2  7749                     ja 0x5b73d
0005b6f4  8bda                     mov ebx, edx
0005b6f6  4585f6                   test r14d, r14d
0005b6f9  7518                     jne 0x5b713
0005b6fb  418d4202                 lea eax, [r10 + 2]
0005b6ff  0fb6d8                   movzx ebx, al
0005b702  48b80000000000150000     movabs rax, 0x150000000000
0005b70c  48c1e320                 shl rbx, 0x20
0005b710  480bd8                   or rbx, rax
0005b713  458d48ff                 lea r9d, [r8 - 1]
0005b717  45894c2408               mov dword ptr [r12 + 8], r9d
0005b71c  4c3bdf                   cmp r11, rdi
0005b71f  740a                     je 0x5b72b
0005b721  498d4302                 lea rax, [r11 + 2]
0005b725  49890424                 mov qword ptr [r12], rax
0005b729  eb12                     jmp 0x5b73d
0005b72b  498b442410               mov rax, qword ptr [r12 + 0x10]
0005b730  49890424                 mov qword ptr [r12], rax
0005b734  4989542410               mov qword ptr [r12 + 0x10], rdx
0005b739  eb02                     jmp 0x5b73d
0005b73b  33d2                     xor edx, edx
0005b73d  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b741  488bc3                   mov rax, rbx
0005b744  48c1e828                 shr rax, 0x28
0005b748  0fb6c8                   movzx ecx, al
0005b74b  83f915                   cmp ecx, 0x15
0005b74e  7728                     ja 0x5b778
0005b750  4c8d05a948faff           lea r8, [rip - 0x5b757]
0005b757  410fb68408a4b80500       movzx eax, byte ptr [r8 + rcx + 0x5b8a4]
0005b760  418b8c8090b80500         mov ecx, dword ptr [r8 + rax*4 + 0x5b890]
0005b768  4903c8                   add rcx, r8
0005b76b  ffe1                     jmp rcx
0005b76d  f6456f02                 test byte ptr [rbp + 0x6f], 2
0005b771  750f                     jne 0x5b782
0005b773  4585db                   test r11d, r11d
0005b776  7e0a                     jle 0x5b782
0005b778  8bc6                     mov eax, esi
0005b77a  eb4d                     jmp 0x5b7c9
0005b77c  f6456f04                 test byte ptr [rbp + 0x6f], 4
0005b780  74f6                     je 0x5b778
0005b782  498b0424                 mov rax, qword ptr [r12]
0005b786  458d41ff                 lea r8d, [r9 - 1]
0005b78a  483bc7                   cmp rax, rdi
0005b78d  7406                     je 0x5b795
0005b78f  4883c002                 add rax, 2
0005b793  eb0a                     jmp 0x5b79f
0005b795  498b442410               mov rax, qword ptr [r12 + 0x10]
0005b79a  4989542410               mov qword ptr [r12 + 0x10], rdx
0005b79f  49890424                 mov qword ptr [r12], rax
0005b7a3  4589442408               mov dword ptr [r12 + 8], r8d
0005b7a8  448b4d9f                 mov r9d, dword ptr [rbp - 0x61]
0005b7ac  4585c0                   test r8d, r8d
0005b7af  0f85cdfeffff             jne 0x5b682
0005b7b5  448b6d97                 mov r13d, dword ptr [rbp - 0x69]
0005b7b9  b802000000               mov eax, 2
0005b7be  4183fb08                 cmp r11d, 8
0005b7c2  440f44e8                 cmove r13d, eax
0005b7c6  418bc5                   mov eax, r13d
0005b7c9  4881c4e8000000           add rsp, 0xe8
0005b7d0  415f                     pop r15
0005b7d2  415e                     pop r14
0005b7d4  415d                     pop r13
0005b7d6  415c                     pop r12
0005b7d8  5f                       pop rdi
0005b7d9  5e                       pop rsi
0005b7da  5b                       pop rbx
0005b7db  5d                       pop rbp
0005b7dc  c3                       ret
0005b7dd  0f1f00                   nop dword ptr [rax]
