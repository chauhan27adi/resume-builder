; `AddKeysetBegin'::`1'::dtor$1
; aetm_enclave.dll, primary RVA 0x5eee0, 34 bytes in 1 chunk(s)

; chunk at RVA 0x5eee0 (34 bytes)
0005eee0  4055                     push rbp
0005eee2  4883ec20                 sub rsp, 0x20
0005eee6  488bea                   mov rbp, rdx
0005eee9  488b9538010000           mov rdx, qword ptr [rbp + 0x138]
0005eef0  488b8d40010000           mov rcx, qword ptr [rbp + 0x140]
0005eef7  e8e4a9fbff               call 0x198e0
0005eefc  4883c420                 add rsp, 0x20
0005ef00  5d                       pop rbp
0005ef01  c3                       ret
