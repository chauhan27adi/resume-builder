; CSqlSortManager_100::DBCompareWCharReaderFastImpl<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x54790, 5776 bytes in 1 chunk(s)

; chunk at RVA 0x54790 (5776 bytes)
00054790  4489442418               mov dword ptr [rsp + 0x18], r8d
00054795  4889542410               mov qword ptr [rsp + 0x10], rdx
0005479a  48894c2408               mov qword ptr [rsp + 8], rcx
0005479f  55                       push rbp
000547a0  53                       push rbx
000547a1  56                       push rsi
000547a2  57                       push rdi
000547a3  4154                     push r12
000547a5  4155                     push r13
000547a7  4156                     push r14
000547a9  4157                     push r15
000547ab  488d6c24e9               lea rbp, [rsp - 0x17]
000547b0  4881ecd8000000           sub rsp, 0xd8
000547b7  4c8b657f                 mov r12, qword ptr [rbp + 0x7f]
000547bb  33c0                     xor eax, eax
000547bd  8bd8                     mov ebx, eax
000547bf  488945bf                 mov qword ptr [rbp - 0x41], rax
000547c3  8bf8                     mov edi, eax
000547c5  488945b7                 mov qword ptr [rbp - 0x49], rax
000547c9  448bf0                   mov r14d, eax
000547cc  8945a3                   mov dword ptr [rbp - 0x5d], eax
000547cf  8bf0                     mov esi, eax
000547d1  c745f708000000           mov dword ptr [rbp - 9], 8
000547d8  418bc8                   mov ecx, r8d
000547db  4d8bf9                   mov r15, r9
000547de  448bc8                   mov r9d, eax
000547e1  c1e910                   shr ecx, 0x10
000547e4  418bc0                   mov eax, r8d
000547e7  83e103                   and ecx, 3
000547ea  83e001                   and eax, 1
000547ed  41ba07000000             mov r10d, 7
000547f3  89450b                   mov dword ptr [rbp + 0xb], eax
000547f6  41bb01000000             mov r11d, 1
000547fc  418bc0                   mov eax, r8d
000547ff  4489559f                 mov dword ptr [rbp - 0x61], r10d
00054803  83e002                   and eax, 2
00054806  44895dfb                 mov dword ptr [rbp - 5], r11d
0005480a  8945ff                   mov dword ptr [rbp - 1], eax
0005480d  458be8                   mov r13d, r8d
00054810  418bc0                   mov eax, r8d
00054813  2500000100               and eax, 0x10000
00054818  8945df                   mov dword ptr [rbp - 0x21], eax
0005481b  418bc0                   mov eax, r8d
0005481e  2500000200               and eax, 0x20000
00054823  8945d3                   mov dword ptr [rbp - 0x2d], eax
00054826  418bc0                   mov eax, r8d
00054829  83e003                   and eax, 3
0005482c  4c8d0561830400           lea r8, [rip + 0x48361]
00054833  8d0c88                   lea ecx, [rax + rcx*4]
00054836  488d05c3b7faff           lea rax, [rip - 0x5483d]
0005483d  0fb6848833050900         movzx eax, byte ptr [rax + rcx*4 + 0x90533]
00054845  8845cc                   mov byte ptr [rbp - 0x34], al
00054848  0c18                     or al, 0x18
0005484a  8845cb                   mov byte ptr [rbp - 0x35], al
0005484d  418b4708                 mov eax, dword ptr [r15 + 8]
00054851  85c0                     test eax, eax
00054853  747b                     je 0x548d0
00054855  41395c2408               cmp dword ptr [r12 + 8], ebx
0005485a  7474                     je 0x548d0
0005485c  498b07                   mov rax, qword ptr [r15]
0005485f  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054863  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
00054867  448945cf                 mov dword ptr [rbp - 0x31], r8d
0005486b  0fb708                   movzx ecx, word ptr [rax]
0005486e  498b5308                 mov rdx, qword ptr [r11 + 8]
00054872  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00054875  0fb7d8                   movzx ebx, ax
00054878  48c1e810                 shr rax, 0x10
0005487c  48c1e320                 shl rbx, 0x20
00054880  480bd8                   or rbx, rax
00054883  498b0424                 mov rax, qword ptr [r12]
00054887  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0005488b  0fb708                   movzx ecx, word ptr [rax]
0005488e  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00054891  0fb64da6                 movzx ecx, byte ptr [rbp - 0x5a]
00054895  0fb655a5                 movzx edx, byte ptr [rbp - 0x5b]
00054899  48894de7                 mov qword ptr [rbp - 0x19], rcx
0005489d  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
000548a1  884d77                   mov byte ptr [rbp + 0x77], cl
000548a4  410fb6c9                 movzx ecx, r9b
000548a8  0fb7f8                   movzx edi, ax
000548ab  884da7                   mov byte ptr [rbp - 0x59], cl
000548ae  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
000548b1  48c1e720                 shl rdi, 0x20
000548b5  48c1e810                 shr rax, 0x10
000548b9  894dab                   mov dword ptr [rbp - 0x55], ecx
000548bc  480bf8                   or rdi, rax
000548bf  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
000548c2  4533ed                   xor r13d, r13d
000548c5  894dc7                   mov dword ptr [rbp - 0x39], ecx
000548c8  8855a8                   mov byte ptr [rbp - 0x58], dl
000548cb  e9de000000               jmp 0x549ae
000548d0  0fb64da6                 movzx ecx, byte ptr [rbp - 0x5a]
000548d4  0fb655a5                 movzx edx, byte ptr [rbp - 0x5b]
000548d8  48894de7                 mov qword ptr [rbp - 0x19], rcx
000548dc  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
000548e0  884d77                   mov byte ptr [rbp + 0x77], cl
000548e3  0fb64da3                 movzx ecx, byte ptr [rbp - 0x5d]
000548e7  884da7                   mov byte ptr [rbp - 0x59], cl
000548ea  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
000548ed  894dab                   mov dword ptr [rbp - 0x55], ecx
000548f0  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
000548f3  894dcf                   mov dword ptr [rbp - 0x31], ecx
000548f6  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
000548f9  894dc7                   mov dword ptr [rbp - 0x39], ecx
000548fc  8855a8                   mov byte ptr [rbp - 0x58], dl
000548ff  410fbae51b               bt r13d, 0x1b
00054904  0f839b130000             jae 0x55ca5
0005490a  85c0                     test eax, eax
0005490c  754e                     jne 0x5495c
0005490e  4139442408               cmp dword ptr [r12 + 8], eax
00054913  0f848c130000             je 0x55ca5
00054919  45895f08                 mov dword ptr [r15 + 8], r11d
0005491d  4533ed                   xor r13d, r13d
00054920  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054924  4d8907                   mov qword ptr [r15], r8
00054927  4d894718                 mov qword ptr [r15 + 0x18], r8
0005492b  4d896f10                 mov qword ptr [r15 + 0x10], r13
0005492f  498b5308                 mov rdx, qword ptr [r11 + 8]
00054933  8b8280000000             mov eax, dword ptr [rdx + 0x80]
00054939  0fb7d8                   movzx ebx, ax
0005493c  48c1e320                 shl rbx, 0x20
00054940  48c1e810                 shr rax, 0x10
00054944  480bd8                   or rbx, rax
00054947  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0005494b  4585c9                   test r9d, r9d
0005494e  7570                     jne 0x549c0
00054950  498b0424                 mov rax, qword ptr [r12]
00054954  0fb708                   movzx ecx, word ptr [rax]
00054957  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005495a  eb44                     jmp 0x549a0
0005495c  45895c2408               mov dword ptr [r12 + 8], r11d
00054961  4533ed                   xor r13d, r13d
00054964  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054968  4d890424                 mov qword ptr [r12], r8
0005496c  4d89442418               mov qword ptr [r12 + 0x18], r8
00054971  4d896c2410               mov qword ptr [r12 + 0x10], r13
00054976  498b5308                 mov rdx, qword ptr [r11 + 8]
0005497a  4585c9                   test r9d, r9d
0005497d  751b                     jne 0x5499a
0005497f  498b07                   mov rax, qword ptr [r15]
00054982  0fb708                   movzx ecx, word ptr [rax]
00054985  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00054988  0fb7d8                   movzx ebx, ax
0005498b  48c1e320                 shl rbx, 0x20
0005498f  48c1e810                 shr rax, 0x10
00054993  480bd8                   or rbx, rax
00054996  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0005499a  8b8280000000             mov eax, dword ptr [rdx + 0x80]
000549a0  0fb7f8                   movzx edi, ax
000549a3  48c1e720                 shl rdi, 0x20
000549a7  48c1e810                 shr rax, 0x10
000549ab  480bf8                   or rdi, rax
000549ae  48897db7                 mov qword ptr [rbp - 0x49], rdi
000549b2  0f1f4000                 nop dword ptr [rax]
000549b6  66660f1f840000000000     nop word ptr [rax + rax]
000549c0  41837b1400               cmp dword ptr [r11 + 0x14], 0
000549c5  44896daf                 mov dword ptr [rbp - 0x51], r13d
000549c9  0f84af000000             je 0x54a7e
000549cf  4d8b4338                 mov r8, qword ptr [r11 + 0x38]
000549d3  488bc3                   mov rax, rbx
000549d6  4d85c0                   test r8, r8
000549d9  7441                     je 0x54a1c
000549db  48c1e828                 shr rax, 0x28
000549df  3cfe                     cmp al, 0xfe
000549e1  7514                     jne 0x549f7
000549e3  4c8d4dbf                 lea r9, [rbp - 0x41]
000549e7  498bd7                   mov rdx, r15
000549ea  e8111a0000               call 0x56400
000549ef  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
000549f3  488b5dbf                 mov rbx, qword ptr [rbp - 0x41]
000549f7  488bc7                   mov rax, rdi
000549fa  48c1e828                 shr rax, 0x28
000549fe  3cfe                     cmp al, 0xfe
00054a00  0f8578000000             jne 0x54a7e
00054a06  4d8b4338                 mov r8, qword ptr [r11 + 0x38]
00054a0a  4c8d4db7                 lea r9, [rbp - 0x49]
00054a0e  498bd4                   mov rdx, r12
00054a11  e8ea190000               call 0x56400
00054a16  488b7db7                 mov rdi, qword ptr [rbp - 0x49]
00054a1a  eb62                     jmp 0x54a7e
00054a1c  48c1e808                 shr rax, 8
00054a20  a8c0                     test al, 0xc0
00054a22  741e                     je 0x54a42
00054a24  49837f1000               cmp qword ptr [r15 + 0x10], 0
00054a29  7517                     jne 0x54a42
00054a2b  4c8d4dbf                 lea r9, [rbp - 0x41]
00054a2f  4d8bc3                   mov r8, r11
00054a32  498bd7                   mov rdx, r15
00054a35  e8f6130000               call 0x55e30
00054a3a  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054a3e  488b5dbf                 mov rbx, qword ptr [rbp - 0x41]
00054a42  488bc7                   mov rax, rdi
00054a45  48c1e808                 shr rax, 8
00054a49  a8c0                     test al, 0xc0
00054a4b  741b                     je 0x54a68
00054a4d  49837c241000             cmp qword ptr [r12 + 0x10], 0
00054a53  7513                     jne 0x54a68
00054a55  4c8d4db7                 lea r9, [rbp - 0x49]
00054a59  4d8bc3                   mov r8, r11
00054a5c  498bd4                   mov rdx, r12
00054a5f  e8cc130000               call 0x55e30
00054a64  488b7db7                 mov rdi, qword ptr [rbp - 0x49]
00054a68  4881e3ff3fffff           and rbx, 0xffffffffffff3fff
00054a6f  4881e7ff3fffff           and rdi, 0xffffffffffff3fff
00054a76  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054a7a  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054a7e  4c8bdb                   mov r11, rbx
00054a81  4c8bef                   mov r13, rdi
00054a84  49c1eb28                 shr r11, 0x28
00054a88  49c1ed28                 shr r13, 0x28
00054a8c  4c895def                 mov qword ptr [rbp - 0x11], r11
00054a90  4c896dd7                 mov qword ptr [rbp - 0x29], r13
00054a94  4180fb06                 cmp r11b, 6
00054a98  0f86ec000000             jbe 0x54b8a
00054a9e  4180fd06                 cmp r13b, 6
00054aa2  0f8641010000             jbe 0x54be9
00054aa8  4c8bf3                   mov r14, rbx
00054aab  488bf7                   mov rsi, rdi
00054aae  448b559f                 mov r10d, dword ptr [rbp - 0x61]
00054ab2  b803000000               mov eax, 3
00054ab7  41b901000000             mov r9d, 1
00054abd  488bd3                   mov rdx, rbx
00054ac0  4c8bc7                   mov r8, rdi
00054ac3  48c1ea10                 shr rdx, 0x10
00054ac7  49c1e810                 shr r8, 0x10
00054acb  413bd0                   cmp edx, r8d
00054ace  0f85be110000             jne 0x55c92
00054ad4  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054ad8  33c0                     xor eax, eax
00054ada  4c8beb                   mov r13, rbx
00054add  49c1ed28                 shr r13, 0x28
00054ae1  4180fd14                 cmp r13b, 0x14
00054ae5  0f96c0                   setbe al
00054ae8  8945fb                   mov dword ptr [rbp - 5], eax
00054aeb  483bdf                   cmp rbx, rdi
00054aee  0f8499100000             je 0x55b8d
00054af4  418d4540                 lea eax, [r13 + 0x40]
00054af8  3c30                     cmp al, 0x30
00054afa  0f87c10f0000             ja 0x55ac1
00054b00  418b0b                   mov ecx, dword ptr [r11]
00054b03  8bc1                     mov eax, ecx
00054b05  25ff030000               and eax, 0x3ff
00054b0a  83f804                   cmp eax, 4
00054b0d  740c                     je 0x54b1b
00054b0f  81f911040400             cmp ecx, 0x40411
00054b15  0f85a60f0000             jne 0x55ac1
00054b1b  0fb6cb                   movzx ecx, bl
00054b1e  c1e108                   shl ecx, 8
00054b21  48c1eb08                 shr rbx, 8
00054b25  0fb6db                   movzx ebx, bl
00054b28  480bd9                   or rbx, rcx
00054b2b  8bc2                     mov eax, edx
00054b2d  400fb6cf                 movzx ecx, dil
00054b31  480bd8                   or rbx, rax
00054b34  48c1ef08                 shr rdi, 8
00054b38  400fb6ff                 movzx edi, dil
00054b3c  c1e108                   shl ecx, 8
00054b3f  480bf9                   or rdi, rcx
00054b42  418bc0                   mov eax, r8d
00054b45  480bf8                   or rdi, rax
00054b48  48c1e310                 shl rbx, 0x10
00054b4c  4881cb02020000           or rbx, 0x202
00054b53  48c1e710                 shl rdi, 0x10
00054b57  4881cf02020000           or rdi, 0x202
00054b5e  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054b62  488bcf                   mov rcx, rdi
00054b65  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054b69  488bc3                   mov rax, rbx
00054b6c  48c1e910                 shr rcx, 0x10
00054b70  48c1e810                 shr rax, 0x10
00054b74  3bc1                     cmp eax, ecx
00054b76  0f8411100000             je 0x55b8d
00054b7c  b803000000               mov eax, 3
00054b81  410f42c1                 cmovb eax, r9d
00054b85  e915120000               jmp 0x55d9f
00054b8a  4584db                   test r11b, r11b
00054b8d  755a                     jne 0x54be9
00054b8f  418b4f08                 mov ecx, dword ptr [r15 + 8]
00054b93  498d470e                 lea rax, [r15 + 0xe]
00054b97  498b17                   mov rdx, qword ptr [r15]
00054b9a  ffc9                     dec ecx
00054b9c  483bd0                   cmp rdx, rax
00054b9f  7406                     je 0x54ba7
00054ba1  488d4202                 lea rax, [rdx + 2]
00054ba5  eb0c                     jmp 0x54bb3
00054ba7  498b4710                 mov rax, qword ptr [r15 + 0x10]
00054bab  49c7471000000000         mov qword ptr [r15 + 0x10], 0
00054bb3  498907                   mov qword ptr [r15], rax
00054bb6  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
00054bba  41894f08                 mov dword ptr [r15 + 8], ecx
00054bbe  85c9                     test ecx, ecx
00054bc0  741c                     je 0x54bde
00054bc2  0fb708                   movzx ecx, word ptr [rax]
00054bc5  498b4008                 mov rax, qword ptr [r8 + 8]
00054bc9  8b1488                   mov edx, dword ptr [rax + rcx*4]
00054bcc  0fb7da                   movzx ebx, dx
00054bcf  48c1e320                 shl rbx, 0x20
00054bd3  48c1ea10                 shr rdx, 0x10
00054bd7  480bda                   or rbx, rdx
00054bda  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054bde  41ba01000000             mov r10d, 1
00054be4  458bca                   mov r9d, r10d
00054be7  eb0e                     jmp 0x54bf7
00054be9  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
00054bed  41ba01000000             mov r10d, 1
00054bf3  448b4daf                 mov r9d, dword ptr [rbp - 0x51]
00054bf7  4584ed                   test r13b, r13b
00054bfa  7555                     jne 0x54c51
00054bfc  418b4c2408               mov ecx, dword ptr [r12 + 8]
00054c01  498d44240e               lea rax, [r12 + 0xe]
00054c06  498b1424                 mov rdx, qword ptr [r12]
00054c0a  ffc9                     dec ecx
00054c0c  483bd0                   cmp rdx, rax
00054c0f  7406                     je 0x54c17
00054c11  488d4202                 lea rax, [rdx + 2]
00054c15  eb0e                     jmp 0x54c25
00054c17  498b442410               mov rax, qword ptr [r12 + 0x10]
00054c1c  49c744241000000000       mov qword ptr [r12 + 0x10], 0
00054c25  49890424                 mov qword ptr [r12], rax
00054c29  41894c2408               mov dword ptr [r12 + 8], ecx
00054c2e  85c9                     test ecx, ecx
00054c30  741c                     je 0x54c4e
00054c32  0fb708                   movzx ecx, word ptr [rax]
00054c35  498b4008                 mov rax, qword ptr [r8 + 8]
00054c39  8b1488                   mov edx, dword ptr [rax + rcx*4]
00054c3c  0fb7fa                   movzx edi, dx
00054c3f  48c1e720                 shl rdi, 0x20
00054c43  48c1ea10                 shr rdx, 0x10
00054c47  480bfa                   or rdi, rdx
00054c4a  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054c4e  458bca                   mov r9d, r10d
00054c51  837dff00                 cmp dword ptr [rbp - 1], 0
00054c55  0f84b9000000             je 0x54d14
00054c5b  837dfb00                 cmp dword ptr [rbp - 5], 0
00054c5f  0f84af000000             je 0x54d14
00054c65  4180fb01                 cmp r11b, 1
00054c69  754e                     jne 0x54cb9
00054c6b  418b4f08                 mov ecx, dword ptr [r15 + 8]
00054c6f  498d470e                 lea rax, [r15 + 0xe]
00054c73  498b17                   mov rdx, qword ptr [r15]
00054c76  ffc9                     dec ecx
00054c78  483bd0                   cmp rdx, rax
00054c7b  7406                     je 0x54c83
00054c7d  488d4202                 lea rax, [rdx + 2]
00054c81  eb0c                     jmp 0x54c8f
00054c83  498b4710                 mov rax, qword ptr [r15 + 0x10]
00054c87  49c7471000000000         mov qword ptr [r15 + 0x10], 0
00054c8f  498907                   mov qword ptr [r15], rax
00054c92  41894f08                 mov dword ptr [r15 + 8], ecx
00054c96  85c9                     test ecx, ecx
00054c98  741c                     je 0x54cb6
00054c9a  0fb708                   movzx ecx, word ptr [rax]
00054c9d  498b4008                 mov rax, qword ptr [r8 + 8]
00054ca1  8b1488                   mov edx, dword ptr [rax + rcx*4]
00054ca4  0fb7da                   movzx ebx, dx
00054ca7  48c1e320                 shl rbx, 0x20
00054cab  48c1ea10                 shr rdx, 0x10
00054caf  480bda                   or rbx, rdx
00054cb2  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054cb6  458bca                   mov r9d, r10d
00054cb9  4180fd01                 cmp r13b, 1
00054cbd  7555                     jne 0x54d14
00054cbf  418b4c2408               mov ecx, dword ptr [r12 + 8]
00054cc4  498d44240e               lea rax, [r12 + 0xe]
00054cc9  498b1424                 mov rdx, qword ptr [r12]
00054ccd  ffc9                     dec ecx
00054ccf  483bd0                   cmp rdx, rax
00054cd2  7406                     je 0x54cda
00054cd4  488d4202                 lea rax, [rdx + 2]
00054cd8  eb0e                     jmp 0x54ce8
00054cda  498b442410               mov rax, qword ptr [r12 + 0x10]
00054cdf  49c744241000000000       mov qword ptr [r12 + 0x10], 0
00054ce8  49890424                 mov qword ptr [r12], rax
00054cec  41894c2408               mov dword ptr [r12 + 8], ecx
00054cf1  85c9                     test ecx, ecx
00054cf3  741c                     je 0x54d11
00054cf5  0fb708                   movzx ecx, word ptr [rax]
00054cf8  498b4008                 mov rax, qword ptr [r8 + 8]
00054cfc  8b1488                   mov edx, dword ptr [rax + rcx*4]
00054cff  0fb7fa                   movzx edi, dx
00054d02  48c1e720                 shl rdi, 0x20
00054d06  48c1ea10                 shr rdx, 0x10
00054d0a  480bfa                   or rdi, rdx
00054d0d  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054d11  458bca                   mov r9d, r10d
00054d14  4180fb02                 cmp r11b, 2
00054d18  0f85b7000000             jne 0x54dd5
00054d1e  458b5f08                 mov r11d, dword ptr [r15 + 8]
00054d22  4d8d4f0e                 lea r9, [r15 + 0xe]
00054d26  488bc3                   mov rax, rbx
00054d29  498d570c                 lea rdx, [r15 + 0xc]
00054d2d  48c1e808                 shr rax, 8
00054d31  0fb6c8                   movzx ecx, al
00054d34  48c1eb20                 shr rbx, 0x20
00054d38  48c1e108                 shl rcx, 8
00054d3c  0fb6c3                   movzx eax, bl
00054d3f  480bc8                   or rcx, rax
00054d42  488b455f                 mov rax, qword ptr [rbp + 0x5f]
00054d46  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00054d4d  448b0488                 mov r8d, dword ptr [rax + rcx*4]
00054d51  440fb71488               movzx r10d, word ptr [rax + rcx*4]
00054d56  498b07                   mov rax, qword ptr [r15]
00054d59  41c1e810                 shr r8d, 0x10
00054d5d  493bc1                   cmp rax, r9
00054d60  741a                     je 0x54d7c
00054d62  498b4f10                 mov rcx, qword ptr [r15 + 0x10]
00054d66  4883c002                 add rax, 2
00054d6a  498907                   mov qword ptr [r15], rax
00054d6d  66448912                 mov word ptr [rdx], r10w
00054d71  66458901                 mov word ptr [r9], r8w
00054d75  4885c9                   test rcx, rcx
00054d78  751e                     jne 0x54d98
00054d7a  eb15                     jmp 0x54d91
00054d7c  498b4710                 mov rax, qword ptr [r15 + 0x10]
00054d80  33c9                     xor ecx, ecx
00054d82  49894f10                 mov qword ptr [r15 + 0x10], rcx
00054d86  498907                   mov qword ptr [r15], rax
00054d89  66448912                 mov word ptr [rdx], r10w
00054d8d  66458901                 mov word ptr [r9], r8w
00054d91  498b07                   mov rax, qword ptr [r15]
00054d94  49894710                 mov qword ptr [r15 + 0x10], rax
00054d98  498917                   mov qword ptr [r15], rdx
00054d9b  418d4301                 lea eax, [r11 + 1]
00054d9f  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
00054da3  41894708                 mov dword ptr [r15 + 8], eax
00054da7  488b4567                 mov rax, qword ptr [rbp + 0x67]
00054dab  488b4008                 mov rax, qword ptr [rax + 8]
00054daf  428b1490                 mov edx, dword ptr [rax + r10*4]
00054db3  41ba01000000             mov r10d, 1
00054db9  0fb7da                   movzx ebx, dx
00054dbc  458bca                   mov r9d, r10d
00054dbf  48c1e320                 shl rbx, 0x20
00054dc3  48c1ea10                 shr rdx, 0x10
00054dc7  480bda                   or rbx, rdx
00054dca  33d2                     xor edx, edx
00054dcc  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054dd0  448bf2                   mov r14d, edx
00054dd3  eb02                     jmp 0x54dd7
00054dd5  33d2                     xor edx, edx
00054dd7  4180fd02                 cmp r13b, 2
00054ddb  0f85c5000000             jne 0x54ea6
00054de1  458b5c2408               mov r11d, dword ptr [r12 + 8]
00054de6  4d8d4c240e               lea r9, [r12 + 0xe]
00054deb  488bc7                   mov rax, rdi
00054dee  48c1ef20                 shr rdi, 0x20
00054df2  48c1e808                 shr rax, 8
00054df6  0fb6c8                   movzx ecx, al
00054df9  48c1e108                 shl rcx, 8
00054dfd  400fb6c7                 movzx eax, dil
00054e01  480bc8                   or rcx, rax
00054e04  488b455f                 mov rax, qword ptr [rbp + 0x5f]
00054e08  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00054e0f  448b0488                 mov r8d, dword ptr [rax + rcx*4]
00054e13  440fb71488               movzx r10d, word ptr [rax + rcx*4]
00054e18  498b0424                 mov rax, qword ptr [r12]
00054e1c  41c1e810                 shr r8d, 0x10
00054e20  493bc1                   cmp rax, r9
00054e23  7421                     je 0x54e46
00054e25  498b4c2410               mov rcx, qword ptr [r12 + 0x10]
00054e2a  498d54240c               lea rdx, [r12 + 0xc]
00054e2f  4883c002                 add rax, 2
00054e33  49890424                 mov qword ptr [r12], rax
00054e37  66448912                 mov word ptr [rdx], r10w
00054e3b  66458901                 mov word ptr [r9], r8w
00054e3f  4885c9                   test rcx, rcx
00054e42  7526                     jne 0x54e6a
00054e44  eb1b                     jmp 0x54e61
00054e46  498b442410               mov rax, qword ptr [r12 + 0x10]
00054e4b  4989542410               mov qword ptr [r12 + 0x10], rdx
00054e50  498d54240c               lea rdx, [r12 + 0xc]
00054e55  49890424                 mov qword ptr [r12], rax
00054e59  66448912                 mov word ptr [rdx], r10w
00054e5d  66458901                 mov word ptr [r9], r8w
00054e61  498b0424                 mov rax, qword ptr [r12]
00054e65  4989442410               mov qword ptr [r12 + 0x10], rax
00054e6a  418d4301                 lea eax, [r11 + 1]
00054e6e  49891424                 mov qword ptr [r12], rdx
00054e72  4189442408               mov dword ptr [r12 + 8], eax
00054e77  41bb01000000             mov r11d, 1
00054e7d  488b4567                 mov rax, qword ptr [rbp + 0x67]
00054e81  458bcb                   mov r9d, r11d
00054e84  488b4008                 mov rax, qword ptr [rax + 8]
00054e88  428b1490                 mov edx, dword ptr [rax + r10*4]
00054e8c  0fb7fa                   movzx edi, dx
00054e8f  48c1e720                 shl rdi, 0x20
00054e93  48c1ea10                 shr rdx, 0x10
00054e97  480bfa                   or rdi, rdx
00054e9a  4533ed                   xor r13d, r13d
00054e9d  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054ea1  418bf5                   mov esi, r13d
00054ea4  eb0e                     jmp 0x54eb4
00054ea6  4585c9                   test r9d, r9d
00054ea9  742a                     je 0x54ed5
00054eab  41bb01000000             mov r11d, 1
00054eb1  4533ed                   xor r13d, r13d
00054eb4  418b4708                 mov eax, dword ptr [r15 + 8]
00054eb8  85c0                     test eax, eax
00054eba  0f849e0d0000             je 0x55c5e
00054ec0  41837c240800             cmp dword ptr [r12 + 8], 0
00054ec6  0f84920d0000             je 0x55c5e
00054ecc  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054ed0  e9ebfaffff               jmp 0x549c0
00054ed5  410fb6c3                 movzx eax, r11b
00054ed9  83f806                   cmp eax, 6
00054edc  0f8748030000             ja 0x5522a
00054ee2  4c8d0517b1faff           lea r8, [rip - 0x54ee9]
00054ee9  418b8c80b45d0500         mov ecx, dword ptr [r8 + rax*4 + 0x55db4]
00054ef1  4903c8                   add rcx, r8
00054ef4  ffe1                     jmp rcx
00054ef6  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00054efa  4d8bc7                   mov r8, r15
00054efd  e8ee150000               call 0x564f0
00054f02  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
00054f06  440fb7e8                 movzx r13d, ax
00054f0a  33d2                     xor edx, edx
00054f0c  0fb6c3                   movzx eax, bl
00054f0f  664403e8                 add r13w, ax
00054f13  440fb7c2                 movzx r8d, dx
00054f17  44385dd7                 cmp byte ptr [rbp - 0x29], r11b
00054f1b  0f8579000000             jne 0x54f9a
00054f21  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00054f25  4d8bc4                   mov r8, r12
00054f28  e8c3150000               call 0x564f0
00054f2d  498b0c24                 mov rcx, qword ptr [r12]
00054f31  440fb7c0                 movzx r8d, ax
00054f35  400fb6c7                 movzx eax, dil
00054f39  664403c0                 add r8w, ax
00054f3d  498d44240e               lea rax, [r12 + 0xe]
00054f42  483bc8                   cmp rcx, rax
00054f45  740d                     je 0x54f54
00054f47  41ff4c2408               dec dword ptr [r12 + 8]
00054f4c  488d4102                 lea rax, [rcx + 2]
00054f50  33d2                     xor edx, edx
00054f52  eb11                     jmp 0x54f65
00054f54  498b442410               mov rax, qword ptr [r12 + 0x10]
00054f59  33d2                     xor edx, edx
00054f5b  41ff4c2408               dec dword ptr [r12 + 8]
00054f60  4989542410               mov qword ptr [r12 + 0x10], rdx
00054f65  418b4c2408               mov ecx, dword ptr [r12 + 8]
00054f6a  4c8b4d67                 mov r9, qword ptr [rbp + 0x67]
00054f6e  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
00054f72  49890424                 mov qword ptr [r12], rax
00054f76  85c9                     test ecx, ecx
00054f78  7424                     je 0x54f9e
00054f7a  0fb708                   movzx ecx, word ptr [rax]
00054f7d  498b4108                 mov rax, qword ptr [r9 + 8]
00054f81  8b1488                   mov edx, dword ptr [rax + rcx*4]
00054f84  0fb7fa                   movzx edi, dx
00054f87  48c1e720                 shl rdi, 0x20
00054f8b  48c1ea10                 shr rdx, 0x10
00054f8f  480bfa                   or rdi, rdx
00054f92  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054f96  33d2                     xor edx, edx
00054f98  eb04                     jmp 0x54f9e
00054f9a  4c8b4d67                 mov r9, qword ptr [rbp + 0x67]
00054f9e  66453be8                 cmp r13w, r8w
00054fa2  742a                     je 0x54fce
00054fa4  837d9f00                 cmp dword ptr [rbp - 0x61], 0
00054fa8  7f07                     jg 0x54fb1
00054faa  4183791000               cmp dword ptr [r9 + 0x10], 0
00054faf  741d                     je 0x54fce
00054fb1  41ba01000000             mov r10d, 1
00054fb7  89559f                   mov dword ptr [rbp - 0x61], edx
00054fba  66453be8                 cmp r13w, r8w
00054fbe  418bc2                   mov eax, r10d
00054fc1  b903000000               mov ecx, 3
00054fc6  0f47c1                   cmova eax, ecx
00054fc9  8945ab                   mov dword ptr [rbp - 0x55], eax
00054fcc  eb06                     jmp 0x54fd4
00054fce  41ba01000000             mov r10d, 1
00054fd4  418b4f08                 mov ecx, dword ptr [r15 + 8]
00054fd8  498d470e                 lea rax, [r15 + 0xe]
00054fdc  498b17                   mov rdx, qword ptr [r15]
00054fdf  ffc9                     dec ecx
00054fe1  483bd0                   cmp rdx, rax
00054fe4  7406                     je 0x54fec
00054fe6  488d4202                 lea rax, [rdx + 2]
00054fea  eb0a                     jmp 0x54ff6
00054fec  498b4710                 mov rax, qword ptr [r15 + 0x10]
00054ff0  33d2                     xor edx, edx
00054ff2  49895710                 mov qword ptr [r15 + 0x10], rdx
00054ff6  498907                   mov qword ptr [r15], rax
00054ff9  41894f08                 mov dword ptr [r15 + 8], ecx
00054ffd  85c9                     test ecx, ecx
00054fff  741c                     je 0x5501d
00055001  0fb708                   movzx ecx, word ptr [rax]
00055004  498b4108                 mov rax, qword ptr [r9 + 8]
00055008  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005500b  0fb7da                   movzx ebx, dx
0005500e  48c1e320                 shl rbx, 0x20
00055012  48c1ea10                 shr rdx, 0x10
00055016  480bda                   or rbx, rdx
00055019  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0005501d  4c8b6dd7                 mov r13, qword ptr [rbp - 0x29]
00055021  458bca                   mov r9d, r10d
00055024  448955af                 mov dword ptr [rbp - 0x51], r10d
00055028  e904020000               jmp 0x55231
0005502d  4c8bf3                   mov r14, rbx
00055030  4180fd06                 cmp r13b, 6
00055034  0f84f3010000             je 0x5522d
0005503a  448b459f                 mov r8d, dword ptr [rbp - 0x61]
0005503e  4183f806                 cmp r8d, 6
00055042  7f08                     jg 0x5504c
00055044  7525                     jne 0x5506b
00055046  837dcf00                 cmp dword ptr [rbp - 0x31], 0
0005504a  751f                     jne 0x5506b
0005504c  4183f806                 cmp r8d, 6
00055050  448955cf                 mov dword ptr [rbp - 0x31], r10d
00055054  8bc2                     mov eax, edx
00055056  c745ab03000000           mov dword ptr [rbp - 0x55], 3
0005505d  0f4e45c7                 cmovle eax, dword ptr [rbp - 0x39]
00055061  8945c7                   mov dword ptr [rbp - 0x39], eax
00055064  c7459f06000000           mov dword ptr [rbp - 0x61], 6
0005506b  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005506f  498d470e                 lea rax, [r15 + 0xe]
00055073  498b17                   mov rdx, qword ptr [r15]
00055076  ffc9                     dec ecx
00055078  483bd0                   cmp rdx, rax
0005507b  7406                     je 0x55083
0005507d  488d4202                 lea rax, [rdx + 2]
00055081  eb0a                     jmp 0x5508d
00055083  498b4710                 mov rax, qword ptr [r15 + 0x10]
00055087  33d2                     xor edx, edx
00055089  49895710                 mov qword ptr [r15 + 0x10], rdx
0005508d  498907                   mov qword ptr [r15], rax
00055090  41894f08                 mov dword ptr [r15 + 8], ecx
00055094  85c9                     test ecx, ecx
00055096  7420                     je 0x550b8
00055098  0fb708                   movzx ecx, word ptr [rax]
0005509b  488b4567                 mov rax, qword ptr [rbp + 0x67]
0005509f  488b4008                 mov rax, qword ptr [rax + 8]
000550a3  8b1488                   mov edx, dword ptr [rax + rcx*4]
000550a6  0fb7da                   movzx ebx, dx
000550a9  48c1e320                 shl rbx, 0x20
000550ad  48c1ea10                 shr rdx, 0x10
000550b1  480bda                   or rbx, rdx
000550b4  48895dbf                 mov qword ptr [rbp - 0x41], rbx
000550b8  458bca                   mov r9d, r10d
000550bb  e96d010000               jmp 0x5522d
000550c0  4180fd06                 cmp r13b, 6
000550c4  0f8463010000             je 0x5522d
000550ca  4180fd01                 cmp r13b, 1
000550ce  0f8459010000             je 0x5522d
000550d4  89542450                 mov dword ptr [rsp + 0x50], edx
000550d8  488bc2                   mov rax, rdx
000550db  488bcb                   mov rcx, rbx
000550de  4c8bf2                   mov r14, rdx
000550e1  488b5567                 mov rdx, qword ptr [rbp + 0x67]
000550e5  4180fd04                 cmp r13b, 4
000550e9  4d8bcc                   mov r9, r12
000550ec  4d8bc7                   mov r8, r15
000550ef  480f45c6                 cmovne rax, rsi
000550f3  48c1e920                 shr rcx, 0x20
000550f7  488bf0                   mov rsi, rax
000550fa  66894da3                 mov word ptr [rbp - 0x5d], cx
000550fe  488bc7                   mov rax, rdi
00055101  48c1e310                 shl rbx, 0x10
00055105  48c1e820                 shr rax, 0x20
00055109  0bd9                     or ebx, ecx
0005510b  488b4d5f                 mov rcx, qword ptr [rbp + 0x5f]
0005510f  668945af                 mov word ptr [rbp - 0x51], ax
00055113  48c1e710                 shl rdi, 0x10
00055117  0bf8                     or edi, eax
00055119  895dd7                   mov dword ptr [rbp - 0x29], ebx
0005511c  488d4503                 lea rax, [rbp + 3]
00055120  897db7                   mov dword ptr [rbp - 0x49], edi
00055123  4889442448               mov qword ptr [rsp + 0x48], rax
00055128  488d45f7                 lea rax, [rbp - 9]
0005512c  4889442440               mov qword ptr [rsp + 0x40], rax
00055131  488d45af                 lea rax, [rbp - 0x51]
00055135  4889442438               mov qword ptr [rsp + 0x38], rax
0005513a  488d45a3                 lea rax, [rbp - 0x5d]
0005513e  4889442430               mov qword ptr [rsp + 0x30], rax
00055143  488d45b7                 lea rax, [rbp - 0x49]
00055147  4889442428               mov qword ptr [rsp + 0x28], rax
0005514c  488d45d7                 lea rax, [rbp - 0x29]
00055150  4889442420               mov qword ptr [rsp + 0x20], rax
00055155  e8e6c1ffff               call 0x51340
0005515a  448bc8                   mov r9d, eax
0005515d  8945af                   mov dword ptr [rbp - 0x51], eax
00055160  8b4503                   mov eax, dword ptr [rbp + 3]
00055163  83f802                   cmp eax, 2
00055166  0f85330c0000             jne 0x55d9f
0005516c  8b45b7                   mov eax, dword ptr [rbp - 0x49]
0005516f  8b4dd7                   mov ecx, dword ptr [rbp - 0x29]
00055172  0fb7d9                   movzx ebx, cx
00055175  0fb7f8                   movzx edi, ax
00055178  48c1e320                 shl rbx, 0x20
0005517c  48c1e720                 shl rdi, 0x20
00055180  48c1e910                 shr rcx, 0x10
00055184  48c1e810                 shr rax, 0x10
00055188  480bd9                   or rbx, rcx
0005518b  480bf8                   or rdi, rax
0005518e  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055192  48897db7                 mov qword ptr [rbp - 0x49], rdi
00055196  4585c9                   test r9d, r9d
00055199  744e                     je 0x551e9
0005519b  41837f0800               cmp dword ptr [r15 + 8], 0
000551a0  7447                     je 0x551e9
000551a2  41837c240800             cmp dword ptr [r12 + 8], 0
000551a8  743f                     je 0x551e9
000551aa  488b4567                 mov rax, qword ptr [rbp + 0x67]
000551ae  488b5008                 mov rdx, qword ptr [rax + 8]
000551b2  498b07                   mov rax, qword ptr [r15]
000551b5  0fb708                   movzx ecx, word ptr [rax]
000551b8  8b048a                   mov eax, dword ptr [rdx + rcx*4]
000551bb  0fb7d8                   movzx ebx, ax
000551be  48c1e810                 shr rax, 0x10
000551c2  48c1e320                 shl rbx, 0x20
000551c6  480bd8                   or rbx, rax
000551c9  498b0424                 mov rax, qword ptr [r12]
000551cd  48895dbf                 mov qword ptr [rbp - 0x41], rbx
000551d1  0fb708                   movzx ecx, word ptr [rax]
000551d4  8b048a                   mov eax, dword ptr [rdx + rcx*4]
000551d7  0fb7f8                   movzx edi, ax
000551da  48c1e720                 shl rdi, 0x20
000551de  48c1e810                 shr rax, 0x10
000551e2  480bf8                   or rdi, rax
000551e5  48897db7                 mov qword ptr [rbp - 0x49], rdi
000551e9  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
000551ed  41ba01000000             mov r10d, 1
000551f3  eb3c                     jmp 0x55231
000551f5  488bc3                   mov rax, rbx
000551f8  44894daf                 mov dword ptr [rbp - 0x51], r9d
000551fc  48c1e820                 shr rax, 0x20
00055200  48ba02020000fffd0000     movabs rdx, 0xfdff00000202
0005520a  0fb6c8                   movzx ecx, al
0005520d  0fb6c3                   movzx eax, bl
00055210  48c1e108                 shl rcx, 8
00055214  488bd9                   mov rbx, rcx
00055217  480bd8                   or rbx, rax
0005521a  48c1e310                 shl rbx, 0x10
0005521e  480bda                   or rbx, rdx
00055221  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055225  4c8bf3                   mov r14, rbx
00055228  eb11                     jmp 0x5523b
0005522a  4c8bf3                   mov r14, rbx
0005522d  44894daf                 mov dword ptr [rbp - 0x51], r9d
00055231  48ba02020000fffd0000     movabs rdx, 0xfdff00000202
0005523b  410fb6c5                 movzx eax, r13b
0005523f  83f806                   cmp eax, 6
00055242  0f875b030000             ja 0x555a3
00055248  4c8d05b1adfaff           lea r8, [rip - 0x5524f]
0005524f  418b8c80d05d0500         mov ecx, dword ptr [r8 + rax*4 + 0x55dd0]
00055257  4903c8                   add rcx, r8
0005525a  ffe1                     jmp rcx
0005525c  453add                   cmp r11b, r13b
0005525f  0f8441030000             je 0x555a6
00055265  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
00055269  4d8bc4                   mov r8, r12
0005526c  498bd5                   mov rdx, r13
0005526f  e87c120000               call 0x564f0
00055274  440fb7c0                 movzx r8d, ax
00055278  400fb6c7                 movzx eax, dil
0005527c  4403c0                   add r8d, eax
0005527f  837d9f00                 cmp dword ptr [rbp - 0x61], 0
00055283  7f07                     jg 0x5528c
00055285  41837d1000               cmp dword ptr [r13 + 0x10], 0
0005528a  7418                     je 0x552a4
0005528c  41ba01000000             mov r10d, 1
00055292  4585c0                   test r8d, r8d
00055295  7413                     je 0x552aa
00055297  4533c0                   xor r8d, r8d
0005529a  448955ab                 mov dword ptr [rbp - 0x55], r10d
0005529e  4489459f                 mov dword ptr [rbp - 0x61], r8d
000552a2  eb09                     jmp 0x552ad
000552a4  41ba01000000             mov r10d, 1
000552aa  4533c0                   xor r8d, r8d
000552ad  418b4c2408               mov ecx, dword ptr [r12 + 8]
000552b2  498d44240e               lea rax, [r12 + 0xe]
000552b7  498b1424                 mov rdx, qword ptr [r12]
000552bb  ffc9                     dec ecx
000552bd  483bd0                   cmp rdx, rax
000552c0  7406                     je 0x552c8
000552c2  488d4202                 lea rax, [rdx + 2]
000552c6  eb0a                     jmp 0x552d2
000552c8  498b442410               mov rax, qword ptr [r12 + 0x10]
000552cd  4d89442410               mov qword ptr [r12 + 0x10], r8
000552d2  49890424                 mov qword ptr [r12], rax
000552d6  41894c2408               mov dword ptr [r12 + 8], ecx
000552db  85c9                     test ecx, ecx
000552dd  741c                     je 0x552fb
000552df  0fb708                   movzx ecx, word ptr [rax]
000552e2  498b4508                 mov rax, qword ptr [r13 + 8]
000552e6  8b1488                   mov edx, dword ptr [rax + rcx*4]
000552e9  0fb7fa                   movzx edi, dx
000552ec  48c1e720                 shl rdi, 0x20
000552f0  48c1ea10                 shr rdx, 0x10
000552f4  480bfa                   or rdi, rdx
000552f7  48897db7                 mov qword ptr [rbp - 0x49], rdi
000552fb  458bca                   mov r9d, r10d
000552fe  e9a8020000               jmp 0x555ab
00055303  488bf7                   mov rsi, rdi
00055306  4180fb06                 cmp r11b, 6
0005530a  743f                     je 0x5534b
0005530c  448b459f                 mov r8d, dword ptr [rbp - 0x61]
00055310  4183f806                 cmp r8d, 6
00055314  7f10                     jg 0x55326
00055316  0f85fc000000             jne 0x55418
0005531c  837dc700                 cmp dword ptr [rbp - 0x39], 0
00055320  0f85f2000000             jne 0x55418
00055326  4533db                   xor r11d, r11d
00055329  448955c7                 mov dword ptr [rbp - 0x39], r10d
0005532d  4183f806                 cmp r8d, 6
00055331  448955ab                 mov dword ptr [rbp - 0x55], r10d
00055335  418bc3                   mov eax, r11d
00055338  c7459f06000000           mov dword ptr [rbp - 0x61], 6
0005533f  0f4e45cf                 cmovle eax, dword ptr [rbp - 0x31]
00055343  8945cf                   mov dword ptr [rbp - 0x31], eax
00055346  e9d0000000               jmp 0x5541b
0005534b  837d9f06                 cmp dword ptr [rbp - 0x61], 6
0005534f  7f23                     jg 0x55374
00055351  7575                     jne 0x553c8
00055353  837dcf00                 cmp dword ptr [rbp - 0x31], 0
00055357  740c                     je 0x55365
00055359  837dc700                 cmp dword ptr [rbp - 0x39], 0
0005535d  7569                     jne 0x553c8
0005535f  448955ab                 mov dword ptr [rbp - 0x55], r10d
00055363  eb54                     jmp 0x553b9
00055365  837dc700                 cmp dword ptr [rbp - 0x39], 0
00055369  7409                     je 0x55374
0005536b  c745ab03000000           mov dword ptr [rbp - 0x55], 3
00055372  eb45                     jmp 0x553b9
00055374  488bc3                   mov rax, rbx
00055377  488bcf                   mov rcx, rdi
0005537a  48c1e820                 shr rax, 0x20
0005537e  48c1e920                 shr rcx, 0x20
00055382  3ac1                     cmp al, cl
00055384  7527                     jne 0x553ad
00055386  488bc3                   mov rax, rbx
00055389  488bcf                   mov rcx, rdi
0005538c  48c1e808                 shr rax, 8
00055390  48c1e908                 shr rcx, 8
00055394  3ac1                     cmp al, cl
00055396  7306                     jae 0x5539e
00055398  448955ab                 mov dword ptr [rbp - 0x55], r10d
0005539c  eb1b                     jmp 0x553b9
0005539e  0f8602020000             jbe 0x555a6
000553a4  c745ab03000000           mov dword ptr [rbp - 0x55], 3
000553ab  eb0c                     jmp 0x553b9
000553ad  ba03000000               mov edx, 3
000553b2  410f42d2                 cmovb edx, r10d
000553b6  8955ab                   mov dword ptr [rbp - 0x55], edx
000553b9  448955c7                 mov dword ptr [rbp - 0x39], r10d
000553bd  448955cf                 mov dword ptr [rbp - 0x31], r10d
000553c1  c7459f06000000           mov dword ptr [rbp - 0x61], 6
000553c8  418b4f08                 mov ecx, dword ptr [r15 + 8]
000553cc  498d470e                 lea rax, [r15 + 0xe]
000553d0  498b17                   mov rdx, qword ptr [r15]
000553d3  ffc9                     dec ecx
000553d5  4533db                   xor r11d, r11d
000553d8  483bd0                   cmp rdx, rax
000553db  7406                     je 0x553e3
000553dd  488d4202                 lea rax, [rdx + 2]
000553e1  eb08                     jmp 0x553eb
000553e3  498b4710                 mov rax, qword ptr [r15 + 0x10]
000553e7  4d895f10                 mov qword ptr [r15 + 0x10], r11
000553eb  498907                   mov qword ptr [r15], rax
000553ee  41894f08                 mov dword ptr [r15 + 8], ecx
000553f2  85c9                     test ecx, ecx
000553f4  7425                     je 0x5541b
000553f6  0fb708                   movzx ecx, word ptr [rax]
000553f9  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
000553fd  498b4008                 mov rax, qword ptr [r8 + 8]
00055401  8b1488                   mov edx, dword ptr [rax + rcx*4]
00055404  0fb7da                   movzx ebx, dx
00055407  48c1e320                 shl rbx, 0x20
0005540b  48c1ea10                 shr rdx, 0x10
0005540f  480bda                   or rbx, rdx
00055412  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055416  eb07                     jmp 0x5541f
00055418  4533db                   xor r11d, r11d
0005541b  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005541f  418b4c2408               mov ecx, dword ptr [r12 + 8]
00055424  498d44240e               lea rax, [r12 + 0xe]
00055429  498b1424                 mov rdx, qword ptr [r12]
0005542d  ffc9                     dec ecx
0005542f  483bd0                   cmp rdx, rax
00055432  7406                     je 0x5543a
00055434  488d4202                 lea rax, [rdx + 2]
00055438  eb0a                     jmp 0x55444
0005543a  498b442410               mov rax, qword ptr [r12 + 0x10]
0005543f  4d895c2410               mov qword ptr [r12 + 0x10], r11
00055444  49890424                 mov qword ptr [r12], rax
00055448  41894c2408               mov dword ptr [r12 + 8], ecx
0005544d  85c9                     test ecx, ecx
0005544f  0f84a6feffff             je 0x552fb
00055455  0fb708                   movzx ecx, word ptr [rax]
00055458  498b4008                 mov rax, qword ptr [r8 + 8]
0005545c  e985feffff               jmp 0x552e6
00055461  4585c9                   test r9d, r9d
00055464  0f8541010000             jne 0x555ab
0005546a  33d2                     xor edx, edx
0005546c  8bf2                     mov esi, edx
0005546e  4180fb04                 cmp r11b, 4
00055472  0f845c030000             je 0x557d4
00055478  89542450                 mov dword ptr [rsp + 0x50], edx
0005547c  488bc7                   mov rax, rdi
0005547f  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00055483  488bcb                   mov rcx, rbx
00055486  48c1e820                 shr rax, 0x20
0005548a  4d8bcc                   mov r9, r12
0005548d  668945a3                 mov word ptr [rbp - 0x5d], ax
00055491  4d8bc7                   mov r8, r15
00055494  48c1e920                 shr rcx, 0x20
00055498  66894daf                 mov word ptr [rbp - 0x51], cx
0005549c  48c1e710                 shl rdi, 0x10
000554a0  0bf8                     or edi, eax
000554a2  48c1e310                 shl rbx, 0x10
000554a6  0bd9                     or ebx, ecx
000554a8  897dd7                   mov dword ptr [rbp - 0x29], edi
000554ab  488b4d5f                 mov rcx, qword ptr [rbp + 0x5f]
000554af  488d4507                 lea rax, [rbp + 7]
000554b3  4889442448               mov qword ptr [rsp + 0x48], rax
000554b8  488d45f7                 lea rax, [rbp - 9]
000554bc  4889442440               mov qword ptr [rsp + 0x40], rax
000554c1  488d45a3                 lea rax, [rbp - 0x5d]
000554c5  4889442438               mov qword ptr [rsp + 0x38], rax
000554ca  488d45af                 lea rax, [rbp - 0x51]
000554ce  4889442430               mov qword ptr [rsp + 0x30], rax
000554d3  488d45d7                 lea rax, [rbp - 0x29]
000554d7  4889442428               mov qword ptr [rsp + 0x28], rax
000554dc  488d45b7                 lea rax, [rbp - 0x49]
000554e0  4889442420               mov qword ptr [rsp + 0x20], rax
000554e5  895db7                   mov dword ptr [rbp - 0x49], ebx
000554e8  e853beffff               call 0x51340
000554ed  448bc8                   mov r9d, eax
000554f0  8945af                   mov dword ptr [rbp - 0x51], eax
000554f3  8b4507                   mov eax, dword ptr [rbp + 7]
000554f6  83f802                   cmp eax, 2
000554f9  0f85a0080000             jne 0x55d9f
000554ff  8b45b7                   mov eax, dword ptr [rbp - 0x49]
00055502  0fb7d8                   movzx ebx, ax
00055505  48c1e810                 shr rax, 0x10
00055509  48c1e320                 shl rbx, 0x20
0005550d  480bd8                   or rbx, rax
00055510  8b45d7                   mov eax, dword ptr [rbp - 0x29]
00055513  0fb7f8                   movzx edi, ax
00055516  48c1e720                 shl rdi, 0x20
0005551a  48c1e810                 shr rax, 0x10
0005551e  480bf8                   or rdi, rax
00055521  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055525  48897db7                 mov qword ptr [rbp - 0x49], rdi
00055529  4585c9                   test r9d, r9d
0005552c  0f849d000000             je 0x555cf
00055532  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00055536  41397708                 cmp dword ptr [r15 + 8], esi
0005553a  7473                     je 0x555af
0005553c  4139742408               cmp dword ptr [r12 + 8], esi
00055541  746c                     je 0x555af
00055543  498b07                   mov rax, qword ptr [r15]
00055546  498b5308                 mov rdx, qword ptr [r11 + 8]
0005554a  0fb708                   movzx ecx, word ptr [rax]
0005554d  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00055550  0fb7d8                   movzx ebx, ax
00055553  48c1e810                 shr rax, 0x10
00055557  48c1e320                 shl rbx, 0x20
0005555b  480bd8                   or rbx, rax
0005555e  498b0424                 mov rax, qword ptr [r12]
00055562  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055566  0fb708                   movzx ecx, word ptr [rax]
00055569  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005556c  0fb7f8                   movzx edi, ax
0005556f  48c1e720                 shl rdi, 0x20
00055573  48c1e810                 shr rax, 0x10
00055577  480bf8                   or rdi, rax
0005557a  48897db7                 mov qword ptr [rbp - 0x49], rdi
0005557e  eb2f                     jmp 0x555af
00055580  488bc7                   mov rax, rdi
00055583  48c1e820                 shr rax, 0x20
00055587  0fb6c8                   movzx ecx, al
0005558a  400fb6c7                 movzx eax, dil
0005558e  48c1e108                 shl rcx, 8
00055592  488bf9                   mov rdi, rcx
00055595  480bf8                   or rdi, rax
00055598  48c1e710                 shl rdi, 0x10
0005559c  480bfa                   or rdi, rdx
0005559f  48897db7                 mov qword ptr [rbp - 0x49], rdi
000555a3  488bf7                   mov rsi, rdi
000555a6  4585c9                   test r9d, r9d
000555a9  7428                     je 0x555d3
000555ab  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
000555af  418b4708                 mov eax, dword ptr [r15 + 8]
000555b3  85c0                     test eax, eax
000555b5  0f84b7060000             je 0x55c72
000555bb  41837c240800             cmp dword ptr [r12 + 8], 0
000555c1  0f84ab060000             je 0x55c72
000555c7  4533ed                   xor r13d, r13d
000555ca  e9f1f3ffff               jmp 0x549c0
000555cf  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
000555d3  4180fb03                 cmp r11b, 3
000555d7  0f85f7010000             jne 0x557d4
000555dd  33c0                     xor eax, eax
000555df  4c8bc3                   mov r8, rbx
000555e2  49c1e820                 shr r8, 0x20
000555e6  8945a3                   mov dword ptr [rbp - 0x5d], eax
000555e9  4180f801                 cmp r8b, 1
000555ed  0f87ce000000             ja 0x556c1
000555f3  498bd6                   mov rdx, r14
000555f6  48c1ea28                 shr rdx, 0x28
000555fa  413ad3                   cmp dl, r11b
000555fd  7730                     ja 0x5562f
000555ff  440fb64da5               movzx r9d, byte ptr [rbp - 0x5b]
00055604  48b800000000ffff0000     movabs rax, 0xffff00000000
0005560e  440fb655a3               movzx r10d, byte ptr [rbp - 0x5d]
00055613  488bd8                   mov rbx, rax
00055616  0fb655a6                 movzx edx, byte ptr [rbp - 0x5a]
0005561a  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
0005561e  488945bf                 mov qword ptr [rbp - 0x41], rax
00055622  44884da8                 mov byte ptr [rbp - 0x58], r9b
00055626  448855a7                 mov byte ptr [rbp - 0x59], r10b
0005562a  e9e5000000               jmp 0x55714
0005562f  498bce                   mov rcx, r14
00055632  48c1e910                 shr rcx, 0x10
00055636  8bc9                     mov ecx, ecx
00055638  80fa22                   cmp dl, 0x22
0005563b  755e                     jne 0x5569b
0005563d  498bd6                   mov rdx, r14
00055640  48c1ea08                 shr rdx, 8
00055644  440fb6d2                 movzx r10d, dl
00055648  440fb6ca                 movzx r9d, dl
0005564c  4180e2c6                 and r10b, 0xc6
00055650  4180e1e4                 and r9b, 0xe4
00055654  448855a7                 mov byte ptr [rbp - 0x59], r10b
00055658  44884da8                 mov byte ptr [rbp - 0x58], r9b
0005565c  4584c0                   test r8b, r8b
0005565f  7517                     jne 0x55678
00055661  48c1e110                 shl rcx, 0x10
00055665  0fb7c3                   movzx eax, bx
00055668  488bd9                   mov rbx, rcx
0005566b  480bd8                   or rbx, rax
0005566e  b104                     mov cl, 4
00055670  80e2c5                   and dl, 0xc5
00055673  e98c000000               jmp 0x55704
00055678  b8000087ff               mov eax, 0xff870000
0005567d  4823c8                   and rcx, rax
00055680  0fb7c3                   movzx eax, bx
00055683  48c1e110                 shl rcx, 0x10
00055687  488bd9                   mov rbx, rcx
0005568a  b105                     mov cl, 5
0005568c  480bd8                   or rbx, rax
0005568f  488bd3                   mov rdx, rbx
00055692  48c1ea08                 shr rdx, 8
00055696  80e2c5                   and dl, 0xc5
00055699  eb69                     jmp 0x55704
0005569b  0fb655a6                 movzx edx, byte ptr [rbp - 0x5a]
0005569f  440fb64da5               movzx r9d, byte ptr [rbp - 0x5b]
000556a4  440fb655a3               movzx r10d, byte ptr [rbp - 0x5d]
000556a9  48c1e110                 shl rcx, 0x10
000556ad  0fb6c3                   movzx eax, bl
000556b0  488bd9                   mov rbx, rcx
000556b3  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
000556b7  480bd8                   or rbx, rax
000556ba  480fbaeb09               bts rbx, 9
000556bf  eb3b                     jmp 0x556fc
000556c1  48b8ffffffffff22ffff     movabs rax, 0xffff22ffffffffff
000556cb  b103                     mov cl, 3
000556cd  4823d8                   and rbx, rax
000556d0  48b80000000000220000     movabs rax, 0x220000000000
000556da  480bd8                   or rbx, rax
000556dd  488bc3                   mov rax, rbx
000556e0  4c8bf3                   mov r14, rbx
000556e3  48c1e808                 shr rax, 8
000556e7  440fb6d0                 movzx r10d, al
000556eb  440fb6c8                 movzx r9d, al
000556ef  4180e2c6                 and r10b, 0xc6
000556f3  4180e1e4                 and r9b, 0xe4
000556f7  24c5                     and al, 0xc5
000556f9  0fb6d0                   movzx edx, al
000556fc  44884da8                 mov byte ptr [rbp - 0x58], r9b
00055700  448855a7                 mov byte ptr [rbp - 0x59], r10b
00055704  4881e3ff02ffff           and rbx, 0xffffffffffff02ff
0005570b  480fbaeb09               bts rbx, 9
00055710  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055714  8b459f                   mov eax, dword ptr [rbp - 0x61]
00055717  884d77                   mov byte ptr [rbp + 0x77], cl
0005571a  488955e7                 mov qword ptr [rbp - 0x19], rdx
0005571e  83f802                   cmp eax, 2
00055721  0f8ead000000             jle 0x557d4
00055727  4180fd03                 cmp r13b, 3
0005572b  0f84ad000000             je 0x557de
00055731  4584d2                   test r10b, r10b
00055734  7417                     je 0x5574d
00055736  b803000000               mov eax, 3
0005573b  41ba02000000             mov r10d, 2
00055741  8945ab                   mov dword ptr [rbp - 0x55], eax
00055744  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055748  e96af3ffff               jmp 0x54ab7
0005574d  83f803                   cmp eax, 3
00055750  0f8e56030000             jle 0x55aac
00055756  84c9                     test cl, cl
00055758  7413                     je 0x5576d
0005575a  b803000000               mov eax, 3
0005575f  8945ab                   mov dword ptr [rbp - 0x55], eax
00055762  448bd0                   mov r10d, eax
00055765  89459f                   mov dword ptr [rbp - 0x61], eax
00055768  e94af3ffff               jmp 0x54ab7
0005576d  83f804                   cmp eax, 4
00055770  0f8e36030000             jle 0x55aac
00055776  837ddf00                 cmp dword ptr [rbp - 0x21], 0
0005577a  0f852c030000             jne 0x55aac
00055780  4584c9                   test r9b, r9b
00055783  7417                     je 0x5579c
00055785  b803000000               mov eax, 3
0005578a  41ba04000000             mov r10d, 4
00055790  8945ab                   mov dword ptr [rbp - 0x55], eax
00055793  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055797  e91bf3ffff               jmp 0x54ab7
0005579c  83f805                   cmp eax, 5
0005579f  0f8e07030000             jle 0x55aac
000557a5  837dd300                 cmp dword ptr [rbp - 0x2d], 0
000557a9  0f85fd020000             jne 0x55aac
000557af  41b901000000             mov r9d, 1
000557b5  84d2                     test dl, dl
000557b7  0f84f7020000             je 0x55ab4
000557bd  b803000000               mov eax, 3
000557c2  41ba05000000             mov r10d, 5
000557c8  8945ab                   mov dword ptr [rbp - 0x55], eax
000557cb  4489559f                 mov dword ptr [rbp - 0x61], r10d
000557cf  e9e9f2ffff               jmp 0x54abd
000557d4  4180fd03                 cmp r13b, 3
000557d8  0f85d0f2ffff             jne 0x54aae
000557de  33c0                     xor eax, eax
000557e0  4c8bd7                   mov r10, rdi
000557e3  49c1ea20                 shr r10, 0x20
000557e7  8945a3                   mov dword ptr [rbp - 0x5d], eax
000557ea  4180fa01                 cmp r10b, 1
000557ee  0f87c0000000             ja 0x558b4
000557f4  488bd6                   mov rdx, rsi
000557f7  48c1ea28                 shr rdx, 0x28
000557fb  80fa03                   cmp dl, 3
000557fe  7728                     ja 0x55828
00055800  440fb645a6               movzx r8d, byte ptr [rbp - 0x5a]
00055805  48b800000000ffff0000     movabs rax, 0xffff00000000
0005580f  440fb64da5               movzx r9d, byte ptr [rbp - 0x5b]
00055814  488bf8                   mov rdi, rax
00055817  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
0005581b  0fb655a3                 movzx edx, byte ptr [rbp - 0x5d]
0005581f  488945b7                 mov qword ptr [rbp - 0x49], rax
00055823  e9d6000000               jmp 0x558fe
00055828  488bce                   mov rcx, rsi
0005582b  48c1e910                 shr rcx, 0x10
0005582f  8bc9                     mov ecx, ecx
00055831  80fa22                   cmp dl, 0x22
00055834  7557                     jne 0x5588d
00055836  4c8bc6                   mov r8, rsi
00055839  49c1e808                 shr r8, 8
0005583d  410fb6d0                 movzx edx, r8b
00055841  450fb6c8                 movzx r9d, r8b
00055845  80e2c6                   and dl, 0xc6
00055848  4180e1e4                 and r9b, 0xe4
0005584c  4584d2                   test r10b, r10b
0005584f  7518                     jne 0x55869
00055851  48c1e110                 shl rcx, 0x10
00055855  0fb7c7                   movzx eax, di
00055858  488bf9                   mov rdi, rcx
0005585b  480bf8                   or rdi, rax
0005585e  b104                     mov cl, 4
00055860  4180e0c5                 and r8b, 0xc5
00055864  e985000000               jmp 0x558ee
00055869  b8000087ff               mov eax, 0xff870000
0005586e  4823c8                   and rcx, rax
00055871  0fb7c7                   movzx eax, di
00055874  48c1e110                 shl rcx, 0x10
00055878  488bf9                   mov rdi, rcx
0005587b  b105                     mov cl, 5
0005587d  480bf8                   or rdi, rax
00055880  4c8bc7                   mov r8, rdi
00055883  49c1e808                 shr r8, 8
00055887  4180e0c5                 and r8b, 0xc5
0005588b  eb61                     jmp 0x558ee
0005588d  440fb645a6               movzx r8d, byte ptr [rbp - 0x5a]
00055892  440fb64da5               movzx r9d, byte ptr [rbp - 0x5b]
00055897  0fb655a3                 movzx edx, byte ptr [rbp - 0x5d]
0005589b  48c1e110                 shl rcx, 0x10
0005589f  400fb6c7                 movzx eax, dil
000558a3  488bf9                   mov rdi, rcx
000558a6  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
000558aa  480bf8                   or rdi, rax
000558ad  480fbaef09               bts rdi, 9
000558b2  eb3a                     jmp 0x558ee
000558b4  48b8ffffffffff22ffff     movabs rax, 0xffff22ffffffffff
000558be  b103                     mov cl, 3
000558c0  4823f8                   and rdi, rax
000558c3  48b80000000000220000     movabs rax, 0x220000000000
000558cd  480bf8                   or rdi, rax
000558d0  488bc7                   mov rax, rdi
000558d3  488bf7                   mov rsi, rdi
000558d6  48c1e808                 shr rax, 8
000558da  0fb6d0                   movzx edx, al
000558dd  440fb6c8                 movzx r9d, al
000558e1  80e2c6                   and dl, 0xc6
000558e4  4180e1e4                 and r9b, 0xe4
000558e8  24c5                     and al, 0xc5
000558ea  440fb6c0                 movzx r8d, al
000558ee  4881e7ff02ffff           and rdi, 0xffffffffffff02ff
000558f5  480fbaef09               bts rdi, 9
000558fa  48897db7                 mov qword ptr [rbp - 0x49], rdi
000558fe  448b559f                 mov r10d, dword ptr [rbp - 0x61]
00055902  4183fa02                 cmp r10d, 2
00055906  0f8ea6f1ffff             jle 0x54ab2
0005590c  4180fb03                 cmp r11b, 3
00055910  0f84b5000000             je 0x559cb
00055916  84d2                     test dl, dl
00055918  741d                     je 0x55937
0005591a  41b901000000             mov r9d, 1
00055920  41ba02000000             mov r10d, 2
00055926  44894dab                 mov dword ptr [rbp - 0x55], r9d
0005592a  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005592e  418d4102                 lea eax, [r9 + 2]
00055932  e986f1ffff               jmp 0x54abd
00055937  4183fa03                 cmp r10d, 3
0005593b  0f8e71f1ffff             jle 0x54ab2
00055941  84c9                     test cl, cl
00055943  741a                     je 0x5595f
00055945  b803000000               mov eax, 3
0005594a  41b901000000             mov r9d, 1
00055950  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055954  448bd0                   mov r10d, eax
00055957  89459f                   mov dword ptr [rbp - 0x61], eax
0005595a  e95ef1ffff               jmp 0x54abd
0005595f  4183fa04                 cmp r10d, 4
00055963  0f8e49f1ffff             jle 0x54ab2
00055969  4584c9                   test r9b, r9b
0005596c  7423                     je 0x55991
0005596e  837ddf00                 cmp dword ptr [rbp - 0x21], 0
00055972  751d                     jne 0x55991
00055974  41b901000000             mov r9d, 1
0005597a  41ba04000000             mov r10d, 4
00055980  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055984  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055988  418d4102                 lea eax, [r9 + 2]
0005598c  e92cf1ffff               jmp 0x54abd
00055991  41b901000000             mov r9d, 1
00055997  418d4102                 lea eax, [r9 + 2]
0005599b  4183fa05                 cmp r10d, 5
0005599f  0f8e18f1ffff             jle 0x54abd
000559a5  4584c0                   test r8b, r8b
000559a8  0f840ff1ffff             je 0x54abd
000559ae  837dd300                 cmp dword ptr [rbp - 0x2d], 0
000559b2  0f8505f1ffff             jne 0x54abd
000559b8  41ba05000000             mov r10d, 5
000559be  44894dab                 mov dword ptr [rbp - 0x55], r9d
000559c2  4489559f                 mov dword ptr [rbp - 0x61], r10d
000559c6  e9f2f0ffff               jmp 0x54abd
000559cb  3855a7                   cmp byte ptr [rbp - 0x59], dl
000559ce  7425                     je 0x559f5
000559d0  b803000000               mov eax, 3
000559d5  41b901000000             mov r9d, 1
000559db  448bd8                   mov r11d, eax
000559de  41ba02000000             mov r10d, 2
000559e4  450f42d9                 cmovb r11d, r9d
000559e8  4489559f                 mov dword ptr [rbp - 0x61], r10d
000559ec  44895dab                 mov dword ptr [rbp - 0x55], r11d
000559f0  e9c8f0ffff               jmp 0x54abd
000559f5  4183fa03                 cmp r10d, 3
000559f9  0f8eb3f0ffff             jle 0x54ab2
000559ff  384d77                   cmp byte ptr [rbp + 0x77], cl
00055a02  7421                     je 0x55a25
00055a04  b803000000               mov eax, 3
00055a09  41b901000000             mov r9d, 1
00055a0f  448bd8                   mov r11d, eax
00055a12  89459f                   mov dword ptr [rbp - 0x61], eax
00055a15  450f42d9                 cmovb r11d, r9d
00055a19  448bd0                   mov r10d, eax
00055a1c  44895dab                 mov dword ptr [rbp - 0x55], r11d
00055a20  e998f0ffff               jmp 0x54abd
00055a25  4183fa04                 cmp r10d, 4
00055a29  0f8e83f0ffff             jle 0x54ab2
00055a2f  0fb64da8                 movzx ecx, byte ptr [rbp - 0x58]
00055a33  413ac9                   cmp cl, r9b
00055a36  742e                     je 0x55a66
00055a38  837ddf00                 cmp dword ptr [rbp - 0x21], 0
00055a3c  7528                     jne 0x55a66
00055a3e  413ac9                   cmp cl, r9b
00055a41  b803000000               mov eax, 3
00055a46  448bd8                   mov r11d, eax
00055a49  41b901000000             mov r9d, 1
00055a4f  450f42d9                 cmovb r11d, r9d
00055a53  41ba04000000             mov r10d, 4
00055a59  44895dab                 mov dword ptr [rbp - 0x55], r11d
00055a5d  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055a61  e957f0ffff               jmp 0x54abd
00055a66  4183fa05                 cmp r10d, 5
00055a6a  0f8e42f0ffff             jle 0x54ab2
00055a70  488b45e7                 mov rax, qword ptr [rbp - 0x19]
00055a74  413ac0                   cmp al, r8b
00055a77  0f8435f0ffff             je 0x54ab2
00055a7d  837dd300                 cmp dword ptr [rbp - 0x2d], 0
00055a81  0f852bf0ffff             jne 0x54ab2
00055a87  413ac0                   cmp al, r8b
00055a8a  41b903000000             mov r9d, 3
00055a90  b801000000               mov eax, 1
00055a95  41ba05000000             mov r10d, 5
00055a9b  440f42c8                 cmovb r9d, eax
00055a9f  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055aa3  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055aa7  e906f0ffff               jmp 0x54ab2
00055aac  448bd0                   mov r10d, eax
00055aaf  e9feefffff               jmp 0x54ab2
00055ab4  448bd0                   mov r10d, eax
00055ab7  b803000000               mov eax, 3
00055abc  e9fcefffff               jmp 0x54abd
00055ac1  837dff00                 cmp dword ptr [rbp - 1], 0
00055ac5  7406                     je 0x55acd
00055ac7  4180fd14                 cmp r13b, 0x14
00055acb  765e                     jbe 0x55b2b
00055acd  4585d2                   test r10d, r10d
00055ad0  7f07                     jg 0x55ad9
00055ad2  41837b1000               cmp dword ptr [r11 + 0x10], 0
00055ad7  7452                     je 0x55b2b
00055ad9  4d8bc7                   mov r8, r15
00055adc  498bd3                   mov rdx, r11
00055adf  e80c0a0000               call 0x564f0
00055ae4  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00055ae8  4d8bc4                   mov r8, r12
00055aeb  0fb6cb                   movzx ecx, bl
00055aee  6603c1                   add ax, cx
00055af1  668945a3                 mov word ptr [rbp - 0x5d], ax
00055af5  e8f6090000               call 0x564f0
00055afa  400fb6cf                 movzx ecx, dil
00055afe  41b801000000             mov r8d, 1
00055b04  6603c1                   add ax, cx
00055b07  663945a3                 cmp word ptr [rbp - 0x5d], ax
00055b0b  7418                     je 0x55b25
00055b0d  41b903000000             mov r9d, 3
00055b13  450f42c8                 cmovb r9d, r8d
00055b17  33c0                     xor eax, eax
00055b19  448bd0                   mov r10d, eax
00055b1c  89459f                   mov dword ptr [rbp - 0x61], eax
00055b1f  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055b23  eb0c                     jmp 0x55b31
00055b25  448b559f                 mov r10d, dword ptr [rbp - 0x61]
00055b29  eb06                     jmp 0x55b31
00055b2b  41b801000000             mov r8d, 1
00055b31  837dd300                 cmp dword ptr [rbp - 0x2d], 0
00055b35  740c                     je 0x55b43
00055b37  837d0b00                 cmp dword ptr [rbp + 0xb], 0
00055b3b  7406                     je 0x55b43
00055b3d  4180fd14                 cmp r13b, 0x14
00055b41  7646                     jbe 0x55b89
00055b43  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00055b47  4183fa01                 cmp r10d, 1
00055b4b  7e40                     jle 0x55b8d
00055b4d  0fb645cc                 movzx eax, byte ptr [rbp - 0x34]
00055b51  4180fd14                 cmp r13b, 0x14
00055b55  0fb64dcb                 movzx ecx, byte ptr [rbp - 0x35]
00055b59  488bd7                   mov rdx, rdi
00055b5c  0f46c8                   cmovbe ecx, eax
00055b5f  48c1ea08                 shr rdx, 8
00055b63  488bc3                   mov rax, rbx
00055b66  22d1                     and dl, cl
00055b68  48c1e808                 shr rax, 8
00055b6c  22c1                     and al, cl
00055b6e  3ac2                     cmp al, dl
00055b70  741b                     je 0x55b8d
00055b72  41b903000000             mov r9d, 3
00055b78  4489459f                 mov dword ptr [rbp - 0x61], r8d
00055b7c  450f42c8                 cmovb r9d, r8d
00055b80  458bd0                   mov r10d, r8d
00055b83  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055b87  eb04                     jmp 0x55b8d
00055b89  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00055b8d  4d8b4710                 mov r8, qword ptr [r15 + 0x10]
00055b91  418b4708                 mov eax, dword ptr [r15 + 8]
00055b95  4d85c0                   test r8, r8
00055b98  750f                     jne 0x55ba9
00055b9a  49830702                 add qword ptr [r15], 2
00055b9e  ffc8                     dec eax
00055ba0  41894708                 mov dword ptr [r15 + 8], eax
00055ba4  4533ed                   xor r13d, r13d
00055ba7  eb28                     jmp 0x55bd1
00055ba9  498b17                   mov rdx, qword ptr [r15]
00055bac  498d4f0e                 lea rcx, [r15 + 0xe]
00055bb0  4533ed                   xor r13d, r13d
00055bb3  ffc8                     dec eax
00055bb5  458bf5                   mov r14d, r13d
00055bb8  41894708                 mov dword ptr [r15 + 8], eax
00055bbc  483bd1                   cmp rdx, rcx
00055bbf  7409                     je 0x55bca
00055bc1  488d4202                 lea rax, [rdx + 2]
00055bc5  498907                   mov qword ptr [r15], rax
00055bc8  eb07                     jmp 0x55bd1
00055bca  4d8907                   mov qword ptr [r15], r8
00055bcd  4d896f10                 mov qword ptr [r15 + 0x10], r13
00055bd1  4d8b442410               mov r8, qword ptr [r12 + 0x10]
00055bd6  418b4c2408               mov ecx, dword ptr [r12 + 8]
00055bdb  4d85c0                   test r8, r8
00055bde  7512                     jne 0x55bf2
00055be0  4983042402               add qword ptr [r12], 2
00055be5  4d8b0424                 mov r8, qword ptr [r12]
00055be9  ffc9                     dec ecx
00055beb  41894c2408               mov dword ptr [r12 + 8], ecx
00055bf0  eb27                     jmp 0x55c19
00055bf2  498b1424                 mov rdx, qword ptr [r12]
00055bf6  498d44240e               lea rax, [r12 + 0xe]
00055bfb  ffc9                     dec ecx
00055bfd  498bf5                   mov rsi, r13
00055c00  41894c2408               mov dword ptr [r12 + 8], ecx
00055c05  483bd0                   cmp rdx, rax
00055c08  7406                     je 0x55c10
00055c0a  4c8d4202                 lea r8, [rdx + 2]
00055c0e  eb05                     jmp 0x55c15
00055c10  4d896c2410               mov qword ptr [r12 + 0x10], r13
00055c15  4d890424                 mov qword ptr [r12], r8
00055c19  418b4708                 mov eax, dword ptr [r15 + 8]
00055c1d  85c0                     test eax, eax
00055c1f  746b                     je 0x55c8c
00055c21  85c9                     test ecx, ecx
00055c23  7467                     je 0x55c8c
00055c25  498b07                   mov rax, qword ptr [r15]
00055c28  498b5308                 mov rdx, qword ptr [r11 + 8]
00055c2c  0fb708                   movzx ecx, word ptr [rax]
00055c2f  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00055c32  0fb7d8                   movzx ebx, ax
00055c35  48c1e810                 shr rax, 0x10
00055c39  48c1e320                 shl rbx, 0x20
00055c3d  480bd8                   or rbx, rax
00055c40  410fb700                 movzx eax, word ptr [r8]
00055c44  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055c48  8b0c82                   mov ecx, dword ptr [rdx + rax*4]
00055c4b  0fb7f9                   movzx edi, cx
00055c4e  48c1e720                 shl rdi, 0x20
00055c52  48c1e910                 shr rcx, 0x10
00055c56  480bf9                   or rdi, rcx
00055c59  e950edffff               jmp 0x549ae
00055c5e  448b559f                 mov r10d, dword ptr [rbp - 0x61]
00055c62  4c8d052b6f0400           lea r8, [rip + 0x46f2b]
00055c69  448b6d6f                 mov r13d, dword ptr [rbp + 0x6f]
00055c6d  e98decffff               jmp 0x548ff
00055c72  448b559f                 mov r10d, dword ptr [rbp - 0x61]
00055c76  448b6d6f                 mov r13d, dword ptr [rbp + 0x6f]
00055c7a  4c8d05136f0400           lea r8, [rip + 0x46f13]
00055c81  41bb01000000             mov r11d, 1
00055c87  e973ecffff               jmp 0x548ff
00055c8c  448b4daf                 mov r9d, dword ptr [rbp - 0x51]
00055c90  ebe4                     jmp 0x55c76
00055c92  48c1ef10                 shr rdi, 0x10
00055c96  48c1eb10                 shr rbx, 0x10
00055c9a  3bdf                     cmp ebx, edi
00055c9c  410f42c1                 cmovb eax, r9d
00055ca0  e9fa000000               jmp 0x55d9f
00055ca5  85c0                     test eax, eax
00055ca7  7538                     jne 0x55ce1
00055ca9  4139442408               cmp dword ptr [r12 + 8], eax
00055cae  0f84d7000000             je 0x55d8b
00055cb4  4585ed                   test r13d, r13d
00055cb7  791c                     jns 0x55cd5
00055cb9  49837c241000             cmp qword ptr [r12 + 0x10], 0
00055cbf  0f84c6000000             je 0x55d8b
00055cc5  8b45ab                   mov eax, dword ptr [rbp - 0x55]
00055cc8  4183fa07                 cmp r10d, 7
00055ccc  410f44c3                 cmove eax, r11d
00055cd0  e9ca000000               jmp 0x55d9f
00055cd5  4585c9                   test r9d, r9d
00055cd8  4d8bfc                   mov r15, r12
00055cdb  480f45df                 cmovne rbx, rdi
00055cdf  eb06                     jmp 0x55ce7
00055ce1  41bb03000000             mov r11d, 3
00055ce7  458b4708                 mov r8d, dword ptr [r15 + 8]
00055ceb  4585c0                   test r8d, r8d
00055cee  0f8497000000             je 0x55d8b
00055cf4  488d3d05a3faff           lea rdi, [rip - 0x55cfb]
00055cfb  0f1f440000               nop dword ptr [rax + rax]
00055d00  4585c9                   test r9d, r9d
00055d03  7407                     je 0x55d0c
00055d05  33d2                     xor edx, edx
00055d07  448bca                   mov r9d, edx
00055d0a  eb21                     jmp 0x55d2d
00055d0c  498b07                   mov rax, qword ptr [r15]
00055d0f  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00055d13  0fb708                   movzx ecx, word ptr [rax]
00055d16  488b4208                 mov rax, qword ptr [rdx + 8]
00055d1a  8b1488                   mov edx, dword ptr [rax + rcx*4]
00055d1d  0fb7da                   movzx ebx, dx
00055d20  48c1e320                 shl rbx, 0x20
00055d24  48c1ea10                 shr rdx, 0x10
00055d28  480bda                   or rbx, rdx
00055d2b  33d2                     xor edx, edx
00055d2d  488bc3                   mov rax, rbx
00055d30  48c1e828                 shr rax, 0x28
00055d34  0fb6c8                   movzx ecx, al
00055d37  83f90c                   cmp ecx, 0xc
00055d3a  7717                     ja 0x55d53
00055d3c  8b8c8fec5d0500           mov ecx, dword ptr [rdi + rcx*4 + 0x55dec]
00055d43  4803cf                   add rcx, rdi
00055d46  ffe1                     jmp rcx
00055d48  41f6c502                 test r13b, 2
00055d4c  7510                     jne 0x55d5e
00055d4e  4585d2                   test r10d, r10d
00055d51  7e0b                     jle 0x55d5e
00055d53  418bc3                   mov eax, r11d
00055d56  eb47                     jmp 0x55d9f
00055d58  41f6c504                 test r13b, 4
00055d5c  74f5                     je 0x55d53
00055d5e  498b0f                   mov rcx, qword ptr [r15]
00055d61  498d470e                 lea rax, [r15 + 0xe]
00055d65  41ffc8                   dec r8d
00055d68  483bc8                   cmp rcx, rax
00055d6b  7406                     je 0x55d73
00055d6d  4883c102                 add rcx, 2
00055d71  eb08                     jmp 0x55d7b
00055d73  498b4f10                 mov rcx, qword ptr [r15 + 0x10]
00055d77  49895710                 mov qword ptr [r15 + 0x10], rdx
00055d7b  49890f                   mov qword ptr [r15], rcx
00055d7e  45894708                 mov dword ptr [r15 + 8], r8d
00055d82  4585c0                   test r8d, r8d
00055d85  0f8575ffffff             jne 0x55d00
00055d8b  448b4dab                 mov r9d, dword ptr [rbp - 0x55]
00055d8f  b802000000               mov eax, 2
00055d94  4183fa07                 cmp r10d, 7
00055d98  440f44c8                 cmove r9d, eax
00055d9c  418bc1                   mov eax, r9d
00055d9f  4881c4d8000000           add rsp, 0xd8
00055da6  415f                     pop r15
00055da8  415e                     pop r14
00055daa  415d                     pop r13
00055dac  415c                     pop r12
00055dae  5f                       pop rdi
00055daf  5e                       pop rsi
00055db0  5b                       pop rbx
00055db1  5d                       pop rbp
00055db2  c3                       ret
00055db3  90                       nop
00055db4  2a5205                   sub dl, byte ptr [rdx + 5]
00055db7  00f6                     add dh, dh
00055db9  4e05002a5205             add rax, 0x5522a00
00055dbf  002d520500c0             add byte ptr [rip - 0x3ffffaae], ch
00055dc5  50                       push rax
00055dc6  0500f55105               add eax, 0x551f500
00055dcb  002d500500a3             add byte ptr [rip - 0x5cfffab0], ch
00055dd1  55                       push rbp
00055dd2  05005c5205               add eax, 0x5525c00
00055dd7  00a3550500a6             add byte ptr [rbx - 0x59fffaab], ah
00055ddd  55                       push rbp
00055dde  0500615405               add eax, 0x5546100
00055de3  008055050003             add byte ptr [rax + 0x3000555], al
00055de9  53                       push rbx
00055dea  05005e5d05               add eax, 0x55d5e00
00055def  00485d                   add byte ptr [rax + 0x5d], cl
00055df2  0500535d05               add eax, 0x55d5300
00055df7  00535d                   add byte ptr [rbx + 0x5d], dl
00055dfa  0500535d05               add eax, 0x55d5300
00055dff  00535d                   add byte ptr [rbx + 0x5d], dl
00055e02  0500585d05               add eax, 0x55d5800
00055e07  00585d                   add byte ptr [rax + 0x5d], bl
00055e0a  0500585d05               add eax, 0x55d5800
00055e0f  00585d                   add byte ptr [rax + 0x5d], bl
00055e12  0500585d05               add eax, 0x55d5800
00055e17  00585d                   add byte ptr [rax + 0x5d], bl
00055e1a  0500585d05               add eax, 0x55d5800
