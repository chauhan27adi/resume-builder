; CSqlSortManager_90::SpecialCaseHandler
; aetm_enclave.dll, primary RVA 0x4eb80, 4072 bytes in 1 chunk(s)

; chunk at RVA 0x4eb80 (4072 bytes)
0004eb80  48895c2418               mov qword ptr [rsp + 0x18], rbx
0004eb85  55                       push rbp
0004eb86  56                       push rsi
0004eb87  57                       push rdi
0004eb88  4154                     push r12
0004eb8a  4155                     push r13
0004eb8c  4156                     push r14
0004eb8e  4157                     push r15
0004eb90  4881ec90000000           sub rsp, 0x90
0004eb97  488b842440010000         mov rax, qword ptr [rsp + 0x140]
0004eb9f  4d8be9                   mov r13, r9
0004eba2  4c8b9c2490010000         mov r11, qword ptr [rsp + 0x190]
0004ebaa  4c8bca                   mov r9, rdx
0004ebad  488b9c2418010000         mov rbx, qword ptr [rsp + 0x118]
0004ebb5  488bac24f0000000         mov rbp, qword ptr [rsp + 0xf0]
0004ebbd  4c8bbc2408010000         mov r15, qword ptr [rsp + 0x108]
0004ebc5  488bbc2410010000         mov rdi, qword ptr [rsp + 0x110]
0004ebcd  488bb42420010000         mov rsi, qword ptr [rsp + 0x120]
0004ebd5  4c8bb42480010000         mov r14, qword ptr [rsp + 0x180]
0004ebdd  4c8ba42488010000         mov r12, qword ptr [rsp + 0x188]
0004ebe5  4c8b942498010000         mov r10, qword ptr [rsp + 0x198]
0004ebed  4889442468               mov qword ptr [rsp + 0x68], rax
0004ebf2  8b842470010000           mov eax, dword ptr [rsp + 0x170]
0004ebf9  89842488000000           mov dword ptr [rsp + 0x88], eax
0004ec00  498b4108                 mov rax, qword ptr [r9 + 8]
0004ec04  4889442458               mov qword ptr [rsp + 0x58], rax
0004ec09  410fb6c0                 movzx eax, r8b
0004ec0d  ffc8                     dec eax
0004ec0f  48894c2478               mov qword ptr [rsp + 0x78], rcx
0004ec14  488b8c2438010000         mov rcx, qword ptr [rsp + 0x138]
0004ec1c  4889542460               mov qword ptr [rsp + 0x60], rdx
0004ec21  488b9424a0010000         mov rdx, qword ptr [rsp + 0x1a0]
0004ec29  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
0004ec31  4c895c2470               mov qword ptr [rsp + 0x70], r11
0004ec36  83f80a                   cmp eax, 0xa
0004ec39  0f87e10e0000             ja 0x4fb20
0004ec3f  4898                     cdqe
0004ec41  4c8d05b813fbff           lea r8, [rip - 0x4ec48]
0004ec48  418b84803cfb0400         mov eax, dword ptr [r8 + rax*4 + 0x4fb3c]
0004ec50  4903c0                   add rax, r8
0004ec53  ffe0                     jmp rax
0004ec55  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004ec5d  0f85bd0e0000             jne 0x4fb20
0004ec63  498b0c24                 mov rcx, qword ptr [r12]
0004ec67  410fb64502               movzx eax, byte ptr [r13 + 2]
0004ec6c  483b8c2478010000         cmp rcx, qword ptr [rsp + 0x178]
0004ec74  7608                     jbe 0x4ec7e
0004ec76  0041ff                   add byte ptr [rcx - 1], al
0004ec79  e9a20e0000               jmp 0x4fb20
0004ec7e  8801                     mov byte ptr [rcx], al
0004ec80  49ff0424                 inc qword ptr [r12]
0004ec84  e9970e0000               jmp 0x4fb20
0004ec89  410fb64500               movzx eax, byte ptr [r13]
0004ec8e  4533d2                   xor r10d, r10d
0004ec91  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0004ec96  410fb78480c0992d00       movzx eax, word ptr [r8 + rax*4 + 0x2d99c0]
0004ec9f  41b807020000             mov r8d, 0x207
0004eca5  4c8d0c81                 lea r9, [rcx + rax*4]
0004eca9  410fb711                 movzx edx, word ptr [r9]
0004ecad  44399424f8000000         cmp dword ptr [rsp + 0xf8], r10d
0004ecb5  0f84ce000000             je 0x4ed89
0004ecbb  486306                   movsxd rax, dword ptr [rsi]
0004ecbe  0fb7ca                   movzx ecx, dx
0004ecc1  66c1e908                 shr cx, 8
0004ecc5  880c18                   mov byte ptr [rax + rbx], cl
0004ecc8  48630e                   movsxd rcx, dword ptr [rsi]
0004eccb  8d4101                   lea eax, [rcx + 1]
0004ecce  8906                     mov dword ptr [rsi], eax
0004ecd0  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004ecd4  ff06                     inc dword ptr [rsi]
0004ecd6  833e04                   cmp dword ptr [rsi], 4
0004ecd9  0f85a4000000             jne 0x4ed83
0004ecdf  448916                   mov dword ptr [rsi], r10d
0004ece2  458b0f                   mov r9d, dword ptr [r15]
0004ece5  8b13                     mov edx, dword ptr [rbx]
0004ece7  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004ecef  7541                     jne 0x4ed32
0004ecf1  41c1c103                 rol r9d, 3
0004ecf5  4133d1                   xor edx, r9d
0004ecf8  418917                   mov dword ptr [r15], edx
0004ecfb  6644394302               cmp word ptr [rbx + 2], r8w
0004ed00  740b                     je 0x4ed0d
0004ed02  8917                     mov dword ptr [rdi], edx
0004ed04  66ff4500                 inc word ptr [rbp]
0004ed08  e9ba000000               jmp 0x4edc7
0004ed0d  0fb703                   movzx eax, word ptr [rbx]
0004ed10  66413bc0                 cmp ax, r8w
0004ed14  746d                     je 0x4ed83
0004ed16  0fb6c8                   movzx ecx, al
0004ed19  4133c9                   xor ecx, r9d
0004ed1c  890f                     mov dword ptr [rdi], ecx
0004ed1e  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004ed22  c1c103                   rol ecx, 3
0004ed25  33c8                     xor ecx, eax
0004ed27  890f                     mov dword ptr [rdi], ecx
0004ed29  66ff4500                 inc word ptr [rbp]
0004ed2d  e995000000               jmp 0x4edc7
0004ed32  4169c920080000           imul ecx, r9d, 0x820
0004ed39  418bc1                   mov eax, r9d
0004ed3c  c1e802                   shr eax, 2
0004ed3f  03c8                     add ecx, eax
0004ed41  8d040a                   lea eax, [rdx + rcx]
0004ed44  4133c1                   xor eax, r9d
0004ed47  418907                   mov dword ptr [r15], eax
0004ed4a  6644394302               cmp word ptr [rbx + 2], r8w
0004ed4f  7408                     je 0x4ed59
0004ed51  8907                     mov dword ptr [rdi], eax
0004ed53  66ff4500                 inc word ptr [rbp]
0004ed57  eb6e                     jmp 0x4edc7
0004ed59  0fb703                   movzx eax, word ptr [rbx]
0004ed5c  66413bc0                 cmp ax, r8w
0004ed60  7421                     je 0x4ed83
0004ed62  0fb6d0                   movzx edx, al
0004ed65  03d1                     add edx, ecx
0004ed67  4133d1                   xor edx, r9d
0004ed6a  69c220080000             imul eax, edx, 0x820
0004ed70  8917                     mov dword ptr [rdi], edx
0004ed72  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004ed76  03c8                     add ecx, eax
0004ed78  8bc2                     mov eax, edx
0004ed7a  c1e802                   shr eax, 2
0004ed7d  03c8                     add ecx, eax
0004ed7f  33ca                     xor ecx, edx
0004ed81  890f                     mov dword ptr [rdi], ecx
0004ed83  66ff4500                 inc word ptr [rbp]
0004ed87  eb3e                     jmp 0x4edc7
0004ed89  498b06                   mov rax, qword ptr [r14]
0004ed8c  66c1ea08                 shr dx, 8
0004ed90  8810                     mov byte ptr [rax], dl
0004ed92  49ff06                   inc qword ptr [r14]
0004ed95  410fb601                 movzx eax, byte ptr [r9]
0004ed99  498b0e                   mov rcx, qword ptr [r14]
0004ed9c  8801                     mov byte ptr [rcx], al
0004ed9e  49ff06                   inc qword ptr [r14]
0004eda1  498b0c24                 mov rcx, qword ptr [r12]
0004eda5  410fb64102               movzx eax, byte ptr [r9 + 2]
0004edaa  8801                     mov byte ptr [rcx], al
0004edac  49ff0424                 inc qword ptr [r12]
0004edb0  410fb64903               movzx ecx, byte ptr [r9 + 3]
0004edb5  498b03                   mov rax, qword ptr [r11]
0004edb8  228c2460010000           and cl, byte ptr [rsp + 0x160]
0004edbf  80e13f                   and cl, 0x3f
0004edc2  8808                     mov byte ptr [rax], cl
0004edc4  49ff03                   inc qword ptr [r11]
0004edc7  410fb64500               movzx eax, byte ptr [r13]
0004edcc  488d0d2d12fbff           lea rcx, [rip - 0x4edd3]
0004edd3  0fb78481c2992d00         movzx eax, word ptr [rcx + rax*4 + 0x2d99c2]
0004eddb  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0004ede0  440fb70c81               movzx r9d, word ptr [rcx + rax*4]
0004ede5  488d1481                 lea rdx, [rcx + rax*4]
0004ede9  410fb7c1                 movzx eax, r9w
0004eded  66c1e808                 shr ax, 8
0004edf1  3c02                     cmp al, 2
0004edf3  0f8578010000             jne 0x4ef71
0004edf9  0f1f8000000000           nop dword ptr [rax]
0004ee00  8b02                     mov eax, dword ptr [rdx]
0004ee02  0fb6c8                   movzx ecx, al
0004ee05  41894500                 mov dword ptr [r13], eax
0004ee09  488d05f011fbff           lea rax, [rip - 0x4ee10]
0004ee10  0fb78488c0992d00         movzx eax, word ptr [rax + rcx*4 + 0x2d99c0]
0004ee18  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0004ee1d  4c8d0c81                 lea r9, [rcx + rax*4]
0004ee21  410fb711                 movzx edx, word ptr [r9]
0004ee25  44399424f8000000         cmp dword ptr [rsp + 0xf8], r10d
0004ee2d  0f84ce000000             je 0x4ef01
0004ee33  486306                   movsxd rax, dword ptr [rsi]
0004ee36  0fb7ca                   movzx ecx, dx
0004ee39  66c1e908                 shr cx, 8
0004ee3d  880c18                   mov byte ptr [rax + rbx], cl
0004ee40  48630e                   movsxd rcx, dword ptr [rsi]
0004ee43  8d4101                   lea eax, [rcx + 1]
0004ee46  8906                     mov dword ptr [rsi], eax
0004ee48  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004ee4c  ff06                     inc dword ptr [rsi]
0004ee4e  833e04                   cmp dword ptr [rsi], 4
0004ee51  0f85a4000000             jne 0x4eefb
0004ee57  448916                   mov dword ptr [rsi], r10d
0004ee5a  458b0f                   mov r9d, dword ptr [r15]
0004ee5d  8b13                     mov edx, dword ptr [rbx]
0004ee5f  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004ee67  7541                     jne 0x4eeaa
0004ee69  41c1c103                 rol r9d, 3
0004ee6d  4133d1                   xor edx, r9d
0004ee70  418917                   mov dword ptr [r15], edx
0004ee73  6644394302               cmp word ptr [rbx + 2], r8w
0004ee78  740b                     je 0x4ee85
0004ee7a  8917                     mov dword ptr [rdi], edx
0004ee7c  66ff4500                 inc word ptr [rbp]
0004ee80  e9ba000000               jmp 0x4ef3f
0004ee85  0fb703                   movzx eax, word ptr [rbx]
0004ee88  66413bc0                 cmp ax, r8w
0004ee8c  746d                     je 0x4eefb
0004ee8e  0fb6c8                   movzx ecx, al
0004ee91  4133c9                   xor ecx, r9d
0004ee94  890f                     mov dword ptr [rdi], ecx
0004ee96  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004ee9a  c1c103                   rol ecx, 3
0004ee9d  33c8                     xor ecx, eax
0004ee9f  890f                     mov dword ptr [rdi], ecx
0004eea1  66ff4500                 inc word ptr [rbp]
0004eea5  e995000000               jmp 0x4ef3f
0004eeaa  4169c920080000           imul ecx, r9d, 0x820
0004eeb1  418bc1                   mov eax, r9d
0004eeb4  c1e802                   shr eax, 2
0004eeb7  03c8                     add ecx, eax
0004eeb9  8d040a                   lea eax, [rdx + rcx]
0004eebc  4133c1                   xor eax, r9d
0004eebf  418907                   mov dword ptr [r15], eax
0004eec2  6644394302               cmp word ptr [rbx + 2], r8w
0004eec7  7408                     je 0x4eed1
0004eec9  8907                     mov dword ptr [rdi], eax
0004eecb  66ff4500                 inc word ptr [rbp]
0004eecf  eb6e                     jmp 0x4ef3f
0004eed1  0fb703                   movzx eax, word ptr [rbx]
0004eed4  66413bc0                 cmp ax, r8w
0004eed8  7421                     je 0x4eefb
0004eeda  0fb6d0                   movzx edx, al
0004eedd  03d1                     add edx, ecx
0004eedf  4133d1                   xor edx, r9d
0004eee2  69c220080000             imul eax, edx, 0x820
0004eee8  8917                     mov dword ptr [rdi], edx
0004eeea  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004eeee  03c8                     add ecx, eax
0004eef0  8bc2                     mov eax, edx
0004eef2  c1e802                   shr eax, 2
0004eef5  03c8                     add ecx, eax
0004eef7  33ca                     xor ecx, edx
0004eef9  890f                     mov dword ptr [rdi], ecx
0004eefb  66ff4500                 inc word ptr [rbp]
0004eeff  eb3e                     jmp 0x4ef3f
0004ef01  498b06                   mov rax, qword ptr [r14]
0004ef04  66c1ea08                 shr dx, 8
0004ef08  8810                     mov byte ptr [rax], dl
0004ef0a  49ff06                   inc qword ptr [r14]
0004ef0d  410fb601                 movzx eax, byte ptr [r9]
0004ef11  498b0e                   mov rcx, qword ptr [r14]
0004ef14  8801                     mov byte ptr [rcx], al
0004ef16  49ff06                   inc qword ptr [r14]
0004ef19  498b0c24                 mov rcx, qword ptr [r12]
0004ef1d  410fb64102               movzx eax, byte ptr [r9 + 2]
0004ef22  8801                     mov byte ptr [rcx], al
0004ef24  49ff0424                 inc qword ptr [r12]
0004ef28  410fb64903               movzx ecx, byte ptr [r9 + 3]
0004ef2d  498b03                   mov rax, qword ptr [r11]
0004ef30  228c2460010000           and cl, byte ptr [rsp + 0x160]
0004ef37  80e13f                   and cl, 0x3f
0004ef3a  8808                     mov byte ptr [rax], cl
0004ef3c  49ff03                   inc qword ptr [r11]
0004ef3f  410fb64500               movzx eax, byte ptr [r13]
0004ef44  488d0db510fbff           lea rcx, [rip - 0x4ef4b]
0004ef4b  0fb78481c2992d00         movzx eax, word ptr [rcx + rax*4 + 0x2d99c2]
0004ef53  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0004ef58  440fb70c81               movzx r9d, word ptr [rcx + rax*4]
0004ef5d  488d1481                 lea rdx, [rcx + rax*4]
0004ef61  410fb7c1                 movzx eax, r9w
0004ef65  66c1e808                 shr ax, 8
0004ef69  3c02                     cmp al, 2
0004ef6b  0f848ffeffff             je 0x4ee00
0004ef71  44399424f8000000         cmp dword ptr [rsp + 0xf8], r10d
0004ef79  7433                     je 0x4efae
0004ef7b  486306                   movsxd rax, dword ptr [rsi]
0004ef7e  410fb7c9                 movzx ecx, r9w
0004ef82  66c1e908                 shr cx, 8
0004ef86  880c18                   mov byte ptr [rax + rbx], cl
0004ef89  48630e                   movsxd rcx, dword ptr [rsi]
0004ef8c  8d4101                   lea eax, [rcx + 1]
0004ef8f  8906                     mov dword ptr [rsi], eax
0004ef91  44884c1901               mov byte ptr [rcx + rbx + 1], r9b
0004ef96  ff06                     inc dword ptr [rsi]
0004ef98  833e04                   cmp dword ptr [rsi], 4
0004ef9b  0f85f00a0000             jne 0x4fa91
0004efa1  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004efa9  e9410a0000               jmp 0x4f9ef
0004efae  498b06                   mov rax, qword ptr [r14]
0004efb1  6641c1e908               shr r9w, 8
0004efb6  448808                   mov byte ptr [rax], r9b
0004efb9  49ff06                   inc qword ptr [r14]
0004efbc  0fb602                   movzx eax, byte ptr [rdx]
0004efbf  498b0e                   mov rcx, qword ptr [r14]
0004efc2  8801                     mov byte ptr [rcx], al
0004efc4  49ff06                   inc qword ptr [r14]
0004efc7  498b0c24                 mov rcx, qword ptr [r12]
0004efcb  0fb64202                 movzx eax, byte ptr [rdx + 2]
0004efcf  8801                     mov byte ptr [rcx], al
0004efd1  49ff0424                 inc qword ptr [r12]
0004efd5  0fb64a03                 movzx ecx, byte ptr [rdx + 3]
0004efd9  498b03                   mov rax, qword ptr [r11]
0004efdc  228c2460010000           and cl, byte ptr [rsp + 0x160]
0004efe3  80e13f                   and cl, 0x3f
0004efe6  8808                     mov byte ptr [rax], cl
0004efe8  e9300b0000               jmp 0x4fb1d
0004efed  83bc242801000000         cmp dword ptr [rsp + 0x128], 0
0004eff5  7551                     jne 0x4f048
0004eff7  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004efff  0f851b0b0000             jne 0x4fb20
0004f005  0fb74d00                 movzx ecx, word ptr [rbp]
0004f009  488b02                   mov rax, qword ptr [rdx]
0004f00c  66c1e906                 shr cx, 6
0004f010  80c980                   or cl, 0x80
0004f013  8808                     mov byte ptr [rax], cl
0004f015  48ff02                   inc qword ptr [rdx]
0004f018  0fb64500                 movzx eax, byte ptr [rbp]
0004f01c  488b0a                   mov rcx, qword ptr [rdx]
0004f01f  c0e002                   shl al, 2
0004f022  0c03                     or al, 3
0004f024  8801                     mov byte ptr [rcx], al
0004f026  48ff02                   inc qword ptr [rdx]
0004f029  488b0a                   mov rcx, qword ptr [rdx]
0004f02c  410fb64501               movzx eax, byte ptr [r13 + 1]
0004f031  8801                     mov byte ptr [rcx], al
0004f033  48ff02                   inc qword ptr [rdx]
0004f036  488b0a                   mov rcx, qword ptr [rdx]
0004f039  410fb64500               movzx eax, byte ptr [r13]
0004f03e  8801                     mov byte ptr [rcx], al
0004f040  48ff02                   inc qword ptr [rdx]
0004f043  e9d80a0000               jmp 0x4fb20
0004f048  83bc243001000000         cmp dword ptr [rsp + 0x130], 0
0004f050  0f85ca0a0000             jne 0x4fb20
0004f056  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f05e  410fb75500               movzx edx, word ptr [r13]
0004f063  743a                     je 0x4f09f
0004f065  486306                   movsxd rax, dword ptr [rsi]
0004f068  0fb7ca                   movzx ecx, dx
0004f06b  66c1e908                 shr cx, 8
0004f06f  880c18                   mov byte ptr [rax + rbx], cl
0004f072  48630e                   movsxd rcx, dword ptr [rsi]
0004f075  8d4101                   lea eax, [rcx + 1]
0004f078  8906                     mov dword ptr [rsi], eax
0004f07a  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f07e  ff06                     inc dword ptr [rsi]
0004f080  833e04                   cmp dword ptr [rsi], 4
0004f083  0f85080a0000             jne 0x4fa91
0004f089  4533d2                   xor r10d, r10d
0004f08c  41b807020000             mov r8d, 0x207
0004f092  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004f09a  e950090000               jmp 0x4f9ef
0004f09f  498b06                   mov rax, qword ptr [r14]
0004f0a2  66c1ea08                 shr dx, 8
0004f0a6  8810                     mov byte ptr [rax], dl
0004f0a8  49ff06                   inc qword ptr [r14]
0004f0ab  410fb64500               movzx eax, byte ptr [r13]
0004f0b0  498b0e                   mov rcx, qword ptr [r14]
0004f0b3  8801                     mov byte ptr [rcx], al
0004f0b5  49ff06                   inc qword ptr [r14]
0004f0b8  498b0c24                 mov rcx, qword ptr [r12]
0004f0bc  410fb64502               movzx eax, byte ptr [r13 + 2]
0004f0c1  8801                     mov byte ptr [rcx], al
0004f0c3  49ff0424                 inc qword ptr [r12]
0004f0c7  410fb64d03               movzx ecx, byte ptr [r13 + 3]
0004f0cc  498b03                   mov rax, qword ptr [r11]
0004f0cf  228c2460010000           and cl, byte ptr [rsp + 0x160]
0004f0d6  80e13f                   and cl, 0x3f
0004f0d9  8808                     mov byte ptr [rax], cl
0004f0db  e93d0a0000               jmp 0x4fb1d
0004f0e0  450fb64500               movzx r8d, byte ptr [r13]
0004f0e5  410fb65503               movzx edx, byte ptr [r13 + 3]
0004f0ea  22942460010000           and dl, byte ptr [rsp + 0x160]
0004f0f1  80cac4                   or dl, 0xc4
0004f0f4  4488442450               mov byte ptr [rsp + 0x50], r8b
0004f0f9  88542454                 mov byte ptr [rsp + 0x54], dl
0004f0fd  4180f801                 cmp r8b, 1
0004f101  0f87e8010000             ja 0x4f2ef
0004f107  488b09                   mov rcx, qword ptr [rcx]
0004f10a  4883e902                 sub rcx, 2
0004f10e  483b8c2448010000         cmp rcx, qword ptr [rsp + 0x148]
0004f116  722b                     jb 0x4f143
0004f118  0f1f840000000000         nop dword ptr [rax + rax]
0004f120  0fb701                   movzx eax, word ptr [rcx]
0004f123  4c8b442458               mov r8, qword ptr [rsp + 0x58]
0004f128  458b0480                 mov r8d, dword ptr [r8 + rax*4]
0004f12c  458bc8                   mov r9d, r8d
0004f12f  410fb7c0                 movzx eax, r8w
0004f133  41c1e918                 shr r9d, 0x18
0004f137  66c1e808                 shr ax, 8
0004f13b  3c03                     cmp al, 3
0004f13d  7347                     jae 0x4f186
0004f13f  3c02                     cmp al, 2
0004f141  754f                     jne 0x4f192
0004f143  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f14b  0f8487010000             je 0x4f2d8
0004f151  486306                   movsxd rax, dword ptr [rsi]
0004f154  c60418ff                 mov byte ptr [rax + rbx], 0xff
0004f158  48630e                   movsxd rcx, dword ptr [rsi]
0004f15b  8d4101                   lea eax, [rcx + 1]
0004f15e  8906                     mov dword ptr [rsi], eax
0004f160  c6441901ff               mov byte ptr [rcx + rbx + 1], 0xff
0004f165  ff06                     inc dword ptr [rsi]
0004f167  833e04                   cmp dword ptr [rsi], 4
0004f16a  0f8521090000             jne 0x4fa91
0004f170  4533d2                   xor r10d, r10d
0004f173  41b807020000             mov r8d, 0x207
0004f179  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004f181  e969080000               jmp 0x4f9ef
0004f186  0f85f3000000             jne 0x4f27f
0004f18c  4180f801                 cmp r8b, 1
0004f190  7710                     ja 0x4f1a2
0004f192  4883c1fe                 add rcx, -2
0004f196  483b8c2448010000         cmp rcx, qword ptr [rsp + 0x148]
0004f19e  7380                     jae 0x4f120
0004f1a0  eba1                     jmp 0x4f143
0004f1a2  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004f1aa  0fb6842458010000         movzx eax, byte ptr [rsp + 0x158]
0004f1b2  450fb6c0                 movzx r8d, r8b
0004f1b6  740c                     je 0x4f1c4
0004f1b8  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
0004f1bd  0fb64c0848               movzx ecx, byte ptr [rax + rcx + 0x48]
0004f1c2  eb03                     jmp 0x4f1c7
0004f1c4  0fb7c8                   movzx ecx, ax
0004f1c7  44228c2460010000         and r9b, byte ptr [rsp + 0x160]
0004f1cf  8b8424f8000000           mov eax, dword ptr [rsp + 0xf8]
0004f1d6  4180c9c4                 or r9b, 0xc4
0004f1da  66c1e108                 shl cx, 8
0004f1de  66440bc1                 or r8w, cx
0004f1e2  85c0                     test eax, eax
0004f1e4  7531                     jne 0x4f217
0004f1e6  498b02                   mov rax, qword ptr [r10]
0004f1e9  410fb6c9                 movzx ecx, r9b
0004f1ed  80e1c6                   and cl, 0xc6
0004f1f0  410fb6d1                 movzx edx, r9b
0004f1f4  80e2e4                   and dl, 0xe4
0004f1f7  8808                     mov byte ptr [rax], cl
0004f1f9  8b842488000000           mov eax, dword ptr [rsp + 0x88]
0004f200  03c0                     add eax, eax
0004f202  4863c8                   movsxd rcx, eax
0004f205  498b02                   mov rax, qword ptr [r10]
0004f208  881401                   mov byte ptr [rcx + rax], dl
0004f20b  0fb6542454               movzx edx, byte ptr [rsp + 0x54]
0004f210  8b8424f8000000           mov eax, dword ptr [rsp + 0xf8]
0004f217  807c245000               cmp byte ptr [rsp + 0x50], 0
0004f21c  7531                     jne 0x4f24f
0004f21e  85c0                     test eax, eax
0004f220  755d                     jne 0x4f27f
0004f222  498b02                   mov rax, qword ptr [r10]
0004f225  4180e1c5                 and r9b, 0xc5
0004f229  4863942488000000         movsxd rdx, dword ptr [rsp + 0x88]
0004f231  c6040204                 mov byte ptr [rdx + rax], 4
0004f235  8d0452                   lea eax, [rdx + rdx*2]
0004f238  4863c8                   movsxd rcx, eax
0004f23b  498b02                   mov rax, qword ptr [r10]
0004f23e  44880c01                 mov byte ptr [rcx + rax], r9b
0004f242  8b8424f8000000           mov eax, dword ptr [rsp + 0xf8]
0004f249  85c0                     test eax, eax
0004f24b  7532                     jne 0x4f27f
0004f24d  eb2d                     jmp 0x4f27c
0004f24f  b987ff0000               mov ecx, 0xff87
0004f254  664423c1                 and r8w, cx
0004f258  85c0                     test eax, eax
0004f25a  7523                     jne 0x4f27f
0004f25c  498b02                   mov rax, qword ptr [r10]
0004f25f  80e2c5                   and dl, 0xc5
0004f262  4c638c2488000000         movsxd r9, dword ptr [rsp + 0x88]
0004f26a  41c6040105               mov byte ptr [r9 + rax], 5
0004f26f  438d0449                 lea eax, [r9 + r9*2]
0004f273  4863c8                   movsxd rcx, eax
0004f276  498b02                   mov rax, qword ptr [r10]
0004f279  881401                   mov byte ptr [rcx + rax], dl
0004f27c  49ff02                   inc qword ptr [r10]
0004f27f  b8ffff0000               mov eax, 0xffff
0004f284  66443bc0                 cmp r8w, ax
0004f288  0f84b5feffff             je 0x4f143
0004f28e  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f296  0f84d3000000             je 0x4f36f
0004f29c  486306                   movsxd rax, dword ptr [rsi]
0004f29f  410fb7c8                 movzx ecx, r8w
0004f2a3  66c1e908                 shr cx, 8
0004f2a7  880c18                   mov byte ptr [rax + rbx], cl
0004f2aa  48630e                   movsxd rcx, dword ptr [rsi]
0004f2ad  8d4101                   lea eax, [rcx + 1]
0004f2b0  8906                     mov dword ptr [rsi], eax
0004f2b2  4488441901               mov byte ptr [rcx + rbx + 1], r8b
0004f2b7  ff06                     inc dword ptr [rsi]
0004f2b9  833e04                   cmp dword ptr [rsi], 4
0004f2bc  0f85cf070000             jne 0x4fa91
0004f2c2  4533d2                   xor r10d, r10d
0004f2c5  41b807020000             mov r8d, 0x207
0004f2cb  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004f2d3  e917070000               jmp 0x4f9ef
0004f2d8  498b06                   mov rax, qword ptr [r14]
0004f2db  c600ff                   mov byte ptr [rax], 0xff
0004f2de  49ff06                   inc qword ptr [r14]
0004f2e1  498b06                   mov rax, qword ptr [r14]
0004f2e4  c600ff                   mov byte ptr [rax], 0xff
0004f2e7  49ff06                   inc qword ptr [r14]
0004f2ea  e931080000               jmp 0x4fb20
0004f2ef  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004f2f7  0fb6842458010000         movzx eax, byte ptr [rsp + 0x158]
0004f2ff  7408                     je 0x4f309
0004f301  460fb64c0848             movzx r9d, byte ptr [rax + r9 + 0x48]
0004f307  eb04                     jmp 0x4f30d
0004f309  440fb7c8                 movzx r9d, ax
0004f30d  6641c1e108               shl r9w, 8
0004f312  66450bc8                 or r9w, r8w
0004f316  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f31e  450fb7c1                 movzx r8d, r9w
0004f322  0f8574ffffff             jne 0x4f29c
0004f328  498b02                   mov rax, qword ptr [r10]
0004f32b  0fb6ca                   movzx ecx, dl
0004f32e  4c63842488000000         movsxd r8, dword ptr [rsp + 0x88]
0004f336  80e1c6                   and cl, 0xc6
0004f339  80e2e4                   and dl, 0xe4
0004f33c  8808                     mov byte ptr [rax], cl
0004f33e  498b02                   mov rax, qword ptr [r10]
0004f341  41c6040003               mov byte ptr [r8 + rax], 3
0004f346  438d0400                 lea eax, [r8 + r8]
0004f34a  4863c8                   movsxd rcx, eax
0004f34d  498b02                   mov rax, qword ptr [r10]
0004f350  881401                   mov byte ptr [rcx + rax], dl
0004f353  438d0440                 lea eax, [r8 + r8*2]
0004f357  0fb6542454               movzx edx, byte ptr [rsp + 0x54]
0004f35c  450fb7c1                 movzx r8d, r9w
0004f360  4863c8                   movsxd rcx, eax
0004f363  80e2c5                   and dl, 0xc5
0004f366  498b02                   mov rax, qword ptr [r10]
0004f369  881401                   mov byte ptr [rcx + rax], dl
0004f36c  49ff02                   inc qword ptr [r10]
0004f36f  498b06                   mov rax, qword ptr [r14]
0004f372  410fb7c8                 movzx ecx, r8w
0004f376  66c1e908                 shr cx, 8
0004f37a  8808                     mov byte ptr [rax], cl
0004f37c  49ff06                   inc qword ptr [r14]
0004f37f  498b06                   mov rax, qword ptr [r14]
0004f382  448800                   mov byte ptr [rax], r8b
0004f385  49ff06                   inc qword ptr [r14]
0004f388  410fb64502               movzx eax, byte ptr [r13 + 2]
0004f38d  498b0c24                 mov rcx, qword ptr [r12]
0004f391  8801                     mov byte ptr [rcx], al
0004f393  49ff0424                 inc qword ptr [r12]
0004f397  498b03                   mov rax, qword ptr [r11]
0004f39a  c60002                   mov byte ptr [rax], 2
0004f39d  e97b070000               jmp 0x4fb1d
0004f3a2  4c8b01                   mov r8, qword ptr [rcx]
0004f3a5  b860110000               mov eax, 0x1160
0004f3aa  66413900                 cmp word ptr [r8], ax
0004f3ae  0f8361040000             jae 0x4f815
0004f3b4  488b442468               mov rax, qword ptr [rsp + 0x68]
0004f3b9  448b8c2450010000         mov r9d, dword ptr [rsp + 0x150]
0004f3c1  488b542460               mov rdx, qword ptr [rsp + 0x60]
0004f3c6  488b4c2478               mov rcx, qword ptr [rsp + 0x78]
0004f3cb  442b08                   sub r9d, dword ptr [rax]
0004f3ce  488d442454               lea rax, [rsp + 0x54]
0004f3d3  4889442438               mov qword ptr [rsp + 0x38], rax
0004f3d8  41ffc1                   inc r9d
0004f3db  488d842488000000         lea rax, [rsp + 0x88]
0004f3e3  c744243003000000         mov dword ptr [rsp + 0x30], 3
0004f3eb  4889442428               mov qword ptr [rsp + 0x28], rax
0004f3f0  488d442450               lea rax, [rsp + 0x50]
0004f3f5  4889442420               mov qword ptr [rsp + 0x20], rax
0004f3fa  e891180000               call 0x50c90
0004f3ff  448bd8                   mov r11d, eax
0004f402  85c0                     test eax, eax
0004f404  0f8e01040000             jle 0x4f80b
0004f40a  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f412  0f842e030000             je 0x4f746
0004f418  48630e                   movsxd rcx, dword ptr [rsi]
0004f41b  4533d2                   xor r10d, r10d
0004f41e  440fb7442450             movzx r8d, word ptr [rsp + 0x50]
0004f424  448bb42400010000         mov r14d, dword ptr [rsp + 0x100]
0004f42c  410fb7d0                 movzx edx, r8w
0004f430  66c1ea08                 shr dx, 8
0004f434  881419                   mov byte ptr [rcx + rbx], dl
0004f437  48630e                   movsxd rcx, dword ptr [rsi]
0004f43a  8d4101                   lea eax, [rcx + 1]
0004f43d  8906                     mov dword ptr [rsi], eax
0004f43f  4488441901               mov byte ptr [rcx + rbx + 1], r8b
0004f444  41b807020000             mov r8d, 0x207
0004f44a  ff06                     inc dword ptr [rsi]
0004f44c  833e04                   cmp dword ptr [rsi], 4
0004f44f  0f858b000000             jne 0x4f4e0
0004f455  448916                   mov dword ptr [rsi], r10d
0004f458  458b0f                   mov r9d, dword ptr [r15]
0004f45b  8b13                     mov edx, dword ptr [rbx]
0004f45d  4585f6                   test r14d, r14d
0004f460  7531                     jne 0x4f493
0004f462  41c1c103                 rol r9d, 3
0004f466  4133d1                   xor edx, r9d
0004f469  418917                   mov dword ptr [r15], edx
0004f46c  6644394302               cmp word ptr [rbx + 2], r8w
0004f471  7404                     je 0x4f477
0004f473  8917                     mov dword ptr [rdi], edx
0004f475  eb69                     jmp 0x4f4e0
0004f477  0fb703                   movzx eax, word ptr [rbx]
0004f47a  66413bc0                 cmp ax, r8w
0004f47e  7460                     je 0x4f4e0
0004f480  0fb6c8                   movzx ecx, al
0004f483  4133c9                   xor ecx, r9d
0004f486  890f                     mov dword ptr [rdi], ecx
0004f488  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f48c  c1c103                   rol ecx, 3
0004f48f  33c8                     xor ecx, eax
0004f491  eb4b                     jmp 0x4f4de
0004f493  4169c920080000           imul ecx, r9d, 0x820
0004f49a  418bc1                   mov eax, r9d
0004f49d  c1e802                   shr eax, 2
0004f4a0  03c8                     add ecx, eax
0004f4a2  8d040a                   lea eax, [rdx + rcx]
0004f4a5  4133c1                   xor eax, r9d
0004f4a8  418907                   mov dword ptr [r15], eax
0004f4ab  6644394302               cmp word ptr [rbx + 2], r8w
0004f4b0  7404                     je 0x4f4b6
0004f4b2  8907                     mov dword ptr [rdi], eax
0004f4b4  eb2a                     jmp 0x4f4e0
0004f4b6  0fb703                   movzx eax, word ptr [rbx]
0004f4b9  66413bc0                 cmp ax, r8w
0004f4bd  7421                     je 0x4f4e0
0004f4bf  0fb6d0                   movzx edx, al
0004f4c2  03d1                     add edx, ecx
0004f4c4  4133d1                   xor edx, r9d
0004f4c7  69c220080000             imul eax, edx, 0x820
0004f4cd  8917                     mov dword ptr [rdi], edx
0004f4cf  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004f4d3  03c8                     add ecx, eax
0004f4d5  8bc2                     mov eax, edx
0004f4d7  c1e802                   shr eax, 2
0004f4da  03c8                     add ecx, eax
0004f4dc  33ca                     xor ecx, edx
0004f4de  890f                     mov dword ptr [rdi], ecx
0004f4e0  66ff4500                 inc word ptr [rbp]
0004f4e4  41bd00ff0000             mov r13d, 0xff00
0004f4ea  486306                   movsxd rax, dword ptr [rsi]
0004f4ed  0fb6942488000000         movzx edx, byte ptr [rsp + 0x88]
0004f4f5  66410bd5                 or dx, r13w
0004f4f9  0fb7ca                   movzx ecx, dx
0004f4fc  66c1e908                 shr cx, 8
0004f500  880c18                   mov byte ptr [rax + rbx], cl
0004f503  48630e                   movsxd rcx, dword ptr [rsi]
0004f506  8d4101                   lea eax, [rcx + 1]
0004f509  8906                     mov dword ptr [rsi], eax
0004f50b  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f50f  ff06                     inc dword ptr [rsi]
0004f511  833e04                   cmp dword ptr [rsi], 4
0004f514  0f858b000000             jne 0x4f5a5
0004f51a  448916                   mov dword ptr [rsi], r10d
0004f51d  458b0f                   mov r9d, dword ptr [r15]
0004f520  8b13                     mov edx, dword ptr [rbx]
0004f522  4585f6                   test r14d, r14d
0004f525  7531                     jne 0x4f558
0004f527  41c1c103                 rol r9d, 3
0004f52b  4133d1                   xor edx, r9d
0004f52e  418917                   mov dword ptr [r15], edx
0004f531  6644394302               cmp word ptr [rbx + 2], r8w
0004f536  7404                     je 0x4f53c
0004f538  8917                     mov dword ptr [rdi], edx
0004f53a  eb69                     jmp 0x4f5a5
0004f53c  0fb703                   movzx eax, word ptr [rbx]
0004f53f  66413bc0                 cmp ax, r8w
0004f543  7460                     je 0x4f5a5
0004f545  0fb6c8                   movzx ecx, al
0004f548  4133c9                   xor ecx, r9d
0004f54b  890f                     mov dword ptr [rdi], ecx
0004f54d  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f551  c1c103                   rol ecx, 3
0004f554  33c8                     xor ecx, eax
0004f556  eb4b                     jmp 0x4f5a3
0004f558  4169c920080000           imul ecx, r9d, 0x820
0004f55f  418bc1                   mov eax, r9d
0004f562  c1e802                   shr eax, 2
0004f565  03c8                     add ecx, eax
0004f567  8d040a                   lea eax, [rdx + rcx]
0004f56a  4133c1                   xor eax, r9d
0004f56d  418907                   mov dword ptr [r15], eax
0004f570  6644394302               cmp word ptr [rbx + 2], r8w
0004f575  7404                     je 0x4f57b
0004f577  8907                     mov dword ptr [rdi], eax
0004f579  eb2a                     jmp 0x4f5a5
0004f57b  0fb703                   movzx eax, word ptr [rbx]
0004f57e  66413bc0                 cmp ax, r8w
0004f582  7421                     je 0x4f5a5
0004f584  0fb6d0                   movzx edx, al
0004f587  03d1                     add edx, ecx
0004f589  4133d1                   xor edx, r9d
0004f58c  69c220080000             imul eax, edx, 0x820
0004f592  8917                     mov dword ptr [rdi], edx
0004f594  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004f598  03c8                     add ecx, eax
0004f59a  8bc2                     mov eax, edx
0004f59c  c1e802                   shr eax, 2
0004f59f  03c8                     add ecx, eax
0004f5a1  33ca                     xor ecx, edx
0004f5a3  890f                     mov dword ptr [rdi], ecx
0004f5a5  66ff4500                 inc word ptr [rbp]
0004f5a9  486306                   movsxd rax, dword ptr [rsi]
0004f5ac  0fb6942489000000         movzx edx, byte ptr [rsp + 0x89]
0004f5b4  66410bd5                 or dx, r13w
0004f5b8  0fb7ca                   movzx ecx, dx
0004f5bb  66c1e908                 shr cx, 8
0004f5bf  880c18                   mov byte ptr [rax + rbx], cl
0004f5c2  48630e                   movsxd rcx, dword ptr [rsi]
0004f5c5  8d4101                   lea eax, [rcx + 1]
0004f5c8  8906                     mov dword ptr [rsi], eax
0004f5ca  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f5ce  ff06                     inc dword ptr [rsi]
0004f5d0  833e04                   cmp dword ptr [rsi], 4
0004f5d3  0f858b000000             jne 0x4f664
0004f5d9  448916                   mov dword ptr [rsi], r10d
0004f5dc  458b0f                   mov r9d, dword ptr [r15]
0004f5df  8b13                     mov edx, dword ptr [rbx]
0004f5e1  4585f6                   test r14d, r14d
0004f5e4  7531                     jne 0x4f617
0004f5e6  41c1c103                 rol r9d, 3
0004f5ea  4133d1                   xor edx, r9d
0004f5ed  418917                   mov dword ptr [r15], edx
0004f5f0  6644394302               cmp word ptr [rbx + 2], r8w
0004f5f5  7404                     je 0x4f5fb
0004f5f7  8917                     mov dword ptr [rdi], edx
0004f5f9  eb69                     jmp 0x4f664
0004f5fb  0fb703                   movzx eax, word ptr [rbx]
0004f5fe  66413bc0                 cmp ax, r8w
0004f602  7460                     je 0x4f664
0004f604  0fb6c8                   movzx ecx, al
0004f607  4133c9                   xor ecx, r9d
0004f60a  890f                     mov dword ptr [rdi], ecx
0004f60c  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f610  c1c103                   rol ecx, 3
0004f613  33c8                     xor ecx, eax
0004f615  eb4b                     jmp 0x4f662
0004f617  4169c920080000           imul ecx, r9d, 0x820
0004f61e  418bc1                   mov eax, r9d
0004f621  c1e802                   shr eax, 2
0004f624  03c8                     add ecx, eax
0004f626  8d040a                   lea eax, [rdx + rcx]
0004f629  4133c1                   xor eax, r9d
0004f62c  418907                   mov dword ptr [r15], eax
0004f62f  6644394302               cmp word ptr [rbx + 2], r8w
0004f634  7404                     je 0x4f63a
0004f636  8907                     mov dword ptr [rdi], eax
0004f638  eb2a                     jmp 0x4f664
0004f63a  0fb703                   movzx eax, word ptr [rbx]
0004f63d  66413bc0                 cmp ax, r8w
0004f641  7421                     je 0x4f664
0004f643  0fb6d0                   movzx edx, al
0004f646  03d1                     add edx, ecx
0004f648  4133d1                   xor edx, r9d
0004f64b  69c220080000             imul eax, edx, 0x820
0004f651  8917                     mov dword ptr [rdi], edx
0004f653  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004f657  03c8                     add ecx, eax
0004f659  8bc2                     mov eax, edx
0004f65b  c1e802                   shr eax, 2
0004f65e  03c8                     add ecx, eax
0004f660  33ca                     xor ecx, edx
0004f662  890f                     mov dword ptr [rdi], ecx
0004f664  66ff4500                 inc word ptr [rbp]
0004f668  486306                   movsxd rax, dword ptr [rsi]
0004f66b  0fb694248a000000         movzx edx, byte ptr [rsp + 0x8a]
0004f673  66410bd5                 or dx, r13w
0004f677  0fb7ca                   movzx ecx, dx
0004f67a  66c1e908                 shr cx, 8
0004f67e  880c18                   mov byte ptr [rax + rbx], cl
0004f681  48630e                   movsxd rcx, dword ptr [rsi]
0004f684  8d4101                   lea eax, [rcx + 1]
0004f687  8906                     mov dword ptr [rsi], eax
0004f689  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f68d  ff06                     inc dword ptr [rsi]
0004f68f  833e04                   cmp dword ptr [rsi], 4
0004f692  0f85a5000000             jne 0x4f73d
0004f698  448916                   mov dword ptr [rsi], r10d
0004f69b  458b0f                   mov r9d, dword ptr [r15]
0004f69e  8b13                     mov edx, dword ptr [rbx]
0004f6a0  4585f6                   test r14d, r14d
0004f6a3  7541                     jne 0x4f6e6
0004f6a5  41c1c103                 rol r9d, 3
0004f6a9  4133d1                   xor edx, r9d
0004f6ac  418917                   mov dword ptr [r15], edx
0004f6af  6644394302               cmp word ptr [rbx + 2], r8w
0004f6b4  740b                     je 0x4f6c1
0004f6b6  8917                     mov dword ptr [rdi], edx
0004f6b8  66ff4500                 inc word ptr [rbp]
0004f6bc  e929010000               jmp 0x4f7ea
0004f6c1  0fb703                   movzx eax, word ptr [rbx]
0004f6c4  66413bc0                 cmp ax, r8w
0004f6c8  7473                     je 0x4f73d
0004f6ca  0fb6c8                   movzx ecx, al
0004f6cd  4133c9                   xor ecx, r9d
0004f6d0  890f                     mov dword ptr [rdi], ecx
0004f6d2  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f6d6  c1c103                   rol ecx, 3
0004f6d9  33c8                     xor ecx, eax
0004f6db  890f                     mov dword ptr [rdi], ecx
0004f6dd  66ff4500                 inc word ptr [rbp]
0004f6e1  e904010000               jmp 0x4f7ea
0004f6e6  4569d120080000           imul r10d, r9d, 0x820
0004f6ed  418bc1                   mov eax, r9d
0004f6f0  c1e802                   shr eax, 2
0004f6f3  4403d0                   add r10d, eax
0004f6f6  428d0412                 lea eax, [rdx + r10]
0004f6fa  4133c1                   xor eax, r9d
0004f6fd  418907                   mov dword ptr [r15], eax
0004f700  6644394302               cmp word ptr [rbx + 2], r8w
0004f705  740b                     je 0x4f712
0004f707  8907                     mov dword ptr [rdi], eax
0004f709  66ff4500                 inc word ptr [rbp]
0004f70d  e9d8000000               jmp 0x4f7ea
0004f712  0fb703                   movzx eax, word ptr [rbx]
0004f715  66413bc0                 cmp ax, r8w
0004f719  7422                     je 0x4f73d
0004f71b  0fb6d0                   movzx edx, al
0004f71e  4103d2                   add edx, r10d
0004f721  4133d1                   xor edx, r9d
0004f724  69c220080000             imul eax, edx, 0x820
0004f72a  8917                     mov dword ptr [rdi], edx
0004f72c  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004f730  03c8                     add ecx, eax
0004f732  8bc2                     mov eax, edx
0004f734  c1e802                   shr eax, 2
0004f737  03c8                     add ecx, eax
0004f739  33ca                     xor ecx, edx
0004f73b  890f                     mov dword ptr [rdi], ecx
0004f73d  66ff4500                 inc word ptr [rbp]
0004f741  e9a4000000               jmp 0x4f7ea
0004f746  498b06                   mov rax, qword ptr [r14]
0004f749  41bd00ff0000             mov r13d, 0xff00
0004f74f  0fb7542450               movzx edx, word ptr [rsp + 0x50]
0004f754  0fb7ca                   movzx ecx, dx
0004f757  66c1e908                 shr cx, 8
0004f75b  8808                     mov byte ptr [rax], cl
0004f75d  49ff06                   inc qword ptr [r14]
0004f760  498b06                   mov rax, qword ptr [r14]
0004f763  8810                     mov byte ptr [rax], dl
0004f765  49ff06                   inc qword ptr [r14]
0004f768  498b0e                   mov rcx, qword ptr [r14]
0004f76b  0fb6942488000000         movzx edx, byte ptr [rsp + 0x88]
0004f773  66410bd5                 or dx, r13w
0004f777  0fb7c2                   movzx eax, dx
0004f77a  66c1e808                 shr ax, 8
0004f77e  8801                     mov byte ptr [rcx], al
0004f780  49ff06                   inc qword ptr [r14]
0004f783  498b06                   mov rax, qword ptr [r14]
0004f786  8810                     mov byte ptr [rax], dl
0004f788  49ff06                   inc qword ptr [r14]
0004f78b  498b0e                   mov rcx, qword ptr [r14]
0004f78e  0fb6942489000000         movzx edx, byte ptr [rsp + 0x89]
0004f796  66410bd5                 or dx, r13w
0004f79a  0fb7c2                   movzx eax, dx
0004f79d  66c1e808                 shr ax, 8
0004f7a1  8801                     mov byte ptr [rcx], al
0004f7a3  49ff06                   inc qword ptr [r14]
0004f7a6  498b06                   mov rax, qword ptr [r14]
0004f7a9  8810                     mov byte ptr [rax], dl
0004f7ab  49ff06                   inc qword ptr [r14]
0004f7ae  498b0e                   mov rcx, qword ptr [r14]
0004f7b1  0fb694248a000000         movzx edx, byte ptr [rsp + 0x8a]
0004f7b9  66410bd5                 or dx, r13w
0004f7bd  0fb7c2                   movzx eax, dx
0004f7c0  66c1e808                 shr ax, 8
0004f7c4  8801                     mov byte ptr [rcx], al
0004f7c6  49ff06                   inc qword ptr [r14]
0004f7c9  498b06                   mov rax, qword ptr [r14]
0004f7cc  488b4c2470               mov rcx, qword ptr [rsp + 0x70]
0004f7d1  8810                     mov byte ptr [rax], dl
0004f7d3  49ff06                   inc qword ptr [r14]
0004f7d6  498b0424                 mov rax, qword ptr [r12]
0004f7da  c60002                   mov byte ptr [rax], 2
0004f7dd  488b01                   mov rax, qword ptr [rcx]
0004f7e0  c60002                   mov byte ptr [rax], 2
0004f7e3  49ff0424                 inc qword ptr [r12]
0004f7e7  48ff01                   inc qword ptr [rcx]
0004f7ea  488b442468               mov rax, qword ptr [rsp + 0x68]
0004f7ef  41ffcb                   dec r11d
0004f7f2  488b8c2480000000         mov rcx, qword ptr [rsp + 0x80]
0004f7fa  440118                   add dword ptr [rax], r11d
0004f7fd  4963c3                   movsxd rax, r11d
0004f800  4803c0                   add rax, rax
0004f803  480101                   add qword ptr [rcx], rax
0004f806  e915030000               jmp 0x4fb20
0004f80b  4c8b5c2470               mov r11, qword ptr [rsp + 0x70]
0004f810  4c8b4c2460               mov r9, qword ptr [rsp + 0x60]
0004f815  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004f81d  410fb64502               movzx eax, byte ptr [r13 + 2]
0004f822  7408                     je 0x4f82c
0004f824  420fb64c0848             movzx ecx, byte ptr [rax + r9 + 0x48]
0004f82a  eb03                     jmp 0x4f82f
0004f82c  0fb7c8                   movzx ecx, ax
0004f82f  410fb64500               movzx eax, byte ptr [r13]
0004f834  66c1e108                 shl cx, 8
0004f838  660bc8                   or cx, ax
0004f83b  66898c2488000000         mov word ptr [rsp + 0x88], cx
0004f843  66c1e908                 shr cx, 8
0004f847  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f84f  743b                     je 0x4f88c
0004f851  486306                   movsxd rax, dword ptr [rsi]
0004f854  880c18                   mov byte ptr [rax + rbx], cl
0004f857  48630e                   movsxd rcx, dword ptr [rsi]
0004f85a  8d4101                   lea eax, [rcx + 1]
0004f85d  8906                     mov dword ptr [rsi], eax
0004f85f  0fb6842488000000         movzx eax, byte ptr [rsp + 0x88]
0004f867  88441901                 mov byte ptr [rcx + rbx + 1], al
0004f86b  ff06                     inc dword ptr [rsi]
0004f86d  833e04                   cmp dword ptr [rsi], 4
0004f870  0f851b020000             jne 0x4fa91
0004f876  4533d2                   xor r10d, r10d
0004f879  41b807020000             mov r8d, 0x207
0004f87f  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004f887  e963010000               jmp 0x4f9ef
0004f88c  498b06                   mov rax, qword ptr [r14]
0004f88f  8808                     mov byte ptr [rax], cl
0004f891  49ff06                   inc qword ptr [r14]
0004f894  498b0e                   mov rcx, qword ptr [r14]
0004f897  0fb6842488000000         movzx eax, byte ptr [rsp + 0x88]
0004f89f  8801                     mov byte ptr [rcx], al
0004f8a1  49ff06                   inc qword ptr [r14]
0004f8a4  498b0424                 mov rax, qword ptr [r12]
0004f8a8  c60002                   mov byte ptr [rax], 2
0004f8ab  410fb64d03               movzx ecx, byte ptr [r13 + 3]
0004f8b0  498b03                   mov rax, qword ptr [r11]
0004f8b3  80e13f                   and cl, 0x3f
0004f8b6  8808                     mov byte ptr [rax], cl
0004f8b8  49ff06                   inc qword ptr [r14]
0004f8bb  e959020000               jmp 0x4fb19
0004f8c0  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f8c8  0f84cc010000             je 0x4fa9a
0004f8ce  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004f8d6  7416                     je 0x4f8ee
0004f8d8  410fb69146010000         movzx edx, byte ptr [r9 + 0x146]
0004f8e0  b8ff000000               mov eax, 0xff
0004f8e5  66c1e208                 shl dx, 8
0004f8e9  660bd0                   or dx, ax
0004f8ec  eb05                     jmp 0x4f8f3
0004f8ee  bafffe0000               mov edx, 0xfeff
0004f8f3  486306                   movsxd rax, dword ptr [rsi]
0004f8f6  0fb7ca                   movzx ecx, dx
0004f8f9  448b9c2400010000         mov r11d, dword ptr [rsp + 0x100]
0004f901  4533d2                   xor r10d, r10d
0004f904  66c1e908                 shr cx, 8
0004f908  41b807020000             mov r8d, 0x207
0004f90e  880c18                   mov byte ptr [rax + rbx], cl
0004f911  48630e                   movsxd rcx, dword ptr [rsi]
0004f914  8d4101                   lea eax, [rcx + 1]
0004f917  8906                     mov dword ptr [rsi], eax
0004f919  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f91d  ff06                     inc dword ptr [rsi]
0004f91f  833e04                   cmp dword ptr [rsi], 4
0004f922  0f858b000000             jne 0x4f9b3
0004f928  448916                   mov dword ptr [rsi], r10d
0004f92b  458b0f                   mov r9d, dword ptr [r15]
0004f92e  8b13                     mov edx, dword ptr [rbx]
0004f930  4585db                   test r11d, r11d
0004f933  7531                     jne 0x4f966
0004f935  41c1c103                 rol r9d, 3
0004f939  4133d1                   xor edx, r9d
0004f93c  418917                   mov dword ptr [r15], edx
0004f93f  6644394302               cmp word ptr [rbx + 2], r8w
0004f944  7404                     je 0x4f94a
0004f946  8917                     mov dword ptr [rdi], edx
0004f948  eb69                     jmp 0x4f9b3
0004f94a  0fb703                   movzx eax, word ptr [rbx]
0004f94d  66413bc0                 cmp ax, r8w
0004f951  7460                     je 0x4f9b3
0004f953  0fb6c8                   movzx ecx, al
0004f956  4133c9                   xor ecx, r9d
0004f959  890f                     mov dword ptr [rdi], ecx
0004f95b  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f95f  c1c103                   rol ecx, 3
0004f962  33c8                     xor ecx, eax
0004f964  eb4b                     jmp 0x4f9b1
0004f966  4169c920080000           imul ecx, r9d, 0x820
0004f96d  418bc1                   mov eax, r9d
0004f970  c1e802                   shr eax, 2
0004f973  03c8                     add ecx, eax
0004f975  8d040a                   lea eax, [rdx + rcx]
0004f978  4133c1                   xor eax, r9d
0004f97b  418907                   mov dword ptr [r15], eax
0004f97e  6644394302               cmp word ptr [rbx + 2], r8w
0004f983  7404                     je 0x4f989
0004f985  8907                     mov dword ptr [rdi], eax
0004f987  eb2a                     jmp 0x4f9b3
0004f989  0fb703                   movzx eax, word ptr [rbx]
0004f98c  66413bc0                 cmp ax, r8w
0004f990  7421                     je 0x4f9b3
0004f992  0fb6d0                   movzx edx, al
0004f995  03d1                     add edx, ecx
0004f997  4133d1                   xor edx, r9d
0004f99a  69c220080000             imul eax, edx, 0x820
0004f9a0  8917                     mov dword ptr [rdi], edx
0004f9a2  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004f9a6  03c8                     add ecx, eax
0004f9a8  8bc2                     mov eax, edx
0004f9aa  c1e802                   shr eax, 2
0004f9ad  03c8                     add ecx, eax
0004f9af  33ca                     xor ecx, edx
0004f9b1  890f                     mov dword ptr [rdi], ecx
0004f9b3  66ff4500                 inc word ptr [rbp]
0004f9b7  410fb64500               movzx eax, byte ptr [r13]
0004f9bc  410fb65502               movzx edx, byte ptr [r13 + 2]
0004f9c1  66c1e008                 shl ax, 8
0004f9c5  660bd0                   or dx, ax
0004f9c8  486306                   movsxd rax, dword ptr [rsi]
0004f9cb  0fb7ca                   movzx ecx, dx
0004f9ce  66c1e908                 shr cx, 8
0004f9d2  880c18                   mov byte ptr [rax + rbx], cl
0004f9d5  48630e                   movsxd rcx, dword ptr [rsi]
0004f9d8  8d4101                   lea eax, [rcx + 1]
0004f9db  8906                     mov dword ptr [rsi], eax
0004f9dd  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f9e1  ff06                     inc dword ptr [rsi]
0004f9e3  833e04                   cmp dword ptr [rsi], 4
0004f9e6  0f85a5000000             jne 0x4fa91
0004f9ec  4585db                   test r11d, r11d
0004f9ef  448916                   mov dword ptr [rsi], r10d
0004f9f2  8b13                     mov edx, dword ptr [rbx]
0004f9f4  458b0f                   mov r9d, dword ptr [r15]
0004f9f7  7541                     jne 0x4fa3a
0004f9f9  41c1c103                 rol r9d, 3
0004f9fd  4133d1                   xor edx, r9d
0004fa00  418917                   mov dword ptr [r15], edx
0004fa03  6644394302               cmp word ptr [rbx + 2], r8w
0004fa08  740b                     je 0x4fa15
0004fa0a  8917                     mov dword ptr [rdi], edx
0004fa0c  66ff4500                 inc word ptr [rbp]
0004fa10  e90b010000               jmp 0x4fb20
0004fa15  0fb703                   movzx eax, word ptr [rbx]
0004fa18  66413bc0                 cmp ax, r8w
0004fa1c  7473                     je 0x4fa91
0004fa1e  0fb6c8                   movzx ecx, al
0004fa21  4133c9                   xor ecx, r9d
0004fa24  890f                     mov dword ptr [rdi], ecx
0004fa26  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004fa2a  c1c103                   rol ecx, 3
0004fa2d  33c8                     xor ecx, eax
0004fa2f  890f                     mov dword ptr [rdi], ecx
0004fa31  66ff4500                 inc word ptr [rbp]
0004fa35  e9e6000000               jmp 0x4fb20
0004fa3a  4569d120080000           imul r10d, r9d, 0x820
0004fa41  418bc1                   mov eax, r9d
0004fa44  c1e802                   shr eax, 2
0004fa47  4403d0                   add r10d, eax
0004fa4a  428d0412                 lea eax, [rdx + r10]
0004fa4e  4133c1                   xor eax, r9d
0004fa51  418907                   mov dword ptr [r15], eax
0004fa54  6644394302               cmp word ptr [rbx + 2], r8w
0004fa59  740b                     je 0x4fa66
0004fa5b  8907                     mov dword ptr [rdi], eax
0004fa5d  66ff4500                 inc word ptr [rbp]
0004fa61  e9ba000000               jmp 0x4fb20
0004fa66  0fb703                   movzx eax, word ptr [rbx]
0004fa69  66413bc0                 cmp ax, r8w
0004fa6d  7422                     je 0x4fa91
0004fa6f  0fb6d0                   movzx edx, al
0004fa72  4103d2                   add edx, r10d
0004fa75  4133d1                   xor edx, r9d
0004fa78  69c220080000             imul eax, edx, 0x820
0004fa7e  8917                     mov dword ptr [rdi], edx
0004fa80  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004fa84  03c8                     add ecx, eax
0004fa86  8bc2                     mov eax, edx
0004fa88  c1e802                   shr eax, 2
0004fa8b  03c8                     add ecx, eax
0004fa8d  33ca                     xor ecx, edx
0004fa8f  890f                     mov dword ptr [rdi], ecx
0004fa91  66ff4500                 inc word ptr [rbp]
0004fa95  e986000000               jmp 0x4fb20
0004fa9a  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004faa2  7416                     je 0x4faba
0004faa4  410fb69146010000         movzx edx, byte ptr [r9 + 0x146]
0004faac  b8ff000000               mov eax, 0xff
0004fab1  66c1e208                 shl dx, 8
0004fab5  660bd0                   or dx, ax
0004fab8  eb05                     jmp 0x4fabf
0004faba  bafffe0000               mov edx, 0xfeff
0004fabf  498b06                   mov rax, qword ptr [r14]
0004fac2  6689942488000000         mov word ptr [rsp + 0x88], dx
0004faca  66c1ea08                 shr dx, 8
0004face  8810                     mov byte ptr [rax], dl
0004fad0  49ff06                   inc qword ptr [r14]
0004fad3  498b0e                   mov rcx, qword ptr [r14]
0004fad6  0fb6842488000000         movzx eax, byte ptr [rsp + 0x88]
0004fade  8801                     mov byte ptr [rcx], al
0004fae0  49ff06                   inc qword ptr [r14]
0004fae3  410fb64500               movzx eax, byte ptr [r13]
0004fae8  410fb65502               movzx edx, byte ptr [r13 + 2]
0004faed  4d8b06                   mov r8, qword ptr [r14]
0004faf0  66c1e008                 shl ax, 8
0004faf4  660bd0                   or dx, ax
0004faf7  0fb7ca                   movzx ecx, dx
0004fafa  66c1ea08                 shr dx, 8
0004fafe  418810                   mov byte ptr [r8], dl
0004fb01  49ff06                   inc qword ptr [r14]
0004fb04  498b06                   mov rax, qword ptr [r14]
0004fb07  8808                     mov byte ptr [rax], cl
0004fb09  49ff06                   inc qword ptr [r14]
0004fb0c  498b0424                 mov rax, qword ptr [r12]
0004fb10  c60002                   mov byte ptr [rax], 2
0004fb13  498b03                   mov rax, qword ptr [r11]
0004fb16  c60002                   mov byte ptr [rax], 2
0004fb19  49ff0424                 inc qword ptr [r12]
0004fb1d  49ff03                   inc qword ptr [r11]
0004fb20  488b9c24e0000000         mov rbx, qword ptr [rsp + 0xe0]
0004fb28  4881c490000000           add rsp, 0x90
0004fb2f  415f                     pop r15
0004fb31  415e                     pop r14
0004fb33  415d                     pop r13
0004fb35  415c                     pop r12
0004fb37  5f                       pop rdi
0004fb38  5e                       pop rsi
0004fb39  5d                       pop rbp
0004fb3a  c3                       ret
0004fb3b  90                       nop
0004fb3c  55                       push rbp
0004fb3d  ec                       in al, dx
0004fb3e  0400                     add al, 0
0004fb40  89ec                     mov esp, ebp
0004fb42  0400                     add al, 0
0004fb44  e0f0                     loopne 0x4fb36
0004fb46  0400                     add al, 0
0004fb48  a2f30400c0f80400ed       movabs byte ptr [0xed0004f8c00004f3], al
0004fb51  ef                       out dx, eax
0004fb52  0400                     add al, 0
