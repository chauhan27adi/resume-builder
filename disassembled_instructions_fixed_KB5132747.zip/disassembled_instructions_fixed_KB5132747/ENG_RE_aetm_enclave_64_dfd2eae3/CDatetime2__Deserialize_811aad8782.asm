; CDatetime2::Deserialize
; aetm_enclave.dll, primary RVA 0x2f0a0, 288 bytes in 1 chunk(s)

; chunk at RVA 0x2f0a0 (288 bytes)
0002f0a0  48895c2408               mov qword ptr [rsp + 8], rbx
0002f0a5  4889742410               mov qword ptr [rsp + 0x10], rsi
0002f0aa  57                       push rdi
0002f0ab  4883ec20                 sub rsp, 0x20
0002f0af  410fb6c0                 movzx eax, r8b
0002f0b3  488d5a08                 lea rbx, [rdx + 8]
0002f0b7  44894118                 mov dword ptr [rcx + 0x18], r8d
0002f0bb  488bf9                   mov rdi, rcx
0002f0be  4c8d053b0ffdff           lea r8, [rip - 0x2f0c5]
0002f0c5  410fb6b48040420600       movzx esi, byte ptr [r8 + rax*4 + 0x64240]
0002f0ce  48c7411000000000         mov qword ptr [rcx + 0x10], 0
0002f0d6  8d46fd                   lea eax, [rsi - 3]
0002f0d9  83f807                   cmp eax, 7
0002f0dc  0f8787000000             ja 0x2f169
0002f0e2  4898                     cdqe
0002f0e4  418b8c80a0f10200         mov ecx, dword ptr [r8 + rax*4 + 0x2f1a0]
0002f0ec  4903c8                   add rcx, r8
0002f0ef  ffe1                     jmp rcx
0002f0f1  0fb703                   movzx eax, word ptr [rbx]
0002f0f4  66894710                 mov word ptr [rdi + 0x10], ax
0002f0f8  0fb64302                 movzx eax, byte ptr [rbx + 2]
0002f0fc  884712                   mov byte ptr [rdi + 0x12], al
0002f0ff  eb77                     jmp 0x2f178
0002f101  8b03                     mov eax, dword ptr [rbx]
0002f103  894710                   mov dword ptr [rdi + 0x10], eax
0002f106  eb70                     jmp 0x2f178
0002f108  8b03                     mov eax, dword ptr [rbx]
0002f10a  894710                   mov dword ptr [rdi + 0x10], eax
0002f10d  0fb64304                 movzx eax, byte ptr [rbx + 4]
0002f111  884714                   mov byte ptr [rdi + 0x14], al
0002f114  eb62                     jmp 0x2f178
0002f116  8b03                     mov eax, dword ptr [rbx]
0002f118  894710                   mov dword ptr [rdi + 0x10], eax
0002f11b  0fb74304                 movzx eax, word ptr [rbx + 4]
0002f11f  66894714                 mov word ptr [rdi + 0x14], ax
0002f123  eb53                     jmp 0x2f178
0002f125  8b03                     mov eax, dword ptr [rbx]
0002f127  894710                   mov dword ptr [rdi + 0x10], eax
0002f12a  0fb74304                 movzx eax, word ptr [rbx + 4]
0002f12e  66894714                 mov word ptr [rdi + 0x14], ax
0002f132  0fb64306                 movzx eax, byte ptr [rbx + 6]
0002f136  884716                   mov byte ptr [rdi + 0x16], al
0002f139  eb3d                     jmp 0x2f178
0002f13b  488b03                   mov rax, qword ptr [rbx]
0002f13e  48894710                 mov qword ptr [rdi + 0x10], rax
0002f142  eb34                     jmp 0x2f178
0002f144  f20f1003                 movsd xmm0, qword ptr [rbx]
0002f148  f20f114710               movsd qword ptr [rdi + 0x10], xmm0
0002f14d  0fb64308                 movzx eax, byte ptr [rbx + 8]
0002f151  884718                   mov byte ptr [rdi + 0x18], al
0002f154  eb22                     jmp 0x2f178
0002f156  f20f1003                 movsd xmm0, qword ptr [rbx]
0002f15a  f20f114710               movsd qword ptr [rdi + 0x10], xmm0
0002f15f  0fb74308                 movzx eax, word ptr [rbx + 8]
0002f163  66894718                 mov word ptr [rdi + 0x18], ax
0002f167  eb0f                     jmp 0x2f178
0002f169  4c8bc6                   mov r8, rsi
0002f16c  488d4f10                 lea rcx, [rdi + 0x10]
0002f170  488bd3                   mov rdx, rbx
0002f173  e89bf00200               call 0x5e213
0002f178  c7470800000000           mov dword ptr [rdi + 8], 0
0002f17f  0fb7041e                 movzx eax, word ptr [rsi + rbx]
0002f183  66894708                 mov word ptr [rdi + 8], ax
0002f187  0fb6441e02               movzx eax, byte ptr [rsi + rbx + 2]
0002f18c  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0002f191  488b742438               mov rsi, qword ptr [rsp + 0x38]
0002f196  88470a                   mov byte ptr [rdi + 0xa], al
0002f199  4883c420                 add rsp, 0x20
0002f19d  5f                       pop rdi
0002f19e  c3                       ret
0002f19f  90                       nop
0002f1a0  f1                       int1
0002f1a1  f00200                   lock add al, byte ptr [rax]
0002f1a4  01f1                     add ecx, esi
0002f1a6  0200                     add al, byte ptr [rax]
0002f1a8  08f1                     or cl, dh
0002f1aa  0200                     add al, byte ptr [rax]
