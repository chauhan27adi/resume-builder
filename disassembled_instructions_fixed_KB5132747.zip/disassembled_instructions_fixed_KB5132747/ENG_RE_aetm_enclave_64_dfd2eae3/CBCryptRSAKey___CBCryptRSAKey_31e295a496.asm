; CBCryptRSAKey::~CBCryptRSAKey
; aetm_enclave.dll, primary RVA 0x18610, 61 bytes in 1 chunk(s)

; chunk at RVA 0x18610 (61 bytes)
00018610  48894c2408               mov qword ptr [rsp + 8], rcx
00018615  4883ec38                 sub rsp, 0x38
00018619  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00018622  488d05b7c20400           lea rax, [rip + 0x4c2b7]
00018629  488901                   mov qword ptr [rcx], rax
0001862c  488d4108                 lea rax, [rcx + 8]
00018630  4889442448               mov qword ptr [rsp + 0x48], rax
00018635  488b08                   mov rcx, qword ptr [rax]
00018638  4885c9                   test rcx, rcx
0001863b  740b                     je 0x18648
0001863d  4883c438                 add rsp, 0x38
00018641  48ff2590aa0400           jmp qword ptr [rip + 0x4aa90]
00018648  4883c438                 add rsp, 0x38
0001864c  c3                       ret
