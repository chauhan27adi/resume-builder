; CSqlSortManager_140::SpecialCaseHandler<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x5c6e0, 1756 bytes in 1 chunk(s)

; chunk at RVA 0x5c6e0 (1756 bytes)
0005c6e0  48895c2418               mov qword ptr [rsp + 0x18], rbx
0005c6e5  55                       push rbp
0005c6e6  56                       push rsi
0005c6e7  57                       push rdi
0005c6e8  4154                     push r12
0005c6ea  4155                     push r13
0005c6ec  4156                     push r14
0005c6ee  4157                     push r15
0005c6f0  4881ec80000000           sub rsp, 0x80
0005c6f7  488b8424f0000000         mov rax, qword ptr [rsp + 0xf0]
0005c6ff  458be8                   mov r13d, r8d
0005c702  488bbc24e0000000         mov rdi, qword ptr [rsp + 0xe0]
0005c70a  488b9c24e8000000         mov rbx, qword ptr [rsp + 0xe8]
0005c712  4c8bb42418010000         mov r14, qword ptr [rsp + 0x118]
0005c71a  4c8bbc2410010000         mov r15, qword ptr [rsp + 0x110]
0005c722  488bac2420010000         mov rbp, qword ptr [rsp + 0x120]
0005c72a  488bb42448010000         mov rsi, qword ptr [rsp + 0x148]
0005c732  4c8b9c2450010000         mov r11, qword ptr [rsp + 0x150]
0005c73a  4c8ba42458010000         mov r12, qword ptr [rsp + 0x158]
0005c742  4c8b942460010000         mov r10, qword ptr [rsp + 0x160]
0005c74a  4c8b842468010000         mov r8, qword ptr [rsp + 0x168]
0005c752  4889442470               mov qword ptr [rsp + 0x70], rax
0005c757  488b842408010000         mov rax, qword ptr [rsp + 0x108]
0005c75f  4889442460               mov qword ptr [rsp + 0x60], rax
0005c764  8b842428010000           mov eax, dword ptr [rsp + 0x128]
0005c76b  48894c2458               mov qword ptr [rsp + 0x58], rcx
0005c770  89442444                 mov dword ptr [rsp + 0x44], eax
0005c774  498b01                   mov rax, qword ptr [r9]
0005c777  488bc8                   mov rcx, rax
0005c77a  4889542450               mov qword ptr [rsp + 0x50], rdx
0005c77f  48c1e928                 shr rcx, 0x28
0005c783  0fb6d1                   movzx edx, cl
0005c786  4c894c2468               mov qword ptr [rsp + 0x68], r9
0005c78b  48897c2448               mov qword ptr [rsp + 0x48], rdi
0005c790  83fa15                   cmp edx, 0x15
0005c793  0f87ae050000             ja 0x5cd47
0005c799  8bca                     mov ecx, edx
0005c79b  488d155e38faff           lea rdx, [rip - 0x5c7a2]
0005c7a2  8b948a64cd0500           mov edx, dword ptr [rdx + rcx*4 + 0x5cd64]
0005c7a9  488d0d5038faff           lea rcx, [rip - 0x5c7b0]
0005c7b0  4803d1                   add rdx, rcx
0005c7b3  ffe2                     jmp rdx
0005c7b5  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0005c7bd  0f8584050000             jne 0x5cd47
0005c7c3  488b8c2430010000         mov rcx, qword ptr [rsp + 0x130]
0005c7cb  4183e502                 and r13d, 2
0005c7cf  488b16                   mov rdx, qword ptr [rsi]
0005c7d2  4883c102                 add rcx, 2
0005c7d6  483bd1                   cmp rdx, rcx
0005c7d9  730d                     jae 0x5c7e8
0005c7db  807afe14                 cmp byte ptr [rdx - 2], 0x14
0005c7df  7707                     ja 0x5c7e8
0005c7e1  bf01000000               mov edi, 1
0005c7e6  eb02                     jmp 0x5c7ea
0005c7e8  33ff                     xor edi, edi
0005c7ea  4585ed                   test r13d, r13d
0005c7ed  7408                     je 0x5c7f7
0005c7ef  85ff                     test edi, edi
0005c7f1  0f8550050000             jne 0x5cd47
0005c7f7  498b13                   mov rdx, qword ptr [r11]
0005c7fa  483b942438010000         cmp rdx, qword ptr [rsp + 0x138]
0005c802  761b                     jbe 0x5c81f
0005c804  0fb6c8                   movzx ecx, al
0005c807  0fb642ff                 movzx eax, byte ptr [rdx - 1]
0005c80b  03c8                     add ecx, eax
0005c80d  b8ff000000               mov eax, 0xff
0005c812  3bc8                     cmp ecx, eax
0005c814  0f47c8                   cmova ecx, eax
0005c817  884aff                   mov byte ptr [rdx - 1], cl
0005c81a  e928050000               jmp 0x5cd47
0005c81f  8802                     mov byte ptr [rdx], al
0005c821  49ff03                   inc qword ptr [r11]
0005c824  e91e050000               jmp 0x5cd47
0005c829  448b5b08                 mov r11d, dword ptr [rbx + 8]
0005c82d  4c8d530e                 lea r10, [rbx + 0xe]
0005c831  488bc8                   mov rcx, rax
0005c834  48c1e820                 shr rax, 0x20
0005c838  48c1e908                 shr rcx, 8
0005c83c  0fb6d1                   movzx edx, cl
0005c83f  0fb6c8                   movzx ecx, al
0005c842  48c1e208                 shl rdx, 8
0005c846  480bd1                   or rdx, rcx
0005c849  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0005c84e  488b81a8000000           mov rax, qword ptr [rcx + 0xa8]
0005c855  440fb70490               movzx r8d, word ptr [rax + rdx*4]
0005c85a  0fb7749002               movzx esi, word ptr [rax + rdx*4 + 2]
0005c85f  488d530c                 lea rdx, [rbx + 0xc]
0005c863  488b03                   mov rax, qword ptr [rbx]
0005c866  493bc2                   cmp rax, r10
0005c869  741a                     je 0x5c885
0005c86b  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
0005c86f  4883c002                 add rax, 2
0005c873  488903                   mov qword ptr [rbx], rax
0005c876  66448902                 mov word ptr [rdx], r8w
0005c87a  66418932                 mov word ptr [r10], si
0005c87e  4885c9                   test rcx, rcx
0005c881  751e                     jne 0x5c8a1
0005c883  eb15                     jmp 0x5c89a
0005c885  488b4310                 mov rax, qword ptr [rbx + 0x10]
0005c889  33ff                     xor edi, edi
0005c88b  48897b10                 mov qword ptr [rbx + 0x10], rdi
0005c88f  488903                   mov qword ptr [rbx], rax
0005c892  66448902                 mov word ptr [rdx], r8w
0005c896  66418932                 mov word ptr [r10], si
0005c89a  488b03                   mov rax, qword ptr [rbx]
0005c89d  48894310                 mov qword ptr [rbx + 0x10], rax
0005c8a1  488913                   mov qword ptr [rbx], rdx
0005c8a4  418d4301                 lea eax, [r11 + 1]
0005c8a8  488b542450               mov rdx, qword ptr [rsp + 0x50]
0005c8ad  894308                   mov dword ptr [rbx + 8], eax
0005c8b0  488b4208                 mov rax, qword ptr [rdx + 8]
0005c8b4  428b1480                 mov edx, dword ptr [rax + r8*4]
0005c8b8  0fb7c2                   movzx eax, dx
0005c8bb  48c1e020                 shl rax, 0x20
0005c8bf  48c1ea10                 shr rdx, 0x10
0005c8c3  480bc2                   or rax, rdx
0005c8c6  498901                   mov qword ptr [r9], rax
0005c8c9  b801000000               mov eax, 1
0005c8ce  e976040000               jmp 0x5cd49
0005c8d3  488b542448               mov rdx, qword ptr [rsp + 0x48]
0005c8d8  4c8d442478               lea r8, [rsp + 0x78]
0005c8dd  33ff                     xor edi, edi
0005c8df  498bc9                   mov rcx, r9
0005c8e2  897c2478                 mov dword ptr [rsp + 0x78], edi
0005c8e6  e8a557ffff               call 0x52090
0005c8eb  39bc24f8000000           cmp dword ptr [rsp + 0xf8], edi
0005c8f2  0f853a030000             jne 0x5cc32
0005c8f8  8b4c2478                 mov ecx, dword ptr [rsp + 0x78]
0005c8fc  85c9                     test ecx, ecx
0005c8fe  0f842e030000             je 0x5cc32
0005c904  498b0424                 mov rax, qword ptr [r12]
0005c908  4c63442444               movsxd r8, dword ptr [rsp + 0x44]
0005c90d  8808                     mov byte ptr [rax], cl
0005c90f  498b0c24                 mov rcx, qword ptr [r12]
0005c913  0fb6442479               movzx eax, byte ptr [rsp + 0x79]
0005c918  41880408                 mov byte ptr [r8 + rcx], al
0005c91c  410fbae510               bt r13d, 0x10
0005c921  7213                     jb 0x5c936
0005c923  498b0c24                 mov rcx, qword ptr [r12]
0005c927  438d0400                 lea eax, [r8 + r8]
0005c92b  4863d0                   movsxd rdx, eax
0005c92e  0fb644247a               movzx eax, byte ptr [rsp + 0x7a]
0005c933  88040a                   mov byte ptr [rdx + rcx], al
0005c936  410fbae511               bt r13d, 0x11
0005c93b  7213                     jb 0x5c950
0005c93d  498b0c24                 mov rcx, qword ptr [r12]
0005c941  438d0440                 lea eax, [r8 + r8*2]
0005c945  4863d0                   movsxd rdx, eax
0005c948  0fb644247b               movzx eax, byte ptr [rsp + 0x7b]
0005c94d  88040a                   mov byte ptr [rdx + rcx], al
0005c950  49ff0424                 inc qword ptr [r12]
0005c954  b801000000               mov eax, 1
0005c959  e9eb030000               jmp 0x5cd49
0005c95e  488b442448               mov rax, qword ptr [rsp + 0x48]
0005c963  33ff                     xor edi, edi
0005c965  b960110000               mov ecx, 0x1160
0005c96a  488938                   mov qword ptr [rax], rdi
0005c96d  488b03                   mov rax, qword ptr [rbx]
0005c970  663908                   cmp word ptr [rax], cx
0005c973  0f83c8020000             jae 0x5cc41
0005c979  488b542450               mov rdx, qword ptr [rsp + 0x50]
0005c97e  488d442444               lea rax, [rsp + 0x44]
0005c983  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0005c988  4c8d4c2440               lea r9, [rsp + 0x40]
0005c98d  4889442430               mov qword ptr [rsp + 0x30], rax
0005c992  4c8bc3                   mov r8, rbx
0005c995  488d442478               lea rax, [rsp + 0x78]
0005c99a  c744242803000000         mov dword ptr [rsp + 0x28], 3
0005c9a2  4889442420               mov qword ptr [rsp + 0x20], rax
0005c9a7  e8c44dffff               call 0x51770
0005c9ac  448be8                   mov r13d, eax
0005c9af  85c0                     test eax, eax
0005c9b1  0f8e85020000             jle 0x5cc3c
0005c9b7  39bc24f8000000           cmp dword ptr [rsp + 0xf8], edi
0005c9be  0f84d2010000             je 0x5cb96
0005c9c4  48634d00                 movsxd rcx, dword ptr [rbp]
0005c9c8  41bc07020000             mov r12d, 0x207
0005c9ce  440fb7442440             movzx r8d, word ptr [rsp + 0x40]
0005c9d4  8bb42400010000           mov esi, dword ptr [rsp + 0x100]
0005c9db  410fb7d0                 movzx edx, r8w
0005c9df  4c8b4c2460               mov r9, qword ptr [rsp + 0x60]
0005c9e4  66c1ea08                 shr dx, 8
0005c9e8  42881431                 mov byte ptr [rcx + r14], dl
0005c9ec  48634d00                 movsxd rcx, dword ptr [rbp]
0005c9f0  8d4101                   lea eax, [rcx + 1]
0005c9f3  894500                   mov dword ptr [rbp], eax
0005c9f6  4688443101               mov byte ptr [rcx + r14 + 1], r8b
0005c9fb  ff4500                   inc dword ptr [rbp]
0005c9fe  837d0004                 cmp dword ptr [rbp], 4
0005ca02  0f8599000000             jne 0x5caa1
0005ca08  897d00                   mov dword ptr [rbp], edi
0005ca0b  458b01                   mov r8d, dword ptr [r9]
0005ca0e  418b16                   mov edx, dword ptr [r14]
0005ca11  85f6                     test esi, esi
0005ca13  7537                     jne 0x5ca4c
0005ca15  41c1c003                 rol r8d, 3
0005ca19  418bc0                   mov eax, r8d
0005ca1c  33c2                     xor eax, edx
0005ca1e  418901                   mov dword ptr [r9], eax
0005ca21  6645396602               cmp word ptr [r14 + 2], r12w
0005ca26  7405                     je 0x5ca2d
0005ca28  418907                   mov dword ptr [r15], eax
0005ca2b  eb74                     jmp 0x5caa1
0005ca2d  410fb706                 movzx eax, word ptr [r14]
0005ca31  66413bc4                 cmp ax, r12w
0005ca35  746a                     je 0x5caa1
0005ca37  0fb6c8                   movzx ecx, al
0005ca3a  4133c8                   xor ecx, r8d
0005ca3d  41890f                   mov dword ptr [r15], ecx
0005ca40  410fb64601               movzx eax, byte ptr [r14 + 1]
0005ca45  c1c103                   rol ecx, 3
0005ca48  33c8                     xor ecx, eax
0005ca4a  eb52                     jmp 0x5ca9e
0005ca4c  4569d020080000           imul r10d, r8d, 0x820
0005ca53  418bc0                   mov eax, r8d
0005ca56  c1e802                   shr eax, 2
0005ca59  4403d0                   add r10d, eax
0005ca5c  418d0412                 lea eax, [r10 + rdx]
0005ca60  4133c0                   xor eax, r8d
0005ca63  418901                   mov dword ptr [r9], eax
0005ca66  6645396602               cmp word ptr [r14 + 2], r12w
0005ca6b  7405                     je 0x5ca72
0005ca6d  418907                   mov dword ptr [r15], eax
0005ca70  eb2f                     jmp 0x5caa1
0005ca72  410fb706                 movzx eax, word ptr [r14]
0005ca76  66413bc4                 cmp ax, r12w
0005ca7a  7425                     je 0x5caa1
0005ca7c  0fb6d0                   movzx edx, al
0005ca7f  4103d2                   add edx, r10d
0005ca82  4133d0                   xor edx, r8d
0005ca85  69c220080000             imul eax, edx, 0x820
0005ca8b  418917                   mov dword ptr [r15], edx
0005ca8e  410fb64e01               movzx ecx, byte ptr [r14 + 1]
0005ca93  03c8                     add ecx, eax
0005ca95  8bc2                     mov eax, edx
0005ca97  c1e802                   shr eax, 2
0005ca9a  03c8                     add ecx, eax
0005ca9c  33ca                     xor ecx, edx
0005ca9e  41890f                   mov dword ptr [r15], ecx
0005caa1  4c8b5c2470               mov r11, qword ptr [rsp + 0x70]
0005caa6  b800ff0000               mov eax, 0xff00
0005caab  0fb6542478               movzx edx, byte ptr [rsp + 0x78]
0005cab0  660bd0                   or dx, ax
0005cab3  0fb7ca                   movzx ecx, dx
0005cab6  6641ff03                 inc word ptr [r11]
0005caba  48634500                 movsxd rax, dword ptr [rbp]
0005cabe  66c1e908                 shr cx, 8
0005cac2  42880c30                 mov byte ptr [rax + r14], cl
0005cac6  48634d00                 movsxd rcx, dword ptr [rbp]
0005caca  8d4101                   lea eax, [rcx + 1]
0005cacd  894500                   mov dword ptr [rbp], eax
0005cad0  4288543101               mov byte ptr [rcx + r14 + 1], dl
0005cad5  ff4500                   inc dword ptr [rbp]
0005cad8  837d0004                 cmp dword ptr [rbp], 4
0005cadc  0f85ae000000             jne 0x5cb90
0005cae2  897d00                   mov dword ptr [rbp], edi
0005cae5  458b01                   mov r8d, dword ptr [r9]
0005cae8  418b16                   mov edx, dword ptr [r14]
0005caeb  85f6                     test esi, esi
0005caed  7548                     jne 0x5cb37
0005caef  41c1c003                 rol r8d, 3
0005caf3  418bc0                   mov eax, r8d
0005caf6  33c2                     xor eax, edx
0005caf8  418901                   mov dword ptr [r9], eax
0005cafb  6645396602               cmp word ptr [r14 + 2], r12w
0005cb00  740c                     je 0x5cb0e
0005cb02  418907                   mov dword ptr [r15], eax
0005cb05  6641ff03                 inc word ptr [r11]
0005cb09  e9ba000000               jmp 0x5cbc8
0005cb0e  410fb706                 movzx eax, word ptr [r14]
0005cb12  66413bc4                 cmp ax, r12w
0005cb16  7478                     je 0x5cb90
0005cb18  0fb6c8                   movzx ecx, al
0005cb1b  4133c8                   xor ecx, r8d
0005cb1e  41890f                   mov dword ptr [r15], ecx
0005cb21  410fb64601               movzx eax, byte ptr [r14 + 1]
0005cb26  c1c103                   rol ecx, 3
0005cb29  33c8                     xor ecx, eax
0005cb2b  41890f                   mov dword ptr [r15], ecx
0005cb2e  6641ff03                 inc word ptr [r11]
0005cb32  e991000000               jmp 0x5cbc8
0005cb37  4569d020080000           imul r10d, r8d, 0x820
0005cb3e  418bc0                   mov eax, r8d
0005cb41  c1e802                   shr eax, 2
0005cb44  4403d0                   add r10d, eax
0005cb47  418d0412                 lea eax, [r10 + rdx]
0005cb4b  4133c0                   xor eax, r8d
0005cb4e  418901                   mov dword ptr [r9], eax
0005cb51  6645396602               cmp word ptr [r14 + 2], r12w
0005cb56  7409                     je 0x5cb61
0005cb58  418907                   mov dword ptr [r15], eax
0005cb5b  6641ff03                 inc word ptr [r11]
0005cb5f  eb67                     jmp 0x5cbc8
0005cb61  410fb706                 movzx eax, word ptr [r14]
0005cb65  66413bc4                 cmp ax, r12w
0005cb69  7425                     je 0x5cb90
0005cb6b  0fb6d0                   movzx edx, al
0005cb6e  4103d2                   add edx, r10d
0005cb71  4133d0                   xor edx, r8d
0005cb74  69c220080000             imul eax, edx, 0x820
0005cb7a  418917                   mov dword ptr [r15], edx
0005cb7d  410fb64e01               movzx ecx, byte ptr [r14 + 1]
0005cb82  03c8                     add ecx, eax
0005cb84  8bc2                     mov eax, edx
0005cb86  c1e802                   shr eax, 2
0005cb89  03c8                     add ecx, eax
0005cb8b  33ca                     xor ecx, edx
0005cb8d  41890f                   mov dword ptr [r15], ecx
0005cb90  6641ff03                 inc word ptr [r11]
0005cb94  eb32                     jmp 0x5cbc8
0005cb96  488b06                   mov rax, qword ptr [rsi]
0005cb99  0fb7542440               movzx edx, word ptr [rsp + 0x40]
0005cb9e  0fb7ca                   movzx ecx, dx
0005cba1  66c1e908                 shr cx, 8
0005cba5  8808                     mov byte ptr [rax], cl
0005cba7  48ff06                   inc qword ptr [rsi]
0005cbaa  488b06                   mov rax, qword ptr [rsi]
0005cbad  8810                     mov byte ptr [rax], dl
0005cbaf  48ff06                   inc qword ptr [rsi]
0005cbb2  488b06                   mov rax, qword ptr [rsi]
0005cbb5  c600ff                   mov byte ptr [rax], 0xff
0005cbb8  48ff06                   inc qword ptr [rsi]
0005cbbb  488b0e                   mov rcx, qword ptr [rsi]
0005cbbe  0fb6442478               movzx eax, byte ptr [rsp + 0x78]
0005cbc3  8801                     mov byte ptr [rcx], al
0005cbc5  48ff06                   inc qword ptr [rsi]
0005cbc8  0fb64c2479               movzx ecx, byte ptr [rsp + 0x79]
0005cbcd  0fb644247a               movzx eax, byte ptr [rsp + 0x7a]
0005cbd2  c1e110                   shl ecx, 0x10
0005cbd5  480bc8                   or rcx, rax
0005cbd8  48b8020200ff00ff0000     movabs rax, 0xff00ff000202
0005cbe2  48c1e110                 shl rcx, 0x10
0005cbe6  480bc8                   or rcx, rax
0005cbe9  488b442468               mov rax, qword ptr [rsp + 0x68]
0005cbee  488908                   mov qword ptr [rax], rcx
0005cbf1  4183fd01                 cmp r13d, 1
0005cbf5  7e3b                     jle 0x5cc32
0005cbf7  488b0b                   mov rcx, qword ptr [rbx]
0005cbfa  488d430e                 lea rax, [rbx + 0xe]
0005cbfe  8b5308                   mov edx, dword ptr [rbx + 8]
0005cc01  458d45ff                 lea r8d, [r13 - 1]
0005cc05  483bc8                   cmp rcx, rax
0005cc08  7417                     je 0x5cc21
0005cc0a  4a8d0c41                 lea rcx, [rcx + r8*2]
0005cc0e  412bd0                   sub edx, r8d
0005cc11  48890b                   mov qword ptr [rbx], rcx
0005cc14  b801000000               mov eax, 1
0005cc19  895308                   mov dword ptr [rbx + 8], edx
0005cc1c  e928010000               jmp 0x5cd49
0005cc21  488b4310                 mov rax, qword ptr [rbx + 0x10]
0005cc25  488903                   mov qword ptr [rbx], rax
0005cc28  8d42ff                   lea eax, [rdx - 1]
0005cc2b  894308                   mov dword ptr [rbx + 8], eax
0005cc2e  48897b10                 mov qword ptr [rbx + 0x10], rdi
0005cc32  b801000000               mov eax, 1
0005cc37  e90d010000               jmp 0x5cd49
0005cc3c  4c8b4c2468               mov r9, qword ptr [rsp + 0x68]
0005cc41  498b09                   mov rcx, qword ptr [r9]
0005cc44  488bc1                   mov rax, rcx
0005cc47  48c1e820                 shr rax, 0x20
0005cc4b  0fb6d0                   movzx edx, al
0005cc4e  48b8ffffffffff00ffff     movabs rax, 0xffff00ffffffffff
0005cc58  4823c8                   and rcx, rax
0005cc5b  48c1e228                 shl rdx, 0x28
0005cc5f  480bd1                   or rdx, rcx
0005cc62  48b902ffffff00ffffff     movabs rcx, 0xffffff00ffffff02
0005cc6c  0fb6c2                   movzx eax, dl
0005cc6f  4823d1                   and rdx, rcx
0005cc72  48c1e020                 shl rax, 0x20
0005cc76  480bc2                   or rax, rdx
0005cc79  4883c802                 or rax, 2
0005cc7d  498901                   mov qword ptr [r9], rax
0005cc80  b801000000               mov eax, 1
0005cc85  e9bf000000               jmp 0x5cd49
0005cc8a  488bc8                   mov rcx, rax
0005cc8d  48c1e920                 shr rcx, 0x20
0005cc91  0fb6d1                   movzx edx, cl
0005cc94  48c1e208                 shl rdx, 8
0005cc98  0fb6c8                   movzx ecx, al
0005cc9b  48b802020000fffd0000     movabs rax, 0xfdff00000202
0005cca5  480bd1                   or rdx, rcx
0005cca8  48c1e210                 shl rdx, 0x10
0005ccac  480bd0                   or rdx, rax
0005ccaf  b801000000               mov eax, 1
0005ccb4  498911                   mov qword ptr [r9], rdx
0005ccb7  488917                   mov qword ptr [rdi], rdx
0005ccba  e98a000000               jmp 0x5cd49
0005ccbf  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0005ccc7  757e                     jne 0x5cd47
0005ccc9  488b16                   mov rdx, qword ptr [rsi]
0005cccc  488b842430010000         mov rax, qword ptr [rsp + 0x130]
0005ccd4  48c1e202                 shl rdx, 2
0005ccd8  488d048500000000         lea rax, [rax*4]
0005cce0  662bd0                   sub dx, ax
0005cce3  b803800000               mov eax, 0x8003
0005cce8  660bd0                   or dx, ax
0005cceb  498b00                   mov rax, qword ptr [r8]
0005ccee  0fb7ca                   movzx ecx, dx
0005ccf1  66c1e908                 shr cx, 8
0005ccf5  8808                     mov byte ptr [rax], cl
0005ccf7  49ff00                   inc qword ptr [r8]
0005ccfa  498b00                   mov rax, qword ptr [r8]
0005ccfd  8810                     mov byte ptr [rax], dl
0005ccff  49ff00                   inc qword ptr [r8]
0005cd02  498b08                   mov rcx, qword ptr [r8]
0005cd05  498b01                   mov rax, qword ptr [r9]
0005cd08  48c1e828                 shr rax, 0x28
0005cd0c  8801                     mov byte ptr [rcx], al
0005cd0e  49ff00                   inc qword ptr [r8]
0005cd11  498b01                   mov rax, qword ptr [r9]
0005cd14  498b08                   mov rcx, qword ptr [r8]
0005cd17  48c1e820                 shr rax, 0x20
0005cd1b  8801                     mov byte ptr [rcx], al
0005cd1d  49ff00                   inc qword ptr [r8]
0005cd20  eb25                     jmp 0x5cd47
0005cd22  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0005cd2a  751b                     jne 0x5cd47
0005cd2c  498b0a                   mov rcx, qword ptr [r10]
0005cd2f  48c1e820                 shr rax, 0x20
0005cd33  483b8c2440010000         cmp rcx, qword ptr [rsp + 0x140]
0005cd3b  7605                     jbe 0x5cd42
0005cd3d  8841ff                   mov byte ptr [rcx - 1], al
0005cd40  eb05                     jmp 0x5cd47
0005cd42  8801                     mov byte ptr [rcx], al
0005cd44  49ff02                   inc qword ptr [r10]
0005cd47  33c0                     xor eax, eax
0005cd49  488b9c24d0000000         mov rbx, qword ptr [rsp + 0xd0]
0005cd51  4881c480000000           add rsp, 0x80
0005cd58  415f                     pop r15
0005cd5a  415e                     pop r14
0005cd5c  415d                     pop r13
0005cd5e  415c                     pop r12
0005cd60  5f                       pop rdi
0005cd61  5e                       pop rsi
0005cd62  5d                       pop rbp
0005cd63  c3                       ret
0005cd64  47cd05                   int 5
0005cd67  00b5c7050029             add byte ptr [rbp + 0x290005c7], dh
0005cd6d  c80500d3                 enter 5, -0x2d
0005cd71  c805005e                 enter 5, 0x5e
0005cd75  c9                       leave
0005cd76  05008acc05               add eax, 0x5cc8a00
0005cd7b  00bfcc050047             add byte ptr [rdi + 0x470005cc], bh
0005cd81  cd05                     int 5
0005cd83  0047cd                   add byte ptr [rdi - 0x33], al
0005cd86  050047cd05               add eax, 0x5cd4700
0005cd8b  0047cd                   add byte ptr [rdi - 0x33], al
0005cd8e  050047cd05               add eax, 0x5cd4700
0005cd93  0047cd                   add byte ptr [rdi - 0x33], al
0005cd96  050047cd05               add eax, 0x5cd4700
0005cd9b  0047cd                   add byte ptr [rdi - 0x33], al
0005cd9e  050047cd05               add eax, 0x5cd4700
0005cda3  0047cd                   add byte ptr [rdi - 0x33], al
0005cda6  050047cd05               add eax, 0x5cd4700
0005cdab  0047cd                   add byte ptr [rdi - 0x33], al
0005cdae  050047cd05               add eax, 0x5cd4700
0005cdb3  0047cd                   add byte ptr [rdi - 0x33], al
0005cdb6  050022cd05               add eax, 0x5cd2200
