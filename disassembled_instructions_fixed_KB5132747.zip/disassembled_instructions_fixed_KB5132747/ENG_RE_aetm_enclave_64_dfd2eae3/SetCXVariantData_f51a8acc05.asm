; SetCXVariantData
; aetm_enclave.dll, primary RVA 0x17b10, 2608 bytes in 8 chunk(s)

; chunk at RVA 0x17b10 (57 bytes)
00017b10  4053                     push rbx
00017b12  56                       push rsi
00017b13  57                       push rdi
00017b14  4156                     push r14
00017b16  4883ec48                 sub rsp, 0x48
00017b1a  488b05e7340900           mov rax, qword ptr [rip + 0x934e7]
00017b21  4833c4                   xor rax, rsp
00017b24  4889442438               mov qword ptr [rsp + 0x38], rax
00017b29  4c8bb42490000000         mov r14, qword ptr [rsp + 0x90]
00017b31  498bd9                   mov rbx, r9
00017b34  0fb6c2                   movzx eax, dl
00017b37  488bf1                   mov rsi, rcx
00017b3a  83c0dc                   add eax, -0x24
00017b3d  418bf8                   mov edi, r8d
00017b40  83f85b                   cmp eax, 0x5b
00017b43  0f879e060000             ja 0x181e7

; chunk at RVA 0x17b49 (855 bytes)
00017b49  4c897c2440               mov qword ptr [rsp + 0x40], r15
00017b4e  4c8d3dab84feff           lea r15, [rip - 0x17b55]
00017b55  4898                     cdqe
00017b57  410fb68407e4840100       movzx eax, byte ptr [r15 + rax + 0x184e4]
00017b60  418b8c87a0840100         mov ecx, dword ptr [r15 + rax*4 + 0x184a0]
00017b68  4903cf                   add rcx, r15
00017b6b  ffe1                     jmp rcx
00017b6d  488b05f4de4500           mov rax, qword ptr [rip + 0x45def4]
00017b74  83ff08                   cmp edi, 8
00017b77  740d                     je 0x17b86
00017b79  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017b80  0f8578060000             jne 0x181fe
00017b86  4885db                   test rbx, rbx
00017b89  0f8479010000             je 0x17d08
00017b8f  498b19                   mov rbx, qword ptr [r9]
00017b92  4881fbff000000           cmp rbx, 0xff
00017b99  0f867d010000             jbe 0x17d1c
00017b9f  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017ba6  0f856a060000             jne 0x18216
00017bac  e96b010000               jmp 0x17d1c
00017bb1  488b0db0de4500           mov rcx, qword ptr [rip + 0x45deb0]
00017bb8  83ff08                   cmp edi, 8
00017bbb  740d                     je 0x17bca
00017bbd  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017bc4  0f8564060000             jne 0x1822e
00017bca  4885db                   test rbx, rbx
00017bcd  743d                     je 0x17c0c
00017bcf  498b19                   mov rbx, qword ptr [r9]
00017bd2  4885db                   test rbx, rbx
00017bd5  791d                     jns 0x17bf4
00017bd7  488bc3                   mov rax, rbx
00017bda  48f7d8                   neg rax
00017bdd  483d00800000             cmp rax, 0x8000
00017be3  7639                     jbe 0x17c1e
00017be5  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017bec  0f8554060000             jne 0x18246
00017bf2  eb2a                     jmp 0x17c1e
00017bf4  4881fb00800000           cmp rbx, 0x8000
00017bfb  7221                     jb 0x17c1e
00017bfd  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017c04  0f8554060000             jne 0x1825e
00017c0a  eb12                     jmp 0x17c1e
00017c0c  ff1586b50400             call qword ptr [rip + 0x4b586]
00017c12  c70016000000             mov dword ptr [rax], 0x16
00017c18  ff1582b50400             call qword ptr [rip + 0x4b582]
00017c1e  66895e08                 mov word ptr [rsi + 8], bx
00017c22  e9bb050000               jmp 0x181e2
00017c27  488b0d3ade4500           mov rcx, qword ptr [rip + 0x45de3a]
00017c2e  83ff08                   cmp edi, 8
00017c31  740d                     je 0x17c40
00017c33  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017c3a  0f8536060000             jne 0x18276
00017c40  4885db                   test rbx, rbx
00017c43  743b                     je 0x17c80
00017c45  498b19                   mov rbx, qword ptr [r9]
00017c48  ba00000080               mov edx, 0x80000000
00017c4d  4885db                   test rbx, rbx
00017c50  791a                     jns 0x17c6c
00017c52  488bc3                   mov rax, rbx
00017c55  48f7d8                   neg rax
00017c58  483bc2                   cmp rax, rdx
00017c5b  7635                     jbe 0x17c92
00017c5d  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017c64  0f8524060000             jne 0x1828e
00017c6a  eb26                     jmp 0x17c92
00017c6c  483bda                   cmp rbx, rdx
00017c6f  7221                     jb 0x17c92
00017c71  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017c78  0f8528060000             jne 0x182a6
00017c7e  eb12                     jmp 0x17c92
00017c80  ff1512b50400             call qword ptr [rip + 0x4b512]
00017c86  c70016000000             mov dword ptr [rax], 0x16
00017c8c  ff150eb50400             call qword ptr [rip + 0x4b50e]
00017c92  895e08                   mov dword ptr [rsi + 8], ebx
00017c95  e948050000               jmp 0x181e2
00017c9a  83ff08                   cmp edi, 8
00017c9d  7414                     je 0x17cb3
00017c9f  488b05c2dd4500           mov rax, qword ptr [rip + 0x45ddc2]
00017ca6  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017cad  0f850b060000             jne 0x182be
00017cb3  4885db                   test rbx, rbx
00017cb6  740c                     je 0x17cc4
00017cb8  498b19                   mov rbx, qword ptr [r9]
00017cbb  48895e08                 mov qword ptr [rsi + 8], rbx
00017cbf  e91e050000               jmp 0x181e2
00017cc4  ff15ceb40400             call qword ptr [rip + 0x4b4ce]
00017cca  c70016000000             mov dword ptr [rax], 0x16
00017cd0  ff15cab40400             call qword ptr [rip + 0x4b4ca]
00017cd6  48895e08                 mov qword ptr [rsi + 8], rbx
00017cda  e903050000               jmp 0x181e2
00017cdf  83ff08                   cmp edi, 8
00017ce2  7414                     je 0x17cf8
00017ce4  488b057ddd4500           mov rax, qword ptr [rip + 0x45dd7d]
00017ceb  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017cf2  0f85de050000             jne 0x182d6
00017cf8  4885db                   test rbx, rbx
00017cfb  740b                     je 0x17d08
00017cfd  498b19                   mov rbx, qword ptr [r9]
00017d00  885e08                   mov byte ptr [rsi + 8], bl
00017d03  e9da040000               jmp 0x181e2
00017d08  33db                     xor ebx, ebx
00017d0a  ff1588b40400             call qword ptr [rip + 0x4b488]
00017d10  c70016000000             mov dword ptr [rax], 0x16
00017d16  ff1584b40400             call qword ptr [rip + 0x4b484]
00017d1c  885e08                   mov byte ptr [rsi + 8], bl
00017d1f  e9be040000               jmp 0x181e2
00017d24  83ff04                   cmp edi, 4
00017d27  7414                     je 0x17d3d
00017d29  488b0538dd4500           mov rax, qword ptr [rip + 0x45dd38]
00017d30  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017d37  0f85b1050000             jne 0x182ee
00017d3d  4885db                   test rbx, rbx
00017d40  7417                     je 0x17d59
00017d42  418b01                   mov eax, dword ptr [r9]
00017d45  89442430                 mov dword ptr [rsp + 0x30], eax
00017d49  f30f10442430             movss xmm0, dword ptr [rsp + 0x30]
00017d4f  f30f114608               movss dword ptr [rsi + 8], xmm0
00017d54  e989040000               jmp 0x181e2
00017d59  33c0                     xor eax, eax
00017d5b  89442430                 mov dword ptr [rsp + 0x30], eax
00017d5f  ff1533b40400             call qword ptr [rip + 0x4b433]
00017d65  c70016000000             mov dword ptr [rax], 0x16
00017d6b  ff152fb40400             call qword ptr [rip + 0x4b42f]
00017d71  f30f10442430             movss xmm0, dword ptr [rsp + 0x30]
00017d77  f30f114608               movss dword ptr [rsi + 8], xmm0
00017d7c  e961040000               jmp 0x181e2
00017d81  83ff08                   cmp edi, 8
00017d84  7414                     je 0x17d9a
00017d86  488b05dbdc4500           mov rax, qword ptr [rip + 0x45dcdb]
00017d8d  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017d94  0f856c050000             jne 0x18306
00017d9a  4885db                   test rbx, rbx
00017d9d  7418                     je 0x17db7
00017d9f  498b01                   mov rax, qword ptr [r9]
00017da2  4889442430               mov qword ptr [rsp + 0x30], rax
00017da7  f20f10442430             movsd xmm0, qword ptr [rsp + 0x30]
00017dad  f20f114608               movsd qword ptr [rsi + 8], xmm0
00017db2  e92b040000               jmp 0x181e2
00017db7  33c0                     xor eax, eax
00017db9  4889442430               mov qword ptr [rsp + 0x30], rax
00017dbe  ff15d4b30400             call qword ptr [rip + 0x4b3d4]
00017dc4  c70016000000             mov dword ptr [rax], 0x16
00017dca  ff15d0b30400             call qword ptr [rip + 0x4b3d0]
00017dd0  f20f10442430             movsd xmm0, qword ptr [rsp + 0x30]
00017dd6  f20f114608               movsd qword ptr [rsi + 8], xmm0
00017ddb  e902040000               jmp 0x181e2
00017de0  83ff08                   cmp edi, 8
00017de3  0f8459030000             je 0x18142
00017de9  488b0578dc4500           mov rax, qword ptr [rip + 0x45dc78]
00017df0  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017df7  0f8521050000             jne 0x1831e
00017dfd  e940030000               jmp 0x18142
00017e02  83ff08                   cmp edi, 8
00017e05  7414                     je 0x17e1b
00017e07  488b055adc4500           mov rax, qword ptr [rip + 0x45dc5a]
00017e0e  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017e15  0f851b050000             jne 0x18336
00017e1b  4c8d4e08                 lea r9, [rsi + 8]
00017e1f  897c2420                 mov dword ptr [rsp + 0x20], edi
00017e23  4d8bc6                   mov r8, r14
00017e26  8bd7                     mov edx, edi
00017e28  488bcb                   mov rcx, rbx
00017e2b  e820f7ffff               call 0x17550
00017e30  498bce                   mov rcx, r14
00017e33  448bc0                   mov r8d, eax
00017e36  e805c2ffff               call 0x14040
00017e3b  488b1526dc4500           mov rdx, qword ptr [rip + 0x45dc26]
00017e42  3c07                     cmp al, 7
00017e44  760d                     jbe 0x17e53
00017e46  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
00017e4d  0f85fb040000             jne 0x1834e
00017e53  0fb6c8                   movzx ecx, al
00017e56  410fb6c0                 movzx eax, r8b
00017e5a  664139848fc8410600       cmp word ptr [r15 + rcx*4 + 0x641c8], ax
00017e63  0f845a020000             je 0x180c3
00017e69  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
00017e70  0f85f0040000             jne 0x18366
00017e76  e948020000               jmp 0x180c3
00017e7b  498bce                   mov rcx, r14
00017e7e  e8ddfffeff               call 0x7e60
00017e83  440fb7c0                 movzx r8d, ax
00017e87  413bf8                   cmp edi, r8d
00017e8a  7414                     je 0x17ea0
00017e8c  488b05d5db4500           mov rax, qword ptr [rip + 0x45dbd5]
00017e93  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017e9a  0f85de040000             jne 0x1837e

; chunk at RVA 0x17ea0 (53 bytes)
00017ea0  48896c2478               mov qword ptr [rsp + 0x78], rbp
00017ea5  4d8bf0                   mov r14, r8
00017ea8  488d4e08                 lea rcx, [rsi + 8]
00017eac  85ff                     test edi, edi
00017eae  746b                     je 0x17f1b
00017eb0  4885c9                   test rcx, rcx
00017eb3  7520                     jne 0x17ed5
00017eb5  ff15ddb20400             call qword ptr [rip + 0x4b2dd]
00017ebb  c70016000000             mov dword ptr [rax], 0x16
00017ec1  ff15d9b20400             call qword ptr [rip + 0x4b2d9]
00017ec7  488b6c2478               mov rbp, qword ptr [rsp + 0x78]
00017ecc  40887e1b                 mov byte ptr [rsi + 0x1b], dil
00017ed0  e90d030000               jmp 0x181e2

; chunk at RVA 0x17ed5 (35 bytes)
00017ed5  4885db                   test rbx, rbx
00017ed8  741e                     je 0x17ef8
00017eda  4c3bf7                   cmp r14, rdi
00017edd  7219                     jb 0x17ef8
00017edf  4c8bc7                   mov r8, rdi
00017ee2  488bd3                   mov rdx, rbx
00017ee5  e829630400               call 0x5e213
00017eea  488b6c2478               mov rbp, qword ptr [rsp + 0x78]
00017eef  40887e1b                 mov byte ptr [rsi + 0x1b], dil
00017ef3  e9ea020000               jmp 0x181e2

; chunk at RVA 0x17ef8 (49 bytes)
00017ef8  33d2                     xor edx, edx
00017efa  e82c630400               call 0x5e22b
00017eff  4885db                   test rbx, rbx
00017f02  74b1                     je 0x17eb5
00017f04  4c3bf7                   cmp r14, rdi
00017f07  7312                     jae 0x17f1b
00017f09  ff1589b20400             call qword ptr [rip + 0x4b289]
00017f0f  c70022000000             mov dword ptr [rax], 0x22
00017f15  ff1585b20400             call qword ptr [rip + 0x4b285]
00017f1b  488b6c2478               mov rbp, qword ptr [rsp + 0x78]
00017f20  40887e1b                 mov byte ptr [rsi + 0x1b], dil
00017f24  e9b9020000               jmp 0x181e2

; chunk at RVA 0x17f29 (702 bytes)
00017f29  498bce                   mov rcx, r14
00017f2c  e82ffffeff               call 0x7e60
00017f31  440fb7c0                 movzx r8d, ax
00017f35  488b052cdb4500           mov rax, qword ptr [rip + 0x45db2c]
00017f3c  413bf8                   cmp edi, r8d
00017f3f  740d                     je 0x17f4e
00017f41  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017f48  0f8548040000             jne 0x18396
00017f4e  83ff04                   cmp edi, 4
00017f51  740d                     je 0x17f60
00017f53  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017f5a  0f854e040000             jne 0x183ae
00017f60  4883c608                 add rsi, 8
00017f64  488bc7                   mov rax, rdi
00017f67  85ff                     test edi, edi
00017f69  746a                     je 0x17fd5
00017f6b  4885f6                   test rsi, rsi
00017f6e  751e                     jne 0x17f8e
00017f70  ff1522b20400             call qword ptr [rip + 0x4b222]
00017f76  c70016000000             mov dword ptr [rax], 0x16
00017f7c  ff151eb20400             call qword ptr [rip + 0x4b21e]
00017f82  8b06                     mov eax, dword ptr [rsi]
00017f84  c1c010                   rol eax, 0x10
00017f87  8906                     mov dword ptr [rsi], eax
00017f89  e954020000               jmp 0x181e2
00017f8e  4885db                   test rbx, rbx
00017f91  7420                     je 0x17fb3
00017f93  4883f808                 cmp rax, 8
00017f97  771a                     ja 0x17fb3
00017f99  4c8bc0                   mov r8, rax
00017f9c  488bd3                   mov rdx, rbx
00017f9f  488bce                   mov rcx, rsi
00017fa2  e86c620400               call 0x5e213
00017fa7  8b06                     mov eax, dword ptr [rsi]
00017fa9  c1c010                   rol eax, 0x10
00017fac  8906                     mov dword ptr [rsi], eax
00017fae  e92f020000               jmp 0x181e2
00017fb3  33c9                     xor ecx, ecx
00017fb5  48890e                   mov qword ptr [rsi], rcx
00017fb8  4885db                   test rbx, rbx
00017fbb  74b3                     je 0x17f70
00017fbd  4883f808                 cmp rax, 8
00017fc1  7612                     jbe 0x17fd5
00017fc3  ff15cfb10400             call qword ptr [rip + 0x4b1cf]
00017fc9  c70022000000             mov dword ptr [rax], 0x22
00017fcf  ff15cbb10400             call qword ptr [rip + 0x4b1cb]
00017fd5  8b06                     mov eax, dword ptr [rsi]
00017fd7  c1c010                   rol eax, 0x10
00017fda  8906                     mov dword ptr [rsi], eax
00017fdc  e901020000               jmp 0x181e2
00017fe1  83ff05                   cmp edi, 5
00017fe4  7414                     je 0x17ffa
00017fe6  488b057bda4500           mov rax, qword ptr [rip + 0x45da7b]
00017fed  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017ff4  0f85cc030000             jne 0x183c6
00017ffa  4c8d4e08                 lea r9, [rsi + 8]
00017ffe  897c2420                 mov dword ptr [rsp + 0x20], edi
00018002  4d8bc6                   mov r8, r14
00018005  8bd7                     mov edx, edi
00018007  488bcb                   mov rcx, rbx
0001800a  e841f5ffff               call 0x17550
0001800f  498bce                   mov rcx, r14
00018012  448bc0                   mov r8d, eax
00018015  e826c0ffff               call 0x14040
0001801a  488b1547da4500           mov rdx, qword ptr [rip + 0x45da47]
00018021  3c07                     cmp al, 7
00018023  760d                     jbe 0x18032
00018025  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
0001802c  0f85ac030000             jne 0x183de
00018032  0fb6c8                   movzx ecx, al
00018035  410fb6c0                 movzx eax, r8b
00018039  664139848f40420600       cmp word ptr [r15 + rcx*4 + 0x64240], ax
00018042  747f                     je 0x180c3
00018044  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
0001804b  0f85a5030000             jne 0x183f6
00018051  eb70                     jmp 0x180c3
00018053  83ff0a                   cmp edi, 0xa
00018056  7414                     je 0x1806c
00018058  488b0509da4500           mov rax, qword ptr [rip + 0x45da09]
0001805f  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00018066  0f85a2030000             jne 0x1840e
0001806c  4c8d4e08                 lea r9, [rsi + 8]
00018070  897c2420                 mov dword ptr [rsp + 0x20], edi
00018074  4d8bc6                   mov r8, r14
00018077  8bd7                     mov edx, edi
00018079  488bcb                   mov rcx, rbx
0001807c  e8cff4ffff               call 0x17550
00018081  498bce                   mov rcx, r14
00018084  448bc0                   mov r8d, eax
00018087  e8b4bfffff               call 0x14040
0001808c  488b15d5d94500           mov rdx, qword ptr [rip + 0x45d9d5]
00018093  3c07                     cmp al, 7
00018095  760d                     jbe 0x180a4
00018097  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
0001809e  0f8582030000             jne 0x18426
000180a4  0fb6c8                   movzx ecx, al
000180a7  410fb6c0                 movzx eax, r8b
000180ab  664139848fb0420600       cmp word ptr [r15 + rcx*4 + 0x642b0], ax
000180b4  740d                     je 0x180c3
000180b6  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
000180bd  0f857b030000             jne 0x1843e
000180c3  4488461b                 mov byte ptr [rsi + 0x1b], r8b
000180c7  e916010000               jmp 0x181e2
000180cc  83ff11                   cmp edi, 0x11
000180cf  7414                     je 0x180e5
000180d1  488b0590d94500           mov rax, qword ptr [rip + 0x45d990]
000180d8  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000180df  0f8571030000             jne 0x18456
000180e5  410fb60e                 movzx ecx, byte ptr [r14]
000180e9  8d4110                   lea eax, [rcx + 0x10]
000180ec  3c01                     cmp al, 1
000180ee  7607                     jbe 0x180f7
000180f0  450fb64e12               movzx r9d, byte ptr [r14 + 0x12]
000180f5  eb12                     jmp 0x18109
000180f7  420fb68c39405a0600       movzx ecx, byte ptr [rcx + r15 + 0x65a40]
00018100  450fb68c8f725b0600       movzx r9d, byte ptr [r15 + rcx*4 + 0x65b72]
00018109  498bce                   mov rcx, r14
0001810c  e82fbfffff               call 0x14040
00018111  488d4e08                 lea rcx, [rsi + 8]
00018115  88442420                 mov byte ptr [rsp + 0x20], al
00018119  488bd3                   mov rdx, rbx
0001811c  448bc7                   mov r8d, edi
0001811f  e8acbeffff               call 0x13fd0
00018124  e9b9000000               jmp 0x181e2
00018129  83ff08                   cmp edi, 8
0001812c  7414                     je 0x18142
0001812e  488b0533d94500           mov rax, qword ptr [rip + 0x45d933]
00018135  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001813c  0f852c030000             jne 0x1846e
00018142  4883c608                 add rsi, 8
00018146  741f                     je 0x18167
00018148  4885db                   test rbx, rbx
0001814b  7415                     je 0x18162
0001814d  498b01                   mov rax, qword ptr [r9]
00018150  488906                   mov qword ptr [rsi], rax
00018153  8bc8                     mov ecx, eax
00018155  8b4604                   mov eax, dword ptr [rsi + 4]
00018158  8906                     mov dword ptr [rsi], eax
0001815a  894e04                   mov dword ptr [rsi + 4], ecx
0001815d  e980000000               jmp 0x181e2
00018162  33c0                     xor eax, eax
00018164  488906                   mov qword ptr [rsi], rax
00018167  ff152bb00400             call qword ptr [rip + 0x4b02b]
0001816d  c70016000000             mov dword ptr [rax], 0x16
00018173  ff1527b00400             call qword ptr [rip + 0x4b027]
00018179  8b0e                     mov ecx, dword ptr [rsi]
0001817b  8b4604                   mov eax, dword ptr [rsi + 4]
0001817e  8906                     mov dword ptr [rsi], eax
00018180  894e04                   mov dword ptr [rsi + 4], ecx
00018183  eb5d                     jmp 0x181e2
00018185  498bce                   mov rcx, r14
00018188  e8d3fcfeff               call 0x7e60
0001818d  440fb7c0                 movzx r8d, ax
00018191  413bf8                   cmp edi, r8d
00018194  7414                     je 0x181aa
00018196  488b05cbd84500           mov rax, qword ptr [rip + 0x45d8cb]
0001819d  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000181a4  0f85dc020000             jne 0x18486
000181aa  488d4e08                 lea rcx, [rsi + 8]
000181ae  4c8bc7                   mov r8, rdi
000181b1  85ff                     test edi, edi
000181b3  742d                     je 0x181e2
000181b5  4885c9                   test rcx, rcx
000181b8  7416                     je 0x181d0
000181ba  4885db                   test rbx, rbx
000181bd  740a                     je 0x181c9
000181bf  488bd3                   mov rdx, rbx
000181c2  e84c600400               call 0x5e213
000181c7  eb19                     jmp 0x181e2
000181c9  33d2                     xor edx, edx
000181cb  e85b600400               call 0x5e22b
000181d0  ff15c2af0400             call qword ptr [rip + 0x4afc2]
000181d6  c70016000000             mov dword ptr [rax], 0x16
000181dc  ff15beaf0400             call qword ptr [rip + 0x4afbe]
000181e2  4c8b7c2440               mov r15, qword ptr [rsp + 0x40]

; chunk at RVA 0x181e7 (23 bytes)
000181e7  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
000181ec  4833cc                   xor rcx, rsp
000181ef  e8dc4b0400               call 0x5cdd0
000181f4  4883c448                 add rsp, 0x48
000181f8  415e                     pop r14
000181fa  5f                       pop rdi
000181fb  5e                       pop rsi
000181fc  5b                       pop rbx
000181fd  c3                       ret

; chunk at RVA 0x181fe (834 bytes)
000181fe  ba32000000               mov edx, 0x32
00018203  b94f010000               mov ecx, 0x14f
00018208  448d4a32                 lea r9d, [rdx + 0x32]
0001820c  448d42de                 lea r8d, [rdx - 0x22]
00018210  e88b110000               call 0x193a0
00018215  cc                       int3
00018216  ba32000000               mov edx, 0x32
0001821b  b94f010000               mov ecx, 0x14f
00018220  448d4a33                 lea r9d, [rdx + 0x33]
00018224  448d42de                 lea r8d, [rdx - 0x22]
00018228  e873110000               call 0x193a0
0001822d  cc                       int3
0001822e  ba32000000               mov edx, 0x32
00018233  b94f010000               mov ecx, 0x14f
00018238  448d4a34                 lea r9d, [rdx + 0x34]
0001823c  448d42de                 lea r8d, [rdx - 0x22]
00018240  e85b110000               call 0x193a0
00018245  cc                       int3
00018246  ba32000000               mov edx, 0x32
0001824b  b94f010000               mov ecx, 0x14f
00018250  448d4a35                 lea r9d, [rdx + 0x35]
00018254  448d42de                 lea r8d, [rdx - 0x22]
00018258  e843110000               call 0x193a0
0001825d  cc                       int3
0001825e  ba32000000               mov edx, 0x32
00018263  b94f010000               mov ecx, 0x14f
00018268  448d4a36                 lea r9d, [rdx + 0x36]
0001826c  448d42de                 lea r8d, [rdx - 0x22]
00018270  e82b110000               call 0x193a0
00018275  cc                       int3
00018276  ba32000000               mov edx, 0x32
0001827b  b94f010000               mov ecx, 0x14f
00018280  448d4a37                 lea r9d, [rdx + 0x37]
00018284  448d42de                 lea r8d, [rdx - 0x22]
00018288  e813110000               call 0x193a0
0001828d  cc                       int3
0001828e  ba32000000               mov edx, 0x32
00018293  b94f010000               mov ecx, 0x14f
00018298  448d4a38                 lea r9d, [rdx + 0x38]
0001829c  448d42de                 lea r8d, [rdx - 0x22]
000182a0  e8fb100000               call 0x193a0
000182a5  cc                       int3
000182a6  ba32000000               mov edx, 0x32
000182ab  b94f010000               mov ecx, 0x14f
000182b0  448d4a39                 lea r9d, [rdx + 0x39]
000182b4  448d42de                 lea r8d, [rdx - 0x22]
000182b8  e8e3100000               call 0x193a0
000182bd  cc                       int3
000182be  ba32000000               mov edx, 0x32
000182c3  b94f010000               mov ecx, 0x14f
000182c8  448d4a3a                 lea r9d, [rdx + 0x3a]
000182cc  448d42de                 lea r8d, [rdx - 0x22]
000182d0  e8cb100000               call 0x193a0
000182d5  cc                       int3
000182d6  ba32000000               mov edx, 0x32
000182db  b94f010000               mov ecx, 0x14f
000182e0  448d4a3b                 lea r9d, [rdx + 0x3b]
000182e4  448d42de                 lea r8d, [rdx - 0x22]
000182e8  e8b3100000               call 0x193a0
000182ed  cc                       int3
000182ee  ba32000000               mov edx, 0x32
000182f3  b94f010000               mov ecx, 0x14f
000182f8  448d4a3c                 lea r9d, [rdx + 0x3c]
000182fc  448d42de                 lea r8d, [rdx - 0x22]
00018300  e89b100000               call 0x193a0
00018305  cc                       int3
00018306  ba32000000               mov edx, 0x32
0001830b  b94f010000               mov ecx, 0x14f
00018310  448d4a3d                 lea r9d, [rdx + 0x3d]
00018314  448d42de                 lea r8d, [rdx - 0x22]
00018318  e883100000               call 0x193a0
0001831d  cc                       int3
0001831e  ba32000000               mov edx, 0x32
00018323  b94f010000               mov ecx, 0x14f
00018328  448d4a3e                 lea r9d, [rdx + 0x3e]
0001832c  448d42de                 lea r8d, [rdx - 0x22]
00018330  e86b100000               call 0x193a0
00018335  cc                       int3
00018336  ba32000000               mov edx, 0x32
0001833b  b94f010000               mov ecx, 0x14f
00018340  448d4a3f                 lea r9d, [rdx + 0x3f]
00018344  448d42de                 lea r8d, [rdx - 0x22]
00018348  e853100000               call 0x193a0
0001834d  cc                       int3
0001834e  ba32000000               mov edx, 0x32
00018353  b94f010000               mov ecx, 0x14f
00018358  448d4a40                 lea r9d, [rdx + 0x40]
0001835c  448d42de                 lea r8d, [rdx - 0x22]
00018360  e83b100000               call 0x193a0
00018365  cc                       int3
00018366  ba32000000               mov edx, 0x32
0001836b  b94f010000               mov ecx, 0x14f
00018370  448d4a41                 lea r9d, [rdx + 0x41]
00018374  448d42de                 lea r8d, [rdx - 0x22]
00018378  e823100000               call 0x193a0
0001837d  cc                       int3
0001837e  ba32000000               mov edx, 0x32
00018383  b94f010000               mov ecx, 0x14f
00018388  448d4a42                 lea r9d, [rdx + 0x42]
0001838c  448d42de                 lea r8d, [rdx - 0x22]
00018390  e80b100000               call 0x193a0
00018395  cc                       int3
00018396  ba32000000               mov edx, 0x32
0001839b  b94f010000               mov ecx, 0x14f
000183a0  448d4a43                 lea r9d, [rdx + 0x43]
000183a4  448d42de                 lea r8d, [rdx - 0x22]
000183a8  e8f30f0000               call 0x193a0
000183ad  cc                       int3
000183ae  ba32000000               mov edx, 0x32
000183b3  b94f010000               mov ecx, 0x14f
000183b8  448d4a44                 lea r9d, [rdx + 0x44]
000183bc  448d42de                 lea r8d, [rdx - 0x22]
000183c0  e8db0f0000               call 0x193a0
000183c5  cc                       int3
000183c6  ba32000000               mov edx, 0x32
000183cb  b94f010000               mov ecx, 0x14f
000183d0  448d4a45                 lea r9d, [rdx + 0x45]
000183d4  448d42de                 lea r8d, [rdx - 0x22]
000183d8  e8c30f0000               call 0x193a0
000183dd  cc                       int3
000183de  ba32000000               mov edx, 0x32
000183e3  b94f010000               mov ecx, 0x14f
000183e8  448d4a46                 lea r9d, [rdx + 0x46]
000183ec  448d42de                 lea r8d, [rdx - 0x22]
000183f0  e8ab0f0000               call 0x193a0
000183f5  cc                       int3
000183f6  ba32000000               mov edx, 0x32
000183fb  b94f010000               mov ecx, 0x14f
00018400  448d4a47                 lea r9d, [rdx + 0x47]
00018404  448d42de                 lea r8d, [rdx - 0x22]
00018408  e8930f0000               call 0x193a0
0001840d  cc                       int3
0001840e  ba32000000               mov edx, 0x32
00018413  b94f010000               mov ecx, 0x14f
00018418  448d4a48                 lea r9d, [rdx + 0x48]
0001841c  448d42de                 lea r8d, [rdx - 0x22]
00018420  e87b0f0000               call 0x193a0
00018425  cc                       int3
00018426  ba32000000               mov edx, 0x32
0001842b  b94f010000               mov ecx, 0x14f
00018430  448d4a49                 lea r9d, [rdx + 0x49]
00018434  448d42de                 lea r8d, [rdx - 0x22]
00018438  e8630f0000               call 0x193a0
0001843d  cc                       int3
0001843e  ba32000000               mov edx, 0x32
00018443  b94f010000               mov ecx, 0x14f
00018448  448d4a4a                 lea r9d, [rdx + 0x4a]
0001844c  448d42de                 lea r8d, [rdx - 0x22]
00018450  e84b0f0000               call 0x193a0
00018455  cc                       int3
00018456  ba32000000               mov edx, 0x32
0001845b  b94f010000               mov ecx, 0x14f
00018460  448d4a4b                 lea r9d, [rdx + 0x4b]
00018464  448d42de                 lea r8d, [rdx - 0x22]
00018468  e8330f0000               call 0x193a0
0001846d  cc                       int3
0001846e  ba32000000               mov edx, 0x32
00018473  b94f010000               mov ecx, 0x14f
00018478  448d4a4c                 lea r9d, [rdx + 0x4c]
0001847c  448d42de                 lea r8d, [rdx - 0x22]
00018480  e81b0f0000               call 0x193a0
00018485  cc                       int3
00018486  ba32000000               mov edx, 0x32
0001848b  b94f010000               mov ecx, 0x14f
00018490  448d4a4d                 lea r9d, [rdx + 0x4d]
00018494  448d42de                 lea r8d, [rdx - 0x22]
00018498  e8030f0000               call 0x193a0
0001849d  cc                       int3
0001849e  6690                     nop
000184a0  858101007b7e             test dword ptr [rcx + 0x7e7b0001], eax
000184a6  0100                     add dword ptr [rax], eax
000184a8  e17f                     loope 0x18529
000184aa  0100                     add dword ptr [rax], eax
000184ac  027e01                   add bh, byte ptr [rsi + 1]
000184af  005380                   add byte ptr [rbx - 0x80], dl
000184b2  0100                     add dword ptr [rax], eax
000184b4  6d                       insd dword ptr [rdi], dx
000184b5  7b01                     jnp 0x184b8
000184b7  00b17b010027             add byte ptr [rcx + 0x2700017b], dh
000184bd  7c01                     jl 0x184c0
000184bf  0029                     add byte ptr [rcx], ch
000184c1  7f01                     jg 0x184c4
000184c3  00247d01002981           add byte ptr [rdi*2 - 0x7ed6ffff], ah
000184ca  0100                     add dword ptr [rax], eax
000184cc  e07d                     loopne 0x1854b
000184ce  0100                     add dword ptr [rax], eax
000184d0  817d0100df7c01           cmp dword ptr [rbp + 1], 0x17cdf00
000184d7  00cc                     add ah, cl
000184d9  800100                   add byte ptr [rcx], 0
