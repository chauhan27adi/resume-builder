; `CBCryptECDH384Key::GenerateKey'::`1'::dtor$1
; aetm_enclave.dll, primary RVA 0x614e0, 38 bytes in 1 chunk(s)

; chunk at RVA 0x614e0 (38 bytes)
000614e0  4055                     push rbp
000614e2  4883ec20                 sub rsp, 0x20
000614e6  488bea                   mov rbp, rdx
000614e9  8b4530                   mov eax, dword ptr [rbp + 0x30]
000614ec  83e001                   and eax, 1
000614ef  85c0                     test eax, eax
000614f1  740d                     je 0x61500
000614f3  836530fe                 and dword ptr [rbp + 0x30], 0xfffffffe
000614f7  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
000614fb  e81071fbff               call 0x18610
00061500  4883c420                 add rsp, 0x20
00061504  5d                       pop rbp
00061505  c3                       ret
