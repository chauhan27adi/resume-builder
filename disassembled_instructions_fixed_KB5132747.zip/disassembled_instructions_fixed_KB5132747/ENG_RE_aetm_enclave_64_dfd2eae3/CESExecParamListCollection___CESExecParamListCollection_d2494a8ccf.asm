; CESExecParamListCollection::~CESExecParamListCollection
; aetm_enclave.dll, primary RVA 0x2e3f0, 43 bytes in 1 chunk(s)

; chunk at RVA 0x2e3f0 (43 bytes)
0002e3f0  48894c2408               mov qword ptr [rsp + 8], rcx
0002e3f5  4883ec38                 sub rsp, 0x38
0002e3f9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0002e402  4c8d0d27000000           lea r9, [rip + 0x27]
0002e409  ba28000000               mov edx, 0x28
0002e40e  448d42e1                 lea r8d, [rdx - 0x1f]
0002e412  4883c438                 add rsp, 0x38
0002e416  e965ea0200               jmp 0x5ce80
