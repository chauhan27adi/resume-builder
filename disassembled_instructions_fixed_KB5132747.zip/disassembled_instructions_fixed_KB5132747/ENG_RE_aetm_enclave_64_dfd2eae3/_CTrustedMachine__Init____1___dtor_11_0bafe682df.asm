; `CTrustedMachine::Init'::`1'::dtor$11
; aetm_enclave.dll, primary RVA 0x5fe70, 28 bytes in 1 chunk(s)

; chunk at RVA 0x5fe70 (28 bytes)
0005fe70  4055                     push rbp
0005fe72  4883ec20                 sub rsp, 0x20
0005fe76  488bea                   mov rbp, rdx
0005fe79  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0005fe7d  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0005fe81  e85a9afbff               call 0x198e0
0005fe86  4883c420                 add rsp, 0x20
0005fe8a  5d                       pop rbp
0005fe8b  c3                       ret
