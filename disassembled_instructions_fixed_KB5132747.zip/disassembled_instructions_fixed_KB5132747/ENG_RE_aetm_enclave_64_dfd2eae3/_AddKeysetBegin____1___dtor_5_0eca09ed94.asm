; `AddKeysetBegin'::`1'::dtor$5
; aetm_enclave.dll, primary RVA 0x5ef50, 34 bytes in 1 chunk(s)

; chunk at RVA 0x5ef50 (34 bytes)
0005ef50  4055                     push rbp
0005ef52  4883ec20                 sub rsp, 0x20
0005ef56  488bea                   mov rbp, rdx
0005ef59  488b9548010000           mov rdx, qword ptr [rbp + 0x148]
0005ef60  488b8d60010000           mov rcx, qword ptr [rbp + 0x160]
0005ef67  e874a9fbff               call 0x198e0
0005ef6c  4883c420                 add rsp, 0x20
0005ef70  5d                       pop rbp
0005ef71  c3                       ret
