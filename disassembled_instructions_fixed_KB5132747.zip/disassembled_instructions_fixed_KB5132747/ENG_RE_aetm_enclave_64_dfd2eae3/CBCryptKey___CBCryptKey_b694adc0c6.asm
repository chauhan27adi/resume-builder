; CBCryptKey::~CBCryptKey
; aetm_enclave.dll, primary RVA 0x18660, 42 bytes in 1 chunk(s)

; chunk at RVA 0x18660 (42 bytes)
00018660  48894c2408               mov qword ptr [rsp + 8], rcx
00018665  4883ec38                 sub rsp, 0x38
00018669  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00018672  488b09                   mov rcx, qword ptr [rcx]
00018675  4885c9                   test rcx, rcx
00018678  740b                     je 0x18685
0001867a  4883c438                 add rsp, 0x38
0001867e  48ff2553aa0400           jmp qword ptr [rip + 0x4aa53]
00018685  4883c438                 add rsp, 0x38
00018689  c3                       ret
