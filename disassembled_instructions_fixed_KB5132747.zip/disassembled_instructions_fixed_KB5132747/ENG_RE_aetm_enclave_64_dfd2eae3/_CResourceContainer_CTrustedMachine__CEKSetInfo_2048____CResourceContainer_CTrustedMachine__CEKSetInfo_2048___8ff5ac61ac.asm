; `CResourceContainer<CTrustedMachine::CEKSetInfo,2048>::~CResourceContainer<CTrustedMachine::CEKSetInfo,2048>'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x5fb20, 42 bytes in 1 chunk(s)

; chunk at RVA 0x5fb20 (42 bytes)
0005fb20  4055                     push rbp
0005fb22  4883ec20                 sub rsp, 0x20
0005fb26  488bea                   mov rbp, rdx
0005fb29  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0005fb2d  4c8d0dac9ffaff           lea r9, [rip - 0x56054]
0005fb34  41b800080000             mov r8d, 0x800
0005fb3a  ba30000000               mov edx, 0x30
0005fb3f  e83cd3ffff               call 0x5ce80
0005fb44  4883c420                 add rsp, 0x20
0005fb48  5d                       pop rbp
0005fb49  c3                       ret
