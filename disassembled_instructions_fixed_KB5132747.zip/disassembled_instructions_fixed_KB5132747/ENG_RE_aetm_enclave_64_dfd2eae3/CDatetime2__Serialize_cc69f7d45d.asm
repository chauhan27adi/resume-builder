; CDatetime2::Serialize
; aetm_enclave.dll, primary RVA 0x2ef50, 312 bytes in 1 chunk(s)

; chunk at RVA 0x2ef50 (312 bytes)
0002ef50  48895c2418               mov qword ptr [rsp + 0x18], rbx
0002ef55  4889742420               mov qword ptr [rsp + 0x20], rsi
0002ef5a  57                       push rdi
0002ef5b  4883ec40                 sub rsp, 0x40
0002ef5f  33c0                     xor eax, eax
0002ef61  c702032a0000             mov dword ptr [rdx], 0x2a03
0002ef67  894218                   mov dword ptr [rdx + 0x18], eax
0002ef6a  4c8d058f10fdff           lea r8, [rip - 0x2ef71]
0002ef71  48894208                 mov qword ptr [rdx + 8], rax
0002ef75  488bf2                   mov rsi, rdx
0002ef78  48894210                 mov qword ptr [rdx + 0x10], rax
0002ef7c  8b4108                   mov eax, dword ptr [rcx + 8]
0002ef7f  488b5110                 mov rdx, qword ptr [rcx + 0x10]
0002ef83  89442430                 mov dword ptr [rsp + 0x30], eax
0002ef87  0fb64118                 movzx eax, byte ptr [rcx + 0x18]
0002ef8b  4889542420               mov qword ptr [rsp + 0x20], rdx
0002ef90  410fb6bc8040420600       movzx edi, byte ptr [r8 + rax*4 + 0x64240]
0002ef99  8d4703                   lea eax, [rdi + 3]
0002ef9c  88461b                   mov byte ptr [rsi + 0x1b], al
0002ef9f  8d47fd                   lea eax, [rdi - 3]
0002efa2  83f807                   cmp eax, 7
0002efa5  0f8784000000             ja 0x2f02f
0002efab  4898                     cdqe
0002efad  418b8c8068f00200         mov ecx, dword ptr [r8 + rax*4 + 0x2f068]
0002efb5  4903c8                   add rcx, r8
0002efb8  ffe1                     jmp rcx
0002efba  0fb6442422               movzx eax, byte ptr [rsp + 0x22]
0002efbf  66895608                 mov word ptr [rsi + 8], dx
0002efc3  88460a                   mov byte ptr [rsi + 0xa], al
0002efc6  eb78                     jmp 0x2f040
0002efc8  895608                   mov dword ptr [rsi + 8], edx
0002efcb  eb73                     jmp 0x2f040
0002efcd  0fb6442424               movzx eax, byte ptr [rsp + 0x24]
0002efd2  895608                   mov dword ptr [rsi + 8], edx
0002efd5  88460c                   mov byte ptr [rsi + 0xc], al
0002efd8  eb66                     jmp 0x2f040
0002efda  0fb7442424               movzx eax, word ptr [rsp + 0x24]
0002efdf  895608                   mov dword ptr [rsi + 8], edx
0002efe2  6689460c                 mov word ptr [rsi + 0xc], ax
0002efe6  eb58                     jmp 0x2f040
0002efe8  0fb7442424               movzx eax, word ptr [rsp + 0x24]
0002efed  895608                   mov dword ptr [rsi + 8], edx
0002eff0  6689460c                 mov word ptr [rsi + 0xc], ax
0002eff4  0fb6442426               movzx eax, byte ptr [rsp + 0x26]
0002eff9  88460e                   mov byte ptr [rsi + 0xe], al
0002effc  eb42                     jmp 0x2f040
0002effe  48895608                 mov qword ptr [rsi + 8], rdx
0002f002  eb3c                     jmp 0x2f040
0002f004  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
0002f00a  0fb6442428               movzx eax, byte ptr [rsp + 0x28]
0002f00f  f20f114608               movsd qword ptr [rsi + 8], xmm0
0002f014  884610                   mov byte ptr [rsi + 0x10], al
0002f017  eb27                     jmp 0x2f040
0002f019  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
0002f01f  0fb7442428               movzx eax, word ptr [rsp + 0x28]
0002f024  f20f114608               movsd qword ptr [rsi + 8], xmm0
0002f029  66894610                 mov word ptr [rsi + 0x10], ax
0002f02d  eb11                     jmp 0x2f040
0002f02f  4c8bc7                   mov r8, rdi
0002f032  488d542420               lea rdx, [rsp + 0x20]
0002f037  488d4e08                 lea rcx, [rsi + 8]
0002f03b  e8d3f10200               call 0x5e213
0002f040  0fb7442430               movzx eax, word ptr [rsp + 0x30]
0002f045  488b5c2460               mov rbx, qword ptr [rsp + 0x60]
0002f04a  6689443708               mov word ptr [rdi + rsi + 8], ax
0002f04f  0fb6442432               movzx eax, byte ptr [rsp + 0x32]
0002f054  8844370a                 mov byte ptr [rdi + rsi + 0xa], al
0002f058  c60600                   mov byte ptr [rsi], 0
0002f05b  488b742468               mov rsi, qword ptr [rsp + 0x68]
0002f060  4883c440                 add rsp, 0x40
0002f064  5f                       pop rdi
0002f065  c3                       ret
0002f066  6690                     nop
0002f068  baef0200c8               mov edx, 0xc80002ef
0002f06d  ef                       out dx, eax
0002f06e  0200                     add al, byte ptr [rax]
0002f070  cdef                     int 0xef
0002f072  0200                     add al, byte ptr [rax]
