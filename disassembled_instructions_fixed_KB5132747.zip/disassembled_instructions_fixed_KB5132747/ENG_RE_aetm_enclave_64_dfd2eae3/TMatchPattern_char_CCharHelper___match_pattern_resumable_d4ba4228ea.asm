; TMatchPattern<char,CCharHelper>::match_pattern_resumable
; aetm_enclave.dll, primary RVA 0x335c0, 3964 bytes in 4 chunk(s)

; chunk at RVA 0x335c0 (198 bytes)
000335c0  4053                     push rbx
000335c2  56                       push rsi
000335c3  4156                     push r14
000335c5  4157                     push r15
000335c7  4881ec38010000           sub rsp, 0x138
000335ce  488b05337a0700           mov rax, qword ptr [rip + 0x77a33]
000335d5  4833c4                   xor rax, rsp
000335d8  4889842410010000         mov qword ptr [rsp + 0x110], rax
000335e0  488b842490010000         mov rax, qword ptr [rsp + 0x190]
000335e8  4c8bf1                   mov r14, rcx
000335eb  4c8b9c24b0010000         mov r11, qword ptr [rsp + 0x1b0]
000335f3  33c9                     xor ecx, ecx
000335f5  4c8bbc2488010000         mov r15, qword ptr [rsp + 0x188]
000335fd  418bf0                   mov esi, r8d
00033600  48898424e0000000         mov qword ptr [rsp + 0xe0], rax
00033608  488bda                   mov rbx, rdx
0003360b  488b842498010000         mov rax, qword ptr [rsp + 0x198]
00033613  48898424e8000000         mov qword ptr [rsp + 0xe8], rax
0003361b  488b8424a0010000         mov rax, qword ptr [rsp + 0x1a0]
00033623  4c898c2400010000         mov qword ptr [rsp + 0x100], r9
0003362b  4c8bca                   mov r9, rdx
0003362e  48898424f0000000         mov qword ptr [rsp + 0xf0], rax
00033636  4c899c24c8000000         mov qword ptr [rsp + 0xc8], r11
0003363e  48899424b8000000         mov qword ptr [rsp + 0xb8], rdx
00033646  4d85f6                   test r14, r14
00033649  7437                     je 0x33682
0003364b  458b4654                 mov r8d, dword ptr [r14 + 0x54]
0003364f  4585c0                   test r8d, r8d
00033652  742e                     je 0x33682
00033654  488b050d454300           mov rax, qword ptr [rip + 0x43450d]
0003365b  480590070000             add rax, 0x790
00033661  488b10                   mov rdx, qword ptr [rax]
00033664  4885d2                   test rdx, rdx
00033667  7406                     je 0x3366f
00033669  44394210                 cmp dword ptr [rdx + 0x10], r8d
0003366d  7411                     je 0x33680
0003366f  ffc1                     inc ecx
00033671  4883c008                 add rax, 8
00033675  83f911                   cmp ecx, 0x11
00033678  0f8d680e0000             jge 0x344e6
0003367e  ebe1                     jmp 0x33661
00033680  33c9                     xor ecx, ecx
00033682  41803b00                 cmp byte ptr [r11], 0

; chunk at RVA 0x33686 (3680 bytes)
00033686  4889ac2478010000         mov qword ptr [rsp + 0x178], rbp
0003368e  488be9                   mov rbp, rcx
00033691  4889bc2430010000         mov qword ptr [rsp + 0x130], rdi
00033699  488bf9                   mov rdi, rcx
0003369c  4c89a42428010000         mov qword ptr [rsp + 0x128], r12
000336a4  4c89ac2420010000         mov qword ptr [rsp + 0x120], r13
000336ac  41bd01000000             mov r13d, 1
000336b2  48898c24a8000000         mov qword ptr [rsp + 0xa8], rcx
000336ba  48898c24c0000000         mov qword ptr [rsp + 0xc0], rcx
000336c2  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
000336ca  48898c2490000000         mov qword ptr [rsp + 0x90], rcx
000336d2  894c2470                 mov dword ptr [rsp + 0x70], ecx
000336d6  48894c2468               mov qword ptr [rsp + 0x68], rcx
000336db  48894c2478               mov qword ptr [rsp + 0x78], rcx
000336e0  48898c24b0000000         mov qword ptr [rsp + 0xb0], rcx
000336e8  48894c2460               mov qword ptr [rsp + 0x60], rcx
000336ed  48898c24d0000000         mov qword ptr [rsp + 0xd0], rcx
000336f5  898c2488000000           mov dword ptr [rsp + 0x88], ecx
000336fc  c644245000               mov byte ptr [rsp + 0x50], 0
00033701  7411                     je 0x33714
00033703  4c8ba42480010000         mov r12, qword ptr [rsp + 0x180]
0003370b  41c60300                 mov byte ptr [r11], 0
0003370f  e9bf020000               jmp 0x339d3
00033714  498b4320                 mov rax, qword ptr [r11 + 0x20]
00033718  498b8bc81f0000           mov rcx, qword ptr [r11 + 0x1fc8]
0003371f  4d8b6308                 mov r12, qword ptr [r11 + 8]
00033723  498b7b58                 mov rdi, qword ptr [r11 + 0x58]
00033727  458b4370                 mov r8d, dword ptr [r11 + 0x70]
0003372b  418b7318                 mov esi, dword ptr [r11 + 0x18]
0003372f  4889842498000000         mov qword ptr [rsp + 0x98], rax
00033737  410fb64328               movzx eax, byte ptr [r11 + 0x28]
0003373c  89442454                 mov dword ptr [rsp + 0x54], eax
00033740  498b4330                 mov rax, qword ptr [r11 + 0x30]
00033744  48898424a8000000         mov qword ptr [rsp + 0xa8], rax
0003374c  498b4338                 mov rax, qword ptr [r11 + 0x38]
00033750  48898424c0000000         mov qword ptr [rsp + 0xc0], rax
00033758  498b4340                 mov rax, qword ptr [r11 + 0x40]
0003375c  4889842480000000         mov qword ptr [rsp + 0x80], rax
00033764  418b4348                 mov eax, dword ptr [r11 + 0x48]
00033768  89442470                 mov dword ptr [rsp + 0x70], eax
0003376c  498b4350                 mov rax, qword ptr [r11 + 0x50]
00033770  48898424b0000000         mov qword ptr [rsp + 0xb0], rax
00033778  498b4360                 mov rax, qword ptr [r11 + 0x60]
0003377c  4889442460               mov qword ptr [rsp + 0x60], rax
00033781  498b4368                 mov rax, qword ptr [r11 + 0x68]
00033785  48898424d0000000         mov qword ptr [rsp + 0xd0], rax
0003378d  410fb64374               movzx eax, byte ptr [r11 + 0x74]
00033792  88442450                 mov byte ptr [rsp + 0x50], al
00033796  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
0003379e  4889bc24a0000000         mov qword ptr [rsp + 0xa0], rdi
000337a6  4489842488000000         mov dword ptr [rsp + 0x88], r8d
000337ae  4883f9ff                 cmp rcx, -1
000337b2  7506                     jne 0x337ba
000337b4  33ed                     xor ebp, ebp
000337b6  8bdd                     mov ebx, ebp
000337b8  eb05                     jmp 0x337bf
000337ba  4803d9                   add rbx, rcx
000337bd  33ed                     xor ebp, ebp
000337bf  4883f9ff                 cmp rcx, -1
000337c3  498d0409                 lea rax, [r9 + rcx]
000337c7  498b8bd01f0000           mov rcx, qword ptr [r11 + 0x1fd0]
000337ce  4c8bd5                   mov r10, rbp
000337d1  4c0f45d0                 cmovne r10, rax
000337d5  488bd5                   mov rdx, rbp
000337d8  4883f9ff                 cmp rcx, -1
000337dc  498d0409                 lea rax, [r9 + rcx]
000337e0  480f45d0                 cmovne rdx, rax
000337e4  4585c0                   test r8d, r8d
000337e7  7420                     je 0x33809
000337e9  4d8b8bb81f0000           mov r9, qword ptr [r11 + 0x1fb8]
000337f0  418b83c01f0000           mov eax, dword ptr [r11 + 0x1fc0]
000337f7  4903c1                   add rax, r9
000337fa  4c894c2468               mov qword ptr [rsp + 0x68], r9
000337ff  48898424d8000000         mov qword ptr [rsp + 0xd8], rax
00033807  eb10                     jmp 0x33819
00033809  4c8bcd                   mov r9, rbp
0003380c  48896c2468               mov qword ptr [rsp + 0x68], rbp
00033811  4889ac24d8000000         mov qword ptr [rsp + 0xd8], rbp
00033819  498b8bd81f0000           mov rcx, qword ptr [r11 + 0x1fd8]
00033820  4c8bc5                   mov r8, rbp
00033823  4883f9ff                 cmp rcx, -1
00033827  4889942490000000         mov qword ptr [rsp + 0x90], rdx
0003382f  4a8d0409                 lea rax, [rcx + r9]
00033833  498b8be01f0000           mov rcx, qword ptr [r11 + 0x1fe0]
0003383a  4c0f45c0                 cmovne r8, rax
0003383e  4883f9ff                 cmp rcx, -1
00033842  4c89442478               mov qword ptr [rsp + 0x78], r8
00033847  4a8d0409                 lea rax, [rcx + r9]
0003384b  4c8bcd                   mov r9, rbp
0003384e  4c0f45c8                 cmovne r9, rax
00033852  418b4314                 mov eax, dword ptr [r11 + 0x14]
00033856  ffc8                     dec eax
00033858  498be9                   mov rbp, r9
0003385b  83f805                   cmp eax, 5
0003385e  0f876d010000             ja 0x339d1
00033864  4c8d1d95c7fcff           lea r11, [rip - 0x3386b]
0003386b  4898                     cdqe
0003386d  4889942490000000         mov qword ptr [rsp + 0x90], rdx
00033875  4c89442478               mov qword ptr [rsp + 0x78], r8
0003387a  418b8c8324450300         mov ecx, dword ptr [r11 + rax*4 + 0x34524]
00033882  4903cb                   add rcx, r11
00033885  ffe1                     jmp rcx
00033887  498bda                   mov rbx, r10
0003388a  4889942490000000         mov qword ptr [rsp + 0x90], rdx
00033892  4c89442478               mov qword ptr [rsp + 0x78], r8
00033897  e972010000               jmp 0x33a0e
0003389c  4889942490000000         mov qword ptr [rsp + 0x90], rdx
000338a4  4c89442478               mov qword ptr [rsp + 0x78], r8
000338a9  e9a8010000               jmp 0x33a56
000338ae  498bda                   mov rbx, r10
000338b1  4889942490000000         mov qword ptr [rsp + 0x90], rdx
000338b9  4c89442478               mov qword ptr [rsp + 0x78], r8
000338be  e9b5030000               jmp 0x33c78
000338c3  4889942490000000         mov qword ptr [rsp + 0x90], rdx
000338cb  4c89442478               mov qword ptr [rsp + 0x78], r8
000338d0  e9a2040000               jmp 0x33d77
000338d5  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
000338da  498bda                   mov rbx, r10
000338dd  4889942490000000         mov qword ptr [rsp + 0x90], rdx
000338e5  4c89442478               mov qword ptr [rsp + 0x78], r8
000338ea  488bf9                   mov rdi, rcx
000338ed  483b8c24a0000000         cmp rcx, qword ptr [rsp + 0xa0]
000338f5  754c                     jne 0x33943
000338f7  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
000338ff  488bcd                   mov rcx, rbp
00033902  ff9424e0000000           call qword ptr [rsp + 0xe0]
00033909  84c0                     test al, al
0003390b  0f8457090000             je 0x34268
00033911  48ff8424a0000000         inc qword ptr [rsp + 0xa0]
00033919  8b442454                 mov eax, dword ptr [rsp + 0x54]
0003391d  84c0                     test al, al
0003391f  741d                     je 0x3393e
00033921  4c3ba424a8000000         cmp r12, qword ptr [rsp + 0xa8]
00033929  7713                     ja 0x3393e
0003392b  807d0020                 cmp byte ptr [rbp], 0x20
0003392f  b900000000               mov ecx, 0
00033934  0fb6c0                   movzx eax, al
00033937  0f45c1                   cmovne eax, ecx
0003393a  88442454                 mov byte ptr [rsp + 0x54], al
0003393e  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
00033943  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
00033947  48ffc1                   inc rcx
0003394a  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
0003394e  418b5654                 mov edx, dword ptr [r14 + 0x54]
00033952  44896c2440               mov dword ptr [rsp + 0x40], r13d
00033957  48896c2438               mov qword ptr [rsp + 0x38], rbp
0003395c  48894c2460               mov qword ptr [rsp + 0x60], rcx
00033961  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033965  44896c2430               mov dword ptr [rsp + 0x30], r13d
0003396a  48895c2428               mov qword ptr [rsp + 0x28], rbx
0003396f  4c89742420               mov qword ptr [rsp + 0x20], r14
00033974  41ff5668                 call qword ptr [r14 + 0x68]
00033978  85c0                     test eax, eax
0003397a  0f844c080000             je 0x341cc
00033980  4983ec01                 sub r12, 1
00033984  0f8448090000             je 0x342d2
0003398a  48ff842480000000         inc qword ptr [rsp + 0x80]
00033992  488d4501                 lea rax, [rbp + 1]
00033996  48ff8c24a0000000         dec qword ptr [rsp + 0xa0]
0003399e  488bcf                   mov rcx, rdi
000339a1  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
000339a9  48894c2460               mov qword ptr [rsp + 0x60], rcx
000339ae  493bc1                   cmp rax, r9
000339b1  0f8306080000             jae 0x341bd
000339b7  488be8                   mov rbp, rax
000339ba  e92bffffff               jmp 0x338ea
000339bf  4889942490000000         mov qword ptr [rsp + 0x90], rdx
000339c7  4c89442478               mov qword ptr [rsp + 0x78], r8
000339cc  e957090000               jmp 0x34328
000339d1  33c9                     xor ecx, ecx
000339d3  488bd1                   mov rdx, rcx
000339d6  48898c2498000000         mov qword ptr [rsp + 0x98], rcx
000339de  c644245400               mov byte ptr [rsp + 0x54], 0
000339e3  85f6                     test esi, esi
000339e5  0f8e24090000             jle 0x3430f
000339eb  4d85ff                   test r15, r15
000339ee  744a                     je 0x33a3a
000339f0  0fb603                   movzx eax, byte ptr [rbx]
000339f3  413807                   cmp byte ptr [r15], al
000339f6  7542                     jne 0x33a3a
000339f8  4d85e4                   test r12, r12
000339fb  0f84580a0000             je 0x34459
00033a01  48ffc3                   inc rbx
00033a04  ffce                     dec esi
00033a06  85f6                     test esi, esi
00033a08  0f8e4b0a0000             jle 0x34459
00033a0e  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
00033a16  488d8c2408010000         lea rcx, [rsp + 0x108]
00033a1e  ff9424e0000000           call qword ptr [rsp + 0xe0]
00033a25  84c0                     test al, al
00033a27  754d                     jne 0x33a76
00033a29  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00033a31  44896a14                 mov dword ptr [rdx + 0x14], r13d
00033a35  e9a8000000               jmp 0x33ae2
00033a3a  0fb603                   movzx eax, byte ptr [rbx]
00033a3d  3c25                     cmp al, 0x25
00033a3f  0f8492010000             je 0x33bd7
00033a45  4d85e4                   test r12, r12
00033a48  0f840b0a0000             je 0x34459
00033a4e  3c5b                     cmp al, 0x5b
00033a50  0f848a010000             je 0x33be0
00033a56  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
00033a5e  488d8c2408010000         lea rcx, [rsp + 0x108]
00033a66  ff9424e0000000           call qword ptr [rsp + 0xe0]
00033a6d  84c0                     test al, al
00033a6f  7462                     je 0x33ad3
00033a71  803b5f                   cmp byte ptr [rbx], 0x5f
00033a74  743d                     je 0x33ab3
00033a76  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
00033a7a  488d842408010000         lea rax, [rsp + 0x108]
00033a82  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
00033a86  418b5654                 mov edx, dword ptr [r14 + 0x54]
00033a8a  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033a8e  44896c2440               mov dword ptr [rsp + 0x40], r13d
00033a93  4889442438               mov qword ptr [rsp + 0x38], rax
00033a98  44896c2430               mov dword ptr [rsp + 0x30], r13d
00033a9d  48895c2428               mov qword ptr [rsp + 0x28], rbx
00033aa2  4c89742420               mov qword ptr [rsp + 0x20], r14
00033aa7  41ff5668                 call qword ptr [r14 + 0x68]
00033aab  85c0                     test eax, eax
00033aad  0f85a6090000             jne 0x34459
00033ab3  49ffcc                   dec r12
00033ab6  498bd5                   mov rdx, r13
00033ab9  48ffc3                   inc rbx
00033abc  4889942498000000         mov qword ptr [rsp + 0x98], rdx
00033ac4  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
00033acc  ffce                     dec esi
00033ace  e910ffffff               jmp 0x339e3
00033ad3  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00033adb  c7421402000000           mov dword ptr [rdx + 0x14], 2
00033ae2  488b842498000000         mov rax, qword ptr [rsp + 0x98]
00033aea  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
00033af1  4c8b842490000000         mov r8, qword ptr [rsp + 0x90]
00033af9  48894220                 mov qword ptr [rdx + 0x20], rax
00033afd  8b442454                 mov eax, dword ptr [rsp + 0x54]
00033b01  884228                   mov byte ptr [rdx + 0x28], al
00033b04  488b8424a8000000         mov rax, qword ptr [rsp + 0xa8]
00033b0c  48894230                 mov qword ptr [rdx + 0x30], rax
00033b10  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
00033b18  48894238                 mov qword ptr [rdx + 0x38], rax
00033b1c  488b842480000000         mov rax, qword ptr [rsp + 0x80]
00033b24  48894240                 mov qword ptr [rdx + 0x40], rax
00033b28  8b442470                 mov eax, dword ptr [rsp + 0x70]
00033b2c  894248                   mov dword ptr [rdx + 0x48], eax
00033b2f  488b8424b0000000         mov rax, qword ptr [rsp + 0xb0]
00033b37  48894250                 mov qword ptr [rdx + 0x50], rax
00033b3b  488b442460               mov rax, qword ptr [rsp + 0x60]
00033b40  48894260                 mov qword ptr [rdx + 0x60], rax
00033b44  488b8424d0000000         mov rax, qword ptr [rsp + 0xd0]
00033b4c  48894268                 mov qword ptr [rdx + 0x68], rax
00033b50  8b842488000000           mov eax, dword ptr [rsp + 0x88]
00033b57  894270                   mov dword ptr [rdx + 0x70], eax
00033b5a  0fb6442450               movzx eax, byte ptr [rsp + 0x50]
00033b5f  884274                   mov byte ptr [rdx + 0x74], al
00033b62  488bc3                   mov rax, rbx
00033b65  482b8424b8000000         sub rax, qword ptr [rsp + 0xb8]
00033b6d  4885db                   test rbx, rbx
00033b70  897218                   mov dword ptr [rdx + 0x18], esi
00033b73  4c896208                 mov qword ptr [rdx + 8], r12
00033b77  480f44c1                 cmove rax, rcx
00033b7b  48897a58                 mov qword ptr [rdx + 0x58], rdi
00033b7f  488982c81f0000           mov qword ptr [rdx + 0x1fc8], rax
00033b86  498bc0                   mov rax, r8
00033b89  482b8424b8000000         sub rax, qword ptr [rsp + 0xb8]
00033b91  4d85c0                   test r8, r8
00033b94  4c8b442478               mov r8, qword ptr [rsp + 0x78]
00033b99  480f44c1                 cmove rax, rcx
00033b9d  488982d01f0000           mov qword ptr [rdx + 0x1fd0], rax
00033ba4  498bc0                   mov rax, r8
00033ba7  482b442468               sub rax, qword ptr [rsp + 0x68]
00033bac  4d85c0                   test r8, r8
00033baf  480f44c1                 cmove rax, rcx
00033bb3  488982d81f0000           mov qword ptr [rdx + 0x1fd8], rax
00033bba  488bc5                   mov rax, rbp
00033bbd  482b442468               sub rax, qword ptr [rsp + 0x68]
00033bc2  4885ed                   test rbp, rbp
00033bc5  480f44c1                 cmove rax, rcx
00033bc9  488982e01f0000           mov qword ptr [rdx + 0x1fe0], rax
00033bd0  32c0                     xor al, al
00033bd2  e9d1080000               jmp 0x344a8
00033bd7  413bf5                   cmp esi, r13d
00033bda  0f8493080000             je 0x34473
00033be0  4c8b9c24c8000000         mov r11, qword ptr [rsp + 0xc8]
00033be8  33c9                     xor ecx, ecx
00033bea  4d8bc5                   mov r8, r13
00033bed  4c89ac2480000000         mov qword ptr [rsp + 0x80], r13
00033bf5  48898c2490000000         mov qword ptr [rsp + 0x90], rcx
00033bfd  8bf9                     mov edi, ecx
00033bff  48894c2460               mov qword ptr [rsp + 0x60], rcx
00033c04  418b83c01f0000           mov eax, dword ptr [r11 + 0x1fc0]
00033c0b  48898c24a0000000         mov qword ptr [rsp + 0xa0], rcx
00033c13  48898c24a8000000         mov qword ptr [rsp + 0xa8], rcx
00033c1b  89b42488000000           mov dword ptr [rsp + 0x88], esi
00033c22  3bf0                     cmp esi, eax
00033c24  0f87d7080000             ja 0x34501
00033c2a  4d8b93b81f0000           mov r10, qword ptr [r11 + 0x1fb8]
00033c31  4c89542468               mov qword ptr [rsp + 0x68], r10
00033c36  498bea                   mov rbp, r10
00033c39  4d8d0c02                 lea r9, [r10 + rax]
00033c3d  4c898c24d8000000         mov qword ptr [rsp + 0xd8], r9
00033c45  85f6                     test esi, esi
00033c47  0f8e6c040000             jle 0x340b9
00033c4d  4d85ff                   test r15, r15
00033c50  0f840f010000             je 0x33d65
00033c56  0fb603                   movzx eax, byte ptr [rbx]
00033c59  413807                   cmp byte ptr [r15], al
00033c5c  0f8503010000             jne 0x33d65
00033c62  4d85e4                   test r12, r12
00033c65  0f8467060000             je 0x342d2
00033c6b  48ffc3                   inc rbx
00033c6e  ffce                     dec esi
00033c70  85f6                     test esi, esi
00033c72  0f8ee1070000             jle 0x34459
00033c78  488b442460               mov rax, qword ptr [rsp + 0x60]
00033c7d  483bc7                   cmp rax, rdi
00033c80  754f                     jne 0x33cd1
00033c82  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
00033c8a  488bcd                   mov rcx, rbp
00033c8d  ff9424e0000000           call qword ptr [rsp + 0xe0]
00033c94  84c0                     test al, al
00033c96  0f84a4050000             je 0x34240
00033c9c  8b442454                 mov eax, dword ptr [rsp + 0x54]
00033ca0  48ffc7                   inc rdi
00033ca3  4889bc24a0000000         mov qword ptr [rsp + 0xa0], rdi
00033cab  84c0                     test al, al
00033cad  741d                     je 0x33ccc
00033caf  4c3ba424a8000000         cmp r12, qword ptr [rsp + 0xa8]
00033cb7  7713                     ja 0x33ccc
00033cb9  807d0020                 cmp byte ptr [rbp], 0x20
00033cbd  b900000000               mov ecx, 0
00033cc2  0fb6c0                   movzx eax, al
00033cc5  0f45c1                   cmovne eax, ecx
00033cc8  89442454                 mov dword ptr [rsp + 0x54], eax
00033ccc  488b442460               mov rax, qword ptr [rsp + 0x60]
00033cd1  48ffc0                   inc rax
00033cd4  4889442460               mov qword ptr [rsp + 0x60], rax
00033cd9  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
00033cdd  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
00033ce1  418b5654                 mov edx, dword ptr [r14 + 0x54]
00033ce5  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033ce9  44896c2440               mov dword ptr [rsp + 0x40], r13d
00033cee  48896c2438               mov qword ptr [rsp + 0x38], rbp
00033cf3  44896c2430               mov dword ptr [rsp + 0x30], r13d
00033cf8  48895c2428               mov qword ptr [rsp + 0x28], rbx
00033cfd  4c89742420               mov qword ptr [rsp + 0x20], r14
00033d02  41ff5668                 call qword ptr [r14 + 0x68]
00033d06  85c0                     test eax, eax
00033d08  0f8599020000             jne 0x33fa7
00033d0e  488b942498000000         mov rdx, qword ptr [rsp + 0x98]
00033d16  4c8b842480000000         mov r8, qword ptr [rsp + 0x80]
00033d1e  4885d2                   test rdx, rdx
00033d21  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
00033d29  498bc0                   mov rax, r8
00033d2c  4c8b542468               mov r10, qword ptr [rsp + 0x68]
00033d31  480f45c2                 cmovne rax, rdx
00033d35  488bd0                   mov rdx, rax
00033d38  4889842498000000         mov qword ptr [rsp + 0x98], rax
00033d40  488d4501                 lea rax, [rbp + 1]
00033d44  493bc1                   cmp rax, r9
00033d47  0f83f7020000             jae 0x34044
00033d4d  49ffcc                   dec r12
00033d50  48ffc3                   inc rbx
00033d53  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
00033d5b  ffce                     dec esi
00033d5d  488be8                   mov rbp, rax
00033d60  e9e0feffff               jmp 0x33c45
00033d65  803b25                   cmp byte ptr [rbx], 0x25
00033d68  0f84f3020000             je 0x34061
00033d6e  4d85e4                   test r12, r12
00033d71  0f845b050000             je 0x342d2
00033d77  488b442460               mov rax, qword ptr [rsp + 0x60]
00033d7c  483bc7                   cmp rax, rdi
00033d7f  754f                     jne 0x33dd0
00033d81  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
00033d89  488bcd                   mov rcx, rbp
00033d8c  ff9424e0000000           call qword ptr [rsp + 0xe0]
00033d93  84c0                     test al, al
00033d95  0f84b9040000             je 0x34254
00033d9b  8b4c2454                 mov ecx, dword ptr [rsp + 0x54]
00033d9f  48ffc7                   inc rdi
00033da2  4889bc24a0000000         mov qword ptr [rsp + 0xa0], rdi
00033daa  84c9                     test cl, cl
00033dac  741d                     je 0x33dcb
00033dae  4c3ba424a8000000         cmp r12, qword ptr [rsp + 0xa8]
00033db6  7713                     ja 0x33dcb
00033db8  807d0020                 cmp byte ptr [rbp], 0x20
00033dbc  0fb6c1                   movzx eax, cl
00033dbf  b900000000               mov ecx, 0
00033dc4  0f45c1                   cmovne eax, ecx
00033dc7  88442454                 mov byte ptr [rsp + 0x54], al
00033dcb  488b442460               mov rax, qword ptr [rsp + 0x60]
00033dd0  48ffc0                   inc rax
00033dd3  4889442460               mov qword ptr [rsp + 0x60], rax
00033dd8  0fb603                   movzx eax, byte ptr [rbx]
00033ddb  3c5f                     cmp al, 0x5f
00033ddd  0f842bffffff             je 0x33d0e
00033de3  3c5b                     cmp al, 0x5b
00033de5  0f85eefeffff             jne 0x33cd9
00033deb  488d7b01                 lea rdi, [rbx + 1]
00033def  90                       nop
00033df0  48ffc3                   inc rbx
00033df3  ffce                     dec esi
00033df5  85f6                     test esi, esi
00033df7  0f8e5c060000             jle 0x34459
00033dfd  4d85ff                   test r15, r15
00033e00  7426                     je 0x33e28
00033e02  0fb603                   movzx eax, byte ptr [rbx]
00033e05  413807                   cmp byte ptr [r15], al
00033e08  751e                     jne 0x33e28
00033e0a  48ffc3                   inc rbx
00033e0d  ffce                     dec esi
00033e0f  85f6                     test esi, esi
00033e11  7fdd                     jg 0x33df0
00033e13  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00033e1b  32c0                     xor al, al
00033e1d  66c742100100             mov word ptr [rdx + 0x10], 1
00033e23  e980060000               jmp 0x344a8
00033e28  803b5d                   cmp byte ptr [rbx], 0x5d
00033e2b  75c3                     jne 0x33df0
00033e2d  32c9                     xor cl, cl
00033e2f  448beb                   mov r13d, ebx
00033e32  442bef                   sub r13d, edi
00033e35  884c2458                 mov byte ptr [rsp + 0x58], cl
00033e39  4585ed                   test r13d, r13d
00033e3c  0f8e47010000             jle 0x33f89
00033e42  803f5e                   cmp byte ptr [rdi], 0x5e
00033e45  7529                     jne 0x33e70
00033e47  4d85ff                   test r15, r15
00033e4a  7406                     je 0x33e52
00033e4c  41803f5e                 cmp byte ptr [r15], 0x5e
00033e50  741e                     je 0x33e70
00033e52  418d45ff                 lea eax, [r13 - 1]
00033e56  48ffc7                   inc rdi
00033e59  b101                     mov cl, 1
00033e5b  448be8                   mov r13d, eax
00033e5e  884c2458                 mov byte ptr [rsp + 0x58], cl
00033e62  85c0                     test eax, eax
00033e64  0f8e1f010000             jle 0x33f89
00033e6a  660f1f440000             nop word ptr [rax + rax]
00033e70  4d85ff                   test r15, r15
00033e73  740d                     je 0x33e82
00033e75  0fb607                   movzx eax, byte ptr [rdi]
00033e78  413807                   cmp byte ptr [r15], al
00033e7b  7505                     jne 0x33e82
00033e7d  41b401                   mov r12b, 1
00033e80  eb03                     jmp 0x33e85
00033e82  4532e4                   xor r12b, r12b
00033e85  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
00033e89  488d4701                 lea rax, [rdi + 1]
00033e8d  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
00033e91  b901000000               mov ecx, 1
00033e96  418b5654                 mov edx, dword ptr [r14 + 0x54]
00033e9a  4584e4                   test r12b, r12b
00033e9d  894c2440                 mov dword ptr [rsp + 0x40], ecx
00033ea1  480f44c7                 cmove rax, rdi
00033ea5  4889442438               mov qword ptr [rsp + 0x38], rax
00033eaa  894c2430                 mov dword ptr [rsp + 0x30], ecx
00033eae  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033eb2  48896c2428               mov qword ptr [rsp + 0x28], rbp
00033eb7  4c89742420               mov qword ptr [rsp + 0x20], r14
00033ebc  48898424f8000000         mov qword ptr [rsp + 0xf8], rax
00033ec4  41ff5668                 call qword ptr [r14 + 0x68]
00033ec8  4c8b8424f8000000         mov r8, qword ptr [rsp + 0xf8]
00033ed0  418d4dff                 lea ecx, [r13 - 1]
00033ed4  4584e4                   test r12b, r12b
00033ed7  8bd0                     mov edx, eax
00033ed9  410f44cd                 cmove ecx, r13d
00033edd  498d7801                 lea rdi, [r8 + 1]
00033ee1  448d69ff                 lea r13d, [rcx - 1]
00033ee5  4183fd01                 cmp r13d, 1
00033ee9  0f8e84000000             jle 0x33f73
00033eef  803f2d                   cmp byte ptr [rdi], 0x2d
00033ef2  757f                     jne 0x33f73
00033ef4  4d85ff                   test r15, r15
00033ef7  7406                     je 0x33eff
00033ef9  41803f2d                 cmp byte ptr [r15], 0x2d
00033efd  7474                     je 0x33f73
00033eff  458d65ff                 lea r12d, [r13 - 1]
00033f03  4d85ff                   test r15, r15
00033f06  740d                     je 0x33f15
00033f08  0fb64701                 movzx eax, byte ptr [rdi + 1]
00033f0c  413807                   cmp byte ptr [r15], al
00033f0f  7504                     jne 0x33f15
00033f11  b001                     mov al, 1
00033f13  eb02                     jmp 0x33f17
00033f15  32c0                     xor al, al
00033f17  84c0                     test al, al
00033f19  490f44f8                 cmove rdi, r8
00033f1d  4883c702                 add rdi, 2
00033f21  84c0                     test al, al
00033f23  450f44e5                 cmove r12d, r13d
00033f27  85d2                     test edx, edx
00033f29  783e                     js 0x33f69
00033f2b  0faee8                   lfence
00033f2e  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
00033f32  41bd01000000             mov r13d, 1
00033f38  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
00033f3c  418b5654                 mov edx, dword ptr [r14 + 0x54]
00033f40  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033f44  44896c2440               mov dword ptr [rsp + 0x40], r13d
00033f49  48897c2438               mov qword ptr [rsp + 0x38], rdi
00033f4e  44896c2430               mov dword ptr [rsp + 0x30], r13d
00033f53  48896c2428               mov qword ptr [rsp + 0x28], rbp
00033f58  4c89742420               mov qword ptr [rsp + 0x20], r14
00033f5d  41ff5668                 call qword ptr [r14 + 0x68]
00033f61  85c0                     test eax, eax
00033f63  0f8ec1000000             jle 0x3402a
00033f69  48ffc7                   inc rdi
00033f6c  458d6c24fe               lea r13d, [r12 - 2]
00033f71  eb08                     jmp 0x33f7b
00033f73  85d2                     test edx, edx
00033f75  0f84bc000000             je 0x34037
00033f7b  4585ed                   test r13d, r13d
00033f7e  0f8fecfeffff             jg 0x33e70
00033f84  0fb64c2458               movzx ecx, byte ptr [rsp + 0x58]
00033f89  41bd01000000             mov r13d, 1
00033f8f  4c8ba42480010000         mov r12, qword ptr [rsp + 0x180]
00033f97  488bbc24a0000000         mov rdi, qword ptr [rsp + 0xa0]
00033f9f  84c9                     test cl, cl
00033fa1  0f8567fdffff             jne 0x33d0e
00033fa7  488b942498000000         mov rdx, qword ptr [rsp + 0x98]
00033faf  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
00033fb7  4c8b842480000000         mov r8, qword ptr [rsp + 0x80]
00033fbf  4c8b542468               mov r10, qword ptr [rsp + 0x68]
00033fc4  8b442454                 mov eax, dword ptr [rsp + 0x54]
00033fc8  0fb68c24a8010000         movzx ecx, byte ptr [rsp + 0x1a8]
00033fd0  4c8b9c2490000000         mov r11, qword ptr [rsp + 0x90]
00033fd8  4d85db                   test r11, r11
00033fdb  0f8424030000             je 0x34305
00033fe1  488b9c24b0000000         mov rbx, qword ptr [rsp + 0xb0]
00033fe9  49ffc0                   inc r8
00033fec  4883fb01                 cmp rbx, 1
00033ff0  4c89842480000000         mov qword ptr [rsp + 0x80], r8
00033ff8  4c8b442478               mov r8, qword ptr [rsp + 0x78]
00033ffd  8bc3                     mov eax, ebx
00033fff  410f47c5                 cmova eax, r13d
00034003  8bc8                     mov ecx, eax
00034005  482bd9                   sub rbx, rcx
00034008  48899c24b0000000         mov qword ptr [rsp + 0xb0], rbx
00034010  4a8d1400                 lea rdx, [rax + r8]
00034014  493bd1                   cmp rdx, r9
00034017  0f8317010000             jae 0x34134
0003401d  4c8bc2                   mov r8, rdx
00034020  4889542478               mov qword ptr [rsp + 0x78], rdx
00034025  e918010000               jmp 0x34142
0003402a  0fb64c2458               movzx ecx, byte ptr [rsp + 0x58]
0003402f  4132cd                   xor cl, r13b
00034032  e958ffffff               jmp 0x33f8f
00034037  0fb64c2458               movzx ecx, byte ptr [rsp + 0x58]
0003403c  80f101                   xor cl, 1
0003403f  e945ffffff               jmp 0x33f89
00034044  412be9                   sub ebp, r9d
00034047  49ffcc                   dec r12
0003404a  ffc5                     inc ebp
0003404c  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
00034054  4903ea                   add rbp, r10
00034057  48ffc3                   inc rbx
0003405a  ffce                     dec esi
0003405c  e9e4fbffff               jmp 0x33c45
00034061  48ffc3                   inc rbx
00034064  83ee01                   sub esi, 1
00034067  0f8406040000             je 0x34473
0003406d  803b25                   cmp byte ptr [rbx], 0x25
00034070  74ef                     je 0x34061
00034072  0fb60b                   movzx ecx, byte ptr [rbx]
00034075  4533db                   xor r11d, r11d
00034078  418bfb                   mov edi, r11d
0003407b  4c899c24a0000000         mov qword ptr [rsp + 0xa0], r11
00034083  498bea                   mov rbp, r10
00034086  48899c2490000000         mov qword ptr [rsp + 0x90], rbx
0003408e  89742470                 mov dword ptr [rsp + 0x70], esi
00034092  8d41a5                   lea eax, [rcx - 0x5b]
00034095  a8fb                     test al, 0xfb
00034097  7415                     je 0x340ae
00034099  4d85ff                   test r15, r15
0003409c  7405                     je 0x340a3
0003409e  41380f                   cmp byte ptr [r15], cl
000340a1  740b                     je 0x340ae
000340a3  b001                     mov al, 1
000340a5  88442450                 mov byte ptr [rsp + 0x50], al
000340a9  e9d4000000               jmp 0x34182
000340ae  32c0                     xor al, al
000340b0  88442450                 mov byte ptr [rsp + 0x50], al
000340b4  e9c9000000               jmp 0x34182
000340b9  4d85e4                   test r12, r12
000340bc  0f84b1030000             je 0x34473
000340c2  0fb68c24a8010000         movzx ecx, byte ptr [rsp + 0x1a8]
000340ca  8b442454                 mov eax, dword ptr [rsp + 0x54]
000340ce  84c9                     test cl, cl
000340d0  0f84fafeffff             je 0x33fd0
000340d6  84c0                     test al, al
000340d8  0f85f2feffff             jne 0x33fd0
000340de  4883bc24e000000000       cmp qword ptr [rsp + 0xe0], 0
000340e7  7530                     jne 0x34119
000340e9  4c8b9c2400010000         mov r11, qword ptr [rsp + 0x100]
000340f1  498bcc                   mov rcx, r12
000340f4  498bc3                   mov rax, r11
000340f7  41803b20                 cmp byte ptr [r11], 0x20
000340fb  0f85c3feffff             jne 0x33fc4
00034101  488d4001                 lea rax, [rax + 1]
00034105  4883e901                 sub rcx, 1
00034109  0f8464030000             je 0x34473
0003410f  803820                   cmp byte ptr [rax], 0x20
00034112  74ed                     je 0x34101
00034114  e9abfeffff               jmp 0x33fc4
00034119  b001                     mov al, 1
0003411b  4c89a424a8000000         mov qword ptr [rsp + 0xa8], r12
00034123  89442454                 mov dword ptr [rsp + 0x54], eax
00034127  48899424c0000000         mov qword ptr [rsp + 0xc0], rdx
0003412f  e99cfeffff               jmp 0x33fd0
00034134  452bc1                   sub r8d, r9d
00034137  4403c0                   add r8d, eax
0003413a  4d03c2                   add r8, r10
0003413d  4c89442478               mov qword ptr [rsp + 0x78], r8
00034142  488b8424d0000000         mov rax, qword ptr [rsp + 0xd0]
0003414a  482bf9                   sub rdi, rcx
0003414d  8b742470                 mov esi, dword ptr [rsp + 0x70]
00034151  488bd0                   mov rdx, rax
00034154  4889842498000000         mov qword ptr [rsp + 0x98], rax
0003415c  498be8                   mov rbp, r8
0003415f  0fb6442450               movzx eax, byte ptr [rsp + 0x50]
00034164  4c8be3                   mov r12, rbx
00034167  4c8b842480000000         mov r8, qword ptr [rsp + 0x80]
0003416f  48899c2480010000         mov qword ptr [rsp + 0x180], rbx
00034177  498bdb                   mov rbx, r11
0003417a  4889bc24a0000000         mov qword ptr [rsp + 0xa0], rdi
00034182  4d85e4                   test r12, r12
00034185  0f8447010000             je 0x342d2
0003418b  4533db                   xor r11d, r11d
0003418e  48899424d0000000         mov qword ptr [rsp + 0xd0], rdx
00034196  418bcb                   mov ecx, r11d
00034199  48894c2460               mov qword ptr [rsp + 0x60], rcx
0003419e  84c0                     test al, al
000341a0  0f8544f7ffff             jne 0x338ea
000341a6  48896c2478               mov qword ptr [rsp + 0x78], rbp
000341ab  4c89a424b0000000         mov qword ptr [rsp + 0xb0], r12
000341b3  4c895c2460               mov qword ptr [rsp + 0x60], r11
000341b8  e988faffff               jmp 0x33c45
000341bd  412be9                   sub ebp, r9d
000341c0  ffc5                     inc ebp
000341c2  48036c2468               add rbp, qword ptr [rsp + 0x68]
000341c7  e91ef7ffff               jmp 0x338ea
000341cc  488b942498000000         mov rdx, qword ptr [rsp + 0x98]
000341d4  4c8bc5                   mov r8, rbp
000341d7  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
000341df  4885d2                   test rdx, rdx
000341e2  4c8b542468               mov r10, qword ptr [rsp + 0x68]
000341e7  480f44942480000000       cmove rdx, qword ptr [rsp + 0x80]
000341f0  48896c2478               mov qword ptr [rsp + 0x78], rbp
000341f5  48ffc5                   inc rbp
000341f8  4c89a424b0000000         mov qword ptr [rsp + 0xb0], r12
00034200  4889942498000000         mov qword ptr [rsp + 0x98], rdx
00034208  493be9                   cmp rbp, r9
0003420b  720e                     jb 0x3421b
0003420d  498be8                   mov rbp, r8
00034210  492be9                   sub rbp, r9
00034213  48ffc5                   inc rbp
00034216  8bed                     mov ebp, ebp
00034218  4903ea                   add rbp, r10
0003421b  488bbc24a0000000         mov rdi, qword ptr [rsp + 0xa0]
00034223  49ffcc                   dec r12
00034226  4c8b842480000000         mov r8, qword ptr [rsp + 0x80]
0003422e  48ffc3                   inc rbx
00034231  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
00034239  ffce                     dec esi
0003423b  e905faffff               jmp 0x33c45
00034240  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00034248  c7421403000000           mov dword ptr [rdx + 0x14], 3
0003424f  e911010000               jmp 0x34365
00034254  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
0003425c  c7421404000000           mov dword ptr [rdx + 0x14], 4
00034263  e9fd000000               jmp 0x34365
00034268  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00034270  488b842498000000         mov rax, qword ptr [rsp + 0x98]
00034278  48894220                 mov qword ptr [rdx + 0x20], rax
0003427c  8b442454                 mov eax, dword ptr [rsp + 0x54]
00034280  884228                   mov byte ptr [rdx + 0x28], al
00034283  488b8424a8000000         mov rax, qword ptr [rsp + 0xa8]
0003428b  48894230                 mov qword ptr [rdx + 0x30], rax
0003428f  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
00034297  48894238                 mov qword ptr [rdx + 0x38], rax
0003429b  488b842480000000         mov rax, qword ptr [rsp + 0x80]
000342a3  48894240                 mov qword ptr [rdx + 0x40], rax
000342a7  8b442470                 mov eax, dword ptr [rsp + 0x70]
000342ab  894248                   mov dword ptr [rdx + 0x48], eax
000342ae  488b8424b0000000         mov rax, qword ptr [rsp + 0xb0]
000342b6  48894250                 mov qword ptr [rdx + 0x50], rax
000342ba  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
000342c2  48894258                 mov qword ptr [rdx + 0x58], rax
000342c6  c7421405000000           mov dword ptr [rdx + 0x14], 5
000342cd  e9e1000000               jmp 0x343b3
000342d2  807c245400               cmp byte ptr [rsp + 0x54], 0
000342d7  0f847c010000             je 0x34459
000342dd  488b8c24f0000000         mov rcx, qword ptr [rsp + 0xf0]
000342e5  4885c9                   test rcx, rcx
000342e8  0f84aa010000             je 0x34498
000342ee  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
000342f6  4885c0                   test rax, rax
000342f9  4c0f45e8                 cmovne r13, rax
000342fd  4c8929                   mov qword ptr [rcx], r13
00034300  e993010000               jmp 0x34498
00034305  84c0                     test al, al
00034307  0f844c010000             je 0x34459
0003430d  eb08                     jmp 0x34317
0003430f  0fb68c24a8010000         movzx ecx, byte ptr [rsp + 0x1a8]
00034317  84c9                     test cl, cl
00034319  0f8435010000             je 0x34454
0003431f  4d85e4                   test r12, r12
00034322  0f8443010000             je 0x3446b
00034328  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
00034330  488d8c240c010000         lea rcx, [rsp + 0x10c]
00034338  ff9424e0000000           call qword ptr [rsp + 0xe0]
0003433f  84c0                     test al, al
00034341  7413                     je 0x34356
00034343  80bc240c01000020         cmp byte ptr [rsp + 0x10c], 0x20
0003434b  0f8508010000             jne 0x34459
00034351  49ffcc                   dec r12
00034354  ebc9                     jmp 0x3431f
00034356  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
0003435e  c7421406000000           mov dword ptr [rdx + 0x14], 6
00034365  488b842498000000         mov rax, qword ptr [rsp + 0x98]
0003436d  48894220                 mov qword ptr [rdx + 0x20], rax
00034371  8b442454                 mov eax, dword ptr [rsp + 0x54]
00034375  884228                   mov byte ptr [rdx + 0x28], al
00034378  488b8424a8000000         mov rax, qword ptr [rsp + 0xa8]
00034380  48894230                 mov qword ptr [rdx + 0x30], rax
00034384  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
0003438c  48894238                 mov qword ptr [rdx + 0x38], rax
00034390  488b842480000000         mov rax, qword ptr [rsp + 0x80]
00034398  48894240                 mov qword ptr [rdx + 0x40], rax
0003439c  8b442470                 mov eax, dword ptr [rsp + 0x70]
000343a0  894248                   mov dword ptr [rdx + 0x48], eax
000343a3  488b8424b0000000         mov rax, qword ptr [rsp + 0xb0]
000343ab  48894250                 mov qword ptr [rdx + 0x50], rax
000343af  48897a58                 mov qword ptr [rdx + 0x58], rdi
000343b3  488b442460               mov rax, qword ptr [rsp + 0x60]
000343b8  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
000343bf  4c8b8c24b8000000         mov r9, qword ptr [rsp + 0xb8]
000343c7  48894260                 mov qword ptr [rdx + 0x60], rax
000343cb  488b8424d0000000         mov rax, qword ptr [rsp + 0xd0]
000343d3  48894268                 mov qword ptr [rdx + 0x68], rax
000343d7  8b842488000000           mov eax, dword ptr [rsp + 0x88]
000343de  894270                   mov dword ptr [rdx + 0x70], eax
000343e1  0fb6442450               movzx eax, byte ptr [rsp + 0x50]
000343e6  884274                   mov byte ptr [rdx + 0x74], al
000343e9  4c896208                 mov qword ptr [rdx + 8], r12
000343ed  897218                   mov dword ptr [rdx + 0x18], esi
000343f0  4885db                   test rbx, rbx
000343f3  7505                     jne 0x343fa
000343f5  488bd9                   mov rbx, rcx
000343f8  eb03                     jmp 0x343fd
000343fa  492bd9                   sub rbx, r9
000343fd  488b842490000000         mov rax, qword ptr [rsp + 0x90]
00034405  48899ac81f0000           mov qword ptr [rdx + 0x1fc8], rbx
0003440c  4885c0                   test rax, rax
0003440f  7505                     jne 0x34416
00034411  488bc1                   mov rax, rcx
00034414  eb03                     jmp 0x34419
00034416  492bc1                   sub rax, r9
00034419  4c8b442468               mov r8, qword ptr [rsp + 0x68]
0003441e  488982d01f0000           mov qword ptr [rdx + 0x1fd0], rax
00034425  488b442478               mov rax, qword ptr [rsp + 0x78]
0003442a  4885c0                   test rax, rax
0003442d  7505                     jne 0x34434
0003442f  488bc1                   mov rax, rcx
00034432  eb03                     jmp 0x34437
00034434  492bc0                   sub rax, r8
00034437  488982d81f0000           mov qword ptr [rdx + 0x1fd8], rax
0003443e  4885ed                   test rbp, rbp
00034441  7406                     je 0x34449
00034443  488bcd                   mov rcx, rbp
00034446  492bc8                   sub rcx, r8
00034449  48898ae01f0000           mov qword ptr [rdx + 0x1fe0], rcx
00034450  32c0                     xor al, al
00034452  eb54                     jmp 0x344a8
00034454  4d85e4                   test r12, r12
00034457  741a                     je 0x34473
00034459  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00034461  32c0                     xor al, al
00034463  66c742100100             mov word ptr [rdx + 0x10], 1
00034469  eb3d                     jmp 0x344a8
0003446b  488b942498000000         mov rdx, qword ptr [rsp + 0x98]
00034473  488b8c24f0000000         mov rcx, qword ptr [rsp + 0xf0]
0003447b  4885c9                   test rcx, rcx
0003447e  7418                     je 0x34498
00034480  807c245400               cmp byte ptr [rsp + 0x54], 0
00034485  480f459424c0000000       cmovne rdx, qword ptr [rsp + 0xc0]
0003448e  4885d2                   test rdx, rdx
00034491  490f44d5                 cmove rdx, r13
00034495  488911                   mov qword ptr [rcx], rdx
00034498  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
000344a0  b001                     mov al, 1
000344a2  66c742100101             mov word ptr [rdx + 0x10], 0x101
000344a8  4c8ba42428010000         mov r12, qword ptr [rsp + 0x128]
000344b0  488bbc2430010000         mov rdi, qword ptr [rsp + 0x130]
000344b8  488bac2478010000         mov rbp, qword ptr [rsp + 0x178]
000344c0  4c8bac2420010000         mov r13, qword ptr [rsp + 0x120]
000344c8  488b8c2410010000         mov rcx, qword ptr [rsp + 0x110]
000344d0  4833cc                   xor rcx, rsp
000344d3  e8f8880200               call 0x5cdd0
000344d8  4881c438010000           add rsp, 0x138
000344df  415f                     pop r15
000344e1  415e                     pop r14
000344e3  5e                       pop rsi
000344e4  5b                       pop rbx
000344e5  c3                       ret

; chunk at RVA 0x344e6 (27 bytes)
000344e6  ba4b000000               mov edx, 0x4b
000344eb  4489442420               mov dword ptr [rsp + 0x20], r8d
000344f0  8d4ad0                   lea ecx, [rdx - 0x30]
000344f3  448d4ab6                 lea r9d, [rdx - 0x4a]
000344f7  448d42c5                 lea r8d, [rdx - 0x3b]
000344fb  e8a04efeff               call 0x193a0
00034500  cc                       int3

; chunk at RVA 0x34501 (59 bytes)
00034501  48894c2420               mov qword ptr [rsp + 0x20], rcx
00034506  4c8d05c3a80600           lea r8, [rip + 0x6a8c3]
0003450d  418bcd                   mov ecx, r13d
00034510  488d1511b50600           lea rdx, [rip + 0x6b511]
00034517  41b9d8040000             mov r9d, 0x4d8
0003451d  e85e4efeff               call 0x19380
00034522  cc                       int3
00034523  90                       nop
00034524  8738                     xchg dword ptr [rax], edi
00034526  0300                     add eax, dword ptr [rax]
00034528  9c                       pushfq
00034529  3803                     cmp byte ptr [rbx], al
0003452b  00ae380300c3             add byte ptr [rsi - 0x3cfffcc8], ch
00034531  3803                     cmp byte ptr [rbx], al
00034533  00d5                     add ch, dl
00034535  3803                     cmp byte ptr [rbx], al
