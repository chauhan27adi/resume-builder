; std::unique_ptr<CAEStreamDecryptionProvider,MemObjDeleter>::~unique_ptr<CAEStreamDecryptionProvider,MemObjDeleter>
; aetm_enclave.dll, primary RVA 0x17320, 102 bytes in 1 chunk(s)

; chunk at RVA 0x17320 (102 bytes)
00017320  4057                     push rdi
00017322  4883ec30                 sub rsp, 0x30
00017326  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0001732f  48895c2440               mov qword ptr [rsp + 0x40], rbx
00017334  488bf9                   mov rdi, rcx
00017337  488b5908                 mov rbx, qword ptr [rcx + 8]
0001733b  4885db                   test rbx, rbx
0001733e  743b                     je 0x1737b
00017340  488b8b98000000           mov rcx, qword ptr [rbx + 0x98]
00017347  4885c9                   test rcx, rcx
0001734a  740b                     je 0x17357
0001734c  488b01                   mov rax, qword ptr [rcx]
0001734f  ba01000000               mov edx, 1
00017354  ff5010                   call qword ptr [rax + 0x10]
00017357  488b8b90000000           mov rcx, qword ptr [rbx + 0x90]
0001735e  4885c9                   test rcx, rcx
00017361  740b                     je 0x1736e
00017363  488b01                   mov rax, qword ptr [rcx]
00017366  ba01000000               mov edx, 1
0001736b  ff5010                   call qword ptr [rax + 0x10]
0001736e  488b0f                   mov rcx, qword ptr [rdi]
00017371  488b01                   mov rax, qword ptr [rcx]
00017374  488bd3                   mov rdx, rbx
00017377  ff5028                   call qword ptr [rax + 0x28]
0001737a  90                       nop
0001737b  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00017380  4883c430                 add rsp, 0x30
00017384  5f                       pop rdi
00017385  c3                       ret
