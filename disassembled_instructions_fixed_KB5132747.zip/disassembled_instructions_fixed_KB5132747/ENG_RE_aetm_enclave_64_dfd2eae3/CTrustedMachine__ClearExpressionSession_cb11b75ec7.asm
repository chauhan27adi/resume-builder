; CTrustedMachine::ClearExpressionSession
; aetm_enclave.dll, primary RVA 0xbcb0, 784 bytes in 1 chunk(s)

; chunk at RVA 0xbcb0 (784 bytes)
0000bcb0  48895c2410               mov qword ptr [rsp + 0x10], rbx
0000bcb5  48894c2408               mov qword ptr [rsp + 8], rcx
0000bcba  55                       push rbp
0000bcbb  56                       push rsi
0000bcbc  57                       push rdi
0000bcbd  4154                     push r12
0000bcbf  4155                     push r13
0000bcc1  4156                     push r14
0000bcc3  4157                     push r15
0000bcc5  4883ec20                 sub rsp, 0x20
0000bcc9  488be9                   mov rbp, rcx
0000bccc  488d7920                 lea rdi, [rcx + 0x20]
0000bcd0  90                       nop
0000bcd1  4c8bf2                   mov r14, rdx
0000bcd4  488bcf                   mov rcx, rdi
0000bcd7  0fb64548                 movzx eax, byte ptr [rbp + 0x48]
0000bcdb  488d9d20300000           lea rbx, [rbp + 0x3020]
0000bce2  483bfb                   cmp rdi, rbx
0000bce5  7312                     jae 0xbcf9
0000bce7  84c0                     test al, al
0000bce9  750e                     jne 0xbcf9
0000bceb  4883c130                 add rcx, 0x30
0000bcef  90                       nop
0000bcf0  0fb64128                 movzx eax, byte ptr [rcx + 0x28]
0000bcf4  483bcb                   cmp rcx, rbx
0000bcf7  72ee                     jb 0xbce7
0000bcf9  48bdabaaaaaaaaaaaaaa     movabs rbp, 0xaaaaaaaaaaaaaaab
0000bd03  49bc00000000ffffffff     movabs r12, 0xffffffff00000000
0000bd0d  49bd0000000001000000     movabs r13, 0x100000000
0000bd17  660f1f840000000000       nop word ptr [rax + rax]
0000bd20  90                       nop
0000bd21  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000bd25  90                       nop
0000bd26  488bf1                   mov rsi, rcx
0000bd29  483bcb                   cmp rcx, rbx
0000bd2c  0f84e9000000             je 0xbe1b
0000bd32  0fb64128                 movzx eax, byte ptr [rcx + 0x28]
0000bd36  488bd1                   mov rdx, rcx
0000bd39  90                       nop
0000bd3a  482bd7                   sub rdx, rdi
0000bd3d  488b4120                 mov rax, qword ptr [rcx + 0x20]
0000bd41  90                       nop
0000bd42  48c1e820                 shr rax, 0x20
0000bd46  48c1fa04                 sar rdx, 4
0000bd4a  480fafd5                 imul rdx, rbp
0000bd4e  4c63c2                   movsxd r8, edx
0000bd51  49c1e020                 shl r8, 0x20
0000bd55  4c0bc0                   or r8, rax
0000bd58  498bc0                   mov rax, r8
0000bd5b  48c1e820                 shr rax, 0x20
0000bd5f  440fb6c8                 movzx r9d, al
0000bd63  4c8bd0                   mov r10, rax
0000bd66  4b8d0449                 lea rax, [r9 + r9*2]
0000bd6a  4803c0                   add rax, rax
0000bd6d  0fb654c729               movzx edx, byte ptr [rdi + rax*8 + 0x29]
0000bd72  90                       nop
0000bd73  488b44c720               mov rax, qword ptr [rdi + rax*8 + 0x20]
0000bd78  48c1e820                 shr rax, 0x20
0000bd7c  413bc0                   cmp eax, r8d
0000bd7f  7565                     jne 0xbde6
0000bd81  84d2                     test dl, dl
0000bd83  7461                     je 0xbde6
0000bd85  410fb6c2                 movzx eax, r10b
0000bd89  90                       nop
0000bd8a  4c8d0440                 lea r8, [rax + rax*2]
0000bd8e  49c1e004                 shl r8, 4
0000bd92  4c03c7                   add r8, rdi
0000bd95  498b4020                 mov rax, qword ptr [r8 + 0x20]
0000bd99  85c0                     test eax, eax
0000bd9b  7549                     jne 0xbde6
0000bd9d  488bd0                   mov rdx, rax
0000bda0  4923d4                   and rdx, r12
0000bda3  4903d5                   add rdx, r13
0000bda6  f0490fb15020             lock cmpxchg qword ptr [r8 + 0x20], rdx
0000bdac  7538                     jne 0xbde6
0000bdae  41c6402800               mov byte ptr [r8 + 0x28], 0
0000bdb3  41c6402900               mov byte ptr [r8 + 0x29], 0
0000bdb8  90                       nop
0000bdb9  498b4020                 mov rax, qword ptr [r8 + 0x20]
0000bdbd  48c1e820                 shr rax, 0x20
0000bdc1  83f8ff                   cmp eax, -1
0000bdc4  7415                     je 0xbddb
0000bdc6  48638700340000           movsxd rax, dword ptr [rdi + 0x3400]
0000bdcd  44898c8700300000         mov dword ptr [rdi + rax*4 + 0x3000], r9d
0000bdd5  ff8700340000             inc dword ptr [rdi + 0x3400]
0000bddb  4c397110                 cmp qword ptr [rcx + 0x10], r14
0000bddf  7505                     jne 0xbde6
0000bde1  e89afdffff               call 0xbb80
0000bde6  483bf3                   cmp rsi, rbx
0000bde9  488d4e30                 lea rcx, [rsi + 0x30]
0000bded  90                       nop
0000bdee  480f43ce                 cmovae rcx, rsi
0000bdf2  0fb64128                 movzx eax, byte ptr [rcx + 0x28]
0000bdf6  483bcb                   cmp rcx, rbx
0000bdf9  0f8321ffffff             jae 0xbd20
0000bdff  90                       nop
0000be00  84c0                     test al, al
0000be02  0f8518ffffff             jne 0xbd20
0000be08  4883c130                 add rcx, 0x30
0000be0c  90                       nop
0000be0d  0fb64128                 movzx eax, byte ptr [rcx + 0x28]
0000be11  483bcb                   cmp rcx, rbx
0000be14  72ea                     jb 0xbe00
0000be16  e905ffffff               jmp 0xbd20
0000be1b  488b6c2460               mov rbp, qword ptr [rsp + 0x60]
0000be20  0fb68550340000           movzx eax, byte ptr [rbp + 0x3450]
0000be27  488db528340000           lea rsi, [rbp + 0x3428]
0000be2e  488dbd283a0000           lea rdi, [rbp + 0x3a28]
0000be35  488bde                   mov rbx, rsi
0000be38  483bf7                   cmp rsi, rdi
0000be3b  7315                     jae 0xbe52
0000be3d  0f1f00                   nop dword ptr [rax]
0000be40  84c0                     test al, al
0000be42  750e                     jne 0xbe52
0000be44  4883c330                 add rbx, 0x30
0000be48  90                       nop
0000be49  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000be4d  483bdf                   cmp rbx, rdi
0000be50  72ee                     jb 0xbe40
0000be52  4533ff                   xor r15d, r15d
0000be55  90                       nop
0000be56  0fb64728                 movzx eax, byte ptr [rdi + 0x28]
0000be5a  488beb                   mov rbp, rbx
0000be5d  483bdf                   cmp rbx, rdi
0000be60  0f8445010000             je 0xbfab
0000be66  488b4b08                 mov rcx, qword ptr [rbx + 8]
0000be6a  4c8d7308                 lea r14, [rbx + 8]
0000be6e  4885c9                   test rcx, rcx
0000be71  7412                     je 0xbe85
0000be73  4d85f6                   test r14, r14
0000be76  740d                     je 0xbe85
0000be78  488b01                   mov rax, qword ptr [rcx]
0000be7b  ba01000000               mov edx, 1
0000be80  ff10                     call qword ptr [rax]
0000be82  4d893e                   mov qword ptr [r14], r15
0000be85  488b0b                   mov rcx, qword ptr [rbx]
0000be88  4885c9                   test rcx, rcx
0000be8b  740b                     je 0xbe98
0000be8d  488b01                   mov rax, qword ptr [rcx]
0000be90  ba01000000               mov edx, 1
0000be95  ff5028                   call qword ptr [rax + 0x28]
0000be98  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0000be9c  4885c9                   test rcx, rcx
0000be9f  740a                     je 0xbeab
0000bea1  bae81f0000               mov edx, 0x1fe8
0000bea6  e8a5100500               call 0x5cf50
0000beab  4c893b                   mov qword ptr [rbx], r15
0000beae  488bcb                   mov rcx, rbx
0000beb1  4d893e                   mov qword ptr [r14], r15
0000beb4  482bce                   sub rcx, rsi
0000beb7  48c74310ffffffff         mov qword ptr [rbx + 0x10], 0xffffffffffffffff
0000bebf  4c897b18                 mov qword ptr [rbx + 0x18], r15
0000bec3  90                       nop
0000bec4  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000bec8  90                       nop
0000bec9  48c1f904                 sar rcx, 4
0000becd  48b8abaaaaaaaaaaaaaa     movabs rax, 0xaaaaaaaaaaaaaaab
0000bed7  480fafc8                 imul rcx, rax
0000bedb  488b4320                 mov rax, qword ptr [rbx + 0x20]
0000bedf  90                       nop
0000bee0  48c1e820                 shr rax, 0x20
0000bee4  4863d1                   movsxd rdx, ecx
0000bee7  48c1e220                 shl rdx, 0x20
0000beeb  480bd0                   or rdx, rax
0000beee  488bc2                   mov rax, rdx
0000bef1  48c1e820                 shr rax, 0x20
0000bef5  8bc8                     mov ecx, eax
0000bef7  83e01f                   and eax, 0x1f
0000befa  448bc8                   mov r9d, eax
0000befd  488d0440                 lea rax, [rax + rax*2]
0000bf01  4803c0                   add rax, rax
0000bf04  440fb644c629             movzx r8d, byte ptr [rsi + rax*8 + 0x29]
0000bf0a  90                       nop
0000bf0b  488b44c620               mov rax, qword ptr [rsi + rax*8 + 0x20]
0000bf10  48c1e820                 shr rax, 0x20
0000bf14  3bc2                     cmp eax, edx
0000bf16  7558                     jne 0xbf70
0000bf18  4584c0                   test r8b, r8b
0000bf1b  7453                     je 0xbf70
0000bf1d  83e11f                   and ecx, 0x1f
0000bf20  90                       nop
0000bf21  488d1449                 lea rdx, [rcx + rcx*2]
0000bf25  48c1e204                 shl rdx, 4
0000bf29  4803d6                   add rdx, rsi
0000bf2c  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000bf30  85c0                     test eax, eax
0000bf32  753c                     jne 0xbf70
0000bf34  488bc8                   mov rcx, rax
0000bf37  4923cc                   and rcx, r12
0000bf3a  4903cd                   add rcx, r13
0000bf3d  f0480fb14a20             lock cmpxchg qword ptr [rdx + 0x20], rcx
0000bf43  752b                     jne 0xbf70
0000bf45  44887a28                 mov byte ptr [rdx + 0x28], r15b
0000bf49  44887a29                 mov byte ptr [rdx + 0x29], r15b
0000bf4d  90                       nop
0000bf4e  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000bf52  48c1e820                 shr rax, 0x20
0000bf56  83f8ff                   cmp eax, -1
0000bf59  7415                     je 0xbf70
0000bf5b  48638680060000           movsxd rax, dword ptr [rsi + 0x680]
0000bf62  44898c8600060000         mov dword ptr [rsi + rax*4 + 0x600], r9d
0000bf6a  ff8680060000             inc dword ptr [rsi + 0x680]
0000bf70  4883c330                 add rbx, 0x30
0000bf74  90                       nop
0000bf75  483bef                   cmp rbp, rdi
0000bf78  480f43dd                 cmovae rbx, rbp
0000bf7c  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000bf80  483bdf                   cmp rbx, rdi
0000bf83  0f83ccfeffff             jae 0xbe55
0000bf89  0f1f8000000000           nop dword ptr [rax]
0000bf90  84c0                     test al, al
0000bf92  0f85bdfeffff             jne 0xbe55
0000bf98  4883c330                 add rbx, 0x30
0000bf9c  90                       nop
0000bf9d  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000bfa1  483bdf                   cmp rbx, rdi
0000bfa4  72ea                     jb 0xbf90
0000bfa6  e9aafeffff               jmp 0xbe55
0000bfab  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0000bfb0  4883c420                 add rsp, 0x20
0000bfb4  415f                     pop r15
0000bfb6  415e                     pop r14
0000bfb8  415d                     pop r13
0000bfba  415c                     pop r12
0000bfbc  5f                       pop rdi
0000bfbd  5e                       pop rsi
0000bfbe  5d                       pop rbp
0000bfbf  c3                       ret
