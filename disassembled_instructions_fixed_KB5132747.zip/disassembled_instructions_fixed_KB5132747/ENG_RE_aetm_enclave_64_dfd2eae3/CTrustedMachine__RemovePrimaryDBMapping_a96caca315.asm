; CTrustedMachine::RemovePrimaryDBMapping
; aetm_enclave.dll, primary RVA 0xd7f0, 361 bytes in 1 chunk(s)

; chunk at RVA 0xd7f0 (361 bytes)
0000d7f0  48895c2410               mov qword ptr [rsp + 0x10], rbx
0000d7f5  48896c2418               mov qword ptr [rsp + 0x18], rbp
0000d7fa  4889742420               mov qword ptr [rsp + 0x20], rsi
0000d7ff  57                       push rdi
0000d800  4883ec20                 sub rsp, 0x20
0000d804  488db9d87a5800           lea rdi, [rcx + 0x587ad8]
0000d80b  90                       nop
0000d80c  440fb681e87a5800         movzx r8d, byte ptr [rcx + 0x587ae8]
0000d814  4c8d89d8aa5800           lea r9, [rcx + 0x58aad8]
0000d81b  8bf2                     mov esi, edx
0000d81d  488bd9                   mov rbx, rcx
0000d820  488bc7                   mov rax, rdi
0000d823  493bf9                   cmp rdi, r9
0000d826  7314                     jae 0xd83c
0000d828  4584c0                   test r8b, r8b
0000d82b  750f                     jne 0xd83c
0000d82d  4883c018                 add rax, 0x18
0000d831  90                       nop
0000d832  440fb64010               movzx r8d, byte ptr [rax + 0x10]
0000d837  493bc1                   cmp rax, r9
0000d83a  72ec                     jb 0xd828
0000d83c  48bdabaaaaaaaaaaaaaa     movabs rbp, 0xaaaaaaaaaaaaaaab
0000d846  66660f1f840000000000     nop word ptr [rax + rax]
0000d850  90                       nop
0000d851  410fb64910               movzx ecx, byte ptr [r9 + 0x10]
0000d856  4c8bd0                   mov r10, rax
0000d859  493bc1                   cmp rax, r9
0000d85c  0f84e2000000             je 0xd944
0000d862  90                       nop
0000d863  488bd0                   mov rdx, rax
0000d866  0fb64810                 movzx ecx, byte ptr [rax + 0x10]
0000d86a  482bd7                   sub rdx, rdi
0000d86d  48c1fa03                 sar rdx, 3
0000d871  90                       nop
0000d872  488b4808                 mov rcx, qword ptr [rax + 8]
0000d876  480fafd5                 imul rdx, rbp
0000d87a  48c1e920                 shr rcx, 0x20
0000d87e  4c63c2                   movsxd r8, edx
0000d881  49c1e020                 shl r8, 0x20
0000d885  4c0bc1                   or r8, rcx
0000d888  4c89442430               mov qword ptr [rsp + 0x30], r8
0000d88d  49c1e820                 shr r8, 0x20
0000d891  0faee8                   lfence
0000d894  498bc8                   mov rcx, r8
0000d897  81e1ff010000             and ecx, 0x1ff
0000d89d  488d0c49                 lea rcx, [rcx + rcx*2]
0000d8a1  488d14cb                 lea rdx, [rbx + rcx*8]
0000d8a5  f048ff82e07a5800         lock inc qword ptr [rdx + 0x587ae0]
0000d8ad  4181e0ff010000           and r8d, 0x1ff
0000d8b4  90                       nop
0000d8b5  4b8d0c40                 lea rcx, [r8 + r8*2]
0000d8b9  440fb65ccf10             movzx r11d, byte ptr [rdi + rcx*8 + 0x10]
0000d8bf  90                       nop
0000d8c0  488b4ccf08               mov rcx, qword ptr [rdi + rcx*8 + 8]
0000d8c5  4c8b442430               mov r8, qword ptr [rsp + 0x30]
0000d8ca  48c1e920                 shr rcx, 0x20
0000d8ce  413bc8                   cmp ecx, r8d
0000d8d1  750a                     jne 0xd8dd
0000d8d3  4584db                   test r11b, r11b
0000d8d6  7405                     je 0xd8dd
0000d8d8  397004                   cmp dword ptr [rax + 4], esi
0000d8db  743f                     je 0xd91c
0000d8dd  0faee8                   lfence
0000d8e0  f048ff8ae07a5800         lock dec qword ptr [rdx + 0x587ae0]
0000d8e8  4883c018                 add rax, 0x18
0000d8ec  4d3bd1                   cmp r10, r9
0000d8ef  90                       nop
0000d8f0  490f43c2                 cmovae rax, r10
0000d8f4  0fb64810                 movzx ecx, byte ptr [rax + 0x10]
0000d8f8  493bc1                   cmp rax, r9
0000d8fb  0f834fffffff             jae 0xd850
0000d901  84c9                     test cl, cl
0000d903  0f8547ffffff             jne 0xd850
0000d909  4883c018                 add rax, 0x18
0000d90d  90                       nop
0000d90e  0fb64810                 movzx ecx, byte ptr [rax + 0x10]
0000d912  493bc1                   cmp rax, r9
0000d915  72ea                     jb 0xd901
0000d917  e934ffffff               jmp 0xd850
0000d91c  49c1e820                 shr r8, 0x20
0000d920  0faee8                   lfence
0000d923  4181e0ff010000           and r8d, 0x1ff
0000d92a  488d542430               lea rdx, [rsp + 0x30]
0000d92f  488bcf                   mov rcx, rdi
0000d932  4b8d0440                 lea rax, [r8 + r8*2]
0000d936  f048ff8cc3e07a5800       lock dec qword ptr [rbx + rax*8 + 0x587ae0]
0000d93f  e8bc270000               call 0x10100
0000d944  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
0000d949  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
0000d94e  488b742448               mov rsi, qword ptr [rsp + 0x48]
0000d953  4883c420                 add rsp, 0x20
0000d957  5f                       pop rdi
0000d958  c3                       ret
