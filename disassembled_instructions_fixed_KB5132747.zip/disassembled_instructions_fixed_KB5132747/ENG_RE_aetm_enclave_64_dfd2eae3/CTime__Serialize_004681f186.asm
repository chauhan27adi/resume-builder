; CTime::Serialize
; aetm_enclave.dll, primary RVA 0x2ec70, 284 bytes in 1 chunk(s)

; chunk at RVA 0x2ec70 (284 bytes)
0002ec70  48895c2418               mov qword ptr [rsp + 0x18], rbx
0002ec75  4889742420               mov qword ptr [rsp + 0x20], rsi
0002ec7a  57                       push rdi
0002ec7b  4883ec30                 sub rsp, 0x30
0002ec7f  33c0                     xor eax, eax
0002ec81  c70203290000             mov dword ptr [rdx], 0x2903
0002ec87  48894208                 mov qword ptr [rdx + 8], rax
0002ec8b  4c8d056e13fdff           lea r8, [rip - 0x2ec92]
0002ec92  48894210                 mov qword ptr [rdx + 0x10], rax
0002ec96  488bf2                   mov rsi, rdx
0002ec99  894218                   mov dword ptr [rdx + 0x18], eax
0002ec9c  0fb64110                 movzx eax, byte ptr [rcx + 0x10]
0002eca0  488b5108                 mov rdx, qword ptr [rcx + 8]
0002eca4  4889542420               mov qword ptr [rsp + 0x20], rdx
0002eca9  410fb6bc8040420600       movzx edi, byte ptr [r8 + rax*4 + 0x64240]
0002ecb2  8d47fd                   lea eax, [rdi - 3]
0002ecb5  83f807                   cmp eax, 7
0002ecb8  0f8784000000             ja 0x2ed42
0002ecbe  4898                     cdqe
0002ecc0  418b8c806ced0200         mov ecx, dword ptr [r8 + rax*4 + 0x2ed6c]
0002ecc8  4903c8                   add rcx, r8
0002eccb  ffe1                     jmp rcx
0002eccd  0fb6442422               movzx eax, byte ptr [rsp + 0x22]
0002ecd2  66895608                 mov word ptr [rsi + 8], dx
0002ecd6  88460a                   mov byte ptr [rsi + 0xa], al
0002ecd9  eb78                     jmp 0x2ed53
0002ecdb  895608                   mov dword ptr [rsi + 8], edx
0002ecde  eb73                     jmp 0x2ed53
0002ece0  0fb6442424               movzx eax, byte ptr [rsp + 0x24]
0002ece5  895608                   mov dword ptr [rsi + 8], edx
0002ece8  88460c                   mov byte ptr [rsi + 0xc], al
0002eceb  eb66                     jmp 0x2ed53
0002eced  0fb7442424               movzx eax, word ptr [rsp + 0x24]
0002ecf2  895608                   mov dword ptr [rsi + 8], edx
0002ecf5  6689460c                 mov word ptr [rsi + 0xc], ax
0002ecf9  eb58                     jmp 0x2ed53
0002ecfb  0fb7442424               movzx eax, word ptr [rsp + 0x24]
0002ed00  895608                   mov dword ptr [rsi + 8], edx
0002ed03  6689460c                 mov word ptr [rsi + 0xc], ax
0002ed07  0fb6442426               movzx eax, byte ptr [rsp + 0x26]
0002ed0c  88460e                   mov byte ptr [rsi + 0xe], al
0002ed0f  eb42                     jmp 0x2ed53
0002ed11  48895608                 mov qword ptr [rsi + 8], rdx
0002ed15  eb3c                     jmp 0x2ed53
0002ed17  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
0002ed1d  0fb6442428               movzx eax, byte ptr [rsp + 0x28]
0002ed22  f20f114608               movsd qword ptr [rsi + 8], xmm0
0002ed27  884610                   mov byte ptr [rsi + 0x10], al
0002ed2a  eb27                     jmp 0x2ed53
0002ed2c  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
0002ed32  0fb7442428               movzx eax, word ptr [rsp + 0x28]
0002ed37  f20f114608               movsd qword ptr [rsi + 8], xmm0
0002ed3c  66894610                 mov word ptr [rsi + 0x10], ax
0002ed40  eb11                     jmp 0x2ed53
0002ed42  4c8bc7                   mov r8, rdi
0002ed45  488d542420               lea rdx, [rsp + 0x20]
0002ed4a  488d4e08                 lea rcx, [rsi + 8]
0002ed4e  e8c0f40200               call 0x5e213
0002ed53  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0002ed58  40887e1b                 mov byte ptr [rsi + 0x1b], dil
0002ed5c  c60600                   mov byte ptr [rsi], 0
0002ed5f  488b742458               mov rsi, qword ptr [rsp + 0x58]
0002ed64  4883c430                 add rsp, 0x30
0002ed68  5f                       pop rdi
0002ed69  c3                       ret
0002ed6a  6690                     nop
0002ed6c  cdec                     int 0xec
0002ed6e  0200                     add al, byte ptr [rax]
0002ed70  dbec                     fucomi st(4)
0002ed72  0200                     add al, byte ptr [rax]
0002ed74  e0ec                     loopne 0x2ed62
0002ed76  0200                     add al, byte ptr [rax]
0002ed78  ed                       in eax, dx
0002ed79  ec                       in al, dx
0002ed7a  0200                     add al, byte ptr [rax]
0002ed7c  fb                       sti
0002ed7d  ec                       in al, dx
0002ed7e  0200                     add al, byte ptr [rax]
0002ed80  11ed                     adc ebp, ebp
0002ed82  0200                     add al, byte ptr [rax]
