; `CTrustedMachine::InitTrustedMachine'::`1'::dtor$1
; aetm_enclave.dll, primary RVA 0x5fc00, 32 bytes in 1 chunk(s)

; chunk at RVA 0x5fc00 (32 bytes)
0005fc00  4055                     push rbp
0005fc02  4883ec20                 sub rsp, 0x20
0005fc06  488bea                   mov rbp, rdx
0005fc09  ba28000000               mov edx, 0x28
0005fc0e  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
0005fc15  e836d3ffff               call 0x5cf50
0005fc1a  4883c420                 add rsp, 0x20
0005fc1e  5d                       pop rbp
0005fc1f  c3                       ret
