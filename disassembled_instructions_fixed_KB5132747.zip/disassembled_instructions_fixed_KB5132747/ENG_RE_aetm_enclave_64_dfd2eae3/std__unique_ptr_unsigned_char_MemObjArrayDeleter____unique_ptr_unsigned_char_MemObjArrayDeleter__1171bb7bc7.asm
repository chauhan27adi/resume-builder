; std::unique_ptr<unsigned char,MemObjArrayDeleter>::~unique_ptr<unsigned char,MemObjArrayDeleter>
; aetm_enclave.dll, primary RVA 0x11060, 37 bytes in 1 chunk(s)

; chunk at RVA 0x11060 (37 bytes)
00011060  4883ec38                 sub rsp, 0x38
00011064  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0001106d  488b5110                 mov rdx, qword ptr [rcx + 0x10]
00011071  4885d2                   test rdx, rdx
00011074  740a                     je 0x11080
00011076  488b09                   mov rcx, qword ptr [rcx]
00011079  488b01                   mov rax, qword ptr [rcx]
0001107c  ff5028                   call qword ptr [rax + 0x28]
0001107f  90                       nop
00011080  4883c438                 add rsp, 0x38
00011084  c3                       ret
