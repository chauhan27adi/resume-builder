; CValExecEncrTMOutput::CbRawBytes
; aetm_enclave.dll, primary RVA 0x16960, 292 bytes in 1 chunk(s)

; chunk at RVA 0x16960 (292 bytes)
00016960  4883ec28                 sub rsp, 0x28
00016964  4c8d0d9596feff           lea r9, [rip - 0x1696b]
0001696b  4c8d81a8000000           lea r8, [rcx + 0xa8]
00016972  410fb608                 movzx ecx, byte ptr [r8]
00016976  420fb68409405a0600       movzx eax, byte ptr [rcx + r9 + 0x65a40]
0001697f  4280bc08405b060001       cmp byte ptr [rax + r9 + 0x65b40], 1
00016988  7508                     jne 0x16992
0001698a  8b4210                   mov eax, dword ptr [rdx + 0x10]
0001698d  4883c428                 add rsp, 0x28
00016991  c3                       ret
00016992  8d41dc                   lea eax, [rcx - 0x24]
00016995  83f85b                   cmp eax, 0x5b
00016998  7764                     ja 0x169fe
0001699a  4898                     cdqe
0001699c  410fb68401286a0100       movzx eax, byte ptr [r9 + rax + 0x16a28]
000169a5  418b8c81086a0100         mov ecx, dword ptr [r9 + rax*4 + 0x16a08]
000169ad  4903c9                   add rcx, r9
000169b0  ffe1                     jmp rcx
000169b2  b803000000               mov eax, 3
000169b7  4883c428                 add rsp, 0x28
000169bb  c3                       ret
000169bc  b804000000               mov eax, 4
000169c1  4883c428                 add rsp, 0x28
000169c5  c3                       ret
000169c6  b805000000               mov eax, 5
000169cb  4883c428                 add rsp, 0x28
000169cf  c3                       ret
000169d0  b80a000000               mov eax, 0xa
000169d5  4883c428                 add rsp, 0x28
000169d9  c3                       ret
000169da  b811000000               mov eax, 0x11
000169df  4883c428                 add rsp, 0x28
000169e3  c3                       ret
000169e4  b808000000               mov eax, 8
000169e9  4883c428                 add rsp, 0x28
000169ed  c3                       ret
000169ee  498bc8                   mov rcx, r8
000169f1  e86a14ffff               call 0x7e60
000169f6  0fb7c0                   movzx eax, ax
000169f9  4883c428                 add rsp, 0x28
000169fd  c3                       ret
000169fe  33c0                     xor eax, eax
00016a00  4883c428                 add rsp, 0x28
00016a04  c3                       ret
00016a05  0f1f00                   nop dword ptr [rax]
00016a08  ee                       out dx, al
00016a09  690100b26901             imul eax, dword ptr [rcx], 0x169b200
00016a0f  00c6                     add dh, al
00016a11  690100e46901             imul eax, dword ptr [rcx], 0x169e400
00016a17  00d0                     add al, dl
00016a19  690100bc6901             imul eax, dword ptr [rcx], 0x169bc00
00016a1f  00da                     add dl, bl
00016a21  690100fe6901             imul eax, dword ptr [rcx], 0x169fe00
00016a27  0000                     add byte ptr [rax], al
