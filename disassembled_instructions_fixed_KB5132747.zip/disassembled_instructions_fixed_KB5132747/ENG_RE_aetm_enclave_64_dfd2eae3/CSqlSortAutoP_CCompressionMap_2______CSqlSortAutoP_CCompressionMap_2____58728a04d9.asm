; CSqlSortAutoP<CCompressionMap<2> >::~CSqlSortAutoP<CCompressionMap<2> >
; aetm_enclave.dll, primary RVA 0x42820, 135 bytes in 5 chunk(s)

; chunk at RVA 0x42820 (30 bytes)
00042820  4889742418               mov qword ptr [rsp + 0x18], rsi
00042825  4156                     push r14
00042827  4883ec20                 sub rsp, 0x20
0004282b  488b31                   mov rsi, qword ptr [rcx]
0004282e  4c8bf1                   mov r14, rcx
00042831  4885f6                   test rsi, rsi
00042834  7465                     je 0x4289b
00042836  488b06                   mov rax, qword ptr [rsi]
00042839  4885c0                   test rax, rax
0004283c  7455                     je 0x42893

; chunk at RVA 0x4283e (12 bytes)
0004283e  48897c2438               mov qword ptr [rsp + 0x38], rdi
00042843  33ff                     xor edi, edi
00042845  397e08                   cmp dword ptr [rsi + 8], edi
00042848  763c                     jbe 0x42886

; chunk at RVA 0x4284a (60 bytes)
0004284a  48895c2430               mov qword ptr [rsp + 0x30], rbx
0004284f  90                       nop
00042850  8bcf                     mov ecx, edi
00042852  488bd0                   mov rdx, rax
00042855  4803c9                   add rcx, rcx
00042858  488b0cc8                 mov rcx, qword ptr [rax + rcx*8]
0004285c  4885c9                   test rcx, rcx
0004285f  7416                     je 0x42877
00042861  488b19                   mov rbx, qword ptr [rcx]
00042864  e833b70100               call 0x5df9c
00042869  488bcb                   mov rcx, rbx
0004286c  4885db                   test rbx, rbx
0004286f  75f0                     jne 0x42861
00042871  488b06                   mov rax, qword ptr [rsi]
00042874  488bd0                   mov rdx, rax
00042877  ffc7                     inc edi
00042879  3b7e08                   cmp edi, dword ptr [rsi + 8]
0004287c  72d2                     jb 0x42850
0004287e  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00042883  488bc2                   mov rax, rdx

; chunk at RVA 0x42886 (13 bytes)
00042886  488bc8                   mov rcx, rax
00042889  e80eb70100               call 0x5df9c
0004288e  488b7c2438               mov rdi, qword ptr [rsp + 0x38]

; chunk at RVA 0x42893 (20 bytes)
00042893  498b0e                   mov rcx, qword ptr [r14]
00042896  e801b70100               call 0x5df9c
0004289b  488b742440               mov rsi, qword ptr [rsp + 0x40]
000428a0  4883c420                 add rsp, 0x20
000428a4  415e                     pop r14
000428a6  c3                       ret
