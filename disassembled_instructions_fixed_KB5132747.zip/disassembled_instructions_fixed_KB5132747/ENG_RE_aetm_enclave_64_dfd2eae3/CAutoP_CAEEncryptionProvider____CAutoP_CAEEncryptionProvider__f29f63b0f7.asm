; CAutoP<CAEEncryptionProvider>::~CAutoP<CAEEncryptionProvider>
; aetm_enclave.dll, primary RVA 0x12980, 94 bytes in 1 chunk(s)

; chunk at RVA 0x12980 (94 bytes)
00012980  4053                     push rbx
00012982  4883ec20                 sub rsp, 0x20
00012986  488b19                   mov rbx, qword ptr [rcx]
00012989  4885db                   test rbx, rbx
0001298c  744a                     je 0x129d8
0001298e  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
00012992  4885c9                   test rcx, rcx
00012995  7413                     je 0x129aa
00012997  488b01                   mov rax, qword ptr [rcx]
0001299a  ba01000000               mov edx, 1
0001299f  ff5010                   call qword ptr [rax + 0x10]
000129a2  48c7437000000000         mov qword ptr [rbx + 0x70], 0
000129aa  488b4b78                 mov rcx, qword ptr [rbx + 0x78]
000129ae  4885c9                   test rcx, rcx
000129b1  7413                     je 0x129c6
000129b3  488b01                   mov rax, qword ptr [rcx]
000129b6  ba01000000               mov edx, 1
000129bb  ff5010                   call qword ptr [rax + 0x10]
000129be  48c7437800000000         mov qword ptr [rbx + 0x78], 0
000129c6  ba80000000               mov edx, 0x80
000129cb  488bcb                   mov rcx, rbx
000129ce  4883c420                 add rsp, 0x20
000129d2  5b                       pop rbx
000129d3  e978a50400               jmp 0x5cf50
000129d8  4883c420                 add rsp, 0x20
000129dc  5b                       pop rbx
000129dd  c3                       ret
