; CSqlSortManager_80::GetNextSortID
; aetm_enclave.dll, primary RVA 0x44f80, 3003 bytes in 1 chunk(s)

; chunk at RVA 0x44f80 (3003 bytes)
00044f80  48895c2408               mov qword ptr [rsp + 8], rbx
00044f85  44894c2420               mov dword ptr [rsp + 0x20], r9d
00044f8a  55                       push rbp
00044f8b  56                       push rsi
00044f8c  57                       push rdi
00044f8d  4154                     push r12
00044f8f  4155                     push r13
00044f91  4156                     push r14
00044f93  4157                     push r15
00044f95  4883ec40                 sub rsp, 0x40
00044f99  418b8088000000           mov eax, dword ptr [r8 + 0x88]
00044fa0  4c8bea                   mov r13, rdx
00044fa3  33d2                     xor edx, edx
00044fa5  498bd8                   mov rbx, r8
00044fa8  448bda                   mov r11d, edx
00044fab  89542424                 mov dword ptr [rsp + 0x24], edx
00044faf  8bf2                     mov esi, edx
00044fb1  89542430                 mov dword ptr [rsp + 0x30], edx
00044fb5  8bea                     mov ebp, edx
00044fb7  8954242c                 mov dword ptr [rsp + 0x2c], edx
00044fbb  8bfa                     mov edi, edx
00044fbd  89942490000000           mov dword ptr [rsp + 0x90], edx
00044fc4  41398084000000           cmp dword ptr [r8 + 0x84], eax
00044fcb  0f8c720a0000             jl 0x45a43
00044fd1  488b8424b8000000         mov rax, qword ptr [rsp + 0xb8]
00044fd9  4885c0                   test rax, rax
00044fdc  7402                     je 0x44fe0
00044fde  8810                     mov byte ptr [rax], dl
00044fe0  0fb7842490000000         movzx eax, word ptr [rsp + 0x90]
00044fe8  89442428                 mov dword ptr [rsp + 0x28], eax
00044fec  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
00044ff4  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
00044ffc  0f1f4000                 nop dword ptr [rax]
00045000  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
00045003  4c8d733c                 lea r14, [rbx + 0x3c]
00045007  41bf01000000             mov r15d, 1
0004500d  83f904                   cmp ecx, 4
00045010  0f8d8e000000             jge 0x450a4
00045016  488b4330                 mov rax, qword ptr [rbx + 0x30]
0004501a  660f1f440000             nop word ptr [rax + rax]
00045020  4885c0                   test rax, rax
00045023  745b                     je 0x45080
00045025  488b4318                 mov rax, qword ptr [rbx + 0x18]
00045029  4885c0                   test rax, rax
0004502c  740b                     je 0x45039
0004502e  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
00045032  ffd0                     call rax
00045034  0fb7c8                   movzx ecx, ax
00045037  eb12                     jmp 0x4504b
00045039  48635338                 movsxd rdx, dword ptr [rbx + 0x38]
0004503d  488b4328                 mov rax, qword ptr [rbx + 0x28]
00045041  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00045045  8d4201                   lea eax, [rdx + 1]
00045048  894338                   mov dword ptr [rbx + 0x38], eax
0004504b  4863435c                 movsxd rax, dword ptr [rbx + 0x5c]
0004504f  66894c433c               mov word ptr [rbx + rax*2 + 0x3c], cx
00045054  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
00045057  48ff4b30                 dec qword ptr [rbx + 0x30]
0004505b  ffc1                     inc ecx
0004505d  488b4330                 mov rax, qword ptr [rbx + 0x30]
00045061  894b5c                   mov dword ptr [rbx + 0x5c], ecx
00045064  83f904                   cmp ecx, 4
00045067  7cb7                     jl 0x45020
00045069  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
0004506e  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
00045076  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
0004507e  eb2c                     jmp 0x450ac
00045080  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
00045088  4533db                   xor r11d, r11d
0004508b  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
00045093  4863c1                   movsxd rax, ecx
00045096  6644895c433c             mov word ptr [rbx + rax*2 + 0x3c], r11w
0004509c  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
0004509f  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
000450a4  85c9                     test ecx, ecx
000450a6  0f8476090000             je 0x45a22
000450ac  837b0400                 cmp dword ptr [rbx + 4], 0
000450b0  7413                     je 0x450c5
000450b2  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
000450b6  6639433c                 cmp word ptr [rbx + 0x3c], ax
000450ba  7509                     jne 0x450c5
000450bc  413bcf                   cmp ecx, r15d
000450bf  0f844f090000             je 0x45a14
000450c5  4c638388000000           movsxd r8, dword ptr [rbx + 0x88]
000450cc  443b8380000000           cmp r8d, dword ptr [rbx + 0x80]
000450d3  0f8d42090000             jge 0x45a1b
000450d9  498b4508                 mov rax, qword ptr [r13 + 8]
000450dd  0fb74b3c                 movzx ecx, word ptr [rbx + 0x3c]
000450e1  8b1488                   mov edx, dword ptr [rax + rcx*4]
000450e4  235314                   and edx, dword ptr [rbx + 0x14]
000450e7  488b4368                 mov rax, qword ptr [rbx + 0x68]
000450eb  42891480                 mov dword ptr [rax + r8*4], edx
000450ef  33d2                     xor edx, edx
000450f1  4585c9                   test r9d, r9d
000450f4  740e                     je 0x45104
000450f6  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
000450fd  488b4370                 mov rax, qword ptr [rbx + 0x70]
00045101  891488                   mov dword ptr [rax + rcx*4], edx
00045104  85ff                     test edi, edi
00045106  0f8513020000             jne 0x4531f
0004510c  397b04                   cmp dword ptr [rbx + 4], edi
0004510f  747d                     je 0x4518e
00045111  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
00045115  6639433c                 cmp word ptr [rbx + 0x3c], ax
00045119  7573                     jne 0x4518e
0004511b  44397b5c                 cmp dword ptr [rbx + 0x5c], r15d
0004511f  7e6d                     jle 0x4518e
00045121  488d533e                 lea rdx, [rbx + 0x3e]
00045125  448d471e                 lea r8d, [rdi + 0x1e]
00045129  488d4b3c                 lea rcx, [rbx + 0x3c]
0004512d  e8ed900100               call 0x5e21f
00045132  ff4b5c                   dec dword ptr [rbx + 0x5c]
00045135  0fb74b3c                 movzx ecx, word ptr [rbx + 0x3c]
00045139  498b4508                 mov rax, qword ptr [r13 + 8]
0004513d  8b1488                   mov edx, dword ptr [rax + rcx*4]
00045140  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045147  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004514b  235314                   and edx, dword ptr [rbx + 0x14]
0004514e  891488                   mov dword ptr [rax + rcx*4], edx
00045151  4c8d15a8aefbff           lea r10, [rip - 0x45158]
00045158  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
0004515f  4533db                   xor r11d, r11d
00045162  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
00045169  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
0004516d  450fb70c90               movzx r9d, word ptr [r8 + rdx*4]
00045172  418bc1                   mov eax, r9d
00045175  c1e808                   shr eax, 8
00045178  83f80b                   cmp eax, 0xb
0004517b  0f8765070000             ja 0x458e6
00045181  418b8c82a05a0400         mov ecx, dword ptr [r10 + rax*4 + 0x45aa0]
00045189  4903ca                   add rcx, r10
0004518c  ffe1                     jmp rcx
0004518e  4585d2                   test r10d, r10d
00045191  7408                     je 0x4519b
00045193  85f6                     test esi, esi
00045195  0f8584010000             jne 0x4531f
0004519b  41837d1400               cmp dword ptr [r13 + 0x14], 0
000451a0  0f8479010000             je 0x4531f
000451a6  448b535c                 mov r10d, dword ptr [rbx + 0x5c]
000451aa  453bd7                   cmp r10d, r15d
000451ad  0f8e6c010000             jle 0x4531f
000451b3  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
000451ba  488b4368                 mov rax, qword ptr [rbx + 0x68]
000451be  f6448803c0               test byte ptr [rax + rcx*4 + 3], 0xc0
000451c3  4c8d0c88                 lea r9, [rax + rcx*4]
000451c7  0f8452010000             je 0x4531f
000451cd  41837d1800               cmp dword ptr [r13 + 0x18], 0
000451d2  743d                     je 0x45211
000451d4  89542424                 mov dword ptr [rsp + 0x24], edx
000451d8  448bda                   mov r11d, edx
000451db  4183fa02                 cmp r10d, 2
000451df  7e30                     jle 0x45211
000451e1  0fb7433e                 movzx eax, word ptr [rbx + 0x3e]
000451e5  663b430c                 cmp ax, word ptr [rbx + 0xc]
000451e9  7426                     je 0x45211
000451eb  8bc8                     mov ecx, eax
000451ed  498b4508                 mov rax, qword ptr [r13 + 8]
000451f1  8b1488                   mov edx, dword ptr [rax + rcx*4]
000451f4  235314                   and edx, dword ptr [rbx + 0x14]
000451f7  413311                   xor edx, dword ptr [r9]
000451fa  f7c2ffffffe7             test edx, 0xe7ffffff
00045200  750f                     jne 0x45211
00045202  458bdf                   mov r11d, r15d
00045205  44897c2424               mov dword ptr [rsp + 0x24], r15d
0004520a  4c8d733e                 lea r14, [rbx + 0x3e]
0004520e  41ffca                   dec r10d
00045211  450fb74e02               movzx r9d, word ptr [r14 + 2]
00045216  66443b4b0c               cmp r9w, word ptr [rbx + 0xc]
0004521b  0f84f5000000             je 0x45316
00045221  498b5520                 mov rdx, qword ptr [r13 + 0x20]
00045225  0fb74204                 movzx eax, word ptr [rdx + 4]
00045229  85c0                     test eax, eax
0004522b  0f84e5000000             je 0x45316
00045231  410fb70e                 movzx ecx, word ptr [r14]
00045235  66394a06                 cmp word ptr [rdx + 6], cx
00045239  760e                     jbe 0x45249
0004523b  4883c210                 add rdx, 0x10
0004523f  412bc7                   sub eax, r15d
00045242  75f1                     jne 0x45235
00045244  e9cd000000               jmp 0x45316
00045249  0f85c7000000             jne 0x45316
0004524f  66443b4a0c               cmp r9w, word ptr [rdx + 0xc]
00045254  0f82bc000000             jb 0x45316
0004525a  66443b4a0e               cmp r9w, word ptr [rdx + 0xe]
0004525f  0f87b1000000             ja 0x45316
00045265  0fb74a08                 movzx ecx, word ptr [rdx + 8]
00045269  498b4528                 mov rax, qword ptr [r13 + 0x28]
0004526d  440fb7420a               movzx r8d, word ptr [rdx + 0xa]
00045272  488d3cc8                 lea rdi, [rax + rcx*8]
00045276  4585c0                   test r8d, r8d
00045279  0f8490000000             je 0x4530f
0004527f  90                       nop
00045280  6644390f                 cmp word ptr [rdi], r9w
00045284  760f                     jbe 0x45295
00045286  4883c708                 add rdi, 8
0004528a  452bc7                   sub r8d, r15d
0004528d  75f1                     jne 0x45280
0004528f  eb7e                     jmp 0x4530f
00045291  6644390f                 cmp word ptr [rdi], r9w
00045295  7578                     jne 0x4530f
00045297  0fb74f02                 movzx ecx, word ptr [rdi + 2]
0004529b  6685c9                   test cx, cx
0004529e  743d                     je 0x452dd
000452a0  4183fa02                 cmp r10d, 2
000452a4  7e10                     jle 0x452b6
000452a6  410fb74604               movzx eax, word ptr [r14 + 4]
000452ab  663bc8                   cmp cx, ax
000452ae  7506                     jne 0x452b6
000452b0  6639430c                 cmp word ptr [rbx + 0xc], ax
000452b4  750b                     jne 0x452c1
000452b6  4883c708                 add rdi, 8
000452ba  452bc7                   sub r8d, r15d
000452bd  75d2                     jne 0x45291
000452bf  eb4e                     jmp 0x4530f
000452c1  4585db                   test r11d, r11d
000452c4  7535                     jne 0x452fb
000452c6  488d5340                 lea rdx, [rbx + 0x40]
000452ca  458d431c                 lea r8d, [r11 + 0x1c]
000452ce  488d4b3c                 lea rcx, [rbx + 0x3c]
000452d2  e8488f0100               call 0x5e21f
000452d7  83435cfe                 add dword ptr [rbx + 0x5c], -2
000452db  eb19                     jmp 0x452f6
000452dd  4585db                   test r11d, r11d
000452e0  7519                     jne 0x452fb
000452e2  488d533e                 lea rdx, [rbx + 0x3e]
000452e6  458d431e                 lea r8d, [r11 + 0x1e]
000452ea  488d4b3c                 lea rcx, [rbx + 0x3c]
000452ee  e82c8f0100               call 0x5e21f
000452f3  ff4b5c                   dec dword ptr [rbx + 0x5c]
000452f6  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
000452fb  8b5704                   mov edx, dword ptr [rdi + 4]
000452fe  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045305  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045309  235314                   and edx, dword ptr [rbx + 0x14]
0004530c  891488                   mov dword ptr [rax + rcx*4], edx
0004530f  8bbc2490000000           mov edi, dword ptr [rsp + 0x90]
00045316  4585db                   test r11d, r11d
00045319  7404                     je 0x4531f
0004531b  4983ee02                 sub r14, 2
0004531f  837b0400                 cmp dword ptr [rbx + 4], 0
00045323  0f8428feffff             je 0x45151
00045329  85ff                     test edi, edi
0004532b  0f8520feffff             jne 0x45151
00045331  410fb706                 movzx eax, word ptr [r14]
00045335  4c8d15c4acfbff           lea r10, [rip - 0x4533c]
0004533c  ffc5                     inc ebp
0004533e  83c0df                   add eax, -0x21
00045341  896c242c                 mov dword ptr [rsp + 0x2c], ebp
00045345  83f83e                   cmp eax, 0x3e
00045348  0f870afeffff             ja 0x45158
0004534e  4898                     cdqe
00045350  410fb68402fc5a0400       movzx eax, byte ptr [r10 + rax + 0x45afc]
00045359  418b8c82d05a0400         mov ecx, dword ptr [r10 + rax*4 + 0x45ad0]
00045361  4903ca                   add rcx, r10
00045364  ffe1                     jmp rcx
00045366  85f6                     test esi, esi
00045368  0f85eafdffff             jne 0x45158
0004536e  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045375  33ed                     xor ebp, ebp
00045377  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004537b  bafcff0000               mov edx, 0xfffc
00045380  418bf7                   mov esi, r15d
00045383  44897c2430               mov dword ptr [rsp + 0x30], r15d
00045388  896c242c                 mov dword ptr [rsp + 0x2c], ebp
0004538c  448bfd                   mov r15d, ebp
0004538f  89ac2498000000           mov dword ptr [rsp + 0x98], ebp
00045396  66891488                 mov word ptr [rax + rcx*4], dx
0004539a  e9c0fdffff               jmp 0x4515f
0004539f  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
000453a6  4533db                   xor r11d, r11d
000453a9  85f6                     test esi, esi
000453ab  0f84b1fdffff             je 0x45162
000453b1  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
000453b8  bafbff0000               mov edx, 0xfffb
000453bd  488b4368                 mov rax, qword ptr [rbx + 0x68]
000453c1  418bf3                   mov esi, r11d
000453c4  44895c2430               mov dword ptr [rsp + 0x30], r11d
000453c9  66891488                 mov word ptr [rax + rcx*4], dx
000453cd  e990fdffff               jmp 0x45162
000453d2  85f6                     test esi, esi
000453d4  0f847efdffff             je 0x45158
000453da  413bef                   cmp ebp, r15d
000453dd  0f8575fdffff             jne 0x45158
000453e3  4533db                   xor r11d, r11d
000453e6  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
000453ed  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
000453f4  0f8468fdffff             je 0x45162
000453fa  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045401  baf9ff0000               mov edx, 0xfff9
00045406  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004540a  44895c242c               mov dword ptr [rsp + 0x2c], r11d
0004540f  66891488                 mov word ptr [rax + rcx*4], dx
00045413  e94afdffff               jmp 0x45162
00045418  85f6                     test esi, esi
0004541a  0f8438fdffff             je 0x45158
00045420  413bef                   cmp ebp, r15d
00045423  0f852ffdffff             jne 0x45158
00045429  4533db                   xor r11d, r11d
0004542c  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
00045433  ebb8                     jmp 0x453ed
00045435  85f6                     test esi, esi
00045437  0f841bfdffff             je 0x45158
0004543d  413bef                   cmp ebp, r15d
00045440  0f8412fdffff             je 0x45158
00045446  44397b5c                 cmp dword ptr [rbx + 0x5c], r15d
0004544a  0f8e08fdffff             jle 0x45158
00045450  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
00045457  4533db                   xor r11d, r11d
0004545a  6641837e025d             cmp word ptr [r14 + 2], 0x5d
00045460  0f84fcfcffff             je 0x45162
00045466  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004546d  bafaff0000               mov edx, 0xfffa
00045472  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045476  458bfb                   mov r15d, r11d
00045479  66891488                 mov word ptr [rax + rcx*4], dx
0004547d  e9e0fcffff               jmp 0x45162
00045482  85f6                     test esi, esi
00045484  0f85cefcffff             jne 0x45158
0004548a  4533db                   xor r11d, r11d
0004548d  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
00045494  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
0004549b  0f84c1fcffff             je 0x45162
000454a1  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
000454a8  baf7ff0000               mov edx, 0xfff7
000454ad  488b4368                 mov rax, qword ptr [rbx + 0x68]
000454b1  66891488                 mov word ptr [rax + rcx*4], dx
000454b5  e9a8fcffff               jmp 0x45162
000454ba  85f6                     test esi, esi
000454bc  0f8596fcffff             jne 0x45158
000454c2  4533db                   xor r11d, r11d
000454c5  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
000454cc  ebc6                     jmp 0x45494
000454ce  85f6                     test esi, esi
000454d0  0f8582fcffff             jne 0x45158
000454d6  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
000454dd  4533db                   xor r11d, r11d
000454e0  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
000454e7  0f8475fcffff             je 0x45162
000454ed  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
000454f4  bafdff0000               mov edx, 0xfffd
000454f9  488b4368                 mov rax, qword ptr [rbx + 0x68]
000454fd  66891488                 mov word ptr [rax + rcx*4], dx
00045501  e95cfcffff               jmp 0x45162
00045506  85f6                     test esi, esi
00045508  0f854afcffff             jne 0x45158
0004550e  4533db                   xor r11d, r11d
00045511  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
00045518  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
0004551f  0f843dfcffff             je 0x45162
00045525  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004552c  bafeff0000               mov edx, 0xfffe
00045531  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045535  66891488                 mov word ptr [rax + rcx*4], dx
00045539  e924fcffff               jmp 0x45162
0004553e  85f6                     test esi, esi
00045540  0f8512fcffff             jne 0x45158
00045546  4533db                   xor r11d, r11d
00045549  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
00045550  ebc6                     jmp 0x45518
00045552  8b4310                   mov eax, dword ptr [rbx + 0x10]
00045555  a802                     test al, 2
00045557  751e                     jne 0x45577
00045559  0fbae01e                 bt eax, 0x1e
0004555d  0f83cd010000             jae 0x45730
00045563  8b435c                   mov eax, dword ptr [rbx + 0x5c]
00045566  394338                   cmp dword ptr [rbx + 0x38], eax
00045569  0f85c1010000             jne 0x45730
0004556f  85d2                     test edx, edx
00045571  0f85b9010000             jne 0x45730
00045577  488d533e                 lea rdx, [rbx + 0x3e]
0004557b  41b81e000000             mov r8d, 0x1e
00045581  488d4b3c                 lea rcx, [rbx + 0x3c]
00045585  e8958c0100               call 0x5e21f
0004558a  488b8c24c0000000         mov rcx, qword ptr [rsp + 0xc0]
00045592  41bb01000000             mov r11d, 1
00045598  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004559b  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
000455a3  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
000455ab  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
000455b3  4885c9                   test rcx, rcx
000455b6  7430                     je 0x455e8
000455b8  48ff01                   inc qword ptr [rcx]
000455bb  eb2b                     jmp 0x455e8
000455bd  498b4508                 mov rax, qword ptr [r13 + 8]
000455c1  410fb70e                 movzx ecx, word ptr [r14]
000455c5  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
000455c8  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
000455d0  8908                     mov dword ptr [rax], ecx
000455d2  f6431004                 test byte ptr [rbx + 0x10], 4
000455d6  759f                     jne 0x45577
000455d8  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
000455e0  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
000455e8  33d2                     xor edx, edx
000455ea  85ff                     test edi, edi
000455ec  7e0b                     jle 0x455f9
000455ee  ffcf                     dec edi
000455f0  8910                     mov dword ptr [rax], edx
000455f2  89bc2490000000           mov dword ptr [rsp + 0x90], edi
000455f9  8b742430                 mov esi, dword ptr [rsp + 0x30]
000455fd  4585db                   test r11d, r11d
00045600  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
00045605  8b6c242c                 mov ebp, dword ptr [rsp + 0x2c]
00045609  0f85f1f9ffff             jne 0x45000
0004560f  41b81e000000             mov r8d, 0x1e
00045615  488d533e                 lea rdx, [rbx + 0x3e]
00045619  488d4b3c                 lea rcx, [rbx + 0x3c]
0004561d  e8fd8b0100               call 0x5e21f
00045622  83bc249000000000         cmp dword ptr [rsp + 0x90], 0
0004562a  0f84ea020000             je 0x4591a
00045630  ff4b5c                   dec dword ptr [rbx + 0x5c]
00045633  ff8388000000             inc dword ptr [rbx + 0x88]
00045639  8bbc2490000000           mov edi, dword ptr [rsp + 0x90]
00045640  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
00045645  e9a2f9ffff               jmp 0x44fec
0004564a  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
00045652  33d2                     xor edx, edx
00045654  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
0004565c  8910                     mov dword ptr [rax], edx
0004565e  4585d2                   test r10d, r10d
00045661  7411                     je 0x45674
00045663  395308                   cmp dword ptr [rbx + 8], edx
00045666  0f84a1020000             je 0x4590d
0004566c  85f6                     test esi, esi
0004566e  0f8599020000             jne 0x4590d
00045674  4c63435c                 movsxd r8, dword ptr [rbx + 0x5c]
00045678  498d4e02                 lea rcx, [r14 + 2]
0004567c  4d03c0                   add r8, r8
0004567f  498bd6                   mov rdx, r14
00045682  e8988b0100               call 0x5e21f
00045687  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004568b  83c703                   add edi, 3
0004568e  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045695  89bc2490000000           mov dword ptr [rsp + 0x90], edi
0004569c  0fb61488                 movzx edx, byte ptr [rax + rcx*4]
000456a0  488d0d59a9fbff           lea rcx, [rip - 0x456a7]
000456a7  0fb7849170a43500         movzx eax, word ptr [rcx + rdx*4 + 0x35a470]
000456af  66418906                 mov word ptr [r14], ax
000456b3  0fb7849172a43500         movzx eax, word ptr [rcx + rdx*4 + 0x35a472]
000456bb  6641894602               mov word ptr [r14 + 2], ax
000456c0  8b535c                   mov edx, dword ptr [rbx + 0x5c]
000456c3  c7436001000000           mov dword ptr [rbx + 0x60], 1
000456ca  ffc2                     inc edx
000456cc  89535c                   mov dword ptr [rbx + 0x5c], edx
000456cf  410fb74e02               movzx ecx, word ptr [r14 + 2]
000456d4  498b4508                 mov rax, qword ptr [r13 + 8]
000456d8  807c880102               cmp byte ptr [rax + rcx*4 + 1], 2
000456dd  488d2c88                 lea rbp, [rax + rcx*4]
000456e1  7547                     jne 0x4572a
000456e3  4c63c2                   movsxd r8, edx
000456e6  498d4e04                 lea rcx, [r14 + 4]
000456ea  4d03c0                   add r8, r8
000456ed  498d5602                 lea rdx, [r14 + 2]
000456f1  e8298b0100               call 0x5e21f
000456f6  0fb64d00                 movzx ecx, byte ptr [rbp]
000456fa  488d15ffa8fbff           lea rdx, [rip - 0x45701]
00045701  0fb7848a70a43500         movzx eax, word ptr [rdx + rcx*4 + 0x35a470]
00045709  6641894602               mov word ptr [r14 + 2], ax
0004570e  0fb7848a72a43500         movzx eax, word ptr [rdx + rcx*4 + 0x35a472]
00045716  6641894604               mov word ptr [r14 + 4], ax
0004571b  ff435c                   inc dword ptr [rbx + 0x5c]
0004571e  ff4360                   inc dword ptr [rbx + 0x60]
00045721  ffc7                     inc edi
00045723  89bc2490000000           mov dword ptr [rsp + 0x90], edi
0004572a  41bb01000000             mov r11d, 1
00045730  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
00045738  e99bfeffff               jmp 0x455d8
0004573d  488b8424b8000000         mov rax, qword ptr [rsp + 0xb8]
00045745  4885c0                   test rax, rax
00045748  7413                     je 0x4575d
0004574a  4180f901                 cmp r9b, 1
0004574e  770d                     ja 0x4575d
00045750  c60001                   mov byte ptr [rax], 1
00045753  8b9388000000             mov edx, dword ptr [rbx + 0x88]
00045759  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
0004575d  4863c2                   movsxd rax, edx
00045760  41803c8001               cmp byte ptr [r8 + rax*4], 1
00045765  761f                     jbe 0x45786
00045767  498b4508                 mov rax, qword ptr [r13 + 8]
0004576b  410fb70e                 movzx ecx, word ptr [r14]
0004576f  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
00045772  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
0004577a  8908                     mov dword ptr [rax], ecx
0004577c  8b9388000000             mov edx, dword ptr [rbx + 0x88]
00045782  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
00045786  410fb74d40               movzx ecx, word ptr [r13 + 0x40]
0004578b  4863c2                   movsxd rax, edx
0004578e  450fb61480               movzx r10d, byte ptr [r8 + rax*4]
00045793  4d8d0c80                 lea r9, [r8 + rax*4]
00045797  410fb65103               movzx edx, byte ptr [r9 + 3]
0004579c  33c0                     xor eax, eax
0004579e  89442420                 mov dword ptr [rsp + 0x20], eax
000457a2  4180fa01                 cmp r10b, 1
000457a6  0f87c2000000             ja 0x4586e
000457ac  b8ffff0000               mov eax, 0xffff
000457b1  85ed                     test ebp, ebp
000457b3  0f849a000000             je 0x45853
000457b9  8bc5                     mov eax, ebp
000457bb  234314                   and eax, dword ptr [rbx + 0x14]
000457be  440fb7c0                 movzx r8d, ax
000457c2  89442434                 mov dword ptr [rsp + 0x34], eax
000457c6  6641c1e808               shr r8w, 8
000457cb  4180f803                 cmp r8b, 3
000457cf  727d                     jb 0x4584e
000457d1  7570                     jne 0x45843
000457d3  3c01                     cmp al, 1
000457d5  7677                     jbe 0x4584e
000457d7  0fb6c0                   movzx eax, al
000457da  440fb7c1                 movzx r8d, cx
000457de  0fb64c2437               movzx ecx, byte ptr [rsp + 0x37]
000457e3  6641c1e008               shl r8w, 8
000457e8  80e13f                   and cl, 0x3f
000457eb  66440bc0                 or r8w, ax
000457ef  0fb6c1                   movzx eax, cl
000457f2  24c6                     and al, 0xc6
000457f4  4489442428               mov dword ptr [rsp + 0x28], r8d
000457f9  88442420                 mov byte ptr [rsp + 0x20], al
000457fd  0fb6c1                   movzx eax, cl
00045800  24e4                     and al, 0xe4
00045802  664489442434             mov word ptr [rsp + 0x34], r8w
00045808  88442422                 mov byte ptr [rsp + 0x22], al
0004580c  4584d2                   test r10b, r10b
0004580f  7512                     jne 0x45823
00045811  8b442434                 mov eax, dword ptr [rsp + 0x34]
00045815  80e1c5                   and cl, 0xc5
00045818  884c2423                 mov byte ptr [rsp + 0x23], cl
0004581c  c644242104               mov byte ptr [rsp + 0x21], 4
00045821  eb35                     jmp 0x45858
00045823  b887ff0000               mov eax, 0xff87
00045828  c644242105               mov byte ptr [rsp + 0x21], 5
0004582d  664423c0                 and r8w, ax
00045831  8b442434                 mov eax, dword ptr [rsp + 0x34]
00045835  80e205                   and dl, 5
00045838  4489442428               mov dword ptr [rsp + 0x28], r8d
0004583d  88542423                 mov byte ptr [rsp + 0x23], dl
00045841  eb15                     jmp 0x45858
00045843  440fb7c0                 movzx r8d, ax
00045847  4489442428               mov dword ptr [rsp + 0x28], r8d
0004584c  eb0a                     jmp 0x45858
0004584e  b8ffff0000               mov eax, 0xffff
00045853  448b442428               mov r8d, dword ptr [rsp + 0x28]
00045858  3dffff0000               cmp eax, 0xffff
0004585d  7548                     jne 0x458a7
0004585f  33d2                     xor edx, edx
00045861  89442428                 mov dword ptr [rsp + 0x28], eax
00045865  89542420                 mov dword ptr [rsp + 0x20], edx
00045869  418901                   mov dword ptr [r9], eax
0004586c  eb44                     jmp 0x458b2
0004586e  418b01                   mov eax, dword ptr [r9]
00045871  450fb7c2                 movzx r8d, r10w
00045875  89842498000000           mov dword ptr [rsp + 0x98], eax
0004587c  0fb6c2                   movzx eax, dl
0004587f  2406                     and al, 6
00045881  66c1e108                 shl cx, 8
00045885  88442420                 mov byte ptr [rsp + 0x20], al
00045889  66440bc1                 or r8w, cx
0004588d  0fb6c2                   movzx eax, dl
00045890  4489442428               mov dword ptr [rsp + 0x28], r8d
00045895  2424                     and al, 0x24
00045897  c644242103               mov byte ptr [rsp + 0x21], 3
0004589c  80e205                   and dl, 5
0004589f  88442422                 mov byte ptr [rsp + 0x22], al
000458a3  88542423                 mov byte ptr [rsp + 0x23], dl
000458a7  66458901                 mov word ptr [r9], r8w
000458ab  33d2                     xor edx, edx
000458ad  41c6410302               mov byte ptr [r9 + 3], 2
000458b2  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
000458ba  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
000458c2  4585c9                   test r9d, r9d
000458c5  7439                     je 0x45900
000458c7  8b442420                 mov eax, dword ptr [rsp + 0x20]
000458cb  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
000458d2  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
000458d6  890491                   mov dword ptr [rcx + rdx*4], eax
000458d9  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
000458e1  e902fdffff               jmp 0x455e8
000458e6  498b4508                 mov rax, qword ptr [r13 + 8]
000458ea  410fb70e                 movzx ecx, word ptr [r14]
000458ee  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
000458f1  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
000458f9  8908                     mov dword ptr [rax], ecx
000458fb  e9d8fcffff               jmp 0x455d8
00045900  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
00045908  e9ddfcffff               jmp 0x455ea
0004590d  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
00045915  e9d0fcffff               jmp 0x455ea
0004591a  8b435c                   mov eax, dword ptr [rbx + 0x5c]
0004591d  ffc8                     dec eax
0004591f  89435c                   mov dword ptr [rbx + 0x5c], eax
00045922  4585ff                   test r15d, r15d
00045925  0f84ce000000             je 0x459f9
0004592b  0f1f440000               nop dword ptr [rax + rax]
00045930  85c0                     test eax, eax
00045932  7544                     jne 0x45978
00045934  48837b3000               cmp qword ptr [rbx + 0x30], 0
00045939  0f84ba000000             je 0x459f9
0004593f  488b4318                 mov rax, qword ptr [rbx + 0x18]
00045943  4885c0                   test rax, rax
00045946  740e                     je 0x45956
00045948  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
0004594c  ffd0                     call rax
0004594e  0fb7c8                   movzx ecx, ax
00045951  8b435c                   mov eax, dword ptr [rbx + 0x5c]
00045954  eb14                     jmp 0x4596a
00045956  48635338                 movsxd rdx, dword ptr [rbx + 0x38]
0004595a  488b4328                 mov rax, qword ptr [rbx + 0x28]
0004595e  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00045962  8d4201                   lea eax, [rdx + 1]
00045965  894338                   mov dword ptr [rbx + 0x38], eax
00045968  33c0                     xor eax, eax
0004596a  4898                     cdqe
0004596c  6641890c46               mov word ptr [r14 + rax*2], cx
00045971  ff435c                   inc dword ptr [rbx + 0x5c]
00045974  48ff4b30                 dec qword ptr [rbx + 0x30]
00045978  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004597f  41baf7ff0000             mov r10d, 0xfff7
00045985  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045989  440fb70c88               movzx r9d, word ptr [rax + rcx*4]
0004598e  4c8d0488                 lea r8, [rax + rcx*4]
00045992  66453bca                 cmp r9w, r10w
00045996  7525                     jne 0x459bd
00045998  6641833e25               cmp word ptr [r14], 0x25
0004599d  751e                     jne 0x459bd
0004599f  41b81e000000             mov r8d, 0x1e
000459a5  488d533e                 lea rdx, [rbx + 0x3e]
000459a9  488d4b3c                 lea rcx, [rbx + 0x3c]
000459ad  e86d880100               call 0x5e21f
000459b2  ff4b5c                   dec dword ptr [rbx + 0x5c]
000459b5  8b435c                   mov eax, dword ptr [rbx + 0x5c]
000459b8  e973ffffff               jmp 0x45930
000459bd  498b4508                 mov rax, qword ptr [r13 + 8]
000459c1  410fb70e                 movzx ecx, word ptr [r14]
000459c5  8b1488                   mov edx, dword ptr [rax + rcx*4]
000459c8  0fb7c2                   movzx eax, dx
000459cb  66c1e808                 shr ax, 8
000459cf  3c01                     cmp al, 1
000459d1  7526                     jne 0x459f9
000459d3  66453bca                 cmp r9w, r10w
000459d7  73c6                     jae 0x4599f
000459d9  410fb64002               movzx eax, byte ptr [r8 + 2]
000459de  c1ea10                   shr edx, 0x10
000459e1  0fb6ca                   movzx ecx, dl
000459e4  6603c8                   add cx, ax
000459e7  b8ff000000               mov eax, 0xff
000459ec  663bc8                   cmp cx, ax
000459ef  7602                     jbe 0x459f3
000459f1  8bc8                     mov ecx, eax
000459f3  41884802                 mov byte ptr [r8 + 2], cl
000459f7  eba6                     jmp 0x4599f
000459f9  ff8388000000             inc dword ptr [rbx + 0x88]
000459ff  85f6                     test esi, esi
00045a01  7440                     je 0x45a43
00045a03  8bbc2490000000           mov edi, dword ptr [rsp + 0x90]
00045a0a  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
00045a0f  e9d8f5ffff               jmp 0x44fec
00045a14  b803000000               mov eax, 3
00045a19  eb2a                     jmp 0x45a45
00045a1b  b802000000               mov eax, 2
00045a20  eb23                     jmp 0x45a45
00045a22  48638388000000           movsxd rax, dword ptr [rbx + 0x88]
00045a29  85f6                     test esi, esi
00045a2b  7430                     je 0x45a5d
00045a2d  488bc8                   mov rcx, rax
00045a30  bafbff0000               mov edx, 0xfffb
00045a35  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045a39  66891488                 mov word ptr [rax + rcx*4], dx
00045a3d  ff8388000000             inc dword ptr [rbx + 0x88]
00045a43  33c0                     xor eax, eax
00045a45  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
00045a4d  4883c440                 add rsp, 0x40
00045a51  415f                     pop r15
00045a53  415e                     pop r14
00045a55  415d                     pop r13
00045a57  415c                     pop r12
00045a59  5f                       pop rdi
00045a5a  5e                       pop rsi
00045a5b  5d                       pop rbp
00045a5c  c3                       ret
00045a5d  398384000000             cmp dword ptr [rbx + 0x84], eax
00045a63  75de                     jne 0x45a43
00045a65  f7431000000008           test dword ptr [rbx + 0x10], 0x8000000
00045a6c  742c                     je 0x45a9a
00045a6e  498b4d08                 mov rcx, qword ptr [r13 + 8]
00045a72  448b8180000000           mov r8d, dword ptr [rcx + 0x80]
00045a79  44234314                 and r8d, dword ptr [rbx + 0x14]
00045a7d  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
00045a81  44890481                 mov dword ptr [rcx + rax*4], r8d
00045a85  4585c9                   test r9d, r9d
00045a88  7410                     je 0x45a9a
00045a8a  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
00045a91  33c0                     xor eax, eax
00045a93  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
00045a97  890491                   mov dword ptr [rcx + rdx*4], eax
00045a9a  418bc7                   mov eax, r15d
00045a9d  eba6                     jmp 0x45a45
00045a9f  90                       nop
00045aa0  7755                     ja 0x45af7
00045aa2  0400                     add al, 0
00045aa4  52                       push rdx
00045aa5  55                       push rbp
00045aa6  0400                     add al, 0
00045aa8  4a56                     push rsi
00045aaa  0400                     add al, 0
00045aac  3d570400e6               cmp eax, 0xe6000457
00045ab1  58                       pop rax
00045ab2  0400                     add al, 0
00045ab4  e658                     out 0x58, al
00045ab6  0400                     add al, 0
00045ab8  bd550400bd               mov ebp, 0xbd000455
00045abd  55                       push rbp
00045abe  0400                     add al, 0
00045ac0  bd550400bd               mov ebp, 0xbd000455
00045ac5  55                       push rbp
00045ac6  0400                     add al, 0
00045ac8  bd550400bd               mov ebp, 0xbd000455
00045acd  55                       push rbp
00045ace  0400                     add al, 0
00045ad0  d25304                   rcl byte ptr [rbx + 4], cl
00045ad3  00ce                     add dh, cl
00045ad5  54                       push rsp
00045ad6  0400                     add al, 0
00045ad8  ba54040082               mov edx, 0x82000454
00045add  54                       push rsp
00045ade  0400                     add al, 0
00045ae0  3554040006               xor eax, 0x6000454
00045ae5  55                       push rbp
00045ae6  0400                     add al, 0
00045ae8  6653                     push bx
00045aea  0400                     add al, 0
00045aec  9f                       lahf
00045aed  53                       push rbx
00045aee  0400                     add al, 0
00045af0  18540400                 sbb byte ptr [rsp + rax], dl
00045af4  3e55                     push rbp
00045af6  0400                     add al, 0
00045af8  58                       pop rax
00045af9  51                       push rcx
00045afa  0400                     add al, 0
00045afc  000a                     add byte ptr [rdx], cl
00045afe  010a                     add dword ptr [rdx], ecx
00045b00  020a                     add cl, byte ptr [rdx]
00045b02  0a0a                     or cl, byte ptr [rdx]
00045b04  0a03                     or al, byte ptr [rbx]
00045b06  0a0a                     or cl, byte ptr [rdx]
00045b08  040a                     add al, 0xa
00045b0a  0a0a                     or cl, byte ptr [rdx]
00045b0c  0a0a                     or cl, byte ptr [rdx]
00045b0e  0a0a                     or cl, byte ptr [rdx]
00045b10  0a0a                     or cl, byte ptr [rdx]
00045b12  0a0a                     or cl, byte ptr [rdx]
00045b14  0a0a                     or cl, byte ptr [rdx]
00045b16  0a0a                     or cl, byte ptr [rdx]
00045b18  0a0a                     or cl, byte ptr [rdx]
00045b1a  050a0a0a0a               add eax, 0xa0a0a0a
00045b1f  0a0a                     or cl, byte ptr [rdx]
00045b21  0a0a                     or cl, byte ptr [rdx]
00045b23  0a0a                     or cl, byte ptr [rdx]
00045b25  0a0a                     or cl, byte ptr [rdx]
00045b27  0a0a                     or cl, byte ptr [rdx]
00045b29  0a0a                     or cl, byte ptr [rdx]
00045b2b  0a0a                     or cl, byte ptr [rdx]
00045b2d  0a0a                     or cl, byte ptr [rdx]
00045b2f  0a0a                     or cl, byte ptr [rdx]
00045b31  0a0a                     or cl, byte ptr [rdx]
00045b33  0a0a                     or cl, byte ptr [rdx]
00045b35  0a06                     or al, byte ptr [rsi]
00045b37  0a07                     or al, byte ptr [rdi]
00045b39  0809                     or byte ptr [rcx], cl
