; CEsCompBase::~CEsCompBase
; aetm_enclave.dll, primary RVA 0x1f8c0, 199 bytes in 1 chunk(s)

; chunk at RVA 0x1f8c0 (199 bytes)
0001f8c0  48894c2408               mov qword ptr [rsp + 8], rcx
0001f8c5  57                       push rdi
0001f8c6  4883ec30                 sub rsp, 0x30
0001f8ca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0001f8d3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0001f8d8  488bf9                   mov rdi, rcx
0001f8db  488d0526520400           lea rax, [rip + 0x45226]
0001f8e2  488901                   mov qword ptr [rcx], rax
0001f8e5  f6410808                 test byte ptr [rcx + 8], 8
0001f8e9  488b4918                 mov rcx, qword ptr [rcx + 0x18]
0001f8ed  7507                     jne 0x1f8f6
0001f8ef  e848d50300               call 0x5ce3c
0001f8f4  eb34                     jmp 0x1f92a
0001f8f6  4885c9                   test rcx, rcx
0001f8f9  742f                     je 0x1f92a
0001f8fb  488d59f8                 lea rbx, [rcx - 8]
0001f8ff  4c8d0d5aeb0000           lea r9, [rip + 0xeb5a]
0001f906  4c8b03                   mov r8, qword ptr [rbx]
0001f909  ba30000000               mov edx, 0x30
0001f90e  e86dd50300               call 0x5ce80
0001f913  488b03                   mov rax, qword ptr [rbx]
0001f916  488d1440                 lea rdx, [rax + rax*2]
0001f91a  48c1e204                 shl rdx, 4
0001f91e  4883c208                 add rdx, 8
0001f922  488bcb                   mov rcx, rbx
0001f925  e832d50300               call 0x5ce5c
0001f92a  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0001f92e  e809d50300               call 0x5ce3c
0001f933  90                       nop
0001f934  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
0001f938  4885c9                   test rcx, rcx
0001f93b  7437                     je 0x1f974
0001f93d  33db                     xor ebx, ebx
0001f93f  395f78                   cmp dword ptr [rdi + 0x78], ebx
0001f942  762a                     jbe 0x1f96e
0001f944  488bd1                   mov rdx, rcx
0001f947  4c8b04d9                 mov r8, qword ptr [rcx + rbx*8]
0001f94b  4d85c0                   test r8, r8
0001f94e  7414                     je 0x1f964
0001f950  498b00                   mov rax, qword ptr [r8]
0001f953  ba01000000               mov edx, 1
0001f958  498bc8                   mov rcx, r8
0001f95b  ff10                     call qword ptr [rax]
0001f95d  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
0001f961  488bd1                   mov rdx, rcx
0001f964  ffc3                     inc ebx
0001f966  3b5f78                   cmp ebx, dword ptr [rdi + 0x78]
0001f969  72dc                     jb 0x1f947
0001f96b  488bca                   mov rcx, rdx
0001f96e  e8c9d40300               call 0x5ce3c
0001f973  90                       nop
0001f974  488d4f28                 lea rcx, [rdi + 0x28]
0001f978  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0001f97d  4883c430                 add rsp, 0x30
0001f981  5f                       pop rdi
0001f982  e9b9c80000               jmp 0x2c240
