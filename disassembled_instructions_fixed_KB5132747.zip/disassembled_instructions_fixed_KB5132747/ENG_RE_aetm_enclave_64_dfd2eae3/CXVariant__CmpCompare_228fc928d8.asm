; CXVariant::CmpCompare
; aetm_enclave.dll, primary RVA 0x3b9c0, 1739 bytes in 1 chunk(s)

; chunk at RVA 0x3b9c0 (1739 bytes)
0003b9c0  4055                     push rbp
0003b9c2  53                       push rbx
0003b9c3  56                       push rsi
0003b9c4  57                       push rdi
0003b9c5  4156                     push r14
0003b9c7  4881ec60010000           sub rsp, 0x160
0003b9ce  48c7842458010000feffffff mov qword ptr [rsp + 0x158], 0xfffffffffffffffe
0003b9da  488dac2490000000         lea rbp, [rsp + 0x90]
0003b9e2  4883e5c0                 and rbp, 0xffffffffffffffc0
0003b9e6  488b051bf60600           mov rax, qword ptr [rip + 0x6f61b]
0003b9ed  4833c4                   xor rax, rsp
0003b9f0  488985c0000000           mov qword ptr [rbp + 0xc0], rax
0003b9f7  498bf9                   mov rdi, r9
0003b9fa  4c8bca                   mov r9, rdx
0003b9fd  488bd9                   mov rbx, rcx
0003ba00  440fb617                 movzx r10d, byte ptr [rdi]
0003ba04  0fb611                   movzx edx, byte ptr [rcx]
0003ba07  0fb6c2                   movzx eax, dl
0003ba0a  488d35ef45fcff           lea rsi, [rip - 0x3ba11]
0003ba11  41beffff0000             mov r14d, 0xffff
0003ba17  410ac2                   or al, r10b
0003ba1a  7458                     je 0x3ba74
0003ba1c  410fb601                 movzx eax, byte ptr [r9]
0003ba20  0fb68c30405a0600         movzx ecx, byte ptr [rax + rsi + 0x65a40]
0003ba28  80bc31a05c060000         cmp byte ptr [rcx + rsi + 0x65ca0], 0
0003ba30  7407                     je 0x3ba39
0003ba32  66453b7110               cmp r14w, word ptr [r9 + 0x10]
0003ba37  743b                     je 0x3ba74
0003ba39  410fb600                 movzx eax, byte ptr [r8]
0003ba3d  0fb68c30405a0600         movzx ecx, byte ptr [rax + rsi + 0x65a40]
0003ba45  80bc31a05c060000         cmp byte ptr [rcx + rsi + 0x65ca0], 0
0003ba4d  7407                     je 0x3ba56
0003ba4f  66453b7010               cmp r14w, word ptr [r8 + 0x10]
0003ba54  741e                     je 0x3ba74
0003ba56  443ad2                   cmp r10b, dl
0003ba59  7412                     je 0x3ba6d
0003ba5b  b828000000               mov eax, 0x28
0003ba60  b930000000               mov ecx, 0x30
0003ba65  80fa03                   cmp dl, 3
0003ba68  0f45c1                   cmovne eax, ecx
0003ba6b  eb66                     jmp 0x3bad3
0003ba6d  b858000000               mov eax, 0x58
0003ba72  eb5f                     jmp 0x3bad3
0003ba74  410fb611                 movzx edx, byte ptr [r9]
0003ba78  410fb608                 movzx ecx, byte ptr [r8]
0003ba7c  440fb69c32405a0600       movzx r11d, byte ptr [rdx + rsi + 0x65a40]
0003ba85  4180bc33405b060000       cmp byte ptr [r11 + rsi + 0x65b40], 0
0003ba8e  7460                     je 0x3baf0
0003ba90  4180bc33a05c060000       cmp byte ptr [r11 + rsi + 0x65ca0], 0
0003ba99  7407                     je 0x3baa2
0003ba9b  66453b7110               cmp r14w, word ptr [r9 + 0x10]
0003baa0  742f                     je 0x3bad1
0003baa2  4c8bd1                   mov r10, rcx
0003baa5  0fb68431405a0600         movzx eax, byte ptr [rcx + rsi + 0x65a40]
0003baad  80bc30a05c060000         cmp byte ptr [rax + rsi + 0x65ca0], 0
0003bab5  7407                     je 0x3babe
0003bab7  66453b7010               cmp r14w, word ptr [r8 + 0x10]
0003babc  7413                     je 0x3bad1
0003babe  80faf0                   cmp dl, 0xf0
0003bac1  7530                     jne 0x3baf3
0003bac3  6645397110               cmp word ptr [r9 + 0x10], r14w
0003bac8  7529                     jne 0x3baf3
0003baca  41f6410108               test byte ptr [r9 + 1], 8
0003bacf  7422                     je 0x3baf3
0003bad1  33c0                     xor eax, eax
0003bad3  488b8dc0000000           mov rcx, qword ptr [rbp + 0xc0]
0003bada  4833cc                   xor rcx, rsp
0003badd  e8ee120200               call 0x5cdd0
0003bae2  4881c460010000           add rsp, 0x160
0003bae9  415e                     pop r14
0003baeb  5f                       pop rdi
0003baec  5e                       pop rsi
0003baed  5b                       pop rbx
0003baee  5d                       pop rbp
0003baef  c3                       ret
0003baf0  4c8bd1                   mov r10, rcx
0003baf3  410fb68c33a8560600       movzx ecx, byte ptr [r11 + rsi + 0x656a8]
0003bafc  410fb68432405a0600       movzx eax, byte ptr [r10 + rsi + 0x65a40]
0003bb05  3a8c30a8560600           cmp cl, byte ptr [rax + rsi + 0x656a8]
0003bb0c  75c3                     jne 0x3bad1
0003bb0e  8d42de                   lea eax, [rdx - 0x22]
0003bb11  3dce000000               cmp eax, 0xce
0003bb16  77b9                     ja 0x3bad1
0003bb18  4898                     cdqe
0003bb1a  0fb68406bcbf0300         movzx eax, byte ptr [rsi + rax + 0x3bfbc]
0003bb22  8b8c8668bf0300           mov ecx, dword ptr [rsi + rax*4 + 0x3bf68]
0003bb29  4803ce                   add rcx, rsi
0003bb2c  ffe1                     jmp rcx
0003bb2e  0fb65708                 movzx edx, byte ptr [rdi + 8]
0003bb32  385308                   cmp byte ptr [rbx + 8], dl
0003bb35  7219                     jb 0x3bb50
0003bb37  b804000000               mov eax, 4
0003bb3c  b902000000               mov ecx, 2
0003bb41  0f44c1                   cmove eax, ecx
0003bb44  eb8d                     jmp 0x3bad3
0003bb46  0fb75708                 movzx edx, word ptr [rdi + 8]
0003bb4a  66395308                 cmp word ptr [rbx + 8], dx
0003bb4e  7de7                     jge 0x3bb37
0003bb50  b801000000               mov eax, 1
0003bb55  e979ffffff               jmp 0x3bad3
0003bb5a  8b5708                   mov edx, dword ptr [rdi + 8]
0003bb5d  395308                   cmp dword ptr [rbx + 8], edx
0003bb60  7dd5                     jge 0x3bb37
0003bb62  b801000000               mov eax, 1
0003bb67  e967ffffff               jmp 0x3bad3
0003bb6c  488b5708                 mov rdx, qword ptr [rdi + 8]
0003bb70  48395308                 cmp qword ptr [rbx + 8], rdx
0003bb74  7dc1                     jge 0x3bb37
0003bb76  b801000000               mov eax, 1
0003bb7b  e953ffffff               jmp 0x3bad3
0003bb80  f30f104708               movss xmm0, dword ptr [rdi + 8]
0003bb85  f30f104b08               movss xmm1, dword ptr [rbx + 8]
0003bb8a  0f2fc1                   comiss xmm0, xmm1
0003bb8d  77c1                     ja 0x3bb50
0003bb8f  0f2ec8                   ucomiss xmm1, xmm0
0003bb92  7a0b                     jp 0x3bb9f
0003bb94  b802000000               mov eax, 2
0003bb99  0f8434ffffff             je 0x3bad3
0003bb9f  b804000000               mov eax, 4
0003bba4  e92affffff               jmp 0x3bad3
0003bba9  f20f104708               movsd xmm0, qword ptr [rdi + 8]
0003bbae  f20f104b08               movsd xmm1, qword ptr [rbx + 8]
0003bbb3  660f2fc1                 comisd xmm0, xmm1
0003bbb7  7797                     ja 0x3bb50
0003bbb9  660f2ec8                 ucomisd xmm1, xmm0
0003bbbd  ebd3                     jmp 0x3bb92
0003bbbf  488d5708                 lea rdx, [rdi + 8]
0003bbc3  488d4b08                 lea rcx, [rbx + 8]
0003bbc7  e8a40a0000               call 0x3c670
0003bbcc  e902ffffff               jmp 0x3bad3
0003bbd1  0f57c0                   xorps xmm0, xmm0
0003bbd4  0f294540                 movaps xmmword ptr [rbp + 0x40], xmm0
0003bbd8  0f294550                 movaps xmmword ptr [rbp + 0x50], xmm0
0003bbdc  0f294560                 movaps xmmword ptr [rbp + 0x60], xmm0
0003bbe0  0f294570                 movaps xmmword ptr [rbp + 0x70], xmm0
0003bbe4  0f298580000000           movaps xmmword ptr [rbp + 0x80], xmm0
0003bbeb  0f298590000000           movaps xmmword ptr [rbp + 0x90], xmm0
0003bbf2  0f2985a0000000           movaps xmmword ptr [rbp + 0xa0], xmm0
0003bbf9  0f2985b0000000           movaps xmmword ptr [rbp + 0xb0], xmm0
0003bc00  488d35f18f0200           lea rsi, [rip + 0x28ff1]
0003bc07  48897540                 mov qword ptr [rbp + 0x40], rsi
0003bc0b  488d0516920200           lea rax, [rip + 0x29216]
0003bc12  48894540                 mov qword ptr [rbp + 0x40], rax
0003bc16  660f7f8580000000         movdqa xmmword ptr [rbp + 0x80], xmm0
0003bc1e  33d2                     xor edx, edx
0003bc20  48899590000000           mov qword ptr [rbp + 0x90], rdx
0003bc27  899598000000             mov dword ptr [rbp + 0x98], edx
0003bc2d  88959d000000             mov byte ptr [rbp + 0x9d], dl
0003bc33  488d05f68f0200           lea rax, [rip + 0x28ff6]
0003bc3a  48894540                 mov qword ptr [rbp + 0x40], rax
0003bc3e  488d5540                 lea rdx, [rbp + 0x40]
0003bc42  498bc9                   mov rcx, r9
0003bc45  e816cdffff               call 0x38960
0003bc4a  8b4710                   mov eax, dword ptr [rdi + 0x10]
0003bc4d  488b4f08                 mov rcx, qword ptr [rdi + 8]
0003bc51  8b5310                   mov edx, dword ptr [rbx + 0x10]
0003bc54  4c8b4308                 mov r8, qword ptr [rbx + 8]
0003bc58  89442440                 mov dword ptr [rsp + 0x40], eax
0003bc5c  48894c2438               mov qword ptr [rsp + 0x38], rcx
0003bc61  89542430                 mov dword ptr [rsp + 0x30], edx
0003bc65  4c89442428               mov qword ptr [rsp + 0x28], r8
0003bc6a  488d4540                 lea rax, [rbp + 0x40]
0003bc6e  4889442420               mov qword ptr [rsp + 0x20], rax
0003bc73  448b8d90000000           mov r9d, dword ptr [rbp + 0x90]
0003bc7a  4c8b8588000000           mov r8, qword ptr [rbp + 0x88]
0003bc81  8b9594000000             mov edx, dword ptr [rbp + 0x94]
0003bc87  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
0003bc8e  ff95a0000000             call qword ptr [rbp + 0xa0]
0003bc94  8bd0                     mov edx, eax
0003bc96  85c0                     test eax, eax
0003bc98  7907                     jns 0x3bca1
0003bc9a  b801000000               mov eax, 1
0003bc9f  eb0f                     jmp 0x3bcb0
0003bca1  b804000000               mov eax, 4
0003bca6  b902000000               mov ecx, 2
0003bcab  85d2                     test edx, edx
0003bcad  0f44c1                   cmove eax, ecx
0003bcb0  48897540                 mov qword ptr [rbp + 0x40], rsi
0003bcb4  e91afeffff               jmp 0x3bad3
0003bcb9  0f57c0                   xorps xmm0, xmm0
0003bcbc  0f294540                 movaps xmmword ptr [rbp + 0x40], xmm0
0003bcc0  0f294550                 movaps xmmword ptr [rbp + 0x50], xmm0
0003bcc4  0f294560                 movaps xmmword ptr [rbp + 0x60], xmm0
0003bcc8  0f294570                 movaps xmmword ptr [rbp + 0x70], xmm0
0003bccc  0f298580000000           movaps xmmword ptr [rbp + 0x80], xmm0
0003bcd3  0f298590000000           movaps xmmword ptr [rbp + 0x90], xmm0
0003bcda  0f2985a0000000           movaps xmmword ptr [rbp + 0xa0], xmm0
0003bce1  0f2985b0000000           movaps xmmword ptr [rbp + 0xb0], xmm0
0003bce8  488d35098f0200           lea rsi, [rip + 0x28f09]
0003bcef  48897540                 mov qword ptr [rbp + 0x40], rsi
0003bcf3  488d052e910200           lea rax, [rip + 0x2912e]
0003bcfa  48894540                 mov qword ptr [rbp + 0x40], rax
0003bcfe  660f7f8580000000         movdqa xmmword ptr [rbp + 0x80], xmm0
0003bd06  33d2                     xor edx, edx
0003bd08  48899590000000           mov qword ptr [rbp + 0x90], rdx
0003bd0f  899598000000             mov dword ptr [rbp + 0x98], edx
0003bd15  88959d000000             mov byte ptr [rbp + 0x9d], dl
0003bd1b  488d050e8f0200           lea rax, [rip + 0x28f0e]
0003bd22  48894540                 mov qword ptr [rbp + 0x40], rax
0003bd26  488d5540                 lea rdx, [rbp + 0x40]
0003bd2a  498bc9                   mov rcx, r9
0003bd2d  e82eccffff               call 0x38960
0003bd32  8b4710                   mov eax, dword ptr [rdi + 0x10]
0003bd35  488b4f08                 mov rcx, qword ptr [rdi + 8]
0003bd39  8b5310                   mov edx, dword ptr [rbx + 0x10]
0003bd3c  4c8b4308                 mov r8, qword ptr [rbx + 8]
0003bd40  89442440                 mov dword ptr [rsp + 0x40], eax
0003bd44  48894c2438               mov qword ptr [rsp + 0x38], rcx
0003bd49  89542430                 mov dword ptr [rsp + 0x30], edx
0003bd4d  4c89442428               mov qword ptr [rsp + 0x28], r8
0003bd52  488d4540                 lea rax, [rbp + 0x40]
0003bd56  4889442420               mov qword ptr [rsp + 0x20], rax
0003bd5b  448b8d90000000           mov r9d, dword ptr [rbp + 0x90]
0003bd62  4c8b8588000000           mov r8, qword ptr [rbp + 0x88]
0003bd69  8b9594000000             mov edx, dword ptr [rbp + 0x94]
0003bd6f  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
0003bd76  ff95a0000000             call qword ptr [rbp + 0xa0]
0003bd7c  8bd0                     mov edx, eax
0003bd7e  85c0                     test eax, eax
0003bd80  7907                     jns 0x3bd89
0003bd82  b801000000               mov eax, 1
0003bd87  eb0f                     jmp 0x3bd98
0003bd89  b804000000               mov eax, 4
0003bd8e  b902000000               mov ecx, 2
0003bd93  85d2                     test edx, edx
0003bd95  0f44c1                   cmove eax, ecx
0003bd98  48897540                 mov qword ptr [rbp + 0x40], rsi
0003bd9c  e932fdffff               jmp 0x3bad3
0003bda1  41f6410110               test byte ptr [r9 + 1], 0x10
0003bda6  7425                     je 0x3bdcd
0003bda8  80faf0                   cmp dl, 0xf0
0003bdab  7420                     je 0x3bdcd
0003bdad  410fb6411a               movzx eax, byte ptr [r9 + 0x1a]
0003bdb2  84c0                     test al, al
0003bdb4  7917                     jns 0x3bdcd
0003bdb6  c1e804                   shr eax, 4
0003bdb9  83e007                   and eax, 7
0003bdbc  7d07                     jge 0x3bdc5
0003bdbe  ffc8                     dec eax
0003bdc0  83c8f0                   or eax, 0xfffffff0
0003bdc3  ffc0                     inc eax
0003bdc5  3c02                     cmp al, 2
0003bdc7  0f8404fdffff             je 0x3bad1
0003bdcd  448b4f10                 mov r9d, dword ptr [rdi + 0x10]
0003bdd1  4c8b4708                 mov r8, qword ptr [rdi + 8]
0003bdd5  8b5310                   mov edx, dword ptr [rbx + 0x10]
0003bdd8  488b4b08                 mov rcx, qword ptr [rbx + 8]
0003bddc  e8ef2cffff               call 0x2ead0
0003bde1  8bd0                     mov edx, eax
0003bde3  85c0                     test eax, eax
0003bde5  0f89ac000000             jns 0x3be97
0003bdeb  b801000000               mov eax, 1
0003bdf0  e9defcffff               jmp 0x3bad3
0003bdf5  488b5308                 mov rdx, qword ptr [rbx + 8]
0003bdf9  483b5708                 cmp rdx, qword ptr [rdi + 8]
0003bdfd  0f8d34fdffff             jge 0x3bb37
0003be03  b801000000               mov eax, 1
0003be08  e9c6fcffff               jmp 0x3bad3
0003be0d  8b5308                   mov edx, dword ptr [rbx + 8]
0003be10  3b5708                   cmp edx, dword ptr [rdi + 8]
0003be13  0f831efdffff             jae 0x3bb37
0003be19  b801000000               mov eax, 1
0003be1e  e9b0fcffff               jmp 0x3bad3
0003be23  488bd7                   mov rdx, rdi
0003be26  488bcb                   mov rcx, rbx
0003be29  e8b234ffff               call 0x2f2e0
0003be2e  e9a0fcffff               jmp 0x3bad3
0003be33  8b5308                   mov edx, dword ptr [rbx + 8]
0003be36  3b5708                   cmp edx, dword ptr [rdi + 8]
0003be39  0f8df8fcffff             jge 0x3bb37
0003be3f  b801000000               mov eax, 1
0003be44  e98afcffff               jmp 0x3bad3
0003be49  488bd7                   mov rdx, rdi
0003be4c  488bcb                   mov rcx, rbx
0003be4f  e8ec34ffff               call 0x2f340
0003be54  e97afcffff               jmp 0x3bad3
0003be59  488d4708                 lea rax, [rdi + 8]
0003be5d  b908000000               mov ecx, 8
0003be62  482bd8                   sub rbx, rax
0003be65  0fb6540308               movzx edx, byte ptr [rbx + rax + 8]
0003be6a  3a10                     cmp dl, byte ptr [rax]
0003be6c  751e                     jne 0x3be8c
0003be6e  48ffc0                   inc rax
0003be71  83e901                   sub ecx, 1
0003be74  75ef                     jne 0x3be65
0003be76  33d2                     xor edx, edx
0003be78  b804000000               mov eax, 4
0003be7d  b902000000               mov ecx, 2
0003be82  85d2                     test edx, edx
0003be84  0f44c1                   cmove eax, ecx
0003be87  e947fcffff               jmp 0x3bad3
0003be8c  0f82befcffff             jb 0x3bb50
0003be92  ba01000000               mov edx, 1
0003be97  b804000000               mov eax, 4
0003be9c  b902000000               mov ecx, 2
0003bea1  85d2                     test edx, edx
0003bea3  0f44c1                   cmove eax, ecx
0003bea6  e928fcffff               jmp 0x3bad3
0003beab  410fb64813               movzx ecx, byte ptr [r8 + 0x13]
0003beb0  410fb64113               movzx eax, byte ptr [r9 + 0x13]
0003beb5  488d353c8d0200           lea rsi, [rip + 0x28d3c]
0003bebc  48897500                 mov qword ptr [rbp], rsi
0003bec0  488d1509900200           lea rdx, [rip + 0x29009]
0003bec7  48895500                 mov qword ptr [rbp], rdx
0003becb  894508                   mov dword ptr [rbp + 8], eax
0003bece  894d0c                   mov dword ptr [rbp + 0xc], ecx
0003bed1  4c8d4500                 lea r8, [rbp]
0003bed5  488bd7                   mov rdx, rdi
0003bed8  488bcb                   mov rcx, rbx
0003bedb  e82035ffff               call 0x2f400
0003bee0  90                       nop
0003bee1  48897500                 mov qword ptr [rbp], rsi
0003bee5  e9e9fbffff               jmp 0x3bad3
0003beea  410fb64813               movzx ecx, byte ptr [r8 + 0x13]
0003beef  410fb64113               movzx eax, byte ptr [r9 + 0x13]
0003bef4  488d35fd8c0200           lea rsi, [rip + 0x28cfd]
0003befb  48897500                 mov qword ptr [rbp], rsi
0003beff  488d15ca8f0200           lea rdx, [rip + 0x28fca]
0003bf06  48895500                 mov qword ptr [rbp], rdx
0003bf0a  894508                   mov dword ptr [rbp + 8], eax
0003bf0d  894d0c                   mov dword ptr [rbp + 0xc], ecx
0003bf10  4c8d4500                 lea r8, [rbp]
0003bf14  488bd7                   mov rdx, rdi
0003bf17  488bcb                   mov rcx, rbx
0003bf1a  e8c136ffff               call 0x2f5e0
0003bf1f  90                       nop
0003bf20  48897500                 mov qword ptr [rbp], rsi
0003bf24  e9aafbffff               jmp 0x3bad3
0003bf29  410fb64813               movzx ecx, byte ptr [r8 + 0x13]
0003bf2e  410fb64113               movzx eax, byte ptr [r9 + 0x13]
0003bf33  488d35be8c0200           lea rsi, [rip + 0x28cbe]
0003bf3a  48897500                 mov qword ptr [rbp], rsi
0003bf3e  488d158b8f0200           lea rdx, [rip + 0x28f8b]
0003bf45  48895500                 mov qword ptr [rbp], rdx
0003bf49  894508                   mov dword ptr [rbp + 8], eax
0003bf4c  894d0c                   mov dword ptr [rbp + 0xc], ecx
0003bf4f  4c8d4500                 lea r8, [rbp]
0003bf53  488bd7                   mov rdx, rdi
0003bf56  488bcb                   mov rcx, rbx
0003bf59  e89238ffff               call 0x2f7f0
0003bf5e  90                       nop
0003bf5f  48897500                 mov qword ptr [rbp], rsi
0003bf63  e96bfbffff               jmp 0x3bad3
0003bf68  d1ba030049be             sar dword ptr [rdx - 0x41b6fffd], 1
0003bf6e  0300                     add eax, dword ptr [rax]
0003bf70  23be0300abbe             and edi, dword ptr [rsi - 0x4154fffd]
0003bf76  0300                     add eax, dword ptr [rax]
