; CSqlSortManager_80::DBCompareStringWFast
; aetm_enclave.dll, primary RVA 0x43c50, 4800 bytes in 3 chunk(s)

; chunk at RVA 0x43c50 (112 bytes)
00043c50  4489442418               mov dword ptr [rsp + 0x18], r8d
00043c55  4889542410               mov qword ptr [rsp + 0x10], rdx
00043c5a  55                       push rbp
00043c5b  56                       push rsi
00043c5c  57                       push rdi
00043c5d  4154                     push r12
00043c5f  4156                     push r14
00043c61  4157                     push r15
00043c63  488d6c24e9               lea rbp, [rsp - 0x17]
00043c68  4881ec88000000           sub rsp, 0x88
00043c6f  448b756f                 mov r14d, dword ptr [rbp + 0x6f]
00043c73  33c9                     xor ecx, ecx
00043c75  4c8b7d77                 mov r15, qword ptr [rbp + 0x77]
00043c79  4d8be1                   mov r12, r9
00043c7c  894dd3                   mov dword ptr [rbp - 0x2d], ecx
00043c7f  458bc8                   mov r9d, r8d
00043c82  894dcf                   mov dword ptr [rbp - 0x31], ecx
00043c85  488bfa                   mov rdi, rdx
00043c88  894dcb                   mov dword ptr [rbp - 0x35], ecx
00043c8b  448bc1                   mov r8d, ecx
00043c8e  4585f6                   test r14d, r14d
00043c91  7405                     je 0x43c98
00043c93  4d85e4                   test r12, r12
00043c96  7415                     je 0x43cad
00043c98  8b757f                   mov esi, dword ptr [rbp + 0x7f]
00043c9b  85f6                     test esi, esi
00043c9d  7405                     je 0x43ca4
00043c9f  4d85ff                   test r15, r15
00043ca2  7409                     je 0x43cad
00043ca4  41f7c1f8effc77           test r9d, 0x77fceff8
00043cab  7413                     je 0x43cc0
00043cad  33c0                     xor eax, eax
00043caf  4881c488000000           add rsp, 0x88
00043cb6  415f                     pop r15
00043cb8  415e                     pop r14
00043cba  415c                     pop r12
00043cbc  5f                       pop rdi
00043cbd  5e                       pop rsi
00043cbe  5d                       pop rbp
00043cbf  c3                       ret

; chunk at RVA 0x43cc0 (4552 bytes)
00043cc0  4c89ac2480000000         mov qword ptr [rsp + 0x80], r13
00043cc8  4585f6                   test r14d, r14d
00043ccb  790b                     jns 0x43cd8
00043ccd  498bcc                   mov rcx, r12
00043cd0  e8db3b0000               call 0x478b0
00043cd5  448bf0                   mov r14d, eax
00043cd8  85f6                     test esi, esi
00043cda  790a                     jns 0x43ce6
00043cdc  498bcf                   mov rcx, r15
00043cdf  e8cc3b0000               call 0x478b0
00043ce4  8bf0                     mov esi, eax
00043ce6  418bc9                   mov ecx, r9d
00043ce9  48899c24c0000000         mov qword ptr [rsp + 0xc0], rbx
00043cf1  83e103                   and ecx, 3
00043cf4  488d0505c3fbff           lea rax, [rip - 0x43cfb]
00043cfb  418bd1                   mov edx, r9d
00043cfe  c1ea10                   shr edx, 0x10
00043d01  83e203                   and edx, 3
00043d04  8d0c91                   lea ecx, [rcx + rdx*4]
00043d07  33d2                     xor edx, edx
00043d09  448b948830050900         mov r10d, dword ptr [rax + rcx*4 + 0x90530]
00043d11  8bca                     mov ecx, edx
00043d13  44895577                 mov dword ptr [rbp + 0x77], r10d
00043d17  488955ff                 mov qword ptr [rbp - 1], rdx
00043d1b  488955f7                 mov qword ptr [rbp - 9], rdx
00043d1f  448d6a07                 lea r13d, [rdx + 7]
00043d23  448d4a01                 lea r9d, [rdx + 1]
00043d27  4585f6                   test r14d, r14d
00043d2a  7458                     je 0x43d84
00043d2c  85f6                     test esi, esi
00043d2e  7454                     je 0x43d84
00043d30  488b4f08                 mov rcx, qword ptr [rdi + 8]
00043d34  410fb70424               movzx eax, word ptr [r12]
00043d39  448b1c81                 mov r11d, dword ptr [rcx + rax*4]
00043d3d  410fb707                 movzx eax, word ptr [r15]
00043d41  4523da                   and r11d, r10d
00043d44  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00043d48  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00043d4c  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
00043d4f  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043d52  4123da                   and ebx, r10d
00043d55  8945ef                   mov dword ptr [rbp - 0x11], eax
00043d58  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043d5b  8945e3                   mov dword ptr [rbp - 0x1d], eax
00043d5e  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043d61  894567                   mov dword ptr [rbp + 0x67], eax
00043d64  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043d67  8945df                   mov dword ptr [rbp - 0x21], eax
00043d6a  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043d6d  8945d7                   mov dword ptr [rbp - 0x29], eax
00043d70  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043d73  895daf                   mov dword ptr [rbp - 0x51], ebx
00043d76  8945db                   mov dword ptr [rbp - 0x25], eax
00043d79  8b45af                   mov eax, dword ptr [rbp - 0x51]
00043d7c  8945c7                   mov dword ptr [rbp - 0x39], eax
00043d7f  e9cb000000               jmp 0x43e4f
00043d84  448b5db3                 mov r11d, dword ptr [rbp - 0x4d]
00043d88  8b5db7                   mov ebx, dword ptr [rbp - 0x49]
00043d8b  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00043d8f  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043d92  8b556f                   mov edx, dword ptr [rbp + 0x6f]
00043d95  8945ef                   mov dword ptr [rbp - 0x11], eax
00043d98  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043d9b  8945e3                   mov dword ptr [rbp - 0x1d], eax
00043d9e  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043da1  8945df                   mov dword ptr [rbp - 0x21], eax
00043da4  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043da7  8945d7                   mov dword ptr [rbp - 0x29], eax
00043daa  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043dad  895daf                   mov dword ptr [rbp - 0x51], ebx
00043db0  8945db                   mov dword ptr [rbp - 0x25], eax
00043db3  8b45af                   mov eax, dword ptr [rbp - 0x51]
00043db6  8945c7                   mov dword ptr [rbp - 0x39], eax
00043db9  895567                   mov dword ptr [rbp + 0x67], edx
00043dbc  eb04                     jmp 0x43dc2
00043dbe  488b4df7                 mov rcx, qword ptr [rbp - 9]
00043dc2  f7455f00000008           test dword ptr [rbp + 0x5f], 0x8000000
00043dc9  0f84fd0f0000             je 0x44dcc
00043dcf  4585f6                   test r14d, r14d
00043dd2  7540                     jne 0x43e14
00043dd4  85f6                     test esi, esi
00043dd6  0f84bc100000             je 0x44e98
00043ddc  488b4f08                 mov rcx, qword ptr [rdi + 8]
00043de0  4c8d65e7                 lea r12, [rbp - 0x19]
00043de4  b820000000               mov eax, 0x20
00043de9  458bf1                   mov r14d, r9d
00043dec  668945e7                 mov word ptr [rbp - 0x19], ax
00043df0  448b9980000000           mov r11d, dword ptr [rcx + 0x80]
00043df7  4523da                   and r11d, r10d
00043dfa  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00043dfe  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00043e02  4585c0                   test r8d, r8d
00043e05  0f85ab0f0000             jne 0x44db6
00043e0b  410fb707                 movzx eax, word ptr [r15]
00043e0f  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
00043e12  eb33                     jmp 0x43e47
00043e14  488b4f08                 mov rcx, qword ptr [rdi + 8]
00043e18  b820000000               mov eax, 0x20
00043e1d  668945eb                 mov word ptr [rbp - 0x15], ax
00043e21  4c8d7deb                 lea r15, [rbp - 0x15]
00043e25  418bf1                   mov esi, r9d
00043e28  4585c0                   test r8d, r8d
00043e2b  7514                     jne 0x43e41
00043e2d  410fb70424               movzx eax, word ptr [r12]
00043e32  448b1c81                 mov r11d, dword ptr [rcx + rax*4]
00043e36  4523da                   and r11d, r10d
00043e39  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00043e3d  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00043e41  8b9980000000             mov ebx, dword ptr [rcx + 0x80]
00043e47  4123da                   and ebx, r10d
00043e4a  33d2                     xor edx, edx
00043e4c  895daf                   mov dword ptr [rbp - 0x51], ebx
00043e4f  895db7                   mov dword ptr [rbp - 0x49], ebx
00043e52  837f1400                 cmp dword ptr [rdi + 0x14], 0
00043e56  8955bf                   mov dword ptr [rbp - 0x41], edx
00043e59  0f8430030000             je 0x4418f
00043e5f  48837dff00               cmp qword ptr [rbp - 1], 0
00043e64  0f85a1000000             jne 0x43f0b
00043e6a  418bc3                   mov eax, r11d
00043e6d  c1e818                   shr eax, 0x18
00043e70  a8c0                     test al, 0xc0
00043e72  0f8493000000             je 0x43f0b
00043e78  837f1800                 cmp dword ptr [rdi + 0x18], 0
00043e7c  7431                     je 0x43eaf
00043e7e  4183fe01                 cmp r14d, 1
00043e82  0f8ed6000000             jle 0x43f5e
00043e88  410fb74c2402             movzx ecx, word ptr [r12 + 2]
00043e8e  418bd3                   mov edx, r11d
00043e91  488b4708                 mov rax, qword ptr [rdi + 8]
00043e95  331488                   xor edx, dword ptr [rax + rcx*4]
00043e98  f7c2ffffffe7             test edx, 0xe7ffffff
00043e9e  0f85ba000000             jne 0x43f5e
00043ea4  4983c402                 add r12, 2
00043ea8  44894dd3                 mov dword ptr [rbp - 0x2d], r9d
00043eac  41ffce                   dec r14d
00043eaf  33c0                     xor eax, eax
00043eb1  418bce                   mov ecx, r14d
00043eb4  440fb7d0                 movzx r10d, ax
00043eb8  440fb7c8                 movzx r9d, ax
00043ebc  83e901                   sub ecx, 1
00043ebf  7411                     je 0x43ed2
00043ec1  83f901                   cmp ecx, 1
00043ec4  7406                     je 0x43ecc
00043ec6  450fb7542404             movzx r10d, word ptr [r12 + 4]
00043ecc  450fb74c2402             movzx r9d, word ptr [r12 + 2]
00043ed2  4c8b4720                 mov r8, qword ptr [rdi + 0x20]
00043ed6  410fb70c24               movzx ecx, word ptr [r12]
00043edb  410fb74004               movzx eax, word ptr [r8 + 4]
00043ee0  85c0                     test eax, eax
00043ee2  7410                     je 0x43ef4
00043ee4  6641394806               cmp word ptr [r8 + 6], cx
00043ee9  767d                     jbe 0x43f68
00043eeb  4983c010                 add r8, 0x10
00043eef  83e801                   sub eax, 1
00043ef2  75f0                     jne 0x43ee4
00043ef4  448b5577                 mov r10d, dword ptr [rbp + 0x77]
00043ef8  837dd300                 cmp dword ptr [rbp - 0x2d], 0
00043efc  41b901000000             mov r9d, 1
00043f02  7407                     je 0x43f0b
00043f04  4983ec02                 sub r12, 2
00043f08  41ffc6                   inc r14d
00043f0b  48837df700               cmp qword ptr [rbp - 9], 0
00043f10  0f8579020000             jne 0x4418f
00043f16  f645bac0                 test byte ptr [rbp - 0x46], 0xc0
00043f1a  0f846f020000             je 0x4418f
00043f20  837f1800                 cmp dword ptr [rdi + 0x18], 0
00043f24  0f8441010000             je 0x4406b
00043f2a  83fe01                   cmp esi, 1
00043f2d  0f8e2f010000             jle 0x44062
00043f33  410fb74f02               movzx ecx, word ptr [r15 + 2]
00043f38  8bd3                     mov edx, ebx
00043f3a  488b4708                 mov rax, qword ptr [rdi + 8]
00043f3e  331488                   xor edx, dword ptr [rax + rcx*4]
00043f41  f7c2ffffffe7             test edx, 0xe7ffffff
00043f47  0f8515010000             jne 0x44062
00043f4d  418bd9                   mov ebx, r9d
00043f50  4983c702                 add r15, 2
00043f54  895dd3                   mov dword ptr [rbp - 0x2d], ebx
00043f57  ffce                     dec esi
00043f59  e910010000               jmp 0x4406e
00043f5e  33c0                     xor eax, eax
00043f60  8945d3                   mov dword ptr [rbp - 0x2d], eax
00043f63  e949ffffff               jmp 0x43eb1
00043f68  758a                     jne 0x43ef4
00043f6a  66453b480c               cmp r9w, word ptr [r8 + 0xc]
00043f6f  7283                     jb 0x43ef4
00043f71  66453b480e               cmp r9w, word ptr [r8 + 0xe]
00043f76  0f8778ffffff             ja 0x43ef4
00043f7c  488b4728                 mov rax, qword ptr [rdi + 0x28]
00043f80  410fb74808               movzx ecx, word ptr [r8 + 8]
00043f85  488d14c8                 lea rdx, [rax + rcx*8]
00043f89  410fb7400a               movzx eax, word ptr [r8 + 0xa]
00043f8e  85c0                     test eax, eax
00043f90  0f845effffff             je 0x43ef4
00043f96  6644390a                 cmp word ptr [rdx], r9w
00043f9a  7618                     jbe 0x43fb4
00043f9c  4883c208                 add rdx, 8
00043fa0  83e801                   sub eax, 1
00043fa3  75f1                     jne 0x43f96
00043fa5  e94affffff               jmp 0x43ef4
00043faa  660f1f440000             nop word ptr [rax + rax]
00043fb0  6644390a                 cmp word ptr [rdx], r9w
00043fb4  0f853affffff             jne 0x43ef4
00043fba  0fb74a02                 movzx ecx, word ptr [rdx + 2]
00043fbe  6685c9                   test cx, cx
00043fc1  745a                     je 0x4401d
00043fc3  66413bca                 cmp cx, r10w
00043fc7  740e                     je 0x43fd7
00043fc9  4883c208                 add rdx, 8
00043fcd  83e801                   sub eax, 1
00043fd0  75de                     jne 0x43fb0
00043fd2  e91dffffff               jmp 0x43ef4
00043fd7  448b5a04                 mov r11d, dword ptr [rdx + 4]
00043fdb  44235d77                 and r11d, dword ptr [rbp + 0x77]
00043fdf  488b4708                 mov rax, qword ptr [rdi + 8]
00043fe3  410fb7ca                 movzx ecx, r10w
00043fe7  448b5577                 mov r10d, dword ptr [rbp + 0x77]
00043feb  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00043fef  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00043ff3  8b1488                   mov edx, dword ptr [rax + rcx*4]
00043ff6  498d442404               lea rax, [r12 + 4]
00043ffb  8b4dd3                   mov ecx, dword ptr [rbp - 0x2d]
00043ffe  4123d2                   and edx, r10d
00044001  85c9                     test ecx, ecx
00044003  8955cf                   mov dword ptr [rbp - 0x31], edx
00044006  490f45c4                 cmovne rax, r12
0004400a  4c8be0                   mov r12, rax
0004400d  418d46fe                 lea eax, [r14 - 2]
00044011  410f45c6                 cmovne eax, r14d
00044015  448bf0                   mov r14d, eax
00044018  e9dbfeffff               jmp 0x43ef8
0004401d  488b4708                 mov rax, qword ptr [rdi + 8]
00044021  448b5577                 mov r10d, dword ptr [rbp + 0x77]
00044025  448b5a04                 mov r11d, dword ptr [rdx + 4]
00044029  4523da                   and r11d, r10d
0004402c  410fb7c9                 movzx ecx, r9w
00044030  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00044034  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00044038  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004403b  8b4dd3                   mov ecx, dword ptr [rbp - 0x2d]
0004403e  4123c2                   and eax, r10d
00044041  8945cf                   mov dword ptr [rbp - 0x31], eax
00044044  85c9                     test ecx, ecx
00044046  498d442402               lea rax, [r12 + 2]
0004404b  490f45c4                 cmovne rax, r12
0004404f  4c8be0                   mov r12, rax
00044052  418d46ff                 lea eax, [r14 - 1]
00044056  410f45c6                 cmovne eax, r14d
0004405a  448bf0                   mov r14d, eax
0004405d  e996feffff               jmp 0x43ef8
00044062  33c0                     xor eax, eax
00044064  8bd8                     mov ebx, eax
00044066  8945d3                   mov dword ptr [rbp - 0x2d], eax
00044069  eb05                     jmp 0x44070
0004406b  8b5dd3                   mov ebx, dword ptr [rbp - 0x2d]
0004406e  33c0                     xor eax, eax
00044070  8bce                     mov ecx, esi
00044072  440fb7c8                 movzx r9d, ax
00044076  440fb7c0                 movzx r8d, ax
0004407a  83e901                   sub ecx, 1
0004407d  740f                     je 0x4408e
0004407f  83f901                   cmp ecx, 1
00044082  7405                     je 0x44089
00044084  450fb74f04               movzx r9d, word ptr [r15 + 4]
00044089  450fb74702               movzx r8d, word ptr [r15 + 2]
0004408e  488b5720                 mov rdx, qword ptr [rdi + 0x20]
00044092  410fb70f                 movzx ecx, word ptr [r15]
00044096  0fb74204                 movzx eax, word ptr [rdx + 4]
0004409a  85c0                     test eax, eax
0004409c  0f84e3000000             je 0x44185
000440a2  66394a06                 cmp word ptr [rdx + 6], cx
000440a6  760e                     jbe 0x440b6
000440a8  4883c210                 add rdx, 0x10
000440ac  83e801                   sub eax, 1
000440af  75f1                     jne 0x440a2
000440b1  e9cf000000               jmp 0x44185
000440b6  0f85c9000000             jne 0x44185
000440bc  66443b420c               cmp r8w, word ptr [rdx + 0xc]
000440c1  0f82be000000             jb 0x44185
000440c7  66443b420e               cmp r8w, word ptr [rdx + 0xe]
000440cc  0f87b3000000             ja 0x44185
000440d2  0fb74a08                 movzx ecx, word ptr [rdx + 8]
000440d6  488b4728                 mov rax, qword ptr [rdi + 0x28]
000440da  488d04c8                 lea rax, [rax + rcx*8]
000440de  0fb74a0a                 movzx ecx, word ptr [rdx + 0xa]
000440e2  85c9                     test ecx, ecx
000440e4  0f849b000000             je 0x44185
000440ea  660f1f440000             nop word ptr [rax + rax]
000440f0  66443900                 cmp word ptr [rax], r8w
000440f4  7612                     jbe 0x44108
000440f6  4883c008                 add rax, 8
000440fa  83e901                   sub ecx, 1
000440fd  75f1                     jne 0x440f0
000440ff  e981000000               jmp 0x44185
00044104  66443900                 cmp word ptr [rax], r8w
00044108  757b                     jne 0x44185
0004410a  0fb75002                 movzx edx, word ptr [rax + 2]
0004410e  6685d2                   test dx, dx
00044111  7440                     je 0x44153
00044113  66413bd1                 cmp dx, r9w
00044117  740b                     je 0x44124
00044119  4883c008                 add rax, 8
0004411d  83e901                   sub ecx, 1
00044120  75e2                     jne 0x44104
00044122  eb61                     jmp 0x44185
00044124  8b5004                   mov edx, dword ptr [rax + 4]
00044127  488b4708                 mov rax, qword ptr [rdi + 8]
0004412b  4123d2                   and edx, r10d
0004412e  410fb7c9                 movzx ecx, r9w
00044132  8955af                   mov dword ptr [rbp - 0x51], edx
00044135  8955b7                   mov dword ptr [rbp - 0x49], edx
00044138  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004413b  498d4704                 lea rax, [r15 + 4]
0004413f  4123ca                   and ecx, r10d
00044142  85db                     test ebx, ebx
00044144  894dcb                   mov dword ptr [rbp - 0x35], ecx
00044147  490f45c7                 cmovne rax, r15
0004414b  4c8bf8                   mov r15, rax
0004414e  8d46fe                   lea eax, [rsi - 2]
00044151  eb2d                     jmp 0x44180
00044153  8b4004                   mov eax, dword ptr [rax + 4]
00044156  4123c2                   and eax, r10d
00044159  410fb7c8                 movzx ecx, r8w
0004415d  8945af                   mov dword ptr [rbp - 0x51], eax
00044160  8945b7                   mov dword ptr [rbp - 0x49], eax
00044163  488b4708                 mov rax, qword ptr [rdi + 8]
00044167  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004416a  4123c2                   and eax, r10d
0004416d  8945cb                   mov dword ptr [rbp - 0x35], eax
00044170  85db                     test ebx, ebx
00044172  498d4702                 lea rax, [r15 + 2]
00044176  490f45c7                 cmovne rax, r15
0004417a  4c8bf8                   mov r15, rax
0004417d  8d46ff                   lea eax, [rsi - 1]
00044180  0f45c6                   cmovne eax, esi
00044183  8bf0                     mov esi, eax
00044185  85db                     test ebx, ebx
00044187  7406                     je 0x4418f
00044189  4983ef02                 sub r15, 2
0004418d  ffc6                     inc esi
0004418f  0fb75db3                 movzx ebx, word ptr [rbp - 0x4d]
00044193  0fb77db7                 movzx edi, word ptr [rbp - 0x49]
00044197  440fb7d3                 movzx r10d, bx
0004419b  440fb7cf                 movzx r9d, di
0004419f  6641c1ea08               shr r10w, 8
000441a4  6641c1e908               shr r9w, 8
000441a9  4180fa0b                 cmp r10b, 0xb
000441ad  7615                     jbe 0x441c4
000441af  4180f90b                 cmp r9b, 0xb
000441b3  7649                     jbe 0x441fe
000441b5  8b45af                   mov eax, dword ptr [rbp - 0x51]
000441b8  8945cb                   mov dword ptr [rbp - 0x35], eax
000441bb  44895dcf                 mov dword ptr [rbp - 0x31], r11d
000441bf  e9c0080000               jmp 0x44a84
000441c4  4584d2                   test r10b, r10b
000441c7  7535                     jne 0x441fe
000441c9  488b5557                 mov rdx, qword ptr [rbp + 0x57]
000441cd  4983c402                 add r12, 2
000441d1  448b5d77                 mov r11d, dword ptr [rbp + 0x77]
000441d5  4183ee01                 sub r14d, 1
000441d9  7415                     je 0x441f0
000441db  410fb70c24               movzx ecx, word ptr [r12]
000441e0  488b4208                 mov rax, qword ptr [rdx + 8]
000441e4  8b0488                   mov eax, dword ptr [rax + rcx*4]
000441e7  4123c3                   and eax, r11d
000441ea  89456f                   mov dword ptr [rbp + 0x6f], eax
000441ed  8945b3                   mov dword ptr [rbp - 0x4d], eax
000441f0  41b801000000             mov r8d, 1
000441f6  418bc0                   mov eax, r8d
000441f9  8945bf                   mov dword ptr [rbp - 0x41], eax
000441fc  eb11                     jmp 0x4420f
000441fe  448b5d77                 mov r11d, dword ptr [rbp + 0x77]
00044202  41b801000000             mov r8d, 1
00044208  8b45bf                   mov eax, dword ptr [rbp - 0x41]
0004420b  488b5557                 mov rdx, qword ptr [rbp + 0x57]
0004420f  4584c9                   test r9b, r9b
00044212  7523                     jne 0x44237
00044214  4983c702                 add r15, 2
00044218  83ee01                   sub esi, 1
0004421b  7414                     je 0x44231
0004421d  410fb70f                 movzx ecx, word ptr [r15]
00044221  488b4208                 mov rax, qword ptr [rdx + 8]
00044225  8b0488                   mov eax, dword ptr [rax + rcx*4]
00044228  4123c3                   and eax, r11d
0004422b  8945af                   mov dword ptr [rbp - 0x51], eax
0004422e  8945b7                   mov dword ptr [rbp - 0x49], eax
00044231  418bc0                   mov eax, r8d
00044234  8945bf                   mov dword ptr [rbp - 0x41], eax
00044237  448b5d5f                 mov r11d, dword ptr [rbp + 0x5f]
0004423b  4183e302                 and r11d, 2
0004423f  44895dbb                 mov dword ptr [rbp - 0x45], r11d
00044243  7454                     je 0x44299
00044245  4180fa01                 cmp r10b, 1
00044249  7525                     jne 0x44270
0004424b  4983c402                 add r12, 2
0004424f  4183ee01                 sub r14d, 1
00044253  7415                     je 0x4426a
00044255  410fb70c24               movzx ecx, word ptr [r12]
0004425a  488b4208                 mov rax, qword ptr [rdx + 8]
0004425e  8b0488                   mov eax, dword ptr [rax + rcx*4]
00044261  234577                   and eax, dword ptr [rbp + 0x77]
00044264  89456f                   mov dword ptr [rbp + 0x6f], eax
00044267  8945b3                   mov dword ptr [rbp - 0x4d], eax
0004426a  418bc0                   mov eax, r8d
0004426d  8945bf                   mov dword ptr [rbp - 0x41], eax
00044270  4180f901                 cmp r9b, 1
00044274  7523                     jne 0x44299
00044276  4983c702                 add r15, 2
0004427a  83ee01                   sub esi, 1
0004427d  7414                     je 0x44293
0004427f  410fb70f                 movzx ecx, word ptr [r15]
00044283  488b4208                 mov rax, qword ptr [rdx + 8]
00044287  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004428a  234577                   and eax, dword ptr [rbp + 0x77]
0004428d  8945af                   mov dword ptr [rbp - 0x51], eax
00044290  8945b7                   mov dword ptr [rbp - 0x49], eax
00044293  418bc0                   mov eax, r8d
00044296  8945bf                   mov dword ptr [rbp - 0x41], eax
00044299  498bd7                   mov rdx, r15
0004429c  4d8bc4                   mov r8, r12
0004429f  4180fa02                 cmp r10b, 2
000442a3  756d                     jne 0x44312
000442a5  0fb645b3                 movzx eax, byte ptr [rbp - 0x4d]
000442a9  4c8d1d50bdfbff           lea r11, [rip - 0x442b0]
000442b0  488d0d49bdfbff           lea rcx, [rip - 0x442b7]
000442b7  c745ef02000000           mov dword ptr [rbp - 0x11], 2
000442be  41ffc6                   inc r14d
000442c1  4c8d65e7                 lea r12, [rbp - 0x19]
000442c5  0fb78c8170a43500         movzx ecx, word ptr [rcx + rax*4 + 0x35a470]
000442cd  410fb7848372a43500       movzx eax, word ptr [r11 + rax*4 + 0x35a472]
000442d6  448b5dbb                 mov r11d, dword ptr [rbp - 0x45]
000442da  668945e9                 mov word ptr [rbp - 0x17], ax
000442de  488b4557                 mov rax, qword ptr [rbp + 0x57]
000442e2  66894de7                 mov word ptr [rbp - 0x19], cx
000442e6  488b4008                 mov rax, qword ptr [rax + 8]
000442ea  8b0488                   mov eax, dword ptr [rax + rcx*4]
000442ed  234577                   and eax, dword ptr [rbp + 0x77]
000442f0  488b4dff                 mov rcx, qword ptr [rbp - 1]
000442f4  89456f                   mov dword ptr [rbp + 0x6f], eax
000442f7  8945b3                   mov dword ptr [rbp - 0x4d], eax
000442fa  33c0                     xor eax, eax
000442fc  4885c9                   test rcx, rcx
000442ff  8945cf                   mov dword ptr [rbp - 0x31], eax
00044302  b801000000               mov eax, 1
00044307  4c0f45c1                 cmovne r8, rcx
0004430b  8945bf                   mov dword ptr [rbp - 0x41], eax
0004430e  4c8945ff                 mov qword ptr [rbp - 1], r8
00044312  4180f902                 cmp r9b, 2
00044316  756c                     jne 0x44384
00044318  0fb645b7                 movzx eax, byte ptr [rbp - 0x49]
0004431c  4c8d05ddbcfbff           lea r8, [rip - 0x44323]
00044323  488b7d57                 mov rdi, qword ptr [rbp + 0x57]
00044327  4c8d7deb                 lea r15, [rbp - 0x15]
0004432b  448b5577                 mov r10d, dword ptr [rbp + 0x77]
0004432f  ffc6                     inc esi
00044331  41b901000000             mov r9d, 1
00044337  c745e302000000           mov dword ptr [rbp - 0x1d], 2
0004433e  410fb78c8070a43500       movzx ecx, word ptr [r8 + rax*4 + 0x35a470]
00044347  410fb7848072a43500       movzx eax, word ptr [r8 + rax*4 + 0x35a472]
00044350  458bc1                   mov r8d, r9d
00044353  668945ed                 mov word ptr [rbp - 0x13], ax
00044357  488b4708                 mov rax, qword ptr [rdi + 8]
0004435b  66894deb                 mov word ptr [rbp - 0x15], cx
0004435f  8b1c88                   mov ebx, dword ptr [rax + rcx*4]
00044362  33c0                     xor eax, eax
00044364  488b4df7                 mov rcx, qword ptr [rbp - 9]
00044368  4123da                   and ebx, r10d
0004436b  4885c9                   test rcx, rcx
0004436e  895daf                   mov dword ptr [rbp - 0x51], ebx
00044371  895db7                   mov dword ptr [rbp - 0x49], ebx
00044374  480f45d1                 cmovne rdx, rcx
00044378  8945cb                   mov dword ptr [rbp - 0x35], eax
0004437b  488bca                   mov rcx, rdx
0004437e  488955f7                 mov qword ptr [rbp - 9], rdx
00044382  eb1d                     jmp 0x443a1
00044384  85c0                     test eax, eax
00044386  7438                     je 0x443c0
00044388  8b5daf                   mov ebx, dword ptr [rbp - 0x51]
0004438b  41b901000000             mov r9d, 1
00044391  488b7d57                 mov rdi, qword ptr [rbp + 0x57]
00044395  448b45bf                 mov r8d, dword ptr [rbp - 0x41]
00044399  448b5577                 mov r10d, dword ptr [rbp + 0x77]
0004439d  488b4df7                 mov rcx, qword ptr [rbp - 9]
000443a1  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
000443a5  8b5567                   mov edx, dword ptr [rbp + 0x67]
000443a8  4585f6                   test r14d, r14d
000443ab  0f8411faffff             je 0x43dc2
000443b1  85f6                     test esi, esi
000443b3  0f8409faffff             je 0x43dc2
000443b9  33d2                     xor edx, edx
000443bb  e992faffff               jmp 0x43e52
000443c0  410fb6c2                 movzx eax, r10b
000443c4  83f806                   cmp eax, 6
000443c7  0f870d010000             ja 0x444da
000443cd  488d152cbcfbff           lea rdx, [rip - 0x443d4]
000443d4  8b8c82a84e0400           mov ecx, dword ptr [rdx + rax*4 + 0x44ea8]
000443db  4803ca                   add rcx, rdx
000443de  ffe1                     jmp rcx
000443e0  453aca                   cmp r9b, r10b
000443e3  0f84fb000000             je 0x444e4
000443e9  4c8b4557                 mov r8, qword ptr [rbp + 0x57]
000443ed  4585ed                   test r13d, r13d
000443f0  7f07                     jg 0x443f9
000443f2  4183781000               cmp dword ptr [r8 + 0x10], 0
000443f7  740c                     je 0x44405
000443f9  33c0                     xor eax, eax
000443fb  c7456703000000           mov dword ptr [rbp + 0x67], 3
00044402  448be8                   mov r13d, eax
00044405  418d46ff                 lea eax, [r14 - 1]
00044409  85c0                     test eax, eax
0004440b  741e                     je 0x4442b
0004440d  498b5008                 mov rdx, qword ptr [r8 + 8]
00044411  410fb7442402             movzx eax, word ptr [r12 + 2]
00044417  807c820101               cmp byte ptr [rdx + rax*4 + 1], 1
0004441c  750d                     jne 0x4442b
0004441e  4983c402                 add r12, 2
00044422  41ffce                   dec r14d
00044425  4183fe01                 cmp r14d, 1
00044429  75e6                     jne 0x44411
0004442b  4983c402                 add r12, 2
0004442f  4183ee01                 sub r14d, 1
00044433  7426                     je 0x4445b
00044435  498b4008                 mov rax, qword ptr [r8 + 8]
00044439  ba01000000               mov edx, 1
0004443e  410fb70c24               movzx ecx, word ptr [r12]
00044443  8955bf                   mov dword ptr [rbp - 0x41], edx
00044446  448b0488                 mov r8d, dword ptr [rax + rcx*4]
0004444a  44234577                 and r8d, dword ptr [rbp + 0x77]
0004444e  4489456f                 mov dword ptr [rbp + 0x6f], r8d
00044452  448945b3                 mov dword ptr [rbp - 0x4d], r8d
00044456  e990000000               jmp 0x444eb
0004445b  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
0004445f  ba01000000               mov edx, 1
00044464  8955bf                   mov dword ptr [rbp - 0x41], edx
00044467  e97f000000               jmp 0x444eb
0004446c  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
00044470  448945cf                 mov dword ptr [rbp - 0x31], r8d
00044474  4180f906                 cmp r9b, 6
00044478  746e                     je 0x444e8
0004447a  4183fd06                 cmp r13d, 6
0004447e  7f08                     jg 0x44488
00044480  7527                     jne 0x444a9
00044482  837ddf00                 cmp dword ptr [rbp - 0x21], 0
00044486  7521                     jne 0x444a9
00044488  33c0                     xor eax, eax
0004448a  c745df01000000           mov dword ptr [rbp - 0x21], 1
00044491  4183fd06                 cmp r13d, 6
00044495  c7456703000000           mov dword ptr [rbp + 0x67], 3
0004449c  41bd06000000             mov r13d, 6
000444a2  0f4e45d7                 cmovle eax, dword ptr [rbp - 0x29]
000444a6  8945d7                   mov dword ptr [rbp - 0x29], eax
000444a9  4983c402                 add r12, 2
000444ad  4183ee01                 sub r14d, 1
000444b1  741d                     je 0x444d0
000444b3  488b4557                 mov rax, qword ptr [rbp + 0x57]
000444b7  410fb70c24               movzx ecx, word ptr [r12]
000444bc  488b4008                 mov rax, qword ptr [rax + 8]
000444c0  448b0488                 mov r8d, dword ptr [rax + rcx*4]
000444c4  44234577                 and r8d, dword ptr [rbp + 0x77]
000444c8  4489456f                 mov dword ptr [rbp + 0x6f], r8d
000444cc  448945b3                 mov dword ptr [rbp - 0x4d], r8d
000444d0  ba01000000               mov edx, 1
000444d5  8955bf                   mov dword ptr [rbp - 0x41], edx
000444d8  eb11                     jmp 0x444eb
000444da  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
000444de  448945cf                 mov dword ptr [rbp - 0x31], r8d
000444e2  eb04                     jmp 0x444e8
000444e4  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
000444e8  8b55bf                   mov edx, dword ptr [rbp - 0x41]
000444eb  410fb6c1                 movzx eax, r9b
000444ef  83f806                   cmp eax, 6
000444f2  0f8702020000             ja 0x446fa
000444f8  488d0d01bbfbff           lea rcx, [rip - 0x444ff]
000444ff  8b8c81c44e0400           mov ecx, dword ptr [rcx + rax*4 + 0x44ec4]
00044506  488d05f3bafbff           lea rax, [rip - 0x4450d]
0004450d  4803c8                   add rcx, rax
00044510  ffe1                     jmp rcx
00044512  453aca                   cmp r9b, r10b
00044515  0f84e5010000             je 0x44700
0004451b  4c8b4557                 mov r8, qword ptr [rbp + 0x57]
0004451f  4585ed                   test r13d, r13d
00044522  7f07                     jg 0x4452b
00044524  4183781000               cmp dword ptr [r8 + 0x10], 0
00044529  7411                     je 0x4453c
0004452b  41b901000000             mov r9d, 1
00044531  33c0                     xor eax, eax
00044533  44894d67                 mov dword ptr [rbp + 0x67], r9d
00044537  448be8                   mov r13d, eax
0004453a  eb06                     jmp 0x44542
0004453c  41b901000000             mov r9d, 1
00044542  8d46ff                   lea eax, [rsi - 1]
00044545  85c0                     test eax, eax
00044547  741e                     je 0x44567
00044549  498b5008                 mov rdx, qword ptr [r8 + 8]
0004454d  0f1f00                   nop dword ptr [rax]
00044550  410fb74702               movzx eax, word ptr [r15 + 2]
00044555  807c820101               cmp byte ptr [rdx + rax*4 + 1], 1
0004455a  750b                     jne 0x44567
0004455c  4983c702                 add r15, 2
00044560  ffce                     dec esi
00044562  83fe01                   cmp esi, 1
00044565  75e9                     jne 0x44550
00044567  4983c702                 add r15, 2
0004456b  83ee01                   sub esi, 1
0004456e  7414                     je 0x44584
00044570  410fb70f                 movzx ecx, word ptr [r15]
00044574  498b4008                 mov rax, qword ptr [r8 + 8]
00044578  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004457b  234577                   and eax, dword ptr [rbp + 0x77]
0004457e  8945af                   mov dword ptr [rbp - 0x51], eax
00044581  8945b7                   mov dword ptr [rbp - 0x49], eax
00044584  458bc1                   mov r8d, r9d
00044587  e982010000               jmp 0x4470e
0004458c  8b45af                   mov eax, dword ptr [rbp - 0x51]
0004458f  8945cb                   mov dword ptr [rbp - 0x35], eax
00044592  4180fa06                 cmp r10b, 6
00044596  743a                     je 0x445d2
00044598  4183fd06                 cmp r13d, 6
0004459c  7f10                     jg 0x445ae
0004459e  0f8526010000             jne 0x446ca
000445a4  837dd700                 cmp dword ptr [rbp - 0x29], 0
000445a8  0f851c010000             jne 0x446ca
000445ae  41b901000000             mov r9d, 1
000445b4  33c0                     xor eax, eax
000445b6  4183fd06                 cmp r13d, 6
000445ba  44894dd7                 mov dword ptr [rbp - 0x29], r9d
000445be  44894d67                 mov dword ptr [rbp + 0x67], r9d
000445c2  0f4e45df                 cmovle eax, dword ptr [rbp - 0x21]
000445c6  8945df                   mov dword ptr [rbp - 0x21], eax
000445c9  458d6905                 lea r13d, [r9 + 5]
000445cd  e9fe000000               jmp 0x446d0
000445d2  4183fd06                 cmp r13d, 6
000445d6  7f52                     jg 0x4462a
000445d8  0f85ba000000             jne 0x44698
000445de  837ddf00                 cmp dword ptr [rbp - 0x21], 0
000445e2  7425                     je 0x44609
000445e4  837dd700                 cmp dword ptr [rbp - 0x29], 0
000445e8  41b901000000             mov r9d, 1
000445ee  0f85aa000000             jne 0x4469e
000445f4  44894d67                 mov dword ptr [rbp + 0x67], r9d
000445f8  458d6905                 lea r13d, [r9 + 5]
000445fc  44894dd7                 mov dword ptr [rbp - 0x29], r9d
00044600  44894ddf                 mov dword ptr [rbp - 0x21], r9d
00044604  e995000000               jmp 0x4469e
00044609  837dd700                 cmp dword ptr [rbp - 0x29], 0
0004460d  741b                     je 0x4462a
0004460f  41b901000000             mov r9d, 1
00044615  c7456703000000           mov dword ptr [rbp + 0x67], 3
0004461c  44894dd7                 mov dword ptr [rbp - 0x29], r9d
00044620  44894ddf                 mov dword ptr [rbp - 0x21], r9d
00044624  458d6905                 lea r13d, [r9 + 5]
00044628  eb74                     jmp 0x4469e
0004462a  3845b3                   cmp byte ptr [rbp - 0x4d], al
0004462d  7549                     jne 0x44678
0004462f  0fb64db6                 movzx ecx, byte ptr [rbp - 0x4a]
00044633  c1e818                   shr eax, 0x18
00044636  80e13f                   and cl, 0x3f
00044639  243f                     and al, 0x3f
0004463b  3ac8                     cmp cl, al
0004463d  7318                     jae 0x44657
0004463f  41b901000000             mov r9d, 1
00044645  44894d67                 mov dword ptr [rbp + 0x67], r9d
00044649  44894dd7                 mov dword ptr [rbp - 0x29], r9d
0004464d  44894ddf                 mov dword ptr [rbp - 0x21], r9d
00044651  458d6905                 lea r13d, [r9 + 5]
00044655  eb47                     jmp 0x4469e
00044657  0f86a3000000             jbe 0x44700
0004465d  41b901000000             mov r9d, 1
00044663  c7456703000000           mov dword ptr [rbp + 0x67], 3
0004466a  44894dd7                 mov dword ptr [rbp - 0x29], r9d
0004466e  44894ddf                 mov dword ptr [rbp - 0x21], r9d
00044672  458d6905                 lea r13d, [r9 + 5]
00044676  eb26                     jmp 0x4469e
00044678  41b901000000             mov r9d, 1
0004467e  b803000000               mov eax, 3
00044683  410f42c1                 cmovb eax, r9d
00044687  44894dd7                 mov dword ptr [rbp - 0x29], r9d
0004468b  894567                   mov dword ptr [rbp + 0x67], eax
0004468e  44894ddf                 mov dword ptr [rbp - 0x21], r9d
00044692  458d6905                 lea r13d, [r9 + 5]
00044696  eb06                     jmp 0x4469e
00044698  41b901000000             mov r9d, 1
0004469e  4983c402                 add r12, 2
000446a2  4183ee01                 sub r14d, 1
000446a6  7428                     je 0x446d0
000446a8  488b5557                 mov rdx, qword ptr [rbp + 0x57]
000446ac  410fb70c24               movzx ecx, word ptr [r12]
000446b1  448b5577                 mov r10d, dword ptr [rbp + 0x77]
000446b5  488b4208                 mov rax, qword ptr [rdx + 8]
000446b9  448b0488                 mov r8d, dword ptr [rax + rcx*4]
000446bd  4523c2                   and r8d, r10d
000446c0  4489456f                 mov dword ptr [rbp + 0x6f], r8d
000446c4  448945b3                 mov dword ptr [rbp - 0x4d], r8d
000446c8  eb0e                     jmp 0x446d8
000446ca  41b901000000             mov r9d, 1
000446d0  448b5577                 mov r10d, dword ptr [rbp + 0x77]
000446d4  488b5557                 mov rdx, qword ptr [rbp + 0x57]
000446d8  4983c702                 add r15, 2
000446dc  83ee01                   sub esi, 1
000446df  7414                     je 0x446f5
000446e1  410fb70f                 movzx ecx, word ptr [r15]
000446e5  488b4208                 mov rax, qword ptr [rdx + 8]
000446e9  8b0488                   mov eax, dword ptr [rax + rcx*4]
000446ec  4123c2                   and eax, r10d
000446ef  8945af                   mov dword ptr [rbp - 0x51], eax
000446f2  8945b7                   mov dword ptr [rbp - 0x49], eax
000446f5  458bc1                   mov r8d, r9d
000446f8  eb14                     jmp 0x4470e
000446fa  8b45af                   mov eax, dword ptr [rbp - 0x51]
000446fd  8945cb                   mov dword ptr [rbp - 0x35], eax
00044700  85d2                     test edx, edx
00044702  7434                     je 0x44738
00044704  448b45bf                 mov r8d, dword ptr [rbp - 0x41]
00044708  41b901000000             mov r9d, 1
0004470e  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044712  8b5daf                   mov ebx, dword ptr [rbp - 0x51]
00044715  8b5567                   mov edx, dword ptr [rbp + 0x67]
00044718  488b7d57                 mov rdi, qword ptr [rbp + 0x57]
0004471c  448b5577                 mov r10d, dword ptr [rbp + 0x77]
00044720  4585f6                   test r14d, r14d
00044723  0f8495f6ffff             je 0x43dbe
00044729  85f6                     test esi, esi
0004472b  0f848df6ffff             je 0x43dbe
00044731  33d2                     xor edx, edx
00044733  e91af7ffff               jmp 0x43e52
00044738  4180fa03                 cmp r10b, 3
0004473c  0f85e0010000             jne 0x44922
00044742  488b4557                 mov rax, qword ptr [rbp + 0x57]
00044746  418bc8                   mov ecx, r8d
00044749  c1e918                   shr ecx, 0x18
0004474c  0fb75040                 movzx edx, word ptr [rax + 0x40]
00044750  33c0                     xor eax, eax
00044752  807db301                 cmp byte ptr [rbp - 0x4d], 1
00044756  8945c3                   mov dword ptr [rbp - 0x3d], eax
00044759  0f87ae000000             ja 0x4480d
0004475f  8b45cf                   mov eax, dword ptr [rbp - 0x31]
00044762  41b8ffff0000             mov r8d, 0xffff
00044768  448945db                 mov dword ptr [rbp - 0x25], r8d
0004476c  85c0                     test eax, eax
0004476e  0f84c9000000             je 0x4483d
00044774  448b4577                 mov r8d, dword ptr [rbp + 0x77]
00044778  4423c0                   and r8d, eax
0004477b  410fb7c0                 movzx eax, r8w
0004477f  448945db                 mov dword ptr [rbp - 0x25], r8d
00044783  66c1e808                 shr ax, 8
00044787  4489456f                 mov dword ptr [rbp + 0x6f], r8d
0004478b  413ac2                   cmp al, r10b
0004478e  730f                     jae 0x4479f
00044790  41b8ffff0000             mov r8d, 0xffff
00044796  448945db                 mov dword ptr [rbp - 0x25], r8d
0004479a  e99e000000               jmp 0x4483d
0004479f  7566                     jne 0x44807
000447a1  4180f801                 cmp r8b, 1
000447a5  770f                     ja 0x447b6
000447a7  41b8ffff0000             mov r8d, 0xffff
000447ad  448945db                 mov dword ptr [rbp - 0x25], r8d
000447b1  e987000000               jmp 0x4483d
000447b6  0fb7da                   movzx ebx, dx
000447b9  410fb6c0                 movzx eax, r8b
000447bd  0fb65572                 movzx edx, byte ptr [rbp + 0x72]
000447c1  80e23f                   and dl, 0x3f
000447c4  66c1e308                 shl bx, 8
000447c8  660bd8                   or bx, ax
000447cb  0fb6c2                   movzx eax, dl
000447ce  24c6                     and al, 0xc6
000447d0  66895d6f                 mov word ptr [rbp + 0x6f], bx
000447d4  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
000447d8  8845c3                   mov byte ptr [rbp - 0x3d], al
000447db  0fb6c2                   movzx eax, dl
000447de  24e4                     and al, 0xe4
000447e0  448945db                 mov dword ptr [rbp - 0x25], r8d
000447e4  807db300                 cmp byte ptr [rbp - 0x4d], 0
000447e8  8845c5                   mov byte ptr [rbp - 0x3b], al
000447eb  750c                     jne 0x447f9
000447ed  80e2c5                   and dl, 0xc5
000447f0  c645c404                 mov byte ptr [rbp - 0x3c], 4
000447f4  8855c6                   mov byte ptr [rbp - 0x3a], dl
000447f7  eb4a                     jmp 0x44843
000447f9  b887ff0000               mov eax, 0xff87
000447fe  c645c405                 mov byte ptr [rbp - 0x3c], 5
00044802  6623d8                   and bx, ax
00044805  eb30                     jmp 0x44837
00044807  410fb7d8                 movzx ebx, r8w
0004480b  eb30                     jmp 0x4483d
0004480d  410fb6c0                 movzx eax, r8b
00044811  0fb7da                   movzx ebx, dx
00044814  66c1e308                 shl bx, 8
00044818  660bd8                   or bx, ax
0004481b  448945cf                 mov dword ptr [rbp - 0x31], r8d
0004481f  448b45db                 mov r8d, dword ptr [rbp - 0x25]
00044823  0fb6c1                   movzx eax, cl
00044826  2406                     and al, 6
00044828  c645c403                 mov byte ptr [rbp - 0x3c], 3
0004482c  8845c3                   mov byte ptr [rbp - 0x3d], al
0004482f  0fb6c1                   movzx eax, cl
00044832  2424                     and al, 0x24
00044834  8845c5                   mov byte ptr [rbp - 0x3b], al
00044837  80e105                   and cl, 5
0004483a  884dc6                   mov byte ptr [rbp - 0x3a], cl
0004483d  807db301                 cmp byte ptr [rbp - 0x4d], 1
00044841  7719                     ja 0x4485c
00044843  4181f8ffff0000           cmp r8d, 0xffff
0004484a  7510                     jne 0x4485c
0004484c  33c0                     xor eax, eax
0004484e  448945b3                 mov dword ptr [rbp - 0x4d], r8d
00044852  8bc8                     mov ecx, eax
00044854  8945c3                   mov dword ptr [rbp - 0x3d], eax
00044857  418bd8                   mov ebx, r8d
0004485a  eb0f                     jmp 0x4486b
0004485c  8b4dc3                   mov ecx, dword ptr [rbp - 0x3d]
0004485f  66895db3                 mov word ptr [rbp - 0x4d], bx
00044863  c645b602                 mov byte ptr [rbp - 0x4a], 2
00044867  448b45b3                 mov r8d, dword ptr [rbp - 0x4d]
0004486b  4489456f                 mov dword ptr [rbp + 0x6f], r8d
0004486f  4183fd02                 cmp r13d, 2
00044873  0f8ea9000000             jle 0x44922
00044879  4180f903                 cmp r9b, 3
0004487d  0f84a9000000             je 0x4492c
00044883  807dc300                 cmp byte ptr [rbp - 0x3d], 0
00044887  7419                     je 0x448a2
00044889  4585db                   test r11d, r11d
0004488c  7514                     jne 0x448a2
0004488e  b903000000               mov ecx, 3
00044893  458d6b02                 lea r13d, [r11 + 2]
00044897  894d67                   mov dword ptr [rbp + 0x67], ecx
0004489a  458bd8                   mov r11d, r8d
0004489d  e9e7010000               jmp 0x44a89
000448a2  4183fd03                 cmp r13d, 3
000448a6  0f8ed4010000             jle 0x44a80
000448ac  8bc1                     mov eax, ecx
000448ae  c1e808                   shr eax, 8
000448b1  84c0                     test al, al
000448b3  7419                     je 0x448ce
000448b5  4585db                   test r11d, r11d
000448b8  7514                     jne 0x448ce
000448ba  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
000448be  b903000000               mov ecx, 3
000448c3  894d67                   mov dword ptr [rbp + 0x67], ecx
000448c6  448be9                   mov r13d, ecx
000448c9  e9bb010000               jmp 0x44a89
000448ce  4183fd04                 cmp r13d, 4
000448d2  0f8ea8010000             jle 0x44a80
000448d8  8bc1                     mov eax, ecx
000448da  c1e810                   shr eax, 0x10
000448dd  84c0                     test al, al
000448df  7415                     je 0x448f6
000448e1  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
000448e5  b903000000               mov ecx, 3
000448ea  894d67                   mov dword ptr [rbp + 0x67], ecx
000448ed  448d6901                 lea r13d, [rcx + 1]
000448f1  e993010000               jmp 0x44a89
000448f6  4183fd05                 cmp r13d, 5
000448fa  0f8e80010000             jle 0x44a80
00044900  8bc1                     mov eax, ecx
00044902  c1e818                   shr eax, 0x18
00044905  84c0                     test al, al
00044907  0f8473010000             je 0x44a80
0004490d  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044911  b903000000               mov ecx, 3
00044916  894d67                   mov dword ptr [rbp + 0x67], ecx
00044919  448d6902                 lea r13d, [rcx + 2]
0004491d  e967010000               jmp 0x44a89
00044922  4180f903                 cmp r9b, 3
00044926  0f8554010000             jne 0x44a80
0004492c  488b4557                 mov rax, qword ptr [rbp + 0x57]
00044930  33c9                     xor ecx, ecx
00044932  440fb64db7               movzx r9d, byte ptr [rbp - 0x49]
00044937  894dbb                   mov dword ptr [rbp - 0x45], ecx
0004493a  440fb74040               movzx r8d, word ptr [rax + 0x40]
0004493f  8b45af                   mov eax, dword ptr [rbp - 0x51]
00044942  8bd0                     mov edx, eax
00044944  c1ea18                   shr edx, 0x18
00044947  4180f901                 cmp r9b, 1
0004494b  0f87a4000000             ja 0x449f5
00044951  b8ffff0000               mov eax, 0xffff
00044956  8945c7                   mov dword ptr [rbp - 0x39], eax
00044959  394dcb                   cmp dword ptr [rbp - 0x35], ecx
0004495c  0f84c4000000             je 0x44a26
00044962  8b4577                   mov eax, dword ptr [rbp + 0x77]
00044965  2345cb                   and eax, dword ptr [rbp - 0x35]
00044968  8945c7                   mov dword ptr [rbp - 0x39], eax
0004496b  8945af                   mov dword ptr [rbp - 0x51], eax
0004496e  66c1e808                 shr ax, 8
00044972  3c03                     cmp al, 3
00044974  730d                     jae 0x44983
00044976  b8ffff0000               mov eax, 0xffff
0004497b  8945c7                   mov dword ptr [rbp - 0x39], eax
0004497e  e9a3000000               jmp 0x44a26
00044983  8b45c7                   mov eax, dword ptr [rbp - 0x39]
00044986  7568                     jne 0x449f0
00044988  3c01                     cmp al, 1
0004498a  770d                     ja 0x44999
0004498c  b8ffff0000               mov eax, 0xffff
00044991  8945c7                   mov dword ptr [rbp - 0x39], eax
00044994  e98d000000               jmp 0x44a26
00044999  0fb64db2                 movzx ecx, byte ptr [rbp - 0x4e]
0004499d  410fb7f8                 movzx edi, r8w
000449a1  0fb6c0                   movzx eax, al
000449a4  80e13f                   and cl, 0x3f
000449a7  66c1e708                 shl di, 8
000449ab  660bf8                   or di, ax
000449ae  0fb6c1                   movzx eax, cl
000449b1  24c6                     and al, 0xc6
000449b3  66897daf                 mov word ptr [rbp - 0x51], di
000449b7  8845bb                   mov byte ptr [rbp - 0x45], al
000449ba  0fb6c1                   movzx eax, cl
000449bd  24e4                     and al, 0xe4
000449bf  8845bd                   mov byte ptr [rbp - 0x43], al
000449c2  4584c9                   test r9b, r9b
000449c5  7515                     jne 0x449dc
000449c7  8b45af                   mov eax, dword ptr [rbp - 0x51]
000449ca  80e1c5                   and cl, 0xc5
000449cd  884dbe                   mov byte ptr [rbp - 0x42], cl
000449d0  c645bc04                 mov byte ptr [rbp - 0x44], 4
000449d4  8b4dbb                   mov ecx, dword ptr [rbp - 0x45]
000449d7  8945c7                   mov dword ptr [rbp - 0x39], eax
000449da  eb50                     jmp 0x44a2c
000449dc  b887ff0000               mov eax, 0xff87
000449e1  c645bc05                 mov byte ptr [rbp - 0x44], 5
000449e5  6623f8                   and di, ax
000449e8  8b45af                   mov eax, dword ptr [rbp - 0x51]
000449eb  8945c7                   mov dword ptr [rbp - 0x39], eax
000449ee  eb2d                     jmp 0x44a1d
000449f0  0fb7f8                   movzx edi, ax
000449f3  eb31                     jmp 0x44a26
000449f5  8945cb                   mov dword ptr [rbp - 0x35], eax
000449f8  410fb7f8                 movzx edi, r8w
000449fc  0fb6c0                   movzx eax, al
000449ff  66c1e708                 shl di, 8
00044a03  660bf8                   or di, ax
00044a06  c645bc03                 mov byte ptr [rbp - 0x44], 3
00044a0a  0fb6c2                   movzx eax, dl
00044a0d  2406                     and al, 6
00044a0f  8845bb                   mov byte ptr [rbp - 0x45], al
00044a12  0fb6c2                   movzx eax, dl
00044a15  2424                     and al, 0x24
00044a17  8845bd                   mov byte ptr [rbp - 0x43], al
00044a1a  8b45c7                   mov eax, dword ptr [rbp - 0x39]
00044a1d  80e205                   and dl, 5
00044a20  8855be                   mov byte ptr [rbp - 0x42], dl
00044a23  8b4dbb                   mov ecx, dword ptr [rbp - 0x45]
00044a26  4180f901                 cmp r9b, 1
00044a2a  7718                     ja 0x44a44
00044a2c  3dffff0000               cmp eax, 0xffff
00044a31  7511                     jne 0x44a44
00044a33  8bf8                     mov edi, eax
00044a35  8945af                   mov dword ptr [rbp - 0x51], eax
00044a38  8945b7                   mov dword ptr [rbp - 0x49], eax
00044a3b  33c0                     xor eax, eax
00044a3d  8bc8                     mov ecx, eax
00044a3f  8945bb                   mov dword ptr [rbp - 0x45], eax
00044a42  eb0e                     jmp 0x44a52
00044a44  66897db7                 mov word ptr [rbp - 0x49], di
00044a48  c645ba02                 mov byte ptr [rbp - 0x46], 2
00044a4c  8b45b7                   mov eax, dword ptr [rbp - 0x49]
00044a4f  8945af                   mov dword ptr [rbp - 0x51], eax
00044a52  4183fd02                 cmp r13d, 2
00044a56  7e28                     jle 0x44a80
00044a58  4180fa03                 cmp r10b, 3
00044a5c  0f8490010000             je 0x44bf2
00044a62  807dbb00                 cmp byte ptr [rbp - 0x45], 0
00044a66  0f8404010000             je 0x44b70
00044a6c  4585db                   test r11d, r11d
00044a6f  0f85fb000000             jne 0x44b70
00044a75  c7456701000000           mov dword ptr [rbp + 0x67], 1
00044a7c  458d6b02                 lea r13d, [r11 + 2]
00044a80  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044a84  b903000000               mov ecx, 3
00044a89  b801000000               mov eax, 1
00044a8e  663bdf                   cmp bx, di
00044a91  0f852b030000             jne 0x44dc2
00044a97  f6455f02                 test byte ptr [rbp + 0x5f], 2
00044a9b  0f854e020000             jne 0x44cef
00044aa1  488b5d57                 mov rbx, qword ptr [rbp + 0x57]
00044aa5  4585ed                   test r13d, r13d
00044aa8  7f0a                     jg 0x44ab4
00044aaa  837b1000                 cmp dword ptr [rbx + 0x10], 0
00044aae  0f843b020000             je 0x44cef
00044ab4  488b7dff                 mov rdi, qword ptr [rbp - 1]
00044ab8  440fb645b5               movzx r8d, byte ptr [rbp - 0x4b]
00044abd  440fb64db9               movzx r9d, byte ptr [rbp - 0x47]
00044ac2  4885ff                   test rdi, rdi
00044ac5  7538                     jne 0x44aff
00044ac7  418d46ff                 lea eax, [r14 - 1]
00044acb  85c0                     test eax, eax
00044acd  7430                     je 0x44aff
00044acf  4c8b5308                 mov r10, qword ptr [rbx + 8]
00044ad3  410fb7442402             movzx eax, word ptr [r12 + 2]
00044ad9  418b0c82                 mov ecx, dword ptr [r10 + rax*4]
00044add  0fb7c1                   movzx eax, cx
00044ae0  66c1e808                 shr ax, 8
00044ae4  3c01                     cmp al, 1
00044ae6  7517                     jne 0x44aff
00044ae8  c1e910                   shr ecx, 0x10
00044aeb  4983c402                 add r12, 2
00044aef  0fb6c1                   movzx eax, cl
00044af2  41ffce                   dec r14d
00044af5  664403c0                 add r8w, ax
00044af9  4183fe01                 cmp r14d, 1
00044afd  75d4                     jne 0x44ad3
00044aff  48837df700               cmp qword ptr [rbp - 9], 0
00044b04  7543                     jne 0x44b49
00044b06  8d46ff                   lea eax, [rsi - 1]
00044b09  85c0                     test eax, eax
00044b0b  743c                     je 0x44b49
00044b0d  4c8b5308                 mov r10, qword ptr [rbx + 8]
00044b11  0f1f4000                 nop dword ptr [rax]
00044b15  6666660f1f840000000000   nop word ptr [rax + rax]
00044b20  410fb74702               movzx eax, word ptr [r15 + 2]
00044b25  418b0c82                 mov ecx, dword ptr [r10 + rax*4]
00044b29  0fb7c1                   movzx eax, cx
00044b2c  66c1e808                 shr ax, 8
00044b30  3c01                     cmp al, 1
00044b32  7515                     jne 0x44b49
00044b34  c1e910                   shr ecx, 0x10
00044b37  4983c702                 add r15, 2
00044b3b  0fb6c1                   movzx eax, cl
00044b3e  ffce                     dec esi
00044b40  664403c8                 add r9w, ax
00044b44  83fe01                   cmp esi, 1
00044b47  75d7                     jne 0x44b20
00044b49  66453bc1                 cmp r8w, r9w
00044b4d  41b901000000             mov r9d, 1
00044b53  0f84a0010000             je 0x44cf9
00044b59  ba03000000               mov edx, 3
00044b5e  410f42d1                 cmovb edx, r9d
00044b62  4533c0                   xor r8d, r8d
00044b65  458be8                   mov r13d, r8d
00044b68  895567                   mov dword ptr [rbp + 0x67], edx
00044b6b  e98f010000               jmp 0x44cff
00044b70  4183fd03                 cmp r13d, 3
00044b74  0f8e06ffffff             jle 0x44a80
00044b7a  8bc1                     mov eax, ecx
00044b7c  c1e808                   shr eax, 8
00044b7f  84c0                     test al, al
00044b81  741d                     je 0x44ba0
00044b83  4585db                   test r11d, r11d
00044b86  7518                     jne 0x44ba0
00044b88  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044b8c  b903000000               mov ecx, 3
00044b91  448be9                   mov r13d, ecx
00044b94  c7456701000000           mov dword ptr [rbp + 0x67], 1
00044b9b  e9e9feffff               jmp 0x44a89
00044ba0  4183fd04                 cmp r13d, 4
00044ba4  0f8ed6feffff             jle 0x44a80
00044baa  8bc1                     mov eax, ecx
00044bac  c1e810                   shr eax, 0x10
00044baf  84c0                     test al, al
00044bb1  7412                     je 0x44bc5
00044bb3  c7456701000000           mov dword ptr [rbp + 0x67], 1
00044bba  41bd04000000             mov r13d, 4
00044bc0  e9bbfeffff               jmp 0x44a80
00044bc5  4183fd05                 cmp r13d, 5
00044bc9  0f8eb1feffff             jle 0x44a80
00044bcf  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044bd3  b801000000               mov eax, 1
00044bd8  c1e918                   shr ecx, 0x18
00044bdb  84c9                     test cl, cl
00044bdd  8d4802                   lea ecx, [rax + 2]
00044be0  0f84a8feffff             je 0x44a8e
00044be6  894567                   mov dword ptr [rbp + 0x67], eax
00044be9  448d6804                 lea r13d, [rax + 4]
00044bed  e99cfeffff               jmp 0x44a8e
00044bf2  0fb645c3                 movzx eax, byte ptr [rbp - 0x3d]
00044bf6  0fb655bb                 movzx edx, byte ptr [rbp - 0x45]
00044bfa  3ac2                     cmp al, dl
00044bfc  7429                     je 0x44c27
00044bfe  4585db                   test r11d, r11d
00044c01  7524                     jne 0x44c27
00044c03  3ac2                     cmp al, dl
00044c05  458d6b02                 lea r13d, [r11 + 2]
00044c09  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044c0d  b903000000               mov ecx, 3
00044c12  448bc1                   mov r8d, ecx
00044c15  b801000000               mov eax, 1
00044c1a  440f42c0                 cmovb r8d, eax
00044c1e  44894567                 mov dword ptr [rbp + 0x67], r8d
00044c22  e967feffff               jmp 0x44a8e
00044c27  4183fd03                 cmp r13d, 3
00044c2b  0f8e4ffeffff             jle 0x44a80
00044c31  448b45c3                 mov r8d, dword ptr [rbp - 0x3d]
00044c35  8bd1                     mov edx, ecx
00044c37  418bc0                   mov eax, r8d
00044c3a  c1ea08                   shr edx, 8
00044c3d  c1e808                   shr eax, 8
00044c40  3ac2                     cmp al, dl
00044c42  7428                     je 0x44c6c
00044c44  4585db                   test r11d, r11d
00044c47  7523                     jne 0x44c6c
00044c49  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044c4d  b903000000               mov ecx, 3
00044c52  3ac2                     cmp al, dl
00044c54  448bc1                   mov r8d, ecx
00044c57  b801000000               mov eax, 1
00044c5c  448be9                   mov r13d, ecx
00044c5f  440f42c0                 cmovb r8d, eax
00044c63  44894567                 mov dword ptr [rbp + 0x67], r8d
00044c67  e922feffff               jmp 0x44a8e
00044c6c  4183fd04                 cmp r13d, 4
00044c70  0f8e0afeffff             jle 0x44a80
00044c76  418bc0                   mov eax, r8d
00044c79  8bd1                     mov edx, ecx
00044c7b  c1e810                   shr eax, 0x10
00044c7e  c1ea10                   shr edx, 0x10
00044c81  3ac2                     cmp al, dl
00044c83  7422                     je 0x44ca7
00044c85  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044c89  b903000000               mov ecx, 3
00044c8e  448bc1                   mov r8d, ecx
00044c91  b801000000               mov eax, 1
00044c96  440f42c0                 cmovb r8d, eax
00044c9a  44894567                 mov dword ptr [rbp + 0x67], r8d
00044c9e  448d6901                 lea r13d, [rcx + 1]
00044ca2  e9e7fdffff               jmp 0x44a8e
00044ca7  4183fd05                 cmp r13d, 5
00044cab  7e31                     jle 0x44cde
00044cad  418bc0                   mov eax, r8d
00044cb0  c1e918                   shr ecx, 0x18
00044cb3  c1e818                   shr eax, 0x18
00044cb6  3ac1                     cmp al, cl
00044cb8  0f84c2fdffff             je 0x44a80
00044cbe  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044cc2  b801000000               mov eax, 1
00044cc7  ba03000000               mov edx, 3
00044ccc  0f42d0                   cmovb edx, eax
00044ccf  895567                   mov dword ptr [rbp + 0x67], edx
00044cd2  448d6804                 lea r13d, [rax + 4]
00044cd6  8d4802                   lea ecx, [rax + 2]
00044cd9  e9b0fdffff               jmp 0x44a8e
00044cde  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044ce2  b801000000               mov eax, 1
00044ce7  8d4802                   lea ecx, [rax + 2]
00044cea  e99ffdffff               jmp 0x44a8e
00044cef  488b7dff                 mov rdi, qword ptr [rbp - 1]
00044cf3  41b901000000             mov r9d, 1
00044cf9  8b5567                   mov edx, dword ptr [rbp + 0x67]
00044cfc  4533c0                   xor r8d, r8d
00044cff  8b455f                   mov eax, dword ptr [rbp + 0x5f]
00044d02  2501000200               and eax, 0x20001
00044d07  3d01000200               cmp eax, 0x20001
00044d0c  7426                     je 0x44d34
00044d0e  4183fd01                 cmp r13d, 1
00044d12  7e20                     jle 0x44d34
00044d14  0fb645ba                 movzx eax, byte ptr [rbp - 0x46]
00044d18  0fb64db6                 movzx ecx, byte ptr [rbp - 0x4a]
00044d1c  243f                     and al, 0x3f
00044d1e  80e13f                   and cl, 0x3f
00044d21  3ac8                     cmp cl, al
00044d23  740f                     je 0x44d34
00044d25  ba03000000               mov edx, 3
00044d2a  458be9                   mov r13d, r9d
00044d2d  410f42d1                 cmovb edx, r9d
00044d31  895567                   mov dword ptr [rbp + 0x67], edx
00044d34  4885ff                   test rdi, rdi
00044d37  7411                     je 0x44d4a
00044d39  836def01                 sub dword ptr [rbp - 0x11], 1
00044d3d  750b                     jne 0x44d4a
00044d3f  4c8be7                   mov r12, rdi
00044d42  4c8945ff                 mov qword ptr [rbp - 1], r8
00044d46  448945cf                 mov dword ptr [rbp - 0x31], r8d
00044d4a  488b4df7                 mov rcx, qword ptr [rbp - 9]
00044d4e  4885c9                   test rcx, rcx
00044d51  7414                     je 0x44d67
00044d53  836de301                 sub dword ptr [rbp - 0x1d], 1
00044d57  750e                     jne 0x44d67
00044d59  4c8bf9                   mov r15, rcx
00044d5c  448945cb                 mov dword ptr [rbp - 0x35], r8d
00044d60  498bc8                   mov rcx, r8
00044d63  48894df7                 mov qword ptr [rbp - 9], rcx
00044d67  8b5daf                   mov ebx, dword ptr [rbp - 0x51]
00044d6a  4983c402                 add r12, 2
00044d6e  488b7d57                 mov rdi, qword ptr [rbp + 0x57]
00044d72  4983c702                 add r15, 2
00044d76  448b45bf                 mov r8d, dword ptr [rbp - 0x41]
00044d7a  ffce                     dec esi
00044d7c  448b5577                 mov r10d, dword ptr [rbp + 0x77]
00044d80  4183ee01                 sub r14d, 1
00044d84  0f8438f0ffff             je 0x43dc2
00044d8a  85f6                     test esi, esi
00044d8c  742f                     je 0x44dbd
00044d8e  488b4f08                 mov rcx, qword ptr [rdi + 8]
00044d92  410fb70424               movzx eax, word ptr [r12]
00044d97  448b1c81                 mov r11d, dword ptr [rcx + rax*4]
00044d9b  410fb707                 movzx eax, word ptr [r15]
00044d9f  4523da                   and r11d, r10d
00044da2  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00044da6  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00044daa  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
00044dad  4123da                   and ebx, r10d
00044db0  895daf                   mov dword ptr [rbp - 0x51], ebx
00044db3  895db7                   mov dword ptr [rbp - 0x49], ebx
00044db6  33d2                     xor edx, edx
00044db8  e995f0ffff               jmp 0x43e52
00044dbd  e900f0ffff               jmp 0x43dc2
00044dc2  0f42c8                   cmovb ecx, eax
00044dc5  8bc1                     mov eax, ecx
00044dc7  e99b000000               jmp 0x44e67
00044dcc  4585f6                   test r14d, r14d
00044dcf  7543                     jne 0x44e14
00044dd1  85f6                     test esi, esi
00044dd3  0f84bf000000             je 0x44e98
00044dd9  448b555f                 mov r10d, dword ptr [rbp + 0x5f]
00044ddd  4585d2                   test r10d, r10d
00044de0  791f                     jns 0x44e01
00044de2  4885c9                   test rcx, rcx
00044de5  0f84ad000000             je 0x44e98
00044deb  443975e3                 cmp dword ptr [rbp - 0x1d], r14d
00044def  0f84a3000000             je 0x44e98
00044df5  4183fd07                 cmp r13d, 7
00044df9  410f44d1                 cmove edx, r9d
00044dfd  8bc2                     mov eax, edx
00044dff  eb66                     jmp 0x44e67
00044e01  4585c0                   test r8d, r8d
00044e04  4d8be7                   mov r12, r15
00044e07  448bf6                   mov r14d, esi
00044e0a  440f45db                 cmovne r11d, ebx
00044e0e  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00044e12  eb0a                     jmp 0x44e1e
00044e14  448b555f                 mov r10d, dword ptr [rbp + 0x5f]
00044e18  41b903000000             mov r9d, 3
00044e1e  4c8d1ddbb1fbff           lea r11, [rip - 0x44e25]
00044e25  4585c0                   test r8d, r8d
00044e28  7407                     je 0x44e31
00044e2a  33c0                     xor eax, eax
00044e2c  448bc0                   mov r8d, eax
00044e2f  eb0f                     jmp 0x44e40
00044e31  410fb70c24               movzx ecx, word ptr [r12]
00044e36  488b4708                 mov rax, qword ptr [rdi + 8]
00044e3a  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
00044e3d  894db3                   mov dword ptr [rbp - 0x4d], ecx
00044e40  0fb745b3                 movzx eax, word ptr [rbp - 0x4d]
00044e44  c1e808                   shr eax, 8
00044e47  83f80b                   cmp eax, 0xb
00044e4a  7718                     ja 0x44e64
00044e4c  418b8c83e04e0400         mov ecx, dword ptr [r11 + rax*4 + 0x44ee0]
00044e54  4903cb                   add rcx, r11
00044e57  ffe1                     jmp rcx
00044e59  41f6c202                 test r10b, 2
00044e5d  752f                     jne 0x44e8e
00044e5f  4585ed                   test r13d, r13d
00044e62  7e2a                     jle 0x44e8e
00044e64  418bc1                   mov eax, r9d
00044e67  488b9c24c0000000         mov rbx, qword ptr [rsp + 0xc0]
00044e6f  4c8bac2480000000         mov r13, qword ptr [rsp + 0x80]
00044e77  4881c488000000           add rsp, 0x88
00044e7e  415f                     pop r15
00044e80  415e                     pop r14
00044e82  415c                     pop r12
00044e84  5f                       pop rdi
00044e85  5e                       pop rsi
00044e86  5d                       pop rbp
00044e87  c3                       ret

; chunk at RVA 0x44e88 (136 bytes)
00044e88  41f6c204                 test r10b, 4
00044e8c  74d6                     je 0x44e64
00044e8e  4983c402                 add r12, 2
00044e92  4183ee01                 sub r14d, 1
00044e96  758d                     jne 0x44e25
00044e98  b802000000               mov eax, 2
00044e9d  4183fd07                 cmp r13d, 7
00044ea1  0f44d0                   cmove edx, eax
00044ea4  8bc2                     mov eax, edx
00044ea6  ebbf                     jmp 0x44e67
00044ea8  e444                     in al, 0x44
00044eaa  0400                     add al, 0
00044eac  e043                     loopne 0x44ef1
00044eae  0400                     add al, 0
00044eb0  e444                     in al, 0x44
00044eb2  0400                     add al, 0
00044eb4  e444                     in al, 0x44
00044eb6  0400                     add al, 0
00044eb8  e444                     in al, 0x44
00044eba  0400                     add al, 0
00044ebc  e444                     in al, 0x44
00044ebe  0400                     add al, 0
00044ec0  6c                       insb byte ptr [rdi], dx
00044ec1  440400                   add al, 0
00044ec4  004704                   add byte ptr [rdi + 4], al
00044ec7  0012                     add byte ptr [rdx], dl
00044ec9  450400                   add al, 0
00044ecc  004704                   add byte ptr [rdi + 4], al
00044ecf  0000                     add byte ptr [rax], al
00044ed1  470400                   add al, 0
00044ed4  004704                   add byte ptr [rdi + 4], al
00044ed7  0000                     add byte ptr [rax], al
00044ed9  470400                   add al, 0
00044edc  8c4504                   mov word ptr [rbp + 4], es
00044edf  008e4e040059             add byte ptr [rsi + 0x5900044e], cl
00044ee5  4e0400                   add al, 0
00044ee8  644e0400                 add al, 0
00044eec  644e0400                 add al, 0
00044ef0  8e4e04                   mov cs, word ptr [rsi + 4]
00044ef3  008e4e040088             add byte ptr [rsi - 0x77fffbb2], cl
00044ef9  4e0400                   add al, 0
00044efc  884e04                   mov byte ptr [rsi + 4], cl
00044eff  00884e040088             add byte ptr [rax - 0x77fffbb2], cl
00044f05  4e0400                   add al, 0
00044f08  884e04                   mov byte ptr [rsi + 4], cl
