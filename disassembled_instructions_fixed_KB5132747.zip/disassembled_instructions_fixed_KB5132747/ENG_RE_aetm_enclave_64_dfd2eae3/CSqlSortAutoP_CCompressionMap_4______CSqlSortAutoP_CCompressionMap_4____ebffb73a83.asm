; CSqlSortAutoP<CCompressionMap<4> >::~CSqlSortAutoP<CCompressionMap<4> >
; aetm_enclave.dll, primary RVA 0x42790, 134 bytes in 5 chunk(s)

; chunk at RVA 0x42790 (30 bytes)
00042790  4889742418               mov qword ptr [rsp + 0x18], rsi
00042795  4156                     push r14
00042797  4883ec20                 sub rsp, 0x20
0004279b  488b31                   mov rsi, qword ptr [rcx]
0004279e  4c8bf1                   mov r14, rcx
000427a1  4885f6                   test rsi, rsi
000427a4  7464                     je 0x4280a
000427a6  488b16                   mov rdx, qword ptr [rsi]
000427a9  4885d2                   test rdx, rdx
000427ac  7454                     je 0x42802

; chunk at RVA 0x427ae (12 bytes)
000427ae  48897c2438               mov qword ptr [rsp + 0x38], rdi
000427b3  33ff                     xor edi, edi
000427b5  397e08                   cmp dword ptr [rsi + 8], edi
000427b8  763b                     jbe 0x427f5

; chunk at RVA 0x427ba (59 bytes)
000427ba  48895c2430               mov qword ptr [rsp + 0x30], rbx
000427bf  90                       nop
000427c0  488d0c7f                 lea rcx, [rdi + rdi*2]
000427c4  488bc2                   mov rax, rdx
000427c7  488b0cca                 mov rcx, qword ptr [rdx + rcx*8]
000427cb  4885c9                   test rcx, rcx
000427ce  7416                     je 0x427e6
000427d0  488b19                   mov rbx, qword ptr [rcx]
000427d3  e8c4b70100               call 0x5df9c
000427d8  488bcb                   mov rcx, rbx
000427db  4885db                   test rbx, rbx
000427de  75f0                     jne 0x427d0
000427e0  488b16                   mov rdx, qword ptr [rsi]
000427e3  488bc2                   mov rax, rdx
000427e6  ffc7                     inc edi
000427e8  3b7e08                   cmp edi, dword ptr [rsi + 8]
000427eb  72d3                     jb 0x427c0
000427ed  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000427f2  488bd0                   mov rdx, rax

; chunk at RVA 0x427f5 (13 bytes)
000427f5  488bca                   mov rcx, rdx
000427f8  e89fb70100               call 0x5df9c
000427fd  488b7c2438               mov rdi, qword ptr [rsp + 0x38]

; chunk at RVA 0x42802 (20 bytes)
00042802  498b0e                   mov rcx, qword ptr [r14]
00042805  e892b70100               call 0x5df9c
0004280a  488b742440               mov rsi, qword ptr [rsp + 0x40]
0004280f  4883c420                 add rsp, 0x20
00042813  415e                     pop r14
00042815  c3                       ret
