; CAutoRg<CAutoRg<CTrustedMachine::EncryptionProviderCacheEntry> >::~CAutoRg<CAutoRg<CTrustedMachine::EncryptionProviderCacheEntry> >
; aetm_enclave.dll, primary RVA 0x6f40, 80 bytes in 3 chunk(s)

; chunk at RVA 0x6f40 (23 bytes)
00006f40  4883ec28                 sub rsp, 0x28
00006f44  488b09                   mov rcx, qword ptr [rcx]
00006f47  4885c9                   test rcx, rcx
00006f4a  743f                     je 0x6f8b
00006f4c  4c8b41f8                 mov r8, qword ptr [rcx - 8]
00006f50  4c8d0de9ecffff           lea r9, [rip - 0x1317]

; chunk at RVA 0x6f57 (47 bytes)
00006f57  48895c2420               mov qword ptr [rsp + 0x20], rbx
00006f5c  ba08000000               mov edx, 8
00006f61  488d59f8                 lea rbx, [rcx - 8]
00006f65  e8165f0500               call 0x5ce80
00006f6a  488b13                   mov rdx, qword ptr [rbx]
00006f6d  488bcb                   mov rcx, rbx
00006f70  488d14d508000000         lea rdx, [rdx*8 + 8]
00006f78  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
00006f7d  4883c428                 add rsp, 0x28
00006f81  e9d65e0500               jmp 0x5ce5c

; chunk at RVA 0x6f86 (10 bytes)
00006f86  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
00006f8b  4883c428                 add rsp, 0x28
00006f8f  c3                       ret
