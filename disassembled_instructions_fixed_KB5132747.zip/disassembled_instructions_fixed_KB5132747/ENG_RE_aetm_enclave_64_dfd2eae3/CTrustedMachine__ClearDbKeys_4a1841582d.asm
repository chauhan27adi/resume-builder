; CTrustedMachine::ClearDbKeys
; aetm_enclave.dll, primary RVA 0xe280, 1305 bytes in 1 chunk(s)

; chunk at RVA 0xe280 (1305 bytes)
0000e280  89542410                 mov dword ptr [rsp + 0x10], edx
0000e284  48894c2408               mov qword ptr [rsp + 8], rcx
0000e289  53                       push rbx
0000e28a  55                       push rbp
0000e28b  56                       push rsi
0000e28c  57                       push rdi
0000e28d  4155                     push r13
0000e28f  4883ec50                 sub rsp, 0x50
0000e293  4c8d81c0da4700           lea r8, [rcx + 0x47dac0]
0000e29a  448bca                   mov r9d, edx
0000e29d  488d91c0da5000           lea rdx, [rcx + 0x50dac0]
0000e2a4  498bd8                   mov rbx, r8
0000e2a7  48899c2498000000         mov qword ptr [rsp + 0x98], rbx
0000e2af  90                       nop
0000e2b0  0fb68100db4700           movzx eax, byte ptr [rcx + 0x47db00]
0000e2b7  4c8bd9                   mov r11, rcx
0000e2ba  4889542420               mov qword ptr [rsp + 0x20], rdx
0000e2bf  4c3bc2                   cmp r8, rdx
0000e2c2  731a                     jae 0xe2de
0000e2c4  84c0                     test al, al
0000e2c6  750e                     jne 0xe2d6
0000e2c8  4883c348                 add rbx, 0x48
0000e2cc  90                       nop
0000e2cd  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000e2d1  483bda                   cmp rbx, rdx
0000e2d4  72ee                     jb 0xe2c4
0000e2d6  48899c2498000000         mov qword ptr [rsp + 0x98], rbx
0000e2de  4c89642448               mov qword ptr [rsp + 0x48], r12
0000e2e3  48be00000000ffffffff     movabs rsi, 0xffffffff00000000
0000e2ed  4c89742440               mov qword ptr [rsp + 0x40], r14
0000e2f2  48bd0000000001000000     movabs rbp, 0x100000000
0000e2fc  4c897c2438               mov qword ptr [rsp + 0x38], r15
0000e301  49ba398ee3388ee3388e     movabs r10, 0x8e38e38e38e38e39
0000e30b  0f1f440000               nop dword ptr [rax + rax]
0000e310  90                       nop
0000e311  0fb64240                 movzx eax, byte ptr [rdx + 0x40]
0000e315  483bda                   cmp rbx, rdx
0000e318  0f8449040000             je 0xe767
0000e31e  44394b04                 cmp dword ptr [rbx + 4], r9d
0000e322  0f85fd030000             jne 0xe725
0000e328  90                       nop
0000e329  488bcb                   mov rcx, rbx
0000e32c  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000e330  492bc8                   sub rcx, r8
0000e333  48c1f903                 sar rcx, 3
0000e337  90                       nop
0000e338  488b4338                 mov rax, qword ptr [rbx + 0x38]
0000e33c  490fafca                 imul rcx, r10
0000e340  48c1e820                 shr rax, 0x20
0000e344  4c63e9                   movsxd r13, ecx
0000e347  49c1e520                 shl r13, 0x20
0000e34b  4c0be8                   or r13, rax
0000e34e  4983fdff                 cmp r13, -1
0000e352  0f84cd030000             je 0xe725
0000e358  4d8d93c85a5100           lea r10, [r11 + 0x515ac8]
0000e35f  90                       nop
0000e360  410fb683e85a5100         movzx eax, byte ptr [r11 + 0x515ae8]
0000e368  4d8d8bc85a5600           lea r9, [r11 + 0x565ac8]
0000e36f  498bca                   mov rcx, r10
0000e372  4d3bd1                   cmp r10, r9
0000e375  7312                     jae 0xe389
0000e377  84c0                     test al, al
0000e379  750e                     jne 0xe389
0000e37b  4883c128                 add rcx, 0x28
0000e37f  90                       nop
0000e380  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000e384  493bc9                   cmp rcx, r9
0000e387  72ee                     jb 0xe377
0000e389  48bbcdcccccccccccccc     movabs rbx, 0xcccccccccccccccd
0000e393  0f1f4000                 nop dword ptr [rax]
0000e397  660f1f840000000000       nop word ptr [rax + rax]
0000e3a0  90                       nop
0000e3a1  410fb64120               movzx eax, byte ptr [r9 + 0x20]
0000e3a6  493bc9                   cmp rcx, r9
0000e3a9  0f84ee000000             je 0xe49d
0000e3af  4c3929                   cmp qword ptr [rcx], r13
0000e3b2  0f85b3000000             jne 0xe46b
0000e3b8  90                       nop
0000e3b9  488bd1                   mov rdx, rcx
0000e3bc  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000e3c0  492bd2                   sub rdx, r10
0000e3c3  90                       nop
0000e3c4  48c1fa03                 sar rdx, 3
0000e3c8  488b4118                 mov rax, qword ptr [rcx + 0x18]
0000e3cc  90                       nop
0000e3cd  48c1e820                 shr rax, 0x20
0000e3d1  480fafd3                 imul rdx, rbx
0000e3d5  4c63c2                   movsxd r8, edx
0000e3d8  49c1e020                 shl r8, 0x20
0000e3dc  4c0bc0                   or r8, rax
0000e3df  498bc0                   mov rax, r8
0000e3e2  48c1e820                 shr rax, 0x20
0000e3e6  8bd0                     mov edx, eax
0000e3e8  25ff1f0000               and eax, 0x1fff
0000e3ed  8bf8                     mov edi, eax
0000e3ef  488d0480                 lea rax, [rax + rax*4]
0000e3f3  450fb65cc221             movzx r11d, byte ptr [r10 + rax*8 + 0x21]
0000e3f9  90                       nop
0000e3fa  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000e3ff  48c1e820                 shr rax, 0x20
0000e403  413bc0                   cmp eax, r8d
0000e406  755c                     jne 0xe464
0000e408  4584db                   test r11b, r11b
0000e40b  7457                     je 0xe464
0000e40d  81e2ff1f0000             and edx, 0x1fff
0000e413  90                       nop
0000e414  488d0492                 lea rax, [rdx + rdx*4]
0000e418  4d8d04c2                 lea r8, [r10 + rax*8]
0000e41c  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000e421  85c0                     test eax, eax
0000e423  753f                     jne 0xe464
0000e425  488bd0                   mov rdx, rax
0000e428  4823d6                   and rdx, rsi
0000e42b  4803d5                   add rdx, rbp
0000e42e  f0490fb15018             lock cmpxchg qword ptr [r8 + 0x18], rdx
0000e434  752e                     jne 0xe464
0000e436  41c6402000               mov byte ptr [r8 + 0x20], 0
0000e43b  41c6402100               mov byte ptr [r8 + 0x21], 0
0000e440  90                       nop
0000e441  498b4018                 mov rax, qword ptr [r8 + 0x18]
0000e445  48c1e820                 shr rax, 0x20
0000e449  83f8ff                   cmp eax, -1
0000e44c  7416                     je 0xe464
0000e44e  49638200800500           movsxd rax, dword ptr [r10 + 0x58000]
0000e455  4189bc8200000500         mov dword ptr [r10 + rax*4 + 0x50000], edi
0000e45d  41ff8200800500           inc dword ptr [r10 + 0x58000]
0000e464  48ff0de5744600           dec qword ptr [rip + 0x4674e5]
0000e46b  493bc9                   cmp rcx, r9
0000e46e  7304                     jae 0xe474
0000e470  4883c128                 add rcx, 0x28
0000e474  90                       nop
0000e475  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000e479  493bc9                   cmp rcx, r9
0000e47c  0f831effffff             jae 0xe3a0
0000e482  84c0                     test al, al
0000e484  0f8516ffffff             jne 0xe3a0
0000e48a  4883c128                 add rcx, 0x28
0000e48e  90                       nop
0000e48f  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000e493  493bc9                   cmp rcx, r9
0000e496  72ea                     jb 0xe482
0000e498  e903ffffff               jmp 0xe3a0
0000e49d  4c8b9c2480000000         mov r11, qword ptr [rsp + 0x80]
0000e4a5  90                       nop
0000e4a6  488b9c2498000000         mov rbx, qword ptr [rsp + 0x98]
0000e4ae  498bc5                   mov rax, r13
0000e4b1  48c1e820                 shr rax, 0x20
0000e4b5  8bc8                     mov ecx, eax
0000e4b7  25ff1f0000               and eax, 0x1fff
0000e4bc  448be0                   mov r12d, eax
0000e4bf  488d04c0                 lea rax, [rax + rax*8]
0000e4c3  4c8d34c500000000         lea r14, [rax*8]
0000e4cb  430fb6941e01db4700       movzx edx, byte ptr [r14 + r11 + 0x47db01]
0000e4d4  90                       nop
0000e4d5  4b8b841ef8da4700         mov rax, qword ptr [r14 + r11 + 0x47daf8]
0000e4dd  48c1e820                 shr rax, 0x20
0000e4e1  413bc5                   cmp eax, r13d
0000e4e4  0f8597020000             jne 0xe781
0000e4ea  84d2                     test dl, dl
0000e4ec  0f848f020000             je 0xe781
0000e4f2  81e1ff1f0000             and ecx, 0x1fff
0000e4f8  498dabb85a4100           lea rbp, [r11 + 0x415ab8]
0000e4ff  488d04c9                 lea rax, [rcx + rcx*8]
0000e503  4c8d3cc500000000         lea r15, [rax*8]
0000e50b  4b8b8c1ff0da4700         mov rcx, qword ptr [r15 + r11 + 0x47daf0]
0000e513  90                       nop
0000e514  488bc1                   mov rax, rcx
0000e517  48c1e820                 shr rax, 0x20
0000e51b  25ff1f0000               and eax, 0x1fff
0000e520  488d0440                 lea rax, [rax + rax*2]
0000e524  4803c0                   add rax, rax
0000e527  0fb654c529               movzx edx, byte ptr [rbp + rax*8 + 0x29]
0000e52c  90                       nop
0000e52d  488b44c520               mov rax, qword ptr [rbp + rax*8 + 0x20]
0000e532  48c1e820                 shr rax, 0x20
0000e536  3bc1                     cmp eax, ecx
0000e538  0f8543020000             jne 0xe781
0000e53e  84d2                     test dl, dl
0000e540  0f843b020000             je 0xe781
0000e546  4b8b841ff0da4700         mov rax, qword ptr [r15 + r11 + 0x47daf0]
0000e54e  be04000000               mov esi, 4
0000e553  48c1e820                 shr rax, 0x20
0000e557  25ff1f0000               and eax, 0x1fff
0000e55c  488d3c40                 lea rdi, [rax + rax*2]
0000e560  48c1e704                 shl rdi, 4
0000e564  4803fd                   add rdi, rbp
0000e567  488b0f                   mov rcx, qword ptr [rdi]
0000e56a  4885c9                   test rcx, rcx
0000e56d  7428                     je 0xe597
0000e56f  488d5108                 lea rdx, [rcx + 8]
0000e573  b8ffffffff               mov eax, 0xffffffff
0000e578  f00fc102                 lock xadd dword ptr [rdx], eax
0000e57c  83f801                   cmp eax, 1
0000e57f  750f                     jne 0xe590
0000e581  4885d2                   test rdx, rdx
0000e584  740a                     je 0xe590
0000e586  488b01                   mov rax, qword ptr [rcx]
0000e589  ba01000000               mov edx, 1
0000e58e  ff10                     call qword ptr [rax]
0000e590  48c70700000000           mov qword ptr [rdi], 0
0000e597  4883c708                 add rdi, 8
0000e59b  4883ee01                 sub rsi, 1
0000e59f  75c6                     jne 0xe567
0000e5a1  4c8b9c2480000000         mov r11, qword ptr [rsp + 0x80]
0000e5a9  90                       nop
0000e5aa  4d8d83c0da4700           lea r8, [r11 + 0x47dac0]
0000e5b1  430fb64c0641             movzx ecx, byte ptr [r14 + r8 + 0x41]
0000e5b7  90                       nop
0000e5b8  4b8b440638               mov rax, qword ptr [r14 + r8 + 0x38]
0000e5bd  48c1e820                 shr rax, 0x20
0000e5c1  413bc5                   cmp eax, r13d
0000e5c4  0f85b7010000             jne 0xe781
0000e5ca  84c9                     test cl, cl
0000e5cc  0f84af010000             je 0xe781
0000e5d2  4b8b4c0730               mov rcx, qword ptr [r15 + r8 + 0x30]
0000e5d7  90                       nop
0000e5d8  488bc1                   mov rax, rcx
0000e5db  48c1e820                 shr rax, 0x20
0000e5df  25ff1f0000               and eax, 0x1fff
0000e5e4  488d0440                 lea rax, [rax + rax*2]
0000e5e8  4803c0                   add rax, rax
0000e5eb  0fb654c529               movzx edx, byte ptr [rbp + rax*8 + 0x29]
0000e5f0  90                       nop
0000e5f1  488b44c520               mov rax, qword ptr [rbp + rax*8 + 0x20]
0000e5f6  48c1e820                 shr rax, 0x20
0000e5fa  3bc1                     cmp eax, ecx
0000e5fc  0f858a000000             jne 0xe68c
0000e602  84d2                     test dl, dl
0000e604  0f8482000000             je 0xe68c
0000e60a  4b8b440730               mov rax, qword ptr [r15 + r8 + 0x30]
0000e60f  48be00000000ffffffff     movabs rsi, 0xffffffff00000000
0000e619  48c1e820                 shr rax, 0x20
0000e61d  90                       nop
0000e61e  25ff1f0000               and eax, 0x1fff
0000e623  488d1440                 lea rdx, [rax + rax*2]
0000e627  48c1e204                 shl rdx, 4
0000e62b  4803d5                   add rdx, rbp
0000e62e  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000e632  85c0                     test eax, eax
0000e634  7560                     jne 0xe696
0000e636  488bc8                   mov rcx, rax
0000e639  49b90000000001000000     movabs r9, 0x100000000
0000e643  4823ce                   and rcx, rsi
0000e646  4903c9                   add rcx, r9
0000e649  f0480fb14a20             lock cmpxchg qword ptr [rdx + 0x20], rcx
0000e64f  7545                     jne 0xe696
0000e651  c6422800                 mov byte ptr [rdx + 0x28], 0
0000e655  c6422900                 mov byte ptr [rdx + 0x29], 0
0000e659  90                       nop
0000e65a  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000e65e  48c1e820                 shr rax, 0x20
0000e662  83f8ff                   cmp eax, -1
0000e665  742f                     je 0xe696
0000e667  4b8b4c0730               mov rcx, qword ptr [r15 + r8 + 0x30]
0000e66c  48638500800600           movsxd rax, dword ptr [rbp + 0x68000]
0000e673  48c1e920                 shr rcx, 0x20
0000e677  81e1ff1f0000             and ecx, 0x1fff
0000e67d  898c8500000600           mov dword ptr [rbp + rax*4 + 0x60000], ecx
0000e684  ff8500800600             inc dword ptr [rbp + 0x68000]
0000e68a  eb0a                     jmp 0xe696
0000e68c  48be00000000ffffffff     movabs rsi, 0xffffffff00000000
0000e696  90                       nop
0000e697  48bd0000000001000000     movabs rbp, 0x100000000
0000e6a1  430fb64c0641             movzx ecx, byte ptr [r14 + r8 + 0x41]
0000e6a7  90                       nop
0000e6a8  4b8b440638               mov rax, qword ptr [r14 + r8 + 0x38]
0000e6ad  48c1e820                 shr rax, 0x20
0000e6b1  413bc5                   cmp eax, r13d
0000e6b4  7551                     jne 0xe707
0000e6b6  84c9                     test cl, cl
0000e6b8  744d                     je 0xe707
0000e6ba  90                       nop
0000e6bb  4b8b440738               mov rax, qword ptr [r15 + r8 + 0x38]
0000e6c0  85c0                     test eax, eax
0000e6c2  7543                     jne 0xe707
0000e6c4  488bc8                   mov rcx, rax
0000e6c7  4823ce                   and rcx, rsi
0000e6ca  4803cd                   add rcx, rbp
0000e6cd  f04b0fb14c0738           lock cmpxchg qword ptr [r15 + r8 + 0x38], rcx
0000e6d4  7531                     jne 0xe707
0000e6d6  43c644074000             mov byte ptr [r15 + r8 + 0x40], 0
0000e6dc  43c644074100             mov byte ptr [r15 + r8 + 0x41], 0
0000e6e2  90                       nop
0000e6e3  4b8b440738               mov rax, qword ptr [r15 + r8 + 0x38]
0000e6e8  48c1e820                 shr rax, 0x20
0000e6ec  83f8ff                   cmp eax, -1
0000e6ef  7416                     je 0xe707
0000e6f1  49638000800900           movsxd rax, dword ptr [r8 + 0x98000]
0000e6f8  4589a48000000900         mov dword ptr [r8 + rax*4 + 0x90000], r12d
0000e700  41ff8000800900           inc dword ptr [r8 + 0x98000]
0000e707  48ff0d3a724600           dec qword ptr [rip + 0x46723a]
0000e70e  49ba398ee3388ee3388e     movabs r10, 0x8e38e38e38e38e39
0000e718  488b542420               mov rdx, qword ptr [rsp + 0x20]
0000e71d  448b8c2488000000         mov r9d, dword ptr [rsp + 0x88]
0000e725  483bda                   cmp rbx, rdx
0000e728  730c                     jae 0xe736
0000e72a  4883c348                 add rbx, 0x48
0000e72e  48899c2498000000         mov qword ptr [rsp + 0x98], rbx
0000e736  90                       nop
0000e737  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000e73b  483bda                   cmp rbx, rdx
0000e73e  0f83ccfbffff             jae 0xe310
0000e744  84c0                     test al, al
0000e746  0f85c4fbffff             jne 0xe310
0000e74c  4883c348                 add rbx, 0x48
0000e750  90                       nop
0000e751  48899c2498000000         mov qword ptr [rsp + 0x98], rbx
0000e759  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000e75d  483bda                   cmp rbx, rdx
0000e760  72e2                     jb 0xe744
0000e762  e9a9fbffff               jmp 0xe310
0000e767  4c8b7c2438               mov r15, qword ptr [rsp + 0x38]
0000e76c  4c8b742440               mov r14, qword ptr [rsp + 0x40]
0000e771  4c8b642448               mov r12, qword ptr [rsp + 0x48]
0000e776  4883c450                 add rsp, 0x50
0000e77a  415d                     pop r13
0000e77c  5f                       pop rdi
0000e77d  5e                       pop rsi
0000e77e  5d                       pop rbp
0000e77f  5b                       pop rbx
0000e780  c3                       ret
0000e781  ba5f000000               mov edx, 0x5f
0000e786  b94b010000               mov ecx, 0x14b
0000e78b  448d4aa2                 lea r9d, [rdx - 0x5e]
0000e78f  448d42b2                 lea r8d, [rdx - 0x4e]
0000e793  e808ac0000               call 0x193a0
0000e798  cc                       int3
