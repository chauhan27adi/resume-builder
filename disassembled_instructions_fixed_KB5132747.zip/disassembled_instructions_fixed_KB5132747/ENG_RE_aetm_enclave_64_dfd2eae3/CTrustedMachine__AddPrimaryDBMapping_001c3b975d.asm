; CTrustedMachine::AddPrimaryDBMapping
; aetm_enclave.dll, primary RVA 0xd550, 652 bytes in 1 chunk(s)

; chunk at RVA 0xd550 (652 bytes)
0000d550  4056                     push rsi
0000d552  57                       push rdi
0000d553  4156                     push r14
0000d555  4883ec50                 sub rsp, 0x50
0000d559  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
0000d562  48895c2478               mov qword ptr [rsp + 0x78], rbx
0000d567  4889ac2480000000         mov qword ptr [rsp + 0x80], rbp
0000d56f  418bf0                   mov esi, r8d
0000d572  8bea                     mov ebp, edx
0000d574  488bf9                   mov rdi, rcx
0000d577  4c8d99d87a5800           lea r11, [rcx + 0x587ad8]
0000d57e  498bc3                   mov rax, r11
0000d581  4c8d89d8aa5800           lea r9, [rcx + 0x58aad8]
0000d588  90                       nop
0000d589  440fb691e87a5800         movzx r10d, byte ptr [rcx + 0x587ae8]
0000d591  4d3bd9                   cmp r11, r9
0000d594  7314                     jae 0xd5aa
0000d596  4584d2                   test r10b, r10b
0000d599  750f                     jne 0xd5aa
0000d59b  4883c018                 add rax, 0x18
0000d59f  90                       nop
0000d5a0  440fb65010               movzx r10d, byte ptr [rax + 0x10]
0000d5a5  493bc1                   cmp rax, r9
0000d5a8  72ec                     jb 0xd596
0000d5aa  49beabaaaaaaaaaaaaaa     movabs r14, 0xaaaaaaaaaaaaaaab
0000d5b4  4c8bd0                   mov r10, rax
0000d5b7  90                       nop
0000d5b8  410fb64910               movzx ecx, byte ptr [r9 + 0x10]
0000d5bd  493bc1                   cmp rax, r9
0000d5c0  0f84e1000000             je 0xd6a7
0000d5c6  90                       nop
0000d5c7  0fb64810                 movzx ecx, byte ptr [rax + 0x10]
0000d5cb  488bd0                   mov rdx, rax
0000d5ce  492bd3                   sub rdx, r11
0000d5d1  48c1fa03                 sar rdx, 3
0000d5d5  490fafd6                 imul rdx, r14
0000d5d9  90                       nop
0000d5da  488b4808                 mov rcx, qword ptr [rax + 8]
0000d5de  4c63c2                   movsxd r8, edx
0000d5e1  49c1e020                 shl r8, 0x20
0000d5e5  48c1e920                 shr rcx, 0x20
0000d5e9  4c0bc1                   or r8, rcx
0000d5ec  4c89442470               mov qword ptr [rsp + 0x70], r8
0000d5f1  49c1e820                 shr r8, 0x20
0000d5f5  0faee8                   lfence
0000d5f8  498bc8                   mov rcx, r8
0000d5fb  81e1ff010000             and ecx, 0x1ff
0000d601  488d0c49                 lea rcx, [rcx + rcx*2]
0000d605  488d14cf                 lea rdx, [rdi + rcx*8]
0000d609  f048ff82e07a5800         lock inc qword ptr [rdx + 0x587ae0]
0000d611  4181e0ff010000           and r8d, 0x1ff
0000d618  4b8d0c40                 lea rcx, [r8 + r8*2]
0000d61c  90                       nop
0000d61d  410fb65ccb10             movzx ebx, byte ptr [r11 + rcx*8 + 0x10]
0000d623  90                       nop
0000d624  498b4ccb08               mov rcx, qword ptr [r11 + rcx*8 + 8]
0000d629  48c1e920                 shr rcx, 0x20
0000d62d  4c8b442470               mov r8, qword ptr [rsp + 0x70]
0000d632  413bc8                   cmp ecx, r8d
0000d635  7509                     jne 0xd640
0000d637  84db                     test bl, bl
0000d639  7405                     je 0xd640
0000d63b  397004                   cmp dword ptr [rax + 4], esi
0000d63e  743f                     je 0xd67f
0000d640  0faee8                   lfence
0000d643  f048ff8ae07a5800         lock dec qword ptr [rdx + 0x587ae0]
0000d64b  4883c018                 add rax, 0x18
0000d64f  4d3bd1                   cmp r10, r9
0000d652  490f43c2                 cmovae rax, r10
0000d656  90                       nop
0000d657  0fb64810                 movzx ecx, byte ptr [rax + 0x10]
0000d65b  493bc1                   cmp rax, r9
0000d65e  0f8350ffffff             jae 0xd5b4
0000d664  84c9                     test cl, cl
0000d666  0f8548ffffff             jne 0xd5b4
0000d66c  4883c018                 add rax, 0x18
0000d670  90                       nop
0000d671  0fb64810                 movzx ecx, byte ptr [rax + 0x10]
0000d675  493bc1                   cmp rax, r9
0000d678  72ea                     jb 0xd664
0000d67a  e935ffffff               jmp 0xd5b4
0000d67f  49c1e820                 shr r8, 0x20
0000d683  0faee8                   lfence
0000d686  4181e0ff010000           and r8d, 0x1ff
0000d68d  4b8d0440                 lea rax, [r8 + r8*2]
0000d691  f048ff8cc7e07a5800       lock dec qword ptr [rdi + rax*8 + 0x587ae0]
0000d69a  488d542470               lea rdx, [rsp + 0x70]
0000d69f  498bcb                   mov rcx, r11
0000d6a2  e8592a0000               call 0x10100
0000d6a7  49638b00380000           movsxd rcx, dword ptr [r11 + 0x3800]
0000d6ae  85c9                     test ecx, ecx
0000d6b0  7509                     jne 0xd6bb
0000d6b2  48c7c2ffffffff           mov rdx, 0xffffffffffffffff
0000d6b9  eb2d                     jmp 0xd6e8
0000d6bb  8d41ff                   lea eax, [rcx - 1]
0000d6be  41898300380000           mov dword ptr [r11 + 0x3800], eax
0000d6c5  4963948bfc2f0000         movsxd rdx, dword ptr [r11 + rcx*4 + 0x2ffc]
0000d6cd  488d0452                 lea rax, [rdx + rdx*2]
0000d6d1  41c644c31101             mov byte ptr [r11 + rax*8 + 0x11], 1
0000d6d7  90                       nop
0000d6d8  498b4cc308               mov rcx, qword ptr [r11 + rax*8 + 8]
0000d6dd  48c1e220                 shl rdx, 0x20
0000d6e1  48c1e920                 shr rcx, 0x20
0000d6e5  480bd1                   or rdx, rcx
0000d6e8  4c895c2438               mov qword ptr [rsp + 0x38], r11
0000d6ed  4889542440               mov qword ptr [rsp + 0x40], rdx
0000d6f2  4883faff                 cmp rdx, -1
0000d6f6  0f84a8000000             je 0xd7a4
0000d6fc  488bc2                   mov rax, rdx
0000d6ff  48c1e820                 shr rax, 0x20
0000d703  8bc8                     mov ecx, eax
0000d705  25ff010000               and eax, 0x1ff
0000d70a  488d0440                 lea rax, [rax + rax*2]
0000d70e  4c8d04c500000000         lea r8, [rax*8]
0000d716  90                       nop
0000d717  470fb64c0311             movzx r9d, byte ptr [r11 + r8 + 0x11]
0000d71d  90                       nop
0000d71e  4b8b440308               mov rax, qword ptr [r11 + r8 + 8]
0000d723  48c1e820                 shr rax, 0x20
0000d727  3bc2                     cmp eax, edx
0000d729  0f8595000000             jne 0xd7c4
0000d72f  4584c9                   test r9b, r9b
0000d732  0f848c000000             je 0xd7c4
0000d738  43892c03                 mov dword ptr [r11 + r8], ebp
0000d73c  90                       nop
0000d73d  470fb64c0311             movzx r9d, byte ptr [r11 + r8 + 0x11]
0000d743  90                       nop
0000d744  4b8b440308               mov rax, qword ptr [r11 + r8 + 8]
0000d749  48c1e820                 shr rax, 0x20
0000d74d  3bc2                     cmp eax, edx
0000d74f  7573                     jne 0xd7c4
0000d751  4584c9                   test r9b, r9b
0000d754  746e                     je 0xd7c4
0000d756  4389740304               mov dword ptr [r11 + r8 + 4], esi
0000d75b  488b442438               mov rax, qword ptr [rsp + 0x38]
0000d760  90                       nop
0000d761  460fb64c0011             movzx r9d, byte ptr [rax + r8 + 0x11]
0000d767  90                       nop
0000d768  4a8b440008               mov rax, qword ptr [rax + r8 + 8]
0000d76d  48c1e820                 shr rax, 0x20
0000d771  3bc2                     cmp eax, edx
0000d773  7519                     jne 0xd78e
0000d775  4584c9                   test r9b, r9b
0000d778  7414                     je 0xd78e
0000d77a  81e1ff010000             and ecx, 0x1ff
0000d780  488d0c49                 lea rcx, [rcx + rcx*2]
0000d784  488b442438               mov rax, qword ptr [rsp + 0x38]
0000d789  c644c81001               mov byte ptr [rax + rcx*8 + 0x10], 1
0000d78e  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
0000d793  488bac2480000000         mov rbp, qword ptr [rsp + 0x80]
0000d79b  4883c450                 add rsp, 0x50
0000d79f  415e                     pop r14
0000d7a1  5f                       pop rdi
0000d7a2  5e                       pop rsi
0000d7a3  c3                       ret
0000d7a4  c744242000020000         mov dword ptr [rsp + 0x20], 0x200
0000d7ac  ba1b000000               mov edx, 0x1b
0000d7b1  b975010000               mov ecx, 0x175
0000d7b6  448d4ae6                 lea r9d, [rdx - 0x1a]
0000d7ba  448d42f5                 lea r8d, [rdx - 0xb]
0000d7be  e8ddbb0000               call 0x193a0
0000d7c3  cc                       int3
0000d7c4  ba5f000000               mov edx, 0x5f
0000d7c9  b94b010000               mov ecx, 0x14b
0000d7ce  448d4aa2                 lea r9d, [rdx - 0x5e]
0000d7d2  448d42b2                 lea r8d, [rdx - 0x4e]
0000d7d6  e8c5bb0000               call 0x193a0
0000d7db  cc                       int3
