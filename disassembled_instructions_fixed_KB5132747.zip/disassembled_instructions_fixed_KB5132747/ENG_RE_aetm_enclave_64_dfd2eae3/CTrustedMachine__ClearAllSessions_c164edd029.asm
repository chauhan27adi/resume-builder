; CTrustedMachine::ClearAllSessions
; aetm_enclave.dll, primary RVA 0xde10, 260 bytes in 1 chunk(s)

; chunk at RVA 0xde10 (260 bytes)
0000de10  48895c2408               mov qword ptr [rsp + 8], rbx
0000de15  48896c2410               mov qword ptr [rsp + 0x10], rbp
0000de1a  4889742418               mov qword ptr [rsp + 0x18], rsi
0000de1f  48897c2420               mov qword ptr [rsp + 0x20], rdi
0000de24  4156                     push r14
0000de26  4883ec20                 sub rsp, 0x20
0000de2a  488da9b03a0000           lea rbp, [rcx + 0x3ab0]
0000de31  90                       nop
0000de32  0fb691c8420000           movzx edx, byte ptr [rcx + 0x42c8]
0000de39  488d99b03a4100           lea rbx, [rcx + 0x413ab0]
0000de40  488bf1                   mov rsi, rcx
0000de43  488bc5                   mov rax, rbp
0000de46  483beb                   cmp rbp, rbx
0000de49  731c                     jae 0xde67
0000de4b  0f1f440000               nop dword ptr [rax + rax]
0000de50  84d2                     test dl, dl
0000de52  7513                     jne 0xde67
0000de54  480520080000             add rax, 0x820
0000de5a  90                       nop
0000de5b  0fb69018080000           movzx edx, byte ptr [rax + 0x818]
0000de62  483bc3                   cmp rax, rbx
0000de65  72e9                     jb 0xde50
0000de67  49bec10ffcc00ffcc00f     movabs r14, 0xfc0fc0fc0fc0fc1
0000de71  0f1f4000                 nop dword ptr [rax]
0000de75  6666660f1f840000000000   nop word ptr [rax + rax]
0000de80  90                       nop
0000de81  0fb68b18080000           movzx ecx, byte ptr [rbx + 0x818]
0000de88  488bf8                   mov rdi, rax
0000de8b  483bc3                   cmp rax, rbx
0000de8e  7469                     je 0xdef9
0000de90  90                       nop
0000de91  488bd0                   mov rdx, rax
0000de94  0fb68818080000           movzx ecx, byte ptr [rax + 0x818]
0000de9b  482bd5                   sub rdx, rbp
0000de9e  48c1fa05                 sar rdx, 5
0000dea2  90                       nop
0000dea3  488b8810080000           mov rcx, qword ptr [rax + 0x810]
0000deaa  490fafd6                 imul rdx, r14
0000deae  48c1e920                 shr rcx, 0x20
0000deb2  4863d2                   movsxd rdx, edx
0000deb5  48c1e220                 shl rdx, 0x20
0000deb9  480bd1                   or rdx, rcx
0000debc  488bce                   mov rcx, rsi
0000debf  e87cfeffff               call 0xdd40
0000dec4  483bfb                   cmp rdi, rbx
0000dec7  488d8720080000           lea rax, [rdi + 0x820]
0000dece  90                       nop
0000decf  480f43c7                 cmovae rax, rdi
0000ded3  0fb68818080000           movzx ecx, byte ptr [rax + 0x818]
0000deda  483bc3                   cmp rax, rbx
0000dedd  73a1                     jae 0xde80
0000dedf  90                       nop
0000dee0  84c9                     test cl, cl
0000dee2  759c                     jne 0xde80
0000dee4  480520080000             add rax, 0x820
0000deea  90                       nop
0000deeb  0fb68818080000           movzx ecx, byte ptr [rax + 0x818]
0000def2  483bc3                   cmp rax, rbx
0000def5  72e9                     jb 0xdee0
0000def7  eb87                     jmp 0xde80
0000def9  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0000defe  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
0000df03  488b742440               mov rsi, qword ptr [rsp + 0x40]
0000df08  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
0000df0d  4883c420                 add rsp, 0x20
0000df11  415e                     pop r14
0000df13  c3                       ret
