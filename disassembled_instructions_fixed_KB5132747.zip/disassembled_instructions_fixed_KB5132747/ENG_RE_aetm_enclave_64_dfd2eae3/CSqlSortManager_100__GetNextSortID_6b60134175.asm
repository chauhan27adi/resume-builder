; CSqlSortManager_100::GetNextSortID
; aetm_enclave.dll, primary RVA 0x53270, 4020 bytes in 1 chunk(s)

; chunk at RVA 0x53270 (4020 bytes)
00053270  48895c2408               mov qword ptr [rsp + 8], rbx
00053275  4889742410               mov qword ptr [rsp + 0x10], rsi
0005327a  48897c2418               mov qword ptr [rsp + 0x18], rdi
0005327f  55                       push rbp
00053280  4154                     push r12
00053282  4155                     push r13
00053284  4156                     push r14
00053286  4157                     push r15
00053288  488d6c24f0               lea rbp, [rsp - 0x10]
0005328d  4881ec10010000           sub rsp, 0x110
00053294  488b056d7d0500           mov rax, qword ptr [rip + 0x57d6d]
0005329b  4833c4                   xor rax, rsp
0005329e  48894508                 mov qword ptr [rbp + 8], rax
000532a2  4533e4                   xor r12d, r12d
000532a5  44894d80                 mov dword ptr [rbp - 0x80], r9d
000532a9  458b4810                 mov r9d, dword ptr [r8 + 0x10]
000532ad  498bf8                   mov rdi, r8
000532b0  418bc1                   mov eax, r9d
000532b3  4889542450               mov qword ptr [rsp + 0x50], rdx
000532b8  d1e8                     shr eax, 1
000532ba  4c8bd2                   mov r10, rdx
000532bd  2401                     and al, 1
000532bf  41c1e91a                 shr r9d, 0x1a
000532c3  4180e101                 and r9b, 1
000532c7  894588                   mov dword ptr [rbp - 0x78], eax
000532ca  418b8088000000           mov eax, dword ptr [r8 + 0x88]
000532d1  458bdc                   mov r11d, r12d
000532d4  48894d90                 mov qword ptr [rbp - 0x70], rcx
000532d8  4489642444               mov dword ptr [rsp + 0x44], r12d
000532dd  448964246c               mov dword ptr [rsp + 0x6c], r12d
000532e2  4489642458               mov dword ptr [rsp + 0x58], r12d
000532e7  44894c2460               mov dword ptr [rsp + 0x60], r9d
000532ec  c644244c01               mov byte ptr [rsp + 0x4c], 1
000532f1  413b8084000000           cmp eax, dword ptr [r8 + 0x84]
000532f8  0f850f0e0000             jne 0x5410d
000532fe  488b4578                 mov rax, qword ptr [rbp + 0x78]
00053302  4885c0                   test rax, rax
00053305  7403                     je 0x5330a
00053307  448818                   mov byte ptr [rax], r11b
0005330a  0fb7442464               movzx eax, word ptr [rsp + 0x64]
0005330f  4d8d703c                 lea r14, [r8 + 0x3c]
00053313  8b5d70                   mov ebx, dword ptr [rbp + 0x70]
00053316  668944245c               mov word ptr [rsp + 0x5c], ax
0005331b  eb13                     jmp 0x53330
0005331d  0f1f00                   nop dword ptr [rax]
00053320  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00053325  4533e4                   xor r12d, r12d
00053328  448b4c2460               mov r9d, dword ptr [rsp + 0x60]
0005332d  0f1f00                   nop dword ptr [rax]
00053330  8b575c                   mov edx, dword ptr [rdi + 0x5c]
00053333  418bf3                   mov esi, r11d
00053336  83fa01                   cmp edx, 1
00053339  7d5d                     jge 0x53398
0005333b  488b4730                 mov rax, qword ptr [rdi + 0x30]
0005333f  90                       nop
00053340  4885c0                   test rax, rax
00053343  7e44                     jle 0x53389
00053345  488b4718                 mov rax, qword ptr [rdi + 0x18]
00053349  4885c0                   test rax, rax
0005334c  740b                     je 0x53359
0005334e  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00053352  ffd0                     call rax
00053354  0fb7c8                   movzx ecx, ax
00053357  eb12                     jmp 0x5336b
00053359  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
0005335d  488b4728                 mov rax, qword ptr [rdi + 0x28]
00053361  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00053365  8d4201                   lea eax, [rdx + 1]
00053368  894738                   mov dword ptr [rdi + 0x38], eax
0005336b  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
0005336f  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00053374  8b575c                   mov edx, dword ptr [rdi + 0x5c]
00053377  48ff4f30                 dec qword ptr [rdi + 0x30]
0005337b  ffc2                     inc edx
0005337d  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053381  89575c                   mov dword ptr [rdi + 0x5c], edx
00053384  83fa01                   cmp edx, 1
00053387  7cb7                     jl 0x53340
00053389  4c8b542450               mov r10, qword ptr [rsp + 0x50]
0005338e  448b4c2460               mov r9d, dword ptr [rsp + 0x60]
00053393  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
00053398  85d2                     test edx, edx
0005339a  0f84aa0d0000             je 0x5414a
000533a0  8b8780000000             mov eax, dword ptr [rdi + 0x80]
000533a6  398788000000             cmp dword ptr [rdi + 0x88], eax
000533ac  0f8d910d0000             jge 0x54143
000533b2  498b4208                 mov rax, qword ptr [r10 + 8]
000533b6  41bd01000000             mov r13d, 1
000533bc  410fb70e                 movzx ecx, word ptr [r14]
000533c0  4489642448               mov dword ptr [rsp + 0x48], r12d
000533c5  4532e4                   xor r12b, r12b
000533c8  448b3c88                 mov r15d, dword ptr [rax + rcx*4]
000533cc  418bc7                   mov eax, r15d
000533cf  44897c2440               mov dword ptr [rsp + 0x40], r15d
000533d4  c1e818                   shr eax, 0x18
000533d7  837f0400                 cmp dword ptr [rdi + 4], 0
000533db  0f84a3000000             je 0x53484
000533e1  663b4f0c                 cmp cx, word ptr [rdi + 0xc]
000533e5  0f8599000000             jne 0x53484
000533eb  83fa02                   cmp edx, 2
000533ee  7d4d                     jge 0x5343d
000533f0  488b4730                 mov rax, qword ptr [rdi + 0x30]
000533f4  4885c0                   test rax, rax
000533f7  7e44                     jle 0x5343d
000533f9  488b4718                 mov rax, qword ptr [rdi + 0x18]
000533fd  4885c0                   test rax, rax
00053400  740b                     je 0x5340d
00053402  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00053406  ffd0                     call rax
00053408  0fb7c8                   movzx ecx, ax
0005340b  eb12                     jmp 0x5341f
0005340d  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
00053411  488b4728                 mov rax, qword ptr [rdi + 0x28]
00053415  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00053419  8d4201                   lea eax, [rdx + 1]
0005341c  894738                   mov dword ptr [rdi + 0x38], eax
0005341f  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00053423  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00053428  8b575c                   mov edx, dword ptr [rdi + 0x5c]
0005342b  48ff4f30                 dec qword ptr [rdi + 0x30]
0005342f  ffc2                     inc edx
00053431  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053435  89575c                   mov dword ptr [rdi + 0x5c], edx
00053438  83fa02                   cmp edx, 2
0005343b  7cb7                     jl 0x533f4
0005343d  413bd5                   cmp edx, r13d
00053440  0f84f60c0000             je 0x5413c
00053446  8d42ff                   lea eax, [rdx - 1]
00053449  498bce                   mov rcx, r14
0005344c  4c63c0                   movsxd r8, eax
0005344f  488d573e                 lea rdx, [rdi + 0x3e]
00053453  4d03c0                   add r8, r8
00053456  e8c4ad0000               call 0x5e21f
0005345b  ff4f5c                   dec dword ptr [rdi + 0x5c]
0005345e  4c8d059bcbfaff           lea r8, [rip - 0x53465]
00053465  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0005346a  410fb70e                 movzx ecx, word ptr [r14]
0005346e  8b542444                 mov edx, dword ptr [rsp + 0x44]
00053472  488b4308                 mov rax, qword ptr [rbx + 8]
00053476  448b3c88                 mov r15d, dword ptr [rax + rcx*4]
0005347a  44897c2440               mov dword ptr [rsp + 0x40], r15d
0005347f  e953040000               jmp 0x538d7
00053484  32db                     xor bl, bl
00053486  41837a1400               cmp dword ptr [r10 + 0x14], 0
0005348b  0f8425010000             je 0x535b6
00053491  8b4c2458                 mov ecx, dword ptr [rsp + 0x58]
00053495  a8c0                     test al, 0xc0
00053497  0f849a010000             je 0x53637
0005349d  49837a3000               cmp qword ptr [r10 + 0x30], 0
000534a2  0f848f010000             je 0x53637
000534a8  85c9                     test ecx, ecx
000534aa  0f8587010000             jne 0x53637
000534b0  4585db                   test r11d, r11d
000534b3  0f857e010000             jne 0x53637
000534b9  83fa08                   cmp edx, 8
000534bc  7d52                     jge 0x53510
000534be  488b4730                 mov rax, qword ptr [rdi + 0x30]
000534c2  4885c0                   test rax, rax
000534c5  7e44                     jle 0x5350b
000534c7  488b4718                 mov rax, qword ptr [rdi + 0x18]
000534cb  4885c0                   test rax, rax
000534ce  740b                     je 0x534db
000534d0  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000534d4  ffd0                     call rax
000534d6  0fb7c8                   movzx ecx, ax
000534d9  eb12                     jmp 0x534ed
000534db  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000534df  488b4728                 mov rax, qword ptr [rdi + 0x28]
000534e3  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
000534e7  8d4201                   lea eax, [rdx + 1]
000534ea  894738                   mov dword ptr [rdi + 0x38], eax
000534ed  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
000534f1  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
000534f6  8b575c                   mov edx, dword ptr [rdi + 0x5c]
000534f9  48ff4f30                 dec qword ptr [rdi + 0x30]
000534fd  ffc2                     inc edx
000534ff  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053503  89575c                   mov dword ptr [rdi + 0x5c], edx
00053506  83fa08                   cmp edx, 8
00053509  7cb7                     jl 0x534c2
0005350b  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00053510  33c0                     xor eax, eax
00053512  4c8975a8                 mov qword ptr [rbp - 0x58], r14
00053516  488945b8                 mov qword ptr [rbp - 0x48], rax
0005351a  4c8d4d98                 lea r9, [rbp - 0x68]
0005351e  0fbaf21f                 btr edx, 0x1f
00053522  410fb7c7                 movzx eax, r15w
00053526  48c1e020                 shl rax, 0x20
0005352a  498bcf                   mov rcx, r15
0005352d  48c1e910                 shr rcx, 0x10
00053531  4d8bc2                   mov r8, r10
00053534  480bc1                   or rax, rcx
00053537  8955b0                   mov dword ptr [rbp - 0x50], edx
0005353a  488d55a8                 lea rdx, [rbp - 0x58]
0005353e  48894598                 mov qword ptr [rbp - 0x68], rax
00053542  4c8975c0                 mov qword ptr [rbp - 0x40], r14
00053546  e8e5280000               call 0x55e30
0005354b  85c0                     test eax, eax
0005354d  7452                     je 0x535a1
0005354f  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053552  498bce                   mov rcx, r14
00053555  488b5da8                 mov rbx, qword ptr [rbp - 0x58]
00053559  482b5dc0                 sub rbx, qword ptr [rbp - 0x40]
0005355d  48d1fb                   sar rbx, 1
00053560  2bc3                     sub eax, ebx
00053562  4c63c0                   movsxd r8, eax
00053565  4863c3                   movsxd rax, ebx
00053568  4d03c0                   add r8, r8
0005356b  4883c01e                 add rax, 0x1e
0005356f  488d1447                 lea rdx, [rdi + rax*2]
00053573  e8a7ac0000               call 0x5e21f
00053578  488b4598                 mov rax, qword ptr [rbp - 0x68]
0005357c  295f5c                   sub dword ptr [rdi + 0x5c], ebx
0005357f  4c8bf8                   mov r15, rax
00053582  488bc8                   mov rcx, rax
00053585  49c1ef20                 shr r15, 0x20
00053589  48c1e110                 shl rcx, 0x10
0005358d  410fb6dd                 movzx ebx, r13b
00053591  440bf9                   or r15d, ecx
00053594  48c1e810                 shr rax, 0x10
00053598  440fb7c0                 movzx r8d, ax
0005359c  4489442448               mov dword ptr [rsp + 0x48], r8d
000535a1  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000535a6  4181e7ffffff3f           and r15d, 0x3fffffff
000535ad  44897c2440               mov dword ptr [rsp + 0x40], r15d
000535b2  84db                     test bl, bl
000535b4  7533                     jne 0x535e9
000535b6  4438642460               cmp byte ptr [rsp + 0x60], r12b
000535bb  742c                     je 0x535e9
000535bd  b800280000               mov eax, 0x2800
000535c2  b9ff030000               mov ecx, 0x3ff
000535c7  66410306                 add ax, word ptr [r14]
000535cb  663bc1                   cmp ax, cx
000535ce  7719                     ja 0x535e9
000535d0  4c8d4c2440               lea r9, [rsp + 0x40]
000535d5  4c8bc7                   mov r8, rdi
000535d8  498bd2                   mov rdx, r10
000535db  e8a0b4ffff               call 0x4ea80
000535e0  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
000535e5  440fb6e0                 movzx r12d, al
000535e9  837f0400                 cmp dword ptr [rdi + 4], 0
000535ed  0f84d4020000             je 0x538c7
000535f3  837c245800               cmp dword ptr [rsp + 0x58], 0
000535f8  0f85c9020000             jne 0x538c7
000535fe  8b5c246c                 mov ebx, dword ptr [rsp + 0x6c]
00053602  4c8d05f7c9faff           lea r8, [rip - 0x53609]
00053609  410fb706                 movzx eax, word ptr [r14]
0005360d  ffc3                     inc ebx
0005360f  83c0db                   add eax, -0x25
00053612  895c246c                 mov dword ptr [rsp + 0x6c], ebx
00053616  83f83a                   cmp eax, 0x3a
00053619  0f87a2020000             ja 0x538c1
0005361f  4898                     cdqe
00053621  410fb68400d0410500       movzx eax, byte ptr [r8 + rax + 0x541d0]
0005362a  418b8c80b4410500         mov ecx, dword ptr [r8 + rax*4 + 0x541b4]
00053632  4903c8                   add rcx, r8
00053635  ffe1                     jmp rcx
00053637  410fb7c7                 movzx eax, r15w
0005363b  66c1e808                 shr ax, 8
0005363f  3cfe                     cmp al, 0xfe
00053641  0f855fffffff             jne 0x535a6
00053647  49837a3800               cmp qword ptr [r10 + 0x38], 0
0005364c  0f8454ffffff             je 0x535a6
00053652  85c9                     test ecx, ecx
00053654  0f854cffffff             jne 0x535a6
0005365a  4585db                   test r11d, r11d
0005365d  7409                     je 0x53668
0005365f  4584c9                   test r9b, r9b
00053662  0f843effffff             je 0x535a6
00053668  83fa02                   cmp edx, 2
0005366b  7d52                     jge 0x536bf
0005366d  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053671  4885c0                   test rax, rax
00053674  7e44                     jle 0x536ba
00053676  488b4718                 mov rax, qword ptr [rdi + 0x18]
0005367a  4885c0                   test rax, rax
0005367d  740b                     je 0x5368a
0005367f  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00053683  ffd0                     call rax
00053685  0fb7c8                   movzx ecx, ax
00053688  eb12                     jmp 0x5369c
0005368a  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
0005368e  488b4728                 mov rax, qword ptr [rdi + 0x28]
00053692  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00053696  8d4201                   lea eax, [rdx + 1]
00053699  894738                   mov dword ptr [rdi + 0x38], eax
0005369c  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
000536a0  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
000536a5  8b575c                   mov edx, dword ptr [rdi + 0x5c]
000536a8  48ff4f30                 dec qword ptr [rdi + 0x30]
000536ac  ffc2                     inc edx
000536ae  488b4730                 mov rax, qword ptr [rdi + 0x30]
000536b2  89575c                   mov dword ptr [rdi + 0x5c], edx
000536b5  83fa02                   cmp edx, 2
000536b8  7cb7                     jl 0x53671
000536ba  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000536bf  450fb706                 movzx r8d, word ptr [r14]
000536c3  8bca                     mov ecx, edx
000536c5  4d8b4a38                 mov r9, qword ptr [r10 + 0x38]
000536c9  b8c0270000               mov eax, 0x27c0
000536ce  0fbaf11f                 btr ecx, 0x1f
000536d2  4103c0                   add eax, r8d
000536d5  6683f829                 cmp ax, 0x29
000536d9  7723                     ja 0x536fe
000536db  488d45f6                 lea rax, [rbp - 0xa]
000536df  4c3bf0                   cmp r14, rax
000536e2  742b                     je 0x5370f
000536e4  413bcd                   cmp ecx, r13d
000536e7  760d                     jbe 0x536f6
000536e9  450fb75e02               movzx r11d, word ptr [r14 + 2]
000536ee  6644895c245c             mov word ptr [rsp + 0x5c], r11w
000536f4  eb06                     jmp 0x536fc
000536f6  440fb75c245c             movzx r11d, word ptr [rsp + 0x5c]
000536fc  7722                     ja 0x53720
000536fe  4181e7ffffff3f           and r15d, 0x3fffffff
00053705  44897c2440               mov dword ptr [rsp + 0x40], r15d
0005370a  e9a7feffff               jmp 0x535b6
0005370f  413bcd                   cmp ecx, r13d
00053712  76ea                     jbe 0x536fe
00053714  33c0                     xor eax, eax
00053716  440fb718                 movzx r11d, word ptr [rax]
0005371a  6644895c245c             mov word ptr [rsp + 0x5c], r11w
00053720  b800240000               mov eax, 0x2400
00053725  b9ff030000               mov ecx, 0x3ff
0005372a  4103c3                   add eax, r11d
0005372d  663bc1                   cmp ax, cx
00053730  77cc                     ja 0x536fe
00053732  b8c9270000               mov eax, 0x27c9
00053737  664403c0                 add r8w, ax
0005373b  b800040000               mov eax, 0x400
00053740  410fb7c8                 movzx ecx, r8w
00053744  0fafc8                   imul ecx, eax
00053747  664103cb                 add cx, r11w
0005374b  0fb7c1                   movzx eax, cx
0005374e  6641833c8100             cmp word ptr [r9 + rax*4], 0
00053754  74a8                     je 0x536fe
00053756  418b0481                 mov eax, dword ptr [r9 + rax*4]
0005375a  498bce                   mov rcx, r14
0005375d  0fb7d8                   movzx ebx, ax
00053760  48c1e810                 shr rax, 0x10
00053764  48c1e320                 shl rbx, 0x20
00053768  480bd8                   or rbx, rax
0005376b  8d42ff                   lea eax, [rdx - 1]
0005376e  4c63c0                   movsxd r8, eax
00053771  488d573e                 lea rdx, [rdi + 0x3e]
00053775  4d03c0                   add r8, r8
00053778  e8a2aa0000               call 0x5e21f
0005377d  ff4f5c                   dec dword ptr [rdi + 0x5c]
00053780  488bc3                   mov rax, rbx
00053783  48c1e810                 shr rax, 0x10
00053787  440fb7c0                 movzx r8d, ax
0005378b  488bc3                   mov rax, rbx
0005378e  48c1e820                 shr rax, 0x20
00053792  48c1e310                 shl rbx, 0x10
00053796  0bc3                     or eax, ebx
00053798  4489442448               mov dword ptr [rsp + 0x48], r8d
0005379d  25ffffff3f               and eax, 0x3fffffff
000537a2  448bf8                   mov r15d, eax
000537a5  89442440                 mov dword ptr [rsp + 0x40], eax
000537a9  e93bfeffff               jmp 0x535e9
000537ae  8b542444                 mov edx, dword ptr [rsp + 0x44]
000537b2  33db                     xor ebx, ebx
000537b4  85d2                     test edx, edx
000537b6  751d                     jne 0x537d5
000537b8  b8fcff0000               mov eax, 0xfffc
000537bd  895c246c                 mov dword ptr [rsp + 0x6c], ebx
000537c1  418bd5                   mov edx, r13d
000537c4  6689442440               mov word ptr [rsp + 0x40], ax
000537c9  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
000537ce  89542444                 mov dword ptr [rsp + 0x44], edx
000537d2  895d80                   mov dword ptr [rbp - 0x80], ebx
000537d5  85f6                     test esi, esi
000537d7  448beb                   mov r13d, ebx
000537da  410f95c5                 setne r13b
000537de  e9ef000000               jmp 0x538d2
000537e3  8b542444                 mov edx, dword ptr [rsp + 0x44]
000537e7  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
000537ec  85d2                     test edx, edx
000537ee  0f84e3000000             je 0x538d7
000537f4  b8fbff0000               mov eax, 0xfffb
000537f9  33d2                     xor edx, edx
000537fb  6689442440               mov word ptr [rsp + 0x40], ax
00053800  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053805  89542444                 mov dword ptr [rsp + 0x44], edx
00053809  e9c9000000               jmp 0x538d7
0005380e  8b542444                 mov edx, dword ptr [rsp + 0x44]
00053812  85d2                     test edx, edx
00053814  0f84b8000000             je 0x538d2
0005381a  413bdd                   cmp ebx, r13d
0005381d  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00053822  0f85af000000             jne 0x538d7
00053828  b8f9ff0000               mov eax, 0xfff9
0005382d  6689442440               mov word ptr [rsp + 0x40], ax
00053832  33c0                     xor eax, eax
00053834  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053839  8944246c                 mov dword ptr [rsp + 0x6c], eax
0005383d  e995000000               jmp 0x538d7
00053842  ba02000000               mov edx, 2
00053847  488bcf                   mov rcx, rdi
0005384a  e8f16affff               call 0x4a340
0005384f  8b542444                 mov edx, dword ptr [rsp + 0x44]
00053853  85d2                     test edx, edx
00053855  7474                     je 0x538cb
00053857  413bdd                   cmp ebx, r13d
0005385a  7e6f                     jle 0x538cb
0005385c  4c8d059dc7faff           lea r8, [rip - 0x53863]
00053863  44396f5c                 cmp dword ptr [rdi + 0x5c], r13d
00053867  7e69                     jle 0x538d2
00053869  6641837e025d             cmp word ptr [r14 + 2], 0x5d
0005386f  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00053874  7461                     je 0x538d7
00053876  b8faff0000               mov eax, 0xfffa
0005387b  4533ed                   xor r13d, r13d
0005387e  6689442440               mov word ptr [rsp + 0x40], ax
00053883  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053888  eb4d                     jmp 0x538d7
0005388a  8b542444                 mov edx, dword ptr [rsp + 0x44]
0005388e  85d2                     test edx, edx
00053890  7540                     jne 0x538d2
00053892  b8f7ff0000               mov eax, 0xfff7
00053897  6689442440               mov word ptr [rsp + 0x40], ax
0005389c  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
000538a1  eb2f                     jmp 0x538d2
000538a3  8b542444                 mov edx, dword ptr [rsp + 0x44]
000538a7  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
000538ac  85d2                     test edx, edx
000538ae  7527                     jne 0x538d7
000538b0  b8feff0000               mov eax, 0xfffe
000538b5  6689442440               mov word ptr [rsp + 0x40], ax
000538ba  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
000538bf  eb16                     jmp 0x538d7
000538c1  8b542444                 mov edx, dword ptr [rsp + 0x44]
000538c5  eb0b                     jmp 0x538d2
000538c7  8b542444                 mov edx, dword ptr [rsp + 0x44]
000538cb  4c8d052ec7faff           lea r8, [rip - 0x538d2]
000538d2  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
000538d7  0fb7442440               movzx eax, word ptr [rsp + 0x40]
000538dc  4533f6                   xor r14d, r14d
000538df  c1e808                   shr eax, 8
000538e2  83f805                   cmp eax, 5
000538e5  0f874d060000             ja 0x53f38
000538eb  418b8c800c420500         mov ecx, dword ptr [r8 + rax*4 + 0x5420c]
000538f3  4903c8                   add rcx, r8
000538f6  ffe1                     jmp rcx
000538f8  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000538fb  488d573e                 lea rdx, [rdi + 0x3e]
000538ff  ffc8                     dec eax
00053901  488d4f3c                 lea rcx, [rdi + 0x3c]
00053905  4c63c0                   movsxd r8, eax
00053908  4d03c0                   add r8, r8
0005390b  e80fa90000               call 0x5e21f
00053910  488b8580000000           mov rax, qword ptr [rbp + 0x80]
00053917  41be01000000             mov r14d, 1
0005391d  ff4f5c                   dec dword ptr [rdi + 0x5c]
00053920  4885c0                   test rax, rax
00053923  7403                     je 0x53928
00053925  48ff00                   inc qword ptr [rax]
00053928  8b742448                 mov esi, dword ptr [rsp + 0x48]
0005392c  33db                     xor ebx, ebx
0005392e  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00053932  448b642458               mov r12d, dword ptr [rsp + 0x58]
00053937  4585e4                   test r12d, r12d
0005393a  7e0a                     jle 0x53946
0005393c  41ffcc                   dec r12d
0005393f  8919                     mov dword ptr [rcx], ebx
00053941  4489642458               mov dword ptr [rsp + 0x58], r12d
00053946  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
0005394b  4585f6                   test r14d, r14d
0005394e  8b5d70                   mov ebx, dword ptr [rbp + 0x70]
00053951  4c8d773c                 lea r14, [rdi + 0x3c]
00053955  0f85c5f9ffff             jne 0x53320
0005395b  8b475c                   mov eax, dword ptr [rdi + 0x5c]
0005395e  4c8d773c                 lea r14, [rdi + 0x3c]
00053962  ffc8                     dec eax
00053964  488d573e                 lea rdx, [rdi + 0x3e]
00053968  4c63c0                   movsxd r8, eax
0005396b  498bce                   mov rcx, r14
0005396e  4d03c0                   add r8, r8
00053971  e8a9a80000               call 0x5e21f
00053976  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053979  ffc8                     dec eax
0005397b  89475c                   mov dword ptr [rdi + 0x5c], eax
0005397e  4585e4                   test r12d, r12d
00053981  0f8424060000             je 0x53fab
00053987  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005398e  488b4768                 mov rax, qword ptr [rdi + 0x68]
00053992  44893c88                 mov dword ptr [rax + rcx*4], r15d
00053996  85db                     test ebx, ebx
00053998  740e                     je 0x539a8
0005399a  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000539a1  488b4770                 mov rax, qword ptr [rdi + 0x70]
000539a5  893488                   mov dword ptr [rax + rcx*4], esi
000539a8  ff8788000000             inc dword ptr [rdi + 0x88]
000539ae  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
000539b3  e968f9ffff               jmp 0x53320
000539b8  44387588                 cmp byte ptr [rbp - 0x78], r14b
000539bc  7411                     je 0x539cf
000539be  443874244c               cmp byte ptr [rsp + 0x4c], r14b
000539c3  740a                     je 0x539cf
000539c5  44397710                 cmp dword ptr [rdi + 0x10], r14d
000539c9  0f8d29ffffff             jge 0x538f8
000539cf  f7471000000040           test dword ptr [rdi + 0x10], 0x40000000
000539d6  0f844cffffff             je 0x53928
000539dc  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000539df  394738                   cmp dword ptr [rdi + 0x38], eax
000539e2  0f8540ffffff             jne 0x53928
000539e8  4439b788000000           cmp dword ptr [rdi + 0x88], r14d
000539ef  0f8533ffffff             jne 0x53928
000539f5  e9fefeffff               jmp 0x538f8
000539fa  488b4560                 mov rax, qword ptr [rbp + 0x60]
000539fe  448930                   mov dword ptr [rax], r14d
00053a01  44397568                 cmp dword ptr [rbp + 0x68], r14d
00053a05  7412                     je 0x53a19
00053a07  44397708                 cmp dword ptr [rdi + 8], r14d
00053a0b  0f8417ffffff             je 0x53928
00053a11  85d2                     test edx, edx
00053a13  0f850fffffff             jne 0x53928
00053a19  4c63475c                 movsxd r8, dword ptr [rdi + 0x5c]
00053a1d  418bcf                   mov ecx, r15d
00053a20  4d03c0                   add r8, r8
00053a23  48c1e910                 shr rcx, 0x10
00053a27  418bc7                   mov eax, r15d
00053a2a  48c1e020                 shl rax, 0x20
00053a2e  480bc1                   or rax, rcx
00053a31  488bc8                   mov rcx, rax
00053a34  48c1e820                 shr rax, 0x20
00053a38  6681e100ff               and cx, 0xff00
00053a3d  0fb7d1                   movzx edx, cx
00053a40  0fb6c8                   movzx ecx, al
00053a43  488b4590                 mov rax, qword ptr [rbp - 0x70]
00053a47  480bd1                   or rdx, rcx
00053a4a  488d4f3e                 lea rcx, [rdi + 0x3e]
00053a4e  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00053a55  8b1c90                   mov ebx, dword ptr [rax + rdx*4]
00053a58  488d573c                 lea rdx, [rdi + 0x3c]
00053a5c  e8bea70000               call 0x5e21f
00053a61  488b442450               mov rax, qword ptr [rsp + 0x50]
00053a66  8344245803               add dword ptr [rsp + 0x58], 3
00053a6b  66895f3c                 mov word ptr [rdi + 0x3c], bx
00053a6f  c1eb10                   shr ebx, 0x10
00053a72  66895f3e                 mov word ptr [rdi + 0x3e], bx
00053a76  8b575c                   mov edx, dword ptr [rdi + 0x5c]
00053a79  c7476001000000           mov dword ptr [rdi + 0x60], 1
00053a80  ffc2                     inc edx
00053a82  89575c                   mov dword ptr [rdi + 0x5c], edx
00053a85  0fb74f3e                 movzx ecx, word ptr [rdi + 0x3e]
00053a89  488b4008                 mov rax, qword ptr [rax + 8]
00053a8d  807c880102               cmp byte ptr [rax + rcx*4 + 1], 2
00053a92  4c8d3488                 lea r14, [rax + rcx*4]
00053a96  755b                     jne 0x53af3
00053a98  4c63c2                   movsxd r8, edx
00053a9b  488d4f40                 lea rcx, [rdi + 0x40]
00053a9f  4d03c0                   add r8, r8
00053aa2  488d573e                 lea rdx, [rdi + 0x3e]
00053aa6  e874a70000               call 0x5e21f
00053aab  418b0e                   mov ecx, dword ptr [r14]
00053aae  8bc1                     mov eax, ecx
00053ab0  48c1e910                 shr rcx, 0x10
00053ab4  48c1e020                 shl rax, 0x20
00053ab8  480bc1                   or rax, rcx
00053abb  488bc8                   mov rcx, rax
00053abe  48c1e820                 shr rax, 0x20
00053ac2  6681e100ff               and cx, 0xff00
00053ac7  0fb7d1                   movzx edx, cx
00053aca  0fb6c8                   movzx ecx, al
00053acd  488b4590                 mov rax, qword ptr [rbp - 0x70]
00053ad1  480bd1                   or rdx, rcx
00053ad4  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00053adb  8b0490                   mov eax, dword ptr [rax + rdx*4]
00053ade  6689473e                 mov word ptr [rdi + 0x3e], ax
00053ae2  c1e810                   shr eax, 0x10
00053ae5  66894740                 mov word ptr [rdi + 0x40], ax
00053ae9  ff475c                   inc dword ptr [rdi + 0x5c]
00053aec  ff4760                   inc dword ptr [rdi + 0x60]
00053aef  ff442458                 inc dword ptr [rsp + 0x58]
00053af3  41be01000000             mov r14d, 1
00053af9  e92afeffff               jmp 0x53928
00053afe  807c244001               cmp byte ptr [rsp + 0x40], 1
00053b03  770c                     ja 0x53b11
00053b05  488b4578                 mov rax, qword ptr [rbp + 0x78]
00053b09  4885c0                   test rax, rax
00053b0c  7403                     je 0x53b11
00053b0e  c60001                   mov byte ptr [rax], 1
00053b11  33db                     xor ebx, ebx
00053b13  418bc7                   mov eax, r15d
00053b16  48c1e810                 shr rax, 0x10
00053b1a  8bcb                     mov ecx, ebx
00053b1c  410fb7d7                 movzx edx, r15w
00053b20  48c1e220                 shl rdx, 0x20
00053b24  480bd0                   or rdx, rax
00053b27  395d80                   cmp dword ptr [rbp - 0x80], ebx
00053b2a  743d                     je 0x53b69
00053b2c  488b4560                 mov rax, qword ptr [rbp + 0x60]
00053b30  448b00                   mov r8d, dword ptr [rax]
00053b33  410fb7c8                 movzx ecx, r8w
00053b37  418bc0                   mov eax, r8d
00053b3a  48c1e120                 shl rcx, 0x20
00053b3e  48c1e810                 shr rax, 0x10
00053b42  480bc8                   or rcx, rax
00053b45  6641c1e808               shr r8w, 8
00053b4a  4180f822                 cmp r8b, 0x22
00053b4e  7419                     je 0x53b69
00053b50  395d70                   cmp dword ptr [rbp + 0x70], ebx
00053b53  7414                     je 0x53b69
00053b55  4c638788000000           movsxd r8, dword ptr [rdi + 0x88]
00053b5c  488b4770                 mov rax, qword ptr [rdi + 0x70]
00053b60  460fb74c80fc             movzx r9d, word ptr [rax + r8*4 - 4]
00053b66  490bc9                   or rcx, r9
00053b69  4c8bd2                   mov r10, rdx
00053b6c  895c2448                 mov dword ptr [rsp + 0x48], ebx
00053b70  49c1ea20                 shr r10, 0x20
00053b74  8bf3                     mov esi, ebx
00053b76  895c2440                 mov dword ptr [rsp + 0x40], ebx
00053b7a  4180fa01                 cmp r10b, 1
00053b7e  0f879e000000             ja 0x53c22
00053b84  4c8bc1                   mov r8, rcx
00053b87  49c1e828                 shr r8, 0x28
00053b8b  4180f803                 cmp r8b, 3
00053b8f  770f                     ja 0x53ba0
00053b91  48b800000000ffff0000     movabs rax, 0xffff00000000
00053b9b  e9e0000000               jmp 0x53c80
00053ba0  488bc1                   mov rax, rcx
00053ba3  48c1e810                 shr rax, 0x10
00053ba7  4180f822                 cmp r8b, 0x22
00053bab  7568                     jne 0x53c15
00053bad  4c8bc9                   mov r9, rcx
00053bb0  49c1e908                 shr r9, 8
00053bb4  450fb6c1                 movzx r8d, r9b
00053bb8  4180e0c6                 and r8b, 0xc6
00053bbc  4488442440               mov byte ptr [rsp + 0x40], r8b
00053bc1  450fb6c1                 movzx r8d, r9b
00053bc5  4180e0e4                 and r8b, 0xe4
00053bc9  4488442442               mov byte ptr [rsp + 0x42], r8b
00053bce  440fb7c2                 movzx r8d, dx
00053bd2  4584d2                   test r10b, r10b
00053bd5  751a                     jne 0x53bf1
00053bd7  48c1e010                 shl rax, 0x10
00053bdb  490bc0                   or rax, r8
00053bde  c644244104               mov byte ptr [rsp + 0x41], 4
00053be3  4180e1c5                 and r9b, 0xc5
00053be7  44884c2443               mov byte ptr [rsp + 0x43], r9b
00053bec  e97c000000               jmp 0x53c6d
00053bf1  ba000087ff               mov edx, 0xff870000
00053bf6  c644244105               mov byte ptr [rsp + 0x41], 5
00053bfb  4823c2                   and rax, rdx
00053bfe  48c1e010                 shl rax, 0x10
00053c02  490bc0                   or rax, r8
00053c05  488bd0                   mov rdx, rax
00053c08  48c1ea08                 shr rdx, 8
00053c0c  80e2c5                   and dl, 0xc5
00053c0f  88542443                 mov byte ptr [rsp + 0x43], dl
00053c13  eb58                     jmp 0x53c6d
00053c15  48c1e010                 shl rax, 0x10
00053c19  440fb6c2                 movzx r8d, dl
00053c1d  490bc0                   or rax, r8
00053c20  eb53                     jmp 0x53c75
00053c22  488bc2                   mov rax, rdx
00053c25  c644244103               mov byte ptr [rsp + 0x41], 3
00053c2a  48b9ffffffffff22ffff     movabs rcx, 0xffff22ffffffffff
00053c34  4823c1                   and rax, rcx
00053c37  48b90000000000220000     movabs rcx, 0x220000000000
00053c41  480bc1                   or rax, rcx
00053c44  4c8bc0                   mov r8, rax
00053c47  488bc8                   mov rcx, rax
00053c4a  49c1e808                 shr r8, 8
00053c4e  410fb6d0                 movzx edx, r8b
00053c52  80e2c6                   and dl, 0xc6
00053c55  88542440                 mov byte ptr [rsp + 0x40], dl
00053c59  410fb6d0                 movzx edx, r8b
00053c5d  80e2e4                   and dl, 0xe4
00053c60  4180e0c5                 and r8b, 0xc5
00053c64  88542442                 mov byte ptr [rsp + 0x42], dl
00053c68  4488442443               mov byte ptr [rsp + 0x43], r8b
00053c6d  8b742440                 mov esi, dword ptr [rsp + 0x40]
00053c71  89742448                 mov dword ptr [rsp + 0x48], esi
00053c75  4825ff02ffff             and rax, 0xffffffffffff02ff
00053c7b  480fbae809               bts rax, 9
00053c80  488bd0                   mov rdx, rax
00053c83  48c1ea28                 shr rdx, 0x28
00053c87  80fa22                   cmp dl, 0x22
00053c8a  740e                     je 0x53c9a
00053c8c  488bd0                   mov rdx, rax
00053c8f  48c1ea10                 shr rdx, 0x10
00053c93  0fb7f2                   movzx esi, dx
00053c96  89742448                 mov dword ptr [rsp + 0x48], esi
00053c9a  488bd0                   mov rdx, rax
00053c9d  48c1e010                 shl rax, 0x10
00053ca1  48c1ea20                 shr rdx, 0x20
00053ca5  0bd0                     or edx, eax
00053ca7  89542440                 mov dword ptr [rsp + 0x40], edx
00053cab  448bfa                   mov r15d, edx
00053cae  80fa01                   cmp dl, 1
00053cb1  0f8677fcffff             jbe 0x5392e
00053cb7  488bc1                   mov rax, rcx
00053cba  48c1e110                 shl rcx, 0x10
00053cbe  48c1e820                 shr rax, 0x20
00053cc2  0bc1                     or eax, ecx
00053cc4  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00053cc8  8901                     mov dword ptr [rcx], eax
00053cca  e963fcffff               jmp 0x53932
00053ccf  4c8d673c                 lea r12, [rdi + 0x3c]
00053cd3  b860110000               mov eax, 0x1160
00053cd8  6641390424               cmp word ptr [r12], ax
00053cdd  0f83e7010000             jae 0x53eca
00053ce3  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053ce6  83f803                   cmp eax, 3
00053ce9  7d4e                     jge 0x53d39
00053ceb  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00053cef  90                       nop
00053cf0  4885c9                   test rcx, rcx
00053cf3  7e44                     jle 0x53d39
00053cf5  488b4718                 mov rax, qword ptr [rdi + 0x18]
00053cf9  4885c0                   test rax, rax
00053cfc  740b                     je 0x53d09
00053cfe  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00053d02  ffd0                     call rax
00053d04  0fb7c8                   movzx ecx, ax
00053d07  eb12                     jmp 0x53d1b
00053d09  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
00053d0d  488b4728                 mov rax, qword ptr [rdi + 0x28]
00053d11  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00053d15  8d4201                   lea eax, [rdx + 1]
00053d18  894738                   mov dword ptr [rdi + 0x38], eax
00053d1b  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00053d1f  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00053d24  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053d27  48ff4f30                 dec qword ptr [rdi + 0x30]
00053d2b  ffc0                     inc eax
00053d2d  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00053d31  89475c                   mov dword ptr [rdi + 0x5c], eax
00053d34  83f803                   cmp eax, 3
00053d37  7cb7                     jl 0x53cf0
00053d39  488b4d90                 mov rcx, qword ptr [rbp - 0x70]
00053d3d  4c8d4c2464               lea r9, [rsp + 0x64]
00053d42  0fbaf01f                 btr eax, 0x1f
00053d46  4c8965c8                 mov qword ptr [rbp - 0x38], r12
00053d4a  8945d0                   mov dword ptr [rbp - 0x30], eax
00053d4d  4c8d45c8                 lea r8, [rbp - 0x38]
00053d51  488d4584                 lea rax, [rbp - 0x7c]
00053d55  4c8965e0                 mov qword ptr [rbp - 0x20], r12
00053d59  4889442430               mov qword ptr [rsp + 0x30], rax
00053d5e  4533ff                   xor r15d, r15d
00053d61  488d442468               lea rax, [rsp + 0x68]
00053d66  c744242803000000         mov dword ptr [rsp + 0x28], 3
00053d6e  488bd3                   mov rdx, rbx
00053d71  4889442420               mov qword ptr [rsp + 0x20], rax
00053d76  4c897dd8                 mov qword ptr [rbp - 0x28], r15
00053d7a  e8f1d9ffff               call 0x51770
00053d7f  8bf0                     mov esi, eax
00053d81  85c0                     test eax, eax
00053d83  0f8e41010000             jle 0x53eca
00053d89  0faee8                   lfence
00053d8c  0fb7442464               movzx eax, word ptr [rsp + 0x64]
00053d91  48639788000000           movsxd rdx, dword ptr [rdi + 0x88]
00053d98  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
00053d9c  448b4570                 mov r8d, dword ptr [rbp + 0x70]
00053da0  6689442470               mov word ptr [rsp + 0x70], ax
00053da5  66c74424720202           mov word ptr [rsp + 0x72], 0x202
00053dac  8b442470                 mov eax, dword ptr [rsp + 0x70]
00053db0  890491                   mov dword ptr [rcx + rdx*4], eax
00053db3  4585c0                   test r8d, r8d
00053db6  740f                     je 0x53dc7
00053db8  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053dbf  488b4770                 mov rax, qword ptr [rdi + 0x70]
00053dc3  44893c88                 mov dword ptr [rax + rcx*4], r15d
00053dc7  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053dce  41b900ff0000             mov r9d, 0xff00
00053dd4  488bd1                   mov rdx, rcx
00053dd7  66c74424760202           mov word ptr [rsp + 0x76], 0x202
00053dde  8d4101                   lea eax, [rcx + 1]
00053de1  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
00053de5  898788000000             mov dword ptr [rdi + 0x88], eax
00053deb  0fb6442468               movzx eax, byte ptr [rsp + 0x68]
00053df0  66410bc1                 or ax, r9w
00053df4  6689442474               mov word ptr [rsp + 0x74], ax
00053df9  8b442474                 mov eax, dword ptr [rsp + 0x74]
00053dfd  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
00053e01  4585c0                   test r8d, r8d
00053e04  740f                     je 0x53e15
00053e06  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053e0d  488b4770                 mov rax, qword ptr [rdi + 0x70]
00053e11  44893c88                 mov dword ptr [rax + rcx*4], r15d
00053e15  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053e1c  488bd1                   mov rdx, rcx
00053e1f  66c744247a0202           mov word ptr [rsp + 0x7a], 0x202
00053e26  8d4101                   lea eax, [rcx + 1]
00053e29  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
00053e2d  898788000000             mov dword ptr [rdi + 0x88], eax
00053e33  0fb6442469               movzx eax, byte ptr [rsp + 0x69]
00053e38  66410bc1                 or ax, r9w
00053e3c  6689442478               mov word ptr [rsp + 0x78], ax
00053e41  8b442478                 mov eax, dword ptr [rsp + 0x78]
00053e45  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
00053e49  4585c0                   test r8d, r8d
00053e4c  740f                     je 0x53e5d
00053e4e  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053e55  488b4770                 mov rax, qword ptr [rdi + 0x70]
00053e59  44893c88                 mov dword ptr [rax + rcx*4], r15d
00053e5d  0fb644246a               movzx eax, byte ptr [rsp + 0x6a]
00053e62  488d573c                 lea rdx, [rdi + 0x3c]
00053e66  ff8788000000             inc dword ptr [rdi + 0x88]
00053e6c  66410bc1                 or ax, r9w
00053e70  668944247c               mov word ptr [rsp + 0x7c], ax
00053e75  ffce                     dec esi
00053e77  4863c6                   movsxd rax, esi
00053e7a  498bcc                   mov rcx, r12
00053e7d  66c744247e0202           mov word ptr [rsp + 0x7e], 0x202
00053e84  448b7c247c               mov r15d, dword ptr [rsp + 0x7c]
00053e89  44897c2440               mov dword ptr [rsp + 0x40], r15d
00053e8e  488d1c00                 lea rbx, [rax + rax]
00053e92  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053e95  2bc6                     sub eax, esi
00053e97  4803d3                   add rdx, rbx
00053e9a  4c63c0                   movsxd r8, eax
00053e9d  4d03c0                   add r8, r8
00053ea0  e87aa30000               call 0x5e21f
00053ea5  29775c                   sub dword ptr [rdi + 0x5c], esi
00053ea8  420fb70c23               movzx ecx, word ptr [rbx + r12]
00053ead  33db                     xor ebx, ebx
00053eaf  488b442450               mov rax, qword ptr [rsp + 0x50]
00053eb4  8b742448                 mov esi, dword ptr [rsp + 0x48]
00053eb8  488b4008                 mov rax, qword ptr [rax + 8]
00053ebc  8b1488                   mov edx, dword ptr [rax + rcx*4]
00053ebf  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00053ec3  8911                     mov dword ptr [rcx], edx
00053ec5  e968faffff               jmp 0x53932
00053eca  410fb70c24               movzx ecx, word ptr [r12]
00053ecf  488b4308                 mov rax, qword ptr [rbx + 8]
00053ed3  8b742448                 mov esi, dword ptr [rsp + 0x48]
00053ed7  8b1488                   mov edx, dword ptr [rax + rcx*4]
00053eda  8bc2                     mov eax, edx
00053edc  c1e810                   shr eax, 0x10
00053edf  0fb6c8                   movzx ecx, al
00053ee2  89542440                 mov dword ptr [rsp + 0x40], edx
00053ee6  c644244202               mov byte ptr [rsp + 0x42], 2
00053eeb  0fb6c2                   movzx eax, dl
00053eee  66c1e008                 shl ax, 8
00053ef2  660bc8                   or cx, ax
00053ef5  66894c2440               mov word ptr [rsp + 0x40], cx
00053efa  33db                     xor ebx, ebx
00053efc  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00053f00  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053f05  8911                     mov dword ptr [rcx], edx
00053f07  e926faffff               jmp 0x53932
00053f0c  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00053f10  410fb6f7                 movzx esi, r15b
00053f14  c1e608                   shl esi, 8
00053f17  c7442440fffd0202         mov dword ptr [rsp + 0x40], 0x202fdff
00053f1f  448939                   mov dword ptr [rcx], r15d
00053f22  0fb64102                 movzx eax, byte ptr [rcx + 2]
00053f26  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053f2b  0bf0                     or esi, eax
00053f2d  89742448                 mov dword ptr [rsp + 0x48], esi
00053f31  33db                     xor ebx, ebx
00053f33  e9faf9ffff               jmp 0x53932
00053f38  488b4560                 mov rax, qword ptr [rbp + 0x60]
00053f3c  410fb7cf                 movzx ecx, r15w
00053f40  48c1e120                 shl rcx, 0x20
00053f44  448938                   mov dword ptr [rax], r15d
00053f47  418bc7                   mov eax, r15d
00053f4a  48c1e810                 shr rax, 0x10
00053f4e  480bc8                   or rcx, rax
00053f51  488bc1                   mov rax, rcx
00053f54  440fb6c9                 movzx r9d, cl
00053f58  48c1e828                 shr rax, 0x28
00053f5c  0440                     add al, 0x40
00053f5e  3c30                     cmp al, 0x30
00053f60  7724                     ja 0x53f86
00053f62  448b03                   mov r8d, dword ptr [rbx]
00053f65  41b9ff030000             mov r9d, 0x3ff
00053f6b  418bc0                   mov eax, r8d
00053f6e  0fb6d1                   movzx edx, cl
00053f71  4123c1                   and eax, r9d
00053f74  83f804                   cmp eax, 4
00053f77  741a                     je 0x53f93
00053f79  440fb6c9                 movzx r9d, cl
00053f7d  4181f811040400           cmp r8d, 0x40411
00053f84  740d                     je 0x53f93
00053f86  410fb6d1                 movzx edx, r9b
00053f8a  4584e4                   test r12b, r12b
00053f8d  0f8495f9ffff             je 0x53928
00053f93  48c1e908                 shr rcx, 8
00053f97  0fb6c2                   movzx eax, dl
00053f9a  0fb6f1                   movzx esi, cl
00053f9d  c1e008                   shl eax, 8
00053fa0  0bf0                     or esi, eax
00053fa2  89742448                 mov dword ptr [rsp + 0x48], esi
00053fa6  e981f9ffff               jmp 0x5392c
00053fab  4585ed                   test r13d, r13d
00053fae  0f841f010000             je 0x540d3
00053fb4  8b742460                 mov esi, dword ptr [rsp + 0x60]
00053fb8  c644244c01               mov byte ptr [rsp + 0x4c], 1
00053fbd  8bc8                     mov ecx, eax
00053fbf  83f801                   cmp eax, 1
00053fc2  7d4d                     jge 0x54011
00053fc4  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053fc8  4885c0                   test rax, rax
00053fcb  7e44                     jle 0x54011
00053fcd  488b4718                 mov rax, qword ptr [rdi + 0x18]
00053fd1  4885c0                   test rax, rax
00053fd4  740b                     je 0x53fe1
00053fd6  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00053fda  ffd0                     call rax
00053fdc  0fb7c8                   movzx ecx, ax
00053fdf  eb12                     jmp 0x53ff3
00053fe1  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
00053fe5  488b4728                 mov rax, qword ptr [rdi + 0x28]
00053fe9  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00053fed  8d4201                   lea eax, [rdx + 1]
00053ff0  894738                   mov dword ptr [rdi + 0x38], eax
00053ff3  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00053ff7  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00053ffc  8b4f5c                   mov ecx, dword ptr [rdi + 0x5c]
00053fff  48ff4f30                 dec qword ptr [rdi + 0x30]
00054003  ffc1                     inc ecx
00054005  488b4730                 mov rax, qword ptr [rdi + 0x30]
00054009  894f5c                   mov dword ptr [rdi + 0x5c], ecx
0005400c  83f901                   cmp ecx, 1
0005400f  7cb7                     jl 0x53fc8
00054011  85c9                     test ecx, ecx
00054013  0f84af000000             je 0x540c8
00054019  41b9f7ff0000             mov r9d, 0xfff7
0005401f  6644394c2440             cmp word ptr [rsp + 0x40], r9w
00054025  7527                     jne 0x5404e
00054027  6641833e25               cmp word ptr [r14], 0x25
0005402c  7520                     jne 0x5404e
0005402e  8d41ff                   lea eax, [rcx - 1]
00054031  4c63c0                   movsxd r8, eax
00054034  488d573e                 lea rdx, [rdi + 0x3e]
00054038  4d03c0                   add r8, r8
0005403b  498bce                   mov rcx, r14
0005403e  e8dca10000               call 0x5e21f
00054043  ff4f5c                   dec dword ptr [rdi + 0x5c]
00054046  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00054049  e96fffffff               jmp 0x53fbd
0005404e  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00054053  450fb706                 movzx r8d, word ptr [r14]
00054057  498b4208                 mov rax, qword ptr [r10 + 8]
0005405b  428b1480                 mov edx, dword ptr [rax + r8*4]
0005405f  8bc2                     mov eax, edx
00054061  c1e810                   shr eax, 0x10
00054064  66c1ea08                 shr dx, 8
00054068  84d2                     test dl, dl
0005406a  752f                     jne 0x5409b
0005406c  4084f6                   test sil, sil
0005406f  7457                     je 0x540c8
00054071  b800280000               mov eax, 0x2800
00054076  664403c0                 add r8w, ax
0005407a  b8ff030000               mov eax, 0x3ff
0005407f  66443bc0                 cmp r8w, ax
00054083  7743                     ja 0x540c8
00054085  4c8d4da0                 lea r9, [rbp - 0x60]
00054089  4c8bc7                   mov r8, rdi
0005408c  498bd2                   mov rdx, r10
0005408f  e8eca9ffff               call 0x4ea80
00054094  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00054097  ffc8                     dec eax
00054099  eb96                     jmp 0x54031
0005409b  80fa01                   cmp dl, 1
0005409e  7528                     jne 0x540c8
000540a0  6644394c2440             cmp word ptr [rsp + 0x40], r9w
000540a6  7386                     jae 0x5402e
000540a8  0fb6d0                   movzx edx, al
000540ab  0fb6442442               movzx eax, byte ptr [rsp + 0x42]
000540b0  6603d0                   add dx, ax
000540b3  b8ff000000               mov eax, 0xff
000540b8  663bd0                   cmp dx, ax
000540bb  7602                     jbe 0x540bf
000540bd  8bd0                     mov edx, eax
000540bf  88542442                 mov byte ptr [rsp + 0x42], dl
000540c3  e966ffffff               jmp 0x5402e
000540c8  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
000540cd  8b742448                 mov esi, dword ptr [rsp + 0x48]
000540d1  eb05                     jmp 0x540d8
000540d3  c644244c00               mov byte ptr [rsp + 0x4c], 0
000540d8  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000540df  488b4768                 mov rax, qword ptr [rdi + 0x68]
000540e3  44893c88                 mov dword ptr [rax + rcx*4], r15d
000540e7  85db                     test ebx, ebx
000540e9  740e                     je 0x540f9
000540eb  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000540f2  488b4770                 mov rax, qword ptr [rdi + 0x70]
000540f6  893488                   mov dword ptr [rax + rcx*4], esi
000540f9  ff8788000000             inc dword ptr [rdi + 0x88]
000540ff  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
00054104  4585db                   test r11d, r11d
00054107  0f8513f2ffff             jne 0x53320
0005410d  33c0                     xor eax, eax
0005410f  488b4d08                 mov rcx, qword ptr [rbp + 8]
00054113  4833cc                   xor rcx, rsp
00054116  e8b58c0000               call 0x5cdd0
0005411b  4c8d9c2410010000         lea r11, [rsp + 0x110]
00054123  498b5b30                 mov rbx, qword ptr [r11 + 0x30]
00054127  498b7338                 mov rsi, qword ptr [r11 + 0x38]
0005412b  498b7b40                 mov rdi, qword ptr [r11 + 0x40]
0005412f  498be3                   mov rsp, r11
00054132  415f                     pop r15
00054134  415e                     pop r14
00054136  415d                     pop r13
00054138  415c                     pop r12
0005413a  5d                       pop rbp
0005413b  c3                       ret
0005413c  b803000000               mov eax, 3
00054141  ebcc                     jmp 0x5410f
00054143  b802000000               mov eax, 2
00054148  ebc5                     jmp 0x5410f
0005414a  4585db                   test r11d, r11d
0005414d  741a                     je 0x54169
0005414f  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00054156  bafbff0000               mov edx, 0xfffb
0005415b  488b4768                 mov rax, qword ptr [rdi + 0x68]
0005415f  66891488                 mov word ptr [rax + rcx*4], dx
00054163  ff8788000000             inc dword ptr [rdi + 0x88]
00054169  8b9788000000             mov edx, dword ptr [rdi + 0x88]
0005416f  3b9784000000             cmp edx, dword ptr [rdi + 0x84]
00054175  7596                     jne 0x5410d
00054177  f7471000000008           test dword ptr [rdi + 0x10], 0x8000000
0005417e  7428                     je 0x541a8
00054180  498b4a08                 mov rcx, qword ptr [r10 + 8]
00054184  4c63c2                   movsxd r8, edx
00054187  488b5768                 mov rdx, qword ptr [rdi + 0x68]
0005418b  8b8980000000             mov ecx, dword ptr [rcx + 0x80]
00054191  42890c82                 mov dword ptr [rdx + r8*4], ecx
00054195  85db                     test ebx, ebx
00054197  740f                     je 0x541a8
00054199  48639788000000           movsxd rdx, dword ptr [rdi + 0x88]
000541a0  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
000541a4  44892491                 mov dword ptr [rcx + rdx*4], r12d
000541a8  b801000000               mov eax, 1
000541ad  e95dffffff               jmp 0x5410f
000541b2  6690                     nop
000541b4  8a38                     mov bh, byte ptr [rax]
000541b6  0500423805               add eax, 0x5384200
000541bb  00ae370500e3             add byte ptr [rsi - 0x1cfffac9], ch
