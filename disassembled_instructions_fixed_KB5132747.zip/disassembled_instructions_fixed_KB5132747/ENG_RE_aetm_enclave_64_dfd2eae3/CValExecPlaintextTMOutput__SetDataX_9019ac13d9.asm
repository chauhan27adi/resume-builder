; CValExecPlaintextTMOutput::SetDataX
; aetm_enclave.dll, primary RVA 0x16ea0, 776 bytes in 11 chunk(s)

; chunk at RVA 0x16ea0 (65 bytes)
00016ea0  4057                     push rdi
00016ea2  4883ec30                 sub rsp, 0x30
00016ea6  498bf8                   mov rdi, r8
00016ea9  4c8b4208                 mov r8, qword ptr [rdx + 8]
00016ead  4d85c0                   test r8, r8
00016eb0  0f840c020000             je 0x170c2
00016eb6  8b5108                   mov edx, dword ptr [rcx + 8]
00016eb9  ffc2                     inc edx
00016ebb  48c1e205                 shl rdx, 5
00016ebf  4903d0                   add rdx, r8
00016ec2  493bd0                   cmp rdx, r8
00016ec5  0f82f7010000             jb 0x170c2
00016ecb  483b1566eb4500           cmp rdx, qword ptr [rip + 0x45eb66]
00016ed2  760d                     jbe 0x16ee1
00016ed4  4c3b0555eb4500           cmp r8, qword ptr [rip + 0x45eb55]
00016edb  0f82e1010000             jb 0x170c2

; chunk at RVA 0x16ee1 (37 bytes)
00016ee1  48895c2440               mov qword ptr [rsp + 0x40], rbx
00016ee6  0faee8                   lfence
00016ee9  8b5908                   mov ebx, dword ptr [rcx + 8]
00016eec  48c1e305                 shl rbx, 5
00016ef0  4903d8                   add rbx, r8
00016ef3  803f03                   cmp byte ptr [rdi], 3
00016ef6  750e                     jne 0x16f06
00016ef8  c60303                   mov byte ptr [rbx], 3
00016efb  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00016f00  4883c430                 add rsp, 0x30
00016f04  5f                       pop rdi
00016f05  c3                       ret

; chunk at RVA 0x16f06 (238 bytes)
00016f06  0fb65110                 movzx edx, byte ptr [rcx + 0x10]
00016f0a  4c8d05ef90feff           lea r8, [rip - 0x16f11]
00016f11  420fb68402405a0600       movzx eax, byte ptr [rdx + r8 + 0x65a40]
00016f1a  4280bc00405b060001       cmp byte ptr [rax + r8 + 0x65b40], 1
00016f23  0f85cb000000             jne 0x16ff4
00016f29  8b4310                   mov eax, dword ptr [rbx + 0x10]
00016f2c  3b4710                   cmp eax, dword ptr [rdi + 0x10]
00016f2f  0f82b4010000             jb 0x170e9
00016f35  488b4b08                 mov rcx, qword ptr [rbx + 8]
00016f39  4c89742458               mov qword ptr [rsp + 0x58], r14
00016f3e  4885c9                   test rcx, rcx
00016f41  0f84ca010000             je 0x17111
00016f47  448bf0                   mov r14d, eax
00016f4a  4803c1                   add rax, rcx
00016f4d  483bc1                   cmp rax, rcx
00016f50  0f82bb010000             jb 0x17111
00016f56  483b05dbea4500           cmp rax, qword ptr [rip + 0x45eadb]
00016f5d  760d                     jbe 0x16f6c
00016f5f  483b0dcaea4500           cmp rcx, qword ptr [rip + 0x45eaca]
00016f66  0f82a5010000             jb 0x17111
00016f6c  48896c2448               mov qword ptr [rsp + 0x48], rbp
00016f71  4889742450               mov qword ptr [rsp + 0x50], rsi
00016f76  0faee8                   lfence
00016f79  8b7710                   mov esi, dword ptr [rdi + 0x10]
00016f7c  488b6f08                 mov rbp, qword ptr [rdi + 8]
00016f80  4885f6                   test rsi, rsi
00016f83  744b                     je 0x16fd0
00016f85  4885ed                   test rbp, rbp
00016f88  7412                     je 0x16f9c
00016f8a  4c3bf6                   cmp r14, rsi
00016f8d  720d                     jb 0x16f9c
00016f8f  448bc6                   mov r8d, esi
00016f92  488bd5                   mov rdx, rbp
00016f95  e879720400               call 0x5e213
00016f9a  eb34                     jmp 0x16fd0
00016f9c  4d8bc6                   mov r8, r14
00016f9f  33d2                     xor edx, edx
00016fa1  e885720400               call 0x5e22b
00016fa6  4885ed                   test rbp, rbp
00016fa9  750e                     jne 0x16fb9
00016fab  ff15e7c10400             call qword ptr [rip + 0x4c1e7]
00016fb1  c70016000000             mov dword ptr [rax], 0x16
00016fb7  eb11                     jmp 0x16fca
00016fb9  4c3bf6                   cmp r14, rsi
00016fbc  7312                     jae 0x16fd0
00016fbe  ff15d4c10400             call qword ptr [rip + 0x4c1d4]
00016fc4  c70022000000             mov dword ptr [rax], 0x22
00016fca  ff15d0c10400             call qword ptr [rip + 0x4c1d0]
00016fd0  8b4710                   mov eax, dword ptr [rdi + 0x10]
00016fd3  488b742450               mov rsi, qword ptr [rsp + 0x50]
00016fd8  488b6c2448               mov rbp, qword ptr [rsp + 0x48]
00016fdd  4c8b742458               mov r14, qword ptr [rsp + 0x58]
00016fe2  48894310                 mov qword ptr [rbx + 0x10], rax
00016fe6  c60300                   mov byte ptr [rbx], 0
00016fe9  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00016fee  4883c430                 add rsp, 0x30
00016ff2  5f                       pop rdi
00016ff3  c3                       ret

; chunk at RVA 0x16ff4 (73 bytes)
00016ff4  8d42dc                   lea eax, [rdx - 0x24]
00016ff7  83f85b                   cmp eax, 0x5b
00016ffa  0f87b4000000             ja 0x170b4
00017000  4898                     cdqe
00017002  410fb684004c710100       movzx eax, byte ptr [r8 + rax + 0x1714c]
0001700b  418b8c8038710100         mov ecx, dword ptr [r8 + rax*4 + 0x17138]
00017013  4903c8                   add rcx, r8
00017016  ffe1                     jmp rcx
00017018  0f1007                   movups xmm0, xmmword ptr [rdi]
0001701b  b8feff0000               mov eax, 0xfffe
00017020  0f1103                   movups xmmword ptr [rbx], xmm0
00017023  0f104f10                 movups xmm1, xmmword ptr [rdi + 0x10]
00017027  0f114b10                 movups xmmword ptr [rbx + 0x10], xmm1
0001702b  66214302                 and word ptr [rbx + 2], ax
0001702f  c60300                   mov byte ptr [rbx], 0
00017032  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00017037  4883c430                 add rsp, 0x30
0001703b  5f                       pop rdi
0001703c  c3                       ret

; chunk at RVA 0x1703d (21 bytes)
0001703d  0fb64708                 movzx eax, byte ptr [rdi + 8]
00017041  884308                   mov byte ptr [rbx + 8], al
00017044  c60300                   mov byte ptr [rbx], 0
00017047  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
0001704c  4883c430                 add rsp, 0x30
00017050  5f                       pop rdi
00017051  c3                       ret

; chunk at RVA 0x17052 (47 bytes)
00017052  440fb6471b               movzx r8d, byte ptr [rdi + 0x1b]
00017057  488d5708                 lea rdx, [rdi + 8]
0001705b  488d4b08                 lea rcx, [rbx + 8]
0001705f  4d85c0                   test r8, r8
00017062  7450                     je 0x170b4
00017064  4885c9                   test rcx, rcx
00017067  741d                     je 0x17086
00017069  4885d2                   test rdx, rdx
0001706c  7413                     je 0x17081
0001706e  e8a0710400               call 0x5e213
00017073  c60300                   mov byte ptr [rbx], 0
00017076  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
0001707b  4883c430                 add rsp, 0x30
0001707f  5f                       pop rdi
00017080  c3                       ret

; chunk at RVA 0x17081 (37 bytes)
00017081  e8a5710400               call 0x5e22b
00017086  ff150cc10400             call qword ptr [rip + 0x4c10c]
0001708c  c70016000000             mov dword ptr [rax], 0x16
00017092  ff1508c10400             call qword ptr [rip + 0x4c108]
00017098  c60300                   mov byte ptr [rbx], 0
0001709b  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
000170a0  4883c430                 add rsp, 0x30
000170a4  5f                       pop rdi
000170a5  c3                       ret

; chunk at RVA 0x170a6 (28 bytes)
000170a6  0f104708                 movups xmm0, xmmword ptr [rdi + 8]
000170aa  0f114308                 movups xmmword ptr [rbx + 8], xmm0
000170ae  8b4718                   mov eax, dword ptr [rdi + 0x18]
000170b1  894318                   mov dword ptr [rbx + 0x18], eax
000170b4  c60300                   mov byte ptr [rbx], 0
000170b7  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
000170bc  4883c430                 add rsp, 0x30
000170c0  5f                       pop rdi
000170c1  c3                       ret

; chunk at RVA 0x170c2 (39 bytes)
000170c2  41b968000000             mov r9d, 0x68
000170c8  48c744242000000000       mov qword ptr [rsp + 0x20], 0
000170d1  4c8d05487c0800           lea r8, [rip + 0x87c48]
000170d8  488d15317b0800           lea rdx, [rip + 0x87b31]
000170df  418d4999                 lea ecx, [r9 - 0x67]
000170e3  e898220000               call 0x19380
000170e8  cc                       int3

; chunk at RVA 0x170e9 (40 bytes)
000170e9  41b9cd040000             mov r9d, 0x4cd
000170ef  48c744242000000000       mov qword ptr [rsp + 0x20], 0
000170f8  4c8d05217c0800           lea r8, [rip + 0x87c21]
000170ff  b901000000               mov ecx, 1
00017104  488d15a5860800           lea rdx, [rip + 0x886a5]
0001710b  e870220000               call 0x19380
00017110  cc                       int3

; chunk at RVA 0x17111 (151 bytes)
00017111  41b968000000             mov r9d, 0x68
00017117  48c744242000000000       mov qword ptr [rsp + 0x20], 0
00017120  4c8d05a17b0800           lea r8, [rip + 0x87ba1]
00017127  488d15e27a0800           lea rdx, [rip + 0x87ae2]
0001712e  418d4999                 lea ecx, [r9 - 0x67]
00017132  e849220000               call 0x19380
00017137  cc                       int3
00017138  187001                   sbb byte ptr [rax + 1], dh
0001713b  005270                   add byte ptr [rdx + 0x70], dl
0001713e  0100                     add dword ptr [rax], eax
00017140  3d700100a6               cmp eax, 0xa6000170
00017145  7001                     jo 0x17148
00017147  00b47001000004           add byte ptr [rax + rsi*2 + 0x4000001], dh
0001714e  0404                     add al, 4
00017150  0101                     add dword ptr [rcx], eax
00017152  0101                     add dword ptr [rcx], eax
00017154  0404                     add al, 4
00017156  0404                     add al, 4
00017158  000404                   add byte ptr [rsp + rax], al
0001715b  0400                     add al, 0
0001715d  0404                     add al, 4
0001715f  0400                     add al, 0
00017161  0400                     add al, 0
00017163  0000                     add byte ptr [rax], al
00017165  0000                     add byte ptr [rax], al
00017167  0404                     add al, 4
00017169  0404                     add al, 4
0001716b  0404                     add al, 4
0001716d  0404                     add al, 4
0001716f  0404                     add al, 4
00017171  0404                     add al, 4
00017173  0404                     add al, 4
00017175  0404                     add al, 4
00017177  0404                     add al, 4
00017179  0404                     add al, 4
0001717b  0404                     add al, 4
0001717d  0404                     add al, 4
0001717f  0404                     add al, 4
00017181  0404                     add al, 4
00017183  0404                     add al, 4
00017185  0404                     add al, 4
00017187  0404                     add al, 4
00017189  0404                     add al, 4
0001718b  0404                     add al, 4
0001718d  0404                     add al, 4
0001718f  0402                     add al, 2
00017191  0403                     add al, 3
00017193  0403                     add al, 3
00017195  0404                     add al, 4
00017197  0404                     add al, 4
00017199  0404                     add al, 4
0001719b  0404                     add al, 4
0001719d  0404                     add al, 4
0001719f  0404                     add al, 4
000171a1  0400                     add al, 0
000171a3  0404                     add al, 4
000171a5  0404                     add al, 4
