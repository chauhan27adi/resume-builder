; `CAEEncryptionProvider::CAEEncryptionProvider'::`1'::dtor$1
; aetm_enclave.dll, primary RVA 0x61230, 28 bytes in 1 chunk(s)

; chunk at RVA 0x61230 (28 bytes)
00061230  4055                     push rbp
00061232  4883ec20                 sub rsp, 0x20
00061236  488bea                   mov rbp, rdx
00061239  488b5578                 mov rdx, qword ptr [rbp + 0x78]
0006123d  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00061241  e89a86fbff               call 0x198e0
00061246  4883c420                 add rsp, 0x20
0006124a  5d                       pop rbp
0006124b  c3                       ret
