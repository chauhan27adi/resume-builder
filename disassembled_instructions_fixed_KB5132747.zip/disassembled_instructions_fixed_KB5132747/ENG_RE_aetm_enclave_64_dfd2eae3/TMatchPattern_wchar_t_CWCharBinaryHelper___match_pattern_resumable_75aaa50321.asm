; TMatchPattern<wchar_t,CWCharBinaryHelper>::match_pattern_resumable
; aetm_enclave.dll, primary RVA 0x328f0, 3268 bytes in 6 chunk(s)

; chunk at RVA 0x328f0 (194 bytes)
000328f0  4053                     push rbx
000328f2  55                       push rbp
000328f3  56                       push rsi
000328f4  4157                     push r15
000328f6  4881ece8000000           sub rsp, 0xe8
000328fd  488b0504870700           mov rax, qword ptr [rip + 0x78704]
00032904  4833c4                   xor rax, rsp
00032907  48898424c8000000         mov qword ptr [rsp + 0xc8], rax
0003290f  4c8b9c2440010000         mov r11, qword ptr [rsp + 0x140]
00032917  4533d2                   xor r10d, r10d
0003291a  488b842450010000         mov rax, qword ptr [rsp + 0x150]
00032922  418bf0                   mov esi, r8d
00032925  488bac2438010000         mov rbp, qword ptr [rsp + 0x138]
0003292d  488bda                   mov rbx, rdx
00032930  4c8bbc2460010000         mov r15, qword ptr [rsp + 0x160]
00032938  4c8bc2                   mov r8, rdx
0003293b  4c898c24b8000000         mov qword ptr [rsp + 0xb8], r9
00032943  4c8b8c2448010000         mov r9, qword ptr [rsp + 0x148]
0003294b  4c898c24a8000000         mov qword ptr [rsp + 0xa8], r9
00032953  4c899c24a0000000         mov qword ptr [rsp + 0xa0], r11
0003295b  48898424b0000000         mov qword ptr [rsp + 0xb0], rax
00032963  4889542460               mov qword ptr [rsp + 0x60], rdx
00032968  4885c9                   test rcx, rcx
0003296b  7440                     je 0x329ad
0003296d  448b4154                 mov r8d, dword ptr [rcx + 0x54]
00032971  4585c0                   test r8d, r8d
00032974  7434                     je 0x329aa
00032976  488b05eb514300           mov rax, qword ptr [rip + 0x4351eb]
0003297d  418bca                   mov ecx, r10d
00032980  480590070000             add rax, 0x790
00032986  488b10                   mov rdx, qword ptr [rax]
00032989  4885d2                   test rdx, rdx
0003298c  7406                     je 0x32994
0003298e  44394210                 cmp dword ptr [rdx + 0x10], r8d
00032992  7411                     je 0x329a5
00032994  ffc1                     inc ecx
00032996  4883c008                 add rax, 8
0003299a  83f911                   cmp ecx, 0x11
0003299d  0f8dbe0b0000             jge 0x33561
000329a3  ebe1                     jmp 0x32986
000329a5  4c8bc3                   mov r8, rbx
000329a8  eb03                     jmp 0x329ad
000329aa  4c8bc2                   mov r8, rdx
000329ad  b901000000               mov ecx, 1

; chunk at RVA 0x329b2 (441 bytes)
000329b2  4889bc2418010000         mov qword ptr [rsp + 0x118], rdi
000329ba  498bfa                   mov rdi, r10
000329bd  4c89a424e0000000         mov qword ptr [rsp + 0xe0], r12
000329c5  4c89ac24d8000000         mov qword ptr [rsp + 0xd8], r13
000329cd  4d8bea                   mov r13, r10
000329d0  4c89b424d0000000         mov qword ptr [rsp + 0xd0], r14
000329d8  4d8bf2                   mov r14, r10
000329db  8d5124                   lea edx, [rcx + 0x24]
000329de  4c89542470               mov qword ptr [rsp + 0x70], r10
000329e3  4c89942490000000         mov qword ptr [rsp + 0x90], r10
000329eb  4c89542448               mov qword ptr [rsp + 0x48], r10
000329f0  4c89942488000000         mov qword ptr [rsp + 0x88], r10
000329f8  4489542440               mov dword ptr [rsp + 0x40], r10d
000329fd  4c89542438               mov qword ptr [rsp + 0x38], r10
00032a02  4c89542468               mov qword ptr [rsp + 0x68], r10
00032a07  4c89942480000000         mov qword ptr [rsp + 0x80], r10
00032a0f  4c89942498000000         mov qword ptr [rsp + 0x98], r10
00032a17  4489542444               mov dword ptr [rsp + 0x44], r10d
00032a1c  40887c2430               mov byte ptr [rsp + 0x30], dil
00032a21  453817                   cmp byte ptr [r15], r10b
00032a24  7410                     je 0x32a36
00032a26  4c8ba42430010000         mov r12, qword ptr [rsp + 0x130]
00032a2e  41883f                   mov byte ptr [r15], dil
00032a31  e942010000               jmp 0x32b78
00032a36  498b4720                 mov rax, qword ptr [r15 + 0x20]
00032a3a  410fb65728               movzx edx, byte ptr [r15 + 0x28]
00032a3f  498b7f58                 mov rdi, qword ptr [r15 + 0x58]
00032a43  458b5770                 mov r10d, dword ptr [r15 + 0x70]
00032a47  418b7718                 mov esi, dword ptr [r15 + 0x18]
00032a4b  4d8b6708                 mov r12, qword ptr [r15 + 8]
00032a4f  4d8b6f60                 mov r13, qword ptr [r15 + 0x60]
00032a53  4889442450               mov qword ptr [rsp + 0x50], rax
00032a58  498b4730                 mov rax, qword ptr [r15 + 0x30]
00032a5c  4889442470               mov qword ptr [rsp + 0x70], rax
00032a61  498b4738                 mov rax, qword ptr [r15 + 0x38]
00032a65  4889842490000000         mov qword ptr [rsp + 0x90], rax
00032a6d  498b4740                 mov rax, qword ptr [r15 + 0x40]
00032a71  4889442448               mov qword ptr [rsp + 0x48], rax
00032a76  418b4748                 mov eax, dword ptr [r15 + 0x48]
00032a7a  89442440                 mov dword ptr [rsp + 0x40], eax
00032a7e  498b4750                 mov rax, qword ptr [r15 + 0x50]
00032a82  4889842480000000         mov qword ptr [rsp + 0x80], rax
00032a8a  498b4768                 mov rax, qword ptr [r15 + 0x68]
00032a8e  4889842498000000         mov qword ptr [rsp + 0x98], rax
00032a96  410fb64774               movzx eax, byte ptr [r15 + 0x74]
00032a9b  88442430                 mov byte ptr [rsp + 0x30], al
00032a9f  498b87c81f0000           mov rax, qword ptr [r15 + 0x1fc8]
00032aa6  89542434                 mov dword ptr [rsp + 0x34], edx
00032aaa  48897c2458               mov qword ptr [rsp + 0x58], rdi
00032aaf  4489542444               mov dword ptr [rsp + 0x44], r10d
00032ab4  4883f8ff                 cmp rax, -1
00032ab8  7505                     jne 0x32abf
00032aba  498bde                   mov rbx, r14
00032abd  eb04                     jmp 0x32ac3
00032abf  488d1c43                 lea rbx, [rbx + rax*2]
00032ac3  498b87d01f0000           mov rax, qword ptr [r15 + 0x1fd0]
00032aca  4883f8ff                 cmp rax, -1
00032ace  750a                     jne 0x32ada
00032ad0  4c89b42488000000         mov qword ptr [rsp + 0x88], r14
00032ad8  eb0c                     jmp 0x32ae6
00032ada  498d0440                 lea rax, [r8 + rax*2]
00032ade  4889842488000000         mov qword ptr [rsp + 0x88], rax
00032ae6  4585d2                   test r10d, r10d
00032ae9  7421                     je 0x32b0c
00032aeb  4d8b87b81f0000           mov r8, qword ptr [r15 + 0x1fb8]
00032af2  418b87c01f0000           mov eax, dword ptr [r15 + 0x1fc0]
00032af9  48d1e8                   shr rax, 1
00032afc  4c89442438               mov qword ptr [rsp + 0x38], r8
00032b01  4d8d1440                 lea r10, [r8 + rax*2]
00032b05  4c89542478               mov qword ptr [rsp + 0x78], r10
00032b0a  eb10                     jmp 0x32b1c
00032b0c  4d8bc6                   mov r8, r14
00032b0f  4c89742438               mov qword ptr [rsp + 0x38], r14
00032b14  4d8bd6                   mov r10, r14
00032b17  4c89742478               mov qword ptr [rsp + 0x78], r14
00032b1c  498b87d81f0000           mov rax, qword ptr [r15 + 0x1fd8]
00032b23  4883f8ff                 cmp rax, -1
00032b27  7507                     jne 0x32b30
00032b29  4c89742468               mov qword ptr [rsp + 0x68], r14
00032b2e  eb09                     jmp 0x32b39
00032b30  498d0440                 lea rax, [r8 + rax*2]
00032b34  4889442468               mov qword ptr [rsp + 0x68], rax
00032b39  498b87e01f0000           mov rax, qword ptr [r15 + 0x1fe0]
00032b40  4883f8ff                 cmp rax, -1
00032b44  7404                     je 0x32b4a
00032b46  4d8d3440                 lea r14, [r8 + rax*2]
00032b4a  418b4714                 mov eax, dword ptr [r15 + 0x14]
00032b4e  ffc8                     dec eax
00032b50  83f805                   cmp eax, 5
00032b53  771b                     ja 0x32b70
00032b55  4c8d05a4d4fcff           lea r8, [rip - 0x32b5c]
00032b5c  4898                     cdqe
00032b5e  418b8c809c350300         mov ecx, dword ptr [r8 + rax*4 + 0x3359c]
00032b66  4903c8                   add rcx, r8
00032b69  ffe1                     jmp rcx

; chunk at RVA 0x32b6b (5 bytes)
00032b6b  b901000000               mov ecx, 1

; chunk at RVA 0x32b70 (2545 bytes)
00032b70  ba25000000               mov edx, 0x25
00032b75  4533d2                   xor r10d, r10d
00032b78  4d8bca                   mov r9, r10
00032b7b  4c89542450               mov qword ptr [rsp + 0x50], r10
00032b80  c644243400               mov byte ptr [rsp + 0x34], 0
00032b85  85f6                     test esi, esi
00032b87  0f8e54080000             jle 0x333e1
00032b8d  4885ed                   test rbp, rbp
00032b90  744c                     je 0x32bde
00032b92  0fb703                   movzx eax, word ptr [rbx]
00032b95  66394500                 cmp word ptr [rbp], ax
00032b99  7543                     jne 0x32bde
00032b9b  4d85e4                   test r12, r12
00032b9e  0f843c090000             je 0x334e0
00032ba4  4883c302                 add rbx, 2
00032ba8  83ee02                   sub esi, 2
00032bab  85f6                     test esi, esi
00032bad  0f8e2d090000             jle 0x334e0
00032bb3  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00032bbb  498bd1                   mov rdx, r9
00032bbe  488d8c24c0000000         lea rcx, [rsp + 0xc0]
00032bc6  41ffd3                   call r11
00032bc9  84c0                     test al, al
00032bcb  0f848d000000             je 0x32c5e
00032bd1  0fb78424c0000000         movzx eax, word ptr [rsp + 0xc0]
00032bd9  663903                   cmp word ptr [rbx], ax
00032bdc  eb52                     jmp 0x32c30
00032bde  0fb703                   movzx eax, word ptr [rbx]
00032be1  663bd0                   cmp dx, ax
00032be4  0f848e000000             je 0x32c78
00032bea  4d85e4                   test r12, r12
00032bed  0f84ed080000             je 0x334e0
00032bf3  ba5b000000               mov edx, 0x5b
00032bf8  663bd0                   cmp dx, ax
00032bfb  0f8480000000             je 0x32c81
00032c01  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00032c09  498bd1                   mov rdx, r9
00032c0c  488d8c24c0000000         lea rcx, [rsp + 0xc0]
00032c14  41ffd3                   call r11
00032c17  84c0                     test al, al
00032c19  7450                     je 0x32c6b
00032c1b  0fb703                   movzx eax, word ptr [rbx]
00032c1e  b95f000000               mov ecx, 0x5f
00032c23  663bc8                   cmp cx, ax
00032c26  740e                     je 0x32c36
00032c28  663b8424c0000000         cmp ax, word ptr [rsp + 0xc0]
00032c30  0f85aa080000             jne 0x334e0
00032c36  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
00032c3e  b901000000               mov ecx, 1
00032c43  4983ec02                 sub r12, 2
00032c47  48894c2450               mov qword ptr [rsp + 0x50], rcx
00032c4c  4883c302                 add rbx, 2
00032c50  448bc9                   mov r9d, ecx
00032c53  83ee02                   sub esi, 2
00032c56  8d5124                   lea edx, [rcx + 0x24]
00032c59  e927ffffff               jmp 0x32b85
00032c5e  41c7471401000000         mov dword ptr [r15 + 0x14], 1
00032c66  e984070000               jmp 0x333ef
00032c6b  41c7471402000000         mov dword ptr [r15 + 0x14], 2
00032c73  e977070000               jmp 0x333ef
00032c78  83fe01                   cmp esi, 1
00032c7b  0f846f080000             je 0x334f0
00032c81  418b87c01f0000           mov eax, dword ptr [r15 + 0x1fc0]
00032c88  4533d2                   xor r10d, r10d
00032c8b  48894c2448               mov qword ptr [rsp + 0x48], rcx
00032c90  4c8bd9                   mov r11, rcx
00032c93  4c89942488000000         mov qword ptr [rsp + 0x88], r10
00032c9b  458bea                   mov r13d, r10d
00032c9e  4c89542458               mov qword ptr [rsp + 0x58], r10
00032ca3  418bfa                   mov edi, r10d
00032ca6  4c89542470               mov qword ptr [rsp + 0x70], r10
00032cab  89742444                 mov dword ptr [rsp + 0x44], esi
00032caf  3bf0                     cmp esi, eax
00032cb1  0f87c5080000             ja 0x3357c
00032cb7  4d8b87b81f0000           mov r8, qword ptr [r15 + 0x1fb8]
00032cbe  8b542434                 mov edx, dword ptr [rsp + 0x34]
00032cc2  4d8bf0                   mov r14, r8
00032cc5  48d1e8                   shr rax, 1
00032cc8  4c89442438               mov qword ptr [rsp + 0x38], r8
00032ccd  4d8d1440                 lea r10, [r8 + rax*2]
00032cd1  4c89542478               mov qword ptr [rsp + 0x78], r10
00032cd6  85f6                     test esi, esi
00032cd8  0f8eaf030000             jle 0x3308d
00032cde  4885ed                   test rbp, rbp
00032ce1  0f84f6000000             je 0x32ddd
00032ce7  0fb703                   movzx eax, word ptr [rbx]
00032cea  66394500                 cmp word ptr [rbp], ax
00032cee  0f85e9000000             jne 0x32ddd
00032cf4  4d85e4                   test r12, r12
00032cf7  0f8448060000             je 0x33345
00032cfd  4883c302                 add rbx, 2
00032d01  83ee02                   sub esi, 2
00032d04  85f6                     test esi, esi
00032d06  0f8ed4070000             jle 0x334e0
00032d0c  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
00032d14  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00032d1c  4c3bef                   cmp r13, rdi
00032d1f  7546                     jne 0x32d67
00032d21  498bd1                   mov rdx, r9
00032d24  498bce                   mov rcx, r14
00032d27  41ffd3                   call r11
00032d2a  84c0                     test al, al
00032d2c  0f84a0050000             je 0x332d2
00032d32  8b542434                 mov edx, dword ptr [rsp + 0x34]
00032d36  4883c702                 add rdi, 2
00032d3a  4c8b542478               mov r10, qword ptr [rsp + 0x78]
00032d3f  48897c2458               mov qword ptr [rsp + 0x58], rdi
00032d44  84d2                     test dl, dl
00032d46  741f                     je 0x32d67
00032d48  4c3b642470               cmp r12, qword ptr [rsp + 0x70]
00032d4d  7718                     ja 0x32d67
00032d4f  b820000000               mov eax, 0x20
00032d54  0fb6d2                   movzx edx, dl
00032d57  66413b06                 cmp ax, word ptr [r14]
00032d5b  b800000000               mov eax, 0
00032d60  0f45d0                   cmovne edx, eax
00032d63  89542434                 mov dword ptr [rsp + 0x34], edx
00032d67  410fb706                 movzx eax, word ptr [r14]
00032d6b  4983c502                 add r13, 2
00032d6f  663903                   cmp word ptr [rbx], ax
00032d72  0f845a020000             je 0x32fd2
00032d78  4c8b5c2448               mov r11, qword ptr [rsp + 0x48]
00032d7d  4c8b8c2488000000         mov r9, qword ptr [rsp + 0x88]
00032d85  4d85c9                   test r9, r9
00032d88  0f84ec050000             je 0x3337a
00032d8e  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
00032d96  49ffc3                   inc r11
00032d99  4c8b442468               mov r8, qword ptr [rsp + 0x68]
00032d9e  4883fb02                 cmp rbx, 2
00032da2  4c8b542478               mov r10, qword ptr [rsp + 0x78]
00032da7  8bc3                     mov eax, ebx
00032da9  b902000000               mov ecx, 2
00032dae  4c895c2448               mov qword ptr [rsp + 0x48], r11
00032db3  0f47c1                   cmova eax, ecx
00032db6  8bc8                     mov ecx, eax
00032db8  482bd9                   sub rbx, rcx
00032dbb  48899c2480000000         mov qword ptr [rsp + 0x80], rbx
00032dc3  4a8d1400                 lea rdx, [rax + r8]
00032dc7  493bd2                   cmp rdx, r10
00032dca  0f8341030000             jae 0x33111
00032dd0  4c8bc2                   mov r8, rdx
00032dd3  4889542468               mov qword ptr [rsp + 0x68], rdx
00032dd8  e944030000               jmp 0x33121
00032ddd  b825000000               mov eax, 0x25
00032de2  663b03                   cmp ax, word ptr [rbx]
00032de5  0f8445020000             je 0x33030
00032deb  4d85e4                   test r12, r12
00032dee  0f8451050000             je 0x33345
00032df4  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
00032dfc  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00032e04  4c3bef                   cmp r13, rdi
00032e07  7545                     jne 0x32e4e
00032e09  498bd1                   mov rdx, r9
00032e0c  498bce                   mov rcx, r14
00032e0f  41ffd3                   call r11
00032e12  84c0                     test al, al
00032e14  0f84c5040000             je 0x332df
00032e1a  8b542434                 mov edx, dword ptr [rsp + 0x34]
00032e1e  4883c702                 add rdi, 2
00032e22  48897c2458               mov qword ptr [rsp + 0x58], rdi
00032e27  84d2                     test dl, dl
00032e29  7423                     je 0x32e4e
00032e2b  4c3b642470               cmp r12, qword ptr [rsp + 0x70]
00032e30  771c                     ja 0x32e4e
00032e32  b920000000               mov ecx, 0x20
00032e37  0fb6d2                   movzx edx, dl
00032e3a  66413b0e                 cmp cx, word ptr [r14]
00032e3e  41b800000000             mov r8d, 0
00032e44  410f45d0                 cmovne edx, r8d
00032e48  89542434                 mov dword ptr [rsp + 0x34], edx
00032e4c  eb03                     jmp 0x32e51
00032e4e  4533c0                   xor r8d, r8d
00032e51  0fb703                   movzx eax, word ptr [rbx]
00032e54  4983c502                 add r13, 2
00032e58  b95f000000               mov ecx, 0x5f
00032e5d  663bc8                   cmp cx, ax
00032e60  0f8467010000             je 0x32fcd
00032e66  b95b000000               mov ecx, 0x5b
00032e6b  663bc8                   cmp cx, ax
00032e6e  0f854f010000             jne 0x32fc3
00032e74  488d5302                 lea rdx, [rbx + 2]
00032e78  b85d000000               mov eax, 0x5d
00032e7d  0f1f00                   nop dword ptr [rax]
00032e80  4883c302                 add rbx, 2
00032e84  83ee02                   sub esi, 2
00032e87  85f6                     test esi, esi
00032e89  0f8e51060000             jle 0x334e0
00032e8f  4885ed                   test rbp, rbp
00032e92  741f                     je 0x32eb3
00032e94  0fb703                   movzx eax, word ptr [rbx]
00032e97  66394500                 cmp word ptr [rbp], ax
00032e9b  7511                     jne 0x32eae
00032e9d  4883c302                 add rbx, 2
00032ea1  83ee02                   sub esi, 2
00032ea4  85f6                     test esi, esi
00032ea6  0f8e34060000             jle 0x334e0
00032eac  ebca                     jmp 0x32e78
00032eae  b85d000000               mov eax, 0x5d
00032eb3  663b03                   cmp ax, word ptr [rbx]
00032eb6  75c8                     jne 0x32e80
00032eb8  488bcb                   mov rcx, rbx
00032ebb  4032ff                   xor dil, dil
00032ebe  482bca                   sub rcx, rdx
00032ec1  48d1f9                   sar rcx, 1
00032ec4  03c9                     add ecx, ecx
00032ec6  85c9                     test ecx, ecx
00032ec8  0f8ee1000000             jle 0x32faf
00032ece  b85e000000               mov eax, 0x5e
00032ed3  663b02                   cmp ax, word ptr [rdx]
00032ed6  751f                     jne 0x32ef7
00032ed8  4885ed                   test rbp, rbp
00032edb  7406                     je 0x32ee3
00032edd  66394500                 cmp word ptr [rbp], ax
00032ee1  7414                     je 0x32ef7
00032ee3  8d41fe                   lea eax, [rcx - 2]
00032ee6  4883c202                 add rdx, 2
00032eea  8bc8                     mov ecx, eax
00032eec  40b701                   mov dil, 1
00032eef  85c0                     test eax, eax
00032ef1  0f8eb8000000             jle 0x32faf
00032ef7  450fb71e                 movzx r11d, word ptr [r14]
00032efb  0f1f440000               nop dword ptr [rax + rax]
00032f00  4885ed                   test rbp, rbp
00032f03  740d                     je 0x32f12
00032f05  0fb702                   movzx eax, word ptr [rdx]
00032f08  66394500                 cmp word ptr [rbp], ax
00032f0c  7504                     jne 0x32f12
00032f0e  b001                     mov al, 1
00032f10  eb02                     jmp 0x32f14
00032f12  32c0                     xor al, al
00032f14  84c0                     test al, al
00032f16  4c8d5202                 lea r10, [rdx + 2]
00032f1a  448d49fe                 lea r9d, [rcx - 2]
00032f1e  4c0f44d2                 cmove r10, rdx
00032f22  440f44c9                 cmove r9d, ecx
00032f26  66453b1a                 cmp r11w, word ptr [r10]
00032f2a  7411                     je 0x32f3d
00032f2c  48c7c0ffffffff           mov rax, 0xffffffffffffffff
00032f33  41b801000000             mov r8d, 1
00032f39  440f42c0                 cmovb r8d, eax
00032f3d  418d49fe                 lea ecx, [r9 - 2]
00032f41  498d5202                 lea rdx, [r10 + 2]
00032f45  83f901                   cmp ecx, 1
00032f48  7e50                     jle 0x32f9a
00032f4a  b82d000000               mov eax, 0x2d
00032f4f  663b02                   cmp ax, word ptr [rdx]
00032f52  7546                     jne 0x32f9a
00032f54  4885ed                   test rbp, rbp
00032f57  7406                     je 0x32f5f
00032f59  66394500                 cmp word ptr [rbp], ax
00032f5d  743b                     je 0x32f9a
00032f5f  448d49fe                 lea r9d, [rcx - 2]
00032f63  4885ed                   test rbp, rbp
00032f66  740e                     je 0x32f76
00032f68  0fb74202                 movzx eax, word ptr [rdx + 2]
00032f6c  66394500                 cmp word ptr [rbp], ax
00032f70  7504                     jne 0x32f76
00032f72  b001                     mov al, 1
00032f74  eb02                     jmp 0x32f78
00032f76  32c0                     xor al, al
00032f78  84c0                     test al, al
00032f7a  490f44d2                 cmove rdx, r10
00032f7e  440f44c9                 cmove r9d, ecx
00032f82  4585c0                   test r8d, r8d
00032f85  7809                     js 0x32f90
00032f87  66443b5a04               cmp r11w, word ptr [rdx + 4]
00032f8c  741d                     je 0x32fab
00032f8e  721b                     jb 0x32fab
00032f90  4883c206                 add rdx, 6
00032f94  418d49fc                 lea ecx, [r9 - 4]
00032f98  eb05                     jmp 0x32f9f
00032f9a  4585c0                   test r8d, r8d
00032f9d  740c                     je 0x32fab
00032f9f  85c9                     test ecx, ecx
00032fa1  7e0c                     jle 0x32faf
00032fa3  4533c0                   xor r8d, r8d
00032fa6  e955ffffff               jmp 0x32f00
00032fab  4080f701                 xor dil, 1
00032faf  8b542434                 mov edx, dword ptr [rsp + 0x34]
00032fb3  4084ff                   test dil, dil
00032fb6  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
00032fbb  0f84b7fdffff             je 0x32d78
00032fc1  eb0a                     jmp 0x32fcd
00032fc3  66413b06                 cmp ax, word ptr [r14]
00032fc7  0f85abfdffff             jne 0x32d78
00032fcd  4c8b542478               mov r10, qword ptr [rsp + 0x78]
00032fd2  4c8b4c2450               mov r9, qword ptr [rsp + 0x50]
00032fd7  4c8b5c2448               mov r11, qword ptr [rsp + 0x48]
00032fdc  4d85c9                   test r9, r9
00032fdf  4c8b442438               mov r8, qword ptr [rsp + 0x38]
00032fe4  498bc3                   mov rax, r11
00032fe7  490f45c1                 cmovne rax, r9
00032feb  4c8bc8                   mov r9, rax
00032fee  4889442450               mov qword ptr [rsp + 0x50], rax
00032ff3  498d4602                 lea rax, [r14 + 2]
00032ff7  493bc2                   cmp rax, r10
00032ffa  7313                     jae 0x3300f
00032ffc  4983ec02                 sub r12, 2
00033000  4883c302                 add rbx, 2
00033004  83ee02                   sub esi, 2
00033007  4c8bf0                   mov r14, rax
0003300a  e9c7fcffff               jmp 0x32cd6
0003300f  452bf2                   sub r14d, r10d
00033012  4983ec02                 sub r12, 2
00033016  4183c602                 add r14d, 2
0003301a  4883c302                 add rbx, 2
0003301e  4d03f0                   add r14, r8
00033021  83ee02                   sub esi, 2
00033024  e9adfcffff               jmp 0x32cd6
00033029  0f1f8000000000           nop dword ptr [rax]
00033030  4883c302                 add rbx, 2
00033034  83ee02                   sub esi, 2
00033037  0f84b7040000             je 0x334f4
0003303d  0fb70b                   movzx ecx, word ptr [rbx]
00033040  663bc1                   cmp ax, cx
00033043  74eb                     je 0x33030
00033045  33c0                     xor eax, eax
00033047  48899c2488000000         mov qword ptr [rsp + 0x88], rbx
0003304f  8bf8                     mov edi, eax
00033051  4889442458               mov qword ptr [rsp + 0x58], rax
00033056  8d41a5                   lea eax, [rcx - 0x5b]
00033059  89742440                 mov dword ptr [rsp + 0x40], esi
0003305d  41bdfbff0000             mov r13d, 0xfffb
00033063  4d8bf0                   mov r14, r8
00033066  664185c5                 test r13w, ax
0003306a  7416                     je 0x33082
0003306c  4885ed                   test rbp, rbp
0003306f  7406                     je 0x33077
00033071  66394d00                 cmp word ptr [rbp], cx
00033075  740b                     je 0x33082
00033077  b001                     mov al, 1
00033079  88442430                 mov byte ptr [rsp + 0x30], al
0003307d  e9d2000000               jmp 0x33154
00033082  32c0                     xor al, al
00033084  88442430                 mov byte ptr [rsp + 0x30], al
00033088  e9c7000000               jmp 0x33154
0003308d  4d85e4                   test r12, r12
00033090  0f845e040000             je 0x334f4
00033096  80bc245801000000         cmp byte ptr [rsp + 0x158], 0
0003309e  0f84d9fcffff             je 0x32d7d
000330a4  84d2                     test dl, dl
000330a6  0f85d1fcffff             jne 0x32d7d
000330ac  4883bc24a000000000       cmp qword ptr [rsp + 0xa0], 0
000330b5  7542                     jne 0x330f9
000330b7  4c8b8424b8000000         mov r8, qword ptr [rsp + 0xb8]
000330bf  41ba20000000             mov r10d, 0x20
000330c5  498bc0                   mov rax, r8
000330c8  498bcc                   mov rcx, r12
000330cb  66453b10                 cmp r10w, word ptr [r8]
000330cf  0f85a8fcffff             jne 0x32d7d
000330d5  6666660f1f840000000000   nop word ptr [rax + rax]
000330e0  488d4002                 lea rax, [rax + 2]
000330e4  4883e902                 sub rcx, 2
000330e8  0f8406040000             je 0x334f4
000330ee  66443b10                 cmp r10w, word ptr [rax]
000330f2  74ec                     je 0x330e0
000330f4  e984fcffff               jmp 0x32d7d
000330f9  b201                     mov dl, 1
000330fb  4c89642470               mov qword ptr [rsp + 0x70], r12
00033100  89542434                 mov dword ptr [rsp + 0x34], edx
00033104  4c898c2490000000         mov qword ptr [rsp + 0x90], r9
0003310c  e96cfcffff               jmp 0x32d7d
00033111  452bc2                   sub r8d, r10d
00033114  4403c0                   add r8d, eax
00033117  4c03442438               add r8, qword ptr [rsp + 0x38]
0003311c  4c89442468               mov qword ptr [rsp + 0x68], r8
00033121  488b842498000000         mov rax, qword ptr [rsp + 0x98]
00033129  4c8be3                   mov r12, rbx
0003312c  8b742440                 mov esi, dword ptr [rsp + 0x40]
00033130  498bd9                   mov rbx, r9
00033133  8b542434                 mov edx, dword ptr [rsp + 0x34]
00033137  482bf9                   sub rdi, rcx
0003313a  4c8bc8                   mov r9, rax
0003313d  4889442450               mov qword ptr [rsp + 0x50], rax
00033142  0fb6442430               movzx eax, byte ptr [rsp + 0x30]
00033147  4d8bf0                   mov r14, r8
0003314a  4c8b442438               mov r8, qword ptr [rsp + 0x38]
0003314f  48897c2458               mov qword ptr [rsp + 0x58], rdi
00033154  4d85e4                   test r12, r12
00033157  0f84e8010000             je 0x33345
0003315d  33c9                     xor ecx, ecx
0003315f  4c898c2498000000         mov qword ptr [rsp + 0x98], r9
00033167  448be9                   mov r13d, ecx
0003316a  84c0                     test al, al
0003316c  7512                     jne 0x33180
0003316e  4c89742468               mov qword ptr [rsp + 0x68], r14
00033173  4c89a42480000000         mov qword ptr [rsp + 0x80], r12
0003317b  e956fbffff               jmp 0x32cd6
00033180  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
00033185  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
0003318d  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00033195  eb03                     jmp 0x3319a
00033197  488bcf                   mov rcx, rdi
0003319a  498bfd                   mov rdi, r13
0003319d  4c3be9                   cmp r13, rcx
000331a0  7549                     jne 0x331eb
000331a2  498bd1                   mov rdx, r9
000331a5  498bce                   mov rcx, r14
000331a8  41ffd3                   call r11
000331ab  84c0                     test al, al
000331ad  0f8439010000             je 0x332ec
000331b3  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
000331b8  8b542434                 mov edx, dword ptr [rsp + 0x34]
000331bc  4883c102                 add rcx, 2
000331c0  48894c2458               mov qword ptr [rsp + 0x58], rcx
000331c5  84d2                     test dl, dl
000331c7  7422                     je 0x331eb
000331c9  4c3b642470               cmp r12, qword ptr [rsp + 0x70]
000331ce  771b                     ja 0x331eb
000331d0  0fb6c2                   movzx eax, dl
000331d3  ba20000000               mov edx, 0x20
000331d8  66413b16                 cmp dx, word ptr [r14]
000331dc  ba00000000               mov edx, 0
000331e1  0f45c2                   cmovne eax, edx
000331e4  0fb6d0                   movzx edx, al
000331e7  89542434                 mov dword ptr [rsp + 0x34], edx
000331eb  410fb706                 movzx eax, word ptr [r14]
000331ef  4983c502                 add r13, 2
000331f3  663903                   cmp word ptr [rbx], ax
000331f6  7462                     je 0x3325a
000331f8  4983ec02                 sub r12, 2
000331fc  0f8443010000             je 0x33345
00033202  48ff442448               inc qword ptr [rsp + 0x48]
00033207  498d4602                 lea rax, [r14 + 2]
0003320b  4c8b542478               mov r10, qword ptr [rsp + 0x78]
00033210  4883e902                 sub rcx, 2
00033214  48894c2458               mov qword ptr [rsp + 0x58], rcx
00033219  4c8bef                   mov r13, rdi
0003321c  493bc2                   cmp rax, r10
0003321f  7318                     jae 0x33239
00033221  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
00033229  4c8bf0                   mov r14, rax
0003322c  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00033234  e961ffffff               jmp 0x3319a
00033239  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
00033241  452bf2                   sub r14d, r10d
00033244  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
0003324c  4183c602                 add r14d, 2
00033250  4c03742438               add r14, qword ptr [rsp + 0x38]
00033255  e940ffffff               jmp 0x3319a
0003325a  4c8b4c2450               mov r9, qword ptr [rsp + 0x50]
0003325f  4d8bc6                   mov r8, r14
00033262  4c8b5c2448               mov r11, qword ptr [rsp + 0x48]
00033267  4d85c9                   test r9, r9
0003326a  4c8b542478               mov r10, qword ptr [rsp + 0x78]
0003326f  4d0f44cb                 cmove r9, r11
00033273  4c89742468               mov qword ptr [rsp + 0x68], r14
00033278  4983c602                 add r14, 2
0003327c  4c89a42480000000         mov qword ptr [rsp + 0x80], r12
00033284  4c894c2450               mov qword ptr [rsp + 0x50], r9
00033289  4d3bf2                   cmp r14, r10
0003328c  731a                     jae 0x332a8
0003328e  4c8b442438               mov r8, qword ptr [rsp + 0x38]
00033293  4983ec02                 sub r12, 2
00033297  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
0003329c  4883c302                 add rbx, 2
000332a0  83ee02                   sub esi, 2
000332a3  e92efaffff               jmp 0x32cd6
000332a8  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
000332ad  4d8bf0                   mov r14, r8
000332b0  4c8b442438               mov r8, qword ptr [rsp + 0x38]
000332b5  4d2bf2                   sub r14, r10
000332b8  4983c602                 add r14, 2
000332bc  4983ec02                 sub r12, 2
000332c0  458bf6                   mov r14d, r14d
000332c3  4883c302                 add rbx, 2
000332c7  4d03f0                   add r14, r8
000332ca  83ee02                   sub esi, 2
000332cd  e904faffff               jmp 0x32cd6
000332d2  41c7471403000000         mov dword ptr [r15 + 0x14], 3
000332da  e910010000               jmp 0x333ef
000332df  41c7471404000000         mov dword ptr [r15 + 0x14], 4
000332e7  e903010000               jmp 0x333ef
000332ec  488b442450               mov rax, qword ptr [rsp + 0x50]
000332f1  49894720                 mov qword ptr [r15 + 0x20], rax
000332f5  8b442434                 mov eax, dword ptr [rsp + 0x34]
000332f9  41884728                 mov byte ptr [r15 + 0x28], al
000332fd  488b442470               mov rax, qword ptr [rsp + 0x70]
00033302  49894730                 mov qword ptr [r15 + 0x30], rax
00033306  488b842490000000         mov rax, qword ptr [rsp + 0x90]
0003330e  49894738                 mov qword ptr [r15 + 0x38], rax
00033312  488b442448               mov rax, qword ptr [rsp + 0x48]
00033317  49894740                 mov qword ptr [r15 + 0x40], rax
0003331b  8b442440                 mov eax, dword ptr [rsp + 0x40]
0003331f  41894748                 mov dword ptr [r15 + 0x48], eax
00033323  488b842480000000         mov rax, qword ptr [rsp + 0x80]
0003332b  49894750                 mov qword ptr [r15 + 0x50], rax
0003332f  488b442458               mov rax, qword ptr [rsp + 0x58]
00033334  49894758                 mov qword ptr [r15 + 0x58], rax
00033338  41c7471405000000         mov dword ptr [r15 + 0x14], 5
00033340  e9f1000000               jmp 0x33436
00033345  84d2                     test dl, dl
00033347  0f8493010000             je 0x334e0
0003334d  488b9424b0000000         mov rdx, qword ptr [rsp + 0xb0]
00033355  4885d2                   test rdx, rdx
00033358  0f84bd010000             je 0x3351b
0003335e  488b842490000000         mov rax, qword ptr [rsp + 0x90]
00033366  b901000000               mov ecx, 1
0003336b  4885c0                   test rax, rax
0003336e  480f45c8                 cmovne rcx, rax
00033372  48890a                   mov qword ptr [rdx], rcx
00033375  e9a1010000               jmp 0x3351b
0003337a  84d2                     test dl, dl
0003337c  0f845e010000             je 0x334e0
00033382  4c8b4c2450               mov r9, qword ptr [rsp + 0x50]
00033387  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
0003338f  80bc245801000000         cmp byte ptr [rsp + 0x158], 0
00033397  0f843e010000             je 0x334db
0003339d  4d85e4                   test r12, r12
000333a0  0f8445010000             je 0x334eb
000333a6  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
000333ae  498bd1                   mov rdx, r9
000333b1  488d8c24c0000000         lea rcx, [rsp + 0xc0]
000333b9  41ffd3                   call r11
000333bc  84c0                     test al, al
000333be  7427                     je 0x333e7
000333c0  b820000000               mov eax, 0x20
000333c5  663b8424c0000000         cmp ax, word ptr [rsp + 0xc0]
000333cd  0f850d010000             jne 0x334e0
000333d3  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
000333db  4983ec02                 sub r12, 2
000333df  ebbc                     jmp 0x3339d
000333e1  8b542434                 mov edx, dword ptr [rsp + 0x34]
000333e5  eba8                     jmp 0x3338f
000333e7  41c7471406000000         mov dword ptr [r15 + 0x14], 6
000333ef  488b442450               mov rax, qword ptr [rsp + 0x50]
000333f4  49894720                 mov qword ptr [r15 + 0x20], rax
000333f8  8b442434                 mov eax, dword ptr [rsp + 0x34]
000333fc  41884728                 mov byte ptr [r15 + 0x28], al
00033400  488b442470               mov rax, qword ptr [rsp + 0x70]
00033405  49894730                 mov qword ptr [r15 + 0x30], rax
00033409  488b842490000000         mov rax, qword ptr [rsp + 0x90]
00033411  49894738                 mov qword ptr [r15 + 0x38], rax
00033415  488b442448               mov rax, qword ptr [rsp + 0x48]
0003341a  49894740                 mov qword ptr [r15 + 0x40], rax
0003341e  8b442440                 mov eax, dword ptr [rsp + 0x40]
00033422  41894748                 mov dword ptr [r15 + 0x48], eax
00033426  488b842480000000         mov rax, qword ptr [rsp + 0x80]
0003342e  49894750                 mov qword ptr [r15 + 0x50], rax
00033432  49897f58                 mov qword ptr [r15 + 0x58], rdi
00033436  488b842498000000         mov rax, qword ptr [rsp + 0x98]
0003343e  488b542460               mov rdx, qword ptr [rsp + 0x60]
00033443  49894768                 mov qword ptr [r15 + 0x68], rax
00033447  8b442444                 mov eax, dword ptr [rsp + 0x44]
0003344b  41894770                 mov dword ptr [r15 + 0x70], eax
0003344f  0fb6442430               movzx eax, byte ptr [rsp + 0x30]
00033454  41884774                 mov byte ptr [r15 + 0x74], al
00033458  48c7c0ffffffff           mov rax, 0xffffffffffffffff
0003345f  4d896708                 mov qword ptr [r15 + 8], r12
00033463  41897718                 mov dword ptr [r15 + 0x18], esi
00033467  4d896f60                 mov qword ptr [r15 + 0x60], r13
0003346b  4885db                   test rbx, rbx
0003346e  7505                     jne 0x33475
00033470  488bd8                   mov rbx, rax
00033473  eb06                     jmp 0x3347b
00033475  482bda                   sub rbx, rdx
00033478  48d1fb                   sar rbx, 1
0003347b  488b8c2488000000         mov rcx, qword ptr [rsp + 0x88]
00033483  49899fc81f0000           mov qword ptr [r15 + 0x1fc8], rbx
0003348a  4885c9                   test rcx, rcx
0003348d  7505                     jne 0x33494
0003348f  488bc8                   mov rcx, rax
00033492  eb06                     jmp 0x3349a
00033494  482bca                   sub rcx, rdx
00033497  48d1f9                   sar rcx, 1
0003349a  488b542438               mov rdx, qword ptr [rsp + 0x38]
0003349f  49898fd01f0000           mov qword ptr [r15 + 0x1fd0], rcx
000334a6  488b4c2468               mov rcx, qword ptr [rsp + 0x68]
000334ab  4885c9                   test rcx, rcx
000334ae  7505                     jne 0x334b5
000334b0  488bc8                   mov rcx, rax
000334b3  eb06                     jmp 0x334bb
000334b5  482bca                   sub rcx, rdx
000334b8  48d1f9                   sar rcx, 1
000334bb  49898fd81f0000           mov qword ptr [r15 + 0x1fd8], rcx
000334c2  4d85f6                   test r14, r14
000334c5  7409                     je 0x334d0
000334c7  498bc6                   mov rax, r14
000334ca  482bc2                   sub rax, rdx
000334cd  48d1f8                   sar rax, 1
000334d0  498987e01f0000           mov qword ptr [r15 + 0x1fe0], rax
000334d7  32c0                     xor al, al
000334d9  eb49                     jmp 0x33524
000334db  4d85e4                   test r12, r12
000334de  7414                     je 0x334f4
000334e0  6641c747100100           mov word ptr [r15 + 0x10], 1
000334e7  32c0                     xor al, al
000334e9  eb39                     jmp 0x33524
000334eb  4c8b4c2450               mov r9, qword ptr [rsp + 0x50]
000334f0  8b542434                 mov edx, dword ptr [rsp + 0x34]
000334f4  488b8c24b0000000         mov rcx, qword ptr [rsp + 0xb0]
000334fc  4885c9                   test rcx, rcx
000334ff  741a                     je 0x3351b
00033501  84d2                     test dl, dl
00033503  b801000000               mov eax, 1
00033508  4c0f458c2490000000       cmovne r9, qword ptr [rsp + 0x90]
00033511  4d85c9                   test r9, r9
00033514  4c0f44c8                 cmove r9, rax
00033518  4c8909                   mov qword ptr [rcx], r9
0003351b  b001                     mov al, 1
0003351d  6641c747100101           mov word ptr [r15 + 0x10], 0x101
00033524  4c8bac24d8000000         mov r13, qword ptr [rsp + 0xd8]
0003352c  4c8ba424e0000000         mov r12, qword ptr [rsp + 0xe0]
00033534  488bbc2418010000         mov rdi, qword ptr [rsp + 0x118]
0003353c  4c8bb424d0000000         mov r14, qword ptr [rsp + 0xd0]
00033544  488b8c24c8000000         mov rcx, qword ptr [rsp + 0xc8]
0003354c  4833cc                   xor rcx, rsp
0003354f  e87c980200               call 0x5cdd0
00033554  4881c4e8000000           add rsp, 0xe8
0003355b  415f                     pop r15
0003355d  5e                       pop rsi
0003355e  5d                       pop rbp
0003355f  5b                       pop rbx
00033560  c3                       ret

; chunk at RVA 0x33561 (27 bytes)
00033561  ba4b000000               mov edx, 0x4b
00033566  4489442420               mov dword ptr [rsp + 0x20], r8d
0003356b  8d4ad0                   lea ecx, [rdx - 0x30]
0003356e  448d4ab6                 lea r9d, [rdx - 0x4a]
00033572  448d42c5                 lea r8d, [rdx - 0x3b]
00033576  e8255efeff               call 0x193a0
0003357b  cc                       int3

; chunk at RVA 0x3357c (56 bytes)
0003357c  41b9d8040000             mov r9d, 0x4d8
00033582  4c89542420               mov qword ptr [rsp + 0x20], r10
00033587  4c8d0542b80600           lea r8, [rip + 0x6b842]
0003358e  488d1593c40600           lea rdx, [rip + 0x6c493]
00033595  e8e65dfeff               call 0x19380
0003359a  cc                       int3
0003359b  90                       nop
0003359c  bb2b030009               mov ebx, 0x900032b
000335a1  2c03                     sub al, 3
000335a3  001c2d0300042e           add byte ptr [rbp + 0x2e040003], bl
000335aa  0300                     add eax, dword ptr [rax]
000335ac  97                       xchg edi, eax
000335ad  3103                     xor dword ptr [rbx], eax
