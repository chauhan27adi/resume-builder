; CEsCompValSeg::~CEsCompValSeg
; aetm_enclave.dll, primary RVA 0x2c240, 124 bytes in 5 chunk(s)

; chunk at RVA 0x2c240 (4 bytes)
0002c240  4883ec28                 sub rsp, 0x28

; chunk at RVA 0x2c244 (16 bytes)
0002c244  48895c2430               mov qword ptr [rsp + 0x30], rbx
0002c249  488bd9                   mov rbx, rcx
0002c24c  488b09                   mov rcx, qword ptr [rcx]
0002c24f  4885c9                   test rcx, rcx
0002c252  7434                     je 0x2c288

; chunk at RVA 0x2c254 (52 bytes)
0002c254  48897c2420               mov qword ptr [rsp + 0x20], rdi
0002c259  33ff                     xor edi, edi
0002c25b  397b08                   cmp dword ptr [rbx + 8], edi
0002c25e  7617                     jbe 0x2c277
0002c260  488b03                   mov rax, qword ptr [rbx]
0002c263  488b0cf8                 mov rcx, qword ptr [rax + rdi*8]
0002c267  488b01                   mov rax, qword ptr [rcx]
0002c26a  ff5048                   call qword ptr [rax + 0x48]
0002c26d  ffc7                     inc edi
0002c26f  3b7b08                   cmp edi, dword ptr [rbx + 8]
0002c272  72ec                     jb 0x2c260
0002c274  488b0b                   mov rcx, qword ptr [rbx]
0002c277  e8c00b0300               call 0x5ce3c
0002c27c  488b7c2420               mov rdi, qword ptr [rsp + 0x20]
0002c281  48c70300000000           mov qword ptr [rbx], 0

; chunk at RVA 0x2c288 (33 bytes)
0002c288  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
0002c28c  4885c9                   test rcx, rcx
0002c28f  740a                     je 0x2c29b
0002c291  ba01000000               mov edx, 1
0002c296  e8b50c0300               call 0x5cf50
0002c29b  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0002c29f  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0002c2a4  4885c9                   test rcx, rcx
0002c2a7  740e                     je 0x2c2b7

; chunk at RVA 0x2c2a9 (19 bytes)
0002c2a9  ba01000000               mov edx, 1
0002c2ae  4883c428                 add rsp, 0x28
0002c2b2  e9990c0300               jmp 0x5cf50
0002c2b7  4883c428                 add rsp, 0x28
0002c2bb  c3                       ret
