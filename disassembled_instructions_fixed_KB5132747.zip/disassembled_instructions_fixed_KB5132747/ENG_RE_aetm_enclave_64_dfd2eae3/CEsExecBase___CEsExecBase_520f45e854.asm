; CEsExecBase::~CEsExecBase
; aetm_enclave.dll, primary RVA 0x2e200, 372 bytes in 5 chunk(s)

; chunk at RVA 0x2e200 (49 bytes)
0002e200  48895c2418               mov qword ptr [rsp + 0x18], rbx
0002e205  48897c2420               mov qword ptr [rsp + 0x20], rdi
0002e20a  4156                     push r14
0002e20c  4883ec20                 sub rsp, 0x20
0002e210  488d0521690300           lea rax, [rip + 0x36921]
0002e217  4533f6                   xor r14d, r14d
0002e21a  488901                   mov qword ptr [rcx], rax
0002e21d  488bd9                   mov rbx, rcx
0002e220  488b4110                 mov rax, qword ptr [rcx + 0x10]
0002e224  4885c0                   test rax, rax
0002e227  0f84ea000000             je 0x2e317
0002e22d  488b4938                 mov rcx, qword ptr [rcx + 0x38]

; chunk at RVA 0x2e231 (103 bytes)
0002e231  48896c2430               mov qword ptr [rsp + 0x30], rbp
0002e236  4885c9                   test rcx, rcx
0002e239  7436                     je 0x2e271
0002e23b  418bfe                   mov edi, r14d
0002e23e  66443b7014               cmp r14w, word ptr [rax + 0x14]
0002e243  732c                     jae 0x2e271
0002e245  6666660f1f840000000000   nop word ptr [rax + rax]
0002e250  488b4b38                 mov rcx, qword ptr [rbx + 0x38]
0002e254  8bc7                     mov eax, edi
0002e256  488b0cc1                 mov rcx, qword ptr [rcx + rax*8]
0002e25a  e8ddeb0200               call 0x5ce3c
0002e25f  488b4310                 mov rax, qword ptr [rbx + 0x10]
0002e263  ffc7                     inc edi
0002e265  0fb74814                 movzx ecx, word ptr [rax + 0x14]
0002e269  3bf9                     cmp edi, ecx
0002e26b  72e3                     jb 0x2e250
0002e26d  488b4b38                 mov rcx, qword ptr [rbx + 0x38]
0002e271  e8c6eb0200               call 0x5ce3c
0002e276  488b4b30                 mov rcx, qword ptr [rbx + 0x30]
0002e27a  488b6b28                 mov rbp, qword ptr [rbx + 0x28]
0002e27e  488b7b10                 mov rdi, qword ptr [rbx + 0x10]
0002e282  4885c9                   test rcx, rcx
0002e285  7405                     je 0x2e28c
0002e287  e8b0eb0200               call 0x5ce3c
0002e28c  4885ed                   test rbp, rbp
0002e28f  7436                     je 0x2e2c7
0002e291  8b4730                   mov eax, dword ptr [rdi + 0x30]
0002e294  85c0                     test eax, eax
0002e296  7427                     je 0x2e2bf

; chunk at RVA 0x2e298 (39 bytes)
0002e298  4889742438               mov qword ptr [rsp + 0x38], rsi
0002e29d  488bfd                   mov rdi, rbp
0002e2a0  8bf0                     mov esi, eax
0002e2a2  488b0f                   mov rcx, qword ptr [rdi]
0002e2a5  4885c9                   test rcx, rcx
0002e2a8  7406                     je 0x2e2b0
0002e2aa  488b01                   mov rax, qword ptr [rcx]
0002e2ad  ff5070                   call qword ptr [rax + 0x70]
0002e2b0  4883c708                 add rdi, 8
0002e2b4  4883ee01                 sub rsi, 1
0002e2b8  75e8                     jne 0x2e2a2
0002e2ba  488b742438               mov rsi, qword ptr [rsp + 0x38]

; chunk at RVA 0x2e2bf (22 bytes)
0002e2bf  488bcd                   mov rcx, rbp
0002e2c2  e875eb0200               call 0x5ce3c
0002e2c7  488b4b40                 mov rcx, qword ptr [rbx + 0x40]
0002e2cb  488b6c2430               mov rbp, qword ptr [rsp + 0x30]
0002e2d0  4885c9                   test rcx, rcx
0002e2d3  7442                     je 0x2e317

; chunk at RVA 0x2e2d5 (159 bytes)
0002e2d5  488b4310                 mov rax, qword ptr [rbx + 0x10]
0002e2d9  418bfe                   mov edi, r14d
0002e2dc  44397078                 cmp dword ptr [rax + 0x78], r14d
0002e2e0  7630                     jbe 0x2e312
0002e2e2  488bd1                   mov rdx, rcx
0002e2e5  8bc7                     mov eax, edi
0002e2e7  4c8b04c1                 mov r8, qword ptr [rcx + rax*8]
0002e2eb  4d85c0                   test r8, r8
0002e2ee  7414                     je 0x2e304
0002e2f0  498b00                   mov rax, qword ptr [r8]
0002e2f3  ba01000000               mov edx, 1
0002e2f8  498bc8                   mov rcx, r8
0002e2fb  ff10                     call qword ptr [rax]
0002e2fd  488b4b40                 mov rcx, qword ptr [rbx + 0x40]
0002e301  488bd1                   mov rdx, rcx
0002e304  488b4310                 mov rax, qword ptr [rbx + 0x10]
0002e308  ffc7                     inc edi
0002e30a  3b7878                   cmp edi, dword ptr [rax + 0x78]
0002e30d  72d6                     jb 0x2e2e5
0002e30f  488bca                   mov rcx, rdx
0002e312  e825eb0200               call 0x5ce3c
0002e317  488b4b58                 mov rcx, qword ptr [rbx + 0x58]
0002e31b  4885c9                   test rcx, rcx
0002e31e  7443                     je 0x2e363
0002e320  418bfe                   mov edi, r14d
0002e323  66443b7360               cmp r14w, word ptr [rbx + 0x60]
0002e328  732b                     jae 0x2e355
0002e32a  660f1f440000             nop word ptr [rax + rax]
0002e330  488b4b58                 mov rcx, qword ptr [rbx + 0x58]
0002e334  8bc7                     mov eax, edi
0002e336  488b14c1                 mov rdx, qword ptr [rcx + rax*8]
0002e33a  4885d2                   test rdx, rdx
0002e33d  740c                     je 0x2e34b
0002e33f  488bca                   mov rcx, rdx
0002e342  e8f5ea0200               call 0x5ce3c
0002e347  488b4b58                 mov rcx, qword ptr [rbx + 0x58]
0002e34b  0fb74360                 movzx eax, word ptr [rbx + 0x60]
0002e34f  ffc7                     inc edi
0002e351  3bf8                     cmp edi, eax
0002e353  72db                     jb 0x2e330
0002e355  e8e2ea0200               call 0x5ce3c
0002e35a  4c897358                 mov qword ptr [rbx + 0x58], r14
0002e35e  6644897360               mov word ptr [rbx + 0x60], r14w
0002e363  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
0002e368  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
0002e36d  4883c420                 add rsp, 0x20
0002e371  415e                     pop r14
0002e373  c3                       ret
