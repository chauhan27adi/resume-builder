; CQDSXEDataExhaustWriter::PersistPlan
; qds.dll, primary RVA 0xb5a30, 920 bytes in 5 chunk(s)

; chunk at RVA 0xb5a30 (44 bytes)
000b5a30  488bc4                   mov rax, rsp
000b5a33  55                       push rbp
000b5a34  57                       push rdi
000b5a35  488da898fdffff           lea rbp, [rax - 0x268]
000b5a3c  4881ec58030000           sub rsp, 0x358
000b5a43  f6056e2f0e0001           test byte ptr [rip + 0xe2f6e], 1
000b5a4a  488bfa                   mov rdi, rdx
000b5a4d  0f846b030000             je 0xb5dbe
000b5a53  488b0da6f50b00           mov rcx, qword ptr [rip + 0xbf5a6]
000b5a5a  8b12                     mov edx, dword ptr [rdx]

; chunk at RVA 0xb5a5c (18 bytes)
000b5a5c  48895808                 mov qword ptr [rax + 8], rbx
000b5a60  488970e8                 mov qword ptr [rax - 0x18], rsi
000b5a64  33f6                     xor esi, esi
000b5a66  4c8960e0                 mov qword ptr [rax - 0x20], r12
000b5a6a  4c8968d8                 mov qword ptr [rax - 0x28], r13

; chunk at RVA 0xb5a6e (296 bytes)
000b5a6e  4c8970d0                 mov qword ptr [rax - 0x30], r14
000b5a72  4c8978c8                 mov qword ptr [rax - 0x38], r15
000b5a76  488d442460               lea rax, [rsp + 0x60]
000b5a7b  4889442448               mov qword ptr [rsp + 0x48], rax
000b5a80  41bf08000000             mov r15d, 8
000b5a86  488d45f0                 lea rax, [rbp - 0x10]
000b5a8a  c744243800000900         mov dword ptr [rsp + 0x38], 0x90000
000b5a92  4889442450               mov qword ptr [rsp + 0x50], rax
000b5a97  488d8590010000           lea rax, [rbp + 0x190]
000b5a9e  4889442460               mov qword ptr [rsp + 0x60], rax
000b5aa3  488b01                   mov rax, qword ptr [rcx]
000b5aa6  89742440                 mov dword ptr [rsp + 0x40], esi
000b5aaa  4889b580010000           mov qword ptr [rbp + 0x180], rsi
000b5ab1  4889742458               mov qword ptr [rsp + 0x58], rsi
000b5ab6  4889b588010000           mov qword ptr [rbp + 0x188], rsi
000b5abd  c74424689e000000         mov dword ptr [rsp + 0x68], 0x9e
000b5ac5  44897c246c               mov dword ptr [rsp + 0x6c], r15d
000b5aca  4889742470               mov qword ptr [rsp + 0x70], rsi
000b5acf  89742478                 mov dword ptr [rsp + 0x78], esi
000b5ad3  c744247c11000000         mov dword ptr [rsp + 0x7c], 0x11
000b5adb  48897580                 mov qword ptr [rbp - 0x80], rsi
000b5adf  897588                   mov dword ptr [rbp - 0x78], esi
000b5ae2  c7458c12000000           mov dword ptr [rbp - 0x74], 0x12
000b5ae9  48897590                 mov qword ptr [rbp - 0x70], rsi
000b5aed  897598                   mov dword ptr [rbp - 0x68], esi
000b5af0  c7459c13000000           mov dword ptr [rbp - 0x64], 0x13
000b5af7  488975a0                 mov qword ptr [rbp - 0x60], rsi
000b5afb  8975a8                   mov dword ptr [rbp - 0x58], esi
000b5afe  c745ac14000000           mov dword ptr [rbp - 0x54], 0x14
000b5b05  488975b0                 mov qword ptr [rbp - 0x50], rsi
000b5b09  8975b8                   mov dword ptr [rbp - 0x48], esi
000b5b0c  c745bc15000000           mov dword ptr [rbp - 0x44], 0x15
000b5b13  488975c0                 mov qword ptr [rbp - 0x40], rsi
000b5b17  8975c8                   mov dword ptr [rbp - 0x38], esi
000b5b1a  c745cc16000000           mov dword ptr [rbp - 0x34], 0x16
000b5b21  488975d0                 mov qword ptr [rbp - 0x30], rsi
000b5b25  8975d8                   mov dword ptr [rbp - 0x28], esi
000b5b28  c745dc17000000           mov dword ptr [rbp - 0x24], 0x17
000b5b2f  488975e0                 mov qword ptr [rbp - 0x20], rsi
000b5b33  8975e8                   mov dword ptr [rbp - 0x18], esi
000b5b36  c745ec18000000           mov dword ptr [rbp - 0x14], 0x18
000b5b3d  ff9028020000             call qword ptr [rax + 0x228]
000b5b43  488d5eff                 lea rbx, [rsi - 1]
000b5b47  488bd0                   mov rdx, rax
000b5b4a  4885c0                   test rax, rax
000b5b4d  7410                     je 0xb5b5f
000b5b4f  488bcb                   mov rcx, rbx
000b5b52  48ffc1                   inc rcx
000b5b55  66393448                 cmp word ptr [rax + rcx*2], si
000b5b59  75f7                     jne 0xb5b52
000b5b5b  03c9                     add ecx, ecx
000b5b5d  eb02                     jmp 0xb5b61
000b5b5f  8bce                     mov ecx, esi
000b5b61  488b442448               mov rax, qword ptr [rsp + 0x48]
000b5b66  894838                   mov dword ptr [rax + 0x38], ecx
000b5b69  488b0d90f40b00           mov rcx, qword ptr [rip + 0xbf490]
000b5b70  48895030                 mov qword ptr [rax + 0x30], rdx
000b5b74  c7403c13000000           mov dword ptr [rax + 0x3c], 0x13
000b5b7b  8b17                     mov edx, dword ptr [rdi]
000b5b7d  488b01                   mov rax, qword ptr [rcx]
000b5b80  ff9020020000             call qword ptr [rax + 0x220]
000b5b86  4c8bb42438030000         mov r14, qword ptr [rsp + 0x338]
000b5b8e  488bc8                   mov rcx, rax
000b5b91  4885c0                   test rax, rax
000b5b94  740d                     je 0xb5ba3

; chunk at RVA 0xb5b96 (552 bytes)
000b5b96  48ffc3                   inc rbx
000b5b99  66393458                 cmp word ptr [rax + rbx*2], si
000b5b9d  75f7                     jne 0xb5b96
000b5b9f  03db                     add ebx, ebx
000b5ba1  eb02                     jmp 0xb5ba5
000b5ba3  8bde                     mov ebx, esi
000b5ba5  488b442448               mov rax, qword ptr [rsp + 0x48]
000b5baa  48894840                 mov qword ptr [rax + 0x40], rcx
000b5bae  895848                   mov dword ptr [rax + 0x48], ebx
000b5bb1  c7404c14000000           mov dword ptr [rax + 0x4c], 0x14
000b5bb8  488b4708                 mov rax, qword ptr [rdi + 8]
000b5bbc  48898590010000           mov qword ptr [rbp + 0x190], rax
000b5bc3  48c7858002000010000000   mov qword ptr [rbp + 0x280], 0x10
000b5bce  4889b588020000           mov qword ptr [rbp + 0x288], rsi
000b5bd5  48c7442420c4040000       mov qword ptr [rsp + 0x20], 0x4c4
000b5bde  48c744242803000000       mov qword ptr [rsp + 0x28], 3
000b5be7  488b8580020000           mov rax, qword ptr [rbp + 0x280]
000b5bee  488b8d88020000           mov rcx, qword ptr [rbp + 0x288]
000b5bf5  488b542420               mov rdx, qword ptr [rsp + 0x20]
000b5bfa  48c1e008                 shl rax, 8
000b5bfe  480bc8                   or rcx, rax
000b5c01  488b442428               mov rax, qword ptr [rsp + 0x28]
000b5c06  48c1e110                 shl rcx, 0x10
000b5c0a  480bd1                   or rdx, rcx
000b5c0d  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
000b5c12  48c1e208                 shl rdx, 8
000b5c16  480bc2                   or rax, rdx
000b5c19  48898598010000           mov qword ptr [rbp + 0x198], rax
000b5c20  488b4718                 mov rax, qword ptr [rdi + 0x18]
000b5c24  488985a0010000           mov qword ptr [rbp + 0x1a0], rax
000b5c2b  488b4738                 mov rax, qword ptr [rdi + 0x38]
000b5c2f  488985da010000           mov qword ptr [rbp + 0x1da], rax
000b5c36  488b4740                 mov rax, qword ptr [rdi + 0x40]
000b5c3a  488985e6010000           mov qword ptr [rbp + 0x1e6], rax
000b5c41  488d87c0000000           lea rax, [rdi + 0xc0]
000b5c48  48894160                 mov qword ptr [rcx + 0x60], rax
000b5c4c  44897968                 mov dword ptr [rcx + 0x68], r15d
000b5c50  c7416c16000000           mov dword ptr [rcx + 0x6c], 0x16
000b5c57  8b8fb8000000             mov ecx, dword ptr [rdi + 0xb8]
000b5c5d  488b542448               mov rdx, qword ptr [rsp + 0x48]
000b5c62  83e1fe                   and ecx, 0xfffffffe
000b5c65  488b87b0000000           mov rax, qword ptr [rdi + 0xb0]
000b5c6c  48894250                 mov qword ptr [rdx + 0x50], rax
000b5c70  894a58                   mov dword ptr [rdx + 0x58], ecx
000b5c73  c7425c15000000           mov dword ptr [rdx + 0x5c], 0x15
000b5c7a  8b8fa8000000             mov ecx, dword ptr [rdi + 0xa8]
000b5c80  488b87a0000000           mov rax, qword ptr [rdi + 0xa0]
000b5c87  83e1fe                   and ecx, 0xfffffffe
000b5c8a  488b542448               mov rdx, qword ptr [rsp + 0x48]
000b5c8f  48894210                 mov qword ptr [rdx + 0x10], rax
000b5c93  488d87d0000000           lea rax, [rdi + 0xd0]
000b5c9a  894a18                   mov dword ptr [rdx + 0x18], ecx
000b5c9d  c7421c11000000           mov dword ptr [rdx + 0x1c], 0x11
000b5ca4  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
000b5ca9  48894120                 mov qword ptr [rcx + 0x20], rax
000b5cad  c741282c000000           mov dword ptr [rcx + 0x28], 0x2c
000b5cb4  c7412c12000000           mov dword ptr [rcx + 0x2c], 0x12
000b5cbb  0fb64f30                 movzx ecx, byte ptr [rdi + 0x30]
000b5cbf  488b4710                 mov rax, qword ptr [rdi + 0x10]
000b5cc3  488985d2010000           mov qword ptr [rbp + 0x1d2], rax
000b5cca  48634728                 movsxd rax, dword ptr [rdi + 0x28]
000b5cce  488985ca010000           mov qword ptr [rbp + 0x1ca], rax
000b5cd5  4863472c                 movsxd rax, dword ptr [rdi + 0x2c]
000b5cd9  488985c0010000           mov qword ptr [rbp + 0x1c0], rax
000b5ce0  0fb6c1                   movzx eax, cl
000b5ce3  2401                     and al, 1
000b5ce5  d0e9                     shr cl, 1
000b5ce7  8885c8010000             mov byte ptr [rbp + 0x1c8], al
000b5ced  80e101                   and cl, 1
000b5cf0  48634748                 movsxd rax, dword ptr [rdi + 0x48]
000b5cf4  488985b8010000           mov qword ptr [rbp + 0x1b8], rax
000b5cfb  488d87c8000000           lea rax, [rdi + 0xc8]
000b5d02  888dc9010000             mov byte ptr [rbp + 0x1c9], cl
000b5d08  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
000b5d0d  48894170                 mov qword ptr [rcx + 0x70], rax
000b5d11  44897978                 mov dword ptr [rcx + 0x78], r15d
000b5d15  c7417c17000000           mov dword ptr [rcx + 0x7c], 0x17
000b5d1c  488b4750                 mov rax, qword ptr [rdi + 0x50]
000b5d20  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
000b5d25  488985a8010000           mov qword ptr [rbp + 0x1a8], rax
000b5d2c  488b4758                 mov rax, qword ptr [rdi + 0x58]
000b5d30  488985b0010000           mov qword ptr [rbp + 0x1b0], rax
000b5d37  488d4760                 lea rax, [rdi + 0x60]
000b5d3b  48898180000000           mov qword ptr [rcx + 0x80], rax
000b5d42  c7818800000040000000     mov dword ptr [rcx + 0x88], 0x40
000b5d4c  c7818c00000018000000     mov dword ptr [rcx + 0x8c], 0x18
000b5d56  0fb64f4c                 movzx ecx, byte ptr [rdi + 0x4c]
000b5d5a  0fb6c1                   movzx eax, cl
000b5d5d  c0e803                   shr al, 3
000b5d60  2401                     and al, 1
000b5d62  8885e5010000             mov byte ptr [rbp + 0x1e5], al
000b5d68  0fb6c1                   movzx eax, cl
000b5d6b  2401                     and al, 1
000b5d6d  8885e3010000             mov byte ptr [rbp + 0x1e3], al
000b5d73  0fb6c1                   movzx eax, cl
000b5d76  d0e8                     shr al, 1
000b5d78  2401                     and al, 1
000b5d7a  c0e902                   shr cl, 2
000b5d7d  80e101                   and cl, 1
000b5d80  8885e4010000             mov byte ptr [rbp + 0x1e4], al
000b5d86  888de2010000             mov byte ptr [rbp + 0x1e2], cl
000b5d8c  488d4c2430               lea rcx, [rsp + 0x30]
000b5d91  e88ad60100               call 0xd3420
000b5d96  4c8bbc2430030000         mov r15, qword ptr [rsp + 0x330]
000b5d9e  4c8bac2440030000         mov r13, qword ptr [rsp + 0x340]
000b5da6  4c8ba42448030000         mov r12, qword ptr [rsp + 0x348]
000b5dae  488bb42450030000         mov rsi, qword ptr [rsp + 0x350]
000b5db6  488b9c2470030000         mov rbx, qword ptr [rsp + 0x370]

; chunk at RVA 0xb5dbe (10 bytes)
000b5dbe  4881c458030000           add rsp, 0x358
000b5dc5  5f                       pop rdi
000b5dc6  5d                       pop rbp
000b5dc7  c3                       ret
