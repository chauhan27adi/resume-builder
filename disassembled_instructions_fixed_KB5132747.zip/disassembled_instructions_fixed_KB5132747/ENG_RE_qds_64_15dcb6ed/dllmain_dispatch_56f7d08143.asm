; dllmain_dispatch
; qds.dll, primary RVA 0x10a0, 164 bytes in 1 chunk(s)

; chunk at RVA 0x10a0 (164 bytes)
000010a0  488bc4                   mov rax, rsp
000010a3  48895820                 mov qword ptr [rax + 0x20], rbx
000010a7  4c894018                 mov qword ptr [rax + 0x18], r8
000010ab  895010                   mov dword ptr [rax + 0x10], edx
000010ae  48894808                 mov qword ptr [rax + 8], rcx
000010b2  56                       push rsi
000010b3  57                       push rdi
000010b4  4156                     push r14
000010b6  4883ec40                 sub rsp, 0x40
000010ba  498bf0                   mov rsi, r8
000010bd  8bfa                     mov edi, edx
000010bf  4c8bf1                   mov r14, rcx
000010c2  85d2                     test edx, edx
000010c4  0f84ae4a0d00             je 0xd5b78
000010ca  8d42ff                   lea eax, [rdx - 1]
000010cd  83f801                   cmp eax, 1
000010d0  7732                     ja 0x1104
000010d2  488b05e7000f00           mov rax, qword ptr [rip + 0xf00e7]
000010d9  4885c0                   test rax, rax
000010dc  0f85aa4a0d00             jne 0xd5b8c
000010e2  c744243001000000         mov dword ptr [rsp + 0x30], 1
000010ea  eb01                     jmp 0x10ed
000010ec  cc                       int3
000010ed  4c8bc6                   mov r8, rsi
000010f0  8bd7                     mov edx, edi
000010f2  498bce                   mov rcx, r14
000010f5  e832ffffff               call 0x102c
000010fa  8bd8                     mov ebx, eax
000010fc  89442430                 mov dword ptr [rsp + 0x30], eax
00001100  85c0                     test eax, eax
00001102  7425                     je 0x1129
00001104  4c8bc6                   mov r8, rsi
00001107  8bd7                     mov edx, edi
00001109  498bce                   mov rcx, r14
0000110c  e833000000               call 0x1144
00001111  8bd8                     mov ebx, eax
00001113  89442430                 mov dword ptr [rsp + 0x30], eax
00001117  83ff01                   cmp edi, 1
0000111a  0f84864a0d00             je 0xd5ba6
00001120  85ff                     test edi, edi
00001122  7465                     je 0x1189
00001124  83ff03                   cmp edi, 3
00001127  7460                     je 0x1189
00001129  eb01                     jmp 0x112c
0000112b  cc                       int3
0000112c  8bc3                     mov eax, ebx
0000112e  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
00001133  4883c440                 add rsp, 0x40
00001137  415e                     pop r14
00001139  5f                       pop rdi
0000113a  5e                       pop rsi
0000113b  c3                       ret
0000113c  90                       nop
0000113d  90                       nop
0000113e  90                       nop
0000113f  90                       nop
00001140  90                       nop
00001141  90                       nop
00001142  90                       nop
00001143  90                       nop
