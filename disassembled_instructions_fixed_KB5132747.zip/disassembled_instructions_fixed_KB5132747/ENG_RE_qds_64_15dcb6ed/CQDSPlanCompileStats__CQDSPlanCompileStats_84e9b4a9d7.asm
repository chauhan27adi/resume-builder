; CQDSPlanCompileStats::CQDSPlanCompileStats
; qds.dll, primary RVA 0x46810, 267 bytes in 1 chunk(s)

; chunk at RVA 0x46810 (267 bytes)
00046810  48894c2408               mov qword ptr [rsp + 8], rcx
00046815  53                       push rbx
00046816  57                       push rdi
00046817  4883ec38                 sub rsp, 0x38
0004681b  48c7442428feffffff       mov qword ptr [rsp + 0x28], 0xfffffffffffffffe
00046824  488bfa                   mov rdi, rdx
00046827  488bd9                   mov rbx, rcx
0004682a  c7410801000000           mov dword ptr [rcx + 8], 1
00046831  488d0580480b00           lea rax, [rip + 0xb4880]
00046838  488901                   mov qword ptr [rcx], rax
0004683b  488d05ce4a0b00           lea rax, [rip + 0xb4ace]
00046842  488901                   mov qword ptr [rcx], rax
00046845  48c7411000000000         mov qword ptr [rcx + 0x10], 0
0004684d  48c7411801000000         mov qword ptr [rcx + 0x18], 1
00046855  ff15e57b0a00             call qword ptr [rip + 0xa7be5]
0004685b  f680e204000010           test byte ptr [rax + 0x4e2], 0x10
00046862  753c                     jne 0x468a0
00046864  ff15967b0a00             call qword ptr [rip + 0xa7b96]
0004686a  4885c0                   test rax, rax
0004686d  7412                     je 0x46881
0004686f  ba14270000               mov edx, 0x2714
00046874  488bc8                   mov rcx, rax
00046877  ff15037c0a00             call qword ptr [rip + 0xa7c03]
0004687d  85c0                     test eax, eax
0004687f  751f                     jne 0x468a0
00046881  488b0d78e71200           mov rcx, qword ptr [rip + 0x12e778]
00046888  488b01                   mov rax, qword ptr [rcx]
0004688b  ff90c0010000             call qword ptr [rax + 0x1c0]
00046891  83b8cc38000000           cmp dword ptr [rax + 0x38cc], 0
00046898  7406                     je 0x468a0
0004689a  488b4f60                 mov rcx, qword ptr [rdi + 0x60]
0004689e  eb4d                     jmp 0x468ed
000468a0  48c744245810000000       mov qword ptr [rsp + 0x58], 0x10
000468a9  48c744246000000000       mov qword ptr [rsp + 0x60], 0
000468b2  48c7442468c4040000       mov qword ptr [rsp + 0x68], 0x4c4
000468bb  48c744242003000000       mov qword ptr [rsp + 0x20], 3
000468c4  488b442458               mov rax, qword ptr [rsp + 0x58]
000468c9  48c1e008                 shl rax, 8
000468cd  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
000468d2  480bc8                   or rcx, rax
000468d5  48c1e110                 shl rcx, 0x10
000468d9  488b442468               mov rax, qword ptr [rsp + 0x68]
000468de  480bc1                   or rax, rcx
000468e1  48c1e008                 shl rax, 8
000468e5  488b4c2420               mov rcx, qword ptr [rsp + 0x20]
000468ea  480bc8                   or rcx, rax
000468ed  48894b28                 mov qword ptr [rbx + 0x28], rcx
000468f1  488b5738                 mov rdx, qword ptr [rdi + 0x38]
000468f5  48035728                 add rdx, qword ptr [rdi + 0x28]
000468f9  48895330                 mov qword ptr [rbx + 0x30], rdx
000468fd  48895320                 mov qword ptr [rbx + 0x20], rdx
00046901  488b4718                 mov rax, qword ptr [rdi + 0x18]
00046905  48894338                 mov qword ptr [rbx + 0x38], rax
00046909  0fb74720                 movzx eax, word ptr [rdi + 0x20]
0004690d  66894340                 mov word ptr [rbx + 0x40], ax
00046911  488bc3                   mov rax, rbx
00046914  4883c438                 add rsp, 0x38
00046918  5f                       pop rdi
00046919  5b                       pop rbx
0004691a  c3                       ret
