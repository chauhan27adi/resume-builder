; CAggFunctionInfo::FSupportsLocalGlobal
; sqllang.dll, primary RVA 0x14cf60, 155 bytes in 1 chunk(s)

; chunk at RVA 0x14cf60 (155 bytes)
0014cf60  4053                     push rbx
0014cf62  4883ec20                 sub rsp, 0x20
0014cf66  488b5960                 mov rbx, qword ptr [rcx + 0x60]
0014cf6a  488bcb                   mov rcx, rbx
0014cf6d  488b03                   mov rax, qword ptr [rbx]
0014cf70  ff5010                   call qword ptr [rax + 0x10]
0014cf73  85c0                     test eax, eax
0014cf75  7430                     je 0x14cfa7
0014cf77  488b03                   mov rax, qword ptr [rbx]
0014cf7a  488bcb                   mov rcx, rbx
0014cf7d  ff5018                   call qword ptr [rax + 0x18]
0014cf80  83f83a                   cmp eax, 0x3a
0014cf83  0f874a747400             ja 0x8943d3
0014cf89  488d157030ebff           lea rdx, [rip - 0x14cf90]
0014cf90  4898                     cdqe
0014cf92  0fb68402c0cf1400         movzx eax, byte ptr [rdx + rax + 0x14cfc0]
0014cf9a  8b8c82b0cf1400           mov ecx, dword ptr [rdx + rax*4 + 0x14cfb0]
0014cfa1  4803ca                   add rcx, rdx
0014cfa4  ffe1                     jmp rcx
0014cfa6  cc                       int3
0014cfa7  b001                     mov al, 1
0014cfa9  4883c420                 add rsp, 0x20
0014cfad  5b                       pop rbx
0014cfae  c3                       ret
0014cfaf  90                       nop
0014cfb0  a7                       cmpsd dword ptr [rsi], dword ptr [rdi]
0014cfb1  cf                       iretd
0014cfb2  1400                     adc al, 0
0014cfb4  d34389                   rol dword ptr [rbx - 0x77], cl
0014cfb7  00c9                     add cl, cl
0014cfb9  438900                   mov dword ptr [r8], eax
0014cfbc  d34389                   rol dword ptr [rbx - 0x77], cl
0014cfbf  0000                     add byte ptr [rax], al
0014cfc1  0300                     add eax, dword ptr [rax]
0014cfc3  0301                     add eax, dword ptr [rcx]
0014cfc5  0300                     add eax, dword ptr [rax]
0014cfc7  0300                     add eax, dword ptr [rax]
0014cfc9  0301                     add eax, dword ptr [rcx]
0014cfcb  0300                     add eax, dword ptr [rax]
0014cfcd  0103                     add dword ptr [rbx], eax
0014cfcf  0101                     add dword ptr [rcx], eax
0014cfd1  0101                     add dword ptr [rcx], eax
0014cfd3  0101                     add dword ptr [rcx], eax
0014cfd5  0101                     add dword ptr [rcx], eax
0014cfd7  0101                     add dword ptr [rcx], eax
0014cfd9  0101                     add dword ptr [rcx], eax
0014cfdb  0100                     add dword ptr [rax], eax
0014cfdd  0100                     add dword ptr [rax], eax
0014cfdf  0101                     add dword ptr [rcx], eax
0014cfe1  0300                     add eax, dword ptr [rax]
0014cfe3  0003                     add byte ptr [rbx], al
0014cfe5  0102                     add dword ptr [rdx], eax
0014cfe7  0303                     add eax, dword ptr [rbx]
0014cfe9  0101                     add dword ptr [rcx], eax
0014cfeb  0000                     add byte ptr [rax], al
0014cfed  0101                     add dword ptr [rcx], eax
0014cfef  0000                     add byte ptr [rax], al
0014cff1  0100                     add dword ptr [rax], eax
0014cff3  0101                     add dword ptr [rcx], eax
0014cff5  0101                     add dword ptr [rcx], eax
0014cff7  0000                     add byte ptr [rax], al
0014cff9  0101                     add dword ptr [rcx], eax
