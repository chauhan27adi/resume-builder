; CDatetime2::Serialize
; sqllang.dll, primary RVA 0x5f8c20, 312 bytes in 1 chunk(s)

; chunk at RVA 0x5f8c20 (312 bytes)
005f8c20  48895c2410               mov qword ptr [rsp + 0x10], rbx
005f8c25  4889742418               mov qword ptr [rsp + 0x18], rsi
005f8c2a  57                       push rdi
005f8c2b  4883ec30                 sub rsp, 0x30
005f8c2f  33c0                     xor eax, eax
005f8c31  c702032a0000             mov dword ptr [rdx], 0x2a03
005f8c37  894218                   mov dword ptr [rdx + 0x18], eax
005f8c3a  4c8d05bf73a0ff           lea r8, [rip - 0x5f8c41]
005f8c41  48894208                 mov qword ptr [rdx + 8], rax
005f8c45  488bf2                   mov rsi, rdx
005f8c48  48894210                 mov qword ptr [rdx + 0x10], rax
005f8c4c  8b4108                   mov eax, dword ptr [rcx + 8]
005f8c4f  488b5110                 mov rdx, qword ptr [rcx + 0x10]
005f8c53  89442440                 mov dword ptr [rsp + 0x40], eax
005f8c57  0fb64118                 movzx eax, byte ptr [rcx + 0x18]
005f8c5b  4889542420               mov qword ptr [rsp + 0x20], rdx
005f8c60  410fb6bc80607e2e02       movzx edi, byte ptr [r8 + rax*4 + 0x22e7e60]
005f8c69  8d4703                   lea eax, [rdi + 3]
005f8c6c  88461b                   mov byte ptr [rsi + 0x1b], al
005f8c6f  8d47fd                   lea eax, [rdi - 3]
005f8c72  83f807                   cmp eax, 7
005f8c75  0f8784000000             ja 0x5f8cff
005f8c7b  4898                     cdqe
005f8c7d  418b8c80388d5f00         mov ecx, dword ptr [r8 + rax*4 + 0x5f8d38]
005f8c85  4903c8                   add rcx, r8
005f8c88  ffe1                     jmp rcx
005f8c8a  0fb6442422               movzx eax, byte ptr [rsp + 0x22]
005f8c8f  66895608                 mov word ptr [rsi + 8], dx
005f8c93  88460a                   mov byte ptr [rsi + 0xa], al
005f8c96  eb78                     jmp 0x5f8d10
005f8c98  895608                   mov dword ptr [rsi + 8], edx
005f8c9b  eb73                     jmp 0x5f8d10
005f8c9d  0fb6442424               movzx eax, byte ptr [rsp + 0x24]
005f8ca2  895608                   mov dword ptr [rsi + 8], edx
005f8ca5  88460c                   mov byte ptr [rsi + 0xc], al
005f8ca8  eb66                     jmp 0x5f8d10
005f8caa  0fb7442424               movzx eax, word ptr [rsp + 0x24]
005f8caf  895608                   mov dword ptr [rsi + 8], edx
005f8cb2  6689460c                 mov word ptr [rsi + 0xc], ax
005f8cb6  eb58                     jmp 0x5f8d10
005f8cb8  0fb7442424               movzx eax, word ptr [rsp + 0x24]
005f8cbd  895608                   mov dword ptr [rsi + 8], edx
005f8cc0  6689460c                 mov word ptr [rsi + 0xc], ax
005f8cc4  0fb6442426               movzx eax, byte ptr [rsp + 0x26]
005f8cc9  88460e                   mov byte ptr [rsi + 0xe], al
005f8ccc  eb42                     jmp 0x5f8d10
005f8cce  48895608                 mov qword ptr [rsi + 8], rdx
005f8cd2  eb3c                     jmp 0x5f8d10
005f8cd4  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
005f8cda  0fb6442428               movzx eax, byte ptr [rsp + 0x28]
005f8cdf  f20f114608               movsd qword ptr [rsi + 8], xmm0
005f8ce4  884610                   mov byte ptr [rsi + 0x10], al
005f8ce7  eb27                     jmp 0x5f8d10
005f8ce9  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
005f8cef  0fb7442428               movzx eax, word ptr [rsp + 0x28]
005f8cf4  f20f114608               movsd qword ptr [rsi + 8], xmm0
005f8cf9  66894610                 mov word ptr [rsi + 0x10], ax
005f8cfd  eb11                     jmp 0x5f8d10
005f8cff  4c8bc7                   mov r8, rdi
005f8d02  488d542420               lea rdx, [rsp + 0x20]
005f8d07  488d4e08                 lea rcx, [rsi + 8]
005f8d0b  e8f086a0ff               call 0x1400
005f8d10  0fb7442440               movzx eax, word ptr [rsp + 0x40]
005f8d15  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
005f8d1a  6689443708               mov word ptr [rdi + rsi + 8], ax
005f8d1f  0fb6442442               movzx eax, byte ptr [rsp + 0x42]
005f8d24  8844370a                 mov byte ptr [rdi + rsi + 0xa], al
005f8d28  c60600                   mov byte ptr [rsi], 0
005f8d2b  488b742450               mov rsi, qword ptr [rsp + 0x50]
005f8d30  4883c430                 add rsp, 0x30
005f8d34  5f                       pop rdi
005f8d35  c3                       ret
005f8d36  90                       nop
005f8d37  90                       nop
005f8d38  8a8c5f00988c5f           mov cl, byte ptr [rdi + rbx*2 + 0x5f8c9800]
005f8d3f  009d8c5f00aa             add byte ptr [rbp - 0x55ffa074], bl
005f8d45  8c5f00                   mov word ptr [rdi], ds
005f8d48  b88c5f00ce               mov eax, 0xce005f8c
005f8d4d  8c5f00                   mov word ptr [rdi], ds
