; attention_handler
; sqllang.dll, primary RVA 0xb78190, 285 bytes in 1 chunk(s)

; chunk at RVA 0xb78190 (285 bytes)
00b78190  4053                     push rbx
00b78192  4883ec20                 sub rsp, 0x20
00b78196  488b05f30af601           mov rax, qword ptr [rip + 0x1f60af3]
00b7819d  488bd9                   mov rbx, rcx
00b781a0  f680f801000001           test byte ptr [rax + 0x1f8], 1
00b781a7  0f8597000000             jne 0xb78244
00b781ad  654c8b0c2558000000       mov r9, qword ptr gs:[0x58]
00b781b6  488b05bb2d3501           mov rax, qword ptr [rip + 0x1352dbb]
00b781bd  448b00                   mov r8d, dword ptr [rax]
00b781c0  488b05b92d3501           mov rax, qword ptr [rip + 0x1352db9]
00b781c7  8b10                     mov edx, dword ptr [rax]
00b781c9  4b8b04c1                 mov rax, qword ptr [r9 + r8*8]
00b781cd  488b0410                 mov rax, qword ptr [rax + rdx]
00b781d1  4885c0                   test rax, rax
00b781d4  741b                     je 0xb781f1
00b781d6  488b4038                 mov rax, qword ptr [rax + 0x38]
00b781da  488b08                   mov rcx, qword ptr [rax]
00b781dd  4885c9                   test rcx, rcx
00b781e0  740f                     je 0xb781f1
00b781e2  bac00f0000               mov edx, 0xfc0
00b781e7  ff15ab2d3501             call qword ptr [rip + 0x1352dab]
00b781ed  85c0                     test eax, eax
00b781ef  7553                     jne 0xb78244
00b781f1  488b05980af601           mov rax, qword ptr [rip + 0x1f60a98]
00b781f8  f680fa01000040           test byte ptr [rax + 0x1fa], 0x40
00b781ff  7543                     jne 0xb78244
00b78201  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00b7820a  488b05672d3501           mov rax, qword ptr [rip + 0x1352d67]
00b78211  8b10                     mov edx, dword ptr [rax]
00b78213  488b05662d3501           mov rax, qword ptr [rip + 0x1352d66]
00b7821a  8b08                     mov ecx, dword ptr [rax]
00b7821c  498b04d0                 mov rax, qword ptr [r8 + rdx*8]
00b78220  488b0401                 mov rax, qword ptr [rcx + rax]
00b78224  4885c0                   test rax, rax
00b78227  742e                     je 0xb78257
00b78229  488b4038                 mov rax, qword ptr [rax + 0x38]
00b7822d  488b08                   mov rcx, qword ptr [rax]
00b78230  4885c9                   test rcx, rcx
00b78233  7422                     je 0xb78257
00b78235  bad60f0000               mov edx, 0xfd6
00b7823a  ff15582d3501             call qword ptr [rip + 0x1352d58]
00b78240  85c0                     test eax, eax
00b78242  7413                     je 0xb78257
00b78244  0fbf93ac020000           movsx edx, word ptr [rbx + 0x2ac]
00b7824b  488d0d8ede8a01           lea rcx, [rip + 0x18ade8e]
00b78252  e8098af100               call 0x1a90c60
00b78257  488b058a233501           mov rax, qword ptr [rip + 0x135238a]
00b7825e  833800                   cmp dword ptr [rax], 0
00b78261  7412                     je 0xb78275
00b78263  488d4c2430               lea rcx, [rsp + 0x30]
00b78268  ff15ba123501             call qword ptr [rip + 0x13512ba]
00b7826e  488b442430               mov rax, qword ptr [rsp + 0x30]
00b78273  eb08                     jmp 0xb7827d
00b78275  488b04250800fe7f         mov rax, qword ptr [0x7ffe0008]
00b7827d  4533c0                   xor r8d, r8d
00b78280  488983a0020000           mov qword ptr [rbx + 0x2a0], rax
00b78287  488bcb                   mov rcx, rbx
00b7828a  418d5012                 lea edx, [r8 + 0x12]
00b7828e  e8fd3d49ff               call 0xc090
00b78293  488b8bc8010000           mov rcx, qword ptr [rbx + 0x1c8]
00b7829a  ba01000000               mov edx, 1
00b7829f  488b01                   mov rax, qword ptr [rcx]
00b782a2  ff5030                   call qword ptr [rax + 0x30]
00b782a5  33c0                     xor eax, eax
00b782a7  4883c420                 add rsp, 0x20
00b782ab  5b                       pop rbx
00b782ac  c3                       ret
