; CEsCmContext::XVariantFromClrType
; sqllang.dll, primary RVA 0x719e60, 2923 bytes in 3 chunk(s)

; chunk at RVA 0x719e60 (19 bytes)
00719e60  4055                     push rbp
00719e62  57                       push rdi
00719e63  4157                     push r15
00719e65  488bec                   mov rbp, rsp
00719e68  4883ec50                 sub rsp, 0x50
00719e6c  448b7a60                 mov r15d, dword ptr [rdx + 0x60]
00719e70  488bf9                   mov rdi, rcx

; chunk at RVA 0x719e73 (2795 bytes)
00719e73  4889742448               mov qword ptr [rsp + 0x48], rsi
00719e78  488bf2                   mov rsi, rdx
00719e7b  4c89642440               mov qword ptr [rsp + 0x40], r12
00719e80  4c896c2438               mov qword ptr [rsp + 0x38], r13
00719e85  4c89742430               mov qword ptr [rsp + 0x30], r14
00719e8a  440fb67249               movzx r14d, byte ptr [rdx + 0x49]
00719e8f  4183ffff                 cmp r15d, -1
00719e93  7519                     jne 0x719eae
00719e95  4883c228                 add rdx, 0x28
00719e99  4533c0                   xor r8d, r8d
00719e9c  e89f86ffff               call 0x712540
00719ea1  8bd0                     mov edx, eax
00719ea3  488bcf                   mov rcx, rdi
00719ea6  448bf8                   mov r15d, eax
00719ea9  e8a290ffff               call 0x712f50
00719eae  4533c0                   xor r8d, r8d
00719eb1  48895c2470               mov qword ptr [rsp + 0x70], rbx
00719eb6  488bd6                   mov rdx, rsi
00719eb9  488bcf                   mov rcx, rdi
00719ebc  e82f92ffff               call 0x7130f0
00719ec1  488b4620                 mov rax, qword ptr [rsi + 0x20]
00719ec5  4c8d2534618eff           lea r12, [rip - 0x719ecc]
00719ecc  41bdffff0000             mov r13d, 0xffff
00719ed2  6644396810               cmp word ptr [rax + 0x10], r13w
00719ed7  741b                     je 0x719ef4
00719ed9  0fb600                   movzx eax, byte ptr [rax]
00719edc  420fb68c20403b0202       movzx ecx, byte ptr [rax + r12 + 0x2023b40]
00719ee5  4280bc21e812b00200       cmp byte ptr [rcx + r12 + 0x2b012e8], 0
00719eee  0f845a010000             je 0x71a04e
00719ef4  837e3c25                 cmp dword ptr [rsi + 0x3c], 0x25
00719ef8  0f8450010000             je 0x71a04e
00719efe  ba16000000               mov edx, 0x16
00719f03  488bcf                   mov rcx, rdi
00719f06  e8558bffff               call 0x712a60
00719f0b  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00719f0f  0fb601                   movzx eax, byte ptr [rcx]
00719f12  420fb69420403b0202       movzx edx, byte ptr [rax + r12 + 0x2023b40]
00719f1b  4280bc22688c050200       cmp byte ptr [rdx + r12 + 0x2058c68], 0
00719f24  747e                     je 0x719fa4
00719f26  ff151c1f7b01             call qword ptr [rip + 0x17b1f1c]
00719f2c  8bc8                     mov ecx, eax
00719f2e  ff151c1f7b01             call qword ptr [rip + 0x17b1f1c]
00719f34  ba21000000               mov edx, 0x21
00719f39  488bcf                   mov rcx, rdi
00719f3c  8bd8                     mov ebx, eax
00719f3e  e81d8bffff               call 0x712a60
00719f43  8bd3                     mov edx, ebx
00719f45  488bcf                   mov rcx, rdi
00719f48  e8537bffff               call 0x711aa0
00719f4d  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00719f51  ff15f11e7b01             call qword ptr [rip + 0x17b1ef1]
00719f57  448bc8                   mov r9d, eax
00719f5a  0fbae010                 bt eax, 0x10
00719f5e  7307                     jae 0x719f67
00719f60  ba00800000               mov edx, 0x8000
00719f65  eb35                     jmp 0x719f9c
00719f67  418bc9                   mov ecx, r9d
00719f6a  c1e90c                   shr ecx, 0xc
00719f6d  83e101                   and ecx, 1
00719f70  448bc1                   mov r8d, ecx
00719f73  4183c802                 or r8d, 2
00719f77  2500200000               and eax, 0x2000
00719f7c  418bc1                   mov eax, r9d
00719f7f  440f44c1                 cmove r8d, ecx
00719f83  418bd0                   mov edx, r8d
00719f86  83ca08                   or edx, 8
00719f89  2500400000               and eax, 0x4000
00719f8e  410f44d0                 cmove edx, r8d
00719f92  410fbae10f               bt r9d, 0xf
00719f97  7303                     jae 0x719f9c
00719f99  83ca10                   or edx, 0x10
00719f9c  488bcf                   mov rcx, rdi
00719f9f  e81c8effff               call 0x712dc0
00719fa4  ba04000000               mov edx, 4
00719fa9  488bcf                   mov rcx, rdi
00719fac  e8af8affff               call 0x712a60
00719fb1  ba28000000               mov edx, 0x28
00719fb6  488bcf                   mov rcx, rdi
00719fb9  e8a28affff               call 0x712a60
00719fbe  488b4620                 mov rax, qword ptr [rsi + 0x20]
00719fc2  4c8d4d28                 lea r9, [rbp + 0x28]
00719fc6  488b0f                   mov rcx, qword ptr [rdi]
00719fc9  41b8a4000000             mov r8d, 0xa4
00719fcf  0fb610                   movzx edx, byte ptr [rax]
00719fd2  420fb68422403b0202       movzx eax, byte ptr [rdx + r12 + 0x2023b40]
00719fdb  488b5708                 mov rdx, qword ptr [rdi + 8]
00719fdf  4280bc20688c050200       cmp byte ptr [rax + r12 + 0x2058c68], 0
00719fe8  7506                     jne 0x719ff0
00719fea  41b8a5000000             mov r8d, 0xa5
00719ff0  e8ab88f9ff               call 0x6b28a0
00719ff5  83f801                   cmp eax, 1
00719ff8  750d                     jne 0x71a007
00719ffa  448d4014                 lea r8d, [rax + 0x14]
00719ffe  8bd0                     mov edx, eax
0071a000  33c9                     xor ecx, ecx
0071a002  e829ff0000               call 0x729f30
0071a007  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a00a  488bcf                   mov rcx, rdi
0071a00d  0fb6d3                   movzx edx, bl
0071a010  e8cb82ffff               call 0x7122e0
0071a015  0fb7d3                   movzx edx, bx
0071a018  488bcf                   mov rcx, rdi
0071a01b  66c1ea08                 shr dx, 8
0071a01f  e8bc82ffff               call 0x7122e0
0071a024  c1eb10                   shr ebx, 0x10
0071a027  488bcf                   mov rcx, rdi
0071a02a  0fb6d3                   movzx edx, bl
0071a02d  e8ae82ffff               call 0x7122e0
0071a032  66c1eb08                 shr bx, 8
0071a036  488bcf                   mov rcx, rdi
0071a039  0fb6d3                   movzx edx, bl
0071a03c  e89f82ffff               call 0x7122e0
0071a041  ba25000000               mov edx, 0x25
0071a046  488bcf                   mov rcx, rdi
0071a049  e8128affff               call 0x712a60
0071a04e  418bd7                   mov edx, r15d
0071a051  488bcf                   mov rcx, rdi
0071a054  e8878effff               call 0x712ee0
0071a059  8b463c                   mov eax, dword ptr [rsi + 0x3c]
0071a05c  83c0e3                   add eax, -0x1d
0071a05f  83f826                   cmp eax, 0x26
0071a062  0f87ac080000             ja 0x71a914
0071a068  4898                     cdqe
0071a06a  410fb68404a4a97100       movzx eax, byte ptr [r12 + rax + 0x71a9a4]
0071a073  418b8c847ca97100         mov ecx, dword ptr [r12 + rax*4 + 0x71a97c]
0071a07b  4903cc                   add rcx, r12
0071a07e  ffe1                     jmp rcx
0071a080  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a084  80382a                   cmp byte ptr [rax], 0x2a
0071a087  750c                     jne 0x71a095
0071a089  0fb65013                 movzx edx, byte ptr [rax + 0x13]
0071a08d  488bcf                   mov rcx, rdi
0071a090  e82b8dffff               call 0x712dc0
0071a095  ba28000000               mov edx, 0x28
0071a09a  488bcf                   mov rcx, rdi
0071a09d  e8be89ffff               call 0x712a60
0071a0a2  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a0a6  0fb608                   movzx ecx, byte ptr [rax]
0071a0a9  80f93d                   cmp cl, 0x3d
0071a0ac  750e                     jne 0x71a0bc
0071a0ae  33c0                     xor eax, eax
0071a0b0  4584f6                   test r14b, r14b
0071a0b3  0f95c0                   setne al
0071a0b6  448d4076                 lea r8d, [rax + 0x76]
0071a0ba  eb2e                     jmp 0x71a0ea
0071a0bc  80f928                   cmp cl, 0x28
0071a0bf  7511                     jne 0x71a0d2
0071a0c1  33c0                     xor eax, eax
0071a0c3  4584f6                   test r14b, r14b
0071a0c6  0f95c0                   setne al
0071a0c9  448d8086000000           lea r8d, [rax + 0x86]
0071a0d0  eb18                     jmp 0x71a0ea
0071a0d2  80f92a                   cmp cl, 0x2a
0071a0d5  0f8564080000             jne 0x71a93f
0071a0db  33c0                     xor eax, eax
0071a0dd  4584f6                   test r14b, r14b
0071a0e0  0f95c0                   setne al
0071a0e3  448d808e000000           lea r8d, [rax + 0x8e]
0071a0ea  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a0ee  4c8d4d28                 lea r9, [rbp + 0x28]
0071a0f2  488b0f                   mov rcx, qword ptr [rdi]
0071a0f5  e8a687f9ff               call 0x6b28a0
0071a0fa  83f801                   cmp eax, 1
0071a0fd  750d                     jne 0x71a10c
0071a0ff  8bd0                     mov edx, eax
0071a101  448d4014                 lea r8d, [rax + 0x14]
0071a105  33c9                     xor ecx, ecx
0071a107  e824fe0000               call 0x729f30
0071a10c  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a10f  488bcf                   mov rcx, rdi
0071a112  0fb6d3                   movzx edx, bl
0071a115  e8c681ffff               call 0x7122e0
0071a11a  0fb7d3                   movzx edx, bx
0071a11d  488bcf                   mov rcx, rdi
0071a120  66c1ea08                 shr dx, 8
0071a124  e8b781ffff               call 0x7122e0
0071a129  c1eb10                   shr ebx, 0x10
0071a12c  488bcf                   mov rcx, rdi
0071a12f  0fb6d3                   movzx edx, bl
0071a132  e8a981ffff               call 0x7122e0
0071a137  66c1eb08                 shr bx, 8
0071a13b  488bcf                   mov rcx, rdi
0071a13e  0fb6d3                   movzx edx, bl
0071a141  e89a81ffff               call 0x7122e0
0071a146  e9f4070000               jmp 0x71a93f
0071a14b  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a14f  0fb611                   movzx edx, byte ptr [rcx]
0071a152  8d4210                   lea eax, [rdx + 0x10]
0071a155  3c01                     cmp al, 1
0071a157  7606                     jbe 0x71a15f
0071a159  0fb64113                 movzx eax, byte ptr [rcx + 0x13]
0071a15d  eb12                     jmp 0x71a171
0071a15f  420fb68c22403b0202       movzx ecx, byte ptr [rdx + r12 + 0x2023b40]
0071a168  410fb6848c433c0202       movzx eax, byte ptr [r12 + rcx*4 + 0x2023c43]
0071a171  0fb6d0                   movzx edx, al
0071a174  488bcf                   mov rcx, rdi
0071a177  e8448cffff               call 0x712dc0
0071a17c  ba28000000               mov edx, 0x28
0071a181  488bcf                   mov rcx, rdi
0071a184  e8d788ffff               call 0x712a60
0071a189  33c0                     xor eax, eax
0071a18b  4584f6                   test r14b, r14b
0071a18e  0f95c0                   setne al
0071a191  448d8092000000           lea r8d, [rax + 0x92]
0071a198  e94dffffff               jmp 0x71a0ea
0071a19d  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a1a1  0fb611                   movzx edx, byte ptr [rcx]
0071a1a4  8d4210                   lea eax, [rdx + 0x10]
0071a1a7  3c01                     cmp al, 1
0071a1a9  7606                     jbe 0x71a1b1
0071a1ab  0fb64113                 movzx eax, byte ptr [rcx + 0x13]
0071a1af  eb12                     jmp 0x71a1c3
0071a1b1  420fb68c22403b0202       movzx ecx, byte ptr [rdx + r12 + 0x2023b40]
0071a1ba  410fb6848c433c0202       movzx eax, byte ptr [r12 + rcx*4 + 0x2023c43]
0071a1c3  0fb6d0                   movzx edx, al
0071a1c6  488bcf                   mov rcx, rdi
0071a1c9  e8f28bffff               call 0x712dc0
0071a1ce  ba28000000               mov edx, 0x28
0071a1d3  488bcf                   mov rcx, rdi
0071a1d6  e88588ffff               call 0x712a60
0071a1db  33c0                     xor eax, eax
0071a1dd  4584f6                   test r14b, r14b
0071a1e0  0f95c0                   setne al
0071a1e3  448d808a000000           lea r8d, [rax + 0x8a]
0071a1ea  e9fbfeffff               jmp 0x71a0ea
0071a1ef  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a1f3  0fb611                   movzx edx, byte ptr [rcx]
0071a1f6  8d4210                   lea eax, [rdx + 0x10]
0071a1f9  3c01                     cmp al, 1
0071a1fb  7606                     jbe 0x71a203
0071a1fd  0fb64112                 movzx eax, byte ptr [rcx + 0x12]
0071a201  eb12                     jmp 0x71a215
0071a203  420fb68c22403b0202       movzx ecx, byte ptr [rdx + r12 + 0x2023b40]
0071a20c  410fb6848c423c0202       movzx eax, byte ptr [r12 + rcx*4 + 0x2023c42]
0071a215  0fb6d0                   movzx edx, al
0071a218  488bcf                   mov rcx, rdi
0071a21b  e8a08bffff               call 0x712dc0
0071a220  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a224  0fb611                   movzx edx, byte ptr [rcx]
0071a227  8d4210                   lea eax, [rdx + 0x10]
0071a22a  3c01                     cmp al, 1
0071a22c  7606                     jbe 0x71a234
0071a22e  0fb64113                 movzx eax, byte ptr [rcx + 0x13]
0071a232  eb12                     jmp 0x71a246
0071a234  420fb68c22403b0202       movzx ecx, byte ptr [rdx + r12 + 0x2023b40]
0071a23d  410fb6848c433c0202       movzx eax, byte ptr [r12 + rcx*4 + 0x2023c43]
0071a246  0fb6d0                   movzx edx, al
0071a249  488bcf                   mov rcx, rdi
0071a24c  e86f8bffff               call 0x712dc0
0071a251  ba28000000               mov edx, 0x28
0071a256  488bcf                   mov rcx, rdi
0071a259  e80288ffff               call 0x712a60
0071a25e  33c0                     xor eax, eax
0071a260  4584f6                   test r14b, r14b
0071a263  0f95c0                   setne al
0071a266  448d4070                 lea r8d, [rax + 0x70]
0071a26a  e97bfeffff               jmp 0x71a0ea
0071a26f  ba28000000               mov edx, 0x28
0071a274  488bcf                   mov rcx, rdi
0071a277  e8e487ffff               call 0x712a60
0071a27c  33c0                     xor eax, eax
0071a27e  4584f6                   test r14b, r14b
0071a281  0f95c0                   setne al
0071a284  448d405e                 lea r8d, [rax + 0x5e]
0071a288  e95dfeffff               jmp 0x71a0ea
0071a28d  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a291  0fb608                   movzx ecx, byte ptr [rax]
0071a294  420fb69421403b0202       movzx edx, byte ptr [rcx + r12 + 0x2023b40]
0071a29d  4280bc22100b060200       cmp byte ptr [rdx + r12 + 0x2060b10], 0
0071a2a6  7407                     je 0x71a2af
0071a2a8  6644396810               cmp word ptr [rax + 0x10], r13w
0071a2ad  7409                     je 0x71a2b8
0071a2af  80f922                   cmp cl, 0x22
0071a2b2  0f8587000000             jne 0x71a33f
0071a2b8  ba28000000               mov edx, 0x28
0071a2bd  488bcf                   mov rcx, rdi
0071a2c0  e89b87ffff               call 0x712a60
0071a2c5  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a2c9  4c8d4d28                 lea r9, [rbp + 0x28]
0071a2cd  488b0f                   mov rcx, qword ptr [rdi]
0071a2d0  41b8b8000000             mov r8d, 0xb8
0071a2d6  e8c585f9ff               call 0x6b28a0
0071a2db  83f801                   cmp eax, 1
0071a2de  750d                     jne 0x71a2ed
0071a2e0  8bd0                     mov edx, eax
0071a2e2  448d4014                 lea r8d, [rax + 0x14]
0071a2e6  33c9                     xor ecx, ecx
0071a2e8  e843fc0000               call 0x729f30
0071a2ed  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a2f0  488bcf                   mov rcx, rdi
0071a2f3  0fb6d3                   movzx edx, bl
0071a2f6  e8e57fffff               call 0x7122e0
0071a2fb  0fb7d3                   movzx edx, bx
0071a2fe  488bcf                   mov rcx, rdi
0071a301  66c1ea08                 shr dx, 8
0071a305  e8d67fffff               call 0x7122e0
0071a30a  c1eb10                   shr ebx, 0x10
0071a30d  488bcf                   mov rcx, rdi
0071a310  0fb6d3                   movzx edx, bl
0071a313  e8c87fffff               call 0x7122e0
0071a318  66c1eb08                 shr bx, 8
0071a31c  488bcf                   mov rcx, rdi
0071a31f  0fb6d3                   movzx edx, bl
0071a322  e8b97fffff               call 0x7122e0
0071a327  ba28000000               mov edx, 0x28
0071a32c  488bcf                   mov rcx, rdi
0071a32f  e82c87ffff               call 0x712a60
0071a334  41b8bb000000             mov r8d, 0xbb
0071a33a  e9abfdffff               jmp 0x71a0ea
0071a33f  440fb77010               movzx r14d, word ptr [rax + 0x10]
0071a344  bba41f0000               mov ebx, 0x1fa4
0071a349  66453bf5                 cmp r14w, r13w
0071a34d  740b                     je 0x71a35a
0071a34f  4280bc22e812b00200       cmp byte ptr [rdx + r12 + 0x2b012e8], 0
0071a358  7403                     je 0x71a35d
0071a35a  448bf3                   mov r14d, ebx
0071a35d  ba21000000               mov edx, 0x21
0071a362  488bcf                   mov rcx, rdi
0071a365  e8f686ffff               call 0x712a60
0071a36a  410fb7d6                 movzx edx, r14w
0071a36e  488bcf                   mov rcx, rdi
0071a371  e82a77ffff               call 0x711aa0
0071a376  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a37a  440fb77010               movzx r14d, word ptr [rax + 0x10]
0071a37f  66453bf5                 cmp r14w, r13w
0071a383  7417                     je 0x71a39c
0071a385  0fb600                   movzx eax, byte ptr [rax]
0071a388  420fb68c20403b0202       movzx ecx, byte ptr [rax + r12 + 0x2023b40]
0071a391  4280bc21e812b00200       cmp byte ptr [rcx + r12 + 0x2b012e8], 0
0071a39a  7403                     je 0x71a39f
0071a39c  448bf3                   mov r14d, ebx
0071a39f  ba21000000               mov edx, 0x21
0071a3a4  488bcf                   mov rcx, rdi
0071a3a7  e8b486ffff               call 0x712a60
0071a3ac  410fb7d6                 movzx edx, r14w
0071a3b0  488bcf                   mov rcx, rdi
0071a3b3  e8e876ffff               call 0x711aa0
0071a3b8  ba15000000               mov edx, 0x15
0071a3bd  488bcf                   mov rcx, rdi
0071a3c0  e89b86ffff               call 0x712a60
0071a3c5  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a3c9  ff15491b7b01             call qword ptr [rip + 0x17b1b49]
0071a3cf  8bd0                     mov edx, eax
0071a3d1  488bcf                   mov rcx, rdi
0071a3d4  e8e789ffff               call 0x712dc0
0071a3d9  ba28000000               mov edx, 0x28
0071a3de  488bcf                   mov rcx, rdi
0071a3e1  e87a86ffff               call 0x712a60
0071a3e6  41b859000000             mov r8d, 0x59
0071a3ec  e9f9fcffff               jmp 0x71a0ea
0071a3f1  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a3f5  440fb77010               movzx r14d, word ptr [rax + 0x10]
0071a3fa  66453bf5                 cmp r14w, r13w
0071a3fe  0f84cc000000             je 0x71a4d0
0071a404  0fb608                   movzx ecx, byte ptr [rax]
0071a407  420fb68421403b0202       movzx eax, byte ptr [rcx + r12 + 0x2023b40]
0071a410  4280bc20e812b00200       cmp byte ptr [rax + r12 + 0x2b012e8], 0
0071a419  0f85b1000000             jne 0x71a4d0
0071a41f  420fb68c21403b0202       movzx ecx, byte ptr [rcx + r12 + 0x2023b40]
0071a428  bba41f0000               mov ebx, 0x1fa4
0071a42d  4280bc21e812b00200       cmp byte ptr [rcx + r12 + 0x2b012e8], 0
0071a436  7404                     je 0x71a43c
0071a438  440fb7f3                 movzx r14d, bx
0071a43c  ba21000000               mov edx, 0x21
0071a441  488bcf                   mov rcx, rdi
0071a444  e81786ffff               call 0x712a60
0071a449  410fb7d6                 movzx edx, r14w
0071a44d  488bcf                   mov rcx, rdi
0071a450  e84b76ffff               call 0x711aa0
0071a455  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a459  440fb77010               movzx r14d, word ptr [rax + 0x10]
0071a45e  66453bf5                 cmp r14w, r13w
0071a462  7417                     je 0x71a47b
0071a464  0fb600                   movzx eax, byte ptr [rax]
0071a467  420fb68c20403b0202       movzx ecx, byte ptr [rax + r12 + 0x2023b40]
0071a470  4280bc21e812b00200       cmp byte ptr [rcx + r12 + 0x2b012e8], 0
0071a479  7403                     je 0x71a47e
0071a47b  448bf3                   mov r14d, ebx
0071a47e  ba21000000               mov edx, 0x21
0071a483  488bcf                   mov rcx, rdi
0071a486  e8d585ffff               call 0x712a60
0071a48b  410fb7d6                 movzx edx, r14w
0071a48f  488bcf                   mov rcx, rdi
0071a492  e80976ffff               call 0x711aa0
0071a497  ba15000000               mov edx, 0x15
0071a49c  488bcf                   mov rcx, rdi
0071a49f  e8bc85ffff               call 0x712a60
0071a4a4  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a4a8  ff156a1a7b01             call qword ptr [rip + 0x17b1a6a]
0071a4ae  8bd0                     mov edx, eax
0071a4b0  488bcf                   mov rcx, rdi
0071a4b3  e80889ffff               call 0x712dc0
0071a4b8  ba28000000               mov edx, 0x28
0071a4bd  488bcf                   mov rcx, rdi
0071a4c0  e89b85ffff               call 0x712a60
0071a4c5  41b850000000             mov r8d, 0x50
0071a4cb  e91afcffff               jmp 0x71a0ea
0071a4d0  ba28000000               mov edx, 0x28
0071a4d5  488bcf                   mov rcx, rdi
0071a4d8  e88385ffff               call 0x712a60
0071a4dd  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a4e1  4c8d4d28                 lea r9, [rbp + 0x28]
0071a4e5  488b0f                   mov rcx, qword ptr [rdi]
0071a4e8  41b8b1000000             mov r8d, 0xb1
0071a4ee  e8ad83f9ff               call 0x6b28a0
0071a4f3  83f801                   cmp eax, 1
0071a4f6  750d                     jne 0x71a505
0071a4f8  8bd0                     mov edx, eax
0071a4fa  448d4014                 lea r8d, [rax + 0x14]
0071a4fe  33c9                     xor ecx, ecx
0071a500  e82bfa0000               call 0x729f30
0071a505  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a508  488bcf                   mov rcx, rdi
0071a50b  0fb6d3                   movzx edx, bl
0071a50e  e8cd7dffff               call 0x7122e0
0071a513  0fb7d3                   movzx edx, bx
0071a516  488bcf                   mov rcx, rdi
0071a519  66c1ea08                 shr dx, 8
0071a51d  e8be7dffff               call 0x7122e0
0071a522  c1eb10                   shr ebx, 0x10
0071a525  488bcf                   mov rcx, rdi
0071a528  0fb6d3                   movzx edx, bl
0071a52b  e8b07dffff               call 0x7122e0
0071a530  66c1eb08                 shr bx, 8
0071a534  488bcf                   mov rcx, rdi
0071a537  0fb6d3                   movzx edx, bl
0071a53a  e8a17dffff               call 0x7122e0
0071a53f  ba28000000               mov edx, 0x28
0071a544  488bcf                   mov rcx, rdi
0071a547  e81485ffff               call 0x712a60
0071a54c  41b8b2000000             mov r8d, 0xb2
0071a552  e993fbffff               jmp 0x71a0ea
0071a557  33c0                     xor eax, eax
0071a559  4c8d4528                 lea r8, [rbp + 0x28]
0071a55d  488bcf                   mov rcx, rdi
0071a560  48894528                 mov qword ptr [rbp + 0x28], rax
0071a564  48894530                 mov qword ptr [rbp + 0x30], rax
0071a568  8d503a                   lea edx, [rax + 0x3a]
0071a56b  e87085ffff               call 0x712ae0
0071a570  8b9fa0000000             mov ebx, dword ptr [rdi + 0xa0]
0071a576  ba26000000               mov edx, 0x26
0071a57b  488bcf                   mov rcx, rdi
0071a57e  e8dd84ffff               call 0x712a60
0071a583  41b003                   mov r8b, 3
0071a586  488bd6                   mov rdx, rsi
0071a589  488bcf                   mov rcx, rdi
0071a58c  e86f8cffff               call 0x713200
0071a591  4c8d4530                 lea r8, [rbp + 0x30]
0071a595  ba38000000               mov edx, 0x38
0071a59a  488bcf                   mov rcx, rdi
0071a59d  e83e85ffff               call 0x712ae0
0071a5a2  488b4750                 mov rax, qword ptr [rdi + 0x50]
0071a5a6  488d5528                 lea rdx, [rbp + 0x28]
0071a5aa  488bcf                   mov rcx, rdi
0071a5ad  448b4804                 mov r9d, dword ptr [rax + 4]
0071a5b1  448b00                   mov r8d, dword ptr [rax]
0071a5b4  e8078affff               call 0x712fc0
0071a5b9  4533c0                   xor r8d, r8d
0071a5bc  899fa0000000             mov dword ptr [rdi + 0xa0], ebx
0071a5c2  488bd6                   mov rdx, rsi
0071a5c5  488bcf                   mov rcx, rdi
0071a5c8  e8338cffff               call 0x713200
0071a5cd  41b802000000             mov r8d, 2
0071a5d3  488bd6                   mov rdx, rsi
0071a5d6  488bcf                   mov rcx, rdi
0071a5d9  e8128bffff               call 0x7130f0
0071a5de  ba25000000               mov edx, 0x25
0071a5e3  488bcf                   mov rcx, rdi
0071a5e6  e87584ffff               call 0x712a60
0071a5eb  ba48000000               mov edx, 0x48
0071a5f0  488bcf                   mov rcx, rdi
0071a5f3  e86884ffff               call 0x712a60
0071a5f8  ba20000000               mov edx, 0x20
0071a5fd  488bcf                   mov rcx, rdi
0071a600  e85b84ffff               call 0x712a60
0071a605  33d2                     xor edx, edx
0071a607  488bcf                   mov rcx, rdi
0071a60a  e8d17cffff               call 0x7122e0
0071a60f  b208                     mov dl, 8
0071a611  488bcf                   mov rcx, rdi
0071a614  e8c77cffff               call 0x7122e0
0071a619  33d2                     xor edx, edx
0071a61b  488bcf                   mov rcx, rdi
0071a61e  e8bd7cffff               call 0x7122e0
0071a623  33d2                     xor edx, edx
0071a625  488bcf                   mov rcx, rdi
0071a628  e8b37cffff               call 0x7122e0
0071a62d  ba60000000               mov edx, 0x60
0071a632  488bcf                   mov rcx, rdi
0071a635  e82684ffff               call 0x712a60
0071a63a  ba53000000               mov edx, 0x53
0071a63f  488bcf                   mov rcx, rdi
0071a642  e81984ffff               call 0x712a60
0071a647  ba1f000000               mov edx, 0x1f
0071a64c  488bcf                   mov rcx, rdi
0071a64f  e80c84ffff               call 0x712a60
0071a654  b218                     mov dl, 0x18
0071a656  488bcf                   mov rcx, rdi
0071a659  e8827cffff               call 0x7122e0
0071a65e  ba58000000               mov edx, 0x58
0071a663  488bcf                   mov rcx, rdi
0071a666  e8f583ffff               call 0x712a60
0071a66b  418bd7                   mov edx, r15d
0071a66e  488bcf                   mov rcx, rdi
0071a671  e86a88ffff               call 0x712ee0
0071a676  837e3c42                 cmp dword ptr [rsi + 0x3c], 0x42
0071a67a  756f                     jne 0x71a6eb
0071a67c  ba6f000000               mov edx, 0x6f
0071a681  488bcf                   mov rcx, rdi
0071a684  e8d783ffff               call 0x712a60
0071a689  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a68d  4c8d4d28                 lea r9, [rbp + 0x28]
0071a691  488b0f                   mov rcx, qword ptr [rdi]
0071a694  41b8c6000000             mov r8d, 0xc6
0071a69a  e80182f9ff               call 0x6b28a0
0071a69f  83f801                   cmp eax, 1
0071a6a2  750d                     jne 0x71a6b1
0071a6a4  8bd0                     mov edx, eax
0071a6a6  448d4014                 lea r8d, [rax + 0x14]
0071a6aa  33c9                     xor ecx, ecx
0071a6ac  e87ff80000               call 0x729f30
0071a6b1  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a6b4  488bcf                   mov rcx, rdi
0071a6b7  0fb6d3                   movzx edx, bl
0071a6ba  e8217cffff               call 0x7122e0
0071a6bf  0fb7d3                   movzx edx, bx
0071a6c2  488bcf                   mov rcx, rdi
0071a6c5  66c1ea08                 shr dx, 8
0071a6c9  e8127cffff               call 0x7122e0
0071a6ce  c1eb10                   shr ebx, 0x10
0071a6d1  488bcf                   mov rcx, rdi
0071a6d4  0fb6d3                   movzx edx, bl
0071a6d7  e8047cffff               call 0x7122e0
0071a6dc  66c1eb08                 shr bx, 8
0071a6e0  488bcf                   mov rcx, rdi
0071a6e3  0fb6d3                   movzx edx, bl
0071a6e6  e8f57bffff               call 0x7122e0
0071a6eb  ba28000000               mov edx, 0x28
0071a6f0  488bcf                   mov rcx, rdi
0071a6f3  e86883ffff               call 0x712a60
0071a6f8  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a6fc  4c8d4d28                 lea r9, [rbp + 0x28]
0071a700  488b0f                   mov rcx, qword ptr [rdi]
0071a703  41b804000000             mov r8d, 4
0071a709  e89281f9ff               call 0x6b28a0
0071a70e  83f801                   cmp eax, 1
0071a711  750d                     jne 0x71a720
0071a713  8bd0                     mov edx, eax
0071a715  448d4014                 lea r8d, [rax + 0x14]
0071a719  33c9                     xor ecx, ecx
0071a71b  e810f80000               call 0x729f30
0071a720  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a723  488bcf                   mov rcx, rdi
0071a726  0fb6d3                   movzx edx, bl
0071a729  e8b27bffff               call 0x7122e0
0071a72e  0fb7d3                   movzx edx, bx
0071a731  488bcf                   mov rcx, rdi
0071a734  66c1ea08                 shr dx, 8
0071a738  e8a37bffff               call 0x7122e0
0071a73d  c1eb10                   shr ebx, 0x10
0071a740  488bcf                   mov rcx, rdi
0071a743  0fb6d3                   movzx edx, bl
0071a746  e8957bffff               call 0x7122e0
0071a74b  66c1eb08                 shr bx, 8
0071a74f  488bcf                   mov rcx, rdi
0071a752  0fb6d3                   movzx edx, bl
0071a755  e8867bffff               call 0x7122e0
0071a75a  ba28000000               mov edx, 0x28
0071a75f  488bcf                   mov rcx, rdi
0071a762  e8f982ffff               call 0x712a60
0071a767  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a76b  4c8d4d28                 lea r9, [rbp + 0x28]
0071a76f  488b0f                   mov rcx, qword ptr [rdi]
0071a772  41b805000000             mov r8d, 5
0071a778  e82381f9ff               call 0x6b28a0
0071a77d  83f801                   cmp eax, 1
0071a780  750d                     jne 0x71a78f
0071a782  8bd0                     mov edx, eax
0071a784  448d4014                 lea r8d, [rax + 0x14]
0071a788  33c9                     xor ecx, ecx
0071a78a  e8a1f70000               call 0x729f30
0071a78f  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a792  488bcf                   mov rcx, rdi
0071a795  0fb6d3                   movzx edx, bl
0071a798  e8437bffff               call 0x7122e0
0071a79d  0fb7d3                   movzx edx, bx
0071a7a0  488bcf                   mov rcx, rdi
0071a7a3  66c1ea08                 shr dx, 8
0071a7a7  e8347bffff               call 0x7122e0
0071a7ac  c1eb10                   shr ebx, 0x10
0071a7af  488bcf                   mov rcx, rdi
0071a7b2  0fb6d3                   movzx edx, bl
0071a7b5  e8267bffff               call 0x7122e0
0071a7ba  66c1eb08                 shr bx, 8
0071a7be  488bcf                   mov rcx, rdi
0071a7c1  0fb6d3                   movzx edx, bl
0071a7c4  e8177bffff               call 0x7122e0
0071a7c9  ba55000000               mov edx, 0x55
0071a7ce  488bcf                   mov rcx, rdi
0071a7d1  e88a82ffff               call 0x712a60
0071a7d6  488b4750                 mov rax, qword ptr [rdi + 0x50]
0071a7da  488d5530                 lea rdx, [rbp + 0x30]
0071a7de  488bcf                   mov rcx, rdi
0071a7e1  448b4804                 mov r9d, dword ptr [rax + 4]
0071a7e5  448b00                   mov r8d, dword ptr [rax]
0071a7e8  e8d387ffff               call 0x712fc0
0071a7ed  e94d010000               jmp 0x71a93f
0071a7f2  41b818000000             mov r8d, 0x18
0071a7f8  488bd6                   mov rdx, rsi
0071a7fb  488bcf                   mov rcx, rdi
0071a7fe  e8ed88ffff               call 0x7130f0
0071a803  418bd7                   mov edx, r15d
0071a806  488bcf                   mov rcx, rdi
0071a809  e8d286ffff               call 0x712ee0
0071a80e  ba28000000               mov edx, 0x28
0071a813  488bcf                   mov rcx, rdi
0071a816  e84582ffff               call 0x712a60
0071a81b  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a81f  4c8d4d28                 lea r9, [rbp + 0x28]
0071a823  488b0f                   mov rcx, qword ptr [rdi]
0071a826  41b805000000             mov r8d, 5
0071a82c  e86f80f9ff               call 0x6b28a0
0071a831  83f801                   cmp eax, 1
0071a834  750d                     jne 0x71a843
0071a836  8bd0                     mov edx, eax
0071a838  448d4014                 lea r8d, [rax + 0x14]
0071a83c  33c9                     xor ecx, ecx
0071a83e  e8edf60000               call 0x729f30
0071a843  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a846  488bcf                   mov rcx, rdi
0071a849  0fb6d3                   movzx edx, bl
0071a84c  e88f7affff               call 0x7122e0
0071a851  0fb7d3                   movzx edx, bx
0071a854  488bcf                   mov rcx, rdi
0071a857  66c1ea08                 shr dx, 8
0071a85b  e8807affff               call 0x7122e0
0071a860  c1eb10                   shr ebx, 0x10
0071a863  488bcf                   mov rcx, rdi
0071a866  0fb6d3                   movzx edx, bl
0071a869  e8727affff               call 0x7122e0
0071a86e  66c1eb08                 shr bx, 8
0071a872  488bcf                   mov rcx, rdi
0071a875  0fb6d3                   movzx edx, bl
0071a878  e8637affff               call 0x7122e0
0071a87d  ba55000000               mov edx, 0x55
0071a882  488bcf                   mov rcx, rdi
0071a885  e8d681ffff               call 0x712a60
0071a88a  4533c0                   xor r8d, r8d
0071a88d  488bd6                   mov rdx, rsi
0071a890  488bcf                   mov rcx, rdi
0071a893  e86889ffff               call 0x713200
0071a898  41b802000000             mov r8d, 2
0071a89e  488bd6                   mov rdx, rsi
0071a8a1  488bcf                   mov rcx, rdi
0071a8a4  e84788ffff               call 0x7130f0
0071a8a9  ba25000000               mov edx, 0x25
0071a8ae  488bcf                   mov rcx, rdi
0071a8b1  e8aa81ffff               call 0x712a60
0071a8b6  ba48000000               mov edx, 0x48
0071a8bb  488bcf                   mov rcx, rdi
0071a8be  e89d81ffff               call 0x712a60
0071a8c3  ba20000000               mov edx, 0x20
0071a8c8  488bcf                   mov rcx, rdi
0071a8cb  e89081ffff               call 0x712a60
0071a8d0  33d2                     xor edx, edx
0071a8d2  488bcf                   mov rcx, rdi
0071a8d5  e8067affff               call 0x7122e0
0071a8da  b208                     mov dl, 8
0071a8dc  488bcf                   mov rcx, rdi
0071a8df  e8fc79ffff               call 0x7122e0
0071a8e4  33d2                     xor edx, edx
0071a8e6  488bcf                   mov rcx, rdi
0071a8e9  e8f279ffff               call 0x7122e0
0071a8ee  33d2                     xor edx, edx
0071a8f0  488bcf                   mov rcx, rdi
0071a8f3  e8e879ffff               call 0x7122e0
0071a8f8  ba60000000               mov edx, 0x60
0071a8fd  488bcf                   mov rcx, rdi
0071a900  e85b81ffff               call 0x712a60
0071a905  ba53000000               mov edx, 0x53
0071a90a  488bcf                   mov rcx, rdi
0071a90d  e84e81ffff               call 0x712a60
0071a912  eb2b                     jmp 0x71a93f
0071a914  488d050ddca301           lea rax, [rip + 0x1a3dc0d]
0071a91b  41b9ba140000             mov r9d, 0x14ba
0071a921  4c8d05d877df01           lea r8, [rip + 0x1df77d8]
0071a928  4889442420               mov qword ptr [rsp + 0x20], rax
0071a92d  488d150ca1df01           lea rdx, [rip + 0x1dfa10c]
0071a934  b901000000               mov ecx, 1
0071a939  ff1539057b01             call qword ptr [rip + 0x17b0539]
0071a93f  837e60ff                 cmp dword ptr [rsi + 0x60], -1
0071a943  488b742448               mov rsi, qword ptr [rsp + 0x48]
0071a948  4c8b742430               mov r14, qword ptr [rsp + 0x30]
0071a94d  4c8b6c2438               mov r13, qword ptr [rsp + 0x38]
0071a952  4c8b642440               mov r12, qword ptr [rsp + 0x40]
0071a957  488b5c2470               mov rbx, qword ptr [rsp + 0x70]
0071a95c  7513                     jne 0x71a971

; chunk at RVA 0x71a95e (109 bytes)
0071a95e  488b8780000000           mov rax, qword ptr [rdi + 0x80]
0071a965  418bcf                   mov ecx, r15d
0071a968  48c1e106                 shl rcx, 6
0071a96c  834c013c01               or dword ptr [rcx + rax + 0x3c], 1
0071a971  4883c450                 add rsp, 0x50
0071a975  415f                     pop r15
0071a977  5f                       pop rdi
0071a978  5d                       pop rbp
0071a979  c3                       ret
0071a97a  90                       nop
0071a97b  90                       nop
0071a97c  6f                       outsd dx, dword ptr [rsi]
0071a97d  a27100efa1710080a0       movabs byte ptr [0xa0800071a1ef0071], al
0071a986  7100                     jno 0x71a988
0071a988  4ba17100f2a771009da1     movabs rax, qword ptr [0xa19d0071a7f20071]
0071a992  7100                     jno 0x71a994
0071a994  8da27100f1a3             lea esp, [rdx - 0x5c0eff8f]
0071a99a  7100                     jno 0x71a99c
0071a99c  57                       push rdi
0071a99d  a5                       movsd dword ptr [rdi], dword ptr [rsi]
0071a99e  7100                     jno 0x71a9a0
0071a9a0  14a9                     adc al, 0xa9
0071a9a2  7100                     jno 0x71a9a4
0071a9a4  0000                     add byte ptr [rax], al
0071a9a6  0101                     add dword ptr [rcx], eax
0071a9a8  0202                     add al, byte ptr [rdx]
0071a9aa  0303                     add eax, dword ptr [rbx]
0071a9ac  0405                     add al, 5
0071a9ae  0509090909               add eax, 0x9090909
0071a9b3  0909                     or dword ptr [rcx], ecx
0071a9b5  0909                     or dword ptr [rcx], ecx
0071a9b7  0909                     or dword ptr [rcx], ecx
0071a9b9  0909                     or dword ptr [rcx], ecx
0071a9bb  0909                     or dword ptr [rcx], ecx
0071a9bd  0909                     or dword ptr [rcx], ecx
