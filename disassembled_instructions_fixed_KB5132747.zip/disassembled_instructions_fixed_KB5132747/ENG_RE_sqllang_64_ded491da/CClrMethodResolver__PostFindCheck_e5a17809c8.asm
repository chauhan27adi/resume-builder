; CClrMethodResolver::PostFindCheck
; sqllang.dll, primary RVA 0x704d00, 692 bytes in 1 chunk(s)

; chunk at RVA 0x704d00 (692 bytes)
00704d00  4883ec58                 sub rsp, 0x58
00704d04  4c8bc9                   mov r9, rcx
00704d07  83fa0a                   cmp edx, 0xa
00704d0a  7508                     jne 0x704d14
00704d0c  8d42f7                   lea eax, [rdx - 9]
00704d0f  4883c458                 add rsp, 0x58
00704d13  c3                       ret
00704d14  448b5158                 mov r10d, dword ptr [rcx + 0x58]
00704d18  4183fa01                 cmp r10d, 1
00704d1c  0f8763020000             ja 0x704f85
00704d22  83fa09                   cmp edx, 9
00704d25  0f875a020000             ja 0x704f85
00704d2b  4863c2                   movsxd rax, edx
00704d2e  488d15cbb28fff           lea rdx, [rip - 0x704d35]
00704d35  8b8c828c4f7000           mov ecx, dword ptr [rdx + rax*4 + 0x704f8c]
00704d3c  4803ca                   add rcx, rdx
00704d3f  ffe1                     jmp rcx
00704d41  4d8b4110                 mov r8, qword ptr [r9 + 0x10]
00704d45  418bca                   mov ecx, r10d
00704d48  498b4018                 mov rax, qword ptr [r8 + 0x18]
00704d4c  488b9098000000           mov rdx, qword ptr [rax + 0x98]
00704d53  498b4028                 mov rax, qword ptr [r8 + 0x28]
00704d57  4889542438               mov qword ptr [rsp + 0x38], rdx
00704d5c  ba41000000               mov edx, 0x41
00704d61  4889442430               mov qword ptr [rsp + 0x30], rax
00704d66  498b4138                 mov rax, qword ptr [r9 + 0x38]
00704d6a  4889442428               mov qword ptr [rsp + 0x28], rax
00704d6f  448d4acf                 lea r9d, [rdx - 0x31]
00704d73  c74424200a000000         mov dword ptr [rsp + 0x20], 0xa
00704d7b  448d42c5                 lea r8d, [rdx - 0x3b]
00704d7f  e8ac050000               call 0x705330
00704d84  33c0                     xor eax, eax
00704d86  4883c458                 add rsp, 0x58
00704d8a  c3                       ret
00704d8b  498b5110                 mov rdx, qword ptr [r9 + 0x10]
00704d8f  41b84a000000             mov r8d, 0x4a
00704d95  488b4218                 mov rax, qword ptr [rdx + 0x18]
00704d99  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
00704d9f  488b8098000000           mov rax, qword ptr [rax + 0x98]
00704da6  03c9                     add ecx, ecx
00704da8  4889442440               mov qword ptr [rsp + 0x40], rax
00704dad  488b4228                 mov rax, qword ptr [rdx + 0x28]
00704db1  894c2438                 mov dword ptr [rsp + 0x38], ecx
00704db5  4889442430               mov qword ptr [rsp + 0x30], rax
00704dba  498b4138                 mov rax, qword ptr [r9 + 0x38]
00704dbe  4889442428               mov qword ptr [rsp + 0x28], rax
00704dc3  c744242002000000         mov dword ptr [rsp + 0x20], 2
00704dcb  e9a3010000               jmp 0x704f73
00704dd0  498b5110                 mov rdx, qword ptr [r9 + 0x10]
00704dd4  41b846000000             mov r8d, 0x46
00704dda  488b4218                 mov rax, qword ptr [rdx + 0x18]
00704dde  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
00704de4  488b8098000000           mov rax, qword ptr [rax + 0x98]
00704deb  03c9                     add ecx, ecx
00704ded  4889442440               mov qword ptr [rsp + 0x40], rax
00704df2  488b4228                 mov rax, qword ptr [rdx + 0x28]
00704df6  894c2438                 mov dword ptr [rsp + 0x38], ecx
00704dfa  4889442430               mov qword ptr [rsp + 0x30], rax
00704dff  498b4138                 mov rax, qword ptr [r9 + 0x38]
00704e03  4889442428               mov qword ptr [rsp + 0x28], rax
00704e08  c744242002000000         mov dword ptr [rsp + 0x20], 2
00704e10  e95e010000               jmp 0x704f73
00704e15  498b5110                 mov rdx, qword ptr [r9 + 0x10]
00704e19  41b849000000             mov r8d, 0x49
00704e1f  488b4218                 mov rax, qword ptr [rdx + 0x18]
00704e23  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
00704e29  488b8098000000           mov rax, qword ptr [rax + 0x98]
00704e30  03c9                     add ecx, ecx
00704e32  4889442440               mov qword ptr [rsp + 0x40], rax
00704e37  488b4228                 mov rax, qword ptr [rdx + 0x28]
00704e3b  894c2438                 mov dword ptr [rsp + 0x38], ecx
00704e3f  4889442430               mov qword ptr [rsp + 0x30], rax
00704e44  498b4138                 mov rax, qword ptr [r9 + 0x38]
00704e48  4889442428               mov qword ptr [rsp + 0x28], rax
00704e4d  c744242002000000         mov dword ptr [rsp + 0x20], 2
00704e55  e919010000               jmp 0x704f73
00704e5a  498b5110                 mov rdx, qword ptr [r9 + 0x10]
00704e5e  41b817000000             mov r8d, 0x17
00704e64  488b4218                 mov rax, qword ptr [rdx + 0x18]
00704e68  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
00704e6e  488b8098000000           mov rax, qword ptr [rax + 0x98]
00704e75  03c9                     add ecx, ecx
00704e77  4889442440               mov qword ptr [rsp + 0x40], rax
00704e7c  488b4228                 mov rax, qword ptr [rdx + 0x28]
00704e80  894c2438                 mov dword ptr [rsp + 0x38], ecx
00704e84  4889442430               mov qword ptr [rsp + 0x30], rax
00704e89  498b4138                 mov rax, qword ptr [r9 + 0x38]
00704e8d  4889442428               mov qword ptr [rsp + 0x28], rax
00704e92  c744242002000000         mov dword ptr [rsp + 0x20], 2
00704e9a  e9d4000000               jmp 0x704f73
00704e9f  498b5138                 mov rdx, qword ptr [r9 + 0x38]
00704ea3  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
00704eaa  660f1f440000             nop word ptr [rax + rax]
00704eb0  48ffc1                   inc rcx
00704eb3  66833c4a00               cmp word ptr [rdx + rcx*2], 0
00704eb8  75f6                     jne 0x704eb0
00704eba  418b4178                 mov eax, dword ptr [r9 + 0x78]
00704ebe  03c9                     add ecx, ecx
00704ec0  89442438                 mov dword ptr [rsp + 0x38], eax
00704ec4  4889542430               mov qword ptr [rsp + 0x30], rdx
00704ec9  ba01000000               mov edx, 1
00704ece  894c2428                 mov dword ptr [rsp + 0x28], ecx
00704ed2  418bca                   mov ecx, r10d
00704ed5  c744242001000000         mov dword ptr [rsp + 0x20], 1
00704edd  448d4a0e                 lea r9d, [rdx + 0xe]
00704ee1  448d4249                 lea r8d, [rdx + 0x49]
00704ee5  e846040000               call 0x705330
00704eea  33c0                     xor eax, eax
00704eec  4883c458                 add rsp, 0x58
00704ef0  c3                       ret
00704ef1  498b5110                 mov rdx, qword ptr [r9 + 0x10]
00704ef5  41b848000000             mov r8d, 0x48
00704efb  488b4218                 mov rax, qword ptr [rdx + 0x18]
00704eff  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
00704f05  488b8098000000           mov rax, qword ptr [rax + 0x98]
00704f0c  03c9                     add ecx, ecx
00704f0e  4889442440               mov qword ptr [rsp + 0x40], rax
00704f13  488b4228                 mov rax, qword ptr [rdx + 0x28]
00704f17  894c2438                 mov dword ptr [rsp + 0x38], ecx
00704f1b  4889442430               mov qword ptr [rsp + 0x30], rax
00704f20  498b4138                 mov rax, qword ptr [r9 + 0x38]
00704f24  4889442428               mov qword ptr [rsp + 0x28], rax
00704f29  c744242001000000         mov dword ptr [rsp + 0x20], 1
00704f31  eb40                     jmp 0x704f73
00704f33  498b5110                 mov rdx, qword ptr [r9 + 0x10]
00704f37  41b82f000000             mov r8d, 0x2f
00704f3d  488b4218                 mov rax, qword ptr [rdx + 0x18]
00704f41  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
00704f47  488b8098000000           mov rax, qword ptr [rax + 0x98]
00704f4e  03c9                     add ecx, ecx
00704f50  4889442440               mov qword ptr [rsp + 0x40], rax
00704f55  488b4228                 mov rax, qword ptr [rdx + 0x28]
00704f59  894c2438                 mov dword ptr [rsp + 0x38], ecx
00704f5d  4889442430               mov qword ptr [rsp + 0x30], rax
00704f62  498b4138                 mov rax, qword ptr [r9 + 0x38]
00704f66  4889442428               mov qword ptr [rsp + 0x28], rax
00704f6b  c74424200c000000         mov dword ptr [rsp + 0x20], 0xc
00704f73  41b910000000             mov r9d, 0x10
00704f79  418bca                   mov ecx, r10d
00704f7c  418d5131                 lea edx, [r9 + 0x31]
00704f80  e8ab030000               call 0x705330
00704f85  33c0                     xor eax, eax
00704f87  4883c458                 add rsp, 0x58
00704f8b  c3                       ret
00704f8c  414d7000                 jo 0x704f90
00704f90  8b4d70                   mov ecx, dword ptr [rbp + 0x70]
00704f93  00d0                     add al, dl
00704f95  4d7000                   jo 0x704f98
00704f98  154e70005a               adc eax, 0x5a00704e
00704f9d  4e7000                   jo 0x704fa0
00704fa0  9f                       lahf
00704fa1  4e7000                   jo 0x704fa4
00704fa4  f1                       int1
00704fa5  4e7000                   jo 0x704fa8
00704fa8  854f70                   test dword ptr [rdi + 0x70], ecx
00704fab  0033                     add byte ptr [rbx], dh
00704fad  4f7000                   jo 0x704fb0
00704fb0  334f70                   xor ecx, dword ptr [rdi + 0x70]
