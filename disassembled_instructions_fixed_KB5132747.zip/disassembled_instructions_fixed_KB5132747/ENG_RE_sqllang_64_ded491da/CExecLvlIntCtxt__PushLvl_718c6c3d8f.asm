; CExecLvlIntCtxt::PushLvl
; sqllang.dll, primary RVA 0xdd7b60, 202 bytes in 1 chunk(s)

; chunk at RVA 0xdd7b60 (202 bytes)
00dd7b60  4057                     push rdi
00dd7b62  4883ec40                 sub rsp, 0x40
00dd7b66  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
00dd7b6f  48895c2468               mov qword ptr [rsp + 0x68], rbx
00dd7b74  488bd9                   mov rbx, rcx
00dd7b77  c7442450a2040000         mov dword ptr [rsp + 0x50], 0x4a2
00dd7b7f  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00dd7b88  488b05e9330f01           mov rax, qword ptr [rip + 0x10f33e9]
00dd7b8f  8b10                     mov edx, dword ptr [rax]
00dd7b91  488b05e8330f01           mov rax, qword ptr [rip + 0x10f33e8]
00dd7b98  8b38                     mov edi, dword ptr [rax]
00dd7b9a  49033cd0                 add rdi, qword ptr [r8 + rdx*8]
00dd7b9e  488b9700010000           mov rdx, qword ptr [rdi + 0x100]
00dd7ba5  4885d2                   test rdx, rdx
00dd7ba8  750f                     jne 0xdd7bb9
00dd7baa  33c9                     xor ecx, ecx
00dd7bac  ff15de330f01             call qword ptr [rip + 0x10f33de]
00dd7bb2  488b9700010000           mov rdx, qword ptr [rdi + 0x100]
00dd7bb9  488b92e8030000           mov rdx, qword ptr [rdx + 0x3e8]
00dd7bc0  4889542458               mov qword ptr [rsp + 0x58], rdx
00dd7bc5  c644242003               mov byte ptr [rsp + 0x20], 3
00dd7bca  41b9a2040000             mov r9d, 0x4a2
00dd7bd0  4c8d0521f42301           lea r8, [rip + 0x123f421]
00dd7bd7  b930000000               mov ecx, 0x30
00dd7bdc  ff15ce320f01             call qword ptr [rip + 0x10f32ce]
00dd7be2  4889442460               mov qword ptr [rsp + 0x60], rax
00dd7be7  4885c0                   test rax, rax
00dd7bea  742a                     je 0xdd7c16
00dd7bec  488b8bf0010000           mov rcx, qword ptr [rbx + 0x1f0]
00dd7bf3  0f57c0                   xorps xmm0, xmm0
00dd7bf6  0f1100                   movups xmmword ptr [rax], xmm0
00dd7bf9  0f114010                 movups xmmword ptr [rax + 0x10], xmm0
00dd7bfd  0f114020                 movups xmmword ptr [rax + 0x20], xmm0
00dd7c01  488908                   mov qword ptr [rax], rcx
00dd7c04  488983f0010000           mov qword ptr [rbx + 0x1f0], rax
00dd7c0b  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
00dd7c10  4883c440                 add rsp, 0x40
00dd7c14  5f                       pop rdi
00dd7c15  c3                       ret
00dd7c16  33d2                     xor edx, edx
00dd7c18  488993f0010000           mov qword ptr [rbx + 0x1f0], rdx
00dd7c1f  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
00dd7c24  4883c440                 add rsp, 0x40
00dd7c28  5f                       pop rdi
00dd7c29  c3                       ret
