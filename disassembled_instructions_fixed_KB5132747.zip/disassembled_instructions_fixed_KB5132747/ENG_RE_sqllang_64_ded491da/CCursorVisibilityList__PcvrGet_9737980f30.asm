; CCursorVisibilityList::PcvrGet
; sqllang.dll, primary RVA 0x44480, 453 bytes in 1 chunk(s)

; chunk at RVA 0x44480 (453 bytes)
00044480  4489442418               mov dword ptr [rsp + 0x18], r8d
00044485  4889542410               mov qword ptr [rsp + 0x10], rdx
0004448a  53                       push rbx
0004448b  55                       push rbp
0004448c  56                       push rsi
0004448d  57                       push rdi
0004448e  4154                     push r12
00044490  4155                     push r13
00044492  4156                     push r14
00044494  4157                     push r15
00044496  4883ec78                 sub rsp, 0x78
0004449a  48c7442450feffffff       mov qword ptr [rsp + 0x50], 0xfffffffffffffffe
000444a3  418bf9                   mov edi, r9d
000444a6  418bf0                   mov esi, r8d
000444a9  4c8bf1                   mov r14, rcx
000444ac  33ed                     xor ebp, ebp
000444ae  396924                   cmp dword ptr [rcx + 0x24], ebp
000444b1  0f850ca35700             jne 0x5be7c3
000444b7  65488b142558000000       mov rdx, qword ptr gs:[0x58]
000444c0  488b05b16ae801           mov rax, qword ptr [rip + 0x1e86ab1]
000444c7  8b08                     mov ecx, dword ptr [rax]
000444c9  488b05b06ae801           mov rax, qword ptr [rip + 0x1e86ab0]
000444d0  8b00                     mov eax, dword ptr [rax]
000444d2  480304ca                 add rax, qword ptr [rdx + rcx*8]
000444d6  488b00                   mov rax, qword ptr [rax]
000444d9  488b4878                 mov rcx, qword ptr [rax + 0x78]
000444dd  448bb91c010000           mov r15d, dword ptr [rcx + 0x11c]
000444e4  41ffc7                   inc r15d
000444e7  488d0582c80102           lea rax, [rip + 0x201c882]
000444ee  4889442458               mov qword ptr [rsp + 0x58], rax
000444f3  48896c2460               mov qword ptr [rsp + 0x60], rbp
000444f8  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00044501  488b05706ae801           mov rax, qword ptr [rip + 0x1e86a70]
00044508  8b08                     mov ecx, dword ptr [rax]
0004450a  488b056f6ae801           mov rax, qword ptr [rip + 0x1e86a6f]
00044511  8b00                     mov eax, dword ptr [rax]
00044513  480304ca                 add rax, qword ptr [rdx + rcx*8]
00044517  488b00                   mov rax, qword ptr [rax]
0004451a  488b8880000000           mov rcx, qword ptr [rax + 0x80]
00044521  448ba10c020000           mov r12d, dword ptr [rcx + 0x20c]
00044528  4489a424d8000000         mov dword ptr [rsp + 0xd8], r12d
00044530  4c89742460               mov qword ptr [rsp + 0x60], r14
00044535  498bce                   mov rcx, r14
00044538  e8a32bfcff               call 0x70e0
0004453d  498b5e08                 mov rbx, qword ptr [r14 + 8]
00044541  493bde                   cmp rbx, r14
00044544  480f44dd                 cmove rbx, rbp
00044548  85ff                     test edi, edi
0004454a  0f857ca25700             jne 0x5be7cc
00044550  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00044559  488b05186ae801           mov rax, qword ptr [rip + 0x1e86a18]
00044560  8b08                     mov ecx, dword ptr [rax]
00044562  488b05176ae801           mov rax, qword ptr [rip + 0x1e86a17]
00044569  8b00                     mov eax, dword ptr [rax]
0004456b  480304ca                 add rax, qword ptr [rdx + rcx*8]
0004456f  488b00                   mov rax, qword ptr [rax]
00044572  488b88a0000000           mov rcx, qword ptr [rax + 0xa0]
00044579  f6412d02                 test byte ptr [rcx + 0x2d], 2
0004457d  0f855ba25700             jne 0x5be7de
00044583  ff154776e801             call qword ptr [rip + 0x1e87647]
00044589  488bc8                   mov rcx, rax
0004458c  48898c24c0000000         mov qword ptr [rsp + 0xc0], rcx
00044594  4885db                   test rbx, rbx
00044597  747d                     je 0x44616
00044599  488bbc24c8000000         mov rdi, qword ptr [rsp + 0xc8]
000445a1  0f1f4000                 nop dword ptr [rax]
000445a5  6666660f1f840000000000   nop word ptr [rax + rax]
000445b0  4885ed                   test rbp, rbp
000445b3  0f8532a25700             jne 0x5be7eb
000445b9  41837e2400               cmp dword ptr [r14 + 0x24], 0
000445be  7509                     jne 0x445c9
000445c0  4439a330010000           cmp dword ptr [rbx + 0x130], r12d
000445c7  7540                     jne 0x44609
000445c9  4439bb1c010000           cmp dword ptr [rbx + 0x11c], r15d
000445d0  7537                     jne 0x44609
000445d2  448ba318010000           mov r12d, dword ptr [rbx + 0x118]
000445d9  4c8d6b18                 lea r13, [rbx + 0x18]
000445dd  4489642420               mov dword ptr [rsp + 0x20], r12d
000445e2  4d8bcd                   mov r9, r13
000445e5  448bc6                   mov r8d, esi
000445e8  488bd7                   mov rdx, rdi
000445eb  ff15f777e801             call qword ptr [rip + 0x1e877f7]
000445f1  85c0                     test eax, eax
000445f3  750c                     jne 0x44601
000445f5  4885ed                   test rbp, rbp
000445f8  0f8505a25700             jne 0x5be803
000445fe  488beb                   mov rbp, rbx
00044601  448ba424d8000000         mov r12d, dword ptr [rsp + 0xd8]
00044609  488b5b08                 mov rbx, qword ptr [rbx + 8]
0004460d  493bde                   cmp rbx, r14
00044610  0f8558a25700             jne 0x5be86e
00044616  488d0553c70102           lea rax, [rip + 0x201c753]
0004461d  4889442458               mov qword ptr [rsp + 0x58], rax
00044622  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
00044627  4885c9                   test rcx, rcx
0004462a  7405                     je 0x44631
0004462c  e8ff2afcff               call 0x7130
00044631  488bc5                   mov rax, rbp
00044634  4883c478                 add rsp, 0x78
00044638  415f                     pop r15
0004463a  415e                     pop r14
0004463c  415d                     pop r13
0004463e  415c                     pop r12
00044640  5f                       pop rdi
00044641  5e                       pop rsi
00044642  5d                       pop rbp
00044643  5b                       pop rbx
00044644  c3                       ret
