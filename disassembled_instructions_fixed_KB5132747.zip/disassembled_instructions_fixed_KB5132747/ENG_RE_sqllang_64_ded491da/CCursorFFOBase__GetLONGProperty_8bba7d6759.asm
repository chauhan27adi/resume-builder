; CCursorFFOBase::GetLONGProperty
; sqllang.dll, primary RVA 0x4cd70, 52 bytes in 1 chunk(s)

; chunk at RVA 0x4cd70 (52 bytes)
0004cd70  4053                     push rbx
0004cd72  4883ec20                 sub rsp, 0x20
0004cd76  448bc2                   mov r8d, edx
0004cd79  488bd9                   mov rbx, rcx
0004cd7c  4183e814                 sub r8d, 0x14
0004cd80  0f845ad55600             je 0x5ba2e0
0004cd86  4183e801                 sub r8d, 1
0004cd8a  0f8445d55600             je 0x5ba2d5
0004cd90  4183f806                 cmp r8d, 6
0004cd94  0f848b000000             je 0x4ce25
0004cd9a  4883c420                 add rsp, 0x20
0004cd9e  5b                       pop rbx
0004cd9f  e95c74ffff               jmp 0x44200
