; CExecStatsCollection::AggAndDelExecStats
; sqllang.dll, primary RVA 0x25cb0, 433 bytes in 5 chunk(s)

; chunk at RVA 0x25cb0 (26 bytes)
00025cb0  4055                     push rbp
00025cb2  56                       push rsi
00025cb3  4154                     push r12
00025cb5  4157                     push r15
00025cb7  4883ec38                 sub rsp, 0x38
00025cbb  658b042548000000         mov eax, dword ptr gs:[0x48]
00025cc3  488db170060000           lea rsi, [rcx + 0x670]

; chunk at RVA 0x25cca (56 bytes)
00025cca  48895c2430               mov qword ptr [rsp + 0x30], rbx
00025ccf  4533e4                   xor r12d, r12d
00025cd2  4c89742420               mov qword ptr [rsp + 0x20], r14
00025cd7  488bea                   mov rbp, rdx
00025cda  448bf0                   mov r14d, eax
00025cdd  4c8bf9                   mov r15, rcx
00025ce0  8b06                     mov eax, dword ptr [rsi]
00025ce2  418bdc                   mov ebx, r12d
00025ce5  85c0                     test eax, eax
00025ce7  0f859344d300             jne 0xd5a180
00025ced  33c0                     xor eax, eax
00025cef  f04c0fb136               lock cmpxchg qword ptr [rsi], r14
00025cf4  418bc4                   mov eax, r12d
00025cf7  0f94c0                   sete al
00025cfa  85c0                     test eax, eax
00025cfc  0f847e44d300             je 0xd5a180

; chunk at RVA 0x25d02 (61 bytes)
00025d02  488b8560060000           mov rax, qword ptr [rbp + 0x660]
00025d09  488b8d68060000           mov rcx, qword ptr [rbp + 0x668]
00025d10  4c8b742420               mov r14, qword ptr [rsp + 0x20]
00025d15  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00025d1a  48894808                 mov qword ptr [rax + 8], rcx
00025d1e  488901                   mov qword ptr [rcx], rax
00025d21  488b05a048ea01           mov rax, qword ptr [rip + 0x1ea48a0]
00025d28  4c89a568060000           mov qword ptr [rbp + 0x668], r12
00025d2f  4c89a560060000           mov qword ptr [rbp + 0x660], r12
00025d36  443820                   cmp byte ptr [rax], r12b
00025d39  0f853845d300             jne 0xd5a277

; chunk at RVA 0xd5a187 (240 bytes)
00d5a187  48897c2428               mov qword ptr [rsp + 0x28], rdi
00d5a18c  498bfc                   mov rdi, r12
00d5a18f  8b08                     mov ecx, dword ptr [rax]
00d5a191  81e184000000             and ecx, 0x84
00d5a197  80f984                   cmp cl, 0x84
00d5a19a  7555                     jne 0xd5a1f1
00d5a19c  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00d5a1a5  488b05cc0d1701           mov rax, qword ptr [rip + 0x1170dcc]
00d5a1ac  8b08                     mov ecx, dword ptr [rax]
00d5a1ae  488b05cb0d1701           mov rax, qword ptr [rip + 0x1170dcb]
00d5a1b5  448b00                   mov r8d, dword ptr [rax]
00d5a1b8  4c0304ca                 add r8, qword ptr [rdx + rcx*8]
00d5a1bc  7410                     je 0xd5a1ce
00d5a1be  4d398010010000           cmp qword ptr [r8 + 0x110], r8
00d5a1c5  7507                     jne 0xd5a1ce
00d5a1c7  498bb800010000           mov rdi, qword ptr [r8 + 0x100]
00d5a1ce  4885ff                   test rdi, rdi
00d5a1d1  741e                     je 0xd5a1f1
00d5a1d3  488b050e041701           mov rax, qword ptr [rip + 0x117040e]
00d5a1da  3918                     cmp dword ptr [rax], ebx
00d5a1dc  7477                     je 0xd5a255
00d5a1de  488d4c2460               lea rcx, [rsp + 0x60]
00d5a1e3  ff153ff31601             call qword ptr [rip + 0x116f33f]
00d5a1e9  488b5c2460               mov rbx, qword ptr [rsp + 0x60]
00d5a1ee  eb01                     jmp 0xd5a1f1
00d5a1f0  cc                       int3
00d5a1f1  488b0578021701           mov rax, qword ptr [rip + 0x1170278]
00d5a1f8  488bce                   mov rcx, rsi
00d5a1fb  4438a0c7000000           cmp byte ptr [rax + 0xc7], r12b
00d5a202  7d5c                     jge 0xd5a260
00d5a204  4d8bc6                   mov r8, r14
00d5a207  488bd7                   mov rdx, rdi
00d5a20a  e8d187dcff               call 0xb229e0
00d5a20f  eb01                     jmp 0xd5a212
00d5a211  cc                       int3
00d5a212  4885ff                   test rdi, rdi
00d5a215  7433                     je 0xd5a24a
00d5a217  488b05ca031701           mov rax, qword ptr [rip + 0x11703ca]
00d5a21e  443920                   cmp dword ptr [rax], r12d
00d5a221  7449                     je 0xd5a26c
00d5a223  488d4c2468               lea rcx, [rsp + 0x68]
00d5a228  ff15faf21601             call qword ptr [rip + 0x116f2fa]
00d5a22e  488b442468               mov rax, qword ptr [rsp + 0x68]
00d5a233  eb01                     jmp 0xd5a236
00d5a235  cc                       int3
00d5a236  488bc8                   mov rcx, rax
00d5a239  482bcb                   sub rcx, rbx
00d5a23c  483bc3                   cmp rax, rbx
00d5a23f  490f42cc                 cmovb rcx, r12
00d5a243  48018f780c0000           add qword ptr [rdi + 0xc78], rcx
00d5a24a  488b7c2428               mov rdi, qword ptr [rsp + 0x28]
00d5a24f  e9aeba2cff               jmp 0x25d02
00d5a254  cc                       int3
00d5a255  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
00d5a25d  eb92                     jmp 0xd5a1f1
00d5a25f  cc                       int3
00d5a260  498bd6                   mov rdx, r14
00d5a263  e89889dcff               call 0xb22c00
00d5a268  90                       nop
00d5a269  eba7                     jmp 0xd5a212
00d5a26b  cc                       int3
00d5a26c  488b04250800fe7f         mov rax, qword ptr [0x7ffe0008]
00d5a274  ebc0                     jmp 0xd5a236
00d5a276  cc                       int3

; chunk at RVA 0xd5a277 (50 bytes)
00d5a277  ff15732b1701             call qword ptr [rip + 0x1172b73]
00d5a27d  448bc0                   mov r8d, eax
00d5a280  b867666666               mov eax, 0x66666667
00d5a285  41f7e8                   imul r8d
00d5a288  d1fa                     sar edx, 1
00d5a28a  8bca                     mov ecx, edx
00d5a28c  c1e91f                   shr ecx, 0x1f
00d5a28f  03d1                     add edx, ecx
00d5a291  8d0c92                   lea ecx, [rdx + rdx*4]
00d5a294  443bc1                   cmp r8d, ecx
00d5a297  0f85a2ba2cff             jne 0x25d3f
00d5a29d  e8ce8bdcff               call 0xb22e70
00d5a2a2  90                       nop
00d5a2a3  e997ba2cff               jmp 0x25d3f
00d5a2a8  cc                       int3
