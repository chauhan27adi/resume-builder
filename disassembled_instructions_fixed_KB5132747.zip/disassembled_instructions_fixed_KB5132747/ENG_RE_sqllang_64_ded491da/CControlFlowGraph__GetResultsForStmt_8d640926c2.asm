; CControlFlowGraph::GetResultsForStmt
; sqllang.dll, primary RVA 0xdffd80, 810 bytes in 5 chunk(s)

; chunk at RVA 0xdffd80 (382 bytes)
00dffd80  48896c2420               mov qword ptr [rsp + 0x20], rbp
00dffd85  56                       push rsi
00dffd86  4156                     push r14
00dffd88  4157                     push r15
00dffd8a  4883ec50                 sub rsp, 0x50
00dffd8e  4c8bf9                   mov r15, rcx
00dffd91  498bf1                   mov rsi, r9
00dffd94  488bca                   mov rcx, rdx
00dffd97  4d8bf0                   mov r14, r8
00dffd9a  488bea                   mov rbp, rdx
00dffd9d  e8eeecffff               call 0xdfea90
00dffda2  a801                     test al, 1
00dffda4  0f8488000000             je 0xdffe32
00dffdaa  8b4548                   mov eax, dword ptr [rbp + 0x48]
00dffdad  3d76010000               cmp eax, 0x176
00dffdb2  7f5c                     jg 0xdffe10
00dffdb4  7427                     je 0xdffddd
00dffdb6  83e829                   sub eax, 0x29
00dffdb9  3dd1000000               cmp eax, 0xd1
00dffdbe  7750                     ja 0xdffe10
00dffdc0  488d15390220ff           lea rdx, [rip - 0xdffdc7]
00dffdc7  4898                     cdqe
00dffdc9  0fb68402d8ffdf00         movzx eax, byte ptr [rdx + rax + 0xdfffd8]
00dffdd1  8b8c82d0ffdf00           mov ecx, dword ptr [rdx + rax*4 + 0xdfffd0]
00dffdd8  4803ca                   add rcx, rdx
00dffddb  ffe1                     jmp rcx
00dffddd  488bce                   mov rcx, rsi
00dffde0  e86bcaffff               call 0xdfc850
00dffde5  804e3202                 or byte ptr [rsi + 0x32], 2
00dffde9  488d4e48                 lea rcx, [rsi + 0x48]
00dffded  4d8bc6                   mov r8, r14
00dffdf0  c7465808000000           mov dword ptr [rsi + 0x58], 8
00dffdf7  488bd5                   mov rdx, rbp
00dffdfa  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dffe02  4883c450                 add rsp, 0x50
00dffe06  415f                     pop r15
00dffe08  415e                     pop r14
00dffe0a  5e                       pop rsi
00dffe0b  e910bfffff               jmp 0xdfbd20
00dffe10  4c8bce                   mov r9, rsi
00dffe13  4d8bc6                   mov r8, r14
00dffe16  488bd5                   mov rdx, rbp
00dffe19  498bcf                   mov rcx, r15
00dffe1c  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dffe24  4883c450                 add rsp, 0x50
00dffe28  415f                     pop r15
00dffe2a  415e                     pop r14
00dffe2c  5e                       pop rsi
00dffe2d  e91eeeffff               jmp 0xdfec50
00dffe32  a802                     test al, 2
00dffe34  0f847c010000             je 0xdfffb6
00dffe3a  8b4548                   mov eax, dword ptr [rbp + 0x48]
00dffe3d  83f821                   cmp eax, 0x21
00dffe40  0f8455010000             je 0xdfff9b
00dffe46  3de0000000               cmp eax, 0xe0
00dffe4b  0f849e000000             je 0xdffeef
00dffe51  3d75010000               cmp eax, 0x175
00dffe56  7460                     je 0xdffeb8
00dffe58  488bcd                   mov rcx, rbp
00dffe5b  e810b5f3ff               call 0xd3b370
00dffe60  84c0                     test al, al
00dffe62  7422                     je 0xdffe86
00dffe64  4c8bce                   mov r9, rsi
00dffe67  4d8bc6                   mov r8, r14
00dffe6a  488bd5                   mov rdx, rbp
00dffe6d  498bcf                   mov rcx, r15
00dffe70  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dffe78  4883c450                 add rsp, 0x50
00dffe7c  415f                     pop r15
00dffe7e  415e                     pop r14
00dffe80  5e                       pop rsi
00dffe81  e95af2ffff               jmp 0xdff0e0
00dffe86  488bcd                   mov rcx, rbp
00dffe89  e832c943ff               call 0x23c7c0
00dffe8e  84c0                     test al, al
00dffe90  0f8420010000             je 0xdfffb6
00dffe96  4c8bce                   mov r9, rsi
00dffe99  4d8bc6                   mov r8, r14
00dffe9c  488bd5                   mov rdx, rbp
00dffe9f  498bcf                   mov rcx, r15
00dffea2  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dffeaa  4883c450                 add rsp, 0x50
00dffeae  415f                     pop r15
00dffeb0  415e                     pop r14
00dffeb2  5e                       pop rsi
00dffeb3  e9a8f7ffff               jmp 0xdff660
00dffeb8  488b4518                 mov rax, qword ptr [rbp + 0x18]
00dffebc  83b8b008000001           cmp dword ptr [rax + 0x8b0], 1
00dffec3  0f84ed000000             je 0xdfffb6
00dffec9  488b80a0080000           mov rax, qword ptr [rax + 0x8a0]
00dffed0  488b4820                 mov rcx, qword ptr [rax + 0x20]
00dffed4  488b01                   mov rax, qword ptr [rcx]
00dffed7  488b4810                 mov rcx, qword ptr [rax + 0x10]
00dffedb  488b01                   mov rax, qword ptr [rcx]
00dffede  ff5018                   call qword ptr [rax + 0x18]
00dffee1  83f862                   cmp eax, 0x62
00dffee4  0f84cc000000             je 0xdfffb6
00dffeea  e9eefeffff               jmp 0xdffddd
00dffeef  498b0f                   mov rcx, qword ptr [r15]
00dffef2  33c0                     xor eax, eax
00dffef4  4889442440               mov qword ptr [rsp + 0x40], rax
00dffef9  6689442448               mov word ptr [rsp + 0x48], ax

; chunk at RVA 0xdffefe (28 bytes)
00dffefe  4c89a42480000000         mov qword ptr [rsp + 0x80], r12
00dfff06  8b4120                   mov eax, dword ptr [rcx + 0x20]
00dfff09  4c8b6518                 mov r12, qword ptr [rbp + 0x18]
00dfff0d  c1e803                   shr eax, 3
00dfff10  a801                     test al, 1
00dfff12  743d                     je 0xdfff51
00dfff14  488b01                   mov rax, qword ptr [rcx]
00dfff17  498bd6                   mov rdx, r14

; chunk at RVA 0xdfff1a (55 bytes)
00dfff1a  48895c2470               mov qword ptr [rsp + 0x70], rbx
00dfff1f  8b99dc040000             mov ebx, dword ptr [rcx + 0x4dc]
00dfff25  48897c2478               mov qword ptr [rsp + 0x78], rdi
00dfff2a  0fb7b9e8040000           movzx edi, word ptr [rcx + 0x4e8]
00dfff31  ff9070010000             call qword ptr [rax + 0x170]
00dfff37  0fb7c0                   movzx eax, ax
00dfff3a  895c2444                 mov dword ptr [rsp + 0x44], ebx
00dfff3e  488b5c2470               mov rbx, qword ptr [rsp + 0x70]
00dfff43  66897c2448               mov word ptr [rsp + 0x48], di
00dfff48  488b7c2478               mov rdi, qword ptr [rsp + 0x78]
00dfff4d  89442440                 mov dword ptr [rsp + 0x40], eax

; chunk at RVA 0xdfff51 (62 bytes)
00dfff51  4d8b1424                 mov r10, qword ptr [r12]
00dfff55  488d442440               lea rax, [rsp + 0x40]
00dfff5a  4d8b4708                 mov r8, qword ptr [r15 + 8]
00dfff5e  4d8bce                   mov r9, r14
00dfff61  4889742430               mov qword ptr [rsp + 0x30], rsi
00dfff66  488bd5                   mov rdx, rbp
00dfff69  4889442428               mov qword ptr [rsp + 0x28], rax
00dfff6e  498bcc                   mov rcx, r12
00dfff71  498b4718                 mov rax, qword ptr [r15 + 0x18]
00dfff75  4889442420               mov qword ptr [rsp + 0x20], rax
00dfff7a  41ff9248020000           call qword ptr [r10 + 0x248]
00dfff81  f6463208                 test byte ptr [rsi + 0x32], 8
00dfff85  4c8ba42480000000         mov r12, qword ptr [rsp + 0x80]
00dfff8d  742f                     je 0xdfffbe

; chunk at RVA 0xdfff8f (283 bytes)
00dfff8f  41f687b001000008         test byte ptr [r15 + 0x1b0], 8
00dfff97  7425                     je 0xdfffbe
00dfff99  eb1b                     jmp 0xdfffb6
00dfff9b  488b4518                 mov rax, qword ptr [rbp + 0x18]
00dfff9f  4883b8d808000000         cmp qword ptr [rax + 0x8d8], 0
00dfffa7  750d                     jne 0xdfffb6
00dfffa9  83b8e008000000           cmp dword ptr [rax + 0x8e0], 0
00dfffb0  0f8627feffff             jbe 0xdffddd
00dfffb6  488bce                   mov rcx, rsi
00dfffb9  e892c8ffff               call 0xdfc850
00dfffbe  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dfffc6  4883c450                 add rsp, 0x50
00dfffca  415f                     pop r15
00dfffcc  415e                     pop r14
00dfffce  5e                       pop rsi
00dfffcf  c3                       ret
