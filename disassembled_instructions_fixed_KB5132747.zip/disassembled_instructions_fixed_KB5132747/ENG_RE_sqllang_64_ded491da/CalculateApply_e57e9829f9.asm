; CalculateApply
; sqllang.dll, primary RVA 0x3203f0, 819 bytes in 10 chunk(s)

; chunk at RVA 0x285c72 (35 bytes)
00285c72  4889b42428010000         mov qword ptr [rsp + 0x128], rsi
00285c7a  4889bc2438010000         mov qword ptr [rsp + 0x138], rdi
00285c82  4c89bc24f0000000         mov qword ptr [rsp + 0xf0], r15
00285c8a  4533ff                   xor r15d, r15d
00285c8d  85db                     test ebx, ebx
00285c8f  0f85cdd33101             jne 0x15a3062

; chunk at RVA 0x3203f0 (80 bytes)
003203f0  488bc4                   mov rax, rsp
003203f3  4c894018                 mov qword ptr [rax + 0x18], r8
003203f7  55                       push rbp
003203f8  4155                     push r13
003203fa  488d68e8                 lea rbp, [rax - 0x18]
003203fe  4881ec08010000           sub rsp, 0x108
00320405  f20f10057bff8002         movsd xmm0, qword ptr [rip + 0x280ff7b]
0032040d  4c8d1574ff8002           lea r10, [rip + 0x280ff74]
00320414  f20f100dccff8002         movsd xmm1, qword ptr [rip + 0x280ffcc]
0032041c  4c8d05c5ff8002           lea r8, [rip + 0x280ffc5]
00320423  4c8b6d48                 mov r13, qword ptr [rbp + 0x48]
00320427  0f2970c8                 movaps xmmword ptr [rax - 0x38], xmm6
0032042b  0f57f6                   xorps xmm6, xmm6
0032042e  440f2940a8               movaps xmmword ptr [rax - 0x58], xmm8
00320433  450f57c0                 xorps xmm8, xmm8
00320437  440f295088               movaps xmmword ptr [rax - 0x78], xmm10
0032043c  450f57d2                 xorps xmm10, xmm10

; chunk at RVA 0x320440 (140 bytes)
00320440  48895808                 mov qword ptr [rax + 8], rbx
00320444  4c8960e8                 mov qword ptr [rax - 0x18], r12
00320448  4c8be2                   mov r12, rdx
0032044b  488b5558                 mov rdx, qword ptr [rbp + 0x58]
0032044f  4c8970e0                 mov qword ptr [rax - 0x20], r14
00320453  4d8bf1                   mov r14, r9
00320456  4c8b4d50                 mov r9, qword ptr [rbp + 0x50]
0032045a  0f2978b8                 movaps xmmword ptr [rax - 0x48], xmm7
0032045e  f20f101a                 movsd xmm3, qword ptr [rdx]
00320462  440f294898               movaps xmmword ptr [rax - 0x68], xmm9
00320467  488bc2                   mov rax, rdx
0032046a  f2410f1011               movsd xmm2, qword ptr [r9]
0032046f  660f2fc3                 comisd xmm0, xmm3
00320473  f20f114d58               movsd qword ptr [rbp + 0x58], xmm1
00320478  f2440f11442470           movsd qword ptr [rsp + 0x70], xmm8
0032047f  490f47c2                 cmova rax, r10
00320483  660f2fc2                 comisd xmm0, xmm2
00320487  f20f1038                 movsd xmm7, qword ptr [rax]
0032048b  498bc1                   mov rax, r9
0032048e  490f47c2                 cmova rax, r10
00320492  660f2fc9                 comisd xmm1, xmm1
00320496  f2440f1008               movsd xmm9, qword ptr [rax]
0032049b  488d4558                 lea rax, [rbp + 0x58]
0032049f  490f47c0                 cmova rax, r8
003204a3  66440f2fc1               comisd xmm8, xmm1
003204a8  f20f1000                 movsd xmm0, qword ptr [rax]
003204ac  488d442470               lea rax, [rsp + 0x70]
003204b1  f20f114588               movsd qword ptr [rbp - 0x78], xmm0
003204b6  490f47c0                 cmova rax, r8
003204ba  f20f1000                 movsd xmm0, qword ptr [rax]
003204be  f20f114590               movsd qword ptr [rbp - 0x70], xmm0
003204c3  83e901                   sub ecx, 1
003204c6  0f853457f6ff             jne 0x285c00

; chunk at RVA 0x3204cc (300 bytes)
003204cc  f20f1005c470cf01         movsd xmm0, qword ptr [rip + 0x1cf70c4]
003204d4  0f28f2                   movaps xmm6, xmm2
003204d7  f20f59f3                 mulsd xmm6, xmm3
003204db  660f2fc6                 comisd xmm0, xmm6
003204df  0f82a82c2801             jb 0x15a318d
003204e5  f20f1005b370cf01         movsd xmm0, qword ptr [rip + 0x1cf70b3]
003204ed  660f2ff0                 comisd xmm6, xmm0
003204f1  0f828d2c2801             jb 0x15a3184
003204f7  f2410f11b698000000       movsd qword ptr [r14 + 0x98], xmm6
00320500  4c8d4558                 lea r8, [rbp + 0x58]
00320504  f20f1002                 movsd xmm0, qword ptr [rdx]
00320508  488d4c2478               lea rcx, [rsp + 0x78]
0032050d  f2410f1009               movsd xmm1, qword ptr [r9]
00320512  488d5580                 lea rdx, [rbp - 0x80]
00320516  f20f114558               movsd qword ptr [rbp + 0x58], xmm0
0032051b  f20f114d80               movsd qword ptr [rbp - 0x80], xmm1
00320520  e8bb020000               call 0x3207e0
00320525  488b08                   mov rcx, qword ptr [rax]
00320528  49894d00                 mov qword ptr [r13], rcx
0032052c  41f60603                 test byte ptr [r14], 3
00320530  0f85cd000000             jne 0x320603
00320536  488b4560                 mov rax, qword ptr [rbp + 0x60]
0032053a  4c8d4c2478               lea r9, [rsp + 0x78]
0032053f  f2410f108680000000       movsd xmm0, qword ptr [r14 + 0x80]
00320548  488d542470               lea rdx, [rsp + 0x70]
0032054d  f2410f104e78             movsd xmm1, qword ptr [r14 + 0x78]
00320553  4d8b4668                 mov r8, qword ptr [r14 + 0x68]
00320557  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0032055b  4889442440               mov qword ptr [rsp + 0x40], rax
00320560  488d4558                 lea rax, [rbp + 0x58]
00320564  4889442438               mov qword ptr [rsp + 0x38], rax
00320569  488d4580                 lea rax, [rbp - 0x80]
0032056d  4889442430               mov qword ptr [rsp + 0x30], rax
00320572  498b4670                 mov rax, qword ptr [r14 + 0x70]
00320576  c744242830000000         mov dword ptr [rsp + 0x28], 0x30
0032057e  4889442420               mov qword ptr [rsp + 0x20], rax
00320583  f20f117d58               movsd qword ptr [rbp + 0x58], xmm7
00320588  f2440f114d80             movsd qword ptr [rbp - 0x80], xmm9
0032058e  f20f11442478             movsd qword ptr [rsp + 0x78], xmm0
00320594  f20f114c2470             movsd qword ptr [rsp + 0x70], xmm1
0032059a  e80127fbff               call 0x2d2ca0
0032059f  f2410f108680000000       movsd xmm0, qword ptr [r14 + 0x80]
003205a8  488d4558                 lea rax, [rbp + 0x58]
003205ac  f2410f104e78             movsd xmm1, qword ptr [r14 + 0x78]
003205b2  4c8d4c2478               lea r9, [rsp + 0x78]
003205b7  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
003205bb  4c8d442470               lea r8, [rsp + 0x70]
003205c0  4889442430               mov qword ptr [rsp + 0x30], rax
003205c5  498bd6                   mov rdx, r14
003205c8  488d4580                 lea rax, [rbp - 0x80]
003205cc  f20f117d58               movsd qword ptr [rbp + 0x58], xmm7
003205d1  4889442428               mov qword ptr [rsp + 0x28], rax
003205d6  c744242030000000         mov dword ptr [rsp + 0x20], 0x30
003205de  f2440f114d80             movsd qword ptr [rbp - 0x80], xmm9
003205e4  f20f11442478             movsd qword ptr [rsp + 0x78], xmm0
003205ea  f20f114c2470             movsd qword ptr [rsp + 0x70], xmm1
003205f0  e8db11fbff               call 0x2d17d0
003205f5  eb01                     jmp 0x3205f8
003205f7  cc                       int3

; chunk at RVA 0x3205f8 (63 bytes)
003205f8  4c8b4d50                 mov r9, qword ptr [rbp + 0x50]
003205fc  4c8d1585fd8002           lea r10, [rip + 0x280fd85]
00320603  48837d3000               cmp qword ptr [rbp + 0x30], 0
00320608  440f288c24b0000000       movaps xmm9, xmmword ptr [rsp + 0xb0]
00320611  0f28bc24d0000000         movaps xmm7, xmmword ptr [rsp + 0xd0]
00320619  4c8bb424f8000000         mov r14, qword ptr [rsp + 0xf8]
00320621  4c8ba42400010000         mov r12, qword ptr [rsp + 0x100]
00320629  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
00320631  0f85f12a2801             jne 0x15a3128

; chunk at RVA 0x320637 (59 bytes)
00320637  f2410f104500             movsd xmm0, qword ptr [r13]
0032063d  66440f2fd0               comisd xmm10, xmm0
00320642  0f87542b2801             ja 0x15a319c
00320648  660f2fc6                 comisd xmm0, xmm6
0032064c  b001                     mov al, 1
0032064e  0f87582b2801             ja 0x15a31ac
00320654  4c8d9c2408010000         lea r11, [rsp + 0x108]
0032065c  410f2873d8               movaps xmm6, xmmword ptr [r11 - 0x28]
00320661  450f2843b8               movaps xmm8, xmmword ptr [r11 - 0x48]
00320666  450f285398               movaps xmm10, xmmword ptr [r11 - 0x68]
0032066b  498be3                   mov rsp, r11
0032066e  415d                     pop r13
00320670  5d                       pop rbp
00320671  c3                       ret

; chunk at RVA 0x15a30f6 (19 bytes)
015a30f6  660f2ec0                 ucomisd xmm0, xmm0
015a30fa  0f8b59ffffff             jnp 0x15a3059
015a3100  0f57c0                   xorps xmm0, xmm0
015a3103  e9552bcefe               jmp 0x285c5d
015a3108  cc                       int3

; chunk at RVA 0x15a3109 (10 bytes)
015a3109  33d2                     xor edx, edx
015a310b  ebb6                     jmp 0x15a30c3
015a310d  cc                       int3
015a310e  33c9                     xor ecx, ecx
015a3110  ebcb                     jmp 0x15a30dd
015a3112  cc                       int3

; chunk at RVA 0x15a3113 (21 bytes)
015a3113  ba08000000               mov edx, 8
015a3118  488bcf                   mov rcx, rdi
015a311b  ff15677e9200             call qword ptr [rip + 0x927e67]
015a3121  90                       nop
015a3122  e9602ccefe               jmp 0x285d87
015a3127  cc                       int3

; chunk at RVA 0x15a3128 (92 bytes)
015a3128  66410f2ef0               ucomisd xmm6, xmm8
015a312d  0f8a04d5d7fe             jp 0x320637
015a3133  0f85fed4d7fe             jne 0x320637
015a3139  f2410f1009               movsd xmm1, qword ptr [r9]
015a313e  66410f2fc8               comisd xmm1, xmm8
015a3143  0f86eed4d7fe             jbe 0x320637
015a3149  f20f100537d25801         movsd xmm0, qword ptr [rip + 0x158d237]
015a3151  488d4550                 lea rax, [rbp + 0x50]
015a3155  660f2fc1                 comisd xmm0, xmm1
015a3159  f2410f104500             movsd xmm0, qword ptr [r13]
015a315f  f20f114d50               movsd qword ptr [rbp + 0x50], xmm1
015a3164  490f47c2                 cmova rax, r10
015a3168  f20f1010                 movsd xmm2, qword ptr [rax]
015a316c  b001                     mov al, 1
015a316e  660f2fc2                 comisd xmm0, xmm2
015a3172  0f86dcd4d7fe             jbe 0x320654
015a3178  f2410f115500             movsd qword ptr [r13], xmm2
015a317e  e9d1d4d7fe               jmp 0x320654
015a3183  cc                       int3
