; CDialogEndpoint::EnqueueError
; sqllang.dll, primary RVA 0x4c9ee0, 1464 bytes in 1 chunk(s)

; chunk at RVA 0x4c9ee0 (1464 bytes)
004c9ee0  488bc4                   mov rax, rsp
004c9ee3  55                       push rbp
004c9ee4  4154                     push r12
004c9ee6  4155                     push r13
004c9ee8  4156                     push r14
004c9eea  4157                     push r15
004c9eec  488d6c2480               lea rbp, [rsp - 0x80]
004c9ef1  4881ec80010000           sub rsp, 0x180
004c9ef8  48c74500feffffff         mov qword ptr [rbp], 0xfffffffffffffffe
004c9f00  48895810                 mov qword ptr [rax + 0x10], rbx
004c9f04  48897018                 mov qword ptr [rax + 0x18], rsi
004c9f08  48897820                 mov qword ptr [rax + 0x20], rdi
004c9f0c  488b0575ed6002           mov rax, qword ptr [rip + 0x260ed75]
004c9f13  4833c4                   xor rax, rsp
004c9f16  48894570                 mov qword ptr [rbp + 0x70], rax
004c9f1a  488bf9                   mov rdi, rcx
004c9f1d  48894dd0                 mov qword ptr [rbp - 0x30], rcx
004c9f21  488d1d80d3e401           lea rbx, [rip + 0x1e4d380]
004c9f28  48895d90                 mov qword ptr [rbp - 0x70], rbx
004c9f2c  c645a000                 mov byte ptr [rbp - 0x60], 0
004c9f30  4533e4                   xor r12d, r12d
004c9f33  4c8965a8                 mov qword ptr [rbp - 0x58], r12
004c9f37  4c8965b0                 mov qword ptr [rbp - 0x50], r12
004c9f3b  c745b860000000           mov dword ptr [rbp - 0x48], 0x60
004c9f42  4c8965c0                 mov qword ptr [rbp - 0x40], r12
004c9f46  448965c8                 mov dword ptr [rbp - 0x38], r12d
004c9f4a  4c896598                 mov qword ptr [rbp - 0x68], r12
004c9f4e  83797806                 cmp dword ptr [rcx + 0x78], 6
004c9f52  0f848c040000             je 0x4ca3e4
004c9f58  4488642460               mov byte ptr [rsp + 0x60], r12b
004c9f5d  c744246803a50000         mov dword ptr [rsp + 0x68], 0xa503
004c9f65  0f57c0                   xorps xmm0, xmm0
004c9f68  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
004c9f6e  44896580                 mov dword ptr [rbp - 0x80], r12d
004c9f72  8b4170                   mov eax, dword ptr [rcx + 0x70]
004c9f75  85c0                     test eax, eax
004c9f77  0f8403040000             je 0x4ca380
004c9f7d  83c0fd                   add eax, -3
004c9f80  83f813                   cmp eax, 0x13
004c9f83  0f870a040000             ja 0x4ca393
004c9f89  4898                     cdqe
004c9f8b  488d156e60b3ff           lea rdx, [rip - 0x4c9f92]
004c9f92  8b8c8248a44c00           mov ecx, dword ptr [rdx + rax*4 + 0x4ca448]
004c9f99  4803ca                   add rcx, rdx
004c9f9c  ffe1                     jmp rcx
004c9f9e  ba54000000               mov edx, 0x54
004c9fa3  448d42f0                 lea r8d, [rdx - 0x10]
004c9fa7  e9e1020000               jmp 0x4ca28d
004c9fac  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004c9fb3  488b01                   mov rax, qword ptr [rcx]
004c9fb6  488d55d0                 lea rdx, [rbp - 0x30]
004c9fba  ff5030                   call qword ptr [rax + 0x30]
004c9fbd  488bd8                   mov rbx, rax
004c9fc0  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004c9fc7  4c8b01                   mov r8, qword ptr [rcx]
004c9fca  488d55e0                 lea rdx, [rbp - 0x20]
004c9fce  41ff5030                 call qword ptr [r8 + 0x30]
004c9fd2  488b0b                   mov rcx, qword ptr [rbx]
004c9fd5  48894c2428               mov qword ptr [rsp + 0x28], rcx
004c9fda  8b4008                   mov eax, dword ptr [rax + 8]
004c9fdd  89442420                 mov dword ptr [rsp + 0x20], eax
004c9fe1  ba54000000               mov edx, 0x54
004c9fe6  448d4abc                 lea r9d, [rdx - 0x44]
004c9fea  448d420e                 lea r8d, [rdx + 0xe]
004c9fee  488d4d90                 lea rcx, [rbp - 0x70]
004c9ff2  e8a930ffff               call 0x4bd0a0
004c9ff7  e9a0020000               jmp 0x4ca29c
004c9ffc  ba54000000               mov edx, 0x54
004ca001  448d42f4                 lea r8d, [rdx - 0xc]
004ca005  e983020000               jmp 0x4ca28d
004ca00a  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca011  488b01                   mov rax, qword ptr [rcx]
004ca014  ff10                     call qword ptr [rax]
004ca016  0f1000                   movups xmm0, xmmword ptr [rax]
004ca019  0f294510                 movaps xmmword ptr [rbp + 0x10], xmm0
004ca01d  41b827000000             mov r8d, 0x27
004ca023  488d5520                 lea rdx, [rbp + 0x20]
004ca027  488bc8                   mov rcx, rax
004ca02a  ff1570fe9f01             call qword ptr [rip + 0x19ffe70]
004ca030  4489656a                 mov dword ptr [rbp + 0x6a], r12d
004ca034  488b8728030000           mov rax, qword ptr [rdi + 0x328]
004ca03b  488b18                   mov rbx, qword ptr [rax]
004ca03e  488bc8                   mov rcx, rax
004ca041  488d55e0                 lea rdx, [rbp - 0x20]
004ca045  ff5330                   call qword ptr [rbx + 0x30]
004ca048  4c8bf8                   mov r15, rax
004ca04b  488bbf28030000           mov rdi, qword ptr [rdi + 0x328]
004ca052  488bcf                   mov rcx, rdi
004ca055  ff5378                   call qword ptr [rbx + 0x78]
004ca058  488bf0                   mov rsi, rax
004ca05b  488bcf                   mov rcx, rdi
004ca05e  ff5308                   call qword ptr [rbx + 8]
004ca061  0fb6d8                   movzx ebx, al
004ca064  4c8b07                   mov r8, qword ptr [rdi]
004ca067  488d55f0                 lea rdx, [rbp - 0x10]
004ca06b  488bcf                   mov rcx, rdi
004ca06e  41ff5030                 call qword ptr [r8 + 0x30]
004ca072  4889742448               mov qword ptr [rsp + 0x48], rsi
004ca077  895c2440                 mov dword ptr [rsp + 0x40], ebx
004ca07b  488d4d22                 lea rcx, [rbp + 0x22]
004ca07f  48894c2438               mov qword ptr [rsp + 0x38], rcx
004ca084  48c744243048000000       mov qword ptr [rsp + 0x30], 0x48
004ca08d  498b0f                   mov rcx, qword ptr [r15]
004ca090  48894c2428               mov qword ptr [rsp + 0x28], rcx
004ca095  8b4008                   mov eax, dword ptr [rax + 8]
004ca098  89442420                 mov dword ptr [rsp + 0x20], eax
004ca09c  ba54000000               mov edx, 0x54
004ca0a1  448d4abc                 lea r9d, [rdx - 0x44]
004ca0a5  448d420f                 lea r8d, [rdx + 0xf]
004ca0a9  488d4d90                 lea rcx, [rbp - 0x70]
004ca0ad  e8ee2fffff               call 0x4bd0a0
004ca0b2  488b7dd0                 mov rdi, qword ptr [rbp - 0x30]
004ca0b6  e9e1010000               jmp 0x4ca29c
004ca0bb  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca0c2  488b01                   mov rax, qword ptr [rcx]
004ca0c5  488d55f0                 lea rdx, [rbp - 0x10]
004ca0c9  ff5030                   call qword ptr [rax + 0x30]
004ca0cc  488bd8                   mov rbx, rax
004ca0cf  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca0d6  4c8b01                   mov r8, qword ptr [rcx]
004ca0d9  488d55e0                 lea rdx, [rbp - 0x20]
004ca0dd  41ff5030                 call qword ptr [r8 + 0x30]
004ca0e1  488b0b                   mov rcx, qword ptr [rbx]
004ca0e4  48894c2428               mov qword ptr [rsp + 0x28], rcx
004ca0e9  8b4008                   mov eax, dword ptr [rax + 8]
004ca0ec  89442420                 mov dword ptr [rsp + 0x20], eax
004ca0f0  ba54000000               mov edx, 0x54
004ca0f5  448d4abc                 lea r9d, [rdx - 0x44]
004ca0f9  448d42e5                 lea r8d, [rdx - 0x1b]
004ca0fd  488d4d90                 lea rcx, [rbp - 0x70]
004ca101  e89a2fffff               call 0x4bd0a0
004ca106  e991010000               jmp 0x4ca29c
004ca10b  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca112  488b01                   mov rax, qword ptr [rcx]
004ca115  488d55f0                 lea rdx, [rbp - 0x10]
004ca119  ff5030                   call qword ptr [rax + 0x30]
004ca11c  488bd8                   mov rbx, rax
004ca11f  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca126  4c8b01                   mov r8, qword ptr [rcx]
004ca129  488d55e0                 lea rdx, [rbp - 0x20]
004ca12d  41ff5030                 call qword ptr [r8 + 0x30]
004ca131  488b0b                   mov rcx, qword ptr [rbx]
004ca134  48894c2428               mov qword ptr [rsp + 0x28], rcx
004ca139  8b4008                   mov eax, dword ptr [rax + 8]
004ca13c  89442420                 mov dword ptr [rsp + 0x20], eax
004ca140  ba54000000               mov edx, 0x54
004ca145  448d4abc                 lea r9d, [rdx - 0x44]
004ca149  448d42d1                 lea r8d, [rdx - 0x2f]
004ca14d  488d4d90                 lea rcx, [rbp - 0x70]
004ca151  e84a2fffff               call 0x4bd0a0
004ca156  e941010000               jmp 0x4ca29c
004ca15b  ba54000000               mov edx, 0x54
004ca160  448d4205                 lea r8d, [rdx + 5]
004ca164  e924010000               jmp 0x4ca28d
004ca169  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca170  488b01                   mov rax, qword ptr [rcx]
004ca173  ff10                     call qword ptr [rax]
004ca175  0f1000                   movups xmm0, xmmword ptr [rax]
004ca178  0f294510                 movaps xmmword ptr [rbp + 0x10], xmm0
004ca17c  41b827000000             mov r8d, 0x27
004ca182  488d5520                 lea rdx, [rbp + 0x20]
004ca186  488bc8                   mov rcx, rax
004ca189  ff1511fd9f01             call qword ptr [rip + 0x19ffd11]
004ca18f  4489656a                 mov dword ptr [rbp + 0x6a], r12d
004ca193  488b8728030000           mov rax, qword ptr [rdi + 0x328]
004ca19a  488b18                   mov rbx, qword ptr [rax]
004ca19d  4c8b6768                 mov r12, qword ptr [rdi + 0x68]
004ca1a1  448b6f60                 mov r13d, dword ptr [rdi + 0x60]
004ca1a5  488bc8                   mov rcx, rax
004ca1a8  488d55f0                 lea rdx, [rbp - 0x10]
004ca1ac  ff5330                   call qword ptr [rbx + 0x30]
004ca1af  4c8bf8                   mov r15, rax
004ca1b2  488bbf28030000           mov rdi, qword ptr [rdi + 0x328]
004ca1b9  488bcf                   mov rcx, rdi
004ca1bc  ff5378                   call qword ptr [rbx + 0x78]
004ca1bf  488bf0                   mov rsi, rax
004ca1c2  488bcf                   mov rcx, rdi
004ca1c5  ff5308                   call qword ptr [rbx + 8]
004ca1c8  0fb6d8                   movzx ebx, al
004ca1cb  4c8b07                   mov r8, qword ptr [rdi]
004ca1ce  488d55e0                 lea rdx, [rbp - 0x20]
004ca1d2  488bcf                   mov rcx, rdi
004ca1d5  41ff5030                 call qword ptr [r8 + 0x30]
004ca1d9  4889742458               mov qword ptr [rsp + 0x58], rsi
004ca1de  895c2450                 mov dword ptr [rsp + 0x50], ebx
004ca1e2  488d4d22                 lea rcx, [rbp + 0x22]
004ca1e6  48894c2448               mov qword ptr [rsp + 0x48], rcx
004ca1eb  48c744244048000000       mov qword ptr [rsp + 0x40], 0x48
004ca1f4  4c89642438               mov qword ptr [rsp + 0x38], r12
004ca1f9  44896c2430               mov dword ptr [rsp + 0x30], r13d
004ca1fe  498b0f                   mov rcx, qword ptr [r15]
004ca201  48894c2428               mov qword ptr [rsp + 0x28], rcx
004ca206  8b4008                   mov eax, dword ptr [rax + 8]
004ca209  89442420                 mov dword ptr [rsp + 0x20], eax
004ca20d  ba60000000               mov edx, 0x60
004ca212  41b910000000             mov r9d, 0x10
004ca218  458bc1                   mov r8d, r9d
004ca21b  488d4d90                 lea rcx, [rbp - 0x70]
004ca21f  e87c2effff               call 0x4bd0a0
004ca224  488b7dd0                 mov rdi, qword ptr [rbp - 0x30]
004ca228  4533e4                   xor r12d, r12d
004ca22b  eb6f                     jmp 0x4ca29c
004ca22d  41b813000000             mov r8d, 0x13
004ca233  eb53                     jmp 0x4ca288
004ca235  0f108758010000           movups xmm0, xmmword ptr [rdi + 0x158]
004ca23c  0f10c8                   movups xmm1, xmm0
004ca23f  660fd6442428             movq qword ptr [rsp + 0x28], xmm0
004ca245  660f73d908               psrldq xmm1, 8
004ca24a  660f7e4c2420             movd dword ptr [rsp + 0x20], xmm1
004ca250  ba54000000               mov edx, 0x54
004ca255  448d4abc                 lea r9d, [rdx - 0x44]
004ca259  448d420a                 lea r8d, [rdx + 0xa]
004ca25d  488d4d90                 lea rcx, [rbp - 0x70]
004ca261  e83a2effff               call 0x4bd0a0
004ca266  eb34                     jmp 0x4ca29c
004ca268  ba18010000               mov edx, 0x118
004ca26d  41b834000000             mov r8d, 0x34
004ca273  eb18                     jmp 0x4ca28d
004ca275  ba18010000               mov edx, 0x118
004ca27a  41b83a000000             mov r8d, 0x3a
004ca280  eb0b                     jmp 0x4ca28d
004ca282  41b81b000000             mov r8d, 0x1b
004ca288  ba61000000               mov edx, 0x61
004ca28d  41b910000000             mov r9d, 0x10
004ca293  488d4d90                 lea rcx, [rbp - 0x70]
004ca297  e8042effff               call 0x4bd0a0
004ca29c  488b55a8                 mov rdx, qword ptr [rbp - 0x58]
004ca2a0  4c8965a8                 mov qword ptr [rbp - 0x58], r12
004ca2a4  448b45b8                 mov r8d, dword ptr [rbp - 0x48]
004ca2a8  488d4c2460               lea rcx, [rsp + 0x60]
004ca2ad  e81e2f0000               call 0x4cd1d0
004ca2b2  807c246803               cmp byte ptr [rsp + 0x68], 3
004ca2b7  7406                     je 0x4ca2bf
004ca2b9  66834c246a01             or word ptr [rsp + 0x6a], 1
004ca2bf  488d9fb8030000           lea rbx, [rdi + 0x3b8]
004ca2c6  4c8db7f8030000           lea r14, [rdi + 0x3f8]
004ca2cd  41803e00                 cmp byte ptr [r14], 0
004ca2d1  7430                     je 0x4ca303
004ca2d3  41c60600                 mov byte ptr [r14], 0
004ca2d7  41f6460a01               test byte ptr [r14 + 0xa], 1
004ca2dc  7411                     je 0x4ca2ef
004ca2de  488b1593abca01           mov rdx, qword ptr [rip + 0x1caab93]
004ca2e5  498d4e08                 lea rcx, [r14 + 8]
004ca2e9  ff152919a001             call qword ptr [rip + 0x1a01929]
004ca2ef  41c7460803a50000         mov dword ptr [r14 + 8], 0xa503
004ca2f7  4d896610                 mov qword ptr [r14 + 0x10], r12
004ca2fb  4d896618                 mov qword ptr [r14 + 0x18], r12
004ca2ff  45896620                 mov dword ptr [r14 + 0x20], r12d
004ca303  488b8f20040000           mov rcx, qword ptr [rdi + 0x420]
004ca30a  4885c9                   test rcx, rcx
004ca30d  740d                     je 0x4ca31c
004ca30f  488b01                   mov rax, qword ptr [rcx]
004ca312  ff5070                   call qword ptr [rax + 0x70]
004ca315  4c89a720040000           mov qword ptr [rdi + 0x420], r12
004ca31c  498bce                   mov rcx, r14
004ca31f  e88c310000               call 0x4cd4b0
004ca324  488bcb                   mov rcx, rbx
004ca327  e8a468feff               call 0x4b0bd0
004ca32c  448965d8                 mov dword ptr [rbp - 0x28], r12d
004ca330  4c8965d0                 mov qword ptr [rbp - 0x30], r12
004ca334  0f1005b572a201           movups xmm0, xmmword ptr [rip + 0x1a272b5]
004ca33b  0f1103                   movups xmmword ptr [rbx], xmm0
004ca33e  c7431002000000           mov dword ptr [rbx + 0x10], 2
004ca345  48c74318ffffffff         mov qword ptr [rbx + 0x18], 0xffffffffffffffff
004ca34d  44896320                 mov dword ptr [rbx + 0x20], r12d
004ca351  0f1045d0                 movups xmm0, xmmword ptr [rbp - 0x30]
004ca355  0f114328                 movups xmmword ptr [rbx + 0x28], xmm0
004ca359  488d542460               lea rdx, [rsp + 0x60]
004ca35e  488bcb                   mov rcx, rbx
004ca361  e87a6dffff               call 0x4c10e0
004ca366  837b3000                 cmp dword ptr [rbx + 0x30], 0
004ca36a  750d                     jne 0x4ca379
004ca36c  8b4310                   mov eax, dword ptr [rbx + 0x10]
004ca36f  a804                     test al, 4
004ca371  7406                     je 0x4ca379
004ca373  83c808                   or eax, 8
004ca376  894310                   mov dword ptr [rbx + 0x10], eax
004ca379  488d1d28cfe401           lea rbx, [rip + 0x1e4cf28]
004ca380  c787f003000001000000     mov dword ptr [rdi + 0x3f0], 1
004ca38a  488bcf                   mov rcx, rdi
004ca38d  e86ef0ffff               call 0x4c9400
004ca392  90                       nop
004ca393  807c246000               cmp byte ptr [rsp + 0x60], 0
004ca398  744a                     je 0x4ca3e4
004ca39a  c644246000               mov byte ptr [rsp + 0x60], 0
004ca39f  f644246a01               test byte ptr [rsp + 0x6a], 1
004ca3a4  7412                     je 0x4ca3b8
004ca3a6  488b15cbaaca01           mov rdx, qword ptr [rip + 0x1caaacb]
004ca3ad  488d4c2468               lea rcx, [rsp + 0x68]
004ca3b2  ff156018a001             call qword ptr [rip + 0x1a01860]
004ca3b8  66448964246a             mov word ptr [rsp + 0x6a], r12w
004ca3be  c744246803000000         mov dword ptr [rsp + 0x68], 3
004ca3c6  0f57c0                   xorps xmm0, xmm0
004ca3c9  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
004ca3cf  44896580                 mov dword ptr [rbp - 0x80], r12d
004ca3d3  66c744246803a5           mov word ptr [rsp + 0x68], 0xa503
004ca3da  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
004ca3e0  44896580                 mov dword ptr [rbp - 0x80], r12d
004ca3e4  48895d90                 mov qword ptr [rbp - 0x70], rbx
004ca3e8  488b4db0                 mov rcx, qword ptr [rbp - 0x50]
004ca3ec  4885c9                   test rcx, rcx
004ca3ef  7417                     je 0x4ca408
004ca3f1  488b01                   mov rax, qword ptr [rcx]
004ca3f4  ff90a0000000             call qword ptr [rax + 0xa0]
004ca3fa  488b4db0                 mov rcx, qword ptr [rbp - 0x50]
004ca3fe  488b01                   mov rax, qword ptr [rcx]
004ca401  ff5010                   call qword ptr [rax + 0x10]
004ca404  4c8965b0                 mov qword ptr [rbp - 0x50], r12
004ca408  488b4da8                 mov rcx, qword ptr [rbp - 0x58]
004ca40c  4885c9                   test rcx, rcx
004ca40f  740a                     je 0x4ca41b
004ca411  ff15910ba001             call qword ptr [rip + 0x1a00b91]
004ca417  4c8965a8                 mov qword ptr [rbp - 0x58], r12
004ca41b  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
004ca41f  4833cc                   xor rcx, rsp
004ca422  e8496cb3ff               call 0x1070
004ca427  4c8d9c2480010000         lea r11, [rsp + 0x180]
004ca42f  498b5b38                 mov rbx, qword ptr [r11 + 0x38]
004ca433  498b7340                 mov rsi, qword ptr [r11 + 0x40]
004ca437  498b7b48                 mov rdi, qword ptr [r11 + 0x48]
004ca43b  498be3                   mov rsp, r11
004ca43e  415f                     pop r15
004ca440  415e                     pop r14
004ca442  415d                     pop r13
004ca444  415c                     pop r12
004ca446  5d                       pop rbp
004ca447  c3                       ret
004ca448  9e                       sahf
004ca449  9f                       lahf
004ca44a  4c0093a34c0093           add byte ptr [rbx - 0x6cffb35d], r10b
004ca451  a34c0093a34c00ac9f       movabs dword ptr [0x9fac004ca393004c], eax
004ca45a  4c00ac9f4c00fc9f         add byte ptr [rdi + rbx*4 - 0x6003ffb4], r13b
004ca462  4c000a                   add byte ptr [rdx], r9b
004ca465  a04c00bba04c005ba1       movabs al, byte ptr [0xa15b004ca0bb004c]
004ca46e  4c0093a34c0093           add byte ptr [rbx - 0x6cffb35d], r10b
004ca475  a34c0069a14c0093a3       movabs dword ptr [0xa393004ca169004c], eax
004ca47e  4c002da24c000b           add byte ptr [rip + 0xb004ca2], r13b
004ca485  a14c0035a24c0068a2       movabs eax, dword ptr [0xa268004ca235004c]
004ca48e  4c0075a2                 add byte ptr [rbp - 0x5e], r14b
