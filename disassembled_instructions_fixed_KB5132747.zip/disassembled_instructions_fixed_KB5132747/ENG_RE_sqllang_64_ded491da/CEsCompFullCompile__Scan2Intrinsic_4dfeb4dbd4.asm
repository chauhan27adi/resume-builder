; CEsCompFullCompile::Scan2Intrinsic
; sqllang.dll, primary RVA 0x1257d0, 1444 bytes in 1 chunk(s)

; chunk at RVA 0x1257d0 (1444 bytes)
001257d0  44894c2420               mov dword ptr [rsp + 0x20], r9d
001257d5  4c89442418               mov qword ptr [rsp + 0x18], r8
001257da  55                       push rbp
001257db  56                       push rsi
001257dc  57                       push rdi
001257dd  4154                     push r12
001257df  4155                     push r13
001257e1  4156                     push r14
001257e3  4157                     push r15
001257e5  488dac24e0ebffff         lea rbp, [rsp - 0x1420]
001257ed  b820150000               mov eax, 0x1520
001257f2  e899b8edff               call 0x1090
001257f7  482be0                   sub rsp, rax
001257fa  48c745d0feffffff         mov qword ptr [rbp - 0x30], 0xfffffffffffffffe
00125802  48899c2460150000         mov qword ptr [rsp + 0x1560], rbx
0012580a  4d8bf0                   mov r14, r8
0012580d  4c8be2                   mov r12, rdx
00125810  488bd9                   mov rbx, rcx
00125813  448b6a18                 mov r13d, dword ptr [rdx + 0x18]
00125817  654c8b142558000000       mov r10, qword ptr gs:[0x58]
00125820  488b055157da01           mov rax, qword ptr [rip + 0x1da5751]
00125827  8b08                     mov ecx, dword ptr [rax]
00125829  488b055057da01           mov rax, qword ptr [rip + 0x1da5750]
00125830  8b00                     mov eax, dword ptr [rax]
00125832  490304ca                 add rax, qword ptr [r10 + rcx*8]
00125836  488b00                   mov rax, qword ptr [rax]
00125839  80b89900000000           cmp byte ptr [rax + 0x99], 0
00125840  7416                     je 0x125858
00125842  e8597deeff               call 0xd5a0
00125847  488bb8a0000000           mov rdi, qword ptr [rax + 0xa0]
0012584e  837f3000                 cmp dword ptr [rdi + 0x30], 0
00125852  0f84ede07500             je 0x883945
00125858  498b4c2410               mov rcx, qword ptr [r12 + 0x10]
0012585d  488b01                   mov rax, qword ptr [rcx]
00125860  ff5018                   call qword ptr [rax + 0x18]
00125863  4d8b4c2410               mov r9, qword ptr [r12 + 0x10]
00125868  4c894c2450               mov qword ptr [rsp + 0x50], r9
0012586d  83f858                   cmp eax, 0x58
00125870  0f85e7e07500             jne 0x88395d
00125876  498b5140                 mov rdx, qword ptr [r9 + 0x40]
0012587a  498d4948                 lea rcx, [r9 + 0x48]
0012587e  48894c2468               mov qword ptr [rsp + 0x68], rcx
00125883  eb01                     jmp 0x125886
00125885  cc                       int3
00125886  4889542458               mov qword ptr [rsp + 0x58], rdx
0012588b  498d7118                 lea rsi, [r9 + 0x18]
0012588f  0fb606                   movzx eax, byte ptr [rsi]
00125892  888568140000             mov byte ptr [rbp + 0x1468], al
00125898  4c8d3d216e9d02           lea r15, [rip + 0x29d6e21]
0012589f  4c63420c                 movsxd r8, dword ptr [rdx + 0xc]
001258a3  4489442448               mov dword ptr [rsp + 0x48], r8d
001258a8  4c8d1551a7edff           lea r10, [rip - 0x1258af]
001258af  33ff                     xor edi, edi
001258b1  48897c2460               mov qword ptr [rsp + 0x60], rdi
001258b6  4338bc105031b402         cmp byte ptr [r8 + r10 + 0x2b43150], dil
001258be  0f85ace07500             jne 0x883970
001258c4  4181f817010000           cmp r8d, 0x117
001258cb  0f8fe2501c00             jg 0x2ea9b3
001258d1  0f841af77500             je 0x884ff1
001258d7  4183c0f1                 add r8d, -0xf
001258db  4181f8ea000000           cmp r8d, 0xea
001258e2  0f87e74c1c00             ja 0x2ea5cf
001258e8  4963c0                   movsxd rax, r8d
001258eb  410fb68402d85a1200       movzx eax, byte ptr [r10 + rax + 0x125ad8]
001258f4  418b8c82085a1200         mov ecx, dword ptr [r10 + rax*4 + 0x125a08]
001258fc  4903ca                   add rcx, r10
001258ff  ffe1                     jmp rcx
00125901  cc                       int3
00125902  498b542420               mov rdx, qword ptr [r12 + 0x20]
00125907  4d8bce                   mov r9, r14
0012590a  4d8bc4                   mov r8, r12
0012590d  488b12                   mov rdx, qword ptr [rdx]
00125910  488bcb                   mov rcx, rbx
00125913  e8d80bf4ff               call 0x664f0
00125918  498b442420               mov rax, qword ptr [r12 + 0x20]
0012591d  488b08                   mov rcx, qword ptr [rax]
00125920  488b4910                 mov rcx, qword ptr [rcx + 0x10]
00125924  4883c118                 add rcx, 0x18
00125928  e8e3741c00               call 0x2ece10
0012592d  448b6b0c                 mov r13d, dword ptr [rbx + 0xc]
00125931  84c0                     test al, al
00125933  0f8542e27500             jne 0x883b7b
00125939  458d4501                 lea r8d, [r13 + 1]
0012593d  4489430c                 mov dword ptr [rbx + 0xc], r8d
00125941  be01000000               mov esi, 1
00125946  89742420                 mov dword ptr [rsp + 0x20], esi
0012594a  41b93c040000             mov r9d, 0x43c
00125950  498bd6                   mov rdx, r14
00125953  488bcb                   mov rcx, rbx
00125956  e8f5fdf3ff               call 0x65750
0012595b  ff430c                   inc dword ptr [rbx + 0xc]
0012595e  498b542420               mov rdx, qword ptr [r12 + 0x20]
00125963  4d8bce                   mov r9, r14
00125966  4d8bc4                   mov r8, r12
00125969  488b5208                 mov rdx, qword ptr [rdx + 8]
0012596d  488bcb                   mov rcx, rbx
00125970  e87b0bf4ff               call 0x664f0
00125975  8b7b0c                   mov edi, dword ptr [rbx + 0xc]
00125978  33c0                     xor eax, eax
0012597a  89442420                 mov dword ptr [rsp + 0x20], eax
0012597e  41b94d040000             mov r9d, 0x44d
00125984  458bc5                   mov r8d, r13d
00125987  498bd6                   mov rdx, r14
0012598a  488bcb                   mov rcx, rbx
0012598d  e8befdf3ff               call 0x65750
00125992  4889442440               mov qword ptr [rsp + 0x40], rax
00125997  ba03000000               mov edx, 3
0012599c  89500c                   mov dword ptr [rax + 0xc], edx
0012599f  488b442440               mov rax, qword ptr [rsp + 0x40]
001259a4  897810                   mov dword ptr [rax + 0x10], edi
001259a7  41897650                 mov dword ptr [r14 + 0x50], esi
001259ab  eb01                     jmp 0x1259ae
001259ad  cc                       int3
001259ae  448b6c2448               mov r13d, dword ptr [rsp + 0x48]
001259b3  488b742450               mov rsi, qword ptr [rsp + 0x50]
001259b8  4c8b742458               mov r14, qword ptr [rsp + 0x58]
001259bd  498bce                   mov rcx, r14
001259c0  e83bfdffff               call 0x125700
001259c5  84c0                     test al, al
001259c7  0f85e4490800             jne 0x1aa3b1
001259cd  498bce                   mov rcx, r14
001259d0  e81bfdffff               call 0x1256f0
001259d5  84c0                     test al, al
001259d7  0f8512752100             jne 0x33ceef
001259dd  498bce                   mov rcx, r14
001259e0  e82bfdffff               call 0x125710
001259e5  84c0                     test al, al
001259e7  0f85b94d1c00             jne 0x2ea7a6
001259ed  488b9c2460150000         mov rbx, qword ptr [rsp + 0x1560]
001259f5  4881c420150000           add rsp, 0x1520
001259fc  415f                     pop r15
001259fe  415e                     pop r14
00125a00  415d                     pop r13
00125a02  415c                     pop r12
00125a04  5f                       pop rdi
00125a05  5e                       pop rsi
00125a06  5d                       pop rbp
00125a07  c3                       ret
00125a08  e541                     in eax, 0x41
00125a0a  8800                     mov byte ptr [rax], al
00125a0c  ad                       lodsd eax, dword ptr [rsi]
00125a0d  3c88                     cmp al, 0x88
00125a0f  00e2                     add dl, ah
00125a11  3c88                     cmp al, 0x88
00125a13  00544288                 add byte ptr [rdx + rax*2 - 0x78], dl
00125a17  0096a52e00b8             add byte ptr [rsi - 0x47ffd15b], dl
00125a1d  3e8800                   mov byte ptr ds:[rax], al
00125a20  cb                       retf
00125a21  3d88001e5b               cmp eax, 0x5b1e0088
00125a26  260002                   add byte ptr es:[rdx], al
00125a29  59                       pop rcx
00125a2a  1200                     adc al, byte ptr [rax]
00125a2c  97                       xchg edi, eax
00125a2d  4b8800                   mov byte ptr [r8], al
00125a30  f5                       cmc
00125a31  a4                       movsb byte ptr [rdi], byte ptr [rsi]
00125a32  2400                     and al, 0
00125a34  a4                       movsb byte ptr [rdi], byte ptr [rsi]
00125a35  448800                   mov byte ptr [rax], r8b
00125a38  4b9f                     lahf
