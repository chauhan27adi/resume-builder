; CAlgTableMetadata::LoadColumns
; sqllang.dll, primary RVA 0x9a720, 947 bytes in 1 chunk(s)

; chunk at RVA 0x9a720 (947 bytes)
0009a720  4055                     push rbp
0009a722  56                       push rsi
0009a723  57                       push rdi
0009a724  4154                     push r12
0009a726  4155                     push r13
0009a728  4156                     push r14
0009a72a  4157                     push r15
0009a72c  488d6c24d9               lea rbp, [rsp - 0x27]
0009a731  4881ecf0000000           sub rsp, 0xf0
0009a738  48c745d7feffffff         mov qword ptr [rbp - 0x29], 0xfffffffffffffffe
0009a740  48899c2448010000         mov qword ptr [rsp + 0x148], rbx
0009a748  488b0539e5a302           mov rax, qword ptr [rip + 0x2a3e539]
0009a74f  4833c4                   xor rax, rsp
0009a752  48894517                 mov qword ptr [rbp + 0x17], rax
0009a756  44884587                 mov byte ptr [rbp - 0x79], r8b
0009a75a  488bf2                   mov rsi, rdx
0009a75d  488bd9                   mov rbx, rcx
0009a760  4c8b6228                 mov r12, qword ptr [rdx + 0x28]
0009a764  4c8965bf                 mov qword ptr [rbp - 0x41], r12
0009a768  4c8965df                 mov qword ptr [rbp - 0x21], r12
0009a76c  4c8baa80010000           mov r13, qword ptr [rdx + 0x180]
0009a773  488b4918                 mov rcx, qword ptr [rcx + 0x18]
0009a777  488b01                   mov rax, qword ptr [rcx]
0009a77a  ff5078                   call qword ptr [rax + 0x78]
0009a77d  4c8bf0                   mov r14, rax
0009a780  488945c7                 mov qword ptr [rbp - 0x39], rax
0009a784  654c8b042558000000       mov r8, qword ptr gs:[0x58]
0009a78d  488b0de407e301           mov rcx, qword ptr [rip + 0x1e307e4]
0009a794  8b11                     mov edx, dword ptr [rcx]
0009a796  488b0de307e301           mov rcx, qword ptr [rip + 0x1e307e3]
0009a79d  8b09                     mov ecx, dword ptr [rcx]
0009a79f  49030cd0                 add rcx, qword ptr [r8 + rdx*8]
0009a7a3  488b09                   mov rcx, qword ptr [rcx]
0009a7a6  488b5150                 mov rdx, qword ptr [rcx + 0x50]
0009a7aa  0fb74208                 movzx eax, word ptr [rdx + 8]
0009a7ae  6689458b                 mov word ptr [rbp - 0x75], ax
0009a7b2  837b1005                 cmp dword ptr [rbx + 0x10], 5
0009a7b6  0f84576c9e00             je 0xa81413
0009a7bc  0fb78380000000           movzx eax, word ptr [rbx + 0x80]
0009a7c3  66894589                 mov word ptr [rbp - 0x77], ax
0009a7c7  488b8318010000           mov rax, qword ptr [rbx + 0x118]
0009a7ce  488945cf                 mov qword ptr [rbp - 0x31], rax
0009a7d2  bfffffffff               mov edi, 0xffffffff
0009a7d7  4885c0                   test rax, rax
0009a7da  0f852c010000             jne 0x9a90c
0009a7e0  498b06                   mov rax, qword ptr [r14]
0009a7e3  33d2                     xor edx, edx
0009a7e5  498bce                   mov rcx, r14
0009a7e8  ff90d0000000             call qword ptr [rax + 0xd0]
0009a7ee  898314010000             mov dword ptr [rbx + 0x114], eax
0009a7f4  498b06                   mov rax, qword ptr [r14]
0009a7f7  ba01000000               mov edx, 1
0009a7fc  498bce                   mov rcx, r14
0009a7ff  ff90d0000000             call qword ptr [rax + 0xd0]
0009a805  2b8314010000             sub eax, dword ptr [rbx + 0x114]
0009a80b  898320010000             mov dword ptr [rbx + 0x120], eax
0009a811  837b1000                 cmp dword ptr [rbx + 0x10], 0
0009a815  7514                     jne 0x9a82b
0009a817  498b06                   mov rax, qword ptr [r14]
0009a81a  498bce                   mov rcx, r14
0009a81d  ff90a8000000             call qword ptr [rax + 0xa8]
0009a823  3bc7                     cmp eax, edi
0009a825  0f85036c9e00             jne 0xa8142e
0009a82b  32c0                     xor al, al
0009a82d  80a31e020000fb           and byte ptr [rbx + 0x21e], 0xfb
0009a834  08831e020000             or byte ptr [rbx + 0x21e], al
0009a83a  c745af510a0000           mov dword ptr [rbp - 0x51], 0xa51
0009a841  c644242003               mov byte ptr [rsp + 0x20], 3
0009a846  41b9510a0000             mov r9d, 0xa51
0009a84c  4c8d056d7cfd01           lea r8, [rip + 0x1fd7c6d]
0009a853  498bd4                   mov rdx, r12
0009a856  b940000000               mov ecx, 0x40
0009a85b  ff154f06e301             call qword ptr [rip + 0x1e3064f]
0009a861  488bf8                   mov rdi, rax
0009a864  488945b7                 mov qword ptr [rbp - 0x49], rax
0009a868  41bf00040000             mov r15d, 0x400
0009a86e  4885c0                   test rax, rax
0009a871  0f84bf6b9e00             je 0xa81436
0009a877  8b8b14010000             mov ecx, dword ptr [rbx + 0x114]
0009a87d  458bc7                   mov r8d, r15d
0009a880  413bcf                   cmp ecx, r15d
0009a883  440f42c1                 cmovb r8d, ecx
0009a887  498bd4                   mov rdx, r12
0009a88a  488bc8                   mov rcx, rax
0009a88d  e8de32ffff               call 0x8db70
0009a892  90                       nop
0009a893  488d052e96fd01           lea rax, [rip + 0x1fd962e]
0009a89a  488907                   mov qword ptr [rdi], rax
0009a89d  eb01                     jmp 0x9a8a0
0009a89f  cc                       int3
0009a8a0  4889bb18010000           mov qword ptr [rbx + 0x118], rdi
0009a8a7  c745af540a0000           mov dword ptr [rbp - 0x51], 0xa54
0009a8ae  c644242003               mov byte ptr [rsp + 0x20], 3
0009a8b3  41b9540a0000             mov r9d, 0xa54
0009a8b9  4c8d05007cfd01           lea r8, [rip + 0x1fd7c00]
0009a8c0  498bd4                   mov rdx, r12
0009a8c3  b938000000               mov ecx, 0x38
0009a8c8  ff15e205e301             call qword ptr [rip + 0x1e305e2]
0009a8ce  488945b7                 mov qword ptr [rbp - 0x49], rax
0009a8d2  4885c0                   test rax, rax
0009a8d5  741c                     je 0x9a8f3
0009a8d7  8b8b14010000             mov ecx, dword ptr [rbx + 0x114]
0009a8dd  413bcf                   cmp ecx, r15d
0009a8e0  440f42f9                 cmovb r15d, ecx
0009a8e4  458bc7                   mov r8d, r15d
0009a8e7  498bd4                   mov rdx, r12
0009a8ea  488bc8                   mov rcx, rax
0009a8ed  e83e770000               call 0xa2030
0009a8f2  90                       nop
0009a8f3  488983c0010000           mov qword ptr [rbx + 0x1c0], rax
0009a8fa  83bb2001000000           cmp dword ptr [rbx + 0x120], 0
0009a901  0f85a18c1e00             jne 0x2835a8
0009a907  bfffffffff               mov edi, 0xffffffff
0009a90c  488b06                   mov rax, qword ptr [rsi]
0009a90f  488bce                   mov rcx, rsi
0009a912  ff5018                   call qword ptr [rax + 0x18]
0009a915  3dfd000000               cmp eax, 0xfd
0009a91a  410f94c7                 sete r15b
0009a91e  498b8d80000000           mov rcx, qword ptr [r13 + 0x80]
0009a925  e8d6e9ffff               call 0x99300
0009a92a  84c0                     test al, al
0009a92c  0f85146b9e00             jne 0xa81446
0009a932  4532e4                   xor r12b, r12b
0009a935  48c7459f00000000         mov qword ptr [rbp - 0x61], 0
0009a93d  4c89758f                 mov qword ptr [rbp - 0x71], r14
0009a941  48c7459701000000         mov qword ptr [rbp - 0x69], 1
0009a949  498b06                   mov rax, qword ptr [r14]
0009a94c  498bce                   mov rcx, r14
0009a94f  ff90a8000000             call qword ptr [rax + 0xa8]
0009a955  3bc7                     cmp eax, edi
0009a957  0f850c6b9e00             jne 0xa81469
0009a95d  33ff                     xor edi, edi
0009a95f  4c8b6dbf                 mov r13, qword ptr [rbp - 0x41]
0009a963  440fb77589               movzx r14d, word ptr [rbp - 0x77]
0009a968  0f1f840000000000         nop dword ptr [rax + rax]
0009a970  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
0009a974  488b01                   mov rax, qword ptr [rcx]
0009a977  48837d9f00               cmp qword ptr [rbp - 0x61], 0
0009a97c  0f852b6b9e00             jne 0xa814ad
0009a982  8b5597                   mov edx, dword ptr [rbp - 0x69]
0009a985  ff90d0000000             call qword ptr [rax + 0xd0]
0009a98b  8b559b                   mov edx, dword ptr [rbp - 0x65]
0009a98e  3bd0                     cmp edx, eax
0009a990  0f8371fdffff             jae 0x9a707
0009a996  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
0009a99a  488b01                   mov rax, qword ptr [rcx]
0009a99d  ffc2                     inc edx
0009a99f  448b4597                 mov r8d, dword ptr [rbp - 0x69]
0009a9a3  ff90e0000000             call qword ptr [rax + 0xe0]
0009a9a9  eb01                     jmp 0x9a9ac
0009a9ab  cc                       int3
0009a9ac  4885c0                   test rax, rax
0009a9af  0f848d000000             je 0x9aa42
0009a9b5  c644244800               mov byte ptr [rsp + 0x48], 0
0009a9ba  0fb64d87                 movzx ecx, byte ptr [rbp - 0x79]
0009a9be  884c2440                 mov byte ptr [rsp + 0x40], cl
0009a9c2  4889742438               mov qword ptr [rsp + 0x38], rsi
0009a9c7  4c896c2430               mov qword ptr [rsp + 0x30], r13
0009a9cc  4488642428               mov byte ptr [rsp + 0x28], r12b
0009a9d1  44887c2420               mov byte ptr [rsp + 0x20], r15b
0009a9d6  450fb7ce                 movzx r9d, r14w
0009a9da  440fb7458b               movzx r8d, word ptr [rbp - 0x75]
0009a9df  488bd0                   mov rdx, rax
0009a9e2  488bcb                   mov rcx, rbx
0009a9e5  e8b6290000               call 0x9d3a0
0009a9ea  488b4d9f                 mov rcx, qword ptr [rbp - 0x61]
0009a9ee  4885c9                   test rcx, rcx
0009a9f1  0f85c76a9e00             jne 0xa814be
0009a9f7  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
0009a9fb  488b01                   mov rax, qword ptr [rcx]
0009a9fe  8b5597                   mov edx, dword ptr [rbp - 0x69]
0009aa01  ff90d0000000             call qword ptr [rax + 0xd0]
0009aa07  8b4d9b                   mov ecx, dword ptr [rbp - 0x65]
0009aa0a  3bc8                     cmp ecx, eax
0009aa0c  7308                     jae 0x9aa16
0009aa0e  ffc1                     inc ecx
0009aa10  894d9b                   mov dword ptr [rbp - 0x65], ecx
0009aa13  eb01                     jmp 0x9aa16
0009aa15  cc                       int3
0009aa16  ffc7                     inc edi
0009aa18  40f6c77f                 test dil, 0x7f
0009aa1c  0f854effffff             jne 0x9a970
0009aa22  488d8e2c020000           lea rcx, [rsi + 0x22c]
0009aa29  e8824cfcff               call 0x5f6b0
0009aa2e  84c0                     test al, al
0009aa30  0f843affffff             je 0x9a970
0009aa36  b15c                     mov cl, 0x5c
0009aa38  e8434efcff               call 0x5f880
0009aa3d  e92effffff               jmp 0x9a970
0009aa42  4584ff                   test r15b, r15b
0009aa45  4c8b75c7                 mov r14, qword ptr [rbp - 0x39]
0009aa49  7511                     jne 0x9aa5c
0009aa4b  498bce                   mov rcx, r14
0009aa4e  e83dbeffff               call 0x96890
0009aa53  83f8ff                   cmp eax, -1
0009aa56  0f85826a9e00             jne 0xa814de
0009aa5c  48837dcf00               cmp qword ptr [rbp - 0x31], 0
0009aa61  7549                     jne 0x9aaac
0009aa63  488b83c0010000           mov rax, qword ptr [rbx + 0x1c0]
0009aa6a  83781800                 cmp dword ptr [rax + 0x18], 0
0009aa6e  0f85846a9e00             jne 0xa814f8
0009aa74  8b4338                   mov eax, dword ptr [rbx + 0x38]
0009aa77  3d54460000               cmp eax, 0x4654
0009aa7c  0f84bd6a9e00             je 0xa8153f
0009aa82  3d46540000               cmp eax, 0x5446
0009aa87  0f84bf6a9e00             je 0xa8154c
0009aa8d  32c0                     xor al, al
0009aa8f  eb01                     jmp 0x9aa92
0009aa91  cc                       int3
0009aa92  4584ff                   test r15b, r15b
0009aa95  7515                     jne 0x9aaac
0009aa97  84c0                     test al, al
0009aa99  7511                     jne 0x9aaac
0009aa9b  837b1004                 cmp dword ptr [rbx + 0x10], 4
0009aa9f  740b                     je 0x9aaac
0009aaa1  488bd6                   mov rdx, rsi
0009aaa4  488bcb                   mov rcx, rbx
0009aaa7  e834000000               call 0x9aae0
0009aaac  488b4d17                 mov rcx, qword ptr [rbp + 0x17]
0009aab0  4833cc                   xor rcx, rsp
0009aab3  e8b865f6ff               call 0x1070
0009aab8  488b9c2448010000         mov rbx, qword ptr [rsp + 0x148]
0009aac0  4881c4f0000000           add rsp, 0xf0
0009aac7  415f                     pop r15
0009aac9  415e                     pop r14
0009aacb  415d                     pop r13
0009aacd  415c                     pop r12
0009aacf  5f                       pop rdi
0009aad0  5e                       pop rsi
0009aad1  5d                       pop rbp
0009aad2  c3                       ret
