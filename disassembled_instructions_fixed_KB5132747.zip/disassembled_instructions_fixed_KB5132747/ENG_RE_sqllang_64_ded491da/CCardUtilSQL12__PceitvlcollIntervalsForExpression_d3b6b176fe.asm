; CCardUtilSQL12::PceitvlcollIntervalsForExpression
; sqllang.dll, primary RVA 0x214640, 1161 bytes in 1 chunk(s)

; chunk at RVA 0x214640 (1161 bytes)
00214640  4c894c2420               mov qword ptr [rsp + 0x20], r9
00214645  4889542410               mov qword ptr [rsp + 0x10], rdx
0021464a  48894c2408               mov qword ptr [rsp + 8], rcx
0021464f  55                       push rbp
00214650  53                       push rbx
00214651  56                       push rsi
00214652  57                       push rdi
00214653  4154                     push r12
00214655  4155                     push r13
00214657  4156                     push r14
00214659  4157                     push r15
0021465b  488d6c24f1               lea rbp, [rsp - 0xf]
00214660  4881ecf8000000           sub rsp, 0xf8
00214667  48c745dffeffffff         mov qword ptr [rbp - 0x21], 0xfffffffffffffffe
0021466f  498bf0                   mov rsi, r8
00214672  488bd9                   mov rbx, rcx
00214675  488b8a08010000           mov rcx, qword ptr [rdx + 0x108]
0021467c  488b01                   mov rax, qword ptr [rcx]
0021467f  ff90a8000000             call qword ptr [rax + 0xa8]
00214685  48894587                 mov qword ptr [rbp - 0x79], rax
00214689  488d45a7                 lea rax, [rbp - 0x59]
0021468d  4889442468               mov qword ptr [rsp + 0x68], rax
00214692  48895da7                 mov qword ptr [rbp - 0x59], rbx
00214696  c645af00                 mov byte ptr [rbp - 0x51], 0
0021469a  4533ff                   xor r15d, r15d
0021469d  44897db3                 mov dword ptr [rbp - 0x4d], r15d
002146a1  c745b701000000           mov dword ptr [rbp - 0x49], 1
002146a8  4c897dbf                 mov qword ptr [rbp - 0x41], r15
002146ac  488d3df53ce401           lea rdi, [rip + 0x1e43cf5]
002146b3  48897d97                 mov qword ptr [rbp - 0x69], rdi
002146b7  c7459f01000000           mov dword ptr [rbp - 0x61], 1
002146be  488d0523e2e501           lea rax, [rip + 0x1e5e223]
002146c5  48894597                 mov qword ptr [rbp - 0x69], rax
002146c9  488d555f                 lea rdx, [rbp + 0x5f]
002146cd  488d4da7                 lea rcx, [rbp - 0x59]
002146d1  e88a92dfff               call 0xd960
002146d6  c7456723110000           mov dword ptr [rbp + 0x67], 0x1123
002146dd  c644242001               mov byte ptr [rsp + 0x20], 1
002146e2  41b923110000             mov r9d, 0x1123
002146e8  4c8d0531f6f201           lea r8, [rip + 0x1f2f631]
002146ef  488bd3                   mov rdx, rbx
002146f2  418d4f68                 lea ecx, [r15 + 0x68]
002146f6  ff15b467cb01             call qword ptr [rip + 0x1cb67b4]
002146fc  4889442430               mov qword ptr [rsp + 0x30], rax
00214701  4885c0                   test rax, rax
00214704  0f8488d87001             je 0x1921f92
0021470a  488bd3                   mov rdx, rbx
0021470d  488bc8                   mov rcx, rax
00214710  e85b7efaff               call 0x1bc570
00214715  4c8be0                   mov r12, rax
00214718  eb01                     jmp 0x21471b
0021471a  cc                       int3
0021471b  8b4e18                   mov ecx, dword ptr [rsi + 0x18]
0021471e  488d442448               lea rax, [rsp + 0x48]
00214723  4889455f                 mov qword ptr [rbp + 0x5f], rax
00214727  48895c2448               mov qword ptr [rsp + 0x48], rbx
0021472c  c644245000               mov byte ptr [rsp + 0x50], 0
00214731  44897c2454               mov dword ptr [rsp + 0x54], r15d
00214736  b801000000               mov eax, 1
0021473b  85c9                     test ecx, ecx
0021473d  0f45c1                   cmovne eax, ecx
00214740  89442458                 mov dword ptr [rsp + 0x58], eax
00214744  4c897c2460               mov qword ptr [rsp + 0x60], r15
00214749  48897c2438               mov qword ptr [rsp + 0x38], rdi
0021474e  c744244001000000         mov dword ptr [rsp + 0x40], 1
00214756  488d0553dbe501           lea rax, [rip + 0x1e5db53]
0021475d  4889442438               mov qword ptr [rsp + 0x38], rax
00214762  4889742468               mov qword ptr [rsp + 0x68], rsi
00214767  488b5e10                 mov rbx, qword ptr [rsi + 0x10]
0021476b  488b03                   mov rax, qword ptr [rbx]
0021476e  488bcb                   mov rcx, rbx
00214771  ff5018                   call qword ptr [rax + 0x18]
00214774  83f859                   cmp eax, 0x59
00214777  0f8567d87001             jne 0x1921fe4
0021477d  837b4000                 cmp dword ptr [rbx + 0x40], 0
00214781  0f855dd87001             jne 0x1921fe4
00214787  458bf7                   mov r14d, r15d
0021478a  44397e18                 cmp dword ptr [rsi + 0x18], r15d
0021478e  0f8e83d87001             jle 0x1922017
00214794  498bff                   mov rdi, r15
00214797  8b4c2454                 mov ecx, dword ptr [rsp + 0x54]
0021479b  4533ed                   xor r13d, r13d
0021479e  6690                     nop
002147a0  488b4620                 mov rax, qword ptr [rsi + 0x20]
002147a4  4c8b3c07                 mov r15, qword ptr [rdi + rax]
002147a8  488b542460               mov rdx, qword ptr [rsp + 0x60]
002147ad  8b5c2458                 mov ebx, dword ptr [rsp + 0x58]
002147b1  4885d2                   test rdx, rdx
002147b4  0f8450feffff             je 0x21460a
002147ba  3bcb                     cmp ecx, ebx
002147bc  0f83d9d77001             jae 0x1921f9b
002147c2  8bc1                     mov eax, ecx
002147c4  4c893cc2                 mov qword ptr [rdx + rax*8], r15
002147c8  8b4c2454                 mov ecx, dword ptr [rsp + 0x54]
002147cc  ffc1                     inc ecx
002147ce  894c2454                 mov dword ptr [rsp + 0x54], ecx
002147d2  41ffc6                   inc r14d
002147d5  4883c708                 add rdi, 8
002147d9  443b7618                 cmp r14d, dword ptr [rsi + 0x18]
002147dd  7cc1                     jl 0x2147a0
002147df  4533ff                   xor r15d, r15d
002147e2  eb01                     jmp 0x2147e5
002147e4  cc                       int3
002147e5  8bf9                     mov edi, ecx
002147e7  894d5f                   mov dword ptr [rbp + 0x5f], ecx
002147ea  458bf7                   mov r14d, r15d
002147ed  4c8b6d77                 mov r13, qword ptr [rbp + 0x77]
002147f1  85c9                     test ecx, ecx
002147f3  0f84cf000000             je 0x2148c8
002147f9  660f1f0400               nop word ptr [rax + rax]
002147fe  6690                     nop
00214800  443bf1                   cmp r14d, ecx
00214803  0f8318d87001             jae 0x1922021
00214809  488b442460               mov rax, qword ptr [rsp + 0x60]
0021480e  498b3407                 mov rsi, qword ptr [r15 + rax]
00214812  eb01                     jmp 0x214815
00214814  cc                       int3
00214815  488b5e10                 mov rbx, qword ptr [rsi + 0x10]
00214819  48c744243000000000       mov qword ptr [rsp + 0x30], 0
00214822  48c7456700000000         mov qword ptr [rbp + 0x67], 0
0021482a  488b03                   mov rax, qword ptr [rbx]
0021482d  488d4d67                 lea rcx, [rbp + 0x67]
00214831  48894c2428               mov qword ptr [rsp + 0x28], rcx
00214836  488d4c2430               lea rcx, [rsp + 0x30]
0021483b  48894c2420               mov qword ptr [rsp + 0x20], rcx
00214840  4c8d4d97                 lea r9, [rbp - 0x69]
00214844  4c8bc6                   mov r8, rsi
00214847  488b5557                 mov rdx, qword ptr [rbp + 0x57]
0021484b  488bcb                   mov rcx, rbx
0021484e  ff9010050000             call qword ptr [rax + 0x510]
00214854  8bc8                     mov ecx, eax
00214856  83f801                   cmp eax, 1
00214859  0f85a3290000             jne 0x217202
0021485f  488b4d87                 mov rcx, qword ptr [rbp - 0x79]
00214863  488b01                   mov rax, qword ptr [rcx]
00214866  488b542430               mov rdx, qword ptr [rsp + 0x30]
0021486b  ff90c8000000             call qword ptr [rax + 0xc8]
00214871  488bd8                   mov rbx, rax
00214874  488945e7                 mov qword ptr [rbp - 0x19], rax
00214878  4885c0                   test rax, rax
0021487b  0f85a8d77001             jne 0x1922029
00214881  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
00214885  488b542430               mov rdx, qword ptr [rsp + 0x30]
0021488a  498bcc                   mov rcx, r12
0021488d  e88e7dfaff               call 0x1bc620
00214892  90                       nop
00214893  4885db                   test rbx, rbx
00214896  0f85a0d77001             jne 0x192203c
0021489c  488b4d67                 mov rcx, qword ptr [rbp + 0x67]
002148a0  4885c9                   test rcx, rcx
002148a3  740a                     je 0x2148af
002148a5  834108ff                 add dword ptr [rcx + 8], -1
002148a9  0f846599feff             je 0x1fe214
002148af  41ffc6                   inc r14d
002148b2  4983c708                 add r15, 8
002148b6  443bf7                   cmp r14d, edi
002148b9  730a                     jae 0x2148c5
002148bb  8b4c2454                 mov ecx, dword ptr [rsp + 0x54]
002148bf  e93cffffff               jmp 0x214800
002148c4  cc                       int3
002148c5  4533ff                   xor r15d, r15d
002148c8  4d85ed                   test r13, r13
002148cb  0f842c010000             je 0x2149fd
002148d1  498d5c2440               lea rbx, [r12 + 0x40]
002148d6  4885db                   test rbx, rbx
002148d9  0f841e010000             je 0x2149fd
002148df  488b4318                 mov rax, qword ptr [rbx + 0x18]
002148e3  4885c0                   test rax, rax
002148e6  7458                     je 0x214940
002148e8  488945c7                 mov qword ptr [rbp - 0x39], rax
002148ec  48c745cf00000000         mov qword ptr [rbp - 0x31], 0
002148f4  65488b142558000000       mov rdx, qword ptr gs:[0x58]
002148fd  488b057466cb01           mov rax, qword ptr [rip + 0x1cb6674]
00214904  8b08                     mov ecx, dword ptr [rax]
00214906  488b057366cb01           mov rax, qword ptr [rip + 0x1cb6673]
0021490d  8b00                     mov eax, dword ptr [rax]
0021490f  480304ca                 add rax, qword ptr [rdx + rcx*8]
00214913  488b4008                 mov rax, qword ptr [rax + 8]
00214917  488b4848                 mov rcx, qword ptr [rax + 0x48]
0021491b  488d81b0020000           lea rax, [rcx + 0x2b0]
00214922  bab8020000               mov edx, 0x2b8
00214927  4885c9                   test rcx, rcx
0021492a  480f44c2                 cmove rax, rdx
0021492e  488b00                   mov rax, qword ptr [rax]
00214931  488945d7                 mov qword ptr [rbp - 0x29], rax
00214935  6666660f1f840000000000   nop word ptr [rax + rax]
00214940  4885db                   test rbx, rbx
00214943  0f84b4000000             je 0x2149fd
00214949  48837b1800               cmp qword ptr [rbx + 0x18], 0
0021494e  0f84a9000000             je 0x2149fd
00214954  4c8d4557                 lea r8, [rbp + 0x57]
00214958  488d55c7                 lea rdx, [rbp - 0x39]
0021495c  e80f98e4ff               call 0x5e170
00214961  84c0                     test al, al
00214963  0f8494000000             je 0x2149fd
00214969  8b4557                   mov eax, dword ptr [rbp + 0x57]
0021496c  8bc8                     mov ecx, eax
0021496e  c1e908                   shr ecx, 8
00214971  440fb6c0                 movzx r8d, al
00214975  488b45d7                 mov rax, qword ptr [rbp - 0x29]
00214979  488b4010                 mov rax, qword ptr [rax + 0x10]
0021497d  3b480c                   cmp ecx, dword ptr [rax + 0xc]
00214980  0f8352d77001             jae 0x19220d8
00214986  0faee8                   lfence
00214989  488b4018                 mov rax, qword ptr [rax + 0x18]
0021498d  488b14c8                 mov rdx, qword ptr [rax + rcx*8]
00214991  eb01                     jmp 0x214994
00214993  cc                       int3
00214994  4a8b3cc2                 mov rdi, qword ptr [rdx + r8*8]
00214998  48897d87                 mov qword ptr [rbp - 0x79], rdi
0021499c  4c897d8f                 mov qword ptr [rbp - 0x71], r15
002149a0  498d4c2418               lea rcx, [r12 + 0x18]
002149a5  4c8d4587                 lea r8, [rbp - 0x79]
002149a9  488d55ef                 lea rdx, [rbp - 0x11]
002149ad  e82e06e5ff               call 0x64fe0
002149b2  488b4008                 mov rax, qword ptr [rax + 8]
002149b6  80782000                 cmp byte ptr [rax + 0x20], 0
002149ba  0f8521d77001             jne 0x19220e1
002149c0  488b4018                 mov rax, qword ptr [rax + 0x18]
002149c4  4885c0                   test rax, rax
002149c7  0f8473ffffff             je 0x214940
002149cd  83781c01                 cmp dword ptr [rax + 0x1c], 1
002149d1  0f8569ffffff             jne 0x214940
002149d7  488b4028                 mov rax, qword ptr [rax + 0x28]
002149db  488b08                   mov rcx, qword ptr [rax]
002149de  83791802                 cmp dword ptr [rcx + 0x18], 2
002149e2  0f94c0                   sete al
002149e5  84c0                     test al, al
002149e7  0f8453ffffff             je 0x214940
002149ed  488bd7                   mov rdx, rdi
002149f0  498bcd                   mov rcx, r13
002149f3  e8e871e5ff               call 0x6bbe0
002149f8  e943ffffff               jmp 0x214940
002149fd  488b4d7f                 mov rcx, qword ptr [rbp + 0x7f]
00214a01  4885c9                   test rcx, rcx
00214a04  7447                     je 0x214a4d
00214a06  410fb6442460             movzx eax, byte ptr [r12 + 0x60]
00214a0c  8801                     mov byte ptr [rcx], al
00214a0e  eb3d                     jmp 0x214a4d
00214a10  cc                       int3
00214a11  c60001                   mov byte ptr [rax], 1
00214a14  4183442408ff             add dword ptr [r12 + 8], -1
00214a1a  750f                     jne 0x214a2b
00214a1c  498b0424                 mov rax, qword ptr [r12]
00214a20  ba01000000               mov edx, 1
00214a25  498bcc                   mov rcx, r12
00214a28  ff10                     call qword ptr [rax]
00214a2a  90                       nop
00214a2b  488b4d67                 mov rcx, qword ptr [rbp + 0x67]
00214a2f  4885c9                   test rcx, rcx
00214a32  7410                     je 0x214a44
00214a34  834108ff                 add dword ptr [rcx + 8], -1
00214a38  750a                     jne 0x214a44
00214a3a  488b01                   mov rax, qword ptr [rcx]
00214a3d  ba01000000               mov edx, 1
00214a42  ff10                     call qword ptr [rax]
00214a44  4533ff                   xor r15d, r15d
00214a47  458be7                   mov r12d, r15d
00214a4a  eb01                     jmp 0x214a4d
00214a4c  cc                       int3
00214a4d  488d055cd8e501           lea rax, [rip + 0x1e5d85c]
00214a54  4889442438               mov qword ptr [rsp + 0x38], rax
00214a59  488d1d4839e401           lea rbx, [rip + 0x1e43948]
00214a60  48895c2438               mov qword ptr [rsp + 0x38], rbx
00214a65  488d442448               lea rax, [rsp + 0x48]
00214a6a  4889455f                 mov qword ptr [rbp + 0x5f], rax
00214a6e  488d4c2448               lea rcx, [rsp + 0x48]
00214a73  e82828e5ff               call 0x672a0
00214a78  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
00214a7d  4885c9                   test rcx, rcx
00214a80  740b                     je 0x214a8d
00214a82  ff152065cb01             call qword ptr [rip + 0x1cb6520]
00214a88  4c897c2460               mov qword ptr [rsp + 0x60], r15
00214a8d  44897c2458               mov dword ptr [rsp + 0x58], r15d
00214a92  488d054fdee501           lea rax, [rip + 0x1e5de4f]
00214a99  48894597                 mov qword ptr [rbp - 0x69], rax
00214a9d  48895d97                 mov qword ptr [rbp - 0x69], rbx
00214aa1  488d45a7                 lea rax, [rbp - 0x59]
00214aa5  4889455f                 mov qword ptr [rbp + 0x5f], rax
00214aa9  488d4da7                 lea rcx, [rbp - 0x59]
00214aad  e87e06e5ff               call 0x65130
00214ab2  498bc4                   mov rax, r12
00214ab5  4881c4f8000000           add rsp, 0xf8
00214abc  415f                     pop r15
00214abe  415e                     pop r14
00214ac0  415d                     pop r13
00214ac2  415c                     pop r12
00214ac4  5f                       pop rdi
00214ac5  5e                       pop rsi
00214ac6  5b                       pop rbx
00214ac7  5d                       pop rbp
00214ac8  c3                       ret
