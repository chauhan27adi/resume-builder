; CAutoSetupSQLExecContextsForInternalTasks::Teardown
; sqllang.dll, primary RVA 0x39920, 152 bytes in 3 chunk(s)

; chunk at RVA 0x39920 (19 bytes)
00039920  4053                     push rbx
00039922  56                       push rsi
00039923  4883ec28                 sub rsp, 0x28
00039927  8b4118                   mov eax, dword ptr [rcx + 0x18]
0003992a  8bf2                     mov esi, edx
0003992c  488bd9                   mov rbx, rcx
0003992f  85c0                     test eax, eax
00039931  744a                     je 0x3997d

; chunk at RVA 0x39933 (74 bytes)
00039933  48896c2448               mov qword ptr [rsp + 0x48], rbp
00039938  488d2dc166fcff           lea rbp, [rip - 0x3993f]
0003993f  4c89742420               mov qword ptr [rsp + 0x20], r14
00039944  4533f6                   xor r14d, r14d
00039947  48897c2450               mov qword ptr [rsp + 0x50], rdi
0003994c  ffc8                     dec eax
0003994e  894318                   mov dword ptr [rbx + 0x18], eax
00039951  ffc8                     dec eax
00039953  83f809                   cmp eax, 9
00039956  770f                     ja 0x39967
00039958  4898                     cdqe
0003995a  8b8c8590990300           mov ecx, dword ptr [rbp + rax*4 + 0x39990]
00039961  4803cd                   add rcx, rbp
00039964  ffe1                     jmp rcx
00039966  cc                       int3
00039967  8b4318                   mov eax, dword ptr [rbx + 0x18]
0003996a  85c0                     test eax, eax
0003996c  75de                     jne 0x3994c
0003996e  4c8b742420               mov r14, qword ptr [rsp + 0x20]
00039973  488b7c2450               mov rdi, qword ptr [rsp + 0x50]
00039978  488b6c2448               mov rbp, qword ptr [rsp + 0x48]

; chunk at RVA 0x3997d (59 bytes)
0003997d  4883c428                 add rsp, 0x28
00039981  5e                       pop rsi
00039982  5b                       pop rbx
00039983  c3                       ret
00039984  90                       nop
00039985  90                       nop
00039986  90                       nop
00039987  90                       nop
00039988  90                       nop
00039989  90                       nop
0003998a  90                       nop
0003998b  90                       nop
0003998c  90                       nop
0003998d  90                       nop
0003998e  90                       nop
0003998f  90                       nop
00039990  8d9803006799             lea ebx, [rax - 0x6698fffd]
00039996  0300                     add eax, dword ptr [rax]
00039998  6799                     cdq
0003999a  0300                     add eax, dword ptr [rax]
0003999c  e49b                     in al, 0x9b
0003999e  0300                     add eax, dword ptr [rax]
000399a0  6c                       insb byte ptr [rdi], dx
000399a1  9b                       wait
000399a2  0300                     add eax, dword ptr [rax]
000399a4  6799                     cdq
000399a6  0300                     add eax, dword ptr [rax]
000399a8  4a9b                     wait
000399aa  0300                     add eax, dword ptr [rax]
000399ac  6799                     cdq
000399ae  0300                     add eax, dword ptr [rax]
