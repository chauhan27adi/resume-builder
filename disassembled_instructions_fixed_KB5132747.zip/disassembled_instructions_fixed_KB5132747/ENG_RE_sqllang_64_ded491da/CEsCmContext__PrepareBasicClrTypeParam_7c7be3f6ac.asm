; CEsCmContext::PrepareBasicClrTypeParam
; sqllang.dll, primary RVA 0x717010, 1664 bytes in 1 chunk(s)

; chunk at RVA 0x717010 (1664 bytes)
00717010  48895c2408               mov qword ptr [rsp + 8], rbx
00717015  4889742418               mov qword ptr [rsp + 0x18], rsi
0071701a  48897c2420               mov qword ptr [rsp + 0x20], rdi
0071701f  55                       push rbp
00717020  4156                     push r14
00717022  4157                     push r15
00717024  488bec                   mov rbp, rsp
00717027  4883ec30                 sub rsp, 0x30
0071702b  837a4002                 cmp dword ptr [rdx + 0x40], 2
0071702f  488bf2                   mov rsi, rdx
00717032  448b7244                 mov r14d, dword ptr [rdx + 0x44]
00717036  488bf9                   mov rdi, rcx
00717039  0fb65a49                 movzx ebx, byte ptr [rdx + 0x49]
0071703d  0f8555010000             jne 0x717198
00717043  f6424c02                 test byte ptr [rdx + 0x4c], 2
00717047  0f844b010000             je 0x717198
0071704d  84db                     test bl, bl
0071704f  747e                     je 0x7170cf
00717051  4533c0                   xor r8d, r8d
00717054  4883c228                 add rdx, 0x28
00717058  e8e3b4ffff               call 0x712540
0071705d  894660                   mov dword ptr [rsi + 0x60], eax
00717060  8bd8                     mov ebx, eax
00717062  488bcf                   mov rcx, rdi
00717065  3dff000000               cmp eax, 0xff
0071706a  770c                     ja 0x717078
0071706c  ba12000000               mov edx, 0x12
00717071  e8eab9ffff               call 0x712a60
00717076  eb19                     jmp 0x717091
00717078  ba0d010000               mov edx, 0x10d
0071707d  e8deb9ffff               call 0x712a60
00717082  0fb6d3                   movzx edx, bl
00717085  488bcf                   mov rcx, rdi
00717088  e853b2ffff               call 0x7122e0
0071708d  66c1eb08                 shr bx, 8
00717091  0fb6d3                   movzx edx, bl
00717094  488bcf                   mov rcx, rdi
00717097  e844b2ffff               call 0x7122e0
0071709c  ba15010000               mov edx, 0x115
007170a1  488bcf                   mov rcx, rdi
007170a4  e8b7b9ffff               call 0x712a60
007170a9  448b463c                 mov r8d, dword ptr [rsi + 0x3c]
007170ad  4c8d4d28                 lea r9, [rbp + 0x28]
007170b1  488b5708                 mov rdx, qword ptr [rdi + 8]
007170b5  488b0f                   mov rcx, qword ptr [rdi]
007170b8  e823b5f9ff               call 0x6b25e0
007170bd  83f801                   cmp eax, 1
007170c0  0f85c6040000             jne 0x71758c
007170c6  448d4018                 lea r8d, [rax + 0x18]
007170ca  e9b3040000               jmp 0x717582
007170cf  4183c6fe                 add r14d, -2
007170d3  4183fe0c                 cmp r14d, 0xc
007170d7  0f878b000000             ja 0x717168
007170dd  488d151c8f8eff           lea rdx, [rip - 0x7170e4]
007170e4  4963c6                   movsxd rax, r14d
007170e7  8b848228767100           mov eax, dword ptr [rdx + rax*4 + 0x717628]
007170ee  4803c2                   add rax, rdx
007170f1  ffe0                     jmp rax
007170f3  ba16000000               mov edx, 0x16
007170f8  e863b9ffff               call 0x712a60
007170fd  e9f1040000               jmp 0x7175f3
00717102  ba21000000               mov edx, 0x21
00717107  e854b9ffff               call 0x712a60
0071710c  33d2                     xor edx, edx
0071710e  488bcf                   mov rcx, rdi
00717111  e88aa9ffff               call 0x711aa0
00717116  e9d8040000               jmp 0x7175f3
0071711b  ba22000000               mov edx, 0x22
00717120  e83bb9ffff               call 0x712a60
00717125  33d2                     xor edx, edx
00717127  488bcf                   mov rcx, rdi
0071712a  e8b1b1ffff               call 0x7122e0
0071712f  33d2                     xor edx, edx
00717131  488bcf                   mov rcx, rdi
00717134  e8a7b1ffff               call 0x7122e0
00717139  33d2                     xor edx, edx
0071713b  488bcf                   mov rcx, rdi
0071713e  e89db1ffff               call 0x7122e0
00717143  33d2                     xor edx, edx
00717145  488bcf                   mov rcx, rdi
00717148  e893b1ffff               call 0x7122e0
0071714d  e9a1040000               jmp 0x7175f3
00717152  ba23000000               mov edx, 0x23
00717157  ebae                     jmp 0x717107
00717159  ba14000000               mov edx, 0x14
0071715e  e8fdb8ffff               call 0x712a60
00717163  e98b040000               jmp 0x7175f3
00717168  488d05b913a401           lea rax, [rip + 0x1a413b9]
0071716f  41b912110000             mov r9d, 0x1112
00717175  4c8d0584afdf01           lea r8, [rip + 0x1dfaf84]
0071717c  4889442420               mov qword ptr [rsp + 0x20], rax
00717181  488d15b8d8df01           lea rdx, [rip + 0x1dfd8b8]
00717188  b901000000               mov ecx, 1
0071718d  ff15e53c7b01             call qword ptr [rip + 0x17b3ce5]
00717193  e95b040000               jmp 0x7175f3
00717198  4183fe0e                 cmp r14d, 0xe
0071719c  7409                     je 0x7171a7
0071719e  84db                     test bl, bl
007171a0  7505                     jne 0x7171a7
007171a2  e889720000               call 0x71e430
007171a7  4533c0                   xor r8d, r8d
007171aa  488bd6                   mov rdx, rsi
007171ad  488bcf                   mov rcx, rdi
007171b0  e83bbfffff               call 0x7130f0
007171b5  4183c6fe                 add r14d, -2
007171b9  4183fe0c                 cmp r14d, 0xc
007171bd  0f8705040000             ja 0x7175c8
007171c3  488d15368e8eff           lea rdx, [rip - 0x7171ca]
007171ca  4963c6                   movsxd rax, r14d
007171cd  8b84825c767100           mov eax, dword ptr [rdx + rax*4 + 0x71765c]
007171d4  4803c2                   add rax, rdx
007171d7  ffe0                     jmp rax
007171d9  ba28000000               mov edx, 0x28
007171de  488bcf                   mov rcx, rdi
007171e1  e87ab8ffff               call 0x712a60
007171e6  4533c0                   xor r8d, r8d
007171e9  84db                     test bl, bl
007171eb  410f95c0                 setne r8b
007171ef  4183c01c                 add r8d, 0x1c
007171f3  488b5708                 mov rdx, qword ptr [rdi + 8]
007171f7  4c8d4d28                 lea r9, [rbp + 0x28]
007171fb  488b0f                   mov rcx, qword ptr [rdi]
007171fe  e89db6f9ff               call 0x6b28a0
00717203  83f801                   cmp eax, 1
00717206  750d                     jne 0x717215
00717208  8bd0                     mov edx, eax
0071720a  448d4014                 lea r8d, [rax + 0x14]
0071720e  33c9                     xor ecx, ecx
00717210  e81b2d0100               call 0x729f30
00717215  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
00717218  488bcf                   mov rcx, rdi
0071721b  0fb6d3                   movzx edx, bl
0071721e  e8bdb0ffff               call 0x7122e0
00717223  0fb7d3                   movzx edx, bx
00717226  488bcf                   mov rcx, rdi
00717229  66c1ea08                 shr dx, 8
0071722d  e8aeb0ffff               call 0x7122e0
00717232  c1eb10                   shr ebx, 0x10
00717235  488bcf                   mov rcx, rdi
00717238  0fb6d3                   movzx edx, bl
0071723b  e8a0b0ffff               call 0x7122e0
00717240  66c1eb08                 shr bx, 8
00717244  488bcf                   mov rcx, rdi
00717247  0fb6d3                   movzx edx, bl
0071724a  e891b0ffff               call 0x7122e0
0071724f  e99f030000               jmp 0x7175f3
00717254  488b4620                 mov rax, qword ptr [rsi + 0x20]
00717258  ba28000000               mov edx, 0x28
0071725d  488bcf                   mov rcx, rdi
00717260  803830                   cmp byte ptr [rax], 0x30
00717263  7517                     jne 0x71727c
00717265  e8f6b7ffff               call 0x712a60
0071726a  4533c0                   xor r8d, r8d
0071726d  84db                     test bl, bl
0071726f  410f95c0                 setne r8b
00717273  4183c023                 add r8d, 0x23
00717277  e977ffffff               jmp 0x7171f3
0071727c  e8dfb7ffff               call 0x712a60
00717281  4533c0                   xor r8d, r8d
00717284  84db                     test bl, bl
00717286  410f95c0                 setne r8b
0071728a  4183c025                 add r8d, 0x25
0071728e  e960ffffff               jmp 0x7171f3
00717293  ba28000000               mov edx, 0x28
00717298  488bcf                   mov rcx, rdi
0071729b  e8c0b7ffff               call 0x712a60
007172a0  4533c0                   xor r8d, r8d
007172a3  84db                     test bl, bl
007172a5  410f95c0                 setne r8b
007172a9  4183c02b                 add r8d, 0x2b
007172ad  e941ffffff               jmp 0x7171f3
007172b2  ba28000000               mov edx, 0x28
007172b7  488bcf                   mov rcx, rdi
007172ba  e8a1b7ffff               call 0x712a60
007172bf  4533c0                   xor r8d, r8d
007172c2  84db                     test bl, bl
007172c4  410f95c0                 setne r8b
007172c8  4183c031                 add r8d, 0x31
007172cc  e922ffffff               jmp 0x7171f3
007172d1  ba28000000               mov edx, 0x28
007172d6  488bcf                   mov rcx, rdi
007172d9  e882b7ffff               call 0x712a60
007172de  4533c0                   xor r8d, r8d
007172e1  84db                     test bl, bl
007172e3  410f95c0                 setne r8b
007172e7  4183c037                 add r8d, 0x37
007172eb  e903ffffff               jmp 0x7171f3
007172f0  ba28000000               mov edx, 0x28
007172f5  488bcf                   mov rcx, rdi
007172f8  e863b7ffff               call 0x712a60
007172fd  4533c0                   xor r8d, r8d
00717300  84db                     test bl, bl
00717302  410f95c0                 setne r8b
00717306  4183c03d                 add r8d, 0x3d
0071730a  e9e4feffff               jmp 0x7171f3
0071730f  ba28000000               mov edx, 0x28
00717314  488bcf                   mov rcx, rdi
00717317  e844b7ffff               call 0x712a60
0071731c  4533c0                   xor r8d, r8d
0071731f  84db                     test bl, bl
00717321  410f95c0                 setne r8b
00717325  4183c043                 add r8d, 0x43
00717329  e9c5feffff               jmp 0x7171f3
0071732e  ba28000000               mov edx, 0x28
00717333  488bcf                   mov rcx, rdi
00717336  e825b7ffff               call 0x712a60
0071733b  4533c0                   xor r8d, r8d
0071733e  84db                     test bl, bl
00717340  410f95c0                 setne r8b
00717344  4183c04a                 add r8d, 0x4a
00717348  e9a6feffff               jmp 0x7171f3
0071734d  4c8b4620                 mov r8, qword ptr [rsi + 0x20]
00717351  410fb600                 movzx eax, byte ptr [r8]
00717355  0fb68c10403b0202         movzx ecx, byte ptr [rax + rdx + 0x2023b40]
0071735d  80bc110023070200         cmp byte ptr [rcx + rdx + 0x2072300], 0
00717365  7424                     je 0x71738b
00717367  b8ffff0000               mov eax, 0xffff
0071736c  6641394010               cmp word ptr [r8 + 0x10], ax
00717371  7418                     je 0x71738b
00717373  ba28000000               mov edx, 0x28
00717378  488bcf                   mov rcx, rdi
0071737b  e8e0b6ffff               call 0x712a60
00717380  41b849000000             mov r8d, 0x49
00717386  e968feffff               jmp 0x7171f3
0071738b  837e4002                 cmp dword ptr [rsi + 0x40], 2
0071738f  7415                     je 0x7173a6
00717391  488b87a8000000           mov rax, qword ptr [rdi + 0xa8]
00717398  ba01000000               mov edx, 1
0071739d  80b87501000000           cmp byte ptr [rax + 0x175], 0
007173a4  7405                     je 0x7173ab
007173a6  ba02000000               mov edx, 2
007173ab  488bcf                   mov rcx, rdi
007173ae  e80dbaffff               call 0x712dc0
007173b3  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
007173b7  ff158b4a7b01             call qword ptr [rip + 0x17b4a8b]
007173bd  8bc8                     mov ecx, eax
007173bf  ff158b4a7b01             call qword ptr [rip + 0x17b4a8b]
007173c5  ba21000000               mov edx, 0x21
007173ca  488bcf                   mov rcx, rdi
007173cd  8bd8                     mov ebx, eax
007173cf  e88cb6ffff               call 0x712a60
007173d4  8bd3                     mov edx, ebx
007173d6  488bcf                   mov rcx, rdi
007173d9  e8c2a6ffff               call 0x711aa0
007173de  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
007173e2  ff15604a7b01             call qword ptr [rip + 0x17b4a60]
007173e8  448bc8                   mov r9d, eax
007173eb  0fbae010                 bt eax, 0x10
007173ef  7307                     jae 0x7173f8
007173f1  ba00800000               mov edx, 0x8000
007173f6  eb35                     jmp 0x71742d
007173f8  418bc9                   mov ecx, r9d
007173fb  c1e90c                   shr ecx, 0xc
007173fe  83e101                   and ecx, 1
00717401  448bc1                   mov r8d, ecx
00717404  4183c802                 or r8d, 2
00717408  2500200000               and eax, 0x2000
0071740d  418bc1                   mov eax, r9d
00717410  440f44c1                 cmove r8d, ecx
00717414  418bd0                   mov edx, r8d
00717417  83ca08                   or edx, 8
0071741a  2500400000               and eax, 0x4000
0071741f  410f44d0                 cmove edx, r8d
00717423  410fbae10f               bt r9d, 0xf
00717428  7303                     jae 0x71742d
0071742a  83ca10                   or edx, 0x10
0071742d  488bcf                   mov rcx, rdi
00717430  e88bb9ffff               call 0x712dc0
00717435  ba04000000               mov edx, 4
0071743a  488bcf                   mov rcx, rdi
0071743d  e81eb6ffff               call 0x712a60
00717442  ba28000000               mov edx, 0x28
00717447  488bcf                   mov rcx, rdi
0071744a  e811b6ffff               call 0x712a60
0071744f  488b5708                 mov rdx, qword ptr [rdi + 8]
00717453  4c8d4d28                 lea r9, [rbp + 0x28]
00717457  488b0f                   mov rcx, qword ptr [rdi]
0071745a  41b8a4000000             mov r8d, 0xa4
00717460  e83bb4f9ff               call 0x6b28a0
00717465  83f801                   cmp eax, 1
00717468  750d                     jne 0x717477
0071746a  8bd0                     mov edx, eax
0071746c  448d4014                 lea r8d, [rax + 0x14]
00717470  33c9                     xor ecx, ecx
00717472  e8b92a0100               call 0x729f30
00717477  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071747a  488bcf                   mov rcx, rdi
0071747d  0fb6d3                   movzx edx, bl
00717480  e85baeffff               call 0x7122e0
00717485  0fb7d3                   movzx edx, bx
00717488  488bcf                   mov rcx, rdi
0071748b  66c1ea08                 shr dx, 8
0071748f  e84caeffff               call 0x7122e0
00717494  c1eb10                   shr ebx, 0x10
00717497  488bcf                   mov rcx, rdi
0071749a  0fb6d3                   movzx edx, bl
0071749d  e83eaeffff               call 0x7122e0
007174a2  66c1eb08                 shr bx, 8
007174a6  488bcf                   mov rcx, rdi
007174a9  0fb6d3                   movzx edx, bl
007174ac  e82faeffff               call 0x7122e0
007174b1  ba25000000               mov edx, 0x25
007174b6  488bcf                   mov rcx, rdi
007174b9  e8a2b5ffff               call 0x712a60
007174be  ba25000000               mov edx, 0x25
007174c3  488bcf                   mov rcx, rdi
007174c6  e895b5ffff               call 0x712a60
007174cb  ba28000000               mov edx, 0x28
007174d0  488bcf                   mov rcx, rdi
007174d3  e888b5ffff               call 0x712a60
007174d8  488b5708                 mov rdx, qword ptr [rdi + 8]
007174dc  4c8d4d28                 lea r9, [rbp + 0x28]
007174e0  488b0f                   mov rcx, qword ptr [rdi]
007174e3  41b8ac000000             mov r8d, 0xac
007174e9  e8b2b3f9ff               call 0x6b28a0
007174ee  83f801                   cmp eax, 1
007174f1  750d                     jne 0x717500
007174f3  8bd0                     mov edx, eax
007174f5  448d4014                 lea r8d, [rax + 0x14]
007174f9  33c9                     xor ecx, ecx
007174fb  e8302a0100               call 0x729f30
00717500  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
00717503  488bcf                   mov rcx, rdi
00717506  0fb6d3                   movzx edx, bl
00717509  e8d2adffff               call 0x7122e0
0071750e  0fb7d3                   movzx edx, bx
00717511  488bcf                   mov rcx, rdi
00717514  66c1ea08                 shr dx, 8
00717518  e8c3adffff               call 0x7122e0
0071751d  c1eb10                   shr ebx, 0x10
00717520  488bcf                   mov rcx, rdi
00717523  0fb6d3                   movzx edx, bl
00717526  e8b5adffff               call 0x7122e0
0071752b  66c1eb08                 shr bx, 8
0071752f  488bcf                   mov rcx, rdi
00717532  0fb6d3                   movzx edx, bl
00717535  e8a6adffff               call 0x7122e0
0071753a  4533c0                   xor r8d, r8d
0071753d  488d5628                 lea rdx, [rsi + 0x28]
00717541  488bcf                   mov rcx, rdi
00717544  e8f7afffff               call 0x712540
00717549  8bd0                     mov edx, eax
0071754b  894660                   mov dword ptr [rsi + 0x60], eax
0071754e  488bcf                   mov rcx, rdi
00717551  e8fab9ffff               call 0x712f50
00717556  ba28000000               mov edx, 0x28
0071755b  488bcf                   mov rcx, rdi
0071755e  e8fdb4ffff               call 0x712a60
00717563  488b5708                 mov rdx, qword ptr [rdi + 8]
00717567  4c8d4d28                 lea r9, [rbp + 0x28]
0071756b  488b0f                   mov rcx, qword ptr [rdi]
0071756e  41b8b2000000             mov r8d, 0xb2
00717574  e827b3f9ff               call 0x6b28a0
00717579  83f801                   cmp eax, 1
0071757c  750e                     jne 0x71758c
0071757e  448d4014                 lea r8d, [rax + 0x14]
00717582  33c9                     xor ecx, ecx
00717584  8d5101                   lea edx, [rcx + 1]
00717587  e8a4290100               call 0x729f30
0071758c  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071758f  488bcf                   mov rcx, rdi
00717592  0fb6d3                   movzx edx, bl
00717595  e846adffff               call 0x7122e0
0071759a  0fb7d3                   movzx edx, bx
0071759d  488bcf                   mov rcx, rdi
007175a0  66c1ea08                 shr dx, 8
007175a4  e837adffff               call 0x7122e0
007175a9  c1eb10                   shr ebx, 0x10
007175ac  488bcf                   mov rcx, rdi
007175af  0fb6d3                   movzx edx, bl
007175b2  e829adffff               call 0x7122e0
007175b7  66c1eb08                 shr bx, 8
007175bb  488bcf                   mov rcx, rdi
007175be  0fb6d3                   movzx edx, bl
007175c1  e81aadffff               call 0x7122e0
007175c6  eb47                     jmp 0x71760f
007175c8  488d05590fa401           lea rax, [rip + 0x1a40f59]
007175cf  41b9e4100000             mov r9d, 0x10e4
007175d5  4c8d0524abdf01           lea r8, [rip + 0x1dfab24]
007175dc  4889442420               mov qword ptr [rsp + 0x20], rax
007175e1  488d1558d4df01           lea rdx, [rip + 0x1dfd458]
007175e8  b901000000               mov ecx, 1
007175ed  ff1585387b01             call qword ptr [rip + 0x17b3885]
007175f3  4533c0                   xor r8d, r8d
007175f6  488d5628                 lea rdx, [rsi + 0x28]
007175fa  488bcf                   mov rcx, rdi
007175fd  e83eafffff               call 0x712540
00717602  8bd0                     mov edx, eax
00717604  894660                   mov dword ptr [rsi + 0x60], eax
00717607  488bcf                   mov rcx, rdi
0071760a  e841b9ffff               call 0x712f50
0071760f  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00717614  488b742460               mov rsi, qword ptr [rsp + 0x60]
00717619  488b7c2468               mov rdi, qword ptr [rsp + 0x68]
0071761e  4883c430                 add rsp, 0x30
00717622  415f                     pop r15
00717624  415e                     pop r14
00717626  5d                       pop rbp
00717627  c3                       ret
00717628  f37071                   jo 0x71769c
0071762b  00f3                     add bl, dh
0071762d  7071                     jo 0x7176a0
0071762f  006871                   add byte ptr [rax + 0x71], ch
00717632  7100                     jno 0x717634
00717634  f37071                   jo 0x7176a8
00717637  00f3                     add bl, dh
00717639  7071                     jo 0x7176ac
0071763b  006871                   add byte ptr [rax + 0x71], ch
0071763e  7100                     jno 0x717640
00717640  f37071                   jo 0x7176b4
00717643  006871                   add byte ptr [rax + 0x71], ch
00717646  7100                     jno 0x717648
00717648  027171                   add dh, byte ptr [rcx + 0x71]
0071764b  006871                   add byte ptr [rax + 0x71], ch
0071764e  7100                     jno 0x717650
00717650  1b7171                   sbb esi, dword ptr [rcx + 0x71]
00717653  005271                   add byte ptr [rdx + 0x71], dl
00717656  7100                     jno 0x717658
00717658  59                       pop rcx
00717659  7171                     jno 0x7176cc
0071765b  00d9                     add cl, bl
0071765d  7171                     jno 0x7176d0
0071765f  002e                     add byte ptr [rsi], ch
00717661  7371                     jae 0x7176d4
00717663  00c8                     add al, cl
00717665  7571                     jne 0x7176d8
00717667  00547271                 add byte ptr [rdx + rsi*2 + 0x71], dl
0071766b  0093727100c8             add byte ptr [rbx - 0x37ff8e8e], dl
00717671  7571                     jne 0x7176e4
00717673  00b2727100c8             add byte ptr [rdx - 0x37ff8e8e], dh
00717679  7571                     jne 0x7176ec
0071767b  00d1                     add cl, dl
0071767d  7271                     jb 0x7176f0
0071767f  00c8                     add al, cl
00717681  7571                     jne 0x7176f4
00717683  00f0                     add al, dh
00717685  7271                     jb 0x7176f8
00717687  000f                     add byte ptr [rdi], cl
00717689  7371                     jae 0x7176fc
0071768b  004d73                   add byte ptr [rbp + 0x73], cl
0071768e  7100                     jno 0x717690
