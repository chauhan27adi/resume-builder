; CContainmentBreachHelper::FireContainmentBreachXEvent
; sqllang.dll, primary RVA 0x333c90, 314 bytes in 3 chunk(s)

; chunk at RVA 0x18ce6a (154 bytes)
0018ce6a  4889bc2460010000         mov qword ptr [rsp + 0x160], rdi
0018ce72  bfffffffff               mov edi, 0xffffffff
0018ce77  4885ed                   test rbp, rbp
0018ce7a  0f84c0b76c00             je 0x858640
0018ce80  8b7d48                   mov edi, dword ptr [rbp + 0x48]
0018ce83  83ff08                   cmp edi, 8
0018ce86  0f84a9b76c00             je 0x858635
0018ce8c  448bc6                   mov r8d, esi
0018ce8f  4885db                   test rbx, rbx
0018ce92  7447                     je 0x18cedb
0018ce94  488b4b08                 mov rcx, qword ptr [rbx + 8]
0018ce98  488bd1                   mov rdx, rcx
0018ce9b  8b4120                   mov eax, dword ptr [rcx + 0x20]
0018ce9e  d1e8                     shr eax, 1
0018cea0  a801                     test al, 1
0018cea2  740d                     je 0x18ceb1
0018cea4  4839b1a8010000           cmp qword ptr [rcx + 0x1a8], rsi
0018ceab  0f85d9b76c00             jne 0x85868a
0018ceb1  4885ed                   test rbp, rbp
0018ceb4  0f84d0b76c00             je 0x85868a
0018ceba  8b453c                   mov eax, dword ptr [rbp + 0x3c]
0018cebd  85c0                     test eax, eax
0018cebf  0f84c5b76c00             je 0x85868a
0018cec5  448b4540                 mov r8d, dword ptr [rbp + 0x40]
0018cec9  8bf0                     mov esi, eax
0018cecb  eb01                     jmp 0x18cece
0018cecd  cc                       int3
0018cece  488b4a10                 mov rcx, qword ptr [rdx + 0x10]
0018ced2  4885c9                   test rcx, rcx
0018ced5  0f851d4b0100             jne 0x1a19f8
0018cedb  44897c2440               mov dword ptr [rsp + 0x40], r15d
0018cee0  4d8bcc                   mov r9, r12
0018cee3  4c896c2430               mov qword ptr [rsp + 0x30], r13
0018cee8  8bd6                     mov edx, esi
0018ceea  418bce                   mov ecx, r14d
0018ceed  897c2428                 mov dword ptr [rsp + 0x28], edi
0018cef1  e87ab30000               call 0x198270
0018cef6  488bbc2460010000         mov rdi, qword ptr [rsp + 0x160]
0018cefe  e90a6e1a00               jmp 0x333d0d
0018cf03  cc                       int3

; chunk at RVA 0x333c90 (125 bytes)
00333c90  4053                     push rbx
00333c92  55                       push rbp
00333c93  56                       push rsi
00333c94  4154                     push r12
00333c96  4155                     push r13
00333c98  4156                     push r14
00333c9a  4157                     push r15
00333c9c  4881ec10010000           sub rsp, 0x110
00333ca3  488b05de4f7a02           mov rax, qword ptr [rip + 0x27a4fde]
00333caa  4833c4                   xor rax, rsp
00333cad  4889842400010000         mov qword ptr [rsp + 0x100], rax
00333cb5  448bbc2470010000         mov r15d, dword ptr [rsp + 0x170]
00333cbd  33f6                     xor esi, esi
00333cbf  4c8bac2478010000         mov r13, qword ptr [rsp + 0x178]
00333cc7  498be9                   mov rbp, r9
00333cca  4c8be2                   mov r12, rdx
00333ccd  488bd9                   mov rbx, rcx
00333cd0  4885c9                   test rcx, rcx
00333cd3  0f848e91e5ff             je 0x18ce67
00333cd9  488b4908                 mov rcx, qword ptr [rcx + 8]
00333cdd  8b4120                   mov eax, dword ptr [rcx + 0x20]
00333ce0  c1e803                   shr eax, 3
00333ce3  a801                     test al, 1
00333ce5  0f8505495200             jne 0x8585f0
00333ceb  448b4920                 mov r9d, dword ptr [rcx + 0x20]
00333cef  418bc1                   mov eax, r9d
00333cf2  d1e8                     shr eax, 1
00333cf4  a801                     test al, 1
00333cf6  0f84fe90e5ff             je 0x18cdfa
00333cfc  0fb68143020000           movzx eax, byte ptr [rcx + 0x243]
00333d03  f6d0                     not al
00333d05  a801                     test al, 1
00333d07  0f84dd90e5ff             je 0x18cdea

; chunk at RVA 0x333d0d (35 bytes)
00333d0d  488b8c2400010000         mov rcx, qword ptr [rsp + 0x100]
00333d15  4833cc                   xor rcx, rsp
00333d18  e853d3ccff               call 0x1070
00333d1d  4881c410010000           add rsp, 0x110
00333d24  415f                     pop r15
00333d26  415e                     pop r14
00333d28  415d                     pop r13
00333d2a  415c                     pop r12
00333d2c  5e                       pop rsi
00333d2d  5d                       pop rbp
00333d2e  5b                       pop rbx
00333d2f  c3                       ret
