; CDecompressBatchLoader<Level1Batch,CLevel1Decompressor,CSimpleRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x9716a0, 1472 bytes in 1 chunk(s)

; chunk at RVA 0x9716a0 (1472 bytes)
009716a0  488bc4                   mov rax, rsp
009716a3  4c894820                 mov qword ptr [rax + 0x20], r9
009716a7  895010                   mov dword ptr [rax + 0x10], edx
009716aa  55                       push rbp
009716ab  56                       push rsi
009716ac  57                       push rdi
009716ad  4154                     push r12
009716af  4155                     push r13
009716b1  4156                     push r14
009716b3  4157                     push r15
009716b5  4881eca0000000           sub rsp, 0xa0
009716bc  48c740b0feffffff         mov qword ptr [rax - 0x50], 0xfffffffffffffffe
009716c4  48895818                 mov qword ptr [rax + 0x18], rbx
009716c8  4d8be0                   mov r12, r8
009716cb  448bd2                   mov r10d, edx
009716ce  488bd9                   mov rbx, rcx
009716d1  83792002                 cmp dword ptr [rcx + 0x20], 2
009716d5  7507                     jne 0x9716de
009716d7  33c0                     xor eax, eax
009716d9  e905050000               jmp 0x971be3
009716de  33f6                     xor esi, esi
009716e0  89742450                 mov dword ptr [rsp + 0x50], esi
009716e4  4889742458               mov qword ptr [rsp + 0x58], rsi
009716e9  4088742460               mov byte ptr [rsp + 0x60], sil
009716ee  0f57c0                   xorps xmm0, xmm0
009716f1  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
009716f7  4889b42480000000         mov qword ptr [rsp + 0x80], rsi
009716ff  448bee                   mov r13d, esi
00971702  32c0                     xor al, al
00971704  888424e0000000           mov byte ptr [rsp + 0xe0], al
0097170b  4c8d1deee868ff           lea r11, [rip - 0x971712]
00971712  41c644241000             mov byte ptr [r12 + 0x10], 0
00971718  80bb1803000000           cmp byte ptr [rbx + 0x318], 0
0097171f  0f84c8000000             je 0x9717ed
00971725  c6831803000000           mov byte ptr [rbx + 0x318], 0
0097172c  4c8b8b10030000           mov r9, qword ptr [rbx + 0x310]
00971733  41ff0424                 inc dword ptr [r12]
00971737  418b1424                 mov edx, dword ptr [r12]
0097173b  4d8b4120                 mov r8, qword ptr [r9 + 0x20]
0097173f  ffca                     dec edx
00971741  498b4c2420               mov rcx, qword ptr [r12 + 0x20]
00971746  498b00                   mov rax, qword ptr [r8]
00971749  488904d1                 mov qword ptr [rcx + rdx*8], rax
0097174d  4d8b4130                 mov r8, qword ptr [r9 + 0x30]
00971751  418b1424                 mov edx, dword ptr [r12]
00971755  ffca                     dec edx
00971757  498b4c2430               mov rcx, qword ptr [r12 + 0x30]
0097175c  418b00                   mov eax, dword ptr [r8]
0097175f  890491                   mov dword ptr [rcx + rdx*4], eax
00971762  4d8b4128                 mov r8, qword ptr [r9 + 0x28]
00971766  418b1424                 mov edx, dword ptr [r12]
0097176a  ffca                     dec edx
0097176c  498b4c2428               mov rcx, qword ptr [r12 + 0x28]
00971771  418b00                   mov eax, dword ptr [r8]
00971774  890491                   mov dword ptr [rcx + rdx*4], eax
00971777  488b8310030000           mov rax, qword ptr [rbx + 0x310]
0097177e  ff08                     dec dword ptr [rax]
00971780  89742450                 mov dword ptr [rsp + 0x50], esi
00971784  498b442408               mov rax, qword ptr [r12 + 8]
00971789  4889442458               mov qword ptr [rsp + 0x58], rax
0097178e  418b1424                 mov edx, dword ptr [r12]
00971792  498b442420               mov rax, qword ptr [r12 + 0x20]
00971797  488d0cd0                 lea rcx, [rax + rdx*8]
0097179b  48894c2470               mov qword ptr [rsp + 0x70], rcx
009717a0  498b442428               mov rax, qword ptr [r12 + 0x28]
009717a5  488d0c90                 lea rcx, [rax + rdx*4]
009717a9  48894c2478               mov qword ptr [rsp + 0x78], rcx
009717ae  498b442430               mov rax, qword ptr [r12 + 0x30]
009717b3  488d0c90                 lea rcx, [rax + rdx*4]
009717b7  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
009717bf  b801000000               mov eax, 1
009717c4  2bc2                     sub eax, edx
009717c6  4403d0                   add r10d, eax
009717c9  44899424e8000000         mov dword ptr [rsp + 0xe8], r10d
009717d1  488d7c2450               lea rdi, [rsp + 0x50]
009717d6  c6831803000000           mov byte ptr [rbx + 0x318], 0
009717dd  41bd01000000             mov r13d, 1
009717e3  4c8b8c24f8000000         mov r9, qword ptr [rsp + 0xf8]
009717eb  eb03                     jmp 0x9717f0
009717ed  498bfc                   mov rdi, r12
009717f0  837b2000                 cmp dword ptr [rbx + 0x20], 0
009717f4  0f8582000000             jne 0x97187c
009717fa  4889742420               mov qword ptr [rsp + 0x20], rsi
009717ff  89742428                 mov dword ptr [rsp + 0x28], esi
00971803  4889742430               mov qword ptr [rsp + 0x30], rsi
00971808  89742438                 mov dword ptr [rsp + 0x38], esi
0097180c  4889742440               mov qword ptr [rsp + 0x40], rsi
00971811  89742448                 mov dword ptr [rsp + 0x48], esi
00971815  668974244c               mov word ptr [rsp + 0x4c], si
0097181a  488d4b28                 lea rcx, [rbx + 0x28]
0097181e  488b01                   mov rax, qword ptr [rcx]
00971821  4d8bc1                   mov r8, r9
00971824  488d542420               lea rdx, [rsp + 0x20]
00971829  ff10                     call qword ptr [rax]
0097182b  c68424e000000001         mov byte ptr [rsp + 0xe0], 1
00971833  3dc60e0400               cmp eax, 0x40ec6
00971838  0f847e030000             je 0x971bbc
0097183e  488b4c2420               mov rcx, qword ptr [rsp + 0x20]
00971843  48894b50                 mov qword ptr [rbx + 0x50], rcx
00971847  8b442428                 mov eax, dword ptr [rsp + 0x28]
0097184b  894348                   mov dword ptr [rbx + 0x48], eax
0097184e  48894b58                 mov qword ptr [rbx + 0x58], rcx
00971852  48897340                 mov qword ptr [rbx + 0x40], rsi
00971856  66c783080300000000       mov word ptr [rbx + 0x308], 0
0097185f  4889b300030000           mov qword ptr [rbx + 0x300], rsi
00971866  c7432001000000           mov dword ptr [rbx + 0x20], 1
0097186d  448b9424e8000000         mov r10d, dword ptr [rsp + 0xe8]
00971875  4c8d1d84e768ff           lea r11, [rip - 0x97187c]
0097187c  488b4330                 mov rax, qword ptr [rbx + 0x30]
00971880  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00971887  4c894708                 mov qword ptr [rdi + 8], r8
0097188b  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00971892  488b5330                 mov rdx, qword ptr [rbx + 0x30]
00971896  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00971899  83e007                   and eax, 7
0097189c  83f805                   cmp eax, 5
0097189f  7741                     ja 0x9718e2
009718a1  4898                     cdqe
009718a3  418b8c83001c9700         mov ecx, dword ptr [r11 + rax*4 + 0x971c00]
009718ab  4903cb                   add rcx, r11
009718ae  ffe1                     jmp rcx
009718b0  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009718b4  400f95c5                 setne bpl
009718b8  eb2b                     jmp 0x9718e5
009718ba  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009718be  400f9dc5                 setge bpl
009718c2  eb21                     jmp 0x9718e5
009718c4  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009718c8  400f9ec5                 setle bpl
009718cc  eb17                     jmp 0x9718e5
009718ce  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009718d2  400f9fc5                 setg bpl
009718d6  eb0d                     jmp 0x9718e5
009718d8  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009718dc  400f9cc5                 setl bpl
009718e0  eb03                     jmp 0x9718e5
009718e2  4032ed                   xor bpl, bpl
009718e5  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
009718ec  8b424c                   mov eax, dword ptr [rdx + 0x4c]
009718ef  83e007                   and eax, 7
009718f2  83f805                   cmp eax, 5
009718f5  7741                     ja 0x971938
009718f7  4898                     cdqe
009718f9  418b8c83181c9700         mov ecx, dword ptr [r11 + rax*4 + 0x971c18]
00971901  4903cb                   add rcx, r11
00971904  ffe1                     jmp rcx
00971906  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097190a  410f95c7                 setne r15b
0097190e  eb2b                     jmp 0x97193b
00971910  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00971914  410f9dc7                 setge r15b
00971918  eb21                     jmp 0x97193b
0097191a  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097191e  410f9ec7                 setle r15b
00971922  eb17                     jmp 0x97193b
00971924  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00971928  410f9fc7                 setg r15b
0097192c  eb0d                     jmp 0x97193b
0097192e  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00971932  410f9cc7                 setl r15b
00971936  eb03                     jmp 0x97193b
00971938  4532ff                   xor r15b, r15b
0097193b  48899c2490000000         mov qword ptr [rsp + 0x90], rbx
00971943  0f31                     rdtsc
00971945  48c1e220                 shl rdx, 0x20
00971949  480bc2                   or rax, rdx
0097194c  48894308                 mov qword ptr [rbx + 8], rax
00971950  488d4b38                 lea rcx, [rbx + 0x38]
00971954  4c8bc7                   mov r8, rdi
00971957  418bd2                   mov edx, r10d
0097195a  e861bdffff               call 0x96d6c0
0097195f  84c0                     test al, al
00971961  7503                     jne 0x971966
00971963  897320                   mov dword ptr [rbx + 0x20], esi
00971966  8b07                     mov eax, dword ptr [rdi]
00971968  48014310                 add qword ptr [rbx + 0x10], rax
0097196c  0f31                     rdtsc
0097196e  48c1e220                 shl rdx, 0x20
00971972  480bc2                   or rax, rdx
00971975  482b4308                 sub rax, qword ptr [rbx + 8]
00971979  480103                   add qword ptr [rbx], rax
0097197c  ff4318                   inc dword ptr [rbx + 0x18]
0097197f  8b07                     mov eax, dword ptr [rdi]
00971981  448bc8                   mov r9d, eax
00971984  85c0                     test eax, eax
00971986  0f8493010000             je 0x971b1f
0097198c  4084ed                   test bpl, bpl
0097198f  7509                     jne 0x97199a
00971991  4584ff                   test r15b, r15b
00971994  0f8485010000             je 0x971b1f
0097199a  448bc0                   mov r8d, eax
0097199d  4084ed                   test bpl, bpl
009719a0  747c                     je 0x971a1e
009719a2  448bce                   mov r9d, esi
009719a5  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
009719a9  85c0                     test eax, eax
009719ab  746a                     je 0x971a17
009719ad  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
009719b1  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
009719b5  4183e007                 and r8d, 7
009719b9  488d2d40e668ff           lea rbp, [rip - 0x9719c0]
009719c0  418bc9                   mov ecx, r9d
009719c3  4d8b14ce                 mov r10, qword ptr [r14 + rcx*8]
009719c7  4183f805                 cmp r8d, 5
009719cb  0f87ae000000             ja 0x971a7f
009719d1  4963c8                   movsxd rcx, r8d
009719d4  8b948d301c9700           mov edx, dword ptr [rbp + rcx*4 + 0x971c30]
009719db  4803d5                   add rdx, rbp
009719de  ffe2                     jmp rdx
009719e0  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
009719e4  0f94c1                   sete cl
009719e7  eb22                     jmp 0x971a0b
009719e9  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
009719ed  0f9cc1                   setl cl
009719f0  eb19                     jmp 0x971a0b
009719f2  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
009719f6  0f9fc1                   setg cl
009719f9  eb10                     jmp 0x971a0b
009719fb  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
009719ff  0f9ec1                   setle cl
00971a02  eb07                     jmp 0x971a0b
00971a04  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00971a08  0f9dc1                   setge cl
00971a0b  84c9                     test cl, cl
00971a0d  7570                     jne 0x971a7f
00971a0f  41ffc1                   inc r9d
00971a12  443bc8                   cmp r9d, eax
00971a15  72a9                     jb 0x9719c0
00971a17  8937                     mov dword ptr [rdi], esi
00971a19  8bc6                     mov eax, esi
00971a1b  448bc6                   mov r8d, esi
00971a1e  458bc8                   mov r9d, r8d
00971a21  4584ff                   test r15b, r15b
00971a24  0f84f5000000             je 0x971b1f
00971a2a  85c0                     test eax, eax
00971a2c  0f84ed000000             je 0x971b1f
00971a32  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00971a36  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
00971a3a  4c8d3dbfe568ff           lea r15, [rip - 0x971a41]
00971a41  0f1f4000                 nop dword ptr [rax]
00971a45  6666660f1f840000000000   nop word ptr [rax + rax]
00971a50  458bd0                   mov r10d, r8d
00971a53  ffc8                     dec eax
00971a55  448bc0                   mov r8d, eax
00971a58  498b2cc6                 mov rbp, qword ptr [r14 + rax*8]
00971a5c  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00971a60  83e107                   and ecx, 7
00971a63  458bca                   mov r9d, r10d
00971a66  83f905                   cmp ecx, 5
00971a69  0f87b0000000             ja 0x971b1f
00971a6f  4863c9                   movsxd rcx, ecx
00971a72  418b948f481c9700         mov edx, dword ptr [r15 + rcx*4 + 0x971c48]
00971a7a  4903d7                   add rdx, r15
00971a7d  ffe2                     jmp rdx
00971a7f  443bc8                   cmp r9d, eax
00971a82  7393                     jae 0x971a17
00971a84  448bc0                   mov r8d, eax
00971a87  4585c9                   test r9d, r9d
00971a8a  7492                     je 0x971a1e
00971a8c  452bc1                   sub r8d, r9d
00971a8f  448bde                   mov r11d, esi
00971a92  7444                     je 0x971ad8
00971a94  4c8bd6                   mov r10, rsi
00971a97  4c8bf6                   mov r14, rsi
00971a9a  660f1f440000             nop word ptr [rax + rax]
00971aa0  438d040b                 lea eax, [r11 + r9]
00971aa4  8bd0                     mov edx, eax
00971aa6  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00971aaa  488b04c1                 mov rax, qword ptr [rcx + rax*8]
00971aae  4989040e                 mov qword ptr [r14 + rcx], rax
00971ab2  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00971ab6  8b0491                   mov eax, dword ptr [rcx + rdx*4]
00971ab9  4189040a                 mov dword ptr [r10 + rcx], eax
00971abd  488b4f28                 mov rcx, qword ptr [rdi + 0x28]
00971ac1  8b0491                   mov eax, dword ptr [rcx + rdx*4]
00971ac4  4189040a                 mov dword ptr [r10 + rcx], eax
00971ac8  41ffc3                   inc r11d
00971acb  4d8d7608                 lea r14, [r14 + 8]
00971acf  4d8d5204                 lea r10, [r10 + 4]
00971ad3  453bd8                   cmp r11d, r8d
00971ad6  72c8                     jb 0x971aa0
00971ad8  448907                   mov dword ptr [rdi], r8d
00971adb  418bc0                   mov eax, r8d
00971ade  e93bffffff               jmp 0x971a1e
00971ae3  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00971ae7  0f94c1                   sete cl
00971aea  eb22                     jmp 0x971b0e
00971aec  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00971af0  0f9cc1                   setl cl
00971af3  eb19                     jmp 0x971b0e
00971af5  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00971af9  0f9fc1                   setg cl
00971afc  eb10                     jmp 0x971b0e
00971afe  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00971b02  0f9ec1                   setle cl
00971b05  eb07                     jmp 0x971b0e
00971b07  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00971b0b  0f9dc1                   setge cl
00971b0e  84c9                     test cl, cl
00971b10  750d                     jne 0x971b1f
00971b12  8907                     mov dword ptr [rdi], eax
00971b14  448bc8                   mov r9d, eax
00971b17  85c0                     test eax, eax
00971b19  0f8531ffffff             jne 0x971a50
00971b1f  80bb1903000000           cmp byte ptr [rbx + 0x319], 0
00971b26  747a                     je 0x971ba2
00971b28  448b0f                   mov r9d, dword ptr [rdi]
00971b2b  4585c9                   test r9d, r9d
00971b2e  7472                     je 0x971ba2
00971b30  c6831803000001           mov byte ptr [rbx + 0x318], 1
00971b37  448b0f                   mov r9d, dword ptr [rdi]
00971b3a  41ffc9                   dec r9d
00971b3d  4c8b9310030000           mov r10, qword ptr [rbx + 0x310]
00971b44  41ff02                   inc dword ptr [r10]
00971b47  418b12                   mov edx, dword ptr [r10]
00971b4a  4c8b4720                 mov r8, qword ptr [rdi + 0x20]
00971b4e  ffca                     dec edx
00971b50  498b4a20                 mov rcx, qword ptr [r10 + 0x20]
00971b54  4b8b04c8                 mov rax, qword ptr [r8 + r9*8]
00971b58  488904d1                 mov qword ptr [rcx + rdx*8], rax
00971b5c  4c8b4730                 mov r8, qword ptr [rdi + 0x30]
00971b60  418b12                   mov edx, dword ptr [r10]
00971b63  ffca                     dec edx
00971b65  498b4a30                 mov rcx, qword ptr [r10 + 0x30]
00971b69  438b0488                 mov eax, dword ptr [r8 + r9*4]
00971b6d  890491                   mov dword ptr [rcx + rdx*4], eax
00971b70  4c8b4728                 mov r8, qword ptr [rdi + 0x28]
00971b74  418b12                   mov edx, dword ptr [r10]
00971b77  ffca                     dec edx
00971b79  498b4a28                 mov rcx, qword ptr [r10 + 0x28]
00971b7d  438b0488                 mov eax, dword ptr [r8 + r9*4]
00971b81  890491                   mov dword ptr [rcx + rdx*4], eax
00971b84  ff0f                     dec dword ptr [rdi]
00971b86  41c644241001             mov byte ptr [r12 + 0x10], 1
00971b8c  488b8310030000           mov rax, qword ptr [rbx + 0x310]
00971b93  488b4820                 mov rcx, qword ptr [rax + 0x20]
00971b97  488b01                   mov rax, qword ptr [rcx]
00971b9a  4989442418               mov qword ptr [r12 + 0x18], rax
00971b9f  448b0f                   mov r9d, dword ptr [rdi]
00971ba2  4503e9                   add r13d, r9d
00971ba5  7529                     jne 0x971bd0
00971ba7  448b9424e8000000         mov r10d, dword ptr [rsp + 0xe8]
00971baf  4c8b8c24f8000000         mov r9, qword ptr [rsp + 0xf8]
00971bb7  e94ffbffff               jmp 0x97170b
00971bbc  c7432002000000           mov dword ptr [rbx + 0x20], 2
00971bc3  41833c2400               cmp dword ptr [r12], 0
00971bc8  400f95c6                 setne sil
00971bcc  8bc6                     mov eax, esi
00971bce  eb13                     jmp 0x971be3
00971bd0  45892c24                 mov dword ptr [r12], r13d
00971bd4  0fb68424e0000000         movzx eax, byte ptr [rsp + 0xe0]
00971bdc  f6d8                     neg al
00971bde  1bc0                     sbb eax, eax
00971be0  83c002                   add eax, 2
00971be3  488b9c24f0000000         mov rbx, qword ptr [rsp + 0xf0]
00971beb  4881c4a0000000           add rsp, 0xa0
00971bf2  415f                     pop r15
00971bf4  415e                     pop r14
00971bf6  415d                     pop r13
00971bf8  415c                     pop r12
00971bfa  5f                       pop rdi
00971bfb  5e                       pop rsi
00971bfc  5d                       pop rbp
00971bfd  c3                       ret
00971bfe  6690                     nop
00971c00  e218                     loop 0x971c1a
00971c02  97                       xchg edi, eax
00971c03  00b0189700ba             add byte ptr [rax - 0x45ff68e8], dh
00971c09  189700ce1897             sbb byte ptr [rdi - 0x68e73200], dl
00971c0f  00c4                     add ah, al
00971c11  189700d81897             sbb byte ptr [rdi - 0x68e72800], dl
00971c17  0038                     add byte ptr [rax], bh
00971c19  199700061997             sbb dword ptr [rdi - 0x68e6fa00], edx
00971c1f  0010                     add byte ptr [rax], dl
00971c21  199700241997             sbb dword ptr [rdi - 0x68e6dc00], edx
00971c27  001a                     add byte ptr [rdx], bl
00971c29  1997002e1997             sbb dword ptr [rdi - 0x68e6d200], edx
00971c2f  007f1a                   add byte ptr [rdi + 0x1a], bh
00971c32  97                       xchg edi, eax
00971c33  00e0                     add al, ah
00971c35  199700e91997             sbb dword ptr [rdi - 0x68e61700], edx
00971c3b  00fb                     add bl, bh
00971c3d  199700f21997             sbb dword ptr [rdi - 0x68e60e00], edx
00971c43  00041a                   add byte ptr [rdx + rbx], al
00971c46  97                       xchg edi, eax
00971c47  001f                     add byte ptr [rdi], bl
00971c49  1b9700e31a97             sbb edx, dword ptr [rdi - 0x68e51d00]
00971c4f  00ec                     add ah, ch
00971c51  1a9700fe1a97             sbb dl, byte ptr [rdi - 0x68e50200]
00971c57  00f5                     add ch, dh
00971c59  1a9700071b97             sbb dl, byte ptr [rdi - 0x68e4f900]
