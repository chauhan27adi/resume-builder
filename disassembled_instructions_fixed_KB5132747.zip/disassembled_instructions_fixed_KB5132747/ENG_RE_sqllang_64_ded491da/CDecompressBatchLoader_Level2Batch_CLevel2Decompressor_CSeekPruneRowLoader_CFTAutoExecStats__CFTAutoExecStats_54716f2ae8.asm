; CDecompressBatchLoader<Level2Batch,CLevel2Decompressor,CSeekPruneRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x9748a0, 1452 bytes in 1 chunk(s)

; chunk at RVA 0x9748a0 (1452 bytes)
009748a0  488bc4                   mov rax, rsp
009748a3  4c894820                 mov qword ptr [rax + 0x20], r9
009748a7  895010                   mov dword ptr [rax + 0x10], edx
009748aa  55                       push rbp
009748ab  56                       push rsi
009748ac  57                       push rdi
009748ad  4154                     push r12
009748af  4155                     push r13
009748b1  4156                     push r14
009748b3  4157                     push r15
009748b5  488d68a1                 lea rbp, [rax - 0x5f]
009748b9  4881ecd0000000           sub rsp, 0xd0
009748c0  48c74517feffffff         mov qword ptr [rbp + 0x17], 0xfffffffffffffffe
009748c8  48895818                 mov qword ptr [rax + 0x18], rbx
009748cc  4d8be0                   mov r12, r8
009748cf  448bfa                   mov r15d, edx
009748d2  488bd9                   mov rbx, rcx
009748d5  83792002                 cmp dword ptr [rcx + 0x20], 2
009748d9  7507                     jne 0x9748e2
009748db  33c0                     xor eax, eax
009748dd  e9ed040000               jmp 0x974dcf
009748e2  33ff                     xor edi, edi
009748e4  897db7                   mov dword ptr [rbp - 0x49], edi
009748e7  48897dbf                 mov qword ptr [rbp - 0x41], rdi
009748eb  40887dc7                 mov byte ptr [rbp - 0x39], dil
009748ef  0f57c0                   xorps xmm0, xmm0
009748f2  660f7f45d7               movdqa xmmword ptr [rbp - 0x29], xmm0
009748f7  0f57c9                   xorps xmm1, xmm1
009748fa  660f7f4de7               movdqa xmmword ptr [rbp - 0x19], xmm1
009748ff  660f7f45f7               movdqa xmmword ptr [rbp - 9], xmm0
00974904  48897d07                 mov qword ptr [rbp + 7], rdi
00974908  c7450f01000000           mov dword ptr [rbp + 0xf], 1
0097490f  897c2420                 mov dword ptr [rsp + 0x20], edi
00974913  32c9                     xor cl, cl
00974915  884d67                   mov byte ptr [rbp + 0x67], cl
00974918  4c8d2de1b668ff           lea r13, [rip - 0x97491f]
0097491f  41c644241000             mov byte ptr [r12 + 0x10], 0
00974925  80bbc81d000000           cmp byte ptr [rbx + 0x1dc8], 0
0097492c  747f                     je 0x9749ad
0097492e  c683c81d000000           mov byte ptr [rbx + 0x1dc8], 0
00974935  4c8b83c01d0000           mov r8, qword ptr [rbx + 0x1dc0]
0097493c  33d2                     xor edx, edx
0097493e  498bcc                   mov rcx, r12
00974941  e85a80ffff               call 0x96c9a0
00974946  488b83c01d0000           mov rax, qword ptr [rbx + 0x1dc0]
0097494d  ff08                     dec dword ptr [rax]
0097494f  897db7                   mov dword ptr [rbp - 0x49], edi
00974952  498b442408               mov rax, qword ptr [r12 + 8]
00974957  488945bf                 mov qword ptr [rbp - 0x41], rax
0097495b  418b1424                 mov edx, dword ptr [r12]
0097495f  498b442420               mov rax, qword ptr [r12 + 0x20]
00974964  488d0cd0                 lea rcx, [rax + rdx*8]
00974968  48894dd7                 mov qword ptr [rbp - 0x29], rcx
0097496c  498b442428               mov rax, qword ptr [r12 + 0x28]
00974971  488d0c90                 lea rcx, [rax + rdx*4]
00974975  48894ddf                 mov qword ptr [rbp - 0x21], rcx
00974979  498b442430               mov rax, qword ptr [r12 + 0x30]
0097497e  488d0c90                 lea rcx, [rax + rdx*4]
00974982  48894de7                 mov qword ptr [rbp - 0x19], rcx
00974986  b801000000               mov eax, 1
0097498b  2bc2                     sub eax, edx
0097498d  4403f8                   add r15d, eax
00974990  44897d6f                 mov dword ptr [rbp + 0x6f], r15d
00974994  488d75b7                 lea rsi, [rbp - 0x49]
00974998  c683c81d000000           mov byte ptr [rbx + 0x1dc8], 0
0097499f  c744242001000000         mov dword ptr [rsp + 0x20], 1
009749a7  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009749ab  eb03                     jmp 0x9749b0
009749ad  498bf4                   mov rsi, r12
009749b0  837b2000                 cmp dword ptr [rbx + 0x20], 0
009749b4  0f85b7000000             jne 0x974a71
009749ba  48897c2428               mov qword ptr [rsp + 0x28], rdi
009749bf  897d87                   mov dword ptr [rbp - 0x79], edi
009749c2  48897d8f                 mov qword ptr [rbp - 0x71], rdi
009749c6  897d97                   mov dword ptr [rbp - 0x69], edi
009749c9  48897d9f                 mov qword ptr [rbp - 0x61], rdi
009749cd  897da7                   mov dword ptr [rbp - 0x59], edi
009749d0  66897dab                 mov word ptr [rbp - 0x55], di
009749d4  488d4b28                 lea rcx, [rbx + 0x28]
009749d8  488b01                   mov rax, qword ptr [rcx]
009749db  4d8bc1                   mov r8, r9
009749de  488d542428               lea rdx, [rsp + 0x28]
009749e3  ff10                     call qword ptr [rax]
009749e5  c6456701                 mov byte ptr [rbp + 0x67], 1
009749e9  3dc60e0400               cmp eax, 0x40ec6
009749ee  0f84b8030000             je 0x974dac
009749f4  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
009749f9  48898b60090000           mov qword ptr [rbx + 0x960], rcx
00974a00  8b4587                   mov eax, dword ptr [rbp - 0x79]
00974a03  898358090000             mov dword ptr [rbx + 0x958], eax
00974a09  48898b68090000           mov qword ptr [rbx + 0x968], rcx
00974a10  4889bb50090000           mov qword ptr [rbx + 0x950], rdi
00974a17  66c783180c00000000       mov word ptr [rbx + 0xc18], 0
00974a20  4889bb100c0000           mov qword ptr [rbx + 0xc10], rdi
00974a27  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
00974a2b  48898b300c0000           mov qword ptr [rbx + 0xc30], rcx
00974a32  8b4597                   mov eax, dword ptr [rbp - 0x69]
00974a35  8983280c0000             mov dword ptr [rbx + 0xc28], eax
00974a3b  48898b380c0000           mov qword ptr [rbx + 0xc38], rcx
00974a42  4889bb200c0000           mov qword ptr [rbx + 0xc20], rdi
00974a49  4889bbac1d0000           mov qword ptr [rbx + 0x1dac], rdi
00974a50  c783b41d000000000101     mov dword ptr [rbx + 0x1db4], 0x1010000
00974a5a  c783a81d000001000000     mov dword ptr [rbx + 0x1da8], 1
00974a64  89bba01c0000             mov dword ptr [rbx + 0x1ca0], edi
00974a6a  c7432001000000           mov dword ptr [rbx + 0x20], 1
00974a71  488b4330                 mov rax, qword ptr [rbx + 0x30]
00974a75  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00974a7c  4c894608                 mov qword ptr [rsi + 8], r8
00974a80  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00974a87  488b5330                 mov rdx, qword ptr [rbx + 0x30]
00974a8b  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00974a8e  83e007                   and eax, 7
00974a91  83f805                   cmp eax, 5
00974a94  7741                     ja 0x974ad7
00974a96  4898                     cdqe
00974a98  418b8c85ec4d9700         mov ecx, dword ptr [r13 + rax*4 + 0x974dec]
00974aa0  4903cd                   add rcx, r13
00974aa3  ffe1                     jmp rcx
00974aa5  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974aa9  410f95c6                 setne r14b
00974aad  eb2b                     jmp 0x974ada
00974aaf  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974ab3  410f9dc6                 setge r14b
00974ab7  eb21                     jmp 0x974ada
00974ab9  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974abd  410f9ec6                 setle r14b
00974ac1  eb17                     jmp 0x974ada
00974ac3  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974ac7  410f9fc6                 setg r14b
00974acb  eb0d                     jmp 0x974ada
00974acd  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974ad1  410f9cc6                 setl r14b
00974ad5  eb03                     jmp 0x974ada
00974ad7  4532f6                   xor r14b, r14b
00974ada  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00974ae1  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00974ae4  83e007                   and eax, 7
00974ae7  83f805                   cmp eax, 5
00974aea  7741                     ja 0x974b2d
00974aec  4898                     cdqe
00974aee  418b8c85044e9700         mov ecx, dword ptr [r13 + rax*4 + 0x974e04]
00974af6  4903cd                   add rcx, r13
00974af9  ffe1                     jmp rcx
00974afb  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974aff  410f95c5                 setne r13b
00974b03  eb2b                     jmp 0x974b30
00974b05  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974b09  410f9dc5                 setge r13b
00974b0d  eb21                     jmp 0x974b30
00974b0f  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974b13  410f9ec5                 setle r13b
00974b17  eb17                     jmp 0x974b30
00974b19  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974b1d  410f9fc5                 setg r13b
00974b21  eb0d                     jmp 0x974b30
00974b23  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974b27  410f9cc5                 setl r13b
00974b2b  eb03                     jmp 0x974b30
00974b2d  4532ed                   xor r13b, r13b
00974b30  48895d1f                 mov qword ptr [rbp + 0x1f], rbx
00974b34  0f31                     rdtsc
00974b36  48c1e220                 shl rdx, 0x20
00974b3a  480bc2                   or rax, rdx
00974b3d  48894308                 mov qword ptr [rbx + 8], rax
00974b41  488d8b48090000           lea rcx, [rbx + 0x948]
00974b48  4c8bc6                   mov r8, rsi
00974b4b  418bd7                   mov edx, r15d
00974b4e  e8ad8fffff               call 0x96db00
00974b53  84c0                     test al, al
00974b55  7503                     jne 0x974b5a
00974b57  897b20                   mov dword ptr [rbx + 0x20], edi
00974b5a  8b06                     mov eax, dword ptr [rsi]
00974b5c  48014310                 add qword ptr [rbx + 0x10], rax
00974b60  0f31                     rdtsc
00974b62  48c1e220                 shl rdx, 0x20
00974b66  480bc2                   or rax, rdx
00974b69  482b4308                 sub rax, qword ptr [rbx + 8]
00974b6d  480103                   add qword ptr [rbx], rax
00974b70  ff4318                   inc dword ptr [rbx + 0x18]
00974b73  8b16                     mov edx, dword ptr [rsi]
00974b75  448bc2                   mov r8d, edx
00974b78  85d2                     test edx, edx
00974b7a  0f84c9010000             je 0x974d49
00974b80  4584f6                   test r14b, r14b
00974b83  7509                     jne 0x974b8e
00974b85  4584ed                   test r13b, r13b
00974b88  0f84bb010000             je 0x974d49
00974b8e  448bca                   mov r9d, edx
00974b91  4584f6                   test r14b, r14b
00974b94  0f8485000000             je 0x974c1f
00974b9a  448bd7                   mov r10d, edi
00974b9d  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00974ba1  85d2                     test edx, edx
00974ba3  7473                     je 0x974c18
00974ba5  4c8b7620                 mov r14, qword ptr [rsi + 0x20]
00974ba9  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00974bad  4183e007                 and r8d, 7
00974bb1  4c8d3d48b468ff           lea r15, [rip - 0x974bb8]
00974bb8  0f1f840000000000         nop dword ptr [rax + rax]
00974bc0  418bc2                   mov eax, r10d
00974bc3  4d8b0cc6                 mov r9, qword ptr [r14 + rax*8]
00974bc7  4183f805                 cmp r8d, 5
00974bcb  0f87ad000000             ja 0x974c7e
00974bd1  4963c0                   movsxd rax, r8d
00974bd4  418b8c871c4e9700         mov ecx, dword ptr [r15 + rax*4 + 0x974e1c]
00974bdc  4903cf                   add rcx, r15
00974bdf  ffe1                     jmp rcx
00974be1  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974be5  0f94c0                   sete al
00974be8  eb22                     jmp 0x974c0c
00974bea  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974bee  0f9cc0                   setl al
00974bf1  eb19                     jmp 0x974c0c
00974bf3  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974bf7  0f9fc0                   setg al
00974bfa  eb10                     jmp 0x974c0c
00974bfc  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974c00  0f9ec0                   setle al
00974c03  eb07                     jmp 0x974c0c
00974c05  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974c09  0f9dc0                   setge al
00974c0c  84c0                     test al, al
00974c0e  756e                     jne 0x974c7e
00974c10  41ffc2                   inc r10d
00974c13  443bd2                   cmp r10d, edx
00974c16  72a8                     jb 0x974bc0
00974c18  893e                     mov dword ptr [rsi], edi
00974c1a  8bd7                     mov edx, edi
00974c1c  448bcf                   mov r9d, edi
00974c1f  458bc1                   mov r8d, r9d
00974c22  4584ed                   test r13b, r13b
00974c25  0f841e010000             je 0x974d49
00974c2b  85d2                     test edx, edx
00974c2d  0f8416010000             je 0x974d49
00974c33  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00974c37  4c8b7e20                 mov r15, qword ptr [rsi + 0x20]
00974c3b  4c8d2dbeb368ff           lea r13, [rip - 0x974c42]
00974c42  0f1f4000                 nop dword ptr [rax]
00974c46  66660f1f840000000000     nop word ptr [rax + rax]
00974c50  458bd1                   mov r10d, r9d
00974c53  ffca                     dec edx
00974c55  448bca                   mov r9d, edx
00974c58  4d8b34d7                 mov r14, qword ptr [r15 + rdx*8]
00974c5c  418b434c                 mov eax, dword ptr [r11 + 0x4c]
00974c60  83e007                   and eax, 7
00974c63  458bc2                   mov r8d, r10d
00974c66  83f805                   cmp eax, 5
00974c69  0f87da000000             ja 0x974d49
00974c6f  4898                     cdqe
00974c71  418b8c85344e9700         mov ecx, dword ptr [r13 + rax*4 + 0x974e34]
00974c79  4903cd                   add rcx, r13
00974c7c  ffe1                     jmp rcx
00974c7e  443bd2                   cmp r10d, edx
00974c81  7395                     jae 0x974c18
00974c83  448bca                   mov r9d, edx
00974c86  4585d2                   test r10d, r10d
00974c89  7494                     je 0x974c1f
00974c8b  452bca                   sub r9d, r10d
00974c8e  8bd7                     mov edx, edi
00974c90  7470                     je 0x974d02
00974c92  4c8bc7                   mov r8, rdi
00974c95  4c8bdf                   mov r11, rdi
00974c98  4c8bf7                   mov r14, rdi
00974c9b  0f1f440000               nop dword ptr [rax + rax]
00974ca0  428d0412                 lea eax, [rdx + r10]
00974ca4  448bf8                   mov r15d, eax
00974ca7  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00974cab  488b04c1                 mov rax, qword ptr [rcx + rax*8]
00974caf  4989040e                 mov qword ptr [r14 + rcx], rax
00974cb3  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
00974cb7  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00974cbb  4189040b                 mov dword ptr [r11 + rcx], eax
00974cbf  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
00974cc3  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00974cc7  4189040b                 mov dword ptr [r11 + rcx], eax
00974ccb  4d03ff                   add r15, r15
00974cce  488b4638                 mov rax, qword ptr [rsi + 0x38]
00974cd2  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00974cd7  420f110400               movups xmmword ptr [rax + r8], xmm0
00974cdc  488b4648                 mov rax, qword ptr [rsi + 0x48]
00974ce0  4885c0                   test rax, rax
00974ce3  740a                     je 0x974cef
00974ce5  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00974cea  420f110400               movups xmmword ptr [rax + r8], xmm0
00974cef  ffc2                     inc edx
00974cf1  4983c608                 add r14, 8
00974cf5  4983c304                 add r11, 4
00974cf9  4983c010                 add r8, 0x10
00974cfd  413bd1                   cmp edx, r9d
00974d00  729e                     jb 0x974ca0
00974d02  44890e                   mov dword ptr [rsi], r9d
00974d05  418bd1                   mov edx, r9d
00974d08  e912ffffff               jmp 0x974c1f
00974d0d  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974d11  0f94c0                   sete al
00974d14  eb22                     jmp 0x974d38
00974d16  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974d1a  0f9cc0                   setl al
00974d1d  eb19                     jmp 0x974d38
00974d1f  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974d23  0f9fc0                   setg al
00974d26  eb10                     jmp 0x974d38
00974d28  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974d2c  0f9ec0                   setle al
00974d2f  eb07                     jmp 0x974d38
00974d31  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974d35  0f9dc0                   setge al
00974d38  84c0                     test al, al
00974d3a  750d                     jne 0x974d49
00974d3c  8916                     mov dword ptr [rsi], edx
00974d3e  448bc2                   mov r8d, edx
00974d41  85d2                     test edx, edx
00974d43  0f8507ffffff             jne 0x974c50
00974d49  80bbc91d000000           cmp byte ptr [rbx + 0x1dc9], 0
00974d50  7440                     je 0x974d92
00974d52  448b06                   mov r8d, dword ptr [rsi]
00974d55  4585c0                   test r8d, r8d
00974d58  7438                     je 0x974d92
00974d5a  c683c81d000001           mov byte ptr [rbx + 0x1dc8], 1
00974d61  8b16                     mov edx, dword ptr [rsi]
00974d63  ffca                     dec edx
00974d65  4c8bc6                   mov r8, rsi
00974d68  488b8bc01d0000           mov rcx, qword ptr [rbx + 0x1dc0]
00974d6f  e82c7cffff               call 0x96c9a0
00974d74  ff0e                     dec dword ptr [rsi]
00974d76  41c644241001             mov byte ptr [r12 + 0x10], 1
00974d7c  488b83c01d0000           mov rax, qword ptr [rbx + 0x1dc0]
00974d83  488b4820                 mov rcx, qword ptr [rax + 0x20]
00974d87  488b01                   mov rax, qword ptr [rcx]
00974d8a  4989442418               mov qword ptr [r12 + 0x18], rax
00974d8f  448b06                   mov r8d, dword ptr [rsi]
00974d92  8b442420                 mov eax, dword ptr [rsp + 0x20]
00974d96  4103c0                   add eax, r8d
00974d99  89442420                 mov dword ptr [rsp + 0x20], eax
00974d9d  7521                     jne 0x974dc0
00974d9f  448b7d6f                 mov r15d, dword ptr [rbp + 0x6f]
00974da3  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00974da7  e96cfbffff               jmp 0x974918
00974dac  c7432002000000           mov dword ptr [rbx + 0x20], 2
00974db3  41833c2400               cmp dword ptr [r12], 0
00974db8  400f95c7                 setne dil
00974dbc  8bc7                     mov eax, edi
00974dbe  eb0f                     jmp 0x974dcf
00974dc0  41890424                 mov dword ptr [r12], eax
00974dc4  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00974dc8  f6d9                     neg cl
00974dca  1bc0                     sbb eax, eax
00974dcc  83c002                   add eax, 2
00974dcf  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
00974dd7  4881c4d0000000           add rsp, 0xd0
00974dde  415f                     pop r15
00974de0  415e                     pop r14
00974de2  415d                     pop r13
00974de4  415c                     pop r12
00974de6  5f                       pop rdi
00974de7  5e                       pop rsi
00974de8  5d                       pop rbp
00974de9  c3                       ret
00974dea  90                       nop
00974deb  90                       nop
00974dec  d7                       xlatb
00974ded  4a97                     xchg rdi, rax
00974def  00a54a9700af             add byte ptr [rbp - 0x50ff68b6], ah
00974df5  4a97                     xchg rdi, rax
00974df7  00c3                     add bl, al
00974df9  4a97                     xchg rdi, rax
00974dfb  00b94a9700cd             add byte ptr [rcx - 0x32ff68b6], bh
00974e01  4a97                     xchg rdi, rax
00974e03  002d4b9700fb             add byte ptr [rip - 0x4ff68b5], ch
00974e09  4a97                     xchg rdi, rax
00974e0b  00054b970019             add byte ptr [rip + 0x1900974b], al
00974e11  4b97                     xchg r15, rax
00974e13  000f                     add byte ptr [rdi], cl
00974e15  4b97                     xchg r15, rax
00974e17  0023                     add byte ptr [rbx], ah
00974e19  4b97                     xchg r15, rax
00974e1b  007e4c                   add byte ptr [rsi + 0x4c], bh
00974e1e  97                       xchg edi, eax
00974e1f  00e1                     add cl, ah
00974e21  4b97                     xchg r15, rax
00974e23  00ea                     add dl, ch
00974e25  4b97                     xchg r15, rax
00974e27  00fc                     add ah, bh
00974e29  4b97                     xchg r15, rax
00974e2b  00f3                     add bl, dh
00974e2d  4b97                     xchg r15, rax
00974e2f  00054c970049             add byte ptr [rip + 0x4900974c], al
00974e35  4d97                     xchg r15, rax
00974e37  000d4d970016             add byte ptr [rip + 0x1600974d], cl
00974e3d  4d97                     xchg r15, rax
00974e3f  0028                     add byte ptr [rax], ch
00974e41  4d97                     xchg r15, rax
00974e43  001f                     add byte ptr [rdi], bl
00974e45  4d97                     xchg r15, rax
00974e47  0031                     add byte ptr [rcx], dh
00974e49  4d97                     xchg r15, rax
