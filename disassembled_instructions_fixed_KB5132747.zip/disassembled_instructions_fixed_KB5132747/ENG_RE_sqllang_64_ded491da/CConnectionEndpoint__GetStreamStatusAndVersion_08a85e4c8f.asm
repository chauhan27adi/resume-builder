; CConnectionEndpoint::GetStreamStatusAndVersion
; sqllang.dll, primary RVA 0x44a580, 444 bytes in 1 chunk(s)

; chunk at RVA 0x44a580 (444 bytes)
0044a580  488bc4                   mov rax, rsp
0044a583  4156                     push r14
0044a585  4881ec80000000           sub rsp, 0x80
0044a58c  48c740a8feffffff         mov qword ptr [rax - 0x58], 0xfffffffffffffffe
0044a594  48895808                 mov qword ptr [rax + 8], rbx
0044a598  48896810                 mov qword ptr [rax + 0x10], rbp
0044a59c  48897018                 mov qword ptr [rax + 0x18], rsi
0044a5a0  48897820                 mov qword ptr [rax + 0x20], rdi
0044a5a4  4d8bf0                   mov r14, r8
0044a5a7  488bda                   mov rbx, rdx
0044a5aa  488bf1                   mov rsi, rcx
0044a5ad  33ed                     xor ebp, ebp
0044a5af  8968c0                   mov dword ptr [rax - 0x40], ebp
0044a5b2  654c8b142558000000       mov r10, qword ptr gs:[0x58]
0044a5bb  488b05b609a801           mov rax, qword ptr [rip + 0x1a809b6]
0044a5c2  448b08                   mov r9d, dword ptr [rax]
0044a5c5  488b05b409a801           mov rax, qword ptr [rip + 0x1a809b4]
0044a5cc  8b38                     mov edi, dword ptr [rax]
0044a5ce  4b033cca                 add rdi, qword ptr [r10 + r9*8]
0044a5d2  488b9700010000           mov rdx, qword ptr [rdi + 0x100]
0044a5d9  4885d2                   test rdx, rdx
0044a5dc  750f                     jne 0x44a5ed
0044a5de  33c9                     xor ecx, ecx
0044a5e0  ff15aa09a801             call qword ptr [rip + 0x1a809aa]
0044a5e6  488b9700010000           mov rdx, qword ptr [rdi + 0x100]
0044a5ed  4889542450               mov qword ptr [rsp + 0x50], rdx
0044a5f2  8b8a68020000             mov ecx, dword ptr [rdx + 0x268]
0044a5f8  8bc1                     mov eax, ecx
0044a5fa  83e001                   and eax, 1
0044a5fd  83f001                   xor eax, 1
0044a600  89442448                 mov dword ptr [rsp + 0x48], eax
0044a604  83c901                   or ecx, 1
0044a607  898a68020000             mov dword ptr [rdx + 0x268], ecx
0044a60d  c744245870044000         mov dword ptr [rsp + 0x58], 0x400470
0044a615  48896c2460               mov qword ptr [rsp + 0x60], rbp
0044a61a  48896c2470               mov qword ptr [rsp + 0x70], rbp
0044a61f  48896c2468               mov qword ptr [rsp + 0x68], rbp
0044a624  48896c2478               mov qword ptr [rsp + 0x78], rbp
0044a629  488d8e98260000           lea rcx, [rsi + 0x2698]
0044a630  48894c2438               mov qword ptr [rsp + 0x38], rcx
0044a635  896c2440                 mov dword ptr [rsp + 0x40], ebp
0044a639  4c8d4c2458               lea r9, [rsp + 0x58]
0044a63e  bf01000000               mov edi, 1
0044a643  41b8ffffffff             mov r8d, 0xffffffff
0044a649  8bd7                     mov edx, edi
0044a64b  e8908dbbff               call 0x33e0
0044a650  8bcd                     mov ecx, ebp
0044a652  85c0                     test eax, eax
0044a654  0f44cf                   cmove ecx, edi
0044a657  894c2440                 mov dword ptr [rsp + 0x40], ecx
0044a65b  488b86804f0000           mov rax, qword ptr [rsi + 0x4f80]
0044a662  498906                   mov qword ptr [r14], rax
0044a665  8b8678260000             mov eax, dword ptr [rsi + 0x2678]
0044a66b  ffc8                     dec eax
0044a66d  83f806                   cmp eax, 6
0044a670  773d                     ja 0x44a6af
0044a672  4898                     cdqe
0044a674  488d158559bbff           lea rdx, [rip - 0x44a67b]
0044a67b  8b8c8220a74400           mov ecx, dword ptr [rdx + rax*4 + 0x44a720]
0044a682  4803ca                   add rcx, rdx
0044a685  ffe1                     jmp rcx
0044a687  c70303000000             mov dword ptr [rbx], 3
0044a68d  eb49                     jmp 0x44a6d8
0044a68f  b804000000               mov eax, 4
0044a694  b902000000               mov ecx, 2
0044a699  80befc30000000           cmp byte ptr [rsi + 0x30fc], 0
0044a6a0  0f44c1                   cmove eax, ecx
0044a6a3  8903                     mov dword ptr [rbx], eax
0044a6a5  eb31                     jmp 0x44a6d8
0044a6a7  c7030d000000             mov dword ptr [rbx], 0xd
0044a6ad  eb29                     jmp 0x44a6d8
0044a6af  488d0572ded001           lea rax, [rip + 0x1d0de72]
0044a6b6  4889442420               mov qword ptr [rsp + 0x20], rax
0044a6bb  41b9d7050000             mov r9d, 0x5d7
0044a6c1  4c8d0578aa0c02           lea r8, [rip + 0x20caa78]
0044a6c8  488d1571a30c02           lea rdx, [rip + 0x20ca371]
0044a6cf  8bcf                     mov ecx, edi
0044a6d1  ff15a107a801             call qword ptr [rip + 0x1a807a1]
0044a6d7  90                       nop
0044a6d8  8b542440                 mov edx, dword ptr [rsp + 0x40]
0044a6dc  85d2                     test edx, edx
0044a6de  740f                     je 0x44a6ef
0044a6e0  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
0044a6e5  ff157507a801             call qword ptr [rip + 0x1a80775]
0044a6eb  896c2440                 mov dword ptr [rsp + 0x40], ebp
0044a6ef  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
0044a6f4  8b442448                 mov eax, dword ptr [rsp + 0x48]
0044a6f8  f7d0                     not eax
0044a6fa  218168020000             and dword ptr [rcx + 0x268], eax
0044a700  4c8d9c2480000000         lea r11, [rsp + 0x80]
0044a708  498b5b10                 mov rbx, qword ptr [r11 + 0x10]
0044a70c  498b6b18                 mov rbp, qword ptr [r11 + 0x18]
0044a710  498b7320                 mov rsi, qword ptr [r11 + 0x20]
0044a714  498b7b28                 mov rdi, qword ptr [r11 + 0x28]
0044a718  498be3                   mov rsp, r11
0044a71b  415e                     pop r14
0044a71d  c3                       ret
0044a71e  6690                     nop
0044a720  87a6440087a6             xchg dword ptr [rsi - 0x5978ffbc], esp
0044a726  440087a644008f           add byte ptr [rdi - 0x70ffbb5a], r8b
0044a72d  a6                       cmpsb byte ptr [rsi], byte ptr [rdi]
0044a72e  4400a7a6440087           add byte ptr [rdi - 0x78ffbb5a], r12b
0044a735  a6                       cmpsb byte ptr [rsi], byte ptr [rdi]
