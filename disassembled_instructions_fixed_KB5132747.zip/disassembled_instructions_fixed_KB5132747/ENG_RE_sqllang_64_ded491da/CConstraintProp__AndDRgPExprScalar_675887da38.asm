; CConstraintProp::AndDRgPExprScalar
; sqllang.dll, primary RVA 0x24b190, 247 bytes in 1 chunk(s)

; chunk at RVA 0x24b190 (247 bytes)
0024b190  4c894c2420               mov qword ptr [rsp + 0x20], r9
0024b195  4889542410               mov qword ptr [rsp + 0x10], rdx
0024b19a  48894c2408               mov qword ptr [rsp + 8], rcx
0024b19f  53                       push rbx
0024b1a0  55                       push rbp
0024b1a1  56                       push rsi
0024b1a2  57                       push rdi
0024b1a3  4154                     push r12
0024b1a5  4155                     push r13
0024b1a7  4156                     push r14
0024b1a9  4157                     push r15
0024b1ab  4883ec48                 sub rsp, 0x48
0024b1af  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
0024b1b8  498be8                   mov rbp, r8
0024b1bb  4c8bd1                   mov r10, rcx
0024b1be  41b701                   mov r15b, 1
0024b1c1  450fb6e7                 movzx r12d, r15b
0024b1c5  4d85c9                   test r9, r9
0024b1c8  7404                     je 0x24b1ce
0024b1ca  41c60100                 mov byte ptr [r9], 0
0024b1ce  418b481c                 mov ecx, dword ptr [r8 + 0x1c]
0024b1d2  b808000000               mov eax, 8
0024b1d7  48f7e1                   mul rcx
0024b1da  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
0024b1e1  480f40c1                 cmovo rax, rcx
0024b1e5  4488642420               mov byte ptr [rsp + 0x20], r12b
0024b1ea  41b9082b0000             mov r9d, 0x2b08
0024b1f0  4c8d055986e201           lea r8, [rip + 0x1e28659]
0024b1f7  498b5210                 mov rdx, qword ptr [r10 + 0x10]
0024b1fb  488bc8                   mov rcx, rax
0024b1fe  ff15f4fcc701             call qword ptr [rip + 0x1c7fcf4]
0024b204  4c8be8                   mov r13, rax
0024b207  448b451c                 mov r8d, dword ptr [rbp + 0x1c]
0024b20b  49c1e003                 shl r8, 3
0024b20f  33d2                     xor edx, edx
0024b211  488bc8                   mov rcx, rax
0024b214  e82362dbff               call 0x143c
0024b219  33ff                     xor edi, edi
0024b21b  448bf7                   mov r14d, edi
0024b21e  8bdf                     mov ebx, edi
0024b220  8b4d1c                   mov ecx, dword ptr [rbp + 0x1c]
0024b223  85c9                     test ecx, ecx
0024b225  0f8407080000             je 0x24ba32
0024b22b  8bf3                     mov esi, ebx
0024b22d  3bd9                     cmp ebx, ecx
0024b22f  0f8313eb3701             jae 0x15c9d48
0024b235  488b4528                 mov rax, qword ptr [rbp + 0x28]
0024b239  488b0cf0                 mov rcx, qword ptr [rax + rsi*8]
0024b23d  eb01                     jmp 0x24b240
0024b23f  cc                       int3
0024b240  488b4910                 mov rcx, qword ptr [rcx + 0x10]
0024b244  488b01                   mov rax, qword ptr [rcx]
0024b247  ff5018                   call qword ptr [rax + 0x18]
0024b24a  83f862                   cmp eax, 0x62
0024b24d  0f84ac070000             je 0x24b9ff
0024b253  4532ff                   xor r15b, r15b
0024b256  ffc3                     inc ebx
0024b258  8b4d1c                   mov ecx, dword ptr [rbp + 0x1c]
0024b25b  3bd9                     cmp ebx, ecx
0024b25d  72cc                     jb 0x24b22b
0024b25f  4584ff                   test r15b, r15b
0024b262  0f85ca070000             jne 0x24ba32
0024b268  4d85ed                   test r13, r13
0024b26b  7409                     je 0x24b276
0024b26d  498bcd                   mov rcx, r13
0024b270  ff1532fdc701             call qword ptr [rip + 0x1c7fd32]
0024b276  4883c448                 add rsp, 0x48
0024b27a  415f                     pop r15
0024b27c  415e                     pop r14
0024b27e  415d                     pop r13
0024b280  415c                     pop r12
0024b282  5f                       pop rdi
0024b283  5e                       pop rsi
0024b284  5d                       pop rbp
0024b285  5b                       pop rbx
0024b286  c3                       ret
