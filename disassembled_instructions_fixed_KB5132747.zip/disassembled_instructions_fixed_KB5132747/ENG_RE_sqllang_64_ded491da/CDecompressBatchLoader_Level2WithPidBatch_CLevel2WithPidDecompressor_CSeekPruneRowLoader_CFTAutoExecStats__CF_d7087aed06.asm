; CDecompressBatchLoader<Level2WithPidBatch,CLevel2WithPidDecompressor,CSeekPruneRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x975400, 1416 bytes in 1 chunk(s)

; chunk at RVA 0x975400 (1416 bytes)
00975400  488bc4                   mov rax, rsp
00975403  4c894820                 mov qword ptr [rax + 0x20], r9
00975407  895010                   mov dword ptr [rax + 0x10], edx
0097540a  55                       push rbp
0097540b  56                       push rsi
0097540c  57                       push rdi
0097540d  4154                     push r12
0097540f  4155                     push r13
00975411  4156                     push r14
00975413  4157                     push r15
00975415  488d68a1                 lea rbp, [rax - 0x5f]
00975419  4881ece0000000           sub rsp, 0xe0
00975420  48c74517feffffff         mov qword ptr [rbp + 0x17], 0xfffffffffffffffe
00975428  48895818                 mov qword ptr [rax + 0x18], rbx
0097542c  4d8be8                   mov r13, r8
0097542f  8bfa                     mov edi, edx
00975431  488bf1                   mov rsi, rcx
00975434  83792002                 cmp dword ptr [rcx + 0x20], 2
00975438  7507                     jne 0x975441
0097543a  33c0                     xor eax, eax
0097543c  e9cc040000               jmp 0x97590d
00975441  4533ff                   xor r15d, r15d
00975444  44897da7                 mov dword ptr [rbp - 0x59], r15d
00975448  4c897daf                 mov qword ptr [rbp - 0x51], r15
0097544c  44887db7                 mov byte ptr [rbp - 0x49], r15b
00975450  0f57c0                   xorps xmm0, xmm0
00975453  660f7f45c7               movdqa xmmword ptr [rbp - 0x39], xmm0
00975458  0f57c9                   xorps xmm1, xmm1
0097545b  660f7f4dd7               movdqa xmmword ptr [rbp - 0x29], xmm1
00975460  660f7f45e7               movdqa xmmword ptr [rbp - 0x19], xmm0
00975465  4c897df7                 mov qword ptr [rbp - 9], r15
00975469  c745ff01000000           mov dword ptr [rbp - 1], 1
00975470  4c897d07                 mov qword ptr [rbp + 7], r15
00975474  44897c2420               mov dword ptr [rsp + 0x20], r15d
00975479  32c9                     xor cl, cl
0097547b  884d67                   mov byte ptr [rbp + 0x67], cl
0097547e  4c8d257bab68ff           lea r12, [rip - 0x975485]
00975485  41c6451000               mov byte ptr [r13 + 0x10], 0
0097548a  80be582e000000           cmp byte ptr [rsi + 0x2e58], 0
00975491  0f8495000000             je 0x97552c
00975497  c686582e000000           mov byte ptr [rsi + 0x2e58], 0
0097549e  488b9e502e0000           mov rbx, qword ptr [rsi + 0x2e50]
009754a5  4c8bc3                   mov r8, rbx
009754a8  33d2                     xor edx, edx
009754aa  498bcd                   mov rcx, r13
009754ad  e8ee74ffff               call 0x96c9a0
009754b2  488b5360                 mov rdx, qword ptr [rbx + 0x60]
009754b6  418b4d00                 mov ecx, dword ptr [r13]
009754ba  ffc9                     dec ecx
009754bc  4803c9                   add rcx, rcx
009754bf  498b4560                 mov rax, qword ptr [r13 + 0x60]
009754c3  0f1002                   movups xmm0, xmmword ptr [rdx]
009754c6  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
009754ca  488b86502e0000           mov rax, qword ptr [rsi + 0x2e50]
009754d1  ff08                     dec dword ptr [rax]
009754d3  44897da7                 mov dword ptr [rbp - 0x59], r15d
009754d7  498b4508                 mov rax, qword ptr [r13 + 8]
009754db  488945af                 mov qword ptr [rbp - 0x51], rax
009754df  418b5500                 mov edx, dword ptr [r13]
009754e3  498b4520                 mov rax, qword ptr [r13 + 0x20]
009754e7  488d0cd0                 lea rcx, [rax + rdx*8]
009754eb  48894dc7                 mov qword ptr [rbp - 0x39], rcx
009754ef  498b4528                 mov rax, qword ptr [r13 + 0x28]
009754f3  488d0c90                 lea rcx, [rax + rdx*4]
009754f7  48894dcf                 mov qword ptr [rbp - 0x31], rcx
009754fb  498b4530                 mov rax, qword ptr [r13 + 0x30]
009754ff  488d0c90                 lea rcx, [rax + rdx*4]
00975503  48894dd7                 mov qword ptr [rbp - 0x29], rcx
00975507  b801000000               mov eax, 1
0097550c  2bc2                     sub eax, edx
0097550e  03f8                     add edi, eax
00975510  897d6f                   mov dword ptr [rbp + 0x6f], edi
00975513  4c8d75a7                 lea r14, [rbp - 0x59]
00975517  c686582e000000           mov byte ptr [rsi + 0x2e58], 0
0097551e  c744242001000000         mov dword ptr [rsp + 0x20], 1
00975526  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
0097552a  eb03                     jmp 0x97552f
0097552c  4d8bf5                   mov r14, r13
0097552f  837e2000                 cmp dword ptr [rsi + 0x20], 0
00975533  7558                     jne 0x97558d
00975535  4c897c2428               mov qword ptr [rsp + 0x28], r15
0097553a  44897c2430               mov dword ptr [rsp + 0x30], r15d
0097553f  4c897c2438               mov qword ptr [rsp + 0x38], r15
00975544  44897d87                 mov dword ptr [rbp - 0x79], r15d
00975548  4c897d8f                 mov qword ptr [rbp - 0x71], r15
0097554c  44897d97                 mov dword ptr [rbp - 0x69], r15d
00975550  6644897d9b               mov word ptr [rbp - 0x65], r15w
00975555  488d4e28                 lea rcx, [rsi + 0x28]
00975559  488b01                   mov rax, qword ptr [rcx]
0097555c  4d8bc1                   mov r8, r9
0097555f  488d542428               lea rdx, [rsp + 0x28]
00975564  ff10                     call qword ptr [rax]
00975566  c6456701                 mov byte ptr [rbp + 0x67], 1
0097556a  3dc60e0400               cmp eax, 0x40ec6
0097556f  0f8474030000             je 0x9758e9
00975575  488d8e48090000           lea rcx, [rsi + 0x948]
0097557c  488d542428               lea rdx, [rsp + 0x28]
00975581  e87a6cf5ff               call 0x8cc200
00975586  c7462001000000           mov dword ptr [rsi + 0x20], 1
0097558d  488b4630                 mov rax, qword ptr [rsi + 0x30]
00975591  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00975598  4d894608                 mov qword ptr [r14 + 8], r8
0097559c  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
009755a3  488b5630                 mov rdx, qword ptr [rsi + 0x30]
009755a7  8b423c                   mov eax, dword ptr [rdx + 0x3c]
009755aa  83e007                   and eax, 7
009755ad  83f805                   cmp eax, 5
009755b0  773c                     ja 0x9755ee
009755b2  4898                     cdqe
009755b4  418b8c8428599700         mov ecx, dword ptr [r12 + rax*4 + 0x975928]
009755bc  4903cc                   add rcx, r12
009755bf  ffe1                     jmp rcx
009755c1  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009755c5  0f95c3                   setne bl
009755c8  eb26                     jmp 0x9755f0
009755ca  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009755ce  0f9dc3                   setge bl
009755d1  eb1d                     jmp 0x9755f0
009755d3  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009755d7  0f9ec3                   setle bl
009755da  eb14                     jmp 0x9755f0
009755dc  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009755e0  0f9fc3                   setg bl
009755e3  eb0b                     jmp 0x9755f0
009755e5  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009755e9  0f9cc3                   setl bl
009755ec  eb02                     jmp 0x9755f0
009755ee  32db                     xor bl, bl
009755f0  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
009755f7  8b424c                   mov eax, dword ptr [rdx + 0x4c]
009755fa  83e007                   and eax, 7
009755fd  83f805                   cmp eax, 5
00975600  7741                     ja 0x975643
00975602  4898                     cdqe
00975604  418b8c8440599700         mov ecx, dword ptr [r12 + rax*4 + 0x975940]
0097560c  4903cc                   add rcx, r12
0097560f  ffe1                     jmp rcx
00975611  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975615  410f95c4                 setne r12b
00975619  eb2b                     jmp 0x975646
0097561b  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097561f  410f9dc4                 setge r12b
00975623  eb21                     jmp 0x975646
00975625  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975629  410f9ec4                 setle r12b
0097562d  eb17                     jmp 0x975646
0097562f  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975633  410f9fc4                 setg r12b
00975637  eb0d                     jmp 0x975646
00975639  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097563d  410f9cc4                 setl r12b
00975641  eb03                     jmp 0x975646
00975643  4532e4                   xor r12b, r12b
00975646  4889751f                 mov qword ptr [rbp + 0x1f], rsi
0097564a  0f31                     rdtsc
0097564c  48c1e220                 shl rdx, 0x20
00975650  480bc2                   or rax, rdx
00975653  48894608                 mov qword ptr [rsi + 8], rax
00975657  488d8e48090000           lea rcx, [rsi + 0x948]
0097565e  4d8bc6                   mov r8, r14
00975661  8bd7                     mov edx, edi
00975663  e83889ffff               call 0x96dfa0
00975668  84c0                     test al, al
0097566a  7504                     jne 0x975670
0097566c  44897e20                 mov dword ptr [rsi + 0x20], r15d
00975670  418b06                   mov eax, dword ptr [r14]
00975673  48014610                 add qword ptr [rsi + 0x10], rax
00975677  0f31                     rdtsc
00975679  48c1e220                 shl rdx, 0x20
0097567d  480bc2                   or rax, rdx
00975680  482b4608                 sub rax, qword ptr [rsi + 8]
00975684  480106                   add qword ptr [rsi], rax
00975687  ff4618                   inc dword ptr [rsi + 0x18]
0097568a  418b06                   mov eax, dword ptr [r14]
0097568d  448bc0                   mov r8d, eax
00975690  85c0                     test eax, eax
00975692  0f84cc010000             je 0x975864
00975698  84db                     test bl, bl
0097569a  7509                     jne 0x9756a5
0097569c  4584e4                   test r12b, r12b
0097569f  0f84bf010000             je 0x975864
009756a5  448bc8                   mov r9d, eax
009756a8  84db                     test bl, bl
009756aa  0f8480000000             je 0x975730
009756b0  458bd7                   mov r10d, r15d
009756b3  4c8b5e30                 mov r11, qword ptr [rsi + 0x30]
009756b7  85c0                     test eax, eax
009756b9  746c                     je 0x975727
009756bb  498b5e20                 mov rbx, qword ptr [r14 + 0x20]
009756bf  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
009756c3  4183e007                 and r8d, 7
009756c7  488d3d32a968ff           lea rdi, [rip - 0x9756ce]
009756ce  6690                     nop
009756d0  418bca                   mov ecx, r10d
009756d3  4c8b0ccb                 mov r9, qword ptr [rbx + rcx*8]
009756d7  4183f805                 cmp r8d, 5
009756db  0f87ae000000             ja 0x97578f
009756e1  4963c8                   movsxd rcx, r8d
009756e4  8b948f58599700           mov edx, dword ptr [rdi + rcx*4 + 0x975958]
009756eb  4803d7                   add rdx, rdi
009756ee  ffe2                     jmp rdx
009756f0  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009756f4  0f94c1                   sete cl
009756f7  eb22                     jmp 0x97571b
009756f9  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009756fd  0f9cc1                   setl cl
00975700  eb19                     jmp 0x97571b
00975702  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975706  0f9fc1                   setg cl
00975709  eb10                     jmp 0x97571b
0097570b  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
0097570f  0f9ec1                   setle cl
00975712  eb07                     jmp 0x97571b
00975714  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975718  0f9dc1                   setge cl
0097571b  84c9                     test cl, cl
0097571d  7570                     jne 0x97578f
0097571f  41ffc2                   inc r10d
00975722  443bd0                   cmp r10d, eax
00975725  72a9                     jb 0x9756d0
00975727  45893e                   mov dword ptr [r14], r15d
0097572a  418bc7                   mov eax, r15d
0097572d  458bcf                   mov r9d, r15d
00975730  458bc1                   mov r8d, r9d
00975733  4584e4                   test r12b, r12b
00975736  0f8428010000             je 0x975864
0097573c  85c0                     test eax, eax
0097573e  0f8420010000             je 0x975864
00975744  4c8b5e30                 mov r11, qword ptr [rsi + 0x30]
00975748  498b7e20                 mov rdi, qword ptr [r14 + 0x20]
0097574c  4c8d25ada868ff           lea r12, [rip - 0x975753]
00975753  0f1f4000                 nop dword ptr [rax]
00975757  660f1f840000000000       nop word ptr [rax + rax]
00975760  458bd1                   mov r10d, r9d
00975763  ffc8                     dec eax
00975765  448bc8                   mov r9d, eax
00975768  488b1cc7                 mov rbx, qword ptr [rdi + rax*8]
0097576c  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00975770  83e107                   and ecx, 7
00975773  458bc2                   mov r8d, r10d
00975776  83f905                   cmp ecx, 5
00975779  0f87e5000000             ja 0x975864
0097577f  4863c9                   movsxd rcx, ecx
00975782  418b948c70599700         mov edx, dword ptr [r12 + rcx*4 + 0x975970]
0097578a  4903d4                   add rdx, r12
0097578d  ffe2                     jmp rdx
0097578f  443bd0                   cmp r10d, eax
00975792  7393                     jae 0x975727
00975794  448bc8                   mov r9d, eax
00975797  4585d2                   test r10d, r10d
0097579a  7494                     je 0x975730
0097579c  452bca                   sub r9d, r10d
0097579f  458bdf                   mov r11d, r15d
009757a2  7478                     je 0x97581c
009757a4  498bd7                   mov rdx, r15
009757a7  498bdf                   mov rbx, r15
009757aa  498bff                   mov rdi, r15
009757ad  0f1f00                   nop dword ptr [rax]
009757b0  438d0413                 lea eax, [r11 + r10]
009757b4  448bc0                   mov r8d, eax
009757b7  498b4e20                 mov rcx, qword ptr [r14 + 0x20]
009757bb  488b04c1                 mov rax, qword ptr [rcx + rax*8]
009757bf  4889040f                 mov qword ptr [rdi + rcx], rax
009757c3  498b4e30                 mov rcx, qword ptr [r14 + 0x30]
009757c7  428b0481                 mov eax, dword ptr [rcx + r8*4]
009757cb  89040b                   mov dword ptr [rbx + rcx], eax
009757ce  498b4e28                 mov rcx, qword ptr [r14 + 0x28]
009757d2  428b0481                 mov eax, dword ptr [rcx + r8*4]
009757d6  89040b                   mov dword ptr [rbx + rcx], eax
009757d9  4d03c0                   add r8, r8
009757dc  498b4638                 mov rax, qword ptr [r14 + 0x38]
009757e0  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
009757e5  0f110410                 movups xmmword ptr [rax + rdx], xmm0
009757e9  498b4648                 mov rax, qword ptr [r14 + 0x48]
009757ed  4885c0                   test rax, rax
009757f0  7409                     je 0x9757fb
009757f2  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
009757f7  0f110410                 movups xmmword ptr [rax + rdx], xmm0
009757fb  498b4660                 mov rax, qword ptr [r14 + 0x60]
009757ff  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00975804  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00975808  41ffc3                   inc r11d
0097580b  4883c708                 add rdi, 8
0097580f  4883c304                 add rbx, 4
00975813  4883c210                 add rdx, 0x10
00975817  453bd9                   cmp r11d, r9d
0097581a  7294                     jb 0x9757b0
0097581c  45890e                   mov dword ptr [r14], r9d
0097581f  418bc1                   mov eax, r9d
00975822  e909ffffff               jmp 0x975730
00975827  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097582b  0f94c1                   sete cl
0097582e  eb22                     jmp 0x975852
00975830  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975834  0f9cc1                   setl cl
00975837  eb19                     jmp 0x975852
00975839  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097583d  0f9fc1                   setg cl
00975840  eb10                     jmp 0x975852
00975842  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975846  0f9ec1                   setle cl
00975849  eb07                     jmp 0x975852
0097584b  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097584f  0f9dc1                   setge cl
00975852  84c9                     test cl, cl
00975854  750e                     jne 0x975864
00975856  418906                   mov dword ptr [r14], eax
00975859  448bc0                   mov r8d, eax
0097585c  85c0                     test eax, eax
0097585e  0f85fcfeffff             jne 0x975760
00975864  80be592e000000           cmp byte ptr [rsi + 0x2e59], 0
0097586b  7463                     je 0x9758d0
0097586d  458b06                   mov r8d, dword ptr [r14]
00975870  4585c0                   test r8d, r8d
00975873  745b                     je 0x9758d0
00975875  c686582e000001           mov byte ptr [rsi + 0x2e58], 1
0097587c  418b1e                   mov ebx, dword ptr [r14]
0097587f  ffcb                     dec ebx
00975881  488bbe502e0000           mov rdi, qword ptr [rsi + 0x2e50]
00975888  4d8bc6                   mov r8, r14
0097588b  8bd3                     mov edx, ebx
0097588d  488bcf                   mov rcx, rdi
00975890  e80b71ffff               call 0x96c9a0
00975895  448bc3                   mov r8d, ebx
00975898  4d03c0                   add r8, r8
0097589b  498b5660                 mov rdx, qword ptr [r14 + 0x60]
0097589f  8b0f                     mov ecx, dword ptr [rdi]
009758a1  ffc9                     dec ecx
009758a3  4803c9                   add rcx, rcx
009758a6  488b4760                 mov rax, qword ptr [rdi + 0x60]
009758aa  420f1004c2               movups xmm0, xmmword ptr [rdx + r8*8]
009758af  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
009758b3  41ff0e                   dec dword ptr [r14]
009758b6  41c6451001               mov byte ptr [r13 + 0x10], 1
009758bb  488b86502e0000           mov rax, qword ptr [rsi + 0x2e50]
009758c2  488b4820                 mov rcx, qword ptr [rax + 0x20]
009758c6  488b01                   mov rax, qword ptr [rcx]
009758c9  49894518                 mov qword ptr [r13 + 0x18], rax
009758cd  458b06                   mov r8d, dword ptr [r14]
009758d0  8b442420                 mov eax, dword ptr [rsp + 0x20]
009758d4  4103c0                   add eax, r8d
009758d7  89442420                 mov dword ptr [rsp + 0x20], eax
009758db  7521                     jne 0x9758fe
009758dd  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
009758e0  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009758e4  e995fbffff               jmp 0x97547e
009758e9  c7462002000000           mov dword ptr [rsi + 0x20], 2
009758f0  41837d0000               cmp dword ptr [r13], 0
009758f5  410f95c7                 setne r15b
009758f9  418bc7                   mov eax, r15d
009758fc  eb0f                     jmp 0x97590d
009758fe  41894500                 mov dword ptr [r13], eax
00975902  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00975906  f6d9                     neg cl
00975908  1bc0                     sbb eax, eax
0097590a  83c002                   add eax, 2
0097590d  488b9c2430010000         mov rbx, qword ptr [rsp + 0x130]
00975915  4881c4e0000000           add rsp, 0xe0
0097591c  415f                     pop r15
0097591e  415e                     pop r14
00975920  415d                     pop r13
00975922  415c                     pop r12
00975924  5f                       pop rdi
00975925  5e                       pop rsi
00975926  5d                       pop rbp
00975927  c3                       ret
00975928  ee                       out dx, al
00975929  55                       push rbp
0097592a  97                       xchg edi, eax
0097592b  00c1                     add cl, al
0097592d  55                       push rbp
0097592e  97                       xchg edi, eax
0097592f  00ca                     add dl, cl
00975931  55                       push rbp
00975932  97                       xchg edi, eax
00975933  00dc                     add ah, bl
00975935  55                       push rbp
00975936  97                       xchg edi, eax
00975937  00d3                     add bl, dl
00975939  55                       push rbp
0097593a  97                       xchg edi, eax
0097593b  00e5                     add ch, ah
0097593d  55                       push rbp
0097593e  97                       xchg edi, eax
0097593f  004356                   add byte ptr [rbx + 0x56], al
00975942  97                       xchg edi, eax
00975943  0011                     add byte ptr [rcx], dl
00975945  56                       push rsi
00975946  97                       xchg edi, eax
00975947  001b                     add byte ptr [rbx], bl
00975949  56                       push rsi
0097594a  97                       xchg edi, eax
0097594b  002f                     add byte ptr [rdi], ch
0097594d  56                       push rsi
0097594e  97                       xchg edi, eax
0097594f  002556970039             add byte ptr [rip + 0x39009756], ah
00975955  56                       push rsi
00975956  97                       xchg edi, eax
00975957  008f579700f0             add byte ptr [rdi - 0xfff68a9], cl
0097595d  56                       push rsi
0097595e  97                       xchg edi, eax
0097595f  00f9                     add cl, bh
00975961  56                       push rsi
00975962  97                       xchg edi, eax
00975963  000b                     add byte ptr [rbx], cl
00975965  57                       push rdi
00975966  97                       xchg edi, eax
00975967  0002                     add byte ptr [rdx], al
00975969  57                       push rdi
0097596a  97                       xchg edi, eax
0097596b  001457                   add byte ptr [rdi + rdx*2], dl
0097596e  97                       xchg edi, eax
0097596f  00645897                 add byte ptr [rax + rbx*2 - 0x69], ah
00975973  0027                     add byte ptr [rdi], ah
00975975  58                       pop rax
00975976  97                       xchg edi, eax
00975977  0030                     add byte ptr [rax], dh
00975979  58                       pop rax
0097597a  97                       xchg edi, eax
0097597b  004258                   add byte ptr [rdx + 0x58], al
0097597e  97                       xchg edi, eax
0097597f  0039                     add byte ptr [rcx], bh
00975981  58                       pop rax
00975982  97                       xchg edi, eax
00975983  004b58                   add byte ptr [rbx + 0x58], cl
00975986  97                       xchg edi, eax
