; CDecompressBatchLoader<Level1Batch,CLevel1Decompressor,CSeekPruneRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x973740, 1488 bytes in 3 chunk(s)

; chunk at RVA 0x973740 (47 bytes)
00973740  4c894c2420               mov qword ptr [rsp + 0x20], r9
00973745  89542410                 mov dword ptr [rsp + 0x10], edx
00973749  53                       push rbx
0097374a  4154                     push r12
0097374c  4881ecb8000000           sub rsp, 0xb8
00973753  83792002                 cmp dword ptr [rcx + 0x20], 2
00973757  4d8be0                   mov r12, r8
0097375a  448bd2                   mov r10d, edx
0097375d  488bd9                   mov rbx, rcx
00973760  750d                     jne 0x97376f
00973762  33c0                     xor eax, eax
00973764  4881c4b8000000           add rsp, 0xb8
0097376b  415c                     pop r12
0097376d  5b                       pop rbx
0097376e  c3                       ret

; chunk at RVA 0x97376f (1345 bytes)
0097376f  4889ac24e0000000         mov qword ptr [rsp + 0xe0], rbp
00973777  0f57c0                   xorps xmm0, xmm0
0097377a  4889b424b0000000         mov qword ptr [rsp + 0xb0], rsi
00973782  33f6                     xor esi, esi
00973784  4889bc24a8000000         mov qword ptr [rsp + 0xa8], rdi
0097378c  32c0                     xor al, al
0097378e  4c89ac24a0000000         mov qword ptr [rsp + 0xa0], r13
00973796  448bee                   mov r13d, esi
00973799  4c89b42498000000         mov qword ptr [rsp + 0x98], r14
009737a1  888424d0000000           mov byte ptr [rsp + 0xd0], al
009737a8  4c89bc2490000000         mov qword ptr [rsp + 0x90], r15
009737b0  89742450                 mov dword ptr [rsp + 0x50], esi
009737b4  4889742458               mov qword ptr [rsp + 0x58], rsi
009737b9  4088742460               mov byte ptr [rsp + 0x60], sil
009737be  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
009737c4  4889b42480000000         mov qword ptr [rsp + 0x80], rsi
009737cc  4188742410               mov byte ptr [r12 + 0x10], sil
009737d1  4c8d1d28c868ff           lea r11, [rip - 0x9737d8]
009737d8  4038b3280c0000           cmp byte ptr [rbx + 0xc28], sil
009737df  0f84c8000000             je 0x9738ad
009737e5  4c8b8b200c0000           mov r9, qword ptr [rbx + 0xc20]
009737ec  488d7c2450               lea rdi, [rsp + 0x50]
009737f1  4088b3280c0000           mov byte ptr [rbx + 0xc28], sil
009737f8  41bd01000000             mov r13d, 1
009737fe  41ff0424                 inc dword ptr [r12]
00973802  418b1424                 mov edx, dword ptr [r12]
00973806  4d8b4120                 mov r8, qword ptr [r9 + 0x20]
0097380a  ffca                     dec edx
0097380c  498b4c2420               mov rcx, qword ptr [r12 + 0x20]
00973811  89742450                 mov dword ptr [rsp + 0x50], esi
00973815  498b00                   mov rax, qword ptr [r8]
00973818  488904d1                 mov qword ptr [rcx + rdx*8], rax
0097381c  4d8b4130                 mov r8, qword ptr [r9 + 0x30]
00973820  418b1424                 mov edx, dword ptr [r12]
00973824  498b4c2430               mov rcx, qword ptr [r12 + 0x30]
00973829  ffca                     dec edx
0097382b  418b00                   mov eax, dword ptr [r8]
0097382e  890491                   mov dword ptr [rcx + rdx*4], eax
00973831  418b1424                 mov edx, dword ptr [r12]
00973835  4d8b4128                 mov r8, qword ptr [r9 + 0x28]
00973839  ffca                     dec edx
0097383b  498b4c2428               mov rcx, qword ptr [r12 + 0x28]
00973840  4c8b8c24e8000000         mov r9, qword ptr [rsp + 0xe8]
00973848  418b00                   mov eax, dword ptr [r8]
0097384b  890491                   mov dword ptr [rcx + rdx*4], eax
0097384e  488b83200c0000           mov rax, qword ptr [rbx + 0xc20]
00973855  ff08                     dec dword ptr [rax]
00973857  418b1424                 mov edx, dword ptr [r12]
0097385b  498b442408               mov rax, qword ptr [r12 + 8]
00973860  4889442458               mov qword ptr [rsp + 0x58], rax
00973865  498b442420               mov rax, qword ptr [r12 + 0x20]
0097386a  488d0cd0                 lea rcx, [rax + rdx*8]
0097386e  498b442428               mov rax, qword ptr [r12 + 0x28]
00973873  48894c2470               mov qword ptr [rsp + 0x70], rcx
00973878  488d0c90                 lea rcx, [rax + rdx*4]
0097387c  498b442430               mov rax, qword ptr [r12 + 0x30]
00973881  48894c2478               mov qword ptr [rsp + 0x78], rcx
00973886  4088b3280c0000           mov byte ptr [rbx + 0xc28], sil
0097388d  488d0c90                 lea rcx, [rax + rdx*4]
00973891  b801000000               mov eax, 1
00973896  2bc2                     sub eax, edx
00973898  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
009738a0  4403d0                   add r10d, eax
009738a3  44899424d8000000         mov dword ptr [rsp + 0xd8], r10d
009738ab  eb03                     jmp 0x9738b0
009738ad  498bfc                   mov rdi, r12
009738b0  397320                   cmp dword ptr [rbx + 0x20], esi
009738b3  0f858d000000             jne 0x973946
009738b9  488b4328                 mov rax, qword ptr [rbx + 0x28]
009738bd  488d4b28                 lea rcx, [rbx + 0x28]
009738c1  4d8bc1                   mov r8, r9
009738c4  4889742420               mov qword ptr [rsp + 0x20], rsi
009738c9  488d542420               lea rdx, [rsp + 0x20]
009738ce  89742428                 mov dword ptr [rsp + 0x28], esi
009738d2  4889742430               mov qword ptr [rsp + 0x30], rsi
009738d7  89742438                 mov dword ptr [rsp + 0x38], esi
009738db  4889742440               mov qword ptr [rsp + 0x40], rsi
009738e0  89742448                 mov dword ptr [rsp + 0x48], esi
009738e4  668974244c               mov word ptr [rsp + 0x4c], si
009738e9  c68424d000000001         mov byte ptr [rsp + 0xd0], 1
009738f1  ff10                     call qword ptr [rax]
009738f3  3dc60e0400               cmp eax, 0x40ec6
009738f8  0f8451030000             je 0x973c4f
009738fe  488b4c2420               mov rcx, qword ptr [rsp + 0x20]
00973903  4c8d1df6c668ff           lea r11, [rip - 0x97390a]
0097390a  8b442428                 mov eax, dword ptr [rsp + 0x28]
0097390e  448b9424d8000000         mov r10d, dword ptr [rsp + 0xd8]
00973916  48898b60090000           mov qword ptr [rbx + 0x960], rcx
0097391d  48898b68090000           mov qword ptr [rbx + 0x968], rcx
00973924  898358090000             mov dword ptr [rbx + 0x958], eax
0097392a  4889b350090000           mov qword ptr [rbx + 0x950], rsi
00973931  6689b3180c0000           mov word ptr [rbx + 0xc18], si
00973938  4889b3100c0000           mov qword ptr [rbx + 0xc10], rsi
0097393f  c7432001000000           mov dword ptr [rbx + 0x20], 1
00973946  488b4330                 mov rax, qword ptr [rbx + 0x30]
0097394a  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00973951  4c894708                 mov qword ptr [rdi + 8], r8
00973955  488b5330                 mov rdx, qword ptr [rbx + 0x30]
00973959  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00973960  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00973963  83e007                   and eax, 7
00973966  83f805                   cmp eax, 5
00973969  7741                     ja 0x9739ac
0097396b  4898                     cdqe
0097396d  418b8c83b03c9700         mov ecx, dword ptr [r11 + rax*4 + 0x973cb0]
00973975  4903cb                   add rcx, r11
00973978  ffe1                     jmp rcx
0097397a  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097397e  400f95c5                 setne bpl
00973982  eb2b                     jmp 0x9739af
00973984  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973988  400f9dc5                 setge bpl
0097398c  eb21                     jmp 0x9739af
0097398e  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973992  400f9ec5                 setle bpl
00973996  eb17                     jmp 0x9739af
00973998  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097399c  400f9fc5                 setg bpl
009739a0  eb0d                     jmp 0x9739af
009739a2  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009739a6  400f9cc5                 setl bpl
009739aa  eb03                     jmp 0x9739af
009739ac  4032ed                   xor bpl, bpl
009739af  8b424c                   mov eax, dword ptr [rdx + 0x4c]
009739b2  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
009739b9  83e007                   and eax, 7
009739bc  83f805                   cmp eax, 5
009739bf  7741                     ja 0x973a02
009739c1  4898                     cdqe
009739c3  418b8c83c83c9700         mov ecx, dword ptr [r11 + rax*4 + 0x973cc8]
009739cb  4903cb                   add rcx, r11
009739ce  ffe1                     jmp rcx
009739d0  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009739d4  410f95c7                 setne r15b
009739d8  eb2b                     jmp 0x973a05
009739da  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009739de  410f9dc7                 setge r15b
009739e2  eb21                     jmp 0x973a05
009739e4  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009739e8  410f9ec7                 setle r15b
009739ec  eb17                     jmp 0x973a05
009739ee  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009739f2  410f9fc7                 setg r15b
009739f6  eb0d                     jmp 0x973a05
009739f8  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009739fc  410f9cc7                 setl r15b
00973a00  eb03                     jmp 0x973a05
00973a02  4532ff                   xor r15b, r15b
00973a05  488d8b48090000           lea rcx, [rbx + 0x948]
00973a0c  4c8bc7                   mov r8, rdi
00973a0f  418bd2                   mov edx, r10d
00973a12  e8a99cffff               call 0x96d6c0
00973a17  84c0                     test al, al
00973a19  7503                     jne 0x973a1e
00973a1b  897320                   mov dword ptr [rbx + 0x20], esi
00973a1e  8b07                     mov eax, dword ptr [rdi]
00973a20  448bc8                   mov r9d, eax
00973a23  85c0                     test eax, eax
00973a25  0f8487010000             je 0x973bb2
00973a2b  4084ed                   test bpl, bpl
00973a2e  7509                     jne 0x973a39
00973a30  4584ff                   test r15b, r15b
00973a33  0f8479010000             je 0x973bb2
00973a39  448bc0                   mov r8d, eax
00973a3c  4084ed                   test bpl, bpl
00973a3f  747d                     je 0x973abe
00973a41  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00973a45  448bce                   mov r9d, esi
00973a48  85c0                     test eax, eax
00973a4a  746b                     je 0x973ab7
00973a4c  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00973a50  488d2da9c568ff           lea rbp, [rip - 0x973a57]
00973a57  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
00973a5b  4183e007                 and r8d, 7
00973a5f  90                       nop
00973a60  418bc9                   mov ecx, r9d
00973a63  4d8b14ce                 mov r10, qword ptr [r14 + rcx*8]
00973a67  4183f805                 cmp r8d, 5
00973a6b  0f879f000000             ja 0x973b10
00973a71  4963c8                   movsxd rcx, r8d
00973a74  8b948de03c9700           mov edx, dword ptr [rbp + rcx*4 + 0x973ce0]
00973a7b  4803d5                   add rdx, rbp
00973a7e  ffe2                     jmp rdx
00973a80  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00973a84  0f94c1                   sete cl
00973a87  eb22                     jmp 0x973aab
00973a89  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00973a8d  0f9cc1                   setl cl
00973a90  eb19                     jmp 0x973aab
00973a92  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00973a96  0f9fc1                   setg cl
00973a99  eb10                     jmp 0x973aab
00973a9b  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00973a9f  0f9ec1                   setle cl
00973aa2  eb07                     jmp 0x973aab
00973aa4  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00973aa8  0f9dc1                   setge cl
00973aab  84c9                     test cl, cl
00973aad  7561                     jne 0x973b10
00973aaf  41ffc1                   inc r9d
00973ab2  443bc8                   cmp r9d, eax
00973ab5  72a9                     jb 0x973a60
00973ab7  8937                     mov dword ptr [rdi], esi
00973ab9  8bc6                     mov eax, esi
00973abb  448bc6                   mov r8d, esi
00973abe  458bc8                   mov r9d, r8d
00973ac1  4584ff                   test r15b, r15b
00973ac4  0f84e8000000             je 0x973bb2
00973aca  85c0                     test eax, eax
00973acc  0f84e0000000             je 0x973bb2
00973ad2  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00973ad6  4c8d3d23c568ff           lea r15, [rip - 0x973add]
00973add  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
00973ae1  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00973ae5  ffc8                     dec eax
00973ae7  458bd0                   mov r10d, r8d
00973aea  83e107                   and ecx, 7
00973aed  448bc0                   mov r8d, eax
00973af0  458bca                   mov r9d, r10d
00973af3  498b2cc6                 mov rbp, qword ptr [r14 + rax*8]
00973af7  83f905                   cmp ecx, 5
00973afa  0f87b2000000             ja 0x973bb2
00973b00  4863c9                   movsxd rcx, ecx
00973b03  418b948ff83c9700         mov edx, dword ptr [r15 + rcx*4 + 0x973cf8]
00973b0b  4903d7                   add rdx, r15
00973b0e  ffe2                     jmp rdx
00973b10  443bc8                   cmp r9d, eax
00973b13  73a2                     jae 0x973ab7
00973b15  448bc0                   mov r8d, eax
00973b18  4585c9                   test r9d, r9d
00973b1b  74a1                     je 0x973abe
00973b1d  448bde                   mov r11d, esi
00973b20  452bc1                   sub r8d, r9d
00973b23  7446                     je 0x973b6b
00973b25  4c8bd6                   mov r10, rsi
00973b28  4c8bf6                   mov r14, rsi
00973b2b  0f1f440000               nop dword ptr [rax + rax]
00973b30  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00973b34  438d040b                 lea eax, [r11 + r9]
00973b38  8bd0                     mov edx, eax
00973b3a  4d8d5204                 lea r10, [r10 + 4]
00973b3e  41ffc3                   inc r11d
00973b41  4d8d7608                 lea r14, [r14 + 8]
00973b45  488b04c1                 mov rax, qword ptr [rcx + rax*8]
00973b49  4989440ef8               mov qword ptr [r14 + rcx - 8], rax
00973b4e  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00973b52  8b0491                   mov eax, dword ptr [rcx + rdx*4]
00973b55  4189440afc               mov dword ptr [r10 + rcx - 4], eax
00973b5a  488b4f28                 mov rcx, qword ptr [rdi + 0x28]
00973b5e  8b0491                   mov eax, dword ptr [rcx + rdx*4]
00973b61  4189440afc               mov dword ptr [r10 + rcx - 4], eax
00973b66  453bd8                   cmp r11d, r8d
00973b69  72c5                     jb 0x973b30
00973b6b  448907                   mov dword ptr [rdi], r8d
00973b6e  418bc0                   mov eax, r8d
00973b71  e948ffffff               jmp 0x973abe
00973b76  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00973b7a  0f94c1                   sete cl
00973b7d  eb22                     jmp 0x973ba1
00973b7f  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00973b83  0f9cc1                   setl cl
00973b86  eb19                     jmp 0x973ba1
00973b88  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00973b8c  0f9fc1                   setg cl
00973b8f  eb10                     jmp 0x973ba1
00973b91  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00973b95  0f9ec1                   setle cl
00973b98  eb07                     jmp 0x973ba1
00973b9a  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00973b9e  0f9dc1                   setge cl
00973ba1  84c9                     test cl, cl
00973ba3  750d                     jne 0x973bb2
00973ba5  8907                     mov dword ptr [rdi], eax
00973ba7  448bc8                   mov r9d, eax
00973baa  85c0                     test eax, eax
00973bac  0f852fffffff             jne 0x973ae1
00973bb2  4038b3290c0000           cmp byte ptr [rbx + 0xc29], sil
00973bb9  747a                     je 0x973c35
00973bbb  448b0f                   mov r9d, dword ptr [rdi]
00973bbe  4585c9                   test r9d, r9d
00973bc1  7472                     je 0x973c35
00973bc3  4c8b93200c0000           mov r10, qword ptr [rbx + 0xc20]
00973bca  c683280c000001           mov byte ptr [rbx + 0xc28], 1
00973bd1  448b0f                   mov r9d, dword ptr [rdi]
00973bd4  41ffc9                   dec r9d
00973bd7  41ff02                   inc dword ptr [r10]
00973bda  418b12                   mov edx, dword ptr [r10]
00973bdd  4c8b4720                 mov r8, qword ptr [rdi + 0x20]
00973be1  ffca                     dec edx
00973be3  498b4a20                 mov rcx, qword ptr [r10 + 0x20]
00973be7  4b8b04c8                 mov rax, qword ptr [r8 + r9*8]
00973beb  488904d1                 mov qword ptr [rcx + rdx*8], rax
00973bef  418b12                   mov edx, dword ptr [r10]
00973bf2  4c8b4730                 mov r8, qword ptr [rdi + 0x30]
00973bf6  ffca                     dec edx
00973bf8  498b4a30                 mov rcx, qword ptr [r10 + 0x30]
00973bfc  438b0488                 mov eax, dword ptr [r8 + r9*4]
00973c00  890491                   mov dword ptr [rcx + rdx*4], eax
00973c03  418b12                   mov edx, dword ptr [r10]
00973c06  498b4a28                 mov rcx, qword ptr [r10 + 0x28]
00973c0a  ffca                     dec edx
00973c0c  4c8b4728                 mov r8, qword ptr [rdi + 0x28]
00973c10  438b0488                 mov eax, dword ptr [r8 + r9*4]
00973c14  890491                   mov dword ptr [rcx + rdx*4], eax
00973c17  ff0f                     dec dword ptr [rdi]
00973c19  41c644241001             mov byte ptr [r12 + 0x10], 1
00973c1f  488b83200c0000           mov rax, qword ptr [rbx + 0xc20]
00973c26  488b4820                 mov rcx, qword ptr [rax + 0x20]
00973c2a  488b01                   mov rax, qword ptr [rcx]
00973c2d  4989442418               mov qword ptr [r12 + 0x18], rax
00973c32  448b0f                   mov r9d, dword ptr [rdi]
00973c35  4503e9                   add r13d, r9d
00973c38  7528                     jne 0x973c62
00973c3a  448b9424d8000000         mov r10d, dword ptr [rsp + 0xd8]
00973c42  4c8b8c24e8000000         mov r9, qword ptr [rsp + 0xe8]
00973c4a  e97dfbffff               jmp 0x9737cc
00973c4f  c7432002000000           mov dword ptr [rbx + 0x20], 2
00973c56  41393424                 cmp dword ptr [r12], esi
00973c5a  400f95c6                 setne sil
00973c5e  8bc6                     mov eax, esi
00973c60  eb13                     jmp 0x973c75
00973c62  0fb68424d0000000         movzx eax, byte ptr [rsp + 0xd0]
00973c6a  f6d8                     neg al
00973c6c  45892c24                 mov dword ptr [r12], r13d
00973c70  1bc0                     sbb eax, eax
00973c72  83c002                   add eax, 2
00973c75  4c8bb42498000000         mov r14, qword ptr [rsp + 0x98]
00973c7d  4c8bac24a0000000         mov r13, qword ptr [rsp + 0xa0]
00973c85  488bbc24a8000000         mov rdi, qword ptr [rsp + 0xa8]
00973c8d  488bb424b0000000         mov rsi, qword ptr [rsp + 0xb0]
00973c95  488bac24e0000000         mov rbp, qword ptr [rsp + 0xe0]
00973c9d  4c8bbc2490000000         mov r15, qword ptr [rsp + 0x90]
00973ca5  4881c4b8000000           add rsp, 0xb8
00973cac  415c                     pop r12
00973cae  5b                       pop rbx
00973caf  c3                       ret

; chunk at RVA 0x973cb0 (96 bytes)
00973cb0  ac                       lodsb al, byte ptr [rsi]
00973cb1  3997007a3997             cmp dword ptr [rdi - 0x68c68600], edx
00973cb7  00843997009839           add byte ptr [rcx + rdi + 0x39980097], al
00973cbe  97                       xchg edi, eax
00973cbf  008e399700a2             add byte ptr [rsi - 0x5dff68c7], cl
00973cc5  399700023a97             cmp dword ptr [rdi - 0x68c5fe00], edx
00973ccb  00d0                     add al, dl
00973ccd  399700da3997             cmp dword ptr [rdi - 0x68c62600], edx
00973cd3  00ee                     add dh, ch
00973cd5  399700e43997             cmp dword ptr [rdi - 0x68c61c00], edx
00973cdb  00f8                     add al, bh
00973cdd  399700103b97             cmp dword ptr [rdi - 0x68c4f000], edx
00973ce3  00803a970089             add byte ptr [rax - 0x76ff68c6], al
00973ce9  3a97009b3a97             cmp dl, byte ptr [rdi - 0x68c56500]
00973cef  00923a9700a4             add byte ptr [rdx - 0x5bff68c6], dl
00973cf5  3a9700b23b97             cmp dl, byte ptr [rdi - 0x68c44e00]
00973cfb  00763b                   add byte ptr [rsi + 0x3b], dh
00973cfe  97                       xchg edi, eax
00973cff  007f3b                   add byte ptr [rdi + 0x3b], bh
00973d02  97                       xchg edi, eax
00973d03  00913b970088             add byte ptr [rcx - 0x77ff68c5], dl
00973d09  3b97009a3b97             cmp edx, dword ptr [rdi - 0x68c46600]
