; CDecompressBatchLoader<Level2Batch,CLevel2Decompressor,CSimpleRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x9720d0, 1418 bytes in 3 chunk(s)

; chunk at RVA 0x9720d0 (58 bytes)
009720d0  4c894c2420               mov qword ptr [rsp + 0x20], r9
009720d5  89542410                 mov dword ptr [rsp + 0x10], edx
009720d9  55                       push rbp
009720da  53                       push rbx
009720db  4154                     push r12
009720dd  4157                     push r15
009720df  488d6c24c1               lea rbp, [rsp - 0x3f]
009720e4  4881ecd8000000           sub rsp, 0xd8
009720eb  83792002                 cmp dword ptr [rcx + 0x20], 2
009720ef  4d8be0                   mov r12, r8
009720f2  448bfa                   mov r15d, edx
009720f5  488bd9                   mov rbx, rcx
009720f8  7510                     jne 0x97210a
009720fa  33c0                     xor eax, eax
009720fc  4881c4d8000000           add rsp, 0xd8
00972103  415f                     pop r15
00972105  415c                     pop r12
00972107  5b                       pop rbx
00972108  5d                       pop rbp
00972109  c3                       ret

; chunk at RVA 0x97210a (1264 bytes)
0097210a  4889b42410010000         mov qword ptr [rsp + 0x110], rsi
00972112  0f57c0                   xorps xmm0, xmm0
00972115  4889bc24d0000000         mov qword ptr [rsp + 0xd0], rdi
0097211d  0f57c9                   xorps xmm1, xmm1
00972120  33ff                     xor edi, edi
00972122  4c89ac24c8000000         mov qword ptr [rsp + 0xc8], r13
0097212a  32c9                     xor cl, cl
0097212c  4c89b424c0000000         mov qword ptr [rsp + 0xc0], r14
00972134  884d67                   mov byte ptr [rbp + 0x67], cl
00972137  897dc7                   mov dword ptr [rbp - 0x39], edi
0097213a  48897dcf                 mov qword ptr [rbp - 0x31], rdi
0097213e  40887dd7                 mov byte ptr [rbp - 0x29], dil
00972142  660f7f45e7               movdqa xmmword ptr [rbp - 0x19], xmm0
00972147  660f7f4df7               movdqa xmmword ptr [rbp - 9], xmm1
0097214c  660f7f4507               movdqa xmmword ptr [rbp + 7], xmm0
00972151  48897d17                 mov qword ptr [rbp + 0x17], rdi
00972155  c7451f01000000           mov dword ptr [rbp + 0x1f], 1
0097215c  897d87                   mov dword ptr [rbp - 0x79], edi
0097215f  41887c2410               mov byte ptr [r12 + 0x10], dil
00972164  4c8d2d95de68ff           lea r13, [rip - 0x97216b]
0097216b  4038bbb8140000           cmp byte ptr [rbx + 0x14b8], dil
00972172  747e                     je 0x9721f2
00972174  4c8b83b0140000           mov r8, qword ptr [rbx + 0x14b0]
0097217b  33d2                     xor edx, edx
0097217d  498bcc                   mov rcx, r12
00972180  4088bbb8140000           mov byte ptr [rbx + 0x14b8], dil
00972187  e814a8ffff               call 0x96c9a0
0097218c  488b83b0140000           mov rax, qword ptr [rbx + 0x14b0]
00972193  488d75c7                 lea rsi, [rbp - 0x39]
00972197  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
0097219b  897dc7                   mov dword ptr [rbp - 0x39], edi
0097219e  c7458701000000           mov dword ptr [rbp - 0x79], 1
009721a5  ff08                     dec dword ptr [rax]
009721a7  418b1424                 mov edx, dword ptr [r12]
009721ab  498b442408               mov rax, qword ptr [r12 + 8]
009721b0  488945cf                 mov qword ptr [rbp - 0x31], rax
009721b4  498b442420               mov rax, qword ptr [r12 + 0x20]
009721b9  488d0cd0                 lea rcx, [rax + rdx*8]
009721bd  498b442428               mov rax, qword ptr [r12 + 0x28]
009721c2  48894de7                 mov qword ptr [rbp - 0x19], rcx
009721c6  488d0c90                 lea rcx, [rax + rdx*4]
009721ca  498b442430               mov rax, qword ptr [r12 + 0x30]
009721cf  48894def                 mov qword ptr [rbp - 0x11], rcx
009721d3  4088bbb8140000           mov byte ptr [rbx + 0x14b8], dil
009721da  488d0c90                 lea rcx, [rax + rdx*4]
009721de  b801000000               mov eax, 1
009721e3  2bc2                     sub eax, edx
009721e5  48894df7                 mov qword ptr [rbp - 9], rcx
009721e9  4403f8                   add r15d, eax
009721ec  44897d6f                 mov dword ptr [rbp + 0x6f], r15d
009721f0  eb03                     jmp 0x9721f5
009721f2  498bf4                   mov rsi, r12
009721f5  397b20                   cmp dword ptr [rbx + 0x20], edi
009721f8  0f85a7000000             jne 0x9722a5
009721fe  488b4328                 mov rax, qword ptr [rbx + 0x28]
00972202  488d4b28                 lea rcx, [rbx + 0x28]
00972206  4d8bc1                   mov r8, r9
00972209  48897d8f                 mov qword ptr [rbp - 0x71], rdi
0097220d  488d558f                 lea rdx, [rbp - 0x71]
00972211  897d97                   mov dword ptr [rbp - 0x69], edi
00972214  48897d9f                 mov qword ptr [rbp - 0x61], rdi
00972218  897da7                   mov dword ptr [rbp - 0x59], edi
0097221b  48897daf                 mov qword ptr [rbp - 0x51], rdi
0097221f  897db7                   mov dword ptr [rbp - 0x49], edi
00972222  66897dbb                 mov word ptr [rbp - 0x45], di
00972226  c6456701                 mov byte ptr [rbp + 0x67], 1
0097222a  ff10                     call qword ptr [rax]
0097222c  3dc60e0400               cmp eax, 0x40ec6
00972231  0f8473030000             je 0x9725aa
00972237  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
0097223b  8b4597                   mov eax, dword ptr [rbp - 0x69]
0097223e  48894b50                 mov qword ptr [rbx + 0x50], rcx
00972242  48894b58                 mov qword ptr [rbx + 0x58], rcx
00972246  488b4d9f                 mov rcx, qword ptr [rbp - 0x61]
0097224a  894348                   mov dword ptr [rbx + 0x48], eax
0097224d  8b45a7                   mov eax, dword ptr [rbp - 0x59]
00972250  48898b20030000           mov qword ptr [rbx + 0x320], rcx
00972257  48898b28030000           mov qword ptr [rbx + 0x328], rcx
0097225e  48897b40                 mov qword ptr [rbx + 0x40], rdi
00972262  6689bb08030000           mov word ptr [rbx + 0x308], di
00972269  4889bb00030000           mov qword ptr [rbx + 0x300], rdi
00972270  898318030000             mov dword ptr [rbx + 0x318], eax
00972276  4889bb10030000           mov qword ptr [rbx + 0x310], rdi
0097227d  4889bb9c140000           mov qword ptr [rbx + 0x149c], rdi
00972284  c783a414000000000101     mov dword ptr [rbx + 0x14a4], 0x1010000
0097228e  c7839814000001000000     mov dword ptr [rbx + 0x1498], 1
00972298  89bb90130000             mov dword ptr [rbx + 0x1390], edi
0097229e  c7432001000000           mov dword ptr [rbx + 0x20], 1
009722a5  488b4330                 mov rax, qword ptr [rbx + 0x30]
009722a9  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
009722b0  4c894608                 mov qword ptr [rsi + 8], r8
009722b4  488b5330                 mov rdx, qword ptr [rbx + 0x30]
009722b8  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
009722bf  8b423c                   mov eax, dword ptr [rdx + 0x3c]
009722c2  83e007                   and eax, 7
009722c5  83f805                   cmp eax, 5
009722c8  7741                     ja 0x97230b
009722ca  4898                     cdqe
009722cc  418b8c85fc259700         mov ecx, dword ptr [r13 + rax*4 + 0x9725fc]
009722d4  4903cd                   add rcx, r13
009722d7  ffe1                     jmp rcx
009722d9  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009722dd  410f95c6                 setne r14b
009722e1  eb2b                     jmp 0x97230e
009722e3  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009722e7  410f9dc6                 setge r14b
009722eb  eb21                     jmp 0x97230e
009722ed  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009722f1  410f9ec6                 setle r14b
009722f5  eb17                     jmp 0x97230e
009722f7  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009722fb  410f9fc6                 setg r14b
009722ff  eb0d                     jmp 0x97230e
00972301  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972305  410f9cc6                 setl r14b
00972309  eb03                     jmp 0x97230e
0097230b  4532f6                   xor r14b, r14b
0097230e  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00972311  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00972318  83e007                   and eax, 7
0097231b  83f805                   cmp eax, 5
0097231e  7741                     ja 0x972361
00972320  4898                     cdqe
00972322  418b8c8514269700         mov ecx, dword ptr [r13 + rax*4 + 0x972614]
0097232a  4903cd                   add rcx, r13
0097232d  ffe1                     jmp rcx
0097232f  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972333  410f95c5                 setne r13b
00972337  eb2b                     jmp 0x972364
00972339  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097233d  410f9dc5                 setge r13b
00972341  eb21                     jmp 0x972364
00972343  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972347  410f9ec5                 setle r13b
0097234b  eb17                     jmp 0x972364
0097234d  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972351  410f9fc5                 setg r13b
00972355  eb0d                     jmp 0x972364
00972357  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097235b  410f9cc5                 setl r13b
0097235f  eb03                     jmp 0x972364
00972361  4532ed                   xor r13b, r13b
00972364  488d4b38                 lea rcx, [rbx + 0x38]
00972368  4c8bc6                   mov r8, rsi
0097236b  418bd7                   mov edx, r15d
0097236e  e88db7ffff               call 0x96db00
00972373  84c0                     test al, al
00972375  7503                     jne 0x97237a
00972377  897b20                   mov dword ptr [rbx + 0x20], edi
0097237a  8b16                     mov edx, dword ptr [rsi]
0097237c  448bc2                   mov r8d, edx
0097237f  85d2                     test edx, edx
00972381  0f84c2010000             je 0x972549
00972387  4584f6                   test r14b, r14b
0097238a  7509                     jne 0x972395
0097238c  4584ed                   test r13b, r13b
0097238f  0f84b4010000             je 0x972549
00972395  448bca                   mov r9d, edx
00972398  4584f6                   test r14b, r14b
0097239b  0f847e000000             je 0x97241f
009723a1  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
009723a5  448bd7                   mov r10d, edi
009723a8  85d2                     test edx, edx
009723aa  746c                     je 0x972418
009723ac  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
009723b0  4c8d3d49dc68ff           lea r15, [rip - 0x9723b7]
009723b7  4c8b7620                 mov r14, qword ptr [rsi + 0x20]
009723bb  4183e007                 and r8d, 7
009723bf  90                       nop
009723c0  418bc2                   mov eax, r10d
009723c3  4d8b0cc6                 mov r9, qword ptr [r14 + rax*8]
009723c7  4183f805                 cmp r8d, 5
009723cb  0f87ad000000             ja 0x97247e
009723d1  4963c0                   movsxd rax, r8d
009723d4  418b8c872c269700         mov ecx, dword ptr [r15 + rax*4 + 0x97262c]
009723dc  4903cf                   add rcx, r15
009723df  ffe1                     jmp rcx
009723e1  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009723e5  0f94c0                   sete al
009723e8  eb22                     jmp 0x97240c
009723ea  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009723ee  0f9cc0                   setl al
009723f1  eb19                     jmp 0x97240c
009723f3  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009723f7  0f9fc0                   setg al
009723fa  eb10                     jmp 0x97240c
009723fc  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972400  0f9ec0                   setle al
00972403  eb07                     jmp 0x97240c
00972405  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972409  0f9dc0                   setge al
0097240c  84c0                     test al, al
0097240e  756e                     jne 0x97247e
00972410  41ffc2                   inc r10d
00972413  443bd2                   cmp r10d, edx
00972416  72a8                     jb 0x9723c0
00972418  893e                     mov dword ptr [rsi], edi
0097241a  8bd7                     mov edx, edi
0097241c  448bcf                   mov r9d, edi
0097241f  458bc1                   mov r8d, r9d
00972422  4584ed                   test r13b, r13b
00972425  0f841e010000             je 0x972549
0097242b  85d2                     test edx, edx
0097242d  0f8416010000             je 0x972549
00972433  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00972437  4c8d2dc2db68ff           lea r13, [rip - 0x97243e]
0097243e  4c8b7e20                 mov r15, qword ptr [rsi + 0x20]
00972442  0f1f4000                 nop dword ptr [rax]
00972446  66660f1f840000000000     nop word ptr [rax + rax]
00972450  418b434c                 mov eax, dword ptr [r11 + 0x4c]
00972454  ffca                     dec edx
00972456  458bd1                   mov r10d, r9d
00972459  83e007                   and eax, 7
0097245c  448bca                   mov r9d, edx
0097245f  458bc2                   mov r8d, r10d
00972462  4d8b34d7                 mov r14, qword ptr [r15 + rdx*8]
00972466  83f805                   cmp eax, 5
00972469  0f87da000000             ja 0x972549
0097246f  4898                     cdqe
00972471  418b8c8544269700         mov ecx, dword ptr [r13 + rax*4 + 0x972644]
00972479  4903cd                   add rcx, r13
0097247c  ffe1                     jmp rcx
0097247e  443bd2                   cmp r10d, edx
00972481  7395                     jae 0x972418
00972483  448bca                   mov r9d, edx
00972486  4585d2                   test r10d, r10d
00972489  7494                     je 0x97241f
0097248b  8bd7                     mov edx, edi
0097248d  452bca                   sub r9d, r10d
00972490  7470                     je 0x972502
00972492  4c8bc7                   mov r8, rdi
00972495  4c8bdf                   mov r11, rdi
00972498  4c8bf7                   mov r14, rdi
0097249b  0f1f440000               nop dword ptr [rax + rax]
009724a0  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
009724a4  428d0412                 lea eax, [rdx + r10]
009724a8  448bf8                   mov r15d, eax
009724ab  488b04c1                 mov rax, qword ptr [rcx + rax*8]
009724af  4989040e                 mov qword ptr [r14 + rcx], rax
009724b3  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
009724b7  428b04b9                 mov eax, dword ptr [rcx + r15*4]
009724bb  4189040b                 mov dword ptr [r11 + rcx], eax
009724bf  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
009724c3  428b04b9                 mov eax, dword ptr [rcx + r15*4]
009724c7  4d03ff                   add r15, r15
009724ca  4189040b                 mov dword ptr [r11 + rcx], eax
009724ce  488b4638                 mov rax, qword ptr [rsi + 0x38]
009724d2  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
009724d7  420f110400               movups xmmword ptr [rax + r8], xmm0
009724dc  488b4648                 mov rax, qword ptr [rsi + 0x48]
009724e0  4885c0                   test rax, rax
009724e3  740a                     je 0x9724ef
009724e5  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
009724ea  420f110400               movups xmmword ptr [rax + r8], xmm0
009724ef  ffc2                     inc edx
009724f1  4983c608                 add r14, 8
009724f5  4983c304                 add r11, 4
009724f9  4983c010                 add r8, 0x10
009724fd  413bd1                   cmp edx, r9d
00972500  729e                     jb 0x9724a0
00972502  44890e                   mov dword ptr [rsi], r9d
00972505  418bd1                   mov edx, r9d
00972508  e912ffffff               jmp 0x97241f
0097250d  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972511  0f94c0                   sete al
00972514  eb22                     jmp 0x972538
00972516  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
0097251a  0f9cc0                   setl al
0097251d  eb19                     jmp 0x972538
0097251f  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972523  0f9fc0                   setg al
00972526  eb10                     jmp 0x972538
00972528  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
0097252c  0f9ec0                   setle al
0097252f  eb07                     jmp 0x972538
00972531  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972535  0f9dc0                   setge al
00972538  84c0                     test al, al
0097253a  750d                     jne 0x972549
0097253c  8916                     mov dword ptr [rsi], edx
0097253e  448bc2                   mov r8d, edx
00972541  85d2                     test edx, edx
00972543  0f8507ffffff             jne 0x972450
00972549  4038bbb9140000           cmp byte ptr [rbx + 0x14b9], dil
00972550  7440                     je 0x972592
00972552  448b06                   mov r8d, dword ptr [rsi]
00972555  4585c0                   test r8d, r8d
00972558  7438                     je 0x972592
0097255a  488b8bb0140000           mov rcx, qword ptr [rbx + 0x14b0]
00972561  4c8bc6                   mov r8, rsi
00972564  c683b814000001           mov byte ptr [rbx + 0x14b8], 1
0097256b  8b16                     mov edx, dword ptr [rsi]
0097256d  ffca                     dec edx
0097256f  e82ca4ffff               call 0x96c9a0
00972574  ff0e                     dec dword ptr [rsi]
00972576  41c644241001             mov byte ptr [r12 + 0x10], 1
0097257c  488b83b0140000           mov rax, qword ptr [rbx + 0x14b0]
00972583  488b4820                 mov rcx, qword ptr [rax + 0x20]
00972587  488b01                   mov rax, qword ptr [rcx]
0097258a  4989442418               mov qword ptr [r12 + 0x18], rax
0097258f  448b06                   mov r8d, dword ptr [rsi]
00972592  8b4587                   mov eax, dword ptr [rbp - 0x79]
00972595  4103c0                   add eax, r8d
00972598  894587                   mov dword ptr [rbp - 0x79], eax
0097259b  7520                     jne 0x9725bd
0097259d  448b7d6f                 mov r15d, dword ptr [rbp + 0x6f]
009725a1  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009725a5  e9b5fbffff               jmp 0x97215f
009725aa  c7432002000000           mov dword ptr [rbx + 0x20], 2
009725b1  41393c24                 cmp dword ptr [r12], edi
009725b5  400f95c7                 setne dil
009725b9  8bc7                     mov eax, edi
009725bb  eb0f                     jmp 0x9725cc
009725bd  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
009725c1  f6d9                     neg cl
009725c3  41890424                 mov dword ptr [r12], eax
009725c7  1bc0                     sbb eax, eax
009725c9  83c002                   add eax, 2
009725cc  4c8bac24c8000000         mov r13, qword ptr [rsp + 0xc8]
009725d4  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
009725dc  488bb42410010000         mov rsi, qword ptr [rsp + 0x110]
009725e4  4c8bb424c0000000         mov r14, qword ptr [rsp + 0xc0]
009725ec  4881c4d8000000           add rsp, 0xd8
009725f3  415f                     pop r15
009725f5  415c                     pop r12
009725f7  5b                       pop rbx
009725f8  5d                       pop rbp
009725f9  c3                       ret

; chunk at RVA 0x9725fc (96 bytes)
009725fc  0b23                     or esp, dword ptr [rbx]
009725fe  97                       xchg edi, eax
009725ff  00d9                     add cl, bl
00972601  229700e32297             and dl, byte ptr [rdi - 0x68dd1d00]
00972607  00f7                     add bh, dh
00972609  229700ed2297             and dl, byte ptr [rdi - 0x68dd1300]
0097260f  0001                     add byte ptr [rcx], al
00972611  239700612397             and edx, dword ptr [rdi - 0x68dc9f00]
00972617  002f                     add byte ptr [rdi], ch
00972619  239700392397             and edx, dword ptr [rdi - 0x68dcc700]
0097261f  004d23                   add byte ptr [rbp + 0x23], cl
00972622  97                       xchg edi, eax
00972623  004323                   add byte ptr [rbx + 0x23], al
00972626  97                       xchg edi, eax
00972627  005723                   add byte ptr [rdi + 0x23], dl
0097262a  97                       xchg edi, eax
0097262b  007e24                   add byte ptr [rsi + 0x24], bh
0097262e  97                       xchg edi, eax
0097262f  00e1                     add cl, ah
00972631  239700ea2397             and edx, dword ptr [rdi - 0x68dc1600]
00972637  00fc                     add ah, bh
00972639  239700f32397             and edx, dword ptr [rdi - 0x68dc0d00]
0097263f  000524970049             add byte ptr [rip + 0x49009724], al
00972645  2597000d25               and eax, 0x250d0097
0097264a  97                       xchg edi, eax
0097264b  0016                     add byte ptr [rsi], dl
0097264d  2597002825               and eax, 0x25280097
00972652  97                       xchg edi, eax
00972653  001f                     add byte ptr [rdi], bl
00972655  2597003125               and eax, 0x25310097
0097265a  97                       xchg edi, eax
