; CBcpImport::ScanColumnsInfo
; sqllang.dll, primary RVA 0x1970dc0, 4228 bytes in 1 chunk(s)

; chunk at RVA 0x1970dc0 (4228 bytes)
01970dc0  4055                     push rbp
01970dc2  53                       push rbx
01970dc3  56                       push rsi
01970dc4  57                       push rdi
01970dc5  4154                     push r12
01970dc7  4155                     push r13
01970dc9  4156                     push r14
01970dcb  4157                     push r15
01970dcd  4881ec78020000           sub rsp, 0x278
01970dd4  488d6c2450               lea rbp, [rsp + 0x50]
01970dd9  48c785e8000000feffffff   mov qword ptr [rbp + 0xe8], 0xfffffffffffffffe
01970de4  488b059d7e1601           mov rax, qword ptr [rip + 0x1167e9d]
01970deb  4833c5                   xor rax, rbp
01970dee  48898510020000           mov qword ptr [rbp + 0x210], rax
01970df5  4d8be9                   mov r13, r9
01970df8  498bd8                   mov rbx, r8
01970dfb  4c8bf2                   mov r14, rdx
01970dfe  48895560                 mov qword ptr [rbp + 0x60], rdx
01970e02  488bf1                   mov rsi, rcx
01970e05  48898dc0000000           mov qword ptr [rbp + 0xc0], rcx
01970e0c  0fb74978                 movzx ecx, word ptr [rcx + 0x78]
01970e10  ff15f2ad5500             call qword ptr [rip + 0x55adf2]
01970e16  488985b8000000           mov qword ptr [rbp + 0xb8], rax
01970e1d  33ff                     xor edi, edi
01970e1f  48897d58                 mov qword ptr [rbp + 0x58], rdi
01970e23  488b4e70                 mov rcx, qword ptr [rsi + 0x70]
01970e27  4c8b01                   mov r8, qword ptr [rcx]
01970e2a  488d95f0000000           lea rdx, [rbp + 0xf0]
01970e31  41ff5060                 call qword ptr [r8 + 0x60]
01970e35  81bdf800000055200000     cmp dword ptr [rbp + 0xf8], 0x2055
01970e3f  7516                     jne 0x1970e57
01970e41  4c8b0b                   mov r9, qword ptr [rbx]
01970e44  4533c0                   xor r8d, r8d
01970e47  33d2                     xor edx, edx
01970e49  488bcb                   mov rcx, rbx
01970e4c  41ff9168010000           call qword ptr [r9 + 0x168]
01970e53  48894558                 mov qword ptr [rbp + 0x58], rax
01970e57  48897d20                 mov qword ptr [rbp + 0x20], rdi
01970e5b  48895d10                 mov qword ptr [rbp + 0x10], rbx
01970e5f  48897d18                 mov qword ptr [rbp + 0x18], rdi
01970e63  488b13                   mov rdx, qword ptr [rbx]
01970e66  488bcb                   mov rcx, rbx
01970e69  ff92a8000000             call qword ptr [rdx + 0xa8]
01970e6f  41bfffffffff             mov r15d, 0xffffffff
01970e75  413bc7                   cmp eax, r15d
01970e78  743c                     je 0x1970eb6
01970e7a  488b03                   mov rax, qword ptr [rbx]
01970e7d  488bcb                   mov rcx, rbx
01970e80  ff90c0000000             call qword ptr [rax + 0xc0]
01970e86  48894520                 mov qword ptr [rbp + 0x20], rax
01970e8a  4885c0                   test rax, rax
01970e8d  7427                     je 0x1970eb6
01970e8f  4c8b00                   mov r8, qword ptr [rax]
01970e92  418bd7                   mov edx, r15d
01970e95  488bc8                   mov rcx, rax
01970e98  41ff5008                 call qword ptr [r8 + 8]
01970e9c  488b4d20                 mov rcx, qword ptr [rbp + 0x20]
01970ea0  488b01                   mov rax, qword ptr [rcx]
01970ea3  488d5528                 lea rdx, [rbp + 0x28]
01970ea7  ff5010                   call qword ptr [rax + 0x10]
01970eaa  8b4d28                   mov ecx, dword ptr [rbp + 0x28]
01970ead  84c0                     test al, al
01970eaf  410f44cf                 cmove ecx, r15d
01970eb3  894d28                   mov dword ptr [rbp + 0x28], ecx
01970eb6  488b03                   mov rax, qword ptr [rbx]
01970eb9  488bcb                   mov rcx, rbx
01970ebc  ff90a8000000             call qword ptr [rax + 0xa8]
01970ec2  8985b0000000             mov dword ptr [rbp + 0xb0], eax
01970ec8  413bc7                   cmp eax, r15d
01970ecb  7423                     je 0x1970ef0
01970ecd  488b4d20                 mov rcx, qword ptr [rbp + 0x20]
01970ed1  4885c9                   test rcx, rcx
01970ed4  7513                     jne 0x1970ee9
01970ed6  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01970eda  4c8b01                   mov r8, qword ptr [rcx]
01970edd  8b5518                   mov edx, dword ptr [rbp + 0x18]
01970ee0  41ff90d0000000           call qword ptr [r8 + 0xd0]
01970ee7  eb15                     jmp 0x1970efe
01970ee9  488b01                   mov rax, qword ptr [rcx]
01970eec  ff10                     call qword ptr [rax]
01970eee  eb0e                     jmp 0x1970efe
01970ef0  488b03                   mov rax, qword ptr [rbx]
01970ef3  33d2                     xor edx, edx
01970ef5  488bcb                   mov rcx, rbx
01970ef8  ff90d0000000             call qword ptr [rax + 0xd0]
01970efe  894628                   mov dword ptr [rsi + 0x28], eax
01970f01  40887d00                 mov byte ptr [rbp], dil
01970f05  418b4510                 mov eax, dword ptr [r13 + 0x10]
01970f09  41bc01000000             mov r12d, 1
01970f0f  480fbae016               bt rax, 0x16
01970f14  7309                     jae 0x1970f1f
01970f16  44886500                 mov byte ptr [rbp], r12b
01970f1a  e995000000               jmp 0x1970fb4
01970f1f  448bf7                   mov r14d, edi
01970f22  488b03                   mov rax, qword ptr [rbx]
01970f25  33d2                     xor edx, edx
01970f27  488bcb                   mov rcx, rbx
01970f2a  ff90d0000000             call qword ptr [rax + 0xd0]
01970f30  448bf8                   mov r15d, eax
01970f33  418bfc                   mov edi, r12d
01970f36  413bc4                   cmp eax, r12d
01970f39  726f                     jb 0x1970faa
01970f3b  0faee8                   lfence
01970f3e  6690                     nop
01970f40  0f57c0                   xorps xmm0, xmm0
01970f43  33c0                     xor eax, eax
01970f45  0f1185b0010000           movups xmmword ptr [rbp + 0x1b0], xmm0
01970f4c  0f1185c0010000           movups xmmword ptr [rbp + 0x1c0], xmm0
01970f53  0f1185d0010000           movups xmmword ptr [rbp + 0x1d0], xmm0
01970f5a  0f1185e0010000           movups xmmword ptr [rbp + 0x1e0], xmm0
01970f61  0f1185f0010000           movups xmmword ptr [rbp + 0x1f0], xmm0
01970f68  48898500020000           mov qword ptr [rbp + 0x200], rax
01970f6f  488b03                   mov rax, qword ptr [rbx]
01970f72  4533c0                   xor r8d, r8d
01970f75  8bd7                     mov edx, edi
01970f77  488bcb                   mov rcx, rbx
01970f7a  ff90e0000000             call qword ptr [rax + 0xe0]
01970f80  4c8b00                   mov r8, qword ptr [rax]
01970f83  488d95b0010000           lea rdx, [rbp + 0x1b0]
01970f8a  488bc8                   mov rcx, rax
01970f8d  41ff5018                 call qword ptr [r8 + 0x18]
01970f91  f6850402000020           test byte ptr [rbp + 0x204], 0x20
01970f98  418d4601                 lea eax, [r14 + 1]
01970f9c  410f44c6                 cmove eax, r14d
01970fa0  448bf0                   mov r14d, eax
01970fa3  ffc7                     inc edi
01970fa5  413bff                   cmp edi, r15d
01970fa8  7696                     jbe 0x1970f40
01970faa  44297628                 sub dword ptr [rsi + 0x28], r14d
01970fae  4c8b7560                 mov r14, qword ptr [rbp + 0x60]
01970fb2  33ff                     xor edi, edi
01970fb4  8b4628                   mov eax, dword ptr [rsi + 0x28]
01970fb7  8bc8                     mov ecx, eax
01970fb9  b880010000               mov eax, 0x180
01970fbe  48f7e1                   mul rcx
01970fc1  49c7c7ffffffff           mov r15, 0xffffffffffffffff
01970fc8  490f40c7                 cmovo rax, r15
01970fcc  c644242005               mov byte ptr [rsp + 0x20], 5
01970fd1  41b9a3030000             mov r9d, 0x3a3
01970fd7  4c8d059a34b500           lea r8, [rip + 0xb5349a]
01970fde  488b5650                 mov rdx, qword ptr [rsi + 0x50]
01970fe2  488bc8                   mov rcx, rax
01970fe5  ff150d9f5500             call qword ptr [rip + 0x559f0d]
01970feb  48894620                 mov qword ptr [rsi + 0x20], rax
01970fef  8b4e28                   mov ecx, dword ptr [rsi + 0x28]
01970ff2  4c8d0449                 lea r8, [rcx + rcx*2]
01970ff6  49c1e007                 shl r8, 7
01970ffa  33d2                     xor edx, edx
01970ffc  488bc8                   mov rcx, rax
01970fff  e8380469fe               call 0x143c
01971004  8b5e28                   mov ebx, dword ptr [rsi + 0x28]
01971007  c74508a6030000           mov dword ptr [rbp + 8], 0x3a6
0197100e  b820000000               mov eax, 0x20
01971013  48f7e3                   mul rbx
01971016  490f40c7                 cmovo rax, r15
0197101a  c644242005               mov byte ptr [rsp + 0x20], 5
0197101f  41b9a6030000             mov r9d, 0x3a6
01971025  4c8d054c34b500           lea r8, [rip + 0xb5344c]
0197102c  488b5650                 mov rdx, qword ptr [rsi + 0x50]
01971030  488bc8                   mov rcx, rax
01971033  ff15bf9e5500             call qword ptr [rip + 0x559ebf]
01971039  488bc8                   mov rcx, rax
0197103c  48894568                 mov qword ptr [rbp + 0x68], rax
01971040  4885c0                   test rax, rax
01971043  743f                     je 0x1971084
01971045  4885db                   test rbx, rbx
01971048  743d                     je 0x1971087
0197104a  4883c008                 add rax, 8
0197104e  6690                     nop
01971050  668978f9                 mov word ptr [rax - 7], di
01971054  c640fb00                 mov byte ptr [rax - 5], 0
01971058  48c7400c00000000         mov qword ptr [rax + 0xc], 0
01971060  c640f800                 mov byte ptr [rax - 8], 0
01971064  8978fc                   mov dword ptr [rax - 4], edi
01971067  4c8938                   mov qword ptr [rax], r15
0197106a  c7400800000000           mov dword ptr [rax + 8], 0
01971071  c7401400000000           mov dword ptr [rax + 0x14], 0
01971078  488d4020                 lea rax, [rax + 0x20]
0197107c  4883eb01                 sub rbx, 1
01971080  75ce                     jne 0x1971050
01971082  eb03                     jmp 0x1971087
01971084  488bcf                   mov rcx, rdi
01971087  48894e48                 mov qword ptr [rsi + 0x48], rcx
0197108b  448b4628                 mov r8d, dword ptr [rsi + 0x28]
0197108f  49c1e005                 shl r8, 5
01971093  33d2                     xor edx, edx
01971095  e8a20369fe               call 0x143c
0197109a  8b5e28                   mov ebx, dword ptr [rsi + 0x28]
0197109d  c1e302                   shl ebx, 2
019710a0  e84b8d69fe               call 0x9df0
019710a5  488d8b00000100           lea rcx, [rbx + 0x10000]
019710ac  483bc1                   cmp rax, rcx
019710af  7322                     jae 0x19710d3
019710b1  48897c2420               mov qword ptr [rsp + 0x20], rdi
019710b6  41b9ab030000             mov r9d, 0x3ab
019710bc  4c8d05ad2bba00           lea r8, [rip + 0xba2bad]
019710c3  488d158609bb00           lea rdx, [rip + 0xbb0986]
019710ca  418bcc                   mov ecx, r12d
019710cd  ff15a59d5500             call qword ptr [rip + 0x559da5]
019710d3  488d430f                 lea rax, [rbx + 0xf]
019710d7  48b9f0ffffffffffff0f     movabs rcx, 0xffffffffffffff0
019710e1  483bc3                   cmp rax, rbx
019710e4  7703                     ja 0x19710e9
019710e6  488bc1                   mov rax, rcx
019710e9  4883e0f0                 and rax, 0xfffffffffffffff0
019710ed  e89eff68fe               call 0x1090
019710f2  482be0                   sub rsp, rax
019710f5  488d442450               lea rax, [rsp + 0x50]
019710fa  48894568                 mov qword ptr [rbp + 0x68], rax
019710fe  498b8588000000           mov rax, qword ptr [r13 + 0x88]
01971105  488985c0000000           mov qword ptr [rbp + 0xc0], rax
0197110c  448be7                   mov r12d, edi
0197110f  897d50                   mov dword ptr [rbp + 0x50], edi
01971112  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01971116  488b01                   mov rax, qword ptr [rcx]
01971119  48837d2000               cmp qword ptr [rbp + 0x20], 0
0197111e  7525                     jne 0x1971145
01971120  8b5518                   mov edx, dword ptr [rbp + 0x18]
01971123  ff90d0000000             call qword ptr [rax + 0xd0]
01971129  8b551c                   mov edx, dword ptr [rbp + 0x1c]
0197112c  3bd0                     cmp edx, eax
0197112e  7320                     jae 0x1971150
01971130  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01971134  488b01                   mov rax, qword ptr [rcx]
01971137  ffc2                     inc edx
01971139  448b4518                 mov r8d, dword ptr [rbp + 0x18]
0197113d  ff90e0000000             call qword ptr [rax + 0xe0]
01971143  eb0b                     jmp 0x1971150
01971145  448b4518                 mov r8d, dword ptr [rbp + 0x18]
01971149  8b5528                   mov edx, dword ptr [rbp + 0x28]
0197114c  ff5028                   call qword ptr [rax + 0x28]
0197114f  90                       nop
01971150  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01971154  488b01                   mov rax, qword ptr [rcx]
01971157  48837d2000               cmp qword ptr [rbp + 0x20], 0
0197115c  752a                     jne 0x1971188
0197115e  8b5518                   mov edx, dword ptr [rbp + 0x18]
01971161  ff90d0000000             call qword ptr [rax + 0xd0]
01971167  8b551c                   mov edx, dword ptr [rbp + 0x1c]
0197116a  3bd0                     cmp edx, eax
0197116c  7205                     jb 0x1971173
0197116e  4c8bff                   mov r15, rdi
01971171  eb22                     jmp 0x1971195
01971173  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01971177  488b01                   mov rax, qword ptr [rcx]
0197117a  ffc2                     inc edx
0197117c  448b4518                 mov r8d, dword ptr [rbp + 0x18]
01971180  ff90e0000000             call qword ptr [rax + 0xe0]
01971186  eb0a                     jmp 0x1971192
01971188  448b4518                 mov r8d, dword ptr [rbp + 0x18]
0197118c  8b5528                   mov edx, dword ptr [rbp + 0x28]
0197118f  ff5028                   call qword ptr [rax + 0x28]
01971192  4c8bf8                   mov r15, rax
01971195  4d85ff                   test r15, r15
01971198  0f8455090000             je 0x1971af3
0197119e  0f57c0                   xorps xmm0, xmm0
019711a1  33c0                     xor eax, eax
019711a3  0f118500010000           movups xmmword ptr [rbp + 0x100], xmm0
019711aa  0f118510010000           movups xmmword ptr [rbp + 0x110], xmm0
019711b1  0f118520010000           movups xmmword ptr [rbp + 0x120], xmm0
019711b8  0f118530010000           movups xmmword ptr [rbp + 0x130], xmm0
019711bf  0f118540010000           movups xmmword ptr [rbp + 0x140], xmm0
019711c6  48898550010000           mov qword ptr [rbp + 0x150], rax
019711cd  498b07                   mov rax, qword ptr [r15]
019711d0  498bcf                   mov rcx, r15
019711d3  ff5008                   call qword ptr [rax + 8]
019711d6  8bf8                     mov edi, eax
019711d8  894504                   mov dword ptr [rbp + 4], eax
019711db  4d8b07                   mov r8, qword ptr [r15]
019711de  488d9500010000           lea rdx, [rbp + 0x100]
019711e5  498bcf                   mov rcx, r15
019711e8  41ff5018                 call qword ptr [r8 + 0x18]
019711ec  807d0000                 cmp byte ptr [rbp], 0
019711f0  7517                     jne 0x1971209
019711f2  f6855401000020           test byte ptr [rbp + 0x154], 0x20
019711f9  740e                     je 0x1971209
019711fb  41bfffffffff             mov r15d, 0xffffffff
01971201  4503e7                   add r12d, r15d
01971204  e98b080000               jmp 0x1971a94
01971209  418bc4                   mov eax, r12d
0197120c  488d1c40                 lea rbx, [rax + rax*2]
01971210  48c1e307                 shl rbx, 7
01971214  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971218  b9ffffffff               mov ecx, 0xffffffff
0197121d  48894c1860               mov qword ptr [rax + rbx + 0x60], rcx
01971222  33c0                     xor eax, eax
01971224  66894531                 mov word ptr [rbp + 0x31], ax
01971228  884533                   mov byte ptr [rbp + 0x33], al
0197122b  48894544                 mov qword ptr [rbp + 0x44], rax
0197122f  884530                   mov byte ptr [rbp + 0x30], al
01971232  894534                   mov dword ptr [rbp + 0x34], eax
01971235  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
0197123c  48894d38                 mov qword ptr [rbp + 0x38], rcx
01971240  894540                   mov dword ptr [rbp + 0x40], eax
01971243  89454c                   mov dword ptr [rbp + 0x4c], eax
01971246  41388516010000           cmp byte ptr [r13 + 0x116], al
0197124d  7518                     jne 0x1971267
0197124f  41388508010000           cmp byte ptr [r13 + 0x108], al
01971256  0f847e010000             je 0x19713da
0197125c  41837d6801               cmp dword ptr [r13 + 0x68], 1
01971261  0f8573010000             jne 0x19713da
01971267  4d8bc7                   mov r8, r15
0197126a  498bd6                   mov rdx, r14
0197126d  483985c0000000           cmp qword ptr [rbp + 0xc0], rax
01971274  0f8592000000             jne 0x197130c
0197127a  66894571                 mov word ptr [rbp + 0x71], ax
0197127e  884573                   mov byte ptr [rbp + 0x73], al
01971281  48898584000000           mov qword ptr [rbp + 0x84], rax
01971288  884570                   mov byte ptr [rbp + 0x70], al
0197128b  894574                   mov dword ptr [rbp + 0x74], eax
0197128e  48894d78                 mov qword ptr [rbp + 0x78], rcx
01971292  898580000000             mov dword ptr [rbp + 0x80], eax
01971298  89858c000000             mov dword ptr [rbp + 0x8c], eax
0197129e  4c8d4d70                 lea r9, [rbp + 0x70]
019712a2  e8e9443dff               call 0xd45790
019712a7  488bf8                   mov rdi, rax
019712aa  41837d6801               cmp dword ptr [r13 + 0x68], 1
019712af  7404                     je 0x19712b5
019712b1  806571fe                 and byte ptr [rbp + 0x71], 0xfe
019712b5  418b9548010000           mov edx, dword ptr [r13 + 0x148]
019712bc  ffc2                     inc edx
019712be  41899548010000           mov dword ptr [r13 + 0x148], edx
019712c5  418d4c2401               lea ecx, [r12 + 1]
019712ca  488d4570                 lea rax, [rbp + 0x70]
019712ce  4889442440               mov qword ptr [rsp + 0x40], rax
019712d3  4c89742438               mov qword ptr [rsp + 0x38], r14
019712d8  4533c0                   xor r8d, r8d
019712db  4489442430               mov dword ptr [rsp + 0x30], r8d
019712e0  4c89442428               mov qword ptr [rsp + 0x28], r8
019712e5  8b4720                   mov eax, dword ptr [rdi + 0x20]
019712e8  89442420                 mov dword ptr [rsp + 0x20], eax
019712ec  4c8b4f18                 mov r9, qword ptr [rdi + 0x18]
019712f0  e8bbe73bff               call 0xd2fab0
019712f5  48897820                 mov qword ptr [rax + 0x20], rdi
019712f9  4533c0                   xor r8d, r8d
019712fc  488bd0                   mov rdx, rax
019712ff  498bcd                   mov rcx, r13
01971302  e809a539ff               call 0xd0b810
01971307  e9cb000000               jmp 0x19713d7
0197130c  66898591000000           mov word ptr [rbp + 0x91], ax
01971313  888593000000             mov byte ptr [rbp + 0x93], al
01971319  488985a4000000           mov qword ptr [rbp + 0xa4], rax
01971320  888590000000             mov byte ptr [rbp + 0x90], al
01971326  898594000000             mov dword ptr [rbp + 0x94], eax
0197132c  48898d98000000           mov qword ptr [rbp + 0x98], rcx
01971333  8985a0000000             mov dword ptr [rbp + 0xa0], eax
01971339  8985ac000000             mov dword ptr [rbp + 0xac], eax
0197133f  4c8d8d90000000           lea r9, [rbp + 0x90]
01971346  e845443dff               call 0xd45790
0197134b  4c8be0                   mov r12, rax
0197134e  4d8bb588000000           mov r14, qword ptr [r13 + 0x88]
01971355  4d85f6                   test r14, r14
01971358  0f847c000000             je 0x19713da
0197135e  90                       nop
0197135f  90                       nop
01971360  498b17                   mov rdx, qword ptr [r15]
01971363  498bcf                   mov rcx, r15
01971366  ff5210                   call qword ptr [rdx + 0x10]
01971369  8b7808                   mov edi, dword ptr [rax + 8]
0197136c  498b17                   mov rdx, qword ptr [r15]
0197136f  498bcf                   mov rcx, r15
01971372  ff5210                   call qword ptr [rdx + 0x10]
01971375  897c2420                 mov dword ptr [rsp + 0x20], edi
01971379  4c8b08                   mov r9, qword ptr [rax]
0197137c  458b4608                 mov r8d, dword ptr [r14 + 8]
01971380  498b16                   mov rdx, qword ptr [r14]
01971383  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
0197138a  ff1590a95500             call qword ptr [rip + 0x55a990]
01971390  84c0                     test al, al
01971392  750b                     jne 0x197139f
01971394  4d8b7658                 mov r14, qword ptr [r14 + 0x58]
01971398  4d85f6                   test r14, r14
0197139b  75c3                     jne 0x1971360
0197139d  eb38                     jmp 0x19713d7
0197139f  4d896620                 mov qword ptr [r14 + 0x20], r12
019713a3  8b4550                   mov eax, dword ptr [rbp + 0x50]
019713a6  ffc0                     inc eax
019713a8  4189462c                 mov dword ptr [r14 + 0x2c], eax
019713ac  0f108590000000           movups xmm0, xmmword ptr [rbp + 0x90]
019713b3  410f114638               movups xmmword ptr [r14 + 0x38], xmm0
019713b8  0f108da0000000           movups xmm1, xmmword ptr [rbp + 0xa0]
019713bf  410f114e48               movups xmmword ptr [r14 + 0x48], xmm1
019713c4  41807e6100               cmp byte ptr [r14 + 0x61], 0
019713c9  7507                     jne 0x19713d2
019713cb  41837d6801               cmp dword ptr [r13 + 0x68], 1
019713d0  7405                     je 0x19713d7
019713d2  41806639fe               and byte ptr [r14 + 0x39], 0xfe
019713d7  8b7d04                   mov edi, dword ptr [rbp + 4]
019713da  498b07                   mov rax, qword ptr [r15]
019713dd  488d5530                 lea rdx, [rbp + 0x30]
019713e1  498bcf                   mov rcx, r15
019713e4  ff5020                   call qword ptr [rax + 0x20]
019713e7  b8ffff0000               mov eax, 0xffff
019713ec  66394540                 cmp word ptr [rbp + 0x40], ax
019713f0  7421                     je 0x1971413
019713f2  0fb64530                 movzx eax, byte ptr [rbp + 0x30]
019713f6  488d1503ec68fe           lea rdx, [rip - 0x19713fd]
019713fd  0fb68c10403b0202         movzx ecx, byte ptr [rax + rdx + 0x2023b40]
01971405  80bc11e812b00200         cmp byte ptr [rcx + rdx + 0x2b012e8], 0
0197140d  0f84a6000000             je 0x19714b9
01971413  81bdf800000055200000     cmp dword ptr [rbp + 0xf8], 0x2055
0197141d  0f8596000000             jne 0x19714b9
01971423  39bdb0000000             cmp dword ptr [rbp + 0xb0], edi
01971429  0f848a000000             je 0x19714b9
0197142f  488b7d58                 mov rdi, qword ptr [rbp + 0x58]
01971433  488b07                   mov rax, qword ptr [rdi]
01971436  488bcf                   mov rcx, rdi
01971439  ff5058                   call qword ptr [rax + 0x58]
0197143c  894508                   mov dword ptr [rbp + 8], eax
0197143f  41bc01000000             mov r12d, 1
01971445  458bf4                   mov r14d, r12d
01971448  413bc4                   cmp eax, r12d
0197144b  0f8282000000             jb 0x19714d3
01971451  0faee8                   lfence
01971454  0f1f4000                 nop dword ptr [rax]
01971458  0f1f840000000000         nop dword ptr [rax + rax]
01971460  4c8b07                   mov r8, qword ptr [rdi]
01971463  418bd6                   mov edx, r14d
01971466  488bcf                   mov rcx, rdi
01971469  41ff5060                 call qword ptr [r8 + 0x60]
0197146d  448be0                   mov r12d, eax
01971470  4c8b07                   mov r8, qword ptr [rdi]
01971473  8bd0                     mov edx, eax
01971475  488bcf                   mov rcx, rdi
01971478  41ff5040                 call qword ptr [r8 + 0x40]
0197147c  488bf8                   mov rdi, rax
0197147f  4885c0                   test rax, rax
01971482  7418                     je 0x197149c
01971484  488b10                   mov rdx, qword ptr [rax]
01971487  488bc8                   mov rcx, rax
0197148a  ff5210                   call qword ptr [rdx + 0x10]
0197148d  394504                   cmp dword ptr [rbp + 4], eax
01971490  750a                     jne 0x197149c
01971492  b8ffffffff               mov eax, 0xffffffff
01971497  443be0                   cmp r12d, eax
0197149a  750f                     jne 0x19714ab
0197149c  41ffc6                   inc r14d
0197149f  443b7508                 cmp r14d, dword ptr [rbp + 8]
019714a3  7728                     ja 0x19714cd
019714a5  488b7d58                 mov rdi, qword ptr [rbp + 0x58]
019714a9  ebb5                     jmp 0x1971460
019714ab  0faee8                   lfence
019714ae  488b07                   mov rax, qword ptr [rdi]
019714b1  488bcf                   mov rcx, rdi
019714b4  ff5018                   call qword ptr [rax + 0x18]
019714b7  eb09                     jmp 0x19714c2
019714b9  498b07                   mov rax, qword ptr [r15]
019714bc  498bcf                   mov rcx, r15
019714bf  ff5008                   call qword ptr [rax + 8]
019714c2  8bc8                     mov ecx, eax
019714c4  488b4620                 mov rax, qword ptr [rsi + 0x20]
019714c8  48894c1860               mov qword ptr [rax + rbx + 0x60], rcx
019714cd  41bc01000000             mov r12d, 1
019714d3  488b4620                 mov rax, qword ptr [rsi + 0x20]
019714d7  c644035c00               mov byte ptr [rbx + rax + 0x5c], 0
019714dc  0fb65530                 movzx edx, byte ptr [rbp + 0x30]
019714e0  440fb74540               movzx r8d, word ptr [rbp + 0x40]
019714e5  41baffff0000             mov r10d, 0xffff
019714eb  4c8d0d0eeb68fe           lea r9, [rip - 0x19714f2]
019714f2  66453bc2                 cmp r8w, r10w
019714f6  0f8490000000             je 0x197158c
019714fc  410fb68c11403b0202       movzx ecx, byte ptr [r9 + rdx + 0x2023b40]
01971505  4280bc09e812b00200       cmp byte ptr [rcx + r9 + 0x2b012e8], 0
0197150e  757c                     jne 0x197158c
01971510  80faf0                   cmp dl, 0xf0
01971513  7568                     jne 0x197157d
01971515  b2a5                     mov dl, 0xa5
01971517  488d8dc8000000           lea rcx, [rbp + 0xc8]
0197151e  e8ad216efe               call 0x536d0
01971523  0fb65531                 movzx edx, byte ptr [rbp + 0x31]
01971527  f6d2                     not dl
01971529  f6c201                   test dl, 1
0197152c  7507                     jne 0x1971535
0197152e  808dc900000001           or byte ptr [rbp + 0xc9], 1
01971535  80bdc800000062           cmp byte ptr [rbp + 0xc8], 0x62
0197153c  7508                     jne 0x1971546
0197153e  664489a5d8000000         mov word ptr [rbp + 0xd8], r12w
01971546  0f1085c8000000           movups xmm0, xmmword ptr [rbp + 0xc8]
0197154d  0f114530                 movups xmmword ptr [rbp + 0x30], xmm0
01971551  0f108dd8000000           movups xmm1, xmmword ptr [rbp + 0xd8]
01971558  0f114d40                 movups xmmword ptr [rbp + 0x40], xmm1
0197155c  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971560  33ff                     xor edi, edi
01971562  897c034c                 mov dword ptr [rbx + rax + 0x4c], edi
01971566  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197156a  40887c035c               mov byte ptr [rbx + rax + 0x5c], dil
0197156f  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971573  c644035d01               mov byte ptr [rbx + rax + 0x5d], 1
01971578  e914010000               jmp 0x1971691
0197157d  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971581  33ff                     xor edi, edi
01971583  897c034c                 mov dword ptr [rbx + rax + 0x4c], edi
01971587  e905010000               jmp 0x1971691
0197158c  c6466001                 mov byte ptr [rsi + 0x60], 1
01971590  80fa22                   cmp dl, 0x22
01971593  7511                     jne 0x19715a6
01971595  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971599  c744034c03000000         mov dword ptr [rbx + rax + 0x4c], 3
019715a1  e9e9000000               jmp 0x197168f
019715a6  80fa63                   cmp dl, 0x63
019715a9  7511                     jne 0x19715bc
019715ab  488b4620                 mov rax, qword ptr [rsi + 0x20]
019715af  c744034c02000000         mov dword ptr [rbx + rax + 0x4c], 2
019715b7  e9d3000000               jmp 0x197168f
019715bc  80fa23                   cmp dl, 0x23
019715bf  0f84c1000000             je 0x1971686
019715c5  410fb68c11403b0202       movzx ecx, byte ptr [r9 + rdx + 0x2023b40]
019715ce  4180bc09100b060200       cmp byte ptr [r9 + rcx + 0x2060b10], 0
019715d7  7420                     je 0x19715f9
019715d9  66453bc2                 cmp r8w, r10w
019715dd  751a                     jne 0x19715f9
019715df  488b4620                 mov rax, qword ptr [rsi + 0x20]
019715e3  c744034c03000000         mov dword ptr [rbx + rax + 0x4c], 3
019715eb  488b4620                 mov rax, qword ptr [rsi + 0x20]
019715ef  c644035c01               mov byte ptr [rbx + rax + 0x5c], 1
019715f4  e996000000               jmp 0x197168f
019715f9  4280bc090023070200       cmp byte ptr [rcx + r9 + 0x2072300], 0
01971602  741d                     je 0x1971621
01971604  66453bc2                 cmp r8w, r10w
01971608  7517                     jne 0x1971621
0197160a  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197160e  c744034c02000000         mov dword ptr [rbx + rax + 0x4c], 2
01971616  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197161a  c644035c01               mov byte ptr [rbx + rax + 0x5c], 1
0197161f  eb6e                     jmp 0x197168f
01971621  4280bc09600a060200       cmp byte ptr [rcx + r9 + 0x2060a60], 0
0197162a  741a                     je 0x1971646
0197162c  66453bc2                 cmp r8w, r10w
01971630  7514                     jne 0x1971646
01971632  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971636  448964034c               mov dword ptr [rbx + rax + 0x4c], r12d
0197163b  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197163f  c644035c01               mov byte ptr [rbx + rax + 0x5c], 1
01971644  eb49                     jmp 0x197168f
01971646  80faf1                   cmp dl, 0xf1
01971649  7494                     je 0x19715df
0197164b  80faf0                   cmp dl, 0xf0
0197164e  7536                     jne 0x1971686
01971650  0f1005c90c1d01           movups xmm0, xmmword ptr [rip + 0x11d0cc9]
01971657  0f114530                 movups xmmword ptr [rbp + 0x30], xmm0
0197165b  0f100dce0c1d01           movups xmm1, xmmword ptr [rip + 0x11d0cce]
01971662  0f114d40                 movups xmmword ptr [rbp + 0x40], xmm1
01971666  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197166a  c744034c03000000         mov dword ptr [rbx + rax + 0x4c], 3
01971672  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971676  c644035c01               mov byte ptr [rbx + rax + 0x5c], 1
0197167b  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197167f  c644035d01               mov byte ptr [rbx + rax + 0x5d], 1
01971684  eb09                     jmp 0x197168f
01971686  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197168a  448964034c               mov dword ptr [rbx + rax + 0x4c], r12d
0197168f  33ff                     xor edi, edi
01971691  448b6550                 mov r12d, dword ptr [rbp + 0x50]
01971695  418bcc                   mov ecx, r12d
01971698  48c1e105                 shl rcx, 5
0197169c  488b4648                 mov rax, qword ptr [rsi + 0x48]
019716a0  0f104530                 movups xmm0, xmmword ptr [rbp + 0x30]
019716a4  0f110401                 movups xmmword ptr [rcx + rax], xmm0
019716a8  0f104d40                 movups xmm1, xmmword ptr [rbp + 0x40]
019716ac  0f114c0110               movups xmmword ptr [rcx + rax + 0x10], xmm1
019716b1  807d30bd                 cmp byte ptr [rbp + 0x30], 0xbd
019716b5  0f94c1                   sete cl
019716b8  488b4620                 mov rax, qword ptr [rsi + 0x20]
019716bc  884c0353                 mov byte ptr [rbx + rax + 0x53], cl
019716c0  8b8544010000             mov eax, dword ptr [rbp + 0x144]
019716c6  83f808                   cmp eax, 8
019716c9  770a                     ja 0x19716d5
019716cb  b924010000               mov ecx, 0x124
019716d0  0fa3c1                   bt ecx, eax
019716d3  721a                     jb 0x19716ef
019716d5  498b07                   mov rax, qword ptr [r15]
019716d8  498bcf                   mov rcx, r15
019716db  ff5048                   call qword ptr [rax + 0x48]
019716de  8bcf                     mov ecx, edi
019716e0  4885c0                   test rax, rax
019716e3  0f95c1                   setne cl
019716e6  488b4620                 mov rax, qword ptr [rsi + 0x20]
019716ea  66894c0346               mov word ptr [rbx + rax + 0x46], cx
019716ef  0fb68554010000           movzx eax, byte ptr [rbp + 0x154]
019716f6  a808                     test al, 8
019716f8  7511                     jne 0x197170b
019716fa  a810                     test al, 0x10
019716fc  750d                     jne 0x197170b
019716fe  83bd4001000000           cmp dword ptr [rbp + 0x140], 0
01971705  7504                     jne 0x197170b
01971707  33c9                     xor ecx, ecx
01971709  eb02                     jmp 0x197170d
0197170b  b101                     mov cl, 1
0197170d  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971711  884c035e                 mov byte ptr [rbx + rax + 0x5e], cl
01971715  41b91c000000             mov r9d, 0x1c
0197171b  458d41e5                 lea r8d, [r9 - 0x1b]
0197171f  488d5530                 lea rdx, [rbp + 0x30]
01971723  488d8d60010000           lea rcx, [rbp + 0x160]
0197172a  ff1560a15500             call qword ptr [rip + 0x55a160]
01971730  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971734  c644035700               mov byte ptr [rbx + rax + 0x57], 0
01971739  0fb64530                 movzx eax, byte ptr [rbp + 0x30]
0197173d  488d15bce868fe           lea rdx, [rip - 0x1971744]
01971744  0fb68c10403b0202         movzx ecx, byte ptr [rax + rdx + 0x2023b40]
0197174c  80bc11e01e120200         cmp byte ptr [rcx + rdx + 0x2121ee0], 0
01971754  741b                     je 0x1971771
01971756  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197175a  c644035401               mov byte ptr [rbx + rax + 0x54], 1
0197175f  80bd000100003a           cmp byte ptr [rbp + 0x100], 0x3a
01971766  7509                     jne 0x1971771
01971768  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197176c  c644035701               mov byte ptr [rbx + rax + 0x57], 1
01971771  80bd000100007a           cmp byte ptr [rbp + 0x100], 0x7a
01971778  751e                     jne 0x1971798
0197177a  c7858801000006001304     mov dword ptr [rbp + 0x188], 0x4130006
01971784  48c7858001000008000000   mov qword ptr [rbp + 0x180], 8
0197178f  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971793  c644035701               mov byte ptr [rbx + rax + 0x57], 1
01971798  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197179c  48c7040380010000         mov qword ptr [rbx + rax], 0x180
019717a4  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
019717a8  0fb78588010000           movzx eax, word ptr [rbp + 0x188]
019717af  6689440b44               mov word ptr [rbx + rcx + 0x44], ax
019717b4  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
019717b8  8b8578010000             mov eax, dword ptr [rbp + 0x178]
019717be  89440b20                 mov dword ptr [rbx + rcx + 0x20], eax
019717c2  418d4c2401               lea ecx, [r12 + 1]
019717c7  488b4620                 mov rax, qword ptr [rsi + 0x20]
019717cb  48894c0308               mov qword ptr [rbx + rax + 8], rcx
019717d0  8b8d80010000             mov ecx, dword ptr [rbp + 0x180]
019717d6  488b4620                 mov rax, qword ptr [rsi + 0x20]
019717da  48894c0330               mov qword ptr [rbx + rax + 0x30], rcx
019717df  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
019717e3  0fb6858a010000           movzx eax, byte ptr [rbp + 0x18a]
019717ea  88440b50                 mov byte ptr [rbx + rcx + 0x50], al
019717ee  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
019717f2  0fb6858b010000           movzx eax, byte ptr [rbp + 0x18b]
019717f9  88440b51                 mov byte ptr [rbx + rcx + 0x51], al
019717fd  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971801  48897c0328               mov qword ptr [rbx + rax + 0x28], rdi
01971806  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197180a  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
01971811  894c0338                 mov dword ptr [rbx + rax + 0x38], ecx
01971815  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971819  894c033c                 mov dword ptr [rbx + rax + 0x3c], ecx
0197181d  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971821  894c0340                 mov dword ptr [rbx + rax + 0x40], ecx
01971825  0fb64530                 movzx eax, byte ptr [rbp + 0x30]
01971829  0410                     add al, 0x10
0197182b  8bcf                     mov ecx, edi
0197182d  3c01                     cmp al, 1
0197182f  0f474d44                 cmova ecx, dword ptr [rbp + 0x44]
01971833  488b5620                 mov rdx, qword ptr [rsi + 0x20]
01971837  4883c268                 add rdx, 0x68
0197183b  4803d3                   add rdx, rbx
0197183e  e8ed5579fe               call 0x106e30
01971843  0fb64530                 movzx eax, byte ptr [rbp + 0x30]
01971847  4c8d0db2e768fe           lea r9, [rip - 0x197184e]
0197184e  420fb68c08403b0202       movzx ecx, byte ptr [rax + r9 + 0x2023b40]
01971857  488b05a2df7a00           mov rax, qword ptr [rip + 0x7adfa2]
0197185e  0fb71448                 movzx edx, word ptr [rax + rcx*2]
01971862  0fb64d31                 movzx ecx, byte ptr [rbp + 0x31]
01971866  f6d1                     not cl
01971868  0fb7c2                   movzx eax, dx
0197186b  66c1e808                 shr ax, 8
0197186f  440fb6c0                 movzx r8d, al
01971873  0fb6c2                   movzx eax, dl
01971876  80e101                   and cl, 1
01971879  440f45c0                 cmovne r8d, eax
0197187d  418b4578                 mov eax, dword ptr [r13 + 0x78]
01971881  83e802                   sub eax, 2
01971884  83f801                   cmp eax, 1
01971887  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197188b  760a                     jbe 0x1971897
0197188d  c644035800               mov byte ptr [rbx + rax + 0x58], 0
01971892  e9eb000000               jmp 0x1971982
01971897  c644035801               mov byte ptr [rbx + rax + 0x58], 1
0197189c  0fb65530                 movzx edx, byte ptr [rbp + 0x30]
019718a0  b8ffff0000               mov eax, 0xffff
019718a5  66394540                 cmp word ptr [rbp + 0x40], ax
019718a9  7414                     je 0x19718bf
019718ab  410fb68c11403b0202       movzx ecx, byte ptr [r9 + rdx + 0x2023b40]
019718b4  4280bc09e812b00200       cmp byte ptr [rcx + r9 + 0x2b012e8], 0
019718bd  7418                     je 0x19718d7
019718bf  410fb68c11403b0202       movzx ecx, byte ptr [r9 + rdx + 0x2023b40]
019718c8  4280bc09d08a050200       cmp byte ptr [rcx + r9 + 0x2058ad0], 0
019718d1  0f84a2000000             je 0x1971979
019718d7  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
019718db  807c0b5d01               cmp byte ptr [rbx + rcx + 0x5d], 1
019718e0  0f8493000000             je 0x1971979
019718e6  0fb64531                 movzx eax, byte ptr [rbp + 0x31]
019718ea  f6d0                     not al
019718ec  a801                     test al, 1
019718ee  7540                     jne 0x1971930
019718f0  41f6c020                 test r8b, 0x20
019718f4  7409                     je 0x19718ff
019718f6  f6857801000010           test byte ptr [rbp + 0x178], 0x10
019718fd  7431                     je 0x1971930
019718ff  418d40ce                 lea eax, [r8 - 0x32]
01971903  3c3a                     cmp al, 0x3a
01971905  7710                     ja 0x1971917
01971907  48ba0100000000000005     movabs rdx, 0x500000000000001
01971911  480fa3c2                 bt rdx, rax
01971915  7219                     jb 0x1971930
01971917  4180f8ad                 cmp r8b, 0xad
0197191b  7413                     je 0x1971930
0197191d  4180f824                 cmp r8b, 0x24
01971921  740d                     je 0x1971930
01971923  4180f8ef                 cmp r8b, 0xef
01971927  7407                     je 0x1971930
01971929  c6440b5500               mov byte ptr [rbx + rcx + 0x55], 0
0197192e  eb52                     jmp 0x1971982
01971930  4584c0                   test r8b, r8b
01971933  7907                     jns 0x197193c
01971935  c6440b5502               mov byte ptr [rbx + rcx + 0x55], 2
0197193a  eb15                     jmp 0x1971951
0197193c  41f6c00c                 test r8b, 0xc
01971940  b801000000               mov eax, 1
01971945  ba04000000               mov edx, 4
0197194a  0f44c2                   cmove eax, edx
0197194d  88440b55                 mov byte ptr [rbx + rcx + 0x55], al
01971951  4180f868                 cmp r8b, 0x68
01971955  7417                     je 0x197196e
01971957  4180f832                 cmp r8b, 0x32
0197195b  7411                     je 0x197196e
0197195d  4180f8ad                 cmp r8b, 0xad
01971961  751f                     jne 0x1971982
01971963  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971967  c644035502               mov byte ptr [rbx + rax + 0x55], 2
0197196c  eb14                     jmp 0x1971982
0197196e  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971972  c644035501               mov byte ptr [rbx + rax + 0x55], 1
01971977  eb09                     jmp 0x1971982
01971979  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197197d  c644035508               mov byte ptr [rbx + rax + 0x55], 8
01971982  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971986  c644035b00               mov byte ptr [rbx + rax + 0x5b], 0
0197198b  41837d7805               cmp dword ptr [r13 + 0x78], 5
01971990  0f94c1                   sete cl
01971993  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971997  884c0359                 mov byte ptr [rbx + rax + 0x59], cl
0197199b  488b4620                 mov rax, qword ptr [rsi + 0x20]
0197199f  c644035a00               mov byte ptr [rbx + rax + 0x5a], 0
019719a4  410fb6c0                 movzx eax, r8b
019719a8  83c0de                   add eax, -0x22
019719ab  3dcf000000               cmp eax, 0xcf
019719b0  7723                     ja 0x19719d5
019719b2  4898                     cdqe
019719b4  410fb68401741d9701       movzx eax, byte ptr [r9 + rax + 0x1971d74]
019719bd  418b8c816c1d9701         mov ecx, dword ptr [r9 + rax*4 + 0x1971d6c]
019719c5  4903c9                   add rcx, r9
019719c8  ffe1                     jmp rcx
019719ca  488b4620                 mov rax, qword ptr [rsi + 0x20]
019719ce  c644035601               mov byte ptr [rbx + rax + 0x56], 1
019719d3  eb09                     jmp 0x19719de
019719d5  488b4620                 mov rax, qword ptr [rsi + 0x20]
019719d9  c644035600               mov byte ptr [rbx + rax + 0x56], 0
019719de  498b07                   mov rax, qword ptr [r15]
019719e1  498bcf                   mov rcx, r15
019719e4  ff5010                   call qword ptr [rax + 0x10]
019719e7  8b5008                   mov edx, dword ptr [rax + 8]
019719ea  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
019719ee  428914a1                 mov dword ptr [rcx + r12*4], edx
019719f2  b900010000               mov ecx, 0x100
019719f7  3bd1                     cmp edx, ecx
019719f9  0f47d1                   cmova edx, ecx
019719fc  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
01971a00  89540b78                 mov dword ptr [rbx + rcx + 0x78], edx
01971a04  4863fa                   movsxd rdi, edx
01971a07  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
01971a0b  4883c17c                 add rcx, 0x7c
01971a0f  4803cb                   add rcx, rbx
01971a12  4c8bcf                   mov r9, rdi
01971a15  4c8b00                   mov r8, qword ptr [rax]
01971a18  ba02010000               mov edx, 0x102
01971a1d  e84e4e69fe               call 0x6870
01971a22  48d1ef                   shr rdi, 1
01971a25  4b8d0464                 lea rax, [r12 + r12*2]
01971a29  48c1e006                 shl rax, 6
01971a2d  4803f8                   add rdi, rax
01971a30  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971a34  4533c0                   xor r8d, r8d
01971a37  66448944787c             mov word ptr [rax + rdi*2 + 0x7c], r8w
01971a3d  418b4510                 mov eax, dword ptr [r13 + 0x10]
01971a41  480fbae00a               bt rax, 0xa
01971a46  7217                     jb 0x1971a5f
01971a48  498b07                   mov rax, qword ptr [r15]
01971a4b  498bcf                   mov rcx, r15
01971a4e  ff5030                   call qword ptr [rax + 0x30]
01971a51  4885c0                   test rax, rax
01971a54  7409                     je 0x1971a5f
01971a56  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971a5a  834c032020               or dword ptr [rbx + rax + 0x20], 0x20
01971a5f  418b4510                 mov eax, dword ptr [r13 + 0x10]
01971a63  480fbae009               bt rax, 9
01971a68  7212                     jb 0x1971a7c
01971a6a  f6855201000004           test byte ptr [rbp + 0x152], 4
01971a71  7409                     je 0x1971a7c
01971a73  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971a77  834c032020               or dword ptr [rbx + rax + 0x20], 0x20
01971a7c  41bfffffffff             mov r15d, 0xffffffff
01971a82  f6855401000020           test byte ptr [rbp + 0x154], 0x20
01971a89  7409                     je 0x1971a94
01971a8b  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971a8f  834c032020               or dword ptr [rbx + rax + 0x20], 0x20
01971a94  488b4d20                 mov rcx, qword ptr [rbp + 0x20]
01971a98  4885c9                   test rcx, rcx
01971a9b  752e                     jne 0x1971acb
01971a9d  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01971aa1  488b01                   mov rax, qword ptr [rcx]
01971aa4  8b5518                   mov edx, dword ptr [rbp + 0x18]
01971aa7  ff90d0000000             call qword ptr [rax + 0xd0]
01971aad  8b4d1c                   mov ecx, dword ptr [rbp + 0x1c]
01971ab0  3bc8                     cmp ecx, eax
01971ab2  732d                     jae 0x1971ae1
01971ab4  ffc1                     inc ecx
01971ab6  894d1c                   mov dword ptr [rbp + 0x1c], ecx
01971ab9  41ffc4                   inc r12d
01971abc  44896550                 mov dword ptr [rbp + 0x50], r12d
01971ac0  4c8b7560                 mov r14, qword ptr [rbp + 0x60]
01971ac4  33ff                     xor edi, edi
01971ac6  e985f6ffff               jmp 0x1971150
01971acb  488b01                   mov rax, qword ptr [rcx]
01971ace  488d5528                 lea rdx, [rbp + 0x28]
01971ad2  ff5010                   call qword ptr [rax + 0x10]
01971ad5  8b4d28                   mov ecx, dword ptr [rbp + 0x28]
01971ad8  84c0                     test al, al
01971ada  410f44cf                 cmove ecx, r15d
01971ade  894d28                   mov dword ptr [rbp + 0x28], ecx
01971ae1  41ffc4                   inc r12d
01971ae4  44896550                 mov dword ptr [rbp + 0x50], r12d
01971ae8  4c8b7560                 mov r14, qword ptr [rbp + 0x60]
01971aec  33ff                     xor edi, edi
01971aee  e95df6ffff               jmp 0x1971150
01971af3  418b8518010000           mov eax, dword ptr [r13 + 0x118]
01971afa  894638                   mov dword ptr [rsi + 0x38], eax
01971afd  85c0                     test eax, eax
01971aff  0f8442020000             je 0x1971d47
01971b05  41bc01000000             mov r12d, 1
01971b0b  44896508                 mov dword ptr [rbp + 8], r12d
01971b0f  8bc8                     mov ecx, eax
01971b11  b810000000               mov eax, 0x10
01971b16  48f7e1                   mul rcx
01971b19  49c7c7ffffffff           mov r15, 0xffffffffffffffff
01971b20  490f40c7                 cmovo rax, r15
01971b24  c644242005               mov byte ptr [rsp + 0x20], 5
01971b29  41b94f050000             mov r9d, 0x54f
01971b2f  4c8d054229b500           lea r8, [rip + 0xb52942]
01971b36  488b5650                 mov rdx, qword ptr [rsi + 0x50]
01971b3a  488bc8                   mov rcx, rax
01971b3d  ff15b5935500             call qword ptr [rip + 0x5593b5]
01971b43  48894630                 mov qword ptr [rsi + 0x30], rax
01971b47  448b4638                 mov r8d, dword ptr [rsi + 0x38]
01971b4b  498d400f                 lea rax, [r8 + 0xf]
01971b4f  48baf0ffffffffffff0f     movabs rdx, 0xffffffffffffff0
01971b59  493bc0                   cmp rax, r8
01971b5c  7703                     ja 0x1971b61
01971b5e  488bc2                   mov rax, rdx
01971b61  4883e0f0                 and rax, 0xfffffffffffffff0
01971b65  e826f568fe               call 0x1090
01971b6a  482be0                   sub rsp, rax
01971b6d  488d7c2450               lea rdi, [rsp + 0x50]
01971b72  48897d60                 mov qword ptr [rbp + 0x60], rdi
01971b76  8b4628                   mov eax, dword ptr [rsi + 0x28]
01971b79  488d480f                 lea rcx, [rax + 0xf]
01971b7d  483bc8                   cmp rcx, rax
01971b80  7703                     ja 0x1971b85
01971b82  488bca                   mov rcx, rdx
01971b85  4883e1f0                 and rcx, 0xfffffffffffffff0
01971b89  488bc1                   mov rax, rcx
01971b8c  e8fff468fe               call 0x1090
01971b91  482be1                   sub rsp, rcx
01971b94  4c8d742450               lea r14, [rsp + 0x50]
01971b99  4c897558                 mov qword ptr [rbp + 0x58], r14
01971b9d  33d2                     xor edx, edx
01971b9f  488bcf                   mov rcx, rdi
01971ba2  e895f868fe               call 0x143c
01971ba7  448b4628                 mov r8d, dword ptr [rsi + 0x28]
01971bab  33d2                     xor edx, edx
01971bad  498bce                   mov rcx, r14
01971bb0  e887f868fe               call 0x143c
01971bb5  33c9                     xor ecx, ecx
01971bb7  448bf9                   mov r15d, ecx
01971bba  8b4638                   mov eax, dword ptr [rsi + 0x38]
01971bbd  85c0                     test eax, eax
01971bbf  0f84b7000000             je 0x1971c7c
01971bc5  4c8be7                   mov r12, rdi
01971bc8  0f1f840000000000         nop dword ptr [rax + rax]
01971bd0  8bd9                     mov ebx, ecx
01971bd2  837e2800                 cmp dword ptr [rsi + 0x28], 0
01971bd6  0f8685000000             jbe 0x1971c61
01971bdc  458bf7                   mov r14d, r15d
01971bdf  90                       nop
01971be0  8bfb                     mov edi, ebx
01971be2  ffc3                     inc ebx
01971be4  488d0c7f                 lea rcx, [rdi + rdi*2]
01971be8  48c1e107                 shl rcx, 7
01971bec  4c8b4e20                 mov r9, qword ptr [rsi + 0x20]
01971bf0  4983c17c                 add r9, 0x7c
01971bf4  4c03c9                   add r9, rcx
01971bf7  498b8d20010000           mov rcx, qword ptr [r13 + 0x120]
01971bfe  498b9528010000           mov rdx, qword ptr [r13 + 0x128]
01971c05  488b4568                 mov rax, qword ptr [rbp + 0x68]
01971c09  8b04b8                   mov eax, dword ptr [rax + rdi*4]
01971c0c  89442420                 mov dword ptr [rsp + 0x20], eax
01971c10  468b04b1                 mov r8d, dword ptr [rcx + r14*4]
01971c14  4a8b14f2                 mov rdx, qword ptr [rdx + r14*8]
01971c18  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
01971c1f  ff15fba05500             call qword ptr [rip + 0x55a0fb]
01971c25  84c0                     test al, al
01971c27  7507                     jne 0x1971c30
01971c29  3b5e28                   cmp ebx, dword ptr [rsi + 0x28]
01971c2c  72b2                     jb 0x1971be0
01971c2e  eb2f                     jmp 0x1971c5f
01971c30  43fe0434                 inc byte ptr [r12 + r14]
01971c34  488b4558                 mov rax, qword ptr [rbp + 0x58]
01971c38  fe0407                   inc byte ptr [rdi + rax]
01971c3b  498bd6                   mov rdx, r14
01971c3e  4803d2                   add rdx, rdx
01971c41  8bcb                     mov ecx, ebx
01971c43  488b4630                 mov rax, qword ptr [rsi + 0x30]
01971c47  48890cd0                 mov qword ptr [rax + rdx*8], rcx
01971c4b  498b8530010000           mov rax, qword ptr [r13 + 0x130]
01971c52  420fb60c30               movzx ecx, byte ptr [rax + r14]
01971c57  488b4630                 mov rax, qword ptr [rsi + 0x30]
01971c5b  894cd008                 mov dword ptr [rax + rdx*8 + 8], ecx
01971c5f  33c9                     xor ecx, ecx
01971c61  41ffc7                   inc r15d
01971c64  8b4638                   mov eax, dword ptr [rsi + 0x38]
01971c67  443bf8                   cmp r15d, eax
01971c6a  0f8260ffffff             jb 0x1971bd0
01971c70  448b6508                 mov r12d, dword ptr [rbp + 8]
01971c74  488b7d60                 mov rdi, qword ptr [rbp + 0x60]
01971c78  4c8b7558                 mov r14, qword ptr [rbp + 0x58]
01971c7c  8bd9                     mov ebx, ecx
01971c7e  85c0                     test eax, eax
01971c80  7450                     je 0x1971cd2
01971c82  41be01000000             mov r14d, 1
01971c88  4585e4                   test r12d, r12d
01971c8b  7441                     je 0x1971cce
01971c8d  8bd3                     mov edx, ebx
01971c8f  803c3a00                 cmp byte ptr [rdx + rdi], 0
01971c93  7532                     jne 0x1971cc7
01971c95  448be1                   mov r12d, ecx
01971c98  498b8528010000           mov rax, qword ptr [r13 + 0x128]
01971c9f  498b8d20010000           mov rcx, qword ptr [r13 + 0x120]
01971ca6  488b04d0                 mov rax, qword ptr [rax + rdx*8]
01971caa  4889442420               mov qword ptr [rsp + 0x20], rax
01971caf  448b0c91                 mov r9d, dword ptr [rcx + rdx*4]
01971cb3  458bc6                   mov r8d, r14d
01971cb6  ba0a000000               mov edx, 0xa
01971cbb  b9d1120000               mov ecx, 0x12d1
01971cc0  e81bb293fe               call 0x2acee0
01971cc5  33c9                     xor ecx, ecx
01971cc7  ffc3                     inc ebx
01971cc9  3b5e38                   cmp ebx, dword ptr [rsi + 0x38]
01971ccc  72ba                     jb 0x1971c88
01971cce  4c8b7558                 mov r14, qword ptr [rbp + 0x58]
01971cd2  8bd9                     mov ebx, ecx
01971cd4  837e2800                 cmp dword ptr [rsi + 0x28], 0
01971cd8  7653                     jbe 0x1971d2d
01971cda  660f1f0400               nop word ptr [rax + rax]
01971cdf  90                       nop
01971ce0  4585e4                   test r12d, r12d
01971ce3  744d                     je 0x1971d32
01971ce5  8bd3                     mov edx, ebx
01971ce7  42803c3201               cmp byte ptr [rdx + r14], 1
01971cec  7638                     jbe 0x1971d26
01971cee  448be1                   mov r12d, ecx
01971cf1  488d0c52                 lea rcx, [rdx + rdx*2]
01971cf5  48c1e107                 shl rcx, 7
01971cf9  488b4620                 mov rax, qword ptr [rsi + 0x20]
01971cfd  4883c07c                 add rax, 0x7c
01971d01  4803c8                   add rcx, rax
01971d04  48894c2420               mov qword ptr [rsp + 0x20], rcx
01971d09  488b4568                 mov rax, qword ptr [rbp + 0x68]
01971d0d  448b0c90                 mov r9d, dword ptr [rax + rdx*4]
01971d11  ba0a000000               mov edx, 0xa
01971d16  b9d2120000               mov ecx, 0x12d2
01971d1b  448d42f7                 lea r8d, [rdx - 9]
01971d1f  e8bcb193fe               call 0x2acee0
01971d24  33c9                     xor ecx, ecx
01971d26  ffc3                     inc ebx
01971d28  3b5e28                   cmp ebx, dword ptr [rsi + 0x28]
01971d2b  72b3                     jb 0x1971ce0
01971d2d  4585e4                   test r12d, r12d
01971d30  7515                     jne 0x1971d47
01971d32  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
01971d36  ff156c925500             call qword ptr [rip + 0x55926c]
01971d3c  4533c0                   xor r8d, r8d
01971d3f  4c894630                 mov qword ptr [rsi + 0x30], r8
01971d43  44894638                 mov dword ptr [rsi + 0x38], r8d
01971d47  488b8d10020000           mov rcx, qword ptr [rbp + 0x210]
01971d4e  4833cd                   xor rcx, rbp
01971d51  e81af368fe               call 0x1070
01971d56  488da528020000           lea rsp, [rbp + 0x228]
01971d5d  415f                     pop r15
01971d5f  415e                     pop r14
01971d61  415d                     pop r13
01971d63  415c                     pop r12
01971d65  5f                       pop rdi
01971d66  5e                       pop rsi
01971d67  5b                       pop rbx
01971d68  5d                       pop rbp
01971d69  c3                       ret
01971d6a  90                       nop
01971d6b  90                       nop
01971d6c  ca1997                   retf 0x9719
01971d6f  01d5                     add ebp, edx
01971d71  199701000001             sbb dword ptr [rdi + 0x1000001], edx
01971d77  0101                     add dword ptr [rcx], eax
01971d79  0101                     add dword ptr [rcx], eax
01971d7b  0101                     add dword ptr [rcx], eax
01971d7d  0101                     add dword ptr [rcx], eax
01971d7f  0101                     add dword ptr [rcx], eax
01971d81  0101                     add dword ptr [rcx], eax
01971d83  0101                     add dword ptr [rcx], eax
01971d85  0101                     add dword ptr [rcx], eax
01971d87  0101                     add dword ptr [rcx], eax
01971d89  0101                     add dword ptr [rcx], eax
01971d8b  0101                     add dword ptr [rcx], eax
01971d8d  0101                     add dword ptr [rcx], eax
01971d8f  0101                     add dword ptr [rcx], eax
01971d91  0101                     add dword ptr [rcx], eax
01971d93  0101                     add dword ptr [rcx], eax
01971d95  0101                     add dword ptr [rcx], eax
01971d97  0101                     add dword ptr [rcx], eax
01971d99  0101                     add dword ptr [rcx], eax
01971d9b  0101                     add dword ptr [rcx], eax
01971d9d  0101                     add dword ptr [rcx], eax
01971d9f  0101                     add dword ptr [rcx], eax
01971da1  0101                     add dword ptr [rcx], eax
01971da3  0101                     add dword ptr [rcx], eax
01971da5  0101                     add dword ptr [rcx], eax
01971da7  0101                     add dword ptr [rcx], eax
01971da9  0101                     add dword ptr [rcx], eax
01971dab  0101                     add dword ptr [rcx], eax
01971dad  0101                     add dword ptr [rcx], eax
01971daf  0101                     add dword ptr [rcx], eax
01971db1  0101                     add dword ptr [rcx], eax
01971db3  0101                     add dword ptr [rcx], eax
01971db5  0001                     add byte ptr [rcx], al
01971db7  0101                     add dword ptr [rcx], eax
01971db9  0101                     add dword ptr [rcx], eax
01971dbb  0101                     add dword ptr [rcx], eax
01971dbd  0101                     add dword ptr [rcx], eax
01971dbf  0101                     add dword ptr [rcx], eax
01971dc1  0101                     add dword ptr [rcx], eax
01971dc3  0101                     add dword ptr [rcx], eax
01971dc5  0101                     add dword ptr [rcx], eax
01971dc7  0101                     add dword ptr [rcx], eax
01971dc9  0101                     add dword ptr [rcx], eax
01971dcb  0101                     add dword ptr [rcx], eax
01971dcd  0101                     add dword ptr [rcx], eax
01971dcf  0101                     add dword ptr [rcx], eax
01971dd1  0101                     add dword ptr [rcx], eax
01971dd3  0101                     add dword ptr [rcx], eax
01971dd5  0101                     add dword ptr [rcx], eax
01971dd7  0101                     add dword ptr [rcx], eax
01971dd9  0101                     add dword ptr [rcx], eax
01971ddb  0101                     add dword ptr [rcx], eax
01971ddd  0101                     add dword ptr [rcx], eax
01971ddf  0101                     add dword ptr [rcx], eax
01971de1  0101                     add dword ptr [rcx], eax
01971de3  0101                     add dword ptr [rcx], eax
01971de5  0101                     add dword ptr [rcx], eax
01971de7  0101                     add dword ptr [rcx], eax
01971de9  0101                     add dword ptr [rcx], eax
01971deb  0101                     add dword ptr [rcx], eax
01971ded  0101                     add dword ptr [rcx], eax
01971def  0101                     add dword ptr [rcx], eax
01971df1  0101                     add dword ptr [rcx], eax
01971df3  0101                     add dword ptr [rcx], eax
01971df5  0101                     add dword ptr [rcx], eax
01971df7  0001                     add byte ptr [rcx], al
01971df9  0001                     add byte ptr [rcx], al
01971dfb  0101                     add dword ptr [rcx], eax
01971dfd  0101                     add dword ptr [rcx], eax
01971dff  0001                     add byte ptr [rcx], al
01971e01  0001                     add byte ptr [rcx], al
01971e03  0101                     add dword ptr [rcx], eax
01971e05  0101                     add dword ptr [rcx], eax
01971e07  0101                     add dword ptr [rcx], eax
01971e09  0101                     add dword ptr [rcx], eax
01971e0b  0101                     add dword ptr [rcx], eax
01971e0d  0101                     add dword ptr [rcx], eax
01971e0f  0101                     add dword ptr [rcx], eax
01971e11  0101                     add dword ptr [rcx], eax
01971e13  0101                     add dword ptr [rcx], eax
01971e15  0101                     add dword ptr [rcx], eax
01971e17  0101                     add dword ptr [rcx], eax
01971e19  0101                     add dword ptr [rcx], eax
01971e1b  0101                     add dword ptr [rcx], eax
01971e1d  0101                     add dword ptr [rcx], eax
01971e1f  0101                     add dword ptr [rcx], eax
01971e21  0101                     add dword ptr [rcx], eax
01971e23  0101                     add dword ptr [rcx], eax
01971e25  0101                     add dword ptr [rcx], eax
01971e27  0101                     add dword ptr [rcx], eax
01971e29  0101                     add dword ptr [rcx], eax
01971e2b  0101                     add dword ptr [rcx], eax
01971e2d  0101                     add dword ptr [rcx], eax
01971e2f  0101                     add dword ptr [rcx], eax
01971e31  0101                     add dword ptr [rcx], eax
01971e33  0101                     add dword ptr [rcx], eax
01971e35  0101                     add dword ptr [rcx], eax
01971e37  0101                     add dword ptr [rcx], eax
01971e39  0001                     add byte ptr [rcx], al
01971e3b  0101                     add dword ptr [rcx], eax
01971e3d  0101                     add dword ptr [rcx], eax
01971e3f  0101                     add dword ptr [rcx], eax
01971e41  0001                     add byte ptr [rcx], al
