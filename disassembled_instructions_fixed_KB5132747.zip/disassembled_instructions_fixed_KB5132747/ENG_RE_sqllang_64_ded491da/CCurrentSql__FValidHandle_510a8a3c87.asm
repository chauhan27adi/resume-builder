; CCurrentSql::FValidHandle
; sqllang.dll, primary RVA 0xb220a0, 396 bytes in 1 chunk(s)

; chunk at RVA 0xb220a0 (396 bytes)
00b220a0  4883ec68                 sub rsp, 0x68
00b220a4  488b05dd6bfb01           mov rax, qword ptr [rip + 0x1fb6bdd]
00b220ab  4833c4                   xor rax, rsp
00b220ae  4889442450               mov qword ptr [rsp + 0x50], rax
00b220b3  448bc2                   mov r8d, edx
00b220b6  4c8bc9                   mov r9, rcx
00b220b9  4885c9                   test rcx, rcx
00b220bc  751b                     jne 0xb220d9
00b220be  85d2                     test edx, edx
00b220c0  7517                     jne 0xb220d9
00b220c2  b801000000               mov eax, 1
00b220c7  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00b220cc  4833cc                   xor rcx, rsp
00b220cf  e89cef4dff               call 0x1070
00b220d4  4883c468                 add rsp, 0x68
00b220d8  c3                       ret
00b220d9  0fb609                   movzx ecx, byte ptr [rcx]
00b220dc  4183f814                 cmp r8d, 0x14
00b220e0  7522                     jne 0xb22104
00b220e2  80f902                   cmp cl, 2
00b220e5  0f84fd000000             je 0xb221e8
00b220eb  80f909                   cmp cl, 9
00b220ee  751e                     jne 0xb2210e
00b220f0  33c0                     xor eax, eax
00b220f2  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00b220f7  4833cc                   xor rcx, rsp
00b220fa  e871ef4dff               call 0x1070
00b220ff  4883c468                 add rsp, 0x68
00b22103  c3                       ret
00b22104  4183f82c                 cmp r8d, 0x2c
00b22108  0f85da000000             jne 0xb221e8
00b2210e  80f908                   cmp cl, 8
00b22111  0f84d1000000             je 0xb221e8
00b22117  80f90c                   cmp cl, 0xc
00b2211a  0f83c8000000             jae 0xb221e8
00b22120  4180790100               cmp byte ptr [r9 + 1], 0
00b22125  0f85bd000000             jne 0xb221e8
00b2212b  8d41fd                   lea eax, [rcx - 3]
00b2212e  3c01                     cmp al, 1
00b22130  7716                     ja 0xb22148
00b22132  410fb74102               movzx eax, word ptr [r9 + 2]
00b22137  bafe7f0000               mov edx, 0x7ffe
00b2213c  66ffc8                   dec ax
00b2213f  663bc2                   cmp ax, dx
00b22142  0f87a0000000             ja 0xb221e8
00b22148  33c0                     xor eax, eax
00b2214a  0f57c0                   xorps xmm0, xmm0
00b2214d  33d2                     xor edx, edx
00b2214f  4889442440               mov qword ptr [rsp + 0x40], rax
00b22154  4983e802                 sub r8, 2
00b22158  89442448                 mov dword ptr [rsp + 0x48], eax
00b2215c  0f11442420               movups xmmword ptr [rsp + 0x20], xmm0
00b22161  0f11442430               movups xmmword ptr [rsp + 0x30], xmm0
00b22166  83f90b                   cmp ecx, 0xb
00b22169  7762                     ja 0xb221cd
00b2216b  4c8d158ede4dff           lea r10, [rip - 0xb22172]
00b22172  418b8c8afc21b200         mov ecx, dword ptr [r10 + rcx*4 + 0xb221fc]
00b2217a  4903ca                   add rcx, r10
00b2217d  ffe1                     jmp rcx
00b2217f  4983f80e                 cmp r8, 0xe
00b22183  7263                     jb 0xb221e8
00b22185  498d5110                 lea rdx, [r9 + 0x10]
00b22189  4983e80e                 sub r8, 0xe
00b2218d  eb3e                     jmp 0xb221cd
00b2218f  4983f808                 cmp r8, 8
00b22193  7253                     jb 0xb221e8
00b22195  498d510a                 lea rdx, [r9 + 0xa]
00b22199  4983e808                 sub r8, 8
00b2219d  eb2e                     jmp 0xb221cd
00b2219f  4983f816                 cmp r8, 0x16
00b221a3  7243                     jb 0xb221e8
00b221a5  498d5118                 lea rdx, [r9 + 0x18]
00b221a9  4983e816                 sub r8, 0x16
00b221ad  eb1e                     jmp 0xb221cd
00b221af  4983f816                 cmp r8, 0x16
00b221b3  7233                     jb 0xb221e8
00b221b5  4983e816                 sub r8, 0x16
00b221b9  498d5118                 lea rdx, [r9 + 0x18]
00b221bd  eb0e                     jmp 0xb221cd
00b221bf  4983f810                 cmp r8, 0x10
00b221c3  7223                     jb 0xb221e8
00b221c5  4983e810                 sub r8, 0x10
00b221c9  498d5112                 lea rdx, [r9 + 0x12]
00b221cd  4d85c0                   test r8, r8
00b221d0  0f84ecfeffff             je 0xb220c2
00b221d6  488d4c2420               lea rcx, [rsp + 0x20]
00b221db  e8cdb54eff               call 0xd7ad
00b221e0  85c0                     test eax, eax
00b221e2  0f84dafeffff             je 0xb220c2
00b221e8  33c0                     xor eax, eax
00b221ea  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00b221ef  4833cc                   xor rcx, rsp
00b221f2  e879ee4dff               call 0x1070
00b221f7  4883c468                 add rsp, 0x68
00b221fb  c3                       ret
00b221fc  c220b2                   ret 0xb220
00b221ff  007f21                   add byte ptr [rdi + 0x21], bh
00b22202  b200                     mov dl, 0
00b22204  af                       scasd eax, dword ptr [rdi]
00b22205  21b200bf21b2             and dword ptr [rdx - 0x4dde4100], esi
00b2220b  008f21b2009f             add byte ptr [rdi - 0x60ff4ddf], cl
00b22211  21b2009f21b2             and dword ptr [rdx - 0x4dde6100], esi
00b22217  00af21b200cd             add byte ptr [rdi - 0x32ff4ddf], ch
00b2221d  21b200bf21b2             and dword ptr [rdx - 0x4dde4100], esi
00b22223  009f21b200af             add byte ptr [rdi - 0x50ff4ddf], bl
