; CDecompressBatchLoader<Level2Batch,CLevel2Decompressor,CSeekPruneRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x9742f0, 1434 bytes in 3 chunk(s)

; chunk at RVA 0x9742f0 (58 bytes)
009742f0  4c894c2420               mov qword ptr [rsp + 0x20], r9
009742f5  89542410                 mov dword ptr [rsp + 0x10], edx
009742f9  55                       push rbp
009742fa  53                       push rbx
009742fb  4154                     push r12
009742fd  4157                     push r15
009742ff  488d6c24c1               lea rbp, [rsp - 0x3f]
00974304  4881ecd8000000           sub rsp, 0xd8
0097430b  83792002                 cmp dword ptr [rcx + 0x20], 2
0097430f  4d8be0                   mov r12, r8
00974312  448bfa                   mov r15d, edx
00974315  488bd9                   mov rbx, rcx
00974318  7510                     jne 0x97432a
0097431a  33c0                     xor eax, eax
0097431c  4881c4d8000000           add rsp, 0xd8
00974323  415f                     pop r15
00974325  415c                     pop r12
00974327  5b                       pop rbx
00974328  5d                       pop rbp
00974329  c3                       ret

; chunk at RVA 0x97432a (1280 bytes)
0097432a  4889b42410010000         mov qword ptr [rsp + 0x110], rsi
00974332  0f57c0                   xorps xmm0, xmm0
00974335  4889bc24d0000000         mov qword ptr [rsp + 0xd0], rdi
0097433d  0f57c9                   xorps xmm1, xmm1
00974340  33ff                     xor edi, edi
00974342  4c89ac24c8000000         mov qword ptr [rsp + 0xc8], r13
0097434a  32c9                     xor cl, cl
0097434c  4c89b424c0000000         mov qword ptr [rsp + 0xc0], r14
00974354  884d67                   mov byte ptr [rbp + 0x67], cl
00974357  897dc7                   mov dword ptr [rbp - 0x39], edi
0097435a  48897dcf                 mov qword ptr [rbp - 0x31], rdi
0097435e  40887dd7                 mov byte ptr [rbp - 0x29], dil
00974362  660f7f45e7               movdqa xmmword ptr [rbp - 0x19], xmm0
00974367  660f7f4df7               movdqa xmmword ptr [rbp - 9], xmm1
0097436c  660f7f4507               movdqa xmmword ptr [rbp + 7], xmm0
00974371  48897d17                 mov qword ptr [rbp + 0x17], rdi
00974375  c7451f01000000           mov dword ptr [rbp + 0x1f], 1
0097437c  897d87                   mov dword ptr [rbp - 0x79], edi
0097437f  41887c2410               mov byte ptr [r12 + 0x10], dil
00974384  4c8d2d75bc68ff           lea r13, [rip - 0x97438b]
0097438b  4038bbc81d0000           cmp byte ptr [rbx + 0x1dc8], dil
00974392  747e                     je 0x974412
00974394  4c8b83c01d0000           mov r8, qword ptr [rbx + 0x1dc0]
0097439b  33d2                     xor edx, edx
0097439d  498bcc                   mov rcx, r12
009743a0  4088bbc81d0000           mov byte ptr [rbx + 0x1dc8], dil
009743a7  e8f485ffff               call 0x96c9a0
009743ac  488b83c01d0000           mov rax, qword ptr [rbx + 0x1dc0]
009743b3  488d75c7                 lea rsi, [rbp - 0x39]
009743b7  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009743bb  897dc7                   mov dword ptr [rbp - 0x39], edi
009743be  c7458701000000           mov dword ptr [rbp - 0x79], 1
009743c5  ff08                     dec dword ptr [rax]
009743c7  418b1424                 mov edx, dword ptr [r12]
009743cb  498b442408               mov rax, qword ptr [r12 + 8]
009743d0  488945cf                 mov qword ptr [rbp - 0x31], rax
009743d4  498b442420               mov rax, qword ptr [r12 + 0x20]
009743d9  488d0cd0                 lea rcx, [rax + rdx*8]
009743dd  498b442428               mov rax, qword ptr [r12 + 0x28]
009743e2  48894de7                 mov qword ptr [rbp - 0x19], rcx
009743e6  488d0c90                 lea rcx, [rax + rdx*4]
009743ea  498b442430               mov rax, qword ptr [r12 + 0x30]
009743ef  48894def                 mov qword ptr [rbp - 0x11], rcx
009743f3  4088bbc81d0000           mov byte ptr [rbx + 0x1dc8], dil
009743fa  488d0c90                 lea rcx, [rax + rdx*4]
009743fe  b801000000               mov eax, 1
00974403  2bc2                     sub eax, edx
00974405  48894df7                 mov qword ptr [rbp - 9], rcx
00974409  4403f8                   add r15d, eax
0097440c  44897d6f                 mov dword ptr [rbp + 0x6f], r15d
00974410  eb03                     jmp 0x974415
00974412  498bf4                   mov rsi, r12
00974415  397b20                   cmp dword ptr [rbx + 0x20], edi
00974418  0f85b3000000             jne 0x9744d1
0097441e  488b4328                 mov rax, qword ptr [rbx + 0x28]
00974422  488d4b28                 lea rcx, [rbx + 0x28]
00974426  4d8bc1                   mov r8, r9
00974429  48897d8f                 mov qword ptr [rbp - 0x71], rdi
0097442d  488d558f                 lea rdx, [rbp - 0x71]
00974431  897d97                   mov dword ptr [rbp - 0x69], edi
00974434  48897d9f                 mov qword ptr [rbp - 0x61], rdi
00974438  897da7                   mov dword ptr [rbp - 0x59], edi
0097443b  48897daf                 mov qword ptr [rbp - 0x51], rdi
0097443f  897db7                   mov dword ptr [rbp - 0x49], edi
00974442  66897dbb                 mov word ptr [rbp - 0x45], di
00974446  c6456701                 mov byte ptr [rbp + 0x67], 1
0097444a  ff10                     call qword ptr [rax]
0097444c  3dc60e0400               cmp eax, 0x40ec6
00974451  0f8483030000             je 0x9747da
00974457  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
0097445b  8b4597                   mov eax, dword ptr [rbp - 0x69]
0097445e  48898b60090000           mov qword ptr [rbx + 0x960], rcx
00974465  48898b68090000           mov qword ptr [rbx + 0x968], rcx
0097446c  488b4d9f                 mov rcx, qword ptr [rbp - 0x61]
00974470  898358090000             mov dword ptr [rbx + 0x958], eax
00974476  8b45a7                   mov eax, dword ptr [rbp - 0x59]
00974479  48898b300c0000           mov qword ptr [rbx + 0xc30], rcx
00974480  48898b380c0000           mov qword ptr [rbx + 0xc38], rcx
00974487  4889bb50090000           mov qword ptr [rbx + 0x950], rdi
0097448e  6689bb180c0000           mov word ptr [rbx + 0xc18], di
00974495  4889bb100c0000           mov qword ptr [rbx + 0xc10], rdi
0097449c  8983280c0000             mov dword ptr [rbx + 0xc28], eax
009744a2  4889bb200c0000           mov qword ptr [rbx + 0xc20], rdi
009744a9  4889bbac1d0000           mov qword ptr [rbx + 0x1dac], rdi
009744b0  c783b41d000000000101     mov dword ptr [rbx + 0x1db4], 0x1010000
009744ba  c783a81d000001000000     mov dword ptr [rbx + 0x1da8], 1
009744c4  89bba01c0000             mov dword ptr [rbx + 0x1ca0], edi
009744ca  c7432001000000           mov dword ptr [rbx + 0x20], 1
009744d1  488b4330                 mov rax, qword ptr [rbx + 0x30]
009744d5  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
009744dc  4c894608                 mov qword ptr [rsi + 8], r8
009744e0  488b5330                 mov rdx, qword ptr [rbx + 0x30]
009744e4  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
009744eb  8b423c                   mov eax, dword ptr [rdx + 0x3c]
009744ee  83e007                   and eax, 7
009744f1  83f805                   cmp eax, 5
009744f4  7741                     ja 0x974537
009744f6  4898                     cdqe
009744f8  418b8c852c489700         mov ecx, dword ptr [r13 + rax*4 + 0x97482c]
00974500  4903cd                   add rcx, r13
00974503  ffe1                     jmp rcx
00974505  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974509  410f95c6                 setne r14b
0097450d  eb2b                     jmp 0x97453a
0097450f  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974513  410f9dc6                 setge r14b
00974517  eb21                     jmp 0x97453a
00974519  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097451d  410f9ec6                 setle r14b
00974521  eb17                     jmp 0x97453a
00974523  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974527  410f9fc6                 setg r14b
0097452b  eb0d                     jmp 0x97453a
0097452d  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974531  410f9cc6                 setl r14b
00974535  eb03                     jmp 0x97453a
00974537  4532f6                   xor r14b, r14b
0097453a  8b424c                   mov eax, dword ptr [rdx + 0x4c]
0097453d  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00974544  83e007                   and eax, 7
00974547  83f805                   cmp eax, 5
0097454a  7741                     ja 0x97458d
0097454c  4898                     cdqe
0097454e  418b8c8544489700         mov ecx, dword ptr [r13 + rax*4 + 0x974844]
00974556  4903cd                   add rcx, r13
00974559  ffe1                     jmp rcx
0097455b  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097455f  410f95c5                 setne r13b
00974563  eb2b                     jmp 0x974590
00974565  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974569  410f9dc5                 setge r13b
0097456d  eb21                     jmp 0x974590
0097456f  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974573  410f9ec5                 setle r13b
00974577  eb17                     jmp 0x974590
00974579  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097457d  410f9fc5                 setg r13b
00974581  eb0d                     jmp 0x974590
00974583  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974587  410f9cc5                 setl r13b
0097458b  eb03                     jmp 0x974590
0097458d  4532ed                   xor r13b, r13b
00974590  488d8b48090000           lea rcx, [rbx + 0x948]
00974597  4c8bc6                   mov r8, rsi
0097459a  418bd7                   mov edx, r15d
0097459d  e85e95ffff               call 0x96db00
009745a2  84c0                     test al, al
009745a4  7503                     jne 0x9745a9
009745a6  897b20                   mov dword ptr [rbx + 0x20], edi
009745a9  8b16                     mov edx, dword ptr [rsi]
009745ab  448bc2                   mov r8d, edx
009745ae  85d2                     test edx, edx
009745b0  0f84c3010000             je 0x974779
009745b6  4584f6                   test r14b, r14b
009745b9  7509                     jne 0x9745c4
009745bb  4584ed                   test r13b, r13b
009745be  0f84b5010000             je 0x974779
009745c4  448bca                   mov r9d, edx
009745c7  4584f6                   test r14b, r14b
009745ca  0f847f000000             je 0x97464f
009745d0  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
009745d4  448bd7                   mov r10d, edi
009745d7  85d2                     test edx, edx
009745d9  746d                     je 0x974648
009745db  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
009745df  4c8d3d1aba68ff           lea r15, [rip - 0x9745e6]
009745e6  4c8b7620                 mov r14, qword ptr [rsi + 0x20]
009745ea  4183e007                 and r8d, 7
009745ee  6690                     nop
009745f0  418bc2                   mov eax, r10d
009745f3  4d8b0cc6                 mov r9, qword ptr [r14 + rax*8]
009745f7  4183f805                 cmp r8d, 5
009745fb  0f87ad000000             ja 0x9746ae
00974601  4963c0                   movsxd rax, r8d
00974604  418b8c875c489700         mov ecx, dword ptr [r15 + rax*4 + 0x97485c]
0097460c  4903cf                   add rcx, r15
0097460f  ffe1                     jmp rcx
00974611  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974615  0f94c0                   sete al
00974618  eb22                     jmp 0x97463c
0097461a  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
0097461e  0f9cc0                   setl al
00974621  eb19                     jmp 0x97463c
00974623  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974627  0f9fc0                   setg al
0097462a  eb10                     jmp 0x97463c
0097462c  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974630  0f9ec0                   setle al
00974633  eb07                     jmp 0x97463c
00974635  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974639  0f9dc0                   setge al
0097463c  84c0                     test al, al
0097463e  756e                     jne 0x9746ae
00974640  41ffc2                   inc r10d
00974643  443bd2                   cmp r10d, edx
00974646  72a8                     jb 0x9745f0
00974648  893e                     mov dword ptr [rsi], edi
0097464a  8bd7                     mov edx, edi
0097464c  448bcf                   mov r9d, edi
0097464f  458bc1                   mov r8d, r9d
00974652  4584ed                   test r13b, r13b
00974655  0f841e010000             je 0x974779
0097465b  85d2                     test edx, edx
0097465d  0f8416010000             je 0x974779
00974663  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00974667  4c8d2d92b968ff           lea r13, [rip - 0x97466e]
0097466e  4c8b7e20                 mov r15, qword ptr [rsi + 0x20]
00974672  0f1f4000                 nop dword ptr [rax]
00974676  66660f1f840000000000     nop word ptr [rax + rax]
00974680  418b434c                 mov eax, dword ptr [r11 + 0x4c]
00974684  ffca                     dec edx
00974686  458bd1                   mov r10d, r9d
00974689  83e007                   and eax, 7
0097468c  448bca                   mov r9d, edx
0097468f  458bc2                   mov r8d, r10d
00974692  4d8b34d7                 mov r14, qword ptr [r15 + rdx*8]
00974696  83f805                   cmp eax, 5
00974699  0f87da000000             ja 0x974779
0097469f  4898                     cdqe
009746a1  418b8c8574489700         mov ecx, dword ptr [r13 + rax*4 + 0x974874]
009746a9  4903cd                   add rcx, r13
009746ac  ffe1                     jmp rcx
009746ae  443bd2                   cmp r10d, edx
009746b1  7395                     jae 0x974648
009746b3  448bca                   mov r9d, edx
009746b6  4585d2                   test r10d, r10d
009746b9  7494                     je 0x97464f
009746bb  8bd7                     mov edx, edi
009746bd  452bca                   sub r9d, r10d
009746c0  7470                     je 0x974732
009746c2  4c8bc7                   mov r8, rdi
009746c5  4c8bdf                   mov r11, rdi
009746c8  4c8bf7                   mov r14, rdi
009746cb  0f1f440000               nop dword ptr [rax + rax]
009746d0  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
009746d4  428d0412                 lea eax, [rdx + r10]
009746d8  448bf8                   mov r15d, eax
009746db  488b04c1                 mov rax, qword ptr [rcx + rax*8]
009746df  4989040e                 mov qword ptr [r14 + rcx], rax
009746e3  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
009746e7  428b04b9                 mov eax, dword ptr [rcx + r15*4]
009746eb  4189040b                 mov dword ptr [r11 + rcx], eax
009746ef  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
009746f3  428b04b9                 mov eax, dword ptr [rcx + r15*4]
009746f7  4d03ff                   add r15, r15
009746fa  4189040b                 mov dword ptr [r11 + rcx], eax
009746fe  488b4638                 mov rax, qword ptr [rsi + 0x38]
00974702  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00974707  420f110400               movups xmmword ptr [rax + r8], xmm0
0097470c  488b4648                 mov rax, qword ptr [rsi + 0x48]
00974710  4885c0                   test rax, rax
00974713  740a                     je 0x97471f
00974715  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
0097471a  420f110400               movups xmmword ptr [rax + r8], xmm0
0097471f  ffc2                     inc edx
00974721  4983c608                 add r14, 8
00974725  4983c304                 add r11, 4
00974729  4983c010                 add r8, 0x10
0097472d  413bd1                   cmp edx, r9d
00974730  729e                     jb 0x9746d0
00974732  44890e                   mov dword ptr [rsi], r9d
00974735  418bd1                   mov edx, r9d
00974738  e912ffffff               jmp 0x97464f
0097473d  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974741  0f94c0                   sete al
00974744  eb22                     jmp 0x974768
00974746  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
0097474a  0f9cc0                   setl al
0097474d  eb19                     jmp 0x974768
0097474f  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974753  0f9fc0                   setg al
00974756  eb10                     jmp 0x974768
00974758  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
0097475c  0f9ec0                   setle al
0097475f  eb07                     jmp 0x974768
00974761  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974765  0f9dc0                   setge al
00974768  84c0                     test al, al
0097476a  750d                     jne 0x974779
0097476c  8916                     mov dword ptr [rsi], edx
0097476e  448bc2                   mov r8d, edx
00974771  85d2                     test edx, edx
00974773  0f8507ffffff             jne 0x974680
00974779  4038bbc91d0000           cmp byte ptr [rbx + 0x1dc9], dil
00974780  7440                     je 0x9747c2
00974782  448b06                   mov r8d, dword ptr [rsi]
00974785  4585c0                   test r8d, r8d
00974788  7438                     je 0x9747c2
0097478a  488b8bc01d0000           mov rcx, qword ptr [rbx + 0x1dc0]
00974791  4c8bc6                   mov r8, rsi
00974794  c683c81d000001           mov byte ptr [rbx + 0x1dc8], 1
0097479b  8b16                     mov edx, dword ptr [rsi]
0097479d  ffca                     dec edx
0097479f  e8fc81ffff               call 0x96c9a0
009747a4  ff0e                     dec dword ptr [rsi]
009747a6  41c644241001             mov byte ptr [r12 + 0x10], 1
009747ac  488b83c01d0000           mov rax, qword ptr [rbx + 0x1dc0]
009747b3  488b4820                 mov rcx, qword ptr [rax + 0x20]
009747b7  488b01                   mov rax, qword ptr [rcx]
009747ba  4989442418               mov qword ptr [r12 + 0x18], rax
009747bf  448b06                   mov r8d, dword ptr [rsi]
009747c2  8b4587                   mov eax, dword ptr [rbp - 0x79]
009747c5  4103c0                   add eax, r8d
009747c8  894587                   mov dword ptr [rbp - 0x79], eax
009747cb  7520                     jne 0x9747ed
009747cd  448b7d6f                 mov r15d, dword ptr [rbp + 0x6f]
009747d1  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009747d5  e9a5fbffff               jmp 0x97437f
009747da  c7432002000000           mov dword ptr [rbx + 0x20], 2
009747e1  41393c24                 cmp dword ptr [r12], edi
009747e5  400f95c7                 setne dil
009747e9  8bc7                     mov eax, edi
009747eb  eb0f                     jmp 0x9747fc
009747ed  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
009747f1  f6d9                     neg cl
009747f3  41890424                 mov dword ptr [r12], eax
009747f7  1bc0                     sbb eax, eax
009747f9  83c002                   add eax, 2
009747fc  4c8bac24c8000000         mov r13, qword ptr [rsp + 0xc8]
00974804  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
0097480c  488bb42410010000         mov rsi, qword ptr [rsp + 0x110]
00974814  4c8bb424c0000000         mov r14, qword ptr [rsp + 0xc0]
0097481c  4881c4d8000000           add rsp, 0xd8
00974823  415f                     pop r15
00974825  415c                     pop r12
00974827  5b                       pop rbx
00974828  5d                       pop rbp
00974829  c3                       ret

; chunk at RVA 0x97482c (96 bytes)
