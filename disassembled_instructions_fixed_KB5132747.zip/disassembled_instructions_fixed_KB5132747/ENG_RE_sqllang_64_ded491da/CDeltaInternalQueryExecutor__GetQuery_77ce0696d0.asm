; CDeltaInternalQueryExecutor::GetQuery
; sqllang.dll, primary RVA 0x1ae7650, 1996 bytes in 1 chunk(s)

; chunk at RVA 0x1ae7650 (1996 bytes)
01ae7650  4055                     push rbp
01ae7652  53                       push rbx
01ae7653  56                       push rsi
01ae7654  57                       push rdi
01ae7655  4154                     push r12
01ae7657  4155                     push r13
01ae7659  4156                     push r14
01ae765b  4157                     push r15
01ae765d  488d6c24e1               lea rbp, [rsp - 0x1f]
01ae7662  4881eca8000000           sub rsp, 0xa8
01ae7669  48c745fffeffffff         mov qword ptr [rbp - 1], 0xfffffffffffffffe
01ae7671  4c8be1                   mov r12, rcx
01ae7674  4533c9                   xor r9d, r9d
01ae7677  44894d6f                 mov dword ptr [rbp + 0x6f], r9d
01ae767b  488b050e16ff00           mov rax, qword ptr [rip + 0xff160e]
01ae7682  44380dc0e7ff00           cmp byte ptr [rip + 0xffe7c0], r9b
01ae7689  740d                     je 0x1ae7698
01ae768b  f680df06000002           test byte ptr [rax + 0x6df], 2
01ae7692  7504                     jne 0x1ae7698
01ae7694  b201                     mov dl, 1
01ae7696  eb02                     jmp 0x1ae769a
01ae7698  32d2                     xor dl, dl
01ae769a  885567                   mov byte ptr [rbp + 0x67], dl
01ae769d  44380da9e7ff00           cmp byte ptr [rip + 0xffe7a9], r9b
01ae76a4  410f95c7                 setne r15b
01ae76a8  44380d50e7ff00           cmp byte ptr [rip + 0xffe750], r9b
01ae76af  750d                     jne 0x1ae76be
01ae76b1  443888e9040000           cmp byte ptr [rax + 0x4e9], r9b
01ae76b8  7c04                     jl 0x1ae76be
01ae76ba  32c0                     xor al, al
01ae76bc  eb02                     jmp 0x1ae76c0
01ae76be  b001                     mov al, 1
01ae76c0  498bf1                   mov rsi, r9
01ae76c3  4c894d7f                 mov qword ptr [rbp + 0x7f], r9
01ae76c7  4c894def                 mov qword ptr [rbp - 0x11], r9
01ae76cb  4d8bf1                   mov r14, r9
01ae76ce  4c894dcf                 mov qword ptr [rbp - 0x31], r9
01ae76d2  4c894de7                 mov qword ptr [rbp - 0x19], r9
01ae76d6  498bf9                   mov rdi, r9
01ae76d9  4c894df7                 mov qword ptr [rbp - 9], r9
01ae76dd  4d8be9                   mov r13, r9
01ae76e0  4c894d07                 mov qword ptr [rbp + 7], r9
01ae76e4  4c8b81a0000000           mov r8, qword ptr [rcx + 0xa0]
01ae76eb  418b4820                 mov ecx, dword ptr [r8 + 0x20]
01ae76ef  83f90b                   cmp ecx, 0xb
01ae76f2  0f87d3000000             ja 0x1ae77cb
01ae76f8  41b96d0d0000             mov r9d, 0xd6d
01ae76fe  410fa3c9                 bt r9d, ecx
01ae7702  0f83c0000000             jae 0x1ae77c8
01ae7708  84d2                     test dl, dl
01ae770a  7409                     je 0x1ae7715
01ae770c  84c0                     test al, al
01ae770e  bb01000000               mov ebx, 1
01ae7713  7405                     je 0x1ae771a
01ae7715  bb02000000               mov ebx, 2
01ae771a  895d6f                   mov dword ptr [rbp + 0x6f], ebx
01ae771d  c644242800               mov byte ptr [rsp + 0x28], 0
01ae7722  488d45ef                 lea rax, [rbp - 0x11]
01ae7726  4889442420               mov qword ptr [rsp + 0x20], rax
01ae772b  4c8d4d7f                 lea r9, [rbp + 0x7f]
01ae772f  4d8b4010                 mov r8, qword ptr [r8 + 0x10]
01ae7733  8bd3                     mov edx, ebx
01ae7735  498bcc                   mov rcx, r12
01ae7738  e8f3060000               call 0x1ae7e30
01ae773d  85c0                     test eax, eax
01ae773f  7927                     jns 0x1ae7768
01ae7741  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae774a  41b976000000             mov r9d, 0x76
01ae7750  4c8d05a9d0a200           lea r8, [rip + 0xa2d0a9]
01ae7757  488d15a2eea200           lea rdx, [rip + 0xa2eea2]
01ae775e  418d498b                 lea ecx, [r9 - 0x75]
01ae7762  ff1510373e00             call qword ptr [rip + 0x3e3710]
01ae7768  4584ff                   test r15b, r15b
01ae776b  7457                     je 0x1ae77c4
01ae776d  4d8b8424a0000000         mov r8, qword ptr [r12 + 0xa0]
01ae7775  c644242801               mov byte ptr [rsp + 0x28], 1
01ae777a  488d45e7                 lea rax, [rbp - 0x19]
01ae777e  4889442420               mov qword ptr [rsp + 0x20], rax
01ae7783  4c8d4dcf                 lea r9, [rbp - 0x31]
01ae7787  4d8b4010                 mov r8, qword ptr [r8 + 0x10]
01ae778b  8bd3                     mov edx, ebx
01ae778d  498bcc                   mov rcx, r12
01ae7790  e89b060000               call 0x1ae7e30
01ae7795  85c0                     test eax, eax
01ae7797  7927                     jns 0x1ae77c0
01ae7799  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae77a2  41b980000000             mov r9d, 0x80
01ae77a8  4c8d0551d0a200           lea r8, [rip + 0xa2d051]
01ae77af  488d154aeea200           lea rdx, [rip + 0xa2ee4a]
01ae77b6  418d4981                 lea ecx, [r9 - 0x7f]
01ae77ba  ff15b8363e00             call qword ptr [rip + 0x3e36b8]
01ae77c0  4c8b75cf                 mov r14, qword ptr [rbp - 0x31]
01ae77c4  488b757f                 mov rsi, qword ptr [rbp + 0x7f]
01ae77c8  4533c9                   xor r9d, r9d
01ae77cb  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae77d3  8b4220                   mov eax, dword ptr [rdx + 0x20]
01ae77d6  48c7c3ffffffff           mov rbx, 0xffffffffffffffff
01ae77dd  83f80b                   cmp eax, 0xb
01ae77e0  0f87c5010000             ja 0x1ae79ab
01ae77e6  b9b60b0000               mov ecx, 0xbb6
01ae77eb  0fa3c1                   bt ecx, eax
01ae77ee  0f83b7010000             jae 0x1ae79ab
01ae77f4  488b5218                 mov rdx, qword ptr [rdx + 0x18]
01ae77f8  4c894ddf                 mov qword ptr [rbp - 0x21], r9
01ae77fc  4c894d77                 mov qword ptr [rbp + 0x77], r9
01ae7800  4c8d4d77                 lea r9, [rbp + 0x77]
01ae7804  4c8d45df                 lea r8, [rbp - 0x21]
01ae7808  498bcc                   mov rcx, r12
01ae780b  e8e0080000               call 0x1ae80f0
01ae7810  4533ed                   xor r13d, r13d
01ae7813  4d8bbc2490000000         mov r15, qword ptr [r12 + 0x90]
01ae781b  4d85ff                   test r15, r15
01ae781e  7509                     jne 0x1ae7829
01ae7820  4c8d3d51115700           lea r15, [rip + 0x571151]
01ae7827  eb14                     jmp 0x1ae783d
01ae7829  488bc3                   mov rax, rbx
01ae782c  0f1f4000                 nop dword ptr [rax]
01ae7830  48ffc0                   inc rax
01ae7833  6645392c47               cmp word ptr [r15 + rax*2], r13w
01ae7838  75f6                     jne 0x1ae7830
01ae783a  448be8                   mov r13d, eax
01ae783d  498b8424a8000000         mov rax, qword ptr [r12 + 0xa8]
01ae7845  488b5030                 mov rdx, qword ptr [rax + 0x30]
01ae7849  488955d7                 mov qword ptr [rbp - 0x29], rdx
01ae784d  488d0d24115700           lea rcx, [rip + 0x571124]
01ae7854  4885d2                   test rdx, rdx
01ae7857  480f45ca                 cmovne rcx, rdx
01ae785b  488bc3                   mov rax, rbx
01ae785e  6690                     nop
01ae7860  48ffc0                   inc rax
01ae7863  66833c4100               cmp word ptr [rcx + rax*2], 0
01ae7868  75f6                     jne 0x1ae7860
01ae786a  8bc0                     mov eax, eax
01ae786c  488945c7                 mov qword ptr [rbp - 0x39], rax
01ae7870  bf09000000               mov edi, 9
01ae7875  8d47fd                   lea eax, [rdi - 3]
01ae7878  4180bc24b000000000       cmp byte ptr [r12 + 0xb0], 0
01ae7881  740a                     je 0x1ae788d
01ae7883  8bdf                     mov ebx, edi
01ae7885  4885d2                   test rdx, rdx
01ae7888  0f45d8                   cmovne ebx, eax
01ae788b  eb05                     jmp 0x1ae7892
01ae788d  bb03000000               mov ebx, 3
01ae7892  488d05678751fe           lea rax, [rip - 0x1ae7899]
01ae7899  488b9cd8604b2c02         mov rbx, qword ptr [rax + rbx*8 + 0x22c4b60]
01ae78a1  498b0424                 mov rax, qword ptr [r12]
01ae78a5  33d2                     xor edx, edx
01ae78a7  498bcc                   mov rcx, r12
01ae78aa  ff9000020000             call qword ptr [rax + 0x200]
01ae78b0  410fb68c24b0000000       movzx ecx, byte ptr [r12 + 0xb0]
01ae78b9  84c9                     test cl, cl
01ae78bb  4c0f456dc7               cmovne r13, qword ptr [rbp - 0x39]
01ae78c0  4c03e8                   add r13, rax
01ae78c3  4c03eb                   add r13, rbx
01ae78c6  4c036d77                 add r13, qword ptr [rbp + 0x77]
01ae78ca  488b5dd7                 mov rbx, qword ptr [rbp - 0x29]
01ae78ce  84c9                     test cl, cl
01ae78d0  740e                     je 0x1ae78e0
01ae78d2  4885db                   test rbx, rbx
01ae78d5  b806000000               mov eax, 6
01ae78da  480f45f8                 cmovne rdi, rax
01ae78de  eb05                     jmp 0x1ae78e5
01ae78e0  bf03000000               mov edi, 3
01ae78e5  488d05148751fe           lea rax, [rip - 0x1ae78ec]
01ae78ec  488b84f8004c2c02         mov rax, qword ptr [rax + rdi*8 + 0x22c4c00]
01ae78f4  48894577                 mov qword ptr [rbp + 0x77], rax
01ae78f8  b802000000               mov eax, 2
01ae78fd  49f7e5                   mul r13
01ae7900  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
01ae7907  480f40c1                 cmovo rax, rcx
01ae790b  c644242006               mov byte ptr [rsp + 0x20], 6
01ae7910  41b937010000             mov r9d, 0x137
01ae7916  4c8d0543eea100           lea r8, [rip + 0xa1ee43]
01ae791d  498b542440               mov rdx, qword ptr [r12 + 0x40]
01ae7922  488bc8                   mov rcx, rax
01ae7925  ff15cd353e00             call qword ptr [rip + 0x3e35cd]
01ae792b  488bf8                   mov rdi, rax
01ae792e  4885c0                   test rax, rax
01ae7931  7408                     je 0x1ae793b
01ae7933  33c9                     xor ecx, ecx
01ae7935  ff156d363e00             call qword ptr [rip + 0x3e366d]
01ae793b  48897df7                 mov qword ptr [rbp - 9], rdi
01ae793f  4180bc24b000000000       cmp byte ptr [r12 + 0xb0], 0
01ae7948  4c0f45fb                 cmovne r15, rbx
01ae794c  ff1596343e00             call qword ptr [rip + 0x3e3496]
01ae7952  4c8bc8                   mov r9, rax
01ae7955  4c897c2428               mov qword ptr [rsp + 0x28], r15
01ae795a  488b5ddf                 mov rbx, qword ptr [rbp - 0x21]
01ae795e  48895c2420               mov qword ptr [rsp + 0x20], rbx
01ae7963  4c8b4577                 mov r8, qword ptr [rbp + 0x77]
01ae7967  498bd5                   mov rdx, r13
01ae796a  488bcf                   mov rcx, rdi
01ae796d  e82ec556fe               call 0x53ea0
01ae7972  448bf8                   mov r15d, eax
01ae7975  488bcb                   mov rcx, rbx
01ae7978  ff152a363e00             call qword ptr [rip + 0x3e362a]
01ae797e  4585ff                   test r15d, r15d
01ae7981  7928                     jns 0x1ae79ab
01ae7983  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae798c  41b992000000             mov r9d, 0x92
01ae7992  4c8d0567cea200           lea r8, [rip + 0xa2ce67]
01ae7999  488d1560eca200           lea rdx, [rip + 0xa2ec60]
01ae79a0  b901000000               mov ecx, 1
01ae79a5  ff15cd343e00             call qword ptr [rip + 0x3e34cd]
01ae79ab  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
01ae79b4  8b05dae7ff00             mov eax, dword ptr [rip + 0xffe7da]
01ae79ba  ba04000000               mov edx, 4
01ae79bf  488b04c1                 mov rax, qword ptr [rcx + rax*8]
01ae79c3  8b0c02                   mov ecx, dword ptr [rdx + rax]
01ae79c6  390d9cd21b01             cmp dword ptr [rip + 0x11bd29c], ecx
01ae79cc  7e2c                     jle 0x1ae79fa
01ae79ce  488d0d93d21b01           lea rcx, [rip + 0x11bd293]
01ae79d5  e8c2d560fe               call 0xf4f9c
01ae79da  833d87d21b01ff           cmp dword ptr [rip + 0x11bd287], -1
01ae79e1  7517                     jne 0x1ae79fa
01ae79e3  48c70582d21b011b000000   mov qword ptr [rip + 0x11bd282], 0x1b
01ae79ee  488d0d73d21b01           lea rcx, [rip + 0x11bd273]
01ae79f5  e8d6a086fe               call 0x351ad0
01ae79fa  33db                     xor ebx, ebx
01ae79fc  0fb64567                 movzx eax, byte ptr [rbp + 0x67]
01ae7a00  84c0                     test al, al
01ae7a02  480f451d66d21b01         cmovne rbx, qword ptr [rip + 0x11bd266]
01ae7a0a  4c8d3d47eca100           lea r15, [rip + 0xa1ec47]
01ae7a11  488d05600f5700           lea rax, [rip + 0x570f60]
01ae7a18  4c0f44f8                 cmove r15, rax
01ae7a1c  4c897d77                 mov qword ptr [rbp + 0x77], r15
01ae7a20  4d8b0424                 mov r8, qword ptr [r12]
01ae7a24  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae7a2c  498bcc                   mov rcx, r12
01ae7a2f  41ff90d0010000           call qword ptr [r8 + 0x1d0]
01ae7a36  4803c3                   add rax, rbx
01ae7a39  4903c5                   add rax, r13
01ae7a3c  480345e7                 add rax, qword ptr [rbp - 0x19]
01ae7a40  488b4def                 mov rcx, qword ptr [rbp - 0x11]
01ae7a44  48ffc1                   inc rcx
01ae7a47  4803c8                   add rcx, rax
01ae7a4a  48894d67                 mov qword ptr [rbp + 0x67], rcx
01ae7a4e  b802000000               mov eax, 2
01ae7a53  48f7e1                   mul rcx
01ae7a56  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
01ae7a5d  480f40c1                 cmovo rax, rcx
01ae7a61  c644242006               mov byte ptr [rsp + 0x20], 6
01ae7a66  41b99e000000             mov r9d, 0x9e
01ae7a6c  4c8d05edeca100           lea r8, [rip + 0xa1eced]
01ae7a73  498b542440               mov rdx, qword ptr [r12 + 0x40]
01ae7a78  488bc8                   mov rcx, rax
01ae7a7b  ff1577343e00             call qword ptr [rip + 0x3e3477]
01ae7a81  4c8be8                   mov r13, rax
01ae7a84  488945c7                 mov qword ptr [rbp - 0x39], rax
01ae7a88  498b8c24a0000000         mov rcx, qword ptr [r12 + 0xa0]
01ae7a90  48634120                 movsxd rax, dword ptr [rcx + 0x20]
01ae7a94  83f80b                   cmp eax, 0xb
01ae7a97  0f87d9020000             ja 0x1ae7d76
01ae7a9d  488bc8                   mov rcx, rax
01ae7aa0  488d05598551fe           lea rax, [rip - 0x1ae7aa7]
01ae7aa7  8b9488ec7dae01           mov edx, dword ptr [rax + rcx*4 + 0x1ae7dec]
01ae7aae  4803d0                   add rdx, rax
01ae7ab1  ffe2                     jmp rdx
01ae7ab3  488d05feeba100           lea rax, [rip + 0xa1ebfe]
01ae7aba  4c8d3d37ad6300           lea r15, [rip + 0x63ad37]
01ae7ac1  837d6f01                 cmp dword ptr [rbp + 0x6f], 1
01ae7ac5  4c0f44f8                 cmove r15, rax
01ae7ac9  ff1519333e00             call qword ptr [rip + 0x3e3319]
01ae7acf  488bd8                   mov rbx, rax
01ae7ad2  4d8b0424                 mov r8, qword ptr [r12]
01ae7ad6  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae7ade  498bcc                   mov rcx, r12
01ae7ae1  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae7ae8  4c8bc0                   mov r8, rax
01ae7aeb  488b4577                 mov rax, qword ptr [rbp + 0x77]
01ae7aef  4889442430               mov qword ptr [rsp + 0x30], rax
01ae7af4  4c897c2428               mov qword ptr [rsp + 0x28], r15
01ae7af9  4889742420               mov qword ptr [rsp + 0x20], rsi
01ae7afe  4c8bcb                   mov r9, rbx
01ae7b01  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae7b05  498bcd                   mov rcx, r13
01ae7b08  e893c356fe               call 0x53ea0
01ae7b0d  85c0                     test eax, eax
01ae7b0f  0f8989020000             jns 0x1ae7d9e
01ae7b15  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae7b1e  41b9ad000000             mov r9d, 0xad
01ae7b24  4c8d05d5cca200           lea r8, [rip + 0xa2ccd5]
01ae7b2b  488d15ceeaa200           lea rdx, [rip + 0xa2eace]
01ae7b32  b901000000               mov ecx, 1
01ae7b37  ff153b333e00             call qword ptr [rip + 0x3e333b]
01ae7b3d  e95c020000               jmp 0x1ae7d9e
01ae7b42  488d056feba100           lea rax, [rip + 0xa1eb6f]
01ae7b49  4c8d3da8ac6300           lea r15, [rip + 0x63aca8]
01ae7b50  837d6f01                 cmp dword ptr [rbp + 0x6f], 1
01ae7b54  4c0f44f8                 cmove r15, rax
01ae7b58  ff158a323e00             call qword ptr [rip + 0x3e328a]
01ae7b5e  488bd8                   mov rbx, rax
01ae7b61  4d8b0424                 mov r8, qword ptr [r12]
01ae7b65  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae7b6d  498bcc                   mov rcx, r12
01ae7b70  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae7b77  4c8bc0                   mov r8, rax
01ae7b7a  488b4577                 mov rax, qword ptr [rbp + 0x77]
01ae7b7e  4889442440               mov qword ptr [rsp + 0x40], rax
01ae7b83  4c897c2438               mov qword ptr [rsp + 0x38], r15
01ae7b88  4c89742430               mov qword ptr [rsp + 0x30], r14
01ae7b8d  4c897c2428               mov qword ptr [rsp + 0x28], r15
01ae7b92  4889742420               mov qword ptr [rsp + 0x20], rsi
01ae7b97  4c8bcb                   mov r9, rbx
01ae7b9a  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae7b9e  498bcd                   mov rcx, r13
01ae7ba1  e8fac256fe               call 0x53ea0
01ae7ba6  85c0                     test eax, eax
01ae7ba8  0f89f0010000             jns 0x1ae7d9e
01ae7bae  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae7bb7  41b9bc000000             mov r9d, 0xbc
01ae7bbd  4c8d053ccca200           lea r8, [rip + 0xa2cc3c]
01ae7bc4  488d1535eaa200           lea rdx, [rip + 0xa2ea35]
01ae7bcb  b901000000               mov ecx, 1
01ae7bd0  ff15a2323e00             call qword ptr [rip + 0x3e32a2]
01ae7bd6  e9c3010000               jmp 0x1ae7d9e
01ae7bdb  ff1507323e00             call qword ptr [rip + 0x3e3207]
01ae7be1  488bd8                   mov rbx, rax
01ae7be4  4d8b0424                 mov r8, qword ptr [r12]
01ae7be8  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae7bf0  498bcc                   mov rcx, r12
01ae7bf3  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae7bfa  4c8bc0                   mov r8, rax
01ae7bfd  4c897c2428               mov qword ptr [rsp + 0x28], r15
01ae7c02  48897c2420               mov qword ptr [rsp + 0x20], rdi
01ae7c07  4c8bcb                   mov r9, rbx
01ae7c0a  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae7c0e  498bcd                   mov rcx, r13
01ae7c11  e88ac256fe               call 0x53ea0
01ae7c16  85c0                     test eax, eax
01ae7c18  0f8980010000             jns 0x1ae7d9e
01ae7c1e  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae7c27  41b9ca000000             mov r9d, 0xca
01ae7c2d  4c8d05cccba200           lea r8, [rip + 0xa2cbcc]
01ae7c34  488d15c5e9a200           lea rdx, [rip + 0xa2e9c5]
01ae7c3b  b901000000               mov ecx, 1
01ae7c40  ff1532323e00             call qword ptr [rip + 0x3e3232]
01ae7c46  e953010000               jmp 0x1ae7d9e
01ae7c4b  488d0566eaa100           lea rax, [rip + 0xa1ea66]
01ae7c52  4c8d3d9fab6300           lea r15, [rip + 0x63ab9f]
01ae7c59  837d6f01                 cmp dword ptr [rbp + 0x6f], 1
01ae7c5d  4c0f44f8                 cmove r15, rax
01ae7c61  ff1581313e00             call qword ptr [rip + 0x3e3181]
01ae7c67  488bd8                   mov rbx, rax
01ae7c6a  4d8b0424                 mov r8, qword ptr [r12]
01ae7c6e  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae7c76  498bcc                   mov rcx, r12
01ae7c79  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae7c80  4c8bc0                   mov r8, rax
01ae7c83  488b4577                 mov rax, qword ptr [rbp + 0x77]
01ae7c87  4889442438               mov qword ptr [rsp + 0x38], rax
01ae7c8c  4c897c2430               mov qword ptr [rsp + 0x30], r15
01ae7c91  4889742428               mov qword ptr [rsp + 0x28], rsi
01ae7c96  48897c2420               mov qword ptr [rsp + 0x20], rdi
01ae7c9b  4c8bcb                   mov r9, rbx
01ae7c9e  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae7ca2  498bcd                   mov rcx, r13
01ae7ca5  e8f6c156fe               call 0x53ea0
01ae7caa  85c0                     test eax, eax
01ae7cac  0f89ec000000             jns 0x1ae7d9e
01ae7cb2  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae7cbb  41b9d8000000             mov r9d, 0xd8
01ae7cc1  4c8d0538cba200           lea r8, [rip + 0xa2cb38]
01ae7cc8  488d1531e9a200           lea rdx, [rip + 0xa2e931]
01ae7ccf  b901000000               mov ecx, 1
01ae7cd4  ff159e313e00             call qword ptr [rip + 0x3e319e]
01ae7cda  e9bf000000               jmp 0x1ae7d9e
01ae7cdf  488d05d2e9a100           lea rax, [rip + 0xa1e9d2]
01ae7ce6  4c8d3d0bab6300           lea r15, [rip + 0x63ab0b]
01ae7ced  837d6f01                 cmp dword ptr [rbp + 0x6f], 1
01ae7cf1  4c0f44f8                 cmove r15, rax
01ae7cf5  ff15ed303e00             call qword ptr [rip + 0x3e30ed]
01ae7cfb  488bd8                   mov rbx, rax
01ae7cfe  4d8b0424                 mov r8, qword ptr [r12]
01ae7d02  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae7d0a  498bcc                   mov rcx, r12
01ae7d0d  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae7d14  4c8bc0                   mov r8, rax
01ae7d17  488b4577                 mov rax, qword ptr [rbp + 0x77]
01ae7d1b  4889442448               mov qword ptr [rsp + 0x48], rax
01ae7d20  4c897c2440               mov qword ptr [rsp + 0x40], r15
01ae7d25  4c89742438               mov qword ptr [rsp + 0x38], r14
01ae7d2a  4c897c2430               mov qword ptr [rsp + 0x30], r15
01ae7d2f  4889742428               mov qword ptr [rsp + 0x28], rsi
01ae7d34  48897c2420               mov qword ptr [rsp + 0x20], rdi
01ae7d39  4c8bcb                   mov r9, rbx
01ae7d3c  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae7d40  498bcd                   mov rcx, r13
01ae7d43  e858c156fe               call 0x53ea0
01ae7d48  85c0                     test eax, eax
01ae7d4a  7952                     jns 0x1ae7d9e
01ae7d4c  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae7d55  41b9e8000000             mov r9d, 0xe8
01ae7d5b  4c8d059ecaa200           lea r8, [rip + 0xa2ca9e]
01ae7d62  488d1597e8a200           lea rdx, [rip + 0xa2e897]
01ae7d69  b901000000               mov ecx, 1
01ae7d6e  ff1504313e00             call qword ptr [rip + 0x3e3104]
01ae7d74  eb28                     jmp 0x1ae7d9e
01ae7d76  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae7d7f  41b9ec000000             mov r9d, 0xec
01ae7d85  4c8d0574caa200           lea r8, [rip + 0xa2ca74]
01ae7d8c  488d15b5cca200           lea rdx, [rip + 0xa2ccb5]
01ae7d93  b901000000               mov ecx, 1
01ae7d98  ff15da303e00             call qword ptr [rip + 0x3e30da]
01ae7d9e  48c745c700000000         mov qword ptr [rbp - 0x39], 0
01ae7da6  33c9                     xor ecx, ecx
01ae7da8  ff15fa313e00             call qword ptr [rip + 0x3e31fa]
01ae7dae  90                       nop
01ae7daf  33c9                     xor ecx, ecx
01ae7db1  ff15f1313e00             call qword ptr [rip + 0x3e31f1]
01ae7db7  90                       nop
01ae7db8  488bcf                   mov rcx, rdi
01ae7dbb  ff15e7313e00             call qword ptr [rip + 0x3e31e7]
01ae7dc1  90                       nop
01ae7dc2  498bce                   mov rcx, r14
01ae7dc5  ff15dd313e00             call qword ptr [rip + 0x3e31dd]
01ae7dcb  90                       nop
01ae7dcc  488bce                   mov rcx, rsi
01ae7dcf  ff15d3313e00             call qword ptr [rip + 0x3e31d3]
01ae7dd5  498bc5                   mov rax, r13
01ae7dd8  4881c4a8000000           add rsp, 0xa8
01ae7ddf  415f                     pop r15
01ae7de1  415e                     pop r14
01ae7de3  415d                     pop r13
01ae7de5  415c                     pop r12
01ae7de7  5f                       pop rdi
01ae7de8  5e                       pop rsi
01ae7de9  5b                       pop rbx
01ae7dea  5d                       pop rbp
01ae7deb  c3                       ret
01ae7dec  b37a                     mov bl, 0x7a
01ae7dee  ae                       scasb al, byte ptr [rdi]
01ae7def  01db                     add ebx, ebx
01ae7df1  7bae                     jnp 0x1ae7da1
01ae7df3  014b7c                   add dword ptr [rbx + 0x7c], ecx
01ae7df6  ae                       scasb al, byte ptr [rdi]
01ae7df7  01b37aae01db             add dword ptr [rbx - 0x24fe5186], esi
01ae7dfd  7bae                     jnp 0x1ae7dad
01ae7dff  014b7c                   add dword ptr [rbx + 0x7c], ecx
01ae7e02  ae                       scasb al, byte ptr [rdi]
01ae7e03  01427b                   add dword ptr [rdx + 0x7b], eax
01ae7e06  ae                       scasb al, byte ptr [rdi]
01ae7e07  01db                     add ebx, ebx
01ae7e09  7bae                     jnp 0x1ae7db9
01ae7e0b  01df                     add edi, ebx
01ae7e0d  7cae                     jl 0x1ae7dbd
01ae7e0f  01db                     add ebx, ebx
01ae7e11  7bae                     jnp 0x1ae7dc1
01ae7e13  01427b                   add dword ptr [rdx + 0x7b], eax
01ae7e16  ae                       scasb al, byte ptr [rdi]
01ae7e17  01df                     add edi, ebx
01ae7e19  7cae                     jl 0x1ae7dc9
