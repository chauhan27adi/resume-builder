; CCardUtilTsEs::PxvarConvert
; sqllang.dll, primary RVA 0x19365c0, 875 bytes in 1 chunk(s)

; chunk at RVA 0x19365c0 (875 bytes)
019365c0  4c894c2420               mov qword ptr [rsp + 0x20], r9
019365c5  4c89442418               mov qword ptr [rsp + 0x18], r8
019365ca  4889542410               mov qword ptr [rsp + 0x10], rdx
019365cf  48894c2408               mov qword ptr [rsp + 8], rcx
019365d4  53                       push rbx
019365d5  56                       push rsi
019365d6  57                       push rdi
019365d7  4154                     push r12
019365d9  4155                     push r13
019365db  4156                     push r14
019365dd  4157                     push r15
019365df  4881ece0000000           sub rsp, 0xe0
019365e6  48c7842488000000feffffff mov qword ptr [rsp + 0x88], 0xfffffffffffffffe
019365f2  498bf1                   mov rsi, r9
019365f5  4d8bf0                   mov r14, r8
019365f8  4c8bea                   mov r13, rdx
019365fb  4c8bc9                   mov r9, rcx
019365fe  4c8ba42440010000         mov r12, qword ptr [rsp + 0x140]
01936606  488d1df3996cfe           lea rbx, [rip - 0x193660d]
0193660d  4d85e4                   test r12, r12
01936610  0f8591000000             jne 0x19366a7
01936616  b9ffff0000               mov ecx, 0xffff
0193661b  6641394810               cmp word ptr [r8 + 0x10], cx
01936620  7431                     je 0x1936653
01936622  410fb600                 movzx eax, byte ptr [r8]
01936626  0fb68418403b0202         movzx eax, byte ptr [rax + rbx + 0x2023b40]
0193662e  4438a418e812b002         cmp byte ptr [rax + rbx + 0x2b012e8], r12b
01936636  751b                     jne 0x1936653
01936638  66394e10                 cmp word ptr [rsi + 0x10], cx
0193663c  7415                     je 0x1936653
0193663e  0fb606                   movzx eax, byte ptr [rsi]
01936641  0fb68c18403b0202         movzx ecx, byte ptr [rax + rbx + 0x2023b40]
01936649  4438a419e812b002         cmp byte ptr [rcx + rbx + 0x2b012e8], r12b
01936651  7454                     je 0x19366a7
01936653  65488b142558000000       mov rdx, qword ptr gs:[0x58]
0193665c  488b0515495900           mov rax, qword ptr [rip + 0x594915]
01936663  8b08                     mov ecx, dword ptr [rax]
01936665  488b0514495900           mov rax, qword ptr [rip + 0x594914]
0193666c  8b00                     mov eax, dword ptr [rax]
0193666e  480304ca                 add rax, qword ptr [rdx + rcx*8]
01936672  488b00                   mov rax, qword ptr [rax]
01936675  488bb880000000           mov rdi, qword ptr [rax + 0x80]
0193667c  4c8ba720010000           mov r12, qword ptr [rdi + 0x120]
01936683  4d85e4                   test r12, r12
01936686  751f                     jne 0x19366a7
01936688  488b8710010000           mov rax, qword ptr [rdi + 0x110]
0193668f  488d8f10010000           lea rcx, [rdi + 0x110]
01936696  ff10                     call qword ptr [rax]
01936698  4c8ba720010000           mov r12, qword ptr [rdi + 0x120]
0193669f  4c8b8c2420010000         mov r9, qword ptr [rsp + 0x120]
019366a7  4d8bc6                   mov r8, r14
019366aa  498bd5                   mov rdx, r13
019366ad  498bc9                   mov rcx, r9
019366b0  e8bb5788fe               call 0x1bbe70
019366b5  4889842440010000         mov qword ptr [rsp + 0x140], rax
019366bd  33d2                     xor edx, edx
019366bf  4533ff                   xor r15d, r15d
019366c2  4c897c2428               mov qword ptr [rsp + 0x28], r15
019366c7  488d05329172fe           lea rax, [rip - 0x18d6ece]
019366ce  4889442420               mov qword ptr [rsp + 0x20], rax
019366d3  4533c9                   xor r9d, r9d
019366d6  4533c0                   xor r8d, r8d
019366d9  488d8c24b8000000         lea rcx, [rsp + 0xb8]
019366e1  e83ab56cfe               call 0x1c20
019366e6  90                       nop
019366e7  418bc7                   mov eax, r15d
019366ea  89442460                 mov dword ptr [rsp + 0x60], eax
019366ee  41803e2b                 cmp byte ptr [r14], 0x2b
019366f2  750f                     jne 0x1936703
019366f4  bf01000000               mov edi, 1
019366f9  803e2b                   cmp byte ptr [rsi], 0x2b
019366fc  0f45c7                   cmovne eax, edi
019366ff  89442460                 mov dword ptr [rsp + 0x60], eax
01936703  4c89642458               mov qword ptr [rsp + 0x58], r12
01936708  c644245000               mov byte ptr [rsp + 0x50], 0
0193670d  c644244800               mov byte ptr [rsp + 0x48], 0
01936712  c644244000               mov byte ptr [rsp + 0x40], 0
01936717  c644243800               mov byte ptr [rsp + 0x38], 0
0193671c  89442430                 mov dword ptr [rsp + 0x30], eax
01936720  488b842420010000         mov rax, qword ptr [rsp + 0x120]
01936728  4889442428               mov qword ptr [rsp + 0x28], rax
0193672d  44897c2420               mov dword ptr [rsp + 0x20], r15d
01936732  4533c9                   xor r9d, r9d
01936735  4c8bc6                   mov r8, rsi
01936738  498bd6                   mov rdx, r14
0193673b  488b8c2440010000         mov rcx, qword ptr [rsp + 0x140]
01936743  ff154f555900             call qword ptr [rip + 0x59554f]
01936749  448be0                   mov r12d, eax
0193674c  83f801                   cmp eax, 1
0193674f  0f858b000000             jne 0x19367e0
01936755  0fb63e                   movzx edi, byte ptr [rsi]
01936758  400fb6cf                 movzx ecx, dil
0193675c  ff156e4f5900             call qword ptr [rip + 0x594f6e]
01936762  84c0                     test al, al
01936764  0f8481000000             je 0x19367eb
0193676a  4080ff3e                 cmp dil, 0x3e
0193676e  747b                     je 0x19367eb
01936770  4080ef28                 sub dil, 0x28
01936774  4080ff03                 cmp dil, 3
01936778  7671                     jbe 0x19367eb
0193677a  0fb606                   movzx eax, byte ptr [rsi]
0193677d  6644897c246a             mov word ptr [rsp + 0x6a], r15w
01936783  c644246803               mov byte ptr [rsp + 0x68], 3
01936788  88442469                 mov byte ptr [rsp + 0x69], al
0193678c  4c897c2470               mov qword ptr [rsp + 0x70], r15
01936791  4c897c2478               mov qword ptr [rsp + 0x78], r15
01936796  4489bc2480000000         mov dword ptr [rsp + 0x80], r15d
0193679e  458bc4                   mov r8d, r12d
019367a1  488bd6                   mov rdx, rsi
019367a4  488d4c2468               lea rcx, [rsp + 0x68]
019367a9  ff15e9585900             call qword ptr [rip + 0x5958e9]
019367af  4c8d4c2468               lea r9, [rsp + 0x68]
019367b4  4c8bc6                   mov r8, rsi
019367b7  498bd6                   mov rdx, r14
019367ba  498bcd                   mov rcx, r13
019367bd  ff154d545900             call qword ptr [rip + 0x59544d]
019367c3  458bc7                   mov r8d, r15d
019367c6  83f804                   cmp eax, 4
019367c9  410f94c0                 sete r8b
019367cd  488bd6                   mov rdx, rsi
019367d0  488b8c2440010000         mov rcx, qword ptr [rsp + 0x140]
019367d8  ff15ba585900             call qword ptr [rip + 0x5958ba]
019367de  eb3e                     jmp 0x193681e
019367e0  4585e4                   test r12d, r12d
019367e3  740a                     je 0x19367ef
019367e5  4183fc07                 cmp r12d, 7
019367e9  7404                     je 0x19367ef
019367eb  32c0                     xor al, al
019367ed  eb02                     jmp 0x19367f1
019367ef  b001                     mov al, 1
019367f1  4183fc06                 cmp r12d, 6
019367f5  7513                     jne 0x193680a
019367f7  0fb606                   movzx eax, byte ptr [rsi]
019367fa  0fb68c18403b0202         movzx ecx, byte ptr [rax + rbx + 0x2023b40]
01936802  0fb68419e01e1202         movzx eax, byte ptr [rcx + rbx + 0x2121ee0]
0193680a  84c0                     test al, al
0193680c  7510                     jne 0x193681e
0193680e  33d2                     xor edx, edx
01936810  488d8c2440010000         lea rcx, [rsp + 0x140]
01936818  e843da89fe               call 0x1d4260
0193681d  90                       nop
0193681e  488d8c24b8000000         lea rcx, [rsp + 0xb8]
01936826  e885b36cfe               call 0x1bb0
0193682b  90                       nop
0193682c  eb22                     jmp 0x1936850
0193682e  488d1dcb976cfe           lea rbx, [rip - 0x1936835]
01936835  4533ff                   xor r15d, r15d
01936838  488bb42438010000         mov rsi, qword ptr [rsp + 0x138]
01936840  4c8bb42430010000         mov r14, qword ptr [rsp + 0x130]
01936848  4c8bac2428010000         mov r13, qword ptr [rsp + 0x128]
01936850  65488b142558000000       mov rdx, qword ptr gs:[0x58]
01936859  488b0518475900           mov rax, qword ptr [rip + 0x594718]
01936860  8b08                     mov ecx, dword ptr [rax]
01936862  488b0517475900           mov rax, qword ptr [rip + 0x594717]
01936869  8b38                     mov edi, dword ptr [rax]
0193686b  48033cca                 add rdi, qword ptr [rdx + rcx*8]
0193686f  488b8f00010000           mov rcx, qword ptr [rdi + 0x100]
01936876  4885c9                   test rcx, rcx
01936879  750d                     jne 0x1936888
0193687b  ff150f475900             call qword ptr [rip + 0x59470f]
01936881  488b8f00010000           mov rcx, qword ptr [rdi + 0x100]
01936888  83b92c02000000           cmp dword ptr [rcx + 0x22c], 0
0193688f  7406                     je 0x1936897
01936891  ff1529465900             call qword ptr [rip + 0x594629]
01936897  4c8ba42440010000         mov r12, qword ptr [rsp + 0x140]
0193689f  4d85e4                   test r12, r12
019368a2  7469                     je 0x193690d
019368a4  488bbc2448010000         mov rdi, qword ptr [rsp + 0x148]
019368ac  4885ff                   test rdi, rdi
019368af  745c                     je 0x193690d
019368b1  4d8bcd                   mov r9, r13
019368b4  4d8bc6                   mov r8, r14
019368b7  488bd6                   mov rdx, rsi
019368ba  498bcc                   mov rcx, r12
019368bd  ff154d535900             call qword ptr [rip + 0x59534d]
019368c3  83f802                   cmp eax, 2
019368c6  7445                     je 0x193690d
019368c8  83f801                   cmp eax, 1
019368cb  0f94c2                   sete dl
019368ce  8b07                     mov eax, dword ptr [rdi]
019368d0  ffc8                     dec eax
019368d2  83f805                   cmp eax, 5
019368d5  7736                     ja 0x193690d
019368d7  8b8c832c699301           mov ecx, dword ptr [rbx + rax*4 + 0x193692c]
019368de  4803cb                   add rcx, rbx
019368e1  ffe1                     jmp rcx
019368e3  0fb6c2                   movzx eax, dl
019368e6  8d044501000000           lea eax, [rax*2 + 1]
019368ed  8907                     mov dword ptr [rdi], eax
019368ef  eb1c                     jmp 0x193690d
019368f1  44893f                   mov dword ptr [rdi], r15d
019368f4  eb17                     jmp 0x193690d
019368f6  0fb6c2                   movzx eax, dl
019368f9  83f001                   xor eax, 1
019368fc  8d044504000000           lea eax, [rax*2 + 4]
01936903  8907                     mov dword ptr [rdi], eax
01936905  eb06                     jmp 0x193690d
01936907  c70707000000             mov dword ptr [rdi], 7
0193690d  4c89bc2440010000         mov qword ptr [rsp + 0x140], r15
01936915  498bc4                   mov rax, r12
01936918  4881c4e0000000           add rsp, 0xe0
0193691f  415f                     pop r15
01936921  415e                     pop r14
01936923  415d                     pop r13
01936925  415c                     pop r12
01936927  5f                       pop rdi
01936928  5e                       pop rsi
01936929  5b                       pop rbx
0193692a  c3                       ret
