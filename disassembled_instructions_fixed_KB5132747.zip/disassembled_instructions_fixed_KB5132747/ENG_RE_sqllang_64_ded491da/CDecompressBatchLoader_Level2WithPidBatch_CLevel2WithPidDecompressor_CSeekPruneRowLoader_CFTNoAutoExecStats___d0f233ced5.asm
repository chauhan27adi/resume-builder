; CDecompressBatchLoader<Level2WithPidBatch,CLevel2WithPidDecompressor,CSeekPruneRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x974e60, 1417 bytes in 3 chunk(s)

; chunk at RVA 0x974e60 (57 bytes)
00974e60  4c894c2420               mov qword ptr [rsp + 0x20], r9
00974e65  89542410                 mov dword ptr [rsp + 0x10], edx
00974e69  55                       push rbp
00974e6a  57                       push rdi
00974e6b  4155                     push r13
00974e6d  4157                     push r15
00974e6f  488d6c24c1               lea rbp, [rsp - 0x3f]
00974e74  4881ece8000000           sub rsp, 0xe8
00974e7b  83792002                 cmp dword ptr [rcx + 0x20], 2
00974e7f  4d8be8                   mov r13, r8
00974e82  8bfa                     mov edi, edx
00974e84  4c8bf9                   mov r15, rcx
00974e87  7510                     jne 0x974e99
00974e89  33c0                     xor eax, eax
00974e8b  4881c4e8000000           add rsp, 0xe8
00974e92  415f                     pop r15
00974e94  415d                     pop r13
00974e96  5f                       pop rdi
00974e97  5d                       pop rbp
00974e98  c3                       ret

; chunk at RVA 0x974e99 (1264 bytes)
00974e99  48899c2420010000         mov qword ptr [rsp + 0x120], rbx
00974ea1  0f57c0                   xorps xmm0, xmm0
00974ea4  4889b424e0000000         mov qword ptr [rsp + 0xe0], rsi
00974eac  0f57c9                   xorps xmm1, xmm1
00974eaf  4c89a424d8000000         mov qword ptr [rsp + 0xd8], r12
00974eb7  4c89b424d0000000         mov qword ptr [rsp + 0xd0], r14
00974ebf  4533f6                   xor r14d, r14d
00974ec2  32c9                     xor cl, cl
00974ec4  448975b7                 mov dword ptr [rbp - 0x49], r14d
00974ec8  884d67                   mov byte ptr [rbp + 0x67], cl
00974ecb  4c8975bf                 mov qword ptr [rbp - 0x41], r14
00974ecf  448875c7                 mov byte ptr [rbp - 0x39], r14b
00974ed3  660f7f45d7               movdqa xmmword ptr [rbp - 0x29], xmm0
00974ed8  660f7f4de7               movdqa xmmword ptr [rbp - 0x19], xmm1
00974edd  660f7f45f7               movdqa xmmword ptr [rbp - 9], xmm0
00974ee2  4c897507                 mov qword ptr [rbp + 7], r14
00974ee6  c7450f01000000           mov dword ptr [rbp + 0xf], 1
00974eed  4c897517                 mov qword ptr [rbp + 0x17], r14
00974ef1  4489742420               mov dword ptr [rsp + 0x20], r14d
00974ef6  45887510                 mov byte ptr [r13 + 0x10], r14b
00974efa  4c8d25ffb068ff           lea r12, [rip - 0x974f01]
00974f01  4538b7582e0000           cmp byte ptr [r15 + 0x2e58], r14b
00974f08  0f8495000000             je 0x974fa3
00974f0e  498b9f502e0000           mov rbx, qword ptr [r15 + 0x2e50]
00974f15  33d2                     xor edx, edx
00974f17  4c8bc3                   mov r8, rbx
00974f1a  4588b7582e0000           mov byte ptr [r15 + 0x2e58], r14b
00974f21  498bcd                   mov rcx, r13
00974f24  e8777affff               call 0x96c9a0
00974f29  488b5360                 mov rdx, qword ptr [rbx + 0x60]
00974f2d  488d75b7                 lea rsi, [rbp - 0x49]
00974f31  418b4d00                 mov ecx, dword ptr [r13]
00974f35  498b4560                 mov rax, qword ptr [r13 + 0x60]
00974f39  ffc9                     dec ecx
00974f3b  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00974f3f  4803c9                   add rcx, rcx
00974f42  0f1002                   movups xmm0, xmmword ptr [rdx]
00974f45  448975b7                 mov dword ptr [rbp - 0x49], r14d
00974f49  c744242001000000         mov dword ptr [rsp + 0x20], 1
00974f51  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
00974f55  498b87502e0000           mov rax, qword ptr [r15 + 0x2e50]
00974f5c  ff08                     dec dword ptr [rax]
00974f5e  418b5500                 mov edx, dword ptr [r13]
00974f62  498b4508                 mov rax, qword ptr [r13 + 8]
00974f66  488945bf                 mov qword ptr [rbp - 0x41], rax
00974f6a  498b4520                 mov rax, qword ptr [r13 + 0x20]
00974f6e  488d0cd0                 lea rcx, [rax + rdx*8]
00974f72  498b4528                 mov rax, qword ptr [r13 + 0x28]
00974f76  48894dd7                 mov qword ptr [rbp - 0x29], rcx
00974f7a  488d0c90                 lea rcx, [rax + rdx*4]
00974f7e  498b4530                 mov rax, qword ptr [r13 + 0x30]
00974f82  48894ddf                 mov qword ptr [rbp - 0x21], rcx
00974f86  4588b7582e0000           mov byte ptr [r15 + 0x2e58], r14b
00974f8d  488d0c90                 lea rcx, [rax + rdx*4]
00974f91  b801000000               mov eax, 1
00974f96  2bc2                     sub eax, edx
00974f98  48894de7                 mov qword ptr [rbp - 0x19], rcx
00974f9c  03f8                     add edi, eax
00974f9e  897d6f                   mov dword ptr [rbp + 0x6f], edi
00974fa1  eb03                     jmp 0x974fa6
00974fa3  498bf5                   mov rsi, r13
00974fa6  45397720                 cmp dword ptr [r15 + 0x20], r14d
00974faa  7558                     jne 0x975004
00974fac  498b4728                 mov rax, qword ptr [r15 + 0x28]
00974fb0  498d4f28                 lea rcx, [r15 + 0x28]
00974fb4  4d8bc1                   mov r8, r9
00974fb7  4c89742428               mov qword ptr [rsp + 0x28], r14
00974fbc  488d542428               lea rdx, [rsp + 0x28]
00974fc1  44897587                 mov dword ptr [rbp - 0x79], r14d
00974fc5  4c89758f                 mov qword ptr [rbp - 0x71], r14
00974fc9  44897597                 mov dword ptr [rbp - 0x69], r14d
00974fcd  4c89759f                 mov qword ptr [rbp - 0x61], r14
00974fd1  448975a7                 mov dword ptr [rbp - 0x59], r14d
00974fd5  66448975ab               mov word ptr [rbp - 0x55], r14w
00974fda  c6456701                 mov byte ptr [rbp + 0x67], 1
00974fde  ff10                     call qword ptr [rax]
00974fe0  3dc60e0400               cmp eax, 0x40ec6
00974fe5  0f844c030000             je 0x975337
00974feb  498d8f48090000           lea rcx, [r15 + 0x948]
00974ff2  488d542428               lea rdx, [rsp + 0x28]
00974ff7  e80472f5ff               call 0x8cc200
00974ffc  41c7472001000000         mov dword ptr [r15 + 0x20], 1
00975004  498b4730                 mov rax, qword ptr [r15 + 0x30]
00975008  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
0097500f  4c894608                 mov qword ptr [rsi + 8], r8
00975013  498b5730                 mov rdx, qword ptr [r15 + 0x30]
00975017  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
0097501e  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00975021  83e007                   and eax, 7
00975024  83f805                   cmp eax, 5
00975027  773c                     ja 0x975065
00975029  4898                     cdqe
0097502b  418b8c848c539700         mov ecx, dword ptr [r12 + rax*4 + 0x97538c]
00975033  4903cc                   add rcx, r12
00975036  ffe1                     jmp rcx
00975038  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097503c  0f95c3                   setne bl
0097503f  eb26                     jmp 0x975067
00975041  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975045  0f9dc3                   setge bl
00975048  eb1d                     jmp 0x975067
0097504a  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097504e  0f9ec3                   setle bl
00975051  eb14                     jmp 0x975067
00975053  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975057  0f9fc3                   setg bl
0097505a  eb0b                     jmp 0x975067
0097505c  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975060  0f9cc3                   setl bl
00975063  eb02                     jmp 0x975067
00975065  32db                     xor bl, bl
00975067  8b424c                   mov eax, dword ptr [rdx + 0x4c]
0097506a  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00975071  83e007                   and eax, 7
00975074  83f805                   cmp eax, 5
00975077  7741                     ja 0x9750ba
00975079  4898                     cdqe
0097507b  418b8c84a4539700         mov ecx, dword ptr [r12 + rax*4 + 0x9753a4]
00975083  4903cc                   add rcx, r12
00975086  ffe1                     jmp rcx
00975088  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097508c  410f95c4                 setne r12b
00975090  eb2b                     jmp 0x9750bd
00975092  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975096  410f9dc4                 setge r12b
0097509a  eb21                     jmp 0x9750bd
0097509c  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009750a0  410f9ec4                 setle r12b
009750a4  eb17                     jmp 0x9750bd
009750a6  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009750aa  410f9fc4                 setg r12b
009750ae  eb0d                     jmp 0x9750bd
009750b0  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009750b4  410f9cc4                 setl r12b
009750b8  eb03                     jmp 0x9750bd
009750ba  4532e4                   xor r12b, r12b
009750bd  498d8f48090000           lea rcx, [r15 + 0x948]
009750c4  4c8bc6                   mov r8, rsi
009750c7  8bd7                     mov edx, edi
009750c9  e8d28effff               call 0x96dfa0
009750ce  84c0                     test al, al
009750d0  7504                     jne 0x9750d6
009750d2  45897720                 mov dword ptr [r15 + 0x20], r14d
009750d6  8b06                     mov eax, dword ptr [rsi]
009750d8  448bc0                   mov r8d, eax
009750db  85c0                     test eax, eax
009750dd  0f84d0010000             je 0x9752b3
009750e3  84db                     test bl, bl
009750e5  7509                     jne 0x9750f0
009750e7  4584e4                   test r12b, r12b
009750ea  0f84c3010000             je 0x9752b3
009750f0  448bc8                   mov r9d, eax
009750f3  84db                     test bl, bl
009750f5  0f8485000000             je 0x975180
009750fb  4d8b5f30                 mov r11, qword ptr [r15 + 0x30]
009750ff  458bd6                   mov r10d, r14d
00975102  85c0                     test eax, eax
00975104  7471                     je 0x975177
00975106  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
0097510a  488d3defae68ff           lea rdi, [rip - 0x975111]
00975111  488b5e20                 mov rbx, qword ptr [rsi + 0x20]
00975115  4183e007                 and r8d, 7
00975119  0f1f8000000000           nop dword ptr [rax]
00975120  418bca                   mov ecx, r10d
00975123  4c8b0ccb                 mov r9, qword ptr [rbx + rcx*8]
00975127  4183f805                 cmp r8d, 5
0097512b  0f87ae000000             ja 0x9751df
00975131  4963c8                   movsxd rcx, r8d
00975134  8b948fbc539700           mov edx, dword ptr [rdi + rcx*4 + 0x9753bc]
0097513b  4803d7                   add rdx, rdi
0097513e  ffe2                     jmp rdx
00975140  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975144  0f94c1                   sete cl
00975147  eb22                     jmp 0x97516b
00975149  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
0097514d  0f9cc1                   setl cl
00975150  eb19                     jmp 0x97516b
00975152  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975156  0f9fc1                   setg cl
00975159  eb10                     jmp 0x97516b
0097515b  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
0097515f  0f9ec1                   setle cl
00975162  eb07                     jmp 0x97516b
00975164  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975168  0f9dc1                   setge cl
0097516b  84c9                     test cl, cl
0097516d  7570                     jne 0x9751df
0097516f  41ffc2                   inc r10d
00975172  443bd0                   cmp r10d, eax
00975175  72a9                     jb 0x975120
00975177  448936                   mov dword ptr [rsi], r14d
0097517a  418bc6                   mov eax, r14d
0097517d  458bce                   mov r9d, r14d
00975180  458bc1                   mov r8d, r9d
00975183  4584e4                   test r12b, r12b
00975186  0f8427010000             je 0x9752b3
0097518c  85c0                     test eax, eax
0097518e  0f841f010000             je 0x9752b3
00975194  4d8b5f30                 mov r11, qword ptr [r15 + 0x30]
00975198  4c8d2561ae68ff           lea r12, [rip - 0x97519f]
0097519f  488b7e20                 mov rdi, qword ptr [rsi + 0x20]
009751a3  0f1f4000                 nop dword ptr [rax]
009751a7  660f1f840000000000       nop word ptr [rax + rax]
009751b0  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
009751b4  ffc8                     dec eax
009751b6  458bd1                   mov r10d, r9d
009751b9  83e107                   and ecx, 7
009751bc  448bc8                   mov r9d, eax
009751bf  458bc2                   mov r8d, r10d
009751c2  488b1cc7                 mov rbx, qword ptr [rdi + rax*8]
009751c6  83f905                   cmp ecx, 5
009751c9  0f87e4000000             ja 0x9752b3
009751cf  4863c9                   movsxd rcx, ecx
009751d2  418b948cd4539700         mov edx, dword ptr [r12 + rcx*4 + 0x9753d4]
009751da  4903d4                   add rdx, r12
009751dd  ffe2                     jmp rdx
009751df  443bd0                   cmp r10d, eax
009751e2  7393                     jae 0x975177
009751e4  448bc8                   mov r9d, eax
009751e7  4585d2                   test r10d, r10d
009751ea  7494                     je 0x975180
009751ec  458bde                   mov r11d, r14d
009751ef  452bca                   sub r9d, r10d
009751f2  7478                     je 0x97526c
009751f4  498bd6                   mov rdx, r14
009751f7  498bde                   mov rbx, r14
009751fa  498bfe                   mov rdi, r14
009751fd  0f1f00                   nop dword ptr [rax]
00975200  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00975204  438d0413                 lea eax, [r11 + r10]
00975208  448bc0                   mov r8d, eax
0097520b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
0097520f  4889040f                 mov qword ptr [rdi + rcx], rax
00975213  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
00975217  428b0481                 mov eax, dword ptr [rcx + r8*4]
0097521b  89040b                   mov dword ptr [rbx + rcx], eax
0097521e  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
00975222  428b0481                 mov eax, dword ptr [rcx + r8*4]
00975226  4d03c0                   add r8, r8
00975229  89040b                   mov dword ptr [rbx + rcx], eax
0097522c  488b4638                 mov rax, qword ptr [rsi + 0x38]
00975230  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00975235  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00975239  488b4648                 mov rax, qword ptr [rsi + 0x48]
0097523d  4885c0                   test rax, rax
00975240  7409                     je 0x97524b
00975242  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00975247  0f110410                 movups xmmword ptr [rax + rdx], xmm0
0097524b  488b4660                 mov rax, qword ptr [rsi + 0x60]
0097524f  41ffc3                   inc r11d
00975252  4883c708                 add rdi, 8
00975256  4883c304                 add rbx, 4
0097525a  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
0097525f  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00975263  4883c210                 add rdx, 0x10
00975267  453bd9                   cmp r11d, r9d
0097526a  7294                     jb 0x975200
0097526c  44890e                   mov dword ptr [rsi], r9d
0097526f  418bc1                   mov eax, r9d
00975272  e909ffffff               jmp 0x975180
00975277  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097527b  0f94c1                   sete cl
0097527e  eb22                     jmp 0x9752a2
00975280  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975284  0f9cc1                   setl cl
00975287  eb19                     jmp 0x9752a2
00975289  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097528d  0f9fc1                   setg cl
00975290  eb10                     jmp 0x9752a2
00975292  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975296  0f9ec1                   setle cl
00975299  eb07                     jmp 0x9752a2
0097529b  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097529f  0f9dc1                   setge cl
009752a2  84c9                     test cl, cl
009752a4  750d                     jne 0x9752b3
009752a6  8906                     mov dword ptr [rsi], eax
009752a8  448bc0                   mov r8d, eax
009752ab  85c0                     test eax, eax
009752ad  0f85fdfeffff             jne 0x9751b0
009752b3  4538b7592e0000           cmp byte ptr [r15 + 0x2e59], r14b
009752ba  7462                     je 0x97531e
009752bc  448b06                   mov r8d, dword ptr [rsi]
009752bf  4585c0                   test r8d, r8d
009752c2  745a                     je 0x97531e
009752c4  498bbf502e0000           mov rdi, qword ptr [r15 + 0x2e50]
009752cb  4c8bc6                   mov r8, rsi
009752ce  41c687582e000001         mov byte ptr [r15 + 0x2e58], 1
009752d6  488bcf                   mov rcx, rdi
009752d9  8b1e                     mov ebx, dword ptr [rsi]
009752db  ffcb                     dec ebx
009752dd  8bd3                     mov edx, ebx
009752df  e8bc76ffff               call 0x96c9a0
009752e4  8b0f                     mov ecx, dword ptr [rdi]
009752e6  488b4760                 mov rax, qword ptr [rdi + 0x60]
009752ea  ffc9                     dec ecx
009752ec  488b5660                 mov rdx, qword ptr [rsi + 0x60]
009752f0  4803c9                   add rcx, rcx
009752f3  448bc3                   mov r8d, ebx
009752f6  4d03c0                   add r8, r8
009752f9  420f1004c2               movups xmm0, xmmword ptr [rdx + r8*8]
009752fe  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
00975302  ff0e                     dec dword ptr [rsi]
00975304  41c6451001               mov byte ptr [r13 + 0x10], 1
00975309  498b87502e0000           mov rax, qword ptr [r15 + 0x2e50]
00975310  488b4820                 mov rcx, qword ptr [rax + 0x20]
00975314  488b01                   mov rax, qword ptr [rcx]
00975317  49894518                 mov qword ptr [r13 + 0x18], rax
0097531b  448b06                   mov r8d, dword ptr [rsi]
0097531e  8b442420                 mov eax, dword ptr [rsp + 0x20]
00975322  4103c0                   add eax, r8d
00975325  89442420                 mov dword ptr [rsp + 0x20], eax
00975329  7521                     jne 0x97534c
0097532b  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
0097532e  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00975332  e9bffbffff               jmp 0x974ef6
00975337  41c7472002000000         mov dword ptr [r15 + 0x20], 2
0097533f  45397500                 cmp dword ptr [r13], r14d
00975343  410f95c6                 setne r14b
00975347  418bc6                   mov eax, r14d
0097534a  eb0f                     jmp 0x97535b
0097534c  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00975350  f6d9                     neg cl
00975352  41894500                 mov dword ptr [r13], eax
00975356  1bc0                     sbb eax, eax
00975358  83c002                   add eax, 2
0097535b  4c8ba424d8000000         mov r12, qword ptr [rsp + 0xd8]
00975363  488bb424e0000000         mov rsi, qword ptr [rsp + 0xe0]
0097536b  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
00975373  4c8bb424d0000000         mov r14, qword ptr [rsp + 0xd0]
0097537b  4881c4e8000000           add rsp, 0xe8
00975382  415f                     pop r15
00975384  415d                     pop r13
00975386  5f                       pop rdi
00975387  5d                       pop rbp
00975388  c3                       ret

; chunk at RVA 0x97538c (96 bytes)
0097538c  6550                     push rax
0097538e  97                       xchg edi, eax
0097538f  0038                     add byte ptr [rax], bh
00975391  50                       push rax
00975392  97                       xchg edi, eax
00975393  004150                   add byte ptr [rcx + 0x50], al
00975396  97                       xchg edi, eax
00975397  005350                   add byte ptr [rbx + 0x50], dl
0097539a  97                       xchg edi, eax
0097539b  004a50                   add byte ptr [rdx + 0x50], cl
0097539e  97                       xchg edi, eax
0097539f  005c5097                 add byte ptr [rax + rdx*2 - 0x69], bl
009753a3  00ba50970088             add byte ptr [rdx - 0x77ff68b0], bh
009753a9  50                       push rax
009753aa  97                       xchg edi, eax
009753ab  0092509700a6             add byte ptr [rdx - 0x59ff68b0], dl
009753b1  50                       push rax
009753b2  97                       xchg edi, eax
009753b3  009c509700b050           add byte ptr [rax + rdx*2 + 0x50b00097], bl
009753ba  97                       xchg edi, eax
009753bb  00df                     add bh, bl
009753bd  51                       push rcx
009753be  97                       xchg edi, eax
009753bf  004051                   add byte ptr [rax + 0x51], al
009753c2  97                       xchg edi, eax
009753c3  004951                   add byte ptr [rcx + 0x51], cl
009753c6  97                       xchg edi, eax
009753c7  005b51                   add byte ptr [rbx + 0x51], bl
009753ca  97                       xchg edi, eax
009753cb  005251                   add byte ptr [rdx + 0x51], dl
009753ce  97                       xchg edi, eax
009753cf  00645197                 add byte ptr [rcx + rdx*2 - 0x69], ah
009753d3  00b352970077             add byte ptr [rbx + 0x77009752], dh
009753d9  52                       push rdx
009753da  97                       xchg edi, eax
009753db  008052970092             add byte ptr [rax - 0x6dff68ae], al
009753e1  52                       push rdx
009753e2  97                       xchg edi, eax
009753e3  00895297009b             add byte ptr [rcx - 0x64ff68ae], cl
009753e9  52                       push rdx
009753ea  97                       xchg edi, eax
