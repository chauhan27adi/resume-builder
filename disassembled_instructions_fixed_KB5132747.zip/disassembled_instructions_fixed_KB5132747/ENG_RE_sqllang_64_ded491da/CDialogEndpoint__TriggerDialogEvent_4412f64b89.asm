; CDialogEndpoint::TriggerDialogEvent
; sqllang.dll, primary RVA 0x4c7700, 692 bytes in 1 chunk(s)

; chunk at RVA 0x4c7700 (692 bytes)
004c7700  4056                     push rsi
004c7702  57                       push rdi
004c7703  4156                     push r14
004c7705  4883ec50                 sub rsp, 0x50
004c7709  48c7442440feffffff       mov qword ptr [rsp + 0x40], 0xfffffffffffffffe
004c7712  48899c2480000000         mov qword ptr [rsp + 0x80], rbx
004c771a  488bd9                   mov rbx, rcx
004c771d  4c8d35dc88b3ff           lea r14, [rip - 0x4c7724]
004c7724  83fa0c                   cmp edx, 0xc
004c7727  750c                     jne 0x4c7735
004c7729  48634130                 movsxd rax, dword ptr [rcx + 0x30]
004c772d  418b9486785f1702         mov edx, dword ptr [r14 + rax*4 + 0x2175f78]
004c7735  80792e00                 cmp byte ptr [rcx + 0x2e], 0
004c7739  7424                     je 0x4c775f
004c773b  83fa03                   cmp edx, 3
004c773e  751f                     jne 0x4c775f
004c7740  488b8130040000           mov rax, qword ptr [rcx + 0x430]
004c7747  c6805d01000001           mov byte ptr [rax + 0x15d], 1
004c774e  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
004c7756  4883c450                 add rsp, 0x50
004c775a  415e                     pop r14
004c775c  5f                       pop rdi
004c775d  5e                       pop rsi
004c775e  c3                       ret
004c775f  48638170010000           movsxd rax, dword ptr [rcx + 0x170]
004c7766  894174                   mov dword ptr [rcx + 0x74], eax
004c7769  4863f2                   movsxd rsi, edx
004c776c  486bc80b                 imul rcx, rax, 0xb
004c7770  4803ce                   add rcx, rsi
004c7773  418bbc8e405e1702         mov edi, dword ptr [r14 + rcx*4 + 0x2175e40]
004c777b  897b78                   mov dword ptr [rbx + 0x78], edi
004c777e  83fa0a                   cmp edx, 0xa
004c7781  775d                     ja 0x4c77e0
004c7783  4863c2                   movsxd rax, edx
004c7786  418b8c8688794c00         mov ecx, dword ptr [r14 + rax*4 + 0x4c7988]
004c778e  4903ce                   add rcx, r14
004c7791  ffe1                     jmp rcx
004c7793  ba01000000               mov edx, 1
004c7798  eb75                     jmp 0x4c780f
004c779a  ba02000000               mov edx, 2
004c779f  eb6e                     jmp 0x4c780f
004c77a1  ba03000000               mov edx, 3
004c77a6  eb67                     jmp 0x4c780f
004c77a8  ba04000000               mov edx, 4
004c77ad  eb60                     jmp 0x4c780f
004c77af  ba05000000               mov edx, 5
004c77b4  eb59                     jmp 0x4c780f
004c77b6  ba06000000               mov edx, 6
004c77bb  eb52                     jmp 0x4c780f
004c77bd  ba07000000               mov edx, 7
004c77c2  eb4b                     jmp 0x4c780f
004c77c4  ba08000000               mov edx, 8
004c77c9  eb44                     jmp 0x4c780f
004c77cb  ba09000000               mov edx, 9
004c77d0  eb3d                     jmp 0x4c780f
004c77d2  ba0a000000               mov edx, 0xa
004c77d7  eb36                     jmp 0x4c780f
004c77d9  ba0d000000               mov edx, 0xd
004c77de  eb2f                     jmp 0x4c780f
004c77e0  488d05410dc901           lea rax, [rip + 0x1c90d41]
004c77e7  4889442420               mov qword ptr [rsp + 0x20], rax
004c77ec  41b9b9190000             mov r9d, 0x19b9
004c77f2  4c8d0597ea0402           lea r8, [rip + 0x204ea97]
004c77f9  488d1540d20402           lea rdx, [rip + 0x204d240]
004c7800  b901000000               mov ecx, 1
004c7805  ff156d36a001             call qword ptr [rip + 0x1a0366d]
004c780b  8b542430                 mov edx, dword ptr [rsp + 0x30]
004c780f  448bc7                   mov r8d, edi
004c7812  488bcb                   mov rcx, rbx
004c7815  e8f6410000               call 0x4cba10
004c781a  8b5378                   mov edx, dword ptr [rbx + 0x78]
004c781d  83fa08                   cmp edx, 8
004c7820  0f8451010000             je 0x4c7977
004c7826  48634374                 movsxd rax, dword ptr [rbx + 0x74]
004c782a  3bd0                     cmp edx, eax
004c782c  740d                     je 0x4c783b
004c782e  899370010000             mov dword ptr [rbx + 0x170], edx
004c7834  838ba802000008           or dword ptr [rbx + 0x2a8], 8
004c783b  486bc80b                 imul rcx, rax, 0xb
004c783f  4803ce                   add rcx, rsi
004c7842  498bbccec0571702         mov rdi, qword ptr [r14 + rcx*8 + 0x21757c0]
004c784a  8b07                     mov eax, dword ptr [rdi]
004c784c  83f80c                   cmp eax, 0xc
004c784f  7418                     je 0x4c7869
004c7851  8bd0                     mov edx, eax
004c7853  488bcb                   mov rcx, rbx
004c7856  e875f9ffff               call 0x4c71d0
004c785b  488d7f04                 lea rdi, [rdi + 4]
004c785f  8b07                     mov eax, dword ptr [rdi]
004c7861  83f80c                   cmp eax, 0xc
004c7864  75eb                     jne 0x4c7851
004c7866  8b5378                   mov edx, dword ptr [rbx + 0x78]
004c7869  83fa06                   cmp edx, 6
004c786c  0f8505010000             jne 0x4c7977
004c7872  395374                   cmp dword ptr [rbx + 0x74], edx
004c7875  750a                     jne 0x4c7881
004c7877  837b300d                 cmp dword ptr [rbx + 0x30], 0xd
004c787b  0f85ef000000             jne 0x4c7970
004c7881  4533c0                   xor r8d, r8d
004c7884  418d5001                 lea edx, [r8 + 1]
004c7888  488d4c2438               lea rcx, [rsp + 0x38]
004c788d  ff1535056102             call qword ptr [rip + 0x2610535]
004c7893  80bbf800000000           cmp byte ptr [rbx + 0xf8], 0
004c789a  0f85b5000000             jne 0x4c7955
004c78a0  837b7400                 cmp dword ptr [rbx + 0x74], 0
004c78a4  0f84ab000000             je 0x4c7955
004c78aa  837b300d                 cmp dword ptr [rbx + 0x30], 0xd
004c78ae  0f84a1000000             je 0x4c7955
004c78b4  488b8338010000           mov rax, qword ptr [rbx + 0x138]
004c78bb  4889442430               mov qword ptr [rsp + 0x30], rax
004c78c0  ba08000000               mov edx, 8
004c78c5  41b826070000             mov r8d, 0x726
004c78cb  488d4c2430               lea rcx, [rsp + 0x30]
004c78d0  ff15aa43a001             call qword ptr [rip + 0x1a043aa]
004c78d6  85c0                     test eax, eax
004c78d8  7442                     je 0x4c791c
004c78da  83f801                   cmp eax, 1
004c78dd  742d                     je 0x4c790c
004c78df  488d05420cc901           lea rax, [rip + 0x1c90c42]
004c78e6  4889442420               mov qword ptr [rsp + 0x20], rax
004c78eb  41b95a170000             mov r9d, 0x175a
004c78f1  4c8d0598e90402           lea r8, [rip + 0x204e998]
004c78f8  488d1541d10402           lea rdx, [rip + 0x204d141]
004c78ff  b901000000               mov ecx, 1
004c7904  ff156e35a001             call qword ptr [rip + 0x1a0356e]
004c790a  eb10                     jmp 0x4c791c
004c790c  c74424347f242d00         mov dword ptr [rsp + 0x34], 0x2d247f
004c7914  c7442430ff818b01         mov dword ptr [rsp + 0x30], 0x18b81ff
004c791c  488b8b10020000           mov rcx, qword ptr [rbx + 0x210]
004c7923  488b442430               mov rax, qword ptr [rsp + 0x30]
004c7928  4885c9                   test rcx, rcx
004c792b  7409                     je 0x4c7936
004c792d  483bc1                   cmp rax, rcx
004c7930  7c04                     jl 0x4c7936
004c7932  480f45c1                 cmovne rax, rcx
004c7936  483b442438               cmp rax, qword ptr [rsp + 0x38]
004c793b  7c18                     jl 0x4c7955
004c793d  7416                     je 0x4c7955
004c793f  488d8b80000000           lea rcx, [rbx + 0x80]
004c7946  e8b5980200               call 0x4f1200
004c794b  488bcb                   mov rcx, rbx
004c794e  e80d330000               call 0x4cac60
004c7953  eb14                     jmp 0x4c7969
004c7955  488bcb                   mov rcx, rbx
004c7958  e8f3350000               call 0x4caf50
004c795d  488d8b80000000           lea rcx, [rbx + 0x80]
004c7964  e8d7a20200               call 0x4f1c40
004c7969  c7437406000000           mov dword ptr [rbx + 0x74], 6
004c7970  b102                     mov cl, 2
004c7972  e8795bb4ff               call 0xd4f0
004c7977  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
004c797f  4883c450                 add rsp, 0x50
004c7983  415e                     pop r14
004c7985  5f                       pop rdi
004c7986  5e                       pop rsi
004c7987  c3                       ret
004c7988  93                       xchg ebx, eax
004c7989  774c                     ja 0x4c79d7
004c798b  009a774c00a1             add byte ptr [rdx - 0x5effb389], bl
004c7991  774c                     ja 0x4c79df
004c7993  00a8774c00af             add byte ptr [rax - 0x50ffb389], ch
004c7999  774c                     ja 0x4c79e7
004c799b  00b6774c00bd             add byte ptr [rsi - 0x42ffb389], dh
004c79a1  774c                     ja 0x4c79ef
004c79a3  00c4                     add ah, al
004c79a5  774c                     ja 0x4c79f3
004c79a7  00cb                     add bl, cl
004c79a9  774c                     ja 0x4c79f7
004c79ab  00d2                     add dl, dl
004c79ad  774c                     ja 0x4c79fb
004c79af  00d9                     add cl, bl
004c79b1  774c                     ja 0x4c79ff
