; CDecompressBatchLoader<Level2WithPidBatch,CLevel2WithPidDecompressor,CSimpleRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x9731b0, 1416 bytes in 1 chunk(s)

; chunk at RVA 0x9731b0 (1416 bytes)
009731b0  488bc4                   mov rax, rsp
009731b3  4c894820                 mov qword ptr [rax + 0x20], r9
009731b7  895010                   mov dword ptr [rax + 0x10], edx
009731ba  55                       push rbp
009731bb  56                       push rsi
009731bc  57                       push rdi
009731bd  4154                     push r12
009731bf  4155                     push r13
009731c1  4156                     push r14
009731c3  4157                     push r15
009731c5  488d68a1                 lea rbp, [rax - 0x5f]
009731c9  4881ece0000000           sub rsp, 0xe0
009731d0  48c74517feffffff         mov qword ptr [rbp + 0x17], 0xfffffffffffffffe
009731d8  48895818                 mov qword ptr [rax + 0x18], rbx
009731dc  4d8be8                   mov r13, r8
009731df  8bfa                     mov edi, edx
009731e1  488bf1                   mov rsi, rcx
009731e4  83792002                 cmp dword ptr [rcx + 0x20], 2
009731e8  7507                     jne 0x9731f1
009731ea  33c0                     xor eax, eax
009731ec  e9cc040000               jmp 0x9736bd
009731f1  4533ff                   xor r15d, r15d
009731f4  44897da7                 mov dword ptr [rbp - 0x59], r15d
009731f8  4c897daf                 mov qword ptr [rbp - 0x51], r15
009731fc  44887db7                 mov byte ptr [rbp - 0x49], r15b
00973200  0f57c0                   xorps xmm0, xmm0
00973203  660f7f45c7               movdqa xmmword ptr [rbp - 0x39], xmm0
00973208  0f57c9                   xorps xmm1, xmm1
0097320b  660f7f4dd7               movdqa xmmword ptr [rbp - 0x29], xmm1
00973210  660f7f45e7               movdqa xmmword ptr [rbp - 0x19], xmm0
00973215  4c897df7                 mov qword ptr [rbp - 9], r15
00973219  c745ff01000000           mov dword ptr [rbp - 1], 1
00973220  4c897d07                 mov qword ptr [rbp + 7], r15
00973224  44897c2420               mov dword ptr [rsp + 0x20], r15d
00973229  32c9                     xor cl, cl
0097322b  884d67                   mov byte ptr [rbp + 0x67], cl
0097322e  4c8d25cbcd68ff           lea r12, [rip - 0x973235]
00973235  41c6451000               mov byte ptr [r13 + 0x10], 0
0097323a  80be4825000000           cmp byte ptr [rsi + 0x2548], 0
00973241  0f8495000000             je 0x9732dc
00973247  c6864825000000           mov byte ptr [rsi + 0x2548], 0
0097324e  488b9e40250000           mov rbx, qword ptr [rsi + 0x2540]
00973255  4c8bc3                   mov r8, rbx
00973258  33d2                     xor edx, edx
0097325a  498bcd                   mov rcx, r13
0097325d  e83e97ffff               call 0x96c9a0
00973262  488b5360                 mov rdx, qword ptr [rbx + 0x60]
00973266  418b4d00                 mov ecx, dword ptr [r13]
0097326a  ffc9                     dec ecx
0097326c  4803c9                   add rcx, rcx
0097326f  498b4560                 mov rax, qword ptr [r13 + 0x60]
00973273  0f1002                   movups xmm0, xmmword ptr [rdx]
00973276  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
0097327a  488b8640250000           mov rax, qword ptr [rsi + 0x2540]
00973281  ff08                     dec dword ptr [rax]
00973283  44897da7                 mov dword ptr [rbp - 0x59], r15d
00973287  498b4508                 mov rax, qword ptr [r13 + 8]
0097328b  488945af                 mov qword ptr [rbp - 0x51], rax
0097328f  418b5500                 mov edx, dword ptr [r13]
00973293  498b4520                 mov rax, qword ptr [r13 + 0x20]
00973297  488d0cd0                 lea rcx, [rax + rdx*8]
0097329b  48894dc7                 mov qword ptr [rbp - 0x39], rcx
0097329f  498b4528                 mov rax, qword ptr [r13 + 0x28]
009732a3  488d0c90                 lea rcx, [rax + rdx*4]
009732a7  48894dcf                 mov qword ptr [rbp - 0x31], rcx
009732ab  498b4530                 mov rax, qword ptr [r13 + 0x30]
009732af  488d0c90                 lea rcx, [rax + rdx*4]
009732b3  48894dd7                 mov qword ptr [rbp - 0x29], rcx
009732b7  b801000000               mov eax, 1
009732bc  2bc2                     sub eax, edx
009732be  03f8                     add edi, eax
009732c0  897d6f                   mov dword ptr [rbp + 0x6f], edi
009732c3  4c8d75a7                 lea r14, [rbp - 0x59]
009732c7  c6864825000000           mov byte ptr [rsi + 0x2548], 0
009732ce  c744242001000000         mov dword ptr [rsp + 0x20], 1
009732d6  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009732da  eb03                     jmp 0x9732df
009732dc  4d8bf5                   mov r14, r13
009732df  837e2000                 cmp dword ptr [rsi + 0x20], 0
009732e3  7555                     jne 0x97333a
009732e5  4c897c2428               mov qword ptr [rsp + 0x28], r15
009732ea  44897c2430               mov dword ptr [rsp + 0x30], r15d
009732ef  4c897c2438               mov qword ptr [rsp + 0x38], r15
009732f4  44897d87                 mov dword ptr [rbp - 0x79], r15d
009732f8  4c897d8f                 mov qword ptr [rbp - 0x71], r15
009732fc  44897d97                 mov dword ptr [rbp - 0x69], r15d
00973300  6644897d9b               mov word ptr [rbp - 0x65], r15w
00973305  488d4e28                 lea rcx, [rsi + 0x28]
00973309  488b01                   mov rax, qword ptr [rcx]
0097330c  4d8bc1                   mov r8, r9
0097330f  488d542428               lea rdx, [rsp + 0x28]
00973314  ff10                     call qword ptr [rax]
00973316  c6456701                 mov byte ptr [rbp + 0x67], 1
0097331a  3dc60e0400               cmp eax, 0x40ec6
0097331f  0f8474030000             je 0x973699
00973325  488d4e38                 lea rcx, [rsi + 0x38]
00973329  488d542428               lea rdx, [rsp + 0x28]
0097332e  e8cd8ef5ff               call 0x8cc200
00973333  c7462001000000           mov dword ptr [rsi + 0x20], 1
0097333a  488b4630                 mov rax, qword ptr [rsi + 0x30]
0097333e  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00973345  4d894608                 mov qword ptr [r14 + 8], r8
00973349  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00973350  488b5630                 mov rdx, qword ptr [rsi + 0x30]
00973354  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00973357  83e007                   and eax, 7
0097335a  83f805                   cmp eax, 5
0097335d  773c                     ja 0x97339b
0097335f  4898                     cdqe
00973361  418b8c84d8369700         mov ecx, dword ptr [r12 + rax*4 + 0x9736d8]
00973369  4903cc                   add rcx, r12
0097336c  ffe1                     jmp rcx
0097336e  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973372  0f95c3                   setne bl
00973375  eb26                     jmp 0x97339d
00973377  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097337b  0f9dc3                   setge bl
0097337e  eb1d                     jmp 0x97339d
00973380  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973384  0f9ec3                   setle bl
00973387  eb14                     jmp 0x97339d
00973389  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097338d  0f9fc3                   setg bl
00973390  eb0b                     jmp 0x97339d
00973392  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973396  0f9cc3                   setl bl
00973399  eb02                     jmp 0x97339d
0097339b  32db                     xor bl, bl
0097339d  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
009733a4  8b424c                   mov eax, dword ptr [rdx + 0x4c]
009733a7  83e007                   and eax, 7
009733aa  83f805                   cmp eax, 5
009733ad  7741                     ja 0x9733f0
009733af  4898                     cdqe
009733b1  418b8c84f0369700         mov ecx, dword ptr [r12 + rax*4 + 0x9736f0]
009733b9  4903cc                   add rcx, r12
009733bc  ffe1                     jmp rcx
009733be  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009733c2  410f95c4                 setne r12b
009733c6  eb2b                     jmp 0x9733f3
009733c8  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009733cc  410f9dc4                 setge r12b
009733d0  eb21                     jmp 0x9733f3
009733d2  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009733d6  410f9ec4                 setle r12b
009733da  eb17                     jmp 0x9733f3
009733dc  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009733e0  410f9fc4                 setg r12b
009733e4  eb0d                     jmp 0x9733f3
009733e6  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009733ea  410f9cc4                 setl r12b
009733ee  eb03                     jmp 0x9733f3
009733f0  4532e4                   xor r12b, r12b
009733f3  4889751f                 mov qword ptr [rbp + 0x1f], rsi
009733f7  0f31                     rdtsc
009733f9  48c1e220                 shl rdx, 0x20
009733fd  480bc2                   or rax, rdx
00973400  48894608                 mov qword ptr [rsi + 8], rax
00973404  488d4e38                 lea rcx, [rsi + 0x38]
00973408  4d8bc6                   mov r8, r14
0097340b  8bd7                     mov edx, edi
0097340d  e88eabffff               call 0x96dfa0
00973412  84c0                     test al, al
00973414  7504                     jne 0x97341a
00973416  44897e20                 mov dword ptr [rsi + 0x20], r15d
0097341a  418b06                   mov eax, dword ptr [r14]
0097341d  48014610                 add qword ptr [rsi + 0x10], rax
00973421  0f31                     rdtsc
00973423  48c1e220                 shl rdx, 0x20
00973427  480bc2                   or rax, rdx
0097342a  482b4608                 sub rax, qword ptr [rsi + 8]
0097342e  480106                   add qword ptr [rsi], rax
00973431  ff4618                   inc dword ptr [rsi + 0x18]
00973434  418b06                   mov eax, dword ptr [r14]
00973437  448bc0                   mov r8d, eax
0097343a  85c0                     test eax, eax
0097343c  0f84d2010000             je 0x973614
00973442  84db                     test bl, bl
00973444  7509                     jne 0x97344f
00973446  4584e4                   test r12b, r12b
00973449  0f84c5010000             je 0x973614
0097344f  448bc8                   mov r9d, eax
00973452  84db                     test bl, bl
00973454  0f8486000000             je 0x9734e0
0097345a  458bd7                   mov r10d, r15d
0097345d  4c8b5e30                 mov r11, qword ptr [rsi + 0x30]
00973461  85c0                     test eax, eax
00973463  7472                     je 0x9734d7
00973465  498b5e20                 mov rbx, qword ptr [r14 + 0x20]
00973469  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
0097346d  4183e007                 and r8d, 7
00973471  488d3d88cb68ff           lea rdi, [rip - 0x973478]
00973478  0f1f840000000000         nop dword ptr [rax + rax]
00973480  418bca                   mov ecx, r10d
00973483  4c8b0ccb                 mov r9, qword ptr [rbx + rcx*8]
00973487  4183f805                 cmp r8d, 5
0097348b  0f87ae000000             ja 0x97353f
00973491  4963c8                   movsxd rcx, r8d
00973494  8b948f08379700           mov edx, dword ptr [rdi + rcx*4 + 0x973708]
0097349b  4803d7                   add rdx, rdi
0097349e  ffe2                     jmp rdx
009734a0  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734a4  0f94c1                   sete cl
009734a7  eb22                     jmp 0x9734cb
009734a9  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734ad  0f9cc1                   setl cl
009734b0  eb19                     jmp 0x9734cb
009734b2  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734b6  0f9fc1                   setg cl
009734b9  eb10                     jmp 0x9734cb
009734bb  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734bf  0f9ec1                   setle cl
009734c2  eb07                     jmp 0x9734cb
009734c4  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734c8  0f9dc1                   setge cl
009734cb  84c9                     test cl, cl
009734cd  7570                     jne 0x97353f
009734cf  41ffc2                   inc r10d
009734d2  443bd0                   cmp r10d, eax
009734d5  72a9                     jb 0x973480
009734d7  45893e                   mov dword ptr [r14], r15d
009734da  418bc7                   mov eax, r15d
009734dd  458bcf                   mov r9d, r15d
009734e0  458bc1                   mov r8d, r9d
009734e3  4584e4                   test r12b, r12b
009734e6  0f8428010000             je 0x973614
009734ec  85c0                     test eax, eax
009734ee  0f8420010000             je 0x973614
009734f4  4c8b5e30                 mov r11, qword ptr [rsi + 0x30]
009734f8  498b7e20                 mov rdi, qword ptr [r14 + 0x20]
009734fc  4c8d25fdca68ff           lea r12, [rip - 0x973503]
00973503  0f1f4000                 nop dword ptr [rax]
00973507  660f1f840000000000       nop word ptr [rax + rax]
00973510  458bd1                   mov r10d, r9d
00973513  ffc8                     dec eax
00973515  448bc8                   mov r9d, eax
00973518  488b1cc7                 mov rbx, qword ptr [rdi + rax*8]
0097351c  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00973520  83e107                   and ecx, 7
00973523  458bc2                   mov r8d, r10d
00973526  83f905                   cmp ecx, 5
00973529  0f87e5000000             ja 0x973614
0097352f  4863c9                   movsxd rcx, ecx
00973532  418b948c20379700         mov edx, dword ptr [r12 + rcx*4 + 0x973720]
0097353a  4903d4                   add rdx, r12
0097353d  ffe2                     jmp rdx
0097353f  443bd0                   cmp r10d, eax
00973542  7393                     jae 0x9734d7
00973544  448bc8                   mov r9d, eax
00973547  4585d2                   test r10d, r10d
0097354a  7494                     je 0x9734e0
0097354c  452bca                   sub r9d, r10d
0097354f  458bdf                   mov r11d, r15d
00973552  7478                     je 0x9735cc
00973554  498bd7                   mov rdx, r15
00973557  498bdf                   mov rbx, r15
0097355a  498bff                   mov rdi, r15
0097355d  0f1f00                   nop dword ptr [rax]
00973560  438d0413                 lea eax, [r11 + r10]
00973564  448bc0                   mov r8d, eax
00973567  498b4e20                 mov rcx, qword ptr [r14 + 0x20]
0097356b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
0097356f  4889040f                 mov qword ptr [rdi + rcx], rax
00973573  498b4e30                 mov rcx, qword ptr [r14 + 0x30]
00973577  428b0481                 mov eax, dword ptr [rcx + r8*4]
0097357b  89040b                   mov dword ptr [rbx + rcx], eax
0097357e  498b4e28                 mov rcx, qword ptr [r14 + 0x28]
00973582  428b0481                 mov eax, dword ptr [rcx + r8*4]
00973586  89040b                   mov dword ptr [rbx + rcx], eax
00973589  4d03c0                   add r8, r8
0097358c  498b4638                 mov rax, qword ptr [r14 + 0x38]
00973590  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00973595  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00973599  498b4648                 mov rax, qword ptr [r14 + 0x48]
0097359d  4885c0                   test rax, rax
009735a0  7409                     je 0x9735ab
009735a2  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
009735a7  0f110410                 movups xmmword ptr [rax + rdx], xmm0
009735ab  498b4660                 mov rax, qword ptr [r14 + 0x60]
009735af  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
009735b4  0f110410                 movups xmmword ptr [rax + rdx], xmm0
009735b8  41ffc3                   inc r11d
009735bb  4883c708                 add rdi, 8
009735bf  4883c304                 add rbx, 4
009735c3  4883c210                 add rdx, 0x10
009735c7  453bd9                   cmp r11d, r9d
009735ca  7294                     jb 0x973560
009735cc  45890e                   mov dword ptr [r14], r9d
009735cf  418bc1                   mov eax, r9d
009735d2  e909ffffff               jmp 0x9734e0
009735d7  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735db  0f94c1                   sete cl
009735de  eb22                     jmp 0x973602
009735e0  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735e4  0f9cc1                   setl cl
009735e7  eb19                     jmp 0x973602
009735e9  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735ed  0f9fc1                   setg cl
009735f0  eb10                     jmp 0x973602
009735f2  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735f6  0f9ec1                   setle cl
009735f9  eb07                     jmp 0x973602
009735fb  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735ff  0f9dc1                   setge cl
00973602  84c9                     test cl, cl
00973604  750e                     jne 0x973614
00973606  418906                   mov dword ptr [r14], eax
00973609  448bc0                   mov r8d, eax
0097360c  85c0                     test eax, eax
0097360e  0f85fcfeffff             jne 0x973510
00973614  80be4925000000           cmp byte ptr [rsi + 0x2549], 0
0097361b  7463                     je 0x973680
0097361d  458b06                   mov r8d, dword ptr [r14]
00973620  4585c0                   test r8d, r8d
00973623  745b                     je 0x973680
00973625  c6864825000001           mov byte ptr [rsi + 0x2548], 1
0097362c  418b1e                   mov ebx, dword ptr [r14]
0097362f  ffcb                     dec ebx
00973631  488bbe40250000           mov rdi, qword ptr [rsi + 0x2540]
00973638  4d8bc6                   mov r8, r14
0097363b  8bd3                     mov edx, ebx
0097363d  488bcf                   mov rcx, rdi
00973640  e85b93ffff               call 0x96c9a0
00973645  448bc3                   mov r8d, ebx
00973648  4d03c0                   add r8, r8
0097364b  498b5660                 mov rdx, qword ptr [r14 + 0x60]
0097364f  8b0f                     mov ecx, dword ptr [rdi]
00973651  ffc9                     dec ecx
00973653  4803c9                   add rcx, rcx
00973656  488b4760                 mov rax, qword ptr [rdi + 0x60]
0097365a  420f1004c2               movups xmm0, xmmword ptr [rdx + r8*8]
0097365f  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
00973663  41ff0e                   dec dword ptr [r14]
00973666  41c6451001               mov byte ptr [r13 + 0x10], 1
0097366b  488b8640250000           mov rax, qword ptr [rsi + 0x2540]
00973672  488b4820                 mov rcx, qword ptr [rax + 0x20]
00973676  488b01                   mov rax, qword ptr [rcx]
00973679  49894518                 mov qword ptr [r13 + 0x18], rax
0097367d  458b06                   mov r8d, dword ptr [r14]
00973680  8b442420                 mov eax, dword ptr [rsp + 0x20]
00973684  4103c0                   add eax, r8d
00973687  89442420                 mov dword ptr [rsp + 0x20], eax
0097368b  7521                     jne 0x9736ae
0097368d  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
00973690  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00973694  e995fbffff               jmp 0x97322e
00973699  c7462002000000           mov dword ptr [rsi + 0x20], 2
009736a0  41837d0000               cmp dword ptr [r13], 0
009736a5  410f95c7                 setne r15b
009736a9  418bc7                   mov eax, r15d
009736ac  eb0f                     jmp 0x9736bd
009736ae  41894500                 mov dword ptr [r13], eax
009736b2  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
009736b6  f6d9                     neg cl
009736b8  1bc0                     sbb eax, eax
009736ba  83c002                   add eax, 2
009736bd  488b9c2430010000         mov rbx, qword ptr [rsp + 0x130]
009736c5  4881c4e0000000           add rsp, 0xe0
009736cc  415f                     pop r15
009736ce  415e                     pop r14
009736d0  415d                     pop r13
009736d2  415c                     pop r12
009736d4  5f                       pop rdi
009736d5  5e                       pop rsi
009736d6  5d                       pop rbp
009736d7  c3                       ret
009736d8  9b                       wait
009736d9  3397006e3397             xor edx, dword ptr [rdi - 0x68cc9200]
009736df  007733                   add byte ptr [rdi + 0x33], dh
009736e2  97                       xchg edi, eax
009736e3  008933970080             add byte ptr [rcx - 0x7fff68cd], cl
009736e9  339700923397             xor edx, dword ptr [rdi - 0x68cc6e00]
009736ef  00f0                     add al, dh
009736f1  339700be3397             xor edx, dword ptr [rdi - 0x68cc4200]
009736f7  00c8                     add al, cl
009736f9  339700dc3397             xor edx, dword ptr [rdi - 0x68cc2400]
009736ff  00d2                     add dl, dl
00973701  339700e63397             xor edx, dword ptr [rdi - 0x68cc1a00]
00973707  003f                     add byte ptr [rdi], bh
00973709  359700a034               xor eax, 0x34a00097
0097370e  97                       xchg edi, eax
0097370f  00a9349700bb             add byte ptr [rcx - 0x44ff68cc], ch
00973715  3497                     xor al, 0x97
00973717  00b2349700c4             add byte ptr [rdx - 0x3bff68cc], dh
0097371d  3497                     xor al, 0x97
0097371f  001436                   add byte ptr [rsi + rsi], dl
00973722  97                       xchg edi, eax
00973723  00d7                     add bh, dl
00973725  359700e035               xor eax, 0x35e00097
0097372a  97                       xchg edi, eax
0097372b  00f2                     add dl, dh
0097372d  359700e935               xor eax, 0x35e90097
00973732  97                       xchg edi, eax
00973733  00fb                     add bl, bh
