; attention_trace
; sqllang.dll, primary RVA 0xb06ef0, 981 bytes in 6 chunk(s)

; chunk at RVA 0xb06ef0 (123 bytes)
00b06ef0  4055                     push rbp
00b06ef2  57                       push rdi
00b06ef3  4156                     push r14
00b06ef5  488dac2440feffff         lea rbp, [rsp - 0x1c0]
00b06efd  4881ecc0020000           sub rsp, 0x2c0
00b06f04  803dad9bff0100           cmp byte ptr [rip + 0x1ff9bad], 0
00b06f0b  488bfa                   mov rdi, rdx
00b06f0e  4c8b7120                 mov r14, qword ptr [rcx + 0x20]
00b06f12  7510                     jne 0xb06f24
00b06f14  488b05751dfd01           mov rax, qword ptr [rip + 0x1fd1d75]
00b06f1b  f680c405000008           test byte ptr [rax + 0x5c4], 8
00b06f22  7417                     je 0xb06f3b
00b06f24  488b4118                 mov rax, qword ptr [rcx + 0x18]
00b06f28  4885c0                   test rax, rax
00b06f2b  740e                     je 0xb06f3b
00b06f2d  0fbf5010                 movsx edx, word ptr [rax + 0x10]
00b06f31  b9e7650000               mov ecx, 0x65e7
00b06f36  e81599f800               call 0x1a90850
00b06f3b  4d8b4e30                 mov r9, qword ptr [r14 + 0x30]
00b06f3f  48899c24f8020000         mov qword ptr [rsp + 0x2f8], rbx
00b06f47  4d85c9                   test r9, r9
00b06f4a  0f8469030000             je 0xb072b9
00b06f50  49837e2800               cmp qword ptr [r14 + 0x28], 0
00b06f55  0f845e030000             je 0xb072b9
00b06f5b  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00b06f64  488b050d403c01           mov rax, qword ptr [rip + 0x13c400d]

; chunk at RVA 0xb06f6b (503 bytes)
00b06f6b  4c89a424b0020000         mov qword ptr [rsp + 0x2b0], r12
00b06f73  4c89ac24a8020000         mov qword ptr [rsp + 0x2a8], r13
00b06f7b  4c89bc24a0020000         mov qword ptr [rsp + 0x2a0], r15
00b06f83  8b08                     mov ecx, dword ptr [rax]
00b06f85  488b05f43f3c01           mov rax, qword ptr [rip + 0x13c3ff4]
00b06f8c  8b10                     mov edx, dword ptr [rax]
00b06f8e  490314c8                 add rdx, qword ptr [r8 + rcx*8]
00b06f92  488b8200010000           mov rax, qword ptr [rdx + 0x100]
00b06f99  4c894a08                 mov qword ptr [rdx + 8], r9
00b06f9d  488b4040                 mov rax, qword ptr [rax + 0x40]
00b06fa1  4c894808                 mov qword ptr [rax + 8], r9
00b06fa5  498b4e28                 mov rcx, qword ptr [r14 + 0x28]
00b06fa9  e892b14fff               call 0x2140
00b06fae  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00b06fb7  488b05ba3f3c01           mov rax, qword ptr [rip + 0x13c3fba]
00b06fbe  8b10                     mov edx, dword ptr [rax]
00b06fc0  488b05b93f3c01           mov rax, qword ptr [rip + 0x13c3fb9]
00b06fc7  8b08                     mov ecx, dword ptr [rax]
00b06fc9  498b04d0                 mov rax, qword ptr [r8 + rdx*8]
00b06fcd  4533c0                   xor r8d, r8d
00b06fd0  33d2                     xor edx, edx
00b06fd2  488b5c0850               mov rbx, qword ptr [rax + rcx + 0x50]
00b06fd7  488d8de0010000           lea rcx, [rbp + 0x1e0]
00b06fde  ff15e40dfd01             call qword ptr [rip + 0x1fd0de4]
00b06fe4  488b85e0010000           mov rax, qword ptr [rbp + 0x1e0]
00b06feb  49bccdcccccccccccccc     movabs r12, 0xcccccccccccccccd
00b06ff5  488983e8000000           mov qword ptr [rbx + 0xe8], rax
00b06ffc  33db                     xor ebx, ebx
00b06ffe  f7055ceafd0100000200     test dword ptr [rip + 0x1fdea5c], 0x20000
00b07008  448d6b01                 lea r13d, [rbx + 1]
00b0700c  4c8d7bff                 lea r15, [rbx - 1]
00b07010  0f84d5000000             je 0xb070eb
00b07016  488d442460               lea rax, [rsp + 0x60]
00b0701b  c744243800000100         mov dword ptr [rsp + 0x38], 0x10000
00b07023  4889442448               mov qword ptr [rsp + 0x48], rax
00b07028  488d442470               lea rax, [rsp + 0x70]
00b0702d  4889442450               mov qword ptr [rsp + 0x50], rax
00b07032  488d8590010000           lea rax, [rbp + 0x190]
00b07039  4889442460               mov qword ptr [rsp + 0x60], rax
00b0703e  488b05a3353c01           mov rax, qword ptr [rip + 0x13c35a3]
00b07045  895c2440                 mov dword ptr [rsp + 0x40], ebx
00b07049  48899d80010000           mov qword ptr [rbp + 0x180], rbx
00b07050  48895c2458               mov qword ptr [rsp + 0x58], rbx
00b07055  48899d88010000           mov qword ptr [rbp + 0x188], rbx
00b0705c  48c74424680c000000       mov qword ptr [rsp + 0x68], 0xc
00b07065  3918                     cmp dword ptr [rax], ebx
00b07067  7416                     je 0xb0707f
00b07069  488d8de8010000           lea rcx, [rbp + 0x1e8]
00b07070  ff15b2243c01             call qword ptr [rip + 0x13c24b2]
00b07076  488b8de8010000           mov rcx, qword ptr [rbp + 0x1e8]
00b0707d  eb08                     jmp 0xb07087
00b0707f  488b0c250800fe7f         mov rcx, qword ptr [0x7ffe0008]
00b07087  488b87a0020000           mov rax, qword ptr [rdi + 0x2a0]
00b0708e  483bc8                   cmp rcx, rax
00b07091  720d                     jb 0xb070a0
00b07093  482bc8                   sub rcx, rax
00b07096  493bcf                   cmp rcx, r15
00b07099  7508                     jne 0xb070a3
00b0709b  498bd7                   mov rdx, r15
00b0709e  eb30                     jmp 0xb070d0
00b070a0  488bcb                   mov rcx, rbx
00b070a3  488b053e353c01           mov rax, qword ptr [rip + 0x13c353e]
00b070aa  3918                     cmp dword ptr [rax], ebx
00b070ac  7418                     je 0xb070c6
00b070ae  4869c140420f00           imul rax, rcx, 0xf4240
00b070b5  488b0d24353c01           mov rcx, qword ptr [rip + 0x13c3524]
00b070bc  33d2                     xor edx, edx
00b070be  48f731                   div qword ptr [rcx]
00b070c1  488bd0                   mov rdx, rax
00b070c4  eb0a                     jmp 0xb070d0
00b070c6  498bc4                   mov rax, r12
00b070c9  48f7e1                   mul rcx
00b070cc  48c1ea03                 shr rdx, 3
00b070d0  418b4654                 mov eax, dword ptr [r14 + 0x54]
00b070d4  488d4c2430               lea rcx, [rsp + 0x30]
00b070d9  898598010000             mov dword ptr [rbp + 0x198], eax
00b070df  48899590010000           mov qword ptr [rbp + 0x190], rdx
00b070e6  e8c52bb1ff               call 0x619cb0
00b070eb  488b05a6323c01           mov rax, qword ptr [rip + 0x13c32a6]
00b070f2  3818                     cmp byte ptr [rax], bl
00b070f4  0f8428010000             je 0xb07222
00b070fa  488b057f1bfd01           mov rax, qword ptr [rip + 0x1fd1b7f]
00b07101  f7403c00000100           test dword ptr [rax + 0x3c], 0x10000
00b07108  0f8414010000             je 0xb07222
00b0710e  488b05633e3c01           mov rax, qword ptr [rip + 0x13c3e63]
00b07115  8b08                     mov ecx, dword ptr [rax]
00b07117  488b05623e3c01           mov rax, qword ptr [rip + 0x13c3e62]
00b0711e  488d14cd00000000         lea rdx, [rcx*8]
00b07126  448b00                   mov r8d, dword ptr [rax]
00b07129  65488b042558000000       mov rax, qword ptr gs:[0x58]
00b07132  488b0c10                 mov rcx, qword ptr [rax + rdx]
00b07136  4a8b440108               mov rax, qword ptr [rcx + r8 + 8]
00b0713b  4885c0                   test rax, rax
00b0713e  0f84de000000             je 0xb07222
00b07144  488b4030                 mov rax, qword ptr [rax + 0x30]
00b07148  4885c0                   test rax, rax
00b0714b  0f84d1000000             je 0xb07222
00b07151  3918                     cmp dword ptr [rax], ebx
00b07153  0f85c9000000             jne 0xb07222
00b07159  65488b042558000000       mov rax, qword ptr gs:[0x58]

; chunk at RVA 0xb07162 (192 bytes)
00b07162  4889b424b8020000         mov qword ptr [rsp + 0x2b8], rsi
00b0716a  488b0c10                 mov rcx, qword ptr [rax + rdx]
00b0716e  4a8b440108               mov rax, qword ptr [rcx + r8 + 8]
00b07173  488b7030                 mov rsi, qword ptr [rax + 0x30]
00b07177  488b056a343c01           mov rax, qword ptr [rip + 0x13c346a]
00b0717e  3918                     cmp dword ptr [rax], ebx
00b07180  7416                     je 0xb07198
00b07182  488d8df0010000           lea rcx, [rbp + 0x1f0]
00b07189  ff1599233c01             call qword ptr [rip + 0x13c2399]
00b0718f  488b8df0010000           mov rcx, qword ptr [rbp + 0x1f0]
00b07196  eb08                     jmp 0xb071a0
00b07198  488b0c250800fe7f         mov rcx, qword ptr [0x7ffe0008]
00b071a0  488b87a0020000           mov rax, qword ptr [rdi + 0x2a0]
00b071a7  483bc8                   cmp rcx, rax
00b071aa  720a                     jb 0xb071b6
00b071ac  482bc8                   sub rcx, rax
00b071af  493bcf                   cmp rcx, r15
00b071b2  7505                     jne 0xb071b9
00b071b4  eb33                     jmp 0xb071e9
00b071b6  488bcb                   mov rcx, rbx
00b071b9  488b0528343c01           mov rax, qword ptr [rip + 0x13c3428]
00b071c0  3918                     cmp dword ptr [rax], ebx
00b071c2  7418                     je 0xb071dc
00b071c4  4869c140420f00           imul rax, rcx, 0xf4240
00b071cb  488b0d0e343c01           mov rcx, qword ptr [rip + 0x13c340e]
00b071d2  33d2                     xor edx, edx
00b071d4  48f731                   div qword ptr [rcx]
00b071d7  4c8bf8                   mov r15, rax
00b071da  eb0d                     jmp 0xb071e9
00b071dc  498bc4                   mov rax, r12
00b071df  48f7e1                   mul rcx
00b071e2  4c8bfa                   mov r15, rdx
00b071e5  49c1ef03                 shr r15, 3
00b071e9  814e0c00200000           or dword ptr [rsi + 0xc], 0x2000
00b071f0  ba10000000               mov edx, 0x10
00b071f5  4c89bef8040000           mov qword ptr [rsi + 0x4f8], r15
00b071fc  418b4654                 mov eax, dword ptr [r14 + 0x54]
00b07200  814e1000000200           or dword ptr [rsi + 0x10], 0x20000
00b07207  894678                   mov dword ptr [rsi + 0x78], eax
00b0720a  488b0d6f1afd01           mov rcx, qword ptr [rip + 0x1fd1a6f]
00b07211  4883c138                 add rcx, 0x38
00b07215  e816cd83ff               call 0x343f30
00b0721a  488bb424b8020000         mov rsi, qword ptr [rsp + 0x2b8]

; chunk at RVA 0xb07222 (86 bytes)
00b07222  498b4e28                 mov rcx, qword ptr [r14 + 0x28]
00b07226  e835ad4fff               call 0x1f60
00b0722b  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00b07234  488b053d3d3c01           mov rax, qword ptr [rip + 0x13c3d3d]
00b0723b  4c8bbc24a0020000         mov r15, qword ptr [rsp + 0x2a0]
00b07243  4c8ba424b0020000         mov r12, qword ptr [rsp + 0x2b0]
00b0724b  8b08                     mov ecx, dword ptr [rax]
00b0724d  488b052c3d3c01           mov rax, qword ptr [rip + 0x13c3d2c]
00b07254  8b10                     mov edx, dword ptr [rax]
00b07256  490314c8                 add rdx, qword ptr [r8 + rcx*8]
00b0725a  488b8200010000           mov rax, qword ptr [rdx + 0x100]
00b07261  48895a08                 mov qword ptr [rdx + 8], rbx
00b07265  488b4040                 mov rax, qword ptr [rax + 0x40]
00b07269  48895808                 mov qword ptr [rax + 8], rbx
00b0726d  488b0514313c01           mov rax, qword ptr [rip + 0x13c3114]
00b07274  3818                     cmp byte ptr [rax], bl
00b07276  741e                     je 0xb07296

; chunk at RVA 0xb07278 (45 bytes)
00b07278  488b0d011afd01           mov rcx, qword ptr [rip + 0x1fd1a01]
00b0727f  ba0f000000               mov edx, 0xf
00b07284  4d8bcd                   mov r9, r13
00b07287  48895c2420               mov qword ptr [rsp + 0x20], rbx
00b0728c  448d4231                 lea r8d, [rdx + 0x31]
00b07290  ff15aa0bfd01             call qword ptr [rip + 0x1fd0baa]
00b07296  4c8bac24a8020000         mov r13, qword ptr [rsp + 0x2a8]
00b0729e  48899fa0020000           mov qword ptr [rdi + 0x2a0], rbx

; chunk at RVA 0xb072a5 (32 bytes)
00b072a5  488b9c24f8020000         mov rbx, qword ptr [rsp + 0x2f8]
00b072ad  4881c4c0020000           add rsp, 0x2c0
00b072b4  415e                     pop r14
00b072b6  5f                       pop rdi
00b072b7  5d                       pop rbp
00b072b8  c3                       ret
00b072b9  33db                     xor ebx, ebx
00b072bb  48899fa0020000           mov qword ptr [rdi + 0x2a0], rbx
00b072c2  ebe1                     jmp 0xb072a5
00b072c4  cc                       int3
