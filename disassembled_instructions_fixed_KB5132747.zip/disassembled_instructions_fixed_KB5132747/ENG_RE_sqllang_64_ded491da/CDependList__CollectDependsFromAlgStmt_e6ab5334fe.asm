; CDependList::CollectDependsFromAlgStmt
; sqllang.dll, primary RVA 0x28a950, 508 bytes in 1 chunk(s)

; chunk at RVA 0x28a950 (508 bytes)
0028a950  48895c2408               mov qword ptr [rsp + 8], rbx
0028a955  48896c2410               mov qword ptr [rsp + 0x10], rbp
0028a95a  4889742418               mov qword ptr [rsp + 0x18], rsi
0028a95f  57                       push rdi
0028a960  4154                     push r12
0028a962  4155                     push r13
0028a964  4156                     push r14
0028a966  4157                     push r15
0028a968  4881ec90000000           sub rsp, 0x90
0028a96f  4c8bbc2400010000         mov r15, qword ptr [rsp + 0x100]
0028a977  410fb6f0                 movzx esi, r8b
0028a97b  448bb42408010000         mov r14d, dword ptr [rsp + 0x108]
0028a983  4c8bea                   mov r13, rdx
0028a986  488bf9                   mov rdi, rcx
0028a989  498bd7                   mov rdx, r15
0028a98c  458bc6                   mov r8d, r14d
0028a98f  488d4c2460               lea rcx, [rsp + 0x60]
0028a994  458be1                   mov r12d, r9d
0028a997  e86430d8ff               call 0xda00
0028a99c  488bac24e8000000         mov rbp, qword ptr [rsp + 0xe8]
0028a9a4  33db                     xor ebx, ebx
0028a9a6  899c2410010000           mov dword ptr [rsp + 0x110], ebx
0028a9ad  8b4548                   mov eax, dword ptr [rbp + 0x48]
0028a9b0  055effffff               add eax, 0xffffff5e
0028a9b5  3deb000000               cmp eax, 0xeb
0028a9ba  776f                     ja 0x28aa2b
0028a9bc  488d153d56d7ff           lea rdx, [rip - 0x28a9c3]
0028a9c3  4898                     cdqe
0028a9c5  0fb6840260aa2800         movzx eax, byte ptr [rdx + rax + 0x28aa60]
0028a9cd  8b8c8250aa2800           mov ecx, dword ptr [rdx + rax*4 + 0x28aa50]
0028a9d4  4803ca                   add rcx, rdx
0028a9d7  ffe1                     jmp rcx
0028a9d9  cc                       int3
0028a9da  488b4d18                 mov rcx, qword ptr [rbp + 0x18]
0028a9de  4885c9                   test rcx, rcx
0028a9e1  0f8530f55300             jne 0x7c9f17
0028a9e7  8b8424f0000000           mov eax, dword ptr [rsp + 0xf0]
0028a9ee  885c2450                 mov byte ptr [rsp + 0x50], bl
0028a9f2  c644244801               mov byte ptr [rsp + 0x48], 1
0028a9f7  89442440                 mov dword ptr [rsp + 0x40], eax
0028a9fb  488b4510                 mov rax, qword ptr [rbp + 0x10]
0028a9ff  4889442438               mov qword ptr [rsp + 0x38], rax
0028aa04  458bcc                   mov r9d, r12d
0028aa07  8b8424e0000000           mov eax, dword ptr [rsp + 0xe0]
0028aa0e  440fb6c6                 movzx r8d, sil
0028aa12  4489742430               mov dword ptr [rsp + 0x30], r14d
0028aa17  498bd5                   mov rdx, r13
0028aa1a  4c897c2428               mov qword ptr [rsp + 0x28], r15
0028aa1f  488bcf                   mov rcx, rdi
0028aa22  89442420                 mov dword ptr [rsp + 0x20], eax
0028aa26  e8d5ebffff               call 0x289600
0028aa2b  4c8d9c2490000000         lea r11, [rsp + 0x90]
0028aa33  498b5b30                 mov rbx, qword ptr [r11 + 0x30]
0028aa37  498b6b38                 mov rbp, qword ptr [r11 + 0x38]
0028aa3b  498b7340                 mov rsi, qword ptr [r11 + 0x40]
0028aa3f  498be3                   mov rsp, r11
0028aa42  415f                     pop r15
0028aa44  415e                     pop r14
0028aa46  415d                     pop r13
0028aa48  415c                     pop r12
0028aa4a  5f                       pop rdi
0028aa4b  c3                       ret
0028aa4c  90                       nop
0028aa4d  90                       nop
0028aa4e  90                       nop
0028aa4f  90                       nop
0028aa50  869e7c00daa9             xchg byte ptr [rsi - 0x5625ff84], bl
0028aa56  2800                     sub byte ptr [rax], al
0028aa58  059e7c002b               add eax, 0x2b007c9e
0028aa5d  aa                       stosb byte ptr [rdi], al
0028aa5e  2800                     sub byte ptr [rax], al
0028aa60  0003                     add byte ptr [rbx], al
0028aa62  0303                     add eax, dword ptr [rbx]
0028aa64  0303                     add eax, dword ptr [rbx]
0028aa66  0303                     add eax, dword ptr [rbx]
0028aa68  0303                     add eax, dword ptr [rbx]
0028aa6a  0303                     add eax, dword ptr [rbx]
0028aa6c  0303                     add eax, dword ptr [rbx]
0028aa6e  0303                     add eax, dword ptr [rbx]
0028aa70  0303                     add eax, dword ptr [rbx]
0028aa72  0303                     add eax, dword ptr [rbx]
0028aa74  0303                     add eax, dword ptr [rbx]
0028aa76  0303                     add eax, dword ptr [rbx]
0028aa78  0303                     add eax, dword ptr [rbx]
0028aa7a  0303                     add eax, dword ptr [rbx]
0028aa7c  0303                     add eax, dword ptr [rbx]
0028aa7e  0001                     add byte ptr [rcx], al
0028aa80  0101                     add dword ptr [rcx], eax
0028aa82  0101                     add dword ptr [rcx], eax
0028aa84  0303                     add eax, dword ptr [rbx]
0028aa86  0303                     add eax, dword ptr [rbx]
0028aa88  0303                     add eax, dword ptr [rbx]
0028aa8a  0303                     add eax, dword ptr [rbx]
0028aa8c  0303                     add eax, dword ptr [rbx]
0028aa8e  0303                     add eax, dword ptr [rbx]
0028aa90  0303                     add eax, dword ptr [rbx]
0028aa92  0303                     add eax, dword ptr [rbx]
0028aa94  0303                     add eax, dword ptr [rbx]
0028aa96  0303                     add eax, dword ptr [rbx]
0028aa98  0300                     add eax, dword ptr [rax]
0028aa9a  0303                     add eax, dword ptr [rbx]
0028aa9c  0303                     add eax, dword ptr [rbx]
0028aa9e  0203                     add al, byte ptr [rbx]
0028aaa0  0303                     add eax, dword ptr [rbx]
0028aaa2  0303                     add eax, dword ptr [rbx]
0028aaa4  0303                     add eax, dword ptr [rbx]
0028aaa6  0303                     add eax, dword ptr [rbx]
0028aaa8  0303                     add eax, dword ptr [rbx]
0028aaaa  0303                     add eax, dword ptr [rbx]
0028aaac  0303                     add eax, dword ptr [rbx]
0028aaae  0303                     add eax, dword ptr [rbx]
0028aab0  0303                     add eax, dword ptr [rbx]
0028aab2  0303                     add eax, dword ptr [rbx]
0028aab4  0300                     add eax, dword ptr [rax]
0028aab6  0003                     add byte ptr [rbx], al
0028aab8  0300                     add eax, dword ptr [rax]
0028aaba  0003                     add byte ptr [rbx], al
0028aabc  0303                     add eax, dword ptr [rbx]
0028aabe  0303                     add eax, dword ptr [rbx]
0028aac0  0303                     add eax, dword ptr [rbx]
0028aac2  0303                     add eax, dword ptr [rbx]
0028aac4  0303                     add eax, dword ptr [rbx]
0028aac6  0303                     add eax, dword ptr [rbx]
0028aac8  0303                     add eax, dword ptr [rbx]
0028aaca  0303                     add eax, dword ptr [rbx]
0028aacc  0303                     add eax, dword ptr [rbx]
0028aace  0303                     add eax, dword ptr [rbx]
0028aad0  0303                     add eax, dword ptr [rbx]
0028aad2  0303                     add eax, dword ptr [rbx]
0028aad4  0301                     add eax, dword ptr [rcx]
0028aad6  0303                     add eax, dword ptr [rbx]
0028aad8  0303                     add eax, dword ptr [rbx]
0028aada  0303                     add eax, dword ptr [rbx]
0028aadc  0303                     add eax, dword ptr [rbx]
0028aade  0303                     add eax, dword ptr [rbx]
0028aae0  0303                     add eax, dword ptr [rbx]
0028aae2  0303                     add eax, dword ptr [rbx]
0028aae4  0303                     add eax, dword ptr [rbx]
0028aae6  0303                     add eax, dword ptr [rbx]
0028aae8  0303                     add eax, dword ptr [rbx]
0028aaea  0303                     add eax, dword ptr [rbx]
0028aaec  0303                     add eax, dword ptr [rbx]
0028aaee  0303                     add eax, dword ptr [rbx]
0028aaf0  0303                     add eax, dword ptr [rbx]
0028aaf2  0303                     add eax, dword ptr [rbx]
0028aaf4  0303                     add eax, dword ptr [rbx]
0028aaf6  0303                     add eax, dword ptr [rbx]
0028aaf8  0303                     add eax, dword ptr [rbx]
0028aafa  0303                     add eax, dword ptr [rbx]
0028aafc  0303                     add eax, dword ptr [rbx]
0028aafe  0303                     add eax, dword ptr [rbx]
0028ab00  0303                     add eax, dword ptr [rbx]
0028ab02  0303                     add eax, dword ptr [rbx]
0028ab04  0303                     add eax, dword ptr [rbx]
0028ab06  0303                     add eax, dword ptr [rbx]
0028ab08  0303                     add eax, dword ptr [rbx]
0028ab0a  0303                     add eax, dword ptr [rbx]
0028ab0c  0303                     add eax, dword ptr [rbx]
0028ab0e  0303                     add eax, dword ptr [rbx]
0028ab10  0303                     add eax, dword ptr [rbx]
0028ab12  0303                     add eax, dword ptr [rbx]
0028ab14  0303                     add eax, dword ptr [rbx]
0028ab16  0303                     add eax, dword ptr [rbx]
0028ab18  0303                     add eax, dword ptr [rbx]
0028ab1a  0303                     add eax, dword ptr [rbx]
0028ab1c  0303                     add eax, dword ptr [rbx]
0028ab1e  0303                     add eax, dword ptr [rbx]
0028ab20  0303                     add eax, dword ptr [rbx]
0028ab22  0303                     add eax, dword ptr [rbx]
0028ab24  0303                     add eax, dword ptr [rbx]
0028ab26  0303                     add eax, dword ptr [rbx]
0028ab28  0303                     add eax, dword ptr [rbx]
0028ab2a  0303                     add eax, dword ptr [rbx]
0028ab2c  0303                     add eax, dword ptr [rbx]
0028ab2e  0303                     add eax, dword ptr [rbx]
0028ab30  0303                     add eax, dword ptr [rbx]
0028ab32  0303                     add eax, dword ptr [rbx]
0028ab34  0303                     add eax, dword ptr [rbx]
0028ab36  0303                     add eax, dword ptr [rbx]
0028ab38  0303                     add eax, dword ptr [rbx]
0028ab3a  0303                     add eax, dword ptr [rbx]
0028ab3c  0303                     add eax, dword ptr [rbx]
0028ab3e  0303                     add eax, dword ptr [rbx]
0028ab40  0303                     add eax, dword ptr [rbx]
0028ab42  0303                     add eax, dword ptr [rbx]
0028ab44  0303                     add eax, dword ptr [rbx]
0028ab46  0303                     add eax, dword ptr [rbx]
0028ab48  0303                     add eax, dword ptr [rbx]
0028ab4a  0300                     add eax, dword ptr [rax]
