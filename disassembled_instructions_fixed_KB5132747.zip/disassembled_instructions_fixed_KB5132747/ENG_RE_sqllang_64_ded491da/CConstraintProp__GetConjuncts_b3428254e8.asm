; CConstraintProp::GetConjuncts
; sqllang.dll, primary RVA 0x6f7d0, 223 bytes in 5 chunk(s)

; chunk at RVA 0x6f7d0 (72 bytes)
0006f7d0  48894c2408               mov qword ptr [rsp + 8], rcx
0006f7d5  53                       push rbx
0006f7d6  57                       push rdi
0006f7d7  4155                     push r13
0006f7d9  4157                     push r15
0006f7db  4883ec38                 sub rsp, 0x38
0006f7df  4c8bf9                   mov r15, rcx
0006f7e2  488bda                   mov rbx, rdx
0006f7e5  488d0d740bac02           lea rcx, [rip + 0x2ac0b74]
0006f7ec  e82f3bffff               call 0x63320
0006f7f1  4533ed                   xor r13d, r13d
0006f7f4  488bf8                   mov rdi, rax
0006f7f7  ff00                     inc dword ptr [rax]
0006f7f9  83380a                   cmp dword ptr [rax], 0xa
0006f7fc  0f835f430600             jae 0xd3b61
0006f802  498b7f10                 mov rdi, qword ptr [r15 + 0x10]
0006f806  488bcf                   mov rcx, rdi
0006f809  488b07                   mov rax, qword ptr [rdi]
0006f80c  ff5018                   call qword ptr [rax + 0x18]
0006f80f  83f859                   cmp eax, 0x59
0006f812  0f8403580000             je 0x7501b

; chunk at RVA 0x75025 (17 bytes)
00075025  4c89642478               mov qword ptr [rsp + 0x78], r12
0007502a  418bfd                   mov edi, r13d
0007502d  458b6718                 mov r12d, dword ptr [r15 + 0x18]
00075031  4585e4                   test r12d, r12d
00075034  7476                     je 0x750ac

; chunk at RVA 0x75036 (118 bytes)
00075036  48896c2468               mov qword ptr [rsp + 0x68], rbp
0007503b  4889742470               mov qword ptr [rsp + 0x70], rsi
00075040  4c89742430               mov qword ptr [rsp + 0x30], r14
00075045  0f1f00                   nop dword ptr [rax]
00075048  0f1f840000000000         nop dword ptr [rax + rax]
00075050  498b4720                 mov rax, qword ptr [r15 + 0x20]
00075054  4863cf                   movsxd rcx, edi
00075057  488b2cc8                 mov rbp, qword ptr [rax + rcx*8]
0007505b  488b7510                 mov rsi, qword ptr [rbp + 0x10]
0007505f  488bce                   mov rcx, rsi
00075062  488b06                   mov rax, qword ptr [rsi]
00075065  ff5018                   call qword ptr [rax + 0x18]
00075068  83f859                   cmp eax, 0x59
0007506b  0f84fc0f0e00             je 0x15606d
00075071  8b7320                   mov esi, dword ptr [rbx + 0x20]
00075074  4c396b28                 cmp qword ptr [rbx + 0x28], r13
00075078  0f8429640500             je 0xcb4a7
0007507e  8b431c                   mov eax, dword ptr [rbx + 0x1c]
00075081  3bc6                     cmp eax, esi
00075083  0f83c7695501             jae 0x15cba50
00075089  8bc8                     mov ecx, eax
0007508b  488b4328                 mov rax, qword ptr [rbx + 0x28]
0007508f  48892cc8                 mov qword ptr [rax + rcx*8], rbp
00075093  ff431c                   inc dword ptr [rbx + 0x1c]
00075096  ffc7                     inc edi
00075098  413bfc                   cmp edi, r12d
0007509b  72b3                     jb 0x75050
0007509d  4c8b742430               mov r14, qword ptr [rsp + 0x30]
000750a2  488b742470               mov rsi, qword ptr [rsp + 0x70]
000750a7  488b6c2468               mov rbp, qword ptr [rsp + 0x68]

; chunk at RVA 0x750ac (5 bytes)
000750ac  4c8b642478               mov r12, qword ptr [rsp + 0x78]

; chunk at RVA 0x750b1 (11 bytes)
000750b1  4883c438                 add rsp, 0x38
000750b5  415f                     pop r15
000750b7  415d                     pop r13
000750b9  5f                       pop rdi
000750ba  5b                       pop rbx
000750bb  c3                       ret
