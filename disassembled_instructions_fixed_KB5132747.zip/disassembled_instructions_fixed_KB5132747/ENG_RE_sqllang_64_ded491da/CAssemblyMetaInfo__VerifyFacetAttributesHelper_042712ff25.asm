; CAssemblyMetaInfo::VerifyFacetAttributesHelper
; sqllang.dll, primary RVA 0x6d3dc0, 1534 bytes in 8 chunk(s)

; chunk at RVA 0x6d3dc0 (141 bytes)
006d3dc0  48895c2410               mov qword ptr [rsp + 0x10], rbx
006d3dc5  57                       push rdi
006d3dc6  4883ec60                 sub rsp, 0x60
006d3dca  418b4014                 mov eax, dword ptr [r8 + 0x14]
006d3dce  4d8bd1                   mov r10, r9
006d3dd1  83e007                   and eax, 7
006d3dd4  498bf8                   mov rdi, r8
006d3dd7  488bda                   mov rbx, rdx
006d3dda  3c06                     cmp al, 6
006d3ddc  7462                     je 0x6d3e40
006d3dde  498b4008                 mov rax, qword ptr [r8 + 8]
006d3de2  4c8b5a18                 mov r11, qword ptr [rdx + 0x18]
006d3de6  418b4810                 mov ecx, dword ptr [r8 + 0x10]
006d3dea  448b5230                 mov r10d, dword ptr [rdx + 0x30]
006d3dee  03c9                     add ecx, ecx
006d3df0  4889442440               mov qword ptr [rsp + 0x40], rax
006d3df5  4503d2                   add r10d, r10d
006d3df8  488b4228                 mov rax, qword ptr [rdx + 0x28]
006d3dfc  ba10000000               mov edx, 0x10
006d3e01  458b8ba0000000           mov r9d, dword ptr [r11 + 0xa0]
006d3e08  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d3e0c  4503c9                   add r9d, r9d
006d3e0f  4889442430               mov qword ptr [rsp + 0x30], rax
006d3e14  b995180000               mov ecx, 0x1895
006d3e19  498b8398000000           mov rax, qword ptr [r11 + 0x98]
006d3e20  448d42f1                 lea r8d, [rdx - 0xf]
006d3e24  4489542428               mov dword ptr [rsp + 0x28], r10d
006d3e29  4889442420               mov qword ptr [rsp + 0x20], rax
006d3e2e  e8ad90bdff               call 0x2acee0
006d3e33  33c0                     xor eax, eax
006d3e35  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d3e3a  4883c460                 add rsp, 0x60
006d3e3e  5f                       pop rdi
006d3e3f  c3                       ret
006d3e40  4180790800               cmp byte ptr [r9 + 8], 0
006d3e45  488b942490000000         mov rdx, qword ptr [rsp + 0x90]

; chunk at RVA 0x6d3e4d (331 bytes)
006d3e4d  4889742470               mov qword ptr [rsp + 0x70], rsi
006d3e52  beffffffff               mov esi, 0xffffffff
006d3e57  745b                     je 0x6d3eb4
006d3e59  8b4a10                   mov ecx, dword ptr [rdx + 0x10]
006d3e5c  83e901                   sub ecx, 1
006d3e5f  742e                     je 0x6d3e8f
006d3e61  83e901                   sub ecx, 1
006d3e64  741c                     je 0x6d3e82
006d3e66  83f901                   cmp ecx, 1
006d3e69  752a                     jne 0x6d3e95
006d3e6b  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d3e6e  83e933                   sub ecx, 0x33
006d3e71  743c                     je 0x6d3eaf
006d3e73  83e901                   sub ecx, 1
006d3e76  7437                     je 0x6d3eaf
006d3e78  83e901                   sub ecx, 1
006d3e7b  7432                     je 0x6d3eaf
006d3e7d  83f901                   cmp ecx, 1
006d3e80  eb11                     jmp 0x6d3e93
006d3e82  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d3e85  83e938                   sub ecx, 0x38
006d3e88  7425                     je 0x6d3eaf
006d3e8a  83f901                   cmp ecx, 1
006d3e8d  eb04                     jmp 0x6d3e93
006d3e8f  837a141c                 cmp dword ptr [rdx + 0x14], 0x1c
006d3e93  741a                     je 0x6d3eaf
006d3e95  488d057c40cf01           lea rax, [rip + 0x1cf407c]
006d3e9c  4889442450               mov qword ptr [rsp + 0x50], rax
006d3ea1  48c74424481a000000       mov qword ptr [rsp + 0x48], 0x1a
006d3eaa  e943040000               jmp 0x6d42f2
006d3eaf  410fb67109               movzx esi, byte ptr [r9 + 9]
006d3eb4  4533db                   xor r11d, r11d
006d3eb7  4538590c                 cmp byte ptr [r9 + 0xc], r11b
006d3ebb  0f845a010000             je 0x6d401b
006d3ec1  448b4210                 mov r8d, dword ptr [rdx + 0x10]
006d3ec5  418bc8                   mov ecx, r8d
006d3ec8  83e901                   sub ecx, 1
006d3ecb  743a                     je 0x6d3f07
006d3ecd  83e901                   sub ecx, 1
006d3ed0  7423                     je 0x6d3ef5
006d3ed2  83f901                   cmp ecx, 1
006d3ed5  7538                     jne 0x6d3f0f
006d3ed7  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d3eda  448bc9                   mov r9d, ecx
006d3edd  4183e933                 sub r9d, 0x33
006d3ee1  7446                     je 0x6d3f29
006d3ee3  4183e901                 sub r9d, 1
006d3ee7  7440                     je 0x6d3f29
006d3ee9  4183e901                 sub r9d, 1
006d3eed  743a                     je 0x6d3f29
006d3eef  4183f901                 cmp r9d, 1
006d3ef3  eb18                     jmp 0x6d3f0d
006d3ef5  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d3ef8  448bc9                   mov r9d, ecx
006d3efb  4183e938                 sub r9d, 0x38
006d3eff  7428                     je 0x6d3f29
006d3f01  4183f901                 cmp r9d, 1
006d3f05  eb06                     jmp 0x6d3f0d
006d3f07  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d3f0a  83f91c                   cmp ecx, 0x1c
006d3f0d  741a                     je 0x6d3f29
006d3f0f  488d058a42cf01           lea rax, [rip + 0x1cf428a]
006d3f16  4889442450               mov qword ptr [rsp + 0x50], rax
006d3f1b  48c74424480e000000       mov qword ptr [rsp + 0x48], 0xe
006d3f24  e9c9030000               jmp 0x6d42f2
006d3f29  458b4a10                 mov r9d, dword ptr [r10 + 0x10]
006d3f2d  4183f9ff                 cmp r9d, -1
006d3f31  7565                     jne 0x6d3f98
006d3f33  83fe01                   cmp esi, 1
006d3f36  7560                     jne 0x6d3f98
006d3f38  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d3f3c  488b4708                 mov rax, qword ptr [rdi + 8]
006d3f40  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d3f43  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d3f46  03c9                     add ecx, ecx
006d3f48  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d3f4f  03d2                     add edx, edx
006d3f51  4889442440               mov qword ptr [rsp + 0x40], rax
006d3f56  4503c9                   add r9d, r9d
006d3f59  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d3f5d  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d3f61  b999180000               mov ecx, 0x1899
006d3f66  4889442430               mov qword ptr [rsp + 0x30], rax
006d3f6b  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d3f72  448bc6                   mov r8d, esi
006d3f75  89542428                 mov dword ptr [rsp + 0x28], edx
006d3f79  8d560f                   lea edx, [rsi + 0xf]
006d3f7c  4889442420               mov qword ptr [rsp + 0x20], rax
006d3f81  e85a8fbdff               call 0x2acee0
006d3f86  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d3f8b  33c0                     xor eax, eax
006d3f8d  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d3f92  4883c460                 add rsp, 0x60
006d3f96  5f                       pop rdi
006d3f97  c3                       ret

; chunk at RVA 0x6d3f98 (277 bytes)
006d3f98  4183e801                 sub r8d, 1
006d3f9c  7473                     je 0x6d4011
006d3f9e  4183e801                 sub r8d, 1
006d3fa2  7468                     je 0x6d400c
006d3fa4  4183f801                 cmp r8d, 1
006d3fa8  756c                     jne 0x6d4016
006d3faa  83f933                   cmp ecx, 0x33
006d3fad  7405                     je 0x6d3fb4
006d3faf  83f936                   cmp ecx, 0x36
006d3fb2  7562                     jne 0x6d4016
006d3fb4  b901000000               mov ecx, 1
006d3fb9  4183f9ff                 cmp r9d, -1
006d3fbd  745c                     je 0x6d401b
006d3fbf  4183f901                 cmp r9d, 1
006d3fc3  7c16                     jl 0x6d3fdb
006d3fc5  85c9                     test ecx, ecx
006d3fc7  b8a00f0000               mov eax, 0xfa0
006d3fcc  41b8401f0000             mov r8d, 0x1f40
006d3fd2  410f44c0                 cmove eax, r8d
006d3fd6  443bc8                   cmp r9d, eax
006d3fd9  7e40                     jle 0x6d401b
006d3fdb  488d05be41cf01           lea rax, [rip + 0x1cf41be]
006d3fe2  4889442450               mov qword ptr [rsp + 0x50], rax
006d3fe7  48c74424480e000000       mov qword ptr [rsp + 0x48], 0xe
006d3ff0  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d3ff3  488b4708                 mov rax, qword ptr [rdi + 8]
006d3ff7  03c9                     add ecx, ecx
006d3ff9  4889442440               mov qword ptr [rsp + 0x40], rax
006d3ffe  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d4002  b997180000               mov ecx, 0x1897
006d4007  e9fd020000               jmp 0x6d4309
006d400c  83f939                   cmp ecx, 0x39
006d400f  eba1                     jmp 0x6d3fb2
006d4011  83f91c                   cmp ecx, 0x1c
006d4014  749e                     je 0x6d3fb4
006d4016  418bcb                   mov ecx, r11d
006d4019  eb9e                     jmp 0x6d3fb9
006d401b  450fb64a14               movzx r9d, byte ptr [r10 + 0x14]
006d4020  4584c9                   test r9b, r9b
006d4023  0f84d2000000             je 0x6d40fb
006d4029  8b4a10                   mov ecx, dword ptr [rdx + 0x10]
006d402c  83e902                   sub ecx, 2
006d402f  747c                     je 0x6d40ad
006d4031  83f901                   cmp ecx, 1
006d4034  0f8580000000             jne 0x6d40ba
006d403a  837a1432                 cmp dword ptr [rdx + 0x14], 0x32
006d403e  757a                     jne 0x6d40ba
006d4040  45385a1c                 cmp byte ptr [r10 + 0x1c], r11b
006d4044  0f858a000000             jne 0x6d40d4
006d404a  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d404e  488b4708                 mov rax, qword ptr [rdi + 8]
006d4052  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d4055  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d4058  03d2                     add edx, edx
006d405a  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d4061  03c9                     add ecx, ecx
006d4063  4889442440               mov qword ptr [rsp + 0x40], rax
006d4068  4503c9                   add r9d, r9d
006d406b  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d406f  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d4073  b99a180000               mov ecx, 0x189a
006d4078  4889442430               mov qword ptr [rsp + 0x30], rax
006d407d  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d4084  89542428                 mov dword ptr [rsp + 0x28], edx
006d4088  ba10000000               mov edx, 0x10
006d408d  4889442420               mov qword ptr [rsp + 0x20], rax
006d4092  448d42f1                 lea r8d, [rdx - 0xf]
006d4096  e8458ebdff               call 0x2acee0
006d409b  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d40a0  33c0                     xor eax, eax
006d40a2  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d40a7  4883c460                 add rsp, 0x60
006d40ab  5f                       pop rdi
006d40ac  c3                       ret

; chunk at RVA 0x6d40ad (328 bytes)
006d40ad  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d40b0  83e91f                   sub ecx, 0x1f
006d40b3  748b                     je 0x6d4040
006d40b5  83f901                   cmp ecx, 1
006d40b8  7486                     je 0x6d4040
006d40ba  488d05bf6dcf01           lea rax, [rip + 0x1cf6dbf]
006d40c1  4889442450               mov qword ptr [rsp + 0x50], rax
006d40c6  48c744244812000000       mov qword ptr [rsp + 0x48], 0x12
006d40cf  e91e020000               jmp 0x6d42f2
006d40d4  458b5a18                 mov r11d, dword ptr [r10 + 0x18]
006d40d8  418d43ff                 lea eax, [r11 - 1]
006d40dc  83f825                   cmp eax, 0x25
006d40df  761a                     jbe 0x6d40fb
006d40e1  488d05986dcf01           lea rax, [rip + 0x1cf6d98]
006d40e8  4889442450               mov qword ptr [rsp + 0x50], rax
006d40ed  48c744244812000000       mov qword ptr [rsp + 0x48], 0x12
006d40f6  e9f5feffff               jmp 0x6d3ff0
006d40fb  41807a1c00               cmp byte ptr [r10 + 0x1c], 0
006d4100  0f849a010000             je 0x6d42a0
006d4106  448b4210                 mov r8d, dword ptr [rdx + 0x10]
006d410a  488d35efbe92ff           lea rsi, [rip - 0x6d4111]
006d4111  4183f802                 cmp r8d, 2
006d4115  7519                     jne 0x6d4130
006d4117  8b4214                   mov eax, dword ptr [rdx + 0x14]
006d411a  83c0df                   add eax, -0x21
006d411d  83f806                   cmp eax, 6
006d4120  7749                     ja 0x6d416b
006d4122  4898                     cdqe
006d4124  8b8c866c436d00           mov ecx, dword ptr [rsi + rax*4 + 0x6d436c]
006d412b  4803ce                   add rcx, rsi
006d412e  ffe1                     jmp rcx
006d4130  418bc8                   mov ecx, r8d
006d4133  83e902                   sub ecx, 2
006d4136  7433                     je 0x6d416b
006d4138  83f901                   cmp ecx, 1
006d413b  753b                     jne 0x6d4178
006d413d  837a1432                 cmp dword ptr [rdx + 0x14], 0x32
006d4141  7535                     jne 0x6d4178
006d4143  4584c9                   test r9b, r9b
006d4146  0f85a9000000             jne 0x6d41f5
006d414c  4183f802                 cmp r8d, 2
006d4150  7540                     jne 0x6d4192
006d4152  8b4214                   mov eax, dword ptr [rdx + 0x14]
006d4155  83c0df                   add eax, -0x21
006d4158  83f806                   cmp eax, 6
006d415b  7735                     ja 0x6d4192
006d415d  4898                     cdqe
006d415f  8b8c8688436d00           mov ecx, dword ptr [rsi + rax*4 + 0x6d4388]
006d4166  4803ce                   add rcx, rsi
006d4169  ffe1                     jmp rcx
006d416b  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d416e  83e91f                   sub ecx, 0x1f
006d4171  74d0                     je 0x6d4143
006d4173  83f901                   cmp ecx, 1
006d4176  74cb                     je 0x6d4143
006d4178  488d059942cf01           lea rax, [rip + 0x1cf4299]
006d417f  4889442450               mov qword ptr [rsp + 0x50], rax
006d4184  48c74424480a000000       mov qword ptr [rsp + 0x48], 0xa
006d418d  e960010000               jmp 0x6d42f2
006d4192  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d4196  488b4708                 mov rax, qword ptr [rdi + 8]
006d419a  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d419d  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d41a0  03d2                     add edx, edx
006d41a2  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d41a9  03c9                     add ecx, ecx
006d41ab  4889442440               mov qword ptr [rsp + 0x40], rax
006d41b0  4503c9                   add r9d, r9d
006d41b3  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d41b7  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d41bb  b99a180000               mov ecx, 0x189a
006d41c0  4889442430               mov qword ptr [rsp + 0x30], rax
006d41c5  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d41cc  89542428                 mov dword ptr [rsp + 0x28], edx
006d41d0  ba10000000               mov edx, 0x10
006d41d5  4889442420               mov qword ptr [rsp + 0x20], rax
006d41da  448d42f1                 lea r8d, [rdx - 0xf]
006d41de  e8fd8cbdff               call 0x2acee0
006d41e3  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d41e8  33c0                     xor eax, eax
006d41ea  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d41ef  4883c460                 add rsp, 0x60
006d41f3  5f                       pop rdi
006d41f4  c3                       ret

; chunk at RVA 0x6d41f5 (171 bytes)
006d41f5  458b4a20                 mov r9d, dword ptr [r10 + 0x20]
006d41f9  4585c9                   test r9d, r9d
006d41fc  782a                     js 0x6d4228
006d41fe  4183f802                 cmp r8d, 2
006d4202  751f                     jne 0x6d4223
006d4204  8b4214                   mov eax, dword ptr [rdx + 0x14]
006d4207  83c0df                   add eax, -0x21
006d420a  83f806                   cmp eax, 6
006d420d  7714                     ja 0x6d4223
006d420f  4898                     cdqe
006d4211  8b8c86a4436d00           mov ecx, dword ptr [rsi + rax*4 + 0x6d43a4]
006d4218  4803ce                   add rcx, rsi
006d421b  ffe1                     jmp rcx
006d421d  41bb07000000             mov r11d, 7
006d4223  453bcb                   cmp r9d, r11d
006d4226  7e78                     jle 0x6d42a0
006d4228  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d422c  488d05e541cf01           lea rax, [rip + 0x1cf41e5]
006d4233  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d4236  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d4239  03d2                     add edx, edx
006d423b  4889442450               mov qword ptr [rsp + 0x50], rax
006d4240  03c9                     add ecx, ecx
006d4242  488b4708                 mov rax, qword ptr [rdi + 8]
006d4246  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d424d  48c74424480a000000       mov qword ptr [rsp + 0x48], 0xa
006d4256  4503c9                   add r9d, r9d
006d4259  4889442440               mov qword ptr [rsp + 0x40], rax
006d425e  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d4262  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d4266  b997180000               mov ecx, 0x1897
006d426b  4889442430               mov qword ptr [rsp + 0x30], rax
006d4270  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d4277  89542428                 mov dword ptr [rsp + 0x28], edx
006d427b  ba10000000               mov edx, 0x10
006d4280  4889442420               mov qword ptr [rsp + 0x20], rax
006d4285  448d42f1                 lea r8d, [rdx - 0xf]
006d4289  e8528cbdff               call 0x2acee0
006d428e  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d4293  33c0                     xor eax, eax
006d4295  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d429a  4883c460                 add rsp, 0x60
006d429e  5f                       pop rdi
006d429f  c3                       ret

; chunk at RVA 0x6d42a0 (181 bytes)
006d42a0  41807a0a00               cmp byte ptr [r10 + 0xa], 0
006d42a5  0f84aa000000             je 0x6d4355
006d42ab  8b4a10                   mov ecx, dword ptr [rdx + 0x10]
006d42ae  83e901                   sub ecx, 1
006d42b1  7424                     je 0x6d42d7
006d42b3  83e901                   sub ecx, 1
006d42b6  740e                     je 0x6d42c6
006d42b8  83e901                   sub ecx, 1
006d42bb  0f8494000000             je 0x6d4355
006d42c1  83f901                   cmp ecx, 1
006d42c4  eb15                     jmp 0x6d42db
006d42c6  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d42c9  83e938                   sub ecx, 0x38
006d42cc  0f8483000000             je 0x6d4355
006d42d2  83f901                   cmp ecx, 1
006d42d5  eb04                     jmp 0x6d42db
006d42d7  837a141c                 cmp dword ptr [rdx + 0x14], 0x1c
006d42db  7478                     je 0x6d4355
006d42dd  488d059c3ecf01           lea rax, [rip + 0x1cf3e9c]
006d42e4  4889442450               mov qword ptr [rsp + 0x50], rax
006d42e9  48c744244814000000       mov qword ptr [rsp + 0x48], 0x14
006d42f2  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d42f5  488b4708                 mov rax, qword ptr [rdi + 8]
006d42f9  03c9                     add ecx, ecx
006d42fb  4889442440               mov qword ptr [rsp + 0x40], rax
006d4300  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d4304  b996180000               mov ecx, 0x1896
006d4309  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d430d  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d4310  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d4314  03d2                     add edx, edx
006d4316  4889442430               mov qword ptr [rsp + 0x30], rax
006d431b  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d4322  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d4329  4503c9                   add r9d, r9d
006d432c  89542428                 mov dword ptr [rsp + 0x28], edx
006d4330  ba10000000               mov edx, 0x10
006d4335  4889442420               mov qword ptr [rsp + 0x20], rax
006d433a  448d42f1                 lea r8d, [rdx - 0xf]
006d433e  e89d8bbdff               call 0x2acee0
006d4343  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d4348  33c0                     xor eax, eax
006d434a  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d434f  4883c460                 add rsp, 0x60
006d4353  5f                       pop rdi
006d4354  c3                       ret

; chunk at RVA 0x6d4355 (21 bytes)
006d4355  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d435a  b801000000               mov eax, 1
006d435f  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d4364  4883c460                 add rsp, 0x60
006d4368  5f                       pop rdi
006d4369  c3                       ret

; chunk at RVA 0x6d436c (84 bytes)
006d436c  43416d                   insd dword ptr [rdi], dx
006d436f  004341                   add byte ptr [rbx + 0x41], al
006d4372  6d                       insd dword ptr [rdi], dx
006d4373  004341                   add byte ptr [rbx + 0x41], al
006d4376  6d                       insd dword ptr [rdi], dx
006d4377  004341                   add byte ptr [rbx + 0x41], al
006d437a  6d                       insd dword ptr [rdi], dx
006d437b  006b41                   add byte ptr [rbx + 0x41], ch
006d437e  6d                       insd dword ptr [rdi], dx
006d437f  004341                   add byte ptr [rbx + 0x41], al
006d4382  6d                       insd dword ptr [rdi], dx
006d4383  004341                   add byte ptr [rbx + 0x41], al
006d4386  6d                       insd dword ptr [rdi], dx
006d4387  00f5                     add ch, dh
006d4389  416d                     insd dword ptr [rdi], dx
006d438b  00f5                     add ch, dh
006d438d  416d                     insd dword ptr [rdi], dx
006d438f  00f5                     add ch, dh
006d4391  416d                     insd dword ptr [rdi], dx
006d4393  00f5                     add ch, dh
006d4395  416d                     insd dword ptr [rdi], dx
006d4397  0092416d00f5             add byte ptr [rdx - 0xaff92bf], dl
006d439d  416d                     insd dword ptr [rdi], dx
006d439f  00f5                     add ch, dh
006d43a1  416d                     insd dword ptr [rdi], dx
006d43a3  001d426d001d             add byte ptr [rip + 0x1d006d42], bl
006d43a9  426d                     insd dword ptr [rdi], dx
006d43ab  001d426d001d             add byte ptr [rip + 0x1d006d42], bl
006d43b1  426d                     insd dword ptr [rdi], dx
006d43b3  0023                     add byte ptr [rbx], ah
006d43b5  426d                     insd dword ptr [rdi], dx
006d43b7  001d426d001d             add byte ptr [rip + 0x1d006d42], bl
006d43bd  426d                     insd dword ptr [rdi], dx
