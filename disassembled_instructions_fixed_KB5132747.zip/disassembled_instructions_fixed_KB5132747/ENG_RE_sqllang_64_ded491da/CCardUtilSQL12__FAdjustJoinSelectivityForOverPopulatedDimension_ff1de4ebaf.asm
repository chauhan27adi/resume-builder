; CCardUtilSQL12::FAdjustJoinSelectivityForOverPopulatedDimension
; sqllang.dll, primary RVA 0x1d4930, 711 bytes in 1 chunk(s)

; chunk at RVA 0x1d4930 (711 bytes)
001d4930  488bc4                   mov rax, rsp
001d4933  48894808                 mov qword ptr [rax + 8], rcx
001d4937  55                       push rbp
001d4938  56                       push rsi
001d4939  57                       push rdi
001d493a  4154                     push r12
001d493c  4155                     push r13
001d493e  4156                     push r14
001d4940  4157                     push r15
001d4942  488d68b1                 lea rbp, [rax - 0x4f]
001d4946  4881ecc0000000           sub rsp, 0xc0
001d494d  48c7459ffeffffff         mov qword ptr [rbp - 0x61], 0xfffffffffffffffe
001d4955  48895810                 mov qword ptr [rax + 0x10], rbx
001d4959  0f2970b8                 movaps xmmword ptr [rax - 0x48], xmm6
001d495d  0f2978a8                 movaps xmmword ptr [rax - 0x58], xmm7
001d4961  440f294098               movaps xmmword ptr [rax - 0x68], xmm8
001d4966  440f294888               movaps xmmword ptr [rax - 0x78], xmm9
001d496b  498bd9                   mov rbx, r9
001d496e  498bf8                   mov rdi, r8
001d4971  488bf2                   mov rsi, rdx
001d4974  4c8bf1                   mov r14, rcx
001d4977  4180b98100000000         cmp byte ptr [r9 + 0x81], 0
001d497f  0f8543077501             jne 0x19250c8
001d4985  498b00                   mov rax, qword ptr [r8]
001d4988  498bc8                   mov rcx, r8
001d498b  ff5008                   call qword ptr [rax + 8]
001d498e  83f802                   cmp eax, 2
001d4991  0f8531077501             jne 0x19250c8
001d4997  488b07                   mov rax, qword ptr [rdi]
001d499a  488bcf                   mov rcx, rdi
001d499d  ff5010                   call qword ptr [rax + 0x10]
001d49a0  488bf8                   mov rdi, rax
001d49a3  4533ff                   xor r15d, r15d
001d49a6  4c897d87                 mov qword ptr [rbp - 0x79], r15
001d49aa  f20f104368               movsd xmm0, qword ptr [rbx + 0x68]
001d49af  660f2f4360               comisd xmm0, xmmword ptr [rbx + 0x60]
001d49b4  0f8711020000             ja 0x1d4bcb
001d49ba  ff4308                   inc dword ptr [rbx + 8]
001d49bd  48895d87                 mov qword ptr [rbp - 0x79], rbx
001d49c1  f20f104360               movsd xmm0, qword ptr [rbx + 0x60]
001d49c6  660f2e4368               ucomisd xmm0, qword ptr [rbx + 0x68]
001d49cb  0f8a20020000             jp 0x1d4bf1
001d49d1  0f851a020000             jne 0x1d4bf1
001d49d7  f20f59054907ea01         mulsd xmm0, qword ptr [rip + 0x1ea0749]
001d49df  f20f103db12be401         movsd xmm7, qword ptr [rip + 0x1e42bb1]
001d49e7  450f57c9                 xorps xmm9, xmm9
001d49eb  f20f1035ad2be401         movsd xmm6, qword ptr [rip + 0x1e42bad]
001d49f3  660f2ff8                 comisd xmm7, xmm0
001d49f7  0f82e5057501             jb 0x1924fe2
001d49fd  660f2fc6                 comisd xmm0, xmm6
001d4a01  0f82d3057501             jb 0x1924fda
001d4a07  660f2f4358               comisd xmm0, xmmword ptr [rbx + 0x58]
001d4a0c  0f93c0                   setae al
001d4a0f  84c0                     test al, al
001d4a11  0f84da010000             je 0x1d4bf1
001d4a17  4c8d258a39e801           lea r12, [rip + 0x1e8398a]
001d4a1e  4c8965af                 mov qword ptr [rbp - 0x51], r12
001d4a22  c745b701000000           mov dword ptr [rbp - 0x49], 1
001d4a29  4c8d2d88d8e901           lea r13, [rip + 0x1e9d888]
001d4a30  4c896daf                 mov qword ptr [rbp - 0x51], r13
001d4a34  4c8975bf                 mov qword ptr [rbp - 0x41], r14
001d4a38  4c897dc7                 mov qword ptr [rbp - 0x39], r15
001d4a3c  4885ff                   test rdi, rdi
001d4a3f  7456                     je 0x1d4a97
001d4a41  8b7f08                   mov edi, dword ptr [rdi + 8]
001d4a44  c7456fe5000000           mov dword ptr [rbp + 0x6f], 0xe5
001d4a4b  c644242001               mov byte ptr [rsp + 0x20], 1
001d4a50  41b9e5000000             mov r9d, 0xe5
001d4a56  4c8d0563eee901           lea r8, [rip + 0x1e9ee63]
001d4a5d  488b55bf                 mov rdx, qword ptr [rbp - 0x41]
001d4a61  b930000000               mov ecx, 0x30
001d4a66  ff154464cf01             call qword ptr [rip + 0x1cf6444]
001d4a6c  488945a7                 mov qword ptr [rbp - 0x59], rax
001d4a70  4885c0                   test rax, rax
001d4a73  0f8480057501             je 0x1924ff9
001d4a79  488bc8                   mov rcx, rax
001d4a7c  e8cf95e8ff               call 0x5e050
001d4a81  eb01                     jmp 0x1d4a84
001d4a83  cc                       int3
001d4a84  488945c7                 mov qword ptr [rbp - 0x39], rax
001d4a88  448bc7                   mov r8d, edi
001d4a8b  488b55bf                 mov rdx, qword ptr [rbp - 0x41]
001d4a8f  488bc8                   mov rcx, rax
001d4a92  e8d985eaff               call 0x7d070
001d4a97  c7456f52160000           mov dword ptr [rbp + 0x6f], 0x1652
001d4a9e  c644242001               mov byte ptr [rsp + 0x20], 1
001d4aa3  41b952160000             mov r9d, 0x1652
001d4aa9  4c8d0570f2f601           lea r8, [rip + 0x1f6f270]
001d4ab0  498bd6                   mov rdx, r14
001d4ab3  b930000000               mov ecx, 0x30
001d4ab8  ff15f263cf01             call qword ptr [rip + 0x1cf63f2]
001d4abe  488bf8                   mov rdi, rax
001d4ac1  488945a7                 mov qword ptr [rbp - 0x59], rax
001d4ac5  4885c0                   test rax, rax
001d4ac8  0f8434057501             je 0x1925002
001d4ace  4c8920                   mov qword ptr [rax], r12
001d4ad1  c7400801000000           mov dword ptr [rax + 8], 1
001d4ad8  488d0571f1f601           lea rax, [rip + 0x1f6f171]
001d4adf  488907                   mov qword ptr [rdi], rax
001d4ae2  4c897f10                 mov qword ptr [rdi + 0x10], r15
001d4ae6  4c897f18                 mov qword ptr [rdi + 0x18], r15
001d4aea  44897f20                 mov dword ptr [rdi + 0x20], r15d
001d4aee  4c897728                 mov qword ptr [rdi + 0x28], r14
001d4af2  eb01                     jmp 0x1d4af5
001d4af4  cc                       int3
001d4af5  48897d6f                 mov qword ptr [rbp + 0x6f], rdi
001d4af9  488b06                   mov rax, qword ptr [rsi]
001d4afc  c644242800               mov byte ptr [rsp + 0x28], 0
001d4b01  c644242000               mov byte ptr [rsp + 0x20], 0
001d4b06  4c8bcf                   mov r9, rdi
001d4b09  4c8d45af                 lea r8, [rbp - 0x51]
001d4b0d  488d558f                 lea rdx, [rbp - 0x71]
001d4b11  488bce                   mov rcx, rsi
001d4b14  ff9060010000             call qword ptr [rax + 0x160]
001d4b1a  f20f10458f               movsd xmm0, qword ptr [rbp - 0x71]
001d4b1f  66440f2fc8               comisd xmm9, xmm0
001d4b24  7315                     jae 0x1d4b3b
001d4b26  488b4577                 mov rax, qword ptr [rbp + 0x77]
001d4b2a  f2440f104068             movsd xmm8, qword ptr [rax + 0x68]
001d4b30  66440f2fc0               comisd xmm8, xmm0
001d4b35  0f82abb40000             jb 0x1dffe6
001d4b3b  4032f6                   xor sil, sil
001d4b3e  4885ff                   test rdi, rdi
001d4b41  7414                     je 0x1d4b57
001d4b43  834708ff                 add dword ptr [rdi + 8], -1
001d4b47  750e                     jne 0x1d4b57
001d4b49  488b07                   mov rax, qword ptr [rdi]
001d4b4c  ba01000000               mov edx, 1
001d4b51  488bcf                   mov rcx, rdi
001d4b54  ff10                     call qword ptr [rax]
001d4b56  90                       nop
001d4b57  4c896daf                 mov qword ptr [rbp - 0x51], r13
001d4b5b  488b7dc7                 mov rdi, qword ptr [rbp - 0x39]
001d4b5f  4885ff                   test rdi, rdi
001d4b62  741b                     je 0x1d4b7f
001d4b64  488b0f                   mov rcx, qword ptr [rdi]
001d4b67  4885c9                   test rcx, rcx
001d4b6a  0f85fd047501             jne 0x192506d
001d4b70  ba30000000               mov edx, 0x30
001d4b75  488bcf                   mov rcx, rdi
001d4b78  ff150a64cf01             call qword ptr [rip + 0x1cf640a]
001d4b7e  90                       nop
001d4b7f  4c8965af                 mov qword ptr [rbp - 0x51], r12
001d4b83  eb01                     jmp 0x1d4b86
001d4b85  cc                       int3
001d4b86  4885db                   test rbx, rbx
001d4b89  740a                     je 0x1d4b95
001d4b8b  834308ff                 add dword ptr [rbx + 8], -1
001d4b8f  0f8430047501             je 0x1924fc5
001d4b95  400fb6c6                 movzx eax, sil
001d4b99  eb01                     jmp 0x1d4b9c
001d4b9b  cc                       int3
001d4b9c  4c8d9c24c0000000         lea r11, [rsp + 0xc0]
001d4ba4  498b5b48                 mov rbx, qword ptr [r11 + 0x48]
001d4ba8  410f2873f0               movaps xmm6, xmmword ptr [r11 - 0x10]
001d4bad  410f287be0               movaps xmm7, xmmword ptr [r11 - 0x20]
001d4bb2  450f2843d0               movaps xmm8, xmmword ptr [r11 - 0x30]
001d4bb7  450f284bc0               movaps xmm9, xmmword ptr [r11 - 0x40]
001d4bbc  498be3                   mov rsp, r11
001d4bbf  415f                     pop r15
001d4bc1  415e                     pop r14
001d4bc3  415d                     pop r13
001d4bc5  415c                     pop r12
001d4bc7  5f                       pop rdi
001d4bc8  5e                       pop rsi
001d4bc9  5d                       pop rbp
001d4bca  c3                       ret
001d4bcb  4c8b16                   mov r10, qword ptr [rsi]
001d4bce  4533c9                   xor r9d, r9d
001d4bd1  4533c0                   xor r8d, r8d
001d4bd4  488bd0                   mov rdx, rax
001d4bd7  488bce                   mov rcx, rsi
001d4bda  41ff92f8000000           call qword ptr [r10 + 0xf8]
001d4be1  488bd8                   mov rbx, rax
001d4be4  48894587                 mov qword ptr [rbp - 0x79], rax
001d4be8  4885c0                   test rax, rax
001d4beb  0f85d0fdffff             jne 0x1d49c1
001d4bf1  4032f6                   xor sil, sil
001d4bf4  eb90                     jmp 0x1d4b86
001d4bf6  cc                       int3
