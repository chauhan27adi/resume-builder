; CCardFrameworkSQL12::DeriveCardinalityProperties
; sqllang.dll, primary RVA 0x1bb6b0, 713 bytes in 1 chunk(s)

; chunk at RVA 0x1bb6b0 (713 bytes)
001bb6b0  488bc4                   mov rax, rsp
001bb6b3  4c894820                 mov qword ptr [rax + 0x20], r9
001bb6b7  4c894018                 mov qword ptr [rax + 0x18], r8
001bb6bb  48895010                 mov qword ptr [rax + 0x10], rdx
001bb6bf  48894808                 mov qword ptr [rax + 8], rcx
001bb6c3  55                       push rbp
001bb6c4  53                       push rbx
001bb6c5  56                       push rsi
001bb6c6  57                       push rdi
001bb6c7  4154                     push r12
001bb6c9  4155                     push r13
001bb6cb  4156                     push r14
001bb6cd  4157                     push r15
001bb6cf  488d68a1                 lea rbp, [rax - 0x5f]
001bb6d3  4881ec98000000           sub rsp, 0x98
001bb6da  48c745f7feffffff         mov qword ptr [rbp - 9], 0xfffffffffffffffe
001bb6e2  0f2970a8                 movaps xmmword ptr [rax - 0x58], xmm6
001bb6e6  4d8be9                   mov r13, r9
001bb6e9  4d8bf8                   mov r15, r8
001bb6ec  488b7910                 mov rdi, qword ptr [rcx + 0x10]
001bb6f0  48897dd7                 mov qword ptr [rbp - 0x29], rdi
001bb6f4  c745cf040a0000           mov dword ptr [rbp - 0x31], 0xa04
001bb6fb  c644242001               mov byte ptr [rsp + 0x20], 1
001bb700  41b9040a0000             mov r9d, 0xa04
001bb706  4c8d05ebb3f801           lea r8, [rip + 0x1f8b3eb]
001bb70d  488b5770                 mov rdx, qword ptr [rdi + 0x70]
001bb711  b928000000               mov ecx, 0x28
001bb716  ff1594f7d001             call qword ptr [rip + 0x1d0f794]
001bb71c  488bd8                   mov rbx, rax
001bb71f  488945e7                 mov qword ptr [rbp - 0x19], rax
001bb723  33f6                     xor esi, esi
001bb725  4885c0                   test rax, rax
001bb728  0f84b75d7301             je 0x18f14e5
001bb72e  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
001bb732  488908                   mov qword ptr [rax], rcx
001bb735  89700c                   mov dword ptr [rax + 0xc], esi
001bb738  48897010                 mov qword ptr [rax + 0x10], rsi
001bb73c  48897018                 mov qword ptr [rax + 0x18], rsi
001bb740  897020                   mov dword ptr [rax + 0x20], esi
001bb743  4533c0                   xor r8d, r8d
001bb746  8d5628                   lea edx, [rsi + 0x28]
001bb749  488bc8                   mov rcx, rax
001bb74c  e8af3feaff               call 0x5f700
001bb751  90                       nop
001bb752  eb01                     jmp 0x1bb755
001bb754  cc                       int3
001bb755  48895dc7                 mov qword ptr [rbp - 0x39], rbx
001bb759  488d4f50                 lea rcx, [rdi + 0x50]
001bb75d  488d55c7                 lea rdx, [rbp - 0x39]
001bb761  e8fa21e5ff               call 0xd960
001bb766  498b4708                 mov rax, qword ptr [r15 + 8]
001bb76a  4885c0                   test rax, rax
001bb76d  0f84bd120000             je 0x1bca30
001bb773  488b4810                 mov rcx, qword ptr [rax + 0x10]
001bb777  eb01                     jmp 0x1bb77a
001bb779  cc                       int3
001bb77a  4c8b6110                 mov r12, qword ptr [rcx + 0x10]
001bb77e  4c8965d7                 mov qword ptr [rbp - 0x29], r12
001bb782  4c8965ff                 mov qword ptr [rbp - 1], r12
001bb786  4c8bf6                   mov r14, rsi
001bb789  488975bf                 mov qword ptr [rbp - 0x41], rsi
001bb78d  f2410f104520             movsd xmm0, qword ptr [r13 + 0x20]
001bb793  0f57f6                   xorps xmm6, xmm6
001bb796  660f2ec6                 ucomisd xmm0, xmm6
001bb79a  7a06                     jp 0x1bb7a2
001bb79c  0f844c5d7301             je 0x18f14ee
001bb7a2  488bfe                   mov rdi, rsi
001bb7a5  488975df                 mov qword ptr [rbp - 0x21], rsi
001bb7a9  4c8bee                   mov r13, rsi
001bb7ac  498bcf                   mov rcx, r15
001bb7af  e8bc31ebff               call 0x6e970
001bb7b4  488945b7                 mov qword ptr [rbp - 0x49], rax
001bb7b8  488b88d0020000           mov rcx, qword ptr [rax + 0x2d0]
001bb7bf  f6410601                 test byte ptr [rcx + 6], 1
001bb7c3  754a                     jne 0x1bb80f
001bb7c5  498b5f08                 mov rbx, qword ptr [r15 + 8]
001bb7c9  4885db                   test rbx, rbx
001bb7cc  0f846c120000             je 0x1bca3e
001bb7d2  488b5b10                 mov rbx, qword ptr [rbx + 0x10]
001bb7d6  eb01                     jmp 0x1bb7d9
001bb7d8  cc                       int3
001bb7d9  488b03                   mov rax, qword ptr [rbx]
001bb7dc  488bcb                   mov rcx, rbx
001bb7df  ff5018                   call qword ptr [rax + 0x18]
001bb7e2  83c0f2                   add eax, -0xe
001bb7e5  83f822                   cmp eax, 0x22
001bb7e8  771e                     ja 0x1bb808
001bb7ea  4898                     cdqe
001bb7ec  488d150d48e4ff           lea rdx, [rip - 0x1bb7f3]
001bb7f3  0fb6840214ba1b00         movzx eax, byte ptr [rdx + rax + 0x1bba14]
001bb7fb  8b8c8200ba1b00           mov ecx, dword ptr [rdx + rax*4 + 0x1bba00]
001bb802  4803ca                   add rcx, rdx
001bb805  ffe1                     jmp rcx
001bb807  cc                       int3
001bb808  4c8bee                   mov r13, rsi
001bb80b  488b45b7                 mov rax, qword ptr [rbp - 0x49]
001bb80f  488bde                   mov rbx, rsi
001bb812  48895de7                 mov qword ptr [rbp - 0x19], rbx
001bb816  f6053fa2920208           test byte ptr [rip + 0x292a23f], 8
001bb81d  0f858e5d7301             jne 0x18f15b1
001bb823  488b4818                 mov rcx, qword ptr [rax + 0x18]
001bb827  488b01                   mov rax, qword ptr [rcx]
001bb82a  ff9080010000             call qword ptr [rax + 0x180]
001bb830  4885c0                   test rax, rax
001bb833  0f85485d7301             jne 0x18f1581
001bb839  f6051ca2920208           test byte ptr [rip + 0x292a21c], 8
001bb840  0f85da5d7301             jne 0x18f1620
001bb846  488b4d6f                 mov rcx, qword ptr [rbp + 0x6f]
001bb84a  488b01                   mov rax, qword ptr [rcx]
001bb84d  4c8bcb                   mov r9, rbx
001bb850  4c8b757f                 mov r14, qword ptr [rbp + 0x7f]
001bb854  4d8bc6                   mov r8, r14
001bb857  498bd7                   mov rdx, r15
001bb85a  ff90d8040000             call qword ptr [rax + 0x4d8]
001bb860  4c8bf8                   mov r15, rax
001bb863  488945bf                 mov qword ptr [rbp - 0x41], rax
001bb867  4c8b00                   mov r8, qword ptr [rax]
001bb86a  488d55c7                 lea rdx, [rbp - 0x39]
001bb86e  488bc8                   mov rcx, rax
001bb871  41ff5008                 call qword ptr [r8 + 8]
001bb875  f2410f104620             movsd xmm0, qword ptr [r14 + 0x20]
001bb87b  f20f104dc7               movsd xmm1, qword ptr [rbp - 0x39]
001bb880  660f2fc8                 comisd xmm1, xmm0
001bb884  7703                     ja 0x1bb889
001bb886  0f28c1                   movaps xmm0, xmm1
001bb889  f20f1145cf               movsd qword ptr [rbp - 0x31], xmm0
001bb88e  488b45b7                 mov rax, qword ptr [rbp - 0x49]
001bb892  488b80d0020000           mov rax, qword ptr [rax + 0x2d0]
001bb899  f6400601                 test byte ptr [rax + 6], 1
001bb89d  0f85935d7301             jne 0x18f1636
001bb8a3  f2410f104e18             movsd xmm1, qword ptr [r14 + 0x18]
001bb8a9  660f2fc8                 comisd xmm1, xmm0
001bb8ad  7703                     ja 0x1bb8b2
001bb8af  0f28c8                   movaps xmm1, xmm0
001bb8b2  f20f114db7               movsd qword ptr [rbp - 0x49], xmm1
001bb8b7  4c8d45b7                 lea r8, [rbp - 0x49]
001bb8bb  498bd7                   mov rdx, r15
001bb8be  498bcc                   mov rcx, r12
001bb8c1  e88afdffff               call 0x1bb650
001bb8c6  4c8bf0                   mov r14, rax
001bb8c9  41834708ff               add dword ptr [r15 + 8], -1
001bb8ce  0f84885d7301             je 0x18f165c
001bb8d4  4c8975bf                 mov qword ptr [rbp - 0x41], r14
001bb8d8  4885db                   test rbx, rbx
001bb8db  0f858f5d7301             jne 0x18f1670
001bb8e1  4d85ed                   test r13, r13
001bb8e4  0f8535030000             jne 0x1bbc1f
001bb8ea  4885db                   test rbx, rbx
001bb8ed  0f85c35e7301             jne 0x18f17b6
001bb8f3  4885ff                   test rdi, rdi
001bb8f6  0f856b3d0100             jne 0x1cf667
001bb8fc  4c8b6d7f                 mov r13, qword ptr [rbp + 0x7f]
001bb900  488975bf                 mov qword ptr [rbp - 0x41], rsi
001bb904  498b8d08010000           mov rcx, qword ptr [r13 + 0x108]
001bb90b  4885c9                   test rcx, rcx
001bb90e  0f85b65e7301             jne 0x18f17ca
001bb914  4d89b508010000           mov qword ptr [r13 + 0x108], r14
001bb91b  488b4567                 mov rax, qword ptr [rbp + 0x67]
001bb91f  488b5010                 mov rdx, qword ptr [rax + 0x10]
001bb923  8b425c                   mov eax, dword ptr [rdx + 0x5c]
001bb926  85c0                     test eax, eax
001bb928  0f84b75e7301             je 0x18f17e5
001bb92e  ffc8                     dec eax
001bb930  89425c                   mov dword ptr [rdx + 0x5c], eax
001bb933  8bc8                     mov ecx, eax
001bb935  488b4268                 mov rax, qword ptr [rdx + 0x68]
001bb939  488b1cc8                 mov rbx, qword ptr [rax + rcx*8]
001bb93d  48895d67                 mov qword ptr [rbp + 0x67], rbx
001bb941  4885db                   test rbx, rbx
001bb944  7417                     je 0x1bb95d
001bb946  488bcb                   mov rcx, rbx
001bb949  e832000000               call 0x1bb980
001bb94e  ba28000000               mov edx, 0x28
001bb953  488bcb                   mov rcx, rbx
001bb956  ff152cf6d001             call qword ptr [rip + 0x1d0f62c]
001bb95c  90                       nop
001bb95d  0f28b42480000000         movaps xmm6, xmmword ptr [rsp + 0x80]
001bb965  4881c498000000           add rsp, 0x98
001bb96c  415f                     pop r15
001bb96e  415e                     pop r14
001bb970  415d                     pop r13
001bb972  415c                     pop r12
001bb974  5f                       pop rdi
001bb975  5e                       pop rsi
001bb976  5b                       pop rbx
001bb977  5d                       pop rbp
001bb978  c3                       ret
