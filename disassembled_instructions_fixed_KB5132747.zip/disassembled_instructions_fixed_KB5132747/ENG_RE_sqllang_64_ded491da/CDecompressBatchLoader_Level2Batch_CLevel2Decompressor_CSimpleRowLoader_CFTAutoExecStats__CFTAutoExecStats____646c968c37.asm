; CDecompressBatchLoader<Level2Batch,CLevel2Decompressor,CSimpleRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x972670, 1436 bytes in 1 chunk(s)

; chunk at RVA 0x972670 (1436 bytes)
00972670  488bc4                   mov rax, rsp
00972673  4c894820                 mov qword ptr [rax + 0x20], r9
00972677  895010                   mov dword ptr [rax + 0x10], edx
0097267a  55                       push rbp
0097267b  56                       push rsi
0097267c  57                       push rdi
0097267d  4154                     push r12
0097267f  4155                     push r13
00972681  4156                     push r14
00972683  4157                     push r15
00972685  488d68a1                 lea rbp, [rax - 0x5f]
00972689  4881ecd0000000           sub rsp, 0xd0
00972690  48c74517feffffff         mov qword ptr [rbp + 0x17], 0xfffffffffffffffe
00972698  48895818                 mov qword ptr [rax + 0x18], rbx
0097269c  4d8be0                   mov r12, r8
0097269f  448bfa                   mov r15d, edx
009726a2  488bd9                   mov rbx, rcx
009726a5  83792002                 cmp dword ptr [rcx + 0x20], 2
009726a9  7507                     jne 0x9726b2
009726ab  33c0                     xor eax, eax
009726ad  e9dd040000               jmp 0x972b8f
009726b2  33ff                     xor edi, edi
009726b4  897db7                   mov dword ptr [rbp - 0x49], edi
009726b7  48897dbf                 mov qword ptr [rbp - 0x41], rdi
009726bb  40887dc7                 mov byte ptr [rbp - 0x39], dil
009726bf  0f57c0                   xorps xmm0, xmm0
009726c2  660f7f45d7               movdqa xmmword ptr [rbp - 0x29], xmm0
009726c7  0f57c9                   xorps xmm1, xmm1
009726ca  660f7f4de7               movdqa xmmword ptr [rbp - 0x19], xmm1
009726cf  660f7f45f7               movdqa xmmword ptr [rbp - 9], xmm0
009726d4  48897d07                 mov qword ptr [rbp + 7], rdi
009726d8  c7450f01000000           mov dword ptr [rbp + 0xf], 1
009726df  897c2420                 mov dword ptr [rsp + 0x20], edi
009726e3  32c9                     xor cl, cl
009726e5  884d67                   mov byte ptr [rbp + 0x67], cl
009726e8  4c8d2d11d968ff           lea r13, [rip - 0x9726ef]
009726ef  41c644241000             mov byte ptr [r12 + 0x10], 0
009726f5  80bbb814000000           cmp byte ptr [rbx + 0x14b8], 0
009726fc  747f                     je 0x97277d
009726fe  c683b814000000           mov byte ptr [rbx + 0x14b8], 0
00972705  4c8b83b0140000           mov r8, qword ptr [rbx + 0x14b0]
0097270c  33d2                     xor edx, edx
0097270e  498bcc                   mov rcx, r12
00972711  e88aa2ffff               call 0x96c9a0
00972716  488b83b0140000           mov rax, qword ptr [rbx + 0x14b0]
0097271d  ff08                     dec dword ptr [rax]
0097271f  897db7                   mov dword ptr [rbp - 0x49], edi
00972722  498b442408               mov rax, qword ptr [r12 + 8]
00972727  488945bf                 mov qword ptr [rbp - 0x41], rax
0097272b  418b1424                 mov edx, dword ptr [r12]
0097272f  498b442420               mov rax, qword ptr [r12 + 0x20]
00972734  488d0cd0                 lea rcx, [rax + rdx*8]
00972738  48894dd7                 mov qword ptr [rbp - 0x29], rcx
0097273c  498b442428               mov rax, qword ptr [r12 + 0x28]
00972741  488d0c90                 lea rcx, [rax + rdx*4]
00972745  48894ddf                 mov qword ptr [rbp - 0x21], rcx
00972749  498b442430               mov rax, qword ptr [r12 + 0x30]
0097274e  488d0c90                 lea rcx, [rax + rdx*4]
00972752  48894de7                 mov qword ptr [rbp - 0x19], rcx
00972756  b801000000               mov eax, 1
0097275b  2bc2                     sub eax, edx
0097275d  4403f8                   add r15d, eax
00972760  44897d6f                 mov dword ptr [rbp + 0x6f], r15d
00972764  488d75b7                 lea rsi, [rbp - 0x49]
00972768  c683b814000000           mov byte ptr [rbx + 0x14b8], 0
0097276f  c744242001000000         mov dword ptr [rsp + 0x20], 1
00972777  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
0097277b  eb03                     jmp 0x972780
0097277d  498bf4                   mov rsi, r12
00972780  837b2000                 cmp dword ptr [rbx + 0x20], 0
00972784  0f85ab000000             jne 0x972835
0097278a  48897c2428               mov qword ptr [rsp + 0x28], rdi
0097278f  897d87                   mov dword ptr [rbp - 0x79], edi
00972792  48897d8f                 mov qword ptr [rbp - 0x71], rdi
00972796  897d97                   mov dword ptr [rbp - 0x69], edi
00972799  48897d9f                 mov qword ptr [rbp - 0x61], rdi
0097279d  897da7                   mov dword ptr [rbp - 0x59], edi
009727a0  66897dab                 mov word ptr [rbp - 0x55], di
009727a4  488d4b28                 lea rcx, [rbx + 0x28]
009727a8  488b01                   mov rax, qword ptr [rcx]
009727ab  4d8bc1                   mov r8, r9
009727ae  488d542428               lea rdx, [rsp + 0x28]
009727b3  ff10                     call qword ptr [rax]
009727b5  c6456701                 mov byte ptr [rbp + 0x67], 1
009727b9  3dc60e0400               cmp eax, 0x40ec6
009727be  0f84a8030000             je 0x972b6c
009727c4  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
009727c9  48894b50                 mov qword ptr [rbx + 0x50], rcx
009727cd  8b4587                   mov eax, dword ptr [rbp - 0x79]
009727d0  894348                   mov dword ptr [rbx + 0x48], eax
009727d3  48894b58                 mov qword ptr [rbx + 0x58], rcx
009727d7  48897b40                 mov qword ptr [rbx + 0x40], rdi
009727db  66c783080300000000       mov word ptr [rbx + 0x308], 0
009727e4  4889bb00030000           mov qword ptr [rbx + 0x300], rdi
009727eb  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
009727ef  48898b20030000           mov qword ptr [rbx + 0x320], rcx
009727f6  8b4597                   mov eax, dword ptr [rbp - 0x69]
009727f9  898318030000             mov dword ptr [rbx + 0x318], eax
009727ff  48898b28030000           mov qword ptr [rbx + 0x328], rcx
00972806  4889bb10030000           mov qword ptr [rbx + 0x310], rdi
0097280d  4889bb9c140000           mov qword ptr [rbx + 0x149c], rdi
00972814  c783a414000000000101     mov dword ptr [rbx + 0x14a4], 0x1010000
0097281e  c7839814000001000000     mov dword ptr [rbx + 0x1498], 1
00972828  89bb90130000             mov dword ptr [rbx + 0x1390], edi
0097282e  c7432001000000           mov dword ptr [rbx + 0x20], 1
00972835  488b4330                 mov rax, qword ptr [rbx + 0x30]
00972839  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00972840  4c894608                 mov qword ptr [rsi + 8], r8
00972844  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
0097284b  488b5330                 mov rdx, qword ptr [rbx + 0x30]
0097284f  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00972852  83e007                   and eax, 7
00972855  83f805                   cmp eax, 5
00972858  7741                     ja 0x97289b
0097285a  4898                     cdqe
0097285c  418b8c85ac2b9700         mov ecx, dword ptr [r13 + rax*4 + 0x972bac]
00972864  4903cd                   add rcx, r13
00972867  ffe1                     jmp rcx
00972869  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097286d  410f95c6                 setne r14b
00972871  eb2b                     jmp 0x97289e
00972873  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972877  410f9dc6                 setge r14b
0097287b  eb21                     jmp 0x97289e
0097287d  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972881  410f9ec6                 setle r14b
00972885  eb17                     jmp 0x97289e
00972887  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097288b  410f9fc6                 setg r14b
0097288f  eb0d                     jmp 0x97289e
00972891  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972895  410f9cc6                 setl r14b
00972899  eb03                     jmp 0x97289e
0097289b  4532f6                   xor r14b, r14b
0097289e  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
009728a5  8b424c                   mov eax, dword ptr [rdx + 0x4c]
009728a8  83e007                   and eax, 7
009728ab  83f805                   cmp eax, 5
009728ae  7741                     ja 0x9728f1
009728b0  4898                     cdqe
009728b2  418b8c85c42b9700         mov ecx, dword ptr [r13 + rax*4 + 0x972bc4]
009728ba  4903cd                   add rcx, r13
009728bd  ffe1                     jmp rcx
009728bf  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009728c3  410f95c5                 setne r13b
009728c7  eb2b                     jmp 0x9728f4
009728c9  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009728cd  410f9dc5                 setge r13b
009728d1  eb21                     jmp 0x9728f4
009728d3  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009728d7  410f9ec5                 setle r13b
009728db  eb17                     jmp 0x9728f4
009728dd  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009728e1  410f9fc5                 setg r13b
009728e5  eb0d                     jmp 0x9728f4
009728e7  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009728eb  410f9cc5                 setl r13b
009728ef  eb03                     jmp 0x9728f4
009728f1  4532ed                   xor r13b, r13b
009728f4  48895d1f                 mov qword ptr [rbp + 0x1f], rbx
009728f8  0f31                     rdtsc
009728fa  48c1e220                 shl rdx, 0x20
009728fe  480bc2                   or rax, rdx
00972901  48894308                 mov qword ptr [rbx + 8], rax
00972905  488d4b38                 lea rcx, [rbx + 0x38]
00972909  4c8bc6                   mov r8, rsi
0097290c  418bd7                   mov edx, r15d
0097290f  e8ecb1ffff               call 0x96db00
00972914  84c0                     test al, al
00972916  7503                     jne 0x97291b
00972918  897b20                   mov dword ptr [rbx + 0x20], edi
0097291b  8b06                     mov eax, dword ptr [rsi]
0097291d  48014310                 add qword ptr [rbx + 0x10], rax
00972921  0f31                     rdtsc
00972923  48c1e220                 shl rdx, 0x20
00972927  480bc2                   or rax, rdx
0097292a  482b4308                 sub rax, qword ptr [rbx + 8]
0097292e  480103                   add qword ptr [rbx], rax
00972931  ff4318                   inc dword ptr [rbx + 0x18]
00972934  8b16                     mov edx, dword ptr [rsi]
00972936  448bc2                   mov r8d, edx
00972939  85d2                     test edx, edx
0097293b  0f84c8010000             je 0x972b09
00972941  4584f6                   test r14b, r14b
00972944  7509                     jne 0x97294f
00972946  4584ed                   test r13b, r13b
00972949  0f84ba010000             je 0x972b09
0097294f  448bca                   mov r9d, edx
00972952  4584f6                   test r14b, r14b
00972955  0f8484000000             je 0x9729df
0097295b  448bd7                   mov r10d, edi
0097295e  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00972962  85d2                     test edx, edx
00972964  7472                     je 0x9729d8
00972966  4c8b7620                 mov r14, qword ptr [rsi + 0x20]
0097296a  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
0097296e  4183e007                 and r8d, 7
00972972  4c8d3d87d668ff           lea r15, [rip - 0x972979]
00972979  0f1f8000000000           nop dword ptr [rax]
00972980  418bc2                   mov eax, r10d
00972983  4d8b0cc6                 mov r9, qword ptr [r14 + rax*8]
00972987  4183f805                 cmp r8d, 5
0097298b  0f87ad000000             ja 0x972a3e
00972991  4963c0                   movsxd rax, r8d
00972994  418b8c87dc2b9700         mov ecx, dword ptr [r15 + rax*4 + 0x972bdc]
0097299c  4903cf                   add rcx, r15
0097299f  ffe1                     jmp rcx
009729a1  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009729a5  0f94c0                   sete al
009729a8  eb22                     jmp 0x9729cc
009729aa  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009729ae  0f9cc0                   setl al
009729b1  eb19                     jmp 0x9729cc
009729b3  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009729b7  0f9fc0                   setg al
009729ba  eb10                     jmp 0x9729cc
009729bc  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009729c0  0f9ec0                   setle al
009729c3  eb07                     jmp 0x9729cc
009729c5  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009729c9  0f9dc0                   setge al
009729cc  84c0                     test al, al
009729ce  756e                     jne 0x972a3e
009729d0  41ffc2                   inc r10d
009729d3  443bd2                   cmp r10d, edx
009729d6  72a8                     jb 0x972980
009729d8  893e                     mov dword ptr [rsi], edi
009729da  8bd7                     mov edx, edi
009729dc  448bcf                   mov r9d, edi
009729df  458bc1                   mov r8d, r9d
009729e2  4584ed                   test r13b, r13b
009729e5  0f841e010000             je 0x972b09
009729eb  85d2                     test edx, edx
009729ed  0f8416010000             je 0x972b09
009729f3  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
009729f7  4c8b7e20                 mov r15, qword ptr [rsi + 0x20]
009729fb  4c8d2dfed568ff           lea r13, [rip - 0x972a02]
00972a02  0f1f4000                 nop dword ptr [rax]
00972a06  66660f1f840000000000     nop word ptr [rax + rax]
00972a10  458bd1                   mov r10d, r9d
00972a13  ffca                     dec edx
00972a15  448bca                   mov r9d, edx
00972a18  4d8b34d7                 mov r14, qword ptr [r15 + rdx*8]
00972a1c  418b434c                 mov eax, dword ptr [r11 + 0x4c]
00972a20  83e007                   and eax, 7
00972a23  458bc2                   mov r8d, r10d
00972a26  83f805                   cmp eax, 5
00972a29  0f87da000000             ja 0x972b09
00972a2f  4898                     cdqe
00972a31  418b8c85f42b9700         mov ecx, dword ptr [r13 + rax*4 + 0x972bf4]
00972a39  4903cd                   add rcx, r13
00972a3c  ffe1                     jmp rcx
00972a3e  443bd2                   cmp r10d, edx
00972a41  7395                     jae 0x9729d8
00972a43  448bca                   mov r9d, edx
00972a46  4585d2                   test r10d, r10d
00972a49  7494                     je 0x9729df
00972a4b  452bca                   sub r9d, r10d
00972a4e  8bd7                     mov edx, edi
00972a50  7470                     je 0x972ac2
00972a52  4c8bc7                   mov r8, rdi
00972a55  4c8bdf                   mov r11, rdi
00972a58  4c8bf7                   mov r14, rdi
00972a5b  0f1f440000               nop dword ptr [rax + rax]
00972a60  428d0412                 lea eax, [rdx + r10]
00972a64  448bf8                   mov r15d, eax
00972a67  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00972a6b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
00972a6f  4989040e                 mov qword ptr [r14 + rcx], rax
00972a73  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
00972a77  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00972a7b  4189040b                 mov dword ptr [r11 + rcx], eax
00972a7f  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
00972a83  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00972a87  4189040b                 mov dword ptr [r11 + rcx], eax
00972a8b  4d03ff                   add r15, r15
00972a8e  488b4638                 mov rax, qword ptr [rsi + 0x38]
00972a92  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00972a97  420f110400               movups xmmword ptr [rax + r8], xmm0
00972a9c  488b4648                 mov rax, qword ptr [rsi + 0x48]
00972aa0  4885c0                   test rax, rax
00972aa3  740a                     je 0x972aaf
00972aa5  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00972aaa  420f110400               movups xmmword ptr [rax + r8], xmm0
00972aaf  ffc2                     inc edx
00972ab1  4983c608                 add r14, 8
00972ab5  4983c304                 add r11, 4
00972ab9  4983c010                 add r8, 0x10
00972abd  413bd1                   cmp edx, r9d
00972ac0  729e                     jb 0x972a60
00972ac2  44890e                   mov dword ptr [rsi], r9d
00972ac5  418bd1                   mov edx, r9d
00972ac8  e912ffffff               jmp 0x9729df
00972acd  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972ad1  0f94c0                   sete al
00972ad4  eb22                     jmp 0x972af8
00972ad6  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972ada  0f9cc0                   setl al
00972add  eb19                     jmp 0x972af8
00972adf  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972ae3  0f9fc0                   setg al
00972ae6  eb10                     jmp 0x972af8
00972ae8  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972aec  0f9ec0                   setle al
00972aef  eb07                     jmp 0x972af8
00972af1  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972af5  0f9dc0                   setge al
00972af8  84c0                     test al, al
00972afa  750d                     jne 0x972b09
00972afc  8916                     mov dword ptr [rsi], edx
00972afe  448bc2                   mov r8d, edx
00972b01  85d2                     test edx, edx
00972b03  0f8507ffffff             jne 0x972a10
00972b09  80bbb914000000           cmp byte ptr [rbx + 0x14b9], 0
00972b10  7440                     je 0x972b52
00972b12  448b06                   mov r8d, dword ptr [rsi]
00972b15  4585c0                   test r8d, r8d
00972b18  7438                     je 0x972b52
00972b1a  c683b814000001           mov byte ptr [rbx + 0x14b8], 1
00972b21  8b16                     mov edx, dword ptr [rsi]
00972b23  ffca                     dec edx
00972b25  4c8bc6                   mov r8, rsi
00972b28  488b8bb0140000           mov rcx, qword ptr [rbx + 0x14b0]
00972b2f  e86c9effff               call 0x96c9a0
00972b34  ff0e                     dec dword ptr [rsi]
00972b36  41c644241001             mov byte ptr [r12 + 0x10], 1
00972b3c  488b83b0140000           mov rax, qword ptr [rbx + 0x14b0]
00972b43  488b4820                 mov rcx, qword ptr [rax + 0x20]
00972b47  488b01                   mov rax, qword ptr [rcx]
00972b4a  4989442418               mov qword ptr [r12 + 0x18], rax
00972b4f  448b06                   mov r8d, dword ptr [rsi]
00972b52  8b442420                 mov eax, dword ptr [rsp + 0x20]
00972b56  4103c0                   add eax, r8d
00972b59  89442420                 mov dword ptr [rsp + 0x20], eax
00972b5d  7521                     jne 0x972b80
00972b5f  448b7d6f                 mov r15d, dword ptr [rbp + 0x6f]
00972b63  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00972b67  e97cfbffff               jmp 0x9726e8
00972b6c  c7432002000000           mov dword ptr [rbx + 0x20], 2
00972b73  41833c2400               cmp dword ptr [r12], 0
00972b78  400f95c7                 setne dil
00972b7c  8bc7                     mov eax, edi
00972b7e  eb0f                     jmp 0x972b8f
00972b80  41890424                 mov dword ptr [r12], eax
00972b84  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00972b88  f6d9                     neg cl
00972b8a  1bc0                     sbb eax, eax
00972b8c  83c002                   add eax, 2
00972b8f  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
00972b97  4881c4d0000000           add rsp, 0xd0
00972b9e  415f                     pop r15
00972ba0  415e                     pop r14
00972ba2  415d                     pop r13
00972ba4  415c                     pop r12
00972ba6  5f                       pop rdi
00972ba7  5e                       pop rsi
00972ba8  5d                       pop rbp
00972ba9  c3                       ret
00972baa  90                       nop
00972bab  90                       nop
00972bac  9b                       wait
00972bad  289700692897             sub byte ptr [rdi - 0x68d79700], dl
00972bb3  007328                   add byte ptr [rbx + 0x28], dh
00972bb6  97                       xchg edi, eax
00972bb7  00872897007d             add byte ptr [rdi + 0x7d009728], al
00972bbd  289700912897             sub byte ptr [rdi - 0x68d76f00], dl
00972bc3  00f1                     add cl, dh
00972bc5  289700bf2897             sub byte ptr [rdi - 0x68d74100], dl
00972bcb  00c9                     add cl, cl
00972bcd  289700dd2897             sub byte ptr [rdi - 0x68d72300], dl
00972bd3  00d3                     add bl, dl
00972bd5  289700e72897             sub byte ptr [rdi - 0x68d71900], dl
00972bdb  003e                     add byte ptr [rsi], bh
00972bdd  2a9700a12997             sub dl, byte ptr [rdi - 0x68d65f00]
00972be3  00aa299700bc             add byte ptr [rdx - 0x43ff68d7], ch
00972be9  299700b32997             sub dword ptr [rdi - 0x68d64d00], edx
00972bef  00c5                     add ch, al
00972bf1  299700092b97             sub dword ptr [rdi - 0x68d4f700], edx
00972bf7  00cd                     add ch, cl
00972bf9  2a9700d62a97             sub dl, byte ptr [rdi - 0x68d52a00]
00972bff  00e8                     add al, ch
00972c01  2a9700df2a97             sub dl, byte ptr [rdi - 0x68d52100]
00972c07  00f1                     add cl, dh
