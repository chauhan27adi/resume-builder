; CAuditTargetOptions::CAuditTargetOptions
; sqllang.dll, primary RVA 0x108ca10, 588 bytes in 1 chunk(s)

; chunk at RVA 0x108ca10 (588 bytes)
0108ca10  4c89442418               mov qword ptr [rsp + 0x18], r8
0108ca15  53                       push rbx
0108ca16  55                       push rbp
0108ca17  56                       push rsi
0108ca18  57                       push rdi
0108ca19  4154                     push r12
0108ca1b  4156                     push r14
0108ca1d  4157                     push r15
0108ca1f  4883ec50                 sub rsp, 0x50
0108ca23  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
0108ca2c  4d8bf8                   mov r15, r8
0108ca2f  4c8bf2                   mov r14, rdx
0108ca32  488bf1                   mov rsi, rcx
0108ca35  8b02                     mov eax, dword ptr [rdx]
0108ca37  8901                     mov dword ptr [rcx], eax
0108ca39  48837a0800               cmp qword ptr [rdx + 8], 0
0108ca3e  0f84e2010000             je 0x108cc26
0108ca44  c7842490000000c8060000   mov dword ptr [rsp + 0x90], 0x6c8
0108ca4f  c644242003               mov byte ptr [rsp + 0x20], 3
0108ca54  41b9c8060000             mov r9d, 0x6c8
0108ca5a  4c8d05a7223a01           lea r8, [rip + 0x13a22a7]
0108ca61  498bd7                   mov rdx, r15
0108ca64  b910000000               mov ecx, 0x10
0108ca69  ff1541e4e300             call qword ptr [rip + 0xe3e441]
0108ca6f  4889842498000000         mov qword ptr [rsp + 0x98], rax
0108ca77  33ed                     xor ebp, ebp
0108ca79  4885c0                   test rax, rax
0108ca7c  740f                     je 0x108ca8d
0108ca7e  0f57c0                   xorps xmm0, xmm0
0108ca81  0f1100                   movups xmmword ptr [rax], xmm0
0108ca84  48894008                 mov qword ptr [rax + 8], rax
0108ca88  488900                   mov qword ptr [rax], rax
0108ca8b  eb03                     jmp 0x108ca90
0108ca8d  488bc5                   mov rax, rbp
0108ca90  48894608                 mov qword ptr [rsi + 8], rax
0108ca94  498b4608                 mov rax, qword ptr [r14 + 8]
0108ca98  488b5808                 mov rbx, qword ptr [rax + 8]
0108ca9c  483bd8                   cmp rbx, rax
0108ca9f  0f8487010000             je 0x108cc2c
0108caa5  4885db                   test rbx, rbx
0108caa8  0f847e010000             je 0x108cc2c
0108caae  4c8d254b35f7fe           lea r12, [rip - 0x108cab5]
0108cab5  6666660f1f840000000000   nop word ptr [rax + rax]
0108cac0  48634310                 movsxd rax, dword ptr [rbx + 0x10]
0108cac4  83f806                   cmp eax, 6
0108cac7  0f8744010000             ja 0x108cc11
0108cacd  418b8c8440cc0801         mov ecx, dword ptr [r12 + rax*4 + 0x108cc40]
0108cad5  4903cc                   add rcx, r12
0108cad8  ffe1                     jmp rcx
0108cada  c7842490000000d5060000   mov dword ptr [rsp + 0x90], 0x6d5
0108cae5  c644242003               mov byte ptr [rsp + 0x20], 3
0108caea  41b9d5060000             mov r9d, 0x6d5
0108caf0  4c8d0511223a01           lea r8, [rip + 0x13a2211]
0108caf7  498bd7                   mov rdx, r15
0108cafa  b928000000               mov ecx, 0x28
0108caff  ff15abe3e300             call qword ptr [rip + 0xe3e3ab]
0108cb05  488bf8                   mov rdi, rax
0108cb08  4889442438               mov qword ptr [rsp + 0x38], rax
0108cb0d  4885c0                   test rax, rax
0108cb10  7436                     je 0x108cb48
0108cb12  8b4b10                   mov ecx, dword ptr [rbx + 0x10]
0108cb15  488928                   mov qword ptr [rax], rbp
0108cb18  48896808                 mov qword ptr [rax + 8], rbp
0108cb1c  894810                   mov dword ptr [rax + 0x10], ecx
0108cb1f  48896818                 mov qword ptr [rax + 0x18], rbp
0108cb23  896820                   mov dword ptr [rax + 0x20], ebp
0108cb26  448b4320                 mov r8d, dword ptr [rbx + 0x20]
0108cb2a  4585c0                   test r8d, r8d
0108cb2d  741c                     je 0x108cb4b
0108cb2f  488b5318                 mov rdx, qword ptr [rbx + 0x18]
0108cb33  498bcf                   mov rcx, r15
0108cb36  ff15fcf1e300             call qword ptr [rip + 0xe3f1fc]
0108cb3c  48894718                 mov qword ptr [rdi + 0x18], rax
0108cb40  8b4320                   mov eax, dword ptr [rbx + 0x20]
0108cb43  894720                   mov dword ptr [rdi + 0x20], eax
0108cb46  eb03                     jmp 0x108cb4b
0108cb48  488bfd                   mov rdi, rbp
0108cb4b  e9a4000000               jmp 0x108cbf4
0108cb50  c7842498000000dc060000   mov dword ptr [rsp + 0x98], 0x6dc
0108cb5b  c644242003               mov byte ptr [rsp + 0x20], 3
0108cb60  41b9dc060000             mov r9d, 0x6dc
0108cb66  4c8d059b213a01           lea r8, [rip + 0x13a219b]
0108cb6d  498bd7                   mov rdx, r15
0108cb70  b920000000               mov ecx, 0x20
0108cb75  ff1535e3e300             call qword ptr [rip + 0xe3e335]
0108cb7b  488bf8                   mov rdi, rax
0108cb7e  4889442440               mov qword ptr [rsp + 0x40], rax
0108cb83  4885c0                   test rax, rax
0108cb86  7417                     je 0x108cb9f
0108cb88  8b4310                   mov eax, dword ptr [rbx + 0x10]
0108cb8b  48892f                   mov qword ptr [rdi], rbp
0108cb8e  48896f08                 mov qword ptr [rdi + 8], rbp
0108cb92  894710                   mov dword ptr [rdi + 0x10], eax
0108cb95  488b4318                 mov rax, qword ptr [rbx + 0x18]
0108cb99  48894718                 mov qword ptr [rdi + 0x18], rax
0108cb9d  eb03                     jmp 0x108cba2
0108cb9f  488bfd                   mov rdi, rbp
0108cba2  eb50                     jmp 0x108cbf4
0108cba4  c78424a8000000e7060000   mov dword ptr [rsp + 0xa8], 0x6e7
0108cbaf  c644242003               mov byte ptr [rsp + 0x20], 3
0108cbb4  41b9e7060000             mov r9d, 0x6e7
0108cbba  4c8d0547213a01           lea r8, [rip + 0x13a2147]
0108cbc1  498bd7                   mov rdx, r15
0108cbc4  b920000000               mov ecx, 0x20
0108cbc9  ff15e1e2e300             call qword ptr [rip + 0xe3e2e1]
0108cbcf  488bf8                   mov rdi, rax
0108cbd2  4889442448               mov qword ptr [rsp + 0x48], rax
0108cbd7  4885c0                   test rax, rax
0108cbda  7415                     je 0x108cbf1
0108cbdc  8b4310                   mov eax, dword ptr [rbx + 0x10]
0108cbdf  48892f                   mov qword ptr [rdi], rbp
0108cbe2  48896f08                 mov qword ptr [rdi + 8], rbp
0108cbe6  894710                   mov dword ptr [rdi + 0x10], eax
0108cbe9  8b4318                   mov eax, dword ptr [rbx + 0x18]
0108cbec  894718                   mov dword ptr [rdi + 0x18], eax
0108cbef  eb03                     jmp 0x108cbf4
0108cbf1  488bfd                   mov rdi, rbp
0108cbf4  4885ff                   test rdi, rdi
0108cbf7  7418                     je 0x108cc11
0108cbf9  488b4e08                 mov rcx, qword ptr [rsi + 8]
0108cbfd  488b01                   mov rax, qword ptr [rcx]
0108cc00  488907                   mov qword ptr [rdi], rax
0108cc03  488b01                   mov rax, qword ptr [rcx]
0108cc06  48897808                 mov qword ptr [rax + 8], rdi
0108cc0a  488939                   mov qword ptr [rcx], rdi
0108cc0d  48894f08                 mov qword ptr [rdi + 8], rcx
0108cc11  488b5b08                 mov rbx, qword ptr [rbx + 8]
0108cc15  493b5e08                 cmp rbx, qword ptr [r14 + 8]
0108cc19  7411                     je 0x108cc2c
0108cc1b  4885db                   test rbx, rbx
0108cc1e  0f859cfeffff             jne 0x108cac0
0108cc24  eb06                     jmp 0x108cc2c
0108cc26  33ed                     xor ebp, ebp
0108cc28  48896908                 mov qword ptr [rcx + 8], rbp
0108cc2c  488bc6                   mov rax, rsi
0108cc2f  4883c450                 add rsp, 0x50
0108cc33  415f                     pop r15
0108cc35  415e                     pop r14
0108cc37  415c                     pop r12
0108cc39  5f                       pop rdi
0108cc3a  5e                       pop rsi
0108cc3b  5d                       pop rbp
0108cc3c  5b                       pop rbx
0108cc3d  c3                       ret
0108cc3e  6690                     nop
0108cc40  daca                     fcmove st(0), st(2)
0108cc42  0801                     or byte ptr [rcx], al
0108cc44  50                       push rax
0108cc45  cb                       retf
0108cc46  0801                     or byte ptr [rcx], al
0108cc48  a4                       movsb byte ptr [rdi], byte ptr [rsi]
0108cc49  cb                       retf
0108cc4a  0801                     or byte ptr [rcx], al
0108cc4c  a4                       movsb byte ptr [rdi], byte ptr [rsi]
0108cc4d  cb                       retf
0108cc4e  0801                     or byte ptr [rcx], al
0108cc50  a4                       movsb byte ptr [rdi], byte ptr [rsi]
0108cc51  cb                       retf
0108cc52  0801                     or byte ptr [rcx], al
0108cc54  a4                       movsb byte ptr [rdi], byte ptr [rsi]
0108cc55  cb                       retf
0108cc56  0801                     or byte ptr [rcx], al
0108cc58  daca                     fcmove st(0), st(2)
0108cc5a  0801                     or byte ptr [rcx], al
