; CDecompressBatchLoader<Level1Batch,CLevel1Decompressor,CSimpleRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x96f7f0, 1488 bytes in 3 chunk(s)

; chunk at RVA 0x96f7f0 (47 bytes)
0096f7f0  4c894c2420               mov qword ptr [rsp + 0x20], r9
0096f7f5  89542410                 mov dword ptr [rsp + 0x10], edx
0096f7f9  53                       push rbx
0096f7fa  4154                     push r12
0096f7fc  4881ecb8000000           sub rsp, 0xb8
0096f803  83792002                 cmp dword ptr [rcx + 0x20], 2
0096f807  4d8be0                   mov r12, r8
0096f80a  448bd2                   mov r10d, edx
0096f80d  488bd9                   mov rbx, rcx
0096f810  750d                     jne 0x96f81f
0096f812  33c0                     xor eax, eax
0096f814  4881c4b8000000           add rsp, 0xb8
0096f81b  415c                     pop r12
0096f81d  5b                       pop rbx
0096f81e  c3                       ret

; chunk at RVA 0x96f81f (1345 bytes)
0096f81f  4889ac24e0000000         mov qword ptr [rsp + 0xe0], rbp
0096f827  0f57c0                   xorps xmm0, xmm0
0096f82a  4889b424b0000000         mov qword ptr [rsp + 0xb0], rsi
0096f832  33f6                     xor esi, esi
0096f834  4889bc24a8000000         mov qword ptr [rsp + 0xa8], rdi
0096f83c  32c0                     xor al, al
0096f83e  4c89ac24a0000000         mov qword ptr [rsp + 0xa0], r13
0096f846  448bee                   mov r13d, esi
0096f849  4c89b42498000000         mov qword ptr [rsp + 0x98], r14
0096f851  888424d0000000           mov byte ptr [rsp + 0xd0], al
0096f858  4c89bc2490000000         mov qword ptr [rsp + 0x90], r15
0096f860  89742450                 mov dword ptr [rsp + 0x50], esi
0096f864  4889742458               mov qword ptr [rsp + 0x58], rsi
0096f869  4088742460               mov byte ptr [rsp + 0x60], sil
0096f86e  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
0096f874  4889b42480000000         mov qword ptr [rsp + 0x80], rsi
0096f87c  4188742410               mov byte ptr [r12 + 0x10], sil
0096f881  4c8d1d780769ff           lea r11, [rip - 0x96f888]
0096f888  4038b318030000           cmp byte ptr [rbx + 0x318], sil
0096f88f  0f84c8000000             je 0x96f95d
0096f895  4c8b8b10030000           mov r9, qword ptr [rbx + 0x310]
0096f89c  488d7c2450               lea rdi, [rsp + 0x50]
0096f8a1  4088b318030000           mov byte ptr [rbx + 0x318], sil
0096f8a8  41bd01000000             mov r13d, 1
0096f8ae  41ff0424                 inc dword ptr [r12]
0096f8b2  418b1424                 mov edx, dword ptr [r12]
0096f8b6  4d8b4120                 mov r8, qword ptr [r9 + 0x20]
0096f8ba  ffca                     dec edx
0096f8bc  498b4c2420               mov rcx, qword ptr [r12 + 0x20]
0096f8c1  89742450                 mov dword ptr [rsp + 0x50], esi
0096f8c5  498b00                   mov rax, qword ptr [r8]
0096f8c8  488904d1                 mov qword ptr [rcx + rdx*8], rax
0096f8cc  4d8b4130                 mov r8, qword ptr [r9 + 0x30]
0096f8d0  418b1424                 mov edx, dword ptr [r12]
0096f8d4  498b4c2430               mov rcx, qword ptr [r12 + 0x30]
0096f8d9  ffca                     dec edx
0096f8db  418b00                   mov eax, dword ptr [r8]
0096f8de  890491                   mov dword ptr [rcx + rdx*4], eax
0096f8e1  418b1424                 mov edx, dword ptr [r12]
0096f8e5  4d8b4128                 mov r8, qword ptr [r9 + 0x28]
0096f8e9  ffca                     dec edx
0096f8eb  498b4c2428               mov rcx, qword ptr [r12 + 0x28]
0096f8f0  4c8b8c24e8000000         mov r9, qword ptr [rsp + 0xe8]
0096f8f8  418b00                   mov eax, dword ptr [r8]
0096f8fb  890491                   mov dword ptr [rcx + rdx*4], eax
0096f8fe  488b8310030000           mov rax, qword ptr [rbx + 0x310]
0096f905  ff08                     dec dword ptr [rax]
0096f907  418b1424                 mov edx, dword ptr [r12]
0096f90b  498b442408               mov rax, qword ptr [r12 + 8]
0096f910  4889442458               mov qword ptr [rsp + 0x58], rax
0096f915  498b442420               mov rax, qword ptr [r12 + 0x20]
0096f91a  488d0cd0                 lea rcx, [rax + rdx*8]
0096f91e  498b442428               mov rax, qword ptr [r12 + 0x28]
0096f923  48894c2470               mov qword ptr [rsp + 0x70], rcx
0096f928  488d0c90                 lea rcx, [rax + rdx*4]
0096f92c  498b442430               mov rax, qword ptr [r12 + 0x30]
0096f931  48894c2478               mov qword ptr [rsp + 0x78], rcx
0096f936  4088b318030000           mov byte ptr [rbx + 0x318], sil
0096f93d  488d0c90                 lea rcx, [rax + rdx*4]
0096f941  b801000000               mov eax, 1
0096f946  2bc2                     sub eax, edx
0096f948  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
0096f950  4403d0                   add r10d, eax
0096f953  44899424d8000000         mov dword ptr [rsp + 0xd8], r10d
0096f95b  eb03                     jmp 0x96f960
0096f95d  498bfc                   mov rdi, r12
0096f960  397320                   cmp dword ptr [rbx + 0x20], esi
0096f963  0f8581000000             jne 0x96f9ea
0096f969  488b4328                 mov rax, qword ptr [rbx + 0x28]
0096f96d  488d4b28                 lea rcx, [rbx + 0x28]
0096f971  4d8bc1                   mov r8, r9
0096f974  4889742420               mov qword ptr [rsp + 0x20], rsi
0096f979  488d542420               lea rdx, [rsp + 0x20]
0096f97e  89742428                 mov dword ptr [rsp + 0x28], esi
0096f982  4889742430               mov qword ptr [rsp + 0x30], rsi
0096f987  89742438                 mov dword ptr [rsp + 0x38], esi
0096f98b  4889742440               mov qword ptr [rsp + 0x40], rsi
0096f990  89742448                 mov dword ptr [rsp + 0x48], esi
0096f994  668974244c               mov word ptr [rsp + 0x4c], si
0096f999  c68424d000000001         mov byte ptr [rsp + 0xd0], 1
0096f9a1  ff10                     call qword ptr [rax]
0096f9a3  3dc60e0400               cmp eax, 0x40ec6
0096f9a8  0f8451030000             je 0x96fcff
0096f9ae  488b4c2420               mov rcx, qword ptr [rsp + 0x20]
0096f9b3  4c8d1d460669ff           lea r11, [rip - 0x96f9ba]
0096f9ba  8b442428                 mov eax, dword ptr [rsp + 0x28]
0096f9be  448b9424d8000000         mov r10d, dword ptr [rsp + 0xd8]
0096f9c6  48894b50                 mov qword ptr [rbx + 0x50], rcx
0096f9ca  48894b58                 mov qword ptr [rbx + 0x58], rcx
0096f9ce  894348                   mov dword ptr [rbx + 0x48], eax
0096f9d1  48897340                 mov qword ptr [rbx + 0x40], rsi
0096f9d5  6689b308030000           mov word ptr [rbx + 0x308], si
0096f9dc  4889b300030000           mov qword ptr [rbx + 0x300], rsi
0096f9e3  c7432001000000           mov dword ptr [rbx + 0x20], 1
0096f9ea  488b4330                 mov rax, qword ptr [rbx + 0x30]
0096f9ee  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
0096f9f5  4c894708                 mov qword ptr [rdi + 8], r8
0096f9f9  488b5330                 mov rdx, qword ptr [rbx + 0x30]
0096f9fd  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
0096fa04  8b423c                   mov eax, dword ptr [rdx + 0x3c]
0096fa07  83e007                   and eax, 7
0096fa0a  83f805                   cmp eax, 5
0096fa0d  7741                     ja 0x96fa50
0096fa0f  4898                     cdqe
0096fa11  418b8c8360fd9600         mov ecx, dword ptr [r11 + rax*4 + 0x96fd60]
0096fa19  4903cb                   add rcx, r11
0096fa1c  ffe1                     jmp rcx
0096fa1e  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096fa22  400f95c5                 setne bpl
0096fa26  eb2b                     jmp 0x96fa53
0096fa28  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096fa2c  400f9dc5                 setge bpl
0096fa30  eb21                     jmp 0x96fa53
0096fa32  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096fa36  400f9ec5                 setle bpl
0096fa3a  eb17                     jmp 0x96fa53
0096fa3c  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096fa40  400f9fc5                 setg bpl
0096fa44  eb0d                     jmp 0x96fa53
0096fa46  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096fa4a  400f9cc5                 setl bpl
0096fa4e  eb03                     jmp 0x96fa53
0096fa50  4032ed                   xor bpl, bpl
0096fa53  8b424c                   mov eax, dword ptr [rdx + 0x4c]
0096fa56  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
0096fa5d  83e007                   and eax, 7
0096fa60  83f805                   cmp eax, 5
0096fa63  7741                     ja 0x96faa6
0096fa65  4898                     cdqe
0096fa67  418b8c8378fd9600         mov ecx, dword ptr [r11 + rax*4 + 0x96fd78]
0096fa6f  4903cb                   add rcx, r11
0096fa72  ffe1                     jmp rcx
0096fa74  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0096fa78  410f95c7                 setne r15b
0096fa7c  eb2b                     jmp 0x96faa9
0096fa7e  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0096fa82  410f9dc7                 setge r15b
0096fa86  eb21                     jmp 0x96faa9
0096fa88  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0096fa8c  410f9ec7                 setle r15b
0096fa90  eb17                     jmp 0x96faa9
0096fa92  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0096fa96  410f9fc7                 setg r15b
0096fa9a  eb0d                     jmp 0x96faa9
0096fa9c  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0096faa0  410f9cc7                 setl r15b
0096faa4  eb03                     jmp 0x96faa9
0096faa6  4532ff                   xor r15b, r15b
0096faa9  488d4b38                 lea rcx, [rbx + 0x38]
0096faad  4c8bc7                   mov r8, rdi
0096fab0  418bd2                   mov edx, r10d
0096fab3  e808dcffff               call 0x96d6c0
0096fab8  84c0                     test al, al
0096faba  7503                     jne 0x96fabf
0096fabc  897320                   mov dword ptr [rbx + 0x20], esi
0096fabf  8b07                     mov eax, dword ptr [rdi]
0096fac1  448bc8                   mov r9d, eax
0096fac4  85c0                     test eax, eax
0096fac6  0f8496010000             je 0x96fc62
0096facc  4084ed                   test bpl, bpl
0096facf  7509                     jne 0x96fada
0096fad1  4584ff                   test r15b, r15b
0096fad4  0f8488010000             je 0x96fc62
0096fada  448bc0                   mov r8d, eax
0096fadd  4084ed                   test bpl, bpl
0096fae0  747c                     je 0x96fb5e
0096fae2  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
0096fae6  448bce                   mov r9d, esi
0096fae9  85c0                     test eax, eax
0096faeb  746a                     je 0x96fb57
0096faed  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
0096faf1  488d2d080569ff           lea rbp, [rip - 0x96faf8]
0096faf8  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
0096fafc  4183e007                 and r8d, 7
0096fb00  418bc9                   mov ecx, r9d
0096fb03  4d8b14ce                 mov r10, qword ptr [r14 + rcx*8]
0096fb07  4183f805                 cmp r8d, 5
0096fb0b  0f87ae000000             ja 0x96fbbf
0096fb11  4963c8                   movsxd rcx, r8d
0096fb14  8b948d90fd9600           mov edx, dword ptr [rbp + rcx*4 + 0x96fd90]
0096fb1b  4803d5                   add rdx, rbp
0096fb1e  ffe2                     jmp rdx
0096fb20  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
0096fb24  0f94c1                   sete cl
0096fb27  eb22                     jmp 0x96fb4b
0096fb29  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
0096fb2d  0f9cc1                   setl cl
0096fb30  eb19                     jmp 0x96fb4b
0096fb32  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
0096fb36  0f9fc1                   setg cl
0096fb39  eb10                     jmp 0x96fb4b
0096fb3b  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
0096fb3f  0f9ec1                   setle cl
0096fb42  eb07                     jmp 0x96fb4b
0096fb44  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
0096fb48  0f9dc1                   setge cl
0096fb4b  84c9                     test cl, cl
0096fb4d  7570                     jne 0x96fbbf
0096fb4f  41ffc1                   inc r9d
0096fb52  443bc8                   cmp r9d, eax
0096fb55  72a9                     jb 0x96fb00
0096fb57  8937                     mov dword ptr [rdi], esi
0096fb59  8bc6                     mov eax, esi
0096fb5b  448bc6                   mov r8d, esi
0096fb5e  458bc8                   mov r9d, r8d
0096fb61  4584ff                   test r15b, r15b
0096fb64  0f84f8000000             je 0x96fc62
0096fb6a  85c0                     test eax, eax
0096fb6c  0f84f0000000             je 0x96fc62
0096fb72  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
0096fb76  4c8d3d830469ff           lea r15, [rip - 0x96fb7d]
0096fb7d  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
0096fb81  0f1f4000                 nop dword ptr [rax]
0096fb85  6666660f1f840000000000   nop word ptr [rax + rax]
0096fb90  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
0096fb94  ffc8                     dec eax
0096fb96  458bd0                   mov r10d, r8d
0096fb99  83e107                   and ecx, 7
0096fb9c  448bc0                   mov r8d, eax
0096fb9f  458bca                   mov r9d, r10d
0096fba2  498b2cc6                 mov rbp, qword ptr [r14 + rax*8]
0096fba6  83f905                   cmp ecx, 5
0096fba9  0f87b3000000             ja 0x96fc62
0096fbaf  4863c9                   movsxd rcx, ecx
0096fbb2  418b948fa8fd9600         mov edx, dword ptr [r15 + rcx*4 + 0x96fda8]
0096fbba  4903d7                   add rdx, r15
0096fbbd  ffe2                     jmp rdx
0096fbbf  443bc8                   cmp r9d, eax
0096fbc2  7393                     jae 0x96fb57
0096fbc4  448bc0                   mov r8d, eax
0096fbc7  4585c9                   test r9d, r9d
0096fbca  7492                     je 0x96fb5e
0096fbcc  448bde                   mov r11d, esi
0096fbcf  452bc1                   sub r8d, r9d
0096fbd2  7447                     je 0x96fc1b
0096fbd4  4c8bd6                   mov r10, rsi
0096fbd7  4c8bf6                   mov r14, rsi
0096fbda  660f1f440000             nop word ptr [rax + rax]
0096fbe0  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0096fbe4  438d040b                 lea eax, [r11 + r9]
0096fbe8  8bd0                     mov edx, eax
0096fbea  4d8d5204                 lea r10, [r10 + 4]
0096fbee  41ffc3                   inc r11d
0096fbf1  4d8d7608                 lea r14, [r14 + 8]
0096fbf5  488b04c1                 mov rax, qword ptr [rcx + rax*8]
0096fbf9  4989440ef8               mov qword ptr [r14 + rcx - 8], rax
0096fbfe  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
0096fc02  8b0491                   mov eax, dword ptr [rcx + rdx*4]
0096fc05  4189440afc               mov dword ptr [r10 + rcx - 4], eax
0096fc0a  488b4f28                 mov rcx, qword ptr [rdi + 0x28]
0096fc0e  8b0491                   mov eax, dword ptr [rcx + rdx*4]
0096fc11  4189440afc               mov dword ptr [r10 + rcx - 4], eax
0096fc16  453bd8                   cmp r11d, r8d
0096fc19  72c5                     jb 0x96fbe0
0096fc1b  448907                   mov dword ptr [rdi], r8d
0096fc1e  418bc0                   mov eax, r8d
0096fc21  e938ffffff               jmp 0x96fb5e
0096fc26  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
0096fc2a  0f94c1                   sete cl
0096fc2d  eb22                     jmp 0x96fc51
0096fc2f  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
0096fc33  0f9cc1                   setl cl
0096fc36  eb19                     jmp 0x96fc51
0096fc38  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
0096fc3c  0f9fc1                   setg cl
0096fc3f  eb10                     jmp 0x96fc51
0096fc41  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
0096fc45  0f9ec1                   setle cl
0096fc48  eb07                     jmp 0x96fc51
0096fc4a  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
0096fc4e  0f9dc1                   setge cl
0096fc51  84c9                     test cl, cl
0096fc53  750d                     jne 0x96fc62
0096fc55  8907                     mov dword ptr [rdi], eax
0096fc57  448bc8                   mov r9d, eax
0096fc5a  85c0                     test eax, eax
0096fc5c  0f852effffff             jne 0x96fb90
0096fc62  4038b319030000           cmp byte ptr [rbx + 0x319], sil
0096fc69  747a                     je 0x96fce5
0096fc6b  448b0f                   mov r9d, dword ptr [rdi]
0096fc6e  4585c9                   test r9d, r9d
0096fc71  7472                     je 0x96fce5
0096fc73  4c8b9310030000           mov r10, qword ptr [rbx + 0x310]
0096fc7a  c6831803000001           mov byte ptr [rbx + 0x318], 1
0096fc81  448b0f                   mov r9d, dword ptr [rdi]
0096fc84  41ffc9                   dec r9d
0096fc87  41ff02                   inc dword ptr [r10]
0096fc8a  418b12                   mov edx, dword ptr [r10]
0096fc8d  4c8b4720                 mov r8, qword ptr [rdi + 0x20]
0096fc91  ffca                     dec edx
0096fc93  498b4a20                 mov rcx, qword ptr [r10 + 0x20]
0096fc97  4b8b04c8                 mov rax, qword ptr [r8 + r9*8]
0096fc9b  488904d1                 mov qword ptr [rcx + rdx*8], rax
0096fc9f  418b12                   mov edx, dword ptr [r10]
0096fca2  4c8b4730                 mov r8, qword ptr [rdi + 0x30]
0096fca6  ffca                     dec edx
0096fca8  498b4a30                 mov rcx, qword ptr [r10 + 0x30]
0096fcac  438b0488                 mov eax, dword ptr [r8 + r9*4]
0096fcb0  890491                   mov dword ptr [rcx + rdx*4], eax
0096fcb3  418b12                   mov edx, dword ptr [r10]
0096fcb6  498b4a28                 mov rcx, qword ptr [r10 + 0x28]
0096fcba  ffca                     dec edx
0096fcbc  4c8b4728                 mov r8, qword ptr [rdi + 0x28]
0096fcc0  438b0488                 mov eax, dword ptr [r8 + r9*4]
0096fcc4  890491                   mov dword ptr [rcx + rdx*4], eax
0096fcc7  ff0f                     dec dword ptr [rdi]
0096fcc9  41c644241001             mov byte ptr [r12 + 0x10], 1
0096fccf  488b8310030000           mov rax, qword ptr [rbx + 0x310]
0096fcd6  488b4820                 mov rcx, qword ptr [rax + 0x20]
0096fcda  488b01                   mov rax, qword ptr [rcx]
0096fcdd  4989442418               mov qword ptr [r12 + 0x18], rax
0096fce2  448b0f                   mov r9d, dword ptr [rdi]
0096fce5  4503e9                   add r13d, r9d
0096fce8  7528                     jne 0x96fd12
0096fcea  448b9424d8000000         mov r10d, dword ptr [rsp + 0xd8]
0096fcf2  4c8b8c24e8000000         mov r9, qword ptr [rsp + 0xe8]
0096fcfa  e97dfbffff               jmp 0x96f87c
0096fcff  c7432002000000           mov dword ptr [rbx + 0x20], 2
0096fd06  41393424                 cmp dword ptr [r12], esi
0096fd0a  400f95c6                 setne sil
0096fd0e  8bc6                     mov eax, esi
0096fd10  eb13                     jmp 0x96fd25
0096fd12  0fb68424d0000000         movzx eax, byte ptr [rsp + 0xd0]
0096fd1a  f6d8                     neg al
0096fd1c  45892c24                 mov dword ptr [r12], r13d
0096fd20  1bc0                     sbb eax, eax
0096fd22  83c002                   add eax, 2
0096fd25  4c8bb42498000000         mov r14, qword ptr [rsp + 0x98]
0096fd2d  4c8bac24a0000000         mov r13, qword ptr [rsp + 0xa0]
0096fd35  488bbc24a8000000         mov rdi, qword ptr [rsp + 0xa8]
0096fd3d  488bb424b0000000         mov rsi, qword ptr [rsp + 0xb0]
0096fd45  488bac24e0000000         mov rbp, qword ptr [rsp + 0xe0]
0096fd4d  4c8bbc2490000000         mov r15, qword ptr [rsp + 0x90]
0096fd55  4881c4b8000000           add rsp, 0xb8
0096fd5c  415c                     pop r12
0096fd5e  5b                       pop rbx
0096fd5f  c3                       ret

; chunk at RVA 0x96fd60 (96 bytes)
0096fd60  50                       push rax
0096fd61  fa                       cli
0096fd62  96                       xchg esi, eax
0096fd63  001e                     add byte ptr [rsi], bl
0096fd65  fa                       cli
0096fd66  96                       xchg esi, eax
0096fd67  0028                     add byte ptr [rax], ch
0096fd69  fa                       cli
0096fd6a  96                       xchg esi, eax
0096fd6b  003cfa                   add byte ptr [rdx + rdi*8], bh
0096fd6e  96                       xchg esi, eax
0096fd6f  0032                     add byte ptr [rdx], dh
0096fd71  fa                       cli
0096fd72  96                       xchg esi, eax
0096fd73  0046fa                   add byte ptr [rsi - 6], al
0096fd76  96                       xchg esi, eax
0096fd77  00a6fa960074             add byte ptr [rsi + 0x740096fa], ah
0096fd7d  fa                       cli
0096fd7e  96                       xchg esi, eax
0096fd7f  007efa                   add byte ptr [rsi - 6], bh
0096fd82  96                       xchg esi, eax
0096fd83  0092fa960088             add byte ptr [rdx - 0x77ff6906], dl
0096fd89  fa                       cli
0096fd8a  96                       xchg esi, eax
0096fd8b  009cfa9600bffb           add byte ptr [rdx + rdi*8 - 0x440ff6a], bl
0096fd92  96                       xchg esi, eax
0096fd93  0020                     add byte ptr [rax], ah
0096fd95  fb                       sti
0096fd96  96                       xchg esi, eax
0096fd97  0029                     add byte ptr [rcx], ch
0096fd99  fb                       sti
0096fd9a  96                       xchg esi, eax
0096fd9b  003b                     add byte ptr [rbx], bh
0096fd9d  fb                       sti
0096fd9e  96                       xchg esi, eax
0096fd9f  0032                     add byte ptr [rdx], dh
0096fda1  fb                       sti
0096fda2  96                       xchg esi, eax
0096fda3  0044fb96                 add byte ptr [rbx + rdi*8 - 0x6a], al
0096fda7  0062fc                   add byte ptr [rdx - 4], ah
0096fdaa  96                       xchg esi, eax
0096fdab  0026                     add byte ptr [rsi], ah
0096fdad  fc                       cld
0096fdae  96                       xchg esi, eax
0096fdaf  002f                     add byte ptr [rdi], ch
0096fdb1  fc                       cld
0096fdb2  96                       xchg esi, eax
0096fdb3  0041fc                   add byte ptr [rcx - 4], al
0096fdb6  96                       xchg esi, eax
0096fdb7  0038                     add byte ptr [rax], bh
0096fdb9  fc                       cld
0096fdba  96                       xchg esi, eax
0096fdbb  004afc                   add byte ptr [rdx - 4], cl
0096fdbe  96                       xchg esi, eax
