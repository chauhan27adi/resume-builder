; CAppDomainManager::AppDomainStateTransitionLockHeld
; sqllang.dll, primary RVA 0x6c52c0, 324 bytes in 1 chunk(s)

; chunk at RVA 0x6c52c0 (324 bytes)
006c52c0  48895c2408               mov qword ptr [rsp + 8], rbx
006c52c5  4889742410               mov qword ptr [rsp + 0x10], rsi
006c52ca  57                       push rdi
006c52cb  4883ec20                 sub rsp, 0x20
006c52cf  488bda                   mov rbx, rdx
006c52d2  4963f8                   movsxd rdi, r8d
006c52d5  486392d4010000           movsxd rdx, dword ptr [rdx + 0x1d4]
006c52dc  488bf1                   mov rsi, rcx
006c52df  3bd7                     cmp edx, edi
006c52e1  0f8dd1000000             jge 0x6c53b8
006c52e7  0faee8                   lfence
006c52ea  8d42ff                   lea eax, [rdx - 1]
006c52ed  c7831c01000001000000     mov dword ptr [rbx + 0x11c], 1
006c52f7  4c8d0502ad93ff           lea r8, [rip - 0x6c52fe]
006c52fe  83f806                   cmp eax, 6
006c5301  7746                     ja 0x6c5349
006c5303  4898                     cdqe
006c5305  418b8c80cc536c00         mov ecx, dword ptr [r8 + rax*4 + 0x6c53cc]
006c530d  4903c8                   add rcx, r8
006c5310  ffe1                     jmp rcx
006c5312  488d4203                 lea rax, [rdx + 3]
006c5316  488d0440                 lea rax, [rax + rax*2]
006c531a  ff4cc610                 dec dword ptr [rsi + rax*8 + 0x10]
006c531e  488b83b8000000           mov rax, qword ptr [rbx + 0xb8]
006c5325  488b8bc0000000           mov rcx, qword ptr [rbx + 0xc0]
006c532c  48894808                 mov qword ptr [rax + 8], rcx
006c5330  488901                   mov qword ptr [rcx], rax
006c5333  48c783c000000000000000   mov qword ptr [rbx + 0xc0], 0
006c533e  48c783b800000000000000   mov qword ptr [rbx + 0xb8], 0
006c5349  8d47ff                   lea eax, [rdi - 1]
006c534c  83f806                   cmp eax, 6
006c534f  773e                     ja 0x6c538f
006c5351  4898                     cdqe
006c5353  418b8c80e8536c00         mov ecx, dword ptr [r8 + rax*4 + 0x6c53e8]
006c535b  4903c8                   add rcx, r8
006c535e  ffe1                     jmp rcx
006c5360  0faee8                   lfence
006c5363  488d8bb8000000           lea rcx, [rbx + 0xb8]
006c536a  488d4703                 lea rax, [rdi + 3]
006c536e  488d0440                 lea rax, [rax + rax*2]
006c5372  ff44c610                 inc dword ptr [rsi + rax*8 + 0x10]
006c5376  488d14c6                 lea rdx, [rsi + rax*8]
006c537a  488b04c6                 mov rax, qword ptr [rsi + rax*8]
006c537e  488901                   mov qword ptr [rcx], rax
006c5381  488b02                   mov rax, qword ptr [rdx]
006c5384  48894808                 mov qword ptr [rax + 8], rcx
006c5388  48890a                   mov qword ptr [rdx], rcx
006c538b  48895108                 mov qword ptr [rcx + 8], rdx
006c538f  8bd7                     mov edx, edi
006c5391  488bcb                   mov rcx, rbx
006c5394  e8d7b6feff               call 0x6b0a70
006c5399  f0ff44be10               lock inc dword ptr [rsi + rdi*4 + 0x10]
006c539e  c7831c01000000000000     mov dword ptr [rbx + 0x11c], 0
006c53a8  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
006c53ad  488b742438               mov rsi, qword ptr [rsp + 0x38]
006c53b2  4883c420                 add rsp, 0x20
006c53b6  5f                       pop rdi
006c53b7  c3                       ret
006c53b8  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
006c53bd  33c0                     xor eax, eax
006c53bf  488b742438               mov rsi, qword ptr [rsp + 0x38]
006c53c4  4883c420                 add rsp, 0x20
006c53c8  5f                       pop rdi
006c53c9  c3                       ret
006c53ca  90                       nop
006c53cb  90                       nop
006c53cc  12536c                   adc dl, byte ptr [rbx + 0x6c]
006c53cf  0012                     add byte ptr [rdx], dl
006c53d1  53                       push rbx
006c53d2  6c                       insb byte ptr [rdi], dx
006c53d3  0012                     add byte ptr [rdx], dl
006c53d5  53                       push rbx
006c53d6  6c                       insb byte ptr [rdi], dx
006c53d7  0012                     add byte ptr [rdx], dl
006c53d9  53                       push rbx
006c53da  6c                       insb byte ptr [rdi], dx
006c53db  0012                     add byte ptr [rdx], dl
006c53dd  53                       push rbx
006c53de  6c                       insb byte ptr [rdi], dx
006c53df  0012                     add byte ptr [rdx], dl
006c53e1  53                       push rbx
006c53e2  6c                       insb byte ptr [rdi], dx
006c53e3  0012                     add byte ptr [rdx], dl
006c53e5  53                       push rbx
006c53e6  6c                       insb byte ptr [rdi], dx
006c53e7  006053                   add byte ptr [rax + 0x53], ah
006c53ea  6c                       insb byte ptr [rdi], dx
006c53eb  006053                   add byte ptr [rax + 0x53], ah
006c53ee  6c                       insb byte ptr [rdi], dx
006c53ef  006053                   add byte ptr [rax + 0x53], ah
006c53f2  6c                       insb byte ptr [rdi], dx
006c53f3  006053                   add byte ptr [rax + 0x53], ah
006c53f6  6c                       insb byte ptr [rdi], dx
006c53f7  006053                   add byte ptr [rax + 0x53], ah
006c53fa  6c                       insb byte ptr [rdi], dx
006c53fb  006053                   add byte ptr [rax + 0x53], ah
006c53fe  6c                       insb byte ptr [rdi], dx
006c53ff  006053                   add byte ptr [rax + 0x53], ah
006c5402  6c                       insb byte ptr [rdi], dx
