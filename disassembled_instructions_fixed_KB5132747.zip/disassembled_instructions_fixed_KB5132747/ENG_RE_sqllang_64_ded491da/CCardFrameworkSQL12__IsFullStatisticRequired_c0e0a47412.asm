; CCardFrameworkSQL12::IsFullStatisticRequired
; sqllang.dll, primary RVA 0x18f2600, 91 bytes in 1 chunk(s)

; chunk at RVA 0x18f2600 (91 bytes)
018f2600  4883ec28                 sub rsp, 0x28
018f2604  488b02                   mov rax, qword ptr [rdx]
018f2607  488bca                   mov rcx, rdx
018f260a  ff5018                   call qword ptr [rax + 0x18]
018f260d  83c0f2                   add eax, -0xe
018f2610  83f812                   cmp eax, 0x12
018f2613  7724                     ja 0x18f2639
018f2615  488d15e4d970fe           lea rdx, [rip - 0x18f261c]
018f261c  4898                     cdqe
018f261e  0fb6840248268f01         movzx eax, byte ptr [rdx + rax + 0x18f2648]
018f2626  8b8c8240268f01           mov ecx, dword ptr [rdx + rax*4 + 0x18f2640]
018f262d  4803ca                   add rcx, rdx
018f2630  ffe1                     jmp rcx
018f2632  b001                     mov al, 1
018f2634  4883c428                 add rsp, 0x28
018f2638  c3                       ret
018f2639  32c0                     xor al, al
018f263b  4883c428                 add rsp, 0x28
018f263f  c3                       ret
018f2640  3226                     xor ah, byte ptr [rsi]
018f2642  8f01                     pop qword ptr [rcx]
018f2644  3926                     cmp dword ptr [rsi], esp
018f2646  8f01                     pop qword ptr [rcx]
018f2648  0001                     add byte ptr [rcx], al
018f264a  0000                     add byte ptr [rax], al
018f264c  0000                     add byte ptr [rax], al
018f264e  0000                     add byte ptr [rax], al
018f2650  0001                     add byte ptr [rcx], al
018f2652  0101                     add dword ptr [rcx], eax
018f2654  0101                     add dword ptr [rcx], eax
018f2656  0101                     add dword ptr [rcx], eax
018f2658  0101                     add dword ptr [rcx], eax
