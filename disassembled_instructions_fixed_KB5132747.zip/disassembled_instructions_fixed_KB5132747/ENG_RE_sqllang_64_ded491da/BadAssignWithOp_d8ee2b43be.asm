; BadAssignWithOp
; sqllang.dll, primary RVA 0x9f2f40, 196 bytes in 1 chunk(s)

; chunk at RVA 0x9f2f40 (196 bytes)
009f2f40  4883ec48                 sub rsp, 0x48
009f2f44  4533c0                   xor r8d, r8d
009f2f47  448bd2                   mov r10d, edx
009f2f4a  83f909                   cmp ecx, 9
009f2f4d  775c                     ja 0x9f2fab
009f2f4f  4863c1                   movsxd rax, ecx
009f2f52  488d15a7d060ff           lea rdx, [rip - 0x9f2f59]
009f2f59  8b8c82dc2f9f00           mov ecx, dword ptr [rdx + rax*4 + 0x9f2fdc]
009f2f60  4803ca                   add rcx, rdx
009f2f63  ffe1                     jmp rcx
009f2f65  4c8d055c5ea201           lea r8, [rip + 0x1a25e5c]
009f2f6c  eb3d                     jmp 0x9f2fab
009f2f6e  4c8d055b5ea201           lea r8, [rip + 0x1a25e5b]
009f2f75  eb34                     jmp 0x9f2fab
009f2f77  4c8d056a5da201           lea r8, [rip + 0x1a25d6a]
009f2f7e  eb2b                     jmp 0x9f2fab
009f2f80  4c8d05695da201           lea r8, [rip + 0x1a25d69]
009f2f87  eb22                     jmp 0x9f2fab
009f2f89  4c8d05685da201           lea r8, [rip + 0x1a25d68]
009f2f90  eb19                     jmp 0x9f2fab
009f2f92  4c8d05675da201           lea r8, [rip + 0x1a25d67]
009f2f99  eb10                     jmp 0x9f2fab
009f2f9b  4c8d05da5ca201           lea r8, [rip + 0x1a25cda]
009f2fa2  eb07                     jmp 0x9f2fab
009f2fa4  4c8d05d95ca201           lea r8, [rip + 0x1a25cd9]
009f2fab  4c89442430               mov qword ptr [rsp + 0x30], r8
009f2fb0  ba6b000000               mov edx, 0x6b
009f2fb5  c744242804000000         mov dword ptr [rsp + 0x28], 4
009f2fbd  418bca                   mov ecx, r10d
009f2fc0  c744242001000000         mov dword ptr [rsp + 0x20], 1
009f2fc8  448d4aa4                 lea r9d, [rdx - 0x5c]
009f2fcc  448d429d                 lea r8d, [rdx - 0x63]
009f2fd0  e89bb70800               call 0xa7e770
009f2fd5  4883c448                 add rsp, 0x48
009f2fd9  c3                       ret
009f2fda  90                       nop
009f2fdb  90                       nop
