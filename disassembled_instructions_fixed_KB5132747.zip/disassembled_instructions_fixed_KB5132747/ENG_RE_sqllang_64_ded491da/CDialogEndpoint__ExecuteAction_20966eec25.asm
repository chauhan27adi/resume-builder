; CDialogEndpoint::ExecuteAction
; sqllang.dll, primary RVA 0x4c71d0, 1320 bytes in 1 chunk(s)

; chunk at RVA 0x4c71d0 (1320 bytes)
004c71d0  488bc4                   mov rax, rsp
004c71d3  55                       push rbp
004c71d4  4156                     push r14
004c71d6  4157                     push r15
004c71d8  488da8c8feffff           lea rbp, [rax - 0x138]
004c71df  4881ec20020000           sub rsp, 0x220
004c71e6  48c74598feffffff         mov qword ptr [rbp - 0x68], 0xfffffffffffffffe
004c71ee  48895810                 mov qword ptr [rax + 0x10], rbx
004c71f2  48897018                 mov qword ptr [rax + 0x18], rsi
004c71f6  48897820                 mov qword ptr [rax + 0x20], rdi
004c71fa  488b05871a6102           mov rax, qword ptr [rip + 0x2611a87]
004c7201  4833c4                   xor rax, rsp
004c7204  48898510010000           mov qword ptr [rbp + 0x110], rax
004c720b  4c8bf1                   mov r14, rcx
004c720e  83fa0a                   cmp edx, 0xa
004c7211  0f8782040000             ja 0x4c7699
004c7217  4863c2                   movsxd rax, edx
004c721a  488d15df8db3ff           lea rdx, [rip - 0x4c7221]
004c7221  8b8c82cc764c00           mov ecx, dword ptr [rdx + rax*4 + 0x4c76cc]
004c7228  4803ca                   add rcx, rdx
004c722b  ffe1                     jmp rcx
004c722d  41837e7406               cmp dword ptr [r14 + 0x74], 6
004c7232  750b                     jne 0x4c723f
004c7234  41837e300d               cmp dword ptr [r14 + 0x30], 0xd
004c7239  0f855a040000             jne 0x4c7699
004c723f  4533c0                   xor r8d, r8d
004c7242  418d5001                 lea edx, [r8 + 1]
004c7246  488d4d88                 lea rcx, [rbp - 0x78]
004c724a  ff15780b6102             call qword ptr [rip + 0x2610b78]
004c7250  4180bef800000000         cmp byte ptr [r14 + 0xf8], 0
004c7258  0f85c1000000             jne 0x4c731f
004c725e  41837e7400               cmp dword ptr [r14 + 0x74], 0
004c7263  0f84b6000000             je 0x4c731f
004c7269  41837e300d               cmp dword ptr [r14 + 0x30], 0xd
004c726e  0f84ab000000             je 0x4c731f
004c7274  498b8638010000           mov rax, qword ptr [r14 + 0x138]
004c727b  4889442478               mov qword ptr [rsp + 0x78], rax
004c7280  ba08000000               mov edx, 8
004c7285  41b826070000             mov r8d, 0x726
004c728b  488d4c2478               lea rcx, [rsp + 0x78]
004c7290  ff15ea49a001             call qword ptr [rip + 0x1a049ea]
004c7296  85c0                     test eax, eax
004c7298  7442                     je 0x4c72dc
004c729a  83f801                   cmp eax, 1
004c729d  742d                     je 0x4c72cc
004c729f  488d058212c901           lea rax, [rip + 0x1c91282]
004c72a6  4889442420               mov qword ptr [rsp + 0x20], rax
004c72ab  41b95a170000             mov r9d, 0x175a
004c72b1  4c8d05d8ef0402           lea r8, [rip + 0x204efd8]
004c72b8  488d1581d70402           lea rdx, [rip + 0x204d781]
004c72bf  b901000000               mov ecx, 1
004c72c4  ff15ae3ba001             call qword ptr [rip + 0x1a03bae]
004c72ca  eb10                     jmp 0x4c72dc
004c72cc  c744247c7f242d00         mov dword ptr [rsp + 0x7c], 0x2d247f
004c72d4  c7442478ff818b01         mov dword ptr [rsp + 0x78], 0x18b81ff
004c72dc  498b8e10020000           mov rcx, qword ptr [r14 + 0x210]
004c72e3  488b442478               mov rax, qword ptr [rsp + 0x78]
004c72e8  4885c9                   test rcx, rcx
004c72eb  7409                     je 0x4c72f6
004c72ed  483bc1                   cmp rax, rcx
004c72f0  7c04                     jl 0x4c72f6
004c72f2  480f45c1                 cmovne rax, rcx
004c72f6  483b4588                 cmp rax, qword ptr [rbp - 0x78]
004c72fa  7c23                     jl 0x4c731f
004c72fc  7421                     je 0x4c731f
004c72fe  498d8e80000000           lea rcx, [r14 + 0x80]
004c7305  e8f69e0200               call 0x4f1200
004c730a  498bce                   mov rcx, r14
004c730d  e84e390000               call 0x4cac60
004c7312  41c7467406000000         mov dword ptr [r14 + 0x74], 6
004c731a  e97a030000               jmp 0x4c7699
004c731f  498bce                   mov rcx, r14
004c7322  e8293c0000               call 0x4caf50
004c7327  498d8e80000000           lea rcx, [r14 + 0x80]
004c732e  e80da90200               call 0x4f1c40
004c7333  41c7467406000000         mov dword ptr [r14 + 0x74], 6
004c733b  e959030000               jmp 0x4c7699
004c7340  498bce                   mov rcx, r14
004c7343  e808370000               call 0x4caa50
004c7348  e94c030000               jmp 0x4c7699
004c734d  498bce                   mov rcx, r14
004c7350  e82b330000               call 0x4ca680
004c7355  e93f030000               jmp 0x4c7699
004c735a  410f108648010000         movups xmm0, xmmword ptr [r14 + 0x148]
004c7362  0f11442478               movups xmmword ptr [rsp + 0x78], xmm0
004c7367  410f108e20010000         movups xmm1, xmmword ptr [r14 + 0x120]
004c736f  0f114d88                 movups xmmword ptr [rbp - 0x78], xmm1
004c7373  4183bec800000001         cmp dword ptr [r14 + 0xc8], 1
004c737b  7c0a                     jl 0x4c7387
004c737d  410fb6be9a020000         movzx edi, byte ptr [r14 + 0x29a]
004c7385  eb03                     jmp 0x4c738a
004c7387  40b705                   mov dil, 5
004c738a  498bce                   mov rcx, r14
004c738d  e87efdffff               call 0x4c7110
004c7392  488bd8                   mov rbx, rax
004c7395  4533ff                   xor r15d, r15d
004c7398  4183ff02                 cmp r15d, 2
004c739c  750a                     jne 0x4c73a8
004c739e  498bce                   mov rcx, r14
004c73a1  e8da320000               call 0x4ca680
004c73a6  eb47                     jmp 0x4c73ef
004c73a8  488d4588                 lea rax, [rbp - 0x78]
004c73ac  4889442420               mov qword ptr [rsp + 0x20], rax
004c73b1  440fb6cf                 movzx r9d, dil
004c73b5  4c8d442478               lea r8, [rsp + 0x78]
004c73ba  418bd7                   mov edx, r15d
004c73bd  488bcb                   mov rcx, rbx
004c73c0  e88b6b0300               call 0x4fdf50
004c73c5  488b03                   mov rax, qword ptr [rbx]
004c73c8  488bcb                   mov rcx, rbx
004c73cb  ff5030                   call qword ptr [rax + 0x30]
004c73ce  84c0                     test al, al
004c73d0  741d                     je 0x4c73ef
004c73d2  488b03                   mov rax, qword ptr [rbx]
004c73d5  488bcb                   mov rcx, rbx
004c73d8  ff5070                   call qword ptr [rax + 0x70]
004c73db  b103                     mov cl, 3
004c73dd  e80e61b4ff               call 0xd4f0
004c73e2  488b03                   mov rax, qword ptr [rbx]
004c73e5  488bcb                   mov rcx, rbx
004c73e8  ff5030                   call qword ptr [rax + 0x30]
004c73eb  84c0                     test al, al
004c73ed  75e3                     jne 0x4c73d2
004c73ef  41ffc7                   inc r15d
004c73f2  4183ff04                 cmp r15d, 4
004c73f6  7ca0                     jl 0x4c7398
004c73f8  498d8e80000000           lea rcx, [r14 + 0x80]
004c73ff  e8fc9d0200               call 0x4f1200
004c7404  e990020000               jmp 0x4c7699
004c7409  498bce                   mov rcx, r14
004c740c  e83f3b0000               call 0x4caf50
004c7411  e983020000               jmp 0x4c7699
004c7416  4533ff                   xor r15d, r15d
004c7419  41837e7804               cmp dword ptr [r14 + 0x78], 4
004c741e  410f95c7                 setne r15b
004c7422  41ffc7                   inc r15d
004c7425  41807e2e00               cmp byte ptr [r14 + 0x2e], 0
004c742a  7515                     jne 0x4c7441
004c742c  498b8630040000           mov rax, qword ptr [r14 + 0x430]
004c7433  4885c0                   test rax, rax
004c7436  7409                     je 0x4c7441
004c7438  44897810                 mov dword ptr [rax + 0x10], r15d
004c743c  e958020000               jmp 0x4c7699
004c7441  498b9e40040000           mov rbx, qword ptr [r14 + 0x440]
004c7448  ff15ea096102             call qword ptr [rip + 0x26109ea]
004c744e  83b8c82e000000           cmp dword ptr [rax + 0x2ec8], 0
004c7455  740d                     je 0x4c7464
004c7457  803da2ea610200           cmp byte ptr [rip + 0x261eaa2], 0
004c745e  0f8435020000             je 0x4c7699
004c7464  8b83c8010000             mov eax, dword ptr [rbx + 0x1c8]
004c746a  83f801                   cmp eax, 1
004c746d  0f8526020000             jne 0x4c7699
004c7473  488b0506186102           mov rax, qword ptr [rip + 0x2611806]
004c747a  488b88f0a80000           mov rcx, qword ptr [rax + 0xa8f0]
004c7481  8b4150                   mov eax, dword ptr [rcx + 0x50]
004c7484  83f803                   cmp eax, 3
004c7487  0f840c020000             je 0x4c7699
004c748d  8b4150                   mov eax, dword ptr [rcx + 0x50]
004c7490  85c0                     test eax, eax
004c7492  0f8401020000             je 0x4c7699
004c7498  80bbe700000000           cmp byte ptr [rbx + 0xe7], 0
004c749f  0f85f4010000             jne 0x4c7699
004c74a5  498bbe40040000           mov rdi, qword ptr [r14 + 0x440]
004c74ac  488bbf38010000           mov rdi, qword ptr [rdi + 0x138]
004c74b3  65488b142558000000       mov rdx, qword ptr gs:[0x58]
004c74bc  488b05b53aa001           mov rax, qword ptr [rip + 0x1a03ab5]
004c74c3  8b18                     mov ebx, dword ptr [rax]
004c74c5  488b05b43aa001           mov rax, qword ptr [rip + 0x1a03ab4]
004c74cc  8b08                     mov ecx, dword ptr [rax]
004c74ce  488b1cda                 mov rbx, qword ptr [rdx + rbx*8]
004c74d2  488b1c19                 mov rbx, qword ptr [rcx + rbx]
004c74d6  498b4e10                 mov rcx, qword ptr [r14 + 0x10]
004c74da  488b01                   mov rax, qword ptr [rcx]
004c74dd  ff5010                   call qword ptr [rax + 0x10]
004c74e0  488bd0                   mov rdx, rax
004c74e3  44897c2430               mov dword ptr [rsp + 0x30], r15d
004c74e8  498b8638010000           mov rax, qword ptr [r14 + 0x138]
004c74ef  4889442428               mov qword ptr [rsp + 0x28], rax
004c74f4  410fb686f8000000         movzx eax, byte ptr [r14 + 0xf8]
004c74fc  88442420                 mov byte ptr [rsp + 0x20], al
004c7500  4d8d8ee8000000           lea r9, [r14 + 0xe8]
004c7507  4c8bc7                   mov r8, rdi
004c750a  488b8b90000000           mov rcx, qword ptr [rbx + 0x90]
004c7511  e8fa620200               call 0x4ed810
004c7516  e97e010000               jmp 0x4c7699
004c751b  498bce                   mov rcx, r14
004c751e  e8bd290000               call 0x4c9ee0
004c7523  e971010000               jmp 0x4c7699
004c7528  498bce                   mov rcx, r14
004c752b  e890040000               call 0x4c79c0
004c7530  e964010000               jmp 0x4c7699
004c7535  c644245000               mov byte ptr [rsp + 0x50], 0
004c753a  4533ff                   xor r15d, r15d
004c753d  c744245803a50000         mov dword ptr [rsp + 0x58], 0xa503
004c7545  0f57c0                   xorps xmm0, xmm0
004c7548  f30f7f442460             movdqu xmmword ptr [rsp + 0x60], xmm0
004c754e  44897c2470               mov dword ptr [rsp + 0x70], r15d
004c7553  c644245001               mov byte ptr [rsp + 0x50], 1
004c7558  488d4da0                 lea rcx, [rbp - 0x60]
004c755c  e84f590000               call 0x4cceb0
004c7561  44897d90                 mov dword ptr [rbp - 0x70], r15d
004c7565  4c897d88                 mov qword ptr [rbp - 0x78], r15
004c7569  4c897c2440               mov qword ptr [rsp + 0x40], r15
004c756e  4c897c2438               mov qword ptr [rsp + 0x38], r15
004c7573  488d45a0                 lea rax, [rbp - 0x60]
004c7577  4889442430               mov qword ptr [rsp + 0x30], rax
004c757c  c744242805000000         mov dword ptr [rsp + 0x28], 5
004c7584  44897c2420               mov dword ptr [rsp + 0x20], r15d
004c7589  4c8d4d88                 lea r9, [rbp - 0x78]
004c758d  4533c0                   xor r8d, r8d
004c7590  488d542450               lea rdx, [rsp + 0x50]
004c7595  498bce                   mov rcx, r14
004c7598  e8030b0000               call 0x4c80a0
004c759d  4983be0001000001         cmp qword ptr [r14 + 0x100], 1
004c75a5  7552                     jne 0x4c75f9
004c75a7  4538bef8000000           cmp byte ptr [r14 + 0xf8], r15b
004c75ae  7549                     jne 0x4c75f9
004c75b0  0fb685fd000000           movzx eax, byte ptr [rbp + 0xfd]
004c75b7  84c0                     test al, al
004c75b9  7560                     jne 0x4c761b
004c75bb  3885fe000000             cmp byte ptr [rbp + 0xfe], al
004c75c1  7518                     jne 0x4c75db
004c75c3  84c0                     test al, al
004c75c5  7554                     jne 0x4c761b
004c75c7  388500010000             cmp byte ptr [rbp + 0x100], al
004c75cd  750c                     jne 0x4c75db
004c75cf  84c0                     test al, al
004c75d1  7548                     jne 0x4c761b
004c75d3  388501010000             cmp byte ptr [rbp + 0x101], al
004c75d9  7425                     je 0x4c7600
004c75db  4983be1002000000         cmp qword ptr [r14 + 0x210], 0
004c75e3  751f                     jne 0x4c7604
004c75e5  498d8e80000000           lea rcx, [r14 + 0x80]
004c75ec  e88f9a0200               call 0x4f1080
004c75f1  498bce                   mov rcx, r14
004c75f4  e8d7f9ffff               call 0x4c6fd0
004c75f9  0fb685fd000000           movzx eax, byte ptr [rbp + 0xfd]
004c7600  84c0                     test al, al
004c7602  7517                     jne 0x4c761b
004c7604  80bd0001000000           cmp byte ptr [rbp + 0x100], 0
004c760b  740e                     je 0x4c761b
004c760d  ba09000000               mov edx, 9
004c7612  498bce                   mov rcx, r14
004c7615  e8e6000000               call 0x4c7700
004c761a  90                       nop
004c761b  807c245000               cmp byte ptr [rsp + 0x50], 0
004c7620  7477                     je 0x4c7699
004c7622  c644245000               mov byte ptr [rsp + 0x50], 0
004c7627  f644245a01               test byte ptr [rsp + 0x5a], 1
004c762c  7412                     je 0x4c7640
004c762e  488b1543d8ca01           mov rdx, qword ptr [rip + 0x1cad843]
004c7635  488d4c2458               lea rcx, [rsp + 0x58]
004c763a  ff15d845a001             call qword ptr [rip + 0x1a045d8]
004c7640  6644897c245a             mov word ptr [rsp + 0x5a], r15w
004c7646  c744245803000000         mov dword ptr [rsp + 0x58], 3
004c764e  0f57c0                   xorps xmm0, xmm0
004c7651  f30f7f442460             movdqu xmmword ptr [rsp + 0x60], xmm0
004c7657  44897c2470               mov dword ptr [rsp + 0x70], r15d
004c765c  66c744245803a5           mov word ptr [rsp + 0x58], 0xa503
004c7663  f30f7f442460             movdqu xmmword ptr [rsp + 0x60], xmm0
004c7669  44897c2470               mov dword ptr [rsp + 0x70], r15d
004c766e  eb29                     jmp 0x4c7699
004c7670  41f686c803000001         test byte ptr [r14 + 0x3c8], 1
004c7678  741f                     je 0x4c7699
004c767a  498b8630040000           mov rax, qword ptr [r14 + 0x430]
004c7681  c6806301000001           mov byte ptr [rax + 0x163], 1
004c7688  c6806601000001           mov byte ptr [rax + 0x166], 1
004c768f  eb08                     jmp 0x4c7699
004c7691  498bce                   mov rcx, r14
004c7694  e8671d0000               call 0x4c9400
004c7699  b102                     mov cl, 2
004c769b  e8505eb4ff               call 0xd4f0
004c76a0  488b8d10010000           mov rcx, qword ptr [rbp + 0x110]
004c76a7  4833cc                   xor rcx, rsp
004c76aa  e8c199b3ff               call 0x1070
004c76af  4c8d9c2420020000         lea r11, [rsp + 0x220]
004c76b7  498b5b28                 mov rbx, qword ptr [r11 + 0x28]
004c76bb  498b7330                 mov rsi, qword ptr [r11 + 0x30]
004c76bf  498b7b38                 mov rdi, qword ptr [r11 + 0x38]
004c76c3  498be3                   mov rsp, r11
004c76c6  415f                     pop r15
004c76c8  415e                     pop r14
004c76ca  5d                       pop rbp
004c76cb  c3                       ret
004c76cc  5a                       pop rdx
004c76cd  734c                     jae 0x4c771b
004c76cf  004d73                   add byte ptr [rbp + 0x73], cl
004c76d2  4c0009                   add byte ptr [rcx], r9b
004c76d5  744c                     je 0x4c7723
004c76d7  001b                     add byte ptr [rbx], bl
004c76d9  754c                     jne 0x4c7727
004c76db  0028                     add byte ptr [rax], ch
004c76dd  754c                     jne 0x4c772b
004c76df  0035754c0070             add byte ptr [rip + 0x70004c75], dh
004c76e5  764c                     jbe 0x4c7733
004c76e7  002d724c0040             add byte ptr [rip + 0x40004c72], ch
004c76ed  734c                     jae 0x4c773b
004c76ef  0091764c0016             add byte ptr [rcx + 0x16004c76], dl
004c76f5  744c                     je 0x4c7743
