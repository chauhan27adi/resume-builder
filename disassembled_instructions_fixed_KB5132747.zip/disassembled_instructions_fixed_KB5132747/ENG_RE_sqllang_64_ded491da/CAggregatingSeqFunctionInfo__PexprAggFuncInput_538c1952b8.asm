; CAggregatingSeqFunctionInfo::PexprAggFuncInput
; sqllang.dll, primary RVA 0x14ea070, 1272 bytes in 1 chunk(s)

; chunk at RVA 0x14ea070 (1272 bytes)
014ea070  4889542410               mov qword ptr [rsp + 0x10], rdx
014ea075  53                       push rbx
014ea076  55                       push rbp
014ea077  56                       push rsi
014ea078  57                       push rdi
014ea079  4154                     push r12
014ea07b  4156                     push r14
014ea07d  4157                     push r15
014ea07f  4883ec70                 sub rsp, 0x70
014ea083  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
014ea08c  4c8bfa                   mov r15, rdx
014ea08f  488bf1                   mov rsi, rcx
014ea092  498b4010                 mov rax, qword ptr [r8 + 0x10]
014ea096  4c8b7048                 mov r14, qword ptr [rax + 0x48]
014ea09a  488b6840                 mov rbp, qword ptr [rax + 0x40]
014ea09e  4d85f6                   test r14, r14
014ea0a1  7404                     je 0x14ea0a7
014ea0a3  41ff4608                 inc dword ptr [r14 + 8]
014ea0a7  4885ed                   test rbp, rbp
014ea0aa  7403                     je 0x14ea0af
014ea0ac  ff4508                   inc dword ptr [rbp + 8]
014ea0af  c78424c0000000f2050000   mov dword ptr [rsp + 0xc0], 0x5f2
014ea0ba  c644242001               mov byte ptr [rsp + 0x20], 1
014ea0bf  41b9f2050000             mov r9d, 0x5f2
014ea0c5  4c8d058c90c300           lea r8, [rip + 0xc3908c]
014ea0cc  b9a8000000               mov ecx, 0xa8
014ea0d1  ff15d90d9e00             call qword ptr [rip + 0x9e0dd9]
014ea0d7  488bd8                   mov rbx, rax
014ea0da  4889442438               mov qword ptr [rsp + 0x38], rax
014ea0df  4885c0                   test rax, rax
014ea0e2  0f847f030000             je 0x14ea467
014ea0e8  c78424c8000000f3050000   mov dword ptr [rsp + 0xc8], 0x5f3
014ea0f3  c644242001               mov byte ptr [rsp + 0x20], 1
014ea0f8  41b9f3050000             mov r9d, 0x5f3
014ea0fe  4c8d055390c300           lea r8, [rip + 0xc39053]
014ea105  498bd7                   mov rdx, r15
014ea108  b968000000               mov ecx, 0x68
014ea10d  ff159d0d9e00             call qword ptr [rip + 0x9e0d9d]
014ea113  488bf8                   mov rdi, rax
014ea116  4889442440               mov qword ptr [rsp + 0x40], rax
014ea11b  4c8d2586e2b600           lea r12, [rip + 0xb6e286]
014ea122  4885c0                   test rax, rax
014ea125  0f84c0020000             je 0x14ea3eb
014ea12b  b27f                     mov dl, 0x7f
014ea12d  488d4c2448               lea rcx, [rsp + 0x48]
014ea132  e849cbb1fe               call 0x6c80
014ea137  4c8b0e                   mov r9, qword ptr [rsi]
014ea13a  488bce                   mov rcx, rsi
014ea13d  41ff5168                 call qword ptr [r9 + 0x68]
014ea141  4533db                   xor r11d, r11d
014ea144  83f83a                   cmp eax, 0x3a
014ea147  0f872b020000             ja 0x14ea378
014ea14d  4898                     cdqe
014ea14f  488d15aa5eb1fe           lea rdx, [rip - 0x14ea156]
014ea156  8b8c827ca44e01           mov ecx, dword ptr [rdx + rax*4 + 0x14ea47c]
014ea15d  4803ca                   add rcx, rdx
014ea160  ffe1                     jmp rcx
014ea162  4c8d15bff06d01           lea r10, [rip + 0x16df0bf]
014ea169  e90d020000               jmp 0x14ea37b
014ea16e  4c8d151bf56d01           lea r10, [rip + 0x16df51b]
014ea175  e901020000               jmp 0x14ea37b
014ea17a  4c8d1587ed6e01           lea r10, [rip + 0x16eed87]
014ea181  e9f5010000               jmp 0x14ea37b
014ea186  4c8d153bff6d01           lea r10, [rip + 0x16dff3b]
014ea18d  e9e9010000               jmp 0x14ea37b
014ea192  4c8d15c7f16e01           lea r10, [rip + 0x16ef1c7]
014ea199  e9dd010000               jmp 0x14ea37b
014ea19e  4c8d15b3f96d01           lea r10, [rip + 0x16df9b3]
014ea1a5  e9d1010000               jmp 0x14ea37b
014ea1aa  4c8d15bff76e01           lea r10, [rip + 0x16ef7bf]
014ea1b1  e9c5010000               jmp 0x14ea37b
014ea1b6  4c8d15cbfd6e01           lea r10, [rip + 0x16efdcb]
014ea1bd  e9b9010000               jmp 0x14ea37b
014ea1c2  4c8d154f0f6e01           lea r10, [rip + 0x16e0f4f]
014ea1c9  e9ad010000               jmp 0x14ea37b
014ea1ce  4c8d15f38b6501           lea r10, [rip + 0x1658bf3]
014ea1d5  e9a1010000               jmp 0x14ea37b
014ea1da  4c8d151f8b6501           lea r10, [rip + 0x1658b1f]
014ea1e1  e995010000               jmp 0x14ea37b
014ea1e6  4c8d159b0c6401           lea r10, [rip + 0x1640c9b]
014ea1ed  e989010000               jmp 0x14ea37b
014ea1f2  4c8d15479e6501           lea r10, [rip + 0x1659e47]
014ea1f9  e97d010000               jmp 0x14ea37b
014ea1fe  4c8d15e3346e01           lea r10, [rip + 0x16e34e3]
014ea205  e971010000               jmp 0x14ea37b
014ea20a  4c8d1597386e01           lea r10, [rip + 0x16e3897]
014ea211  e965010000               jmp 0x14ea37b
014ea216  4c8d156b2f6e01           lea r10, [rip + 0x16e2f6b]
014ea21d  e959010000               jmp 0x14ea37b
014ea222  4c8d156f2b6e01           lea r10, [rip + 0x16e2b6f]
014ea229  e94d010000               jmp 0x14ea37b
014ea22e  4c8d1593e66e01           lea r10, [rip + 0x16ee693]
014ea235  e941010000               jmp 0x14ea37b
014ea23a  4c8d15ef8a6501           lea r10, [rip + 0x1658aef]
014ea241  e935010000               jmp 0x14ea37b
014ea246  4c8d15fb8a6501           lea r10, [rip + 0x1658afb]
014ea24d  e929010000               jmp 0x14ea37b
014ea252  4c8d154fc46501           lea r10, [rip + 0x165c44f]
014ea259  e91d010000               jmp 0x14ea37b
014ea25e  4c8d15f3066601           lea r10, [rip + 0x16606f3]
014ea265  e911010000               jmp 0x14ea37b
014ea26a  4c8d15b7066601           lea r10, [rip + 0x16606b7]
014ea271  e905010000               jmp 0x14ea37b
014ea276  4c8d1523bc6e01           lea r10, [rip + 0x16ebc23]
014ea27d  e9f9000000               jmp 0x14ea37b
014ea282  4c8d15c7c46e01           lea r10, [rip + 0x16ec4c7]
014ea289  e9ed000000               jmp 0x14ea37b
014ea28e  4c8d150bd16e01           lea r10, [rip + 0x16ed10b]
014ea295  e9e1000000               jmp 0x14ea37b
014ea29a  4c8d15dfdb6e01           lea r10, [rip + 0x16edbdf]
014ea2a1  e9d5000000               jmp 0x14ea37b
014ea2a6  4c8d1573546e01           lea r10, [rip + 0x16e5473]
014ea2ad  e9c9000000               jmp 0x14ea37b
014ea2b2  4c8d156f146601           lea r10, [rip + 0x166146f]
014ea2b9  e9bd000000               jmp 0x14ea37b
014ea2be  4c8d157b146601           lea r10, [rip + 0x166147b]
014ea2c5  e9b1000000               jmp 0x14ea37b
014ea2ca  4c8d15b74a6e01           lea r10, [rip + 0x16e4ab7]
014ea2d1  e9a5000000               jmp 0x14ea37b
014ea2d6  4c8d1583506e01           lea r10, [rip + 0x16e5083]
014ea2dd  e999000000               jmp 0x14ea37b
014ea2e2  4c8d15f7df6e01           lea r10, [rip + 0x16edff7]
014ea2e9  e98d000000               jmp 0x14ea37b
014ea2ee  4c8d157b896501           lea r10, [rip + 0x165897b]
014ea2f5  e981000000               jmp 0x14ea37b
014ea2fa  4c8d1587896e01           lea r10, [rip + 0x16e8987]
014ea301  eb78                     jmp 0x14ea37b
014ea303  4c8d1546696e01           lea r10, [rip + 0x16e6946]
014ea30a  eb6f                     jmp 0x14ea37b
014ea30c  4c8d15b5696e01           lea r10, [rip + 0x16e69b5]
014ea313  eb66                     jmp 0x14ea37b
014ea315  4c8d1594716e01           lea r10, [rip + 0x16e7194]
014ea31c  eb5d                     jmp 0x14ea37b
014ea31e  4c8d15b37b6e01           lea r10, [rip + 0x16e7bb3]
014ea325  eb54                     jmp 0x14ea37b
014ea327  4c8d1512856e01           lea r10, [rip + 0x16e8512]
014ea32e  eb4b                     jmp 0x14ea37b
014ea330  4c8d15a1866e01           lea r10, [rip + 0x16e86a1]
014ea337  eb42                     jmp 0x14ea37b
014ea339  4c8d15d0876e01           lea r10, [rip + 0x16e87d0]
014ea340  eb39                     jmp 0x14ea37b
014ea342  4c8d159f006f01           lea r10, [rip + 0x16f009f]
014ea349  eb30                     jmp 0x14ea37b
014ea34b  4c8d15ce8d6e01           lea r10, [rip + 0x16e8dce]
014ea352  eb27                     jmp 0x14ea37b
014ea354  4c8d15dd926e01           lea r10, [rip + 0x16e92dd]
014ea35b  eb1e                     jmp 0x14ea37b
014ea35d  4c8d158c996e01           lea r10, [rip + 0x16e998c]
014ea364  eb15                     jmp 0x14ea37b
014ea366  4c8d15a3026f01           lea r10, [rip + 0x16f02a3]
014ea36d  eb0c                     jmp 0x14ea37b
014ea36f  4c8d152a0b6f01           lea r10, [rip + 0x16f0b2a]
014ea376  eb03                     jmp 0x14ea37b
014ea378  4d8bd3                   mov r10, r11
014ea37b  4c8927                   mov qword ptr [rdi], r12
014ea37e  c7470801000000           mov dword ptr [rdi + 8], 1
014ea385  488d05d418ae00           lea rax, [rip + 0xae18d4]
014ea38c  488907                   mov qword ptr [rdi], rax
014ea38f  4c897f10                 mov qword ptr [rdi + 0x10], r15
014ea393  488d05be82ad00           lea rax, [rip + 0xad82be]
014ea39a  488907                   mov qword ptr [rdi], rax
014ea39d  0f10442448               movups xmm0, xmmword ptr [rsp + 0x48]
014ea3a2  0f114718                 movups xmmword ptr [rdi + 0x18], xmm0
014ea3a6  0f104c2458               movups xmm1, xmmword ptr [rsp + 0x58]
014ea3ab  0f114f28                 movups xmmword ptr [rdi + 0x28], xmm1
014ea3af  80673efc                 and byte ptr [rdi + 0x3e], 0xfc
014ea3b3  66c7473c0500             mov word ptr [rdi + 0x3c], 5
014ea3b9  e8b28cb7fe               call 0x63070
014ea3be  894738                   mov dword ptr [rdi + 0x38], eax
014ea3c1  488d05c06aad00           lea rax, [rip + 0xad6ac0]
014ea3c8  488907                   mov qword ptr [rdi], rax
014ea3cb  48896f40                 mov qword ptr [rdi + 0x40], rbp
014ea3cf  4c897748                 mov qword ptr [rdi + 0x48], r14
014ea3d3  488d056e40ad00           lea rax, [rip + 0xad406e]
014ea3da  488907                   mov qword ptr [rdi], rax
014ea3dd  4c895f58                 mov qword ptr [rdi + 0x58], r11
014ea3e1  4c895760                 mov qword ptr [rdi + 0x60], r10
014ea3e5  80675080                 and byte ptr [rdi + 0x50], 0x80
014ea3e9  eb06                     jmp 0x14ea3f1
014ea3eb  4533db                   xor r11d, r11d
014ea3ee  418bfb                   mov edi, r11d
014ea3f1  4c8923                   mov qword ptr [rbx], r12
014ea3f4  c7430801000000           mov dword ptr [rbx + 8], 1
014ea3fb  488d05667eb800           lea rax, [rip + 0xb87e66]
014ea402  488903                   mov qword ptr [rbx], rax
014ea405  4c895b60                 mov qword ptr [rbx + 0x60], r11
014ea409  4c895b68                 mov qword ptr [rbx + 0x68], r11
014ea40d  4c895b70                 mov qword ptr [rbx + 0x70], r11
014ea411  4c895b78                 mov qword ptr [rbx + 0x78], r11
014ea415  f20f1005f3a66301         movsd xmm0, qword ptr [rip + 0x163a6f3]
014ea41d  f20f118388000000         movsd qword ptr [rbx + 0x88], xmm0
014ea425  4c899b90000000           mov qword ptr [rbx + 0x90], r11
014ea42c  4c899b98000000           mov qword ptr [rbx + 0x98], r11
014ea433  4c899ba0000000           mov qword ptr [rbx + 0xa0], r11
014ea43a  4c895b20                 mov qword ptr [rbx + 0x20], r11
014ea43e  44895b18                 mov dword ptr [rbx + 0x18], r11d
014ea442  48897b10                 mov qword ptr [rbx + 0x10], rdi
014ea446  4c895b50                 mov qword ptr [rbx + 0x50], r11
014ea44a  4c895b58                 mov qword ptr [rbx + 0x58], r11
014ea44e  4c899b80000000           mov qword ptr [rbx + 0x80], r11
014ea455  488bc3                   mov rax, rbx
014ea458  4883c470                 add rsp, 0x70
014ea45c  415f                     pop r15
014ea45e  415e                     pop r14
014ea460  415c                     pop r12
014ea462  5f                       pop rdi
014ea463  5e                       pop rsi
014ea464  5d                       pop rbp
014ea465  5b                       pop rbx
014ea466  c3                       ret
014ea467  4533db                   xor r11d, r11d
014ea46a  418bc3                   mov eax, r11d
014ea46d  4883c470                 add rsp, 0x70
014ea471  415f                     pop r15
014ea473  415e                     pop r14
014ea475  415c                     pop r12
014ea477  5f                       pop rdi
014ea478  5e                       pop rsi
014ea479  5d                       pop rbp
014ea47a  5b                       pop rbx
014ea47b  c3                       ret
014ea47c  5e                       pop rsi
014ea47d  a24e0178a34e016aa2       movabs byte ptr [0xa26a014ea378014e], al
014ea486  4e0178a3                 add qword ptr [rax - 0x5d], r15
014ea48a  4e01ce                   add rsi, r9
014ea48d  a14e0178a34e0146a2       movabs eax, dword ptr [0xa246014ea378014e]
014ea496  4e0178a3                 add qword ptr [rax - 0x5d], r15
014ea49a  4e013a                   add qword ptr [rdx], r15
014ea49d  a24e0178a34e0152a2       movabs byte ptr [0xa252014ea378014e], al
014ea4a6  4e0178a3                 add qword ptr [rax - 0x5d], r15
014ea4aa  4e01f2                   add rdx, r14
014ea4ad  a14e0122a24e0116a2       movabs eax, dword ptr [0xa216014ea222014e]
014ea4b6  4e012e                   add qword ptr [rsi], r13
014ea4b9  a24e01fea14e010aa2       movabs byte ptr [0xa20a014ea1fe014e], al
014ea4c2  4e010ca3                 add qword ptr [rbx + r12*4], r9
014ea4c6  4e0115a34e011e           add qword ptr [rip + 0x1e014ea3], r10
014ea4cd  a34e0127a34e0130a3       movabs dword ptr [0xa330014ea327014e], eax
014ea4d6  4e0139                   add qword ptr [rcx], r15
014ea4d9  a34e0176a24e018ea2       movabs dword ptr [0xa28e014ea276014e], eax
014ea4e2  4e0182a24e019a           add qword ptr [rdx - 0x65feb15e], r8
014ea4e9  a24e01e6a14e01a6a2       movabs byte ptr [0xa2a6014ea1e6014e], al
014ea4f2  4e01b2a24e01be           add qword ptr [rdx - 0x41feb15e], r14
014ea4f9  a24e01caa24e0178a3       movabs byte ptr [0xa378014ea2ca014e], al
014ea502  4e01d6                   add rsi, r10
014ea505  a24e01daa14e0178a3       movabs byte ptr [0xa378014ea1da014e], al
014ea50e  4e01e2                   add rdx, r12
014ea511  a24e01eea24e0178a3       movabs byte ptr [0xa378014ea2ee014e], al
014ea51a  4e0178a3                 add qword ptr [rax - 0x5d], r15
014ea51e  4e0178a3                 add qword ptr [rax - 0x5d], r15
014ea522  4e01fa                   add rdx, r15
014ea525  a24e0186a14e01c2a1       movabs byte ptr [0xa1c2014ea186014e], al
014ea52e  4e017aa1                 add qword ptr [rdx - 0x5f], r15
014ea532  4e0192a14e0162           add qword ptr [rdx + 0x62014ea1], r10
014ea539  a14e016ea14e0103a3       movabs eax, dword ptr [0xa303014ea16e014e]
014ea542  4e019ea14e01aa           add qword ptr [rsi - 0x55feb15f], r11
014ea549  a14e01b6a14e0142a3       movabs eax, dword ptr [0xa342014ea1b6014e]
014ea552  4e014ba3                 add qword ptr [rbx - 0x5d], r9
014ea556  4e0154a34e               add qword ptr [rbx + r12*4 + 0x4e], r10
014ea55b  015da3                   add dword ptr [rbp - 0x5d], ebx
014ea55e  4e0166a3                 add qword ptr [rsi - 0x5d], r12
014ea562  4e016fa3                 add qword ptr [rdi - 0x5d], r13
