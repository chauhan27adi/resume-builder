; CConstraintTag::PwszCnstType
; sqllang.dll, primary RVA 0x17741a0, 572 bytes in 1 chunk(s)

; chunk at RVA 0x17741a0 (572 bytes)
017741a0  4883ec28                 sub rsp, 0x28
017741a4  8b4110                   mov eax, dword ptr [rcx + 0x10]
017741a7  25ff010000               and eax, 0x1ff
017741ac  83f822                   cmp eax, 0x22
017741af  0f878f010000             ja 0x1774344
017741b5  4c8d0544be88fe           lea r8, [rip - 0x17741bc]
017741bc  4898                     cdqe
017741be  418b8c8050437701         mov ecx, dword ptr [r8 + rax*4 + 0x1774350]
017741c6  4903c8                   add rcx, r8
017741c9  ffe1                     jmp rcx
017741cb  488d052669c300           lea rax, [rip + 0xc36926]
017741d2  4883c428                 add rsp, 0x28
017741d6  c3                       ret
017741d7  488d05f21ad400           lea rax, [rip + 0xd41af2]
017741de  4883c428                 add rsp, 0x28
017741e2  c3                       ret
017741e3  488b02                   mov rax, qword ptr [rdx]
017741e6  488bca                   mov rcx, rdx
017741e9  ff90a0000000             call qword ptr [rax + 0xa0]
017741ef  4885c0                   test rax, rax
017741f2  488d15b71ad400           lea rdx, [rip + 0xd41ab7]
017741f9  488d0d20a6b400           lea rcx, [rip + 0xb4a620]
01774200  480f45ca                 cmovne rcx, rdx
01774204  488bc1                   mov rax, rcx
01774207  4883c428                 add rsp, 0x28
0177420b  c3                       ret
0177420c  488d056d39c600           lea rax, [rip + 0xc6396d]
01774213  4883c428                 add rsp, 0x28
01774217  c3                       ret
01774218  488d058155a400           lea rax, [rip + 0xa45581]
0177421f  4883c428                 add rsp, 0x28
01774223  c3                       ret
01774224  488d05c5a5b400           lea rax, [rip + 0xb4a5c5]
0177422b  4883c428                 add rsp, 0x28
0177422f  c3                       ret
01774230  488d0589a5b400           lea rax, [rip + 0xb4a589]
01774237  4883c428                 add rsp, 0x28
0177423b  c3                       ret
0177423c  488d05956dc300           lea rax, [rip + 0xc36d95]
01774243  4883c428                 add rsp, 0x28
01774247  c3                       ret
01774248  488d0551a5b400           lea rax, [rip + 0xb4a551]
0177424f  4883c428                 add rsp, 0x28
01774253  c3                       ret
01774254  488d05350d9b00           lea rax, [rip + 0x9b0d35]
0177425b  4883c428                 add rsp, 0x28
0177425f  c3                       ret
01774260  488d0509a5b400           lea rax, [rip + 0xb4a509]
01774267  4883c428                 add rsp, 0x28
0177426b  c3                       ret
0177426c  488d05b51ad400           lea rax, [rip + 0xd41ab5]
01774273  4883c428                 add rsp, 0x28
01774277  c3                       ret
01774278  488d05891ad400           lea rax, [rip + 0xd41a89]
0177427f  4883c428                 add rsp, 0x28
01774283  c3                       ret
01774284  488d055d1ad400           lea rax, [rip + 0xd41a5d]
0177428b  4883c428                 add rsp, 0x28
0177428f  c3                       ret
01774290  488d057919d400           lea rax, [rip + 0xd41979]
01774297  4883c428                 add rsp, 0x28
0177429b  c3                       ret
0177429c  488d052d19d400           lea rax, [rip + 0xd4192d]
017742a3  4883c428                 add rsp, 0x28
017742a7  c3                       ret
017742a8  488d05f918d400           lea rax, [rip + 0xd418f9]
017742af  4883c428                 add rsp, 0x28
017742b3  c3                       ret
017742b4  488d05b518d400           lea rax, [rip + 0xd418b5]
017742bb  4883c428                 add rsp, 0x28
017742bf  c3                       ret
017742c0  654c8b042558000000       mov r8, qword ptr gs:[0x58]
017742c9  488b05a86c7500           mov rax, qword ptr [rip + 0x756ca8]
017742d0  8b10                     mov edx, dword ptr [rax]
017742d2  488b05a76c7500           mov rax, qword ptr [rip + 0x756ca7]
017742d9  8b08                     mov ecx, dword ptr [rax]
017742db  498b04d0                 mov rax, qword ptr [r8 + rdx*8]
017742df  488b0c01                 mov rcx, qword ptr [rcx + rax]
017742e3  488b4148                 mov rax, qword ptr [rcx + 0x48]
017742e7  83b8e403000002           cmp dword ptr [rax + 0x3e4], 2
017742ee  750c                     jne 0x17742fc
017742f0  488d056118d400           lea rax, [rip + 0xd41861]
017742f7  4883c428                 add rsp, 0x28
017742fb  c3                       ret
017742fc  488d053d18d400           lea rax, [rip + 0xd4183d]
01774303  4883c428                 add rsp, 0x28
01774307  c3                       ret
01774308  488d051918d400           lea rax, [rip + 0xd41819]
0177430f  4883c428                 add rsp, 0x28
01774313  c3                       ret
01774314  488d05ed17d400           lea rax, [rip + 0xd417ed]
0177431b  4883c428                 add rsp, 0x28
0177431f  c3                       ret
01774320  488d055119d400           lea rax, [rip + 0xd41951]
01774327  4883c428                 add rsp, 0x28
0177432b  c3                       ret
0177432c  488d051d69c300           lea rax, [rip + 0xc3691d]
01774333  4883c428                 add rsp, 0x28
01774337  c3                       ret
01774338  488d050119d400           lea rax, [rip + 0xd41901]
0177433f  4883c428                 add rsp, 0x28
01774343  c3                       ret
01774344  488d054527ba00           lea rax, [rip + 0xba2745]
0177434b  4883c428                 add rsp, 0x28
0177434f  c3                       ret
01774350  cb                       retf
01774351  417701                   ja 0x1774355
01774354  d7                       xlatb
01774355  417701                   ja 0x1774359
01774358  e341                     jrcxz 0x177439b
0177435a  7701                     ja 0x177435d
0177435c  0c42                     or al, 0x42
0177435e  7701                     ja 0x1774361
01774360  184277                   sbb byte ptr [rdx + 0x77], al
01774363  0118                     add dword ptr [rax], ebx
01774365  427701                   ja 0x1774369
01774368  184277                   sbb byte ptr [rdx + 0x77], al
0177436b  012442                   add dword ptr [rdx + rax*2], esp
0177436e  7701                     ja 0x1774371
01774370  304277                   xor byte ptr [rdx + 0x77], al
01774373  013c42                   add dword ptr [rdx + rax*2], edi
01774376  7701                     ja 0x1774379
01774378  54                       push rsp
01774379  427701                   ja 0x177437d
