; AuditTVF::OutputColumn
; sqllang.dll, primary RVA 0x1138e90, 2308 bytes in 3 chunk(s)

; chunk at RVA 0x1138e90 (145 bytes)
01138e90  4055                     push rbp
01138e92  56                       push rsi
01138e93  57                       push rdi
01138e94  4154                     push r12
01138e96  4155                     push r13
01138e98  4156                     push r14
01138e9a  4157                     push r15
01138e9c  4881ec80000000           sub rsp, 0x80
01138ea3  488b05defd9901           mov rax, qword ptr [rip + 0x199fdde]
01138eaa  4833c4                   xor rax, rsp
01138ead  4889442478               mov qword ptr [rsp + 0x78], rax
01138eb2  4c8bf1                   mov r14, rcx
01138eb5  450fb7e1                 movzx r12d, r9w
01138eb9  488b8950060000           mov rcx, qword ptr [rcx + 0x650]
01138ec0  418bd4                   mov edx, r12d
01138ec3  498bf8                   mov rdi, r8
01138ec6  be05400080               mov esi, 0x80004005
01138ecb  488b01                   mov rax, qword ptr [rcx]
01138ece  ff5018                   call qword ptr [rax + 0x18]
01138ed1  bdffff0000               mov ebp, 0xffff
01138ed6  4c8d2d2371ecfe           lea r13, [rip - 0x1138edd]
01138edd  0fb75010                 movzx edx, word ptr [rax + 0x10]
01138ee1  663bd5                   cmp dx, bp
01138ee4  7417                     je 0x1138efd
01138ee6  0fb600                   movzx eax, byte ptr [rax]
01138ee9  420fb68c28403b0202       movzx ecx, byte ptr [rax + r13 + 0x2023b40]
01138ef2  4280bc29e812b00200       cmp byte ptr [rcx + r13 + 0x2b012e8], 0
01138efb  7402                     je 0x1138eff
01138efd  8bd5                     mov edx, ebp
01138eff  0fb7ca                   movzx ecx, dx
01138f02  394f28                   cmp dword ptr [rdi + 0x28], ecx
01138f05  0f8779070000             ja 0x1139684
01138f0b  498b8e50060000           mov rcx, qword ptr [r14 + 0x650]
01138f12  488b01                   mov rax, qword ptr [rcx]
01138f15  ff5010                   call qword ptr [rax + 0x10]
01138f18  443be0                   cmp r12d, eax
01138f1b  0f8d63070000             jge 0x1139684

; chunk at RVA 0x1138f21 (1891 bytes)
01138f21  48899c24c8000000         mov qword ptr [rsp + 0xc8], rbx
01138f29  0faee8                   lfence
01138f2c  498b8e50060000           mov rcx, qword ptr [r14 + 0x650]
01138f33  33db                     xor ebx, ebx
01138f35  418bd4                   mov edx, r12d
01138f38  8bf3                     mov esi, ebx
01138f3a  488b01                   mov rax, qword ptr [rcx]
01138f3d  ff5018                   call qword ptr [rax + 0x18]
01138f40  0fb608                   movzx ecx, byte ptr [rax]
01138f43  83c1dc                   add ecx, -0x24
01138f46  81f9c3000000             cmp ecx, 0xc3
01138f4c  0f87ef060000             ja 0x1139641
01138f52  4863c1                   movsxd rax, ecx
01138f55  420fb68428d0961301       movzx eax, byte ptr [rax + r13 + 0x11396d0]
01138f5e  418b8c85a8961301         mov ecx, dword ptr [r13 + rax*4 + 0x11396a8]
01138f66  4903cd                   add rcx, r13
01138f69  ffe1                     jmp rcx
01138f6b  488b4708                 mov rax, qword ptr [rdi + 8]
01138f6f  8b4004                   mov eax, dword ptr [rax + 4]
01138f72  8bc8                     mov ecx, eax
01138f74  81e100fcff0f             and ecx, 0xffffc00
01138f7a  81f900080000             cmp ecx, 0x800
01138f80  0f85f1060000             jne 0x1139677
01138f86  a9ff030000               test eax, 0x3ff
01138f8b  0f85e6060000             jne 0x1139677
01138f91  25000000f0               and eax, 0xf0000000
01138f96  3d00000060               cmp eax, 0x60000000
01138f9b  0f85d6060000             jne 0x1139677
01138fa1  0faee8                   lfence
01138fa4  4963c4                   movsxd rax, r12d
01138fa7  488bcf                   mov rcx, rdi
01138faa  498d1cc6                 lea rbx, [r14 + rax*8]
01138fae  e89dd4ecfe               call 0x6450
01138fb3  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
01138fb7  66894108                 mov word ptr [rcx + 8], ax
01138fbb  488b4370                 mov rax, qword ptr [rbx + 0x70]
01138fbf  408830                   mov byte ptr [rax], sil
01138fc2  e9b5060000               jmp 0x113967c
01138fc7  488b4708                 mov rax, qword ptr [rdi + 8]
01138fcb  bd000c0000               mov ebp, 0xc00
01138fd0  8b4004                   mov eax, dword ptr [rax + 4]
01138fd3  8bc8                     mov ecx, eax
01138fd5  81e100fcff0f             and ecx, 0xffffc00
01138fdb  3bcd                     cmp ecx, ebp
01138fdd  0f8594060000             jne 0x1139677
01138fe3  a9ff030000               test eax, 0x3ff
01138fe8  0f8589060000             jne 0x1139677
01138fee  25000000f0               and eax, 0xf0000000
01138ff3  3d00000060               cmp eax, 0x60000000
01138ff8  0f8579060000             jne 0x1139677
01138ffe  0faee8                   lfence
01139001  4963c4                   movsxd rax, r12d
01139004  488bcf                   mov rcx, rdi
01139007  498d1cc6                 lea rbx, [r14 + rax*8]
0113900b  e840d4ecfe               call 0x6450
01139010  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
01139014  894108                   mov dword ptr [rcx + 8], eax
01139017  488b4370                 mov rax, qword ptr [rbx + 0x70]
0113901b  408830                   mov byte ptr [rax], sil
0113901e  e959060000               jmp 0x113967c
01139023  488b4708                 mov rax, qword ptr [rdi + 8]
01139027  8b4004                   mov eax, dword ptr [rax + 4]
0113902a  8bd0                     mov edx, eax
0113902c  81e200fcff0f             and edx, 0xffffc00
01139032  81fa00100000             cmp edx, 0x1000
01139038  7517                     jne 0x1139051
0113903a  a9ff030000               test eax, 0x3ff
0113903f  7510                     jne 0x1139051
01139041  8bc8                     mov ecx, eax
01139043  81e1000000f0             and ecx, 0xf0000000
01139049  81f900000060             cmp ecx, 0x60000000
0113904f  7427                     je 0x1139078
01139051  81fa00200000             cmp edx, 0x2000
01139057  0f851a060000             jne 0x1139677
0113905d  a9ff030000               test eax, 0x3ff
01139062  0f850f060000             jne 0x1139677
01139068  25000000f0               and eax, 0xf0000000
0113906d  3d00000060               cmp eax, 0x60000000
01139072  0f85ff050000             jne 0x1139677
01139078  0faee8                   lfence
0113907b  4963c4                   movsxd rax, r12d
0113907e  488bcf                   mov rcx, rdi
01139081  498d1cc6                 lea rbx, [r14 + rax*8]
01139085  e8c6d3ecfe               call 0x6450
0113908a  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
0113908e  48894108                 mov qword ptr [rcx + 8], rax
01139092  488b4370                 mov rax, qword ptr [rbx + 0x70]
01139096  408830                   mov byte ptr [rax], sil
01139099  e9de050000               jmp 0x113967c
0113909e  488b4708                 mov rax, qword ptr [rdi + 8]
011390a2  8b4004                   mov eax, dword ptr [rax + 4]
011390a5  8bc8                     mov ecx, eax
011390a7  81e100fcff0f             and ecx, 0xffffc00
011390ad  81f900680000             cmp ecx, 0x6800
011390b3  0f85be050000             jne 0x1139677
011390b9  a9ff030000               test eax, 0x3ff
011390be  0f85b3050000             jne 0x1139677
011390c4  25000000f0               and eax, 0xf0000000
011390c9  3d00000060               cmp eax, 0x60000000
011390ce  0f85a3050000             jne 0x1139677
011390d4  0faee8                   lfence
011390d7  4963c4                   movsxd rax, r12d
011390da  488bcf                   mov rcx, rdi
011390dd  498d1cc6                 lea rbx, [r14 + rax*8]
011390e1  e86ad3ecfe               call 0x6450
011390e6  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
011390ea  884108                   mov byte ptr [rcx + 8], al
011390ed  488b4370                 mov rax, qword ptr [rbx + 0x70]
011390f1  408830                   mov byte ptr [rax], sil
011390f4  e983050000               jmp 0x113967c
011390f9  488b4708                 mov rax, qword ptr [rdi + 8]
011390fd  8b4004                   mov eax, dword ptr [rax + 4]
01139100  8bc8                     mov ecx, eax
01139102  81e100fcff0f             and ecx, 0xffffc00
01139108  81f900300000             cmp ecx, 0x3000
0113910e  0f8563050000             jne 0x1139677
01139114  a9ff030000               test eax, 0x3ff
01139119  0f8558050000             jne 0x1139677
0113911f  25000000f0               and eax, 0xf0000000
01139124  3d00000060               cmp eax, 0x60000000
01139129  0f8548050000             jne 0x1139677
0113912f  488bcf                   mov rcx, rdi
01139132  e819d3ecfe               call 0x6450
01139137  4c8d442438               lea r8, [rsp + 0x38]
0113913c  4889442440               mov qword ptr [rsp + 0x40], rax
01139141  488d542430               lea rdx, [rsp + 0x30]
01139146  895c2430                 mov dword ptr [rsp + 0x30], ebx
0113914a  488d4c2440               lea rcx, [rsp + 0x40]
0113914f  48895c2438               mov qword ptr [rsp + 0x38], rbx
01139154  ff15d628d900             call qword ptr [rip + 0xd928d6]
0113915a  817c2430dab93700         cmp dword ptr [rsp + 0x30], 0x37b9da
01139162  0f870f050000             ja 0x1139677
01139168  48b8ffbf692ac9000000     movabs rax, 0xc92a69bfff
01139172  4839442438               cmp qword ptr [rsp + 0x38], rax
01139177  0f87fa040000             ja 0x1139677
0113917d  0faee8                   lfence
01139180  498b8e50060000           mov rcx, qword ptr [r14 + 0x650]
01139187  488d05c2aa2001           lea rax, [rip + 0x120aac2]
0113918e  4889442448               mov qword ptr [rsp + 0x48], rax
01139193  418bd4                   mov edx, r12d
01139196  8b442430                 mov eax, dword ptr [rsp + 0x30]
0113919a  89442450                 mov dword ptr [rsp + 0x50], eax
0113919e  488b442438               mov rax, qword ptr [rsp + 0x38]
011391a3  4889442458               mov qword ptr [rsp + 0x58], rax
011391a8  4963c4                   movsxd rax, r12d
011391ab  c744246007000000         mov dword ptr [rsp + 0x60], 7
011391b3  498d1cc6                 lea rbx, [r14 + rax*8]
011391b7  488b01                   mov rax, qword ptr [rcx]
011391ba  ff5018                   call qword ptr [rax + 0x18]
011391bd  488b5370                 mov rdx, qword ptr [rbx + 0x70]
011391c1  488d4c2448               lea rcx, [rsp + 0x48]
011391c6  4c8bc0                   mov r8, rax
011391c9  ff1581aa2001             call qword ptr [rip + 0x120aa81]
011391cf  488b4370                 mov rax, qword ptr [rbx + 0x70]
011391d3  408830                   mov byte ptr [rax], sil
011391d6  e9a1040000               jmp 0x113967c
011391db  395f28                   cmp dword ptr [rdi + 0x28], ebx
011391de  0faee8                   lfence
011391e1  0f86a4010000             jbe 0x113938b
011391e7  498b8e50060000           mov rcx, qword ptr [r14 + 0x650]
011391ee  418bd4                   mov edx, r12d
011391f1  488b01                   mov rax, qword ptr [rcx]
011391f4  ff5018                   call qword ptr [rax + 0x18]
011391f7  66396810                 cmp word ptr [rax + 0x10], bp
011391fb  741d                     je 0x113921a
011391fd  0faee8                   lfence
01139200  0fb608                   movzx ecx, byte ptr [rax]
01139203  420fb69429403b0202       movzx edx, byte ptr [rcx + r13 + 0x2023b40]
0113920c  42389c2ae812b002         cmp byte ptr [rdx + r13 + 0x2b012e8], bl
01139214  7504                     jne 0x113921a
01139216  0fb76810                 movzx ebp, word ptr [rax + 0x10]
0113921a  0fb7c5                   movzx eax, bp
0113921d  394728                   cmp dword ptr [rdi + 0x28], eax
01139220  0f8751040000             ja 0x1139677
01139226  399c24e0000000           cmp dword ptr [rsp + 0xe0], ebx
0113922d  0f84c7000000             je 0x11392fa
01139233  4183fc16                 cmp r12d, 0x16
01139237  0f85bd000000             jne 0x11392fa
0113923d  488b4708                 mov rax, qword ptr [rdi + 8]
01139241  8b4004                   mov eax, dword ptr [rax + 4]
01139244  8bc8                     mov ecx, eax
01139246  81e100fcff0f             and ecx, 0xffffc00
0113924c  81f900100000             cmp ecx, 0x1000
01139252  0f851f040000             jne 0x1139677
01139258  a9ff030000               test eax, 0x3ff
0113925d  0f8514040000             jne 0x1139677
01139263  25000000f0               and eax, 0xf0000000
01139268  3d00000060               cmp eax, 0x60000000
0113926d  0f8504040000             jne 0x1139677
01139273  0faee8                   lfence
01139276  488bcf                   mov rcx, rdi
01139279  e8d2d1ecfe               call 0x6450
0113927e  0f57c0                   xorps xmm0, xmm0
01139281  4c8bc8                   mov r9, rax
01139284  0f11442468               movups xmmword ptr [rsp + 0x68], xmm0
01139289  41ba01000000             mov r10d, 1
0113928f  90                       nop
01139290  8bcb                     mov ecx, ebx
01139292  4d85d1                   test r9, r10
01139295  7426                     je 0x11392bd
01139297  48c1e903                 shr rcx, 3
0113929b  488d542477               lea rdx, [rsp + 0x77]
011392a0  83e10f                   and ecx, 0xf
011392a3  448bc3                   mov r8d, ebx
011392a6  482bd1                   sub rdx, rcx
011392a9  4183e007                 and r8d, 7
011392ad  0fb602                   movzx eax, byte ptr [rdx]
011392b0  440fb3c0                 btr eax, r8d
011392b4  0fb6c8                   movzx ecx, al
011392b7  440fabc1                 bts ecx, r8d
011392bb  880a                     mov byte ptr [rdx], cl
011392bd  ffc3                     inc ebx
011392bf  49d1c2                   rol r10, 1
011392c2  83fb08                   cmp ebx, 8
011392c5  72c9                     jb 0x1139290
011392c7  4b8b44e670               mov rax, qword ptr [r14 + r12*8 + 0x70]
011392cc  4b8d0ce6                 lea rcx, [r14 + r12*8]
011392d0  488b5008                 mov rdx, qword ptr [rax + 8]
011392d4  48c7401010000000         mov qword ptr [rax + 0x10], 0x10
011392dc  488d442468               lea rax, [rsp + 0x68]
011392e1  483bd0                   cmp rdx, rax
011392e4  7408                     je 0x11392ee
011392e6  0f10442468               movups xmm0, xmmword ptr [rsp + 0x68]
011392eb  0f1102                   movups xmmword ptr [rdx], xmm0
011392ee  488b4170                 mov rax, qword ptr [rcx + 0x70]
011392f2  408830                   mov byte ptr [rax], sil
011392f5  e982030000               jmp 0x113967c
011392fa  488b4708                 mov rax, qword ptr [rdi + 8]
011392fe  8b4004                   mov eax, dword ptr [rax + 4]
01139301  8bd0                     mov edx, eax
01139303  81e200fcff0f             and edx, 0xffffc00
01139309  81fa00580000             cmp edx, 0x5800
0113930f  7517                     jne 0x1139328
01139311  a9ff030000               test eax, 0x3ff
01139316  7510                     jne 0x1139328
01139318  8bc8                     mov ecx, eax
0113931a  81e1000000f0             and ecx, 0xf0000000
01139320  81f900000060             cmp ecx, 0x60000000
01139326  7427                     je 0x113934f
01139328  81fa00540000             cmp edx, 0x5400
0113932e  0f8543030000             jne 0x1139677
01139334  a9ff030000               test eax, 0x3ff
01139339  0f8538030000             jne 0x1139677
0113933f  25000000f0               and eax, 0xf0000000
01139344  3d00000060               cmp eax, 0x60000000
01139349  0f8528030000             jne 0x1139677
0113934f  0faee8                   lfence
01139352  488bcf                   mov rcx, rdi
01139355  e8f6d0ecfe               call 0x6450
0113935a  448b4728                 mov r8d, dword ptr [rdi + 0x28]
0113935e  4963cc                   movsxd rcx, r12d
01139361  498d1cce                 lea rbx, [r14 + rcx*8]
01139365  498b4cce70               mov rcx, qword ptr [r14 + rcx*8 + 0x70]
0113936a  4c894110                 mov qword ptr [rcx + 0x10], r8
0113936e  488b4908                 mov rcx, qword ptr [rcx + 8]
01139372  483bc8                   cmp rcx, rax
01139375  7408                     je 0x113937f
01139377  488bd0                   mov rdx, rax
0113937a  e88180ecfe               call 0x1400
0113937f  488b4370                 mov rax, qword ptr [rbx + 0x70]
01139383  408830                   mov byte ptr [rax], sil
01139386  e9f1020000               jmp 0x113967c
0113938b  4b8b4ce670               mov rcx, qword ptr [r14 + r12*8 + 0x70]
01139390  c60103                   mov byte ptr [rcx], 3
01139393  e9e4020000               jmp 0x113967c
01139398  488b4708                 mov rax, qword ptr [rdi + 8]
0113939c  8b4004                   mov eax, dword ptr [rax + 4]
0113939f  8bc8                     mov ecx, eax
011393a1  81e100fcff0f             and ecx, 0xffffc00
011393a7  4183fc03                 cmp r12d, 3
011393ab  755d                     jne 0x113940a
011393ad  bd000c0000               mov ebp, 0xc00
011393b2  3bcd                     cmp ecx, ebp
011393b4  0f85bd020000             jne 0x1139677
011393ba  a9ff030000               test eax, 0x3ff
011393bf  0f85b2020000             jne 0x1139677
011393c5  25000000f0               and eax, 0xf0000000
011393ca  3d00000060               cmp eax, 0x60000000
011393cf  0f85a2020000             jne 0x1139677
011393d5  0faee8                   lfence
011393d8  488bcf                   mov rcx, rdi
011393db  e870d0ecfe               call 0x6450
011393e0  498d96a00a0000           lea rdx, [r14 + 0xaa0]
011393e7  8bc8                     mov ecx, eax
011393e9  418d6c2401               lea ebp, [r12 + 1]
011393ee  e8ade4feff               call 0x11278a0
011393f3  4c8bc8                   mov r9, rax
011393f6  498d4e68                 lea rcx, [r14 + 0x68]
011393fa  448bc5                   mov r8d, ebp
011393fd  418bd4                   mov edx, r12d
01139400  e8eb100000               call 0x113a4f0
01139405  e972020000               jmp 0x113967c
0113940a  4183fc0e                 cmp r12d, 0xe
0113940e  755d                     jne 0x113946d
01139410  81f900080000             cmp ecx, 0x800
01139416  0f855b020000             jne 0x1139677
0113941c  a9ff030000               test eax, 0x3ff
01139421  0f8550020000             jne 0x1139677
01139427  25000000f0               and eax, 0xf0000000
0113942c  3d00000060               cmp eax, 0x60000000
01139431  0f8540020000             jne 0x1139677
01139437  0faee8                   lfence
0113943a  488bcf                   mov rcx, rdi
0113943d  e80ed0ecfe               call 0x6450
01139442  498d96a50a0000           lea rdx, [r14 + 0xaa5]
01139449  0fb7c8                   movzx ecx, ax
0113944c  418d6c24f4               lea ebp, [r12 - 0xc]
01139451  e8eae4feff               call 0x1127940
01139456  4c8bc8                   mov r9, rax
01139459  498d4e68                 lea rcx, [r14 + 0x68]
0113945d  448bc5                   mov r8d, ebp
01139460  418bd4                   mov edx, r12d
01139463  e888100000               call 0x113a4f0
01139468  e90f020000               jmp 0x113967c
0113946d  be05400080               mov esi, 0x80004005
01139472  81f9004c0000             cmp ecx, 0x4c00
01139478  0f85fe010000             jne 0x113967c
0113947e  a9ff030000               test eax, 0x3ff
01139483  0f85f3010000             jne 0x113967c
01139489  25000000f0               and eax, 0xf0000000
0113948e  3d00000060               cmp eax, 0x60000000
01139493  0f85e3010000             jne 0x113967c
01139499  0faee8                   lfence
0113949c  488bcf                   mov rcx, rdi
0113949f  e8accfecfe               call 0x6450
011394a4  4c8bc8                   mov r9, rax
011394a7  4885c0                   test rax, rax
011394aa  7420                     je 0x11394cc
011394ac  bd000c0000               mov ebp, 0xc00
011394b1  8bcd                     mov ecx, ebp
011394b3  3818                     cmp byte ptr [rax], bl
011394b5  7409                     je 0x11394c0
011394b7  48ffc0                   inc rax
011394ba  4883e901                 sub rcx, 1
011394be  75f3                     jne 0x11394b3
011394c0  482be9                   sub rbp, rcx
011394c3  4885c9                   test rcx, rcx
011394c6  480f44eb                 cmove rbp, rbx
011394ca  7503                     jne 0x11394cf
011394cc  488beb                   mov rbp, rbx
011394cf  498d4e68                 lea rcx, [r14 + 0x68]
011394d3  448bc5                   mov r8d, ebp
011394d6  418bd4                   mov edx, r12d
011394d9  e812100000               call 0x113a4f0
011394de  e999010000               jmp 0x113967c
011394e3  488b4708                 mov rax, qword ptr [rdi + 8]
011394e7  8b4004                   mov eax, dword ptr [rax + 4]
011394ea  8bc8                     mov ecx, eax
011394ec  81e100fcff0f             and ecx, 0xffffc00
011394f2  81f900500000             cmp ecx, 0x5000
011394f8  0f8579010000             jne 0x1139677
011394fe  a9ff030000               test eax, 0x3ff
01139503  0f856e010000             jne 0x1139677
01139509  25000000f0               and eax, 0xf0000000
0113950e  3d00000060               cmp eax, 0x60000000
01139513  0f855e010000             jne 0x1139677
01139519  488bcf                   mov rcx, rdi
0113951c  e82fcfecfe               call 0x6450
01139521  4983c668                 add r14, 0x68
01139525  0faee8                   lfence
01139528  418bd4                   mov edx, r12d
0113952b  4885c0                   test rax, rax
0113952e  7414                     je 0x1139544
01139530  448b4728                 mov r8d, dword ptr [rdi + 0x28]
01139534  4c8bc8                   mov r9, rax
01139537  498bce                   mov rcx, r14
0113953a  e8b10f0000               call 0x113a4f0
0113953f  e938010000               jmp 0x113967c
01139544  498b8ee8050000           mov rcx, qword ptr [r14 + 0x5e8]
0113954b  488b01                   mov rax, qword ptr [rcx]
0113954e  ff5018                   call qword ptr [rax + 0x18]
01139551  66396810                 cmp word ptr [rax + 0x10], bp
01139555  7458                     je 0x11395af
01139557  0faee8                   lfence
0113955a  0fb608                   movzx ecx, byte ptr [rax]
0113955d  420fb69429403b0202       movzx edx, byte ptr [rcx + r13 + 0x2023b40]
01139566  42389c2ae812b002         cmp byte ptr [rdx + r13 + 0x2b012e8], bl
0113956e  753f                     jne 0x11395af
01139570  663b5810                 cmp bx, word ptr [rax + 0x10]
01139574  7239                     jb 0x11395af
01139576  0faee8                   lfence
01139579  498b8ee8050000           mov rcx, qword ptr [r14 + 0x5e8]
01139580  418bd4                   mov edx, r12d
01139583  488b01                   mov rax, qword ptr [rcx]
01139586  ff5018                   call qword ptr [rax + 0x18]
01139589  66396810                 cmp word ptr [rax + 0x10], bp
0113958d  741d                     je 0x11395ac
0113958f  0faee8                   lfence
01139592  0fb608                   movzx ecx, byte ptr [rax]
01139595  420fb69429403b0202       movzx edx, byte ptr [rcx + r13 + 0x2023b40]
0113959e  42389c2ae812b002         cmp byte ptr [rdx + r13 + 0x2b012e8], bl
011395a6  7504                     jne 0x11395ac
011395a8  0fb76810                 movzx ebp, word ptr [rax + 0x10]
011395ac  0fb7dd                   movzx ebx, bp
011395af  4963c4                   movsxd rax, r12d
011395b2  488d15bff3f100           lea rdx, [rip + 0xf1f3bf]
011395b9  498d0cc6                 lea rcx, [r14 + rax*8]
011395bd  498b44c608               mov rax, qword ptr [r14 + rax*8 + 8]
011395c2  48895008                 mov qword ptr [rax + 8], rdx
011395c6  bafeff0000               mov edx, 0xfffe
011395cb  488b4108                 mov rax, qword ptr [rcx + 8]
011395cf  66215002                 and word ptr [rax + 2], dx
011395d3  488b4108                 mov rax, qword ptr [rcx + 8]
011395d7  48895810                 mov qword ptr [rax + 0x10], rbx
011395db  488b4108                 mov rax, qword ptr [rcx + 8]
011395df  408830                   mov byte ptr [rax], sil
011395e2  e995000000               jmp 0x113967c
011395e7  488b4708                 mov rax, qword ptr [rdi + 8]
011395eb  8b4004                   mov eax, dword ptr [rax + 4]
011395ee  8bc8                     mov ecx, eax
011395f0  81e100fcff0f             and ecx, 0xffffc00
011395f6  81f900540000             cmp ecx, 0x5400
011395fc  7579                     jne 0x1139677
011395fe  a9ff030000               test eax, 0x3ff
01139603  7572                     jne 0x1139677
01139605  25000000f0               and eax, 0xf0000000
0113960a  3d00000060               cmp eax, 0x60000000
0113960f  7566                     jne 0x1139677
01139611  0faee8                   lfence
01139614  488bcf                   mov rcx, rdi
01139617  e834ceecfe               call 0x6450
0113961c  4885c0                   test rax, rax
0113961f  488d0dca7fdb00           lea rcx, [rip + 0xdb7fca]
01139626  4b8d14e6                 lea rdx, [r14 + r12*8]
0113962a  480f44c1                 cmove rax, rcx
0113962e  488b4a70                 mov rcx, qword ptr [rdx + 0x70]
01139632  0f1000                   movups xmm0, xmmword ptr [rax]
01139635  0f114108                 movups xmmword ptr [rcx + 8], xmm0
01139639  488b4270                 mov rax, qword ptr [rdx + 0x70]
0113963d  8818                     mov byte ptr [rax], bl
0113963f  eb3b                     jmp 0x113967c
01139641  0faee8                   lfence
01139644  488d05ddee0101           lea rax, [rip + 0x101eedd]
0113964b  41b9c7090000             mov r9d, 0x9c7
01139651  4c8d0528993d01           lea r8, [rip + 0x13d9928]
01139658  4889442420               mov qword ptr [rsp + 0x20], rax
0113965d  488d15dcb33d01           lea rdx, [rip + 0x13db3dc]
01139664  b901000000               mov ecx, 1
01139669  ff150918d900             call qword ptr [rip + 0xd91809]
0113966f  4b8b4ce670               mov rcx, qword ptr [r14 + r12*8 + 0x70]
01139674  c60103                   mov byte ptr [rcx], 3
01139677  be05400080               mov esi, 0x80004005
0113967c  488b9c24c8000000         mov rbx, qword ptr [rsp + 0xc8]

; chunk at RVA 0x1139684 (272 bytes)
01139684  8bc6                     mov eax, esi
01139686  488b4c2478               mov rcx, qword ptr [rsp + 0x78]
0113968b  4833cc                   xor rcx, rsp
0113968e  e8dd79ecfe               call 0x1070
01139693  4881c480000000           add rsp, 0x80
0113969a  415f                     pop r15
0113969c  415e                     pop r14
0113969e  415d                     pop r13
011396a0  415c                     pop r12
011396a2  5f                       pop rdi
011396a3  5e                       pop rsi
011396a4  5d                       pop rbp
011396a5  c3                       ret
011396a6  90                       nop
011396a7  90                       nop
011396a8  e795                     out 0x95, eax
011396aa  1301                     adc eax, dword ptr [rcx]
011396ac  f9                       stc
011396ad  90                       nop
011396ae  1301                     adc eax, dword ptr [rcx]
011396b0  6b8f1301c78f13           imul ecx, dword ptr [rdi - 0x7038feed], 0x13
011396b7  019e90130123             add dword ptr [rsi + 0x23011390], ebx
011396bd  90                       nop
011396be  1301                     adc eax, dword ptr [rcx]
011396c0  db9113019893             fist dword ptr [rcx - 0x6c67feed]
011396c6  1301                     adc eax, dword ptr [rcx]
011396c8  e394                     jrcxz 0x113965e
011396ca  1301                     adc eax, dword ptr [rcx]
011396cc  4196                     xchg r14d, eax
011396ce  1301                     adc eax, dword ptr [rcx]
011396d0  0009                     add byte ptr [rcx], cl
011396d2  0909                     or dword ptr [rcx], ecx
011396d4  0909                     or dword ptr [rcx], ecx
011396d6  0109                     add dword ptr [rcx], ecx
011396d8  0909                     or dword ptr [rcx], ecx
011396da  0909                     or dword ptr [rcx], ecx
011396dc  0909                     or dword ptr [rcx], ecx
011396de  0909                     or dword ptr [rcx], ecx
011396e0  0209                     add cl, byte ptr [rcx]
011396e2  0909                     or dword ptr [rcx], ecx
011396e4  0309                     add ecx, dword ptr [rcx]
011396e6  0909                     or dword ptr [rcx], ecx
011396e8  0909                     or dword ptr [rcx], ecx
011396ea  0909                     or dword ptr [rcx], ecx
011396ec  0909                     or dword ptr [rcx], ecx
011396ee  0909                     or dword ptr [rcx], ecx
011396f0  0909                     or dword ptr [rcx], ecx
011396f2  0909                     or dword ptr [rcx], ecx
011396f4  0909                     or dword ptr [rcx], ecx
011396f6  0909                     or dword ptr [rcx], ecx
011396f8  0909                     or dword ptr [rcx], ecx
011396fa  0909                     or dword ptr [rcx], ecx
011396fc  0909                     or dword ptr [rcx], ecx
011396fe  0909                     or dword ptr [rcx], ecx
01139700  0909                     or dword ptr [rcx], ecx
01139702  0909                     or dword ptr [rcx], ecx
01139704  0909                     or dword ptr [rcx], ecx
01139706  0909                     or dword ptr [rcx], ecx
01139708  0909                     or dword ptr [rcx], ecx
0113970a  0909                     or dword ptr [rcx], ecx
0113970c  0909                     or dword ptr [rcx], ecx
0113970e  0909                     or dword ptr [rcx], ecx
01139710  0909                     or dword ptr [rcx], ecx
01139712  0909                     or dword ptr [rcx], ecx
01139714  0409                     add al, 9
01139716  0909                     or dword ptr [rcx], ecx
01139718  0909                     or dword ptr [rcx], ecx
0113971a  0909                     or dword ptr [rcx], ecx
0113971c  0909                     or dword ptr [rcx], ecx
0113971e  0909                     or dword ptr [rcx], ecx
01139720  0909                     or dword ptr [rcx], ecx
01139722  0909                     or dword ptr [rcx], ecx
01139724  0909                     or dword ptr [rcx], ecx
01139726  0909                     or dword ptr [rcx], ecx
01139728  0909                     or dword ptr [rcx], ecx
0113972a  090509090909             or dword ptr [rip + 0x9090909], eax
01139730  0909                     or dword ptr [rcx], ecx
01139732  0909                     or dword ptr [rcx], ecx
01139734  0909                     or dword ptr [rcx], ecx
01139736  0909                     or dword ptr [rcx], ecx
01139738  0909                     or dword ptr [rcx], ecx
0113973a  0909                     or dword ptr [rcx], ecx
0113973c  0909                     or dword ptr [rcx], ecx
0113973e  0909                     or dword ptr [rcx], ecx
01139740  0909                     or dword ptr [rcx], ecx
01139742  0909                     or dword ptr [rcx], ecx
01139744  0909                     or dword ptr [rcx], ecx
01139746  0909                     or dword ptr [rcx], ecx
01139748  0909                     or dword ptr [rcx], ecx
0113974a  0909                     or dword ptr [rcx], ecx
0113974c  0909                     or dword ptr [rcx], ecx
0113974e  0909                     or dword ptr [rcx], ecx
01139750  0906                     or dword ptr [rsi], eax
01139752  0907                     or dword ptr [rdi], eax
01139754  0909                     or dword ptr [rcx], ecx
01139756  0909                     or dword ptr [rcx], ecx
01139758  0909                     or dword ptr [rcx], ecx
0113975a  0909                     or dword ptr [rcx], ecx
0113975c  0909                     or dword ptr [rcx], ecx
0113975e  0909                     or dword ptr [rcx], ecx
01139760  0909                     or dword ptr [rcx], ecx
01139762  0909                     or dword ptr [rcx], ecx
01139764  0909                     or dword ptr [rcx], ecx
01139766  0909                     or dword ptr [rcx], ecx
01139768  0909                     or dword ptr [rcx], ecx
0113976a  0909                     or dword ptr [rcx], ecx
0113976c  0909                     or dword ptr [rcx], ecx
0113976e  0909                     or dword ptr [rcx], ecx
01139770  0909                     or dword ptr [rcx], ecx
01139772  0909                     or dword ptr [rcx], ecx
01139774  0909                     or dword ptr [rcx], ecx
01139776  0909                     or dword ptr [rcx], ecx
01139778  0909                     or dword ptr [rcx], ecx
0113977a  0909                     or dword ptr [rcx], ecx
0113977c  0909                     or dword ptr [rcx], ecx
0113977e  0909                     or dword ptr [rcx], ecx
01139780  0909                     or dword ptr [rcx], ecx
01139782  0909                     or dword ptr [rcx], ecx
01139784  0909                     or dword ptr [rcx], ecx
01139786  0909                     or dword ptr [rcx], ecx
01139788  0909                     or dword ptr [rcx], ecx
0113978a  0909                     or dword ptr [rcx], ecx
0113978c  0909                     or dword ptr [rcx], ecx
0113978e  0909                     or dword ptr [rcx], ecx
01139790  0909                     or dword ptr [rcx], ecx
01139792  0908                     or dword ptr [rax], ecx
