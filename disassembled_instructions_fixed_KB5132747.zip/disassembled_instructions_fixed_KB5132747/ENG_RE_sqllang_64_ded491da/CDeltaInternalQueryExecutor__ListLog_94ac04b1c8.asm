; CDeltaInternalQueryExecutor::ListLog
; sqllang.dll, primary RVA 0x1aea4d0, 456 bytes in 1 chunk(s)

; chunk at RVA 0x1aea4d0 (456 bytes)
01aea4d0  48895c2408               mov qword ptr [rsp + 8], rbx
01aea4d5  4889742410               mov qword ptr [rsp + 0x10], rsi
01aea4da  57                       push rdi
01aea4db  4883ec20                 sub rsp, 0x20
01aea4df  488b81a0000000           mov rax, qword ptr [rcx + 0xa0]
01aea4e6  410fb6d8                 movzx ebx, r8b
01aea4ea  0fb6f2                   movzx esi, dl
01aea4ed  488bf9                   mov rdi, rcx
01aea4f0  4883781000               cmp qword ptr [rax + 0x10], 0
01aea4f5  750c                     jne 0x1aea503
01aea4f7  4883781800               cmp qword ptr [rax + 0x18], 0
01aea4fc  7505                     jne 0x1aea503
01aea4fe  e85de2ffff               call 0x1ae8760
01aea503  41b908000000             mov r9d, 8
01aea509  458d41ff                 lea r8d, [r9 - 1]
01aea50d  84db                     test bl, bl
01aea50f  742b                     je 0x1aea53c
01aea511  488b8fa0000000           mov rcx, qword ptr [rdi + 0xa0]
01aea518  8b5120                   mov edx, dword ptr [rcx + 0x20]
01aea51b  85d2                     test edx, edx
01aea51d  7416                     je 0x1aea535
01aea51f  83ea01                   sub edx, 1
01aea522  740b                     je 0x1aea52f
01aea524  83fa01                   cmp edx, 1
01aea527  7513                     jne 0x1aea53c
01aea529  44894920                 mov dword ptr [rcx + 0x20], r9d
01aea52d  eb0d                     jmp 0x1aea53c
01aea52f  44894120                 mov dword ptr [rcx + 0x20], r8d
01aea533  eb07                     jmp 0x1aea53c
01aea535  c7412006000000           mov dword ptr [rcx + 0x20], 6
01aea53c  488b8fa0000000           mov rcx, qword ptr [rdi + 0xa0]
01aea543  4084f6                   test sil, sil
01aea546  0f848a000000             je 0x1aea5d6
01aea54c  c6475001                 mov byte ptr [rdi + 0x50], 1
01aea550  48634120                 movsxd rax, dword ptr [rcx + 0x20]
01aea554  413bc1                   cmp eax, r9d
01aea557  0f87e3000000             ja 0x1aea640
01aea55d  488d159c5a51fe           lea rdx, [rip - 0x1aea564]
01aea564  8b848250a6ae01           mov eax, dword ptr [rdx + rax*4 + 0x1aea650]
01aea56b  4803c2                   add rax, rdx
01aea56e  ffe0                     jmp rax
01aea570  84db                     test bl, bl
01aea572  b803000000               mov eax, 3
01aea577  ba0a000000               mov edx, 0xa
01aea57c  0f45c2                   cmovne eax, edx
01aea57f  894120                   mov dword ptr [rcx + 0x20], eax
01aea582  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01aea587  488b742438               mov rsi, qword ptr [rsp + 0x38]
01aea58c  4883c420                 add rsp, 0x20
01aea590  5f                       pop rdi
01aea591  c3                       ret
01aea592  84db                     test bl, bl
01aea594  b804000000               mov eax, 4
01aea599  ba09000000               mov edx, 9
01aea59e  0f45c2                   cmovne eax, edx
01aea5a1  894120                   mov dword ptr [rcx + 0x20], eax
01aea5a4  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01aea5a9  488b742438               mov rsi, qword ptr [rsp + 0x38]
01aea5ae  4883c420                 add rsp, 0x20
01aea5b2  5f                       pop rdi
01aea5b3  c3                       ret
01aea5b4  84db                     test bl, bl
01aea5b6  b805000000               mov eax, 5
01aea5bb  ba0b000000               mov edx, 0xb
01aea5c0  0f45c2                   cmovne eax, edx
01aea5c3  894120                   mov dword ptr [rcx + 0x20], eax
01aea5c6  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01aea5cb  488b742438               mov rsi, qword ptr [rsp + 0x38]
01aea5d0  4883c420                 add rsp, 0x20
01aea5d4  5f                       pop rdi
01aea5d5  c3                       ret
01aea5d6  c6475000                 mov byte ptr [rdi + 0x50], 0
01aea5da  8b4120                   mov eax, dword ptr [rcx + 0x20]
01aea5dd  83c0fd                   add eax, -3
01aea5e0  413bc1                   cmp eax, r9d
01aea5e3  775b                     ja 0x1aea640
01aea5e5  4898                     cdqe
01aea5e7  488d15125a51fe           lea rdx, [rip - 0x1aea5ee]
01aea5ee  8b848274a6ae01           mov eax, dword ptr [rdx + rax*4 + 0x1aea674]
01aea5f5  4803c2                   add rax, rdx
01aea5f8  ffe0                     jmp rax
01aea5fa  f6db                     neg bl
01aea5fc  1bc0                     sbb eax, eax
01aea5fe  83e006                   and eax, 6
01aea601  894120                   mov dword ptr [rcx + 0x20], eax
01aea604  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01aea609  488b742438               mov rsi, qword ptr [rsp + 0x38]
01aea60e  4883c420                 add rsp, 0x20
01aea612  5f                       pop rdi
01aea613  c3                       ret
01aea614  84db                     test bl, bl
01aea616  b801000000               mov eax, 1
01aea61b  410f45c0                 cmovne eax, r8d
01aea61f  894120                   mov dword ptr [rcx + 0x20], eax
01aea622  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01aea627  488b742438               mov rsi, qword ptr [rsp + 0x38]
01aea62c  4883c420                 add rsp, 0x20
01aea630  5f                       pop rdi
01aea631  c3                       ret
01aea632  84db                     test bl, bl
01aea634  b802000000               mov eax, 2
01aea639  410f45c1                 cmovne eax, r9d
01aea63d  894120                   mov dword ptr [rcx + 0x20], eax
01aea640  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01aea645  488b742438               mov rsi, qword ptr [rsp + 0x38]
01aea64a  4883c420                 add rsp, 0x20
01aea64e  5f                       pop rdi
01aea64f  c3                       ret
01aea650  70a5                     jo 0x1aea5f7
01aea652  ae                       scasb al, byte ptr [rdi]
01aea653  0192a5ae01b4             add dword ptr [rdx - 0x4bfe515b], edx
01aea659  a5                       movsd dword ptr [rdi], dword ptr [rsi]
01aea65a  ae                       scasb al, byte ptr [rdi]
01aea65b  0140a6                   add dword ptr [rax - 0x5a], eax
01aea65e  ae                       scasb al, byte ptr [rdi]
01aea65f  0140a6                   add dword ptr [rax - 0x5a], eax
01aea662  ae                       scasb al, byte ptr [rdi]
01aea663  0140a6                   add dword ptr [rax - 0x5a], eax
01aea666  ae                       scasb al, byte ptr [rdi]
01aea667  0170a5                   add dword ptr [rax - 0x5b], esi
01aea66a  ae                       scasb al, byte ptr [rdi]
01aea66b  0192a5ae01b4             add dword ptr [rdx - 0x4bfe515b], edx
01aea671  a5                       movsd dword ptr [rdi], dword ptr [rsi]
01aea672  ae                       scasb al, byte ptr [rdi]
01aea673  01fa                     add edx, edi
01aea675  a5                       movsd dword ptr [rdi], dword ptr [rsi]
01aea676  ae                       scasb al, byte ptr [rdi]
01aea677  0114a6                   add dword ptr [rsi + riz*4], edx
01aea67a  ae                       scasb al, byte ptr [rdi]
01aea67b  0132                     add dword ptr [rdx], esi
01aea67d  a6                       cmpsb byte ptr [rsi], byte ptr [rdi]
01aea67e  ae                       scasb al, byte ptr [rdi]
01aea67f  0140a6                   add dword ptr [rax - 0x5a], eax
01aea682  ae                       scasb al, byte ptr [rdi]
01aea683  0140a6                   add dword ptr [rax - 0x5a], eax
01aea686  ae                       scasb al, byte ptr [rdi]
01aea687  0140a6                   add dword ptr [rax - 0x5a], eax
01aea68a  ae                       scasb al, byte ptr [rdi]
01aea68b  0114a6                   add dword ptr [rsi + riz*4], edx
01aea68e  ae                       scasb al, byte ptr [rdi]
01aea68f  01fa                     add edx, edi
01aea691  a5                       movsd dword ptr [rdi], dword ptr [rsi]
01aea692  ae                       scasb al, byte ptr [rdi]
01aea693  0132                     add dword ptr [rdx], esi
01aea695  a6                       cmpsb byte ptr [rsi], byte ptr [rdi]
01aea696  ae                       scasb al, byte ptr [rdi]
