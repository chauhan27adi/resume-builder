; CEsCompFullCompile::ICacheCollation
; sqllang.dll, primary RVA 0x11dba0, 269 bytes in 1 chunk(s)

; chunk at RVA 0x11dba0 (269 bytes)
0011dba0  4889542410               mov qword ptr [rsp + 0x10], rdx
0011dba5  55                       push rbp
0011dba6  56                       push rsi
0011dba7  57                       push rdi
0011dba8  4156                     push r14
0011dbaa  4157                     push r15
0011dbac  4883ec40                 sub rsp, 0x40
0011dbb0  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
0011dbb9  48895c2470               mov qword ptr [rsp + 0x70], rbx
0011dbbe  418bd9                   mov ebx, r9d
0011dbc1  498be8                   mov rbp, r8
0011dbc4  4c8bfa                   mov r15, rdx
0011dbc7  488bf9                   mov rdi, rcx
0011dbca  654c8b1c2558000000       mov r11, qword ptr gs:[0x58]
0011dbd3  488b059ed3da01           mov rax, qword ptr [rip + 0x1dad39e]
0011dbda  448b10                   mov r10d, dword ptr [rax]
0011dbdd  488b059cd3da01           mov rax, qword ptr [rip + 0x1dad39c]
0011dbe4  8b00                     mov eax, dword ptr [rax]
0011dbe6  4b0304d3                 add rax, qword ptr [r11 + r10*8]
0011dbea  488b00                   mov rax, qword ptr [rax]
0011dbed  4c8b5050                 mov r10, qword ptr [rax + 0x50]
0011dbf1  410fb74a08               movzx ecx, word ptr [r10 + 8]
0011dbf6  ff152ce1da01             call qword ptr [rip + 0x1dae12c]
0011dbfc  8b00                     mov eax, dword ptr [rax]
0011dbfe  394514                   cmp dword ptr [rbp + 0x14], eax
0011dc01  0f85e84b1600             jne 0x2827ef
0011dc07  85db                     test ebx, ebx
0011dc09  0f85e14e1c00             jne 0x2e2af0
0011dc0f  0fb64500                 movzx eax, byte ptr [rbp]
0011dc13  488d15e623eeff           lea rdx, [rip - 0x11dc1a]
0011dc1a  0fb68c10403b0202         movzx ecx, byte ptr [rax + rdx + 0x2023b40]
0011dc22  33db                     xor ebx, ebx
0011dc24  8bc3                     mov eax, ebx
0011dc26  388411688c0502           cmp byte ptr [rcx + rdx + 0x2058c68], al
0011dc2d  0f95c0                   setne al
0011dc30  8bf0                     mov esi, eax
0011dc32  488b8788000000           mov rax, qword ptr [rdi + 0x88]
0011dc39  48391cf0                 cmp qword ptr [rax + rsi*8], rbx
0011dc3d  7413                     je 0x11dc52
0011dc3f  8bc6                     mov eax, esi
0011dc41  488b5c2470               mov rbx, qword ptr [rsp + 0x70]
0011dc46  4883c440                 add rsp, 0x40
0011dc4a  415f                     pop r15
0011dc4c  415e                     pop r14
0011dc4e  5f                       pop rdi
0011dc4f  5e                       pop rsi
0011dc50  5d                       pop rbp
0011dc51  c3                       ret
0011dc52  c78424800000005a120000   mov dword ptr [rsp + 0x80], 0x125a
0011dc5d  c644242002               mov byte ptr [rsp + 0x20], 2
0011dc62  41b95a120000             mov r9d, 0x125a
0011dc68  4c8d054959f501           lea r8, [rip + 0x1f55949]
0011dc6f  498bd7                   mov rdx, r15
0011dc72  b980000000               mov ecx, 0x80
0011dc77  ff1533d2da01             call qword ptr [rip + 0x1dad233]
0011dc7d  4889442438               mov qword ptr [rsp + 0x38], rax
0011dc82  4885c0                   test rax, rax
0011dc85  740c                     je 0x11dc93
0011dc87  488bc8                   mov rcx, rax
0011dc8a  ff1580e4da01             call qword ptr [rip + 0x1dae480]
0011dc90  488bd8                   mov rbx, rax
0011dc93  488bd3                   mov rdx, rbx
0011dc96  488bcd                   mov rcx, rbp
0011dc99  ff1579e4da01             call qword ptr [rip + 0x1dae479]
0011dc9f  488b8f88000000           mov rcx, qword ptr [rdi + 0x88]
0011dca6  48891cf1                 mov qword ptr [rcx + rsi*8], rbx
0011dcaa  eb93                     jmp 0x11dc3f
0011dcac  cc                       int3
