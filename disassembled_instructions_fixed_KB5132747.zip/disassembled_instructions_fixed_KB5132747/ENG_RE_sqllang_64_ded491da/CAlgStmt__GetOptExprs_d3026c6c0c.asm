; CAlgStmt::GetOptExprs
; sqllang.dll, primary RVA 0x352690, 212 bytes in 1 chunk(s)

; chunk at RVA 0x352690 (212 bytes)
00352690  48895c2408               mov qword ptr [rsp + 8], rbx
00352695  48896c2410               mov qword ptr [rsp + 0x10], rbp
0035269a  4889742418               mov qword ptr [rsp + 0x18], rsi
0035269f  48897c2420               mov qword ptr [rsp + 0x20], rdi
003526a4  4156                     push r14
003526a6  4883ec30                 sub rsp, 0x30
003526aa  33db                     xor ebx, ebx
003526ac  488be9                   mov rbp, rcx
003526af  891a                     mov dword ptr [rdx], ebx
003526b1  4d8bf0                   mov r14, r8
003526b4  488b4918                 mov rcx, qword ptr [rcx + 0x18]
003526b8  488bfa                   mov rdi, rdx
003526bb  8bf3                     mov esi, ebx
003526bd  4885c9                   test rcx, rcx
003526c0  0f85ce030000             jne 0x352a94
003526c6  48395d10                 cmp qword ptr [rbp + 0x10], rbx
003526ca  752a                     jne 0x3526f6
003526cc  48399df0000000           cmp qword ptr [rbp + 0xf0], rbx
003526d3  7521                     jne 0x3526f6
003526d5  488bc6                   mov rax, rsi
003526d8  eb01                     jmp 0x3526db
003526da  cc                       int3
003526db  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
003526e0  488b6c2448               mov rbp, qword ptr [rsp + 0x48]
003526e5  488b742450               mov rsi, qword ptr [rsp + 0x50]
003526ea  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
003526ef  4883c430                 add rsp, 0x30
003526f3  415e                     pop r14
003526f5  c3                       ret
003526f6  8b0f                     mov ecx, dword ptr [rdi]
003526f8  4c8d0569d4d101           lea r8, [rip + 0x1d1d469]
003526ff  83c102                   add ecx, 2
00352702  c644242003               mov byte ptr [rsp + 0x20], 3
00352707  b808000000               mov eax, 8
0035270c  41b9e2000000             mov r9d, 0xe2
00352712  48f7e1                   mul rcx
00352715  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
0035271c  498bd6                   mov rdx, r14
0035271f  480f40c1                 cmovo rax, rcx
00352723  488bc8                   mov rcx, rax
00352726  ff15cc87b701             call qword ptr [rip + 0x1b787cc]
0035272c  4c8bf0                   mov r14, rax
0035272f  391f                     cmp dword ptr [rdi], ebx
00352731  0f8709859e00             ja 0xd3ac40
00352737  488bce                   mov rcx, rsi
0035273a  ff156888b701             call qword ptr [rip + 0x1b78868]
00352740  8b17                     mov edx, dword ptr [rdi]
00352742  498bc6                   mov rax, r14
00352745  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
00352749  49890cd6                 mov qword ptr [r14 + rdx*8], rcx
0035274d  ff07                     inc dword ptr [rdi]
0035274f  8b17                     mov edx, dword ptr [rdi]
00352751  488b8df0000000           mov rcx, qword ptr [rbp + 0xf0]
00352758  49890cd6                 mov qword ptr [r14 + rdx*8], rcx
0035275c  ff07                     inc dword ptr [rdi]
0035275e  e978ffffff               jmp 0x3526db
00352763  cc                       int3
