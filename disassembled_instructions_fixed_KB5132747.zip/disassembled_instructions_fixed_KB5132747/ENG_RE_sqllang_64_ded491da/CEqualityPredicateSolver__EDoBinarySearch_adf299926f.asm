; CEqualityPredicateSolver::EDoBinarySearch
; sqllang.dll, primary RVA 0x1c66a0, 319 bytes in 1 chunk(s)

; chunk at RVA 0x1c66a0 (319 bytes)
001c66a0  4053                     push rbx
001c66a2  55                       push rbp
001c66a3  56                       push rsi
001c66a4  57                       push rdi
001c66a5  4154                     push r12
001c66a7  4155                     push r13
001c66a9  4156                     push r14
001c66ab  4157                     push r15
001c66ad  4883ec48                 sub rsp, 0x48
001c66b1  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
001c66ba  448bf2                   mov r14d, edx
001c66bd  488bf9                   mov rdi, rcx
001c66c0  488b4920                 mov rcx, qword ptr [rcx + 0x20]
001c66c4  488b01                   mov rax, qword ptr [rcx]
001c66c7  ff5010                   call qword ptr [rax + 0x10]
001c66ca  48898424a8000000         mov qword ptr [rsp + 0xa8], rax
001c66d2  4c8b4f08                 mov r9, qword ptr [rdi + 8]
001c66d6  4d8b4128                 mov r8, qword ptr [r9 + 0x28]
001c66da  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
001c66de  41bd04000000             mov r13d, 4
001c66e4  458d7dfd                 lea r15d, [r13 - 3]
001c66e8  4d85c0                   test r8, r8
001c66eb  0f84209b7101             je 0x18e0211
001c66f1  418b401c                 mov eax, dword ptr [r8 + 0x1c]
001c66f5  8d68ff                   lea ebp, [rax - 1]
001c66f8  448be5                   mov r12d, ebp
001c66fb  f6410801                 test byte ptr [rcx + 8], 1
001c66ff  450f45ef                 cmovne r13d, r15d
001c6703  4489ac2498000000         mov dword ptr [rsp + 0x98], r13d
001c670b  85c0                     test eax, eax
001c670d  0f84249b7101             je 0x18e0237
001c6713  3be8                     cmp ebp, eax
001c6715  0f832a9b7101             jae 0x18e0245
001c671b  0faee8                   lfence
001c671e  498b4028                 mov rax, qword ptr [r8 + 0x28]
001c6722  488b14e8                 mov rdx, qword ptr [rax + rbp*8]
001c6726  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
001c672a  eb01                     jmp 0x1c672d
001c672c  cc                       int3
001c672d  4c8b4228                 mov r8, qword ptr [rdx + 0x28]
001c6731  488b01                   mov rax, qword ptr [rcx]
001c6734  488b17                   mov rdx, qword ptr [rdi]
001c6737  ff5008                   call qword ptr [rax + 8]
001c673a  488bd8                   mov rbx, rax
001c673d  48898424a0000000         mov qword ptr [rsp + 0xa0], rax
001c6745  4885c0                   test rax, rax
001c6748  0f84e7390400             je 0x20a135
001c674e  488b7718                 mov rsi, qword ptr [rdi + 0x18]
001c6752  4c8bc8                   mov r9, rax
001c6755  4c8b8424a8000000         mov r8, qword ptr [rsp + 0xa8]
001c675d  488b5710                 mov rdx, qword ptr [rdi + 0x10]
001c6761  488bce                   mov rcx, rsi
001c6764  ff15a654d001             call qword ptr [rip + 0x1d054a6]
001c676a  83f802                   cmp eax, 2
001c676d  0f8575c30000             jne 0x1d2ae8
001c6773  8b4624                   mov eax, dword ptr [rsi + 0x24]
001c6776  3b4324                   cmp eax, dword ptr [rbx + 0x24]
001c6779  0f8c63c30000             jl 0x1d2ae2
001c677f  0f8fc89a7101             jg 0x18e024d
001c6785  c6472801                 mov byte ptr [rdi + 0x28], 1
001c6789  eb01                     jmp 0x1c678c
001c678b  cc                       int3
001c678c  8d4501                   lea eax, [rbp + 1]
001c678f  894738                   mov dword ptr [rdi + 0x38], eax
001c6792  418d442401               lea eax, [r12 + 1]
001c6797  89473c                   mov dword ptr [rdi + 0x3c], eax
001c679a  488d4730                 lea rax, [rdi + 0x30]
001c679e  807f2800                 cmp byte ptr [rdi + 0x28], 0
001c67a2  0f8435cf0000             je 0x1d36dd
001c67a8  f20f100538bc9702         movsd xmm0, qword ptr [rip + 0x297bc38]
001c67b0  f20f1100                 movsd qword ptr [rax], xmm0
001c67b4  eb01                     jmp 0x1c67b7
001c67b6  cc                       int3
001c67b7  33ff                     xor edi, edi
001c67b9  448bff                   mov r15d, edi
001c67bc  4885db                   test rbx, rbx
001c67bf  740a                     je 0x1c67cb
001c67c1  834320ff                 add dword ptr [rbx + 0x20], -1
001c67c5  0f84d79a7101             je 0x18e02a2
001c67cb  418bc7                   mov eax, r15d
001c67ce  4883c448                 add rsp, 0x48
001c67d2  415f                     pop r15
001c67d4  415e                     pop r14
001c67d6  415d                     pop r13
001c67d8  415c                     pop r12
001c67da  5f                       pop rdi
001c67db  5e                       pop rsi
001c67dc  5d                       pop rbp
001c67dd  5b                       pop rbx
001c67de  c3                       ret
