; CContainmentBreachHandler::CDBSubStatementTypeValidation
; sqllang.dll, primary RVA 0x857830, 849 bytes in 1 chunk(s)

; chunk at RVA 0x857830 (849 bytes)
00857830  4883ec38                 sub rsp, 0x38
00857834  81c133ffffff             add ecx, 0xffffff33
0085783a  4d8bd1                   mov r10, r9
0085783d  4d8bd8                   mov r11, r8
00857840  81f9a8000000             cmp ecx, 0xa8
00857846  0f8767020000             ja 0x857ab3
0085784c  4863c1                   movsxd rax, ecx
0085784f  4c8d05aa877aff           lea r8, [rip - 0x857856]
00857856  410fb68400d87a8500       movzx eax, byte ptr [r8 + rax + 0x857ad8]
0085785f  418b8c80b87a8500         mov ecx, dword ptr [r8 + rax*4 + 0x857ab8]
00857867  4903c8                   add rcx, r8
0085786a  ffe1                     jmp rcx
0085786c  85d2                     test edx, edx
0085786e  0f8488000000             je 0x8578fc
00857874  81fa00000800             cmp edx, 0x80000
0085787a  7467                     je 0x8578e3
0085787c  81fa00000002             cmp edx, 0x2000000
00857882  7446                     je 0x8578ca
00857884  81fa00000004             cmp edx, 0x4000000
0085788a  7425                     je 0x8578b1
0085788c  81fa00000008             cmp edx, 0x8000000
00857892  0f851b020000             jne 0x857ab3
00857898  41b811000000             mov r8d, 0x11
0085789e  4533c9                   xor r9d, r9d
008578a1  498bd2                   mov rdx, r10
008578a4  498bcb                   mov rcx, r11
008578a7  e824d093ff               call 0x1948d0
008578ac  4883c438                 add rsp, 0x38
008578b0  c3                       ret
008578b1  41b810000000             mov r8d, 0x10
008578b7  4533c9                   xor r9d, r9d
008578ba  498bd2                   mov rdx, r10
008578bd  498bcb                   mov rcx, r11
008578c0  e80bd093ff               call 0x1948d0
008578c5  4883c438                 add rsp, 0x38
008578c9  c3                       ret
008578ca  41b812000000             mov r8d, 0x12
008578d0  4533c9                   xor r9d, r9d
008578d3  498bd2                   mov rdx, r10
008578d6  498bcb                   mov rcx, r11
008578d9  e8f2cf93ff               call 0x1948d0
008578de  4883c438                 add rsp, 0x38
008578e2  c3                       ret
008578e3  41b813000000             mov r8d, 0x13
008578e9  4533c9                   xor r9d, r9d
008578ec  498bd2                   mov rdx, r10
008578ef  498bcb                   mov rcx, r11
008578f2  e8d9cf93ff               call 0x1948d0
008578f7  4883c438                 add rsp, 0x38
008578fb  c3                       ret
008578fc  41b80f000000             mov r8d, 0xf
00857902  4533c9                   xor r9d, r9d
00857905  498bd2                   mov rdx, r10
00857908  498bcb                   mov rcx, r11
0085790b  e8c0cf93ff               call 0x1948d0
00857910  4883c438                 add rsp, 0x38
00857914  c3                       ret
00857915  83ea18                   sub edx, 0x18
00857918  7461                     je 0x85797b
0085791a  83ea01                   sub edx, 1
0085791d  7443                     je 0x857962
0085791f  83ea01                   sub edx, 1
00857922  7425                     je 0x857949
00857924  83ea02                   sub edx, 2
00857927  7452                     je 0x85797b
00857929  83fa01                   cmp edx, 1
0085792c  0f8581010000             jne 0x857ab3
00857932  448d420d                 lea r8d, [rdx + 0xd]
00857936  4533c9                   xor r9d, r9d
00857939  498bd2                   mov rdx, r10
0085793c  498bcb                   mov rcx, r11
0085793f  e88ccf93ff               call 0x1948d0
00857944  4883c438                 add rsp, 0x38
00857948  c3                       ret
00857949  41b80d000000             mov r8d, 0xd
0085794f  4533c9                   xor r9d, r9d
00857952  498bd2                   mov rdx, r10
00857955  498bcb                   mov rcx, r11
00857958  e873cf93ff               call 0x1948d0
0085795d  4883c438                 add rsp, 0x38
00857961  c3                       ret
00857962  41b80c000000             mov r8d, 0xc
00857968  4533c9                   xor r9d, r9d
0085796b  498bd2                   mov rdx, r10
0085796e  498bcb                   mov rcx, r11
00857971  e85acf93ff               call 0x1948d0
00857976  4883c438                 add rsp, 0x38
0085797a  c3                       ret
0085797b  41b80b000000             mov r8d, 0xb
00857981  4533c9                   xor r9d, r9d
00857984  498bd2                   mov rdx, r10
00857987  498bcb                   mov rcx, r11
0085798a  e841cf93ff               call 0x1948d0
0085798f  4883c438                 add rsp, 0x38
00857993  c3                       ret
00857994  83ea02                   sub edx, 2
00857997  7420                     je 0x8579b9
00857999  83fa01                   cmp edx, 1
0085799c  0f8511010000             jne 0x857ab3
008579a2  448d4240                 lea r8d, [rdx + 0x40]
008579a6  4533c9                   xor r9d, r9d
008579a9  498bd2                   mov rdx, r10
008579ac  498bcb                   mov rcx, r11
008579af  e81ccf93ff               call 0x1948d0
008579b4  4883c438                 add rsp, 0x38
008579b8  c3                       ret
008579b9  41b840000000             mov r8d, 0x40
008579bf  4533c9                   xor r9d, r9d
008579c2  498bd2                   mov rdx, r10
008579c5  498bcb                   mov rcx, r11
008579c8  e803cf93ff               call 0x1948d0
008579cd  4883c438                 add rsp, 0x38
008579d1  c3                       ret
008579d2  33c0                     xor eax, eax
008579d4  83fa05                   cmp edx, 5
008579d7  448d401e                 lea r8d, [rax + 0x1e]
008579db  eb67                     jmp 0x857a44
008579dd  83fa02                   cmp edx, 2
008579e0  743e                     je 0x857a20
008579e2  83fa04                   cmp edx, 4
008579e5  7420                     je 0x857a07
008579e7  83fa08                   cmp edx, 8
008579ea  0f85c3000000             jne 0x857ab3
008579f0  448d4230                 lea r8d, [rdx + 0x30]
008579f4  4533c9                   xor r9d, r9d
008579f7  498bd2                   mov rdx, r10
008579fa  498bcb                   mov rcx, r11
008579fd  e8cece93ff               call 0x1948d0
00857a02  4883c438                 add rsp, 0x38
00857a06  c3                       ret
00857a07  41b837000000             mov r8d, 0x37
00857a0d  4533c9                   xor r9d, r9d
00857a10  498bd2                   mov rdx, r10
00857a13  498bcb                   mov rcx, r11
00857a16  e8b5ce93ff               call 0x1948d0
00857a1b  4883c438                 add rsp, 0x38
00857a1f  c3                       ret
00857a20  41b836000000             mov r8d, 0x36
00857a26  4533c9                   xor r9d, r9d
00857a29  498bd2                   mov rdx, r10
00857a2c  498bcb                   mov rcx, r11
00857a2f  e89cce93ff               call 0x1948d0
00857a34  4883c438                 add rsp, 0x38
00857a38  c3                       ret
00857a39  33c0                     xor eax, eax
00857a3b  41b832000000             mov r8d, 0x32
00857a41  83fa02                   cmp edx, 2
00857a44  440f45c0                 cmovne r8d, eax
00857a48  4585c0                   test r8d, r8d
00857a4b  7466                     je 0x857ab3
00857a4d  4533c9                   xor r9d, r9d
00857a50  498bd2                   mov rdx, r10
00857a53  498bcb                   mov rcx, r11
00857a56  e875ce93ff               call 0x1948d0
00857a5b  4883c438                 add rsp, 0x38
00857a5f  c3                       ret
00857a60  83ea01                   sub edx, 1
00857a63  743a                     je 0x857a9f
00857a65  83ea01                   sub edx, 1
00857a68  741c                     je 0x857a86
00857a6a  83fa02                   cmp edx, 2
00857a6d  7544                     jne 0x857ab3
00857a6f  448d4245                 lea r8d, [rdx + 0x45]
00857a73  4533c9                   xor r9d, r9d
00857a76  498bd2                   mov rdx, r10
00857a79  498bcb                   mov rcx, r11
00857a7c  e84fce93ff               call 0x1948d0
00857a81  4883c438                 add rsp, 0x38
00857a85  c3                       ret
00857a86  41b845000000             mov r8d, 0x45
00857a8c  4533c9                   xor r9d, r9d
00857a8f  498bd2                   mov rdx, r10
00857a92  498bcb                   mov rcx, r11
00857a95  e836ce93ff               call 0x1948d0
00857a9a  4883c438                 add rsp, 0x38
00857a9e  c3                       ret
00857a9f  41b846000000             mov r8d, 0x46
00857aa5  4533c9                   xor r9d, r9d
00857aa8  498bd2                   mov rdx, r10
00857aab  498bcb                   mov rcx, r11
00857aae  e81dce93ff               call 0x1948d0
00857ab3  4883c438                 add rsp, 0x38
00857ab7  c3                       ret
00857ab8  1579850060               adc eax, 0x60008579
00857abd  7a85                     jp 0x857a44
00857abf  006c7885                 add byte ptr [rax + rdi*2 - 0x7b], ch
00857ac3  0094798500397a           add byte ptr [rcx + rdi*2 + 0x7a390085], dl
00857aca  8500                     test dword ptr [rax], eax
00857acc  dd7985                   fnstsw word ptr [rcx - 0x7b]
00857acf  00d2                     add dl, dl
00857ad1  7985                     jns 0x857a58
00857ad3  00b37a850000             add byte ptr [rbx + 0x857a], dh
