; CBindEnv::LookupTargetTable
; sqllang.dll, primary RVA 0x269e40, 333 bytes in 3 chunk(s)

; chunk at RVA 0x207753 (200 bytes)
00207753  4c89bc24e0000000         mov qword ptr [rsp + 0xe0], r15
0020775b  440fb67d67               movzx r15d, byte ptr [rbp + 0x67]
00207760  4584ff                   test r15b, r15b
00207763  0f8553058000             jne 0xa07cbc
00207769  498b4e30                 mov rcx, qword ptr [r14 + 0x30]
0020776d  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
00207770  8b75c7                   mov esi, dword ptr [rbp - 0x39]
00207773  c745cf02000000           mov dword ptr [rbp - 0x31], 2
0020777a  f6411004                 test byte ptr [rcx + 0x10], 4
0020777e  897dd7                   mov dword ptr [rbp - 0x29], edi
00207781  8975db                   mov dword ptr [rbp - 0x25], esi
00207784  895ddf                   mov dword ptr [rbp - 0x21], ebx
00207787  7534                     jne 0x2077bd
00207789  0f1045cf                 movups xmm0, xmmword ptr [rbp - 0x31]
0020778d  488d55e7                 lea rdx, [rbp - 0x19]
00207791  488b01                   mov rax, qword ptr [rcx]
00207794  f20f104ddf               movsd xmm1, qword ptr [rbp - 0x21]
00207799  4d8bcd                   mov r9, r13
0020779c  885c2428                 mov byte ptr [rsp + 0x28], bl
002077a0  4533c0                   xor r8d, r8d
002077a3  0f2945e7                 movaps xmmword ptr [rbp - 0x19], xmm0
002077a7  f20f114df7               movsd qword ptr [rbp - 9], xmm1
002077ac  4c89642420               mov qword ptr [rsp + 0x20], r12
002077b1  ff5010                   call qword ptr [rax + 0x10]
002077b4  83f802                   cmp eax, 2
002077b7  0f84f9048000             je 0xa07cb6
002077bd  c745cf02000000           mov dword ptr [rbp - 0x31], 2
002077c4  488d45cf                 lea rax, [rbp - 0x31]
002077c8  897dd7                   mov dword ptr [rbp - 0x29], edi
002077cb  8975db                   mov dword ptr [rbp - 0x25], esi
002077ce  895ddf                   mov dword ptr [rbp - 0x21], ebx
002077d1  eb01                     jmp 0x2077d4
002077d3  cc                       int3
002077d4  498b4e30                 mov rcx, qword ptr [r14 + 0x30]
002077d8  f6411004                 test byte ptr [rcx + 0x10], 4
002077dc  752d                     jne 0x20780b
002077de  0f1000                   movups xmm0, xmmword ptr [rax]
002077e1  488d5507                 lea rdx, [rbp + 7]
002077e5  44887c2428               mov byte ptr [rsp + 0x28], r15b
002077ea  f20f104810               movsd xmm1, qword ptr [rax + 0x10]
002077ef  4d8bcd                   mov r9, r13
002077f2  488b01                   mov rax, qword ptr [rcx]
002077f5  41b001                   mov r8b, 1
002077f8  0f294507                 movaps xmmword ptr [rbp + 7], xmm0
002077fc  f20f114d17               movsd qword ptr [rbp + 0x17], xmm1
00207801  4c89642420               mov qword ptr [rsp + 0x20], r12
00207806  ff5010                   call qword ptr [rax + 0x10]
00207809  8bd8                     mov ebx, eax
0020780b  8bc3                     mov eax, ebx
0020780d  4c8bbc24e0000000         mov r15, qword ptr [rsp + 0xe0]
00207815  e999260600               jmp 0x269eb3
0020781a  cc                       int3

; chunk at RVA 0x269e40 (115 bytes)
00269e40  4055                     push rbp
00269e42  53                       push rbx
00269e43  56                       push rsi
00269e44  57                       push rdi
00269e45  4154                     push r12
00269e47  4155                     push r13
00269e49  4156                     push r14
00269e4b  488d6c24d9               lea rbp, [rsp - 0x27]
00269e50  4881ec90000000           sub rsp, 0x90
00269e57  33db                     xor ebx, ebx
00269e59  488955d7                 mov qword ptr [rbp - 0x29], rdx
00269e5d  4c8bf1                   mov r14, rcx
00269e60  895dcf                   mov dword ptr [rbp - 0x31], ebx
00269e63  488b4930                 mov rcx, qword ptr [rcx + 0x30]
00269e67  4d8be1                   mov r12, r9
00269e6a  4d8be8                   mov r13, r8
00269e6d  488bf2                   mov rsi, rdx
00269e70  f6411004                 test byte ptr [rcx + 0x10], 4
00269e74  0f85a8d8f9ff             jne 0x207722
00269e7a  0f1045cf                 movups xmm0, xmmword ptr [rbp - 0x31]
00269e7e  488d55e7                 lea rdx, [rbp - 0x19]
00269e82  488b01                   mov rax, qword ptr [rcx]
00269e85  f20f104ddf               movsd xmm1, qword ptr [rbp - 0x21]
00269e8a  4d8bcd                   mov r9, r13
00269e8d  885c2428                 mov byte ptr [rsp + 0x28], bl
00269e91  4533c0                   xor r8d, r8d
00269e94  0f2945e7                 movaps xmmword ptr [rbp - 0x19], xmm0
00269e98  f20f114df7               movsd qword ptr [rbp - 9], xmm1
00269e9d  4c89642420               mov qword ptr [rsp + 0x20], r12
00269ea2  ff5010                   call qword ptr [rax + 0x10]
00269ea5  8bf8                     mov edi, eax
00269ea7  83f803                   cmp eax, 3
00269eaa  0f8574d8f9ff             jne 0x207724
00269eb0  eb01                     jmp 0x269eb3
00269eb2  cc                       int3

; chunk at RVA 0x269eb3 (18 bytes)
00269eb3  4881c490000000           add rsp, 0x90
00269eba  415e                     pop r14
00269ebc  415d                     pop r13
00269ebe  415c                     pop r12
00269ec0  5f                       pop rdi
00269ec1  5e                       pop rsi
00269ec2  5b                       pop rbx
00269ec3  5d                       pop rbp
00269ec4  c3                       ret
