; CCardFrameworkSQL12::GenStatsInfoSet
; sqllang.dll, primary RVA 0x375ea0, 303 bytes in 6 chunk(s)

; chunk at RVA 0x1c75c5 (31 bytes)
001c75c5  488bc3                   mov rax, rbx
001c75c8  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001c75cd  488b9c2490000000         mov rbx, qword ptr [rsp + 0x90]
001c75d5  4c8b7c2468               mov r15, qword ptr [rsp + 0x68]
001c75da  4881c498000000           add rsp, 0x98
001c75e1  5f                       pop rdi
001c75e2  5e                       pop rsi
001c75e3  c3                       ret

; chunk at RVA 0x375ea0 (44 bytes)
00375ea0  488bc4                   mov rax, rsp
00375ea3  56                       push rsi
00375ea4  57                       push rdi
00375ea5  4881ec98000000           sub rsp, 0x98
00375eac  4c8b4970                 mov r9, qword ptr [rcx + 0x70]
00375eb0  488bf1                   mov rsi, rcx
00375eb3  4d85c9                   test r9, r9
00375eb6  0f84b9000000             je 0x375f75
00375ebc  418b7918                 mov edi, dword ptr [r9 + 0x18]
00375ec0  85ff                     test edi, edi
00375ec2  0f84ad000000             je 0x375f75
00375ec8  458b410c                 mov r8d, dword ptr [r9 + 0xc]

; chunk at RVA 0x375ecc (4 bytes)
00375ecc  488958e8                 mov qword ptr [rax - 0x18], rbx

; chunk at RVA 0x375ed0 (165 bytes)
00375ed0  488968e0                 mov qword ptr [rax - 0x20], rbp
00375ed4  4c8960d8                 mov qword ptr [rax - 0x28], r12
00375ed8  4533e4                   xor r12d, r12d
00375edb  4c8968d0                 mov qword ptr [rax - 0x30], r13
00375edf  418bec                   mov ebp, r12d
00375ee2  4c8970c8                 mov qword ptr [rax - 0x38], r14
00375ee6  418bd4                   mov edx, r12d
00375ee9  4c8978c0                 mov qword ptr [rax - 0x40], r15
00375eed  4489a424b0000000         mov dword ptr [rsp + 0xb0], r12d
00375ef5  4585c0                   test r8d, r8d
00375ef8  7415                     je 0x375f0f
00375efa  498b4910                 mov rcx, qword ptr [r9 + 0x10]
00375efe  6690                     nop
00375f00  8bc2                     mov eax, edx
00375f02  48392cc1                 cmp qword ptr [rcx + rax*8], rbp
00375f06  7507                     jne 0x375f0f
00375f08  ffc2                     inc edx
00375f0a  413bd0                   cmp edx, r8d
00375f0d  72f1                     jb 0x375f00
00375f0f  413bd0                   cmp edx, r8d
00375f12  0f840214e5ff             je 0x1c731a
00375f18  4d8b4910                 mov r9, qword ptr [r9 + 0x10]
00375f1c  8bc2                     mov eax, edx
00375f1e  4d8b14c1                 mov r10, qword ptr [r9 + rax*8]
00375f22  4d85d2                   test r10, r10
00375f25  0f84ef13e5ff             je 0x1c731a
00375f2b  0f1f440000               nop dword ptr [rax + rax]
00375f30  498b4208                 mov rax, qword ptr [r10 + 8]
00375f34  8b4848                   mov ecx, dword ptr [rax + 0x48]
00375f37  034844                   add ecx, dword ptr [rax + 0x44]
00375f3a  034840                   add ecx, dword ptr [rax + 0x40]
00375f3d  03483c                   add ecx, dword ptr [rax + 0x3c]
00375f40  498b02                   mov rax, qword ptr [r10]
00375f43  03e9                     add ebp, ecx
00375f45  4c8bd0                   mov r10, rax
00375f48  4885c0                   test rax, rax
00375f4b  751d                     jne 0x375f6a
00375f4d  0f1f00                   nop dword ptr [rax]
00375f50  ffc2                     inc edx
00375f52  8bc2                     mov eax, edx
00375f54  413bd0                   cmp edx, r8d
00375f57  0f83ad13e5ff             jae 0x1c730a
00375f5d  4d3924d1                 cmp qword ptr [r9 + rdx*8], r12
00375f61  74ed                     je 0x375f50
00375f63  eb01                     jmp 0x375f66
00375f65  cc                       int3
00375f66  4d8b14d1                 mov r10, qword ptr [r9 + rdx*8]
00375f6a  4d85d2                   test r10, r10
00375f6d  75c1                     jne 0x375f30
00375f6f  e99f13e5ff               jmp 0x1c7313
00375f74  cc                       int3

; chunk at RVA 0x375f75 (12 bytes)
00375f75  33c0                     xor eax, eax
00375f77  4881c498000000           add rsp, 0x98
00375f7e  5f                       pop rdi
00375f7f  5e                       pop rsi
00375f80  c3                       ret

; chunk at RVA 0x18f271a (47 bytes)
018f271a  498b06                   mov rax, qword ptr [r14]
018f271d  4c8bc3                   mov r8, rbx
018f2720  498b5708                 mov rdx, qword ptr [r15 + 8]
018f2724  498bce                   mov rcx, r14
018f2727  ff5050                   call qword ptr [rax + 0x50]
018f272a  4885c0                   test rax, rax
018f272d  0f85954e8dfe             jne 0x1c75c8
018f2733  498b06                   mov rax, qword ptr [r14]
018f2736  4c8bc3                   mov r8, rbx
018f2739  498b5708                 mov rdx, qword ptr [r15 + 8]
018f273d  498bce                   mov rcx, r14
018f2740  ff5010                   call qword ptr [rax + 0x10]
018f2743  e9804e8dfe               jmp 0x1c75c8
018f2748  cc                       int3
