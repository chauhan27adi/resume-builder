; CAutoScrollLock::Init
; sqllang.dll, primary RVA 0x43a70, 222 bytes in 1 chunk(s)

; chunk at RVA 0x43a70 (222 bytes)
00043a70  48895c2408               mov qword ptr [rsp + 8], rbx
00043a75  4889742410               mov qword ptr [rsp + 0x10], rsi
00043a7a  48897c2418               mov qword ptr [rsp + 0x18], rdi
00043a7f  4156                     push r14
00043a81  4883ec20                 sub rsp, 0x20
00043a85  488b02                   mov rax, qword ptr [rdx]
00043a88  488bd9                   mov rbx, rcx
00043a8b  488bca                   mov rcx, rdx
00043a8e  418bf1                   mov esi, r9d
00043a91  418bf8                   mov edi, r8d
00043a94  4c8bf2                   mov r14, rdx
00043a97  ff90f8000000             call qword ptr [rax + 0xf8]
00043a9d  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00043aa2  4c895318                 mov qword ptr [rbx + 0x18], r10
00043aa6  488903                   mov qword ptr [rbx], rax
00043aa9  c7431000000000           mov dword ptr [rbx + 0x10], 0
00043ab0  4885c0                   test rax, rax
00043ab3  747a                     je 0x43b2f
00043ab5  85f6                     test esi, esi
00043ab7  7576                     jne 0x43b2f
00043ab9  85ff                     test edi, edi
00043abb  7510                     jne 0x43acd
00043abd  498b06                   mov rax, qword ptr [r14]
00043ac0  8d560e                   lea edx, [rsi + 0xe]
00043ac3  498bce                   mov rcx, r14
00043ac6  ff5030                   call qword ptr [rax + 0x30]
00043ac9  85c0                     test eax, eax
00043acb  7462                     je 0x43b2f
00043acd  ba01000000               mov edx, 1
00043ad2  895308                   mov dword ptr [rbx + 8], edx
00043ad5  eb01                     jmp 0x43ad8
00043ad7  cc                       int3
00043ad8  85ff                     test edi, edi
00043ada  7560                     jne 0x43b3c
00043adc  488b0b                   mov rcx, qword ptr [rbx]
00043adf  4885c9                   test rcx, rcx
00043ae2  7458                     je 0x43b3c
00043ae4  397964                   cmp dword ptr [rcx + 0x64], edi
00043ae7  7653                     jbe 0x43b3c
00043ae9  c7430c01000000           mov dword ptr [rbx + 0xc], 1
00043af0  eb01                     jmp 0x43af3
00043af2  cc                       int3
00043af3  8b8188000000             mov eax, dword ptr [rcx + 0x88]
00043af9  894314                   mov dword ptr [rbx + 0x14], eax
00043afc  85d2                     test edx, edx
00043afe  7419                     je 0x43b19
00043b00  85ff                     test edi, edi
00043b02  750d                     jne 0x43b11
00043b04  c781d800000001000000     mov dword ptr [rcx + 0xd8], 1
00043b0e  488b0b                   mov rcx, qword ptr [rbx]
00043b11  488b4318                 mov rax, qword ptr [rbx + 0x18]
00043b15  48894840                 mov qword ptr [rax + 0x40], rcx
00043b19  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00043b1e  488b742438               mov rsi, qword ptr [rsp + 0x38]
00043b23  488b7c2440               mov rdi, qword ptr [rsp + 0x40]
00043b28  4883c420                 add rsp, 0x20
00043b2c  415e                     pop r14
00043b2e  c3                       ret
00043b2f  33d2                     xor edx, edx
00043b31  c7430800000000           mov dword ptr [rbx + 8], 0
00043b38  85f6                     test esi, esi
00043b3a  749c                     je 0x43ad8
00043b3c  488b0b                   mov rcx, qword ptr [rbx]
00043b3f  c7430c00000000           mov dword ptr [rbx + 0xc], 0
00043b46  4885c9                   test rcx, rcx
00043b49  74b1                     je 0x43afc
00043b4b  eba6                     jmp 0x43af3
00043b4d  cc                       int3
