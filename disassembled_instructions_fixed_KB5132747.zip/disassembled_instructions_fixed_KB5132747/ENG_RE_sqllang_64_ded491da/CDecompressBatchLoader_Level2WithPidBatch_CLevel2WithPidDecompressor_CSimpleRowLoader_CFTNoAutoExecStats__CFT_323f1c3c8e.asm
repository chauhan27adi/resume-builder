; CDecompressBatchLoader<Level2WithPidBatch,CLevel2WithPidDecompressor,CSimpleRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x972c20, 1401 bytes in 3 chunk(s)

; chunk at RVA 0x972c20 (57 bytes)
00972c20  4c894c2420               mov qword ptr [rsp + 0x20], r9
00972c25  89542410                 mov dword ptr [rsp + 0x10], edx
00972c29  55                       push rbp
00972c2a  57                       push rdi
00972c2b  4155                     push r13
00972c2d  4157                     push r15
00972c2f  488d6c24c1               lea rbp, [rsp - 0x3f]
00972c34  4881ece8000000           sub rsp, 0xe8
00972c3b  83792002                 cmp dword ptr [rcx + 0x20], 2
00972c3f  4d8be8                   mov r13, r8
00972c42  8bfa                     mov edi, edx
00972c44  4c8bf9                   mov r15, rcx
00972c47  7510                     jne 0x972c59
00972c49  33c0                     xor eax, eax
00972c4b  4881c4e8000000           add rsp, 0xe8
00972c52  415f                     pop r15
00972c54  415d                     pop r13
00972c56  5f                       pop rdi
00972c57  5d                       pop rbp
00972c58  c3                       ret

; chunk at RVA 0x972c59 (1248 bytes)
00972c59  48899c2420010000         mov qword ptr [rsp + 0x120], rbx
00972c61  0f57c0                   xorps xmm0, xmm0
00972c64  4889b424e0000000         mov qword ptr [rsp + 0xe0], rsi
00972c6c  0f57c9                   xorps xmm1, xmm1
00972c6f  4c89a424d8000000         mov qword ptr [rsp + 0xd8], r12
00972c77  4c89b424d0000000         mov qword ptr [rsp + 0xd0], r14
00972c7f  4533f6                   xor r14d, r14d
00972c82  32c9                     xor cl, cl
00972c84  448975b7                 mov dword ptr [rbp - 0x49], r14d
00972c88  884d67                   mov byte ptr [rbp + 0x67], cl
00972c8b  4c8975bf                 mov qword ptr [rbp - 0x41], r14
00972c8f  448875c7                 mov byte ptr [rbp - 0x39], r14b
00972c93  660f7f45d7               movdqa xmmword ptr [rbp - 0x29], xmm0
00972c98  660f7f4de7               movdqa xmmword ptr [rbp - 0x19], xmm1
00972c9d  660f7f45f7               movdqa xmmword ptr [rbp - 9], xmm0
00972ca2  4c897507                 mov qword ptr [rbp + 7], r14
00972ca6  c7450f01000000           mov dword ptr [rbp + 0xf], 1
00972cad  4c897517                 mov qword ptr [rbp + 0x17], r14
00972cb1  4489742420               mov dword ptr [rsp + 0x20], r14d
00972cb6  45887510                 mov byte ptr [r13 + 0x10], r14b
00972cba  4c8d253fd368ff           lea r12, [rip - 0x972cc1]
00972cc1  4538b748250000           cmp byte ptr [r15 + 0x2548], r14b
00972cc8  0f8495000000             je 0x972d63
00972cce  498b9f40250000           mov rbx, qword ptr [r15 + 0x2540]
00972cd5  33d2                     xor edx, edx
00972cd7  4c8bc3                   mov r8, rbx
00972cda  4588b748250000           mov byte ptr [r15 + 0x2548], r14b
00972ce1  498bcd                   mov rcx, r13
00972ce4  e8b79cffff               call 0x96c9a0
00972ce9  488b5360                 mov rdx, qword ptr [rbx + 0x60]
00972ced  488d75b7                 lea rsi, [rbp - 0x49]
00972cf1  418b4d00                 mov ecx, dword ptr [r13]
00972cf5  498b4560                 mov rax, qword ptr [r13 + 0x60]
00972cf9  ffc9                     dec ecx
00972cfb  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00972cff  4803c9                   add rcx, rcx
00972d02  0f1002                   movups xmm0, xmmword ptr [rdx]
00972d05  448975b7                 mov dword ptr [rbp - 0x49], r14d
00972d09  c744242001000000         mov dword ptr [rsp + 0x20], 1
00972d11  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
00972d15  498b8740250000           mov rax, qword ptr [r15 + 0x2540]
00972d1c  ff08                     dec dword ptr [rax]
00972d1e  418b5500                 mov edx, dword ptr [r13]
00972d22  498b4508                 mov rax, qword ptr [r13 + 8]
00972d26  488945bf                 mov qword ptr [rbp - 0x41], rax
00972d2a  498b4520                 mov rax, qword ptr [r13 + 0x20]
00972d2e  488d0cd0                 lea rcx, [rax + rdx*8]
00972d32  498b4528                 mov rax, qword ptr [r13 + 0x28]
00972d36  48894dd7                 mov qword ptr [rbp - 0x29], rcx
00972d3a  488d0c90                 lea rcx, [rax + rdx*4]
00972d3e  498b4530                 mov rax, qword ptr [r13 + 0x30]
00972d42  48894ddf                 mov qword ptr [rbp - 0x21], rcx
00972d46  4588b748250000           mov byte ptr [r15 + 0x2548], r14b
00972d4d  488d0c90                 lea rcx, [rax + rdx*4]
00972d51  b801000000               mov eax, 1
00972d56  2bc2                     sub eax, edx
00972d58  48894de7                 mov qword ptr [rbp - 0x19], rcx
00972d5c  03f8                     add edi, eax
00972d5e  897d6f                   mov dword ptr [rbp + 0x6f], edi
00972d61  eb03                     jmp 0x972d66
00972d63  498bf5                   mov rsi, r13
00972d66  45397720                 cmp dword ptr [r15 + 0x20], r14d
00972d6a  7555                     jne 0x972dc1
00972d6c  498b4728                 mov rax, qword ptr [r15 + 0x28]
00972d70  498d4f28                 lea rcx, [r15 + 0x28]
00972d74  4d8bc1                   mov r8, r9
00972d77  4c89742428               mov qword ptr [rsp + 0x28], r14
00972d7c  488d542428               lea rdx, [rsp + 0x28]
00972d81  44897587                 mov dword ptr [rbp - 0x79], r14d
00972d85  4c89758f                 mov qword ptr [rbp - 0x71], r14
00972d89  44897597                 mov dword ptr [rbp - 0x69], r14d
00972d8d  4c89759f                 mov qword ptr [rbp - 0x61], r14
00972d91  448975a7                 mov dword ptr [rbp - 0x59], r14d
00972d95  66448975ab               mov word ptr [rbp - 0x55], r14w
00972d9a  c6456701                 mov byte ptr [rbp + 0x67], 1
00972d9e  ff10                     call qword ptr [rax]
00972da0  3dc60e0400               cmp eax, 0x40ec6
00972da5  0f843c030000             je 0x9730e7
00972dab  498d4f38                 lea rcx, [r15 + 0x38]
00972daf  488d542428               lea rdx, [rsp + 0x28]
00972db4  e84794f5ff               call 0x8cc200
00972db9  41c7472001000000         mov dword ptr [r15 + 0x20], 1
00972dc1  498b4730                 mov rax, qword ptr [r15 + 0x30]
00972dc5  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00972dcc  4c894608                 mov qword ptr [rsi + 8], r8
00972dd0  498b5730                 mov rdx, qword ptr [r15 + 0x30]
00972dd4  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00972ddb  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00972dde  83e007                   and eax, 7
00972de1  83f805                   cmp eax, 5
00972de4  773c                     ja 0x972e22
00972de6  4898                     cdqe
00972de8  418b8c843c319700         mov ecx, dword ptr [r12 + rax*4 + 0x97313c]
00972df0  4903cc                   add rcx, r12
00972df3  ffe1                     jmp rcx
00972df5  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972df9  0f95c3                   setne bl
00972dfc  eb26                     jmp 0x972e24
00972dfe  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972e02  0f9dc3                   setge bl
00972e05  eb1d                     jmp 0x972e24
00972e07  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972e0b  0f9ec3                   setle bl
00972e0e  eb14                     jmp 0x972e24
00972e10  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972e14  0f9fc3                   setg bl
00972e17  eb0b                     jmp 0x972e24
00972e19  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972e1d  0f9cc3                   setl bl
00972e20  eb02                     jmp 0x972e24
00972e22  32db                     xor bl, bl
00972e24  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00972e27  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00972e2e  83e007                   and eax, 7
00972e31  83f805                   cmp eax, 5
00972e34  7741                     ja 0x972e77
00972e36  4898                     cdqe
00972e38  418b8c8454319700         mov ecx, dword ptr [r12 + rax*4 + 0x973154]
00972e40  4903cc                   add rcx, r12
00972e43  ffe1                     jmp rcx
00972e45  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e49  410f95c4                 setne r12b
00972e4d  eb2b                     jmp 0x972e7a
00972e4f  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e53  410f9dc4                 setge r12b
00972e57  eb21                     jmp 0x972e7a
00972e59  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e5d  410f9ec4                 setle r12b
00972e61  eb17                     jmp 0x972e7a
00972e63  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e67  410f9fc4                 setg r12b
00972e6b  eb0d                     jmp 0x972e7a
00972e6d  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e71  410f9cc4                 setl r12b
00972e75  eb03                     jmp 0x972e7a
00972e77  4532e4                   xor r12b, r12b
00972e7a  498d4f38                 lea rcx, [r15 + 0x38]
00972e7e  4c8bc6                   mov r8, rsi
00972e81  8bd7                     mov edx, edi
00972e83  e818b1ffff               call 0x96dfa0
00972e88  84c0                     test al, al
00972e8a  7504                     jne 0x972e90
00972e8c  45897720                 mov dword ptr [r15 + 0x20], r14d
00972e90  8b06                     mov eax, dword ptr [rsi]
00972e92  448bc0                   mov r8d, eax
00972e95  85c0                     test eax, eax
00972e97  0f84c6010000             je 0x973063
00972e9d  84db                     test bl, bl
00972e9f  7509                     jne 0x972eaa
00972ea1  4584e4                   test r12b, r12b
00972ea4  0f84b9010000             je 0x973063
00972eaa  448bc8                   mov r9d, eax
00972ead  84db                     test bl, bl
00972eaf  747f                     je 0x972f30
00972eb1  4d8b5f30                 mov r11, qword ptr [r15 + 0x30]
00972eb5  458bd6                   mov r10d, r14d
00972eb8  85c0                     test eax, eax
00972eba  746b                     je 0x972f27
00972ebc  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00972ec0  488d3d39d168ff           lea rdi, [rip - 0x972ec7]
00972ec7  488b5e20                 mov rbx, qword ptr [rsi + 0x20]
00972ecb  4183e007                 and r8d, 7
00972ecf  90                       nop
00972ed0  418bca                   mov ecx, r10d
00972ed3  4c8b0ccb                 mov r9, qword ptr [rbx + rcx*8]
00972ed7  4183f805                 cmp r8d, 5
00972edb  0f87ae000000             ja 0x972f8f
00972ee1  4963c8                   movsxd rcx, r8d
00972ee4  8b948f6c319700           mov edx, dword ptr [rdi + rcx*4 + 0x97316c]
00972eeb  4803d7                   add rdx, rdi
00972eee  ffe2                     jmp rdx
00972ef0  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972ef4  0f94c1                   sete cl
00972ef7  eb22                     jmp 0x972f1b
00972ef9  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972efd  0f9cc1                   setl cl
00972f00  eb19                     jmp 0x972f1b
00972f02  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972f06  0f9fc1                   setg cl
00972f09  eb10                     jmp 0x972f1b
00972f0b  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972f0f  0f9ec1                   setle cl
00972f12  eb07                     jmp 0x972f1b
00972f14  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972f18  0f9dc1                   setge cl
00972f1b  84c9                     test cl, cl
00972f1d  7570                     jne 0x972f8f
00972f1f  41ffc2                   inc r10d
00972f22  443bd0                   cmp r10d, eax
00972f25  72a9                     jb 0x972ed0
00972f27  448936                   mov dword ptr [rsi], r14d
00972f2a  418bc6                   mov eax, r14d
00972f2d  458bce                   mov r9d, r14d
00972f30  458bc1                   mov r8d, r9d
00972f33  4584e4                   test r12b, r12b
00972f36  0f8427010000             je 0x973063
00972f3c  85c0                     test eax, eax
00972f3e  0f841f010000             je 0x973063
00972f44  4d8b5f30                 mov r11, qword ptr [r15 + 0x30]
00972f48  4c8d25b1d068ff           lea r12, [rip - 0x972f4f]
00972f4f  488b7e20                 mov rdi, qword ptr [rsi + 0x20]
00972f53  0f1f4000                 nop dword ptr [rax]
00972f57  660f1f840000000000       nop word ptr [rax + rax]
00972f60  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00972f64  ffc8                     dec eax
00972f66  458bd1                   mov r10d, r9d
00972f69  83e107                   and ecx, 7
00972f6c  448bc8                   mov r9d, eax
00972f6f  458bc2                   mov r8d, r10d
00972f72  488b1cc7                 mov rbx, qword ptr [rdi + rax*8]
00972f76  83f905                   cmp ecx, 5
00972f79  0f87e4000000             ja 0x973063
00972f7f  4863c9                   movsxd rcx, ecx
00972f82  418b948c84319700         mov edx, dword ptr [r12 + rcx*4 + 0x973184]
00972f8a  4903d4                   add rdx, r12
00972f8d  ffe2                     jmp rdx
00972f8f  443bd0                   cmp r10d, eax
00972f92  7393                     jae 0x972f27
00972f94  448bc8                   mov r9d, eax
00972f97  4585d2                   test r10d, r10d
00972f9a  7494                     je 0x972f30
00972f9c  458bde                   mov r11d, r14d
00972f9f  452bca                   sub r9d, r10d
00972fa2  7478                     je 0x97301c
00972fa4  498bd6                   mov rdx, r14
00972fa7  498bde                   mov rbx, r14
00972faa  498bfe                   mov rdi, r14
00972fad  0f1f00                   nop dword ptr [rax]
00972fb0  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00972fb4  438d0413                 lea eax, [r11 + r10]
00972fb8  448bc0                   mov r8d, eax
00972fbb  488b04c1                 mov rax, qword ptr [rcx + rax*8]
00972fbf  4889040f                 mov qword ptr [rdi + rcx], rax
00972fc3  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
00972fc7  428b0481                 mov eax, dword ptr [rcx + r8*4]
00972fcb  89040b                   mov dword ptr [rbx + rcx], eax
00972fce  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
00972fd2  428b0481                 mov eax, dword ptr [rcx + r8*4]
00972fd6  4d03c0                   add r8, r8
00972fd9  89040b                   mov dword ptr [rbx + rcx], eax
00972fdc  488b4638                 mov rax, qword ptr [rsi + 0x38]
00972fe0  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00972fe5  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00972fe9  488b4648                 mov rax, qword ptr [rsi + 0x48]
00972fed  4885c0                   test rax, rax
00972ff0  7409                     je 0x972ffb
00972ff2  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00972ff7  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00972ffb  488b4660                 mov rax, qword ptr [rsi + 0x60]
00972fff  41ffc3                   inc r11d
00973002  4883c708                 add rdi, 8
00973006  4883c304                 add rbx, 4
0097300a  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
0097300f  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00973013  4883c210                 add rdx, 0x10
00973017  453bd9                   cmp r11d, r9d
0097301a  7294                     jb 0x972fb0
0097301c  44890e                   mov dword ptr [rsi], r9d
0097301f  418bc1                   mov eax, r9d
00973022  e909ffffff               jmp 0x972f30
00973027  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097302b  0f94c1                   sete cl
0097302e  eb22                     jmp 0x973052
00973030  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00973034  0f9cc1                   setl cl
00973037  eb19                     jmp 0x973052
00973039  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097303d  0f9fc1                   setg cl
00973040  eb10                     jmp 0x973052
00973042  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00973046  0f9ec1                   setle cl
00973049  eb07                     jmp 0x973052
0097304b  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097304f  0f9dc1                   setge cl
00973052  84c9                     test cl, cl
00973054  750d                     jne 0x973063
00973056  8906                     mov dword ptr [rsi], eax
00973058  448bc0                   mov r8d, eax
0097305b  85c0                     test eax, eax
0097305d  0f85fdfeffff             jne 0x972f60
00973063  4538b749250000           cmp byte ptr [r15 + 0x2549], r14b
0097306a  7462                     je 0x9730ce
0097306c  448b06                   mov r8d, dword ptr [rsi]
0097306f  4585c0                   test r8d, r8d
00973072  745a                     je 0x9730ce
00973074  498bbf40250000           mov rdi, qword ptr [r15 + 0x2540]
0097307b  4c8bc6                   mov r8, rsi
0097307e  41c6874825000001         mov byte ptr [r15 + 0x2548], 1
00973086  488bcf                   mov rcx, rdi
00973089  8b1e                     mov ebx, dword ptr [rsi]
0097308b  ffcb                     dec ebx
0097308d  8bd3                     mov edx, ebx
0097308f  e80c99ffff               call 0x96c9a0
00973094  8b0f                     mov ecx, dword ptr [rdi]
00973096  488b4760                 mov rax, qword ptr [rdi + 0x60]
0097309a  ffc9                     dec ecx
0097309c  488b5660                 mov rdx, qword ptr [rsi + 0x60]
009730a0  4803c9                   add rcx, rcx
009730a3  448bc3                   mov r8d, ebx
009730a6  4d03c0                   add r8, r8
009730a9  420f1004c2               movups xmm0, xmmword ptr [rdx + r8*8]
009730ae  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
009730b2  ff0e                     dec dword ptr [rsi]
009730b4  41c6451001               mov byte ptr [r13 + 0x10], 1
009730b9  498b8740250000           mov rax, qword ptr [r15 + 0x2540]
009730c0  488b4820                 mov rcx, qword ptr [rax + 0x20]
009730c4  488b01                   mov rax, qword ptr [rcx]
009730c7  49894518                 mov qword ptr [r13 + 0x18], rax
009730cb  448b06                   mov r8d, dword ptr [rsi]
009730ce  8b442420                 mov eax, dword ptr [rsp + 0x20]
009730d2  4103c0                   add eax, r8d
009730d5  89442420                 mov dword ptr [rsp + 0x20], eax
009730d9  7521                     jne 0x9730fc
009730db  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
009730de  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009730e2  e9cffbffff               jmp 0x972cb6
009730e7  41c7472002000000         mov dword ptr [r15 + 0x20], 2
009730ef  45397500                 cmp dword ptr [r13], r14d
009730f3  410f95c6                 setne r14b
009730f7  418bc6                   mov eax, r14d
009730fa  eb0f                     jmp 0x97310b
009730fc  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00973100  f6d9                     neg cl
00973102  41894500                 mov dword ptr [r13], eax
00973106  1bc0                     sbb eax, eax
00973108  83c002                   add eax, 2
0097310b  4c8ba424d8000000         mov r12, qword ptr [rsp + 0xd8]
00973113  488bb424e0000000         mov rsi, qword ptr [rsp + 0xe0]
0097311b  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
00973123  4c8bb424d0000000         mov r14, qword ptr [rsp + 0xd0]
0097312b  4881c4e8000000           add rsp, 0xe8
00973132  415f                     pop r15
00973134  415d                     pop r13
00973136  5f                       pop rdi
00973137  5d                       pop rbp
00973138  c3                       ret

; chunk at RVA 0x97313c (96 bytes)
0097313c  222e                     and ch, byte ptr [rsi]
0097313e  97                       xchg edi, eax
0097313f  00f5                     add ch, dh
00973141  2d9700fe2d               sub eax, 0x2dfe0097
00973146  97                       xchg edi, eax
00973147  0010                     add byte ptr [rax], dl
00973149  2e97                     xchg edi, eax
0097314b  0007                     add byte ptr [rdi], al
0097314d  2e97                     xchg edi, eax
0097314f  0019                     add byte ptr [rcx], bl
00973151  2e97                     xchg edi, eax
00973153  00772e                   add byte ptr [rdi + 0x2e], dh
00973156  97                       xchg edi, eax
00973157  00452e                   add byte ptr [rbp + 0x2e], al
0097315a  97                       xchg edi, eax
0097315b  004f2e                   add byte ptr [rdi + 0x2e], cl
0097315e  97                       xchg edi, eax
0097315f  00632e                   add byte ptr [rbx + 0x2e], ah
00973162  97                       xchg edi, eax
00973163  00592e                   add byte ptr [rcx + 0x2e], bl
00973166  97                       xchg edi, eax
00973167  006d2e                   add byte ptr [rbp + 0x2e], ch
0097316a  97                       xchg edi, eax
0097316b  008f2f9700f0             add byte ptr [rdi - 0xfff68d1], cl
00973171  2e97                     xchg edi, eax
00973173  00f9                     add cl, bh
00973175  2e97                     xchg edi, eax
00973177  000b                     add byte ptr [rbx], cl
