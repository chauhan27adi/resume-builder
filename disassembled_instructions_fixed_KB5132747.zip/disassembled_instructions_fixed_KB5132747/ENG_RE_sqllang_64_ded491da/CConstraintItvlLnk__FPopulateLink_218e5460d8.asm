; CConstraintItvlLnk::FPopulateLink
; sqllang.dll, primary RVA 0x13bbc0, 290 bytes in 1 chunk(s)

; chunk at RVA 0x13bbc0 (290 bytes)
0013bbc0  4889542410               mov qword ptr [rsp + 0x10], rdx
0013bbc5  55                       push rbp
0013bbc6  56                       push rsi
0013bbc7  57                       push rdi
0013bbc8  4156                     push r14
0013bbca  4157                     push r15
0013bbcc  4883ec50                 sub rsp, 0x50
0013bbd0  48c7442440feffffff       mov qword ptr [rsp + 0x40], 0xfffffffffffffffe
0013bbd9  48899c2480000000         mov qword ptr [rsp + 0x80], rbx
0013bbe1  4d8bf1                   mov r14, r9
0013bbe4  458bf8                   mov r15d, r8d
0013bbe7  488bea                   mov rbp, rdx
0013bbea  488bf1                   mov rsi, rcx
0013bbed  418d40ff                 lea eax, [r8 - 1]
0013bbf1  83f841                   cmp eax, 0x41
0013bbf4  0f871e144901             ja 0x15cd018
0013bbfa  488d0dff43ecff           lea rcx, [rip - 0x13bc01]
0013bc01  0fb68401a0bc1300         movzx eax, byte ptr [rcx + rax + 0x13bca0]
0013bc09  448b948188bc1300         mov r10d, dword ptr [rcx + rax*4 + 0x13bc88]
0013bc11  4c03d1                   add r10, rcx
0013bc14  41ffe2                   jmp r10
0013bc17  800e01                   or byte ptr [rsi], 1
0013bc1a  4d85f6                   test r14, r14
0013bc1d  400f94c7                 sete dil
0013bc21  488d4e08                 lea rcx, [rsi + 8]
0013bc25  4c89742430               mov qword ptr [rsp + 0x30], r14
0013bc2a  488b9c24a0000000         mov rbx, qword ptr [rsp + 0xa0]
0013bc32  48895c2428               mov qword ptr [rsp + 0x28], rbx
0013bc37  40887c2420               mov byte ptr [rsp + 0x20], dil
0013bc3c  41b101                   mov r9b, 1
0013bc3f  450fb6c1                 movzx r8d, r9b
0013bc43  e8c8d4fcff               call 0x109110
0013bc48  800e02                   or byte ptr [rsi], 2
0013bc4b  488d4e58                 lea rcx, [rsi + 0x58]
0013bc4f  4c89742430               mov qword ptr [rsp + 0x30], r14
0013bc54  48895c2428               mov qword ptr [rsp + 0x28], rbx
0013bc59  40887c2420               mov byte ptr [rsp + 0x20], dil
0013bc5e  41b101                   mov r9b, 1
0013bc61  4533c0                   xor r8d, r8d
0013bc64  488bd5                   mov rdx, rbp
0013bc67  e8a4d4fcff               call 0x109110
0013bc6c  800e0c                   or byte ptr [rsi], 0xc
0013bc6f  b001                     mov al, 1
0013bc71  eb01                     jmp 0x13bc74
0013bc73  cc                       int3
0013bc74  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
0013bc7c  4883c450                 add rsp, 0x50
0013bc80  415f                     pop r15
0013bc82  415e                     pop r14
0013bc84  5f                       pop rdi
0013bc85  5e                       pop rsi
0013bc86  5d                       pop rbp
0013bc87  c3                       ret
0013bc88  ab                       stosd dword ptr [rdi], eax
0013bc89  25150017bc               and eax, 0xbc170015
0013bc8e  1300                     adc eax, dword ptr [rax]
0013bc90  1c58                     sbb al, 0x58
0013bc92  3300                     xor eax, dword ptr [rax]
0013bc94  206727                   and byte ptr [rdi + 0x27], ah
0013bc97  002f                     add byte ptr [rdi], ch
0013bc99  25150018d0               and eax, 0xd0180015
0013bc9e  5c                       pop rsp
0013bc9f  0100                     add dword ptr [rax], eax
0013bca1  0100                     add dword ptr [rax], eax
0013bca3  0203                     add al, byte ptr [rbx]
0013bca5  020505050505             add al, byte ptr [rip + 0x5050505]
0013bcab  0505050505               add eax, 0x5050505
0013bcb0  0505050505               add eax, 0x5050505
0013bcb5  0505050505               add eax, 0x5050505
0013bcba  0505050505               add eax, 0x5050505
0013bcbf  0505050505               add eax, 0x5050505
0013bcc4  0405                     add al, 5
0013bcc6  0505050505               add eax, 0x5050505
0013bccb  0505050505               add eax, 0x5050505
0013bcd0  0505050505               add eax, 0x5050505
0013bcd5  0505050505               add eax, 0x5050505
0013bcda  0505050505               add eax, 0x5050505
