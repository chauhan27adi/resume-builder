; CCostUtils::CardEstimateRebindsAndRewinds
; sqllang.dll, primary RVA 0xee510, 693 bytes in 7 chunk(s)

; chunk at RVA 0xe62bd (66 bytes)
000e62bd  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
000e62c5  f20f1006                 movsd xmm0, qword ptr [rsi]
000e62c9  f20f5e00                 divsd xmm0, qword ptr [rax]
000e62cd  660f2ff8                 comisd xmm7, xmm0
000e62d1  0f82c8644201             jb 0x150c79f
000e62d7  660f2fc6                 comisd xmm0, xmm6
000e62db  0f82b6644201             jb 0x150c797
000e62e1  f20f5c0527c6f801         subsd xmm0, qword ptr [rip + 0x1f8c627]
000e62e9  660f2ff8                 comisd xmm7, xmm0
000e62ed  0f82c3644201             jb 0x150c7b6
000e62f3  660f2fc6                 comisd xmm0, xmm6
000e62f7  73ba                     jae 0xe62b3
000e62f9  0f28c6                   movaps xmm0, xmm6
000e62fc  ebb5                     jmp 0xe62b3
000e62fe  cc                       int3

; chunk at RVA 0xee510 (67 bytes)
000ee510  488bc4                   mov rax, rsp
000ee513  53                       push rbx
000ee514  4156                     push r14
000ee516  4157                     push r15
000ee518  4883ec60                 sub rsp, 0x60
000ee51c  80bc24b000000000         cmp byte ptr [rsp + 0xb0], 0
000ee524  4d8bf8                   mov r15, r8
000ee527  4c8bb424d0000000         mov r14, qword ptr [rsp + 0xd0]
000ee52f  4c8bd1                   mov r10, rcx
000ee532  0f2970d8                 movaps xmmword ptr [rax - 0x28], xmm6
000ee536  f20f10356290f201         movsd xmm6, qword ptr [rip + 0x1f29062]
000ee53e  0f2978c8                 movaps xmmword ptr [rax - 0x38], xmm7
000ee542  f20f103d4e90f201         movsd xmm7, qword ptr [rip + 0x1f2904e]
000ee54a  440f2940b8               movaps xmmword ptr [rax - 0x48], xmm8
000ee54f  450f57c0                 xorps xmm8, xmm8

; chunk at RVA 0xee553 (7 bytes)
000ee553  48897010                 mov qword ptr [rax + 0x10], rsi
000ee557  498bf1                   mov rsi, r9

; chunk at RVA 0xee55a (39 bytes)
000ee55a  48897818                 mov qword ptr [rax + 0x18], rdi
000ee55e  488bfa                   mov rdi, rdx
000ee561  0f851c7dffff             jne 0xe6283
000ee567  837a1c01                 cmp dword ptr [rdx + 0x1c], 1
000ee56b  488b9c24c8000000         mov rbx, qword ptr [rsp + 0xc8]
000ee573  0f85447dffff             jne 0xe62bd
000ee579  488b4228                 mov rax, qword ptr [rdx + 0x28]
000ee57d  4c8b4908                 mov r9, qword ptr [rcx + 8]

; chunk at RVA 0xee581 (177 bytes)
000ee581  4889ac2480000000         mov qword ptr [rsp + 0x80], rbp
000ee589  488b28                   mov rbp, qword ptr [rax]
000ee58c  4d85c9                   test r9, r9
000ee58f  0f85c8e14101             jne 0x150c75d
000ee595  488b4910                 mov rcx, qword ptr [rcx + 0x10]
000ee599  488b4130                 mov rax, qword ptr [rcx + 0x30]
000ee59d  488b4918                 mov rcx, qword ptr [rcx + 0x18]
000ee5a1  8b00                     mov eax, dword ptr [rax]
000ee5a3  99                       cdq
000ee5a4  0fb6d2                   movzx edx, dl
000ee5a7  03c2                     add eax, edx
000ee5a9  448bc0                   mov r8d, eax
000ee5ac  0fb6c0                   movzx eax, al
000ee5af  2bc2                     sub eax, edx
000ee5b1  41c1f808                 sar r8d, 8
000ee5b5  488b5110                 mov rdx, qword ptr [rcx + 0x10]
000ee5b9  488b8a30010000           mov rcx, qword ptr [rdx + 0x130]
000ee5c0  488b4960                 mov rcx, qword ptr [rcx + 0x60]
000ee5c4  443b410c                 cmp r8d, dword ptr [rcx + 0xc]
000ee5c8  0f83b3e14101             jae 0x150c781
000ee5ce  0faee8                   lfence
000ee5d1  488b4918                 mov rcx, qword ptr [rcx + 0x18]
000ee5d5  4d8b4a08                 mov r9, qword ptr [r10 + 8]
000ee5d9  4a8b0cc1                 mov rcx, qword ptr [rcx + r8*8]
000ee5dd  eb01                     jmp 0xee5e0
000ee5df  cc                       int3
000ee5e0  488b0cc1                 mov rcx, qword ptr [rcx + rax*8]
000ee5e4  4c8b5908                 mov r11, qword ptr [rcx + 8]
000ee5e8  498bca                   mov rcx, r10
000ee5eb  e88003f8ff               call 0x6e970
000ee5f0  488b8818030000           mov rcx, qword ptr [rax + 0x318]
000ee5f7  4d85c9                   test r9, r9
000ee5fa  0f858de14101             jne 0x150c78d
000ee600  498b4210                 mov rax, qword ptr [r10 + 0x10]
000ee604  488b5008                 mov rdx, qword ptr [rax + 8]
000ee608  488b01                   mov rax, qword ptr [rcx]
000ee60b  4d8bcb                   mov r9, r11
000ee60e  488b5210                 mov rdx, qword ptr [rdx + 0x10]
000ee612  4c8bc5                   mov r8, rbp
000ee615  48897c2428               mov qword ptr [rsp + 0x28], rdi
000ee61a  48895c2420               mov qword ptr [rsp + 0x20], rbx
000ee61f  ff5038                   call qword ptr [rax + 0x38]
000ee622  488bac2480000000         mov rbp, qword ptr [rsp + 0x80]
000ee62a  84c0                     test al, al
000ee62c  0f848b7cffff             je 0xe62bd

; chunk at RVA 0xee650 (149 bytes)
000ee650  660f2fc6                 comisd xmm0, xmm6
000ee654  0f8273e14101             jb 0x150c7cd
000ee65a  0f28d0                   movaps xmm2, xmm0
000ee65d  eb01                     jmp 0xee660
000ee65f  cc                       int3
000ee660  f20f100b                 movsd xmm1, qword ptr [rbx]
000ee664  660f2fd1                 comisd xmm2, xmm1
000ee668  0f87082e0500             ja 0x141476
000ee66e  660f2ff8                 comisd xmm7, xmm0
000ee672  0f28d0                   movaps xmm2, xmm0
000ee675  0f8279e14101             jb 0x150c7f4
000ee67b  660f2fc6                 comisd xmm0, xmm6
000ee67f  0f8267e14101             jb 0x150c7ec
000ee685  66440f2fc2               comisd xmm8, xmm2
000ee68a  0f877be14101             ja 0x150c80b
000ee690  660f2ff8                 comisd xmm7, xmm0
000ee694  0f8282e14101             jb 0x150c81c
000ee69a  660f2fc6                 comisd xmm0, xmm6
000ee69e  0f8270e14101             jb 0x150c814
000ee6a4  0f28d0                   movaps xmm2, xmm0
000ee6a7  eb01                     jmp 0xee6aa
000ee6a9  cc                       int3
000ee6aa  660f2fd1                 comisd xmm2, xmm1
000ee6ae  7717                     ja 0xee6c7
000ee6b0  660f2ff8                 comisd xmm7, xmm0
000ee6b4  0f28c8                   movaps xmm1, xmm0
000ee6b7  0f827ee14101             jb 0x150c83b
000ee6bd  660f2fc6                 comisd xmm0, xmm6
000ee6c1  0f826ce14101             jb 0x150c833
000ee6c7  f20f110b                 movsd qword ptr [rbx], xmm1
000ee6cb  f20f1006                 movsd xmm0, qword ptr [rsi]
000ee6cf  488bb42488000000         mov rsi, qword ptr [rsp + 0x88]
000ee6d7  f20f5cc1                 subsd xmm0, xmm1
000ee6db  660f2ff8                 comisd xmm7, xmm0
000ee6df  0f8275e14101             jb 0x150c85a

; chunk at RVA 0xee6e5 (188 bytes)
000ee6e5  660f2fc6                 comisd xmm0, xmm6
000ee6e9  0f8263e14101             jb 0x150c852
000ee6ef  0f28c8                   movaps xmm1, xmm0
000ee6f2  eb01                     jmp 0xee6f5
000ee6f4  cc                       int3
000ee6f5  f20f10157349a502         movsd xmm2, qword ptr [rip + 0x2a54973]
000ee6fd  f20f5cca                 subsd xmm1, xmm2
000ee701  660f2ff9                 comisd xmm7, xmm1
000ee705  0f826ee14101             jb 0x150c879
000ee70b  660f2fce                 comisd xmm1, xmm6
000ee70f  0f825ce14101             jb 0x150c871
000ee715  66410f2fc8               comisd xmm1, xmm8
000ee71a  0f875f2d0500             ja 0x14147f
000ee720  0f57c0                   xorps xmm0, xmm0
000ee723  488b8424b8000000         mov rax, qword ptr [rsp + 0xb8]
000ee72b  f20f1100                 movsd qword ptr [rax], xmm0
000ee72f  f2410f100f               movsd xmm1, qword ptr [r15]
000ee734  66440f2ec1               ucomisd xmm8, xmm1
000ee739  7a06                     jp 0xee741
000ee73b  0f8481e14101             je 0x150c8c2
000ee741  f20f5ec1                 divsd xmm0, xmm1
000ee745  660f2ff8                 comisd xmm7, xmm0
000ee749  0f8296e14101             jb 0x150c8e5
000ee74f  660f2fc6                 comisd xmm0, xmm6
000ee753  0f8284e14101             jb 0x150c8dd
000ee759  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
000ee761  f20f1100                 movsd qword ptr [rax], xmm0
000ee765  f20f100b                 movsd xmm1, qword ptr [rbx]
000ee769  f2410f5e0f               divsd xmm1, qword ptr [r15]
000ee76e  660f2ff9                 comisd xmm7, xmm1
000ee772  0f828ce14101             jb 0x150c904
000ee778  660f2fce                 comisd xmm1, xmm6
000ee77c  0f827ae14101             jb 0x150c8fc
000ee782  f2410f110e               movsd qword ptr [r14], xmm1
000ee787  0f28742450               movaps xmm6, xmmword ptr [rsp + 0x50]
000ee78c  0f287c2440               movaps xmm7, xmmword ptr [rsp + 0x40]
000ee791  440f28442430             movaps xmm8, xmmword ptr [rsp + 0x30]
000ee797  4883c460                 add rsp, 0x60
000ee79b  415f                     pop r15
000ee79d  415e                     pop r14
000ee79f  5b                       pop rbx
000ee7a0  c3                       ret
