; CEsCmContext::GetClrUdxToken
; sqllang.dll, primary RVA 0x713650, 496 bytes in 1 chunk(s)

; chunk at RVA 0x713650 (496 bytes)
00713650  488bc4                   mov rax, rsp
00713653  53                       push rbx
00713654  55                       push rbp
00713655  56                       push rsi
00713656  57                       push rdi
00713657  4156                     push r14
00713659  4881ec80000000           sub rsp, 0x80
00713660  48c740c8feffffff         mov qword ptr [rax - 0x38], 0xfffffffffffffffe
00713668  498be8                   mov rbp, r8
0071366b  488bda                   mov rbx, rdx
0071366e  488bf1                   mov rsi, rcx
00713671  4533f6                   xor r14d, r14d
00713674  4c897020                 mov qword ptr [rax + 0x20], r14
00713678  4c897010                 mov qword ptr [rax + 0x10], r14
0071367c  654c8b142558000000       mov r10, qword ptr gs:[0x58]
00713685  488b05ec787b01           mov rax, qword ptr [rip + 0x17b78ec]
0071368c  448b08                   mov r9d, dword ptr [rax]
0071368f  488b05ea787b01           mov rax, qword ptr [rip + 0x17b78ea]
00713696  8b38                     mov edi, dword ptr [rax]
00713698  4b033cca                 add rdi, qword ptr [r10 + r9*8]
0071369c  488b8f00010000           mov rcx, qword ptr [rdi + 0x100]
007136a3  4885c9                   test rcx, rcx
007136a6  750d                     jne 0x7136b5
007136a8  ff15e2787b01             call qword ptr [rip + 0x17b78e2]
007136ae  488b8f00010000           mov rcx, qword ptr [rdi + 0x100]
007136b5  4489742420               mov dword ptr [rsp + 0x20], r14d
007136ba  448b0b                   mov r9d, dword ptr [rbx]
007136bd  448b431c                 mov r8d, dword ptr [rbx + 0x1c]
007136c1  488bd5                   mov rdx, rbp
007136c4  488b89e8030000           mov rcx, qword ptr [rcx + 0x3e8]
007136cb  e8d03ff8ff               call 0x6976a0
007136d0  488bf8                   mov rdi, rax
007136d3  48898424c8000000         mov qword ptr [rsp + 0xc8], rax
007136db  488d8424b8000000         lea rax, [rsp + 0xb8]
007136e3  4889442420               mov qword ptr [rsp + 0x20], rax
007136e8  448b8f10010000           mov r9d, dword ptr [rdi + 0x110]
007136ef  4c8b8708010000           mov r8, qword ptr [rdi + 0x108]
007136f6  8b5770                   mov edx, dword ptr [rdi + 0x70]
007136f9  488b0e                   mov rcx, qword ptr [rsi]
007136fc  e84fd9f9ff               call 0x6b1050
00713701  83f801                   cmp eax, 1
00713704  7510                     jne 0x713716
00713706  448b0b                   mov r9d, dword ptr [rbx]
00713709  33d2                     xor edx, edx
0071370b  448d4058                 lea r8d, [rax + 0x58]
0071370f  8bc8                     mov ecx, eax
00713711  e81a680100               call 0x729f30
00713716  488b86a8000000           mov rax, qword ptr [rsi + 0xa8]
0071371d  80b87801000000           cmp byte ptr [rax + 0x178], 0
00713724  7509                     jne 0x71372f
00713726  83782422                 cmp dword ptr [rax + 0x24], 0x22
0071372a  458bde                   mov r11d, r14d
0071372d  7506                     jne 0x713735
0071372f  41bb01000000             mov r11d, 1
00713735  8b4324                   mov eax, dword ptr [rbx + 0x24]
00713738  83c0fa                   add eax, -6
0071373b  83f807                   cmp eax, 7
0071373e  772d                     ja 0x71376d
00713740  4898                     cdqe
00713742  488d15b7c88eff           lea rdx, [rip - 0x713749]
00713749  8b8c8220387100           mov ecx, dword ptr [rdx + rax*4 + 0x713820]
00713750  4803ca                   add rcx, rdx
00713753  ffe1                     jmp rcx
00713755  41ba01000000             mov r10d, 1
0071375b  eb16                     jmp 0x713773
0071375d  41ba02000000             mov r10d, 2
00713763  eb0e                     jmp 0x713773
00713765  41ba03000000             mov r10d, 3
0071376b  eb06                     jmp 0x713773
0071376d  41ba04000000             mov r10d, 4
00713773  448b4b54                 mov r9d, dword ptr [rbx + 0x54]
00713777  41d1e9                   shr r9d, 1
0071377a  488b5338                 mov rdx, qword ptr [rbx + 0x38]
0071377e  448b435c                 mov r8d, dword ptr [rbx + 0x5c]
00713782  41d1e8                   shr r8d, 1
00713785  488b4348                 mov rax, qword ptr [rbx + 0x48]
00713789  8b4b50                   mov ecx, dword ptr [rbx + 0x50]
0071378c  d1e9                     shr ecx, 1
0071378e  488dac24b0000000         lea rbp, [rsp + 0xb0]
00713796  48896c2468               mov qword ptr [rsp + 0x68], rbp
0071379b  c744246001000000         mov dword ptr [rsp + 0x60], 1
007137a3  44895c2458               mov dword ptr [rsp + 0x58], r11d
007137a8  4489542450               mov dword ptr [rsp + 0x50], r10d
007137ad  44894c2448               mov dword ptr [rsp + 0x48], r9d
007137b2  4889542440               mov qword ptr [rsp + 0x40], rdx
007137b7  4489742438               mov dword ptr [rsp + 0x38], r14d
007137bc  4489442430               mov dword ptr [rsp + 0x30], r8d
007137c1  4889442428               mov qword ptr [rsp + 0x28], rax
007137c6  894c2420                 mov dword ptr [rsp + 0x20], ecx
007137ca  4c8b4b30                 mov r9, qword ptr [rbx + 0x30]
007137ce  4c8b8424b8000000         mov r8, qword ptr [rsp + 0xb8]
007137d6  488b5608                 mov rdx, qword ptr [rsi + 8]
007137da  488b0e                   mov rcx, qword ptr [rsi]
007137dd  e8eefef9ff               call 0x6b36d0
007137e2  83f801                   cmp eax, 1
007137e5  750e                     jne 0x7137f5
007137e7  8bd0                     mov edx, eax
007137e9  448d4032                 lea r8d, [rax + 0x32]
007137ed  33c9                     xor ecx, ecx
007137ef  e83c670100               call 0x729f30
007137f4  90                       nop
007137f5  488bcf                   mov rcx, rdi
007137f8  e87318f8ff               call 0x695070
007137fd  ba90010000               mov edx, 0x190
00713802  488bcf                   mov rcx, rdi
00713805  ff157d777b01             call qword ptr [rip + 0x17b777d]
0071380b  8b8424b0000000           mov eax, dword ptr [rsp + 0xb0]
00713812  4881c480000000           add rsp, 0x80
00713819  415e                     pop r14
0071381b  5f                       pop rdi
0071381c  5e                       pop rsi
0071381d  5d                       pop rbp
0071381e  5b                       pop rbx
0071381f  c3                       ret
00713820  55                       push rbp
