; CalcPrecisionAndScale
; sqllang.dll, primary RVA 0x13ef030, 452 bytes in 1 chunk(s)

; chunk at RVA 0x13ef030 (452 bytes)
013ef030  488bc4                   mov rax, rsp
013ef033  48895808                 mov qword ptr [rax + 8], rbx
013ef037  55                       push rbp
013ef038  56                       push rsi
013ef039  57                       push rdi
013ef03a  4883ec60                 sub rsp, 0x60
013ef03e  32db                     xor bl, bl
013ef040  4d63d8                   movsxd r11, r8d
013ef043  4032ff                   xor dil, dil
013ef046  885818                   mov byte ptr [rax + 0x18], bl
013ef049  40887820                 mov byte ptr [rax + 0x20], dil
013ef04d  498bf1                   mov rsi, r9
013ef050  488d2da90fc1fe           lea rbp, [rip - 0x13ef057]
013ef057  4c8bd1                   mov r10, rcx
013ef05a  4183fb05                 cmp r11d, 5
013ef05e  0f8726010000             ja 0x13ef18a
013ef064  468b8c9ddcf13e01         mov r9d, dword ptr [rbp + r11*4 + 0x13ef1dc]
013ef06c  4c03cd                   add r9, rbp
013ef06f  41ffe1                   jmp r9
013ef072  0faee8                   lfence
013ef075  0fb60a                   movzx ecx, byte ptr [rdx]
013ef078  8d4110                   lea eax, [rcx + 0x10]
013ef07b  3c01                     cmp al, 1
013ef07d  760b                     jbe 0x13ef08a
013ef07f  440fb64a13               movzx r9d, byte ptr [rdx + 0x13]
013ef084  0fb65a12                 movzx ebx, byte ptr [rdx + 0x12]
013ef088  eb31                     jmp 0x13ef0bb
013ef08a  0fb68429403b0202         movzx eax, byte ptr [rcx + rbp + 0x2023b40]
013ef092  440fb68c85433c0202       movzx r9d, byte ptr [rbp + rax*4 + 0x2023c43]
013ef09b  80f9f0                   cmp cl, 0xf0
013ef09e  740b                     je 0x13ef0ab
013ef0a0  80f9f1                   cmp cl, 0xf1
013ef0a3  7406                     je 0x13ef0ab
013ef0a5  0fb65a12                 movzx ebx, byte ptr [rdx + 0x12]
013ef0a9  eb10                     jmp 0x13ef0bb
013ef0ab  0fb68429403b0202         movzx eax, byte ptr [rcx + rbp + 0x2023b40]
013ef0b3  0fb69c85423c0202         movzx ebx, byte ptr [rbp + rax*4 + 0x2023c42]
013ef0bb  410fb612                 movzx edx, byte ptr [r10]
013ef0bf  8d4210                   lea eax, [rdx + 0x10]
013ef0c2  3c01                     cmp al, 1
013ef0c4  760c                     jbe 0x13ef0d2
013ef0c6  450fb64213               movzx r8d, byte ptr [r10 + 0x13]
013ef0cb  410fb65212               movzx edx, byte ptr [r10 + 0x12]
013ef0d0  eb32                     jmp 0x13ef104
013ef0d2  0fb68c2a403b0202         movzx ecx, byte ptr [rdx + rbp + 0x2023b40]
013ef0da  440fb6848d433c0202       movzx r8d, byte ptr [rbp + rcx*4 + 0x2023c43]
013ef0e3  80faf0                   cmp dl, 0xf0
013ef0e6  740c                     je 0x13ef0f4
013ef0e8  80faf1                   cmp dl, 0xf1
013ef0eb  7407                     je 0x13ef0f4
013ef0ed  410fb65212               movzx edx, byte ptr [r10 + 0x12]
013ef0f2  eb10                     jmp 0x13ef104
013ef0f4  0fb68c2a403b0202         movzx ecx, byte ptr [rdx + rbp + 0x2023b40]
013ef0fc  0fb6948d423c0202         movzx edx, byte ptr [rbp + rcx*4 + 0x2023c42]
013ef104  488d842498000000         lea rax, [rsp + 0x98]
013ef10c  418bcb                   mov ecx, r11d
013ef10f  4889442430               mov qword ptr [rsp + 0x30], rax
013ef114  488d842490000000         lea rax, [rsp + 0x90]
013ef11c  4889442428               mov qword ptr [rsp + 0x28], rax
013ef121  44884c2420               mov byte ptr [rsp + 0x20], r9b
013ef126  440fb6cb                 movzx r9d, bl
013ef12a  ff1530c7ad00             call qword ptr [rip + 0xadc730]
013ef130  0fb69c2490000000         movzx ebx, byte ptr [rsp + 0x90]
013ef138  0fb6bc2498000000         movzx edi, byte ptr [rsp + 0x98]
013ef140  eb48                     jmp 0x13ef18a
013ef142  0fb609                   movzx ecx, byte ptr [rcx]
013ef145  8d4110                   lea eax, [rcx + 0x10]
013ef148  3c01                     cmp al, 1
013ef14a  760c                     jbe 0x13ef158
013ef14c  410fb65a12               movzx ebx, byte ptr [r10 + 0x12]
013ef151  410fb67a13               movzx edi, byte ptr [r10 + 0x13]
013ef156  eb32                     jmp 0x13ef18a
013ef158  0fb68429403b0202         movzx eax, byte ptr [rcx + rbp + 0x2023b40]
013ef160  488bd1                   mov rdx, rcx
013ef163  80c110                   add cl, 0x10
013ef166  0fb69c85423c0202         movzx ebx, byte ptr [rbp + rax*4 + 0x2023c42]
013ef16e  80f901                   cmp cl, 1
013ef171  7607                     jbe 0x13ef17a
013ef173  410fb67a13               movzx edi, byte ptr [r10 + 0x13]
013ef178  eb10                     jmp 0x13ef18a
013ef17a  0fb6842a403b0202         movzx eax, byte ptr [rdx + rbp + 0x2023b40]
013ef182  0fb6bc85433c0202         movzx edi, byte ptr [rbp + rax*4 + 0x2023c43]
013ef18a  0fb616                   movzx edx, byte ptr [rsi]
013ef18d  488d4c2440               lea rcx, [rsp + 0x40]
013ef192  0fb6c3                   movzx eax, bl
013ef195  440fb6842877900502       movzx r8d, byte ptr [rax + rbp + 0x2059077]
013ef19e  e82d45c6fe               call 0x536d0
013ef1a3  0fb64601                 movzx eax, byte ptr [rsi + 1]
013ef1a7  f6d0                     not al
013ef1a9  885c2452                 mov byte ptr [rsp + 0x52], bl
013ef1ad  40887c2453               mov byte ptr [rsp + 0x53], dil
013ef1b2  a801                     test al, 1
013ef1b4  7505                     jne 0x13ef1bb
013ef1b6  804c244101               or byte ptr [rsp + 0x41], 1
013ef1bb  0f10442440               movups xmm0, xmmword ptr [rsp + 0x40]
013ef1c0  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
013ef1c8  0f104c2450               movups xmm1, xmmword ptr [rsp + 0x50]
013ef1cd  0f1106                   movups xmmword ptr [rsi], xmm0
013ef1d0  0f114e10                 movups xmmword ptr [rsi + 0x10], xmm1
013ef1d4  4883c460                 add rsp, 0x60
013ef1d8  5f                       pop rdi
013ef1d9  5e                       pop rsi
013ef1da  5d                       pop rbp
013ef1db  c3                       ret
013ef1dc  72f0                     jb 0x13ef1ce
013ef1de  3e0172f0                 add dword ptr ds:[rdx - 0x10], esi
013ef1e2  3e0172f0                 add dword ptr ds:[rdx - 0x10], esi
013ef1e6  3e0172f0                 add dword ptr ds:[rdx - 0x10], esi
013ef1ea  3e0172f0                 add dword ptr ds:[rdx - 0x10], esi
013ef1ee  3e0142f1                 add dword ptr ds:[rdx - 0xf], eax
