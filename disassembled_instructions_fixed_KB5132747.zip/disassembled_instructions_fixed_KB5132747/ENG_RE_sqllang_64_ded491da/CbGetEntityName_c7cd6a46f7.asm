; CbGetEntityName
; sqllang.dll, primary RVA 0x770a40, 1744 bytes in 1 chunk(s)

; chunk at RVA 0x770a40 (1744 bytes)
00770a40  4055                     push rbp
00770a42  56                       push rsi
00770a43  57                       push rdi
00770a44  4154                     push r12
00770a46  4155                     push r13
00770a48  4156                     push r14
00770a4a  4157                     push r15
00770a4c  4881ecf0010000           sub rsp, 0x1f0
00770a53  488d6c2440               lea rbp, [rsp + 0x40]
00770a58  48c74528feffffff         mov qword ptr [rbp + 0x28], 0xfffffffffffffffe
00770a60  48899df8010000           mov qword ptr [rbp + 0x1f8], rbx
00770a67  488b051a823602           mov rax, qword ptr [rip + 0x236821a]
00770a6e  4833c5                   xor rax, rbp
00770a71  488985a0010000           mov qword ptr [rbp + 0x1a0], rax
00770a78  498bd9                   mov rbx, r9
00770a7b  4d8bf8                   mov r15, r8
00770a7e  4c8bad10020000           mov r13, qword ptr [rbp + 0x210]
00770a85  8b7108                   mov esi, dword ptr [rcx + 8]
00770a88  448b7128                 mov r14d, dword ptr [rcx + 0x28]
00770a8c  8b4148                   mov eax, dword ptr [rcx + 0x48]
00770a8f  33ff                     xor edi, edi
00770a91  448be7                   mov r12d, edi
00770a94  8b8d18020000             mov ecx, dword ptr [rbp + 0x218]
00770a9a  83f821                   cmp eax, 0x21
00770a9d  0f8754050000             ja 0x770ff7
00770aa3  488d1556f588ff           lea rdx, [rip - 0x770aaa]
00770aaa  448b848288107700         mov r8d, dword ptr [rdx + rax*4 + 0x771088]
00770ab2  4c03c2                   add r8, rdx
00770ab5  41ffe0                   jmp r8
00770ab8  498b01                   mov rax, qword ptr [r9]
00770abb  41b101                   mov r9b, 1
00770abe  4533c0                   xor r8d, r8d
00770ac1  8bd6                     mov edx, esi
00770ac3  488bcb                   mov rcx, rbx
00770ac6  ff9068010000             call qword ptr [rax + 0x168]
00770acc  488bc8                   mov rcx, rax
00770acf  4885c0                   test rax, rax
00770ad2  0f8415050000             je 0x770fed
00770ad8  488b00                   mov rax, qword ptr [rax]
00770adb  ff10                     call qword ptr [rax]
00770add  e9f1040000               jmp 0x770fd3
00770ae2  498b01                   mov rax, qword ptr [r9]
00770ae5  41b101                   mov r9b, 1
00770ae8  4533c0                   xor r8d, r8d
00770aeb  8bd6                     mov edx, esi
00770aed  488bcb                   mov rcx, rbx
00770af0  ff90e8000000             call qword ptr [rax + 0xe8]
00770af6  ebd4                     jmp 0x770acc
00770af8  498b01                   mov rax, qword ptr [r9]
00770afb  41b101                   mov r9b, 1
00770afe  4533c0                   xor r8d, r8d
00770b01  8bd6                     mov edx, esi
00770b03  488bcb                   mov rcx, rbx
00770b06  ff90d8000000             call qword ptr [rax + 0xd8]
00770b0c  ebbe                     jmp 0x770acc
00770b0e  498b01                   mov rax, qword ptr [r9]
00770b11  41b101                   mov r9b, 1
00770b14  4533c0                   xor r8d, r8d
00770b17  8bd6                     mov edx, esi
00770b19  488bcb                   mov rcx, rbx
00770b1c  ff9068010000             call qword ptr [rax + 0x168]
00770b22  488bf0                   mov rsi, rax
00770b25  4885c0                   test rax, rax
00770b28  0f84bf040000             je 0x770fed
00770b2e  488b00                   mov rax, qword ptr [rax]
00770b31  488d9560010000           lea rdx, [rbp + 0x160]
00770b38  488bce                   mov rcx, rsi
00770b3b  ff5030                   call qword ptr [rax + 0x30]
00770b3e  80bd60010000f3           cmp byte ptr [rbp + 0x160], 0xf3
00770b45  0f85a2040000             jne 0x770fed
00770b4b  488b06                   mov rax, qword ptr [rsi]
00770b4e  488bce                   mov rcx, rsi
00770b51  ff5058                   call qword ptr [rax + 0x58]
00770b54  4c8b13                   mov r10, qword ptr [rbx]
00770b57  897c2438                 mov dword ptr [rsp + 0x38], edi
00770b5b  897c2430                 mov dword ptr [rsp + 0x30], edi
00770b5f  c644242801               mov byte ptr [rsp + 0x28], 1
00770b64  40887c2420               mov byte ptr [rsp + 0x20], dil
00770b69  4533c9                   xor r9d, r9d
00770b6c  41b001                   mov r8b, 1
00770b6f  8bd0                     mov edx, eax
00770b71  488bcb                   mov rcx, rbx
00770b74  41ff5278                 call qword ptr [r10 + 0x78]
00770b78  488bc8                   mov rcx, rax
00770b7b  4885c0                   test rax, rax
00770b7e  0f8469040000             je 0x770fed
00770b84  488b00                   mov rax, qword ptr [rax]
00770b87  ff5078                   call qword ptr [rax + 0x78]
00770b8a  488bc8                   mov rcx, rax
00770b8d  4885c0                   test rax, rax
00770b90  0f8457040000             je 0x770fed
00770b96  488b00                   mov rax, qword ptr [rax]
00770b99  4533c0                   xor r8d, r8d
00770b9c  418bd6                   mov edx, r14d
00770b9f  ff5028                   call qword ptr [rax + 0x28]
00770ba2  488bc8                   mov rcx, rax
00770ba5  4885c0                   test rax, rax
00770ba8  0f843f040000             je 0x770fed
00770bae  488b00                   mov rax, qword ptr [rax]
00770bb1  ff5010                   call qword ptr [rax + 0x10]
00770bb4  e91a040000               jmp 0x770fd3
00770bb9  498b01                   mov rax, qword ptr [r9]
00770bbc  897c2438                 mov dword ptr [rsp + 0x38], edi
00770bc0  897c2430                 mov dword ptr [rsp + 0x30], edi
00770bc4  c644242801               mov byte ptr [rsp + 0x28], 1
00770bc9  40887c2420               mov byte ptr [rsp + 0x20], dil
00770bce  4533c9                   xor r9d, r9d
00770bd1  41b001                   mov r8b, 1
00770bd4  8bd6                     mov edx, esi
00770bd6  488bcb                   mov rcx, rbx
00770bd9  ff5078                   call qword ptr [rax + 0x78]
00770bdc  4885c0                   test rax, rax
00770bdf  0f8408040000             je 0x770fed
00770be5  488b10                   mov rdx, qword ptr [rax]
00770be8  488bc8                   mov rcx, rax
00770beb  4585f6                   test r14d, r14d
00770bee  7405                     je 0x770bf5
00770bf0  ff5278                   call qword ptr [rdx + 0x78]
00770bf3  eb95                     jmp 0x770b8a
00770bf5  ff5228                   call qword ptr [rdx + 0x28]
00770bf8  e9d6030000               jmp 0x770fd3
00770bfd  498b01                   mov rax, qword ptr [r9]
00770c00  897c2438                 mov dword ptr [rsp + 0x38], edi
00770c04  897c2430                 mov dword ptr [rsp + 0x30], edi
00770c08  c644242801               mov byte ptr [rsp + 0x28], 1
00770c0d  40887c2420               mov byte ptr [rsp + 0x20], dil
00770c12  4533c9                   xor r9d, r9d
00770c15  41b001                   mov r8b, 1
00770c18  8bd6                     mov edx, esi
00770c1a  488bcb                   mov rcx, rbx
00770c1d  ff5078                   call qword ptr [rax + 0x78]
00770c20  488bc8                   mov rcx, rax
00770c23  4885c0                   test rax, rax
00770c26  0f84c1030000             je 0x770fed
00770c2c  488b00                   mov rax, qword ptr [rax]
00770c2f  ff90a8000000             call qword ptr [rax + 0xa8]
00770c35  488bd8                   mov rbx, rax
00770c38  4885c0                   test rax, rax
00770c3b  0f84ac030000             je 0x770fed
00770c41  488b00                   mov rax, qword ptr [rax]
00770c44  488bcb                   mov rcx, rbx
00770c47  ff5038                   call qword ptr [rax + 0x38]
00770c4a  443bf0                   cmp r14d, eax
00770c4d  0f879a030000             ja 0x770fed
00770c53  0faee8                   lfence
00770c56  488b03                   mov rax, qword ptr [rbx]
00770c59  418bd6                   mov edx, r14d
00770c5c  488bcb                   mov rcx, rbx
00770c5f  ff5040                   call qword ptr [rax + 0x40]
00770c62  e93bffffff               jmp 0x770ba2
00770c67  498b01                   mov rax, qword ptr [r9]
00770c6a  897c2438                 mov dword ptr [rsp + 0x38], edi
00770c6e  897c2430                 mov dword ptr [rsp + 0x30], edi
00770c72  c644242801               mov byte ptr [rsp + 0x28], 1
00770c77  40887c2420               mov byte ptr [rsp + 0x20], dil
00770c7c  4533c9                   xor r9d, r9d
00770c7f  41b001                   mov r8b, 1
00770c82  8bd6                     mov edx, esi
00770c84  488bcb                   mov rcx, rbx
00770c87  ff5078                   call qword ptr [rax + 0x78]
00770c8a  488bc8                   mov rcx, rax
00770c8d  4885c0                   test rax, rax
00770c90  0f8457030000             je 0x770fed
00770c96  488b00                   mov rax, qword ptr [rax]
00770c99  ff5078                   call qword ptr [rax + 0x78]
00770c9c  488bf0                   mov rsi, rax
00770c9f  4885c0                   test rax, rax
00770ca2  0f8445030000             je 0x770fed
00770ca8  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00770cb1  488b05c0a27501           mov rax, qword ptr [rip + 0x175a2c0]
00770cb8  8b08                     mov ecx, dword ptr [rax]
00770cba  488b05bfa27501           mov rax, qword ptr [rip + 0x175a2bf]
00770cc1  8b18                     mov ebx, dword ptr [rax]
00770cc3  48031cca                 add rbx, qword ptr [rdx + rcx*8]
00770cc7  488b8300010000           mov rax, qword ptr [rbx + 0x100]
00770cce  4885c0                   test rax, rax
00770cd1  750f                     jne 0x770ce2
00770cd3  33c9                     xor ecx, ecx
00770cd5  ff15b5a27501             call qword ptr [rip + 0x175a2b5]
00770cdb  488b8300010000           mov rax, qword ptr [rbx + 0x100]
00770ce2  488b80e8030000           mov rax, qword ptr [rax + 0x3e8]
00770ce9  48894500                 mov qword ptr [rbp], rax
00770ced  4c897d08                 mov qword ptr [rbp + 8], r15
00770cf1  48897510                 mov qword ptr [rbp + 0x10], rsi
00770cf5  48897d18                 mov qword ptr [rbp + 0x18], rdi
00770cf9  48897d20                 mov qword ptr [rbp + 0x20], rdi
00770cfd  488d4518                 lea rax, [rbp + 0x18]
00770d01  48894520                 mov qword ptr [rbp + 0x20], rax
00770d05  488d4518                 lea rax, [rbp + 0x18]
00770d09  48894518                 mov qword ptr [rbp + 0x18], rax
00770d0d  418bd6                   mov edx, r14d
00770d10  488d4d00                 lea rcx, [rbp]
00770d14  e817d10300               call 0x7ade30
00770d19  488bd8                   mov rbx, rax
00770d1c  4885c0                   test rax, rax
00770d1f  746b                     je 0x770d8c
00770d21  488b00                   mov rax, qword ptr [rax]
00770d24  488bcb                   mov rcx, rbx
00770d27  ff5038                   call qword ptr [rax + 0x38]
00770d2a  84c0                     test al, al
00770d2c  745e                     je 0x770d8c
00770d2e  488b03                   mov rax, qword ptr [rbx]
00770d31  488bcb                   mov rcx, rbx
00770d34  ff10                     call qword ptr [rax]
00770d36  488bd8                   mov rbx, rax
00770d39  0f1f8000000000           nop dword ptr [rax]
00770d40  488d4518                 lea rax, [rbp + 0x18]
00770d44  488b5520                 mov rdx, qword ptr [rbp + 0x20]
00770d48  483bd0                   cmp rdx, rax
00770d4b  0f8485020000             je 0x770fd6
00770d51  488d42f8                 lea rax, [rdx - 8]
00770d55  488bcf                   mov rcx, rdi
00770d58  4885d2                   test rdx, rdx
00770d5b  480f45c8                 cmovne rcx, rax
00770d5f  4885c9                   test rcx, rcx
00770d62  0f846e020000             je 0x770fd6
00770d68  488b5110                 mov rdx, qword ptr [rcx + 0x10]
00770d6c  488b4108                 mov rax, qword ptr [rcx + 8]
00770d70  48895008                 mov qword ptr [rax + 8], rdx
00770d74  488902                   mov qword ptr [rdx], rax
00770d77  48897910                 mov qword ptr [rcx + 0x10], rdi
00770d7b  48897908                 mov qword ptr [rcx + 8], rdi
00770d7f  ba20000000               mov edx, 0x20
00770d84  ff15fea17501             call qword ptr [rip + 0x175a1fe]
00770d8a  ebb4                     jmp 0x770d40
00770d8c  0f1f00                   nop dword ptr [rax]
00770d8f  90                       nop
00770d90  488d4518                 lea rax, [rbp + 0x18]
00770d94  488b5520                 mov rdx, qword ptr [rbp + 0x20]
00770d98  483bd0                   cmp rdx, rax
00770d9b  0f844c020000             je 0x770fed
00770da1  488d42f8                 lea rax, [rdx - 8]
00770da5  488bcf                   mov rcx, rdi
00770da8  4885d2                   test rdx, rdx
00770dab  480f45c8                 cmovne rcx, rax
00770daf  4885c9                   test rcx, rcx
00770db2  0f8435020000             je 0x770fed
00770db8  488b5110                 mov rdx, qword ptr [rcx + 0x10]
00770dbc  488b4108                 mov rax, qword ptr [rcx + 8]
00770dc0  48895008                 mov qword ptr [rax + 8], rdx
00770dc4  488902                   mov qword ptr [rdx], rax
00770dc7  48897910                 mov qword ptr [rcx + 0x10], rdi
00770dcb  48897908                 mov qword ptr [rcx + 8], rdi
00770dcf  ba20000000               mov edx, 0x20
00770dd4  ff15aea17501             call qword ptr [rip + 0x175a1ae]
00770dda  ebb4                     jmp 0x770d90
00770ddc  498b01                   mov rax, qword ptr [r9]
00770ddf  4533c0                   xor r8d, r8d
00770de2  8bd6                     mov edx, esi
00770de4  488bcb                   mov rcx, rbx
00770de7  ff9098010000             call qword ptr [rax + 0x198]
00770ded  488bc8                   mov rcx, rax
00770df0  4885c0                   test rax, rax
00770df3  0f84f4010000             je 0x770fed
00770df9  488b00                   mov rax, qword ptr [rax]
00770dfc  ff5018                   call qword ptr [rax + 0x18]
00770dff  e9cf010000               jmp 0x770fd3
00770e04  498b01                   mov rax, qword ptr [r9]
00770e07  41b101                   mov r9b, 1
00770e0a  450fb6c1                 movzx r8d, r9b
00770e0e  8bd6                     mov edx, esi
00770e10  488bcb                   mov rcx, rbx
00770e13  ff90a8020000             call qword ptr [rax + 0x2a8]
00770e19  e984fdffff               jmp 0x770ba2
00770e1e  498b01                   mov rax, qword ptr [r9]
00770e21  41b101                   mov r9b, 1
00770e24  450fb6c1                 movzx r8d, r9b
00770e28  8bd6                     mov edx, esi
00770e2a  488bcb                   mov rcx, rbx
00770e2d  ff9088020000             call qword ptr [rax + 0x288]
00770e33  e96afdffff               jmp 0x770ba2
00770e38  33d2                     xor edx, edx
00770e3a  41b828010000             mov r8d, 0x128
00770e40  488d4d30                 lea rcx, [rbp + 0x30]
00770e44  e8f30589ff               call 0x143c
00770e49  8b0424                   mov eax, dword ptr [rsp]
00770e4c  b800010000               mov eax, 0x100
00770e51  482be0                   sub rsp, rax
00770e54  488d4c2440               lea rcx, [rsp + 0x40]
00770e59  8b01                     mov eax, dword ptr [rcx]
00770e5b  48894d68                 mov qword ptr [rbp + 0x68], rcx
00770e5f  c7457800010000           mov dword ptr [rbp + 0x78], 0x100
00770e66  488b03                   mov rax, qword ptr [rbx]
00770e69  33d2                     xor edx, edx
00770e6b  488bcb                   mov rcx, rbx
00770e6e  ff90d0020000             call qword ptr [rax + 0x2d0]
00770e74  4c8b08                   mov r9, qword ptr [rax]
00770e77  4c8d4530                 lea r8, [rbp + 0x30]
00770e7b  8bd6                     mov edx, esi
00770e7d  488bc8                   mov rcx, rax
00770e80  41ff5118                 call qword ptr [r9 + 0x18]
00770e84  488b7d68                 mov rdi, qword ptr [rbp + 0x68]
00770e88  448b6578                 mov r12d, dword ptr [rbp + 0x78]
00770e8c  e951010000               jmp 0x770fe2
00770e91  498b01                   mov rax, qword ptr [r9]
00770e94  4533c0                   xor r8d, r8d
00770e97  8bd6                     mov edx, esi
00770e99  488bcb                   mov rcx, rbx
00770e9c  ff90f8010000             call qword ptr [rax + 0x1f8]
00770ea2  e925fcffff               jmp 0x770acc
00770ea7  498b01                   mov rax, qword ptr [r9]
00770eaa  4533c0                   xor r8d, r8d
00770ead  8bd6                     mov edx, esi
00770eaf  488bcb                   mov rcx, rbx
00770eb2  ff90e8010000             call qword ptr [rax + 0x1e8]
00770eb8  e90ffcffff               jmp 0x770acc
00770ebd  498b01                   mov rax, qword ptr [r9]
00770ec0  4533c0                   xor r8d, r8d
00770ec3  8bd6                     mov edx, esi
00770ec5  488bcb                   mov rcx, rbx
00770ec8  ff90d8010000             call qword ptr [rax + 0x1d8]
00770ece  e9f9fbffff               jmp 0x770acc
00770ed3  498b01                   mov rax, qword ptr [r9]
00770ed6  4533c0                   xor r8d, r8d
00770ed9  8bd6                     mov edx, esi
00770edb  488bcb                   mov rcx, rbx
00770ede  ff9078010000             call qword ptr [rax + 0x178]
00770ee4  e9dc000000               jmp 0x770fc5
00770ee9  498b01                   mov rax, qword ptr [r9]
00770eec  4533c0                   xor r8d, r8d
00770eef  8bd6                     mov edx, esi
00770ef1  488bcb                   mov rcx, rbx
00770ef4  ff9068020000             call qword ptr [rax + 0x268]
00770efa  488bc8                   mov rcx, rax
00770efd  4885c0                   test rax, rax
00770f00  0f84e7000000             je 0x770fed
00770f06  488b00                   mov rax, qword ptr [rax]
00770f09  ff5008                   call qword ptr [rax + 8]
00770f0c  e9c2000000               jmp 0x770fd3
00770f11  498b01                   mov rax, qword ptr [r9]
00770f14  4533c0                   xor r8d, r8d
00770f17  8bd6                     mov edx, esi
00770f19  488bcb                   mov rcx, rbx
00770f1c  ff9038020000             call qword ptr [rax + 0x238]
00770f22  ebd6                     jmp 0x770efa
00770f24  498b01                   mov rax, qword ptr [r9]
00770f27  41b101                   mov r9b, 1
00770f2a  450fb6c1                 movzx r8d, r9b
00770f2e  8bd6                     mov edx, esi
00770f30  488bcb                   mov rcx, rbx
00770f33  ff9090030000             call qword ptr [rax + 0x390]
00770f39  e98efbffff               jmp 0x770acc
00770f3e  498b01                   mov rax, qword ptr [r9]
00770f41  4533c0                   xor r8d, r8d
00770f44  8bd6                     mov edx, esi
00770f46  488bcb                   mov rcx, rbx
00770f49  ff9028030000             call qword ptr [rax + 0x328]
00770f4f  e978fbffff               jmp 0x770acc
00770f54  498b01                   mov rax, qword ptr [r9]
00770f57  4533c0                   xor r8d, r8d
00770f5a  8bd6                     mov edx, esi
00770f5c  488bcb                   mov rcx, rbx
00770f5f  ff90b8030000             call qword ptr [rax + 0x3b8]
00770f65  e962fbffff               jmp 0x770acc
00770f6a  498b01                   mov rax, qword ptr [r9]
00770f6d  4533c0                   xor r8d, r8d
00770f70  8bd6                     mov edx, esi
00770f72  488bcb                   mov rcx, rbx
00770f75  ff90e0030000             call qword ptr [rax + 0x3e0]
00770f7b  e922fcffff               jmp 0x770ba2
00770f80  498b01                   mov rax, qword ptr [r9]
00770f83  4533c0                   xor r8d, r8d
00770f86  8bd6                     mov edx, esi
00770f88  488bcb                   mov rcx, rbx
00770f8b  ff9008020000             call qword ptr [rax + 0x208]
00770f91  e964ffffff               jmp 0x770efa
00770f96  498b01                   mov rax, qword ptr [r9]
00770f99  4533c0                   xor r8d, r8d
00770f9c  8bd6                     mov edx, esi
00770f9e  488bcb                   mov rcx, rbx
00770fa1  ff9080050000             call qword ptr [rax + 0x580]
00770fa7  e920fbffff               jmp 0x770acc
00770fac  498b01                   mov rax, qword ptr [r9]
00770faf  40887c2420               mov byte ptr [rsp + 0x20], dil
00770fb4  4533c9                   xor r9d, r9d
00770fb7  41b001                   mov r8b, 1
00770fba  8bd6                     mov edx, esi
00770fbc  488bcb                   mov rcx, rbx
00770fbf  ff90b8010000             call qword ptr [rax + 0x1b8]
00770fc5  4885c0                   test rax, rax
00770fc8  488bc8                   mov rcx, rax
00770fcb  7420                     je 0x770fed
00770fcd  488b00                   mov rax, qword ptr [rax]
00770fd0  ff5020                   call qword ptr [rax + 0x20]
00770fd3  488bd8                   mov rbx, rax
00770fd6  4885db                   test rbx, rbx
00770fd9  7416                     je 0x770ff1
00770fdb  488b3b                   mov rdi, qword ptr [rbx]
00770fde  448b6308                 mov r12d, dword ptr [rbx + 8]
00770fe2  8b8d18020000             mov ecx, dword ptr [rbp + 0x218]
00770fe8  443be1                   cmp r12d, ecx
00770feb  760a                     jbe 0x770ff7
00770fed  33c0                     xor eax, eax
00770fef  eb6c                     jmp 0x77105d
00770ff1  8b8d18020000             mov ecx, dword ptr [rbp + 0x218]
00770ff7  0faee8                   lfence
00770ffa  418bdc                   mov ebx, r12d
00770ffd  8bf1                     mov esi, ecx
00770fff  4585e4                   test r12d, r12d
00771002  7456                     je 0x77105a
00771004  4d85ed                   test r13, r13
00771007  750e                     jne 0x771017
00771009  ff1569bb7501             call qword ptr [rip + 0x175bb69]
0077100f  c70016000000             mov dword ptr [rax], 0x16
00771015  eb3d                     jmp 0x771054
00771017  4885ff                   test rdi, rdi
0077101a  7415                     je 0x771031
0077101c  483bf3                   cmp rsi, rbx
0077101f  7210                     jb 0x771031
00771021  4c8bc3                   mov r8, rbx
00771024  488bd7                   mov rdx, rdi
00771027  498bcd                   mov rcx, r13
0077102a  e8d10389ff               call 0x1400
0077102f  eb29                     jmp 0x77105a
00771031  4c8bc6                   mov r8, rsi
00771034  33d2                     xor edx, edx
00771036  498bcd                   mov rcx, r13
00771039  e8fe0389ff               call 0x143c
0077103e  4885ff                   test rdi, rdi
00771041  74c6                     je 0x771009
00771043  483bf3                   cmp rsi, rbx
00771046  7312                     jae 0x77105a
00771048  ff152abb7501             call qword ptr [rip + 0x175bb2a]
0077104e  c70022000000             mov dword ptr [rax], 0x22
00771054  ff152ebb7501             call qword ptr [rip + 0x175bb2e]
0077105a  418bc4                   mov eax, r12d
0077105d  488b8da0010000           mov rcx, qword ptr [rbp + 0x1a0]
00771064  4833cd                   xor rcx, rbp
00771067  e8040089ff               call 0x1070
0077106c  488b9df8010000           mov rbx, qword ptr [rbp + 0x1f8]
00771073  488da5b0010000           lea rsp, [rbp + 0x1b0]
0077107a  415f                     pop r15
0077107c  415e                     pop r14
0077107e  415d                     pop r13
00771080  415c                     pop r12
00771082  5f                       pop rdi
00771083  5e                       pop rsi
00771084  5d                       pop rbp
00771085  c3                       ret
00771086  90                       nop
00771087  90                       nop
00771088  ed                       in eax, dx
00771089  0f77                     emms
0077108b  00b90b7700fd             add byte ptr [rcx - 0x2ff88f5], bh
00771091  0b7700                   or esi, dword ptr [rdi]
00771094  f8                       clc
00771095  0a7700                   or dh, byte ptr [rdi]
00771098  e20a                     loop 0x7710a4
0077109a  7700                     ja 0x77109c
0077109c  dc0d7700b80a             fmul qword ptr [rip + 0xab80077]
007710a2  7700                     ja 0x7710a4
007710a4  670c77                   or al, 0x77
007710a7  000e                     add byte ptr [rsi], cl
007710a9  0b7700                   or esi, dword ptr [rdi]
007710ac  f70f7700d30e             test dword ptr [rdi], 0xed30077
007710b2  7700                     ja 0x7710b4
007710b4  f70f7700f70f             test dword ptr [rdi], 0xff70077
007710ba  7700                     ja 0x7710bc
007710bc  f70f7700f70f             test dword ptr [rdi], 0xff70077
007710c2  7700                     ja 0x7710c4
007710c4  bd0e7700a7               mov ebp, 0xa700770e
