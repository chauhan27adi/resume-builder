; CAppDomain::Release
; sqllang.dll, primary RVA 0x6b0920, 316 bytes in 1 chunk(s)

; chunk at RVA 0x6b0920 (316 bytes)
006b0920  4053                     push rbx
006b0922  4883ec30                 sub rsp, 0x30
006b0926  488b81d0010000           mov rax, qword ptr [rcx + 0x1d0]
006b092d  488bd9                   mov rbx, rcx
006b0930  4889442448               mov qword ptr [rsp + 0x48], rax
006b0935  488b442448               mov rax, qword ptr [rsp + 0x48]
006b093a  4889442440               mov qword ptr [rsp + 0x40], rax
006b093f  8b442440                 mov eax, dword ptr [rsp + 0x40]
006b0943  ffc8                     dec eax
006b0945  89442440                 mov dword ptr [rsp + 0x40], eax
006b0949  488b442448               mov rax, qword ptr [rsp + 0x48]
006b094e  488b542440               mov rdx, qword ptr [rsp + 0x40]
006b0953  f0480fb191d0010000       lock cmpxchg qword ptr [rcx + 0x1d0], rdx
006b095c  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
006b0961  483bc8                   cmp rcx, rax
006b0964  7449                     je 0x6b09af
006b0966  0f0d8bd0010000           prefetchw byte ptr [rbx + 0x1d0]
006b096d  0f1f00                   nop dword ptr [rax]
006b0970  f390                     pause
006b0972  488b83d0010000           mov rax, qword ptr [rbx + 0x1d0]
006b0979  4889442448               mov qword ptr [rsp + 0x48], rax
006b097e  488b442448               mov rax, qword ptr [rsp + 0x48]
006b0983  4889442440               mov qword ptr [rsp + 0x40], rax
006b0988  8b442440                 mov eax, dword ptr [rsp + 0x40]
006b098c  ffc8                     dec eax
006b098e  89442440                 mov dword ptr [rsp + 0x40], eax
006b0992  488b442448               mov rax, qword ptr [rsp + 0x48]
006b0997  488b4c2440               mov rcx, qword ptr [rsp + 0x40]
006b099c  f0480fb18bd0010000       lock cmpxchg qword ptr [rbx + 0x1d0], rcx
006b09a5  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
006b09aa  483bc8                   cmp rcx, rax
006b09ad  75c1                     jne 0x6b0970
006b09af  488b442440               mov rax, qword ptr [rsp + 0x40]
006b09b4  4889442448               mov qword ptr [rsp + 0x48], rax
006b09b9  8b442448                 mov eax, dword ptr [rsp + 0x48]
006b09bd  85c0                     test eax, eax
006b09bf  7573                     jne 0x6b0a34
006b09c1  8b44244c                 mov eax, dword ptr [rsp + 0x4c]
006b09c5  83f802                   cmp eax, 2
006b09c8  746a                     je 0x6b0a34
006b09ca  8b44244c                 mov eax, dword ptr [rsp + 0x4c]
006b09ce  83f806                   cmp eax, 6
006b09d1  7f61                     jg 0x6b0a34
006b09d3  4863442444               movsxd rax, dword ptr [rsp + 0x44]
006b09d8  83f806                   cmp eax, 6
006b09db  771d                     ja 0x6b09fa
006b09dd  488d151cf694ff           lea rdx, [rip - 0x6b09e4]
006b09e4  8b8c82400a6b00           mov ecx, dword ptr [rdx + rax*4 + 0x6b0a40]
006b09eb  4803ca                   add rcx, rdx
006b09ee  ffe1                     jmp rcx
006b09f0  488bcb                   mov rcx, rbx
006b09f3  e848edffff               call 0x6af740
006b09f8  eb2b                     jmp 0x6b0a25
006b09fa  488d05277baa01           lea rax, [rip + 0x1aa7b27]
006b0a01  41b9f9090000             mov r9d, 0x9f9
006b0a07  4c8d05c215e601           lea r8, [rip + 0x1e615c2]
006b0a0e  4889442420               mov qword ptr [rsp + 0x20], rax
006b0a13  488d152640e601           lea rdx, [rip + 0x1e64026]
006b0a1a  b901000000               mov ecx, 1
006b0a1f  ff1553a48101             call qword ptr [rip + 0x181a453]
006b0a25  488b8bd8000000           mov rcx, qword ptr [rbx + 0xd8]
006b0a2c  488bd3                   mov rdx, rbx
006b0a2f  e8bc520100               call 0x6c5cf0
006b0a34  8b442440                 mov eax, dword ptr [rsp + 0x40]
006b0a38  4883c430                 add rsp, 0x30
006b0a3c  5b                       pop rbx
006b0a3d  c3                       ret
006b0a3e  6690                     nop
006b0a40  250a6b00f0               and eax, 0xf0006b0a
006b0a45  096b00                   or dword ptr [rbx], ebp
006b0a48  fa                       cli
006b0a49  096b00                   or dword ptr [rbx], ebp
006b0a4c  f0096b00                 lock or dword ptr [rbx], ebp
006b0a50  f0096b00                 lock or dword ptr [rbx], ebp
006b0a54  250a6b0025               and eax, 0x25006b0a
006b0a59  0a6b00                   or ch, byte ptr [rbx]
