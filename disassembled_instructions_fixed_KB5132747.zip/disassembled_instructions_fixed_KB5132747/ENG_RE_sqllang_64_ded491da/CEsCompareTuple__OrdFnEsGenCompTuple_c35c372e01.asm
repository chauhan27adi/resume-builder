; CEsCompareTuple::OrdFnEsGenCompTuple
; sqllang.dll, primary RVA 0x2dfeb0, 1140 bytes in 3 chunk(s)

; chunk at RVA 0x2dfeb0 (59 bytes)
002dfeb0  48895c2410               mov qword ptr [rsp + 0x10], rbx
002dfeb5  4889742418               mov qword ptr [rsp + 0x18], rsi
002dfeba  48897c2420               mov qword ptr [rsp + 0x20], rdi
002dfebf  4156                     push r14
002dfec1  4883ec30                 sub rsp, 0x30
002dfec5  498bf0                   mov rsi, r8
002dfec8  488bda                   mov rbx, rdx
002dfecb  488bf9                   mov rdi, rcx
002dfece  4c8bf2                   mov r14, rdx
002dfed1  4d85c0                   test r8, r8
002dfed4  7407                     je 0x2dfedd
002dfed6  41c70000000000           mov dword ptr [r8], 0
002dfedd  440fb609                 movzx r9d, byte ptr [rcx]
002dfee1  4180f9f0                 cmp r9b, 0xf0
002dfee5  0f84abc35a00             je 0x88c296

; chunk at RVA 0x2dfeeb (154 bytes)
002dfeeb  4c897c2440               mov qword ptr [rsp + 0x40], r15
002dfef0  baffff0000               mov edx, 0xffff
002dfef5  4c8d3d0401d2ff           lea r15, [rip - 0x2dfefc]
002dfefc  430fb68c39403b0202       movzx ecx, byte ptr [r9 + r15 + 0x2023b40]
002dff05  4280bc39d889050200       cmp byte ptr [rcx + r15 + 0x20589d8], 0
002dff0e  0f85ad2b0000             jne 0x2e2ac1
002dff14  0fb60b                   movzx ecx, byte ptr [rbx]
002dff17  420fb68439403b0202       movzx eax, byte ptr [rcx + r15 + 0x2023b40]
002dff20  4280bc38d889050200       cmp byte ptr [rax + r15 + 0x20589d8], 0
002dff29  0f85a22b0000             jne 0x2e2ad1
002dff2f  4180f9f0                 cmp r9b, 0xf0
002dff33  0f8472c35a00             je 0x88c2ab
002dff39  0fb6d1                   movzx edx, cl
002dff3c  410fb6c9                 movzx ecx, r9b
002dff40  ff1592bcbe01             call qword ptr [rip + 0x1bebc92]
002dff46  84c0                     test al, al
002dff48  0f8487c35a00             je 0x88c2d5
002dff4e  0fb607                   movzx eax, byte ptr [rdi]
002dff51  83c0de                   add eax, -0x22
002dff54  3dce000000               cmp eax, 0xce
002dff59  0f8744c75a00             ja 0x88c6a3
002dff5f  4898                     cdqe
002dff61  410fb6840700002e00       movzx eax, byte ptr [r15 + rax + 0x2e0000]
002dff6a  418b8c879cff2d00         mov ecx, dword ptr [r15 + rax*4 + 0x2dff9c]
002dff72  4903cf                   add rcx, r15
002dff75  ffe1                     jmp rcx
002dff77  cc                       int3
002dff78  b868020000               mov eax, 0x268
002dff7d  eb01                     jmp 0x2dff80
002dff7f  cc                       int3
002dff80  4c8b7c2440               mov r15, qword ptr [rsp + 0x40]

; chunk at RVA 0x2dff85 (927 bytes)
002dff85  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
002dff8a  488b742450               mov rsi, qword ptr [rsp + 0x50]
002dff8f  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
002dff94  4883c430                 add rsp, 0x30
002dff98  415e                     pop r14
002dff9a  c3                       ret
002dff9b  90                       nop
002dff9c  a3c68800a215330085       movabs dword ptr [0x85003315a20088c6], eax
002dffa5  ed                       in eax, dx
002dffa6  3300                     xor eax, dword ptr [rax]
002dffa8  7a15                     jp 0x2dffbf
002dffaa  3300                     xor eax, dword ptr [rax]
002dffac  841533008e15             test byte ptr [rip + 0x158e0033], dl
002dffb2  3300                     xor eax, dword ptr [rax]
002dffb4  2403                     and al, 3
002dffb6  2e002e                   add byte ptr cs:[rsi], ch
002dffb9  032e                     add ebp, dword ptr [rsi]
002dffbb  0078ff                   add byte ptr [rax - 1], bh
002dffbe  2d007bed33               sub eax, 0x33ed7b00
002dffc3  0018                     add byte ptr [rax], bl
002dffc5  0517005ded               add eax, 0xed5d0017
002dffca  3300                     xor eax, dword ptr [rax]
002dffcc  71ed                     jno 0x2dffbb
002dffce  3300                     xor eax, dword ptr [rax]
002dffd0  22051700ac15             and al, byte ptr [rip + 0x15ac0017]
002dffd6  3300                     xor eax, dword ptr [rax]
002dffd8  48ed                     in eax, dx
002dffda  3300                     xor eax, dword ptr [rax]
002dffdc  67ed                     in eax, dx
002dffde  3300                     xor eax, dword ptr [rax]
