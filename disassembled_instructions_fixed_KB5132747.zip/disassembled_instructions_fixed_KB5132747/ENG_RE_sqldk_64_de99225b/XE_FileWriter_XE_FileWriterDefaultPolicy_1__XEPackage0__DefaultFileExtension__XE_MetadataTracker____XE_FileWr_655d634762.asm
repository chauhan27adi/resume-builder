; XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker>::~XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker>
; sqldk.dll, primary RVA 0x1be310, 309 bytes in 1 chunk(s)

; chunk at RVA 0x1be310 (309 bytes)
001be310  48894c2408               mov qword ptr [rsp + 8], rcx
001be315  53                       push rbx
001be316  56                       push rsi
001be317  57                       push rdi
001be318  4883ec30                 sub rsp, 0x30
001be31c  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001be325  488bf9                   mov rdi, rcx
001be328  488d0509ce0b00           lea rax, [rip + 0xbce09]
001be32f  488901                   mov qword ptr [rcx], rax
001be332  488db168060000           lea rsi, [rcx + 0x668]
001be339  48833e00                 cmp qword ptr [rsi], 0
001be33d  7464                     je 0x1be3a3
001be33f  33db                     xor ebx, ebx
001be341  488b4128                 mov rax, qword ptr [rcx + 0x28]
001be345  3918                     cmp dword ptr [rax], ebx
001be347  7635                     jbe 0x1be37e
001be349  0f1f00                   nop dword ptr [rax]
001be34c  0f1f4000                 nop dword ptr [rax]
001be350  488d0cdd00000000         lea rcx, [rbx*8]
001be358  488b06                   mov rax, qword ptr [rsi]
001be35b  4c8b0401                 mov r8, qword ptr [rcx + rax]
001be35f  4d85c0                   test r8, r8
001be362  7410                     je 0x1be374
001be364  4d8b8088020000           mov r8, qword ptr [r8 + 0x288]
001be36b  488b1401                 mov rdx, qword ptr [rcx + rax]
001be36f  e8bc060000               call 0x1bea30
001be374  ffc3                     inc ebx
001be376  488b4728                 mov rax, qword ptr [rdi + 0x28]
001be37a  3b18                     cmp ebx, dword ptr [rax]
001be37c  72d2                     jb 0x1be350
001be37e  4883bf8807000000         cmp qword ptr [rdi + 0x788], 0
001be386  741b                     je 0x1be3a3
001be388  4c8b8770060000           mov r8, qword ptr [rdi + 0x670]
001be38f  4d8b8088020000           mov r8, qword ptr [r8 + 0x288]
001be396  488b9770060000           mov rdx, qword ptr [rdi + 0x670]
001be39d  e88e060000               call 0x1bea30
001be3a2  90                       nop
001be3a3  488b8fa0070000           mov rcx, qword ptr [rdi + 0x7a0]
001be3aa  4883f9ff                 cmp rcx, -1
001be3ae  7407                     je 0x1be3b7
001be3b0  ff151a6e1500             call qword ptr [rip + 0x156e1a]
001be3b6  90                       nop
001be3b7  488d8768070000           lea rax, [rdi + 0x768]
001be3be  4889442458               mov qword ptr [rsp + 0x58], rax
001be3c3  488d5810                 lea rbx, [rax + 0x10]
001be3c7  48895c2460               mov qword ptr [rsp + 0x60], rbx
001be3cc  488b0b                   mov rcx, qword ptr [rbx]
001be3cf  e8acaae8ff               call 0x48e80
001be3d4  48c70300000000           mov qword ptr [rbx], 0
001be3db  488bcb                   mov rcx, rbx
001be3de  e8fda7e8ff               call 0x48be0
001be3e3  90                       nop
001be3e4  4889742468               mov qword ptr [rsp + 0x68], rsi
001be3e9  488b0e                   mov rcx, qword ptr [rsi]
001be3ec  e8ef1f0000               call 0x1c03e0
001be3f1  48c70600000000           mov qword ptr [rsi], 0
001be3f8  488b0e                   mov rcx, qword ptr [rsi]
001be3fb  4885c9                   test rcx, rcx
001be3fe  742c                     je 0x1be42c
001be400  488d59f8                 lea rbx, [rcx - 8]
001be404  4c8d0d0595e8ff           lea r9, [rip - 0x176afb]
001be40b  4c8b03                   mov r8, qword ptr [rbx]
001be40e  ba08000000               mov edx, 8
001be413  e80864e6ff               call 0x24820
001be418  488b13                   mov rdx, qword ptr [rbx]
001be41b  488d14d508000000         lea rdx, [rdx*8 + 8]
001be423  488bcb                   mov rcx, rbx
001be426  e8058be4ff               call 0x6f30
001be42b  90                       nop
001be42c  488d4f10                 lea rcx, [rdi + 0x10]
001be430  48894c2450               mov qword ptr [rsp + 0x50], rcx
001be435  4883c118                 add rcx, 0x18
001be439  4883c430                 add rsp, 0x30
001be43d  5f                       pop rdi
001be43e  5e                       pop rsi
001be43f  5b                       pop rbx
001be440  e98b95e8ff               jmp 0x479d0
