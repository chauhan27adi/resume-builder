; `MemoryClerkInternal::OpenSharedMemory'::`1'::dtor$0
; sqldk.dll, primary RVA 0x228860, 53 bytes in 1 chunk(s)

; chunk at RVA 0x228860 (53 bytes)
00228860  4055                     push rbp
00228862  4883ec30                 sub rsp, 0x30
00228866  488bea                   mov rbp, rdx
00228869  c644242806               mov byte ptr [rsp + 0x28], 6
0022886e  8b4570                   mov eax, dword ptr [rbp + 0x70]
00228871  89442420                 mov dword ptr [rsp + 0x20], eax
00228875  4c8d0d64130700           lea r9, [rip + 0x71364]
0022887c  41b801000000             mov r8d, 1
00228882  488b5538                 mov rdx, qword ptr [rbp + 0x38]
00228886  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0022888a  e881e6ddff               call 0x6f10
0022888f  4883c430                 add rsp, 0x30
00228893  5d                       pop rbp
00228894  c3                       ret
