; MemObjCache<CMemObj>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13ef60, 121 bytes in 1 chunk(s)

; chunk at RVA 0x13ef60 (121 bytes)
0013ef60  48894c2408               mov qword ptr [rsp + 8], rcx
0013ef65  57                       push rdi
0013ef66  4883ec30                 sub rsp, 0x30
0013ef6a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013ef73  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013ef78  8bda                     mov ebx, edx
0013ef7a  488bf9                   mov rdi, rcx
0013ef7d  488d058c8c1000           lea rax, [rip + 0x108c8c]
0013ef84  488901                   mov qword ptr [rcx], rax
0013ef87  488d05da7f1000           lea rax, [rip + 0x107fda]
0013ef8e  488901                   mov qword ptr [rcx], rax
0013ef91  488d0570821000           lea rax, [rip + 0x108270]
0013ef98  488901                   mov qword ptr [rcx], rax
0013ef9b  4883c138                 add rcx, 0x38
0013ef9f  e84c26edff               call 0x115f0
0013efa4  90                       nop
0013efa5  488d4f30                 lea rcx, [rdi + 0x30]
0013efa9  e84226edff               call 0x115f0
0013efae  90                       nop
0013efaf  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013efb6  83e305                   and ebx, 5
0013efb9  80fb05                   cmp bl, 5
0013efbc  750d                     jne 0x13efcb
0013efbe  ba78010000               mov edx, 0x178
0013efc3  488bcf                   mov rcx, rdi
0013efc6  e84520ecff               call 0x1010
0013efcb  488bc7                   mov rax, rdi
0013efce  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013efd3  4883c430                 add rsp, 0x30
0013efd7  5f                       pop rdi
0013efd8  c3                       ret
