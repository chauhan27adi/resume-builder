; AutoSpinlockHolder<26,1,268435713>::~AutoSpinlockHolder<26,1,268435713>
; sqldk.dll, primary RVA 0x958c0, 27 bytes in 1 chunk(s)

; chunk at RVA 0x958c0 (27 bytes)
000958c0  48894c2408               mov qword ptr [rsp + 8], rcx
000958c5  4883ec38                 sub rsp, 0x38
000958c9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000958d2  4883c438                 add rsp, 0x38
000958d6  e905aef8ff               jmp 0x206e0
