; MemObjCache<CMemThread<CMemLargePageObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13ebf0, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13ebf0 (79 bytes)
0013ebf0  48894c2408               mov qword ptr [rsp + 8], rcx
0013ebf5  57                       push rdi
0013ebf6  4883ec30                 sub rsp, 0x30
0013ebfa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013ec03  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013ec08  8bda                     mov ebx, edx
0013ec0a  488bf9                   mov rdi, rcx
0013ec0d  488d05b4961000           lea rax, [rip + 0x1096b4]
0013ec14  488901                   mov qword ptr [rcx], rax
0013ec17  e8044bfdff               call 0x113720
0013ec1c  83e305                   and ebx, 5
0013ec1f  80fb05                   cmp bl, 5
0013ec22  750d                     jne 0x13ec31
0013ec24  baf0020000               mov edx, 0x2f0
0013ec29  488bcf                   mov rcx, rdi
0013ec2c  e8df23ecff               call 0x1010
0013ec31  488bc7                   mov rax, rdi
0013ec34  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013ec39  4883c430                 add rsp, 0x30
0013ec3d  5f                       pop rdi
0013ec3e  c3                       ret
