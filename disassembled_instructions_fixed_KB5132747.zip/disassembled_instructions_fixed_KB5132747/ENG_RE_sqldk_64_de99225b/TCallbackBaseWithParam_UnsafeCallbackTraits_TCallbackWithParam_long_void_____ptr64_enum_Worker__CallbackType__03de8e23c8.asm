; TCallbackBaseWithParam<UnsafeCallbackTraits<TCallbackWithParam<long,void * __ptr64,enum Worker::CallbackType,NullType,NullType> >,long,void * __ptr64,enum Worker::CallbackType,NullType,NullType>::~TCallbackBaseWithParam<UnsafeCallbackTraits<TCallbackWithParam<long,void * __ptr64,enum Worker::CallbackType,NullType,NullType> >,long,void * __ptr64,enum Worker::CallbackType,NullType,NullType>
; sqldk.dll, primary RVA 0x8d9d0, 50 bytes in 1 chunk(s)

; chunk at RVA 0x8d9d0 (50 bytes)
0008d9d0  48894c2408               mov qword ptr [rsp + 8], rcx
0008d9d5  4883ec18                 sub rsp, 0x18
0008d9d9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
0008d9e1  488b5108                 mov rdx, qword ptr [rcx + 8]
0008d9e5  4885d2                   test rdx, rdx
0008d9e8  7413                     je 0x8d9fd
0008d9ea  488b01                   mov rax, qword ptr [rcx]
0008d9ed  48895008                 mov qword ptr [rax + 8], rdx
0008d9f1  488902                   mov qword ptr [rdx], rax
0008d9f4  33c0                     xor eax, eax
0008d9f6  48894108                 mov qword ptr [rcx + 8], rax
0008d9fa  488901                   mov qword ptr [rcx], rax
0008d9fd  4883c418                 add rsp, 0x18
0008da01  c3                       ret
