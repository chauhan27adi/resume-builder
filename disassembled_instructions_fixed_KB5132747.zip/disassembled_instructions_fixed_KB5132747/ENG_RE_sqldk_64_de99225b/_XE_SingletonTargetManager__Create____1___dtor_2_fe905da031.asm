; `XE_SingletonTargetManager::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x235e74, 56 bytes in 1 chunk(s)

; chunk at RVA 0x235e74 (56 bytes)
00235e74  4055                     push rbp
00235e76  4883ec30                 sub rsp, 0x30
00235e7a  488bea                   mov rbp, rdx
00235e7d  c644242806               mov byte ptr [rsp + 0x28], 6
00235e82  8b4578                   mov eax, dword ptr [rbp + 0x78]
00235e85  89442420                 mov dword ptr [rsp + 0x20], eax
00235e89  4c8d0d004b0700           lea r9, [rip + 0x74b00]
00235e90  41b801000000             mov r8d, 1
00235e96  488b5570                 mov rdx, qword ptr [rbp + 0x70]
00235e9a  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
00235ea1  e84a40faff               call 0x1d9ef0
00235ea6  4883c430                 add rsp, 0x30
00235eaa  5d                       pop rbp
00235eab  c3                       ret
