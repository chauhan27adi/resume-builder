; DbgDataBuff::`vector deleting destructor'
; sqldk.dll, primary RVA 0xb8470, 67 bytes in 1 chunk(s)

; chunk at RVA 0xb8470 (67 bytes)
000b8470  48894c2408               mov qword ptr [rsp + 8], rcx
000b8475  57                       push rdi
000b8476  4883ec30                 sub rsp, 0x30
000b847a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000b8483  48895c2448               mov qword ptr [rsp + 0x48], rbx
000b8488  8bda                     mov ebx, edx
000b848a  488bf9                   mov rdi, rcx
000b848d  ff1535131800             call qword ptr [rip + 0x181335]
000b8493  f6c301                   test bl, 1
000b8496  740d                     je 0xb84a5
000b8498  ba68010000               mov edx, 0x168
000b849d  488bcf                   mov rcx, rdi
000b84a0  e88beaf4ff               call 0x6f30
000b84a5  488bc7                   mov rax, rdi
000b84a8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000b84ad  4883c430                 add rsp, 0x30
000b84b1  5f                       pop rdi
000b84b2  c3                       ret
