; AutoWorkerWaitContext::~AutoWorkerWaitContext
; sqldk.dll, primary RVA 0x95200, 60 bytes in 3 chunk(s)

; chunk at RVA 0x95200 (16 bytes)
00095200  4883ec28                 sub rsp, 0x28
00095204  488b01                   mov rax, qword ptr [rcx]
00095207  4885c0                   test rax, rax
0009520a  742b                     je 0x95237
0009520c  488b4008                 mov rax, qword ptr [rax + 8]

; chunk at RVA 0x95210 (39 bytes)
00095210  48895c2420               mov qword ptr [rsp + 0x20], rbx
00095215  81a020030000ffff7fff     and dword ptr [rax + 0x320], 0xff7fffff
0009521f  488b19                   mov rbx, qword ptr [rcx]
00095222  488bcb                   mov rcx, rbx
00095225  e8b6dff6ff               call 0x31e0
0009522a  33c0                     xor eax, eax
0009522c  894318                   mov dword ptr [rbx + 0x18], eax
0009522f  488903                   mov qword ptr [rbx], rax
00095232  488b5c2420               mov rbx, qword ptr [rsp + 0x20]

; chunk at RVA 0x95237 (5 bytes)
00095237  4883c428                 add rsp, 0x28
0009523b  c3                       ret
