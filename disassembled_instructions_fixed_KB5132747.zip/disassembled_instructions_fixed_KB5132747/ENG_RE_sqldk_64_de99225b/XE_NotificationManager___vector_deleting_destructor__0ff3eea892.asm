; XE_NotificationManager::`vector deleting destructor'
; sqldk.dll, primary RVA 0x1e1040, 63 bytes in 1 chunk(s)

; chunk at RVA 0x1e1040 (63 bytes)
001e1040  48894c2408               mov qword ptr [rsp + 8], rcx
001e1045  53                       push rbx
001e1046  4883ec30                 sub rsp, 0x30
001e104a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001e1053  488bd9                   mov rbx, rcx
001e1056  488d05e3970c00           lea rax, [rip + 0xc97e3]
001e105d  488901                   mov qword ptr [rcx], rax
001e1060  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
001e1067  f6c201                   test dl, 1
001e106a  740a                     je 0x1e1076
001e106c  ba18000000               mov edx, 0x18
001e1071  e8ba5ee2ff               call 0x6f30
001e1076  488bc3                   mov rax, rbx
001e1079  4883c430                 add rsp, 0x30
001e107d  5b                       pop rbx
001e107e  c3                       ret
