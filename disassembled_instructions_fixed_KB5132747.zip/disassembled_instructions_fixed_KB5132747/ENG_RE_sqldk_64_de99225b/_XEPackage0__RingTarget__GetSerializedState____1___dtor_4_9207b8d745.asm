; `XEPackage0::RingTarget::GetSerializedState'::`1'::dtor$4
; sqldk.dll, primary RVA 0x231dd1, 31 bytes in 1 chunk(s)

; chunk at RVA 0x231dd1 (31 bytes)
00231dd1  4055                     push rbp
00231dd3  4883ec20                 sub rsp, 0x20
00231dd7  488bea                   mov rbp, rdx
00231dda  4533c0                   xor r8d, r8d
00231ddd  488b5560                 mov rdx, qword ptr [rbp + 0x60]
00231de1  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00231de5  e826f2dcff               call 0x1010
00231dea  4883c420                 add rsp, 0x20
00231dee  5d                       pop rbp
00231def  c3                       ret
