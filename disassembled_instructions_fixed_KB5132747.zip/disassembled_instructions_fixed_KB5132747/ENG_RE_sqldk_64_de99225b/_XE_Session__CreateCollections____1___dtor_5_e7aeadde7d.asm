; `XE_Session::CreateCollections'::`1'::dtor$5
; sqldk.dll, primary RVA 0x234ca4, 59 bytes in 1 chunk(s)

; chunk at RVA 0x234ca4 (59 bytes)
00234ca4  4055                     push rbp
00234ca6  4883ec30                 sub rsp, 0x30
00234caa  488bea                   mov rbp, rdx
00234cad  c644242806               mov byte ptr [rsp + 0x28], 6
00234cb2  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00234cb8  89442420                 mov dword ptr [rsp + 0x20], eax
00234cbc  4c8d0db55b0700           lea r9, [rip + 0x75bb5]
00234cc3  41b801000000             mov r8d, 1
00234cc9  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00234cd0  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00234cd4  e81752faff               call 0x1d9ef0
00234cd9  4883c430                 add rsp, 0x30
00234cdd  5d                       pop rbp
00234cde  c3                       ret
