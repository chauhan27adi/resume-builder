; MemObjCache<CMemDbg<CMemLargePageObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13eb30, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13eb30 (79 bytes)
0013eb30  48894c2408               mov qword ptr [rsp + 8], rcx
0013eb35  57                       push rdi
0013eb36  4883ec30                 sub rsp, 0x30
0013eb3a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013eb43  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013eb48  8bda                     mov ebx, edx
0013eb4a  488bf9                   mov rdi, rcx
0013eb4d  488d05249a1000           lea rax, [rip + 0x109a24]
0013eb54  488901                   mov qword ptr [rcx], rax
0013eb57  e8e44d0300               call 0x173940
0013eb5c  83e305                   and ebx, 5
0013eb5f  80fb05                   cmp bl, 5
0013eb62  750d                     jne 0x13eb71
0013eb64  bae8050000               mov edx, 0x5e8
0013eb69  488bcf                   mov rcx, rdi
0013eb6c  e89f24ecff               call 0x1010
0013eb71  488bc7                   mov rax, rdi
0013eb74  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013eb79  4883c430                 add rsp, 0x30
0013eb7d  5f                       pop rdi
0013eb7e  c3                       ret
