; `SOS_Node::CreateMultipleTasksInternal'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21d4e0, 66 bytes in 1 chunk(s)

; chunk at RVA 0x21d4e0 (66 bytes)
0021d4e0  4055                     push rbp
0021d4e2  4883ec30                 sub rsp, 0x30
0021d4e6  488bea                   mov rbp, rdx
0021d4e9  488b5578                 mov rdx, qword ptr [rbp + 0x78]
0021d4ed  4881c2780e0000           add rdx, 0xe78
0021d4f4  c644242806               mov byte ptr [rsp + 0x28], 6
0021d4f9  8b4560                   mov eax, dword ptr [rbp + 0x60]
0021d4fc  89442420                 mov dword ptr [rsp + 0x20], eax
0021d500  4c8d0d69cd0500           lea r9, [rip + 0x5cd69]
0021d507  41b801000000             mov r8d, 1
0021d50d  488b12                   mov rdx, qword ptr [rdx]
0021d510  488b8dc8000000           mov rcx, qword ptr [rbp + 0xc8]
0021d517  e8f499deff               call 0x6f10
0021d51c  4883c430                 add rsp, 0x30
0021d520  5d                       pop rbp
0021d521  c3                       ret
