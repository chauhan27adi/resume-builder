; `ISOSHostImpl::CreateTaskCallback'::`1'::dtor$1
; sqldk.dll, primary RVA 0x229bc4, 59 bytes in 1 chunk(s)

; chunk at RVA 0x229bc4 (59 bytes)
00229bc4  4055                     push rbp
00229bc6  4883ec30                 sub rsp, 0x30
00229bca  488bea                   mov rbp, rdx
00229bcd  c644242806               mov byte ptr [rsp + 0x28], 6
00229bd2  8b8598000000             mov eax, dword ptr [rbp + 0x98]
00229bd8  89442420                 mov dword ptr [rsp + 0x20], eax
00229bdc  4c8d0dfdff0600           lea r9, [rip + 0x6fffd]
00229be3  41b801000000             mov r8d, 1
00229be9  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
00229bf0  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00229bf4  e817d3ddff               call 0x6f10
00229bf9  4883c430                 add rsp, 0x30
00229bfd  5d                       pop rbp
00229bfe  c3                       ret
