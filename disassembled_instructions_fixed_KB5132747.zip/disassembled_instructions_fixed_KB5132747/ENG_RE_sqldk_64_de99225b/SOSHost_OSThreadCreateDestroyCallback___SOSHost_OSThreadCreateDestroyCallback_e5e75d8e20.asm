; SOSHost_OSThreadCreateDestroyCallback::~SOSHost_OSThreadCreateDestroyCallback
; sqldk.dll, primary RVA 0x1607e0, 39 bytes in 1 chunk(s)

; chunk at RVA 0x1607e0 (39 bytes)
001607e0  48894c2408               mov qword ptr [rsp + 8], rcx
001607e5  4883ec38                 sub rsp, 0x38
001607e9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001607f2  4883791800               cmp qword ptr [rcx + 0x18], 0
001607f7  7409                     je 0x160802
001607f9  4883c438                 add rsp, 0x38
001607fd  e9ae9af0ff               jmp 0x6a2b0
00160802  4883c438                 add rsp, 0x38
00160806  c3                       ret
