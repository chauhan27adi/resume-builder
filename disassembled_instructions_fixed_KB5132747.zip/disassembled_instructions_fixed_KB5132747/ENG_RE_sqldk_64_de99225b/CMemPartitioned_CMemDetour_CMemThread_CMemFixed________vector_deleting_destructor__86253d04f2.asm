; CMemPartitioned<CMemDetour<CMemThread<CMemFixed> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce830, 129 bytes in 1 chunk(s)

; chunk at RVA 0xce830 (129 bytes)
000ce830  48894c2408               mov qword ptr [rsp + 8], rcx
000ce835  57                       push rdi
000ce836  4883ec30                 sub rsp, 0x30
000ce83a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce843  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce848  8bda                     mov ebx, edx
000ce84a  488bf9                   mov rdi, rcx
000ce84d  488d05ace51700           lea rax, [rip + 0x17e5ac]
000ce854  488901                   mov qword ptr [rcx], rax
000ce857  488d81e8020000           lea rax, [rcx + 0x2e8]
000ce85e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce863  488d0dd6b21600           lea rcx, [rip + 0x16b2d6]
000ce86a  488908                   mov qword ptr [rax], rcx
000ce86d  488d05ecee1700           lea rax, [rip + 0x17eeec]
000ce874  488907                   mov qword ptr [rdi], rax
000ce877  488d8720020000           lea rax, [rdi + 0x220]
000ce87e  4889442458               mov qword ptr [rsp + 0x58], rax
000ce883  488908                   mov qword ptr [rax], rcx
000ce886  488bcf                   mov rcx, rdi
000ce889  e8b2dd0200               call 0xfc640
000ce88e  83e305                   and ebx, 5
000ce891  80fb05                   cmp bl, 5
000ce894  750d                     jne 0xce8a3
000ce896  ba20030000               mov edx, 0x320
000ce89b  488bcf                   mov rcx, rdi
000ce89e  e86d27f3ff               call 0x1010
000ce8a3  488bc7                   mov rax, rdi
000ce8a6  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce8ab  4883c430                 add rsp, 0x30
000ce8af  5f                       pop rdi
000ce8b0  c3                       ret
