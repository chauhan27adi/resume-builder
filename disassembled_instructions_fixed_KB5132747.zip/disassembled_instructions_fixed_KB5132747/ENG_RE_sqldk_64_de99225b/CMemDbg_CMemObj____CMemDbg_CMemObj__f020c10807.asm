; CMemDbg<CMemObj>::~CMemDbg<CMemObj>
; sqldk.dll, primary RVA 0x16e5d0, 99 bytes in 1 chunk(s)

; chunk at RVA 0x16e5d0 (99 bytes)
0016e5d0  48894c2408               mov qword ptr [rsp + 8], rcx
0016e5d5  53                       push rbx
0016e5d6  4883ec30                 sub rsp, 0x30
0016e5da  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0016e5e3  488bd9                   mov rbx, rcx
0016e5e6  488d05b3de0d00           lea rax, [rip + 0xddeb3]
0016e5ed  488901                   mov qword ptr [rcx], rax
0016e5f0  488d05c1760f00           lea rax, [rip + 0xf76c1]
0016e5f7  48898138010000           mov qword ptr [rcx + 0x138], rax
0016e5fe  488d0563890d00           lea rax, [rip + 0xd8963]
0016e605  488901                   mov qword ptr [rcx], rax
0016e608  488d05f98b0d00           lea rax, [rip + 0xd8bf9]
0016e60f  488901                   mov qword ptr [rcx], rax
0016e612  4883c138                 add rcx, 0x38
0016e616  e8d52feaff               call 0x115f0
0016e61b  90                       nop
0016e61c  488d4b30                 lea rcx, [rbx + 0x30]
0016e620  e8cb2feaff               call 0x115f0
0016e625  90                       nop
0016e626  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0016e62d  4883c430                 add rsp, 0x30
0016e631  5b                       pop rbx
0016e632  c3                       ret
