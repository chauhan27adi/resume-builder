; CMemPartitioned<CMemThread<CMemDbg<CMemLargePageObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcead0, 133 bytes in 1 chunk(s)

; chunk at RVA 0xcead0 (133 bytes)
000cead0  48894c2408               mov qword ptr [rsp + 8], rcx
000cead5  57                       push rdi
000cead6  4883ec30                 sub rsp, 0x30
000ceada  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ceae3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ceae8  8bda                     mov ebx, edx
000ceaea  488bf9                   mov rdi, rcx
000ceaed  488d05fcda1700           lea rax, [rip + 0x17dafc]
000ceaf4  488901                   mov qword ptr [rcx], rax
000ceaf7  488d8100070000           lea rax, [rcx + 0x700]
000ceafe  4889442450               mov qword ptr [rsp + 0x50], rax
000ceb03  488d0d36b01600           lea rcx, [rip + 0x16b036]
000ceb0a  488908                   mov qword ptr [rax], rcx
000ceb0d  488d056c9e1700           lea rax, [rip + 0x179e6c]
000ceb14  488907                   mov qword ptr [rdi], rax
000ceb17  488d8798050000           lea rax, [rdi + 0x598]
000ceb1e  4889442458               mov qword ptr [rsp + 0x58], rax
000ceb23  48894830                 mov qword ptr [rax + 0x30], rcx
000ceb27  488908                   mov qword ptr [rax], rcx
000ceb2a  488bcf                   mov rcx, rdi
000ceb2d  e80e4e0a00               call 0x173940
000ceb32  83e305                   and ebx, 5
000ceb35  80fb05                   cmp bl, 5
000ceb38  750d                     jne 0xceb47
000ceb3a  ba38070000               mov edx, 0x738
000ceb3f  488bcf                   mov rcx, rdi
000ceb42  e8c924f3ff               call 0x1010
000ceb47  488bc7                   mov rax, rdi
000ceb4a  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ceb4f  4883c430                 add rsp, 0x30
000ceb53  5f                       pop rdi
000ceb54  c3                       ret
