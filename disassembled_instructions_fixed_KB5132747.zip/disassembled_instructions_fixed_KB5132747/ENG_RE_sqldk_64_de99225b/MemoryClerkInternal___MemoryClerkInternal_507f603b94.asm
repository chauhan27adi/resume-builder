; MemoryClerkInternal::~MemoryClerkInternal
; sqldk.dll, primary RVA 0x154d60, 75 bytes in 1 chunk(s)

; chunk at RVA 0x154d60 (75 bytes)
00154d60  48894c2408               mov qword ptr [rsp + 8], rcx
00154d65  53                       push rbx
00154d66  4883ec30                 sub rsp, 0x30
00154d6a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00154d73  488bd9                   mov rbx, rcx
00154d76  488d057b1f0f00           lea rax, [rip + 0xf1f7b]
00154d7d  488901                   mov qword ptr [rcx], rax
00154d80  488d0531fe1000           lea rax, [rip + 0x10fe31]
00154d87  48894140                 mov qword ptr [rcx + 0x40], rax
00154d8b  488b8918060000           mov rcx, qword ptr [rcx + 0x618]
00154d92  4885c9                   test rcx, rcx
00154d95  7407                     je 0x154d9e
00154d97  488b01                   mov rax, qword ptr [rcx]
00154d9a  ff5010                   call qword ptr [rax + 0x10]
00154d9d  90                       nop
00154d9e  488bcb                   mov rcx, rbx
00154da1  4883c430                 add rsp, 0x30
00154da5  5b                       pop rbx
00154da6  e9b57fedff               jmp 0x2cd60
