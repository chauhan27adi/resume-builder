; CMemObj::~CMemObj
; sqldk.dll, primary RVA 0x89510, 75 bytes in 1 chunk(s)

; chunk at RVA 0x89510 (75 bytes)
00089510  48894c2408               mov qword ptr [rsp + 8], rcx
00089515  53                       push rbx
00089516  4883ec30                 sub rsp, 0x30
0008951a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00089523  488bd9                   mov rbx, rcx
00089526  488d053bda1b00           lea rax, [rip + 0x1bda3b]
0008952d  488901                   mov qword ptr [rcx], rax
00089530  488d05d1dc1b00           lea rax, [rip + 0x1bdcd1]
00089537  488901                   mov qword ptr [rcx], rax
0008953a  4883c138                 add rcx, 0x38
0008953e  e8ad80f8ff               call 0x115f0
00089543  90                       nop
00089544  488d4b30                 lea rcx, [rbx + 0x30]
00089548  e8a380f8ff               call 0x115f0
0008954d  90                       nop
0008954e  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
00089555  4883c430                 add rsp, 0x30
00089559  5b                       pop rbx
0008955a  c3                       ret
