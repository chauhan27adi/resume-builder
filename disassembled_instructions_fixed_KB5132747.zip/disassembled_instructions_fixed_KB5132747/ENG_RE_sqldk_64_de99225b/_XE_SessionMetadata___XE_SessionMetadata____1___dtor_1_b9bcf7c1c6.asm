; `XE_SessionMetadata::~XE_SessionMetadata'::`1'::dtor$1
; sqldk.dll, primary RVA 0x216690, 42 bytes in 1 chunk(s)

; chunk at RVA 0x216690 (42 bytes)
00216690  4055                     push rbp
00216692  4883ec20                 sub rsp, 0x20
00216696  488bea                   mov rbp, rdx
00216699  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0021669d  4c8d0d4c14e3ff           lea r9, [rip - 0x1cebb4]
002166a4  41b800040000             mov r8d, 0x400
002166aa  ba08000000               mov edx, 8
002166af  e86ce1e0ff               call 0x24820
002166b4  4883c420                 add rsp, 0x20
002166b8  5d                       pop rbp
002166b9  c3                       ret
