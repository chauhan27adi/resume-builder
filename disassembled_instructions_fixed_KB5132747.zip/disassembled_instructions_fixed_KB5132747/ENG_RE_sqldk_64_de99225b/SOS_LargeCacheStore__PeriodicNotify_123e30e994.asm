; SOS_LargeCacheStore::PeriodicNotify
; sqldk.dll, primary RVA 0x17280, 491 bytes in 5 chunk(s)

; chunk at RVA 0x17280 (31 bytes)
00017280  488bc4                   mov rax, rsp
00017283  57                       push rdi
00017284  4156                     push r14
00017286  4157                     push r15
00017288  4883ec50                 sub rsp, 0x50
0001728c  f6416801                 test byte ptr [rcx + 0x68], 1
00017290  4d8bf9                   mov r15, r9
00017293  4d8bf0                   mov r14, r8
00017296  488bf9                   mov rdi, rcx
00017299  0f85ea000000             jne 0x17389

; chunk at RVA 0x1729f (46 bytes)
0001729f  48895808                 mov qword ptr [rax + 8], rbx
000172a3  488d99289afeff           lea rbx, [rcx - 0x165d8]
000172aa  48896810                 mov qword ptr [rax + 0x10], rbp
000172ae  48897018                 mov qword ptr [rax + 0x18], rsi
000172b2  85d2                     test edx, edx
000172b4  0f84d9000000             je 0x17393
000172ba  83fa01                   cmp edx, 1
000172bd  0f85b4000000             jne 0x17377
000172c3  488b942490000000         mov rdx, qword ptr [rsp + 0x90]
000172cb  33ed                     xor ebp, ebp

; chunk at RVA 0x172cd (170 bytes)
000172cd  0f2970d8                 movaps xmmword ptr [rax - 0x28], xmm6
000172d1  488b02                   mov rax, qword ptr [rdx]
000172d4  48894330                 mov qword ptr [rbx + 0x30], rax
000172d8  488b4208                 mov rax, qword ptr [rdx + 8]
000172dc  48894338                 mov qword ptr [rbx + 0x38], rax
000172e0  488b4210                 mov rax, qword ptr [rdx + 0x10]
000172e4  48894340                 mov qword ptr [rbx + 0x40], rax
000172e8  896b48                   mov dword ptr [rbx + 0x48], ebp
000172eb  498b01                   mov rax, qword ptr [r9]
000172ee  f20f105130               movsd xmm2, qword ptr [rcx + 0x30]
000172f3  48894138                 mov qword ptr [rcx + 0x38], rax
000172f7  488bcb                   mov rcx, rbx
000172fa  f2410f1009               movsd xmm1, qword ptr [r9]
000172ff  e8dc060000               call 0x179e0
00017304  488d979893feff           lea rdx, [rdi - 0x16c68]
0001730b  48894740                 mov qword ptr [rdi + 0x40], rax
0001730f  488d8aa0070000           lea rcx, [rdx + 0x7a0]
00017316  4885c9                   test rcx, rcx
00017319  7408                     je 0x17323
0001731b  4533c0                   xor r8d, r8d
0001731e  e8cdf7feff               call 0x6af0
00017323  488b07                   mov rax, qword ptr [rdi]
00017326  488bcf                   mov rcx, rdi
00017329  ff5018                   call qword ptr [rax + 0x18]
0001732c  488bc8                   mov rcx, rax
0001732f  0f57f6                   xorps xmm6, xmm6
00017332  4885c0                   test rax, rax
00017335  0f88bd051600             js 0x1778f8
0001733b  f2480f2af0               cvtsi2sd xmm6, rax
00017340  eb01                     jmp 0x17343
00017342  cc                       int3
00017343  f20f59354dce2400         mulsd xmm6, qword ptr [rip + 0x24ce4d]
0001734b  0f57c0                   xorps xmm0, xmm0
0001734e  f2480f2a87284cffff       cvtsi2sd xmm0, qword ptr [rdi - 0xb3d8]
00017357  660f2fc6                 comisd xmm0, xmm6
0001735b  0f87af051600             ja 0x177910
00017361  488b87284cffff           mov rax, qword ptr [rdi - 0xb3d8]
00017368  0f28742440               movaps xmm6, xmmword ptr [rsp + 0x40]
0001736d  488987f8fdffff           mov qword ptr [rdi - 0x208], rax
00017374  eb01                     jmp 0x17377
00017376  cc                       int3

; chunk at RVA 0x17389 (10 bytes)
00017389  4883c450                 add rsp, 0x50
0001738d  415f                     pop r15
0001738f  415e                     pop r14
00017391  5f                       pop rdi
00017392  c3                       ret

; chunk at RVA 0x17393 (234 bytes)
00017393  be01000000               mov esi, 1
00017398  498bd6                   mov rdx, r14
0001739b  448bc6                   mov r8d, esi
0001739e  488bcb                   mov rcx, rbx
000173a1  e8ea000000               call 0x17490
000173a6  4881c388b10000           add rbx, 0xb188
000173ad  8bd6                     mov edx, esi
000173af  488bcb                   mov rcx, rbx
000173b2  e849050000               call 0x17900
000173b7  33ed                     xor ebp, ebp
000173b9  85c0                     test eax, eax
000173bb  7539                     jne 0x173f6
000173bd  498b4e08                 mov rcx, qword ptr [r14 + 8]
000173c1  488b4318                 mov rax, qword ptr [rbx + 0x18]
000173c5  493bce                   cmp rcx, r14
000173c8  f20f1025d8cd2400         movsd xmm4, qword ptr [rip + 0x24cdd8]
000173d0  480f44cd                 cmove rcx, rbp
000173d4  488908                   mov qword ptr [rax], rcx
000173d7  896b04                   mov dword ptr [rbx + 4], ebp
000173da  660f1f440000             nop word ptr [rax + rax]
000173e0  488b5318                 mov rdx, qword ptr [rbx + 0x18]
000173e4  48392a                   cmp qword ptr [rdx], rbp
000173e7  0f85c4051600             jne 0x1779b1
000173ed  397304                   cmp dword ptr [rbx + 4], esi
000173f0  0f8774061600             ja 0x177a6a
000173f6  488b87089afeff           mov rax, qword ptr [rdi - 0x165f8]
000173fd  0f57c9                   xorps xmm1, xmm1
00017400  488bcb                   mov rcx, rbx
00017403  8b4028                   mov eax, dword ptr [rax + 0x28]
00017406  c1e002                   shl eax, 2
00017409  f2480f2ac8               cvtsi2sd xmm1, rax
0001740e  e85d050000               call 0x17970
00017413  0f57c9                   xorps xmm1, xmm1
00017416  f20f114730               movsd qword ptr [rdi + 0x30], xmm0
0001741b  660f2fc1                 comisd xmm0, xmm1
0001741f  7745                     ja 0x17466
00017421  488b87284cffff           mov rax, qword ptr [rdi - 0xb3d8]
00017428  0f57d2                   xorps xmm2, xmm2
0001742b  480387f8fdffff           add rax, qword ptr [rdi - 0x208]
00017432  4899                     cqo
00017434  482bc2                   sub rax, rdx
00017437  488b97f0fdffff           mov rdx, qword ptr [rdi - 0x210]
0001743e  48d1f8                   sar rax, 1
00017441  488bc8                   mov rcx, rax
00017444  4885d2                   test rdx, rdx
00017447  0f884c061600             js 0x177a99
0001744d  f2480f2ad2               cvtsi2sd xmm2, rdx
00017452  eb01                     jmp 0x17455
00017454  cc                       int3
00017455  f20f5e1543cd2400         divsd xmm2, qword ptr [rip + 0x24cd43]
0001745d  4885c9                   test rcx, rcx
00017460  0f854e061600             jne 0x177ab4
00017466  f2410f110f               movsd qword ptr [r15], xmm1
0001746b  f20f114f28               movsd qword ptr [rdi + 0x28], xmm1
00017470  4889aff0fdffff           mov qword ptr [rdi - 0x210], rbp
00017477  e9fbfeffff               jmp 0x17377
0001747c  cc                       int3
