; `ISOSHostImpl::CreateCountingSemaphore'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22b504, 56 bytes in 1 chunk(s)

; chunk at RVA 0x22b504 (56 bytes)
0022b504  4055                     push rbp
0022b506  4883ec30                 sub rsp, 0x30
0022b50a  488bea                   mov rbp, rdx
0022b50d  c644242806               mov byte ptr [rsp + 0x28], 6
0022b512  8b4530                   mov eax, dword ptr [rbp + 0x30]
0022b515  89442420                 mov dword ptr [rsp + 0x20], eax
0022b519  4c8d0dc0e60600           lea r9, [rip + 0x6e6c0]
0022b520  41b801000000             mov r8d, 1
0022b526  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0022b52d  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0022b531  e8dab9ddff               call 0x6f10
0022b536  4883c430                 add rsp, 0x30
0022b53a  5d                       pop rbp
0022b53b  c3                       ret
