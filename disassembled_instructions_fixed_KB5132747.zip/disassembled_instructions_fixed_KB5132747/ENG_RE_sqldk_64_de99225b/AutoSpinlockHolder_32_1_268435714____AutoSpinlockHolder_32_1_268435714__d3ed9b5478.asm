; AutoSpinlockHolder<32,1,268435714>::~AutoSpinlockHolder<32,1,268435714>
; sqldk.dll, primary RVA 0x6bdb0, 111 bytes in 1 chunk(s)

; chunk at RVA 0x6bdb0 (111 bytes)
0006bdb0  48894c2408               mov qword ptr [rsp + 8], rcx
0006bdb5  57                       push rdi
0006bdb6  4883ec30                 sub rsp, 0x30
0006bdba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0006bdc3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0006bdc8  488bd9                   mov rbx, rcx
0006bdcb  488b39                   mov rdi, qword ptr [rcx]
0006bdce  4885ff                   test rdi, rdi
0006bdd1  7441                     je 0x6be14
0006bdd3  83790800                 cmp dword ptr [rcx + 8], 0
0006bdd7  743b                     je 0x6be14
0006bdd9  803de1962a0000           cmp byte ptr [rip + 0x2a96e1], 0
0006bde0  7427                     je 0x6be09
0006bde2  ff1560dc1c00             call qword ptr [rip + 0x1cdc60]
0006bde8  448bc0                   mov r8d, eax
0006bdeb  b867666666               mov eax, 0x66666667
0006bdf0  41f7e8                   imul r8d
0006bdf3  d1fa                     sar edx, 1
0006bdf5  8bca                     mov ecx, edx
0006bdf7  c1e91f                   shr ecx, 0x1f
0006bdfa  03d1                     add edx, ecx
0006bdfc  8d0c92                   lea ecx, [rdx + rdx*4]
0006bdff  443bc1                   cmp r8d, ecx
0006be02  7505                     jne 0x6be09
0006be04  e8f7720000               call 0x73100
0006be09  33c0                     xor eax, eax
0006be0b  488907                   mov qword ptr [rdi], rax
0006be0e  488903                   mov qword ptr [rbx], rax
0006be11  894308                   mov dword ptr [rbx + 8], eax
0006be14  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0006be19  4883c430                 add rsp, 0x30
0006be1d  5f                       pop rdi
0006be1e  c3                       ret
