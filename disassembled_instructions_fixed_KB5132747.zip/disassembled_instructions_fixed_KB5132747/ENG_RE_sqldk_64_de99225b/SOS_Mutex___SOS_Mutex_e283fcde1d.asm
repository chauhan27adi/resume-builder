; SOS_Mutex::~SOS_Mutex
; sqldk.dll, primary RVA 0x55a50, 32 bytes in 1 chunk(s)

; chunk at RVA 0x55a50 (32 bytes)
00055a50  48894c2408               mov qword ptr [rsp + 8], rcx
00055a55  4883ec18                 sub rsp, 0x18
00055a59  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00055a61  488d05d8401e00           lea rax, [rip + 0x1e40d8]
00055a68  488901                   mov qword ptr [rcx], rax
00055a6b  4883c418                 add rsp, 0x18
00055a6f  c3                       ret
