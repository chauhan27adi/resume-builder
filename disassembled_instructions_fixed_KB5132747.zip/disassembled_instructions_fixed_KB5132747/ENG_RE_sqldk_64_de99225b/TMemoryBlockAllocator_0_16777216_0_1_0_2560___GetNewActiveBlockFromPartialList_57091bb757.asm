; TMemoryBlockAllocator<0,16777216,0,1,0,2560>::GetNewActiveBlockFromPartialList
; sqldk.dll, primary RVA 0x1ea30, 292 bytes in 1 chunk(s)

; chunk at RVA 0x1ea30 (292 bytes)
0001ea30  488bc4                   mov rax, rsp
0001ea33  44884018                 mov byte ptr [rax + 0x18], r8b
0001ea37  48894808                 mov qword ptr [rax + 8], rcx
0001ea3b  55                       push rbp
0001ea3c  56                       push rsi
0001ea3d  57                       push rdi
0001ea3e  4154                     push r12
0001ea40  4155                     push r13
0001ea42  4156                     push r14
0001ea44  4157                     push r15
0001ea46  488d68a9                 lea rbp, [rax - 0x57]
0001ea4a  4881ec90000000           sub rsp, 0x90
0001ea51  48c7450ffeffffff         mov qword ptr [rbp + 0xf], 0xfffffffffffffffe
0001ea59  48895810                 mov qword ptr [rax + 0x10], rbx
0001ea5d  4c8bf9                   mov r15, rcx
0001ea60  33ff                     xor edi, edi
0001ea62  8bdf                     mov ebx, edi
0001ea64  48895daf                 mov qword ptr [rbp - 0x51], rbx
0001ea68  488d45b7                 lea rax, [rbp - 0x49]
0001ea6c  488945bf                 mov qword ptr [rbp - 0x41], rax
0001ea70  488d45b7                 lea rax, [rbp - 0x49]
0001ea74  488945b7                 mov qword ptr [rbp - 0x49], rax
0001ea78  440fb7ea                 movzx r13d, dx
0001ea7c  4983c502                 add r13, 2
0001ea80  49c1e507                 shl r13, 7
0001ea84  4c03e9                   add r13, rcx
0001ea87  4c896df7                 mov qword ptr [rbp - 9], r13
0001ea8b  448d6706                 lea r12d, [rdi + 6]
0001ea8f  440fb6757f               movzx r14d, byte ptr [rbp + 0x7f]
0001ea94  4584c9                   test r9b, r9b
0001ea97  0f8476430700             je 0x92e13
0001ea9d  8d7701                   lea esi, [rdi + 1]
0001eaa0  eb01                     jmp 0x1eaa3
0001eaa2  cc                       int3
0001eaa3  48895daf                 mov qword ptr [rbp - 0x51], rbx
0001eaa7  83fe02                   cmp esi, 2
0001eaaa  0f820fffffff             jb 0x1e9bf
0001eab0  4885db                   test rbx, rbx
0001eab3  0f85a7000000             jne 0x1eb60
0001eab9  eb01                     jmp 0x1eabc
0001eabb  cc                       int3
0001eabc  807d6f00                 cmp byte ptr [rbp + 0x6f], 0
0001eac0  0f849a000000             je 0x1eb60
0001eac6  498d7530                 lea rsi, [r13 + 0x30]
0001eaca  488975ff                 mov qword ptr [rbp - 1], rsi
0001eace  897d07                   mov dword ptr [rbp + 7], edi
0001ead1  488bdf                   mov rbx, rdi
0001ead4  658b042548000000         mov eax, dword ptr gs:[0x48]
0001eadc  448bf0                   mov r14d, eax
0001eadf  8b06                     mov eax, dword ptr [rsi]
0001eae1  85c0                     test eax, eax
0001eae3  0f8507ab0000             jne 0x295f0
0001eae9  33c0                     xor eax, eax
0001eaeb  f04c0fb136               lock cmpxchg qword ptr [rsi], r14
0001eaf0  8bc7                     mov eax, edi
0001eaf2  0f94c0                   sete al
0001eaf5  85c0                     test eax, eax
0001eaf7  0f84f3aa0000             je 0x295f0
0001eafd  c7450701000000           mov dword ptr [rbp + 7], 1
0001eb04  448bff                   mov r15d, edi
0001eb07  4983c538                 add r13, 0x38
0001eb0b  4c8b65f7                 mov r12, qword ptr [rbp - 9]
0001eb0f  488b5daf                 mov rbx, qword ptr [rbp - 0x51]
0001eb13  0f1f4000                 nop dword ptr [rax]
0001eb17  660f1f840000000000       nop word ptr [rax + rax]
0001eb20  4183ff01                 cmp r15d, 1
0001eb24  731d                     jae 0x1eb43
0001eb26  498b5d08                 mov rbx, qword ptr [r13 + 8]
0001eb2a  493bdd                   cmp rbx, r13
0001eb2d  0f858d460700             jne 0x931c0
0001eb33  488b5daf                 mov rbx, qword ptr [rbp - 0x51]
0001eb37  41ffc7                   inc r15d
0001eb3a  4983c510                 add r13, 0x10
0001eb3e  4885db                   test rbx, rbx
0001eb41  74dd                     je 0x1eb20
0001eb43  488d4dff                 lea rcx, [rbp - 1]
0001eb47  e8f4dbffff               call 0x1c740
0001eb4c  660f1f0400               nop word ptr [rax + rax]
0001eb51  eb0d                     jmp 0x1eb60
0001eb53  cc                       int3
