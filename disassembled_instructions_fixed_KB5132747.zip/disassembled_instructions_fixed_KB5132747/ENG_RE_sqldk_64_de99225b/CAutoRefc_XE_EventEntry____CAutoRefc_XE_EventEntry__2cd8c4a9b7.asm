; CAutoRefc<XE_EventEntry>::~CAutoRefc<XE_EventEntry>
; sqldk.dll, primary RVA 0x1ee680, 80 bytes in 1 chunk(s)

; chunk at RVA 0x1ee680 (80 bytes)
001ee680  4053                     push rbx
001ee682  4883ec20                 sub rsp, 0x20
001ee686  488b19                   mov rbx, qword ptr [rcx]
001ee689  4885db                   test rbx, rbx
001ee68c  743c                     je 0x1ee6ca
001ee68e  b8ffffffff               mov eax, 0xffffffff
001ee693  f00fc14310               lock xadd dword ptr [rbx + 0x10], eax
001ee698  83f801                   cmp eax, 1
001ee69b  752d                     jne 0x1ee6ca
001ee69d  48837b0800               cmp qword ptr [rbx + 8], 0
001ee6a2  740c                     je 0x1ee6b0
001ee6a4  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001ee6a8  488bd3                   mov rdx, rbx
001ee6ab  e8c0a6ffff               call 0x1e8d70
001ee6b0  488bcb                   mov rcx, rbx
001ee6b3  e848550000               call 0x1f3c00
001ee6b8  baa8000000               mov edx, 0xa8
001ee6bd  488bcb                   mov rcx, rbx
001ee6c0  4883c420                 add rsp, 0x20
001ee6c4  5b                       pop rbx
001ee6c5  e96688e1ff               jmp 0x6f30
001ee6ca  4883c420                 add rsp, 0x20
001ee6ce  5b                       pop rbx
001ee6cf  c3                       ret
