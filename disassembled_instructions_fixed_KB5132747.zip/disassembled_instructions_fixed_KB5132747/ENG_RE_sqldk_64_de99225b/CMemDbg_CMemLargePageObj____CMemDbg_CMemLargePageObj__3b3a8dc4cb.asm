; CMemDbg<CMemLargePageObj>::~CMemDbg<CMemLargePageObj>
; sqldk.dll, primary RVA 0x173940, 109 bytes in 1 chunk(s)

; chunk at RVA 0x173940 (109 bytes)
00173940  48894c2408               mov qword ptr [rsp + 8], rcx
00173945  53                       push rbx
00173946  4883ec30                 sub rsp, 0x30
0017394a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00173953  488bd9                   mov rbx, rcx
00173956  488d05fb950d00           lea rax, [rip + 0xd95fb]
0017395d  488901                   mov qword ptr [rcx], rax
00173960  488d0551230f00           lea rax, [rip + 0xf2351]
00173967  488981d8010000           mov qword ptr [rcx + 0x1d8], rax
0017396e  488d05a3340d00           lea rax, [rip + 0xd34a3]
00173975  488901                   mov qword ptr [rcx], rax
00173978  488d05e9350d00           lea rax, [rip + 0xd35e9]
0017397f  488901                   mov qword ptr [rcx], rax
00173982  488d057f380d00           lea rax, [rip + 0xd387f]
00173989  488901                   mov qword ptr [rcx], rax
0017398c  4883c138                 add rcx, 0x38
00173990  e85bdce9ff               call 0x115f0
00173995  90                       nop
00173996  488d4b30                 lea rcx, [rbx + 0x30]
0017399a  e851dce9ff               call 0x115f0
0017399f  90                       nop
001739a0  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
001739a7  4883c430                 add rsp, 0x30
001739ab  5b                       pop rbx
001739ac  c3                       ret
