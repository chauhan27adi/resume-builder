; CMemThread<CMemFixed>::PbGetNewPages
; sqldk.dll, primary RVA 0x1b7b0, 179 bytes in 1 chunk(s)

; chunk at RVA 0x1b7b0 (179 bytes)
0001b7b0  48895c2408               mov qword ptr [rsp + 8], rbx
0001b7b5  48896c2410               mov qword ptr [rsp + 0x10], rbp
0001b7ba  4889742418               mov qword ptr [rsp + 0x18], rsi
0001b7bf  57                       push rdi
0001b7c0  4883ec20                 sub rsp, 0x20
0001b7c4  488d9908010000           lea rbx, [rcx + 0x108]
0001b7cb  498bf0                   mov rsi, r8
0001b7ce  48c7838000000000000000   mov qword ptr [rbx + 0x80], 0
0001b7d9  488bea                   mov rbp, rdx
0001b7dc  488bf9                   mov rdi, rcx
0001b7df  b8ff7fffff               mov eax, 0xffff7fff
0001b7e4  f00fc14360               lock xadd dword ptr [rbx + 0x60], eax
0001b7e9  3d01800000               cmp eax, 0x8001
0001b7ee  7411                     je 0x1b801
0001b7f0  488d4b30                 lea rcx, [rbx + 0x30]
0001b7f4  e83731ffff               call 0xe930
0001b7f9  488bcb                   mov rcx, rbx
0001b7fc  e82f31ffff               call 0xe930
0001b801  488b4f40                 mov rcx, qword ptr [rdi + 0x40]
0001b805  4c8bc6                   mov r8, rsi
0001b808  488bd5                   mov rdx, rbp
0001b80b  488b01                   mov rax, qword ptr [rcx]
0001b80e  ff10                     call qword ptr [rax]
0001b810  65488b142558000000       mov rdx, qword ptr gs:[0x58]
0001b819  488be8                   mov rbp, rax
0001b81c  8b0dae972f00             mov ecx, dword ptr [rip + 0x2f97ae]
0001b822  8b359060feff             mov esi, dword ptr [rip - 0x19f70]
0001b828  480334ca                 add rsi, qword ptr [rdx + rcx*8]
0001b82c  488b9600010000           mov rdx, qword ptr [rsi + 0x100]
0001b833  4885d2                   test rdx, rdx
0001b836  0f84c9070e00             je 0xfc005
0001b83c  4c8d8790010000           lea r8, [rdi + 0x190]
0001b843  488bcb                   mov rcx, rbx
0001b846  e835b7feff               call 0x6f80
0001b84b  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0001b850  488bc5                   mov rax, rbp
0001b853  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
0001b858  488b742440               mov rsi, qword ptr [rsp + 0x40]
0001b85d  4883c420                 add rsp, 0x20
0001b861  5f                       pop rdi
0001b862  c3                       ret
