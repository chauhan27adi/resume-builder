; XE_Engine::ReleaseObjectReference
; sqldk.dll, primary RVA 0x1e31a0, 460 bytes in 1 chunk(s)

; chunk at RVA 0x1e31a0 (460 bytes)
001e31a0  4057                     push rdi
001e31a2  4883ec30                 sub rsp, 0x30
001e31a6  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001e31af  48895c2448               mov qword ptr [rsp + 0x48], rbx
001e31b4  488bd9                   mov rbx, rcx
001e31b7  8bc1                     mov eax, ecx
001e31b9  83e007                   and eax, 7
001e31bc  83f805                   cmp eax, 5
001e31bf  0f877d010000             ja 0x1e3342
001e31c5  4898                     cdqe
001e31c7  488d1532cee1ff           lea rdx, [rip - 0x1e31ce]
001e31ce  8b8c8254331e00           mov ecx, dword ptr [rdx + rax*4 + 0x1e3354]
001e31d5  4803ca                   add rcx, rdx
001e31d8  ffe1                     jmp rcx
001e31da  4883e3f8                 and rbx, 0xfffffffffffffff8
001e31de  b8ffffffff               mov eax, 0xffffffff
001e31e3  f00fc14328               lock xadd dword ptr [rbx + 0x28], eax
001e31e8  ffc8                     dec eax
001e31ea  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e31ef  4883c430                 add rsp, 0x30
001e31f3  5f                       pop rdi
001e31f4  c3                       ret
001e31f5  4883e3f8                 and rbx, 0xfffffffffffffff8
001e31f9  bfffffffff               mov edi, 0xffffffff
001e31fe  f00fc17b18               lock xadd dword ptr [rbx + 0x18], edi
001e3203  83ef01                   sub edi, 1
001e3206  751b                     jne 0x1e3223
001e3208  48837b1000               cmp qword ptr [rbx + 0x10], 0
001e320d  740c                     je 0x1e321b
001e320f  488bd3                   mov rdx, rbx
001e3212  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
001e3216  e8955d0000               call 0x1e8fb0
001e321b  488bcb                   mov rcx, rbx
001e321e  e88da30000               call 0x1ed5b0
001e3223  8bc7                     mov eax, edi
001e3225  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e322a  4883c430                 add rsp, 0x30
001e322e  5f                       pop rdi
001e322f  c3                       ret
001e3230  4883e3f8                 and rbx, 0xfffffffffffffff8
001e3234  bfffffffff               mov edi, 0xffffffff
001e3239  f00fc17b18               lock xadd dword ptr [rbx + 0x18], edi
001e323e  83ef01                   sub edi, 1
001e3241  75e0                     jne 0x1e3223
001e3243  48837b1000               cmp qword ptr [rbx + 0x10], 0
001e3248  740c                     je 0x1e3256
001e324a  488bd3                   mov rdx, rbx
001e324d  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
001e3251  e88a720000               call 0x1ea4e0
001e3256  488bcb                   mov rcx, rbx
001e3259  e8b2190100               call 0x1f4c10
001e325e  8bc7                     mov eax, edi
001e3260  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e3265  4883c430                 add rsp, 0x30
001e3269  5f                       pop rdi
001e326a  c3                       ret
001e326b  4883e3f8                 and rbx, 0xfffffffffffffff8
001e326f  bfffffffff               mov edi, 0xffffffff
001e3274  f00fc13b                 lock xadd dword ptr [rbx], edi
001e3278  83ef01                   sub edi, 1
001e327b  75a6                     jne 0x1e3223
001e327d  48895c2440               mov qword ptr [rsp + 0x40], rbx
001e3282  4885db                   test rbx, rbx
001e3285  749c                     je 0x1e3223
001e3287  488bcb                   mov rcx, rbx
001e328a  e831fa0000               call 0x1f2cc0
001e328f  90                       nop
001e3290  c703adde0080             mov dword ptr [rbx], 0x8000dead
001e3296  ba88000000               mov edx, 0x88
001e329b  488bcb                   mov rcx, rbx
001e329e  e88d3ce2ff               call 0x6f30
001e32a3  8bc7                     mov eax, edi
001e32a5  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e32aa  4883c430                 add rsp, 0x30
001e32ae  5f                       pop rdi
001e32af  c3                       ret
001e32b0  4883e3f8                 and rbx, 0xfffffffffffffff8
001e32b4  bfffffffff               mov edi, 0xffffffff
001e32b9  f00fc17b10               lock xadd dword ptr [rbx + 0x10], edi
001e32be  83ef01                   sub edi, 1
001e32c1  0f855cffffff             jne 0x1e3223
001e32c7  48837b0800               cmp qword ptr [rbx + 8], 0
001e32cc  740c                     je 0x1e32da
001e32ce  488bd3                   mov rdx, rbx
001e32d1  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001e32d5  e8965a0000               call 0x1e8d70
001e32da  488bcb                   mov rcx, rbx
001e32dd  e81e090100               call 0x1f3c00
001e32e2  baa8000000               mov edx, 0xa8
001e32e7  488bcb                   mov rcx, rbx
001e32ea  e8413ce2ff               call 0x6f30
001e32ef  8bc7                     mov eax, edi
001e32f1  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e32f6  4883c430                 add rsp, 0x30
001e32fa  5f                       pop rdi
001e32fb  c3                       ret
001e32fc  4883e3f8                 and rbx, 0xfffffffffffffff8
001e3300  488d4308                 lea rax, [rbx + 8]
001e3304  bfffffffff               mov edi, 0xffffffff
001e3309  f00fc138                 lock xadd dword ptr [rax], edi
001e330d  83ef01                   sub edi, 1
001e3310  0f850dffffff             jne 0x1e3223
001e3316  33c9                     xor ecx, ecx
001e3318  4885c0                   test rax, rax
001e331b  480f44d9                 cmove rbx, rcx
001e331f  4885db                   test rbx, rbx
001e3322  0f84fbfeffff             je 0x1e3223
001e3328  4c8b03                   mov r8, qword ptr [rbx]
001e332b  8d5701                   lea edx, [rdi + 1]
001e332e  488bcb                   mov rcx, rbx
001e3331  41ff5020                 call qword ptr [r8 + 0x20]
001e3335  8bc7                     mov eax, edi
001e3337  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e333c  4883c430                 add rsp, 0x30
001e3340  5f                       pop rdi
001e3341  c3                       ret
001e3342  b8ffffffff               mov eax, 0xffffffff
001e3347  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e334c  4883c430                 add rsp, 0x30
001e3350  5f                       pop rdi
001e3351  c3                       ret
001e3352  90                       nop
001e3353  90                       nop
001e3354  da31                     fidiv dword ptr [rcx]
