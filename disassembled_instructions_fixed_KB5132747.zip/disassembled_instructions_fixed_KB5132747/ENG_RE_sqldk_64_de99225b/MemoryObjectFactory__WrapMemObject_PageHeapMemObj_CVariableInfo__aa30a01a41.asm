; MemoryObjectFactory::WrapMemObject<PageHeapMemObj,CVariableInfo>
; sqldk.dll, primary RVA 0xc9840, 4408 bytes in 1 chunk(s)

; chunk at RVA 0xc9840 (4408 bytes)
000c9840  4c894c2420               mov qword ptr [rsp + 0x20], r9
000c9845  4c89442418               mov qword ptr [rsp + 0x18], r8
000c984a  55                       push rbp
000c984b  56                       push rsi
000c984c  57                       push rdi
000c984d  4154                     push r12
000c984f  4155                     push r13
000c9851  4156                     push r14
000c9853  4157                     push r15
000c9855  488bec                   mov rbp, rsp
000c9858  4883ec70                 sub rsp, 0x70
000c985c  48c745d0feffffff         mov qword ptr [rbp - 0x30], 0xfffffffffffffffe
000c9864  48899c24b0000000         mov qword ptr [rsp + 0xb0], rbx
000c986c  498bf0                   mov rsi, r8
000c986f  8bc2                     mov eax, edx
000c9871  488d158867f3ff           lea rdx, [rip - 0xc9878]
000c9878  4c8bbcc200273100         mov r15, qword ptr [rdx + rax*8 + 0x312700]
000c9880  4c897d58                 mov qword ptr [rbp + 0x58], r15
000c9884  448b6578                 mov r12d, dword ptr [rbp + 0x78]
000c9888  458bf4                   mov r14d, r12d
000c988b  4181e602002f01           and r14d, 0x12f0002
000c9892  4533ed                   xor r13d, r13d
000c9895  418bdd                   mov ebx, r13d
000c9898  83f92a                   cmp ecx, 0x2a
000c989b  0f8710100000             ja 0xca8b1
000c98a1  4863c1                   movsxd rax, ecx
000c98a4  8b8c82cca80c00           mov ecx, dword ptr [rdx + rax*4 + 0xca8cc]
000c98ab  4803ca                   add rcx, rdx
000c98ae  ffe1                     jmp rcx
000c98b0  488bd6                   mov rdx, rsi
000c98b3  b980000000               mov ecx, 0x80
000c98b8  e8c389f4ff               call 0x12280
000c98bd  488bd8                   mov rbx, rax
000c98c0  48894558                 mov qword ptr [rbp + 0x58], rax
000c98c4  4885c0                   test rax, rax
000c98c7  744c                     je 0xc9915
000c98c9  c7400801000000           mov dword ptr [rax + 8], 1
000c98d0  488d0531d91700           lea rax, [rip + 0x17d931]
000c98d7  488903                   mov qword ptr [rbx], rax
000c98da  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c98e2  44896b18                 mov dword ptr [rbx + 0x18], r13d
000c98e6  4c896b20                 mov qword ptr [rbx + 0x20], r13
000c98ea  44896b28                 mov dword ptr [rbx + 0x28], r13d
000c98ee  4c896b30                 mov qword ptr [rbx + 0x30], r13
000c98f2  4c896b38                 mov qword ptr [rbx + 0x38], r13
000c98f6  4c896b40                 mov qword ptr [rbx + 0x40], r13
000c98fa  4c896b48                 mov qword ptr [rbx + 0x48], r13
000c98fe  488d051b4d1800           lea rax, [rip + 0x184d1b]
000c9905  488903                   mov qword ptr [rbx], rax
000c9908  488d4368                 lea rax, [rbx + 0x68]
000c990c  48894008                 mov qword ptr [rax + 8], rax
000c9910  488900                   mov qword ptr [rax], rax
000c9913  eb03                     jmp 0xc9918
000c9915  498bdd                   mov rbx, r13
000c9918  e96c0f0000               jmp 0xca889
000c991d  488bd6                   mov rdx, rsi
000c9920  b950040000               mov ecx, 0x450
000c9925  e85689f4ff               call 0x12280
000c992a  488bd8                   mov rbx, rax
000c992d  48894558                 mov qword ptr [rbp + 0x58], rax
000c9931  4885c0                   test rax, rax
000c9934  7464                     je 0xc999a
000c9936  c7400801000000           mov dword ptr [rax + 8], 1
000c993d  488d05c4d81700           lea rax, [rip + 0x17d8c4]
000c9944  488903                   mov qword ptr [rbx], rax
000c9947  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c994f  44896b18                 mov dword ptr [rbx + 0x18], r13d
000c9953  4c896b20                 mov qword ptr [rbx + 0x20], r13
000c9957  44896b28                 mov dword ptr [rbx + 0x28], r13d
000c995b  4c896b30                 mov qword ptr [rbx + 0x30], r13
000c995f  4c896b38                 mov qword ptr [rbx + 0x38], r13
000c9963  4c896b40                 mov qword ptr [rbx + 0x40], r13
000c9967  4c896b48                 mov qword ptr [rbx + 0x48], r13
000c996b  488d05ae4c1800           lea rax, [rip + 0x184cae]
000c9972  488903                   mov qword ptr [rbx], rax
000c9975  488d4368                 lea rax, [rbx + 0x68]
000c9979  48894008                 mov qword ptr [rax + 8], rax
000c997d  488900                   mov qword ptr [rax], rax
000c9980  488d05e9491800           lea rax, [rip + 0x1849e9]
000c9987  488903                   mov qword ptr [rbx], rax
000c998a  488d0527c31900           lea rax, [rip + 0x19c327]
000c9991  48898390000000           mov qword ptr [rbx + 0x90], rax
000c9998  eb03                     jmp 0xc999d
000c999a  498bdd                   mov rbx, r13
000c999d  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000c99a6  8b0524b62400             mov eax, dword ptr [rip + 0x24b624]
000c99ac  8b3d067ff3ff             mov edi, dword ptr [rip - 0xc80fa]
000c99b2  48033cc1                 add rdi, qword ptr [rcx + rax*8]
000c99b6  488b8700010000           mov rax, qword ptr [rdi + 0x100]
000c99bd  4885c0                   test rax, rax
000c99c0  750e                     jne 0xc99d0
000c99c2  33c9                     xor ecx, ecx
000c99c4  e897c2f5ff               call 0x25c60
000c99c9  488b8700010000           mov rax, qword ptr [rdi + 0x100]
000c99d0  488b8058020000           mov rax, qword ptr [rax + 0x258]
000c99d7  48898380000000           mov qword ptr [rbx + 0x80], rax
000c99de  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c99e8  4489b38c000000           mov dword ptr [rbx + 0x8c], r14d
000c99ef  4489ab38040000           mov dword ptr [rbx + 0x438], r13d
000c99f6  418bc4                   mov eax, r12d
000c99f9  c1e819                   shr eax, 0x19
000c99fc  83e001                   and eax, 1
000c99ff  89833c040000             mov dword ptr [rbx + 0x43c], eax
000c9a05  4489ab40040000           mov dword ptr [rbx + 0x440], r13d
000c9a0c  4c89ab48040000           mov qword ptr [rbx + 0x448], r13
000c9a13  488d8b90000000           lea rcx, [rbx + 0x90]
000c9a1a  4c8bcb                   mov r9, rbx
000c9a1d  458bc6                   mov r8d, r14d
000c9a20  498bd7                   mov rdx, r15
000c9a23  e878e90900               call 0x1683a0
000c9a28  e95c0e0000               jmp 0xca889
000c9a2d  488bd6                   mov rdx, rsi
000c9a30  b9f8000000               mov ecx, 0xf8
000c9a35  e84688f4ff               call 0x12280
000c9a3a  48894558                 mov qword ptr [rbp + 0x58], rax
000c9a3e  4885c0                   test rax, rax
000c9a41  740d                     je 0xc9a50
000c9a43  488bc8                   mov rcx, rax
000c9a46  e8653d0000               call 0xcd7b0
000c9a4b  488bd8                   mov rbx, rax
000c9a4e  eb03                     jmp 0xc9a53
000c9a50  498bdd                   mov rbx, r13
000c9a53  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000c9a5a  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000c9a5f  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000c9a66  488bcb                   mov rcx, rbx
000c9a69  e812980100               call 0xe3280
000c9a6e  e9160e0000               jmp 0xca889
000c9a73  488bd6                   mov rdx, rsi
000c9a76  b988000000               mov ecx, 0x88
000c9a7b  e80088f4ff               call 0x12280
000c9a80  488bf8                   mov rdi, rax
000c9a83  48894558                 mov qword ptr [rbp + 0x58], rax
000c9a87  4885c0                   test rax, rax
000c9a8a  745d                     je 0xc9ae9
000c9a8c  c7400801000000           mov dword ptr [rax + 8], 1
000c9a93  488d056ed71700           lea rax, [rip + 0x17d76e]
000c9a9a  488907                   mov qword ptr [rdi], rax
000c9a9d  48c7471000200000         mov qword ptr [rdi + 0x10], 0x2000
000c9aa5  44896f18                 mov dword ptr [rdi + 0x18], r13d
000c9aa9  4c896f20                 mov qword ptr [rdi + 0x20], r13
000c9aad  44896f28                 mov dword ptr [rdi + 0x28], r13d
000c9ab1  4c896f30                 mov qword ptr [rdi + 0x30], r13
000c9ab5  4c896f38                 mov qword ptr [rdi + 0x38], r13
000c9ab9  4c896f40                 mov qword ptr [rdi + 0x40], r13
000c9abd  4c896f48                 mov qword ptr [rdi + 0x48], r13
000c9ac1  488d05584b1800           lea rax, [rip + 0x184b58]
000c9ac8  488907                   mov qword ptr [rdi], rax
000c9acb  488d4768                 lea rax, [rdi + 0x68]
000c9acf  48894008                 mov qword ptr [rax + 8], rax
000c9ad3  488900                   mov qword ptr [rax], rax
000c9ad6  488d0543141800           lea rax, [rip + 0x181443]
000c9add  488907                   mov qword ptr [rdi], rax
000c9ae0  4c89af80000000           mov qword ptr [rdi + 0x80], r13
000c9ae7  eb03                     jmp 0xc9aec
000c9ae9  498bfd                   mov rdi, r13
000c9aec  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c9af3  0f1008                   movups xmm1, xmmword ptr [rax]
000c9af6  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c9afa  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c9afe  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c9b02  66480f7eca               movq rdx, xmm1
000c9b07  48c1ea20                 shr rdx, 0x20
000c9b0b  f6c201                   test dl, 1
000c9b0e  7564                     jne 0xc9b74
000c9b10  81e22ffbffff             and edx, 0xfffffb2f
000c9b16  81ca20020000             or edx, 0x220
000c9b1c  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c9b20  48c1e820                 shr rax, 0x20
000c9b24  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c9b28  498bc8                   mov rcx, r8
000c9b2b  48c1e920                 shr rcx, 0x20
000c9b2f  49c1e810                 shr r8, 0x10
000c9b33  89442438                 mov dword ptr [rsp + 0x38], eax
000c9b37  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c9b3a  89442430                 mov dword ptr [rsp + 0x30], eax
000c9b3e  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c9b42  664489442420             mov word ptr [rsp + 0x20], r8w
000c9b48  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c9b4d  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c9b51  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c9b54  e8b77df4ff               call 0x11910
000c9b59  48898780000000           mov qword ptr [rdi + 0x80], rax
000c9b60  4885c0                   test rax, rax
000c9b63  0f95c0                   setne al
000c9b66  498bdd                   mov rbx, r13
000c9b69  84c0                     test al, al
000c9b6b  480f45df                 cmovne rbx, rdi
000c9b6f  e9150d0000               jmp 0xca889
000c9b74  b001                     mov al, 1
000c9b76  498bdd                   mov rbx, r13
000c9b79  84c0                     test al, al
000c9b7b  480f45df                 cmovne rbx, rdi
000c9b7f  e9050d0000               jmp 0xca889
000c9b84  488bd6                   mov rdx, rsi
000c9b87  b958040000               mov ecx, 0x458
000c9b8c  e8ef86f4ff               call 0x12280
000c9b91  488bd8                   mov rbx, rax
000c9b94  48894558                 mov qword ptr [rbp + 0x58], rax
000c9b98  4885c0                   test rax, rax
000c9b9b  7475                     je 0xc9c12
000c9b9d  c7400801000000           mov dword ptr [rax + 8], 1
000c9ba4  488d055dd61700           lea rax, [rip + 0x17d65d]
000c9bab  488903                   mov qword ptr [rbx], rax
000c9bae  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c9bb6  44896b18                 mov dword ptr [rbx + 0x18], r13d
000c9bba  4c896b20                 mov qword ptr [rbx + 0x20], r13
000c9bbe  44896b28                 mov dword ptr [rbx + 0x28], r13d
000c9bc2  4c896b30                 mov qword ptr [rbx + 0x30], r13
000c9bc6  4c896b38                 mov qword ptr [rbx + 0x38], r13
000c9bca  4c896b40                 mov qword ptr [rbx + 0x40], r13
000c9bce  4c896b48                 mov qword ptr [rbx + 0x48], r13
000c9bd2  488d05474a1800           lea rax, [rip + 0x184a47]
000c9bd9  488903                   mov qword ptr [rbx], rax
000c9bdc  488d4368                 lea rax, [rbx + 0x68]
000c9be0  48894008                 mov qword ptr [rax + 8], rax
000c9be4  488900                   mov qword ptr [rax], rax
000c9be7  488d0582471800           lea rax, [rip + 0x184782]
000c9bee  488903                   mov qword ptr [rbx], rax
000c9bf1  488d05c0c01900           lea rax, [rip + 0x19c0c0]
000c9bf8  48898390000000           mov qword ptr [rbx + 0x90], rax
000c9bff  488d05ca151800           lea rax, [rip + 0x1815ca]
000c9c06  488903                   mov qword ptr [rbx], rax
000c9c09  4c89ab50040000           mov qword ptr [rbx + 0x450], r13
000c9c10  eb03                     jmp 0xc9c15
000c9c12  498bdd                   mov rbx, r13
000c9c15  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c9c1c  0f1008                   movups xmm1, xmmword ptr [rax]
000c9c1f  66480f7eca               movq rdx, xmm1
000c9c24  48c1ea20                 shr rdx, 0x20
000c9c28  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c9c2c  f6c201                   test dl, 1
000c9c2f  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c9c33  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c9c37  0f8560fdffff             jne 0xc999d
000c9c3d  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c9c41  48c1e820                 shr rax, 0x20
000c9c45  89442438                 mov dword ptr [rsp + 0x38], eax
000c9c49  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c9c4d  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c9c50  498bc8                   mov rcx, r8
000c9c53  89442430                 mov dword ptr [rsp + 0x30], eax
000c9c57  48c1e920                 shr rcx, 0x20
000c9c5b  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c9c5f  49c1e810                 shr r8, 0x10
000c9c63  664489442420             mov word ptr [rsp + 0x20], r8w
000c9c69  81e22ffbffff             and edx, 0xfffffb2f
000c9c6f  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c9c74  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c9c78  81ca20020000             or edx, 0x220
000c9c7e  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c9c81  e88a7cf4ff               call 0x11910
000c9c86  48898350040000           mov qword ptr [rbx + 0x450], rax
000c9c8d  4885c0                   test rax, rax
000c9c90  0f95c0                   setne al
000c9c93  84c0                     test al, al
000c9c95  0f8502fdffff             jne 0xc999d
000c9c9b  498bdd                   mov rbx, r13
000c9c9e  e90e0c0000               jmp 0xca8b1
000c9ca3  488bd6                   mov rdx, rsi
000c9ca6  b958010000               mov ecx, 0x158
000c9cab  e8d085f4ff               call 0x12280
000c9cb0  48894558                 mov qword ptr [rbp + 0x58], rax
000c9cb4  4885c0                   test rax, rax
000c9cb7  740d                     je 0xc9cc6
000c9cb9  488bc8                   mov rcx, rax
000c9cbc  e83fbd0100               call 0xe5a00
000c9cc1  488bd8                   mov rbx, rax
000c9cc4  eb03                     jmp 0xc9cc9
000c9cc6  498bdd                   mov rbx, r13
000c9cc9  e9bb0b0000               jmp 0xca889
000c9cce  488bd6                   mov rdx, rsi
000c9cd1  b9d0010000               mov ecx, 0x1d0
000c9cd6  e8a585f4ff               call 0x12280
000c9cdb  48894558                 mov qword ptr [rbp + 0x58], rax
000c9cdf  4885c0                   test rax, rax
000c9ce2  740d                     je 0xc9cf1
000c9ce4  488bc8                   mov rcx, rax
000c9ce7  e8843b0000               call 0xcd870
000c9cec  488bd8                   mov rbx, rax
000c9cef  eb03                     jmp 0xc9cf4
000c9cf1  498bdd                   mov rbx, r13
000c9cf4  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000c9cfb  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000c9d00  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000c9d07  488bcb                   mov rcx, rbx
000c9d0a  e871350200               call 0xed280
000c9d0f  e9750b0000               jmp 0xca889
000c9d14  488bd6                   mov rdx, rsi
000c9d17  b960010000               mov ecx, 0x160
000c9d1c  e85f85f4ff               call 0x12280
000c9d21  48894558                 mov qword ptr [rbp + 0x58], rax
000c9d25  4885c0                   test rax, rax
000c9d28  740d                     je 0xc9d37
000c9d2a  488bc8                   mov rcx, rax
000c9d2d  e85eff0100               call 0xe9c90
000c9d32  488bf8                   mov rdi, rax
000c9d35  eb03                     jmp 0xc9d3a
000c9d37  498bfd                   mov rdi, r13
000c9d3a  e9adfdffff               jmp 0xc9aec
000c9d3f  488bd6                   mov rdx, rsi
000c9d42  b9d0000000               mov ecx, 0xd0
000c9d47  e83485f4ff               call 0x12280
000c9d4c  488bd8                   mov rbx, rax
000c9d4f  48894558                 mov qword ptr [rbp + 0x58], rax
000c9d53  4885c0                   test rax, rax
000c9d56  0f8485000000             je 0xc9de1
000c9d5c  c7400801000000           mov dword ptr [rax + 8], 1
000c9d63  488d059ed41700           lea rax, [rip + 0x17d49e]
000c9d6a  488903                   mov qword ptr [rbx], rax
000c9d6d  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c9d75  44896b18                 mov dword ptr [rbx + 0x18], r13d
000c9d79  4c896b20                 mov qword ptr [rbx + 0x20], r13
000c9d7d  44896b28                 mov dword ptr [rbx + 0x28], r13d
000c9d81  4c896b30                 mov qword ptr [rbx + 0x30], r13
000c9d85  4c896b38                 mov qword ptr [rbx + 0x38], r13
000c9d89  4c896b40                 mov qword ptr [rbx + 0x40], r13
000c9d8d  4c896b48                 mov qword ptr [rbx + 0x48], r13
000c9d91  488d0588481800           lea rax, [rip + 0x184888]
000c9d98  488903                   mov qword ptr [rbx], rax
000c9d9b  488d4368                 lea rax, [rbx + 0x68]
000c9d9f  48894008                 mov qword ptr [rax + 8], rax
000c9da3  488900                   mov qword ptr [rax], rax
000c9da6  488d05fbff1700           lea rax, [rip + 0x17fffb]
000c9dad  488903                   mov qword ptr [rbx], rax
000c9db0  4c89ab80000000           mov qword ptr [rbx + 0x80], r13
000c9db7  0f57c0                   xorps xmm0, xmm0
000c9dba  33c0                     xor eax, eax
000c9dbc  0f118388000000           movups xmmword ptr [rbx + 0x88], xmm0
000c9dc3  0f118398000000           movups xmmword ptr [rbx + 0x98], xmm0
000c9dca  0f1183a8000000           movups xmmword ptr [rbx + 0xa8], xmm0
000c9dd1  0f1183b8000000           movups xmmword ptr [rbx + 0xb8], xmm0
000c9dd8  488983c8000000           mov qword ptr [rbx + 0xc8], rax
000c9ddf  eb03                     jmp 0xc9de4
000c9de1  498bdd                   mov rbx, r13
000c9de4  e9a00a0000               jmp 0xca889
000c9de9  488bd6                   mov rdx, rsi
000c9dec  b9d8000000               mov ecx, 0xd8
000c9df1  e88a84f4ff               call 0x12280
000c9df6  48894558                 mov qword ptr [rbp + 0x58], rax
000c9dfa  4885c0                   test rax, rax
000c9dfd  740d                     je 0xc9e0c
000c9dff  488bc8                   mov rcx, rax
000c9e02  e819350200               call 0xed320
000c9e07  488bf8                   mov rdi, rax
000c9e0a  eb03                     jmp 0xc9e0f
000c9e0c  498bfd                   mov rdi, r13
000c9e0f  e9d8fcffff               jmp 0xc9aec
000c9e14  488bd6                   mov rdx, rsi
000c9e17  b928050000               mov ecx, 0x528
000c9e1c  e85f84f4ff               call 0x12280
000c9e21  48894558                 mov qword ptr [rbp + 0x58], rax
000c9e25  4885c0                   test rax, rax
000c9e28  740d                     je 0xc9e37
000c9e2a  488bc8                   mov rcx, rax
000c9e2d  e89edc0100               call 0xe7ad0
000c9e32  488bd8                   mov rbx, rax
000c9e35  eb03                     jmp 0xc9e3a
000c9e37  498bdd                   mov rbx, r13
000c9e3a  4c89ab80000000           mov qword ptr [rbx + 0x80], r13
000c9e41  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c9e4b  4489b38c000000           mov dword ptr [rbx + 0x8c], r14d
000c9e52  4c89ab38040000           mov qword ptr [rbx + 0x438], r13
000c9e59  e9a7fbffff               jmp 0xc9a05
000c9e5e  488bd6                   mov rdx, rsi
000c9e61  b930050000               mov ecx, 0x530
000c9e66  e81584f4ff               call 0x12280
000c9e6b  48894558                 mov qword ptr [rbp + 0x58], rax
000c9e6f  4885c0                   test rax, rax
000c9e72  740d                     je 0xc9e81
000c9e74  488bc8                   mov rcx, rax
000c9e77  e804210200               call 0xebf80
000c9e7c  488bd8                   mov rbx, rax
000c9e7f  eb03                     jmp 0xc9e84
000c9e81  498bdd                   mov rbx, r13
000c9e84  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c9e8b  0f1008                   movups xmm1, xmmword ptr [rax]
000c9e8e  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c9e92  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c9e96  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c9e9a  66480f7eca               movq rdx, xmm1
000c9e9f  48c1ea20                 shr rdx, 0x20
000c9ea3  f6c201                   test dl, 1
000c9ea6  7592                     jne 0xc9e3a
000c9ea8  81e22ffbffff             and edx, 0xfffffb2f
000c9eae  81ca20020000             or edx, 0x220
000c9eb4  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c9eb8  48c1e820                 shr rax, 0x20
000c9ebc  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c9ec0  498bc8                   mov rcx, r8
000c9ec3  48c1e920                 shr rcx, 0x20
000c9ec7  49c1e810                 shr r8, 0x10
000c9ecb  89442438                 mov dword ptr [rsp + 0x38], eax
000c9ecf  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c9ed2  89442430                 mov dword ptr [rsp + 0x30], eax
000c9ed6  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c9eda  664489442420             mov word ptr [rsp + 0x20], r8w
000c9ee0  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c9ee5  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c9ee9  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c9eec  e81f7af4ff               call 0x11910
000c9ef1  48898350040000           mov qword ptr [rbx + 0x450], rax
000c9ef8  4885c0                   test rax, rax
000c9efb  0f95c0                   setne al
000c9efe  84c0                     test al, al
000c9f00  0f8534ffffff             jne 0xc9e3a
000c9f06  498bdd                   mov rbx, r13
000c9f09  e9a3090000               jmp 0xca8b1
000c9f0e  488bd6                   mov rdx, rsi
000c9f11  b9a0040000               mov ecx, 0x4a0
000c9f16  e86583f4ff               call 0x12280
000c9f1b  48894558                 mov qword ptr [rbp + 0x58], rax
000c9f1f  4885c0                   test rax, rax
000c9f22  740d                     je 0xc9f31
000c9f24  488bc8                   mov rcx, rax
000c9f27  e8b4340200               call 0xed3e0
000c9f2c  488bd8                   mov rbx, rax
000c9f2f  eb03                     jmp 0xc9f34
000c9f31  498bdd                   mov rbx, r13
000c9f34  e964faffff               jmp 0xc999d
000c9f39  488bd6                   mov rdx, rsi
000c9f3c  b9a8040000               mov ecx, 0x4a8
000c9f41  e83a83f4ff               call 0x12280
000c9f46  48894558                 mov qword ptr [rbp + 0x58], rax
000c9f4a  4885c0                   test rax, rax
000c9f4d  740d                     je 0xc9f5c
000c9f4f  488bc8                   mov rcx, rax
000c9f52  e849350200               call 0xed4a0
000c9f57  488bd8                   mov rbx, rax
000c9f5a  eb03                     jmp 0xc9f5f
000c9f5c  498bdd                   mov rbx, r13
000c9f5f  e9b1fcffff               jmp 0xc9c15
000c9f64  488bd6                   mov rdx, rsi
000c9f67  b9a8010000               mov ecx, 0x1a8
000c9f6c  e80f83f4ff               call 0x12280
000c9f71  48894558                 mov qword ptr [rbp + 0x58], rax
000c9f75  4885c0                   test rax, rax
000c9f78  740d                     je 0xc9f87
000c9f7a  488bc8                   mov rcx, rax
000c9f7d  e8ee350200               call 0xed570
000c9f82  488bd8                   mov rbx, rax
000c9f85  eb03                     jmp 0xc9f8a
000c9f87  498bdd                   mov rbx, r13
000c9f8a  e9fa080000               jmp 0xca889
000c9f8f  488bd6                   mov rdx, rsi
000c9f92  b9b0010000               mov ecx, 0x1b0
000c9f97  e8e482f4ff               call 0x12280
000c9f9c  48894558                 mov qword ptr [rbp + 0x58], rax
000c9fa0  4885c0                   test rax, rax
000c9fa3  740d                     je 0xc9fb2
000c9fa5  488bc8                   mov rcx, rax
000c9fa8  e833360200               call 0xed5e0
000c9fad  488bf8                   mov rdi, rax
000c9fb0  eb03                     jmp 0xc9fb5
000c9fb2  498bfd                   mov rdi, r13
000c9fb5  e932fbffff               jmp 0xc9aec
000c9fba  488bd6                   mov rdx, rsi
000c9fbd  b978050000               mov ecx, 0x578
000c9fc2  e8b982f4ff               call 0x12280
000c9fc7  48894558                 mov qword ptr [rbp + 0x58], rax
000c9fcb  4885c0                   test rax, rax
000c9fce  740d                     je 0xc9fdd
000c9fd0  488bc8                   mov rcx, rax
000c9fd3  e878360200               call 0xed650
000c9fd8  488bd8                   mov rbx, rax
000c9fdb  eb03                     jmp 0xc9fe0
000c9fdd  498bdd                   mov rbx, r13
000c9fe0  e955feffff               jmp 0xc9e3a
000c9fe5  488bd6                   mov rdx, rsi
000c9fe8  b980050000               mov ecx, 0x580
000c9fed  e88e82f4ff               call 0x12280
000c9ff2  48894558                 mov qword ptr [rbp + 0x58], rax
000c9ff6  4885c0                   test rax, rax
000c9ff9  740d                     je 0xca008
000c9ffb  488bc8                   mov rcx, rax
000c9ffe  e8bd360200               call 0xed6c0
000ca003  488bd8                   mov rbx, rax
000ca006  eb03                     jmp 0xca00b
000ca008  498bdd                   mov rbx, r13
000ca00b  e974feffff               jmp 0xc9e84
000ca010  488bd6                   mov rdx, rsi
000ca013  b920020000               mov ecx, 0x220
000ca018  e86382f4ff               call 0x12280
000ca01d  48894558                 mov qword ptr [rbp + 0x58], rax
000ca021  4885c0                   test rax, rax
000ca024  740d                     je 0xca033
000ca026  488bc8                   mov rcx, rax
000ca029  e8c2380000               call 0xcd8f0
000ca02e  488bd8                   mov rbx, rax
000ca031  eb03                     jmp 0xca036
000ca033  498bdd                   mov rbx, r13
000ca036  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000ca03d  418b4504                 mov eax, dword ptr [r13 + 4]
000ca041  2573020000               and eax, 0x273
000ca046  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000ca04d  83f802                   cmp eax, 2
000ca050  7527                     jne 0xca079
000ca052  803ddf7d260000           cmp byte ptr [rip + 0x267ddf], 0
000ca059  741e                     je 0xca079
000ca05b  8b058baa2400             mov eax, dword ptr [rip + 0x24aa8b]
000ca061  83f801                   cmp eax, 1
000ca064  7613                     jbe 0xca079
000ca066  c7837801000001000000     mov dword ptr [rbx + 0x178], 1
000ca070  448b3d75aa2400           mov r15d, dword ptr [rip + 0x24aa75]
000ca077  eb15                     jmp 0xca08e
000ca079  c7837801000000000000     mov dword ptr [rbx + 0x178], 0
000ca083  418bcc                   mov ecx, r12d
000ca086  e855570700               call 0x13f7e0
000ca08b  448bf8                   mov r15d, eax
000ca08e  418bc7                   mov eax, r15d
000ca091  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca099  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca09d  48c7835801000000000000   mov qword ptr [rbx + 0x158], 0
000ca0a8  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca0ac  0f879a000000             ja 0xca14c
000ca0b2  0faee8                   lfence
000ca0b5  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca0b9  48c1e00d                 shl rax, 0xd
000ca0bd  4881faa01f0000           cmp rdx, 0x1fa0
000ca0c4  762d                     jbe 0xca0f3
000ca0c6  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000ca0cb  4c8bca                   mov r9, rdx
000ca0ce  4c8bc2                   mov r8, rdx
000ca0d1  498bce                   mov rcx, r14
000ca0d4  e817d8f3ff               call 0x78f0
000ca0d9  66ff4614                 inc word ptr [rsi + 0x14]
000ca0dd  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca0e1  48c1e00d                 shl rax, 0xd
000ca0e5  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca0ea  8b4808                   mov ecx, dword ptr [rax + 8]
000ca0ed  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca0f1  eb4e                     jmp 0xca141
000ca0f3  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000ca0f8  418b4608                 mov eax, dword ptr [r14 + 8]
000ca0fc  483bc2                   cmp rax, rdx
000ca0ff  730d                     jae 0xca10e
000ca101  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000ca105  418b4608                 mov eax, dword ptr [r14 + 8]
000ca109  483bc2                   cmp rax, rdx
000ca10c  72f3                     jb 0xca101
000ca10e  418b7e08                 mov edi, dword ptr [r14 + 8]
000ca112  4c8bca                   mov r9, rdx
000ca115  41b820000000             mov r8d, 0x20
000ca11b  498bce                   mov rcx, r14
000ca11e  e8cdd7f3ff               call 0x78f0
000ca123  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca127  7514                     jne 0xca13d
000ca129  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca12d  48c1e00d                 shl rax, 0xd
000ca131  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca136  8b4808                   mov ecx, dword ptr [rax + 8]
000ca139  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca13d  66ff4614                 inc word ptr [rsi + 0x14]
000ca141  498d4610                 lea rax, [r14 + 0x10]
000ca145  48898358010000           mov qword ptr [rbx + 0x158], rax
000ca14c  4c896c2420               mov qword ptr [rsp + 0x20], r13
000ca151  458bcf                   mov r9d, r15d
000ca154  458bc4                   mov r8d, r12d
000ca157  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000ca15e  488bcb                   mov rcx, rbx
000ca161  e80a730700               call 0x141470
000ca166  85c0                     test eax, eax
000ca168  0f8514070000             jne 0xca882
000ca16e  33db                     xor ebx, ebx
000ca170  e93c070000               jmp 0xca8b1
000ca175  488bd6                   mov rdx, rsi
000ca178  b928020000               mov ecx, 0x228
000ca17d  e8fe80f4ff               call 0x12280
000ca182  48894558                 mov qword ptr [rbp + 0x58], rax
000ca186  4885c0                   test rax, rax
000ca189  740d                     je 0xca198
000ca18b  488bc8                   mov rcx, rax
000ca18e  e8dd370000               call 0xcd970
000ca193  488bd8                   mov rbx, rax
000ca196  eb03                     jmp 0xca19b
000ca198  498bdd                   mov rbx, r13
000ca19b  4c8bbd90000000           mov r15, qword ptr [rbp + 0x90]
000ca1a2  418b4704                 mov eax, dword ptr [r15 + 4]
000ca1a6  2573020000               and eax, 0x273
000ca1ab  448bad88000000           mov r13d, dword ptr [rbp + 0x88]
000ca1b2  83f802                   cmp eax, 2
000ca1b5  7527                     jne 0xca1de
000ca1b7  803d7a7c260000           cmp byte ptr [rip + 0x267c7a], 0
000ca1be  741e                     je 0xca1de
000ca1c0  8b0526a92400             mov eax, dword ptr [rip + 0x24a926]
000ca1c6  83f801                   cmp eax, 1
000ca1c9  7613                     jbe 0xca1de
000ca1cb  c7838001000001000000     mov dword ptr [rbx + 0x180], 1
000ca1d5  448b2510a92400           mov r12d, dword ptr [rip + 0x24a910]
000ca1dc  eb15                     jmp 0xca1f3
000ca1de  c7838001000000000000     mov dword ptr [rbx + 0x180], 0
000ca1e8  418bcd                   mov ecx, r13d
000ca1eb  e8f0550700               call 0x13f7e0
000ca1f0  448be0                   mov r12d, eax
000ca1f3  418bc4                   mov eax, r12d
000ca1f6  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca1fe  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca202  48c7836001000000000000   mov qword ptr [rbx + 0x160], 0
000ca20d  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca211  0f87a4000000             ja 0xca2bb
000ca217  0faee8                   lfence
000ca21a  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca21e  48c1e00d                 shl rax, 0xd
000ca222  4881faa01f0000           cmp rdx, 0x1fa0
000ca229  762d                     jbe 0xca258
000ca22b  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000ca230  4c8bca                   mov r9, rdx
000ca233  4c8bc2                   mov r8, rdx
000ca236  498bce                   mov rcx, r14
000ca239  e8b2d6f3ff               call 0x78f0
000ca23e  66ff4614                 inc word ptr [rsi + 0x14]
000ca242  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca246  48c1e00d                 shl rax, 0xd
000ca24a  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca24f  8b4808                   mov ecx, dword ptr [rax + 8]
000ca252  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca256  eb58                     jmp 0xca2b0
000ca258  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000ca25d  418b4608                 mov eax, dword ptr [r14 + 8]
000ca261  483bc2                   cmp rax, rdx
000ca264  7317                     jae 0xca27d
000ca266  660f1f0400               nop word ptr [rax + rax]
000ca26b  0f1f440000               nop dword ptr [rax + rax]
000ca270  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000ca274  418b4608                 mov eax, dword ptr [r14 + 8]
000ca278  483bc2                   cmp rax, rdx
000ca27b  72f3                     jb 0xca270
000ca27d  418b7e08                 mov edi, dword ptr [r14 + 8]
000ca281  4c8bca                   mov r9, rdx
000ca284  41b820000000             mov r8d, 0x20
000ca28a  498bce                   mov rcx, r14
000ca28d  e85ed6f3ff               call 0x78f0
000ca292  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca296  7514                     jne 0xca2ac
000ca298  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca29c  48c1e00d                 shl rax, 0xd
000ca2a0  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca2a5  8b4808                   mov ecx, dword ptr [rax + 8]
000ca2a8  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca2ac  66ff4614                 inc word ptr [rsi + 0x14]
000ca2b0  498d4610                 lea rax, [r14 + 0x10]
000ca2b4  48898360010000           mov qword ptr [rbx + 0x160], rax
000ca2bb  4c897c2420               mov qword ptr [rsp + 0x20], r15
000ca2c0  458bcc                   mov r9d, r12d
000ca2c3  458bc5                   mov r8d, r13d
000ca2c6  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000ca2cd  488bcb                   mov rcx, rbx
000ca2d0  e8fb790700               call 0x141cd0
000ca2d5  85c0                     test eax, eax
000ca2d7  0f8491feffff             je 0xca16e
000ca2dd  410f100f                 movups xmm1, xmmword ptr [r15]
000ca2e1  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000ca2e5  410f104710               movups xmm0, xmmword ptr [r15 + 0x10]
000ca2ea  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000ca2ee  66480f7eca               movq rdx, xmm1
000ca2f3  48c1ea20                 shr rdx, 0x20
000ca2f7  f6c201                   test dl, 1
000ca2fa  0f8582050000             jne 0xca882
000ca300  81e22ffbffff             and edx, 0xfffffb2f
000ca306  81ca20020000             or edx, 0x220
000ca30c  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000ca310  48c1e820                 shr rax, 0x20
000ca314  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000ca318  498bc8                   mov rcx, r8
000ca31b  48c1e920                 shr rcx, 0x20
000ca31f  49c1e810                 shr r8, 0x10
000ca323  89442438                 mov dword ptr [rsp + 0x38], eax
000ca327  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000ca32a  89442430                 mov dword ptr [rsp + 0x30], eax
000ca32e  894c2428                 mov dword ptr [rsp + 0x28], ecx
000ca332  664489442420             mov word ptr [rsp + 0x20], r8w
000ca338  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000ca33d  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000ca341  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000ca344  e8c775f4ff               call 0x11910
000ca349  48898380000000           mov qword ptr [rbx + 0x80], rax
000ca350  4885c0                   test rax, rax
000ca353  0f95c0                   setne al
000ca356  84c0                     test al, al
000ca358  0f8524050000             jne 0xca882
000ca35e  33db                     xor ebx, ebx
000ca360  e94c050000               jmp 0xca8b1
000ca365  488bd6                   mov rdx, rsi
000ca368  b9f0050000               mov ecx, 0x5f0
000ca36d  e80e7ff4ff               call 0x12280
000ca372  48894560                 mov qword ptr [rbp + 0x60], rax
000ca376  4885c0                   test rax, rax
000ca379  740d                     je 0xca388
000ca37b  488bc8                   mov rcx, rax
000ca37e  e86d360000               call 0xcd9f0
000ca383  488bd8                   mov rbx, rax
000ca386  eb03                     jmp 0xca38b
000ca388  498bdd                   mov rbx, r13
000ca38b  488bbd90000000           mov rdi, qword ptr [rbp + 0x90]
000ca392  8b4704                   mov eax, dword ptr [rdi + 4]
000ca395  2573020000               and eax, 0x273
000ca39a  448bad88000000           mov r13d, dword ptr [rbp + 0x88]
000ca3a1  83f802                   cmp eax, 2
000ca3a4  7527                     jne 0xca3cd
000ca3a6  803d8b7a260000           cmp byte ptr [rip + 0x267a8b], 0
000ca3ad  741e                     je 0xca3cd
000ca3af  8b0537a72400             mov eax, dword ptr [rip + 0x24a737]
000ca3b5  83f801                   cmp eax, 1
000ca3b8  7613                     jbe 0xca3cd
000ca3ba  c7834805000001000000     mov dword ptr [rbx + 0x548], 1
000ca3c4  448b2521a72400           mov r12d, dword ptr [rip + 0x24a721]
000ca3cb  eb15                     jmp 0xca3e2
000ca3cd  c7834805000000000000     mov dword ptr [rbx + 0x548], 0
000ca3d7  418bcd                   mov ecx, r13d
000ca3da  e801540700               call 0x13f7e0
000ca3df  448be0                   mov r12d, eax
000ca3e2  418bc4                   mov eax, r12d
000ca3e5  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca3ed  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca3f1  48c7832805000000000000   mov qword ptr [rbx + 0x528], 0
000ca3fc  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca400  0f87b0000000             ja 0xca4b6
000ca406  0faee8                   lfence
000ca409  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca40d  48c1e00d                 shl rax, 0xd
000ca411  4881faa01f0000           cmp rdx, 0x1fa0
000ca418  762d                     jbe 0xca447
000ca41a  4c8b7c30f0               mov r15, qword ptr [rax + rsi - 0x10]
000ca41f  4c8bca                   mov r9, rdx
000ca422  4c8bc2                   mov r8, rdx
000ca425  498bcf                   mov rcx, r15
000ca428  e8c3d4f3ff               call 0x78f0
000ca42d  66ff4614                 inc word ptr [rsi + 0x14]
000ca431  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca435  48c1e00d                 shl rax, 0xd
000ca439  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca43e  8b4808                   mov ecx, dword ptr [rax + 8]
000ca441  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca445  eb60                     jmp 0xca4a7
000ca447  4c8b7c30f8               mov r15, qword ptr [rax + rsi - 8]
000ca44c  418b4708                 mov eax, dword ptr [r15 + 8]
000ca450  483bc2                   cmp rax, rdx
000ca453  7318                     jae 0xca46d
000ca455  660f1f0400               nop word ptr [rax + rax]
000ca45a  660f1f440000             nop word ptr [rax + rax]
000ca460  4d8b7f18                 mov r15, qword ptr [r15 + 0x18]
000ca464  418b4708                 mov eax, dword ptr [r15 + 8]
000ca468  483bc2                   cmp rax, rdx
000ca46b  72f3                     jb 0xca460
000ca46d  418b7f08                 mov edi, dword ptr [r15 + 8]
000ca471  4c8bca                   mov r9, rdx
000ca474  41b820000000             mov r8d, 0x20
000ca47a  498bcf                   mov rcx, r15
000ca47d  e86ed4f3ff               call 0x78f0
000ca482  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca486  7514                     jne 0xca49c
000ca488  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca48c  48c1e00d                 shl rax, 0xd
000ca490  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca495  8b4808                   mov ecx, dword ptr [rax + 8]
000ca498  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca49c  66ff4614                 inc word ptr [rsi + 0x14]
000ca4a0  488bbd90000000           mov rdi, qword ptr [rbp + 0x90]
000ca4a7  498d4710                 lea rax, [r15 + 0x10]
000ca4ab  48898328050000           mov qword ptr [rbx + 0x528], rax
000ca4b2  4c8b7d58                 mov r15, qword ptr [rbp + 0x58]
000ca4b6  48897c2420               mov qword ptr [rsp + 0x20], rdi
000ca4bb  458bcc                   mov r9d, r12d
000ca4be  458bc5                   mov r8d, r13d
000ca4c1  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000ca4c8  488bcb                   mov rcx, rbx
000ca4cb  e8d0730700               call 0x1418a0
000ca4d0  85c0                     test eax, eax
000ca4d2  0f8496fcffff             je 0xca16e
000ca4d8  4533ed                   xor r13d, r13d
000ca4db  4c89ab80000000           mov qword ptr [rbx + 0x80], r13
000ca4e2  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000ca4ec  4489b38c000000           mov dword ptr [rbx + 0x8c], r14d
000ca4f3  4c89ab38040000           mov qword ptr [rbx + 0x438], r13
000ca4fa  4489ab40040000           mov dword ptr [rbx + 0x440], r13d
000ca501  4c89ab48040000           mov qword ptr [rbx + 0x448], r13
000ca508  488d8b90000000           lea rcx, [rbx + 0x90]
000ca50f  4c8bcb                   mov r9, rbx
000ca512  458bc6                   mov r8d, r14d
000ca515  498bd7                   mov rdx, r15
000ca518  e883de0900               call 0x1683a0
000ca51d  e963030000               jmp 0xca885
000ca522  488bd6                   mov rdx, rsi
000ca525  b9f8050000               mov ecx, 0x5f8
000ca52a  e8517df4ff               call 0x12280
000ca52f  48894560                 mov qword ptr [rbp + 0x60], rax
000ca533  4885c0                   test rax, rax
000ca536  740d                     je 0xca545
000ca538  488bc8                   mov rcx, rax
000ca53b  e830350000               call 0xcda70
000ca540  488bd8                   mov rbx, rax
000ca543  eb03                     jmp 0xca548
000ca545  498bdd                   mov rbx, r13
000ca548  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000ca54f  418b4504                 mov eax, dword ptr [r13 + 4]
000ca553  2573020000               and eax, 0x273
000ca558  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000ca55e  83f802                   cmp eax, 2
000ca561  7527                     jne 0xca58a
000ca563  803dce78260000           cmp byte ptr [rip + 0x2678ce], 0
000ca56a  741e                     je 0xca58a
000ca56c  8b057aa52400             mov eax, dword ptr [rip + 0x24a57a]
000ca572  83f801                   cmp eax, 1
000ca575  7613                     jbe 0xca58a
000ca577  c7835005000001000000     mov dword ptr [rbx + 0x550], 1
000ca581  448b2564a52400           mov r12d, dword ptr [rip + 0x24a564]
000ca588  eb14                     jmp 0xca59e
000ca58a  c7835005000000000000     mov dword ptr [rbx + 0x550], 0
000ca594  8bcf                     mov ecx, edi
000ca596  e845520700               call 0x13f7e0
000ca59b  448be0                   mov r12d, eax
000ca59e  418bc4                   mov eax, r12d
000ca5a1  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca5a9  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca5ad  48c7833005000000000000   mov qword ptr [rbx + 0x530], 0
000ca5b8  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca5bc  0f87a4000000             ja 0xca666
000ca5c2  0faee8                   lfence
000ca5c5  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca5c9  48c1e00d                 shl rax, 0xd
000ca5cd  4881faa01f0000           cmp rdx, 0x1fa0
000ca5d4  762d                     jbe 0xca603
000ca5d6  4c8b7c30f0               mov r15, qword ptr [rax + rsi - 0x10]
000ca5db  4c8bca                   mov r9, rdx
000ca5de  4c8bc2                   mov r8, rdx
000ca5e1  498bcf                   mov rcx, r15
000ca5e4  e807d3f3ff               call 0x78f0
000ca5e9  66ff4614                 inc word ptr [rsi + 0x14]
000ca5ed  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca5f1  48c1e00d                 shl rax, 0xd
000ca5f5  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca5fa  8b4808                   mov ecx, dword ptr [rax + 8]
000ca5fd  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca601  eb54                     jmp 0xca657
000ca603  4c8b7c30f8               mov r15, qword ptr [rax + rsi - 8]
000ca608  418b4708                 mov eax, dword ptr [r15 + 8]
000ca60c  483bc2                   cmp rax, rdx
000ca60f  730d                     jae 0xca61e
000ca611  4d8b7f18                 mov r15, qword ptr [r15 + 0x18]
000ca615  418b4708                 mov eax, dword ptr [r15 + 8]
000ca619  483bc2                   cmp rax, rdx
000ca61c  72f3                     jb 0xca611
000ca61e  418b7f08                 mov edi, dword ptr [r15 + 8]
000ca622  4c8bca                   mov r9, rdx
000ca625  41b820000000             mov r8d, 0x20
000ca62b  498bcf                   mov rcx, r15
000ca62e  e8bdd2f3ff               call 0x78f0
000ca633  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca637  7514                     jne 0xca64d
000ca639  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca63d  48c1e00d                 shl rax, 0xd
000ca641  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca646  8b4808                   mov ecx, dword ptr [rax + 8]
000ca649  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca64d  66ff4614                 inc word ptr [rsi + 0x14]
000ca651  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000ca657  498d4710                 lea rax, [r15 + 0x10]
000ca65b  48898330050000           mov qword ptr [rbx + 0x530], rax
000ca662  4c8b7d58                 mov r15, qword ptr [rbp + 0x58]
000ca666  4c896c2420               mov qword ptr [rsp + 0x20], r13
000ca66b  458bcc                   mov r9d, r12d
000ca66e  448bc7                   mov r8d, edi
000ca671  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000ca678  488bcb                   mov rcx, rbx
000ca67b  e8807a0700               call 0x142100
000ca680  85c0                     test eax, eax
000ca682  0f84e6faffff             je 0xca16e
000ca688  410f104d00               movups xmm1, xmmword ptr [r13]
000ca68d  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000ca691  410f104510               movups xmm0, xmmword ptr [r13 + 0x10]
000ca696  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000ca69a  66480f7eca               movq rdx, xmm1
000ca69f  48c1ea20                 shr rdx, 0x20
000ca6a3  f6c201                   test dl, 1
000ca6a6  0f852cfeffff             jne 0xca4d8
000ca6ac  81e22ffbffff             and edx, 0xfffffb2f
000ca6b2  81ca20020000             or edx, 0x220
000ca6b8  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000ca6bc  48c1e820                 shr rax, 0x20
000ca6c0  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000ca6c4  498bc8                   mov rcx, r8
000ca6c7  48c1e920                 shr rcx, 0x20
000ca6cb  49c1e810                 shr r8, 0x10
000ca6cf  89442438                 mov dword ptr [rsp + 0x38], eax
000ca6d3  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000ca6d6  89442430                 mov dword ptr [rsp + 0x30], eax
000ca6da  894c2428                 mov dword ptr [rsp + 0x28], ecx
000ca6de  664489442420             mov word ptr [rsp + 0x20], r8w
000ca6e4  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000ca6e9  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000ca6ed  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000ca6f0  e81b72f4ff               call 0x11910
000ca6f5  48898350040000           mov qword ptr [rbx + 0x450], rax
000ca6fc  4885c0                   test rax, rax
000ca6ff  0f95c0                   setne al
000ca702  84c0                     test al, al
000ca704  0f85cefdffff             jne 0xca4d8
000ca70a  33db                     xor ebx, ebx
000ca70c  e9a0010000               jmp 0xca8b1
000ca711  488bd6                   mov rdx, rsi
000ca714  b998020000               mov ecx, 0x298
000ca719  e8627bf4ff               call 0x12280
000ca71e  48894558                 mov qword ptr [rbp + 0x58], rax
000ca722  4885c0                   test rax, rax
000ca725  740d                     je 0xca734
000ca727  488bc8                   mov rcx, rax
000ca72a  e8c1330000               call 0xcdaf0
000ca72f  488bd8                   mov rbx, rax
000ca732  eb03                     jmp 0xca737
000ca734  498bdd                   mov rbx, r13
000ca737  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000ca73e  418b4504                 mov eax, dword ptr [r13 + 4]
000ca742  2573020000               and eax, 0x273
000ca747  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000ca74e  83f802                   cmp eax, 2
000ca751  7527                     jne 0xca77a
000ca753  803dde76260000           cmp byte ptr [rip + 0x2676de], 0
000ca75a  741e                     je 0xca77a
000ca75c  8b058aa32400             mov eax, dword ptr [rip + 0x24a38a]
000ca762  83f801                   cmp eax, 1
000ca765  7613                     jbe 0xca77a
000ca767  c783f001000001000000     mov dword ptr [rbx + 0x1f0], 1
000ca771  448b3d74a32400           mov r15d, dword ptr [rip + 0x24a374]
000ca778  eb15                     jmp 0xca78f
000ca77a  c783f001000000000000     mov dword ptr [rbx + 0x1f0], 0
000ca784  418bcc                   mov ecx, r12d
000ca787  e854500700               call 0x13f7e0
000ca78c  448bf8                   mov r15d, eax
000ca78f  418bc7                   mov eax, r15d
000ca792  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca79a  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca79e  48c783d001000000000000   mov qword ptr [rbx + 0x1d0], 0
000ca7a9  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca7ad  0f879a000000             ja 0xca84d
000ca7b3  0faee8                   lfence
000ca7b6  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca7ba  48c1e00d                 shl rax, 0xd
000ca7be  4881faa01f0000           cmp rdx, 0x1fa0
000ca7c5  762d                     jbe 0xca7f4
000ca7c7  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000ca7cc  4c8bca                   mov r9, rdx
000ca7cf  4c8bc2                   mov r8, rdx
000ca7d2  498bce                   mov rcx, r14
000ca7d5  e816d1f3ff               call 0x78f0
000ca7da  66ff4614                 inc word ptr [rsi + 0x14]
000ca7de  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca7e2  48c1e00d                 shl rax, 0xd
000ca7e6  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca7eb  8b4808                   mov ecx, dword ptr [rax + 8]
000ca7ee  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca7f2  eb4e                     jmp 0xca842
000ca7f4  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000ca7f9  418b4608                 mov eax, dword ptr [r14 + 8]
000ca7fd  483bc2                   cmp rax, rdx
000ca800  730d                     jae 0xca80f
000ca802  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000ca806  418b4608                 mov eax, dword ptr [r14 + 8]
000ca80a  483bc2                   cmp rax, rdx
000ca80d  72f3                     jb 0xca802
000ca80f  418b7e08                 mov edi, dword ptr [r14 + 8]
000ca813  4c8bca                   mov r9, rdx
000ca816  41b820000000             mov r8d, 0x20
000ca81c  498bce                   mov rcx, r14
000ca81f  e8ccd0f3ff               call 0x78f0
000ca824  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca828  7514                     jne 0xca83e
000ca82a  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca82e  48c1e00d                 shl rax, 0xd
000ca832  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca837  8b4808                   mov ecx, dword ptr [rax + 8]
000ca83a  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca83e  66ff4614                 inc word ptr [rsi + 0x14]
000ca842  498d4610                 lea rax, [r14 + 0x10]
000ca846  488983d0010000           mov qword ptr [rbx + 0x1d0], rax
000ca84d  4c896c2420               mov qword ptr [rsp + 0x20], r13
000ca852  458bcf                   mov r9d, r15d
000ca855  458bc4                   mov r8d, r12d
000ca858  488bbd80000000           mov rdi, qword ptr [rbp + 0x80]
000ca85f  488bd7                   mov rdx, rdi
000ca862  488bcb                   mov rcx, rbx
000ca865  e8c67c0700               call 0x142530
000ca86a  85c0                     test eax, eax
000ca86c  0f84fcf8ffff             je 0xca16e
000ca872  440fb64744               movzx r8d, byte ptr [rdi + 0x44]
000ca877  498bd5                   mov rdx, r13
000ca87a  488bcb                   mov rcx, rbx
000ca87d  e8fe290200               call 0xed280
000ca882  4533ed                   xor r13d, r13d
000ca885  448b6578                 mov r12d, dword ptr [rbp + 0x78]
000ca889  4885db                   test rbx, rbx
000ca88c  7423                     je 0xca8b1
000ca88e  4c896b50                 mov qword ptr [rbx + 0x50], r13
000ca892  4c896b60                 mov qword ptr [rbx + 0x60], r13
000ca896  4c896b58                 mov qword ptr [rbx + 0x58], r13
000ca89a  c7437801000000           mov dword ptr [rbx + 0x78], 1
000ca8a1  41c1ec17                 shr r12d, 0x17
000ca8a5  4183e401                 and r12d, 1
000ca8a9  4489637c                 mov dword ptr [rbx + 0x7c], r12d
000ca8ad  834b2802                 or dword ptr [rbx + 0x28], 2
000ca8b1  488bc3                   mov rax, rbx
000ca8b4  488b9c24b0000000         mov rbx, qword ptr [rsp + 0xb0]
000ca8bc  4883c470                 add rsp, 0x70
000ca8c0  415f                     pop r15
000ca8c2  415e                     pop r14
000ca8c4  415d                     pop r13
000ca8c6  415c                     pop r12
000ca8c8  5f                       pop rdi
000ca8c9  5e                       pop rsi
000ca8ca  5d                       pop rbp
000ca8cb  c3                       ret
000ca8cc  b098                     mov al, 0x98
000ca8ce  0c00                     or al, 0
000ca8d0  1d990c00a3               sbb eax, 0xa3000c99
000ca8d5  9c                       pushfq
000ca8d6  0c00                     or al, 0
000ca8d8  149e                     adc al, 0x9e
000ca8da  0c00                     or al, 0
