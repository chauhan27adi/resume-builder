; `WorkDispatcher::CreateAndEnqueueTask'::`1'::dtor$0
; sqldk.dll, primary RVA 0x219690, 69 bytes in 1 chunk(s)

; chunk at RVA 0x219690 (69 bytes)
00219690  4055                     push rbp
00219692  4883ec30                 sub rsp, 0x30
00219696  488bea                   mov rbp, rdx
00219699  488b95b8000000           mov rdx, qword ptr [rbp + 0xb8]
002196a0  4881c2780e0000           add rdx, 0xe78
002196a7  c644242806               mov byte ptr [rsp + 0x28], 6
002196ac  8b85c0000000             mov eax, dword ptr [rbp + 0xc0]
002196b2  89442420                 mov dword ptr [rsp + 0x20], eax
002196b6  4c8d0db30b0600           lea r9, [rip + 0x60bb3]
002196bd  41b801000000             mov r8d, 1
002196c3  488b12                   mov rdx, qword ptr [rdx]
002196c6  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
002196ca  e841d8deff               call 0x6f10
002196cf  4883c430                 add rsp, 0x30
002196d3  5d                       pop rbp
002196d4  c3                       ret
