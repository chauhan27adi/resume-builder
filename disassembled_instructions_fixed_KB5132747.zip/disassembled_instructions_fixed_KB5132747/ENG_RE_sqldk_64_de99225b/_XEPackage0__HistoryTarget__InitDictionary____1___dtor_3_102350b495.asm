; `XEPackage0::HistoryTarget::InitDictionary'::`1'::dtor$3
; sqldk.dll, primary RVA 0x2329ce, 48 bytes in 1 chunk(s)

; chunk at RVA 0x2329ce (48 bytes)
002329ce  4055                     push rbp
002329d0  4883ec20                 sub rsp, 0x20
002329d4  488bea                   mov rbp, rdx
002329d7  4c8b85f0000000           mov r8, qword ptr [rbp + 0xf0]
002329de  4981c030200000           add r8, 0x2030
002329e5  4d8b00                   mov r8, qword ptr [r8]
002329e8  488b5578                 mov rdx, qword ptr [rbp + 0x78]
002329ec  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
002329f3  e818e6dcff               call 0x1010
002329f8  4883c420                 add rsp, 0x20
002329fc  5d                       pop rbp
002329fd  c3                       ret
