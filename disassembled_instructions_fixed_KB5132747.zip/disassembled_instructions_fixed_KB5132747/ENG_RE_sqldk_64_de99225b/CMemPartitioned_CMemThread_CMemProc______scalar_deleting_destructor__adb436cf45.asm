; CMemPartitioned<CMemThread<CMemProc> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcde00, 104 bytes in 1 chunk(s)

; chunk at RVA 0xcde00 (104 bytes)
000cde00  48894c2408               mov qword ptr [rsp + 8], rcx
000cde05  57                       push rdi
000cde06  4883ec30                 sub rsp, 0x30
000cde0a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cde13  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cde18  8bda                     mov ebx, edx
000cde1a  488bf9                   mov rdi, rcx
000cde1d  488d05040c1800           lea rax, [rip + 0x180c04]
000cde24  488901                   mov qword ptr [rcx], rax
000cde27  488d8108020000           lea rax, [rcx + 0x208]
000cde2e  4889442450               mov qword ptr [rsp + 0x50], rax
000cde33  488d0d06bd1600           lea rcx, [rip + 0x16bd06]
000cde3a  488908                   mov qword ptr [rax], rcx
000cde3d  488bcf                   mov rcx, rdi
000cde40  e83b4e0000               call 0xd2c80
000cde45  83e305                   and ebx, 5
000cde48  80fb05                   cmp bl, 5
000cde4b  750d                     jne 0xcde5a
000cde4d  ba40020000               mov edx, 0x240
000cde52  488bcf                   mov rcx, rdi
000cde55  e8b631f3ff               call 0x1010
000cde5a  488bc7                   mov rax, rdi
000cde5d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cde62  4883c430                 add rsp, 0x30
000cde66  5f                       pop rdi
000cde67  c3                       ret
