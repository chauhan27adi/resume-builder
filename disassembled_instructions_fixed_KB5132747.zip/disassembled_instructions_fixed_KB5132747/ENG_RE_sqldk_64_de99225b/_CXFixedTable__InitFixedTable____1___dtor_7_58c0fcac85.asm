; `CXFixedTable::InitFixedTable'::`1'::dtor$7
; sqldk.dll, primary RVA 0x216d9e, 37 bytes in 1 chunk(s)

; chunk at RVA 0x216d9e (37 bytes)
00216d9e  4055                     push rbp
00216da0  4883ec20                 sub rsp, 0x20
00216da4  488bea                   mov rbp, rdx
00216da7  4533c0                   xor r8d, r8d
00216daa  488b95e0000000           mov rdx, qword ptr [rbp + 0xe0]
00216db1  488b8df8000000           mov rcx, qword ptr [rbp + 0xf8]
00216db8  e853a2deff               call 0x1010
00216dbd  4883c420                 add rsp, 0x20
00216dc1  5d                       pop rbp
00216dc2  c3                       ret
