; `XE_MetadataStore::DeserializeMetadata'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2160b0, 31 bytes in 1 chunk(s)

; chunk at RVA 0x2160b0 (31 bytes)
002160b0  4055                     push rbp
002160b2  4883ec20                 sub rsp, 0x20
002160b6  488bea                   mov rbp, rdx
002160b9  4533c0                   xor r8d, r8d
002160bc  488b5528                 mov rdx, qword ptr [rbp + 0x28]
002160c0  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
002160c4  e847afdeff               call 0x1010
002160c9  4883c420                 add rsp, 0x20
002160cd  5d                       pop rbp
002160ce  c3                       ret
