; TEnumerator<TList<PoolList,SOS_ResourcePool,0,TListSLock> >::~TEnumerator<TList<PoolList,SOS_ResourcePool,0,TListSLock> >
; sqldk.dll, primary RVA 0x18e960, 203 bytes in 1 chunk(s)

; chunk at RVA 0x18e960 (203 bytes)
0018e960  48895c2410               mov qword ptr [rsp + 0x10], rbx
0018e965  48896c2418               mov qword ptr [rsp + 0x18], rbp
0018e96a  4889742420               mov qword ptr [rsp + 0x20], rsi
0018e96f  57                       push rdi
0018e970  4883ec20                 sub rsp, 0x20
0018e974  488b39                   mov rdi, qword ptr [rcx]
0018e977  33ed                     xor ebp, ebp
0018e979  488bd9                   mov rbx, rcx
0018e97c  beffffffff               mov esi, 0xffffffff
0018e981  4885ff                   test rdi, rdi
0018e984  7436                     je 0x18e9bc
0018e986  8bc6                     mov eax, esi
0018e988  f00fc14718               lock xadd dword ptr [rdi + 0x18], eax
0018e98d  83f801                   cmp eax, 1
0018e990  7527                     jne 0x18e9b9
0018e992  48396f08                 cmp qword ptr [rdi + 8], rbp
0018e996  740c                     je 0x18e9a4
0018e998  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
0018e99c  488bd7                   mov rdx, rdi
0018e99f  e80c2ae8ff               call 0x113b0
0018e9a4  488bcf                   mov rcx, rdi
0018e9a7  e844c2edff               call 0x6abf0
0018e9ac  bae80b0000               mov edx, 0xbe8
0018e9b1  488bcf                   mov rcx, rdi
0018e9b4  e87785e7ff               call 0x6f30
0018e9b9  48892b                   mov qword ptr [rbx], rbp
0018e9bc  488b7b08                 mov rdi, qword ptr [rbx + 8]
0018e9c0  4885ff                   test rdi, rdi
0018e9c3  7435                     je 0x18e9fa
0018e9c5  f00fc17718               lock xadd dword ptr [rdi + 0x18], esi
0018e9ca  83fe01                   cmp esi, 1
0018e9cd  7527                     jne 0x18e9f6
0018e9cf  48396f08                 cmp qword ptr [rdi + 8], rbp
0018e9d3  740c                     je 0x18e9e1
0018e9d5  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
0018e9d9  488bd7                   mov rdx, rdi
0018e9dc  e8cf29e8ff               call 0x113b0
0018e9e1  488bcf                   mov rcx, rdi
0018e9e4  e807c2edff               call 0x6abf0
0018e9e9  bae80b0000               mov edx, 0xbe8
0018e9ee  488bcf                   mov rcx, rdi
0018e9f1  e83a85e7ff               call 0x6f30
0018e9f6  48896b08                 mov qword ptr [rbx + 8], rbp
0018e9fa  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0018e9fe  4885c9                   test rcx, rcx
0018ea01  740f                     je 0x18ea12
0018ea03  8b5320                   mov edx, dword ptr [rbx + 0x20]
0018ea06  e8f571e7ff               call 0x5c00
0018ea0b  48896b18                 mov qword ptr [rbx + 0x18], rbp
0018ea0f  896b20                   mov dword ptr [rbx + 0x20], ebp
0018ea12  488b742448               mov rsi, qword ptr [rsp + 0x48]
0018ea17  48896b10                 mov qword ptr [rbx + 0x10], rbp
0018ea1b  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
0018ea20  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
0018ea25  4883c420                 add rsp, 0x20
0018ea29  5f                       pop rdi
0018ea2a  c3                       ret
