; XE_TargetEntry::~XE_TargetEntry
; sqldk.dll, primary RVA 0x1f4aa0, 196 bytes in 5 chunk(s)

; chunk at RVA 0x1f4aa0 (33 bytes)
001f4aa0  4056                     push rsi
001f4aa2  4883ec20                 sub rsp, 0x20
001f4aa6  488d7140                 lea rsi, [rcx + 0x40]
001f4aaa  488d05075f0b00           lea rax, [rip + 0xb5f07]
001f4ab1  488901                   mov qword ptr [rcx], rax
001f4ab4  488b4e08                 mov rcx, qword ptr [rsi + 8]
001f4ab8  483bce                   cmp rcx, rsi
001f4abb  0f849d000000             je 0x1f4b5e

; chunk at RVA 0x1f4ac1 (37 bytes)
001f4ac1  48895c2438               mov qword ptr [rsp + 0x38], rbx
001f4ac6  488d41d8                 lea rax, [rcx - 0x28]
001f4aca  48896c2440               mov qword ptr [rsp + 0x40], rbp
001f4acf  33ed                     xor ebp, ebp
001f4ad1  4885c9                   test rcx, rcx
001f4ad4  8bdd                     mov ebx, ebp
001f4ad6  480f45d8                 cmovne rbx, rax
001f4ada  4885db                   test rbx, rbx
001f4add  7475                     je 0x1f4b54
001f4adf  488b4b30                 mov rcx, qword ptr [rbx + 0x30]
001f4ae3  483bce                   cmp rcx, rsi

; chunk at RVA 0x1f4ae6 (110 bytes)
001f4ae6  48897c2448               mov qword ptr [rsp + 0x48], rdi
001f4aeb  8bfd                     mov edi, ebp
001f4aed  480f44cd                 cmove rcx, rbp
001f4af1  4885c9                   test rcx, rcx
001f4af4  488d41d8                 lea rax, [rcx - 0x28]
001f4af8  480f45f8                 cmovne rdi, rax
001f4afc  0f1f4000                 nop dword ptr [rax]
001f4b00  b8ffffffff               mov eax, 0xffffffff
001f4b05  f00fc14318               lock xadd dword ptr [rbx + 0x18], eax
001f4b0a  83f801                   cmp eax, 1
001f4b0d  751a                     jne 0x1f4b29
001f4b0f  48396b10                 cmp qword ptr [rbx + 0x10], rbp
001f4b13  740c                     je 0x1f4b21
001f4b15  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
001f4b19  488bd3                   mov rdx, rbx
001f4b1c  e8bf59ffff               call 0x1ea4e0
001f4b21  488bcb                   mov rcx, rbx
001f4b24  e8e7000000               call 0x1f4c10
001f4b29  488bdf                   mov rbx, rdi
001f4b2c  4885ff                   test rdi, rdi
001f4b2f  7419                     je 0x1f4b4a
001f4b31  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
001f4b35  488bfd                   mov rdi, rbp
001f4b38  483bce                   cmp rcx, rsi
001f4b3b  480f44cd                 cmove rcx, rbp
001f4b3f  4885c9                   test rcx, rcx
001f4b42  488d41d8                 lea rax, [rcx - 0x28]
001f4b46  480f45f8                 cmovne rdi, rax
001f4b4a  4885db                   test rbx, rbx
001f4b4d  75b1                     jne 0x1f4b00
001f4b4f  488b7c2448               mov rdi, qword ptr [rsp + 0x48]

; chunk at RVA 0x1f4b54 (10 bytes)
001f4b54  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
001f4b59  488b6c2440               mov rbp, qword ptr [rsp + 0x40]

; chunk at RVA 0x1f4b5e (6 bytes)
001f4b5e  4883c420                 add rsp, 0x20
001f4b62  5e                       pop rsi
001f4b63  c3                       ret
