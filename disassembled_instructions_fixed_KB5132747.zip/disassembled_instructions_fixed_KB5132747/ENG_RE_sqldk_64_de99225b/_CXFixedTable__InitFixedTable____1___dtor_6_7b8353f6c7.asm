; `CXFixedTable::InitFixedTable'::`1'::dtor$6
; sqldk.dll, primary RVA 0x216d79, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216d79 (31 bytes)
00216d79  4055                     push rbp
00216d7b  4883ec20                 sub rsp, 0x20
00216d7f  488bea                   mov rbp, rdx
00216d82  4533c0                   xor r8d, r8d
00216d85  488b5528                 mov rdx, qword ptr [rbp + 0x28]
00216d89  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
00216d8d  e87ea2deff               call 0x1010
00216d92  4883c420                 add rsp, 0x20
00216d96  5d                       pop rbp
00216d97  c3                       ret
