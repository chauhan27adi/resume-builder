; XE_AutoP<ColumnTransformRule>::~XE_AutoP<ColumnTransformRule>
; sqldk.dll, primary RVA 0x4dbd0, 61 bytes in 1 chunk(s)

; chunk at RVA 0x4dbd0 (61 bytes)
0004dbd0  48894c2408               mov qword ptr [rsp + 8], rcx
0004dbd5  53                       push rbx
0004dbd6  4883ec30                 sub rsp, 0x30
0004dbda  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0004dbe3  488bd9                   mov rbx, rcx
0004dbe6  488b09                   mov rcx, qword ptr [rcx]
0004dbe9  4885c9                   test rcx, rcx
0004dbec  7406                     je 0x4dbf4
0004dbee  ff155c742c00             call qword ptr [rip + 0x2c745c]
0004dbf4  48c70300000000           mov qword ptr [rbx], 0
0004dbfb  ba08000000               mov edx, 8
0004dc00  488b0b                   mov rcx, qword ptr [rbx]
0004dc03  4883c430                 add rsp, 0x30
0004dc07  5b                       pop rbx
0004dc08  e92393fbff               jmp 0x6f30
