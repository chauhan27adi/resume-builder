; CMemAligned<CMemDbg<CMemObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xd05b0, 79 bytes in 1 chunk(s)

; chunk at RVA 0xd05b0 (79 bytes)
000d05b0  48894c2408               mov qword ptr [rsp + 8], rcx
000d05b5  57                       push rdi
000d05b6  4883ec30                 sub rsp, 0x30
000d05ba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d05c3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d05c8  8bda                     mov ebx, edx
000d05ca  488bf9                   mov rdi, rcx
000d05cd  488d055cb11700           lea rax, [rip + 0x17b15c]
000d05d4  488901                   mov qword ptr [rcx], rax
000d05d7  e8f4df0900               call 0x16e5d0
000d05dc  83e305                   and ebx, 5
000d05df  80fb05                   cmp bl, 5
000d05e2  750d                     jne 0xd05f1
000d05e4  ba00050000               mov edx, 0x500
000d05e9  488bcf                   mov rcx, rdi
000d05ec  e81f0af3ff               call 0x1010
000d05f1  488bc7                   mov rax, rdi
000d05f4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d05f9  4883c430                 add rsp, 0x30
000d05fd  5f                       pop rdi
000d05fe  c3                       ret
