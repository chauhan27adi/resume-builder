; CMemDetour<CMemThread<CMemLargePageObj> >::~CMemDetour<CMemThread<CMemLargePageObj> >
; sqldk.dll, primary RVA 0x11af60, 59 bytes in 1 chunk(s)

; chunk at RVA 0x11af60 (59 bytes)
0011af60  48894c2408               mov qword ptr [rsp + 8], rcx
0011af65  4883ec38                 sub rsp, 0x38
0011af69  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0011af72  488d052f1d1300           lea rax, [rip + 0x131d2f]
0011af79  488901                   mov qword ptr [rcx], rax
0011af7c  488d81e0020000           lea rax, [rcx + 0x2e0]
0011af83  4889442448               mov qword ptr [rsp + 0x48], rax
0011af88  488d15b1eb1100           lea rdx, [rip + 0x11ebb1]
0011af8f  488910                   mov qword ptr [rax], rdx
0011af92  4883c438                 add rsp, 0x38
0011af96  e98587ffff               jmp 0x113720
