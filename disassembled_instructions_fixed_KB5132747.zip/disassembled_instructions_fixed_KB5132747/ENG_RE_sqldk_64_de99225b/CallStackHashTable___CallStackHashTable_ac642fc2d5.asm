; CallStackHashTable::~CallStackHashTable
; sqldk.dll, primary RVA 0x63610, 120 bytes in 1 chunk(s)

; chunk at RVA 0x63610 (120 bytes)
00063610  48895c2408               mov qword ptr [rsp + 8], rbx
00063615  48896c2410               mov qword ptr [rsp + 0x10], rbp
0006361a  4889742418               mov qword ptr [rsp + 0x18], rsi
0006361f  57                       push rdi
00063620  4883ec20                 sub rsp, 0x20
00063624  488bf1                   mov rsi, rcx
00063627  488d5908                 lea rbx, [rcx + 8]
0006362b  bf80000000               mov edi, 0x80
00063630  33ed                     xor ebp, ebp
00063632  488b0b                   mov rcx, qword ptr [rbx]
00063635  4885c9                   test rcx, rcx
00063638  7411                     je 0x6364b
0006363a  33d2                     xor edx, edx
0006363c  41b800800000             mov r8d, 0x8000
00063642  ff15385f1d00             call qword ptr [rip + 0x1d5f38]
00063648  48892b                   mov qword ptr [rbx], rbp
0006364b  4883c308                 add rbx, 8
0006364f  4883ef01                 sub rdi, 1
00063653  75dd                     jne 0x63632
00063655  488b8e08040000           mov rcx, qword ptr [rsi + 0x408]
0006365c  4883f9ff                 cmp rcx, -1
00063660  7411                     je 0x63673
00063662  ff15b05e1d00             call qword ptr [rip + 0x1d5eb0]
00063668  48c78608040000ffffffff   mov qword ptr [rsi + 0x408], 0xffffffffffffffff
00063673  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00063678  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
0006367d  488b742440               mov rsi, qword ptr [rsp + 0x40]
00063682  4883c420                 add rsp, 0x20
00063686  5f                       pop rdi
00063687  c3                       ret
