; sub_24412
; sqldk.dll, primary RVA 0x24412, 14 bytes in 1 chunk(s)

; chunk at RVA 0x24412 (14 bytes)
00024412  4883c420                 add rsp, 0x20
00024416  5f                       pop rdi
00024417  c3                       ret
00024418  90                       nop
00024419  90                       nop
0002441a  90                       nop
0002441b  90                       nop
0002441c  90                       nop
0002441d  90                       nop
0002441e  90                       nop
0002441f  90                       nop
