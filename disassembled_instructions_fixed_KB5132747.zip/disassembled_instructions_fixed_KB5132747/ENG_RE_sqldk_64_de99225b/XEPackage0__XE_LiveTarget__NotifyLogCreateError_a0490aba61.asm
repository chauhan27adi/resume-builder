; XEPackage0::XE_LiveTarget::NotifyLogCreateError
; sqldk.dll, primary RVA 0x1d0e80, 51 bytes in 1 chunk(s)

; chunk at RVA 0x1d0e80 (51 bytes)
001d0e80  4883ec38                 sub rsp, 0x38
001d0e84  488d0545c30d00           lea rax, [rip + 0xdc345]
001d0e8b  41b958010000             mov r9d, 0x158
001d0e91  4c8d0560ae0d00           lea r8, [rip + 0xdae60]
001d0e98  4889442420               mov qword ptr [rsp + 0x20], rax
001d0e9d  488d1598ae0d00           lea rdx, [rip + 0xdae98]
001d0ea4  b901000000               mov ecx, 1
001d0ea9  e8420ffeff               call 0x1b1df0
001d0eae  4883c438                 add rsp, 0x38
001d0eb2  c3                       ret
