; CMemThread<CMemProc>::~CMemThread<CMemProc>
; sqldk.dll, primary RVA 0xd2c80, 111 bytes in 1 chunk(s)

; chunk at RVA 0xd2c80 (111 bytes)
000d2c80  48894c2408               mov qword ptr [rsp + 8], rcx
000d2c85  53                       push rbx
000d2c86  4883ec30                 sub rsp, 0x30
000d2c8a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d2c93  488bd9                   mov rbx, rcx
000d2c96  488d052b811700           lea rax, [rip + 0x17812b]
000d2c9d  488901                   mov qword ptr [rcx], rax
000d2ca0  488d81a0000000           lea rax, [rcx + 0xa0]
000d2ca7  4889442448               mov qword ptr [rsp + 0x48], rax
000d2cac  488d0d8d6e1600           lea rcx, [rip + 0x166e8d]
000d2cb3  48894830                 mov qword ptr [rax + 0x30], rcx
000d2cb7  488908                   mov qword ptr [rax], rcx
000d2cba  488d0597461700           lea rax, [rip + 0x174697]
000d2cc1  488903                   mov qword ptr [rbx], rax
000d2cc4  488d053d451700           lea rax, [rip + 0x17453d]
000d2ccb  488903                   mov qword ptr [rbx], rax
000d2cce  488d4b38                 lea rcx, [rbx + 0x38]
000d2cd2  e819e9f3ff               call 0x115f0
000d2cd7  90                       nop
000d2cd8  488d4b30                 lea rcx, [rbx + 0x30]
000d2cdc  e80fe9f3ff               call 0x115f0
000d2ce1  90                       nop
000d2ce2  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
000d2ce9  4883c430                 add rsp, 0x30
000d2ced  5b                       pop rbx
000d2cee  c3                       ret
