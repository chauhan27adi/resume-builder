; CMemThread<CMemObj>::~CMemThread<CMemObj>
; sqldk.dll, primary RVA 0x12a190, 111 bytes in 1 chunk(s)

; chunk at RVA 0x12a190 (111 bytes)
0012a190  48894c2408               mov qword ptr [rsp + 8], rcx
0012a195  53                       push rbx
0012a196  4883ec30                 sub rsp, 0x30
0012a19a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0012a1a3  488bd9                   mov rbx, rcx
0012a1a6  488d056bde1100           lea rax, [rip + 0x11de6b]
0012a1ad  488901                   mov qword ptr [rcx], rax
0012a1b0  488d8128010000           lea rax, [rcx + 0x128]
0012a1b7  4889442448               mov qword ptr [rsp + 0x48], rax
0012a1bc  488d0d7df91000           lea rcx, [rip + 0x10f97d]
0012a1c3  48894830                 mov qword ptr [rax + 0x30], rcx
0012a1c7  488908                   mov qword ptr [rax], rcx
0012a1ca  488d0597cd1100           lea rax, [rip + 0x11cd97]
0012a1d1  488903                   mov qword ptr [rbx], rax
0012a1d4  488d052dd01100           lea rax, [rip + 0x11d02d]
0012a1db  488903                   mov qword ptr [rbx], rax
0012a1de  488d4b38                 lea rcx, [rbx + 0x38]
0012a1e2  e80974eeff               call 0x115f0
0012a1e7  90                       nop
0012a1e8  488d4b30                 lea rcx, [rbx + 0x30]
0012a1ec  e8ff73eeff               call 0x115f0
0012a1f1  90                       nop
0012a1f2  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0012a1f9  4883c430                 add rsp, 0x30
0012a1fd  5b                       pop rbx
0012a1fe  c3                       ret
