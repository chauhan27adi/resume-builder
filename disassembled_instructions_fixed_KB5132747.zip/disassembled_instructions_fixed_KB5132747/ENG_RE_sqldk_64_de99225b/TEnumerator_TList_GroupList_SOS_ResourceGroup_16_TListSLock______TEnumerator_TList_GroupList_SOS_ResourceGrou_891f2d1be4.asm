; TEnumerator<TList<GroupList,SOS_ResourceGroup,16,TListSLock> >::~TEnumerator<TList<GroupList,SOS_ResourceGroup,16,TListSLock> >
; sqldk.dll, primary RVA 0x1a5580, 203 bytes in 1 chunk(s)

; chunk at RVA 0x1a5580 (203 bytes)
001a5580  48895c2410               mov qword ptr [rsp + 0x10], rbx
001a5585  48896c2418               mov qword ptr [rsp + 0x18], rbp
001a558a  4889742420               mov qword ptr [rsp + 0x20], rsi
001a558f  57                       push rdi
001a5590  4883ec20                 sub rsp, 0x20
001a5594  488b39                   mov rdi, qword ptr [rcx]
001a5597  33ed                     xor ebp, ebp
001a5599  488bd9                   mov rbx, rcx
001a559c  beffffffff               mov esi, 0xffffffff
001a55a1  4885ff                   test rdi, rdi
001a55a4  7436                     je 0x1a55dc
001a55a6  8bc6                     mov eax, esi
001a55a8  f00fc14728               lock xadd dword ptr [rdi + 0x28], eax
001a55ad  83f801                   cmp eax, 1
001a55b0  7527                     jne 0x1a55d9
001a55b2  48396f18                 cmp qword ptr [rdi + 0x18], rbp
001a55b6  740c                     je 0x1a55c4
001a55b8  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
001a55bc  488bd7                   mov rdx, rdi
001a55bf  e88ca7e6ff               call 0xfd50
001a55c4  488bcf                   mov rcx, rdi
001a55c7  e844cfffff               call 0x1a2510
001a55cc  ba880d0000               mov edx, 0xd88
001a55d1  488bcf                   mov rcx, rdi
001a55d4  e85719e6ff               call 0x6f30
001a55d9  48892b                   mov qword ptr [rbx], rbp
001a55dc  488b7b08                 mov rdi, qword ptr [rbx + 8]
001a55e0  4885ff                   test rdi, rdi
001a55e3  7435                     je 0x1a561a
001a55e5  f00fc17728               lock xadd dword ptr [rdi + 0x28], esi
001a55ea  83fe01                   cmp esi, 1
001a55ed  7527                     jne 0x1a5616
001a55ef  48396f18                 cmp qword ptr [rdi + 0x18], rbp
001a55f3  740c                     je 0x1a5601
001a55f5  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
001a55f9  488bd7                   mov rdx, rdi
001a55fc  e84fa7e6ff               call 0xfd50
001a5601  488bcf                   mov rcx, rdi
001a5604  e807cfffff               call 0x1a2510
001a5609  ba880d0000               mov edx, 0xd88
001a560e  488bcf                   mov rcx, rdi
001a5611  e81a19e6ff               call 0x6f30
001a5616  48896b08                 mov qword ptr [rbx + 8], rbp
001a561a  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001a561e  4885c9                   test rcx, rcx
001a5621  740f                     je 0x1a5632
001a5623  8b5320                   mov edx, dword ptr [rbx + 0x20]
001a5626  e8d505e6ff               call 0x5c00
001a562b  48896b18                 mov qword ptr [rbx + 0x18], rbp
001a562f  896b20                   mov dword ptr [rbx + 0x20], ebp
001a5632  488b742448               mov rsi, qword ptr [rsp + 0x48]
001a5637  48896b10                 mov qword ptr [rbx + 0x10], rbp
001a563b  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
001a5640  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
001a5645  4883c420                 add rsp, 0x20
001a5649  5f                       pop rdi
001a564a  c3                       ret
