; `TPartitionedDescriptorList<ClockInfo,CacheClockAlgorithm,ClockInfoInternalList>::InitMemoryComponents'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22d130, 53 bytes in 1 chunk(s)

; chunk at RVA 0x22d130 (53 bytes)
0022d130  4055                     push rbp
0022d132  4883ec30                 sub rsp, 0x30
0022d136  488bea                   mov rbp, rdx
0022d139  c644242806               mov byte ptr [rsp + 0x28], 6
0022d13e  8b4570                   mov eax, dword ptr [rbp + 0x70]
0022d141  89442420                 mov dword ptr [rsp + 0x20], eax
0022d145  4c8d0d84d10400           lea r9, [rip + 0x4d184]
0022d14c  41b801000000             mov r8d, 1
0022d152  488b5568                 mov rdx, qword ptr [rbp + 0x68]
0022d156  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0022d15a  e8b19dddff               call 0x6f10
0022d15f  4883c430                 add rsp, 0x30
0022d163  5d                       pop rbp
0022d164  c3                       ret
