; XE_ResolvedObject<XEType>::~XE_ResolvedObject<XEType>
; sqldk.dll, primary RVA 0x41160, 43 bytes in 1 chunk(s)

; chunk at RVA 0x41160 (43 bytes)
00041160  48894c2408               mov qword ptr [rsp + 8], rcx
00041165  4883ec38                 sub rsp, 0x38
00041169  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00041172  488b4910                 mov rcx, qword ptr [rcx + 0x10]
00041176  4885c9                   test rcx, rcx
00041179  740b                     je 0x41186
0004117b  4883c438                 add rsp, 0x38
0004117f  48ff252a422d00           jmp qword ptr [rip + 0x2d422a]
00041186  4883c438                 add rsp, 0x38
0004118a  c3                       ret
