; OstreamStreamBuf::`vector deleting destructor'
; sqldk.dll, primary RVA 0x57c70, 67 bytes in 1 chunk(s)

; chunk at RVA 0x57c70 (67 bytes)
00057c70  48894c2408               mov qword ptr [rsp + 8], rcx
00057c75  57                       push rdi
00057c76  4883ec30                 sub rsp, 0x30
00057c7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00057c83  48895c2448               mov qword ptr [rsp + 0x48], rbx
00057c88  8bda                     mov ebx, edx
00057c8a  488bf9                   mov rdi, rcx
00057c8d  ff15351b1e00             call qword ptr [rip + 0x1e1b35]
00057c93  f6c301                   test bl, 1
00057c96  740d                     je 0x57ca5
00057c98  ba70010000               mov edx, 0x170
00057c9d  488bcf                   mov rcx, rdi
00057ca0  e88bf2faff               call 0x6f30
00057ca5  488bc7                   mov rax, rdi
00057ca8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00057cad  4883c430                 add rsp, 0x30
00057cb1  5f                       pop rdi
00057cb2  c3                       ret
