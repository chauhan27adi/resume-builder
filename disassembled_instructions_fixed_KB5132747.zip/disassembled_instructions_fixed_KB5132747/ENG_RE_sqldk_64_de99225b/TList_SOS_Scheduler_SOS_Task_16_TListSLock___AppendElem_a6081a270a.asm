; TList<SOS_Scheduler,SOS_Task,16,TListSLock>::AppendElem
; sqldk.dll, primary RVA 0xfaa0, 432 bytes in 5 chunk(s)

; chunk at RVA 0xfaa0 (20 bytes)
0000faa0  4057                     push rdi
0000faa2  4155                     push r13
0000faa4  4883ec48                 sub rsp, 0x48
0000faa8  658b042548000000         mov eax, dword ptr gs:[0x48]
0000fab0  488d7910                 lea rdi, [rcx + 0x10]

; chunk at RVA 0xfab4 (81 bytes)
0000fab4  48895c2478               mov qword ptr [rsp + 0x78], rbx
0000fab9  4533ed                   xor r13d, r13d
0000fabc  48896c2440               mov qword ptr [rsp + 0x40], rbp
0000fac1  4885c9                   test rcx, rcx
0000fac4  4c89642430               mov qword ptr [rsp + 0x30], r12
0000fac9  418bdd                   mov ebx, r13d
0000facc  4c89742428               mov qword ptr [rsp + 0x28], r14
0000fad1  4c8d61d0                 lea r12, [rcx - 0x30]
0000fad5  8be8                     mov ebp, eax
0000fad7  4d0f44e5                 cmove r12, r13
0000fadb  8b07                     mov eax, dword ptr [rdi]
0000fadd  4c8bf1                   mov r14, rcx
0000fae0  4c897c2420               mov qword ptr [rsp + 0x20], r15
0000fae5  4c8bfa                   mov r15, rdx
0000fae8  85c0                     test eax, eax
0000faea  0f8591870700             jne 0x88281
0000faf0  33c0                     xor eax, eax
0000faf2  f0480fb12f               lock cmpxchg qword ptr [rdi], rbp
0000faf7  418bc5                   mov eax, r13d
0000fafa  0f94c0                   sete al
0000fafd  85c0                     test eax, eax
0000faff  0f847c870700             je 0x88281

; chunk at RVA 0xfb05 (70 bytes)
0000fb05  498b06                   mov rax, qword ptr [r14]
0000fb08  498d4f10                 lea rcx, [r15 + 0x10]
0000fb0c  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
0000fb11  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
0000fb16  488901                   mov qword ptr [rcx], rax
0000fb19  498b06                   mov rax, qword ptr [r14]
0000fb1c  48894808                 mov qword ptr [rax + 8], rcx
0000fb20  49890e                   mov qword ptr [r14], rcx
0000fb23  4c897108                 mov qword ptr [rcx + 8], r14
0000fb27  41ff4618                 inc dword ptr [r14 + 0x18]
0000fb2b  4c8b742428               mov r14, qword ptr [rsp + 0x28]
0000fb30  4d896720                 mov qword ptr [r15 + 0x20], r12
0000fb34  44382d86593000           cmp byte ptr [rip + 0x305986], r13b
0000fb3b  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
0000fb40  4c8b642430               mov r12, qword ptr [rsp + 0x30]
0000fb45  0f8514880700             jne 0x8835f

; chunk at RVA 0x8828c (211 bytes)
0008828c  4889742438               mov qword ptr [rsp + 0x38], rsi
00088291  498bf5                   mov rsi, r13
00088294  3c84                     cmp al, 0x84
00088296  754b                     jne 0x882e3
00088298  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000882a1  8b0529cd2800             mov eax, dword ptr [rip + 0x28cd29]
000882a7  8b150b96f7ff             mov edx, dword ptr [rip - 0x869f5]
000882ad  480314c1                 add rdx, qword ptr [rcx + rax*8]
000882b1  7410                     je 0x882c3
000882b3  48399210010000           cmp qword ptr [rdx + 0x110], rdx
000882ba  7507                     jne 0x882c3
000882bc  488bb200010000           mov rsi, qword ptr [rdx + 0x100]
000882c3  4885f6                   test rsi, rsi
000882c6  741b                     je 0x882e3
000882c8  391df6d12800             cmp dword ptr [rip + 0x28d1f6], ebx
000882ce  746d                     je 0x8833d
000882d0  488d4c2460               lea rcx, [rsp + 0x60]
000882d5  ff15f5111b00             call qword ptr [rip + 0x1b11f5]
000882db  488b5c2460               mov rbx, qword ptr [rsp + 0x60]
000882e0  eb01                     jmp 0x882e3
000882e2  cc                       int3
000882e3  f605edc7280080           test byte ptr [rip + 0x28c7ed], 0x80
000882ea  488bcf                   mov rcx, rdi
000882ed  7459                     je 0x88348
000882ef  4c8bc5                   mov r8, rbp
000882f2  488bd6                   mov rdx, rsi
000882f5  e8b60dfbff               call 0x390b0
000882fa  eb01                     jmp 0x882fd
000882fc  cc                       int3
000882fd  4885f6                   test rsi, rsi
00088300  7430                     je 0x88332
00088302  44392dbbd12800           cmp dword ptr [rip + 0x28d1bb], r13d
00088309  7449                     je 0x88354
0008830b  488d4c2468               lea rcx, [rsp + 0x68]
00088310  ff15ba111b00             call qword ptr [rip + 0x1b11ba]
00088316  488b442468               mov rax, qword ptr [rsp + 0x68]
0008831b  eb01                     jmp 0x8831e
0008831d  cc                       int3
0008831e  488bc8                   mov rcx, rax
00088321  482bcb                   sub rcx, rbx
00088324  483bc3                   cmp rax, rbx
00088327  490f42cd                 cmovb rcx, r13
0008832b  48018e780c0000           add qword ptr [rsi + 0xc78], rcx
00088332  488b742438               mov rsi, qword ptr [rsp + 0x38]
00088337  e9c977f8ff               jmp 0xfb05
0008833c  cc                       int3
0008833d  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
00088345  eb9c                     jmp 0x882e3
00088347  cc                       int3
00088348  488bd5                   mov rdx, rbp
0008834b  e85021feff               call 0x6a4a0
00088350  90                       nop
00088351  ebaa                     jmp 0x882fd
00088353  cc                       int3
00088354  488b04250800fe7f         mov rax, qword ptr [0x7ffe0008]
0008835c  ebc0                     jmp 0x8831e
0008835e  cc                       int3

; chunk at RVA 0x8835f (50 bytes)
0008835f  ff15e3161b00             call qword ptr [rip + 0x1b16e3]
00088365  448bc0                   mov r8d, eax
00088368  b867666666               mov eax, 0x66666667
0008836d  41f7e8                   imul r8d
00088370  d1fa                     sar edx, 1
00088372  8bca                     mov ecx, edx
00088374  c1e91f                   shr ecx, 0x1f
00088377  03d1                     add edx, ecx
00088379  8d0c92                   lea ecx, [rdx + rdx*4]
0008837c  443bc1                   cmp r8d, ecx
0008837f  0f85c677f8ff             jne 0xfb4b
00088385  e85623feff               call 0x6a6e0
0008838a  90                       nop
0008838b  e9bb77f8ff               jmp 0xfb4b
00088390  cc                       int3
