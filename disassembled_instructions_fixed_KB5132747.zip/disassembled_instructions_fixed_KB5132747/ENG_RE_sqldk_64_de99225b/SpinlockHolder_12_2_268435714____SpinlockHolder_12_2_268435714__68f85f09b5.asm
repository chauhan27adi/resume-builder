; SpinlockHolder<12,2,268435714>::~SpinlockHolder<12,2,268435714>
; sqldk.dll, primary RVA 0x9a430, 97 bytes in 1 chunk(s)

; chunk at RVA 0x9a430 (97 bytes)
0009a430  48895c2408               mov qword ptr [rsp + 8], rbx
0009a435  57                       push rdi
0009a436  4883ec20                 sub rsp, 0x20
0009a43a  488b39                   mov rdi, qword ptr [rcx]
0009a43d  488bd9                   mov rbx, rcx
0009a440  4885ff                   test rdi, rdi
0009a443  7441                     je 0x9a486
0009a445  83790800                 cmp dword ptr [rcx + 8], 0
0009a449  743b                     je 0x9a486
0009a44b  803d6fb0270000           cmp byte ptr [rip + 0x27b06f], 0
0009a452  7427                     je 0x9a47b
0009a454  ff15eef51900             call qword ptr [rip + 0x19f5ee]
0009a45a  448bc0                   mov r8d, eax
0009a45d  b867666666               mov eax, 0x66666667
0009a462  41f7e8                   imul r8d
0009a465  d1fa                     sar edx, 1
0009a467  8bca                     mov ecx, edx
0009a469  c1e91f                   shr ecx, 0x1f
0009a46c  03d1                     add edx, ecx
0009a46e  8d0c92                   lea ecx, [rdx + rdx*4]
0009a471  443bc1                   cmp r8d, ecx
0009a474  7505                     jne 0x9a47b
0009a476  e8c5070000               call 0x9ac40
0009a47b  33c0                     xor eax, eax
0009a47d  488907                   mov qword ptr [rdi], rax
0009a480  488903                   mov qword ptr [rbx], rax
0009a483  894308                   mov dword ptr [rbx + 8], eax
0009a486  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0009a48b  4883c420                 add rsp, 0x20
0009a48f  5f                       pop rdi
0009a490  c3                       ret
