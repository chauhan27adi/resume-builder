; IMemObj::~IMemObj
; sqldk.dll, primary RVA 0x8b440, 65 bytes in 1 chunk(s)

; chunk at RVA 0x8b440 (65 bytes)
0008b440  48894c2408               mov qword ptr [rsp + 8], rcx
0008b445  53                       push rbx
0008b446  4883ec30                 sub rsp, 0x30
0008b44a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0008b453  488bd9                   mov rbx, rcx
0008b456  488d05abbd1b00           lea rax, [rip + 0x1bbdab]
0008b45d  488901                   mov qword ptr [rcx], rax
0008b460  4883c138                 add rcx, 0x38
0008b464  e88761f8ff               call 0x115f0
0008b469  90                       nop
0008b46a  488d4b30                 lea rcx, [rbx + 0x30]
0008b46e  e87d61f8ff               call 0x115f0
0008b473  90                       nop
0008b474  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0008b47b  4883c430                 add rsp, 0x30
0008b47f  5b                       pop rbx
0008b480  c3                       ret
