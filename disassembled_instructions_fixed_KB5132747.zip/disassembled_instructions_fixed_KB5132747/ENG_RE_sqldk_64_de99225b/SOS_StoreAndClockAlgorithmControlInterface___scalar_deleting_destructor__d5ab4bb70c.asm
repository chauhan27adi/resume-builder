; SOS_StoreAndClockAlgorithmControlInterface::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x1821b0, 63 bytes in 1 chunk(s)

; chunk at RVA 0x1821b0 (63 bytes)
001821b0  48894c2408               mov qword ptr [rsp + 8], rcx
001821b5  53                       push rbx
001821b6  4883ec30                 sub rsp, 0x30
001821ba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001821c3  488bd9                   mov rbx, rcx
001821c6  488d0593da0c00           lea rax, [rip + 0xcda93]
001821cd  488901                   mov qword ptr [rcx], rax
001821d0  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
001821d7  f6c201                   test dl, 1
001821da  740a                     je 0x1821e6
001821dc  ba10000000               mov edx, 0x10
001821e1  e84a4de8ff               call 0x6f30
001821e6  488bc3                   mov rax, rbx
001821e9  4883c430                 add rsp, 0x30
001821ed  5b                       pop rbx
001821ee  c3                       ret
