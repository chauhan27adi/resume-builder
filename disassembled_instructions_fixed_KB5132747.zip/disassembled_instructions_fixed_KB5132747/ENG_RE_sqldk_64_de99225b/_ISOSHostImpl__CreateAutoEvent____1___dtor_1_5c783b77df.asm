; `ISOSHostImpl::CreateAutoEvent'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22a34c, 62 bytes in 1 chunk(s)

; chunk at RVA 0x22a34c (62 bytes)
0022a34c  4055                     push rbp
0022a34e  4883ec30                 sub rsp, 0x30
0022a352  488bea                   mov rbp, rdx
0022a355  c644242806               mov byte ptr [rsp + 0x28], 6
0022a35a  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022a360  89442420                 mov dword ptr [rsp + 0x20], eax
0022a364  4c8d0d75f80600           lea r9, [rip + 0x6f875]
0022a36b  41b801000000             mov r8d, 1
0022a371  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0022a378  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
0022a37f  e88ccbddff               call 0x6f10
0022a384  4883c430                 add rsp, 0x30
0022a388  5d                       pop rbp
0022a389  c3                       ret
