; AutoSpinlockHolder<8,3,268435714>::~AutoSpinlockHolder<8,3,268435714>
; sqldk.dll, primary RVA 0x1dd450, 111 bytes in 1 chunk(s)

; chunk at RVA 0x1dd450 (111 bytes)
001dd450  48894c2408               mov qword ptr [rsp + 8], rcx
001dd455  57                       push rdi
001dd456  4883ec30                 sub rsp, 0x30
001dd45a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001dd463  48895c2448               mov qword ptr [rsp + 0x48], rbx
001dd468  488bd9                   mov rbx, rcx
001dd46b  488b39                   mov rdi, qword ptr [rcx]
001dd46e  4885ff                   test rdi, rdi
001dd471  7441                     je 0x1dd4b4
001dd473  83790800                 cmp dword ptr [rcx + 8], 0
001dd477  743b                     je 0x1dd4b4
001dd479  803d4180130000           cmp byte ptr [rip + 0x138041], 0
001dd480  7427                     je 0x1dd4a9
001dd482  ff15c0c50500             call qword ptr [rip + 0x5c5c0]
001dd488  448bc0                   mov r8d, eax
001dd48b  b867666666               mov eax, 0x66666667
001dd490  41f7e8                   imul r8d
001dd493  d1fa                     sar edx, 1
001dd495  8bca                     mov ecx, edx
001dd497  c1e91f                   shr ecx, 0x1f
001dd49a  03d1                     add edx, ecx
001dd49c  8d0c92                   lea ecx, [rdx + rdx*4]
001dd49f  443bc1                   cmp r8d, ecx
001dd4a2  7505                     jne 0x1dd4a9
001dd4a4  e8a7090000               call 0x1dde50
001dd4a9  33c0                     xor eax, eax
001dd4ab  488907                   mov qword ptr [rdi], rax
001dd4ae  488903                   mov qword ptr [rbx], rax
001dd4b1  894308                   mov dword ptr [rbx + 8], eax
001dd4b4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001dd4b9  4883c430                 add rsp, 0x30
001dd4bd  5f                       pop rdi
001dd4be  c3                       ret
