; SOS_TraceStreamBufferT<256>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x57eb0, 67 bytes in 1 chunk(s)

; chunk at RVA 0x57eb0 (67 bytes)
00057eb0  48894c2408               mov qword ptr [rsp + 8], rcx
00057eb5  57                       push rdi
00057eb6  4883ec30                 sub rsp, 0x30
00057eba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00057ec3  48895c2448               mov qword ptr [rsp + 0x48], rbx
00057ec8  8bda                     mov ebx, edx
00057eca  488bf9                   mov rdi, rcx
00057ecd  ff15f5181e00             call qword ptr [rip + 0x1e18f5]
00057ed3  f6c301                   test bl, 1
00057ed6  740d                     je 0x57ee5
00057ed8  ba68010000               mov edx, 0x168
00057edd  488bcf                   mov rcx, rdi
00057ee0  e84bf0faff               call 0x6f30
00057ee5  488bc7                   mov rax, rdi
00057ee8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00057eed  4883c430                 add rsp, 0x30
00057ef1  5f                       pop rdi
00057ef2  c3                       ret
