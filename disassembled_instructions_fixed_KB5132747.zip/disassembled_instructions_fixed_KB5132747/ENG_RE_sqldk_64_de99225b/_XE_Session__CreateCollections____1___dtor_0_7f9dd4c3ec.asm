; `XE_Session::CreateCollections'::`1'::dtor$0
; sqldk.dll, primary RVA 0x234b60, 62 bytes in 1 chunk(s)

; chunk at RVA 0x234b60 (62 bytes)
00234b60  4055                     push rbp
00234b62  4883ec30                 sub rsp, 0x30
00234b66  488bea                   mov rbp, rdx
00234b69  c644242806               mov byte ptr [rsp + 0x28], 6
00234b6e  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00234b74  89442420                 mov dword ptr [rsp + 0x20], eax
00234b78  4c8d0df95c0700           lea r9, [rip + 0x75cf9]
00234b7f  41b801000000             mov r8d, 1
00234b85  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00234b8c  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
00234b93  e85853faff               call 0x1d9ef0
00234b98  4883c430                 add rsp, 0x30
00234b9c  5d                       pop rbp
00234b9d  c3                       ret
