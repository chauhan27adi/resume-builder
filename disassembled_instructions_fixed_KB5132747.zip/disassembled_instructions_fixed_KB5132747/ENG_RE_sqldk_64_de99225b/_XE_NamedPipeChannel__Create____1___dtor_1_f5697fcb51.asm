; `XE_NamedPipeChannel::Create'::`1'::dtor$1
; sqldk.dll, primary RVA 0x2369c8, 37 bytes in 1 chunk(s)

; chunk at RVA 0x2369c8 (37 bytes)
002369c8  4055                     push rbp
002369ca  4883ec20                 sub rsp, 0x20
002369ce  488bea                   mov rbp, rdx
002369d1  4533c0                   xor r8d, r8d
002369d4  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
002369db  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
002369e2  e829a6dcff               call 0x1010
002369e7  4883c420                 add rsp, 0x20
002369eb  5d                       pop rbp
002369ec  c3                       ret
