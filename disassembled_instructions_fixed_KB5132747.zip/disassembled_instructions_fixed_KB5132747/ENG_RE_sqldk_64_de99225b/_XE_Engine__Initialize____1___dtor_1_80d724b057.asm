; `XE_Engine::Initialize'::`1'::dtor$1
; sqldk.dll, primary RVA 0x233f37, 56 bytes in 1 chunk(s)

; chunk at RVA 0x233f37 (56 bytes)
00233f37  4055                     push rbp
00233f39  4883ec30                 sub rsp, 0x30
00233f3d  488bea                   mov rbp, rdx
00233f40  c644242806               mov byte ptr [rsp + 0x28], 6
00233f45  8b4530                   mov eax, dword ptr [rbp + 0x30]
00233f48  89442420                 mov dword ptr [rsp + 0x20], eax
00233f4c  4c8d0d4d680700           lea r9, [rip + 0x7684d]
00233f53  41b801000000             mov r8d, 1
00233f59  488b1560e71700           mov rdx, qword ptr [rip + 0x17e760]
00233f60  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00233f64  e8875ffaff               call 0x1d9ef0
00233f69  4883c430                 add rsp, 0x30
00233f6d  5d                       pop rbp
00233f6e  c3                       ret
