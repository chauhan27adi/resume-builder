; `XE_Xml<XE_Metadata,XE_StandardFormatter,XE_SerializedEvent<XE_Metadata,XE_VersionConfig> >::WriteObjectId'::`1'::dtor$5
; sqldk.dll, primary RVA 0x231a70, 37 bytes in 1 chunk(s)

; chunk at RVA 0x231a70 (37 bytes)
00231a70  4055                     push rbp
00231a72  4883ec20                 sub rsp, 0x20
00231a76  488bea                   mov rbp, rdx
00231a79  4533c0                   xor r8d, r8d
00231a7c  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
00231a83  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
00231a8a  e881f5dcff               call 0x1010
00231a8f  4883c420                 add rsp, 0x20
00231a93  5d                       pop rbp
00231a94  c3                       ret
