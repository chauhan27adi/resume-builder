; TEnumerator<TList<SOS_Node,SystemThread,184,TListSLock> >::~TEnumerator<TList<SOS_Node,SystemThread,184,TListSLock> >
; sqldk.dll, primary RVA 0x73930, 345 bytes in 1 chunk(s)

; chunk at RVA 0x73930 (345 bytes)
00073930  48895c2410               mov qword ptr [rsp + 0x10], rbx
00073935  48896c2418               mov qword ptr [rsp + 0x18], rbp
0007393a  4889742420               mov qword ptr [rsp + 0x20], rsi
0007393f  57                       push rdi
00073940  4883ec20                 sub rsp, 0x20
00073944  488b39                   mov rdi, qword ptr [rcx]
00073947  33ed                     xor ebp, ebp
00073949  488bd9                   mov rbx, rcx
0007394c  beffffffff               mov esi, 0xffffffff
00073951  4885ff                   test rdi, rdi
00073954  747d                     je 0x739d3
00073956  8bc6                     mov eax, esi
00073958  f00fc187d0000000         lock xadd dword ptr [rdi + 0xd0], eax
00073960  83f801                   cmp eax, 1
00073963  756b                     jne 0x739d0
00073965  4839afc0000000           cmp qword ptr [rdi + 0xc0], rbp
0007396c  7435                     je 0x739a3
0007396e  488b8fc8000000           mov rcx, qword ptr [rdi + 0xc8]
00073975  488bd7                   mov rdx, rdi
00073978  4883c140                 add rcx, 0x40
0007397c  e80f010000               call 0x73a90
00073981  654c8b042558000000       mov r8, qword ptr gs:[0x58]
0007398a  8b0540162a00             mov eax, dword ptr [rip + 0x2a1640]
00073990  8b1522dff8ff             mov edx, dword ptr [rip - 0x720de]
00073996  490314c0                 add rdx, qword ptr [r8 + rax*8]
0007399a  488997f8000000           mov qword ptr [rdi + 0xf8], rdx
000739a1  eb20                     jmp 0x739c3
000739a3  65488b142558000000       mov rdx, qword ptr gs:[0x58]
000739ac  8b051e162a00             mov eax, dword ptr [rip + 0x2a161e]
000739b2  8b0d00dff8ff             mov ecx, dword ptr [rip - 0x72100]
000739b8  48030cc2                 add rcx, qword ptr [rdx + rax*8]
000739bc  48898ff8000000           mov qword ptr [rdi + 0xf8], rcx
000739c3  488b8f40010000           mov rcx, qword ptr [rdi + 0x140]
000739ca  ff1590571c00             call qword ptr [rip + 0x1c5790]
000739d0  48892b                   mov qword ptr [rbx], rbp
000739d3  488b7b08                 mov rdi, qword ptr [rbx + 8]
000739d7  4885ff                   test rdi, rdi
000739da  747c                     je 0x73a58
000739dc  f00fc1b7d0000000         lock xadd dword ptr [rdi + 0xd0], esi
000739e4  83fe01                   cmp esi, 1
000739e7  756b                     jne 0x73a54
000739e9  4839afc0000000           cmp qword ptr [rdi + 0xc0], rbp
000739f0  7435                     je 0x73a27
000739f2  488b8fc8000000           mov rcx, qword ptr [rdi + 0xc8]
000739f9  488bd7                   mov rdx, rdi
000739fc  4883c140                 add rcx, 0x40
00073a00  e88b000000               call 0x73a90
00073a05  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00073a0e  8b05bc152a00             mov eax, dword ptr [rip + 0x2a15bc]
00073a14  8b159edef8ff             mov edx, dword ptr [rip - 0x72162]
00073a1a  490314c0                 add rdx, qword ptr [r8 + rax*8]
00073a1e  488997f8000000           mov qword ptr [rdi + 0xf8], rdx
00073a25  eb20                     jmp 0x73a47
00073a27  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00073a30  8b059a152a00             mov eax, dword ptr [rip + 0x2a159a]
00073a36  8b0d7cdef8ff             mov ecx, dword ptr [rip - 0x72184]
00073a3c  48030cc2                 add rcx, qword ptr [rdx + rax*8]
00073a40  48898ff8000000           mov qword ptr [rdi + 0xf8], rcx
00073a47  488b8f40010000           mov rcx, qword ptr [rdi + 0x140]
00073a4e  ff150c571c00             call qword ptr [rip + 0x1c570c]
00073a54  48896b08                 mov qword ptr [rbx + 8], rbp
00073a58  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
00073a5c  4885c9                   test rcx, rcx
00073a5f  740f                     je 0x73a70
00073a61  8b5320                   mov edx, dword ptr [rbx + 0x20]
00073a64  e89721f9ff               call 0x5c00
00073a69  48896b18                 mov qword ptr [rbx + 0x18], rbp
00073a6d  896b20                   mov dword ptr [rbx + 0x20], ebp
00073a70  488b742448               mov rsi, qword ptr [rsp + 0x48]
00073a75  48896b10                 mov qword ptr [rbx + 0x10], rbp
00073a79  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
00073a7e  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
00073a83  4883c420                 add rsp, 0x20
00073a87  5f                       pop rdi
00073a88  c3                       ret
