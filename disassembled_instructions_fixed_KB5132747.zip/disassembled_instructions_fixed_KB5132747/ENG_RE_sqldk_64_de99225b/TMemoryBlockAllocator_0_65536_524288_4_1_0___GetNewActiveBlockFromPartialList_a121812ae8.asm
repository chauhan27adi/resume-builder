; TMemoryBlockAllocator<0,65536,524288,4,1,0>::GetNewActiveBlockFromPartialList
; sqldk.dll, primary RVA 0x3a220, 242 bytes in 1 chunk(s)

; chunk at RVA 0x3a220 (242 bytes)
0003a220  488bc4                   mov rax, rsp
0003a223  48894808                 mov qword ptr [rax + 8], rcx
0003a227  55                       push rbp
0003a228  4154                     push r12
0003a22a  4155                     push r13
0003a22c  4156                     push r14
0003a22e  4157                     push r15
0003a230  488d68a9                 lea rbp, [rax - 0x57]
0003a234  4881ec90000000           sub rsp, 0x90
0003a23b  48c7451ffeffffff         mov qword ptr [rbp + 0x1f], 0xfffffffffffffffe
0003a243  48895810                 mov qword ptr [rax + 0x10], rbx
0003a247  48897018                 mov qword ptr [rax + 0x18], rsi
0003a24b  48897820                 mov qword ptr [rax + 0x20], rdi
0003a24f  450fb6e8                 movzx r13d, r8b
0003a253  33ff                     xor edi, edi
0003a255  8bdf                     mov ebx, edi
0003a257  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0003a25b  488d45c7                 lea rax, [rbp - 0x39]
0003a25f  488945cf                 mov qword ptr [rbp - 0x31], rax
0003a263  488d45c7                 lea rax, [rbp - 0x39]
0003a267  488945c7                 mov qword ptr [rbp - 0x39], rax
0003a26b  0fb7c2                   movzx eax, dx
0003a26e  488d0440                 lea rax, [rax + rax*2]
0003a272  48c1e006                 shl rax, 6
0003a276  4803c1                   add rax, rcx
0003a279  488945d7                 mov qword ptr [rbp - 0x29], rax
0003a27d  4c8da000010000           lea r12, [rax + 0x100]
0003a284  448d7f06                 lea r15d, [rdi + 6]
0003a288  440fb6757f               movzx r14d, byte ptr [rbp + 0x7f]
0003a28d  4584c9                   test r9b, r9b
0003a290  0f8487760500             je 0x9191d
0003a296  8d7704                   lea esi, [rdi + 4]
0003a299  eb01                     jmp 0x3a29c
0003a29b  cc                       int3
0003a29c  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0003a2a0  83fe08                   cmp esi, 8
0003a2a3  0f83ac000000             jae 0x3a355
0003a2a9  48897dbf                 mov qword ptr [rbp - 0x41], rdi
0003a2ad  488d55df                 lea rdx, [rbp - 0x21]
0003a2b1  488955e7                 mov qword ptr [rbp - 0x19], rdx
0003a2b5  488d4ddf                 lea rcx, [rbp - 0x21]
0003a2b9  48894ddf                 mov qword ptr [rbp - 0x21], rcx
0003a2bd  4863fe                   movsxd rdi, esi
0003a2c0  4883c711                 add rdi, 0x11
0003a2c4  48c1e704                 shl rdi, 4
0003a2c8  4803f8                   add rdi, rax
0003a2cb  488bcf                   mov rcx, rdi
0003a2ce  ff1544ef1f00             call qword ptr [rip + 0x1fef44]
0003a2d4  4c8bc0                   mov r8, rax
0003a2d7  4885c0                   test rax, rax
0003a2da  0f853d020000             jne 0x3a51d
0003a2e0  488b5dbf                 mov rbx, qword ptr [rbp - 0x41]
0003a2e4  4533e4                   xor r12d, r12d
0003a2e7  488d45df                 lea rax, [rbp - 0x21]
0003a2eb  488b55e7                 mov rdx, qword ptr [rbp - 0x19]
0003a2ef  483bd0                   cmp rdx, rax
0003a2f2  0f8592750500             jne 0x9188a
0003a2f8  ffc6                     inc esi
0003a2fa  4885db                   test rbx, rbx
0003a2fd  488b45d7                 mov rax, qword ptr [rbp - 0x29]
0003a301  4c8da000010000           lea r12, [rax + 0x100]
0003a308  7505                     jne 0x3a30f
0003a30a  33ff                     xor edi, edi
0003a30c  eb8e                     jmp 0x3a29c
0003a30e  cc                       int3
0003a30f  eb0f                     jmp 0x3a320
0003a311  cc                       int3
