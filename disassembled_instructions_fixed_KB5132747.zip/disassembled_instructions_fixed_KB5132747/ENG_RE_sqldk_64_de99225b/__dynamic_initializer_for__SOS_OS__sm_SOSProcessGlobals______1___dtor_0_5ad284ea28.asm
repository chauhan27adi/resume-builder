; ``dynamic initializer for 'SOS_OS::sm_SOSProcessGlobals'''::`1'::dtor$0
; sqldk.dll, primary RVA 0x22f500, 49 bytes in 1 chunk(s)

; chunk at RVA 0x22f500 (49 bytes)
0022f500  4055                     push rbp
0022f502  4883ec20                 sub rsp, 0x20
0022f506  488bea                   mov rbp, rdx
0022f509  488d0d502f1000           lea rcx, [rip + 0x102f50]
0022f510  4883c110                 add rcx, 0x10
0022f514  4c8d0d75fbf7ff           lea r9, [rip - 0x8048b]
0022f51b  41b841000000             mov r8d, 0x41
0022f521  ba58000000               mov edx, 0x58
0022f526  e8f552dfff               call 0x24820
0022f52b  4883c420                 add rsp, 0x20
0022f52f  5d                       pop rbp
0022f530  c3                       ret
