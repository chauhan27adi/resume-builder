; CAutoRg<XMLActionTransformRule>::~CAutoRg<XMLActionTransformRule>
; sqldk.dll, primary RVA 0x4e0c0, 79 bytes in 3 chunk(s)

; chunk at RVA 0x4e0c0 (23 bytes)
0004e0c0  4883ec28                 sub rsp, 0x28
0004e0c4  488b09                   mov rcx, qword ptr [rcx]
0004e0c7  4885c9                   test rcx, rcx
0004e0ca  743f                     je 0x4e10b
0004e0cc  4c8b41f8                 mov r8, qword ptr [rcx - 8]
0004e0d0  4c8d0dc9020000           lea r9, [rip + 0x2c9]

; chunk at RVA 0x4e0d7 (51 bytes)
0004e0d7  48895c2420               mov qword ptr [rsp + 0x20], rbx
0004e0dc  ba18000000               mov edx, 0x18
0004e0e1  488d59f8                 lea rbx, [rcx - 8]
0004e0e5  e83667fdff               call 0x24820
0004e0ea  488b03                   mov rax, qword ptr [rbx]
0004e0ed  488bcb                   mov rcx, rbx
0004e0f0  488d1440                 lea rdx, [rax + rax*2]
0004e0f4  488d14d508000000         lea rdx, [rdx*8 + 8]
0004e0fc  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0004e101  4883c428                 add rsp, 0x28
0004e105  e9268efbff               jmp 0x6f30

; chunk at RVA 0x4e10b (5 bytes)
0004e10b  4883c428                 add rsp, 0x28
0004e10f  c3                       ret
