; `XE_Session::CreateCollections'::`1'::dtor$6
; sqldk.dll, primary RVA 0x234d06, 59 bytes in 1 chunk(s)

; chunk at RVA 0x234d06 (59 bytes)
00234d06  4055                     push rbp
00234d08  4883ec30                 sub rsp, 0x30
00234d0c  488bea                   mov rbp, rdx
00234d0f  c644242806               mov byte ptr [rsp + 0x28], 6
00234d14  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00234d1a  89442420                 mov dword ptr [rsp + 0x20], eax
00234d1e  4c8d0d535b0700           lea r9, [rip + 0x75b53]
00234d25  41b801000000             mov r8d, 1
00234d2b  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00234d32  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00234d36  e8b551faff               call 0x1d9ef0
00234d3b  4883c430                 add rsp, 0x30
00234d3f  5d                       pop rbp
00234d40  c3                       ret
