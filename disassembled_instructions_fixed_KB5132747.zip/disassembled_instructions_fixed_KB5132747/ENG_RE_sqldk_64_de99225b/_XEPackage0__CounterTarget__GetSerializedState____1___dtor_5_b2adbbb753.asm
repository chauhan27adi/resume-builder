; `XEPackage0::CounterTarget::GetSerializedState'::`1'::dtor$5
; sqldk.dll, primary RVA 0x231804, 34 bytes in 1 chunk(s)

; chunk at RVA 0x231804 (34 bytes)
00231804  4055                     push rbp
00231806  4883ec20                 sub rsp, 0x20
0023180a  488bea                   mov rbp, rdx
0023180d  4533c0                   xor r8d, r8d
00231810  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
00231817  488b4d78                 mov rcx, qword ptr [rbp + 0x78]
0023181b  e8f0f7dcff               call 0x1010
00231820  4883c420                 add rsp, 0x20
00231824  5d                       pop rbp
00231825  c3                       ret
