; `XE_EngineObjectFactorySrv::SessionCreate'::`1'::dtor$0
; sqldk.dll, primary RVA 0x232c50, 53 bytes in 1 chunk(s)

; chunk at RVA 0x232c50 (53 bytes)
00232c50  4055                     push rbp
00232c52  4883ec30                 sub rsp, 0x30
00232c56  488bea                   mov rbp, rdx
00232c59  c644242806               mov byte ptr [rsp + 0x28], 6
00232c5e  8b4560                   mov eax, dword ptr [rbp + 0x60]
00232c61  89442420                 mov dword ptr [rsp + 0x20], eax
00232c65  4c8d0d1c790700           lea r9, [rip + 0x7791c]
00232c6c  41b801000000             mov r8d, 1
00232c72  488b5558                 mov rdx, qword ptr [rbp + 0x58]
00232c76  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
00232c7a  e87172faff               call 0x1d9ef0
00232c7f  4883c430                 add rsp, 0x30
00232c83  5d                       pop rbp
00232c84  c3                       ret
