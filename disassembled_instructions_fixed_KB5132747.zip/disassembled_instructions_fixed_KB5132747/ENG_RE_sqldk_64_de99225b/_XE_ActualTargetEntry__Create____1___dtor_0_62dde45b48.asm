; `XE_ActualTargetEntry::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235bb0, 53 bytes in 1 chunk(s)

; chunk at RVA 0x235bb0 (53 bytes)
00235bb0  4055                     push rbp
00235bb2  4883ec30                 sub rsp, 0x30
00235bb6  488bea                   mov rbp, rdx
00235bb9  c644242806               mov byte ptr [rsp + 0x28], 6
00235bbe  8b4540                   mov eax, dword ptr [rbp + 0x40]
00235bc1  89442420                 mov dword ptr [rsp + 0x20], eax
00235bc5  4c8d0dc44d0700           lea r9, [rip + 0x74dc4]
00235bcc  41b801000000             mov r8d, 1
00235bd2  488b5548                 mov rdx, qword ptr [rbp + 0x48]
00235bd6  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00235bda  e81143faff               call 0x1d9ef0
00235bdf  4883c430                 add rsp, 0x30
00235be3  5d                       pop rbp
00235be4  c3                       ret
