; TAutoMutex<SOS_RecursiveMutex,4294967295>::~TAutoMutex<SOS_RecursiveMutex,4294967295>
; sqldk.dll, primary RVA 0x55940, 68 bytes in 3 chunk(s)

; chunk at RVA 0x55940 (15 bytes)
00055940  4053                     push rbx
00055942  4883ec20                 sub rsp, 0x20
00055946  83790800                 cmp dword ptr [rcx + 8], 0
0005594a  488bd9                   mov rbx, rcx
0005594d  762f                     jbe 0x5597e

; chunk at RVA 0x5594f (47 bytes)
0005594f  48897c2430               mov qword ptr [rsp + 0x30], rdi
00055954  33ff                     xor edi, edi
00055956  488b0b                   mov rcx, qword ptr [rbx]
00055959  4883694001               sub qword ptr [rcx + 0x40], 1
0005595e  7513                     jne 0x55973
00055960  f0093c24                 lock or dword ptr [rsp], edi
00055964  33d2                     xor edx, edx
00055966  48897930                 mov qword ptr [rcx + 0x30], rdi
0005596a  48897938                 mov qword ptr [rcx + 0x38], rdi
0005596e  e87d05fbff               call 0x5ef0
00055973  834308ff                 add dword ptr [rbx + 8], -1
00055977  75dd                     jne 0x55956
00055979  488b7c2430               mov rdi, qword ptr [rsp + 0x30]

; chunk at RVA 0x5597e (6 bytes)
0005597e  4883c420                 add rsp, 0x20
00055982  5b                       pop rbx
00055983  c3                       ret
