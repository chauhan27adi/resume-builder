; CMemPartitioned<CMemThread<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce620, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce620 (104 bytes)
000ce620  48894c2408               mov qword ptr [rsp + 8], rcx
000ce625  57                       push rdi
000ce626  4883ec30                 sub rsp, 0x30
000ce62a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce633  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce638  8bda                     mov ebx, edx
000ce63a  488bf9                   mov rdi, rcx
000ce63d  488d0514ed1700           lea rax, [rip + 0x17ed14]
000ce644  488901                   mov qword ptr [rcx], rax
000ce647  488d8170020000           lea rax, [rcx + 0x270]
000ce64e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce653  488d0de6b41600           lea rcx, [rip + 0x16b4e6]
000ce65a  488908                   mov qword ptr [rax], rcx
000ce65d  488bcf                   mov rcx, rdi
000ce660  e8dbdf0200               call 0xfc640
000ce665  83e305                   and ebx, 5
000ce668  80fb05                   cmp bl, 5
000ce66b  750d                     jne 0xce67a
000ce66d  baa8020000               mov edx, 0x2a8
000ce672  488bcf                   mov rcx, rdi
000ce675  e89629f3ff               call 0x1010
000ce67a  488bc7                   mov rax, rdi
000ce67d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce682  4883c430                 add rsp, 0x30
000ce686  5f                       pop rdi
000ce687  c3                       ret
