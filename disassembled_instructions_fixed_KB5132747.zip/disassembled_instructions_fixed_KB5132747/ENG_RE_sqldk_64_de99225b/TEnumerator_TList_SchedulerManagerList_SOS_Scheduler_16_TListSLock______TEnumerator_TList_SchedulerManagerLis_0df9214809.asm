; TEnumerator<TList<SchedulerManagerList,SOS_Scheduler,16,TListSLock> >::~TEnumerator<TList<SchedulerManagerList,SOS_Scheduler,16,TListSLock> >
; sqldk.dll, primary RVA 0x75350, 177 bytes in 1 chunk(s)

; chunk at RVA 0x75350 (177 bytes)
00075350  48895c2410               mov qword ptr [rsp + 0x10], rbx
00075355  48896c2418               mov qword ptr [rsp + 0x18], rbp
0007535a  4889742420               mov qword ptr [rsp + 0x20], rsi
0007535f  57                       push rdi
00075360  4883ec20                 sub rsp, 0x20
00075364  488b39                   mov rdi, qword ptr [rcx]
00075367  33ed                     xor ebp, ebp
00075369  488bd9                   mov rbx, rcx
0007536c  beffffffff               mov esi, 0xffffffff
00075371  4885ff                   test rdi, rdi
00075374  7429                     je 0x7539f
00075376  8bc6                     mov eax, esi
00075378  f00fc14728               lock xadd dword ptr [rdi + 0x28], eax
0007537d  83f801                   cmp eax, 1
00075380  751a                     jne 0x7539c
00075382  48396f18                 cmp qword ptr [rdi + 0x18], rbp
00075386  740c                     je 0x75394
00075388  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0007538c  488bd7                   mov rdx, rdi
0007538f  e8bca9f9ff               call 0xfd50
00075394  488bcf                   mov rcx, rdi
00075397  e8e46f0000               call 0x7c380
0007539c  48892b                   mov qword ptr [rbx], rbp
0007539f  488b7b08                 mov rdi, qword ptr [rbx + 8]
000753a3  4885ff                   test rdi, rdi
000753a6  7428                     je 0x753d0
000753a8  f00fc17728               lock xadd dword ptr [rdi + 0x28], esi
000753ad  83fe01                   cmp esi, 1
000753b0  751a                     jne 0x753cc
000753b2  48396f18                 cmp qword ptr [rdi + 0x18], rbp
000753b6  740c                     je 0x753c4
000753b8  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000753bc  488bd7                   mov rdx, rdi
000753bf  e88ca9f9ff               call 0xfd50
000753c4  488bcf                   mov rcx, rdi
000753c7  e8b46f0000               call 0x7c380
000753cc  48896b08                 mov qword ptr [rbx + 8], rbp
000753d0  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
000753d4  4885c9                   test rcx, rcx
000753d7  740f                     je 0x753e8
000753d9  8b5320                   mov edx, dword ptr [rbx + 0x20]
000753dc  e81f08f9ff               call 0x5c00
000753e1  48896b18                 mov qword ptr [rbx + 0x18], rbp
000753e5  896b20                   mov dword ptr [rbx + 0x20], ebp
000753e8  488b742448               mov rsi, qword ptr [rsp + 0x48]
000753ed  48896b10                 mov qword ptr [rbx + 0x10], rbp
000753f1  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
000753f6  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
000753fb  4883c420                 add rsp, 0x20
000753ff  5f                       pop rdi
00075400  c3                       ret
