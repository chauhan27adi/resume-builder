; ChildList<XTList<ProbCostData>,CacheProbabilisticAlgorithm,ProbCostData>::~ChildList<XTList<ProbCostData>,CacheProbabilisticAlgorithm,ProbCostData>
; sqldk.dll, primary RVA 0x180b30, 28 bytes in 1 chunk(s)

; chunk at RVA 0x180b30 (28 bytes)
00180b30  48894c2408               mov qword ptr [rsp + 8], rcx
00180b35  4883ec18                 sub rsp, 0x18
00180b39  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00180b41  c701adde0080             mov dword ptr [rcx], 0x8000dead
00180b47  4883c418                 add rsp, 0x18
00180b4b  c3                       ret
