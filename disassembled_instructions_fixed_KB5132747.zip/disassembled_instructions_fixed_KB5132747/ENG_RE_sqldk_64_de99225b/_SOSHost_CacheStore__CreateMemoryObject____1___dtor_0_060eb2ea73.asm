; `SOSHost_CacheStore::CreateMemoryObject'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22bc50, 53 bytes in 1 chunk(s)

; chunk at RVA 0x22bc50 (53 bytes)
0022bc50  4055                     push rbp
0022bc52  4883ec30                 sub rsp, 0x30
0022bc56  488bea                   mov rbp, rdx
0022bc59  c644242806               mov byte ptr [rsp + 0x28], 6
0022bc5e  8b4570                   mov eax, dword ptr [rbp + 0x70]
0022bc61  89442420                 mov dword ptr [rsp + 0x20], eax
0022bc65  4c8d0d44e30600           lea r9, [rip + 0x6e344]
0022bc6c  41b801000000             mov r8d, 1
0022bc72  488b5578                 mov rdx, qword ptr [rbp + 0x78]
0022bc76  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022bc7a  e891b2ddff               call 0x6f10
0022bc7f  4883c430                 add rsp, 0x30
0022bc83  5d                       pop rbp
0022bc84  c3                       ret
