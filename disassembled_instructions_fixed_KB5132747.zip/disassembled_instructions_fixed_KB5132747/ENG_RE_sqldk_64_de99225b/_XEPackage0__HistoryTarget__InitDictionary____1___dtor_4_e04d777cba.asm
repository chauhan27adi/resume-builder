; `XEPackage0::HistoryTarget::InitDictionary'::`1'::dtor$4
; sqldk.dll, primary RVA 0x232a04, 51 bytes in 1 chunk(s)

; chunk at RVA 0x232a04 (51 bytes)
00232a04  4055                     push rbp
00232a06  4883ec20                 sub rsp, 0x20
00232a0a  488bea                   mov rbp, rdx
00232a0d  4c8b85f0000000           mov r8, qword ptr [rbp + 0xf0]
00232a14  4981c030200000           add r8, 0x2030
00232a1b  4d8b00                   mov r8, qword ptr [r8]
00232a1e  488b9500010000           mov rdx, qword ptr [rbp + 0x100]
00232a25  488b8d08010000           mov rcx, qword ptr [rbp + 0x108]
00232a2c  e8dfe5dcff               call 0x1010
00232a31  4883c420                 add rsp, 0x20
00232a35  5d                       pop rbp
00232a36  c3                       ret
