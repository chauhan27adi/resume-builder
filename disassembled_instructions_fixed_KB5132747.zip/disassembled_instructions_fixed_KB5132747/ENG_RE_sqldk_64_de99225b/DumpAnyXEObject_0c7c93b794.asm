; DumpAnyXEObject
; sqldk.dll, primary RVA 0x1facc0, 1082 bytes in 13 chunk(s)

; chunk at RVA 0x1facc0 (78 bytes)
001facc0  4885d2                   test rdx, rdx
001facc3  0f8485010000             je 0x1fae4e
001facc9  55                       push rbp
001facca  53                       push rbx
001faccb  56                       push rsi
001faccc  488bec                   mov rbp, rsp
001faccf  4881ec80000000           sub rsp, 0x80
001facd6  488b01                   mov rax, qword ptr [rcx]
001facd9  4c8d4204                 lea r8, [rdx + 4]
001facdd  488bda                   mov rbx, rdx
001face0  41b904000000             mov r9d, 4
001face6  488d5530                 lea rdx, [rbp + 0x30]
001facea  488bf1                   mov rsi, rcx
001faced  ff5058                   call qword ptr [rax + 0x58]
001facf0  85c0                     test eax, eax
001facf2  0f884c010000             js 0x1fae44
001facf8  8b4530                   mov eax, dword ptr [rbp + 0x30]
001facfb  c1e81c                   shr eax, 0x1c
001facfe  83f808                   cmp eax, 8
001fad01  0f873d010000             ja 0x1fae44
001fad07  488d15f252e0ff           lea rdx, [rip - 0x1fad0e]

; chunk at RVA 0x1fad0e (129 bytes)
001fad0e  4c89742470               mov qword ptr [rsp + 0x70], r14
001fad13  8b8c82d8b01f00           mov ecx, dword ptr [rdx + rax*4 + 0x1fb0d8]
001fad1a  4803ca                   add rcx, rdx
001fad1d  ffe1                     jmp rcx
001fad1f  0faee8                   lfence
001fad22  4533f6                   xor r14d, r14d
001fad25  4c8975a0                 mov qword ptr [rbp - 0x60], r14
001fad29  0faee8                   lfence
001fad2c  488b06                   mov rax, qword ptr [rsi]
001fad2f  458d4648                 lea r8d, [r14 + 0x48]
001fad33  488bd3                   mov rdx, rbx
001fad36  488bce                   mov rcx, rsi
001fad39  ff5060                   call qword ptr [rax + 0x60]
001fad3c  488b06                   mov rax, qword ptr [rsi]
001fad3f  4c8d4308                 lea r8, [rbx + 8]
001fad43  458d4e08                 lea r9d, [r14 + 8]
001fad47  488bce                   mov rcx, rsi
001fad4a  488d55a0                 lea rdx, [rbp - 0x60]
001fad4e  ff5058                   call qword ptr [rax + 0x58]
001fad51  85c0                     test eax, eax
001fad53  7816                     js 0x1fad6b
001fad55  0faee8                   lfence
001fad58  488b06                   mov rax, qword ptr [rsi]
001fad5b  41b800010000             mov r8d, 0x100
001fad61  488b55a0                 mov rdx, qword ptr [rbp - 0x60]
001fad65  488bce                   mov rcx, rsi
001fad68  ff5060                   call qword ptr [rax + 0x60]
001fad6b  488b06                   mov rax, qword ptr [rsi]
001fad6e  4c8d4324                 lea r8, [rbx + 0x24]
001fad72  41b902000000             mov r9d, 2
001fad78  6644897528               mov word ptr [rbp + 0x28], r14w
001fad7d  488d5528                 lea rdx, [rbp + 0x28]
001fad81  488bce                   mov rcx, rsi
001fad84  ff5058                   call qword ptr [rax + 0x58]
001fad87  85c0                     test eax, eax
001fad89  0f88b0000000             js 0x1fae3f

; chunk at RVA 0x1fad8f (176 bytes)
001fad8f  48897c2478               mov qword ptr [rsp + 0x78], rdi
001fad94  0faee8                   lfence
001fad97  0fb74528                 movzx eax, word ptr [rbp + 0x28]
001fad9b  4c8d4340                 lea r8, [rbx + 0x40]
001fad9f  bf00040000               mov edi, 0x400
001fada4  4c897538                 mov qword ptr [rbp + 0x38], r14
001fada8  483bc7                   cmp rax, rdi
001fadab  488d5538                 lea rdx, [rbp + 0x38]
001fadaf  41b908000000             mov r9d, 8
001fadb5  488bce                   mov rcx, rsi
001fadb8  0f42f8                   cmovb edi, eax
001fadbb  488b06                   mov rax, qword ptr [rsi]
001fadbe  ff5058                   call qword ptr [rax + 0x58]
001fadc1  85c0                     test eax, eax
001fadc3  7875                     js 0x1fae3a
001fadc5  0faee8                   lfence
001fadc8  488b06                   mov rax, qword ptr [rsi]
001fadcb  4c8d04bf                 lea r8, [rdi + rdi*4]
001fadcf  488b5538                 mov rdx, qword ptr [rbp + 0x38]
001fadd3  488bce                   mov rcx, rsi
001fadd6  49c1e003                 shl r8, 3
001fadda  ff5060                   call qword ptr [rax + 0x60]
001faddd  418bde                   mov ebx, r14d
001fade0  4885ff                   test rdi, rdi
001fade3  7455                     je 0x1fae3a
001fade5  498bc6                   mov rax, r14
001fade8  0f1f840000000000         nop dword ptr [rax + rax]
001fadf0  488d0c80                 lea rcx, [rax + rax*4]
001fadf4  4c8975a8                 mov qword ptr [rbp - 0x58], r14
001fadf8  488b4538                 mov rax, qword ptr [rbp + 0x38]
001fadfc  488d4901                 lea rcx, [rcx + 1]
001fae00  41b908000000             mov r9d, 8
001fae06  488d55a8                 lea rdx, [rbp - 0x58]
001fae0a  4c8d04c8                 lea r8, [rax + rcx*8]
001fae0e  488b06                   mov rax, qword ptr [rsi]
001fae11  488bce                   mov rcx, rsi
001fae14  ff5058                   call qword ptr [rax + 0x58]
001fae17  85c0                     test eax, eax
001fae19  7816                     js 0x1fae31
001fae1b  0faee8                   lfence
001fae1e  488b06                   mov rax, qword ptr [rsi]
001fae21  41b800010000             mov r8d, 0x100
001fae27  488b55a8                 mov rdx, qword ptr [rbp - 0x58]
001fae2b  488bce                   mov rcx, rsi
001fae2e  ff5060                   call qword ptr [rax + 0x60]
001fae31  ffc3                     inc ebx
001fae33  8bc3                     mov eax, ebx
001fae35  483bc7                   cmp rax, rdi
001fae38  72b6                     jb 0x1fadf0
001fae3a  488b7c2478               mov rdi, qword ptr [rsp + 0x78]

; chunk at RVA 0x1fae3f (5 bytes)
001fae3f  4c8b742470               mov r14, qword ptr [rsp + 0x70]

; chunk at RVA 0x1fae44 (11 bytes)
001fae44  4881c480000000           add rsp, 0x80
001fae4b  5e                       pop rsi
001fae4c  5b                       pop rbx
001fae4d  5d                       pop rbp
001fae4e  c3                       ret

; chunk at RVA 0x1fae4f (89 bytes)
001fae4f  4533f6                   xor r14d, r14d
001fae52  4c8975b0                 mov qword ptr [rbp - 0x50], r14
001fae56  0faee8                   lfence
001fae59  488b06                   mov rax, qword ptr [rsi]
001fae5c  458d4648                 lea r8d, [r14 + 0x48]
001fae60  488bd3                   mov rdx, rbx
001fae63  488bce                   mov rcx, rsi
001fae66  ff5060                   call qword ptr [rax + 0x60]
001fae69  488b06                   mov rax, qword ptr [rsi]
001fae6c  4c8d4308                 lea r8, [rbx + 8]
001fae70  458d4e08                 lea r9d, [r14 + 8]
001fae74  488bce                   mov rcx, rsi
001fae77  488d55b0                 lea rdx, [rbp - 0x50]
001fae7b  ff5058                   call qword ptr [rax + 0x58]
001fae7e  85c0                     test eax, eax
001fae80  78bd                     js 0x1fae3f
001fae82  0faee8                   lfence
001fae85  488b06                   mov rax, qword ptr [rsi]
001fae88  41b800010000             mov r8d, 0x100
001fae8e  488b55b0                 mov rdx, qword ptr [rbp - 0x50]
001fae92  488bce                   mov rcx, rsi
001fae95  ff5060                   call qword ptr [rax + 0x60]
001fae98  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001fae9d  4881c480000000           add rsp, 0x80
001faea4  5e                       pop rsi
001faea5  5b                       pop rbx
001faea6  5d                       pop rbp
001faea7  c3                       ret

; chunk at RVA 0x1faea8 (93 bytes)
001faea8  4533f6                   xor r14d, r14d
001faeab  4c8975b8                 mov qword ptr [rbp - 0x48], r14
001faeaf  0faee8                   lfence
001faeb2  488b06                   mov rax, qword ptr [rsi]
001faeb5  458d4638                 lea r8d, [r14 + 0x38]
001faeb9  488bd3                   mov rdx, rbx
001faebc  488bce                   mov rcx, rsi
001faebf  ff5060                   call qword ptr [rax + 0x60]
001faec2  488b06                   mov rax, qword ptr [rsi]
001faec5  4c8d4308                 lea r8, [rbx + 8]
001faec9  458d4e08                 lea r9d, [r14 + 8]
001faecd  488bce                   mov rcx, rsi
001faed0  488d55b8                 lea rdx, [rbp - 0x48]
001faed4  ff5058                   call qword ptr [rax + 0x58]
001faed7  85c0                     test eax, eax
001faed9  0f8860ffffff             js 0x1fae3f
001faedf  0faee8                   lfence
001faee2  488b06                   mov rax, qword ptr [rsi]
001faee5  41b800010000             mov r8d, 0x100
001faeeb  488b55b8                 mov rdx, qword ptr [rbp - 0x48]
001faeef  488bce                   mov rcx, rsi
001faef2  ff5060                   call qword ptr [rax + 0x60]
001faef5  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001faefa  4881c480000000           add rsp, 0x80
001faf01  5e                       pop rsi
001faf02  5b                       pop rbx
001faf03  5d                       pop rbp
001faf04  c3                       ret

; chunk at RVA 0x1faf05 (93 bytes)
001faf05  4533f6                   xor r14d, r14d
001faf08  4c8975c0                 mov qword ptr [rbp - 0x40], r14
001faf0c  0faee8                   lfence
001faf0f  488b06                   mov rax, qword ptr [rsi]
001faf12  458d4630                 lea r8d, [r14 + 0x30]
001faf16  488bd3                   mov rdx, rbx
001faf19  488bce                   mov rcx, rsi
001faf1c  ff5060                   call qword ptr [rax + 0x60]
001faf1f  488b06                   mov rax, qword ptr [rsi]
001faf22  4c8d4308                 lea r8, [rbx + 8]
001faf26  458d4e08                 lea r9d, [r14 + 8]
001faf2a  488bce                   mov rcx, rsi
001faf2d  488d55c0                 lea rdx, [rbp - 0x40]
001faf31  ff5058                   call qword ptr [rax + 0x58]
001faf34  85c0                     test eax, eax
001faf36  0f8803ffffff             js 0x1fae3f
001faf3c  0faee8                   lfence
001faf3f  488b06                   mov rax, qword ptr [rsi]
001faf42  41b800010000             mov r8d, 0x100
001faf48  488b55c0                 mov rdx, qword ptr [rbp - 0x40]
001faf4c  488bce                   mov rcx, rsi
001faf4f  ff5060                   call qword ptr [rax + 0x60]
001faf52  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001faf57  4881c480000000           add rsp, 0x80
001faf5e  5e                       pop rsi
001faf5f  5b                       pop rbx
001faf60  5d                       pop rbp
001faf61  c3                       ret

; chunk at RVA 0x1faf62 (93 bytes)
001faf62  4533f6                   xor r14d, r14d
001faf65  4c8975c8                 mov qword ptr [rbp - 0x38], r14
001faf69  0faee8                   lfence
001faf6c  488b06                   mov rax, qword ptr [rsi]
001faf6f  458d4650                 lea r8d, [r14 + 0x50]
001faf73  488bd3                   mov rdx, rbx
001faf76  488bce                   mov rcx, rsi
001faf79  ff5060                   call qword ptr [rax + 0x60]
001faf7c  488b06                   mov rax, qword ptr [rsi]
001faf7f  4c8d4308                 lea r8, [rbx + 8]
001faf83  458d4e08                 lea r9d, [r14 + 8]
001faf87  488bce                   mov rcx, rsi
001faf8a  488d55c8                 lea rdx, [rbp - 0x38]
001faf8e  ff5058                   call qword ptr [rax + 0x58]
001faf91  85c0                     test eax, eax
001faf93  0f88a6feffff             js 0x1fae3f
001faf99  0faee8                   lfence
001faf9c  488b06                   mov rax, qword ptr [rsi]
001faf9f  41b800010000             mov r8d, 0x100
001fafa5  488b55c8                 mov rdx, qword ptr [rbp - 0x38]
001fafa9  488bce                   mov rcx, rsi
001fafac  ff5060                   call qword ptr [rax + 0x60]
001fafaf  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001fafb4  4881c480000000           add rsp, 0x80
001fafbb  5e                       pop rsi
001fafbc  5b                       pop rbx
001fafbd  5d                       pop rbp
001fafbe  c3                       ret

; chunk at RVA 0x1fafbf (93 bytes)
001fafbf  4533f6                   xor r14d, r14d
001fafc2  4c8975d0                 mov qword ptr [rbp - 0x30], r14
001fafc6  0faee8                   lfence
001fafc9  488b06                   mov rax, qword ptr [rsi]
001fafcc  458d4660                 lea r8d, [r14 + 0x60]
001fafd0  488bd3                   mov rdx, rbx
001fafd3  488bce                   mov rcx, rsi
001fafd6  ff5060                   call qword ptr [rax + 0x60]
001fafd9  488b06                   mov rax, qword ptr [rsi]
001fafdc  4c8d4308                 lea r8, [rbx + 8]
001fafe0  458d4e08                 lea r9d, [r14 + 8]
001fafe4  488bce                   mov rcx, rsi
001fafe7  488d55d0                 lea rdx, [rbp - 0x30]
001fafeb  ff5058                   call qword ptr [rax + 0x58]
001fafee  85c0                     test eax, eax
001faff0  0f8849feffff             js 0x1fae3f
001faff6  0faee8                   lfence
001faff9  488b06                   mov rax, qword ptr [rsi]
001faffc  41b800010000             mov r8d, 0x100
001fb002  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
001fb006  488bce                   mov rcx, rsi
001fb009  ff5060                   call qword ptr [rax + 0x60]
001fb00c  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001fb011  4881c480000000           add rsp, 0x80
001fb018  5e                       pop rsi
001fb019  5b                       pop rbx
001fb01a  5d                       pop rbp
001fb01b  c3                       ret

; chunk at RVA 0x1fb01c (93 bytes)
001fb01c  4533f6                   xor r14d, r14d
001fb01f  4c8975d8                 mov qword ptr [rbp - 0x28], r14
001fb023  0faee8                   lfence
001fb026  488b06                   mov rax, qword ptr [rsi]
001fb029  458d4628                 lea r8d, [r14 + 0x28]
001fb02d  488bd3                   mov rdx, rbx
001fb030  488bce                   mov rcx, rsi
001fb033  ff5060                   call qword ptr [rax + 0x60]
001fb036  488b06                   mov rax, qword ptr [rsi]
001fb039  4c8d4308                 lea r8, [rbx + 8]
001fb03d  458d4e08                 lea r9d, [r14 + 8]
001fb041  488bce                   mov rcx, rsi
001fb044  488d55d8                 lea rdx, [rbp - 0x28]
001fb048  ff5058                   call qword ptr [rax + 0x58]
001fb04b  85c0                     test eax, eax
001fb04d  0f88ecfdffff             js 0x1fae3f
001fb053  0faee8                   lfence
001fb056  488b06                   mov rax, qword ptr [rsi]
001fb059  41b800010000             mov r8d, 0x100
001fb05f  488b55d8                 mov rdx, qword ptr [rbp - 0x28]
001fb063  488bce                   mov rcx, rsi
001fb066  ff5060                   call qword ptr [rax + 0x60]
001fb069  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001fb06e  4881c480000000           add rsp, 0x80
001fb075  5e                       pop rsi
001fb076  5b                       pop rbx
001fb077  5d                       pop rbp
001fb078  c3                       ret

; chunk at RVA 0x1fb079 (93 bytes)
001fb079  4533f6                   xor r14d, r14d
001fb07c  4c8975e0                 mov qword ptr [rbp - 0x20], r14
001fb080  0faee8                   lfence
001fb083  488b06                   mov rax, qword ptr [rsi]
001fb086  458d4658                 lea r8d, [r14 + 0x58]
001fb08a  488bd3                   mov rdx, rbx
001fb08d  488bce                   mov rcx, rsi
001fb090  ff5060                   call qword ptr [rax + 0x60]
001fb093  488b06                   mov rax, qword ptr [rsi]
001fb096  4c8d4308                 lea r8, [rbx + 8]
001fb09a  458d4e08                 lea r9d, [r14 + 8]
001fb09e  488bce                   mov rcx, rsi
001fb0a1  488d55e0                 lea rdx, [rbp - 0x20]
001fb0a5  ff5058                   call qword ptr [rax + 0x58]
001fb0a8  85c0                     test eax, eax
001fb0aa  0f888ffdffff             js 0x1fae3f
001fb0b0  0faee8                   lfence
001fb0b3  488b06                   mov rax, qword ptr [rsi]
001fb0b6  41b800010000             mov r8d, 0x100
001fb0bc  488b55e0                 mov rdx, qword ptr [rbp - 0x20]
001fb0c0  488bce                   mov rcx, rsi
001fb0c3  ff5060                   call qword ptr [rax + 0x60]
001fb0c6  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001fb0cb  4881c480000000           add rsp, 0x80
001fb0d2  5e                       pop rsi
001fb0d3  5b                       pop rbx
001fb0d4  5d                       pop rbp
001fb0d5  c3                       ret

; chunk at RVA 0x1fb0d8 (36 bytes)
