; CMemThread<CMemAligned<CMemProc> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcd690, 55 bytes in 1 chunk(s)

; chunk at RVA 0xcd690 (55 bytes)
000cd690  48895c2408               mov qword ptr [rsp + 8], rbx
000cd695  57                       push rdi
000cd696  4883ec20                 sub rsp, 0x20
000cd69a  8bda                     mov ebx, edx
000cd69c  488bf9                   mov rdi, rcx
000cd69f  e8fc89ffff               call 0xc60a0
000cd6a4  83e305                   and ebx, 5
000cd6a7  80fb05                   cmp bl, 5
000cd6aa  750d                     jne 0xcd6b9
000cd6ac  ba80010000               mov edx, 0x180
000cd6b1  488bcf                   mov rcx, rdi
000cd6b4  e85739f3ff               call 0x1010
000cd6b9  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000cd6be  488bc7                   mov rax, rdi
000cd6c1  4883c420                 add rsp, 0x20
000cd6c5  5f                       pop rdi
000cd6c6  c3                       ret
