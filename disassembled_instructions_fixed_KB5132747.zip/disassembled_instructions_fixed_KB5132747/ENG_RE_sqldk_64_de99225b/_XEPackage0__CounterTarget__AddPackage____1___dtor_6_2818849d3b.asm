; `XEPackage0::CounterTarget::AddPackage'::`1'::dtor$6
; sqldk.dll, primary RVA 0x23196f, 45 bytes in 1 chunk(s)

; chunk at RVA 0x23196f (45 bytes)
0023196f  4055                     push rbp
00231971  4883ec20                 sub rsp, 0x20
00231975  488bea                   mov rbp, rdx
00231978  488b8db0000000           mov rcx, qword ptr [rbp + 0xb0]
0023197f  4c8d0d0a5ae1ff           lea r9, [rip - 0x1ea5f6]
00231986  41b880000000             mov r8d, 0x80
0023198c  ba18000000               mov edx, 0x18
00231991  e88a2edfff               call 0x24820
00231996  4883c420                 add rsp, 0x20
0023199a  5d                       pop rbp
0023199b  c3                       ret
