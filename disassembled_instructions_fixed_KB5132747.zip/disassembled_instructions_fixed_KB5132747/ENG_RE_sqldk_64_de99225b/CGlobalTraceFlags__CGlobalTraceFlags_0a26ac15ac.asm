; CGlobalTraceFlags::CGlobalTraceFlags
; sqldk.dll, primary RVA 0x1b5130, 49 bytes in 1 chunk(s)

; chunk at RVA 0x1b5130 (49 bytes)
001b5130  4053                     push rbx
001b5132  4883ec20                 sub rsp, 0x20
001b5136  488bd9                   mov rbx, rcx
001b5139  4c8d0d10f5ffff           lea r9, [rip - 0xaf0]
001b5140  488d0da9211900           lea rcx, [rip + 0x1921a9]
001b5147  ba39160000               mov edx, 0x1639
001b514c  41b818000000             mov r8d, 0x18
001b5152  ff1500490800             call qword ptr [rip + 0x84900]
001b5158  488bc3                   mov rax, rbx
001b515b  4883c420                 add rsp, 0x20
001b515f  5b                       pop rbx
001b5160  c3                       ret
