; CMemThread<CMemDbg<CMemProc> >::~CMemThread<CMemDbg<CMemProc> >
; sqldk.dll, primary RVA 0xd4d90, 63 bytes in 1 chunk(s)

; chunk at RVA 0xd4d90 (63 bytes)
000d4d90  48894c2408               mov qword ptr [rsp + 8], rcx
000d4d95  4883ec38                 sub rsp, 0x38
000d4d99  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d4da2  488d056f5d1700           lea rax, [rip + 0x175d6f]
000d4da9  488901                   mov qword ptr [rcx], rax
000d4dac  488d8170040000           lea rax, [rcx + 0x470]
000d4db3  4889442448               mov qword ptr [rsp + 0x48], rax
000d4db8  488d15814d1600           lea rdx, [rip + 0x164d81]
000d4dbf  48895030                 mov qword ptr [rax + 0x30], rdx
000d4dc3  488910                   mov qword ptr [rax], rdx
000d4dc6  4883c438                 add rsp, 0x38
000d4dca  e901ad0900               jmp 0x16fad0
