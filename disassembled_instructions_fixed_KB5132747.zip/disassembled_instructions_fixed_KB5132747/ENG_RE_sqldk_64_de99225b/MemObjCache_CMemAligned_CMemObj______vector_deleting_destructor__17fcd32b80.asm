; MemObjCache<CMemAligned<CMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13efe0, 131 bytes in 1 chunk(s)

; chunk at RVA 0x13efe0 (131 bytes)
0013efe0  48894c2408               mov qword ptr [rsp + 8], rcx
0013efe5  57                       push rdi
0013efe6  4883ec30                 sub rsp, 0x30
0013efea  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013eff3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013eff8  8bda                     mov ebx, edx
0013effa  488bf9                   mov rdi, rcx
0013effd  488d0504881000           lea rax, [rip + 0x108804]
0013f004  488901                   mov qword ptr [rcx], rax
0013f007  488d057ac81000           lea rax, [rip + 0x10c87a]
0013f00e  488901                   mov qword ptr [rcx], rax
0013f011  488d05507f1000           lea rax, [rip + 0x107f50]
0013f018  488901                   mov qword ptr [rcx], rax
0013f01b  488d05e6811000           lea rax, [rip + 0x1081e6]
0013f022  488901                   mov qword ptr [rcx], rax
0013f025  4883c138                 add rcx, 0x38
0013f029  e8c225edff               call 0x115f0
0013f02e  90                       nop
0013f02f  488d4f30                 lea rcx, [rdi + 0x30]
0013f033  e8b825edff               call 0x115f0
0013f038  90                       nop
0013f039  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013f040  83e305                   and ebx, 5
0013f043  80fb05                   cmp bl, 5
0013f046  750d                     jne 0x13f055
0013f048  ba80010000               mov edx, 0x180
0013f04d  488bcf                   mov rcx, rdi
0013f050  e8bb1fecff               call 0x1010
0013f055  488bc7                   mov rax, rdi
0013f058  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013f05d  4883c430                 add rsp, 0x30
0013f061  5f                       pop rdi
0013f062  c3                       ret
