; CAutoP<XEPackage0::OrphanEntry>::~CAutoP<XEPackage0::OrphanEntry>
; sqldk.dll, primary RVA 0x1ccbb0, 68 bytes in 1 chunk(s)

; chunk at RVA 0x1ccbb0 (68 bytes)
001ccbb0  4053                     push rbx
001ccbb2  4883ec30                 sub rsp, 0x30
001ccbb6  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001ccbbf  488b19                   mov rbx, qword ptr [rcx]
001ccbc2  48895c2440               mov qword ptr [rsp + 0x40], rbx
001ccbc7  4885db                   test rbx, rbx
001ccbca  7422                     je 0x1ccbee
001ccbcc  837b2c00                 cmp dword ptr [rbx + 0x2c], 0
001ccbd0  750a                     jne 0x1ccbdc
001ccbd2  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
001ccbd6  ff1574841400             call qword ptr [rip + 0x148474]
001ccbdc  ba48000000               mov edx, 0x48
001ccbe1  488bcb                   mov rcx, rbx
001ccbe4  4883c430                 add rsp, 0x30
001ccbe8  5b                       pop rbx
001ccbe9  e942a3e3ff               jmp 0x6f30
001ccbee  4883c430                 add rsp, 0x30
001ccbf2  5b                       pop rbx
001ccbf3  c3                       ret
