; `XEPackage0::PairingTarget::ParseEventActions'::`1'::dtor$2
; sqldk.dll, primary RVA 0x23128c, 41 bytes in 1 chunk(s)

; chunk at RVA 0x23128c (41 bytes)
0023128c  4055                     push rbp
0023128e  4883ec20                 sub rsp, 0x20
00231292  488bea                   mov rbp, rdx
00231295  4c8b85a8000000           mov r8, qword ptr [rbp + 0xa8]
0023129c  488b95b0000000           mov rdx, qword ptr [rbp + 0xb0]
002312a3  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
002312aa  e861fddcff               call 0x1010
002312af  4883c420                 add rsp, 0x20
002312b3  5d                       pop rbp
002312b4  c3                       ret
