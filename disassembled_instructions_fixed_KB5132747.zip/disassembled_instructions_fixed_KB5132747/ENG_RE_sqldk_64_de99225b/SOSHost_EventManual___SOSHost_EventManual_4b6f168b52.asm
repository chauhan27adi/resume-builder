; SOSHost_EventManual::~SOSHost_EventManual
; sqldk.dll, primary RVA 0xadcc0, 67 bytes in 1 chunk(s)

; chunk at RVA 0xadcc0 (67 bytes)
000adcc0  48894c2408               mov qword ptr [rsp + 8], rcx
000adcc5  53                       push rbx
000adcc6  4883ec30                 sub rsp, 0x30
000adcca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000adcd3  488bd9                   mov rbx, rcx
000adcd6  488d05f3971900           lea rax, [rip + 0x1997f3]
000adcdd  488901                   mov qword ptr [rcx], rax
000adce0  488b8918010000           mov rcx, qword ptr [rcx + 0x118]
000adce7  4885c9                   test rcx, rcx
000adcea  7407                     je 0xadcf3
000adcec  488b01                   mov rax, qword ptr [rcx]
000adcef  ff5008                   call qword ptr [rax + 8]
000adcf2  90                       nop
000adcf3  488d0526981900           lea rax, [rip + 0x199826]
000adcfa  488903                   mov qword ptr [rbx], rax
000adcfd  4883c430                 add rsp, 0x30
000add01  5b                       pop rbx
000add02  c3                       ret
