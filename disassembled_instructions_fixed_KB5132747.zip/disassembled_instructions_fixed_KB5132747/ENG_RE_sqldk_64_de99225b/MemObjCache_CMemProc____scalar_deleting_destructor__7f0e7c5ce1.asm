; MemObjCache<CMemProc>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13dba0, 121 bytes in 1 chunk(s)

; chunk at RVA 0x13dba0 (121 bytes)
0013dba0  48894c2408               mov qword ptr [rsp + 8], rcx
0013dba5  57                       push rdi
0013dba6  4883ec30                 sub rsp, 0x30
0013dbaa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013dbb3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013dbb8  8bda                     mov ebx, edx
0013dbba  488bf9                   mov rdi, rcx
0013dbbd  488d05acd01000           lea rax, [rip + 0x10d0ac]
0013dbc4  488901                   mov qword ptr [rcx], rax
0013dbc7  488d058a971000           lea rax, [rip + 0x10978a]
0013dbce  488901                   mov qword ptr [rcx], rax
0013dbd1  488d0530961000           lea rax, [rip + 0x109630]
0013dbd8  488901                   mov qword ptr [rcx], rax
0013dbdb  4883c138                 add rcx, 0x38
0013dbdf  e80c3aedff               call 0x115f0
0013dbe4  90                       nop
0013dbe5  488d4f30                 lea rcx, [rdi + 0x30]
0013dbe9  e8023aedff               call 0x115f0
0013dbee  90                       nop
0013dbef  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013dbf6  83e305                   and ebx, 5
0013dbf9  80fb05                   cmp bl, 5
0013dbfc  750d                     jne 0x13dc0b
0013dbfe  baf0000000               mov edx, 0xf0
0013dc03  488bcf                   mov rcx, rdi
0013dc06  e80534ecff               call 0x1010
0013dc0b  488bc7                   mov rax, rdi
0013dc0e  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013dc13  4883c430                 add rsp, 0x30
0013dc17  5f                       pop rdi
0013dc18  c3                       ret
