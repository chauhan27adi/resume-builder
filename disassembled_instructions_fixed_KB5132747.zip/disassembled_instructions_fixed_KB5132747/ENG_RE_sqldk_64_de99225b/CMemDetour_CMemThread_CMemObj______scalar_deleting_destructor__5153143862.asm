; CMemDetour<CMemThread<CMemObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xced30, 104 bytes in 1 chunk(s)

; chunk at RVA 0xced30 (104 bytes)
000ced30  48894c2408               mov qword ptr [rsp + 8], rcx
000ced35  57                       push rdi
000ced36  4883ec30                 sub rsp, 0x30
000ced3a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ced43  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ced48  8bda                     mov ebx, edx
000ced4a  488bf9                   mov rdi, rcx
000ced4d  488d059cd41700           lea rax, [rip + 0x17d49c]
000ced54  488901                   mov qword ptr [rcx], rax
000ced57  488d8140020000           lea rax, [rcx + 0x240]
000ced5e  4889442450               mov qword ptr [rsp + 0x50], rax
000ced63  488d0dd6ad1600           lea rcx, [rip + 0x16add6]
000ced6a  488908                   mov qword ptr [rax], rcx
000ced6d  488bcf                   mov rcx, rdi
000ced70  e81bb40500               call 0x12a190
000ced75  83e305                   and ebx, 5
000ced78  80fb05                   cmp bl, 5
000ced7b  750d                     jne 0xced8a
000ced7d  ba78020000               mov edx, 0x278
000ced82  488bcf                   mov rcx, rdi
000ced85  e88622f3ff               call 0x1010
000ced8a  488bc7                   mov rax, rdi
000ced8d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ced92  4883c430                 add rsp, 0x30
000ced96  5f                       pop rdi
000ced97  c3                       ret
