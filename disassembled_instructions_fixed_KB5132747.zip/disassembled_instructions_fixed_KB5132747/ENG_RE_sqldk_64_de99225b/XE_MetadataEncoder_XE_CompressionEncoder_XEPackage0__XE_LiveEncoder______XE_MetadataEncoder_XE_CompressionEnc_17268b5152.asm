; XE_MetadataEncoder<XE_CompressionEncoder<XEPackage0::XE_LiveEncoder> >::~XE_MetadataEncoder<XE_CompressionEncoder<XEPackage0::XE_LiveEncoder> >
; sqldk.dll, primary RVA 0x1d23a0, 36 bytes in 1 chunk(s)

; chunk at RVA 0x1d23a0 (36 bytes)
001d23a0  48894c2408               mov qword ptr [rsp + 8], rcx
001d23a5  4883ec38                 sub rsp, 0x38
001d23a9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001d23b2  48894c2448               mov qword ptr [rsp + 0x48], rcx
001d23b7  4883c110                 add rcx, 0x10
001d23bb  4883c438                 add rsp, 0x38
001d23bf  e93c35e7ff               jmp 0x45900
