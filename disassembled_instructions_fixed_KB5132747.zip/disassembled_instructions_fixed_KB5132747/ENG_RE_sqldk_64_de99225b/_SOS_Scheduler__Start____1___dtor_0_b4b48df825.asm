; `SOS_Scheduler::Start'::`1'::dtor$0
; sqldk.dll, primary RVA 0x219a80, 63 bytes in 1 chunk(s)

; chunk at RVA 0x219a80 (63 bytes)
00219a80  4055                     push rbp
00219a82  4883ec30                 sub rsp, 0x30
00219a86  488bea                   mov rbp, rdx
00219a89  488b5550                 mov rdx, qword ptr [rbp + 0x50]
00219a8d  4881c2780e0000           add rdx, 0xe78
00219a94  c644242806               mov byte ptr [rsp + 0x28], 6
00219a99  8b4540                   mov eax, dword ptr [rbp + 0x40]
00219a9c  89442420                 mov dword ptr [rsp + 0x20], eax
00219aa0  4c8d0dc9070600           lea r9, [rip + 0x607c9]
00219aa7  41b801000000             mov r8d, 1
00219aad  488b12                   mov rdx, qword ptr [rdx]
00219ab0  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
00219ab4  e857d4deff               call 0x6f10
00219ab9  4883c430                 add rsp, 0x30
00219abd  5d                       pop rbp
00219abe  c3                       ret
