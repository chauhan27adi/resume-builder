; MemObjCache<CMemFixed>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e4e0, 121 bytes in 1 chunk(s)

; chunk at RVA 0x13e4e0 (121 bytes)
0013e4e0  48894c2408               mov qword ptr [rsp + 8], rcx
0013e4e5  57                       push rdi
0013e4e6  4883ec30                 sub rsp, 0x30
0013e4ea  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e4f3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e4f8  8bda                     mov ebx, edx
0013e4fa  488bf9                   mov rdi, rcx
0013e4fd  488d058cac1000           lea rax, [rip + 0x10ac8c]
0013e504  488901                   mov qword ptr [rcx], rax
0013e507  488d05aa8b1000           lea rax, [rip + 0x108baa]
0013e50e  488901                   mov qword ptr [rcx], rax
0013e511  488d05f08c1000           lea rax, [rip + 0x108cf0]
0013e518  488901                   mov qword ptr [rcx], rax
0013e51b  4883c138                 add rcx, 0x38
0013e51f  e8cc30edff               call 0x115f0
0013e524  90                       nop
0013e525  488d4f30                 lea rcx, [rdi + 0x30]
0013e529  e8c230edff               call 0x115f0
0013e52e  90                       nop
0013e52f  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013e536  83e305                   and ebx, 5
0013e539  80fb05                   cmp bl, 5
0013e53c  750d                     jne 0x13e54b
0013e53e  ba58010000               mov edx, 0x158
0013e543  488bcf                   mov rcx, rdi
0013e546  e8c52aecff               call 0x1010
0013e54b  488bc7                   mov rax, rdi
0013e54e  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e553  4883c430                 add rsp, 0x30
0013e557  5f                       pop rdi
0013e558  c3                       ret
