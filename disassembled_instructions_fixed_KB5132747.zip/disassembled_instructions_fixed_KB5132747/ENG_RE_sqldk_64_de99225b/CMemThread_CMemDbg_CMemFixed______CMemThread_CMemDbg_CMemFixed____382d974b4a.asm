; CMemThread<CMemDbg<CMemFixed> >::~CMemThread<CMemDbg<CMemFixed> >
; sqldk.dll, primary RVA 0xfe720, 63 bytes in 1 chunk(s)

; chunk at RVA 0xfe720 (63 bytes)
000fe720  48894c2408               mov qword ptr [rsp + 8], rcx
000fe725  4883ec38                 sub rsp, 0x38
000fe729  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000fe732  488d05b7af1400           lea rax, [rip + 0x14afb7]
000fe739  488901                   mov qword ptr [rcx], rax
000fe73c  488d81d8040000           lea rax, [rcx + 0x4d8]
000fe743  4889442448               mov qword ptr [rsp + 0x48], rax
000fe748  488d15f1b31300           lea rdx, [rip + 0x13b3f1]
000fe74f  48895030                 mov qword ptr [rax + 0x30], rdx
000fe753  488910                   mov qword ptr [rax], rdx
000fe756  4883c438                 add rsp, 0x38
000fe75a  e901280700               jmp 0x170f60
