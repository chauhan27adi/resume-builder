; `HostManager::CreateSOSHostObject'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21cd30, 53 bytes in 1 chunk(s)

; chunk at RVA 0x21cd30 (53 bytes)
0021cd30  4055                     push rbp
0021cd32  4883ec30                 sub rsp, 0x30
0021cd36  488bea                   mov rbp, rdx
0021cd39  c644242806               mov byte ptr [rsp + 0x28], 6
0021cd3e  8b4538                   mov eax, dword ptr [rbp + 0x38]
0021cd41  89442420                 mov dword ptr [rsp + 0x20], eax
0021cd45  4c8d0d04c40700           lea r9, [rip + 0x7c404]
0021cd4c  41b801000000             mov r8d, 1
0021cd52  488b5578                 mov rdx, qword ptr [rbp + 0x78]
0021cd56  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0021cd5a  e8b1a1deff               call 0x6f10
0021cd5f  4883c430                 add rsp, 0x30
0021cd63  5d                       pop rbp
0021cd64  c3                       ret
