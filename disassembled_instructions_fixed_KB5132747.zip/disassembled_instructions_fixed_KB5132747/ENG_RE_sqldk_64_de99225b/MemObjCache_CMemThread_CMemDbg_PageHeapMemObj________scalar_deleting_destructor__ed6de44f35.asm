; MemObjCache<CMemThread<CMemDbg<PageHeapMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e250, 115 bytes in 1 chunk(s)

; chunk at RVA 0x13e250 (115 bytes)
0013e250  48894c2408               mov qword ptr [rsp + 8], rcx
0013e255  57                       push rdi
0013e256  4883ec30                 sub rsp, 0x30
0013e25a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e263  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e268  8bda                     mov ebx, edx
0013e26a  488bf9                   mov rdi, rcx
0013e26d  488d05ec671200           lea rax, [rip + 0x1267ec]
0013e274  488901                   mov qword ptr [rcx], rax
0013e277  488d058ac01000           lea rax, [rip + 0x10c08a]
0013e27e  488901                   mov qword ptr [rcx], rax
0013e281  488d8150040000           lea rax, [rcx + 0x450]
0013e288  4889442450               mov qword ptr [rsp + 0x50], rax
0013e28d  488d0dacb80f00           lea rcx, [rip + 0xfb8ac]
0013e294  48894830                 mov qword ptr [rax + 0x30], rcx
0013e298  488908                   mov qword ptr [rax], rcx
0013e29b  488bcf                   mov rcx, rdi
0013e29e  e85d410300               call 0x172400
0013e2a3  f6c301                   test bl, 1
0013e2a6  740d                     je 0x13e2b5
0013e2a8  ba78050000               mov edx, 0x578
0013e2ad  488bcf                   mov rcx, rdi
0013e2b0  e87b8cecff               call 0x6f30
0013e2b5  488bc7                   mov rax, rdi
0013e2b8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e2bd  4883c430                 add rsp, 0x30
0013e2c1  5f                       pop rdi
0013e2c2  c3                       ret
