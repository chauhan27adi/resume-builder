; XE_MetadataEncoder<XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker> >::~XE_MetadataEncoder<XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker> >
; sqldk.dll, primary RVA 0x1be2f0, 24 bytes in 1 chunk(s)

; chunk at RVA 0x1be2f0 (24 bytes)
001be2f0  48894c2408               mov qword ptr [rsp + 8], rcx
001be2f5  4883ec38                 sub rsp, 0x38
001be2f9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001be302  4883c438                 add rsp, 0x38
001be306  eb08                     jmp 0x1be310
