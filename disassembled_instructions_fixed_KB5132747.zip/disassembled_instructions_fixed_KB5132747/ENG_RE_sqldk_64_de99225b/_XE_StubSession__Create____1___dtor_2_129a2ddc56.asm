; `XE_StubSession::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x23533e, 56 bytes in 1 chunk(s)

; chunk at RVA 0x23533e (56 bytes)
0023533e  4055                     push rbp
00235340  4883ec30                 sub rsp, 0x30
00235344  488bea                   mov rbp, rdx
00235347  c644242806               mov byte ptr [rsp + 0x28], 6
0023534c  8b4530                   mov eax, dword ptr [rbp + 0x30]
0023534f  89442420                 mov dword ptr [rsp + 0x20], eax
00235353  4c8d0dae550700           lea r9, [rip + 0x755ae]
0023535a  41b801000000             mov r8d, 1
00235360  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
00235367  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
0023536b  e8804bfaff               call 0x1d9ef0
00235370  4883c430                 add rsp, 0x30
00235374  5d                       pop rbp
00235375  c3                       ret
