; XE_CompressionCache::~XE_CompressionCache
; sqldk.dll, primary RVA 0x45900, 153 bytes in 1 chunk(s)

; chunk at RVA 0x45900 (153 bytes)
00045900  48894c2408               mov qword ptr [rsp + 8], rcx
00045905  57                       push rdi
00045906  4883ec30                 sub rsp, 0x30
0004590a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00045913  48895c2448               mov qword ptr [rsp + 0x48], rbx
00045918  4889742450               mov qword ptr [rsp + 0x50], rsi
0004591d  488bf9                   mov rdi, rcx
00045920  488b5118                 mov rdx, qword ptr [rcx + 0x18]
00045924  33f6                     xor esi, esi
00045926  4885d2                   test rdx, rdx
00045929  744b                     je 0x45976
0004592b  488bc2                   mov rax, rdx
0004592e  6690                     nop
00045930  4c8d4718                 lea r8, [rdi + 0x18]
00045934  4885c0                   test rax, rax
00045937  7422                     je 0x4595b
00045939  0f1f00                   nop dword ptr [rax]
0004593c  0f1f4000                 nop dword ptr [rax]
00045940  488b08                   mov rcx, qword ptr [rax]
00045943  483bc2                   cmp rax, rdx
00045946  740d                     je 0x45955
00045948  4c8bc0                   mov r8, rax
0004594b  488bc1                   mov rax, rcx
0004594e  4885c9                   test rcx, rcx
00045951  75ed                     jne 0x45940
00045953  eb06                     jmp 0x4595b
00045955  498908                   mov qword ptr [r8], rcx
00045958  488930                   mov qword ptr [rax], rsi
0004595b  488d4afc                 lea rcx, [rdx - 4]
0004595f  4885c9                   test rcx, rcx
00045962  7406                     je 0x4596a
00045964  ff15e6f62c00             call qword ptr [rip + 0x2cf6e6]
0004596a  488b5718                 mov rdx, qword ptr [rdi + 0x18]
0004596e  488bc2                   mov rax, rdx
00045971  4885d2                   test rdx, rdx
00045974  75ba                     jne 0x45930
00045976  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0004597a  4885c9                   test rcx, rcx
0004597d  7406                     je 0x45985
0004597f  ff1503f72c00             call qword ptr [rip + 0x2cf703]
00045985  48897720                 mov qword ptr [rdi + 0x20], rsi
00045989  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0004598e  488b742450               mov rsi, qword ptr [rsp + 0x50]
00045993  4883c430                 add rsp, 0x30
00045997  5f                       pop rdi
00045998  c3                       ret
