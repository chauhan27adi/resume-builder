; CGlobalTraceFlags::FindDeclaredFlag
; sqldk.dll, primary RVA 0x1b5170, 99 bytes in 1 chunk(s)

; chunk at RVA 0x1b5170 (99 bytes)
001b5170  4883ec58                 sub rsp, 0x58
001b5174  488b050dbf1500           mov rax, qword ptr [rip + 0x15bf0d]
001b517b  4833c4                   xor rax, rsp
001b517e  4889442448               mov qword ptr [rsp + 0x48], rax
001b5183  33c0                     xor eax, eax
001b5185  488d1564211900           lea rdx, [rip + 0x192164]
001b518c  0f57c0                   xorps xmm0, xmm0
001b518f  4889442440               mov qword ptr [rsp + 0x40], rax
001b5194  0f11442430               movups xmmword ptr [rsp + 0x30], xmm0
001b5199  66894c2430               mov word ptr [rsp + 0x30], cx
001b519e  488d05abf4ffff           lea rax, [rip - 0xb55]
001b51a5  488d4c2430               lea rcx, [rsp + 0x30]
001b51aa  4889442420               mov qword ptr [rsp + 0x20], rax
001b51af  41b918000000             mov r9d, 0x18
001b51b5  41b839160000             mov r8d, 0x1639
001b51bb  ff158f480800             call qword ptr [rip + 0x8488f]
001b51c1  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
001b51c6  4833cc                   xor rcx, rsp
001b51c9  e812f4e4ff               call 0x45e0
001b51ce  4883c458                 add rsp, 0x58
001b51d2  c3                       ret
