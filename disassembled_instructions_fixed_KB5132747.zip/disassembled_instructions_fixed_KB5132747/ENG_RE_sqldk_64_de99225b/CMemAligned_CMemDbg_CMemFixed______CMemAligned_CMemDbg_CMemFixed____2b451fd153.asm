; CMemAligned<CMemDbg<CMemFixed> >::~CMemAligned<CMemDbg<CMemFixed> >
; sqldk.dll, primary RVA 0xfb620, 37 bytes in 1 chunk(s)

; chunk at RVA 0xfb620 (37 bytes)
000fb620  48894c2408               mov qword ptr [rsp + 8], rcx
000fb625  4883ec38                 sub rsp, 0x38
000fb629  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000fb632  488d05effc1400           lea rax, [rip + 0x14fcef]
000fb639  488901                   mov qword ptr [rcx], rax
000fb63c  4883c438                 add rsp, 0x38
000fb640  e91b590700               jmp 0x170f60
