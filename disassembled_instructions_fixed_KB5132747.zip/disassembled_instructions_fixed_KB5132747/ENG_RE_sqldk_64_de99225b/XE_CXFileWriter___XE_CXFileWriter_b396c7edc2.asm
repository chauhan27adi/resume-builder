; XE_CXFileWriter::~XE_CXFileWriter
; sqldk.dll, primary RVA 0x4e960, 290 bytes in 1 chunk(s)

; chunk at RVA 0x4e960 (290 bytes)
0004e960  48894c2408               mov qword ptr [rsp + 8], rcx
0004e965  53                       push rbx
0004e966  55                       push rbp
0004e967  56                       push rsi
0004e968  57                       push rdi
0004e969  4156                     push r14
0004e96b  4883ec30                 sub rsp, 0x30
0004e96f  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0004e978  488bf1                   mov rsi, rcx
0004e97b  e810120000               call 0x4fb90
0004e980  488b9e58020000           mov rbx, qword ptr [rsi + 0x258]
0004e987  4533f6                   xor r14d, r14d
0004e98a  4885db                   test rbx, rbx
0004e98d  7462                     je 0x4e9f1
0004e98f  488d6bfc                 lea rbp, [rbx - 4]
0004e993  4883e5f8                 and rbp, 0xfffffffffffffff8
0004e997  418bfe                   mov edi, r14d
0004e99a  397d00                   cmp dword ptr [rbp], edi
0004e99d  7649                     jbe 0x4e9e8
0004e99f  4883c320                 add rbx, 0x20
0004e9a3  0f1f4000                 nop dword ptr [rax]
0004e9a7  660f1f840000000000       nop word ptr [rax + rax]
0004e9b0  488d43e0                 lea rax, [rbx - 0x20]
0004e9b4  4889442468               mov qword ptr [rsp + 0x68], rax
0004e9b9  48895c2470               mov qword ptr [rsp + 0x70], rbx
0004e9be  488b0b                   mov rcx, qword ptr [rbx]
0004e9c1  4885c9                   test rcx, rcx
0004e9c4  7406                     je 0x4e9cc
0004e9c6  ff1584662c00             call qword ptr [rip + 0x2c6684]
0004e9cc  4c8933                   mov qword ptr [rbx], r14
0004e9cf  33d2                     xor edx, edx
0004e9d1  488b0b                   mov rcx, qword ptr [rbx]
0004e9d4  e85785fbff               call 0x6f30
0004e9d9  48ffc7                   inc rdi
0004e9dc  4883c350                 add rbx, 0x50
0004e9e0  8b4500                   mov eax, dword ptr [rbp]
0004e9e3  483bf8                   cmp rdi, rax
0004e9e6  72c8                     jb 0x4e9b0
0004e9e8  488bcd                   mov rcx, rbp
0004e9eb  ff155f662c00             call qword ptr [rip + 0x2c665f]
0004e9f1  488b8ea0020000           mov rcx, qword ptr [rsi + 0x2a0]
0004e9f8  4883f9ff                 cmp rcx, -1
0004e9fc  7406                     je 0x4ea04
0004e9fe  ff1514ab1e00             call qword ptr [rip + 0x1eab14]
0004ea04  488b8eb8020000           mov rcx, qword ptr [rsi + 0x2b8]
0004ea0b  4885c9                   test rcx, rcx
0004ea0e  7430                     je 0x4ea40
0004ea10  4881b9d0bf000039707865   cmp qword ptr [rcx + 0xbfd0], 0x65787039
0004ea1b  7523                     jne 0x4ea40
0004ea1d  488b99c8bf0000           mov rbx, qword ptr [rcx + 0xbfc8]
0004ea24  33d2                     xor edx, edx
0004ea26  41b828d00000             mov r8d, 0xd028
0004ea2c  e8035efbff               call 0x4834
0004ea31  4885db                   test rbx, rbx
0004ea34  740a                     je 0x4ea40
0004ea36  488bcb                   mov rcx, rbx
0004ea39  ff1511662c00             call qword ptr [rip + 0x2c6611]
0004ea3f  90                       nop
0004ea40  488d9e30020000           lea rbx, [rsi + 0x230]
0004ea47  488b0b                   mov rcx, qword ptr [rbx]
0004ea4a  4885c9                   test rcx, rcx
0004ea4d  7406                     je 0x4ea55
0004ea4f  ff15fb652c00             call qword ptr [rip + 0x2c65fb]
0004ea55  4c8933                   mov qword ptr [rbx], r14
0004ea58  48895c2460               mov qword ptr [rsp + 0x60], rbx
0004ea5d  488b0b                   mov rcx, qword ptr [rbx]
0004ea60  4885c9                   test rcx, rcx
0004ea63  7406                     je 0x4ea6b
0004ea65  ff15e5652c00             call qword ptr [rip + 0x2c65e5]
0004ea6b  4c8933                   mov qword ptr [rbx], r14
0004ea6e  33d2                     xor edx, edx
0004ea70  488b0b                   mov rcx, qword ptr [rbx]
0004ea73  4883c430                 add rsp, 0x30
0004ea77  415e                     pop r14
0004ea79  5f                       pop rdi
0004ea7a  5e                       pop rsi
0004ea7b  5d                       pop rbp
0004ea7c  5b                       pop rbx
0004ea7d  e9ae84fbff               jmp 0x6f30
