; CAutoP<XE_PackageFilter>::~CAutoP<XE_PackageFilter>
; sqldk.dll, primary RVA 0x48cd0, 127 bytes in 1 chunk(s)

; chunk at RVA 0x48cd0 (127 bytes)
00048cd0  4053                     push rbx
00048cd2  4883ec30                 sub rsp, 0x30
00048cd6  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00048cdf  488b19                   mov rbx, qword ptr [rcx]
00048ce2  48895c2440               mov qword ptr [rsp + 0x40], rbx
00048ce7  4885db                   test rbx, rbx
00048cea  745d                     je 0x48d49
00048cec  488d4b50                 lea rcx, [rbx + 0x50]
00048cf0  48894c2448               mov qword ptr [rsp + 0x48], rcx
00048cf5  4883c110                 add rcx, 0x10
00048cf9  e8c28fffff               call 0x41cc0
00048cfe  90                       nop
00048cff  488d4b38                 lea rcx, [rbx + 0x38]
00048d03  48894c2450               mov qword ptr [rsp + 0x50], rcx
00048d08  4883c110                 add rcx, 0x10
00048d0c  e8af8fffff               call 0x41cc0
00048d11  90                       nop
00048d12  488d4b20                 lea rcx, [rbx + 0x20]
00048d16  48894c2458               mov qword ptr [rsp + 0x58], rcx
00048d1b  4883c110                 add rcx, 0x10
00048d1f  e89c8fffff               call 0x41cc0
00048d24  90                       nop
00048d25  488d4b08                 lea rcx, [rbx + 8]
00048d29  48894c2440               mov qword ptr [rsp + 0x40], rcx
00048d2e  4883c110                 add rcx, 0x10
00048d32  e8898fffff               call 0x41cc0
00048d37  ba68000000               mov edx, 0x68
00048d3c  488bcb                   mov rcx, rbx
00048d3f  4883c430                 add rsp, 0x30
00048d43  5b                       pop rbx
00048d44  e9e7e1fbff               jmp 0x6f30
00048d49  4883c430                 add rsp, 0x30
00048d4d  5b                       pop rbx
00048d4e  c3                       ret
