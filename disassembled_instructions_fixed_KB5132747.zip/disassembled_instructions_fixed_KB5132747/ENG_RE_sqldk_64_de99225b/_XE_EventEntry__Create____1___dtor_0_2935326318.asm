; `XE_EventEntry::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2359f0, 59 bytes in 1 chunk(s)

; chunk at RVA 0x2359f0 (59 bytes)
002359f0  4055                     push rbp
002359f2  4883ec30                 sub rsp, 0x30
002359f6  488bea                   mov rbp, rdx
002359f9  c644242806               mov byte ptr [rsp + 0x28], 6
002359fe  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00235a04  89442420                 mov dword ptr [rsp + 0x20], eax
00235a08  4c8d0d594f0700           lea r9, [rip + 0x74f59]
00235a0f  41b801000000             mov r8d, 1
00235a15  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
00235a1c  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00235a20  e8cb44faff               call 0x1d9ef0
00235a25  4883c430                 add rsp, 0x30
00235a29  5d                       pop rbp
00235a2a  c3                       ret
