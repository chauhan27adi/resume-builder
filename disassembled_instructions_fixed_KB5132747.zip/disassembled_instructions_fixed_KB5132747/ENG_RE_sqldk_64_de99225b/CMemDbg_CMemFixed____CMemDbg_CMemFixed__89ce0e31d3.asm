; CMemDbg<CMemFixed>::~CMemDbg<CMemFixed>
; sqldk.dll, primary RVA 0x170f60, 99 bytes in 1 chunk(s)

; chunk at RVA 0x170f60 (99 bytes)
00170f60  48894c2408               mov qword ptr [rsp + 8], rcx
00170f65  53                       push rbx
00170f66  4883ec30                 sub rsp, 0x30
00170f6a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00170f73  488bd9                   mov rbx, rcx
00170f76  488d0593ca0d00           lea rax, [rip + 0xdca93]
00170f7d  488901                   mov qword ptr [rcx], rax
00170f80  488d05314d0f00           lea rax, [rip + 0xf4d31]
00170f87  48898118010000           mov qword ptr [rcx + 0x118], rax
00170f8e  488d0523610d00           lea rax, [rip + 0xd6123]
00170f95  488901                   mov qword ptr [rcx], rax
00170f98  488d0569620d00           lea rax, [rip + 0xd6269]
00170f9f  488901                   mov qword ptr [rcx], rax
00170fa2  4883c138                 add rcx, 0x38
00170fa6  e84506eaff               call 0x115f0
00170fab  90                       nop
00170fac  488d4b30                 lea rcx, [rbx + 0x30]
00170fb0  e83b06eaff               call 0x115f0
00170fb5  90                       nop
00170fb6  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
00170fbd  4883c430                 add rsp, 0x30
00170fc1  5b                       pop rbx
00170fc2  c3                       ret
