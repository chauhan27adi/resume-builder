; `ISOSHost_MemoryClerkImpl::OpenSharedMemory'::`1'::dtor$4
; sqldk.dll, primary RVA 0x22903c, 56 bytes in 1 chunk(s)

; chunk at RVA 0x22903c (56 bytes)
0022903c  4055                     push rbp
0022903e  4883ec30                 sub rsp, 0x30
00229042  488bea                   mov rbp, rdx
00229045  c644242806               mov byte ptr [rsp + 0x28], 6
0022904a  8b8580000000             mov eax, dword ptr [rbp + 0x80]
00229050  89442420                 mov dword ptr [rsp + 0x20], eax
00229054  4c8d0d850b0700           lea r9, [rip + 0x70b85]
0022905b  41b801000000             mov r8d, 1
00229061  488b5538                 mov rdx, qword ptr [rbp + 0x38]
00229065  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00229069  e8a2deddff               call 0x6f10
0022906e  4883c430                 add rsp, 0x30
00229072  5d                       pop rbp
00229073  c3                       ret
