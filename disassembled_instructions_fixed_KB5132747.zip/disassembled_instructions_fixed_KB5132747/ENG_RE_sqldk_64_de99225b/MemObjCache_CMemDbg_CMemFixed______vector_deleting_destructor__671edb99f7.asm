; MemObjCache<CMemDbg<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e5f0, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13e5f0 (79 bytes)
0013e5f0  48894c2408               mov qword ptr [rsp + 8], rcx
0013e5f5  57                       push rdi
0013e5f6  4883ec30                 sub rsp, 0x30
0013e5fa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e603  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e608  8bda                     mov ebx, edx
0013e60a  488bf9                   mov rdi, rcx
0013e60d  488d05cca81000           lea rax, [rip + 0x10a8cc]
0013e614  488901                   mov qword ptr [rcx], rax
0013e617  e844290300               call 0x170f60
0013e61c  83e305                   and ebx, 5
0013e61f  80fb05                   cmp bl, 5
0013e622  750d                     jne 0x13e631
0013e624  ba28050000               mov edx, 0x528
0013e629  488bcf                   mov rcx, rdi
0013e62c  e8df29ecff               call 0x1010
0013e631  488bc7                   mov rax, rdi
0013e634  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e639  4883c430                 add rsp, 0x30
0013e63d  5f                       pop rdi
0013e63e  c3                       ret
