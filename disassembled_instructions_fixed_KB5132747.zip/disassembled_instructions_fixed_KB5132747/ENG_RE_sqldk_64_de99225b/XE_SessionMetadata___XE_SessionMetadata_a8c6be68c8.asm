; XE_SessionMetadata::~XE_SessionMetadata
; sqldk.dll, primary RVA 0x470d0, 54 bytes in 1 chunk(s)

; chunk at RVA 0x470d0 (54 bytes)
000470d0  48894c2408               mov qword ptr [rsp + 8], rcx
000470d5  4883ec38                 sub rsp, 0x38
000470d9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000470e2  4883c108                 add rcx, 8
000470e6  48894c2448               mov qword ptr [rsp + 0x48], rcx
000470eb  4c8d0dfe090000           lea r9, [rip + 0x9fe]
000470f2  ba08000000               mov edx, 8
000470f7  41b800040000             mov r8d, 0x400
000470fd  4883c438                 add rsp, 0x38
00047101  e91ad7fdff               jmp 0x24820
