; `ISOSHostImpl::CreateRecursiveMutex'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22a23c, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22a23c (59 bytes)
0022a23c  4055                     push rbp
0022a23e  4883ec30                 sub rsp, 0x30
0022a242  488bea                   mov rbp, rdx
0022a245  c644242806               mov byte ptr [rsp + 0x28], 6
0022a24a  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0022a250  89442420                 mov dword ptr [rsp + 0x20], eax
0022a254  4c8d0d85f90600           lea r9, [rip + 0x6f985]
0022a25b  41b801000000             mov r8d, 1
0022a261  488b5570                 mov rdx, qword ptr [rbp + 0x70]
0022a265  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
0022a26c  e89fccddff               call 0x6f10
0022a271  4883c430                 add rsp, 0x30
0022a275  5d                       pop rbp
0022a276  c3                       ret
