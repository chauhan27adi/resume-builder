; `XE_MetadataTracker::XE_MetadataTracker'::`1'::dtor$6
; sqldk.dll, primary RVA 0x2165f6, 42 bytes in 1 chunk(s)

; chunk at RVA 0x2165f6 (42 bytes)
002165f6  4055                     push rbp
002165f8  4883ec20                 sub rsp, 0x20
002165fc  488bea                   mov rbp, rdx
002165ff  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00216603  4c8d0de614e3ff           lea r9, [rip - 0x1ceb1a]
0021660a  41b800040000             mov r8d, 0x400
00216610  ba08000000               mov edx, 8
00216615  e806e2e0ff               call 0x24820
0021661a  4883c420                 add rsp, 0x20
0021661e  5d                       pop rbp
0021661f  c3                       ret
