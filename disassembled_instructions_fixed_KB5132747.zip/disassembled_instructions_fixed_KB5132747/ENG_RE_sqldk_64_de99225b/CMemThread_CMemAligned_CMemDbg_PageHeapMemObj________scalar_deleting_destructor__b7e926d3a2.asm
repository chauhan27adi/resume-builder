; CMemThread<CMemAligned<CMemDbg<PageHeapMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13df40, 115 bytes in 1 chunk(s)

; chunk at RVA 0x13df40 (115 bytes)
0013df40  48894c2408               mov qword ptr [rsp + 8], rcx
0013df45  57                       push rdi
0013df46  4883ec30                 sub rsp, 0x30
0013df4a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013df53  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013df58  8bda                     mov ebx, edx
0013df5a  488bf9                   mov rdi, rcx
0013df5d  488d054cc21000           lea rax, [rip + 0x10c24c]
0013df64  488901                   mov qword ptr [rcx], rax
0013df67  488d8158040000           lea rax, [rcx + 0x458]
0013df6e  4889442450               mov qword ptr [rsp + 0x50], rax
0013df73  488d0dc6bb0f00           lea rcx, [rip + 0xfbbc6]
0013df7a  48894830                 mov qword ptr [rax + 0x30], rcx
0013df7e  488908                   mov qword ptr [rax], rcx
0013df81  488d0548d21000           lea rax, [rip + 0x10d248]
0013df88  488907                   mov qword ptr [rdi], rax
0013df8b  488bcf                   mov rcx, rdi
0013df8e  e86d440300               call 0x172400
0013df93  f6c301                   test bl, 1
0013df96  740d                     je 0x13dfa5
0013df98  ba30050000               mov edx, 0x530
0013df9d  488bcf                   mov rcx, rdi
0013dfa0  e88b8fecff               call 0x6f30
0013dfa5  488bc7                   mov rax, rdi
0013dfa8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013dfad  4883c430                 add rsp, 0x30
0013dfb1  5f                       pop rdi
0013dfb2  c3                       ret
