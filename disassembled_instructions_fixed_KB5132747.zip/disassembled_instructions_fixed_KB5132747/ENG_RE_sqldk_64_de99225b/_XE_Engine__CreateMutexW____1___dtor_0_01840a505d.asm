; `XE_Engine::CreateMutexW'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235550, 56 bytes in 1 chunk(s)

; chunk at RVA 0x235550 (56 bytes)
00235550  4055                     push rbp
00235552  4883ec30                 sub rsp, 0x30
00235556  488bea                   mov rbp, rdx
00235559  c644242806               mov byte ptr [rsp + 0x28], 6
0023555e  8b4550                   mov eax, dword ptr [rbp + 0x50]
00235561  89442420                 mov dword ptr [rsp + 0x20], eax
00235565  4c8d0d745c0400           lea r9, [rip + 0x45c74]
0023556c  41b801000000             mov r8d, 1
00235572  488b1547d11700           mov rdx, qword ptr [rip + 0x17d147]
00235579  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
0023557d  e86e49faff               call 0x1d9ef0
00235582  4883c430                 add rsp, 0x30
00235586  5d                       pop rbp
00235587  c3                       ret
