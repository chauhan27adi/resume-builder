; XE_Session::~XE_Session
; sqldk.dll, primary RVA 0x1eada0, 352 bytes in 1 chunk(s)

; chunk at RVA 0x1eada0 (352 bytes)
001eada0  48894c2408               mov qword ptr [rsp + 8], rcx
001eada5  53                       push rbx
001eada6  56                       push rsi
001eada7  57                       push rdi
001eada8  4883ec30                 sub rsp, 0x30
001eadac  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001eadb5  488bf9                   mov rdi, rcx
001eadb8  488d0571fe0800           lea rax, [rip + 0x8fe71]
001eadbf  488901                   mov qword ptr [rcx], rax
001eadc2  4881c140080000           add rcx, 0x840
001eadc9  e822910000               call 0x1f3ef0
001eadce  90                       nop
001eadcf  488d8798060000           lea rax, [rdi + 0x698]
001eadd6  4889442458               mov qword ptr [rsp + 0x58], rax
001eaddb  488d0d5eed0400           lea rcx, [rip + 0x4ed5e]
001eade2  488908                   mov qword ptr [rax], rcx
001eade5  488d8768050000           lea rax, [rdi + 0x568]
001eadec  4889442460               mov qword ptr [rsp + 0x60], rax
001eadf1  488908                   mov qword ptr [rax], rcx
001eadf4  488b9fd8040000           mov rbx, qword ptr [rdi + 0x4d8]
001eadfb  beffffffff               mov esi, 0xffffffff
001eae00  4885db                   test rbx, rbx
001eae03  742d                     je 0x1eae32
001eae05  8bc6                     mov eax, esi
001eae07  f00fc103                 lock xadd dword ptr [rbx], eax
001eae0b  83f801                   cmp eax, 1
001eae0e  7522                     jne 0x1eae32
001eae10  48895c2458               mov qword ptr [rsp + 0x58], rbx
001eae15  488bcb                   mov rcx, rbx
001eae18  e8a37e0000               call 0x1f2cc0
001eae1d  90                       nop
001eae1e  c703adde0080             mov dword ptr [rbx], 0x8000dead
001eae24  ba88000000               mov edx, 0x88
001eae29  488bcb                   mov rcx, rbx
001eae2c  e8ffc0e1ff               call 0x6f30
001eae31  90                       nop
001eae32  488b8fd0040000           mov rcx, qword ptr [rdi + 0x4d0]
001eae39  4885c9                   test rcx, rcx
001eae3c  741f                     je 0x1eae5d
001eae3e  8bc6                     mov eax, esi
001eae40  f00fc101                 lock xadd dword ptr [rcx], eax
001eae44  83f801                   cmp eax, 1
001eae47  7514                     jne 0x1eae5d
001eae49  48894c2458               mov qword ptr [rsp + 0x58], rcx
001eae4e  c701adde0080             mov dword ptr [rcx], 0x8000dead
001eae54  8d502f                   lea edx, [rax + 0x2f]
001eae57  e8d4c0e1ff               call 0x6f30
001eae5c  90                       nop
001eae5d  488b8fc8040000           mov rcx, qword ptr [rdi + 0x4c8]
001eae64  4885c9                   test rcx, rcx
001eae67  742c                     je 0x1eae95
001eae69  488d59f8                 lea rbx, [rcx - 8]
001eae6d  4c8d0d3c14ffff           lea r9, [rip - 0xebc4]
001eae74  4c8b03                   mov r8, qword ptr [rbx]
001eae77  ba08000000               mov edx, 8
001eae7c  e89f99e3ff               call 0x24820
001eae81  488b13                   mov rdx, qword ptr [rbx]
001eae84  488d14d508000000         lea rdx, [rdx*8 + 8]
001eae8c  488bcb                   mov rcx, rbx
001eae8f  e89cc0e1ff               call 0x6f30
001eae94  90                       nop
001eae95  488b8fc0040000           mov rcx, qword ptr [rdi + 0x4c0]
001eae9c  4885c9                   test rcx, rcx
001eae9f  741f                     je 0x1eaec0
001eaea1  8bc6                     mov eax, esi
001eaea3  f00fc101                 lock xadd dword ptr [rcx], eax
001eaea7  83f801                   cmp eax, 1
001eaeaa  7514                     jne 0x1eaec0
001eaeac  48894c2458               mov qword ptr [rsp + 0x58], rcx
001eaeb1  c701adde0080             mov dword ptr [rcx], 0x8000dead
001eaeb7  8d502f                   lea edx, [rax + 0x2f]
001eaeba  e871c0e1ff               call 0x6f30
001eaebf  90                       nop
001eaec0  488b8fb8040000           mov rcx, qword ptr [rdi + 0x4b8]
001eaec7  4885c9                   test rcx, rcx
001eaeca  741d                     je 0x1eaee9
001eaecc  f00fc131                 lock xadd dword ptr [rcx], esi
001eaed0  83fe01                   cmp esi, 1
001eaed3  7514                     jne 0x1eaee9
001eaed5  48894c2458               mov qword ptr [rsp + 0x58], rcx
001eaeda  c701adde0080             mov dword ptr [rcx], 0x8000dead
001eaee0  8d562f                   lea edx, [rsi + 0x2f]
001eaee3  e848c0e1ff               call 0x6f30
001eaee8  90                       nop
001eaee9  488b4f28                 mov rcx, qword ptr [rdi + 0x28]
001eaeed  4885c9                   test rcx, rcx
001eaef0  7406                     je 0x1eaef8
001eaef2  488b01                   mov rax, qword ptr [rcx]
001eaef5  ff5028                   call qword ptr [rax + 0x28]
001eaef8  4883c430                 add rsp, 0x30
001eaefc  5f                       pop rdi
001eaefd  5e                       pop rsi
001eaefe  5b                       pop rbx
001eaeff  c3                       ret
