; `CXFixedTable::InitFixedTable'::`1'::dtor$5
; sqldk.dll, primary RVA 0x216d54, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216d54 (31 bytes)
00216d54  4055                     push rbp
00216d56  4883ec20                 sub rsp, 0x20
00216d5a  488bea                   mov rbp, rdx
00216d5d  4533c0                   xor r8d, r8d
00216d60  488b5538                 mov rdx, qword ptr [rbp + 0x38]
00216d64  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00216d68  e8a3a2deff               call 0x1010
00216d6d  4883c420                 add rsp, 0x20
00216d71  5d                       pop rbp
00216d72  c3                       ret
