; MemoryNode::ShrinkUsingExternalCaches
; sqldk.dll, primary RVA 0xa2540, 1099 bytes in 3 chunk(s)

; chunk at RVA 0xa2540 (17 bytes)
000a2540  488bc4                   mov rax, rsp
000a2543  48895010                 mov qword ptr [rax + 0x10], rdx
000a2547  53                       push rbx
000a2548  55                       push rbp
000a2549  57                       push rdi
000a254a  4881ec90000000           sub rsp, 0x90

; chunk at RVA 0xa2551 (1007 bytes)
000a2551  488970e0                 mov qword ptr [rax - 0x20], rsi
000a2555  488bf9                   mov rdi, rcx
000a2558  4c8970c8                 mov qword ptr [rax - 0x38], r14
000a255c  4533f6                   xor r14d, r14d
000a255f  4c8978c0                 mov qword ptr [rax - 0x40], r15
000a2563  b802000000               mov eax, 2
000a2568  8be8                     mov ebp, eax
000a256a  898424b0000000           mov dword ptr [rsp + 0xb0], eax
000a2571  488b05201d2700           mov rax, qword ptr [rip + 0x271d20]
000a2578  4885c0                   test rax, rax
000a257b  740b                     je 0xa2588
000a257d  f6802006000010           test byte ptr [rax + 0x620], 0x10
000a2584  490f45c6                 cmovne rax, r14
000a2588  4885c0                   test rax, rax
000a258b  4c896c2478               mov qword ptr [rsp + 0x78], r13
000a2590  4c8db888050000           lea r15, [rax + 0x588]
000a2597  4d0f44fe                 cmove r15, r14
000a259b  e800ffffff               call 0xa24a0
000a25a0  4c89b424c0000000         mov qword ptr [rsp + 0xc0], r14
000a25a8  8bf0                     mov esi, eax
000a25aa  85c0                     test eax, eax
000a25ac  7447                     je 0xa25f5
000a25ae  488b4f50                 mov rcx, qword ptr [rdi + 0x50]
000a25b2  48034f48                 add rcx, qword ptr [rdi + 0x48]
000a25b6  48034f40                 add rcx, qword ptr [rdi + 0x40]
000a25ba  833d57cd280001           cmp dword ptr [rip + 0x28cd57], 1
000a25c1  750b                     jne 0xa25ce
000a25c3  488b4768                 mov rax, qword ptr [rdi + 0x68]
000a25c7  482b4760                 sub rax, qword ptr [rdi + 0x60]
000a25cb  4803c8                   add rcx, rax
000a25ce  4c8b87a8000000           mov r8, qword ptr [rdi + 0xa8]
000a25d5  488d4101                 lea rax, [rcx + 1]
000a25d9  4899                     cqo
000a25db  482bc2                   sub rax, rdx
000a25de  48d1f8                   sar rax, 1
000a25e1  4c3bc0                   cmp r8, rax
000a25e4  7e0f                     jle 0xa25f5
000a25e6  41bd01000000             mov r13d, 1
000a25ec  4c3b8790000000           cmp r8, qword ptr [rdi + 0x90]
000a25f3  7f03                     jg 0xa25f8
000a25f5  4d8bee                   mov r13, r14
000a25f8  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000a2601  8b05c9292700             mov eax, dword ptr [rip + 0x2729c9]
000a2607  8b1dabf2f5ff             mov ebx, dword ptr [rip - 0xa0d55]
000a260d  48031cc1                 add rbx, qword ptr [rcx + rax*8]
000a2611  488b8300010000           mov rax, qword ptr [rbx + 0x100]
000a2618  4885c0                   test rax, rax
000a261b  750e                     jne 0xa262b
000a261d  33c9                     xor ecx, ecx
000a261f  e83c36f8ff               call 0x25c60
000a2624  488b8300010000           mov rax, qword ptr [rbx + 0x100]
000a262b  488b80e0030000           mov rax, qword ptr [rax + 0x3e0]
000a2632  4c89a42480000000         mov qword ptr [rsp + 0x80], r12
000a263a  4885c0                   test rax, rax
000a263d  7410                     je 0xa264f
000a263f  f6802006000004           test byte ptr [rax + 0x620], 4
000a2646  4c8da0b0030000           lea r12, [rax + 0x3b0]
000a264d  7403                     je 0xa2652
000a264f  4d8be6                   mov r12, r14
000a2652  4c89a424c8000000         mov qword ptr [rsp + 0xc8], r12
000a265a  85f6                     test esi, esi
000a265c  0f84a8020000             je 0xa290a
000a2662  48837f7000               cmp qword ptr [rdi + 0x70], 0
000a2667  7e6c                     jle 0xa26d5
000a2669  8b35e12e2700             mov esi, dword ptr [rip + 0x272ee1]
000a266f  410fb7ee                 movzx ebp, r14w
000a2673  0fb79f80000000           movzx ebx, word ptr [rdi + 0x80]
000a267a  85f6                     test esi, esi
000a267c  7457                     je 0xa26d5
000a267e  440fb7f6                 movzx r14d, si
000a2682  0f1f4000                 nop dword ptr [rax]
000a2686  66660f1f840000000000     nop word ptr [rax + rax]
000a2690  0fb7d3                   movzx edx, bx
000a2693  488d0df61e2700           lea rcx, [rip + 0x271ef6]
000a269a  e8513df6ff               call 0x63f0
000a269f  4533c9                   xor r9d, r9d
000a26a2  48c744242000000000       mov qword ptr [rsp + 0x20], 0
000a26ab  4533c0                   xor r8d, r8d
000a26ae  488bc8                   mov rcx, rax
000a26b1  418d5101                 lea edx, [r9 + 1]
000a26b5  e84604f7ff               call 0x12b00
000a26ba  0fb7cb                   movzx ecx, bx
000a26bd  8d4301                   lea eax, [rbx + 1]
000a26c0  66ffc5                   inc bp
000a26c3  33db                     xor ebx, ebx
000a26c5  ffc1                     inc ecx
000a26c7  413bce                   cmp ecx, r14d
000a26ca  660f42d8                 cmovb bx, ax
000a26ce  0fb7c5                   movzx eax, bp
000a26d1  3bc6                     cmp eax, esi
000a26d3  72bb                     jb 0xa2690
000a26d5  4d85e4                   test r12, r12
000a26d8  740d                     je 0xa26e7
000a26da  ba02000000               mov edx, 2
000a26df  498bcc                   mov rcx, r12
000a26e2  e8f9d40a00               call 0x14fbe0
000a26e7  488b7770                 mov rsi, qword ptr [rdi + 0x70]
000a26eb  488bcf                   mov rcx, rdi
000a26ee  e8ad8ef6ff               call 0xb5a0
000a26f3  4c8bf0                   mov r14, rax
000a26f6  488bcf                   mov rcx, rdi
000a26f9  488d4601                 lea rax, [rsi + 1]
000a26fd  4899                     cqo
000a26ff  482bc2                   sub rax, rdx
000a2702  48d1f8                   sar rax, 1
000a2705  4c2bf0                   sub r14, rax
000a2708  e8138ef6ff               call 0xb520
000a270d  4c8be0                   mov r12, rax
000a2710  4d85ff                   test r15, r15
000a2713  747f                     je 0xa2794
000a2715  418b4f48                 mov ecx, dword ptr [r15 + 0x48]
000a2719  33db                     xor ebx, ebx
000a271b  85c9                     test ecx, ecx
000a271d  7403                     je 0xa2722
000a271f  498b1f                   mov rbx, qword ptr [r15]
000a2722  4885db                   test rbx, rbx
000a2725  746d                     je 0xa2794
000a2727  33ed                     xor ebp, ebp
000a2729  85c9                     test ecx, ecx
000a272b  400f95c5                 setne bpl
000a272f  90                       nop
000a2730  4d85ed                   test r13, r13
000a2733  7406                     je 0xa273b
000a2735  807b1000                 cmp byte ptr [rbx + 0x10], 0
000a2739  743f                     je 0xa277a
000a273b  488b03                   mov rax, qword ptr [rbx]
000a273e  41b001                   mov r8b, 1
000a2741  33d2                     xor edx, edx
000a2743  488bcb                   mov rcx, rbx
000a2746  ff5018                   call qword ptr [rax + 0x18]
000a2749  488b13                   mov rdx, qword ptr [rbx]
000a274c  488bcb                   mov rcx, rbx
000a274f  488bf0                   mov rsi, rax
000a2752  ff5220                   call qword ptr [rdx + 0x20]
000a2755  84c0                     test al, al
000a2757  7421                     je 0xa277a
000a2759  488bce                   mov rcx, rsi
000a275c  f0480fc18f00010000       lock xadd qword ptr [rdi + 0x100], rcx
000a2765  4885c9                   test rcx, rcx
000a2768  7809                     js 0xa2773
000a276a  488d0431                 lea rax, [rcx + rsi]
000a276e  4885c0                   test rax, rax
000a2771  7907                     jns 0xa277a
000a2773  4889b700010000           mov qword ptr [rdi + 0x100], rsi
000a277a  33db                     xor ebx, ebx
000a277c  413b6f48                 cmp ebp, dword ptr [r15 + 0x48]
000a2780  7309                     jae 0xa278b
000a2782  4863dd                   movsxd rbx, ebp
000a2785  ffc5                     inc ebp
000a2787  498b1cdf                 mov rbx, qword ptr [r15 + rbx*8]
000a278b  4885db                   test rbx, rbx
000a278e  75a0                     jne 0xa2730
000a2790  488b7770                 mov rsi, qword ptr [rdi + 0x70]
000a2794  488bcf                   mov rcx, rdi
000a2797  e8048ef6ff               call 0xb5a0
000a279c  488bd8                   mov rbx, rax
000a279f  488bcf                   mov rcx, rdi
000a27a2  488d4601                 lea rax, [rsi + 1]
000a27a6  4899                     cqo
000a27a8  482bc2                   sub rax, rdx
000a27ab  48d1f8                   sar rax, 1
000a27ae  482bd8                   sub rbx, rax
000a27b1  e86a8df6ff               call 0xb520
000a27b6  488b8c24b8000000         mov rcx, qword ptr [rsp + 0xb8]
000a27be  483b19                   cmp rbx, qword ptr [rcx]
000a27c1  7e15                     jle 0xa27d8
000a27c3  83790800                 cmp dword ptr [rcx + 8], 0
000a27c7  7505                     jne 0xa27ce
000a27c9  493bde                   cmp rbx, r14
000a27cc  7e0f                     jle 0xa27dd
000a27ce  33ed                     xor ebp, ebp
000a27d0  8d5d02                   lea ebx, [rbp + 2]
000a27d3  e934010000               jmp 0xa290c
000a27d8  493bde                   cmp rbx, r14
000a27db  7f09                     jg 0xa27e6
000a27dd  493bc4                   cmp rax, r12
000a27e0  0f8d14010000             jge 0xa28fa
000a27e6  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000a27ef  8b05db272700             mov eax, dword ptr [rip + 0x2727db]
000a27f5  8b1dbdf0f5ff             mov ebx, dword ptr [rip - 0xa0f43]
000a27fb  48031cc1                 add rbx, qword ptr [rcx + rax*8]
000a27ff  488bb300010000           mov rsi, qword ptr [rbx + 0x100]
000a2806  4885f6                   test rsi, rsi
000a2809  750e                     jne 0xa2819
000a280b  33c9                     xor ecx, ecx
000a280d  e84e34f8ff               call 0x25c60
000a2812  488bb300010000           mov rsi, qword ptr [rbx + 0x100]
000a2819  0f31                     rdtsc
000a281b  48c1e220                 shl rdx, 0x20
000a281f  480bc2                   or rax, rdx
000a2822  488b9640030000           mov rdx, qword ptr [rsi + 0x340]
000a2829  483bc2                   cmp rax, rdx
000a282c  7722                     ja 0xa2850
000a282e  48b9ffffffffffffff7f     movabs rcx, 0x7fffffffffffffff
000a2838  483bd1                   cmp rdx, rcx
000a283b  743b                     je 0xa2878
000a283d  488b8e60020000           mov rcx, qword ptr [rsi + 0x260]
000a2844  482bd0                   sub rdx, rax
000a2847  483b91f00d0000           cmp rdx, qword ptr [rcx + 0xdf0]
000a284e  7628                     jbe 0xa2878
000a2850  8b9e68020000             mov ebx, dword ptr [rsi + 0x268]
000a2856  488d15c3f72800           lea rdx, [rip + 0x28f7c3]
000a285d  8bc3                     mov eax, ebx
000a285f  33c9                     xor ecx, ecx
000a2861  83c801                   or eax, 1
000a2864  898668020000             mov dword ptr [rsi + 0x268], eax
000a286a  e8510df7ff               call 0x135c0
000a286f  83cbfe                   or ebx, 0xfffffffe
000a2872  219e68020000             and dword ptr [rsi + 0x268], ebx
000a2878  488bac24c0000000         mov rbp, qword ptr [rsp + 0xc0]
000a2880  48b877be9f1a2fdd2406     movabs rax, 0x624dd2f1a9fbe77
000a288a  48ffc5                   inc rbp
000a288d  4533f6                   xor r14d, r14d
000a2890  48f7e5                   mul rbp
000a2893  488bc5                   mov rax, rbp
000a2896  4889ac24c0000000         mov qword ptr [rsp + 0xc0], rbp
000a289e  482bc2                   sub rax, rdx
000a28a1  48d1e8                   shr rax, 1
000a28a4  4803c2                   add rax, rdx
000a28a7  48c1e809                 shr rax, 9
000a28ab  4869c8e8030000           imul rcx, rax, 0x3e8
000a28b2  483be9                   cmp rbp, rcx
000a28b5  752a                     jne 0xa28e1
000a28b7  488d542430               lea rdx, [rsp + 0x30]
000a28bc  c744243060004000         mov dword ptr [rsp + 0x30], 0x400060
000a28c4  418d4e01                 lea ecx, [r14 + 1]
000a28c8  4c89742438               mov qword ptr [rsp + 0x38], r14
000a28cd  4c89742448               mov qword ptr [rsp + 0x48], r14
000a28d2  4c89742440               mov qword ptr [rsp + 0x40], r14
000a28d7  4c89742450               mov qword ptr [rsp + 0x50], r14
000a28dc  e8df0cf7ff               call 0x135c0
000a28e1  488bcf                   mov rcx, rdi
000a28e4  e8b7fbffff               call 0xa24a0
000a28e9  85c0                     test eax, eax
000a28eb  7416                     je 0xa2903
000a28ed  4c8ba424c8000000         mov r12, qword ptr [rsp + 0xc8]
000a28f5  e968fdffff               jmp 0xa2662
000a28fa  bb02000000               mov ebx, 2
000a28ff  8beb                     mov ebp, ebx
000a2901  eb09                     jmp 0xa290c
000a2903  8bac24b0000000           mov ebp, dword ptr [rsp + 0xb0]
000a290a  8bdd                     mov ebx, ebp
000a290c  488b5750                 mov rdx, qword ptr [rdi + 0x50]
000a2910  48035748                 add rdx, qword ptr [rdi + 0x48]
000a2914  48035740                 add rdx, qword ptr [rdi + 0x40]
000a2918  833df9c9280001           cmp dword ptr [rip + 0x28c9f9], 1
000a291f  4c8b7c2468               mov r15, qword ptr [rsp + 0x68]
000a2924  4c8b742470               mov r14, qword ptr [rsp + 0x70]
000a2929  4c8b6c2478               mov r13, qword ptr [rsp + 0x78]
000a292e  4c8ba42480000000         mov r12, qword ptr [rsp + 0x80]
000a2936  488bb42488000000         mov rsi, qword ptr [rsp + 0x88]
000a293e  750b                     jne 0xa294b

; chunk at RVA 0xa2940 (75 bytes)
000a2940  488b4768                 mov rax, qword ptr [rdi + 0x68]
000a2944  482b4760                 sub rax, qword ptr [rdi + 0x60]
000a2948  4803d0                   add rdx, rax
000a294b  488b8790000000           mov rax, qword ptr [rdi + 0x90]
000a2952  488b8fa8000000           mov rcx, qword ptr [rdi + 0xa8]
000a2959  483bc8                   cmp rcx, rax
000a295c  480f4dc8                 cmovge rcx, rax
000a2960  488d4201                 lea rax, [rdx + 1]
000a2964  4899                     cqo
000a2966  482bc2                   sub rax, rdx
000a2969  48d1f8                   sar rax, 1
000a296c  483bc8                   cmp rcx, rax
000a296f  7c0d                     jl 0xa297e
000a2971  488bcf                   mov rcx, rdi
000a2974  e8073ef7ff               call 0x16780
000a2979  85c0                     test eax, eax
000a297b  0f44eb                   cmove ebp, ebx
000a297e  8bc5                     mov eax, ebp
000a2980  4881c490000000           add rsp, 0x90
000a2987  5f                       pop rdi
000a2988  5d                       pop rbp
000a2989  5b                       pop rbx
000a298a  c3                       ret
