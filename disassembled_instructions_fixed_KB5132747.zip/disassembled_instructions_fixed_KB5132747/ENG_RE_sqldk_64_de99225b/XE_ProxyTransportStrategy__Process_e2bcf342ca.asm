; XE_ProxyTransportStrategy::Process
; sqldk.dll, primary RVA 0x1fedb0, 1284 bytes in 1 chunk(s)

; chunk at RVA 0x1fedb0 (1284 bytes)
001fedb0  4055                     push rbp
001fedb2  56                       push rsi
001fedb3  57                       push rdi
001fedb4  4154                     push r12
001fedb6  4155                     push r13
001fedb8  4156                     push r14
001fedba  4157                     push r15
001fedbc  488dac2450c0ffff         lea rbp, [rsp - 0x3fb0]
001fedc4  b8b0400000               mov eax, 0x40b0
001fedc9  e8221fe1ff               call 0x10cf0
001fedce  482be0                   sub rsp, rax
001fedd1  48c7442440feffffff       mov qword ptr [rsp + 0x40], 0xfffffffffffffffe
001fedda  48899c2400410000         mov qword ptr [rsp + 0x4100], rbx
001fede2  488b059f221100           mov rax, qword ptr [rip + 0x11229f]
001fede9  4833c4                   xor rax, rsp
001fedec  488985a03f0000           mov qword ptr [rbp + 0x3fa0], rax
001fedf3  488bfa                   mov rdi, rdx
001fedf6  488bf1                   mov rsi, rcx
001fedf9  4533ed                   xor r13d, r13d
001fedfc  4c896c2438               mov qword ptr [rsp + 0x38], r13
001fee01  44896c2434               mov dword ptr [rsp + 0x34], r13d
001fee06  44896c2430               mov dword ptr [rsp + 0x30], r13d
001fee0b  0f57c0                   xorps xmm0, xmm0
001fee0e  33c0                     xor eax, eax
001fee10  0f11442470               movups xmmword ptr [rsp + 0x70], xmm0
001fee15  48894580                 mov qword ptr [rbp - 0x80], rax
001fee19  488b02                   mov rax, qword ptr [rdx]
001fee1c  488d4c2430               lea rcx, [rsp + 0x30]
001fee21  48894c2420               mov qword ptr [rsp + 0x20], rcx
001fee26  4c8d4c2434               lea r9, [rsp + 0x34]
001fee2b  458d4508                 lea r8d, [r13 + 8]
001fee2f  488d542438               lea rdx, [rsp + 0x38]
001fee34  488bcf                   mov rcx, rdi
001fee37  ff5008                   call qword ptr [rax + 8]
001fee3a  84c0                     test al, al
001fee3c  0f8420040000             je 0x1ff262
001fee42  488b442438               mov rax, qword ptr [rsp + 0x38]
001fee47  89442470                 mov dword ptr [rsp + 0x70], eax
001fee4b  c744247418000000         mov dword ptr [rsp + 0x74], 0x18
001fee53  83f805                   cmp eax, 5
001fee56  0f87e7030000             ja 0x1ff243
001fee5c  4863c8                   movsxd rcx, eax
001fee5f  4c8d059a11e0ff           lea r8, [rip - 0x1fee66]
001fee66  418b94889cf21f00         mov edx, dword ptr [r8 + rcx*4 + 0x1ff29c]
001fee6e  4903d0                   add rdx, r8
001fee71  ffe2                     jmp rdx
001fee73  c78520040000ffffffff     mov dword ptr [rbp + 0x420], 0xffffffff
001fee7d  48894590                 mov qword ptr [rbp - 0x70], rax
001fee81  448b44243c               mov r8d, dword ptr [rsp + 0x3c]
001fee86  4183c0f8                 add r8d, -8
001fee8a  488b07                   mov rax, qword ptr [rdi]
001fee8d  488d4c2430               lea rcx, [rsp + 0x30]
001fee92  48894c2420               mov qword ptr [rsp + 0x20], rcx
001fee97  4c8d4c2434               lea r9, [rsp + 0x34]
001fee9c  488d5598                 lea rdx, [rbp - 0x68]
001feea0  488bcf                   mov rcx, rdi
001feea3  ff5008                   call qword ptr [rax + 8]
001feea6  84c0                     test al, al
001feea8  0f8495030000             je 0x1ff243
001feeae  4c8b4598                 mov r8, qword ptr [rbp - 0x68]
001feeb2  4c89442478               mov qword ptr [rsp + 0x78], r8
001feeb7  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001feebb  0f2845a0                 movaps xmm0, xmmword ptr [rbp - 0x60]
001feebf  0f29442450               movaps xmmword ptr [rsp + 0x50], xmm0
001feec4  f20f104db0               movsd xmm1, qword ptr [rbp - 0x50]
001feec9  f20f114c2460             movsd qword ptr [rsp + 0x60], xmm1
001feecf  488b01                   mov rax, qword ptr [rcx]
001feed2  488d5580                 lea rdx, [rbp - 0x80]
001feed6  4889542420               mov qword ptr [rsp + 0x20], rdx
001feedb  4c8d4c2450               lea r9, [rsp + 0x50]
001feee0  488d55b8                 lea rdx, [rbp - 0x48]
001feee4  ff10                     call qword ptr [rax]
001feee6  e95f030000               jmp 0x1ff24a
001feeeb  488b07                   mov rax, qword ptr [rdi]
001feeee  488d4c2430               lea rcx, [rsp + 0x30]
001feef3  48894c2420               mov qword ptr [rsp + 0x20], rcx
001feef8  4c8d4c2434               lea r9, [rsp + 0x34]
001feefd  41b808000000             mov r8d, 8
001fef03  488d542458               lea rdx, [rsp + 0x58]
001fef08  488bcf                   mov rcx, rdi
001fef0b  ff5008                   call qword ptr [rax + 8]
001fef0e  84c0                     test al, al
001fef10  0f842d030000             je 0x1ff243
001fef16  488b542458               mov rdx, qword ptr [rsp + 0x58]
001fef1b  4889542478               mov qword ptr [rsp + 0x78], rdx
001fef20  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001fef24  488b01                   mov rax, qword ptr [rcx]
001fef27  4c8d4580                 lea r8, [rbp - 0x80]
001fef2b  ff5008                   call qword ptr [rax + 8]
001fef2e  e917030000               jmp 0x1ff24a
001fef33  4c8b6618                 mov r12, qword ptr [rsi + 0x18]
001fef37  4c89642450               mov qword ptr [rsp + 0x50], r12
001fef3c  4c896c2458               mov qword ptr [rsp + 0x58], r13
001fef41  4533c0                   xor r8d, r8d
001fef44  baffffffff               mov edx, 0xffffffff
001fef49  498bcc                   mov rcx, r12
001fef4c  ff153e611100             call qword ptr [rip + 0x11613e]
001fef52  458bfd                   mov r15d, r13d
001fef55  85c0                     test eax, eax
001fef57  410f94c7                 sete r15b
001fef5b  44897c2458               mov dword ptr [rsp + 0x58], r15d
001fef60  448b44243c               mov r8d, dword ptr [rsp + 0x3c]
001fef65  4183c0f8                 add r8d, -8
001fef69  488b07                   mov rax, qword ptr [rdi]
001fef6c  488b5610                 mov rdx, qword ptr [rsi + 0x10]
001fef70  4883c208                 add rdx, 8
001fef74  488d4c2430               lea rcx, [rsp + 0x30]
001fef79  48894c2420               mov qword ptr [rsp + 0x20], rcx
001fef7e  4c8d4c2434               lea r9, [rsp + 0x34]
001fef83  488bcf                   mov rcx, rdi
001fef86  ff5008                   call qword ptr [rax + 8]
001fef89  84c0                     test al, al
001fef8b  0f844e010000             je 0x1ff0df
001fef91  488b5e10                 mov rbx, qword ptr [rsi + 0x10]
001fef95  4c8d9b18020000           lea r11, [rbx + 0x218]
001fef9c  0fb78310020000           movzx eax, word ptr [rbx + 0x210]
001fefa3  4c6bf038                 imul r14, rax, 0x38
001fefa7  4d03f3                   add r14, r11
001fefaa  4d3bde                   cmp r11, r14
001fefad  0f83f9000000             jae 0x1ff0ac
001fefb3  498d5310                 lea rdx, [r11 + 0x10]
001fefb7  488b42f8                 mov rax, qword ptr [rdx - 8]
001fefbb  4885c0                   test rax, rax
001fefbe  7407                     je 0x1fefc7
001fefc0  4903c3                   add rax, r11
001fefc3  488942f8                 mov qword ptr [rdx - 8], rax
001fefc7  8b42f0                   mov eax, dword ptr [rdx - 0x10]
001fefca  448bd0                   mov r10d, eax
001fefcd  4181e200fcff0f           and r10d, 0xffffc00
001fefd4  4181fa003c0000           cmp r10d, 0x3c00
001fefdb  7522                     jne 0x1fefff
001fefdd  a9ff030000               test eax, 0x3ff
001fefe2  751b                     jne 0x1fefff
001fefe4  8bc8                     mov ecx, eax
001fefe6  81e1000000f0             and ecx, 0xf0000000
001fefec  81f900000060             cmp ecx, 0x60000000
001feff2  750b                     jne 0x1fefff
001feff4  458bc5                   mov r8d, r13d
001feff7  41b906000000             mov r9d, 6
001feffd  eb2e                     jmp 0x1ff02d
001fefff  448bc0                   mov r8d, eax
001ff002  4181e0ff030000           and r8d, 0x3ff
001ff009  448bc8                   mov r9d, eax
001ff00c  41c1e91c                 shr r9d, 0x1c
001ff010  4181fa00380000           cmp r10d, 0x3800
001ff017  7409                     je 0x1ff022
001ff019  4181fa00400000           cmp r10d, 0x4000
001ff020  7519                     jne 0x1ff03b
001ff022  4585c0                   test r8d, r8d
001ff025  7514                     jne 0x1ff03b
001ff027  4183f906                 cmp r9d, 6
001ff02b  750e                     jne 0x1ff03b
001ff02d  488b0a                   mov rcx, qword ptr [rdx]
001ff030  4885c9                   test rcx, rcx
001ff033  7406                     je 0x1ff03b
001ff035  4903cb                   add rcx, r11
001ff038  48890a                   mov qword ptr [rdx], rcx
001ff03b  4181fa003c0000           cmp r10d, 0x3c00
001ff042  750d                     jne 0x1ff051
001ff044  4585c0                   test r8d, r8d
001ff047  751c                     jne 0x1ff065
001ff049  4183f906                 cmp r9d, 6
001ff04d  7516                     jne 0x1ff065
001ff04f  eb2a                     jmp 0x1ff07b
001ff051  4181fa00380000           cmp r10d, 0x3800
001ff058  750b                     jne 0x1ff065
001ff05a  4585c0                   test r8d, r8d
001ff05d  7506                     jne 0x1ff065
001ff05f  4183f906                 cmp r9d, 6
001ff063  7416                     je 0x1ff07b
001ff065  c1e81c                   shr eax, 0x1c
001ff068  4181fa00400000           cmp r10d, 0x4000
001ff06f  751a                     jne 0x1ff08b
001ff071  4585c0                   test r8d, r8d
001ff074  7515                     jne 0x1ff08b
001ff076  83f806                   cmp eax, 6
001ff079  7510                     jne 0x1ff08b
001ff07b  488b4208                 mov rax, qword ptr [rdx + 8]
001ff07f  4885c0                   test rax, rax
001ff082  7407                     je 0x1ff08b
001ff084  4903c3                   add rax, r11
001ff087  48894208                 mov qword ptr [rdx + 8], rax
001ff08b  488b4218                 mov rax, qword ptr [rdx + 0x18]
001ff08f  4885c0                   test rax, rax
001ff092  7407                     je 0x1ff09b
001ff094  4903c3                   add rax, r11
001ff097  48894218                 mov qword ptr [rdx + 0x18], rax
001ff09b  4883c238                 add rdx, 0x38
001ff09f  488d42f0                 lea rax, [rdx - 0x10]
001ff0a3  493bc6                   cmp rax, r14
001ff0a6  0f820bffffff             jb 0x1fefb7
001ff0ac  488b4308                 mov rax, qword ptr [rbx + 8]
001ff0b0  4889442478               mov qword ptr [rsp + 0x78], rax
001ff0b5  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff0b9  488b01                   mov rax, qword ptr [rcx]
001ff0bc  4c8d4310                 lea r8, [rbx + 0x10]
001ff0c0  488d5580                 lea rdx, [rbp - 0x80]
001ff0c4  4889542428               mov qword ptr [rsp + 0x28], rdx
001ff0c9  4c895c2420               mov qword ptr [rsp + 0x20], r11
001ff0ce  440fb78b10020000         movzx r9d, word ptr [rbx + 0x210]
001ff0d6  488b5308                 mov rdx, qword ptr [rbx + 8]
001ff0da  ff5010                   call qword ptr [rax + 0x10]
001ff0dd  eb07                     jmp 0x1ff0e6
001ff0df  c7458053000000           mov dword ptr [rbp - 0x80], 0x53
001ff0e6  4585ff                   test r15d, r15d
001ff0e9  0f845b010000             je 0x1ff24a
001ff0ef  498bcc                   mov rcx, r12
001ff0f2  ff15a05f1100             call qword ptr [rip + 0x115fa0]
001ff0f8  e94d010000               jmp 0x1ff24a
001ff0fd  488b07                   mov rax, qword ptr [rdi]
001ff100  488d4c2430               lea rcx, [rsp + 0x30]
001ff105  48894c2420               mov qword ptr [rsp + 0x20], rcx
001ff10a  4c8d4c2434               lea r9, [rsp + 0x34]
001ff10f  41b808020000             mov r8d, 0x208
001ff115  488d5598                 lea rdx, [rbp - 0x68]
001ff119  488bcf                   mov rcx, rdi
001ff11c  ff5008                   call qword ptr [rax + 8]
001ff11f  84c0                     test al, al
001ff121  0f841c010000             je 0x1ff243
001ff127  488b5598                 mov rdx, qword ptr [rbp - 0x68]
001ff12b  4889542478               mov qword ptr [rsp + 0x78], rdx
001ff130  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff134  488b01                   mov rax, qword ptr [rcx]
001ff137  4c8d4d80                 lea r9, [rbp - 0x80]
001ff13b  4c8d45a0                 lea r8, [rbp - 0x60]
001ff13f  ff5018                   call qword ptr [rax + 0x18]
001ff142  e903010000               jmp 0x1ff24a
001ff147  488b07                   mov rax, qword ptr [rdi]
001ff14a  488d4c2430               lea rcx, [rsp + 0x30]
001ff14f  48894c2420               mov qword ptr [rsp + 0x20], rcx
001ff154  4c8d4c2434               lea r9, [rsp + 0x34]
001ff159  41b810000000             mov r8d, 0x10
001ff15f  488d542458               lea rdx, [rsp + 0x58]
001ff164  488bcf                   mov rcx, rdi
001ff167  ff5008                   call qword ptr [rax + 8]
001ff16a  84c0                     test al, al
001ff16c  0f84d1000000             je 0x1ff243
001ff172  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff176  488b01                   mov rax, qword ptr [rcx]
001ff179  488b542458               mov rdx, qword ptr [rsp + 0x58]
001ff17e  ff5038                   call qword ptr [rax + 0x38]
001ff181  8b4c2460                 mov ecx, dword ptr [rsp + 0x60]
001ff185  483bc1                   cmp rax, rcx
001ff188  7251                     jb 0x1ff1db
001ff18a  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff18e  488b1f                   mov rbx, qword ptr [rdi]
001ff191  488b01                   mov rax, qword ptr [rcx]
001ff194  488b542458               mov rdx, qword ptr [rsp + 0x58]
001ff199  ff5040                   call qword ptr [rax + 0x40]
001ff19c  488bd0                   mov rdx, rax
001ff19f  488d442430               lea rax, [rsp + 0x30]
001ff1a4  4889442420               mov qword ptr [rsp + 0x20], rax
001ff1a9  4c8d4c2434               lea r9, [rsp + 0x34]
001ff1ae  448b442460               mov r8d, dword ptr [rsp + 0x60]
001ff1b3  488bcf                   mov rcx, rdi
001ff1b6  ff5308                   call qword ptr [rbx + 8]
001ff1b9  84c0                     test al, al
001ff1bb  0f8482000000             je 0x1ff243
001ff1c1  488b542458               mov rdx, qword ptr [rsp + 0x58]
001ff1c6  4889542478               mov qword ptr [rsp + 0x78], rdx
001ff1cb  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff1cf  488b01                   mov rax, qword ptr [rcx]
001ff1d2  4c8d4580                 lea r8, [rbp - 0x80]
001ff1d6  ff5020                   call qword ptr [rax + 0x20]
001ff1d9  eb6f                     jmp 0x1ff24a
001ff1db  c7458036000000           mov dword ptr [rbp - 0x80], 0x36
001ff1e2  eb66                     jmp 0x1ff24a
001ff1e4  33d2                     xor edx, edx
001ff1e6  41b810400000             mov r8d, 0x4010
001ff1ec  488d4d90                 lea rcx, [rbp - 0x70]
001ff1f0  e83f56e0ff               call 0x4834
001ff1f5  488b07                   mov rax, qword ptr [rdi]
001ff1f8  488d4c2430               lea rcx, [rsp + 0x30]
001ff1fd  48894c2420               mov qword ptr [rsp + 0x20], rcx
001ff202  4c8d4c2434               lea r9, [rsp + 0x34]
001ff207  41b808400000             mov r8d, 0x4008
001ff20d  488d5598                 lea rdx, [rbp - 0x68]
001ff211  488bcf                   mov rcx, rdi
001ff214  ff5008                   call qword ptr [rax + 8]
001ff217  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff21b  488b01                   mov rax, qword ptr [rcx]
001ff21e  41b800040000             mov r8d, 0x400
001ff224  488d5580                 lea rdx, [rbp - 0x80]
001ff228  4889542420               mov qword ptr [rsp + 0x20], rdx
001ff22d  4c8d4da0                 lea r9, [rbp - 0x60]
001ff231  488b5598                 mov rdx, qword ptr [rbp - 0x68]
001ff235  ff5028                   call qword ptr [rax + 0x28]
001ff238  488b4598                 mov rax, qword ptr [rbp - 0x68]
001ff23c  4889442478               mov qword ptr [rsp + 0x78], rax
001ff241  eb07                     jmp 0x1ff24a
001ff243  c7458053000000           mov dword ptr [rbp - 0x80], 0x53
001ff24a  488b07                   mov rax, qword ptr [rdi]
001ff24d  4c8d4c2430               lea r9, [rsp + 0x30]
001ff252  41b818000000             mov r8d, 0x18
001ff258  488d542470               lea rdx, [rsp + 0x70]
001ff25d  488bcf                   mov rcx, rdi
001ff260  ff10                     call qword ptr [rax]
001ff262  488b07                   mov rax, qword ptr [rdi]
001ff265  488bcf                   mov rcx, rdi
001ff268  ff5020                   call qword ptr [rax + 0x20]
001ff26b  84c0                     test al, al
001ff26d  0f94c0                   sete al
001ff270  488b8da03f0000           mov rcx, qword ptr [rbp + 0x3fa0]
001ff277  4833cc                   xor rcx, rsp
001ff27a  e86153e0ff               call 0x45e0
001ff27f  488b9c2400410000         mov rbx, qword ptr [rsp + 0x4100]
001ff287  4881c4b0400000           add rsp, 0x40b0
001ff28e  415f                     pop r15
001ff290  415e                     pop r14
001ff292  415d                     pop r13
001ff294  415c                     pop r12
001ff296  5f                       pop rdi
001ff297  5e                       pop rsi
001ff298  5d                       pop rbp
001ff299  c3                       ret
001ff29a  90                       nop
001ff29b  90                       nop
001ff29c  73ee                     jae 0x1ff28c
