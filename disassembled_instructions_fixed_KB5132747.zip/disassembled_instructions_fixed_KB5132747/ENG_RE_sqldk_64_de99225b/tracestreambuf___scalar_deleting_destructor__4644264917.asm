; tracestreambuf::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x1b6e70, 67 bytes in 1 chunk(s)

; chunk at RVA 0x1b6e70 (67 bytes)
001b6e70  48894c2408               mov qword ptr [rsp + 8], rcx
001b6e75  57                       push rdi
001b6e76  4883ec30                 sub rsp, 0x30
001b6e7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001b6e83  48895c2448               mov qword ptr [rsp + 0x48], rbx
001b6e88  8bda                     mov ebx, edx
001b6e8a  488bf9                   mov rdi, rcx
001b6e8d  ff1535290800             call qword ptr [rip + 0x82935]
001b6e93  f6c301                   test bl, 1
001b6e96  740d                     je 0x1b6ea5
001b6e98  ba28080000               mov edx, 0x828
001b6e9d  488bcf                   mov rcx, rdi
001b6ea0  e88b00e5ff               call 0x6f30
001b6ea5  488bc7                   mov rax, rdi
001b6ea8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001b6ead  4883c430                 add rsp, 0x30
001b6eb1  5f                       pop rdi
001b6eb2  c3                       ret
