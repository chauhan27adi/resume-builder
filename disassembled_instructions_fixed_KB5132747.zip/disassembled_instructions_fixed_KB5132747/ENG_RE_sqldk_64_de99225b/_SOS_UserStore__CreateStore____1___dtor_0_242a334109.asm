; `SOS_UserStore::CreateStore'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22cd70, 53 bytes in 1 chunk(s)

; chunk at RVA 0x22cd70 (53 bytes)
0022cd70  4055                     push rbp
0022cd72  4883ec30                 sub rsp, 0x30
0022cd76  488bea                   mov rbp, rdx
0022cd79  c644242806               mov byte ptr [rsp + 0x28], 6
0022cd7e  8b4530                   mov eax, dword ptr [rbp + 0x30]
0022cd81  89442420                 mov dword ptr [rsp + 0x20], eax
0022cd85  4c8d0d0cd60400           lea r9, [rip + 0x4d60c]
0022cd8c  41b801000000             mov r8d, 1
0022cd92  488b5540                 mov rdx, qword ptr [rbp + 0x40]
0022cd96  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0022cd9a  e871a1ddff               call 0x6f10
0022cd9f  4883c430                 add rsp, 0x30
0022cda3  5d                       pop rbp
0022cda4  c3                       ret
