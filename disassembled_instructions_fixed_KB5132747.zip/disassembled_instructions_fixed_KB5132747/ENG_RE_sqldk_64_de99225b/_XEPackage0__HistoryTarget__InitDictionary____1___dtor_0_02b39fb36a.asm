; `XEPackage0::HistoryTarget::InitDictionary'::`1'::dtor$0
; sqldk.dll, primary RVA 0x232910, 51 bytes in 1 chunk(s)

; chunk at RVA 0x232910 (51 bytes)
00232910  4055                     push rbp
00232912  4883ec20                 sub rsp, 0x20
00232916  488bea                   mov rbp, rdx
00232919  4c8b85f0000000           mov r8, qword ptr [rbp + 0xf0]
00232920  4981c030200000           add r8, 0x2030
00232927  4d8b00                   mov r8, qword ptr [r8]
0023292a  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
00232931  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
00232938  e8d3e6dcff               call 0x1010
0023293d  4883c420                 add rsp, 0x20
00232941  5d                       pop rbp
00232942  c3                       ret
