; CMemPartitioned<CMemDetour<CMemThread<CMemProc> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce010, 129 bytes in 1 chunk(s)

; chunk at RVA 0xce010 (129 bytes)
000ce010  48894c2408               mov qword ptr [rsp + 8], rcx
000ce015  57                       push rdi
000ce016  4883ec30                 sub rsp, 0x30
000ce01a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce023  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce028  8bda                     mov ebx, edx
000ce02a  488bf9                   mov rdi, rcx
000ce02d  488d0594041800           lea rax, [rip + 0x180494]
000ce034  488901                   mov qword ptr [rcx], rax
000ce037  488d8180020000           lea rax, [rcx + 0x280]
000ce03e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce043  488d0df6ba1600           lea rcx, [rip + 0x16baf6]
000ce04a  488908                   mov qword ptr [rax], rcx
000ce04d  488d05dc0d1800           lea rax, [rip + 0x180ddc]
000ce054  488907                   mov qword ptr [rdi], rax
000ce057  488d87b8010000           lea rax, [rdi + 0x1b8]
000ce05e  4889442458               mov qword ptr [rsp + 0x58], rax
000ce063  488908                   mov qword ptr [rax], rcx
000ce066  488bcf                   mov rcx, rdi
000ce069  e8124c0000               call 0xd2c80
000ce06e  83e305                   and ebx, 5
000ce071  80fb05                   cmp bl, 5
000ce074  750d                     jne 0xce083
000ce076  bab8020000               mov edx, 0x2b8
000ce07b  488bcf                   mov rcx, rdi
000ce07e  e88d2ff3ff               call 0x1010
000ce083  488bc7                   mov rax, rdi
000ce086  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce08b  4883c430                 add rsp, 0x30
000ce08f  5f                       pop rdi
000ce090  c3                       ret
