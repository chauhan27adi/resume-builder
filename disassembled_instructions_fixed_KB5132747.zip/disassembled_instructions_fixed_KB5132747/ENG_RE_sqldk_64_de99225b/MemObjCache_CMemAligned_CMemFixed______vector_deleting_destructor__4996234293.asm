; MemObjCache<CMemAligned<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e560, 131 bytes in 1 chunk(s)

; chunk at RVA 0x13e560 (131 bytes)
0013e560  48894c2408               mov qword ptr [rsp + 8], rcx
0013e565  57                       push rdi
0013e566  4883ec30                 sub rsp, 0x30
0013e56a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e573  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e578  8bda                     mov ebx, edx
0013e57a  488bf9                   mov rdi, rcx
0013e57d  488d0564ad1000           lea rax, [rip + 0x10ad64]
0013e584  488901                   mov qword ptr [rcx], rax
0013e587  488d05eaca1000           lea rax, [rip + 0x10caea]
0013e58e  488901                   mov qword ptr [rcx], rax
0013e591  488d05208b1000           lea rax, [rip + 0x108b20]
0013e598  488901                   mov qword ptr [rcx], rax
0013e59b  488d05668c1000           lea rax, [rip + 0x108c66]
0013e5a2  488901                   mov qword ptr [rcx], rax
0013e5a5  4883c138                 add rcx, 0x38
0013e5a9  e84230edff               call 0x115f0
0013e5ae  90                       nop
0013e5af  488d4f30                 lea rcx, [rdi + 0x30]
0013e5b3  e83830edff               call 0x115f0
0013e5b8  90                       nop
0013e5b9  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013e5c0  83e305                   and ebx, 5
0013e5c3  80fb05                   cmp bl, 5
0013e5c6  750d                     jne 0x13e5d5
0013e5c8  ba60010000               mov edx, 0x160
0013e5cd  488bcf                   mov rcx, rdi
0013e5d0  e83b2aecff               call 0x1010
0013e5d5  488bc7                   mov rax, rdi
0013e5d8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e5dd  4883c430                 add rsp, 0x30
0013e5e1  5f                       pop rdi
0013e5e2  c3                       ret
