; CMemPartitioned<CMemThread<CMemDbg<CMemFixed> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce700, 133 bytes in 1 chunk(s)

; chunk at RVA 0xce700 (133 bytes)
000ce700  48894c2408               mov qword ptr [rsp + 8], rcx
000ce705  57                       push rdi
000ce706  4883ec30                 sub rsp, 0x30
000ce70a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce713  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce718  8bda                     mov ebx, edx
000ce71a  488bf9                   mov rdi, rcx
000ce71d  488d0584e91700           lea rax, [rip + 0x17e984]
000ce724  488901                   mov qword ptr [rcx], rax
000ce727  488d8140060000           lea rax, [rcx + 0x640]
000ce72e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce733  488d0d06b41600           lea rcx, [rip + 0x16b406]
000ce73a  488908                   mov qword ptr [rax], rcx
000ce73d  488d05acaf1700           lea rax, [rip + 0x17afac]
000ce744  488907                   mov qword ptr [rdi], rax
000ce747  488d87d8040000           lea rax, [rdi + 0x4d8]
000ce74e  4889442458               mov qword ptr [rsp + 0x58], rax
000ce753  48894830                 mov qword ptr [rax + 0x30], rcx
000ce757  488908                   mov qword ptr [rax], rcx
000ce75a  488bcf                   mov rcx, rdi
000ce75d  e8fe270a00               call 0x170f60
000ce762  83e305                   and ebx, 5
000ce765  80fb05                   cmp bl, 5
000ce768  750d                     jne 0xce777
000ce76a  ba78060000               mov edx, 0x678
000ce76f  488bcf                   mov rcx, rdi
000ce772  e89928f3ff               call 0x1010
000ce777  488bc7                   mov rax, rdi
000ce77a  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce77f  4883c430                 add rsp, 0x30
000ce783  5f                       pop rdi
000ce784  c3                       ret
