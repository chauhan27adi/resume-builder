; `XEPackage0::XE_LiveWriter::WriteBuffer'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2321e0, 31 bytes in 1 chunk(s)

; chunk at RVA 0x2321e0 (31 bytes)
002321e0  4055                     push rbp
002321e2  4883ec20                 sub rsp, 0x20
002321e6  488bea                   mov rbp, rdx
002321e9  4533c0                   xor r8d, r8d
002321ec  488b5578                 mov rdx, qword ptr [rbp + 0x78]
002321f0  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
002321f4  e817eedcff               call 0x1010
002321f9  4883c420                 add rsp, 0x20
002321fd  5d                       pop rbp
002321fe  c3                       ret
