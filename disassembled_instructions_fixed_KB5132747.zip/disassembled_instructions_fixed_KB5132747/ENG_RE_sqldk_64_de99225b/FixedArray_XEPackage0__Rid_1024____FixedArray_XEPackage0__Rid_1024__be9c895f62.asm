; FixedArray<XEPackage0::Rid,1024>::~FixedArray<XEPackage0::Rid,1024>
; sqldk.dll, primary RVA 0x1bc080, 45 bytes in 1 chunk(s)

; chunk at RVA 0x1bc080 (45 bytes)
001bc080  48894c2408               mov qword ptr [rsp + 8], rcx
001bc085  4883ec38                 sub rsp, 0x38
001bc089  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001bc092  4c8d0d57faffff           lea r9, [rip - 0x5a9]
001bc099  ba10000000               mov edx, 0x10
001bc09e  41b800040000             mov r8d, 0x400
001bc0a4  4883c438                 add rsp, 0x38
001bc0a8  e97387e6ff               jmp 0x24820
