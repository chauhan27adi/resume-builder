; UtilDbccTraceOff
; sqldk.dll, primary RVA 0x1b4680, 306 bytes in 1 chunk(s)

; chunk at RVA 0x1b4680 (306 bytes)
001b4680  48895c2408               mov qword ptr [rsp + 8], rbx
001b4685  4889742410               mov qword ptr [rsp + 0x10], rsi
001b468a  57                       push rdi
001b468b  4883ec20                 sub rsp, 0x20
001b468f  0fbff2                   movsx esi, dx
001b4692  8bd9                     mov ebx, ecx
001b4694  4183f8ff                 cmp r8d, -1
001b4698  0f84c5000000             je 0x1b4763
001b469e  4585c0                   test r8d, r8d
001b46a1  7508                     jne 0x1b46ab
001b46a3  81f9d8440000             cmp ecx, 0x44d8
001b46a9  7212                     jb 0x1b46bd
001b46ab  32c0                     xor al, al
001b46ad  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001b46b2  488b742438               mov rsi, qword ptr [rsp + 0x38]
001b46b7  4883c420                 add rsp, 0x20
001b46bb  5f                       pop rdi
001b46bc  c3                       ret
001b46bd  4585c9                   test r9d, r9d
001b46c0  7410                     je 0x1b46d2
001b46c2  e8a90a0000               call 0x1b5170
001b46c7  4885c0                   test rax, rax
001b46ca  7406                     je 0x1b46d2
001b46cc  83780c00                 cmp dword ptr [rax + 0xc], 0
001b46d0  74d9                     je 0x1b46ab
001b46d2  488b0d2fd91700           mov rcx, qword ptr [rip + 0x17d92f]
001b46d9  488b01                   mov rax, qword ptr [rcx]
001b46dc  ff5020                   call qword ptr [rax + 0x20]
001b46df  4c8bc0                   mov r8, rax
001b46e2  4885c0                   test rax, rax
001b46e5  7477                     je 0x1b475e
001b46e7  b8cdcccccc               mov eax, 0xcccccccd
001b46ec  f7e3                     mul ebx
001b46ee  8bc3                     mov eax, ebx
001b46f0  c1ea03                   shr edx, 3
001b46f3  8d0c92                   lea ecx, [rdx + rdx*4]
001b46f6  03c9                     add ecx, ecx
001b46f8  2bc1                     sub eax, ecx
001b46fa  4533d2                   xor r10d, r10d
001b46fd  4c8d0c8500000000         lea r9, [rax*4]
001b4705  43395c0104               cmp dword ptr [r9 + r8 + 4], ebx
001b470a  7435                     je 0x1b4741
001b470c  418bd2                   mov edx, r10d
001b470f  498d4004                 lea rax, [r8 + 4]
001b4713  498bca                   mov rcx, r10
001b4716  3918                     cmp dword ptr [rax], ebx
001b4718  741d                     je 0x1b4737
001b471a  ffc2                     inc edx
001b471c  48ffc1                   inc rcx
001b471f  4883c004                 add rax, 4
001b4723  4883f90a                 cmp rcx, 0xa
001b4727  7ced                     jl 0x1b4716
001b4729  4d8b4030                 mov r8, qword ptr [r8 + 0x30]
001b472d  4d85c0                   test r8, r8
001b4730  75d3                     jne 0x1b4705
001b4732  40b701                   mov dil, 1
001b4735  eb3b                     jmp 0x1b4772
001b4737  4863c2                   movsxd rax, edx
001b473a  4589548004               mov dword ptr [r8 + rax*4 + 4], r10d
001b473f  eb05                     jmp 0x1b4746
001b4741  4789540104               mov dword ptr [r9 + r8 + 4], r10d
001b4746  488b0dbbd81700           mov rcx, qword ptr [rip + 0x17d8bb]
001b474d  41b901000000             mov r9d, 1
001b4753  458bc1                   mov r8d, r9d
001b4756  8bd3                     mov edx, ebx
001b4758  488b01                   mov rax, qword ptr [rcx]
001b475b  ff5010                   call qword ptr [rax + 0x10]
001b475e  40b701                   mov dil, 1
001b4761  eb0f                     jmp 0x1b4772
001b4763  418bd1                   mov edx, r9d
001b4766  e835fcffff               call 0x1b43a0
001b476b  0fb6f8                   movzx edi, al
001b476e  84c0                     test al, al
001b4770  7430                     je 0x1b47a2
001b4772  488b0d8fd81700           mov rcx, qword ptr [rip + 0x17d88f]
001b4779  488b11                   mov rdx, qword ptr [rcx]
001b477c  ff12                     call qword ptr [rdx]
001b477e  f6803901000002           test byte ptr [rax + 0x139], 2
001b4785  7517                     jne 0x1b479e
001b4787  81fbc9090000             cmp ebx, 0x9c9
001b478d  740f                     je 0x1b479e
001b478f  448bc6                   mov r8d, esi
001b4792  8bd3                     mov edx, ebx
001b4794  b98f440000               mov ecx, 0x448f
001b4799  e8722e0000               call 0x1b7610
001b479e  400fb6c7                 movzx eax, dil
001b47a2  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001b47a7  488b742438               mov rsi, qword ptr [rsp + 0x38]
001b47ac  4883c420                 add rsp, 0x20
001b47b0  5f                       pop rdi
001b47b1  c3                       ret
