; XE_AutoP<ColumnDescriptor>::~XE_AutoP<ColumnDescriptor>
; sqldk.dll, primary RVA 0x41d50, 61 bytes in 1 chunk(s)

; chunk at RVA 0x41d50 (61 bytes)
00041d50  48894c2408               mov qword ptr [rsp + 8], rcx
00041d55  53                       push rbx
00041d56  4883ec30                 sub rsp, 0x30
00041d5a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00041d63  488bd9                   mov rbx, rcx
00041d66  488b09                   mov rcx, qword ptr [rcx]
00041d69  4885c9                   test rcx, rcx
00041d6c  7406                     je 0x41d74
00041d6e  ff15dc322d00             call qword ptr [rip + 0x2d32dc]
00041d74  48c70300000000           mov qword ptr [rbx], 0
00041d7b  ba10000000               mov edx, 0x10
00041d80  488b0b                   mov rcx, qword ptr [rbx]
00041d83  4883c430                 add rsp, 0x30
00041d87  5b                       pop rbx
00041d88  e9a351fcff               jmp 0x6f30
