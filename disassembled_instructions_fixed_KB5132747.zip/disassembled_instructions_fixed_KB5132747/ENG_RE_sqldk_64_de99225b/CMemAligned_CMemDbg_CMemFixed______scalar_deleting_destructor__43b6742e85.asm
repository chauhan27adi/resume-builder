; CMemAligned<CMemDbg<CMemFixed> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xd0730, 79 bytes in 1 chunk(s)

; chunk at RVA 0xd0730 (79 bytes)
000d0730  48894c2408               mov qword ptr [rsp + 8], rcx
000d0735  57                       push rdi
000d0736  4883ec30                 sub rsp, 0x30
000d073a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d0743  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d0748  8bda                     mov ebx, edx
000d074a  488bf9                   mov rdi, rcx
000d074d  488d05d4ab1700           lea rax, [rip + 0x17abd4]
000d0754  488901                   mov qword ptr [rcx], rax
000d0757  e804080a00               call 0x170f60
000d075c  83e305                   and ebx, 5
000d075f  80fb05                   cmp bl, 5
000d0762  750d                     jne 0xd0771
000d0764  bae0040000               mov edx, 0x4e0
000d0769  488bcf                   mov rcx, rdi
000d076c  e89f08f3ff               call 0x1010
000d0771  488bc7                   mov rax, rdi
000d0774  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d0779  4883c430                 add rsp, 0x30
000d077d  5f                       pop rdi
000d077e  c3                       ret
