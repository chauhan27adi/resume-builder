; `XE_MetadataTracker::~XE_MetadataTracker'::`1'::dtor$4
; sqldk.dll, primary RVA 0x21675f, 42 bytes in 1 chunk(s)

; chunk at RVA 0x21675f (42 bytes)
0021675f  4055                     push rbp
00216761  4883ec20                 sub rsp, 0x20
00216765  488bea                   mov rbp, rdx
00216768  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
0021676c  4c8d0d7d13e3ff           lea r9, [rip - 0x1cec83]
00216773  41b800040000             mov r8d, 0x400
00216779  ba08000000               mov edx, 8
0021677e  e89de0e0ff               call 0x24820
00216783  4883c420                 add rsp, 0x20
00216787  5d                       pop rbp
00216788  c3                       ret
