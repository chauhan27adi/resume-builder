; CMemThread<CMemAligned<CMemDbg<PageHeapMemObj> > >::~CMemThread<CMemAligned<CMemDbg<PageHeapMemObj> > >
; sqldk.dll, primary RVA 0xec0c0, 73 bytes in 1 chunk(s)

; chunk at RVA 0xec0c0 (73 bytes)
000ec0c0  48894c2408               mov qword ptr [rsp + 8], rcx
000ec0c5  4883ec38                 sub rsp, 0x38
000ec0c9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ec0d2  488d05d7e01500           lea rax, [rip + 0x15e0d7]
000ec0d9  488901                   mov qword ptr [rcx], rax
000ec0dc  488d8158040000           lea rax, [rcx + 0x458]
000ec0e3  4889442448               mov qword ptr [rsp + 0x48], rax
000ec0e8  488d1551da1400           lea rdx, [rip + 0x14da51]
000ec0ef  48895030                 mov qword ptr [rax + 0x30], rdx
000ec0f3  488910                   mov qword ptr [rax], rdx
000ec0f6  488d05d3f01500           lea rax, [rip + 0x15f0d3]
000ec0fd  488901                   mov qword ptr [rcx], rax
000ec100  4883c438                 add rsp, 0x38
000ec104  e9f7620800               jmp 0x172400
