; `XEPackage0::RingTarget::PackageEntry::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x231f15, 35 bytes in 1 chunk(s)

; chunk at RVA 0x231f15 (35 bytes)
00231f15  4055                     push rbp
00231f17  4883ec20                 sub rsp, 0x20
00231f1b  488bea                   mov rbp, rdx
00231f1e  4c8b4570                 mov r8, qword ptr [rbp + 0x70]
00231f22  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
00231f29  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
00231f2d  e8def0dcff               call 0x1010
00231f32  4883c420                 add rsp, 0x20
00231f36  5d                       pop rbp
00231f37  c3                       ret
