; CMemThread<CMemAligned<CMemFixed> >::~CMemThread<CMemAligned<CMemFixed> >
; sqldk.dll, primary RVA 0x100860, 121 bytes in 1 chunk(s)

; chunk at RVA 0x100860 (121 bytes)
00100860  48894c2408               mov qword ptr [rsp + 8], rcx
00100865  53                       push rbx
00100866  4883ec30                 sub rsp, 0x30
0010086a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00100873  488bd9                   mov rbx, rcx
00100876  488d05c38b1400           lea rax, [rip + 0x148bc3]
0010087d  488901                   mov qword ptr [rcx], rax
00100880  488d8110010000           lea rax, [rcx + 0x110]
00100887  4889442448               mov qword ptr [rsp + 0x48], rax
0010088c  488d0dad921300           lea rcx, [rip + 0x1392ad]
00100893  48894830                 mov qword ptr [rax + 0x30], rcx
00100897  488908                   mov qword ptr [rax], rcx
0010089a  488d05d7a71400           lea rax, [rip + 0x14a7d7]
001008a1  488903                   mov qword ptr [rbx], rax
001008a4  488d050d681400           lea rax, [rip + 0x14680d]
001008ab  488903                   mov qword ptr [rbx], rax
001008ae  488d0553691400           lea rax, [rip + 0x146953]
001008b5  488903                   mov qword ptr [rbx], rax
001008b8  488d4b38                 lea rcx, [rbx + 0x38]
001008bc  e82f0df1ff               call 0x115f0
001008c1  90                       nop
001008c2  488d4b30                 lea rcx, [rbx + 0x30]
001008c6  e8250df1ff               call 0x115f0
001008cb  90                       nop
001008cc  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
001008d3  4883c430                 add rsp, 0x30
001008d7  5b                       pop rbx
001008d8  c3                       ret
