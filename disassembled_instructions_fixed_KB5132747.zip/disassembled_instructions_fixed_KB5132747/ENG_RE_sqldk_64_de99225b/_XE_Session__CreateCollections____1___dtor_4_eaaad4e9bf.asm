; `XE_Session::CreateCollections'::`1'::dtor$4
; sqldk.dll, primary RVA 0x234c39, 59 bytes in 1 chunk(s)

; chunk at RVA 0x234c39 (59 bytes)
00234c39  4055                     push rbp
00234c3b  4883ec30                 sub rsp, 0x30
00234c3f  488bea                   mov rbp, rdx
00234c42  c644242806               mov byte ptr [rsp + 0x28], 6
00234c47  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00234c4d  89442420                 mov dword ptr [rsp + 0x20], eax
00234c51  4c8d0d205c0700           lea r9, [rip + 0x75c20]
00234c58  41b801000000             mov r8d, 1
00234c5e  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00234c65  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00234c69  e88252faff               call 0x1d9ef0
00234c6e  4883c430                 add rsp, 0x30
00234c72  5d                       pop rbp
00234c73  c3                       ret
