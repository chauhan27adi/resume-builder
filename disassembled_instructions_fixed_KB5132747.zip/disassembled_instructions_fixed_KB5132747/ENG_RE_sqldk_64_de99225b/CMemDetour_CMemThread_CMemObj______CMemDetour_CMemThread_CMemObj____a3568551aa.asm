; CMemDetour<CMemThread<CMemObj> >::~CMemDetour<CMemThread<CMemObj> >
; sqldk.dll, primary RVA 0x131910, 59 bytes in 1 chunk(s)

; chunk at RVA 0x131910 (59 bytes)
00131910  48894c2408               mov qword ptr [rsp + 8], rcx
00131915  4883ec38                 sub rsp, 0x38
00131919  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00131922  488d05c7a81100           lea rax, [rip + 0x11a8c7]
00131929  488901                   mov qword ptr [rcx], rax
0013192c  488d8140020000           lea rax, [rcx + 0x240]
00131933  4889442448               mov qword ptr [rsp + 0x48], rax
00131938  488d1501821000           lea rdx, [rip + 0x108201]
0013193f  488910                   mov qword ptr [rax], rdx
00131942  4883c438                 add rsp, 0x38
00131946  e94588ffff               jmp 0x12a190
