; `XEPackage0::BucketizingTarget::GetSerializedState'::`1'::dtor$4
; sqldk.dll, primary RVA 0x230891, 31 bytes in 1 chunk(s)

; chunk at RVA 0x230891 (31 bytes)
00230891  4055                     push rbp
00230893  4883ec20                 sub rsp, 0x20
00230897  488bea                   mov rbp, rdx
0023089a  4533c0                   xor r8d, r8d
0023089d  488b5570                 mov rdx, qword ptr [rbp + 0x70]
002308a1  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
002308a5  e86607ddff               call 0x1010
002308aa  4883c420                 add rsp, 0x20
002308ae  5d                       pop rbp
002308af  c3                       ret
