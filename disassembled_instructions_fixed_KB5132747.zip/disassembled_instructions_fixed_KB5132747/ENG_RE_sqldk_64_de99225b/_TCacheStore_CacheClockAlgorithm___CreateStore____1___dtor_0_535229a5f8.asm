; `TCacheStore<CacheClockAlgorithm>::CreateStore'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22d190, 53 bytes in 1 chunk(s)

; chunk at RVA 0x22d190 (53 bytes)
0022d190  4055                     push rbp
0022d192  4883ec30                 sub rsp, 0x30
0022d196  488bea                   mov rbp, rdx
0022d199  c644242806               mov byte ptr [rsp + 0x28], 6
0022d19e  8b4540                   mov eax, dword ptr [rbp + 0x40]
0022d1a1  89442420                 mov dword ptr [rsp + 0x20], eax
0022d1a5  4c8d0d24d10400           lea r9, [rip + 0x4d124]
0022d1ac  41b801000000             mov r8d, 1
0022d1b2  488b5550                 mov rdx, qword ptr [rbp + 0x50]
0022d1b6  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
0022d1ba  e8519dddff               call 0x6f10
0022d1bf  4883c430                 add rsp, 0x30
0022d1c3  5d                       pop rbp
0022d1c4  c3                       ret
