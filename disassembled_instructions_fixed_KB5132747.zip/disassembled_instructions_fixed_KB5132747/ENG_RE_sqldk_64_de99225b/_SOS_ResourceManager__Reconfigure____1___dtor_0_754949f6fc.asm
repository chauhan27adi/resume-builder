; `SOS_ResourceManager::Reconfigure'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22eb00, 66 bytes in 1 chunk(s)

; chunk at RVA 0x22eb00 (66 bytes)
0022eb00  4055                     push rbp
0022eb02  4883ec30                 sub rsp, 0x30
0022eb06  488bea                   mov rbp, rdx
0022eb09  488b9550010000           mov rdx, qword ptr [rbp + 0x150]
0022eb10  4883c240                 add rdx, 0x40
0022eb14  c644242806               mov byte ptr [rsp + 0x28], 6
0022eb19  8b4578                   mov eax, dword ptr [rbp + 0x78]
0022eb1c  89442420                 mov dword ptr [rsp + 0x20], eax
0022eb20  4c8d0d39080700           lea r9, [rip + 0x70839]
0022eb27  41b801000000             mov r8d, 1
0022eb2d  488b12                   mov rdx, qword ptr [rdx]
0022eb30  488b8dc0000000           mov rcx, qword ptr [rbp + 0xc0]
0022eb37  e8d483ddff               call 0x6f10
0022eb3c  4883c430                 add rsp, 0x30
0022eb40  5d                       pop rbp
0022eb41  c3                       ret
