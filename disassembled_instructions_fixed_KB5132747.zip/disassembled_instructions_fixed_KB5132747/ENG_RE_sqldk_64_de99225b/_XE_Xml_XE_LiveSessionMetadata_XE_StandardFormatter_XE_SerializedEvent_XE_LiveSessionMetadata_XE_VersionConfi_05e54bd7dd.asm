; `XE_Xml<XE_LiveSessionMetadata,XE_StandardFormatter,XE_SerializedEvent<XE_LiveSessionMetadata,XE_VersionConfig> >::CacheObjectString'::`1'::dtor$0
; sqldk.dll, primary RVA 0x231570, 31 bytes in 1 chunk(s)

; chunk at RVA 0x231570 (31 bytes)
00231570  4055                     push rbp
00231572  4883ec20                 sub rsp, 0x20
00231576  488bea                   mov rbp, rdx
00231579  4533c0                   xor r8d, r8d
0023157c  488b5560                 mov rdx, qword ptr [rbp + 0x60]
00231580  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
00231584  e887fadcff               call 0x1010
00231589  4883c420                 add rsp, 0x20
0023158d  5d                       pop rbp
0023158e  c3                       ret
