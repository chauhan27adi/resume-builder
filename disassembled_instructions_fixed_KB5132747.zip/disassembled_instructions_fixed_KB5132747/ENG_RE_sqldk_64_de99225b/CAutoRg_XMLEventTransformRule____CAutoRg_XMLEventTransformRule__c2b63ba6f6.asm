; CAutoRg<XMLEventTransformRule>::~CAutoRg<XMLEventTransformRule>
; sqldk.dll, primary RVA 0x4e120, 79 bytes in 3 chunk(s)

; chunk at RVA 0x4e120 (23 bytes)
0004e120  4883ec28                 sub rsp, 0x28
0004e124  488b09                   mov rcx, qword ptr [rcx]
0004e127  4885c9                   test rcx, rcx
0004e12a  743f                     je 0x4e16b
0004e12c  4c8b41f8                 mov r8, qword ptr [rcx - 8]
0004e130  4c8d0d99020000           lea r9, [rip + 0x299]

; chunk at RVA 0x4e137 (51 bytes)
0004e137  48895c2420               mov qword ptr [rsp + 0x20], rbx
0004e13c  ba28000000               mov edx, 0x28
0004e141  488d59f8                 lea rbx, [rcx - 8]
0004e145  e8d666fdff               call 0x24820
0004e14a  488b03                   mov rax, qword ptr [rbx]
0004e14d  488bcb                   mov rcx, rbx
0004e150  488d1480                 lea rdx, [rax + rax*4]
0004e154  488d14d508000000         lea rdx, [rdx*8 + 8]
0004e15c  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0004e161  4883c428                 add rsp, 0x28
0004e165  e9c68dfbff               jmp 0x6f30

; chunk at RVA 0x4e16b (5 bytes)
0004e16b  4883c428                 add rsp, 0x28
0004e16f  c3                       ret
