; MemObjCache<CMemThread<CMemAligned<CMemDbg<CMemLargePageObj> > > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13ed50, 128 bytes in 1 chunk(s)

; chunk at RVA 0x13ed50 (128 bytes)
0013ed50  48894c2408               mov qword ptr [rsp + 8], rcx
0013ed55  57                       push rdi
0013ed56  4883ec30                 sub rsp, 0x30
0013ed5a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013ed63  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013ed68  8bda                     mov ebx, edx
0013ed6a  488bf9                   mov rdi, rcx
0013ed6d  488d05e4581200           lea rax, [rip + 0x1258e4]
0013ed74  488901                   mov qword ptr [rcx], rax
0013ed77  488d0552991000           lea rax, [rip + 0x109952]
0013ed7e  488901                   mov qword ptr [rcx], rax
0013ed81  488d81a0050000           lea rax, [rcx + 0x5a0]
0013ed88  4889442450               mov qword ptr [rsp + 0x50], rax
0013ed8d  488d0dacad0f00           lea rcx, [rip + 0xfadac]
0013ed94  48894830                 mov qword ptr [rax + 0x30], rcx
0013ed98  488908                   mov qword ptr [rax], rcx
0013ed9b  488d05dec61000           lea rax, [rip + 0x10c6de]
0013eda2  488907                   mov qword ptr [rdi], rax
0013eda5  488bcf                   mov rcx, rdi
0013eda8  e8934b0300               call 0x173940
0013edad  83e305                   and ebx, 5
0013edb0  80fb05                   cmp bl, 5
0013edb3  750d                     jne 0x13edc2
0013edb5  bac8060000               mov edx, 0x6c8
0013edba  488bcf                   mov rcx, rdi
0013edbd  e84e22ecff               call 0x1010
0013edc2  488bc7                   mov rax, rdi
0013edc5  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013edca  4883c430                 add rsp, 0x30
0013edce  5f                       pop rdi
0013edcf  c3                       ret
