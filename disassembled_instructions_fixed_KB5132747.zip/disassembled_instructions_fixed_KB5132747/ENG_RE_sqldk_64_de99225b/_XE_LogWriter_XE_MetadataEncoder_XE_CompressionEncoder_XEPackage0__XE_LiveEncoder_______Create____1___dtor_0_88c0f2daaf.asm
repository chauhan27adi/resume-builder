; `XE_LogWriter<XE_MetadataEncoder<XE_CompressionEncoder<XEPackage0::XE_LiveEncoder> > >::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x232240, 31 bytes in 1 chunk(s)

; chunk at RVA 0x232240 (31 bytes)
00232240  4055                     push rbp
00232242  4883ec20                 sub rsp, 0x20
00232246  488bea                   mov rbp, rdx
00232249  4533c0                   xor r8d, r8d
0023224c  488b5528                 mov rdx, qword ptr [rbp + 0x28]
00232250  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00232254  e8b7eddcff               call 0x1010
00232259  4883c420                 add rsp, 0x20
0023225d  5d                       pop rbp
0023225e  c3                       ret
