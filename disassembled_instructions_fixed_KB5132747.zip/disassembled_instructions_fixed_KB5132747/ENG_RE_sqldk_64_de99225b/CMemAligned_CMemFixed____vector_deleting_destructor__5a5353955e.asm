; CMemAligned<CMemFixed>::`vector deleting destructor'
; sqldk.dll, primary RVA 0xd0790, 121 bytes in 1 chunk(s)

; chunk at RVA 0xd0790 (121 bytes)
000d0790  48894c2408               mov qword ptr [rsp + 8], rcx
000d0795  57                       push rdi
000d0796  4883ec30                 sub rsp, 0x30
000d079a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d07a3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d07a8  8bda                     mov ebx, edx
000d07aa  488bf9                   mov rdi, rcx
000d07ad  488d05c4a81700           lea rax, [rip + 0x17a8c4]
000d07b4  488901                   mov qword ptr [rcx], rax
000d07b7  488d05fa681700           lea rax, [rip + 0x1768fa]
000d07be  488901                   mov qword ptr [rcx], rax
000d07c1  488d05406a1700           lea rax, [rip + 0x176a40]
000d07c8  488901                   mov qword ptr [rcx], rax
000d07cb  4883c138                 add rcx, 0x38
000d07cf  e81c0ef4ff               call 0x115f0
000d07d4  90                       nop
000d07d5  488d4f30                 lea rcx, [rdi + 0x30]
000d07d9  e8120ef4ff               call 0x115f0
000d07de  90                       nop
000d07df  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
000d07e6  83e305                   and ebx, 5
000d07e9  80fb05                   cmp bl, 5
000d07ec  750d                     jne 0xd07fb
000d07ee  ba10010000               mov edx, 0x110
000d07f3  488bcf                   mov rcx, rdi
000d07f6  e81508f3ff               call 0x1010
000d07fb  488bc7                   mov rax, rdi
000d07fe  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d0803  4883c430                 add rsp, 0x30
000d0807  5f                       pop rdi
000d0808  c3                       ret
