; `PackageEntry::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x216fc4, 35 bytes in 1 chunk(s)

; chunk at RVA 0x216fc4 (35 bytes)
00216fc4  4055                     push rbp
00216fc6  4883ec20                 sub rsp, 0x20
00216fca  488bea                   mov rbp, rdx
00216fcd  4c8b8590000000           mov r8, qword ptr [rbp + 0x90]
00216fd4  488b5548                 mov rdx, qword ptr [rbp + 0x48]
00216fd8  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00216fdc  e82fa0deff               call 0x1010
00216fe1  4883c420                 add rsp, 0x20
00216fe5  5d                       pop rbp
00216fe6  c3                       ret
