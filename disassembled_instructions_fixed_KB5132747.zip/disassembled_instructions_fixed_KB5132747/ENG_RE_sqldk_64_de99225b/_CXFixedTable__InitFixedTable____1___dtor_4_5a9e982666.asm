; `CXFixedTable::InitFixedTable'::`1'::dtor$4
; sqldk.dll, primary RVA 0x216d2d, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216d2d (31 bytes)
00216d2d  4055                     push rbp
00216d2f  4883ec20                 sub rsp, 0x20
00216d33  488bea                   mov rbp, rdx
00216d36  4533c0                   xor r8d, r8d
00216d39  488b5548                 mov rdx, qword ptr [rbp + 0x48]
00216d3d  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00216d41  e8caa2deff               call 0x1010
00216d46  4883c420                 add rsp, 0x20
00216d4a  5d                       pop rbp
00216d4b  c3                       ret
