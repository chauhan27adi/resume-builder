; CMemThread<CMemLargePageObj>::~CMemThread<CMemLargePageObj>
; sqldk.dll, primary RVA 0x113720, 121 bytes in 1 chunk(s)

; chunk at RVA 0x113720 (121 bytes)
00113720  48894c2408               mov qword ptr [rsp + 8], rcx
00113725  53                       push rbx
00113726  4883ec30                 sub rsp, 0x30
0011372a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00113733  488bd9                   mov rbx, rcx
00113736  488d05f3541300           lea rax, [rip + 0x1354f3]
0011373d  488901                   mov qword ptr [rcx], rax
00113740  488d81c8010000           lea rax, [rcx + 0x1c8]
00113747  4889442448               mov qword ptr [rsp + 0x48], rax
0011374c  488d0ded631200           lea rcx, [rip + 0x1263ed]
00113753  48894830                 mov qword ptr [rax + 0x30], rcx
00113757  488908                   mov qword ptr [rax], rcx
0011375a  488d05b7361300           lea rax, [rip + 0x1336b7]
00113761  488903                   mov qword ptr [rbx], rax
00113764  488d05fd371300           lea rax, [rip + 0x1337fd]
0011376b  488903                   mov qword ptr [rbx], rax
0011376e  488d05933a1300           lea rax, [rip + 0x133a93]
00113775  488903                   mov qword ptr [rbx], rax
00113778  488d4b38                 lea rcx, [rbx + 0x38]
0011377c  e86fdeefff               call 0x115f0
00113781  90                       nop
00113782  488d4b30                 lea rcx, [rbx + 0x30]
00113786  e865deefff               call 0x115f0
0011378b  90                       nop
0011378c  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
00113793  4883c430                 add rsp, 0x30
00113797  5b                       pop rbx
00113798  c3                       ret
