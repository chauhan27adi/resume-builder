; MemObjCache<CMemThread<CMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13f130, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13f130 (79 bytes)
0013f130  48894c2408               mov qword ptr [rsp + 8], rcx
0013f135  57                       push rdi
0013f136  4883ec30                 sub rsp, 0x30
0013f13a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013f143  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013f148  8bda                     mov ebx, edx
0013f14a  488bf9                   mov rdi, rcx
0013f14d  488d055c851000           lea rax, [rip + 0x10855c]
0013f154  488901                   mov qword ptr [rcx], rax
0013f157  e834b0feff               call 0x12a190
0013f15c  83e305                   and ebx, 5
0013f15f  80fb05                   cmp bl, 5
0013f162  750d                     jne 0x13f171
0013f164  ba50020000               mov edx, 0x250
0013f169  488bcf                   mov rcx, rdi
0013f16c  e89f1eecff               call 0x1010
0013f171  488bc7                   mov rax, rdi
0013f174  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013f179  4883c430                 add rsp, 0x30
0013f17d  5f                       pop rdi
0013f17e  c3                       ret
