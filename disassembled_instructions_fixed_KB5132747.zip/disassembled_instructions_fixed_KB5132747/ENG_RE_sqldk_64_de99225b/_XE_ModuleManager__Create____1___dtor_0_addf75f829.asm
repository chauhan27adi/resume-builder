; `XE_ModuleManager::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2356e0, 62 bytes in 1 chunk(s)

; chunk at RVA 0x2356e0 (62 bytes)
002356e0  4055                     push rbp
002356e2  4883ec30                 sub rsp, 0x30
002356e6  488bea                   mov rbp, rdx
002356e9  c644242806               mov byte ptr [rsp + 0x28], 6
002356ee  8b8588000000             mov eax, dword ptr [rbp + 0x88]
002356f4  89442420                 mov dword ptr [rsp + 0x20], eax
002356f8  4c8d0d41520700           lea r9, [rip + 0x75241]
002356ff  41b801000000             mov r8d, 1
00235705  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0023570c  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
00235713  e8d847faff               call 0x1d9ef0
00235718  4883c430                 add rsp, 0x30
0023571c  5d                       pop rbp
0023571d  c3                       ret
