; `SOS_Node::EnqueueTimerTaskDirectInternal'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21d5f0, 53 bytes in 1 chunk(s)

; chunk at RVA 0x21d5f0 (53 bytes)
0021d5f0  4055                     push rbp
0021d5f2  4883ec30                 sub rsp, 0x30
0021d5f6  488bea                   mov rbp, rdx
0021d5f9  c644242806               mov byte ptr [rsp + 0x28], 6
0021d5fe  8b4550                   mov eax, dword ptr [rbp + 0x50]
0021d601  89442420                 mov dword ptr [rsp + 0x20], eax
0021d605  4c8d0d2cbf0700           lea r9, [rip + 0x7bf2c]
0021d60c  41b801000000             mov r8d, 1
0021d612  488b5540                 mov rdx, qword ptr [rbp + 0x40]
0021d616  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0021d61a  e8f198deff               call 0x6f10
0021d61f  4883c430                 add rsp, 0x30
0021d623  5d                       pop rbp
0021d624  c3                       ret
