; CMemDetour<CMemThread<CMemLargePageObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xce960, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce960 (104 bytes)
000ce960  48894c2408               mov qword ptr [rsp + 8], rcx
000ce965  57                       push rdi
000ce966  4883ec30                 sub rsp, 0x30
000ce96a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce973  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce978  8bda                     mov ebx, edx
000ce97a  488bf9                   mov rdi, rcx
000ce97d  488d0524e31700           lea rax, [rip + 0x17e324]
000ce984  488901                   mov qword ptr [rcx], rax
000ce987  488d81e0020000           lea rax, [rcx + 0x2e0]
000ce98e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce993  488d0da6b11600           lea rcx, [rip + 0x16b1a6]
000ce99a  488908                   mov qword ptr [rax], rcx
000ce99d  488bcf                   mov rcx, rdi
000ce9a0  e87b4d0400               call 0x113720
000ce9a5  83e305                   and ebx, 5
000ce9a8  80fb05                   cmp bl, 5
000ce9ab  750d                     jne 0xce9ba
000ce9ad  ba18030000               mov edx, 0x318
000ce9b2  488bcf                   mov rcx, rdi
000ce9b5  e85626f3ff               call 0x1010
000ce9ba  488bc7                   mov rax, rdi
000ce9bd  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce9c2  4883c430                 add rsp, 0x30
000ce9c6  5f                       pop rdi
000ce9c7  c3                       ret
