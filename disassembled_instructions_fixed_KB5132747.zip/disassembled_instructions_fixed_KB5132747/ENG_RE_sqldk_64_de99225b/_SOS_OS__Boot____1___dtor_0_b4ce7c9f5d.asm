; `SOS_OS::Boot'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21ce10, 62 bytes in 1 chunk(s)

; chunk at RVA 0x21ce10 (62 bytes)
0021ce10  4055                     push rbp
0021ce12  4883ec30                 sub rsp, 0x30
0021ce16  488bea                   mov rbp, rdx
0021ce19  c644242806               mov byte ptr [rsp + 0x28], 6
0021ce1e  8b85f8000000             mov eax, dword ptr [rbp + 0xf8]
0021ce24  89442420                 mov dword ptr [rsp + 0x20], eax
0021ce28  4c8d0d21c30700           lea r9, [rip + 0x7c321]
0021ce2f  41b801000000             mov r8d, 1
0021ce35  488b158cf51800           mov rdx, qword ptr [rip + 0x18f58c]
0021ce3c  488b8d08010000           mov rcx, qword ptr [rbp + 0x108]
0021ce43  e8c8a0deff               call 0x6f10
0021ce48  4883c430                 add rsp, 0x30
0021ce4c  5d                       pop rbp
0021ce4d  c3                       ret
