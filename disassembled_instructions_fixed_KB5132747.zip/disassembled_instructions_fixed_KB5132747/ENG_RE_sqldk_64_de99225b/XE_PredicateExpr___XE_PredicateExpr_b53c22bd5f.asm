; XE_PredicateExpr::~XE_PredicateExpr
; sqldk.dll, primary RVA 0x1fa2c0, 39 bytes in 1 chunk(s)

; chunk at RVA 0x1fa2c0 (39 bytes)
001fa2c0  48894c2408               mov qword ptr [rsp + 8], rcx
001fa2c5  4883ec18                 sub rsp, 0x18
001fa2c9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
001fa2d1  488d05a8080b00           lea rax, [rip + 0xb08a8]
001fa2d8  488901                   mov qword ptr [rcx], rax
001fa2db  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
001fa2e2  4883c418                 add rsp, 0x18
001fa2e6  c3                       ret
