; `XE_AssocMemory::Add'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235af0, 53 bytes in 1 chunk(s)

; chunk at RVA 0x235af0 (53 bytes)
00235af0  4055                     push rbp
00235af2  4883ec30                 sub rsp, 0x30
00235af6  488bea                   mov rbp, rdx
00235af9  c644242806               mov byte ptr [rsp + 0x28], 6
00235afe  8b4570                   mov eax, dword ptr [rbp + 0x70]
00235b01  89442420                 mov dword ptr [rsp + 0x20], eax
00235b05  4c8d0d5c4e0700           lea r9, [rip + 0x74e5c]
00235b0c  41b801000000             mov r8d, 1
00235b12  488b5578                 mov rdx, qword ptr [rbp + 0x78]
00235b16  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00235b1a  e8d143faff               call 0x1d9ef0
00235b1f  4883c430                 add rsp, 0x30
00235b23  5d                       pop rbp
00235b24  c3                       ret
