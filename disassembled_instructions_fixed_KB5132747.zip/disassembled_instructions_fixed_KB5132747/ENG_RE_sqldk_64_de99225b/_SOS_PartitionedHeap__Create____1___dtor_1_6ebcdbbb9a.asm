; `SOS_PartitionedHeap::Create'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22dc90, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22dc90 (59 bytes)
0022dc90  4055                     push rbp
0022dc92  4883ec30                 sub rsp, 0x30
0022dc96  488bea                   mov rbp, rdx
0022dc99  c644242806               mov byte ptr [rsp + 0x28], 6
0022dc9e  8b4548                   mov eax, dword ptr [rbp + 0x48]
0022dca1  89442420                 mov dword ptr [rsp + 0x20], eax
0022dca5  4c8d0da4100700           lea r9, [rip + 0x710a4]
0022dcac  41b801000000             mov r8d, 1
0022dcb2  488b95b8000000           mov rdx, qword ptr [rbp + 0xb8]
0022dcb9  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
0022dcc0  e84b92ddff               call 0x6f10
0022dcc5  4883c430                 add rsp, 0x30
0022dcc9  5d                       pop rbp
0022dcca  c3                       ret
