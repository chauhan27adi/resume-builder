; std::basic_ostream<char,std::char_traits<char> >::sentry::~sentry
; sqldk.dll, primary RVA 0x58350, 75 bytes in 1 chunk(s)

; chunk at RVA 0x58350 (75 bytes)
00058350  48894c2408               mov qword ptr [rsp + 8], rcx
00058355  53                       push rbx
00058356  4883ec30                 sub rsp, 0x30
0005835a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00058363  488bd9                   mov rbx, rcx
00058366  ff1514141e00             call qword ptr [rip + 0x1e1414]
0005836c  84c0                     test al, al
0005836e  750a                     jne 0x5837a
00058370  488b0b                   mov rcx, qword ptr [rbx]
00058373  ff1517141e00             call qword ptr [rip + 0x1e1417]
00058379  90                       nop
0005837a  488b13                   mov rdx, qword ptr [rbx]
0005837d  488b02                   mov rax, qword ptr [rdx]
00058380  48634804                 movsxd rcx, dword ptr [rax + 4]
00058384  488b4c1148               mov rcx, qword ptr [rcx + rdx + 0x48]
00058389  4885c9                   test rcx, rcx
0005838c  7407                     je 0x58395
0005838e  488b01                   mov rax, qword ptr [rcx]
00058391  ff5010                   call qword ptr [rax + 0x10]
00058394  90                       nop
00058395  4883c430                 add rsp, 0x30
00058399  5b                       pop rbx
0005839a  c3                       ret
