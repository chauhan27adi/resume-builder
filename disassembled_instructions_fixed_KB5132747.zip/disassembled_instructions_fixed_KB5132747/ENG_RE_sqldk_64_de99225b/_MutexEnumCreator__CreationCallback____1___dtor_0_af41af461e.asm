; `MutexEnumCreator::CreationCallback'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21c5d0, 53 bytes in 1 chunk(s)

; chunk at RVA 0x21c5d0 (53 bytes)
0021c5d0  4055                     push rbp
0021c5d2  4883ec30                 sub rsp, 0x30
0021c5d6  488bea                   mov rbp, rdx
0021c5d9  c644242806               mov byte ptr [rsp + 0x28], 6
0021c5de  8b4550                   mov eax, dword ptr [rbp + 0x50]
0021c5e1  89442420                 mov dword ptr [rsp + 0x20], eax
0021c5e5  4c8d0d74c70700           lea r9, [rip + 0x7c774]
0021c5ec  41b801000000             mov r8d, 1
0021c5f2  488b5558                 mov rdx, qword ptr [rbp + 0x58]
0021c5f6  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0021c5fa  e811a9deff               call 0x6f10
0021c5ff  4883c430                 add rsp, 0x30
0021c603  5d                       pop rbp
0021c604  c3                       ret
