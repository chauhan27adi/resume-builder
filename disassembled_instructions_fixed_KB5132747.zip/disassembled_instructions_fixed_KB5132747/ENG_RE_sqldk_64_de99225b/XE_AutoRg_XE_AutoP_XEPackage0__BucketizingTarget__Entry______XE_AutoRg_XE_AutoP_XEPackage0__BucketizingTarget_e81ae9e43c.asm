; XE_AutoRg<XE_AutoP<XEPackage0::BucketizingTarget::Entry> >::~XE_AutoRg<XE_AutoP<XEPackage0::BucketizingTarget::Entry> >
; sqldk.dll, primary RVA 0x1c62d0, 99 bytes in 1 chunk(s)

; chunk at RVA 0x1c62d0 (99 bytes)
001c62d0  48894c2408               mov qword ptr [rsp + 8], rcx
001c62d5  53                       push rbx
001c62d6  4883ec30                 sub rsp, 0x30
001c62da  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001c62e3  488bd9                   mov rbx, rcx
001c62e6  488b09                   mov rcx, qword ptr [rcx]
001c62e9  e8d20e0000               call 0x1c71c0
001c62ee  48c70300000000           mov qword ptr [rbx], 0
001c62f5  488b0b                   mov rcx, qword ptr [rbx]
001c62f8  4885c9                   test rcx, rcx
001c62fb  7430                     je 0x1c632d
001c62fd  488d59f8                 lea rbx, [rcx - 8]
001c6301  4c8d0d48ffffff           lea r9, [rip - 0xb8]
001c6308  4c8b03                   mov r8, qword ptr [rbx]
001c630b  ba08000000               mov edx, 8
001c6310  e80be5e5ff               call 0x24820
001c6315  488b13                   mov rdx, qword ptr [rbx]
001c6318  488d14d508000000         lea rdx, [rdx*8 + 8]
001c6320  488bcb                   mov rcx, rbx
001c6323  4883c430                 add rsp, 0x30
001c6327  5b                       pop rbx
001c6328  e9030ce4ff               jmp 0x6f30
001c632d  4883c430                 add rsp, 0x30
001c6331  5b                       pop rbx
001c6332  c3                       ret
