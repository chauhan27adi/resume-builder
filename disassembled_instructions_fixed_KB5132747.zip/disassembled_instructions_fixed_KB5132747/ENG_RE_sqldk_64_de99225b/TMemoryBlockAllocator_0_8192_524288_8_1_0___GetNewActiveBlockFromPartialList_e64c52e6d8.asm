; TMemoryBlockAllocator<0,8192,524288,8,1,0>::GetNewActiveBlockFromPartialList
; sqldk.dll, primary RVA 0x1b1a0, 238 bytes in 1 chunk(s)

; chunk at RVA 0x1b1a0 (238 bytes)
0001b1a0  488bc4                   mov rax, rsp
0001b1a3  48894808                 mov qword ptr [rax + 8], rcx
0001b1a7  55                       push rbp
0001b1a8  4154                     push r12
0001b1aa  4155                     push r13
0001b1ac  4156                     push r14
0001b1ae  4157                     push r15
0001b1b0  488d68a9                 lea rbp, [rax - 0x57]
0001b1b4  4881ec90000000           sub rsp, 0x90
0001b1bb  48c7451ffeffffff         mov qword ptr [rbp + 0x1f], 0xfffffffffffffffe
0001b1c3  48895810                 mov qword ptr [rax + 0x10], rbx
0001b1c7  48897018                 mov qword ptr [rax + 0x18], rsi
0001b1cb  48897820                 mov qword ptr [rax + 0x20], rdi
0001b1cf  450fb6e8                 movzx r13d, r8b
0001b1d3  33ff                     xor edi, edi
0001b1d5  8bdf                     mov ebx, edi
0001b1d7  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0001b1db  488d45c7                 lea rax, [rbp - 0x39]
0001b1df  488945cf                 mov qword ptr [rbp - 0x31], rax
0001b1e3  488d45c7                 lea rax, [rbp - 0x39]
0001b1e7  488945c7                 mov qword ptr [rbp - 0x39], rax
0001b1eb  0fb7c2                   movzx eax, dx
0001b1ee  488d0480                 lea rax, [rax + rax*4]
0001b1f2  48c1e006                 shl rax, 6
0001b1f6  4803c1                   add rax, rcx
0001b1f9  488945d7                 mov qword ptr [rbp - 0x29], rax
0001b1fd  4c8da000010000           lea r12, [rax + 0x100]
0001b204  448d7f06                 lea r15d, [rdi + 6]
0001b208  440fb6757f               movzx r14d, byte ptr [rbp + 0x7f]
0001b20d  4584c9                   test r9b, r9b
0001b210  0f84875d0700             je 0x90f9d
0001b216  8d7708                   lea esi, [rdi + 8]
0001b219  eb01                     jmp 0x1b21c
0001b21b  cc                       int3
0001b21c  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0001b220  83fe10                   cmp esi, 0x10
0001b223  0f8390190000             jae 0x1cbb9
0001b229  48897dbf                 mov qword ptr [rbp - 0x41], rdi
0001b22d  488d55df                 lea rdx, [rbp - 0x21]
0001b231  488955e7                 mov qword ptr [rbp - 0x19], rdx
0001b235  488d4ddf                 lea rcx, [rbp - 0x21]
0001b239  48894ddf                 mov qword ptr [rbp - 0x21], rcx
0001b23d  4863fe                   movsxd rdi, esi
0001b240  4883c711                 add rdi, 0x11
0001b244  48c1e704                 shl rdi, 4
0001b248  4803f8                   add rdi, rax
0001b24b  488bcf                   mov rcx, rdi
0001b24e  ff15c4df2100             call qword ptr [rip + 0x21dfc4]
0001b254  4c8bc0                   mov r8, rax
0001b257  4885c0                   test rax, rax
0001b25a  7569                     jne 0x1b2c5
0001b25c  488b5dbf                 mov rbx, qword ptr [rbp - 0x41]
0001b260  4533e4                   xor r12d, r12d
0001b263  488d45df                 lea rax, [rbp - 0x21]
0001b267  488b55e7                 mov rdx, qword ptr [rbp - 0x19]
0001b26b  483bd0                   cmp rdx, rax
0001b26e  0f85965c0700             jne 0x90f0a
0001b274  ffc6                     inc esi
0001b276  4885db                   test rbx, rbx
0001b279  488b45d7                 mov rax, qword ptr [rbp - 0x29]
0001b27d  4c8da000010000           lea r12, [rax + 0x100]
0001b284  7505                     jne 0x1b28b
0001b286  33ff                     xor edi, edi
0001b288  eb92                     jmp 0x1b21c
0001b28a  cc                       int3
0001b28b  eb03                     jmp 0x1b290
0001b28d  cc                       int3
