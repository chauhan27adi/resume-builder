; `SOS_UserStore::CreateDescriptor'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22cdc0, 72 bytes in 1 chunk(s)

; chunk at RVA 0x22cdc0 (72 bytes)
0022cdc0  4055                     push rbp
0022cdc2  4883ec30                 sub rsp, 0x30
0022cdc6  488bea                   mov rbp, rdx
0022cdc9  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0022cdd0  4881c2c0060000           add rdx, 0x6c0
0022cdd7  c644242806               mov byte ptr [rsp + 0x28], 6
0022cddc  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022cde2  89442420                 mov dword ptr [rsp + 0x20], eax
0022cde6  4c8d0dabd50400           lea r9, [rip + 0x4d5ab]
0022cded  41b801000000             mov r8d, 1
0022cdf3  488b12                   mov rdx, qword ptr [rdx]
0022cdf6  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
0022cdfd  e80ea1ddff               call 0x6f10
0022ce02  4883c430                 add rsp, 0x30
0022ce06  5d                       pop rbp
0022ce07  c3                       ret
