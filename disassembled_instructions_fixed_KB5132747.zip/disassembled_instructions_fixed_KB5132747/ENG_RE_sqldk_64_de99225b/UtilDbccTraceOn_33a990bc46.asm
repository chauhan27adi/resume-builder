; UtilDbccTraceOn
; sqldk.dll, primary RVA 0x1b47c0, 377 bytes in 1 chunk(s)

; chunk at RVA 0x1b47c0 (377 bytes)
001b47c0  48895c2408               mov qword ptr [rsp + 8], rbx
001b47c5  4889742410               mov qword ptr [rsp + 0x10], rsi
001b47ca  57                       push rdi
001b47cb  4883ec20                 sub rsp, 0x20
001b47cf  0fbff2                   movsx esi, dx
001b47d2  8bd9                     mov ebx, ecx
001b47d4  4183f8ff                 cmp r8d, -1
001b47d8  0f840c010000             je 0x1b48ea
001b47de  4585c0                   test r8d, r8d
001b47e1  7508                     jne 0x1b47eb
001b47e3  81f9d8440000             cmp ecx, 0x44d8
001b47e9  7212                     jb 0x1b47fd
001b47eb  32c0                     xor al, al
001b47ed  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001b47f2  488b742438               mov rsi, qword ptr [rsp + 0x38]
001b47f7  4883c420                 add rsp, 0x20
001b47fb  5f                       pop rdi
001b47fc  c3                       ret
001b47fd  4585c9                   test r9d, r9d
001b4800  7410                     je 0x1b4812
001b4802  e869090000               call 0x1b5170
001b4807  4885c0                   test rax, rax
001b480a  7406                     je 0x1b4812
001b480c  83780c00                 cmp dword ptr [rax + 0xc], 0
001b4810  74d9                     je 0x1b47eb
001b4812  488b0defd71700           mov rcx, qword ptr [rip + 0x17d7ef]
001b4819  488b01                   mov rax, qword ptr [rcx]
001b481c  ff5020                   call qword ptr [rax + 0x20]
001b481f  33d2                     xor edx, edx
001b4821  4c8bc0                   mov r8, rax
001b4824  4885c0                   test rax, rax
001b4827  7467                     je 0x1b4890
001b4829  b8cdcccccc               mov eax, 0xcccccccd
001b482e  f7e3                     mul ebx
001b4830  8bc3                     mov eax, ebx
001b4832  c1ea03                   shr edx, 3
001b4835  8d0c92                   lea ecx, [rdx + rdx*4]
001b4838  03c9                     add ecx, ecx
001b483a  2bc1                     sub eax, ecx
001b483c  4c8d0c8500000000         lea r9, [rax*4]
001b4844  0f1f4000                 nop dword ptr [rax]
001b4848  0f1f840000000000         nop dword ptr [rax + rax]
001b4850  438b440104               mov eax, dword ptr [r9 + r8 + 4]
001b4855  85c0                     test eax, eax
001b4857  0f8486000000             je 0x1b48e3
001b485d  3bc3                     cmp eax, ebx
001b485f  7478                     je 0x1b48d9
001b4861  33d2                     xor edx, edx
001b4863  498d4004                 lea rax, [r8 + 4]
001b4867  33c9                     xor ecx, ecx
001b4869  0f1f8000000000           nop dword ptr [rax]
001b4870  833800                   cmp dword ptr [rax], 0
001b4873  7469                     je 0x1b48de
001b4875  ffc2                     inc edx
001b4877  48ffc1                   inc rcx
001b487a  4883c004                 add rax, 4
001b487e  4883f90a                 cmp rcx, 0xa
001b4882  7cec                     jl 0x1b4870
001b4884  498bd0                   mov rdx, r8
001b4887  4d8b4030                 mov r8, qword ptr [r8 + 0x30]
001b488b  4d85c0                   test r8, r8
001b488e  75c0                     jne 0x1b4850
001b4890  488b0d71d71700           mov rcx, qword ptr [rip + 0x17d771]
001b4897  488b01                   mov rax, qword ptr [rcx]
001b489a  ff5018                   call qword ptr [rax + 0x18]
001b489d  4c8bc0                   mov r8, rax
001b48a0  4885c0                   test rax, rax
001b48a3  0f8442ffffff             je 0x1b47eb
001b48a9  b8cdcccccc               mov eax, 0xcccccccd
001b48ae  f7e3                     mul ebx
001b48b0  8bc3                     mov eax, ebx
001b48b2  c1ea03                   shr edx, 3
001b48b5  8d0c92                   lea ecx, [rdx + rdx*4]
001b48b8  03c9                     add ecx, ecx
001b48ba  2bc1                     sub eax, ecx
001b48bc  41895c8004               mov dword ptr [r8 + rax*4 + 4], ebx
001b48c1  488b0d40d71700           mov rcx, qword ptr [rip + 0x17d740]
001b48c8  41b901000000             mov r9d, 1
001b48ce  4533c0                   xor r8d, r8d
001b48d1  8bd3                     mov edx, ebx
001b48d3  488b01                   mov rax, qword ptr [rcx]
001b48d6  ff5010                   call qword ptr [rax + 0x10]
001b48d9  40b701                   mov dil, 1
001b48dc  eb1b                     jmp 0x1b48f9
001b48de  4863c2                   movsxd rax, edx
001b48e1  ebd9                     jmp 0x1b48bc
001b48e3  43895c0104               mov dword ptr [r9 + r8 + 4], ebx
001b48e8  ebd7                     jmp 0x1b48c1
001b48ea  418bd1                   mov edx, r9d
001b48ed  e8eef7ffff               call 0x1b40e0
001b48f2  0fb6f8                   movzx edi, al
001b48f5  84c0                     test al, al
001b48f7  7430                     je 0x1b4929
001b48f9  488b0d08d71700           mov rcx, qword ptr [rip + 0x17d708]
001b4900  488b11                   mov rdx, qword ptr [rcx]
001b4903  ff12                     call qword ptr [rdx]
001b4905  f6803901000002           test byte ptr [rax + 0x139], 2
001b490c  7517                     jne 0x1b4925
001b490e  81fbc9090000             cmp ebx, 0x9c9
001b4914  740f                     je 0x1b4925
001b4916  448bc6                   mov r8d, esi
001b4919  8bd3                     mov edx, ebx
001b491b  b98e440000               mov ecx, 0x448e
001b4920  e8eb2c0000               call 0x1b7610
001b4925  400fb6c7                 movzx eax, dil
001b4929  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001b492e  488b742438               mov rsi, qword ptr [rsp + 0x38]
001b4933  4883c420                 add rsp, 0x20
001b4937  5f                       pop rdi
001b4938  c3                       ret
