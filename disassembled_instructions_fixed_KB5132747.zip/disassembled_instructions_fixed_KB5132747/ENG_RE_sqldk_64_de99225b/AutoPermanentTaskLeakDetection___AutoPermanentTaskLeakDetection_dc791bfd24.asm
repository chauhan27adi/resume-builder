; AutoPermanentTaskLeakDetection::~AutoPermanentTaskLeakDetection
; sqldk.dll, primary RVA 0x734e0, 598 bytes in 1 chunk(s)

; chunk at RVA 0x734e0 (598 bytes)
000734e0  4053                     push rbx
000734e2  4883ec20                 sub rsp, 0x20
000734e6  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000734ef  8b05db1a2a00             mov eax, dword ptr [rip + 0x2a1adb]
000734f5  8b1dbde3f8ff             mov ebx, dword ptr [rip - 0x71c43]
000734fb  48031cc1                 add rbx, qword ptr [rcx + rax*8]
000734ff  488b8b00010000           mov rcx, qword ptr [rbx + 0x100]
00073506  4885c9                   test rcx, rcx
00073509  750c                     jne 0x73517
0007350b  e85027fbff               call 0x25c60
00073510  488b8b00010000           mov rcx, qword ptr [rbx + 0x100]
00073517  488b8958020000           mov rcx, qword ptr [rcx + 0x258]
0007351e  488d1d5bda2a00           lea rbx, [rip + 0x2ada5b]
00073525  4533c9                   xor r9d, r9d
00073528  0f1f840000000000         nop dword ptr [rax + rax]
00073530  4e8b94c9c8010000         mov r10, qword ptr [rcx + r9*8 + 0x1c8]
00073538  458bd9                   mov r11d, r9d
0007353b  4d85d2                   test r10, r10
0007353e  744f                     je 0x7358f
00073540  498bc2                   mov rax, r10
00073543  4899                     cqo
00073545  81e2ff1f0000             and edx, 0x1fff
0007354b  4803c2                   add rax, rdx
0007354e  48c1f80d                 sar rax, 0xd
00073552  488bd0                   mov rdx, rax
00073555  4d69c380030000           imul r8, r11, 0x380
0007355c  48f7da                   neg rdx
0007355f  f0490fc1941848030000     lock xadd qword ptr [r8 + rbx + 0x348], rdx
00073569  f0490fc1841808010000     lock xadd qword ptr [r8 + rbx + 0x108], rax
00073573  4c2991b0010000           sub qword ptr [rcx + 0x1b0], r10
0007357a  4183f940                 cmp r9d, 0x40
0007357e  7408                     je 0x73588
00073580  4e2994c9c8010000         sub qword ptr [rcx + r9*8 + 0x1c8], r10
00073588  4c2991c0010000           sub qword ptr [rcx + 0x1c0], r10
0007358f  4183f93f                 cmp r9d, 0x3f
00073593  740e                     je 0x735a3
00073595  418d4101                 lea eax, [r9 + 1]
00073599  4c8b94c1c8010000         mov r10, qword ptr [rcx + rax*8 + 0x1c8]
000735a1  eb07                     jmp 0x735aa
000735a3  4c8b91b0010000           mov r10, qword ptr [rcx + 0x1b0]
000735aa  4d85d2                   test r10, r10
000735ad  7453                     je 0x73602
000735af  498bc2                   mov rax, r10
000735b2  458d5901                 lea r11d, [r9 + 1]
000735b6  4899                     cqo
000735b8  81e2ff1f0000             and edx, 0x1fff
000735be  4803c2                   add rax, rdx
000735c1  48c1f80d                 sar rax, 0xd
000735c5  488bd0                   mov rdx, rax
000735c8  4d69c380030000           imul r8, r11, 0x380
000735cf  48f7da                   neg rdx
000735d2  f0490fc1941848030000     lock xadd qword ptr [r8 + rbx + 0x348], rdx
000735dc  f0490fc1841808010000     lock xadd qword ptr [r8 + rbx + 0x108], rax
000735e6  4c2991b0010000           sub qword ptr [rcx + 0x1b0], r10
000735ed  4183f93f                 cmp r9d, 0x3f
000735f1  7408                     je 0x735fb
000735f3  4e2994d9c8010000         sub qword ptr [rcx + r11*8 + 0x1c8], r10
000735fb  4c2991c0010000           sub qword ptr [rcx + 0x1c0], r10
00073602  4183f93e                 cmp r9d, 0x3e
00073606  740e                     je 0x73616
00073608  418d4102                 lea eax, [r9 + 2]
0007360c  4c8b94c1c8010000         mov r10, qword ptr [rcx + rax*8 + 0x1c8]
00073614  eb07                     jmp 0x7361d
00073616  4c8b91b0010000           mov r10, qword ptr [rcx + 0x1b0]
0007361d  4d85d2                   test r10, r10
00073620  7453                     je 0x73675
00073622  498bc2                   mov rax, r10
00073625  458d5902                 lea r11d, [r9 + 2]
00073629  4899                     cqo
0007362b  81e2ff1f0000             and edx, 0x1fff
00073631  4803c2                   add rax, rdx
00073634  48c1f80d                 sar rax, 0xd
00073638  488bd0                   mov rdx, rax
0007363b  4d69c380030000           imul r8, r11, 0x380
00073642  48f7da                   neg rdx
00073645  f0490fc1941848030000     lock xadd qword ptr [r8 + rbx + 0x348], rdx
0007364f  f0490fc1841808010000     lock xadd qword ptr [r8 + rbx + 0x108], rax
00073659  4c2991b0010000           sub qword ptr [rcx + 0x1b0], r10
00073660  4183f93e                 cmp r9d, 0x3e
00073664  7408                     je 0x7366e
00073666  4e2994d9c8010000         sub qword ptr [rcx + r11*8 + 0x1c8], r10
0007366e  4c2991c0010000           sub qword ptr [rcx + 0x1c0], r10
00073675  4183f93d                 cmp r9d, 0x3d
00073679  740e                     je 0x73689
0007367b  418d4103                 lea eax, [r9 + 3]
0007367f  4c8b94c1c8010000         mov r10, qword ptr [rcx + rax*8 + 0x1c8]
00073687  eb07                     jmp 0x73690
00073689  4c8b91b0010000           mov r10, qword ptr [rcx + 0x1b0]
00073690  4d85d2                   test r10, r10
00073693  7453                     je 0x736e8
00073695  498bc2                   mov rax, r10
00073698  458d5903                 lea r11d, [r9 + 3]
0007369c  4899                     cqo
0007369e  81e2ff1f0000             and edx, 0x1fff
000736a4  4803c2                   add rax, rdx
000736a7  48c1f80d                 sar rax, 0xd
000736ab  488bd0                   mov rdx, rax
000736ae  4d69c380030000           imul r8, r11, 0x380
000736b5  48f7da                   neg rdx
000736b8  f0490fc1941848030000     lock xadd qword ptr [r8 + rbx + 0x348], rdx
000736c2  f0490fc1841808010000     lock xadd qword ptr [r8 + rbx + 0x108], rax
000736cc  4c2991b0010000           sub qword ptr [rcx + 0x1b0], r10
000736d3  4183f93d                 cmp r9d, 0x3d
000736d7  7408                     je 0x736e1
000736d9  4e2994d9c8010000         sub qword ptr [rcx + r11*8 + 0x1c8], r10
000736e1  4c2991c0010000           sub qword ptr [rcx + 0x1c0], r10
000736e8  4183c104                 add r9d, 4
000736ec  4183f940                 cmp r9d, 0x40
000736f0  0f823afeffff             jb 0x73530
000736f6  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000736ff  8b05cb182a00             mov eax, dword ptr [rip + 0x2a18cb]
00073705  8b1dade1f8ff             mov ebx, dword ptr [rip - 0x71e53]
0007370b  48031cc1                 add rbx, qword ptr [rcx + rax*8]
0007370f  488b8b00010000           mov rcx, qword ptr [rbx + 0x100]
00073716  4885c9                   test rcx, rcx
00073719  750c                     jne 0x73727
0007371b  e84025fbff               call 0x25c60
00073720  488b8b00010000           mov rcx, qword ptr [rbx + 0x100]
00073727  4533c0                   xor r8d, r8d
0007372a  33d2                     xor edx, edx
0007372c  4883c420                 add rsp, 0x20
00073730  5b                       pop rbx
00073731  e91afaf9ff               jmp 0x13150
