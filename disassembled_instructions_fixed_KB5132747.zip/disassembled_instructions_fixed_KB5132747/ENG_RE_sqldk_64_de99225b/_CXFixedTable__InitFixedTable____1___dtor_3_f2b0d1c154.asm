; `CXFixedTable::InitFixedTable'::`1'::dtor$3
; sqldk.dll, primary RVA 0x216d08, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216d08 (31 bytes)
00216d08  4055                     push rbp
00216d0a  4883ec20                 sub rsp, 0x20
00216d0e  488bea                   mov rbp, rdx
00216d11  4533c0                   xor r8d, r8d
00216d14  488b5558                 mov rdx, qword ptr [rbp + 0x58]
00216d18  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00216d1c  e8efa2deff               call 0x1010
00216d21  4883c420                 add rsp, 0x20
00216d25  5d                       pop rbp
00216d26  c3                       ret
