; CMemAligned<CMemDbg<CMemLargePageObj> >::~CMemAligned<CMemDbg<CMemLargePageObj> >
; sqldk.dll, primary RVA 0x112080, 37 bytes in 1 chunk(s)

; chunk at RVA 0x112080 (37 bytes)
00112080  48894c2408               mov qword ptr [rsp + 8], rcx
00112085  4883ec38                 sub rsp, 0x38
00112089  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00112092  488d05e7931300           lea rax, [rip + 0x1393e7]
00112099  488901                   mov qword ptr [rcx], rax
0011209c  4883c438                 add rsp, 0x38
001120a0  e99b180600               jmp 0x173940
