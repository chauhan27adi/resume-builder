; SOSHost_TaskAutoOnFlags::~SOSHost_TaskAutoOnFlags
; sqldk.dll, primary RVA 0x1605f0, 36 bytes in 1 chunk(s)

; chunk at RVA 0x1605f0 (36 bytes)
001605f0  48894c2408               mov qword ptr [rsp + 8], rcx
001605f5  4883ec18                 sub rsp, 0x18
001605f9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00160601  488b5108                 mov rdx, qword ptr [rcx + 8]
00160605  8b01                     mov eax, dword ptr [rcx]
00160607  f7d0                     not eax
00160609  218268020000             and dword ptr [rdx + 0x268], eax
0016060f  4883c418                 add rsp, 0x18
00160613  c3                       ret
