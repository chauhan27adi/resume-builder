; CMemDbg<PageHeapMemObj>::~CMemDbg<PageHeapMemObj>
; sqldk.dll, primary RVA 0x172400, 99 bytes in 1 chunk(s)

; chunk at RVA 0x172400 (99 bytes)
00172400  48894c2408               mov qword ptr [rsp + 8], rcx
00172405  53                       push rbx
00172406  4883ec30                 sub rsp, 0x30
0017240a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00172413  488bd9                   mov rbx, rcx
00172416  488d0553bf0d00           lea rax, [rip + 0xdbf53]
0017241d  488901                   mov qword ptr [rcx], rax
00172420  488d0591380f00           lea rax, [rip + 0xf3891]
00172427  48898190000000           mov qword ptr [rcx + 0x90], rax
0017242e  488d05ebc10d00           lea rax, [rip + 0xdc1eb]
00172435  488901                   mov qword ptr [rcx], rax
00172438  488d05c94d0d00           lea rax, [rip + 0xd4dc9]
0017243f  488901                   mov qword ptr [rcx], rax
00172442  4883c138                 add rcx, 0x38
00172446  e8a5f1e9ff               call 0x115f0
0017244b  90                       nop
0017244c  488d4b30                 lea rcx, [rbx + 0x30]
00172450  e89bf1e9ff               call 0x115f0
00172455  90                       nop
00172456  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0017245d  4883c430                 add rsp, 0x30
00172461  5b                       pop rbx
00172462  c3                       ret
