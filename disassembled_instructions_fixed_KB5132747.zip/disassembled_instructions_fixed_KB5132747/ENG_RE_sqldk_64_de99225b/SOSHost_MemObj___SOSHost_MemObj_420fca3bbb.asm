; SOSHost_MemObj::~SOSHost_MemObj
; sqldk.dll, primary RVA 0x6abc0, 28 bytes in 1 chunk(s)

; chunk at RVA 0x6abc0 (28 bytes)
0006abc0  48894c2408               mov qword ptr [rsp + 8], rcx
0006abc5  4883ec18                 sub rsp, 0x18
0006abc9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
0006abd1  c701adde0080             mov dword ptr [rcx], 0x8000dead
0006abd7  4883c418                 add rsp, 0x18
0006abdb  c3                       ret
