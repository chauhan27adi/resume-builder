; CMemThread<CMemFixed>::~CMemThread<CMemFixed>
; sqldk.dll, primary RVA 0xfc640, 111 bytes in 1 chunk(s)

; chunk at RVA 0xfc640 (111 bytes)
000fc640  48894c2408               mov qword ptr [rsp + 8], rcx
000fc645  53                       push rbx
000fc646  4883ec30                 sub rsp, 0x30
000fc64a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000fc653  488bd9                   mov rbx, rcx
000fc656  488d05ebd11400           lea rax, [rip + 0x14d1eb]
000fc65d  488901                   mov qword ptr [rcx], rax
000fc660  488d8108010000           lea rax, [rcx + 0x108]
000fc667  4889442448               mov qword ptr [rsp + 0x48], rax
000fc66c  488d0dcdd41300           lea rcx, [rip + 0x13d4cd]
000fc673  48894830                 mov qword ptr [rax + 0x30], rcx
000fc677  488908                   mov qword ptr [rax], rcx
000fc67a  488d0537aa1400           lea rax, [rip + 0x14aa37]
000fc681  488903                   mov qword ptr [rbx], rax
000fc684  488d057dab1400           lea rax, [rip + 0x14ab7d]
000fc68b  488903                   mov qword ptr [rbx], rax
000fc68e  488d4b38                 lea rcx, [rbx + 0x38]
000fc692  e8594ff1ff               call 0x115f0
000fc697  90                       nop
000fc698  488d4b30                 lea rcx, [rbx + 0x30]
000fc69c  e84f4ff1ff               call 0x115f0
000fc6a1  90                       nop
000fc6a2  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
000fc6a9  4883c430                 add rsp, 0x30
000fc6ad  5b                       pop rbx
000fc6ae  c3                       ret
