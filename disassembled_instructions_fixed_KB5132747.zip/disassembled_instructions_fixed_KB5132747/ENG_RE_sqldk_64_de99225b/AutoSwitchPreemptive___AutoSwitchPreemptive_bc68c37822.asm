; AutoSwitchPreemptive::~AutoSwitchPreemptive
; sqldk.dll, primary RVA 0xbee10, 83 bytes in 1 chunk(s)

; chunk at RVA 0xbee10 (83 bytes)
000bee10  48894c2408               mov qword ptr [rsp + 8], rcx
000bee15  53                       push rbx
000bee16  4883ec30                 sub rsp, 0x30
000bee1a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000bee23  488bd9                   mov rbx, rcx
000bee26  833900                   cmp dword ptr [rcx], 0
000bee29  742a                     je 0xbee55
000bee2b  488b5108                 mov rdx, qword ptr [rcx + 8]
000bee2f  488b8a60020000           mov rcx, qword ptr [rdx + 0x260]
000bee36  837b0400                 cmp dword ptr [rbx + 4], 0
000bee3a  740c                     je 0xbee48
000bee3c  818a2003000000080000     or dword ptr [rdx + 0x320], 0x800
000bee46  eb0d                     jmp 0xbee55
000bee48  488b01                   mov rax, qword ptr [rcx]
000bee4b  41b801000000             mov r8d, 1
000bee51  ff5010                   call qword ptr [rax + 0x10]
000bee54  90                       nop
000bee55  488d4b10                 lea rcx, [rbx + 0x10]
000bee59  4883c430                 add rsp, 0x30
000bee5d  5b                       pop rbx
000bee5e  e9ad5ff5ff               jmp 0x14e10
