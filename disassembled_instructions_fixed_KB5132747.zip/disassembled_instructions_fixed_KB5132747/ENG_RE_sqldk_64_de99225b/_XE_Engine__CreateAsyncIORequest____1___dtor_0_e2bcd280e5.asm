; `XE_Engine::CreateAsyncIORequest'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235630, 56 bytes in 1 chunk(s)

; chunk at RVA 0x235630 (56 bytes)
00235630  4055                     push rbp
00235632  4883ec30                 sub rsp, 0x30
00235636  488bea                   mov rbp, rdx
00235639  c644242806               mov byte ptr [rsp + 0x28], 6
0023563e  8b4558                   mov eax, dword ptr [rbp + 0x58]
00235641  89442420                 mov dword ptr [rsp + 0x20], eax
00235645  4c8d0d945b0400           lea r9, [rip + 0x45b94]
0023564c  41b801000000             mov r8d, 1
00235652  488b1567d01700           mov rdx, qword ptr [rip + 0x17d067]
00235659  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0023565d  e88e48faff               call 0x1d9ef0
00235662  4883c430                 add rsp, 0x30
00235666  5d                       pop rbp
00235667  c3                       ret
