; MemoryObjectFactory::WrapMemObject<CMemLargePageObj,CVariableInfo>
; sqldk.dll, primary RVA 0xca980, 5920 bytes in 1 chunk(s)

; chunk at RVA 0xca980 (5920 bytes)
000ca980  4c894c2420               mov qword ptr [rsp + 0x20], r9
000ca985  4c89442418               mov qword ptr [rsp + 0x18], r8
000ca98a  55                       push rbp
000ca98b  56                       push rsi
000ca98c  57                       push rdi
000ca98d  4154                     push r12
000ca98f  4155                     push r13
000ca991  4156                     push r14
000ca993  4157                     push r15
000ca995  488bec                   mov rbp, rsp
000ca998  4881ec80000000           sub rsp, 0x80
000ca99f  48c745c0feffffff         mov qword ptr [rbp - 0x40], 0xfffffffffffffffe
000ca9a7  48899c24c0000000         mov qword ptr [rsp + 0xc0], rbx
000ca9af  4d8be1                   mov r12, r9
000ca9b2  498bf0                   mov rsi, r8
000ca9b5  8bc2                     mov eax, edx
000ca9b7  488d154256f3ff           lea rdx, [rip - 0xca9be]
000ca9be  4c8bacc200273100         mov r13, qword ptr [rdx + rax*8 + 0x312700]
000ca9c6  4c896d60                 mov qword ptr [rbp + 0x60], r13
000ca9ca  8b7d78                   mov edi, dword ptr [rbp + 0x78]
000ca9cd  448bff                   mov r15d, edi
000ca9d0  4181e702002f01           and r15d, 0x12f0002
000ca9d7  4533f6                   xor r14d, r14d
000ca9da  418bde                   mov ebx, r14d
000ca9dd  83f92a                   cmp ecx, 0x2a
000ca9e0  0f87ee150000             ja 0xcbfd4
000ca9e6  4863c1                   movsxd rax, ecx
000ca9e9  8b8c82f4bf0c00           mov ecx, dword ptr [rdx + rax*4 + 0xcbff4]
000ca9f0  4803ca                   add rcx, rdx
000ca9f3  ffe1                     jmp rcx
000ca9f5  488bd6                   mov rdx, rsi
000ca9f8  b9c8010000               mov ecx, 0x1c8
000ca9fd  e87e78f4ff               call 0x12280
000caa02  488bd8                   mov rbx, rax
000caa05  48894560                 mov qword ptr [rbp + 0x60], rax
000caa09  4885c0                   test rax, rax
000caa0c  744b                     je 0xcaa59
000caa0e  c7400801000000           mov dword ptr [rax + 8], 1
000caa15  488d05ecc71700           lea rax, [rip + 0x17c7ec]
000caa1c  488903                   mov qword ptr [rbx], rax
000caa1f  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000caa27  44897318                 mov dword ptr [rbx + 0x18], r14d
000caa2b  4c897320                 mov qword ptr [rbx + 0x20], r14
000caa2f  44897328                 mov dword ptr [rbx + 0x28], r14d
000caa33  4c897330                 mov qword ptr [rbx + 0x30], r14
000caa37  4c897338                 mov qword ptr [rbx + 0x38], r14
000caa3b  4c897340                 mov qword ptr [rbx + 0x40], r14
000caa3f  4c897348                 mov qword ptr [rbx + 0x48], r14
000caa43  488d051ec51700           lea rax, [rip + 0x17c51e]
000caa4a  488903                   mov qword ptr [rbx], rax
000caa4d  488d05c4c31700           lea rax, [rip + 0x17c3c4]
000caa54  488903                   mov qword ptr [rbx], rax
000caa57  eb03                     jmp 0xcaa5c
000caa59  498bde                   mov rbx, r14
000caa5c  e9d9140000               jmp 0xcbf3a
000caa61  488bd6                   mov rdx, rsi
000caa64  b998050000               mov ecx, 0x598
000caa69  e81278f4ff               call 0x12280
000caa6e  488bd8                   mov rbx, rax
000caa71  48894560                 mov qword ptr [rbp + 0x60], rax
000caa75  4885c0                   test rax, rax
000caa78  7463                     je 0xcaadd
000caa7a  c7400801000000           mov dword ptr [rax + 8], 1
000caa81  488d0580c71700           lea rax, [rip + 0x17c780]
000caa88  488903                   mov qword ptr [rbx], rax
000caa8b  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000caa93  44897318                 mov dword ptr [rbx + 0x18], r14d
000caa97  4c897320                 mov qword ptr [rbx + 0x20], r14
000caa9b  44897328                 mov dword ptr [rbx + 0x28], r14d
000caa9f  4c897330                 mov qword ptr [rbx + 0x30], r14
000caaa3  4c897338                 mov qword ptr [rbx + 0x38], r14
000caaa7  4c897340                 mov qword ptr [rbx + 0x40], r14
000caaab  4c897348                 mov qword ptr [rbx + 0x48], r14
000caaaf  488d05b2c41700           lea rax, [rip + 0x17c4b2]
000caab6  488903                   mov qword ptr [rbx], rax
000caab9  488d0558c31700           lea rax, [rip + 0x17c358]
000caac0  488903                   mov qword ptr [rbx], rax
000caac3  488d058e241800           lea rax, [rip + 0x18248e]
000caaca  488903                   mov qword ptr [rbx], rax
000caacd  488d05e4b11900           lea rax, [rip + 0x19b1e4]
000caad4  488983d8010000           mov qword ptr [rbx + 0x1d8], rax
000caadb  eb03                     jmp 0xcaae0
000caadd  498bde                   mov rbx, r14
000caae0  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000caae9  8b05e1a42400             mov eax, dword ptr [rip + 0x24a4e1]
000caaef  448b35c26df3ff           mov r14d, dword ptr [rip - 0xc923e]
000caaf6  4c0334c1                 add r14, qword ptr [rcx + rax*8]
000caafa  498b8600010000           mov rax, qword ptr [r14 + 0x100]
000cab01  4885c0                   test rax, rax
000cab04  750e                     jne 0xcab14
000cab06  33c9                     xor ecx, ecx
000cab08  e853b1f5ff               call 0x25c60
000cab0d  498b8600010000           mov rax, qword ptr [r14 + 0x100]
000cab14  488b8058020000           mov rax, qword ptr [rax + 0x258]
000cab1b  488983c8010000           mov qword ptr [rbx + 0x1c8], rax
000cab22  c783d001000001000000     mov dword ptr [rbx + 0x1d0], 1
000cab2c  4489bbd4010000           mov dword ptr [rbx + 0x1d4], r15d
000cab33  4533f6                   xor r14d, r14d
000cab36  4489b380050000           mov dword ptr [rbx + 0x580], r14d
000cab3d  c1ef19                   shr edi, 0x19
000cab40  83e701                   and edi, 1
000cab43  89bb84050000             mov dword ptr [rbx + 0x584], edi
000cab49  4489b388050000           mov dword ptr [rbx + 0x588], r14d
000cab50  4c89b390050000           mov qword ptr [rbx + 0x590], r14
000cab57  488d8bd8010000           lea rcx, [rbx + 0x1d8]
000cab5e  4c8bcb                   mov r9, rbx
000cab61  458bc7                   mov r8d, r15d
000cab64  498bd5                   mov rdx, r13
000cab67  e834d80900               call 0x1683a0
000cab6c  e9cc130000               jmp 0xcbf3d
000cab71  488bd6                   mov rdx, rsi
000cab74  b940020000               mov ecx, 0x240
000cab79  e80277f4ff               call 0x12280
000cab7e  488bd8                   mov rbx, rax
000cab81  48894560                 mov qword ptr [rbp + 0x60], rax
000cab85  4885c0                   test rax, rax
000cab88  0f8493000000             je 0xcac21
000cab8e  c7400801000000           mov dword ptr [rax + 8], 1
000cab95  488d056cc61700           lea rax, [rip + 0x17c66c]
000cab9c  488903                   mov qword ptr [rbx], rax
000cab9f  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000caba7  44897318                 mov dword ptr [rbx + 0x18], r14d
000cabab  4c897320                 mov qword ptr [rbx + 0x20], r14
000cabaf  44897328                 mov dword ptr [rbx + 0x28], r14d
000cabb3  4c897330                 mov qword ptr [rbx + 0x30], r14
000cabb7  4c897338                 mov qword ptr [rbx + 0x38], r14
000cabbb  4c897340                 mov qword ptr [rbx + 0x40], r14
000cabbf  4c897348                 mov qword ptr [rbx + 0x48], r14
000cabc3  488d059ec31700           lea rax, [rip + 0x17c39e]
000cabca  488903                   mov qword ptr [rbx], rax
000cabcd  488d0544c21700           lea rax, [rip + 0x17c244]
000cabd4  488903                   mov qword ptr [rbx], rax
000cabd7  488d05721f1800           lea rax, [rip + 0x181f72]
000cabde  488903                   mov qword ptr [rbx], rax
000cabe1  488d8b08020000           lea rcx, [rbx + 0x208]
000cabe8  48894dc8                 mov qword ptr [rbp - 0x38], rcx
000cabec  488d4108                 lea rax, [rcx + 8]
000cabf0  48894008                 mov qword ptr [rax + 8], rax
000cabf4  488900                   mov qword ptr [rax], rax
000cabf7  4c897118                 mov qword ptr [rcx + 0x18], r14
000cabfb  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cac02  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cac09  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cac11  488d0528ef1600           lea rax, [rip + 0x16ef28]
000cac18  488901                   mov qword ptr [rcx], rax
000cac1b  4c897130                 mov qword ptr [rcx + 0x30], r14
000cac1f  eb03                     jmp 0xcac24
000cac21  498bde                   mov rbx, r14
000cac24  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000cac2b  0fb64844                 movzx ecx, byte ptr [rax + 0x44]
000cac2f  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000cac36  c683d001000000           mov byte ptr [rbx + 0x1d0], 0
000cac3d  c683d101000000           mov byte ptr [rbx + 0x1d1], 0
000cac44  c683d201000000           mov byte ptr [rbx + 0x1d2], 0
000cac4b  4489b3f8010000           mov dword ptr [rbx + 0x1f8], r14d
000cac52  48c783fc01000001000000   mov qword ptr [rbx + 0x1fc], 1
000cac5d  4489b304020000           mov dword ptr [rbx + 0x204], r14d
000cac64  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cac6b  0f1000                   movups xmm0, xmmword ptr [rax]
000cac6e  0f1183d8010000           movups xmmword ptr [rbx + 0x1d8], xmm0
000cac75  0f104810                 movups xmm1, xmmword ptr [rax + 0x10]
000cac79  0f118be8010000           movups xmmword ptr [rbx + 0x1e8], xmm1
000cac80  c683d301000001           mov byte ptr [rbx + 0x1d3], 1
000cac87  f683dc01000001           test byte ptr [rbx + 0x1dc], 1
000cac8e  0fb683d3010000           movzx eax, byte ptr [rbx + 0x1d3]
000cac95  410f45c6                 cmovne eax, r14d
000cac99  8883d3010000             mov byte ptr [rbx + 0x1d3], al
000cac9f  84c9                     test cl, cl
000caca1  0f8493120000             je 0xcbf3a
000caca7  488bcb                   mov rcx, rbx
000cacaa  e8d1940700               call 0x144180
000cacaf  e986120000               jmp 0xcbf3a
000cacb4  488bd6                   mov rdx, rsi
000cacb7  b9d0010000               mov ecx, 0x1d0
000cacbc  e8bf75f4ff               call 0x12280
000cacc1  488bf8                   mov rdi, rax
000cacc4  48894560                 mov qword ptr [rbp + 0x60], rax
000cacc8  4885c0                   test rax, rax
000caccb  745c                     je 0xcad29
000caccd  c7400801000000           mov dword ptr [rax + 8], 1
000cacd4  488d052dc51700           lea rax, [rip + 0x17c52d]
000cacdb  488907                   mov qword ptr [rdi], rax
000cacde  48c7471000200000         mov qword ptr [rdi + 0x10], 0x2000
000cace6  44897718                 mov dword ptr [rdi + 0x18], r14d
000cacea  4c897720                 mov qword ptr [rdi + 0x20], r14
000cacee  44897728                 mov dword ptr [rdi + 0x28], r14d
000cacf2  4c897730                 mov qword ptr [rdi + 0x30], r14
000cacf6  4c897738                 mov qword ptr [rdi + 0x38], r14
000cacfa  4c897740                 mov qword ptr [rdi + 0x40], r14
000cacfe  4c897748                 mov qword ptr [rdi + 0x48], r14
000cad02  488d055fc21700           lea rax, [rip + 0x17c25f]
000cad09  488907                   mov qword ptr [rdi], rax
000cad0c  488d0505c11700           lea rax, [rip + 0x17c105]
000cad13  488907                   mov qword ptr [rdi], rax
000cad16  488d05bb081800           lea rax, [rip + 0x1808bb]
000cad1d  488907                   mov qword ptr [rdi], rax
000cad20  4c89b7c8010000           mov qword ptr [rdi + 0x1c8], r14
000cad27  eb03                     jmp 0xcad2c
000cad29  498bfe                   mov rdi, r14
000cad2c  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cad33  0f1008                   movups xmm1, xmmword ptr [rax]
000cad36  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cad3a  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000cad3e  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cad42  66480f7eca               movq rdx, xmm1
000cad47  48c1ea20                 shr rdx, 0x20
000cad4b  f6c201                   test dl, 1
000cad4e  7564                     jne 0xcadb4
000cad50  81e22ffbffff             and edx, 0xfffffb2f
000cad56  81ca20020000             or edx, 0x220
000cad5c  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cad60  48c1e820                 shr rax, 0x20
000cad64  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000cad68  498bc8                   mov rcx, r8
000cad6b  48c1e920                 shr rcx, 0x20
000cad6f  49c1e810                 shr r8, 0x10
000cad73  89442438                 mov dword ptr [rsp + 0x38], eax
000cad77  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000cad7a  89442430                 mov dword ptr [rsp + 0x30], eax
000cad7e  894c2428                 mov dword ptr [rsp + 0x28], ecx
000cad82  664489442420             mov word ptr [rsp + 0x20], r8w
000cad88  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000cad8d  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000cad91  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000cad94  e8776bf4ff               call 0x11910
000cad99  488987c8010000           mov qword ptr [rdi + 0x1c8], rax
000cada0  4885c0                   test rax, rax
000cada3  0f95c0                   setne al
000cada6  498bde                   mov rbx, r14
000cada9  84c0                     test al, al
000cadab  480f45df                 cmovne rbx, rdi
000cadaf  e986110000               jmp 0xcbf3a
000cadb4  b001                     mov al, 1
000cadb6  498bde                   mov rbx, r14
000cadb9  84c0                     test al, al
000cadbb  480f45df                 cmovne rbx, rdi
000cadbf  e976110000               jmp 0xcbf3a
000cadc4  488bd6                   mov rdx, rsi
000cadc7  b9a0050000               mov ecx, 0x5a0
000cadcc  e8af74f4ff               call 0x12280
000cadd1  488bd8                   mov rbx, rax
000cadd4  48894560                 mov qword ptr [rbp + 0x60], rax
000cadd8  4885c0                   test rax, rax
000caddb  7474                     je 0xcae51
000caddd  c7400801000000           mov dword ptr [rax + 8], 1
000cade4  488d051dc41700           lea rax, [rip + 0x17c41d]
000cadeb  488903                   mov qword ptr [rbx], rax
000cadee  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000cadf6  44897318                 mov dword ptr [rbx + 0x18], r14d
000cadfa  4c897320                 mov qword ptr [rbx + 0x20], r14
000cadfe  44897328                 mov dword ptr [rbx + 0x28], r14d
000cae02  4c897330                 mov qword ptr [rbx + 0x30], r14
000cae06  4c897338                 mov qword ptr [rbx + 0x38], r14
000cae0a  4c897340                 mov qword ptr [rbx + 0x40], r14
000cae0e  4c897348                 mov qword ptr [rbx + 0x48], r14
000cae12  488d054fc11700           lea rax, [rip + 0x17c14f]
000cae19  488903                   mov qword ptr [rbx], rax
000cae1c  488d05f5bf1700           lea rax, [rip + 0x17bff5]
000cae23  488903                   mov qword ptr [rbx], rax
000cae26  488d052b211800           lea rax, [rip + 0x18212b]
000cae2d  488903                   mov qword ptr [rbx], rax
000cae30  488d0581ae1900           lea rax, [rip + 0x19ae81]
000cae37  488983d8010000           mov qword ptr [rbx + 0x1d8], rax
000cae3e  488d053b061800           lea rax, [rip + 0x18063b]
000cae45  488903                   mov qword ptr [rbx], rax
000cae48  4c89b398050000           mov qword ptr [rbx + 0x598], r14
000cae4f  eb03                     jmp 0xcae54
000cae51  498bde                   mov rbx, r14
000cae54  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cae5b  0f1008                   movups xmm1, xmmword ptr [rax]
000cae5e  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cae62  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000cae66  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cae6a  66480f7eca               movq rdx, xmm1
000cae6f  48c1ea20                 shr rdx, 0x20
000cae73  f6c201                   test dl, 1
000cae76  0f8564fcffff             jne 0xcaae0
000cae7c  81e22ffbffff             and edx, 0xfffffb2f
000cae82  81ca20020000             or edx, 0x220
000cae88  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cae8c  48c1e820                 shr rax, 0x20
000cae90  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000cae94  498bc8                   mov rcx, r8
000cae97  48c1e920                 shr rcx, 0x20
000cae9b  49c1e810                 shr r8, 0x10
000cae9f  89442438                 mov dword ptr [rsp + 0x38], eax
000caea3  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000caea6  89442430                 mov dword ptr [rsp + 0x30], eax
000caeaa  894c2428                 mov dword ptr [rsp + 0x28], ecx
000caeae  664489442420             mov word ptr [rsp + 0x20], r8w
000caeb4  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000caeb9  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000caebd  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000caec0  e84b6af4ff               call 0x11910
000caec5  48898398050000           mov qword ptr [rbx + 0x598], rax
000caecc  4885c0                   test rax, rax
000caecf  0f95c0                   setne al
000caed2  84c0                     test al, al
000caed4  0f8506fcffff             jne 0xcaae0
000caeda  498bde                   mov rbx, r14
000caedd  e9f2100000               jmp 0xcbfd4
000caee2  488bd6                   mov rdx, rsi
000caee5  b9a0020000               mov ecx, 0x2a0
000caeea  e89173f4ff               call 0x12280
000caeef  48894560                 mov qword ptr [rbp + 0x60], rax
000caef3  4885c0                   test rax, rax
000caef6  740d                     je 0xcaf05
000caef8  488bc8                   mov rcx, rax
000caefb  e800870400               call 0x113600
000caf00  488bd8                   mov rbx, rax
000caf03  eb03                     jmp 0xcaf08
000caf05  498bde                   mov rbx, r14
000caf08  e92d100000               jmp 0xcbf3a
000caf0d  488bd6                   mov rdx, rsi
000caf10  b918030000               mov ecx, 0x318
000caf15  e86673f4ff               call 0x12280
000caf1a  48894560                 mov qword ptr [rbp + 0x60], rax
000caf1e  4885c0                   test rax, rax
000caf21  740d                     je 0xcaf30
000caf23  488bc8                   mov rcx, rax
000caf26  e8c52c0000               call 0xcdbf0
000caf2b  488bd8                   mov rbx, rax
000caf2e  eb03                     jmp 0xcaf33
000caf30  498bde                   mov rbx, r14
000caf33  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000caf3a  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000caf3f  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000caf46  488bcb                   mov rcx, rbx
000caf49  e862000500               call 0x11afb0
000caf4e  e9e70f0000               jmp 0xcbf3a
000caf53  488bd6                   mov rdx, rsi
000caf56  b9a8020000               mov ecx, 0x2a8
000caf5b  e82073f4ff               call 0x12280
000caf60  48894560                 mov qword ptr [rbp + 0x60], rax
000caf64  4885c0                   test rax, rax
000caf67  740d                     je 0xcaf76
000caf69  488bc8                   mov rcx, rax
000caf6c  e8efc90400               call 0x117960
000caf71  488bf8                   mov rdi, rax
000caf74  eb03                     jmp 0xcaf79
000caf76  498bfe                   mov rdi, r14
000caf79  e9aefdffff               jmp 0xcad2c
000caf7e  488bd6                   mov rdx, rsi
000caf81  b918020000               mov ecx, 0x218
000caf86  e8f572f4ff               call 0x12280
000caf8b  488bd8                   mov rbx, rax
000caf8e  48894560                 mov qword ptr [rbp + 0x60], rax
000caf92  4885c0                   test rax, rax
000caf95  0f8484000000             je 0xcb01f
000caf9b  c7400801000000           mov dword ptr [rax + 8], 1
000cafa2  488d055fc21700           lea rax, [rip + 0x17c25f]
000cafa9  488903                   mov qword ptr [rbx], rax
000cafac  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000cafb4  44897318                 mov dword ptr [rbx + 0x18], r14d
000cafb8  4c897320                 mov qword ptr [rbx + 0x20], r14
000cafbc  44897328                 mov dword ptr [rbx + 0x28], r14d
000cafc0  4c897330                 mov qword ptr [rbx + 0x30], r14
000cafc4  4c897338                 mov qword ptr [rbx + 0x38], r14
000cafc8  4c897340                 mov qword ptr [rbx + 0x40], r14
000cafcc  4c897348                 mov qword ptr [rbx + 0x48], r14
000cafd0  488d0591bf1700           lea rax, [rip + 0x17bf91]
000cafd7  488903                   mov qword ptr [rbx], rax
000cafda  488d0537be1700           lea rax, [rip + 0x17be37]
000cafe1  488903                   mov qword ptr [rbx], rax
000cafe4  488d053dd81700           lea rax, [rip + 0x17d83d]
000cafeb  488903                   mov qword ptr [rbx], rax
000cafee  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000caff5  0f57c0                   xorps xmm0, xmm0
000caff8  33c0                     xor eax, eax
000caffa  0f1183d0010000           movups xmmword ptr [rbx + 0x1d0], xmm0
000cb001  0f1183e0010000           movups xmmword ptr [rbx + 0x1e0], xmm0
000cb008  0f1183f0010000           movups xmmword ptr [rbx + 0x1f0], xmm0
000cb00f  0f118300020000           movups xmmword ptr [rbx + 0x200], xmm0
000cb016  48898310020000           mov qword ptr [rbx + 0x210], rax
000cb01d  eb03                     jmp 0xcb022
000cb01f  498bde                   mov rbx, r14
000cb022  e9130f0000               jmp 0xcbf3a
000cb027  488bd6                   mov rdx, rsi
000cb02a  b920020000               mov ecx, 0x220
000cb02f  e84c72f4ff               call 0x12280
000cb034  488bf8                   mov rdi, rax
000cb037  48894560                 mov qword ptr [rbp + 0x60], rax
000cb03b  4885c0                   test rax, rax
000cb03e  0f8495000000             je 0xcb0d9
000cb044  c7400801000000           mov dword ptr [rax + 8], 1
000cb04b  488d05b6c11700           lea rax, [rip + 0x17c1b6]
000cb052  488907                   mov qword ptr [rdi], rax
000cb055  48c7471000200000         mov qword ptr [rdi + 0x10], 0x2000
000cb05d  44897718                 mov dword ptr [rdi + 0x18], r14d
000cb061  4c897720                 mov qword ptr [rdi + 0x20], r14
000cb065  44897728                 mov dword ptr [rdi + 0x28], r14d
000cb069  4c897730                 mov qword ptr [rdi + 0x30], r14
000cb06d  4c897738                 mov qword ptr [rdi + 0x38], r14
000cb071  4c897740                 mov qword ptr [rdi + 0x40], r14
000cb075  4c897748                 mov qword ptr [rdi + 0x48], r14
000cb079  488d05e8be1700           lea rax, [rip + 0x17bee8]
000cb080  488907                   mov qword ptr [rdi], rax
000cb083  488d058ebd1700           lea rax, [rip + 0x17bd8e]
000cb08a  488907                   mov qword ptr [rdi], rax
000cb08d  488d0544051800           lea rax, [rip + 0x180544]
000cb094  488907                   mov qword ptr [rdi], rax
000cb097  4c89b7c8010000           mov qword ptr [rdi + 0x1c8], r14
000cb09e  488d057bd31700           lea rax, [rip + 0x17d37b]
000cb0a5  488907                   mov qword ptr [rdi], rax
000cb0a8  4c89b7d0010000           mov qword ptr [rdi + 0x1d0], r14
000cb0af  0f57c0                   xorps xmm0, xmm0
000cb0b2  33c0                     xor eax, eax
000cb0b4  0f1187d8010000           movups xmmword ptr [rdi + 0x1d8], xmm0
000cb0bb  0f1187e8010000           movups xmmword ptr [rdi + 0x1e8], xmm0
000cb0c2  0f1187f8010000           movups xmmword ptr [rdi + 0x1f8], xmm0
000cb0c9  0f118708020000           movups xmmword ptr [rdi + 0x208], xmm0
000cb0d0  48898718020000           mov qword ptr [rdi + 0x218], rax
000cb0d7  eb03                     jmp 0xcb0dc
000cb0d9  498bfe                   mov rdi, r14
000cb0dc  e94bfcffff               jmp 0xcad2c
000cb0e1  488bd6                   mov rdx, rsi
000cb0e4  b970060000               mov ecx, 0x670
000cb0e9  e89271f4ff               call 0x12280
000cb0ee  48894560                 mov qword ptr [rbp + 0x60], rax
000cb0f2  4885c0                   test rax, rax
000cb0f5  740d                     je 0xcb104
000cb0f7  488bc8                   mov rcx, rax
000cb0fa  e811a60400               call 0x115710
000cb0ff  488bd8                   mov rbx, rax
000cb102  eb03                     jmp 0xcb107
000cb104  498bde                   mov rbx, r14
000cb107  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000cb10e  c783d001000001000000     mov dword ptr [rbx + 0x1d0], 1
000cb118  4489bbd4010000           mov dword ptr [rbx + 0x1d4], r15d
000cb11f  4c89b380050000           mov qword ptr [rbx + 0x580], r14
000cb126  4489b388050000           mov dword ptr [rbx + 0x588], r14d
000cb12d  4c89b390050000           mov qword ptr [rbx + 0x590], r14
000cb134  488d8bd8010000           lea rcx, [rbx + 0x1d8]
000cb13b  4c8bcb                   mov r9, rbx
000cb13e  458bc7                   mov r8d, r15d
000cb141  498bd5                   mov rdx, r13
000cb144  e857d20900               call 0x1683a0
000cb149  e9ec0d0000               jmp 0xcbf3a
000cb14e  488bd6                   mov rdx, rsi
000cb151  b978060000               mov ecx, 0x678
000cb156  e82571f4ff               call 0x12280
000cb15b  48894560                 mov qword ptr [rbp + 0x60], rax
000cb15f  4885c0                   test rax, rax
000cb162  740d                     je 0xcb171
000cb164  488bc8                   mov rcx, rax
000cb167  e8e4ea0400               call 0x119c50
000cb16c  488bd8                   mov rbx, rax
000cb16f  eb03                     jmp 0xcb174
000cb171  498bde                   mov rbx, r14
000cb174  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cb17b  0f1008                   movups xmm1, xmmword ptr [rax]
000cb17e  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cb182  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000cb186  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cb18a  66480f7eca               movq rdx, xmm1
000cb18f  48c1ea20                 shr rdx, 0x20
000cb193  f6c201                   test dl, 1
000cb196  0f856bffffff             jne 0xcb107
000cb19c  81e22ffbffff             and edx, 0xfffffb2f
000cb1a2  81ca20020000             or edx, 0x220
000cb1a8  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cb1ac  48c1e820                 shr rax, 0x20
000cb1b0  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000cb1b4  498bc8                   mov rcx, r8
000cb1b7  48c1e920                 shr rcx, 0x20
000cb1bb  49c1e810                 shr r8, 0x10
000cb1bf  89442438                 mov dword ptr [rsp + 0x38], eax
000cb1c3  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000cb1c6  89442430                 mov dword ptr [rsp + 0x30], eax
000cb1ca  894c2428                 mov dword ptr [rsp + 0x28], ecx
000cb1ce  664489442420             mov word ptr [rsp + 0x20], r8w
000cb1d4  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000cb1d9  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000cb1dd  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000cb1e0  e82b67f4ff               call 0x11910
000cb1e5  48898398050000           mov qword ptr [rbx + 0x598], rax
000cb1ec  4885c0                   test rax, rax
000cb1ef  0f95c0                   setne al
000cb1f2  84c0                     test al, al
000cb1f4  0f850dffffff             jne 0xcb107
000cb1fa  498bde                   mov rbx, r14
000cb1fd  e9d20d0000               jmp 0xcbfd4
000cb202  488bd6                   mov rdx, rsi
000cb205  b9e8050000               mov ecx, 0x5e8
000cb20a  e87170f4ff               call 0x12280
000cb20f  488bd8                   mov rbx, rax
000cb212  48894560                 mov qword ptr [rbp + 0x60], rax
000cb216  4885c0                   test rax, rax
000cb219  0f849c000000             je 0xcb2bb
000cb21f  c7400801000000           mov dword ptr [rax + 8], 1
000cb226  488d05dbbf1700           lea rax, [rip + 0x17bfdb]
000cb22d  488903                   mov qword ptr [rbx], rax
000cb230  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000cb238  44897318                 mov dword ptr [rbx + 0x18], r14d
000cb23c  4c897320                 mov qword ptr [rbx + 0x20], r14
000cb240  44897328                 mov dword ptr [rbx + 0x28], r14d
000cb244  4c897330                 mov qword ptr [rbx + 0x30], r14
000cb248  4c897338                 mov qword ptr [rbx + 0x38], r14
000cb24c  4c897340                 mov qword ptr [rbx + 0x40], r14
000cb250  4c897348                 mov qword ptr [rbx + 0x48], r14
000cb254  488d050dbd1700           lea rax, [rip + 0x17bd0d]
000cb25b  488903                   mov qword ptr [rbx], rax
000cb25e  488d05b3bb1700           lea rax, [rip + 0x17bbb3]
000cb265  488903                   mov qword ptr [rbx], rax
000cb268  488d05e91c1800           lea rax, [rip + 0x181ce9]
000cb26f  488903                   mov qword ptr [rbx], rax
000cb272  488d053faa1900           lea rax, [rip + 0x19aa3f]
000cb279  488983d8010000           mov qword ptr [rbx + 0x1d8], rax
000cb280  488d05f1d21700           lea rax, [rip + 0x17d2f1]
000cb287  488903                   mov qword ptr [rbx], rax
000cb28a  4c89b398050000           mov qword ptr [rbx + 0x598], r14
000cb291  0f57c0                   xorps xmm0, xmm0
000cb294  33c0                     xor eax, eax
000cb296  0f1183a0050000           movups xmmword ptr [rbx + 0x5a0], xmm0
000cb29d  0f1183b0050000           movups xmmword ptr [rbx + 0x5b0], xmm0
000cb2a4  0f1183c0050000           movups xmmword ptr [rbx + 0x5c0], xmm0
000cb2ab  0f1183d0050000           movups xmmword ptr [rbx + 0x5d0], xmm0
000cb2b2  488983e0050000           mov qword ptr [rbx + 0x5e0], rax
000cb2b9  eb03                     jmp 0xcb2be
000cb2bb  498bde                   mov rbx, r14
000cb2be  e91df8ffff               jmp 0xcaae0
000cb2c3  488bd6                   mov rdx, rsi
000cb2c6  b9f0050000               mov ecx, 0x5f0
000cb2cb  e8b06ff4ff               call 0x12280
000cb2d0  488bd8                   mov rbx, rax
000cb2d3  48894560                 mov qword ptr [rbp + 0x60], rax
000cb2d7  4885c0                   test rax, rax
000cb2da  0f84ad000000             je 0xcb38d
000cb2e0  c7400801000000           mov dword ptr [rax + 8], 1
000cb2e7  488d051abf1700           lea rax, [rip + 0x17bf1a]
000cb2ee  488903                   mov qword ptr [rbx], rax
000cb2f1  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000cb2f9  44897318                 mov dword ptr [rbx + 0x18], r14d
000cb2fd  4c897320                 mov qword ptr [rbx + 0x20], r14
000cb301  44897328                 mov dword ptr [rbx + 0x28], r14d
000cb305  4c897330                 mov qword ptr [rbx + 0x30], r14
000cb309  4c897338                 mov qword ptr [rbx + 0x38], r14
000cb30d  4c897340                 mov qword ptr [rbx + 0x40], r14
000cb311  4c897348                 mov qword ptr [rbx + 0x48], r14
000cb315  488d054cbc1700           lea rax, [rip + 0x17bc4c]
000cb31c  488903                   mov qword ptr [rbx], rax
000cb31f  488d05f2ba1700           lea rax, [rip + 0x17baf2]
000cb326  488903                   mov qword ptr [rbx], rax
000cb329  488d05281c1800           lea rax, [rip + 0x181c28]
000cb330  488903                   mov qword ptr [rbx], rax
000cb333  488d057ea91900           lea rax, [rip + 0x19a97e]
000cb33a  488983d8010000           mov qword ptr [rbx + 0x1d8], rax
000cb341  488d0538011800           lea rax, [rip + 0x180138]
000cb348  488903                   mov qword ptr [rbx], rax
000cb34b  4c89b398050000           mov qword ptr [rbx + 0x598], r14
000cb352  488d0517ce1700           lea rax, [rip + 0x17ce17]
000cb359  488903                   mov qword ptr [rbx], rax
000cb35c  4c89b3a0050000           mov qword ptr [rbx + 0x5a0], r14
000cb363  0f57c0                   xorps xmm0, xmm0
000cb366  33c0                     xor eax, eax
000cb368  0f1183a8050000           movups xmmword ptr [rbx + 0x5a8], xmm0
000cb36f  0f1183b8050000           movups xmmword ptr [rbx + 0x5b8], xmm0
000cb376  0f1183c8050000           movups xmmword ptr [rbx + 0x5c8], xmm0
000cb37d  0f1183d8050000           movups xmmword ptr [rbx + 0x5d8], xmm0
000cb384  488983e8050000           mov qword ptr [rbx + 0x5e8], rax
000cb38b  eb03                     jmp 0xcb390
000cb38d  498bde                   mov rbx, r14
000cb390  e9bffaffff               jmp 0xcae54
000cb395  488bd6                   mov rdx, rsi
000cb398  b9f0020000               mov ecx, 0x2f0
000cb39d  e8de6ef4ff               call 0x12280
000cb3a2  488bd8                   mov rbx, rax
000cb3a5  48894560                 mov qword ptr [rbp + 0x60], rax
000cb3a9  4885c0                   test rax, rax
000cb3ac  7444                     je 0xcb3f2
000cb3ae  488bc8                   mov rcx, rax
000cb3b1  e84a820400               call 0x113600
000cb3b6  90                       nop
000cb3b7  488d050acf1700           lea rax, [rip + 0x17cf0a]
000cb3be  488903                   mov qword ptr [rbx], rax
000cb3c1  4c89b3a0020000           mov qword ptr [rbx + 0x2a0], r14
000cb3c8  0f57c0                   xorps xmm0, xmm0
000cb3cb  33c0                     xor eax, eax
000cb3cd  0f1183a8020000           movups xmmword ptr [rbx + 0x2a8], xmm0
000cb3d4  0f1183b8020000           movups xmmword ptr [rbx + 0x2b8], xmm0
000cb3db  0f1183c8020000           movups xmmword ptr [rbx + 0x2c8], xmm0
000cb3e2  0f1183d8020000           movups xmmword ptr [rbx + 0x2d8], xmm0
000cb3e9  488983e8020000           mov qword ptr [rbx + 0x2e8], rax
000cb3f0  eb03                     jmp 0xcb3f5
000cb3f2  498bde                   mov rbx, r14
000cb3f5  e9400b0000               jmp 0xcbf3a
000cb3fa  488bd6                   mov rdx, rsi
000cb3fd  b9f8020000               mov ecx, 0x2f8
000cb402  e8796ef4ff               call 0x12280
000cb407  488bf8                   mov rdi, rax
000cb40a  48894560                 mov qword ptr [rbp + 0x60], rax
000cb40e  4885c0                   test rax, rax
000cb411  7444                     je 0xcb457
000cb413  488bc8                   mov rcx, rax
000cb416  e845c50400               call 0x117960
000cb41b  90                       nop
000cb41c  488d058d931900           lea rax, [rip + 0x19938d]
000cb423  488907                   mov qword ptr [rdi], rax
000cb426  4c89b7a8020000           mov qword ptr [rdi + 0x2a8], r14
000cb42d  0f57c0                   xorps xmm0, xmm0
000cb430  33c0                     xor eax, eax
000cb432  0f1187b0020000           movups xmmword ptr [rdi + 0x2b0], xmm0
000cb439  0f1187c0020000           movups xmmword ptr [rdi + 0x2c0], xmm0
000cb440  0f1187d0020000           movups xmmword ptr [rdi + 0x2d0], xmm0
000cb447  0f1187e0020000           movups xmmword ptr [rdi + 0x2e0], xmm0
000cb44e  488987f0020000           mov qword ptr [rdi + 0x2f0], rax
000cb455  eb03                     jmp 0xcb45a
000cb457  498bfe                   mov rdi, r14
000cb45a  e9cdf8ffff               jmp 0xcad2c
000cb45f  488bd6                   mov rdx, rsi
000cb462  b9c0060000               mov ecx, 0x6c0
000cb467  e8146ef4ff               call 0x12280
000cb46c  488bd8                   mov rbx, rax
000cb46f  48894560                 mov qword ptr [rbp + 0x60], rax
000cb473  4885c0                   test rax, rax
000cb476  7444                     je 0xcb4bc
000cb478  488bc8                   mov rcx, rax
000cb47b  e890a20400               call 0x115710
000cb480  90                       nop
000cb481  488d0580941900           lea rax, [rip + 0x199480]
000cb488  488903                   mov qword ptr [rbx], rax
000cb48b  4c89b370060000           mov qword ptr [rbx + 0x670], r14
000cb492  0f57c0                   xorps xmm0, xmm0
000cb495  33c0                     xor eax, eax
000cb497  0f118378060000           movups xmmword ptr [rbx + 0x678], xmm0
000cb49e  0f118388060000           movups xmmword ptr [rbx + 0x688], xmm0
000cb4a5  0f118398060000           movups xmmword ptr [rbx + 0x698], xmm0
000cb4ac  0f1183a8060000           movups xmmword ptr [rbx + 0x6a8], xmm0
000cb4b3  488983b8060000           mov qword ptr [rbx + 0x6b8], rax
000cb4ba  eb03                     jmp 0xcb4bf
000cb4bc  498bde                   mov rbx, r14
000cb4bf  e943fcffff               jmp 0xcb107
000cb4c4  488bd6                   mov rdx, rsi
000cb4c7  b9c8060000               mov ecx, 0x6c8
000cb4cc  e8af6df4ff               call 0x12280
000cb4d1  488bd8                   mov rbx, rax
000cb4d4  48894560                 mov qword ptr [rbp + 0x60], rax
000cb4d8  4885c0                   test rax, rax
000cb4db  7444                     je 0xcb521
000cb4dd  488bc8                   mov rcx, rax
000cb4e0  e86be70400               call 0x119c50
000cb4e5  90                       nop
000cb4e6  488d056b911900           lea rax, [rip + 0x19916b]
000cb4ed  488903                   mov qword ptr [rbx], rax
000cb4f0  4c89b378060000           mov qword ptr [rbx + 0x678], r14
000cb4f7  0f57c0                   xorps xmm0, xmm0
000cb4fa  33c0                     xor eax, eax
000cb4fc  0f118380060000           movups xmmword ptr [rbx + 0x680], xmm0
000cb503  0f118390060000           movups xmmword ptr [rbx + 0x690], xmm0
000cb50a  0f1183a0060000           movups xmmword ptr [rbx + 0x6a0], xmm0
000cb511  0f1183b0060000           movups xmmword ptr [rbx + 0x6b0], xmm0
000cb518  488983c0060000           mov qword ptr [rbx + 0x6c0], rax
000cb51f  eb03                     jmp 0xcb524
000cb521  498bde                   mov rbx, r14
000cb524  e94bfcffff               jmp 0xcb174
000cb529  488bd6                   mov rdx, rsi
000cb52c  b968030000               mov ecx, 0x368
000cb531  e84a6df4ff               call 0x12280
000cb536  488bd8                   mov rbx, rax
000cb539  48894560                 mov qword ptr [rbp + 0x60], rax
000cb53d  4885c0                   test rax, rax
000cb540  7453                     je 0xcb595
000cb542  488bc8                   mov rcx, rax
000cb545  e8b6800400               call 0x113600
000cb54a  90                       nop
000cb54b  488d054e131800           lea rax, [rip + 0x18134e]
000cb552  488903                   mov qword ptr [rbx], rax
000cb555  488d8b30030000           lea rcx, [rbx + 0x330]
000cb55c  48894dc8                 mov qword ptr [rbp - 0x38], rcx
000cb560  488d4108                 lea rax, [rcx + 8]
000cb564  48894008                 mov qword ptr [rax + 8], rax
000cb568  488900                   mov qword ptr [rax], rax
000cb56b  4c897118                 mov qword ptr [rcx + 0x18], r14
000cb56f  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cb576  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cb57d  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cb585  488d05b4e51600           lea rax, [rip + 0x16e5b4]
000cb58c  488901                   mov qword ptr [rcx], rax
000cb58f  4c897130                 mov qword ptr [rcx + 0x30], r14
000cb593  eb03                     jmp 0xcb598
000cb595  498bde                   mov rbx, r14
000cb598  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000cb59f  418b4504                 mov eax, dword ptr [r13 + 4]
000cb5a3  2573020000               and eax, 0x273
000cb5a8  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000cb5af  83f802                   cmp eax, 2
000cb5b2  7527                     jne 0xcb5db
000cb5b4  803d7d68260000           cmp byte ptr [rip + 0x26687d], 0
000cb5bb  741e                     je 0xcb5db
000cb5bd  8b0529952400             mov eax, dword ptr [rip + 0x249529]
000cb5c3  83f801                   cmp eax, 1
000cb5c6  7613                     jbe 0xcb5db
000cb5c8  c783c002000001000000     mov dword ptr [rbx + 0x2c0], 1
000cb5d2  448b3d13952400           mov r15d, dword ptr [rip + 0x249513]
000cb5d9  eb12                     jmp 0xcb5ed
000cb5db  4489b3c0020000           mov dword ptr [rbx + 0x2c0], r14d
000cb5e2  418bcc                   mov ecx, r12d
000cb5e5  e8f6410700               call 0x13f7e0
000cb5ea  448bf8                   mov r15d, eax
000cb5ed  418bc7                   mov eax, r15d
000cb5f0  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cb5f8  4883e2f0                 and rdx, 0xfffffffffffffff0
000cb5fc  4c89b3a0020000           mov qword ptr [rbx + 0x2a0], r14
000cb603  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cb607  0f87a1000000             ja 0xcb6ae
000cb60d  0faee8                   lfence
000cb610  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb614  48c1e00d                 shl rax, 0xd
000cb618  4881faa01f0000           cmp rdx, 0x1fa0
000cb61f  762d                     jbe 0xcb64e
000cb621  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cb626  4c8bca                   mov r9, rdx
000cb629  4c8bc2                   mov r8, rdx
000cb62c  498bce                   mov rcx, r14
000cb62f  e8bcc2f3ff               call 0x78f0
000cb634  66ff4614                 inc word ptr [rsi + 0x14]
000cb638  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb63c  48c1e00d                 shl rax, 0xd
000cb640  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cb645  8b4808                   mov ecx, dword ptr [rax + 8]
000cb648  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cb64c  eb52                     jmp 0xcb6a0
000cb64e  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cb653  418b4608                 mov eax, dword ptr [r14 + 8]
000cb657  483bc2                   cmp rax, rdx
000cb65a  7311                     jae 0xcb66d
000cb65c  0f1f00                   nop dword ptr [rax]
000cb65f  90                       nop
000cb660  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cb664  418b4608                 mov eax, dword ptr [r14 + 8]
000cb668  483bc2                   cmp rax, rdx
000cb66b  72f3                     jb 0xcb660
000cb66d  418b7e08                 mov edi, dword ptr [r14 + 8]
000cb671  4c8bca                   mov r9, rdx
000cb674  41b820000000             mov r8d, 0x20
000cb67a  498bce                   mov rcx, r14
000cb67d  e86ec2f3ff               call 0x78f0
000cb682  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cb686  7514                     jne 0xcb69c
000cb688  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb68c  48c1e00d                 shl rax, 0xd
000cb690  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cb695  8b4808                   mov ecx, dword ptr [rax + 8]
000cb698  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cb69c  66ff4614                 inc word ptr [rsi + 0x14]
000cb6a0  498d4610                 lea rax, [r14 + 0x10]
000cb6a4  488983a0020000           mov qword ptr [rbx + 0x2a0], rax
000cb6ab  4533f6                   xor r14d, r14d
000cb6ae  4c896c2420               mov qword ptr [rsp + 0x20], r13
000cb6b3  458bcf                   mov r9d, r15d
000cb6b6  458bc4                   mov r8d, r12d
000cb6b9  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000cb6c0  488bcb                   mov rcx, rbx
000cb6c3  e8d8910700               call 0x1448a0
000cb6c8  85c0                     test eax, eax
000cb6ca  0f8566080000             jne 0xcbf36
000cb6d0  498bde                   mov rbx, r14
000cb6d3  e9fc080000               jmp 0xcbfd4
000cb6d8  488bd6                   mov rdx, rsi
000cb6db  b970030000               mov ecx, 0x370
000cb6e0  e89b6bf4ff               call 0x12280
000cb6e5  488bd8                   mov rbx, rax
000cb6e8  48894560                 mov qword ptr [rbp + 0x60], rax
000cb6ec  4885c0                   test rax, rax
000cb6ef  7453                     je 0xcb744
000cb6f1  488bc8                   mov rcx, rax
000cb6f4  e867c20400               call 0x117960
000cb6f9  90                       nop
000cb6fa  488d05f7121800           lea rax, [rip + 0x1812f7]
000cb701  488903                   mov qword ptr [rbx], rax
000cb704  488d8b38030000           lea rcx, [rbx + 0x338]
000cb70b  48894dc8                 mov qword ptr [rbp - 0x38], rcx
000cb70f  488d4108                 lea rax, [rcx + 8]
000cb713  48894008                 mov qword ptr [rax + 8], rax
000cb717  488900                   mov qword ptr [rax], rax
000cb71a  4c897118                 mov qword ptr [rcx + 0x18], r14
000cb71e  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cb725  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cb72c  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cb734  488d0505e41600           lea rax, [rip + 0x16e405]
000cb73b  488901                   mov qword ptr [rcx], rax
000cb73e  4c897130                 mov qword ptr [rcx + 0x30], r14
000cb742  eb03                     jmp 0xcb747
000cb744  498bde                   mov rbx, r14
000cb747  4c8bbd90000000           mov r15, qword ptr [rbp + 0x90]
000cb74e  418b4704                 mov eax, dword ptr [r15 + 4]
000cb752  2573020000               and eax, 0x273
000cb757  448bad88000000           mov r13d, dword ptr [rbp + 0x88]
000cb75e  83f802                   cmp eax, 2
000cb761  7527                     jne 0xcb78a
000cb763  803dce66260000           cmp byte ptr [rip + 0x2666ce], 0
000cb76a  741e                     je 0xcb78a
000cb76c  8b057a932400             mov eax, dword ptr [rip + 0x24937a]
000cb772  83f801                   cmp eax, 1
000cb775  7613                     jbe 0xcb78a
000cb777  c783c802000001000000     mov dword ptr [rbx + 0x2c8], 1
000cb781  448b2564932400           mov r12d, dword ptr [rip + 0x249364]
000cb788  eb12                     jmp 0xcb79c
000cb78a  4489b3c8020000           mov dword ptr [rbx + 0x2c8], r14d
000cb791  418bcd                   mov ecx, r13d
000cb794  e847400700               call 0x13f7e0
000cb799  448be0                   mov r12d, eax
000cb79c  418bc4                   mov eax, r12d
000cb79f  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cb7a7  4883e2f0                 and rdx, 0xfffffffffffffff0
000cb7ab  4c89b3a8020000           mov qword ptr [rbx + 0x2a8], r14
000cb7b2  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cb7b6  0f87a2000000             ja 0xcb85e
000cb7bc  0faee8                   lfence
000cb7bf  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb7c3  48c1e00d                 shl rax, 0xd
000cb7c7  4881faa01f0000           cmp rdx, 0x1fa0
000cb7ce  762d                     jbe 0xcb7fd
000cb7d0  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cb7d5  4c8bca                   mov r9, rdx
000cb7d8  4c8bc2                   mov r8, rdx
000cb7db  498bce                   mov rcx, r14
000cb7de  e80dc1f3ff               call 0x78f0
000cb7e3  66ff4614                 inc word ptr [rsi + 0x14]
000cb7e7  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb7eb  48c1e00d                 shl rax, 0xd
000cb7ef  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cb7f4  8b4808                   mov ecx, dword ptr [rax + 8]
000cb7f7  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cb7fb  eb53                     jmp 0xcb850
000cb7fd  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cb802  418b4608                 mov eax, dword ptr [r14 + 8]
000cb806  483bc2                   cmp rax, rdx
000cb809  7312                     jae 0xcb81d
000cb80b  0f1f0400                 nop dword ptr [rax + rax]
000cb80f  90                       nop
000cb810  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cb814  418b4608                 mov eax, dword ptr [r14 + 8]
000cb818  483bc2                   cmp rax, rdx
000cb81b  72f3                     jb 0xcb810
000cb81d  418b7e08                 mov edi, dword ptr [r14 + 8]
000cb821  4c8bca                   mov r9, rdx
000cb824  41b820000000             mov r8d, 0x20
000cb82a  498bce                   mov rcx, r14
000cb82d  e8bec0f3ff               call 0x78f0
000cb832  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cb836  7514                     jne 0xcb84c
000cb838  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb83c  48c1e00d                 shl rax, 0xd
000cb840  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cb845  8b4808                   mov ecx, dword ptr [rax + 8]
000cb848  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cb84c  66ff4614                 inc word ptr [rsi + 0x14]
000cb850  498d4610                 lea rax, [r14 + 0x10]
000cb854  488983a8020000           mov qword ptr [rbx + 0x2a8], rax
000cb85b  4533f6                   xor r14d, r14d
000cb85e  4c897c2420               mov qword ptr [rsp + 0x20], r15
000cb863  458bcc                   mov r9d, r12d
000cb866  458bc5                   mov r8d, r13d
000cb869  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000cb870  488bcb                   mov rcx, rbx
000cb873  e888980700               call 0x145100
000cb878  85c0                     test eax, eax
000cb87a  0f847af9ffff             je 0xcb1fa
000cb880  410f100f                 movups xmm1, xmmword ptr [r15]
000cb884  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cb888  410f104710               movups xmm0, xmmword ptr [r15 + 0x10]
000cb88d  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cb891  66480f7eca               movq rdx, xmm1
000cb896  48c1ea20                 shr rdx, 0x20
000cb89a  f6c201                   test dl, 1
000cb89d  0f8593060000             jne 0xcbf36
000cb8a3  81e22ffbffff             and edx, 0xfffffb2f
000cb8a9  81ca20020000             or edx, 0x220
000cb8af  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cb8b3  48c1e820                 shr rax, 0x20
000cb8b7  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000cb8bb  498bc8                   mov rcx, r8
000cb8be  48c1e920                 shr rcx, 0x20
000cb8c2  49c1e810                 shr r8, 0x10
000cb8c6  89442438                 mov dword ptr [rsp + 0x38], eax
000cb8ca  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000cb8cd  89442430                 mov dword ptr [rsp + 0x30], eax
000cb8d1  894c2428                 mov dword ptr [rsp + 0x28], ecx
000cb8d5  664489442420             mov word ptr [rsp + 0x20], r8w
000cb8db  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000cb8e0  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000cb8e4  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000cb8e7  e82460f4ff               call 0x11910
000cb8ec  488983c8010000           mov qword ptr [rbx + 0x1c8], rax
000cb8f3  4885c0                   test rax, rax
000cb8f6  0f95c0                   setne al
000cb8f9  84c0                     test al, al
000cb8fb  0f8535060000             jne 0xcbf36
000cb901  498bde                   mov rbx, r14
000cb904  e9cb060000               jmp 0xcbfd4
000cb909  488bd6                   mov rdx, rsi
000cb90c  b938070000               mov ecx, 0x738
000cb911  e86a69f4ff               call 0x12280
000cb916  488bd8                   mov rbx, rax
000cb919  48894560                 mov qword ptr [rbp + 0x60], rax
000cb91d  4885c0                   test rax, rax
000cb920  7453                     je 0xcb975
000cb922  488bc8                   mov rcx, rax
000cb925  e8e69d0400               call 0x115710
000cb92a  90                       nop
000cb92b  488d05be0c1800           lea rax, [rip + 0x180cbe]
000cb932  488903                   mov qword ptr [rbx], rax
000cb935  488d8b00070000           lea rcx, [rbx + 0x700]
000cb93c  48894dc8                 mov qword ptr [rbp - 0x38], rcx
000cb940  488d4108                 lea rax, [rcx + 8]
000cb944  48894008                 mov qword ptr [rax + 8], rax
000cb948  488900                   mov qword ptr [rax], rax
000cb94b  4c897118                 mov qword ptr [rcx + 0x18], r14
000cb94f  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cb956  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cb95d  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cb965  488d05d4e11600           lea rax, [rip + 0x16e1d4]
000cb96c  488901                   mov qword ptr [rcx], rax
000cb96f  4c897130                 mov qword ptr [rcx + 0x30], r14
000cb973  eb03                     jmp 0xcb978
000cb975  498bde                   mov rbx, r14
000cb978  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cb97f  8b4004                   mov eax, dword ptr [rax + 4]
000cb982  2573020000               and eax, 0x273
000cb987  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000cb98d  83f802                   cmp eax, 2
000cb990  7527                     jne 0xcb9b9
000cb992  803d9f64260000           cmp byte ptr [rip + 0x26649f], 0
000cb999  741e                     je 0xcb9b9
000cb99b  8b054b912400             mov eax, dword ptr [rip + 0x24914b]
000cb9a1  83f801                   cmp eax, 1
000cb9a4  7613                     jbe 0xcb9b9
000cb9a6  c7839006000001000000     mov dword ptr [rbx + 0x690], 1
000cb9b0  448b2535912400           mov r12d, dword ptr [rip + 0x249135]
000cb9b7  eb11                     jmp 0xcb9ca
000cb9b9  4489b390060000           mov dword ptr [rbx + 0x690], r14d
000cb9c0  8bcf                     mov ecx, edi
000cb9c2  e8193e0700               call 0x13f7e0
000cb9c7  448be0                   mov r12d, eax
000cb9ca  418bc4                   mov eax, r12d
000cb9cd  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cb9d5  4883e2f0                 and rdx, 0xfffffffffffffff0
000cb9d9  4c89b370060000           mov qword ptr [rbx + 0x670], r14
000cb9e0  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cb9e4  0f87aa000000             ja 0xcba94
000cb9ea  0faee8                   lfence
000cb9ed  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb9f1  48c1e00d                 shl rax, 0xd
000cb9f5  4881faa01f0000           cmp rdx, 0x1fa0
000cb9fc  762d                     jbe 0xcba2b
000cb9fe  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cba03  4c8bca                   mov r9, rdx
000cba06  4c8bc2                   mov r8, rdx
000cba09  498bce                   mov rcx, r14
000cba0c  e8dfbef3ff               call 0x78f0
000cba11  66ff4614                 inc word ptr [rsi + 0x14]
000cba15  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cba19  48c1e00d                 shl rax, 0xd
000cba1d  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cba22  8b4808                   mov ecx, dword ptr [rax + 8]
000cba25  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cba29  eb5b                     jmp 0xcba86
000cba2b  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cba30  418b4608                 mov eax, dword ptr [r14 + 8]
000cba34  483bc2                   cmp rax, rdx
000cba37  7314                     jae 0xcba4d
000cba39  0f1f00                   nop dword ptr [rax]
000cba3c  0f1f4000                 nop dword ptr [rax]
000cba40  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cba44  418b4608                 mov eax, dword ptr [r14 + 8]
000cba48  483bc2                   cmp rax, rdx
000cba4b  72f3                     jb 0xcba40
000cba4d  418b7e08                 mov edi, dword ptr [r14 + 8]
000cba51  4c8bca                   mov r9, rdx
000cba54  41b820000000             mov r8d, 0x20
000cba5a  498bce                   mov rcx, r14
000cba5d  e88ebef3ff               call 0x78f0
000cba62  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cba66  7514                     jne 0xcba7c
000cba68  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cba6c  48c1e00d                 shl rax, 0xd
000cba70  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cba75  8b4808                   mov ecx, dword ptr [rax + 8]
000cba78  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cba7c  66ff4614                 inc word ptr [rsi + 0x14]
000cba80  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000cba86  498d4610                 lea rax, [r14 + 0x10]
000cba8a  48898370060000           mov qword ptr [rbx + 0x670], rax
000cba91  4533f6                   xor r14d, r14d
000cba94  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cba9b  4889442420               mov qword ptr [rsp + 0x20], rax
000cbaa0  458bcc                   mov r9d, r12d
000cbaa3  448bc7                   mov r8d, edi
000cbaa6  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000cbaad  488bcb                   mov rcx, rbx
000cbab0  e81b920700               call 0x144cd0
000cbab5  85c0                     test eax, eax
000cbab7  0f843df7ffff             je 0xcb1fa
000cbabd  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000cbac4  c783d001000001000000     mov dword ptr [rbx + 0x1d0], 1
000cbace  4489bbd4010000           mov dword ptr [rbx + 0x1d4], r15d
000cbad5  48c7838005000000000000   mov qword ptr [rbx + 0x580], 0
000cbae0  4489b388050000           mov dword ptr [rbx + 0x588], r14d
000cbae7  4c89b390050000           mov qword ptr [rbx + 0x590], r14
000cbaee  488d8bd8010000           lea rcx, [rbx + 0x1d8]
000cbaf5  4c8bcb                   mov r9, rbx
000cbaf8  458bc7                   mov r8d, r15d
000cbafb  498bd5                   mov rdx, r13
000cbafe  e89dc80900               call 0x1683a0
000cbb03  e92e040000               jmp 0xcbf36
000cbb08  488bd6                   mov rdx, rsi
000cbb0b  b940070000               mov ecx, 0x740
000cbb10  e86b67f4ff               call 0x12280
000cbb15  488bd8                   mov rbx, rax
000cbb18  488945c8                 mov qword ptr [rbp - 0x38], rax
000cbb1c  4885c0                   test rax, rax
000cbb1f  7453                     je 0xcbb74
000cbb21  488bc8                   mov rcx, rax
000cbb24  e827e10400               call 0x119c50
000cbb29  90                       nop
000cbb2a  488d05170c1800           lea rax, [rip + 0x180c17]
000cbb31  488903                   mov qword ptr [rbx], rax
000cbb34  488d8b08070000           lea rcx, [rbx + 0x708]
000cbb3b  48894dd0                 mov qword ptr [rbp - 0x30], rcx
000cbb3f  488d4108                 lea rax, [rcx + 8]
000cbb43  48894008                 mov qword ptr [rax + 8], rax
000cbb47  488900                   mov qword ptr [rax], rax
000cbb4a  4c897118                 mov qword ptr [rcx + 0x18], r14
000cbb4e  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cbb55  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cbb5c  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cbb64  488d05d5df1600           lea rax, [rip + 0x16dfd5]
000cbb6b  488901                   mov qword ptr [rcx], rax
000cbb6e  4c897130                 mov qword ptr [rcx + 0x30], r14
000cbb72  eb03                     jmp 0xcbb77
000cbb74  498bde                   mov rbx, r14
000cbb77  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000cbb7e  418b4504                 mov eax, dword ptr [r13 + 4]
000cbb82  2573020000               and eax, 0x273
000cbb87  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000cbb8d  83f802                   cmp eax, 2
000cbb90  7527                     jne 0xcbbb9
000cbb92  803d9f62260000           cmp byte ptr [rip + 0x26629f], 0
000cbb99  741e                     je 0xcbbb9
000cbb9b  8b054b8f2400             mov eax, dword ptr [rip + 0x248f4b]
000cbba1  83f801                   cmp eax, 1
000cbba4  7613                     jbe 0xcbbb9
000cbba6  c7839806000001000000     mov dword ptr [rbx + 0x698], 1
000cbbb0  448b25358f2400           mov r12d, dword ptr [rip + 0x248f35]
000cbbb7  eb11                     jmp 0xcbbca
000cbbb9  4489b398060000           mov dword ptr [rbx + 0x698], r14d
000cbbc0  8bcf                     mov ecx, edi
000cbbc2  e8193c0700               call 0x13f7e0
000cbbc7  448be0                   mov r12d, eax
000cbbca  418bc4                   mov eax, r12d
000cbbcd  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cbbd5  4883e2f0                 and rdx, 0xfffffffffffffff0
000cbbd9  4c89b378060000           mov qword ptr [rbx + 0x678], r14
000cbbe0  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cbbe4  0f87aa000000             ja 0xcbc94
000cbbea  0faee8                   lfence
000cbbed  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbbf1  48c1e00d                 shl rax, 0xd
000cbbf5  4881faa01f0000           cmp rdx, 0x1fa0
000cbbfc  762d                     jbe 0xcbc2b
000cbbfe  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cbc03  4c8bca                   mov r9, rdx
000cbc06  4c8bc2                   mov r8, rdx
000cbc09  498bce                   mov rcx, r14
000cbc0c  e8dfbcf3ff               call 0x78f0
000cbc11  66ff4614                 inc word ptr [rsi + 0x14]
000cbc15  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbc19  48c1e00d                 shl rax, 0xd
000cbc1d  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cbc22  8b4808                   mov ecx, dword ptr [rax + 8]
000cbc25  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cbc29  eb5b                     jmp 0xcbc86
000cbc2b  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cbc30  418b4608                 mov eax, dword ptr [r14 + 8]
000cbc34  483bc2                   cmp rax, rdx
000cbc37  7314                     jae 0xcbc4d
000cbc39  0f1f00                   nop dword ptr [rax]
000cbc3c  0f1f4000                 nop dword ptr [rax]
000cbc40  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cbc44  418b4608                 mov eax, dword ptr [r14 + 8]
000cbc48  483bc2                   cmp rax, rdx
000cbc4b  72f3                     jb 0xcbc40
000cbc4d  418b7e08                 mov edi, dword ptr [r14 + 8]
000cbc51  4c8bca                   mov r9, rdx
000cbc54  41b820000000             mov r8d, 0x20
000cbc5a  498bce                   mov rcx, r14
000cbc5d  e88ebcf3ff               call 0x78f0
000cbc62  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cbc66  7514                     jne 0xcbc7c
000cbc68  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbc6c  48c1e00d                 shl rax, 0xd
000cbc70  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cbc75  8b4808                   mov ecx, dword ptr [rax + 8]
000cbc78  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cbc7c  66ff4614                 inc word ptr [rsi + 0x14]
000cbc80  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000cbc86  498d4610                 lea rax, [r14 + 0x10]
000cbc8a  48898378060000           mov qword ptr [rbx + 0x678], rax
000cbc91  4533f6                   xor r14d, r14d
000cbc94  4c896c2420               mov qword ptr [rsp + 0x20], r13
000cbc99  458bcc                   mov r9d, r12d
000cbc9c  448bc7                   mov r8d, edi
000cbc9f  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000cbca6  488bcb                   mov rcx, rbx
000cbca9  e882980700               call 0x145530
000cbcae  85c0                     test eax, eax
000cbcb0  0f8444f5ffff             je 0xcb1fa
000cbcb6  410f104d00               movups xmm1, xmmword ptr [r13]
000cbcbb  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cbcbf  410f104510               movups xmm0, xmmword ptr [r13 + 0x10]
000cbcc4  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cbcc8  66480f7eca               movq rdx, xmm1
000cbccd  48c1ea20                 shr rdx, 0x20
000cbcd1  f6c201                   test dl, 1
000cbcd4  755e                     jne 0xcbd34
000cbcd6  81e22ffbffff             and edx, 0xfffffb2f
000cbcdc  81ca20020000             or edx, 0x220
000cbce2  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cbce6  48c1e820                 shr rax, 0x20
000cbcea  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000cbcee  498bc8                   mov rcx, r8
000cbcf1  48c1e920                 shr rcx, 0x20
000cbcf5  49c1e810                 shr r8, 0x10
000cbcf9  89442438                 mov dword ptr [rsp + 0x38], eax
000cbcfd  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000cbd00  89442430                 mov dword ptr [rsp + 0x30], eax
000cbd04  894c2428                 mov dword ptr [rsp + 0x28], ecx
000cbd08  664489442420             mov word ptr [rsp + 0x20], r8w
000cbd0e  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000cbd13  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000cbd17  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000cbd1a  e8f15bf4ff               call 0x11910
000cbd1f  48898398050000           mov qword ptr [rbx + 0x598], rax
000cbd26  4885c0                   test rax, rax
000cbd29  0f95c0                   setne al
000cbd2c  84c0                     test al, al
000cbd2e  0f84c6f4ffff             je 0xcb1fa
000cbd34  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000cbd3b  c783d001000001000000     mov dword ptr [rbx + 0x1d0], 1
000cbd45  4489bbd4010000           mov dword ptr [rbx + 0x1d4], r15d
000cbd4c  48c7838005000000000000   mov qword ptr [rbx + 0x580], 0
000cbd57  4489b388050000           mov dword ptr [rbx + 0x588], r14d
000cbd5e  4c89b390050000           mov qword ptr [rbx + 0x590], r14
000cbd65  488d8bd8010000           lea rcx, [rbx + 0x1d8]
000cbd6c  4c8bcb                   mov r9, rbx
000cbd6f  458bc7                   mov r8d, r15d
000cbd72  488b5560                 mov rdx, qword ptr [rbp + 0x60]
000cbd76  e825c60900               call 0x1683a0
000cbd7b  e9b6010000               jmp 0xcbf36
000cbd80  488bd6                   mov rdx, rsi
000cbd83  b9e0030000               mov ecx, 0x3e0
000cbd88  e8f364f4ff               call 0x12280
000cbd8d  488bd8                   mov rbx, rax
000cbd90  48894560                 mov qword ptr [rbp + 0x60], rax
000cbd94  4885c0                   test rax, rax
000cbd97  7453                     je 0xcbdec
000cbd99  488bc8                   mov rcx, rax
000cbd9c  e84f1e0000               call 0xcdbf0
000cbda1  90                       nop
000cbda2  488d059f051800           lea rax, [rip + 0x18059f]
000cbda9  488903                   mov qword ptr [rbx], rax
000cbdac  488d8ba8030000           lea rcx, [rbx + 0x3a8]
000cbdb3  48894dd0                 mov qword ptr [rbp - 0x30], rcx
000cbdb7  488d4108                 lea rax, [rcx + 8]
000cbdbb  48894008                 mov qword ptr [rax + 8], rax
000cbdbf  488900                   mov qword ptr [rax], rax
000cbdc2  4c897118                 mov qword ptr [rcx + 0x18], r14
000cbdc6  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cbdcd  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cbdd4  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cbddc  488d055ddd1600           lea rax, [rip + 0x16dd5d]
000cbde3  488901                   mov qword ptr [rcx], rax
000cbde6  4c897130                 mov qword ptr [rcx + 0x30], r14
000cbdea  eb03                     jmp 0xcbdef
000cbdec  498bde                   mov rbx, r14
000cbdef  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000cbdf6  418b4504                 mov eax, dword ptr [r13 + 4]
000cbdfa  2573020000               and eax, 0x273
000cbdff  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000cbe06  83f802                   cmp eax, 2
000cbe09  7527                     jne 0xcbe32
000cbe0b  803d2660260000           cmp byte ptr [rip + 0x266026], 0
000cbe12  741e                     je 0xcbe32
000cbe14  8b05d28c2400             mov eax, dword ptr [rip + 0x248cd2]
000cbe1a  83f801                   cmp eax, 1
000cbe1d  7613                     jbe 0xcbe32
000cbe1f  c7833803000001000000     mov dword ptr [rbx + 0x338], 1
000cbe29  448b3dbc8c2400           mov r15d, dword ptr [rip + 0x248cbc]
000cbe30  eb12                     jmp 0xcbe44
000cbe32  4489b338030000           mov dword ptr [rbx + 0x338], r14d
000cbe39  418bcc                   mov ecx, r12d
000cbe3c  e89f390700               call 0x13f7e0
000cbe41  448bf8                   mov r15d, eax
000cbe44  418bc7                   mov eax, r15d
000cbe47  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cbe4f  4883e2f0                 and rdx, 0xfffffffffffffff0
000cbe53  4c89b318030000           mov qword ptr [rbx + 0x318], r14
000cbe5a  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cbe5e  0f879d000000             ja 0xcbf01
000cbe64  0faee8                   lfence
000cbe67  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbe6b  48c1e00d                 shl rax, 0xd
000cbe6f  4881faa01f0000           cmp rdx, 0x1fa0
000cbe76  762d                     jbe 0xcbea5
000cbe78  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cbe7d  4c8bca                   mov r9, rdx
000cbe80  4c8bc2                   mov r8, rdx
000cbe83  498bce                   mov rcx, r14
000cbe86  e865baf3ff               call 0x78f0
000cbe8b  66ff4614                 inc word ptr [rsi + 0x14]
000cbe8f  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbe93  48c1e00d                 shl rax, 0xd
000cbe97  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cbe9c  8b4808                   mov ecx, dword ptr [rax + 8]
000cbe9f  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cbea3  eb4e                     jmp 0xcbef3
000cbea5  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cbeaa  418b4608                 mov eax, dword ptr [r14 + 8]
000cbeae  483bc2                   cmp rax, rdx
000cbeb1  730d                     jae 0xcbec0
000cbeb3  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cbeb7  418b4608                 mov eax, dword ptr [r14 + 8]
000cbebb  483bc2                   cmp rax, rdx
000cbebe  72f3                     jb 0xcbeb3
000cbec0  418b7e08                 mov edi, dword ptr [r14 + 8]
000cbec4  4c8bca                   mov r9, rdx
000cbec7  41b820000000             mov r8d, 0x20
000cbecd  498bce                   mov rcx, r14
000cbed0  e81bbaf3ff               call 0x78f0
000cbed5  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cbed9  7514                     jne 0xcbeef
000cbedb  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbedf  48c1e00d                 shl rax, 0xd
000cbee3  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cbee8  8b4808                   mov ecx, dword ptr [rax + 8]
000cbeeb  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cbeef  66ff4614                 inc word ptr [rsi + 0x14]
000cbef3  498d4610                 lea rax, [r14 + 0x10]
000cbef7  48898318030000           mov qword ptr [rbx + 0x318], rax
000cbefe  4533f6                   xor r14d, r14d
000cbf01  4c896c2420               mov qword ptr [rsp + 0x20], r13
000cbf06  458bcf                   mov r9d, r15d
000cbf09  458bc4                   mov r8d, r12d
000cbf0c  488bbd80000000           mov rdi, qword ptr [rbp + 0x80]
000cbf13  488bd7                   mov rdx, rdi
000cbf16  488bcb                   mov rcx, rbx
000cbf19  e8429a0700               call 0x145960
000cbf1e  85c0                     test eax, eax
000cbf20  0f84d4f2ffff             je 0xcb1fa
000cbf26  440fb64744               movzx r8d, byte ptr [rdi + 0x44]
000cbf2b  498bd5                   mov rdx, r13
000cbf2e  488bcb                   mov rcx, rbx
000cbf31  e87af00400               call 0x11afb0
000cbf36  4c8b6558                 mov r12, qword ptr [rbp + 0x58]
000cbf3a  4533f6                   xor r14d, r14d
000cbf3d  4885db                   test rbx, rbx
000cbf40  0f848e000000             je 0xcbfd4
000cbf46  0fb77d70                 movzx edi, word ptr [rbp + 0x70]
000cbf4a  66897c2420               mov word ptr [rsp + 0x20], di
000cbf4f  440fb74d68               movzx r9d, word ptr [rbp + 0x68]
000cbf54  4d8bc4                   mov r8, r12
000cbf57  488bd6                   mov rdx, rsi
000cbf5a  488bcb                   mov rcx, rbx
000cbf5d  e8ae61f4ff               call 0x12110
000cbf62  48899b28010000           mov qword ptr [rbx + 0x128], rbx
000cbf69  4c89b3c0010000           mov qword ptr [rbx + 0x1c0], r14
000cbf70  4489b3b8010000           mov dword ptr [rbx + 0x1b8], r14d
000cbf77  4c89b3a8010000           mov qword ptr [rbx + 0x1a8], r14
000cbf7e  4c89b3b0010000           mov qword ptr [rbx + 0x1b0], r14
000cbf85  8d4f10                   lea ecx, [rdi + 0x10]
000cbf88  4883c110                 add rcx, 0x10
000cbf8c  4883f920                 cmp rcx, 0x20
000cbf90  b820000000               mov eax, 0x20
000cbf95  480f42c8                 cmovb rcx, rax
000cbf99  48898ba0010000           mov qword ptr [rbx + 0x1a0], rcx
000cbfa0  0f57c0                   xorps xmm0, xmm0
000cbfa3  0f118330010000           movups xmmword ptr [rbx + 0x130], xmm0
000cbfaa  0f118340010000           movups xmmword ptr [rbx + 0x140], xmm0
000cbfb1  0f118350010000           movups xmmword ptr [rbx + 0x150], xmm0
000cbfb8  0f118360010000           movups xmmword ptr [rbx + 0x160], xmm0
000cbfbf  0f118370010000           movups xmmword ptr [rbx + 0x170], xmm0
000cbfc6  0f118380010000           movups xmmword ptr [rbx + 0x180], xmm0
000cbfcd  0f118390010000           movups xmmword ptr [rbx + 0x190], xmm0
000cbfd4  488bc3                   mov rax, rbx
000cbfd7  488b9c24c0000000         mov rbx, qword ptr [rsp + 0xc0]
000cbfdf  4881c480000000           add rsp, 0x80
000cbfe6  415f                     pop r15
000cbfe8  415e                     pop r14
000cbfea  415d                     pop r13
000cbfec  415c                     pop r12
000cbfee  5f                       pop rdi
000cbfef  5e                       pop rsi
000cbff0  5d                       pop rbp
000cbff1  c3                       ret
000cbff2  90                       nop
000cbff3  90                       nop
000cbff4  f5                       cmc
000cbff5  a90c0061aa               test eax, 0xaa61000c
000cbffa  0c00                     or al, 0
000cbffc  e2ae                     loop 0xcbfac
000cbffe  0c00                     or al, 0
000cc000  e1b0                     loope 0xcbfb2
000cc002  0c00                     or al, 0
000cc004  7eaf                     jle 0xcbfb5
000cc006  0c00                     or al, 0
000cc008  02b20c0095b3             add dh, byte ptr [rdx - 0x4c6afff4]
000cc00e  0c00                     or al, 0
000cc010  5f                       pop rdi
000cc011  b40c                     mov ah, 0xc
000cc013  00d4                     add ah, dl
000cc015  bf0c00d4bf               mov edi, 0xbfd4000c
000cc01a  0c00                     or al, 0
000cc01c  29b50c0009b9             sub dword ptr [rbp - 0x46f6fff4], esi
000cc022  0c00                     or al, 0
