; SOS_CacheStoreBase::~SOS_CacheStoreBase
; sqldk.dll, primary RVA 0x173eb0, 190 bytes in 1 chunk(s)

; chunk at RVA 0x173eb0 (190 bytes)
00173eb0  48894c2408               mov qword ptr [rsp + 8], rcx
00173eb5  53                       push rbx
00173eb6  4883ec30                 sub rsp, 0x30
00173eba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00173ec3  488bd9                   mov rbx, rcx
00173ec6  488d052bbd0d00           lea rax, [rip + 0xdbd2b]
00173ecd  488901                   mov qword ptr [rcx], rax
00173ed0  488d05e10c0f00           lea rax, [rip + 0xf0ce1]
00173ed7  48894140                 mov qword ptr [rcx + 0x40], rax
00173edb  488b9140060000           mov rdx, qword ptr [rcx + 0x640]
00173ee2  4885d2                   test rdx, rdx
00173ee5  7447                     je 0x173f2e
00173ee7  488bc2                   mov rax, rdx
00173eea  41b800020000             mov r8d, 0x200
00173ef0  482500e0ffff             and rax, 0xffffffffffffe000
00173ef6  740b                     je 0x173f03
00173ef8  6644394004               cmp word ptr [rax + 4], r8w
00173efd  7504                     jne 0x173f03
00173eff  488b4028                 mov rax, qword ptr [rax + 0x28]
00173f03  488b4008                 mov rax, qword ptr [rax + 8]
00173f07  488b4810                 mov rcx, qword ptr [rax + 0x10]
00173f0b  48f7d9                   neg rcx
00173f0e  4823ca                   and rcx, rdx
00173f11  740b                     je 0x173f1e
00173f13  6644394104               cmp word ptr [rcx + 4], r8w
00173f18  7504                     jne 0x173f1e
00173f1a  488b4928                 mov rcx, qword ptr [rcx + 0x28]
00173f1e  488b4908                 mov rcx, qword ptr [rcx + 8]
00173f22  f6412808                 test byte ptr [rcx + 0x28], 8
00173f26  7506                     jne 0x173f2e
00173f28  488b01                   mov rax, qword ptr [rcx]
00173f2b  ff5028                   call qword ptr [rax + 0x28]
00173f2e  48c7834006000000000000   mov qword ptr [rbx + 0x640], 0
00173f39  488d05b82d0d00           lea rax, [rip + 0xd2db8]
00173f40  488903                   mov qword ptr [rbx], rax
00173f43  488d056e0c0f00           lea rax, [rip + 0xf0c6e]
00173f4a  48894340                 mov qword ptr [rbx + 0x40], rax
00173f4e  488b8b18060000           mov rcx, qword ptr [rbx + 0x618]
00173f55  4885c9                   test rcx, rcx
00173f58  7407                     je 0x173f61
00173f5a  488b01                   mov rax, qword ptr [rcx]
00173f5d  ff5010                   call qword ptr [rax + 0x10]
00173f60  90                       nop
00173f61  488bcb                   mov rcx, rbx
00173f64  4883c430                 add rsp, 0x30
00173f68  5b                       pop rbx
00173f69  e9f28debff               jmp 0x2cd60
