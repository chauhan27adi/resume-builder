; `HistoryTargetTables::CreateEventTransformer'::`1'::dtor$0
; sqldk.dll, primary RVA 0x216e40, 35 bytes in 1 chunk(s)

; chunk at RVA 0x216e40 (35 bytes)
00216e40  4055                     push rbp
00216e42  4883ec20                 sub rsp, 0x20
00216e46  488bea                   mov rbp, rdx
00216e49  4c8b85b8000000           mov r8, qword ptr [rbp + 0xb8]
00216e50  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00216e54  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00216e58  e8b3a1deff               call 0x1010
00216e5d  4883c420                 add rsp, 0x20
00216e61  5d                       pop rbp
00216e62  c3                       ret
