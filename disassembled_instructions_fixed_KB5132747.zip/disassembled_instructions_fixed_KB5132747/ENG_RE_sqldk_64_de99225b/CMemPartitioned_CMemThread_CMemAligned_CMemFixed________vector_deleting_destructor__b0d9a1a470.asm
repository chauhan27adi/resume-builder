; CMemPartitioned<CMemThread<CMemAligned<CMemFixed> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce690, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce690 (104 bytes)
000ce690  48894c2408               mov qword ptr [rsp + 8], rcx
000ce695  57                       push rdi
000ce696  4883ec30                 sub rsp, 0x30
000ce69a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce6a3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce6a8  8bda                     mov ebx, edx
000ce6aa  488bf9                   mov rdi, rcx
000ce6ad  488d05fced1700           lea rax, [rip + 0x17edfc]
000ce6b4  488901                   mov qword ptr [rcx], rax
000ce6b7  488d8178020000           lea rax, [rcx + 0x278]
000ce6be  4889442450               mov qword ptr [rsp + 0x50], rax
000ce6c3  488d0d76b41600           lea rcx, [rip + 0x16b476]
000ce6ca  488908                   mov qword ptr [rax], rcx
000ce6cd  488bcf                   mov rcx, rdi
000ce6d0  e88b210300               call 0x100860
000ce6d5  83e305                   and ebx, 5
000ce6d8  80fb05                   cmp bl, 5
000ce6db  750d                     jne 0xce6ea
000ce6dd  bab0020000               mov edx, 0x2b0
000ce6e2  488bcf                   mov rcx, rdi
000ce6e5  e82629f3ff               call 0x1010
000ce6ea  488bc7                   mov rax, rdi
000ce6ed  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce6f2  4883c430                 add rsp, 0x30
000ce6f6  5f                       pop rdi
000ce6f7  c3                       ret
