; `SOS_OS::Boot'::`1'::dtor$3
; sqldk.dll, primary RVA 0x21ce75, 59 bytes in 1 chunk(s)

; chunk at RVA 0x21ce75 (59 bytes)
0021ce75  4055                     push rbp
0021ce77  4883ec30                 sub rsp, 0x30
0021ce7b  488bea                   mov rbp, rdx
0021ce7e  c644242806               mov byte ptr [rsp + 0x28], 6
0021ce83  8b85f8000000             mov eax, dword ptr [rbp + 0xf8]
0021ce89  89442420                 mov dword ptr [rsp + 0x20], eax
0021ce8d  4c8d0decbe0700           lea r9, [rip + 0x7beec]
0021ce94  41b801000000             mov r8d, 1
0021ce9a  488b5538                 mov rdx, qword ptr [rbp + 0x38]
0021ce9e  488b8d08010000           mov rcx, qword ptr [rbp + 0x108]
0021cea5  e866a0deff               call 0x6f10
0021ceaa  4883c430                 add rsp, 0x30
0021ceae  5d                       pop rbp
0021ceaf  c3                       ret
