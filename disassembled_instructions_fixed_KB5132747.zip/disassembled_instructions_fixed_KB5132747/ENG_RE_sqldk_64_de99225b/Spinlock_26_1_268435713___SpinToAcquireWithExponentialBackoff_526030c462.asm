; Spinlock<26,1,268435713>::SpinToAcquireWithExponentialBackoff
; sqldk.dll, primary RVA 0x321c0, 394 bytes in 1 chunk(s)

; chunk at RVA 0x321c0 (394 bytes)
000321c0  48895c2408               mov qword ptr [rsp + 8], rbx
000321c5  48896c2410               mov qword ptr [rsp + 0x10], rbp
000321ca  56                       push rsi
000321cb  57                       push rdi
000321cc  4154                     push r12
000321ce  4156                     push r14
000321d0  4157                     push r15
000321d2  4883ec50                 sub rsp, 0x50
000321d6  654c8b042558000000       mov r8, qword ptr gs:[0x58]
000321df  b81a000000               mov eax, 0x1a
000321e4  448b0dcdf6fcff           mov r9d, dword ptr [rip - 0x30933]
000321eb  4c8be2                   mov r12, rdx
000321ee  6689442420               mov word ptr [rsp + 0x20], ax
000321f3  4c8bf1                   mov r14, rcx
000321f6  8b05d42d2e00             mov eax, dword ptr [rip + 0x2e2dd4]
000321fc  c744242401000000         mov dword ptr [rsp + 0x24], 1
00032204  4d030cc0                 add r9, qword ptr [r8 + rax*8]
00032208  0f84dc340600             je 0x956ea
0003220e  4d398910010000           cmp qword ptr [r9 + 0x110], r9
00032215  0f85cf340600             jne 0x956ea
0003221b  498b8100010000           mov rax, qword ptr [r9 + 0x100]
00032222  4889442428               mov qword ptr [rsp + 0x28], rax
00032227  4885c0                   test rax, rax
0003222a  0f84c3340600             je 0x956f3
00032230  488b80e0030000           mov rax, qword ptr [rax + 0x3e0]
00032237  eb01                     jmp 0x3223a
00032239  cc                       int3
0003223a  f605b7282e0001           test byte ptr [rip + 0x2e28b7], 1
00032241  4889442430               mov qword ptr [rsp + 0x30], rax
00032246  48c744243800000000       mov qword ptr [rsp + 0x38], 0
0003224f  c744244000000000         mov dword ptr [rsp + 0x40], 0
00032257  741f                     je 0x32278
00032259  4885c0                   test rax, rax
0003225c  741a                     je 0x32278
0003225e  0fb780a0000000           movzx eax, word ptr [rax + 0xa0]
00032265  486bc858                 imul rcx, rax, 0x58
00032269  488d0528023000           lea rax, [rip + 0x300228]
00032270  4803c8                   add rcx, rax
00032273  48894c2438               mov qword ptr [rsp + 0x38], rcx
00032278  8b056e282e00             mov eax, dword ptr [rip + 0x2e286e]
0003227e  41b83c000000             mov r8d, 0x3c
00032284  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
00032289  493bc0                   cmp rax, r8
0003228c  8bf8                     mov edi, eax
0003228e  410f47f8                 cmova edi, r8d
00032292  4885c9                   test rcx, rcx
00032295  741f                     je 0x322b6
00032297  488b4108                 mov rax, qword ptr [rcx + 8]
0003229b  48ff80b8050000           inc qword ptr [rax + 0x5b8]
000322a2  488b5108                 mov rdx, qword ptr [rcx + 8]
000322a6  488b82b0050000           mov rax, qword ptr [rdx + 0x5b0]
000322ad  4885c0                   test rax, rax
000322b0  0f85af010000             jne 0x32465
000322b6  8b0530282e00             mov eax, dword ptr [rip + 0x2e2830]
000322bc  440fb63dfc312e00         movzx r15d, byte ptr [rip + 0x2e31fc]
000322c4  493bc0                   cmp rax, r8
000322c7  488b358a152e00           mov rsi, qword ptr [rip + 0x2e158a]
000322ce  8be8                     mov ebp, eax
000322d0  490f47e8                 cmova rbp, r8
000322d4  33db                     xor ebx, ebx
000322d6  4584ff                   test r15b, r15b
000322d9  0f851c340600             jne 0x956fb
000322df  488bd7                   mov rdx, rdi
000322e2  4885d2                   test rdx, rdx
000322e5  7413                     je 0x322fa
000322e7  660f1f0400               nop word ptr [rax + rax]
000322ec  0f1f4000                 nop dword ptr [rax]
000322f0  f390                     pause
000322f2  4803de                   add rbx, rsi
000322f5  483bda                   cmp rbx, rdx
000322f8  72f6                     jb 0x322f0
000322fa  488b442438               mov rax, qword ptr [rsp + 0x38]
000322ff  4885c0                   test rax, rax
00032302  740b                     je 0x3230f
00032304  488b4008                 mov rax, qword ptr [rax + 8]
00032308  480198b0050000           add qword ptr [rax + 0x5b0], rbx
0003230f  418b06                   mov eax, dword ptr [r14]
00032312  85c0                     test eax, eax
00032314  0f85f7330600             jne 0x95711
0003231a  33c0                     xor eax, eax
0003231c  f04d0fb126               lock cmpxchg qword ptr [r14], r12
00032321  b800000000               mov eax, 0
00032326  0f94c0                   sete al
00032329  85c0                     test eax, eax
0003232b  0f84e0330600             je 0x95711
00032331  4c8d5c2450               lea r11, [rsp + 0x50]
00032336  498b5b30                 mov rbx, qword ptr [r11 + 0x30]
0003233a  498b6b38                 mov rbp, qword ptr [r11 + 0x38]
0003233e  498be3                   mov rsp, r11
00032341  415f                     pop r15
00032343  415e                     pop r14
00032345  415c                     pop r12
00032347  5f                       pop rdi
00032348  5e                       pop rsi
00032349  c3                       ret
