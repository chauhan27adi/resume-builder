; MiniSOSThreadResources::FakeTaskFunc
; sqldk.dll, primary RVA 0x8bc30, 53 bytes in 1 chunk(s)

; chunk at RVA 0x8bc30 (53 bytes)
0008bc30  4883ec38                 sub rsp, 0x38
0008bc34  488d05c5052200           lea rax, [rip + 0x2205c5]
0008bc3b  41b9d0010000             mov r9d, 0x1d0
0008bc41  4c8d0538fe2100           lea r8, [rip + 0x21fe38]
0008bc48  4889442420               mov qword ptr [rsp + 0x20], rax
0008bc4d  488d15e8002200           lea rdx, [rip + 0x2200e8]
0008bc54  b901000000               mov ecx, 1
0008bc59  e892611200               call 0x1b1df0
0008bc5e  33c0                     xor eax, eax
0008bc60  4883c438                 add rsp, 0x38
0008bc64  c3                       ret
