; CMemAligned<CMemDbg<PageHeapMemObj> >::~CMemAligned<CMemDbg<PageHeapMemObj> >
; sqldk.dll, primary RVA 0xe41f0, 37 bytes in 1 chunk(s)

; chunk at RVA 0xe41f0 (37 bytes)
000e41f0  48894c2408               mov qword ptr [rsp + 8], rcx
000e41f5  4883ec38                 sub rsp, 0x38
000e41f9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000e4202  488d05c76f1600           lea rax, [rip + 0x166fc7]
000e4209  488901                   mov qword ptr [rcx], rax
000e420c  4883c438                 add rsp, 0x38
000e4210  e9ebe10800               jmp 0x172400
