; XE_SessionBasicTargetImpl::`vector deleting destructor'
; sqldk.dll, primary RVA 0x1eeb50, 63 bytes in 1 chunk(s)

; chunk at RVA 0x1eeb50 (63 bytes)
001eeb50  48894c2408               mov qword ptr [rsp + 8], rcx
001eeb55  53                       push rbx
001eeb56  4883ec30                 sub rsp, 0x30
001eeb5a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001eeb63  488bd9                   mov rbx, rcx
001eeb66  488d051b6f0700           lea rax, [rip + 0x76f1b]
001eeb6d  488901                   mov qword ptr [rcx], rax
001eeb70  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
001eeb77  f6c201                   test dl, 1
001eeb7a  740a                     je 0x1eeb86
001eeb7c  ba18000000               mov edx, 0x18
001eeb81  e8aa83e1ff               call 0x6f30
001eeb86  488bc3                   mov rax, rbx
001eeb89  4883c430                 add rsp, 0x30
001eeb8d  5b                       pop rbx
001eeb8e  c3                       ret
