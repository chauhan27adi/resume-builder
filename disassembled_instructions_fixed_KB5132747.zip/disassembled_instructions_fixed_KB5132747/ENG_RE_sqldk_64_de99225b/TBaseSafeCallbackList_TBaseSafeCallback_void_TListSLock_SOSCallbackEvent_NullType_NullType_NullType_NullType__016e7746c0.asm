; TBaseSafeCallbackList<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType> >::~TBaseSafeCallbackList<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType> >
; sqldk.dll, primary RVA 0x6ad60, 27 bytes in 1 chunk(s)

; chunk at RVA 0x6ad60 (27 bytes)
0006ad60  48894c2408               mov qword ptr [rsp + 8], rcx
0006ad65  4883ec38                 sub rsp, 0x38
0006ad69  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0006ad72  4883c438                 add rsp, 0x38
0006ad76  e995050000               jmp 0x6b310
