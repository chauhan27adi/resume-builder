; `XE_ProxyTargetEntry::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235d70, 56 bytes in 1 chunk(s)

; chunk at RVA 0x235d70 (56 bytes)
00235d70  4055                     push rbp
00235d72  4883ec30                 sub rsp, 0x30
00235d76  488bea                   mov rbp, rdx
00235d79  c644242806               mov byte ptr [rsp + 0x28], 6
00235d7e  8b8588000000             mov eax, dword ptr [rbp + 0x88]
00235d84  89442420                 mov dword ptr [rsp + 0x20], eax
00235d88  4c8d0d014c0700           lea r9, [rip + 0x74c01]
00235d8f  41b801000000             mov r8d, 1
00235d95  488b5570                 mov rdx, qword ptr [rbp + 0x70]
00235d99  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00235d9d  e84e41faff               call 0x1d9ef0
00235da2  4883c430                 add rsp, 0x30
00235da6  5d                       pop rbp
00235da7  c3                       ret
