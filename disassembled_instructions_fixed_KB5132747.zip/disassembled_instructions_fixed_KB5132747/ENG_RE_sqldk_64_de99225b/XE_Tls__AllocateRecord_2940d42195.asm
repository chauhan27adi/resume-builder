; XE_Tls::AllocateRecord
; sqldk.dll, primary RVA 0x260a0, 380 bytes in 4 chunk(s)

; chunk at RVA 0x25fe8 (170 bytes)
00025fe8  48895c2420               mov qword ptr [rsp + 0x20], rbx
00025fed  e86eaf1b00               call 0x1e0f60
00025ff2  488bd8                   mov rbx, rax
00025ff5  4885c0                   test rax, rax
00025ff8  0f8440af1b00             je 0x1e0f3e
00025ffe  0faee8                   lfence
00026001  448bcd                   mov r9d, ebp
00026004  0f1f4000                 nop dword ptr [rax]
00026008  0f1f840000000000         nop dword ptr [rax + rax]
00026010  418bc9                   mov ecx, r9d
00026013  4c8d048b                 lea r8, [rbx + rcx*4]
00026017  660f1f840000000000       nop word ptr [rax + rax]
00026020  418b00                   mov eax, dword ptr [r8]
00026023  8bc8                     mov ecx, eax
00026025  f7d1                     not ecx
00026027  8bd1                     mov edx, ecx
00026029  f7da                     neg edx
0002602b  23d1                     and edx, ecx
0002602d  0f84e7ae1b00             je 0x1e0f1a
00026033  8bca                     mov ecx, edx
00026035  0bc8                     or ecx, eax
00026037  f0410fb108               lock cmpxchg dword ptr [r8], ecx
0002603c  75e2                     jne 0x26020
0002603e  0fbcc2                   bsf eax, edx
00026041  41c1e105                 shl r9d, 5
00026045  89442458                 mov dword ptr [rsp + 0x58], eax
00026049  428d2c08                 lea ebp, [rax + r9]
0002604d  4881c5820b0000           add rbp, 0xb82
00026054  48c1e506                 shl rbp, 6
00026058  4803eb                   add rbp, rbx
0002605b  8bc6                     mov eax, esi
0002605d  498d0cc6                 lea rcx, [r14 + rax*8]
00026061  33c0                     xor eax, eax
00026063  f0480fb119               lock cmpxchg qword ptr [rcx], rbx
00026068  0f84beae1b00             je 0x1e0f2c
0002606e  ff1584302100             call qword ptr [rip + 0x213084]
00026074  4c8bc3                   mov r8, rbx
00026077  33d2                     xor edx, edx
00026079  488bc8                   mov rcx, rax
0002607c  ff157e302100             call qword ptr [rip + 0x21307e]
00026082  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
00026087  4883c428                 add rsp, 0x28
0002608b  415e                     pop r14
0002608d  5f                       pop rdi
0002608e  5e                       pop rsi
0002608f  5d                       pop rbp
00026090  eb0e                     jmp 0x260a0

; chunk at RVA 0x260a0 (156 bytes)
000260a0  4055                     push rbp
000260a2  56                       push rsi
000260a3  57                       push rdi
000260a4  4156                     push r14
000260a6  4883ec28                 sub rsp, 0x28
000260aa  33ed                     xor ebp, ebp
000260ac  4c8d35ade93100           lea r14, [rip + 0x31e9ad]
000260b3  8bfd                     mov edi, ebp
000260b5  8bf5                     mov esi, ebp
000260b7  81fe00010000             cmp esi, 0x100
000260bd  7370                     jae 0x2612f
000260bf  8bc6                     mov eax, esi
000260c1  4d8b1cc6                 mov r11, qword ptr [r14 + rax*8]
000260c5  4d85db                   test r11, r11
000260c8  0f8405ffffff             je 0x25fd3
000260ce  488bfd                   mov rdi, rbp
000260d1  448bd5                   mov r10d, ebp
000260d4  418bc2                   mov eax, r10d
000260d7  4d8d0c83                 lea r9, [r11 + rax*4]
000260db  0f1f440000               nop dword ptr [rax + rax]
000260e0  458b01                   mov r8d, dword ptr [r9]
000260e3  418bc0                   mov eax, r8d
000260e6  f7d0                     not eax
000260e8  8bc8                     mov ecx, eax
000260ea  f7d9                     neg ecx
000260ec  23c8                     and ecx, eax
000260ee  750c                     jne 0x260fc
000260f0  41ffc2                   inc r10d
000260f3  4183fa20                 cmp r10d, 0x20
000260f7  72db                     jb 0x260d4
000260f9  eb2d                     jmp 0x26128
000260fb  cc                       int3
000260fc  8bd1                     mov edx, ecx
000260fe  418bc0                   mov eax, r8d
00026101  410bd0                   or edx, r8d
00026104  f0410fb111               lock cmpxchg dword ptr [r9], edx
00026109  75d5                     jne 0x260e0
0002610b  0fbcc1                   bsf eax, ecx
0002610e  41c1e205                 shl r10d, 5
00026112  89442450                 mov dword ptr [rsp + 0x50], eax
00026116  428d3c10                 lea edi, [rax + r10]
0002611a  4881c7820b0000           add rdi, 0xb82
00026121  48c1e706                 shl rdi, 6
00026125  4903fb                   add rdi, r11
00026128  ffc6                     inc esi
0002612a  4885ff                   test rdi, rdi
0002612d  7488                     je 0x260b7
0002612f  488bc7                   mov rax, rdi
00026132  4883c428                 add rsp, 0x28
00026136  415e                     pop r14
00026138  5f                       pop rdi
00026139  5e                       pop rsi
0002613a  5d                       pop rbp
0002613b  c3                       ret

; chunk at RVA 0x1e0f1a (36 bytes)
001e0f1a  41ffc1                   inc r9d
001e0f1d  4183f920                 cmp r9d, 0x20
001e0f21  0f82e950e4ff             jb 0x26010
001e0f27  e92f51e4ff               jmp 0x2605b
001e0f2c  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
001e0f31  488bc5                   mov rax, rbp
001e0f34  4883c428                 add rsp, 0x28
001e0f38  415e                     pop r14
001e0f3a  5f                       pop rdi
001e0f3b  5e                       pop rsi
001e0f3c  5d                       pop rbp
001e0f3d  c3                       ret

; chunk at RVA 0x1e0f3e (18 bytes)
001e0f3e  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
001e0f43  488bc7                   mov rax, rdi
001e0f46  4883c428                 add rsp, 0x28
001e0f4a  415e                     pop r14
001e0f4c  5f                       pop rdi
001e0f4d  5e                       pop rsi
001e0f4e  5d                       pop rbp
001e0f4f  c3                       ret
