; SOS_Task::AutoSwitchPreemptive::~AutoSwitchPreemptive
; sqldk.dll, primary RVA 0xbed70, 118 bytes in 1 chunk(s)

; chunk at RVA 0xbed70 (118 bytes)
000bed70  48894c2408               mov qword ptr [rsp + 8], rcx
000bed75  57                       push rdi
000bed76  4883ec30                 sub rsp, 0x30
000bed7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000bed83  48895c2450               mov qword ptr [rsp + 0x50], rbx
000bed88  488bf9                   mov rdi, rcx
000bed8b  488d5910                 lea rbx, [rcx + 0x10]
000bed8f  48895c2448               mov qword ptr [rsp + 0x48], rbx
000bed94  833b00                   cmp dword ptr [rbx], 0
000bed97  742a                     je 0xbedc3
000bed99  488b5308                 mov rdx, qword ptr [rbx + 8]
000bed9d  488b8a60020000           mov rcx, qword ptr [rdx + 0x260]
000beda4  837b0400                 cmp dword ptr [rbx + 4], 0
000beda8  740c                     je 0xbedb6
000bedaa  818a2003000000080000     or dword ptr [rdx + 0x320], 0x800
000bedb4  eb0d                     jmp 0xbedc3
000bedb6  488b01                   mov rax, qword ptr [rcx]
000bedb9  41b801000000             mov r8d, 1
000bedbf  ff5010                   call qword ptr [rax + 0x10]
000bedc2  90                       nop
000bedc3  488d4b10                 lea rcx, [rbx + 0x10]
000bedc7  e84460f5ff               call 0x14e10
000bedcc  90                       nop
000bedcd  488b4f08                 mov rcx, qword ptr [rdi + 8]
000bedd1  8b07                     mov eax, dword ptr [rdi]
000bedd3  f7d0                     not eax
000bedd5  218168020000             and dword ptr [rcx + 0x268], eax
000beddb  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
000bede0  4883c430                 add rsp, 0x30
000bede4  5f                       pop rdi
000bede5  c3                       ret
