; CMemAligned<CMemObj>::`vector deleting destructor'
; sqldk.dll, primary RVA 0xd0610, 121 bytes in 1 chunk(s)

; chunk at RVA 0xd0610 (121 bytes)
000d0610  48894c2408               mov qword ptr [rsp + 8], rcx
000d0615  57                       push rdi
000d0616  4883ec30                 sub rsp, 0x30
000d061a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d0623  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d0628  8bda                     mov ebx, edx
000d062a  488bf9                   mov rdi, rcx
000d062d  488d0554b21700           lea rax, [rip + 0x17b254]
000d0634  488901                   mov qword ptr [rcx], rax
000d0637  488d052a691700           lea rax, [rip + 0x17692a]
000d063e  488901                   mov qword ptr [rcx], rax
000d0641  488d05c06b1700           lea rax, [rip + 0x176bc0]
000d0648  488901                   mov qword ptr [rcx], rax
000d064b  4883c138                 add rcx, 0x38
000d064f  e89c0ff4ff               call 0x115f0
000d0654  90                       nop
000d0655  488d4f30                 lea rcx, [rdi + 0x30]
000d0659  e8920ff4ff               call 0x115f0
000d065e  90                       nop
000d065f  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
000d0666  83e305                   and ebx, 5
000d0669  80fb05                   cmp bl, 5
000d066c  750d                     jne 0xd067b
000d066e  ba30010000               mov edx, 0x130
000d0673  488bcf                   mov rcx, rdi
000d0676  e89509f3ff               call 0x1010
000d067b  488bc7                   mov rax, rdi
000d067e  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d0683  4883c430                 add rsp, 0x30
000d0687  5f                       pop rdi
000d0688  c3                       ret
