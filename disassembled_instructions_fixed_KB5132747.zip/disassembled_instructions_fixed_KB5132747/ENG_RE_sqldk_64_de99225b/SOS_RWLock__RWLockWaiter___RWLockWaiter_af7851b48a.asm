; SOS_RWLock::RWLockWaiter::~RWLockWaiter
; sqldk.dll, primary RVA 0x79570, 33 bytes in 1 chunk(s)

; chunk at RVA 0x79570 (33 bytes)
00079570  48894c2408               mov qword ptr [rsp + 8], rcx
00079575  4883ec18                 sub rsp, 0x18
00079579  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00079581  488d05b8051c00           lea rax, [rip + 0x1c05b8]
00079588  48894118                 mov qword ptr [rcx + 0x18], rax
0007958c  4883c418                 add rsp, 0x18
00079590  c3                       ret
