; `XEPackage0::BucketizingTarget::AllocateSlots'::`1'::dtor$0
; sqldk.dll, primary RVA 0x230950, 41 bytes in 1 chunk(s)

; chunk at RVA 0x230950 (41 bytes)
00230950  4055                     push rbp
00230952  4883ec20                 sub rsp, 0x20
00230956  488bea                   mov rbp, rdx
00230959  4c8b85a8000000           mov r8, qword ptr [rbp + 0xa8]
00230960  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
00230967  488b8db0000000           mov rcx, qword ptr [rbp + 0xb0]
0023096e  e89d06ddff               call 0x1010
00230973  4883c420                 add rsp, 0x20
00230977  5d                       pop rbp
00230978  c3                       ret
