; `XE_TCollection<0,0>::IsValid'::`1'::dtor$2
; sqldk.dll, primary RVA 0x2358f4, 34 bytes in 1 chunk(s)

; chunk at RVA 0x2358f4 (34 bytes)
002358f4  4055                     push rbp
002358f6  4883ec20                 sub rsp, 0x20
002358fa  488bea                   mov rbp, rdx
002358fd  4533c0                   xor r8d, r8d
00235900  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00235907  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
0023590b  e800b7dcff               call 0x1010
00235910  4883c420                 add rsp, 0x20
00235914  5d                       pop rbp
00235915  c3                       ret
