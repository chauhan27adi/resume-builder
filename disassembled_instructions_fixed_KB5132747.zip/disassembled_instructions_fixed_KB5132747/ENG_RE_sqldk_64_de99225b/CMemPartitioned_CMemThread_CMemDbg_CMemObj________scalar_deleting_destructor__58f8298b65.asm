; CMemPartitioned<CMemThread<CMemDbg<CMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcee80, 133 bytes in 1 chunk(s)

; chunk at RVA 0xcee80 (133 bytes)
000cee80  48894c2408               mov qword ptr [rsp + 8], rcx
000cee85  57                       push rdi
000cee86  4883ec30                 sub rsp, 0x30
000cee8a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cee93  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cee98  8bda                     mov ebx, edx
000cee9a  488bf9                   mov rdi, rcx
000cee9d  488d0594cc1700           lea rax, [rip + 0x17cc94]
000ceea4  488901                   mov qword ptr [rcx], rax
000ceea7  488d8160060000           lea rax, [rcx + 0x660]
000ceeae  4889442450               mov qword ptr [rsp + 0x50], rax
000ceeb3  488d0d86ac1600           lea rcx, [rip + 0x16ac86]
000ceeba  488908                   mov qword ptr [rax], rcx
000ceebd  488d05a48e1700           lea rax, [rip + 0x178ea4]
000ceec4  488907                   mov qword ptr [rdi], rax
000ceec7  488d87f8040000           lea rax, [rdi + 0x4f8]
000ceece  4889442458               mov qword ptr [rsp + 0x58], rax
000ceed3  48894830                 mov qword ptr [rax + 0x30], rcx
000ceed7  488908                   mov qword ptr [rax], rcx
000ceeda  488bcf                   mov rcx, rdi
000ceedd  e8eef60900               call 0x16e5d0
000ceee2  83e305                   and ebx, 5
000ceee5  80fb05                   cmp bl, 5
000ceee8  750d                     jne 0xceef7
000ceeea  ba98060000               mov edx, 0x698
000ceeef  488bcf                   mov rcx, rdi
000ceef2  e81921f3ff               call 0x1010
000ceef7  488bc7                   mov rax, rdi
000ceefa  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ceeff  4883c430                 add rsp, 0x30
000cef03  5f                       pop rdi
000cef04  c3                       ret
