; CMemDetour<CMemThread<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce5b0, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce5b0 (104 bytes)
000ce5b0  48894c2408               mov qword ptr [rsp + 8], rcx
000ce5b5  57                       push rdi
000ce5b6  4883ec30                 sub rsp, 0x30
000ce5ba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce5c3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce5c8  8bda                     mov ebx, edx
000ce5ca  488bf9                   mov rdi, rcx
000ce5cd  488d058cf11700           lea rax, [rip + 0x17f18c]
000ce5d4  488901                   mov qword ptr [rcx], rax
000ce5d7  488d8120020000           lea rax, [rcx + 0x220]
000ce5de  4889442450               mov qword ptr [rsp + 0x50], rax
000ce5e3  488d0d56b51600           lea rcx, [rip + 0x16b556]
000ce5ea  488908                   mov qword ptr [rax], rcx
000ce5ed  488bcf                   mov rcx, rdi
000ce5f0  e84be00200               call 0xfc640
000ce5f5  83e305                   and ebx, 5
000ce5f8  80fb05                   cmp bl, 5
000ce5fb  750d                     jne 0xce60a
000ce5fd  ba58020000               mov edx, 0x258
000ce602  488bcf                   mov rcx, rdi
000ce605  e8062af3ff               call 0x1010
000ce60a  488bc7                   mov rax, rdi
000ce60d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce612  4883c430                 add rsp, 0x30
000ce616  5f                       pop rdi
000ce617  c3                       ret
