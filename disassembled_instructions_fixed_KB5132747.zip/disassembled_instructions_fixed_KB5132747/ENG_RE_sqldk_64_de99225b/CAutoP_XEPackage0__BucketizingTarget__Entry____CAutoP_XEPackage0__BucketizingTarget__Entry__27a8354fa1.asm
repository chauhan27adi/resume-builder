; CAutoP<XEPackage0::BucketizingTarget::Entry>::~CAutoP<XEPackage0::BucketizingTarget::Entry>
; sqldk.dll, primary RVA 0x1c7170, 61 bytes in 1 chunk(s)

; chunk at RVA 0x1c7170 (61 bytes)
001c7170  4053                     push rbx
001c7172  4883ec30                 sub rsp, 0x30
001c7176  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001c717f  488b19                   mov rbx, qword ptr [rcx]
001c7182  48895c2440               mov qword ptr [rsp + 0x40], rbx
001c7187  4885db                   test rbx, rbx
001c718a  741b                     je 0x1c71a7
001c718c  488d4b10                 lea rcx, [rbx + 0x10]
001c7190  e82babe7ff               call 0x41cc0
001c7195  ba20000000               mov edx, 0x20
001c719a  488bcb                   mov rcx, rbx
001c719d  4883c430                 add rsp, 0x30
001c71a1  5b                       pop rbx
001c71a2  e989fde3ff               jmp 0x6f30
001c71a7  4883c430                 add rsp, 0x30
001c71ab  5b                       pop rbx
001c71ac  c3                       ret
