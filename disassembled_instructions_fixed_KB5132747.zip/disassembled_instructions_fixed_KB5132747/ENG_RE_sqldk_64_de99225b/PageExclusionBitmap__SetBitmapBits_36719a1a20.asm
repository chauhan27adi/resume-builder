; PageExclusionBitmap::SetBitmapBits
; sqldk.dll, primary RVA 0xcd30, 370 bytes in 7 chunk(s)

; chunk at RVA 0xcd30 (32 bytes)
0000cd30  4889742418               mov qword ptr [rsp + 0x18], rsi
0000cd35  57                       push rdi
0000cd36  488b3d83263200           mov rdi, qword ptr [rip + 0x322683]
0000cd3d  488bf2                   mov rsi, rdx
0000cd40  450fb6d0                 movzx r10d, r8b
0000cd44  4c8bc1                   mov r8, rcx
0000cd47  4885ff                   test rdi, rdi
0000cd4a  0f84525b0000             je 0x128a2

; chunk at RVA 0xcd50 (126 bytes)
0000cd50  48895c2410               mov qword ptr [rsp + 0x10], rbx
0000cd55  4c8bd9                   mov r11, rcx
0000cd58  488bd9                   mov rbx, rcx
0000cd5b  49c1eb10                 shr r11, 0x10
0000cd5f  48c1eb0d                 shr rbx, 0xd
0000cd63  4c8bcb                   mov r9, rbx
0000cd66  48c1ea0d                 shr rdx, 0xd
0000cd6a  4183e107                 and r9d, 7
0000cd6e  4883fa08                 cmp rdx, 8
0000cd72  0f87795a0000             ja 0x127f1
0000cd78  b908000000               mov ecx, 8
0000cd7d  8bc1                     mov eax, ecx
0000cd7f  492bc1                   sub rax, r9
0000cd82  483bc2                   cmp rax, rdx
0000cd85  0f82665a0000             jb 0x127f1
0000cd8b  420fb6041f               movzx eax, byte ptr [rdi + r11]
0000cd90  2aca                     sub cl, dl
0000cd92  412ac9                   sub cl, r9b
0000cd95  baff000000               mov edx, 0xff
0000cd9a  448bc2                   mov r8d, edx
0000cd9d  41d3f8                   sar r8d, cl
0000cda0  418bc9                   mov ecx, r9d
0000cda3  d2e2                     shl dl, cl
0000cda5  4422c2                   and r8b, dl
0000cda8  4122c0                   and al, r8b
0000cdab  4584d2                   test r10b, r10b
0000cdae  0f847b110000             je 0xdf2f
0000cdb4  413ac0                   cmp al, r8b
0000cdb7  0f84e05a0000             je 0x1289d
0000cdbd  f04608041f               lock or byte ptr [rdi + r11], r8b
0000cdc2  488b5c2410               mov rbx, qword ptr [rsp + 0x10]
0000cdc7  488b742420               mov rsi, qword ptr [rsp + 0x20]
0000cdcc  5f                       pop rdi
0000cdcd  c3                       ret

; chunk at RVA 0xdf2f (28 bytes)
0000df2f  84c0                     test al, al
0000df31  0f8466490000             je 0x1289d
0000df37  41f6d0                   not r8b
0000df3a  f04620041f               lock and byte ptr [rdi + r11], r8b
0000df3f  488b5c2410               mov rbx, qword ptr [rsp + 0x10]
0000df44  488b742420               mov rsi, qword ptr [rsp + 0x20]
0000df49  5f                       pop rdi
0000df4a  c3                       ret

; chunk at RVA 0x127f1 (4 bytes)
000127f1  498d1430                 lea rdx, [r8 + rsi]

; chunk at RVA 0x127f5 (168 bytes)
000127f5  48896c2418               mov qword ptr [rsp + 0x18], rbp
000127fa  0fb6cb                   movzx ecx, bl
000127fd  4d8bc8                   mov r9, r8
00012800  80e13f                   and cl, 0x3f
00012803  49c1e913                 shr r9, 0x13
00012807  4c8d8200e0ffff           lea r8, [rdx - 0x2000]
0001280e  48c7c3ffffffff           mov rbx, 0xffffffffffffffff
00012815  49c1e813                 shr r8, 0x13
00012819  488bf3                   mov rsi, rbx
0001281c  48d3e6                   shl rsi, cl
0001281f  4d8bd8                   mov r11, r8
00012822  48c1ea0d                 shr rdx, 0xd
00012826  b940000000               mov ecx, 0x40
0001282b  80e23f                   and dl, 0x3f
0001282e  4d2bd9                   sub r11, r9
00012831  2aca                     sub cl, dl
00012833  4e8d0ccf                 lea r9, [rdi + r9*8]
00012837  48d3eb                   shr rbx, cl
0001283a  4a8d3cc7                 lea rdi, [rdi + r8*8]
0001283e  33ed                     xor ebp, ebp
00012840  498bc9                   mov rcx, r9
00012843  448bc5                   mov r8d, ebp
00012846  4983c301                 add r11, 1
0001284a  744c                     je 0x12898
0001284c  0f1f00                   nop dword ptr [rax]
0001284f  90                       nop
00012850  4c3bc9                   cmp r9, rcx
00012853  0f8552ed0100             jne 0x315ab
00012859  b201                     mov dl, 1
0001285b  4983fb01                 cmp r11, 1
0001285f  0f8557ed0100             jne 0x315bc
00012865  488bc3                   mov rax, rbx
00012868  4823c6                   and rax, rsi
0001286b  eb01                     jmp 0x1286e
0001286d  cc                       int3
0001286e  84d2                     test dl, dl
00012870  0f8435ec0100             je 0x314ab
00012876  4584d2                   test r10b, r10b
00012879  0f8571bf0100             jne 0x2e7f0
0001287f  48f7d0                   not rax
00012882  f0482101                 lock and qword ptr [rcx], rax
00012886  eb01                     jmp 0x12889
00012888  cc                       int3
00012889  41ffc0                   inc r8d
0001288c  4883c108                 add rcx, 8
00012890  418bc0                   mov eax, r8d
00012893  493bc3                   cmp rax, r11
00012896  72b8                     jb 0x12850
00012898  488b6c2418               mov rbp, qword ptr [rsp + 0x18]

; chunk at RVA 0x1289d (5 bytes)
0001289d  488b5c2410               mov rbx, qword ptr [rsp + 0x10]

; chunk at RVA 0x128a2 (7 bytes)
000128a2  488b742420               mov rsi, qword ptr [rsp + 0x20]
000128a7  5f                       pop rdi
000128a8  c3                       ret
