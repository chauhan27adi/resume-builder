; CGlobalTraceFlags::TurnOn
; sqldk.dll, primary RVA 0x1b40e0, 589 bytes in 3 chunk(s)

; chunk at RVA 0x1b40e0 (188 bytes)
001b40e0  4053                     push rbx
001b40e2  55                       push rbp
001b40e3  57                       push rdi
001b40e4  4883ec30                 sub rsp, 0x30
001b40e8  0fb7e9                   movzx ebp, cx
001b40eb  8bda                     mov ebx, edx
001b40ed  b9d6440000               mov ecx, 0x44d6
001b40f2  8d45ff                   lea eax, [rbp - 1]
001b40f5  663bc1                   cmp ax, cx
001b40f8  773f                     ja 0x1b4139
001b40fa  0faee8                   lfence
001b40fd  8d42ff                   lea eax, [rdx - 1]
001b4100  83f801                   cmp eax, 1
001b4103  0f8789000000             ja 0x1b4192
001b4109  0fb7cd                   movzx ecx, bp
001b410c  e85f100000               call 0x1b5170
001b4111  488bf8                   mov rdi, rax
001b4114  4885c0                   test rax, rax
001b4117  743f                     je 0x1b4158
001b4119  488b0de8de1700           mov rcx, qword ptr [rip + 0x17dee8]
001b4120  488b11                   mov rdx, qword ptr [rcx]
001b4123  ff12                     call qword ptr [rdx]
001b4125  f680c301000004           test byte ptr [rax + 0x1c3], 4
001b412c  752a                     jne 0x1b4158
001b412e  83fb01                   cmp ebx, 1
001b4131  7510                     jne 0x1b4143
001b4133  837f0800                 cmp dword ptr [rdi + 8], 0
001b4137  7559                     jne 0x1b4192
001b4139  32c0                     xor al, al
001b413b  4883c430                 add rsp, 0x30
001b413f  5f                       pop rdi
001b4140  5d                       pop rbp
001b4141  5b                       pop rbx
001b4142  c3                       ret
001b4143  83fb02                   cmp ebx, 2
001b4146  754a                     jne 0x1b4192
001b4148  837f0c00                 cmp dword ptr [rdi + 0xc], 0
001b414c  750f                     jne 0x1b415d
001b414e  32c0                     xor al, al
001b4150  4883c430                 add rsp, 0x30
001b4154  5f                       pop rdi
001b4155  5d                       pop rbp
001b4156  5b                       pop rbx
001b4157  c3                       ret
001b4158  83fb02                   cmp ebx, 2
001b415b  7535                     jne 0x1b4192
001b415d  8bcd                     mov ecx, ebp
001b415f  e87cf7fcff               call 0x1838e0
001b4164  488b0d9dde1700           mov rcx, qword ptr [rip + 0x17de9d]
001b416b  4533c9                   xor r9d, r9d
001b416e  4533c0                   xor r8d, r8d
001b4171  8bd5                     mov edx, ebp
001b4173  488b01                   mov rax, qword ptr [rcx]
001b4176  ff5010                   call qword ptr [rax + 0x10]
001b4179  488b1d40792000           mov rbx, qword ptr [rip + 0x207940]
001b4180  4885db                   test rbx, rbx
001b4183  740d                     je 0x1b4192
001b4185  8bcd                     mov ecx, ebp
001b4187  ff5308                   call qword ptr [rbx + 8]
001b418a  488b1b                   mov rbx, qword ptr [rbx]
001b418d  4885db                   test rbx, rbx
001b4190  75f3                     jne 0x1b4185
001b4192  658b042548000000         mov eax, dword ptr gs:[0x48]
001b419a  33db                     xor ebx, ebx

; chunk at RVA 0x1b419c (288 bytes)
001b419c  4889742450               mov qword ptr [rsp + 0x50], rsi
001b41a1  8bf0                     mov esi, eax
001b41a3  8b057f6e2000             mov eax, dword ptr [rip + 0x206e7f]
001b41a9  85c0                     test eax, eax
001b41ab  7518                     jne 0x1b41c5
001b41ad  33c0                     xor eax, eax
001b41af  f0480fb135706e2000       lock cmpxchg qword ptr [rip + 0x206e70], rsi
001b41b8  8bc3                     mov eax, ebx
001b41ba  0f94c0                   sete al
001b41bd  85c0                     test eax, eax
001b41bf  0f85c6000000             jne 0x1b428b
001b41c5  8b052d091600             mov eax, dword ptr [rip + 0x16092d]
001b41cb  33ff                     xor edi, edi
001b41cd  2584000000               and eax, 0x84
001b41d2  3c84                     cmp al, 0x84
001b41d4  7552                     jne 0x1b4228
001b41d6  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
001b41df  8b05eb0d1600             mov eax, dword ptr [rip + 0x160deb]
001b41e5  8b15cdd6e4ff             mov edx, dword ptr [rip - 0x1b2933]
001b41eb  480314c1                 add rdx, qword ptr [rcx + rax*8]
001b41ef  7410                     je 0x1b4201
001b41f1  48399210010000           cmp qword ptr [rdx + 0x110], rdx
001b41f8  7507                     jne 0x1b4201
001b41fa  488bba00010000           mov rdi, qword ptr [rdx + 0x100]
001b4201  4885ff                   test rdi, rdi
001b4204  7422                     je 0x1b4228
001b4206  391db8121600             cmp dword ptr [rip + 0x1612b8], ebx
001b420c  7412                     je 0x1b4220
001b420e  488d4c2460               lea rcx, [rsp + 0x60]
001b4213  ff15b7520800             call qword ptr [rip + 0x852b7]
001b4219  488b5c2460               mov rbx, qword ptr [rsp + 0x60]
001b421e  eb08                     jmp 0x1b4228
001b4220  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
001b4228  f605a808160080           test byte ptr [rip + 0x1608a8], 0x80
001b422f  488d0df26d2000           lea rcx, [rip + 0x206df2]
001b4236  740d                     je 0x1b4245
001b4238  4c8bc6                   mov r8, rsi
001b423b  488bd7                   mov rdx, rdi
001b423e  e8dd090000               call 0x1b4c20
001b4243  eb08                     jmp 0x1b424d
001b4245  488bd6                   mov rdx, rsi
001b4248  e8d30b0000               call 0x1b4e20
001b424d  4885ff                   test rdi, rdi
001b4250  7439                     je 0x1b428b
001b4252  833d6b12160000           cmp dword ptr [rip + 0x16126b], 0
001b4259  7412                     je 0x1b426d
001b425b  488d4c2468               lea rcx, [rsp + 0x68]
001b4260  ff156a520800             call qword ptr [rip + 0x8526a]
001b4266  488b4c2468               mov rcx, qword ptr [rsp + 0x68]
001b426b  eb08                     jmp 0x1b4275
001b426d  488b0c250800fe7f         mov rcx, qword ptr [0x7ffe0008]
001b4275  33c0                     xor eax, eax
001b4277  488bd1                   mov rdx, rcx
001b427a  482bd3                   sub rdx, rbx
001b427d  483bcb                   cmp rcx, rbx
001b4280  480f43c2                 cmovae rax, rdx
001b4284  480187780c0000           add qword ptr [rdi + 0xc78], rax
001b428b  488b0d76dd1700           mov rcx, qword ptr [rip + 0x17dd76]
001b4292  488b01                   mov rax, qword ptr [rcx]
001b4295  ff10                     call qword ptr [rax]
001b4297  488b742450               mov rsi, qword ptr [rsp + 0x50]
001b429c  488bcd                   mov rcx, rbp
001b429f  48c1e903                 shr rcx, 3
001b42a3  4803c1                   add rax, rcx
001b42a6  8bcd                     mov ecx, ebp
001b42a8  83e107                   and ecx, 7
001b42ab  0fb610                   movzx edx, byte ptr [rax]
001b42ae  0fabca                   bts edx, ecx
001b42b1  8810                     mov byte ptr [rax], dl
001b42b3  803d0712160000           cmp byte ptr [rip + 0x161207], 0
001b42ba  7427                     je 0x1b42e3

; chunk at RVA 0x1b42bc (113 bytes)
001b42bc  ff1586570800             call qword ptr [rip + 0x85786]
001b42c2  448bc0                   mov r8d, eax
001b42c5  b867666666               mov eax, 0x66666667
001b42ca  41f7e8                   imul r8d
001b42cd  d1fa                     sar edx, 1
001b42cf  8bca                     mov ecx, edx
001b42d1  c1e91f                   shr ecx, 0x1f
001b42d4  03d1                     add edx, ecx
001b42d6  8d0c92                   lea ecx, [rdx + rdx*4]
001b42d9  443bc1                   cmp r8d, ecx
001b42dc  7505                     jne 0x1b42e3
001b42de  e86d0d0000               call 0x1b5050
001b42e3  8bcd                     mov ecx, ebp
001b42e5  48c705386d200000000000   mov qword ptr [rip + 0x206d38], 0
001b42f0  e8ebf5fcff               call 0x1838e0
001b42f5  488b0d0cdd1700           mov rcx, qword ptr [rip + 0x17dd0c]
001b42fc  4533c9                   xor r9d, r9d
001b42ff  4533c0                   xor r8d, r8d
001b4302  8bd5                     mov edx, ebp
001b4304  488b01                   mov rax, qword ptr [rcx]
001b4307  ff5010                   call qword ptr [rax + 0x10]
001b430a  488b1daf772000           mov rbx, qword ptr [rip + 0x2077af]
001b4311  4885db                   test rbx, rbx
001b4314  740d                     je 0x1b4323
001b4316  8bcd                     mov ecx, ebp
001b4318  ff5308                   call qword ptr [rbx + 8]
001b431b  488b1b                   mov rbx, qword ptr [rbx]
001b431e  4885db                   test rbx, rbx
001b4321  75f3                     jne 0x1b4316
001b4323  b001                     mov al, 1
001b4325  4883c430                 add rsp, 0x30
001b4329  5f                       pop rdi
001b432a  5d                       pop rbp
001b432b  5b                       pop rbx
001b432c  c3                       ret
