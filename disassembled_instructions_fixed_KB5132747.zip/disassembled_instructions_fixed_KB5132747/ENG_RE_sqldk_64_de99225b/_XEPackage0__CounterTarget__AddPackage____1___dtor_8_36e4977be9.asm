; `XEPackage0::CounterTarget::AddPackage'::`1'::dtor$8
; sqldk.dll, primary RVA 0x2319a2, 45 bytes in 1 chunk(s)

; chunk at RVA 0x2319a2 (45 bytes)
002319a2  4055                     push rbp
002319a4  4883ec20                 sub rsp, 0x20
002319a8  488bea                   mov rbp, rdx
002319ab  488b8db0000000           mov rcx, qword ptr [rbp + 0xb0]
002319b2  4c8d0dd759e1ff           lea r9, [rip - 0x1ea629]
002319b9  41b880000000             mov r8d, 0x80
002319bf  ba18000000               mov edx, 0x18
002319c4  e8572edfff               call 0x24820
002319c9  4883c420                 add rsp, 0x20
002319cd  5d                       pop rbp
002319ce  c3                       ret
