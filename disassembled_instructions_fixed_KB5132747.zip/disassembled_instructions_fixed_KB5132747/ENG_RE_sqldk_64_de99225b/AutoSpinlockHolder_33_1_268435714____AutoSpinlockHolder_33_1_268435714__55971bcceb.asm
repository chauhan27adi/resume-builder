; AutoSpinlockHolder<33,1,268435714>::~AutoSpinlockHolder<33,1,268435714>
; sqldk.dll, primary RVA 0x1748d0, 27 bytes in 1 chunk(s)

; chunk at RVA 0x1748d0 (27 bytes)
001748d0  48894c2408               mov qword ptr [rsp + 8], rcx
001748d5  4883ec38                 sub rsp, 0x38
001748d9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001748e2  4883c438                 add rsp, 0x38
001748e6  e9455e0000               jmp 0x17a730
