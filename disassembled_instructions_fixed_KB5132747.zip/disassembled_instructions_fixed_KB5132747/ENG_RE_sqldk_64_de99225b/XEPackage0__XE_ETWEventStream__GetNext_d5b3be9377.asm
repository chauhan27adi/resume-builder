; XEPackage0::XE_ETWEventStream::GetNext
; sqldk.dll, primary RVA 0x1c08a0, 1132 bytes in 6 chunk(s)

; chunk at RVA 0x1c08a0 (281 bytes)
001c08a0  4053                     push rbx
001c08a2  56                       push rsi
001c08a3  57                       push rdi
001c08a4  4156                     push r14
001c08a6  4883ec28                 sub rsp, 0x28
001c08aa  33f6                     xor esi, esi
001c08ac  4d8bd0                   mov r10, r8
001c08af  488bfa                   mov rdi, rdx
001c08b2  488bd9                   mov rbx, rcx
001c08b5  49397010                 cmp qword ptr [r8 + 0x10], rsi
001c08b9  744f                     je 0x1c090a
001c08bb  4d8b08                   mov r9, qword ptr [r8]
001c08be  4d85c9                   test r9, r9
001c08c1  7447                     je 0x1c090a
001c08c3  4d8b5820                 mov r11, qword ptr [r8 + 0x20]
001c08c7  448bc6                   mov r8d, esi
001c08ca  660f1f440000             nop word ptr [rax + rax]
001c08d0  418bc0                   mov eax, r8d
001c08d3  4869c83fff0000           imul rcx, rax, 0xff3f
001c08da  4903cb                   add rcx, r11
001c08dd  493bc9                   cmp rcx, r9
001c08e0  7409                     je 0x1c08eb
001c08e2  41ffc0                   inc r8d
001c08e5  4183f810                 cmp r8d, 0x10
001c08e9  72e5                     jb 0x1c08d0
001c08eb  418bc8                   mov ecx, r8d
001c08ee  418bc0                   mov eax, r8d
001c08f1  83e11f                   and ecx, 0x1f
001c08f4  ba01000000               mov edx, 1
001c08f9  d3e2                     shl edx, cl
001c08fb  f7d2                     not edx
001c08fd  48c1e805                 shr rax, 5
001c0901  f041219483f0f30f00       lock and dword ptr [r11 + rax*4 + 0xff3f0], edx
001c090a  498932                   mov qword ptr [r10], rsi
001c090d  4c8d1decf6e3ff           lea r11, [rip - 0x1c0914]
001c0914  41897208                 mov dword ptr [r10 + 8], esi
001c0918  41beff030000             mov r14d, 0x3ff
001c091e  49897210                 mov qword ptr [r10 + 0x10], rsi
001c0922  41c7421c01000000         mov dword ptr [r10 + 0x1c], 1
001c092a  6641897218               mov word ptr [r10 + 0x18], si
001c092f  48634320                 movsxd rax, dword ptr [rbx + 0x20]
001c0933  8bd0                     mov edx, eax
001c0935  83f808                   cmp eax, 8
001c0938  0f879d010000             ja 0x1c0adb
001c093e  418b8c83c00c1c00         mov ecx, dword ptr [r11 + rax*4 + 0x1c0cc0]
001c0946  4903cb                   add rcx, r11
001c0949  ffe1                     jmp rcx
001c094b  c7432001000000           mov dword ptr [rbx + 0x20], 1
001c0952  488b5308                 mov rdx, qword ptr [rbx + 8]
001c0956  440fb74a26               movzx r9d, word ptr [rdx + 0x26]
001c095b  664585c9                 test r9w, r9w
001c095f  0f8473020000             je 0x1c0bd8
001c0965  488b03                   mov rax, qword ptr [rbx]
001c0968  0fb74b18                 movzx ecx, word ptr [rbx + 0x18]
001c096c  48c1e104                 shl rcx, 4
001c0970  48034810                 add rcx, qword ptr [rax + 0x10]
001c0974  6683780201               cmp word ptr [rax + 2], 1
001c0979  4c8b01                   mov r8, qword ptr [rcx]
001c097c  0f86ff010000             jbe 0x1c0b81
001c0982  488b4240                 mov rax, qword ptr [rdx + 0x40]
001c0986  4b8d0c89                 lea rcx, [r9 + r9*4]
001c098a  440fb74cc810             movzx r9d, word ptr [rax + rcx*8 + 0x10]
001c0990  e9f0010000               jmp 0x1c0b85
001c0995  488bcb                   mov rcx, rbx
001c0998  e883030000               call 0x1c0d20
001c099d  8bd0                     mov edx, eax
001c099f  894320                   mov dword ptr [rbx + 0x20], eax
001c09a2  e934010000               jmp 0x1c0adb
001c09a7  c7432003000000           mov dword ptr [rbx + 0x20], 3
001c09ae  488b03                   mov rax, qword ptr [rbx]
001c09b1  0fb77b18                 movzx edi, word ptr [rbx + 0x18]
001c09b5  48c1e704                 shl rdi, 4

; chunk at RVA 0x1c09b9 (210 bytes)
001c09b9  4c89642468               mov qword ptr [rsp + 0x68], r12
001c09be  48037810                 add rdi, qword ptr [rax + 0x10]
001c09c2  4c8b6308                 mov r12, qword ptr [rbx + 8]
001c09c6  6639770e                 cmp word ptr [rdi + 0xe], si
001c09ca  0f844b020000             je 0x1c0c1b
001c09d0  397708                   cmp dword ptr [rdi + 8], esi
001c09d3  0f8642020000             jbe 0x1c0c1b
001c09d9  48896c2458               mov qword ptr [rsp + 0x58], rbp
001c09de  448bde                   mov r11d, esi
001c09e1  498b6a20                 mov rbp, qword ptr [r10 + 0x20]
001c09e5  4c897c2420               mov qword ptr [rsp + 0x20], r15
001c09ea  4c8bfe                   mov r15, rsi
001c09ed  0f1f00                   nop dword ptr [rax]
001c09f0  418bc3                   mov eax, r11d
001c09f3  4c8d0c8500000000         lea r9, [rax*4]
001c09fb  0f1f440000               nop dword ptr [rax + rax]
001c0a00  458b8429f0f30f00         mov r8d, dword ptr [r9 + rbp + 0xff3f0]
001c0a08  418bc0                   mov eax, r8d
001c0a0b  f7d0                     not eax
001c0a0d  8bc8                     mov ecx, eax
001c0a0f  f7d9                     neg ecx
001c0a11  23c8                     and ecx, eax
001c0a13  4585db                   test r11d, r11d
001c0a16  0fb7d1                   movzx edx, cx
001c0a19  0f45d1                   cmovne edx, ecx
001c0a1c  85d2                     test edx, edx
001c0a1e  0f84e4010000             je 0x1c0c08
001c0a24  8bca                     mov ecx, edx
001c0a26  418bc0                   mov eax, r8d
001c0a29  410bc8                   or ecx, r8d
001c0a2c  f0410fb18c29f0f30f00     lock cmpxchg dword ptr [r9 + rbp + 0xff3f0], ecx
001c0a36  75c8                     jne 0x1c0a00
001c0a38  0fbcc2                   bsf eax, edx
001c0a3b  41c1e305                 shl r11d, 5
001c0a3f  4103c3                   add eax, r11d
001c0a42  4c69f83fff0000           imul r15, rax, 0xff3f
001c0a49  4c03fd                   add r15, rbp
001c0a4c  4d893a                   mov qword ptr [r10], r15
001c0a4f  8b4708                   mov eax, dword ptr [rdi + 8]
001c0a52  41894208                 mov dword ptr [r10 + 8], eax
001c0a56  488b17                   mov rdx, qword ptr [rdi]
001c0a59  49895210                 mov qword ptr [r10 + 0x10], rdx
001c0a5d  664523742404             and r14w, word ptr [r12 + 4]
001c0a63  410fb7ce                 movzx ecx, r14w
001c0a67  6645897218               mov word ptr [r10 + 0x18], r14w
001c0a6c  ff15e6461500             call qword ptr [rip + 0x1546e6]
001c0a72  66ff4318                 inc word ptr [rbx + 0x18]
001c0a76  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
001c0a7b  488b6c2458               mov rbp, qword ptr [rsp + 0x58]
001c0a80  4c8b642468               mov r12, qword ptr [rsp + 0x68]
001c0a85  e9bf000000               jmp 0x1c0b49
001c0a8a  cc                       int3

; chunk at RVA 0x1c0a8b (381 bytes)
001c0a8b  488b03                   mov rax, qword ptr [rbx]
001c0a8e  0fb75318                 movzx edx, word ptr [rbx + 0x18]
001c0a92  4803d2                   add rdx, rdx
001c0a95  488b4810                 mov rcx, qword ptr [rax + 0x10]
001c0a99  0fb744d1fc               movzx eax, word ptr [rcx + rdx*8 - 4]
001c0a9e  488d1480                 lea rdx, [rax + rax*4]
001c0aa2  488b4308                 mov rax, qword ptr [rbx + 8]
001c0aa6  488b4840                 mov rcx, qword ptr [rax + 0x40]
001c0aaa  448b04d1                 mov r8d, dword ptr [rcx + rdx*8]
001c0aae  418bc8                   mov ecx, r8d
001c0ab1  81e100fcff0f             and ecx, 0xffffc00
001c0ab7  81f900500000             cmp ecx, 0x5000
001c0abd  7533                     jne 0x1c0af2
001c0abf  4585c6                   test r14d, r8d
001c0ac2  752e                     jne 0x1c0af2
001c0ac4  418bc0                   mov eax, r8d
001c0ac7  25000000f0               and eax, 0xf0000000
001c0acc  3d00000060               cmp eax, 0x60000000
001c0ad1  751f                     jne 0x1c0af2
001c0ad3  ba05000000               mov edx, 5
001c0ad8  895320                   mov dword ptr [rbx + 0x20], edx
001c0adb  ffca                     dec edx
001c0add  83fa06                   cmp edx, 6
001c0ae0  7767                     ja 0x1c0b49
001c0ae2  4863c2                   movsxd rax, edx
001c0ae5  418b8c83f00c1c00         mov ecx, dword ptr [r11 + rax*4 + 0x1c0cf0]
001c0aed  4903cb                   add rcx, r11
001c0af0  ffe1                     jmp rcx
001c0af2  418bc0                   mov eax, r8d
001c0af5  41c1e81c                 shr r8d, 0x1c
001c0af9  4123c6                   and eax, r14d
001c0afc  81f9004c0000             cmp ecx, 0x4c00
001c0b02  750f                     jne 0x1c0b13
001c0b04  85c0                     test eax, eax
001c0b06  750b                     jne 0x1c0b13
001c0b08  4183f806                 cmp r8d, 6
001c0b0c  7505                     jne 0x1c0b13
001c0b0e  8d5004                   lea edx, [rax + 4]
001c0b11  ebc5                     jmp 0x1c0ad8
001c0b13  488bcb                   mov rcx, rbx
001c0b16  e805020000               call 0x1c0d20
001c0b1b  8bd0                     mov edx, eax
001c0b1d  ebb9                     jmp 0x1c0ad8
001c0b1f  c7432007000000           mov dword ptr [rbx + 0x20], 7
001c0b26  488b0b                   mov rcx, qword ptr [rbx]
001c0b29  440fb7431a               movzx r8d, word ptr [rbx + 0x1a]
001c0b2e  49c1e004                 shl r8, 4
001c0b32  4c034118                 add r8, qword ptr [rcx + 0x18]
001c0b36  498b4808                 mov rcx, qword ptr [r8 + 8]
001c0b3a  418b5004                 mov edx, dword ptr [r8 + 4]
001c0b3e  49890a                   mov qword ptr [r10], rcx
001c0b41  41895208                 mov dword ptr [r10 + 8], edx
001c0b45  66ff431a                 inc word ptr [rbx + 0x1a]
001c0b49  837b2008                 cmp dword ptr [rbx + 0x20], 8
001c0b4d  400f95c6                 setne sil
001c0b51  8bc6                     mov eax, esi
001c0b53  4883c428                 add rsp, 0x28
001c0b57  415e                     pop r14
001c0b59  5f                       pop rdi
001c0b5a  5e                       pop rsi
001c0b5b  5b                       pop rbx
001c0b5c  c3                       ret
001c0b5d  0fb7431c                 movzx eax, word ptr [rbx + 0x1c]
001c0b61  ba08000000               mov edx, 8
001c0b66  6639431a                 cmp word ptr [rbx + 0x1a], ax
001c0b6a  b906000000               mov ecx, 6
001c0b6f  0f42d1                   cmovb edx, ecx
001c0b72  e961ffffff               jmp 0x1c0ad8
001c0b77  ba08000000               mov edx, 8
001c0b7c  895320                   mov dword ptr [rbx + 0x20], edx
001c0b7f  ebc8                     jmp 0x1c0b49
001c0b81  448b4908                 mov r9d, dword ptr [rcx + 8]
001c0b85  66837a2401               cmp word ptr [rdx + 0x24], 1
001c0b8a  7645                     jbe 0x1c0bd1
001c0b8c  488b4240                 mov rax, qword ptr [rdx + 0x40]
001c0b90  8b00                     mov eax, dword ptr [rax]
001c0b92  a900fcff0f               test eax, 0xffffc00
001c0b97  7538                     jne 0x1c0bd1
001c0b99  4185c6                   test r14d, eax
001c0b9c  7533                     jne 0x1c0bd1
001c0b9e  25000000f0               and eax, 0xf0000000
001c0ba3  3d00000030               cmp eax, 0x30000000
001c0ba8  7527                     jne 0x1c0bd1
001c0baa  410fb600                 movzx eax, byte ptr [r8]
001c0bae  884705                   mov byte ptr [rdi + 5], al
001c0bb1  410fb64001               movzx eax, byte ptr [r8 + 1]
001c0bb6  884704                   mov byte ptr [rdi + 4], al
001c0bb9  498d4002                 lea rax, [r8 + 2]
001c0bbd  498902                   mov qword ptr [r10], rax
001c0bc0  418d41fe                 lea eax, [r9 - 2]
001c0bc4  41894208                 mov dword ptr [r10 + 8], eax
001c0bc8  66ff4318                 inc word ptr [rbx + 0x18]
001c0bcc  e978ffffff               jmp 0x1c0b49
001c0bd1  4d8902                   mov qword ptr [r10], r8
001c0bd4  45894a08                 mov dword ptr [r10 + 8], r9d
001c0bd8  66ff4318                 inc word ptr [rbx + 0x18]
001c0bdc  e968ffffff               jmp 0x1c0b49
001c0be1  488b03                   mov rax, qword ptr [rbx]
001c0be4  0fb75318                 movzx edx, word ptr [rbx + 0x18]
001c0be8  48c1e204                 shl rdx, 4
001c0bec  488b4010                 mov rax, qword ptr [rax + 0x10]
001c0bf0  4883c008                 add rax, 8
001c0bf4  41c7420804000000         mov dword ptr [r10 + 8], 4
001c0bfc  4803c2                   add rax, rdx
001c0bff  498902                   mov qword ptr [r10], rax
001c0c02  e942ffffff               jmp 0x1c0b49
001c0c07  cc                       int3

; chunk at RVA 0x1c0c08 (19 bytes)
001c0c08  41ffc3                   inc r11d
001c0c0b  4183fb01                 cmp r11d, 1
001c0c0f  0f82dbfdffff             jb 0x1c09f0
001c0c15  e932feffff               jmp 0x1c0a4c
001c0c1a  cc                       int3

; chunk at RVA 0x1c0c1b (28 bytes)
001c0c1b  488b07                   mov rax, qword ptr [rdi]
001c0c1e  8b4f08                   mov ecx, dword ptr [rdi + 8]
001c0c21  4c8b642468               mov r12, qword ptr [rsp + 0x68]
001c0c26  498902                   mov qword ptr [r10], rax
001c0c29  41894a08                 mov dword ptr [r10 + 8], ecx
001c0c2d  66ff4318                 inc word ptr [rbx + 0x18]
001c0c31  e913ffffff               jmp 0x1c0b49
001c0c36  cc                       int3

; chunk at RVA 0x1c0c37 (213 bytes)
001c0c37  488d05748f0e00           lea rax, [rip + 0xe8f74]
001c0c3e  41c7420801000000         mov dword ptr [r10 + 8], 1
001c0c46  498902                   mov qword ptr [r10], rax
001c0c49  e9fbfeffff               jmp 0x1c0b49
001c0c4e  488d055b8f0e00           lea rax, [rip + 0xe8f5b]
001c0c55  41c7420802000000         mov dword ptr [r10 + 8], 2
001c0c5d  498902                   mov qword ptr [r10], rax
001c0c60  e9e4feffff               jmp 0x1c0b49
001c0c65  488b03                   mov rax, qword ptr [rbx]
001c0c68  488d5324                 lea rdx, [rbx + 0x24]
001c0c6c  440fb7431a               movzx r8d, word ptr [rbx + 0x1a]
001c0c71  49c1e004                 shl r8, 4
001c0c75  4c034018                 add r8, qword ptr [rax + 0x18]
001c0c79  8b83a4010000             mov eax, dword ptr [rbx + 0x1a4]
001c0c7f  83e00f                   and eax, 0xf
001c0c82  488d0440                 lea rax, [rax + rax*2]
001c0c86  488d14c2                 lea rdx, [rdx + rax*8]
001c0c8a  418b00                   mov eax, dword ptr [r8]
001c0c8d  894210                   mov dword ptr [rdx + 0x10], eax
001c0c90  4923c6                   and rax, r14
001c0c93  486bc838                 imul rcx, rax, 0x38
001c0c97  488b4310                 mov rax, qword ptr [rbx + 0x10]
001c0c9b  0f10440110               movups xmm0, xmmword ptr [rcx + rax + 0x10]
001c0ca0  0f1102                   movups xmmword ptr [rdx], xmm0
001c0ca3  418b4004                 mov eax, dword ptr [r8 + 4]
001c0ca7  894214                   mov dword ptr [rdx + 0x14], eax
001c0caa  498912                   mov qword ptr [r10], rdx
001c0cad  41c7420818000000         mov dword ptr [r10 + 8], 0x18
001c0cb5  ff83a4010000             inc dword ptr [rbx + 0x1a4]
001c0cbb  e989feffff               jmp 0x1c0b49
001c0cc0  4b091c00                 or qword ptr [r8 + r8], rbx
001c0cc4  95                       xchg ebp, eax
001c0cc5  091c00                   or dword ptr [rax + rax], ebx
001c0cc8  a7                       cmpsd dword ptr [rsi], dword ptr [rdi]
001c0cc9  091c00                   or dword ptr [rax + rax], ebx
001c0ccc  8b0a                     mov ecx, dword ptr [rdx]
001c0cce  1c00                     sbb al, 0
001c0cd0  95                       xchg ebp, eax
001c0cd1  091c00                   or dword ptr [rax + rax], ebx
001c0cd4  95                       xchg ebp, eax
001c0cd5  091c00                   or dword ptr [rax + rax], ebx
