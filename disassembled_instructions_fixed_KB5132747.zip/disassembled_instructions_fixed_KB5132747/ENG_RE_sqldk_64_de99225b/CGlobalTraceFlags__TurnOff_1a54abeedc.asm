; CGlobalTraceFlags::TurnOff
; sqldk.dll, primary RVA 0x1b43a0, 576 bytes in 4 chunk(s)

; chunk at RVA 0x1b43a0 (149 bytes)
001b43a0  4053                     push rbx
001b43a2  55                       push rbp
001b43a3  57                       push rdi
001b43a4  4883ec30                 sub rsp, 0x30
001b43a8  0fb7e9                   movzx ebp, cx
001b43ab  b9d6440000               mov ecx, 0x44d6
001b43b0  8d45ff                   lea eax, [rbp - 1]
001b43b3  663bc1                   cmp ax, cx
001b43b6  0f871b020000             ja 0x1b45d7
001b43bc  0faee8                   lfence
001b43bf  83fa02                   cmp edx, 2
001b43c2  7569                     jne 0x1b442d
001b43c4  0fb7cd                   movzx ecx, bp
001b43c7  e8a40d0000               call 0x1b5170
001b43cc  488bd8                   mov rbx, rax
001b43cf  4885c0                   test rax, rax
001b43d2  741f                     je 0x1b43f3
001b43d4  488b0d2ddc1700           mov rcx, qword ptr [rip + 0x17dc2d]
001b43db  488b11                   mov rdx, qword ptr [rcx]
001b43de  ff12                     call qword ptr [rdx]
001b43e0  f680c301000004           test byte ptr [rax + 0x1c3], 4
001b43e7  750a                     jne 0x1b43f3
001b43e9  837b0c00                 cmp dword ptr [rbx + 0xc], 0
001b43ed  0f84e4010000             je 0x1b45d7
001b43f3  8bcd                     mov ecx, ebp
001b43f5  e8c6f8fcff               call 0x183cc0
001b43fa  488b0d07dc1700           mov rcx, qword ptr [rip + 0x17dc07]
001b4401  4533c9                   xor r9d, r9d
001b4404  8bd5                     mov edx, ebp
001b4406  488b01                   mov rax, qword ptr [rcx]
001b4409  458d4101                 lea r8d, [r9 + 1]
001b440d  ff5010                   call qword ptr [rax + 0x10]
001b4410  488b1da9762000           mov rbx, qword ptr [rip + 0x2076a9]
001b4417  4885db                   test rbx, rbx
001b441a  7411                     je 0x1b442d
001b441c  0f1f00                   nop dword ptr [rax]
001b441f  90                       nop
001b4420  8bcd                     mov ecx, ebp
001b4422  ff5308                   call qword ptr [rbx + 8]
001b4425  488b1b                   mov rbx, qword ptr [rbx]
001b4428  4885db                   test rbx, rbx
001b442b  75f3                     jne 0x1b4420
001b442d  658b042548000000         mov eax, dword ptr gs:[0x48]

; chunk at RVA 0x1b4435 (299 bytes)
001b4435  4889742450               mov qword ptr [rsp + 0x50], rsi
001b443a  4c89742458               mov qword ptr [rsp + 0x58], r14
001b443f  4533f6                   xor r14d, r14d
001b4442  8bf0                     mov esi, eax
001b4444  418bde                   mov ebx, r14d
001b4447  8b05db6b2000             mov eax, dword ptr [rip + 0x206bdb]
001b444d  85c0                     test eax, eax
001b444f  7519                     jne 0x1b446a
001b4451  33c0                     xor eax, eax
001b4453  f0480fb135cc6b2000       lock cmpxchg qword ptr [rip + 0x206bcc], rsi
001b445c  418bc6                   mov eax, r14d
001b445f  0f94c0                   sete al
001b4462  85c0                     test eax, eax
001b4464  0f85c5000000             jne 0x1b452f
001b446a  8b0588061600             mov eax, dword ptr [rip + 0x160688]
001b4470  498bfe                   mov rdi, r14
001b4473  2584000000               and eax, 0x84
001b4478  3c84                     cmp al, 0x84
001b447a  7552                     jne 0x1b44ce
001b447c  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
001b4485  8b05450b1600             mov eax, dword ptr [rip + 0x160b45]
001b448b  8b1527d4e4ff             mov edx, dword ptr [rip - 0x1b2bd9]
001b4491  480314c1                 add rdx, qword ptr [rcx + rax*8]
001b4495  7410                     je 0x1b44a7
001b4497  48399210010000           cmp qword ptr [rdx + 0x110], rdx
001b449e  7507                     jne 0x1b44a7
001b44a0  488bba00010000           mov rdi, qword ptr [rdx + 0x100]
001b44a7  4885ff                   test rdi, rdi
001b44aa  7422                     je 0x1b44ce
001b44ac  391d12101600             cmp dword ptr [rip + 0x161012], ebx
001b44b2  7412                     je 0x1b44c6
001b44b4  488d4c2460               lea rcx, [rsp + 0x60]
001b44b9  ff1511500800             call qword ptr [rip + 0x85011]
001b44bf  488b5c2460               mov rbx, qword ptr [rsp + 0x60]
001b44c4  eb08                     jmp 0x1b44ce
001b44c6  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
001b44ce  f6050206160080           test byte ptr [rip + 0x160602], 0x80
001b44d5  488d0d4c6b2000           lea rcx, [rip + 0x206b4c]
001b44dc  740d                     je 0x1b44eb
001b44de  4c8bc6                   mov r8, rsi
001b44e1  488bd7                   mov rdx, rdi
001b44e4  e837070000               call 0x1b4c20
001b44e9  eb08                     jmp 0x1b44f3
001b44eb  488bd6                   mov rdx, rsi
001b44ee  e82d090000               call 0x1b4e20
001b44f3  4885ff                   test rdi, rdi
001b44f6  7437                     je 0x1b452f
001b44f8  443935c50f1600           cmp dword ptr [rip + 0x160fc5], r14d
001b44ff  7412                     je 0x1b4513
001b4501  488d4c2468               lea rcx, [rsp + 0x68]
001b4506  ff15c44f0800             call qword ptr [rip + 0x84fc4]
001b450c  488b442468               mov rax, qword ptr [rsp + 0x68]
001b4511  eb08                     jmp 0x1b451b
001b4513  488b04250800fe7f         mov rax, qword ptr [0x7ffe0008]
001b451b  488bc8                   mov rcx, rax
001b451e  482bcb                   sub rcx, rbx
001b4521  483bc3                   cmp rax, rbx
001b4524  490f42ce                 cmovb rcx, r14
001b4528  48018f780c0000           add qword ptr [rdi + 0xc78], rcx
001b452f  488b0dd2da1700           mov rcx, qword ptr [rip + 0x17dad2]
001b4536  488b01                   mov rax, qword ptr [rcx]
001b4539  ff10                     call qword ptr [rax]
001b453b  488b742450               mov rsi, qword ptr [rsp + 0x50]
001b4540  488bcd                   mov rcx, rbp
001b4543  48c1e903                 shr rcx, 3
001b4547  4803c1                   add rax, rcx
001b454a  8bcd                     mov ecx, ebp
001b454c  83e107                   and ecx, 7
001b454f  0fb610                   movzx edx, byte ptr [rax]
001b4552  0fb3ca                   btr edx, ecx
001b4555  8810                     mov byte ptr [rax], dl
001b4557  443835630f1600           cmp byte ptr [rip + 0x160f63], r14b
001b455e  7427                     je 0x1b4587

; chunk at RVA 0x1b4560 (95 bytes)
001b4560  ff15e2540800             call qword ptr [rip + 0x854e2]
001b4566  448bc8                   mov r9d, eax
001b4569  b867666666               mov eax, 0x66666667
001b456e  41f7e9                   imul r9d
001b4571  d1fa                     sar edx, 1
001b4573  8bca                     mov ecx, edx
001b4575  c1e91f                   shr ecx, 0x1f
001b4578  03d1                     add edx, ecx
001b457a  8d0c92                   lea ecx, [rdx + rdx*4]
001b457d  443bc9                   cmp r9d, ecx
001b4580  7505                     jne 0x1b4587
001b4582  e8c90a0000               call 0x1b5050
001b4587  8bcd                     mov ecx, ebp
001b4589  4c8935986a2000           mov qword ptr [rip + 0x206a98], r14
001b4590  e82bf7fcff               call 0x183cc0
001b4595  488b0d6cda1700           mov rcx, qword ptr [rip + 0x17da6c]
001b459c  4533c9                   xor r9d, r9d
001b459f  8bd5                     mov edx, ebp
001b45a1  488b01                   mov rax, qword ptr [rcx]
001b45a4  458d4101                 lea r8d, [r9 + 1]
001b45a8  ff5010                   call qword ptr [rax + 0x10]
001b45ab  488b1d0e752000           mov rbx, qword ptr [rip + 0x20750e]
001b45b2  4c8b742458               mov r14, qword ptr [rsp + 0x58]
001b45b7  4885db                   test rbx, rbx
001b45ba  7411                     je 0x1b45cd
001b45bc  0f1f00                   nop dword ptr [rax]

; chunk at RVA 0x1b45c0 (33 bytes)
001b45c0  8bcd                     mov ecx, ebp
001b45c2  ff5308                   call qword ptr [rbx + 8]
001b45c5  488b1b                   mov rbx, qword ptr [rbx]
001b45c8  4885db                   test rbx, rbx
001b45cb  75f3                     jne 0x1b45c0
001b45cd  b001                     mov al, 1
001b45cf  4883c430                 add rsp, 0x30
001b45d3  5f                       pop rdi
001b45d4  5d                       pop rbp
001b45d5  5b                       pop rbx
001b45d6  c3                       ret
001b45d7  32c0                     xor al, al
001b45d9  4883c430                 add rsp, 0x30
001b45dd  5f                       pop rdi
001b45de  5d                       pop rbp
001b45df  5b                       pop rbx
001b45e0  c3                       ret
