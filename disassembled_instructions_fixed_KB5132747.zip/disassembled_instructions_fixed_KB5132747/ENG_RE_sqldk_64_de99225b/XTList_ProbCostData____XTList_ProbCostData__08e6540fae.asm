; XTList<ProbCostData>::~XTList<ProbCostData>
; sqldk.dll, primary RVA 0x6b410, 28 bytes in 1 chunk(s)

; chunk at RVA 0x6b410 (28 bytes)
0006b410  48894c2408               mov qword ptr [rsp + 8], rcx
0006b415  4883ec18                 sub rsp, 0x18
0006b419  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
0006b421  c701adde0080             mov dword ptr [rcx], 0x8000dead
0006b427  4883c418                 add rsp, 0x18
0006b42b  c3                       ret
