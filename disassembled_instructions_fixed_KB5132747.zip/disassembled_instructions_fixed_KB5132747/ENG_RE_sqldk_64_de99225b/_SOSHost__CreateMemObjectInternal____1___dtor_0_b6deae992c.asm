; `SOSHost::CreateMemObjectInternal'::`1'::dtor$0
; sqldk.dll, primary RVA 0x229610, 53 bytes in 1 chunk(s)

; chunk at RVA 0x229610 (53 bytes)
00229610  4055                     push rbp
00229612  4883ec30                 sub rsp, 0x30
00229616  488bea                   mov rbp, rdx
00229619  c644242806               mov byte ptr [rsp + 0x28], 6
0022961e  8b4530                   mov eax, dword ptr [rbp + 0x30]
00229621  89442420                 mov dword ptr [rsp + 0x20], eax
00229625  4c8d0db4050700           lea r9, [rip + 0x705b4]
0022962c  41b801000000             mov r8d, 1
00229632  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00229636  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0022963a  e8d1d8ddff               call 0x6f10
0022963f  4883c430                 add rsp, 0x30
00229643  5d                       pop rbp
00229644  c3                       ret
