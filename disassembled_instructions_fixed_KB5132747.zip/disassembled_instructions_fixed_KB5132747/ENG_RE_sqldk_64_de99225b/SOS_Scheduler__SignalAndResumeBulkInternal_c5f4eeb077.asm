; SOS_Scheduler::SignalAndResumeBulkInternal
; sqldk.dll, primary RVA 0x1e6a0, 346 bytes in 3 chunk(s)

; chunk at RVA 0x1e6a0 (78 bytes)
0001e6a0  4053                     push rbx
0001e6a2  55                       push rbp
0001e6a3  56                       push rsi
0001e6a4  57                       push rdi
0001e6a5  b8d8400000               mov eax, 0x40d8
0001e6aa  e84126ffff               call 0x10cf0
0001e6af  482be0                   sub rsp, rax
0001e6b2  488b05cf292f00           mov rax, qword ptr [rip + 0x2f29cf]
0001e6b9  4833c4                   xor rax, rsp
0001e6bc  48898424c0400000         mov qword ptr [rsp + 0x40c0], rax
0001e6c4  488b5908                 mov rbx, qword ptr [rcx + 8]
0001e6c8  8bea                     mov ebp, edx
0001e6ca  33d2                     xor edx, edx
0001e6cc  488bf1                   mov rsi, rcx
0001e6cf  483bd9                   cmp rbx, rcx
0001e6d2  418bf8                   mov edi, r8d
0001e6d5  488d4c2420               lea rcx, [rsp + 0x20]
0001e6da  0f84ef000000             je 0x1e7cf
0001e6e0  e80bfcffff               call 0x1e2f0
0001e6e5  4885db                   test rbx, rbx
0001e6e8  0f84e9000000             je 0x1e7d7

; chunk at RVA 0x1e6ee (225 bytes)
0001e6ee  4c89a42408410000         mov qword ptr [rsp + 0x4108], r12
0001e6f6  4c89b42418410000         mov qword ptr [rsp + 0x4118], r14
0001e6fe  4c8d359b512f00           lea r14, [rip + 0x2f519b]
0001e705  4c89bc24d0400000         mov qword ptr [rsp + 0x40d0], r15
0001e70d  4533ff                   xor r15d, r15d
0001e710  458d6703                 lea r12d, [r15 + 3]
0001e714  0f1f4000                 nop dword ptr [rax]
0001e718  0f1f840000000000         nop dword ptr [rax + rax]
0001e720  4c8bcb                   mov r9, rbx
0001e723  4c8d5308                 lea r10, [rbx + 8]
0001e727  488b5b08                 mov rbx, qword ptr [rbx + 8]
0001e72b  483bde                   cmp rbx, rsi
0001e72e  4d8b4110                 mov r8, qword ptr [r9 + 0x10]
0001e732  490f44df                 cmove rbx, r15
0001e736  4d8b5918                 mov r11, qword ptr [r9 + 0x18]
0001e73a  418b4018                 mov eax, dword ptr [r8 + 0x18]
0001e73e  6690                     nop
0001e740  4863c8                   movsxd rcx, eax
0001e743  488d1449                 lea rdx, [rcx + rcx*2]
0001e747  4803d2                   add rdx, rdx
0001e74a  45387cd618               cmp byte ptr [r14 + rdx*8 + 0x18], r15b
0001e74f  740c                     je 0x1e75d
0001e751  8bc8                     mov ecx, eax
0001e753  f0450fb16018             lock cmpxchg dword ptr [r8 + 0x18], r12d
0001e759  3bc1                     cmp eax, ecx
0001e75b  75e3                     jne 0x1e740
0001e75d  4863c8                   movsxd rcx, eax
0001e760  488d0449                 lea rax, [rcx + rcx*2]
0001e764  4803c0                   add rax, rax
0001e767  418b54c61c               mov edx, dword ptr [r14 + rax*8 + 0x1c]
0001e76c  85d2                     test edx, edx
0001e76e  0f85732a0000             jne 0x211e7
0001e774  4d8918                   mov qword ptr [r8], r11
0001e777  418b54c61c               mov edx, dword ptr [r14 + rax*8 + 0x1c]
0001e77c  498b01                   mov rax, qword ptr [r9]
0001e77f  498b0a                   mov rcx, qword ptr [r10]
0001e782  48894808                 mov qword ptr [rax + 8], rcx
0001e786  488901                   mov qword ptr [rcx], rax
0001e789  498b4110                 mov rax, qword ptr [r9 + 0x10]
0001e78d  4d893a                   mov qword ptr [r10], r15
0001e790  4d8939                   mov qword ptr [r9], r15
0001e793  f0ff4814                 lock dec dword ptr [rax + 0x14]
0001e797  85d2                     test edx, edx
0001e799  7510                     jne 0x1e7ab
0001e79b  448bc7                   mov r8d, edi
0001e79e  488d4c2420               lea rcx, [rsp + 0x20]
0001e7a3  498bd1                   mov rdx, r9
0001e7a6  e835fcffff               call 0x1e3e0
0001e7ab  4885db                   test rbx, rbx
0001e7ae  0f856cffffff             jne 0x1e720
0001e7b4  4c8bbc24d0400000         mov r15, qword ptr [rsp + 0x40d0]
0001e7bc  4c8bb42418410000         mov r14, qword ptr [rsp + 0x4118]
0001e7c4  4c8ba42408410000         mov r12, qword ptr [rsp + 0x4108]
0001e7cc  eb09                     jmp 0x1e7d7
0001e7ce  cc                       int3

; chunk at RVA 0x1e7d7 (43 bytes)
0001e7d7  448bc7                   mov r8d, edi
0001e7da  488d4c2420               lea rcx, [rsp + 0x20]
0001e7df  8bd5                     mov edx, ebp
0001e7e1  e8fafcffff               call 0x1e4e0
0001e7e6  488b8c24c0400000         mov rcx, qword ptr [rsp + 0x40c0]
0001e7ee  4833cc                   xor rcx, rsp
0001e7f1  e8ea5dfeff               call 0x45e0
0001e7f6  4881c4d8400000           add rsp, 0x40d8
0001e7fd  5f                       pop rdi
0001e7fe  5e                       pop rsi
0001e7ff  5d                       pop rbp
0001e800  5b                       pop rbx
0001e801  c3                       ret
