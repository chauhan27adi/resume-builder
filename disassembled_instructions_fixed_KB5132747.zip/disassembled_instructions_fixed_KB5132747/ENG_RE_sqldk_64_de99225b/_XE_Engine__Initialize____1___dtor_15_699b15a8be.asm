; `XE_Engine::Initialize'::`1'::dtor$15
; sqldk.dll, primary RVA 0x233fc2, 53 bytes in 1 chunk(s)

; chunk at RVA 0x233fc2 (53 bytes)
00233fc2  4055                     push rbp
00233fc4  4883ec30                 sub rsp, 0x30
00233fc8  488bea                   mov rbp, rdx
00233fcb  c644242806               mov byte ptr [rsp + 0x28], 6
00233fd0  8b4530                   mov eax, dword ptr [rbp + 0x30]
00233fd3  89442420                 mov dword ptr [rsp + 0x20], eax
00233fd7  4c8d0dc2670700           lea r9, [rip + 0x767c2]
00233fde  41b801000000             mov r8d, 1
00233fe4  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00233fe8  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00233fec  e8ff5efaff               call 0x1d9ef0
00233ff1  4883c430                 add rsp, 0x30
00233ff5  5d                       pop rbp
00233ff6  c3                       ret
