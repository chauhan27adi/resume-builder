; XEPackage0::RingTarget::InsertEvent
; sqldk.dll, primary RVA 0x33fd0, 197 bytes in 3 chunk(s)

; chunk at RVA 0x33fd0 (63 bytes)
00033fd0  4057                     push rdi
00033fd2  4c8b5928                 mov r11, qword ptr [rcx + 0x28]
00033fd6  33ff                     xor edi, edi
00033fd8  c7415401000000           mov dword ptr [rcx + 0x54], 1
00033fdf  4c8bc1                   mov r8, rcx
00033fe2  4d85db                   test r11, r11
00033fe5  0f84c3350000             je 0x375ae
00033feb  498b4320                 mov rax, qword ptr [r11 + 0x20]
00033fef  482b4220                 sub rax, qword ptr [rdx + 0x20]
00033ff3  4885c0                   test rax, rax
00033ff6  0f8fb2350000             jg 0x375ae
00033ffc  ff4120                   inc dword ptr [rcx + 0x20]
00033fff  498b03                   mov rax, qword ptr [r11]
00034002  488902                   mov qword ptr [rdx], rax
00034005  498913                   mov qword ptr [r11], rdx
00034008  48895128                 mov qword ptr [rcx + 0x28], rdx
0003400c  eb01                     jmp 0x3400f
0003400e  cc                       int3

; chunk at RVA 0x3400f (13 bytes)
0003400f  4183786401               cmp dword ptr [r8 + 0x64], 1
00034014  0f8491ba1900             je 0x1cfaab
0003401a  5f                       pop rdi
0003401b  c3                       ret

; chunk at RVA 0x375b4 (121 bytes)
000375b4  48895c2410               mov qword ptr [rsp + 0x10], rbx
000375b9  4585d2                   test r10d, r10d
000375bc  7424                     je 0x375e2
000375be  4d8b4848                 mov r9, qword ptr [r8 + 0x48]
000375c2  0f1f4000                 nop dword ptr [rax]
000375c6  66660f1f840000000000     nop word ptr [rax + rax]
000375d0  8bc1                     mov eax, ecx
000375d2  4803c0                   add rax, rax
000375d5  498b04c1                 mov rax, qword ptr [r9 + rax*8]
000375d9  4885c0                   test rax, rax
000375dc  0f8552841900             jne 0x1cfa34
000375e2  498b5848                 mov rbx, qword ptr [r8 + 0x48]
000375e6  8bc1                     mov eax, ecx
000375e8  4803c0                   add rax, rax
000375eb  4c8b0cc3                 mov r9, qword ptr [rbx + rax*8]
000375ef  4d85c9                   test r9, r9
000375f2  0f855e841900             jne 0x1cfa56
000375f8  413bca                   cmp ecx, r10d
000375fb  0f84a2841900             je 0x1cfaa3
00037601  4d85db                   test r11, r11
00037604  7504                     jne 0x3760a
00037606  49895028                 mov qword ptr [r8 + 0x28], rdx
0003760a  8bc1                     mov eax, ecx
0003760c  4803c0                   add rax, rax
0003760f  488914c3                 mov qword ptr [rbx + rax*8], rdx
00037613  41ff4020                 inc dword ptr [r8 + 0x20]
00037617  498b4018                 mov rax, qword ptr [r8 + 0x18]
0003761b  488902                   mov qword ptr [rdx], rax
0003761e  49895018                 mov qword ptr [r8 + 0x18], rdx
00037622  488b5c2410               mov rbx, qword ptr [rsp + 0x10]
00037627  e9e3c9ffff               jmp 0x3400f
0003762c  cc                       int3
