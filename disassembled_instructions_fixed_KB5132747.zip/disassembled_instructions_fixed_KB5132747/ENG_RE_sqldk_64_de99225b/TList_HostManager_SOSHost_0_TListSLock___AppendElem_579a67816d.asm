; TList<HostManager,SOSHost,0,TListSLock>::AppendElem
; sqldk.dll, primary RVA 0x11d40, 407 bytes in 5 chunk(s)

; chunk at RVA 0x11d40 (20 bytes)
00011d40  4057                     push rdi
00011d42  4154                     push r12
00011d44  4883ec48                 sub rsp, 0x48
00011d48  658b042548000000         mov eax, dword ptr gs:[0x48]
00011d50  488d7910                 lea rdi, [rcx + 0x10]

; chunk at RVA 0x11d54 (66 bytes)
00011d54  48895c2440               mov qword ptr [rsp + 0x40], rbx
00011d59  4533e4                   xor r12d, r12d
00011d5c  4889742430               mov qword ptr [rsp + 0x30], rsi
00011d61  418bdc                   mov ebx, r12d
00011d64  4c89742428               mov qword ptr [rsp + 0x28], r14
00011d69  488bf1                   mov rsi, rcx
00011d6c  4c897c2420               mov qword ptr [rsp + 0x20], r15
00011d71  4c8bf2                   mov r14, rdx
00011d74  448bf8                   mov r15d, eax
00011d77  8b07                     mov eax, dword ptr [rdi]
00011d79  85c0                     test eax, eax
00011d7b  0f85b12a0600             jne 0x74832
00011d81  33c0                     xor eax, eax
00011d83  f04c0fb13f               lock cmpxchg qword ptr [rdi], r15
00011d88  418bc4                   mov eax, r12d
00011d8b  0f94c0                   sete al
00011d8e  85c0                     test eax, eax
00011d90  0f849c2a0600             je 0x74832

; chunk at RVA 0x11d96 (60 bytes)
00011d96  488b06                   mov rax, qword ptr [rsi]
00011d99  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
00011d9e  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00011da3  498906                   mov qword ptr [r14], rax
00011da6  488b06                   mov rax, qword ptr [rsi]
00011da9  4c897008                 mov qword ptr [rax + 8], r14
00011dad  4c8936                   mov qword ptr [rsi], r14
00011db0  49897608                 mov qword ptr [r14 + 8], rsi
00011db4  ff4618                   inc dword ptr [rsi + 0x18]
00011db7  49897610                 mov qword ptr [r14 + 0x10], rsi
00011dbb  443825ff363000           cmp byte ptr [rip + 0x3036ff], r12b
00011dc2  4c8b742428               mov r14, qword ptr [rsp + 0x28]
00011dc7  488b742430               mov rsi, qword ptr [rsp + 0x30]
00011dcc  0f853e2b0600             jne 0x74910

; chunk at RVA 0x7483d (211 bytes)
0007483d  48896c2438               mov qword ptr [rsp + 0x38], rbp
00074842  498bec                   mov rbp, r12
00074845  3c84                     cmp al, 0x84
00074847  754b                     jne 0x74894
00074849  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
00074852  8b0578072a00             mov eax, dword ptr [rip + 0x2a0778]
00074858  8b155ad0f8ff             mov edx, dword ptr [rip - 0x72fa6]
0007485e  480314c1                 add rdx, qword ptr [rcx + rax*8]
00074862  7410                     je 0x74874
00074864  48399210010000           cmp qword ptr [rdx + 0x110], rdx
0007486b  7507                     jne 0x74874
0007486d  488baa00010000           mov rbp, qword ptr [rdx + 0x100]
00074874  4885ed                   test rbp, rbp
00074877  741b                     je 0x74894
00074879  391d450c2a00             cmp dword ptr [rip + 0x2a0c45], ebx
0007487f  746d                     je 0x748ee
00074881  488d4c2460               lea rcx, [rsp + 0x60]
00074886  ff15444c1c00             call qword ptr [rip + 0x1c4c44]
0007488c  488b5c2460               mov rbx, qword ptr [rsp + 0x60]
00074891  eb01                     jmp 0x74894
00074893  cc                       int3
00074894  f6053c022a0080           test byte ptr [rip + 0x2a023c], 0x80
0007489b  488bcf                   mov rcx, rdi
0007489e  7459                     je 0x748f9
000748a0  4d8bc7                   mov r8, r15
000748a3  488bd5                   mov rdx, rbp
000748a6  e80548fcff               call 0x390b0
000748ab  eb01                     jmp 0x748ae
000748ad  cc                       int3
000748ae  4885ed                   test rbp, rbp
000748b1  7430                     je 0x748e3
000748b3  4439250a0c2a00           cmp dword ptr [rip + 0x2a0c0a], r12d
000748ba  7449                     je 0x74905
000748bc  488d4c2468               lea rcx, [rsp + 0x68]
000748c1  ff15094c1c00             call qword ptr [rip + 0x1c4c09]
000748c7  488b442468               mov rax, qword ptr [rsp + 0x68]
000748cc  eb01                     jmp 0x748cf
000748ce  cc                       int3
000748cf  488bc8                   mov rcx, rax
000748d2  482bcb                   sub rcx, rbx
000748d5  483bc3                   cmp rax, rbx
000748d8  490f42cc                 cmovb rcx, r12
000748dc  48018d780c0000           add qword ptr [rbp + 0xc78], rcx
000748e3  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
000748e8  e9a9d4f9ff               jmp 0x11d96
000748ed  cc                       int3
000748ee  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
000748f6  eb9c                     jmp 0x74894
000748f8  cc                       int3
000748f9  498bd7                   mov rdx, r15
000748fc  e89f5bffff               call 0x6a4a0
00074901  90                       nop
00074902  ebaa                     jmp 0x748ae
00074904  cc                       int3
00074905  488b04250800fe7f         mov rax, qword ptr [0x7ffe0008]
0007490d  ebc0                     jmp 0x748cf
0007490f  cc                       int3

; chunk at RVA 0x74910 (50 bytes)
00074910  ff1532511c00             call qword ptr [rip + 0x1c5132]
00074916  448bc0                   mov r8d, eax
00074919  b867666666               mov eax, 0x66666667
0007491e  41f7e8                   imul r8d
00074921  d1fa                     sar edx, 1
00074923  8bca                     mov ecx, edx
00074925  c1e91f                   shr ecx, 0x1f
00074928  03d1                     add edx, ecx
0007492a  8d0c92                   lea ecx, [rdx + rdx*4]
0007492d  443bc1                   cmp r8d, ecx
00074930  0f859cd4f9ff             jne 0x11dd2
00074936  e8a55dffff               call 0x6a6e0
0007493b  90                       nop
0007493c  e991d4f9ff               jmp 0x11dd2
00074941  cc                       int3
