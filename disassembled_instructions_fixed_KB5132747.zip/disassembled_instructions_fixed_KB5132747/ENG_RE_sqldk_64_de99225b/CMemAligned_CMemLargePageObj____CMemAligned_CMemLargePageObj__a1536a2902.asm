; CMemAligned<CMemLargePageObj>::~CMemAligned<CMemLargePageObj>
; sqldk.dll, primary RVA 0x1117e0, 95 bytes in 1 chunk(s)

; chunk at RVA 0x1117e0 (95 bytes)
001117e0  48894c2408               mov qword ptr [rsp + 8], rcx
001117e5  53                       push rbx
001117e6  4883ec30                 sub rsp, 0x30
001117ea  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001117f3  488bd9                   mov rbx, rcx
001117f6  488d05db9d1300           lea rax, [rip + 0x139ddb]
001117fd  488901                   mov qword ptr [rcx], rax
00111800  488d0511561300           lea rax, [rip + 0x135611]
00111807  488901                   mov qword ptr [rcx], rax
0011180a  488d0557571300           lea rax, [rip + 0x135757]
00111811  488901                   mov qword ptr [rcx], rax
00111814  488d05ed591300           lea rax, [rip + 0x1359ed]
0011181b  488901                   mov qword ptr [rcx], rax
0011181e  4883c138                 add rcx, 0x38
00111822  e8c9fdefff               call 0x115f0
00111827  90                       nop
00111828  488d4b30                 lea rcx, [rbx + 0x30]
0011182c  e8bffdefff               call 0x115f0
00111831  90                       nop
00111832  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
00111839  4883c430                 add rsp, 0x30
0011183d  5b                       pop rbx
0011183e  c3                       ret
