; SOS_Scheduler::Switch
; sqldk.dll, primary RVA 0x26e0, 321 bytes in 7 chunk(s)

; chunk at RVA 0x26e0 (105 bytes)
000026e0  4053                     push rbx
000026e2  56                       push rsi
000026e3  57                       push rdi
000026e4  4154                     push r12
000026e6  4883ec48                 sub rsp, 0x48
000026ea  498bf0                   mov rsi, r8
000026ed  488bfa                   mov rdi, rdx
000026f0  488bd9                   mov rbx, rcx
000026f3  f048ff81480e0000         lock inc qword ptr [rcx + 0xe48]
000026fb  4533e4                   xor r12d, r12d
000026fe  493bd0                   cmp rdx, r8
00002701  0f8558dc0000             jne 0x1035f
00002707  ba01000000               mov edx, 1
0000270c  488bcf                   mov rcx, rdi
0000270f  e85c020000               call 0x2970
00002714  488b8760020000           mov rax, qword ptr [rdi + 0x260]
0000271b  4839b800140000           cmp qword ptr [rax + 0x1400], rdi
00002722  0f85f4ca0700             jne 0x7f21c
00002728  4c396710                 cmp qword ptr [rdi + 0x10], r12
0000272c  0f8514cb0700             jne 0x7f246
00002732  488bb758020000           mov rsi, qword ptr [rdi + 0x258]
00002739  4885f6                   test rsi, rsi
0000273c  7467                     je 0x27a5
0000273e  658b042548000000         mov eax, dword ptr gs:[0x48]
00002746  498bdc                   mov rbx, r12

; chunk at RVA 0x2749 (12 bytes)
00002749  4c89742438               mov qword ptr [rsp + 0x38], r14
0000274e  4c8db690000000           lea r14, [rsi + 0x90]

; chunk at RVA 0x2755 (40 bytes)
00002755  4c897c2430               mov qword ptr [rsp + 0x30], r15
0000275a  448bf8                   mov r15d, eax
0000275d  418b06                   mov eax, dword ptr [r14]
00002760  85c0                     test eax, eax
00002762  0f856d490300             jne 0x370d5
00002768  33c0                     xor eax, eax
0000276a  f04d0fb13e               lock cmpxchg qword ptr [r14], r15
0000276f  418bc4                   mov eax, r12d
00002772  0f94c0                   sete al
00002775  85c0                     test eax, eax
00002777  0f8458490300             je 0x370d5

; chunk at RVA 0x277d (32 bytes)
0000277d  83860801000002           add dword ptr [rsi + 0x108], 2
00002784  4c8b7c2430               mov r15, qword ptr [rsp + 0x30]
00002789  4c89a6c8000000           mov qword ptr [rsi + 0xc8], r12
00002790  4438252a2d3100           cmp byte ptr [rip + 0x312d2a], r12b
00002797  0f8582cb0700             jne 0x7f31f

; chunk at RVA 0x27a5 (16 bytes)
000027a5  8b87d4030000             mov eax, dword ptr [rdi + 0x3d4]
000027ab  4883c448                 add rsp, 0x48
000027af  415c                     pop r12
000027b1  5f                       pop rdi
000027b2  5e                       pop rsi
000027b3  5b                       pop rbx
000027b4  c3                       ret

; chunk at RVA 0x370e0 (66 bytes)
000370e0  48896c2440               mov qword ptr [rsp + 0x40], rbp
000370e5  498bec                   mov rbp, r12
000370e8  3c84                     cmp al, 0x84
000370ea  0f8480810400             je 0x7f270
000370f0  f605e0d92d0080           test byte ptr [rip + 0x2dd9e0], 0x80
000370f7  498bce                   mov rcx, r14
000370fa  0f84cf810400             je 0x7f2cf
00037100  4d8bc7                   mov r8, r15
00037103  488bd5                   mov rdx, rbp
00037106  e8f5230000               call 0x39500
0003710b  eb01                     jmp 0x3710e
0003710d  cc                       int3
0003710e  4885ed                   test rbp, rbp
00037111  0f85c7810400             jne 0x7f2de
00037117  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
0003711c  e95cb6fcff               jmp 0x277d
00037121  cc                       int3

; chunk at RVA 0x7f31f (50 bytes)
0007f31f  ff1523a71b00             call qword ptr [rip + 0x1ba723]
0007f325  448bc0                   mov r8d, eax
0007f328  b867666666               mov eax, 0x66666667
0007f32d  41f7e8                   imul r8d
0007f330  d1fa                     sar edx, 1
0007f332  8bca                     mov ecx, edx
0007f334  c1e91f                   shr ecx, 0x1f
0007f337  03d1                     add edx, ecx
0007f339  8d0c92                   lea ecx, [rdx + rdx*4]
0007f33c  443bc1                   cmp r8d, ecx
0007f33f  0f855834f8ff             jne 0x279d
0007f345  e8e68fffff               call 0x78330
0007f34a  90                       nop
0007f34b  e94d34f8ff               jmp 0x279d
0007f350  cc                       int3
