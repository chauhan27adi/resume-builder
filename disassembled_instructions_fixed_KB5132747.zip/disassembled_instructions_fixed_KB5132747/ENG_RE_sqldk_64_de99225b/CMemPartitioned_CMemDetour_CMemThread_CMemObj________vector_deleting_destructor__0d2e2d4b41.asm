; CMemPartitioned<CMemDetour<CMemThread<CMemObj> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcefb0, 129 bytes in 1 chunk(s)

; chunk at RVA 0xcefb0 (129 bytes)
000cefb0  48894c2408               mov qword ptr [rsp + 8], rcx
000cefb5  57                       push rdi
000cefb6  4883ec30                 sub rsp, 0x30
000cefba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cefc3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cefc8  8bda                     mov ebx, edx
000cefca  488bf9                   mov rdi, rcx
000cefcd  488d050cca1700           lea rax, [rip + 0x17ca0c]
000cefd4  488901                   mov qword ptr [rcx], rax
000cefd7  488d8108030000           lea rax, [rcx + 0x308]
000cefde  4889442450               mov qword ptr [rsp + 0x50], rax
000cefe3  488d0d56ab1600           lea rcx, [rip + 0x16ab56]
000cefea  488908                   mov qword ptr [rax], rcx
000cefed  488d05fcd11700           lea rax, [rip + 0x17d1fc]
000ceff4  488907                   mov qword ptr [rdi], rax
000ceff7  488d8740020000           lea rax, [rdi + 0x240]
000ceffe  4889442458               mov qword ptr [rsp + 0x58], rax
000cf003  488908                   mov qword ptr [rax], rcx
000cf006  488bcf                   mov rcx, rdi
000cf009  e882b10500               call 0x12a190
000cf00e  83e305                   and ebx, 5
000cf011  80fb05                   cmp bl, 5
000cf014  750d                     jne 0xcf023
000cf016  ba40030000               mov edx, 0x340
000cf01b  488bcf                   mov rcx, rdi
000cf01e  e8ed1ff3ff               call 0x1010
000cf023  488bc7                   mov rax, rdi
000cf026  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cf02b  4883c430                 add rsp, 0x30
000cf02f  5f                       pop rdi
000cf030  c3                       ret
