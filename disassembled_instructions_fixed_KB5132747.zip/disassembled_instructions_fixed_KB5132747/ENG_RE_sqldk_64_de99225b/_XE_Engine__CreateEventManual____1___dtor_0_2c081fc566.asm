; `XE_Engine::CreateEventManual'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2355e0, 56 bytes in 1 chunk(s)

; chunk at RVA 0x2355e0 (56 bytes)
002355e0  4055                     push rbp
002355e2  4883ec30                 sub rsp, 0x30
002355e6  488bea                   mov rbp, rdx
002355e9  c644242806               mov byte ptr [rsp + 0x28], 6
002355ee  8b4560                   mov eax, dword ptr [rbp + 0x60]
002355f1  89442420                 mov dword ptr [rsp + 0x20], eax
002355f5  4c8d0de45b0400           lea r9, [rip + 0x45be4]
002355fc  41b801000000             mov r8d, 1
00235602  488b15b7d01700           mov rdx, qword ptr [rip + 0x17d0b7]
00235609  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
0023560d  e8de48faff               call 0x1d9ef0
00235612  4883c430                 add rsp, 0x30
00235616  5d                       pop rbp
00235617  c3                       ret
