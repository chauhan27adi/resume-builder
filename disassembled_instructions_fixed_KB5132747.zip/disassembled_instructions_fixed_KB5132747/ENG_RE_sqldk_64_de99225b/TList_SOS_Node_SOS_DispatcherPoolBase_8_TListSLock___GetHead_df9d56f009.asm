; TList<SOS_Node,SOS_DispatcherPoolBase,8,TListSLock>::GetHead
; sqldk.dll, primary RVA 0x18820, 428 bytes in 6 chunk(s)

; chunk at RVA 0x18820 (20 bytes)
00018820  4053                     push rbx
00018822  4156                     push r14
00018824  4883ec38                 sub rsp, 0x38
00018828  658b042548000000         mov eax, dword ptr gs:[0x48]
00018830  4c8d7110                 lea r14, [rcx + 0x10]

; chunk at RVA 0x18834 (48 bytes)
00018834  48896c2430               mov qword ptr [rsp + 0x30], rbp
00018839  33db                     xor ebx, ebx
0001883b  8be8                     mov ebp, eax
0001883d  418b06                   mov eax, dword ptr [r14]
00018840  4889742428               mov qword ptr [rsp + 0x28], rsi
00018845  488bf1                   mov rsi, rcx
00018848  85c0                     test eax, eax
0001884a  0f85ca6b1700             jne 0x18f41a
00018850  33c0                     xor eax, eax
00018852  f0490fb12e               lock cmpxchg qword ptr [r14], rbp
00018857  8bc3                     mov eax, ebx
00018859  0f94c0                   sete al
0001885c  85c0                     test eax, eax
0001885e  0f84b66b1700             je 0x18f41a

; chunk at RVA 0x18864 (20 bytes)
00018864  488b4e08                 mov rcx, qword ptr [rsi + 8]
00018868  33db                     xor ebx, ebx
0001886a  488b6c2430               mov rbp, qword ptr [rsp + 0x30]
0001886f  483bce                   cmp rcx, rsi
00018872  0f855f120000             jne 0x19ad7

; chunk at RVA 0x19ad7 (73 bytes)
00019ad7  4885c9                   test rcx, rcx
00019ada  488d41f8                 lea rax, [rcx - 8]
00019ade  480f45d8                 cmovne rbx, rax
00019ae2  4885db                   test rbx, rbx
00019ae5  0f848dedffff             je 0x18878
00019aeb  0f1f00                   nop dword ptr [rax]
00019aee  6690                     nop
00019af0  8b4b20                   mov ecx, dword ptr [rbx + 0x20]
00019af3  85c9                     test ecx, ecx
00019af5  0f840e5a1700             je 0x18f509
00019afb  660f1f0400               nop word ptr [rax + rax]
00019b00  8d5101                   lea edx, [rcx + 1]
00019b03  8bc1                     mov eax, ecx
00019b05  f00fb15320               lock cmpxchg dword ptr [rbx + 0x20], edx
00019b0a  3bc8                     cmp ecx, eax
00019b0c  0f85e7591700             jne 0x18f4f9
00019b12  85d2                     test edx, edx
00019b14  0f855eedffff             jne 0x18878
00019b1a  e9ea591700               jmp 0x18f509
00019b1f  cc                       int3

; chunk at RVA 0x18f420 (217 bytes)
0018f420  48897c2420               mov qword ptr [rsp + 0x20], rdi
0018f425  2584000000               and eax, 0x84
0018f42a  33ff                     xor edi, edi
0018f42c  3c84                     cmp al, 0x84
0018f42e  754b                     jne 0x18f47b
0018f430  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
0018f439  8b05915b1800             mov eax, dword ptr [rip + 0x185b91]
0018f43f  8b157324e7ff             mov edx, dword ptr [rip - 0x18db8d]
0018f445  480314c1                 add rdx, qword ptr [rcx + rax*8]
0018f449  7410                     je 0x18f45b
0018f44b  48399210010000           cmp qword ptr [rdx + 0x110], rdx
0018f452  7507                     jne 0x18f45b
0018f454  488bba00010000           mov rdi, qword ptr [rdx + 0x100]
0018f45b  4885ff                   test rdi, rdi
0018f45e  741b                     je 0x18f47b
0018f460  391d5e601800             cmp dword ptr [rip + 0x18605e], ebx
0018f466  746f                     je 0x18f4d7
0018f468  488d4c2450               lea rcx, [rsp + 0x50]
0018f46d  ff155da00a00             call qword ptr [rip + 0xaa05d]
0018f473  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0018f478  eb01                     jmp 0x18f47b
0018f47a  cc                       int3
0018f47b  f6055556180080           test byte ptr [rip + 0x185655], 0x80
0018f482  498bce                   mov rcx, r14
0018f485  745b                     je 0x18f4e2
0018f487  4c8bc5                   mov r8, rbp
0018f48a  488bd7                   mov rdx, rdi
0018f48d  e81e9ceaff               call 0x390b0
0018f492  eb01                     jmp 0x18f495
0018f494  cc                       int3
0018f495  4885ff                   test rdi, rdi
0018f498  7432                     je 0x18f4cc
0018f49a  833d2360180000           cmp dword ptr [rip + 0x186023], 0
0018f4a1  744b                     je 0x18f4ee
0018f4a3  488d4c2458               lea rcx, [rsp + 0x58]
0018f4a8  ff1522a00a00             call qword ptr [rip + 0xaa022]
0018f4ae  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0018f4b3  eb01                     jmp 0x18f4b6
0018f4b5  cc                       int3
0018f4b6  33c0                     xor eax, eax
0018f4b8  488bd1                   mov rdx, rcx
0018f4bb  482bd3                   sub rdx, rbx
0018f4be  483bcb                   cmp rcx, rbx
0018f4c1  480f43c2                 cmovae rax, rdx
0018f4c5  480187780c0000           add qword ptr [rdi + 0xc78], rax
0018f4cc  488b7c2420               mov rdi, qword ptr [rsp + 0x20]
0018f4d1  e98e93e8ff               jmp 0x18864
0018f4d6  cc                       int3
0018f4d7  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
0018f4df  eb9a                     jmp 0x18f47b
0018f4e1  cc                       int3
0018f4e2  488bd5                   mov rdx, rbp
0018f4e5  e8b6afedff               call 0x6a4a0
0018f4ea  90                       nop
0018f4eb  eba8                     jmp 0x18f495
0018f4ed  cc                       int3
0018f4ee  488b0c250800fe7f         mov rcx, qword ptr [0x7ffe0008]
0018f4f6  ebbe                     jmp 0x18f4b6
0018f4f8  cc                       int3

; chunk at RVA 0x18f532 (50 bytes)
0018f532  ff1510a50a00             call qword ptr [rip + 0xaa510]
0018f538  448bc0                   mov r8d, eax
0018f53b  b867666666               mov eax, 0x66666667
0018f540  41f7e8                   imul r8d
0018f543  d1fa                     sar edx, 1
0018f545  8bca                     mov ecx, edx
0018f547  c1e91f                   shr ecx, 0x1f
0018f54a  03d1                     add edx, ecx
0018f54c  8d0c92                   lea ecx, [rdx + rdx*4]
0018f54f  443bc1                   cmp r8d, ecx
0018f552  0f853293e8ff             jne 0x1888a
0018f558  e883b1edff               call 0x6a6e0
0018f55d  90                       nop
0018f55e  e92793e8ff               jmp 0x1888a
0018f563  cc                       int3
