; SOS_CacheStore::~SOS_CacheStore
; sqldk.dll, primary RVA 0x180f80, 27 bytes in 1 chunk(s)

; chunk at RVA 0x180f80 (27 bytes)
00180f80  48894c2408               mov qword ptr [rsp + 8], rcx
00180f85  4883ec38                 sub rsp, 0x38
00180f89  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00180f92  4883c438                 add rsp, 0x38
00180f96  e985120000               jmp 0x182220
