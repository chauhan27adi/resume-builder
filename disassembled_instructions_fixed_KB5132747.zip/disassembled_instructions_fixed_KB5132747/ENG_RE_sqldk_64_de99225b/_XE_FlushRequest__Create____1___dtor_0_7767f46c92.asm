; `XE_FlushRequest::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x233380, 59 bytes in 1 chunk(s)

; chunk at RVA 0x233380 (59 bytes)
00233380  4055                     push rbp
00233382  4883ec30                 sub rsp, 0x30
00233386  488bea                   mov rbp, rdx
00233389  c644242806               mov byte ptr [rsp + 0x28], 6
0023338e  8b8580000000             mov eax, dword ptr [rbp + 0x80]
00233394  89442420                 mov dword ptr [rsp + 0x20], eax
00233398  4c8d0db1730700           lea r9, [rip + 0x773b1]
0023339f  41b801000000             mov r8d, 1
002333a5  488b5570                 mov rdx, qword ptr [rbp + 0x70]
002333a9  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
002333b0  e83b6bfaff               call 0x1d9ef0
002333b5  4883c430                 add rsp, 0x30
002333b9  5d                       pop rbp
002333ba  c3                       ret
