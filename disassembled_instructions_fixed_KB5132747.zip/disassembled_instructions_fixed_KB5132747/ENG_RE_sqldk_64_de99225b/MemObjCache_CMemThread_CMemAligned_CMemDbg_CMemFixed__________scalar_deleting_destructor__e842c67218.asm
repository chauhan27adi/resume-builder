; MemObjCache<CMemThread<CMemAligned<CMemDbg<CMemFixed> > > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e7f0, 128 bytes in 1 chunk(s)

; chunk at RVA 0x13e7f0 (128 bytes)
0013e7f0  48894c2408               mov qword ptr [rsp + 8], rcx
0013e7f5  57                       push rdi
0013e7f6  4883ec30                 sub rsp, 0x30
0013e7fa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e803  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e808  8bda                     mov ebx, edx
0013e80a  488bf9                   mov rdi, rcx
0013e80d  488d055c671200           lea rax, [rip + 0x12675c]
0013e814  488901                   mov qword ptr [rcx], rax
0013e817  488d057aad1000           lea rax, [rip + 0x10ad7a]
0013e81e  488901                   mov qword ptr [rcx], rax
0013e821  488d81e0040000           lea rax, [rcx + 0x4e0]
0013e828  4889442450               mov qword ptr [rsp + 0x50], rax
0013e82d  488d0d0cb30f00           lea rcx, [rip + 0xfb30c]
0013e834  48894830                 mov qword ptr [rax + 0x30], rcx
0013e838  488908                   mov qword ptr [rax], rcx
0013e83b  488d05e6ca1000           lea rax, [rip + 0x10cae6]
0013e842  488907                   mov qword ptr [rdi], rax
0013e845  488bcf                   mov rcx, rdi
0013e848  e813270300               call 0x170f60
0013e84d  83e305                   and ebx, 5
0013e850  80fb05                   cmp bl, 5
0013e853  750d                     jne 0x13e862
0013e855  ba08060000               mov edx, 0x608
0013e85a  488bcf                   mov rcx, rdi
0013e85d  e8ae27ecff               call 0x1010
0013e862  488bc7                   mov rax, rdi
0013e865  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e86a  4883c430                 add rsp, 0x30
0013e86e  5f                       pop rdi
0013e86f  c3                       ret
