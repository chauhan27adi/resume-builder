; `XEPackage0::PairingTarget::GetSerializedState'::`1'::dtor$4
; sqldk.dll, primary RVA 0x2310c1, 31 bytes in 1 chunk(s)

; chunk at RVA 0x2310c1 (31 bytes)
002310c1  4055                     push rbp
002310c3  4883ec20                 sub rsp, 0x20
002310c7  488bea                   mov rbp, rdx
002310ca  4533c0                   xor r8d, r8d
002310cd  488b5560                 mov rdx, qword ptr [rbp + 0x60]
002310d1  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
002310d5  e836ffdcff               call 0x1010
002310da  4883c420                 add rsp, 0x20
002310de  5d                       pop rbp
002310df  c3                       ret
