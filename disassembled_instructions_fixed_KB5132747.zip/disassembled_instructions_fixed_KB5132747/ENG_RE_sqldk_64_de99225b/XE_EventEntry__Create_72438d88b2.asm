; XE_EventEntry::Create
; sqldk.dll, primary RVA 0x1f3600, 948 bytes in 1 chunk(s)

; chunk at RVA 0x1f3600 (948 bytes)
001f3600  6644894c2420             mov word ptr [rsp + 0x20], r9w
001f3606  48894c2408               mov qword ptr [rsp + 8], rcx
001f360b  53                       push rbx
001f360c  55                       push rbp
001f360d  56                       push rsi
001f360e  57                       push rdi
001f360f  4155                     push r13
001f3611  4156                     push r14
001f3613  4157                     push r15
001f3615  4883ec60                 sub rsp, 0x60
001f3619  48c7442458feffffff       mov qword ptr [rsp + 0x58], 0xfffffffffffffffe
001f3622  498be8                   mov rbp, r8
001f3625  4c8bfa                   mov r15, rdx
001f3628  4c8bf1                   mov r14, rcx
001f362b  33f6                     xor esi, esi
001f362d  410fb74026               movzx eax, word ptr [r8 + 0x26]
001f3632  450fb75024               movzx r10d, word ptr [r8 + 0x24]
001f3637  442bd0                   sub r10d, eax
001f363a  440fb7ac24d0000000       movzx r13d, word ptr [rsp + 0xd0]
001f3643  418d4501                 lea eax, [r13 + 1]
001f3647  4103c2                   add eax, r10d
001f364a  c1e004                   shl eax, 4
001f364d  3d10020000               cmp eax, 0x210
001f3652  0f8720030000             ja 0x1f3978
001f3658  c78424b000000060000000   mov dword ptr [rsp + 0xb0], 0x60
001f3663  488b4908                 mov rcx, qword ptr [rcx + 8]
001f3667  488b01                   mov rax, qword ptr [rcx]
001f366a  c644242006               mov byte ptr [rsp + 0x20], 6
001f366f  448d4e60                 lea r9d, [rsi + 0x60]
001f3673  4c8d05ee720b00           lea r8, [rip + 0xb72ee]
001f367a  418d5148                 lea edx, [r9 + 0x48]
001f367e  ff5050                   call qword ptr [rax + 0x50]
001f3681  488bf8                   mov rdi, rax
001f3684  4889442450               mov qword ptr [rsp + 0x50], rax
001f3689  448d4e01                 lea r9d, [rsi + 1]
001f368d  4885c0                   test rax, rax
001f3690  7472                     je 0x1f3704
001f3692  488930                   mov qword ptr [rax], rsi
001f3695  48897008                 mov qword ptr [rax + 8], rsi
001f3699  44894810                 mov dword ptr [rax + 0x10], r9d
001f369d  48897018                 mov qword ptr [rax + 0x18], rsi
001f36a1  48897020                 mov qword ptr [rax + 0x20], rsi
001f36a5  48897028                 mov qword ptr [rax + 0x28], rsi
001f36a9  0f280510ca0800           movaps xmm0, xmmword ptr [rip + 0x8ca10]
001f36b0  0f114030                 movups xmmword ptr [rax + 0x30], xmm0
001f36b4  0f280d15ca0800           movaps xmm1, xmmword ptr [rip + 0x8ca15]
001f36bb  0f114840                 movups xmmword ptr [rax + 0x40], xmm1
001f36bf  0f28051aca0800           movaps xmm0, xmmword ptr [rip + 0x8ca1a]
001f36c6  0f114050                 movups xmmword ptr [rax + 0x50], xmm0
001f36ca  0f280d1fca0800           movaps xmm1, xmmword ptr [rip + 0x8ca1f]
001f36d1  0f114860                 movups xmmword ptr [rax + 0x60], xmm1
001f36d5  0f280524ca0800           movaps xmm0, xmmword ptr [rip + 0x8ca24]
001f36dc  0f114070                 movups xmmword ptr [rax + 0x70], xmm0
001f36e0  0f280d29ca0800           movaps xmm1, xmmword ptr [rip + 0x8ca29]
001f36e7  0f118880000000           movups xmmword ptr [rax + 0x80], xmm1
001f36ee  4889b090000000           mov qword ptr [rax + 0x90], rsi
001f36f5  480598000000             add rax, 0x98
001f36fb  48894008                 mov qword ptr [rax + 8], rax
001f36ff  488900                   mov qword ptr [rax], rax
001f3702  eb03                     jmp 0x1f3707
001f3704  488bfe                   mov rdi, rsi
001f3707  488bdf                   mov rbx, rdi
001f370a  48895c2450               mov qword ptr [rsp + 0x50], rbx
001f370f  4885ff                   test rdi, rdi
001f3712  0f841d020000             je 0x1f3935
001f3718  4c8b1581e91300           mov r10, qword ptr [rip + 0x13e981]
001f371f  0fb74504                 movzx eax, word ptr [rbp + 4]
001f3723  b9ff030000               mov ecx, 0x3ff
001f3728  6623c1                   and ax, cx
001f372b  4c8bc6                   mov r8, rsi
001f372e  0fb7c0                   movzx eax, ax
001f3731  4c69d890010000           imul r11, rax, 0x190
001f3738  498b9230010000           mov rdx, qword ptr [r10 + 0x130]
001f373f  4903d3                   add rdx, r11
001f3742  8b4228                   mov eax, dword ptr [rdx + 0x28]
001f3745  85c0                     test eax, eax
001f3747  7426                     je 0x1f376f
001f3749  0f1f00                   nop dword ptr [rax]
001f374c  0f1f4000                 nop dword ptr [rax]
001f3750  8d4801                   lea ecx, [rax + 1]
001f3753  f00fb14a28               lock cmpxchg dword ptr [rdx + 0x28], ecx
001f3758  740b                     je 0x1f3765
001f375a  f390                     pause
001f375c  8b4228                   mov eax, dword ptr [rdx + 0x28]
001f375f  85c0                     test eax, eax
001f3761  75ed                     jne 0x1f3750
001f3763  eb0a                     jmp 0x1f376f
001f3765  4d8b8230010000           mov r8, qword ptr [r10 + 0x130]
001f376c  4d03c3                   add r8, r11
001f376f  488b8790000000           mov rax, qword ptr [rdi + 0x90]
001f3776  4885c0                   test rax, rax
001f3779  7404                     je 0x1f377f
001f377b  f0ff4828                 lock dec dword ptr [rax + 0x28]
001f377f  4c898790000000           mov qword ptr [rdi + 0x90], r8
001f3786  4d85c0                   test r8, r8
001f3789  0f84a1010000             je 0x1f3930
001f378f  4c897f38                 mov qword ptr [rdi + 0x38], r15
001f3793  48896f60                 mov qword ptr [rdi + 0x60], rbp
001f3797  488b9c24c8000000         mov rbx, qword ptr [rsp + 0xc8]
001f379f  4885db                   test rbx, rbx
001f37a2  0f849f000000             je 0x1f3847
001f37a8  8bd3                     mov edx, ebx
001f37aa  83e207                   and edx, 7
001f37ad  83fa05                   cmp edx, 5
001f37b0  0f877a010000             ja 0x1f3930
001f37b6  4863c2                   movsxd rax, edx
001f37b9  4c8d0540c8e0ff           lea r8, [rip - 0x1f37c0]
001f37c0  418b8c809c391f00         mov ecx, dword ptr [r8 + rax*4 + 0x1f399c]
001f37c8  4903c8                   add rcx, r8
001f37cb  ffe1                     jmp rcx
001f37cd  488bcb                   mov rcx, rbx
001f37d0  4883e1f8                 and rcx, 0xfffffffffffffff8
001f37d4  488d4128                 lea rax, [rcx + 0x28]
001f37d8  eb31                     jmp 0x1f380b
001f37da  488bcb                   mov rcx, rbx
001f37dd  4883e1f8                 and rcx, 0xfffffffffffffff8
001f37e1  488d4118                 lea rax, [rcx + 0x18]
001f37e5  eb24                     jmp 0x1f380b
001f37e7  488bcb                   mov rcx, rbx
001f37ea  4883e1f8                 and rcx, 0xfffffffffffffff8
001f37ee  488bc1                   mov rax, rcx
001f37f1  eb18                     jmp 0x1f380b
001f37f3  488bcb                   mov rcx, rbx
001f37f6  4883e1f8                 and rcx, 0xfffffffffffffff8
001f37fa  488d4110                 lea rax, [rcx + 0x10]
001f37fe  eb0b                     jmp 0x1f380b
001f3800  488bcb                   mov rcx, rbx
001f3803  4883e1f8                 and rcx, 0xfffffffffffffff8
001f3807  488d4108                 lea rax, [rcx + 8]
001f380b  f0440fc108               lock xadd dword ptr [rax], r9d
001f3810  41ffc1                   inc r9d
001f3813  4183f9ff                 cmp r9d, -1
001f3817  0f8413010000             je 0x1f3930
001f381d  83fa03                   cmp edx, 3
001f3820  480f45ce                 cmovne rcx, rsi
001f3824  89b424b0000000           mov dword ptr [rsp + 0xb0], esi
001f382b  488b01                   mov rax, qword ptr [rcx]
001f382e  4c8bcf                   mov r9, rdi
001f3831  4c8d8424b0000000         lea r8, [rsp + 0xb0]
001f3839  498bd6                   mov rdx, r14
001f383c  ff5018                   call qword ptr [rax + 0x18]
001f383f  85c0                     test eax, eax
001f3841  0f84e9000000             je 0x1f3930
001f3847  48895f48                 mov qword ptr [rdi + 0x48], rbx
001f384b  4889742448               mov qword ptr [rsp + 0x48], rsi
001f3850  4889742438               mov qword ptr [rsp + 0x38], rsi
001f3855  4889742430               mov qword ptr [rsp + 0x30], rsi
001f385a  488d442448               lea rax, [rsp + 0x48]
001f385f  4889442428               mov qword ptr [rsp + 0x28], rax
001f3864  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
001f386c  4889442420               mov qword ptr [rsp + 0x20], rax
001f3871  440fb78c24b8000000       movzx r9d, word ptr [rsp + 0xb8]
001f387a  4c8bc5                   mov r8, rbp
001f387d  ba18000000               mov edx, 0x18
001f3882  498bce                   mov rcx, r14
001f3885  e8660a0000               call 0x1f42f0
001f388a  85c0                     test eax, eax
001f388c  744a                     je 0x1f38d8
001f388e  488b442448               mov rax, qword ptr [rsp + 0x48]
001f3893  488bd6                   mov rdx, rsi
001f3896  4889542448               mov qword ptr [rsp + 0x48], rdx
001f389b  48894740                 mov qword ptr [rdi + 0x40], rax
001f389f  66399424d0000000         cmp word ptr [rsp + 0xd0], dx
001f38a7  7422                     je 0x1f38cb
001f38a9  0faee8                   lfence
001f38ac  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
001f38b4  458bc5                   mov r8d, r13d
001f38b7  498bd6                   mov rdx, r14
001f38ba  488bcf                   mov rcx, rdi
001f38bd  e8fe000000               call 0x1f39c0
001f38c2  85c0                     test eax, eax
001f38c4  7412                     je 0x1f38d8
001f38c6  488b542448               mov rdx, qword ptr [rsp + 0x48]
001f38cb  488bde                   mov rbx, rsi
001f38ce  48895c2450               mov qword ptr [rsp + 0x50], rbx
001f38d3  488bf7                   mov rsi, rdi
001f38d6  eb0a                     jmp 0x1f38e2
001f38d8  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
001f38dd  488b542448               mov rdx, qword ptr [rsp + 0x48]
001f38e2  4885d2                   test rdx, rdx
001f38e5  744e                     je 0x1f3935
001f38e7  488bc2                   mov rax, rdx
001f38ea  41b800020000             mov r8d, 0x200
001f38f0  482500e0ffff             and rax, 0xffffffffffffe000
001f38f6  740b                     je 0x1f3903
001f38f8  6644394004               cmp word ptr [rax + 4], r8w
001f38fd  7504                     jne 0x1f3903
001f38ff  488b4028                 mov rax, qword ptr [rax + 0x28]
001f3903  488b4008                 mov rax, qword ptr [rax + 8]
001f3907  488b4810                 mov rcx, qword ptr [rax + 0x10]
001f390b  48f7d9                   neg rcx
001f390e  4823ca                   and rcx, rdx
001f3911  740b                     je 0x1f391e
001f3913  6644394104               cmp word ptr [rcx + 4], r8w
001f3918  7504                     jne 0x1f391e
001f391a  488b4928                 mov rcx, qword ptr [rcx + 0x28]
001f391e  488b4908                 mov rcx, qword ptr [rcx + 8]
001f3922  f6412808                 test byte ptr [rcx + 0x28], 8
001f3926  750d                     jne 0x1f3935
001f3928  488b01                   mov rax, qword ptr [rcx]
001f392b  ff5028                   call qword ptr [rax + 0x28]
001f392e  eb05                     jmp 0x1f3935
001f3930  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
001f3935  4885db                   test rbx, rbx
001f3938  744e                     je 0x1f3988
001f393a  b8ffffffff               mov eax, 0xffffffff
001f393f  f00fc14310               lock xadd dword ptr [rbx + 0x10], eax
001f3944  83f801                   cmp eax, 1
001f3947  753f                     jne 0x1f3988
001f3949  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
001f394e  48837b0800               cmp qword ptr [rbx + 8], 0
001f3953  740c                     je 0x1f3961
001f3955  488bd3                   mov rdx, rbx
001f3958  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001f395c  e80f54ffff               call 0x1e8d70
001f3961  488bcb                   mov rcx, rbx
001f3964  e897020000               call 0x1f3c00
001f3969  baa8000000               mov edx, 0xa8
001f396e  488bcb                   mov rcx, rbx
001f3971  e8ba35e1ff               call 0x6f30
001f3976  eb10                     jmp 0x1f3988
001f3978  ba18000000               mov edx, 0x18
001f397d  8d4a0f                   lea ecx, [rdx + 0xf]
001f3980  4533c0                   xor r8d, r8d
001f3983  e8a8d4feff               call 0x1e0e30
001f3988  488bc6                   mov rax, rsi
001f398b  4883c460                 add rsp, 0x60
001f398f  415f                     pop r15
001f3991  415e                     pop r14
001f3993  415d                     pop r13
001f3995  5f                       pop rdi
001f3996  5e                       pop rsi
001f3997  5d                       pop rbp
001f3998  5b                       pop rbx
001f3999  c3                       ret
001f399a  90                       nop
001f399b  90                       nop
001f399c  cd37                     int 0x37
