; `XEPackage0::XE_LiveWriter::Register'::`1'::dtor$0
; sqldk.dll, primary RVA 0x232190, 31 bytes in 1 chunk(s)

; chunk at RVA 0x232190 (31 bytes)
00232190  4055                     push rbp
00232192  4883ec20                 sub rsp, 0x20
00232196  488bea                   mov rbp, rdx
00232199  4533c0                   xor r8d, r8d
0023219c  488b5560                 mov rdx, qword ptr [rbp + 0x60]
002321a0  488b4d78                 mov rcx, qword ptr [rbp + 0x78]
002321a4  e867eedcff               call 0x1010
002321a9  4883c420                 add rsp, 0x20
002321ad  5d                       pop rbp
002321ae  c3                       ret
