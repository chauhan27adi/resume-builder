; CMemDetour<CMemThread<CMemProc> >::~CMemDetour<CMemThread<CMemProc> >
; sqldk.dll, primary RVA 0xd5fe0, 59 bytes in 1 chunk(s)

; chunk at RVA 0xd5fe0 (59 bytes)
000d5fe0  48894c2408               mov qword ptr [rsp + 8], rcx
000d5fe5  4883ec38                 sub rsp, 0x38
000d5fe9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d5ff2  488d05378e1700           lea rax, [rip + 0x178e37]
000d5ff9  488901                   mov qword ptr [rcx], rax
000d5ffc  488d81b8010000           lea rax, [rcx + 0x1b8]
000d6003  4889442448               mov qword ptr [rsp + 0x48], rax
000d6008  488d15313b1600           lea rdx, [rip + 0x163b31]
000d600f  488910                   mov qword ptr [rax], rdx
000d6012  4883c438                 add rsp, 0x38
000d6016  e965ccffff               jmp 0xd2c80
