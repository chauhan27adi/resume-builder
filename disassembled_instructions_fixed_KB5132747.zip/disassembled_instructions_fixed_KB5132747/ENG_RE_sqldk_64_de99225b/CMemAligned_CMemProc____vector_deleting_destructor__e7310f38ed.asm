; CMemAligned<CMemProc>::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcd610, 121 bytes in 1 chunk(s)

; chunk at RVA 0xcd610 (121 bytes)
000cd610  48894c2408               mov qword ptr [rsp + 8], rcx
000cd615  57                       push rdi
000cd616  4883ec30                 sub rsp, 0x30
000cd61a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cd623  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cd628  8bda                     mov ebx, edx
000cd62a  488bf9                   mov rdi, rcx
000cd62d  488d05a41a1800           lea rax, [rip + 0x181aa4]
000cd634  488901                   mov qword ptr [rcx], rax
000cd637  488d051a9d1700           lea rax, [rip + 0x179d1a]
000cd63e  488901                   mov qword ptr [rcx], rax
000cd641  488d05c09b1700           lea rax, [rip + 0x179bc0]
000cd648  488901                   mov qword ptr [rcx], rax
000cd64b  4883c138                 add rcx, 0x38
000cd64f  e89c3ff4ff               call 0x115f0
000cd654  90                       nop
000cd655  488d4f30                 lea rcx, [rdi + 0x30]
000cd659  e8923ff4ff               call 0x115f0
000cd65e  90                       nop
000cd65f  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
000cd666  83e305                   and ebx, 5
000cd669  80fb05                   cmp bl, 5
000cd66c  750d                     jne 0xcd67b
000cd66e  baa8000000               mov edx, 0xa8
000cd673  488bcf                   mov rcx, rdi
000cd676  e89539f3ff               call 0x1010
000cd67b  488bc7                   mov rax, rdi
000cd67e  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cd683  4883c430                 add rsp, 0x30
000cd687  5f                       pop rdi
000cd688  c3                       ret
