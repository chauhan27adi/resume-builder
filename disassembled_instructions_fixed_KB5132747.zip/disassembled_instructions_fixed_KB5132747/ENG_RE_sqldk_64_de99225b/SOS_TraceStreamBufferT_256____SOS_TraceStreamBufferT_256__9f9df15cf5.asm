; SOS_TraceStreamBufferT<256>::~SOS_TraceStreamBufferT<256>
; sqldk.dll, primary RVA 0x57cc0, 29 bytes in 1 chunk(s)

; chunk at RVA 0x57cc0 (29 bytes)
00057cc0  48894c2408               mov qword ptr [rsp + 8], rcx
00057cc5  4883ec38                 sub rsp, 0x38
00057cc9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00057cd2  4883c438                 add rsp, 0x38
00057cd6  48ff25eb1a1e00           jmp qword ptr [rip + 0x1e1aeb]
