; `XMLCXTargetConfigHelper::ParseFromString'::`1'::dtor$0
; sqldk.dll, primary RVA 0x217690, 34 bytes in 1 chunk(s)

; chunk at RVA 0x217690 (34 bytes)
00217690  4055                     push rbp
00217692  4883ec20                 sub rsp, 0x20
00217696  488bea                   mov rbp, rdx
00217699  4533c0                   xor r8d, r8d
0021769c  488b5570                 mov rdx, qword ptr [rbp + 0x70]
002176a0  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
002176a7  e86499deff               call 0x1010
002176ac  4883c420                 add rsp, 0x20
002176b0  5d                       pop rbp
002176b1  c3                       ret
