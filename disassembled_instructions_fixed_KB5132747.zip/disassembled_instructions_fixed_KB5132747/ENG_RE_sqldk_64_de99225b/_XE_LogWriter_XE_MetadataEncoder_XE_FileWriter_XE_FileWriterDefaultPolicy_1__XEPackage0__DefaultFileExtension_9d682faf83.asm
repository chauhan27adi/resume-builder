; `XE_LogWriter<XE_MetadataEncoder<XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker> > >::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x230080, 31 bytes in 1 chunk(s)

; chunk at RVA 0x230080 (31 bytes)
00230080  4055                     push rbp
00230082  4883ec20                 sub rsp, 0x20
00230086  488bea                   mov rbp, rdx
00230089  4533c0                   xor r8d, r8d
0023008c  488b5550                 mov rdx, qword ptr [rbp + 0x50]
00230090  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00230094  e8770fddff               call 0x1010
00230099  4883c420                 add rsp, 0x20
0023009d  5d                       pop rbp
0023009e  c3                       ret
