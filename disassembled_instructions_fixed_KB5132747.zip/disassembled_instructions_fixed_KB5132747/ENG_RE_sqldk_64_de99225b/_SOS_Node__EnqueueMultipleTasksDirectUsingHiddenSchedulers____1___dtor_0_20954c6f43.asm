; `SOS_Node::EnqueueMultipleTasksDirectUsingHiddenSchedulers'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21d240, 69 bytes in 1 chunk(s)

; chunk at RVA 0x21d240 (69 bytes)
0021d240  4055                     push rbp
0021d242  4883ec30                 sub rsp, 0x30
0021d246  488bea                   mov rbp, rdx
0021d249  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
0021d250  4881c2780e0000           add rdx, 0xe78
0021d257  c644242806               mov byte ptr [rsp + 0x28], 6
0021d25c  8b4550                   mov eax, dword ptr [rbp + 0x50]
0021d25f  89442420                 mov dword ptr [rsp + 0x20], eax
0021d263  4c8d0d06d00500           lea r9, [rip + 0x5d006]
0021d26a  41b801000000             mov r8d, 1
0021d270  488b12                   mov rdx, qword ptr [rdx]
0021d273  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
0021d27a  e8919cdeff               call 0x6f10
0021d27f  4883c430                 add rsp, 0x30
0021d283  5d                       pop rbp
0021d284  c3                       ret
