; MemObjCache<CMemThread<CMemProc> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13dd70, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13dd70 (79 bytes)
0013dd70  48894c2408               mov qword ptr [rsp + 8], rcx
0013dd75  57                       push rdi
0013dd76  4883ec30                 sub rsp, 0x30
0013dd7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013dd83  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013dd88  8bda                     mov ebx, edx
0013dd8a  488bf9                   mov rdi, rcx
0013dd8d  488d057cc91000           lea rax, [rip + 0x10c97c]
0013dd94  488901                   mov qword ptr [rcx], rax
0013dd97  e8e44ef9ff               call 0xd2c80
0013dd9c  83e305                   and ebx, 5
0013dd9f  80fb05                   cmp bl, 5
0013dda2  750d                     jne 0x13ddb1
0013dda4  bac8010000               mov edx, 0x1c8
0013dda9  488bcf                   mov rcx, rdi
0013ddac  e85f32ecff               call 0x1010
0013ddb1  488bc7                   mov rax, rdi
0013ddb4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013ddb9  4883c430                 add rsp, 0x30
0013ddbd  5f                       pop rdi
0013ddbe  c3                       ret
