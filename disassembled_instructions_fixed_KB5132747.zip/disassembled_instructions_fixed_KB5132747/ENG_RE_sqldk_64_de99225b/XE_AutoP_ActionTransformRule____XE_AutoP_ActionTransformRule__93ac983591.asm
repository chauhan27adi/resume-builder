; XE_AutoP<ActionTransformRule>::~XE_AutoP<ActionTransformRule>
; sqldk.dll, primary RVA 0x4db80, 61 bytes in 1 chunk(s)

; chunk at RVA 0x4db80 (61 bytes)
0004db80  48894c2408               mov qword ptr [rsp + 8], rcx
0004db85  53                       push rbx
0004db86  4883ec30                 sub rsp, 0x30
0004db8a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0004db93  488bd9                   mov rbx, rcx
0004db96  488b09                   mov rcx, qword ptr [rcx]
0004db99  4885c9                   test rcx, rcx
0004db9c  7406                     je 0x4dba4
0004db9e  ff15ac742c00             call qword ptr [rip + 0x2c74ac]
0004dba4  48c70300000000           mov qword ptr [rbx], 0
0004dbab  ba0c000000               mov edx, 0xc
0004dbb0  488b0b                   mov rcx, qword ptr [rbx]
0004dbb3  4883c430                 add rsp, 0x30
0004dbb7  5b                       pop rbx
0004dbb8  e97393fbff               jmp 0x6f30
