; `XEPackage0::CounterTarget::AddPackage'::`1'::dtor$1
; sqldk.dll, primary RVA 0x2318e0, 35 bytes in 1 chunk(s)

; chunk at RVA 0x2318e0 (35 bytes)
002318e0  4055                     push rbp
002318e2  4883ec20                 sub rsp, 0x20
002318e6  488bea                   mov rbp, rdx
002318e9  4c8b85b8000000           mov r8, qword ptr [rbp + 0xb8]
002318f0  488b5538                 mov rdx, qword ptr [rbp + 0x38]
002318f4  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
002318f8  e813f7dcff               call 0x1010
002318fd  4883c420                 add rsp, 0x20
00231901  5d                       pop rbp
00231902  c3                       ret
