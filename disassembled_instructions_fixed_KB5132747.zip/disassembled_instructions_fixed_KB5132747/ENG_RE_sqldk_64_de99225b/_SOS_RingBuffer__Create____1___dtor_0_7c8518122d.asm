; `SOS_RingBuffer::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22dbc0, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22dbc0 (59 bytes)
0022dbc0  4055                     push rbp
0022dbc2  4883ec30                 sub rsp, 0x30
0022dbc6  488bea                   mov rbp, rdx
0022dbc9  c644242806               mov byte ptr [rsp + 0x28], 6
0022dbce  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022dbd4  89442420                 mov dword ptr [rsp + 0x20], eax
0022dbd8  4c8d0dc9cc0600           lea r9, [rip + 0x6ccc9]
0022dbdf  41b801000000             mov r8d, 1
0022dbe5  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
0022dbec  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022dbf0  e81b93ddff               call 0x6f10
0022dbf5  4883c430                 add rsp, 0x30
0022dbf9  5d                       pop rbp
0022dbfa  c3                       ret
