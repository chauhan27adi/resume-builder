; TCallbackListBase<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType>,BaseSafeCallbackTraits<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType>,TListSLock,SOSCallbackEvent>::List>::~TCallbackListBase<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType>,BaseSafeCallbackTraits<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType>,TListSLock,SOSCallbackEvent>::List>
; sqldk.dll, primary RVA 0x6b310, 151 bytes in 1 chunk(s)

; chunk at RVA 0x6b310 (151 bytes)
0006b310  48894c2408               mov qword ptr [rsp + 8], rcx
0006b315  57                       push rdi
0006b316  4883ec50                 sub rsp, 0x50
0006b31a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0006b323  48895c2468               mov qword ptr [rsp + 0x68], rbx
0006b328  4889742470               mov qword ptr [rsp + 0x70], rsi
0006b32d  488bf1                   mov rsi, rcx
0006b330  e8db8cfbff               call 0x24010
0006b335  85c0                     test eax, eax
0006b337  7558                     jne 0x6b391
0006b339  488bce                   mov rcx, rsi
0006b33c  e8cf8cfbff               call 0x24010
0006b341  85c0                     test eax, eax
0006b343  754c                     jne 0x6b391
0006b345  0f57c0                   xorps xmm0, xmm0
0006b348  f30f7f442428             movdqu xmmword ptr [rsp + 0x28], xmm0
0006b34e  4533c0                   xor r8d, r8d
0006b351  488bd6                   mov rdx, rsi
0006b354  488d4c2428               lea rcx, [rsp + 0x28]
0006b359  e8928dfbff               call 0x240f0
0006b35e  90                       nop
0006b35f  33ff                     xor edi, edi
0006b361  488d4c2428               lea rcx, [rsp + 0x28]
0006b366  e8958efbff               call 0x24200
0006b36b  488bd8                   mov rbx, rax
0006b36e  4885ff                   test rdi, rdi
0006b371  740b                     je 0x6b37e
0006b373  488bd7                   mov rdx, rdi
0006b376  488bce                   mov rcx, rsi
0006b379  e872050000               call 0x6b8f0
0006b37e  488bfb                   mov rdi, rbx
0006b381  4885db                   test rbx, rbx
0006b384  75db                     jne 0x6b361
0006b386  488d4c2428               lea rcx, [rsp + 0x28]
0006b38b  e870a4fbff               call 0x25800
0006b390  90                       nop
0006b391  c706adde0080             mov dword ptr [rsi], 0x8000dead
0006b397  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0006b39c  488b742470               mov rsi, qword ptr [rsp + 0x70]
0006b3a1  4883c450                 add rsp, 0x50
0006b3a5  5f                       pop rdi
0006b3a6  c3                       ret
