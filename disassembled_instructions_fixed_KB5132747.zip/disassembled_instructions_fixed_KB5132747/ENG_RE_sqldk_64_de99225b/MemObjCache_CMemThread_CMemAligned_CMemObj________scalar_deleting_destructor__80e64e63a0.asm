; MemObjCache<CMemThread<CMemAligned<CMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13f190, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13f190 (79 bytes)
0013f190  48894c2408               mov qword ptr [rsp + 8], rcx
0013f195  57                       push rdi
0013f196  4883ec30                 sub rsp, 0x30
0013f19a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013f1a3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013f1a8  8bda                     mov ebx, edx
0013f1aa  488bf9                   mov rdi, rcx
0013f1ad  488d054c531200           lea rax, [rip + 0x12534c]
0013f1b4  488901                   mov qword ptr [rcx], rax
0013f1b7  e8b4f2feff               call 0x12e470
0013f1bc  83e305                   and ebx, 5
0013f1bf  80fb05                   cmp bl, 5
0013f1c2  750d                     jne 0x13f1d1
0013f1c4  ba58020000               mov edx, 0x258
0013f1c9  488bcf                   mov rcx, rdi
0013f1cc  e83f1eecff               call 0x1010
0013f1d1  488bc7                   mov rax, rdi
0013f1d4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013f1d9  4883c430                 add rsp, 0x30
0013f1dd  5f                       pop rdi
0013f1de  c3                       ret
