; SOSHost_CacheStore::~SOSHost_CacheStore
; sqldk.dll, primary RVA 0x180fb0, 48 bytes in 1 chunk(s)

; chunk at RVA 0x180fb0 (48 bytes)
00180fb0  48894c2408               mov qword ptr [rsp + 8], rcx
00180fb5  4883ec38                 sub rsp, 0x38
00180fb9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00180fc2  488d055feb0c00           lea rax, [rip + 0xceb5f]
00180fc9  488901                   mov qword ptr [rcx], rax
00180fcc  488d05e53b0e00           lea rax, [rip + 0xe3be5]
00180fd3  48894140                 mov qword ptr [rcx + 0x40], rax
00180fd7  4883c438                 add rsp, 0x38
00180fdb  e940120000               jmp 0x182220
