; AutoSpinlockHolder<10,3,268435714>::~AutoSpinlockHolder<10,3,268435714>
; sqldk.dll, primary RVA 0x87a90, 111 bytes in 1 chunk(s)

; chunk at RVA 0x87a90 (111 bytes)
00087a90  48894c2408               mov qword ptr [rsp + 8], rcx
00087a95  57                       push rdi
00087a96  4883ec30                 sub rsp, 0x30
00087a9a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00087aa3  48895c2448               mov qword ptr [rsp + 0x48], rbx
00087aa8  488bd9                   mov rbx, rcx
00087aab  488b39                   mov rdi, qword ptr [rcx]
00087aae  4885ff                   test rdi, rdi
00087ab1  7441                     je 0x87af4
00087ab3  83790800                 cmp dword ptr [rcx + 8], 0
00087ab7  743b                     je 0x87af4
00087ab9  803d01da280000           cmp byte ptr [rip + 0x28da01], 0
00087ac0  7427                     je 0x87ae9
00087ac2  ff15801f1b00             call qword ptr [rip + 0x1b1f80]
00087ac8  448bc0                   mov r8d, eax
00087acb  b867666666               mov eax, 0x66666667
00087ad0  41f7e8                   imul r8d
00087ad3  d1fa                     sar edx, 1
00087ad5  8bca                     mov ecx, edx
00087ad7  c1e91f                   shr ecx, 0x1f
00087ada  03d1                     add edx, ecx
00087adc  8d0c92                   lea ecx, [rdx + rdx*4]
00087adf  443bc1                   cmp r8d, ecx
00087ae2  7505                     jne 0x87ae9
00087ae4  e857feffff               call 0x87940
00087ae9  33c0                     xor eax, eax
00087aeb  488907                   mov qword ptr [rdi], rax
00087aee  488903                   mov qword ptr [rbx], rax
00087af1  894308                   mov dword ptr [rbx + 8], eax
00087af4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00087af9  4883c430                 add rsp, 0x30
00087afd  5f                       pop rdi
00087afe  c3                       ret
