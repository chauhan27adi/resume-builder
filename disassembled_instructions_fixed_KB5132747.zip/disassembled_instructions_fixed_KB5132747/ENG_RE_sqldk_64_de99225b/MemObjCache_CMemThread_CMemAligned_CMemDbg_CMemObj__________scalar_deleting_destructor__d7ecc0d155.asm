; MemObjCache<CMemThread<CMemAligned<CMemDbg<CMemObj> > > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13f270, 128 bytes in 1 chunk(s)

; chunk at RVA 0x13f270 (128 bytes)
0013f270  48894c2408               mov qword ptr [rsp + 8], rcx
0013f275  57                       push rdi
0013f276  4883ec30                 sub rsp, 0x30
0013f27a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013f283  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013f288  8bda                     mov ebx, edx
0013f28a  488bf9                   mov rdi, rcx
0013f28d  488d0514511200           lea rax, [rip + 0x125114]
0013f294  488901                   mov qword ptr [rcx], rax
0013f297  488d051a881000           lea rax, [rip + 0x10881a]
0013f29e  488901                   mov qword ptr [rcx], rax
0013f2a1  488d8100050000           lea rax, [rcx + 0x500]
0013f2a8  4889442450               mov qword ptr [rsp + 0x50], rax
0013f2ad  488d0d8ca80f00           lea rcx, [rip + 0xfa88c]
0013f2b4  48894830                 mov qword ptr [rax + 0x30], rcx
0013f2b8  488908                   mov qword ptr [rax], rcx
0013f2bb  488d056ec41000           lea rax, [rip + 0x10c46e]
0013f2c2  488907                   mov qword ptr [rdi], rax
0013f2c5  488bcf                   mov rcx, rdi
0013f2c8  e803f30200               call 0x16e5d0
0013f2cd  83e305                   and ebx, 5
0013f2d0  80fb05                   cmp bl, 5
0013f2d3  750d                     jne 0x13f2e2
0013f2d5  ba28060000               mov edx, 0x628
0013f2da  488bcf                   mov rcx, rdi
0013f2dd  e82e1decff               call 0x1010
0013f2e2  488bc7                   mov rax, rdi
0013f2e5  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013f2ea  4883c430                 add rsp, 0x30
0013f2ee  5f                       pop rdi
0013f2ef  c3                       ret
