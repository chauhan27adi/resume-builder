; DescriptorAllocator<SOS_MemoryFreeBlock,0>::Pop
; sqldk.dll, primary RVA 0x28970, 624 bytes in 3 chunk(s)

; chunk at RVA 0x28970 (85 bytes)
00028970  89542410                 mov dword ptr [rsp + 0x10], edx
00028974  4154                     push r12
00028976  4155                     push r13
00028978  4156                     push r14
0002897a  4157                     push r15
0002897c  4881ec88000000           sub rsp, 0x88
00028983  4c8bf1                   mov r14, rcx
00028986  8bc2                     mov eax, edx
00028988  0fb689cc040000           movzx ecx, byte ptr [rcx + 0x4cc]
0002898f  4d8bf8                   mov r15, r8
00028992  4533c0                   xor r8d, r8d
00028995  48d3e0                   shl rax, cl
00028998  4532ed                   xor r13b, r13b
0002899b  448bd2                   mov r10d, edx
0002899e  490386c0040000           add rax, qword ptr [r14 + 0x4c0]
000289a5  4532e4                   xor r12b, r12b
000289a8  4889442438               mov qword ptr [rsp + 0x38], rax
000289ad  4489442458               mov dword ptr [rsp + 0x58], r8d
000289b2  4c89442460               mov qword ptr [rsp + 0x60], r8
000289b7  4c89442468               mov qword ptr [rsp + 0x68], r8
000289bc  4d85c9                   test r9, r9
000289bf  0f85b51e0700             jne 0x9a87a

; chunk at RVA 0x289c5 (405 bytes)
000289c5  48899c24c0000000         mov qword ptr [rsp + 0xc0], rbx
000289cd  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000289d2  4889ac2480000000         mov qword ptr [rsp + 0x80], rbp
000289da  4889742478               mov qword ptr [rsp + 0x78], rsi
000289df  48897c2470               mov qword ptr [rsp + 0x70], rdi
000289e4  488b7c2450               mov rdi, qword ptr [rsp + 0x50]
000289e9  c78424b000000001000000   mov dword ptr [rsp + 0xb0], 1
000289f4  0f1f4000                 nop dword ptr [rax]
000289f8  0f1f840000000000         nop dword ptr [rax + rax]
00028a00  488b7008                 mov rsi, qword ptr [rax + 8]
00028a04  4885f6                   test rsi, rsi
00028a07  0f85dc000000             jne 0x28ae9
00028a0d  410fb68ecc040000         movzx ecx, byte ptr [r14 + 0x4cc]
00028a15  418bd2                   mov edx, r10d
00028a18  48d3e2                   shl rdx, cl
00028a1b  490396c0040000           add rdx, qword ptr [r14 + 0x4c0]
00028a22  418bc2                   mov eax, r10d
00028a25  0fb72a                   movzx ebp, word ptr [rdx]
00028a28  6683fd40                 cmp bp, 0x40
00028a2c  0f84cd010000             je 0x28bff
00028a32  440fb7cd                 movzx r9d, bp
00028a36  44886c2420               mov byte ptr [rsp + 0x20], r13b
00028a3b  458bc2                   mov r8d, r10d
00028a3e  488bd6                   mov rdx, rsi
00028a41  498bce                   mov rcx, r14
00028a44  e897020000               call 0x28ce0
00028a49  84c0                     test al, al
00028a4b  7529                     jne 0x28a76
00028a4d  448b8424b8000000         mov r8d, dword ptr [rsp + 0xb8]
00028a55  440fb7cd                 movzx r9d, bp
00028a59  4c897c2428               mov qword ptr [rsp + 0x28], r15
00028a5e  488bd6                   mov rdx, rsi
00028a61  498bce                   mov rcx, r14
00028a64  44886c2420               mov byte ptr [rsp + 0x20], r13b
00028a69  e8b2050000               call 0x29020
00028a6e  84c0                     test al, al
00028a70  0f84491e0700             je 0x9a8bf
00028a76  8bac24b0000000           mov ebp, dword ptr [rsp + 0xb0]
00028a7d  f7c5ff1f0000             test ebp, 0x1fff
00028a83  0f84481e0700             je 0x9a8d1
00028a89  4584e4                   test r12b, r12b
00028a8c  0f8494010000             je 0x28c26
00028a92  833d2bca2e0000           cmp dword ptr [rip + 0x2eca2b], 0
00028a99  0f84401f0700             je 0x9a9df
00028a9f  488d4c2430               lea rcx, [rsp + 0x30]
00028aa4  ff15260a2100             call qword ptr [rip + 0x210a26]
00028aaa  488b442430               mov rax, qword ptr [rsp + 0x30]
00028aaf  eb01                     jmp 0x28ab2
00028ab1  cc                       int3
00028ab2  483bc7                   cmp rax, rdi
00028ab5  0f82321f0700             jb 0x9a9ed
00028abb  482bc7                   sub rax, rdi
00028abe  4533c0                   xor r8d, r8d
00028ac1  eb01                     jmp 0x28ac4
00028ac3  cc                       int3
00028ac4  483bc3                   cmp rax, rbx
00028ac7  0f874c1f0700             ja 0x9aa19
00028acd  488b442438               mov rax, qword ptr [rsp + 0x38]
00028ad2  ffc5                     inc ebp
00028ad4  448b9424b8000000         mov r10d, dword ptr [rsp + 0xb8]
00028adc  89ac24b0000000           mov dword ptr [rsp + 0xb0], ebp
00028ae3  e918ffffff               jmp 0x28a00
00028ae8  cc                       int3
00028ae9  488bce                   mov rcx, rsi
00028aec  ff1526072100             call qword ptr [rip + 0x210726]
00028af2  488be8                   mov rbp, rax
00028af5  4885c0                   test rax, rax
00028af8  0f85a90c0100             jne 0x397a7
00028afe  4533c0                   xor r8d, r8d
00028b01  418be8                   mov ebp, r8d
00028b04  488b5618                 mov rdx, qword ptr [rsi + 0x18]
00028b08  4885d2                   test rdx, rdx
00028b0b  7432                     je 0x28b3f
00028b0d  0f1f00                   nop dword ptr [rax]
00028b10  498be8                   mov rbp, r8
00028b13  483bd6                   cmp rdx, rsi
00028b16  7327                     jae 0x28b3f
00028b18  0faee8                   lfence
00028b1b  488d4a40                 lea rcx, [rdx + 0x40]
00028b1f  488bc2                   mov rax, rdx
00028b22  483bce                   cmp rcx, rsi
00028b25  490f44c8                 cmove rcx, r8
00028b29  f0480fb14e18             lock cmpxchg qword ptr [rsi + 0x18], rcx
00028b2f  0f85631d0700             jne 0x9a898
00028b35  0faee8                   lfence
00028b38  f0ff4e28                 lock dec dword ptr [rsi + 0x28]
00028b3c  488bea                   mov rbp, rdx
00028b3f  4885ed                   test rbp, rbp
00028b42  0f84601d0700             je 0x9a8a8
00028b48  488b742478               mov rsi, qword ptr [rsp + 0x78]
00028b4d  488b9c24c0000000         mov rbx, qword ptr [rsp + 0xc0]
00028b55  4584e4                   test r12b, r12b
00028b58  7466                     je 0x28bc0

; chunk at RVA 0x28b5a (134 bytes)
00028b5a  833d63c92e0000           cmp dword ptr [rip + 0x2ec963], 0
00028b61  0f84bd1e0700             je 0x9aa24
00028b67  488d4c2440               lea rcx, [rsp + 0x40]
00028b6c  ff155e092100             call qword ptr [rip + 0x21095e]
00028b72  488b4c2440               mov rcx, qword ptr [rsp + 0x40]
00028b77  eb01                     jmp 0x28b7a
00028b79  cc                       int3
00028b7a  483bcf                   cmp rcx, rdi
00028b7d  0f82b71e0700             jb 0x9aa3a
00028b83  482bcf                   sub rcx, rdi
00028b86  4883f9ff                 cmp rcx, -1
00028b8a  0f84a21e0700             je 0x9aa32
00028b90  833d2dc92e0000           cmp dword ptr [rip + 0x2ec92d], 0
00028b97  0f84a51e0700             je 0x9aa42
00028b9d  33d2                     xor edx, edx
00028b9f  4869c1e8030000           imul rax, rcx, 0x3e8
00028ba6  48f7351bc92e00           div qword ptr [rip + 0x2ec91b]
00028bad  488bd0                   mov rdx, rax
00028bb0  eb01                     jmp 0x28bb3
00028bb2  cc                       int3
00028bb3  498b4620                 mov rax, qword ptr [r14 + 0x20]
00028bb7  483bd0                   cmp rdx, rax
00028bba  0f87991e0700             ja 0x9aa59
00028bc0  488b7c2470               mov rdi, qword ptr [rsp + 0x70]
00028bc5  488bc5                   mov rax, rbp
00028bc8  488bac2480000000         mov rbp, qword ptr [rsp + 0x80]
00028bd0  4881c488000000           add rsp, 0x88
00028bd7  415f                     pop r15
00028bd9  415e                     pop r14
00028bdb  415d                     pop r13
00028bdd  415c                     pop r12
00028bdf  c3                       ret
