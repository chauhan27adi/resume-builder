; `DefaultAutoXactFactory::CreateNewAutoReadOnlyXact'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22fac0, 44 bytes in 1 chunk(s)

; chunk at RVA 0x22fac0 (44 bytes)
0022fac0  4055                     push rbp
0022fac2  4883ec30                 sub rsp, 0x30
0022fac6  488bea                   mov rbp, rdx
0022fac9  c644242006               mov byte ptr [rsp + 0x20], 6
0022face  448b4d58                 mov r9d, dword ptr [rbp + 0x58]
0022fad2  4c8d05c7180700           lea r8, [rip + 0x718c7]
0022fad9  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0022fadd  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
0022fae1  e82a74ddff               call 0x6f10
0022fae6  4883c430                 add rsp, 0x30
0022faea  5d                       pop rbp
0022faeb  c3                       ret
