; CAutoRg<EventTypeEntry>::~CAutoRg<EventTypeEntry>
; sqldk.dll, primary RVA 0x4e040, 84 bytes in 3 chunk(s)

; chunk at RVA 0x4e040 (23 bytes)
0004e040  4883ec28                 sub rsp, 0x28
0004e044  488b09                   mov rcx, qword ptr [rcx]
0004e047  4885c9                   test rcx, rcx
0004e04a  7444                     je 0x4e090
0004e04c  4c8b41f8                 mov r8, qword ptr [rcx - 8]
0004e050  4c8d0d99f8ffff           lea r9, [rip - 0x767]

; chunk at RVA 0x4e057 (51 bytes)
0004e057  48895c2420               mov qword ptr [rsp + 0x20], rbx
0004e05c  ba18000000               mov edx, 0x18
0004e061  488d59f8                 lea rbx, [rcx - 8]
0004e065  e8b667fdff               call 0x24820
0004e06a  488b03                   mov rax, qword ptr [rbx]
0004e06d  488bcb                   mov rcx, rbx
0004e070  488d1440                 lea rdx, [rax + rax*2]
0004e074  488d14d508000000         lea rdx, [rdx*8 + 8]
0004e07c  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0004e081  4883c428                 add rsp, 0x28
0004e085  e9a68efbff               jmp 0x6f30

; chunk at RVA 0x4e08b (10 bytes)
0004e08b  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0004e090  4883c428                 add rsp, 0x28
0004e094  c3                       ret
