; CMemThread<CMemAligned<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e420, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13e420 (55 bytes)
0013e420  48895c2408               mov qword ptr [rsp + 8], rbx
0013e425  57                       push rdi
0013e426  4883ec20                 sub rsp, 0x20
0013e42a  8bda                     mov ebx, edx
0013e42c  488bf9                   mov rdi, rcx
0013e42f  e82c24fcff               call 0x100860
0013e434  83e305                   and ebx, 5
0013e437  80fb05                   cmp bl, 5
0013e43a  750d                     jne 0x13e449
0013e43c  bae8010000               mov edx, 0x1e8
0013e441  488bcf                   mov rcx, rdi
0013e444  e8c72becff               call 0x1010
0013e449  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013e44e  488bc7                   mov rax, rdi
0013e451  4883c420                 add rsp, 0x20
0013e455  5f                       pop rdi
0013e456  c3                       ret
