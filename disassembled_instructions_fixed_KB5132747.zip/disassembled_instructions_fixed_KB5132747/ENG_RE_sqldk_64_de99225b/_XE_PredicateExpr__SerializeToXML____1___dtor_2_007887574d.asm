; `XE_PredicateExpr::SerializeToXML'::`1'::dtor$2
; sqldk.dll, primary RVA 0x236140, 56 bytes in 1 chunk(s)

; chunk at RVA 0x236140 (56 bytes)
00236140  4055                     push rbp
00236142  4883ec30                 sub rsp, 0x30
00236146  488bea                   mov rbp, rdx
00236149  c644242806               mov byte ptr [rsp + 0x28], 6
0023614e  8b4530                   mov eax, dword ptr [rbp + 0x30]
00236151  89442420                 mov dword ptr [rsp + 0x20], eax
00236155  4c8d0d44460700           lea r9, [rip + 0x74644]
0023615c  41b801000000             mov r8d, 1
00236162  488b1557c51700           mov rdx, qword ptr [rip + 0x17c557]
00236169  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
0023616d  e87e3dfaff               call 0x1d9ef0
00236172  4883c430                 add rsp, 0x30
00236176  5d                       pop rbp
00236177  c3                       ret
