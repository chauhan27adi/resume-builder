; TEnumerator<TList<ExternalPoolList,SOS_ExternalResourcePool,0,TListSLock> >::~TEnumerator<TList<ExternalPoolList,SOS_ExternalResourcePool,0,TListSLock> >
; sqldk.dll, primary RVA 0x1a54b0, 187 bytes in 1 chunk(s)

; chunk at RVA 0x1a54b0 (187 bytes)
001a54b0  48895c2410               mov qword ptr [rsp + 0x10], rbx
001a54b5  48896c2418               mov qword ptr [rsp + 0x18], rbp
001a54ba  4889742420               mov qword ptr [rsp + 0x20], rsi
001a54bf  57                       push rdi
001a54c0  4883ec20                 sub rsp, 0x20
001a54c4  488b39                   mov rdi, qword ptr [rcx]
001a54c7  33ed                     xor ebp, ebp
001a54c9  488bd9                   mov rbx, rcx
001a54cc  beffffffff               mov esi, 0xffffffff
001a54d1  4885ff                   test rdi, rdi
001a54d4  742e                     je 0x1a5504
001a54d6  8bc6                     mov eax, esi
001a54d8  f00fc14718               lock xadd dword ptr [rdi + 0x18], eax
001a54dd  83f801                   cmp eax, 1
001a54e0  751f                     jne 0x1a5501
001a54e2  48396f08                 cmp qword ptr [rdi + 8], rbp
001a54e6  740c                     je 0x1a54f4
001a54e8  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
001a54ec  488bd7                   mov rdx, rdi
001a54ef  e8bcbee6ff               call 0x113b0
001a54f4  baf8010000               mov edx, 0x1f8
001a54f9  488bcf                   mov rcx, rdi
001a54fc  e82f1ae6ff               call 0x6f30
001a5501  48892b                   mov qword ptr [rbx], rbp
001a5504  488b7b08                 mov rdi, qword ptr [rbx + 8]
001a5508  4885ff                   test rdi, rdi
001a550b  742d                     je 0x1a553a
001a550d  f00fc17718               lock xadd dword ptr [rdi + 0x18], esi
001a5512  83fe01                   cmp esi, 1
001a5515  751f                     jne 0x1a5536
001a5517  48396f08                 cmp qword ptr [rdi + 8], rbp
001a551b  740c                     je 0x1a5529
001a551d  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
001a5521  488bd7                   mov rdx, rdi
001a5524  e887bee6ff               call 0x113b0
001a5529  baf8010000               mov edx, 0x1f8
001a552e  488bcf                   mov rcx, rdi
001a5531  e8fa19e6ff               call 0x6f30
001a5536  48896b08                 mov qword ptr [rbx + 8], rbp
001a553a  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001a553e  4885c9                   test rcx, rcx
001a5541  740f                     je 0x1a5552
001a5543  8b5320                   mov edx, dword ptr [rbx + 0x20]
001a5546  e8b506e6ff               call 0x5c00
001a554b  48896b18                 mov qword ptr [rbx + 0x18], rbp
001a554f  896b20                   mov dword ptr [rbx + 0x20], ebp
001a5552  488b742448               mov rsi, qword ptr [rsp + 0x48]
001a5557  48896b10                 mov qword ptr [rbx + 0x10], rbp
001a555b  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
001a5560  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
001a5565  4883c420                 add rsp, 0x20
001a5569  5f                       pop rdi
001a556a  c3                       ret
