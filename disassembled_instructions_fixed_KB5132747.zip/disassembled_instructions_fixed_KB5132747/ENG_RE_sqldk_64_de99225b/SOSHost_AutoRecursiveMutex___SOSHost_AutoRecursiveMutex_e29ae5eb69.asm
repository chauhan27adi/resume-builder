; SOSHost_AutoRecursiveMutex::~SOSHost_AutoRecursiveMutex
; sqldk.dll, primary RVA 0x1ea6c0, 68 bytes in 3 chunk(s)

; chunk at RVA 0x1ea6c0 (15 bytes)
001ea6c0  4053                     push rbx
001ea6c2  4883ec20                 sub rsp, 0x20
001ea6c6  83791000                 cmp dword ptr [rcx + 0x10], 0
001ea6ca  488bd9                   mov rbx, rcx
001ea6cd  762f                     jbe 0x1ea6fe

; chunk at RVA 0x1ea6cf (47 bytes)
001ea6cf  48897c2430               mov qword ptr [rsp + 0x30], rdi
001ea6d4  33ff                     xor edi, edi
001ea6d6  488b0b                   mov rcx, qword ptr [rbx]
001ea6d9  4883694001               sub qword ptr [rcx + 0x40], 1
001ea6de  7513                     jne 0x1ea6f3
001ea6e0  f0093c24                 lock or dword ptr [rsp], edi
001ea6e4  33d2                     xor edx, edx
001ea6e6  48897930                 mov qword ptr [rcx + 0x30], rdi
001ea6ea  48897938                 mov qword ptr [rcx + 0x38], rdi
001ea6ee  e8fdb7e1ff               call 0x5ef0
001ea6f3  834310ff                 add dword ptr [rbx + 0x10], -1
001ea6f7  75dd                     jne 0x1ea6d6
001ea6f9  488b7c2430               mov rdi, qword ptr [rsp + 0x30]

; chunk at RVA 0x1ea6fe (6 bytes)
001ea6fe  4883c420                 add rsp, 0x20
001ea702  5b                       pop rbx
001ea703  c3                       ret
