; CAutoRefc<XE_TargetEntry>::~CAutoRefc<XE_TargetEntry>
; sqldk.dll, primary RVA 0x1eeb00, 67 bytes in 1 chunk(s)

; chunk at RVA 0x1eeb00 (67 bytes)
001eeb00  4053                     push rbx
001eeb02  4883ec20                 sub rsp, 0x20
001eeb06  488b19                   mov rbx, qword ptr [rcx]
001eeb09  4885db                   test rbx, rbx
001eeb0c  742f                     je 0x1eeb3d
001eeb0e  b8ffffffff               mov eax, 0xffffffff
001eeb13  f00fc14318               lock xadd dword ptr [rbx + 0x18], eax
001eeb18  83f801                   cmp eax, 1
001eeb1b  7520                     jne 0x1eeb3d
001eeb1d  48837b1000               cmp qword ptr [rbx + 0x10], 0
001eeb22  740c                     je 0x1eeb30
001eeb24  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
001eeb28  488bd3                   mov rdx, rbx
001eeb2b  e8b0b9ffff               call 0x1ea4e0
001eeb30  488bcb                   mov rcx, rbx
001eeb33  4883c420                 add rsp, 0x20
001eeb37  5b                       pop rbx
001eeb38  e9d3600000               jmp 0x1f4c10
001eeb3d  4883c420                 add rsp, 0x20
001eeb41  5b                       pop rbx
001eeb42  c3                       ret
