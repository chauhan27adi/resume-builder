; MemObjCache<CMemDbg<CMemProc> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13dcb0, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13dcb0 (79 bytes)
0013dcb0  48894c2408               mov qword ptr [rsp + 8], rcx
0013dcb5  57                       push rdi
0013dcb6  4883ec30                 sub rsp, 0x30
0013dcba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013dcc3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013dcc8  8bda                     mov ebx, edx
0013dcca  488bf9                   mov rdi, rcx
0013dccd  488d05eccc1000           lea rax, [rip + 0x10ccec]
0013dcd4  488901                   mov qword ptr [rcx], rax
0013dcd7  e8f41d0300               call 0x16fad0
0013dcdc  83e305                   and ebx, 5
0013dcdf  80fb05                   cmp bl, 5
0013dce2  750d                     jne 0x13dcf1
0013dce4  bac0040000               mov edx, 0x4c0
0013dce9  488bcf                   mov rcx, rdi
0013dcec  e81f33ecff               call 0x1010
0013dcf1  488bc7                   mov rax, rdi
0013dcf4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013dcf9  4883c430                 add rsp, 0x30
0013dcfd  5f                       pop rdi
0013dcfe  c3                       ret
