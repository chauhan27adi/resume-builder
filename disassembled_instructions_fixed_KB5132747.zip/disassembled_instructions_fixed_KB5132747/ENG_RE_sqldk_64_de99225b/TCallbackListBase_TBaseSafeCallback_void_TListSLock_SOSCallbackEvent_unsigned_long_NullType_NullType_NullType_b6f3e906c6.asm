; TCallbackListBase<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,unsigned long,NullType,NullType,NullType>,BaseSafeCallbackTraits<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,unsigned long,NullType,NullType,NullType>,TListSLock,SOSCallbackEvent>::List>::~TCallbackListBase<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,unsigned long,NullType,NullType,NullType>,BaseSafeCallbackTraits<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,unsigned long,NullType,NullType,NullType>,TListSLock,SOSCallbackEvent>::List>
; sqldk.dll, primary RVA 0x6b260, 159 bytes in 1 chunk(s)

; chunk at RVA 0x6b260 (159 bytes)
0006b260  48894c2408               mov qword ptr [rsp + 8], rcx
0006b265  57                       push rdi
0006b266  4883ec50                 sub rsp, 0x50
0006b26a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0006b273  48895c2468               mov qword ptr [rsp + 0x68], rbx
0006b278  4889742470               mov qword ptr [rsp + 0x70], rsi
0006b27d  488bf1                   mov rsi, rcx
0006b280  e88b8dfbff               call 0x24010
0006b285  85c0                     test eax, eax
0006b287  7560                     jne 0x6b2e9
0006b289  488bce                   mov rcx, rsi
0006b28c  e87f8dfbff               call 0x24010
0006b291  85c0                     test eax, eax
0006b293  7554                     jne 0x6b2e9
0006b295  0f57c0                   xorps xmm0, xmm0
0006b298  f30f7f442428             movdqu xmmword ptr [rsp + 0x28], xmm0
0006b29e  4533c0                   xor r8d, r8d
0006b2a1  488bd6                   mov rdx, rsi
0006b2a4  488d4c2428               lea rcx, [rsp + 0x28]
0006b2a9  e8428efbff               call 0x240f0
0006b2ae  90                       nop
0006b2af  33db                     xor ebx, ebx
0006b2b1  488d4c2428               lea rcx, [rsp + 0x28]
0006b2b6  e8458ffbff               call 0x24200
0006b2bb  488bf8                   mov rdi, rax
0006b2be  4885db                   test rbx, rbx
0006b2c1  7413                     je 0x6b2d6
0006b2c3  488bd3                   mov rdx, rbx
0006b2c6  488bce                   mov rcx, rsi
0006b2c9  e8e2f5ffff               call 0x6a8b0
0006b2ce  488bcb                   mov rcx, rbx
0006b2d1  e8daefffff               call 0x6a2b0
0006b2d6  488bdf                   mov rbx, rdi
0006b2d9  4885ff                   test rdi, rdi
0006b2dc  75d3                     jne 0x6b2b1
0006b2de  488d4c2428               lea rcx, [rsp + 0x28]
0006b2e3  e818a5fbff               call 0x25800
0006b2e8  90                       nop
0006b2e9  c706adde0080             mov dword ptr [rsi], 0x8000dead
0006b2ef  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0006b2f4  488b742470               mov rsi, qword ptr [rsp + 0x70]
0006b2f9  4883c450                 add rsp, 0x50
0006b2fd  5f                       pop rdi
0006b2fe  c3                       ret
