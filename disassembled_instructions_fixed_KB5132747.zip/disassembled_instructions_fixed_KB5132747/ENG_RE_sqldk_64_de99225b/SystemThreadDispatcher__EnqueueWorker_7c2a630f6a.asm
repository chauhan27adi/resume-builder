; SystemThreadDispatcher::EnqueueWorker
; sqldk.dll, primary RVA 0x27960, 261 bytes in 1 chunk(s)

; chunk at RVA 0x27960 (261 bytes)
00027960  4055                     push rbp
00027962  56                       push rsi
00027963  57                       push rdi
00027964  4154                     push r12
00027966  4155                     push r13
00027968  4156                     push r14
0002796a  4157                     push r15
0002796c  4883ec40                 sub rsp, 0x40
00027970  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00027979  48899c2488000000         mov qword ptr [rsp + 0x88], rbx
00027981  458be8                   mov r13d, r8d
00027984  488bea                   mov rbp, rdx
00027987  488bf9                   mov rdi, rcx
0002798a  4533e4                   xor r12d, r12d
0002798d  44396108                 cmp dword ptr [rcx + 8], r12d
00027991  0f8531430400             jne 0x6bcc8
00027997  4c8d7740                 lea r14, [rdi + 0x40]
0002799b  4c89742430               mov qword ptr [rsp + 0x30], r14
000279a0  4489642438               mov dword ptr [rsp + 0x38], r12d
000279a5  33db                     xor ebx, ebx
000279a7  658b042548000000         mov eax, dword ptr gs:[0x48]
000279af  448bf8                   mov r15d, eax
000279b2  418b06                   mov eax, dword ptr [r14]
000279b5  85c0                     test eax, eax
000279b7  0f8571f10000             jne 0x36b2e
000279bd  33c0                     xor eax, eax
000279bf  f04d0fb13e               lock cmpxchg qword ptr [r14], r15
000279c4  8bc3                     mov eax, ebx
000279c6  0f94c0                   sete al
000279c9  85c0                     test eax, eax
000279cb  0f845df10000             je 0x36b2e
000279d1  c744243801000000         mov dword ptr [rsp + 0x38], 1
000279d9  488d5720                 lea rdx, [rdi + 0x20]
000279dd  488b4a08                 mov rcx, qword ptr [rdx + 8]
000279e1  33db                     xor ebx, ebx
000279e3  483bca                   cmp rcx, rdx
000279e6  0f8566060000             jne 0x28052
000279ec  837f0800                 cmp dword ptr [rdi + 8], 0
000279f0  0f8560430400             jne 0x6bd56
000279f6  488d5710                 lea rdx, [rdi + 0x10]
000279fa  488d4d08                 lea rcx, [rbp + 8]
000279fe  488b02                   mov rax, qword ptr [rdx]
00027a01  488901                   mov qword ptr [rcx], rax
00027a04  488b02                   mov rax, qword ptr [rdx]
00027a07  48894808                 mov qword ptr [rax + 8], rcx
00027a0b  48890a                   mov qword ptr [rdx], rcx
00027a0e  48895108                 mov qword ptr [rcx + 8], rdx
00027a12  488b742430               mov rsi, qword ptr [rsp + 0x30]
00027a17  4885f6                   test rsi, rsi
00027a1a  7425                     je 0x27a41
00027a1c  803d9eda2e0000           cmp byte ptr [rip + 0x2eda9e], 0
00027a23  0f8543430400             jne 0x6bd6c
00027a29  48c70600000000           mov qword ptr [rsi], 0
00027a30  48c744243000000000       mov qword ptr [rsp + 0x30], 0
00027a39  c744243800000000         mov dword ptr [rsp + 0x38], 0
00027a41  4885db                   test rbx, rbx
00027a44  0f8554060000             jne 0x2809e
00027a4a  418bc4                   mov eax, r12d
00027a4d  488b9c2488000000         mov rbx, qword ptr [rsp + 0x88]
00027a55  4883c440                 add rsp, 0x40
00027a59  415f                     pop r15
00027a5b  415e                     pop r14
00027a5d  415d                     pop r13
00027a5f  415c                     pop r12
00027a61  5f                       pop rdi
00027a62  5e                       pop rsi
00027a63  5d                       pop rbp
00027a64  c3                       ret
