; `StackFramesStore::Create'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22daf4, 62 bytes in 1 chunk(s)

; chunk at RVA 0x22daf4 (62 bytes)
0022daf4  4055                     push rbp
0022daf6  4883ec30                 sub rsp, 0x30
0022dafa  488bea                   mov rbp, rdx
0022dafd  c644242806               mov byte ptr [rsp + 0x28], 6
0022db02  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022db08  89442420                 mov dword ptr [rsp + 0x20], eax
0022db0c  4c8d0d15cd0600           lea r9, [rip + 0x6cd15]
0022db13  41b801000000             mov r8d, 1
0022db19  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
0022db20  488b8da8000000           mov rcx, qword ptr [rbp + 0xa8]
0022db27  e8e493ddff               call 0x6f10
0022db2c  4883c430                 add rsp, 0x30
0022db30  5d                       pop rbp
0022db31  c3                       ret
