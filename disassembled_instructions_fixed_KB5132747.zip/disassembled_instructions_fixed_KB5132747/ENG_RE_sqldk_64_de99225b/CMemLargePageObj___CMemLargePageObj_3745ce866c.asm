; CMemLargePageObj::~CMemLargePageObj
; sqldk.dll, primary RVA 0x89a30, 85 bytes in 1 chunk(s)

; chunk at RVA 0x89a30 (85 bytes)
00089a30  48894c2408               mov qword ptr [rsp + 8], rcx
00089a35  53                       push rbx
00089a36  4883ec30                 sub rsp, 0x30
00089a3a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00089a43  488bd9                   mov rbx, rcx
00089a46  488d05cbd31b00           lea rax, [rip + 0x1bd3cb]
00089a4d  488901                   mov qword ptr [rcx], rax
00089a50  488d0511d51b00           lea rax, [rip + 0x1bd511]
00089a57  488901                   mov qword ptr [rcx], rax
00089a5a  488d05a7d71b00           lea rax, [rip + 0x1bd7a7]
00089a61  488901                   mov qword ptr [rcx], rax
00089a64  4883c138                 add rcx, 0x38
00089a68  e8837bf8ff               call 0x115f0
00089a6d  90                       nop
00089a6e  488d4b30                 lea rcx, [rbx + 0x30]
00089a72  e8797bf8ff               call 0x115f0
00089a77  90                       nop
00089a78  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
00089a7f  4883c430                 add rsp, 0x30
00089a83  5b                       pop rbx
00089a84  c3                       ret
