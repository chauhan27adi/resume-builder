; SOS_MemoryNodeEnum::~SOS_MemoryNodeEnum
; sqldk.dll, primary RVA 0x9e0d0, 165 bytes in 1 chunk(s)

; chunk at RVA 0x9e0d0 (165 bytes)
0009e0d0  48894c2408               mov qword ptr [rsp + 8], rcx
0009e0d5  57                       push rdi
0009e0d6  4883ec30                 sub rsp, 0x30
0009e0da  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0009e0e3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0009e0e8  4889742450               mov qword ptr [rsp + 0x50], rsi
0009e0ed  488bd9                   mov rbx, rcx
0009e0f0  488b09                   mov rcx, qword ptr [rcx]
0009e0f3  bfffffffff               mov edi, 0xffffffff
0009e0f8  33f6                     xor esi, esi
0009e0fa  4885c9                   test rcx, rcx
0009e0fd  7421                     je 0x9e120
0009e0ff  8bc7                     mov eax, edi
0009e101  f00fc14118               lock xadd dword ptr [rcx + 0x18], eax
0009e106  83f801                   cmp eax, 1
0009e109  7512                     jne 0x9e11d
0009e10b  48397108                 cmp qword ptr [rcx + 8], rsi
0009e10f  740c                     je 0x9e11d
0009e111  488bd1                   mov rdx, rcx
0009e114  488b4910                 mov rcx, qword ptr [rcx + 0x10]
0009e118  e89332f7ff               call 0x113b0
0009e11d  488933                   mov qword ptr [rbx], rsi
0009e120  488b4b08                 mov rcx, qword ptr [rbx + 8]
0009e124  4885c9                   test rcx, rcx
0009e127  7420                     je 0x9e149
0009e129  f00fc17918               lock xadd dword ptr [rcx + 0x18], edi
0009e12e  83ff01                   cmp edi, 1
0009e131  7512                     jne 0x9e145
0009e133  48397108                 cmp qword ptr [rcx + 8], rsi
0009e137  740c                     je 0x9e145
0009e139  488bd1                   mov rdx, rcx
0009e13c  488b4910                 mov rcx, qword ptr [rcx + 0x10]
0009e140  e86b32f7ff               call 0x113b0
0009e145  48897308                 mov qword ptr [rbx + 8], rsi
0009e149  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0009e14d  4885c9                   test rcx, rcx
0009e150  740f                     je 0x9e161
0009e152  8b5320                   mov edx, dword ptr [rbx + 0x20]
0009e155  e8a67af6ff               call 0x5c00
0009e15a  48897318                 mov qword ptr [rbx + 0x18], rsi
0009e15e  897320                   mov dword ptr [rbx + 0x20], esi
0009e161  48897310                 mov qword ptr [rbx + 0x10], rsi
0009e165  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0009e16a  488b742450               mov rsi, qword ptr [rsp + 0x50]
0009e16f  4883c430                 add rsp, 0x30
0009e173  5f                       pop rdi
0009e174  c3                       ret
