; CMemThread<CMemFixed>::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e360, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13e360 (55 bytes)
0013e360  48895c2408               mov qword ptr [rsp + 8], rbx
0013e365  57                       push rdi
0013e366  4883ec20                 sub rsp, 0x20
0013e36a  8bda                     mov ebx, edx
0013e36c  488bf9                   mov rdi, rcx
0013e36f  e8cce2fbff               call 0xfc640
0013e374  83e305                   and ebx, 5
0013e377  80fb05                   cmp bl, 5
0013e37a  750d                     jne 0x13e389
0013e37c  bae0010000               mov edx, 0x1e0
0013e381  488bcf                   mov rcx, rdi
0013e384  e8872cecff               call 0x1010
0013e389  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013e38e  488bc7                   mov rax, rdi
0013e391  4883c420                 add rsp, 0x20
0013e395  5f                       pop rdi
0013e396  c3                       ret
