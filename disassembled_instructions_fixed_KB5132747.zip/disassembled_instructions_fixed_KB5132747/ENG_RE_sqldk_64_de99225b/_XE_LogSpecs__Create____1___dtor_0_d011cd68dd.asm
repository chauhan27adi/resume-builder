; `XE_LogSpecs::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x215fe0, 34 bytes in 1 chunk(s)

; chunk at RVA 0x215fe0 (34 bytes)
00215fe0  4055                     push rbp
00215fe2  4883ec20                 sub rsp, 0x20
00215fe6  488bea                   mov rbp, rdx
00215fe9  4533c0                   xor r8d, r8d
00215fec  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
00215ff3  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00215ff7  e814b0deff               call 0x1010
00215ffc  4883c420                 add rsp, 0x20
00216000  5d                       pop rbp
00216001  c3                       ret
