; `GlobalCacheActivenessStats::Init'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22d0e0, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22d0e0 (59 bytes)
0022d0e0  4055                     push rbp
0022d0e2  4883ec30                 sub rsp, 0x30
0022d0e6  488bea                   mov rbp, rdx
0022d0e9  c644242806               mov byte ptr [rsp + 0x28], 6
0022d0ee  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0022d0f4  89442420                 mov dword ptr [rsp + 0x20], eax
0022d0f8  4c8d0d99d20400           lea r9, [rip + 0x4d299]
0022d0ff  41b801000000             mov r8d, 1
0022d105  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
0022d10c  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022d110  e8fb9dddff               call 0x6f10
0022d115  4883c430                 add rsp, 0x30
0022d119  5d                       pop rbp
0022d11a  c3                       ret
