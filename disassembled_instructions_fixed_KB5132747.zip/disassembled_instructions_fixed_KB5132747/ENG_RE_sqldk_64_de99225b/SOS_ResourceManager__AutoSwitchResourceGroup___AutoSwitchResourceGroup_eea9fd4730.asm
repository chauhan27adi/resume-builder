; SOS_ResourceManager::AutoSwitchResourceGroup::~AutoSwitchResourceGroup
; sqldk.dll, primary RVA 0x27e40, 61 bytes in 1 chunk(s)

; chunk at RVA 0x27e40 (61 bytes)
00027e40  4053                     push rbx
00027e42  4883ec20                 sub rsp, 0x20
00027e46  488b01                   mov rax, qword ptr [rcx]
00027e49  488bd9                   mov rbx, rcx
00027e4c  4885c0                   test rax, rax
00027e4f  7426                     je 0x27e77
00027e51  488b5108                 mov rdx, qword ptr [rcx + 8]
00027e55  483bd0                   cmp rdx, rax
00027e58  741d                     je 0x27e77
00027e5a  488d0d3fda2e00           lea rcx, [rip + 0x2eda3f]
00027e61  e8ca630000               call 0x2e230
00027e66  488b5b08                 mov rbx, qword ptr [rbx + 8]
00027e6a  83bba400000003           cmp dword ptr [rbx + 0xa4], 3
00027e71  0f8369010600             jae 0x87fe0
00027e77  4883c420                 add rsp, 0x20
00027e7b  5b                       pop rbx
00027e7c  c3                       ret
