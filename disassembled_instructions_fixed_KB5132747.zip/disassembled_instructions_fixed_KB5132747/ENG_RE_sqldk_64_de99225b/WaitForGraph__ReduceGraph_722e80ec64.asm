; WaitForGraph::ReduceGraph
; sqldk.dll, primary RVA 0x13e50, 194 bytes in 1 chunk(s)

; chunk at RVA 0x13e50 (194 bytes)
00013e50  48895c2408               mov qword ptr [rsp + 8], rbx
00013e55  48896c2410               mov qword ptr [rsp + 0x10], rbp
00013e5a  4889742418               mov qword ptr [rsp + 0x18], rsi
00013e5f  57                       push rdi
00013e60  4156                     push r14
00013e62  4157                     push r15
00013e64  4883ec20                 sub rsp, 0x20
00013e68  83791c00                 cmp dword ptr [rcx + 0x1c], 0
00013e6c  488bea                   mov rbp, rdx
00013e6f  488bd9                   mov rbx, rcx
00013e72  0f8495000000             je 0x13f0d
00013e78  4885d2                   test rdx, rdx
00013e7b  0f8583000000             jne 0x13f04
00013e81  41bf01000000             mov r15d, 1
00013e87  660f1f840000000000       nop word ptr [rax + rax]
00013e90  4532f6                   xor r14b, r14b
00013e93  33f6                     xor esi, esi
00013e95  39731c                   cmp dword ptr [rbx + 0x1c], esi
00013e98  7624                     jbe 0x13ebe
00013e9a  90                       nop
00013e9b  0f1f440000               nop dword ptr [rax + rax]
00013ea0  488b4328                 mov rax, qword ptr [rbx + 0x28]
00013ea4  488b3cf0                 mov rdi, qword ptr [rax + rsi*8]
00013ea8  4885ff                   test rdi, rdi
00013eab  740a                     je 0x13eb7
00013ead  44397f30                 cmp dword ptr [rdi + 0x30], r15d
00013eb1  0f848f5e0200             je 0x39d46
00013eb7  ffc6                     inc esi
00013eb9  3b731c                   cmp esi, dword ptr [rbx + 0x1c]
00013ebc  72e2                     jb 0x13ea0
00013ebe  488b03                   mov rax, qword ptr [rbx]
00013ec1  488bcb                   mov rcx, rbx
00013ec4  ff5040                   call qword ptr [rax + 0x40]
00013ec7  84c0                     test al, al
00013ec9  0f85bc501900             jne 0x1a8f8b
00013ecf  4584f6                   test r14b, r14b
00013ed2  75bc                     jne 0x13e90
00013ed4  4885ed                   test rbp, rbp
00013ed7  0f85a4501900             jne 0x1a8f81
00013edd  396b48                   cmp dword ptr [rbx + 0x48], ebp
00013ee0  eb01                     jmp 0x13ee3
00013ee2  cc                       int3
00013ee3  7628                     jbe 0x13f0d
00013ee5  418bc7                   mov eax, r15d
00013ee8  eb01                     jmp 0x13eeb
00013eea  cc                       int3
00013eeb  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00013ef0  488b6c2448               mov rbp, qword ptr [rsp + 0x48]
00013ef5  488b742450               mov rsi, qword ptr [rsp + 0x50]
00013efa  4883c420                 add rsp, 0x20
00013efe  415f                     pop r15
00013f00  415e                     pop r14
00013f02  5f                       pop rdi
00013f03  c3                       ret
00013f04  833a00                   cmp dword ptr [rdx], 0
00013f07  0f8574ffffff             jne 0x13e81
00013f0d  33c0                     xor eax, eax
00013f0f  ebda                     jmp 0x13eeb
00013f11  cc                       int3
