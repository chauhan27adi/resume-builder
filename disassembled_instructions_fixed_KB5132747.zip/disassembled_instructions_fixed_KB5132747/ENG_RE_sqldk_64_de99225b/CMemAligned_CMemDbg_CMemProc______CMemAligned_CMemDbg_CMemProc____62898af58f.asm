; CMemAligned<CMemDbg<CMemProc> >::~CMemAligned<CMemDbg<CMemProc> >
; sqldk.dll, primary RVA 0xc14d0, 37 bytes in 1 chunk(s)

; chunk at RVA 0xc14d0 (37 bytes)
000c14d0  48894c2408               mov qword ptr [rsp + 8], rcx
000c14d5  4883ec38                 sub rsp, 0x38
000c14d9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000c14e2  488d05f7df1800           lea rax, [rip + 0x18dff7]
000c14e9  488901                   mov qword ptr [rcx], rax
000c14ec  4883c438                 add rsp, 0x38
000c14f0  e9dbe50a00               jmp 0x16fad0
