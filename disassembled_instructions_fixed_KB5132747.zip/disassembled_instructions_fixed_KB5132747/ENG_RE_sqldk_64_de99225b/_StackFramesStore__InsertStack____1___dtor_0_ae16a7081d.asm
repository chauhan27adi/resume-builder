; `StackFramesStore::InsertStack'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22db70, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22db70 (59 bytes)
0022db70  4055                     push rbp
0022db72  4883ec30                 sub rsp, 0x30
0022db76  488bea                   mov rbp, rdx
0022db79  c644242806               mov byte ptr [rsp + 0x28], 6
0022db7e  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022db84  89442420                 mov dword ptr [rsp + 0x20], eax
0022db88  4c8d0dc1cc0600           lea r9, [rip + 0x6ccc1]
0022db8f  41b801000000             mov r8d, 1
0022db95  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
0022db9c  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
0022dba0  e86b93ddff               call 0x6f10
0022dba5  4883c430                 add rsp, 0x30
0022dba9  5d                       pop rbp
0022dbaa  c3                       ret
