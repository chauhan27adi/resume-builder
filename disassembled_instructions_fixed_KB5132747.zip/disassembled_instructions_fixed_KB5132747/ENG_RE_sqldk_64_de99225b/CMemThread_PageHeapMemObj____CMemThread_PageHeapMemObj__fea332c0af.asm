; CMemThread<PageHeapMemObj>::~CMemThread<PageHeapMemObj>
; sqldk.dll, primary RVA 0xe5b10, 111 bytes in 1 chunk(s)

; chunk at RVA 0xe5b10 (111 bytes)
000e5b10  48894c2408               mov qword ptr [rsp + 8], rcx
000e5b15  53                       push rbx
000e5b16  4883ec30                 sub rsp, 0x30
000e5b1a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000e5b23  488bd9                   mov rbx, rcx
000e5b26  488d0533491600           lea rax, [rip + 0x164933]
000e5b2d  488901                   mov qword ptr [rcx], rax
000e5b30  488d8180000000           lea rax, [rcx + 0x80]
000e5b37  4889442448               mov qword ptr [rsp + 0x48], rax
000e5b3c  488d0dfd3f1500           lea rcx, [rip + 0x153ffd]
000e5b43  48894830                 mov qword ptr [rax + 0x30], rcx
000e5b47  488908                   mov qword ptr [rax], rcx
000e5b4a  488d05cf8a1600           lea rax, [rip + 0x168acf]
000e5b51  488903                   mov qword ptr [rbx], rax
000e5b54  488d05ad161600           lea rax, [rip + 0x1616ad]
000e5b5b  488903                   mov qword ptr [rbx], rax
000e5b5e  488d4b38                 lea rcx, [rbx + 0x38]
000e5b62  e889baf2ff               call 0x115f0
000e5b67  90                       nop
000e5b68  488d4b30                 lea rcx, [rbx + 0x30]
000e5b6c  e87fbaf2ff               call 0x115f0
000e5b71  90                       nop
000e5b72  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
000e5b79  4883c430                 add rsp, 0x30
000e5b7d  5b                       pop rbx
000e5b7e  c3                       ret
