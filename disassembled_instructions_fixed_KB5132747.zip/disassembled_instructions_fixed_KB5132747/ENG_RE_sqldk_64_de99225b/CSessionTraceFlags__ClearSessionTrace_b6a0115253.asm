; CSessionTraceFlags::ClearSessionTrace
; sqldk.dll, primary RVA 0x1b4a50, 206 bytes in 1 chunk(s)

; chunk at RVA 0x1b4a50 (206 bytes)
001b4a50  4053                     push rbx
001b4a52  4883ec20                 sub rsp, 0x20
001b4a56  8bd9                     mov ebx, ecx
001b4a58  81f9d8440000             cmp ecx, 0x44d8
001b4a5e  0f83b2000000             jae 0x1b4b16
001b4a64  85d2                     test edx, edx
001b4a66  7414                     je 0x1b4a7c
001b4a68  e803070000               call 0x1b5170
001b4a6d  4885c0                   test rax, rax
001b4a70  740a                     je 0x1b4a7c
001b4a72  83780c00                 cmp dword ptr [rax + 0xc], 0
001b4a76  0f849a000000             je 0x1b4b16
001b4a7c  488b0d85d51700           mov rcx, qword ptr [rip + 0x17d585]
001b4a83  488b01                   mov rax, qword ptr [rcx]
001b4a86  ff5020                   call qword ptr [rax + 0x20]
001b4a89  4c8bc8                   mov r9, rax
001b4a8c  4885c0                   test rax, rax
001b4a8f  747d                     je 0x1b4b0e
001b4a91  8bcb                     mov ecx, ebx
001b4a93  b8cdcccccc               mov eax, 0xcccccccd
001b4a98  f7e3                     mul ebx
001b4a9a  c1ea03                   shr edx, 3
001b4a9d  448d0492                 lea r8d, [rdx + rdx*4]
001b4aa1  4503c0                   add r8d, r8d
001b4aa4  412bc8                   sub ecx, r8d
001b4aa7  4533d2                   xor r10d, r10d
001b4aaa  4c8d048d00000000         lea r8, [rcx*4]
001b4ab2  43395c0104               cmp dword ptr [r9 + r8 + 4], ebx
001b4ab7  7438                     je 0x1b4af1
001b4ab9  418bd2                   mov edx, r10d
001b4abc  498d4104                 lea rax, [r9 + 4]
001b4ac0  498bca                   mov rcx, r10
001b4ac3  3918                     cmp dword ptr [rax], ebx
001b4ac5  7420                     je 0x1b4ae7
001b4ac7  ffc2                     inc edx
001b4ac9  48ffc1                   inc rcx
001b4acc  4883c004                 add rax, 4
001b4ad0  4883f90a                 cmp rcx, 0xa
001b4ad4  7ced                     jl 0x1b4ac3
001b4ad6  4d8b4930                 mov r9, qword ptr [r9 + 0x30]
001b4ada  4d85c9                   test r9, r9
001b4add  75d3                     jne 0x1b4ab2
001b4adf  b001                     mov al, 1
001b4ae1  4883c420                 add rsp, 0x20
001b4ae5  5b                       pop rbx
001b4ae6  c3                       ret
001b4ae7  4863c2                   movsxd rax, edx
001b4aea  4589548104               mov dword ptr [r9 + rax*4 + 4], r10d
001b4aef  eb05                     jmp 0x1b4af6
001b4af1  4789540104               mov dword ptr [r9 + r8 + 4], r10d
001b4af6  488b0d0bd51700           mov rcx, qword ptr [rip + 0x17d50b]
001b4afd  41b901000000             mov r9d, 1
001b4b03  458bc1                   mov r8d, r9d
001b4b06  8bd3                     mov edx, ebx
001b4b08  488b01                   mov rax, qword ptr [rcx]
001b4b0b  ff5010                   call qword ptr [rax + 0x10]
001b4b0e  b001                     mov al, 1
001b4b10  4883c420                 add rsp, 0x20
001b4b14  5b                       pop rbx
001b4b15  c3                       ret
001b4b16  32c0                     xor al, al
001b4b18  4883c420                 add rsp, 0x20
001b4b1c  5b                       pop rbx
001b4b1d  c3                       ret
