; CMemThread<CMemAligned<CMemObj> >::~CMemThread<CMemAligned<CMemObj> >
; sqldk.dll, primary RVA 0x12e470, 121 bytes in 1 chunk(s)

; chunk at RVA 0x12e470 (121 bytes)
0012e470  48894c2408               mov qword ptr [rsp + 8], rcx
0012e475  53                       push rbx
0012e476  4883ec30                 sub rsp, 0x30
0012e47a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0012e483  488bd9                   mov rbx, rcx
0012e486  488d05339a1100           lea rax, [rip + 0x119a33]
0012e48d  488901                   mov qword ptr [rcx], rax
0012e490  488d8130010000           lea rax, [rcx + 0x130]
0012e497  4889442448               mov qword ptr [rsp + 0x48], rax
0012e49c  488d0d9db61000           lea rcx, [rip + 0x10b69d]
0012e4a3  48894830                 mov qword ptr [rax + 0x30], rcx
0012e4a7  488908                   mov qword ptr [rax], rcx
0012e4aa  488d05d7d31100           lea rax, [rip + 0x11d3d7]
0012e4b1  488903                   mov qword ptr [rbx], rax
0012e4b4  488d05ad8a1100           lea rax, [rip + 0x118aad]
0012e4bb  488903                   mov qword ptr [rbx], rax
0012e4be  488d05438d1100           lea rax, [rip + 0x118d43]
0012e4c5  488903                   mov qword ptr [rbx], rax
0012e4c8  488d4b38                 lea rcx, [rbx + 0x38]
0012e4cc  e81f31eeff               call 0x115f0
0012e4d1  90                       nop
0012e4d2  488d4b30                 lea rcx, [rbx + 0x30]
0012e4d6  e81531eeff               call 0x115f0
0012e4db  90                       nop
0012e4dc  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0012e4e3  4883c430                 add rsp, 0x30
0012e4e7  5b                       pop rbx
0012e4e8  c3                       ret
