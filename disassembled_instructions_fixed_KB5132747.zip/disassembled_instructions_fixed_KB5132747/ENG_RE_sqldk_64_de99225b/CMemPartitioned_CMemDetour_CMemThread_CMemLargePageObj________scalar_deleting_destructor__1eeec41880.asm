; CMemPartitioned<CMemDetour<CMemThread<CMemLargePageObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcec00, 129 bytes in 1 chunk(s)

; chunk at RVA 0xcec00 (129 bytes)
000cec00  48894c2408               mov qword ptr [rsp + 8], rcx
000cec05  57                       push rdi
000cec06  4883ec30                 sub rsp, 0x30
000cec0a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cec13  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cec18  8bda                     mov ebx, edx
000cec1a  488bf9                   mov rdi, rcx
000cec1d  488d0524d71700           lea rax, [rip + 0x17d724]
000cec24  488901                   mov qword ptr [rcx], rax
000cec27  488d81a8030000           lea rax, [rcx + 0x3a8]
000cec2e  4889442450               mov qword ptr [rsp + 0x50], rax
000cec33  488d0d06af1600           lea rcx, [rip + 0x16af06]
000cec3a  488908                   mov qword ptr [rax], rcx
000cec3d  488d0564e01700           lea rax, [rip + 0x17e064]
000cec44  488907                   mov qword ptr [rdi], rax
000cec47  488d87e0020000           lea rax, [rdi + 0x2e0]
000cec4e  4889442458               mov qword ptr [rsp + 0x58], rax
000cec53  488908                   mov qword ptr [rax], rcx
000cec56  488bcf                   mov rcx, rdi
000cec59  e8c24a0400               call 0x113720
000cec5e  83e305                   and ebx, 5
000cec61  80fb05                   cmp bl, 5
000cec64  750d                     jne 0xcec73
000cec66  bae0030000               mov edx, 0x3e0
000cec6b  488bcf                   mov rcx, rdi
000cec6e  e89d23f3ff               call 0x1010
000cec73  488bc7                   mov rax, rdi
000cec76  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cec7b  4883c430                 add rsp, 0x30
000cec7f  5f                       pop rdi
000cec80  c3                       ret
