; SOS_IOCompRequest::Protect
; sqldk.dll, primary RVA 0x1c450, 305 bytes in 5 chunk(s)

; chunk at RVA 0x1c450 (21 bytes)
0001c450  4883ec38                 sub rsp, 0x38
0001c454  4c8d5120                 lea r10, [rcx + 0x20]
0001c458  49f7c2ff0f0000           test r10, 0xfff
0001c45f  0f84cca80100             je 0x36d31

; chunk at RVA 0x1c465 (5 bytes)
0001c465  4883c438                 add rsp, 0x38
0001c469  c3                       ret

; chunk at RVA 0x36d52 (9 bytes)
00036d52  48895c2448               mov qword ptr [rsp + 0x48], rbx
00036d57  4c8d4124                 lea r8, [rcx + 0x24]

; chunk at RVA 0x36d5b (134 bytes)
00036d5b  48897c2430               mov qword ptr [rsp + 0x30], rdi
00036d60  488d1d993f2400           lea rbx, [rip + 0x243f99]
00036d67  bfffffffff               mov edi, 0xffffffff
00036d6c  41bb00010000             mov r11d, 0x100
00036d72  8bd7                     mov edx, edi
00036d74  0f1f4000                 nop dword ptr [rax]
00036d78  0f1f840000000000         nop dword ptr [rax + rax]
00036d80  410fb608                 movzx ecx, byte ptr [r8]
00036d84  4d8d4004                 lea r8, [r8 + 4]
00036d88  8bc2                     mov eax, edx
00036d8a  c1ea08                   shr edx, 8
00036d8d  4833c8                   xor rcx, rax
00036d90  0fb6c1                   movzx eax, cl
00036d93  410fb648fd               movzx ecx, byte ptr [r8 - 3]
00036d98  331483                   xor edx, dword ptr [rbx + rax*4]
00036d9b  8bc2                     mov eax, edx
00036d9d  c1ea08                   shr edx, 8
00036da0  4833c8                   xor rcx, rax
00036da3  0fb6c1                   movzx eax, cl
00036da6  410fb648fe               movzx ecx, byte ptr [r8 - 2]
00036dab  331483                   xor edx, dword ptr [rbx + rax*4]
00036dae  8bc2                     mov eax, edx
00036db0  c1ea08                   shr edx, 8
00036db3  4833c8                   xor rcx, rax
00036db6  0fb6c1                   movzx eax, cl
00036db9  410fb648ff               movzx ecx, byte ptr [r8 - 1]
00036dbe  331483                   xor edx, dword ptr [rbx + rax*4]
00036dc1  8bc2                     mov eax, edx
00036dc3  c1ea08                   shr edx, 8
00036dc6  4833c8                   xor rcx, rax
00036dc9  0fb6c1                   movzx eax, cl
00036dcc  331483                   xor edx, dword ptr [rbx + rax*4]
00036dcf  4983eb04                 sub r11, 4
00036dd3  75ab                     jne 0x36d80
00036dd5  85d2                     test edx, edx
00036dd7  0f44d7                   cmove edx, edi
00036dda  488b7c2430               mov rdi, qword ptr [rsp + 0x30]
00036ddf  33db                     xor ebx, ebx

; chunk at RVA 0x36df0 (136 bytes)
00036df0  458bc1                   mov r8d, r9d
00036df3  418bc1                   mov eax, r9d
00036df6  f0410fb112               lock cmpxchg dword ptr [r10], edx
00036dfb  448bc8                   mov r9d, eax
00036dfe  8bd3                     mov edx, ebx
00036e00  413bc0                   cmp eax, r8d
00036e03  75eb                     jne 0x36df0
00036e05  4c8d4c2440               lea r9, [rsp + 0x40]
00036e0a  ba00100000               mov edx, 0x1000
00036e0f  41b802000000             mov r8d, 2
00036e15  498bca                   mov rcx, r10
00036e18  ff153a232000             call qword ptr [rip + 0x20233a]
00036e1e  85c0                     test eax, eax
00036e20  7521                     jne 0x36e43
00036e22  41b9d7080000             mov r9d, 0x8d7
00036e28  48895c2420               mov qword ptr [rsp + 0x20], rbx
00036e2d  4c8d05ac502700           lea r8, [rip + 0x2750ac]
00036e34  488d159d502700           lea rdx, [rip + 0x27509d]
00036e3b  8d4801                   lea ecx, [rax + 1]
00036e3e  e8adaf1700               call 0x1b1df0
00036e43  837c244004               cmp dword ptr [rsp + 0x40], 4
00036e48  7423                     je 0x36e6d
00036e4a  41b9dc080000             mov r9d, 0x8dc
00036e50  48895c2420               mov qword ptr [rsp + 0x20], rbx
00036e55  4c8d0584502700           lea r8, [rip + 0x275084]
00036e5c  b901000000               mov ecx, 1
00036e61  488d1598502700           lea rdx, [rip + 0x275098]
00036e68  e883af1700               call 0x1b1df0
00036e6d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00036e72  e9ee55feff               jmp 0x1c465
00036e77  cc                       int3
