; `ISOSHostImpl::CreateManualEvent'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22a45c, 62 bytes in 1 chunk(s)

; chunk at RVA 0x22a45c (62 bytes)
0022a45c  4055                     push rbp
0022a45e  4883ec30                 sub rsp, 0x30
0022a462  488bea                   mov rbp, rdx
0022a465  c644242806               mov byte ptr [rsp + 0x28], 6
0022a46a  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022a470  89442420                 mov dword ptr [rsp + 0x20], eax
0022a474  4c8d0d65f70600           lea r9, [rip + 0x6f765]
0022a47b  41b801000000             mov r8d, 1
0022a481  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0022a488  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
0022a48f  e87ccaddff               call 0x6f10
0022a494  4883c430                 add rsp, 0x30
0022a498  5d                       pop rbp
0022a499  c3                       ret
