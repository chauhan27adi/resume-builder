; `XEPackage0::RingTarget::PackageEntry::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x231ea0, 38 bytes in 1 chunk(s)

; chunk at RVA 0x231ea0 (38 bytes)
00231ea0  4055                     push rbp
00231ea2  4883ec20                 sub rsp, 0x20
00231ea6  488bea                   mov rbp, rdx
00231ea9  4c8b4570                 mov r8, qword ptr [rbp + 0x70]
00231ead  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
00231eb4  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
00231ebb  e850f1dcff               call 0x1010
00231ec0  4883c420                 add rsp, 0x20
00231ec4  5d                       pop rbp
00231ec5  c3                       ret
