; CSessionTraceFlags::SetSessionTrace
; sqldk.dll, primary RVA 0x1b4940, 266 bytes in 1 chunk(s)

; chunk at RVA 0x1b4940 (266 bytes)
001b4940  4053                     push rbx
001b4942  4883ec20                 sub rsp, 0x20
001b4946  8bd9                     mov ebx, ecx
001b4948  81f9d8440000             cmp ecx, 0x44d8
001b494e  0f83ee000000             jae 0x1b4a42
001b4954  85d2                     test edx, edx
001b4956  7414                     je 0x1b496c
001b4958  e813080000               call 0x1b5170
001b495d  4885c0                   test rax, rax
001b4960  740a                     je 0x1b496c
001b4962  83780c00                 cmp dword ptr [rax + 0xc], 0
001b4966  0f84d6000000             je 0x1b4a42
001b496c  488b0d95d61700           mov rcx, qword ptr [rip + 0x17d695]
001b4973  488b01                   mov rax, qword ptr [rcx]
001b4976  ff5020                   call qword ptr [rax + 0x20]
001b4979  33d2                     xor edx, edx
001b497b  4c8bc8                   mov r9, rax
001b497e  4885c0                   test rax, rax
001b4981  745d                     je 0x1b49e0
001b4983  8bcb                     mov ecx, ebx
001b4985  b8cdcccccc               mov eax, 0xcccccccd
001b498a  f7e3                     mul ebx
001b498c  c1ea03                   shr edx, 3
001b498f  448d0492                 lea r8d, [rdx + rdx*4]
001b4993  4503c0                   add r8d, r8d
001b4996  412bc8                   sub ecx, r8d
001b4999  4c8d048d00000000         lea r8, [rcx*4]
001b49a1  438b440104               mov eax, dword ptr [r9 + r8 + 4]
001b49a6  85c0                     test eax, eax
001b49a8  7473                     je 0x1b4a1d
001b49aa  3bc3                     cmp eax, ebx
001b49ac  0f8488000000             je 0x1b4a3a
001b49b2  33d2                     xor edx, edx
001b49b4  498d4104                 lea rax, [r9 + 4]
001b49b8  33c9                     xor ecx, ecx
001b49ba  660f1f440000             nop word ptr [rax + rax]
001b49c0  833800                   cmp dword ptr [rax], 0
001b49c3  744e                     je 0x1b4a13
001b49c5  ffc2                     inc edx
001b49c7  48ffc1                   inc rcx
001b49ca  4883c004                 add rax, 4
001b49ce  4883f90a                 cmp rcx, 0xa
001b49d2  7cec                     jl 0x1b49c0
001b49d4  498bd1                   mov rdx, r9
001b49d7  4d8b4930                 mov r9, qword ptr [r9 + 0x30]
001b49db  4d85c9                   test r9, r9
001b49de  75c1                     jne 0x1b49a1
001b49e0  488b0d21d61700           mov rcx, qword ptr [rip + 0x17d621]
001b49e7  4c8b01                   mov r8, qword ptr [rcx]
001b49ea  41ff5018                 call qword ptr [r8 + 0x18]
001b49ee  4c8bc8                   mov r9, rax
001b49f1  4885c0                   test rax, rax
001b49f4  744c                     je 0x1b4a42
001b49f6  8bcb                     mov ecx, ebx
001b49f8  b8cdcccccc               mov eax, 0xcccccccd
001b49fd  f7e3                     mul ebx
001b49ff  c1ea03                   shr edx, 3
001b4a02  448d0492                 lea r8d, [rdx + rdx*4]
001b4a06  4503c0                   add r8d, r8d
001b4a09  412bc8                   sub ecx, r8d
001b4a0c  41895c8904               mov dword ptr [r9 + rcx*4 + 4], ebx
001b4a11  eb0f                     jmp 0x1b4a22
001b4a13  4863c2                   movsxd rax, edx
001b4a16  41895c8104               mov dword ptr [r9 + rax*4 + 4], ebx
001b4a1b  eb05                     jmp 0x1b4a22
001b4a1d  43895c0104               mov dword ptr [r9 + r8 + 4], ebx
001b4a22  488b0ddfd51700           mov rcx, qword ptr [rip + 0x17d5df]
001b4a29  41b901000000             mov r9d, 1
001b4a2f  4533c0                   xor r8d, r8d
001b4a32  8bd3                     mov edx, ebx
001b4a34  488b01                   mov rax, qword ptr [rcx]
001b4a37  ff5010                   call qword ptr [rax + 0x10]
001b4a3a  b001                     mov al, 1
001b4a3c  4883c420                 add rsp, 0x20
001b4a40  5b                       pop rbx
001b4a41  c3                       ret
001b4a42  32c0                     xor al, al
001b4a44  4883c420                 add rsp, 0x20
001b4a48  5b                       pop rbx
001b4a49  c3                       ret
