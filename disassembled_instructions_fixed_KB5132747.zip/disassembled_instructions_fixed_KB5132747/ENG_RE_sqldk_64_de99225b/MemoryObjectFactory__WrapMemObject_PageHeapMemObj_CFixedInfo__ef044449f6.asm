; MemoryObjectFactory::WrapMemObject<PageHeapMemObj,CFixedInfo>
; sqldk.dll, primary RVA 0xc7860, 4052 bytes in 1 chunk(s)

; chunk at RVA 0xc7860 (4052 bytes)
000c7860  4c894c2420               mov qword ptr [rsp + 0x20], r9
000c7865  4c89442418               mov qword ptr [rsp + 0x18], r8
000c786a  55                       push rbp
000c786b  56                       push rsi
000c786c  57                       push rdi
000c786d  4154                     push r12
000c786f  4155                     push r13
000c7871  4156                     push r14
000c7873  4157                     push r15
000c7875  488bec                   mov rbp, rsp
000c7878  4883ec70                 sub rsp, 0x70
000c787c  48c745d0feffffff         mov qword ptr [rbp - 0x30], 0xfffffffffffffffe
000c7884  48899c24b0000000         mov qword ptr [rsp + 0xb0], rbx
000c788c  498bf8                   mov rdi, r8
000c788f  8bc2                     mov eax, edx
000c7891  488d156887f3ff           lea rdx, [rip - 0xc7898]
000c7898  4c8bacc200273100         mov r13, qword ptr [rdx + rax*8 + 0x312700]
000c78a0  448b7578                 mov r14d, dword ptr [rbp + 0x78]
000c78a4  418bf6                   mov esi, r14d
000c78a7  81e602002f01             and esi, 0x12f0002
000c78ad  4533e4                   xor r12d, r12d
000c78b0  418bdc                   mov ebx, r12d
000c78b3  83f92a                   cmp ecx, 0x2a
000c78b6  0f87af0e0000             ja 0xc876b
000c78bc  4863c1                   movsxd rax, ecx
000c78bf  8b8c8288870c00           mov ecx, dword ptr [rdx + rax*4 + 0xc8788]
000c78c6  4803ca                   add rcx, rdx
000c78c9  ffe1                     jmp rcx
000c78cb  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c78cf  488d8380000000           lea rax, [rbx + 0x80]
000c78d6  49894028                 mov qword ptr [r8 + 0x28], rax
000c78da  664183483001             or word ptr [r8 + 0x30], 1
000c78e0  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c78e4  4885db                   test rbx, rbx
000c78e7  744c                     je 0xc7935
000c78e9  c7430801000000           mov dword ptr [rbx + 8], 1
000c78f0  488d0511f91700           lea rax, [rip + 0x17f911]
000c78f7  488903                   mov qword ptr [rbx], rax
000c78fa  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7902  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7906  4c896320                 mov qword ptr [rbx + 0x20], r12
000c790a  44896328                 mov dword ptr [rbx + 0x28], r12d
000c790e  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7912  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7916  4c896340                 mov qword ptr [rbx + 0x40], r12
000c791a  4c896348                 mov qword ptr [rbx + 0x48], r12
000c791e  488d05fb6c1800           lea rax, [rip + 0x186cfb]
000c7925  488903                   mov qword ptr [rbx], rax
000c7928  488d4368                 lea rax, [rbx + 0x68]
000c792c  48894008                 mov qword ptr [rax + 8], rax
000c7930  488900                   mov qword ptr [rax], rax
000c7933  eb03                     jmp 0xc7938
000c7935  498bdc                   mov rbx, r12
000c7938  e9060e0000               jmp 0xc8743
000c793d  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c7941  488d8350040000           lea rax, [rbx + 0x450]
000c7948  49894028                 mov qword ptr [r8 + 0x28], rax
000c794c  664183483001             or word ptr [r8 + 0x30], 1
000c7952  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c7956  4885db                   test rbx, rbx
000c7959  7464                     je 0xc79bf
000c795b  c7430801000000           mov dword ptr [rbx + 8], 1
000c7962  488d059ff81700           lea rax, [rip + 0x17f89f]
000c7969  488903                   mov qword ptr [rbx], rax
000c796c  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7974  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7978  4c896320                 mov qword ptr [rbx + 0x20], r12
000c797c  44896328                 mov dword ptr [rbx + 0x28], r12d
000c7980  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7984  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7988  4c896340                 mov qword ptr [rbx + 0x40], r12
000c798c  4c896348                 mov qword ptr [rbx + 0x48], r12
000c7990  488d05896c1800           lea rax, [rip + 0x186c89]
000c7997  488903                   mov qword ptr [rbx], rax
000c799a  488d4368                 lea rax, [rbx + 0x68]
000c799e  48894008                 mov qword ptr [rax + 8], rax
000c79a2  488900                   mov qword ptr [rax], rax
000c79a5  488d05c4691800           lea rax, [rip + 0x1869c4]
000c79ac  488903                   mov qword ptr [rbx], rax
000c79af  488d0502e31900           lea rax, [rip + 0x19e302]
000c79b6  48898390000000           mov qword ptr [rbx + 0x90], rax
000c79bd  eb03                     jmp 0xc79c2
000c79bf  498bdc                   mov rbx, r12
000c79c2  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000c79cb  8b05ffd52400             mov eax, dword ptr [rip + 0x24d5ff]
000c79d1  8b3de19ef3ff             mov edi, dword ptr [rip - 0xc611f]
000c79d7  48033cc1                 add rdi, qword ptr [rcx + rax*8]
000c79db  488b8700010000           mov rax, qword ptr [rdi + 0x100]
000c79e2  4885c0                   test rax, rax
000c79e5  750e                     jne 0xc79f5
000c79e7  33c9                     xor ecx, ecx
000c79e9  e872e2f5ff               call 0x25c60
000c79ee  488b8700010000           mov rax, qword ptr [rdi + 0x100]
000c79f5  488b8058020000           mov rax, qword ptr [rax + 0x258]
000c79fc  48898380000000           mov qword ptr [rbx + 0x80], rax
000c7a03  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c7a0d  89b38c000000             mov dword ptr [rbx + 0x8c], esi
000c7a13  4489a338040000           mov dword ptr [rbx + 0x438], r12d
000c7a1a  418bc6                   mov eax, r14d
000c7a1d  c1e819                   shr eax, 0x19
000c7a20  83e001                   and eax, 1
000c7a23  89833c040000             mov dword ptr [rbx + 0x43c], eax
000c7a29  4489a340040000           mov dword ptr [rbx + 0x440], r12d
000c7a30  4c89a348040000           mov qword ptr [rbx + 0x448], r12
000c7a37  488d8b90000000           lea rcx, [rbx + 0x90]
000c7a3e  4c8bcb                   mov r9, rbx
000c7a41  448bc6                   mov r8d, esi
000c7a44  498bd5                   mov rdx, r13
000c7a47  e854090a00               call 0x1683a0
000c7a4c  e9f20c0000               jmp 0xc8743
000c7a51  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7a55  488d8100010000           lea rax, [rcx + 0x100]
000c7a5c  49894028                 mov qword ptr [r8 + 0x28], rax
000c7a60  664183483001             or word ptr [r8 + 0x30], 1
000c7a66  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7a6a  4885c9                   test rcx, rcx
000c7a6d  740a                     je 0xc7a79
000c7a6f  e83c5d0000               call 0xcd7b0
000c7a74  488bd8                   mov rbx, rax
000c7a77  eb03                     jmp 0xc7a7c
000c7a79  498bdc                   mov rbx, r12
000c7a7c  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000c7a83  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000c7a88  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000c7a8f  488bcb                   mov rcx, rbx
000c7a92  e8e9b70100               call 0xe3280
000c7a97  e9a70c0000               jmp 0xc8743
000c7a9c  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c7aa0  488d8390000000           lea rax, [rbx + 0x90]
000c7aa7  49894028                 mov qword ptr [r8 + 0x28], rax
000c7aab  664183483001             or word ptr [r8 + 0x30], 1
000c7ab1  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c7ab5  4885db                   test rbx, rbx
000c7ab8  745d                     je 0xc7b17
000c7aba  c7430801000000           mov dword ptr [rbx + 8], 1
000c7ac1  488d0540f71700           lea rax, [rip + 0x17f740]
000c7ac8  488903                   mov qword ptr [rbx], rax
000c7acb  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7ad3  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7ad7  4c896320                 mov qword ptr [rbx + 0x20], r12
000c7adb  44896328                 mov dword ptr [rbx + 0x28], r12d
000c7adf  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7ae3  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7ae7  4c896340                 mov qword ptr [rbx + 0x40], r12
000c7aeb  4c896348                 mov qword ptr [rbx + 0x48], r12
000c7aef  488d052a6b1800           lea rax, [rip + 0x186b2a]
000c7af6  488903                   mov qword ptr [rbx], rax
000c7af9  488d4368                 lea rax, [rbx + 0x68]
000c7afd  48894008                 mov qword ptr [rax + 8], rax
000c7b01  488900                   mov qword ptr [rax], rax
000c7b04  488d0515341800           lea rax, [rip + 0x183415]
000c7b0b  488903                   mov qword ptr [rbx], rax
000c7b0e  4c89a380000000           mov qword ptr [rbx + 0x80], r12
000c7b15  eb03                     jmp 0xc7b1a
000c7b17  498bdc                   mov rbx, r12
000c7b1a  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c7b21  0f1008                   movups xmm1, xmmword ptr [rax]
000c7b24  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c7b28  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c7b2c  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c7b30  66480f7eca               movq rdx, xmm1
000c7b35  48c1ea20                 shr rdx, 0x20
000c7b39  f6c201                   test dl, 1
000c7b3c  0f85010c0000             jne 0xc8743
000c7b42  81e22ffbffff             and edx, 0xfffffb2f
000c7b48  81ca20020000             or edx, 0x220
000c7b4e  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c7b52  48c1e820                 shr rax, 0x20
000c7b56  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c7b5a  498bc8                   mov rcx, r8
000c7b5d  48c1e920                 shr rcx, 0x20
000c7b61  49c1e810                 shr r8, 0x10
000c7b65  89442438                 mov dword ptr [rsp + 0x38], eax
000c7b69  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c7b6c  89442430                 mov dword ptr [rsp + 0x30], eax
000c7b70  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c7b74  664489442420             mov word ptr [rsp + 0x20], r8w
000c7b7a  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c7b7f  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c7b83  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c7b86  e8859df4ff               call 0x11910
000c7b8b  48898380000000           mov qword ptr [rbx + 0x80], rax
000c7b92  4885c0                   test rax, rax
000c7b95  0f95c0                   setne al
000c7b98  84c0                     test al, al
000c7b9a  0f85a30b0000             jne 0xc8743
000c7ba0  498bdc                   mov rbx, r12
000c7ba3  e9c30b0000               jmp 0xc876b
000c7ba8  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c7bac  488d8360040000           lea rax, [rbx + 0x460]
000c7bb3  49894028                 mov qword ptr [r8 + 0x28], rax
000c7bb7  664183483001             or word ptr [r8 + 0x30], 1
000c7bbd  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c7bc1  4885db                   test rbx, rbx
000c7bc4  7475                     je 0xc7c3b
000c7bc6  c7430801000000           mov dword ptr [rbx + 8], 1
000c7bcd  488d0534f61700           lea rax, [rip + 0x17f634]
000c7bd4  488903                   mov qword ptr [rbx], rax
000c7bd7  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7bdf  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7be3  4c896320                 mov qword ptr [rbx + 0x20], r12
000c7be7  44896328                 mov dword ptr [rbx + 0x28], r12d
000c7beb  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7bef  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7bf3  4c896340                 mov qword ptr [rbx + 0x40], r12
000c7bf7  4c896348                 mov qword ptr [rbx + 0x48], r12
000c7bfb  488d051e6a1800           lea rax, [rip + 0x186a1e]
000c7c02  488903                   mov qword ptr [rbx], rax
000c7c05  488d4368                 lea rax, [rbx + 0x68]
000c7c09  48894008                 mov qword ptr [rax + 8], rax
000c7c0d  488900                   mov qword ptr [rax], rax
000c7c10  488d0559671800           lea rax, [rip + 0x186759]
000c7c17  488903                   mov qword ptr [rbx], rax
000c7c1a  488d0597e01900           lea rax, [rip + 0x19e097]
000c7c21  48898390000000           mov qword ptr [rbx + 0x90], rax
000c7c28  488d05a1351800           lea rax, [rip + 0x1835a1]
000c7c2f  488903                   mov qword ptr [rbx], rax
000c7c32  4c89a350040000           mov qword ptr [rbx + 0x450], r12
000c7c39  eb03                     jmp 0xc7c3e
000c7c3b  498bdc                   mov rbx, r12
000c7c3e  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c7c45  0f1008                   movups xmm1, xmmword ptr [rax]
000c7c48  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c7c4c  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c7c50  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c7c54  66480f7eca               movq rdx, xmm1
000c7c59  48c1ea20                 shr rdx, 0x20
000c7c5d  f6c201                   test dl, 1
000c7c60  0f855cfdffff             jne 0xc79c2
000c7c66  81e22ffbffff             and edx, 0xfffffb2f
000c7c6c  81ca20020000             or edx, 0x220
000c7c72  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c7c76  48c1e820                 shr rax, 0x20
000c7c7a  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c7c7e  498bc8                   mov rcx, r8
000c7c81  48c1e920                 shr rcx, 0x20
000c7c85  49c1e810                 shr r8, 0x10
000c7c89  89442438                 mov dword ptr [rsp + 0x38], eax
000c7c8d  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c7c90  89442430                 mov dword ptr [rsp + 0x30], eax
000c7c94  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c7c98  664489442420             mov word ptr [rsp + 0x20], r8w
000c7c9e  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c7ca3  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c7ca7  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c7caa  e8619cf4ff               call 0x11910
000c7caf  48898350040000           mov qword ptr [rbx + 0x450], rax
000c7cb6  4885c0                   test rax, rax
000c7cb9  0f95c0                   setne al
000c7cbc  84c0                     test al, al
000c7cbe  0f85fefcffff             jne 0xc79c2
000c7cc4  498bdc                   mov rbx, r12
000c7cc7  e99f0a0000               jmp 0xc876b
000c7ccc  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7cd0  488d8160010000           lea rax, [rcx + 0x160]
000c7cd7  49894028                 mov qword ptr [r8 + 0x28], rax
000c7cdb  664183483001             or word ptr [r8 + 0x30], 1
000c7ce1  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7ce5  4885c9                   test rcx, rcx
000c7ce8  740a                     je 0xc7cf4
000c7cea  e811dd0100               call 0xe5a00
000c7cef  488bd8                   mov rbx, rax
000c7cf2  eb03                     jmp 0xc7cf7
000c7cf4  498bdc                   mov rbx, r12
000c7cf7  e9470a0000               jmp 0xc8743
000c7cfc  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7d00  488d81d0010000           lea rax, [rcx + 0x1d0]
000c7d07  49894028                 mov qword ptr [r8 + 0x28], rax
000c7d0b  664183483001             or word ptr [r8 + 0x30], 1
000c7d11  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7d15  4885c9                   test rcx, rcx
000c7d18  740a                     je 0xc7d24
000c7d1a  e8515b0000               call 0xcd870
000c7d1f  488bd8                   mov rbx, rax
000c7d22  eb03                     jmp 0xc7d27
000c7d24  498bdc                   mov rbx, r12
000c7d27  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000c7d2e  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000c7d33  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000c7d3a  488bcb                   mov rcx, rbx
000c7d3d  e83e550200               call 0xed280
000c7d42  e9fc090000               jmp 0xc8743
000c7d47  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7d4b  488d8160010000           lea rax, [rcx + 0x160]
000c7d52  49894028                 mov qword ptr [r8 + 0x28], rax
000c7d56  664183483001             or word ptr [r8 + 0x30], 1
000c7d5c  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7d60  4885c9                   test rcx, rcx
000c7d63  740a                     je 0xc7d6f
000c7d65  e8261f0200               call 0xe9c90
000c7d6a  488bd8                   mov rbx, rax
000c7d6d  eb03                     jmp 0xc7d72
000c7d6f  498bdc                   mov rbx, r12
000c7d72  e9a3fdffff               jmp 0xc7b1a
000c7d77  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c7d7b  488d83d0000000           lea rax, [rbx + 0xd0]
000c7d82  49894028                 mov qword ptr [r8 + 0x28], rax
000c7d86  664183483001             or word ptr [r8 + 0x30], 1
000c7d8c  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c7d90  4885db                   test rbx, rbx
000c7d93  0f8485000000             je 0xc7e1e
000c7d99  c7430801000000           mov dword ptr [rbx + 8], 1
000c7da0  488d0561f41700           lea rax, [rip + 0x17f461]
000c7da7  488903                   mov qword ptr [rbx], rax
000c7daa  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7db2  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7db6  4c896320                 mov qword ptr [rbx + 0x20], r12
000c7dba  44896328                 mov dword ptr [rbx + 0x28], r12d
000c7dbe  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7dc2  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7dc6  4c896340                 mov qword ptr [rbx + 0x40], r12
000c7dca  4c896348                 mov qword ptr [rbx + 0x48], r12
000c7dce  488d054b681800           lea rax, [rip + 0x18684b]
000c7dd5  488903                   mov qword ptr [rbx], rax
000c7dd8  488d4368                 lea rax, [rbx + 0x68]
000c7ddc  48894008                 mov qword ptr [rax + 8], rax
000c7de0  488900                   mov qword ptr [rax], rax
000c7de3  488d05be1f1800           lea rax, [rip + 0x181fbe]
000c7dea  488903                   mov qword ptr [rbx], rax
000c7ded  4c89a380000000           mov qword ptr [rbx + 0x80], r12
000c7df4  0f57c0                   xorps xmm0, xmm0
000c7df7  33c0                     xor eax, eax
000c7df9  0f118388000000           movups xmmword ptr [rbx + 0x88], xmm0
000c7e00  0f118398000000           movups xmmword ptr [rbx + 0x98], xmm0
000c7e07  0f1183a8000000           movups xmmword ptr [rbx + 0xa8], xmm0
000c7e0e  0f1183b8000000           movups xmmword ptr [rbx + 0xb8], xmm0
000c7e15  488983c8000000           mov qword ptr [rbx + 0xc8], rax
000c7e1c  eb03                     jmp 0xc7e21
000c7e1e  498bdc                   mov rbx, r12
000c7e21  e91d090000               jmp 0xc8743
000c7e26  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7e2a  488d81e0000000           lea rax, [rcx + 0xe0]
000c7e31  49894028                 mov qword ptr [r8 + 0x28], rax
000c7e35  664183483001             or word ptr [r8 + 0x30], 1
000c7e3b  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7e3f  4885c9                   test rcx, rcx
000c7e42  740a                     je 0xc7e4e
000c7e44  e8d7540200               call 0xed320
000c7e49  488bd8                   mov rbx, rax
000c7e4c  eb03                     jmp 0xc7e51
000c7e4e  498bdc                   mov rbx, r12
000c7e51  e9c4fcffff               jmp 0xc7b1a
000c7e56  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7e5a  488d8130050000           lea rax, [rcx + 0x530]
000c7e61  49894028                 mov qword ptr [r8 + 0x28], rax
000c7e65  664183483001             or word ptr [r8 + 0x30], 1
000c7e6b  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7e6f  4885c9                   test rcx, rcx
000c7e72  740a                     je 0xc7e7e
000c7e74  e857fc0100               call 0xe7ad0
000c7e79  488bd8                   mov rbx, rax
000c7e7c  eb03                     jmp 0xc7e81
000c7e7e  498bdc                   mov rbx, r12
000c7e81  4c89a380000000           mov qword ptr [rbx + 0x80], r12
000c7e88  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c7e92  89b38c000000             mov dword ptr [rbx + 0x8c], esi
000c7e98  4c89a338040000           mov qword ptr [rbx + 0x438], r12
000c7e9f  e985fbffff               jmp 0xc7a29
000c7ea4  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7ea8  488d8130050000           lea rax, [rcx + 0x530]
000c7eaf  49894028                 mov qword ptr [r8 + 0x28], rax
000c7eb3  664183483001             or word ptr [r8 + 0x30], 1
000c7eb9  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7ebd  4885c9                   test rcx, rcx
000c7ec0  740a                     je 0xc7ecc
000c7ec2  e8b9400200               call 0xebf80
000c7ec7  488bd8                   mov rbx, rax
000c7eca  eb03                     jmp 0xc7ecf
000c7ecc  498bdc                   mov rbx, r12
000c7ecf  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c7ed6  0f1008                   movups xmm1, xmmword ptr [rax]
000c7ed9  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c7edd  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c7ee1  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c7ee5  66480f7eca               movq rdx, xmm1
000c7eea  48c1ea20                 shr rdx, 0x20
000c7eee  f6c201                   test dl, 1
000c7ef1  758e                     jne 0xc7e81
000c7ef3  81e22ffbffff             and edx, 0xfffffb2f
000c7ef9  81ca20020000             or edx, 0x220
000c7eff  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c7f03  48c1e820                 shr rax, 0x20
000c7f07  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c7f0b  498bc8                   mov rcx, r8
000c7f0e  48c1e920                 shr rcx, 0x20
000c7f12  49c1e810                 shr r8, 0x10
000c7f16  89442438                 mov dword ptr [rsp + 0x38], eax
000c7f1a  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c7f1d  89442430                 mov dword ptr [rsp + 0x30], eax
000c7f21  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c7f25  664489442420             mov word ptr [rsp + 0x20], r8w
000c7f2b  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c7f30  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c7f34  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c7f37  e8d499f4ff               call 0x11910
000c7f3c  48898350040000           mov qword ptr [rbx + 0x450], rax
000c7f43  4885c0                   test rax, rax
000c7f46  0f95c0                   setne al
000c7f49  84c0                     test al, al
000c7f4b  0f8530ffffff             jne 0xc7e81
000c7f51  498bdc                   mov rbx, r12
000c7f54  e912080000               jmp 0xc876b
000c7f59  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7f5d  488d81a0040000           lea rax, [rcx + 0x4a0]
000c7f64  49894028                 mov qword ptr [r8 + 0x28], rax
000c7f68  664183483001             or word ptr [r8 + 0x30], 1
000c7f6e  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7f72  4885c9                   test rcx, rcx
000c7f75  740a                     je 0xc7f81
000c7f77  e864540200               call 0xed3e0
000c7f7c  488bd8                   mov rbx, rax
000c7f7f  eb03                     jmp 0xc7f84
000c7f81  498bdc                   mov rbx, r12
000c7f84  e939faffff               jmp 0xc79c2
000c7f89  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7f8d  488d81b0040000           lea rax, [rcx + 0x4b0]
000c7f94  49894028                 mov qword ptr [r8 + 0x28], rax
000c7f98  664183483001             or word ptr [r8 + 0x30], 1
000c7f9e  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7fa2  4885c9                   test rcx, rcx
000c7fa5  740a                     je 0xc7fb1
000c7fa7  e8f4540200               call 0xed4a0
000c7fac  488bd8                   mov rbx, rax
000c7faf  eb03                     jmp 0xc7fb4
000c7fb1  498bdc                   mov rbx, r12
000c7fb4  e985fcffff               jmp 0xc7c3e
000c7fb9  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7fbd  488d81b0010000           lea rax, [rcx + 0x1b0]
000c7fc4  49894028                 mov qword ptr [r8 + 0x28], rax
000c7fc8  664183483001             or word ptr [r8 + 0x30], 1
000c7fce  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7fd2  4885c9                   test rcx, rcx
000c7fd5  740a                     je 0xc7fe1
000c7fd7  e894550200               call 0xed570
000c7fdc  488bd8                   mov rbx, rax
000c7fdf  eb03                     jmp 0xc7fe4
000c7fe1  498bdc                   mov rbx, r12
000c7fe4  e95a070000               jmp 0xc8743
000c7fe9  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7fed  488d81b0010000           lea rax, [rcx + 0x1b0]
000c7ff4  49894028                 mov qword ptr [r8 + 0x28], rax
000c7ff8  664183483001             or word ptr [r8 + 0x30], 1
000c7ffe  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c8002  4885c9                   test rcx, rcx
000c8005  740a                     je 0xc8011
000c8007  e8d4550200               call 0xed5e0
000c800c  488bd8                   mov rbx, rax
000c800f  eb03                     jmp 0xc8014
000c8011  498bdc                   mov rbx, r12
000c8014  e901fbffff               jmp 0xc7b1a
000c8019  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c801d  488d8180050000           lea rax, [rcx + 0x580]
000c8024  49894028                 mov qword ptr [r8 + 0x28], rax
000c8028  664183483001             or word ptr [r8 + 0x30], 1
000c802e  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c8032  4885c9                   test rcx, rcx
000c8035  740a                     je 0xc8041
000c8037  e814560200               call 0xed650
000c803c  488bd8                   mov rbx, rax
000c803f  eb03                     jmp 0xc8044
000c8041  498bdc                   mov rbx, r12
000c8044  e938feffff               jmp 0xc7e81
000c8049  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c804d  488d8180050000           lea rax, [rcx + 0x580]
000c8054  49894028                 mov qword ptr [r8 + 0x28], rax
000c8058  664183483001             or word ptr [r8 + 0x30], 1
000c805e  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c8062  4885c9                   test rcx, rcx
000c8065  740a                     je 0xc8071
000c8067  e854560200               call 0xed6c0
000c806c  488bd8                   mov rbx, rax
000c806f  eb03                     jmp 0xc8074
000c8071  498bdc                   mov rbx, r12
000c8074  e956feffff               jmp 0xc7ecf
000c8079  4d8d7828                 lea r15, [r8 + 0x28]
000c807d  498b0f                   mov rcx, qword ptr [r15]
000c8080  488d8120020000           lea rax, [rcx + 0x220]
000c8087  498907                   mov qword ptr [r15], rax
000c808a  498d7030                 lea rsi, [r8 + 0x30]
000c808e  66830e01                 or word ptr [rsi], 1
000c8092  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c8096  4885c9                   test rcx, rcx
000c8099  740a                     je 0xc80a5
000c809b  e850580000               call 0xcd8f0
000c80a0  488bd8                   mov rbx, rax
000c80a3  eb03                     jmp 0xc80a8
000c80a5  498bdc                   mov rbx, r12
000c80a8  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000c80af  418b4504                 mov eax, dword ptr [r13 + 4]
000c80b3  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000c80ba  41be00020000             mov r14d, 0x200
000c80c0  a802                     test al, 2
000c80c2  743c                     je 0xc8100
000c80c4  a820                     test al, 0x20
000c80c6  7538                     jne 0xc8100
000c80c8  a810                     test al, 0x10
000c80ca  7534                     jne 0xc8100
000c80cc  a801                     test al, 1
000c80ce  7530                     jne 0xc8100
000c80d0  4185c6                   test r14d, eax
000c80d3  752b                     jne 0xc8100
000c80d5  a840                     test al, 0x40
000c80d7  7527                     jne 0xc8100
000c80d9  803d589d260000           cmp byte ptr [rip + 0x269d58], 0
000c80e0  741e                     je 0xc8100
000c80e2  8b0504ca2400             mov eax, dword ptr [rip + 0x24ca04]
000c80e8  83f801                   cmp eax, 1
000c80eb  7613                     jbe 0xc8100
000c80ed  c7837801000001000000     mov dword ptr [rbx + 0x178], 1
000c80f7  448b0deec92400           mov r9d, dword ptr [rip + 0x24c9ee]
000c80fe  eb15                     jmp 0xc8115
000c8100  c7837801000000000000     mov dword ptr [rbx + 0x178], 0
000c810a  418bcc                   mov ecx, r12d
000c810d  e8ce760700               call 0x13f7e0
000c8112  448bc8                   mov r9d, eax
000c8115  418bc1                   mov eax, r9d
000c8118  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c8120  4883e0f0                 and rax, 0xfffffffffffffff0
000c8124  48c7835801000000000000   mov qword ptr [rbx + 0x158], 0
000c812f  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c8136  740b                     je 0xc8143
000c8138  6644397704               cmp word ptr [rdi + 4], r14w
000c813d  7504                     jne 0xc8143
000c813f  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c8143  498b0f                   mov rcx, qword ptr [r15]
000c8146  488d1401                 lea rdx, [rcx + rax]
000c814a  488d8700200000           lea rax, [rdi + 0x2000]
000c8151  483bd0                   cmp rdx, rax
000c8154  730e                     jae 0xc8164
000c8156  498917                   mov qword ptr [r15], rdx
000c8159  66830e01                 or word ptr [rsi], 1
000c815d  48898b58010000           mov qword ptr [rbx + 0x158], rcx
000c8164  4c896c2420               mov qword ptr [rsp + 0x20], r13
000c8169  458bc4                   mov r8d, r12d
000c816c  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000c8173  488bcb                   mov rcx, rbx
000c8176  e8f5920700               call 0x141470
000c817b  85c0                     test eax, eax
000c817d  0f85b9050000             jne 0xc873c
000c8183  33db                     xor ebx, ebx
000c8185  e9e1050000               jmp 0xc876b
000c818a  4d8d7828                 lea r15, [r8 + 0x28]
000c818e  498b0f                   mov rcx, qword ptr [r15]
000c8191  488d8130020000           lea rax, [rcx + 0x230]
000c8198  498907                   mov qword ptr [r15], rax
000c819b  498d7030                 lea rsi, [r8 + 0x30]
000c819f  66830e01                 or word ptr [rsi], 1
000c81a3  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c81a7  4885c9                   test rcx, rcx
000c81aa  740a                     je 0xc81b6
000c81ac  e8bf570000               call 0xcd970
000c81b1  488bd8                   mov rbx, rax
000c81b4  eb03                     jmp 0xc81b9
000c81b6  498bdc                   mov rbx, r12
000c81b9  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000c81c0  418b4504                 mov eax, dword ptr [r13 + 4]
000c81c4  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000c81cb  41be00020000             mov r14d, 0x200
000c81d1  a802                     test al, 2
000c81d3  743c                     je 0xc8211
000c81d5  a820                     test al, 0x20
000c81d7  7538                     jne 0xc8211
000c81d9  a810                     test al, 0x10
000c81db  7534                     jne 0xc8211
000c81dd  a801                     test al, 1
000c81df  7530                     jne 0xc8211
000c81e1  4185c6                   test r14d, eax
000c81e4  752b                     jne 0xc8211
000c81e6  a840                     test al, 0x40
000c81e8  7527                     jne 0xc8211
000c81ea  803d479c260000           cmp byte ptr [rip + 0x269c47], 0
000c81f1  741e                     je 0xc8211
000c81f3  8b05f3c82400             mov eax, dword ptr [rip + 0x24c8f3]
000c81f9  83f801                   cmp eax, 1
000c81fc  7613                     jbe 0xc8211
000c81fe  c7838001000001000000     mov dword ptr [rbx + 0x180], 1
000c8208  448b0dddc82400           mov r9d, dword ptr [rip + 0x24c8dd]
000c820f  eb15                     jmp 0xc8226
000c8211  c7838001000000000000     mov dword ptr [rbx + 0x180], 0
000c821b  418bcc                   mov ecx, r12d
000c821e  e8bd750700               call 0x13f7e0
000c8223  448bc8                   mov r9d, eax
000c8226  418bc1                   mov eax, r9d
000c8229  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c8231  4883e0f0                 and rax, 0xfffffffffffffff0
000c8235  48c7836001000000000000   mov qword ptr [rbx + 0x160], 0
000c8240  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c8247  740b                     je 0xc8254
000c8249  6644397704               cmp word ptr [rdi + 4], r14w
000c824e  7504                     jne 0xc8254
000c8250  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c8254  498b0f                   mov rcx, qword ptr [r15]
000c8257  488d1401                 lea rdx, [rcx + rax]
000c825b  488d8700200000           lea rax, [rdi + 0x2000]
000c8262  483bd0                   cmp rdx, rax
000c8265  730e                     jae 0xc8275
000c8267  498917                   mov qword ptr [r15], rdx
000c826a  66830e01                 or word ptr [rsi], 1
000c826e  48898b60010000           mov qword ptr [rbx + 0x160], rcx
000c8275  4c896c2420               mov qword ptr [rsp + 0x20], r13
000c827a  458bc4                   mov r8d, r12d
000c827d  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000c8284  488bcb                   mov rcx, rbx
000c8287  e8449a0700               call 0x141cd0
000c828c  85c0                     test eax, eax
000c828e  0f84effeffff             je 0xc8183
000c8294  410f104d00               movups xmm1, xmmword ptr [r13]
000c8299  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c829d  410f104510               movups xmm0, xmmword ptr [r13 + 0x10]
000c82a2  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c82a6  66480f7eca               movq rdx, xmm1
000c82ab  48c1ea20                 shr rdx, 0x20
000c82af  f6c201                   test dl, 1
000c82b2  0f8584040000             jne 0xc873c
000c82b8  81e22ffbffff             and edx, 0xfffffb2f
000c82be  81ca20020000             or edx, 0x220
000c82c4  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c82c8  48c1e820                 shr rax, 0x20
000c82cc  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c82d0  498bc8                   mov rcx, r8
000c82d3  48c1e920                 shr rcx, 0x20
000c82d7  49c1e810                 shr r8, 0x10
000c82db  89442438                 mov dword ptr [rsp + 0x38], eax
000c82df  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c82e2  89442430                 mov dword ptr [rsp + 0x30], eax
000c82e6  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c82ea  664489442420             mov word ptr [rsp + 0x20], r8w
000c82f0  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c82f5  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c82f9  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c82fc  e80f96f4ff               call 0x11910
000c8301  48898380000000           mov qword ptr [rbx + 0x80], rax
000c8308  4885c0                   test rax, rax
000c830b  0f95c0                   setne al
000c830e  84c0                     test al, al
000c8310  0f8526040000             jne 0xc873c
000c8316  33db                     xor ebx, ebx
000c8318  e94e040000               jmp 0xc876b
000c831d  4d8d6028                 lea r12, [r8 + 0x28]
000c8321  498b0c24                 mov rcx, qword ptr [r12]
000c8325  488d81f0050000           lea rax, [rcx + 0x5f0]
000c832c  49890424                 mov qword ptr [r12], rax
000c8330  4d8d7830                 lea r15, [r8 + 0x30]
000c8334  6641830f01               or word ptr [r15], 1
000c8339  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c833d  4885c9                   test rcx, rcx
000c8340  740a                     je 0xc834c
000c8342  e8a9560000               call 0xcd9f0
000c8347  488bd8                   mov rbx, rax
000c834a  eb02                     jmp 0xc834e
000c834c  33db                     xor ebx, ebx
000c834e  4c8b9590000000           mov r10, qword ptr [rbp + 0x90]
000c8355  418b4204                 mov eax, dword ptr [r10 + 4]
000c8359  448b8588000000           mov r8d, dword ptr [rbp + 0x88]
000c8360  41be00020000             mov r14d, 0x200
000c8366  a802                     test al, 2
000c8368  743c                     je 0xc83a6
000c836a  a820                     test al, 0x20
000c836c  7538                     jne 0xc83a6
000c836e  a810                     test al, 0x10
000c8370  7534                     jne 0xc83a6
000c8372  a801                     test al, 1
000c8374  7530                     jne 0xc83a6
000c8376  4185c6                   test r14d, eax
000c8379  752b                     jne 0xc83a6
000c837b  a840                     test al, 0x40
000c837d  7527                     jne 0xc83a6
000c837f  803db29a260000           cmp byte ptr [rip + 0x269ab2], 0
000c8386  741e                     je 0xc83a6
000c8388  8b055ec72400             mov eax, dword ptr [rip + 0x24c75e]
000c838e  83f801                   cmp eax, 1
000c8391  7613                     jbe 0xc83a6
000c8393  c7834805000001000000     mov dword ptr [rbx + 0x548], 1
000c839d  448b0d48c72400           mov r9d, dword ptr [rip + 0x24c748]
000c83a4  eb23                     jmp 0xc83c9
000c83a6  c7834805000000000000     mov dword ptr [rbx + 0x548], 0
000c83b0  418bc8                   mov ecx, r8d
000c83b3  e828740700               call 0x13f7e0
000c83b8  448bc8                   mov r9d, eax
000c83bb  448b8588000000           mov r8d, dword ptr [rbp + 0x88]
000c83c2  4c8b9590000000           mov r10, qword ptr [rbp + 0x90]
000c83c9  418bc1                   mov eax, r9d
000c83cc  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c83d4  4883e0f0                 and rax, 0xfffffffffffffff0
000c83d8  48c7832805000000000000   mov qword ptr [rbx + 0x528], 0
000c83e3  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c83ea  740b                     je 0xc83f7
000c83ec  6644397704               cmp word ptr [rdi + 4], r14w
000c83f1  7504                     jne 0xc83f7
000c83f3  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c83f7  498b0c24                 mov rcx, qword ptr [r12]
000c83fb  488d1401                 lea rdx, [rcx + rax]
000c83ff  488d8700200000           lea rax, [rdi + 0x2000]
000c8406  483bd0                   cmp rdx, rax
000c8409  7310                     jae 0xc841b
000c840b  49891424                 mov qword ptr [r12], rdx
000c840f  6641830f01               or word ptr [r15], 1
000c8414  48898b28050000           mov qword ptr [rbx + 0x528], rcx
000c841b  4c89542420               mov qword ptr [rsp + 0x20], r10
000c8420  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000c8427  488bcb                   mov rcx, rbx
000c842a  e871940700               call 0x1418a0
000c842f  85c0                     test eax, eax
000c8431  0f844cfdffff             je 0xc8183
000c8437  4533e4                   xor r12d, r12d
000c843a  4c89a380000000           mov qword ptr [rbx + 0x80], r12
000c8441  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c844b  89b38c000000             mov dword ptr [rbx + 0x8c], esi
000c8451  4c89a338040000           mov qword ptr [rbx + 0x438], r12
000c8458  4489a340040000           mov dword ptr [rbx + 0x440], r12d
000c845f  4c89a348040000           mov qword ptr [rbx + 0x448], r12
000c8466  488d8b90000000           lea rcx, [rbx + 0x90]
000c846d  4c8bcb                   mov r9, rbx
000c8470  448bc6                   mov r8d, esi
000c8473  498bd5                   mov rdx, r13
000c8476  e825ff0900               call 0x1683a0
000c847b  e9bf020000               jmp 0xc873f
000c8480  4d8d6028                 lea r12, [r8 + 0x28]
000c8484  498b0c24                 mov rcx, qword ptr [r12]
000c8488  488d8100060000           lea rax, [rcx + 0x600]
000c848f  49890424                 mov qword ptr [r12], rax
000c8493  4d8d7830                 lea r15, [r8 + 0x30]
000c8497  6641830f01               or word ptr [r15], 1
000c849c  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c84a0  4885c9                   test rcx, rcx
000c84a3  740a                     je 0xc84af
000c84a5  e8c6550000               call 0xcda70
000c84aa  488bd8                   mov rbx, rax
000c84ad  eb02                     jmp 0xc84b1
000c84af  33db                     xor ebx, ebx
000c84b1  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c84b8  8b4004                   mov eax, dword ptr [rax + 4]
000c84bb  448b8588000000           mov r8d, dword ptr [rbp + 0x88]
000c84c2  41be00020000             mov r14d, 0x200
000c84c8  a802                     test al, 2
000c84ca  743c                     je 0xc8508
000c84cc  a820                     test al, 0x20
000c84ce  7538                     jne 0xc8508
000c84d0  a810                     test al, 0x10
000c84d2  7534                     jne 0xc8508
000c84d4  a801                     test al, 1
000c84d6  7530                     jne 0xc8508
000c84d8  4185c6                   test r14d, eax
000c84db  752b                     jne 0xc8508
000c84dd  a840                     test al, 0x40
000c84df  7527                     jne 0xc8508
000c84e1  803d5099260000           cmp byte ptr [rip + 0x269950], 0
000c84e8  741e                     je 0xc8508
000c84ea  8b05fcc52400             mov eax, dword ptr [rip + 0x24c5fc]
000c84f0  83f801                   cmp eax, 1
000c84f3  7613                     jbe 0xc8508
000c84f5  c7835005000001000000     mov dword ptr [rbx + 0x550], 1
000c84ff  448b0de6c52400           mov r9d, dword ptr [rip + 0x24c5e6]
000c8506  eb1c                     jmp 0xc8524
000c8508  c7835005000000000000     mov dword ptr [rbx + 0x550], 0
000c8512  418bc8                   mov ecx, r8d
000c8515  e8c6720700               call 0x13f7e0
000c851a  448bc8                   mov r9d, eax
000c851d  448b8588000000           mov r8d, dword ptr [rbp + 0x88]
000c8524  418bc1                   mov eax, r9d
000c8527  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c852f  4883e0f0                 and rax, 0xfffffffffffffff0
000c8533  48c7833005000000000000   mov qword ptr [rbx + 0x530], 0
000c853e  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c8545  740b                     je 0xc8552
000c8547  6644397704               cmp word ptr [rdi + 4], r14w
000c854c  7504                     jne 0xc8552
000c854e  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c8552  498b0c24                 mov rcx, qword ptr [r12]
000c8556  488d1401                 lea rdx, [rcx + rax]
000c855a  488d8700200000           lea rax, [rdi + 0x2000]
000c8561  483bd0                   cmp rdx, rax
000c8564  7310                     jae 0xc8576
000c8566  49891424                 mov qword ptr [r12], rdx
000c856a  6641830f01               or word ptr [r15], 1
000c856f  48898b30050000           mov qword ptr [rbx + 0x530], rcx
000c8576  488bbd90000000           mov rdi, qword ptr [rbp + 0x90]
000c857d  48897c2420               mov qword ptr [rsp + 0x20], rdi
000c8582  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000c8589  488bcb                   mov rcx, rbx
000c858c  e86f9b0700               call 0x142100
000c8591  85c0                     test eax, eax
000c8593  0f84eafbffff             je 0xc8183
000c8599  0f100f                   movups xmm1, xmmword ptr [rdi]
000c859c  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c85a0  0f104710                 movups xmm0, xmmword ptr [rdi + 0x10]
000c85a4  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c85a8  66480f7eca               movq rdx, xmm1
000c85ad  48c1ea20                 shr rdx, 0x20
000c85b1  f6c201                   test dl, 1
000c85b4  0f857dfeffff             jne 0xc8437
000c85ba  81e22ffbffff             and edx, 0xfffffb2f
000c85c0  81ca20020000             or edx, 0x220
000c85c6  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c85ca  48c1e820                 shr rax, 0x20
000c85ce  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c85d2  498bc8                   mov rcx, r8
000c85d5  48c1e920                 shr rcx, 0x20
000c85d9  49c1e810                 shr r8, 0x10
000c85dd  89442438                 mov dword ptr [rsp + 0x38], eax
000c85e1  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c85e4  89442430                 mov dword ptr [rsp + 0x30], eax
000c85e8  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c85ec  664489442420             mov word ptr [rsp + 0x20], r8w
000c85f2  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c85f7  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c85fb  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c85fe  e80d93f4ff               call 0x11910
000c8603  48898350040000           mov qword ptr [rbx + 0x450], rax
000c860a  4885c0                   test rax, rax
000c860d  0f95c0                   setne al
000c8610  84c0                     test al, al
000c8612  0f851ffeffff             jne 0xc8437
000c8618  33db                     xor ebx, ebx
000c861a  e94c010000               jmp 0xc876b
000c861f  4d8d7828                 lea r15, [r8 + 0x28]
000c8623  498b0f                   mov rcx, qword ptr [r15]
000c8626  488d81a0020000           lea rax, [rcx + 0x2a0]
000c862d  498907                   mov qword ptr [r15], rax
000c8630  498d7030                 lea rsi, [r8 + 0x30]
000c8634  66830e01                 or word ptr [rsi], 1
000c8638  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c863c  4885c9                   test rcx, rcx
000c863f  740a                     je 0xc864b
000c8641  e8aa540000               call 0xcdaf0
000c8646  488bd8                   mov rbx, rax
000c8649  eb03                     jmp 0xc864e
000c864b  498bdc                   mov rbx, r12
000c864e  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000c8655  418b4504                 mov eax, dword ptr [r13 + 4]
000c8659  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000c8660  41be00020000             mov r14d, 0x200
000c8666  a802                     test al, 2
000c8668  743c                     je 0xc86a6
000c866a  a820                     test al, 0x20
000c866c  7538                     jne 0xc86a6
000c866e  a810                     test al, 0x10
000c8670  7534                     jne 0xc86a6
000c8672  a801                     test al, 1
000c8674  7530                     jne 0xc86a6
000c8676  4185c6                   test r14d, eax
000c8679  752b                     jne 0xc86a6
000c867b  a840                     test al, 0x40
000c867d  7527                     jne 0xc86a6
000c867f  803db297260000           cmp byte ptr [rip + 0x2697b2], 0
000c8686  741e                     je 0xc86a6
000c8688  8b055ec42400             mov eax, dword ptr [rip + 0x24c45e]
000c868e  83f801                   cmp eax, 1
000c8691  7613                     jbe 0xc86a6
000c8693  c783f001000001000000     mov dword ptr [rbx + 0x1f0], 1
000c869d  448b0d48c42400           mov r9d, dword ptr [rip + 0x24c448]
000c86a4  eb15                     jmp 0xc86bb
000c86a6  c783f001000000000000     mov dword ptr [rbx + 0x1f0], 0
000c86b0  418bcc                   mov ecx, r12d
000c86b3  e828710700               call 0x13f7e0
000c86b8  448bc8                   mov r9d, eax
000c86bb  418bc1                   mov eax, r9d
000c86be  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c86c6  4883e0f0                 and rax, 0xfffffffffffffff0
000c86ca  48c783d001000000000000   mov qword ptr [rbx + 0x1d0], 0
000c86d5  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c86dc  740b                     je 0xc86e9
000c86de  6644397704               cmp word ptr [rdi + 4], r14w
000c86e3  7504                     jne 0xc86e9
000c86e5  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c86e9  498b0f                   mov rcx, qword ptr [r15]
000c86ec  488d1401                 lea rdx, [rcx + rax]
000c86f0  488d8700200000           lea rax, [rdi + 0x2000]
000c86f7  483bd0                   cmp rdx, rax
000c86fa  730e                     jae 0xc870a
000c86fc  498917                   mov qword ptr [r15], rdx
000c86ff  66830e01                 or word ptr [rsi], 1
000c8703  48898bd0010000           mov qword ptr [rbx + 0x1d0], rcx
000c870a  4c896c2420               mov qword ptr [rsp + 0x20], r13
000c870f  458bc4                   mov r8d, r12d
000c8712  488bbd80000000           mov rdi, qword ptr [rbp + 0x80]
000c8719  488bd7                   mov rdx, rdi
000c871c  488bcb                   mov rcx, rbx
000c871f  e80c9e0700               call 0x142530
000c8724  85c0                     test eax, eax
000c8726  0f8457faffff             je 0xc8183
000c872c  440fb64744               movzx r8d, byte ptr [rdi + 0x44]
000c8731  498bd5                   mov rdx, r13
000c8734  488bcb                   mov rcx, rbx
000c8737  e8444b0200               call 0xed280
000c873c  4533e4                   xor r12d, r12d
000c873f  448b7578                 mov r14d, dword ptr [rbp + 0x78]
000c8743  4885db                   test rbx, rbx
000c8746  7423                     je 0xc876b
000c8748  4c896350                 mov qword ptr [rbx + 0x50], r12
000c874c  4c896360                 mov qword ptr [rbx + 0x60], r12
000c8750  4c896358                 mov qword ptr [rbx + 0x58], r12
000c8754  c7437801000000           mov dword ptr [rbx + 0x78], 1
000c875b  41c1ee17                 shr r14d, 0x17
000c875f  4183e601                 and r14d, 1
000c8763  4489737c                 mov dword ptr [rbx + 0x7c], r14d
000c8767  834b2802                 or dword ptr [rbx + 0x28], 2
000c876b  488bc3                   mov rax, rbx
000c876e  488b9c24b0000000         mov rbx, qword ptr [rsp + 0xb0]
000c8776  4883c470                 add rsp, 0x70
000c877a  415f                     pop r15
000c877c  415e                     pop r14
000c877e  415d                     pop r13
000c8780  415c                     pop r12
000c8782  5f                       pop rdi
000c8783  5e                       pop rsi
000c8784  5d                       pop rbp
000c8785  c3                       ret
000c8786  90                       nop
000c8787  90                       nop
000c8788  cb                       retf
000c8789  780c                     js 0xc8797
000c878b  003d790c00cc             add byte ptr [rip - 0x33fff387], bh
000c8791  7c0c                     jl 0xc879f
000c8793  00567e                   add byte ptr [rsi + 0x7e], dl
000c8796  0c00                     or al, 0
000c8798  777d                     ja 0xc8817
000c879a  0c00                     or al, 0
000c879c  59                       pop rcx
000c879d  7f0c                     jg 0xc87ab
000c879f  00b97f0c0019             add byte ptr [rcx + 0x19000c7f], bh
000c87a5  800c006b                 or byte ptr [rax + rax], 0x6b
000c87a9  870c00                   xchg dword ptr [rax + rax], ecx
000c87ac  6b870c0079800c           imul eax, dword ptr [rdi - 0x7f86fff4], 0xc
000c87b3  001d830c006b             add byte ptr [rip + 0x6b000c83], bl
000c87b9  870c00                   xchg dword ptr [rax + rax], ecx
000c87bc  6b870c006b870c           imul eax, dword ptr [rdi - 0x7894fff4], 0xc
000c87c3  006b87                   add byte ptr [rbx - 0x79], ch
000c87c6  0c00                     or al, 0
000c87c8  9c                       pushfq
000c87c9  7a0c                     jp 0xc87d7
000c87cb  00a87b0c0047             add byte ptr [rax + 0x47000c7b], ch
000c87d1  7d0c                     jge 0xc87df
000c87d3  00a47e0c00267e           add byte ptr [rsi + rdi*2 + 0x7e26000c], ah
000c87da  0c00                     or al, 0
000c87dc  897f0c                   mov dword ptr [rdi + 0xc], edi
000c87df  00e9                     add cl, ch
000c87e1  7f0c                     jg 0xc87ef
000c87e3  004980                   add byte ptr [rcx - 0x80], cl
000c87e6  0c00                     or al, 0
000c87e8  6b870c006b870c           imul eax, dword ptr [rdi - 0x7894fff4], 0xc
000c87ef  008a810c0080             add byte ptr [rdx - 0x7ffff37f], cl
000c87f5  840c00                   test byte ptr [rax + rax], cl
000c87f8  6b870c006b870c           imul eax, dword ptr [rdi - 0x7894fff4], 0xc
000c87ff  006b87                   add byte ptr [rbx - 0x79], ch
000c8802  0c00                     or al, 0
000c8804  6b870c00517a0c           imul eax, dword ptr [rdi + 0x7a51000c], 0xc
000c880b  006b87                   add byte ptr [rbx - 0x79], ch
000c880e  0c00                     or al, 0
000c8810  fc                       cld
000c8811  7c0c                     jl 0xc881f
000c8813  006b87                   add byte ptr [rbx - 0x79], ch
000c8816  0c00                     or al, 0
000c8818  6b870c006b870c           imul eax, dword ptr [rdi - 0x7894fff4], 0xc
000c881f  006b87                   add byte ptr [rbx - 0x79], ch
000c8822  0c00                     or al, 0
000c8824  6b870c006b870c           imul eax, dword ptr [rdi - 0x7894fff4], 0xc
000c882b  006b87                   add byte ptr [rbx - 0x79], ch
000c882e  0c00                     or al, 0
