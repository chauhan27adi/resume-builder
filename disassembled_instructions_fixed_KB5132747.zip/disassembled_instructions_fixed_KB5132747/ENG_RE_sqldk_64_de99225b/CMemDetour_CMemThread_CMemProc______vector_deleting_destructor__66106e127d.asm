; CMemDetour<CMemThread<CMemProc> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcdd90, 104 bytes in 1 chunk(s)

; chunk at RVA 0xcdd90 (104 bytes)
000cdd90  48894c2408               mov qword ptr [rsp + 8], rcx
000cdd95  57                       push rdi
000cdd96  4883ec30                 sub rsp, 0x30
000cdd9a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cdda3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cdda8  8bda                     mov ebx, edx
000cddaa  488bf9                   mov rdi, rcx
000cddad  488d057c101800           lea rax, [rip + 0x18107c]
000cddb4  488901                   mov qword ptr [rcx], rax
000cddb7  488d81b8010000           lea rax, [rcx + 0x1b8]
000cddbe  4889442450               mov qword ptr [rsp + 0x50], rax
000cddc3  488d0d76bd1600           lea rcx, [rip + 0x16bd76]
000cddca  488908                   mov qword ptr [rax], rcx
000cddcd  488bcf                   mov rcx, rdi
000cddd0  e8ab4e0000               call 0xd2c80
000cddd5  83e305                   and ebx, 5
000cddd8  80fb05                   cmp bl, 5
000cdddb  750d                     jne 0xcddea
000cdddd  baf0010000               mov edx, 0x1f0
000cdde2  488bcf                   mov rcx, rdi
000cdde5  e82632f3ff               call 0x1010
000cddea  488bc7                   mov rax, rdi
000cdded  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cddf2  4883c430                 add rsp, 0x30
000cddf6  5f                       pop rdi
000cddf7  c3                       ret
