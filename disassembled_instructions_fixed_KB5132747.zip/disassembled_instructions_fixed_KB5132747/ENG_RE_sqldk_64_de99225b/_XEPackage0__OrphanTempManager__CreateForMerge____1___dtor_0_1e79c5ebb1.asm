; `XEPackage0::OrphanTempManager::CreateForMerge'::`1'::dtor$0
; sqldk.dll, primary RVA 0x231340, 41 bytes in 1 chunk(s)

; chunk at RVA 0x231340 (41 bytes)
00231340  4055                     push rbp
00231342  4883ec20                 sub rsp, 0x20
00231346  488bea                   mov rbp, rdx
00231349  4c8b85f8000000           mov r8, qword ptr [rbp + 0xf8]
00231350  488b95f0000000           mov rdx, qword ptr [rbp + 0xf0]
00231357  488b8d08010000           mov rcx, qword ptr [rbp + 0x108]
0023135e  e8adfcdcff               call 0x1010
00231363  4883c420                 add rsp, 0x20
00231367  5d                       pop rbp
00231368  c3                       ret
