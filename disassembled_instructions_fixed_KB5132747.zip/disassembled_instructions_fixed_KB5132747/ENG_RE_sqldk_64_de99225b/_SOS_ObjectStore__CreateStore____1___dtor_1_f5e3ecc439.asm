; `SOS_ObjectStore::CreateStore'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22ce7b, 53 bytes in 1 chunk(s)

; chunk at RVA 0x22ce7b (53 bytes)
0022ce7b  4055                     push rbp
0022ce7d  4883ec30                 sub rsp, 0x30
0022ce81  488bea                   mov rbp, rdx
0022ce84  c644242806               mov byte ptr [rsp + 0x28], 6
0022ce89  8b4530                   mov eax, dword ptr [rbp + 0x30]
0022ce8c  89442420                 mov dword ptr [rsp + 0x20], eax
0022ce90  4c8d0d01d50400           lea r9, [rip + 0x4d501]
0022ce97  41b801000000             mov r8d, 1
0022ce9d  488b5548                 mov rdx, qword ptr [rbp + 0x48]
0022cea1  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022cea5  e866a0ddff               call 0x6f10
0022ceaa  4883c430                 add rsp, 0x30
0022ceae  5d                       pop rbp
0022ceaf  c3                       ret
