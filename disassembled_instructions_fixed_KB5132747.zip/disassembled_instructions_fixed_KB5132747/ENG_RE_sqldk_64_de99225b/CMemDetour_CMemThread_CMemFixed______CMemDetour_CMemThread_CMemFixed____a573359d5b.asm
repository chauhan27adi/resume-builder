; CMemDetour<CMemThread<CMemFixed> >::~CMemDetour<CMemThread<CMemFixed> >
; sqldk.dll, primary RVA 0x103ce0, 59 bytes in 1 chunk(s)

; chunk at RVA 0x103ce0 (59 bytes)
00103ce0  48894c2408               mov qword ptr [rsp + 8], rcx
00103ce5  4883ec38                 sub rsp, 0x38
00103ce9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00103cf2  488d05679a1400           lea rax, [rip + 0x149a67]
00103cf9  488901                   mov qword ptr [rcx], rax
00103cfc  488d8120020000           lea rax, [rcx + 0x220]
00103d03  4889442448               mov qword ptr [rsp + 0x48], rax
00103d08  488d15315e1300           lea rdx, [rip + 0x135e31]
00103d0f  488910                   mov qword ptr [rax], rdx
00103d12  4883c438                 add rsp, 0x38
00103d16  e92589ffff               jmp 0xfc640
