; TBaseSafeCallbackList<TBaseSafeCallbackWithParam<void,TListSLock,SOSCallbackEvent,void * __ptr64,SOS_Node * __ptr64,unsigned __int64,unsigned __int64> >::~TBaseSafeCallbackList<TBaseSafeCallbackWithParam<void,TListSLock,SOSCallbackEvent,void * __ptr64,SOS_Node * __ptr64,unsigned __int64,unsigned __int64> >
; sqldk.dll, primary RVA 0x6ad30, 27 bytes in 1 chunk(s)

; chunk at RVA 0x6ad30 (27 bytes)
0006ad30  48894c2408               mov qword ptr [rsp + 8], rcx
0006ad35  4883ec38                 sub rsp, 0x38
0006ad39  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0006ad42  4883c438                 add rsp, 0x38
0006ad46  e915050000               jmp 0x6b260
