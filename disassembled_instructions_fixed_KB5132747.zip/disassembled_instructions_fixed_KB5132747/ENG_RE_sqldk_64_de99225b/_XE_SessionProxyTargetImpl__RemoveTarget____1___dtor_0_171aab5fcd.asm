; `XE_SessionProxyTargetImpl::RemoveTarget'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235060, 32 bytes in 1 chunk(s)

; chunk at RVA 0x235060 (32 bytes)
00235060  4055                     push rbp
00235062  4883ec20                 sub rsp, 0x20
00235066  488bea                   mov rbp, rdx
00235069  4c8b4548                 mov r8, qword ptr [rbp + 0x48]
0023506d  488b5558                 mov rdx, qword ptr [rbp + 0x58]
00235071  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
00235075  e896bfdcff               call 0x1010
0023507a  4883c420                 add rsp, 0x20
0023507e  5d                       pop rbp
0023507f  c3                       ret
