; SOS_SchedulerMonitorRecord::SerializeRecord
; sqldk.dll, primary RVA 0x185e60, 1012 bytes in 1 chunk(s)

; chunk at RVA 0x185e60 (1012 bytes)
00185e60  48895c2408               mov qword ptr [rsp + 8], rbx
00185e65  4889742410               mov qword ptr [rsp + 0x10], rsi
00185e6a  57                       push rdi
00185e6b  4881eca0000000           sub rsp, 0xa0
00185e72  4c635918                 movsxd r11, dword ptr [rcx + 0x18]
00185e76  498bd9                   mov rbx, r9
00185e79  498bf8                   mov rdi, r8
00185e7c  488bf2                   mov rsi, rdx
00185e7f  4c8bd1                   mov r10, rcx
00185e82  4183fb0a                 cmp r11d, 0xa
00185e86  0f8787030000             ja 0x186213
00185e8c  4c8d056da1e7ff           lea r8, [rip - 0x185e93]
00185e93  438b849828621800         mov eax, dword ptr [r8 + r11*4 + 0x186228]
00185e9b  4903c0                   add rax, r8
00185e9e  ffe0                     jmp rax
00185ea0  8b4170                   mov eax, dword ptr [rcx + 0x70]
00185ea3  0fb7511c                 movzx edx, word ptr [rcx + 0x1c]
00185ea7  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
00185eaf  89842490000000           mov dword ptr [rsp + 0x90], eax
00185eb6  488b4168                 mov rax, qword ptr [rcx + 0x68]
00185eba  4889842488000000         mov qword ptr [rsp + 0x88], rax
00185ec2  8b4160                   mov eax, dword ptr [rcx + 0x60]
00185ec5  89842480000000           mov dword ptr [rsp + 0x80], eax
00185ecc  488b4150                 mov rax, qword ptr [rcx + 0x50]
00185ed0  4889442478               mov qword ptr [rsp + 0x78], rax
00185ed5  488b4158                 mov rax, qword ptr [rcx + 0x58]
00185ed9  4889442470               mov qword ptr [rsp + 0x70], rax
00185ede  8b4148                   mov eax, dword ptr [rcx + 0x48]
00185ee1  89442468                 mov dword ptr [rsp + 0x68], eax
00185ee5  8b4144                   mov eax, dword ptr [rcx + 0x44]
00185ee8  89442460                 mov dword ptr [rsp + 0x60], eax
00185eec  8b4140                   mov eax, dword ptr [rcx + 0x40]
00185eef  89442458                 mov dword ptr [rsp + 0x58], eax
00185ef3  488b4130                 mov rax, qword ptr [rcx + 0x30]
00185ef7  4889442450               mov qword ptr [rsp + 0x50], rax
00185efc  488b4128                 mov rax, qword ptr [rcx + 0x28]
00185f00  4889442448               mov qword ptr [rsp + 0x48], rax
00185f05  8b4120                   mov eax, dword ptr [rcx + 0x20]
00185f08  488bce                   mov rcx, rsi
00185f0b  89442440                 mov dword ptr [rsp + 0x40], eax
00185f0f  488b051abf1a00           mov rax, qword ptr [rip + 0x1abf1a]
00185f16  89542438                 mov dword ptr [rsp + 0x38], edx
00185f1a  488bd7                   mov rdx, rdi
00185f1d  4889442430               mov qword ptr [rsp + 0x30], rax
00185f22  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
00185f2a  4c8bc3                   mov r8, rbx
00185f2d  4889442428               mov qword ptr [rsp + 0x28], rax
00185f32  48c744242000000000       mov qword ptr [rsp + 0x20], 0
00185f3b  e82034ecff               call 0x49360
00185f40  e9ce020000               jmp 0x186213
00185f45  418b4270                 mov eax, dword ptr [r10 + 0x70]
00185f49  488bd7                   mov rdx, rdi
00185f4c  0fb7491c                 movzx ecx, word ptr [rcx + 0x1c]
00185f50  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
00185f58  89442470                 mov dword ptr [rsp + 0x70], eax
00185f5c  498b4268                 mov rax, qword ptr [r10 + 0x68]
00185f60  4889442468               mov qword ptr [rsp + 0x68], rax
00185f65  418b4260                 mov eax, dword ptr [r10 + 0x60]
00185f69  89442460                 mov dword ptr [rsp + 0x60], eax
00185f6d  498b4250                 mov rax, qword ptr [r10 + 0x50]
00185f71  4889442458               mov qword ptr [rsp + 0x58], rax
00185f76  498b4258                 mov rax, qword ptr [r10 + 0x58]
00185f7a  4889442450               mov qword ptr [rsp + 0x50], rax
00185f7f  418b4248                 mov eax, dword ptr [r10 + 0x48]
00185f83  89442448                 mov dword ptr [rsp + 0x48], eax
00185f87  418b4244                 mov eax, dword ptr [r10 + 0x44]
00185f8b  89442440                 mov dword ptr [rsp + 0x40], eax
00185f8f  488b059abe1a00           mov rax, qword ptr [rip + 0x1abe9a]
00185f96  894c2438                 mov dword ptr [rsp + 0x38], ecx
00185f9a  488bce                   mov rcx, rsi
00185f9d  4889442430               mov qword ptr [rsp + 0x30], rax
00185fa2  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
00185faa  4c8bc3                   mov r8, rbx
00185fad  4889442428               mov qword ptr [rsp + 0x28], rax
00185fb2  48c744242000000000       mov qword ptr [rsp + 0x20], 0
00185fbb  e8a033ecff               call 0x49360
00185fc0  e94e020000               jmp 0x186213
00185fc5  8b4170                   mov eax, dword ptr [rcx + 0x70]
00185fc8  4c8bc3                   mov r8, rbx
00185fcb  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
00185fd3  488bd7                   mov rdx, rdi
00185fd6  89442468                 mov dword ptr [rsp + 0x68], eax
00185fda  488b4168                 mov rax, qword ptr [rcx + 0x68]
00185fde  4889442460               mov qword ptr [rsp + 0x60], rax
00185fe3  8b4160                   mov eax, dword ptr [rcx + 0x60]
00185fe6  89442458                 mov dword ptr [rsp + 0x58], eax
00185fea  488b4150                 mov rax, qword ptr [rcx + 0x50]
00185fee  4889442450               mov qword ptr [rsp + 0x50], rax
00185ff3  488b4158                 mov rax, qword ptr [rcx + 0x58]
00185ff7  4889442448               mov qword ptr [rsp + 0x48], rax
00185ffc  8b4148                   mov eax, dword ptr [rcx + 0x48]
00185fff  89442440                 mov dword ptr [rsp + 0x40], eax
00186003  8b4144                   mov eax, dword ptr [rcx + 0x44]
00186006  488bce                   mov rcx, rsi
00186009  89442438                 mov dword ptr [rsp + 0x38], eax
0018600d  488b051cbe1a00           mov rax, qword ptr [rip + 0x1abe1c]
00186014  4889442430               mov qword ptr [rsp + 0x30], rax
00186019  488b0580511100           mov rax, qword ptr [rip + 0x115180]
00186020  4889442428               mov qword ptr [rsp + 0x28], rax
00186025  48c744242000000000       mov qword ptr [rsp + 0x20], 0
0018602e  e82d33ecff               call 0x49360
00186033  e9db010000               jmp 0x186213
00186038  418b4270                 mov eax, dword ptr [r10 + 0x70]
0018603c  488bd7                   mov rdx, rdi
0018603f  0fb7491c                 movzx ecx, word ptr [rcx + 0x1c]
00186043  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
0018604b  89842488000000           mov dword ptr [rsp + 0x88], eax
00186052  498b4268                 mov rax, qword ptr [r10 + 0x68]
00186056  4889842480000000         mov qword ptr [rsp + 0x80], rax
0018605e  418b4260                 mov eax, dword ptr [r10 + 0x60]
00186062  89442478                 mov dword ptr [rsp + 0x78], eax
00186066  498b4258                 mov rax, qword ptr [r10 + 0x58]
0018606a  4889442470               mov qword ptr [rsp + 0x70], rax
0018606f  498b4250                 mov rax, qword ptr [r10 + 0x50]
00186073  4889442468               mov qword ptr [rsp + 0x68], rax
00186078  418b4248                 mov eax, dword ptr [r10 + 0x48]
0018607c  89442460                 mov dword ptr [rsp + 0x60], eax
00186080  418b4244                 mov eax, dword ptr [r10 + 0x44]
00186084  89442458                 mov dword ptr [rsp + 0x58], eax
00186088  418b4240                 mov eax, dword ptr [r10 + 0x40]
0018608c  89442450                 mov dword ptr [rsp + 0x50], eax
00186090  498b4230                 mov rax, qword ptr [r10 + 0x30]
00186094  4889442448               mov qword ptr [rsp + 0x48], rax
00186099  498b4228                 mov rax, qword ptr [r10 + 0x28]
0018609d  4889442440               mov qword ptr [rsp + 0x40], rax
001860a2  488b0587bd1a00           mov rax, qword ptr [rip + 0x1abd87]
001860a9  894c2438                 mov dword ptr [rsp + 0x38], ecx
001860ad  488bce                   mov rcx, rsi
001860b0  4889442430               mov qword ptr [rsp + 0x30], rax
001860b5  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
001860bd  4c8bc3                   mov r8, rbx
001860c0  4889442428               mov qword ptr [rsp + 0x28], rax
001860c5  48c744242000000000       mov qword ptr [rsp + 0x20], 0
001860ce  e88d32ecff               call 0x49360
001860d3  e93b010000               jmp 0x186213
001860d8  418b4270                 mov eax, dword ptr [r10 + 0x70]
001860dc  488bd7                   mov rdx, rdi
001860df  0fb7491c                 movzx ecx, word ptr [rcx + 0x1c]
001860e3  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
001860eb  89842490000000           mov dword ptr [rsp + 0x90], eax
001860f2  498b4268                 mov rax, qword ptr [r10 + 0x68]
001860f6  4889842488000000         mov qword ptr [rsp + 0x88], rax
001860fe  418b4260                 mov eax, dword ptr [r10 + 0x60]
00186102  89842480000000           mov dword ptr [rsp + 0x80], eax
00186109  498b4250                 mov rax, qword ptr [r10 + 0x50]
0018610d  4889442478               mov qword ptr [rsp + 0x78], rax
00186112  498b4258                 mov rax, qword ptr [r10 + 0x58]
00186116  4889442470               mov qword ptr [rsp + 0x70], rax
0018611b  418b4248                 mov eax, dword ptr [r10 + 0x48]
0018611f  89442468                 mov dword ptr [rsp + 0x68], eax
00186123  418b4244                 mov eax, dword ptr [r10 + 0x44]
00186127  89442460                 mov dword ptr [rsp + 0x60], eax
0018612b  418b4240                 mov eax, dword ptr [r10 + 0x40]
0018612f  89442458                 mov dword ptr [rsp + 0x58], eax
00186133  498b4238                 mov rax, qword ptr [r10 + 0x38]
00186137  4889442450               mov qword ptr [rsp + 0x50], rax
0018613c  498b4230                 mov rax, qword ptr [r10 + 0x30]
00186140  4889442448               mov qword ptr [rsp + 0x48], rax
00186145  498b4228                 mov rax, qword ptr [r10 + 0x28]
00186149  4889442440               mov qword ptr [rsp + 0x40], rax
0018614e  488b05dbbc1a00           mov rax, qword ptr [rip + 0x1abcdb]
00186155  894c2438                 mov dword ptr [rsp + 0x38], ecx
00186159  488bce                   mov rcx, rsi
0018615c  4889442430               mov qword ptr [rsp + 0x30], rax
00186161  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
00186169  4c8bc3                   mov r8, rbx
0018616c  4889442428               mov qword ptr [rsp + 0x28], rax
00186171  48c744242000000000       mov qword ptr [rsp + 0x20], 0
0018617a  e8e131ecff               call 0x49360
0018617f  e98f000000               jmp 0x186213
00186184  418b4270                 mov eax, dword ptr [r10 + 0x70]
00186188  488bd7                   mov rdx, rdi
0018618b  0fb7491c                 movzx ecx, word ptr [rcx + 0x1c]
0018618f  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
00186197  89842480000000           mov dword ptr [rsp + 0x80], eax
0018619e  498b4268                 mov rax, qword ptr [r10 + 0x68]
001861a2  4889442478               mov qword ptr [rsp + 0x78], rax
001861a7  418b4260                 mov eax, dword ptr [r10 + 0x60]
001861ab  89442470                 mov dword ptr [rsp + 0x70], eax
001861af  498b4250                 mov rax, qword ptr [r10 + 0x50]
001861b3  4889442468               mov qword ptr [rsp + 0x68], rax
001861b8  498b4258                 mov rax, qword ptr [r10 + 0x58]
001861bc  4889442460               mov qword ptr [rsp + 0x60], rax
001861c1  418b4248                 mov eax, dword ptr [r10 + 0x48]
001861c5  89442458                 mov dword ptr [rsp + 0x58], eax
001861c9  418b4244                 mov eax, dword ptr [r10 + 0x44]
001861cd  89442450                 mov dword ptr [rsp + 0x50], eax
001861d1  418b4240                 mov eax, dword ptr [r10 + 0x40]
001861d5  89442448                 mov dword ptr [rsp + 0x48], eax
001861d9  498b4228                 mov rax, qword ptr [r10 + 0x28]
001861dd  4889442440               mov qword ptr [rsp + 0x40], rax
001861e2  488b0547bc1a00           mov rax, qword ptr [rip + 0x1abc47]
001861e9  894c2438                 mov dword ptr [rsp + 0x38], ecx
001861ed  488bce                   mov rcx, rsi
001861f0  4889442430               mov qword ptr [rsp + 0x30], rax
001861f5  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
001861fd  4c8bc3                   mov r8, rbx
00186200  4889442428               mov qword ptr [rsp + 0x28], rax
00186205  48c744242000000000       mov qword ptr [rsp + 0x20], 0
0018620e  e84d31ecff               call 0x49360
00186213  4c8d9c24a0000000         lea r11, [rsp + 0xa0]
0018621b  498b5b10                 mov rbx, qword ptr [r11 + 0x10]
0018621f  498b7318                 mov rsi, qword ptr [r11 + 0x18]
00186223  498be3                   mov rsp, r11
00186226  5f                       pop rdi
00186227  c3                       ret
00186228  a05e1800a05e180045       movabs al, byte ptr [0x4500185ea000185e]
00186231  5f                       pop rdi
00186232  1800                     sbb byte ptr [rax], al
00186234  455f                     pop r15
00186236  1800                     sbb byte ptr [rax], al
