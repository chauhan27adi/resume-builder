; `XE_ProxyTransportStrategy::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2370b0, 31 bytes in 1 chunk(s)

; chunk at RVA 0x2370b0 (31 bytes)
002370b0  4055                     push rbp
002370b2  4883ec20                 sub rsp, 0x20
002370b6  488bea                   mov rbp, rdx
002370b9  4533c0                   xor r8d, r8d
002370bc  488b5558                 mov rdx, qword ptr [rbp + 0x58]
002370c0  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
002370c4  e8479fdcff               call 0x1010
002370c9  4883c420                 add rsp, 0x20
002370cd  5d                       pop rbp
002370ce  c3                       ret
