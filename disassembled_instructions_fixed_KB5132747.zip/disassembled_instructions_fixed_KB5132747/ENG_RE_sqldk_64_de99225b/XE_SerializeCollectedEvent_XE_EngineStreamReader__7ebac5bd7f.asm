; XE_SerializeCollectedEvent<XE_EngineStreamReader>
; sqldk.dll, primary RVA 0x3b460, 443 bytes in 5 chunk(s)

; chunk at RVA 0x2c540 (75 bytes)
0002c540  8bcd                     mov ecx, ebp
0002c542  83c508                   add ebp, 8
0002c545  418bde                   mov ebx, r14d
0002c548  48c1e304                 shl rbx, 4
0002c54c  49035d18                 add rbx, qword ptr [r13 + 0x18]
0002c550  488b03                   mov rax, qword ptr [rbx]
0002c553  4a890439                 mov qword ptr [rcx + r15], rax
0002c557  448b4304                 mov r8d, dword ptr [rbx + 4]
0002c55b  488b5308                 mov rdx, qword ptr [rbx + 8]
0002c55f  8bcd                     mov ecx, ebp
0002c561  4903cf                   add rcx, r15
0002c564  e89756fdff               call 0x1c00
0002c569  410fb74504               movzx eax, word ptr [r13 + 4]
0002c56e  41ffc6                   inc r14d
0002c571  036b04                   add ebp, dword ptr [rbx + 4]
0002c574  443bf0                   cmp r14d, eax
0002c577  72c7                     jb 0x2c540
0002c579  488b0588e52400           mov rax, qword ptr [rip + 0x24e588]
0002c580  4a89443d00               mov qword ptr [rbp + r15], rax
0002c585  e946f00000               jmp 0x3b5d0
0002c58a  cc                       int3

; chunk at RVA 0x3b460 (20 bytes)
0003b460  4c894c2420               mov qword ptr [rsp + 0x20], r9
0003b465  53                       push rbx
0003b466  55                       push rbp
0003b467  4155                     push r13
0003b469  4156                     push r14
0003b46b  4157                     push r15
0003b46d  4883ec40                 sub rsp, 0x40
0003b471  4d8be8                   mov r13, r8

; chunk at RVA 0x3b474 (163 bytes)
0003b474  48897c2430               mov qword ptr [rsp + 0x30], rdi
0003b479  8bfa                     mov edi, edx
0003b47b  4c8d7918                 lea r15, [rcx + 0x18]
0003b47f  8b5104                   mov edx, dword ptr [rcx + 4]
0003b482  4533f6                   xor r14d, r14d
0003b485  83e2ca                   and edx, 0xffffffca
0003b488  4c89bc2480000000         mov qword ptr [rsp + 0x80], r15
0003b490  83ca0a                   or edx, 0xa
0003b493  4803f9                   add rdi, rcx
0003b496  895104                   mov dword ptr [rcx + 4], edx
0003b499  418bee                   mov ebp, r14d
0003b49c  418b4104                 mov eax, dword ptr [r9 + 4]
0003b4a0  8901                     mov dword ptr [rcx], eax
0003b4a2  418b4008                 mov eax, dword ptr [r8 + 8]
0003b4a6  41b800000080             mov r8d, 0x80000000
0003b4ac  894114                   mov dword ptr [rcx + 0x14], eax
0003b4af  418bc6                   mov eax, r14d
0003b4b2  6641394504               cmp word ptr [r13 + 4], ax
0003b4b7  48897c2470               mov qword ptr [rsp + 0x70], rdi
0003b4bc  410f47c0                 cmova eax, r8d
0003b4c0  0fbaf21f                 btr edx, 0x1f
0003b4c4  0bc2                     or eax, edx
0003b4c6  894104                   mov dword ptr [rcx + 4], eax
0003b4c9  8b842490000000           mov eax, dword ptr [rsp + 0x90]
0003b4d0  894108                   mov dword ptr [rcx + 8], eax
0003b4d3  498b4520                 mov rax, qword ptr [r13 + 0x20]
0003b4d7  4889410c                 mov qword ptr [rcx + 0xc], rax
0003b4db  6641396d02               cmp word ptr [r13 + 2], bp
0003b4e0  0f86da000000             jbe 0x3b5c0
0003b4e6  498b5510                 mov rdx, qword ptr [r13 + 0x10]
0003b4ea  498bcf                   mov rcx, r15
0003b4ed  448b4208                 mov r8d, dword ptr [rdx + 8]
0003b4f1  488b12                   mov rdx, qword ptr [rdx]
0003b4f4  e80767fcff               call 0x1c00
0003b4f9  498b4510                 mov rax, qword ptr [r13 + 0x10]
0003b4fd  b901000000               mov ecx, 1
0003b502  898c2490000000           mov dword ptr [rsp + 0x90], ecx
0003b509  8b6808                   mov ebp, dword ptr [rax + 8]
0003b50c  66413b4d02               cmp cx, word ptr [r13 + 2]
0003b511  0f83a9000000             jae 0x3b5c0

; chunk at RVA 0x3b517 (169 bytes)
0003b517  4889742438               mov qword ptr [rsp + 0x38], rsi
0003b51c  4c89642428               mov qword ptr [rsp + 0x28], r12
0003b521  0f1f4000                 nop dword ptr [rax]
0003b525  6666660f1f840000000000   nop word ptr [rax + rax]
0003b530  8bd9                     mov ebx, ecx
0003b532  48c1e304                 shl rbx, 4
0003b536  49035d10                 add rbx, qword ptr [r13 + 0x10]
0003b53a  448be5                   mov r12d, ebp
0003b53d  4d03e7                   add r12, r15
0003b540  448b7b08                 mov r15d, dword ptr [rbx + 8]
0003b544  664439730e               cmp word ptr [rbx + 0xe], r14w
0003b549  0f8581311b00             jne 0x1ee6d0
0003b54f  488b13                   mov rdx, qword ptr [rbx]
0003b552  8bc7                     mov eax, edi
0003b554  412bc4                   sub eax, r12d
0003b557  498bcc                   mov rcx, r12
0003b55a  443bf8                   cmp r15d, eax
0003b55d  440f43f8                 cmovae r15d, eax
0003b561  458bc7                   mov r8d, r15d
0003b564  e89766fcff               call 0x1c00
0003b569  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
0003b56d  4c8bbc2480000000         mov r15, qword ptr [rsp + 0x80]
0003b575  488d0c80                 lea rcx, [rax + rax*4]
0003b579  488b842488000000         mov rax, qword ptr [rsp + 0x88]
0003b581  488b4040                 mov rax, qword ptr [rax + 0x40]
0003b585  0fb754c810               movzx edx, word ptr [rax + rcx*8 + 0x10]
0003b58a  8b8c2490000000           mov ecx, dword ptr [rsp + 0x90]
0003b591  ffc1                     inc ecx
0003b593  898c2490000000           mov dword ptr [rsp + 0x90], ecx
0003b59a  42892c3a                 mov dword ptr [rdx + r15], ebp
0003b59e  8b4308                   mov eax, dword ptr [rbx + 8]
0003b5a1  4289443a04               mov dword ptr [rdx + r15 + 4], eax
0003b5a6  036b08                   add ebp, dword ptr [rbx + 8]
0003b5a9  410fb74502               movzx eax, word ptr [r13 + 2]
0003b5ae  3bc8                     cmp ecx, eax
0003b5b0  0f827affffff             jb 0x3b530
0003b5b6  4c8b642428               mov r12, qword ptr [rsp + 0x28]
0003b5bb  488b742438               mov rsi, qword ptr [rsp + 0x38]

; chunk at RVA 0x3b5c0 (16 bytes)
0003b5c0  488b7c2430               mov rdi, qword ptr [rsp + 0x30]
0003b5c5  6645397504               cmp word ptr [r13 + 4], r14w
0003b5ca  0f87660fffff             ja 0x2c536
