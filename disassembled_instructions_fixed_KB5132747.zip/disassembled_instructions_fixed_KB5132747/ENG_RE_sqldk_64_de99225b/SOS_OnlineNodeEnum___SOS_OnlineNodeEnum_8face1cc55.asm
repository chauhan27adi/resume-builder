; SOS_OnlineNodeEnum::~SOS_OnlineNodeEnum
; sqldk.dll, primary RVA 0xb6060, 27 bytes in 1 chunk(s)

; chunk at RVA 0xb6060 (27 bytes)
000b6060  48894c2408               mov qword ptr [rsp + 8], rcx
000b6065  4883ec38                 sub rsp, 0x38
000b6069  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000b6072  4883c438                 add rsp, 0x38
000b6076  e92505f7ff               jmp 0x265a0
