; MemObjCache<CMemThread<CMemAligned<CMemProc> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcd6d0, 79 bytes in 1 chunk(s)

; chunk at RVA 0xcd6d0 (79 bytes)
000cd6d0  48894c2408               mov qword ptr [rsp + 8], rcx
000cd6d5  57                       push rdi
000cd6d6  4883ec30                 sub rsp, 0x30
000cd6da  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cd6e3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cd6e8  8bda                     mov ebx, edx
000cd6ea  488bf9                   mov rdi, rcx
000cd6ed  488d05dc7d1900           lea rax, [rip + 0x197ddc]
000cd6f4  488901                   mov qword ptr [rcx], rax
000cd6f7  e8a489ffff               call 0xc60a0
000cd6fc  83e305                   and ebx, 5
000cd6ff  80fb05                   cmp bl, 5
000cd702  750d                     jne 0xcd711
000cd704  bad0010000               mov edx, 0x1d0
000cd709  488bcf                   mov rcx, rdi
000cd70c  e8ff38f3ff               call 0x1010
000cd711  488bc7                   mov rax, rdi
000cd714  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cd719  4883c430                 add rsp, 0x30
000cd71d  5f                       pop rdi
000cd71e  c3                       ret
