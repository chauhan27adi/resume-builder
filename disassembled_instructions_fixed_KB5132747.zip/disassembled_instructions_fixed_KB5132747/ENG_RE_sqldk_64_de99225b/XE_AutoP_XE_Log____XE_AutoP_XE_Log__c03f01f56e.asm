; XE_AutoP<XE_Log>::~XE_AutoP<XE_Log>
; sqldk.dll, primary RVA 0x47910, 50 bytes in 1 chunk(s)

; chunk at RVA 0x47910 (50 bytes)
00047910  48894c2408               mov qword ptr [rsp + 8], rcx
00047915  53                       push rbx
00047916  4883ec30                 sub rsp, 0x30
0004791a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00047923  488bd9                   mov rbx, rcx
00047926  488b09                   mov rcx, qword ptr [rcx]
00047929  e852150000               call 0x48e80
0004792e  48c70300000000           mov qword ptr [rbx], 0
00047935  488bcb                   mov rcx, rbx
00047938  4883c430                 add rsp, 0x30
0004793c  5b                       pop rbx
0004793d  e99e120000               jmp 0x48be0
