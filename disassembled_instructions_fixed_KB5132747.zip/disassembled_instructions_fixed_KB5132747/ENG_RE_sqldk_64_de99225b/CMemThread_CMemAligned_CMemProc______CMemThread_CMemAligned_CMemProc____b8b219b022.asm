; CMemThread<CMemAligned<CMemProc> >::~CMemThread<CMemAligned<CMemProc> >
; sqldk.dll, primary RVA 0xc60a0, 121 bytes in 1 chunk(s)

; chunk at RVA 0xc60a0 (121 bytes)
000c60a0  48894c2408               mov qword ptr [rsp + 8], rcx
000c60a5  53                       push rbx
000c60a6  4883ec30                 sub rsp, 0x30
000c60aa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000c60b3  488bd9                   mov rbx, rcx
000c60b6  488d0573911800           lea rax, [rip + 0x189173]
000c60bd  488901                   mov qword ptr [rcx], rax
000c60c0  488d81a8000000           lea rax, [rcx + 0xa8]
000c60c7  4889442448               mov qword ptr [rsp + 0x48], rax
000c60cc  488d0d6d3a1700           lea rcx, [rip + 0x173a6d]
000c60d3  48894830                 mov qword ptr [rax + 0x30], rcx
000c60d7  488908                   mov qword ptr [rax], rcx
000c60da  488d05f78f1800           lea rax, [rip + 0x188ff7]
000c60e1  488903                   mov qword ptr [rbx], rax
000c60e4  488d056d121800           lea rax, [rip + 0x18126d]
000c60eb  488903                   mov qword ptr [rbx], rax
000c60ee  488d0513111800           lea rax, [rip + 0x181113]
000c60f5  488903                   mov qword ptr [rbx], rax
000c60f8  488d4b38                 lea rcx, [rbx + 0x38]
000c60fc  e8efb4f4ff               call 0x115f0
000c6101  90                       nop
000c6102  488d4b30                 lea rcx, [rbx + 0x30]
000c6106  e8e5b4f4ff               call 0x115f0
000c610b  90                       nop
000c610c  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
000c6113  4883c430                 add rsp, 0x30
000c6117  5b                       pop rbx
000c6118  c3                       ret
