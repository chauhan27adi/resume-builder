; DescriptorAllocator<SOS_MemoryFreeBlock,0>::InstallNewPageAsActive
; sqldk.dll, primary RVA 0x29020, 460 bytes in 1 chunk(s)

; chunk at RVA 0x29020 (460 bytes)
00029020  4889542410               mov qword ptr [rsp + 0x10], rdx
00029025  53                       push rbx
00029026  55                       push rbp
00029027  56                       push rsi
00029028  57                       push rdi
00029029  4154                     push r12
0002902b  4155                     push r13
0002902d  4156                     push r14
0002902f  4157                     push r15
00029031  4883ec68                 sub rsp, 0x68
00029035  48c7442440feffffff       mov qword ptr [rsp + 0x40], 0xfffffffffffffffe
0002903e  450fb7e1                 movzx r12d, r9w
00029042  4c8be9                   mov r13, rcx
00029045  6644898c24c8000000       mov word ptr [rsp + 0xc8], r9w
0002904e  410fb7e9                 movzx ebp, r9w
00029052  0fb689cc040000           movzx ecx, byte ptr [rcx + 0x4cc]
00029059  418bc0                   mov eax, r8d
0002905c  48d3e0                   shl rax, cl
0002905f  490385c0040000           add rax, qword ptr [r13 + 0x4c0]
00029066  48898424b0000000         mov qword ptr [rsp + 0xb0], rax
0002906e  4533c0                   xor r8d, r8d
00029071  44388424d0000000         cmp byte ptr [rsp + 0xd0], r8b
00029079  7517                     jne 0x29092
0002907b  418d442401               lea eax, [r12 + 1]
00029080  898424c8000000           mov dword ptr [rsp + 0xc8], eax
00029087  66413b4508               cmp ax, word ptr [r13 + 8]
0002908c  0f84a4010000             je 0x29236
00029092  4c8d0dc76b2f00           lea r9, [rip + 0x2f6bc7]
00029099  4c8bb424d8000000         mov r14, qword ptr [rsp + 0xd8]
000290a1  0f1f4000                 nop dword ptr [rax]
000290a5  6666660f1f840000000000   nop word ptr [rax + rax]
000290b0  440fb7fd                 movzx r15d, bp
000290b4  4b8d3c7f                 lea rdi, [r15 + r15*2]
000290b8  48c1e706                 shl rdi, 6
000290bc  4903fd                   add rdi, r13
000290bf  488b8f58050000           mov rcx, qword ptr [rdi + 0x558]
000290c6  483b8f60050000           cmp rcx, qword ptr [rdi + 0x560]
000290cd  400f92c6                 setb sil
000290d1  0f8308010000             jae 0x291df
000290d7  488d8768050000           lea rax, [rdi + 0x568]
000290de  b901000000               mov ecx, 1
000290e3  8708                     xchg dword ptr [rax], ecx
000290e5  898c24d0000000           mov dword ptr [rsp + 0xd0], ecx
000290ec  85c9                     test ecx, ecx
000290ee  7441                     je 0x29131
000290f0  8d4501                   lea eax, [rbp + 1]
000290f3  418be8                   mov ebp, r8d
000290f6  66413b4508               cmp ax, word ptr [r13 + 8]
000290fb  660f45e8                 cmovne bp, ax
000290ff  4084f6                   test sil, sil
00029102  0f84ae200700             je 0x9b1b6
00029108  85c9                     test ecx, ecx
0002910a  7410                     je 0x2911c
0002910c  488b8f78050000           mov rcx, qword ptr [rdi + 0x578]
00029113  4885c9                   test rcx, rcx
00029116  0f8538050000             jne 0x29654
0002911c  400fb6c6                 movzx eax, sil
00029120  4883c468                 add rsp, 0x68
00029124  415f                     pop r15
00029126  415e                     pop r14
00029128  415d                     pop r13
0002912a  415c                     pop r12
0002912c  5f                       pop rdi
0002912d  5e                       pop rsi
0002912e  5d                       pop rbp
0002912f  5b                       pop rbx
00029130  c3                       ret
00029131  4889442438               mov qword ptr [rsp + 0x38], rax
00029136  488b9758050000           mov rdx, qword ptr [rdi + 0x558]
0002913d  483b9760050000           cmp rdx, qword ptr [rdi + 0x560]
00029144  400f92c6                 setb sil
00029148  0f838e000000             jae 0x291dc
0002914e  4d85f6                   test r14, r14
00029151  0f8551010000             jne 0x292a8
00029157  498b9d58040000           mov rbx, qword ptr [r13 + 0x458]
0002915e  4885db                   test rbx, rbx
00029161  0f84af010000             je 0x29316
00029167  4c89442420               mov qword ptr [rsp + 0x20], r8
0002916c  4d8bce                   mov r9, r14
0002916f  440fb7c5                 movzx r8d, bp
00029173  410fb7d4                 movzx edx, r12w
00029177  488bcb                   mov rcx, rbx
0002917a  e861fcffff               call 0x28de0
0002917f  488bd0                   mov rdx, rax
00029182  4885c0                   test rax, rax
00029185  0f8481010000             je 0x2930c
0002918b  c7403000000000           mov dword ptr [rax + 0x30], 0
00029192  4c8b8424b8000000         mov r8, qword ptr [rsp + 0xb8]
0002919a  498bc0                   mov rax, r8
0002919d  488b8c24b0000000         mov rcx, qword ptr [rsp + 0xb0]
000291a5  f0480fb15108             lock cmpxchg qword ptr [rcx + 8], rdx
000291ab  0f8581040000             jne 0x29632
000291b1  498bd0                   mov rdx, r8
000291b4  498bcd                   mov rcx, r13
000291b7  e844000000               call 0x29200
000291bc  48ff8758050000           inc qword ptr [rdi + 0x558]
000291c3  4533c0                   xor r8d, r8d
000291c6  eb01                     jmp 0x291c9
000291c8  cc                       int3
000291c9  4c898778050000           mov qword ptr [rdi + 0x578], r8
000291d0  488b442438               mov rax, qword ptr [rsp + 0x38]
000291d5  4c8d0d846a2f00           lea r9, [rip + 0x2f6a84]
000291dc  448900                   mov dword ptr [rax], r8d
000291df  8b8c24d0000000           mov ecx, dword ptr [rsp + 0xd0]
000291e6  e905ffffff               jmp 0x290f0
000291eb  cc                       int3
