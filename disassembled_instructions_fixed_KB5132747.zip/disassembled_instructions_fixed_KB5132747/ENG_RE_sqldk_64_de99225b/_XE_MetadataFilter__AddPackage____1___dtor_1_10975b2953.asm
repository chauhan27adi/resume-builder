; `XE_MetadataFilter::AddPackage'::`1'::dtor$1
; sqldk.dll, primary RVA 0x2163d4, 34 bytes in 1 chunk(s)

; chunk at RVA 0x2163d4 (34 bytes)
002163d4  4055                     push rbp
002163d6  4883ec20                 sub rsp, 0x20
002163da  488bea                   mov rbp, rdx
002163dd  4533c0                   xor r8d, r8d
002163e0  488b95c0000000           mov rdx, qword ptr [rbp + 0xc0]
002163e7  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
002163eb  e820acdeff               call 0x1010
002163f0  4883c420                 add rsp, 0x20
002163f4  5d                       pop rbp
002163f5  c3                       ret
