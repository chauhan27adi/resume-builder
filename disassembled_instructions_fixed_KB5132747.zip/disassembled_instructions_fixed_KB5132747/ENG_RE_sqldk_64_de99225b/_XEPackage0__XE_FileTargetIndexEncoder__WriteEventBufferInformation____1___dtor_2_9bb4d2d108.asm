; `XEPackage0::XE_FileTargetIndexEncoder::WriteEventBufferInformation'::`1'::dtor$2
; sqldk.dll, primary RVA 0x22fd40, 45 bytes in 1 chunk(s)

; chunk at RVA 0x22fd40 (45 bytes)
0022fd40  4055                     push rbp
0022fd42  4883ec20                 sub rsp, 0x20
0022fd46  488bea                   mov rbp, rdx
0022fd49  488d8d00010000           lea rcx, [rbp + 0x100]
0022fd50  4c8d0d99bdf8ff           lea r9, [rip - 0x74267]
0022fd57  41b800040000             mov r8d, 0x400
0022fd5d  ba10000000               mov edx, 0x10
0022fd62  e8b94adfff               call 0x24820
0022fd67  4883c420                 add rsp, 0x20
0022fd6b  5d                       pop rbp
0022fd6c  c3                       ret
