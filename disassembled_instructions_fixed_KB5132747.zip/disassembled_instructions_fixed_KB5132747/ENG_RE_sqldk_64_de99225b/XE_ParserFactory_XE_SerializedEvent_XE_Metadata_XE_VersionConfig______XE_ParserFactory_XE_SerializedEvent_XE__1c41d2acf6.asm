; XE_ParserFactory<XE_SerializedEvent<XE_Metadata,XE_VersionConfig> >::~XE_ParserFactory<XE_SerializedEvent<XE_Metadata,XE_VersionConfig> >
; sqldk.dll, primary RVA 0x1c6620, 37 bytes in 1 chunk(s)

; chunk at RVA 0x1c6620 (37 bytes)
001c6620  48894c2408               mov qword ptr [rsp + 8], rcx
001c6625  4883ec18                 sub rsp, 0x18
001c6629  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
001c6631  48894c2428               mov qword ptr [rsp + 0x28], rcx
001c6636  488d054b4b0b00           lea rax, [rip + 0xb4b4b]
001c663d  488901                   mov qword ptr [rcx], rax
001c6640  4883c418                 add rsp, 0x18
001c6644  c3                       ret
