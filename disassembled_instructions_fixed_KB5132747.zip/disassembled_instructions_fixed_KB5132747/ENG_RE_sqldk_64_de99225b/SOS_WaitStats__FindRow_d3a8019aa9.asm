; SOS_WaitStats::FindRow
; sqldk.dll, primary RVA 0x1a820, 239 bytes in 7 chunk(s)

; chunk at RVA 0x1a820 (6 bytes)
0001a820  4057                     push rdi
0001a822  4883ec50                 sub rsp, 0x50

; chunk at RVA 0x1a826 (34 bytes)
0001a826  48896c2448               mov qword ptr [rsp + 0x48], rbp
0001a82b  8bfa                     mov edi, edx
0001a82d  8bea                     mov ebp, edx
0001a82f  4c897c2420               mov qword ptr [rsp + 0x20], r15
0001a834  83e50f                   and ebp, 0xf
0001a837  4c8bf9                   mov r15, rcx
0001a83a  83791000                 cmp dword ptr [rcx + 0x10], 0
0001a83e  745a                     je 0x1a89a
0001a840  658b042548000000         mov eax, dword ptr gs:[0x48]

; chunk at RVA 0x1a848 (62 bytes)
0001a848  48895c2468               mov qword ptr [rsp + 0x68], rbx
0001a84d  4c89642438               mov qword ptr [rsp + 0x38], r12
0001a852  4c896c2430               mov qword ptr [rsp + 0x30], r13
0001a857  4533ed                   xor r13d, r13d
0001a85a  448be0                   mov r12d, eax
0001a85d  418bdd                   mov ebx, r13d
0001a860  8b4118                   mov eax, dword ptr [rcx + 0x18]
0001a863  4c89742428               mov qword ptr [rsp + 0x28], r14
0001a868  85c0                     test eax, eax
0001a86a  0f854b5f0100             jne 0x307bb
0001a870  33c0                     xor eax, eax
0001a872  f04c0fb16118             lock cmpxchg qword ptr [rcx + 0x18], r12
0001a878  418bc5                   mov eax, r13d
0001a87b  0f94c0                   sete al
0001a87e  85c0                     test eax, eax
0001a880  0f84355f0100             je 0x307bb

; chunk at RVA 0x1a886 (20 bytes)
0001a886  4c8b642438               mov r12, qword ptr [rsp + 0x38]
0001a88b  4c8b6c2430               mov r13, qword ptr [rsp + 0x30]
0001a890  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0001a895  4c8b742428               mov r14, qword ptr [rsp + 0x28]

; chunk at RVA 0x1a89a (25 bytes)
0001a89a  498b44ef20               mov rax, qword ptr [r15 + rbp*8 + 0x20]
0001a89f  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
0001a8a4  488b6c2448               mov rbp, qword ptr [rsp + 0x48]
0001a8a9  4885c0                   test rax, rax
0001a8ac  7426                     je 0x1a8d4
0001a8ae  660f1f0400               nop word ptr [rax + rax]

; chunk at RVA 0x1a8c0 (25 bytes)
0001a8c0  397820                   cmp dword ptr [rax + 0x20], edi
0001a8c3  7506                     jne 0x1a8cb
0001a8c5  4883c450                 add rsp, 0x50
0001a8c9  5f                       pop rdi
0001a8ca  c3                       ret
0001a8cb  488b4028                 mov rax, qword ptr [rax + 0x28]
0001a8cf  4885c0                   test rax, rax
0001a8d2  75ec                     jne 0x1a8c0
0001a8d4  33c0                     xor eax, eax
0001a8d6  ebed                     jmp 0x1a8c5
0001a8d8  cc                       int3

; chunk at RVA 0x307c6 (67 bytes)
000307c6  4889742440               mov qword ptr [rsp + 0x40], rsi
000307cb  498bf5                   mov rsi, r13
000307ce  3c84                     cmp al, 0x84
000307d0  0f84b1d11700             je 0x1ad987
000307d6  f605fa422e0080           test byte ptr [rip + 0x2e42fa], 0x80
000307dd  498d4f18                 lea rcx, [r15 + 0x18]
000307e1  0f84ffd11700             je 0x1ad9e6
000307e7  4d8bc4                   mov r8, r12
000307ea  488bd6                   mov rdx, rsi
000307ed  e81e000000               call 0x30810
000307f2  eb01                     jmp 0x307f5
000307f4  cc                       int3
000307f5  4885f6                   test rsi, rsi
000307f8  0f85f7d11700             jne 0x1ad9f5
000307fe  488b742440               mov rsi, qword ptr [rsp + 0x40]
00030803  e97ea0feff               jmp 0x1a886
00030808  cc                       int3
