; MemObjCache<CMemLargePageObj>::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13ea40, 131 bytes in 1 chunk(s)

; chunk at RVA 0x13ea40 (131 bytes)
0013ea40  48894c2408               mov qword ptr [rsp + 8], rcx
0013ea45  57                       push rdi
0013ea46  4883ec30                 sub rsp, 0x30
0013ea4a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013ea53  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013ea58  8bda                     mov ebx, edx
0013ea5a  488bf9                   mov rdi, rcx
0013ea5d  488d05c49d1000           lea rax, [rip + 0x109dc4]
0013ea64  488901                   mov qword ptr [rcx], rax
0013ea67  488d05aa831000           lea rax, [rip + 0x1083aa]
0013ea6e  488901                   mov qword ptr [rcx], rax
0013ea71  488d05f0841000           lea rax, [rip + 0x1084f0]
0013ea78  488901                   mov qword ptr [rcx], rax
0013ea7b  488d0586871000           lea rax, [rip + 0x108786]
0013ea82  488901                   mov qword ptr [rcx], rax
0013ea85  4883c138                 add rcx, 0x38
0013ea89  e8622bedff               call 0x115f0
0013ea8e  90                       nop
0013ea8f  488d4f30                 lea rcx, [rdi + 0x30]
0013ea93  e8582bedff               call 0x115f0
0013ea98  90                       nop
0013ea99  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013eaa0  83e305                   and ebx, 5
0013eaa3  80fb05                   cmp bl, 5
0013eaa6  750d                     jne 0x13eab5
0013eaa8  ba18020000               mov edx, 0x218
0013eaad  488bcf                   mov rcx, rdi
0013eab0  e85b25ecff               call 0x1010
0013eab5  488bc7                   mov rax, rdi
0013eab8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013eabd  4883c430                 add rsp, 0x30
0013eac1  5f                       pop rdi
0013eac2  c3                       ret
