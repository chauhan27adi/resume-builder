; `PackageEntry::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x216f30, 38 bytes in 1 chunk(s)

; chunk at RVA 0x216f30 (38 bytes)
00216f30  4055                     push rbp
00216f32  4883ec20                 sub rsp, 0x20
00216f36  488bea                   mov rbp, rdx
00216f39  4c8b8590000000           mov r8, qword ptr [rbp + 0x90]
00216f40  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00216f47  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00216f4b  e8c0a0deff               call 0x1010
00216f50  4883c420                 add rsp, 0x20
00216f54  5d                       pop rbp
00216f55  c3                       ret
