; `XEPackage0::HistoryTarget::GetSerializedState'::`1'::dtor$3
; sqldk.dll, primary RVA 0x232791, 31 bytes in 1 chunk(s)

; chunk at RVA 0x232791 (31 bytes)
00232791  4055                     push rbp
00232793  4883ec20                 sub rsp, 0x20
00232797  488bea                   mov rbp, rdx
0023279a  4533c0                   xor r8d, r8d
0023279d  488b5568                 mov rdx, qword ptr [rbp + 0x68]
002327a1  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
002327a5  e866e8dcff               call 0x1010
002327aa  4883c420                 add rsp, 0x20
002327ae  5d                       pop rbp
002327af  c3                       ret
