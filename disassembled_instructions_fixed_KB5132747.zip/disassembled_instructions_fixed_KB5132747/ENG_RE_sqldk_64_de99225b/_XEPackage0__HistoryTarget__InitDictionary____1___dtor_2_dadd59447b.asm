; `XEPackage0::HistoryTarget::InitDictionary'::`1'::dtor$2
; sqldk.dll, primary RVA 0x23299b, 45 bytes in 1 chunk(s)

; chunk at RVA 0x23299b (45 bytes)
0023299b  4055                     push rbp
0023299d  4883ec20                 sub rsp, 0x20
002329a1  488bea                   mov rbp, rdx
002329a4  4c8b85f0000000           mov r8, qword ptr [rbp + 0xf0]
002329ab  4981c030200000           add r8, 0x2030
002329b2  4d8b00                   mov r8, qword ptr [r8]
002329b5  488b5568                 mov rdx, qword ptr [rbp + 0x68]
002329b9  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
002329bd  e84ee6dcff               call 0x1010
002329c2  4883c420                 add rsp, 0x20
002329c6  5d                       pop rbp
002329c7  c3                       ret
