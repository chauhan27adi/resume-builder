; `SOS_OS::DefaultCreateTraceBuffRoutine'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21cf10, 53 bytes in 1 chunk(s)

; chunk at RVA 0x21cf10 (53 bytes)
0021cf10  4055                     push rbp
0021cf12  4883ec30                 sub rsp, 0x30
0021cf16  488bea                   mov rbp, rdx
0021cf19  c644242806               mov byte ptr [rsp + 0x28], 6
0021cf1e  8b4558                   mov eax, dword ptr [rbp + 0x58]
0021cf21  89442420                 mov dword ptr [rsp + 0x20], eax
0021cf25  4c8d0d24c20700           lea r9, [rip + 0x7c224]
0021cf2c  41b801000000             mov r8d, 1
0021cf32  488b5550                 mov rdx, qword ptr [rbp + 0x50]
0021cf36  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0021cf3a  e8d19fdeff               call 0x6f10
0021cf3f  4883c430                 add rsp, 0x30
0021cf43  5d                       pop rbp
0021cf44  c3                       ret
