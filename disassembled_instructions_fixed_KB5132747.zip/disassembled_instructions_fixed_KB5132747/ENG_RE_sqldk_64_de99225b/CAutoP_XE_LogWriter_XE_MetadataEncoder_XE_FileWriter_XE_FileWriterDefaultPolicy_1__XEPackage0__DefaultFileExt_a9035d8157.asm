; CAutoP<XE_LogWriter<XE_MetadataEncoder<XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker> > > >::~CAutoP<XE_LogWriter<XE_MetadataEncoder<XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker> > > >
; sqldk.dll, primary RVA 0x1be240, 66 bytes in 1 chunk(s)

; chunk at RVA 0x1be240 (66 bytes)
001be240  4053                     push rbx
001be242  4883ec30                 sub rsp, 0x30
001be246  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001be24f  488b19                   mov rbx, qword ptr [rcx]
001be252  48895c2440               mov qword ptr [rsp + 0x40], rbx
001be257  4885db                   test rbx, rbx
001be25a  7420                     je 0x1be27c
001be25c  488d4b08                 lea rcx, [rbx + 8]
001be260  48894c2440               mov qword ptr [rsp + 0x40], rcx
001be265  e8a6000000               call 0x1be310
001be26a  bac0070000               mov edx, 0x7c0
001be26f  488bcb                   mov rcx, rbx
001be272  4883c430                 add rsp, 0x30
001be276  5b                       pop rbx
001be277  e9b48ce4ff               jmp 0x6f30
001be27c  4883c430                 add rsp, 0x30
001be280  5b                       pop rbx
001be281  c3                       ret
