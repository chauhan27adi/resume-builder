; `XE_StubSession::Create'::`1'::dtor$3
; sqldk.dll, primary RVA 0x23538b, 56 bytes in 1 chunk(s)

; chunk at RVA 0x23538b (56 bytes)
0023538b  4055                     push rbp
0023538d  4883ec30                 sub rsp, 0x30
00235391  488bea                   mov rbp, rdx
00235394  c644242806               mov byte ptr [rsp + 0x28], 6
00235399  8b4530                   mov eax, dword ptr [rbp + 0x30]
0023539c  89442420                 mov dword ptr [rsp + 0x20], eax
002353a0  4c8d0d61550700           lea r9, [rip + 0x75561]
002353a7  41b801000000             mov r8d, 1
002353ad  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
002353b4  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
002353b8  e8334bfaff               call 0x1d9ef0
002353bd  4883c430                 add rsp, 0x30
002353c1  5d                       pop rbp
002353c2  c3                       ret
