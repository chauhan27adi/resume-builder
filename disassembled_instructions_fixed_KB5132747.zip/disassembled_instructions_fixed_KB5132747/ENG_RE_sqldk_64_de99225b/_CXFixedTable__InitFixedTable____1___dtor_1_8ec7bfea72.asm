; `CXFixedTable::InitFixedTable'::`1'::dtor$1
; sqldk.dll, primary RVA 0x216cbb, 34 bytes in 1 chunk(s)

; chunk at RVA 0x216cbb (34 bytes)
00216cbb  4055                     push rbp
00216cbd  4883ec20                 sub rsp, 0x20
00216cc1  488bea                   mov rbp, rdx
00216cc4  4533c0                   xor r8d, r8d
00216cc7  488b5578                 mov rdx, qword ptr [rbp + 0x78]
00216ccb  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
00216cd2  e839a3deff               call 0x1010
00216cd7  4883c420                 add rsp, 0x20
00216cdb  5d                       pop rbp
00216cdc  c3                       ret
