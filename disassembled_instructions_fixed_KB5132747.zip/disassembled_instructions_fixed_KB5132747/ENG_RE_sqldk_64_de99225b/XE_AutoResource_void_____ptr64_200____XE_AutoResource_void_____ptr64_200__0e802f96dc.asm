; XE_AutoResource<void * __ptr64,200>::~XE_AutoResource<void * __ptr64,200>
; sqldk.dll, primary RVA 0x47880, 36 bytes in 1 chunk(s)

; chunk at RVA 0x47880 (36 bytes)
00047880  4053                     push rbx
00047882  4883ec20                 sub rsp, 0x20
00047886  488bd9                   mov rbx, rcx
00047889  488b09                   mov rcx, qword ptr [rcx]
0004788c  4885c9                   test rcx, rcx
0004788f  7406                     je 0x47897
00047891  ff1531d82c00             call qword ptr [rip + 0x2cd831]
00047897  48c70300000000           mov qword ptr [rbx], 0
0004789e  4883c420                 add rsp, 0x20
000478a2  5b                       pop rbx
000478a3  c3                       ret
