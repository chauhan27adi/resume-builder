; TEnumerator<TList<ClockInfoInternalList,ClockInfo,88,CacheStoreClockSLock> >::~TEnumerator<TList<ClockInfoInternalList,ClockInfo,88,CacheStoreClockSLock> >
; sqldk.dll, primary RVA 0x164700, 177 bytes in 1 chunk(s)

; chunk at RVA 0x164700 (177 bytes)
00164700  48895c2410               mov qword ptr [rsp + 0x10], rbx
00164705  48896c2418               mov qword ptr [rsp + 0x18], rbp
0016470a  4889742420               mov qword ptr [rsp + 0x20], rsi
0016470f  57                       push rdi
00164710  4883ec20                 sub rsp, 0x20
00164714  488b39                   mov rdi, qword ptr [rcx]
00164717  33ed                     xor ebp, ebp
00164719  488bd9                   mov rbx, rcx
0016471c  beffffffff               mov esi, 0xffffffff
00164721  4885ff                   test rdi, rdi
00164724  7429                     je 0x16474f
00164726  8bc6                     mov eax, esi
00164728  f00fc14770               lock xadd dword ptr [rdi + 0x70], eax
0016472d  83f801                   cmp eax, 1
00164730  751a                     jne 0x16474c
00164732  48396f60                 cmp qword ptr [rdi + 0x60], rbp
00164736  740c                     je 0x164744
00164738  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
0016473c  488bd7                   mov rdx, rdi
0016473f  e88c69ecff               call 0x2b0d0
00164744  488b07                   mov rax, qword ptr [rdi]
00164747  488bcf                   mov rcx, rdi
0016474a  ff10                     call qword ptr [rax]
0016474c  48892b                   mov qword ptr [rbx], rbp
0016474f  488b7b08                 mov rdi, qword ptr [rbx + 8]
00164753  4885ff                   test rdi, rdi
00164756  7428                     je 0x164780
00164758  f00fc17770               lock xadd dword ptr [rdi + 0x70], esi
0016475d  83fe01                   cmp esi, 1
00164760  751a                     jne 0x16477c
00164762  48396f60                 cmp qword ptr [rdi + 0x60], rbp
00164766  740c                     je 0x164774
00164768  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
0016476c  488bd7                   mov rdx, rdi
0016476f  e85c69ecff               call 0x2b0d0
00164774  488b07                   mov rax, qword ptr [rdi]
00164777  488bcf                   mov rcx, rdi
0016477a  ff10                     call qword ptr [rax]
0016477c  48896b08                 mov qword ptr [rbx + 8], rbp
00164780  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
00164784  4885c9                   test rcx, rcx
00164787  740f                     je 0x164798
00164789  8b5320                   mov edx, dword ptr [rbx + 0x20]
0016478c  e86f14eaff               call 0x5c00
00164791  48896b18                 mov qword ptr [rbx + 0x18], rbp
00164795  896b20                   mov dword ptr [rbx + 0x20], ebp
00164798  488b742448               mov rsi, qword ptr [rsp + 0x48]
0016479d  48896b10                 mov qword ptr [rbx + 0x10], rbp
001647a1  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
001647a6  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
001647ab  4883c420                 add rsp, 0x20
001647af  5f                       pop rdi
001647b0  c3                       ret
