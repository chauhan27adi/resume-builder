; `XE_ModuleManager::RegisterPackage'::`1'::dtor$4
; sqldk.dll, primary RVA 0x235840, 59 bytes in 1 chunk(s)

; chunk at RVA 0x235840 (59 bytes)
00235840  4055                     push rbp
00235842  4883ec30                 sub rsp, 0x30
00235846  488bea                   mov rbp, rdx
00235849  c644242806               mov byte ptr [rsp + 0x28], 6
0023584e  8b4530                   mov eax, dword ptr [rbp + 0x30]
00235851  89442420                 mov dword ptr [rsp + 0x20], eax
00235855  4c8d0de4500700           lea r9, [rip + 0x750e4]
0023585c  41b801000000             mov r8d, 1
00235862  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
00235869  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
00235870  e87b46faff               call 0x1d9ef0
00235875  4883c430                 add rsp, 0x30
00235879  5d                       pop rbp
0023587a  c3                       ret
