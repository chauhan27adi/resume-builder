; CAutoP<SEHashTable<XE_XMLObjectString,XE_XMLObjectString,0,0,XE_BaseAllocator> >::~CAutoP<SEHashTable<XE_XMLObjectString,XE_XMLObjectString,0,0,XE_BaseAllocator> >
; sqldk.dll, primary RVA 0x1c7590, 60 bytes in 1 chunk(s)

; chunk at RVA 0x1c7590 (60 bytes)
001c7590  4053                     push rbx
001c7592  4883ec20                 sub rsp, 0x20
001c7596  488b19                   mov rbx, qword ptr [rcx]
001c7599  4885db                   test rbx, rbx
001c759c  7428                     je 0x1c75c6
001c759e  488b0b                   mov rcx, qword ptr [rbx]
001c75a1  4885c9                   test rcx, rcx
001c75a4  740e                     je 0x1c75b4
001c75a6  ff15a4da1400             call qword ptr [rip + 0x14daa4]
001c75ac  33c0                     xor eax, eax
001c75ae  488903                   mov qword ptr [rbx], rax
001c75b1  894308                   mov dword ptr [rbx + 8], eax
001c75b4  ba20000000               mov edx, 0x20
001c75b9  488bcb                   mov rcx, rbx
001c75bc  4883c420                 add rsp, 0x20
001c75c0  5b                       pop rbx
001c75c1  e96af9e3ff               jmp 0x6f30
001c75c6  4883c420                 add rsp, 0x20
001c75ca  5b                       pop rbx
001c75cb  c3                       ret
