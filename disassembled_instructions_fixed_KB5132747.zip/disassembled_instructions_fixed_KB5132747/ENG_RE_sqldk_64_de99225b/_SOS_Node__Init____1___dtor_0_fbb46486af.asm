; `SOS_Node::Init'::`1'::dtor$0
; sqldk.dll, primary RVA 0x218a40, 63 bytes in 1 chunk(s)

; chunk at RVA 0x218a40 (63 bytes)
00218a40  4055                     push rbp
00218a42  4883ec30                 sub rsp, 0x30
00218a46  488bea                   mov rbp, rdx
00218a49  488b5548                 mov rdx, qword ptr [rbp + 0x48]
00218a4d  4881c240010000           add rdx, 0x140
00218a54  c644242806               mov byte ptr [rsp + 0x28], 6
00218a59  8b4530                   mov eax, dword ptr [rbp + 0x30]
00218a5c  89442420                 mov dword ptr [rsp + 0x20], eax
00218a60  4c8d0dc1ec0700           lea r9, [rip + 0x7ecc1]
00218a67  41b801000000             mov r8d, 1
00218a6d  488b12                   mov rdx, qword ptr [rdx]
00218a70  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00218a74  e897e4deff               call 0x6f10
00218a79  4883c430                 add rsp, 0x30
00218a7d  5d                       pop rbp
00218a7e  c3                       ret
