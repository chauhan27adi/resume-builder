; CMemAligned<CMemDbg<PageHeapMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xd0810, 76 bytes in 1 chunk(s)

; chunk at RVA 0xd0810 (76 bytes)
000d0810  48894c2408               mov qword ptr [rsp + 8], rcx
000d0815  57                       push rdi
000d0816  4883ec30                 sub rsp, 0x30
000d081a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d0823  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d0828  8bda                     mov ebx, edx
000d082a  488bf9                   mov rdi, rcx
000d082d  488d059ca91700           lea rax, [rip + 0x17a99c]
000d0834  488901                   mov qword ptr [rcx], rax
000d0837  e8c41b0a00               call 0x172400
000d083c  f6c301                   test bl, 1
000d083f  740d                     je 0xd084e
000d0841  ba58040000               mov edx, 0x458
000d0846  488bcf                   mov rcx, rdi
000d0849  e8e266f3ff               call 0x6f30
000d084e  488bc7                   mov rax, rdi
000d0851  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d0856  4883c430                 add rsp, 0x30
000d085a  5f                       pop rdi
000d085b  c3                       ret
