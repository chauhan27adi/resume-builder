; MemObjCache<CMemAligned<CMemProc> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13dc20, 131 bytes in 1 chunk(s)

; chunk at RVA 0x13dc20 (131 bytes)
0013dc20  48894c2408               mov qword ptr [rsp + 8], rcx
0013dc25  57                       push rdi
0013dc26  4883ec30                 sub rsp, 0x30
0013dc2a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013dc33  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013dc38  8bda                     mov ebx, edx
0013dc3a  488bf9                   mov rdi, rcx
0013dc3d  488d0524cc1000           lea rax, [rip + 0x10cc24]
0013dc44  488901                   mov qword ptr [rcx], rax
0013dc47  488d058a141100           lea rax, [rip + 0x11148a]
0013dc4e  488901                   mov qword ptr [rcx], rax
0013dc51  488d0500971000           lea rax, [rip + 0x109700]
0013dc58  488901                   mov qword ptr [rcx], rax
0013dc5b  488d05a6951000           lea rax, [rip + 0x1095a6]
0013dc62  488901                   mov qword ptr [rcx], rax
0013dc65  4883c138                 add rcx, 0x38
0013dc69  e88239edff               call 0x115f0
0013dc6e  90                       nop
0013dc6f  488d4f30                 lea rcx, [rdi + 0x30]
0013dc73  e87839edff               call 0x115f0
0013dc78  90                       nop
0013dc79  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013dc80  83e305                   and ebx, 5
0013dc83  80fb05                   cmp bl, 5
0013dc86  750d                     jne 0x13dc95
0013dc88  baf8000000               mov edx, 0xf8
0013dc8d  488bcf                   mov rcx, rdi
0013dc90  e87b33ecff               call 0x1010
0013dc95  488bc7                   mov rax, rdi
0013dc98  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013dc9d  4883c430                 add rsp, 0x30
0013dca1  5f                       pop rdi
0013dca2  c3                       ret
