; `TCacheStore<CacheProbabilisticAlgorithm>::Init'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22d340, 62 bytes in 1 chunk(s)

; chunk at RVA 0x22d340 (62 bytes)
0022d340  4055                     push rbp
0022d342  4883ec30                 sub rsp, 0x30
0022d346  488bea                   mov rbp, rdx
0022d349  c644242806               mov byte ptr [rsp + 0x28], 6
0022d34e  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0022d354  89442420                 mov dword ptr [rsp + 0x20], eax
0022d358  4c8d0d71cf0400           lea r9, [rip + 0x4cf71]
0022d35f  41b801000000             mov r8d, 1
0022d365  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
0022d36c  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
0022d373  e8989bddff               call 0x6f10
0022d378  4883c430                 add rsp, 0x30
0022d37c  5d                       pop rbp
0022d37d  c3                       ret
