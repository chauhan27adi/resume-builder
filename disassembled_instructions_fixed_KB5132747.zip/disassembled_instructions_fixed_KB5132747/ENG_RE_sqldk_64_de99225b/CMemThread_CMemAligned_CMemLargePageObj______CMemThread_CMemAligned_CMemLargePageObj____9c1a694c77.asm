; CMemThread<CMemAligned<CMemLargePageObj> >::~CMemThread<CMemAligned<CMemLargePageObj> >
; sqldk.dll, primary RVA 0x117a90, 63 bytes in 1 chunk(s)

; chunk at RVA 0x117a90 (63 bytes)
00117a90  48894c2408               mov qword ptr [rsp + 8], rcx
00117a95  4883ec38                 sub rsp, 0x38
00117a99  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00117aa2  488d052f101300           lea rax, [rip + 0x13102f]
00117aa9  488901                   mov qword ptr [rcx], rax
00117aac  488d81d0010000           lea rax, [rcx + 0x1d0]
00117ab3  4889442448               mov qword ptr [rsp + 0x48], rax
00117ab8  488d1581201200           lea rdx, [rip + 0x122081]
00117abf  48895030                 mov qword ptr [rax + 0x30], rdx
00117ac3  488910                   mov qword ptr [rax], rdx
00117ac6  4883c438                 add rsp, 0x38
00117aca  e9119dffff               jmp 0x1117e0
