; CMemAligned<CMemDbg<CMemObj> >::~CMemAligned<CMemDbg<CMemObj> >
; sqldk.dll, primary RVA 0x129190, 37 bytes in 1 chunk(s)

; chunk at RVA 0x129190 (37 bytes)
00129190  48894c2408               mov qword ptr [rsp + 8], rcx
00129195  4883ec38                 sub rsp, 0x38
00129199  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001291a2  488d0587251200           lea rax, [rip + 0x122587]
001291a9  488901                   mov qword ptr [rcx], rax
001291ac  4883c438                 add rsp, 0x38
001291b0  e91b540400               jmp 0x16e5d0
