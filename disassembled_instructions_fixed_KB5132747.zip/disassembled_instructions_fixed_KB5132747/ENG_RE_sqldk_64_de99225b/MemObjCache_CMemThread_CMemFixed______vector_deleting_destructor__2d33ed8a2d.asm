; MemObjCache<CMemThread<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e6b0, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13e6b0 (79 bytes)
0013e6b0  48894c2408               mov qword ptr [rsp + 8], rcx
0013e6b5  57                       push rdi
0013e6b6  4883ec30                 sub rsp, 0x30
0013e6ba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e6c3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e6c8  8bda                     mov ebx, edx
0013e6ca  488bf9                   mov rdi, rcx
0013e6cd  488d05b4a61000           lea rax, [rip + 0x10a6b4]
0013e6d4  488901                   mov qword ptr [rcx], rax
0013e6d7  e864dffbff               call 0xfc640
0013e6dc  83e305                   and ebx, 5
0013e6df  80fb05                   cmp bl, 5
0013e6e2  750d                     jne 0x13e6f1
0013e6e4  ba30020000               mov edx, 0x230
0013e6e9  488bcf                   mov rcx, rdi
0013e6ec  e81f29ecff               call 0x1010
0013e6f1  488bc7                   mov rax, rdi
0013e6f4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e6f9  4883c430                 add rsp, 0x30
0013e6fd  5f                       pop rdi
0013e6fe  c3                       ret
