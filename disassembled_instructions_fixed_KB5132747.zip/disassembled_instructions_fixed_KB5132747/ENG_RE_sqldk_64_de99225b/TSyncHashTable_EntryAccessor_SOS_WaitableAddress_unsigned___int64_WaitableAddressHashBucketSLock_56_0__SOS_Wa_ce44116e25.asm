; TSyncHashTable_EntryAccessor<SOS_WaitableAddress,unsigned __int64,WaitableAddressHashBucketSLock,56,0,&SOS_WaitableAddressManager::CookieHash>::~TSyncHashTable_EntryAccessor<SOS_WaitableAddress,unsigned __int64,WaitableAddressHashBucketSLock,56,0,&SOS_WaitableAddressManager::CookieHash>
; sqldk.dll, primary RVA 0xaefa0, 71 bytes in 1 chunk(s)

; chunk at RVA 0xaefa0 (71 bytes)
000aefa0  4053                     push rbx
000aefa2  4883ec20                 sub rsp, 0x20
000aefa6  803d1465260000           cmp byte ptr [rip + 0x266514], 0
000aefad  488b19                   mov rbx, qword ptr [rcx]
000aefb0  7427                     je 0xaefd9
000aefb2  ff1590aa1800             call qword ptr [rip + 0x18aa90]
000aefb8  448bc0                   mov r8d, eax
000aefbb  b867666666               mov eax, 0x66666667
000aefc0  41f7e8                   imul r8d
000aefc3  d1fa                     sar edx, 1
000aefc5  8bca                     mov ecx, edx
000aefc7  c1e91f                   shr ecx, 0x1f
000aefca  03d1                     add edx, ecx
000aefcc  8d0c92                   lea ecx, [rdx + rdx*4]
000aefcf  443bc1                   cmp r8d, ecx
000aefd2  7505                     jne 0xaefd9
000aefd4  e817030000               call 0xaf2f0
000aefd9  48c7431000000000         mov qword ptr [rbx + 0x10], 0
000aefe1  4883c420                 add rsp, 0x20
000aefe5  5b                       pop rbx
000aefe6  c3                       ret
