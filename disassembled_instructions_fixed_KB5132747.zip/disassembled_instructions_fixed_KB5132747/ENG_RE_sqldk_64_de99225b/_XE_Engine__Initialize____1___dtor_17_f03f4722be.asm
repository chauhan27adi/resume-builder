; `XE_Engine::Initialize'::`1'::dtor$17
; sqldk.dll, primary RVA 0x23401f, 53 bytes in 1 chunk(s)

; chunk at RVA 0x23401f (53 bytes)
0023401f  4055                     push rbp
00234021  4883ec30                 sub rsp, 0x30
00234025  488bea                   mov rbp, rdx
00234028  c644242806               mov byte ptr [rsp + 0x28], 6
0023402d  8b4530                   mov eax, dword ptr [rbp + 0x30]
00234030  89442420                 mov dword ptr [rsp + 0x20], eax
00234034  4c8d0d65670700           lea r9, [rip + 0x76765]
0023403b  41b801000000             mov r8d, 1
00234041  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00234045  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00234049  e8a25efaff               call 0x1d9ef0
0023404e  4883c430                 add rsp, 0x30
00234052  5d                       pop rbp
00234053  c3                       ret
