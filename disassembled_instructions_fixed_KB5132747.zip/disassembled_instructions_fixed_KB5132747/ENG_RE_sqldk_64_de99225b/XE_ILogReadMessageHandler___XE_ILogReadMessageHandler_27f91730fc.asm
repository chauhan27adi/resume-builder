; XE_ILogReadMessageHandler::~XE_ILogReadMessageHandler
; sqldk.dll, primary RVA 0x1bbc50, 32 bytes in 1 chunk(s)

; chunk at RVA 0x1bbc50 (32 bytes)
001bbc50  48894c2408               mov qword ptr [rsp + 8], rcx
001bbc55  4883ec18                 sub rsp, 0x18
001bbc59  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
001bbc61  488d05b88f0c00           lea rax, [rip + 0xc8fb8]
001bbc68  488901                   mov qword ptr [rcx], rax
001bbc6b  4883c418                 add rsp, 0x18
001bbc6f  c3                       ret
