; `XE_MetadataSerializer::SerializeAllToBuffer<XE_SessionMetadata const >'::`1'::dtor$0
; sqldk.dll, primary RVA 0x216ab0, 45 bytes in 1 chunk(s)

; chunk at RVA 0x216ab0 (45 bytes)
00216ab0  4055                     push rbp
00216ab2  4883ec20                 sub rsp, 0x20
00216ab6  488bea                   mov rbp, rdx
00216ab9  4c8d0d00b2e2ff           lea r9, [rip - 0x1d4e00]
00216ac0  41b800040000             mov r8d, 0x400
00216ac6  ba08000000               mov edx, 8
00216acb  488d8dc0000000           lea rcx, [rbp + 0xc0]
00216ad2  e849dde0ff               call 0x24820
00216ad7  4883c420                 add rsp, 0x20
00216adb  5d                       pop rbp
00216adc  c3                       ret
