; `XE_ModuleManager::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x235761, 62 bytes in 1 chunk(s)

; chunk at RVA 0x235761 (62 bytes)
00235761  4055                     push rbp
00235763  4883ec30                 sub rsp, 0x30
00235767  488bea                   mov rbp, rdx
0023576a  c644242806               mov byte ptr [rsp + 0x28], 6
0023576f  8b8588000000             mov eax, dword ptr [rbp + 0x88]
00235775  89442420                 mov dword ptr [rsp + 0x20], eax
00235779  4c8d0dc0510700           lea r9, [rip + 0x751c0]
00235780  41b801000000             mov r8d, 1
00235786  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0023578d  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
00235794  e85747faff               call 0x1d9ef0
00235799  4883c430                 add rsp, 0x30
0023579d  5d                       pop rbp
0023579e  c3                       ret
