; AutoMakeMicroSOSThread::FakeTaskFunc
; sqldk.dll, primary RVA 0x8c460, 53 bytes in 1 chunk(s)

; chunk at RVA 0x8c460 (53 bytes)
0008c460  4883ec38                 sub rsp, 0x38
0008c464  488d054dfd2100           lea rax, [rip + 0x21fd4d]
0008c46b  41b98e040000             mov r9d, 0x48e
0008c471  4c8d0508f62100           lea r8, [rip + 0x21f608]
0008c478  4889442420               mov qword ptr [rsp + 0x20], rax
0008c47d  488d15b8f82100           lea rdx, [rip + 0x21f8b8]
0008c484  b901000000               mov ecx, 1
0008c489  e862591200               call 0x1b1df0
0008c48e  33c0                     xor eax, eax
0008c490  4883c438                 add rsp, 0x38
0008c494  c3                       ret
