; CMemAligned<CMemDbg<CMemLargePageObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xd0690, 79 bytes in 1 chunk(s)

; chunk at RVA 0xd0690 (79 bytes)
000d0690  48894c2408               mov qword ptr [rsp + 8], rcx
000d0695  57                       push rdi
000d0696  4883ec30                 sub rsp, 0x30
000d069a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d06a3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d06a8  8bda                     mov ebx, edx
000d06aa  488bf9                   mov rdi, rcx
000d06ad  488d05ccad1700           lea rax, [rip + 0x17adcc]
000d06b4  488901                   mov qword ptr [rcx], rax
000d06b7  e884320a00               call 0x173940
000d06bc  83e305                   and ebx, 5
000d06bf  80fb05                   cmp bl, 5
000d06c2  750d                     jne 0xd06d1
000d06c4  baa0050000               mov edx, 0x5a0
000d06c9  488bcf                   mov rcx, rdi
000d06cc  e83f09f3ff               call 0x1010
000d06d1  488bc7                   mov rax, rdi
000d06d4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d06d9  4883c430                 add rsp, 0x30
000d06dd  5f                       pop rdi
000d06de  c3                       ret
