; XEPackage0::XE_LiveTarget::NotifyLogSetSizeError
; sqldk.dll, primary RVA 0x1d0ec0, 51 bytes in 1 chunk(s)

; chunk at RVA 0x1d0ec0 (51 bytes)
001d0ec0  4883ec38                 sub rsp, 0x38
001d0ec4  488d0505c30d00           lea rax, [rip + 0xdc305]
001d0ecb  41b961010000             mov r9d, 0x161
001d0ed1  4c8d0520ae0d00           lea r8, [rip + 0xdae20]
001d0ed8  4889442420               mov qword ptr [rsp + 0x20], rax
001d0edd  488d1558ae0d00           lea rdx, [rip + 0xdae58]
001d0ee4  b901000000               mov ecx, 1
001d0ee9  e8020ffeff               call 0x1b1df0
001d0eee  4883c438                 add rsp, 0x38
001d0ef2  c3                       ret
