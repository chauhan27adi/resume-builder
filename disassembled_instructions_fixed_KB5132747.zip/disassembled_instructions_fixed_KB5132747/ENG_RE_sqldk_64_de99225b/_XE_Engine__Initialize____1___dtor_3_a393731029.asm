; `XE_Engine::Initialize'::`1'::dtor$3
; sqldk.dll, primary RVA 0x234096, 56 bytes in 1 chunk(s)

; chunk at RVA 0x234096 (56 bytes)
00234096  4055                     push rbp
00234098  4883ec30                 sub rsp, 0x30
0023409c  488bea                   mov rbp, rdx
0023409f  c644242806               mov byte ptr [rsp + 0x28], 6
002340a4  8b4530                   mov eax, dword ptr [rbp + 0x30]
002340a7  89442420                 mov dword ptr [rsp + 0x20], eax
002340ab  4c8d0dee660700           lea r9, [rip + 0x766ee]
002340b2  41b801000000             mov r8d, 1
002340b8  488b1501e61700           mov rdx, qword ptr [rip + 0x17e601]
002340bf  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
002340c3  e8285efaff               call 0x1d9ef0
002340c8  4883c430                 add rsp, 0x30
002340cc  5d                       pop rbp
002340cd  c3                       ret
