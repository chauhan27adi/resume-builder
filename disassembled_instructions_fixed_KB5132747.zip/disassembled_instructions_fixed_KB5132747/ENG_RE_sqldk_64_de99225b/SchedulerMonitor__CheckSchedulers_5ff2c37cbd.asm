; SchedulerMonitor::CheckSchedulers
; sqldk.dll, primary RVA 0x18eb0, 1639 bytes in 1 chunk(s)

; chunk at RVA 0x18eb0 (1639 bytes)
00018eb0  488bc4                   mov rax, rsp
00018eb3  55                       push rbp
00018eb4  4154                     push r12
00018eb6  4155                     push r13
00018eb8  4156                     push r14
00018eba  4157                     push r15
00018ebc  488da8d8f6ffff           lea rbp, [rax - 0x928]
00018ec3  4881ec000a0000           sub rsp, 0xa00
00018eca  48c74578feffffff         mov qword ptr [rbp + 0x78], 0xfffffffffffffffe
00018ed2  48895810                 mov qword ptr [rax + 0x10], rbx
00018ed6  48897018                 mov qword ptr [rax + 0x18], rsi
00018eda  48897820                 mov qword ptr [rax + 0x20], rdi
00018ede  488b05a3812f00           mov rax, qword ptr [rip + 0x2f81a3]
00018ee5  4833c4                   xor rax, rsp
00018ee8  488985f0080000           mov qword ptr [rbp + 0x8f0], rax
00018eef  8bfa                     mov edi, edx
00018ef1  89542438                 mov dword ptr [rsp + 0x38], edx
00018ef5  4c8bf9                   mov r15, rcx
00018ef8  48894c2440               mov qword ptr [rsp + 0x40], rcx
00018efd  be01000000               mov esi, 1
00018f02  8bde                     mov ebx, esi
00018f04  895c2420                 mov dword ptr [rsp + 0x20], ebx
00018f08  4533f6                   xor r14d, r14d
00018f0b  4489742430               mov dword ptr [rsp + 0x30], r14d
00018f10  33d2                     xor edx, edx
00018f12  41b800010000             mov r8d, 0x100
00018f18  488d8df0070000           lea rcx, [rbp + 0x7f0]
00018f1f  e810b9feff               call 0x4834
00018f24  33d2                     xor edx, edx
00018f26  41b800010000             mov r8d, 0x100
00018f2c  488d8df0060000           lea rcx, [rbp + 0x6f0]
00018f33  e8fcb8feff               call 0x4834
00018f38  b9e8010000               mov ecx, 0x1e8
00018f3d  41b898010000             mov r8d, 0x198
00018f43  3bfe                     cmp edi, esi
00018f45  440f45c1                 cmovne r8d, ecx
00018f49  4d034718                 add r8, qword ptr [r15 + 0x18]
00018f4d  ba68010000               mov edx, 0x168
00018f52  b9b8010000               mov ecx, 0x1b8
00018f57  3bfe                     cmp edi, esi
00018f59  0f45d1                   cmovne edx, ecx
00018f5c  49035718                 add rdx, qword ptr [r15 + 0x18]
00018f60  448bce                   mov r9d, esi
00018f63  488d4d38                 lea rcx, [rbp + 0x38]
00018f67  e834f2ffff               call 0x181a0
00018f6c  90                       nop
00018f6d  458bee                   mov r13d, r14d
00018f70  448d66fe                 lea r12d, [rsi - 2]
00018f74  498bf6                   mov rsi, r14
00018f77  4d85ed                   test r13, r13
00018f7a  0f842cfbffff             je 0x18aac
00018f80  488b5d38                 mov rbx, qword ptr [rbp + 0x38]
00018f84  4885db                   test rbx, rbx
00018f87  0f84cb000000             je 0x19058
00018f8d  483b5d40                 cmp rbx, qword ptr [rbp + 0x40]
00018f91  0f843b030000             je 0x192d2
00018f97  4c8b7548                 mov r14, qword ptr [rbp + 0x48]
00018f9b  4d8d7e10                 lea r15, [r14 + 0x10]
00018f9f  33d2                     xor edx, edx
00018fa1  8bda                     mov ebx, edx
00018fa3  658b042548000000         mov eax, dword ptr gs:[0x48]
00018fab  8bf0                     mov esi, eax
00018fad  418b07                   mov eax, dword ptr [r15]
00018fb0  85c0                     test eax, eax
00018fb2  0f8526361700             jne 0x18c5de
00018fb8  33c0                     xor eax, eax
00018fba  f0490fb137               lock cmpxchg qword ptr [r15], rsi
00018fbf  8bc2                     mov eax, edx
00018fc1  0f94c0                   sete al
00018fc4  85c0                     test eax, eax
00018fc6  0f8412361700             je 0x18c5de
00018fcc  498b4d18                 mov rcx, qword ptr [r13 + 0x18]
00018fd0  493bce                   cmp rcx, r14
00018fd3  0f84e1361700             je 0x18c6ba
00018fd9  488d41f0                 lea rax, [rcx - 0x10]
00018fdd  488bf2                   mov rsi, rdx
00018fe0  4885c9                   test rcx, rcx
00018fe3  480f45f0                 cmovne rsi, rax
00018fe7  4885f6                   test rsi, rsi
00018fea  743e                     je 0x1902a
00018fec  660f1f0400               nop word ptr [rax + rax]
00018ff1  0f1f4000                 nop dword ptr [rax]
00018ff5  6666660f1f840000000000   nop word ptr [rax + rax]
00019000  8b4e28                   mov ecx, dword ptr [rsi + 0x28]
00019003  85c9                     test ecx, ecx
00019005  0f84cd361700             je 0x18c6d8
0001900b  660f1f0400               nop word ptr [rax + rax]
00019010  8d5101                   lea edx, [rcx + 1]
00019013  8bc1                     mov eax, ecx
00019015  f00fb15628               lock cmpxchg dword ptr [rsi + 0x28], edx
0001901a  3bc8                     cmp ecx, eax
0001901c  0f85a4361700             jne 0x18c6c6
00019022  85d2                     test edx, edx
00019024  0f84ac361700             je 0x18c6d6
0001902a  4533f6                   xor r14d, r14d
0001902d  803d8dc42f0000           cmp byte ptr [rip + 0x2fc48d], 0
00019034  0f85c4361700             jne 0x18c6fe
0001903a  4d8937                   mov qword ptr [r15], r14
0001903d  48897538                 mov qword ptr [rbp + 0x38], rsi
00019041  418bc4                   mov eax, r12d
00019044  f0410fc14528             lock xadd dword ptr [r13 + 0x28], eax
0001904a  83f801                   cmp eax, 1
0001904d  0f84dd361700             je 0x18c730
00019053  4c8b7c2440               mov r15, qword ptr [rsp + 0x40]
00019058  8b5c2420                 mov ebx, dword ptr [rsp + 0x20]
0001905c  4c8bee                   mov r13, rsi
0001905f  4889742470               mov qword ptr [rsp + 0x70], rsi
00019064  4885f6                   test rsi, rsi
00019067  0f8496020000             je 0x19303
0001906d  c744243001000000         mov dword ptr [rsp + 0x30], 1
00019075  4c8bc6                   mov r8, rsi
00019078  8bd7                     mov edx, edi
0001907a  498bcf                   mov rcx, r15
0001907d  e87efaffff               call 0x18b00
00019082  85db                     test ebx, ebx
00019084  0f852cfaffff             jne 0x18ab6
0001908a  418bde                   mov ebx, r14d
0001908d  895c2420                 mov dword ptr [rsp + 0x20], ebx
00019091  83ff01                   cmp edi, 1
00019094  0f85dafeffff             jne 0x18f74
0001909a  0f57c0                   xorps xmm0, xmm0
0001909d  f30f7f442478             movdqu xmmword ptr [rsp + 0x78], xmm0
000190a3  4533ed                   xor r13d, r13d
000190a6  4c896d90                 mov qword ptr [rbp - 0x70], r13
000190aa  44896d98                 mov dword ptr [rbp - 0x68], r13d
000190ae  4c896d88                 mov qword ptr [rbp - 0x78], r13
000190b2  488d1d2ffd2f00           lea rbx, [rip + 0x2ffd2f]
000190b9  48895d88                 mov qword ptr [rbp - 0x78], rbx
000190bd  488bcb                   mov rcx, rbx
000190c0  e87bf8ffff               call 0x18940
000190c5  4889442478               mov qword ptr [rsp + 0x78], rax
000190ca  488bcb                   mov rcx, rbx
000190cd  e82ef9ffff               call 0x18a00
000190d2  48894580                 mov qword ptr [rbp - 0x80], rax
000190d6  458bfd                   mov r15d, r13d
000190d9  0f1f8000000000           nop dword ptr [rax]
000190e0  498bdd                   mov rbx, r13
000190e3  4d85ff                   test r15, r15
000190e6  0f84ddf9ffff             je 0x18ac9
000190ec  488b4c2478               mov rcx, qword ptr [rsp + 0x78]
000190f1  4885c9                   test rcx, rcx
000190f4  0f84ab000000             je 0x191a5
000190fa  483b4d80                 cmp rcx, qword ptr [rbp - 0x80]
000190fe  0f8466fdffff             je 0x18e6a
00019104  498bdd                   mov rbx, r13
00019107  658b042548000000         mov eax, dword ptr gs:[0x48]
0001910f  448bf0                   mov r14d, eax
00019112  8b05e0fc2f00             mov eax, dword ptr [rip + 0x2ffce0]
00019118  85c0                     test eax, eax
0001911a  0f854b010200             jne 0x3926b
00019120  33c0                     xor eax, eax
00019122  f04c0fb135cdfc2f00       lock cmpxchg qword ptr [rip + 0x2ffccd], r14
0001912b  418bc5                   mov eax, r13d
0001912e  0f94c0                   sete al
00019131  85c0                     test eax, eax
00019133  0f8432010200             je 0x3926b
00019139  498b5f08                 mov rbx, qword ptr [r15 + 8]
0001913d  4c8d35a4fc2f00           lea r14, [rip + 0x2ffca4]
00019144  493bde                   cmp rbx, r14
00019147  0f8488361700             je 0x18c7d5
0001914d  4885db                   test rbx, rbx
00019150  7428                     je 0x1917a
00019152  8b4b18                   mov ecx, dword ptr [rbx + 0x18]
00019155  85c9                     test ecx, ecx
00019157  0f846f361700             je 0x18c7cc
0001915d  0f1f00                   nop dword ptr [rax]
00019160  8d5101                   lea edx, [rcx + 1]
00019163  8bc1                     mov eax, ecx
00019165  f00fb15318               lock cmpxchg dword ptr [rbx + 0x18], edx
0001916a  3bc8                     cmp ecx, eax
0001916c  0f85c2010200             jne 0x39334
00019172  85d2                     test edx, edx
00019174  0f8452361700             je 0x18c7cc
0001917a  803d40c32f0000           cmp byte ptr [rip + 0x2fc340], 0
00019181  0f8557361700             jne 0x18c7de
00019187  4c892d6afc2f00           mov qword ptr [rip + 0x2ffc6a], r13
0001918e  48895c2478               mov qword ptr [rsp + 0x78], rbx
00019193  418bc4                   mov eax, r12d
00019196  f0410fc14718             lock xadd dword ptr [r15 + 0x18], eax
0001919c  83f801                   cmp eax, 1
0001919f  0f846b361700             je 0x18c810
000191a5  4c8bfb                   mov r15, rbx
000191a8  4885db                   test rbx, rbx
000191ab  0f84a4000000             je 0x19255
000191b1  488d8b600b0000           lea rcx, [rbx + 0xb60]
000191b8  488d9570060000           lea rdx, [rbp + 0x670]
000191bf  e8fcb7feff               call 0x49c0
000191c4  0fb78610140000           movzx eax, word ptr [rsi + 0x1410]
000191cb  488d0c80                 lea rcx, [rax + rax*4]
000191cf  488d14cd00000000         lea rdx, [rcx*8]
000191d7  4c8d05826a3000           lea r8, [rip + 0x306a82]
000191de  420fb7440210             movzx eax, word ptr [rdx + r8 + 0x10]
000191e4  488b8cc570060000         mov rcx, qword ptr [rbp + rax*8 + 0x670]
000191ec  4a234c0208               and rcx, qword ptr [rdx + r8 + 8]
000191f1  48858e18140000           test qword ptr [rsi + 0x1418], rcx
000191f8  0f84e2feffff             je 0x190e0
000191fe  8b93300b0000             mov edx, dword ptr [rbx + 0xb30]
00019204  833dc5c62f0001           cmp dword ptr [rip + 0x2fc6c5], 1
0001920b  0f8531361700             jne 0x18c842
00019211  81be680e000000001000     cmp dword ptr [rsi + 0xe68], 0x100000
0001921b  41b901000000             mov r9d, 1
00019221  0f831b361700             jae 0x18c842
00019227  448b865c140000           mov r8d, dword ptr [rsi + 0x145c]
0001922e  488d1c9500000000         lea rbx, [rdx*4]
00019236  488d8e80000000           lea rcx, [rsi + 0x80]
0001923d  e87ed7feff               call 0x69c0
00019242  01841df0070000           add dword ptr [rbp + rbx + 0x7f0], eax
00019249  ff841df0060000           inc dword ptr [rbp + rbx + 0x6f0]
00019250  e98bfeffff               jmp 0x190e0
00019255  488b4c2478               mov rcx, qword ptr [rsp + 0x78]
0001925a  4885c9                   test rcx, rcx
0001925d  4c8b6c2470               mov r13, qword ptr [rsp + 0x70]
00019262  0f85e3351700             jne 0x18c84b
00019268  4533f6                   xor r14d, r14d
0001926b  488b4d80                 mov rcx, qword ptr [rbp - 0x80]
0001926f  4885c9                   test rcx, rcx
00019272  7415                     je 0x19289
00019274  418bc4                   mov eax, r12d
00019277  f00fc14118               lock xadd dword ptr [rcx + 0x18], eax
0001927c  83f801                   cmp eax, 1
0001927f  0f840e361700             je 0x18c893
00019285  4c897580                 mov qword ptr [rbp - 0x80], r14
00019289  4c897588                 mov qword ptr [rbp - 0x78], r14
0001928d  8b7c2438                 mov edi, dword ptr [rsp + 0x38]
00019291  4c8b7c2440               mov r15, qword ptr [rsp + 0x40]
00019296  8b5c2420                 mov ebx, dword ptr [rsp + 0x20]
0001929a  e9d5fcffff               jmp 0x18f74
0001929f  cc                       int3
000192a0  4c89742448               mov qword ptr [rsp + 0x48], r14
000192a5  418bc4                   mov eax, r12d
000192a8  f00fc14718               lock xadd dword ptr [rdi + 0x18], eax
000192ad  83f801                   cmp eax, 1
000192b0  0f856e010000             jne 0x19424
000192b6  48837f0800               cmp qword ptr [rdi + 8], 0
000192bb  0f85a4010000             jne 0x19465
000192c1  488bcf                   mov rcx, rdi
000192c4  e827190500               call 0x6abf0
000192c9  488bcf                   mov rcx, rdi
000192cc  e9ee361700               jmp 0x18c9bf
000192d1  cc                       int3
000192d2  4c897538                 mov qword ptr [rbp + 0x38], r14
000192d6  418bc4                   mov eax, r12d
000192d9  f00fc14328               lock xadd dword ptr [rbx + 0x28], eax
000192de  83f801                   cmp eax, 1
000192e1  0f8571fdffff             jne 0x19058
000192e7  48837b1800               cmp qword ptr [rbx + 0x18], 0
000192ec  740c                     je 0x192fa
000192ee  488bd3                   mov rdx, rbx
000192f1  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
000192f5  e8566affff               call 0xfd50
000192fa  488bcb                   mov rcx, rbx
000192fd  e87e300600               call 0x7c380
00019302  90                       nop
00019303  488d4d38                 lea rcx, [rbp + 0x38]
00019307  e804eeffff               call 0x18110
0001930c  83ff01                   cmp edi, 1
0001930f  0f85c8f7ffff             jne 0x18add
00019315  0f57c0                   xorps xmm0, xmm0
00019318  f30f7f442448             movdqu xmmword ptr [rsp + 0x48], xmm0
0001931e  4c89742460               mov qword ptr [rsp + 0x60], r14
00019323  4489742468               mov dword ptr [rsp + 0x68], r14d
00019328  4c89742458               mov qword ptr [rsp + 0x58], r14
0001932d  4c8d2db4fa2f00           lea r13, [rip + 0x2ffab4]
00019334  4c896c2458               mov qword ptr [rsp + 0x58], r13
00019339  498bcd                   mov rcx, r13
0001933c  e8fff5ffff               call 0x18940
00019341  488bf8                   mov rdi, rax
00019344  4889442448               mov qword ptr [rsp + 0x48], rax
00019349  498bcd                   mov rcx, r13
0001934c  e8aff6ffff               call 0x18a00
00019351  4889442450               mov qword ptr [rsp + 0x50], rax
00019356  498bf6                   mov rsi, r14
00019359  0f1f8000000000           nop dword ptr [rax]
00019360  498bde                   mov rbx, r14
00019363  4885f6                   test rsi, rsi
00019366  0f8468f7ffff             je 0x18ad4
0001936c  4885ff                   test rdi, rdi
0001936f  0f84b4000000             je 0x19429
00019375  483b7c2450               cmp rdi, qword ptr [rsp + 0x50]
0001937a  0f8420ffffff             je 0x192a0
00019380  658b042548000000         mov eax, dword ptr gs:[0x48]
00019388  448bf0                   mov r14d, eax
0001938b  8b0567fa2f00             mov eax, dword ptr [rip + 0x2ffa67]
00019391  85c0                     test eax, eax
00019393  0f85da000200             jne 0x39473
00019399  33c0                     xor eax, eax
0001939b  f04c0fb13554fa2f00       lock cmpxchg qword ptr [rip + 0x2ffa54], r14
000193a4  41b800000000             mov r8d, 0
000193aa  418bc0                   mov eax, r8d
000193ad  0f94c0                   sete al
000193b0  85c0                     test eax, eax
000193b2  0f84be000200             je 0x39476
000193b8  4533f6                   xor r14d, r14d
000193bb  488b5e08                 mov rbx, qword ptr [rsi + 8]
000193bf  493bdd                   cmp rbx, r13
000193c2  0f849b351700             je 0x18c963
000193c8  4885db                   test rbx, rbx
000193cb  742d                     je 0x193fa
000193cd  8b4b18                   mov ecx, dword ptr [rbx + 0x18]
000193d0  85c9                     test ecx, ecx
000193d2  0f8482351700             je 0x18c95a
000193d8  660f1f0400               nop word ptr [rax + rax]
000193dd  0f1f00                   nop dword ptr [rax]
000193e0  8d5101                   lea edx, [rcx + 1]
000193e3  8bc1                     mov eax, ecx
000193e5  f00fb15318               lock cmpxchg dword ptr [rbx + 0x18], edx
000193ea  3bc8                     cmp ecx, eax
000193ec  0f85d4341700             jne 0x18c8c6
000193f2  85d2                     test edx, edx
000193f4  0f8460351700             je 0x18c95a
000193fa  803dc0c02f0000           cmp byte ptr [rip + 0x2fc0c0], 0
00019401  0f8565351700             jne 0x18c96c
00019407  4c8935eaf92f00           mov qword ptr [rip + 0x2ff9ea], r14
0001940e  48895c2448               mov qword ptr [rsp + 0x48], rbx
00019413  418bc4                   mov eax, r12d
00019416  f00fc14618               lock xadd dword ptr [rsi + 0x18], eax
0001941b  83f801                   cmp eax, 1
0001941e  0f847a351700             je 0x18c99e
00019424  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
00019429  488bf3                   mov rsi, rbx
0001942c  4885db                   test rbx, rbx
0001942f  745a                     je 0x1948b
00019431  448b83300b0000           mov r8d, dword ptr [rbx + 0xb30]
00019438  428b8c85f0060000         mov ecx, dword ptr [rbp + r8*4 + 0x6f0]
00019440  85c9                     test ecx, ecx
00019442  0f8418ffffff             je 0x19360
00019448  33d2                     xor edx, edx
0001944a  428b8485f0070000         mov eax, dword ptr [rbp + r8*4 + 0x7f0]
00019452  f7f1                     div ecx
00019454  498b4f18                 mov rcx, qword ptr [r15 + 0x18]
00019458  4289848138060000         mov dword ptr [rcx + r8*4 + 0x638], eax
00019460  e9fbfeffff               jmp 0x19360
00019465  488bd7                   mov rdx, rdi
00019468  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
0001946c  e83f7fffff               call 0x113b0
00019471  488bcf                   mov rcx, rdi
00019474  e877170500               call 0x6abf0
00019479  bae80b0000               mov edx, 0xbe8
0001947e  488bcf                   mov rcx, rdi
00019481  e8aadafeff               call 0x6f30
00019486  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
0001948b  4885ff                   test rdi, rdi
0001948e  0f853c351700             jne 0x18c9d0
00019494  488b442450               mov rax, qword ptr [rsp + 0x50]
00019499  4885c0                   test rax, rax
0001949c  7415                     je 0x194b3
0001949e  f0440fc16018             lock xadd dword ptr [rax + 0x18], r12d
000194a4  4183fc01                 cmp r12d, 1
000194a8  0f8467351700             je 0x18ca15
000194ae  4c89742450               mov qword ptr [rsp + 0x50], r14
000194b3  4c89742458               mov qword ptr [rsp + 0x58], r14
000194b8  498d9fe0010000           lea rbx, [r15 + 0x1e0]
000194bf  498db718020000           lea rsi, [r15 + 0x218]
000194c6  eb01                     jmp 0x194c9
000194c8  cc                       int3
000194c9  837c243001               cmp dword ptr [rsp + 0x30], 1
000194ce  750b                     jne 0x194db
000194d0  837c242001               cmp dword ptr [rsp + 0x20], 1
000194d5  0f846e351700             je 0x18ca49
000194db  833b01                   cmp dword ptr [rbx], 1
000194de  0f835c381700             jae 0x18cd40
000194e4  448933                   mov dword ptr [rbx], r14d
000194e7  488b8df0080000           mov rcx, qword ptr [rbp + 0x8f0]
000194ee  4833cc                   xor rcx, rsp
000194f1  e8eab0feff               call 0x45e0
000194f6  4c8d9c24000a0000         lea r11, [rsp + 0xa00]
000194fe  498b5b38                 mov rbx, qword ptr [r11 + 0x38]
00019502  498b7340                 mov rsi, qword ptr [r11 + 0x40]
00019506  498b7b48                 mov rdi, qword ptr [r11 + 0x48]
0001950a  498be3                   mov rsp, r11
0001950d  415f                     pop r15
0001950f  415e                     pop r14
00019511  415d                     pop r13
00019513  415c                     pop r12
00019515  5d                       pop rbp
00019516  c3                       ret
