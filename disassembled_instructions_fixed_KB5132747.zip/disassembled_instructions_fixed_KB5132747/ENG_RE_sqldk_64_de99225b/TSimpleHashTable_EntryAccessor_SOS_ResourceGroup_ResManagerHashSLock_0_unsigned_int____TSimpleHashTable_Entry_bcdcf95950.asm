; TSimpleHashTable_EntryAccessor<SOS_ResourceGroup,ResManagerHashSLock,0,unsigned int>::~TSimpleHashTable_EntryAccessor<SOS_ResourceGroup,ResManagerHashSLock,0,unsigned int>
; sqldk.dll, primary RVA 0x1a5730, 71 bytes in 1 chunk(s)

; chunk at RVA 0x1a5730 (71 bytes)
001a5730  4053                     push rbx
001a5732  4883ec20                 sub rsp, 0x20
001a5736  803d84fd160000           cmp byte ptr [rip + 0x16fd84], 0
001a573d  488b19                   mov rbx, qword ptr [rcx]
001a5740  7427                     je 0x1a5769
001a5742  ff1500430900             call qword ptr [rip + 0x94300]
001a5748  448bc0                   mov r8d, eax
001a574b  b867666666               mov eax, 0x66666667
001a5750  41f7e8                   imul r8d
001a5753  d1fa                     sar edx, 1
001a5755  8bca                     mov ecx, edx
001a5757  c1e91f                   shr ecx, 0x1f
001a575a  03d1                     add edx, ecx
001a575c  8d0c92                   lea ecx, [rdx + rdx*4]
001a575f  443bc1                   cmp r8d, ecx
001a5762  7505                     jne 0x1a5769
001a5764  e887080000               call 0x1a5ff0
001a5769  48c7431800000000         mov qword ptr [rbx + 0x18], 0
001a5771  4883c420                 add rsp, 0x20
001a5775  5b                       pop rbx
001a5776  c3                       ret
