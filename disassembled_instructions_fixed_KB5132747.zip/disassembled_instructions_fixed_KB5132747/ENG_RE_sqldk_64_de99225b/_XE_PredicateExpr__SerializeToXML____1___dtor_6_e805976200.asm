; `XE_PredicateExpr::SerializeToXML'::`1'::dtor$6
; sqldk.dll, primary RVA 0x2361eb, 31 bytes in 1 chunk(s)

; chunk at RVA 0x2361eb (31 bytes)
002361eb  4055                     push rbp
002361ed  4883ec20                 sub rsp, 0x20
002361f1  488bea                   mov rbp, rdx
002361f4  4533c0                   xor r8d, r8d
002361f7  488b5540                 mov rdx, qword ptr [rbp + 0x40]
002361fb  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
002361ff  e80caedcff               call 0x1010
00236204  4883c420                 add rsp, 0x20
00236208  5d                       pop rbp
00236209  c3                       ret
