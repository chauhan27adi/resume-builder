; MemoryPoolManager::AdjustMemoryUsage
; sqldk.dll, primary RVA 0xb6b0, 3437 bytes in 1 chunk(s)

; chunk at RVA 0xb6b0 (3437 bytes)
0000b6b0  4489442418               mov dword ptr [rsp + 0x18], r8d
0000b6b5  53                       push rbx
0000b6b6  56                       push rsi
0000b6b7  57                       push rdi
0000b6b8  4154                     push r12
0000b6ba  4155                     push r13
0000b6bc  4156                     push r14
0000b6be  4157                     push r15
0000b6c0  4881ecb0020000           sub rsp, 0x2b0
0000b6c7  48c78424a0010000feffffff mov qword ptr [rsp + 0x1a0], 0xfffffffffffffffe
0000b6d3  0f29b424a0020000         movaps xmmword ptr [rsp + 0x2a0], xmm6
0000b6db  418bf1                   mov esi, r9d
0000b6de  488bda                   mov rbx, rdx
0000b6e1  4c8bf1                   mov r14, rcx
0000b6e4  4533e4                   xor r12d, r12d
0000b6e7  4c89642428               mov qword ptr [rsp + 0x28], r12
0000b6ec  4c89642450               mov qword ptr [rsp + 0x50], r12
0000b6f1  4c89642440               mov qword ptr [rsp + 0x40], r12
0000b6f6  4c89642438               mov qword ptr [rsp + 0x38], r12
0000b6fb  4c89a42488000000         mov qword ptr [rsp + 0x88], r12
0000b703  4c89642458               mov qword ptr [rsp + 0x58], r12
0000b708  458bec                   mov r13d, r12d
0000b70b  65488b142558000000       mov rdx, qword ptr gs:[0x58]
0000b714  8b05b6983000             mov eax, dword ptr [rip + 0x3098b6]
0000b71a  8b3d9861ffff             mov edi, dword ptr [rip - 0x9e68]
0000b720  48033cc2                 add rdi, qword ptr [rdx + rax*8]
0000b724  488b8700010000           mov rax, qword ptr [rdi + 0x100]
0000b72b  4885c0                   test rax, rax
0000b72e  0f84c79a0900             je 0xa51fb
0000b734  f6806802000040           test byte ptr [rax + 0x268], 0x40
0000b73b  0f85d99e0900             jne 0xa561a
0000b741  4c8d3d203b3200           lea r15, [rip + 0x323b20]
0000b748  4c89bc24a8000000         mov qword ptr [rsp + 0xa8], r15
0000b750  418bfc                   mov edi, r12d
0000b753  4489a424b0000000         mov dword ptr [rsp + 0xb0], r12d
0000b75b  85f6                     test esi, esi
0000b75d  0f85ac9a0900             jne 0xa520f
0000b763  c78424780100007e004000   mov dword ptr [rsp + 0x178], 0x40007e
0000b76e  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
0000b776  4c89a42490010000         mov qword ptr [rsp + 0x190], r12
0000b77e  4c89a42488010000         mov qword ptr [rsp + 0x188], r12
0000b786  4c89a42498010000         mov qword ptr [rsp + 0x198], r12
0000b78e  4533c9                   xor r9d, r9d
0000b791  4c8d842478010000         lea r8, [rsp + 0x178]
0000b799  33d2                     xor edx, edx
0000b79b  498bcf                   mov rcx, r15
0000b79e  e85dfcffff               call 0xb400
0000b7a3  85c0                     test eax, eax
0000b7a5  0f85669e0900             jne 0xa5611
0000b7ab  be01000000               mov esi, 1
0000b7b0  89b424b0000000           mov dword ptr [rsp + 0xb0], esi
0000b7b7  4983fe01                 cmp r14, 1
0000b7bb  4c0f4cf6                 cmovl r14, rsi
0000b7bf  4c89b424f0020000         mov qword ptr [rsp + 0x2f0], r14
0000b7c7  488b05d23a3200           mov rax, qword ptr [rip + 0x323ad2]
0000b7ce  4889842480000000         mov qword ptr [rsp + 0x80], rax
0000b7d6  4c8b05833a3200           mov r8, qword ptr [rip + 0x323a83]
0000b7dd  4c3bc3                   cmp r8, rbx
0000b7e0  490f47d8                 cmova rbx, r8
0000b7e4  48899c24f8020000         mov qword ptr [rsp + 0x2f8], rbx
0000b7ec  48bf4b598638d6c56d34     movabs rdi, 0x346dc5d63886594b
0000b7f6  448b15c79c3000           mov r10d, dword ptr [rip + 0x309cc7]
0000b7fd  4c8b0dc49c3000           mov r9, qword ptr [rip + 0x309cc4]
0000b804  49c7c3ffffffff           mov r11, 0xffffffffffffffff
0000b80b  4c895c2448               mov qword ptr [rsp + 0x48], r11
0000b810  493bd8                   cmp rbx, r8
0000b813  0f827f9a0900             jb 0xa5298
0000b819  488bcb                   mov rcx, rbx
0000b81c  492bc8                   sub rcx, r8
0000b81f  493bcb                   cmp rcx, r11
0000b822  0f84689a0900             je 0xa5290
0000b828  4585d2                   test r10d, r10d
0000b82b  0f84709a0900             je 0xa52a1
0000b831  4869c1e8030000           imul rax, rcx, 0x3e8
0000b838  33d2                     xor edx, edx
0000b83a  49f7f1                   div r9
0000b83d  488bd0                   mov rdx, rax
0000b840  eb01                     jmp 0xb843
0000b842  cc                       int3
0000b843  83fa64                   cmp edx, 0x64
0000b846  0f8c659a0900             jl 0xa52b1
0000b84c  493bd8                   cmp rbx, r8
0000b84f  0f826f9a0900             jb 0xa52c4
0000b855  488bcb                   mov rcx, rbx
0000b858  492bc8                   sub rcx, r8
0000b85b  493bcb                   cmp rcx, r11
0000b85e  0f845b9a0900             je 0xa52bf
0000b864  4585d2                   test r10d, r10d
0000b867  0f84609a0900             je 0xa52cd
0000b86d  4869c1e8030000           imul rax, rcx, 0x3e8
0000b874  33d2                     xor edx, edx
0000b876  49f7f1                   div r9
0000b879  4889442448               mov qword ptr [rsp + 0x48], rax
0000b87e  eb01                     jmp 0xb881
0000b880  cc                       int3
0000b881  496bd61b                 imul rdx, r14, 0x1b
0000b885  48c1fa05                 sar rdx, 5
0000b889  48899424a0000000         mov qword ptr [rsp + 0xa0], rdx
0000b891  488bc2                   mov rax, rdx
0000b894  48c1f802                 sar rax, 2
0000b898  488d0c40                 lea rcx, [rax + rax*2]
0000b89c  48894c2478               mov qword ptr [rsp + 0x78], rcx
0000b8a1  488bc2                   mov rax, rdx
0000b8a4  48c1f804                 sar rax, 4
0000b8a8  488d0c40                 lea rcx, [rax + rax*2]
0000b8ac  48894c2430               mov qword ptr [rsp + 0x30], rcx
0000b8b1  488bc2                   mov rax, rdx
0000b8b4  48c1f805                 sar rax, 5
0000b8b8  4883f801                 cmp rax, 1
0000b8bc  480f4cc6                 cmovl rax, rsi
0000b8c0  4889842498000000         mov qword ptr [rsp + 0x98], rax
0000b8c8  488b0509373200           mov rax, qword ptr [rip + 0x323709]
0000b8cf  488905ea363200           mov qword ptr [rip + 0x3236ea], rax
0000b8d6  4889150b373200           mov qword ptr [rip + 0x32370b], rdx
0000b8dd  4c8925f4363200           mov qword ptr [rip + 0x3236f4], r12
0000b8e4  4c8925f5363200           mov qword ptr [rip + 0x3236f5], r12
0000b8eb  488b0546373200           mov rax, qword ptr [rip + 0x323746]
0000b8f2  48890527373200           mov qword ptr [rip + 0x323727], rax
0000b8f9  48891548373200           mov qword ptr [rip + 0x323748], rdx
0000b900  4c892531373200           mov qword ptr [rip + 0x323731], r12
0000b907  4c892532373200           mov qword ptr [rip + 0x323732], r12
0000b90e  488b0583373200           mov rax, qword ptr [rip + 0x323783]
0000b915  48890564373200           mov qword ptr [rip + 0x323764], rax
0000b91c  48891585373200           mov qword ptr [rip + 0x323785], rdx
0000b923  4c89256e373200           mov qword ptr [rip + 0x32376e], r12
0000b92a  4c89256f373200           mov qword ptr [rip + 0x32376f], r12
0000b931  488b05c0373200           mov rax, qword ptr [rip + 0x3237c0]
0000b938  488905a1373200           mov qword ptr [rip + 0x3237a1], rax
0000b93f  488915c2373200           mov qword ptr [rip + 0x3237c2], rdx
0000b946  4c8925ab373200           mov qword ptr [rip + 0x3237ab], r12
0000b94d  4c8925ac373200           mov qword ptr [rip + 0x3237ac], r12
0000b954  488b05fd373200           mov rax, qword ptr [rip + 0x3237fd]
0000b95b  488905de373200           mov qword ptr [rip + 0x3237de], rax
0000b962  488915ff373200           mov qword ptr [rip + 0x3237ff], rdx
0000b969  4c8925e8373200           mov qword ptr [rip + 0x3237e8], r12
0000b970  4c8925e9373200           mov qword ptr [rip + 0x3237e9], r12
0000b977  488b053a383200           mov rax, qword ptr [rip + 0x32383a]
0000b97e  4889051b383200           mov qword ptr [rip + 0x32381b], rax
0000b985  4889153c383200           mov qword ptr [rip + 0x32383c], rdx
0000b98c  4c892525383200           mov qword ptr [rip + 0x323825], r12
0000b993  4c892526383200           mov qword ptr [rip + 0x323826], r12
0000b99a  4c8935ef553100           mov qword ptr [rip + 0x3155ef], r14
0000b9a1  4c8b2500583100           mov r12, qword ptr [rip + 0x315800]
0000b9a8  ff15a27e3000             call qword ptr [rip + 0x307ea2]
0000b9ae  4c8bf0                   mov r14, rax
0000b9b1  33c0                     xor eax, eax
0000b9b3  8bf0                     mov esi, eax
0000b9b5  448b3d949b3000           mov r15d, dword ptr [rip + 0x309b94]
0000b9bc  0fb7f8                   movzx edi, ax
0000b9bf  4585ff                   test r15d, r15d
0000b9c2  742a                     je 0xb9ee
0000b9c4  0f1f00                   nop dword ptr [rax]
0000b9c7  660f1f840000000000       nop word ptr [rax + rax]
0000b9d0  0fb7d7                   movzx edx, di
0000b9d3  488d0db68b3000           lea rcx, [rip + 0x308bb6]
0000b9da  e811aaffff               call 0x63f0
0000b9df  48037058                 add rsi, qword ptr [rax + 0x58]
0000b9e3  66ffc7                   inc di
0000b9e6  0fb7c7                   movzx eax, di
0000b9e9  413bc7                   cmp eax, r15d
0000b9ec  72e2                     jb 0xb9d0
0000b9ee  488d4601                 lea rax, [rsi + 1]
0000b9f2  4899                     cqo
0000b9f4  482bc2                   sub rax, rdx
0000b9f7  48d1f8                   sar rax, 1
0000b9fa  4c3bf0                   cmp r14, rax
0000b9fd  490f4cc6                 cmovl rax, r14
0000ba01  4c2bf0                   sub r14, rax
0000ba04  4d2bf4                   sub r14, r12
0000ba07  f04c0fc13598573100       lock xadd qword ptr [rip + 0x315798], r14
0000ba10  488bbc2480000000         mov rdi, qword ptr [rsp + 0x80]
0000ba18  4c8bcf                   mov r9, rdi
0000ba1b  4c8b35b3903000           mov r14, qword ptr [rip + 0x3090b3]
0000ba22  f20f10359e832500         movsd xmm6, qword ptr [rip + 0x25839e]
0000ba2a  480fbcc7                 bsf rax, rdi
0000ba2e  4c8b9c24f0020000         mov r11, qword ptr [rsp + 0x2f0]
0000ba36  0f8406990900             je 0xa5342
0000ba3c  0f57d2                   xorps xmm2, xmm2
0000ba3f  f2490f2ad3               cvtsi2sd xmm2, r11
0000ba44  488d3575553100           lea rsi, [rip + 0x315575]
0000ba4b  41bff0000000             mov r15d, 0xf0
0000ba51  4533e4                   xor r12d, r12d
0000ba54  0f1f4000                 nop dword ptr [rax]
0000ba58  0f1f840000000000         nop dword ptr [rax + rax]
0000ba60  448bd0                   mov r10d, eax
0000ba63  4969d280030000           imul rdx, r10, 0x380
0000ba6a  4803d6                   add rdx, rsi
0000ba6d  498bc4                   mov rax, r12
0000ba70  4c8b82c8000000           mov r8, qword ptr [rdx + 0xc8]
0000ba77  4c898290000000           mov qword ptr [rdx + 0x90], r8
0000ba7e  83bad000000001           cmp dword ptr [rdx + 0xd0], 1
0000ba85  0f8457980900             je 0xa52e2
0000ba8b  498bc0                   mov rax, r8
0000ba8e  488b8a28010000           mov rcx, qword ptr [rdx + 0x128]
0000ba95  48898af0000000           mov qword ptr [rdx + 0xf0], rcx
0000ba9c  83ba3001000001           cmp dword ptr [rdx + 0x130], 1
0000baa3  0f8449980900             je 0xa52f2
0000baa9  4803c1                   add rax, rcx
0000baac  4903c8                   add rcx, r8
0000baaf  4c8b8288010000           mov r8, qword ptr [rdx + 0x188]
0000bab6  4c898250010000           mov qword ptr [rdx + 0x150], r8
0000babd  83ba9001000001           cmp dword ptr [rdx + 0x190], 1
0000bac4  0f8438980900             je 0xa5302
0000baca  4903c0                   add rax, r8
0000bacd  4903c8                   add rcx, r8
0000bad0  4c8b82e8010000           mov r8, qword ptr [rdx + 0x1e8]
0000bad7  4c8982b0010000           mov qword ptr [rdx + 0x1b0], r8
0000bade  83baf001000001           cmp dword ptr [rdx + 0x1f0], 1
0000bae5  0f8427980900             je 0xa5312
0000baeb  4903c0                   add rax, r8
0000baee  4903c8                   add rcx, r8
0000baf1  4c8b8248020000           mov r8, qword ptr [rdx + 0x248]
0000baf8  4c898210020000           mov qword ptr [rdx + 0x210], r8
0000baff  83ba5002000001           cmp dword ptr [rdx + 0x250], 1
0000bb06  7506                     jne 0xbb0e
0000bb08  41f6c620                 test r14b, 0x20
0000bb0c  7503                     jne 0xbb11
0000bb0e  4903c0                   add rax, r8
0000bb11  4903c8                   add rcx, r8
0000bb14  4c8b82a8020000           mov r8, qword ptr [rdx + 0x2a8]
0000bb1b  4c898270020000           mov qword ptr [rdx + 0x270], r8
0000bb22  83bab002000001           cmp dword ptr [rdx + 0x2b0], 1
0000bb29  0f84f3970900             je 0xa5322
0000bb2f  4903c0                   add rax, r8
0000bb32  4903c8                   add rcx, r8
0000bb35  4c8b8208030000           mov r8, qword ptr [rdx + 0x308]
0000bb3c  4c8982d0020000           mov qword ptr [rdx + 0x2d0], r8
0000bb43  83ba1003000001           cmp dword ptr [rdx + 0x310], 1
0000bb4a  0f84e2970900             je 0xa5332
0000bb50  4903c0                   add rax, r8
0000bb53  4903c8                   add rcx, r8
0000bb56  48894228                 mov qword ptr [rdx + 0x28], rax
0000bb5a  48894a30                 mov qword ptr [rdx + 0x30], rcx
0000bb5e  0f28c2                   movaps xmm0, xmm2
0000bb61  f20f598218030000         mulsd xmm0, qword ptr [rdx + 0x318]
0000bb69  f20f5ec6                 divsd xmm0, xmm6
0000bb6d  f2480f2cc8               cvttsd2si rcx, xmm0
0000bb72  48894a18                 mov qword ptr [rdx + 0x18], rcx
0000bb76  0f28ca                   movaps xmm1, xmm2
0000bb79  f20f598a20030000         mulsd xmm1, qword ptr [rdx + 0x320]
0000bb81  f20f5ece                 divsd xmm1, xmm6
0000bb85  f2480f2cc1               cvttsd2si rax, xmm1
0000bb8a  48894220                 mov qword ptr [rdx + 0x20], rax
0000bb8e  4c895a50                 mov qword ptr [rdx + 0x50], r11
0000bb92  4c03e9                   add r13, rcx
0000bb95  b890000000               mov eax, 0x90
0000bb9a  4d85c0                   test r8, r8
0000bb9d  490f4fc7                 cmovg rax, r15
0000bba1  4c010410                 add qword ptr [rax + rdx], r8
0000bba5  4c89a2d0020000           mov qword ptr [rdx + 0x2d0], r12
0000bbac  4d0fb3d1                 btr r9, r10
0000bbb0  490fbcc1                 bsf rax, r9
0000bbb4  0f85a6feffff             jne 0xba60
0000bbba  eb01                     jmp 0xbbbd
0000bbbc  cc                       int3
0000bbbd  498bc3                   mov rax, r11
0000bbc0  492bc5                   sub rax, r13
0000bbc3  498bd4                   mov rdx, r12
0000bbc6  480f49d0                 cmovns rdx, rax
0000bbca  4889542470               mov qword ptr [rsp + 0x70], rdx
0000bbcf  486bc21b                 imul rax, rdx, 0x1b
0000bbd3  48c1f805                 sar rax, 5
0000bbd7  4889842490000000         mov qword ptr [rsp + 0x90], rax
0000bbdf  48897c2460               mov qword ptr [rsp + 0x60], rdi
0000bbe4  488d0d95533100           lea rcx, [rip + 0x315395]
0000bbeb  480fbcc7                 bsf rax, rdi
0000bbef  4889442468               mov qword ptr [rsp + 0x68], rax
0000bbf4  0f84e5970900             je 0xa53df
0000bbfa  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
0000bbff  eb01                     jmp 0xbc02
0000bc01  cc                       int3
0000bc02  4889442478               mov qword ptr [rsp + 0x78], rax
0000bc07  4c69e080030000           imul r12, rax, 0x380
0000bc0e  33c0                     xor eax, eax
0000bc10  448bf8                   mov r15d, eax
0000bc13  448be8                   mov r13d, eax
0000bc16  8bf0                     mov esi, eax
0000bc18  4c8d89b8000000           lea r9, [rcx + 0xb8]
0000bc1f  4d03cc                   add r9, r12
0000bc22  c744242002000000         mov dword ptr [rsp + 0x20], 2
0000bc2a  eb01                     jmp 0xbc2d
0000bc2c  cc                       int3
0000bc2d  4c8d0476                 lea r8, [rsi + rsi*2]
0000bc31  49c1e005                 shl r8, 5
0000bc35  4b8b7c0118               mov rdi, qword ptr [r9 + r8 + 0x18]
0000bc3a  478b5c0158               mov r11d, dword ptr [r9 + r8 + 0x58]
0000bc3f  4183fb01                 cmp r11d, 1
0000bc43  0f8402970900             je 0xa534b
0000bc49  48017c2428               add qword ptr [rsp + 0x28], rdi
0000bc4e  4c8bd0                   mov r10, rax
0000bc51  4183fb01                 cmp r11d, 1
0000bc55  7433                     je 0xbc8a
0000bc57  488bc7                   mov rax, rdi
0000bc5a  4b2b0401                 sub rax, qword ptr [r9 + r8]
0000bc5e  4869c0e8030000           imul rax, rax, 0x3e8
0000bc65  48634c2448               movsxd rcx, dword ptr [rsp + 0x48]
0000bc6a  4899                     cqo
0000bc6c  48f7f9                   idiv rcx
0000bc6f  4c8bd0                   mov r10, rax
0000bc72  4b8b4c0110               mov rcx, qword ptr [r9 + r8 + 0x10]
0000bc77  488d0449                 lea rax, [rcx + rcx*2]
0000bc7b  4899                     cqo
0000bc7d  83e203                   and edx, 3
0000bc80  4803c2                   add rax, rdx
0000bc83  48c1f802                 sar rax, 2
0000bc87  4c03d0                   add r10, rax
0000bc8a  4f89540110               mov qword ptr [r9 + r8 + 0x10], r10
0000bc8f  488bd3                   mov rdx, rbx
0000bc92  4b395c0130               cmp qword ptr [r9 + r8 + 0x30], rbx
0000bc97  4b0f4c540130             cmovl rdx, qword ptr [r9 + r8 + 0x30]
0000bc9d  488b4c2430               mov rcx, qword ptr [rsp + 0x30]
0000bca2  4c3bd1                   cmp r10, rcx
0000bca5  490f4cca                 cmovl rcx, r10
0000bca9  4803cf                   add rcx, rdi
0000bcac  488bc7                   mov rax, rdi
0000bcaf  483bf9                   cmp rdi, rcx
0000bcb2  480f4ec1                 cmovle rax, rcx
0000bcb6  483bc2                   cmp rax, rdx
0000bcb9  480f4fd0                 cmovg rdx, rax
0000bcbd  4b89540120               mov qword ptr [r9 + r8 + 0x20], rdx
0000bcc2  4533d2                   xor r10d, r10d
0000bcc5  4f89540130               mov qword ptr [r9 + r8 + 0x30], r10
0000bcca  4183fb01                 cmp r11d, 1
0000bcce  0f848a960900             je 0xa535e
0000bcd4  4c03fa                   add r15, rdx
0000bcd7  4801542440               add qword ptr [rsp + 0x40], rdx
0000bcdc  4c03ea                   add r13, rdx
0000bcdf  488d0d9a523100           lea rcx, [rip + 0x31529a]
0000bce6  498b440c60               mov rax, qword ptr [r12 + rcx + 0x60]
0000bceb  483bd0                   cmp rdx, rax
0000bcee  480f4cc2                 cmovl rax, rdx
0000bcf2  4183fb01                 cmp r11d, 1
0000bcf6  0f8472960900             je 0xa536e
0000bcfc  4885f6                   test rsi, rsi
0000bcff  7506                     jne 0xbd07
0000bd01  4183fb02                 cmp r11d, 2
0000bd05  7410                     je 0xbd17
0000bd07  4901bc0858e00000         add qword ptr [r8 + rcx + 0xe058], rdi
0000bd0f  4901840860e00000         add qword ptr [r8 + rcx + 0xe060], rax
0000bd17  4c8d4601                 lea r8, [rsi + 1]
0000bd1b  4f8d0440                 lea r8, [r8 + r8*2]
0000bd1f  49c1e005                 shl r8, 5
0000bd23  4b8b7c0118               mov rdi, qword ptr [r9 + r8 + 0x18]
0000bd28  478b5c0158               mov r11d, dword ptr [r9 + r8 + 0x58]
0000bd2d  4183fb01                 cmp r11d, 1
0000bd31  7506                     jne 0xbd39
0000bd33  41f6c620                 test r14b, 0x20
0000bd37  753e                     jne 0xbd77
0000bd39  48017c2428               add qword ptr [rsp + 0x28], rdi
0000bd3e  4183fb01                 cmp r11d, 1
0000bd42  7433                     je 0xbd77
0000bd44  488bc7                   mov rax, rdi
0000bd47  4b2b0401                 sub rax, qword ptr [r9 + r8]
0000bd4b  4869c0e8030000           imul rax, rax, 0x3e8
0000bd52  48634c2448               movsxd rcx, dword ptr [rsp + 0x48]
0000bd57  4899                     cqo
0000bd59  48f7f9                   idiv rcx
0000bd5c  4c8bd0                   mov r10, rax
0000bd5f  4b8b4c0110               mov rcx, qword ptr [r9 + r8 + 0x10]
0000bd64  488d0449                 lea rax, [rcx + rcx*2]
0000bd68  4899                     cqo
0000bd6a  83e203                   and edx, 3
0000bd6d  4803c2                   add rax, rdx
0000bd70  48c1f802                 sar rax, 2
0000bd74  4c03d0                   add r10, rax
0000bd77  4f89540110               mov qword ptr [r9 + r8 + 0x10], r10
0000bd7c  488bd3                   mov rdx, rbx
0000bd7f  4b395c0130               cmp qword ptr [r9 + r8 + 0x30], rbx
0000bd84  4b0f4c540130             cmovl rdx, qword ptr [r9 + r8 + 0x30]
0000bd8a  488b4c2430               mov rcx, qword ptr [rsp + 0x30]
0000bd8f  4c3bd1                   cmp r10, rcx
0000bd92  490f4cca                 cmovl rcx, r10
0000bd96  4803cf                   add rcx, rdi
0000bd99  488bc7                   mov rax, rdi
0000bd9c  483bf9                   cmp rdi, rcx
0000bd9f  480f4ec1                 cmovle rax, rcx
0000bda3  483bc2                   cmp rax, rdx
0000bda6  480f4fd0                 cmovg rdx, rax
0000bdaa  4b89540120               mov qword ptr [r9 + r8 + 0x20], rdx
0000bdaf  33c0                     xor eax, eax
0000bdb1  4b89440130               mov qword ptr [r9 + r8 + 0x30], rax
0000bdb6  4183fb01                 cmp r11d, 1
0000bdba  7506                     jne 0xbdc2
0000bdbc  41f6c620                 test r14b, 0x20
0000bdc0  7508                     jne 0xbdca
0000bdc2  4c03fa                   add r15, rdx
0000bdc5  4801542440               add qword ptr [rsp + 0x40], rdx
0000bdca  4c03ea                   add r13, rdx
0000bdcd  4c8d15ac513100           lea r10, [rip + 0x3151ac]
0000bdd4  4b8b4c1460               mov rcx, qword ptr [r12 + r10 + 0x60]
0000bdd9  483bd1                   cmp rdx, rcx
0000bddc  480f4cca                 cmovl rcx, rdx
0000bde0  4183fb01                 cmp r11d, 1
0000bde4  7506                     jne 0xbdec
0000bde6  41f6c620                 test r14b, 0x20
0000bdea  751b                     jne 0xbe07
0000bdec  837c242001               cmp dword ptr [rsp + 0x20], 1
0000bdf1  0f8487950900             je 0xa537e
0000bdf7  4b01bc1058e00000         add qword ptr [r8 + r10 + 0xe058], rdi
0000bdff  4b018c1060e00000         add qword ptr [r8 + r10 + 0xe060], rcx
0000be07  4c8d4602                 lea r8, [rsi + 2]
0000be0b  4f8d0440                 lea r8, [r8 + r8*2]
0000be0f  49c1e005                 shl r8, 5
0000be13  4b8b7c0118               mov rdi, qword ptr [r9 + r8 + 0x18]
0000be18  478b5c0158               mov r11d, dword ptr [r9 + r8 + 0x58]
0000be1d  4183fb01                 cmp r11d, 1
0000be21  0f8467950900             je 0xa538e
0000be27  48017c2428               add qword ptr [rsp + 0x28], rdi
0000be2c  4c8bd0                   mov r10, rax
0000be2f  4183fb01                 cmp r11d, 1
0000be33  7433                     je 0xbe68
0000be35  488bc7                   mov rax, rdi
0000be38  4b2b0401                 sub rax, qword ptr [r9 + r8]
0000be3c  4869c0e8030000           imul rax, rax, 0x3e8
0000be43  48634c2448               movsxd rcx, dword ptr [rsp + 0x48]
0000be48  4899                     cqo
0000be4a  48f7f9                   idiv rcx
0000be4d  4c8bd0                   mov r10, rax
0000be50  4b8b4c0110               mov rcx, qword ptr [r9 + r8 + 0x10]
0000be55  488d0449                 lea rax, [rcx + rcx*2]
0000be59  4899                     cqo
0000be5b  83e203                   and edx, 3
0000be5e  4803c2                   add rax, rdx
0000be61  48c1f802                 sar rax, 2
0000be65  4c03d0                   add r10, rax
0000be68  4f89540110               mov qword ptr [r9 + r8 + 0x10], r10
0000be6d  488bd3                   mov rdx, rbx
0000be70  4b395c0130               cmp qword ptr [r9 + r8 + 0x30], rbx
0000be75  4b0f4c540130             cmovl rdx, qword ptr [r9 + r8 + 0x30]
0000be7b  488b442430               mov rax, qword ptr [rsp + 0x30]
0000be80  4c3bd0                   cmp r10, rax
0000be83  490f4cc2                 cmovl rax, r10
0000be87  4803c7                   add rax, rdi
0000be8a  488bcf                   mov rcx, rdi
0000be8d  483bf8                   cmp rdi, rax
0000be90  480f4ec8                 cmovle rcx, rax
0000be94  483bca                   cmp rcx, rdx
0000be97  480f4fd1                 cmovg rdx, rcx
0000be9b  4b89540120               mov qword ptr [r9 + r8 + 0x20], rdx
0000bea0  4bc744013000000000       mov qword ptr [r9 + r8 + 0x30], 0
0000bea9  4183fb01                 cmp r11d, 1
0000bead  0f84ee940900             je 0xa53a1
0000beb3  4c03fa                   add r15, rdx
0000beb6  4801542440               add qword ptr [rsp + 0x40], rdx
0000bebb  4c03ea                   add r13, rdx
0000bebe  488d0dbb503100           lea rcx, [rip + 0x3150bb]
0000bec5  4d8b540c60               mov r10, qword ptr [r12 + rcx + 0x60]
0000beca  498bc2                   mov rax, r10
0000becd  493bd2                   cmp rdx, r10
0000bed0  480f4cc2                 cmovl rax, rdx
0000bed4  4183fb01                 cmp r11d, 1
0000bed8  0f84d3940900             je 0xa53b1
0000bede  837c242000               cmp dword ptr [rsp + 0x20], 0
0000bee3  0f84d8940900             je 0xa53c1
0000bee9  4901bc0858e00000         add qword ptr [r8 + rcx + 0xe058], rdi
0000bef1  4901840860e00000         add qword ptr [r8 + rcx + 0xe060], rax
0000bef9  4d8b540c60               mov r10, qword ptr [r12 + rcx + 0x60]
0000befe  8344242003               add dword ptr [rsp + 0x20], 3
0000bf03  4883c603                 add rsi, 3
0000bf07  4883fe06                 cmp rsi, 6
0000bf0b  0f8c0cf7ffff             jl 0xb61d
0000bf11  4d897c0c78               mov qword ptr [r12 + rcx + 0x78], r15
0000bf16  4d89ac0c80000000         mov qword ptr [r12 + rcx + 0x80], r13
0000bf1e  4c8b442468               mov r8, qword ptr [rsp + 0x68]
0000bf23  4c8d0d56503100           lea r9, [rip + 0x315056]
0000bf2a  4585c0                   test r8d, r8d
0000bf2d  7442                     je 0xbf71
0000bf2f  498b540c58               mov rdx, qword ptr [r12 + rcx + 0x58]
0000bf34  488b442470               mov rax, qword ptr [rsp + 0x70]
0000bf39  4803c2                   add rax, rdx
0000bf3c  4839842498000000         cmp qword ptr [rsp + 0x98], rax
0000bf44  480f4f842498000000       cmovg rax, qword ptr [rsp + 0x98]
0000bf4d  4f8b540c60               mov r10, qword ptr [r12 + r9 + 0x60]
0000bf52  493bc2                   cmp rax, r10
0000bf55  0f8c76940900             jl 0xa53d1
0000bf5b  4b8b4c0c68               mov rcx, qword ptr [r12 + r9 + 0x68]
0000bf60  482bca                   sub rcx, rdx
0000bf63  b800000000               mov eax, 0
0000bf68  480f49c1                 cmovns rax, rcx
0000bf6c  4801442450               add qword ptr [rsp + 0x50], rax
0000bf71  498bcf                   mov rcx, r15
0000bf74  4d3bfa                   cmp r15, r10
0000bf77  490f4dca                 cmovge rcx, r10
0000bf7b  488bd1                   mov rdx, rcx
0000bf7e  4585c0                   test r8d, r8d
0000bf81  740b                     je 0xbf8e
0000bf83  4b3b4c0c58               cmp rcx, qword ptr [r12 + r9 + 0x58]
0000bf88  4b0f4d540c58             cmovge rdx, qword ptr [r12 + r9 + 0x58]
0000bf8e  4801542438               add qword ptr [rsp + 0x38], rdx
0000bf93  4c2bfa                   sub r15, rdx
0000bf96  4c01bc2488000000         add qword ptr [rsp + 0x88], r15
0000bf9e  482bca                   sub rcx, rdx
0000bfa1  4c8b4c2458               mov r9, qword ptr [rsp + 0x58]
0000bfa6  4c03c9                   add r9, rcx
0000bfa9  4c894c2458               mov qword ptr [rsp + 0x58], r9
0000bfae  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
0000bfb3  488b442478               mov rax, qword ptr [rsp + 0x78]
0000bfb8  480fb3c1                 btr rcx, rax
0000bfbc  48894c2460               mov qword ptr [rsp + 0x60], rcx
0000bfc1  480fbcc1                 bsf rax, rcx
0000bfc5  4889442468               mov qword ptr [rsp + 0x68], rax
0000bfca  0f8540f6ffff             jne 0xb610
0000bfd0  488b9c24f8020000         mov rbx, qword ptr [rsp + 0x2f8]
0000bfd8  488b542470               mov rdx, qword ptr [rsp + 0x70]
0000bfdd  4c8b9c24f0020000         mov r11, qword ptr [rsp + 0x2f0]
0000bfe5  488bbc2480000000         mov rdi, qword ptr [rsp + 0x80]
0000bfed  4533e4                   xor r12d, r12d
0000bff0  eb01                     jmp 0xbff3
0000bff2  cc                       int3
0000bff3  488b05e62f3200           mov rax, qword ptr [rip + 0x322fe6]
0000bffa  483905d72f3200           cmp qword ptr [rip + 0x322fd7], rax
0000c001  480f4f05cf2f3200         cmovg rax, qword ptr [rip + 0x322fcf]
0000c009  488905884f3100           mov qword ptr [rip + 0x314f88], rax
0000c010  488bc2                   mov rax, rdx
0000c013  4c3bca                   cmp r9, rdx
0000c016  490f4cc1                 cmovl rax, r9
0000c01a  4803442438               add rax, qword ptr [rsp + 0x38]
0000c01f  4889442470               mov qword ptr [rsp + 0x70], rax
0000c024  498bcb                   mov rcx, r11
0000c027  482b4c2428               sub rcx, qword ptr [rsp + 0x28]
0000c02c  4d8bc4                   mov r8, r12
0000c02f  4c0f49c1                 cmovns r8, rcx
0000c033  4c898424c8000000         mov qword ptr [rsp + 0xc8], r8
0000c03b  4c2bd8                   sub r11, rax
0000c03e  498bc4                   mov rax, r12
0000c041  490f49c3                 cmovns rax, r11
0000c045  48898424d0000000         mov qword ptr [rsp + 0xd0], rax
0000c04d  488bc2                   mov rax, rdx
0000c050  482b442450               sub rax, qword ptr [rsp + 0x50]
0000c055  4d8bc4                   mov r8, r12
0000c058  4c0f49c0                 cmovns r8, rax
0000c05c  4c89842498000000         mov qword ptr [rsp + 0x98], r8
0000c064  492bd1                   sub rdx, r9
0000c067  498bc4                   mov rax, r12
0000c06a  480f49c2                 cmovns rax, rdx
0000c06e  4889442478               mov qword ptr [rsp + 0x78], rax
0000c073  833d464f310000           cmp dword ptr [rip + 0x314f46], 0
0000c07a  0f846a930900             je 0xa53ea
0000c080  480fbcff                 bsf rdi, rdi
0000c084  0f8425030000             je 0xc3af
0000c08a  8bc7                     mov eax, edi
0000c08c  48898424b8000000         mov qword ptr [rsp + 0xb8], rax
0000c094  4c69f880030000           imul r15, rax, 0x380
0000c09b  4c897c2430               mov qword ptr [rsp + 0x30], r15
0000c0a0  4c8d15d94e3100           lea r10, [rip + 0x314ed9]
0000c0a7  4f8b4c1760               mov r9, qword ptr [r15 + r10 + 0x60]
0000c0ac  4d6bc11b                 imul r8, r9, 0x1b
0000c0b0  49c1f805                 sar r8, 5
0000c0b4  4c898424d8000000         mov qword ptr [rsp + 0xd8], r8
0000c0bc  4c898424e0000000         mov qword ptr [rsp + 0xe0], r8
0000c0c4  498bd8                   mov rbx, r8
0000c0c7  48c1fb05                 sar rbx, 5
0000c0cb  4883fb01                 cmp rbx, 1
0000c0cf  b901000000               mov ecx, 1
0000c0d4  480f4cd9                 cmovl rbx, rcx
0000c0d8  4f8b5c1758               mov r11, qword ptr [r15 + r10 + 0x58]
0000c0dd  498bc1                   mov rax, r9
0000c0e0  492bc3                   sub rax, r11
0000c0e3  498bd4                   mov rdx, r12
0000c0e6  480f49d0                 cmovns rdx, rax
0000c0ea  4b8b741768               mov rsi, qword ptr [r15 + r10 + 0x68]
0000c0ef  498bc1                   mov rax, r9
0000c0f2  482bc6                   sub rax, rsi
0000c0f5  4d8bec                   mov r13, r12
0000c0f8  4c0f49e8                 cmovns r13, rax
0000c0fc  4f8b541778               mov r10, qword ptr [r15 + r10 + 0x78]
0000c101  498bc1                   mov rax, r9
0000c104  492bc2                   sub rax, r10
0000c107  4c0f49e0                 cmovns r12, rax
0000c10b  4885d2                   test rdx, rdx
0000c10e  0f8e11f5ffff             jle 0xb625
0000c114  85ff                     test edi, edi
0000c116  0f8409f5ffff             je 0xb625
0000c11c  48894c2468               mov qword ptr [rsp + 0x68], rcx
0000c121  498bcd                   mov rcx, r13
0000c124  493bd5                   cmp rdx, r13
0000c127  480f4cca                 cmovl rcx, rdx
0000c12b  482b8c2498000000         sub rcx, qword ptr [rsp + 0x98]
0000c133  b800000000               mov eax, 0
0000c138  480f49c1                 cmovns rax, rcx
0000c13c  4c2be8                   sub r13, rax
0000c13f  498bcc                   mov rcx, r12
0000c142  493bd4                   cmp rdx, r12
0000c145  480f4cca                 cmovl rcx, rdx
0000c149  482b4c2478               sub rcx, qword ptr [rsp + 0x78]
0000c14e  b800000000               mov eax, 0
0000c153  480f49c1                 cmovns rax, rcx
0000c157  4c2be0                   sub r12, rax
0000c15a  488b942490000000         mov rdx, qword ptr [rsp + 0x90]
0000c162  4839542458               cmp qword ptr [rsp + 0x58], rdx
0000c167  0f8f9b920900             jg 0xa5408
0000c16d  488bc3                   mov rax, rbx
0000c170  4c3bc3                   cmp r8, rbx
0000c173  490f4fc0                 cmovg rax, r8
0000c177  4889442450               mov qword ptr [rsp + 0x50], rax
0000c17c  4c39ac24c8000000         cmp qword ptr [rsp + 0xc8], r13
0000c184  4c0f4cac24c8000000       cmovl r13, qword ptr [rsp + 0xc8]
0000c18d  4c39a424d0000000         cmp qword ptr [rsp + 0xd0], r12
0000c195  4c0f4ca424d0000000       cmovl r12, qword ptr [rsp + 0xd0]
0000c19e  4c89a424e8000000         mov qword ptr [rsp + 0xe8], r12
0000c1a6  483bf0                   cmp rsi, rax
0000c1a9  488bf0                   mov rsi, rax
0000c1ac  0f8d86920900             jge 0xa5438
0000c1b2  4c3bd0                   cmp r10, rax
0000c1b5  0f8f7d920900             jg 0xa5438
0000c1bb  b901000000               mov ecx, 1
0000c1c0  8bc1                     mov eax, ecx
0000c1c2  4533c0                   xor r8d, r8d
0000c1c5  eb01                     jmp 0xc1c8
0000c1c7  cc                       int3
0000c1c8  488b9424a0000000         mov rdx, qword ptr [rsp + 0xa0]
0000c1d0  4839542470               cmp qword ptr [rsp + 0x70], rdx
0000c1d5  0f8f6d920900             jg 0xa5448
0000c1db  85c0                     test eax, eax
0000c1dd  0f8465920900             je 0xa5448
0000c1e3  418bc0                   mov eax, r8d
0000c1e6  4d8bd0                   mov r10, r8
0000c1e9  eb01                     jmp 0xc1ec
0000c1eb  cc                       int3
0000c1ec  4c89542460               mov qword ptr [rsp + 0x60], r10
0000c1f1  4c8d05884d3100           lea r8, [rip + 0x314d88]
0000c1f8  4b8b4c0750               mov rcx, qword ptr [r15 + r8 + 0x50]
0000c1fd  8b942400030000           mov edx, dword ptr [rsp + 0x300]
0000c204  493bc9                   cmp rcx, r9
0000c207  7c08                     jl 0xc211
0000c209  85c0                     test eax, eax
0000c20b  0f8542920900             jne 0xa5453
0000c211  4f894c0750               mov qword ptr [r15 + r8 + 0x50], r9
0000c216  498bc9                   mov rcx, r9
0000c219  4c8d0d604d3100           lea r9, [rip + 0x314d60]
0000c220  4f395c0f48               cmp qword ptr [r15 + r9 + 0x48], r11
0000c225  7f13                     jg 0xc23a
0000c227  488b442458               mov rax, qword ptr [rsp + 0x58]
0000c22c  483b842490000000         cmp rax, qword ptr [rsp + 0x90]
0000c234  0f8f27920900             jg 0xa5461
0000c23a  4f895c0f48               mov qword ptr [r15 + r9 + 0x48], r11
0000c23f  85ff                     test edi, edi
0000c241  751c                     jne 0xc25f
0000c243  482b4c2428               sub rcx, qword ptr [rsp + 0x28]
0000c248  b800000000               mov eax, 0
0000c24d  480f49c1                 cmovns rax, rcx
0000c251  480305402e3200           add rax, qword ptr [rip + 0x322e40]
0000c258  488905294d3100           mov qword ptr [rip + 0x314d29], rax
0000c25f  c744243800000000         mov dword ptr [rsp + 0x38], 0
0000c267  498db900010000           lea rdi, [r9 + 0x100]
0000c26e  4903ff                   add rdi, r15
0000c271  eb01                     jmp 0xc274
0000c273  cc                       int3
0000c274  4c8b5fd0                 mov r11, qword ptr [rdi - 0x30]
0000c278  8b5710                   mov edx, dword ptr [rdi + 0x10]
0000c27b  83fa01                   cmp edx, 1
0000c27e  0f84b0f3ffff             je 0xb634
0000c284  4f8d042b                 lea r8, [r11 + r13]
0000c288  493bf0                   cmp rsi, r8
0000c28b  4c0f4cc6                 cmovl r8, rsi
0000c28f  4d85d2                   test r10, r10
0000c292  0f85d7910900             jne 0xa546f
0000c298  488b4fd8                 mov rcx, qword ptr [rdi - 0x28]
0000c29c  4903cc                   add rcx, r12
0000c29f  493bc8                   cmp rcx, r8
0000c2a2  4c0f4cc1                 cmovl r8, rcx
0000c2a6  4c8bcb                   mov r9, rbx
0000c2a9  4c3bc3                   cmp r8, rbx
0000c2ac  4d0f4fc8                 cmovg r9, r8
0000c2b0  83fa01                   cmp edx, 1
0000c2b3  0f84cdf3ffff             je 0xb686
0000c2b9  48837c246800             cmp qword ptr [rsp + 0x68], 0
0000c2bf  7413                     je 0xc2d4
0000c2c1  488b442458               mov rax, qword ptr [rsp + 0x58]
0000c2c6  483b842490000000         cmp rax, qword ptr [rsp + 0x90]
0000c2ce  0f8f0e920900             jg 0xa54e2
0000c2d4  be01000000               mov esi, 1
0000c2d9  89742420                 mov dword ptr [rsp + 0x20], esi
0000c2dd  41bc64000000             mov r12d, 0x64
0000c2e3  4c894fc0                 mov qword ptr [rdi - 0x40], r9
0000c2e7  488b8424d8000000         mov rax, qword ptr [rsp + 0xd8]
0000c2ef  488947e0                 mov qword ptr [rdi - 0x20], rax
0000c2f3  448b3f                   mov r15d, dword ptr [rdi]
0000c2f6  488b47f0                 mov rax, qword ptr [rdi - 0x10]
0000c2fa  4885c0                   test rax, rax
0000c2fd  741e                     je 0xc31d
0000c2ff  488d4fb8                 lea rcx, [rdi - 0x48]
0000c303  4c8d442420               lea r8, [rsp + 0x20]
0000c308  488b9424e0000000         mov rdx, qword ptr [rsp + 0xe0]
0000c310  ffd0                     call rax
0000c312  4c8b35bc873000           mov r14, qword ptr [rip + 0x3087bc]
0000c319  8b742420                 mov esi, dword ptr [rsp + 0x20]
0000c31d  8937                     mov dword ptr [rdi], esi
0000c31f  48833d9159320000         cmp qword ptr [rip + 0x325991], 0
0000c327  7413                     je 0xc33c
0000c329  413bf7                   cmp esi, r15d
0000c32c  0f85be910900             jne 0xa54f0
0000c332  41f6c640                 test r14b, 0x40
0000c336  0f85b4910900             jne 0xa54f0
0000c33c  4c8b7c2430               mov r15, qword ptr [rsp + 0x30]
0000c341  488b47d0                 mov rax, qword ptr [rdi - 0x30]
0000c345  488947b8                 mov qword ptr [rdi - 0x48], rax
0000c349  8b442438                 mov eax, dword ptr [rsp + 0x38]
0000c34d  ffc0                     inc eax
0000c34f  89442438                 mov dword ptr [rsp + 0x38], eax
0000c353  4883c760                 add rdi, 0x60
0000c357  83f806                   cmp eax, 6
0000c35a  4c8ba424e8000000         mov r12, qword ptr [rsp + 0xe8]
0000c362  488b742450               mov rsi, qword ptr [rsp + 0x50]
0000c367  4c8b542460               mov r10, qword ptr [rsp + 0x60]
0000c36c  7d0d                     jge 0xc37b
0000c36e  4c8d0d0b4c3100           lea r9, [rip + 0x314c0b]
0000c375  e9fafeffff               jmp 0xc274
0000c37a  cc                       int3
0000c37b  488b8c2480000000         mov rcx, qword ptr [rsp + 0x80]
0000c383  488b8424b8000000         mov rax, qword ptr [rsp + 0xb8]
0000c38b  480fb3c1                 btr rcx, rax
0000c38f  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
0000c397  480fbcf9                 bsf rdi, rcx
0000c39b  41bc00000000             mov r12d, 0
0000c3a1  0f85e3fcffff             jne 0xc08a
0000c3a7  488b9c24f8020000         mov rbx, qword ptr [rsp + 0x2f8]
0000c3af  48891daa2e3200           mov qword ptr [rip + 0x322eaa], rbx
0000c3b6  8bbc24b0000000           mov edi, dword ptr [rsp + 0xb0]
0000c3bd  bb01000000               mov ebx, 1
0000c3c2  4c8d3d9f2e3200           lea r15, [rip + 0x322e9f]
0000c3c9  eb01                     jmp 0xc3cc
0000c3cb  cc                       int3
0000c3cc  85ff                     test edi, edi
0000c3ce  742d                     je 0xc3fd
0000c3d0  0f1f0400                 nop dword ptr [rax + rax]
0000c3d4  0f1f4000                 nop dword ptr [rax]
0000c3d8  0f1f840000000000         nop dword ptr [rax + rax]
0000c3e0  4c8925b12e3200           mov qword ptr [rip + 0x322eb1], r12
0000c3e7  33d2                     xor edx, edx
0000c3e9  498bcf                   mov rcx, r15
0000c3ec  e8ff9affff               call 0x5ef0
0000c3f1  83c7ff                   add edi, -1
0000c3f4  89bc24b0000000           mov dword ptr [rsp + 0xb0], edi
0000c3fb  75e3                     jne 0xc3e0
0000c3fd  8bc3                     mov eax, ebx
0000c3ff  eb01                     jmp 0xc402
0000c401  cc                       int3
0000c402  0f28b424a0020000         movaps xmm6, xmmword ptr [rsp + 0x2a0]
0000c40a  4881c4b0020000           add rsp, 0x2b0
0000c411  415f                     pop r15
0000c413  415e                     pop r14
0000c415  415d                     pop r13
0000c417  415c                     pop r12
0000c419  5f                       pop rdi
0000c41a  5e                       pop rsi
0000c41b  5b                       pop rbx
0000c41c  c3                       ret
