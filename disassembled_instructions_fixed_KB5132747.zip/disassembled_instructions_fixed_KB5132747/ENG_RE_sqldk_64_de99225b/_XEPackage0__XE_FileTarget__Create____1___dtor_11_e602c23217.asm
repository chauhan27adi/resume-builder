; `XEPackage0::XE_FileTarget::Create'::`1'::dtor$11
; sqldk.dll, primary RVA 0x22ffa4, 35 bytes in 1 chunk(s)

; chunk at RVA 0x22ffa4 (35 bytes)
0022ffa4  4055                     push rbp
0022ffa6  4883ec20                 sub rsp, 0x20
0022ffaa  488bea                   mov rbp, rdx
0022ffad  4c8b8580000000           mov r8, qword ptr [rbp + 0x80]
0022ffb4  488b5548                 mov rdx, qword ptr [rbp + 0x48]
0022ffb8  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
0022ffbc  e84f10ddff               call 0x1010
0022ffc1  4883c420                 add rsp, 0x20
0022ffc5  5d                       pop rbp
0022ffc6  c3                       ret
