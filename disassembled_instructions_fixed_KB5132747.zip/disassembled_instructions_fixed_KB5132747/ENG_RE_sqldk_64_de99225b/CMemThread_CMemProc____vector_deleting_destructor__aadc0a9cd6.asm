; CMemThread<CMemProc>::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13dae0, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13dae0 (55 bytes)
0013dae0  48895c2408               mov qword ptr [rsp + 8], rbx
0013dae5  57                       push rdi
0013dae6  4883ec20                 sub rsp, 0x20
0013daea  8bda                     mov ebx, edx
0013daec  488bf9                   mov rdi, rcx
0013daef  e88c51f9ff               call 0xd2c80
0013daf4  83e305                   and ebx, 5
0013daf7  80fb05                   cmp bl, 5
0013dafa  750d                     jne 0x13db09
0013dafc  ba78010000               mov edx, 0x178
0013db01  488bcf                   mov rcx, rdi
0013db04  e80735ecff               call 0x1010
0013db09  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013db0e  488bc7                   mov rax, rdi
0013db11  4883c420                 add rsp, 0x20
0013db15  5f                       pop rdi
0013db16  c3                       ret
