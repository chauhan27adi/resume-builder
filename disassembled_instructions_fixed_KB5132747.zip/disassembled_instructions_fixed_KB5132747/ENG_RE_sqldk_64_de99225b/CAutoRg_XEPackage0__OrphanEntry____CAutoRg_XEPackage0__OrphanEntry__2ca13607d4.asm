; CAutoRg<XEPackage0::OrphanEntry>::~CAutoRg<XEPackage0::OrphanEntry>
; sqldk.dll, primary RVA 0x1ccb50, 79 bytes in 3 chunk(s)

; chunk at RVA 0x1ccb50 (23 bytes)
001ccb50  4883ec28                 sub rsp, 0x28
001ccb54  488b09                   mov rcx, qword ptr [rcx]
001ccb57  4885c9                   test rcx, rcx
001ccb5a  743f                     je 0x1ccb9b
001ccb5c  4c8b41f8                 mov r8, qword ptr [rcx - 8]
001ccb60  4c8d0d29c6ffff           lea r9, [rip - 0x39d7]

; chunk at RVA 0x1ccb67 (51 bytes)
001ccb67  48895c2420               mov qword ptr [rsp + 0x20], rbx
001ccb6c  ba48000000               mov edx, 0x48
001ccb71  488d59f8                 lea rbx, [rcx - 8]
001ccb75  e8a67ce5ff               call 0x24820
001ccb7a  488b03                   mov rax, qword ptr [rbx]
001ccb7d  488bcb                   mov rcx, rbx
001ccb80  488d14c0                 lea rdx, [rax + rax*8]
001ccb84  488d14d508000000         lea rdx, [rdx*8 + 8]
001ccb8c  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
001ccb91  4883c428                 add rsp, 0x28
001ccb95  e996a3e3ff               jmp 0x6f30

; chunk at RVA 0x1ccb9b (5 bytes)
001ccb9b  4883c428                 add rsp, 0x28
001ccb9f  c3                       ret
