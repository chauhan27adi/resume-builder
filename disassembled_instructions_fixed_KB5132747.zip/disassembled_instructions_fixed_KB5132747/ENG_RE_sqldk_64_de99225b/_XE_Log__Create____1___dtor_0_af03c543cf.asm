; `XE_Log::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x215f30, 31 bytes in 1 chunk(s)

; chunk at RVA 0x215f30 (31 bytes)
00215f30  4055                     push rbp
00215f32  4883ec20                 sub rsp, 0x20
00215f36  488bea                   mov rbp, rdx
00215f39  4533c0                   xor r8d, r8d
00215f3c  488b5520                 mov rdx, qword ptr [rbp + 0x20]
00215f40  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
00215f44  e8c7b0deff               call 0x1010
00215f49  4883c420                 add rsp, 0x20
00215f4d  5d                       pop rbp
00215f4e  c3                       ret
