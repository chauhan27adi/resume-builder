; `CXFixedTable::InitFixedTable'::`1'::dtor$2
; sqldk.dll, primary RVA 0x216ce3, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216ce3 (31 bytes)
00216ce3  4055                     push rbp
00216ce5  4883ec20                 sub rsp, 0x20
00216ce9  488bea                   mov rbp, rdx
00216cec  4533c0                   xor r8d, r8d
00216cef  488b5568                 mov rdx, qword ptr [rbp + 0x68]
00216cf3  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00216cf7  e814a3deff               call 0x1010
00216cfc  4883c420                 add rsp, 0x20
00216d00  5d                       pop rbp
00216d01  c3                       ret
