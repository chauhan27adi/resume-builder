; TAutoMutex<UnfairRecursiveMutexInternal<SuspendQueueExpSLock,0>,4294967295>::~TAutoMutex<UnfairRecursiveMutexInternal<SuspendQueueExpSLock,0>,4294967295>
; sqldk.dll, primary RVA 0x94d70, 126 bytes in 3 chunk(s)

; chunk at RVA 0x94d70 (15 bytes)
00094d70  4057                     push rdi
00094d72  4883ec20                 sub rsp, 0x20
00094d76  83790800                 cmp dword ptr [rcx + 8], 0
00094d7a  488bf9                   mov rdi, rcx
00094d7d  7669                     jbe 0x94de8

; chunk at RVA 0x94d7f (105 bytes)
00094d7f  48895c2430               mov qword ptr [rsp + 0x30], rbx
00094d84  4889742438               mov qword ptr [rsp + 0x38], rsi
00094d89  33f6                     xor esi, esi
00094d8b  0f1f440000               nop dword ptr [rax + rax]
00094d90  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00094d99  8b0531022800             mov eax, dword ptr [rip + 0x280231]
00094d9f  8b1513cbf6ff             mov edx, dword ptr [rip - 0x934ed]
00094da5  488b1f                   mov rbx, qword ptr [rdi]
00094da8  498b04c0                 mov rax, qword ptr [r8 + rax*8]
00094dac  4839b41000010000         cmp qword ptr [rax + rdx + 0x100], rsi
00094db4  7507                     jne 0x94dbd
00094db6  33c9                     xor ecx, ecx
00094db8  e8a30ef9ff               call 0x25c60
00094dbd  48836b3801               sub qword ptr [rbx + 0x38], 1
00094dc2  7514                     jne 0x94dd8
00094dc4  48897328                 mov qword ptr [rbx + 0x28], rsi
00094dc8  488bcb                   mov rcx, rbx
00094dcb  48897330                 mov qword ptr [rbx + 0x30], rsi
00094dcf  48897320                 mov qword ptr [rbx + 0x20], rsi
00094dd3  e8a8b7f8ff               call 0x20580
00094dd8  834708ff                 add dword ptr [rdi + 8], -1
00094ddc  75b2                     jne 0x94d90
00094dde  488b742438               mov rsi, qword ptr [rsp + 0x38]
00094de3  488b5c2430               mov rbx, qword ptr [rsp + 0x30]

; chunk at RVA 0x94de8 (6 bytes)
00094de8  4883c420                 add rsp, 0x20
00094dec  5f                       pop rdi
00094ded  c3                       ret
