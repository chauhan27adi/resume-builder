; `StackFramesStore::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22dab0, 62 bytes in 1 chunk(s)

; chunk at RVA 0x22dab0 (62 bytes)
0022dab0  4055                     push rbp
0022dab2  4883ec30                 sub rsp, 0x30
0022dab6  488bea                   mov rbp, rdx
0022dab9  c644242806               mov byte ptr [rsp + 0x28], 6
0022dabe  8b85a0000000             mov eax, dword ptr [rbp + 0xa0]
0022dac4  89442420                 mov dword ptr [rsp + 0x20], eax
0022dac8  4c8d0d59cd0600           lea r9, [rip + 0x6cd59]
0022dacf  41b801000000             mov r8d, 1
0022dad5  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
0022dadc  488b8da8000000           mov rcx, qword ptr [rbp + 0xa8]
0022dae3  e82894ddff               call 0x6f10
0022dae8  4883c430                 add rsp, 0x30
0022daec  5d                       pop rbp
0022daed  c3                       ret
