; SOS_NodeEnum::~SOS_NodeEnum
; sqldk.dll, primary RVA 0xb6540, 27 bytes in 1 chunk(s)

; chunk at RVA 0xb6540 (27 bytes)
000b6540  48894c2408               mov qword ptr [rsp + 8], rcx
000b6545  4883ec38                 sub rsp, 0x38
000b6549  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000b6552  4883c438                 add rsp, 0x38
000b6556  e94500f7ff               jmp 0x265a0
