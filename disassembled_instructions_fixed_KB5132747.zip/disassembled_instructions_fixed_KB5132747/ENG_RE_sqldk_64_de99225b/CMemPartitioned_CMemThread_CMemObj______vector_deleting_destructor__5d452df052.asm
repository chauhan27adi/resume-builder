; CMemPartitioned<CMemThread<CMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xceda0, 104 bytes in 1 chunk(s)

; chunk at RVA 0xceda0 (104 bytes)
000ceda0  48894c2408               mov qword ptr [rsp + 8], rcx
000ceda5  57                       push rdi
000ceda6  4883ec30                 sub rsp, 0x30
000cedaa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cedb3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cedb8  8bda                     mov ebx, edx
000cedba  488bf9                   mov rdi, rcx
000cedbd  488d0524d01700           lea rax, [rip + 0x17d024]
000cedc4  488901                   mov qword ptr [rcx], rax
000cedc7  488d8190020000           lea rax, [rcx + 0x290]
000cedce  4889442450               mov qword ptr [rsp + 0x50], rax
000cedd3  488d0d66ad1600           lea rcx, [rip + 0x16ad66]
000cedda  488908                   mov qword ptr [rax], rcx
000ceddd  488bcf                   mov rcx, rdi
000cede0  e8abb30500               call 0x12a190
000cede5  83e305                   and ebx, 5
000cede8  80fb05                   cmp bl, 5
000cedeb  750d                     jne 0xcedfa
000ceded  bac8020000               mov edx, 0x2c8
000cedf2  488bcf                   mov rcx, rdi
000cedf5  e81622f3ff               call 0x1010
000cedfa  488bc7                   mov rax, rdi
000cedfd  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cee02  4883c430                 add rsp, 0x30
000cee06  5f                       pop rdi
000cee07  c3                       ret
