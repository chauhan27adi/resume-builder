; `ISOSHostImpl::CreateOSAffinityChangeCallback'::`1'::dtor$1
; sqldk.dll, primary RVA 0x229cc4, 59 bytes in 1 chunk(s)

; chunk at RVA 0x229cc4 (59 bytes)
00229cc4  4055                     push rbp
00229cc6  4883ec30                 sub rsp, 0x30
00229cca  488bea                   mov rbp, rdx
00229ccd  c644242806               mov byte ptr [rsp + 0x28], 6
00229cd2  8b8598000000             mov eax, dword ptr [rbp + 0x98]
00229cd8  89442420                 mov dword ptr [rsp + 0x20], eax
00229cdc  4c8d0dfdfe0600           lea r9, [rip + 0x6fefd]
00229ce3  41b801000000             mov r8d, 1
00229ce9  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
00229cf0  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00229cf4  e817d2ddff               call 0x6f10
00229cf9  4883c430                 add rsp, 0x30
00229cfd  5d                       pop rbp
00229cfe  c3                       ret
