; XE_PredicateExpr::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x1fa2f0, 63 bytes in 1 chunk(s)

; chunk at RVA 0x1fa2f0 (63 bytes)
001fa2f0  48894c2408               mov qword ptr [rsp + 8], rcx
001fa2f5  53                       push rbx
001fa2f6  4883ec30                 sub rsp, 0x30
001fa2fa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001fa303  488bd9                   mov rbx, rcx
001fa306  488d0573080b00           lea rax, [rip + 0xb0873]
001fa30d  488901                   mov qword ptr [rcx], rax
001fa310  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
001fa317  f6c201                   test dl, 1
001fa31a  740a                     je 0x1fa326
001fa31c  ba10000000               mov edx, 0x10
001fa321  e80acce0ff               call 0x6f30
001fa326  488bc3                   mov rax, rbx
001fa329  4883c430                 add rsp, 0x30
001fa32d  5b                       pop rbx
001fa32e  c3                       ret
