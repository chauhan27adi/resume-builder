; `XE_MetadataFilter::Init'::`1'::dtor$1
; sqldk.dll, primary RVA 0x2161c0, 37 bytes in 1 chunk(s)

; chunk at RVA 0x2161c0 (37 bytes)
002161c0  4055                     push rbp
002161c2  4883ec20                 sub rsp, 0x20
002161c6  488bea                   mov rbp, rdx
002161c9  4533c0                   xor r8d, r8d
002161cc  488b9500010000           mov rdx, qword ptr [rbp + 0x100]
002161d3  488b8d08010000           mov rcx, qword ptr [rbp + 0x108]
002161da  e831aedeff               call 0x1010
002161df  4883c420                 add rsp, 0x20
002161e3  5d                       pop rbp
002161e4  c3                       ret
