; LowMemoryGuardContext::~LowMemoryGuardContext
; sqldk.dll, primary RVA 0x944a0, 33 bytes in 1 chunk(s)

; chunk at RVA 0x944a0 (33 bytes)
000944a0  48894c2408               mov qword ptr [rsp + 8], rcx
000944a5  4883ec18                 sub rsp, 0x18
000944a9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
000944b1  488d05f02f1b00           lea rax, [rip + 0x1b2ff0]
000944b8  48894140                 mov qword ptr [rcx + 0x40], rax
000944bc  4883c418                 add rsp, 0x18
000944c0  c3                       ret
