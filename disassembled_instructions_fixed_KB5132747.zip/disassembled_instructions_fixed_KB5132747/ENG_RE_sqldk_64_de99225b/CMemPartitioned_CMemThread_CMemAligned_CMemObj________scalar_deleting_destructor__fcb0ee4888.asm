; CMemPartitioned<CMemThread<CMemAligned<CMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcee10, 104 bytes in 1 chunk(s)

; chunk at RVA 0xcee10 (104 bytes)
000cee10  48894c2408               mov qword ptr [rsp + 8], rcx
000cee15  57                       push rdi
000cee16  4883ec30                 sub rsp, 0x30
000cee1a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cee23  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cee28  8bda                     mov ebx, edx
000cee2a  488bf9                   mov rdi, rcx
000cee2d  488d050cd11700           lea rax, [rip + 0x17d10c]
000cee34  488901                   mov qword ptr [rcx], rax
000cee37  488d8198020000           lea rax, [rcx + 0x298]
000cee3e  4889442450               mov qword ptr [rsp + 0x50], rax
000cee43  488d0df6ac1600           lea rcx, [rip + 0x16acf6]
000cee4a  488908                   mov qword ptr [rax], rcx
000cee4d  488bcf                   mov rcx, rdi
000cee50  e81bf60500               call 0x12e470
000cee55  83e305                   and ebx, 5
000cee58  80fb05                   cmp bl, 5
000cee5b  750d                     jne 0xcee6a
000cee5d  bad0020000               mov edx, 0x2d0
000cee62  488bcf                   mov rcx, rdi
000cee65  e8a621f3ff               call 0x1010
000cee6a  488bc7                   mov rax, rdi
000cee6d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cee72  4883c430                 add rsp, 0x30
000cee76  5f                       pop rdi
000cee77  c3                       ret
