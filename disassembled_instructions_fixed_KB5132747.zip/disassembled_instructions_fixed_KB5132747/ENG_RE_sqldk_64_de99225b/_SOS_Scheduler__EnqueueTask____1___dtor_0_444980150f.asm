; `SOS_Scheduler::EnqueueTask'::`1'::dtor$0
; sqldk.dll, primary RVA 0x219e50, 69 bytes in 1 chunk(s)

; chunk at RVA 0x219e50 (69 bytes)
00219e50  4055                     push rbp
00219e52  4883ec30                 sub rsp, 0x30
00219e56  488bea                   mov rbp, rdx
00219e59  488b95e0000000           mov rdx, qword ptr [rbp + 0xe0]
00219e60  4881c2780e0000           add rdx, 0xe78
00219e67  c644242806               mov byte ptr [rsp + 0x28], 6
00219e6c  8b85f8000000             mov eax, dword ptr [rbp + 0xf8]
00219e72  89442420                 mov dword ptr [rsp + 0x20], eax
00219e76  4c8d0df3030600           lea r9, [rip + 0x603f3]
00219e7d  41b801000000             mov r8d, 1
00219e83  488b12                   mov rdx, qword ptr [rdx]
00219e86  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
00219e8a  e881d0deff               call 0x6f10
00219e8f  4883c430                 add rsp, 0x30
00219e93  5d                       pop rbp
00219e94  c3                       ret
