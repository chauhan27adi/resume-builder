; MemObjCache<CMemThread<CMemAligned<CMemFixed> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e710, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13e710 (79 bytes)
0013e710  48894c2408               mov qword ptr [rsp + 8], rcx
0013e715  57                       push rdi
0013e716  4883ec30                 sub rsp, 0x30
0013e71a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e723  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e728  8bda                     mov ebx, edx
0013e72a  488bf9                   mov rdi, rcx
0013e72d  488d0594691200           lea rax, [rip + 0x126994]
0013e734  488901                   mov qword ptr [rcx], rax
0013e737  e82421fcff               call 0x100860
0013e73c  83e305                   and ebx, 5
0013e73f  80fb05                   cmp bl, 5
0013e742  750d                     jne 0x13e751
0013e744  ba38020000               mov edx, 0x238
0013e749  488bcf                   mov rcx, rdi
0013e74c  e8bf28ecff               call 0x1010
0013e751  488bc7                   mov rax, rdi
0013e754  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e759  4883c430                 add rsp, 0x30
0013e75d  5f                       pop rdi
0013e75e  c3                       ret
