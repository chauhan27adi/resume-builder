; `SOS_SharedMemory::Create'::`1'::dtor$1
; sqldk.dll, primary RVA 0x2287c0, 59 bytes in 1 chunk(s)

; chunk at RVA 0x2287c0 (59 bytes)
002287c0  4055                     push rbp
002287c2  4883ec30                 sub rsp, 0x30
002287c6  488bea                   mov rbp, rdx
002287c9  c644242806               mov byte ptr [rsp + 0x28], 6
002287ce  8b4540                   mov eax, dword ptr [rbp + 0x40]
002287d1  89442420                 mov dword ptr [rsp + 0x20], eax
002287d5  4c8d0d04140700           lea r9, [rip + 0x71404]
002287dc  41b801000000             mov r8d, 1
002287e2  488b9508010000           mov rdx, qword ptr [rbp + 0x108]
002287e9  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
002287f0  e81be7ddff               call 0x6f10
002287f5  4883c430                 add rsp, 0x30
002287f9  5d                       pop rbp
002287fa  c3                       ret
