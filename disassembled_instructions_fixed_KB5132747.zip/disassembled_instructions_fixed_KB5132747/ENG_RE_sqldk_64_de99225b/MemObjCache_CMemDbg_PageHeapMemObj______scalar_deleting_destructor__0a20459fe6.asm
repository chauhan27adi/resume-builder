; MemObjCache<CMemDbg<PageHeapMemObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e0d0, 76 bytes in 1 chunk(s)

; chunk at RVA 0x13e0d0 (76 bytes)
0013e0d0  48894c2408               mov qword ptr [rsp + 8], rcx
0013e0d5  57                       push rdi
0013e0d6  4883ec30                 sub rsp, 0x30
0013e0da  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e0e3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e0e8  8bda                     mov ebx, edx
0013e0ea  488bf9                   mov rdi, rcx
0013e0ed  488d0504ba1000           lea rax, [rip + 0x10ba04]
0013e0f4  488901                   mov qword ptr [rcx], rax
0013e0f7  e804430300               call 0x172400
0013e0fc  f6c301                   test bl, 1
0013e0ff  740d                     je 0x13e10e
0013e101  baa0040000               mov edx, 0x4a0
0013e106  488bcf                   mov rcx, rdi
0013e109  e8228eecff               call 0x6f30
0013e10e  488bc7                   mov rax, rdi
0013e111  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e116  4883c430                 add rsp, 0x30
0013e11a  5f                       pop rdi
0013e11b  c3                       ret
