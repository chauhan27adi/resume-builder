; `XE_MetadataStore::DeserializePackageCallback'::`1'::dtor$0
; sqldk.dll, primary RVA 0x216110, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216110 (31 bytes)
00216110  4055                     push rbp
00216112  4883ec20                 sub rsp, 0x20
00216116  488bea                   mov rbp, rdx
00216119  4533c0                   xor r8d, r8d
0021611c  488b5570                 mov rdx, qword ptr [rbp + 0x70]
00216120  488b4d78                 mov rcx, qword ptr [rbp + 0x78]
00216124  e8e7aedeff               call 0x1010
00216129  4883c420                 add rsp, 0x20
0021612d  5d                       pop rbp
0021612e  c3                       ret
