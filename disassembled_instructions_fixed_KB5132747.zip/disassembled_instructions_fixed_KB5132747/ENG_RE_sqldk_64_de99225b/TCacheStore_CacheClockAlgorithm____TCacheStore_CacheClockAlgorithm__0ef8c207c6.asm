; TCacheStore<CacheClockAlgorithm>::~TCacheStore<CacheClockAlgorithm>
; sqldk.dll, primary RVA 0x182220, 231 bytes in 1 chunk(s)

; chunk at RVA 0x182220 (231 bytes)
00182220  48894c2408               mov qword ptr [rsp + 8], rcx
00182225  57                       push rdi
00182226  4883ec30                 sub rsp, 0x30
0018222a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00182233  48895c2450               mov qword ptr [rsp + 0x50], rbx
00182238  488bf9                   mov rdi, rcx
0018223b  488d054ed90c00           lea rax, [rip + 0xcd94e]
00182242  488901                   mov qword ptr [rcx], rax
00182245  488d056c290e00           lea rax, [rip + 0xe296c]
0018224c  48894140                 mov qword ptr [rcx + 0x40], rax
00182250  488b8970060000           mov rcx, qword ptr [rcx + 0x670]
00182257  4885c9                   test rcx, rcx
0018225a  7428                     je 0x182284
0018225c  488d59f8                 lea rbx, [rcx - 8]
00182260  4c8d0d798feeff           lea r9, [rip - 0x117087]
00182267  4c8b03                   mov r8, qword ptr [rbx]
0018226a  ba38000000               mov edx, 0x38
0018226f  e8ac25eaff               call 0x24820
00182274  486b1338                 imul rdx, qword ptr [rbx], 0x38
00182278  4883c208                 add rdx, 8
0018227c  488bcb                   mov rcx, rbx
0018227f  e8ac4ce8ff               call 0x6f30
00182284  33db                     xor ebx, ebx
00182286  48899f70060000           mov qword ptr [rdi + 0x670], rbx
0018228d  48899f58060000           mov qword ptr [rdi + 0x658], rbx
00182294  48899f60060000           mov qword ptr [rdi + 0x660], rbx
0018229b  48899f78060000           mov qword ptr [rdi + 0x678], rbx
001822a2  48899f80060000           mov qword ptr [rdi + 0x680], rbx
001822a9  488b8f500a0000           mov rcx, qword ptr [rdi + 0xa50]
001822b0  4885c9                   test rcx, rcx
001822b3  7427                     je 0x1822dc
001822b5  488d5108                 lea rdx, [rcx + 8]
001822b9  b8ffffffff               mov eax, 0xffffffff
001822be  f00fc102                 lock xadd dword ptr [rdx], eax
001822c2  83f801                   cmp eax, 1
001822c5  750e                     jne 0x1822d5
001822c7  4885d2                   test rdx, rdx
001822ca  7409                     je 0x1822d5
001822cc  488b01                   mov rax, qword ptr [rcx]
001822cf  8d5301                   lea edx, [rbx + 1]
001822d2  ff5048                   call qword ptr [rax + 0x48]
001822d5  48899f500a0000           mov qword ptr [rdi + 0xa50], rbx
001822dc  488d8f90060000           lea rcx, [rdi + 0x690]
001822e3  e8e893eaff               call 0x2b6d0
001822e8  488d8f68080000           lea rcx, [rdi + 0x868]
001822ef  e8dc93eaff               call 0x2b6d0
001822f4  90                       nop
001822f5  488bcf                   mov rcx, rdi
001822f8  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
001822fd  4883c430                 add rsp, 0x30
00182301  5f                       pop rdi
00182302  e9a91bffff               jmp 0x173eb0
