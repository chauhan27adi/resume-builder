; `Worker::Init'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21af10, 66 bytes in 1 chunk(s)

; chunk at RVA 0x21af10 (66 bytes)
0021af10  4055                     push rbp
0021af12  4883ec30                 sub rsp, 0x30
0021af16  488bea                   mov rbp, rdx
0021af19  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0021af1d  4881c2e8030000           add rdx, 0x3e8
0021af24  c644242806               mov byte ptr [rsp + 0x28], 6
0021af29  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0021af2f  89442420                 mov dword ptr [rsp + 0x20], eax
0021af33  4c8d0d56f30500           lea r9, [rip + 0x5f356]
0021af3a  41b801000000             mov r8d, 1
0021af40  488b12                   mov rdx, qword ptr [rdx]
0021af43  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
0021af47  e8c4bfdeff               call 0x6f10
0021af4c  4883c430                 add rsp, 0x30
0021af50  5d                       pop rbp
0021af51  c3                       ret
