; SpinlockHolder<5,8,268435714>::~SpinlockHolder<5,8,268435714>
; sqldk.dll, primary RVA 0x1964f0, 97 bytes in 1 chunk(s)

; chunk at RVA 0x1964f0 (97 bytes)
001964f0  48895c2408               mov qword ptr [rsp + 8], rbx
001964f5  57                       push rdi
001964f6  4883ec20                 sub rsp, 0x20
001964fa  488b39                   mov rdi, qword ptr [rcx]
001964fd  488bd9                   mov rbx, rcx
00196500  4885ff                   test rdi, rdi
00196503  7441                     je 0x196546
00196505  83790800                 cmp dword ptr [rcx + 8], 0
00196509  743b                     je 0x196546
0019650b  803dafef170000           cmp byte ptr [rip + 0x17efaf], 0
00196512  7427                     je 0x19653b
00196514  ff152e350a00             call qword ptr [rip + 0xa352e]
0019651a  448bc0                   mov r8d, eax
0019651d  b867666666               mov eax, 0x66666667
00196522  41f7e8                   imul r8d
00196525  d1fa                     sar edx, 1
00196527  8bca                     mov ecx, edx
00196529  c1e91f                   shr ecx, 0x1f
0019652c  03d1                     add edx, ecx
0019652e  8d0c92                   lea ecx, [rdx + rdx*4]
00196531  443bc1                   cmp r8d, ecx
00196534  7505                     jne 0x19653b
00196536  e855130000               call 0x197890
0019653b  33c0                     xor eax, eax
0019653d  488907                   mov qword ptr [rdi], rax
00196540  488903                   mov qword ptr [rbx], rax
00196543  894308                   mov dword ptr [rbx + 8], eax
00196546  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0019654b  4883c420                 add rsp, 0x20
0019654f  5f                       pop rdi
00196550  c3                       ret
