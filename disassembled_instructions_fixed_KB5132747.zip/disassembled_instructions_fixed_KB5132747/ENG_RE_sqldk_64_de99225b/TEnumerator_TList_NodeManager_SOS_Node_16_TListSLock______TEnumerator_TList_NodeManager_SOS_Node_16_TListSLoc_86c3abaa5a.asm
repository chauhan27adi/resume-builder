; TEnumerator<TList<NodeManager,SOS_Node,16,TListSLock> >::~TEnumerator<TList<NodeManager,SOS_Node,16,TListSLock> >
; sqldk.dll, primary RVA 0xb6570, 151 bytes in 1 chunk(s)

; chunk at RVA 0xb6570 (151 bytes)
000b6570  48895c2410               mov qword ptr [rsp + 0x10], rbx
000b6575  4889742418               mov qword ptr [rsp + 0x18], rsi
000b657a  57                       push rdi
000b657b  4883ec20                 sub rsp, 0x20
000b657f  488bd9                   mov rbx, rcx
000b6582  33f6                     xor esi, esi
000b6584  488b09                   mov rcx, qword ptr [rcx]
000b6587  bfffffffff               mov edi, 0xffffffff
000b658c  4885c9                   test rcx, rcx
000b658f  7421                     je 0xb65b2
000b6591  8bc7                     mov eax, edi
000b6593  f00fc14128               lock xadd dword ptr [rcx + 0x28], eax
000b6598  83f801                   cmp eax, 1
000b659b  7512                     jne 0xb65af
000b659d  48397118                 cmp qword ptr [rcx + 0x18], rsi
000b65a1  740c                     je 0xb65af
000b65a3  488bd1                   mov rdx, rcx
000b65a6  488b4920                 mov rcx, qword ptr [rcx + 0x20]
000b65aa  e8a197f5ff               call 0xfd50
000b65af  488933                   mov qword ptr [rbx], rsi
000b65b2  488b4b08                 mov rcx, qword ptr [rbx + 8]
000b65b6  4885c9                   test rcx, rcx
000b65b9  7420                     je 0xb65db
000b65bb  f00fc17928               lock xadd dword ptr [rcx + 0x28], edi
000b65c0  83ff01                   cmp edi, 1
000b65c3  7512                     jne 0xb65d7
000b65c5  48397118                 cmp qword ptr [rcx + 0x18], rsi
000b65c9  740c                     je 0xb65d7
000b65cb  488bd1                   mov rdx, rcx
000b65ce  488b4920                 mov rcx, qword ptr [rcx + 0x20]
000b65d2  e87997f5ff               call 0xfd50
000b65d7  48897308                 mov qword ptr [rbx + 8], rsi
000b65db  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
000b65df  4885c9                   test rcx, rcx
000b65e2  740f                     je 0xb65f3
000b65e4  8b5320                   mov edx, dword ptr [rbx + 0x20]
000b65e7  e814f6f4ff               call 0x5c00
000b65ec  48897318                 mov qword ptr [rbx + 0x18], rsi
000b65f0  897320                   mov dword ptr [rbx + 0x20], esi
000b65f3  48897310                 mov qword ptr [rbx + 0x10], rsi
000b65f7  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
000b65fc  488b742440               mov rsi, qword ptr [rsp + 0x40]
000b6601  4883c420                 add rsp, 0x20
000b6605  5f                       pop rdi
000b6606  c3                       ret
