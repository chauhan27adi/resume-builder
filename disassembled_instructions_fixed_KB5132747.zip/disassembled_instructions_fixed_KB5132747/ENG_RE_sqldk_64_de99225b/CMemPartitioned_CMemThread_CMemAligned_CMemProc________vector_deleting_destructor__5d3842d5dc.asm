; CMemPartitioned<CMemThread<CMemAligned<CMemProc> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcde70, 104 bytes in 1 chunk(s)

; chunk at RVA 0xcde70 (104 bytes)
000cde70  48894c2408               mov qword ptr [rsp + 8], rcx
000cde75  57                       push rdi
000cde76  4883ec30                 sub rsp, 0x30
000cde7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cde83  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cde88  8bda                     mov ebx, edx
000cde8a  488bf9                   mov rdi, rcx
000cde8d  488d05ec0c1800           lea rax, [rip + 0x180cec]
000cde94  488901                   mov qword ptr [rcx], rax
000cde97  488d8110020000           lea rax, [rcx + 0x210]
000cde9e  4889442450               mov qword ptr [rsp + 0x50], rax
000cdea3  488d0d96bc1600           lea rcx, [rip + 0x16bc96]
000cdeaa  488908                   mov qword ptr [rax], rcx
000cdead  488bcf                   mov rcx, rdi
000cdeb0  e8eb81ffff               call 0xc60a0
000cdeb5  83e305                   and ebx, 5
000cdeb8  80fb05                   cmp bl, 5
000cdebb  750d                     jne 0xcdeca
000cdebd  ba48020000               mov edx, 0x248
000cdec2  488bcf                   mov rcx, rdi
000cdec5  e84631f3ff               call 0x1010
000cdeca  488bc7                   mov rax, rdi
000cdecd  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cded2  4883c430                 add rsp, 0x30
000cded6  5f                       pop rdi
000cded7  c3                       ret
