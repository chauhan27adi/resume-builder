; CMemThread<CMemLargePageObj>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e880, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13e880 (55 bytes)
0013e880  48895c2408               mov qword ptr [rsp + 8], rbx
0013e885  57                       push rdi
0013e886  4883ec20                 sub rsp, 0x20
0013e88a  8bda                     mov ebx, edx
0013e88c  488bf9                   mov rdi, rcx
0013e88f  e88c4efdff               call 0x113720
0013e894  83e305                   and ebx, 5
0013e897  80fb05                   cmp bl, 5
0013e89a  750d                     jne 0x13e8a9
0013e89c  baa0020000               mov edx, 0x2a0
0013e8a1  488bcf                   mov rcx, rdi
0013e8a4  e86727ecff               call 0x1010
0013e8a9  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013e8ae  488bc7                   mov rax, rdi
0013e8b1  4883c420                 add rsp, 0x20
0013e8b5  5f                       pop rdi
0013e8b6  c3                       ret
