; SOS_OnlineNodeEnum::GetNext
; sqldk.dll, primary RVA 0x26930, 241 bytes in 5 chunk(s)

; chunk at RVA 0x2661e (64 bytes)
0002661e  488bcb                   mov rcx, rbx
00026621  e8baf80800               call 0xb5ee0
00026626  33d2                     xor edx, edx
00026628  488bcb                   mov rcx, rbx
0002662b  e840000000               call 0x26670
00026630  4885c0                   test rax, rax
00026633  7424                     je 0x26659
00026635  0f1f00                   nop dword ptr [rax]
00026638  0f1f840000000000         nop dword ptr [rax + rax]
00026640  f6802006000010           test byte ptr [rax + 0x620], 0x10
00026647  7410                     je 0x26659
00026649  488bd0                   mov rdx, rax
0002664c  488bcb                   mov rcx, rbx
0002664f  e81c000000               call 0x26670
00026654  4885c0                   test rax, rax
00026657  75e7                     jne 0x26640
00026659  488b7c2468               mov rdi, qword ptr [rsp + 0x68]

; chunk at RVA 0x2665e (11 bytes)
0002665e  488b742460               mov rsi, qword ptr [rsp + 0x60]
00026663  4883c450                 add rsp, 0x50
00026667  5b                       pop rbx
00026668  c3                       ret

; chunk at RVA 0x26930 (18 bytes)
00026930  4053                     push rbx
00026932  4883ec50                 sub rsp, 0x50
00026936  488bd9                   mov rbx, rcx
00026939  4885d2                   test rdx, rdx
0002693c  0f84a9650100             je 0x3ceeb

; chunk at RVA 0x26942 (52 bytes)
00026942  488bcb                   mov rcx, rbx
00026945  e826fdffff               call 0x26670
0002694a  488bd0                   mov rdx, rax
0002694d  4885c0                   test rax, rax
00026950  740d                     je 0x2695f
00026952  f6822006000010           test byte ptr [rdx + 0x620], 0x10
00026959  0f85d3f60800             jne 0xb6032
0002695f  4885d2                   test rdx, rdx
00026962  7409                     je 0x2696d
00026964  f6822006000002           test byte ptr [rdx + 0x620], 2
0002696b  75d5                     jne 0x26942
0002696d  488bc2                   mov rax, rdx
00026970  4883c450                 add rsp, 0x50
00026974  5b                       pop rbx
00026975  c3                       ret

; chunk at RVA 0x3ceeb (96 bytes)
0003ceeb  4889742460               mov qword ptr [rsp + 0x60], rsi
0003cef0  33f6                     xor esi, esi
0003cef2  8bc6                     mov eax, esi
0003cef4  0f1f4000                 nop dword ptr [rax]
0003cef8  0f1f840000000000         nop dword ptr [rax + rax]
0003cf00  488bd0                   mov rdx, rax
0003cf03  488bcb                   mov rcx, rbx
0003cf06  e86597feff               call 0x26670
0003cf0b  4885c0                   test rax, rax
0003cf0e  7430                     je 0x3cf40
0003cf10  f6802006000010           test byte ptr [rax + 0x620], 0x10
0003cf17  7410                     je 0x3cf29
0003cf19  488bd0                   mov rdx, rax
0003cf1c  488bcb                   mov rcx, rbx
0003cf1f  e84c97feff               call 0x26670
0003cf24  4885c0                   test rax, rax
0003cf27  75e7                     jne 0x3cf10
0003cf29  4885c0                   test rax, rax
0003cf2c  7412                     je 0x3cf40
0003cf2e  f6802006000002           test byte ptr [rax + 0x620], 2
0003cf35  75c9                     jne 0x3cf00
0003cf37  4885c0                   test rax, rax
0003cf3a  0f851e97feff             jne 0x2665e
0003cf40  48897c2468               mov qword ptr [rsp + 0x68], rdi
0003cf45  e94b900700               jmp 0xb5f95
0003cf4a  cc                       int3
