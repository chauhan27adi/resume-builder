; MemoryNode::ShouldShrinkExternalCache
; sqldk.dll, primary RVA 0xa24a0, 151 bytes in 1 chunk(s)

; chunk at RVA 0xa24a0 (151 bytes)
000a24a0  4883ec28                 sub rsp, 0x28
000a24a4  488b5150                 mov rdx, qword ptr [rcx + 0x50]
000a24a8  4c8bc1                   mov r8, rcx
000a24ab  48035148                 add rdx, qword ptr [rcx + 0x48]
000a24af  48035140                 add rdx, qword ptr [rcx + 0x40]
000a24b3  833d5ece280001           cmp dword ptr [rip + 0x28ce5e], 1
000a24ba  750b                     jne 0xa24c7
000a24bc  488b4168                 mov rax, qword ptr [rcx + 0x68]
000a24c0  482b4160                 sub rax, qword ptr [rcx + 0x60]
000a24c4  4803d0                   add rdx, rax
000a24c7  498b8090000000           mov rax, qword ptr [r8 + 0x90]
000a24ce  488b89a8000000           mov rcx, qword ptr [rcx + 0xa8]
000a24d5  483bc8                   cmp rcx, rax
000a24d8  480f4dc8                 cmovge rcx, rax
000a24dc  488d4201                 lea rax, [rdx + 1]
000a24e0  4899                     cqo
000a24e2  482bc2                   sub rax, rdx
000a24e5  48d1f8                   sar rax, 1
000a24e8  483bc8                   cmp rcx, rax
000a24eb  7c40                     jl 0xa252d
000a24ed  498bc8                   mov rcx, r8
000a24f0  e88b42f7ff               call 0x16780
000a24f5  85c0                     test eax, eax
000a24f7  7534                     jne 0xa252d
000a24f9  f605da25270001           test byte ptr [rip + 0x2725da], 1
000a2500  7524                     jne 0xa2526
000a2502  f605d225270002           test byte ptr [rip + 0x2725d2], 2
000a2509  751b                     jne 0xa2526
000a250b  8d4801                   lea ecx, [rax + 1]
000a250e  e8ad31f7ff               call 0x156c0
000a2513  85c0                     test eax, eax
000a2515  740f                     je 0xa2526
000a2517  ff1533132700             call qword ptr [rip + 0x271333]
000a251d  483b05bcfd2600           cmp rax, qword ptr [rip + 0x26fdbc]
000a2524  7f07                     jg 0xa252d
000a2526  33c0                     xor eax, eax
000a2528  4883c428                 add rsp, 0x28
000a252c  c3                       ret
000a252d  b801000000               mov eax, 1
000a2532  4883c428                 add rsp, 0x28
000a2536  c3                       ret
