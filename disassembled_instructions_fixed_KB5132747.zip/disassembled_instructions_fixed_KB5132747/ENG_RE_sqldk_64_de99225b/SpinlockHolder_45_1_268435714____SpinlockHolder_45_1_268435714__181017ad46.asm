; SpinlockHolder<45,1,268435714>::~SpinlockHolder<45,1,268435714>
; sqldk.dll, primary RVA 0x1f7210, 97 bytes in 1 chunk(s)

; chunk at RVA 0x1f7210 (97 bytes)
001f7210  48895c2408               mov qword ptr [rsp + 8], rbx
001f7215  57                       push rdi
001f7216  4883ec20                 sub rsp, 0x20
001f721a  488b39                   mov rdi, qword ptr [rcx]
001f721d  488bd9                   mov rbx, rcx
001f7220  4885ff                   test rdi, rdi
001f7223  7441                     je 0x1f7266
001f7225  83790800                 cmp dword ptr [rcx + 8], 0
001f7229  743b                     je 0x1f7266
001f722b  803d8fe2110000           cmp byte ptr [rip + 0x11e28f], 0
001f7232  7427                     je 0x1f725b
001f7234  ff150e280400             call qword ptr [rip + 0x4280e]
001f723a  448bc0                   mov r8d, eax
001f723d  b867666666               mov eax, 0x66666667
001f7242  41f7e8                   imul r8d
001f7245  d1fa                     sar edx, 1
001f7247  8bca                     mov ecx, edx
001f7249  c1e91f                   shr ecx, 0x1f
001f724c  03d1                     add edx, ecx
001f724e  8d0c92                   lea ecx, [rdx + rdx*4]
001f7251  443bc1                   cmp r8d, ecx
001f7254  7505                     jne 0x1f725b
001f7256  e825000000               call 0x1f7280
001f725b  33c0                     xor eax, eax
001f725d  488907                   mov qword ptr [rdi], rax
001f7260  488903                   mov qword ptr [rbx], rax
001f7263  894308                   mov dword ptr [rbx + 8], eax
001f7266  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001f726b  4883c420                 add rsp, 0x20
001f726f  5f                       pop rdi
001f7270  c3                       ret
