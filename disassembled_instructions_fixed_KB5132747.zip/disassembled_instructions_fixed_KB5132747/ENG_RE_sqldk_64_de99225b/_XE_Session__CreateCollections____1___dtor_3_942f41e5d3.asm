; `XE_Session::CreateCollections'::`1'::dtor$3
; sqldk.dll, primary RVA 0x234bd7, 59 bytes in 1 chunk(s)

; chunk at RVA 0x234bd7 (59 bytes)
00234bd7  4055                     push rbp
00234bd9  4883ec30                 sub rsp, 0x30
00234bdd  488bea                   mov rbp, rdx
00234be0  c644242806               mov byte ptr [rsp + 0x28], 6
00234be5  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00234beb  89442420                 mov dword ptr [rsp + 0x20], eax
00234bef  4c8d0d825c0700           lea r9, [rip + 0x75c82]
00234bf6  41b801000000             mov r8d, 1
00234bfc  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00234c03  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00234c07  e8e452faff               call 0x1d9ef0
00234c0c  4883c430                 add rsp, 0x30
00234c10  5d                       pop rbp
00234c11  c3                       ret
