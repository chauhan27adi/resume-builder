; CMemThread<CMemProc>::PbGetNewPages
; sqldk.dll, primary RVA 0x2f960, 179 bytes in 1 chunk(s)

; chunk at RVA 0x2f960 (179 bytes)
0002f960  48895c2408               mov qword ptr [rsp + 8], rbx
0002f965  48896c2410               mov qword ptr [rsp + 0x10], rbp
0002f96a  4889742418               mov qword ptr [rsp + 0x18], rsi
0002f96f  57                       push rdi
0002f970  4883ec20                 sub rsp, 0x20
0002f974  488d99a0000000           lea rbx, [rcx + 0xa0]
0002f97b  498bf0                   mov rsi, r8
0002f97e  48c7838000000000000000   mov qword ptr [rbx + 0x80], 0
0002f989  488bea                   mov rbp, rdx
0002f98c  488bf9                   mov rdi, rcx
0002f98f  b8ff7fffff               mov eax, 0xffff7fff
0002f994  f00fc14360               lock xadd dword ptr [rbx + 0x60], eax
0002f999  3d01800000               cmp eax, 0x8001
0002f99e  7411                     je 0x2f9b1
0002f9a0  488d4b30                 lea rcx, [rbx + 0x30]
0002f9a4  e887effdff               call 0xe930
0002f9a9  488bcb                   mov rcx, rbx
0002f9ac  e87feffdff               call 0xe930
0002f9b1  488b4f40                 mov rcx, qword ptr [rdi + 0x40]
0002f9b5  4c8bc6                   mov r8, rsi
0002f9b8  488bd5                   mov rdx, rbp
0002f9bb  488b01                   mov rax, qword ptr [rcx]
0002f9be  ff10                     call qword ptr [rax]
0002f9c0  65488b142558000000       mov rdx, qword ptr gs:[0x58]
0002f9c9  488be8                   mov rbp, rax
0002f9cc  8b0dfe552e00             mov ecx, dword ptr [rip + 0x2e55fe]
0002f9d2  8b35e01efdff             mov esi, dword ptr [rip - 0x2e120]
0002f9d8  480334ca                 add rsi, qword ptr [rdx + rcx*8]
0002f9dc  488b9600010000           mov rdx, qword ptr [rsi + 0x100]
0002f9e3  4885d2                   test rdx, rdx
0002f9e6  0f84522c0a00             je 0xd263e
0002f9ec  4c8d8728010000           lea r8, [rdi + 0x128]
0002f9f3  488bcb                   mov rcx, rbx
0002f9f6  e88575fdff               call 0x6f80
0002f9fb  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0002fa00  488bc5                   mov rax, rbp
0002fa03  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
0002fa08  488b742440               mov rsi, qword ptr [rsp + 0x40]
0002fa0d  4883c420                 add rsp, 0x20
0002fa11  5f                       pop rdi
0002fa12  c3                       ret
