; `XEPackage0::HistoryTarget::InitStreams'::`1'::dtor$0
; sqldk.dll, primary RVA 0x232a80, 42 bytes in 1 chunk(s)

; chunk at RVA 0x232a80 (42 bytes)
00232a80  4055                     push rbp
00232a82  4883ec20                 sub rsp, 0x20
00232a86  488bea                   mov rbp, rdx
00232a89  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
00232a8d  4981c030200000           add r8, 0x2030
00232a94  4d8b00                   mov r8, qword ptr [r8]
00232a97  488b5550                 mov rdx, qword ptr [rbp + 0x50]
00232a9b  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00232a9f  e86ce5dcff               call 0x1010
00232aa4  4883c420                 add rsp, 0x20
00232aa8  5d                       pop rbp
00232aa9  c3                       ret
