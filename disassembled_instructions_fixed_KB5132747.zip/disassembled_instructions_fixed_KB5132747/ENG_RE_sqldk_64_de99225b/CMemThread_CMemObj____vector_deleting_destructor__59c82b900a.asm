; CMemThread<CMemObj>::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13ede0, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13ede0 (55 bytes)
0013ede0  48895c2408               mov qword ptr [rsp + 8], rbx
0013ede5  57                       push rdi
0013ede6  4883ec20                 sub rsp, 0x20
0013edea  8bda                     mov ebx, edx
0013edec  488bf9                   mov rdi, rcx
0013edef  e89cb3feff               call 0x12a190
0013edf4  83e305                   and ebx, 5
0013edf7  80fb05                   cmp bl, 5
0013edfa  750d                     jne 0x13ee09
0013edfc  ba00020000               mov edx, 0x200
0013ee01  488bcf                   mov rcx, rdi
0013ee04  e80722ecff               call 0x1010
0013ee09  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013ee0e  488bc7                   mov rax, rdi
0013ee11  4883c420                 add rsp, 0x20
0013ee15  5f                       pop rdi
0013ee16  c3                       ret
