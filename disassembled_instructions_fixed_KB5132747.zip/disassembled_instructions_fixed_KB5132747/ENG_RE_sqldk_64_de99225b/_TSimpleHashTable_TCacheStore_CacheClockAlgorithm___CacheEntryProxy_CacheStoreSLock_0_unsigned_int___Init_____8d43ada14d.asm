; `TSimpleHashTable<TCacheStore<CacheClockAlgorithm>::CacheEntryProxy,CacheStoreSLock,0,unsigned int>::Init'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22d530, 53 bytes in 1 chunk(s)

; chunk at RVA 0x22d530 (53 bytes)
0022d530  4055                     push rbp
0022d532  4883ec30                 sub rsp, 0x30
0022d536  488bea                   mov rbp, rdx
0022d539  c644242806               mov byte ptr [rsp + 0x28], 6
0022d53e  8b4568                   mov eax, dword ptr [rbp + 0x68]
0022d541  89442420                 mov dword ptr [rsp + 0x20], eax
0022d545  4c8d0d84cd0400           lea r9, [rip + 0x4cd84]
0022d54c  41b801000000             mov r8d, 1
0022d552  488b5570                 mov rdx, qword ptr [rbp + 0x70]
0022d556  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0022d55a  e8b199ddff               call 0x6f10
0022d55f  4883c430                 add rsp, 0x30
0022d563  5d                       pop rbp
0022d564  c3                       ret
