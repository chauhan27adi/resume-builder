; `SOS_Node::CompleteStartIO'::`1'::dtor$0
; sqldk.dll, primary RVA 0x218fc0, 66 bytes in 1 chunk(s)

; chunk at RVA 0x218fc0 (66 bytes)
00218fc0  4055                     push rbp
00218fc2  4883ec30                 sub rsp, 0x30
00218fc6  488bea                   mov rbp, rdx
00218fc9  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
00218fd0  4881c240010000           add rdx, 0x140
00218fd7  c644242806               mov byte ptr [rsp + 0x28], 6
00218fdc  8b4544                   mov eax, dword ptr [rbp + 0x44]
00218fdf  89442420                 mov dword ptr [rsp + 0x20], eax
00218fe3  4c8d0d3ee70700           lea r9, [rip + 0x7e73e]
00218fea  41b801000000             mov r8d, 1
00218ff0  488b12                   mov rdx, qword ptr [rdx]
00218ff3  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00218ff7  e814dfdeff               call 0x6f10
00218ffc  4883c430                 add rsp, 0x30
00219000  5d                       pop rbp
00219001  c3                       ret
