; `CXFixedTable::InitFixedTable'::`1'::dtor$0
; sqldk.dll, primary RVA 0x216c90, 37 bytes in 1 chunk(s)

; chunk at RVA 0x216c90 (37 bytes)
00216c90  4055                     push rbp
00216c92  4883ec20                 sub rsp, 0x20
00216c96  488bea                   mov rbp, rdx
00216c99  4533c0                   xor r8d, r8d
00216c9c  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
00216ca3  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
00216caa  e861a3deff               call 0x1010
00216caf  4883c420                 add rsp, 0x20
00216cb3  5d                       pop rbp
00216cb4  c3                       ret
