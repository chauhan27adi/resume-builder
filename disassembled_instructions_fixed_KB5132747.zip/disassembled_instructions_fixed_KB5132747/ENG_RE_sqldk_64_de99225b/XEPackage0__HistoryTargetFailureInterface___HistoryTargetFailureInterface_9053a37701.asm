; XEPackage0::HistoryTargetFailureInterface::~HistoryTargetFailureInterface
; sqldk.dll, primary RVA 0x1bbbe0, 32 bytes in 1 chunk(s)

; chunk at RVA 0x1bbbe0 (32 bytes)
001bbbe0  48894c2408               mov qword ptr [rsp + 8], rcx
001bbbe5  4883ec18                 sub rsp, 0x18
001bbbe9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
001bbbf1  488d0528900c00           lea rax, [rip + 0xc9028]
001bbbf8  488901                   mov qword ptr [rcx], rax
001bbbfb  4883c418                 add rsp, 0x18
001bbbff  c3                       ret
