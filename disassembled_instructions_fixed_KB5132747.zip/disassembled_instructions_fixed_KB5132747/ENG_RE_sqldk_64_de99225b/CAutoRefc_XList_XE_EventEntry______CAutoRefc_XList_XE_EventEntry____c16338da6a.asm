; CAutoRefc<XList<XE_EventEntry> >::~CAutoRefc<XList<XE_EventEntry> >
; sqldk.dll, primary RVA 0x1dc2b0, 63 bytes in 1 chunk(s)

; chunk at RVA 0x1dc2b0 (63 bytes)
001dc2b0  4883ec38                 sub rsp, 0x38
001dc2b4  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001dc2bd  488b09                   mov rcx, qword ptr [rcx]
001dc2c0  4885c9                   test rcx, rcx
001dc2c3  7425                     je 0x1dc2ea
001dc2c5  b8ffffffff               mov eax, 0xffffffff
001dc2ca  f00fc101                 lock xadd dword ptr [rcx], eax
001dc2ce  83f801                   cmp eax, 1
001dc2d1  7517                     jne 0x1dc2ea
001dc2d3  48894c2440               mov qword ptr [rsp + 0x40], rcx
001dc2d8  c701adde0080             mov dword ptr [rcx], 0x8000dead
001dc2de  8d502f                   lea edx, [rax + 0x2f]
001dc2e1  4883c438                 add rsp, 0x38
001dc2e5  e946ace2ff               jmp 0x6f30
001dc2ea  4883c438                 add rsp, 0x38
001dc2ee  c3                       ret
