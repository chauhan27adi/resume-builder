; `XE_StubSession::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235280, 56 bytes in 1 chunk(s)

; chunk at RVA 0x235280 (56 bytes)
00235280  4055                     push rbp
00235282  4883ec30                 sub rsp, 0x30
00235286  488bea                   mov rbp, rdx
00235289  c644242806               mov byte ptr [rsp + 0x28], 6
0023528e  8b4530                   mov eax, dword ptr [rbp + 0x30]
00235291  89442420                 mov dword ptr [rsp + 0x20], eax
00235295  4c8d0d6c560700           lea r9, [rip + 0x7566c]
0023529c  41b801000000             mov r8d, 1
002352a2  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
002352a9  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
002352ad  e83e4cfaff               call 0x1d9ef0
002352b2  4883c430                 add rsp, 0x30
002352b6  5d                       pop rbp
002352b7  c3                       ret
