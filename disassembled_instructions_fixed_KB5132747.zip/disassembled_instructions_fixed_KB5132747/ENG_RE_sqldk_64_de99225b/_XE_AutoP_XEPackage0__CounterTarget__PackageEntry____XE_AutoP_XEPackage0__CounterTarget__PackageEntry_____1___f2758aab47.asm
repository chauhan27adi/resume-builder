; `XE_AutoP<XEPackage0::CounterTarget::PackageEntry>::~XE_AutoP<XEPackage0::CounterTarget::PackageEntry>'::`1'::dtor$1
; sqldk.dll, primary RVA 0x231b20, 42 bytes in 1 chunk(s)

; chunk at RVA 0x231b20 (42 bytes)
00231b20  4055                     push rbp
00231b22  4883ec20                 sub rsp, 0x20
00231b26  488bea                   mov rbp, rdx
00231b29  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
00231b2d  4c8d0d5c58e1ff           lea r9, [rip - 0x1ea7a4]
00231b34  41b880000000             mov r8d, 0x80
00231b3a  ba18000000               mov edx, 0x18
00231b3f  e8dc2cdfff               call 0x24820
00231b44  4883c420                 add rsp, 0x20
00231b48  5d                       pop rbp
00231b49  c3                       ret
