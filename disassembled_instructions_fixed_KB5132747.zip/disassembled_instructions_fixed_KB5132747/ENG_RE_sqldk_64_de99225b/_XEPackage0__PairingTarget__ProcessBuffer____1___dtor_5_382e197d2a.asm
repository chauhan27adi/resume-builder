; `XEPackage0::PairingTarget::ProcessBuffer'::`1'::dtor$5
; sqldk.dll, primary RVA 0x230ee4, 41 bytes in 1 chunk(s)

; chunk at RVA 0x230ee4 (41 bytes)
00230ee4  4055                     push rbp
00230ee6  4883ec20                 sub rsp, 0x20
00230eea  488bea                   mov rbp, rdx
00230eed  4c8b8568010000           mov r8, qword ptr [rbp + 0x168]
00230ef4  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
00230efb  488b8db0000000           mov rcx, qword ptr [rbp + 0xb0]
00230f02  e80901ddff               call 0x1010
00230f07  4883c420                 add rsp, 0x20
00230f0b  5d                       pop rbp
00230f0c  c3                       ret
