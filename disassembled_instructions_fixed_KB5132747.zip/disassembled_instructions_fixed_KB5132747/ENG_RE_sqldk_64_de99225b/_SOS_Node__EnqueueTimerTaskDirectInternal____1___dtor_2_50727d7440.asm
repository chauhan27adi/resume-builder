; `SOS_Node::EnqueueTimerTaskDirectInternal'::`1'::dtor$2
; sqldk.dll, primary RVA 0x21d660, 63 bytes in 1 chunk(s)

; chunk at RVA 0x21d660 (63 bytes)
0021d660  4055                     push rbp
0021d662  4883ec30                 sub rsp, 0x30
0021d666  488bea                   mov rbp, rdx
0021d669  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0021d66d  4881c2780e0000           add rdx, 0xe78
0021d674  c644242806               mov byte ptr [rsp + 0x28], 6
0021d679  8b4550                   mov eax, dword ptr [rbp + 0x50]
0021d67c  89442420                 mov dword ptr [rsp + 0x20], eax
0021d680  4c8d0de9cb0500           lea r9, [rip + 0x5cbe9]
0021d687  41b801000000             mov r8d, 1
0021d68d  488b12                   mov rdx, qword ptr [rdx]
0021d690  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0021d694  e87798deff               call 0x6f10
0021d699  4883c430                 add rsp, 0x30
0021d69d  5d                       pop rbp
0021d69e  c3                       ret
