; `ISOSHostImpl::CreateIOCompRequest'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22b00c, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22b00c (59 bytes)
0022b00c  4055                     push rbp
0022b00e  4883ec30                 sub rsp, 0x30
0022b012  488bea                   mov rbp, rdx
0022b015  c644242806               mov byte ptr [rsp + 0x28], 6
0022b01a  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0022b020  89442420                 mov dword ptr [rsp + 0x20], eax
0022b024  4c8d0db5eb0600           lea r9, [rip + 0x6ebb5]
0022b02b  41b801000000             mov r8d, 1
0022b031  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
0022b038  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022b03c  e8cfbeddff               call 0x6f10
0022b041  4883c430                 add rsp, 0x30
0022b045  5d                       pop rbp
0022b046  c3                       ret
