; CMemThread<CMemAligned<CMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13eea0, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13eea0 (55 bytes)
0013eea0  48895c2408               mov qword ptr [rsp + 8], rbx
0013eea5  57                       push rdi
0013eea6  4883ec20                 sub rsp, 0x20
0013eeaa  8bda                     mov ebx, edx
0013eeac  488bf9                   mov rdi, rcx
0013eeaf  e8bcf5feff               call 0x12e470
0013eeb4  83e305                   and ebx, 5
0013eeb7  80fb05                   cmp bl, 5
0013eeba  750d                     jne 0x13eec9
0013eebc  ba08020000               mov edx, 0x208
0013eec1  488bcf                   mov rcx, rdi
0013eec4  e84721ecff               call 0x1010
0013eec9  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013eece  488bc7                   mov rax, rdi
0013eed1  4883c420                 add rsp, 0x20
0013eed5  5f                       pop rdi
0013eed6  c3                       ret
