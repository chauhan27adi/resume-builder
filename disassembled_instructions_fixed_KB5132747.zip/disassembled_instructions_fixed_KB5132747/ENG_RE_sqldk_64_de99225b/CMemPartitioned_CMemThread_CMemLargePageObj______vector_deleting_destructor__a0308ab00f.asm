; CMemPartitioned<CMemThread<CMemLargePageObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce9d0, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce9d0 (104 bytes)
000ce9d0  48894c2408               mov qword ptr [rsp + 8], rcx
000ce9d5  57                       push rdi
000ce9d6  4883ec30                 sub rsp, 0x30
000ce9da  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce9e3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce9e8  8bda                     mov ebx, edx
000ce9ea  488bf9                   mov rdi, rcx
000ce9ed  488d05acde1700           lea rax, [rip + 0x17deac]
000ce9f4  488901                   mov qword ptr [rcx], rax
000ce9f7  488d8130030000           lea rax, [rcx + 0x330]
000ce9fe  4889442450               mov qword ptr [rsp + 0x50], rax
000cea03  488d0d36b11600           lea rcx, [rip + 0x16b136]
000cea0a  488908                   mov qword ptr [rax], rcx
000cea0d  488bcf                   mov rcx, rdi
000cea10  e80b4d0400               call 0x113720
000cea15  83e305                   and ebx, 5
000cea18  80fb05                   cmp bl, 5
000cea1b  750d                     jne 0xcea2a
000cea1d  ba68030000               mov edx, 0x368
000cea22  488bcf                   mov rcx, rdi
000cea25  e8e625f3ff               call 0x1010
000cea2a  488bc7                   mov rax, rdi
000cea2d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cea32  4883c430                 add rsp, 0x30
000cea36  5f                       pop rdi
000cea37  c3                       ret
