; TList<SchedulerManager,Worker,24,TListSLock>::AppendElem
; sqldk.dll, primary RVA 0x269b0, 266 bytes in 5 chunk(s)

; chunk at RVA 0x269b0 (20 bytes)
000269b0  4057                     push rdi
000269b2  4154                     push r12
000269b4  4883ec48                 sub rsp, 0x48
000269b8  658b042548000000         mov eax, dword ptr gs:[0x48]
000269c0  488d7910                 lea rdi, [rcx + 0x10]

; chunk at RVA 0x269c4 (66 bytes)
000269c4  48895c2440               mov qword ptr [rsp + 0x40], rbx
000269c9  4533e4                   xor r12d, r12d
000269cc  4889742430               mov qword ptr [rsp + 0x30], rsi
000269d1  418bdc                   mov ebx, r12d
000269d4  4c89742428               mov qword ptr [rsp + 0x28], r14
000269d9  488bf1                   mov rsi, rcx
000269dc  448bf0                   mov r14d, eax
000269df  8b07                     mov eax, dword ptr [rdi]
000269e1  4c897c2420               mov qword ptr [rsp + 0x20], r15
000269e6  4c8bfa                   mov r15, rdx
000269e9  85c0                     test eax, eax
000269eb  0f85f0000100             jne 0x36ae1
000269f1  33c0                     xor eax, eax
000269f3  f04c0fb137               lock cmpxchg qword ptr [rdi], r14
000269f8  418bc4                   mov eax, r12d
000269fb  0f94c0                   sete al
000269fe  85c0                     test eax, eax
00026a00  0f84db000100             je 0x36ae1

; chunk at RVA 0x26a06 (64 bytes)
00026a06  488b06                   mov rax, qword ptr [rsi]
00026a09  498d4f18                 lea rcx, [r15 + 0x18]
00026a0d  4c8b742428               mov r14, qword ptr [rsp + 0x28]
00026a12  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00026a17  488901                   mov qword ptr [rcx], rax
00026a1a  488b06                   mov rax, qword ptr [rsi]
00026a1d  48894808                 mov qword ptr [rax + 8], rcx
00026a21  48890e                   mov qword ptr [rsi], rcx
00026a24  48897108                 mov qword ptr [rcx + 8], rsi
00026a28  ff4618                   inc dword ptr [rsi + 0x18]
00026a2b  49897728                 mov qword ptr [r15 + 0x28], rsi
00026a2f  4438258bea2e00           cmp byte ptr [rip + 0x2eea8b], r12b
00026a36  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
00026a3b  488b742430               mov rsi, qword ptr [rsp + 0x30]
00026a40  0f857ab70400             jne 0x721c0

; chunk at RVA 0x36aec (66 bytes)
00036aec  48896c2438               mov qword ptr [rsp + 0x38], rbp
00036af1  498bec                   mov rbp, r12
00036af4  3c84                     cmp al, 0x84
00036af6  0f8415b60300             je 0x72111
00036afc  f605d4df2d0080           test byte ptr [rip + 0x2ddfd4], 0x80
00036b03  488bcf                   mov rcx, rdi
00036b06  0f8464b60300             je 0x72170
00036b0c  4d8bc6                   mov r8, r14
00036b0f  488bd5                   mov rdx, rbp
00036b12  e899250000               call 0x390b0
00036b17  eb01                     jmp 0x36b1a
00036b19  cc                       int3
00036b1a  4885ed                   test rbp, rbp
00036b1d  0f855cb60300             jne 0x7217f
00036b23  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
00036b28  e9d9fefeff               jmp 0x26a06
00036b2d  cc                       int3

; chunk at RVA 0x721c0 (50 bytes)
000721c0  ff1582781c00             call qword ptr [rip + 0x1c7882]
000721c6  448bc0                   mov r8d, eax
000721c9  b867666666               mov eax, 0x66666667
000721ce  41f7e8                   imul r8d
000721d1  d1fa                     sar edx, 1
000721d3  8bca                     mov ecx, edx
000721d5  c1e91f                   shr ecx, 0x1f
000721d8  03d1                     add edx, ecx
000721da  8d0c92                   lea ecx, [rdx + rdx*4]
000721dd  443bc1                   cmp r8d, ecx
000721e0  0f856048fbff             jne 0x26a46
000721e6  e8f584ffff               call 0x6a6e0
000721eb  90                       nop
000721ec  e95548fbff               jmp 0x26a46
000721f1  cc                       int3
