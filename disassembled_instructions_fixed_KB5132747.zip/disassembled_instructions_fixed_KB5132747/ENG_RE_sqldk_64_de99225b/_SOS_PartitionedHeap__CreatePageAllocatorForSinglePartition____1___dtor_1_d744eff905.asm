; `SOS_PartitionedHeap::CreatePageAllocatorForSinglePartition'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22dd40, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22dd40 (59 bytes)
0022dd40  4055                     push rbp
0022dd42  4883ec30                 sub rsp, 0x30
0022dd46  488bea                   mov rbp, rdx
0022dd49  c644242806               mov byte ptr [rsp + 0x28], 6
0022dd4e  8b85a0000000             mov eax, dword ptr [rbp + 0xa0]
0022dd54  89442420                 mov dword ptr [rsp + 0x20], eax
0022dd58  4c8d0df10f0700           lea r9, [rip + 0x70ff1]
0022dd5f  41b801000000             mov r8d, 1
0022dd65  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
0022dd6c  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022dd70  e89b91ddff               call 0x6f10
0022dd75  4883c430                 add rsp, 0x30
0022dd79  5d                       pop rbp
0022dd7a  c3                       ret
