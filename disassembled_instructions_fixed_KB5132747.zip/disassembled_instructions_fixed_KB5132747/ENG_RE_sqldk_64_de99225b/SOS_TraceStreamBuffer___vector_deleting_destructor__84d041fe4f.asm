; SOS_TraceStreamBuffer::`vector deleting destructor'
; sqldk.dll, primary RVA 0x57f00, 67 bytes in 1 chunk(s)

; chunk at RVA 0x57f00 (67 bytes)
00057f00  48894c2408               mov qword ptr [rsp + 8], rcx
00057f05  57                       push rdi
00057f06  4883ec30                 sub rsp, 0x30
00057f0a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00057f13  48895c2448               mov qword ptr [rsp + 0x48], rbx
00057f18  8bda                     mov ebx, edx
00057f1a  488bf9                   mov rdi, rcx
00057f1d  ff15a5181e00             call qword ptr [rip + 0x1e18a5]
00057f23  f6c301                   test bl, 1
00057f26  740d                     je 0x57f35
00057f28  ba68000000               mov edx, 0x68
00057f2d  488bcf                   mov rcx, rdi
00057f30  e8fbeffaff               call 0x6f30
00057f35  488bc7                   mov rax, rdi
00057f38  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00057f3d  4883c430                 add rsp, 0x30
00057f41  5f                       pop rdi
00057f42  c3                       ret
