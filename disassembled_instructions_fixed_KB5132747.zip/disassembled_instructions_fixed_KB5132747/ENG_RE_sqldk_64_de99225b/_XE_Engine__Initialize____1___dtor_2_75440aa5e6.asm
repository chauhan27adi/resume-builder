; `XE_Engine::Initialize'::`1'::dtor$2
; sqldk.dll, primary RVA 0x233f84, 56 bytes in 1 chunk(s)

; chunk at RVA 0x233f84 (56 bytes)
00233f84  4055                     push rbp
00233f86  4883ec30                 sub rsp, 0x30
00233f8a  488bea                   mov rbp, rdx
00233f8d  c644242806               mov byte ptr [rsp + 0x28], 6
00233f92  8b4530                   mov eax, dword ptr [rbp + 0x30]
00233f95  89442420                 mov dword ptr [rsp + 0x20], eax
00233f99  4c8d0d00680700           lea r9, [rip + 0x76800]
00233fa0  41b801000000             mov r8d, 1
00233fa6  488b1513e71700           mov rdx, qword ptr [rip + 0x17e713]
00233fad  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00233fb1  e83a5ffaff               call 0x1d9ef0
00233fb6  4883c430                 add rsp, 0x30
00233fba  5d                       pop rbp
00233fbb  c3                       ret
