; CAlgTableMetadata::LoadColumns
; sqllang.dll, primary RVA 0xac1f0, 803 bytes in 1 chunk(s)

; chunk at RVA 0xac1f0 (803 bytes)
000ac1f0  4055                     push rbp
000ac1f2  56                       push rsi
000ac1f3  57                       push rdi
000ac1f4  4154                     push r12
000ac1f6  4155                     push r13
000ac1f8  4156                     push r14
000ac1fa  4157                     push r15
000ac1fc  488d6c24d9               lea rbp, [rsp - 0x27]
000ac201  4881ecf0000000           sub rsp, 0xf0
000ac208  48c745d7feffffff         mov qword ptr [rbp - 0x29], 0xfffffffffffffffe
000ac210  48899c2448010000         mov qword ptr [rsp + 0x148], rbx
000ac218  488b0569daa202           mov rax, qword ptr [rip + 0x2a2da69]
000ac21f  4833c4                   xor rax, rsp
000ac222  48894517                 mov qword ptr [rbp + 0x17], rax
000ac226  44884587                 mov byte ptr [rbp - 0x79], r8b
000ac22a  488bf2                   mov rsi, rdx
000ac22d  488bd9                   mov rbx, rcx
000ac230  4c8b6228                 mov r12, qword ptr [rdx + 0x28]
000ac234  4c8965bf                 mov qword ptr [rbp - 0x41], r12
000ac238  4c8965df                 mov qword ptr [rbp - 0x21], r12
000ac23c  4c8baa80010000           mov r13, qword ptr [rdx + 0x180]
000ac243  488b4918                 mov rcx, qword ptr [rcx + 0x18]
000ac247  488b01                   mov rax, qword ptr [rcx]
000ac24a  ff5078                   call qword ptr [rax + 0x78]
000ac24d  4c8bf0                   mov r14, rax
000ac250  488945c7                 mov qword ptr [rbp - 0x39], rax
000ac254  654c8b042558000000       mov r8, qword ptr gs:[0x58]
000ac25d  488b0d14ede101           mov rcx, qword ptr [rip + 0x1e1ed14]
000ac264  8b11                     mov edx, dword ptr [rcx]
000ac266  488b0d13ede101           mov rcx, qword ptr [rip + 0x1e1ed13]
000ac26d  8b09                     mov ecx, dword ptr [rcx]
000ac26f  49030cd0                 add rcx, qword ptr [r8 + rdx*8]
000ac273  488b09                   mov rcx, qword ptr [rcx]
000ac276  488b5150                 mov rdx, qword ptr [rcx + 0x50]
000ac27a  0fb74208                 movzx eax, word ptr [rdx + 8]
000ac27e  6689458b                 mov word ptr [rbp - 0x75], ax
000ac282  837b1005                 cmp dword ptr [rbx + 0x10], 5
000ac286  0f8437579d00             je 0xa819c3
000ac28c  0fb78380000000           movzx eax, word ptr [rbx + 0x80]
000ac293  66894589                 mov word ptr [rbp - 0x77], ax
000ac297  488b8318010000           mov rax, qword ptr [rbx + 0x118]
000ac29e  488945cf                 mov qword ptr [rbp - 0x31], rax
000ac2a2  bfffffffff               mov edi, 0xffffffff
000ac2a7  4885c0                   test rax, rax
000ac2aa  0f852c010000             jne 0xac3dc
000ac2b0  498b06                   mov rax, qword ptr [r14]
000ac2b3  33d2                     xor edx, edx
000ac2b5  498bce                   mov rcx, r14
000ac2b8  ff90d0000000             call qword ptr [rax + 0xd0]
000ac2be  898314010000             mov dword ptr [rbx + 0x114], eax
000ac2c4  498b06                   mov rax, qword ptr [r14]
000ac2c7  ba01000000               mov edx, 1
000ac2cc  498bce                   mov rcx, r14
000ac2cf  ff90d0000000             call qword ptr [rax + 0xd0]
000ac2d5  2b8314010000             sub eax, dword ptr [rbx + 0x114]
000ac2db  898320010000             mov dword ptr [rbx + 0x120], eax
000ac2e1  837b1000                 cmp dword ptr [rbx + 0x10], 0
000ac2e5  7514                     jne 0xac2fb
000ac2e7  498b06                   mov rax, qword ptr [r14]
000ac2ea  498bce                   mov rcx, r14
000ac2ed  ff90a8000000             call qword ptr [rax + 0xa8]
000ac2f3  3bc7                     cmp eax, edi
000ac2f5  0f85e3569d00             jne 0xa819de
000ac2fb  32c0                     xor al, al
000ac2fd  80a31e020000fb           and byte ptr [rbx + 0x21e], 0xfb
000ac304  08831e020000             or byte ptr [rbx + 0x21e], al
000ac30a  c745af510a0000           mov dword ptr [rbp - 0x51], 0xa51
000ac311  c644242003               mov byte ptr [rsp + 0x20], 3
000ac316  41b9510a0000             mov r9d, 0xa51
000ac31c  4c8d056d080702           lea r8, [rip + 0x207086d]
000ac323  498bd4                   mov rdx, r12
000ac326  b940000000               mov ecx, 0x40
000ac32b  ff157febe101             call qword ptr [rip + 0x1e1eb7f]
000ac331  488bf8                   mov rdi, rax
000ac334  488945b7                 mov qword ptr [rbp - 0x49], rax
000ac338  41bf00040000             mov r15d, 0x400
000ac33e  4885c0                   test rax, rax
000ac341  0f849f569d00             je 0xa819e6
000ac347  8b8b14010000             mov ecx, dword ptr [rbx + 0x114]
000ac34d  458bc7                   mov r8d, r15d
000ac350  413bcf                   cmp ecx, r15d
000ac353  440f42c1                 cmovb r8d, ecx
000ac357  498bd4                   mov rdx, r12
000ac35a  488bc8                   mov rcx, rax
000ac35d  e8cecefeff               call 0x99230
000ac362  90                       nop
000ac363  488d05160e0702           lea rax, [rip + 0x2070e16]
000ac36a  488907                   mov qword ptr [rdi], rax
000ac36d  eb01                     jmp 0xac370
000ac36f  cc                       int3
000ac370  4889bb18010000           mov qword ptr [rbx + 0x118], rdi
000ac377  c745af540a0000           mov dword ptr [rbp - 0x51], 0xa54
000ac37e  c644242003               mov byte ptr [rsp + 0x20], 3
000ac383  41b9540a0000             mov r9d, 0xa54
000ac389  4c8d0500080702           lea r8, [rip + 0x2070800]
000ac390  498bd4                   mov rdx, r12
000ac393  b938000000               mov ecx, 0x38
000ac398  ff1512ebe101             call qword ptr [rip + 0x1e1eb12]
000ac39e  488945b7                 mov qword ptr [rbp - 0x49], rax
000ac3a2  4885c0                   test rax, rax
000ac3a5  741c                     je 0xac3c3
000ac3a7  8b8b14010000             mov ecx, dword ptr [rbx + 0x114]
000ac3ad  413bcf                   cmp ecx, r15d
000ac3b0  440f42f9                 cmovb r15d, ecx
000ac3b4  458bc7                   mov r8d, r15d
000ac3b7  498bd4                   mov rdx, r12
000ac3ba  488bc8                   mov rcx, rax
000ac3bd  e8fe510000               call 0xb15c0
000ac3c2  90                       nop
000ac3c3  488983c0010000           mov qword ptr [rbx + 0x1c0], rax
000ac3ca  83bb2001000000           cmp dword ptr [rbx + 0x120], 0
000ac3d1  0f8501311400             jne 0x1ef4d8
000ac3d7  bfffffffff               mov edi, 0xffffffff
000ac3dc  488b06                   mov rax, qword ptr [rsi]
000ac3df  488bce                   mov rcx, rsi
000ac3e2  ff5018                   call qword ptr [rax + 0x18]
000ac3e5  3dfd000000               cmp eax, 0xfd
000ac3ea  410f94c7                 sete r15b
000ac3ee  498b8d80000000           mov rcx, qword ptr [r13 + 0x80]
000ac3f5  e816fbffff               call 0xabf10
000ac3fa  84c0                     test al, al
000ac3fc  0f85f4559d00             jne 0xa819f6
000ac402  4532e4                   xor r12b, r12b
000ac405  48c7459f00000000         mov qword ptr [rbp - 0x61], 0
000ac40d  4c89758f                 mov qword ptr [rbp - 0x71], r14
000ac411  48c7459701000000         mov qword ptr [rbp - 0x69], 1
000ac419  498b06                   mov rax, qword ptr [r14]
000ac41c  498bce                   mov rcx, r14
000ac41f  ff90a8000000             call qword ptr [rax + 0xa8]
000ac425  3bc7                     cmp eax, edi
000ac427  0f85ec559d00             jne 0xa81a19
000ac42d  33ff                     xor edi, edi
000ac42f  4c8b6dbf                 mov r13, qword ptr [rbp - 0x41]
000ac433  440fb77589               movzx r14d, word ptr [rbp - 0x77]
000ac438  0f1f840000000000         nop dword ptr [rax + rax]
000ac440  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
000ac444  488b01                   mov rax, qword ptr [rcx]
000ac447  48837d9f00               cmp qword ptr [rbp - 0x61], 0
000ac44c  0f850b569d00             jne 0xa81a5d
000ac452  8b5597                   mov edx, dword ptr [rbp - 0x69]
000ac455  ff90d0000000             call qword ptr [rax + 0xd0]
000ac45b  8b559b                   mov edx, dword ptr [rbp - 0x65]
000ac45e  3bd0                     cmp edx, eax
000ac460  0f8351090000             jae 0xacdb7
000ac466  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
000ac46a  488b01                   mov rax, qword ptr [rcx]
000ac46d  ffc2                     inc edx
000ac46f  448b4597                 mov r8d, dword ptr [rbp - 0x69]
000ac473  ff90e0000000             call qword ptr [rax + 0xe0]
000ac479  eb01                     jmp 0xac47c
000ac47b  cc                       int3
000ac47c  4885c0                   test rax, rax
000ac47f  0f840c0e0000             je 0xad291
000ac485  c644244800               mov byte ptr [rsp + 0x48], 0
000ac48a  0fb64d87                 movzx ecx, byte ptr [rbp - 0x79]
000ac48e  884c2440                 mov byte ptr [rsp + 0x40], cl
000ac492  4889742438               mov qword ptr [rsp + 0x38], rsi
000ac497  4c896c2430               mov qword ptr [rsp + 0x30], r13
000ac49c  4488642428               mov byte ptr [rsp + 0x28], r12b
000ac4a1  44887c2420               mov byte ptr [rsp + 0x20], r15b
000ac4a6  450fb7ce                 movzx r9d, r14w
000ac4aa  440fb7458b               movzx r8d, word ptr [rbp - 0x75]
000ac4af  488bd0                   mov rdx, rax
000ac4b2  488bcb                   mov rcx, rbx
000ac4b5  e866000000               call 0xac520
000ac4ba  488b4d9f                 mov rcx, qword ptr [rbp - 0x61]
000ac4be  4885c9                   test rcx, rcx
000ac4c1  0f85a7559d00             jne 0xa81a6e
000ac4c7  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
000ac4cb  488b01                   mov rax, qword ptr [rcx]
000ac4ce  8b5597                   mov edx, dword ptr [rbp - 0x69]
000ac4d1  ff90d0000000             call qword ptr [rax + 0xd0]
000ac4d7  8b4d9b                   mov ecx, dword ptr [rbp - 0x65]
000ac4da  3bc8                     cmp ecx, eax
000ac4dc  7308                     jae 0xac4e6
000ac4de  ffc1                     inc ecx
000ac4e0  894d9b                   mov dword ptr [rbp - 0x65], ecx
000ac4e3  eb01                     jmp 0xac4e6
000ac4e5  cc                       int3
000ac4e6  ffc7                     inc edi
000ac4e8  40f6c77f                 test dil, 0x7f
000ac4ec  0f854effffff             jne 0xac440
000ac4f2  488d8e2c020000           lea rcx, [rsi + 0x22c]
000ac4f9  e82254fbff               call 0x61920
000ac4fe  84c0                     test al, al
000ac500  0f843affffff             je 0xac440
000ac506  b15c                     mov cl, 0x5c
000ac508  e84351fbff               call 0x61650
000ac50d  e92effffff               jmp 0xac440
000ac512  cc                       int3
