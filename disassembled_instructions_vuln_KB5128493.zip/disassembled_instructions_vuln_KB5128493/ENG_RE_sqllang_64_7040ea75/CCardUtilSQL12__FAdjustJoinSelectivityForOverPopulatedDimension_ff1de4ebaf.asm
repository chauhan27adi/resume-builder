; CCardUtilSQL12::FAdjustJoinSelectivityForOverPopulatedDimension
; sqllang.dll, primary RVA 0x26c9a0, 667 bytes in 1 chunk(s)

; chunk at RVA 0x26c9a0 (667 bytes)
0026c9a0  488bc4                   mov rax, rsp
0026c9a3  48894808                 mov qword ptr [rax + 8], rcx
0026c9a7  55                       push rbp
0026c9a8  56                       push rsi
0026c9a9  57                       push rdi
0026c9aa  4154                     push r12
0026c9ac  4155                     push r13
0026c9ae  4156                     push r14
0026c9b0  4157                     push r15
0026c9b2  488d68b1                 lea rbp, [rax - 0x4f]
0026c9b6  4881ecc0000000           sub rsp, 0xc0
0026c9bd  48c7459ffeffffff         mov qword ptr [rbp - 0x61], 0xfffffffffffffffe
0026c9c5  48895810                 mov qword ptr [rax + 0x10], rbx
0026c9c9  0f2970b8                 movaps xmmword ptr [rax - 0x48], xmm6
0026c9cd  0f2978a8                 movaps xmmword ptr [rax - 0x58], xmm7
0026c9d1  440f294098               movaps xmmword ptr [rax - 0x68], xmm8
0026c9d6  440f294888               movaps xmmword ptr [rax - 0x78], xmm9
0026c9db  498bd9                   mov rbx, r9
0026c9de  498bf8                   mov rdi, r8
0026c9e1  488bf2                   mov rsi, rdx
0026c9e4  4c8bf1                   mov r14, rcx
0026c9e7  4180b98100000000         cmp byte ptr [r9 + 0x81], 0
0026c9ef  0f85c37c6b01             jne 0x19246b8
0026c9f5  498b00                   mov rax, qword ptr [r8]
0026c9f8  498bc8                   mov rcx, r8
0026c9fb  ff5008                   call qword ptr [rax + 8]
0026c9fe  83f802                   cmp eax, 2
0026ca01  0f85b17c6b01             jne 0x19246b8
0026ca07  488b07                   mov rax, qword ptr [rdi]
0026ca0a  488bcf                   mov rcx, rdi
0026ca0d  ff5010                   call qword ptr [rax + 0x10]
0026ca10  488bf8                   mov rdi, rax
0026ca13  4533ff                   xor r15d, r15d
0026ca16  4c897d87                 mov qword ptr [rbp - 0x79], r15
0026ca1a  f20f104368               movsd xmm0, qword ptr [rbx + 0x68]
0026ca1f  660f2f4360               comisd xmm0, xmmword ptr [rbx + 0x60]
0026ca24  0f87de050000             ja 0x26d008
0026ca2a  ff4308                   inc dword ptr [rbx + 8]
0026ca2d  48895d87                 mov qword ptr [rbp - 0x79], rbx
0026ca31  f20f104360               movsd xmm0, qword ptr [rbx + 0x60]
0026ca36  660f2e4368               ucomisd xmm0, qword ptr [rbx + 0x68]
0026ca3b  0f8aed050000             jp 0x26d02e
0026ca41  0f85e7050000             jne 0x26d02e
0026ca47  f20f5905912eeb01         mulsd xmm0, qword ptr [rip + 0x1eb2e91]
0026ca4f  f20f103d01a7da01         movsd xmm7, qword ptr [rip + 0x1daa701]
0026ca57  450f57c9                 xorps xmm9, xmm9
0026ca5b  f20f1035fda6da01         movsd xmm6, qword ptr [rip + 0x1daa6fd]
0026ca63  660f2ff8                 comisd xmm7, xmm0
0026ca67  0f82657b6b01             jb 0x19245d2
0026ca6d  660f2fc6                 comisd xmm0, xmm6
0026ca71  0f82537b6b01             jb 0x19245ca
0026ca77  660f2f4358               comisd xmm0, xmmword ptr [rbx + 0x58]
0026ca7c  0f93c0                   setae al
0026ca7f  84c0                     test al, al
0026ca81  0f84a7050000             je 0x26d02e
0026ca87  4c8d2532adde01           lea r12, [rip + 0x1dead32]
0026ca8e  4c8965af                 mov qword ptr [rbp - 0x51], r12
0026ca92  c745b701000000           mov dword ptr [rbp - 0x49], 1
0026ca99  4c8d2d90ffea01           lea r13, [rip + 0x1eaff90]
0026caa0  4c896daf                 mov qword ptr [rbp - 0x51], r13
0026caa4  4c8975bf                 mov qword ptr [rbp - 0x41], r14
0026caa8  4c897dc7                 mov qword ptr [rbp - 0x39], r15
0026caac  4885ff                   test rdi, rdi
0026caaf  7456                     je 0x26cb07
0026cab1  8b7f08                   mov edi, dword ptr [rdi + 8]
0026cab4  c7456fe5000000           mov dword ptr [rbp + 0x6f], 0xe5
0026cabb  c644242001               mov byte ptr [rsp + 0x20], 1
0026cac0  41b9e5000000             mov r9d, 0xe5
0026cac6  4c8d055305eb01           lea r8, [rip + 0x1eb0553]
0026cacd  488b55bf                 mov rdx, qword ptr [rbp - 0x41]
0026cad1  b930000000               mov ecx, 0x30
0026cad6  ff15d4e3c501             call qword ptr [rip + 0x1c5e3d4]
0026cadc  488945a7                 mov qword ptr [rbp - 0x59], rax
0026cae0  4885c0                   test rax, rax
0026cae3  0f84007b6b01             je 0x19245e9
0026cae9  488bc8                   mov rcx, rax
0026caec  e8ffc41100               call 0x388ff0
0026caf1  eb01                     jmp 0x26caf4
0026caf3  cc                       int3
0026caf4  488945c7                 mov qword ptr [rbp - 0x39], rax
0026caf8  448bc7                   mov r8d, edi
0026cafb  488b55bf                 mov rdx, qword ptr [rbp - 0x41]
0026caff  488bc8                   mov rcx, rax
0026cb02  e8a92de0ff               call 0x6f8b0
0026cb07  c7456f52160000           mov dword ptr [rbp + 0x6f], 0x1652
0026cb0e  c644242001               mov byte ptr [rsp + 0x20], 1
0026cb13  41b952160000             mov r9d, 0x1652
0026cb19  4c8d05b878ed01           lea r8, [rip + 0x1ed78b8]
0026cb20  498bd6                   mov rdx, r14
0026cb23  b930000000               mov ecx, 0x30
0026cb28  ff1582e3c501             call qword ptr [rip + 0x1c5e382]
0026cb2e  488bf8                   mov rdi, rax
0026cb31  488945a7                 mov qword ptr [rbp - 0x59], rax
0026cb35  4885c0                   test rax, rax
0026cb38  0f84b47a6b01             je 0x19245f2
0026cb3e  4c8920                   mov qword ptr [rax], r12
0026cb41  c7400801000000           mov dword ptr [rax + 8], 1
0026cb48  488d050978ed01           lea rax, [rip + 0x1ed7809]
0026cb4f  488907                   mov qword ptr [rdi], rax
0026cb52  4c897f10                 mov qword ptr [rdi + 0x10], r15
0026cb56  4c897f18                 mov qword ptr [rdi + 0x18], r15
0026cb5a  44897f20                 mov dword ptr [rdi + 0x20], r15d
0026cb5e  4c897728                 mov qword ptr [rdi + 0x28], r14
0026cb62  eb01                     jmp 0x26cb65
0026cb64  cc                       int3
0026cb65  48897d6f                 mov qword ptr [rbp + 0x6f], rdi
0026cb69  488b06                   mov rax, qword ptr [rsi]
0026cb6c  c644242800               mov byte ptr [rsp + 0x28], 0
0026cb71  c644242000               mov byte ptr [rsp + 0x20], 0
0026cb76  4c8bcf                   mov r9, rdi
0026cb79  4c8d45af                 lea r8, [rbp - 0x51]
0026cb7d  488d558f                 lea rdx, [rbp - 0x71]
0026cb81  488bce                   mov rcx, rsi
0026cb84  ff9060010000             call qword ptr [rax + 0x160]
0026cb8a  f20f10458f               movsd xmm0, qword ptr [rbp - 0x71]
0026cb8f  66440f2fc8               comisd xmm9, xmm0
0026cb94  7315                     jae 0x26cbab
0026cb96  488b4577                 mov rax, qword ptr [rbp + 0x77]
0026cb9a  f2440f104068             movsd xmm8, qword ptr [rax + 0x68]
0026cba0  66440f2fc0               comisd xmm8, xmm0
0026cba5  0f82008f0100             jb 0x285aab
0026cbab  4032f6                   xor sil, sil
0026cbae  4885ff                   test rdi, rdi
0026cbb1  7414                     je 0x26cbc7
0026cbb3  834708ff                 add dword ptr [rdi + 8], -1
0026cbb7  750e                     jne 0x26cbc7
0026cbb9  488b07                   mov rax, qword ptr [rdi]
0026cbbc  ba01000000               mov edx, 1
0026cbc1  488bcf                   mov rcx, rdi
0026cbc4  ff10                     call qword ptr [rax]
0026cbc6  90                       nop
0026cbc7  4c896daf                 mov qword ptr [rbp - 0x51], r13
0026cbcb  488b7dc7                 mov rdi, qword ptr [rbp - 0x39]
0026cbcf  4885ff                   test rdi, rdi
0026cbd2  741b                     je 0x26cbef
0026cbd4  488b0f                   mov rcx, qword ptr [rdi]
0026cbd7  4885c9                   test rcx, rcx
0026cbda  0f857d7a6b01             jne 0x192465d
0026cbe0  ba30000000               mov edx, 0x30
0026cbe5  488bcf                   mov rcx, rdi
0026cbe8  ff159ae3c501             call qword ptr [rip + 0x1c5e39a]
0026cbee  90                       nop
0026cbef  4c8965af                 mov qword ptr [rbp - 0x51], r12
0026cbf3  eb01                     jmp 0x26cbf6
0026cbf5  cc                       int3
0026cbf6  4885db                   test rbx, rbx
0026cbf9  740a                     je 0x26cc05
0026cbfb  834308ff                 add dword ptr [rbx + 8], -1
0026cbff  0f84b0796b01             je 0x19245b5
0026cc05  400fb6c6                 movzx eax, sil
0026cc09  eb01                     jmp 0x26cc0c
0026cc0b  cc                       int3
0026cc0c  4c8d9c24c0000000         lea r11, [rsp + 0xc0]
0026cc14  498b5b48                 mov rbx, qword ptr [r11 + 0x48]
0026cc18  410f2873f0               movaps xmm6, xmmword ptr [r11 - 0x10]
0026cc1d  410f287be0               movaps xmm7, xmmword ptr [r11 - 0x20]
0026cc22  450f2843d0               movaps xmm8, xmmword ptr [r11 - 0x30]
0026cc27  450f284bc0               movaps xmm9, xmmword ptr [r11 - 0x40]
0026cc2c  498be3                   mov rsp, r11
0026cc2f  415f                     pop r15
0026cc31  415e                     pop r14
0026cc33  415d                     pop r13
0026cc35  415c                     pop r12
0026cc37  5f                       pop rdi
0026cc38  5e                       pop rsi
0026cc39  5d                       pop rbp
0026cc3a  c3                       ret
