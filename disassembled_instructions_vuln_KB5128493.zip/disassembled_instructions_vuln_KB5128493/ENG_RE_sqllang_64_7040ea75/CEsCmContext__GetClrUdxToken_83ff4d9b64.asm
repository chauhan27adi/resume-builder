; CEsCmContext::GetClrUdxToken
; sqllang.dll, primary RVA 0x713c00, 496 bytes in 1 chunk(s)

; chunk at RVA 0x713c00 (496 bytes)
00713c00  488bc4                   mov rax, rsp
00713c03  53                       push rbx
00713c04  55                       push rbp
00713c05  56                       push rsi
00713c06  57                       push rdi
00713c07  4156                     push r14
00713c09  4881ec80000000           sub rsp, 0x80
00713c10  48c740c8feffffff         mov qword ptr [rax - 0x38], 0xfffffffffffffffe
00713c18  498be8                   mov rbp, r8
00713c1b  488bda                   mov rbx, rdx
00713c1e  488bf1                   mov rsi, rcx
00713c21  4533f6                   xor r14d, r14d
00713c24  4c897020                 mov qword ptr [rax + 0x20], r14
00713c28  4c897010                 mov qword ptr [rax + 0x10], r14
00713c2c  654c8b142558000000       mov r10, qword ptr gs:[0x58]
00713c35  488b053c737b01           mov rax, qword ptr [rip + 0x17b733c]
00713c3c  448b08                   mov r9d, dword ptr [rax]
00713c3f  488b053a737b01           mov rax, qword ptr [rip + 0x17b733a]
00713c46  8b38                     mov edi, dword ptr [rax]
00713c48  4b033cca                 add rdi, qword ptr [r10 + r9*8]
00713c4c  488b8f00010000           mov rcx, qword ptr [rdi + 0x100]
00713c53  4885c9                   test rcx, rcx
00713c56  750d                     jne 0x713c65
00713c58  ff1532737b01             call qword ptr [rip + 0x17b7332]
00713c5e  488b8f00010000           mov rcx, qword ptr [rdi + 0x100]
00713c65  4489742420               mov dword ptr [rsp + 0x20], r14d
00713c6a  448b0b                   mov r9d, dword ptr [rbx]
00713c6d  448b431c                 mov r8d, dword ptr [rbx + 0x1c]
00713c71  488bd5                   mov rdx, rbp
00713c74  488b89e8030000           mov rcx, qword ptr [rcx + 0x3e8]
00713c7b  e8d03ef8ff               call 0x697b50
00713c80  488bf8                   mov rdi, rax
00713c83  48898424c8000000         mov qword ptr [rsp + 0xc8], rax
00713c8b  488d8424b8000000         lea rax, [rsp + 0xb8]
00713c93  4889442420               mov qword ptr [rsp + 0x20], rax
00713c98  448b8f10010000           mov r9d, dword ptr [rdi + 0x110]
00713c9f  4c8b8708010000           mov r8, qword ptr [rdi + 0x108]
00713ca6  8b5770                   mov edx, dword ptr [rdi + 0x70]
00713ca9  488b0e                   mov rcx, qword ptr [rsi]
00713cac  e8cfd8f9ff               call 0x6b1580
00713cb1  83f801                   cmp eax, 1
00713cb4  7510                     jne 0x713cc6
00713cb6  448b0b                   mov r9d, dword ptr [rbx]
00713cb9  33d2                     xor edx, edx
00713cbb  448d4058                 lea r8d, [rax + 0x58]
00713cbf  8bc8                     mov ecx, eax
00713cc1  e81a680100               call 0x72a4e0
00713cc6  488b86a8000000           mov rax, qword ptr [rsi + 0xa8]
00713ccd  80b87801000000           cmp byte ptr [rax + 0x178], 0
00713cd4  7509                     jne 0x713cdf
00713cd6  83782422                 cmp dword ptr [rax + 0x24], 0x22
00713cda  458bde                   mov r11d, r14d
00713cdd  7506                     jne 0x713ce5
00713cdf  41bb01000000             mov r11d, 1
00713ce5  8b4324                   mov eax, dword ptr [rbx + 0x24]
00713ce8  83c0fa                   add eax, -6
00713ceb  83f807                   cmp eax, 7
00713cee  772d                     ja 0x713d1d
00713cf0  4898                     cdqe
00713cf2  488d1507c38eff           lea rdx, [rip - 0x713cf9]
00713cf9  8b8c82d03d7100           mov ecx, dword ptr [rdx + rax*4 + 0x713dd0]
00713d00  4803ca                   add rcx, rdx
00713d03  ffe1                     jmp rcx
00713d05  41ba01000000             mov r10d, 1
00713d0b  eb16                     jmp 0x713d23
00713d0d  41ba02000000             mov r10d, 2
00713d13  eb0e                     jmp 0x713d23
00713d15  41ba03000000             mov r10d, 3
00713d1b  eb06                     jmp 0x713d23
00713d1d  41ba04000000             mov r10d, 4
00713d23  448b4b54                 mov r9d, dword ptr [rbx + 0x54]
00713d27  41d1e9                   shr r9d, 1
00713d2a  488b5338                 mov rdx, qword ptr [rbx + 0x38]
00713d2e  448b435c                 mov r8d, dword ptr [rbx + 0x5c]
00713d32  41d1e8                   shr r8d, 1
00713d35  488b4348                 mov rax, qword ptr [rbx + 0x48]
00713d39  8b4b50                   mov ecx, dword ptr [rbx + 0x50]
00713d3c  d1e9                     shr ecx, 1
00713d3e  488dac24b0000000         lea rbp, [rsp + 0xb0]
00713d46  48896c2468               mov qword ptr [rsp + 0x68], rbp
00713d4b  c744246001000000         mov dword ptr [rsp + 0x60], 1
00713d53  44895c2458               mov dword ptr [rsp + 0x58], r11d
00713d58  4489542450               mov dword ptr [rsp + 0x50], r10d
00713d5d  44894c2448               mov dword ptr [rsp + 0x48], r9d
00713d62  4889542440               mov qword ptr [rsp + 0x40], rdx
00713d67  4489742438               mov dword ptr [rsp + 0x38], r14d
00713d6c  4489442430               mov dword ptr [rsp + 0x30], r8d
00713d71  4889442428               mov qword ptr [rsp + 0x28], rax
00713d76  894c2420                 mov dword ptr [rsp + 0x20], ecx
00713d7a  4c8b4b30                 mov r9, qword ptr [rbx + 0x30]
00713d7e  4c8b8424b8000000         mov r8, qword ptr [rsp + 0xb8]
00713d86  488b5608                 mov rdx, qword ptr [rsi + 8]
00713d8a  488b0e                   mov rcx, qword ptr [rsi]
00713d8d  e86efef9ff               call 0x6b3c00
00713d92  83f801                   cmp eax, 1
00713d95  750e                     jne 0x713da5
00713d97  8bd0                     mov edx, eax
00713d99  448d4032                 lea r8d, [rax + 0x32]
00713d9d  33c9                     xor ecx, ecx
00713d9f  e83c670100               call 0x72a4e0
00713da4  90                       nop
00713da5  488bcf                   mov rcx, rdi
00713da8  e87317f8ff               call 0x695520
00713dad  ba90010000               mov edx, 0x190
00713db2  488bcf                   mov rcx, rdi
00713db5  ff15cd717b01             call qword ptr [rip + 0x17b71cd]
00713dbb  8b8424b0000000           mov eax, dword ptr [rsp + 0xb0]
00713dc2  4881c480000000           add rsp, 0x80
00713dc9  415e                     pop r14
00713dcb  5f                       pop rdi
00713dcc  5e                       pop rsi
00713dcd  5d                       pop rbp
00713dce  5b                       pop rbx
00713dcf  c3                       ret
00713dd0  053d71000d               add eax, 0xd00713d
00713dd5  3d7100153d               cmp eax, 0x3d150071
00713dda  7100                     jno 0x713ddc
00713ddc  153d71001d               adc eax, 0x1d00713d
00713de1  3d71001d3d               cmp eax, 0x3d1d0071
00713de6  7100                     jno 0x713de8
00713de8  053d710015               add eax, 0x1500713d
