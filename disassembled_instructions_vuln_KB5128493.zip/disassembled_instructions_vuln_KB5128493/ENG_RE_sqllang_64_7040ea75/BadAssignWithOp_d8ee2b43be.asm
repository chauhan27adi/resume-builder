; BadAssignWithOp
; sqllang.dll, primary RVA 0x9f34f0, 196 bytes in 1 chunk(s)

; chunk at RVA 0x9f34f0 (196 bytes)
009f34f0  4883ec48                 sub rsp, 0x48
009f34f4  4533c0                   xor r8d, r8d
009f34f7  448bd2                   mov r10d, edx
009f34fa  83f909                   cmp ecx, 9
009f34fd  775c                     ja 0x9f355b
009f34ff  4863c1                   movsxd rax, ecx
009f3502  488d15f7ca60ff           lea rdx, [rip - 0x9f3509]
009f3509  8b8c828c359f00           mov ecx, dword ptr [rdx + rax*4 + 0x9f358c]
009f3510  4803ca                   add rcx, rdx
009f3513  ffe1                     jmp rcx
009f3515  4c8d052c76a201           lea r8, [rip + 0x1a2762c]
009f351c  eb3d                     jmp 0x9f355b
009f351e  4c8d05b776a201           lea r8, [rip + 0x1a276b7]
009f3525  eb34                     jmp 0x9f355b
009f3527  4c8d05b676a201           lea r8, [rip + 0x1a276b6]
009f352e  eb2b                     jmp 0x9f355b
009f3530  4c8d05b576a201           lea r8, [rip + 0x1a276b5]
009f3537  eb22                     jmp 0x9f355b
009f3539  4c8d05b476a201           lea r8, [rip + 0x1a276b4]
009f3540  eb19                     jmp 0x9f355b
009f3542  4c8d055376a201           lea r8, [rip + 0x1a27653]
009f3549  eb10                     jmp 0x9f355b
009f354b  4c8d055276a201           lea r8, [rip + 0x1a27652]
009f3552  eb07                     jmp 0x9f355b
009f3554  4c8d055176a201           lea r8, [rip + 0x1a27651]
009f355b  4c89442430               mov qword ptr [rsp + 0x30], r8
009f3560  ba6b000000               mov edx, 0x6b
009f3565  c744242804000000         mov dword ptr [rsp + 0x28], 4
009f356d  418bca                   mov ecx, r10d
009f3570  c744242001000000         mov dword ptr [rsp + 0x20], 1
009f3578  448d4aa4                 lea r9d, [rdx - 0x5c]
009f357c  448d429d                 lea r8d, [rdx - 0x63]
009f3580  e89bb70800               call 0xa7ed20
009f3585  4883c448                 add rsp, 0x48
009f3589  c3                       ret
009f358a  90                       nop
009f358b  90                       nop
009f358c  15359f001e               adc eax, 0x1e009f35
009f3591  359f002735               xor eax, 0x3527009f
009f3596  9f                       lahf
009f3597  0030                     add byte ptr [rax], dh
009f3599  359f003935               xor eax, 0x3539009f
009f359e  9f                       lahf
009f359f  005b35                   add byte ptr [rbx + 0x35], bl
009f35a2  9f                       lahf
009f35a3  005b35                   add byte ptr [rbx + 0x35], bl
009f35a6  9f                       lahf
009f35a7  004235                   add byte ptr [rdx + 0x35], al
009f35aa  9f                       lahf
009f35ab  004b35                   add byte ptr [rbx + 0x35], cl
009f35ae  9f                       lahf
009f35af  0054359f                 add byte ptr [rbp + rsi - 0x61], dl
