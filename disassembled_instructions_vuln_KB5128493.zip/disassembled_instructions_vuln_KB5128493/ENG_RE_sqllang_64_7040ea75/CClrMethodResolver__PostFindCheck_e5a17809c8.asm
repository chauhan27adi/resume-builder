; CClrMethodResolver::PostFindCheck
; sqllang.dll, primary RVA 0x705290, 692 bytes in 1 chunk(s)

; chunk at RVA 0x705290 (692 bytes)
00705290  4883ec58                 sub rsp, 0x58
00705294  4c8bc9                   mov r9, rcx
00705297  83fa0a                   cmp edx, 0xa
0070529a  7508                     jne 0x7052a4
0070529c  8d42f7                   lea eax, [rdx - 9]
0070529f  4883c458                 add rsp, 0x58
007052a3  c3                       ret
007052a4  448b5158                 mov r10d, dword ptr [rcx + 0x58]
007052a8  4183fa01                 cmp r10d, 1
007052ac  0f8763020000             ja 0x705515
007052b2  83fa09                   cmp edx, 9
007052b5  0f875a020000             ja 0x705515
007052bb  4863c2                   movsxd rax, edx
007052be  488d153bad8fff           lea rdx, [rip - 0x7052c5]
007052c5  8b8c821c557000           mov ecx, dword ptr [rdx + rax*4 + 0x70551c]
007052cc  4803ca                   add rcx, rdx
007052cf  ffe1                     jmp rcx
007052d1  4d8b4110                 mov r8, qword ptr [r9 + 0x10]
007052d5  418bca                   mov ecx, r10d
007052d8  498b4018                 mov rax, qword ptr [r8 + 0x18]
007052dc  488b9098000000           mov rdx, qword ptr [rax + 0x98]
007052e3  498b4028                 mov rax, qword ptr [r8 + 0x28]
007052e7  4889542438               mov qword ptr [rsp + 0x38], rdx
007052ec  ba41000000               mov edx, 0x41
007052f1  4889442430               mov qword ptr [rsp + 0x30], rax
007052f6  498b4138                 mov rax, qword ptr [r9 + 0x38]
007052fa  4889442428               mov qword ptr [rsp + 0x28], rax
007052ff  448d4acf                 lea r9d, [rdx - 0x31]
00705303  c74424200a000000         mov dword ptr [rsp + 0x20], 0xa
0070530b  448d42c5                 lea r8d, [rdx - 0x3b]
0070530f  e8ac050000               call 0x7058c0
00705314  33c0                     xor eax, eax
00705316  4883c458                 add rsp, 0x58
0070531a  c3                       ret
0070531b  498b5110                 mov rdx, qword ptr [r9 + 0x10]
0070531f  41b84a000000             mov r8d, 0x4a
00705325  488b4218                 mov rax, qword ptr [rdx + 0x18]
00705329  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
0070532f  488b8098000000           mov rax, qword ptr [rax + 0x98]
00705336  03c9                     add ecx, ecx
00705338  4889442440               mov qword ptr [rsp + 0x40], rax
0070533d  488b4228                 mov rax, qword ptr [rdx + 0x28]
00705341  894c2438                 mov dword ptr [rsp + 0x38], ecx
00705345  4889442430               mov qword ptr [rsp + 0x30], rax
0070534a  498b4138                 mov rax, qword ptr [r9 + 0x38]
0070534e  4889442428               mov qword ptr [rsp + 0x28], rax
00705353  c744242002000000         mov dword ptr [rsp + 0x20], 2
0070535b  e9a3010000               jmp 0x705503
00705360  498b5110                 mov rdx, qword ptr [r9 + 0x10]
00705364  41b846000000             mov r8d, 0x46
0070536a  488b4218                 mov rax, qword ptr [rdx + 0x18]
0070536e  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
00705374  488b8098000000           mov rax, qword ptr [rax + 0x98]
0070537b  03c9                     add ecx, ecx
0070537d  4889442440               mov qword ptr [rsp + 0x40], rax
00705382  488b4228                 mov rax, qword ptr [rdx + 0x28]
00705386  894c2438                 mov dword ptr [rsp + 0x38], ecx
0070538a  4889442430               mov qword ptr [rsp + 0x30], rax
0070538f  498b4138                 mov rax, qword ptr [r9 + 0x38]
00705393  4889442428               mov qword ptr [rsp + 0x28], rax
00705398  c744242002000000         mov dword ptr [rsp + 0x20], 2
007053a0  e95e010000               jmp 0x705503
007053a5  498b5110                 mov rdx, qword ptr [r9 + 0x10]
007053a9  41b849000000             mov r8d, 0x49
007053af  488b4218                 mov rax, qword ptr [rdx + 0x18]
007053b3  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
007053b9  488b8098000000           mov rax, qword ptr [rax + 0x98]
007053c0  03c9                     add ecx, ecx
007053c2  4889442440               mov qword ptr [rsp + 0x40], rax
007053c7  488b4228                 mov rax, qword ptr [rdx + 0x28]
007053cb  894c2438                 mov dword ptr [rsp + 0x38], ecx
007053cf  4889442430               mov qword ptr [rsp + 0x30], rax
007053d4  498b4138                 mov rax, qword ptr [r9 + 0x38]
007053d8  4889442428               mov qword ptr [rsp + 0x28], rax
007053dd  c744242002000000         mov dword ptr [rsp + 0x20], 2
007053e5  e919010000               jmp 0x705503
007053ea  498b5110                 mov rdx, qword ptr [r9 + 0x10]
007053ee  41b817000000             mov r8d, 0x17
007053f4  488b4218                 mov rax, qword ptr [rdx + 0x18]
007053f8  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
007053fe  488b8098000000           mov rax, qword ptr [rax + 0x98]
00705405  03c9                     add ecx, ecx
00705407  4889442440               mov qword ptr [rsp + 0x40], rax
0070540c  488b4228                 mov rax, qword ptr [rdx + 0x28]
00705410  894c2438                 mov dword ptr [rsp + 0x38], ecx
00705414  4889442430               mov qword ptr [rsp + 0x30], rax
00705419  498b4138                 mov rax, qword ptr [r9 + 0x38]
0070541d  4889442428               mov qword ptr [rsp + 0x28], rax
00705422  c744242002000000         mov dword ptr [rsp + 0x20], 2
0070542a  e9d4000000               jmp 0x705503
0070542f  498b5138                 mov rdx, qword ptr [r9 + 0x38]
00705433  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
0070543a  660f1f440000             nop word ptr [rax + rax]
00705440  48ffc1                   inc rcx
00705443  66833c4a00               cmp word ptr [rdx + rcx*2], 0
00705448  75f6                     jne 0x705440
0070544a  418b4178                 mov eax, dword ptr [r9 + 0x78]
0070544e  03c9                     add ecx, ecx
00705450  89442438                 mov dword ptr [rsp + 0x38], eax
00705454  4889542430               mov qword ptr [rsp + 0x30], rdx
00705459  ba01000000               mov edx, 1
0070545e  894c2428                 mov dword ptr [rsp + 0x28], ecx
00705462  418bca                   mov ecx, r10d
00705465  c744242001000000         mov dword ptr [rsp + 0x20], 1
0070546d  448d4a0e                 lea r9d, [rdx + 0xe]
00705471  448d4249                 lea r8d, [rdx + 0x49]
00705475  e846040000               call 0x7058c0
0070547a  33c0                     xor eax, eax
0070547c  4883c458                 add rsp, 0x58
00705480  c3                       ret
00705481  498b5110                 mov rdx, qword ptr [r9 + 0x10]
00705485  41b848000000             mov r8d, 0x48
0070548b  488b4218                 mov rax, qword ptr [rdx + 0x18]
0070548f  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
00705495  488b8098000000           mov rax, qword ptr [rax + 0x98]
0070549c  03c9                     add ecx, ecx
0070549e  4889442440               mov qword ptr [rsp + 0x40], rax
007054a3  488b4228                 mov rax, qword ptr [rdx + 0x28]
007054a7  894c2438                 mov dword ptr [rsp + 0x38], ecx
007054ab  4889442430               mov qword ptr [rsp + 0x30], rax
007054b0  498b4138                 mov rax, qword ptr [r9 + 0x38]
007054b4  4889442428               mov qword ptr [rsp + 0x28], rax
007054b9  c744242001000000         mov dword ptr [rsp + 0x20], 1
007054c1  eb40                     jmp 0x705503
007054c3  498b5110                 mov rdx, qword ptr [r9 + 0x10]
007054c7  41b82f000000             mov r8d, 0x2f
007054cd  488b4218                 mov rax, qword ptr [rdx + 0x18]
007054d1  8b88a0000000             mov ecx, dword ptr [rax + 0xa0]
007054d7  488b8098000000           mov rax, qword ptr [rax + 0x98]
007054de  03c9                     add ecx, ecx
007054e0  4889442440               mov qword ptr [rsp + 0x40], rax
007054e5  488b4228                 mov rax, qword ptr [rdx + 0x28]
007054e9  894c2438                 mov dword ptr [rsp + 0x38], ecx
007054ed  4889442430               mov qword ptr [rsp + 0x30], rax
007054f2  498b4138                 mov rax, qword ptr [r9 + 0x38]
007054f6  4889442428               mov qword ptr [rsp + 0x28], rax
007054fb  c74424200c000000         mov dword ptr [rsp + 0x20], 0xc
00705503  41b910000000             mov r9d, 0x10
00705509  418bca                   mov ecx, r10d
0070550c  418d5131                 lea edx, [r9 + 0x31]
00705510  e8ab030000               call 0x7058c0
00705515  33c0                     xor eax, eax
00705517  4883c458                 add rsp, 0x58
0070551b  c3                       ret
0070551c  d15270                   rcl dword ptr [rdx + 0x70]
0070551f  001b                     add byte ptr [rbx], bl
00705521  53                       push rbx
00705522  7000                     jo 0x705524
