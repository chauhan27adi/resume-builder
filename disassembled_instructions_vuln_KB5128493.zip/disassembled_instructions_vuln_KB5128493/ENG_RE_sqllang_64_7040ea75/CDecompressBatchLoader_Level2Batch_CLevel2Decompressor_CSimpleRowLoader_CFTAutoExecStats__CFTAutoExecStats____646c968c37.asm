; CDecompressBatchLoader<Level2Batch,CLevel2Decompressor,CSimpleRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x972c20, 1436 bytes in 1 chunk(s)

; chunk at RVA 0x972c20 (1436 bytes)
00972c20  488bc4                   mov rax, rsp
00972c23  4c894820                 mov qword ptr [rax + 0x20], r9
00972c27  895010                   mov dword ptr [rax + 0x10], edx
00972c2a  55                       push rbp
00972c2b  56                       push rsi
00972c2c  57                       push rdi
00972c2d  4154                     push r12
00972c2f  4155                     push r13
00972c31  4156                     push r14
00972c33  4157                     push r15
00972c35  488d68a1                 lea rbp, [rax - 0x5f]
00972c39  4881ecd0000000           sub rsp, 0xd0
00972c40  48c74517feffffff         mov qword ptr [rbp + 0x17], 0xfffffffffffffffe
00972c48  48895818                 mov qword ptr [rax + 0x18], rbx
00972c4c  4d8be0                   mov r12, r8
00972c4f  448bfa                   mov r15d, edx
00972c52  488bd9                   mov rbx, rcx
00972c55  83792002                 cmp dword ptr [rcx + 0x20], 2
00972c59  7507                     jne 0x972c62
00972c5b  33c0                     xor eax, eax
00972c5d  e9dd040000               jmp 0x97313f
00972c62  33ff                     xor edi, edi
00972c64  897db7                   mov dword ptr [rbp - 0x49], edi
00972c67  48897dbf                 mov qword ptr [rbp - 0x41], rdi
00972c6b  40887dc7                 mov byte ptr [rbp - 0x39], dil
00972c6f  0f57c0                   xorps xmm0, xmm0
00972c72  660f7f45d7               movdqa xmmword ptr [rbp - 0x29], xmm0
00972c77  0f57c9                   xorps xmm1, xmm1
00972c7a  660f7f4de7               movdqa xmmword ptr [rbp - 0x19], xmm1
00972c7f  660f7f45f7               movdqa xmmword ptr [rbp - 9], xmm0
00972c84  48897d07                 mov qword ptr [rbp + 7], rdi
00972c88  c7450f01000000           mov dword ptr [rbp + 0xf], 1
00972c8f  897c2420                 mov dword ptr [rsp + 0x20], edi
00972c93  32c9                     xor cl, cl
00972c95  884d67                   mov byte ptr [rbp + 0x67], cl
00972c98  4c8d2d61d368ff           lea r13, [rip - 0x972c9f]
00972c9f  41c644241000             mov byte ptr [r12 + 0x10], 0
00972ca5  80bbb814000000           cmp byte ptr [rbx + 0x14b8], 0
00972cac  747f                     je 0x972d2d
00972cae  c683b814000000           mov byte ptr [rbx + 0x14b8], 0
00972cb5  4c8b83b0140000           mov r8, qword ptr [rbx + 0x14b0]
00972cbc  33d2                     xor edx, edx
00972cbe  498bcc                   mov rcx, r12
00972cc1  e88aa2ffff               call 0x96cf50
00972cc6  488b83b0140000           mov rax, qword ptr [rbx + 0x14b0]
00972ccd  ff08                     dec dword ptr [rax]
00972ccf  897db7                   mov dword ptr [rbp - 0x49], edi
00972cd2  498b442408               mov rax, qword ptr [r12 + 8]
00972cd7  488945bf                 mov qword ptr [rbp - 0x41], rax
00972cdb  418b1424                 mov edx, dword ptr [r12]
00972cdf  498b442420               mov rax, qword ptr [r12 + 0x20]
00972ce4  488d0cd0                 lea rcx, [rax + rdx*8]
00972ce8  48894dd7                 mov qword ptr [rbp - 0x29], rcx
00972cec  498b442428               mov rax, qword ptr [r12 + 0x28]
00972cf1  488d0c90                 lea rcx, [rax + rdx*4]
00972cf5  48894ddf                 mov qword ptr [rbp - 0x21], rcx
00972cf9  498b442430               mov rax, qword ptr [r12 + 0x30]
00972cfe  488d0c90                 lea rcx, [rax + rdx*4]
00972d02  48894de7                 mov qword ptr [rbp - 0x19], rcx
00972d06  b801000000               mov eax, 1
00972d0b  2bc2                     sub eax, edx
00972d0d  4403f8                   add r15d, eax
00972d10  44897d6f                 mov dword ptr [rbp + 0x6f], r15d
00972d14  488d75b7                 lea rsi, [rbp - 0x49]
00972d18  c683b814000000           mov byte ptr [rbx + 0x14b8], 0
00972d1f  c744242001000000         mov dword ptr [rsp + 0x20], 1
00972d27  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00972d2b  eb03                     jmp 0x972d30
00972d2d  498bf4                   mov rsi, r12
00972d30  837b2000                 cmp dword ptr [rbx + 0x20], 0
00972d34  0f85ab000000             jne 0x972de5
00972d3a  48897c2428               mov qword ptr [rsp + 0x28], rdi
00972d3f  897d87                   mov dword ptr [rbp - 0x79], edi
00972d42  48897d8f                 mov qword ptr [rbp - 0x71], rdi
00972d46  897d97                   mov dword ptr [rbp - 0x69], edi
00972d49  48897d9f                 mov qword ptr [rbp - 0x61], rdi
00972d4d  897da7                   mov dword ptr [rbp - 0x59], edi
00972d50  66897dab                 mov word ptr [rbp - 0x55], di
00972d54  488d4b28                 lea rcx, [rbx + 0x28]
00972d58  488b01                   mov rax, qword ptr [rcx]
00972d5b  4d8bc1                   mov r8, r9
00972d5e  488d542428               lea rdx, [rsp + 0x28]
00972d63  ff10                     call qword ptr [rax]
00972d65  c6456701                 mov byte ptr [rbp + 0x67], 1
00972d69  3dc60e0400               cmp eax, 0x40ec6
00972d6e  0f84a8030000             je 0x97311c
00972d74  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
00972d79  48894b50                 mov qword ptr [rbx + 0x50], rcx
00972d7d  8b4587                   mov eax, dword ptr [rbp - 0x79]
00972d80  894348                   mov dword ptr [rbx + 0x48], eax
00972d83  48894b58                 mov qword ptr [rbx + 0x58], rcx
00972d87  48897b40                 mov qword ptr [rbx + 0x40], rdi
00972d8b  66c783080300000000       mov word ptr [rbx + 0x308], 0
00972d94  4889bb00030000           mov qword ptr [rbx + 0x300], rdi
00972d9b  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
00972d9f  48898b20030000           mov qword ptr [rbx + 0x320], rcx
00972da6  8b4597                   mov eax, dword ptr [rbp - 0x69]
00972da9  898318030000             mov dword ptr [rbx + 0x318], eax
00972daf  48898b28030000           mov qword ptr [rbx + 0x328], rcx
00972db6  4889bb10030000           mov qword ptr [rbx + 0x310], rdi
00972dbd  4889bb9c140000           mov qword ptr [rbx + 0x149c], rdi
00972dc4  c783a414000000000101     mov dword ptr [rbx + 0x14a4], 0x1010000
00972dce  c7839814000001000000     mov dword ptr [rbx + 0x1498], 1
00972dd8  89bb90130000             mov dword ptr [rbx + 0x1390], edi
00972dde  c7432001000000           mov dword ptr [rbx + 0x20], 1
00972de5  488b4330                 mov rax, qword ptr [rbx + 0x30]
00972de9  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00972df0  4c894608                 mov qword ptr [rsi + 8], r8
00972df4  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00972dfb  488b5330                 mov rdx, qword ptr [rbx + 0x30]
00972dff  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00972e02  83e007                   and eax, 7
00972e05  83f805                   cmp eax, 5
00972e08  7741                     ja 0x972e4b
00972e0a  4898                     cdqe
00972e0c  418b8c855c319700         mov ecx, dword ptr [r13 + rax*4 + 0x97315c]
00972e14  4903cd                   add rcx, r13
00972e17  ffe1                     jmp rcx
00972e19  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972e1d  410f95c6                 setne r14b
00972e21  eb2b                     jmp 0x972e4e
00972e23  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972e27  410f9dc6                 setge r14b
00972e2b  eb21                     jmp 0x972e4e
00972e2d  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972e31  410f9ec6                 setle r14b
00972e35  eb17                     jmp 0x972e4e
00972e37  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972e3b  410f9fc6                 setg r14b
00972e3f  eb0d                     jmp 0x972e4e
00972e41  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972e45  410f9cc6                 setl r14b
00972e49  eb03                     jmp 0x972e4e
00972e4b  4532f6                   xor r14b, r14b
00972e4e  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00972e55  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00972e58  83e007                   and eax, 7
00972e5b  83f805                   cmp eax, 5
00972e5e  7741                     ja 0x972ea1
00972e60  4898                     cdqe
00972e62  418b8c8574319700         mov ecx, dword ptr [r13 + rax*4 + 0x973174]
00972e6a  4903cd                   add rcx, r13
00972e6d  ffe1                     jmp rcx
00972e6f  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e73  410f95c5                 setne r13b
00972e77  eb2b                     jmp 0x972ea4
00972e79  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e7d  410f9dc5                 setge r13b
00972e81  eb21                     jmp 0x972ea4
00972e83  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e87  410f9ec5                 setle r13b
00972e8b  eb17                     jmp 0x972ea4
00972e8d  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e91  410f9fc5                 setg r13b
00972e95  eb0d                     jmp 0x972ea4
00972e97  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972e9b  410f9cc5                 setl r13b
00972e9f  eb03                     jmp 0x972ea4
00972ea1  4532ed                   xor r13b, r13b
00972ea4  48895d1f                 mov qword ptr [rbp + 0x1f], rbx
00972ea8  0f31                     rdtsc
00972eaa  48c1e220                 shl rdx, 0x20
00972eae  480bc2                   or rax, rdx
00972eb1  48894308                 mov qword ptr [rbx + 8], rax
00972eb5  488d4b38                 lea rcx, [rbx + 0x38]
00972eb9  4c8bc6                   mov r8, rsi
00972ebc  418bd7                   mov edx, r15d
00972ebf  e8ecb1ffff               call 0x96e0b0
00972ec4  84c0                     test al, al
00972ec6  7503                     jne 0x972ecb
00972ec8  897b20                   mov dword ptr [rbx + 0x20], edi
00972ecb  8b06                     mov eax, dword ptr [rsi]
00972ecd  48014310                 add qword ptr [rbx + 0x10], rax
00972ed1  0f31                     rdtsc
00972ed3  48c1e220                 shl rdx, 0x20
00972ed7  480bc2                   or rax, rdx
00972eda  482b4308                 sub rax, qword ptr [rbx + 8]
00972ede  480103                   add qword ptr [rbx], rax
00972ee1  ff4318                   inc dword ptr [rbx + 0x18]
00972ee4  8b16                     mov edx, dword ptr [rsi]
00972ee6  448bc2                   mov r8d, edx
00972ee9  85d2                     test edx, edx
00972eeb  0f84c8010000             je 0x9730b9
00972ef1  4584f6                   test r14b, r14b
00972ef4  7509                     jne 0x972eff
00972ef6  4584ed                   test r13b, r13b
00972ef9  0f84ba010000             je 0x9730b9
00972eff  448bca                   mov r9d, edx
00972f02  4584f6                   test r14b, r14b
00972f05  0f8484000000             je 0x972f8f
00972f0b  448bd7                   mov r10d, edi
00972f0e  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00972f12  85d2                     test edx, edx
00972f14  7472                     je 0x972f88
00972f16  4c8b7620                 mov r14, qword ptr [rsi + 0x20]
00972f1a  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00972f1e  4183e007                 and r8d, 7
00972f22  4c8d3dd7d068ff           lea r15, [rip - 0x972f29]
00972f29  0f1f8000000000           nop dword ptr [rax]
00972f30  418bc2                   mov eax, r10d
00972f33  4d8b0cc6                 mov r9, qword ptr [r14 + rax*8]
00972f37  4183f805                 cmp r8d, 5
00972f3b  0f87ad000000             ja 0x972fee
00972f41  4963c0                   movsxd rax, r8d
00972f44  418b8c878c319700         mov ecx, dword ptr [r15 + rax*4 + 0x97318c]
00972f4c  4903cf                   add rcx, r15
00972f4f  ffe1                     jmp rcx
00972f51  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972f55  0f94c0                   sete al
00972f58  eb22                     jmp 0x972f7c
00972f5a  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972f5e  0f9cc0                   setl al
00972f61  eb19                     jmp 0x972f7c
00972f63  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972f67  0f9fc0                   setg al
00972f6a  eb10                     jmp 0x972f7c
00972f6c  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972f70  0f9ec0                   setle al
00972f73  eb07                     jmp 0x972f7c
00972f75  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972f79  0f9dc0                   setge al
00972f7c  84c0                     test al, al
00972f7e  756e                     jne 0x972fee
00972f80  41ffc2                   inc r10d
00972f83  443bd2                   cmp r10d, edx
00972f86  72a8                     jb 0x972f30
00972f88  893e                     mov dword ptr [rsi], edi
00972f8a  8bd7                     mov edx, edi
00972f8c  448bcf                   mov r9d, edi
00972f8f  458bc1                   mov r8d, r9d
00972f92  4584ed                   test r13b, r13b
00972f95  0f841e010000             je 0x9730b9
00972f9b  85d2                     test edx, edx
00972f9d  0f8416010000             je 0x9730b9
00972fa3  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00972fa7  4c8b7e20                 mov r15, qword ptr [rsi + 0x20]
00972fab  4c8d2d4ed068ff           lea r13, [rip - 0x972fb2]
00972fb2  0f1f4000                 nop dword ptr [rax]
00972fb6  66660f1f840000000000     nop word ptr [rax + rax]
00972fc0  458bd1                   mov r10d, r9d
00972fc3  ffca                     dec edx
00972fc5  448bca                   mov r9d, edx
00972fc8  4d8b34d7                 mov r14, qword ptr [r15 + rdx*8]
00972fcc  418b434c                 mov eax, dword ptr [r11 + 0x4c]
00972fd0  83e007                   and eax, 7
00972fd3  458bc2                   mov r8d, r10d
00972fd6  83f805                   cmp eax, 5
00972fd9  0f87da000000             ja 0x9730b9
00972fdf  4898                     cdqe
00972fe1  418b8c85a4319700         mov ecx, dword ptr [r13 + rax*4 + 0x9731a4]
00972fe9  4903cd                   add rcx, r13
00972fec  ffe1                     jmp rcx
00972fee  443bd2                   cmp r10d, edx
00972ff1  7395                     jae 0x972f88
00972ff3  448bca                   mov r9d, edx
00972ff6  4585d2                   test r10d, r10d
00972ff9  7494                     je 0x972f8f
00972ffb  452bca                   sub r9d, r10d
00972ffe  8bd7                     mov edx, edi
00973000  7470                     je 0x973072
00973002  4c8bc7                   mov r8, rdi
00973005  4c8bdf                   mov r11, rdi
00973008  4c8bf7                   mov r14, rdi
0097300b  0f1f440000               nop dword ptr [rax + rax]
00973010  428d0412                 lea eax, [rdx + r10]
00973014  448bf8                   mov r15d, eax
00973017  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0097301b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
0097301f  4989040e                 mov qword ptr [r14 + rcx], rax
00973023  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
00973027  428b04b9                 mov eax, dword ptr [rcx + r15*4]
0097302b  4189040b                 mov dword ptr [r11 + rcx], eax
0097302f  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
00973033  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00973037  4189040b                 mov dword ptr [r11 + rcx], eax
0097303b  4d03ff                   add r15, r15
0097303e  488b4638                 mov rax, qword ptr [rsi + 0x38]
00973042  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00973047  420f110400               movups xmmword ptr [rax + r8], xmm0
0097304c  488b4648                 mov rax, qword ptr [rsi + 0x48]
00973050  4885c0                   test rax, rax
00973053  740a                     je 0x97305f
00973055  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
0097305a  420f110400               movups xmmword ptr [rax + r8], xmm0
0097305f  ffc2                     inc edx
00973061  4983c608                 add r14, 8
00973065  4983c304                 add r11, 4
00973069  4983c010                 add r8, 0x10
0097306d  413bd1                   cmp edx, r9d
00973070  729e                     jb 0x973010
00973072  44890e                   mov dword ptr [rsi], r9d
00973075  418bd1                   mov edx, r9d
00973078  e912ffffff               jmp 0x972f8f
0097307d  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00973081  0f94c0                   sete al
00973084  eb22                     jmp 0x9730a8
00973086  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
0097308a  0f9cc0                   setl al
0097308d  eb19                     jmp 0x9730a8
0097308f  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00973093  0f9fc0                   setg al
00973096  eb10                     jmp 0x9730a8
00973098  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
0097309c  0f9ec0                   setle al
0097309f  eb07                     jmp 0x9730a8
009730a1  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
009730a5  0f9dc0                   setge al
009730a8  84c0                     test al, al
009730aa  750d                     jne 0x9730b9
009730ac  8916                     mov dword ptr [rsi], edx
009730ae  448bc2                   mov r8d, edx
009730b1  85d2                     test edx, edx
009730b3  0f8507ffffff             jne 0x972fc0
009730b9  80bbb914000000           cmp byte ptr [rbx + 0x14b9], 0
009730c0  7440                     je 0x973102
009730c2  448b06                   mov r8d, dword ptr [rsi]
009730c5  4585c0                   test r8d, r8d
009730c8  7438                     je 0x973102
009730ca  c683b814000001           mov byte ptr [rbx + 0x14b8], 1
009730d1  8b16                     mov edx, dword ptr [rsi]
009730d3  ffca                     dec edx
009730d5  4c8bc6                   mov r8, rsi
009730d8  488b8bb0140000           mov rcx, qword ptr [rbx + 0x14b0]
009730df  e86c9effff               call 0x96cf50
009730e4  ff0e                     dec dword ptr [rsi]
009730e6  41c644241001             mov byte ptr [r12 + 0x10], 1
009730ec  488b83b0140000           mov rax, qword ptr [rbx + 0x14b0]
009730f3  488b4820                 mov rcx, qword ptr [rax + 0x20]
009730f7  488b01                   mov rax, qword ptr [rcx]
009730fa  4989442418               mov qword ptr [r12 + 0x18], rax
009730ff  448b06                   mov r8d, dword ptr [rsi]
00973102  8b442420                 mov eax, dword ptr [rsp + 0x20]
00973106  4103c0                   add eax, r8d
00973109  89442420                 mov dword ptr [rsp + 0x20], eax
0097310d  7521                     jne 0x973130
0097310f  448b7d6f                 mov r15d, dword ptr [rbp + 0x6f]
00973113  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00973117  e97cfbffff               jmp 0x972c98
0097311c  c7432002000000           mov dword ptr [rbx + 0x20], 2
00973123  41833c2400               cmp dword ptr [r12], 0
00973128  400f95c7                 setne dil
0097312c  8bc7                     mov eax, edi
0097312e  eb0f                     jmp 0x97313f
00973130  41890424                 mov dword ptr [r12], eax
00973134  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00973138  f6d9                     neg cl
0097313a  1bc0                     sbb eax, eax
0097313c  83c002                   add eax, 2
0097313f  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
00973147  4881c4d0000000           add rsp, 0xd0
0097314e  415f                     pop r15
00973150  415e                     pop r14
00973152  415d                     pop r13
00973154  415c                     pop r12
00973156  5f                       pop rdi
00973157  5e                       pop rsi
00973158  5d                       pop rbp
00973159  c3                       ret
0097315a  90                       nop
0097315b  90                       nop
0097315c  4b2e97                   xchg edi, eax
0097315f  0019                     add byte ptr [rcx], bl
00973161  2e97                     xchg edi, eax
00973163  0023                     add byte ptr [rbx], ah
00973165  2e97                     xchg edi, eax
00973167  0037                     add byte ptr [rdi], dh
00973169  2e97                     xchg edi, eax
0097316b  002d2e970041             add byte ptr [rip + 0x4100972e], ch
00973171  2e97                     xchg edi, eax
00973173  00a12e97006f             add byte ptr [rcx + 0x6f00972e], ah
00973179  2e97                     xchg edi, eax
0097317b  00792e                   add byte ptr [rcx + 0x2e], bh
0097317e  97                       xchg edi, eax
0097317f  008d2e970083             add byte ptr [rbp - 0x7cff68d2], cl
00973185  2e97                     xchg edi, eax
00973187  00972e9700ee             add byte ptr [rdi - 0x11ff68d2], dl
