; CContainmentBreachHandler::CDBSubStatementTypeValidation
; sqllang.dll, primary RVA 0x857de0, 849 bytes in 1 chunk(s)

; chunk at RVA 0x857de0 (849 bytes)
00857de0  4883ec38                 sub rsp, 0x38
00857de4  81c133ffffff             add ecx, 0xffffff33
00857dea  4d8bd1                   mov r10, r9
00857ded  4d8bd8                   mov r11, r8
00857df0  81f9a8000000             cmp ecx, 0xa8
00857df6  0f8767020000             ja 0x858063
00857dfc  4863c1                   movsxd rax, ecx
00857dff  4c8d05fa817aff           lea r8, [rip - 0x857e06]
00857e06  410fb6840088808500       movzx eax, byte ptr [r8 + rax + 0x858088]
00857e0f  418b8c8068808500         mov ecx, dword ptr [r8 + rax*4 + 0x858068]
00857e17  4903c8                   add rcx, r8
00857e1a  ffe1                     jmp rcx
00857e1c  85d2                     test edx, edx
00857e1e  0f8488000000             je 0x857eac
00857e24  81fa00000800             cmp edx, 0x80000
00857e2a  7467                     je 0x857e93
00857e2c  81fa00000002             cmp edx, 0x2000000
00857e32  7446                     je 0x857e7a
00857e34  81fa00000004             cmp edx, 0x4000000
00857e3a  7425                     je 0x857e61
00857e3c  81fa00000008             cmp edx, 0x8000000
00857e42  0f851b020000             jne 0x858063
00857e48  41b811000000             mov r8d, 0x11
00857e4e  4533c9                   xor r9d, r9d
00857e51  498bd2                   mov rdx, r10
00857e54  498bcb                   mov rcx, r11
00857e57  e8347faeff               call 0x33fd90
00857e5c  4883c438                 add rsp, 0x38
00857e60  c3                       ret
00857e61  41b810000000             mov r8d, 0x10
00857e67  4533c9                   xor r9d, r9d
00857e6a  498bd2                   mov rdx, r10
00857e6d  498bcb                   mov rcx, r11
00857e70  e81b7faeff               call 0x33fd90
00857e75  4883c438                 add rsp, 0x38
00857e79  c3                       ret
00857e7a  41b812000000             mov r8d, 0x12
00857e80  4533c9                   xor r9d, r9d
00857e83  498bd2                   mov rdx, r10
00857e86  498bcb                   mov rcx, r11
00857e89  e8027faeff               call 0x33fd90
00857e8e  4883c438                 add rsp, 0x38
00857e92  c3                       ret
00857e93  41b813000000             mov r8d, 0x13
00857e99  4533c9                   xor r9d, r9d
00857e9c  498bd2                   mov rdx, r10
00857e9f  498bcb                   mov rcx, r11
00857ea2  e8e97eaeff               call 0x33fd90
00857ea7  4883c438                 add rsp, 0x38
00857eab  c3                       ret
00857eac  41b80f000000             mov r8d, 0xf
00857eb2  4533c9                   xor r9d, r9d
00857eb5  498bd2                   mov rdx, r10
00857eb8  498bcb                   mov rcx, r11
00857ebb  e8d07eaeff               call 0x33fd90
00857ec0  4883c438                 add rsp, 0x38
00857ec4  c3                       ret
00857ec5  83ea18                   sub edx, 0x18
00857ec8  7461                     je 0x857f2b
00857eca  83ea01                   sub edx, 1
00857ecd  7443                     je 0x857f12
00857ecf  83ea01                   sub edx, 1
00857ed2  7425                     je 0x857ef9
00857ed4  83ea02                   sub edx, 2
00857ed7  7452                     je 0x857f2b
00857ed9  83fa01                   cmp edx, 1
00857edc  0f8581010000             jne 0x858063
00857ee2  448d420d                 lea r8d, [rdx + 0xd]
00857ee6  4533c9                   xor r9d, r9d
00857ee9  498bd2                   mov rdx, r10
00857eec  498bcb                   mov rcx, r11
00857eef  e89c7eaeff               call 0x33fd90
00857ef4  4883c438                 add rsp, 0x38
00857ef8  c3                       ret
00857ef9  41b80d000000             mov r8d, 0xd
00857eff  4533c9                   xor r9d, r9d
00857f02  498bd2                   mov rdx, r10
00857f05  498bcb                   mov rcx, r11
00857f08  e8837eaeff               call 0x33fd90
00857f0d  4883c438                 add rsp, 0x38
00857f11  c3                       ret
00857f12  41b80c000000             mov r8d, 0xc
00857f18  4533c9                   xor r9d, r9d
00857f1b  498bd2                   mov rdx, r10
00857f1e  498bcb                   mov rcx, r11
00857f21  e86a7eaeff               call 0x33fd90
00857f26  4883c438                 add rsp, 0x38
00857f2a  c3                       ret
00857f2b  41b80b000000             mov r8d, 0xb
00857f31  4533c9                   xor r9d, r9d
00857f34  498bd2                   mov rdx, r10
00857f37  498bcb                   mov rcx, r11
00857f3a  e8517eaeff               call 0x33fd90
00857f3f  4883c438                 add rsp, 0x38
00857f43  c3                       ret
00857f44  83ea02                   sub edx, 2
00857f47  7420                     je 0x857f69
00857f49  83fa01                   cmp edx, 1
00857f4c  0f8511010000             jne 0x858063
00857f52  448d4240                 lea r8d, [rdx + 0x40]
00857f56  4533c9                   xor r9d, r9d
00857f59  498bd2                   mov rdx, r10
00857f5c  498bcb                   mov rcx, r11
00857f5f  e82c7eaeff               call 0x33fd90
00857f64  4883c438                 add rsp, 0x38
00857f68  c3                       ret
00857f69  41b840000000             mov r8d, 0x40
00857f6f  4533c9                   xor r9d, r9d
00857f72  498bd2                   mov rdx, r10
00857f75  498bcb                   mov rcx, r11
00857f78  e8137eaeff               call 0x33fd90
00857f7d  4883c438                 add rsp, 0x38
00857f81  c3                       ret
00857f82  33c0                     xor eax, eax
00857f84  83fa05                   cmp edx, 5
00857f87  448d401e                 lea r8d, [rax + 0x1e]
00857f8b  eb67                     jmp 0x857ff4
00857f8d  83fa02                   cmp edx, 2
00857f90  743e                     je 0x857fd0
00857f92  83fa04                   cmp edx, 4
00857f95  7420                     je 0x857fb7
00857f97  83fa08                   cmp edx, 8
00857f9a  0f85c3000000             jne 0x858063
00857fa0  448d4230                 lea r8d, [rdx + 0x30]
00857fa4  4533c9                   xor r9d, r9d
00857fa7  498bd2                   mov rdx, r10
00857faa  498bcb                   mov rcx, r11
00857fad  e8de7daeff               call 0x33fd90
00857fb2  4883c438                 add rsp, 0x38
00857fb6  c3                       ret
00857fb7  41b837000000             mov r8d, 0x37
00857fbd  4533c9                   xor r9d, r9d
00857fc0  498bd2                   mov rdx, r10
00857fc3  498bcb                   mov rcx, r11
00857fc6  e8c57daeff               call 0x33fd90
00857fcb  4883c438                 add rsp, 0x38
00857fcf  c3                       ret
00857fd0  41b836000000             mov r8d, 0x36
00857fd6  4533c9                   xor r9d, r9d
00857fd9  498bd2                   mov rdx, r10
00857fdc  498bcb                   mov rcx, r11
00857fdf  e8ac7daeff               call 0x33fd90
00857fe4  4883c438                 add rsp, 0x38
00857fe8  c3                       ret
00857fe9  33c0                     xor eax, eax
00857feb  41b832000000             mov r8d, 0x32
00857ff1  83fa02                   cmp edx, 2
00857ff4  440f45c0                 cmovne r8d, eax
00857ff8  4585c0                   test r8d, r8d
00857ffb  7466                     je 0x858063
00857ffd  4533c9                   xor r9d, r9d
00858000  498bd2                   mov rdx, r10
00858003  498bcb                   mov rcx, r11
00858006  e8857daeff               call 0x33fd90
0085800b  4883c438                 add rsp, 0x38
0085800f  c3                       ret
00858010  83ea01                   sub edx, 1
00858013  743a                     je 0x85804f
00858015  83ea01                   sub edx, 1
00858018  741c                     je 0x858036
0085801a  83fa02                   cmp edx, 2
0085801d  7544                     jne 0x858063
0085801f  448d4245                 lea r8d, [rdx + 0x45]
00858023  4533c9                   xor r9d, r9d
00858026  498bd2                   mov rdx, r10
00858029  498bcb                   mov rcx, r11
0085802c  e85f7daeff               call 0x33fd90
00858031  4883c438                 add rsp, 0x38
00858035  c3                       ret
00858036  41b845000000             mov r8d, 0x45
0085803c  4533c9                   xor r9d, r9d
0085803f  498bd2                   mov rdx, r10
00858042  498bcb                   mov rcx, r11
00858045  e8467daeff               call 0x33fd90
0085804a  4883c438                 add rsp, 0x38
0085804e  c3                       ret
0085804f  41b846000000             mov r8d, 0x46
00858055  4533c9                   xor r9d, r9d
00858058  498bd2                   mov rdx, r10
0085805b  498bcb                   mov rcx, r11
0085805e  e82d7daeff               call 0x33fd90
00858063  4883c438                 add rsp, 0x38
00858067  c3                       ret
