; CCursorFFOBase::GetLONGProperty
; sqllang.dll, primary RVA 0x4ddc0, 69 bytes in 1 chunk(s)

; chunk at RVA 0x4ddc0 (69 bytes)
0004ddc0  4053                     push rbx
0004ddc2  4883ec20                 sub rsp, 0x20
0004ddc6  448bc2                   mov r8d, edx
0004ddc9  488bd9                   mov rbx, rcx
0004ddcc  4183e814                 sub r8d, 0x14
0004ddd0  0f848ac95600             je 0x5ba760
0004ddd6  4183e801                 sub r8d, 1
0004ddda  0f8475c95600             je 0x5ba755
0004dde0  4183f806                 cmp r8d, 6
0004dde4  740a                     je 0x4ddf0
0004dde6  4883c420                 add rsp, 0x20
0004ddea  5b                       pop rbx
0004ddeb  e9707cffff               jmp 0x45a60
0004ddf0  488b01                   mov rax, qword ptr [rcx]
0004ddf3  ba07000000               mov edx, 7
0004ddf8  ff5030                   call qword ptr [rax + 0x30]
0004ddfb  f7d8                     neg eax
0004ddfd  1bc0                     sbb eax, eax
0004ddff  4883c420                 add rsp, 0x20
0004de03  5b                       pop rbx
0004de04  c3                       ret
