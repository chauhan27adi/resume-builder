; CDecompressBatchLoader<Level1Batch,CLevel1Decompressor,CSeekPruneRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x973cf0, 1488 bytes in 3 chunk(s)

; chunk at RVA 0x973cf0 (47 bytes)
00973cf0  4c894c2420               mov qword ptr [rsp + 0x20], r9
00973cf5  89542410                 mov dword ptr [rsp + 0x10], edx
00973cf9  53                       push rbx
00973cfa  4154                     push r12
00973cfc  4881ecb8000000           sub rsp, 0xb8
00973d03  83792002                 cmp dword ptr [rcx + 0x20], 2
00973d07  4d8be0                   mov r12, r8
00973d0a  448bd2                   mov r10d, edx
00973d0d  488bd9                   mov rbx, rcx
00973d10  750d                     jne 0x973d1f
00973d12  33c0                     xor eax, eax
00973d14  4881c4b8000000           add rsp, 0xb8
00973d1b  415c                     pop r12
00973d1d  5b                       pop rbx
00973d1e  c3                       ret

; chunk at RVA 0x973d1f (1345 bytes)
00973d1f  4889ac24e0000000         mov qword ptr [rsp + 0xe0], rbp
00973d27  0f57c0                   xorps xmm0, xmm0
00973d2a  4889b424b0000000         mov qword ptr [rsp + 0xb0], rsi
00973d32  33f6                     xor esi, esi
00973d34  4889bc24a8000000         mov qword ptr [rsp + 0xa8], rdi
00973d3c  32c0                     xor al, al
00973d3e  4c89ac24a0000000         mov qword ptr [rsp + 0xa0], r13
00973d46  448bee                   mov r13d, esi
00973d49  4c89b42498000000         mov qword ptr [rsp + 0x98], r14
00973d51  888424d0000000           mov byte ptr [rsp + 0xd0], al
00973d58  4c89bc2490000000         mov qword ptr [rsp + 0x90], r15
00973d60  89742450                 mov dword ptr [rsp + 0x50], esi
00973d64  4889742458               mov qword ptr [rsp + 0x58], rsi
00973d69  4088742460               mov byte ptr [rsp + 0x60], sil
00973d6e  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
00973d74  4889b42480000000         mov qword ptr [rsp + 0x80], rsi
00973d7c  4188742410               mov byte ptr [r12 + 0x10], sil
00973d81  4c8d1d78c268ff           lea r11, [rip - 0x973d88]
00973d88  4038b3280c0000           cmp byte ptr [rbx + 0xc28], sil
00973d8f  0f84c8000000             je 0x973e5d
00973d95  4c8b8b200c0000           mov r9, qword ptr [rbx + 0xc20]
00973d9c  488d7c2450               lea rdi, [rsp + 0x50]
00973da1  4088b3280c0000           mov byte ptr [rbx + 0xc28], sil
00973da8  41bd01000000             mov r13d, 1
00973dae  41ff0424                 inc dword ptr [r12]
00973db2  418b1424                 mov edx, dword ptr [r12]
00973db6  4d8b4120                 mov r8, qword ptr [r9 + 0x20]
00973dba  ffca                     dec edx
00973dbc  498b4c2420               mov rcx, qword ptr [r12 + 0x20]
00973dc1  89742450                 mov dword ptr [rsp + 0x50], esi
00973dc5  498b00                   mov rax, qword ptr [r8]
00973dc8  488904d1                 mov qword ptr [rcx + rdx*8], rax
00973dcc  4d8b4130                 mov r8, qword ptr [r9 + 0x30]
00973dd0  418b1424                 mov edx, dword ptr [r12]
00973dd4  498b4c2430               mov rcx, qword ptr [r12 + 0x30]
00973dd9  ffca                     dec edx
00973ddb  418b00                   mov eax, dword ptr [r8]
00973dde  890491                   mov dword ptr [rcx + rdx*4], eax
00973de1  418b1424                 mov edx, dword ptr [r12]
00973de5  4d8b4128                 mov r8, qword ptr [r9 + 0x28]
00973de9  ffca                     dec edx
00973deb  498b4c2428               mov rcx, qword ptr [r12 + 0x28]
00973df0  4c8b8c24e8000000         mov r9, qword ptr [rsp + 0xe8]
00973df8  418b00                   mov eax, dword ptr [r8]
00973dfb  890491                   mov dword ptr [rcx + rdx*4], eax
00973dfe  488b83200c0000           mov rax, qword ptr [rbx + 0xc20]
00973e05  ff08                     dec dword ptr [rax]
00973e07  418b1424                 mov edx, dword ptr [r12]
00973e0b  498b442408               mov rax, qword ptr [r12 + 8]
00973e10  4889442458               mov qword ptr [rsp + 0x58], rax
00973e15  498b442420               mov rax, qword ptr [r12 + 0x20]
00973e1a  488d0cd0                 lea rcx, [rax + rdx*8]
00973e1e  498b442428               mov rax, qword ptr [r12 + 0x28]
00973e23  48894c2470               mov qword ptr [rsp + 0x70], rcx
00973e28  488d0c90                 lea rcx, [rax + rdx*4]
00973e2c  498b442430               mov rax, qword ptr [r12 + 0x30]
00973e31  48894c2478               mov qword ptr [rsp + 0x78], rcx
00973e36  4088b3280c0000           mov byte ptr [rbx + 0xc28], sil
00973e3d  488d0c90                 lea rcx, [rax + rdx*4]
00973e41  b801000000               mov eax, 1
00973e46  2bc2                     sub eax, edx
00973e48  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
00973e50  4403d0                   add r10d, eax
00973e53  44899424d8000000         mov dword ptr [rsp + 0xd8], r10d
00973e5b  eb03                     jmp 0x973e60
00973e5d  498bfc                   mov rdi, r12
00973e60  397320                   cmp dword ptr [rbx + 0x20], esi
00973e63  0f858d000000             jne 0x973ef6
00973e69  488b4328                 mov rax, qword ptr [rbx + 0x28]
00973e6d  488d4b28                 lea rcx, [rbx + 0x28]
00973e71  4d8bc1                   mov r8, r9
00973e74  4889742420               mov qword ptr [rsp + 0x20], rsi
00973e79  488d542420               lea rdx, [rsp + 0x20]
00973e7e  89742428                 mov dword ptr [rsp + 0x28], esi
00973e82  4889742430               mov qword ptr [rsp + 0x30], rsi
00973e87  89742438                 mov dword ptr [rsp + 0x38], esi
00973e8b  4889742440               mov qword ptr [rsp + 0x40], rsi
00973e90  89742448                 mov dword ptr [rsp + 0x48], esi
00973e94  668974244c               mov word ptr [rsp + 0x4c], si
00973e99  c68424d000000001         mov byte ptr [rsp + 0xd0], 1
00973ea1  ff10                     call qword ptr [rax]
00973ea3  3dc60e0400               cmp eax, 0x40ec6
00973ea8  0f8451030000             je 0x9741ff
00973eae  488b4c2420               mov rcx, qword ptr [rsp + 0x20]
00973eb3  4c8d1d46c168ff           lea r11, [rip - 0x973eba]
00973eba  8b442428                 mov eax, dword ptr [rsp + 0x28]
00973ebe  448b9424d8000000         mov r10d, dword ptr [rsp + 0xd8]
00973ec6  48898b60090000           mov qword ptr [rbx + 0x960], rcx
00973ecd  48898b68090000           mov qword ptr [rbx + 0x968], rcx
00973ed4  898358090000             mov dword ptr [rbx + 0x958], eax
00973eda  4889b350090000           mov qword ptr [rbx + 0x950], rsi
00973ee1  6689b3180c0000           mov word ptr [rbx + 0xc18], si
00973ee8  4889b3100c0000           mov qword ptr [rbx + 0xc10], rsi
00973eef  c7432001000000           mov dword ptr [rbx + 0x20], 1
00973ef6  488b4330                 mov rax, qword ptr [rbx + 0x30]
00973efa  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00973f01  4c894708                 mov qword ptr [rdi + 8], r8
00973f05  488b5330                 mov rdx, qword ptr [rbx + 0x30]
00973f09  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00973f10  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00973f13  83e007                   and eax, 7
00973f16  83f805                   cmp eax, 5
00973f19  7741                     ja 0x973f5c
00973f1b  4898                     cdqe
00973f1d  418b8c8360429700         mov ecx, dword ptr [r11 + rax*4 + 0x974260]
00973f25  4903cb                   add rcx, r11
00973f28  ffe1                     jmp rcx
00973f2a  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973f2e  400f95c5                 setne bpl
00973f32  eb2b                     jmp 0x973f5f
00973f34  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973f38  400f9dc5                 setge bpl
00973f3c  eb21                     jmp 0x973f5f
00973f3e  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973f42  400f9ec5                 setle bpl
00973f46  eb17                     jmp 0x973f5f
00973f48  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973f4c  400f9fc5                 setg bpl
00973f50  eb0d                     jmp 0x973f5f
00973f52  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973f56  400f9cc5                 setl bpl
00973f5a  eb03                     jmp 0x973f5f
00973f5c  4032ed                   xor bpl, bpl
00973f5f  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00973f62  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00973f69  83e007                   and eax, 7
00973f6c  83f805                   cmp eax, 5
00973f6f  7741                     ja 0x973fb2
00973f71  4898                     cdqe
00973f73  418b8c8378429700         mov ecx, dword ptr [r11 + rax*4 + 0x974278]
00973f7b  4903cb                   add rcx, r11
00973f7e  ffe1                     jmp rcx
00973f80  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973f84  410f95c7                 setne r15b
00973f88  eb2b                     jmp 0x973fb5
00973f8a  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973f8e  410f9dc7                 setge r15b
00973f92  eb21                     jmp 0x973fb5
00973f94  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973f98  410f9ec7                 setle r15b
00973f9c  eb17                     jmp 0x973fb5
00973f9e  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973fa2  410f9fc7                 setg r15b
00973fa6  eb0d                     jmp 0x973fb5
00973fa8  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973fac  410f9cc7                 setl r15b
00973fb0  eb03                     jmp 0x973fb5
00973fb2  4532ff                   xor r15b, r15b
00973fb5  488d8b48090000           lea rcx, [rbx + 0x948]
00973fbc  4c8bc7                   mov r8, rdi
00973fbf  418bd2                   mov edx, r10d
00973fc2  e8a99cffff               call 0x96dc70
00973fc7  84c0                     test al, al
00973fc9  7503                     jne 0x973fce
00973fcb  897320                   mov dword ptr [rbx + 0x20], esi
00973fce  8b07                     mov eax, dword ptr [rdi]
00973fd0  448bc8                   mov r9d, eax
00973fd3  85c0                     test eax, eax
00973fd5  0f8487010000             je 0x974162
00973fdb  4084ed                   test bpl, bpl
00973fde  7509                     jne 0x973fe9
00973fe0  4584ff                   test r15b, r15b
00973fe3  0f8479010000             je 0x974162
00973fe9  448bc0                   mov r8d, eax
00973fec  4084ed                   test bpl, bpl
00973fef  747d                     je 0x97406e
00973ff1  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00973ff5  448bce                   mov r9d, esi
00973ff8  85c0                     test eax, eax
00973ffa  746b                     je 0x974067
00973ffc  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00974000  488d2df9bf68ff           lea rbp, [rip - 0x974007]
00974007  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
0097400b  4183e007                 and r8d, 7
0097400f  90                       nop
00974010  418bc9                   mov ecx, r9d
00974013  4d8b14ce                 mov r10, qword ptr [r14 + rcx*8]
00974017  4183f805                 cmp r8d, 5
0097401b  0f879f000000             ja 0x9740c0
00974021  4963c8                   movsxd rcx, r8d
00974024  8b948d90429700           mov edx, dword ptr [rbp + rcx*4 + 0x974290]
0097402b  4803d5                   add rdx, rbp
0097402e  ffe2                     jmp rdx
00974030  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00974034  0f94c1                   sete cl
00974037  eb22                     jmp 0x97405b
00974039  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
0097403d  0f9cc1                   setl cl
00974040  eb19                     jmp 0x97405b
00974042  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00974046  0f9fc1                   setg cl
00974049  eb10                     jmp 0x97405b
0097404b  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
0097404f  0f9ec1                   setle cl
00974052  eb07                     jmp 0x97405b
00974054  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00974058  0f9dc1                   setge cl
0097405b  84c9                     test cl, cl
0097405d  7561                     jne 0x9740c0
0097405f  41ffc1                   inc r9d
00974062  443bc8                   cmp r9d, eax
00974065  72a9                     jb 0x974010
00974067  8937                     mov dword ptr [rdi], esi
00974069  8bc6                     mov eax, esi
0097406b  448bc6                   mov r8d, esi
0097406e  458bc8                   mov r9d, r8d
00974071  4584ff                   test r15b, r15b
00974074  0f84e8000000             je 0x974162
0097407a  85c0                     test eax, eax
0097407c  0f84e0000000             je 0x974162
00974082  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00974086  4c8d3d73bf68ff           lea r15, [rip - 0x97408d]
0097408d  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
00974091  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00974095  ffc8                     dec eax
00974097  458bd0                   mov r10d, r8d
0097409a  83e107                   and ecx, 7
0097409d  448bc0                   mov r8d, eax
009740a0  458bca                   mov r9d, r10d
009740a3  498b2cc6                 mov rbp, qword ptr [r14 + rax*8]
009740a7  83f905                   cmp ecx, 5
009740aa  0f87b2000000             ja 0x974162
009740b0  4863c9                   movsxd rcx, ecx
009740b3  418b948fa8429700         mov edx, dword ptr [r15 + rcx*4 + 0x9742a8]
009740bb  4903d7                   add rdx, r15
009740be  ffe2                     jmp rdx
009740c0  443bc8                   cmp r9d, eax
009740c3  73a2                     jae 0x974067
009740c5  448bc0                   mov r8d, eax
009740c8  4585c9                   test r9d, r9d
009740cb  74a1                     je 0x97406e
009740cd  448bde                   mov r11d, esi
009740d0  452bc1                   sub r8d, r9d
009740d3  7446                     je 0x97411b
009740d5  4c8bd6                   mov r10, rsi
009740d8  4c8bf6                   mov r14, rsi
009740db  0f1f440000               nop dword ptr [rax + rax]
009740e0  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
009740e4  438d040b                 lea eax, [r11 + r9]
009740e8  8bd0                     mov edx, eax
009740ea  4d8d5204                 lea r10, [r10 + 4]
009740ee  41ffc3                   inc r11d
009740f1  4d8d7608                 lea r14, [r14 + 8]
009740f5  488b04c1                 mov rax, qword ptr [rcx + rax*8]
009740f9  4989440ef8               mov qword ptr [r14 + rcx - 8], rax
009740fe  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00974102  8b0491                   mov eax, dword ptr [rcx + rdx*4]
00974105  4189440afc               mov dword ptr [r10 + rcx - 4], eax
0097410a  488b4f28                 mov rcx, qword ptr [rdi + 0x28]
0097410e  8b0491                   mov eax, dword ptr [rcx + rdx*4]
00974111  4189440afc               mov dword ptr [r10 + rcx - 4], eax
00974116  453bd8                   cmp r11d, r8d
00974119  72c5                     jb 0x9740e0
0097411b  448907                   mov dword ptr [rdi], r8d
0097411e  418bc0                   mov eax, r8d
00974121  e948ffffff               jmp 0x97406e
00974126  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
0097412a  0f94c1                   sete cl
0097412d  eb22                     jmp 0x974151
0097412f  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00974133  0f9cc1                   setl cl
00974136  eb19                     jmp 0x974151
00974138  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
0097413c  0f9fc1                   setg cl
0097413f  eb10                     jmp 0x974151
00974141  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00974145  0f9ec1                   setle cl
00974148  eb07                     jmp 0x974151
0097414a  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
0097414e  0f9dc1                   setge cl
00974151  84c9                     test cl, cl
00974153  750d                     jne 0x974162
00974155  8907                     mov dword ptr [rdi], eax
00974157  448bc8                   mov r9d, eax
0097415a  85c0                     test eax, eax
0097415c  0f852fffffff             jne 0x974091
00974162  4038b3290c0000           cmp byte ptr [rbx + 0xc29], sil
00974169  747a                     je 0x9741e5
0097416b  448b0f                   mov r9d, dword ptr [rdi]
0097416e  4585c9                   test r9d, r9d
00974171  7472                     je 0x9741e5
00974173  4c8b93200c0000           mov r10, qword ptr [rbx + 0xc20]
0097417a  c683280c000001           mov byte ptr [rbx + 0xc28], 1
00974181  448b0f                   mov r9d, dword ptr [rdi]
00974184  41ffc9                   dec r9d
00974187  41ff02                   inc dword ptr [r10]
0097418a  418b12                   mov edx, dword ptr [r10]
0097418d  4c8b4720                 mov r8, qword ptr [rdi + 0x20]
00974191  ffca                     dec edx
00974193  498b4a20                 mov rcx, qword ptr [r10 + 0x20]
00974197  4b8b04c8                 mov rax, qword ptr [r8 + r9*8]
0097419b  488904d1                 mov qword ptr [rcx + rdx*8], rax
0097419f  418b12                   mov edx, dword ptr [r10]
009741a2  4c8b4730                 mov r8, qword ptr [rdi + 0x30]
009741a6  ffca                     dec edx
009741a8  498b4a30                 mov rcx, qword ptr [r10 + 0x30]
009741ac  438b0488                 mov eax, dword ptr [r8 + r9*4]
009741b0  890491                   mov dword ptr [rcx + rdx*4], eax
009741b3  418b12                   mov edx, dword ptr [r10]
009741b6  498b4a28                 mov rcx, qword ptr [r10 + 0x28]
009741ba  ffca                     dec edx
009741bc  4c8b4728                 mov r8, qword ptr [rdi + 0x28]
009741c0  438b0488                 mov eax, dword ptr [r8 + r9*4]
009741c4  890491                   mov dword ptr [rcx + rdx*4], eax
009741c7  ff0f                     dec dword ptr [rdi]
009741c9  41c644241001             mov byte ptr [r12 + 0x10], 1
009741cf  488b83200c0000           mov rax, qword ptr [rbx + 0xc20]
009741d6  488b4820                 mov rcx, qword ptr [rax + 0x20]
009741da  488b01                   mov rax, qword ptr [rcx]
009741dd  4989442418               mov qword ptr [r12 + 0x18], rax
009741e2  448b0f                   mov r9d, dword ptr [rdi]
009741e5  4503e9                   add r13d, r9d
009741e8  7528                     jne 0x974212
009741ea  448b9424d8000000         mov r10d, dword ptr [rsp + 0xd8]
009741f2  4c8b8c24e8000000         mov r9, qword ptr [rsp + 0xe8]
009741fa  e97dfbffff               jmp 0x973d7c
009741ff  c7432002000000           mov dword ptr [rbx + 0x20], 2
00974206  41393424                 cmp dword ptr [r12], esi
0097420a  400f95c6                 setne sil
0097420e  8bc6                     mov eax, esi
00974210  eb13                     jmp 0x974225
00974212  0fb68424d0000000         movzx eax, byte ptr [rsp + 0xd0]
0097421a  f6d8                     neg al
0097421c  45892c24                 mov dword ptr [r12], r13d
00974220  1bc0                     sbb eax, eax
00974222  83c002                   add eax, 2
00974225  4c8bb42498000000         mov r14, qword ptr [rsp + 0x98]
0097422d  4c8bac24a0000000         mov r13, qword ptr [rsp + 0xa0]
00974235  488bbc24a8000000         mov rdi, qword ptr [rsp + 0xa8]
0097423d  488bb424b0000000         mov rsi, qword ptr [rsp + 0xb0]
00974245  488bac24e0000000         mov rbp, qword ptr [rsp + 0xe0]
0097424d  4c8bbc2490000000         mov r15, qword ptr [rsp + 0x90]
00974255  4881c4b8000000           add rsp, 0xb8
0097425c  415c                     pop r12
0097425e  5b                       pop rbx
0097425f  c3                       ret

; chunk at RVA 0x974260 (96 bytes)
00974260  5c                       pop rsp
