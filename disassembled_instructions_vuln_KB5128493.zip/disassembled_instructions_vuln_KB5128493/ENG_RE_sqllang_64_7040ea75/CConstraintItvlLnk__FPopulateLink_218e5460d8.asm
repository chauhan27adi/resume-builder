; CConstraintItvlLnk::FPopulateLink
; sqllang.dll, primary RVA 0x115370, 290 bytes in 1 chunk(s)

; chunk at RVA 0x115370 (290 bytes)
00115370  4889542410               mov qword ptr [rsp + 0x10], rdx
00115375  55                       push rbp
00115376  56                       push rsi
00115377  57                       push rdi
00115378  4156                     push r14
0011537a  4157                     push r15
0011537c  4883ec50                 sub rsp, 0x50
00115380  48c7442440feffffff       mov qword ptr [rsp + 0x40], 0xfffffffffffffffe
00115389  48899c2480000000         mov qword ptr [rsp + 0x80], rbx
00115391  4d8bf1                   mov r14, r9
00115394  458bf8                   mov r15d, r8d
00115397  488bea                   mov rbp, rdx
0011539a  488bf1                   mov rsi, rcx
0011539d  418d40ff                 lea eax, [r8 - 1]
001153a1  83f841                   cmp eax, 0x41
001153a4  0f878e724b01             ja 0x15cc638
001153aa  488d0d4faceeff           lea rcx, [rip - 0x1153b1]
001153b1  0fb6840150541100         movzx eax, byte ptr [rcx + rax + 0x115450]
001153b9  448b948138541100         mov r10d, dword ptr [rcx + rax*4 + 0x115438]
001153c1  4c03d1                   add r10, rcx
001153c4  41ffe2                   jmp r10
001153c7  800e01                   or byte ptr [rsi], 1
001153ca  4d85f6                   test r14, r14
001153cd  400f94c7                 sete dil
001153d1  488d4e08                 lea rcx, [rsi + 8]
001153d5  4c89742430               mov qword ptr [rsp + 0x30], r14
001153da  488b9c24a0000000         mov rbx, qword ptr [rsp + 0xa0]
001153e2  48895c2428               mov qword ptr [rsp + 0x28], rbx
001153e7  40887c2420               mov byte ptr [rsp + 0x20], dil
001153ec  41b101                   mov r9b, 1
001153ef  450fb6c1                 movzx r8d, r9b
001153f3  e8b80ffcff               call 0xd63b0
001153f8  800e02                   or byte ptr [rsi], 2
001153fb  488d4e58                 lea rcx, [rsi + 0x58]
001153ff  4c89742430               mov qword ptr [rsp + 0x30], r14
00115404  48895c2428               mov qword ptr [rsp + 0x28], rbx
00115409  40887c2420               mov byte ptr [rsp + 0x20], dil
0011540e  41b101                   mov r9b, 1
00115411  4533c0                   xor r8d, r8d
00115414  488bd5                   mov rdx, rbp
00115417  e8940ffcff               call 0xd63b0
0011541c  800e0c                   or byte ptr [rsi], 0xc
0011541f  b001                     mov al, 1
00115421  eb01                     jmp 0x115424
00115423  cc                       int3
00115424  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
0011542c  4883c450                 add rsp, 0x50
00115430  415f                     pop r15
00115432  415e                     pop r14
00115434  5f                       pop rdi
00115435  5e                       pop rsi
00115436  5d                       pop rbp
00115437  c3                       ret
00115438  4b381500c75311           cmp byte ptr [rip + 0x1153c700], dl
0011543f  00f6                     add dh, dh
00115441  5b                       pop rbx
00115442  1c00                     sbb al, 0
