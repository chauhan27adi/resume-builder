; CAppDomainManager::AppDomainStateTransitionLockHeld
; sqllang.dll, primary RVA 0x6c5850, 324 bytes in 1 chunk(s)

; chunk at RVA 0x6c5850 (324 bytes)
006c5850  48895c2408               mov qword ptr [rsp + 8], rbx
006c5855  4889742410               mov qword ptr [rsp + 0x10], rsi
006c585a  57                       push rdi
006c585b  4883ec20                 sub rsp, 0x20
006c585f  488bda                   mov rbx, rdx
006c5862  4963f8                   movsxd rdi, r8d
006c5865  486392d4010000           movsxd rdx, dword ptr [rdx + 0x1d4]
006c586c  488bf1                   mov rsi, rcx
006c586f  3bd7                     cmp edx, edi
006c5871  0f8dd1000000             jge 0x6c5948
006c5877  0faee8                   lfence
006c587a  8d42ff                   lea eax, [rdx - 1]
006c587d  c7831c01000001000000     mov dword ptr [rbx + 0x11c], 1
006c5887  4c8d0572a793ff           lea r8, [rip - 0x6c588e]
006c588e  83f806                   cmp eax, 6
006c5891  7746                     ja 0x6c58d9
006c5893  4898                     cdqe
006c5895  418b8c805c596c00         mov ecx, dword ptr [r8 + rax*4 + 0x6c595c]
006c589d  4903c8                   add rcx, r8
006c58a0  ffe1                     jmp rcx
006c58a2  488d4203                 lea rax, [rdx + 3]
006c58a6  488d0440                 lea rax, [rax + rax*2]
006c58aa  ff4cc610                 dec dword ptr [rsi + rax*8 + 0x10]
006c58ae  488b83b8000000           mov rax, qword ptr [rbx + 0xb8]
006c58b5  488b8bc0000000           mov rcx, qword ptr [rbx + 0xc0]
006c58bc  48894808                 mov qword ptr [rax + 8], rcx
006c58c0  488901                   mov qword ptr [rcx], rax
006c58c3  48c783c000000000000000   mov qword ptr [rbx + 0xc0], 0
006c58ce  48c783b800000000000000   mov qword ptr [rbx + 0xb8], 0
006c58d9  8d47ff                   lea eax, [rdi - 1]
006c58dc  83f806                   cmp eax, 6
006c58df  773e                     ja 0x6c591f
006c58e1  4898                     cdqe
006c58e3  418b8c8078596c00         mov ecx, dword ptr [r8 + rax*4 + 0x6c5978]
006c58eb  4903c8                   add rcx, r8
006c58ee  ffe1                     jmp rcx
006c58f0  0faee8                   lfence
006c58f3  488d8bb8000000           lea rcx, [rbx + 0xb8]
006c58fa  488d4703                 lea rax, [rdi + 3]
006c58fe  488d0440                 lea rax, [rax + rax*2]
006c5902  ff44c610                 inc dword ptr [rsi + rax*8 + 0x10]
006c5906  488d14c6                 lea rdx, [rsi + rax*8]
006c590a  488b04c6                 mov rax, qword ptr [rsi + rax*8]
006c590e  488901                   mov qword ptr [rcx], rax
006c5911  488b02                   mov rax, qword ptr [rdx]
006c5914  48894808                 mov qword ptr [rax + 8], rcx
006c5918  48890a                   mov qword ptr [rdx], rcx
006c591b  48895108                 mov qword ptr [rcx + 8], rdx
006c591f  8bd7                     mov edx, edi
006c5921  488bcb                   mov rcx, rbx
006c5924  e877b6feff               call 0x6b0fa0
006c5929  f0ff44be10               lock inc dword ptr [rsi + rdi*4 + 0x10]
006c592e  c7831c01000000000000     mov dword ptr [rbx + 0x11c], 0
006c5938  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
006c593d  488b742438               mov rsi, qword ptr [rsp + 0x38]
006c5942  4883c420                 add rsp, 0x20
006c5946  5f                       pop rdi
006c5947  c3                       ret
006c5948  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
006c594d  33c0                     xor eax, eax
006c594f  488b742438               mov rsi, qword ptr [rsp + 0x38]
006c5954  4883c420                 add rsp, 0x20
006c5958  5f                       pop rdi
006c5959  c3                       ret
006c595a  90                       nop
006c595b  90                       nop
006c595c  a2586c00a2586c00a2       movabs byte ptr [0xa2006c58a2006c58], al
006c5965  58                       pop rax
006c5966  6c                       insb byte ptr [rdi], dx
006c5967  00a2586c00a2             add byte ptr [rdx - 0x5dff93a8], ah
006c596d  58                       pop rax
006c596e  6c                       insb byte ptr [rdi], dx
006c596f  00a2586c00a2             add byte ptr [rdx - 0x5dff93a8], ah
006c5975  58                       pop rax
006c5976  6c                       insb byte ptr [rdi], dx
006c5977  00f0                     add al, dh
006c5979  58                       pop rax
006c597a  6c                       insb byte ptr [rdi], dx
006c597b  00f0                     add al, dh
006c597d  58                       pop rax
006c597e  6c                       insb byte ptr [rdi], dx
006c597f  00f0                     add al, dh
006c5981  58                       pop rax
006c5982  6c                       insb byte ptr [rdi], dx
006c5983  00f0                     add al, dh
006c5985  58                       pop rax
006c5986  6c                       insb byte ptr [rdi], dx
006c5987  00f0                     add al, dh
006c5989  58                       pop rax
006c598a  6c                       insb byte ptr [rdi], dx
006c598b  00f0                     add al, dh
006c598d  58                       pop rax
006c598e  6c                       insb byte ptr [rdi], dx
006c598f  00f0                     add al, dh
006c5991  58                       pop rax
006c5992  6c                       insb byte ptr [rdi], dx
