; CDialogEndpoint::ExecuteAction
; sqllang.dll, primary RVA 0x4c75e0, 1320 bytes in 1 chunk(s)

; chunk at RVA 0x4c75e0 (1320 bytes)
004c75e0  488bc4                   mov rax, rsp
004c75e3  55                       push rbp
004c75e4  4156                     push r14
004c75e6  4157                     push r15
004c75e8  488da8c8feffff           lea rbp, [rax - 0x138]
004c75ef  4881ec20020000           sub rsp, 0x220
004c75f6  48c74598feffffff         mov qword ptr [rbp - 0x68], 0xfffffffffffffffe
004c75fe  48895810                 mov qword ptr [rax + 0x10], rbx
004c7602  48897018                 mov qword ptr [rax + 0x18], rsi
004c7606  48897820                 mov qword ptr [rax + 0x20], rdi
004c760a  488b0577266102           mov rax, qword ptr [rip + 0x2612677]
004c7611  4833c4                   xor rax, rsp
004c7614  48898510010000           mov qword ptr [rbp + 0x110], rax
004c761b  4c8bf1                   mov r14, rcx
004c761e  83fa0a                   cmp edx, 0xa
004c7621  0f8782040000             ja 0x4c7aa9
004c7627  4863c2                   movsxd rax, edx
004c762a  488d15cf89b3ff           lea rdx, [rip - 0x4c7631]
004c7631  8b8c82dc7a4c00           mov ecx, dword ptr [rdx + rax*4 + 0x4c7adc]
004c7638  4803ca                   add rcx, rdx
004c763b  ffe1                     jmp rcx
004c763d  41837e7406               cmp dword ptr [r14 + 0x74], 6
004c7642  750b                     jne 0x4c764f
004c7644  41837e300d               cmp dword ptr [r14 + 0x30], 0xd
004c7649  0f855a040000             jne 0x4c7aa9
004c764f  4533c0                   xor r8d, r8d
004c7652  418d5001                 lea edx, [r8 + 1]
004c7656  488d4d88                 lea rcx, [rbp - 0x78]
004c765a  ff1568176102             call qword ptr [rip + 0x2611768]
004c7660  4180bef800000000         cmp byte ptr [r14 + 0xf8], 0
004c7668  0f85c1000000             jne 0x4c772f
004c766e  41837e7400               cmp dword ptr [r14 + 0x74], 0
004c7673  0f84b6000000             je 0x4c772f
004c7679  41837e300d               cmp dword ptr [r14 + 0x30], 0xd
004c767e  0f84ab000000             je 0x4c772f
004c7684  498b8638010000           mov rax, qword ptr [r14 + 0x138]
004c768b  4889442478               mov qword ptr [rsp + 0x78], rax
004c7690  ba08000000               mov edx, 8
004c7695  41b826070000             mov r8d, 0x726
004c769b  488d4c2478               lea rcx, [rsp + 0x78]
004c76a0  ff15da45a001             call qword ptr [rip + 0x1a045da]
004c76a6  85c0                     test eax, eax
004c76a8  7442                     je 0x4c76ec
004c76aa  83f801                   cmp eax, 1
004c76ad  742d                     je 0x4c76dc
004c76af  488d05aa13c901           lea rax, [rip + 0x1c913aa]
004c76b6  4889442420               mov qword ptr [rsp + 0x20], rax
004c76bb  41b95a170000             mov r9d, 0x175a
004c76c1  4c8d05a8090502           lea r8, [rip + 0x20509a8]
004c76c8  488d1551f10402           lea rdx, [rip + 0x204f151]
004c76cf  b901000000               mov ecx, 1
004c76d4  ff159e37a001             call qword ptr [rip + 0x1a0379e]
004c76da  eb10                     jmp 0x4c76ec
004c76dc  c744247c7f242d00         mov dword ptr [rsp + 0x7c], 0x2d247f
004c76e4  c7442478ff818b01         mov dword ptr [rsp + 0x78], 0x18b81ff
004c76ec  498b8e10020000           mov rcx, qword ptr [r14 + 0x210]
004c76f3  488b442478               mov rax, qword ptr [rsp + 0x78]
004c76f8  4885c9                   test rcx, rcx
004c76fb  7409                     je 0x4c7706
004c76fd  483bc1                   cmp rax, rcx
004c7700  7c04                     jl 0x4c7706
004c7702  480f45c1                 cmovne rax, rcx
004c7706  483b4588                 cmp rax, qword ptr [rbp - 0x78]
004c770a  7c23                     jl 0x4c772f
004c770c  7421                     je 0x4c772f
004c770e  498d8e80000000           lea rcx, [r14 + 0x80]
004c7715  e8f69e0200               call 0x4f1610
004c771a  498bce                   mov rcx, r14
004c771d  e84e390000               call 0x4cb070
004c7722  41c7467406000000         mov dword ptr [r14 + 0x74], 6
004c772a  e97a030000               jmp 0x4c7aa9
004c772f  498bce                   mov rcx, r14
004c7732  e8293c0000               call 0x4cb360
004c7737  498d8e80000000           lea rcx, [r14 + 0x80]
004c773e  e80da90200               call 0x4f2050
004c7743  41c7467406000000         mov dword ptr [r14 + 0x74], 6
004c774b  e959030000               jmp 0x4c7aa9
004c7750  498bce                   mov rcx, r14
004c7753  e808370000               call 0x4cae60
004c7758  e94c030000               jmp 0x4c7aa9
004c775d  498bce                   mov rcx, r14
004c7760  e82b330000               call 0x4caa90
004c7765  e93f030000               jmp 0x4c7aa9
004c776a  410f108648010000         movups xmm0, xmmword ptr [r14 + 0x148]
004c7772  0f11442478               movups xmmword ptr [rsp + 0x78], xmm0
004c7777  410f108e20010000         movups xmm1, xmmword ptr [r14 + 0x120]
004c777f  0f114d88                 movups xmmword ptr [rbp - 0x78], xmm1
004c7783  4183bec800000001         cmp dword ptr [r14 + 0xc8], 1
004c778b  7c0a                     jl 0x4c7797
004c778d  410fb6be9a020000         movzx edi, byte ptr [r14 + 0x29a]
004c7795  eb03                     jmp 0x4c779a
004c7797  40b705                   mov dil, 5
004c779a  498bce                   mov rcx, r14
004c779d  e87efdffff               call 0x4c7520
004c77a2  488bd8                   mov rbx, rax
004c77a5  4533ff                   xor r15d, r15d
004c77a8  4183ff02                 cmp r15d, 2
004c77ac  750a                     jne 0x4c77b8
004c77ae  498bce                   mov rcx, r14
004c77b1  e8da320000               call 0x4caa90
004c77b6  eb47                     jmp 0x4c77ff
004c77b8  488d4588                 lea rax, [rbp - 0x78]
004c77bc  4889442420               mov qword ptr [rsp + 0x20], rax
004c77c1  440fb6cf                 movzx r9d, dil
004c77c5  4c8d442478               lea r8, [rsp + 0x78]
004c77ca  418bd7                   mov edx, r15d
004c77cd  488bcb                   mov rcx, rbx
004c77d0  e88b6b0300               call 0x4fe360
004c77d5  488b03                   mov rax, qword ptr [rbx]
004c77d8  488bcb                   mov rcx, rbx
004c77db  ff5030                   call qword ptr [rax + 0x30]
004c77de  84c0                     test al, al
004c77e0  741d                     je 0x4c77ff
004c77e2  488b03                   mov rax, qword ptr [rbx]
004c77e5  488bcb                   mov rcx, rbx
004c77e8  ff5070                   call qword ptr [rax + 0x70]
004c77eb  b103                     mov cl, 3
004c77ed  e8de65b4ff               call 0xddd0
004c77f2  488b03                   mov rax, qword ptr [rbx]
004c77f5  488bcb                   mov rcx, rbx
004c77f8  ff5030                   call qword ptr [rax + 0x30]
004c77fb  84c0                     test al, al
004c77fd  75e3                     jne 0x4c77e2
004c77ff  41ffc7                   inc r15d
004c7802  4183ff04                 cmp r15d, 4
004c7806  7ca0                     jl 0x4c77a8
004c7808  498d8e80000000           lea rcx, [r14 + 0x80]
004c780f  e8fc9d0200               call 0x4f1610
004c7814  e990020000               jmp 0x4c7aa9
004c7819  498bce                   mov rcx, r14
004c781c  e83f3b0000               call 0x4cb360
004c7821  e983020000               jmp 0x4c7aa9
004c7826  4533ff                   xor r15d, r15d
004c7829  41837e7804               cmp dword ptr [r14 + 0x78], 4
004c782e  410f95c7                 setne r15b
004c7832  41ffc7                   inc r15d
004c7835  41807e2e00               cmp byte ptr [r14 + 0x2e], 0
004c783a  7515                     jne 0x4c7851
004c783c  498b8630040000           mov rax, qword ptr [r14 + 0x430]
004c7843  4885c0                   test rax, rax
004c7846  7409                     je 0x4c7851
004c7848  44897810                 mov dword ptr [rax + 0x10], r15d
004c784c  e958020000               jmp 0x4c7aa9
004c7851  498b9e40040000           mov rbx, qword ptr [r14 + 0x440]
004c7858  ff15da156102             call qword ptr [rip + 0x26115da]
004c785e  83b8c82e000000           cmp dword ptr [rax + 0x2ec8], 0
004c7865  740d                     je 0x4c7874
004c7867  803dc2f6610200           cmp byte ptr [rip + 0x261f6c2], 0
004c786e  0f8435020000             je 0x4c7aa9
004c7874  8b83c8010000             mov eax, dword ptr [rbx + 0x1c8]
004c787a  83f801                   cmp eax, 1
004c787d  0f8526020000             jne 0x4c7aa9
004c7883  488b05f6236102           mov rax, qword ptr [rip + 0x26123f6]
004c788a  488b88f0a80000           mov rcx, qword ptr [rax + 0xa8f0]
004c7891  8b4150                   mov eax, dword ptr [rcx + 0x50]
004c7894  83f803                   cmp eax, 3
004c7897  0f840c020000             je 0x4c7aa9
004c789d  8b4150                   mov eax, dword ptr [rcx + 0x50]
004c78a0  85c0                     test eax, eax
004c78a2  0f8401020000             je 0x4c7aa9
004c78a8  80bbe700000000           cmp byte ptr [rbx + 0xe7], 0
004c78af  0f85f4010000             jne 0x4c7aa9
004c78b5  498bbe40040000           mov rdi, qword ptr [r14 + 0x440]
004c78bc  488bbf38010000           mov rdi, qword ptr [rdi + 0x138]
004c78c3  65488b142558000000       mov rdx, qword ptr gs:[0x58]
004c78cc  488b05a536a001           mov rax, qword ptr [rip + 0x1a036a5]
004c78d3  8b18                     mov ebx, dword ptr [rax]
004c78d5  488b05a436a001           mov rax, qword ptr [rip + 0x1a036a4]
004c78dc  8b08                     mov ecx, dword ptr [rax]
004c78de  488b1cda                 mov rbx, qword ptr [rdx + rbx*8]
004c78e2  488b1c19                 mov rbx, qword ptr [rcx + rbx]
004c78e6  498b4e10                 mov rcx, qword ptr [r14 + 0x10]
004c78ea  488b01                   mov rax, qword ptr [rcx]
004c78ed  ff5010                   call qword ptr [rax + 0x10]
004c78f0  488bd0                   mov rdx, rax
004c78f3  44897c2430               mov dword ptr [rsp + 0x30], r15d
004c78f8  498b8638010000           mov rax, qword ptr [r14 + 0x138]
004c78ff  4889442428               mov qword ptr [rsp + 0x28], rax
004c7904  410fb686f8000000         movzx eax, byte ptr [r14 + 0xf8]
004c790c  88442420                 mov byte ptr [rsp + 0x20], al
004c7910  4d8d8ee8000000           lea r9, [r14 + 0xe8]
004c7917  4c8bc7                   mov r8, rdi
004c791a  488b8b90000000           mov rcx, qword ptr [rbx + 0x90]
004c7921  e8fa620200               call 0x4edc20
004c7926  e97e010000               jmp 0x4c7aa9
004c792b  498bce                   mov rcx, r14
004c792e  e8bd290000               call 0x4ca2f0
004c7933  e971010000               jmp 0x4c7aa9
004c7938  498bce                   mov rcx, r14
004c793b  e890040000               call 0x4c7dd0
004c7940  e964010000               jmp 0x4c7aa9
004c7945  c644245000               mov byte ptr [rsp + 0x50], 0
004c794a  4533ff                   xor r15d, r15d
004c794d  c744245803a50000         mov dword ptr [rsp + 0x58], 0xa503
004c7955  0f57c0                   xorps xmm0, xmm0
004c7958  f30f7f442460             movdqu xmmword ptr [rsp + 0x60], xmm0
004c795e  44897c2470               mov dword ptr [rsp + 0x70], r15d
004c7963  c644245001               mov byte ptr [rsp + 0x50], 1
004c7968  488d4da0                 lea rcx, [rbp - 0x60]
004c796c  e84f590000               call 0x4cd2c0
004c7971  44897d90                 mov dword ptr [rbp - 0x70], r15d
004c7975  4c897d88                 mov qword ptr [rbp - 0x78], r15
004c7979  4c897c2440               mov qword ptr [rsp + 0x40], r15
004c797e  4c897c2438               mov qword ptr [rsp + 0x38], r15
004c7983  488d45a0                 lea rax, [rbp - 0x60]
004c7987  4889442430               mov qword ptr [rsp + 0x30], rax
004c798c  c744242805000000         mov dword ptr [rsp + 0x28], 5
004c7994  44897c2420               mov dword ptr [rsp + 0x20], r15d
004c7999  4c8d4d88                 lea r9, [rbp - 0x78]
004c799d  4533c0                   xor r8d, r8d
004c79a0  488d542450               lea rdx, [rsp + 0x50]
004c79a5  498bce                   mov rcx, r14
004c79a8  e8030b0000               call 0x4c84b0
004c79ad  4983be0001000001         cmp qword ptr [r14 + 0x100], 1
004c79b5  7552                     jne 0x4c7a09
004c79b7  4538bef8000000           cmp byte ptr [r14 + 0xf8], r15b
004c79be  7549                     jne 0x4c7a09
004c79c0  0fb685fd000000           movzx eax, byte ptr [rbp + 0xfd]
004c79c7  84c0                     test al, al
004c79c9  7560                     jne 0x4c7a2b
004c79cb  3885fe000000             cmp byte ptr [rbp + 0xfe], al
004c79d1  7518                     jne 0x4c79eb
004c79d3  84c0                     test al, al
004c79d5  7554                     jne 0x4c7a2b
004c79d7  388500010000             cmp byte ptr [rbp + 0x100], al
004c79dd  750c                     jne 0x4c79eb
004c79df  84c0                     test al, al
004c79e1  7548                     jne 0x4c7a2b
004c79e3  388501010000             cmp byte ptr [rbp + 0x101], al
004c79e9  7425                     je 0x4c7a10
004c79eb  4983be1002000000         cmp qword ptr [r14 + 0x210], 0
004c79f3  751f                     jne 0x4c7a14
004c79f5  498d8e80000000           lea rcx, [r14 + 0x80]
004c79fc  e88f9a0200               call 0x4f1490
004c7a01  498bce                   mov rcx, r14
004c7a04  e8d7f9ffff               call 0x4c73e0
004c7a09  0fb685fd000000           movzx eax, byte ptr [rbp + 0xfd]
004c7a10  84c0                     test al, al
004c7a12  7517                     jne 0x4c7a2b
004c7a14  80bd0001000000           cmp byte ptr [rbp + 0x100], 0
004c7a1b  740e                     je 0x4c7a2b
004c7a1d  ba09000000               mov edx, 9
004c7a22  498bce                   mov rcx, r14
004c7a25  e8e6000000               call 0x4c7b10
004c7a2a  90                       nop
004c7a2b  807c245000               cmp byte ptr [rsp + 0x50], 0
004c7a30  7477                     je 0x4c7aa9
004c7a32  c644245000               mov byte ptr [rsp + 0x50], 0
004c7a37  f644245a01               test byte ptr [rsp + 0x5a], 1
004c7a3c  7412                     je 0x4c7a50
004c7a3e  488b1533d4ca01           mov rdx, qword ptr [rip + 0x1cad433]
004c7a45  488d4c2458               lea rcx, [rsp + 0x58]
004c7a4a  ff15c841a001             call qword ptr [rip + 0x1a041c8]
004c7a50  6644897c245a             mov word ptr [rsp + 0x5a], r15w
004c7a56  c744245803000000         mov dword ptr [rsp + 0x58], 3
004c7a5e  0f57c0                   xorps xmm0, xmm0
004c7a61  f30f7f442460             movdqu xmmword ptr [rsp + 0x60], xmm0
004c7a67  44897c2470               mov dword ptr [rsp + 0x70], r15d
004c7a6c  66c744245803a5           mov word ptr [rsp + 0x58], 0xa503
004c7a73  f30f7f442460             movdqu xmmword ptr [rsp + 0x60], xmm0
004c7a79  44897c2470               mov dword ptr [rsp + 0x70], r15d
004c7a7e  eb29                     jmp 0x4c7aa9
004c7a80  41f686c803000001         test byte ptr [r14 + 0x3c8], 1
004c7a88  741f                     je 0x4c7aa9
004c7a8a  498b8630040000           mov rax, qword ptr [r14 + 0x430]
004c7a91  c6806301000001           mov byte ptr [rax + 0x163], 1
004c7a98  c6806601000001           mov byte ptr [rax + 0x166], 1
004c7a9f  eb08                     jmp 0x4c7aa9
004c7aa1  498bce                   mov rcx, r14
004c7aa4  e8671d0000               call 0x4c9810
004c7aa9  b102                     mov cl, 2
004c7aab  e82063b4ff               call 0xddd0
004c7ab0  488b8d10010000           mov rcx, qword ptr [rbp + 0x110]
004c7ab7  4833cc                   xor rcx, rsp
004c7aba  e8b195b3ff               call 0x1070
004c7abf  4c8d9c2420020000         lea r11, [rsp + 0x220]
004c7ac7  498b5b28                 mov rbx, qword ptr [r11 + 0x28]
004c7acb  498b7330                 mov rsi, qword ptr [r11 + 0x30]
004c7acf  498b7b38                 mov rdi, qword ptr [r11 + 0x38]
004c7ad3  498be3                   mov rsp, r11
004c7ad6  415f                     pop r15
004c7ad8  415e                     pop r14
004c7ada  5d                       pop rbp
004c7adb  c3                       ret
004c7adc  6a77                     push 0x77
004c7ade  4c005d77                 add byte ptr [rbp + 0x77], r11b
004c7ae2  4c0019                   add byte ptr [rcx], r11b
004c7ae5  784c                     js 0x4c7b33
004c7ae7  002b                     add byte ptr [rbx], ch
004c7ae9  794c                     jns 0x4c7b37
004c7aeb  0038                     add byte ptr [rax], bh
004c7aed  794c                     jns 0x4c7b3b
004c7aef  004579                   add byte ptr [rbp + 0x79], al
004c7af2  4c00807a4c003d           add byte ptr [rax + 0x3d004c7a], r8b
004c7af9  764c                     jbe 0x4c7b47
004c7afb  005077                   add byte ptr [rax + 0x77], dl
004c7afe  4c00a17a4c0026           add byte ptr [rcx + 0x26004c7a], r12b
004c7b05  784c                     js 0x4c7b53
