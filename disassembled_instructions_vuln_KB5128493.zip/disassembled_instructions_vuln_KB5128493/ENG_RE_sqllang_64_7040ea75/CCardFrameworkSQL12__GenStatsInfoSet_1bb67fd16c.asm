; CCardFrameworkSQL12::GenStatsInfoSet
; sqllang.dll, primary RVA 0x22e820, 303 bytes in 6 chunk(s)

; chunk at RVA 0x22e820 (44 bytes)
0022e820  488bc4                   mov rax, rsp
0022e823  56                       push rsi
0022e824  57                       push rdi
0022e825  4881ec98000000           sub rsp, 0x98
0022e82c  4c8b4970                 mov r9, qword ptr [rcx + 0x70]
0022e830  488bf1                   mov rsi, rcx
0022e833  4d85c9                   test r9, r9
0022e836  0f84690c0000             je 0x22f4a5
0022e83c  418b7918                 mov edi, dword ptr [r9 + 0x18]
0022e840  85ff                     test edi, edi
0022e842  0f845d0c0000             je 0x22f4a5
0022e848  458b410c                 mov r8d, dword ptr [r9 + 0xc]

; chunk at RVA 0x22e84c (4 bytes)
0022e84c  488958e8                 mov qword ptr [rax - 0x18], rbx

; chunk at RVA 0x22e850 (165 bytes)
0022e850  488968e0                 mov qword ptr [rax - 0x20], rbp
0022e854  4c8960d8                 mov qword ptr [rax - 0x28], r12
0022e858  4533e4                   xor r12d, r12d
0022e85b  4c8968d0                 mov qword ptr [rax - 0x30], r13
0022e85f  418bec                   mov ebp, r12d
0022e862  4c8970c8                 mov qword ptr [rax - 0x38], r14
0022e866  418bd4                   mov edx, r12d
0022e869  4c8978c0                 mov qword ptr [rax - 0x40], r15
0022e86d  4489a424b0000000         mov dword ptr [rsp + 0xb0], r12d
0022e875  4585c0                   test r8d, r8d
0022e878  7415                     je 0x22e88f
0022e87a  498b4910                 mov rcx, qword ptr [r9 + 0x10]
0022e87e  6690                     nop
0022e880  8bc2                     mov eax, edx
0022e882  48392cc1                 cmp qword ptr [rcx + rax*8], rbp
0022e886  7507                     jne 0x22e88f
0022e888  ffc2                     inc edx
0022e88a  413bd0                   cmp edx, r8d
0022e88d  72f1                     jb 0x22e880
0022e88f  413bd0                   cmp edx, r8d
0022e892  0f84a2470300             je 0x26303a
0022e898  4d8b4910                 mov r9, qword ptr [r9 + 0x10]
0022e89c  8bc2                     mov eax, edx
0022e89e  4d8b14c1                 mov r10, qword ptr [r9 + rax*8]
0022e8a2  4d85d2                   test r10, r10
0022e8a5  0f848f470300             je 0x26303a
0022e8ab  0f1f440000               nop dword ptr [rax + rax]
0022e8b0  498b4208                 mov rax, qword ptr [r10 + 8]
0022e8b4  8b4848                   mov ecx, dword ptr [rax + 0x48]
0022e8b7  034844                   add ecx, dword ptr [rax + 0x44]
0022e8ba  034840                   add ecx, dword ptr [rax + 0x40]
0022e8bd  03483c                   add ecx, dword ptr [rax + 0x3c]
0022e8c0  498b02                   mov rax, qword ptr [r10]
0022e8c3  03e9                     add ebp, ecx
0022e8c5  4c8bd0                   mov r10, rax
0022e8c8  4885c0                   test rax, rax
0022e8cb  751d                     jne 0x22e8ea
0022e8cd  0f1f00                   nop dword ptr [rax]
0022e8d0  ffc2                     inc edx
0022e8d2  8bc2                     mov eax, edx
0022e8d4  413bd0                   cmp edx, r8d
0022e8d7  0f834d470300             jae 0x26302a
0022e8dd  4d3924d1                 cmp qword ptr [r9 + rdx*8], r12
0022e8e1  74ed                     je 0x22e8d0
0022e8e3  eb01                     jmp 0x22e8e6
0022e8e5  cc                       int3
0022e8e6  4d8b14d1                 mov r10, qword ptr [r9 + rdx*8]
0022e8ea  4d85d2                   test r10, r10
0022e8ed  75c1                     jne 0x22e8b0
0022e8ef  e93f470300               jmp 0x263033
0022e8f4  cc                       int3

; chunk at RVA 0x22f4a5 (12 bytes)
0022f4a5  33c0                     xor eax, eax
0022f4a7  4881c498000000           add rsp, 0x98
0022f4ae  5f                       pop rdi
0022f4af  5e                       pop rsi
0022f4b0  c3                       ret

; chunk at RVA 0x2632e5 (31 bytes)
002632e5  488bc3                   mov rax, rbx
002632e8  4c8b742470               mov r14, qword ptr [rsp + 0x70]
002632ed  488b9c2490000000         mov rbx, qword ptr [rsp + 0x90]
002632f5  4c8b7c2468               mov r15, qword ptr [rsp + 0x68]
002632fa  4881c498000000           add rsp, 0x98
00263301  5f                       pop rdi
00263302  5e                       pop rsi
00263303  c3                       ret

; chunk at RVA 0x18f1b7a (47 bytes)
018f1b7a  498b06                   mov rax, qword ptr [r14]
018f1b7d  4c8bc3                   mov r8, rbx
018f1b80  498b5708                 mov rdx, qword ptr [r15 + 8]
018f1b84  498bce                   mov rcx, r14
018f1b87  ff5050                   call qword ptr [rax + 0x50]
018f1b8a  4885c0                   test rax, rax
018f1b8d  0f85551797fe             jne 0x2632e8
018f1b93  498b06                   mov rax, qword ptr [r14]
018f1b96  4c8bc3                   mov r8, rbx
018f1b99  498b5708                 mov rdx, qword ptr [r15 + 8]
018f1b9d  498bce                   mov rcx, r14
018f1ba0  ff5010                   call qword ptr [rax + 0x10]
018f1ba3  e9401797fe               jmp 0x2632e8
018f1ba8  cc                       int3
