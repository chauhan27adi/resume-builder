; CCardFrameworkSQL12::IsFullStatisticRequired
; sqllang.dll, primary RVA 0x18f1a60, 91 bytes in 1 chunk(s)

; chunk at RVA 0x18f1a60 (91 bytes)
018f1a60  4883ec28                 sub rsp, 0x28
018f1a64  488b02                   mov rax, qword ptr [rdx]
018f1a67  488bca                   mov rcx, rdx
018f1a6a  ff5018                   call qword ptr [rax + 0x18]
018f1a6d  83c0f2                   add eax, -0xe
018f1a70  83f812                   cmp eax, 0x12
018f1a73  7724                     ja 0x18f1a99
018f1a75  488d1584e570fe           lea rdx, [rip - 0x18f1a7c]
018f1a7c  4898                     cdqe
018f1a7e  0fb68402a81a8f01         movzx eax, byte ptr [rdx + rax + 0x18f1aa8]
018f1a86  8b8c82a01a8f01           mov ecx, dword ptr [rdx + rax*4 + 0x18f1aa0]
018f1a8d  4803ca                   add rcx, rdx
018f1a90  ffe1                     jmp rcx
018f1a92  b001                     mov al, 1
018f1a94  4883c428                 add rsp, 0x28
018f1a98  c3                       ret
018f1a99  32c0                     xor al, al
018f1a9b  4883c428                 add rsp, 0x28
018f1a9f  c3                       ret
018f1aa0  92                       xchg edx, eax
018f1aa1  1a8f01991a8f             sbb cl, byte ptr [rdi - 0x70e566ff]
018f1aa7  0100                     add dword ptr [rax], eax
018f1aa9  0100                     add dword ptr [rax], eax
018f1aab  0000                     add byte ptr [rax], al
018f1aad  0000                     add byte ptr [rax], al
018f1aaf  0000                     add byte ptr [rax], al
018f1ab1  0101                     add dword ptr [rcx], eax
018f1ab3  0101                     add dword ptr [rcx], eax
018f1ab5  0101                     add dword ptr [rcx], eax
018f1ab7  0101                     add dword ptr [rcx], eax
018f1ab9  0100                     add dword ptr [rax], eax
