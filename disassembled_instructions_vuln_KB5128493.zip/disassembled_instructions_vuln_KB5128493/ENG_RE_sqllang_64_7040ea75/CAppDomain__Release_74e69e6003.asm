; CAppDomain::Release
; sqllang.dll, primary RVA 0x6b0e50, 316 bytes in 1 chunk(s)

; chunk at RVA 0x6b0e50 (316 bytes)
006b0e50  4053                     push rbx
006b0e52  4883ec30                 sub rsp, 0x30
006b0e56  488b81d0010000           mov rax, qword ptr [rcx + 0x1d0]
006b0e5d  488bd9                   mov rbx, rcx
006b0e60  4889442448               mov qword ptr [rsp + 0x48], rax
006b0e65  488b442448               mov rax, qword ptr [rsp + 0x48]
006b0e6a  4889442440               mov qword ptr [rsp + 0x40], rax
006b0e6f  8b442440                 mov eax, dword ptr [rsp + 0x40]
006b0e73  ffc8                     dec eax
006b0e75  89442440                 mov dword ptr [rsp + 0x40], eax
006b0e79  488b442448               mov rax, qword ptr [rsp + 0x48]
006b0e7e  488b542440               mov rdx, qword ptr [rsp + 0x40]
006b0e83  f0480fb191d0010000       lock cmpxchg qword ptr [rcx + 0x1d0], rdx
006b0e8c  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
006b0e91  483bc8                   cmp rcx, rax
006b0e94  7449                     je 0x6b0edf
006b0e96  0f0d8bd0010000           prefetchw byte ptr [rbx + 0x1d0]
006b0e9d  0f1f00                   nop dword ptr [rax]
006b0ea0  f390                     pause
006b0ea2  488b83d0010000           mov rax, qword ptr [rbx + 0x1d0]
006b0ea9  4889442448               mov qword ptr [rsp + 0x48], rax
006b0eae  488b442448               mov rax, qword ptr [rsp + 0x48]
006b0eb3  4889442440               mov qword ptr [rsp + 0x40], rax
006b0eb8  8b442440                 mov eax, dword ptr [rsp + 0x40]
006b0ebc  ffc8                     dec eax
006b0ebe  89442440                 mov dword ptr [rsp + 0x40], eax
006b0ec2  488b442448               mov rax, qword ptr [rsp + 0x48]
006b0ec7  488b4c2440               mov rcx, qword ptr [rsp + 0x40]
006b0ecc  f0480fb18bd0010000       lock cmpxchg qword ptr [rbx + 0x1d0], rcx
006b0ed5  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
006b0eda  483bc8                   cmp rcx, rax
006b0edd  75c1                     jne 0x6b0ea0
006b0edf  488b442440               mov rax, qword ptr [rsp + 0x40]
006b0ee4  4889442448               mov qword ptr [rsp + 0x48], rax
006b0ee9  8b442448                 mov eax, dword ptr [rsp + 0x48]
006b0eed  85c0                     test eax, eax
006b0eef  7573                     jne 0x6b0f64
006b0ef1  8b44244c                 mov eax, dword ptr [rsp + 0x4c]
006b0ef5  83f802                   cmp eax, 2
006b0ef8  746a                     je 0x6b0f64
006b0efa  8b44244c                 mov eax, dword ptr [rsp + 0x4c]
006b0efe  83f806                   cmp eax, 6
006b0f01  7f61                     jg 0x6b0f64
006b0f03  4863442444               movsxd rax, dword ptr [rsp + 0x44]
006b0f08  83f806                   cmp eax, 6
006b0f0b  771d                     ja 0x6b0f2a
006b0f0d  488d15ecf094ff           lea rdx, [rip - 0x6b0f14]
006b0f14  8b8c82700f6b00           mov ecx, dword ptr [rdx + rax*4 + 0x6b0f70]
006b0f1b  4803ca                   add rcx, rdx
006b0f1e  ffe1                     jmp rcx
006b0f20  488bcb                   mov rcx, rbx
006b0f23  e848edffff               call 0x6afc70
006b0f28  eb2b                     jmp 0x6b0f55
006b0f2a  488d052f7baa01           lea rax, [rip + 0x1aa7b2f]
006b0f31  41b9f9090000             mov r9d, 0x9f9
006b0f37  4c8d05722ee601           lea r8, [rip + 0x1e62e72]
006b0f3e  4889442420               mov qword ptr [rsp + 0x20], rax
006b0f43  488d15d658e601           lea rdx, [rip + 0x1e658d6]
006b0f4a  b901000000               mov ecx, 1
006b0f4f  ff15239f8101             call qword ptr [rip + 0x1819f23]
006b0f55  488b8bd8000000           mov rcx, qword ptr [rbx + 0xd8]
006b0f5c  488bd3                   mov rdx, rbx
006b0f5f  e81c530100               call 0x6c6280
006b0f64  8b442440                 mov eax, dword ptr [rsp + 0x40]
006b0f68  4883c430                 add rsp, 0x30
006b0f6c  5b                       pop rbx
006b0f6d  c3                       ret
006b0f6e  6690                     nop
006b0f70  55                       push rbp
006b0f71  0f6b00                   packssdw mm0, qword ptr [rax]
006b0f74  200f                     and byte ptr [rdi], cl
006b0f76  6b002a                   imul eax, dword ptr [rax], 0x2a
006b0f79  0f6b00                   packssdw mm0, qword ptr [rax]
006b0f7c  200f                     and byte ptr [rdi], cl
006b0f7e  6b0020                   imul eax, dword ptr [rax], 0x20
006b0f81  0f6b00                   packssdw mm0, qword ptr [rax]
006b0f84  55                       push rbp
006b0f85  0f6b00                   packssdw mm0, qword ptr [rax]
006b0f88  55                       push rbp
006b0f89  0f6b00                   packssdw mm0, qword ptr [rax]
