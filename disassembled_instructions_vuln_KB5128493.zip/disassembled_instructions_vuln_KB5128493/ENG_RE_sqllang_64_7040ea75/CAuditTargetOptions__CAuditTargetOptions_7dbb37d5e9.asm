; CAuditTargetOptions::CAuditTargetOptions
; sqllang.dll, primary RVA 0x108c4a0, 588 bytes in 1 chunk(s)

; chunk at RVA 0x108c4a0 (588 bytes)
0108c4a0  4c89442418               mov qword ptr [rsp + 0x18], r8
0108c4a5  53                       push rbx
0108c4a6  55                       push rbp
0108c4a7  56                       push rsi
0108c4a8  57                       push rdi
0108c4a9  4154                     push r12
0108c4ab  4156                     push r14
0108c4ad  4157                     push r15
0108c4af  4883ec50                 sub rsp, 0x50
0108c4b3  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
0108c4bc  4d8bf8                   mov r15, r8
0108c4bf  4c8bf2                   mov r14, rdx
0108c4c2  488bf1                   mov rsi, rcx
0108c4c5  8b02                     mov eax, dword ptr [rdx]
0108c4c7  8901                     mov dword ptr [rcx], eax
0108c4c9  48837a0800               cmp qword ptr [rdx + 8], 0
0108c4ce  0f84e2010000             je 0x108c6b6
0108c4d4  c7842490000000c8060000   mov dword ptr [rsp + 0x90], 0x6c8
0108c4df  c644242003               mov byte ptr [rsp + 0x20], 3
0108c4e4  41b9c8060000             mov r9d, 0x6c8
0108c4ea  4c8d05c7443a01           lea r8, [rip + 0x13a44c7]
0108c4f1  498bd7                   mov rdx, r15
0108c4f4  b910000000               mov ecx, 0x10
0108c4f9  ff15b1e9e300             call qword ptr [rip + 0xe3e9b1]
0108c4ff  4889842498000000         mov qword ptr [rsp + 0x98], rax
0108c507  33ed                     xor ebp, ebp
0108c509  4885c0                   test rax, rax
0108c50c  740f                     je 0x108c51d
0108c50e  0f57c0                   xorps xmm0, xmm0
0108c511  0f1100                   movups xmmword ptr [rax], xmm0
0108c514  48894008                 mov qword ptr [rax + 8], rax
0108c518  488900                   mov qword ptr [rax], rax
0108c51b  eb03                     jmp 0x108c520
0108c51d  488bc5                   mov rax, rbp
0108c520  48894608                 mov qword ptr [rsi + 8], rax
0108c524  498b4608                 mov rax, qword ptr [r14 + 8]
0108c528  488b5808                 mov rbx, qword ptr [rax + 8]
0108c52c  483bd8                   cmp rbx, rax
0108c52f  0f8487010000             je 0x108c6bc
0108c535  4885db                   test rbx, rbx
0108c538  0f847e010000             je 0x108c6bc
0108c53e  4c8d25bb3af7fe           lea r12, [rip - 0x108c545]
0108c545  6666660f1f840000000000   nop word ptr [rax + rax]
0108c550  48634310                 movsxd rax, dword ptr [rbx + 0x10]
0108c554  83f806                   cmp eax, 6
0108c557  0f8744010000             ja 0x108c6a1
0108c55d  418b8c84d0c60801         mov ecx, dword ptr [r12 + rax*4 + 0x108c6d0]
0108c565  4903cc                   add rcx, r12
0108c568  ffe1                     jmp rcx
0108c56a  c7842490000000d5060000   mov dword ptr [rsp + 0x90], 0x6d5
0108c575  c644242003               mov byte ptr [rsp + 0x20], 3
0108c57a  41b9d5060000             mov r9d, 0x6d5
0108c580  4c8d0531443a01           lea r8, [rip + 0x13a4431]
0108c587  498bd7                   mov rdx, r15
0108c58a  b928000000               mov ecx, 0x28
0108c58f  ff151be9e300             call qword ptr [rip + 0xe3e91b]
0108c595  488bf8                   mov rdi, rax
0108c598  4889442438               mov qword ptr [rsp + 0x38], rax
0108c59d  4885c0                   test rax, rax
0108c5a0  7436                     je 0x108c5d8
0108c5a2  8b4b10                   mov ecx, dword ptr [rbx + 0x10]
0108c5a5  488928                   mov qword ptr [rax], rbp
0108c5a8  48896808                 mov qword ptr [rax + 8], rbp
0108c5ac  894810                   mov dword ptr [rax + 0x10], ecx
0108c5af  48896818                 mov qword ptr [rax + 0x18], rbp
0108c5b3  896820                   mov dword ptr [rax + 0x20], ebp
0108c5b6  448b4320                 mov r8d, dword ptr [rbx + 0x20]
0108c5ba  4585c0                   test r8d, r8d
0108c5bd  741c                     je 0x108c5db
0108c5bf  488b5318                 mov rdx, qword ptr [rbx + 0x18]
0108c5c3  498bcf                   mov rcx, r15
0108c5c6  ff156cf7e300             call qword ptr [rip + 0xe3f76c]
0108c5cc  48894718                 mov qword ptr [rdi + 0x18], rax
0108c5d0  8b4320                   mov eax, dword ptr [rbx + 0x20]
0108c5d3  894720                   mov dword ptr [rdi + 0x20], eax
0108c5d6  eb03                     jmp 0x108c5db
0108c5d8  488bfd                   mov rdi, rbp
0108c5db  e9a4000000               jmp 0x108c684
0108c5e0  c7842498000000dc060000   mov dword ptr [rsp + 0x98], 0x6dc
0108c5eb  c644242003               mov byte ptr [rsp + 0x20], 3
0108c5f0  41b9dc060000             mov r9d, 0x6dc
0108c5f6  4c8d05bb433a01           lea r8, [rip + 0x13a43bb]
0108c5fd  498bd7                   mov rdx, r15
0108c600  b920000000               mov ecx, 0x20
0108c605  ff15a5e8e300             call qword ptr [rip + 0xe3e8a5]
0108c60b  488bf8                   mov rdi, rax
0108c60e  4889442440               mov qword ptr [rsp + 0x40], rax
0108c613  4885c0                   test rax, rax
0108c616  7417                     je 0x108c62f
0108c618  8b4310                   mov eax, dword ptr [rbx + 0x10]
0108c61b  48892f                   mov qword ptr [rdi], rbp
0108c61e  48896f08                 mov qword ptr [rdi + 8], rbp
0108c622  894710                   mov dword ptr [rdi + 0x10], eax
0108c625  488b4318                 mov rax, qword ptr [rbx + 0x18]
0108c629  48894718                 mov qword ptr [rdi + 0x18], rax
0108c62d  eb03                     jmp 0x108c632
0108c62f  488bfd                   mov rdi, rbp
0108c632  eb50                     jmp 0x108c684
0108c634  c78424a8000000e7060000   mov dword ptr [rsp + 0xa8], 0x6e7
0108c63f  c644242003               mov byte ptr [rsp + 0x20], 3
0108c644  41b9e7060000             mov r9d, 0x6e7
0108c64a  4c8d0567433a01           lea r8, [rip + 0x13a4367]
0108c651  498bd7                   mov rdx, r15
0108c654  b920000000               mov ecx, 0x20
0108c659  ff1551e8e300             call qword ptr [rip + 0xe3e851]
0108c65f  488bf8                   mov rdi, rax
0108c662  4889442448               mov qword ptr [rsp + 0x48], rax
0108c667  4885c0                   test rax, rax
0108c66a  7415                     je 0x108c681
0108c66c  8b4310                   mov eax, dword ptr [rbx + 0x10]
0108c66f  48892f                   mov qword ptr [rdi], rbp
0108c672  48896f08                 mov qword ptr [rdi + 8], rbp
0108c676  894710                   mov dword ptr [rdi + 0x10], eax
0108c679  8b4318                   mov eax, dword ptr [rbx + 0x18]
0108c67c  894718                   mov dword ptr [rdi + 0x18], eax
0108c67f  eb03                     jmp 0x108c684
0108c681  488bfd                   mov rdi, rbp
0108c684  4885ff                   test rdi, rdi
0108c687  7418                     je 0x108c6a1
0108c689  488b4e08                 mov rcx, qword ptr [rsi + 8]
0108c68d  488b01                   mov rax, qword ptr [rcx]
0108c690  488907                   mov qword ptr [rdi], rax
0108c693  488b01                   mov rax, qword ptr [rcx]
0108c696  48897808                 mov qword ptr [rax + 8], rdi
0108c69a  488939                   mov qword ptr [rcx], rdi
0108c69d  48894f08                 mov qword ptr [rdi + 8], rcx
0108c6a1  488b5b08                 mov rbx, qword ptr [rbx + 8]
0108c6a5  493b5e08                 cmp rbx, qword ptr [r14 + 8]
0108c6a9  7411                     je 0x108c6bc
0108c6ab  4885db                   test rbx, rbx
0108c6ae  0f859cfeffff             jne 0x108c550
0108c6b4  eb06                     jmp 0x108c6bc
0108c6b6  33ed                     xor ebp, ebp
0108c6b8  48896908                 mov qword ptr [rcx + 8], rbp
0108c6bc  488bc6                   mov rax, rsi
0108c6bf  4883c450                 add rsp, 0x50
0108c6c3  415f                     pop r15
0108c6c5  415e                     pop r14
0108c6c7  415c                     pop r12
0108c6c9  5f                       pop rdi
0108c6ca  5e                       pop rsi
0108c6cb  5d                       pop rbp
0108c6cc  5b                       pop rbx
0108c6cd  c3                       ret
0108c6ce  6690                     nop
0108c6d0  6ac5                     push -0x3b
0108c6d2  0801                     or byte ptr [rcx], al
0108c6d4  e0c5                     loopne 0x108c69b
0108c6d6  0801                     or byte ptr [rcx], al
0108c6d8  34c6                     xor al, 0xc6
0108c6da  0801                     or byte ptr [rcx], al
0108c6dc  34c6                     xor al, 0xc6
0108c6de  0801                     or byte ptr [rcx], al
0108c6e0  34c6                     xor al, 0xc6
0108c6e2  0801                     or byte ptr [rcx], al
0108c6e4  34c6                     xor al, 0xc6
0108c6e6  0801                     or byte ptr [rcx], al
0108c6e8  6ac5                     push -0x3b
0108c6ea  0801                     or byte ptr [rcx], al
