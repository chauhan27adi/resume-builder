; CDialogEndpoint::EnqueueError
; sqllang.dll, primary RVA 0x4ca2f0, 1464 bytes in 1 chunk(s)

; chunk at RVA 0x4ca2f0 (1464 bytes)
004ca2f0  488bc4                   mov rax, rsp
004ca2f3  55                       push rbp
004ca2f4  4154                     push r12
004ca2f6  4155                     push r13
004ca2f8  4156                     push r14
004ca2fa  4157                     push r15
004ca2fc  488d6c2480               lea rbp, [rsp - 0x80]
004ca301  4881ec80010000           sub rsp, 0x180
004ca308  48c74500feffffff         mov qword ptr [rbp], 0xfffffffffffffffe
004ca310  48895810                 mov qword ptr [rax + 0x10], rbx
004ca314  48897018                 mov qword ptr [rax + 0x18], rsi
004ca318  48897820                 mov qword ptr [rax + 0x20], rdi
004ca31c  488b0565f96002           mov rax, qword ptr [rip + 0x260f965]
004ca323  4833c4                   xor rax, rsp
004ca326  48894570                 mov qword ptr [rbp + 0x70], rax
004ca32a  488bf9                   mov rdi, rcx
004ca32d  48894dd0                 mov qword ptr [rbp - 0x30], rcx
004ca331  488d1d50ece401           lea rbx, [rip + 0x1e4ec50]
004ca338  48895d90                 mov qword ptr [rbp - 0x70], rbx
004ca33c  c645a000                 mov byte ptr [rbp - 0x60], 0
004ca340  4533e4                   xor r12d, r12d
004ca343  4c8965a8                 mov qword ptr [rbp - 0x58], r12
004ca347  4c8965b0                 mov qword ptr [rbp - 0x50], r12
004ca34b  c745b860000000           mov dword ptr [rbp - 0x48], 0x60
004ca352  4c8965c0                 mov qword ptr [rbp - 0x40], r12
004ca356  448965c8                 mov dword ptr [rbp - 0x38], r12d
004ca35a  4c896598                 mov qword ptr [rbp - 0x68], r12
004ca35e  83797806                 cmp dword ptr [rcx + 0x78], 6
004ca362  0f848c040000             je 0x4ca7f4
004ca368  4488642460               mov byte ptr [rsp + 0x60], r12b
004ca36d  c744246803a50000         mov dword ptr [rsp + 0x68], 0xa503
004ca375  0f57c0                   xorps xmm0, xmm0
004ca378  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
004ca37e  44896580                 mov dword ptr [rbp - 0x80], r12d
004ca382  8b4170                   mov eax, dword ptr [rcx + 0x70]
004ca385  85c0                     test eax, eax
004ca387  0f8403040000             je 0x4ca790
004ca38d  83c0fd                   add eax, -3
004ca390  83f813                   cmp eax, 0x13
004ca393  0f870a040000             ja 0x4ca7a3
004ca399  4898                     cdqe
004ca39b  488d155e5cb3ff           lea rdx, [rip - 0x4ca3a2]
004ca3a2  8b8c8258a84c00           mov ecx, dword ptr [rdx + rax*4 + 0x4ca858]
004ca3a9  4803ca                   add rcx, rdx
004ca3ac  ffe1                     jmp rcx
004ca3ae  ba54000000               mov edx, 0x54
004ca3b3  448d42f0                 lea r8d, [rdx - 0x10]
004ca3b7  e9e1020000               jmp 0x4ca69d
004ca3bc  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca3c3  488b01                   mov rax, qword ptr [rcx]
004ca3c6  488d55d0                 lea rdx, [rbp - 0x30]
004ca3ca  ff5030                   call qword ptr [rax + 0x30]
004ca3cd  488bd8                   mov rbx, rax
004ca3d0  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca3d7  4c8b01                   mov r8, qword ptr [rcx]
004ca3da  488d55e0                 lea rdx, [rbp - 0x20]
004ca3de  41ff5030                 call qword ptr [r8 + 0x30]
004ca3e2  488b0b                   mov rcx, qword ptr [rbx]
004ca3e5  48894c2428               mov qword ptr [rsp + 0x28], rcx
004ca3ea  8b4008                   mov eax, dword ptr [rax + 8]
004ca3ed  89442420                 mov dword ptr [rsp + 0x20], eax
004ca3f1  ba54000000               mov edx, 0x54
004ca3f6  448d4abc                 lea r9d, [rdx - 0x44]
004ca3fa  448d420e                 lea r8d, [rdx + 0xe]
004ca3fe  488d4d90                 lea rcx, [rbp - 0x70]
004ca402  e8a930ffff               call 0x4bd4b0
004ca407  e9a0020000               jmp 0x4ca6ac
004ca40c  ba54000000               mov edx, 0x54
004ca411  448d42f4                 lea r8d, [rdx - 0xc]
004ca415  e983020000               jmp 0x4ca69d
004ca41a  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca421  488b01                   mov rax, qword ptr [rcx]
004ca424  ff10                     call qword ptr [rax]
004ca426  0f1000                   movups xmm0, xmmword ptr [rax]
004ca429  0f294510                 movaps xmmword ptr [rbp + 0x10], xmm0
004ca42d  41b827000000             mov r8d, 0x27
004ca433  488d5520                 lea rdx, [rbp + 0x20]
004ca437  488bc8                   mov rcx, rax
004ca43a  ff1560fa9f01             call qword ptr [rip + 0x19ffa60]
004ca440  4489656a                 mov dword ptr [rbp + 0x6a], r12d
004ca444  488b8728030000           mov rax, qword ptr [rdi + 0x328]
004ca44b  488b18                   mov rbx, qword ptr [rax]
004ca44e  488bc8                   mov rcx, rax
004ca451  488d55e0                 lea rdx, [rbp - 0x20]
004ca455  ff5330                   call qword ptr [rbx + 0x30]
004ca458  4c8bf8                   mov r15, rax
004ca45b  488bbf28030000           mov rdi, qword ptr [rdi + 0x328]
004ca462  488bcf                   mov rcx, rdi
004ca465  ff5378                   call qword ptr [rbx + 0x78]
004ca468  488bf0                   mov rsi, rax
004ca46b  488bcf                   mov rcx, rdi
004ca46e  ff5308                   call qword ptr [rbx + 8]
004ca471  0fb6d8                   movzx ebx, al
004ca474  4c8b07                   mov r8, qword ptr [rdi]
004ca477  488d55f0                 lea rdx, [rbp - 0x10]
004ca47b  488bcf                   mov rcx, rdi
004ca47e  41ff5030                 call qword ptr [r8 + 0x30]
004ca482  4889742448               mov qword ptr [rsp + 0x48], rsi
004ca487  895c2440                 mov dword ptr [rsp + 0x40], ebx
004ca48b  488d4d22                 lea rcx, [rbp + 0x22]
004ca48f  48894c2438               mov qword ptr [rsp + 0x38], rcx
004ca494  48c744243048000000       mov qword ptr [rsp + 0x30], 0x48
004ca49d  498b0f                   mov rcx, qword ptr [r15]
004ca4a0  48894c2428               mov qword ptr [rsp + 0x28], rcx
004ca4a5  8b4008                   mov eax, dword ptr [rax + 8]
004ca4a8  89442420                 mov dword ptr [rsp + 0x20], eax
004ca4ac  ba54000000               mov edx, 0x54
004ca4b1  448d4abc                 lea r9d, [rdx - 0x44]
004ca4b5  448d420f                 lea r8d, [rdx + 0xf]
004ca4b9  488d4d90                 lea rcx, [rbp - 0x70]
004ca4bd  e8ee2fffff               call 0x4bd4b0
004ca4c2  488b7dd0                 mov rdi, qword ptr [rbp - 0x30]
004ca4c6  e9e1010000               jmp 0x4ca6ac
004ca4cb  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca4d2  488b01                   mov rax, qword ptr [rcx]
004ca4d5  488d55f0                 lea rdx, [rbp - 0x10]
004ca4d9  ff5030                   call qword ptr [rax + 0x30]
004ca4dc  488bd8                   mov rbx, rax
004ca4df  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca4e6  4c8b01                   mov r8, qword ptr [rcx]
004ca4e9  488d55e0                 lea rdx, [rbp - 0x20]
004ca4ed  41ff5030                 call qword ptr [r8 + 0x30]
004ca4f1  488b0b                   mov rcx, qword ptr [rbx]
004ca4f4  48894c2428               mov qword ptr [rsp + 0x28], rcx
004ca4f9  8b4008                   mov eax, dword ptr [rax + 8]
004ca4fc  89442420                 mov dword ptr [rsp + 0x20], eax
004ca500  ba54000000               mov edx, 0x54
004ca505  448d4abc                 lea r9d, [rdx - 0x44]
004ca509  448d42e5                 lea r8d, [rdx - 0x1b]
004ca50d  488d4d90                 lea rcx, [rbp - 0x70]
004ca511  e89a2fffff               call 0x4bd4b0
004ca516  e991010000               jmp 0x4ca6ac
004ca51b  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca522  488b01                   mov rax, qword ptr [rcx]
004ca525  488d55f0                 lea rdx, [rbp - 0x10]
004ca529  ff5030                   call qword ptr [rax + 0x30]
004ca52c  488bd8                   mov rbx, rax
004ca52f  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca536  4c8b01                   mov r8, qword ptr [rcx]
004ca539  488d55e0                 lea rdx, [rbp - 0x20]
004ca53d  41ff5030                 call qword ptr [r8 + 0x30]
004ca541  488b0b                   mov rcx, qword ptr [rbx]
004ca544  48894c2428               mov qword ptr [rsp + 0x28], rcx
004ca549  8b4008                   mov eax, dword ptr [rax + 8]
004ca54c  89442420                 mov dword ptr [rsp + 0x20], eax
004ca550  ba54000000               mov edx, 0x54
004ca555  448d4abc                 lea r9d, [rdx - 0x44]
004ca559  448d42d1                 lea r8d, [rdx - 0x2f]
004ca55d  488d4d90                 lea rcx, [rbp - 0x70]
004ca561  e84a2fffff               call 0x4bd4b0
004ca566  e941010000               jmp 0x4ca6ac
004ca56b  ba54000000               mov edx, 0x54
004ca570  448d4205                 lea r8d, [rdx + 5]
004ca574  e924010000               jmp 0x4ca69d
004ca579  488b8f28030000           mov rcx, qword ptr [rdi + 0x328]
004ca580  488b01                   mov rax, qword ptr [rcx]
004ca583  ff10                     call qword ptr [rax]
004ca585  0f1000                   movups xmm0, xmmword ptr [rax]
004ca588  0f294510                 movaps xmmword ptr [rbp + 0x10], xmm0
004ca58c  41b827000000             mov r8d, 0x27
004ca592  488d5520                 lea rdx, [rbp + 0x20]
004ca596  488bc8                   mov rcx, rax
004ca599  ff1501f99f01             call qword ptr [rip + 0x19ff901]
004ca59f  4489656a                 mov dword ptr [rbp + 0x6a], r12d
004ca5a3  488b8728030000           mov rax, qword ptr [rdi + 0x328]
004ca5aa  488b18                   mov rbx, qword ptr [rax]
004ca5ad  4c8b6768                 mov r12, qword ptr [rdi + 0x68]
004ca5b1  448b6f60                 mov r13d, dword ptr [rdi + 0x60]
004ca5b5  488bc8                   mov rcx, rax
004ca5b8  488d55f0                 lea rdx, [rbp - 0x10]
004ca5bc  ff5330                   call qword ptr [rbx + 0x30]
004ca5bf  4c8bf8                   mov r15, rax
004ca5c2  488bbf28030000           mov rdi, qword ptr [rdi + 0x328]
004ca5c9  488bcf                   mov rcx, rdi
004ca5cc  ff5378                   call qword ptr [rbx + 0x78]
004ca5cf  488bf0                   mov rsi, rax
004ca5d2  488bcf                   mov rcx, rdi
004ca5d5  ff5308                   call qword ptr [rbx + 8]
004ca5d8  0fb6d8                   movzx ebx, al
004ca5db  4c8b07                   mov r8, qword ptr [rdi]
004ca5de  488d55e0                 lea rdx, [rbp - 0x20]
004ca5e2  488bcf                   mov rcx, rdi
004ca5e5  41ff5030                 call qword ptr [r8 + 0x30]
004ca5e9  4889742458               mov qword ptr [rsp + 0x58], rsi
004ca5ee  895c2450                 mov dword ptr [rsp + 0x50], ebx
004ca5f2  488d4d22                 lea rcx, [rbp + 0x22]
004ca5f6  48894c2448               mov qword ptr [rsp + 0x48], rcx
004ca5fb  48c744244048000000       mov qword ptr [rsp + 0x40], 0x48
004ca604  4c89642438               mov qword ptr [rsp + 0x38], r12
004ca609  44896c2430               mov dword ptr [rsp + 0x30], r13d
004ca60e  498b0f                   mov rcx, qword ptr [r15]
004ca611  48894c2428               mov qword ptr [rsp + 0x28], rcx
004ca616  8b4008                   mov eax, dword ptr [rax + 8]
004ca619  89442420                 mov dword ptr [rsp + 0x20], eax
004ca61d  ba60000000               mov edx, 0x60
004ca622  41b910000000             mov r9d, 0x10
004ca628  458bc1                   mov r8d, r9d
004ca62b  488d4d90                 lea rcx, [rbp - 0x70]
004ca62f  e87c2effff               call 0x4bd4b0
004ca634  488b7dd0                 mov rdi, qword ptr [rbp - 0x30]
004ca638  4533e4                   xor r12d, r12d
004ca63b  eb6f                     jmp 0x4ca6ac
004ca63d  41b813000000             mov r8d, 0x13
004ca643  eb53                     jmp 0x4ca698
004ca645  0f108758010000           movups xmm0, xmmword ptr [rdi + 0x158]
004ca64c  0f10c8                   movups xmm1, xmm0
004ca64f  660fd6442428             movq qword ptr [rsp + 0x28], xmm0
004ca655  660f73d908               psrldq xmm1, 8
004ca65a  660f7e4c2420             movd dword ptr [rsp + 0x20], xmm1
004ca660  ba54000000               mov edx, 0x54
004ca665  448d4abc                 lea r9d, [rdx - 0x44]
004ca669  448d420a                 lea r8d, [rdx + 0xa]
004ca66d  488d4d90                 lea rcx, [rbp - 0x70]
004ca671  e83a2effff               call 0x4bd4b0
004ca676  eb34                     jmp 0x4ca6ac
004ca678  ba18010000               mov edx, 0x118
004ca67d  41b834000000             mov r8d, 0x34
004ca683  eb18                     jmp 0x4ca69d
004ca685  ba18010000               mov edx, 0x118
004ca68a  41b83a000000             mov r8d, 0x3a
004ca690  eb0b                     jmp 0x4ca69d
004ca692  41b81b000000             mov r8d, 0x1b
004ca698  ba61000000               mov edx, 0x61
004ca69d  41b910000000             mov r9d, 0x10
004ca6a3  488d4d90                 lea rcx, [rbp - 0x70]
004ca6a7  e8042effff               call 0x4bd4b0
004ca6ac  488b55a8                 mov rdx, qword ptr [rbp - 0x58]
004ca6b0  4c8965a8                 mov qword ptr [rbp - 0x58], r12
004ca6b4  448b45b8                 mov r8d, dword ptr [rbp - 0x48]
004ca6b8  488d4c2460               lea rcx, [rsp + 0x60]
004ca6bd  e81e2f0000               call 0x4cd5e0
004ca6c2  807c246803               cmp byte ptr [rsp + 0x68], 3
004ca6c7  7406                     je 0x4ca6cf
004ca6c9  66834c246a01             or word ptr [rsp + 0x6a], 1
004ca6cf  488d9fb8030000           lea rbx, [rdi + 0x3b8]
004ca6d6  4c8db7f8030000           lea r14, [rdi + 0x3f8]
004ca6dd  41803e00                 cmp byte ptr [r14], 0
004ca6e1  7430                     je 0x4ca713
004ca6e3  41c60600                 mov byte ptr [r14], 0
004ca6e7  41f6460a01               test byte ptr [r14 + 0xa], 1
004ca6ec  7411                     je 0x4ca6ff
004ca6ee  488b1583a7ca01           mov rdx, qword ptr [rip + 0x1caa783]
004ca6f5  498d4e08                 lea rcx, [r14 + 8]
004ca6f9  ff151915a001             call qword ptr [rip + 0x1a01519]
004ca6ff  41c7460803a50000         mov dword ptr [r14 + 8], 0xa503
004ca707  4d896610                 mov qword ptr [r14 + 0x10], r12
004ca70b  4d896618                 mov qword ptr [r14 + 0x18], r12
004ca70f  45896620                 mov dword ptr [r14 + 0x20], r12d
004ca713  488b8f20040000           mov rcx, qword ptr [rdi + 0x420]
004ca71a  4885c9                   test rcx, rcx
004ca71d  740d                     je 0x4ca72c
004ca71f  488b01                   mov rax, qword ptr [rcx]
004ca722  ff5070                   call qword ptr [rax + 0x70]
004ca725  4c89a720040000           mov qword ptr [rdi + 0x420], r12
004ca72c  498bce                   mov rcx, r14
004ca72f  e88c310000               call 0x4cd8c0
004ca734  488bcb                   mov rcx, rbx
004ca737  e8a468feff               call 0x4b0fe0
004ca73c  448965d8                 mov dword ptr [rbp - 0x28], r12d
004ca740  4c8965d0                 mov qword ptr [rbp - 0x30], r12
004ca744  0f1005ddbeb401           movups xmm0, xmmword ptr [rip + 0x1b4bedd]
004ca74b  0f1103                   movups xmmword ptr [rbx], xmm0
004ca74e  c7431002000000           mov dword ptr [rbx + 0x10], 2
004ca755  48c74318ffffffff         mov qword ptr [rbx + 0x18], 0xffffffffffffffff
004ca75d  44896320                 mov dword ptr [rbx + 0x20], r12d
004ca761  0f1045d0                 movups xmm0, xmmword ptr [rbp - 0x30]
004ca765  0f114328                 movups xmmword ptr [rbx + 0x28], xmm0
004ca769  488d542460               lea rdx, [rsp + 0x60]
004ca76e  488bcb                   mov rcx, rbx
004ca771  e87a6dffff               call 0x4c14f0
004ca776  837b3000                 cmp dword ptr [rbx + 0x30], 0
004ca77a  750d                     jne 0x4ca789
004ca77c  8b4310                   mov eax, dword ptr [rbx + 0x10]
004ca77f  a804                     test al, 4
004ca781  7406                     je 0x4ca789
004ca783  83c808                   or eax, 8
004ca786  894310                   mov dword ptr [rbx + 0x10], eax
004ca789  488d1df8e7e401           lea rbx, [rip + 0x1e4e7f8]
004ca790  c787f003000001000000     mov dword ptr [rdi + 0x3f0], 1
004ca79a  488bcf                   mov rcx, rdi
004ca79d  e86ef0ffff               call 0x4c9810
004ca7a2  90                       nop
004ca7a3  807c246000               cmp byte ptr [rsp + 0x60], 0
004ca7a8  744a                     je 0x4ca7f4
004ca7aa  c644246000               mov byte ptr [rsp + 0x60], 0
004ca7af  f644246a01               test byte ptr [rsp + 0x6a], 1
004ca7b4  7412                     je 0x4ca7c8
004ca7b6  488b15bba6ca01           mov rdx, qword ptr [rip + 0x1caa6bb]
004ca7bd  488d4c2468               lea rcx, [rsp + 0x68]
004ca7c2  ff155014a001             call qword ptr [rip + 0x1a01450]
004ca7c8  66448964246a             mov word ptr [rsp + 0x6a], r12w
004ca7ce  c744246803000000         mov dword ptr [rsp + 0x68], 3
004ca7d6  0f57c0                   xorps xmm0, xmm0
004ca7d9  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
004ca7df  44896580                 mov dword ptr [rbp - 0x80], r12d
004ca7e3  66c744246803a5           mov word ptr [rsp + 0x68], 0xa503
004ca7ea  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
004ca7f0  44896580                 mov dword ptr [rbp - 0x80], r12d
004ca7f4  48895d90                 mov qword ptr [rbp - 0x70], rbx
004ca7f8  488b4db0                 mov rcx, qword ptr [rbp - 0x50]
004ca7fc  4885c9                   test rcx, rcx
004ca7ff  7417                     je 0x4ca818
004ca801  488b01                   mov rax, qword ptr [rcx]
004ca804  ff90a0000000             call qword ptr [rax + 0xa0]
004ca80a  488b4db0                 mov rcx, qword ptr [rbp - 0x50]
004ca80e  488b01                   mov rax, qword ptr [rcx]
004ca811  ff5010                   call qword ptr [rax + 0x10]
004ca814  4c8965b0                 mov qword ptr [rbp - 0x50], r12
004ca818  488b4da8                 mov rcx, qword ptr [rbp - 0x58]
004ca81c  4885c9                   test rcx, rcx
004ca81f  740a                     je 0x4ca82b
004ca821  ff158107a001             call qword ptr [rip + 0x1a00781]
004ca827  4c8965a8                 mov qword ptr [rbp - 0x58], r12
004ca82b  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
004ca82f  4833cc                   xor rcx, rsp
004ca832  e83968b3ff               call 0x1070
004ca837  4c8d9c2480010000         lea r11, [rsp + 0x180]
004ca83f  498b5b38                 mov rbx, qword ptr [r11 + 0x38]
004ca843  498b7340                 mov rsi, qword ptr [r11 + 0x40]
004ca847  498b7b48                 mov rdi, qword ptr [r11 + 0x48]
004ca84b  498be3                   mov rsp, r11
004ca84e  415f                     pop r15
004ca850  415e                     pop r14
004ca852  415d                     pop r13
004ca854  415c                     pop r12
004ca856  5d                       pop rbp
004ca857  c3                       ret
004ca858  ae                       scasb al, byte ptr [rdi]
004ca859  a34c00a3a74c00a3a7       movabs dword ptr [0xa7a3004ca7a3004c], eax
004ca862  4c00a3a74c00bc           add byte ptr [rbx - 0x43ffb359], r12b
004ca869  a34c00bca34c000ca4       movabs dword ptr [0xa40c004ca3bc004c], eax
004ca872  4c001a                   add byte ptr [rdx], r11b
004ca875  a4                       movsb byte ptr [rdi], byte ptr [rsi]
004ca876  4c00cb                   add bl, r9b
004ca879  a4                       movsb byte ptr [rdi], byte ptr [rsi]
004ca87a  4c006ba5                 add byte ptr [rbx - 0x5b], r13b
004ca87e  4c00a3a74c00a3           add byte ptr [rbx - 0x5cffb359], r12b
004ca885  a7                       cmpsd dword ptr [rsi], dword ptr [rdi]
004ca886  4c0079a5                 add byte ptr [rcx - 0x5b], r15b
004ca88a  4c00a3a74c003d           add byte ptr [rbx + 0x3d004ca7], r12b
004ca891  a6                       cmpsb byte ptr [rsi], byte ptr [rdi]
004ca892  4c001b                   add byte ptr [rbx], r11b
004ca895  a5                       movsd dword ptr [rdi], dword ptr [rsi]
004ca896  4c0045a6                 add byte ptr [rbp - 0x5a], r8b
004ca89a  4c0078a6                 add byte ptr [rax - 0x5a], r15b
004ca89e  4c0085a64c0092           add byte ptr [rbp - 0x6dffb35a], r8b
004ca8a5  a6                       cmpsb byte ptr [rsi], byte ptr [rdi]
