; CCardFrameworkSQL12::DeriveCardinalityProperties
; sqllang.dll, primary RVA 0x257da0, 775 bytes in 1 chunk(s)

; chunk at RVA 0x257da0 (775 bytes)
00257da0  488bc4                   mov rax, rsp
00257da3  4c894820                 mov qword ptr [rax + 0x20], r9
00257da7  4c894018                 mov qword ptr [rax + 0x18], r8
00257dab  48895010                 mov qword ptr [rax + 0x10], rdx
00257daf  48894808                 mov qword ptr [rax + 8], rcx
00257db3  55                       push rbp
00257db4  53                       push rbx
00257db5  56                       push rsi
00257db6  57                       push rdi
00257db7  4154                     push r12
00257db9  4155                     push r13
00257dbb  4156                     push r14
00257dbd  4157                     push r15
00257dbf  488d68a1                 lea rbp, [rax - 0x5f]
00257dc3  4881ec98000000           sub rsp, 0x98
00257dca  48c745f7feffffff         mov qword ptr [rbp - 9], 0xfffffffffffffffe
00257dd2  0f2970a8                 movaps xmmword ptr [rax - 0x58], xmm6
00257dd6  4d8be9                   mov r13, r9
00257dd9  4d8bf8                   mov r15, r8
00257ddc  488b7910                 mov rdi, qword ptr [rcx + 0x10]
00257de0  48897dd7                 mov qword ptr [rbp - 0x29], rdi
00257de4  c745cf040a0000           mov dword ptr [rbp - 0x31], 0xa04
00257deb  c644242001               mov byte ptr [rsp + 0x20], 1
00257df0  41b9040a0000             mov r9d, 0xa04
00257df6  4c8d053bbdee01           lea r8, [rip + 0x1eebd3b]
00257dfd  488b5770                 mov rdx, qword ptr [rdi + 0x70]
00257e01  b928000000               mov ecx, 0x28
00257e06  ff15a430c701             call qword ptr [rip + 0x1c730a4]
00257e0c  488bd8                   mov rbx, rax
00257e0f  488945e7                 mov qword ptr [rbp - 0x19], rax
00257e13  33f6                     xor esi, esi
00257e15  4885c0                   test rax, rax
00257e18  0f84278b6901             je 0x18f0945
00257e1e  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
00257e22  488908                   mov qword ptr [rax], rcx
00257e25  89700c                   mov dword ptr [rax + 0xc], esi
00257e28  48897010                 mov qword ptr [rax + 0x10], rsi
00257e2c  48897018                 mov qword ptr [rax + 0x18], rsi
00257e30  897020                   mov dword ptr [rax + 0x20], esi
00257e33  4533c0                   xor r8d, r8d
00257e36  8d5628                   lea edx, [rsi + 0x28]
00257e39  488bc8                   mov rcx, rax
00257e3c  e8df99e0ff               call 0x61820
00257e41  90                       nop
00257e42  eb01                     jmp 0x257e45
00257e44  cc                       int3
00257e45  48895dc7                 mov qword ptr [rbp - 0x39], rbx
00257e49  488d4f50                 lea rcx, [rdi + 0x50]
00257e4d  488d55c7                 lea rdx, [rbp - 0x39]
00257e51  e84acadbff               call 0x148a0
00257e56  498b4708                 mov rax, qword ptr [r15 + 8]
00257e5a  4885c0                   test rax, rax
00257e5d  0f84d0130000             je 0x259233
00257e63  488b4810                 mov rcx, qword ptr [rax + 0x10]
00257e67  eb01                     jmp 0x257e6a
00257e69  cc                       int3
00257e6a  4c8b6110                 mov r12, qword ptr [rcx + 0x10]
00257e6e  4c8965d7                 mov qword ptr [rbp - 0x29], r12
00257e72  4c8965ff                 mov qword ptr [rbp - 1], r12
00257e76  4c8bf6                   mov r14, rsi
00257e79  488975bf                 mov qword ptr [rbp - 0x41], rsi
00257e7d  f2410f104520             movsd xmm0, qword ptr [r13 + 0x20]
00257e83  0f57f6                   xorps xmm6, xmm6
00257e86  660f2ec6                 ucomisd xmm0, xmm6
00257e8a  7a06                     jp 0x257e92
00257e8c  0f84bc8a6901             je 0x18f094e
00257e92  488bfe                   mov rdi, rsi
00257e95  488975df                 mov qword ptr [rbp - 0x21], rsi
00257e99  4c8bee                   mov r13, rsi
00257e9c  498bcf                   mov rcx, r15
00257e9f  e8ec9fe1ff               call 0x71e90
00257ea4  488945b7                 mov qword ptr [rbp - 0x49], rax
00257ea8  488b88d0020000           mov rcx, qword ptr [rax + 0x2d0]
00257eaf  f6410601                 test byte ptr [rcx + 6], 1
00257eb3  754a                     jne 0x257eff
00257eb5  498b5f08                 mov rbx, qword ptr [r15 + 8]
00257eb9  4885db                   test rbx, rbx
00257ebc  0f847f130000             je 0x259241
00257ec2  488b5b10                 mov rbx, qword ptr [rbx + 0x10]
00257ec6  eb01                     jmp 0x257ec9
00257ec8  cc                       int3
00257ec9  488b03                   mov rax, qword ptr [rbx]
00257ecc  488bcb                   mov rcx, rbx
00257ecf  ff5018                   call qword ptr [rax + 0x18]
00257ed2  83c0f2                   add eax, -0xe
00257ed5  83f822                   cmp eax, 0x22
00257ed8  771e                     ja 0x257ef8
00257eda  4898                     cdqe
00257edc  488d151d81daff           lea rdx, [rip - 0x257ee3]
00257ee3  0fb6840284802500         movzx eax, byte ptr [rdx + rax + 0x258084]
00257eeb  8b8c8270802500           mov ecx, dword ptr [rdx + rax*4 + 0x258070]
00257ef2  4803ca                   add rcx, rdx
00257ef5  ffe1                     jmp rcx
00257ef7  cc                       int3
00257ef8  4c8bee                   mov r13, rsi
00257efb  488b45b7                 mov rax, qword ptr [rbp - 0x49]
00257eff  488bde                   mov rbx, rsi
00257f02  48895de7                 mov qword ptr [rbp - 0x19], rbx
00257f06  f6057feb880208           test byte ptr [rip + 0x288eb7f], 8
00257f0d  0f85fe8a6901             jne 0x18f0a11
00257f13  488b4818                 mov rcx, qword ptr [rax + 0x18]
00257f17  488b01                   mov rax, qword ptr [rcx]
00257f1a  ff9080010000             call qword ptr [rax + 0x180]
00257f20  4885c0                   test rax, rax
00257f23  0f85b88a6901             jne 0x18f09e1
00257f29  f6055ceb880208           test byte ptr [rip + 0x288eb5c], 8
00257f30  0f854a8b6901             jne 0x18f0a80
00257f36  488b4d6f                 mov rcx, qword ptr [rbp + 0x6f]
00257f3a  488b01                   mov rax, qword ptr [rcx]
00257f3d  4c8bcb                   mov r9, rbx
00257f40  4c8b757f                 mov r14, qword ptr [rbp + 0x7f]
00257f44  4d8bc6                   mov r8, r14
00257f47  498bd7                   mov rdx, r15
00257f4a  ff90d8040000             call qword ptr [rax + 0x4d8]
00257f50  4c8bf8                   mov r15, rax
00257f53  488945bf                 mov qword ptr [rbp - 0x41], rax
00257f57  4c8b00                   mov r8, qword ptr [rax]
00257f5a  488d55c7                 lea rdx, [rbp - 0x39]
00257f5e  488bc8                   mov rcx, rax
00257f61  41ff5008                 call qword ptr [r8 + 8]
00257f65  f2410f104620             movsd xmm0, qword ptr [r14 + 0x20]
00257f6b  f20f104dc7               movsd xmm1, qword ptr [rbp - 0x39]
00257f70  660f2fc8                 comisd xmm1, xmm0
00257f74  7703                     ja 0x257f79
00257f76  0f28c1                   movaps xmm0, xmm1
00257f79  f20f1145cf               movsd qword ptr [rbp - 0x31], xmm0
00257f7e  488b45b7                 mov rax, qword ptr [rbp - 0x49]
00257f82  488b80d0020000           mov rax, qword ptr [rax + 0x2d0]
00257f89  f6400601                 test byte ptr [rax + 6], 1
00257f8d  0f85038b6901             jne 0x18f0a96
00257f93  f2410f104e18             movsd xmm1, qword ptr [r14 + 0x18]
00257f99  660f2fc8                 comisd xmm1, xmm0
00257f9d  7703                     ja 0x257fa2
00257f9f  0f28c8                   movaps xmm1, xmm0
00257fa2  f20f114db7               movsd qword ptr [rbp - 0x49], xmm1
00257fa7  4c8d45b7                 lea r8, [rbp - 0x49]
00257fab  498bd7                   mov rdx, r15
00257fae  498bcc                   mov rcx, r12
00257fb1  e88afdffff               call 0x257d40
00257fb6  4c8bf0                   mov r14, rax
00257fb9  41834708ff               add dword ptr [r15 + 8], -1
00257fbe  0f84f88a6901             je 0x18f0abc
00257fc4  4c8975bf                 mov qword ptr [rbp - 0x41], r14
00257fc8  4885db                   test rbx, rbx
00257fcb  0f85ff8a6901             jne 0x18f0ad0
00257fd1  4d85ed                   test r13, r13
00257fd4  0f85220c0000             jne 0x258bfc
00257fda  4885db                   test rbx, rbx
00257fdd  0f85338c6901             jne 0x18f0c16
00257fe3  4885ff                   test rdi, rdi
00257fe6  0f8532640000             jne 0x25e41e
00257fec  4c8b6d7f                 mov r13, qword ptr [rbp + 0x7f]
00257ff0  488975bf                 mov qword ptr [rbp - 0x41], rsi
00257ff4  498b8d08010000           mov rcx, qword ptr [r13 + 0x108]
00257ffb  4885c9                   test rcx, rcx
00257ffe  0f85268c6901             jne 0x18f0c2a
00258004  4d89b508010000           mov qword ptr [r13 + 0x108], r14
0025800b  488b4567                 mov rax, qword ptr [rbp + 0x67]
0025800f  488b5010                 mov rdx, qword ptr [rax + 0x10]
00258013  8b425c                   mov eax, dword ptr [rdx + 0x5c]
00258016  85c0                     test eax, eax
00258018  0f84278c6901             je 0x18f0c45
0025801e  ffc8                     dec eax
00258020  89425c                   mov dword ptr [rdx + 0x5c], eax
00258023  8bc8                     mov ecx, eax
00258025  488b4268                 mov rax, qword ptr [rdx + 0x68]
00258029  488b1cc8                 mov rbx, qword ptr [rax + rcx*8]
0025802d  48895d67                 mov qword ptr [rbp + 0x67], rbx
00258031  4885db                   test rbx, rbx
00258034  7417                     je 0x25804d
00258036  488bcb                   mov rcx, rbx
00258039  e862fcffff               call 0x257ca0
0025803e  ba28000000               mov edx, 0x28
00258043  488bcb                   mov rcx, rbx
00258046  ff153c2fc701             call qword ptr [rip + 0x1c72f3c]
0025804c  90                       nop
0025804d  0f28b42480000000         movaps xmm6, xmmword ptr [rsp + 0x80]
00258055  4881c498000000           add rsp, 0x98
0025805c  415f                     pop r15
0025805e  415e                     pop r14
00258060  415d                     pop r13
00258062  415c                     pop r12
00258064  5f                       pop rdi
00258065  5e                       pop rsi
00258066  5b                       pop rbx
00258067  5d                       pop rbp
00258068  c3                       ret
00258069  90                       nop
0025806a  90                       nop
0025806b  90                       nop
0025806c  90                       nop
0025806d  90                       nop
0025806e  90                       nop
0025806f  90                       nop
00258070  59                       pop rcx
00258071  412600741428             add byte ptr es:[rsp + rdx + 0x28], dh
00258077  00ce                     add dh, cl
00258079  8a2500324126             mov ah, byte ptr [rip + 0x26413200]
0025807f  00f8                     add al, bh
00258081  7e25                     jle 0x2580a8
00258083  0000                     add byte ptr [rax], al
00258085  0400                     add al, 0
00258087  0000                     add byte ptr [rax], al
00258089  0000                     add byte ptr [rax], al
0025808b  0000                     add byte ptr [rax], al
0025808d  0404                     add al, 4
0025808f  0404                     add al, 4
00258091  0404                     add al, 4
00258093  0404                     add al, 4
00258095  0102                     add dword ptr [rdx], eax
00258097  0404                     add al, 4
00258099  0404                     add al, 4
0025809b  0404                     add al, 4
0025809d  0404                     add al, 4
0025809f  0404                     add al, 4
002580a1  0404                     add al, 4
002580a3  030403                   add eax, dword ptr [rbx + rax]
