; CDecompressBatchLoader<Level1Batch,CLevel1Decompressor,CSimpleRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x971c50, 1472 bytes in 1 chunk(s)

; chunk at RVA 0x971c50 (1472 bytes)
00971c50  488bc4                   mov rax, rsp
00971c53  4c894820                 mov qword ptr [rax + 0x20], r9
00971c57  895010                   mov dword ptr [rax + 0x10], edx
00971c5a  55                       push rbp
00971c5b  56                       push rsi
00971c5c  57                       push rdi
00971c5d  4154                     push r12
00971c5f  4155                     push r13
00971c61  4156                     push r14
00971c63  4157                     push r15
00971c65  4881eca0000000           sub rsp, 0xa0
00971c6c  48c740b0feffffff         mov qword ptr [rax - 0x50], 0xfffffffffffffffe
00971c74  48895818                 mov qword ptr [rax + 0x18], rbx
00971c78  4d8be0                   mov r12, r8
00971c7b  448bd2                   mov r10d, edx
00971c7e  488bd9                   mov rbx, rcx
00971c81  83792002                 cmp dword ptr [rcx + 0x20], 2
00971c85  7507                     jne 0x971c8e
00971c87  33c0                     xor eax, eax
00971c89  e905050000               jmp 0x972193
00971c8e  33f6                     xor esi, esi
00971c90  89742450                 mov dword ptr [rsp + 0x50], esi
00971c94  4889742458               mov qword ptr [rsp + 0x58], rsi
00971c99  4088742460               mov byte ptr [rsp + 0x60], sil
00971c9e  0f57c0                   xorps xmm0, xmm0
00971ca1  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
00971ca7  4889b42480000000         mov qword ptr [rsp + 0x80], rsi
00971caf  448bee                   mov r13d, esi
00971cb2  32c0                     xor al, al
00971cb4  888424e0000000           mov byte ptr [rsp + 0xe0], al
00971cbb  4c8d1d3ee368ff           lea r11, [rip - 0x971cc2]
00971cc2  41c644241000             mov byte ptr [r12 + 0x10], 0
00971cc8  80bb1803000000           cmp byte ptr [rbx + 0x318], 0
00971ccf  0f84c8000000             je 0x971d9d
00971cd5  c6831803000000           mov byte ptr [rbx + 0x318], 0
00971cdc  4c8b8b10030000           mov r9, qword ptr [rbx + 0x310]
00971ce3  41ff0424                 inc dword ptr [r12]
00971ce7  418b1424                 mov edx, dword ptr [r12]
00971ceb  4d8b4120                 mov r8, qword ptr [r9 + 0x20]
00971cef  ffca                     dec edx
00971cf1  498b4c2420               mov rcx, qword ptr [r12 + 0x20]
00971cf6  498b00                   mov rax, qword ptr [r8]
00971cf9  488904d1                 mov qword ptr [rcx + rdx*8], rax
00971cfd  4d8b4130                 mov r8, qword ptr [r9 + 0x30]
00971d01  418b1424                 mov edx, dword ptr [r12]
00971d05  ffca                     dec edx
00971d07  498b4c2430               mov rcx, qword ptr [r12 + 0x30]
00971d0c  418b00                   mov eax, dword ptr [r8]
00971d0f  890491                   mov dword ptr [rcx + rdx*4], eax
00971d12  4d8b4128                 mov r8, qword ptr [r9 + 0x28]
00971d16  418b1424                 mov edx, dword ptr [r12]
00971d1a  ffca                     dec edx
00971d1c  498b4c2428               mov rcx, qword ptr [r12 + 0x28]
00971d21  418b00                   mov eax, dword ptr [r8]
00971d24  890491                   mov dword ptr [rcx + rdx*4], eax
00971d27  488b8310030000           mov rax, qword ptr [rbx + 0x310]
00971d2e  ff08                     dec dword ptr [rax]
00971d30  89742450                 mov dword ptr [rsp + 0x50], esi
00971d34  498b442408               mov rax, qword ptr [r12 + 8]
00971d39  4889442458               mov qword ptr [rsp + 0x58], rax
00971d3e  418b1424                 mov edx, dword ptr [r12]
00971d42  498b442420               mov rax, qword ptr [r12 + 0x20]
00971d47  488d0cd0                 lea rcx, [rax + rdx*8]
00971d4b  48894c2470               mov qword ptr [rsp + 0x70], rcx
00971d50  498b442428               mov rax, qword ptr [r12 + 0x28]
00971d55  488d0c90                 lea rcx, [rax + rdx*4]
00971d59  48894c2478               mov qword ptr [rsp + 0x78], rcx
00971d5e  498b442430               mov rax, qword ptr [r12 + 0x30]
00971d63  488d0c90                 lea rcx, [rax + rdx*4]
00971d67  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
00971d6f  b801000000               mov eax, 1
00971d74  2bc2                     sub eax, edx
00971d76  4403d0                   add r10d, eax
00971d79  44899424e8000000         mov dword ptr [rsp + 0xe8], r10d
00971d81  488d7c2450               lea rdi, [rsp + 0x50]
00971d86  c6831803000000           mov byte ptr [rbx + 0x318], 0
00971d8d  41bd01000000             mov r13d, 1
00971d93  4c8b8c24f8000000         mov r9, qword ptr [rsp + 0xf8]
00971d9b  eb03                     jmp 0x971da0
00971d9d  498bfc                   mov rdi, r12
00971da0  837b2000                 cmp dword ptr [rbx + 0x20], 0
00971da4  0f8582000000             jne 0x971e2c
00971daa  4889742420               mov qword ptr [rsp + 0x20], rsi
00971daf  89742428                 mov dword ptr [rsp + 0x28], esi
00971db3  4889742430               mov qword ptr [rsp + 0x30], rsi
00971db8  89742438                 mov dword ptr [rsp + 0x38], esi
00971dbc  4889742440               mov qword ptr [rsp + 0x40], rsi
00971dc1  89742448                 mov dword ptr [rsp + 0x48], esi
00971dc5  668974244c               mov word ptr [rsp + 0x4c], si
00971dca  488d4b28                 lea rcx, [rbx + 0x28]
00971dce  488b01                   mov rax, qword ptr [rcx]
00971dd1  4d8bc1                   mov r8, r9
00971dd4  488d542420               lea rdx, [rsp + 0x20]
00971dd9  ff10                     call qword ptr [rax]
00971ddb  c68424e000000001         mov byte ptr [rsp + 0xe0], 1
00971de3  3dc60e0400               cmp eax, 0x40ec6
00971de8  0f847e030000             je 0x97216c
00971dee  488b4c2420               mov rcx, qword ptr [rsp + 0x20]
00971df3  48894b50                 mov qword ptr [rbx + 0x50], rcx
00971df7  8b442428                 mov eax, dword ptr [rsp + 0x28]
00971dfb  894348                   mov dword ptr [rbx + 0x48], eax
00971dfe  48894b58                 mov qword ptr [rbx + 0x58], rcx
00971e02  48897340                 mov qword ptr [rbx + 0x40], rsi
00971e06  66c783080300000000       mov word ptr [rbx + 0x308], 0
00971e0f  4889b300030000           mov qword ptr [rbx + 0x300], rsi
00971e16  c7432001000000           mov dword ptr [rbx + 0x20], 1
00971e1d  448b9424e8000000         mov r10d, dword ptr [rsp + 0xe8]
00971e25  4c8d1dd4e168ff           lea r11, [rip - 0x971e2c]
00971e2c  488b4330                 mov rax, qword ptr [rbx + 0x30]
00971e30  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00971e37  4c894708                 mov qword ptr [rdi + 8], r8
00971e3b  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00971e42  488b5330                 mov rdx, qword ptr [rbx + 0x30]
00971e46  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00971e49  83e007                   and eax, 7
00971e4c  83f805                   cmp eax, 5
00971e4f  7741                     ja 0x971e92
00971e51  4898                     cdqe
00971e53  418b8c83b0219700         mov ecx, dword ptr [r11 + rax*4 + 0x9721b0]
00971e5b  4903cb                   add rcx, r11
00971e5e  ffe1                     jmp rcx
00971e60  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00971e64  400f95c5                 setne bpl
00971e68  eb2b                     jmp 0x971e95
00971e6a  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00971e6e  400f9dc5                 setge bpl
00971e72  eb21                     jmp 0x971e95
00971e74  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00971e78  400f9ec5                 setle bpl
00971e7c  eb17                     jmp 0x971e95
00971e7e  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00971e82  400f9fc5                 setg bpl
00971e86  eb0d                     jmp 0x971e95
00971e88  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00971e8c  400f9cc5                 setl bpl
00971e90  eb03                     jmp 0x971e95
00971e92  4032ed                   xor bpl, bpl
00971e95  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00971e9c  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00971e9f  83e007                   and eax, 7
00971ea2  83f805                   cmp eax, 5
00971ea5  7741                     ja 0x971ee8
00971ea7  4898                     cdqe
00971ea9  418b8c83c8219700         mov ecx, dword ptr [r11 + rax*4 + 0x9721c8]
00971eb1  4903cb                   add rcx, r11
00971eb4  ffe1                     jmp rcx
00971eb6  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00971eba  410f95c7                 setne r15b
00971ebe  eb2b                     jmp 0x971eeb
00971ec0  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00971ec4  410f9dc7                 setge r15b
00971ec8  eb21                     jmp 0x971eeb
00971eca  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00971ece  410f9ec7                 setle r15b
00971ed2  eb17                     jmp 0x971eeb
00971ed4  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00971ed8  410f9fc7                 setg r15b
00971edc  eb0d                     jmp 0x971eeb
00971ede  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00971ee2  410f9cc7                 setl r15b
00971ee6  eb03                     jmp 0x971eeb
00971ee8  4532ff                   xor r15b, r15b
00971eeb  48899c2490000000         mov qword ptr [rsp + 0x90], rbx
00971ef3  0f31                     rdtsc
00971ef5  48c1e220                 shl rdx, 0x20
00971ef9  480bc2                   or rax, rdx
00971efc  48894308                 mov qword ptr [rbx + 8], rax
00971f00  488d4b38                 lea rcx, [rbx + 0x38]
00971f04  4c8bc7                   mov r8, rdi
00971f07  418bd2                   mov edx, r10d
00971f0a  e861bdffff               call 0x96dc70
00971f0f  84c0                     test al, al
00971f11  7503                     jne 0x971f16
00971f13  897320                   mov dword ptr [rbx + 0x20], esi
00971f16  8b07                     mov eax, dword ptr [rdi]
00971f18  48014310                 add qword ptr [rbx + 0x10], rax
00971f1c  0f31                     rdtsc
00971f1e  48c1e220                 shl rdx, 0x20
00971f22  480bc2                   or rax, rdx
00971f25  482b4308                 sub rax, qword ptr [rbx + 8]
00971f29  480103                   add qword ptr [rbx], rax
00971f2c  ff4318                   inc dword ptr [rbx + 0x18]
00971f2f  8b07                     mov eax, dword ptr [rdi]
00971f31  448bc8                   mov r9d, eax
00971f34  85c0                     test eax, eax
00971f36  0f8493010000             je 0x9720cf
00971f3c  4084ed                   test bpl, bpl
00971f3f  7509                     jne 0x971f4a
00971f41  4584ff                   test r15b, r15b
00971f44  0f8485010000             je 0x9720cf
00971f4a  448bc0                   mov r8d, eax
00971f4d  4084ed                   test bpl, bpl
00971f50  747c                     je 0x971fce
00971f52  448bce                   mov r9d, esi
00971f55  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00971f59  85c0                     test eax, eax
00971f5b  746a                     je 0x971fc7
00971f5d  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
00971f61  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00971f65  4183e007                 and r8d, 7
00971f69  488d2d90e068ff           lea rbp, [rip - 0x971f70]
00971f70  418bc9                   mov ecx, r9d
00971f73  4d8b14ce                 mov r10, qword ptr [r14 + rcx*8]
00971f77  4183f805                 cmp r8d, 5
00971f7b  0f87ae000000             ja 0x97202f
00971f81  4963c8                   movsxd rcx, r8d
00971f84  8b948de0219700           mov edx, dword ptr [rbp + rcx*4 + 0x9721e0]
00971f8b  4803d5                   add rdx, rbp
00971f8e  ffe2                     jmp rdx
00971f90  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00971f94  0f94c1                   sete cl
00971f97  eb22                     jmp 0x971fbb
00971f99  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00971f9d  0f9cc1                   setl cl
00971fa0  eb19                     jmp 0x971fbb
00971fa2  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00971fa6  0f9fc1                   setg cl
00971fa9  eb10                     jmp 0x971fbb
00971fab  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00971faf  0f9ec1                   setle cl
00971fb2  eb07                     jmp 0x971fbb
00971fb4  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
00971fb8  0f9dc1                   setge cl
00971fbb  84c9                     test cl, cl
00971fbd  7570                     jne 0x97202f
00971fbf  41ffc1                   inc r9d
00971fc2  443bc8                   cmp r9d, eax
00971fc5  72a9                     jb 0x971f70
00971fc7  8937                     mov dword ptr [rdi], esi
00971fc9  8bc6                     mov eax, esi
00971fcb  448bc6                   mov r8d, esi
00971fce  458bc8                   mov r9d, r8d
00971fd1  4584ff                   test r15b, r15b
00971fd4  0f84f5000000             je 0x9720cf
00971fda  85c0                     test eax, eax
00971fdc  0f84ed000000             je 0x9720cf
00971fe2  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00971fe6  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
00971fea  4c8d3d0fe068ff           lea r15, [rip - 0x971ff1]
00971ff1  0f1f4000                 nop dword ptr [rax]
00971ff5  6666660f1f840000000000   nop word ptr [rax + rax]
00972000  458bd0                   mov r10d, r8d
00972003  ffc8                     dec eax
00972005  448bc0                   mov r8d, eax
00972008  498b2cc6                 mov rbp, qword ptr [r14 + rax*8]
0097200c  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00972010  83e107                   and ecx, 7
00972013  458bca                   mov r9d, r10d
00972016  83f905                   cmp ecx, 5
00972019  0f87b0000000             ja 0x9720cf
0097201f  4863c9                   movsxd rcx, ecx
00972022  418b948ff8219700         mov edx, dword ptr [r15 + rcx*4 + 0x9721f8]
0097202a  4903d7                   add rdx, r15
0097202d  ffe2                     jmp rdx
0097202f  443bc8                   cmp r9d, eax
00972032  7393                     jae 0x971fc7
00972034  448bc0                   mov r8d, eax
00972037  4585c9                   test r9d, r9d
0097203a  7492                     je 0x971fce
0097203c  452bc1                   sub r8d, r9d
0097203f  448bde                   mov r11d, esi
00972042  7444                     je 0x972088
00972044  4c8bd6                   mov r10, rsi
00972047  4c8bf6                   mov r14, rsi
0097204a  660f1f440000             nop word ptr [rax + rax]
00972050  438d040b                 lea eax, [r11 + r9]
00972054  8bd0                     mov edx, eax
00972056  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0097205a  488b04c1                 mov rax, qword ptr [rcx + rax*8]
0097205e  4989040e                 mov qword ptr [r14 + rcx], rax
00972062  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00972066  8b0491                   mov eax, dword ptr [rcx + rdx*4]
00972069  4189040a                 mov dword ptr [r10 + rcx], eax
0097206d  488b4f28                 mov rcx, qword ptr [rdi + 0x28]
00972071  8b0491                   mov eax, dword ptr [rcx + rdx*4]
00972074  4189040a                 mov dword ptr [r10 + rcx], eax
00972078  41ffc3                   inc r11d
0097207b  4d8d7608                 lea r14, [r14 + 8]
0097207f  4d8d5204                 lea r10, [r10 + 4]
00972083  453bd8                   cmp r11d, r8d
00972086  72c8                     jb 0x972050
00972088  448907                   mov dword ptr [rdi], r8d
0097208b  418bc0                   mov eax, r8d
0097208e  e93bffffff               jmp 0x971fce
00972093  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
00972097  0f94c1                   sete cl
0097209a  eb22                     jmp 0x9720be
0097209c  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
009720a0  0f9cc1                   setl cl
009720a3  eb19                     jmp 0x9720be
009720a5  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
009720a9  0f9fc1                   setg cl
009720ac  eb10                     jmp 0x9720be
009720ae  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
009720b2  0f9ec1                   setle cl
009720b5  eb07                     jmp 0x9720be
009720b7  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
009720bb  0f9dc1                   setge cl
009720be  84c9                     test cl, cl
009720c0  750d                     jne 0x9720cf
009720c2  8907                     mov dword ptr [rdi], eax
009720c4  448bc8                   mov r9d, eax
009720c7  85c0                     test eax, eax
009720c9  0f8531ffffff             jne 0x972000
009720cf  80bb1903000000           cmp byte ptr [rbx + 0x319], 0
009720d6  747a                     je 0x972152
009720d8  448b0f                   mov r9d, dword ptr [rdi]
009720db  4585c9                   test r9d, r9d
009720de  7472                     je 0x972152
009720e0  c6831803000001           mov byte ptr [rbx + 0x318], 1
009720e7  448b0f                   mov r9d, dword ptr [rdi]
009720ea  41ffc9                   dec r9d
009720ed  4c8b9310030000           mov r10, qword ptr [rbx + 0x310]
009720f4  41ff02                   inc dword ptr [r10]
009720f7  418b12                   mov edx, dword ptr [r10]
009720fa  4c8b4720                 mov r8, qword ptr [rdi + 0x20]
009720fe  ffca                     dec edx
00972100  498b4a20                 mov rcx, qword ptr [r10 + 0x20]
00972104  4b8b04c8                 mov rax, qword ptr [r8 + r9*8]
00972108  488904d1                 mov qword ptr [rcx + rdx*8], rax
0097210c  4c8b4730                 mov r8, qword ptr [rdi + 0x30]
00972110  418b12                   mov edx, dword ptr [r10]
00972113  ffca                     dec edx
00972115  498b4a30                 mov rcx, qword ptr [r10 + 0x30]
00972119  438b0488                 mov eax, dword ptr [r8 + r9*4]
0097211d  890491                   mov dword ptr [rcx + rdx*4], eax
00972120  4c8b4728                 mov r8, qword ptr [rdi + 0x28]
00972124  418b12                   mov edx, dword ptr [r10]
00972127  ffca                     dec edx
00972129  498b4a28                 mov rcx, qword ptr [r10 + 0x28]
0097212d  438b0488                 mov eax, dword ptr [r8 + r9*4]
00972131  890491                   mov dword ptr [rcx + rdx*4], eax
00972134  ff0f                     dec dword ptr [rdi]
00972136  41c644241001             mov byte ptr [r12 + 0x10], 1
0097213c  488b8310030000           mov rax, qword ptr [rbx + 0x310]
00972143  488b4820                 mov rcx, qword ptr [rax + 0x20]
00972147  488b01                   mov rax, qword ptr [rcx]
0097214a  4989442418               mov qword ptr [r12 + 0x18], rax
0097214f  448b0f                   mov r9d, dword ptr [rdi]
00972152  4503e9                   add r13d, r9d
00972155  7529                     jne 0x972180
00972157  448b9424e8000000         mov r10d, dword ptr [rsp + 0xe8]
0097215f  4c8b8c24f8000000         mov r9, qword ptr [rsp + 0xf8]
00972167  e94ffbffff               jmp 0x971cbb
0097216c  c7432002000000           mov dword ptr [rbx + 0x20], 2
00972173  41833c2400               cmp dword ptr [r12], 0
00972178  400f95c6                 setne sil
0097217c  8bc6                     mov eax, esi
0097217e  eb13                     jmp 0x972193
00972180  45892c24                 mov dword ptr [r12], r13d
00972184  0fb68424e0000000         movzx eax, byte ptr [rsp + 0xe0]
0097218c  f6d8                     neg al
0097218e  1bc0                     sbb eax, eax
00972190  83c002                   add eax, 2
00972193  488b9c24f0000000         mov rbx, qword ptr [rsp + 0xf0]
0097219b  4881c4a0000000           add rsp, 0xa0
009721a2  415f                     pop r15
009721a4  415e                     pop r14
009721a6  415d                     pop r13
009721a8  415c                     pop r12
009721aa  5f                       pop rdi
009721ab  5e                       pop rsi
009721ac  5d                       pop rbp
009721ad  c3                       ret
009721ae  6690                     nop
009721b0  92                       xchg edx, eax
