; CConstraintProp::AndDRgPExprScalar
; sqllang.dll, primary RVA 0x24ff40, 291 bytes in 1 chunk(s)

; chunk at RVA 0x24ff40 (291 bytes)
0024ff40  4c894c2420               mov qword ptr [rsp + 0x20], r9
0024ff45  4889542410               mov qword ptr [rsp + 0x10], rdx
0024ff4a  48894c2408               mov qword ptr [rsp + 8], rcx
0024ff4f  53                       push rbx
0024ff50  55                       push rbp
0024ff51  56                       push rsi
0024ff52  57                       push rdi
0024ff53  4154                     push r12
0024ff55  4155                     push r13
0024ff57  4156                     push r14
0024ff59  4157                     push r15
0024ff5b  4883ec48                 sub rsp, 0x48
0024ff5f  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
0024ff68  498be8                   mov rbp, r8
0024ff6b  4c8bd1                   mov r10, rcx
0024ff6e  41b701                   mov r15b, 1
0024ff71  450fb6e7                 movzx r12d, r15b
0024ff75  4d85c9                   test r9, r9
0024ff78  7404                     je 0x24ff7e
0024ff7a  41c60100                 mov byte ptr [r9], 0
0024ff7e  418b481c                 mov ecx, dword ptr [r8 + 0x1c]
0024ff82  b808000000               mov eax, 8
0024ff87  48f7e1                   mul rcx
0024ff8a  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
0024ff91  480f40c1                 cmovo rax, rcx
0024ff95  4488642420               mov byte ptr [rsp + 0x20], r12b
0024ff9a  41b9082b0000             mov r9d, 0x2b08
0024ffa0  4c8d0549d0ec01           lea r8, [rip + 0x1ecd049]
0024ffa7  498b5210                 mov rdx, qword ptr [r10 + 0x10]
0024ffab  488bc8                   mov rcx, rax
0024ffae  ff1544afc701             call qword ptr [rip + 0x1c7af44]
0024ffb4  4c8be8                   mov r13, rax
0024ffb7  448b451c                 mov r8d, dword ptr [rbp + 0x1c]
0024ffbb  49c1e003                 shl r8, 3
0024ffbf  33d2                     xor edx, edx
0024ffc1  488bc8                   mov rcx, rax
0024ffc4  e82d30dbff               call 0x2ff6
0024ffc9  33ff                     xor edi, edi
0024ffcb  448bf7                   mov r14d, edi
0024ffce  8bdf                     mov ebx, edi
0024ffd0  8b4d1c                   mov ecx, dword ptr [rbp + 0x1c]
0024ffd3  85c9                     test ecx, ecx
0024ffd5  0f8438feffff             je 0x24fe13
0024ffdb  8bf3                     mov esi, ebx
0024ffdd  3bd9                     cmp ebx, ecx
0024ffdf  0f8383933701             jae 0x15c9368
0024ffe5  488b4528                 mov rax, qword ptr [rbp + 0x28]
0024ffe9  488b0cf0                 mov rcx, qword ptr [rax + rsi*8]
0024ffed  eb01                     jmp 0x24fff0
0024ffef  cc                       int3
0024fff0  488b4910                 mov rcx, qword ptr [rcx + 0x10]
0024fff4  488b01                   mov rax, qword ptr [rcx]
0024fff7  ff5018                   call qword ptr [rax + 0x18]
0024fffa  83f862                   cmp eax, 0x62
0024fffd  7434                     je 0x250033
0024ffff  4532ff                   xor r15b, r15b
00250002  ffc3                     inc ebx
00250004  8b4d1c                   mov ecx, dword ptr [rbp + 0x1c]
00250007  3bd9                     cmp ebx, ecx
00250009  72d0                     jb 0x24ffdb
0025000b  4584ff                   test r15b, r15b
0025000e  0f85fffdffff             jne 0x24fe13
00250014  4d85ed                   test r13, r13
00250017  7409                     je 0x250022
00250019  498bcd                   mov rcx, r13
0025001c  ff1586afc701             call qword ptr [rip + 0x1c7af86]
00250022  4883c448                 add rsp, 0x48
00250026  415f                     pop r15
00250028  415e                     pop r14
0025002a  415d                     pop r13
0025002c  415c                     pop r12
0025002e  5f                       pop rdi
0025002f  5e                       pop rsi
00250030  5d                       pop rbp
00250031  5b                       pop rbx
00250032  c3                       ret
00250033  3b5d1c                   cmp ebx, dword ptr [rbp + 0x1c]
00250036  0f8335933701             jae 0x15c9371
0025003c  488b4528                 mov rax, qword ptr [rbp + 0x28]
00250040  488b0cf0                 mov rcx, qword ptr [rax + rsi*8]
00250044  eb01                     jmp 0x250047
00250046  cc                       int3
00250047  488b5110                 mov rdx, qword ptr [rcx + 0x10]
0025004b  807a4003                 cmp byte ptr [rdx + 0x40], 3
0025004f  0f84f7ec0a00             je 0x2fed4c
00250055  418bc6                   mov eax, r14d
00250058  498954c500               mov qword ptr [r13 + rax*8], rdx
0025005d  41ffc6                   inc r14d
00250060  eba0                     jmp 0x250002
00250062  cc                       int3
