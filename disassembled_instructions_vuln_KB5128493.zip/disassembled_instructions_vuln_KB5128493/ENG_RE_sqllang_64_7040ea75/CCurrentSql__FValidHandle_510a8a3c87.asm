; CCurrentSql::FValidHandle
; sqllang.dll, primary RVA 0xb22510, 396 bytes in 1 chunk(s)

; chunk at RVA 0xb22510 (396 bytes)
00b22510  4883ec68                 sub rsp, 0x68
00b22514  488b056d77fb01           mov rax, qword ptr [rip + 0x1fb776d]
00b2251b  4833c4                   xor rax, rsp
00b2251e  4889442450               mov qword ptr [rsp + 0x50], rax
00b22523  448bc2                   mov r8d, edx
00b22526  4c8bc9                   mov r9, rcx
00b22529  4885c9                   test rcx, rcx
00b2252c  751b                     jne 0xb22549
00b2252e  85d2                     test edx, edx
00b22530  7517                     jne 0xb22549
00b22532  b801000000               mov eax, 1
00b22537  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00b2253c  4833cc                   xor rcx, rsp
00b2253f  e82ceb4dff               call 0x1070
00b22544  4883c468                 add rsp, 0x68
00b22548  c3                       ret
00b22549  0fb609                   movzx ecx, byte ptr [rcx]
00b2254c  4183f814                 cmp r8d, 0x14
00b22550  7522                     jne 0xb22574
00b22552  80f902                   cmp cl, 2
00b22555  0f84fd000000             je 0xb22658
00b2255b  80f909                   cmp cl, 9
00b2255e  751e                     jne 0xb2257e
00b22560  33c0                     xor eax, eax
00b22562  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00b22567  4833cc                   xor rcx, rsp
00b2256a  e801eb4dff               call 0x1070
00b2256f  4883c468                 add rsp, 0x68
00b22573  c3                       ret
00b22574  4183f82c                 cmp r8d, 0x2c
00b22578  0f85da000000             jne 0xb22658
00b2257e  80f908                   cmp cl, 8
00b22581  0f84d1000000             je 0xb22658
00b22587  80f90c                   cmp cl, 0xc
00b2258a  0f83c8000000             jae 0xb22658
00b22590  4180790100               cmp byte ptr [r9 + 1], 0
00b22595  0f85bd000000             jne 0xb22658
00b2259b  8d41fd                   lea eax, [rcx - 3]
00b2259e  3c01                     cmp al, 1
00b225a0  7716                     ja 0xb225b8
00b225a2  410fb74102               movzx eax, word ptr [r9 + 2]
00b225a7  bafe7f0000               mov edx, 0x7ffe
00b225ac  66ffc8                   dec ax
00b225af  663bc2                   cmp ax, dx
00b225b2  0f87a0000000             ja 0xb22658
00b225b8  33c0                     xor eax, eax
00b225ba  0f57c0                   xorps xmm0, xmm0
00b225bd  33d2                     xor edx, edx
00b225bf  4889442440               mov qword ptr [rsp + 0x40], rax
00b225c4  4983e802                 sub r8, 2
00b225c8  89442448                 mov dword ptr [rsp + 0x48], eax
00b225cc  0f11442420               movups xmmword ptr [rsp + 0x20], xmm0
00b225d1  0f11442430               movups xmmword ptr [rsp + 0x30], xmm0
00b225d6  83f90b                   cmp ecx, 0xb
00b225d9  7762                     ja 0xb2263d
00b225db  4c8d151eda4dff           lea r10, [rip - 0xb225e2]
00b225e2  418b8c8a6c26b200         mov ecx, dword ptr [r10 + rcx*4 + 0xb2266c]
00b225ea  4903ca                   add rcx, r10
00b225ed  ffe1                     jmp rcx
00b225ef  4983f80e                 cmp r8, 0xe
00b225f3  7263                     jb 0xb22658
00b225f5  498d5110                 lea rdx, [r9 + 0x10]
00b225f9  4983e80e                 sub r8, 0xe
00b225fd  eb3e                     jmp 0xb2263d
00b225ff  4983f808                 cmp r8, 8
00b22603  7253                     jb 0xb22658
00b22605  498d510a                 lea rdx, [r9 + 0xa]
00b22609  4983e808                 sub r8, 8
00b2260d  eb2e                     jmp 0xb2263d
00b2260f  4983f816                 cmp r8, 0x16
00b22613  7243                     jb 0xb22658
00b22615  498d5118                 lea rdx, [r9 + 0x18]
00b22619  4983e816                 sub r8, 0x16
00b2261d  eb1e                     jmp 0xb2263d
00b2261f  4983f816                 cmp r8, 0x16
00b22623  7233                     jb 0xb22658
00b22625  4983e816                 sub r8, 0x16
00b22629  498d5118                 lea rdx, [r9 + 0x18]
00b2262d  eb0e                     jmp 0xb2263d
00b2262f  4983f810                 cmp r8, 0x10
00b22633  7223                     jb 0xb22658
00b22635  4983e810                 sub r8, 0x10
00b22639  498d5112                 lea rdx, [r9 + 0x12]
00b2263d  4d85c0                   test r8, r8
00b22640  0f84ecfeffff             je 0xb22532
00b22646  488d4c2420               lea rcx, [rsp + 0x20]
00b2264b  e885d64eff               call 0xfcd5
00b22650  85c0                     test eax, eax
00b22652  0f84dafeffff             je 0xb22532
00b22658  33c0                     xor eax, eax
00b2265a  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00b2265f  4833cc                   xor rcx, rsp
00b22662  e809ea4dff               call 0x1070
00b22667  4883c468                 add rsp, 0x68
00b2266b  c3                       ret
00b2266c  3225b200ef25             xor ah, byte ptr [rip + 0x25ef00b2]
00b22672  b200                     mov dl, 0
