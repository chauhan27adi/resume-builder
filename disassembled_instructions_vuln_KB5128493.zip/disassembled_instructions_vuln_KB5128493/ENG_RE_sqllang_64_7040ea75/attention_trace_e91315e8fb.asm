; attention_trace
; sqllang.dll, primary RVA 0x3525a0, 682 bytes in 6 chunk(s)

; chunk at RVA 0x3525a0 (123 bytes)
003525a0  4055                     push rbp
003525a2  57                       push rdi
003525a3  4156                     push r14
003525a5  488dac2440feffff         lea rbp, [rsp - 0x1c0]
003525ad  4881ecc0020000           sub rsp, 0x2c0
003525b4  803dfdf67a0200           cmp byte ptr [rip + 0x27af6fd], 0
003525bb  488bfa                   mov rdi, rdx
003525be  4c8b7120                 mov r14, qword ptr [rcx + 0x20]
003525c2  7510                     jne 0x3525d4
003525c4  488b05c5767802           mov rax, qword ptr [rip + 0x27876c5]
003525cb  f680c405000008           test byte ptr [rax + 0x5c4], 8
003525d2  7417                     je 0x3525eb
003525d4  488b4118                 mov rax, qword ptr [rcx + 0x18]
003525d8  4885c0                   test rax, rax
003525db  740e                     je 0x3525eb
003525dd  0fbf5010                 movsx edx, word ptr [rax + 0x10]
003525e1  b9e7650000               mov ecx, 0x65e7
003525e6  e845d77301               call 0x1a8fd30
003525eb  4d8b4e30                 mov r9, qword ptr [r14 + 0x30]
003525ef  48899c24f8020000         mov qword ptr [rsp + 0x2f8], rbx
003525f7  4d85c9                   test r9, r9
003525fa  0f84a6507b00             je 0xb076a6
00352600  49837e2800               cmp qword ptr [r14 + 0x28], 0
00352605  0f849b507b00             je 0xb076a6
0035260b  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00352614  488b055d89b701           mov rax, qword ptr [rip + 0x1b7895d]

; chunk at RVA 0x35261b (202 bytes)
0035261b  4c89a424b0020000         mov qword ptr [rsp + 0x2b0], r12
00352623  4c89ac24a8020000         mov qword ptr [rsp + 0x2a8], r13
0035262b  4c89bc24a0020000         mov qword ptr [rsp + 0x2a0], r15
00352633  8b08                     mov ecx, dword ptr [rax]
00352635  488b054489b701           mov rax, qword ptr [rip + 0x1b78944]
0035263c  8b10                     mov edx, dword ptr [rax]
0035263e  490314c8                 add rdx, qword ptr [r8 + rcx*8]
00352642  488b8200010000           mov rax, qword ptr [rdx + 0x100]
00352649  4c894a08                 mov qword ptr [rdx + 8], r9
0035264d  488b4040                 mov rax, qword ptr [rax + 0x40]
00352651  4c894808                 mov qword ptr [rax + 8], r9
00352655  498b4e28                 mov rcx, qword ptr [r14 + 0x28]
00352659  e892f3caff               call 0x19f0
0035265e  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00352667  488b050a89b701           mov rax, qword ptr [rip + 0x1b7890a]
0035266e  8b10                     mov edx, dword ptr [rax]
00352670  488b050989b701           mov rax, qword ptr [rip + 0x1b78909]
00352677  8b08                     mov ecx, dword ptr [rax]
00352679  498b04d0                 mov rax, qword ptr [r8 + rdx*8]
0035267d  4533c0                   xor r8d, r8d
00352680  33d2                     xor edx, edx
00352682  488b5c0850               mov rbx, qword ptr [rax + rcx + 0x50]
00352687  488d8de0010000           lea rcx, [rbp + 0x1e0]
0035268e  ff1534677802             call qword ptr [rip + 0x2786734]
00352694  488b85e0010000           mov rax, qword ptr [rbp + 0x1e0]
0035269b  49bccdcccccccccccccc     movabs r12, 0xcccccccccccccccd
003526a5  488983e8000000           mov qword ptr [rbx + 0xe8], rax
003526ac  33db                     xor ebx, ebx
003526ae  f705dc43790200000200     test dword ptr [rip + 0x27943dc], 0x20000
003526b8  448d6b01                 lea r13d, [rbx + 1]
003526bc  4c8d7bff                 lea r15, [rbx - 1]
003526c0  0f85da4d7b00             jne 0xb074a0
003526c6  488b05cb7cb701           mov rax, qword ptr [rip + 0x1b77ccb]
003526cd  3818                     cmp byte ptr [rax], bl
003526cf  7414                     je 0x3526e5
003526d1  488b05a8757802           mov rax, qword ptr [rip + 0x27875a8]
003526d8  f7403c00000100           test dword ptr [rax + 0x3c], 0x10000
003526df  0f859f4e7b00             jne 0xb07584

; chunk at RVA 0x3526e5 (86 bytes)
003526e5  498b4e28                 mov rcx, qword ptr [r14 + 0x28]
003526e9  e822f1caff               call 0x1810
003526ee  654c8b042558000000       mov r8, qword ptr gs:[0x58]
003526f7  488b057a88b701           mov rax, qword ptr [rip + 0x1b7887a]
003526fe  4c8bbc24a0020000         mov r15, qword ptr [rsp + 0x2a0]
00352706  4c8ba424b0020000         mov r12, qword ptr [rsp + 0x2b0]
0035270e  8b08                     mov ecx, dword ptr [rax]
00352710  488b056988b701           mov rax, qword ptr [rip + 0x1b78869]
00352717  8b10                     mov edx, dword ptr [rax]
00352719  490314c8                 add rdx, qword ptr [r8 + rcx*8]
0035271d  488b8200010000           mov rax, qword ptr [rdx + 0x100]
00352724  48895a08                 mov qword ptr [rdx + 8], rbx
00352728  488b4040                 mov rax, qword ptr [rax + 0x40]
0035272c  48895808                 mov qword ptr [rax + 8], rbx
00352730  488b05517cb701           mov rax, qword ptr [rip + 0x1b77c51]
00352737  3818                     cmp byte ptr [rax], bl
00352739  741e                     je 0x352759

; chunk at RVA 0x35273b (45 bytes)
0035273b  488b0d3e757802           mov rcx, qword ptr [rip + 0x278753e]
00352742  ba0f000000               mov edx, 0xf
00352747  4d8bcd                   mov r9, r13
0035274a  48895c2420               mov qword ptr [rsp + 0x20], rbx
0035274f  448d4231                 lea r8d, [rdx + 0x31]
00352753  ff15e7667802             call qword ptr [rip + 0x27866e7]
00352759  4c8bac24a8020000         mov r13, qword ptr [rsp + 0x2a8]
00352761  48899fa0020000           mov qword ptr [rdi + 0x2a0], rbx

; chunk at RVA 0x352768 (20 bytes)
00352768  488b9c24f8020000         mov rbx, qword ptr [rsp + 0x2f8]
00352770  4881c4c0020000           add rsp, 0x2c0
00352777  415e                     pop r14
00352779  5f                       pop rdi
0035277a  5d                       pop rbp
0035277b  c3                       ret

; chunk at RVA 0xb075d8 (206 bytes)
00b075d8  4889b424b8020000         mov qword ptr [rsp + 0x2b8], rsi
00b075e0  488b0c10                 mov rcx, qword ptr [rax + rdx]
00b075e4  4a8b440108               mov rax, qword ptr [rcx + r8 + 8]
00b075e9  488b7030                 mov rsi, qword ptr [rax + 0x30]
00b075ed  488b05f42f3c01           mov rax, qword ptr [rip + 0x13c2ff4]
00b075f4  3918                     cmp dword ptr [rax], ebx
00b075f6  746d                     je 0xb07665
00b075f8  488d8df0010000           lea rcx, [rbp + 0x1f0]
00b075ff  ff15231f3c01             call qword ptr [rip + 0x13c1f23]
00b07605  488b8df0010000           mov rcx, qword ptr [rbp + 0x1f0]
00b0760c  eb01                     jmp 0xb0760f
00b0760e  cc                       int3
00b0760f  488b87a0020000           mov rax, qword ptr [rdi + 0x2a0]
00b07616  483bc8                   cmp rcx, rax
00b07619  7255                     jb 0xb07670
00b0761b  482bc8                   sub rcx, rax
00b0761e  493bcf                   cmp rcx, r15
00b07621  7550                     jne 0xb07673
00b07623  eb01                     jmp 0xb07626
00b07625  cc                       int3
00b07626  814e0c00200000           or dword ptr [rsi + 0xc], 0x2000
00b0762d  ba10000000               mov edx, 0x10
00b07632  4c89bef8040000           mov qword ptr [rsi + 0x4f8], r15
00b07639  418b4654                 mov eax, dword ptr [r14 + 0x54]
00b0763d  814e1000000200           or dword ptr [rsi + 0x10], 0x20000
00b07644  894678                   mov dword ptr [rsi + 0x78], eax
00b07647  488b0d3226fd01           mov rcx, qword ptr [rip + 0x1fd2632]
00b0764e  4883c138                 add rcx, 0x38
00b07652  e8197171ff               call 0x21e770
00b07657  488bb424b8020000         mov rsi, qword ptr [rsp + 0x2b8]
00b0765f  e981b084ff               jmp 0x3526e5
00b07664  cc                       int3
00b07665  488b0c250800fe7f         mov rcx, qword ptr [0x7ffe0008]
00b0766d  eba0                     jmp 0xb0760f
00b0766f  cc                       int3
00b07670  488bcb                   mov rcx, rbx
00b07673  488b056e2f3c01           mov rax, qword ptr [rip + 0x13c2f6e]
00b0767a  3918                     cmp dword ptr [rax], ebx
00b0767c  7418                     je 0xb07696
00b0767e  4869c140420f00           imul rax, rcx, 0xf4240
00b07685  488b0d542f3c01           mov rcx, qword ptr [rip + 0x13c2f54]
00b0768c  33d2                     xor edx, edx
00b0768e  48f731                   div qword ptr [rcx]
00b07691  4c8bf8                   mov r15, rax
00b07694  eb90                     jmp 0xb07626
00b07696  498bc4                   mov rax, r12
00b07699  48f7e1                   mul rcx
00b0769c  4c8bfa                   mov r15, rdx
00b0769f  49c1ef03                 shr r15, 3
00b076a3  eb81                     jmp 0xb07626
00b076a5  cc                       int3
