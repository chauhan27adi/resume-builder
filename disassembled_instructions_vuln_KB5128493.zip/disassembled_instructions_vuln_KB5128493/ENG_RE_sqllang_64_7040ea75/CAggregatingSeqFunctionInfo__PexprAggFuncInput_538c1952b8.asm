; CAggregatingSeqFunctionInfo::PexprAggFuncInput
; sqllang.dll, primary RVA 0x14e96a0, 1272 bytes in 1 chunk(s)

; chunk at RVA 0x14e96a0 (1272 bytes)
014e96a0  4889542410               mov qword ptr [rsp + 0x10], rdx
014e96a5  53                       push rbx
014e96a6  55                       push rbp
014e96a7  56                       push rsi
014e96a8  57                       push rdi
014e96a9  4154                     push r12
014e96ab  4156                     push r14
014e96ad  4157                     push r15
014e96af  4883ec70                 sub rsp, 0x70
014e96b3  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
014e96bc  4c8bfa                   mov r15, rdx
014e96bf  488bf1                   mov rsi, rcx
014e96c2  498b4010                 mov rax, qword ptr [r8 + 0x10]
014e96c6  4c8b7048                 mov r14, qword ptr [rax + 0x48]
014e96ca  488b6840                 mov rbp, qword ptr [rax + 0x40]
014e96ce  4d85f6                   test r14, r14
014e96d1  7404                     je 0x14e96d7
014e96d3  41ff4608                 inc dword ptr [r14 + 8]
014e96d7  4885ed                   test rbp, rbp
014e96da  7403                     je 0x14e96df
014e96dc  ff4508                   inc dword ptr [rbp + 8]
014e96df  c78424c0000000f2050000   mov dword ptr [rsp + 0xc0], 0x5f2
014e96ea  c644242001               mov byte ptr [rsp + 0x20], 1
014e96ef  41b9f2050000             mov r9d, 0x5f2
014e96f5  4c8d058ca5c300           lea r8, [rip + 0xc3a58c]
014e96fc  b9a8000000               mov ecx, 0xa8
014e9701  ff15a9179e00             call qword ptr [rip + 0x9e17a9]
014e9707  488bd8                   mov rbx, rax
014e970a  4889442438               mov qword ptr [rsp + 0x38], rax
014e970f  4885c0                   test rax, rax
014e9712  0f847f030000             je 0x14e9a97
014e9718  c78424c8000000f3050000   mov dword ptr [rsp + 0xc8], 0x5f3
014e9723  c644242001               mov byte ptr [rsp + 0x20], 1
014e9728  41b9f3050000             mov r9d, 0x5f3
014e972e  4c8d0553a5c300           lea r8, [rip + 0xc3a553]
014e9735  498bd7                   mov rdx, r15
014e9738  b968000000               mov ecx, 0x68
014e973d  ff156d179e00             call qword ptr [rip + 0x9e176d]
014e9743  488bf8                   mov rdi, rax
014e9746  4889442440               mov qword ptr [rsp + 0x40], rax
014e974b  4c8d256ee0b600           lea r12, [rip + 0xb6e06e]
014e9752  4885c0                   test rax, rax
014e9755  0f84c0020000             je 0x14e9a1b
014e975b  b27f                     mov dl, 0x7f
014e975d  488d4c2448               lea rcx, [rsp + 0x48]
014e9762  e869d4b1fe               call 0x6bd0
014e9767  4c8b0e                   mov r9, qword ptr [rsi]
014e976a  488bce                   mov rcx, rsi
014e976d  41ff5168                 call qword ptr [r9 + 0x68]
014e9771  4533db                   xor r11d, r11d
014e9774  83f83a                   cmp eax, 0x3a
014e9777  0f872b020000             ja 0x14e99a8
014e977d  4898                     cdqe
014e977f  488d157a68b1fe           lea rdx, [rip - 0x14e9786]
014e9786  8b8c82ac9a4e01           mov ecx, dword ptr [rdx + rax*4 + 0x14e9aac]
014e978d  4803ca                   add rcx, rdx
014e9790  ffe1                     jmp rcx
014e9792  4c8d15af0a6e01           lea r10, [rip + 0x16e0aaf]
014e9799  e90d020000               jmp 0x14e99ab
014e979e  4c8d150b0f6e01           lea r10, [rip + 0x16e0f0b]
014e97a5  e901020000               jmp 0x14e99ab
014e97aa  4c8d1517086f01           lea r10, [rip + 0x16f0817]
014e97b1  e9f5010000               jmp 0x14e99ab
014e97b6  4c8d154b196e01           lea r10, [rip + 0x16e194b]
014e97bd  e9e9010000               jmp 0x14e99ab
014e97c2  4c8d15570c6f01           lea r10, [rip + 0x16f0c57]
014e97c9  e9dd010000               jmp 0x14e99ab
014e97ce  4c8d15a3136e01           lea r10, [rip + 0x16e13a3]
014e97d5  e9d1010000               jmp 0x14e99ab
014e97da  4c8d155f126f01           lea r10, [rip + 0x16f125f]
014e97e1  e9c5010000               jmp 0x14e99ab
014e97e6  4c8d155b186f01           lea r10, [rip + 0x16f185b]
014e97ed  e9b9010000               jmp 0x14e99ab
014e97f2  4c8d151f296e01           lea r10, [rip + 0x16e291f]
014e97f9  e9ad010000               jmp 0x14e99ab
014e97fe  4c8d150baa6501           lea r10, [rip + 0x165aa0b]
014e9805  e9a1010000               jmp 0x14e99ab
014e980a  4c8d15cfa96501           lea r10, [rip + 0x165a9cf]
014e9811  e995010000               jmp 0x14e99ab
014e9816  4c8d1593256401           lea r10, [rip + 0x1642593]
014e981d  e989010000               jmp 0x14e99ab
014e9822  4c8d157fcd6301           lea r10, [rip + 0x163cd7f]
014e9829  e97d010000               jmp 0x14e99ab
014e982e  4c8d15b34e6e01           lea r10, [rip + 0x16e4eb3]
014e9835  e971010000               jmp 0x14e99ab
014e983a  4c8d1567526e01           lea r10, [rip + 0x16e5267]
014e9841  e965010000               jmp 0x14e99ab
014e9846  4c8d153b496e01           lea r10, [rip + 0x16e493b]
014e984d  e959010000               jmp 0x14e99ab
014e9852  4c8d153f456e01           lea r10, [rip + 0x16e453f]
014e9859  e94d010000               jmp 0x14e99ab
014e985e  4c8d1523016f01           lea r10, [rip + 0x16f0123]
014e9865  e941010000               jmp 0x14e99ab
014e986a  4c8d1597b16501           lea r10, [rip + 0x165b197]
014e9871  e935010000               jmp 0x14e99ab
014e9876  4c8d15a3b16501           lea r10, [rip + 0x165b1a3]
014e987d  e929010000               jmp 0x14e99ab
014e9882  4c8d154fdd6501           lea r10, [rip + 0x165dd4f]
014e9889  e91d010000               jmp 0x14e99ab
014e988e  4c8d1503266601           lea r10, [rip + 0x1662603]
014e9895  e911010000               jmp 0x14e99ab
014e989a  4c8d15c7256601           lea r10, [rip + 0x16625c7]
014e98a1  e905010000               jmp 0x14e99ab
014e98a6  4c8d151bd66e01           lea r10, [rip + 0x16ed61b]
014e98ad  e9f9000000               jmp 0x14e99ab
014e98b2  4c8d15f7de6e01           lea r10, [rip + 0x16edef7]
014e98b9  e9ed000000               jmp 0x14e99ab
014e98be  4c8d151beb6e01           lea r10, [rip + 0x16eeb1b]
014e98c5  e9e1000000               jmp 0x14e99ab
014e98ca  4c8d151ff66e01           lea r10, [rip + 0x16ef61f]
014e98d1  e9d5000000               jmp 0x14e99ab
014e98d6  4c8d15436e6e01           lea r10, [rip + 0x16e6e43]
014e98dd  e9c9000000               jmp 0x14e99ab
014e98e2  4c8d156f2d6601           lea r10, [rip + 0x1662d6f]
014e98e9  e9bd000000               jmp 0x14e99ab
014e98ee  4c8d157b2d6601           lea r10, [rip + 0x1662d7b]
014e98f5  e9b1000000               jmp 0x14e99ab
014e98fa  4c8d1587646e01           lea r10, [rip + 0x16e6487]
014e9901  e9a5000000               jmp 0x14e99ab
014e9906  4c8d15536a6e01           lea r10, [rip + 0x16e6a53]
014e990d  e999000000               jmp 0x14e99ab
014e9912  4c8d1537fa6e01           lea r10, [rip + 0x16efa37]
014e9919  e98d000000               jmp 0x14e99ab
014e991e  4c8d158ba86501           lea r10, [rip + 0x165a88b]
014e9925  e981000000               jmp 0x14e99ab
014e992a  4c8d1597a36e01           lea r10, [rip + 0x16ea397]
014e9931  eb78                     jmp 0x14e99ab
014e9933  4c8d1516836e01           lea r10, [rip + 0x16e8316]
014e993a  eb6f                     jmp 0x14e99ab
014e993c  4c8d1585836e01           lea r10, [rip + 0x16e8385]
014e9943  eb66                     jmp 0x14e99ab
014e9945  4c8d15b48b6e01           lea r10, [rip + 0x16e8bb4]
014e994c  eb5d                     jmp 0x14e99ab
014e994e  4c8d15d3956e01           lea r10, [rip + 0x16e95d3]
014e9955  eb54                     jmp 0x14e99ab
014e9957  4c8d15429f6e01           lea r10, [rip + 0x16e9f42]
014e995e  eb4b                     jmp 0x14e99ab
014e9960  4c8d15e1a06e01           lea r10, [rip + 0x16ea0e1]
014e9967  eb42                     jmp 0x14e99ab
014e9969  4c8d1510a26e01           lea r10, [rip + 0x16ea210]
014e9970  eb39                     jmp 0x14e99ab
014e9972  4c8d158f1b6f01           lea r10, [rip + 0x16f1b8f]
014e9979  eb30                     jmp 0x14e99ab
014e997b  4c8d15dea76e01           lea r10, [rip + 0x16ea7de]
014e9982  eb27                     jmp 0x14e99ab
014e9984  4c8d15ddac6e01           lea r10, [rip + 0x16eacdd]
014e998b  eb1e                     jmp 0x14e99ab
014e998d  4c8d1594b36e01           lea r10, [rip + 0x16eb394]
014e9994  eb15                     jmp 0x14e99ab
014e9996  4c8d15931d6f01           lea r10, [rip + 0x16f1d93]
014e999d  eb0c                     jmp 0x14e99ab
014e999f  4c8d1522266f01           lea r10, [rip + 0x16f2622]
014e99a6  eb03                     jmp 0x14e99ab
014e99a8  4d8bd3                   mov r10, r11
014e99ab  4c8927                   mov qword ptr [rdi], r12
014e99ae  c7470801000000           mov dword ptr [rdi + 8], 1
014e99b5  488d05f491ae00           lea rax, [rip + 0xae91f4]
014e99bc  488907                   mov qword ptr [rdi], rax
014e99bf  4c897f10                 mov qword ptr [rdi + 0x10], r15
014e99c3  488d05661eae00           lea rax, [rip + 0xae1e66]
014e99ca  488907                   mov qword ptr [rdi], rax
014e99cd  0f10442448               movups xmm0, xmmword ptr [rsp + 0x48]
014e99d2  0f114718                 movups xmmword ptr [rdi + 0x18], xmm0
014e99d6  0f104c2458               movups xmm1, xmmword ptr [rsp + 0x58]
014e99db  0f114f28                 movups xmmword ptr [rdi + 0x28], xmm1
014e99df  80673efc                 and byte ptr [rdi + 0x3e], 0xfc
014e99e3  66c7473c0500             mov word ptr [rdi + 0x3c], 5
014e99e9  e842c6b7fe               call 0x66030
014e99ee  894738                   mov dword ptr [rdi + 0x38], eax
014e99f1  488d0538f4ad00           lea rax, [rip + 0xadf438]
014e99f8  488907                   mov qword ptr [rdi], rax
014e99fb  48896f40                 mov qword ptr [rdi + 0x40], rbp
014e99ff  4c897748                 mov qword ptr [rdi + 0x48], r14
014e9a03  488d052eb6a600           lea rax, [rip + 0xa6b62e]
014e9a0a  488907                   mov qword ptr [rdi], rax
014e9a0d  4c895f58                 mov qword ptr [rdi + 0x58], r11
014e9a11  4c895760                 mov qword ptr [rdi + 0x60], r10
014e9a15  80675080                 and byte ptr [rdi + 0x50], 0x80
014e9a19  eb06                     jmp 0x14e9a21
014e9a1b  4533db                   xor r11d, r11d
014e9a1e  418bfb                   mov edi, r11d
014e9a21  4c8923                   mov qword ptr [rbx], r12
014e9a24  c7430801000000           mov dword ptr [rbx + 8], 1
014e9a2b  488d05fe2ec300           lea rax, [rip + 0xc32efe]
014e9a32  488903                   mov qword ptr [rbx], rax
014e9a35  4c895b60                 mov qword ptr [rbx + 0x60], r11
014e9a39  4c895b68                 mov qword ptr [rbx + 0x68], r11
014e9a3d  4c895b70                 mov qword ptr [rbx + 0x70], r11
014e9a41  4c895b78                 mov qword ptr [rbx + 0x78], r11
014e9a45  f20f100503256401         movsd xmm0, qword ptr [rip + 0x1642503]
014e9a4d  f20f118388000000         movsd qword ptr [rbx + 0x88], xmm0
014e9a55  4c899b90000000           mov qword ptr [rbx + 0x90], r11
014e9a5c  4c899b98000000           mov qword ptr [rbx + 0x98], r11
014e9a63  4c899ba0000000           mov qword ptr [rbx + 0xa0], r11
014e9a6a  4c895b20                 mov qword ptr [rbx + 0x20], r11
014e9a6e  44895b18                 mov dword ptr [rbx + 0x18], r11d
014e9a72  48897b10                 mov qword ptr [rbx + 0x10], rdi
014e9a76  4c895b50                 mov qword ptr [rbx + 0x50], r11
014e9a7a  4c895b58                 mov qword ptr [rbx + 0x58], r11
014e9a7e  4c899b80000000           mov qword ptr [rbx + 0x80], r11
014e9a85  488bc3                   mov rax, rbx
014e9a88  4883c470                 add rsp, 0x70
014e9a8c  415f                     pop r15
014e9a8e  415e                     pop r14
014e9a90  415c                     pop r12
014e9a92  5f                       pop rdi
014e9a93  5e                       pop rsi
014e9a94  5d                       pop rbp
014e9a95  5b                       pop rbx
014e9a96  c3                       ret
014e9a97  4533db                   xor r11d, r11d
014e9a9a  418bc3                   mov eax, r11d
014e9a9d  4883c470                 add rsp, 0x70
014e9aa1  415f                     pop r15
014e9aa3  415e                     pop r14
014e9aa5  415c                     pop r12
014e9aa7  5f                       pop rdi
014e9aa8  5e                       pop rsi
014e9aa9  5d                       pop rbp
014e9aaa  5b                       pop rbx
014e9aab  c3                       ret
014e9aac  8e984e01a899             mov ds, word ptr [rax - 0x6657feb2]
014e9ab2  4e019a984e01a8           add qword ptr [rdx - 0x57feb168], r11
014e9ab9  99                       cdq
014e9aba  4e01fe                   add rsi, r15
014e9abd  97                       xchg edi, eax
014e9abe  4e01a8994e0176           add qword ptr [rax + 0x76014e99], r13
014e9ac5  98                       cwde
014e9ac6  4e01a8994e016a           add qword ptr [rax + 0x6a014e99], r13
014e9acd  98                       cwde
014e9ace  4e01a8994e0182           add qword ptr [rax - 0x7dfeb167], r13
014e9ad5  98                       cwde
014e9ad6  4e01a8994e0122           add qword ptr [rax + 0x22014e99], r13
014e9add  98                       cwde
014e9ade  4e015298                 add qword ptr [rdx - 0x68], r10
014e9ae2  4e014698                 add qword ptr [rsi - 0x68], r8
014e9ae6  4e015e98                 add qword ptr [rsi - 0x68], r11
014e9aea  4e012e                   add qword ptr [rsi], r13
014e9aed  98                       cwde
014e9aee  4e013a                   add qword ptr [rdx], r15
014e9af1  98                       cwde
014e9af2  4e013c99                 add qword ptr [rcx + r11*4], r15
014e9af6  4e014599                 add qword ptr [rbp - 0x67], r8
014e9afa  4e014e99                 add qword ptr [rsi - 0x67], r9
014e9afe  4e015799                 add qword ptr [rdi - 0x67], r10
014e9b02  4e016099                 add qword ptr [rax - 0x67], r12
014e9b06  4e016999                 add qword ptr [rcx - 0x67], r13
014e9b0a  4e01a6984e01be           add qword ptr [rsi - 0x41feb168], r12
014e9b11  98                       cwde
014e9b12  4e01b2984e01ca           add qword ptr [rdx - 0x35feb168], r14
014e9b19  98                       cwde
014e9b1a  4e0116                   add qword ptr [rsi], r10
014e9b1d  98                       cwde
014e9b1e  4e01d6                   add rsi, r10
014e9b21  98                       cwde
014e9b22  4e01e2                   add rdx, r12
014e9b25  98                       cwde
014e9b26  4e01ee                   add rsi, r13
014e9b29  98                       cwde
014e9b2a  4e01fa                   add rdx, r15
014e9b2d  98                       cwde
014e9b2e  4e01a8994e0106           add qword ptr [rax + 0x6014e99], r13
014e9b35  99                       cdq
014e9b36  4e010a                   add qword ptr [rdx], r9
014e9b39  98                       cwde
014e9b3a  4e01a8994e0112           add qword ptr [rax + 0x12014e99], r13
014e9b41  99                       cdq
014e9b42  4e011e                   add qword ptr [rsi], r11
014e9b45  99                       cdq
014e9b46  4e01a8994e01a8           add qword ptr [rax - 0x57feb167], r13
014e9b4d  99                       cdq
014e9b4e  4e01a8994e012a           add qword ptr [rax + 0x2a014e99], r13
014e9b55  99                       cdq
014e9b56  4e01b6974e01f2           add qword ptr [rsi - 0xdfeb169], r14
014e9b5d  97                       xchg edi, eax
014e9b5e  4e01aa974e01c2           add qword ptr [rdx - 0x3dfeb169], r13
014e9b65  97                       xchg edi, eax
014e9b66  4e0192974e019e           add qword ptr [rdx - 0x61feb169], r10
014e9b6d  97                       xchg edi, eax
014e9b6e  4e0133                   add qword ptr [rbx], r14
014e9b71  99                       cdq
014e9b72  4e01ce                   add rsi, r9
014e9b75  97                       xchg edi, eax
014e9b76  4e01da                   add rdx, r11
014e9b79  97                       xchg edi, eax
014e9b7a  4e01e6                   add rsi, r12
014e9b7d  97                       xchg edi, eax
014e9b7e  4e017299                 add qword ptr [rdx - 0x67], r14
014e9b82  4e017b99                 add qword ptr [rbx - 0x67], r15
014e9b86  4e0184994e018d99         add qword ptr [rcx + r11*4 - 0x6672feb2], r8
014e9b8e  4e0196994e019f           add qword ptr [rsi - 0x60feb167], r10
014e9b95  99                       cdq
