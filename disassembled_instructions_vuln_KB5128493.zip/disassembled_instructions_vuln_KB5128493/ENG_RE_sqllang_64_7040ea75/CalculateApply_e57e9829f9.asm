; CalculateApply
; sqllang.dll, primary RVA 0x1c07e0, 819 bytes in 10 chunk(s)

; chunk at RVA 0x1c07e0 (80 bytes)
001c07e0  488bc4                   mov rax, rsp
001c07e3  4c894018                 mov qword ptr [rax + 0x18], r8
001c07e7  55                       push rbp
001c07e8  4155                     push r13
001c07ea  488d68e8                 lea rbp, [rax - 0x18]
001c07ee  4881ec08010000           sub rsp, 0x108
001c07f5  f20f10058bb79602         movsd xmm0, qword ptr [rip + 0x296b78b]
001c07fd  4c8d1584b79602           lea r10, [rip + 0x296b784]
001c0804  f20f100dccb79602         movsd xmm1, qword ptr [rip + 0x296b7cc]
001c080c  4c8d05c5b79602           lea r8, [rip + 0x296b7c5]
001c0813  4c8b6d48                 mov r13, qword ptr [rbp + 0x48]
001c0817  0f2970c8                 movaps xmmword ptr [rax - 0x38], xmm6
001c081b  0f57f6                   xorps xmm6, xmm6
001c081e  440f2940a8               movaps xmmword ptr [rax - 0x58], xmm8
001c0823  450f57c0                 xorps xmm8, xmm8
001c0827  440f295088               movaps xmmword ptr [rax - 0x78], xmm10
001c082c  450f57d2                 xorps xmm10, xmm10

; chunk at RVA 0x1c0830 (140 bytes)
001c0830  48895808                 mov qword ptr [rax + 8], rbx
001c0834  4c8960e8                 mov qword ptr [rax - 0x18], r12
001c0838  4c8be2                   mov r12, rdx
001c083b  488b5558                 mov rdx, qword ptr [rbp + 0x58]
001c083f  4c8970e0                 mov qword ptr [rax - 0x20], r14
001c0843  4d8bf1                   mov r14, r9
001c0846  4c8b4d50                 mov r9, qword ptr [rbp + 0x50]
001c084a  0f2978b8                 movaps xmmword ptr [rax - 0x48], xmm7
001c084e  f20f101a                 movsd xmm3, qword ptr [rdx]
001c0852  440f294898               movaps xmmword ptr [rax - 0x68], xmm9
001c0857  488bc2                   mov rax, rdx
001c085a  f2410f1011               movsd xmm2, qword ptr [r9]
001c085f  660f2fc3                 comisd xmm0, xmm3
001c0863  f20f114d58               movsd qword ptr [rbp + 0x58], xmm1
001c0868  f2440f11442470           movsd qword ptr [rsp + 0x70], xmm8
001c086f  490f47c2                 cmova rax, r10
001c0873  660f2fc2                 comisd xmm0, xmm2
001c0877  f20f1038                 movsd xmm7, qword ptr [rax]
001c087b  498bc1                   mov rax, r9
001c087e  490f47c2                 cmova rax, r10
001c0882  660f2fc9                 comisd xmm1, xmm1
001c0886  f2440f1008               movsd xmm9, qword ptr [rax]
001c088b  488d4558                 lea rax, [rbp + 0x58]
001c088f  490f47c0                 cmova rax, r8
001c0893  66440f2fc1               comisd xmm8, xmm1
001c0898  f20f1000                 movsd xmm0, qword ptr [rax]
001c089c  488d442470               lea rax, [rsp + 0x70]
001c08a1  f20f114588               movsd qword ptr [rbp - 0x78], xmm0
001c08a6  490f47c0                 cmova rax, r8
001c08aa  f20f1000                 movsd xmm0, qword ptr [rax]
001c08ae  f20f114590               movsd qword ptr [rbp - 0x70], xmm0
001c08b3  83e901                   sub ecx, 1
001c08b6  0f85b4130300             jne 0x1f1c70

; chunk at RVA 0x1c08bc (300 bytes)
001c08bc  f20f10059468e501         movsd xmm0, qword ptr [rip + 0x1e56894]
001c08c4  0f28f2                   movaps xmm6, xmm2
001c08c7  f20f59f3                 mulsd xmm6, xmm3
001c08cb  660f2fc6                 comisd xmm0, xmm6
001c08cf  0f82d81e3e01             jb 0x15a27ad
001c08d5  f20f10058368e501         movsd xmm0, qword ptr [rip + 0x1e56883]
001c08dd  660f2ff0                 comisd xmm6, xmm0
001c08e1  0f82bd1e3e01             jb 0x15a27a4
001c08e7  f2410f11b698000000       movsd qword ptr [r14 + 0x98], xmm6
001c08f0  4c8d4558                 lea r8, [rbp + 0x58]
001c08f4  f20f1002                 movsd xmm0, qword ptr [rdx]
001c08f8  488d4c2478               lea rcx, [rsp + 0x78]
001c08fd  f2410f1009               movsd xmm1, qword ptr [r9]
001c0902  488d5580                 lea rdx, [rbp - 0x80]
001c0906  f20f114558               movsd qword ptr [rbp + 0x58], xmm0
001c090b  f20f114d80               movsd qword ptr [rbp - 0x80], xmm1
001c0910  e8bb020000               call 0x1c0bd0
001c0915  488b08                   mov rcx, qword ptr [rax]
001c0918  49894d00                 mov qword ptr [r13], rcx
001c091c  41f60603                 test byte ptr [r14], 3
001c0920  0f85cd000000             jne 0x1c09f3
001c0926  488b4560                 mov rax, qword ptr [rbp + 0x60]
001c092a  4c8d4c2478               lea r9, [rsp + 0x78]
001c092f  f2410f108680000000       movsd xmm0, qword ptr [r14 + 0x80]
001c0938  488d542470               lea rdx, [rsp + 0x70]
001c093d  f2410f104e78             movsd xmm1, qword ptr [r14 + 0x78]
001c0943  4d8b4668                 mov r8, qword ptr [r14 + 0x68]
001c0947  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
001c094b  4889442440               mov qword ptr [rsp + 0x40], rax
001c0950  488d4558                 lea rax, [rbp + 0x58]
001c0954  4889442438               mov qword ptr [rsp + 0x38], rax
001c0959  488d4580                 lea rax, [rbp - 0x80]
001c095d  4889442430               mov qword ptr [rsp + 0x30], rax
001c0962  498b4670                 mov rax, qword ptr [r14 + 0x70]
001c0966  c744242830000000         mov dword ptr [rsp + 0x28], 0x30
001c096e  4889442420               mov qword ptr [rsp + 0x20], rax
001c0973  f20f117d58               movsd qword ptr [rbp + 0x58], xmm7
001c0978  f2440f114d80             movsd qword ptr [rbp - 0x80], xmm9
001c097e  f20f11442478             movsd qword ptr [rsp + 0x78], xmm0
001c0984  f20f114c2470             movsd qword ptr [rsp + 0x70], xmm1
001c098a  e8411afcff               call 0x1823d0
001c098f  f2410f108680000000       movsd xmm0, qword ptr [r14 + 0x80]
001c0998  488d4558                 lea rax, [rbp + 0x58]
001c099c  f2410f104e78             movsd xmm1, qword ptr [r14 + 0x78]
001c09a2  4c8d4c2478               lea r9, [rsp + 0x78]
001c09a7  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
001c09ab  4c8d442470               lea r8, [rsp + 0x70]
001c09b0  4889442430               mov qword ptr [rsp + 0x30], rax
001c09b5  498bd6                   mov rdx, r14
001c09b8  488d4580                 lea rax, [rbp - 0x80]
001c09bc  f20f117d58               movsd qword ptr [rbp + 0x58], xmm7
001c09c1  4889442428               mov qword ptr [rsp + 0x28], rax
001c09c6  c744242030000000         mov dword ptr [rsp + 0x20], 0x30
001c09ce  f2440f114d80             movsd qword ptr [rbp - 0x80], xmm9
001c09d4  f20f11442478             movsd qword ptr [rsp + 0x78], xmm0
001c09da  f20f114c2470             movsd qword ptr [rsp + 0x70], xmm1
001c09e0  e82b09fcff               call 0x181310
001c09e5  eb01                     jmp 0x1c09e8
001c09e7  cc                       int3

; chunk at RVA 0x1c09e8 (63 bytes)
001c09e8  4c8b4d50                 mov r9, qword ptr [rbp + 0x50]
001c09ec  4c8d1595b59602           lea r10, [rip + 0x296b595]
001c09f3  48837d3000               cmp qword ptr [rbp + 0x30], 0
001c09f8  440f288c24b0000000       movaps xmm9, xmmword ptr [rsp + 0xb0]
001c0a01  0f28bc24d0000000         movaps xmm7, xmmword ptr [rsp + 0xd0]
001c0a09  4c8bb424f8000000         mov r14, qword ptr [rsp + 0xf8]
001c0a11  4c8ba42400010000         mov r12, qword ptr [rsp + 0x100]
001c0a19  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
001c0a21  0f85211d3e01             jne 0x15a2748

; chunk at RVA 0x1c0a27 (59 bytes)
001c0a27  f2410f104500             movsd xmm0, qword ptr [r13]
001c0a2d  66440f2fd0               comisd xmm10, xmm0
001c0a32  0f87841d3e01             ja 0x15a27bc
001c0a38  660f2fc6                 comisd xmm0, xmm6
001c0a3c  b001                     mov al, 1
001c0a3e  0f87881d3e01             ja 0x15a27cc
001c0a44  4c8d9c2408010000         lea r11, [rsp + 0x108]
001c0a4c  410f2873d8               movaps xmm6, xmmword ptr [r11 - 0x28]
001c0a51  450f2843b8               movaps xmm8, xmmword ptr [r11 - 0x48]
001c0a56  450f285398               movaps xmm10, xmmword ptr [r11 - 0x68]
001c0a5b  498be3                   mov rsp, r11
001c0a5e  415d                     pop r13
001c0a60  5d                       pop rbp
001c0a61  c3                       ret

; chunk at RVA 0x1f1ce2 (35 bytes)
001f1ce2  4889b42428010000         mov qword ptr [rsp + 0x128], rsi
001f1cea  4889bc2438010000         mov qword ptr [rsp + 0x138], rdi
001f1cf2  4c89bc24f0000000         mov qword ptr [rsp + 0xf0], r15
001f1cfa  4533ff                   xor r15d, r15d
001f1cfd  85db                     test ebx, ebx
001f1cff  0f857d093b01             jne 0x15a2682

; chunk at RVA 0x15a2716 (19 bytes)
015a2716  660f2ec0                 ucomisd xmm0, xmm0
015a271a  0f8b59ffffff             jnp 0x15a2679
015a2720  0f57c0                   xorps xmm0, xmm0
015a2723  e9a5f5c4fe               jmp 0x1f1ccd
015a2728  cc                       int3

; chunk at RVA 0x15a2729 (10 bytes)
015a2729  33d2                     xor edx, edx
015a272b  ebb6                     jmp 0x15a26e3
015a272d  cc                       int3
015a272e  33c9                     xor ecx, ecx
015a2730  ebcb                     jmp 0x15a26fd
015a2732  cc                       int3

; chunk at RVA 0x15a2733 (21 bytes)
015a2733  ba08000000               mov edx, 8
015a2738  488bcf                   mov rcx, rdi
015a273b  ff1547889200             call qword ptr [rip + 0x928847]
015a2741  90                       nop
015a2742  e9b0f6c4fe               jmp 0x1f1df7
015a2747  cc                       int3

; chunk at RVA 0x15a2748 (92 bytes)
015a2748  66410f2ef0               ucomisd xmm6, xmm8
015a274d  0f8ad4e2c1fe             jp 0x1c0a27
015a2753  0f85cee2c1fe             jne 0x1c0a27
015a2759  f2410f1009               movsd xmm1, qword ptr [r9]
015a275e  66410f2fc8               comisd xmm1, xmm8
015a2763  0f86bee2c1fe             jbe 0x1c0a27
015a2769  f20f100517985801         movsd xmm0, qword ptr [rip + 0x1589817]
015a2771  488d4550                 lea rax, [rbp + 0x50]
015a2775  660f2fc1                 comisd xmm0, xmm1
015a2779  f2410f104500             movsd xmm0, qword ptr [r13]
015a277f  f20f114d50               movsd qword ptr [rbp + 0x50], xmm1
015a2784  490f47c2                 cmova rax, r10
015a2788  f20f1010                 movsd xmm2, qword ptr [rax]
015a278c  b001                     mov al, 1
015a278e  660f2fc2                 comisd xmm0, xmm2
015a2792  0f86ace2c1fe             jbe 0x1c0a44
015a2798  f2410f115500             movsd qword ptr [r13], xmm2
015a279e  e9a1e2c1fe               jmp 0x1c0a44
015a27a3  cc                       int3
