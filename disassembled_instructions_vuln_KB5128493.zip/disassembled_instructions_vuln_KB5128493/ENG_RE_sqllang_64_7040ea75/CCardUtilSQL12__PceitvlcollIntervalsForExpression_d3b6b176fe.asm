; CCardUtilSQL12::PceitvlcollIntervalsForExpression
; sqllang.dll, primary RVA 0x291400, 683 bytes in 1 chunk(s)

; chunk at RVA 0x291400 (683 bytes)
00291400  4c894c2420               mov qword ptr [rsp + 0x20], r9
00291405  4889542410               mov qword ptr [rsp + 0x10], rdx
0029140a  48894c2408               mov qword ptr [rsp + 8], rcx
0029140f  55                       push rbp
00291410  53                       push rbx
00291411  56                       push rsi
00291412  57                       push rdi
00291413  4154                     push r12
00291415  4155                     push r13
00291417  4156                     push r14
00291419  4157                     push r15
0029141b  488d6c24f1               lea rbp, [rsp - 0xf]
00291420  4881ecf8000000           sub rsp, 0xf8
00291427  48c745dffeffffff         mov qword ptr [rbp - 0x21], 0xfffffffffffffffe
0029142f  498bf0                   mov rsi, r8
00291432  488bd9                   mov rbx, rcx
00291435  488b8a08010000           mov rcx, qword ptr [rdx + 0x108]
0029143c  488b01                   mov rax, qword ptr [rcx]
0029143f  ff90a8000000             call qword ptr [rax + 0xa8]
00291445  48894587                 mov qword ptr [rbp - 0x79], rax
00291449  488d45a7                 lea rax, [rbp - 0x59]
0029144d  4889442468               mov qword ptr [rsp + 0x68], rax
00291452  48895da7                 mov qword ptr [rbp - 0x59], rbx
00291456  c645af00                 mov byte ptr [rbp - 0x51], 0
0029145a  4533ff                   xor r15d, r15d
0029145d  44897db3                 mov dword ptr [rbp - 0x4d], r15d
00291461  c745b701000000           mov dword ptr [rbp - 0x49], 1
00291468  4c897dbf                 mov qword ptr [rbp - 0x41], r15
0029146c  488d3d4d63dc01           lea rdi, [rip + 0x1dc634d]
00291473  48897d97                 mov qword ptr [rbp - 0x69], rdi
00291477  c7459f01000000           mov dword ptr [rbp - 0x61], 1
0029147e  488d052bbbe801           lea rax, [rip + 0x1e8bb2b]
00291485  48894597                 mov qword ptr [rbp - 0x69], rax
00291489  488d555f                 lea rdx, [rbp + 0x5f]
0029148d  488d4da7                 lea rcx, [rbp - 0x59]
00291491  e80a34d8ff               call 0x148a0
00291496  c7456723110000           mov dword ptr [rbp + 0x67], 0x1123
0029149d  c644242001               mov byte ptr [rsp + 0x20], 1
002914a2  41b923110000             mov r9d, 0x1123
002914a8  4c8d05292feb01           lea r8, [rip + 0x1eb2f29]
002914af  488bd3                   mov rdx, rbx
002914b2  418d4f68                 lea ecx, [r15 + 0x68]
002914b6  ff15f499c301             call qword ptr [rip + 0x1c399f4]
002914bc  4889442430               mov qword ptr [rsp + 0x30], rax
002914c1  4885c0                   test rax, rax
002914c4  0f8498006901             je 0x1921562
002914ca  488bd3                   mov rdx, rbx
002914cd  488bc8                   mov rcx, rax
002914d0  e80b7cfcff               call 0x2590e0
002914d5  4c8be0                   mov r12, rax
002914d8  eb01                     jmp 0x2914db
002914da  cc                       int3
002914db  8b4e18                   mov ecx, dword ptr [rsi + 0x18]
002914de  488d442448               lea rax, [rsp + 0x48]
002914e3  4889455f                 mov qword ptr [rbp + 0x5f], rax
002914e7  48895c2448               mov qword ptr [rsp + 0x48], rbx
002914ec  c644245000               mov byte ptr [rsp + 0x50], 0
002914f1  44897c2454               mov dword ptr [rsp + 0x54], r15d
002914f6  b801000000               mov eax, 1
002914fb  85c9                     test ecx, ecx
002914fd  0f45c1                   cmovne eax, ecx
00291500  89442458                 mov dword ptr [rsp + 0x58], eax
00291504  4c897c2460               mov qword ptr [rsp + 0x60], r15
00291509  48897c2438               mov qword ptr [rsp + 0x38], rdi
0029150e  c744244001000000         mov dword ptr [rsp + 0x40], 1
00291516  488d05dbb4e801           lea rax, [rip + 0x1e8b4db]
0029151d  4889442438               mov qword ptr [rsp + 0x38], rax
00291522  4889742468               mov qword ptr [rsp + 0x68], rsi
00291527  488b5e10                 mov rbx, qword ptr [rsi + 0x10]
0029152b  488b03                   mov rax, qword ptr [rbx]
0029152e  488bcb                   mov rcx, rbx
00291531  ff5018                   call qword ptr [rax + 0x18]
00291534  83f859                   cmp eax, 0x59
00291537  0f8577006901             jne 0x19215b4
0029153d  837b4000                 cmp dword ptr [rbx + 0x40], 0
00291541  0f856d006901             jne 0x19215b4
00291547  458bf7                   mov r14d, r15d
0029154a  44397e18                 cmp dword ptr [rsi + 0x18], r15d
0029154e  0f8e93006901             jle 0x19215e7
00291554  498bff                   mov rdi, r15
00291557  8b4c2454                 mov ecx, dword ptr [rsp + 0x54]
0029155b  4533ed                   xor r13d, r13d
0029155e  6690                     nop
00291560  488b4620                 mov rax, qword ptr [rsi + 0x20]
00291564  4c8b3c07                 mov r15, qword ptr [rdi + rax]
00291568  488b542460               mov rdx, qword ptr [rsp + 0x60]
0029156d  8b5c2458                 mov ebx, dword ptr [rsp + 0x58]
00291571  4885d2                   test rdx, rdx
00291574  0f840f010000             je 0x291689
0029157a  3bcb                     cmp ecx, ebx
0029157c  0f83e9ff6801             jae 0x192156b
00291582  8bc1                     mov eax, ecx
00291584  4c893cc2                 mov qword ptr [rdx + rax*8], r15
00291588  8b4c2454                 mov ecx, dword ptr [rsp + 0x54]
0029158c  ffc1                     inc ecx
0029158e  894c2454                 mov dword ptr [rsp + 0x54], ecx
00291592  41ffc6                   inc r14d
00291595  4883c708                 add rdi, 8
00291599  443b7618                 cmp r14d, dword ptr [rsi + 0x18]
0029159d  7cc1                     jl 0x291560
0029159f  4533ff                   xor r15d, r15d
002915a2  eb01                     jmp 0x2915a5
002915a4  cc                       int3
002915a5  8bf9                     mov edi, ecx
002915a7  894d5f                   mov dword ptr [rbp + 0x5f], ecx
002915aa  458bf7                   mov r14d, r15d
002915ad  4c8b6d77                 mov r13, qword ptr [rbp + 0x77]
002915b1  85c9                     test ecx, ecx
002915b3  0f8438110000             je 0x2926f1
002915b9  660f1f0400               nop word ptr [rax + rax]
002915be  6690                     nop
002915c0  443bf1                   cmp r14d, ecx
002915c3  0f8328006901             jae 0x19215f1
002915c9  488b442460               mov rax, qword ptr [rsp + 0x60]
002915ce  498b3407                 mov rsi, qword ptr [r15 + rax]
002915d2  eb01                     jmp 0x2915d5
002915d4  cc                       int3
002915d5  488b5e10                 mov rbx, qword ptr [rsi + 0x10]
002915d9  48c744243000000000       mov qword ptr [rsp + 0x30], 0
002915e2  48c7456700000000         mov qword ptr [rbp + 0x67], 0
002915ea  488b03                   mov rax, qword ptr [rbx]
002915ed  488d4d67                 lea rcx, [rbp + 0x67]
002915f1  48894c2428               mov qword ptr [rsp + 0x28], rcx
002915f6  488d4c2430               lea rcx, [rsp + 0x30]
002915fb  48894c2420               mov qword ptr [rsp + 0x20], rcx
00291600  4c8d4d97                 lea r9, [rbp - 0x69]
00291604  4c8bc6                   mov r8, rsi
00291607  488b5557                 mov rdx, qword ptr [rbp + 0x57]
0029160b  488bcb                   mov rcx, rbx
0029160e  ff9010050000             call qword ptr [rax + 0x510]
00291614  8bc8                     mov ecx, eax
00291616  83f801                   cmp eax, 1
00291619  0f85ef180200             jne 0x2b2f0e
0029161f  488b4d87                 mov rcx, qword ptr [rbp - 0x79]
00291623  488b01                   mov rax, qword ptr [rcx]
00291626  488b542430               mov rdx, qword ptr [rsp + 0x30]
0029162b  ff90c8000000             call qword ptr [rax + 0xc8]
00291631  488bd8                   mov rbx, rax
00291634  488945e7                 mov qword ptr [rbp - 0x19], rax
00291638  4885c0                   test rax, rax
0029163b  0f85b8ff6801             jne 0x19215f9
00291641  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
00291645  488b542430               mov rdx, qword ptr [rsp + 0x30]
0029164a  498bcc                   mov rcx, r12
0029164d  e83e71fcff               call 0x258790
00291652  90                       nop
00291653  4885db                   test rbx, rbx
00291656  0f85b0ff6801             jne 0x192160c
0029165c  488b4d67                 mov rcx, qword ptr [rbp + 0x67]
00291660  4885c9                   test rcx, rcx
00291663  740a                     je 0x29166f
00291665  834108ff                 add dword ptr [rcx + 8], -1
00291669  0f8455bb0500             je 0x2ed1c4
0029166f  41ffc6                   inc r14d
00291672  4983c708                 add r15, 8
00291676  443bf7                   cmp r14d, edi
00291679  0f836f100000             jae 0x2926ee
0029167f  8b4c2454                 mov ecx, dword ptr [rsp + 0x54]
00291683  e938ffffff               jmp 0x2915c0
00291688  cc                       int3
00291689  8bd3                     mov edx, ebx
0029168b  488d4c2448               lea rcx, [rsp + 0x48]
00291690  e86b760f00               call 0x388d00
00291695  488bd0                   mov rdx, rax
00291698  4889442460               mov qword ptr [rsp + 0x60], rax
0029169d  895c2458                 mov dword ptr [rsp + 0x58], ebx
002916a1  8b4c2454                 mov ecx, dword ptr [rsp + 0x54]
002916a5  e9d0feffff               jmp 0x29157a
002916aa  cc                       int3
