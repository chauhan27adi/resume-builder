; AuditTVF::OutputColumn
; sqllang.dll, primary RVA 0x1138510, 2308 bytes in 3 chunk(s)

; chunk at RVA 0x1138510 (145 bytes)
01138510  4055                     push rbp
01138512  56                       push rsi
01138513  57                       push rdi
01138514  4154                     push r12
01138516  4155                     push r13
01138518  4156                     push r14
0113851a  4157                     push r15
0113851c  4881ec80000000           sub rsp, 0x80
01138523  488b055e179a01           mov rax, qword ptr [rip + 0x19a175e]
0113852a  4833c4                   xor rax, rsp
0113852d  4889442478               mov qword ptr [rsp + 0x78], rax
01138532  4c8bf1                   mov r14, rcx
01138535  450fb7e1                 movzx r12d, r9w
01138539  488b8950060000           mov rcx, qword ptr [rcx + 0x650]
01138540  418bd4                   mov edx, r12d
01138543  498bf8                   mov rdi, r8
01138546  be05400080               mov esi, 0x80004005
0113854b  488b01                   mov rax, qword ptr [rcx]
0113854e  ff5018                   call qword ptr [rax + 0x18]
01138551  bdffff0000               mov ebp, 0xffff
01138556  4c8d2da37aecfe           lea r13, [rip - 0x113855d]
0113855d  0fb75010                 movzx edx, word ptr [rax + 0x10]
01138561  663bd5                   cmp dx, bp
01138564  7417                     je 0x113857d
01138566  0fb600                   movzx eax, byte ptr [rax]
01138569  420fb68c2810360202       movzx ecx, byte ptr [rax + r13 + 0x2023610]
01138572  4280bc299875ae0200       cmp byte ptr [rcx + r13 + 0x2ae7598], 0
0113857b  7402                     je 0x113857f
0113857d  8bd5                     mov edx, ebp
0113857f  0fb7ca                   movzx ecx, dx
01138582  394f28                   cmp dword ptr [rdi + 0x28], ecx
01138585  0f8779070000             ja 0x1138d04
0113858b  498b8e50060000           mov rcx, qword ptr [r14 + 0x650]
01138592  488b01                   mov rax, qword ptr [rcx]
01138595  ff5010                   call qword ptr [rax + 0x10]
01138598  443be0                   cmp r12d, eax
0113859b  0f8d63070000             jge 0x1138d04

; chunk at RVA 0x11385a1 (1891 bytes)
011385a1  48899c24c8000000         mov qword ptr [rsp + 0xc8], rbx
011385a9  0faee8                   lfence
011385ac  498b8e50060000           mov rcx, qword ptr [r14 + 0x650]
011385b3  33db                     xor ebx, ebx
011385b5  418bd4                   mov edx, r12d
011385b8  8bf3                     mov esi, ebx
011385ba  488b01                   mov rax, qword ptr [rcx]
011385bd  ff5018                   call qword ptr [rax + 0x18]
011385c0  0fb608                   movzx ecx, byte ptr [rax]
011385c3  83c1dc                   add ecx, -0x24
011385c6  81f9c3000000             cmp ecx, 0xc3
011385cc  0f87ef060000             ja 0x1138cc1
011385d2  4863c1                   movsxd rax, ecx
011385d5  420fb68428508d1301       movzx eax, byte ptr [rax + r13 + 0x1138d50]
011385de  418b8c85288d1301         mov ecx, dword ptr [r13 + rax*4 + 0x1138d28]
011385e6  4903cd                   add rcx, r13
011385e9  ffe1                     jmp rcx
011385eb  488b4708                 mov rax, qword ptr [rdi + 8]
011385ef  8b4004                   mov eax, dword ptr [rax + 4]
011385f2  8bc8                     mov ecx, eax
011385f4  81e100fcff0f             and ecx, 0xffffc00
011385fa  81f900080000             cmp ecx, 0x800
01138600  0f85f1060000             jne 0x1138cf7
01138606  a9ff030000               test eax, 0x3ff
0113860b  0f85e6060000             jne 0x1138cf7
01138611  25000000f0               and eax, 0xf0000000
01138616  3d00000060               cmp eax, 0x60000000
0113861b  0f85d6060000             jne 0x1138cf7
01138621  0faee8                   lfence
01138624  4963c4                   movsxd rax, r12d
01138627  488bcf                   mov rcx, rdi
0113862a  498d1cc6                 lea rbx, [r14 + rax*8]
0113862e  e8dddeecfe               call 0x6510
01138633  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
01138637  66894108                 mov word ptr [rcx + 8], ax
0113863b  488b4370                 mov rax, qword ptr [rbx + 0x70]
0113863f  408830                   mov byte ptr [rax], sil
01138642  e9b5060000               jmp 0x1138cfc
01138647  488b4708                 mov rax, qword ptr [rdi + 8]
0113864b  bd000c0000               mov ebp, 0xc00
01138650  8b4004                   mov eax, dword ptr [rax + 4]
01138653  8bc8                     mov ecx, eax
01138655  81e100fcff0f             and ecx, 0xffffc00
0113865b  3bcd                     cmp ecx, ebp
0113865d  0f8594060000             jne 0x1138cf7
01138663  a9ff030000               test eax, 0x3ff
01138668  0f8589060000             jne 0x1138cf7
0113866e  25000000f0               and eax, 0xf0000000
01138673  3d00000060               cmp eax, 0x60000000
01138678  0f8579060000             jne 0x1138cf7
0113867e  0faee8                   lfence
01138681  4963c4                   movsxd rax, r12d
01138684  488bcf                   mov rcx, rdi
01138687  498d1cc6                 lea rbx, [r14 + rax*8]
0113868b  e880deecfe               call 0x6510
01138690  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
01138694  894108                   mov dword ptr [rcx + 8], eax
01138697  488b4370                 mov rax, qword ptr [rbx + 0x70]
0113869b  408830                   mov byte ptr [rax], sil
0113869e  e959060000               jmp 0x1138cfc
011386a3  488b4708                 mov rax, qword ptr [rdi + 8]
011386a7  8b4004                   mov eax, dword ptr [rax + 4]
011386aa  8bd0                     mov edx, eax
011386ac  81e200fcff0f             and edx, 0xffffc00
011386b2  81fa00100000             cmp edx, 0x1000
011386b8  7517                     jne 0x11386d1
011386ba  a9ff030000               test eax, 0x3ff
011386bf  7510                     jne 0x11386d1
011386c1  8bc8                     mov ecx, eax
011386c3  81e1000000f0             and ecx, 0xf0000000
011386c9  81f900000060             cmp ecx, 0x60000000
011386cf  7427                     je 0x11386f8
011386d1  81fa00200000             cmp edx, 0x2000
011386d7  0f851a060000             jne 0x1138cf7
011386dd  a9ff030000               test eax, 0x3ff
011386e2  0f850f060000             jne 0x1138cf7
011386e8  25000000f0               and eax, 0xf0000000
011386ed  3d00000060               cmp eax, 0x60000000
011386f2  0f85ff050000             jne 0x1138cf7
011386f8  0faee8                   lfence
011386fb  4963c4                   movsxd rax, r12d
011386fe  488bcf                   mov rcx, rdi
01138701  498d1cc6                 lea rbx, [r14 + rax*8]
01138705  e806deecfe               call 0x6510
0113870a  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
0113870e  48894108                 mov qword ptr [rcx + 8], rax
01138712  488b4370                 mov rax, qword ptr [rbx + 0x70]
01138716  408830                   mov byte ptr [rax], sil
01138719  e9de050000               jmp 0x1138cfc
0113871e  488b4708                 mov rax, qword ptr [rdi + 8]
01138722  8b4004                   mov eax, dword ptr [rax + 4]
01138725  8bc8                     mov ecx, eax
01138727  81e100fcff0f             and ecx, 0xffffc00
0113872d  81f900680000             cmp ecx, 0x6800
01138733  0f85be050000             jne 0x1138cf7
01138739  a9ff030000               test eax, 0x3ff
0113873e  0f85b3050000             jne 0x1138cf7
01138744  25000000f0               and eax, 0xf0000000
01138749  3d00000060               cmp eax, 0x60000000
0113874e  0f85a3050000             jne 0x1138cf7
01138754  0faee8                   lfence
01138757  4963c4                   movsxd rax, r12d
0113875a  488bcf                   mov rcx, rdi
0113875d  498d1cc6                 lea rbx, [r14 + rax*8]
01138761  e8aaddecfe               call 0x6510
01138766  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
0113876a  884108                   mov byte ptr [rcx + 8], al
0113876d  488b4370                 mov rax, qword ptr [rbx + 0x70]
01138771  408830                   mov byte ptr [rax], sil
01138774  e983050000               jmp 0x1138cfc
01138779  488b4708                 mov rax, qword ptr [rdi + 8]
0113877d  8b4004                   mov eax, dword ptr [rax + 4]
01138780  8bc8                     mov ecx, eax
01138782  81e100fcff0f             and ecx, 0xffffc00
01138788  81f900300000             cmp ecx, 0x3000
0113878e  0f8563050000             jne 0x1138cf7
01138794  a9ff030000               test eax, 0x3ff
01138799  0f8558050000             jne 0x1138cf7
0113879f  25000000f0               and eax, 0xf0000000
011387a4  3d00000060               cmp eax, 0x60000000
011387a9  0f8548050000             jne 0x1138cf7
011387af  488bcf                   mov rcx, rdi
011387b2  e859ddecfe               call 0x6510
011387b7  4c8d442438               lea r8, [rsp + 0x38]
011387bc  4889442440               mov qword ptr [rsp + 0x40], rax
011387c1  488d542430               lea rdx, [rsp + 0x30]
011387c6  895c2430                 mov dword ptr [rsp + 0x30], ebx
011387ca  488d4c2440               lea rcx, [rsp + 0x40]
011387cf  48895c2438               mov qword ptr [rsp + 0x38], rbx
011387d4  ff155632d900             call qword ptr [rip + 0xd93256]
011387da  817c2430dab93700         cmp dword ptr [rsp + 0x30], 0x37b9da
011387e2  0f870f050000             ja 0x1138cf7
011387e8  48b8ffbf692ac9000000     movabs rax, 0xc92a69bfff
011387f2  4839442438               cmp qword ptr [rsp + 0x38], rax
011387f7  0f87fa040000             ja 0x1138cf7
011387fd  0faee8                   lfence
01138800  498b8e50060000           mov rcx, qword ptr [r14 + 0x650]
01138807  488d0522d12001           lea rax, [rip + 0x120d122]
0113880e  4889442448               mov qword ptr [rsp + 0x48], rax
01138813  418bd4                   mov edx, r12d
01138816  8b442430                 mov eax, dword ptr [rsp + 0x30]
0113881a  89442450                 mov dword ptr [rsp + 0x50], eax
0113881e  488b442438               mov rax, qword ptr [rsp + 0x38]
01138823  4889442458               mov qword ptr [rsp + 0x58], rax
01138828  4963c4                   movsxd rax, r12d
0113882b  c744246007000000         mov dword ptr [rsp + 0x60], 7
01138833  498d1cc6                 lea rbx, [r14 + rax*8]
01138837  488b01                   mov rax, qword ptr [rcx]
0113883a  ff5018                   call qword ptr [rax + 0x18]
0113883d  488b5370                 mov rdx, qword ptr [rbx + 0x70]
01138841  488d4c2448               lea rcx, [rsp + 0x48]
01138846  4c8bc0                   mov r8, rax
01138849  ff15e1d02001             call qword ptr [rip + 0x120d0e1]
0113884f  488b4370                 mov rax, qword ptr [rbx + 0x70]
01138853  408830                   mov byte ptr [rax], sil
01138856  e9a1040000               jmp 0x1138cfc
0113885b  395f28                   cmp dword ptr [rdi + 0x28], ebx
0113885e  0faee8                   lfence
01138861  0f86a4010000             jbe 0x1138a0b
01138867  498b8e50060000           mov rcx, qword ptr [r14 + 0x650]
0113886e  418bd4                   mov edx, r12d
01138871  488b01                   mov rax, qword ptr [rcx]
01138874  ff5018                   call qword ptr [rax + 0x18]
01138877  66396810                 cmp word ptr [rax + 0x10], bp
0113887b  741d                     je 0x113889a
0113887d  0faee8                   lfence
01138880  0fb608                   movzx ecx, byte ptr [rax]
01138883  420fb6942910360202       movzx edx, byte ptr [rcx + r13 + 0x2023610]
0113888c  42389c2a9875ae02         cmp byte ptr [rdx + r13 + 0x2ae7598], bl
01138894  7504                     jne 0x113889a
01138896  0fb76810                 movzx ebp, word ptr [rax + 0x10]
0113889a  0fb7c5                   movzx eax, bp
0113889d  394728                   cmp dword ptr [rdi + 0x28], eax
011388a0  0f8751040000             ja 0x1138cf7
011388a6  399c24e0000000           cmp dword ptr [rsp + 0xe0], ebx
011388ad  0f84c7000000             je 0x113897a
011388b3  4183fc16                 cmp r12d, 0x16
011388b7  0f85bd000000             jne 0x113897a
011388bd  488b4708                 mov rax, qword ptr [rdi + 8]
011388c1  8b4004                   mov eax, dword ptr [rax + 4]
011388c4  8bc8                     mov ecx, eax
011388c6  81e100fcff0f             and ecx, 0xffffc00
011388cc  81f900100000             cmp ecx, 0x1000
011388d2  0f851f040000             jne 0x1138cf7
011388d8  a9ff030000               test eax, 0x3ff
011388dd  0f8514040000             jne 0x1138cf7
011388e3  25000000f0               and eax, 0xf0000000
011388e8  3d00000060               cmp eax, 0x60000000
011388ed  0f8504040000             jne 0x1138cf7
011388f3  0faee8                   lfence
011388f6  488bcf                   mov rcx, rdi
011388f9  e812dcecfe               call 0x6510
011388fe  0f57c0                   xorps xmm0, xmm0
01138901  4c8bc8                   mov r9, rax
01138904  0f11442468               movups xmmword ptr [rsp + 0x68], xmm0
01138909  41ba01000000             mov r10d, 1
0113890f  90                       nop
01138910  8bcb                     mov ecx, ebx
01138912  4d85d1                   test r9, r10
01138915  7426                     je 0x113893d
01138917  48c1e903                 shr rcx, 3
0113891b  488d542477               lea rdx, [rsp + 0x77]
01138920  83e10f                   and ecx, 0xf
01138923  448bc3                   mov r8d, ebx
01138926  482bd1                   sub rdx, rcx
01138929  4183e007                 and r8d, 7
0113892d  0fb602                   movzx eax, byte ptr [rdx]
01138930  440fb3c0                 btr eax, r8d
01138934  0fb6c8                   movzx ecx, al
01138937  440fabc1                 bts ecx, r8d
0113893b  880a                     mov byte ptr [rdx], cl
0113893d  ffc3                     inc ebx
0113893f  49d1c2                   rol r10, 1
01138942  83fb08                   cmp ebx, 8
01138945  72c9                     jb 0x1138910
01138947  4b8b44e670               mov rax, qword ptr [r14 + r12*8 + 0x70]
0113894c  4b8d0ce6                 lea rcx, [r14 + r12*8]
01138950  488b5008                 mov rdx, qword ptr [rax + 8]
01138954  48c7401010000000         mov qword ptr [rax + 0x10], 0x10
0113895c  488d442468               lea rax, [rsp + 0x68]
01138961  483bd0                   cmp rdx, rax
01138964  7408                     je 0x113896e
01138966  0f10442468               movups xmm0, xmmword ptr [rsp + 0x68]
0113896b  0f1102                   movups xmmword ptr [rdx], xmm0
0113896e  488b4170                 mov rax, qword ptr [rcx + 0x70]
01138972  408830                   mov byte ptr [rax], sil
01138975  e982030000               jmp 0x1138cfc
0113897a  488b4708                 mov rax, qword ptr [rdi + 8]
0113897e  8b4004                   mov eax, dword ptr [rax + 4]
01138981  8bd0                     mov edx, eax
01138983  81e200fcff0f             and edx, 0xffffc00
01138989  81fa00580000             cmp edx, 0x5800
0113898f  7517                     jne 0x11389a8
01138991  a9ff030000               test eax, 0x3ff
01138996  7510                     jne 0x11389a8
01138998  8bc8                     mov ecx, eax
0113899a  81e1000000f0             and ecx, 0xf0000000
011389a0  81f900000060             cmp ecx, 0x60000000
011389a6  7427                     je 0x11389cf
011389a8  81fa00540000             cmp edx, 0x5400
011389ae  0f8543030000             jne 0x1138cf7
011389b4  a9ff030000               test eax, 0x3ff
011389b9  0f8538030000             jne 0x1138cf7
011389bf  25000000f0               and eax, 0xf0000000
011389c4  3d00000060               cmp eax, 0x60000000
011389c9  0f8528030000             jne 0x1138cf7
011389cf  0faee8                   lfence
011389d2  488bcf                   mov rcx, rdi
011389d5  e836dbecfe               call 0x6510
011389da  448b4728                 mov r8d, dword ptr [rdi + 0x28]
011389de  4963cc                   movsxd rcx, r12d
011389e1  498d1cce                 lea rbx, [r14 + rcx*8]
011389e5  498b4cce70               mov rcx, qword ptr [r14 + rcx*8 + 0x70]
011389ea  4c894110                 mov qword ptr [rcx + 0x10], r8
011389ee  488b4908                 mov rcx, qword ptr [rcx + 8]
011389f2  483bc8                   cmp rcx, rax
011389f5  7408                     je 0x11389ff
011389f7  488bd0                   mov rdx, rax
011389fa  e8c1a5ecfe               call 0x2fc0
011389ff  488b4370                 mov rax, qword ptr [rbx + 0x70]
01138a03  408830                   mov byte ptr [rax], sil
01138a06  e9f1020000               jmp 0x1138cfc
01138a0b  4b8b4ce670               mov rcx, qword ptr [r14 + r12*8 + 0x70]
01138a10  c60103                   mov byte ptr [rcx], 3
01138a13  e9e4020000               jmp 0x1138cfc
01138a18  488b4708                 mov rax, qword ptr [rdi + 8]
01138a1c  8b4004                   mov eax, dword ptr [rax + 4]
01138a1f  8bc8                     mov ecx, eax
01138a21  81e100fcff0f             and ecx, 0xffffc00
01138a27  4183fc03                 cmp r12d, 3
01138a2b  755d                     jne 0x1138a8a
01138a2d  bd000c0000               mov ebp, 0xc00
01138a32  3bcd                     cmp ecx, ebp
01138a34  0f85bd020000             jne 0x1138cf7
01138a3a  a9ff030000               test eax, 0x3ff
01138a3f  0f85b2020000             jne 0x1138cf7
01138a45  25000000f0               and eax, 0xf0000000
01138a4a  3d00000060               cmp eax, 0x60000000
01138a4f  0f85a2020000             jne 0x1138cf7
01138a55  0faee8                   lfence
01138a58  488bcf                   mov rcx, rdi
01138a5b  e8b0daecfe               call 0x6510
01138a60  498d96a00a0000           lea rdx, [r14 + 0xaa0]
01138a67  8bc8                     mov ecx, eax
01138a69  418d6c2401               lea ebp, [r12 + 1]
01138a6e  e8ade4feff               call 0x1126f20
01138a73  4c8bc8                   mov r9, rax
01138a76  498d4e68                 lea rcx, [r14 + 0x68]
01138a7a  448bc5                   mov r8d, ebp
01138a7d  418bd4                   mov edx, r12d
01138a80  e8eb100000               call 0x1139b70
01138a85  e972020000               jmp 0x1138cfc
01138a8a  4183fc0e                 cmp r12d, 0xe
01138a8e  755d                     jne 0x1138aed
01138a90  81f900080000             cmp ecx, 0x800
01138a96  0f855b020000             jne 0x1138cf7
01138a9c  a9ff030000               test eax, 0x3ff
01138aa1  0f8550020000             jne 0x1138cf7
01138aa7  25000000f0               and eax, 0xf0000000
01138aac  3d00000060               cmp eax, 0x60000000
01138ab1  0f8540020000             jne 0x1138cf7
01138ab7  0faee8                   lfence
01138aba  488bcf                   mov rcx, rdi
01138abd  e84edaecfe               call 0x6510
01138ac2  498d96a50a0000           lea rdx, [r14 + 0xaa5]
01138ac9  0fb7c8                   movzx ecx, ax
01138acc  418d6c24f4               lea ebp, [r12 - 0xc]
01138ad1  e8eae4feff               call 0x1126fc0
01138ad6  4c8bc8                   mov r9, rax
01138ad9  498d4e68                 lea rcx, [r14 + 0x68]
01138add  448bc5                   mov r8d, ebp
01138ae0  418bd4                   mov edx, r12d
01138ae3  e888100000               call 0x1139b70
01138ae8  e90f020000               jmp 0x1138cfc
01138aed  be05400080               mov esi, 0x80004005
01138af2  81f9004c0000             cmp ecx, 0x4c00
01138af8  0f85fe010000             jne 0x1138cfc
01138afe  a9ff030000               test eax, 0x3ff
01138b03  0f85f3010000             jne 0x1138cfc
01138b09  25000000f0               and eax, 0xf0000000
01138b0e  3d00000060               cmp eax, 0x60000000
01138b13  0f85e3010000             jne 0x1138cfc
01138b19  0faee8                   lfence
01138b1c  488bcf                   mov rcx, rdi
01138b1f  e8ecd9ecfe               call 0x6510
01138b24  4c8bc8                   mov r9, rax
01138b27  4885c0                   test rax, rax
01138b2a  7420                     je 0x1138b4c
01138b2c  bd000c0000               mov ebp, 0xc00
01138b31  8bcd                     mov ecx, ebp
01138b33  3818                     cmp byte ptr [rax], bl
01138b35  7409                     je 0x1138b40
01138b37  48ffc0                   inc rax
01138b3a  4883e901                 sub rcx, 1
01138b3e  75f3                     jne 0x1138b33
01138b40  482be9                   sub rbp, rcx
01138b43  4885c9                   test rcx, rcx
01138b46  480f44eb                 cmove rbp, rbx
01138b4a  7503                     jne 0x1138b4f
01138b4c  488beb                   mov rbp, rbx
01138b4f  498d4e68                 lea rcx, [r14 + 0x68]
01138b53  448bc5                   mov r8d, ebp
01138b56  418bd4                   mov edx, r12d
01138b59  e812100000               call 0x1139b70
01138b5e  e999010000               jmp 0x1138cfc
01138b63  488b4708                 mov rax, qword ptr [rdi + 8]
01138b67  8b4004                   mov eax, dword ptr [rax + 4]
01138b6a  8bc8                     mov ecx, eax
01138b6c  81e100fcff0f             and ecx, 0xffffc00
01138b72  81f900500000             cmp ecx, 0x5000
01138b78  0f8579010000             jne 0x1138cf7
01138b7e  a9ff030000               test eax, 0x3ff
01138b83  0f856e010000             jne 0x1138cf7
01138b89  25000000f0               and eax, 0xf0000000
01138b8e  3d00000060               cmp eax, 0x60000000
01138b93  0f855e010000             jne 0x1138cf7
01138b99  488bcf                   mov rcx, rdi
01138b9c  e86fd9ecfe               call 0x6510
01138ba1  4983c668                 add r14, 0x68
01138ba5  0faee8                   lfence
01138ba8  418bd4                   mov edx, r12d
01138bab  4885c0                   test rax, rax
01138bae  7414                     je 0x1138bc4
01138bb0  448b4728                 mov r8d, dword ptr [rdi + 0x28]
01138bb4  4c8bc8                   mov r9, rax
01138bb7  498bce                   mov rcx, r14
01138bba  e8b10f0000               call 0x1139b70
01138bbf  e938010000               jmp 0x1138cfc
01138bc4  498b8ee8050000           mov rcx, qword ptr [r14 + 0x5e8]
01138bcb  488b01                   mov rax, qword ptr [rcx]
01138bce  ff5018                   call qword ptr [rax + 0x18]
01138bd1  66396810                 cmp word ptr [rax + 0x10], bp
01138bd5  7458                     je 0x1138c2f
01138bd7  0faee8                   lfence
01138bda  0fb608                   movzx ecx, byte ptr [rax]
01138bdd  420fb6942910360202       movzx edx, byte ptr [rcx + r13 + 0x2023610]
01138be6  42389c2a9875ae02         cmp byte ptr [rdx + r13 + 0x2ae7598], bl
01138bee  753f                     jne 0x1138c2f
01138bf0  663b5810                 cmp bx, word ptr [rax + 0x10]
01138bf4  7239                     jb 0x1138c2f
01138bf6  0faee8                   lfence
01138bf9  498b8ee8050000           mov rcx, qword ptr [r14 + 0x5e8]
01138c00  418bd4                   mov edx, r12d
01138c03  488b01                   mov rax, qword ptr [rcx]
01138c06  ff5018                   call qword ptr [rax + 0x18]
01138c09  66396810                 cmp word ptr [rax + 0x10], bp
01138c0d  741d                     je 0x1138c2c
01138c0f  0faee8                   lfence
01138c12  0fb608                   movzx ecx, byte ptr [rax]
01138c15  420fb6942910360202       movzx edx, byte ptr [rcx + r13 + 0x2023610]
01138c1e  42389c2a9875ae02         cmp byte ptr [rdx + r13 + 0x2ae7598], bl
01138c26  7504                     jne 0x1138c2c
01138c28  0fb76810                 movzx ebp, word ptr [rax + 0x10]
01138c2c  0fb7dd                   movzx ebx, bp
01138c2f  4963c4                   movsxd rax, r12d
01138c32  488d1547f2f100           lea rdx, [rip + 0xf1f247]
01138c39  498d0cc6                 lea rcx, [r14 + rax*8]
01138c3d  498b44c608               mov rax, qword ptr [r14 + rax*8 + 8]
01138c42  48895008                 mov qword ptr [rax + 8], rdx
01138c46  bafeff0000               mov edx, 0xfffe
01138c4b  488b4108                 mov rax, qword ptr [rcx + 8]
01138c4f  66215002                 and word ptr [rax + 2], dx
01138c53  488b4108                 mov rax, qword ptr [rcx + 8]
01138c57  48895810                 mov qword ptr [rax + 0x10], rbx
01138c5b  488b4108                 mov rax, qword ptr [rcx + 8]
01138c5f  408830                   mov byte ptr [rax], sil
01138c62  e995000000               jmp 0x1138cfc
01138c67  488b4708                 mov rax, qword ptr [rdi + 8]
01138c6b  8b4004                   mov eax, dword ptr [rax + 4]
01138c6e  8bc8                     mov ecx, eax
01138c70  81e100fcff0f             and ecx, 0xffffc00
01138c76  81f900540000             cmp ecx, 0x5400
01138c7c  7579                     jne 0x1138cf7
01138c7e  a9ff030000               test eax, 0x3ff
01138c83  7572                     jne 0x1138cf7
01138c85  25000000f0               and eax, 0xf0000000
01138c8a  3d00000060               cmp eax, 0x60000000
01138c8f  7566                     jne 0x1138cf7
01138c91  0faee8                   lfence
01138c94  488bcf                   mov rcx, rdi
01138c97  e874d8ecfe               call 0x6510
01138c9c  4885c0                   test rax, rax
01138c9f  488d0d82d9ed00           lea rcx, [rip + 0xedd982]
01138ca6  4b8d14e6                 lea rdx, [r14 + r12*8]
01138caa  480f44c1                 cmove rax, rcx
01138cae  488b4a70                 mov rcx, qword ptr [rdx + 0x70]
01138cb2  0f1000                   movups xmm0, xmmword ptr [rax]
01138cb5  0f114108                 movups xmmword ptr [rcx + 8], xmm0
01138cb9  488b4270                 mov rax, qword ptr [rdx + 0x70]
01138cbd  8818                     mov byte ptr [rax], bl
01138cbf  eb3b                     jmp 0x1138cfc
01138cc1  0faee8                   lfence
01138cc4  488d0595fd0101           lea rax, [rip + 0x101fd95]
01138ccb  41b9c7090000             mov r9d, 0x9c7
01138cd1  4c8d0588c03d01           lea r8, [rip + 0x13dc088]
01138cd8  4889442420               mov qword ptr [rsp + 0x20], rax
01138cdd  488d153cdb3d01           lea rdx, [rip + 0x13ddb3c]
01138ce4  b901000000               mov ecx, 1
01138ce9  ff158921d900             call qword ptr [rip + 0xd92189]
01138cef  4b8b4ce670               mov rcx, qword ptr [r14 + r12*8 + 0x70]
01138cf4  c60103                   mov byte ptr [rcx], 3
01138cf7  be05400080               mov esi, 0x80004005
01138cfc  488b9c24c8000000         mov rbx, qword ptr [rsp + 0xc8]

; chunk at RVA 0x1138d04 (272 bytes)
01138d04  8bc6                     mov eax, esi
01138d06  488b4c2478               mov rcx, qword ptr [rsp + 0x78]
01138d0b  4833cc                   xor rcx, rsp
01138d0e  e85d83ecfe               call 0x1070
01138d13  4881c480000000           add rsp, 0x80
01138d1a  415f                     pop r15
01138d1c  415e                     pop r14
01138d1e  415d                     pop r13
01138d20  415c                     pop r12
01138d22  5f                       pop rdi
01138d23  5e                       pop rsi
01138d24  5d                       pop rbp
01138d25  c3                       ret
01138d26  90                       nop
01138d27  90                       nop
01138d28  678c13                   mov word ptr [ebx], ss
01138d2b  017987                   add dword ptr [rcx - 0x79], edi
01138d2e  1301                     adc eax, dword ptr [rcx]
01138d30  eb85                     jmp 0x1138cb7
01138d32  1301                     adc eax, dword ptr [rcx]
01138d34  478613                   xchg byte ptr [r11], r10b
01138d37  011e                     add dword ptr [rsi], ebx
01138d39  8713                     xchg dword ptr [rbx], edx
01138d3b  01a38613015b             add dword ptr [rbx + 0x5b011386], esp
01138d41  8813                     mov byte ptr [rbx], dl
01138d43  0118                     add dword ptr [rax], ebx
01138d45  8a13                     mov dl, byte ptr [rbx]
01138d47  01638b                   add dword ptr [rbx - 0x75], esp
01138d4a  1301                     adc eax, dword ptr [rcx]
01138d4c  c18c130100090909         ror dword ptr [rbx + rdx + 0x9090001], 9
01138d54  0909                     or dword ptr [rcx], ecx
01138d56  0109                     add dword ptr [rcx], ecx
01138d58  0909                     or dword ptr [rcx], ecx
01138d5a  0909                     or dword ptr [rcx], ecx
01138d5c  0909                     or dword ptr [rcx], ecx
01138d5e  0909                     or dword ptr [rcx], ecx
01138d60  0209                     add cl, byte ptr [rcx]
01138d62  0909                     or dword ptr [rcx], ecx
01138d64  0309                     add ecx, dword ptr [rcx]
01138d66  0909                     or dword ptr [rcx], ecx
01138d68  0909                     or dword ptr [rcx], ecx
01138d6a  0909                     or dword ptr [rcx], ecx
01138d6c  0909                     or dword ptr [rcx], ecx
01138d6e  0909                     or dword ptr [rcx], ecx
01138d70  0909                     or dword ptr [rcx], ecx
01138d72  0909                     or dword ptr [rcx], ecx
01138d74  0909                     or dword ptr [rcx], ecx
01138d76  0909                     or dword ptr [rcx], ecx
01138d78  0909                     or dword ptr [rcx], ecx
01138d7a  0909                     or dword ptr [rcx], ecx
01138d7c  0909                     or dword ptr [rcx], ecx
01138d7e  0909                     or dword ptr [rcx], ecx
01138d80  0909                     or dword ptr [rcx], ecx
01138d82  0909                     or dword ptr [rcx], ecx
01138d84  0909                     or dword ptr [rcx], ecx
01138d86  0909                     or dword ptr [rcx], ecx
01138d88  0909                     or dword ptr [rcx], ecx
01138d8a  0909                     or dword ptr [rcx], ecx
01138d8c  0909                     or dword ptr [rcx], ecx
01138d8e  0909                     or dword ptr [rcx], ecx
01138d90  0909                     or dword ptr [rcx], ecx
01138d92  0909                     or dword ptr [rcx], ecx
01138d94  0409                     add al, 9
01138d96  0909                     or dword ptr [rcx], ecx
01138d98  0909                     or dword ptr [rcx], ecx
01138d9a  0909                     or dword ptr [rcx], ecx
01138d9c  0909                     or dword ptr [rcx], ecx
01138d9e  0909                     or dword ptr [rcx], ecx
01138da0  0909                     or dword ptr [rcx], ecx
01138da2  0909                     or dword ptr [rcx], ecx
01138da4  0909                     or dword ptr [rcx], ecx
01138da6  0909                     or dword ptr [rcx], ecx
01138da8  0909                     or dword ptr [rcx], ecx
01138daa  090509090909             or dword ptr [rip + 0x9090909], eax
01138db0  0909                     or dword ptr [rcx], ecx
01138db2  0909                     or dword ptr [rcx], ecx
01138db4  0909                     or dword ptr [rcx], ecx
01138db6  0909                     or dword ptr [rcx], ecx
01138db8  0909                     or dword ptr [rcx], ecx
01138dba  0909                     or dword ptr [rcx], ecx
01138dbc  0909                     or dword ptr [rcx], ecx
01138dbe  0909                     or dword ptr [rcx], ecx
01138dc0  0909                     or dword ptr [rcx], ecx
01138dc2  0909                     or dword ptr [rcx], ecx
01138dc4  0909                     or dword ptr [rcx], ecx
01138dc6  0909                     or dword ptr [rcx], ecx
01138dc8  0909                     or dword ptr [rcx], ecx
01138dca  0909                     or dword ptr [rcx], ecx
01138dcc  0909                     or dword ptr [rcx], ecx
01138dce  0909                     or dword ptr [rcx], ecx
01138dd0  0906                     or dword ptr [rsi], eax
01138dd2  0907                     or dword ptr [rdi], eax
01138dd4  0909                     or dword ptr [rcx], ecx
01138dd6  0909                     or dword ptr [rcx], ecx
01138dd8  0909                     or dword ptr [rcx], ecx
01138dda  0909                     or dword ptr [rcx], ecx
01138ddc  0909                     or dword ptr [rcx], ecx
01138dde  0909                     or dword ptr [rcx], ecx
01138de0  0909                     or dword ptr [rcx], ecx
01138de2  0909                     or dword ptr [rcx], ecx
01138de4  0909                     or dword ptr [rcx], ecx
01138de6  0909                     or dword ptr [rcx], ecx
01138de8  0909                     or dword ptr [rcx], ecx
01138dea  0909                     or dword ptr [rcx], ecx
01138dec  0909                     or dword ptr [rcx], ecx
01138dee  0909                     or dword ptr [rcx], ecx
01138df0  0909                     or dword ptr [rcx], ecx
01138df2  0909                     or dword ptr [rcx], ecx
01138df4  0909                     or dword ptr [rcx], ecx
01138df6  0909                     or dword ptr [rcx], ecx
01138df8  0909                     or dword ptr [rcx], ecx
01138dfa  0909                     or dword ptr [rcx], ecx
01138dfc  0909                     or dword ptr [rcx], ecx
01138dfe  0909                     or dword ptr [rcx], ecx
01138e00  0909                     or dword ptr [rcx], ecx
01138e02  0909                     or dword ptr [rcx], ecx
01138e04  0909                     or dword ptr [rcx], ecx
01138e06  0909                     or dword ptr [rcx], ecx
01138e08  0909                     or dword ptr [rcx], ecx
01138e0a  0909                     or dword ptr [rcx], ecx
01138e0c  0909                     or dword ptr [rcx], ecx
01138e0e  0909                     or dword ptr [rcx], ecx
01138e10  0909                     or dword ptr [rcx], ecx
01138e12  0908                     or dword ptr [rax], ecx
