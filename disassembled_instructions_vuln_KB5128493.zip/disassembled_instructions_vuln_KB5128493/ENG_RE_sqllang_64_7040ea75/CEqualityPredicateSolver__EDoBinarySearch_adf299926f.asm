; CEqualityPredicateSolver::EDoBinarySearch
; sqllang.dll, primary RVA 0x267610, 551 bytes in 1 chunk(s)

; chunk at RVA 0x267610 (551 bytes)
00267610  4053                     push rbx
00267612  55                       push rbp
00267613  56                       push rsi
00267614  57                       push rdi
00267615  4154                     push r12
00267617  4155                     push r13
00267619  4156                     push r14
0026761b  4157                     push r15
0026761d  4883ec48                 sub rsp, 0x48
00267621  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
0026762a  448bf2                   mov r14d, edx
0026762d  488bf9                   mov rdi, rcx
00267630  488b4920                 mov rcx, qword ptr [rcx + 0x20]
00267634  488b01                   mov rax, qword ptr [rcx]
00267637  ff5010                   call qword ptr [rax + 0x10]
0026763a  48898424a8000000         mov qword ptr [rsp + 0xa8], rax
00267642  4c8b4f08                 mov r9, qword ptr [rdi + 8]
00267646  4d8b4128                 mov r8, qword ptr [r9 + 0x28]
0026764a  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0026764e  41bd04000000             mov r13d, 4
00267654  458d7dfd                 lea r15d, [r13 - 3]
00267658  4d85c0                   test r8, r8
0026765b  0f84a0806701             je 0x18df701
00267661  418b401c                 mov eax, dword ptr [r8 + 0x1c]
00267665  8d68ff                   lea ebp, [rax - 1]
00267668  448be5                   mov r12d, ebp
0026766b  f6410801                 test byte ptr [rcx + 8], 1
0026766f  450f45ef                 cmovne r13d, r15d
00267673  4489ac2498000000         mov dword ptr [rsp + 0x98], r13d
0026767b  85c0                     test eax, eax
0026767d  0f84a4806701             je 0x18df727
00267683  3be8                     cmp ebp, eax
00267685  0f83aa806701             jae 0x18df735
0026768b  0faee8                   lfence
0026768e  498b4028                 mov rax, qword ptr [r8 + 0x28]
00267692  488b14e8                 mov rdx, qword ptr [rax + rbp*8]
00267696  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0026769a  eb01                     jmp 0x26769d
0026769c  cc                       int3
0026769d  4c8b4228                 mov r8, qword ptr [rdx + 0x28]
002676a1  488b01                   mov rax, qword ptr [rcx]
002676a4  488b17                   mov rdx, qword ptr [rdi]
002676a7  ff5008                   call qword ptr [rax + 8]
002676aa  488bd8                   mov rbx, rax
002676ad  48898424a0000000         mov qword ptr [rsp + 0xa0], rax
002676b5  4885c0                   test rax, rax
002676b8  0f84d4806701             je 0x18df792
002676be  488b7718                 mov rsi, qword ptr [rdi + 0x18]
002676c2  4c8bc8                   mov r9, rax
002676c5  4c8b8424a8000000         mov r8, qword ptr [rsp + 0xa8]
002676cd  488b5710                 mov rdx, qword ptr [rdi + 0x10]
002676d1  488bce                   mov rcx, rsi
002676d4  ff153645c601             call qword ptr [rip + 0x1c64536]
002676da  83f802                   cmp eax, 2
002676dd  756e                     jne 0x26774d
002676df  8b4624                   mov eax, dword ptr [rsi + 0x24]
002676e2  3b4324                   cmp eax, dword ptr [rbx + 0x24]
002676e5  7c60                     jl 0x267747
002676e7  0f8f50806701             jg 0x18df73d
002676ed  c6472801                 mov byte ptr [rdi + 0x28], 1
002676f1  eb01                     jmp 0x2676f4
002676f3  cc                       int3
002676f4  8d4501                   lea eax, [rbp + 1]
002676f7  894738                   mov dword ptr [rdi + 0x38], eax
002676fa  418d442401               lea eax, [r12 + 1]
002676ff  89473c                   mov dword ptr [rdi + 0x3c], eax
00267702  488d4730                 lea rax, [rdi + 0x30]
00267706  807f2800                 cmp byte ptr [rdi + 0x28], 0
0026770a  0f8492230000             je 0x269aa2
00267710  f20f1005c8bf8d02         movsd xmm0, qword ptr [rip + 0x28dbfc8]
00267718  f20f1100                 movsd qword ptr [rax], xmm0
0026771c  eb01                     jmp 0x26771f
0026771e  cc                       int3
0026771f  33ff                     xor edi, edi
00267721  448bff                   mov r15d, edi
00267724  4885db                   test rbx, rbx
00267727  740a                     je 0x267733
00267729  834320ff                 add dword ptr [rbx + 0x20], -1
0026772d  0f846d806701             je 0x18df7a0
00267733  418bc7                   mov eax, r15d
00267736  4883c448                 add rsp, 0x48
0026773a  415f                     pop r15
0026773c  415e                     pop r14
0026773e  415d                     pop r13
00267740  415c                     pop r12
00267742  5f                       pop rdi
00267743  5e                       pop rsi
00267744  5d                       pop rbp
00267745  5b                       pop rbx
00267746  c3                       ret
00267747  418bc7                   mov eax, r15d
0026774a  eb01                     jmp 0x26774d
0026774c  cc                       int3
0026774d  413bc5                   cmp eax, r13d
00267750  0f8542806701             jne 0x18df798
00267756  418bee                   mov ebp, r14d
00267759  453bf4                   cmp r14d, r12d
0026775c  7396                     jae 0x2676f4
0026775e  0f1f00                   nop dword ptr [rax]
00267761  0f1f4000                 nop dword ptr [rax]
00267765  6666660f1f840000000000   nop word ptr [rax + rax]
00267770  418d342c                 lea esi, [r12 + rbp]
00267774  d1ee                     shr esi, 1
00267776  8d4601                   lea eax, [rsi + 1]
00267779  89842490000000           mov dword ptr [rsp + 0x90], eax
00267780  488b4708                 mov rax, qword ptr [rdi + 8]
00267784  488b4028                 mov rax, qword ptr [rax + 0x28]
00267788  4533ed                   xor r13d, r13d
0026778b  3b701c                   cmp esi, dword ptr [rax + 0x1c]
0026778e  0f83b47f6701             jae 0x18df748
00267794  0faee8                   lfence
00267797  488b4028                 mov rax, qword ptr [rax + 0x28]
0026779b  4c8b04f0                 mov r8, qword ptr [rax + rsi*8]
0026779f  488b9c24a0000000         mov rbx, qword ptr [rsp + 0xa0]
002677a7  eb01                     jmp 0x2677aa
002677a9  cc                       int3
002677aa  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
002677ae  488b01                   mov rax, qword ptr [rcx]
002677b1  4d8b4028                 mov r8, qword ptr [r8 + 0x28]
002677b5  488b17                   mov rdx, qword ptr [rdi]
002677b8  ff5008                   call qword ptr [rax + 8]
002677bb  4c8bf0                   mov r14, rax
002677be  4885db                   test rbx, rbx
002677c1  740a                     je 0x2677cd
002677c3  834320ff                 add dword ptr [rbx + 0x20], -1
002677c7  0f84847f6701             je 0x18df751
002677cd  498bde                   mov rbx, r14
002677d0  48899c24a0000000         mov qword ptr [rsp + 0xa0], rbx
002677d8  4d85f6                   test r14, r14
002677db  0f84b17f6701             je 0x18df792
002677e1  4c8b6f18                 mov r13, qword ptr [rdi + 0x18]
002677e5  4d8bce                   mov r9, r14
002677e8  4c8b8424a8000000         mov r8, qword ptr [rsp + 0xa8]
002677f0  488b5710                 mov rdx, qword ptr [rdi + 0x10]
002677f4  498bcd                   mov rcx, r13
002677f7  ff151344c601             call qword ptr [rip + 0x1c64413]
002677fd  83f802                   cmp eax, 2
00267800  0f84a41a0000             je 0x2692aa
00267806  3b842498000000           cmp eax, dword ptr [rsp + 0x98]
0026780d  7515                     jne 0x267824
0026780f  448be6                   mov r12d, esi
00267812  eb01                     jmp 0x267815
00267814  cc                       int3
00267815  413bec                   cmp ebp, r12d
00267818  0f8252ffffff             jb 0x267770
0026781e  e9d1feffff               jmp 0x2676f4
00267823  cc                       int3
00267824  83f802                   cmp eax, 2
00267827  0f84991a0000             je 0x2692c6
0026782d  8bac2490000000           mov ebp, dword ptr [rsp + 0x90]
00267834  ebdf                     jmp 0x267815
00267836  cc                       int3
