; CExecLvlIntCtxt::PushLvl
; sqllang.dll, primary RVA 0xdd78a0, 202 bytes in 1 chunk(s)

; chunk at RVA 0xdd78a0 (202 bytes)
00dd78a0  4057                     push rdi
00dd78a2  4883ec40                 sub rsp, 0x40
00dd78a6  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
00dd78af  48895c2468               mov qword ptr [rsp + 0x68], rbx
00dd78b4  488bd9                   mov rbx, rcx
00dd78b7  c744245084040000         mov dword ptr [rsp + 0x50], 0x484
00dd78bf  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00dd78c8  488b05a9360f01           mov rax, qword ptr [rip + 0x10f36a9]
00dd78cf  8b10                     mov edx, dword ptr [rax]
00dd78d1  488b05a8360f01           mov rax, qword ptr [rip + 0x10f36a8]
00dd78d8  8b38                     mov edi, dword ptr [rax]
00dd78da  49033cd0                 add rdi, qword ptr [r8 + rdx*8]
00dd78de  488b9700010000           mov rdx, qword ptr [rdi + 0x100]
00dd78e5  4885d2                   test rdx, rdx
00dd78e8  750f                     jne 0xdd78f9
00dd78ea  33c9                     xor ecx, ecx
00dd78ec  ff159e360f01             call qword ptr [rip + 0x10f369e]
00dd78f2  488b9700010000           mov rdx, qword ptr [rdi + 0x100]
00dd78f9  488b92e8030000           mov rdx, qword ptr [rdx + 0x3e8]
00dd7900  4889542458               mov qword ptr [rsp + 0x58], rdx
00dd7905  c644242003               mov byte ptr [rsp + 0x20], 3
00dd790a  41b984040000             mov r9d, 0x484
00dd7910  4c8d0541f32301           lea r8, [rip + 0x123f341]
00dd7917  b930000000               mov ecx, 0x30
00dd791c  ff158e350f01             call qword ptr [rip + 0x10f358e]
00dd7922  4889442460               mov qword ptr [rsp + 0x60], rax
00dd7927  4885c0                   test rax, rax
00dd792a  742a                     je 0xdd7956
00dd792c  488b8bf0010000           mov rcx, qword ptr [rbx + 0x1f0]
00dd7933  0f57c0                   xorps xmm0, xmm0
00dd7936  0f1100                   movups xmmword ptr [rax], xmm0
00dd7939  0f114010                 movups xmmword ptr [rax + 0x10], xmm0
00dd793d  0f114020                 movups xmmword ptr [rax + 0x20], xmm0
00dd7941  488908                   mov qword ptr [rax], rcx
00dd7944  488983f0010000           mov qword ptr [rbx + 0x1f0], rax
00dd794b  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
00dd7950  4883c440                 add rsp, 0x40
00dd7954  5f                       pop rdi
00dd7955  c3                       ret
00dd7956  33d2                     xor edx, edx
00dd7958  488993f0010000           mov qword ptr [rbx + 0x1f0], rdx
00dd795f  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
00dd7964  4883c440                 add rsp, 0x40
00dd7968  5f                       pop rdi
00dd7969  c3                       ret
