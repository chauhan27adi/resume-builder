; CControlFlowGraph::GetResultsForStmt
; sqllang.dll, primary RVA 0xdffac0, 810 bytes in 5 chunk(s)

; chunk at RVA 0xdffac0 (382 bytes)
00dffac0  48896c2420               mov qword ptr [rsp + 0x20], rbp
00dffac5  56                       push rsi
00dffac6  4156                     push r14
00dffac8  4157                     push r15
00dffaca  4883ec50                 sub rsp, 0x50
00dfface  4c8bf9                   mov r15, rcx
00dffad1  498bf1                   mov rsi, r9
00dffad4  488bca                   mov rcx, rdx
00dffad7  4d8bf0                   mov r14, r8
00dffada  488bea                   mov rbp, rdx
00dffadd  e8eeecffff               call 0xdfe7d0
00dffae2  a801                     test al, 1
00dffae4  0f8488000000             je 0xdffb72
00dffaea  8b4548                   mov eax, dword ptr [rbp + 0x48]
00dffaed  3d76010000               cmp eax, 0x176
00dffaf2  7f5c                     jg 0xdffb50
00dffaf4  7427                     je 0xdffb1d
00dffaf6  83e829                   sub eax, 0x29
00dffaf9  3dd1000000               cmp eax, 0xd1
00dffafe  7750                     ja 0xdffb50
00dffb00  488d15f90420ff           lea rdx, [rip - 0xdffb07]
00dffb07  4898                     cdqe
00dffb09  0fb6840218fddf00         movzx eax, byte ptr [rdx + rax + 0xdffd18]
00dffb11  8b8c8210fddf00           mov ecx, dword ptr [rdx + rax*4 + 0xdffd10]
00dffb18  4803ca                   add rcx, rdx
00dffb1b  ffe1                     jmp rcx
00dffb1d  488bce                   mov rcx, rsi
00dffb20  e86bcaffff               call 0xdfc590
00dffb25  804e3202                 or byte ptr [rsi + 0x32], 2
00dffb29  488d4e48                 lea rcx, [rsi + 0x48]
00dffb2d  4d8bc6                   mov r8, r14
00dffb30  c7465808000000           mov dword ptr [rsi + 0x58], 8
00dffb37  488bd5                   mov rdx, rbp
00dffb3a  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dffb42  4883c450                 add rsp, 0x50
00dffb46  415f                     pop r15
00dffb48  415e                     pop r14
00dffb4a  5e                       pop rsi
00dffb4b  e910bfffff               jmp 0xdfba60
00dffb50  4c8bce                   mov r9, rsi
00dffb53  4d8bc6                   mov r8, r14
00dffb56  488bd5                   mov rdx, rbp
00dffb59  498bcf                   mov rcx, r15
00dffb5c  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dffb64  4883c450                 add rsp, 0x50
00dffb68  415f                     pop r15
00dffb6a  415e                     pop r14
00dffb6c  5e                       pop rsi
00dffb6d  e91eeeffff               jmp 0xdfe990
00dffb72  a802                     test al, 2
00dffb74  0f847c010000             je 0xdffcf6
00dffb7a  8b4548                   mov eax, dword ptr [rbp + 0x48]
00dffb7d  83f821                   cmp eax, 0x21
00dffb80  0f8455010000             je 0xdffcdb
00dffb86  3de0000000               cmp eax, 0xe0
00dffb8b  0f849e000000             je 0xdffc2f
00dffb91  3d75010000               cmp eax, 0x175
00dffb96  7460                     je 0xdffbf8
00dffb98  488bcd                   mov rcx, rbp
00dffb9b  e8e0b7f3ff               call 0xd3b380
00dffba0  84c0                     test al, al
00dffba2  7422                     je 0xdffbc6
00dffba4  4c8bce                   mov r9, rsi
00dffba7  4d8bc6                   mov r8, r14
00dffbaa  488bd5                   mov rdx, rbp
00dffbad  498bcf                   mov rcx, r15
00dffbb0  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dffbb8  4883c450                 add rsp, 0x50
00dffbbc  415f                     pop r15
00dffbbe  415e                     pop r14
00dffbc0  5e                       pop rsi
00dffbc1  e95af2ffff               jmp 0xdfee20
00dffbc6  488bcd                   mov rcx, rbp
00dffbc9  e892e943ff               call 0x23e560
00dffbce  84c0                     test al, al
00dffbd0  0f8420010000             je 0xdffcf6
00dffbd6  4c8bce                   mov r9, rsi
00dffbd9  4d8bc6                   mov r8, r14
00dffbdc  488bd5                   mov rdx, rbp
00dffbdf  498bcf                   mov rcx, r15
00dffbe2  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dffbea  4883c450                 add rsp, 0x50
00dffbee  415f                     pop r15
00dffbf0  415e                     pop r14
00dffbf2  5e                       pop rsi
00dffbf3  e9a8f7ffff               jmp 0xdff3a0
00dffbf8  488b4518                 mov rax, qword ptr [rbp + 0x18]
00dffbfc  83b8b008000001           cmp dword ptr [rax + 0x8b0], 1
00dffc03  0f84ed000000             je 0xdffcf6
00dffc09  488b80a0080000           mov rax, qword ptr [rax + 0x8a0]
00dffc10  488b4820                 mov rcx, qword ptr [rax + 0x20]
00dffc14  488b01                   mov rax, qword ptr [rcx]
00dffc17  488b4810                 mov rcx, qword ptr [rax + 0x10]
00dffc1b  488b01                   mov rax, qword ptr [rcx]
00dffc1e  ff5018                   call qword ptr [rax + 0x18]
00dffc21  83f862                   cmp eax, 0x62
00dffc24  0f84cc000000             je 0xdffcf6
00dffc2a  e9eefeffff               jmp 0xdffb1d
00dffc2f  498b0f                   mov rcx, qword ptr [r15]
00dffc32  33c0                     xor eax, eax
00dffc34  4889442440               mov qword ptr [rsp + 0x40], rax
00dffc39  6689442448               mov word ptr [rsp + 0x48], ax

; chunk at RVA 0xdffc3e (28 bytes)
00dffc3e  4c89a42480000000         mov qword ptr [rsp + 0x80], r12
00dffc46  8b4120                   mov eax, dword ptr [rcx + 0x20]
00dffc49  4c8b6518                 mov r12, qword ptr [rbp + 0x18]
00dffc4d  c1e803                   shr eax, 3
00dffc50  a801                     test al, 1
00dffc52  743d                     je 0xdffc91
00dffc54  488b01                   mov rax, qword ptr [rcx]
00dffc57  498bd6                   mov rdx, r14

; chunk at RVA 0xdffc5a (55 bytes)
00dffc5a  48895c2470               mov qword ptr [rsp + 0x70], rbx
00dffc5f  8b99dc040000             mov ebx, dword ptr [rcx + 0x4dc]
00dffc65  48897c2478               mov qword ptr [rsp + 0x78], rdi
00dffc6a  0fb7b9e8040000           movzx edi, word ptr [rcx + 0x4e8]
00dffc71  ff9070010000             call qword ptr [rax + 0x170]
00dffc77  0fb7c0                   movzx eax, ax
00dffc7a  895c2444                 mov dword ptr [rsp + 0x44], ebx
00dffc7e  488b5c2470               mov rbx, qword ptr [rsp + 0x70]
00dffc83  66897c2448               mov word ptr [rsp + 0x48], di
00dffc88  488b7c2478               mov rdi, qword ptr [rsp + 0x78]
00dffc8d  89442440                 mov dword ptr [rsp + 0x40], eax

; chunk at RVA 0xdffc91 (62 bytes)
00dffc91  4d8b1424                 mov r10, qword ptr [r12]
00dffc95  488d442440               lea rax, [rsp + 0x40]
00dffc9a  4d8b4708                 mov r8, qword ptr [r15 + 8]
00dffc9e  4d8bce                   mov r9, r14
00dffca1  4889742430               mov qword ptr [rsp + 0x30], rsi
00dffca6  488bd5                   mov rdx, rbp
00dffca9  4889442428               mov qword ptr [rsp + 0x28], rax
00dffcae  498bcc                   mov rcx, r12
00dffcb1  498b4718                 mov rax, qword ptr [r15 + 0x18]
00dffcb5  4889442420               mov qword ptr [rsp + 0x20], rax
00dffcba  41ff9248020000           call qword ptr [r10 + 0x248]
00dffcc1  f6463208                 test byte ptr [rsi + 0x32], 8
00dffcc5  4c8ba42480000000         mov r12, qword ptr [rsp + 0x80]
00dffccd  742f                     je 0xdffcfe

; chunk at RVA 0xdffccf (283 bytes)
00dffccf  41f687b001000008         test byte ptr [r15 + 0x1b0], 8
00dffcd7  7425                     je 0xdffcfe
00dffcd9  eb1b                     jmp 0xdffcf6
00dffcdb  488b4518                 mov rax, qword ptr [rbp + 0x18]
00dffcdf  4883b8d808000000         cmp qword ptr [rax + 0x8d8], 0
00dffce7  750d                     jne 0xdffcf6
00dffce9  83b8e008000000           cmp dword ptr [rax + 0x8e0], 0
00dffcf0  0f8627feffff             jbe 0xdffb1d
00dffcf6  488bce                   mov rcx, rsi
00dffcf9  e892c8ffff               call 0xdfc590
00dffcfe  488bac2488000000         mov rbp, qword ptr [rsp + 0x88]
00dffd06  4883c450                 add rsp, 0x50
00dffd0a  415f                     pop r15
00dffd0c  415e                     pop r14
00dffd0e  5e                       pop rsi
00dffd0f  c3                       ret
00dffd10  1dfbdf0050               sbb eax, 0x5000dffb
00dffd15  fb                       sti
00dffd16  df00                     fild word ptr [rax]
00dffd18  0001                     add byte ptr [rcx], al
00dffd1a  0101                     add dword ptr [rcx], eax
00dffd1c  0101                     add dword ptr [rcx], eax
00dffd1e  0101                     add dword ptr [rcx], eax
00dffd20  0101                     add dword ptr [rcx], eax
00dffd22  0101                     add dword ptr [rcx], eax
00dffd24  0101                     add dword ptr [rcx], eax
00dffd26  0101                     add dword ptr [rcx], eax
00dffd28  0101                     add dword ptr [rcx], eax
00dffd2a  0101                     add dword ptr [rcx], eax
00dffd2c  0101                     add dword ptr [rcx], eax
00dffd2e  0101                     add dword ptr [rcx], eax
00dffd30  0101                     add dword ptr [rcx], eax
00dffd32  0101                     add dword ptr [rcx], eax
00dffd34  0101                     add dword ptr [rcx], eax
00dffd36  0101                     add dword ptr [rcx], eax
00dffd38  0101                     add dword ptr [rcx], eax
00dffd3a  0101                     add dword ptr [rcx], eax
00dffd3c  0101                     add dword ptr [rcx], eax
00dffd3e  0101                     add dword ptr [rcx], eax
00dffd40  0101                     add dword ptr [rcx], eax
00dffd42  0101                     add dword ptr [rcx], eax
00dffd44  0101                     add dword ptr [rcx], eax
00dffd46  0101                     add dword ptr [rcx], eax
00dffd48  0101                     add dword ptr [rcx], eax
00dffd4a  0101                     add dword ptr [rcx], eax
00dffd4c  0101                     add dword ptr [rcx], eax
00dffd4e  0101                     add dword ptr [rcx], eax
00dffd50  0101                     add dword ptr [rcx], eax
00dffd52  0101                     add dword ptr [rcx], eax
00dffd54  0101                     add dword ptr [rcx], eax
00dffd56  0101                     add dword ptr [rcx], eax
00dffd58  0101                     add dword ptr [rcx], eax
00dffd5a  0101                     add dword ptr [rcx], eax
00dffd5c  0101                     add dword ptr [rcx], eax
00dffd5e  0101                     add dword ptr [rcx], eax
00dffd60  0101                     add dword ptr [rcx], eax
00dffd62  0101                     add dword ptr [rcx], eax
00dffd64  0101                     add dword ptr [rcx], eax
00dffd66  0001                     add byte ptr [rcx], al
00dffd68  0101                     add dword ptr [rcx], eax
00dffd6a  0101                     add dword ptr [rcx], eax
00dffd6c  0101                     add dword ptr [rcx], eax
00dffd6e  0101                     add dword ptr [rcx], eax
00dffd70  0101                     add dword ptr [rcx], eax
00dffd72  0101                     add dword ptr [rcx], eax
00dffd74  0101                     add dword ptr [rcx], eax
00dffd76  0101                     add dword ptr [rcx], eax
00dffd78  0101                     add dword ptr [rcx], eax
00dffd7a  0101                     add dword ptr [rcx], eax
00dffd7c  0101                     add dword ptr [rcx], eax
00dffd7e  0101                     add dword ptr [rcx], eax
00dffd80  0101                     add dword ptr [rcx], eax
00dffd82  0101                     add dword ptr [rcx], eax
00dffd84  0101                     add dword ptr [rcx], eax
00dffd86  0101                     add dword ptr [rcx], eax
00dffd88  0101                     add dword ptr [rcx], eax
00dffd8a  0101                     add dword ptr [rcx], eax
00dffd8c  0101                     add dword ptr [rcx], eax
00dffd8e  0101                     add dword ptr [rcx], eax
00dffd90  0101                     add dword ptr [rcx], eax
00dffd92  0101                     add dword ptr [rcx], eax
00dffd94  0101                     add dword ptr [rcx], eax
00dffd96  0101                     add dword ptr [rcx], eax
00dffd98  0101                     add dword ptr [rcx], eax
00dffd9a  0101                     add dword ptr [rcx], eax
00dffd9c  0101                     add dword ptr [rcx], eax
00dffd9e  0101                     add dword ptr [rcx], eax
00dffda0  0001                     add byte ptr [rcx], al
00dffda2  0101                     add dword ptr [rcx], eax
00dffda4  0101                     add dword ptr [rcx], eax
00dffda6  0101                     add dword ptr [rcx], eax
00dffda8  0000                     add byte ptr [rax], al
00dffdaa  0000                     add byte ptr [rax], al
00dffdac  0101                     add dword ptr [rcx], eax
00dffdae  0101                     add dword ptr [rcx], eax
00dffdb0  0101                     add dword ptr [rcx], eax
00dffdb2  0101                     add dword ptr [rcx], eax
00dffdb4  0101                     add dword ptr [rcx], eax
00dffdb6  0101                     add dword ptr [rcx], eax
00dffdb8  0101                     add dword ptr [rcx], eax
00dffdba  0101                     add dword ptr [rcx], eax
00dffdbc  0101                     add dword ptr [rcx], eax
00dffdbe  0101                     add dword ptr [rcx], eax
00dffdc0  0101                     add dword ptr [rcx], eax
00dffdc2  0101                     add dword ptr [rcx], eax
00dffdc4  0101                     add dword ptr [rcx], eax
00dffdc6  0101                     add dword ptr [rcx], eax
00dffdc8  0101                     add dword ptr [rcx], eax
00dffdca  0101                     add dword ptr [rcx], eax
00dffdcc  0101                     add dword ptr [rcx], eax
00dffdce  0101                     add dword ptr [rcx], eax
00dffdd0  0101                     add dword ptr [rcx], eax
00dffdd2  0101                     add dword ptr [rcx], eax
00dffdd4  0000                     add byte ptr [rax], al
00dffdd6  0101                     add dword ptr [rcx], eax
00dffdd8  0101                     add dword ptr [rcx], eax
00dffdda  0101                     add dword ptr [rcx], eax
00dffddc  0101                     add dword ptr [rcx], eax
00dffdde  0001                     add byte ptr [rcx], al
00dffde0  0101                     add dword ptr [rcx], eax
00dffde2  0101                     add dword ptr [rcx], eax
00dffde4  0101                     add dword ptr [rcx], eax
00dffde6  0101                     add dword ptr [rcx], eax
00dffde8  0100                     add dword ptr [rax], eax
