; CBindEnv::LookupTargetTable
; sqllang.dll, primary RVA 0x2e28b0, 333 bytes in 3 chunk(s)

; chunk at RVA 0x2e28b0 (115 bytes)
002e28b0  4055                     push rbp
002e28b2  53                       push rbx
002e28b3  56                       push rsi
002e28b4  57                       push rdi
002e28b5  4154                     push r12
002e28b7  4155                     push r13
002e28b9  4156                     push r14
002e28bb  488d6c24d9               lea rbp, [rsp - 0x27]
002e28c0  4881ec90000000           sub rsp, 0x90
002e28c7  33db                     xor ebx, ebx
002e28c9  488955d7                 mov qword ptr [rbp - 0x29], rdx
002e28cd  4c8bf1                   mov r14, rcx
002e28d0  895dcf                   mov dword ptr [rbp - 0x31], ebx
002e28d3  488b4930                 mov rcx, qword ptr [rcx + 0x30]
002e28d7  4d8be1                   mov r12, r9
002e28da  4d8be8                   mov r13, r8
002e28dd  488bf2                   mov rsi, rdx
002e28e0  f6411004                 test byte ptr [rcx + 0x10], 4
002e28e4  0f85f8dd0200             jne 0x3106e2
002e28ea  0f1045cf                 movups xmm0, xmmword ptr [rbp - 0x31]
002e28ee  488d55e7                 lea rdx, [rbp - 0x19]
002e28f2  488b01                   mov rax, qword ptr [rcx]
002e28f5  f20f104ddf               movsd xmm1, qword ptr [rbp - 0x21]
002e28fa  4d8bcd                   mov r9, r13
002e28fd  885c2428                 mov byte ptr [rsp + 0x28], bl
002e2901  4533c0                   xor r8d, r8d
002e2904  0f2945e7                 movaps xmmword ptr [rbp - 0x19], xmm0
002e2908  f20f114df7               movsd qword ptr [rbp - 9], xmm1
002e290d  4c89642420               mov qword ptr [rsp + 0x20], r12
002e2912  ff5010                   call qword ptr [rax + 0x10]
002e2915  8bf8                     mov edi, eax
002e2917  83f803                   cmp eax, 3
002e291a  0f85c4dd0200             jne 0x3106e4
002e2920  eb01                     jmp 0x2e2923
002e2922  cc                       int3

; chunk at RVA 0x2e2923 (18 bytes)
002e2923  4881c490000000           add rsp, 0x90
002e292a  415e                     pop r14
002e292c  415d                     pop r13
002e292e  415c                     pop r12
002e2930  5f                       pop rdi
002e2931  5e                       pop rsi
002e2932  5b                       pop rbx
002e2933  5d                       pop rbp
002e2934  c3                       ret

; chunk at RVA 0x310713 (200 bytes)
00310713  4c89bc24e0000000         mov qword ptr [rsp + 0xe0], r15
0031071b  440fb67d67               movzx r15d, byte ptr [rbp + 0x67]
00310720  4584ff                   test r15b, r15b
00310723  0f85437b6f00             jne 0xa0826c
00310729  498b4e30                 mov rcx, qword ptr [r14 + 0x30]
0031072d  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
00310730  8b75c7                   mov esi, dword ptr [rbp - 0x39]
00310733  c745cf02000000           mov dword ptr [rbp - 0x31], 2
0031073a  f6411004                 test byte ptr [rcx + 0x10], 4
0031073e  897dd7                   mov dword ptr [rbp - 0x29], edi
00310741  8975db                   mov dword ptr [rbp - 0x25], esi
00310744  895ddf                   mov dword ptr [rbp - 0x21], ebx
00310747  7534                     jne 0x31077d
00310749  0f1045cf                 movups xmm0, xmmword ptr [rbp - 0x31]
0031074d  488d55e7                 lea rdx, [rbp - 0x19]
00310751  488b01                   mov rax, qword ptr [rcx]
00310754  f20f104ddf               movsd xmm1, qword ptr [rbp - 0x21]
00310759  4d8bcd                   mov r9, r13
0031075c  885c2428                 mov byte ptr [rsp + 0x28], bl
00310760  4533c0                   xor r8d, r8d
00310763  0f2945e7                 movaps xmmword ptr [rbp - 0x19], xmm0
00310767  f20f114df7               movsd qword ptr [rbp - 9], xmm1
0031076c  4c89642420               mov qword ptr [rsp + 0x20], r12
00310771  ff5010                   call qword ptr [rax + 0x10]
00310774  83f802                   cmp eax, 2
00310777  0f84e97a6f00             je 0xa08266
0031077d  c745cf02000000           mov dword ptr [rbp - 0x31], 2
00310784  488d45cf                 lea rax, [rbp - 0x31]
00310788  897dd7                   mov dword ptr [rbp - 0x29], edi
0031078b  8975db                   mov dword ptr [rbp - 0x25], esi
0031078e  895ddf                   mov dword ptr [rbp - 0x21], ebx
00310791  eb01                     jmp 0x310794
00310793  cc                       int3
00310794  498b4e30                 mov rcx, qword ptr [r14 + 0x30]
00310798  f6411004                 test byte ptr [rcx + 0x10], 4
0031079c  752d                     jne 0x3107cb
0031079e  0f1000                   movups xmm0, xmmword ptr [rax]
003107a1  488d5507                 lea rdx, [rbp + 7]
003107a5  44887c2428               mov byte ptr [rsp + 0x28], r15b
003107aa  f20f104810               movsd xmm1, qword ptr [rax + 0x10]
003107af  4d8bcd                   mov r9, r13
003107b2  488b01                   mov rax, qword ptr [rcx]
003107b5  41b001                   mov r8b, 1
003107b8  0f294507                 movaps xmmword ptr [rbp + 7], xmm0
003107bc  f20f114d17               movsd qword ptr [rbp + 0x17], xmm1
003107c1  4c89642420               mov qword ptr [rsp + 0x20], r12
003107c6  ff5010                   call qword ptr [rax + 0x10]
003107c9  8bd8                     mov ebx, eax
003107cb  8bc3                     mov eax, ebx
003107cd  4c8bbc24e0000000         mov r15, qword ptr [rsp + 0xe0]
003107d5  e94921fdff               jmp 0x2e2923
003107da  cc                       int3
