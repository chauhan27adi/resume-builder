; CBcpImport::ScanColumnsInfo
; sqllang.dll, primary RVA 0x1970290, 4228 bytes in 1 chunk(s)

; chunk at RVA 0x1970290 (4228 bytes)
01970290  4055                     push rbp
01970292  53                       push rbx
01970293  56                       push rsi
01970294  57                       push rdi
01970295  4154                     push r12
01970297  4155                     push r13
01970299  4156                     push r14
0197029b  4157                     push r15
0197029d  4881ec78020000           sub rsp, 0x278
019702a4  488d6c2450               lea rbp, [rsp + 0x50]
019702a9  48c785e8000000feffffff   mov qword ptr [rbp + 0xe8], 0xfffffffffffffffe
019702b4  488b05cd991601           mov rax, qword ptr [rip + 0x11699cd]
019702bb  4833c5                   xor rax, rbp
019702be  48898510020000           mov qword ptr [rbp + 0x210], rax
019702c5  4d8be9                   mov r13, r9
019702c8  498bd8                   mov rbx, r8
019702cb  4c8bf2                   mov r14, rdx
019702ce  48895560                 mov qword ptr [rbp + 0x60], rdx
019702d2  488bf1                   mov rsi, rcx
019702d5  48898dc0000000           mov qword ptr [rbp + 0xc0], rcx
019702dc  0fb74978                 movzx ecx, word ptr [rcx + 0x78]
019702e0  ff1522b95500             call qword ptr [rip + 0x55b922]
019702e6  488985b8000000           mov qword ptr [rbp + 0xb8], rax
019702ed  33ff                     xor edi, edi
019702ef  48897d58                 mov qword ptr [rbp + 0x58], rdi
019702f3  488b4e70                 mov rcx, qword ptr [rsi + 0x70]
019702f7  4c8b01                   mov r8, qword ptr [rcx]
019702fa  488d95f0000000           lea rdx, [rbp + 0xf0]
01970301  41ff5060                 call qword ptr [r8 + 0x60]
01970305  81bdf800000055200000     cmp dword ptr [rbp + 0xf8], 0x2055
0197030f  7516                     jne 0x1970327
01970311  4c8b0b                   mov r9, qword ptr [rbx]
01970314  4533c0                   xor r8d, r8d
01970317  33d2                     xor edx, edx
01970319  488bcb                   mov rcx, rbx
0197031c  41ff9168010000           call qword ptr [r9 + 0x168]
01970323  48894558                 mov qword ptr [rbp + 0x58], rax
01970327  48897d20                 mov qword ptr [rbp + 0x20], rdi
0197032b  48895d10                 mov qword ptr [rbp + 0x10], rbx
0197032f  48897d18                 mov qword ptr [rbp + 0x18], rdi
01970333  488b13                   mov rdx, qword ptr [rbx]
01970336  488bcb                   mov rcx, rbx
01970339  ff92a8000000             call qword ptr [rdx + 0xa8]
0197033f  41bfffffffff             mov r15d, 0xffffffff
01970345  413bc7                   cmp eax, r15d
01970348  743c                     je 0x1970386
0197034a  488b03                   mov rax, qword ptr [rbx]
0197034d  488bcb                   mov rcx, rbx
01970350  ff90c0000000             call qword ptr [rax + 0xc0]
01970356  48894520                 mov qword ptr [rbp + 0x20], rax
0197035a  4885c0                   test rax, rax
0197035d  7427                     je 0x1970386
0197035f  4c8b00                   mov r8, qword ptr [rax]
01970362  418bd7                   mov edx, r15d
01970365  488bc8                   mov rcx, rax
01970368  41ff5008                 call qword ptr [r8 + 8]
0197036c  488b4d20                 mov rcx, qword ptr [rbp + 0x20]
01970370  488b01                   mov rax, qword ptr [rcx]
01970373  488d5528                 lea rdx, [rbp + 0x28]
01970377  ff5010                   call qword ptr [rax + 0x10]
0197037a  8b4d28                   mov ecx, dword ptr [rbp + 0x28]
0197037d  84c0                     test al, al
0197037f  410f44cf                 cmove ecx, r15d
01970383  894d28                   mov dword ptr [rbp + 0x28], ecx
01970386  488b03                   mov rax, qword ptr [rbx]
01970389  488bcb                   mov rcx, rbx
0197038c  ff90a8000000             call qword ptr [rax + 0xa8]
01970392  8985b0000000             mov dword ptr [rbp + 0xb0], eax
01970398  413bc7                   cmp eax, r15d
0197039b  7423                     je 0x19703c0
0197039d  488b4d20                 mov rcx, qword ptr [rbp + 0x20]
019703a1  4885c9                   test rcx, rcx
019703a4  7513                     jne 0x19703b9
019703a6  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
019703aa  4c8b01                   mov r8, qword ptr [rcx]
019703ad  8b5518                   mov edx, dword ptr [rbp + 0x18]
019703b0  41ff90d0000000           call qword ptr [r8 + 0xd0]
019703b7  eb15                     jmp 0x19703ce
019703b9  488b01                   mov rax, qword ptr [rcx]
019703bc  ff10                     call qword ptr [rax]
019703be  eb0e                     jmp 0x19703ce
019703c0  488b03                   mov rax, qword ptr [rbx]
019703c3  33d2                     xor edx, edx
019703c5  488bcb                   mov rcx, rbx
019703c8  ff90d0000000             call qword ptr [rax + 0xd0]
019703ce  894628                   mov dword ptr [rsi + 0x28], eax
019703d1  40887d00                 mov byte ptr [rbp], dil
019703d5  418b4510                 mov eax, dword ptr [r13 + 0x10]
019703d9  41bc01000000             mov r12d, 1
019703df  480fbae016               bt rax, 0x16
019703e4  7309                     jae 0x19703ef
019703e6  44886500                 mov byte ptr [rbp], r12b
019703ea  e995000000               jmp 0x1970484
019703ef  448bf7                   mov r14d, edi
019703f2  488b03                   mov rax, qword ptr [rbx]
019703f5  33d2                     xor edx, edx
019703f7  488bcb                   mov rcx, rbx
019703fa  ff90d0000000             call qword ptr [rax + 0xd0]
01970400  448bf8                   mov r15d, eax
01970403  418bfc                   mov edi, r12d
01970406  413bc4                   cmp eax, r12d
01970409  726f                     jb 0x197047a
0197040b  0faee8                   lfence
0197040e  6690                     nop
01970410  0f57c0                   xorps xmm0, xmm0
01970413  33c0                     xor eax, eax
01970415  0f1185b0010000           movups xmmword ptr [rbp + 0x1b0], xmm0
0197041c  0f1185c0010000           movups xmmword ptr [rbp + 0x1c0], xmm0
01970423  0f1185d0010000           movups xmmword ptr [rbp + 0x1d0], xmm0
0197042a  0f1185e0010000           movups xmmword ptr [rbp + 0x1e0], xmm0
01970431  0f1185f0010000           movups xmmword ptr [rbp + 0x1f0], xmm0
01970438  48898500020000           mov qword ptr [rbp + 0x200], rax
0197043f  488b03                   mov rax, qword ptr [rbx]
01970442  4533c0                   xor r8d, r8d
01970445  8bd7                     mov edx, edi
01970447  488bcb                   mov rcx, rbx
0197044a  ff90e0000000             call qword ptr [rax + 0xe0]
01970450  4c8b00                   mov r8, qword ptr [rax]
01970453  488d95b0010000           lea rdx, [rbp + 0x1b0]
0197045a  488bc8                   mov rcx, rax
0197045d  41ff5018                 call qword ptr [r8 + 0x18]
01970461  f6850402000020           test byte ptr [rbp + 0x204], 0x20
01970468  418d4601                 lea eax, [r14 + 1]
0197046c  410f44c6                 cmove eax, r14d
01970470  448bf0                   mov r14d, eax
01970473  ffc7                     inc edi
01970475  413bff                   cmp edi, r15d
01970478  7696                     jbe 0x1970410
0197047a  44297628                 sub dword ptr [rsi + 0x28], r14d
0197047e  4c8b7560                 mov r14, qword ptr [rbp + 0x60]
01970482  33ff                     xor edi, edi
01970484  8b4628                   mov eax, dword ptr [rsi + 0x28]
01970487  8bc8                     mov ecx, eax
01970489  b880010000               mov eax, 0x180
0197048e  48f7e1                   mul rcx
01970491  49c7c7ffffffff           mov r15, 0xffffffffffffffff
01970498  490f40c7                 cmovo rax, r15
0197049c  c644242005               mov byte ptr [rsp + 0x20], 5
019704a1  41b9a3030000             mov r9d, 0x3a3
019704a7  4c8d055a5cb500           lea r8, [rip + 0xb55c5a]
019704ae  488b5650                 mov rdx, qword ptr [rsi + 0x50]
019704b2  488bc8                   mov rcx, rax
019704b5  ff153daa5500             call qword ptr [rip + 0x55aa3d]
019704bb  48894620                 mov qword ptr [rsi + 0x20], rax
019704bf  8b4e28                   mov ecx, dword ptr [rsi + 0x28]
019704c2  4c8d0449                 lea r8, [rcx + rcx*2]
019704c6  49c1e007                 shl r8, 7
019704ca  33d2                     xor edx, edx
019704cc  488bc8                   mov rcx, rax
019704cf  e8222b69fe               call 0x2ff6
019704d4  8b5e28                   mov ebx, dword ptr [rsi + 0x28]
019704d7  c74508a6030000           mov dword ptr [rbp + 8], 0x3a6
019704de  b820000000               mov eax, 0x20
019704e3  48f7e3                   mul rbx
019704e6  490f40c7                 cmovo rax, r15
019704ea  c644242005               mov byte ptr [rsp + 0x20], 5
019704ef  41b9a6030000             mov r9d, 0x3a6
019704f5  4c8d050c5cb500           lea r8, [rip + 0xb55c0c]
019704fc  488b5650                 mov rdx, qword ptr [rsi + 0x50]
01970500  488bc8                   mov rcx, rax
01970503  ff15efa95500             call qword ptr [rip + 0x55a9ef]
01970509  488bc8                   mov rcx, rax
0197050c  48894568                 mov qword ptr [rbp + 0x68], rax
01970510  4885c0                   test rax, rax
01970513  743f                     je 0x1970554
01970515  4885db                   test rbx, rbx
01970518  743d                     je 0x1970557
0197051a  4883c008                 add rax, 8
0197051e  6690                     nop
01970520  668978f9                 mov word ptr [rax - 7], di
01970524  c640fb00                 mov byte ptr [rax - 5], 0
01970528  48c7400c00000000         mov qword ptr [rax + 0xc], 0
01970530  c640f800                 mov byte ptr [rax - 8], 0
01970534  8978fc                   mov dword ptr [rax - 4], edi
01970537  4c8938                   mov qword ptr [rax], r15
0197053a  c7400800000000           mov dword ptr [rax + 8], 0
01970541  c7401400000000           mov dword ptr [rax + 0x14], 0
01970548  488d4020                 lea rax, [rax + 0x20]
0197054c  4883eb01                 sub rbx, 1
01970550  75ce                     jne 0x1970520
01970552  eb03                     jmp 0x1970557
01970554  488bcf                   mov rcx, rdi
01970557  48894e48                 mov qword ptr [rsi + 0x48], rcx
0197055b  448b4628                 mov r8d, dword ptr [rsi + 0x28]
0197055f  49c1e005                 shl r8, 5
01970563  33d2                     xor edx, edx
01970565  e88c2a69fe               call 0x2ff6
0197056a  8b5e28                   mov ebx, dword ptr [rsi + 0x28]
0197056d  c1e302                   shl ebx, 2
01970570  e82bf569fe               call 0xfaa0
01970575  488d8b00000100           lea rcx, [rbx + 0x10000]
0197057c  483bc1                   cmp rax, rcx
0197057f  7322                     jae 0x19705a3
01970581  48897c2420               mov qword ptr [rsp + 0x20], rdi
01970586  41b9ab030000             mov r9d, 0x3ab
0197058c  4c8d05bd54ba00           lea r8, [rip + 0xba54bd]
01970593  488d157e32bb00           lea rdx, [rip + 0xbb327e]
0197059a  418bcc                   mov ecx, r12d
0197059d  ff15d5a85500             call qword ptr [rip + 0x55a8d5]
019705a3  488d430f                 lea rax, [rbx + 0xf]
019705a7  48b9f0ffffffffffff0f     movabs rcx, 0xffffffffffffff0
019705b1  483bc3                   cmp rax, rbx
019705b4  7703                     ja 0x19705b9
019705b6  488bc1                   mov rax, rcx
019705b9  4883e0f0                 and rax, 0xfffffffffffffff0
019705bd  e82e0f69fe               call 0x14f0
019705c2  482be0                   sub rsp, rax
019705c5  488d442450               lea rax, [rsp + 0x50]
019705ca  48894568                 mov qword ptr [rbp + 0x68], rax
019705ce  498b8588000000           mov rax, qword ptr [r13 + 0x88]
019705d5  488985c0000000           mov qword ptr [rbp + 0xc0], rax
019705dc  448be7                   mov r12d, edi
019705df  897d50                   mov dword ptr [rbp + 0x50], edi
019705e2  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
019705e6  488b01                   mov rax, qword ptr [rcx]
019705e9  48837d2000               cmp qword ptr [rbp + 0x20], 0
019705ee  7525                     jne 0x1970615
019705f0  8b5518                   mov edx, dword ptr [rbp + 0x18]
019705f3  ff90d0000000             call qword ptr [rax + 0xd0]
019705f9  8b551c                   mov edx, dword ptr [rbp + 0x1c]
019705fc  3bd0                     cmp edx, eax
019705fe  7320                     jae 0x1970620
01970600  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01970604  488b01                   mov rax, qword ptr [rcx]
01970607  ffc2                     inc edx
01970609  448b4518                 mov r8d, dword ptr [rbp + 0x18]
0197060d  ff90e0000000             call qword ptr [rax + 0xe0]
01970613  eb0b                     jmp 0x1970620
01970615  448b4518                 mov r8d, dword ptr [rbp + 0x18]
01970619  8b5528                   mov edx, dword ptr [rbp + 0x28]
0197061c  ff5028                   call qword ptr [rax + 0x28]
0197061f  90                       nop
01970620  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01970624  488b01                   mov rax, qword ptr [rcx]
01970627  48837d2000               cmp qword ptr [rbp + 0x20], 0
0197062c  752a                     jne 0x1970658
0197062e  8b5518                   mov edx, dword ptr [rbp + 0x18]
01970631  ff90d0000000             call qword ptr [rax + 0xd0]
01970637  8b551c                   mov edx, dword ptr [rbp + 0x1c]
0197063a  3bd0                     cmp edx, eax
0197063c  7205                     jb 0x1970643
0197063e  4c8bff                   mov r15, rdi
01970641  eb22                     jmp 0x1970665
01970643  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01970647  488b01                   mov rax, qword ptr [rcx]
0197064a  ffc2                     inc edx
0197064c  448b4518                 mov r8d, dword ptr [rbp + 0x18]
01970650  ff90e0000000             call qword ptr [rax + 0xe0]
01970656  eb0a                     jmp 0x1970662
01970658  448b4518                 mov r8d, dword ptr [rbp + 0x18]
0197065c  8b5528                   mov edx, dword ptr [rbp + 0x28]
0197065f  ff5028                   call qword ptr [rax + 0x28]
01970662  4c8bf8                   mov r15, rax
01970665  4d85ff                   test r15, r15
01970668  0f8455090000             je 0x1970fc3
0197066e  0f57c0                   xorps xmm0, xmm0
01970671  33c0                     xor eax, eax
01970673  0f118500010000           movups xmmword ptr [rbp + 0x100], xmm0
0197067a  0f118510010000           movups xmmword ptr [rbp + 0x110], xmm0
01970681  0f118520010000           movups xmmword ptr [rbp + 0x120], xmm0
01970688  0f118530010000           movups xmmword ptr [rbp + 0x130], xmm0
0197068f  0f118540010000           movups xmmword ptr [rbp + 0x140], xmm0
01970696  48898550010000           mov qword ptr [rbp + 0x150], rax
0197069d  498b07                   mov rax, qword ptr [r15]
019706a0  498bcf                   mov rcx, r15
019706a3  ff5008                   call qword ptr [rax + 8]
019706a6  8bf8                     mov edi, eax
019706a8  894504                   mov dword ptr [rbp + 4], eax
019706ab  4d8b07                   mov r8, qword ptr [r15]
019706ae  488d9500010000           lea rdx, [rbp + 0x100]
019706b5  498bcf                   mov rcx, r15
019706b8  41ff5018                 call qword ptr [r8 + 0x18]
019706bc  807d0000                 cmp byte ptr [rbp], 0
019706c0  7517                     jne 0x19706d9
019706c2  f6855401000020           test byte ptr [rbp + 0x154], 0x20
019706c9  740e                     je 0x19706d9
019706cb  41bfffffffff             mov r15d, 0xffffffff
019706d1  4503e7                   add r12d, r15d
019706d4  e98b080000               jmp 0x1970f64
019706d9  418bc4                   mov eax, r12d
019706dc  488d1c40                 lea rbx, [rax + rax*2]
019706e0  48c1e307                 shl rbx, 7
019706e4  488b4620                 mov rax, qword ptr [rsi + 0x20]
019706e8  b9ffffffff               mov ecx, 0xffffffff
019706ed  48894c1860               mov qword ptr [rax + rbx + 0x60], rcx
019706f2  33c0                     xor eax, eax
019706f4  66894531                 mov word ptr [rbp + 0x31], ax
019706f8  884533                   mov byte ptr [rbp + 0x33], al
019706fb  48894544                 mov qword ptr [rbp + 0x44], rax
019706ff  884530                   mov byte ptr [rbp + 0x30], al
01970702  894534                   mov dword ptr [rbp + 0x34], eax
01970705  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
0197070c  48894d38                 mov qword ptr [rbp + 0x38], rcx
01970710  894540                   mov dword ptr [rbp + 0x40], eax
01970713  89454c                   mov dword ptr [rbp + 0x4c], eax
01970716  41388516010000           cmp byte ptr [r13 + 0x116], al
0197071d  7518                     jne 0x1970737
0197071f  41388508010000           cmp byte ptr [r13 + 0x108], al
01970726  0f847e010000             je 0x19708aa
0197072c  41837d6801               cmp dword ptr [r13 + 0x68], 1
01970731  0f8573010000             jne 0x19708aa
01970737  4d8bc7                   mov r8, r15
0197073a  498bd6                   mov rdx, r14
0197073d  483985c0000000           cmp qword ptr [rbp + 0xc0], rax
01970744  0f8592000000             jne 0x19707dc
0197074a  66894571                 mov word ptr [rbp + 0x71], ax
0197074e  884573                   mov byte ptr [rbp + 0x73], al
01970751  48898584000000           mov qword ptr [rbp + 0x84], rax
01970758  884570                   mov byte ptr [rbp + 0x70], al
0197075b  894574                   mov dword ptr [rbp + 0x74], eax
0197075e  48894d78                 mov qword ptr [rbp + 0x78], rcx
01970762  898580000000             mov dword ptr [rbp + 0x80], eax
01970768  89858c000000             mov dword ptr [rbp + 0x8c], eax
0197076e  4c8d4d70                 lea r9, [rbp + 0x70]
01970772  e819503dff               call 0xd45790
01970777  488bf8                   mov rdi, rax
0197077a  41837d6801               cmp dword ptr [r13 + 0x68], 1
0197077f  7404                     je 0x1970785
01970781  806571fe                 and byte ptr [rbp + 0x71], 0xfe
01970785  418b9548010000           mov edx, dword ptr [r13 + 0x148]
0197078c  ffc2                     inc edx
0197078e  41899548010000           mov dword ptr [r13 + 0x148], edx
01970795  418d4c2401               lea ecx, [r12 + 1]
0197079a  488d4570                 lea rax, [rbp + 0x70]
0197079e  4889442440               mov qword ptr [rsp + 0x40], rax
019707a3  4c89742438               mov qword ptr [rsp + 0x38], r14
019707a8  4533c0                   xor r8d, r8d
019707ab  4489442430               mov dword ptr [rsp + 0x30], r8d
019707b0  4c89442428               mov qword ptr [rsp + 0x28], r8
019707b5  8b4720                   mov eax, dword ptr [rdi + 0x20]
019707b8  89442420                 mov dword ptr [rsp + 0x20], eax
019707bc  4c8b4f18                 mov r9, qword ptr [rdi + 0x18]
019707c0  e8fbf23bff               call 0xd2fac0
019707c5  48897820                 mov qword ptr [rax + 0x20], rdi
019707c9  4533c0                   xor r8d, r8d
019707cc  488bd0                   mov rdx, rax
019707cf  498bcd                   mov rcx, r13
019707d2  e859b039ff               call 0xd0b830
019707d7  e9cb000000               jmp 0x19708a7
019707dc  66898591000000           mov word ptr [rbp + 0x91], ax
019707e3  888593000000             mov byte ptr [rbp + 0x93], al
019707e9  488985a4000000           mov qword ptr [rbp + 0xa4], rax
019707f0  888590000000             mov byte ptr [rbp + 0x90], al
019707f6  898594000000             mov dword ptr [rbp + 0x94], eax
019707fc  48898d98000000           mov qword ptr [rbp + 0x98], rcx
01970803  8985a0000000             mov dword ptr [rbp + 0xa0], eax
01970809  8985ac000000             mov dword ptr [rbp + 0xac], eax
0197080f  4c8d8d90000000           lea r9, [rbp + 0x90]
01970816  e8754f3dff               call 0xd45790
0197081b  4c8be0                   mov r12, rax
0197081e  4d8bb588000000           mov r14, qword ptr [r13 + 0x88]
01970825  4d85f6                   test r14, r14
01970828  0f847c000000             je 0x19708aa
0197082e  90                       nop
0197082f  90                       nop
01970830  498b17                   mov rdx, qword ptr [r15]
01970833  498bcf                   mov rcx, r15
01970836  ff5210                   call qword ptr [rdx + 0x10]
01970839  8b7808                   mov edi, dword ptr [rax + 8]
0197083c  498b17                   mov rdx, qword ptr [r15]
0197083f  498bcf                   mov rcx, r15
01970842  ff5210                   call qword ptr [rdx + 0x10]
01970845  897c2420                 mov dword ptr [rsp + 0x20], edi
01970849  4c8b08                   mov r9, qword ptr [rax]
0197084c  458b4608                 mov r8d, dword ptr [r14 + 8]
01970850  498b16                   mov rdx, qword ptr [r14]
01970853  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
0197085a  ff15c0b45500             call qword ptr [rip + 0x55b4c0]
01970860  84c0                     test al, al
01970862  750b                     jne 0x197086f
01970864  4d8b7658                 mov r14, qword ptr [r14 + 0x58]
01970868  4d85f6                   test r14, r14
0197086b  75c3                     jne 0x1970830
0197086d  eb38                     jmp 0x19708a7
0197086f  4d896620                 mov qword ptr [r14 + 0x20], r12
01970873  8b4550                   mov eax, dword ptr [rbp + 0x50]
01970876  ffc0                     inc eax
01970878  4189462c                 mov dword ptr [r14 + 0x2c], eax
0197087c  0f108590000000           movups xmm0, xmmword ptr [rbp + 0x90]
01970883  410f114638               movups xmmword ptr [r14 + 0x38], xmm0
01970888  0f108da0000000           movups xmm1, xmmword ptr [rbp + 0xa0]
0197088f  410f114e48               movups xmmword ptr [r14 + 0x48], xmm1
01970894  41807e6100               cmp byte ptr [r14 + 0x61], 0
01970899  7507                     jne 0x19708a2
0197089b  41837d6801               cmp dword ptr [r13 + 0x68], 1
019708a0  7405                     je 0x19708a7
019708a2  41806639fe               and byte ptr [r14 + 0x39], 0xfe
019708a7  8b7d04                   mov edi, dword ptr [rbp + 4]
019708aa  498b07                   mov rax, qword ptr [r15]
019708ad  488d5530                 lea rdx, [rbp + 0x30]
019708b1  498bcf                   mov rcx, r15
019708b4  ff5020                   call qword ptr [rax + 0x20]
019708b7  b8ffff0000               mov eax, 0xffff
019708bc  66394540                 cmp word ptr [rbp + 0x40], ax
019708c0  7421                     je 0x19708e3
019708c2  0fb64530                 movzx eax, byte ptr [rbp + 0x30]
019708c6  488d1533f768fe           lea rdx, [rip - 0x19708cd]
019708cd  0fb68c1010360202         movzx ecx, byte ptr [rax + rdx + 0x2023610]
019708d5  80bc119875ae0200         cmp byte ptr [rcx + rdx + 0x2ae7598], 0
019708dd  0f84a6000000             je 0x1970989
019708e3  81bdf800000055200000     cmp dword ptr [rbp + 0xf8], 0x2055
019708ed  0f8596000000             jne 0x1970989
019708f3  39bdb0000000             cmp dword ptr [rbp + 0xb0], edi
019708f9  0f848a000000             je 0x1970989
019708ff  488b7d58                 mov rdi, qword ptr [rbp + 0x58]
01970903  488b07                   mov rax, qword ptr [rdi]
01970906  488bcf                   mov rcx, rdi
01970909  ff5058                   call qword ptr [rax + 0x58]
0197090c  894508                   mov dword ptr [rbp + 8], eax
0197090f  41bc01000000             mov r12d, 1
01970915  458bf4                   mov r14d, r12d
01970918  413bc4                   cmp eax, r12d
0197091b  0f8282000000             jb 0x19709a3
01970921  0faee8                   lfence
01970924  0f1f4000                 nop dword ptr [rax]
01970928  0f1f840000000000         nop dword ptr [rax + rax]
01970930  4c8b07                   mov r8, qword ptr [rdi]
01970933  418bd6                   mov edx, r14d
01970936  488bcf                   mov rcx, rdi
01970939  41ff5060                 call qword ptr [r8 + 0x60]
0197093d  448be0                   mov r12d, eax
01970940  4c8b07                   mov r8, qword ptr [rdi]
01970943  8bd0                     mov edx, eax
01970945  488bcf                   mov rcx, rdi
01970948  41ff5040                 call qword ptr [r8 + 0x40]
0197094c  488bf8                   mov rdi, rax
0197094f  4885c0                   test rax, rax
01970952  7418                     je 0x197096c
01970954  488b10                   mov rdx, qword ptr [rax]
01970957  488bc8                   mov rcx, rax
0197095a  ff5210                   call qword ptr [rdx + 0x10]
0197095d  394504                   cmp dword ptr [rbp + 4], eax
01970960  750a                     jne 0x197096c
01970962  b8ffffffff               mov eax, 0xffffffff
01970967  443be0                   cmp r12d, eax
0197096a  750f                     jne 0x197097b
0197096c  41ffc6                   inc r14d
0197096f  443b7508                 cmp r14d, dword ptr [rbp + 8]
01970973  7728                     ja 0x197099d
01970975  488b7d58                 mov rdi, qword ptr [rbp + 0x58]
01970979  ebb5                     jmp 0x1970930
0197097b  0faee8                   lfence
0197097e  488b07                   mov rax, qword ptr [rdi]
01970981  488bcf                   mov rcx, rdi
01970984  ff5018                   call qword ptr [rax + 0x18]
01970987  eb09                     jmp 0x1970992
01970989  498b07                   mov rax, qword ptr [r15]
0197098c  498bcf                   mov rcx, r15
0197098f  ff5008                   call qword ptr [rax + 8]
01970992  8bc8                     mov ecx, eax
01970994  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970998  48894c1860               mov qword ptr [rax + rbx + 0x60], rcx
0197099d  41bc01000000             mov r12d, 1
019709a3  488b4620                 mov rax, qword ptr [rsi + 0x20]
019709a7  c644035c00               mov byte ptr [rbx + rax + 0x5c], 0
019709ac  0fb65530                 movzx edx, byte ptr [rbp + 0x30]
019709b0  440fb74540               movzx r8d, word ptr [rbp + 0x40]
019709b5  41baffff0000             mov r10d, 0xffff
019709bb  4c8d0d3ef668fe           lea r9, [rip - 0x19709c2]
019709c2  66453bc2                 cmp r8w, r10w
019709c6  0f8490000000             je 0x1970a5c
019709cc  410fb68c1110360202       movzx ecx, byte ptr [r9 + rdx + 0x2023610]
019709d5  4280bc099875ae0200       cmp byte ptr [rcx + r9 + 0x2ae7598], 0
019709de  757c                     jne 0x1970a5c
019709e0  80faf0                   cmp dl, 0xf0
019709e3  7568                     jne 0x1970a4d
019709e5  b2a5                     mov dl, 0xa5
019709e7  488d8dc8000000           lea rcx, [rbp + 0xc8]
019709ee  e83d356efe               call 0x53f30
019709f3  0fb65531                 movzx edx, byte ptr [rbp + 0x31]
019709f7  f6d2                     not dl
019709f9  f6c201                   test dl, 1
019709fc  7507                     jne 0x1970a05
019709fe  808dc900000001           or byte ptr [rbp + 0xc9], 1
01970a05  80bdc800000062           cmp byte ptr [rbp + 0xc8], 0x62
01970a0c  7508                     jne 0x1970a16
01970a0e  664489a5d8000000         mov word ptr [rbp + 0xd8], r12w
01970a16  0f1085c8000000           movups xmm0, xmmword ptr [rbp + 0xc8]
01970a1d  0f114530                 movups xmmword ptr [rbp + 0x30], xmm0
01970a21  0f108dd8000000           movups xmm1, xmmword ptr [rbp + 0xd8]
01970a28  0f114d40                 movups xmmword ptr [rbp + 0x40], xmm1
01970a2c  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970a30  33ff                     xor edi, edi
01970a32  897c034c                 mov dword ptr [rbx + rax + 0x4c], edi
01970a36  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970a3a  40887c035c               mov byte ptr [rbx + rax + 0x5c], dil
01970a3f  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970a43  c644035d01               mov byte ptr [rbx + rax + 0x5d], 1
01970a48  e914010000               jmp 0x1970b61
01970a4d  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970a51  33ff                     xor edi, edi
01970a53  897c034c                 mov dword ptr [rbx + rax + 0x4c], edi
01970a57  e905010000               jmp 0x1970b61
01970a5c  c6466001                 mov byte ptr [rsi + 0x60], 1
01970a60  80fa22                   cmp dl, 0x22
01970a63  7511                     jne 0x1970a76
01970a65  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970a69  c744034c03000000         mov dword ptr [rbx + rax + 0x4c], 3
01970a71  e9e9000000               jmp 0x1970b5f
01970a76  80fa63                   cmp dl, 0x63
01970a79  7511                     jne 0x1970a8c
01970a7b  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970a7f  c744034c02000000         mov dword ptr [rbx + rax + 0x4c], 2
01970a87  e9d3000000               jmp 0x1970b5f
01970a8c  80fa23                   cmp dl, 0x23
01970a8f  0f84c1000000             je 0x1970b56
01970a95  410fb68c1110360202       movzx ecx, byte ptr [r9 + rdx + 0x2023610]
01970a9e  4180bc093801060200       cmp byte ptr [r9 + rcx + 0x2060138], 0
01970aa7  7420                     je 0x1970ac9
01970aa9  66453bc2                 cmp r8w, r10w
01970aad  751a                     jne 0x1970ac9
01970aaf  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970ab3  c744034c03000000         mov dword ptr [rbx + rax + 0x4c], 3
01970abb  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970abf  c644035c01               mov byte ptr [rbx + rax + 0x5c], 1
01970ac4  e996000000               jmp 0x1970b5f
01970ac9  4280bc0980c9110200       cmp byte ptr [rcx + r9 + 0x211c980], 0
01970ad2  741d                     je 0x1970af1
01970ad4  66453bc2                 cmp r8w, r10w
01970ad8  7517                     jne 0x1970af1
01970ada  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970ade  c744034c02000000         mov dword ptr [rbx + rax + 0x4c], 2
01970ae6  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970aea  c644035c01               mov byte ptr [rbx + rax + 0x5c], 1
01970aef  eb6e                     jmp 0x1970b5f
01970af1  4280bc091001060200       cmp byte ptr [rcx + r9 + 0x2060110], 0
01970afa  741a                     je 0x1970b16
01970afc  66453bc2                 cmp r8w, r10w
01970b00  7514                     jne 0x1970b16
01970b02  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970b06  448964034c               mov dword ptr [rbx + rax + 0x4c], r12d
01970b0b  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970b0f  c644035c01               mov byte ptr [rbx + rax + 0x5c], 1
01970b14  eb49                     jmp 0x1970b5f
01970b16  80faf1                   cmp dl, 0xf1
01970b19  7494                     je 0x1970aaf
01970b1b  80faf0                   cmp dl, 0xf0
01970b1e  7536                     jne 0x1970b56
01970b20  0f1005592b1d01           movups xmm0, xmmword ptr [rip + 0x11d2b59]
01970b27  0f114530                 movups xmmword ptr [rbp + 0x30], xmm0
01970b2b  0f100d5e2b1d01           movups xmm1, xmmword ptr [rip + 0x11d2b5e]
01970b32  0f114d40                 movups xmmword ptr [rbp + 0x40], xmm1
01970b36  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970b3a  c744034c03000000         mov dword ptr [rbx + rax + 0x4c], 3
01970b42  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970b46  c644035c01               mov byte ptr [rbx + rax + 0x5c], 1
01970b4b  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970b4f  c644035d01               mov byte ptr [rbx + rax + 0x5d], 1
01970b54  eb09                     jmp 0x1970b5f
01970b56  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970b5a  448964034c               mov dword ptr [rbx + rax + 0x4c], r12d
01970b5f  33ff                     xor edi, edi
01970b61  448b6550                 mov r12d, dword ptr [rbp + 0x50]
01970b65  418bcc                   mov ecx, r12d
01970b68  48c1e105                 shl rcx, 5
01970b6c  488b4648                 mov rax, qword ptr [rsi + 0x48]
01970b70  0f104530                 movups xmm0, xmmword ptr [rbp + 0x30]
01970b74  0f110401                 movups xmmword ptr [rcx + rax], xmm0
01970b78  0f104d40                 movups xmm1, xmmword ptr [rbp + 0x40]
01970b7c  0f114c0110               movups xmmword ptr [rcx + rax + 0x10], xmm1
01970b81  807d30bd                 cmp byte ptr [rbp + 0x30], 0xbd
01970b85  0f94c1                   sete cl
01970b88  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970b8c  884c0353                 mov byte ptr [rbx + rax + 0x53], cl
01970b90  8b8544010000             mov eax, dword ptr [rbp + 0x144]
01970b96  83f808                   cmp eax, 8
01970b99  770a                     ja 0x1970ba5
01970b9b  b924010000               mov ecx, 0x124
01970ba0  0fa3c1                   bt ecx, eax
01970ba3  721a                     jb 0x1970bbf
01970ba5  498b07                   mov rax, qword ptr [r15]
01970ba8  498bcf                   mov rcx, r15
01970bab  ff5048                   call qword ptr [rax + 0x48]
01970bae  8bcf                     mov ecx, edi
01970bb0  4885c0                   test rax, rax
01970bb3  0f95c1                   setne cl
01970bb6  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970bba  66894c0346               mov word ptr [rbx + rax + 0x46], cx
01970bbf  0fb68554010000           movzx eax, byte ptr [rbp + 0x154]
01970bc6  a808                     test al, 8
01970bc8  7511                     jne 0x1970bdb
01970bca  a810                     test al, 0x10
01970bcc  750d                     jne 0x1970bdb
01970bce  83bd4001000000           cmp dword ptr [rbp + 0x140], 0
01970bd5  7504                     jne 0x1970bdb
01970bd7  33c9                     xor ecx, ecx
01970bd9  eb02                     jmp 0x1970bdd
01970bdb  b101                     mov cl, 1
01970bdd  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970be1  884c035e                 mov byte ptr [rbx + rax + 0x5e], cl
01970be5  41b91c000000             mov r9d, 0x1c
01970beb  458d41e5                 lea r8d, [r9 - 0x1b]
01970bef  488d5530                 lea rdx, [rbp + 0x30]
01970bf3  488d8d60010000           lea rcx, [rbp + 0x160]
01970bfa  ff1590ac5500             call qword ptr [rip + 0x55ac90]
01970c00  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970c04  c644035700               mov byte ptr [rbx + rax + 0x57], 0
01970c09  0fb64530                 movzx eax, byte ptr [rbp + 0x30]
01970c0d  488d15ecf368fe           lea rdx, [rip - 0x1970c14]
01970c14  0fb68c1010360202         movzx ecx, byte ptr [rax + rdx + 0x2023610]
01970c1c  80bc11780c120200         cmp byte ptr [rcx + rdx + 0x2120c78], 0
01970c24  741b                     je 0x1970c41
01970c26  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970c2a  c644035401               mov byte ptr [rbx + rax + 0x54], 1
01970c2f  80bd000100003a           cmp byte ptr [rbp + 0x100], 0x3a
01970c36  7509                     jne 0x1970c41
01970c38  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970c3c  c644035701               mov byte ptr [rbx + rax + 0x57], 1
01970c41  80bd000100007a           cmp byte ptr [rbp + 0x100], 0x7a
01970c48  751e                     jne 0x1970c68
01970c4a  c7858801000006001304     mov dword ptr [rbp + 0x188], 0x4130006
01970c54  48c7858001000008000000   mov qword ptr [rbp + 0x180], 8
01970c5f  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970c63  c644035701               mov byte ptr [rbx + rax + 0x57], 1
01970c68  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970c6c  48c7040380010000         mov qword ptr [rbx + rax], 0x180
01970c74  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
01970c78  0fb78588010000           movzx eax, word ptr [rbp + 0x188]
01970c7f  6689440b44               mov word ptr [rbx + rcx + 0x44], ax
01970c84  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
01970c88  8b8578010000             mov eax, dword ptr [rbp + 0x178]
01970c8e  89440b20                 mov dword ptr [rbx + rcx + 0x20], eax
01970c92  418d4c2401               lea ecx, [r12 + 1]
01970c97  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970c9b  48894c0308               mov qword ptr [rbx + rax + 8], rcx
01970ca0  8b8d80010000             mov ecx, dword ptr [rbp + 0x180]
01970ca6  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970caa  48894c0330               mov qword ptr [rbx + rax + 0x30], rcx
01970caf  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
01970cb3  0fb6858a010000           movzx eax, byte ptr [rbp + 0x18a]
01970cba  88440b50                 mov byte ptr [rbx + rcx + 0x50], al
01970cbe  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
01970cc2  0fb6858b010000           movzx eax, byte ptr [rbp + 0x18b]
01970cc9  88440b51                 mov byte ptr [rbx + rcx + 0x51], al
01970ccd  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970cd1  48897c0328               mov qword ptr [rbx + rax + 0x28], rdi
01970cd6  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970cda  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
01970ce1  894c0338                 mov dword ptr [rbx + rax + 0x38], ecx
01970ce5  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970ce9  894c033c                 mov dword ptr [rbx + rax + 0x3c], ecx
01970ced  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970cf1  894c0340                 mov dword ptr [rbx + rax + 0x40], ecx
01970cf5  0fb64530                 movzx eax, byte ptr [rbp + 0x30]
01970cf9  0410                     add al, 0x10
01970cfb  8bcf                     mov ecx, edi
01970cfd  3c01                     cmp al, 1
01970cff  0f474d44                 cmova ecx, dword ptr [rbp + 0x44]
01970d03  488b5620                 mov rdx, qword ptr [rsi + 0x20]
01970d07  4883c268                 add rdx, 0x68
01970d0b  4803d3                   add rdx, rbx
01970d0e  e89d5d75fe               call 0xc6ab0
01970d13  0fb64530                 movzx eax, byte ptr [rbp + 0x30]
01970d17  4c8d0de2f268fe           lea r9, [rip - 0x1970d1e]
01970d1e  420fb68c0810360202       movzx ecx, byte ptr [rax + r9 + 0x2023610]
01970d27  488b0592d36f00           mov rax, qword ptr [rip + 0x6fd392]
01970d2e  0fb71448                 movzx edx, word ptr [rax + rcx*2]
01970d32  0fb64d31                 movzx ecx, byte ptr [rbp + 0x31]
01970d36  f6d1                     not cl
01970d38  0fb7c2                   movzx eax, dx
01970d3b  66c1e808                 shr ax, 8
01970d3f  440fb6c0                 movzx r8d, al
01970d43  0fb6c2                   movzx eax, dl
01970d46  80e101                   and cl, 1
01970d49  440f45c0                 cmovne r8d, eax
01970d4d  418b4578                 mov eax, dword ptr [r13 + 0x78]
01970d51  83e802                   sub eax, 2
01970d54  83f801                   cmp eax, 1
01970d57  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970d5b  760a                     jbe 0x1970d67
01970d5d  c644035800               mov byte ptr [rbx + rax + 0x58], 0
01970d62  e9eb000000               jmp 0x1970e52
01970d67  c644035801               mov byte ptr [rbx + rax + 0x58], 1
01970d6c  0fb65530                 movzx edx, byte ptr [rbp + 0x30]
01970d70  b8ffff0000               mov eax, 0xffff
01970d75  66394540                 cmp word ptr [rbp + 0x40], ax
01970d79  7414                     je 0x1970d8f
01970d7b  410fb68c1110360202       movzx ecx, byte ptr [r9 + rdx + 0x2023610]
01970d84  4280bc099875ae0200       cmp byte ptr [rcx + r9 + 0x2ae7598], 0
01970d8d  7418                     je 0x1970da7
01970d8f  410fb68c1110360202       movzx ecx, byte ptr [r9 + rdx + 0x2023610]
01970d98  4280bc090082050200       cmp byte ptr [rcx + r9 + 0x2058200], 0
01970da1  0f84a2000000             je 0x1970e49
01970da7  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
01970dab  807c0b5d01               cmp byte ptr [rbx + rcx + 0x5d], 1
01970db0  0f8493000000             je 0x1970e49
01970db6  0fb64531                 movzx eax, byte ptr [rbp + 0x31]
01970dba  f6d0                     not al
01970dbc  a801                     test al, 1
01970dbe  7540                     jne 0x1970e00
01970dc0  41f6c020                 test r8b, 0x20
01970dc4  7409                     je 0x1970dcf
01970dc6  f6857801000010           test byte ptr [rbp + 0x178], 0x10
01970dcd  7431                     je 0x1970e00
01970dcf  418d40ce                 lea eax, [r8 - 0x32]
01970dd3  3c3a                     cmp al, 0x3a
01970dd5  7710                     ja 0x1970de7
01970dd7  48ba0100000000000005     movabs rdx, 0x500000000000001
01970de1  480fa3c2                 bt rdx, rax
01970de5  7219                     jb 0x1970e00
01970de7  4180f8ad                 cmp r8b, 0xad
01970deb  7413                     je 0x1970e00
01970ded  4180f824                 cmp r8b, 0x24
01970df1  740d                     je 0x1970e00
01970df3  4180f8ef                 cmp r8b, 0xef
01970df7  7407                     je 0x1970e00
01970df9  c6440b5500               mov byte ptr [rbx + rcx + 0x55], 0
01970dfe  eb52                     jmp 0x1970e52
01970e00  4584c0                   test r8b, r8b
01970e03  7907                     jns 0x1970e0c
01970e05  c6440b5502               mov byte ptr [rbx + rcx + 0x55], 2
01970e0a  eb15                     jmp 0x1970e21
01970e0c  41f6c00c                 test r8b, 0xc
01970e10  b801000000               mov eax, 1
01970e15  ba04000000               mov edx, 4
01970e1a  0f44c2                   cmove eax, edx
01970e1d  88440b55                 mov byte ptr [rbx + rcx + 0x55], al
01970e21  4180f868                 cmp r8b, 0x68
01970e25  7417                     je 0x1970e3e
01970e27  4180f832                 cmp r8b, 0x32
01970e2b  7411                     je 0x1970e3e
01970e2d  4180f8ad                 cmp r8b, 0xad
01970e31  751f                     jne 0x1970e52
01970e33  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970e37  c644035502               mov byte ptr [rbx + rax + 0x55], 2
01970e3c  eb14                     jmp 0x1970e52
01970e3e  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970e42  c644035501               mov byte ptr [rbx + rax + 0x55], 1
01970e47  eb09                     jmp 0x1970e52
01970e49  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970e4d  c644035508               mov byte ptr [rbx + rax + 0x55], 8
01970e52  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970e56  c644035b00               mov byte ptr [rbx + rax + 0x5b], 0
01970e5b  41837d7805               cmp dword ptr [r13 + 0x78], 5
01970e60  0f94c1                   sete cl
01970e63  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970e67  884c0359                 mov byte ptr [rbx + rax + 0x59], cl
01970e6b  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970e6f  c644035a00               mov byte ptr [rbx + rax + 0x5a], 0
01970e74  410fb6c0                 movzx eax, r8b
01970e78  83c0de                   add eax, -0x22
01970e7b  3dcf000000               cmp eax, 0xcf
01970e80  7723                     ja 0x1970ea5
01970e82  4898                     cdqe
01970e84  410fb6840144129701       movzx eax, byte ptr [r9 + rax + 0x1971244]
01970e8d  418b8c813c129701         mov ecx, dword ptr [r9 + rax*4 + 0x197123c]
01970e95  4903c9                   add rcx, r9
01970e98  ffe1                     jmp rcx
01970e9a  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970e9e  c644035601               mov byte ptr [rbx + rax + 0x56], 1
01970ea3  eb09                     jmp 0x1970eae
01970ea5  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970ea9  c644035600               mov byte ptr [rbx + rax + 0x56], 0
01970eae  498b07                   mov rax, qword ptr [r15]
01970eb1  498bcf                   mov rcx, r15
01970eb4  ff5010                   call qword ptr [rax + 0x10]
01970eb7  8b5008                   mov edx, dword ptr [rax + 8]
01970eba  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
01970ebe  428914a1                 mov dword ptr [rcx + r12*4], edx
01970ec2  b900010000               mov ecx, 0x100
01970ec7  3bd1                     cmp edx, ecx
01970ec9  0f47d1                   cmova edx, ecx
01970ecc  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
01970ed0  89540b78                 mov dword ptr [rbx + rcx + 0x78], edx
01970ed4  4863fa                   movsxd rdi, edx
01970ed7  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
01970edb  4883c17c                 add rcx, 0x7c
01970edf  4803cb                   add rcx, rbx
01970ee2  4c8bcf                   mov r9, rdi
01970ee5  4c8b00                   mov r8, qword ptr [rax]
01970ee8  ba02010000               mov edx, 0x102
01970eed  e8ee2269fe               call 0x31e0
01970ef2  48d1ef                   shr rdi, 1
01970ef5  4b8d0464                 lea rax, [r12 + r12*2]
01970ef9  48c1e006                 shl rax, 6
01970efd  4803f8                   add rdi, rax
01970f00  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970f04  4533c0                   xor r8d, r8d
01970f07  66448944787c             mov word ptr [rax + rdi*2 + 0x7c], r8w
01970f0d  418b4510                 mov eax, dword ptr [r13 + 0x10]
01970f11  480fbae00a               bt rax, 0xa
01970f16  7217                     jb 0x1970f2f
01970f18  498b07                   mov rax, qword ptr [r15]
01970f1b  498bcf                   mov rcx, r15
01970f1e  ff5030                   call qword ptr [rax + 0x30]
01970f21  4885c0                   test rax, rax
01970f24  7409                     je 0x1970f2f
01970f26  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970f2a  834c032020               or dword ptr [rbx + rax + 0x20], 0x20
01970f2f  418b4510                 mov eax, dword ptr [r13 + 0x10]
01970f33  480fbae009               bt rax, 9
01970f38  7212                     jb 0x1970f4c
01970f3a  f6855201000004           test byte ptr [rbp + 0x152], 4
01970f41  7409                     je 0x1970f4c
01970f43  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970f47  834c032020               or dword ptr [rbx + rax + 0x20], 0x20
01970f4c  41bfffffffff             mov r15d, 0xffffffff
01970f52  f6855401000020           test byte ptr [rbp + 0x154], 0x20
01970f59  7409                     je 0x1970f64
01970f5b  488b4620                 mov rax, qword ptr [rsi + 0x20]
01970f5f  834c032020               or dword ptr [rbx + rax + 0x20], 0x20
01970f64  488b4d20                 mov rcx, qword ptr [rbp + 0x20]
01970f68  4885c9                   test rcx, rcx
01970f6b  752e                     jne 0x1970f9b
01970f6d  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
01970f71  488b01                   mov rax, qword ptr [rcx]
01970f74  8b5518                   mov edx, dword ptr [rbp + 0x18]
01970f77  ff90d0000000             call qword ptr [rax + 0xd0]
01970f7d  8b4d1c                   mov ecx, dword ptr [rbp + 0x1c]
01970f80  3bc8                     cmp ecx, eax
01970f82  732d                     jae 0x1970fb1
01970f84  ffc1                     inc ecx
01970f86  894d1c                   mov dword ptr [rbp + 0x1c], ecx
01970f89  41ffc4                   inc r12d
01970f8c  44896550                 mov dword ptr [rbp + 0x50], r12d
01970f90  4c8b7560                 mov r14, qword ptr [rbp + 0x60]
01970f94  33ff                     xor edi, edi
01970f96  e985f6ffff               jmp 0x1970620
01970f9b  488b01                   mov rax, qword ptr [rcx]
01970f9e  488d5528                 lea rdx, [rbp + 0x28]
01970fa2  ff5010                   call qword ptr [rax + 0x10]
01970fa5  8b4d28                   mov ecx, dword ptr [rbp + 0x28]
01970fa8  84c0                     test al, al
01970faa  410f44cf                 cmove ecx, r15d
01970fae  894d28                   mov dword ptr [rbp + 0x28], ecx
01970fb1  41ffc4                   inc r12d
01970fb4  44896550                 mov dword ptr [rbp + 0x50], r12d
01970fb8  4c8b7560                 mov r14, qword ptr [rbp + 0x60]
01970fbc  33ff                     xor edi, edi
01970fbe  e95df6ffff               jmp 0x1970620
01970fc3  418b8518010000           mov eax, dword ptr [r13 + 0x118]
01970fca  894638                   mov dword ptr [rsi + 0x38], eax
01970fcd  85c0                     test eax, eax
01970fcf  0f8442020000             je 0x1971217
01970fd5  41bc01000000             mov r12d, 1
01970fdb  44896508                 mov dword ptr [rbp + 8], r12d
01970fdf  8bc8                     mov ecx, eax
01970fe1  b810000000               mov eax, 0x10
01970fe6  48f7e1                   mul rcx
01970fe9  49c7c7ffffffff           mov r15, 0xffffffffffffffff
01970ff0  490f40c7                 cmovo rax, r15
01970ff4  c644242005               mov byte ptr [rsp + 0x20], 5
01970ff9  41b94f050000             mov r9d, 0x54f
01970fff  4c8d050251b500           lea r8, [rip + 0xb55102]
01971006  488b5650                 mov rdx, qword ptr [rsi + 0x50]
0197100a  488bc8                   mov rcx, rax
0197100d  ff15e59e5500             call qword ptr [rip + 0x559ee5]
01971013  48894630                 mov qword ptr [rsi + 0x30], rax
01971017  448b4638                 mov r8d, dword ptr [rsi + 0x38]
0197101b  498d400f                 lea rax, [r8 + 0xf]
0197101f  48baf0ffffffffffff0f     movabs rdx, 0xffffffffffffff0
01971029  493bc0                   cmp rax, r8
0197102c  7703                     ja 0x1971031
0197102e  488bc2                   mov rax, rdx
01971031  4883e0f0                 and rax, 0xfffffffffffffff0
01971035  e8b60469fe               call 0x14f0
0197103a  482be0                   sub rsp, rax
0197103d  488d7c2450               lea rdi, [rsp + 0x50]
01971042  48897d60                 mov qword ptr [rbp + 0x60], rdi
01971046  8b4628                   mov eax, dword ptr [rsi + 0x28]
01971049  488d480f                 lea rcx, [rax + 0xf]
0197104d  483bc8                   cmp rcx, rax
01971050  7703                     ja 0x1971055
01971052  488bca                   mov rcx, rdx
01971055  4883e1f0                 and rcx, 0xfffffffffffffff0
01971059  488bc1                   mov rax, rcx
0197105c  e88f0469fe               call 0x14f0
01971061  482be1                   sub rsp, rcx
01971064  4c8d742450               lea r14, [rsp + 0x50]
01971069  4c897558                 mov qword ptr [rbp + 0x58], r14
0197106d  33d2                     xor edx, edx
0197106f  488bcf                   mov rcx, rdi
01971072  e87f1f69fe               call 0x2ff6
01971077  448b4628                 mov r8d, dword ptr [rsi + 0x28]
0197107b  33d2                     xor edx, edx
0197107d  498bce                   mov rcx, r14
01971080  e8711f69fe               call 0x2ff6
01971085  33c9                     xor ecx, ecx
01971087  448bf9                   mov r15d, ecx
0197108a  8b4638                   mov eax, dword ptr [rsi + 0x38]
0197108d  85c0                     test eax, eax
0197108f  0f84b7000000             je 0x197114c
01971095  4c8be7                   mov r12, rdi
01971098  0f1f840000000000         nop dword ptr [rax + rax]
019710a0  8bd9                     mov ebx, ecx
019710a2  837e2800                 cmp dword ptr [rsi + 0x28], 0
019710a6  0f8685000000             jbe 0x1971131
019710ac  458bf7                   mov r14d, r15d
019710af  90                       nop
019710b0  8bfb                     mov edi, ebx
019710b2  ffc3                     inc ebx
019710b4  488d0c7f                 lea rcx, [rdi + rdi*2]
019710b8  48c1e107                 shl rcx, 7
019710bc  4c8b4e20                 mov r9, qword ptr [rsi + 0x20]
019710c0  4983c17c                 add r9, 0x7c
019710c4  4c03c9                   add r9, rcx
019710c7  498b8d20010000           mov rcx, qword ptr [r13 + 0x120]
019710ce  498b9528010000           mov rdx, qword ptr [r13 + 0x128]
019710d5  488b4568                 mov rax, qword ptr [rbp + 0x68]
019710d9  8b04b8                   mov eax, dword ptr [rax + rdi*4]
019710dc  89442420                 mov dword ptr [rsp + 0x20], eax
019710e0  468b04b1                 mov r8d, dword ptr [rcx + r14*4]
019710e4  4a8b14f2                 mov rdx, qword ptr [rdx + r14*8]
019710e8  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
019710ef  ff152bac5500             call qword ptr [rip + 0x55ac2b]
019710f5  84c0                     test al, al
019710f7  7507                     jne 0x1971100
019710f9  3b5e28                   cmp ebx, dword ptr [rsi + 0x28]
019710fc  72b2                     jb 0x19710b0
019710fe  eb2f                     jmp 0x197112f
01971100  43fe0434                 inc byte ptr [r12 + r14]
01971104  488b4558                 mov rax, qword ptr [rbp + 0x58]
01971108  fe0407                   inc byte ptr [rdi + rax]
0197110b  498bd6                   mov rdx, r14
0197110e  4803d2                   add rdx, rdx
01971111  8bcb                     mov ecx, ebx
01971113  488b4630                 mov rax, qword ptr [rsi + 0x30]
01971117  48890cd0                 mov qword ptr [rax + rdx*8], rcx
0197111b  498b8530010000           mov rax, qword ptr [r13 + 0x130]
01971122  420fb60c30               movzx ecx, byte ptr [rax + r14]
01971127  488b4630                 mov rax, qword ptr [rsi + 0x30]
0197112b  894cd008                 mov dword ptr [rax + rdx*8 + 8], ecx
0197112f  33c9                     xor ecx, ecx
01971131  41ffc7                   inc r15d
01971134  8b4638                   mov eax, dword ptr [rsi + 0x38]
01971137  443bf8                   cmp r15d, eax
0197113a  0f8260ffffff             jb 0x19710a0
01971140  448b6508                 mov r12d, dword ptr [rbp + 8]
01971144  488b7d60                 mov rdi, qword ptr [rbp + 0x60]
01971148  4c8b7558                 mov r14, qword ptr [rbp + 0x58]
0197114c  8bd9                     mov ebx, ecx
0197114e  85c0                     test eax, eax
01971150  7450                     je 0x19711a2
01971152  41be01000000             mov r14d, 1
01971158  4585e4                   test r12d, r12d
0197115b  7441                     je 0x197119e
0197115d  8bd3                     mov edx, ebx
0197115f  803c3a00                 cmp byte ptr [rdx + rdi], 0
01971163  7532                     jne 0x1971197
01971165  448be1                   mov r12d, ecx
01971168  498b8528010000           mov rax, qword ptr [r13 + 0x128]
0197116f  498b8d20010000           mov rcx, qword ptr [r13 + 0x120]
01971176  488b04d0                 mov rax, qword ptr [rax + rdx*8]
0197117a  4889442420               mov qword ptr [rsp + 0x20], rax
0197117f  448b0c91                 mov r9d, dword ptr [rcx + rdx*4]
01971183  458bc6                   mov r8d, r14d
01971186  ba0a000000               mov edx, 0xa
0197118b  b9d1120000               mov ecx, 0x12d1
01971190  e8ab428afe               call 0x215440
01971195  33c9                     xor ecx, ecx
01971197  ffc3                     inc ebx
01971199  3b5e38                   cmp ebx, dword ptr [rsi + 0x38]
0197119c  72ba                     jb 0x1971158
0197119e  4c8b7558                 mov r14, qword ptr [rbp + 0x58]
019711a2  8bd9                     mov ebx, ecx
019711a4  837e2800                 cmp dword ptr [rsi + 0x28], 0
019711a8  7653                     jbe 0x19711fd
019711aa  660f1f0400               nop word ptr [rax + rax]
019711af  90                       nop
019711b0  4585e4                   test r12d, r12d
019711b3  744d                     je 0x1971202
019711b5  8bd3                     mov edx, ebx
019711b7  42803c3201               cmp byte ptr [rdx + r14], 1
019711bc  7638                     jbe 0x19711f6
019711be  448be1                   mov r12d, ecx
019711c1  488d0c52                 lea rcx, [rdx + rdx*2]
019711c5  48c1e107                 shl rcx, 7
019711c9  488b4620                 mov rax, qword ptr [rsi + 0x20]
019711cd  4883c07c                 add rax, 0x7c
019711d1  4803c8                   add rcx, rax
019711d4  48894c2420               mov qword ptr [rsp + 0x20], rcx
019711d9  488b4568                 mov rax, qword ptr [rbp + 0x68]
019711dd  448b0c90                 mov r9d, dword ptr [rax + rdx*4]
019711e1  ba0a000000               mov edx, 0xa
019711e6  b9d2120000               mov ecx, 0x12d2
019711eb  448d42f7                 lea r8d, [rdx - 9]
019711ef  e84c428afe               call 0x215440
019711f4  33c9                     xor ecx, ecx
019711f6  ffc3                     inc ebx
019711f8  3b5e28                   cmp ebx, dword ptr [rsi + 0x28]
019711fb  72b3                     jb 0x19711b0
019711fd  4585e4                   test r12d, r12d
01971200  7515                     jne 0x1971217
01971202  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
01971206  ff159c9d5500             call qword ptr [rip + 0x559d9c]
0197120c  4533c0                   xor r8d, r8d
0197120f  4c894630                 mov qword ptr [rsi + 0x30], r8
01971213  44894638                 mov dword ptr [rsi + 0x38], r8d
01971217  488b8d10020000           mov rcx, qword ptr [rbp + 0x210]
0197121e  4833cd                   xor rcx, rbp
01971221  e84afe68fe               call 0x1070
01971226  488da528020000           lea rsp, [rbp + 0x228]
0197122d  415f                     pop r15
0197122f  415e                     pop r14
01971231  415d                     pop r13
01971233  415c                     pop r12
01971235  5f                       pop rdi
01971236  5e                       pop rsi
01971237  5b                       pop rbx
01971238  5d                       pop rbp
01971239  c3                       ret
0197123a  90                       nop
0197123b  90                       nop
