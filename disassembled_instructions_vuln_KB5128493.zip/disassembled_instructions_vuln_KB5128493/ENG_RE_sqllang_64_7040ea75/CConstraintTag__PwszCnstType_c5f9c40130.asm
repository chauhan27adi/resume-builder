; CConstraintTag::PwszCnstType
; sqllang.dll, primary RVA 0x1773810, 572 bytes in 1 chunk(s)

; chunk at RVA 0x1773810 (572 bytes)
01773810  4883ec28                 sub rsp, 0x28
01773814  8b4110                   mov eax, dword ptr [rcx + 0x10]
01773817  25ff010000               and eax, 0x1ff
0177381c  83f822                   cmp eax, 0x22
0177381f  0f878f010000             ja 0x17739b4
01773825  4c8d05d4c788fe           lea r8, [rip - 0x177382c]
0177382c  4898                     cdqe
0177382e  418b8c80c0397701         mov ecx, dword ptr [r8 + rax*4 + 0x17739c0]
01773836  4903c8                   add rcx, r8
01773839  ffe1                     jmp rcx
0177383b  488d057e8fc300           lea rax, [rip + 0xc38f7e]
01773842  4883c428                 add rsp, 0x28
01773846  c3                       ret
01773847  488d05b23fd400           lea rax, [rip + 0xd43fb2]
0177384e  4883c428                 add rsp, 0x28
01773852  c3                       ret
01773853  488b02                   mov rax, qword ptr [rdx]
01773856  488bca                   mov rcx, rdx
01773859  ff90a0000000             call qword ptr [rax + 0xa0]
0177385f  4885c0                   test rax, rax
01773862  488d15773fd400           lea rdx, [rip + 0xd43f77]
01773869  488d0df0c7b400           lea rcx, [rip + 0xb4c7f0]
01773870  480f45ca                 cmovne rcx, rdx
01773874  488bc1                   mov rax, rcx
01773877  4883c428                 add rsp, 0x28
0177387b  c3                       ret
0177387c  488d05c55ec600           lea rax, [rip + 0xc65ec5]
01773883  4883c428                 add rsp, 0x28
01773887  c3                       ret
01773888  488d054150a400           lea rax, [rip + 0xa45041]
0177388f  4883c428                 add rsp, 0x28
01773893  c3                       ret
01773894  488d0595c7b400           lea rax, [rip + 0xb4c795]
0177389b  4883c428                 add rsp, 0x28
0177389f  c3                       ret
017738a0  488d0559c7b400           lea rax, [rip + 0xb4c759]
017738a7  4883c428                 add rsp, 0x28
017738ab  c3                       ret
017738ac  488d05dd93c300           lea rax, [rip + 0xc393dd]
017738b3  4883c428                 add rsp, 0x28
017738b7  c3                       ret
017738b8  488d05e9c7b400           lea rax, [rip + 0xb4c7e9]
017738bf  4883c428                 add rsp, 0x28
017738c3  c3                       ret
017738c4  488d05d5219b00           lea rax, [rip + 0x9b21d5]
017738cb  4883c428                 add rsp, 0x28
017738cf  c3                       ret
017738d0  488d05a1c7b400           lea rax, [rip + 0xb4c7a1]
017738d7  4883c428                 add rsp, 0x28
017738db  c3                       ret
017738dc  488d050d40d400           lea rax, [rip + 0xd4400d]
017738e3  4883c428                 add rsp, 0x28
017738e7  c3                       ret
017738e8  488d05e13fd400           lea rax, [rip + 0xd43fe1]
017738ef  4883c428                 add rsp, 0x28
017738f3  c3                       ret
017738f4  488d05b53fd400           lea rax, [rip + 0xd43fb5]
017738fb  4883c428                 add rsp, 0x28
017738ff  c3                       ret
01773900  488d05793fd400           lea rax, [rip + 0xd43f79]
01773907  4883c428                 add rsp, 0x28
0177390b  c3                       ret
0177390c  488d052d3fd400           lea rax, [rip + 0xd43f2d]
01773913  4883c428                 add rsp, 0x28
01773917  c3                       ret
01773918  488d05f93ed400           lea rax, [rip + 0xd43ef9]
0177391f  4883c428                 add rsp, 0x28
01773923  c3                       ret
01773924  488d05bd40d400           lea rax, [rip + 0xd440bd]
0177392b  4883c428                 add rsp, 0x28
0177392f  c3                       ret
01773930  654c8b042558000000       mov r8, qword ptr gs:[0x58]
01773939  488b0538767500           mov rax, qword ptr [rip + 0x757638]
01773940  8b10                     mov edx, dword ptr [rax]
01773942  488b0537767500           mov rax, qword ptr [rip + 0x757637]
01773949  8b08                     mov ecx, dword ptr [rax]
0177394b  498b04d0                 mov rax, qword ptr [r8 + rdx*8]
0177394f  488b0c01                 mov rcx, qword ptr [rcx + rax]
01773953  488b4148                 mov rax, qword ptr [rcx + 0x48]
01773957  83b8e403000002           cmp dword ptr [rax + 0x3e4], 2
0177395e  750c                     jne 0x177396c
01773960  488d056940d400           lea rax, [rip + 0xd44069]
01773967  4883c428                 add rsp, 0x28
0177396b  c3                       ret
0177396c  488d054540d400           lea rax, [rip + 0xd44045]
01773973  4883c428                 add rsp, 0x28
01773977  c3                       ret
01773978  488d052140d400           lea rax, [rip + 0xd44021]
0177397f  4883c428                 add rsp, 0x28
01773983  c3                       ret
01773984  488d05f53fd400           lea rax, [rip + 0xd43ff5]
0177398b  4883c428                 add rsp, 0x28
0177398f  c3                       ret
01773990  488d05b13fd400           lea rax, [rip + 0xd43fb1]
01773997  4883c428                 add rsp, 0x28
0177399b  c3                       ret
0177399c  488d05458fc300           lea rax, [rip + 0xc38f45]
017739a3  4883c428                 add rsp, 0x28
017739a7  c3                       ret
017739a8  488d05613fd400           lea rax, [rip + 0xd43f61]
017739af  4883c428                 add rsp, 0x28
017739b3  c3                       ret
017739b4  488d05b54dba00           lea rax, [rip + 0xba4db5]
017739bb  4883c428                 add rsp, 0x28
017739bf  c3                       ret
017739c0  3b38                     cmp edi, dword ptr [rax]
017739c2  7701                     ja 0x17739c5
017739c4  47387701                 cmp byte ptr [r15 + 1], r14b
017739c8  53                       push rbx
017739c9  387701                   cmp byte ptr [rdi + 1], dh
017739cc  7c38                     jl 0x1773a06
017739ce  7701                     ja 0x17739d1
017739d0  8838                     mov byte ptr [rax], bh
017739d2  7701                     ja 0x17739d5
017739d4  8838                     mov byte ptr [rax], bh
017739d6  7701                     ja 0x17739d9
017739d8  8838                     mov byte ptr [rax], bh
017739da  7701                     ja 0x17739dd
017739dc  94                       xchg esp, eax
017739dd  387701                   cmp byte ptr [rdi + 1], dh
017739e0  a0387701ac387701c4       movabs al, byte ptr [0xc4017738ac017738]
017739e9  387701                   cmp byte ptr [rdi + 1], dh
017739ec  d038                     sar byte ptr [rax], 1
017739ee  7701                     ja 0x17739f1
017739f0  e8387701dc               call 0xffffffffdd78b12d
017739f5  387701                   cmp byte ptr [rdi + 1], dh
017739f8  f4                       hlt
017739f9  387701                   cmp byte ptr [rdi + 1], dh
017739fc  0039                     add byte ptr [rcx], bh
017739fe  7701                     ja 0x1773a01
01773a00  0c39                     or al, 0x39
01773a02  7701                     ja 0x1773a05
01773a04  1839                     sbb byte ptr [rcx], bh
01773a06  7701                     ja 0x1773a09
01773a08  b439                     mov ah, 0x39
01773a0a  7701                     ja 0x1773a0d
01773a0c  b439                     mov ah, 0x39
01773a0e  7701                     ja 0x1773a11
01773a10  b439                     mov ah, 0x39
01773a12  7701                     ja 0x1773a15
01773a14  2439                     and al, 0x39
01773a16  7701                     ja 0x1773a19
01773a18  b439                     mov ah, 0x39
01773a1a  7701                     ja 0x1773a1d
01773a1c  b439                     mov ah, 0x39
01773a1e  7701                     ja 0x1773a21
01773a20  b439                     mov ah, 0x39
01773a22  7701                     ja 0x1773a25
01773a24  b439                     mov ah, 0x39
01773a26  7701                     ja 0x1773a29
01773a28  3039                     xor byte ptr [rcx], bh
01773a2a  7701                     ja 0x1773a2d
01773a2c  b8387701b4               mov eax, 0xb4017738
01773a31  397701                   cmp dword ptr [rdi + 1], esi
01773a34  b439                     mov ah, 0x39
01773a36  7701                     ja 0x1773a39
01773a38  7839                     js 0x1773a73
01773a3a  7701                     ja 0x1773a3d
01773a3c  8439                     test byte ptr [rcx], bh
01773a3e  7701                     ja 0x1773a41
01773a40  90                       nop
01773a41  397701                   cmp dword ptr [rdi + 1], esi
01773a44  9c                       pushfq
01773a45  397701                   cmp dword ptr [rdi + 1], esi
01773a48  a839                     test al, 0x39
01773a4a  7701                     ja 0x1773a4d
