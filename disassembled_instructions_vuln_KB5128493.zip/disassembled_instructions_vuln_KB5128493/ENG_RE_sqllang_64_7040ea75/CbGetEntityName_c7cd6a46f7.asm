; CbGetEntityName
; sqllang.dll, primary RVA 0x770ff0, 1744 bytes in 1 chunk(s)

; chunk at RVA 0x770ff0 (1744 bytes)
00770ff0  4055                     push rbp
00770ff2  56                       push rsi
00770ff3  57                       push rdi
00770ff4  4154                     push r12
00770ff6  4155                     push r13
00770ff8  4156                     push r14
00770ffa  4157                     push r15
00770ffc  4881ecf0010000           sub rsp, 0x1f0
00771003  488d6c2440               lea rbp, [rsp + 0x40]
00771008  48c74528feffffff         mov qword ptr [rbp + 0x28], 0xfffffffffffffffe
00771010  48899df8010000           mov qword ptr [rbp + 0x1f8], rbx
00771017  488b056a8c3602           mov rax, qword ptr [rip + 0x2368c6a]
0077101e  4833c5                   xor rax, rbp
00771021  488985a0010000           mov qword ptr [rbp + 0x1a0], rax
00771028  498bd9                   mov rbx, r9
0077102b  4d8bf8                   mov r15, r8
0077102e  4c8bad10020000           mov r13, qword ptr [rbp + 0x210]
00771035  8b7108                   mov esi, dword ptr [rcx + 8]
00771038  448b7128                 mov r14d, dword ptr [rcx + 0x28]
0077103c  8b4148                   mov eax, dword ptr [rcx + 0x48]
0077103f  33ff                     xor edi, edi
00771041  448be7                   mov r12d, edi
00771044  8b8d18020000             mov ecx, dword ptr [rbp + 0x218]
0077104a  83f821                   cmp eax, 0x21
0077104d  0f8754050000             ja 0x7715a7
00771053  488d15a6ef88ff           lea rdx, [rip - 0x77105a]
0077105a  448b848238167700         mov r8d, dword ptr [rdx + rax*4 + 0x771638]
00771062  4c03c2                   add r8, rdx
00771065  41ffe0                   jmp r8
00771068  498b01                   mov rax, qword ptr [r9]
0077106b  41b101                   mov r9b, 1
0077106e  4533c0                   xor r8d, r8d
00771071  8bd6                     mov edx, esi
00771073  488bcb                   mov rcx, rbx
00771076  ff9068010000             call qword ptr [rax + 0x168]
0077107c  488bc8                   mov rcx, rax
0077107f  4885c0                   test rax, rax
00771082  0f8415050000             je 0x77159d
00771088  488b00                   mov rax, qword ptr [rax]
0077108b  ff10                     call qword ptr [rax]
0077108d  e9f1040000               jmp 0x771583
00771092  498b01                   mov rax, qword ptr [r9]
00771095  41b101                   mov r9b, 1
00771098  4533c0                   xor r8d, r8d
0077109b  8bd6                     mov edx, esi
0077109d  488bcb                   mov rcx, rbx
007710a0  ff90e8000000             call qword ptr [rax + 0xe8]
007710a6  ebd4                     jmp 0x77107c
007710a8  498b01                   mov rax, qword ptr [r9]
007710ab  41b101                   mov r9b, 1
007710ae  4533c0                   xor r8d, r8d
007710b1  8bd6                     mov edx, esi
007710b3  488bcb                   mov rcx, rbx
007710b6  ff90d8000000             call qword ptr [rax + 0xd8]
007710bc  ebbe                     jmp 0x77107c
007710be  498b01                   mov rax, qword ptr [r9]
007710c1  41b101                   mov r9b, 1
007710c4  4533c0                   xor r8d, r8d
007710c7  8bd6                     mov edx, esi
007710c9  488bcb                   mov rcx, rbx
007710cc  ff9068010000             call qword ptr [rax + 0x168]
007710d2  488bf0                   mov rsi, rax
007710d5  4885c0                   test rax, rax
007710d8  0f84bf040000             je 0x77159d
007710de  488b00                   mov rax, qword ptr [rax]
007710e1  488d9560010000           lea rdx, [rbp + 0x160]
007710e8  488bce                   mov rcx, rsi
007710eb  ff5030                   call qword ptr [rax + 0x30]
007710ee  80bd60010000f3           cmp byte ptr [rbp + 0x160], 0xf3
007710f5  0f85a2040000             jne 0x77159d
007710fb  488b06                   mov rax, qword ptr [rsi]
007710fe  488bce                   mov rcx, rsi
00771101  ff5058                   call qword ptr [rax + 0x58]
00771104  4c8b13                   mov r10, qword ptr [rbx]
00771107  897c2438                 mov dword ptr [rsp + 0x38], edi
0077110b  897c2430                 mov dword ptr [rsp + 0x30], edi
0077110f  c644242801               mov byte ptr [rsp + 0x28], 1
00771114  40887c2420               mov byte ptr [rsp + 0x20], dil
00771119  4533c9                   xor r9d, r9d
0077111c  41b001                   mov r8b, 1
0077111f  8bd0                     mov edx, eax
00771121  488bcb                   mov rcx, rbx
00771124  41ff5278                 call qword ptr [r10 + 0x78]
00771128  488bc8                   mov rcx, rax
0077112b  4885c0                   test rax, rax
0077112e  0f8469040000             je 0x77159d
00771134  488b00                   mov rax, qword ptr [rax]
00771137  ff5078                   call qword ptr [rax + 0x78]
0077113a  488bc8                   mov rcx, rax
0077113d  4885c0                   test rax, rax
00771140  0f8457040000             je 0x77159d
00771146  488b00                   mov rax, qword ptr [rax]
00771149  4533c0                   xor r8d, r8d
0077114c  418bd6                   mov edx, r14d
0077114f  ff5028                   call qword ptr [rax + 0x28]
00771152  488bc8                   mov rcx, rax
00771155  4885c0                   test rax, rax
00771158  0f843f040000             je 0x77159d
0077115e  488b00                   mov rax, qword ptr [rax]
00771161  ff5010                   call qword ptr [rax + 0x10]
00771164  e91a040000               jmp 0x771583
00771169  498b01                   mov rax, qword ptr [r9]
0077116c  897c2438                 mov dword ptr [rsp + 0x38], edi
00771170  897c2430                 mov dword ptr [rsp + 0x30], edi
00771174  c644242801               mov byte ptr [rsp + 0x28], 1
00771179  40887c2420               mov byte ptr [rsp + 0x20], dil
0077117e  4533c9                   xor r9d, r9d
00771181  41b001                   mov r8b, 1
00771184  8bd6                     mov edx, esi
00771186  488bcb                   mov rcx, rbx
00771189  ff5078                   call qword ptr [rax + 0x78]
0077118c  4885c0                   test rax, rax
0077118f  0f8408040000             je 0x77159d
00771195  488b10                   mov rdx, qword ptr [rax]
00771198  488bc8                   mov rcx, rax
0077119b  4585f6                   test r14d, r14d
0077119e  7405                     je 0x7711a5
007711a0  ff5278                   call qword ptr [rdx + 0x78]
007711a3  eb95                     jmp 0x77113a
007711a5  ff5228                   call qword ptr [rdx + 0x28]
007711a8  e9d6030000               jmp 0x771583
007711ad  498b01                   mov rax, qword ptr [r9]
007711b0  897c2438                 mov dword ptr [rsp + 0x38], edi
007711b4  897c2430                 mov dword ptr [rsp + 0x30], edi
007711b8  c644242801               mov byte ptr [rsp + 0x28], 1
007711bd  40887c2420               mov byte ptr [rsp + 0x20], dil
007711c2  4533c9                   xor r9d, r9d
007711c5  41b001                   mov r8b, 1
007711c8  8bd6                     mov edx, esi
007711ca  488bcb                   mov rcx, rbx
007711cd  ff5078                   call qword ptr [rax + 0x78]
007711d0  488bc8                   mov rcx, rax
007711d3  4885c0                   test rax, rax
007711d6  0f84c1030000             je 0x77159d
007711dc  488b00                   mov rax, qword ptr [rax]
007711df  ff90a8000000             call qword ptr [rax + 0xa8]
007711e5  488bd8                   mov rbx, rax
007711e8  4885c0                   test rax, rax
007711eb  0f84ac030000             je 0x77159d
007711f1  488b00                   mov rax, qword ptr [rax]
007711f4  488bcb                   mov rcx, rbx
007711f7  ff5038                   call qword ptr [rax + 0x38]
007711fa  443bf0                   cmp r14d, eax
007711fd  0f879a030000             ja 0x77159d
00771203  0faee8                   lfence
00771206  488b03                   mov rax, qword ptr [rbx]
00771209  418bd6                   mov edx, r14d
0077120c  488bcb                   mov rcx, rbx
0077120f  ff5040                   call qword ptr [rax + 0x40]
00771212  e93bffffff               jmp 0x771152
00771217  498b01                   mov rax, qword ptr [r9]
0077121a  897c2438                 mov dword ptr [rsp + 0x38], edi
0077121e  897c2430                 mov dword ptr [rsp + 0x30], edi
00771222  c644242801               mov byte ptr [rsp + 0x28], 1
00771227  40887c2420               mov byte ptr [rsp + 0x20], dil
0077122c  4533c9                   xor r9d, r9d
0077122f  41b001                   mov r8b, 1
00771232  8bd6                     mov edx, esi
00771234  488bcb                   mov rcx, rbx
00771237  ff5078                   call qword ptr [rax + 0x78]
0077123a  488bc8                   mov rcx, rax
0077123d  4885c0                   test rax, rax
00771240  0f8457030000             je 0x77159d
00771246  488b00                   mov rax, qword ptr [rax]
00771249  ff5078                   call qword ptr [rax + 0x78]
0077124c  488bf0                   mov rsi, rax
0077124f  4885c0                   test rax, rax
00771252  0f8445030000             je 0x77159d
00771258  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00771261  488b05109d7501           mov rax, qword ptr [rip + 0x1759d10]
00771268  8b08                     mov ecx, dword ptr [rax]
0077126a  488b050f9d7501           mov rax, qword ptr [rip + 0x1759d0f]
00771271  8b18                     mov ebx, dword ptr [rax]
00771273  48031cca                 add rbx, qword ptr [rdx + rcx*8]
00771277  488b8300010000           mov rax, qword ptr [rbx + 0x100]
0077127e  4885c0                   test rax, rax
00771281  750f                     jne 0x771292
00771283  33c9                     xor ecx, ecx
00771285  ff15059d7501             call qword ptr [rip + 0x1759d05]
0077128b  488b8300010000           mov rax, qword ptr [rbx + 0x100]
00771292  488b80e8030000           mov rax, qword ptr [rax + 0x3e8]
00771299  48894500                 mov qword ptr [rbp], rax
0077129d  4c897d08                 mov qword ptr [rbp + 8], r15
007712a1  48897510                 mov qword ptr [rbp + 0x10], rsi
007712a5  48897d18                 mov qword ptr [rbp + 0x18], rdi
007712a9  48897d20                 mov qword ptr [rbp + 0x20], rdi
007712ad  488d4518                 lea rax, [rbp + 0x18]
007712b1  48894520                 mov qword ptr [rbp + 0x20], rax
007712b5  488d4518                 lea rax, [rbp + 0x18]
007712b9  48894518                 mov qword ptr [rbp + 0x18], rax
007712bd  418bd6                   mov edx, r14d
007712c0  488d4d00                 lea rcx, [rbp]
007712c4  e817d10300               call 0x7ae3e0
007712c9  488bd8                   mov rbx, rax
007712cc  4885c0                   test rax, rax
007712cf  746b                     je 0x77133c
007712d1  488b00                   mov rax, qword ptr [rax]
007712d4  488bcb                   mov rcx, rbx
007712d7  ff5038                   call qword ptr [rax + 0x38]
007712da  84c0                     test al, al
007712dc  745e                     je 0x77133c
007712de  488b03                   mov rax, qword ptr [rbx]
007712e1  488bcb                   mov rcx, rbx
007712e4  ff10                     call qword ptr [rax]
007712e6  488bd8                   mov rbx, rax
007712e9  0f1f8000000000           nop dword ptr [rax]
007712f0  488d4518                 lea rax, [rbp + 0x18]
007712f4  488b5520                 mov rdx, qword ptr [rbp + 0x20]
007712f8  483bd0                   cmp rdx, rax
007712fb  0f8485020000             je 0x771586
00771301  488d42f8                 lea rax, [rdx - 8]
00771305  488bcf                   mov rcx, rdi
00771308  4885d2                   test rdx, rdx
0077130b  480f45c8                 cmovne rcx, rax
0077130f  4885c9                   test rcx, rcx
00771312  0f846e020000             je 0x771586
00771318  488b5110                 mov rdx, qword ptr [rcx + 0x10]
0077131c  488b4108                 mov rax, qword ptr [rcx + 8]
00771320  48895008                 mov qword ptr [rax + 8], rdx
00771324  488902                   mov qword ptr [rdx], rax
00771327  48897910                 mov qword ptr [rcx + 0x10], rdi
0077132b  48897908                 mov qword ptr [rcx + 8], rdi
0077132f  ba20000000               mov edx, 0x20
00771334  ff154e9c7501             call qword ptr [rip + 0x1759c4e]
0077133a  ebb4                     jmp 0x7712f0
0077133c  0f1f00                   nop dword ptr [rax]
0077133f  90                       nop
00771340  488d4518                 lea rax, [rbp + 0x18]
00771344  488b5520                 mov rdx, qword ptr [rbp + 0x20]
00771348  483bd0                   cmp rdx, rax
0077134b  0f844c020000             je 0x77159d
00771351  488d42f8                 lea rax, [rdx - 8]
00771355  488bcf                   mov rcx, rdi
00771358  4885d2                   test rdx, rdx
0077135b  480f45c8                 cmovne rcx, rax
0077135f  4885c9                   test rcx, rcx
00771362  0f8435020000             je 0x77159d
00771368  488b5110                 mov rdx, qword ptr [rcx + 0x10]
0077136c  488b4108                 mov rax, qword ptr [rcx + 8]
00771370  48895008                 mov qword ptr [rax + 8], rdx
00771374  488902                   mov qword ptr [rdx], rax
00771377  48897910                 mov qword ptr [rcx + 0x10], rdi
0077137b  48897908                 mov qword ptr [rcx + 8], rdi
0077137f  ba20000000               mov edx, 0x20
00771384  ff15fe9b7501             call qword ptr [rip + 0x1759bfe]
0077138a  ebb4                     jmp 0x771340
0077138c  498b01                   mov rax, qword ptr [r9]
0077138f  4533c0                   xor r8d, r8d
00771392  8bd6                     mov edx, esi
00771394  488bcb                   mov rcx, rbx
00771397  ff9098010000             call qword ptr [rax + 0x198]
0077139d  488bc8                   mov rcx, rax
007713a0  4885c0                   test rax, rax
007713a3  0f84f4010000             je 0x77159d
007713a9  488b00                   mov rax, qword ptr [rax]
007713ac  ff5018                   call qword ptr [rax + 0x18]
007713af  e9cf010000               jmp 0x771583
007713b4  498b01                   mov rax, qword ptr [r9]
007713b7  41b101                   mov r9b, 1
007713ba  450fb6c1                 movzx r8d, r9b
007713be  8bd6                     mov edx, esi
007713c0  488bcb                   mov rcx, rbx
007713c3  ff90a8020000             call qword ptr [rax + 0x2a8]
007713c9  e984fdffff               jmp 0x771152
007713ce  498b01                   mov rax, qword ptr [r9]
007713d1  41b101                   mov r9b, 1
007713d4  450fb6c1                 movzx r8d, r9b
007713d8  8bd6                     mov edx, esi
007713da  488bcb                   mov rcx, rbx
007713dd  ff9088020000             call qword ptr [rax + 0x288]
007713e3  e96afdffff               jmp 0x771152
007713e8  33d2                     xor edx, edx
007713ea  41b828010000             mov r8d, 0x128
007713f0  488d4d30                 lea rcx, [rbp + 0x30]
007713f4  e8fd1b89ff               call 0x2ff6
007713f9  8b0424                   mov eax, dword ptr [rsp]
007713fc  b800010000               mov eax, 0x100
00771401  482be0                   sub rsp, rax
00771404  488d4c2440               lea rcx, [rsp + 0x40]
00771409  8b01                     mov eax, dword ptr [rcx]
0077140b  48894d68                 mov qword ptr [rbp + 0x68], rcx
0077140f  c7457800010000           mov dword ptr [rbp + 0x78], 0x100
00771416  488b03                   mov rax, qword ptr [rbx]
00771419  33d2                     xor edx, edx
0077141b  488bcb                   mov rcx, rbx
0077141e  ff90d0020000             call qword ptr [rax + 0x2d0]
00771424  4c8b08                   mov r9, qword ptr [rax]
00771427  4c8d4530                 lea r8, [rbp + 0x30]
0077142b  8bd6                     mov edx, esi
0077142d  488bc8                   mov rcx, rax
00771430  41ff5118                 call qword ptr [r9 + 0x18]
00771434  488b7d68                 mov rdi, qword ptr [rbp + 0x68]
00771438  448b6578                 mov r12d, dword ptr [rbp + 0x78]
0077143c  e951010000               jmp 0x771592
00771441  498b01                   mov rax, qword ptr [r9]
00771444  4533c0                   xor r8d, r8d
00771447  8bd6                     mov edx, esi
00771449  488bcb                   mov rcx, rbx
0077144c  ff90f8010000             call qword ptr [rax + 0x1f8]
00771452  e925fcffff               jmp 0x77107c
00771457  498b01                   mov rax, qword ptr [r9]
0077145a  4533c0                   xor r8d, r8d
0077145d  8bd6                     mov edx, esi
0077145f  488bcb                   mov rcx, rbx
00771462  ff90e8010000             call qword ptr [rax + 0x1e8]
00771468  e90ffcffff               jmp 0x77107c
0077146d  498b01                   mov rax, qword ptr [r9]
00771470  4533c0                   xor r8d, r8d
00771473  8bd6                     mov edx, esi
00771475  488bcb                   mov rcx, rbx
00771478  ff90d8010000             call qword ptr [rax + 0x1d8]
0077147e  e9f9fbffff               jmp 0x77107c
00771483  498b01                   mov rax, qword ptr [r9]
00771486  4533c0                   xor r8d, r8d
00771489  8bd6                     mov edx, esi
0077148b  488bcb                   mov rcx, rbx
0077148e  ff9078010000             call qword ptr [rax + 0x178]
00771494  e9dc000000               jmp 0x771575
00771499  498b01                   mov rax, qword ptr [r9]
0077149c  4533c0                   xor r8d, r8d
0077149f  8bd6                     mov edx, esi
007714a1  488bcb                   mov rcx, rbx
007714a4  ff9068020000             call qword ptr [rax + 0x268]
007714aa  488bc8                   mov rcx, rax
007714ad  4885c0                   test rax, rax
007714b0  0f84e7000000             je 0x77159d
007714b6  488b00                   mov rax, qword ptr [rax]
007714b9  ff5008                   call qword ptr [rax + 8]
007714bc  e9c2000000               jmp 0x771583
007714c1  498b01                   mov rax, qword ptr [r9]
007714c4  4533c0                   xor r8d, r8d
007714c7  8bd6                     mov edx, esi
007714c9  488bcb                   mov rcx, rbx
007714cc  ff9038020000             call qword ptr [rax + 0x238]
007714d2  ebd6                     jmp 0x7714aa
007714d4  498b01                   mov rax, qword ptr [r9]
007714d7  41b101                   mov r9b, 1
007714da  450fb6c1                 movzx r8d, r9b
007714de  8bd6                     mov edx, esi
007714e0  488bcb                   mov rcx, rbx
007714e3  ff9090030000             call qword ptr [rax + 0x390]
007714e9  e98efbffff               jmp 0x77107c
007714ee  498b01                   mov rax, qword ptr [r9]
007714f1  4533c0                   xor r8d, r8d
007714f4  8bd6                     mov edx, esi
007714f6  488bcb                   mov rcx, rbx
007714f9  ff9028030000             call qword ptr [rax + 0x328]
007714ff  e978fbffff               jmp 0x77107c
00771504  498b01                   mov rax, qword ptr [r9]
00771507  4533c0                   xor r8d, r8d
0077150a  8bd6                     mov edx, esi
0077150c  488bcb                   mov rcx, rbx
0077150f  ff90b8030000             call qword ptr [rax + 0x3b8]
00771515  e962fbffff               jmp 0x77107c
0077151a  498b01                   mov rax, qword ptr [r9]
0077151d  4533c0                   xor r8d, r8d
00771520  8bd6                     mov edx, esi
00771522  488bcb                   mov rcx, rbx
00771525  ff90e0030000             call qword ptr [rax + 0x3e0]
0077152b  e922fcffff               jmp 0x771152
00771530  498b01                   mov rax, qword ptr [r9]
00771533  4533c0                   xor r8d, r8d
00771536  8bd6                     mov edx, esi
00771538  488bcb                   mov rcx, rbx
0077153b  ff9008020000             call qword ptr [rax + 0x208]
00771541  e964ffffff               jmp 0x7714aa
00771546  498b01                   mov rax, qword ptr [r9]
00771549  4533c0                   xor r8d, r8d
0077154c  8bd6                     mov edx, esi
0077154e  488bcb                   mov rcx, rbx
00771551  ff9080050000             call qword ptr [rax + 0x580]
00771557  e920fbffff               jmp 0x77107c
0077155c  498b01                   mov rax, qword ptr [r9]
0077155f  40887c2420               mov byte ptr [rsp + 0x20], dil
00771564  4533c9                   xor r9d, r9d
00771567  41b001                   mov r8b, 1
0077156a  8bd6                     mov edx, esi
0077156c  488bcb                   mov rcx, rbx
0077156f  ff90b8010000             call qword ptr [rax + 0x1b8]
00771575  4885c0                   test rax, rax
00771578  488bc8                   mov rcx, rax
0077157b  7420                     je 0x77159d
0077157d  488b00                   mov rax, qword ptr [rax]
00771580  ff5020                   call qword ptr [rax + 0x20]
00771583  488bd8                   mov rbx, rax
00771586  4885db                   test rbx, rbx
00771589  7416                     je 0x7715a1
0077158b  488b3b                   mov rdi, qword ptr [rbx]
0077158e  448b6308                 mov r12d, dword ptr [rbx + 8]
00771592  8b8d18020000             mov ecx, dword ptr [rbp + 0x218]
00771598  443be1                   cmp r12d, ecx
0077159b  760a                     jbe 0x7715a7
0077159d  33c0                     xor eax, eax
0077159f  eb6c                     jmp 0x77160d
007715a1  8b8d18020000             mov ecx, dword ptr [rbp + 0x218]
007715a7  0faee8                   lfence
007715aa  418bdc                   mov ebx, r12d
007715ad  8bf1                     mov esi, ecx
007715af  4585e4                   test r12d, r12d
007715b2  7456                     je 0x77160a
007715b4  4d85ed                   test r13, r13
007715b7  750e                     jne 0x7715c7
007715b9  ff15b9b57501             call qword ptr [rip + 0x175b5b9]
007715bf  c70016000000             mov dword ptr [rax], 0x16
007715c5  eb3d                     jmp 0x771604
007715c7  4885ff                   test rdi, rdi
007715ca  7415                     je 0x7715e1
007715cc  483bf3                   cmp rsi, rbx
007715cf  7210                     jb 0x7715e1
007715d1  4c8bc3                   mov r8, rbx
007715d4  488bd7                   mov rdx, rdi
007715d7  498bcd                   mov rcx, r13
007715da  e8e11989ff               call 0x2fc0
007715df  eb29                     jmp 0x77160a
007715e1  4c8bc6                   mov r8, rsi
007715e4  33d2                     xor edx, edx
007715e6  498bcd                   mov rcx, r13
007715e9  e8081a89ff               call 0x2ff6
007715ee  4885ff                   test rdi, rdi
007715f1  74c6                     je 0x7715b9
007715f3  483bf3                   cmp rsi, rbx
007715f6  7312                     jae 0x77160a
007715f8  ff157ab57501             call qword ptr [rip + 0x175b57a]
007715fe  c70022000000             mov dword ptr [rax], 0x22
00771604  ff157eb57501             call qword ptr [rip + 0x175b57e]
0077160a  418bc4                   mov eax, r12d
0077160d  488b8da0010000           mov rcx, qword ptr [rbp + 0x1a0]
00771614  4833cd                   xor rcx, rbp
00771617  e854fa88ff               call 0x1070
0077161c  488b9df8010000           mov rbx, qword ptr [rbp + 0x1f8]
00771623  488da5b0010000           lea rsp, [rbp + 0x1b0]
0077162a  415f                     pop r15
0077162c  415e                     pop r14
0077162e  415d                     pop r13
00771630  415c                     pop r12
00771632  5f                       pop rdi
00771633  5e                       pop rsi
00771634  5d                       pop rbp
00771635  c3                       ret
00771636  90                       nop
00771637  90                       nop
00771638  9d                       popfq
00771639  1577006911               adc eax, 0x11690077
0077163e  7700                     ja 0x771640
00771640  ad                       lodsd eax, dword ptr [rsi]
00771641  117700                   adc dword ptr [rdi], esi
00771644  a810                     test al, 0x10
00771646  7700                     ja 0x771648
00771648  92                       xchg edx, eax
00771649  107700                   adc byte ptr [rdi], dh
0077164c  8c13                     mov word ptr [rbx], ss
0077164e  7700                     ja 0x771650
00771650  6810770017               push 0x17007710
00771655  127700                   adc dh, byte ptr [rdi]
00771658  be107700a7               mov esi, 0xa7007710
0077165d  1577008314               adc eax, 0x14830077
00771662  7700                     ja 0x771664
00771664  a7                       cmpsd dword ptr [rsi], dword ptr [rdi]
00771665  157700a715               adc eax, 0x15a70077
0077166a  7700                     ja 0x77166c
0077166c  a7                       cmpsd dword ptr [rsi], dword ptr [rdi]
0077166d  157700a715               adc eax, 0x15a70077
00771672  7700                     ja 0x771674
00771674  6d                       insd dword ptr [rdi], dx
00771675  1477                     adc al, 0x77
00771677  005714                   add byte ptr [rdi + 0x14], dl
0077167a  7700                     ja 0x77167c
0077167c  411477                   adc al, 0x77
0077167f  0099147700c1             add byte ptr [rcx - 0x3eff88ec], bl
00771685  1477                     adc al, 0x77
00771687  00b4137700ce13           add byte ptr [rbx + rdx + 0x13ce0077], dh
0077168e  7700                     ja 0x771690
00771690  e8137700a7               call 0xffffffffa7778da8
00771695  157700d414               adc eax, 0x14d40077
0077169a  7700                     ja 0x77169c
0077169c  ee                       out dx, al
0077169d  1477                     adc al, 0x77
0077169f  00041577001a15           add byte ptr [rdx + 0x151a0077], al
007716a6  7700                     ja 0x7716a8
007716a8  30157700a715             xor byte ptr [rip + 0x15a70077], dl
007716ae  7700                     ja 0x7716b0
007716b0  46157700a715             adc eax, 0x15a70077
007716b6  7700                     ja 0x7716b8
007716b8  a7                       cmpsd dword ptr [rsi], dword ptr [rdi]
007716b9  1577005c15               adc eax, 0x155c0077
007716be  7700                     ja 0x7716c0
