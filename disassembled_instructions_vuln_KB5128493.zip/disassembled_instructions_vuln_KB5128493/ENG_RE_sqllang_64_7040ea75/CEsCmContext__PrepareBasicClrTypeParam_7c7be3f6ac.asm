; CEsCmContext::PrepareBasicClrTypeParam
; sqllang.dll, primary RVA 0x7175c0, 1664 bytes in 1 chunk(s)

; chunk at RVA 0x7175c0 (1664 bytes)
007175c0  48895c2408               mov qword ptr [rsp + 8], rbx
007175c5  4889742418               mov qword ptr [rsp + 0x18], rsi
007175ca  48897c2420               mov qword ptr [rsp + 0x20], rdi
007175cf  55                       push rbp
007175d0  4156                     push r14
007175d2  4157                     push r15
007175d4  488bec                   mov rbp, rsp
007175d7  4883ec30                 sub rsp, 0x30
007175db  837a4002                 cmp dword ptr [rdx + 0x40], 2
007175df  488bf2                   mov rsi, rdx
007175e2  448b7244                 mov r14d, dword ptr [rdx + 0x44]
007175e6  488bf9                   mov rdi, rcx
007175e9  0fb65a49                 movzx ebx, byte ptr [rdx + 0x49]
007175ed  0f8555010000             jne 0x717748
007175f3  f6424c02                 test byte ptr [rdx + 0x4c], 2
007175f7  0f844b010000             je 0x717748
007175fd  84db                     test bl, bl
007175ff  747e                     je 0x71767f
00717601  4533c0                   xor r8d, r8d
00717604  4883c228                 add rdx, 0x28
00717608  e8e3b4ffff               call 0x712af0
0071760d  894660                   mov dword ptr [rsi + 0x60], eax
00717610  8bd8                     mov ebx, eax
00717612  488bcf                   mov rcx, rdi
00717615  3dff000000               cmp eax, 0xff
0071761a  770c                     ja 0x717628
0071761c  ba12000000               mov edx, 0x12
00717621  e8eab9ffff               call 0x713010
00717626  eb19                     jmp 0x717641
00717628  ba0d010000               mov edx, 0x10d
0071762d  e8deb9ffff               call 0x713010
00717632  0fb6d3                   movzx edx, bl
00717635  488bcf                   mov rcx, rdi
00717638  e853b2ffff               call 0x712890
0071763d  66c1eb08                 shr bx, 8
00717641  0fb6d3                   movzx edx, bl
00717644  488bcf                   mov rcx, rdi
00717647  e844b2ffff               call 0x712890
0071764c  ba15010000               mov edx, 0x115
00717651  488bcf                   mov rcx, rdi
00717654  e8b7b9ffff               call 0x713010
00717659  448b463c                 mov r8d, dword ptr [rsi + 0x3c]
0071765d  4c8d4d28                 lea r9, [rbp + 0x28]
00717661  488b5708                 mov rdx, qword ptr [rdi + 8]
00717665  488b0f                   mov rcx, qword ptr [rdi]
00717668  e8a3b4f9ff               call 0x6b2b10
0071766d  83f801                   cmp eax, 1
00717670  0f85c6040000             jne 0x717b3c
00717676  448d4018                 lea r8d, [rax + 0x18]
0071767a  e9b3040000               jmp 0x717b32
0071767f  4183c6fe                 add r14d, -2
00717683  4183fe0c                 cmp r14d, 0xc
00717687  0f878b000000             ja 0x717718
0071768d  488d156c898eff           lea rdx, [rip - 0x717694]
00717694  4963c6                   movsxd rax, r14d
00717697  8b8482d87b7100           mov eax, dword ptr [rdx + rax*4 + 0x717bd8]
0071769e  4803c2                   add rax, rdx
007176a1  ffe0                     jmp rax
007176a3  ba16000000               mov edx, 0x16
007176a8  e863b9ffff               call 0x713010
007176ad  e9f1040000               jmp 0x717ba3
007176b2  ba21000000               mov edx, 0x21
007176b7  e854b9ffff               call 0x713010
007176bc  33d2                     xor edx, edx
007176be  488bcf                   mov rcx, rdi
007176c1  e88aa9ffff               call 0x712050
007176c6  e9d8040000               jmp 0x717ba3
007176cb  ba22000000               mov edx, 0x22
007176d0  e83bb9ffff               call 0x713010
007176d5  33d2                     xor edx, edx
007176d7  488bcf                   mov rcx, rdi
007176da  e8b1b1ffff               call 0x712890
007176df  33d2                     xor edx, edx
007176e1  488bcf                   mov rcx, rdi
007176e4  e8a7b1ffff               call 0x712890
007176e9  33d2                     xor edx, edx
007176eb  488bcf                   mov rcx, rdi
007176ee  e89db1ffff               call 0x712890
007176f3  33d2                     xor edx, edx
007176f5  488bcf                   mov rcx, rdi
007176f8  e893b1ffff               call 0x712890
007176fd  e9a1040000               jmp 0x717ba3
00717702  ba23000000               mov edx, 0x23
00717707  ebae                     jmp 0x7176b7
00717709  ba14000000               mov edx, 0x14
0071770e  e8fdb8ffff               call 0x713010
00717713  e98b040000               jmp 0x717ba3
00717718  488d054113a401           lea rax, [rip + 0x1a41341]
0071771f  41b912110000             mov r9d, 0x1112
00717725  4c8d05b4c7df01           lea r8, [rip + 0x1dfc7b4]
0071772c  4889442420               mov qword ptr [rsp + 0x20], rax
00717731  488d15e8f0df01           lea rdx, [rip + 0x1dff0e8]
00717738  b901000000               mov ecx, 1
0071773d  ff1535377b01             call qword ptr [rip + 0x17b3735]
00717743  e95b040000               jmp 0x717ba3
00717748  4183fe0e                 cmp r14d, 0xe
0071774c  7409                     je 0x717757
0071774e  84db                     test bl, bl
00717750  7505                     jne 0x717757
00717752  e889720000               call 0x71e9e0
00717757  4533c0                   xor r8d, r8d
0071775a  488bd6                   mov rdx, rsi
0071775d  488bcf                   mov rcx, rdi
00717760  e83bbfffff               call 0x7136a0
00717765  4183c6fe                 add r14d, -2
00717769  4183fe0c                 cmp r14d, 0xc
0071776d  0f8705040000             ja 0x717b78
00717773  488d1586888eff           lea rdx, [rip - 0x71777a]
0071777a  4963c6                   movsxd rax, r14d
0071777d  8b84820c7c7100           mov eax, dword ptr [rdx + rax*4 + 0x717c0c]
00717784  4803c2                   add rax, rdx
00717787  ffe0                     jmp rax
00717789  ba28000000               mov edx, 0x28
0071778e  488bcf                   mov rcx, rdi
00717791  e87ab8ffff               call 0x713010
00717796  4533c0                   xor r8d, r8d
00717799  84db                     test bl, bl
0071779b  410f95c0                 setne r8b
0071779f  4183c01c                 add r8d, 0x1c
007177a3  488b5708                 mov rdx, qword ptr [rdi + 8]
007177a7  4c8d4d28                 lea r9, [rbp + 0x28]
007177ab  488b0f                   mov rcx, qword ptr [rdi]
007177ae  e81db6f9ff               call 0x6b2dd0
007177b3  83f801                   cmp eax, 1
007177b6  750d                     jne 0x7177c5
007177b8  8bd0                     mov edx, eax
007177ba  448d4014                 lea r8d, [rax + 0x14]
007177be  33c9                     xor ecx, ecx
007177c0  e81b2d0100               call 0x72a4e0
007177c5  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
007177c8  488bcf                   mov rcx, rdi
007177cb  0fb6d3                   movzx edx, bl
007177ce  e8bdb0ffff               call 0x712890
007177d3  0fb7d3                   movzx edx, bx
007177d6  488bcf                   mov rcx, rdi
007177d9  66c1ea08                 shr dx, 8
007177dd  e8aeb0ffff               call 0x712890
007177e2  c1eb10                   shr ebx, 0x10
007177e5  488bcf                   mov rcx, rdi
007177e8  0fb6d3                   movzx edx, bl
007177eb  e8a0b0ffff               call 0x712890
007177f0  66c1eb08                 shr bx, 8
007177f4  488bcf                   mov rcx, rdi
007177f7  0fb6d3                   movzx edx, bl
007177fa  e891b0ffff               call 0x712890
007177ff  e99f030000               jmp 0x717ba3
00717804  488b4620                 mov rax, qword ptr [rsi + 0x20]
00717808  ba28000000               mov edx, 0x28
0071780d  488bcf                   mov rcx, rdi
00717810  803830                   cmp byte ptr [rax], 0x30
00717813  7517                     jne 0x71782c
00717815  e8f6b7ffff               call 0x713010
0071781a  4533c0                   xor r8d, r8d
0071781d  84db                     test bl, bl
0071781f  410f95c0                 setne r8b
00717823  4183c023                 add r8d, 0x23
00717827  e977ffffff               jmp 0x7177a3
0071782c  e8dfb7ffff               call 0x713010
00717831  4533c0                   xor r8d, r8d
00717834  84db                     test bl, bl
00717836  410f95c0                 setne r8b
0071783a  4183c025                 add r8d, 0x25
0071783e  e960ffffff               jmp 0x7177a3
00717843  ba28000000               mov edx, 0x28
00717848  488bcf                   mov rcx, rdi
0071784b  e8c0b7ffff               call 0x713010
00717850  4533c0                   xor r8d, r8d
00717853  84db                     test bl, bl
00717855  410f95c0                 setne r8b
00717859  4183c02b                 add r8d, 0x2b
0071785d  e941ffffff               jmp 0x7177a3
00717862  ba28000000               mov edx, 0x28
00717867  488bcf                   mov rcx, rdi
0071786a  e8a1b7ffff               call 0x713010
0071786f  4533c0                   xor r8d, r8d
00717872  84db                     test bl, bl
00717874  410f95c0                 setne r8b
00717878  4183c031                 add r8d, 0x31
0071787c  e922ffffff               jmp 0x7177a3
00717881  ba28000000               mov edx, 0x28
00717886  488bcf                   mov rcx, rdi
00717889  e882b7ffff               call 0x713010
0071788e  4533c0                   xor r8d, r8d
00717891  84db                     test bl, bl
00717893  410f95c0                 setne r8b
00717897  4183c037                 add r8d, 0x37
0071789b  e903ffffff               jmp 0x7177a3
007178a0  ba28000000               mov edx, 0x28
007178a5  488bcf                   mov rcx, rdi
007178a8  e863b7ffff               call 0x713010
007178ad  4533c0                   xor r8d, r8d
007178b0  84db                     test bl, bl
007178b2  410f95c0                 setne r8b
007178b6  4183c03d                 add r8d, 0x3d
007178ba  e9e4feffff               jmp 0x7177a3
007178bf  ba28000000               mov edx, 0x28
007178c4  488bcf                   mov rcx, rdi
007178c7  e844b7ffff               call 0x713010
007178cc  4533c0                   xor r8d, r8d
007178cf  84db                     test bl, bl
007178d1  410f95c0                 setne r8b
007178d5  4183c043                 add r8d, 0x43
007178d9  e9c5feffff               jmp 0x7177a3
007178de  ba28000000               mov edx, 0x28
007178e3  488bcf                   mov rcx, rdi
007178e6  e825b7ffff               call 0x713010
007178eb  4533c0                   xor r8d, r8d
007178ee  84db                     test bl, bl
007178f0  410f95c0                 setne r8b
007178f4  4183c04a                 add r8d, 0x4a
007178f8  e9a6feffff               jmp 0x7177a3
007178fd  4c8b4620                 mov r8, qword ptr [rsi + 0x20]
00717901  410fb600                 movzx eax, byte ptr [r8]
00717905  0fb68c1010360202         movzx ecx, byte ptr [rax + rdx + 0x2023610]
0071790d  80bc1180c9110200         cmp byte ptr [rcx + rdx + 0x211c980], 0
00717915  7424                     je 0x71793b
00717917  b8ffff0000               mov eax, 0xffff
0071791c  6641394010               cmp word ptr [r8 + 0x10], ax
00717921  7418                     je 0x71793b
00717923  ba28000000               mov edx, 0x28
00717928  488bcf                   mov rcx, rdi
0071792b  e8e0b6ffff               call 0x713010
00717930  41b849000000             mov r8d, 0x49
00717936  e968feffff               jmp 0x7177a3
0071793b  837e4002                 cmp dword ptr [rsi + 0x40], 2
0071793f  7415                     je 0x717956
00717941  488b87a8000000           mov rax, qword ptr [rdi + 0xa8]
00717948  ba01000000               mov edx, 1
0071794d  80b87501000000           cmp byte ptr [rax + 0x175], 0
00717954  7405                     je 0x71795b
00717956  ba02000000               mov edx, 2
0071795b  488bcf                   mov rcx, rdi
0071795e  e80dbaffff               call 0x713370
00717963  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00717967  ff15db447b01             call qword ptr [rip + 0x17b44db]
0071796d  8bc8                     mov ecx, eax
0071796f  ff15db447b01             call qword ptr [rip + 0x17b44db]
00717975  ba21000000               mov edx, 0x21
0071797a  488bcf                   mov rcx, rdi
0071797d  8bd8                     mov ebx, eax
0071797f  e88cb6ffff               call 0x713010
00717984  8bd3                     mov edx, ebx
00717986  488bcf                   mov rcx, rdi
00717989  e8c2a6ffff               call 0x712050
0071798e  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00717992  ff15b0447b01             call qword ptr [rip + 0x17b44b0]
00717998  448bc8                   mov r9d, eax
0071799b  0fbae010                 bt eax, 0x10
0071799f  7307                     jae 0x7179a8
007179a1  ba00800000               mov edx, 0x8000
007179a6  eb35                     jmp 0x7179dd
007179a8  418bc9                   mov ecx, r9d
007179ab  c1e90c                   shr ecx, 0xc
007179ae  83e101                   and ecx, 1
007179b1  448bc1                   mov r8d, ecx
007179b4  4183c802                 or r8d, 2
007179b8  2500200000               and eax, 0x2000
007179bd  418bc1                   mov eax, r9d
007179c0  440f44c1                 cmove r8d, ecx
007179c4  418bd0                   mov edx, r8d
007179c7  83ca08                   or edx, 8
007179ca  2500400000               and eax, 0x4000
007179cf  410f44d0                 cmove edx, r8d
007179d3  410fbae10f               bt r9d, 0xf
007179d8  7303                     jae 0x7179dd
007179da  83ca10                   or edx, 0x10
007179dd  488bcf                   mov rcx, rdi
007179e0  e88bb9ffff               call 0x713370
007179e5  ba04000000               mov edx, 4
007179ea  488bcf                   mov rcx, rdi
007179ed  e81eb6ffff               call 0x713010
007179f2  ba28000000               mov edx, 0x28
007179f7  488bcf                   mov rcx, rdi
007179fa  e811b6ffff               call 0x713010
007179ff  488b5708                 mov rdx, qword ptr [rdi + 8]
00717a03  4c8d4d28                 lea r9, [rbp + 0x28]
00717a07  488b0f                   mov rcx, qword ptr [rdi]
00717a0a  41b8a4000000             mov r8d, 0xa4
00717a10  e8bbb3f9ff               call 0x6b2dd0
00717a15  83f801                   cmp eax, 1
00717a18  750d                     jne 0x717a27
00717a1a  8bd0                     mov edx, eax
00717a1c  448d4014                 lea r8d, [rax + 0x14]
00717a20  33c9                     xor ecx, ecx
00717a22  e8b92a0100               call 0x72a4e0
00717a27  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
00717a2a  488bcf                   mov rcx, rdi
00717a2d  0fb6d3                   movzx edx, bl
00717a30  e85baeffff               call 0x712890
00717a35  0fb7d3                   movzx edx, bx
00717a38  488bcf                   mov rcx, rdi
00717a3b  66c1ea08                 shr dx, 8
00717a3f  e84caeffff               call 0x712890
00717a44  c1eb10                   shr ebx, 0x10
00717a47  488bcf                   mov rcx, rdi
00717a4a  0fb6d3                   movzx edx, bl
00717a4d  e83eaeffff               call 0x712890
00717a52  66c1eb08                 shr bx, 8
00717a56  488bcf                   mov rcx, rdi
00717a59  0fb6d3                   movzx edx, bl
00717a5c  e82faeffff               call 0x712890
00717a61  ba25000000               mov edx, 0x25
00717a66  488bcf                   mov rcx, rdi
00717a69  e8a2b5ffff               call 0x713010
00717a6e  ba25000000               mov edx, 0x25
00717a73  488bcf                   mov rcx, rdi
00717a76  e895b5ffff               call 0x713010
00717a7b  ba28000000               mov edx, 0x28
00717a80  488bcf                   mov rcx, rdi
00717a83  e888b5ffff               call 0x713010
00717a88  488b5708                 mov rdx, qword ptr [rdi + 8]
00717a8c  4c8d4d28                 lea r9, [rbp + 0x28]
00717a90  488b0f                   mov rcx, qword ptr [rdi]
00717a93  41b8ac000000             mov r8d, 0xac
00717a99  e832b3f9ff               call 0x6b2dd0
00717a9e  83f801                   cmp eax, 1
00717aa1  750d                     jne 0x717ab0
00717aa3  8bd0                     mov edx, eax
00717aa5  448d4014                 lea r8d, [rax + 0x14]
00717aa9  33c9                     xor ecx, ecx
00717aab  e8302a0100               call 0x72a4e0
00717ab0  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
00717ab3  488bcf                   mov rcx, rdi
00717ab6  0fb6d3                   movzx edx, bl
00717ab9  e8d2adffff               call 0x712890
00717abe  0fb7d3                   movzx edx, bx
00717ac1  488bcf                   mov rcx, rdi
00717ac4  66c1ea08                 shr dx, 8
00717ac8  e8c3adffff               call 0x712890
00717acd  c1eb10                   shr ebx, 0x10
00717ad0  488bcf                   mov rcx, rdi
00717ad3  0fb6d3                   movzx edx, bl
00717ad6  e8b5adffff               call 0x712890
00717adb  66c1eb08                 shr bx, 8
00717adf  488bcf                   mov rcx, rdi
00717ae2  0fb6d3                   movzx edx, bl
00717ae5  e8a6adffff               call 0x712890
00717aea  4533c0                   xor r8d, r8d
00717aed  488d5628                 lea rdx, [rsi + 0x28]
00717af1  488bcf                   mov rcx, rdi
00717af4  e8f7afffff               call 0x712af0
00717af9  8bd0                     mov edx, eax
00717afb  894660                   mov dword ptr [rsi + 0x60], eax
00717afe  488bcf                   mov rcx, rdi
00717b01  e8fab9ffff               call 0x713500
00717b06  ba28000000               mov edx, 0x28
00717b0b  488bcf                   mov rcx, rdi
00717b0e  e8fdb4ffff               call 0x713010
00717b13  488b5708                 mov rdx, qword ptr [rdi + 8]
00717b17  4c8d4d28                 lea r9, [rbp + 0x28]
00717b1b  488b0f                   mov rcx, qword ptr [rdi]
00717b1e  41b8b2000000             mov r8d, 0xb2
00717b24  e8a7b2f9ff               call 0x6b2dd0
00717b29  83f801                   cmp eax, 1
00717b2c  750e                     jne 0x717b3c
00717b2e  448d4014                 lea r8d, [rax + 0x14]
00717b32  33c9                     xor ecx, ecx
00717b34  8d5101                   lea edx, [rcx + 1]
00717b37  e8a4290100               call 0x72a4e0
00717b3c  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
00717b3f  488bcf                   mov rcx, rdi
00717b42  0fb6d3                   movzx edx, bl
00717b45  e846adffff               call 0x712890
00717b4a  0fb7d3                   movzx edx, bx
00717b4d  488bcf                   mov rcx, rdi
00717b50  66c1ea08                 shr dx, 8
00717b54  e837adffff               call 0x712890
00717b59  c1eb10                   shr ebx, 0x10
00717b5c  488bcf                   mov rcx, rdi
00717b5f  0fb6d3                   movzx edx, bl
00717b62  e829adffff               call 0x712890
00717b67  66c1eb08                 shr bx, 8
00717b6b  488bcf                   mov rcx, rdi
00717b6e  0fb6d3                   movzx edx, bl
00717b71  e81aadffff               call 0x712890
00717b76  eb47                     jmp 0x717bbf
00717b78  488d05e10ea401           lea rax, [rip + 0x1a40ee1]
00717b7f  41b9e4100000             mov r9d, 0x10e4
00717b85  4c8d0554c3df01           lea r8, [rip + 0x1dfc354]
00717b8c  4889442420               mov qword ptr [rsp + 0x20], rax
00717b91  488d1588ecdf01           lea rdx, [rip + 0x1dfec88]
00717b98  b901000000               mov ecx, 1
00717b9d  ff15d5327b01             call qword ptr [rip + 0x17b32d5]
00717ba3  4533c0                   xor r8d, r8d
00717ba6  488d5628                 lea rdx, [rsi + 0x28]
00717baa  488bcf                   mov rcx, rdi
00717bad  e83eafffff               call 0x712af0
00717bb2  8bd0                     mov edx, eax
00717bb4  894660                   mov dword ptr [rsi + 0x60], eax
00717bb7  488bcf                   mov rcx, rdi
00717bba  e841b9ffff               call 0x713500
00717bbf  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00717bc4  488b742460               mov rsi, qword ptr [rsp + 0x60]
00717bc9  488b7c2468               mov rdi, qword ptr [rsp + 0x68]
00717bce  4883c430                 add rsp, 0x30
00717bd2  415f                     pop r15
00717bd4  415e                     pop r14
00717bd6  5d                       pop rbp
00717bd7  c3                       ret
00717bd8  a3767100a376710018       movabs dword ptr [0x18007176a3007176], eax
00717be1  7771                     ja 0x717c54
00717be3  00a3767100a3             add byte ptr [rbx - 0x5cff8e8a], ah
00717be9  7671                     jbe 0x717c5c
00717beb  0018                     add byte ptr [rax], bl
00717bed  7771                     ja 0x717c60
00717bef  00a376710018             add byte ptr [rbx + 0x18007176], ah
00717bf5  7771                     ja 0x717c68
00717bf7  00b276710018             add byte ptr [rdx + 0x18007176], dh
00717bfd  7771                     ja 0x717c70
00717bff  00cb                     add bl, cl
00717c01  7671                     jbe 0x717c74
00717c03  0002                     add byte ptr [rdx], al
00717c05  7771                     ja 0x717c78
00717c07  0009                     add byte ptr [rcx], cl
00717c09  7771                     ja 0x717c7c
00717c0b  0089777100de             add byte ptr [rcx - 0x21ff8e89], cl
00717c11  7871                     js 0x717c84
00717c13  00787b                   add byte ptr [rax + 0x7b], bh
00717c16  7100                     jno 0x717c18
00717c18  0478                     add al, 0x78
00717c1a  7100                     jno 0x717c1c
00717c1c  437871                   js 0x717c90
00717c1f  00787b                   add byte ptr [rax + 0x7b], bh
00717c22  7100                     jno 0x717c24
