; CalcPrecisionAndScale
; sqllang.dll, primary RVA 0x13ee690, 452 bytes in 1 chunk(s)

; chunk at RVA 0x13ee690 (452 bytes)
013ee690  488bc4                   mov rax, rsp
013ee693  48895808                 mov qword ptr [rax + 8], rbx
013ee697  55                       push rbp
013ee698  56                       push rsi
013ee699  57                       push rdi
013ee69a  4883ec60                 sub rsp, 0x60
013ee69e  32db                     xor bl, bl
013ee6a0  4d63d8                   movsxd r11, r8d
013ee6a3  4032ff                   xor dil, dil
013ee6a6  885818                   mov byte ptr [rax + 0x18], bl
013ee6a9  40887820                 mov byte ptr [rax + 0x20], dil
013ee6ad  498bf1                   mov rsi, r9
013ee6b0  488d2d4919c1fe           lea rbp, [rip - 0x13ee6b7]
013ee6b7  4c8bd1                   mov r10, rcx
013ee6ba  4183fb05                 cmp r11d, 5
013ee6be  0f8726010000             ja 0x13ee7ea
013ee6c4  468b8c9d3ce83e01         mov r9d, dword ptr [rbp + r11*4 + 0x13ee83c]
013ee6cc  4c03cd                   add r9, rbp
013ee6cf  41ffe1                   jmp r9
013ee6d2  0faee8                   lfence
013ee6d5  0fb60a                   movzx ecx, byte ptr [rdx]
013ee6d8  8d4110                   lea eax, [rcx + 0x10]
013ee6db  3c01                     cmp al, 1
013ee6dd  760b                     jbe 0x13ee6ea
013ee6df  440fb64a13               movzx r9d, byte ptr [rdx + 0x13]
013ee6e4  0fb65a12                 movzx ebx, byte ptr [rdx + 0x12]
013ee6e8  eb31                     jmp 0x13ee71b
013ee6ea  0fb6842910360202         movzx eax, byte ptr [rcx + rbp + 0x2023610]
013ee6f2  440fb68c8513370202       movzx r9d, byte ptr [rbp + rax*4 + 0x2023713]
013ee6fb  80f9f0                   cmp cl, 0xf0
013ee6fe  740b                     je 0x13ee70b
013ee700  80f9f1                   cmp cl, 0xf1
013ee703  7406                     je 0x13ee70b
013ee705  0fb65a12                 movzx ebx, byte ptr [rdx + 0x12]
013ee709  eb10                     jmp 0x13ee71b
013ee70b  0fb6842910360202         movzx eax, byte ptr [rcx + rbp + 0x2023610]
013ee713  0fb69c8512370202         movzx ebx, byte ptr [rbp + rax*4 + 0x2023712]
013ee71b  410fb612                 movzx edx, byte ptr [r10]
013ee71f  8d4210                   lea eax, [rdx + 0x10]
013ee722  3c01                     cmp al, 1
013ee724  760c                     jbe 0x13ee732
013ee726  450fb64213               movzx r8d, byte ptr [r10 + 0x13]
013ee72b  410fb65212               movzx edx, byte ptr [r10 + 0x12]
013ee730  eb32                     jmp 0x13ee764
013ee732  0fb68c2a10360202         movzx ecx, byte ptr [rdx + rbp + 0x2023610]
013ee73a  440fb6848d13370202       movzx r8d, byte ptr [rbp + rcx*4 + 0x2023713]
013ee743  80faf0                   cmp dl, 0xf0
013ee746  740c                     je 0x13ee754
013ee748  80faf1                   cmp dl, 0xf1
013ee74b  7407                     je 0x13ee754
013ee74d  410fb65212               movzx edx, byte ptr [r10 + 0x12]
013ee752  eb10                     jmp 0x13ee764
013ee754  0fb68c2a10360202         movzx ecx, byte ptr [rdx + rbp + 0x2023610]
013ee75c  0fb6948d12370202         movzx edx, byte ptr [rbp + rcx*4 + 0x2023712]
013ee764  488d842498000000         lea rax, [rsp + 0x98]
013ee76c  418bcb                   mov ecx, r11d
013ee76f  4889442430               mov qword ptr [rsp + 0x30], rax
013ee774  488d842490000000         lea rax, [rsp + 0x90]
013ee77c  4889442428               mov qword ptr [rsp + 0x28], rax
013ee781  44884c2420               mov byte ptr [rsp + 0x20], r9b
013ee786  440fb6cb                 movzx r9d, bl
013ee78a  ff15d0d0ad00             call qword ptr [rip + 0xadd0d0]
013ee790  0fb69c2490000000         movzx ebx, byte ptr [rsp + 0x90]
013ee798  0fb6bc2498000000         movzx edi, byte ptr [rsp + 0x98]
013ee7a0  eb48                     jmp 0x13ee7ea
013ee7a2  0fb609                   movzx ecx, byte ptr [rcx]
013ee7a5  8d4110                   lea eax, [rcx + 0x10]
013ee7a8  3c01                     cmp al, 1
013ee7aa  760c                     jbe 0x13ee7b8
013ee7ac  410fb65a12               movzx ebx, byte ptr [r10 + 0x12]
013ee7b1  410fb67a13               movzx edi, byte ptr [r10 + 0x13]
013ee7b6  eb32                     jmp 0x13ee7ea
013ee7b8  0fb6842910360202         movzx eax, byte ptr [rcx + rbp + 0x2023610]
013ee7c0  488bd1                   mov rdx, rcx
013ee7c3  80c110                   add cl, 0x10
013ee7c6  0fb69c8512370202         movzx ebx, byte ptr [rbp + rax*4 + 0x2023712]
013ee7ce  80f901                   cmp cl, 1
013ee7d1  7607                     jbe 0x13ee7da
013ee7d3  410fb67a13               movzx edi, byte ptr [r10 + 0x13]
013ee7d8  eb10                     jmp 0x13ee7ea
013ee7da  0fb6842a10360202         movzx eax, byte ptr [rdx + rbp + 0x2023610]
013ee7e2  0fb6bc8513370202         movzx edi, byte ptr [rbp + rax*4 + 0x2023713]
013ee7ea  0fb616                   movzx edx, byte ptr [rsi]
013ee7ed  488d4c2440               lea rcx, [rsp + 0x40]
013ee7f2  0fb6c3                   movzx eax, bl
013ee7f5  440fb684285f830502       movzx r8d, byte ptr [rax + rbp + 0x205835f]
013ee7fe  e82d57c6fe               call 0x53f30
013ee803  0fb64601                 movzx eax, byte ptr [rsi + 1]
013ee807  f6d0                     not al
013ee809  885c2452                 mov byte ptr [rsp + 0x52], bl
013ee80d  40887c2453               mov byte ptr [rsp + 0x53], dil
013ee812  a801                     test al, 1
013ee814  7505                     jne 0x13ee81b
013ee816  804c244101               or byte ptr [rsp + 0x41], 1
013ee81b  0f10442440               movups xmm0, xmmword ptr [rsp + 0x40]
013ee820  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
013ee828  0f104c2450               movups xmm1, xmmword ptr [rsp + 0x50]
013ee82d  0f1106                   movups xmmword ptr [rsi], xmm0
013ee830  0f114e10                 movups xmmword ptr [rsi + 0x10], xmm1
013ee834  4883c460                 add rsp, 0x60
013ee838  5f                       pop rdi
013ee839  5e                       pop rsi
013ee83a  5d                       pop rbp
013ee83b  c3                       ret
013ee83c  d2e6                     shl dh, cl
013ee83e  3e01d2                   add edx, edx
013ee841  e63e                     out 0x3e, al
013ee843  01d2                     add edx, edx
013ee845  e63e                     out 0x3e, al
013ee847  01d2                     add edx, edx
013ee849  e63e                     out 0x3e, al
013ee84b  01d2                     add edx, edx
013ee84d  e63e                     out 0x3e, al
