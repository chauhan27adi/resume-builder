; CAssemblyMetaInfo::VerifyFacetAttributesHelper
; sqllang.dll, primary RVA 0x6d4350, 1534 bytes in 8 chunk(s)

; chunk at RVA 0x6d4350 (141 bytes)
006d4350  48895c2410               mov qword ptr [rsp + 0x10], rbx
006d4355  57                       push rdi
006d4356  4883ec60                 sub rsp, 0x60
006d435a  418b4014                 mov eax, dword ptr [r8 + 0x14]
006d435e  4d8bd1                   mov r10, r9
006d4361  83e007                   and eax, 7
006d4364  498bf8                   mov rdi, r8
006d4367  488bda                   mov rbx, rdx
006d436a  3c06                     cmp al, 6
006d436c  7462                     je 0x6d43d0
006d436e  498b4008                 mov rax, qword ptr [r8 + 8]
006d4372  4c8b5a18                 mov r11, qword ptr [rdx + 0x18]
006d4376  418b4810                 mov ecx, dword ptr [r8 + 0x10]
006d437a  448b5230                 mov r10d, dword ptr [rdx + 0x30]
006d437e  03c9                     add ecx, ecx
006d4380  4889442440               mov qword ptr [rsp + 0x40], rax
006d4385  4503d2                   add r10d, r10d
006d4388  488b4228                 mov rax, qword ptr [rdx + 0x28]
006d438c  ba10000000               mov edx, 0x10
006d4391  458b8ba0000000           mov r9d, dword ptr [r11 + 0xa0]
006d4398  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d439c  4503c9                   add r9d, r9d
006d439f  4889442430               mov qword ptr [rsp + 0x30], rax
006d43a4  b995180000               mov ecx, 0x1895
006d43a9  498b8398000000           mov rax, qword ptr [r11 + 0x98]
006d43b0  448d42f1                 lea r8d, [rdx - 0xf]
006d43b4  4489542428               mov dword ptr [rsp + 0x28], r10d
006d43b9  4889442420               mov qword ptr [rsp + 0x20], rax
006d43be  e87d10b4ff               call 0x215440
006d43c3  33c0                     xor eax, eax
006d43c5  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d43ca  4883c460                 add rsp, 0x60
006d43ce  5f                       pop rdi
006d43cf  c3                       ret
006d43d0  4180790800               cmp byte ptr [r9 + 8], 0
006d43d5  488b942490000000         mov rdx, qword ptr [rsp + 0x90]

; chunk at RVA 0x6d43dd (331 bytes)
006d43dd  4889742470               mov qword ptr [rsp + 0x70], rsi
006d43e2  beffffffff               mov esi, 0xffffffff
006d43e7  745b                     je 0x6d4444
006d43e9  8b4a10                   mov ecx, dword ptr [rdx + 0x10]
006d43ec  83e901                   sub ecx, 1
006d43ef  742e                     je 0x6d441f
006d43f1  83e901                   sub ecx, 1
006d43f4  741c                     je 0x6d4412
006d43f6  83f901                   cmp ecx, 1
006d43f9  752a                     jne 0x6d4425
006d43fb  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d43fe  83e933                   sub ecx, 0x33
006d4401  743c                     je 0x6d443f
006d4403  83e901                   sub ecx, 1
006d4406  7437                     je 0x6d443f
006d4408  83e901                   sub ecx, 1
006d440b  7432                     je 0x6d443f
006d440d  83f901                   cmp ecx, 1
006d4410  eb11                     jmp 0x6d4423
006d4412  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d4415  83e938                   sub ecx, 0x38
006d4418  7425                     je 0x6d443f
006d441a  83f901                   cmp ecx, 1
006d441d  eb04                     jmp 0x6d4423
006d441f  837a141c                 cmp dword ptr [rdx + 0x14], 0x1c
006d4423  741a                     je 0x6d443f
006d4425  488d05cc55cf01           lea rax, [rip + 0x1cf55cc]
006d442c  4889442450               mov qword ptr [rsp + 0x50], rax
006d4431  48c74424481a000000       mov qword ptr [rsp + 0x48], 0x1a
006d443a  e943040000               jmp 0x6d4882
006d443f  410fb67109               movzx esi, byte ptr [r9 + 9]
006d4444  4533db                   xor r11d, r11d
006d4447  4538590c                 cmp byte ptr [r9 + 0xc], r11b
006d444b  0f845a010000             je 0x6d45ab
006d4451  448b4210                 mov r8d, dword ptr [rdx + 0x10]
006d4455  418bc8                   mov ecx, r8d
006d4458  83e901                   sub ecx, 1
006d445b  743a                     je 0x6d4497
006d445d  83e901                   sub ecx, 1
006d4460  7423                     je 0x6d4485
006d4462  83f901                   cmp ecx, 1
006d4465  7538                     jne 0x6d449f
006d4467  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d446a  448bc9                   mov r9d, ecx
006d446d  4183e933                 sub r9d, 0x33
006d4471  7446                     je 0x6d44b9
006d4473  4183e901                 sub r9d, 1
006d4477  7440                     je 0x6d44b9
006d4479  4183e901                 sub r9d, 1
006d447d  743a                     je 0x6d44b9
006d447f  4183f901                 cmp r9d, 1
006d4483  eb18                     jmp 0x6d449d
006d4485  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d4488  448bc9                   mov r9d, ecx
006d448b  4183e938                 sub r9d, 0x38
006d448f  7428                     je 0x6d44b9
006d4491  4183f901                 cmp r9d, 1
006d4495  eb06                     jmp 0x6d449d
006d4497  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d449a  83f91c                   cmp ecx, 0x1c
006d449d  741a                     je 0x6d44b9
006d449f  488d05da57cf01           lea rax, [rip + 0x1cf57da]
006d44a6  4889442450               mov qword ptr [rsp + 0x50], rax
006d44ab  48c74424480e000000       mov qword ptr [rsp + 0x48], 0xe
006d44b4  e9c9030000               jmp 0x6d4882
006d44b9  458b4a10                 mov r9d, dword ptr [r10 + 0x10]
006d44bd  4183f9ff                 cmp r9d, -1
006d44c1  7565                     jne 0x6d4528
006d44c3  83fe01                   cmp esi, 1
006d44c6  7560                     jne 0x6d4528
006d44c8  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d44cc  488b4708                 mov rax, qword ptr [rdi + 8]
006d44d0  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d44d3  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d44d6  03c9                     add ecx, ecx
006d44d8  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d44df  03d2                     add edx, edx
006d44e1  4889442440               mov qword ptr [rsp + 0x40], rax
006d44e6  4503c9                   add r9d, r9d
006d44e9  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d44ed  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d44f1  b999180000               mov ecx, 0x1899
006d44f6  4889442430               mov qword ptr [rsp + 0x30], rax
006d44fb  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d4502  448bc6                   mov r8d, esi
006d4505  89542428                 mov dword ptr [rsp + 0x28], edx
006d4509  8d560f                   lea edx, [rsi + 0xf]
006d450c  4889442420               mov qword ptr [rsp + 0x20], rax
006d4511  e82a0fb4ff               call 0x215440
006d4516  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d451b  33c0                     xor eax, eax
006d451d  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d4522  4883c460                 add rsp, 0x60
006d4526  5f                       pop rdi
006d4527  c3                       ret

; chunk at RVA 0x6d4528 (277 bytes)
006d4528  4183e801                 sub r8d, 1
006d452c  7473                     je 0x6d45a1
006d452e  4183e801                 sub r8d, 1
006d4532  7468                     je 0x6d459c
006d4534  4183f801                 cmp r8d, 1
006d4538  756c                     jne 0x6d45a6
006d453a  83f933                   cmp ecx, 0x33
006d453d  7405                     je 0x6d4544
006d453f  83f936                   cmp ecx, 0x36
006d4542  7562                     jne 0x6d45a6
006d4544  b901000000               mov ecx, 1
006d4549  4183f9ff                 cmp r9d, -1
006d454d  745c                     je 0x6d45ab
006d454f  4183f901                 cmp r9d, 1
006d4553  7c16                     jl 0x6d456b
006d4555  85c9                     test ecx, ecx
006d4557  b8a00f0000               mov eax, 0xfa0
006d455c  41b8401f0000             mov r8d, 0x1f40
006d4562  410f44c0                 cmove eax, r8d
006d4566  443bc8                   cmp r9d, eax
006d4569  7e40                     jle 0x6d45ab
006d456b  488d050e57cf01           lea rax, [rip + 0x1cf570e]
006d4572  4889442450               mov qword ptr [rsp + 0x50], rax
006d4577  48c74424480e000000       mov qword ptr [rsp + 0x48], 0xe
006d4580  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d4583  488b4708                 mov rax, qword ptr [rdi + 8]
006d4587  03c9                     add ecx, ecx
006d4589  4889442440               mov qword ptr [rsp + 0x40], rax
006d458e  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d4592  b997180000               mov ecx, 0x1897
006d4597  e9fd020000               jmp 0x6d4899
006d459c  83f939                   cmp ecx, 0x39
006d459f  eba1                     jmp 0x6d4542
006d45a1  83f91c                   cmp ecx, 0x1c
006d45a4  749e                     je 0x6d4544
006d45a6  418bcb                   mov ecx, r11d
006d45a9  eb9e                     jmp 0x6d4549
006d45ab  450fb64a14               movzx r9d, byte ptr [r10 + 0x14]
006d45b0  4584c9                   test r9b, r9b
006d45b3  0f84d2000000             je 0x6d468b
006d45b9  8b4a10                   mov ecx, dword ptr [rdx + 0x10]
006d45bc  83e902                   sub ecx, 2
006d45bf  747c                     je 0x6d463d
006d45c1  83f901                   cmp ecx, 1
006d45c4  0f8580000000             jne 0x6d464a
006d45ca  837a1432                 cmp dword ptr [rdx + 0x14], 0x32
006d45ce  757a                     jne 0x6d464a
006d45d0  45385a1c                 cmp byte ptr [r10 + 0x1c], r11b
006d45d4  0f858a000000             jne 0x6d4664
006d45da  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d45de  488b4708                 mov rax, qword ptr [rdi + 8]
006d45e2  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d45e5  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d45e8  03d2                     add edx, edx
006d45ea  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d45f1  03c9                     add ecx, ecx
006d45f3  4889442440               mov qword ptr [rsp + 0x40], rax
006d45f8  4503c9                   add r9d, r9d
006d45fb  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d45ff  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d4603  b99a180000               mov ecx, 0x189a
006d4608  4889442430               mov qword ptr [rsp + 0x30], rax
006d460d  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d4614  89542428                 mov dword ptr [rsp + 0x28], edx
006d4618  ba10000000               mov edx, 0x10
006d461d  4889442420               mov qword ptr [rsp + 0x20], rax
006d4622  448d42f1                 lea r8d, [rdx - 0xf]
006d4626  e8150eb4ff               call 0x215440
006d462b  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d4630  33c0                     xor eax, eax
006d4632  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d4637  4883c460                 add rsp, 0x60
006d463b  5f                       pop rdi
006d463c  c3                       ret

; chunk at RVA 0x6d463d (328 bytes)
006d463d  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d4640  83e91f                   sub ecx, 0x1f
006d4643  748b                     je 0x6d45d0
006d4645  83f901                   cmp ecx, 1
006d4648  7486                     je 0x6d45d0
006d464a  488d05df82cf01           lea rax, [rip + 0x1cf82df]
006d4651  4889442450               mov qword ptr [rsp + 0x50], rax
006d4656  48c744244812000000       mov qword ptr [rsp + 0x48], 0x12
006d465f  e91e020000               jmp 0x6d4882
006d4664  458b5a18                 mov r11d, dword ptr [r10 + 0x18]
006d4668  418d43ff                 lea eax, [r11 - 1]
006d466c  83f825                   cmp eax, 0x25
006d466f  761a                     jbe 0x6d468b
006d4671  488d05b882cf01           lea rax, [rip + 0x1cf82b8]
006d4678  4889442450               mov qword ptr [rsp + 0x50], rax
006d467d  48c744244812000000       mov qword ptr [rsp + 0x48], 0x12
006d4686  e9f5feffff               jmp 0x6d4580
006d468b  41807a1c00               cmp byte ptr [r10 + 0x1c], 0
006d4690  0f849a010000             je 0x6d4830
006d4696  448b4210                 mov r8d, dword ptr [rdx + 0x10]
006d469a  488d355fb992ff           lea rsi, [rip - 0x6d46a1]
006d46a1  4183f802                 cmp r8d, 2
006d46a5  7519                     jne 0x6d46c0
006d46a7  8b4214                   mov eax, dword ptr [rdx + 0x14]
006d46aa  83c0df                   add eax, -0x21
006d46ad  83f806                   cmp eax, 6
006d46b0  7749                     ja 0x6d46fb
006d46b2  4898                     cdqe
006d46b4  8b8c86fc486d00           mov ecx, dword ptr [rsi + rax*4 + 0x6d48fc]
006d46bb  4803ce                   add rcx, rsi
006d46be  ffe1                     jmp rcx
006d46c0  418bc8                   mov ecx, r8d
006d46c3  83e902                   sub ecx, 2
006d46c6  7433                     je 0x6d46fb
006d46c8  83f901                   cmp ecx, 1
006d46cb  753b                     jne 0x6d4708
006d46cd  837a1432                 cmp dword ptr [rdx + 0x14], 0x32
006d46d1  7535                     jne 0x6d4708
006d46d3  4584c9                   test r9b, r9b
006d46d6  0f85a9000000             jne 0x6d4785
006d46dc  4183f802                 cmp r8d, 2
006d46e0  7540                     jne 0x6d4722
006d46e2  8b4214                   mov eax, dword ptr [rdx + 0x14]
006d46e5  83c0df                   add eax, -0x21
006d46e8  83f806                   cmp eax, 6
006d46eb  7735                     ja 0x6d4722
006d46ed  4898                     cdqe
006d46ef  8b8c8618496d00           mov ecx, dword ptr [rsi + rax*4 + 0x6d4918]
006d46f6  4803ce                   add rcx, rsi
006d46f9  ffe1                     jmp rcx
006d46fb  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d46fe  83e91f                   sub ecx, 0x1f
006d4701  74d0                     je 0x6d46d3
006d4703  83f901                   cmp ecx, 1
006d4706  74cb                     je 0x6d46d3
006d4708  488d052958cf01           lea rax, [rip + 0x1cf5829]
006d470f  4889442450               mov qword ptr [rsp + 0x50], rax
006d4714  48c74424480a000000       mov qword ptr [rsp + 0x48], 0xa
006d471d  e960010000               jmp 0x6d4882
006d4722  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d4726  488b4708                 mov rax, qword ptr [rdi + 8]
006d472a  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d472d  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d4730  03d2                     add edx, edx
006d4732  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d4739  03c9                     add ecx, ecx
006d473b  4889442440               mov qword ptr [rsp + 0x40], rax
006d4740  4503c9                   add r9d, r9d
006d4743  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d4747  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d474b  b99a180000               mov ecx, 0x189a
006d4750  4889442430               mov qword ptr [rsp + 0x30], rax
006d4755  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d475c  89542428                 mov dword ptr [rsp + 0x28], edx
006d4760  ba10000000               mov edx, 0x10
006d4765  4889442420               mov qword ptr [rsp + 0x20], rax
006d476a  448d42f1                 lea r8d, [rdx - 0xf]
006d476e  e8cd0cb4ff               call 0x215440
006d4773  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d4778  33c0                     xor eax, eax
006d477a  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d477f  4883c460                 add rsp, 0x60
006d4783  5f                       pop rdi
006d4784  c3                       ret

; chunk at RVA 0x6d4785 (171 bytes)
006d4785  458b4a20                 mov r9d, dword ptr [r10 + 0x20]
006d4789  4585c9                   test r9d, r9d
006d478c  782a                     js 0x6d47b8
006d478e  4183f802                 cmp r8d, 2
006d4792  751f                     jne 0x6d47b3
006d4794  8b4214                   mov eax, dword ptr [rdx + 0x14]
006d4797  83c0df                   add eax, -0x21
006d479a  83f806                   cmp eax, 6
006d479d  7714                     ja 0x6d47b3
006d479f  4898                     cdqe
006d47a1  8b8c8634496d00           mov ecx, dword ptr [rsi + rax*4 + 0x6d4934]
006d47a8  4803ce                   add rcx, rsi
006d47ab  ffe1                     jmp rcx
006d47ad  41bb07000000             mov r11d, 7
006d47b3  453bcb                   cmp r9d, r11d
006d47b6  7e78                     jle 0x6d4830
006d47b8  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d47bc  488d057557cf01           lea rax, [rip + 0x1cf5775]
006d47c3  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d47c6  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d47c9  03d2                     add edx, edx
006d47cb  4889442450               mov qword ptr [rsp + 0x50], rax
006d47d0  03c9                     add ecx, ecx
006d47d2  488b4708                 mov rax, qword ptr [rdi + 8]
006d47d6  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d47dd  48c74424480a000000       mov qword ptr [rsp + 0x48], 0xa
006d47e6  4503c9                   add r9d, r9d
006d47e9  4889442440               mov qword ptr [rsp + 0x40], rax
006d47ee  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d47f2  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d47f6  b997180000               mov ecx, 0x1897
006d47fb  4889442430               mov qword ptr [rsp + 0x30], rax
006d4800  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d4807  89542428                 mov dword ptr [rsp + 0x28], edx
006d480b  ba10000000               mov edx, 0x10
006d4810  4889442420               mov qword ptr [rsp + 0x20], rax
006d4815  448d42f1                 lea r8d, [rdx - 0xf]
006d4819  e8220cb4ff               call 0x215440
006d481e  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d4823  33c0                     xor eax, eax
006d4825  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d482a  4883c460                 add rsp, 0x60
006d482e  5f                       pop rdi
006d482f  c3                       ret

; chunk at RVA 0x6d4830 (181 bytes)
006d4830  41807a0a00               cmp byte ptr [r10 + 0xa], 0
006d4835  0f84aa000000             je 0x6d48e5
006d483b  8b4a10                   mov ecx, dword ptr [rdx + 0x10]
006d483e  83e901                   sub ecx, 1
006d4841  7424                     je 0x6d4867
006d4843  83e901                   sub ecx, 1
006d4846  740e                     je 0x6d4856
006d4848  83e901                   sub ecx, 1
006d484b  0f8494000000             je 0x6d48e5
006d4851  83f901                   cmp ecx, 1
006d4854  eb15                     jmp 0x6d486b
006d4856  8b4a14                   mov ecx, dword ptr [rdx + 0x14]
006d4859  83e938                   sub ecx, 0x38
006d485c  0f8483000000             je 0x6d48e5
006d4862  83f901                   cmp ecx, 1
006d4865  eb04                     jmp 0x6d486b
006d4867  837a141c                 cmp dword ptr [rdx + 0x14], 0x1c
006d486b  7478                     je 0x6d48e5
006d486d  488d05ec53cf01           lea rax, [rip + 0x1cf53ec]
006d4874  4889442450               mov qword ptr [rsp + 0x50], rax
006d4879  48c744244814000000       mov qword ptr [rsp + 0x48], 0x14
006d4882  8b4f10                   mov ecx, dword ptr [rdi + 0x10]
006d4885  488b4708                 mov rax, qword ptr [rdi + 8]
006d4889  03c9                     add ecx, ecx
006d488b  4889442440               mov qword ptr [rsp + 0x40], rax
006d4890  894c2438                 mov dword ptr [rsp + 0x38], ecx
006d4894  b996180000               mov ecx, 0x1896
006d4899  4c8b4318                 mov r8, qword ptr [rbx + 0x18]
006d489d  8b5330                   mov edx, dword ptr [rbx + 0x30]
006d48a0  488b4328                 mov rax, qword ptr [rbx + 0x28]
006d48a4  03d2                     add edx, edx
006d48a6  4889442430               mov qword ptr [rsp + 0x30], rax
006d48ab  458b88a0000000           mov r9d, dword ptr [r8 + 0xa0]
006d48b2  498b8098000000           mov rax, qword ptr [r8 + 0x98]
006d48b9  4503c9                   add r9d, r9d
006d48bc  89542428                 mov dword ptr [rsp + 0x28], edx
006d48c0  ba10000000               mov edx, 0x10
006d48c5  4889442420               mov qword ptr [rsp + 0x20], rax
006d48ca  448d42f1                 lea r8d, [rdx - 0xf]
006d48ce  e86d0bb4ff               call 0x215440
006d48d3  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d48d8  33c0                     xor eax, eax
006d48da  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d48df  4883c460                 add rsp, 0x60
006d48e3  5f                       pop rdi
006d48e4  c3                       ret

; chunk at RVA 0x6d48e5 (21 bytes)
006d48e5  488b742470               mov rsi, qword ptr [rsp + 0x70]
006d48ea  b801000000               mov eax, 1
006d48ef  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
006d48f4  4883c460                 add rsp, 0x60
006d48f8  5f                       pop rdi
006d48f9  c3                       ret

; chunk at RVA 0x6d48fc (84 bytes)
006d48fc  d3466d                   rol dword ptr [rsi + 0x6d], cl
006d48ff  00d3                     add bl, dl
006d4901  466d                     insd dword ptr [rdi], dx
006d4903  00d3                     add bl, dl
006d4905  466d                     insd dword ptr [rdi], dx
006d4907  00d3                     add bl, dl
006d4909  466d                     insd dword ptr [rdi], dx
006d490b  00fb                     add bl, bh
006d490d  466d                     insd dword ptr [rdi], dx
006d490f  00d3                     add bl, dl
006d4911  466d                     insd dword ptr [rdi], dx
006d4913  00d3                     add bl, dl
006d4915  466d                     insd dword ptr [rdi], dx
006d4917  0085476d0085             add byte ptr [rbp - 0x7aff92b9], al
006d491d  476d                     insd dword ptr [rdi], dx
006d491f  0085476d0085             add byte ptr [rbp - 0x7aff92b9], al
006d4925  476d                     insd dword ptr [rdi], dx
006d4927  0022                     add byte ptr [rdx], ah
006d4929  476d                     insd dword ptr [rdi], dx
006d492b  0085476d0085             add byte ptr [rbp - 0x7aff92b9], al
006d4931  476d                     insd dword ptr [rdi], dx
006d4933  00ad476d00ad             add byte ptr [rbp - 0x52ff92b9], ch
006d4939  476d                     insd dword ptr [rdi], dx
006d493b  00ad476d00ad             add byte ptr [rbp - 0x52ff92b9], ch
006d4941  476d                     insd dword ptr [rdi], dx
006d4943  00b3476d00ad             add byte ptr [rbx - 0x52ff92b9], dh
006d4949  476d                     insd dword ptr [rdi], dx
