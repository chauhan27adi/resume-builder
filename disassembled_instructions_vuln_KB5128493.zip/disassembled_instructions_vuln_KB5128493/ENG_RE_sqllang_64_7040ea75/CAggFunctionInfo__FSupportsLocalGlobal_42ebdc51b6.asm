; CAggFunctionInfo::FSupportsLocalGlobal
; sqllang.dll, primary RVA 0x14f930, 155 bytes in 1 chunk(s)

; chunk at RVA 0x14f930 (155 bytes)
0014f930  4053                     push rbx
0014f932  4883ec20                 sub rsp, 0x20
0014f936  488b5960                 mov rbx, qword ptr [rcx + 0x60]
0014f93a  488bcb                   mov rcx, rbx
0014f93d  488b03                   mov rax, qword ptr [rbx]
0014f940  ff5010                   call qword ptr [rax + 0x10]
0014f943  85c0                     test eax, eax
0014f945  7430                     je 0x14f977
0014f947  488b03                   mov rax, qword ptr [rbx]
0014f94a  488bcb                   mov rcx, rbx
0014f94d  ff5018                   call qword ptr [rax + 0x18]
0014f950  83f83a                   cmp eax, 0x3a
0014f953  0f872a507400             ja 0x894983
0014f959  488d15a006ebff           lea rdx, [rip - 0x14f960]
0014f960  4898                     cdqe
0014f962  0fb6840290f91400         movzx eax, byte ptr [rdx + rax + 0x14f990]
0014f96a  8b8c8280f91400           mov ecx, dword ptr [rdx + rax*4 + 0x14f980]
0014f971  4803ca                   add rcx, rdx
0014f974  ffe1                     jmp rcx
0014f976  cc                       int3
0014f977  b001                     mov al, 1
0014f979  4883c420                 add rsp, 0x20
0014f97d  5b                       pop rbx
0014f97e  c3                       ret
0014f97f  90                       nop
0014f980  77f9                     ja 0x14f97b
0014f982  1400                     adc al, 0
0014f984  83498900                 or dword ptr [rcx - 0x77], 0
0014f988  7949                     jns 0x14f9d3
0014f98a  8900                     mov dword ptr [rax], eax
0014f98c  83498900                 or dword ptr [rcx - 0x77], 0
0014f990  0003                     add byte ptr [rbx], al
0014f992  0003                     add byte ptr [rbx], al
0014f994  0103                     add dword ptr [rbx], eax
0014f996  0003                     add byte ptr [rbx], al
0014f998  0003                     add byte ptr [rbx], al
0014f99a  0103                     add dword ptr [rbx], eax
0014f99c  0001                     add byte ptr [rcx], al
0014f99e  0301                     add eax, dword ptr [rcx]
0014f9a0  0101                     add dword ptr [rcx], eax
0014f9a2  0101                     add dword ptr [rcx], eax
0014f9a4  0101                     add dword ptr [rcx], eax
0014f9a6  0101                     add dword ptr [rcx], eax
0014f9a8  0101                     add dword ptr [rcx], eax
0014f9aa  0101                     add dword ptr [rcx], eax
0014f9ac  0001                     add byte ptr [rcx], al
0014f9ae  0001                     add byte ptr [rcx], al
0014f9b0  0103                     add dword ptr [rbx], eax
0014f9b2  0000                     add byte ptr [rax], al
0014f9b4  0301                     add eax, dword ptr [rcx]
0014f9b6  0203                     add al, byte ptr [rbx]
0014f9b8  0301                     add eax, dword ptr [rcx]
0014f9ba  0100                     add dword ptr [rax], eax
0014f9bc  0001                     add byte ptr [rcx], al
0014f9be  0100                     add dword ptr [rax], eax
0014f9c0  0001                     add byte ptr [rcx], al
0014f9c2  0001                     add byte ptr [rcx], al
0014f9c4  0101                     add dword ptr [rcx], eax
0014f9c6  0100                     add dword ptr [rax], eax
0014f9c8  0001                     add byte ptr [rcx], al
