; CDecompressBatchLoader<Level2Batch,CLevel2Decompressor,CSeekPruneRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x9748a0, 1434 bytes in 3 chunk(s)

; chunk at RVA 0x9748a0 (58 bytes)
009748a0  4c894c2420               mov qword ptr [rsp + 0x20], r9
009748a5  89542410                 mov dword ptr [rsp + 0x10], edx
009748a9  55                       push rbp
009748aa  53                       push rbx
009748ab  4154                     push r12
009748ad  4157                     push r15
009748af  488d6c24c1               lea rbp, [rsp - 0x3f]
009748b4  4881ecd8000000           sub rsp, 0xd8
009748bb  83792002                 cmp dword ptr [rcx + 0x20], 2
009748bf  4d8be0                   mov r12, r8
009748c2  448bfa                   mov r15d, edx
009748c5  488bd9                   mov rbx, rcx
009748c8  7510                     jne 0x9748da
009748ca  33c0                     xor eax, eax
009748cc  4881c4d8000000           add rsp, 0xd8
009748d3  415f                     pop r15
009748d5  415c                     pop r12
009748d7  5b                       pop rbx
009748d8  5d                       pop rbp
009748d9  c3                       ret

; chunk at RVA 0x9748da (1280 bytes)
009748da  4889b42410010000         mov qword ptr [rsp + 0x110], rsi
009748e2  0f57c0                   xorps xmm0, xmm0
009748e5  4889bc24d0000000         mov qword ptr [rsp + 0xd0], rdi
009748ed  0f57c9                   xorps xmm1, xmm1
009748f0  33ff                     xor edi, edi
009748f2  4c89ac24c8000000         mov qword ptr [rsp + 0xc8], r13
009748fa  32c9                     xor cl, cl
009748fc  4c89b424c0000000         mov qword ptr [rsp + 0xc0], r14
00974904  884d67                   mov byte ptr [rbp + 0x67], cl
00974907  897dc7                   mov dword ptr [rbp - 0x39], edi
0097490a  48897dcf                 mov qword ptr [rbp - 0x31], rdi
0097490e  40887dd7                 mov byte ptr [rbp - 0x29], dil
00974912  660f7f45e7               movdqa xmmword ptr [rbp - 0x19], xmm0
00974917  660f7f4df7               movdqa xmmword ptr [rbp - 9], xmm1
0097491c  660f7f4507               movdqa xmmword ptr [rbp + 7], xmm0
00974921  48897d17                 mov qword ptr [rbp + 0x17], rdi
00974925  c7451f01000000           mov dword ptr [rbp + 0x1f], 1
0097492c  897d87                   mov dword ptr [rbp - 0x79], edi
0097492f  41887c2410               mov byte ptr [r12 + 0x10], dil
00974934  4c8d2dc5b668ff           lea r13, [rip - 0x97493b]
0097493b  4038bbc81d0000           cmp byte ptr [rbx + 0x1dc8], dil
00974942  747e                     je 0x9749c2
00974944  4c8b83c01d0000           mov r8, qword ptr [rbx + 0x1dc0]
0097494b  33d2                     xor edx, edx
0097494d  498bcc                   mov rcx, r12
00974950  4088bbc81d0000           mov byte ptr [rbx + 0x1dc8], dil
00974957  e8f485ffff               call 0x96cf50
0097495c  488b83c01d0000           mov rax, qword ptr [rbx + 0x1dc0]
00974963  488d75c7                 lea rsi, [rbp - 0x39]
00974967  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
0097496b  897dc7                   mov dword ptr [rbp - 0x39], edi
0097496e  c7458701000000           mov dword ptr [rbp - 0x79], 1
00974975  ff08                     dec dword ptr [rax]
00974977  418b1424                 mov edx, dword ptr [r12]
0097497b  498b442408               mov rax, qword ptr [r12 + 8]
00974980  488945cf                 mov qword ptr [rbp - 0x31], rax
00974984  498b442420               mov rax, qword ptr [r12 + 0x20]
00974989  488d0cd0                 lea rcx, [rax + rdx*8]
0097498d  498b442428               mov rax, qword ptr [r12 + 0x28]
00974992  48894de7                 mov qword ptr [rbp - 0x19], rcx
00974996  488d0c90                 lea rcx, [rax + rdx*4]
0097499a  498b442430               mov rax, qword ptr [r12 + 0x30]
0097499f  48894def                 mov qword ptr [rbp - 0x11], rcx
009749a3  4088bbc81d0000           mov byte ptr [rbx + 0x1dc8], dil
009749aa  488d0c90                 lea rcx, [rax + rdx*4]
009749ae  b801000000               mov eax, 1
009749b3  2bc2                     sub eax, edx
009749b5  48894df7                 mov qword ptr [rbp - 9], rcx
009749b9  4403f8                   add r15d, eax
009749bc  44897d6f                 mov dword ptr [rbp + 0x6f], r15d
009749c0  eb03                     jmp 0x9749c5
009749c2  498bf4                   mov rsi, r12
009749c5  397b20                   cmp dword ptr [rbx + 0x20], edi
009749c8  0f85b3000000             jne 0x974a81
009749ce  488b4328                 mov rax, qword ptr [rbx + 0x28]
009749d2  488d4b28                 lea rcx, [rbx + 0x28]
009749d6  4d8bc1                   mov r8, r9
009749d9  48897d8f                 mov qword ptr [rbp - 0x71], rdi
009749dd  488d558f                 lea rdx, [rbp - 0x71]
009749e1  897d97                   mov dword ptr [rbp - 0x69], edi
009749e4  48897d9f                 mov qword ptr [rbp - 0x61], rdi
009749e8  897da7                   mov dword ptr [rbp - 0x59], edi
009749eb  48897daf                 mov qword ptr [rbp - 0x51], rdi
009749ef  897db7                   mov dword ptr [rbp - 0x49], edi
009749f2  66897dbb                 mov word ptr [rbp - 0x45], di
009749f6  c6456701                 mov byte ptr [rbp + 0x67], 1
009749fa  ff10                     call qword ptr [rax]
009749fc  3dc60e0400               cmp eax, 0x40ec6
00974a01  0f8483030000             je 0x974d8a
00974a07  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
00974a0b  8b4597                   mov eax, dword ptr [rbp - 0x69]
00974a0e  48898b60090000           mov qword ptr [rbx + 0x960], rcx
00974a15  48898b68090000           mov qword ptr [rbx + 0x968], rcx
00974a1c  488b4d9f                 mov rcx, qword ptr [rbp - 0x61]
00974a20  898358090000             mov dword ptr [rbx + 0x958], eax
00974a26  8b45a7                   mov eax, dword ptr [rbp - 0x59]
00974a29  48898b300c0000           mov qword ptr [rbx + 0xc30], rcx
00974a30  48898b380c0000           mov qword ptr [rbx + 0xc38], rcx
00974a37  4889bb50090000           mov qword ptr [rbx + 0x950], rdi
00974a3e  6689bb180c0000           mov word ptr [rbx + 0xc18], di
00974a45  4889bb100c0000           mov qword ptr [rbx + 0xc10], rdi
00974a4c  8983280c0000             mov dword ptr [rbx + 0xc28], eax
00974a52  4889bb200c0000           mov qword ptr [rbx + 0xc20], rdi
00974a59  4889bbac1d0000           mov qword ptr [rbx + 0x1dac], rdi
00974a60  c783b41d000000000101     mov dword ptr [rbx + 0x1db4], 0x1010000
00974a6a  c783a81d000001000000     mov dword ptr [rbx + 0x1da8], 1
00974a74  89bba01c0000             mov dword ptr [rbx + 0x1ca0], edi
00974a7a  c7432001000000           mov dword ptr [rbx + 0x20], 1
00974a81  488b4330                 mov rax, qword ptr [rbx + 0x30]
00974a85  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00974a8c  4c894608                 mov qword ptr [rsi + 8], r8
00974a90  488b5330                 mov rdx, qword ptr [rbx + 0x30]
00974a94  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00974a9b  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00974a9e  83e007                   and eax, 7
00974aa1  83f805                   cmp eax, 5
00974aa4  7741                     ja 0x974ae7
00974aa6  4898                     cdqe
00974aa8  418b8c85dc4d9700         mov ecx, dword ptr [r13 + rax*4 + 0x974ddc]
00974ab0  4903cd                   add rcx, r13
00974ab3  ffe1                     jmp rcx
00974ab5  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974ab9  410f95c6                 setne r14b
00974abd  eb2b                     jmp 0x974aea
00974abf  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974ac3  410f9dc6                 setge r14b
00974ac7  eb21                     jmp 0x974aea
00974ac9  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974acd  410f9ec6                 setle r14b
00974ad1  eb17                     jmp 0x974aea
00974ad3  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974ad7  410f9fc6                 setg r14b
00974adb  eb0d                     jmp 0x974aea
00974add  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00974ae1  410f9cc6                 setl r14b
00974ae5  eb03                     jmp 0x974aea
00974ae7  4532f6                   xor r14b, r14b
00974aea  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00974aed  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00974af4  83e007                   and eax, 7
00974af7  83f805                   cmp eax, 5
00974afa  7741                     ja 0x974b3d
00974afc  4898                     cdqe
00974afe  418b8c85f44d9700         mov ecx, dword ptr [r13 + rax*4 + 0x974df4]
00974b06  4903cd                   add rcx, r13
00974b09  ffe1                     jmp rcx
00974b0b  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974b0f  410f95c5                 setne r13b
00974b13  eb2b                     jmp 0x974b40
00974b15  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974b19  410f9dc5                 setge r13b
00974b1d  eb21                     jmp 0x974b40
00974b1f  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974b23  410f9ec5                 setle r13b
00974b27  eb17                     jmp 0x974b40
00974b29  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974b2d  410f9fc5                 setg r13b
00974b31  eb0d                     jmp 0x974b40
00974b33  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00974b37  410f9cc5                 setl r13b
00974b3b  eb03                     jmp 0x974b40
00974b3d  4532ed                   xor r13b, r13b
00974b40  488d8b48090000           lea rcx, [rbx + 0x948]
00974b47  4c8bc6                   mov r8, rsi
00974b4a  418bd7                   mov edx, r15d
00974b4d  e85e95ffff               call 0x96e0b0
00974b52  84c0                     test al, al
00974b54  7503                     jne 0x974b59
00974b56  897b20                   mov dword ptr [rbx + 0x20], edi
00974b59  8b16                     mov edx, dword ptr [rsi]
00974b5b  448bc2                   mov r8d, edx
00974b5e  85d2                     test edx, edx
00974b60  0f84c3010000             je 0x974d29
00974b66  4584f6                   test r14b, r14b
00974b69  7509                     jne 0x974b74
00974b6b  4584ed                   test r13b, r13b
00974b6e  0f84b5010000             je 0x974d29
00974b74  448bca                   mov r9d, edx
00974b77  4584f6                   test r14b, r14b
00974b7a  0f847f000000             je 0x974bff
00974b80  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00974b84  448bd7                   mov r10d, edi
00974b87  85d2                     test edx, edx
00974b89  746d                     je 0x974bf8
00974b8b  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00974b8f  4c8d3d6ab468ff           lea r15, [rip - 0x974b96]
00974b96  4c8b7620                 mov r14, qword ptr [rsi + 0x20]
00974b9a  4183e007                 and r8d, 7
00974b9e  6690                     nop
00974ba0  418bc2                   mov eax, r10d
00974ba3  4d8b0cc6                 mov r9, qword ptr [r14 + rax*8]
00974ba7  4183f805                 cmp r8d, 5
00974bab  0f87ad000000             ja 0x974c5e
00974bb1  4963c0                   movsxd rax, r8d
00974bb4  418b8c870c4e9700         mov ecx, dword ptr [r15 + rax*4 + 0x974e0c]
00974bbc  4903cf                   add rcx, r15
00974bbf  ffe1                     jmp rcx
00974bc1  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974bc5  0f94c0                   sete al
00974bc8  eb22                     jmp 0x974bec
00974bca  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974bce  0f9cc0                   setl al
00974bd1  eb19                     jmp 0x974bec
00974bd3  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974bd7  0f9fc0                   setg al
00974bda  eb10                     jmp 0x974bec
00974bdc  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974be0  0f9ec0                   setle al
00974be3  eb07                     jmp 0x974bec
00974be5  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00974be9  0f9dc0                   setge al
00974bec  84c0                     test al, al
00974bee  756e                     jne 0x974c5e
00974bf0  41ffc2                   inc r10d
00974bf3  443bd2                   cmp r10d, edx
00974bf6  72a8                     jb 0x974ba0
00974bf8  893e                     mov dword ptr [rsi], edi
00974bfa  8bd7                     mov edx, edi
00974bfc  448bcf                   mov r9d, edi
00974bff  458bc1                   mov r8d, r9d
00974c02  4584ed                   test r13b, r13b
00974c05  0f841e010000             je 0x974d29
00974c0b  85d2                     test edx, edx
00974c0d  0f8416010000             je 0x974d29
00974c13  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00974c17  4c8d2de2b368ff           lea r13, [rip - 0x974c1e]
00974c1e  4c8b7e20                 mov r15, qword ptr [rsi + 0x20]
00974c22  0f1f4000                 nop dword ptr [rax]
00974c26  66660f1f840000000000     nop word ptr [rax + rax]
00974c30  418b434c                 mov eax, dword ptr [r11 + 0x4c]
00974c34  ffca                     dec edx
00974c36  458bd1                   mov r10d, r9d
00974c39  83e007                   and eax, 7
00974c3c  448bca                   mov r9d, edx
00974c3f  458bc2                   mov r8d, r10d
00974c42  4d8b34d7                 mov r14, qword ptr [r15 + rdx*8]
00974c46  83f805                   cmp eax, 5
00974c49  0f87da000000             ja 0x974d29
00974c4f  4898                     cdqe
00974c51  418b8c85244e9700         mov ecx, dword ptr [r13 + rax*4 + 0x974e24]
00974c59  4903cd                   add rcx, r13
00974c5c  ffe1                     jmp rcx
00974c5e  443bd2                   cmp r10d, edx
00974c61  7395                     jae 0x974bf8
00974c63  448bca                   mov r9d, edx
00974c66  4585d2                   test r10d, r10d
00974c69  7494                     je 0x974bff
00974c6b  8bd7                     mov edx, edi
00974c6d  452bca                   sub r9d, r10d
00974c70  7470                     je 0x974ce2
00974c72  4c8bc7                   mov r8, rdi
00974c75  4c8bdf                   mov r11, rdi
00974c78  4c8bf7                   mov r14, rdi
00974c7b  0f1f440000               nop dword ptr [rax + rax]
00974c80  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00974c84  428d0412                 lea eax, [rdx + r10]
00974c88  448bf8                   mov r15d, eax
00974c8b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
00974c8f  4989040e                 mov qword ptr [r14 + rcx], rax
00974c93  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
00974c97  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00974c9b  4189040b                 mov dword ptr [r11 + rcx], eax
00974c9f  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
00974ca3  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00974ca7  4d03ff                   add r15, r15
00974caa  4189040b                 mov dword ptr [r11 + rcx], eax
00974cae  488b4638                 mov rax, qword ptr [rsi + 0x38]
00974cb2  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00974cb7  420f110400               movups xmmword ptr [rax + r8], xmm0
00974cbc  488b4648                 mov rax, qword ptr [rsi + 0x48]
00974cc0  4885c0                   test rax, rax
00974cc3  740a                     je 0x974ccf
00974cc5  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00974cca  420f110400               movups xmmword ptr [rax + r8], xmm0
00974ccf  ffc2                     inc edx
00974cd1  4983c608                 add r14, 8
00974cd5  4983c304                 add r11, 4
00974cd9  4983c010                 add r8, 0x10
00974cdd  413bd1                   cmp edx, r9d
00974ce0  729e                     jb 0x974c80
00974ce2  44890e                   mov dword ptr [rsi], r9d
00974ce5  418bd1                   mov edx, r9d
00974ce8  e912ffffff               jmp 0x974bff
00974ced  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974cf1  0f94c0                   sete al
00974cf4  eb22                     jmp 0x974d18
00974cf6  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974cfa  0f9cc0                   setl al
00974cfd  eb19                     jmp 0x974d18
00974cff  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974d03  0f9fc0                   setg al
00974d06  eb10                     jmp 0x974d18
00974d08  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974d0c  0f9ec0                   setle al
00974d0f  eb07                     jmp 0x974d18
00974d11  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00974d15  0f9dc0                   setge al
00974d18  84c0                     test al, al
00974d1a  750d                     jne 0x974d29
00974d1c  8916                     mov dword ptr [rsi], edx
00974d1e  448bc2                   mov r8d, edx
00974d21  85d2                     test edx, edx
00974d23  0f8507ffffff             jne 0x974c30
00974d29  4038bbc91d0000           cmp byte ptr [rbx + 0x1dc9], dil
00974d30  7440                     je 0x974d72
00974d32  448b06                   mov r8d, dword ptr [rsi]
00974d35  4585c0                   test r8d, r8d
00974d38  7438                     je 0x974d72
00974d3a  488b8bc01d0000           mov rcx, qword ptr [rbx + 0x1dc0]
00974d41  4c8bc6                   mov r8, rsi
00974d44  c683c81d000001           mov byte ptr [rbx + 0x1dc8], 1
00974d4b  8b16                     mov edx, dword ptr [rsi]
00974d4d  ffca                     dec edx
00974d4f  e8fc81ffff               call 0x96cf50
00974d54  ff0e                     dec dword ptr [rsi]
00974d56  41c644241001             mov byte ptr [r12 + 0x10], 1
00974d5c  488b83c01d0000           mov rax, qword ptr [rbx + 0x1dc0]
00974d63  488b4820                 mov rcx, qword ptr [rax + 0x20]
00974d67  488b01                   mov rax, qword ptr [rcx]
00974d6a  4989442418               mov qword ptr [r12 + 0x18], rax
00974d6f  448b06                   mov r8d, dword ptr [rsi]
00974d72  8b4587                   mov eax, dword ptr [rbp - 0x79]
00974d75  4103c0                   add eax, r8d
00974d78  894587                   mov dword ptr [rbp - 0x79], eax
00974d7b  7520                     jne 0x974d9d
00974d7d  448b7d6f                 mov r15d, dword ptr [rbp + 0x6f]
00974d81  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00974d85  e9a5fbffff               jmp 0x97492f
00974d8a  c7432002000000           mov dword ptr [rbx + 0x20], 2
00974d91  41393c24                 cmp dword ptr [r12], edi
00974d95  400f95c7                 setne dil
00974d99  8bc7                     mov eax, edi
00974d9b  eb0f                     jmp 0x974dac
00974d9d  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00974da1  f6d9                     neg cl
00974da3  41890424                 mov dword ptr [r12], eax
00974da7  1bc0                     sbb eax, eax
00974da9  83c002                   add eax, 2
00974dac  4c8bac24c8000000         mov r13, qword ptr [rsp + 0xc8]
00974db4  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00974dbc  488bb42410010000         mov rsi, qword ptr [rsp + 0x110]
00974dc4  4c8bb424c0000000         mov r14, qword ptr [rsp + 0xc0]
00974dcc  4881c4d8000000           add rsp, 0xd8
00974dd3  415f                     pop r15
00974dd5  415c                     pop r12
00974dd7  5b                       pop rbx
00974dd8  5d                       pop rbp
00974dd9  c3                       ret

; chunk at RVA 0x974ddc (96 bytes)
00974ddc  e74a                     out 0x4a, eax
00974dde  97                       xchg edi, eax
00974ddf  00b54a9700bf             add byte ptr [rbp - 0x40ff68b6], dh
00974de5  4a97                     xchg rdi, rax
00974de7  00d3                     add bl, dl
00974de9  4a97                     xchg rdi, rax
00974deb  00c9                     add cl, cl
00974ded  4a97                     xchg rdi, rax
00974def  00dd                     add ch, bl
00974df1  4a97                     xchg rdi, rax
00974df3  003d4b97000b             add byte ptr [rip + 0xb00974b], bh
00974df9  4b97                     xchg r15, rax
00974dfb  00154b970029             add byte ptr [rip + 0x2900974b], dl
00974e01  4b97                     xchg r15, rax
00974e03  001f                     add byte ptr [rdi], bl
00974e05  4b97                     xchg r15, rax
00974e07  0033                     add byte ptr [rbx], dh
00974e09  4b97                     xchg r15, rax
00974e0b  005e4c                   add byte ptr [rsi + 0x4c], bl
00974e0e  97                       xchg edi, eax
00974e0f  00c1                     add cl, al
00974e11  4b97                     xchg r15, rax
00974e13  00ca                     add dl, cl
00974e15  4b97                     xchg r15, rax
00974e17  00dc                     add ah, bl
00974e19  4b97                     xchg r15, rax
00974e1b  00d3                     add bl, dl
00974e1d  4b97                     xchg r15, rax
00974e1f  00e5                     add ch, ah
00974e21  4b97                     xchg r15, rax
00974e23  0029                     add byte ptr [rcx], ch
00974e25  4d97                     xchg r15, rax
00974e27  00ed                     add ch, ch
00974e29  4c97                     xchg rdi, rax
00974e2b  00f6                     add dh, dh
00974e2d  4c97                     xchg rdi, rax
00974e2f  0008                     add byte ptr [rax], cl
00974e31  4d97                     xchg r15, rax
00974e33  00ff                     add bh, bh
00974e35  4c97                     xchg rdi, rax
00974e37  0011                     add byte ptr [rcx], dl
00974e39  4d97                     xchg r15, rax
