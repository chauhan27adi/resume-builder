; CAlgStmt::GetOptExprs
; sqllang.dll, primary RVA 0x2c3f50, 102 bytes in 1 chunk(s)

; chunk at RVA 0x2c3f50 (102 bytes)
002c3f50  48895c2408               mov qword ptr [rsp + 8], rbx
002c3f55  48896c2410               mov qword ptr [rsp + 0x10], rbp
002c3f5a  4889742418               mov qword ptr [rsp + 0x18], rsi
002c3f5f  48897c2420               mov qword ptr [rsp + 0x20], rdi
002c3f64  4156                     push r14
002c3f66  4883ec30                 sub rsp, 0x30
002c3f6a  33db                     xor ebx, ebx
002c3f6c  488be9                   mov rbp, rcx
002c3f6f  891a                     mov dword ptr [rdx], ebx
002c3f71  4d8bf0                   mov r14, r8
002c3f74  488b4918                 mov rcx, qword ptr [rcx + 0x18]
002c3f78  488bfa                   mov rdi, rdx
002c3f7b  8bf3                     mov esi, ebx
002c3f7d  4885c9                   test rcx, rcx
002c3f80  0f8598040000             jne 0x2c441e
002c3f86  48395d10                 cmp qword ptr [rbp + 0x10], rbx
002c3f8a  757a                     jne 0x2c4006
002c3f8c  48399df0000000           cmp qword ptr [rbp + 0xf0], rbx
002c3f93  7571                     jne 0x2c4006
002c3f95  488bc6                   mov rax, rsi
002c3f98  eb01                     jmp 0x2c3f9b
002c3f9a  cc                       int3
002c3f9b  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
002c3fa0  488b6c2448               mov rbp, qword ptr [rsp + 0x48]
002c3fa5  488b742450               mov rsi, qword ptr [rsp + 0x50]
002c3faa  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
002c3faf  4883c430                 add rsp, 0x30
002c3fb3  415e                     pop r14
002c3fb5  c3                       ret
