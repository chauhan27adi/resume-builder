; CDeltaInternalQueryExecutor::ListLog
; sqllang.dll, primary RVA 0x1ae99b0, 456 bytes in 1 chunk(s)

; chunk at RVA 0x1ae99b0 (456 bytes)
01ae99b0  48895c2408               mov qword ptr [rsp + 8], rbx
01ae99b5  4889742410               mov qword ptr [rsp + 0x10], rsi
01ae99ba  57                       push rdi
01ae99bb  4883ec20                 sub rsp, 0x20
01ae99bf  488b81a0000000           mov rax, qword ptr [rcx + 0xa0]
01ae99c6  410fb6d8                 movzx ebx, r8b
01ae99ca  0fb6f2                   movzx esi, dl
01ae99cd  488bf9                   mov rdi, rcx
01ae99d0  4883781000               cmp qword ptr [rax + 0x10], 0
01ae99d5  750c                     jne 0x1ae99e3
01ae99d7  4883781800               cmp qword ptr [rax + 0x18], 0
01ae99dc  7505                     jne 0x1ae99e3
01ae99de  e85de2ffff               call 0x1ae7c40
01ae99e3  41b908000000             mov r9d, 8
01ae99e9  458d41ff                 lea r8d, [r9 - 1]
01ae99ed  84db                     test bl, bl
01ae99ef  742b                     je 0x1ae9a1c
01ae99f1  488b8fa0000000           mov rcx, qword ptr [rdi + 0xa0]
01ae99f8  8b5120                   mov edx, dword ptr [rcx + 0x20]
01ae99fb  85d2                     test edx, edx
01ae99fd  7416                     je 0x1ae9a15
01ae99ff  83ea01                   sub edx, 1
01ae9a02  740b                     je 0x1ae9a0f
01ae9a04  83fa01                   cmp edx, 1
01ae9a07  7513                     jne 0x1ae9a1c
01ae9a09  44894920                 mov dword ptr [rcx + 0x20], r9d
01ae9a0d  eb0d                     jmp 0x1ae9a1c
01ae9a0f  44894120                 mov dword ptr [rcx + 0x20], r8d
01ae9a13  eb07                     jmp 0x1ae9a1c
01ae9a15  c7412006000000           mov dword ptr [rcx + 0x20], 6
01ae9a1c  488b8fa0000000           mov rcx, qword ptr [rdi + 0xa0]
01ae9a23  4084f6                   test sil, sil
01ae9a26  0f848a000000             je 0x1ae9ab6
01ae9a2c  c6475001                 mov byte ptr [rdi + 0x50], 1
01ae9a30  48634120                 movsxd rax, dword ptr [rcx + 0x20]
01ae9a34  413bc1                   cmp eax, r9d
01ae9a37  0f87e3000000             ja 0x1ae9b20
01ae9a3d  488d15bc6551fe           lea rdx, [rip - 0x1ae9a44]
01ae9a44  8b8482309bae01           mov eax, dword ptr [rdx + rax*4 + 0x1ae9b30]
01ae9a4b  4803c2                   add rax, rdx
01ae9a4e  ffe0                     jmp rax
01ae9a50  84db                     test bl, bl
01ae9a52  b803000000               mov eax, 3
01ae9a57  ba0a000000               mov edx, 0xa
01ae9a5c  0f45c2                   cmovne eax, edx
01ae9a5f  894120                   mov dword ptr [rcx + 0x20], eax
01ae9a62  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01ae9a67  488b742438               mov rsi, qword ptr [rsp + 0x38]
01ae9a6c  4883c420                 add rsp, 0x20
01ae9a70  5f                       pop rdi
01ae9a71  c3                       ret
01ae9a72  84db                     test bl, bl
01ae9a74  b804000000               mov eax, 4
01ae9a79  ba09000000               mov edx, 9
01ae9a7e  0f45c2                   cmovne eax, edx
01ae9a81  894120                   mov dword ptr [rcx + 0x20], eax
01ae9a84  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01ae9a89  488b742438               mov rsi, qword ptr [rsp + 0x38]
01ae9a8e  4883c420                 add rsp, 0x20
01ae9a92  5f                       pop rdi
01ae9a93  c3                       ret
01ae9a94  84db                     test bl, bl
01ae9a96  b805000000               mov eax, 5
01ae9a9b  ba0b000000               mov edx, 0xb
01ae9aa0  0f45c2                   cmovne eax, edx
01ae9aa3  894120                   mov dword ptr [rcx + 0x20], eax
01ae9aa6  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01ae9aab  488b742438               mov rsi, qword ptr [rsp + 0x38]
01ae9ab0  4883c420                 add rsp, 0x20
01ae9ab4  5f                       pop rdi
01ae9ab5  c3                       ret
01ae9ab6  c6475000                 mov byte ptr [rdi + 0x50], 0
01ae9aba  8b4120                   mov eax, dword ptr [rcx + 0x20]
01ae9abd  83c0fd                   add eax, -3
01ae9ac0  413bc1                   cmp eax, r9d
01ae9ac3  775b                     ja 0x1ae9b20
01ae9ac5  4898                     cdqe
01ae9ac7  488d15326551fe           lea rdx, [rip - 0x1ae9ace]
01ae9ace  8b8482549bae01           mov eax, dword ptr [rdx + rax*4 + 0x1ae9b54]
01ae9ad5  4803c2                   add rax, rdx
01ae9ad8  ffe0                     jmp rax
01ae9ada  f6db                     neg bl
01ae9adc  1bc0                     sbb eax, eax
01ae9ade  83e006                   and eax, 6
01ae9ae1  894120                   mov dword ptr [rcx + 0x20], eax
01ae9ae4  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01ae9ae9  488b742438               mov rsi, qword ptr [rsp + 0x38]
01ae9aee  4883c420                 add rsp, 0x20
01ae9af2  5f                       pop rdi
01ae9af3  c3                       ret
01ae9af4  84db                     test bl, bl
01ae9af6  b801000000               mov eax, 1
01ae9afb  410f45c0                 cmovne eax, r8d
01ae9aff  894120                   mov dword ptr [rcx + 0x20], eax
01ae9b02  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01ae9b07  488b742438               mov rsi, qword ptr [rsp + 0x38]
01ae9b0c  4883c420                 add rsp, 0x20
01ae9b10  5f                       pop rdi
01ae9b11  c3                       ret
01ae9b12  84db                     test bl, bl
01ae9b14  b802000000               mov eax, 2
01ae9b19  410f45c1                 cmovne eax, r9d
01ae9b1d  894120                   mov dword ptr [rcx + 0x20], eax
01ae9b20  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
01ae9b25  488b742438               mov rsi, qword ptr [rsp + 0x38]
01ae9b2a  4883c420                 add rsp, 0x20
01ae9b2e  5f                       pop rdi
01ae9b2f  c3                       ret
01ae9b30  50                       push rax
