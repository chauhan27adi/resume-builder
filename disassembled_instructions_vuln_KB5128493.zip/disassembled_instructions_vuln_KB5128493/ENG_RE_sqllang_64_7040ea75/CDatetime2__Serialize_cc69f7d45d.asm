; CDatetime2::Serialize
; sqllang.dll, primary RVA 0x5f9080, 312 bytes in 1 chunk(s)

; chunk at RVA 0x5f9080 (312 bytes)
005f9080  48895c2410               mov qword ptr [rsp + 0x10], rbx
005f9085  4889742418               mov qword ptr [rsp + 0x18], rsi
005f908a  57                       push rdi
005f908b  4883ec30                 sub rsp, 0x30
005f908f  33c0                     xor eax, eax
005f9091  c702032a0000             mov dword ptr [rdx], 0x2a03
005f9097  894218                   mov dword ptr [rdx + 0x18], eax
005f909a  4c8d055f6fa0ff           lea r8, [rip - 0x5f90a1]
005f90a1  48894208                 mov qword ptr [rdx + 8], rax
005f90a5  488bf2                   mov rsi, rdx
005f90a8  48894210                 mov qword ptr [rdx + 0x10], rax
005f90ac  8b4108                   mov eax, dword ptr [rcx + 8]
005f90af  488b5110                 mov rdx, qword ptr [rcx + 0x10]
005f90b3  89442440                 mov dword ptr [rsp + 0x40], eax
005f90b7  0fb64118                 movzx eax, byte ptr [rcx + 0x18]
005f90bb  4889542420               mov qword ptr [rsp + 0x20], rdx
005f90c0  410fb6bc80009b2e02       movzx edi, byte ptr [r8 + rax*4 + 0x22e9b00]
005f90c9  8d4703                   lea eax, [rdi + 3]
005f90cc  88461b                   mov byte ptr [rsi + 0x1b], al
005f90cf  8d47fd                   lea eax, [rdi - 3]
005f90d2  83f807                   cmp eax, 7
005f90d5  0f8784000000             ja 0x5f915f
005f90db  4898                     cdqe
005f90dd  418b8c8098915f00         mov ecx, dword ptr [r8 + rax*4 + 0x5f9198]
005f90e5  4903c8                   add rcx, r8
005f90e8  ffe1                     jmp rcx
005f90ea  0fb6442422               movzx eax, byte ptr [rsp + 0x22]
005f90ef  66895608                 mov word ptr [rsi + 8], dx
005f90f3  88460a                   mov byte ptr [rsi + 0xa], al
005f90f6  eb78                     jmp 0x5f9170
005f90f8  895608                   mov dword ptr [rsi + 8], edx
005f90fb  eb73                     jmp 0x5f9170
005f90fd  0fb6442424               movzx eax, byte ptr [rsp + 0x24]
005f9102  895608                   mov dword ptr [rsi + 8], edx
005f9105  88460c                   mov byte ptr [rsi + 0xc], al
005f9108  eb66                     jmp 0x5f9170
005f910a  0fb7442424               movzx eax, word ptr [rsp + 0x24]
005f910f  895608                   mov dword ptr [rsi + 8], edx
005f9112  6689460c                 mov word ptr [rsi + 0xc], ax
005f9116  eb58                     jmp 0x5f9170
005f9118  0fb7442424               movzx eax, word ptr [rsp + 0x24]
005f911d  895608                   mov dword ptr [rsi + 8], edx
005f9120  6689460c                 mov word ptr [rsi + 0xc], ax
005f9124  0fb6442426               movzx eax, byte ptr [rsp + 0x26]
005f9129  88460e                   mov byte ptr [rsi + 0xe], al
005f912c  eb42                     jmp 0x5f9170
005f912e  48895608                 mov qword ptr [rsi + 8], rdx
005f9132  eb3c                     jmp 0x5f9170
005f9134  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
005f913a  0fb6442428               movzx eax, byte ptr [rsp + 0x28]
005f913f  f20f114608               movsd qword ptr [rsi + 8], xmm0
005f9144  884610                   mov byte ptr [rsi + 0x10], al
005f9147  eb27                     jmp 0x5f9170
005f9149  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
005f914f  0fb7442428               movzx eax, word ptr [rsp + 0x28]
005f9154  f20f114608               movsd qword ptr [rsi + 8], xmm0
005f9159  66894610                 mov word ptr [rsi + 0x10], ax
005f915d  eb11                     jmp 0x5f9170
005f915f  4c8bc7                   mov r8, rdi
005f9162  488d542420               lea rdx, [rsp + 0x20]
005f9167  488d4e08                 lea rcx, [rsi + 8]
005f916b  e8509ea0ff               call 0x2fc0
005f9170  0fb7442440               movzx eax, word ptr [rsp + 0x40]
005f9175  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
005f917a  6689443708               mov word ptr [rdi + rsi + 8], ax
005f917f  0fb6442442               movzx eax, byte ptr [rsp + 0x42]
005f9184  8844370a                 mov byte ptr [rdi + rsi + 0xa], al
005f9188  c60600                   mov byte ptr [rsi], 0
005f918b  488b742450               mov rsi, qword ptr [rsp + 0x50]
005f9190  4883c430                 add rsp, 0x30
005f9194  5f                       pop rdi
005f9195  c3                       ret
005f9196  90                       nop
005f9197  90                       nop
