; CDecompressBatchLoader<Level2WithPidBatch,CLevel2WithPidDecompressor,CSeekPruneRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x9759b0, 1416 bytes in 1 chunk(s)

; chunk at RVA 0x9759b0 (1416 bytes)
009759b0  488bc4                   mov rax, rsp
009759b3  4c894820                 mov qword ptr [rax + 0x20], r9
009759b7  895010                   mov dword ptr [rax + 0x10], edx
009759ba  55                       push rbp
009759bb  56                       push rsi
009759bc  57                       push rdi
009759bd  4154                     push r12
009759bf  4155                     push r13
009759c1  4156                     push r14
009759c3  4157                     push r15
009759c5  488d68a1                 lea rbp, [rax - 0x5f]
009759c9  4881ece0000000           sub rsp, 0xe0
009759d0  48c74517feffffff         mov qword ptr [rbp + 0x17], 0xfffffffffffffffe
009759d8  48895818                 mov qword ptr [rax + 0x18], rbx
009759dc  4d8be8                   mov r13, r8
009759df  8bfa                     mov edi, edx
009759e1  488bf1                   mov rsi, rcx
009759e4  83792002                 cmp dword ptr [rcx + 0x20], 2
009759e8  7507                     jne 0x9759f1
009759ea  33c0                     xor eax, eax
009759ec  e9cc040000               jmp 0x975ebd
009759f1  4533ff                   xor r15d, r15d
009759f4  44897da7                 mov dword ptr [rbp - 0x59], r15d
009759f8  4c897daf                 mov qword ptr [rbp - 0x51], r15
009759fc  44887db7                 mov byte ptr [rbp - 0x49], r15b
00975a00  0f57c0                   xorps xmm0, xmm0
00975a03  660f7f45c7               movdqa xmmword ptr [rbp - 0x39], xmm0
00975a08  0f57c9                   xorps xmm1, xmm1
00975a0b  660f7f4dd7               movdqa xmmword ptr [rbp - 0x29], xmm1
00975a10  660f7f45e7               movdqa xmmword ptr [rbp - 0x19], xmm0
00975a15  4c897df7                 mov qword ptr [rbp - 9], r15
00975a19  c745ff01000000           mov dword ptr [rbp - 1], 1
00975a20  4c897d07                 mov qword ptr [rbp + 7], r15
00975a24  44897c2420               mov dword ptr [rsp + 0x20], r15d
00975a29  32c9                     xor cl, cl
00975a2b  884d67                   mov byte ptr [rbp + 0x67], cl
00975a2e  4c8d25cba568ff           lea r12, [rip - 0x975a35]
00975a35  41c6451000               mov byte ptr [r13 + 0x10], 0
00975a3a  80be582e000000           cmp byte ptr [rsi + 0x2e58], 0
00975a41  0f8495000000             je 0x975adc
00975a47  c686582e000000           mov byte ptr [rsi + 0x2e58], 0
00975a4e  488b9e502e0000           mov rbx, qword ptr [rsi + 0x2e50]
00975a55  4c8bc3                   mov r8, rbx
00975a58  33d2                     xor edx, edx
00975a5a  498bcd                   mov rcx, r13
00975a5d  e8ee74ffff               call 0x96cf50
00975a62  488b5360                 mov rdx, qword ptr [rbx + 0x60]
00975a66  418b4d00                 mov ecx, dword ptr [r13]
00975a6a  ffc9                     dec ecx
00975a6c  4803c9                   add rcx, rcx
00975a6f  498b4560                 mov rax, qword ptr [r13 + 0x60]
00975a73  0f1002                   movups xmm0, xmmword ptr [rdx]
00975a76  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
00975a7a  488b86502e0000           mov rax, qword ptr [rsi + 0x2e50]
00975a81  ff08                     dec dword ptr [rax]
00975a83  44897da7                 mov dword ptr [rbp - 0x59], r15d
00975a87  498b4508                 mov rax, qword ptr [r13 + 8]
00975a8b  488945af                 mov qword ptr [rbp - 0x51], rax
00975a8f  418b5500                 mov edx, dword ptr [r13]
00975a93  498b4520                 mov rax, qword ptr [r13 + 0x20]
00975a97  488d0cd0                 lea rcx, [rax + rdx*8]
00975a9b  48894dc7                 mov qword ptr [rbp - 0x39], rcx
00975a9f  498b4528                 mov rax, qword ptr [r13 + 0x28]
00975aa3  488d0c90                 lea rcx, [rax + rdx*4]
00975aa7  48894dcf                 mov qword ptr [rbp - 0x31], rcx
00975aab  498b4530                 mov rax, qword ptr [r13 + 0x30]
00975aaf  488d0c90                 lea rcx, [rax + rdx*4]
00975ab3  48894dd7                 mov qword ptr [rbp - 0x29], rcx
00975ab7  b801000000               mov eax, 1
00975abc  2bc2                     sub eax, edx
00975abe  03f8                     add edi, eax
00975ac0  897d6f                   mov dword ptr [rbp + 0x6f], edi
00975ac3  4c8d75a7                 lea r14, [rbp - 0x59]
00975ac7  c686582e000000           mov byte ptr [rsi + 0x2e58], 0
00975ace  c744242001000000         mov dword ptr [rsp + 0x20], 1
00975ad6  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00975ada  eb03                     jmp 0x975adf
00975adc  4d8bf5                   mov r14, r13
00975adf  837e2000                 cmp dword ptr [rsi + 0x20], 0
00975ae3  7558                     jne 0x975b3d
00975ae5  4c897c2428               mov qword ptr [rsp + 0x28], r15
00975aea  44897c2430               mov dword ptr [rsp + 0x30], r15d
00975aef  4c897c2438               mov qword ptr [rsp + 0x38], r15
00975af4  44897d87                 mov dword ptr [rbp - 0x79], r15d
00975af8  4c897d8f                 mov qword ptr [rbp - 0x71], r15
00975afc  44897d97                 mov dword ptr [rbp - 0x69], r15d
00975b00  6644897d9b               mov word ptr [rbp - 0x65], r15w
00975b05  488d4e28                 lea rcx, [rsi + 0x28]
00975b09  488b01                   mov rax, qword ptr [rcx]
00975b0c  4d8bc1                   mov r8, r9
00975b0f  488d542428               lea rdx, [rsp + 0x28]
00975b14  ff10                     call qword ptr [rax]
00975b16  c6456701                 mov byte ptr [rbp + 0x67], 1
00975b1a  3dc60e0400               cmp eax, 0x40ec6
00975b1f  0f8474030000             je 0x975e99
00975b25  488d8e48090000           lea rcx, [rsi + 0x948]
00975b2c  488d542428               lea rdx, [rsp + 0x28]
00975b31  e87a6cf5ff               call 0x8cc7b0
00975b36  c7462001000000           mov dword ptr [rsi + 0x20], 1
00975b3d  488b4630                 mov rax, qword ptr [rsi + 0x30]
00975b41  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00975b48  4d894608                 mov qword ptr [r14 + 8], r8
00975b4c  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00975b53  488b5630                 mov rdx, qword ptr [rsi + 0x30]
00975b57  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00975b5a  83e007                   and eax, 7
00975b5d  83f805                   cmp eax, 5
00975b60  773c                     ja 0x975b9e
00975b62  4898                     cdqe
00975b64  418b8c84d85e9700         mov ecx, dword ptr [r12 + rax*4 + 0x975ed8]
00975b6c  4903cc                   add rcx, r12
00975b6f  ffe1                     jmp rcx
00975b71  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975b75  0f95c3                   setne bl
00975b78  eb26                     jmp 0x975ba0
00975b7a  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975b7e  0f9dc3                   setge bl
00975b81  eb1d                     jmp 0x975ba0
00975b83  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975b87  0f9ec3                   setle bl
00975b8a  eb14                     jmp 0x975ba0
00975b8c  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975b90  0f9fc3                   setg bl
00975b93  eb0b                     jmp 0x975ba0
00975b95  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975b99  0f9cc3                   setl bl
00975b9c  eb02                     jmp 0x975ba0
00975b9e  32db                     xor bl, bl
00975ba0  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00975ba7  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00975baa  83e007                   and eax, 7
00975bad  83f805                   cmp eax, 5
00975bb0  7741                     ja 0x975bf3
00975bb2  4898                     cdqe
00975bb4  418b8c84f05e9700         mov ecx, dword ptr [r12 + rax*4 + 0x975ef0]
00975bbc  4903cc                   add rcx, r12
00975bbf  ffe1                     jmp rcx
00975bc1  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975bc5  410f95c4                 setne r12b
00975bc9  eb2b                     jmp 0x975bf6
00975bcb  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975bcf  410f9dc4                 setge r12b
00975bd3  eb21                     jmp 0x975bf6
00975bd5  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975bd9  410f9ec4                 setle r12b
00975bdd  eb17                     jmp 0x975bf6
00975bdf  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975be3  410f9fc4                 setg r12b
00975be7  eb0d                     jmp 0x975bf6
00975be9  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975bed  410f9cc4                 setl r12b
00975bf1  eb03                     jmp 0x975bf6
00975bf3  4532e4                   xor r12b, r12b
00975bf6  4889751f                 mov qword ptr [rbp + 0x1f], rsi
00975bfa  0f31                     rdtsc
00975bfc  48c1e220                 shl rdx, 0x20
00975c00  480bc2                   or rax, rdx
00975c03  48894608                 mov qword ptr [rsi + 8], rax
00975c07  488d8e48090000           lea rcx, [rsi + 0x948]
00975c0e  4d8bc6                   mov r8, r14
00975c11  8bd7                     mov edx, edi
00975c13  e83889ffff               call 0x96e550
00975c18  84c0                     test al, al
00975c1a  7504                     jne 0x975c20
00975c1c  44897e20                 mov dword ptr [rsi + 0x20], r15d
00975c20  418b06                   mov eax, dword ptr [r14]
00975c23  48014610                 add qword ptr [rsi + 0x10], rax
00975c27  0f31                     rdtsc
00975c29  48c1e220                 shl rdx, 0x20
00975c2d  480bc2                   or rax, rdx
00975c30  482b4608                 sub rax, qword ptr [rsi + 8]
00975c34  480106                   add qword ptr [rsi], rax
00975c37  ff4618                   inc dword ptr [rsi + 0x18]
00975c3a  418b06                   mov eax, dword ptr [r14]
00975c3d  448bc0                   mov r8d, eax
00975c40  85c0                     test eax, eax
00975c42  0f84cc010000             je 0x975e14
00975c48  84db                     test bl, bl
00975c4a  7509                     jne 0x975c55
00975c4c  4584e4                   test r12b, r12b
00975c4f  0f84bf010000             je 0x975e14
00975c55  448bc8                   mov r9d, eax
00975c58  84db                     test bl, bl
00975c5a  0f8480000000             je 0x975ce0
00975c60  458bd7                   mov r10d, r15d
00975c63  4c8b5e30                 mov r11, qword ptr [rsi + 0x30]
00975c67  85c0                     test eax, eax
00975c69  746c                     je 0x975cd7
00975c6b  498b5e20                 mov rbx, qword ptr [r14 + 0x20]
00975c6f  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00975c73  4183e007                 and r8d, 7
00975c77  488d3d82a368ff           lea rdi, [rip - 0x975c7e]
00975c7e  6690                     nop
00975c80  418bca                   mov ecx, r10d
00975c83  4c8b0ccb                 mov r9, qword ptr [rbx + rcx*8]
00975c87  4183f805                 cmp r8d, 5
00975c8b  0f87ae000000             ja 0x975d3f
00975c91  4963c8                   movsxd rcx, r8d
00975c94  8b948f085f9700           mov edx, dword ptr [rdi + rcx*4 + 0x975f08]
00975c9b  4803d7                   add rdx, rdi
00975c9e  ffe2                     jmp rdx
00975ca0  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975ca4  0f94c1                   sete cl
00975ca7  eb22                     jmp 0x975ccb
00975ca9  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975cad  0f9cc1                   setl cl
00975cb0  eb19                     jmp 0x975ccb
00975cb2  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975cb6  0f9fc1                   setg cl
00975cb9  eb10                     jmp 0x975ccb
00975cbb  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975cbf  0f9ec1                   setle cl
00975cc2  eb07                     jmp 0x975ccb
00975cc4  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975cc8  0f9dc1                   setge cl
00975ccb  84c9                     test cl, cl
00975ccd  7570                     jne 0x975d3f
00975ccf  41ffc2                   inc r10d
00975cd2  443bd0                   cmp r10d, eax
00975cd5  72a9                     jb 0x975c80
00975cd7  45893e                   mov dword ptr [r14], r15d
00975cda  418bc7                   mov eax, r15d
00975cdd  458bcf                   mov r9d, r15d
00975ce0  458bc1                   mov r8d, r9d
00975ce3  4584e4                   test r12b, r12b
00975ce6  0f8428010000             je 0x975e14
00975cec  85c0                     test eax, eax
00975cee  0f8420010000             je 0x975e14
00975cf4  4c8b5e30                 mov r11, qword ptr [rsi + 0x30]
00975cf8  498b7e20                 mov rdi, qword ptr [r14 + 0x20]
00975cfc  4c8d25fda268ff           lea r12, [rip - 0x975d03]
00975d03  0f1f4000                 nop dword ptr [rax]
00975d07  660f1f840000000000       nop word ptr [rax + rax]
00975d10  458bd1                   mov r10d, r9d
00975d13  ffc8                     dec eax
00975d15  448bc8                   mov r9d, eax
00975d18  488b1cc7                 mov rbx, qword ptr [rdi + rax*8]
00975d1c  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00975d20  83e107                   and ecx, 7
00975d23  458bc2                   mov r8d, r10d
00975d26  83f905                   cmp ecx, 5
00975d29  0f87e5000000             ja 0x975e14
00975d2f  4863c9                   movsxd rcx, ecx
00975d32  418b948c205f9700         mov edx, dword ptr [r12 + rcx*4 + 0x975f20]
00975d3a  4903d4                   add rdx, r12
00975d3d  ffe2                     jmp rdx
00975d3f  443bd0                   cmp r10d, eax
00975d42  7393                     jae 0x975cd7
00975d44  448bc8                   mov r9d, eax
00975d47  4585d2                   test r10d, r10d
00975d4a  7494                     je 0x975ce0
00975d4c  452bca                   sub r9d, r10d
00975d4f  458bdf                   mov r11d, r15d
00975d52  7478                     je 0x975dcc
00975d54  498bd7                   mov rdx, r15
00975d57  498bdf                   mov rbx, r15
00975d5a  498bff                   mov rdi, r15
00975d5d  0f1f00                   nop dword ptr [rax]
00975d60  438d0413                 lea eax, [r11 + r10]
00975d64  448bc0                   mov r8d, eax
00975d67  498b4e20                 mov rcx, qword ptr [r14 + 0x20]
00975d6b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
00975d6f  4889040f                 mov qword ptr [rdi + rcx], rax
00975d73  498b4e30                 mov rcx, qword ptr [r14 + 0x30]
00975d77  428b0481                 mov eax, dword ptr [rcx + r8*4]
00975d7b  89040b                   mov dword ptr [rbx + rcx], eax
00975d7e  498b4e28                 mov rcx, qword ptr [r14 + 0x28]
00975d82  428b0481                 mov eax, dword ptr [rcx + r8*4]
00975d86  89040b                   mov dword ptr [rbx + rcx], eax
00975d89  4d03c0                   add r8, r8
00975d8c  498b4638                 mov rax, qword ptr [r14 + 0x38]
00975d90  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00975d95  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00975d99  498b4648                 mov rax, qword ptr [r14 + 0x48]
00975d9d  4885c0                   test rax, rax
00975da0  7409                     je 0x975dab
00975da2  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00975da7  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00975dab  498b4660                 mov rax, qword ptr [r14 + 0x60]
00975daf  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00975db4  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00975db8  41ffc3                   inc r11d
00975dbb  4883c708                 add rdi, 8
00975dbf  4883c304                 add rbx, 4
00975dc3  4883c210                 add rdx, 0x10
00975dc7  453bd9                   cmp r11d, r9d
00975dca  7294                     jb 0x975d60
00975dcc  45890e                   mov dword ptr [r14], r9d
00975dcf  418bc1                   mov eax, r9d
00975dd2  e909ffffff               jmp 0x975ce0
00975dd7  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975ddb  0f94c1                   sete cl
00975dde  eb22                     jmp 0x975e02
00975de0  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975de4  0f9cc1                   setl cl
00975de7  eb19                     jmp 0x975e02
00975de9  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975ded  0f9fc1                   setg cl
00975df0  eb10                     jmp 0x975e02
00975df2  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975df6  0f9ec1                   setle cl
00975df9  eb07                     jmp 0x975e02
00975dfb  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975dff  0f9dc1                   setge cl
00975e02  84c9                     test cl, cl
00975e04  750e                     jne 0x975e14
00975e06  418906                   mov dword ptr [r14], eax
00975e09  448bc0                   mov r8d, eax
00975e0c  85c0                     test eax, eax
00975e0e  0f85fcfeffff             jne 0x975d10
00975e14  80be592e000000           cmp byte ptr [rsi + 0x2e59], 0
00975e1b  7463                     je 0x975e80
00975e1d  458b06                   mov r8d, dword ptr [r14]
00975e20  4585c0                   test r8d, r8d
00975e23  745b                     je 0x975e80
00975e25  c686582e000001           mov byte ptr [rsi + 0x2e58], 1
00975e2c  418b1e                   mov ebx, dword ptr [r14]
00975e2f  ffcb                     dec ebx
00975e31  488bbe502e0000           mov rdi, qword ptr [rsi + 0x2e50]
00975e38  4d8bc6                   mov r8, r14
00975e3b  8bd3                     mov edx, ebx
00975e3d  488bcf                   mov rcx, rdi
00975e40  e80b71ffff               call 0x96cf50
00975e45  448bc3                   mov r8d, ebx
00975e48  4d03c0                   add r8, r8
00975e4b  498b5660                 mov rdx, qword ptr [r14 + 0x60]
00975e4f  8b0f                     mov ecx, dword ptr [rdi]
00975e51  ffc9                     dec ecx
00975e53  4803c9                   add rcx, rcx
00975e56  488b4760                 mov rax, qword ptr [rdi + 0x60]
00975e5a  420f1004c2               movups xmm0, xmmword ptr [rdx + r8*8]
00975e5f  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
00975e63  41ff0e                   dec dword ptr [r14]
00975e66  41c6451001               mov byte ptr [r13 + 0x10], 1
00975e6b  488b86502e0000           mov rax, qword ptr [rsi + 0x2e50]
00975e72  488b4820                 mov rcx, qword ptr [rax + 0x20]
00975e76  488b01                   mov rax, qword ptr [rcx]
00975e79  49894518                 mov qword ptr [r13 + 0x18], rax
00975e7d  458b06                   mov r8d, dword ptr [r14]
00975e80  8b442420                 mov eax, dword ptr [rsp + 0x20]
00975e84  4103c0                   add eax, r8d
00975e87  89442420                 mov dword ptr [rsp + 0x20], eax
00975e8b  7521                     jne 0x975eae
00975e8d  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
00975e90  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00975e94  e995fbffff               jmp 0x975a2e
00975e99  c7462002000000           mov dword ptr [rsi + 0x20], 2
00975ea0  41837d0000               cmp dword ptr [r13], 0
00975ea5  410f95c7                 setne r15b
00975ea9  418bc7                   mov eax, r15d
00975eac  eb0f                     jmp 0x975ebd
00975eae  41894500                 mov dword ptr [r13], eax
00975eb2  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00975eb6  f6d9                     neg cl
00975eb8  1bc0                     sbb eax, eax
00975eba  83c002                   add eax, 2
00975ebd  488b9c2430010000         mov rbx, qword ptr [rsp + 0x130]
00975ec5  4881c4e0000000           add rsp, 0xe0
00975ecc  415f                     pop r15
00975ece  415e                     pop r14
00975ed0  415d                     pop r13
00975ed2  415c                     pop r12
00975ed4  5f                       pop rdi
00975ed5  5e                       pop rsi
00975ed6  5d                       pop rbp
00975ed7  c3                       ret
00975ed8  9e                       sahf
00975ed9  5b                       pop rbx
00975eda  97                       xchg edi, eax
00975edb  00715b                   add byte ptr [rcx + 0x5b], dh
00975ede  97                       xchg edi, eax
00975edf  007a5b                   add byte ptr [rdx + 0x5b], bh
00975ee2  97                       xchg edi, eax
00975ee3  008c5b9700835b           add byte ptr [rbx + rbx*2 + 0x5b830097], cl
00975eea  97                       xchg edi, eax
00975eeb  00955b9700f3             add byte ptr [rbp - 0xcff68a5], dl
00975ef1  5b                       pop rbx
00975ef2  97                       xchg edi, eax
00975ef3  00c1                     add cl, al
00975ef5  5b                       pop rbx
00975ef6  97                       xchg edi, eax
00975ef7  00cb                     add bl, cl
00975ef9  5b                       pop rbx
00975efa  97                       xchg edi, eax
00975efb  00df                     add bh, bl
00975efd  5b                       pop rbx
00975efe  97                       xchg edi, eax
00975eff  00d5                     add ch, dl
00975f01  5b                       pop rbx
00975f02  97                       xchg edi, eax
00975f03  00e9                     add cl, ch
00975f05  5b                       pop rbx
00975f06  97                       xchg edi, eax
00975f07  003f                     add byte ptr [rdi], bh
00975f09  5d                       pop rbp
00975f0a  97                       xchg edi, eax
00975f0b  00a05c9700a9             add byte ptr [rax - 0x56ff68a4], ah
00975f11  5c                       pop rsp
00975f12  97                       xchg edi, eax
00975f13  00bb5c9700b2             add byte ptr [rbx - 0x4dff68a4], bh
00975f19  5c                       pop rsp
00975f1a  97                       xchg edi, eax
00975f1b  00c4                     add ah, al
00975f1d  5c                       pop rsp
00975f1e  97                       xchg edi, eax
00975f1f  00145e                   add byte ptr [rsi + rbx*2], dl
00975f22  97                       xchg edi, eax
00975f23  00d7                     add bh, dl
00975f25  5d                       pop rbp
00975f26  97                       xchg edi, eax
00975f27  00e0                     add al, ah
00975f29  5d                       pop rbp
00975f2a  97                       xchg edi, eax
00975f2b  00f2                     add dl, dh
00975f2d  5d                       pop rbp
00975f2e  97                       xchg edi, eax
00975f2f  00e9                     add cl, ch
00975f31  5d                       pop rbp
00975f32  97                       xchg edi, eax
00975f33  00fb                     add bl, bh
00975f35  5d                       pop rbp
00975f36  97                       xchg edi, eax
