; CCursorVisibilityList::PcvrGet
; sqllang.dll, primary RVA 0x44f60, 332 bytes in 1 chunk(s)

; chunk at RVA 0x44f60 (332 bytes)
00044f60  4489442418               mov dword ptr [rsp + 0x18], r8d
00044f65  4889542410               mov qword ptr [rsp + 0x10], rdx
00044f6a  53                       push rbx
00044f6b  55                       push rbp
00044f6c  56                       push rsi
00044f6d  57                       push rdi
00044f6e  4154                     push r12
00044f70  4155                     push r13
00044f72  4156                     push r14
00044f74  4157                     push r15
00044f76  4883ec78                 sub rsp, 0x78
00044f7a  48c7442450feffffff       mov qword ptr [rsp + 0x50], 0xfffffffffffffffe
00044f83  418bf9                   mov edi, r9d
00044f86  418bf0                   mov esi, r8d
00044f89  4c8bf1                   mov r14, rcx
00044f8c  33ed                     xor ebp, ebp
00044f8e  396924                   cmp dword ptr [rcx + 0x24], ebp
00044f91  0f85ac9c5700             jne 0x5bec43
00044f97  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00044fa0  488b05d15fe801           mov rax, qword ptr [rip + 0x1e85fd1]
00044fa7  8b08                     mov ecx, dword ptr [rax]
00044fa9  488b05d05fe801           mov rax, qword ptr [rip + 0x1e85fd0]
00044fb0  8b00                     mov eax, dword ptr [rax]
00044fb2  480304ca                 add rax, qword ptr [rdx + rcx*8]
00044fb6  488b00                   mov rax, qword ptr [rax]
00044fb9  488b4878                 mov rcx, qword ptr [rax + 0x78]
00044fbd  448bb91c010000           mov r15d, dword ptr [rcx + 0x11c]
00044fc4  41ffc7                   inc r15d
00044fc7  488d0572b50102           lea rax, [rip + 0x201b572]
00044fce  4889442458               mov qword ptr [rsp + 0x58], rax
00044fd3  48896c2460               mov qword ptr [rsp + 0x60], rbp
00044fd8  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00044fe1  488b05905fe801           mov rax, qword ptr [rip + 0x1e85f90]
00044fe8  8b08                     mov ecx, dword ptr [rax]
00044fea  488b058f5fe801           mov rax, qword ptr [rip + 0x1e85f8f]
00044ff1  8b00                     mov eax, dword ptr [rax]
00044ff3  480304ca                 add rax, qword ptr [rdx + rcx*8]
00044ff7  488b00                   mov rax, qword ptr [rax]
00044ffa  488b8880000000           mov rcx, qword ptr [rax + 0x80]
00045001  448ba10c020000           mov r12d, dword ptr [rcx + 0x20c]
00045008  4489a424d8000000         mov dword ptr [rsp + 0xd8], r12d
00045010  4c89742460               mov qword ptr [rsp + 0x60], r14
00045015  498bce                   mov rcx, r14
00045018  e81320fcff               call 0x7030
0004501d  498b5e08                 mov rbx, qword ptr [r14 + 8]
00045021  493bde                   cmp rbx, r14
00045024  480f44dd                 cmove rbx, rbp
00045028  85ff                     test edi, edi
0004502a  0f851c9c5700             jne 0x5bec4c
00045030  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00045039  488b05385fe801           mov rax, qword ptr [rip + 0x1e85f38]
00045040  8b08                     mov ecx, dword ptr [rax]
00045042  488b05375fe801           mov rax, qword ptr [rip + 0x1e85f37]
00045049  8b00                     mov eax, dword ptr [rax]
0004504b  480304ca                 add rax, qword ptr [rdx + rcx*8]
0004504f  488b00                   mov rax, qword ptr [rax]
00045052  488b88a0000000           mov rcx, qword ptr [rax + 0xa0]
00045059  f6412d02                 test byte ptr [rcx + 0x2d], 2
0004505d  0f85fb9b5700             jne 0x5bec5e
00045063  ff15676be801             call qword ptr [rip + 0x1e86b67]
00045069  488bc8                   mov rcx, rax
0004506c  48898c24c0000000         mov qword ptr [rsp + 0xc0], rcx
00045074  4885db                   test rbx, rbx
00045077  0f85293e0000             jne 0x48ea6
0004507d  488d05bcb40102           lea rax, [rip + 0x201b4bc]
00045084  4889442458               mov qword ptr [rsp + 0x58], rax
00045089  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
0004508e  4885c9                   test rcx, rcx
00045091  7405                     je 0x45098
00045093  e8e81ffcff               call 0x7080
00045098  488bc5                   mov rax, rbp
0004509b  4883c478                 add rsp, 0x78
0004509f  415f                     pop r15
000450a1  415e                     pop r14
000450a3  415d                     pop r13
000450a5  415c                     pop r12
000450a7  5f                       pop rdi
000450a8  5e                       pop rsi
000450a9  5d                       pop rbp
000450aa  5b                       pop rbx
000450ab  c3                       ret
