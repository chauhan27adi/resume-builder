; attention_handler
; sqllang.dll, primary RVA 0x352820, 221 bytes in 1 chunk(s)

; chunk at RVA 0x352820 (221 bytes)
00352820  4053                     push rbx
00352822  4883ec20                 sub rsp, 0x20
00352826  488b0563747802           mov rax, qword ptr [rip + 0x2787463]
0035282d  488bd9                   mov rbx, rcx
00352830  f680f801000001           test byte ptr [rax + 0x1f8], 1
00352837  0f853b5c8200             jne 0xb78478
0035283d  654c8b0c2558000000       mov r9, qword ptr gs:[0x58]
00352846  488b052b87b701           mov rax, qword ptr [rip + 0x1b7872b]
0035284d  448b00                   mov r8d, dword ptr [rax]
00352850  488b052987b701           mov rax, qword ptr [rip + 0x1b78729]
00352857  8b10                     mov edx, dword ptr [rax]
00352859  4b8b04c1                 mov rax, qword ptr [r9 + r8*8]
0035285d  488b0410                 mov rax, qword ptr [rax + rdx]
00352861  4885c0                   test rax, rax
00352864  0f85c55b8200             jne 0xb7842f
0035286a  488b051f747802           mov rax, qword ptr [rip + 0x278741f]
00352871  f680fa01000040           test byte ptr [rax + 0x1fa], 0x40
00352878  0f85fa5b8200             jne 0xb78478
0035287e  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00352887  488b05ea86b701           mov rax, qword ptr [rip + 0x1b786ea]
0035288e  8b10                     mov edx, dword ptr [rax]
00352890  488b05e986b701           mov rax, qword ptr [rip + 0x1b786e9]
00352897  8b08                     mov ecx, dword ptr [rax]
00352899  498b04d0                 mov rax, qword ptr [r8 + rdx*8]
0035289d  488b0401                 mov rax, qword ptr [rcx + rax]
003528a1  4885c0                   test rax, rax
003528a4  0f85ab5b8200             jne 0xb78455
003528aa  488b05377db701           mov rax, qword ptr [rip + 0x1b77d37]
003528b1  833800                   cmp dword ptr [rax], 0
003528b4  0f84d85b8200             je 0xb78492
003528ba  488d4c2430               lea rcx, [rsp + 0x30]
003528bf  ff15636cb701             call qword ptr [rip + 0x1b76c63]
003528c5  488b442430               mov rax, qword ptr [rsp + 0x30]
003528ca  eb01                     jmp 0x3528cd
003528cc  cc                       int3
003528cd  4533c0                   xor r8d, r8d
003528d0  488983a0020000           mov qword ptr [rbx + 0x2a0], rax
003528d7  488bcb                   mov rcx, rbx
003528da  418d5012                 lea edx, [r8 + 0x12]
003528de  e8bda3cbff               call 0xcca0
003528e3  488b8bc8010000           mov rcx, qword ptr [rbx + 0x1c8]
003528ea  ba01000000               mov edx, 1
003528ef  488b01                   mov rax, qword ptr [rcx]
003528f2  ff5030                   call qword ptr [rax + 0x30]
003528f5  33c0                     xor eax, eax
003528f7  4883c420                 add rsp, 0x20
003528fb  5b                       pop rbx
003528fc  c3                       ret
