; CEsCompFullCompile::Scan2Intrinsic
; sqllang.dll, primary RVA 0x1309a0, 1444 bytes in 1 chunk(s)

; chunk at RVA 0x1309a0 (1444 bytes)
001309a0  44894c2420               mov dword ptr [rsp + 0x20], r9d
001309a5  4c89442418               mov qword ptr [rsp + 0x18], r8
001309aa  55                       push rbp
001309ab  56                       push rsi
001309ac  57                       push rdi
001309ad  4154                     push r12
001309af  4155                     push r13
001309b1  4156                     push r14
001309b3  4157                     push r15
001309b5  488dac24e0ebffff         lea rbp, [rsp - 0x1420]
001309bd  b820150000               mov eax, 0x1520
001309c2  e8290bedff               call 0x14f0
001309c7  482be0                   sub rsp, rax
001309ca  48c745d0feffffff         mov qword ptr [rbp - 0x30], 0xfffffffffffffffe
001309d2  48899c2460150000         mov qword ptr [rsp + 0x1560], rbx
001309da  4d8bf0                   mov r14, r8
001309dd  4c8be2                   mov r12, rdx
001309e0  488bd9                   mov rbx, rcx
001309e3  448b6a18                 mov r13d, dword ptr [rdx + 0x18]
001309e7  654c8b142558000000       mov r10, qword ptr gs:[0x58]
001309f0  488b0581a5d901           mov rax, qword ptr [rip + 0x1d9a581]
001309f7  8b08                     mov ecx, dword ptr [rax]
001309f9  488b0580a5d901           mov rax, qword ptr [rip + 0x1d9a580]
00130a00  8b00                     mov eax, dword ptr [rax]
00130a02  490304ca                 add rax, qword ptr [r10 + rcx*8]
00130a06  488b00                   mov rax, qword ptr [rax]
00130a09  80b89900000000           cmp byte ptr [rax + 0x99], 0
00130a10  7416                     je 0x130a28
00130a12  e849f1edff               call 0xfb60
00130a17  488bb8a0000000           mov rdi, qword ptr [rax + 0xa0]
00130a1e  837f3000                 cmp dword ptr [rdi + 0x30], 0
00130a22  0f84cd347500             je 0x883ef5
00130a28  498b4c2410               mov rcx, qword ptr [r12 + 0x10]
00130a2d  488b01                   mov rax, qword ptr [rcx]
00130a30  ff5018                   call qword ptr [rax + 0x18]
00130a33  4d8b4c2410               mov r9, qword ptr [r12 + 0x10]
00130a38  4c894c2450               mov qword ptr [rsp + 0x50], r9
00130a3d  83f858                   cmp eax, 0x58
00130a40  0f85c7347500             jne 0x883f0d
00130a46  498b5140                 mov rdx, qword ptr [r9 + 0x40]
00130a4a  498d4948                 lea rcx, [r9 + 0x48]
00130a4e  48894c2468               mov qword ptr [rsp + 0x68], rcx
00130a53  eb01                     jmp 0x130a56
00130a55  cc                       int3
00130a56  4889542458               mov qword ptr [rsp + 0x58], rdx
00130a5b  498d7118                 lea rsi, [r9 + 0x18]
00130a5f  0fb606                   movzx eax, byte ptr [rsi]
00130a62  888568140000             mov byte ptr [rbp + 0x1468], al
00130a68  4c8d3dd1659b02           lea r15, [rip + 0x29b65d1]
00130a6f  4c63420c                 movsxd r8, dword ptr [rdx + 0xc]
00130a73  4489442448               mov dword ptr [rsp + 0x48], r8d
00130a78  4c8d1581f5ecff           lea r10, [rip - 0x130a7f]
00130a7f  33ff                     xor edi, edi
00130a81  48897c2460               mov qword ptr [rsp + 0x60], rdi
00130a86  4338bc10804cb402         cmp byte ptr [r8 + r10 + 0x2b44c80], dil
00130a8e  0f858c347500             jne 0x883f20
00130a94  4181f817010000           cmp r8d, 0x117
00130a9b  0f8f735a0f00             jg 0x226514
00130aa1  0f84fa4a7500             je 0x8855a1
00130aa7  4183c0f1                 add r8d, -0xf
00130aab  4181f8ea000000           cmp r8d, 0xea
00130ab2  0f87e7570f00             ja 0x22629f
00130ab8  4963c0                   movsxd rax, r8d
00130abb  410fb68402a80c1300       movzx eax, byte ptr [r10 + rax + 0x130ca8]
00130ac4  418b8c82d80b1300         mov ecx, dword ptr [r10 + rax*4 + 0x130bd8]
00130acc  4903ca                   add rcx, r10
00130acf  ffe1                     jmp rcx
00130ad1  cc                       int3
00130ad2  498b542420               mov rdx, qword ptr [r12 + 0x20]
00130ad7  4d8bce                   mov r9, r14
00130ada  4d8bc4                   mov r8, r12
00130add  488b12                   mov rdx, qword ptr [rdx]
00130ae0  488bcb                   mov rcx, rbx
00130ae3  e888d7f3ff               call 0x6e270
00130ae8  498b442420               mov rax, qword ptr [r12 + 0x20]
00130aed  488b08                   mov rcx, qword ptr [rax]
00130af0  488b4910                 mov rcx, qword ptr [rcx + 0x10]
00130af4  4883c118                 add rcx, 0x18
00130af8  e813ed2500               call 0x38f810
00130afd  448b6b0c                 mov r13d, dword ptr [rbx + 0xc]
00130b01  84c0                     test al, al
00130b03  0f8522367500             jne 0x88412b
00130b09  458d4501                 lea r8d, [r13 + 1]
00130b0d  4489430c                 mov dword ptr [rbx + 0xc], r8d
00130b11  be01000000               mov esi, 1
00130b16  89742420                 mov dword ptr [rsp + 0x20], esi
00130b1a  41b93c040000             mov r9d, 0x43c
00130b20  498bd6                   mov rdx, r14
00130b23  488bcb                   mov rcx, rbx
00130b26  e8c5c8f3ff               call 0x6d3f0
00130b2b  ff430c                   inc dword ptr [rbx + 0xc]
00130b2e  498b542420               mov rdx, qword ptr [r12 + 0x20]
00130b33  4d8bce                   mov r9, r14
00130b36  4d8bc4                   mov r8, r12
00130b39  488b5208                 mov rdx, qword ptr [rdx + 8]
00130b3d  488bcb                   mov rcx, rbx
00130b40  e82bd7f3ff               call 0x6e270
00130b45  8b7b0c                   mov edi, dword ptr [rbx + 0xc]
00130b48  33c0                     xor eax, eax
00130b4a  89442420                 mov dword ptr [rsp + 0x20], eax
00130b4e  41b94d040000             mov r9d, 0x44d
00130b54  458bc5                   mov r8d, r13d
00130b57  498bd6                   mov rdx, r14
00130b5a  488bcb                   mov rcx, rbx
00130b5d  e88ec8f3ff               call 0x6d3f0
00130b62  4889442440               mov qword ptr [rsp + 0x40], rax
00130b67  ba03000000               mov edx, 3
00130b6c  89500c                   mov dword ptr [rax + 0xc], edx
00130b6f  488b442440               mov rax, qword ptr [rsp + 0x40]
00130b74  897810                   mov dword ptr [rax + 0x10], edi
00130b77  41897650                 mov dword ptr [r14 + 0x50], esi
00130b7b  eb01                     jmp 0x130b7e
00130b7d  cc                       int3
00130b7e  448b6c2448               mov r13d, dword ptr [rsp + 0x48]
00130b83  488b742450               mov rsi, qword ptr [rsp + 0x50]
00130b88  4c8b742458               mov r14, qword ptr [rsp + 0x58]
00130b8d  498bce                   mov rcx, r14
00130b90  e83bfdffff               call 0x1308d0
00130b95  84c0                     test al, al
00130b97  0f85899f0f00             jne 0x22ab26
00130b9d  498bce                   mov rcx, r14
00130ba0  e81bfdffff               call 0x1308c0
00130ba5  84c0                     test al, al
00130ba7  0f8512710900             jne 0x1c7cbf
00130bad  498bce                   mov rcx, r14
00130bb0  e82bfdffff               call 0x1308e0
00130bb5  84c0                     test al, al
00130bb7  0f85e35a0f00             jne 0x2266a0
00130bbd  488b9c2460150000         mov rbx, qword ptr [rsp + 0x1560]
00130bc5  4881c420150000           add rsp, 0x1520
00130bcc  415f                     pop r15
00130bce  415e                     pop r14
00130bd0  415d                     pop r13
00130bd2  415c                     pop r12
00130bd4  5f                       pop rdi
00130bd5  5e                       pop rsi
00130bd6  5d                       pop rbp
00130bd7  c3                       ret
00130bd8  95                       xchg ebp, eax
00130bd9  478800                   mov byte ptr [r8], r8b
00130bdc  5d                       pop rbp
00130bdd  428800                   mov byte ptr [rax], al
00130be0  92                       xchg edx, eax
00130be1  428800                   mov byte ptr [rax], al
00130be4  0448                     add al, 0x48
00130be6  8800                     mov byte ptr [rax], al
