; CDeltaInternalQueryExecutor::GetQuery
; sqllang.dll, primary RVA 0x1ae6b30, 1996 bytes in 1 chunk(s)

; chunk at RVA 0x1ae6b30 (1996 bytes)
01ae6b30  4055                     push rbp
01ae6b32  53                       push rbx
01ae6b33  56                       push rsi
01ae6b34  57                       push rdi
01ae6b35  4154                     push r12
01ae6b37  4155                     push r13
01ae6b39  4156                     push r14
01ae6b3b  4157                     push r15
01ae6b3d  488d6c24e1               lea rbp, [rsp - 0x1f]
01ae6b42  4881eca8000000           sub rsp, 0xa8
01ae6b49  48c745fffeffffff         mov qword ptr [rbp - 1], 0xfffffffffffffffe
01ae6b51  4c8be1                   mov r12, rcx
01ae6b54  4533c9                   xor r9d, r9d
01ae6b57  44894d6f                 mov dword ptr [rbp + 0x6f], r9d
01ae6b5b  488b052e31ff00           mov rax, qword ptr [rip + 0xff312e]
01ae6b62  44380d10030001           cmp byte ptr [rip + 0x1000310], r9b
01ae6b69  740d                     je 0x1ae6b78
01ae6b6b  f680df06000002           test byte ptr [rax + 0x6df], 2
01ae6b72  7504                     jne 0x1ae6b78
01ae6b74  b201                     mov dl, 1
01ae6b76  eb02                     jmp 0x1ae6b7a
01ae6b78  32d2                     xor dl, dl
01ae6b7a  885567                   mov byte ptr [rbp + 0x67], dl
01ae6b7d  44380df9020001           cmp byte ptr [rip + 0x10002f9], r9b
01ae6b84  410f95c7                 setne r15b
01ae6b88  44380da0020001           cmp byte ptr [rip + 0x10002a0], r9b
01ae6b8f  750d                     jne 0x1ae6b9e
01ae6b91  443888e9040000           cmp byte ptr [rax + 0x4e9], r9b
01ae6b98  7c04                     jl 0x1ae6b9e
01ae6b9a  32c0                     xor al, al
01ae6b9c  eb02                     jmp 0x1ae6ba0
01ae6b9e  b001                     mov al, 1
01ae6ba0  498bf1                   mov rsi, r9
01ae6ba3  4c894d7f                 mov qword ptr [rbp + 0x7f], r9
01ae6ba7  4c894def                 mov qword ptr [rbp - 0x11], r9
01ae6bab  4d8bf1                   mov r14, r9
01ae6bae  4c894dcf                 mov qword ptr [rbp - 0x31], r9
01ae6bb2  4c894de7                 mov qword ptr [rbp - 0x19], r9
01ae6bb6  498bf9                   mov rdi, r9
01ae6bb9  4c894df7                 mov qword ptr [rbp - 9], r9
01ae6bbd  4d8be9                   mov r13, r9
01ae6bc0  4c894d07                 mov qword ptr [rbp + 7], r9
01ae6bc4  4c8b81a0000000           mov r8, qword ptr [rcx + 0xa0]
01ae6bcb  418b4820                 mov ecx, dword ptr [r8 + 0x20]
01ae6bcf  83f90b                   cmp ecx, 0xb
01ae6bd2  0f87d3000000             ja 0x1ae6cab
01ae6bd8  41b96d0d0000             mov r9d, 0xd6d
01ae6bde  410fa3c9                 bt r9d, ecx
01ae6be2  0f83c0000000             jae 0x1ae6ca8
01ae6be8  84d2                     test dl, dl
01ae6bea  7409                     je 0x1ae6bf5
01ae6bec  84c0                     test al, al
01ae6bee  bb01000000               mov ebx, 1
01ae6bf3  7405                     je 0x1ae6bfa
01ae6bf5  bb02000000               mov ebx, 2
01ae6bfa  895d6f                   mov dword ptr [rbp + 0x6f], ebx
01ae6bfd  c644242800               mov byte ptr [rsp + 0x28], 0
01ae6c02  488d45ef                 lea rax, [rbp - 0x11]
01ae6c06  4889442420               mov qword ptr [rsp + 0x20], rax
01ae6c0b  4c8d4d7f                 lea r9, [rbp + 0x7f]
01ae6c0f  4d8b4010                 mov r8, qword ptr [r8 + 0x10]
01ae6c13  8bd3                     mov edx, ebx
01ae6c15  498bcc                   mov rcx, r12
01ae6c18  e8f3060000               call 0x1ae7310
01ae6c1d  85c0                     test eax, eax
01ae6c1f  7927                     jns 0x1ae6c48
01ae6c21  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae6c2a  41b976000000             mov r9d, 0x76
01ae6c30  4c8d05a9f9a200           lea r8, [rip + 0xa2f9a9]
01ae6c37  488d15a217a300           lea rdx, [rip + 0xa317a2]
01ae6c3e  418d498b                 lea ecx, [r9 - 0x75]
01ae6c42  ff1530423e00             call qword ptr [rip + 0x3e4230]
01ae6c48  4584ff                   test r15b, r15b
01ae6c4b  7457                     je 0x1ae6ca4
01ae6c4d  4d8b8424a0000000         mov r8, qword ptr [r12 + 0xa0]
01ae6c55  c644242801               mov byte ptr [rsp + 0x28], 1
01ae6c5a  488d45e7                 lea rax, [rbp - 0x19]
01ae6c5e  4889442420               mov qword ptr [rsp + 0x20], rax
01ae6c63  4c8d4dcf                 lea r9, [rbp - 0x31]
01ae6c67  4d8b4010                 mov r8, qword ptr [r8 + 0x10]
01ae6c6b  8bd3                     mov edx, ebx
01ae6c6d  498bcc                   mov rcx, r12
01ae6c70  e89b060000               call 0x1ae7310
01ae6c75  85c0                     test eax, eax
01ae6c77  7927                     jns 0x1ae6ca0
01ae6c79  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae6c82  41b980000000             mov r9d, 0x80
01ae6c88  4c8d0551f9a200           lea r8, [rip + 0xa2f951]
01ae6c8f  488d154a17a300           lea rdx, [rip + 0xa3174a]
01ae6c96  418d4981                 lea ecx, [r9 - 0x7f]
01ae6c9a  ff15d8413e00             call qword ptr [rip + 0x3e41d8]
01ae6ca0  4c8b75cf                 mov r14, qword ptr [rbp - 0x31]
01ae6ca4  488b757f                 mov rsi, qword ptr [rbp + 0x7f]
01ae6ca8  4533c9                   xor r9d, r9d
01ae6cab  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae6cb3  8b4220                   mov eax, dword ptr [rdx + 0x20]
01ae6cb6  48c7c3ffffffff           mov rbx, 0xffffffffffffffff
01ae6cbd  83f80b                   cmp eax, 0xb
01ae6cc0  0f87c5010000             ja 0x1ae6e8b
01ae6cc6  b9b60b0000               mov ecx, 0xbb6
01ae6ccb  0fa3c1                   bt ecx, eax
01ae6cce  0f83b7010000             jae 0x1ae6e8b
01ae6cd4  488b5218                 mov rdx, qword ptr [rdx + 0x18]
01ae6cd8  4c894ddf                 mov qword ptr [rbp - 0x21], r9
01ae6cdc  4c894d77                 mov qword ptr [rbp + 0x77], r9
01ae6ce0  4c8d4d77                 lea r9, [rbp + 0x77]
01ae6ce4  4c8d45df                 lea r8, [rbp - 0x21]
01ae6ce8  498bcc                   mov rcx, r12
01ae6ceb  e8e0080000               call 0x1ae75d0
01ae6cf0  4533ed                   xor r13d, r13d
01ae6cf3  4d8bbc2490000000         mov r15, qword ptr [r12 + 0x90]
01ae6cfb  4d85ff                   test r15, r15
01ae6cfe  7509                     jne 0x1ae6d09
01ae6d00  4c8d3d79115700           lea r15, [rip + 0x571179]
01ae6d07  eb14                     jmp 0x1ae6d1d
01ae6d09  488bc3                   mov rax, rbx
01ae6d0c  0f1f4000                 nop dword ptr [rax]
01ae6d10  48ffc0                   inc rax
01ae6d13  6645392c47               cmp word ptr [r15 + rax*2], r13w
01ae6d18  75f6                     jne 0x1ae6d10
01ae6d1a  448be8                   mov r13d, eax
01ae6d1d  498b8424a8000000         mov rax, qword ptr [r12 + 0xa8]
01ae6d25  488b5030                 mov rdx, qword ptr [rax + 0x30]
01ae6d29  488955d7                 mov qword ptr [rbp - 0x29], rdx
01ae6d2d  488d0d4c115700           lea rcx, [rip + 0x57114c]
01ae6d34  4885d2                   test rdx, rdx
01ae6d37  480f45ca                 cmovne rcx, rdx
01ae6d3b  488bc3                   mov rax, rbx
01ae6d3e  6690                     nop
01ae6d40  48ffc0                   inc rax
01ae6d43  66833c4100               cmp word ptr [rcx + rax*2], 0
01ae6d48  75f6                     jne 0x1ae6d40
01ae6d4a  8bc0                     mov eax, eax
01ae6d4c  488945c7                 mov qword ptr [rbp - 0x39], rax
01ae6d50  bf09000000               mov edi, 9
01ae6d55  8d47fd                   lea eax, [rdi - 3]
01ae6d58  4180bc24b000000000       cmp byte ptr [r12 + 0xb0], 0
01ae6d61  740a                     je 0x1ae6d6d
01ae6d63  8bdf                     mov ebx, edi
01ae6d65  4885d2                   test rdx, rdx
01ae6d68  0f45d8                   cmovne ebx, eax
01ae6d6b  eb05                     jmp 0x1ae6d72
01ae6d6d  bb03000000               mov ebx, 3
01ae6d72  488d05879251fe           lea rax, [rip - 0x1ae6d79]
01ae6d79  488b9cd840722c02         mov rbx, qword ptr [rax + rbx*8 + 0x22c7240]
01ae6d81  498b0424                 mov rax, qword ptr [r12]
01ae6d85  33d2                     xor edx, edx
01ae6d87  498bcc                   mov rcx, r12
01ae6d8a  ff9000020000             call qword ptr [rax + 0x200]
01ae6d90  410fb68c24b0000000       movzx ecx, byte ptr [r12 + 0xb0]
01ae6d99  84c9                     test cl, cl
01ae6d9b  4c0f456dc7               cmovne r13, qword ptr [rbp - 0x39]
01ae6da0  4c03e8                   add r13, rax
01ae6da3  4c03eb                   add r13, rbx
01ae6da6  4c036d77                 add r13, qword ptr [rbp + 0x77]
01ae6daa  488b5dd7                 mov rbx, qword ptr [rbp - 0x29]
01ae6dae  84c9                     test cl, cl
01ae6db0  740e                     je 0x1ae6dc0
01ae6db2  4885db                   test rbx, rbx
01ae6db5  b806000000               mov eax, 6
01ae6dba  480f45f8                 cmovne rdi, rax
01ae6dbe  eb05                     jmp 0x1ae6dc5
01ae6dc0  bf03000000               mov edi, 3
01ae6dc5  488d05349251fe           lea rax, [rip - 0x1ae6dcc]
01ae6dcc  488b84f8e06a2c02         mov rax, qword ptr [rax + rdi*8 + 0x22c6ae0]
01ae6dd4  48894577                 mov qword ptr [rbp + 0x77], rax
01ae6dd8  b802000000               mov eax, 2
01ae6ddd  49f7e5                   mul r13
01ae6de0  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
01ae6de7  480f40c1                 cmovo rax, rcx
01ae6deb  c644242006               mov byte ptr [rsp + 0x20], 6
01ae6df0  41b937010000             mov r9d, 0x137
01ae6df6  4c8d058315a200           lea r8, [rip + 0xa21583]
01ae6dfd  498b542440               mov rdx, qword ptr [r12 + 0x40]
01ae6e02  488bc8                   mov rcx, rax
01ae6e05  ff15ed403e00             call qword ptr [rip + 0x3e40ed]
01ae6e0b  488bf8                   mov rdi, rax
01ae6e0e  4885c0                   test rax, rax
01ae6e11  7408                     je 0x1ae6e1b
01ae6e13  33c9                     xor ecx, ecx
01ae6e15  ff158d413e00             call qword ptr [rip + 0x3e418d]
01ae6e1b  48897df7                 mov qword ptr [rbp - 9], rdi
01ae6e1f  4180bc24b000000000       cmp byte ptr [r12 + 0xb0], 0
01ae6e28  4c0f45fb                 cmovne r15, rbx
01ae6e2c  ff15b63f3e00             call qword ptr [rip + 0x3e3fb6]
01ae6e32  4c8bc8                   mov r9, rax
01ae6e35  4c897c2428               mov qword ptr [rsp + 0x28], r15
01ae6e3a  488b5ddf                 mov rbx, qword ptr [rbp - 0x21]
01ae6e3e  48895c2420               mov qword ptr [rsp + 0x20], rbx
01ae6e43  4c8b4577                 mov r8, qword ptr [rbp + 0x77]
01ae6e47  498bd5                   mov rdx, r13
01ae6e4a  488bcf                   mov rcx, rdi
01ae6e4d  e83ea956fe               call 0x51790
01ae6e52  448bf8                   mov r15d, eax
01ae6e55  488bcb                   mov rcx, rbx
01ae6e58  ff154a413e00             call qword ptr [rip + 0x3e414a]
01ae6e5e  4585ff                   test r15d, r15d
01ae6e61  7928                     jns 0x1ae6e8b
01ae6e63  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae6e6c  41b992000000             mov r9d, 0x92
01ae6e72  4c8d0567f7a200           lea r8, [rip + 0xa2f767]
01ae6e79  488d156015a300           lea rdx, [rip + 0xa31560]
01ae6e80  b901000000               mov ecx, 1
01ae6e85  ff15ed3f3e00             call qword ptr [rip + 0x3e3fed]
01ae6e8b  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
01ae6e94  8b0572070001             mov eax, dword ptr [rip + 0x1000772]
01ae6e9a  ba04000000               mov edx, 4
01ae6e9f  488b04c1                 mov rax, qword ptr [rcx + rax*8]
01ae6ea3  8b0c02                   mov ecx, dword ptr [rdx + rax]
01ae6ea6  390dccee1b01             cmp dword ptr [rip + 0x11beecc], ecx
01ae6eac  7e2c                     jle 0x1ae6eda
01ae6eae  488d0dc3ee1b01           lea rcx, [rip + 0x11beec3]
01ae6eb5  e8c25b58fe               call 0x6ca7c
01ae6eba  833db7ee1b01ff           cmp dword ptr [rip + 0x11beeb7], -1
01ae6ec1  7517                     jne 0x1ae6eda
01ae6ec3  48c705b2ee1b011b000000   mov qword ptr [rip + 0x11beeb2], 0x1b
01ae6ece  488d0da3ee1b01           lea rcx, [rip + 0x11beea3]
01ae6ed5  e8c69788fe               call 0x3706a0
01ae6eda  33db                     xor ebx, ebx
01ae6edc  0fb64567                 movzx eax, byte ptr [rbp + 0x67]
01ae6ee0  84c0                     test al, al
01ae6ee2  480f451d96ee1b01         cmovne rbx, qword ptr [rip + 0x11bee96]
01ae6eea  4c8d3d5714a200           lea r15, [rip + 0xa21457]
01ae6ef1  488d05880f5700           lea rax, [rip + 0x570f88]
01ae6ef8  4c0f44f8                 cmove r15, rax
01ae6efc  4c897d77                 mov qword ptr [rbp + 0x77], r15
01ae6f00  4d8b0424                 mov r8, qword ptr [r12]
01ae6f04  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae6f0c  498bcc                   mov rcx, r12
01ae6f0f  41ff90d0010000           call qword ptr [r8 + 0x1d0]
01ae6f16  4803c3                   add rax, rbx
01ae6f19  4903c5                   add rax, r13
01ae6f1c  480345e7                 add rax, qword ptr [rbp - 0x19]
01ae6f20  488b4def                 mov rcx, qword ptr [rbp - 0x11]
01ae6f24  48ffc1                   inc rcx
01ae6f27  4803c8                   add rcx, rax
01ae6f2a  48894d67                 mov qword ptr [rbp + 0x67], rcx
01ae6f2e  b802000000               mov eax, 2
01ae6f33  48f7e1                   mul rcx
01ae6f36  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
01ae6f3d  480f40c1                 cmovo rax, rcx
01ae6f41  c644242006               mov byte ptr [rsp + 0x20], 6
01ae6f46  41b99e000000             mov r9d, 0x9e
01ae6f4c  4c8d052d14a200           lea r8, [rip + 0xa2142d]
01ae6f53  498b542440               mov rdx, qword ptr [r12 + 0x40]
01ae6f58  488bc8                   mov rcx, rax
01ae6f5b  ff15973f3e00             call qword ptr [rip + 0x3e3f97]
01ae6f61  4c8be8                   mov r13, rax
01ae6f64  488945c7                 mov qword ptr [rbp - 0x39], rax
01ae6f68  498b8c24a0000000         mov rcx, qword ptr [r12 + 0xa0]
01ae6f70  48634120                 movsxd rax, dword ptr [rcx + 0x20]
01ae6f74  83f80b                   cmp eax, 0xb
01ae6f77  0f87d9020000             ja 0x1ae7256
01ae6f7d  488bc8                   mov rcx, rax
01ae6f80  488d05799051fe           lea rax, [rip - 0x1ae6f87]
01ae6f87  8b9488cc72ae01           mov edx, dword ptr [rax + rcx*4 + 0x1ae72cc]
01ae6f8e  4803d0                   add rdx, rax
01ae6f91  ffe2                     jmp rdx
01ae6f93  488d052e14a200           lea rax, [rip + 0xa2142e]
01ae6f9a  4c8d3d87c36300           lea r15, [rip + 0x63c387]
01ae6fa1  837d6f01                 cmp dword ptr [rbp + 0x6f], 1
01ae6fa5  4c0f44f8                 cmove r15, rax
01ae6fa9  ff15393e3e00             call qword ptr [rip + 0x3e3e39]
01ae6faf  488bd8                   mov rbx, rax
01ae6fb2  4d8b0424                 mov r8, qword ptr [r12]
01ae6fb6  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae6fbe  498bcc                   mov rcx, r12
01ae6fc1  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae6fc8  4c8bc0                   mov r8, rax
01ae6fcb  488b4577                 mov rax, qword ptr [rbp + 0x77]
01ae6fcf  4889442430               mov qword ptr [rsp + 0x30], rax
01ae6fd4  4c897c2428               mov qword ptr [rsp + 0x28], r15
01ae6fd9  4889742420               mov qword ptr [rsp + 0x20], rsi
01ae6fde  4c8bcb                   mov r9, rbx
01ae6fe1  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae6fe5  498bcd                   mov rcx, r13
01ae6fe8  e8a3a756fe               call 0x51790
01ae6fed  85c0                     test eax, eax
01ae6fef  0f8989020000             jns 0x1ae727e
01ae6ff5  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae6ffe  41b9ad000000             mov r9d, 0xad
01ae7004  4c8d05d5f5a200           lea r8, [rip + 0xa2f5d5]
01ae700b  488d15ce13a300           lea rdx, [rip + 0xa313ce]
01ae7012  b901000000               mov ecx, 1
01ae7017  ff155b3e3e00             call qword ptr [rip + 0x3e3e5b]
01ae701d  e95c020000               jmp 0x1ae727e
01ae7022  488d059f13a200           lea rax, [rip + 0xa2139f]
01ae7029  4c8d3df8c26300           lea r15, [rip + 0x63c2f8]
01ae7030  837d6f01                 cmp dword ptr [rbp + 0x6f], 1
01ae7034  4c0f44f8                 cmove r15, rax
01ae7038  ff15aa3d3e00             call qword ptr [rip + 0x3e3daa]
01ae703e  488bd8                   mov rbx, rax
01ae7041  4d8b0424                 mov r8, qword ptr [r12]
01ae7045  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae704d  498bcc                   mov rcx, r12
01ae7050  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae7057  4c8bc0                   mov r8, rax
01ae705a  488b4577                 mov rax, qword ptr [rbp + 0x77]
01ae705e  4889442440               mov qword ptr [rsp + 0x40], rax
01ae7063  4c897c2438               mov qword ptr [rsp + 0x38], r15
01ae7068  4c89742430               mov qword ptr [rsp + 0x30], r14
01ae706d  4c897c2428               mov qword ptr [rsp + 0x28], r15
01ae7072  4889742420               mov qword ptr [rsp + 0x20], rsi
01ae7077  4c8bcb                   mov r9, rbx
01ae707a  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae707e  498bcd                   mov rcx, r13
01ae7081  e80aa756fe               call 0x51790
01ae7086  85c0                     test eax, eax
01ae7088  0f89f0010000             jns 0x1ae727e
01ae708e  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae7097  41b9bc000000             mov r9d, 0xbc
01ae709d  4c8d053cf5a200           lea r8, [rip + 0xa2f53c]
01ae70a4  488d153513a300           lea rdx, [rip + 0xa31335]
01ae70ab  b901000000               mov ecx, 1
01ae70b0  ff15c23d3e00             call qword ptr [rip + 0x3e3dc2]
01ae70b6  e9c3010000               jmp 0x1ae727e
01ae70bb  ff15273d3e00             call qword ptr [rip + 0x3e3d27]
01ae70c1  488bd8                   mov rbx, rax
01ae70c4  4d8b0424                 mov r8, qword ptr [r12]
01ae70c8  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae70d0  498bcc                   mov rcx, r12
01ae70d3  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae70da  4c8bc0                   mov r8, rax
01ae70dd  4c897c2428               mov qword ptr [rsp + 0x28], r15
01ae70e2  48897c2420               mov qword ptr [rsp + 0x20], rdi
01ae70e7  4c8bcb                   mov r9, rbx
01ae70ea  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae70ee  498bcd                   mov rcx, r13
01ae70f1  e89aa656fe               call 0x51790
01ae70f6  85c0                     test eax, eax
01ae70f8  0f8980010000             jns 0x1ae727e
01ae70fe  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae7107  41b9ca000000             mov r9d, 0xca
01ae710d  4c8d05ccf4a200           lea r8, [rip + 0xa2f4cc]
01ae7114  488d15c512a300           lea rdx, [rip + 0xa312c5]
01ae711b  b901000000               mov ecx, 1
01ae7120  ff15523d3e00             call qword ptr [rip + 0x3e3d52]
01ae7126  e953010000               jmp 0x1ae727e
01ae712b  488d059612a200           lea rax, [rip + 0xa21296]
01ae7132  4c8d3defc16300           lea r15, [rip + 0x63c1ef]
01ae7139  837d6f01                 cmp dword ptr [rbp + 0x6f], 1
01ae713d  4c0f44f8                 cmove r15, rax
01ae7141  ff15a13c3e00             call qword ptr [rip + 0x3e3ca1]
01ae7147  488bd8                   mov rbx, rax
01ae714a  4d8b0424                 mov r8, qword ptr [r12]
01ae714e  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae7156  498bcc                   mov rcx, r12
01ae7159  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae7160  4c8bc0                   mov r8, rax
01ae7163  488b4577                 mov rax, qword ptr [rbp + 0x77]
01ae7167  4889442438               mov qword ptr [rsp + 0x38], rax
01ae716c  4c897c2430               mov qword ptr [rsp + 0x30], r15
01ae7171  4889742428               mov qword ptr [rsp + 0x28], rsi
01ae7176  48897c2420               mov qword ptr [rsp + 0x20], rdi
01ae717b  4c8bcb                   mov r9, rbx
01ae717e  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae7182  498bcd                   mov rcx, r13
01ae7185  e806a656fe               call 0x51790
01ae718a  85c0                     test eax, eax
01ae718c  0f89ec000000             jns 0x1ae727e
01ae7192  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae719b  41b9d8000000             mov r9d, 0xd8
01ae71a1  4c8d0538f4a200           lea r8, [rip + 0xa2f438]
01ae71a8  488d153112a300           lea rdx, [rip + 0xa31231]
01ae71af  b901000000               mov ecx, 1
01ae71b4  ff15be3c3e00             call qword ptr [rip + 0x3e3cbe]
01ae71ba  e9bf000000               jmp 0x1ae727e
01ae71bf  488d050212a200           lea rax, [rip + 0xa21202]
01ae71c6  4c8d3d5bc16300           lea r15, [rip + 0x63c15b]
01ae71cd  837d6f01                 cmp dword ptr [rbp + 0x6f], 1
01ae71d1  4c0f44f8                 cmove r15, rax
01ae71d5  ff150d3c3e00             call qword ptr [rip + 0x3e3c0d]
01ae71db  488bd8                   mov rbx, rax
01ae71de  4d8b0424                 mov r8, qword ptr [r12]
01ae71e2  498b9424a0000000         mov rdx, qword ptr [r12 + 0xa0]
01ae71ea  498bcc                   mov rcx, r12
01ae71ed  41ff90c8010000           call qword ptr [r8 + 0x1c8]
01ae71f4  4c8bc0                   mov r8, rax
01ae71f7  488b4577                 mov rax, qword ptr [rbp + 0x77]
01ae71fb  4889442448               mov qword ptr [rsp + 0x48], rax
01ae7200  4c897c2440               mov qword ptr [rsp + 0x40], r15
01ae7205  4c89742438               mov qword ptr [rsp + 0x38], r14
01ae720a  4c897c2430               mov qword ptr [rsp + 0x30], r15
01ae720f  4889742428               mov qword ptr [rsp + 0x28], rsi
01ae7214  48897c2420               mov qword ptr [rsp + 0x20], rdi
01ae7219  4c8bcb                   mov r9, rbx
01ae721c  488b5567                 mov rdx, qword ptr [rbp + 0x67]
01ae7220  498bcd                   mov rcx, r13
01ae7223  e868a556fe               call 0x51790
01ae7228  85c0                     test eax, eax
01ae722a  7952                     jns 0x1ae727e
01ae722c  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae7235  41b9e8000000             mov r9d, 0xe8
01ae723b  4c8d059ef3a200           lea r8, [rip + 0xa2f39e]
01ae7242  488d159711a300           lea rdx, [rip + 0xa31197]
01ae7249  b901000000               mov ecx, 1
01ae724e  ff15243c3e00             call qword ptr [rip + 0x3e3c24]
01ae7254  eb28                     jmp 0x1ae727e
01ae7256  48c744242000000000       mov qword ptr [rsp + 0x20], 0
01ae725f  41b9ec000000             mov r9d, 0xec
01ae7265  4c8d0574f3a200           lea r8, [rip + 0xa2f374]
01ae726c  488d15b5f5a200           lea rdx, [rip + 0xa2f5b5]
01ae7273  b901000000               mov ecx, 1
01ae7278  ff15fa3b3e00             call qword ptr [rip + 0x3e3bfa]
01ae727e  48c745c700000000         mov qword ptr [rbp - 0x39], 0
01ae7286  33c9                     xor ecx, ecx
01ae7288  ff151a3d3e00             call qword ptr [rip + 0x3e3d1a]
01ae728e  90                       nop
01ae728f  33c9                     xor ecx, ecx
01ae7291  ff15113d3e00             call qword ptr [rip + 0x3e3d11]
01ae7297  90                       nop
01ae7298  488bcf                   mov rcx, rdi
01ae729b  ff15073d3e00             call qword ptr [rip + 0x3e3d07]
01ae72a1  90                       nop
01ae72a2  498bce                   mov rcx, r14
01ae72a5  ff15fd3c3e00             call qword ptr [rip + 0x3e3cfd]
01ae72ab  90                       nop
01ae72ac  488bce                   mov rcx, rsi
01ae72af  ff15f33c3e00             call qword ptr [rip + 0x3e3cf3]
01ae72b5  498bc5                   mov rax, r13
01ae72b8  4881c4a8000000           add rsp, 0xa8
01ae72bf  415f                     pop r15
01ae72c1  415e                     pop r14
01ae72c3  415d                     pop r13
01ae72c5  415c                     pop r12
01ae72c7  5f                       pop rdi
01ae72c8  5e                       pop rsi
01ae72c9  5b                       pop rbx
01ae72ca  5d                       pop rbp
01ae72cb  c3                       ret
01ae72cc  93                       xchg ebx, eax
01ae72cd  6f                       outsd dx, dword ptr [rsi]
01ae72ce  ae                       scasb al, byte ptr [rdi]
01ae72cf  01bb70ae012b             add dword ptr [rbx + 0x2b01ae70], edi
01ae72d5  71ae                     jno 0x1ae7285
01ae72d7  01936fae01bb             add dword ptr [rbx - 0x44fe5191], edx
01ae72dd  70ae                     jo 0x1ae728d
01ae72df  012b                     add dword ptr [rbx], ebp
01ae72e1  71ae                     jno 0x1ae7291
01ae72e3  0122                     add dword ptr [rdx], esp
01ae72e5  70ae                     jo 0x1ae7295
01ae72e7  01bb70ae01bf             add dword ptr [rbx - 0x40fe5190], edi
01ae72ed  71ae                     jno 0x1ae729d
01ae72ef  01bb70ae0122             add dword ptr [rbx + 0x2201ae70], edi
01ae72f5  70ae                     jo 0x1ae72a5
