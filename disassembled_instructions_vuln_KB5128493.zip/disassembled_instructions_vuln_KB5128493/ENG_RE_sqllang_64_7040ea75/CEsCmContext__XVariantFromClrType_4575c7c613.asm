; CEsCmContext::XVariantFromClrType
; sqllang.dll, primary RVA 0x71a410, 2923 bytes in 3 chunk(s)

; chunk at RVA 0x71a410 (19 bytes)
0071a410  4055                     push rbp
0071a412  57                       push rdi
0071a413  4157                     push r15
0071a415  488bec                   mov rbp, rsp
0071a418  4883ec50                 sub rsp, 0x50
0071a41c  448b7a60                 mov r15d, dword ptr [rdx + 0x60]
0071a420  488bf9                   mov rdi, rcx

; chunk at RVA 0x71a423 (2795 bytes)
0071a423  4889742448               mov qword ptr [rsp + 0x48], rsi
0071a428  488bf2                   mov rsi, rdx
0071a42b  4c89642440               mov qword ptr [rsp + 0x40], r12
0071a430  4c896c2438               mov qword ptr [rsp + 0x38], r13
0071a435  4c89742430               mov qword ptr [rsp + 0x30], r14
0071a43a  440fb67249               movzx r14d, byte ptr [rdx + 0x49]
0071a43f  4183ffff                 cmp r15d, -1
0071a443  7519                     jne 0x71a45e
0071a445  4883c228                 add rdx, 0x28
0071a449  4533c0                   xor r8d, r8d
0071a44c  e89f86ffff               call 0x712af0
0071a451  8bd0                     mov edx, eax
0071a453  488bcf                   mov rcx, rdi
0071a456  448bf8                   mov r15d, eax
0071a459  e8a290ffff               call 0x713500
0071a45e  4533c0                   xor r8d, r8d
0071a461  48895c2470               mov qword ptr [rsp + 0x70], rbx
0071a466  488bd6                   mov rdx, rsi
0071a469  488bcf                   mov rcx, rdi
0071a46c  e82f92ffff               call 0x7136a0
0071a471  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a475  4c8d25845b8eff           lea r12, [rip - 0x71a47c]
0071a47c  41bdffff0000             mov r13d, 0xffff
0071a482  6644396810               cmp word ptr [rax + 0x10], r13w
0071a487  741b                     je 0x71a4a4
0071a489  0fb600                   movzx eax, byte ptr [rax]
0071a48c  420fb68c2010360202       movzx ecx, byte ptr [rax + r12 + 0x2023610]
0071a495  4280bc219875ae0200       cmp byte ptr [rcx + r12 + 0x2ae7598], 0
0071a49e  0f845a010000             je 0x71a5fe
0071a4a4  837e3c25                 cmp dword ptr [rsi + 0x3c], 0x25
0071a4a8  0f8450010000             je 0x71a5fe
0071a4ae  ba16000000               mov edx, 0x16
0071a4b3  488bcf                   mov rcx, rdi
0071a4b6  e8558bffff               call 0x713010
0071a4bb  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a4bf  0fb601                   movzx eax, byte ptr [rcx]
0071a4c2  420fb6942010360202       movzx edx, byte ptr [rax + r12 + 0x2023610]
0071a4cb  4280bc220086050200       cmp byte ptr [rdx + r12 + 0x2058600], 0
0071a4d4  747e                     je 0x71a554
0071a4d6  ff156c197b01             call qword ptr [rip + 0x17b196c]
0071a4dc  8bc8                     mov ecx, eax
0071a4de  ff156c197b01             call qword ptr [rip + 0x17b196c]
0071a4e4  ba21000000               mov edx, 0x21
0071a4e9  488bcf                   mov rcx, rdi
0071a4ec  8bd8                     mov ebx, eax
0071a4ee  e81d8bffff               call 0x713010
0071a4f3  8bd3                     mov edx, ebx
0071a4f5  488bcf                   mov rcx, rdi
0071a4f8  e8537bffff               call 0x712050
0071a4fd  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a501  ff1541197b01             call qword ptr [rip + 0x17b1941]
0071a507  448bc8                   mov r9d, eax
0071a50a  0fbae010                 bt eax, 0x10
0071a50e  7307                     jae 0x71a517
0071a510  ba00800000               mov edx, 0x8000
0071a515  eb35                     jmp 0x71a54c
0071a517  418bc9                   mov ecx, r9d
0071a51a  c1e90c                   shr ecx, 0xc
0071a51d  83e101                   and ecx, 1
0071a520  448bc1                   mov r8d, ecx
0071a523  4183c802                 or r8d, 2
0071a527  2500200000               and eax, 0x2000
0071a52c  418bc1                   mov eax, r9d
0071a52f  440f44c1                 cmove r8d, ecx
0071a533  418bd0                   mov edx, r8d
0071a536  83ca08                   or edx, 8
0071a539  2500400000               and eax, 0x4000
0071a53e  410f44d0                 cmove edx, r8d
0071a542  410fbae10f               bt r9d, 0xf
0071a547  7303                     jae 0x71a54c
0071a549  83ca10                   or edx, 0x10
0071a54c  488bcf                   mov rcx, rdi
0071a54f  e81c8effff               call 0x713370
0071a554  ba04000000               mov edx, 4
0071a559  488bcf                   mov rcx, rdi
0071a55c  e8af8affff               call 0x713010
0071a561  ba28000000               mov edx, 0x28
0071a566  488bcf                   mov rcx, rdi
0071a569  e8a28affff               call 0x713010
0071a56e  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a572  4c8d4d28                 lea r9, [rbp + 0x28]
0071a576  488b0f                   mov rcx, qword ptr [rdi]
0071a579  41b8a4000000             mov r8d, 0xa4
0071a57f  0fb610                   movzx edx, byte ptr [rax]
0071a582  420fb6842210360202       movzx eax, byte ptr [rdx + r12 + 0x2023610]
0071a58b  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a58f  4280bc200086050200       cmp byte ptr [rax + r12 + 0x2058600], 0
0071a598  7506                     jne 0x71a5a0
0071a59a  41b8a5000000             mov r8d, 0xa5
0071a5a0  e82b88f9ff               call 0x6b2dd0
0071a5a5  83f801                   cmp eax, 1
0071a5a8  750d                     jne 0x71a5b7
0071a5aa  448d4014                 lea r8d, [rax + 0x14]
0071a5ae  8bd0                     mov edx, eax
0071a5b0  33c9                     xor ecx, ecx
0071a5b2  e829ff0000               call 0x72a4e0
0071a5b7  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a5ba  488bcf                   mov rcx, rdi
0071a5bd  0fb6d3                   movzx edx, bl
0071a5c0  e8cb82ffff               call 0x712890
0071a5c5  0fb7d3                   movzx edx, bx
0071a5c8  488bcf                   mov rcx, rdi
0071a5cb  66c1ea08                 shr dx, 8
0071a5cf  e8bc82ffff               call 0x712890
0071a5d4  c1eb10                   shr ebx, 0x10
0071a5d7  488bcf                   mov rcx, rdi
0071a5da  0fb6d3                   movzx edx, bl
0071a5dd  e8ae82ffff               call 0x712890
0071a5e2  66c1eb08                 shr bx, 8
0071a5e6  488bcf                   mov rcx, rdi
0071a5e9  0fb6d3                   movzx edx, bl
0071a5ec  e89f82ffff               call 0x712890
0071a5f1  ba25000000               mov edx, 0x25
0071a5f6  488bcf                   mov rcx, rdi
0071a5f9  e8128affff               call 0x713010
0071a5fe  418bd7                   mov edx, r15d
0071a601  488bcf                   mov rcx, rdi
0071a604  e8878effff               call 0x713490
0071a609  8b463c                   mov eax, dword ptr [rsi + 0x3c]
0071a60c  83c0e3                   add eax, -0x1d
0071a60f  83f826                   cmp eax, 0x26
0071a612  0f87ac080000             ja 0x71aec4
0071a618  4898                     cdqe
0071a61a  410fb6840454af7100       movzx eax, byte ptr [r12 + rax + 0x71af54]
0071a623  418b8c842caf7100         mov ecx, dword ptr [r12 + rax*4 + 0x71af2c]
0071a62b  4903cc                   add rcx, r12
0071a62e  ffe1                     jmp rcx
0071a630  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a634  80382a                   cmp byte ptr [rax], 0x2a
0071a637  750c                     jne 0x71a645
0071a639  0fb65013                 movzx edx, byte ptr [rax + 0x13]
0071a63d  488bcf                   mov rcx, rdi
0071a640  e82b8dffff               call 0x713370
0071a645  ba28000000               mov edx, 0x28
0071a64a  488bcf                   mov rcx, rdi
0071a64d  e8be89ffff               call 0x713010
0071a652  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a656  0fb608                   movzx ecx, byte ptr [rax]
0071a659  80f93d                   cmp cl, 0x3d
0071a65c  750e                     jne 0x71a66c
0071a65e  33c0                     xor eax, eax
0071a660  4584f6                   test r14b, r14b
0071a663  0f95c0                   setne al
0071a666  448d4076                 lea r8d, [rax + 0x76]
0071a66a  eb2e                     jmp 0x71a69a
0071a66c  80f928                   cmp cl, 0x28
0071a66f  7511                     jne 0x71a682
0071a671  33c0                     xor eax, eax
0071a673  4584f6                   test r14b, r14b
0071a676  0f95c0                   setne al
0071a679  448d8086000000           lea r8d, [rax + 0x86]
0071a680  eb18                     jmp 0x71a69a
0071a682  80f92a                   cmp cl, 0x2a
0071a685  0f8564080000             jne 0x71aeef
0071a68b  33c0                     xor eax, eax
0071a68d  4584f6                   test r14b, r14b
0071a690  0f95c0                   setne al
0071a693  448d808e000000           lea r8d, [rax + 0x8e]
0071a69a  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a69e  4c8d4d28                 lea r9, [rbp + 0x28]
0071a6a2  488b0f                   mov rcx, qword ptr [rdi]
0071a6a5  e82687f9ff               call 0x6b2dd0
0071a6aa  83f801                   cmp eax, 1
0071a6ad  750d                     jne 0x71a6bc
0071a6af  8bd0                     mov edx, eax
0071a6b1  448d4014                 lea r8d, [rax + 0x14]
0071a6b5  33c9                     xor ecx, ecx
0071a6b7  e824fe0000               call 0x72a4e0
0071a6bc  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a6bf  488bcf                   mov rcx, rdi
0071a6c2  0fb6d3                   movzx edx, bl
0071a6c5  e8c681ffff               call 0x712890
0071a6ca  0fb7d3                   movzx edx, bx
0071a6cd  488bcf                   mov rcx, rdi
0071a6d0  66c1ea08                 shr dx, 8
0071a6d4  e8b781ffff               call 0x712890
0071a6d9  c1eb10                   shr ebx, 0x10
0071a6dc  488bcf                   mov rcx, rdi
0071a6df  0fb6d3                   movzx edx, bl
0071a6e2  e8a981ffff               call 0x712890
0071a6e7  66c1eb08                 shr bx, 8
0071a6eb  488bcf                   mov rcx, rdi
0071a6ee  0fb6d3                   movzx edx, bl
0071a6f1  e89a81ffff               call 0x712890
0071a6f6  e9f4070000               jmp 0x71aeef
0071a6fb  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a6ff  0fb611                   movzx edx, byte ptr [rcx]
0071a702  8d4210                   lea eax, [rdx + 0x10]
0071a705  3c01                     cmp al, 1
0071a707  7606                     jbe 0x71a70f
0071a709  0fb64113                 movzx eax, byte ptr [rcx + 0x13]
0071a70d  eb12                     jmp 0x71a721
0071a70f  420fb68c2210360202       movzx ecx, byte ptr [rdx + r12 + 0x2023610]
0071a718  410fb6848c13370202       movzx eax, byte ptr [r12 + rcx*4 + 0x2023713]
0071a721  0fb6d0                   movzx edx, al
0071a724  488bcf                   mov rcx, rdi
0071a727  e8448cffff               call 0x713370
0071a72c  ba28000000               mov edx, 0x28
0071a731  488bcf                   mov rcx, rdi
0071a734  e8d788ffff               call 0x713010
0071a739  33c0                     xor eax, eax
0071a73b  4584f6                   test r14b, r14b
0071a73e  0f95c0                   setne al
0071a741  448d8092000000           lea r8d, [rax + 0x92]
0071a748  e94dffffff               jmp 0x71a69a
0071a74d  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a751  0fb611                   movzx edx, byte ptr [rcx]
0071a754  8d4210                   lea eax, [rdx + 0x10]
0071a757  3c01                     cmp al, 1
0071a759  7606                     jbe 0x71a761
0071a75b  0fb64113                 movzx eax, byte ptr [rcx + 0x13]
0071a75f  eb12                     jmp 0x71a773
0071a761  420fb68c2210360202       movzx ecx, byte ptr [rdx + r12 + 0x2023610]
0071a76a  410fb6848c13370202       movzx eax, byte ptr [r12 + rcx*4 + 0x2023713]
0071a773  0fb6d0                   movzx edx, al
0071a776  488bcf                   mov rcx, rdi
0071a779  e8f28bffff               call 0x713370
0071a77e  ba28000000               mov edx, 0x28
0071a783  488bcf                   mov rcx, rdi
0071a786  e88588ffff               call 0x713010
0071a78b  33c0                     xor eax, eax
0071a78d  4584f6                   test r14b, r14b
0071a790  0f95c0                   setne al
0071a793  448d808a000000           lea r8d, [rax + 0x8a]
0071a79a  e9fbfeffff               jmp 0x71a69a
0071a79f  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a7a3  0fb611                   movzx edx, byte ptr [rcx]
0071a7a6  8d4210                   lea eax, [rdx + 0x10]
0071a7a9  3c01                     cmp al, 1
0071a7ab  7606                     jbe 0x71a7b3
0071a7ad  0fb64112                 movzx eax, byte ptr [rcx + 0x12]
0071a7b1  eb12                     jmp 0x71a7c5
0071a7b3  420fb68c2210360202       movzx ecx, byte ptr [rdx + r12 + 0x2023610]
0071a7bc  410fb6848c12370202       movzx eax, byte ptr [r12 + rcx*4 + 0x2023712]
0071a7c5  0fb6d0                   movzx edx, al
0071a7c8  488bcf                   mov rcx, rdi
0071a7cb  e8a08bffff               call 0x713370
0071a7d0  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a7d4  0fb611                   movzx edx, byte ptr [rcx]
0071a7d7  8d4210                   lea eax, [rdx + 0x10]
0071a7da  3c01                     cmp al, 1
0071a7dc  7606                     jbe 0x71a7e4
0071a7de  0fb64113                 movzx eax, byte ptr [rcx + 0x13]
0071a7e2  eb12                     jmp 0x71a7f6
0071a7e4  420fb68c2210360202       movzx ecx, byte ptr [rdx + r12 + 0x2023610]
0071a7ed  410fb6848c13370202       movzx eax, byte ptr [r12 + rcx*4 + 0x2023713]
0071a7f6  0fb6d0                   movzx edx, al
0071a7f9  488bcf                   mov rcx, rdi
0071a7fc  e86f8bffff               call 0x713370
0071a801  ba28000000               mov edx, 0x28
0071a806  488bcf                   mov rcx, rdi
0071a809  e80288ffff               call 0x713010
0071a80e  33c0                     xor eax, eax
0071a810  4584f6                   test r14b, r14b
0071a813  0f95c0                   setne al
0071a816  448d4070                 lea r8d, [rax + 0x70]
0071a81a  e97bfeffff               jmp 0x71a69a
0071a81f  ba28000000               mov edx, 0x28
0071a824  488bcf                   mov rcx, rdi
0071a827  e8e487ffff               call 0x713010
0071a82c  33c0                     xor eax, eax
0071a82e  4584f6                   test r14b, r14b
0071a831  0f95c0                   setne al
0071a834  448d405e                 lea r8d, [rax + 0x5e]
0071a838  e95dfeffff               jmp 0x71a69a
0071a83d  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a841  0fb608                   movzx ecx, byte ptr [rax]
0071a844  420fb6942110360202       movzx edx, byte ptr [rcx + r12 + 0x2023610]
0071a84d  4280bc223801060200       cmp byte ptr [rdx + r12 + 0x2060138], 0
0071a856  7407                     je 0x71a85f
0071a858  6644396810               cmp word ptr [rax + 0x10], r13w
0071a85d  7409                     je 0x71a868
0071a85f  80f922                   cmp cl, 0x22
0071a862  0f8587000000             jne 0x71a8ef
0071a868  ba28000000               mov edx, 0x28
0071a86d  488bcf                   mov rcx, rdi
0071a870  e89b87ffff               call 0x713010
0071a875  488b5708                 mov rdx, qword ptr [rdi + 8]
0071a879  4c8d4d28                 lea r9, [rbp + 0x28]
0071a87d  488b0f                   mov rcx, qword ptr [rdi]
0071a880  41b8b8000000             mov r8d, 0xb8
0071a886  e84585f9ff               call 0x6b2dd0
0071a88b  83f801                   cmp eax, 1
0071a88e  750d                     jne 0x71a89d
0071a890  8bd0                     mov edx, eax
0071a892  448d4014                 lea r8d, [rax + 0x14]
0071a896  33c9                     xor ecx, ecx
0071a898  e843fc0000               call 0x72a4e0
0071a89d  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071a8a0  488bcf                   mov rcx, rdi
0071a8a3  0fb6d3                   movzx edx, bl
0071a8a6  e8e57fffff               call 0x712890
0071a8ab  0fb7d3                   movzx edx, bx
0071a8ae  488bcf                   mov rcx, rdi
0071a8b1  66c1ea08                 shr dx, 8
0071a8b5  e8d67fffff               call 0x712890
0071a8ba  c1eb10                   shr ebx, 0x10
0071a8bd  488bcf                   mov rcx, rdi
0071a8c0  0fb6d3                   movzx edx, bl
0071a8c3  e8c87fffff               call 0x712890
0071a8c8  66c1eb08                 shr bx, 8
0071a8cc  488bcf                   mov rcx, rdi
0071a8cf  0fb6d3                   movzx edx, bl
0071a8d2  e8b97fffff               call 0x712890
0071a8d7  ba28000000               mov edx, 0x28
0071a8dc  488bcf                   mov rcx, rdi
0071a8df  e82c87ffff               call 0x713010
0071a8e4  41b8bb000000             mov r8d, 0xbb
0071a8ea  e9abfdffff               jmp 0x71a69a
0071a8ef  440fb77010               movzx r14d, word ptr [rax + 0x10]
0071a8f4  bba41f0000               mov ebx, 0x1fa4
0071a8f9  66453bf5                 cmp r14w, r13w
0071a8fd  740b                     je 0x71a90a
0071a8ff  4280bc229875ae0200       cmp byte ptr [rdx + r12 + 0x2ae7598], 0
0071a908  7403                     je 0x71a90d
0071a90a  448bf3                   mov r14d, ebx
0071a90d  ba21000000               mov edx, 0x21
0071a912  488bcf                   mov rcx, rdi
0071a915  e8f686ffff               call 0x713010
0071a91a  410fb7d6                 movzx edx, r14w
0071a91e  488bcf                   mov rcx, rdi
0071a921  e82a77ffff               call 0x712050
0071a926  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a92a  440fb77010               movzx r14d, word ptr [rax + 0x10]
0071a92f  66453bf5                 cmp r14w, r13w
0071a933  7417                     je 0x71a94c
0071a935  0fb600                   movzx eax, byte ptr [rax]
0071a938  420fb68c2010360202       movzx ecx, byte ptr [rax + r12 + 0x2023610]
0071a941  4280bc219875ae0200       cmp byte ptr [rcx + r12 + 0x2ae7598], 0
0071a94a  7403                     je 0x71a94f
0071a94c  448bf3                   mov r14d, ebx
0071a94f  ba21000000               mov edx, 0x21
0071a954  488bcf                   mov rcx, rdi
0071a957  e8b486ffff               call 0x713010
0071a95c  410fb7d6                 movzx edx, r14w
0071a960  488bcf                   mov rcx, rdi
0071a963  e8e876ffff               call 0x712050
0071a968  ba15000000               mov edx, 0x15
0071a96d  488bcf                   mov rcx, rdi
0071a970  e89b86ffff               call 0x713010
0071a975  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071a979  ff1599157b01             call qword ptr [rip + 0x17b1599]
0071a97f  8bd0                     mov edx, eax
0071a981  488bcf                   mov rcx, rdi
0071a984  e8e789ffff               call 0x713370
0071a989  ba28000000               mov edx, 0x28
0071a98e  488bcf                   mov rcx, rdi
0071a991  e87a86ffff               call 0x713010
0071a996  41b859000000             mov r8d, 0x59
0071a99c  e9f9fcffff               jmp 0x71a69a
0071a9a1  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071a9a5  440fb77010               movzx r14d, word ptr [rax + 0x10]
0071a9aa  66453bf5                 cmp r14w, r13w
0071a9ae  0f84cc000000             je 0x71aa80
0071a9b4  0fb608                   movzx ecx, byte ptr [rax]
0071a9b7  420fb6842110360202       movzx eax, byte ptr [rcx + r12 + 0x2023610]
0071a9c0  4280bc209875ae0200       cmp byte ptr [rax + r12 + 0x2ae7598], 0
0071a9c9  0f85b1000000             jne 0x71aa80
0071a9cf  420fb68c2110360202       movzx ecx, byte ptr [rcx + r12 + 0x2023610]
0071a9d8  bba41f0000               mov ebx, 0x1fa4
0071a9dd  4280bc219875ae0200       cmp byte ptr [rcx + r12 + 0x2ae7598], 0
0071a9e6  7404                     je 0x71a9ec
0071a9e8  440fb7f3                 movzx r14d, bx
0071a9ec  ba21000000               mov edx, 0x21
0071a9f1  488bcf                   mov rcx, rdi
0071a9f4  e81786ffff               call 0x713010
0071a9f9  410fb7d6                 movzx edx, r14w
0071a9fd  488bcf                   mov rcx, rdi
0071aa00  e84b76ffff               call 0x712050
0071aa05  488b4620                 mov rax, qword ptr [rsi + 0x20]
0071aa09  440fb77010               movzx r14d, word ptr [rax + 0x10]
0071aa0e  66453bf5                 cmp r14w, r13w
0071aa12  7417                     je 0x71aa2b
0071aa14  0fb600                   movzx eax, byte ptr [rax]
0071aa17  420fb68c2010360202       movzx ecx, byte ptr [rax + r12 + 0x2023610]
0071aa20  4280bc219875ae0200       cmp byte ptr [rcx + r12 + 0x2ae7598], 0
0071aa29  7403                     je 0x71aa2e
0071aa2b  448bf3                   mov r14d, ebx
0071aa2e  ba21000000               mov edx, 0x21
0071aa33  488bcf                   mov rcx, rdi
0071aa36  e8d585ffff               call 0x713010
0071aa3b  410fb7d6                 movzx edx, r14w
0071aa3f  488bcf                   mov rcx, rdi
0071aa42  e80976ffff               call 0x712050
0071aa47  ba15000000               mov edx, 0x15
0071aa4c  488bcf                   mov rcx, rdi
0071aa4f  e8bc85ffff               call 0x713010
0071aa54  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0071aa58  ff15ba147b01             call qword ptr [rip + 0x17b14ba]
0071aa5e  8bd0                     mov edx, eax
0071aa60  488bcf                   mov rcx, rdi
0071aa63  e80889ffff               call 0x713370
0071aa68  ba28000000               mov edx, 0x28
0071aa6d  488bcf                   mov rcx, rdi
0071aa70  e89b85ffff               call 0x713010
0071aa75  41b850000000             mov r8d, 0x50
0071aa7b  e91afcffff               jmp 0x71a69a
0071aa80  ba28000000               mov edx, 0x28
0071aa85  488bcf                   mov rcx, rdi
0071aa88  e88385ffff               call 0x713010
0071aa8d  488b5708                 mov rdx, qword ptr [rdi + 8]
0071aa91  4c8d4d28                 lea r9, [rbp + 0x28]
0071aa95  488b0f                   mov rcx, qword ptr [rdi]
0071aa98  41b8b1000000             mov r8d, 0xb1
0071aa9e  e82d83f9ff               call 0x6b2dd0
0071aaa3  83f801                   cmp eax, 1
0071aaa6  750d                     jne 0x71aab5
0071aaa8  8bd0                     mov edx, eax
0071aaaa  448d4014                 lea r8d, [rax + 0x14]
0071aaae  33c9                     xor ecx, ecx
0071aab0  e82bfa0000               call 0x72a4e0
0071aab5  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071aab8  488bcf                   mov rcx, rdi
0071aabb  0fb6d3                   movzx edx, bl
0071aabe  e8cd7dffff               call 0x712890
0071aac3  0fb7d3                   movzx edx, bx
0071aac6  488bcf                   mov rcx, rdi
0071aac9  66c1ea08                 shr dx, 8
0071aacd  e8be7dffff               call 0x712890
0071aad2  c1eb10                   shr ebx, 0x10
0071aad5  488bcf                   mov rcx, rdi
0071aad8  0fb6d3                   movzx edx, bl
0071aadb  e8b07dffff               call 0x712890
0071aae0  66c1eb08                 shr bx, 8
0071aae4  488bcf                   mov rcx, rdi
0071aae7  0fb6d3                   movzx edx, bl
0071aaea  e8a17dffff               call 0x712890
0071aaef  ba28000000               mov edx, 0x28
0071aaf4  488bcf                   mov rcx, rdi
0071aaf7  e81485ffff               call 0x713010
0071aafc  41b8b2000000             mov r8d, 0xb2
0071ab02  e993fbffff               jmp 0x71a69a
0071ab07  33c0                     xor eax, eax
0071ab09  4c8d4528                 lea r8, [rbp + 0x28]
0071ab0d  488bcf                   mov rcx, rdi
0071ab10  48894528                 mov qword ptr [rbp + 0x28], rax
0071ab14  48894530                 mov qword ptr [rbp + 0x30], rax
0071ab18  8d503a                   lea edx, [rax + 0x3a]
0071ab1b  e87085ffff               call 0x713090
0071ab20  8b9fa0000000             mov ebx, dword ptr [rdi + 0xa0]
0071ab26  ba26000000               mov edx, 0x26
0071ab2b  488bcf                   mov rcx, rdi
0071ab2e  e8dd84ffff               call 0x713010
0071ab33  41b003                   mov r8b, 3
0071ab36  488bd6                   mov rdx, rsi
0071ab39  488bcf                   mov rcx, rdi
0071ab3c  e86f8cffff               call 0x7137b0
0071ab41  4c8d4530                 lea r8, [rbp + 0x30]
0071ab45  ba38000000               mov edx, 0x38
0071ab4a  488bcf                   mov rcx, rdi
0071ab4d  e83e85ffff               call 0x713090
0071ab52  488b4750                 mov rax, qword ptr [rdi + 0x50]
0071ab56  488d5528                 lea rdx, [rbp + 0x28]
0071ab5a  488bcf                   mov rcx, rdi
0071ab5d  448b4804                 mov r9d, dword ptr [rax + 4]
0071ab61  448b00                   mov r8d, dword ptr [rax]
0071ab64  e8078affff               call 0x713570
0071ab69  4533c0                   xor r8d, r8d
0071ab6c  899fa0000000             mov dword ptr [rdi + 0xa0], ebx
0071ab72  488bd6                   mov rdx, rsi
0071ab75  488bcf                   mov rcx, rdi
0071ab78  e8338cffff               call 0x7137b0
0071ab7d  41b802000000             mov r8d, 2
0071ab83  488bd6                   mov rdx, rsi
0071ab86  488bcf                   mov rcx, rdi
0071ab89  e8128bffff               call 0x7136a0
0071ab8e  ba25000000               mov edx, 0x25
0071ab93  488bcf                   mov rcx, rdi
0071ab96  e87584ffff               call 0x713010
0071ab9b  ba48000000               mov edx, 0x48
0071aba0  488bcf                   mov rcx, rdi
0071aba3  e86884ffff               call 0x713010
0071aba8  ba20000000               mov edx, 0x20
0071abad  488bcf                   mov rcx, rdi
0071abb0  e85b84ffff               call 0x713010
0071abb5  33d2                     xor edx, edx
0071abb7  488bcf                   mov rcx, rdi
0071abba  e8d17cffff               call 0x712890
0071abbf  b208                     mov dl, 8
0071abc1  488bcf                   mov rcx, rdi
0071abc4  e8c77cffff               call 0x712890
0071abc9  33d2                     xor edx, edx
0071abcb  488bcf                   mov rcx, rdi
0071abce  e8bd7cffff               call 0x712890
0071abd3  33d2                     xor edx, edx
0071abd5  488bcf                   mov rcx, rdi
0071abd8  e8b37cffff               call 0x712890
0071abdd  ba60000000               mov edx, 0x60
0071abe2  488bcf                   mov rcx, rdi
0071abe5  e82684ffff               call 0x713010
0071abea  ba53000000               mov edx, 0x53
0071abef  488bcf                   mov rcx, rdi
0071abf2  e81984ffff               call 0x713010
0071abf7  ba1f000000               mov edx, 0x1f
0071abfc  488bcf                   mov rcx, rdi
0071abff  e80c84ffff               call 0x713010
0071ac04  b218                     mov dl, 0x18
0071ac06  488bcf                   mov rcx, rdi
0071ac09  e8827cffff               call 0x712890
0071ac0e  ba58000000               mov edx, 0x58
0071ac13  488bcf                   mov rcx, rdi
0071ac16  e8f583ffff               call 0x713010
0071ac1b  418bd7                   mov edx, r15d
0071ac1e  488bcf                   mov rcx, rdi
0071ac21  e86a88ffff               call 0x713490
0071ac26  837e3c42                 cmp dword ptr [rsi + 0x3c], 0x42
0071ac2a  756f                     jne 0x71ac9b
0071ac2c  ba6f000000               mov edx, 0x6f
0071ac31  488bcf                   mov rcx, rdi
0071ac34  e8d783ffff               call 0x713010
0071ac39  488b5708                 mov rdx, qword ptr [rdi + 8]
0071ac3d  4c8d4d28                 lea r9, [rbp + 0x28]
0071ac41  488b0f                   mov rcx, qword ptr [rdi]
0071ac44  41b8c6000000             mov r8d, 0xc6
0071ac4a  e88181f9ff               call 0x6b2dd0
0071ac4f  83f801                   cmp eax, 1
0071ac52  750d                     jne 0x71ac61
0071ac54  8bd0                     mov edx, eax
0071ac56  448d4014                 lea r8d, [rax + 0x14]
0071ac5a  33c9                     xor ecx, ecx
0071ac5c  e87ff80000               call 0x72a4e0
0071ac61  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071ac64  488bcf                   mov rcx, rdi
0071ac67  0fb6d3                   movzx edx, bl
0071ac6a  e8217cffff               call 0x712890
0071ac6f  0fb7d3                   movzx edx, bx
0071ac72  488bcf                   mov rcx, rdi
0071ac75  66c1ea08                 shr dx, 8
0071ac79  e8127cffff               call 0x712890
0071ac7e  c1eb10                   shr ebx, 0x10
0071ac81  488bcf                   mov rcx, rdi
0071ac84  0fb6d3                   movzx edx, bl
0071ac87  e8047cffff               call 0x712890
0071ac8c  66c1eb08                 shr bx, 8
0071ac90  488bcf                   mov rcx, rdi
0071ac93  0fb6d3                   movzx edx, bl
0071ac96  e8f57bffff               call 0x712890
0071ac9b  ba28000000               mov edx, 0x28
0071aca0  488bcf                   mov rcx, rdi
0071aca3  e86883ffff               call 0x713010
0071aca8  488b5708                 mov rdx, qword ptr [rdi + 8]
0071acac  4c8d4d28                 lea r9, [rbp + 0x28]
0071acb0  488b0f                   mov rcx, qword ptr [rdi]
0071acb3  41b804000000             mov r8d, 4
0071acb9  e81281f9ff               call 0x6b2dd0
0071acbe  83f801                   cmp eax, 1
0071acc1  750d                     jne 0x71acd0
0071acc3  8bd0                     mov edx, eax
0071acc5  448d4014                 lea r8d, [rax + 0x14]
0071acc9  33c9                     xor ecx, ecx
0071accb  e810f80000               call 0x72a4e0
0071acd0  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071acd3  488bcf                   mov rcx, rdi
0071acd6  0fb6d3                   movzx edx, bl
0071acd9  e8b27bffff               call 0x712890
0071acde  0fb7d3                   movzx edx, bx
0071ace1  488bcf                   mov rcx, rdi
0071ace4  66c1ea08                 shr dx, 8
0071ace8  e8a37bffff               call 0x712890
0071aced  c1eb10                   shr ebx, 0x10
0071acf0  488bcf                   mov rcx, rdi
0071acf3  0fb6d3                   movzx edx, bl
0071acf6  e8957bffff               call 0x712890
0071acfb  66c1eb08                 shr bx, 8
0071acff  488bcf                   mov rcx, rdi
0071ad02  0fb6d3                   movzx edx, bl
0071ad05  e8867bffff               call 0x712890
0071ad0a  ba28000000               mov edx, 0x28
0071ad0f  488bcf                   mov rcx, rdi
0071ad12  e8f982ffff               call 0x713010
0071ad17  488b5708                 mov rdx, qword ptr [rdi + 8]
0071ad1b  4c8d4d28                 lea r9, [rbp + 0x28]
0071ad1f  488b0f                   mov rcx, qword ptr [rdi]
0071ad22  41b805000000             mov r8d, 5
0071ad28  e8a380f9ff               call 0x6b2dd0
0071ad2d  83f801                   cmp eax, 1
0071ad30  750d                     jne 0x71ad3f
0071ad32  8bd0                     mov edx, eax
0071ad34  448d4014                 lea r8d, [rax + 0x14]
0071ad38  33c9                     xor ecx, ecx
0071ad3a  e8a1f70000               call 0x72a4e0
0071ad3f  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071ad42  488bcf                   mov rcx, rdi
0071ad45  0fb6d3                   movzx edx, bl
0071ad48  e8437bffff               call 0x712890
0071ad4d  0fb7d3                   movzx edx, bx
0071ad50  488bcf                   mov rcx, rdi
0071ad53  66c1ea08                 shr dx, 8
0071ad57  e8347bffff               call 0x712890
0071ad5c  c1eb10                   shr ebx, 0x10
0071ad5f  488bcf                   mov rcx, rdi
0071ad62  0fb6d3                   movzx edx, bl
0071ad65  e8267bffff               call 0x712890
0071ad6a  66c1eb08                 shr bx, 8
0071ad6e  488bcf                   mov rcx, rdi
0071ad71  0fb6d3                   movzx edx, bl
0071ad74  e8177bffff               call 0x712890
0071ad79  ba55000000               mov edx, 0x55
0071ad7e  488bcf                   mov rcx, rdi
0071ad81  e88a82ffff               call 0x713010
0071ad86  488b4750                 mov rax, qword ptr [rdi + 0x50]
0071ad8a  488d5530                 lea rdx, [rbp + 0x30]
0071ad8e  488bcf                   mov rcx, rdi
0071ad91  448b4804                 mov r9d, dword ptr [rax + 4]
0071ad95  448b00                   mov r8d, dword ptr [rax]
0071ad98  e8d387ffff               call 0x713570
0071ad9d  e94d010000               jmp 0x71aeef
0071ada2  41b818000000             mov r8d, 0x18
0071ada8  488bd6                   mov rdx, rsi
0071adab  488bcf                   mov rcx, rdi
0071adae  e8ed88ffff               call 0x7136a0
0071adb3  418bd7                   mov edx, r15d
0071adb6  488bcf                   mov rcx, rdi
0071adb9  e8d286ffff               call 0x713490
0071adbe  ba28000000               mov edx, 0x28
0071adc3  488bcf                   mov rcx, rdi
0071adc6  e84582ffff               call 0x713010
0071adcb  488b5708                 mov rdx, qword ptr [rdi + 8]
0071adcf  4c8d4d28                 lea r9, [rbp + 0x28]
0071add3  488b0f                   mov rcx, qword ptr [rdi]
0071add6  41b805000000             mov r8d, 5
0071addc  e8ef7ff9ff               call 0x6b2dd0
0071ade1  83f801                   cmp eax, 1
0071ade4  750d                     jne 0x71adf3
0071ade6  8bd0                     mov edx, eax
0071ade8  448d4014                 lea r8d, [rax + 0x14]
0071adec  33c9                     xor ecx, ecx
0071adee  e8edf60000               call 0x72a4e0
0071adf3  8b5d28                   mov ebx, dword ptr [rbp + 0x28]
0071adf6  488bcf                   mov rcx, rdi
0071adf9  0fb6d3                   movzx edx, bl
0071adfc  e88f7affff               call 0x712890
0071ae01  0fb7d3                   movzx edx, bx
0071ae04  488bcf                   mov rcx, rdi
0071ae07  66c1ea08                 shr dx, 8
0071ae0b  e8807affff               call 0x712890
0071ae10  c1eb10                   shr ebx, 0x10
0071ae13  488bcf                   mov rcx, rdi
0071ae16  0fb6d3                   movzx edx, bl
0071ae19  e8727affff               call 0x712890
0071ae1e  66c1eb08                 shr bx, 8
0071ae22  488bcf                   mov rcx, rdi
0071ae25  0fb6d3                   movzx edx, bl
0071ae28  e8637affff               call 0x712890
0071ae2d  ba55000000               mov edx, 0x55
0071ae32  488bcf                   mov rcx, rdi
0071ae35  e8d681ffff               call 0x713010
0071ae3a  4533c0                   xor r8d, r8d
0071ae3d  488bd6                   mov rdx, rsi
0071ae40  488bcf                   mov rcx, rdi
0071ae43  e86889ffff               call 0x7137b0
0071ae48  41b802000000             mov r8d, 2
0071ae4e  488bd6                   mov rdx, rsi
0071ae51  488bcf                   mov rcx, rdi
0071ae54  e84788ffff               call 0x7136a0
0071ae59  ba25000000               mov edx, 0x25
0071ae5e  488bcf                   mov rcx, rdi
0071ae61  e8aa81ffff               call 0x713010
0071ae66  ba48000000               mov edx, 0x48
0071ae6b  488bcf                   mov rcx, rdi
0071ae6e  e89d81ffff               call 0x713010
0071ae73  ba20000000               mov edx, 0x20
0071ae78  488bcf                   mov rcx, rdi
0071ae7b  e89081ffff               call 0x713010
0071ae80  33d2                     xor edx, edx
0071ae82  488bcf                   mov rcx, rdi
0071ae85  e8067affff               call 0x712890
0071ae8a  b208                     mov dl, 8
0071ae8c  488bcf                   mov rcx, rdi
0071ae8f  e8fc79ffff               call 0x712890
0071ae94  33d2                     xor edx, edx
0071ae96  488bcf                   mov rcx, rdi
0071ae99  e8f279ffff               call 0x712890
0071ae9e  33d2                     xor edx, edx
0071aea0  488bcf                   mov rcx, rdi
0071aea3  e8e879ffff               call 0x712890
0071aea8  ba60000000               mov edx, 0x60
0071aead  488bcf                   mov rcx, rdi
0071aeb0  e85b81ffff               call 0x713010
0071aeb5  ba53000000               mov edx, 0x53
0071aeba  488bcf                   mov rcx, rdi
0071aebd  e84e81ffff               call 0x713010
0071aec2  eb2b                     jmp 0x71aeef
0071aec4  488d0595dba301           lea rax, [rip + 0x1a3db95]
0071aecb  41b9ba140000             mov r9d, 0x14ba
0071aed1  4c8d050890df01           lea r8, [rip + 0x1df9008]
0071aed8  4889442420               mov qword ptr [rsp + 0x20], rax
0071aedd  488d153cb9df01           lea rdx, [rip + 0x1dfb93c]
0071aee4  b901000000               mov ecx, 1
0071aee9  ff1589ff7a01             call qword ptr [rip + 0x17aff89]
0071aeef  837e60ff                 cmp dword ptr [rsi + 0x60], -1
0071aef3  488b742448               mov rsi, qword ptr [rsp + 0x48]
0071aef8  4c8b742430               mov r14, qword ptr [rsp + 0x30]
0071aefd  4c8b6c2438               mov r13, qword ptr [rsp + 0x38]
0071af02  4c8b642440               mov r12, qword ptr [rsp + 0x40]
0071af07  488b5c2470               mov rbx, qword ptr [rsp + 0x70]
0071af0c  7513                     jne 0x71af21

; chunk at RVA 0x71af0e (109 bytes)
0071af0e  488b8780000000           mov rax, qword ptr [rdi + 0x80]
0071af15  418bcf                   mov ecx, r15d
0071af18  48c1e106                 shl rcx, 6
0071af1c  834c013c01               or dword ptr [rcx + rax + 0x3c], 1
0071af21  4883c450                 add rsp, 0x50
0071af25  415f                     pop r15
0071af27  5f                       pop rdi
0071af28  5d                       pop rbp
0071af29  c3                       ret
0071af2a  90                       nop
0071af2b  90                       nop
