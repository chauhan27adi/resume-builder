; CDecompressBatchLoader<Level2Batch,CLevel2Decompressor,CSeekPruneRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x974e50, 1452 bytes in 1 chunk(s)

; chunk at RVA 0x974e50 (1452 bytes)
00974e50  488bc4                   mov rax, rsp
00974e53  4c894820                 mov qword ptr [rax + 0x20], r9
00974e57  895010                   mov dword ptr [rax + 0x10], edx
00974e5a  55                       push rbp
00974e5b  56                       push rsi
00974e5c  57                       push rdi
00974e5d  4154                     push r12
00974e5f  4155                     push r13
00974e61  4156                     push r14
00974e63  4157                     push r15
00974e65  488d68a1                 lea rbp, [rax - 0x5f]
00974e69  4881ecd0000000           sub rsp, 0xd0
00974e70  48c74517feffffff         mov qword ptr [rbp + 0x17], 0xfffffffffffffffe
00974e78  48895818                 mov qword ptr [rax + 0x18], rbx
00974e7c  4d8be0                   mov r12, r8
00974e7f  448bfa                   mov r15d, edx
00974e82  488bd9                   mov rbx, rcx
00974e85  83792002                 cmp dword ptr [rcx + 0x20], 2
00974e89  7507                     jne 0x974e92
00974e8b  33c0                     xor eax, eax
00974e8d  e9ed040000               jmp 0x97537f
00974e92  33ff                     xor edi, edi
00974e94  897db7                   mov dword ptr [rbp - 0x49], edi
00974e97  48897dbf                 mov qword ptr [rbp - 0x41], rdi
00974e9b  40887dc7                 mov byte ptr [rbp - 0x39], dil
00974e9f  0f57c0                   xorps xmm0, xmm0
00974ea2  660f7f45d7               movdqa xmmword ptr [rbp - 0x29], xmm0
00974ea7  0f57c9                   xorps xmm1, xmm1
00974eaa  660f7f4de7               movdqa xmmword ptr [rbp - 0x19], xmm1
00974eaf  660f7f45f7               movdqa xmmword ptr [rbp - 9], xmm0
00974eb4  48897d07                 mov qword ptr [rbp + 7], rdi
00974eb8  c7450f01000000           mov dword ptr [rbp + 0xf], 1
00974ebf  897c2420                 mov dword ptr [rsp + 0x20], edi
00974ec3  32c9                     xor cl, cl
00974ec5  884d67                   mov byte ptr [rbp + 0x67], cl
00974ec8  4c8d2d31b168ff           lea r13, [rip - 0x974ecf]
00974ecf  41c644241000             mov byte ptr [r12 + 0x10], 0
00974ed5  80bbc81d000000           cmp byte ptr [rbx + 0x1dc8], 0
00974edc  747f                     je 0x974f5d
00974ede  c683c81d000000           mov byte ptr [rbx + 0x1dc8], 0
00974ee5  4c8b83c01d0000           mov r8, qword ptr [rbx + 0x1dc0]
00974eec  33d2                     xor edx, edx
00974eee  498bcc                   mov rcx, r12
00974ef1  e85a80ffff               call 0x96cf50
00974ef6  488b83c01d0000           mov rax, qword ptr [rbx + 0x1dc0]
00974efd  ff08                     dec dword ptr [rax]
00974eff  897db7                   mov dword ptr [rbp - 0x49], edi
00974f02  498b442408               mov rax, qword ptr [r12 + 8]
00974f07  488945bf                 mov qword ptr [rbp - 0x41], rax
00974f0b  418b1424                 mov edx, dword ptr [r12]
00974f0f  498b442420               mov rax, qword ptr [r12 + 0x20]
00974f14  488d0cd0                 lea rcx, [rax + rdx*8]
00974f18  48894dd7                 mov qword ptr [rbp - 0x29], rcx
00974f1c  498b442428               mov rax, qword ptr [r12 + 0x28]
00974f21  488d0c90                 lea rcx, [rax + rdx*4]
00974f25  48894ddf                 mov qword ptr [rbp - 0x21], rcx
00974f29  498b442430               mov rax, qword ptr [r12 + 0x30]
00974f2e  488d0c90                 lea rcx, [rax + rdx*4]
00974f32  48894de7                 mov qword ptr [rbp - 0x19], rcx
00974f36  b801000000               mov eax, 1
00974f3b  2bc2                     sub eax, edx
00974f3d  4403f8                   add r15d, eax
00974f40  44897d6f                 mov dword ptr [rbp + 0x6f], r15d
00974f44  488d75b7                 lea rsi, [rbp - 0x49]
00974f48  c683c81d000000           mov byte ptr [rbx + 0x1dc8], 0
00974f4f  c744242001000000         mov dword ptr [rsp + 0x20], 1
00974f57  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00974f5b  eb03                     jmp 0x974f60
00974f5d  498bf4                   mov rsi, r12
00974f60  837b2000                 cmp dword ptr [rbx + 0x20], 0
00974f64  0f85b7000000             jne 0x975021
00974f6a  48897c2428               mov qword ptr [rsp + 0x28], rdi
00974f6f  897d87                   mov dword ptr [rbp - 0x79], edi
00974f72  48897d8f                 mov qword ptr [rbp - 0x71], rdi
00974f76  897d97                   mov dword ptr [rbp - 0x69], edi
00974f79  48897d9f                 mov qword ptr [rbp - 0x61], rdi
00974f7d  897da7                   mov dword ptr [rbp - 0x59], edi
00974f80  66897dab                 mov word ptr [rbp - 0x55], di
00974f84  488d4b28                 lea rcx, [rbx + 0x28]
00974f88  488b01                   mov rax, qword ptr [rcx]
00974f8b  4d8bc1                   mov r8, r9
00974f8e  488d542428               lea rdx, [rsp + 0x28]
00974f93  ff10                     call qword ptr [rax]
00974f95  c6456701                 mov byte ptr [rbp + 0x67], 1
00974f99  3dc60e0400               cmp eax, 0x40ec6
00974f9e  0f84b8030000             je 0x97535c
00974fa4  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
00974fa9  48898b60090000           mov qword ptr [rbx + 0x960], rcx
00974fb0  8b4587                   mov eax, dword ptr [rbp - 0x79]
00974fb3  898358090000             mov dword ptr [rbx + 0x958], eax
00974fb9  48898b68090000           mov qword ptr [rbx + 0x968], rcx
00974fc0  4889bb50090000           mov qword ptr [rbx + 0x950], rdi
00974fc7  66c783180c00000000       mov word ptr [rbx + 0xc18], 0
00974fd0  4889bb100c0000           mov qword ptr [rbx + 0xc10], rdi
00974fd7  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
00974fdb  48898b300c0000           mov qword ptr [rbx + 0xc30], rcx
00974fe2  8b4597                   mov eax, dword ptr [rbp - 0x69]
00974fe5  8983280c0000             mov dword ptr [rbx + 0xc28], eax
00974feb  48898b380c0000           mov qword ptr [rbx + 0xc38], rcx
00974ff2  4889bb200c0000           mov qword ptr [rbx + 0xc20], rdi
00974ff9  4889bbac1d0000           mov qword ptr [rbx + 0x1dac], rdi
00975000  c783b41d000000000101     mov dword ptr [rbx + 0x1db4], 0x1010000
0097500a  c783a81d000001000000     mov dword ptr [rbx + 0x1da8], 1
00975014  89bba01c0000             mov dword ptr [rbx + 0x1ca0], edi
0097501a  c7432001000000           mov dword ptr [rbx + 0x20], 1
00975021  488b4330                 mov rax, qword ptr [rbx + 0x30]
00975025  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
0097502c  4c894608                 mov qword ptr [rsi + 8], r8
00975030  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00975037  488b5330                 mov rdx, qword ptr [rbx + 0x30]
0097503b  8b423c                   mov eax, dword ptr [rdx + 0x3c]
0097503e  83e007                   and eax, 7
00975041  83f805                   cmp eax, 5
00975044  7741                     ja 0x975087
00975046  4898                     cdqe
00975048  418b8c859c539700         mov ecx, dword ptr [r13 + rax*4 + 0x97539c]
00975050  4903cd                   add rcx, r13
00975053  ffe1                     jmp rcx
00975055  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975059  410f95c6                 setne r14b
0097505d  eb2b                     jmp 0x97508a
0097505f  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975063  410f9dc6                 setge r14b
00975067  eb21                     jmp 0x97508a
00975069  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097506d  410f9ec6                 setle r14b
00975071  eb17                     jmp 0x97508a
00975073  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975077  410f9fc6                 setg r14b
0097507b  eb0d                     jmp 0x97508a
0097507d  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975081  410f9cc6                 setl r14b
00975085  eb03                     jmp 0x97508a
00975087  4532f6                   xor r14b, r14b
0097508a  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00975091  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00975094  83e007                   and eax, 7
00975097  83f805                   cmp eax, 5
0097509a  7741                     ja 0x9750dd
0097509c  4898                     cdqe
0097509e  418b8c85b4539700         mov ecx, dword ptr [r13 + rax*4 + 0x9753b4]
009750a6  4903cd                   add rcx, r13
009750a9  ffe1                     jmp rcx
009750ab  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009750af  410f95c5                 setne r13b
009750b3  eb2b                     jmp 0x9750e0
009750b5  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009750b9  410f9dc5                 setge r13b
009750bd  eb21                     jmp 0x9750e0
009750bf  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009750c3  410f9ec5                 setle r13b
009750c7  eb17                     jmp 0x9750e0
009750c9  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009750cd  410f9fc5                 setg r13b
009750d1  eb0d                     jmp 0x9750e0
009750d3  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009750d7  410f9cc5                 setl r13b
009750db  eb03                     jmp 0x9750e0
009750dd  4532ed                   xor r13b, r13b
009750e0  48895d1f                 mov qword ptr [rbp + 0x1f], rbx
009750e4  0f31                     rdtsc
009750e6  48c1e220                 shl rdx, 0x20
009750ea  480bc2                   or rax, rdx
009750ed  48894308                 mov qword ptr [rbx + 8], rax
009750f1  488d8b48090000           lea rcx, [rbx + 0x948]
009750f8  4c8bc6                   mov r8, rsi
009750fb  418bd7                   mov edx, r15d
009750fe  e8ad8fffff               call 0x96e0b0
00975103  84c0                     test al, al
00975105  7503                     jne 0x97510a
00975107  897b20                   mov dword ptr [rbx + 0x20], edi
0097510a  8b06                     mov eax, dword ptr [rsi]
0097510c  48014310                 add qword ptr [rbx + 0x10], rax
00975110  0f31                     rdtsc
00975112  48c1e220                 shl rdx, 0x20
00975116  480bc2                   or rax, rdx
00975119  482b4308                 sub rax, qword ptr [rbx + 8]
0097511d  480103                   add qword ptr [rbx], rax
00975120  ff4318                   inc dword ptr [rbx + 0x18]
00975123  8b16                     mov edx, dword ptr [rsi]
00975125  448bc2                   mov r8d, edx
00975128  85d2                     test edx, edx
0097512a  0f84c9010000             je 0x9752f9
00975130  4584f6                   test r14b, r14b
00975133  7509                     jne 0x97513e
00975135  4584ed                   test r13b, r13b
00975138  0f84bb010000             je 0x9752f9
0097513e  448bca                   mov r9d, edx
00975141  4584f6                   test r14b, r14b
00975144  0f8485000000             je 0x9751cf
0097514a  448bd7                   mov r10d, edi
0097514d  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00975151  85d2                     test edx, edx
00975153  7473                     je 0x9751c8
00975155  4c8b7620                 mov r14, qword ptr [rsi + 0x20]
00975159  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
0097515d  4183e007                 and r8d, 7
00975161  4c8d3d98ae68ff           lea r15, [rip - 0x975168]
00975168  0f1f840000000000         nop dword ptr [rax + rax]
00975170  418bc2                   mov eax, r10d
00975173  4d8b0cc6                 mov r9, qword ptr [r14 + rax*8]
00975177  4183f805                 cmp r8d, 5
0097517b  0f87ad000000             ja 0x97522e
00975181  4963c0                   movsxd rax, r8d
00975184  418b8c87cc539700         mov ecx, dword ptr [r15 + rax*4 + 0x9753cc]
0097518c  4903cf                   add rcx, r15
0097518f  ffe1                     jmp rcx
00975191  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975195  0f94c0                   sete al
00975198  eb22                     jmp 0x9751bc
0097519a  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
0097519e  0f9cc0                   setl al
009751a1  eb19                     jmp 0x9751bc
009751a3  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009751a7  0f9fc0                   setg al
009751aa  eb10                     jmp 0x9751bc
009751ac  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009751b0  0f9ec0                   setle al
009751b3  eb07                     jmp 0x9751bc
009751b5  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009751b9  0f9dc0                   setge al
009751bc  84c0                     test al, al
009751be  756e                     jne 0x97522e
009751c0  41ffc2                   inc r10d
009751c3  443bd2                   cmp r10d, edx
009751c6  72a8                     jb 0x975170
009751c8  893e                     mov dword ptr [rsi], edi
009751ca  8bd7                     mov edx, edi
009751cc  448bcf                   mov r9d, edi
009751cf  458bc1                   mov r8d, r9d
009751d2  4584ed                   test r13b, r13b
009751d5  0f841e010000             je 0x9752f9
009751db  85d2                     test edx, edx
009751dd  0f8416010000             je 0x9752f9
009751e3  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
009751e7  4c8b7e20                 mov r15, qword ptr [rsi + 0x20]
009751eb  4c8d2d0eae68ff           lea r13, [rip - 0x9751f2]
009751f2  0f1f4000                 nop dword ptr [rax]
009751f6  66660f1f840000000000     nop word ptr [rax + rax]
00975200  458bd1                   mov r10d, r9d
00975203  ffca                     dec edx
00975205  448bca                   mov r9d, edx
00975208  4d8b34d7                 mov r14, qword ptr [r15 + rdx*8]
0097520c  418b434c                 mov eax, dword ptr [r11 + 0x4c]
00975210  83e007                   and eax, 7
00975213  458bc2                   mov r8d, r10d
00975216  83f805                   cmp eax, 5
00975219  0f87da000000             ja 0x9752f9
0097521f  4898                     cdqe
00975221  418b8c85e4539700         mov ecx, dword ptr [r13 + rax*4 + 0x9753e4]
00975229  4903cd                   add rcx, r13
0097522c  ffe1                     jmp rcx
0097522e  443bd2                   cmp r10d, edx
00975231  7395                     jae 0x9751c8
00975233  448bca                   mov r9d, edx
00975236  4585d2                   test r10d, r10d
00975239  7494                     je 0x9751cf
0097523b  452bca                   sub r9d, r10d
0097523e  8bd7                     mov edx, edi
00975240  7470                     je 0x9752b2
00975242  4c8bc7                   mov r8, rdi
00975245  4c8bdf                   mov r11, rdi
00975248  4c8bf7                   mov r14, rdi
0097524b  0f1f440000               nop dword ptr [rax + rax]
00975250  428d0412                 lea eax, [rdx + r10]
00975254  448bf8                   mov r15d, eax
00975257  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
0097525b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
0097525f  4989040e                 mov qword ptr [r14 + rcx], rax
00975263  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
00975267  428b04b9                 mov eax, dword ptr [rcx + r15*4]
0097526b  4189040b                 mov dword ptr [r11 + rcx], eax
0097526f  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
00975273  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00975277  4189040b                 mov dword ptr [r11 + rcx], eax
0097527b  4d03ff                   add r15, r15
0097527e  488b4638                 mov rax, qword ptr [rsi + 0x38]
00975282  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00975287  420f110400               movups xmmword ptr [rax + r8], xmm0
0097528c  488b4648                 mov rax, qword ptr [rsi + 0x48]
00975290  4885c0                   test rax, rax
00975293  740a                     je 0x97529f
00975295  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
0097529a  420f110400               movups xmmword ptr [rax + r8], xmm0
0097529f  ffc2                     inc edx
009752a1  4983c608                 add r14, 8
009752a5  4983c304                 add r11, 4
009752a9  4983c010                 add r8, 0x10
009752ad  413bd1                   cmp edx, r9d
009752b0  729e                     jb 0x975250
009752b2  44890e                   mov dword ptr [rsi], r9d
009752b5  418bd1                   mov edx, r9d
009752b8  e912ffffff               jmp 0x9751cf
009752bd  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
009752c1  0f94c0                   sete al
009752c4  eb22                     jmp 0x9752e8
009752c6  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
009752ca  0f9cc0                   setl al
009752cd  eb19                     jmp 0x9752e8
009752cf  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
009752d3  0f9fc0                   setg al
009752d6  eb10                     jmp 0x9752e8
009752d8  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
009752dc  0f9ec0                   setle al
009752df  eb07                     jmp 0x9752e8
009752e1  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
009752e5  0f9dc0                   setge al
009752e8  84c0                     test al, al
009752ea  750d                     jne 0x9752f9
009752ec  8916                     mov dword ptr [rsi], edx
009752ee  448bc2                   mov r8d, edx
009752f1  85d2                     test edx, edx
009752f3  0f8507ffffff             jne 0x975200
009752f9  80bbc91d000000           cmp byte ptr [rbx + 0x1dc9], 0
00975300  7440                     je 0x975342
00975302  448b06                   mov r8d, dword ptr [rsi]
00975305  4585c0                   test r8d, r8d
00975308  7438                     je 0x975342
0097530a  c683c81d000001           mov byte ptr [rbx + 0x1dc8], 1
00975311  8b16                     mov edx, dword ptr [rsi]
00975313  ffca                     dec edx
00975315  4c8bc6                   mov r8, rsi
00975318  488b8bc01d0000           mov rcx, qword ptr [rbx + 0x1dc0]
0097531f  e82c7cffff               call 0x96cf50
00975324  ff0e                     dec dword ptr [rsi]
00975326  41c644241001             mov byte ptr [r12 + 0x10], 1
0097532c  488b83c01d0000           mov rax, qword ptr [rbx + 0x1dc0]
00975333  488b4820                 mov rcx, qword ptr [rax + 0x20]
00975337  488b01                   mov rax, qword ptr [rcx]
0097533a  4989442418               mov qword ptr [r12 + 0x18], rax
0097533f  448b06                   mov r8d, dword ptr [rsi]
00975342  8b442420                 mov eax, dword ptr [rsp + 0x20]
00975346  4103c0                   add eax, r8d
00975349  89442420                 mov dword ptr [rsp + 0x20], eax
0097534d  7521                     jne 0x975370
0097534f  448b7d6f                 mov r15d, dword ptr [rbp + 0x6f]
00975353  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00975357  e96cfbffff               jmp 0x974ec8
0097535c  c7432002000000           mov dword ptr [rbx + 0x20], 2
00975363  41833c2400               cmp dword ptr [r12], 0
00975368  400f95c7                 setne dil
0097536c  8bc7                     mov eax, edi
0097536e  eb0f                     jmp 0x97537f
00975370  41890424                 mov dword ptr [r12], eax
00975374  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00975378  f6d9                     neg cl
0097537a  1bc0                     sbb eax, eax
0097537c  83c002                   add eax, 2
0097537f  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
00975387  4881c4d0000000           add rsp, 0xd0
0097538e  415f                     pop r15
00975390  415e                     pop r14
00975392  415d                     pop r13
00975394  415c                     pop r12
00975396  5f                       pop rdi
00975397  5e                       pop rsi
00975398  5d                       pop rbp
00975399  c3                       ret
0097539a  90                       nop
0097539b  90                       nop
0097539c  875097                   xchg dword ptr [rax - 0x69], edx
0097539f  005550                   add byte ptr [rbp + 0x50], dl
009753a2  97                       xchg edi, eax
009753a3  005f50                   add byte ptr [rdi + 0x50], bl
009753a6  97                       xchg edi, eax
009753a7  007350                   add byte ptr [rbx + 0x50], dh
009753aa  97                       xchg edi, eax
009753ab  006950                   add byte ptr [rcx + 0x50], ch
009753ae  97                       xchg edi, eax
009753af  007d50                   add byte ptr [rbp + 0x50], bh
009753b2  97                       xchg edi, eax
009753b3  00dd                     add ch, bl
009753b5  50                       push rax
009753b6  97                       xchg edi, eax
009753b7  00ab509700b5             add byte ptr [rbx - 0x4aff68b0], ch
009753bd  50                       push rax
009753be  97                       xchg edi, eax
009753bf  00c9                     add cl, cl
009753c1  50                       push rax
009753c2  97                       xchg edi, eax
009753c3  00bf509700d3             add byte ptr [rdi - 0x2cff68b0], bh
009753c9  50                       push rax
009753ca  97                       xchg edi, eax
009753cb  002e                     add byte ptr [rsi], ch
009753cd  52                       push rdx
009753ce  97                       xchg edi, eax
009753cf  00915197009a             add byte ptr [rcx - 0x65ff68af], dl
009753d5  51                       push rcx
009753d6  97                       xchg edi, eax
009753d7  00ac519700a351           add byte ptr [rcx + rdx*2 + 0x51a30097], ch
009753de  97                       xchg edi, eax
009753df  00b5519700f9             add byte ptr [rbp - 0x6ff68af], dh
009753e5  52                       push rdx
009753e6  97                       xchg edi, eax
009753e7  00bd529700c6             add byte ptr [rbp - 0x39ff68ae], bh
009753ed  52                       push rdx
009753ee  97                       xchg edi, eax
009753ef  00d8                     add al, bl
009753f1  52                       push rdx
009753f2  97                       xchg edi, eax
009753f3  00cf                     add bh, cl
009753f5  52                       push rdx
009753f6  97                       xchg edi, eax
009753f7  00e1                     add cl, ah
009753f9  52                       push rdx
009753fa  97                       xchg edi, eax
