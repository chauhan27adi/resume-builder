; CDecompressBatchLoader<Level2WithPidBatch,CLevel2WithPidDecompressor,CSeekPruneRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x975410, 1417 bytes in 3 chunk(s)

; chunk at RVA 0x975410 (57 bytes)
00975410  4c894c2420               mov qword ptr [rsp + 0x20], r9
00975415  89542410                 mov dword ptr [rsp + 0x10], edx
00975419  55                       push rbp
0097541a  57                       push rdi
0097541b  4155                     push r13
0097541d  4157                     push r15
0097541f  488d6c24c1               lea rbp, [rsp - 0x3f]
00975424  4881ece8000000           sub rsp, 0xe8
0097542b  83792002                 cmp dword ptr [rcx + 0x20], 2
0097542f  4d8be8                   mov r13, r8
00975432  8bfa                     mov edi, edx
00975434  4c8bf9                   mov r15, rcx
00975437  7510                     jne 0x975449
00975439  33c0                     xor eax, eax
0097543b  4881c4e8000000           add rsp, 0xe8
00975442  415f                     pop r15
00975444  415d                     pop r13
00975446  5f                       pop rdi
00975447  5d                       pop rbp
00975448  c3                       ret

; chunk at RVA 0x975449 (1264 bytes)
00975449  48899c2420010000         mov qword ptr [rsp + 0x120], rbx
00975451  0f57c0                   xorps xmm0, xmm0
00975454  4889b424e0000000         mov qword ptr [rsp + 0xe0], rsi
0097545c  0f57c9                   xorps xmm1, xmm1
0097545f  4c89a424d8000000         mov qword ptr [rsp + 0xd8], r12
00975467  4c89b424d0000000         mov qword ptr [rsp + 0xd0], r14
0097546f  4533f6                   xor r14d, r14d
00975472  32c9                     xor cl, cl
00975474  448975b7                 mov dword ptr [rbp - 0x49], r14d
00975478  884d67                   mov byte ptr [rbp + 0x67], cl
0097547b  4c8975bf                 mov qword ptr [rbp - 0x41], r14
0097547f  448875c7                 mov byte ptr [rbp - 0x39], r14b
00975483  660f7f45d7               movdqa xmmword ptr [rbp - 0x29], xmm0
00975488  660f7f4de7               movdqa xmmword ptr [rbp - 0x19], xmm1
0097548d  660f7f45f7               movdqa xmmword ptr [rbp - 9], xmm0
00975492  4c897507                 mov qword ptr [rbp + 7], r14
00975496  c7450f01000000           mov dword ptr [rbp + 0xf], 1
0097549d  4c897517                 mov qword ptr [rbp + 0x17], r14
009754a1  4489742420               mov dword ptr [rsp + 0x20], r14d
009754a6  45887510                 mov byte ptr [r13 + 0x10], r14b
009754aa  4c8d254fab68ff           lea r12, [rip - 0x9754b1]
009754b1  4538b7582e0000           cmp byte ptr [r15 + 0x2e58], r14b
009754b8  0f8495000000             je 0x975553
009754be  498b9f502e0000           mov rbx, qword ptr [r15 + 0x2e50]
009754c5  33d2                     xor edx, edx
009754c7  4c8bc3                   mov r8, rbx
009754ca  4588b7582e0000           mov byte ptr [r15 + 0x2e58], r14b
009754d1  498bcd                   mov rcx, r13
009754d4  e8777affff               call 0x96cf50
009754d9  488b5360                 mov rdx, qword ptr [rbx + 0x60]
009754dd  488d75b7                 lea rsi, [rbp - 0x49]
009754e1  418b4d00                 mov ecx, dword ptr [r13]
009754e5  498b4560                 mov rax, qword ptr [r13 + 0x60]
009754e9  ffc9                     dec ecx
009754eb  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009754ef  4803c9                   add rcx, rcx
009754f2  0f1002                   movups xmm0, xmmword ptr [rdx]
009754f5  448975b7                 mov dword ptr [rbp - 0x49], r14d
009754f9  c744242001000000         mov dword ptr [rsp + 0x20], 1
00975501  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
00975505  498b87502e0000           mov rax, qword ptr [r15 + 0x2e50]
0097550c  ff08                     dec dword ptr [rax]
0097550e  418b5500                 mov edx, dword ptr [r13]
00975512  498b4508                 mov rax, qword ptr [r13 + 8]
00975516  488945bf                 mov qword ptr [rbp - 0x41], rax
0097551a  498b4520                 mov rax, qword ptr [r13 + 0x20]
0097551e  488d0cd0                 lea rcx, [rax + rdx*8]
00975522  498b4528                 mov rax, qword ptr [r13 + 0x28]
00975526  48894dd7                 mov qword ptr [rbp - 0x29], rcx
0097552a  488d0c90                 lea rcx, [rax + rdx*4]
0097552e  498b4530                 mov rax, qword ptr [r13 + 0x30]
00975532  48894ddf                 mov qword ptr [rbp - 0x21], rcx
00975536  4588b7582e0000           mov byte ptr [r15 + 0x2e58], r14b
0097553d  488d0c90                 lea rcx, [rax + rdx*4]
00975541  b801000000               mov eax, 1
00975546  2bc2                     sub eax, edx
00975548  48894de7                 mov qword ptr [rbp - 0x19], rcx
0097554c  03f8                     add edi, eax
0097554e  897d6f                   mov dword ptr [rbp + 0x6f], edi
00975551  eb03                     jmp 0x975556
00975553  498bf5                   mov rsi, r13
00975556  45397720                 cmp dword ptr [r15 + 0x20], r14d
0097555a  7558                     jne 0x9755b4
0097555c  498b4728                 mov rax, qword ptr [r15 + 0x28]
00975560  498d4f28                 lea rcx, [r15 + 0x28]
00975564  4d8bc1                   mov r8, r9
00975567  4c89742428               mov qword ptr [rsp + 0x28], r14
0097556c  488d542428               lea rdx, [rsp + 0x28]
00975571  44897587                 mov dword ptr [rbp - 0x79], r14d
00975575  4c89758f                 mov qword ptr [rbp - 0x71], r14
00975579  44897597                 mov dword ptr [rbp - 0x69], r14d
0097557d  4c89759f                 mov qword ptr [rbp - 0x61], r14
00975581  448975a7                 mov dword ptr [rbp - 0x59], r14d
00975585  66448975ab               mov word ptr [rbp - 0x55], r14w
0097558a  c6456701                 mov byte ptr [rbp + 0x67], 1
0097558e  ff10                     call qword ptr [rax]
00975590  3dc60e0400               cmp eax, 0x40ec6
00975595  0f844c030000             je 0x9758e7
0097559b  498d8f48090000           lea rcx, [r15 + 0x948]
009755a2  488d542428               lea rdx, [rsp + 0x28]
009755a7  e80472f5ff               call 0x8cc7b0
009755ac  41c7472001000000         mov dword ptr [r15 + 0x20], 1
009755b4  498b4730                 mov rax, qword ptr [r15 + 0x30]
009755b8  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
009755bf  4c894608                 mov qword ptr [rsi + 8], r8
009755c3  498b5730                 mov rdx, qword ptr [r15 + 0x30]
009755c7  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
009755ce  8b423c                   mov eax, dword ptr [rdx + 0x3c]
009755d1  83e007                   and eax, 7
009755d4  83f805                   cmp eax, 5
009755d7  773c                     ja 0x975615
009755d9  4898                     cdqe
009755db  418b8c843c599700         mov ecx, dword ptr [r12 + rax*4 + 0x97593c]
009755e3  4903cc                   add rcx, r12
009755e6  ffe1                     jmp rcx
009755e8  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009755ec  0f95c3                   setne bl
009755ef  eb26                     jmp 0x975617
009755f1  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009755f5  0f9dc3                   setge bl
009755f8  eb1d                     jmp 0x975617
009755fa  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009755fe  0f9ec3                   setle bl
00975601  eb14                     jmp 0x975617
00975603  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975607  0f9fc3                   setg bl
0097560a  eb0b                     jmp 0x975617
0097560c  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00975610  0f9cc3                   setl bl
00975613  eb02                     jmp 0x975617
00975615  32db                     xor bl, bl
00975617  8b424c                   mov eax, dword ptr [rdx + 0x4c]
0097561a  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00975621  83e007                   and eax, 7
00975624  83f805                   cmp eax, 5
00975627  7741                     ja 0x97566a
00975629  4898                     cdqe
0097562b  418b8c8454599700         mov ecx, dword ptr [r12 + rax*4 + 0x975954]
00975633  4903cc                   add rcx, r12
00975636  ffe1                     jmp rcx
00975638  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097563c  410f95c4                 setne r12b
00975640  eb2b                     jmp 0x97566d
00975642  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975646  410f9dc4                 setge r12b
0097564a  eb21                     jmp 0x97566d
0097564c  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975650  410f9ec4                 setle r12b
00975654  eb17                     jmp 0x97566d
00975656  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097565a  410f9fc4                 setg r12b
0097565e  eb0d                     jmp 0x97566d
00975660  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00975664  410f9cc4                 setl r12b
00975668  eb03                     jmp 0x97566d
0097566a  4532e4                   xor r12b, r12b
0097566d  498d8f48090000           lea rcx, [r15 + 0x948]
00975674  4c8bc6                   mov r8, rsi
00975677  8bd7                     mov edx, edi
00975679  e8d28effff               call 0x96e550
0097567e  84c0                     test al, al
00975680  7504                     jne 0x975686
00975682  45897720                 mov dword ptr [r15 + 0x20], r14d
00975686  8b06                     mov eax, dword ptr [rsi]
00975688  448bc0                   mov r8d, eax
0097568b  85c0                     test eax, eax
0097568d  0f84d0010000             je 0x975863
00975693  84db                     test bl, bl
00975695  7509                     jne 0x9756a0
00975697  4584e4                   test r12b, r12b
0097569a  0f84c3010000             je 0x975863
009756a0  448bc8                   mov r9d, eax
009756a3  84db                     test bl, bl
009756a5  0f8485000000             je 0x975730
009756ab  4d8b5f30                 mov r11, qword ptr [r15 + 0x30]
009756af  458bd6                   mov r10d, r14d
009756b2  85c0                     test eax, eax
009756b4  7471                     je 0x975727
009756b6  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
009756ba  488d3d3fa968ff           lea rdi, [rip - 0x9756c1]
009756c1  488b5e20                 mov rbx, qword ptr [rsi + 0x20]
009756c5  4183e007                 and r8d, 7
009756c9  0f1f8000000000           nop dword ptr [rax]
009756d0  418bca                   mov ecx, r10d
009756d3  4c8b0ccb                 mov r9, qword ptr [rbx + rcx*8]
009756d7  4183f805                 cmp r8d, 5
009756db  0f87ae000000             ja 0x97578f
009756e1  4963c8                   movsxd rcx, r8d
009756e4  8b948f6c599700           mov edx, dword ptr [rdi + rcx*4 + 0x97596c]
009756eb  4803d7                   add rdx, rdi
009756ee  ffe2                     jmp rdx
009756f0  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009756f4  0f94c1                   sete cl
009756f7  eb22                     jmp 0x97571b
009756f9  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009756fd  0f9cc1                   setl cl
00975700  eb19                     jmp 0x97571b
00975702  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975706  0f9fc1                   setg cl
00975709  eb10                     jmp 0x97571b
0097570b  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
0097570f  0f9ec1                   setle cl
00975712  eb07                     jmp 0x97571b
00975714  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00975718  0f9dc1                   setge cl
0097571b  84c9                     test cl, cl
0097571d  7570                     jne 0x97578f
0097571f  41ffc2                   inc r10d
00975722  443bd0                   cmp r10d, eax
00975725  72a9                     jb 0x9756d0
00975727  448936                   mov dword ptr [rsi], r14d
0097572a  418bc6                   mov eax, r14d
0097572d  458bce                   mov r9d, r14d
00975730  458bc1                   mov r8d, r9d
00975733  4584e4                   test r12b, r12b
00975736  0f8427010000             je 0x975863
0097573c  85c0                     test eax, eax
0097573e  0f841f010000             je 0x975863
00975744  4d8b5f30                 mov r11, qword ptr [r15 + 0x30]
00975748  4c8d25b1a868ff           lea r12, [rip - 0x97574f]
0097574f  488b7e20                 mov rdi, qword ptr [rsi + 0x20]
00975753  0f1f4000                 nop dword ptr [rax]
00975757  660f1f840000000000       nop word ptr [rax + rax]
00975760  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00975764  ffc8                     dec eax
00975766  458bd1                   mov r10d, r9d
00975769  83e107                   and ecx, 7
0097576c  448bc8                   mov r9d, eax
0097576f  458bc2                   mov r8d, r10d
00975772  488b1cc7                 mov rbx, qword ptr [rdi + rax*8]
00975776  83f905                   cmp ecx, 5
00975779  0f87e4000000             ja 0x975863
0097577f  4863c9                   movsxd rcx, ecx
00975782  418b948c84599700         mov edx, dword ptr [r12 + rcx*4 + 0x975984]
0097578a  4903d4                   add rdx, r12
0097578d  ffe2                     jmp rdx
0097578f  443bd0                   cmp r10d, eax
00975792  7393                     jae 0x975727
00975794  448bc8                   mov r9d, eax
00975797  4585d2                   test r10d, r10d
0097579a  7494                     je 0x975730
0097579c  458bde                   mov r11d, r14d
0097579f  452bca                   sub r9d, r10d
009757a2  7478                     je 0x97581c
009757a4  498bd6                   mov rdx, r14
009757a7  498bde                   mov rbx, r14
009757aa  498bfe                   mov rdi, r14
009757ad  0f1f00                   nop dword ptr [rax]
009757b0  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
009757b4  438d0413                 lea eax, [r11 + r10]
009757b8  448bc0                   mov r8d, eax
009757bb  488b04c1                 mov rax, qword ptr [rcx + rax*8]
009757bf  4889040f                 mov qword ptr [rdi + rcx], rax
009757c3  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
009757c7  428b0481                 mov eax, dword ptr [rcx + r8*4]
009757cb  89040b                   mov dword ptr [rbx + rcx], eax
009757ce  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
009757d2  428b0481                 mov eax, dword ptr [rcx + r8*4]
009757d6  4d03c0                   add r8, r8
009757d9  89040b                   mov dword ptr [rbx + rcx], eax
009757dc  488b4638                 mov rax, qword ptr [rsi + 0x38]
009757e0  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
009757e5  0f110410                 movups xmmword ptr [rax + rdx], xmm0
009757e9  488b4648                 mov rax, qword ptr [rsi + 0x48]
009757ed  4885c0                   test rax, rax
009757f0  7409                     je 0x9757fb
009757f2  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
009757f7  0f110410                 movups xmmword ptr [rax + rdx], xmm0
009757fb  488b4660                 mov rax, qword ptr [rsi + 0x60]
009757ff  41ffc3                   inc r11d
00975802  4883c708                 add rdi, 8
00975806  4883c304                 add rbx, 4
0097580a  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
0097580f  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00975813  4883c210                 add rdx, 0x10
00975817  453bd9                   cmp r11d, r9d
0097581a  7294                     jb 0x9757b0
0097581c  44890e                   mov dword ptr [rsi], r9d
0097581f  418bc1                   mov eax, r9d
00975822  e909ffffff               jmp 0x975730
00975827  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097582b  0f94c1                   sete cl
0097582e  eb22                     jmp 0x975852
00975830  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975834  0f9cc1                   setl cl
00975837  eb19                     jmp 0x975852
00975839  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097583d  0f9fc1                   setg cl
00975840  eb10                     jmp 0x975852
00975842  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00975846  0f9ec1                   setle cl
00975849  eb07                     jmp 0x975852
0097584b  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
0097584f  0f9dc1                   setge cl
00975852  84c9                     test cl, cl
00975854  750d                     jne 0x975863
00975856  8906                     mov dword ptr [rsi], eax
00975858  448bc0                   mov r8d, eax
0097585b  85c0                     test eax, eax
0097585d  0f85fdfeffff             jne 0x975760
00975863  4538b7592e0000           cmp byte ptr [r15 + 0x2e59], r14b
0097586a  7462                     je 0x9758ce
0097586c  448b06                   mov r8d, dword ptr [rsi]
0097586f  4585c0                   test r8d, r8d
00975872  745a                     je 0x9758ce
00975874  498bbf502e0000           mov rdi, qword ptr [r15 + 0x2e50]
0097587b  4c8bc6                   mov r8, rsi
0097587e  41c687582e000001         mov byte ptr [r15 + 0x2e58], 1
00975886  488bcf                   mov rcx, rdi
00975889  8b1e                     mov ebx, dword ptr [rsi]
0097588b  ffcb                     dec ebx
0097588d  8bd3                     mov edx, ebx
0097588f  e8bc76ffff               call 0x96cf50
00975894  8b0f                     mov ecx, dword ptr [rdi]
00975896  488b4760                 mov rax, qword ptr [rdi + 0x60]
0097589a  ffc9                     dec ecx
0097589c  488b5660                 mov rdx, qword ptr [rsi + 0x60]
009758a0  4803c9                   add rcx, rcx
009758a3  448bc3                   mov r8d, ebx
009758a6  4d03c0                   add r8, r8
009758a9  420f1004c2               movups xmm0, xmmword ptr [rdx + r8*8]
009758ae  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
009758b2  ff0e                     dec dword ptr [rsi]
009758b4  41c6451001               mov byte ptr [r13 + 0x10], 1
009758b9  498b87502e0000           mov rax, qword ptr [r15 + 0x2e50]
009758c0  488b4820                 mov rcx, qword ptr [rax + 0x20]
009758c4  488b01                   mov rax, qword ptr [rcx]
009758c7  49894518                 mov qword ptr [r13 + 0x18], rax
009758cb  448b06                   mov r8d, dword ptr [rsi]
009758ce  8b442420                 mov eax, dword ptr [rsp + 0x20]
009758d2  4103c0                   add eax, r8d
009758d5  89442420                 mov dword ptr [rsp + 0x20], eax
009758d9  7521                     jne 0x9758fc
009758db  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
009758de  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009758e2  e9bffbffff               jmp 0x9754a6
009758e7  41c7472002000000         mov dword ptr [r15 + 0x20], 2
009758ef  45397500                 cmp dword ptr [r13], r14d
009758f3  410f95c6                 setne r14b
009758f7  418bc6                   mov eax, r14d
009758fa  eb0f                     jmp 0x97590b
009758fc  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00975900  f6d9                     neg cl
00975902  41894500                 mov dword ptr [r13], eax
00975906  1bc0                     sbb eax, eax
00975908  83c002                   add eax, 2
0097590b  4c8ba424d8000000         mov r12, qword ptr [rsp + 0xd8]
00975913  488bb424e0000000         mov rsi, qword ptr [rsp + 0xe0]
0097591b  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
00975923  4c8bb424d0000000         mov r14, qword ptr [rsp + 0xd0]
0097592b  4881c4e8000000           add rsp, 0xe8
00975932  415f                     pop r15
00975934  415d                     pop r13
00975936  5f                       pop rdi
00975937  5d                       pop rbp
00975938  c3                       ret

; chunk at RVA 0x97593c (96 bytes)
0097593c  15569700e8               adc eax, 0xe8009756
00975941  55                       push rbp
00975942  97                       xchg edi, eax
00975943  00f1                     add cl, dh
00975945  55                       push rbp
00975946  97                       xchg edi, eax
00975947  0003                     add byte ptr [rbx], al
00975949  56                       push rsi
0097594a  97                       xchg edi, eax
0097594b  00fa                     add dl, bh
0097594d  55                       push rbp
0097594e  97                       xchg edi, eax
0097594f  000c56                   add byte ptr [rsi + rdx*2], cl
00975952  97                       xchg edi, eax
00975953  006a56                   add byte ptr [rdx + 0x56], ch
00975956  97                       xchg edi, eax
00975957  0038                     add byte ptr [rax], bh
00975959  56                       push rsi
0097595a  97                       xchg edi, eax
0097595b  004256                   add byte ptr [rdx + 0x56], al
0097595e  97                       xchg edi, eax
0097595f  005656                   add byte ptr [rsi + 0x56], dl
00975962  97                       xchg edi, eax
00975963  004c5697                 add byte ptr [rsi + rdx*2 - 0x69], cl
00975967  006056                   add byte ptr [rax + 0x56], ah
0097596a  97                       xchg edi, eax
0097596b  008f579700f0             add byte ptr [rdi - 0xfff68a9], cl
00975971  56                       push rsi
00975972  97                       xchg edi, eax
00975973  00f9                     add cl, bh
00975975  56                       push rsi
00975976  97                       xchg edi, eax
00975977  000b                     add byte ptr [rbx], cl
00975979  57                       push rdi
0097597a  97                       xchg edi, eax
0097597b  0002                     add byte ptr [rdx], al
0097597d  57                       push rdi
0097597e  97                       xchg edi, eax
0097597f  001457                   add byte ptr [rdi + rdx*2], dl
00975982  97                       xchg edi, eax
00975983  006358                   add byte ptr [rbx + 0x58], ah
00975986  97                       xchg edi, eax
00975987  0027                     add byte ptr [rdi], ah
00975989  58                       pop rax
0097598a  97                       xchg edi, eax
0097598b  0030                     add byte ptr [rax], dh
0097598d  58                       pop rax
0097598e  97                       xchg edi, eax
0097598f  004258                   add byte ptr [rdx + 0x58], al
00975992  97                       xchg edi, eax
00975993  0039                     add byte ptr [rcx], bh
00975995  58                       pop rax
00975996  97                       xchg edi, eax
00975997  004b58                   add byte ptr [rbx + 0x58], cl
0097599a  97                       xchg edi, eax
