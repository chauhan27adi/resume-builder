; CConstraintProp::GetConjuncts
; sqllang.dll, primary RVA 0x70880, 224 bytes in 5 chunk(s)

; chunk at RVA 0x70880 (72 bytes)
00070880  48894c2408               mov qword ptr [rsp + 8], rcx
00070885  53                       push rbx
00070886  57                       push rdi
00070887  4155                     push r13
00070889  4157                     push r15
0007088b  4883ec38                 sub rsp, 0x38
0007088f  4c8bf9                   mov r15, rcx
00070892  488bda                   mov rbx, rdx
00070895  488d0ddcb6ab02           lea rcx, [rip + 0x2abb6dc]
0007089c  e88f5cffff               call 0x66530
000708a1  4533ed                   xor r13d, r13d
000708a4  488bf8                   mov rdi, rax
000708a7  ff00                     inc dword ptr [rax]
000708a9  83380a                   cmp dword ptr [rax], 0xa
000708ac  0f83a3e10800             jae 0xfea55
000708b2  498b7f10                 mov rdi, qword ptr [r15 + 0x10]
000708b6  488bcf                   mov rcx, rdi
000708b9  488b07                   mov rax, qword ptr [rdi]
000708bc  ff5018                   call qword ptr [rax + 0x18]
000708bf  83f859                   cmp eax, 0x59
000708c2  0f84d2600000             je 0x7699a

; chunk at RVA 0x769a4 (17 bytes)
000769a4  4c89642478               mov qword ptr [rsp + 0x78], r12
000769a9  418bfd                   mov edi, r13d
000769ac  458b6718                 mov r12d, dword ptr [r15 + 0x18]
000769b0  4585e4                   test r12d, r12d
000769b3  7477                     je 0x76a2c

; chunk at RVA 0x769b5 (119 bytes)
000769b5  48896c2468               mov qword ptr [rsp + 0x68], rbp
000769ba  4889742470               mov qword ptr [rsp + 0x70], rsi
000769bf  4c89742430               mov qword ptr [rsp + 0x30], r14
000769c4  0f1f00                   nop dword ptr [rax]
000769c7  660f1f840000000000       nop word ptr [rax + rax]
000769d0  498b4720                 mov rax, qword ptr [r15 + 0x20]
000769d4  4863cf                   movsxd rcx, edi
000769d7  488b2cc8                 mov rbp, qword ptr [rax + rcx*8]
000769db  488b7510                 mov rsi, qword ptr [rbp + 0x10]
000769df  488bce                   mov rcx, rsi
000769e2  488b06                   mov rax, qword ptr [rsi]
000769e5  ff5018                   call qword ptr [rax + 0x18]
000769e8  83f859                   cmp eax, 0x59
000769eb  0f84474d2f00             je 0x36b738
000769f1  8b7320                   mov esi, dword ptr [rbx + 0x20]
000769f4  4c396b28                 cmp qword ptr [rbx + 0x28], r13
000769f8  0f84d51c0600             je 0xd86d3
000769fe  8b431c                   mov eax, dword ptr [rbx + 0x1c]
00076a01  3bc6                     cmp eax, esi
00076a03  0f8367465501             jae 0x15cb070
00076a09  8bc8                     mov ecx, eax
00076a0b  488b4328                 mov rax, qword ptr [rbx + 0x28]
00076a0f  48892cc8                 mov qword ptr [rax + rcx*8], rbp
00076a13  ff431c                   inc dword ptr [rbx + 0x1c]
00076a16  ffc7                     inc edi
00076a18  413bfc                   cmp edi, r12d
00076a1b  72b3                     jb 0x769d0
00076a1d  4c8b742430               mov r14, qword ptr [rsp + 0x30]
00076a22  488b742470               mov rsi, qword ptr [rsp + 0x70]
00076a27  488b6c2468               mov rbp, qword ptr [rsp + 0x68]

; chunk at RVA 0x76a2c (5 bytes)
00076a2c  4c8b642478               mov r12, qword ptr [rsp + 0x78]

; chunk at RVA 0x76a31 (11 bytes)
00076a31  4883c438                 add rsp, 0x38
00076a35  415f                     pop r15
00076a37  415d                     pop r13
00076a39  5f                       pop rdi
00076a3a  5b                       pop rbx
00076a3b  c3                       ret
