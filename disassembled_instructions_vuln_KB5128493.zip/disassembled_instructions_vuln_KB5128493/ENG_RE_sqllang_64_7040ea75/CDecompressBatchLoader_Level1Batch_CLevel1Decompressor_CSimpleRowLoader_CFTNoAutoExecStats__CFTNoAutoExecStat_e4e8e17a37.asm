; CDecompressBatchLoader<Level1Batch,CLevel1Decompressor,CSimpleRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x96fda0, 1488 bytes in 3 chunk(s)

; chunk at RVA 0x96fda0 (47 bytes)
0096fda0  4c894c2420               mov qword ptr [rsp + 0x20], r9
0096fda5  89542410                 mov dword ptr [rsp + 0x10], edx
0096fda9  53                       push rbx
0096fdaa  4154                     push r12
0096fdac  4881ecb8000000           sub rsp, 0xb8
0096fdb3  83792002                 cmp dword ptr [rcx + 0x20], 2
0096fdb7  4d8be0                   mov r12, r8
0096fdba  448bd2                   mov r10d, edx
0096fdbd  488bd9                   mov rbx, rcx
0096fdc0  750d                     jne 0x96fdcf
0096fdc2  33c0                     xor eax, eax
0096fdc4  4881c4b8000000           add rsp, 0xb8
0096fdcb  415c                     pop r12
0096fdcd  5b                       pop rbx
0096fdce  c3                       ret

; chunk at RVA 0x96fdcf (1345 bytes)
0096fdcf  4889ac24e0000000         mov qword ptr [rsp + 0xe0], rbp
0096fdd7  0f57c0                   xorps xmm0, xmm0
0096fdda  4889b424b0000000         mov qword ptr [rsp + 0xb0], rsi
0096fde2  33f6                     xor esi, esi
0096fde4  4889bc24a8000000         mov qword ptr [rsp + 0xa8], rdi
0096fdec  32c0                     xor al, al
0096fdee  4c89ac24a0000000         mov qword ptr [rsp + 0xa0], r13
0096fdf6  448bee                   mov r13d, esi
0096fdf9  4c89b42498000000         mov qword ptr [rsp + 0x98], r14
0096fe01  888424d0000000           mov byte ptr [rsp + 0xd0], al
0096fe08  4c89bc2490000000         mov qword ptr [rsp + 0x90], r15
0096fe10  89742450                 mov dword ptr [rsp + 0x50], esi
0096fe14  4889742458               mov qword ptr [rsp + 0x58], rsi
0096fe19  4088742460               mov byte ptr [rsp + 0x60], sil
0096fe1e  f30f7f442470             movdqu xmmword ptr [rsp + 0x70], xmm0
0096fe24  4889b42480000000         mov qword ptr [rsp + 0x80], rsi
0096fe2c  4188742410               mov byte ptr [r12 + 0x10], sil
0096fe31  4c8d1dc80169ff           lea r11, [rip - 0x96fe38]
0096fe38  4038b318030000           cmp byte ptr [rbx + 0x318], sil
0096fe3f  0f84c8000000             je 0x96ff0d
0096fe45  4c8b8b10030000           mov r9, qword ptr [rbx + 0x310]
0096fe4c  488d7c2450               lea rdi, [rsp + 0x50]
0096fe51  4088b318030000           mov byte ptr [rbx + 0x318], sil
0096fe58  41bd01000000             mov r13d, 1
0096fe5e  41ff0424                 inc dword ptr [r12]
0096fe62  418b1424                 mov edx, dword ptr [r12]
0096fe66  4d8b4120                 mov r8, qword ptr [r9 + 0x20]
0096fe6a  ffca                     dec edx
0096fe6c  498b4c2420               mov rcx, qword ptr [r12 + 0x20]
0096fe71  89742450                 mov dword ptr [rsp + 0x50], esi
0096fe75  498b00                   mov rax, qword ptr [r8]
0096fe78  488904d1                 mov qword ptr [rcx + rdx*8], rax
0096fe7c  4d8b4130                 mov r8, qword ptr [r9 + 0x30]
0096fe80  418b1424                 mov edx, dword ptr [r12]
0096fe84  498b4c2430               mov rcx, qword ptr [r12 + 0x30]
0096fe89  ffca                     dec edx
0096fe8b  418b00                   mov eax, dword ptr [r8]
0096fe8e  890491                   mov dword ptr [rcx + rdx*4], eax
0096fe91  418b1424                 mov edx, dword ptr [r12]
0096fe95  4d8b4128                 mov r8, qword ptr [r9 + 0x28]
0096fe99  ffca                     dec edx
0096fe9b  498b4c2428               mov rcx, qword ptr [r12 + 0x28]
0096fea0  4c8b8c24e8000000         mov r9, qword ptr [rsp + 0xe8]
0096fea8  418b00                   mov eax, dword ptr [r8]
0096feab  890491                   mov dword ptr [rcx + rdx*4], eax
0096feae  488b8310030000           mov rax, qword ptr [rbx + 0x310]
0096feb5  ff08                     dec dword ptr [rax]
0096feb7  418b1424                 mov edx, dword ptr [r12]
0096febb  498b442408               mov rax, qword ptr [r12 + 8]
0096fec0  4889442458               mov qword ptr [rsp + 0x58], rax
0096fec5  498b442420               mov rax, qword ptr [r12 + 0x20]
0096feca  488d0cd0                 lea rcx, [rax + rdx*8]
0096fece  498b442428               mov rax, qword ptr [r12 + 0x28]
0096fed3  48894c2470               mov qword ptr [rsp + 0x70], rcx
0096fed8  488d0c90                 lea rcx, [rax + rdx*4]
0096fedc  498b442430               mov rax, qword ptr [r12 + 0x30]
0096fee1  48894c2478               mov qword ptr [rsp + 0x78], rcx
0096fee6  4088b318030000           mov byte ptr [rbx + 0x318], sil
0096feed  488d0c90                 lea rcx, [rax + rdx*4]
0096fef1  b801000000               mov eax, 1
0096fef6  2bc2                     sub eax, edx
0096fef8  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
0096ff00  4403d0                   add r10d, eax
0096ff03  44899424d8000000         mov dword ptr [rsp + 0xd8], r10d
0096ff0b  eb03                     jmp 0x96ff10
0096ff0d  498bfc                   mov rdi, r12
0096ff10  397320                   cmp dword ptr [rbx + 0x20], esi
0096ff13  0f8581000000             jne 0x96ff9a
0096ff19  488b4328                 mov rax, qword ptr [rbx + 0x28]
0096ff1d  488d4b28                 lea rcx, [rbx + 0x28]
0096ff21  4d8bc1                   mov r8, r9
0096ff24  4889742420               mov qword ptr [rsp + 0x20], rsi
0096ff29  488d542420               lea rdx, [rsp + 0x20]
0096ff2e  89742428                 mov dword ptr [rsp + 0x28], esi
0096ff32  4889742430               mov qword ptr [rsp + 0x30], rsi
0096ff37  89742438                 mov dword ptr [rsp + 0x38], esi
0096ff3b  4889742440               mov qword ptr [rsp + 0x40], rsi
0096ff40  89742448                 mov dword ptr [rsp + 0x48], esi
0096ff44  668974244c               mov word ptr [rsp + 0x4c], si
0096ff49  c68424d000000001         mov byte ptr [rsp + 0xd0], 1
0096ff51  ff10                     call qword ptr [rax]
0096ff53  3dc60e0400               cmp eax, 0x40ec6
0096ff58  0f8451030000             je 0x9702af
0096ff5e  488b4c2420               mov rcx, qword ptr [rsp + 0x20]
0096ff63  4c8d1d960069ff           lea r11, [rip - 0x96ff6a]
0096ff6a  8b442428                 mov eax, dword ptr [rsp + 0x28]
0096ff6e  448b9424d8000000         mov r10d, dword ptr [rsp + 0xd8]
0096ff76  48894b50                 mov qword ptr [rbx + 0x50], rcx
0096ff7a  48894b58                 mov qword ptr [rbx + 0x58], rcx
0096ff7e  894348                   mov dword ptr [rbx + 0x48], eax
0096ff81  48897340                 mov qword ptr [rbx + 0x40], rsi
0096ff85  6689b308030000           mov word ptr [rbx + 0x308], si
0096ff8c  4889b300030000           mov qword ptr [rbx + 0x300], rsi
0096ff93  c7432001000000           mov dword ptr [rbx + 0x20], 1
0096ff9a  488b4330                 mov rax, qword ptr [rbx + 0x30]
0096ff9e  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
0096ffa5  4c894708                 mov qword ptr [rdi + 8], r8
0096ffa9  488b5330                 mov rdx, qword ptr [rbx + 0x30]
0096ffad  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
0096ffb4  8b423c                   mov eax, dword ptr [rdx + 0x3c]
0096ffb7  83e007                   and eax, 7
0096ffba  83f805                   cmp eax, 5
0096ffbd  7741                     ja 0x970000
0096ffbf  4898                     cdqe
0096ffc1  418b8c8310039700         mov ecx, dword ptr [r11 + rax*4 + 0x970310]
0096ffc9  4903cb                   add rcx, r11
0096ffcc  ffe1                     jmp rcx
0096ffce  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096ffd2  400f95c5                 setne bpl
0096ffd6  eb2b                     jmp 0x970003
0096ffd8  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096ffdc  400f9dc5                 setge bpl
0096ffe0  eb21                     jmp 0x970003
0096ffe2  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096ffe6  400f9ec5                 setle bpl
0096ffea  eb17                     jmp 0x970003
0096ffec  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096fff0  400f9fc5                 setg bpl
0096fff4  eb0d                     jmp 0x970003
0096fff6  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0096fffa  400f9cc5                 setl bpl
0096fffe  eb03                     jmp 0x970003
00970000  4032ed                   xor bpl, bpl
00970003  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00970006  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
0097000d  83e007                   and eax, 7
00970010  83f805                   cmp eax, 5
00970013  7741                     ja 0x970056
00970015  4898                     cdqe
00970017  418b8c8328039700         mov ecx, dword ptr [r11 + rax*4 + 0x970328]
0097001f  4903cb                   add rcx, r11
00970022  ffe1                     jmp rcx
00970024  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00970028  410f95c7                 setne r15b
0097002c  eb2b                     jmp 0x970059
0097002e  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00970032  410f9dc7                 setge r15b
00970036  eb21                     jmp 0x970059
00970038  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097003c  410f9ec7                 setle r15b
00970040  eb17                     jmp 0x970059
00970042  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00970046  410f9fc7                 setg r15b
0097004a  eb0d                     jmp 0x970059
0097004c  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00970050  410f9cc7                 setl r15b
00970054  eb03                     jmp 0x970059
00970056  4532ff                   xor r15b, r15b
00970059  488d4b38                 lea rcx, [rbx + 0x38]
0097005d  4c8bc7                   mov r8, rdi
00970060  418bd2                   mov edx, r10d
00970063  e808dcffff               call 0x96dc70
00970068  84c0                     test al, al
0097006a  7503                     jne 0x97006f
0097006c  897320                   mov dword ptr [rbx + 0x20], esi
0097006f  8b07                     mov eax, dword ptr [rdi]
00970071  448bc8                   mov r9d, eax
00970074  85c0                     test eax, eax
00970076  0f8496010000             je 0x970212
0097007c  4084ed                   test bpl, bpl
0097007f  7509                     jne 0x97008a
00970081  4584ff                   test r15b, r15b
00970084  0f8488010000             je 0x970212
0097008a  448bc0                   mov r8d, eax
0097008d  4084ed                   test bpl, bpl
00970090  747c                     je 0x97010e
00970092  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00970096  448bce                   mov r9d, esi
00970099  85c0                     test eax, eax
0097009b  746a                     je 0x970107
0097009d  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
009700a1  488d2d58ff68ff           lea rbp, [rip - 0x9700a8]
009700a8  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
009700ac  4183e007                 and r8d, 7
009700b0  418bc9                   mov ecx, r9d
009700b3  4d8b14ce                 mov r10, qword ptr [r14 + rcx*8]
009700b7  4183f805                 cmp r8d, 5
009700bb  0f87ae000000             ja 0x97016f
009700c1  4963c8                   movsxd rcx, r8d
009700c4  8b948d40039700           mov edx, dword ptr [rbp + rcx*4 + 0x970340]
009700cb  4803d5                   add rdx, rbp
009700ce  ffe2                     jmp rdx
009700d0  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
009700d4  0f94c1                   sete cl
009700d7  eb22                     jmp 0x9700fb
009700d9  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
009700dd  0f9cc1                   setl cl
009700e0  eb19                     jmp 0x9700fb
009700e2  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
009700e6  0f9fc1                   setg cl
009700e9  eb10                     jmp 0x9700fb
009700eb  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
009700ef  0f9ec1                   setle cl
009700f2  eb07                     jmp 0x9700fb
009700f4  4d3b5330                 cmp r10, qword ptr [r11 + 0x30]
009700f8  0f9dc1                   setge cl
009700fb  84c9                     test cl, cl
009700fd  7570                     jne 0x97016f
009700ff  41ffc1                   inc r9d
00970102  443bc8                   cmp r9d, eax
00970105  72a9                     jb 0x9700b0
00970107  8937                     mov dword ptr [rdi], esi
00970109  8bc6                     mov eax, esi
0097010b  448bc6                   mov r8d, esi
0097010e  458bc8                   mov r9d, r8d
00970111  4584ff                   test r15b, r15b
00970114  0f84f8000000             je 0x970212
0097011a  85c0                     test eax, eax
0097011c  0f84f0000000             je 0x970212
00970122  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00970126  4c8d3dd3fe68ff           lea r15, [rip - 0x97012d]
0097012d  4c8b7720                 mov r14, qword ptr [rdi + 0x20]
00970131  0f1f4000                 nop dword ptr [rax]
00970135  6666660f1f840000000000   nop word ptr [rax + rax]
00970140  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00970144  ffc8                     dec eax
00970146  458bd0                   mov r10d, r8d
00970149  83e107                   and ecx, 7
0097014c  448bc0                   mov r8d, eax
0097014f  458bca                   mov r9d, r10d
00970152  498b2cc6                 mov rbp, qword ptr [r14 + rax*8]
00970156  83f905                   cmp ecx, 5
00970159  0f87b3000000             ja 0x970212
0097015f  4863c9                   movsxd rcx, ecx
00970162  418b948f58039700         mov edx, dword ptr [r15 + rcx*4 + 0x970358]
0097016a  4903d7                   add rdx, r15
0097016d  ffe2                     jmp rdx
0097016f  443bc8                   cmp r9d, eax
00970172  7393                     jae 0x970107
00970174  448bc0                   mov r8d, eax
00970177  4585c9                   test r9d, r9d
0097017a  7492                     je 0x97010e
0097017c  448bde                   mov r11d, esi
0097017f  452bc1                   sub r8d, r9d
00970182  7447                     je 0x9701cb
00970184  4c8bd6                   mov r10, rsi
00970187  4c8bf6                   mov r14, rsi
0097018a  660f1f440000             nop word ptr [rax + rax]
00970190  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00970194  438d040b                 lea eax, [r11 + r9]
00970198  8bd0                     mov edx, eax
0097019a  4d8d5204                 lea r10, [r10 + 4]
0097019e  41ffc3                   inc r11d
009701a1  4d8d7608                 lea r14, [r14 + 8]
009701a5  488b04c1                 mov rax, qword ptr [rcx + rax*8]
009701a9  4989440ef8               mov qword ptr [r14 + rcx - 8], rax
009701ae  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
009701b2  8b0491                   mov eax, dword ptr [rcx + rdx*4]
009701b5  4189440afc               mov dword ptr [r10 + rcx - 4], eax
009701ba  488b4f28                 mov rcx, qword ptr [rdi + 0x28]
009701be  8b0491                   mov eax, dword ptr [rcx + rdx*4]
009701c1  4189440afc               mov dword ptr [r10 + rcx - 4], eax
009701c6  453bd8                   cmp r11d, r8d
009701c9  72c5                     jb 0x970190
009701cb  448907                   mov dword ptr [rdi], r8d
009701ce  418bc0                   mov eax, r8d
009701d1  e938ffffff               jmp 0x97010e
009701d6  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
009701da  0f94c1                   sete cl
009701dd  eb22                     jmp 0x970201
009701df  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
009701e3  0f9cc1                   setl cl
009701e6  eb19                     jmp 0x970201
009701e8  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
009701ec  0f9fc1                   setg cl
009701ef  eb10                     jmp 0x970201
009701f1  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
009701f5  0f9ec1                   setle cl
009701f8  eb07                     jmp 0x970201
009701fa  493b6b40                 cmp rbp, qword ptr [r11 + 0x40]
009701fe  0f9dc1                   setge cl
00970201  84c9                     test cl, cl
00970203  750d                     jne 0x970212
00970205  8907                     mov dword ptr [rdi], eax
00970207  448bc8                   mov r9d, eax
0097020a  85c0                     test eax, eax
0097020c  0f852effffff             jne 0x970140
00970212  4038b319030000           cmp byte ptr [rbx + 0x319], sil
00970219  747a                     je 0x970295
0097021b  448b0f                   mov r9d, dword ptr [rdi]
0097021e  4585c9                   test r9d, r9d
00970221  7472                     je 0x970295
00970223  4c8b9310030000           mov r10, qword ptr [rbx + 0x310]
0097022a  c6831803000001           mov byte ptr [rbx + 0x318], 1
00970231  448b0f                   mov r9d, dword ptr [rdi]
00970234  41ffc9                   dec r9d
00970237  41ff02                   inc dword ptr [r10]
0097023a  418b12                   mov edx, dword ptr [r10]
0097023d  4c8b4720                 mov r8, qword ptr [rdi + 0x20]
00970241  ffca                     dec edx
00970243  498b4a20                 mov rcx, qword ptr [r10 + 0x20]
00970247  4b8b04c8                 mov rax, qword ptr [r8 + r9*8]
0097024b  488904d1                 mov qword ptr [rcx + rdx*8], rax
0097024f  418b12                   mov edx, dword ptr [r10]
00970252  4c8b4730                 mov r8, qword ptr [rdi + 0x30]
00970256  ffca                     dec edx
00970258  498b4a30                 mov rcx, qword ptr [r10 + 0x30]
0097025c  438b0488                 mov eax, dword ptr [r8 + r9*4]
00970260  890491                   mov dword ptr [rcx + rdx*4], eax
00970263  418b12                   mov edx, dword ptr [r10]
00970266  498b4a28                 mov rcx, qword ptr [r10 + 0x28]
0097026a  ffca                     dec edx
0097026c  4c8b4728                 mov r8, qword ptr [rdi + 0x28]
00970270  438b0488                 mov eax, dword ptr [r8 + r9*4]
00970274  890491                   mov dword ptr [rcx + rdx*4], eax
00970277  ff0f                     dec dword ptr [rdi]
00970279  41c644241001             mov byte ptr [r12 + 0x10], 1
0097027f  488b8310030000           mov rax, qword ptr [rbx + 0x310]
00970286  488b4820                 mov rcx, qword ptr [rax + 0x20]
0097028a  488b01                   mov rax, qword ptr [rcx]
0097028d  4989442418               mov qword ptr [r12 + 0x18], rax
00970292  448b0f                   mov r9d, dword ptr [rdi]
00970295  4503e9                   add r13d, r9d
00970298  7528                     jne 0x9702c2
0097029a  448b9424d8000000         mov r10d, dword ptr [rsp + 0xd8]
009702a2  4c8b8c24e8000000         mov r9, qword ptr [rsp + 0xe8]
009702aa  e97dfbffff               jmp 0x96fe2c
009702af  c7432002000000           mov dword ptr [rbx + 0x20], 2
009702b6  41393424                 cmp dword ptr [r12], esi
009702ba  400f95c6                 setne sil
009702be  8bc6                     mov eax, esi
009702c0  eb13                     jmp 0x9702d5
009702c2  0fb68424d0000000         movzx eax, byte ptr [rsp + 0xd0]
009702ca  f6d8                     neg al
009702cc  45892c24                 mov dword ptr [r12], r13d
009702d0  1bc0                     sbb eax, eax
009702d2  83c002                   add eax, 2
009702d5  4c8bb42498000000         mov r14, qword ptr [rsp + 0x98]
009702dd  4c8bac24a0000000         mov r13, qword ptr [rsp + 0xa0]
009702e5  488bbc24a8000000         mov rdi, qword ptr [rsp + 0xa8]
009702ed  488bb424b0000000         mov rsi, qword ptr [rsp + 0xb0]
009702f5  488bac24e0000000         mov rbp, qword ptr [rsp + 0xe0]
009702fd  4c8bbc2490000000         mov r15, qword ptr [rsp + 0x90]
00970305  4881c4b8000000           add rsp, 0xb8
0097030c  415c                     pop r12
0097030e  5b                       pop rbx
0097030f  c3                       ret

; chunk at RVA 0x970310 (96 bytes)
00970310  0000                     add byte ptr [rax], al
00970312  97                       xchg edi, eax
00970313  00ce                     add dh, cl
00970315  ff9600d8ff96             call qword ptr [rsi - 0x69002800]
0097031b  00ec                     add ah, ch
0097031d  ff9600e2ff96             call qword ptr [rsi - 0x69001e00]
00970323  00f6                     add dh, dh
00970325  ff9600560097             call qword ptr [rsi - 0x68ffaa00]
0097032b  002400                   add byte ptr [rax + rax], ah
0097032e  97                       xchg edi, eax
0097032f  002e                     add byte ptr [rsi], ch
00970331  009700420097             add byte ptr [rdi - 0x68ffbe00], dl
00970337  0038                     add byte ptr [rax], bh
00970339  0097004c0097             add byte ptr [rdi - 0x68ffb400], dl
0097033f  006f01                   add byte ptr [rdi + 1], ch
00970342  97                       xchg edi, eax
00970343  00d0                     add al, dl
00970345  009700d90097             add byte ptr [rdi - 0x68ff2700], dl
0097034b  00eb                     add bl, ch
0097034d  009700e20097             add byte ptr [rdi - 0x68ff1e00], dl
00970353  00f4                     add ah, dh
00970355  009700120297             add byte ptr [rdi - 0x68fdee00], dl
0097035b  00d6                     add dh, dl
0097035d  019700df0197             add dword ptr [rdi - 0x68fe2100], edx
00970363  00f1                     add cl, dh
00970365  019700e80197             add dword ptr [rdi - 0x68fe1800], edx
0097036b  00fa                     add dl, bh
