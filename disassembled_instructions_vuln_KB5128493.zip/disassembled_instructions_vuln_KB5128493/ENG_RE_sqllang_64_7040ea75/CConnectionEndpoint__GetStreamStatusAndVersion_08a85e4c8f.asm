; CConnectionEndpoint::GetStreamStatusAndVersion
; sqllang.dll, primary RVA 0x44ab60, 444 bytes in 1 chunk(s)

; chunk at RVA 0x44ab60 (444 bytes)
0044ab60  488bc4                   mov rax, rsp
0044ab63  4156                     push r14
0044ab65  4881ec80000000           sub rsp, 0x80
0044ab6c  48c740a8feffffff         mov qword ptr [rax - 0x58], 0xfffffffffffffffe
0044ab74  48895808                 mov qword ptr [rax + 8], rbx
0044ab78  48896810                 mov qword ptr [rax + 0x10], rbp
0044ab7c  48897018                 mov qword ptr [rax + 0x18], rsi
0044ab80  48897820                 mov qword ptr [rax + 0x20], rdi
0044ab84  4d8bf0                   mov r14, r8
0044ab87  488bda                   mov rbx, rdx
0044ab8a  488bf1                   mov rsi, rcx
0044ab8d  33ed                     xor ebp, ebp
0044ab8f  8968c0                   mov dword ptr [rax - 0x40], ebp
0044ab92  654c8b142558000000       mov r10, qword ptr gs:[0x58]
0044ab9b  488b05d603a801           mov rax, qword ptr [rip + 0x1a803d6]
0044aba2  448b08                   mov r9d, dword ptr [rax]
0044aba5  488b05d403a801           mov rax, qword ptr [rip + 0x1a803d4]
0044abac  8b38                     mov edi, dword ptr [rax]
0044abae  4b033cca                 add rdi, qword ptr [r10 + r9*8]
0044abb2  488b9700010000           mov rdx, qword ptr [rdi + 0x100]
0044abb9  4885d2                   test rdx, rdx
0044abbc  750f                     jne 0x44abcd
0044abbe  33c9                     xor ecx, ecx
0044abc0  ff15ca03a801             call qword ptr [rip + 0x1a803ca]
0044abc6  488b9700010000           mov rdx, qword ptr [rdi + 0x100]
0044abcd  4889542450               mov qword ptr [rsp + 0x50], rdx
0044abd2  8b8a68020000             mov ecx, dword ptr [rdx + 0x268]
0044abd8  8bc1                     mov eax, ecx
0044abda  83e001                   and eax, 1
0044abdd  83f001                   xor eax, 1
0044abe0  89442448                 mov dword ptr [rsp + 0x48], eax
0044abe4  83c901                   or ecx, 1
0044abe7  898a68020000             mov dword ptr [rdx + 0x268], ecx
0044abed  c744245870044000         mov dword ptr [rsp + 0x58], 0x400470
0044abf5  48896c2460               mov qword ptr [rsp + 0x60], rbp
0044abfa  48896c2470               mov qword ptr [rsp + 0x70], rbp
0044abff  48896c2468               mov qword ptr [rsp + 0x68], rbp
0044ac04  48896c2478               mov qword ptr [rsp + 0x78], rbp
0044ac09  488d8e98260000           lea rcx, [rsi + 0x2698]
0044ac10  48894c2438               mov qword ptr [rsp + 0x38], rcx
0044ac15  896c2440                 mov dword ptr [rsp + 0x40], ebp
0044ac19  4c8d4c2458               lea r9, [rsp + 0x58]
0044ac1e  bf01000000               mov edi, 1
0044ac23  41b8ffffffff             mov r8d, 0xffffffff
0044ac29  8bd7                     mov edx, edi
0044ac2b  e84089bbff               call 0x3570
0044ac30  8bcd                     mov ecx, ebp
0044ac32  85c0                     test eax, eax
0044ac34  0f44cf                   cmove ecx, edi
0044ac37  894c2440                 mov dword ptr [rsp + 0x40], ecx
0044ac3b  488b86804f0000           mov rax, qword ptr [rsi + 0x4f80]
0044ac42  498906                   mov qword ptr [r14], rax
0044ac45  8b8678260000             mov eax, dword ptr [rsi + 0x2678]
0044ac4b  ffc8                     dec eax
0044ac4d  83f806                   cmp eax, 6
0044ac50  773d                     ja 0x44ac8f
0044ac52  4898                     cdqe
0044ac54  488d15a553bbff           lea rdx, [rip - 0x44ac5b]
0044ac5b  8b8c8200ad4400           mov ecx, dword ptr [rdx + rax*4 + 0x44ad00]
0044ac62  4803ca                   add rcx, rdx
0044ac65  ffe1                     jmp rcx
0044ac67  c70303000000             mov dword ptr [rbx], 3
0044ac6d  eb49                     jmp 0x44acb8
0044ac6f  b804000000               mov eax, 4
0044ac74  b902000000               mov ecx, 2
0044ac79  80befc30000000           cmp byte ptr [rsi + 0x30fc], 0
0044ac80  0f44c1                   cmove eax, ecx
0044ac83  8903                     mov dword ptr [rbx], eax
0044ac85  eb31                     jmp 0x44acb8
0044ac87  c7030d000000             mov dword ptr [rbx], 0xd
0044ac8d  eb29                     jmp 0x44acb8
0044ac8f  488d05caddd001           lea rax, [rip + 0x1d0ddca]
0044ac96  4889442420               mov qword ptr [rsp + 0x20], rax
0044ac9b  41b9d7050000             mov r9d, 0x5d7
0044aca1  4c8d0578c20c02           lea r8, [rip + 0x20cc278]
0044aca8  488d1571bb0c02           lea rdx, [rip + 0x20cbb71]
0044acaf  8bcf                     mov ecx, edi
0044acb1  ff15c101a801             call qword ptr [rip + 0x1a801c1]
0044acb7  90                       nop
0044acb8  8b542440                 mov edx, dword ptr [rsp + 0x40]
0044acbc  85d2                     test edx, edx
0044acbe  740f                     je 0x44accf
0044acc0  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
0044acc5  ff159501a801             call qword ptr [rip + 0x1a80195]
0044accb  896c2440                 mov dword ptr [rsp + 0x40], ebp
0044accf  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
0044acd4  8b442448                 mov eax, dword ptr [rsp + 0x48]
0044acd8  f7d0                     not eax
0044acda  218168020000             and dword ptr [rcx + 0x268], eax
0044ace0  4c8d9c2480000000         lea r11, [rsp + 0x80]
0044ace8  498b5b10                 mov rbx, qword ptr [r11 + 0x10]
0044acec  498b6b18                 mov rbp, qword ptr [r11 + 0x18]
0044acf0  498b7320                 mov rsi, qword ptr [r11 + 0x20]
0044acf4  498b7b28                 mov rdi, qword ptr [r11 + 0x28]
0044acf8  498be3                   mov rsp, r11
0044acfb  415e                     pop r14
0044acfd  c3                       ret
0044acfe  6690                     nop
0044ad00  67ac                     lodsb al, byte ptr [esi]
0044ad02  440067ac                 add byte ptr [rdi - 0x54], r12b
0044ad06  440067ac                 add byte ptr [rdi - 0x54], r12b
0044ad0a  44006fac                 add byte ptr [rdi - 0x54], r13b
0044ad0e  440087ac440067           add byte ptr [rdi + 0x670044ac], r8b
0044ad15  ac                       lodsb al, byte ptr [rsi]
0044ad16  440067ac                 add byte ptr [rdi - 0x54], r12b
