; CEsCompFullCompile::ICacheCollation
; sqllang.dll, primary RVA 0x10bdc0, 178 bytes in 1 chunk(s)

; chunk at RVA 0x10bdc0 (178 bytes)
0010bdc0  4889542410               mov qword ptr [rsp + 0x10], rdx
0010bdc5  55                       push rbp
0010bdc6  56                       push rsi
0010bdc7  57                       push rdi
0010bdc8  4156                     push r14
0010bdca  4157                     push r15
0010bdcc  4883ec40                 sub rsp, 0x40
0010bdd0  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
0010bdd9  48895c2470               mov qword ptr [rsp + 0x70], rbx
0010bdde  418bd9                   mov ebx, r9d
0010bde1  498be8                   mov rbp, r8
0010bde4  4c8bfa                   mov r15, rdx
0010bde7  488bf9                   mov rdi, rcx
0010bdea  654c8b1c2558000000       mov r11, qword ptr gs:[0x58]
0010bdf3  488b057ef1db01           mov rax, qword ptr [rip + 0x1dbf17e]
0010bdfa  448b10                   mov r10d, dword ptr [rax]
0010bdfd  488b057cf1db01           mov rax, qword ptr [rip + 0x1dbf17c]
0010be04  8b00                     mov eax, dword ptr [rax]
0010be06  4b0304d3                 add rax, qword ptr [r11 + r10*8]
0010be0a  488b00                   mov rax, qword ptr [rax]
0010be0d  4c8b5050                 mov r10, qword ptr [rax + 0x50]
0010be11  410fb74a08               movzx ecx, word ptr [r10 + 8]
0010be16  ff150cffdb01             call qword ptr [rip + 0x1dbff0c]
0010be1c  8b00                     mov eax, dword ptr [rax]
0010be1e  394514                   cmp dword ptr [rbp + 0x14], eax
0010be21  0f8558290e00             jne 0x1ee77f
0010be27  85db                     test ebx, ebx
0010be29  0f853c850b00             jne 0x1c436b
0010be2f  0fb64500                 movzx eax, byte ptr [rbp]
0010be33  488d15c641efff           lea rdx, [rip - 0x10be3a]
0010be3a  0fb68c1010360202         movzx ecx, byte ptr [rax + rdx + 0x2023610]
0010be42  33db                     xor ebx, ebx
0010be44  8bc3                     mov eax, ebx
0010be46  38841100860502           cmp byte ptr [rcx + rdx + 0x2058600], al
0010be4d  0f95c0                   setne al
0010be50  8bf0                     mov esi, eax
0010be52  488b8788000000           mov rax, qword ptr [rdi + 0x88]
0010be59  48391cf0                 cmp qword ptr [rax + rsi*8], rbx
0010be5d  7468                     je 0x10bec7
0010be5f  8bc6                     mov eax, esi
0010be61  488b5c2470               mov rbx, qword ptr [rsp + 0x70]
0010be66  4883c440                 add rsp, 0x40
0010be6a  415f                     pop r15
0010be6c  415e                     pop r14
0010be6e  5f                       pop rdi
0010be6f  5e                       pop rsi
0010be70  5d                       pop rbp
0010be71  c3                       ret
