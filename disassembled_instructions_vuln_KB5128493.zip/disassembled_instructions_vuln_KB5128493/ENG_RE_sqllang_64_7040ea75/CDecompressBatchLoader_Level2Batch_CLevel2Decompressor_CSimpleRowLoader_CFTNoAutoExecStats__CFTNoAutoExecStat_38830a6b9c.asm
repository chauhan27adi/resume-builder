; CDecompressBatchLoader<Level2Batch,CLevel2Decompressor,CSimpleRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x972680, 1418 bytes in 3 chunk(s)

; chunk at RVA 0x972680 (58 bytes)
00972680  4c894c2420               mov qword ptr [rsp + 0x20], r9
00972685  89542410                 mov dword ptr [rsp + 0x10], edx
00972689  55                       push rbp
0097268a  53                       push rbx
0097268b  4154                     push r12
0097268d  4157                     push r15
0097268f  488d6c24c1               lea rbp, [rsp - 0x3f]
00972694  4881ecd8000000           sub rsp, 0xd8
0097269b  83792002                 cmp dword ptr [rcx + 0x20], 2
0097269f  4d8be0                   mov r12, r8
009726a2  448bfa                   mov r15d, edx
009726a5  488bd9                   mov rbx, rcx
009726a8  7510                     jne 0x9726ba
009726aa  33c0                     xor eax, eax
009726ac  4881c4d8000000           add rsp, 0xd8
009726b3  415f                     pop r15
009726b5  415c                     pop r12
009726b7  5b                       pop rbx
009726b8  5d                       pop rbp
009726b9  c3                       ret

; chunk at RVA 0x9726ba (1264 bytes)
009726ba  4889b42410010000         mov qword ptr [rsp + 0x110], rsi
009726c2  0f57c0                   xorps xmm0, xmm0
009726c5  4889bc24d0000000         mov qword ptr [rsp + 0xd0], rdi
009726cd  0f57c9                   xorps xmm1, xmm1
009726d0  33ff                     xor edi, edi
009726d2  4c89ac24c8000000         mov qword ptr [rsp + 0xc8], r13
009726da  32c9                     xor cl, cl
009726dc  4c89b424c0000000         mov qword ptr [rsp + 0xc0], r14
009726e4  884d67                   mov byte ptr [rbp + 0x67], cl
009726e7  897dc7                   mov dword ptr [rbp - 0x39], edi
009726ea  48897dcf                 mov qword ptr [rbp - 0x31], rdi
009726ee  40887dd7                 mov byte ptr [rbp - 0x29], dil
009726f2  660f7f45e7               movdqa xmmword ptr [rbp - 0x19], xmm0
009726f7  660f7f4df7               movdqa xmmword ptr [rbp - 9], xmm1
009726fc  660f7f4507               movdqa xmmword ptr [rbp + 7], xmm0
00972701  48897d17                 mov qword ptr [rbp + 0x17], rdi
00972705  c7451f01000000           mov dword ptr [rbp + 0x1f], 1
0097270c  897d87                   mov dword ptr [rbp - 0x79], edi
0097270f  41887c2410               mov byte ptr [r12 + 0x10], dil
00972714  4c8d2de5d868ff           lea r13, [rip - 0x97271b]
0097271b  4038bbb8140000           cmp byte ptr [rbx + 0x14b8], dil
00972722  747e                     je 0x9727a2
00972724  4c8b83b0140000           mov r8, qword ptr [rbx + 0x14b0]
0097272b  33d2                     xor edx, edx
0097272d  498bcc                   mov rcx, r12
00972730  4088bbb8140000           mov byte ptr [rbx + 0x14b8], dil
00972737  e814a8ffff               call 0x96cf50
0097273c  488b83b0140000           mov rax, qword ptr [rbx + 0x14b0]
00972743  488d75c7                 lea rsi, [rbp - 0x39]
00972747  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
0097274b  897dc7                   mov dword ptr [rbp - 0x39], edi
0097274e  c7458701000000           mov dword ptr [rbp - 0x79], 1
00972755  ff08                     dec dword ptr [rax]
00972757  418b1424                 mov edx, dword ptr [r12]
0097275b  498b442408               mov rax, qword ptr [r12 + 8]
00972760  488945cf                 mov qword ptr [rbp - 0x31], rax
00972764  498b442420               mov rax, qword ptr [r12 + 0x20]
00972769  488d0cd0                 lea rcx, [rax + rdx*8]
0097276d  498b442428               mov rax, qword ptr [r12 + 0x28]
00972772  48894de7                 mov qword ptr [rbp - 0x19], rcx
00972776  488d0c90                 lea rcx, [rax + rdx*4]
0097277a  498b442430               mov rax, qword ptr [r12 + 0x30]
0097277f  48894def                 mov qword ptr [rbp - 0x11], rcx
00972783  4088bbb8140000           mov byte ptr [rbx + 0x14b8], dil
0097278a  488d0c90                 lea rcx, [rax + rdx*4]
0097278e  b801000000               mov eax, 1
00972793  2bc2                     sub eax, edx
00972795  48894df7                 mov qword ptr [rbp - 9], rcx
00972799  4403f8                   add r15d, eax
0097279c  44897d6f                 mov dword ptr [rbp + 0x6f], r15d
009727a0  eb03                     jmp 0x9727a5
009727a2  498bf4                   mov rsi, r12
009727a5  397b20                   cmp dword ptr [rbx + 0x20], edi
009727a8  0f85a7000000             jne 0x972855
009727ae  488b4328                 mov rax, qword ptr [rbx + 0x28]
009727b2  488d4b28                 lea rcx, [rbx + 0x28]
009727b6  4d8bc1                   mov r8, r9
009727b9  48897d8f                 mov qword ptr [rbp - 0x71], rdi
009727bd  488d558f                 lea rdx, [rbp - 0x71]
009727c1  897d97                   mov dword ptr [rbp - 0x69], edi
009727c4  48897d9f                 mov qword ptr [rbp - 0x61], rdi
009727c8  897da7                   mov dword ptr [rbp - 0x59], edi
009727cb  48897daf                 mov qword ptr [rbp - 0x51], rdi
009727cf  897db7                   mov dword ptr [rbp - 0x49], edi
009727d2  66897dbb                 mov word ptr [rbp - 0x45], di
009727d6  c6456701                 mov byte ptr [rbp + 0x67], 1
009727da  ff10                     call qword ptr [rax]
009727dc  3dc60e0400               cmp eax, 0x40ec6
009727e1  0f8473030000             je 0x972b5a
009727e7  488b4d8f                 mov rcx, qword ptr [rbp - 0x71]
009727eb  8b4597                   mov eax, dword ptr [rbp - 0x69]
009727ee  48894b50                 mov qword ptr [rbx + 0x50], rcx
009727f2  48894b58                 mov qword ptr [rbx + 0x58], rcx
009727f6  488b4d9f                 mov rcx, qword ptr [rbp - 0x61]
009727fa  894348                   mov dword ptr [rbx + 0x48], eax
009727fd  8b45a7                   mov eax, dword ptr [rbp - 0x59]
00972800  48898b20030000           mov qword ptr [rbx + 0x320], rcx
00972807  48898b28030000           mov qword ptr [rbx + 0x328], rcx
0097280e  48897b40                 mov qword ptr [rbx + 0x40], rdi
00972812  6689bb08030000           mov word ptr [rbx + 0x308], di
00972819  4889bb00030000           mov qword ptr [rbx + 0x300], rdi
00972820  898318030000             mov dword ptr [rbx + 0x318], eax
00972826  4889bb10030000           mov qword ptr [rbx + 0x310], rdi
0097282d  4889bb9c140000           mov qword ptr [rbx + 0x149c], rdi
00972834  c783a414000000000101     mov dword ptr [rbx + 0x14a4], 0x1010000
0097283e  c7839814000001000000     mov dword ptr [rbx + 0x1498], 1
00972848  89bb90130000             mov dword ptr [rbx + 0x1390], edi
0097284e  c7432001000000           mov dword ptr [rbx + 0x20], 1
00972855  488b4330                 mov rax, qword ptr [rbx + 0x30]
00972859  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
00972860  4c894608                 mov qword ptr [rsi + 8], r8
00972864  488b5330                 mov rdx, qword ptr [rbx + 0x30]
00972868  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
0097286f  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00972872  83e007                   and eax, 7
00972875  83f805                   cmp eax, 5
00972878  7741                     ja 0x9728bb
0097287a  4898                     cdqe
0097287c  418b8c85ac2b9700         mov ecx, dword ptr [r13 + rax*4 + 0x972bac]
00972884  4903cd                   add rcx, r13
00972887  ffe1                     jmp rcx
00972889  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097288d  410f95c6                 setne r14b
00972891  eb2b                     jmp 0x9728be
00972893  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00972897  410f9dc6                 setge r14b
0097289b  eb21                     jmp 0x9728be
0097289d  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009728a1  410f9ec6                 setle r14b
009728a5  eb17                     jmp 0x9728be
009728a7  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009728ab  410f9fc6                 setg r14b
009728af  eb0d                     jmp 0x9728be
009728b1  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009728b5  410f9cc6                 setl r14b
009728b9  eb03                     jmp 0x9728be
009728bb  4532f6                   xor r14b, r14b
009728be  8b424c                   mov eax, dword ptr [rdx + 0x4c]
009728c1  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
009728c8  83e007                   and eax, 7
009728cb  83f805                   cmp eax, 5
009728ce  7741                     ja 0x972911
009728d0  4898                     cdqe
009728d2  418b8c85c42b9700         mov ecx, dword ptr [r13 + rax*4 + 0x972bc4]
009728da  4903cd                   add rcx, r13
009728dd  ffe1                     jmp rcx
009728df  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009728e3  410f95c5                 setne r13b
009728e7  eb2b                     jmp 0x972914
009728e9  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009728ed  410f9dc5                 setge r13b
009728f1  eb21                     jmp 0x972914
009728f3  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009728f7  410f9ec5                 setle r13b
009728fb  eb17                     jmp 0x972914
009728fd  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00972901  410f9fc5                 setg r13b
00972905  eb0d                     jmp 0x972914
00972907  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097290b  410f9cc5                 setl r13b
0097290f  eb03                     jmp 0x972914
00972911  4532ed                   xor r13b, r13b
00972914  488d4b38                 lea rcx, [rbx + 0x38]
00972918  4c8bc6                   mov r8, rsi
0097291b  418bd7                   mov edx, r15d
0097291e  e88db7ffff               call 0x96e0b0
00972923  84c0                     test al, al
00972925  7503                     jne 0x97292a
00972927  897b20                   mov dword ptr [rbx + 0x20], edi
0097292a  8b16                     mov edx, dword ptr [rsi]
0097292c  448bc2                   mov r8d, edx
0097292f  85d2                     test edx, edx
00972931  0f84c2010000             je 0x972af9
00972937  4584f6                   test r14b, r14b
0097293a  7509                     jne 0x972945
0097293c  4584ed                   test r13b, r13b
0097293f  0f84b4010000             je 0x972af9
00972945  448bca                   mov r9d, edx
00972948  4584f6                   test r14b, r14b
0097294b  0f847e000000             je 0x9729cf
00972951  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00972955  448bd7                   mov r10d, edi
00972958  85d2                     test edx, edx
0097295a  746c                     je 0x9729c8
0097295c  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00972960  4c8d3d99d668ff           lea r15, [rip - 0x972967]
00972967  4c8b7620                 mov r14, qword ptr [rsi + 0x20]
0097296b  4183e007                 and r8d, 7
0097296f  90                       nop
00972970  418bc2                   mov eax, r10d
00972973  4d8b0cc6                 mov r9, qword ptr [r14 + rax*8]
00972977  4183f805                 cmp r8d, 5
0097297b  0f87ad000000             ja 0x972a2e
00972981  4963c0                   movsxd rax, r8d
00972984  418b8c87dc2b9700         mov ecx, dword ptr [r15 + rax*4 + 0x972bdc]
0097298c  4903cf                   add rcx, r15
0097298f  ffe1                     jmp rcx
00972991  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00972995  0f94c0                   sete al
00972998  eb22                     jmp 0x9729bc
0097299a  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
0097299e  0f9cc0                   setl al
009729a1  eb19                     jmp 0x9729bc
009729a3  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009729a7  0f9fc0                   setg al
009729aa  eb10                     jmp 0x9729bc
009729ac  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009729b0  0f9ec0                   setle al
009729b3  eb07                     jmp 0x9729bc
009729b5  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009729b9  0f9dc0                   setge al
009729bc  84c0                     test al, al
009729be  756e                     jne 0x972a2e
009729c0  41ffc2                   inc r10d
009729c3  443bd2                   cmp r10d, edx
009729c6  72a8                     jb 0x972970
009729c8  893e                     mov dword ptr [rsi], edi
009729ca  8bd7                     mov edx, edi
009729cc  448bcf                   mov r9d, edi
009729cf  458bc1                   mov r8d, r9d
009729d2  4584ed                   test r13b, r13b
009729d5  0f841e010000             je 0x972af9
009729db  85d2                     test edx, edx
009729dd  0f8416010000             je 0x972af9
009729e3  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
009729e7  4c8d2d12d668ff           lea r13, [rip - 0x9729ee]
009729ee  4c8b7e20                 mov r15, qword ptr [rsi + 0x20]
009729f2  0f1f4000                 nop dword ptr [rax]
009729f6  66660f1f840000000000     nop word ptr [rax + rax]
00972a00  418b434c                 mov eax, dword ptr [r11 + 0x4c]
00972a04  ffca                     dec edx
00972a06  458bd1                   mov r10d, r9d
00972a09  83e007                   and eax, 7
00972a0c  448bca                   mov r9d, edx
00972a0f  458bc2                   mov r8d, r10d
00972a12  4d8b34d7                 mov r14, qword ptr [r15 + rdx*8]
00972a16  83f805                   cmp eax, 5
00972a19  0f87da000000             ja 0x972af9
00972a1f  4898                     cdqe
00972a21  418b8c85f42b9700         mov ecx, dword ptr [r13 + rax*4 + 0x972bf4]
00972a29  4903cd                   add rcx, r13
00972a2c  ffe1                     jmp rcx
00972a2e  443bd2                   cmp r10d, edx
00972a31  7395                     jae 0x9729c8
00972a33  448bca                   mov r9d, edx
00972a36  4585d2                   test r10d, r10d
00972a39  7494                     je 0x9729cf
00972a3b  8bd7                     mov edx, edi
00972a3d  452bca                   sub r9d, r10d
00972a40  7470                     je 0x972ab2
00972a42  4c8bc7                   mov r8, rdi
00972a45  4c8bdf                   mov r11, rdi
00972a48  4c8bf7                   mov r14, rdi
00972a4b  0f1f440000               nop dword ptr [rax + rax]
00972a50  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00972a54  428d0412                 lea eax, [rdx + r10]
00972a58  448bf8                   mov r15d, eax
00972a5b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
00972a5f  4989040e                 mov qword ptr [r14 + rcx], rax
00972a63  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
00972a67  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00972a6b  4189040b                 mov dword ptr [r11 + rcx], eax
00972a6f  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
00972a73  428b04b9                 mov eax, dword ptr [rcx + r15*4]
00972a77  4d03ff                   add r15, r15
00972a7a  4189040b                 mov dword ptr [r11 + rcx], eax
00972a7e  488b4638                 mov rax, qword ptr [rsi + 0x38]
00972a82  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00972a87  420f110400               movups xmmword ptr [rax + r8], xmm0
00972a8c  488b4648                 mov rax, qword ptr [rsi + 0x48]
00972a90  4885c0                   test rax, rax
00972a93  740a                     je 0x972a9f
00972a95  420f1004f8               movups xmm0, xmmword ptr [rax + r15*8]
00972a9a  420f110400               movups xmmword ptr [rax + r8], xmm0
00972a9f  ffc2                     inc edx
00972aa1  4983c608                 add r14, 8
00972aa5  4983c304                 add r11, 4
00972aa9  4983c010                 add r8, 0x10
00972aad  413bd1                   cmp edx, r9d
00972ab0  729e                     jb 0x972a50
00972ab2  44890e                   mov dword ptr [rsi], r9d
00972ab5  418bd1                   mov edx, r9d
00972ab8  e912ffffff               jmp 0x9729cf
00972abd  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972ac1  0f94c0                   sete al
00972ac4  eb22                     jmp 0x972ae8
00972ac6  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972aca  0f9cc0                   setl al
00972acd  eb19                     jmp 0x972ae8
00972acf  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972ad3  0f9fc0                   setg al
00972ad6  eb10                     jmp 0x972ae8
00972ad8  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972adc  0f9ec0                   setle al
00972adf  eb07                     jmp 0x972ae8
00972ae1  4d3b7340                 cmp r14, qword ptr [r11 + 0x40]
00972ae5  0f9dc0                   setge al
00972ae8  84c0                     test al, al
00972aea  750d                     jne 0x972af9
00972aec  8916                     mov dword ptr [rsi], edx
00972aee  448bc2                   mov r8d, edx
00972af1  85d2                     test edx, edx
00972af3  0f8507ffffff             jne 0x972a00
00972af9  4038bbb9140000           cmp byte ptr [rbx + 0x14b9], dil
00972b00  7440                     je 0x972b42
00972b02  448b06                   mov r8d, dword ptr [rsi]
00972b05  4585c0                   test r8d, r8d
00972b08  7438                     je 0x972b42
00972b0a  488b8bb0140000           mov rcx, qword ptr [rbx + 0x14b0]
00972b11  4c8bc6                   mov r8, rsi
00972b14  c683b814000001           mov byte ptr [rbx + 0x14b8], 1
00972b1b  8b16                     mov edx, dword ptr [rsi]
00972b1d  ffca                     dec edx
00972b1f  e82ca4ffff               call 0x96cf50
00972b24  ff0e                     dec dword ptr [rsi]
00972b26  41c644241001             mov byte ptr [r12 + 0x10], 1
00972b2c  488b83b0140000           mov rax, qword ptr [rbx + 0x14b0]
00972b33  488b4820                 mov rcx, qword ptr [rax + 0x20]
00972b37  488b01                   mov rax, qword ptr [rcx]
00972b3a  4989442418               mov qword ptr [r12 + 0x18], rax
00972b3f  448b06                   mov r8d, dword ptr [rsi]
00972b42  8b4587                   mov eax, dword ptr [rbp - 0x79]
00972b45  4103c0                   add eax, r8d
00972b48  894587                   mov dword ptr [rbp - 0x79], eax
00972b4b  7520                     jne 0x972b6d
00972b4d  448b7d6f                 mov r15d, dword ptr [rbp + 0x6f]
00972b51  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00972b55  e9b5fbffff               jmp 0x97270f
00972b5a  c7432002000000           mov dword ptr [rbx + 0x20], 2
00972b61  41393c24                 cmp dword ptr [r12], edi
00972b65  400f95c7                 setne dil
00972b69  8bc7                     mov eax, edi
00972b6b  eb0f                     jmp 0x972b7c
00972b6d  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00972b71  f6d9                     neg cl
00972b73  41890424                 mov dword ptr [r12], eax
00972b77  1bc0                     sbb eax, eax
00972b79  83c002                   add eax, 2
00972b7c  4c8bac24c8000000         mov r13, qword ptr [rsp + 0xc8]
00972b84  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00972b8c  488bb42410010000         mov rsi, qword ptr [rsp + 0x110]
00972b94  4c8bb424c0000000         mov r14, qword ptr [rsp + 0xc0]
00972b9c  4881c4d8000000           add rsp, 0xd8
00972ba3  415f                     pop r15
00972ba5  415c                     pop r12
00972ba7  5b                       pop rbx
00972ba8  5d                       pop rbp
00972ba9  c3                       ret

; chunk at RVA 0x972bac (96 bytes)
00972bac  bb28970089               mov ebx, 0x89009728
00972bb1  289700932897             sub byte ptr [rdi - 0x68d76d00], dl
00972bb7  00a72897009d             add byte ptr [rdi - 0x62ff68d8], ah
00972bbd  289700b12897             sub byte ptr [rdi - 0x68d74f00], dl
00972bc3  0011                     add byte ptr [rcx], dl
00972bc5  299700df2897             sub dword ptr [rdi - 0x68d72100], edx
00972bcb  00e9                     add cl, ch
00972bcd  289700fd2897             sub byte ptr [rdi - 0x68d70300], dl
00972bd3  00f3                     add bl, dh
00972bd5  289700072997             sub byte ptr [rdi - 0x68d6f900], dl
00972bdb  002e                     add byte ptr [rsi], ch
00972bdd  2a9700912997             sub dl, byte ptr [rdi - 0x68d66f00]
00972be3  009a299700ac             add byte ptr [rdx - 0x53ff68d7], bl
00972be9  299700a32997             sub dword ptr [rdi - 0x68d65d00], edx
00972bef  00b5299700f9             add byte ptr [rbp - 0x6ff68d7], dh
00972bf5  2a9700bd2a97             sub dl, byte ptr [rdi - 0x68d54300]
00972bfb  00c6                     add dh, al
00972bfd  2a9700d82a97             sub dl, byte ptr [rdi - 0x68d52800]
00972c03  00cf                     add bh, cl
00972c05  2a9700e12a97             sub dl, byte ptr [rdi - 0x68d51f00]
