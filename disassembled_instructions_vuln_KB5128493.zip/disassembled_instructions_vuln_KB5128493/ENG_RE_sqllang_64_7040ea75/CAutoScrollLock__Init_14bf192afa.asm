; CAutoScrollLock::Init
; sqllang.dll, primary RVA 0x45690, 215 bytes in 1 chunk(s)

; chunk at RVA 0x45690 (215 bytes)
00045690  48895c2408               mov qword ptr [rsp + 8], rbx
00045695  4889742410               mov qword ptr [rsp + 0x10], rsi
0004569a  48897c2418               mov qword ptr [rsp + 0x18], rdi
0004569f  4156                     push r14
000456a1  4883ec20                 sub rsp, 0x20
000456a5  488b02                   mov rax, qword ptr [rdx]
000456a8  488bd9                   mov rbx, rcx
000456ab  488bca                   mov rcx, rdx
000456ae  418bf1                   mov esi, r9d
000456b1  418bf8                   mov edi, r8d
000456b4  4c8bf2                   mov r14, rdx
000456b7  ff90f8000000             call qword ptr [rax + 0xf8]
000456bd  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000456c2  4c895318                 mov qword ptr [rbx + 0x18], r10
000456c6  488903                   mov qword ptr [rbx], rax
000456c9  c7431000000000           mov dword ptr [rbx + 0x10], 0
000456d0  4885c0                   test rax, rax
000456d3  0f847b060000             je 0x45d54
000456d9  85f6                     test esi, esi
000456db  0f8573060000             jne 0x45d54
000456e1  85ff                     test edi, edi
000456e3  7514                     jne 0x456f9
000456e5  498b06                   mov rax, qword ptr [r14]
000456e8  8d560e                   lea edx, [rsi + 0xe]
000456eb  498bce                   mov rcx, r14
000456ee  ff5030                   call qword ptr [rax + 0x30]
000456f1  85c0                     test eax, eax
000456f3  0f845b060000             je 0x45d54
000456f9  ba01000000               mov edx, 1
000456fe  895308                   mov dword ptr [rbx + 8], edx
00045701  eb01                     jmp 0x45704
00045703  cc                       int3
00045704  85ff                     test edi, edi
00045706  0f8559060000             jne 0x45d65
0004570c  488b0b                   mov rcx, qword ptr [rbx]
0004570f  4885c9                   test rcx, rcx
00045712  0f844d060000             je 0x45d65
00045718  397964                   cmp dword ptr [rcx + 0x64], edi
0004571b  0f8644060000             jbe 0x45d65
00045721  c7430c01000000           mov dword ptr [rbx + 0xc], 1
00045728  eb01                     jmp 0x4572b
0004572a  cc                       int3
0004572b  8b8188000000             mov eax, dword ptr [rcx + 0x88]
00045731  894314                   mov dword ptr [rbx + 0x14], eax
00045734  85d2                     test edx, edx
00045736  7419                     je 0x45751
00045738  85ff                     test edi, edi
0004573a  750d                     jne 0x45749
0004573c  c781d800000001000000     mov dword ptr [rcx + 0xd8], 1
00045746  488b0b                   mov rcx, qword ptr [rbx]
00045749  488b4318                 mov rax, qword ptr [rbx + 0x18]
0004574d  48894840                 mov qword ptr [rax + 0x40], rcx
00045751  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00045756  488b742438               mov rsi, qword ptr [rsp + 0x38]
0004575b  488b7c2440               mov rdi, qword ptr [rsp + 0x40]
00045760  4883c420                 add rsp, 0x20
00045764  415e                     pop r14
00045766  c3                       ret
