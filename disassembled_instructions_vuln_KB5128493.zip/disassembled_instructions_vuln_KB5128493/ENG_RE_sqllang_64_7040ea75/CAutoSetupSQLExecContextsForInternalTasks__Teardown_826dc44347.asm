; CAutoSetupSQLExecContextsForInternalTasks::Teardown
; sqllang.dll, primary RVA 0x38f30, 152 bytes in 3 chunk(s)

; chunk at RVA 0x38f30 (19 bytes)
00038f30  4053                     push rbx
00038f32  56                       push rsi
00038f33  4883ec28                 sub rsp, 0x28
00038f37  8b4118                   mov eax, dword ptr [rcx + 0x18]
00038f3a  8bf2                     mov esi, edx
00038f3c  488bd9                   mov rbx, rcx
00038f3f  85c0                     test eax, eax
00038f41  744a                     je 0x38f8d

; chunk at RVA 0x38f43 (74 bytes)
00038f43  48896c2448               mov qword ptr [rsp + 0x48], rbp
00038f48  488d2db170fcff           lea rbp, [rip - 0x38f4f]
00038f4f  4c89742420               mov qword ptr [rsp + 0x20], r14
00038f54  4533f6                   xor r14d, r14d
00038f57  48897c2450               mov qword ptr [rsp + 0x50], rdi
00038f5c  ffc8                     dec eax
00038f5e  894318                   mov dword ptr [rbx + 0x18], eax
00038f61  ffc8                     dec eax
00038f63  83f809                   cmp eax, 9
00038f66  770f                     ja 0x38f77
00038f68  4898                     cdqe
00038f6a  8b8c85a08f0300           mov ecx, dword ptr [rbp + rax*4 + 0x38fa0]
00038f71  4803cd                   add rcx, rbp
00038f74  ffe1                     jmp rcx
00038f76  cc                       int3
00038f77  8b4318                   mov eax, dword ptr [rbx + 0x18]
00038f7a  85c0                     test eax, eax
00038f7c  75de                     jne 0x38f5c
00038f7e  4c8b742420               mov r14, qword ptr [rsp + 0x20]
00038f83  488b7c2450               mov rdi, qword ptr [rsp + 0x50]
00038f88  488b6c2448               mov rbp, qword ptr [rsp + 0x48]

; chunk at RVA 0x38f8d (59 bytes)
00038f8d  4883c428                 add rsp, 0x28
00038f91  5e                       pop rsi
00038f92  5b                       pop rbx
00038f93  c3                       ret
00038f94  90                       nop
00038f95  90                       nop
00038f96  90                       nop
00038f97  90                       nop
00038f98  90                       nop
00038f99  90                       nop
00038f9a  90                       nop
00038f9b  90                       nop
00038f9c  90                       nop
00038f9d  90                       nop
00038f9e  90                       nop
00038f9f  90                       nop
00038fa0  a7                       cmpsd dword ptr [rsi], dword ptr [rdi]
00038fa1  8e03                     mov es, word ptr [rbx]
00038fa3  00778f                   add byte ptr [rdi - 0x71], dh
00038fa6  0300                     add eax, dword ptr [rax]
00038fa8  778f                     ja 0x38f39
00038faa  0300                     add eax, dword ptr [rax]
00038fac  f4                       hlt
00038fad  91                       xchg ecx, eax
00038fae  0300                     add eax, dword ptr [rax]
00038fb0  7c91                     jl 0x38f43
00038fb2  0300                     add eax, dword ptr [rax]
00038fb4  778f                     ja 0x38f45
00038fb6  0300                     add eax, dword ptr [rax]
00038fb8  5a                       pop rdx
00038fb9  91                       xchg ecx, eax
00038fba  0300                     add eax, dword ptr [rax]
00038fbc  778f                     ja 0x38f4d
00038fbe  0300                     add eax, dword ptr [rax]
00038fc0  2691                     xchg ecx, eax
00038fc2  0300                     add eax, dword ptr [rax]
00038fc4  c9                       leave
00038fc5  90                       nop
00038fc6  0300                     add eax, dword ptr [rax]
