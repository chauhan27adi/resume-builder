; CEsCompareTuple::OrdFnEsGenCompTuple
; sqllang.dll, primary RVA 0x18edf0, 1140 bytes in 3 chunk(s)

; chunk at RVA 0x18edf0 (59 bytes)
0018edf0  48895c2410               mov qword ptr [rsp + 0x10], rbx
0018edf5  4889742418               mov qword ptr [rsp + 0x18], rsi
0018edfa  48897c2420               mov qword ptr [rsp + 0x20], rdi
0018edff  4156                     push r14
0018ee01  4883ec30                 sub rsp, 0x30
0018ee05  498bf0                   mov rsi, r8
0018ee08  488bda                   mov rbx, rdx
0018ee0b  488bf9                   mov rdi, rcx
0018ee0e  4c8bf2                   mov r14, rdx
0018ee11  4d85c0                   test r8, r8
0018ee14  7407                     je 0x18ee1d
0018ee16  41c70000000000           mov dword ptr [r8], 0
0018ee1d  440fb609                 movzx r9d, byte ptr [rcx]
0018ee21  4180f9f0                 cmp r9b, 0xf0
0018ee25  0f841bda6f00             je 0x88c846

; chunk at RVA 0x18ee2b (154 bytes)
0018ee2b  4c897c2440               mov qword ptr [rsp + 0x40], r15
0018ee30  baffff0000               mov edx, 0xffff
0018ee35  4c8d3dc411e7ff           lea r15, [rip - 0x18ee3c]
0018ee3c  430fb68c3910360202       movzx ecx, byte ptr [r9 + r15 + 0x2023610]
0018ee45  4280bc39887e050200       cmp byte ptr [rcx + r15 + 0x2057e88], 0
0018ee4e  0f857d440000             jne 0x1932d1
0018ee54  0fb60b                   movzx ecx, byte ptr [rbx]
0018ee57  420fb6843910360202       movzx eax, byte ptr [rcx + r15 + 0x2023610]
0018ee60  4280bc38887e050200       cmp byte ptr [rax + r15 + 0x2057e88], 0
0018ee69  0f8572440000             jne 0x1932e1
0018ee6f  4180f9f0                 cmp r9b, 0xf0
0018ee73  0f84e2d96f00             je 0x88c85b
0018ee79  0fb6d1                   movzx edx, cl
0018ee7c  410fb6c9                 movzx ecx, r9b
0018ee80  ff1552cdd301             call qword ptr [rip + 0x1d3cd52]
0018ee86  84c0                     test al, al
0018ee88  0f84f7d96f00             je 0x88c885
0018ee8e  0fb607                   movzx eax, byte ptr [rdi]
0018ee91  83c0de                   add eax, -0x22
0018ee94  3dce000000               cmp eax, 0xce
0018ee99  0f87b4dd6f00             ja 0x88cc53
0018ee9f  4898                     cdqe
0018eea1  410fb6840740ef1800       movzx eax, byte ptr [r15 + rax + 0x18ef40]
0018eeaa  418b8c87dcee1800         mov ecx, dword ptr [r15 + rax*4 + 0x18eedc]
0018eeb2  4903cf                   add rcx, r15
0018eeb5  ffe1                     jmp rcx
0018eeb7  cc                       int3
0018eeb8  b868020000               mov eax, 0x268
0018eebd  eb01                     jmp 0x18eec0
0018eebf  cc                       int3
0018eec0  4c8b7c2440               mov r15, qword ptr [rsp + 0x40]

; chunk at RVA 0x18eec5 (927 bytes)
0018eec5  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0018eeca  488b742450               mov rsi, qword ptr [rsp + 0x50]
0018eecf  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
0018eed4  4883c430                 add rsp, 0x30
0018eed8  415e                     pop r14
0018eeda  c3                       ret
0018eedb  90                       nop
0018eedc  53                       push rbx
0018eedd  cc                       int3
0018eede  8800                     mov byte ptr [rax], al
0018eee0  bd7b3100bb               mov ebp, 0xbb00317b
0018eee5  201e                     and byte ptr [rsi], bl
0018eee7  00957b31009f             add byte ptr [rbp - 0x60ffce85], dl
0018eeed  7b31                     jnp 0x18ef20
0018eeef  00a97b310064             add byte ptr [rcx + 0x6400317b], ch
0018eef5  f21800                   sbb byte ptr [rax], al
0018eef8  6e                       outsb dx, byte ptr [rsi]
0018eef9  f21800                   sbb byte ptr [rax], al
0018eefc  b8ee1800b1               mov eax, 0xb10018ee
0018ef01  201e                     and byte ptr [rsi], bl
0018ef03  009be11d0093             add byte ptr [rbx - 0x6cffe21f], bl
0018ef09  201e                     and byte ptr [rsi], bl
0018ef0b  00a7201e00a5             add byte ptr [rdi - 0x5affe1e0], ah
0018ef11  e11d                     loope 0x18ef30
0018ef13  00c7                     add bh, al
0018ef15  7b31                     jnp 0x18ef48
0018ef17  007e20                   add byte ptr [rsi + 0x20], bh
