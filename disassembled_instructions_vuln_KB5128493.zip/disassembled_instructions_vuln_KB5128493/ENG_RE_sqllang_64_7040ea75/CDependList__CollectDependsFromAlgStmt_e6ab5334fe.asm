; CDependList::CollectDependsFromAlgStmt
; sqllang.dll, primary RVA 0x1f6260, 508 bytes in 1 chunk(s)

; chunk at RVA 0x1f6260 (508 bytes)
001f6260  48895c2408               mov qword ptr [rsp + 8], rbx
001f6265  48896c2410               mov qword ptr [rsp + 0x10], rbp
001f626a  4889742418               mov qword ptr [rsp + 0x18], rsi
001f626f  57                       push rdi
001f6270  4154                     push r12
001f6272  4155                     push r13
001f6274  4156                     push r14
001f6276  4157                     push r15
001f6278  4881ec90000000           sub rsp, 0x90
001f627f  4c8bbc2400010000         mov r15, qword ptr [rsp + 0x100]
001f6287  410fb6f0                 movzx esi, r8b
001f628b  448bb42408010000         mov r14d, dword ptr [rsp + 0x108]
001f6293  4c8bea                   mov r13, rdx
001f6296  488bf9                   mov rdi, rcx
001f6299  498bd7                   mov rdx, r15
001f629c  458bc6                   mov r8d, r14d
001f629f  488d4c2460               lea rcx, [rsp + 0x60]
001f62a4  458be1                   mov r12d, r9d
001f62a7  e864e6e1ff               call 0x14910
001f62ac  488bac24e8000000         mov rbp, qword ptr [rsp + 0xe8]
001f62b4  33db                     xor ebx, ebx
001f62b6  899c2410010000           mov dword ptr [rsp + 0x110], ebx
001f62bd  8b4548                   mov eax, dword ptr [rbp + 0x48]
001f62c0  055effffff               add eax, 0xffffff5e
001f62c5  3deb000000               cmp eax, 0xeb
001f62ca  776f                     ja 0x1f633b
001f62cc  488d152d9de0ff           lea rdx, [rip - 0x1f62d3]
001f62d3  4898                     cdqe
001f62d5  0fb6840270631f00         movzx eax, byte ptr [rdx + rax + 0x1f6370]
001f62dd  8b8c8260631f00           mov ecx, dword ptr [rdx + rax*4 + 0x1f6360]
001f62e4  4803ca                   add rcx, rdx
001f62e7  ffe1                     jmp rcx
001f62e9  cc                       int3
001f62ea  488b4d18                 mov rcx, qword ptr [rbp + 0x18]
001f62ee  4885c9                   test rcx, rcx
001f62f1  0f85d0415d00             jne 0x7ca4c7
001f62f7  8b8424f0000000           mov eax, dword ptr [rsp + 0xf0]
001f62fe  885c2450                 mov byte ptr [rsp + 0x50], bl
001f6302  c644244801               mov byte ptr [rsp + 0x48], 1
001f6307  89442440                 mov dword ptr [rsp + 0x40], eax
001f630b  488b4510                 mov rax, qword ptr [rbp + 0x10]
001f630f  4889442438               mov qword ptr [rsp + 0x38], rax
001f6314  458bcc                   mov r9d, r12d
001f6317  8b8424e0000000           mov eax, dword ptr [rsp + 0xe0]
001f631e  440fb6c6                 movzx r8d, sil
001f6322  4489742430               mov dword ptr [rsp + 0x30], r14d
001f6327  498bd5                   mov rdx, r13
001f632a  4c897c2428               mov qword ptr [rsp + 0x28], r15
001f632f  488bcf                   mov rcx, rdi
001f6332  89442420                 mov dword ptr [rsp + 0x20], eax
001f6336  e805ecffff               call 0x1f4f40
001f633b  4c8d9c2490000000         lea r11, [rsp + 0x90]
001f6343  498b5b30                 mov rbx, qword ptr [r11 + 0x30]
001f6347  498b6b38                 mov rbp, qword ptr [r11 + 0x38]
001f634b  498b7340                 mov rsi, qword ptr [r11 + 0x40]
001f634f  498be3                   mov rsp, r11
001f6352  415f                     pop r15
001f6354  415e                     pop r14
001f6356  415d                     pop r13
001f6358  415c                     pop r12
001f635a  5f                       pop rdi
001f635b  c3                       ret
001f635c  90                       nop
001f635d  90                       nop
001f635e  90                       nop
001f635f  90                       nop
001f6360  36a4                     movsb byte ptr [rdi], byte ptr ss:[rsi]
001f6362  7c00                     jl 0x1f6364
