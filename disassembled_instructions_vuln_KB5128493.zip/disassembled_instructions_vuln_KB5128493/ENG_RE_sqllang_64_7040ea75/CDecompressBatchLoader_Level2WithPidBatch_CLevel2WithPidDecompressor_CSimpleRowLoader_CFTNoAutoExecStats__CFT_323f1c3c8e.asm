; CDecompressBatchLoader<Level2WithPidBatch,CLevel2WithPidDecompressor,CSimpleRowLoader<CFTNoAutoExecStats>,CFTNoAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x9731d0, 1401 bytes in 3 chunk(s)

; chunk at RVA 0x9731d0 (57 bytes)
009731d0  4c894c2420               mov qword ptr [rsp + 0x20], r9
009731d5  89542410                 mov dword ptr [rsp + 0x10], edx
009731d9  55                       push rbp
009731da  57                       push rdi
009731db  4155                     push r13
009731dd  4157                     push r15
009731df  488d6c24c1               lea rbp, [rsp - 0x3f]
009731e4  4881ece8000000           sub rsp, 0xe8
009731eb  83792002                 cmp dword ptr [rcx + 0x20], 2
009731ef  4d8be8                   mov r13, r8
009731f2  8bfa                     mov edi, edx
009731f4  4c8bf9                   mov r15, rcx
009731f7  7510                     jne 0x973209
009731f9  33c0                     xor eax, eax
009731fb  4881c4e8000000           add rsp, 0xe8
00973202  415f                     pop r15
00973204  415d                     pop r13
00973206  5f                       pop rdi
00973207  5d                       pop rbp
00973208  c3                       ret

; chunk at RVA 0x973209 (1248 bytes)
00973209  48899c2420010000         mov qword ptr [rsp + 0x120], rbx
00973211  0f57c0                   xorps xmm0, xmm0
00973214  4889b424e0000000         mov qword ptr [rsp + 0xe0], rsi
0097321c  0f57c9                   xorps xmm1, xmm1
0097321f  4c89a424d8000000         mov qword ptr [rsp + 0xd8], r12
00973227  4c89b424d0000000         mov qword ptr [rsp + 0xd0], r14
0097322f  4533f6                   xor r14d, r14d
00973232  32c9                     xor cl, cl
00973234  448975b7                 mov dword ptr [rbp - 0x49], r14d
00973238  884d67                   mov byte ptr [rbp + 0x67], cl
0097323b  4c8975bf                 mov qword ptr [rbp - 0x41], r14
0097323f  448875c7                 mov byte ptr [rbp - 0x39], r14b
00973243  660f7f45d7               movdqa xmmword ptr [rbp - 0x29], xmm0
00973248  660f7f4de7               movdqa xmmword ptr [rbp - 0x19], xmm1
0097324d  660f7f45f7               movdqa xmmword ptr [rbp - 9], xmm0
00973252  4c897507                 mov qword ptr [rbp + 7], r14
00973256  c7450f01000000           mov dword ptr [rbp + 0xf], 1
0097325d  4c897517                 mov qword ptr [rbp + 0x17], r14
00973261  4489742420               mov dword ptr [rsp + 0x20], r14d
00973266  45887510                 mov byte ptr [r13 + 0x10], r14b
0097326a  4c8d258fcd68ff           lea r12, [rip - 0x973271]
00973271  4538b748250000           cmp byte ptr [r15 + 0x2548], r14b
00973278  0f8495000000             je 0x973313
0097327e  498b9f40250000           mov rbx, qword ptr [r15 + 0x2540]
00973285  33d2                     xor edx, edx
00973287  4c8bc3                   mov r8, rbx
0097328a  4588b748250000           mov byte ptr [r15 + 0x2548], r14b
00973291  498bcd                   mov rcx, r13
00973294  e8b79cffff               call 0x96cf50
00973299  488b5360                 mov rdx, qword ptr [rbx + 0x60]
0097329d  488d75b7                 lea rsi, [rbp - 0x49]
009732a1  418b4d00                 mov ecx, dword ptr [r13]
009732a5  498b4560                 mov rax, qword ptr [r13 + 0x60]
009732a9  ffc9                     dec ecx
009732ab  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
009732af  4803c9                   add rcx, rcx
009732b2  0f1002                   movups xmm0, xmmword ptr [rdx]
009732b5  448975b7                 mov dword ptr [rbp - 0x49], r14d
009732b9  c744242001000000         mov dword ptr [rsp + 0x20], 1
009732c1  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
009732c5  498b8740250000           mov rax, qword ptr [r15 + 0x2540]
009732cc  ff08                     dec dword ptr [rax]
009732ce  418b5500                 mov edx, dword ptr [r13]
009732d2  498b4508                 mov rax, qword ptr [r13 + 8]
009732d6  488945bf                 mov qword ptr [rbp - 0x41], rax
009732da  498b4520                 mov rax, qword ptr [r13 + 0x20]
009732de  488d0cd0                 lea rcx, [rax + rdx*8]
009732e2  498b4528                 mov rax, qword ptr [r13 + 0x28]
009732e6  48894dd7                 mov qword ptr [rbp - 0x29], rcx
009732ea  488d0c90                 lea rcx, [rax + rdx*4]
009732ee  498b4530                 mov rax, qword ptr [r13 + 0x30]
009732f2  48894ddf                 mov qword ptr [rbp - 0x21], rcx
009732f6  4588b748250000           mov byte ptr [r15 + 0x2548], r14b
009732fd  488d0c90                 lea rcx, [rax + rdx*4]
00973301  b801000000               mov eax, 1
00973306  2bc2                     sub eax, edx
00973308  48894de7                 mov qword ptr [rbp - 0x19], rcx
0097330c  03f8                     add edi, eax
0097330e  897d6f                   mov dword ptr [rbp + 0x6f], edi
00973311  eb03                     jmp 0x973316
00973313  498bf5                   mov rsi, r13
00973316  45397720                 cmp dword ptr [r15 + 0x20], r14d
0097331a  7555                     jne 0x973371
0097331c  498b4728                 mov rax, qword ptr [r15 + 0x28]
00973320  498d4f28                 lea rcx, [r15 + 0x28]
00973324  4d8bc1                   mov r8, r9
00973327  4c89742428               mov qword ptr [rsp + 0x28], r14
0097332c  488d542428               lea rdx, [rsp + 0x28]
00973331  44897587                 mov dword ptr [rbp - 0x79], r14d
00973335  4c89758f                 mov qword ptr [rbp - 0x71], r14
00973339  44897597                 mov dword ptr [rbp - 0x69], r14d
0097333d  4c89759f                 mov qword ptr [rbp - 0x61], r14
00973341  448975a7                 mov dword ptr [rbp - 0x59], r14d
00973345  66448975ab               mov word ptr [rbp - 0x55], r14w
0097334a  c6456701                 mov byte ptr [rbp + 0x67], 1
0097334e  ff10                     call qword ptr [rax]
00973350  3dc60e0400               cmp eax, 0x40ec6
00973355  0f843c030000             je 0x973697
0097335b  498d4f38                 lea rcx, [r15 + 0x38]
0097335f  488d542428               lea rdx, [rsp + 0x28]
00973364  e84794f5ff               call 0x8cc7b0
00973369  41c7472001000000         mov dword ptr [r15 + 0x20], 1
00973371  498b4730                 mov rax, qword ptr [r15 + 0x30]
00973375  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
0097337c  4c894608                 mov qword ptr [rsi + 8], r8
00973380  498b5730                 mov rdx, qword ptr [r15 + 0x30]
00973384  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
0097338b  8b423c                   mov eax, dword ptr [rdx + 0x3c]
0097338e  83e007                   and eax, 7
00973391  83f805                   cmp eax, 5
00973394  773c                     ja 0x9733d2
00973396  4898                     cdqe
00973398  418b8c84ec369700         mov ecx, dword ptr [r12 + rax*4 + 0x9736ec]
009733a0  4903cc                   add rcx, r12
009733a3  ffe1                     jmp rcx
009733a5  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009733a9  0f95c3                   setne bl
009733ac  eb26                     jmp 0x9733d4
009733ae  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009733b2  0f9dc3                   setge bl
009733b5  eb1d                     jmp 0x9733d4
009733b7  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009733bb  0f9ec3                   setle bl
009733be  eb14                     jmp 0x9733d4
009733c0  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009733c4  0f9fc3                   setg bl
009733c7  eb0b                     jmp 0x9733d4
009733c9  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
009733cd  0f9cc3                   setl bl
009733d0  eb02                     jmp 0x9733d4
009733d2  32db                     xor bl, bl
009733d4  8b424c                   mov eax, dword ptr [rdx + 0x4c]
009733d7  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
009733de  83e007                   and eax, 7
009733e1  83f805                   cmp eax, 5
009733e4  7741                     ja 0x973427
009733e6  4898                     cdqe
009733e8  418b8c8404379700         mov ecx, dword ptr [r12 + rax*4 + 0x973704]
009733f0  4903cc                   add rcx, r12
009733f3  ffe1                     jmp rcx
009733f5  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
009733f9  410f95c4                 setne r12b
009733fd  eb2b                     jmp 0x97342a
009733ff  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973403  410f9dc4                 setge r12b
00973407  eb21                     jmp 0x97342a
00973409  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097340d  410f9ec4                 setle r12b
00973411  eb17                     jmp 0x97342a
00973413  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973417  410f9fc4                 setg r12b
0097341b  eb0d                     jmp 0x97342a
0097341d  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973421  410f9cc4                 setl r12b
00973425  eb03                     jmp 0x97342a
00973427  4532e4                   xor r12b, r12b
0097342a  498d4f38                 lea rcx, [r15 + 0x38]
0097342e  4c8bc6                   mov r8, rsi
00973431  8bd7                     mov edx, edi
00973433  e818b1ffff               call 0x96e550
00973438  84c0                     test al, al
0097343a  7504                     jne 0x973440
0097343c  45897720                 mov dword ptr [r15 + 0x20], r14d
00973440  8b06                     mov eax, dword ptr [rsi]
00973442  448bc0                   mov r8d, eax
00973445  85c0                     test eax, eax
00973447  0f84c6010000             je 0x973613
0097344d  84db                     test bl, bl
0097344f  7509                     jne 0x97345a
00973451  4584e4                   test r12b, r12b
00973454  0f84b9010000             je 0x973613
0097345a  448bc8                   mov r9d, eax
0097345d  84db                     test bl, bl
0097345f  747f                     je 0x9734e0
00973461  4d8b5f30                 mov r11, qword ptr [r15 + 0x30]
00973465  458bd6                   mov r10d, r14d
00973468  85c0                     test eax, eax
0097346a  746b                     je 0x9734d7
0097346c  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00973470  488d3d89cb68ff           lea rdi, [rip - 0x973477]
00973477  488b5e20                 mov rbx, qword ptr [rsi + 0x20]
0097347b  4183e007                 and r8d, 7
0097347f  90                       nop
00973480  418bca                   mov ecx, r10d
00973483  4c8b0ccb                 mov r9, qword ptr [rbx + rcx*8]
00973487  4183f805                 cmp r8d, 5
0097348b  0f87ae000000             ja 0x97353f
00973491  4963c8                   movsxd rcx, r8d
00973494  8b948f1c379700           mov edx, dword ptr [rdi + rcx*4 + 0x97371c]
0097349b  4803d7                   add rdx, rdi
0097349e  ffe2                     jmp rdx
009734a0  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734a4  0f94c1                   sete cl
009734a7  eb22                     jmp 0x9734cb
009734a9  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734ad  0f9cc1                   setl cl
009734b0  eb19                     jmp 0x9734cb
009734b2  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734b6  0f9fc1                   setg cl
009734b9  eb10                     jmp 0x9734cb
009734bb  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734bf  0f9ec1                   setle cl
009734c2  eb07                     jmp 0x9734cb
009734c4  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
009734c8  0f9dc1                   setge cl
009734cb  84c9                     test cl, cl
009734cd  7570                     jne 0x97353f
009734cf  41ffc2                   inc r10d
009734d2  443bd0                   cmp r10d, eax
009734d5  72a9                     jb 0x973480
009734d7  448936                   mov dword ptr [rsi], r14d
009734da  418bc6                   mov eax, r14d
009734dd  458bce                   mov r9d, r14d
009734e0  458bc1                   mov r8d, r9d
009734e3  4584e4                   test r12b, r12b
009734e6  0f8427010000             je 0x973613
009734ec  85c0                     test eax, eax
009734ee  0f841f010000             je 0x973613
009734f4  4d8b5f30                 mov r11, qword ptr [r15 + 0x30]
009734f8  4c8d2501cb68ff           lea r12, [rip - 0x9734ff]
009734ff  488b7e20                 mov rdi, qword ptr [rsi + 0x20]
00973503  0f1f4000                 nop dword ptr [rax]
00973507  660f1f840000000000       nop word ptr [rax + rax]
00973510  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00973514  ffc8                     dec eax
00973516  458bd1                   mov r10d, r9d
00973519  83e107                   and ecx, 7
0097351c  448bc8                   mov r9d, eax
0097351f  458bc2                   mov r8d, r10d
00973522  488b1cc7                 mov rbx, qword ptr [rdi + rax*8]
00973526  83f905                   cmp ecx, 5
00973529  0f87e4000000             ja 0x973613
0097352f  4863c9                   movsxd rcx, ecx
00973532  418b948c34379700         mov edx, dword ptr [r12 + rcx*4 + 0x973734]
0097353a  4903d4                   add rdx, r12
0097353d  ffe2                     jmp rdx
0097353f  443bd0                   cmp r10d, eax
00973542  7393                     jae 0x9734d7
00973544  448bc8                   mov r9d, eax
00973547  4585d2                   test r10d, r10d
0097354a  7494                     je 0x9734e0
0097354c  458bde                   mov r11d, r14d
0097354f  452bca                   sub r9d, r10d
00973552  7478                     je 0x9735cc
00973554  498bd6                   mov rdx, r14
00973557  498bde                   mov rbx, r14
0097355a  498bfe                   mov rdi, r14
0097355d  0f1f00                   nop dword ptr [rax]
00973560  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00973564  438d0413                 lea eax, [r11 + r10]
00973568  448bc0                   mov r8d, eax
0097356b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
0097356f  4889040f                 mov qword ptr [rdi + rcx], rax
00973573  488b4e30                 mov rcx, qword ptr [rsi + 0x30]
00973577  428b0481                 mov eax, dword ptr [rcx + r8*4]
0097357b  89040b                   mov dword ptr [rbx + rcx], eax
0097357e  488b4e28                 mov rcx, qword ptr [rsi + 0x28]
00973582  428b0481                 mov eax, dword ptr [rcx + r8*4]
00973586  4d03c0                   add r8, r8
00973589  89040b                   mov dword ptr [rbx + rcx], eax
0097358c  488b4638                 mov rax, qword ptr [rsi + 0x38]
00973590  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00973595  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00973599  488b4648                 mov rax, qword ptr [rsi + 0x48]
0097359d  4885c0                   test rax, rax
009735a0  7409                     je 0x9735ab
009735a2  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
009735a7  0f110410                 movups xmmword ptr [rax + rdx], xmm0
009735ab  488b4660                 mov rax, qword ptr [rsi + 0x60]
009735af  41ffc3                   inc r11d
009735b2  4883c708                 add rdi, 8
009735b6  4883c304                 add rbx, 4
009735ba  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
009735bf  0f110410                 movups xmmword ptr [rax + rdx], xmm0
009735c3  4883c210                 add rdx, 0x10
009735c7  453bd9                   cmp r11d, r9d
009735ca  7294                     jb 0x973560
009735cc  44890e                   mov dword ptr [rsi], r9d
009735cf  418bc1                   mov eax, r9d
009735d2  e909ffffff               jmp 0x9734e0
009735d7  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735db  0f94c1                   sete cl
009735de  eb22                     jmp 0x973602
009735e0  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735e4  0f9cc1                   setl cl
009735e7  eb19                     jmp 0x973602
009735e9  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735ed  0f9fc1                   setg cl
009735f0  eb10                     jmp 0x973602
009735f2  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735f6  0f9ec1                   setle cl
009735f9  eb07                     jmp 0x973602
009735fb  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
009735ff  0f9dc1                   setge cl
00973602  84c9                     test cl, cl
00973604  750d                     jne 0x973613
00973606  8906                     mov dword ptr [rsi], eax
00973608  448bc0                   mov r8d, eax
0097360b  85c0                     test eax, eax
0097360d  0f85fdfeffff             jne 0x973510
00973613  4538b749250000           cmp byte ptr [r15 + 0x2549], r14b
0097361a  7462                     je 0x97367e
0097361c  448b06                   mov r8d, dword ptr [rsi]
0097361f  4585c0                   test r8d, r8d
00973622  745a                     je 0x97367e
00973624  498bbf40250000           mov rdi, qword ptr [r15 + 0x2540]
0097362b  4c8bc6                   mov r8, rsi
0097362e  41c6874825000001         mov byte ptr [r15 + 0x2548], 1
00973636  488bcf                   mov rcx, rdi
00973639  8b1e                     mov ebx, dword ptr [rsi]
0097363b  ffcb                     dec ebx
0097363d  8bd3                     mov edx, ebx
0097363f  e80c99ffff               call 0x96cf50
00973644  8b0f                     mov ecx, dword ptr [rdi]
00973646  488b4760                 mov rax, qword ptr [rdi + 0x60]
0097364a  ffc9                     dec ecx
0097364c  488b5660                 mov rdx, qword ptr [rsi + 0x60]
00973650  4803c9                   add rcx, rcx
00973653  448bc3                   mov r8d, ebx
00973656  4d03c0                   add r8, r8
00973659  420f1004c2               movups xmm0, xmmword ptr [rdx + r8*8]
0097365e  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
00973662  ff0e                     dec dword ptr [rsi]
00973664  41c6451001               mov byte ptr [r13 + 0x10], 1
00973669  498b8740250000           mov rax, qword ptr [r15 + 0x2540]
00973670  488b4820                 mov rcx, qword ptr [rax + 0x20]
00973674  488b01                   mov rax, qword ptr [rcx]
00973677  49894518                 mov qword ptr [r13 + 0x18], rax
0097367b  448b06                   mov r8d, dword ptr [rsi]
0097367e  8b442420                 mov eax, dword ptr [rsp + 0x20]
00973682  4103c0                   add eax, r8d
00973685  89442420                 mov dword ptr [rsp + 0x20], eax
00973689  7521                     jne 0x9736ac
0097368b  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
0097368e  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00973692  e9cffbffff               jmp 0x973266
00973697  41c7472002000000         mov dword ptr [r15 + 0x20], 2
0097369f  45397500                 cmp dword ptr [r13], r14d
009736a3  410f95c6                 setne r14b
009736a7  418bc6                   mov eax, r14d
009736aa  eb0f                     jmp 0x9736bb
009736ac  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
009736b0  f6d9                     neg cl
009736b2  41894500                 mov dword ptr [r13], eax
009736b6  1bc0                     sbb eax, eax
009736b8  83c002                   add eax, 2
009736bb  4c8ba424d8000000         mov r12, qword ptr [rsp + 0xd8]
009736c3  488bb424e0000000         mov rsi, qword ptr [rsp + 0xe0]
009736cb  488b9c2420010000         mov rbx, qword ptr [rsp + 0x120]
009736d3  4c8bb424d0000000         mov r14, qword ptr [rsp + 0xd0]
009736db  4881c4e8000000           add rsp, 0xe8
009736e2  415f                     pop r15
009736e4  415d                     pop r13
009736e6  5f                       pop rdi
009736e7  5d                       pop rbp
009736e8  c3                       ret

; chunk at RVA 0x9736ec (96 bytes)
009736ec  d233                     sal byte ptr [rbx], cl
009736ee  97                       xchg edi, eax
009736ef  00a5339700ae             add byte ptr [rbp - 0x51ff68cd], ah
009736f5  339700c03397             xor edx, dword ptr [rdi - 0x68cc4000]
009736fb  00b7339700c9             add byte ptr [rdi - 0x36ff68cd], dh
00973701  339700273497             xor edx, dword ptr [rdi - 0x68cbd900]
00973707  00f5                     add ch, dh
00973709  339700ff3397             xor edx, dword ptr [rdi - 0x68cc0100]
0097370f  0013                     add byte ptr [rbx], dl
00973711  3497                     xor al, 0x97
00973713  0009                     add byte ptr [rcx], cl
00973715  3497                     xor al, 0x97
00973717  001d3497003f             add byte ptr [rip + 0x3f009734], bl
0097371d  359700a034               xor eax, 0x34a00097
00973722  97                       xchg edi, eax
00973723  00a9349700bb             add byte ptr [rcx - 0x44ff68cc], ch
00973729  3497                     xor al, 0x97
0097372b  00b2349700c4             add byte ptr [rdx - 0x3bff68cc], dh
00973731  3497                     xor al, 0x97
00973733  0013                     add byte ptr [rbx], dl
00973735  3697                     xchg edi, eax
00973737  00d7                     add bh, dl
00973739  359700e035               xor eax, 0x35e00097
0097373e  97                       xchg edi, eax
0097373f  00f2                     add dl, dh
00973741  359700e935               xor eax, 0x35e90097
00973746  97                       xchg edi, eax
00973747  00fb                     add bl, bh
