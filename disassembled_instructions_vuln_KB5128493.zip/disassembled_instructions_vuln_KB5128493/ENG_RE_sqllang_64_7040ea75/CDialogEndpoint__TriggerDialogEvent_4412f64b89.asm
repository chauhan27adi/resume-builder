; CDialogEndpoint::TriggerDialogEvent
; sqllang.dll, primary RVA 0x4c7b10, 692 bytes in 1 chunk(s)

; chunk at RVA 0x4c7b10 (692 bytes)
004c7b10  4056                     push rsi
004c7b12  57                       push rdi
004c7b13  4156                     push r14
004c7b15  4883ec50                 sub rsp, 0x50
004c7b19  48c7442440feffffff       mov qword ptr [rsp + 0x40], 0xfffffffffffffffe
004c7b22  48899c2480000000         mov qword ptr [rsp + 0x80], rbx
004c7b2a  488bd9                   mov rbx, rcx
004c7b2d  4c8d35cc84b3ff           lea r14, [rip - 0x4c7b34]
004c7b34  83fa0c                   cmp edx, 0xc
004c7b37  750c                     jne 0x4c7b45
004c7b39  48634130                 movsxd rax, dword ptr [rcx + 0x30]
004c7b3d  418b9486785f1702         mov edx, dword ptr [r14 + rax*4 + 0x2175f78]
004c7b45  80792e00                 cmp byte ptr [rcx + 0x2e], 0
004c7b49  7424                     je 0x4c7b6f
004c7b4b  83fa03                   cmp edx, 3
004c7b4e  751f                     jne 0x4c7b6f
004c7b50  488b8130040000           mov rax, qword ptr [rcx + 0x430]
004c7b57  c6805d01000001           mov byte ptr [rax + 0x15d], 1
004c7b5e  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
004c7b66  4883c450                 add rsp, 0x50
004c7b6a  415e                     pop r14
004c7b6c  5f                       pop rdi
004c7b6d  5e                       pop rsi
004c7b6e  c3                       ret
004c7b6f  48638170010000           movsxd rax, dword ptr [rcx + 0x170]
004c7b76  894174                   mov dword ptr [rcx + 0x74], eax
004c7b79  4863f2                   movsxd rsi, edx
004c7b7c  486bc80b                 imul rcx, rax, 0xb
004c7b80  4803ce                   add rcx, rsi
004c7b83  418bbc8e905c1702         mov edi, dword ptr [r14 + rcx*4 + 0x2175c90]
004c7b8b  897b78                   mov dword ptr [rbx + 0x78], edi
004c7b8e  83fa0a                   cmp edx, 0xa
004c7b91  775d                     ja 0x4c7bf0
004c7b93  4863c2                   movsxd rax, edx
004c7b96  418b8c86987d4c00         mov ecx, dword ptr [r14 + rax*4 + 0x4c7d98]
004c7b9e  4903ce                   add rcx, r14
004c7ba1  ffe1                     jmp rcx
004c7ba3  ba01000000               mov edx, 1
004c7ba8  eb75                     jmp 0x4c7c1f
004c7baa  ba02000000               mov edx, 2
004c7baf  eb6e                     jmp 0x4c7c1f
004c7bb1  ba03000000               mov edx, 3
004c7bb6  eb67                     jmp 0x4c7c1f
004c7bb8  ba04000000               mov edx, 4
004c7bbd  eb60                     jmp 0x4c7c1f
004c7bbf  ba05000000               mov edx, 5
004c7bc4  eb59                     jmp 0x4c7c1f
004c7bc6  ba06000000               mov edx, 6
004c7bcb  eb52                     jmp 0x4c7c1f
004c7bcd  ba07000000               mov edx, 7
004c7bd2  eb4b                     jmp 0x4c7c1f
004c7bd4  ba08000000               mov edx, 8
004c7bd9  eb44                     jmp 0x4c7c1f
004c7bdb  ba09000000               mov edx, 9
004c7be0  eb3d                     jmp 0x4c7c1f
004c7be2  ba0a000000               mov edx, 0xa
004c7be7  eb36                     jmp 0x4c7c1f
004c7be9  ba0d000000               mov edx, 0xd
004c7bee  eb2f                     jmp 0x4c7c1f
004c7bf0  488d05690ec901           lea rax, [rip + 0x1c90e69]
004c7bf7  4889442420               mov qword ptr [rsp + 0x20], rax
004c7bfc  41b9b9190000             mov r9d, 0x19b9
004c7c02  4c8d0567040502           lea r8, [rip + 0x2050467]
004c7c09  488d1510ec0402           lea rdx, [rip + 0x204ec10]
004c7c10  b901000000               mov ecx, 1
004c7c15  ff155d32a001             call qword ptr [rip + 0x1a0325d]
004c7c1b  8b542430                 mov edx, dword ptr [rsp + 0x30]
004c7c1f  448bc7                   mov r8d, edi
004c7c22  488bcb                   mov rcx, rbx
004c7c25  e8f6410000               call 0x4cbe20
004c7c2a  8b5378                   mov edx, dword ptr [rbx + 0x78]
004c7c2d  83fa08                   cmp edx, 8
004c7c30  0f8451010000             je 0x4c7d87
004c7c36  48634374                 movsxd rax, dword ptr [rbx + 0x74]
004c7c3a  3bd0                     cmp edx, eax
004c7c3c  740d                     je 0x4c7c4b
004c7c3e  899370010000             mov dword ptr [rbx + 0x170], edx
004c7c44  838ba802000008           or dword ptr [rbx + 0x2a8], 8
004c7c4b  486bc80b                 imul rcx, rax, 0xb
004c7c4f  4803ce                   add rcx, rsi
004c7c52  498bbccec0571702         mov rdi, qword ptr [r14 + rcx*8 + 0x21757c0]
004c7c5a  8b07                     mov eax, dword ptr [rdi]
004c7c5c  83f80c                   cmp eax, 0xc
004c7c5f  7418                     je 0x4c7c79
004c7c61  8bd0                     mov edx, eax
004c7c63  488bcb                   mov rcx, rbx
004c7c66  e875f9ffff               call 0x4c75e0
004c7c6b  488d7f04                 lea rdi, [rdi + 4]
004c7c6f  8b07                     mov eax, dword ptr [rdi]
004c7c71  83f80c                   cmp eax, 0xc
004c7c74  75eb                     jne 0x4c7c61
004c7c76  8b5378                   mov edx, dword ptr [rbx + 0x78]
004c7c79  83fa06                   cmp edx, 6
004c7c7c  0f8505010000             jne 0x4c7d87
004c7c82  395374                   cmp dword ptr [rbx + 0x74], edx
004c7c85  750a                     jne 0x4c7c91
004c7c87  837b300d                 cmp dword ptr [rbx + 0x30], 0xd
004c7c8b  0f85ef000000             jne 0x4c7d80
004c7c91  4533c0                   xor r8d, r8d
004c7c94  418d5001                 lea edx, [r8 + 1]
004c7c98  488d4c2438               lea rcx, [rsp + 0x38]
004c7c9d  ff1525116102             call qword ptr [rip + 0x2611125]
004c7ca3  80bbf800000000           cmp byte ptr [rbx + 0xf8], 0
004c7caa  0f85b5000000             jne 0x4c7d65
004c7cb0  837b7400                 cmp dword ptr [rbx + 0x74], 0
004c7cb4  0f84ab000000             je 0x4c7d65
004c7cba  837b300d                 cmp dword ptr [rbx + 0x30], 0xd
004c7cbe  0f84a1000000             je 0x4c7d65
004c7cc4  488b8338010000           mov rax, qword ptr [rbx + 0x138]
004c7ccb  4889442430               mov qword ptr [rsp + 0x30], rax
004c7cd0  ba08000000               mov edx, 8
004c7cd5  41b826070000             mov r8d, 0x726
004c7cdb  488d4c2430               lea rcx, [rsp + 0x30]
004c7ce0  ff159a3fa001             call qword ptr [rip + 0x1a03f9a]
004c7ce6  85c0                     test eax, eax
004c7ce8  7442                     je 0x4c7d2c
004c7cea  83f801                   cmp eax, 1
004c7ced  742d                     je 0x4c7d1c
004c7cef  488d056a0dc901           lea rax, [rip + 0x1c90d6a]
004c7cf6  4889442420               mov qword ptr [rsp + 0x20], rax
004c7cfb  41b95a170000             mov r9d, 0x175a
004c7d01  4c8d0568030502           lea r8, [rip + 0x2050368]
004c7d08  488d1511eb0402           lea rdx, [rip + 0x204eb11]
004c7d0f  b901000000               mov ecx, 1
004c7d14  ff155e31a001             call qword ptr [rip + 0x1a0315e]
004c7d1a  eb10                     jmp 0x4c7d2c
004c7d1c  c74424347f242d00         mov dword ptr [rsp + 0x34], 0x2d247f
004c7d24  c7442430ff818b01         mov dword ptr [rsp + 0x30], 0x18b81ff
004c7d2c  488b8b10020000           mov rcx, qword ptr [rbx + 0x210]
004c7d33  488b442430               mov rax, qword ptr [rsp + 0x30]
004c7d38  4885c9                   test rcx, rcx
004c7d3b  7409                     je 0x4c7d46
004c7d3d  483bc1                   cmp rax, rcx
004c7d40  7c04                     jl 0x4c7d46
004c7d42  480f45c1                 cmovne rax, rcx
004c7d46  483b442438               cmp rax, qword ptr [rsp + 0x38]
004c7d4b  7c18                     jl 0x4c7d65
004c7d4d  7416                     je 0x4c7d65
004c7d4f  488d8b80000000           lea rcx, [rbx + 0x80]
004c7d56  e8b5980200               call 0x4f1610
004c7d5b  488bcb                   mov rcx, rbx
004c7d5e  e80d330000               call 0x4cb070
004c7d63  eb14                     jmp 0x4c7d79
004c7d65  488bcb                   mov rcx, rbx
004c7d68  e8f3350000               call 0x4cb360
004c7d6d  488d8b80000000           lea rcx, [rbx + 0x80]
004c7d74  e8d7a20200               call 0x4f2050
004c7d79  c7437406000000           mov dword ptr [rbx + 0x74], 6
004c7d80  b102                     mov cl, 2
004c7d82  e84960b4ff               call 0xddd0
004c7d87  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
004c7d8f  4883c450                 add rsp, 0x50
004c7d93  415e                     pop r14
004c7d95  5f                       pop rdi
004c7d96  5e                       pop rsi
004c7d97  c3                       ret
004c7d98  a37b4c00aa7b4c00b1       movabs dword ptr [0xb1004c7baa004c7b], eax
004c7da1  7b4c                     jnp 0x4c7def
004c7da3  00b87b4c00bf             add byte ptr [rax - 0x40ffb385], bh
004c7da9  7b4c                     jnp 0x4c7df7
004c7dab  00c6                     add dh, al
004c7dad  7b4c                     jnp 0x4c7dfb
004c7daf  00cd                     add ch, cl
004c7db1  7b4c                     jnp 0x4c7dff
004c7db3  00d4                     add ah, dl
004c7db5  7b4c                     jnp 0x4c7e03
004c7db7  00db                     add bl, bl
004c7db9  7b4c                     jnp 0x4c7e07
004c7dbb  00e2                     add dl, ah
004c7dbd  7b4c                     jnp 0x4c7e0b
004c7dbf  00e9                     add cl, ch
004c7dc1  7b4c                     jnp 0x4c7e0f
