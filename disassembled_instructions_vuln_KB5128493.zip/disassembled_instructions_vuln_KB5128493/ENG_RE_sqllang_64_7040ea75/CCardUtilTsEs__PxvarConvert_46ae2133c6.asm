; CCardUtilTsEs::PxvarConvert
; sqllang.dll, primary RVA 0x2be670, 511 bytes in 1 chunk(s)

; chunk at RVA 0x2be670 (511 bytes)
002be670  4c894c2420               mov qword ptr [rsp + 0x20], r9
002be675  4c89442418               mov qword ptr [rsp + 0x18], r8
002be67a  4889542410               mov qword ptr [rsp + 0x10], rdx
002be67f  48894c2408               mov qword ptr [rsp + 8], rcx
002be684  53                       push rbx
002be685  56                       push rsi
002be686  57                       push rdi
002be687  4154                     push r12
002be689  4155                     push r13
002be68b  4156                     push r14
002be68d  4157                     push r15
002be68f  4881ece0000000           sub rsp, 0xe0
002be696  48c7842488000000feffffff mov qword ptr [rsp + 0x88], 0xfffffffffffffffe
002be6a2  498bf1                   mov rsi, r9
002be6a5  4d8bf0                   mov r14, r8
002be6a8  4c8bea                   mov r13, rdx
002be6ab  4c8bc9                   mov r9, rcx
002be6ae  4c8ba42440010000         mov r12, qword ptr [rsp + 0x140]
002be6b6  488d1d4319d4ff           lea rbx, [rip - 0x2be6bd]
002be6bd  4d85e4                   test r12, r12
002be6c0  754d                     jne 0x2be70f
002be6c2  b9ffff0000               mov ecx, 0xffff
002be6c7  6641394810               cmp word ptr [r8 + 0x10], cx
002be6cc  0f8422766701             je 0x1935cf4
002be6d2  410fb600                 movzx eax, byte ptr [r8]
002be6d6  0fb6841810360202         movzx eax, byte ptr [rax + rbx + 0x2023610]
002be6de  4438a4189875ae02         cmp byte ptr [rax + rbx + 0x2ae7598], r12b
002be6e6  0f8508766701             jne 0x1935cf4
002be6ec  66394e10                 cmp word ptr [rsi + 0x10], cx
002be6f0  0f84fe756701             je 0x1935cf4
002be6f6  0fb606                   movzx eax, byte ptr [rsi]
002be6f9  0fb68c1810360202         movzx ecx, byte ptr [rax + rbx + 0x2023610]
002be701  4438a4199875ae02         cmp byte ptr [rcx + rbx + 0x2ae7598], r12b
002be709  0f85e5756701             jne 0x1935cf4
002be70f  4d8bc6                   mov r8, r14
002be712  498bd5                   mov rdx, r13
002be715  498bc9                   mov rcx, r9
002be718  e8d39df9ff               call 0x2584f0
002be71d  4889842440010000         mov qword ptr [rsp + 0x140], rax
002be725  33d2                     xor edx, edx
002be727  4533ff                   xor r15d, r15d
002be72a  4c897c2428               mov qword ptr [rsp + 0x28], r15
002be72f  488d053a32daff           lea rax, [rip - 0x25cdc6]
002be736  4889442420               mov qword ptr [rsp + 0x20], rax
002be73b  4533c9                   xor r9d, r9d
002be73e  4533c0                   xor r8d, r8d
002be741  488d8c24b8000000         lea rcx, [rsp + 0xb8]
002be749  e8f234d4ff               call 0x1c40
002be74e  90                       nop
002be74f  418bc7                   mov eax, r15d
002be752  89442460                 mov dword ptr [rsp + 0x60], eax
002be756  41803e2b                 cmp byte ptr [r14], 0x2b
002be75a  0f84f2756701             je 0x1935d52
002be760  4c89642458               mov qword ptr [rsp + 0x58], r12
002be765  c644245000               mov byte ptr [rsp + 0x50], 0
002be76a  c644244800               mov byte ptr [rsp + 0x48], 0
002be76f  c644244000               mov byte ptr [rsp + 0x40], 0
002be774  c644243800               mov byte ptr [rsp + 0x38], 0
002be779  89442430                 mov dword ptr [rsp + 0x30], eax
002be77d  488b842420010000         mov rax, qword ptr [rsp + 0x120]
002be785  4889442428               mov qword ptr [rsp + 0x28], rax
002be78a  44897c2420               mov dword ptr [rsp + 0x20], r15d
002be78f  4533c9                   xor r9d, r9d
002be792  4c8bc6                   mov r8, rsi
002be795  498bd6                   mov rdx, r14
002be798  488b8c2440010000         mov rcx, qword ptr [rsp + 0x140]
002be7a0  ff15f2d4c001             call qword ptr [rip + 0x1c0d4f2]
002be7a6  448be0                   mov r12d, eax
002be7a9  83f801                   cmp eax, 1
002be7ac  0f84b5756701             je 0x1935d67
002be7b2  4585e4                   test r12d, r12d
002be7b5  0f853b766701             jne 0x1935df6
002be7bb  b001                     mov al, 1
002be7bd  4183fc06                 cmp r12d, 6
002be7c1  0f8441766701             je 0x1935e08
002be7c7  84c0                     test al, al
002be7c9  0f8452766701             je 0x1935e21
002be7cf  488d8c24b8000000         lea rcx, [rsp + 0xb8]
002be7d7  e8f433d4ff               call 0x1bd0
002be7dc  90                       nop
002be7dd  eb01                     jmp 0x2be7e0
002be7df  cc                       int3
002be7e0  65488b142558000000       mov rdx, qword ptr gs:[0x58]
002be7e9  488b0588c7c001           mov rax, qword ptr [rip + 0x1c0c788]
002be7f0  8b08                     mov ecx, dword ptr [rax]
002be7f2  488b0587c7c001           mov rax, qword ptr [rip + 0x1c0c787]
002be7f9  8b38                     mov edi, dword ptr [rax]
002be7fb  48033cca                 add rdi, qword ptr [rdx + rcx*8]
002be7ff  488b8f00010000           mov rcx, qword ptr [rdi + 0x100]
002be806  4885c9                   test rcx, rcx
002be809  0f8450766701             je 0x1935e5f
002be80f  83b92c02000000           cmp dword ptr [rcx + 0x22c], 0
002be816  0f8556766701             jne 0x1935e72
002be81c  4c8ba42440010000         mov r12, qword ptr [rsp + 0x140]
002be824  4d85e4                   test r12, r12
002be827  7428                     je 0x2be851
002be829  488bbc2448010000         mov rdi, qword ptr [rsp + 0x148]
002be831  4885ff                   test rdi, rdi
002be834  741b                     je 0x2be851
002be836  4d8bcd                   mov r9, r13
002be839  4d8bc6                   mov r8, r14
002be83c  488bd6                   mov rdx, rsi
002be83f  498bcc                   mov rcx, r12
002be842  ff15c8d3c001             call qword ptr [rip + 0x1c0d3c8]
002be848  83f802                   cmp eax, 2
002be84b  0f852e766701             jne 0x1935e7f
002be851  4c89bc2440010000         mov qword ptr [rsp + 0x140], r15
002be859  498bc4                   mov rax, r12
002be85c  4881c4e0000000           add rsp, 0xe0
002be863  415f                     pop r15
002be865  415e                     pop r14
002be867  415d                     pop r13
002be869  415c                     pop r12
002be86b  5f                       pop rdi
002be86c  5e                       pop rsi
002be86d  5b                       pop rbx
002be86e  c3                       ret
