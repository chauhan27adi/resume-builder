; CCostUtils::CardEstimateRebindsAndRewinds
; sqllang.dll, primary RVA 0x128c20, 693 bytes in 7 chunk(s)

; chunk at RVA 0x128c20 (67 bytes)
00128c20  488bc4                   mov rax, rsp
00128c23  53                       push rbx
00128c24  4156                     push r14
00128c26  4157                     push r15
00128c28  4883ec60                 sub rsp, 0x60
00128c2c  80bc24b000000000         cmp byte ptr [rsp + 0xb0], 0
00128c34  4d8bf8                   mov r15, r8
00128c37  4c8bb424d0000000         mov r14, qword ptr [rsp + 0xd0]
00128c3f  4c8bd1                   mov r10, rcx
00128c42  0f2970d8                 movaps xmmword ptr [rax - 0x28], xmm6
00128c46  f20f103512e5ee01         movsd xmm6, qword ptr [rip + 0x1eee512]
00128c4e  0f2978c8                 movaps xmmword ptr [rax - 0x38], xmm7
00128c52  f20f103dfee4ee01         movsd xmm7, qword ptr [rip + 0x1eee4fe]
00128c5a  440f2940b8               movaps xmmword ptr [rax - 0x48], xmm8
00128c5f  450f57c0                 xorps xmm8, xmm8

; chunk at RVA 0x128c63 (7 bytes)
00128c63  48897010                 mov qword ptr [rax + 0x10], rsi
00128c67  498bf1                   mov rsi, r9

; chunk at RVA 0x128c6a (39 bytes)
00128c6a  48897818                 mov qword ptr [rax + 0x18], rdi
00128c6e  488bfa                   mov rdi, rdx
00128c71  0f85c3532600             jne 0x38e03a
00128c77  837a1c01                 cmp dword ptr [rdx + 0x1c], 1
00128c7b  488b9c24c8000000         mov rbx, qword ptr [rsp + 0xc8]
00128c83  0f85eb532600             jne 0x38e074
00128c89  488b4228                 mov rax, qword ptr [rdx + 0x28]
00128c8d  4c8b4908                 mov r9, qword ptr [rcx + 8]

; chunk at RVA 0x128c91 (177 bytes)
00128c91  4889ac2480000000         mov qword ptr [rsp + 0x80], rbp
00128c99  488b28                   mov rbp, qword ptr [rax]
00128c9c  4d85c9                   test r9, r9
00128c9f  0f85d8303e01             jne 0x150bd7d
00128ca5  488b4910                 mov rcx, qword ptr [rcx + 0x10]
00128ca9  488b4130                 mov rax, qword ptr [rcx + 0x30]
00128cad  488b4918                 mov rcx, qword ptr [rcx + 0x18]
00128cb1  8b00                     mov eax, dword ptr [rax]
00128cb3  99                       cdq
00128cb4  0fb6d2                   movzx edx, dl
00128cb7  03c2                     add eax, edx
00128cb9  448bc0                   mov r8d, eax
00128cbc  0fb6c0                   movzx eax, al
00128cbf  2bc2                     sub eax, edx
00128cc1  41c1f808                 sar r8d, 8
00128cc5  488b5110                 mov rdx, qword ptr [rcx + 0x10]
00128cc9  488b8a30010000           mov rcx, qword ptr [rdx + 0x130]
00128cd0  488b4960                 mov rcx, qword ptr [rcx + 0x60]
00128cd4  443b410c                 cmp r8d, dword ptr [rcx + 0xc]
00128cd8  0f83c3303e01             jae 0x150bda1
00128cde  0faee8                   lfence
00128ce1  488b4918                 mov rcx, qword ptr [rcx + 0x18]
00128ce5  4d8b4a08                 mov r9, qword ptr [r10 + 8]
00128ce9  4a8b0cc1                 mov rcx, qword ptr [rcx + r8*8]
00128ced  eb01                     jmp 0x128cf0
00128cef  cc                       int3
00128cf0  488b0cc1                 mov rcx, qword ptr [rcx + rax*8]
00128cf4  4c8b5908                 mov r11, qword ptr [rcx + 8]
00128cf8  498bca                   mov rcx, r10
00128cfb  e89091f4ff               call 0x71e90
00128d00  488b8818030000           mov rcx, qword ptr [rax + 0x318]
00128d07  4d85c9                   test r9, r9
00128d0a  0f859d303e01             jne 0x150bdad
00128d10  498b4210                 mov rax, qword ptr [r10 + 0x10]
00128d14  488b5008                 mov rdx, qword ptr [rax + 8]
00128d18  488b01                   mov rax, qword ptr [rcx]
00128d1b  4d8bcb                   mov r9, r11
00128d1e  488b5210                 mov rdx, qword ptr [rdx + 0x10]
00128d22  4c8bc5                   mov r8, rbp
00128d25  48897c2428               mov qword ptr [rsp + 0x28], rdi
00128d2a  48895c2420               mov qword ptr [rsp + 0x20], rbx
00128d2f  ff5038                   call qword ptr [rax + 0x38]
00128d32  488bac2480000000         mov rbp, qword ptr [rsp + 0x80]
00128d3a  84c0                     test al, al
00128d3c  0f8432532600             je 0x38e074

; chunk at RVA 0x128d60 (149 bytes)
00128d60  660f2fc6                 comisd xmm0, xmm6
00128d64  0f8283303e01             jb 0x150bded
00128d6a  0f28d0                   movaps xmm2, xmm0
00128d6d  eb01                     jmp 0x128d70
00128d6f  cc                       int3
00128d70  f20f100b                 movsd xmm1, qword ptr [rbx]
00128d74  660f2fd1                 comisd xmm2, xmm1
00128d78  0f8761110000             ja 0x129edf
00128d7e  660f2ff8                 comisd xmm7, xmm0
00128d82  0f28d0                   movaps xmm2, xmm0
00128d85  0f8289303e01             jb 0x150be14
00128d8b  660f2fc6                 comisd xmm0, xmm6
00128d8f  0f8277303e01             jb 0x150be0c
00128d95  66440f2fc2               comisd xmm8, xmm2
00128d9a  0f878b303e01             ja 0x150be2b
00128da0  660f2ff8                 comisd xmm7, xmm0
00128da4  0f8292303e01             jb 0x150be3c
00128daa  660f2fc6                 comisd xmm0, xmm6
00128dae  0f8280303e01             jb 0x150be34
00128db4  0f28d0                   movaps xmm2, xmm0
00128db7  eb01                     jmp 0x128dba
00128db9  cc                       int3
00128dba  660f2fd1                 comisd xmm2, xmm1
00128dbe  7717                     ja 0x128dd7
00128dc0  660f2ff8                 comisd xmm7, xmm0
00128dc4  0f28c8                   movaps xmm1, xmm0
00128dc7  0f828e303e01             jb 0x150be5b
00128dcd  660f2fc6                 comisd xmm0, xmm6
00128dd1  0f827c303e01             jb 0x150be53
00128dd7  f20f110b                 movsd qword ptr [rbx], xmm1
00128ddb  f20f1006                 movsd xmm0, qword ptr [rsi]
00128ddf  488bb42488000000         mov rsi, qword ptr [rsp + 0x88]
00128de7  f20f5cc1                 subsd xmm0, xmm1
00128deb  660f2ff8                 comisd xmm7, xmm0
00128def  0f8285303e01             jb 0x150be7a

; chunk at RVA 0x128df5 (188 bytes)
00128df5  660f2fc6                 comisd xmm0, xmm6
00128df9  0f8273303e01             jb 0x150be72
00128dff  0f28c8                   movaps xmm1, xmm0
00128e02  eb01                     jmp 0x128e05
00128e04  cc                       int3
00128e05  f20f1015c3b2a102         movsd xmm2, qword ptr [rip + 0x2a1b2c3]
00128e0d  f20f5cca                 subsd xmm1, xmm2
00128e11  660f2ff9                 comisd xmm7, xmm1
00128e15  0f827e303e01             jb 0x150be99
00128e1b  660f2fce                 comisd xmm1, xmm6
00128e1f  0f826c303e01             jb 0x150be91
00128e25  66410f2fc8               comisd xmm1, xmm8
00128e2a  0f87b8100000             ja 0x129ee8
00128e30  0f57c0                   xorps xmm0, xmm0
00128e33  488b8424b8000000         mov rax, qword ptr [rsp + 0xb8]
00128e3b  f20f1100                 movsd qword ptr [rax], xmm0
00128e3f  f2410f100f               movsd xmm1, qword ptr [r15]
00128e44  66440f2ec1               ucomisd xmm8, xmm1
00128e49  7a06                     jp 0x128e51
00128e4b  0f8491303e01             je 0x150bee2
00128e51  f20f5ec1                 divsd xmm0, xmm1
00128e55  660f2ff8                 comisd xmm7, xmm0
00128e59  0f82a6303e01             jb 0x150bf05
00128e5f  660f2fc6                 comisd xmm0, xmm6
00128e63  0f8294303e01             jb 0x150befd
00128e69  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
00128e71  f20f1100                 movsd qword ptr [rax], xmm0
00128e75  f20f100b                 movsd xmm1, qword ptr [rbx]
00128e79  f2410f5e0f               divsd xmm1, qword ptr [r15]
00128e7e  660f2ff9                 comisd xmm7, xmm1
00128e82  0f829c303e01             jb 0x150bf24
00128e88  660f2fce                 comisd xmm1, xmm6
00128e8c  0f828a303e01             jb 0x150bf1c
00128e92  f2410f110e               movsd qword ptr [r14], xmm1
00128e97  0f28742450               movaps xmm6, xmmword ptr [rsp + 0x50]
00128e9c  0f287c2440               movaps xmm7, xmmword ptr [rsp + 0x40]
00128ea1  440f28442430             movaps xmm8, xmmword ptr [rsp + 0x30]
00128ea7  4883c460                 add rsp, 0x60
00128eab  415f                     pop r15
00128ead  415e                     pop r14
00128eaf  5b                       pop rbx
00128eb0  c3                       ret

; chunk at RVA 0x38e074 (66 bytes)
0038e074  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
0038e07c  f20f1006                 movsd xmm0, qword ptr [rsi]
0038e080  f20f5e00                 divsd xmm0, qword ptr [rax]
0038e084  660f2ff8                 comisd xmm7, xmm0
0038e088  0f8231dd1701             jb 0x150bdbf
0038e08e  660f2fc6                 comisd xmm0, xmm6
0038e092  0f821fdd1701             jb 0x150bdb7
0038e098  f20f5c0550ead801         subsd xmm0, qword ptr [rip + 0x1d8ea50]
0038e0a0  660f2ff8                 comisd xmm7, xmm0
0038e0a4  0f822cdd1701             jb 0x150bdd6
0038e0aa  660f2fc6                 comisd xmm0, xmm6
0038e0ae  73ba                     jae 0x38e06a
0038e0b0  0f28c6                   movaps xmm0, xmm6
0038e0b3  ebb5                     jmp 0x38e06a
0038e0b5  cc                       int3
