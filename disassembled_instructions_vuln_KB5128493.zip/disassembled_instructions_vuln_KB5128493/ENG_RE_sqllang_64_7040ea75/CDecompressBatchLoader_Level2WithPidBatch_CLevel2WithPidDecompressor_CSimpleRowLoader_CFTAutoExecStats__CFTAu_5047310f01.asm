; CDecompressBatchLoader<Level2WithPidBatch,CLevel2WithPidDecompressor,CSimpleRowLoader<CFTAutoExecStats>,CFTAutoExecStats>::LoadNextBatch
; sqllang.dll, primary RVA 0x973760, 1416 bytes in 1 chunk(s)

; chunk at RVA 0x973760 (1416 bytes)
00973760  488bc4                   mov rax, rsp
00973763  4c894820                 mov qword ptr [rax + 0x20], r9
00973767  895010                   mov dword ptr [rax + 0x10], edx
0097376a  55                       push rbp
0097376b  56                       push rsi
0097376c  57                       push rdi
0097376d  4154                     push r12
0097376f  4155                     push r13
00973771  4156                     push r14
00973773  4157                     push r15
00973775  488d68a1                 lea rbp, [rax - 0x5f]
00973779  4881ece0000000           sub rsp, 0xe0
00973780  48c74517feffffff         mov qword ptr [rbp + 0x17], 0xfffffffffffffffe
00973788  48895818                 mov qword ptr [rax + 0x18], rbx
0097378c  4d8be8                   mov r13, r8
0097378f  8bfa                     mov edi, edx
00973791  488bf1                   mov rsi, rcx
00973794  83792002                 cmp dword ptr [rcx + 0x20], 2
00973798  7507                     jne 0x9737a1
0097379a  33c0                     xor eax, eax
0097379c  e9cc040000               jmp 0x973c6d
009737a1  4533ff                   xor r15d, r15d
009737a4  44897da7                 mov dword ptr [rbp - 0x59], r15d
009737a8  4c897daf                 mov qword ptr [rbp - 0x51], r15
009737ac  44887db7                 mov byte ptr [rbp - 0x49], r15b
009737b0  0f57c0                   xorps xmm0, xmm0
009737b3  660f7f45c7               movdqa xmmword ptr [rbp - 0x39], xmm0
009737b8  0f57c9                   xorps xmm1, xmm1
009737bb  660f7f4dd7               movdqa xmmword ptr [rbp - 0x29], xmm1
009737c0  660f7f45e7               movdqa xmmword ptr [rbp - 0x19], xmm0
009737c5  4c897df7                 mov qword ptr [rbp - 9], r15
009737c9  c745ff01000000           mov dword ptr [rbp - 1], 1
009737d0  4c897d07                 mov qword ptr [rbp + 7], r15
009737d4  44897c2420               mov dword ptr [rsp + 0x20], r15d
009737d9  32c9                     xor cl, cl
009737db  884d67                   mov byte ptr [rbp + 0x67], cl
009737de  4c8d251bc868ff           lea r12, [rip - 0x9737e5]
009737e5  41c6451000               mov byte ptr [r13 + 0x10], 0
009737ea  80be4825000000           cmp byte ptr [rsi + 0x2548], 0
009737f1  0f8495000000             je 0x97388c
009737f7  c6864825000000           mov byte ptr [rsi + 0x2548], 0
009737fe  488b9e40250000           mov rbx, qword ptr [rsi + 0x2540]
00973805  4c8bc3                   mov r8, rbx
00973808  33d2                     xor edx, edx
0097380a  498bcd                   mov rcx, r13
0097380d  e83e97ffff               call 0x96cf50
00973812  488b5360                 mov rdx, qword ptr [rbx + 0x60]
00973816  418b4d00                 mov ecx, dword ptr [r13]
0097381a  ffc9                     dec ecx
0097381c  4803c9                   add rcx, rcx
0097381f  498b4560                 mov rax, qword ptr [r13 + 0x60]
00973823  0f1002                   movups xmm0, xmmword ptr [rdx]
00973826  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
0097382a  488b8640250000           mov rax, qword ptr [rsi + 0x2540]
00973831  ff08                     dec dword ptr [rax]
00973833  44897da7                 mov dword ptr [rbp - 0x59], r15d
00973837  498b4508                 mov rax, qword ptr [r13 + 8]
0097383b  488945af                 mov qword ptr [rbp - 0x51], rax
0097383f  418b5500                 mov edx, dword ptr [r13]
00973843  498b4520                 mov rax, qword ptr [r13 + 0x20]
00973847  488d0cd0                 lea rcx, [rax + rdx*8]
0097384b  48894dc7                 mov qword ptr [rbp - 0x39], rcx
0097384f  498b4528                 mov rax, qword ptr [r13 + 0x28]
00973853  488d0c90                 lea rcx, [rax + rdx*4]
00973857  48894dcf                 mov qword ptr [rbp - 0x31], rcx
0097385b  498b4530                 mov rax, qword ptr [r13 + 0x30]
0097385f  488d0c90                 lea rcx, [rax + rdx*4]
00973863  48894dd7                 mov qword ptr [rbp - 0x29], rcx
00973867  b801000000               mov eax, 1
0097386c  2bc2                     sub eax, edx
0097386e  03f8                     add edi, eax
00973870  897d6f                   mov dword ptr [rbp + 0x6f], edi
00973873  4c8d75a7                 lea r14, [rbp - 0x59]
00973877  c6864825000000           mov byte ptr [rsi + 0x2548], 0
0097387e  c744242001000000         mov dword ptr [rsp + 0x20], 1
00973886  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
0097388a  eb03                     jmp 0x97388f
0097388c  4d8bf5                   mov r14, r13
0097388f  837e2000                 cmp dword ptr [rsi + 0x20], 0
00973893  7555                     jne 0x9738ea
00973895  4c897c2428               mov qword ptr [rsp + 0x28], r15
0097389a  44897c2430               mov dword ptr [rsp + 0x30], r15d
0097389f  4c897c2438               mov qword ptr [rsp + 0x38], r15
009738a4  44897d87                 mov dword ptr [rbp - 0x79], r15d
009738a8  4c897d8f                 mov qword ptr [rbp - 0x71], r15
009738ac  44897d97                 mov dword ptr [rbp - 0x69], r15d
009738b0  6644897d9b               mov word ptr [rbp - 0x65], r15w
009738b5  488d4e28                 lea rcx, [rsi + 0x28]
009738b9  488b01                   mov rax, qword ptr [rcx]
009738bc  4d8bc1                   mov r8, r9
009738bf  488d542428               lea rdx, [rsp + 0x28]
009738c4  ff10                     call qword ptr [rax]
009738c6  c6456701                 mov byte ptr [rbp + 0x67], 1
009738ca  3dc60e0400               cmp eax, 0x40ec6
009738cf  0f8474030000             je 0x973c49
009738d5  488d4e38                 lea rcx, [rsi + 0x38]
009738d9  488d542428               lea rdx, [rsp + 0x28]
009738de  e8cd8ef5ff               call 0x8cc7b0
009738e3  c7462001000000           mov dword ptr [rsi + 0x20], 1
009738ea  488b4630                 mov rax, qword ptr [rsi + 0x30]
009738ee  4c8b8058010000           mov r8, qword ptr [rax + 0x158]
009738f5  4d894608                 mov qword ptr [r14 + 8], r8
009738f9  4d8b88e0000000           mov r9, qword ptr [r8 + 0xe0]
00973900  488b5630                 mov rdx, qword ptr [rsi + 0x30]
00973904  8b423c                   mov eax, dword ptr [rdx + 0x3c]
00973907  83e007                   and eax, 7
0097390a  83f805                   cmp eax, 5
0097390d  773c                     ja 0x97394b
0097390f  4898                     cdqe
00973911  418b8c84883c9700         mov ecx, dword ptr [r12 + rax*4 + 0x973c88]
00973919  4903cc                   add rcx, r12
0097391c  ffe1                     jmp rcx
0097391e  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973922  0f95c3                   setne bl
00973925  eb26                     jmp 0x97394d
00973927  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097392b  0f9dc3                   setge bl
0097392e  eb1d                     jmp 0x97394d
00973930  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973934  0f9ec3                   setle bl
00973937  eb14                     jmp 0x97394d
00973939  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
0097393d  0f9fc3                   setg bl
00973940  eb0b                     jmp 0x97394d
00973942  4c3b4a30                 cmp r9, qword ptr [rdx + 0x30]
00973946  0f9cc3                   setl bl
00973949  eb02                     jmp 0x97394d
0097394b  32db                     xor bl, bl
0097394d  4d8b88b8000000           mov r9, qword ptr [r8 + 0xb8]
00973954  8b424c                   mov eax, dword ptr [rdx + 0x4c]
00973957  83e007                   and eax, 7
0097395a  83f805                   cmp eax, 5
0097395d  7741                     ja 0x9739a0
0097395f  4898                     cdqe
00973961  418b8c84a03c9700         mov ecx, dword ptr [r12 + rax*4 + 0x973ca0]
00973969  4903cc                   add rcx, r12
0097396c  ffe1                     jmp rcx
0097396e  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973972  410f95c4                 setne r12b
00973976  eb2b                     jmp 0x9739a3
00973978  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097397c  410f9dc4                 setge r12b
00973980  eb21                     jmp 0x9739a3
00973982  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973986  410f9ec4                 setle r12b
0097398a  eb17                     jmp 0x9739a3
0097398c  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
00973990  410f9fc4                 setg r12b
00973994  eb0d                     jmp 0x9739a3
00973996  4c3b4a40                 cmp r9, qword ptr [rdx + 0x40]
0097399a  410f9cc4                 setl r12b
0097399e  eb03                     jmp 0x9739a3
009739a0  4532e4                   xor r12b, r12b
009739a3  4889751f                 mov qword ptr [rbp + 0x1f], rsi
009739a7  0f31                     rdtsc
009739a9  48c1e220                 shl rdx, 0x20
009739ad  480bc2                   or rax, rdx
009739b0  48894608                 mov qword ptr [rsi + 8], rax
009739b4  488d4e38                 lea rcx, [rsi + 0x38]
009739b8  4d8bc6                   mov r8, r14
009739bb  8bd7                     mov edx, edi
009739bd  e88eabffff               call 0x96e550
009739c2  84c0                     test al, al
009739c4  7504                     jne 0x9739ca
009739c6  44897e20                 mov dword ptr [rsi + 0x20], r15d
009739ca  418b06                   mov eax, dword ptr [r14]
009739cd  48014610                 add qword ptr [rsi + 0x10], rax
009739d1  0f31                     rdtsc
009739d3  48c1e220                 shl rdx, 0x20
009739d7  480bc2                   or rax, rdx
009739da  482b4608                 sub rax, qword ptr [rsi + 8]
009739de  480106                   add qword ptr [rsi], rax
009739e1  ff4618                   inc dword ptr [rsi + 0x18]
009739e4  418b06                   mov eax, dword ptr [r14]
009739e7  448bc0                   mov r8d, eax
009739ea  85c0                     test eax, eax
009739ec  0f84d2010000             je 0x973bc4
009739f2  84db                     test bl, bl
009739f4  7509                     jne 0x9739ff
009739f6  4584e4                   test r12b, r12b
009739f9  0f84c5010000             je 0x973bc4
009739ff  448bc8                   mov r9d, eax
00973a02  84db                     test bl, bl
00973a04  0f8486000000             je 0x973a90
00973a0a  458bd7                   mov r10d, r15d
00973a0d  4c8b5e30                 mov r11, qword ptr [rsi + 0x30]
00973a11  85c0                     test eax, eax
00973a13  7472                     je 0x973a87
00973a15  498b5e20                 mov rbx, qword ptr [r14 + 0x20]
00973a19  458b433c                 mov r8d, dword ptr [r11 + 0x3c]
00973a1d  4183e007                 and r8d, 7
00973a21  488d3dd8c568ff           lea rdi, [rip - 0x973a28]
00973a28  0f1f840000000000         nop dword ptr [rax + rax]
00973a30  418bca                   mov ecx, r10d
00973a33  4c8b0ccb                 mov r9, qword ptr [rbx + rcx*8]
00973a37  4183f805                 cmp r8d, 5
00973a3b  0f87ae000000             ja 0x973aef
00973a41  4963c8                   movsxd rcx, r8d
00973a44  8b948fb83c9700           mov edx, dword ptr [rdi + rcx*4 + 0x973cb8]
00973a4b  4803d7                   add rdx, rdi
00973a4e  ffe2                     jmp rdx
00973a50  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00973a54  0f94c1                   sete cl
00973a57  eb22                     jmp 0x973a7b
00973a59  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00973a5d  0f9cc1                   setl cl
00973a60  eb19                     jmp 0x973a7b
00973a62  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00973a66  0f9fc1                   setg cl
00973a69  eb10                     jmp 0x973a7b
00973a6b  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00973a6f  0f9ec1                   setle cl
00973a72  eb07                     jmp 0x973a7b
00973a74  4d3b4b30                 cmp r9, qword ptr [r11 + 0x30]
00973a78  0f9dc1                   setge cl
00973a7b  84c9                     test cl, cl
00973a7d  7570                     jne 0x973aef
00973a7f  41ffc2                   inc r10d
00973a82  443bd0                   cmp r10d, eax
00973a85  72a9                     jb 0x973a30
00973a87  45893e                   mov dword ptr [r14], r15d
00973a8a  418bc7                   mov eax, r15d
00973a8d  458bcf                   mov r9d, r15d
00973a90  458bc1                   mov r8d, r9d
00973a93  4584e4                   test r12b, r12b
00973a96  0f8428010000             je 0x973bc4
00973a9c  85c0                     test eax, eax
00973a9e  0f8420010000             je 0x973bc4
00973aa4  4c8b5e30                 mov r11, qword ptr [rsi + 0x30]
00973aa8  498b7e20                 mov rdi, qword ptr [r14 + 0x20]
00973aac  4c8d254dc568ff           lea r12, [rip - 0x973ab3]
00973ab3  0f1f4000                 nop dword ptr [rax]
00973ab7  660f1f840000000000       nop word ptr [rax + rax]
00973ac0  458bd1                   mov r10d, r9d
00973ac3  ffc8                     dec eax
00973ac5  448bc8                   mov r9d, eax
00973ac8  488b1cc7                 mov rbx, qword ptr [rdi + rax*8]
00973acc  418b4b4c                 mov ecx, dword ptr [r11 + 0x4c]
00973ad0  83e107                   and ecx, 7
00973ad3  458bc2                   mov r8d, r10d
00973ad6  83f905                   cmp ecx, 5
00973ad9  0f87e5000000             ja 0x973bc4
00973adf  4863c9                   movsxd rcx, ecx
00973ae2  418b948cd03c9700         mov edx, dword ptr [r12 + rcx*4 + 0x973cd0]
00973aea  4903d4                   add rdx, r12
00973aed  ffe2                     jmp rdx
00973aef  443bd0                   cmp r10d, eax
00973af2  7393                     jae 0x973a87
00973af4  448bc8                   mov r9d, eax
00973af7  4585d2                   test r10d, r10d
00973afa  7494                     je 0x973a90
00973afc  452bca                   sub r9d, r10d
00973aff  458bdf                   mov r11d, r15d
00973b02  7478                     je 0x973b7c
00973b04  498bd7                   mov rdx, r15
00973b07  498bdf                   mov rbx, r15
00973b0a  498bff                   mov rdi, r15
00973b0d  0f1f00                   nop dword ptr [rax]
00973b10  438d0413                 lea eax, [r11 + r10]
00973b14  448bc0                   mov r8d, eax
00973b17  498b4e20                 mov rcx, qword ptr [r14 + 0x20]
00973b1b  488b04c1                 mov rax, qword ptr [rcx + rax*8]
00973b1f  4889040f                 mov qword ptr [rdi + rcx], rax
00973b23  498b4e30                 mov rcx, qword ptr [r14 + 0x30]
00973b27  428b0481                 mov eax, dword ptr [rcx + r8*4]
00973b2b  89040b                   mov dword ptr [rbx + rcx], eax
00973b2e  498b4e28                 mov rcx, qword ptr [r14 + 0x28]
00973b32  428b0481                 mov eax, dword ptr [rcx + r8*4]
00973b36  89040b                   mov dword ptr [rbx + rcx], eax
00973b39  4d03c0                   add r8, r8
00973b3c  498b4638                 mov rax, qword ptr [r14 + 0x38]
00973b40  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00973b45  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00973b49  498b4648                 mov rax, qword ptr [r14 + 0x48]
00973b4d  4885c0                   test rax, rax
00973b50  7409                     je 0x973b5b
00973b52  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00973b57  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00973b5b  498b4660                 mov rax, qword ptr [r14 + 0x60]
00973b5f  420f1004c0               movups xmm0, xmmword ptr [rax + r8*8]
00973b64  0f110410                 movups xmmword ptr [rax + rdx], xmm0
00973b68  41ffc3                   inc r11d
00973b6b  4883c708                 add rdi, 8
00973b6f  4883c304                 add rbx, 4
00973b73  4883c210                 add rdx, 0x10
00973b77  453bd9                   cmp r11d, r9d
00973b7a  7294                     jb 0x973b10
00973b7c  45890e                   mov dword ptr [r14], r9d
00973b7f  418bc1                   mov eax, r9d
00973b82  e909ffffff               jmp 0x973a90
00973b87  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00973b8b  0f94c1                   sete cl
00973b8e  eb22                     jmp 0x973bb2
00973b90  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00973b94  0f9cc1                   setl cl
00973b97  eb19                     jmp 0x973bb2
00973b99  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00973b9d  0f9fc1                   setg cl
00973ba0  eb10                     jmp 0x973bb2
00973ba2  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00973ba6  0f9ec1                   setle cl
00973ba9  eb07                     jmp 0x973bb2
00973bab  493b5b40                 cmp rbx, qword ptr [r11 + 0x40]
00973baf  0f9dc1                   setge cl
00973bb2  84c9                     test cl, cl
00973bb4  750e                     jne 0x973bc4
00973bb6  418906                   mov dword ptr [r14], eax
00973bb9  448bc0                   mov r8d, eax
00973bbc  85c0                     test eax, eax
00973bbe  0f85fcfeffff             jne 0x973ac0
00973bc4  80be4925000000           cmp byte ptr [rsi + 0x2549], 0
00973bcb  7463                     je 0x973c30
00973bcd  458b06                   mov r8d, dword ptr [r14]
00973bd0  4585c0                   test r8d, r8d
00973bd3  745b                     je 0x973c30
00973bd5  c6864825000001           mov byte ptr [rsi + 0x2548], 1
00973bdc  418b1e                   mov ebx, dword ptr [r14]
00973bdf  ffcb                     dec ebx
00973be1  488bbe40250000           mov rdi, qword ptr [rsi + 0x2540]
00973be8  4d8bc6                   mov r8, r14
00973beb  8bd3                     mov edx, ebx
00973bed  488bcf                   mov rcx, rdi
00973bf0  e85b93ffff               call 0x96cf50
00973bf5  448bc3                   mov r8d, ebx
00973bf8  4d03c0                   add r8, r8
00973bfb  498b5660                 mov rdx, qword ptr [r14 + 0x60]
00973bff  8b0f                     mov ecx, dword ptr [rdi]
00973c01  ffc9                     dec ecx
00973c03  4803c9                   add rcx, rcx
00973c06  488b4760                 mov rax, qword ptr [rdi + 0x60]
00973c0a  420f1004c2               movups xmm0, xmmword ptr [rdx + r8*8]
00973c0f  0f1104c8                 movups xmmword ptr [rax + rcx*8], xmm0
00973c13  41ff0e                   dec dword ptr [r14]
00973c16  41c6451001               mov byte ptr [r13 + 0x10], 1
00973c1b  488b8640250000           mov rax, qword ptr [rsi + 0x2540]
00973c22  488b4820                 mov rcx, qword ptr [rax + 0x20]
00973c26  488b01                   mov rax, qword ptr [rcx]
00973c29  49894518                 mov qword ptr [r13 + 0x18], rax
00973c2d  458b06                   mov r8d, dword ptr [r14]
00973c30  8b442420                 mov eax, dword ptr [rsp + 0x20]
00973c34  4103c0                   add eax, r8d
00973c37  89442420                 mov dword ptr [rsp + 0x20], eax
00973c3b  7521                     jne 0x973c5e
00973c3d  8b7d6f                   mov edi, dword ptr [rbp + 0x6f]
00973c40  4c8b4d7f                 mov r9, qword ptr [rbp + 0x7f]
00973c44  e995fbffff               jmp 0x9737de
00973c49  c7462002000000           mov dword ptr [rsi + 0x20], 2
00973c50  41837d0000               cmp dword ptr [r13], 0
00973c55  410f95c7                 setne r15b
00973c59  418bc7                   mov eax, r15d
00973c5c  eb0f                     jmp 0x973c6d
00973c5e  41894500                 mov dword ptr [r13], eax
00973c62  0fb64d67                 movzx ecx, byte ptr [rbp + 0x67]
00973c66  f6d9                     neg cl
00973c68  1bc0                     sbb eax, eax
00973c6a  83c002                   add eax, 2
00973c6d  488b9c2430010000         mov rbx, qword ptr [rsp + 0x130]
00973c75  4881c4e0000000           add rsp, 0xe0
00973c7c  415f                     pop r15
00973c7e  415e                     pop r14
00973c80  415d                     pop r13
00973c82  415c                     pop r12
00973c84  5f                       pop rdi
00973c85  5e                       pop rsi
00973c86  5d                       pop rbp
00973c87  c3                       ret
00973c88  4b3997001e3997           cmp qword ptr [r15 - 0x68c6e200], rdx
00973c8f  0027                     add byte ptr [rdi], ah
00973c91  399700393997             cmp dword ptr [rdi - 0x68c6c700], edx
00973c97  0030                     add byte ptr [rax], dh
00973c99  399700423997             cmp dword ptr [rdi - 0x68c6be00], edx
00973c9f  00a03997006e             add byte ptr [rax + 0x6e009739], ah
00973ca5  399700783997             cmp dword ptr [rdi - 0x68c68800], edx
00973cab  008c3997008239           add byte ptr [rcx + rdi + 0x39820097], cl
00973cb2  97                       xchg edi, eax
00973cb3  0096399700ef             add byte ptr [rsi - 0x10ff68c7], dl
00973cb9  3a9700503a97             cmp dl, byte ptr [rdi - 0x68c5b000]
00973cbf  00593a                   add byte ptr [rcx + 0x3a], bl
00973cc2  97                       xchg edi, eax
00973cc3  006b3a                   add byte ptr [rbx + 0x3a], ch
00973cc6  97                       xchg edi, eax
00973cc7  00623a                   add byte ptr [rdx + 0x3a], ah
00973cca  97                       xchg edi, eax
00973ccb  00743a97                 add byte ptr [rdx + rdi - 0x69], dh
00973ccf  00c4                     add ah, al
00973cd1  3b9700873b97             cmp edx, dword ptr [rdi - 0x68c47900]
00973cd7  00903b9700a2             add byte ptr [rax - 0x5dff68c5], dl
00973cdd  3b9700993b97             cmp edx, dword ptr [rdi - 0x68c46700]
