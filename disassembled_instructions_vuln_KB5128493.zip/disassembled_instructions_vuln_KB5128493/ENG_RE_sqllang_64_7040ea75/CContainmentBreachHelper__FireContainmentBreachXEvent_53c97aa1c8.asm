; CContainmentBreachHelper::FireContainmentBreachXEvent
; sqllang.dll, primary RVA 0x322e20, 314 bytes in 3 chunk(s)

; chunk at RVA 0x322e20 (125 bytes)
00322e20  4053                     push rbx
00322e22  55                       push rbp
00322e23  56                       push rsi
00322e24  4154                     push r12
00322e26  4155                     push r13
00322e28  4156                     push r14
00322e2a  4157                     push r15
00322e2c  4881ec10010000           sub rsp, 0x110
00322e33  488b054e6e7b02           mov rax, qword ptr [rip + 0x27b6e4e]
00322e3a  4833c4                   xor rax, rsp
00322e3d  4889842400010000         mov qword ptr [rsp + 0x100], rax
00322e45  448bbc2470010000         mov r15d, dword ptr [rsp + 0x170]
00322e4d  33f6                     xor esi, esi
00322e4f  4c8bac2478010000         mov r13, qword ptr [rsp + 0x178]
00322e57  498be9                   mov rbp, r9
00322e5a  4c8be2                   mov r12, rdx
00322e5d  488bd9                   mov rbx, rcx
00322e60  4885c9                   test rcx, rcx
00322e63  0f84be540100             je 0x338327
00322e69  488b4908                 mov rcx, qword ptr [rcx + 8]
00322e6d  8b4120                   mov eax, dword ptr [rcx + 0x20]
00322e70  c1e803                   shr eax, 3
00322e73  a801                     test al, 1
00322e75  0f85255d5300             jne 0x858ba0
00322e7b  448b4920                 mov r9d, dword ptr [rcx + 0x20]
00322e7f  418bc1                   mov eax, r9d
00322e82  d1e8                     shr eax, 1
00322e84  a801                     test al, 1
00322e86  0f842e540100             je 0x3382ba
00322e8c  0fb68143020000           movzx eax, byte ptr [rcx + 0x243]
00322e93  f6d0                     not al
00322e95  a801                     test al, 1
00322e97  0f840d540100             je 0x3382aa

; chunk at RVA 0x322e9d (35 bytes)
00322e9d  488b8c2400010000         mov rcx, qword ptr [rsp + 0x100]
00322ea5  4833cc                   xor rcx, rsp
00322ea8  e8c3e1cdff               call 0x1070
00322ead  4881c410010000           add rsp, 0x110
00322eb4  415f                     pop r15
00322eb6  415e                     pop r14
00322eb8  415d                     pop r13
00322eba  415c                     pop r12
00322ebc  5e                       pop rsi
00322ebd  5d                       pop rbp
00322ebe  5b                       pop rbx
00322ebf  c3                       ret

; chunk at RVA 0x33832a (154 bytes)
0033832a  4889bc2460010000         mov qword ptr [rsp + 0x160], rdi
00338332  bfffffffff               mov edi, 0xffffffff
00338337  4885ed                   test rbp, rbp
0033833a  0f84b0085200             je 0x858bf0
00338340  8b7d48                   mov edi, dword ptr [rbp + 0x48]
00338343  83ff08                   cmp edi, 8
00338346  0f8499085200             je 0x858be5
0033834c  448bc6                   mov r8d, esi
0033834f  4885db                   test rbx, rbx
00338352  7447                     je 0x33839b
00338354  488b4b08                 mov rcx, qword ptr [rbx + 8]
00338358  488bd1                   mov rdx, rcx
0033835b  8b4120                   mov eax, dword ptr [rcx + 0x20]
0033835e  d1e8                     shr eax, 1
00338360  a801                     test al, 1
00338362  740d                     je 0x338371
00338364  4839b1a8010000           cmp qword ptr [rcx + 0x1a8], rsi
0033836b  0f85c9085200             jne 0x858c3a
00338371  4885ed                   test rbp, rbp
00338374  0f84c0085200             je 0x858c3a
0033837a  8b453c                   mov eax, dword ptr [rbp + 0x3c]
0033837d  85c0                     test eax, eax
0033837f  0f84b5085200             je 0x858c3a
00338385  448b4540                 mov r8d, dword ptr [rbp + 0x40]
00338389  8bf0                     mov esi, eax
0033838b  eb01                     jmp 0x33838e
0033838d  cc                       int3
0033838e  488b4a10                 mov rcx, qword ptr [rdx + 0x10]
00338392  4885c9                   test rcx, rcx
00338395  0f850db60000             jne 0x3439a8
0033839b  44897c2440               mov dword ptr [rsp + 0x40], r15d
003383a0  4d8bcc                   mov r9, r12
003383a3  4c896c2430               mov qword ptr [rsp + 0x30], r13
003383a8  8bd6                     mov edx, esi
003383aa  418bce                   mov ecx, r14d
003383ad  897c2428                 mov dword ptr [rsp + 0x28], edi
003383b1  e8ba9f0000               call 0x342370
003383b6  488bbc2460010000         mov rdi, qword ptr [rsp + 0x160]
003383be  e9daaafeff               jmp 0x322e9d
003383c3  cc                       int3
