; CTrustedMachine::ClearDbKeys
; aetm_enclave.dll, primary RVA 0xe2d0, 1306 bytes in 1 chunk(s)

; chunk at RVA 0xe2d0 (1306 bytes)
0000e2d0  89542410                 mov dword ptr [rsp + 0x10], edx
0000e2d4  48894c2408               mov qword ptr [rsp + 8], rcx
0000e2d9  53                       push rbx
0000e2da  55                       push rbp
0000e2db  56                       push rsi
0000e2dc  57                       push rdi
0000e2dd  4155                     push r13
0000e2df  4156                     push r14
0000e2e1  4883ec38                 sub rsp, 0x38
0000e2e5  4c8d99c0da4700           lea r11, [rcx + 0x47dac0]
0000e2ec  90                       nop
0000e2ed  0fb68100db4700           movzx eax, byte ptr [rcx + 0x47db00]
0000e2f4  4c8d81c0da5000           lea r8, [rcx + 0x50dac0]
0000e2fb  4c89842488000000         mov qword ptr [rsp + 0x88], r8
0000e303  488bf9                   mov rdi, rcx
0000e306  498bdb                   mov rbx, r11
0000e309  4d3bd8                   cmp r11, r8
0000e30c  7314                     jae 0xe322
0000e30e  6690                     nop
0000e310  84c0                     test al, al
0000e312  750e                     jne 0xe322
0000e314  4883c348                 add rbx, 0x48
0000e318  90                       nop
0000e319  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000e31d  493bd8                   cmp rbx, r8
0000e320  72ee                     jb 0xe310
0000e322  4c89642430               mov qword ptr [rsp + 0x30], r12
0000e327  48be00000000ffffffff     movabs rsi, 0xffffffff00000000
0000e331  4c897c2428               mov qword ptr [rsp + 0x28], r15
0000e336  48bd0000000001000000     movabs rbp, 0x100000000
0000e340  49b9398ee3388ee3380e     movabs r9, 0xe38e38e38e38e39
0000e34a  49be6766666666666666     movabs r14, 0x6666666666666667
0000e354  0f1f4000                 nop dword ptr [rax]
0000e358  0f1f840000000000         nop dword ptr [rax + rax]
0000e360  90                       nop
0000e361  410fb64040               movzx eax, byte ptr [r8 + 0x40]
0000e366  493bd8                   cmp rbx, r8
0000e369  0f844c040000             je 0xe7bb
0000e36f  395304                   cmp dword ptr [rbx + 4], edx
0000e372  0f850c040000             jne 0xe784
0000e378  90                       nop
0000e379  488bcb                   mov rcx, rbx
0000e37c  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000e380  492bcb                   sub rcx, r11
0000e383  498bc1                   mov rax, r9
0000e386  90                       nop
0000e387  48f7e9                   imul rcx
0000e38a  48c1fa02                 sar rdx, 2
0000e38e  488bc2                   mov rax, rdx
0000e391  48c1e83f                 shr rax, 0x3f
0000e395  4803d0                   add rdx, rax
0000e398  488b4338                 mov rax, qword ptr [rbx + 0x38]
0000e39c  48c1e820                 shr rax, 0x20
0000e3a0  4c63ea                   movsxd r13, edx
0000e3a3  49c1e520                 shl r13, 0x20
0000e3a7  4c0be8                   or r13, rax
0000e3aa  4983fdff                 cmp r13, -1
0000e3ae  0f84cc030000             je 0xe780
0000e3b4  4c8d97c85a5100           lea r10, [rdi + 0x515ac8]
0000e3bb  90                       nop
0000e3bc  0fb687e85a5100           movzx eax, byte ptr [rdi + 0x515ae8]
0000e3c3  4c8d8fc85a5600           lea r9, [rdi + 0x565ac8]
0000e3ca  498bca                   mov rcx, r10
0000e3cd  4d3bd1                   cmp r10, r9
0000e3d0  731e                     jae 0xe3f0
0000e3d2  84c0                     test al, al
0000e3d4  751a                     jne 0xe3f0
0000e3d6  4883c128                 add rcx, 0x28
0000e3da  90                       nop
0000e3db  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000e3df  493bc9                   cmp rcx, r9
0000e3e2  72ee                     jb 0xe3d2
0000e3e4  0f1f4000                 nop dword ptr [rax]
0000e3e8  0f1f840000000000         nop dword ptr [rax + rax]
0000e3f0  90                       nop
0000e3f1  410fb64120               movzx eax, byte ptr [r9 + 0x20]
0000e3f6  493bc9                   cmp rcx, r9
0000e3f9  0f84fc000000             je 0xe4fb
0000e3ff  4c3929                   cmp qword ptr [rcx], r13
0000e402  0f85bf000000             jne 0xe4c7
0000e408  90                       nop
0000e409  488bd1                   mov rdx, rcx
0000e40c  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000e410  492bd2                   sub rdx, r10
0000e413  90                       nop
0000e414  498bc6                   mov rax, r14
0000e417  48f7ea                   imul rdx
0000e41a  48c1fa04                 sar rdx, 4
0000e41e  488bc2                   mov rax, rdx
0000e421  48c1e83f                 shr rax, 0x3f
0000e425  4803d0                   add rdx, rax
0000e428  488b4118                 mov rax, qword ptr [rcx + 0x18]
0000e42c  48c1e820                 shr rax, 0x20
0000e430  90                       nop
0000e431  4c63c2                   movsxd r8, edx
0000e434  49c1e020                 shl r8, 0x20
0000e438  4c0bc0                   or r8, rax
0000e43b  498bc0                   mov rax, r8
0000e43e  48c1e820                 shr rax, 0x20
0000e442  8bd0                     mov edx, eax
0000e444  25ff1f0000               and eax, 0x1fff
0000e449  8bf8                     mov edi, eax
0000e44b  488d0480                 lea rax, [rax + rax*4]
0000e44f  450fb65cc221             movzx r11d, byte ptr [r10 + rax*8 + 0x21]
0000e455  90                       nop
0000e456  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000e45b  48c1e820                 shr rax, 0x20
0000e45f  413bc0                   cmp eax, r8d
0000e462  755c                     jne 0xe4c0
0000e464  4584db                   test r11b, r11b
0000e467  7457                     je 0xe4c0
0000e469  81e2ff1f0000             and edx, 0x1fff
0000e46f  90                       nop
0000e470  488d0492                 lea rax, [rdx + rdx*4]
0000e474  4d8d04c2                 lea r8, [r10 + rax*8]
0000e478  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000e47d  85c0                     test eax, eax
0000e47f  753f                     jne 0xe4c0
0000e481  488bd0                   mov rdx, rax
0000e484  4823d6                   and rdx, rsi
0000e487  4803d5                   add rdx, rbp
0000e48a  f0490fb15018             lock cmpxchg qword ptr [r8 + 0x18], rdx
0000e490  752e                     jne 0xe4c0
0000e492  41c6402000               mov byte ptr [r8 + 0x20], 0
0000e497  41c6402100               mov byte ptr [r8 + 0x21], 0
0000e49c  90                       nop
0000e49d  498b4018                 mov rax, qword ptr [r8 + 0x18]
0000e4a1  48c1e820                 shr rax, 0x20
0000e4a5  83f8ff                   cmp eax, -1
0000e4a8  7416                     je 0xe4c0
0000e4aa  49638200800500           movsxd rax, dword ptr [r10 + 0x58000]
0000e4b1  4189bc8200000500         mov dword ptr [r10 + rax*4 + 0x50000], edi
0000e4b9  41ff8200800500           inc dword ptr [r10 + 0x58000]
0000e4c0  48ff0d89744600           dec qword ptr [rip + 0x467489]
0000e4c7  493bc9                   cmp rcx, r9
0000e4ca  7304                     jae 0xe4d0
0000e4cc  4883c128                 add rcx, 0x28
0000e4d0  90                       nop
0000e4d1  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000e4d5  493bc9                   cmp rcx, r9
0000e4d8  0f8312ffffff             jae 0xe3f0
0000e4de  6690                     nop
0000e4e0  84c0                     test al, al
0000e4e2  0f8508ffffff             jne 0xe3f0
0000e4e8  4883c128                 add rcx, 0x28
0000e4ec  90                       nop
0000e4ed  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000e4f1  493bc9                   cmp rcx, r9
0000e4f4  72ea                     jb 0xe4e0
0000e4f6  e9f5feffff               jmp 0xe3f0
0000e4fb  488b7c2470               mov rdi, qword ptr [rsp + 0x70]
0000e500  90                       nop
0000e501  498bc5                   mov rax, r13
0000e504  48c1e820                 shr rax, 0x20
0000e508  8bc8                     mov ecx, eax
0000e50a  25ff1f0000               and eax, 0x1fff
0000e50f  448be0                   mov r12d, eax
0000e512  488d04c0                 lea rax, [rax + rax*8]
0000e516  4c8d34c500000000         lea r14, [rax*8]
0000e51e  410fb6943e01db4700       movzx edx, byte ptr [r14 + rdi + 0x47db01]
0000e527  90                       nop
0000e528  498b843ef8da4700         mov rax, qword ptr [r14 + rdi + 0x47daf8]
0000e530  48c1e820                 shr rax, 0x20
0000e534  413bc5                   cmp eax, r13d
0000e537  0f8595020000             jne 0xe7d2
0000e53d  84d2                     test dl, dl
0000e53f  0f848d020000             je 0xe7d2
0000e545  81e1ff1f0000             and ecx, 0x1fff
0000e54b  488dafb85a4100           lea rbp, [rdi + 0x415ab8]
0000e552  488d04c9                 lea rax, [rcx + rcx*8]
0000e556  4c8d3cc500000000         lea r15, [rax*8]
0000e55e  498b8c3ff0da4700         mov rcx, qword ptr [r15 + rdi + 0x47daf0]
0000e566  90                       nop
0000e567  488bc1                   mov rax, rcx
0000e56a  48c1e820                 shr rax, 0x20
0000e56e  25ff1f0000               and eax, 0x1fff
0000e573  488d0440                 lea rax, [rax + rax*2]
0000e577  4803c0                   add rax, rax
0000e57a  0fb654c529               movzx edx, byte ptr [rbp + rax*8 + 0x29]
0000e57f  90                       nop
0000e580  488b44c520               mov rax, qword ptr [rbp + rax*8 + 0x20]
0000e585  48c1e820                 shr rax, 0x20
0000e589  3bc1                     cmp eax, ecx
0000e58b  0f8541020000             jne 0xe7d2
0000e591  84d2                     test dl, dl
0000e593  0f8439020000             je 0xe7d2
0000e599  498b843ff0da4700         mov rax, qword ptr [r15 + rdi + 0x47daf0]
0000e5a1  be04000000               mov esi, 4
0000e5a6  48c1e820                 shr rax, 0x20
0000e5aa  25ff1f0000               and eax, 0x1fff
0000e5af  488d3c40                 lea rdi, [rax + rax*2]
0000e5b3  48c1e704                 shl rdi, 4
0000e5b7  4803fd                   add rdi, rbp
0000e5ba  660f1f440000             nop word ptr [rax + rax]
0000e5c0  488b0f                   mov rcx, qword ptr [rdi]
0000e5c3  4885c9                   test rcx, rcx
0000e5c6  7428                     je 0xe5f0
0000e5c8  488d5108                 lea rdx, [rcx + 8]
0000e5cc  b8ffffffff               mov eax, 0xffffffff
0000e5d1  f00fc102                 lock xadd dword ptr [rdx], eax
0000e5d5  83f801                   cmp eax, 1
0000e5d8  750f                     jne 0xe5e9
0000e5da  4885d2                   test rdx, rdx
0000e5dd  740a                     je 0xe5e9
0000e5df  488b01                   mov rax, qword ptr [rcx]
0000e5e2  ba01000000               mov edx, 1
0000e5e7  ff10                     call qword ptr [rax]
0000e5e9  48c70700000000           mov qword ptr [rdi], 0
0000e5f0  4883c708                 add rdi, 8
0000e5f4  4883ee01                 sub rsi, 1
0000e5f8  75c6                     jne 0xe5c0
0000e5fa  488b7c2470               mov rdi, qword ptr [rsp + 0x70]
0000e5ff  90                       nop
0000e600  4c8d9fc0da4700           lea r11, [rdi + 0x47dac0]
0000e607  430fb64c1e41             movzx ecx, byte ptr [r14 + r11 + 0x41]
0000e60d  90                       nop
0000e60e  4b8b441e38               mov rax, qword ptr [r14 + r11 + 0x38]
0000e613  48c1e820                 shr rax, 0x20
0000e617  413bc5                   cmp eax, r13d
0000e61a  0f85b2010000             jne 0xe7d2
0000e620  84c9                     test cl, cl
0000e622  0f84aa010000             je 0xe7d2
0000e628  4b8b4c1f30               mov rcx, qword ptr [r15 + r11 + 0x30]
0000e62d  90                       nop
0000e62e  488bc1                   mov rax, rcx
0000e631  48c1e820                 shr rax, 0x20
0000e635  25ff1f0000               and eax, 0x1fff
0000e63a  488d0440                 lea rax, [rax + rax*2]
0000e63e  4803c0                   add rax, rax
0000e641  0fb654c529               movzx edx, byte ptr [rbp + rax*8 + 0x29]
0000e646  90                       nop
0000e647  488b44c520               mov rax, qword ptr [rbp + rax*8 + 0x20]
0000e64c  48c1e820                 shr rax, 0x20
0000e650  3bc1                     cmp eax, ecx
0000e652  0f858a000000             jne 0xe6e2
0000e658  84d2                     test dl, dl
0000e65a  0f8482000000             je 0xe6e2
0000e660  4b8b441f30               mov rax, qword ptr [r15 + r11 + 0x30]
0000e665  48be00000000ffffffff     movabs rsi, 0xffffffff00000000
0000e66f  48c1e820                 shr rax, 0x20
0000e673  90                       nop
0000e674  25ff1f0000               and eax, 0x1fff
0000e679  488d1440                 lea rdx, [rax + rax*2]
0000e67d  48c1e204                 shl rdx, 4
0000e681  4803d5                   add rdx, rbp
0000e684  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000e688  85c0                     test eax, eax
0000e68a  7560                     jne 0xe6ec
0000e68c  488bc8                   mov rcx, rax
0000e68f  49b80000000001000000     movabs r8, 0x100000000
0000e699  4823ce                   and rcx, rsi
0000e69c  4903c8                   add rcx, r8
0000e69f  f0480fb14a20             lock cmpxchg qword ptr [rdx + 0x20], rcx
0000e6a5  7545                     jne 0xe6ec
0000e6a7  c6422800                 mov byte ptr [rdx + 0x28], 0
0000e6ab  c6422900                 mov byte ptr [rdx + 0x29], 0
0000e6af  90                       nop
0000e6b0  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000e6b4  48c1e820                 shr rax, 0x20
0000e6b8  83f8ff                   cmp eax, -1
0000e6bb  742f                     je 0xe6ec
0000e6bd  4b8b4c1f30               mov rcx, qword ptr [r15 + r11 + 0x30]
0000e6c2  48638500800600           movsxd rax, dword ptr [rbp + 0x68000]
0000e6c9  48c1e920                 shr rcx, 0x20
0000e6cd  81e1ff1f0000             and ecx, 0x1fff
0000e6d3  898c8500000600           mov dword ptr [rbp + rax*4 + 0x60000], ecx
0000e6da  ff8500800600             inc dword ptr [rbp + 0x68000]
0000e6e0  eb0a                     jmp 0xe6ec
0000e6e2  48be00000000ffffffff     movabs rsi, 0xffffffff00000000
0000e6ec  90                       nop
0000e6ed  48bd0000000001000000     movabs rbp, 0x100000000
0000e6f7  430fb64c1e41             movzx ecx, byte ptr [r14 + r11 + 0x41]
0000e6fd  90                       nop
0000e6fe  4b8b441e38               mov rax, qword ptr [r14 + r11 + 0x38]
0000e703  48c1e820                 shr rax, 0x20
0000e707  413bc5                   cmp eax, r13d
0000e70a  7551                     jne 0xe75d
0000e70c  84c9                     test cl, cl
0000e70e  744d                     je 0xe75d
0000e710  90                       nop
0000e711  4b8b441f38               mov rax, qword ptr [r15 + r11 + 0x38]
0000e716  85c0                     test eax, eax
0000e718  7543                     jne 0xe75d
0000e71a  488bc8                   mov rcx, rax
0000e71d  4823ce                   and rcx, rsi
0000e720  4803cd                   add rcx, rbp
0000e723  f04b0fb14c1f38           lock cmpxchg qword ptr [r15 + r11 + 0x38], rcx
0000e72a  7531                     jne 0xe75d
0000e72c  43c6441f4000             mov byte ptr [r15 + r11 + 0x40], 0
0000e732  43c6441f4100             mov byte ptr [r15 + r11 + 0x41], 0
0000e738  90                       nop
0000e739  4b8b441f38               mov rax, qword ptr [r15 + r11 + 0x38]
0000e73e  48c1e820                 shr rax, 0x20
0000e742  83f8ff                   cmp eax, -1
0000e745  7416                     je 0xe75d
0000e747  49638300800900           movsxd rax, dword ptr [r11 + 0x98000]
0000e74e  4589a48300000900         mov dword ptr [r11 + rax*4 + 0x90000], r12d
0000e756  41ff8300800900           inc dword ptr [r11 + 0x98000]
0000e75d  48ff0de4714600           dec qword ptr [rip + 0x4671e4]
0000e764  49be6766666666666666     movabs r14, 0x6666666666666667
0000e76e  4c8b842488000000         mov r8, qword ptr [rsp + 0x88]
0000e776  49b9398ee3388ee3380e     movabs r9, 0xe38e38e38e38e39
0000e780  8b542478                 mov edx, dword ptr [rsp + 0x78]
0000e784  493bd8                   cmp rbx, r8
0000e787  7304                     jae 0xe78d
0000e789  4883c348                 add rbx, 0x48
0000e78d  90                       nop
0000e78e  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000e792  493bd8                   cmp rbx, r8
0000e795  0f83c5fbffff             jae 0xe360
0000e79b  0f1f440000               nop dword ptr [rax + rax]
0000e7a0  84c0                     test al, al
0000e7a2  0f85b8fbffff             jne 0xe360
0000e7a8  4883c348                 add rbx, 0x48
0000e7ac  90                       nop
0000e7ad  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000e7b1  493bd8                   cmp rbx, r8
0000e7b4  72ea                     jb 0xe7a0
0000e7b6  e9a5fbffff               jmp 0xe360
0000e7bb  4c8b7c2428               mov r15, qword ptr [rsp + 0x28]
0000e7c0  4c8b642430               mov r12, qword ptr [rsp + 0x30]
0000e7c5  4883c438                 add rsp, 0x38
0000e7c9  415e                     pop r14
0000e7cb  415d                     pop r13
0000e7cd  5f                       pop rdi
0000e7ce  5e                       pop rsi
0000e7cf  5d                       pop rbp
0000e7d0  5b                       pop rbx
0000e7d1  c3                       ret
0000e7d2  ba5f000000               mov edx, 0x5f
0000e7d7  b94b010000               mov ecx, 0x14b
0000e7dc  448d4aa2                 lea r9d, [rdx - 0x5e]
0000e7e0  448d42b2                 lea r8d, [rdx - 0x4e]
0000e7e4  e857ac0000               call 0x19440
0000e7e9  cc                       int3
