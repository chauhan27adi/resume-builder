; CEsExecBase::~CEsExecBase
; aetm_enclave.dll, primary RVA 0x2e2a0, 372 bytes in 5 chunk(s)

; chunk at RVA 0x2e2a0 (49 bytes)
0002e2a0  48895c2418               mov qword ptr [rsp + 0x18], rbx
0002e2a5  48897c2420               mov qword ptr [rsp + 0x20], rdi
0002e2aa  4156                     push r14
0002e2ac  4883ec20                 sub rsp, 0x20
0002e2b0  488d0581680300           lea rax, [rip + 0x36881]
0002e2b7  4533f6                   xor r14d, r14d
0002e2ba  488901                   mov qword ptr [rcx], rax
0002e2bd  488bd9                   mov rbx, rcx
0002e2c0  488b4110                 mov rax, qword ptr [rcx + 0x10]
0002e2c4  4885c0                   test rax, rax
0002e2c7  0f84ea000000             je 0x2e3b7
0002e2cd  488b4938                 mov rcx, qword ptr [rcx + 0x38]

; chunk at RVA 0x2e2d1 (103 bytes)
0002e2d1  48896c2430               mov qword ptr [rsp + 0x30], rbp
0002e2d6  4885c9                   test rcx, rcx
0002e2d9  7436                     je 0x2e311
0002e2db  418bfe                   mov edi, r14d
0002e2de  66443b7014               cmp r14w, word ptr [rax + 0x14]
0002e2e3  732c                     jae 0x2e311
0002e2e5  6666660f1f840000000000   nop word ptr [rax + rax]
0002e2f0  488b4b38                 mov rcx, qword ptr [rbx + 0x38]
0002e2f4  8bc7                     mov eax, edi
0002e2f6  488b0cc1                 mov rcx, qword ptr [rcx + rax*8]
0002e2fa  e8ddeb0200               call 0x5cedc
0002e2ff  488b4310                 mov rax, qword ptr [rbx + 0x10]
0002e303  ffc7                     inc edi
0002e305  0fb74814                 movzx ecx, word ptr [rax + 0x14]
0002e309  3bf9                     cmp edi, ecx
0002e30b  72e3                     jb 0x2e2f0
0002e30d  488b4b38                 mov rcx, qword ptr [rbx + 0x38]
0002e311  e8c6eb0200               call 0x5cedc
0002e316  488b4b30                 mov rcx, qword ptr [rbx + 0x30]
0002e31a  488b6b28                 mov rbp, qword ptr [rbx + 0x28]
0002e31e  488b7b10                 mov rdi, qword ptr [rbx + 0x10]
0002e322  4885c9                   test rcx, rcx
0002e325  7405                     je 0x2e32c
0002e327  e8b0eb0200               call 0x5cedc
0002e32c  4885ed                   test rbp, rbp
0002e32f  7436                     je 0x2e367
0002e331  8b4730                   mov eax, dword ptr [rdi + 0x30]
0002e334  85c0                     test eax, eax
0002e336  7427                     je 0x2e35f

; chunk at RVA 0x2e338 (39 bytes)
0002e338  4889742438               mov qword ptr [rsp + 0x38], rsi
0002e33d  488bfd                   mov rdi, rbp
0002e340  8bf0                     mov esi, eax
0002e342  488b0f                   mov rcx, qword ptr [rdi]
0002e345  4885c9                   test rcx, rcx
0002e348  7406                     je 0x2e350
0002e34a  488b01                   mov rax, qword ptr [rcx]
0002e34d  ff5070                   call qword ptr [rax + 0x70]
0002e350  4883c708                 add rdi, 8
0002e354  4883ee01                 sub rsi, 1
0002e358  75e8                     jne 0x2e342
0002e35a  488b742438               mov rsi, qword ptr [rsp + 0x38]

; chunk at RVA 0x2e35f (22 bytes)
0002e35f  488bcd                   mov rcx, rbp
0002e362  e875eb0200               call 0x5cedc
0002e367  488b4b40                 mov rcx, qword ptr [rbx + 0x40]
0002e36b  488b6c2430               mov rbp, qword ptr [rsp + 0x30]
0002e370  4885c9                   test rcx, rcx
0002e373  7442                     je 0x2e3b7

; chunk at RVA 0x2e375 (159 bytes)
0002e375  488b4310                 mov rax, qword ptr [rbx + 0x10]
0002e379  418bfe                   mov edi, r14d
0002e37c  44397078                 cmp dword ptr [rax + 0x78], r14d
0002e380  7630                     jbe 0x2e3b2
0002e382  488bd1                   mov rdx, rcx
0002e385  8bc7                     mov eax, edi
0002e387  4c8b04c1                 mov r8, qword ptr [rcx + rax*8]
0002e38b  4d85c0                   test r8, r8
0002e38e  7414                     je 0x2e3a4
0002e390  498b00                   mov rax, qword ptr [r8]
0002e393  ba01000000               mov edx, 1
0002e398  498bc8                   mov rcx, r8
0002e39b  ff10                     call qword ptr [rax]
0002e39d  488b4b40                 mov rcx, qword ptr [rbx + 0x40]
0002e3a1  488bd1                   mov rdx, rcx
0002e3a4  488b4310                 mov rax, qword ptr [rbx + 0x10]
0002e3a8  ffc7                     inc edi
0002e3aa  3b7878                   cmp edi, dword ptr [rax + 0x78]
0002e3ad  72d6                     jb 0x2e385
0002e3af  488bca                   mov rcx, rdx
0002e3b2  e825eb0200               call 0x5cedc
0002e3b7  488b4b58                 mov rcx, qword ptr [rbx + 0x58]
0002e3bb  4885c9                   test rcx, rcx
0002e3be  7443                     je 0x2e403
0002e3c0  418bfe                   mov edi, r14d
0002e3c3  66443b7360               cmp r14w, word ptr [rbx + 0x60]
0002e3c8  732b                     jae 0x2e3f5
0002e3ca  660f1f440000             nop word ptr [rax + rax]
0002e3d0  488b4b58                 mov rcx, qword ptr [rbx + 0x58]
0002e3d4  8bc7                     mov eax, edi
0002e3d6  488b14c1                 mov rdx, qword ptr [rcx + rax*8]
0002e3da  4885d2                   test rdx, rdx
0002e3dd  740c                     je 0x2e3eb
0002e3df  488bca                   mov rcx, rdx
0002e3e2  e8f5ea0200               call 0x5cedc
0002e3e7  488b4b58                 mov rcx, qword ptr [rbx + 0x58]
0002e3eb  0fb74360                 movzx eax, word ptr [rbx + 0x60]
0002e3ef  ffc7                     inc edi
0002e3f1  3bf8                     cmp edi, eax
0002e3f3  72db                     jb 0x2e3d0
0002e3f5  e8e2ea0200               call 0x5cedc
0002e3fa  4c897358                 mov qword ptr [rbx + 0x58], r14
0002e3fe  6644897360               mov word ptr [rbx + 0x60], r14w
0002e403  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
0002e408  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
0002e40d  4883c420                 add rsp, 0x20
0002e411  415e                     pop r14
0002e413  c3                       ret
