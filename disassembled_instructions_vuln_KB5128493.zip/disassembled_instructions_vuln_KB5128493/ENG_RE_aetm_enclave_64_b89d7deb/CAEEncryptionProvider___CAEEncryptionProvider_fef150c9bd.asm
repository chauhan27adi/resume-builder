; CAEEncryptionProvider::~CAEEncryptionProvider
; aetm_enclave.dll, primary RVA 0x19e20, 71 bytes in 1 chunk(s)

; chunk at RVA 0x19e20 (71 bytes)
00019e20  4053                     push rbx
00019e22  4883ec20                 sub rsp, 0x20
00019e26  488bd9                   mov rbx, rcx
00019e29  488b4970                 mov rcx, qword ptr [rcx + 0x70]
00019e2d  4885c9                   test rcx, rcx
00019e30  7413                     je 0x19e45
00019e32  488b01                   mov rax, qword ptr [rcx]
00019e35  ba01000000               mov edx, 1
00019e3a  ff5010                   call qword ptr [rax + 0x10]
00019e3d  48c7437000000000         mov qword ptr [rbx + 0x70], 0
00019e45  488b4b78                 mov rcx, qword ptr [rbx + 0x78]
00019e49  4885c9                   test rcx, rcx
00019e4c  7413                     je 0x19e61
00019e4e  488b01                   mov rax, qword ptr [rcx]
00019e51  ba01000000               mov edx, 1
00019e56  ff5010                   call qword ptr [rax + 0x10]
00019e59  48c7437800000000         mov qword ptr [rbx + 0x78], 0
00019e61  4883c420                 add rsp, 0x20
00019e65  5b                       pop rbx
00019e66  c3                       ret
