; `CResourceContainer<CTrustedMachine::CEKSetInfo,2048>::~CResourceContainer<CTrustedMachine::CEKSetInfo,2048>'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x5fbc0, 42 bytes in 1 chunk(s)

; chunk at RVA 0x5fbc0 (42 bytes)
0005fbc0  4055                     push rbp
0005fbc2  4883ec20                 sub rsp, 0x20
0005fbc6  488bea                   mov rbp, rdx
0005fbc9  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0005fbcd  4c8d0d0c9ffaff           lea r9, [rip - 0x560f4]
0005fbd4  41b800080000             mov r8d, 0x800
0005fbda  ba30000000               mov edx, 0x30
0005fbdf  e83cd3ffff               call 0x5cf20
0005fbe4  4883c420                 add rsp, 0x20
0005fbe8  5d                       pop rbp
0005fbe9  c3                       ret
