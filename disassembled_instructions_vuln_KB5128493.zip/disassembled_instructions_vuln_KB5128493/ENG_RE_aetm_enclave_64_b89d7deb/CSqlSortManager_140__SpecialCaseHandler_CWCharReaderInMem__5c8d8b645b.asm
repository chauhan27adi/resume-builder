; CSqlSortManager_140::SpecialCaseHandler<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x5c780, 1756 bytes in 1 chunk(s)

; chunk at RVA 0x5c780 (1756 bytes)
0005c780  48895c2418               mov qword ptr [rsp + 0x18], rbx
0005c785  55                       push rbp
0005c786  56                       push rsi
0005c787  57                       push rdi
0005c788  4154                     push r12
0005c78a  4155                     push r13
0005c78c  4156                     push r14
0005c78e  4157                     push r15
0005c790  4881ec80000000           sub rsp, 0x80
0005c797  488b8424f0000000         mov rax, qword ptr [rsp + 0xf0]
0005c79f  458be8                   mov r13d, r8d
0005c7a2  488bbc24e0000000         mov rdi, qword ptr [rsp + 0xe0]
0005c7aa  488b9c24e8000000         mov rbx, qword ptr [rsp + 0xe8]
0005c7b2  4c8bb42418010000         mov r14, qword ptr [rsp + 0x118]
0005c7ba  4c8bbc2410010000         mov r15, qword ptr [rsp + 0x110]
0005c7c2  488bac2420010000         mov rbp, qword ptr [rsp + 0x120]
0005c7ca  488bb42448010000         mov rsi, qword ptr [rsp + 0x148]
0005c7d2  4c8b9c2450010000         mov r11, qword ptr [rsp + 0x150]
0005c7da  4c8ba42458010000         mov r12, qword ptr [rsp + 0x158]
0005c7e2  4c8b942460010000         mov r10, qword ptr [rsp + 0x160]
0005c7ea  4c8b842468010000         mov r8, qword ptr [rsp + 0x168]
0005c7f2  4889442470               mov qword ptr [rsp + 0x70], rax
0005c7f7  488b842408010000         mov rax, qword ptr [rsp + 0x108]
0005c7ff  4889442460               mov qword ptr [rsp + 0x60], rax
0005c804  8b842428010000           mov eax, dword ptr [rsp + 0x128]
0005c80b  48894c2458               mov qword ptr [rsp + 0x58], rcx
0005c810  89442444                 mov dword ptr [rsp + 0x44], eax
0005c814  498b01                   mov rax, qword ptr [r9]
0005c817  488bc8                   mov rcx, rax
0005c81a  4889542450               mov qword ptr [rsp + 0x50], rdx
0005c81f  48c1e928                 shr rcx, 0x28
0005c823  0fb6d1                   movzx edx, cl
0005c826  4c894c2468               mov qword ptr [rsp + 0x68], r9
0005c82b  48897c2448               mov qword ptr [rsp + 0x48], rdi
0005c830  83fa15                   cmp edx, 0x15
0005c833  0f87ae050000             ja 0x5cde7
0005c839  8bca                     mov ecx, edx
0005c83b  488d15be37faff           lea rdx, [rip - 0x5c842]
0005c842  8b948a04ce0500           mov edx, dword ptr [rdx + rcx*4 + 0x5ce04]
0005c849  488d0db037faff           lea rcx, [rip - 0x5c850]
0005c850  4803d1                   add rdx, rcx
0005c853  ffe2                     jmp rdx
0005c855  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0005c85d  0f8584050000             jne 0x5cde7
0005c863  488b8c2430010000         mov rcx, qword ptr [rsp + 0x130]
0005c86b  4183e502                 and r13d, 2
0005c86f  488b16                   mov rdx, qword ptr [rsi]
0005c872  4883c102                 add rcx, 2
0005c876  483bd1                   cmp rdx, rcx
0005c879  730d                     jae 0x5c888
0005c87b  807afe14                 cmp byte ptr [rdx - 2], 0x14
0005c87f  7707                     ja 0x5c888
0005c881  bf01000000               mov edi, 1
0005c886  eb02                     jmp 0x5c88a
0005c888  33ff                     xor edi, edi
0005c88a  4585ed                   test r13d, r13d
0005c88d  7408                     je 0x5c897
0005c88f  85ff                     test edi, edi
0005c891  0f8550050000             jne 0x5cde7
0005c897  498b13                   mov rdx, qword ptr [r11]
0005c89a  483b942438010000         cmp rdx, qword ptr [rsp + 0x138]
0005c8a2  761b                     jbe 0x5c8bf
0005c8a4  0fb6c8                   movzx ecx, al
0005c8a7  0fb642ff                 movzx eax, byte ptr [rdx - 1]
0005c8ab  03c8                     add ecx, eax
0005c8ad  b8ff000000               mov eax, 0xff
0005c8b2  3bc8                     cmp ecx, eax
0005c8b4  0f47c8                   cmova ecx, eax
0005c8b7  884aff                   mov byte ptr [rdx - 1], cl
0005c8ba  e928050000               jmp 0x5cde7
0005c8bf  8802                     mov byte ptr [rdx], al
0005c8c1  49ff03                   inc qword ptr [r11]
0005c8c4  e91e050000               jmp 0x5cde7
0005c8c9  448b5b08                 mov r11d, dword ptr [rbx + 8]
0005c8cd  4c8d530e                 lea r10, [rbx + 0xe]
0005c8d1  488bc8                   mov rcx, rax
0005c8d4  48c1e820                 shr rax, 0x20
0005c8d8  48c1e908                 shr rcx, 8
0005c8dc  0fb6d1                   movzx edx, cl
0005c8df  0fb6c8                   movzx ecx, al
0005c8e2  48c1e208                 shl rdx, 8
0005c8e6  480bd1                   or rdx, rcx
0005c8e9  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0005c8ee  488b81a8000000           mov rax, qword ptr [rcx + 0xa8]
0005c8f5  440fb70490               movzx r8d, word ptr [rax + rdx*4]
0005c8fa  0fb7749002               movzx esi, word ptr [rax + rdx*4 + 2]
0005c8ff  488d530c                 lea rdx, [rbx + 0xc]
0005c903  488b03                   mov rax, qword ptr [rbx]
0005c906  493bc2                   cmp rax, r10
0005c909  741a                     je 0x5c925
0005c90b  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
0005c90f  4883c002                 add rax, 2
0005c913  488903                   mov qword ptr [rbx], rax
0005c916  66448902                 mov word ptr [rdx], r8w
0005c91a  66418932                 mov word ptr [r10], si
0005c91e  4885c9                   test rcx, rcx
0005c921  751e                     jne 0x5c941
0005c923  eb15                     jmp 0x5c93a
0005c925  488b4310                 mov rax, qword ptr [rbx + 0x10]
0005c929  33ff                     xor edi, edi
0005c92b  48897b10                 mov qword ptr [rbx + 0x10], rdi
0005c92f  488903                   mov qword ptr [rbx], rax
0005c932  66448902                 mov word ptr [rdx], r8w
0005c936  66418932                 mov word ptr [r10], si
0005c93a  488b03                   mov rax, qword ptr [rbx]
0005c93d  48894310                 mov qword ptr [rbx + 0x10], rax
0005c941  488913                   mov qword ptr [rbx], rdx
0005c944  418d4301                 lea eax, [r11 + 1]
0005c948  488b542450               mov rdx, qword ptr [rsp + 0x50]
0005c94d  894308                   mov dword ptr [rbx + 8], eax
0005c950  488b4208                 mov rax, qword ptr [rdx + 8]
0005c954  428b1480                 mov edx, dword ptr [rax + r8*4]
0005c958  0fb7c2                   movzx eax, dx
0005c95b  48c1e020                 shl rax, 0x20
0005c95f  48c1ea10                 shr rdx, 0x10
0005c963  480bc2                   or rax, rdx
0005c966  498901                   mov qword ptr [r9], rax
0005c969  b801000000               mov eax, 1
0005c96e  e976040000               jmp 0x5cde9
0005c973  488b542448               mov rdx, qword ptr [rsp + 0x48]
0005c978  4c8d442478               lea r8, [rsp + 0x78]
0005c97d  33ff                     xor edi, edi
0005c97f  498bc9                   mov rcx, r9
0005c982  897c2478                 mov dword ptr [rsp + 0x78], edi
0005c986  e8a557ffff               call 0x52130
0005c98b  39bc24f8000000           cmp dword ptr [rsp + 0xf8], edi
0005c992  0f853a030000             jne 0x5ccd2
0005c998  8b4c2478                 mov ecx, dword ptr [rsp + 0x78]
0005c99c  85c9                     test ecx, ecx
0005c99e  0f842e030000             je 0x5ccd2
0005c9a4  498b0424                 mov rax, qword ptr [r12]
0005c9a8  4c63442444               movsxd r8, dword ptr [rsp + 0x44]
0005c9ad  8808                     mov byte ptr [rax], cl
0005c9af  498b0c24                 mov rcx, qword ptr [r12]
0005c9b3  0fb6442479               movzx eax, byte ptr [rsp + 0x79]
0005c9b8  41880408                 mov byte ptr [r8 + rcx], al
0005c9bc  410fbae510               bt r13d, 0x10
0005c9c1  7213                     jb 0x5c9d6
0005c9c3  498b0c24                 mov rcx, qword ptr [r12]
0005c9c7  438d0400                 lea eax, [r8 + r8]
0005c9cb  4863d0                   movsxd rdx, eax
0005c9ce  0fb644247a               movzx eax, byte ptr [rsp + 0x7a]
0005c9d3  88040a                   mov byte ptr [rdx + rcx], al
0005c9d6  410fbae511               bt r13d, 0x11
0005c9db  7213                     jb 0x5c9f0
0005c9dd  498b0c24                 mov rcx, qword ptr [r12]
0005c9e1  438d0440                 lea eax, [r8 + r8*2]
0005c9e5  4863d0                   movsxd rdx, eax
0005c9e8  0fb644247b               movzx eax, byte ptr [rsp + 0x7b]
0005c9ed  88040a                   mov byte ptr [rdx + rcx], al
0005c9f0  49ff0424                 inc qword ptr [r12]
0005c9f4  b801000000               mov eax, 1
0005c9f9  e9eb030000               jmp 0x5cde9
0005c9fe  488b442448               mov rax, qword ptr [rsp + 0x48]
0005ca03  33ff                     xor edi, edi
0005ca05  b960110000               mov ecx, 0x1160
0005ca0a  488938                   mov qword ptr [rax], rdi
0005ca0d  488b03                   mov rax, qword ptr [rbx]
0005ca10  663908                   cmp word ptr [rax], cx
0005ca13  0f83c8020000             jae 0x5cce1
0005ca19  488b542450               mov rdx, qword ptr [rsp + 0x50]
0005ca1e  488d442444               lea rax, [rsp + 0x44]
0005ca23  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0005ca28  4c8d4c2440               lea r9, [rsp + 0x40]
0005ca2d  4889442430               mov qword ptr [rsp + 0x30], rax
0005ca32  4c8bc3                   mov r8, rbx
0005ca35  488d442478               lea rax, [rsp + 0x78]
0005ca3a  c744242803000000         mov dword ptr [rsp + 0x28], 3
0005ca42  4889442420               mov qword ptr [rsp + 0x20], rax
0005ca47  e8c44dffff               call 0x51810
0005ca4c  448be8                   mov r13d, eax
0005ca4f  85c0                     test eax, eax
0005ca51  0f8e85020000             jle 0x5ccdc
0005ca57  39bc24f8000000           cmp dword ptr [rsp + 0xf8], edi
0005ca5e  0f84d2010000             je 0x5cc36
0005ca64  48634d00                 movsxd rcx, dword ptr [rbp]
0005ca68  41bc07020000             mov r12d, 0x207
0005ca6e  440fb7442440             movzx r8d, word ptr [rsp + 0x40]
0005ca74  8bb42400010000           mov esi, dword ptr [rsp + 0x100]
0005ca7b  410fb7d0                 movzx edx, r8w
0005ca7f  4c8b4c2460               mov r9, qword ptr [rsp + 0x60]
0005ca84  66c1ea08                 shr dx, 8
0005ca88  42881431                 mov byte ptr [rcx + r14], dl
0005ca8c  48634d00                 movsxd rcx, dword ptr [rbp]
0005ca90  8d4101                   lea eax, [rcx + 1]
0005ca93  894500                   mov dword ptr [rbp], eax
0005ca96  4688443101               mov byte ptr [rcx + r14 + 1], r8b
0005ca9b  ff4500                   inc dword ptr [rbp]
0005ca9e  837d0004                 cmp dword ptr [rbp], 4
0005caa2  0f8599000000             jne 0x5cb41
0005caa8  897d00                   mov dword ptr [rbp], edi
0005caab  458b01                   mov r8d, dword ptr [r9]
0005caae  418b16                   mov edx, dword ptr [r14]
0005cab1  85f6                     test esi, esi
0005cab3  7537                     jne 0x5caec
0005cab5  41c1c003                 rol r8d, 3
0005cab9  418bc0                   mov eax, r8d
0005cabc  33c2                     xor eax, edx
0005cabe  418901                   mov dword ptr [r9], eax
0005cac1  6645396602               cmp word ptr [r14 + 2], r12w
0005cac6  7405                     je 0x5cacd
0005cac8  418907                   mov dword ptr [r15], eax
0005cacb  eb74                     jmp 0x5cb41
0005cacd  410fb706                 movzx eax, word ptr [r14]
0005cad1  66413bc4                 cmp ax, r12w
0005cad5  746a                     je 0x5cb41
0005cad7  0fb6c8                   movzx ecx, al
0005cada  4133c8                   xor ecx, r8d
0005cadd  41890f                   mov dword ptr [r15], ecx
0005cae0  410fb64601               movzx eax, byte ptr [r14 + 1]
0005cae5  c1c103                   rol ecx, 3
0005cae8  33c8                     xor ecx, eax
0005caea  eb52                     jmp 0x5cb3e
0005caec  4569d020080000           imul r10d, r8d, 0x820
0005caf3  418bc0                   mov eax, r8d
0005caf6  c1e802                   shr eax, 2
0005caf9  4403d0                   add r10d, eax
0005cafc  418d0412                 lea eax, [r10 + rdx]
0005cb00  4133c0                   xor eax, r8d
0005cb03  418901                   mov dword ptr [r9], eax
0005cb06  6645396602               cmp word ptr [r14 + 2], r12w
0005cb0b  7405                     je 0x5cb12
0005cb0d  418907                   mov dword ptr [r15], eax
0005cb10  eb2f                     jmp 0x5cb41
0005cb12  410fb706                 movzx eax, word ptr [r14]
0005cb16  66413bc4                 cmp ax, r12w
0005cb1a  7425                     je 0x5cb41
0005cb1c  0fb6d0                   movzx edx, al
0005cb1f  4103d2                   add edx, r10d
0005cb22  4133d0                   xor edx, r8d
0005cb25  69c220080000             imul eax, edx, 0x820
0005cb2b  418917                   mov dword ptr [r15], edx
0005cb2e  410fb64e01               movzx ecx, byte ptr [r14 + 1]
0005cb33  03c8                     add ecx, eax
0005cb35  8bc2                     mov eax, edx
0005cb37  c1e802                   shr eax, 2
0005cb3a  03c8                     add ecx, eax
0005cb3c  33ca                     xor ecx, edx
0005cb3e  41890f                   mov dword ptr [r15], ecx
0005cb41  4c8b5c2470               mov r11, qword ptr [rsp + 0x70]
0005cb46  b800ff0000               mov eax, 0xff00
0005cb4b  0fb6542478               movzx edx, byte ptr [rsp + 0x78]
0005cb50  660bd0                   or dx, ax
0005cb53  0fb7ca                   movzx ecx, dx
0005cb56  6641ff03                 inc word ptr [r11]
0005cb5a  48634500                 movsxd rax, dword ptr [rbp]
0005cb5e  66c1e908                 shr cx, 8
0005cb62  42880c30                 mov byte ptr [rax + r14], cl
0005cb66  48634d00                 movsxd rcx, dword ptr [rbp]
0005cb6a  8d4101                   lea eax, [rcx + 1]
0005cb6d  894500                   mov dword ptr [rbp], eax
0005cb70  4288543101               mov byte ptr [rcx + r14 + 1], dl
0005cb75  ff4500                   inc dword ptr [rbp]
0005cb78  837d0004                 cmp dword ptr [rbp], 4
0005cb7c  0f85ae000000             jne 0x5cc30
0005cb82  897d00                   mov dword ptr [rbp], edi
0005cb85  458b01                   mov r8d, dword ptr [r9]
0005cb88  418b16                   mov edx, dword ptr [r14]
0005cb8b  85f6                     test esi, esi
0005cb8d  7548                     jne 0x5cbd7
0005cb8f  41c1c003                 rol r8d, 3
0005cb93  418bc0                   mov eax, r8d
0005cb96  33c2                     xor eax, edx
0005cb98  418901                   mov dword ptr [r9], eax
0005cb9b  6645396602               cmp word ptr [r14 + 2], r12w
0005cba0  740c                     je 0x5cbae
0005cba2  418907                   mov dword ptr [r15], eax
0005cba5  6641ff03                 inc word ptr [r11]
0005cba9  e9ba000000               jmp 0x5cc68
0005cbae  410fb706                 movzx eax, word ptr [r14]
0005cbb2  66413bc4                 cmp ax, r12w
0005cbb6  7478                     je 0x5cc30
0005cbb8  0fb6c8                   movzx ecx, al
0005cbbb  4133c8                   xor ecx, r8d
0005cbbe  41890f                   mov dword ptr [r15], ecx
0005cbc1  410fb64601               movzx eax, byte ptr [r14 + 1]
0005cbc6  c1c103                   rol ecx, 3
0005cbc9  33c8                     xor ecx, eax
0005cbcb  41890f                   mov dword ptr [r15], ecx
0005cbce  6641ff03                 inc word ptr [r11]
0005cbd2  e991000000               jmp 0x5cc68
0005cbd7  4569d020080000           imul r10d, r8d, 0x820
0005cbde  418bc0                   mov eax, r8d
0005cbe1  c1e802                   shr eax, 2
0005cbe4  4403d0                   add r10d, eax
0005cbe7  418d0412                 lea eax, [r10 + rdx]
0005cbeb  4133c0                   xor eax, r8d
0005cbee  418901                   mov dword ptr [r9], eax
0005cbf1  6645396602               cmp word ptr [r14 + 2], r12w
0005cbf6  7409                     je 0x5cc01
0005cbf8  418907                   mov dword ptr [r15], eax
0005cbfb  6641ff03                 inc word ptr [r11]
0005cbff  eb67                     jmp 0x5cc68
0005cc01  410fb706                 movzx eax, word ptr [r14]
0005cc05  66413bc4                 cmp ax, r12w
0005cc09  7425                     je 0x5cc30
0005cc0b  0fb6d0                   movzx edx, al
0005cc0e  4103d2                   add edx, r10d
0005cc11  4133d0                   xor edx, r8d
0005cc14  69c220080000             imul eax, edx, 0x820
0005cc1a  418917                   mov dword ptr [r15], edx
0005cc1d  410fb64e01               movzx ecx, byte ptr [r14 + 1]
0005cc22  03c8                     add ecx, eax
0005cc24  8bc2                     mov eax, edx
0005cc26  c1e802                   shr eax, 2
0005cc29  03c8                     add ecx, eax
0005cc2b  33ca                     xor ecx, edx
0005cc2d  41890f                   mov dword ptr [r15], ecx
0005cc30  6641ff03                 inc word ptr [r11]
0005cc34  eb32                     jmp 0x5cc68
0005cc36  488b06                   mov rax, qword ptr [rsi]
0005cc39  0fb7542440               movzx edx, word ptr [rsp + 0x40]
0005cc3e  0fb7ca                   movzx ecx, dx
0005cc41  66c1e908                 shr cx, 8
0005cc45  8808                     mov byte ptr [rax], cl
0005cc47  48ff06                   inc qword ptr [rsi]
0005cc4a  488b06                   mov rax, qword ptr [rsi]
0005cc4d  8810                     mov byte ptr [rax], dl
0005cc4f  48ff06                   inc qword ptr [rsi]
0005cc52  488b06                   mov rax, qword ptr [rsi]
0005cc55  c600ff                   mov byte ptr [rax], 0xff
0005cc58  48ff06                   inc qword ptr [rsi]
0005cc5b  488b0e                   mov rcx, qword ptr [rsi]
0005cc5e  0fb6442478               movzx eax, byte ptr [rsp + 0x78]
0005cc63  8801                     mov byte ptr [rcx], al
0005cc65  48ff06                   inc qword ptr [rsi]
0005cc68  0fb64c2479               movzx ecx, byte ptr [rsp + 0x79]
0005cc6d  0fb644247a               movzx eax, byte ptr [rsp + 0x7a]
0005cc72  c1e110                   shl ecx, 0x10
0005cc75  480bc8                   or rcx, rax
0005cc78  48b8020200ff00ff0000     movabs rax, 0xff00ff000202
0005cc82  48c1e110                 shl rcx, 0x10
0005cc86  480bc8                   or rcx, rax
0005cc89  488b442468               mov rax, qword ptr [rsp + 0x68]
0005cc8e  488908                   mov qword ptr [rax], rcx
0005cc91  4183fd01                 cmp r13d, 1
0005cc95  7e3b                     jle 0x5ccd2
0005cc97  488b0b                   mov rcx, qword ptr [rbx]
0005cc9a  488d430e                 lea rax, [rbx + 0xe]
0005cc9e  8b5308                   mov edx, dword ptr [rbx + 8]
0005cca1  458d45ff                 lea r8d, [r13 - 1]
0005cca5  483bc8                   cmp rcx, rax
0005cca8  7417                     je 0x5ccc1
0005ccaa  4a8d0c41                 lea rcx, [rcx + r8*2]
0005ccae  412bd0                   sub edx, r8d
0005ccb1  48890b                   mov qword ptr [rbx], rcx
0005ccb4  b801000000               mov eax, 1
0005ccb9  895308                   mov dword ptr [rbx + 8], edx
0005ccbc  e928010000               jmp 0x5cde9
0005ccc1  488b4310                 mov rax, qword ptr [rbx + 0x10]
0005ccc5  488903                   mov qword ptr [rbx], rax
0005ccc8  8d42ff                   lea eax, [rdx - 1]
0005cccb  894308                   mov dword ptr [rbx + 8], eax
0005ccce  48897b10                 mov qword ptr [rbx + 0x10], rdi
0005ccd2  b801000000               mov eax, 1
0005ccd7  e90d010000               jmp 0x5cde9
0005ccdc  4c8b4c2468               mov r9, qword ptr [rsp + 0x68]
0005cce1  498b09                   mov rcx, qword ptr [r9]
0005cce4  488bc1                   mov rax, rcx
0005cce7  48c1e820                 shr rax, 0x20
0005cceb  0fb6d0                   movzx edx, al
0005ccee  48b8ffffffffff00ffff     movabs rax, 0xffff00ffffffffff
0005ccf8  4823c8                   and rcx, rax
0005ccfb  48c1e228                 shl rdx, 0x28
0005ccff  480bd1                   or rdx, rcx
0005cd02  48b902ffffff00ffffff     movabs rcx, 0xffffff00ffffff02
0005cd0c  0fb6c2                   movzx eax, dl
0005cd0f  4823d1                   and rdx, rcx
0005cd12  48c1e020                 shl rax, 0x20
0005cd16  480bc2                   or rax, rdx
0005cd19  4883c802                 or rax, 2
0005cd1d  498901                   mov qword ptr [r9], rax
0005cd20  b801000000               mov eax, 1
0005cd25  e9bf000000               jmp 0x5cde9
0005cd2a  488bc8                   mov rcx, rax
0005cd2d  48c1e920                 shr rcx, 0x20
0005cd31  0fb6d1                   movzx edx, cl
0005cd34  48c1e208                 shl rdx, 8
0005cd38  0fb6c8                   movzx ecx, al
0005cd3b  48b802020000fffd0000     movabs rax, 0xfdff00000202
0005cd45  480bd1                   or rdx, rcx
0005cd48  48c1e210                 shl rdx, 0x10
0005cd4c  480bd0                   or rdx, rax
0005cd4f  b801000000               mov eax, 1
0005cd54  498911                   mov qword ptr [r9], rdx
0005cd57  488917                   mov qword ptr [rdi], rdx
0005cd5a  e98a000000               jmp 0x5cde9
0005cd5f  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0005cd67  757e                     jne 0x5cde7
0005cd69  488b16                   mov rdx, qword ptr [rsi]
0005cd6c  488b842430010000         mov rax, qword ptr [rsp + 0x130]
0005cd74  48c1e202                 shl rdx, 2
0005cd78  488d048500000000         lea rax, [rax*4]
0005cd80  662bd0                   sub dx, ax
0005cd83  b803800000               mov eax, 0x8003
0005cd88  660bd0                   or dx, ax
0005cd8b  498b00                   mov rax, qword ptr [r8]
0005cd8e  0fb7ca                   movzx ecx, dx
0005cd91  66c1e908                 shr cx, 8
0005cd95  8808                     mov byte ptr [rax], cl
0005cd97  49ff00                   inc qword ptr [r8]
0005cd9a  498b00                   mov rax, qword ptr [r8]
0005cd9d  8810                     mov byte ptr [rax], dl
0005cd9f  49ff00                   inc qword ptr [r8]
0005cda2  498b08                   mov rcx, qword ptr [r8]
0005cda5  498b01                   mov rax, qword ptr [r9]
0005cda8  48c1e828                 shr rax, 0x28
0005cdac  8801                     mov byte ptr [rcx], al
0005cdae  49ff00                   inc qword ptr [r8]
0005cdb1  498b01                   mov rax, qword ptr [r9]
0005cdb4  498b08                   mov rcx, qword ptr [r8]
0005cdb7  48c1e820                 shr rax, 0x20
0005cdbb  8801                     mov byte ptr [rcx], al
0005cdbd  49ff00                   inc qword ptr [r8]
0005cdc0  eb25                     jmp 0x5cde7
0005cdc2  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0005cdca  751b                     jne 0x5cde7
0005cdcc  498b0a                   mov rcx, qword ptr [r10]
0005cdcf  48c1e820                 shr rax, 0x20
0005cdd3  483b8c2440010000         cmp rcx, qword ptr [rsp + 0x140]
0005cddb  7605                     jbe 0x5cde2
0005cddd  8841ff                   mov byte ptr [rcx - 1], al
0005cde0  eb05                     jmp 0x5cde7
0005cde2  8801                     mov byte ptr [rcx], al
0005cde4  49ff02                   inc qword ptr [r10]
0005cde7  33c0                     xor eax, eax
0005cde9  488b9c24d0000000         mov rbx, qword ptr [rsp + 0xd0]
0005cdf1  4881c480000000           add rsp, 0x80
0005cdf8  415f                     pop r15
0005cdfa  415e                     pop r14
0005cdfc  415d                     pop r13
0005cdfe  415c                     pop r12
0005ce00  5f                       pop rdi
0005ce01  5e                       pop rsi
0005ce02  5d                       pop rbp
0005ce03  c3                       ret
0005ce04  e7cd                     out 0xcd, eax
0005ce06  050055c805               add eax, 0x5c85500
0005ce0b  00c9                     add cl, cl
0005ce0d  c8050073                 enter 5, 0x73
0005ce11  c9                       leave
0005ce12  0500fec905               add eax, 0x5c9fe00
0005ce17  002a                     add byte ptr [rdx], ch
0005ce19  cd05                     int 5
0005ce1b  005fcd                   add byte ptr [rdi - 0x33], bl
0005ce1e  0500e7cd05               add eax, 0x5cde700
0005ce23  00e7                     add bh, ah
0005ce25  cd05                     int 5
0005ce27  00e7                     add bh, ah
0005ce29  cd05                     int 5
0005ce2b  00e7                     add bh, ah
0005ce2d  cd05                     int 5
0005ce2f  00e7                     add bh, ah
0005ce31  cd05                     int 5
0005ce33  00e7                     add bh, ah
0005ce35  cd05                     int 5
0005ce37  00e7                     add bh, ah
0005ce39  cd05                     int 5
0005ce3b  00e7                     add bh, ah
0005ce3d  cd05                     int 5
0005ce3f  00e7                     add bh, ah
0005ce41  cd05                     int 5
0005ce43  00e7                     add bh, ah
0005ce45  cd05                     int 5
0005ce47  00e7                     add bh, ah
0005ce49  cd05                     int 5
0005ce4b  00e7                     add bh, ah
0005ce4d  cd05                     int 5
0005ce4f  00e7                     add bh, ah
0005ce51  cd05                     int 5
0005ce53  00e7                     add bh, ah
0005ce55  cd05                     int 5
0005ce57  00c2                     add dl, al
0005ce59  cd05                     int 5
