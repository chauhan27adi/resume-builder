; std::unique_ptr<CAEStreamDecryptionProvider,MemObjDeleter>::~unique_ptr<CAEStreamDecryptionProvider,MemObjDeleter>
; aetm_enclave.dll, primary RVA 0x173c0, 102 bytes in 1 chunk(s)

; chunk at RVA 0x173c0 (102 bytes)
000173c0  4057                     push rdi
000173c2  4883ec30                 sub rsp, 0x30
000173c6  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000173cf  48895c2440               mov qword ptr [rsp + 0x40], rbx
000173d4  488bf9                   mov rdi, rcx
000173d7  488b5908                 mov rbx, qword ptr [rcx + 8]
000173db  4885db                   test rbx, rbx
000173de  743b                     je 0x1741b
000173e0  488b8b98000000           mov rcx, qword ptr [rbx + 0x98]
000173e7  4885c9                   test rcx, rcx
000173ea  740b                     je 0x173f7
000173ec  488b01                   mov rax, qword ptr [rcx]
000173ef  ba01000000               mov edx, 1
000173f4  ff5010                   call qword ptr [rax + 0x10]
000173f7  488b8b90000000           mov rcx, qword ptr [rbx + 0x90]
000173fe  4885c9                   test rcx, rcx
00017401  740b                     je 0x1740e
00017403  488b01                   mov rax, qword ptr [rcx]
00017406  ba01000000               mov edx, 1
0001740b  ff5010                   call qword ptr [rax + 0x10]
0001740e  488b0f                   mov rcx, qword ptr [rdi]
00017411  488b01                   mov rax, qword ptr [rcx]
00017414  488bd3                   mov rdx, rbx
00017417  ff5028                   call qword ptr [rax + 0x28]
0001741a  90                       nop
0001741b  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00017420  4883c430                 add rsp, 0x30
00017424  5f                       pop rdi
00017425  c3                       ret
