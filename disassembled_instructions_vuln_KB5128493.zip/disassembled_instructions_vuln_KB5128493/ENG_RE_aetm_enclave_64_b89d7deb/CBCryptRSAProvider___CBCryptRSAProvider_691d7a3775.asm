; CBCryptRSAProvider::~CBCryptRSAProvider
; aetm_enclave.dll, primary RVA 0x18e60, 81 bytes in 1 chunk(s)

; chunk at RVA 0x18e60 (81 bytes)
00018e60  48894c2408               mov qword ptr [rsp + 8], rcx
00018e65  53                       push rbx
00018e66  4883ec30                 sub rsp, 0x30
00018e6a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00018e73  488bd9                   mov rbx, rcx
00018e76  488d4108                 lea rax, [rcx + 8]
00018e7a  4889442448               mov qword ptr [rsp + 0x48], rax
00018e7f  488d0d5aba0400           lea rcx, [rip + 0x4ba5a]
00018e86  488908                   mov qword ptr [rax], rcx
00018e89  4883c008                 add rax, 8
00018e8d  4889442450               mov qword ptr [rsp + 0x50], rax
00018e92  488b08                   mov rcx, qword ptr [rax]
00018e95  4885c9                   test rcx, rcx
00018e98  7407                     je 0x18ea1
00018e9a  ff1538a20400             call qword ptr [rip + 0x4a238]
00018ea0  90                       nop
00018ea1  488d0550ba0400           lea rax, [rip + 0x4ba50]
00018ea8  488903                   mov qword ptr [rbx], rax
00018eab  4883c430                 add rsp, 0x30
00018eaf  5b                       pop rbx
00018eb0  c3                       ret
