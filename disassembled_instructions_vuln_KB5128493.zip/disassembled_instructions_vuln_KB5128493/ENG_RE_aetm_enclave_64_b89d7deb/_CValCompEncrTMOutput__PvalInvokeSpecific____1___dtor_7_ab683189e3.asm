; `CValCompEncrTMOutput::PvalInvokeSpecific'::`1'::dtor$7
; aetm_enclave.dll, primary RVA 0x60b60, 28 bytes in 1 chunk(s)

; chunk at RVA 0x60b60 (28 bytes)
00060b60  4055                     push rbp
00060b62  4883ec20                 sub rsp, 0x20
00060b66  488bea                   mov rbp, rdx
00060b69  488b5548                 mov rdx, qword ptr [rbp + 0x48]
00060b6d  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00060b71  e80a8efbff               call 0x19980
00060b76  4883c420                 add rsp, 0x20
00060b7a  5d                       pop rbp
00060b7b  c3                       ret
