; CValExecPlaintextTMOutput::SetDataX
; aetm_enclave.dll, primary RVA 0x16f40, 776 bytes in 11 chunk(s)

; chunk at RVA 0x16f40 (65 bytes)
00016f40  4057                     push rdi
00016f42  4883ec30                 sub rsp, 0x30
00016f46  498bf8                   mov rdi, r8
00016f49  4c8b4208                 mov r8, qword ptr [rdx + 8]
00016f4d  4d85c0                   test r8, r8
00016f50  0f840c020000             je 0x17162
00016f56  8b5108                   mov edx, dword ptr [rcx + 8]
00016f59  ffc2                     inc edx
00016f5b  48c1e205                 shl rdx, 5
00016f5f  4903d0                   add rdx, r8
00016f62  493bd0                   cmp rdx, r8
00016f65  0f82f7010000             jb 0x17162
00016f6b  483b15c6ea4500           cmp rdx, qword ptr [rip + 0x45eac6]
00016f72  760d                     jbe 0x16f81
00016f74  4c3b053de94500           cmp r8, qword ptr [rip + 0x45e93d]
00016f7b  0f82e1010000             jb 0x17162

; chunk at RVA 0x16f81 (37 bytes)
00016f81  48895c2440               mov qword ptr [rsp + 0x40], rbx
00016f86  0faee8                   lfence
00016f89  8b5908                   mov ebx, dword ptr [rcx + 8]
00016f8c  48c1e305                 shl rbx, 5
00016f90  4903d8                   add rbx, r8
00016f93  803f03                   cmp byte ptr [rdi], 3
00016f96  750e                     jne 0x16fa6
00016f98  c60303                   mov byte ptr [rbx], 3
00016f9b  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00016fa0  4883c430                 add rsp, 0x30
00016fa4  5f                       pop rdi
00016fa5  c3                       ret

; chunk at RVA 0x16fa6 (238 bytes)
00016fa6  0fb65110                 movzx edx, byte ptr [rcx + 0x10]
00016faa  4c8d054f90feff           lea r8, [rip - 0x16fb1]
00016fb1  420fb68402405a0600       movzx eax, byte ptr [rdx + r8 + 0x65a40]
00016fba  4280bc00405b060001       cmp byte ptr [rax + r8 + 0x65b40], 1
00016fc3  0f85cb000000             jne 0x17094
00016fc9  8b4310                   mov eax, dword ptr [rbx + 0x10]
00016fcc  3b4710                   cmp eax, dword ptr [rdi + 0x10]
00016fcf  0f82b4010000             jb 0x17189
00016fd5  488b4b08                 mov rcx, qword ptr [rbx + 8]
00016fd9  4c89742458               mov qword ptr [rsp + 0x58], r14
00016fde  4885c9                   test rcx, rcx
00016fe1  0f84ca010000             je 0x171b1
00016fe7  448bf0                   mov r14d, eax
00016fea  4803c1                   add rax, rcx
00016fed  483bc1                   cmp rax, rcx
00016ff0  0f82bb010000             jb 0x171b1
00016ff6  483b053bea4500           cmp rax, qword ptr [rip + 0x45ea3b]
00016ffd  760d                     jbe 0x1700c
00016fff  483b0db2e84500           cmp rcx, qword ptr [rip + 0x45e8b2]
00017006  0f82a5010000             jb 0x171b1
0001700c  48896c2448               mov qword ptr [rsp + 0x48], rbp
00017011  4889742450               mov qword ptr [rsp + 0x50], rsi
00017016  0faee8                   lfence
00017019  8b7710                   mov esi, dword ptr [rdi + 0x10]
0001701c  488b6f08                 mov rbp, qword ptr [rdi + 8]
00017020  4885f6                   test rsi, rsi
00017023  744b                     je 0x17070
00017025  4885ed                   test rbp, rbp
00017028  7412                     je 0x1703c
0001702a  4c3bf6                   cmp r14, rsi
0001702d  720d                     jb 0x1703c
0001702f  448bc6                   mov r8d, esi
00017032  488bd5                   mov rdx, rbp
00017035  e879720400               call 0x5e2b3
0001703a  eb34                     jmp 0x17070
0001703c  4d8bc6                   mov r8, r14
0001703f  33d2                     xor edx, edx
00017041  e885720400               call 0x5e2cb
00017046  4885ed                   test rbp, rbp
00017049  750e                     jne 0x17059
0001704b  ff1547c10400             call qword ptr [rip + 0x4c147]
00017051  c70016000000             mov dword ptr [rax], 0x16
00017057  eb11                     jmp 0x1706a
00017059  4c3bf6                   cmp r14, rsi
0001705c  7312                     jae 0x17070
0001705e  ff1534c10400             call qword ptr [rip + 0x4c134]
00017064  c70022000000             mov dword ptr [rax], 0x22
0001706a  ff1530c10400             call qword ptr [rip + 0x4c130]
00017070  8b4710                   mov eax, dword ptr [rdi + 0x10]
00017073  488b742450               mov rsi, qword ptr [rsp + 0x50]
00017078  488b6c2448               mov rbp, qword ptr [rsp + 0x48]
0001707d  4c8b742458               mov r14, qword ptr [rsp + 0x58]
00017082  48894310                 mov qword ptr [rbx + 0x10], rax
00017086  c60300                   mov byte ptr [rbx], 0
00017089  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
0001708e  4883c430                 add rsp, 0x30
00017092  5f                       pop rdi
00017093  c3                       ret

; chunk at RVA 0x17094 (73 bytes)
00017094  8d42dc                   lea eax, [rdx - 0x24]
00017097  83f85b                   cmp eax, 0x5b
0001709a  0f87b4000000             ja 0x17154
000170a0  4898                     cdqe
000170a2  410fb68400ec710100       movzx eax, byte ptr [r8 + rax + 0x171ec]
000170ab  418b8c80d8710100         mov ecx, dword ptr [r8 + rax*4 + 0x171d8]
000170b3  4903c8                   add rcx, r8
000170b6  ffe1                     jmp rcx
000170b8  0f1007                   movups xmm0, xmmword ptr [rdi]
000170bb  b8feff0000               mov eax, 0xfffe
000170c0  0f1103                   movups xmmword ptr [rbx], xmm0
000170c3  0f104f10                 movups xmm1, xmmword ptr [rdi + 0x10]
000170c7  0f114b10                 movups xmmword ptr [rbx + 0x10], xmm1
000170cb  66214302                 and word ptr [rbx + 2], ax
000170cf  c60300                   mov byte ptr [rbx], 0
000170d2  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
000170d7  4883c430                 add rsp, 0x30
000170db  5f                       pop rdi
000170dc  c3                       ret

; chunk at RVA 0x170dd (21 bytes)
000170dd  0fb64708                 movzx eax, byte ptr [rdi + 8]
000170e1  884308                   mov byte ptr [rbx + 8], al
000170e4  c60300                   mov byte ptr [rbx], 0
000170e7  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
000170ec  4883c430                 add rsp, 0x30
000170f0  5f                       pop rdi
000170f1  c3                       ret

; chunk at RVA 0x170f2 (47 bytes)
000170f2  440fb6471b               movzx r8d, byte ptr [rdi + 0x1b]
000170f7  488d5708                 lea rdx, [rdi + 8]
000170fb  488d4b08                 lea rcx, [rbx + 8]
000170ff  4d85c0                   test r8, r8
00017102  7450                     je 0x17154
00017104  4885c9                   test rcx, rcx
00017107  741d                     je 0x17126
00017109  4885d2                   test rdx, rdx
0001710c  7413                     je 0x17121
0001710e  e8a0710400               call 0x5e2b3
00017113  c60300                   mov byte ptr [rbx], 0
00017116  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
0001711b  4883c430                 add rsp, 0x30
0001711f  5f                       pop rdi
00017120  c3                       ret

; chunk at RVA 0x17121 (37 bytes)
00017121  e8a5710400               call 0x5e2cb
00017126  ff156cc00400             call qword ptr [rip + 0x4c06c]
0001712c  c70016000000             mov dword ptr [rax], 0x16
00017132  ff1568c00400             call qword ptr [rip + 0x4c068]
00017138  c60300                   mov byte ptr [rbx], 0
0001713b  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00017140  4883c430                 add rsp, 0x30
00017144  5f                       pop rdi
00017145  c3                       ret

; chunk at RVA 0x17146 (28 bytes)
00017146  0f104708                 movups xmm0, xmmword ptr [rdi + 8]
0001714a  0f114308                 movups xmmword ptr [rbx + 8], xmm0
0001714e  8b4718                   mov eax, dword ptr [rdi + 0x18]
00017151  894318                   mov dword ptr [rbx + 0x18], eax
00017154  c60300                   mov byte ptr [rbx], 0
00017157  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
0001715c  4883c430                 add rsp, 0x30
00017160  5f                       pop rdi
00017161  c3                       ret

; chunk at RVA 0x17162 (39 bytes)
00017162  41b968000000             mov r9d, 0x68
00017168  48c744242000000000       mov qword ptr [rsp + 0x20], 0
00017171  4c8d05a87b0800           lea r8, [rip + 0x87ba8]
00017178  488d15917a0800           lea rdx, [rip + 0x87a91]
0001717f  418d4999                 lea ecx, [r9 - 0x67]
00017183  e898220000               call 0x19420
00017188  cc                       int3

; chunk at RVA 0x17189 (40 bytes)
00017189  41b9cd040000             mov r9d, 0x4cd
0001718f  48c744242000000000       mov qword ptr [rsp + 0x20], 0
00017198  4c8d05817b0800           lea r8, [rip + 0x87b81]
0001719f  b901000000               mov ecx, 1
000171a4  488d1505860800           lea rdx, [rip + 0x88605]
000171ab  e870220000               call 0x19420
000171b0  cc                       int3

; chunk at RVA 0x171b1 (151 bytes)
000171b1  41b968000000             mov r9d, 0x68
000171b7  48c744242000000000       mov qword ptr [rsp + 0x20], 0
000171c0  4c8d05017b0800           lea r8, [rip + 0x87b01]
000171c7  488d15427a0800           lea rdx, [rip + 0x87a42]
000171ce  418d4999                 lea ecx, [r9 - 0x67]
000171d2  e849220000               call 0x19420
000171d7  cc                       int3
000171d8  b8700100f2               mov eax, 0xf2000170
000171dd  7001                     jo 0x171e0
000171df  00dd                     add ch, bl
000171e1  7001                     jo 0x171e4
000171e3  004671                   add byte ptr [rsi + 0x71], al
000171e6  0100                     add dword ptr [rax], eax
000171e8  54                       push rsp
000171e9  7101                     jno 0x171ec
000171eb  0000                     add byte ptr [rax], al
000171ed  0404                     add al, 4
000171ef  0401                     add al, 1
000171f1  0101                     add dword ptr [rcx], eax
000171f3  010404                   add dword ptr [rsp + rax], eax
000171f6  0404                     add al, 4
000171f8  000404                   add byte ptr [rsp + rax], al
000171fb  0400                     add al, 0
000171fd  0404                     add al, 4
000171ff  0400                     add al, 0
00017201  0400                     add al, 0
00017203  0000                     add byte ptr [rax], al
00017205  0000                     add byte ptr [rax], al
00017207  0404                     add al, 4
00017209  0404                     add al, 4
0001720b  0404                     add al, 4
0001720d  0404                     add al, 4
0001720f  0404                     add al, 4
00017211  0404                     add al, 4
00017213  0404                     add al, 4
00017215  0404                     add al, 4
00017217  0404                     add al, 4
00017219  0404                     add al, 4
0001721b  0404                     add al, 4
0001721d  0404                     add al, 4
0001721f  0404                     add al, 4
00017221  0404                     add al, 4
00017223  0404                     add al, 4
00017225  0404                     add al, 4
00017227  0404                     add al, 4
00017229  0404                     add al, 4
0001722b  0404                     add al, 4
0001722d  0404                     add al, 4
0001722f  0402                     add al, 2
00017231  0403                     add al, 3
00017233  0403                     add al, 3
00017235  0404                     add al, 4
00017237  0404                     add al, 4
00017239  0404                     add al, 4
0001723b  0404                     add al, 4
0001723d  0404                     add al, 4
0001723f  0404                     add al, 4
00017241  0400                     add al, 0
00017243  0404                     add al, 4
00017245  0404                     add al, 4
