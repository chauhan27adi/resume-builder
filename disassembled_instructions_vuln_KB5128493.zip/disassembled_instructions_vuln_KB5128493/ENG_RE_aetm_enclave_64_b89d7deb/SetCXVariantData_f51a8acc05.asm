; SetCXVariantData
; aetm_enclave.dll, primary RVA 0x17bb0, 2608 bytes in 8 chunk(s)

; chunk at RVA 0x17bb0 (57 bytes)
00017bb0  4053                     push rbx
00017bb2  56                       push rsi
00017bb3  57                       push rdi
00017bb4  4156                     push r14
00017bb6  4883ec48                 sub rsp, 0x48
00017bba  488b0547340900           mov rax, qword ptr [rip + 0x93447]
00017bc1  4833c4                   xor rax, rsp
00017bc4  4889442438               mov qword ptr [rsp + 0x38], rax
00017bc9  4c8bb42490000000         mov r14, qword ptr [rsp + 0x90]
00017bd1  498bd9                   mov rbx, r9
00017bd4  0fb6c2                   movzx eax, dl
00017bd7  488bf1                   mov rsi, rcx
00017bda  83c0dc                   add eax, -0x24
00017bdd  418bf8                   mov edi, r8d
00017be0  83f85b                   cmp eax, 0x5b
00017be3  0f879e060000             ja 0x18287

; chunk at RVA 0x17be9 (855 bytes)
00017be9  4c897c2440               mov qword ptr [rsp + 0x40], r15
00017bee  4c8d3d0b84feff           lea r15, [rip - 0x17bf5]
00017bf5  4898                     cdqe
00017bf7  410fb6840784850100       movzx eax, byte ptr [r15 + rax + 0x18584]
00017c00  418b8c8740850100         mov ecx, dword ptr [r15 + rax*4 + 0x18540]
00017c08  4903cf                   add rcx, r15
00017c0b  ffe1                     jmp rcx
00017c0d  488b054cde4500           mov rax, qword ptr [rip + 0x45de4c]
00017c14  83ff08                   cmp edi, 8
00017c17  740d                     je 0x17c26
00017c19  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017c20  0f8578060000             jne 0x1829e
00017c26  4885db                   test rbx, rbx
00017c29  0f8479010000             je 0x17da8
00017c2f  498b19                   mov rbx, qword ptr [r9]
00017c32  4881fbff000000           cmp rbx, 0xff
00017c39  0f867d010000             jbe 0x17dbc
00017c3f  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017c46  0f856a060000             jne 0x182b6
00017c4c  e96b010000               jmp 0x17dbc
00017c51  488b0d08de4500           mov rcx, qword ptr [rip + 0x45de08]
00017c58  83ff08                   cmp edi, 8
00017c5b  740d                     je 0x17c6a
00017c5d  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017c64  0f8564060000             jne 0x182ce
00017c6a  4885db                   test rbx, rbx
00017c6d  743d                     je 0x17cac
00017c6f  498b19                   mov rbx, qword ptr [r9]
00017c72  4885db                   test rbx, rbx
00017c75  791d                     jns 0x17c94
00017c77  488bc3                   mov rax, rbx
00017c7a  48f7d8                   neg rax
00017c7d  483d00800000             cmp rax, 0x8000
00017c83  7639                     jbe 0x17cbe
00017c85  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017c8c  0f8554060000             jne 0x182e6
00017c92  eb2a                     jmp 0x17cbe
00017c94  4881fb00800000           cmp rbx, 0x8000
00017c9b  7221                     jb 0x17cbe
00017c9d  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017ca4  0f8554060000             jne 0x182fe
00017caa  eb12                     jmp 0x17cbe
00017cac  ff15e6b40400             call qword ptr [rip + 0x4b4e6]
00017cb2  c70016000000             mov dword ptr [rax], 0x16
00017cb8  ff15e2b40400             call qword ptr [rip + 0x4b4e2]
00017cbe  66895e08                 mov word ptr [rsi + 8], bx
00017cc2  e9bb050000               jmp 0x18282
00017cc7  488b0d92dd4500           mov rcx, qword ptr [rip + 0x45dd92]
00017cce  83ff08                   cmp edi, 8
00017cd1  740d                     je 0x17ce0
00017cd3  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017cda  0f8536060000             jne 0x18316
00017ce0  4885db                   test rbx, rbx
00017ce3  743b                     je 0x17d20
00017ce5  498b19                   mov rbx, qword ptr [r9]
00017ce8  ba00000080               mov edx, 0x80000000
00017ced  4885db                   test rbx, rbx
00017cf0  791a                     jns 0x17d0c
00017cf2  488bc3                   mov rax, rbx
00017cf5  48f7d8                   neg rax
00017cf8  483bc2                   cmp rax, rdx
00017cfb  7635                     jbe 0x17d32
00017cfd  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017d04  0f8524060000             jne 0x1832e
00017d0a  eb26                     jmp 0x17d32
00017d0c  483bda                   cmp rbx, rdx
00017d0f  7221                     jb 0x17d32
00017d11  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00017d18  0f8528060000             jne 0x18346
00017d1e  eb12                     jmp 0x17d32
00017d20  ff1572b40400             call qword ptr [rip + 0x4b472]
00017d26  c70016000000             mov dword ptr [rax], 0x16
00017d2c  ff156eb40400             call qword ptr [rip + 0x4b46e]
00017d32  895e08                   mov dword ptr [rsi + 8], ebx
00017d35  e948050000               jmp 0x18282
00017d3a  83ff08                   cmp edi, 8
00017d3d  7414                     je 0x17d53
00017d3f  488b051add4500           mov rax, qword ptr [rip + 0x45dd1a]
00017d46  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017d4d  0f850b060000             jne 0x1835e
00017d53  4885db                   test rbx, rbx
00017d56  740c                     je 0x17d64
00017d58  498b19                   mov rbx, qword ptr [r9]
00017d5b  48895e08                 mov qword ptr [rsi + 8], rbx
00017d5f  e91e050000               jmp 0x18282
00017d64  ff152eb40400             call qword ptr [rip + 0x4b42e]
00017d6a  c70016000000             mov dword ptr [rax], 0x16
00017d70  ff152ab40400             call qword ptr [rip + 0x4b42a]
00017d76  48895e08                 mov qword ptr [rsi + 8], rbx
00017d7a  e903050000               jmp 0x18282
00017d7f  83ff08                   cmp edi, 8
00017d82  7414                     je 0x17d98
00017d84  488b05d5dc4500           mov rax, qword ptr [rip + 0x45dcd5]
00017d8b  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017d92  0f85de050000             jne 0x18376
00017d98  4885db                   test rbx, rbx
00017d9b  740b                     je 0x17da8
00017d9d  498b19                   mov rbx, qword ptr [r9]
00017da0  885e08                   mov byte ptr [rsi + 8], bl
00017da3  e9da040000               jmp 0x18282
00017da8  33db                     xor ebx, ebx
00017daa  ff15e8b30400             call qword ptr [rip + 0x4b3e8]
00017db0  c70016000000             mov dword ptr [rax], 0x16
00017db6  ff15e4b30400             call qword ptr [rip + 0x4b3e4]
00017dbc  885e08                   mov byte ptr [rsi + 8], bl
00017dbf  e9be040000               jmp 0x18282
00017dc4  83ff04                   cmp edi, 4
00017dc7  7414                     je 0x17ddd
00017dc9  488b0590dc4500           mov rax, qword ptr [rip + 0x45dc90]
00017dd0  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017dd7  0f85b1050000             jne 0x1838e
00017ddd  4885db                   test rbx, rbx
00017de0  7417                     je 0x17df9
00017de2  418b01                   mov eax, dword ptr [r9]
00017de5  89442430                 mov dword ptr [rsp + 0x30], eax
00017de9  f30f10442430             movss xmm0, dword ptr [rsp + 0x30]
00017def  f30f114608               movss dword ptr [rsi + 8], xmm0
00017df4  e989040000               jmp 0x18282
00017df9  33c0                     xor eax, eax
00017dfb  89442430                 mov dword ptr [rsp + 0x30], eax
00017dff  ff1593b30400             call qword ptr [rip + 0x4b393]
00017e05  c70016000000             mov dword ptr [rax], 0x16
00017e0b  ff158fb30400             call qword ptr [rip + 0x4b38f]
00017e11  f30f10442430             movss xmm0, dword ptr [rsp + 0x30]
00017e17  f30f114608               movss dword ptr [rsi + 8], xmm0
00017e1c  e961040000               jmp 0x18282
00017e21  83ff08                   cmp edi, 8
00017e24  7414                     je 0x17e3a
00017e26  488b0533dc4500           mov rax, qword ptr [rip + 0x45dc33]
00017e2d  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017e34  0f856c050000             jne 0x183a6
00017e3a  4885db                   test rbx, rbx
00017e3d  7418                     je 0x17e57
00017e3f  498b01                   mov rax, qword ptr [r9]
00017e42  4889442430               mov qword ptr [rsp + 0x30], rax
00017e47  f20f10442430             movsd xmm0, qword ptr [rsp + 0x30]
00017e4d  f20f114608               movsd qword ptr [rsi + 8], xmm0
00017e52  e92b040000               jmp 0x18282
00017e57  33c0                     xor eax, eax
00017e59  4889442430               mov qword ptr [rsp + 0x30], rax
00017e5e  ff1534b30400             call qword ptr [rip + 0x4b334]
00017e64  c70016000000             mov dword ptr [rax], 0x16
00017e6a  ff1530b30400             call qword ptr [rip + 0x4b330]
00017e70  f20f10442430             movsd xmm0, qword ptr [rsp + 0x30]
00017e76  f20f114608               movsd qword ptr [rsi + 8], xmm0
00017e7b  e902040000               jmp 0x18282
00017e80  83ff08                   cmp edi, 8
00017e83  0f8459030000             je 0x181e2
00017e89  488b05d0db4500           mov rax, qword ptr [rip + 0x45dbd0]
00017e90  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017e97  0f8521050000             jne 0x183be
00017e9d  e940030000               jmp 0x181e2
00017ea2  83ff08                   cmp edi, 8
00017ea5  7414                     je 0x17ebb
00017ea7  488b05b2db4500           mov rax, qword ptr [rip + 0x45dbb2]
00017eae  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017eb5  0f851b050000             jne 0x183d6
00017ebb  4c8d4e08                 lea r9, [rsi + 8]
00017ebf  897c2420                 mov dword ptr [rsp + 0x20], edi
00017ec3  4d8bc6                   mov r8, r14
00017ec6  8bd7                     mov edx, edi
00017ec8  488bcb                   mov rcx, rbx
00017ecb  e820f7ffff               call 0x175f0
00017ed0  498bce                   mov rcx, r14
00017ed3  448bc0                   mov r8d, eax
00017ed6  e805c2ffff               call 0x140e0
00017edb  488b157edb4500           mov rdx, qword ptr [rip + 0x45db7e]
00017ee2  3c07                     cmp al, 7
00017ee4  760d                     jbe 0x17ef3
00017ee6  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
00017eed  0f85fb040000             jne 0x183ee
00017ef3  0fb6c8                   movzx ecx, al
00017ef6  410fb6c0                 movzx eax, r8b
00017efa  664139848fc8410600       cmp word ptr [r15 + rcx*4 + 0x641c8], ax
00017f03  0f845a020000             je 0x18163
00017f09  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
00017f10  0f85f0040000             jne 0x18406
00017f16  e948020000               jmp 0x18163
00017f1b  498bce                   mov rcx, r14
00017f1e  e83dfffeff               call 0x7e60
00017f23  440fb7c0                 movzx r8d, ax
00017f27  413bf8                   cmp edi, r8d
00017f2a  7414                     je 0x17f40
00017f2c  488b052ddb4500           mov rax, qword ptr [rip + 0x45db2d]
00017f33  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017f3a  0f85de040000             jne 0x1841e

; chunk at RVA 0x17f40 (53 bytes)
00017f40  48896c2478               mov qword ptr [rsp + 0x78], rbp
00017f45  4d8bf0                   mov r14, r8
00017f48  488d4e08                 lea rcx, [rsi + 8]
00017f4c  85ff                     test edi, edi
00017f4e  746b                     je 0x17fbb
00017f50  4885c9                   test rcx, rcx
00017f53  7520                     jne 0x17f75
00017f55  ff153db20400             call qword ptr [rip + 0x4b23d]
00017f5b  c70016000000             mov dword ptr [rax], 0x16
00017f61  ff1539b20400             call qword ptr [rip + 0x4b239]
00017f67  488b6c2478               mov rbp, qword ptr [rsp + 0x78]
00017f6c  40887e1b                 mov byte ptr [rsi + 0x1b], dil
00017f70  e90d030000               jmp 0x18282

; chunk at RVA 0x17f75 (35 bytes)
00017f75  4885db                   test rbx, rbx
00017f78  741e                     je 0x17f98
00017f7a  4c3bf7                   cmp r14, rdi
00017f7d  7219                     jb 0x17f98
00017f7f  4c8bc7                   mov r8, rdi
00017f82  488bd3                   mov rdx, rbx
00017f85  e829630400               call 0x5e2b3
00017f8a  488b6c2478               mov rbp, qword ptr [rsp + 0x78]
00017f8f  40887e1b                 mov byte ptr [rsi + 0x1b], dil
00017f93  e9ea020000               jmp 0x18282

; chunk at RVA 0x17f98 (49 bytes)
00017f98  33d2                     xor edx, edx
00017f9a  e82c630400               call 0x5e2cb
00017f9f  4885db                   test rbx, rbx
00017fa2  74b1                     je 0x17f55
00017fa4  4c3bf7                   cmp r14, rdi
00017fa7  7312                     jae 0x17fbb
00017fa9  ff15e9b10400             call qword ptr [rip + 0x4b1e9]
00017faf  c70022000000             mov dword ptr [rax], 0x22
00017fb5  ff15e5b10400             call qword ptr [rip + 0x4b1e5]
00017fbb  488b6c2478               mov rbp, qword ptr [rsp + 0x78]
00017fc0  40887e1b                 mov byte ptr [rsi + 0x1b], dil
00017fc4  e9b9020000               jmp 0x18282

; chunk at RVA 0x17fc9 (702 bytes)
00017fc9  498bce                   mov rcx, r14
00017fcc  e88ffefeff               call 0x7e60
00017fd1  440fb7c0                 movzx r8d, ax
00017fd5  488b0584da4500           mov rax, qword ptr [rip + 0x45da84]
00017fdc  413bf8                   cmp edi, r8d
00017fdf  740d                     je 0x17fee
00017fe1  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017fe8  0f8548040000             jne 0x18436
00017fee  83ff04                   cmp edi, 4
00017ff1  740d                     je 0x18000
00017ff3  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00017ffa  0f854e040000             jne 0x1844e
00018000  4883c608                 add rsi, 8
00018004  488bc7                   mov rax, rdi
00018007  85ff                     test edi, edi
00018009  746a                     je 0x18075
0001800b  4885f6                   test rsi, rsi
0001800e  751e                     jne 0x1802e
00018010  ff1582b10400             call qword ptr [rip + 0x4b182]
00018016  c70016000000             mov dword ptr [rax], 0x16
0001801c  ff157eb10400             call qword ptr [rip + 0x4b17e]
00018022  8b06                     mov eax, dword ptr [rsi]
00018024  c1c010                   rol eax, 0x10
00018027  8906                     mov dword ptr [rsi], eax
00018029  e954020000               jmp 0x18282
0001802e  4885db                   test rbx, rbx
00018031  7420                     je 0x18053
00018033  4883f808                 cmp rax, 8
00018037  771a                     ja 0x18053
00018039  4c8bc0                   mov r8, rax
0001803c  488bd3                   mov rdx, rbx
0001803f  488bce                   mov rcx, rsi
00018042  e86c620400               call 0x5e2b3
00018047  8b06                     mov eax, dword ptr [rsi]
00018049  c1c010                   rol eax, 0x10
0001804c  8906                     mov dword ptr [rsi], eax
0001804e  e92f020000               jmp 0x18282
00018053  33c9                     xor ecx, ecx
00018055  48890e                   mov qword ptr [rsi], rcx
00018058  4885db                   test rbx, rbx
0001805b  74b3                     je 0x18010
0001805d  4883f808                 cmp rax, 8
00018061  7612                     jbe 0x18075
00018063  ff152fb10400             call qword ptr [rip + 0x4b12f]
00018069  c70022000000             mov dword ptr [rax], 0x22
0001806f  ff152bb10400             call qword ptr [rip + 0x4b12b]
00018075  8b06                     mov eax, dword ptr [rsi]
00018077  c1c010                   rol eax, 0x10
0001807a  8906                     mov dword ptr [rsi], eax
0001807c  e901020000               jmp 0x18282
00018081  83ff05                   cmp edi, 5
00018084  7414                     je 0x1809a
00018086  488b05d3d94500           mov rax, qword ptr [rip + 0x45d9d3]
0001808d  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00018094  0f85cc030000             jne 0x18466
0001809a  4c8d4e08                 lea r9, [rsi + 8]
0001809e  897c2420                 mov dword ptr [rsp + 0x20], edi
000180a2  4d8bc6                   mov r8, r14
000180a5  8bd7                     mov edx, edi
000180a7  488bcb                   mov rcx, rbx
000180aa  e841f5ffff               call 0x175f0
000180af  498bce                   mov rcx, r14
000180b2  448bc0                   mov r8d, eax
000180b5  e826c0ffff               call 0x140e0
000180ba  488b159fd94500           mov rdx, qword ptr [rip + 0x45d99f]
000180c1  3c07                     cmp al, 7
000180c3  760d                     jbe 0x180d2
000180c5  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
000180cc  0f85ac030000             jne 0x1847e
000180d2  0fb6c8                   movzx ecx, al
000180d5  410fb6c0                 movzx eax, r8b
000180d9  664139848f40420600       cmp word ptr [r15 + rcx*4 + 0x64240], ax
000180e2  747f                     je 0x18163
000180e4  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
000180eb  0f85a5030000             jne 0x18496
000180f1  eb70                     jmp 0x18163
000180f3  83ff0a                   cmp edi, 0xa
000180f6  7414                     je 0x1810c
000180f8  488b0561d94500           mov rax, qword ptr [rip + 0x45d961]
000180ff  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00018106  0f85a2030000             jne 0x184ae
0001810c  4c8d4e08                 lea r9, [rsi + 8]
00018110  897c2420                 mov dword ptr [rsp + 0x20], edi
00018114  4d8bc6                   mov r8, r14
00018117  8bd7                     mov edx, edi
00018119  488bcb                   mov rcx, rbx
0001811c  e8cff4ffff               call 0x175f0
00018121  498bce                   mov rcx, r14
00018124  448bc0                   mov r8d, eax
00018127  e8b4bfffff               call 0x140e0
0001812c  488b152dd94500           mov rdx, qword ptr [rip + 0x45d92d]
00018133  3c07                     cmp al, 7
00018135  760d                     jbe 0x18144
00018137  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
0001813e  0f8582030000             jne 0x184c6
00018144  0fb6c8                   movzx ecx, al
00018147  410fb6c0                 movzx eax, r8b
0001814b  664139848fb0420600       cmp word ptr [r15 + rcx*4 + 0x642b0], ax
00018154  740d                     je 0x18163
00018156  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
0001815d  0f857b030000             jne 0x184de
00018163  4488461b                 mov byte ptr [rsi + 0x1b], r8b
00018167  e916010000               jmp 0x18282
0001816c  83ff11                   cmp edi, 0x11
0001816f  7414                     je 0x18185
00018171  488b05e8d84500           mov rax, qword ptr [rip + 0x45d8e8]
00018178  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001817f  0f8571030000             jne 0x184f6
00018185  410fb60e                 movzx ecx, byte ptr [r14]
00018189  8d4110                   lea eax, [rcx + 0x10]
0001818c  3c01                     cmp al, 1
0001818e  7607                     jbe 0x18197
00018190  450fb64e12               movzx r9d, byte ptr [r14 + 0x12]
00018195  eb12                     jmp 0x181a9
00018197  420fb68c39405a0600       movzx ecx, byte ptr [rcx + r15 + 0x65a40]
000181a0  450fb68c8f725b0600       movzx r9d, byte ptr [r15 + rcx*4 + 0x65b72]
000181a9  498bce                   mov rcx, r14
000181ac  e82fbfffff               call 0x140e0
000181b1  488d4e08                 lea rcx, [rsi + 8]
000181b5  88442420                 mov byte ptr [rsp + 0x20], al
000181b9  488bd3                   mov rdx, rbx
000181bc  448bc7                   mov r8d, edi
000181bf  e8acbeffff               call 0x14070
000181c4  e9b9000000               jmp 0x18282
000181c9  83ff08                   cmp edi, 8
000181cc  7414                     je 0x181e2
000181ce  488b058bd84500           mov rax, qword ptr [rip + 0x45d88b]
000181d5  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000181dc  0f852c030000             jne 0x1850e
000181e2  4883c608                 add rsi, 8
000181e6  741f                     je 0x18207
000181e8  4885db                   test rbx, rbx
000181eb  7415                     je 0x18202
000181ed  498b01                   mov rax, qword ptr [r9]
000181f0  488906                   mov qword ptr [rsi], rax
000181f3  8bc8                     mov ecx, eax
000181f5  8b4604                   mov eax, dword ptr [rsi + 4]
000181f8  8906                     mov dword ptr [rsi], eax
000181fa  894e04                   mov dword ptr [rsi + 4], ecx
000181fd  e980000000               jmp 0x18282
00018202  33c0                     xor eax, eax
00018204  488906                   mov qword ptr [rsi], rax
00018207  ff158baf0400             call qword ptr [rip + 0x4af8b]
0001820d  c70016000000             mov dword ptr [rax], 0x16
00018213  ff1587af0400             call qword ptr [rip + 0x4af87]
00018219  8b0e                     mov ecx, dword ptr [rsi]
0001821b  8b4604                   mov eax, dword ptr [rsi + 4]
0001821e  8906                     mov dword ptr [rsi], eax
00018220  894e04                   mov dword ptr [rsi + 4], ecx
00018223  eb5d                     jmp 0x18282
00018225  498bce                   mov rcx, r14
00018228  e833fcfeff               call 0x7e60
0001822d  440fb7c0                 movzx r8d, ax
00018231  413bf8                   cmp edi, r8d
00018234  7414                     je 0x1824a
00018236  488b0523d84500           mov rax, qword ptr [rip + 0x45d823]
0001823d  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00018244  0f85dc020000             jne 0x18526
0001824a  488d4e08                 lea rcx, [rsi + 8]
0001824e  4c8bc7                   mov r8, rdi
00018251  85ff                     test edi, edi
00018253  742d                     je 0x18282
00018255  4885c9                   test rcx, rcx
00018258  7416                     je 0x18270
0001825a  4885db                   test rbx, rbx
0001825d  740a                     je 0x18269
0001825f  488bd3                   mov rdx, rbx
00018262  e84c600400               call 0x5e2b3
00018267  eb19                     jmp 0x18282
00018269  33d2                     xor edx, edx
0001826b  e85b600400               call 0x5e2cb
00018270  ff1522af0400             call qword ptr [rip + 0x4af22]
00018276  c70016000000             mov dword ptr [rax], 0x16
0001827c  ff151eaf0400             call qword ptr [rip + 0x4af1e]
00018282  4c8b7c2440               mov r15, qword ptr [rsp + 0x40]

; chunk at RVA 0x18287 (23 bytes)
00018287  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
0001828c  4833cc                   xor rcx, rsp
0001828f  e8dc4b0400               call 0x5ce70
00018294  4883c448                 add rsp, 0x48
00018298  415e                     pop r14
0001829a  5f                       pop rdi
0001829b  5e                       pop rsi
0001829c  5b                       pop rbx
0001829d  c3                       ret

; chunk at RVA 0x1829e (834 bytes)
0001829e  ba32000000               mov edx, 0x32
000182a3  b94f010000               mov ecx, 0x14f
000182a8  448d4a32                 lea r9d, [rdx + 0x32]
000182ac  448d42de                 lea r8d, [rdx - 0x22]
000182b0  e88b110000               call 0x19440
000182b5  cc                       int3
000182b6  ba32000000               mov edx, 0x32
000182bb  b94f010000               mov ecx, 0x14f
000182c0  448d4a33                 lea r9d, [rdx + 0x33]
000182c4  448d42de                 lea r8d, [rdx - 0x22]
000182c8  e873110000               call 0x19440
000182cd  cc                       int3
000182ce  ba32000000               mov edx, 0x32
000182d3  b94f010000               mov ecx, 0x14f
000182d8  448d4a34                 lea r9d, [rdx + 0x34]
000182dc  448d42de                 lea r8d, [rdx - 0x22]
000182e0  e85b110000               call 0x19440
000182e5  cc                       int3
000182e6  ba32000000               mov edx, 0x32
000182eb  b94f010000               mov ecx, 0x14f
000182f0  448d4a35                 lea r9d, [rdx + 0x35]
000182f4  448d42de                 lea r8d, [rdx - 0x22]
000182f8  e843110000               call 0x19440
000182fd  cc                       int3
000182fe  ba32000000               mov edx, 0x32
00018303  b94f010000               mov ecx, 0x14f
00018308  448d4a36                 lea r9d, [rdx + 0x36]
0001830c  448d42de                 lea r8d, [rdx - 0x22]
00018310  e82b110000               call 0x19440
00018315  cc                       int3
00018316  ba32000000               mov edx, 0x32
0001831b  b94f010000               mov ecx, 0x14f
00018320  448d4a37                 lea r9d, [rdx + 0x37]
00018324  448d42de                 lea r8d, [rdx - 0x22]
00018328  e813110000               call 0x19440
0001832d  cc                       int3
0001832e  ba32000000               mov edx, 0x32
00018333  b94f010000               mov ecx, 0x14f
00018338  448d4a38                 lea r9d, [rdx + 0x38]
0001833c  448d42de                 lea r8d, [rdx - 0x22]
00018340  e8fb100000               call 0x19440
00018345  cc                       int3
00018346  ba32000000               mov edx, 0x32
0001834b  b94f010000               mov ecx, 0x14f
00018350  448d4a39                 lea r9d, [rdx + 0x39]
00018354  448d42de                 lea r8d, [rdx - 0x22]
00018358  e8e3100000               call 0x19440
0001835d  cc                       int3
0001835e  ba32000000               mov edx, 0x32
00018363  b94f010000               mov ecx, 0x14f
00018368  448d4a3a                 lea r9d, [rdx + 0x3a]
0001836c  448d42de                 lea r8d, [rdx - 0x22]
00018370  e8cb100000               call 0x19440
00018375  cc                       int3
00018376  ba32000000               mov edx, 0x32
0001837b  b94f010000               mov ecx, 0x14f
00018380  448d4a3b                 lea r9d, [rdx + 0x3b]
00018384  448d42de                 lea r8d, [rdx - 0x22]
00018388  e8b3100000               call 0x19440
0001838d  cc                       int3
0001838e  ba32000000               mov edx, 0x32
00018393  b94f010000               mov ecx, 0x14f
00018398  448d4a3c                 lea r9d, [rdx + 0x3c]
0001839c  448d42de                 lea r8d, [rdx - 0x22]
000183a0  e89b100000               call 0x19440
000183a5  cc                       int3
000183a6  ba32000000               mov edx, 0x32
000183ab  b94f010000               mov ecx, 0x14f
000183b0  448d4a3d                 lea r9d, [rdx + 0x3d]
000183b4  448d42de                 lea r8d, [rdx - 0x22]
000183b8  e883100000               call 0x19440
000183bd  cc                       int3
000183be  ba32000000               mov edx, 0x32
000183c3  b94f010000               mov ecx, 0x14f
000183c8  448d4a3e                 lea r9d, [rdx + 0x3e]
000183cc  448d42de                 lea r8d, [rdx - 0x22]
000183d0  e86b100000               call 0x19440
000183d5  cc                       int3
000183d6  ba32000000               mov edx, 0x32
000183db  b94f010000               mov ecx, 0x14f
000183e0  448d4a3f                 lea r9d, [rdx + 0x3f]
000183e4  448d42de                 lea r8d, [rdx - 0x22]
000183e8  e853100000               call 0x19440
000183ed  cc                       int3
000183ee  ba32000000               mov edx, 0x32
000183f3  b94f010000               mov ecx, 0x14f
000183f8  448d4a40                 lea r9d, [rdx + 0x40]
000183fc  448d42de                 lea r8d, [rdx - 0x22]
00018400  e83b100000               call 0x19440
00018405  cc                       int3
00018406  ba32000000               mov edx, 0x32
0001840b  b94f010000               mov ecx, 0x14f
00018410  448d4a41                 lea r9d, [rdx + 0x41]
00018414  448d42de                 lea r8d, [rdx - 0x22]
00018418  e823100000               call 0x19440
0001841d  cc                       int3
0001841e  ba32000000               mov edx, 0x32
00018423  b94f010000               mov ecx, 0x14f
00018428  448d4a42                 lea r9d, [rdx + 0x42]
0001842c  448d42de                 lea r8d, [rdx - 0x22]
00018430  e80b100000               call 0x19440
00018435  cc                       int3
00018436  ba32000000               mov edx, 0x32
0001843b  b94f010000               mov ecx, 0x14f
00018440  448d4a43                 lea r9d, [rdx + 0x43]
00018444  448d42de                 lea r8d, [rdx - 0x22]
00018448  e8f30f0000               call 0x19440
0001844d  cc                       int3
0001844e  ba32000000               mov edx, 0x32
00018453  b94f010000               mov ecx, 0x14f
00018458  448d4a44                 lea r9d, [rdx + 0x44]
0001845c  448d42de                 lea r8d, [rdx - 0x22]
00018460  e8db0f0000               call 0x19440
00018465  cc                       int3
00018466  ba32000000               mov edx, 0x32
0001846b  b94f010000               mov ecx, 0x14f
00018470  448d4a45                 lea r9d, [rdx + 0x45]
00018474  448d42de                 lea r8d, [rdx - 0x22]
00018478  e8c30f0000               call 0x19440
0001847d  cc                       int3
0001847e  ba32000000               mov edx, 0x32
00018483  b94f010000               mov ecx, 0x14f
00018488  448d4a46                 lea r9d, [rdx + 0x46]
0001848c  448d42de                 lea r8d, [rdx - 0x22]
00018490  e8ab0f0000               call 0x19440
00018495  cc                       int3
00018496  ba32000000               mov edx, 0x32
0001849b  b94f010000               mov ecx, 0x14f
000184a0  448d4a47                 lea r9d, [rdx + 0x47]
000184a4  448d42de                 lea r8d, [rdx - 0x22]
000184a8  e8930f0000               call 0x19440
000184ad  cc                       int3
000184ae  ba32000000               mov edx, 0x32
000184b3  b94f010000               mov ecx, 0x14f
000184b8  448d4a48                 lea r9d, [rdx + 0x48]
000184bc  448d42de                 lea r8d, [rdx - 0x22]
000184c0  e87b0f0000               call 0x19440
000184c5  cc                       int3
000184c6  ba32000000               mov edx, 0x32
000184cb  b94f010000               mov ecx, 0x14f
000184d0  448d4a49                 lea r9d, [rdx + 0x49]
000184d4  448d42de                 lea r8d, [rdx - 0x22]
000184d8  e8630f0000               call 0x19440
000184dd  cc                       int3
000184de  ba32000000               mov edx, 0x32
000184e3  b94f010000               mov ecx, 0x14f
000184e8  448d4a4a                 lea r9d, [rdx + 0x4a]
000184ec  448d42de                 lea r8d, [rdx - 0x22]
000184f0  e84b0f0000               call 0x19440
000184f5  cc                       int3
000184f6  ba32000000               mov edx, 0x32
000184fb  b94f010000               mov ecx, 0x14f
00018500  448d4a4b                 lea r9d, [rdx + 0x4b]
00018504  448d42de                 lea r8d, [rdx - 0x22]
00018508  e8330f0000               call 0x19440
0001850d  cc                       int3
0001850e  ba32000000               mov edx, 0x32
00018513  b94f010000               mov ecx, 0x14f
00018518  448d4a4c                 lea r9d, [rdx + 0x4c]
0001851c  448d42de                 lea r8d, [rdx - 0x22]
00018520  e81b0f0000               call 0x19440
00018525  cc                       int3
00018526  ba32000000               mov edx, 0x32
0001852b  b94f010000               mov ecx, 0x14f
00018530  448d4a4d                 lea r9d, [rdx + 0x4d]
00018534  448d42de                 lea r8d, [rdx - 0x22]
00018538  e8030f0000               call 0x19440
0001853d  cc                       int3
0001853e  6690                     nop
00018540  258201001b               and eax, 0x1b000182
00018545  7f01                     jg 0x18548
00018547  0081800100a2             add byte ptr [rcx - 0x5dfffe80], al
0001854d  7e01                     jle 0x18550
0001854f  00f3                     add bl, dh
00018551  800100                   add byte ptr [rcx], 0
00018554  0d7c010051               or eax, 0x5100017c
00018559  7c01                     jl 0x1855c
0001855b  00c7                     add bh, al
0001855d  7c01                     jl 0x18560
0001855f  00c9                     add cl, cl
00018561  7f01                     jg 0x18564
00018563  00c4                     add ah, al
00018565  7d01                     jge 0x18568
00018567  00c9                     add cl, cl
00018569  810100807e01             add dword ptr [rcx], 0x17e8000
0001856f  0021                     add byte ptr [rcx], ah
00018571  7e01                     jle 0x18574
00018573  007f7d                   add byte ptr [rdi + 0x7d], bh
00018576  0100                     add dword ptr [rax], eax
00018578  6c                       insb byte ptr [rdi], dx
00018579  8101003a7d01             add dword ptr [rcx], 0x17d3a00
0001857f  008282010000             add byte ptr [rdx + 0x182], al
00018585  1010                     adc byte ptr [rax], dl
00018587  1001                     adc byte ptr [rcx], al
00018589  0203                     add al, byte ptr [rbx]
0001858b  0410                     add al, 0x10
0001858d  1010                     adc byte ptr [rax], dl
0001858f  100510101006             adc byte ptr [rip + 0x6101010], al
00018595  1010                     adc byte ptr [rax], dl
00018597  1007                     adc byte ptr [rdi], al
00018599  1008                     adc byte ptr [rax], cl
0001859b  090a                     or dword ptr [rdx], ecx
0001859d  0b0c10                   or ecx, dword ptr [rax + rdx]
000185a0  1010                     adc byte ptr [rax], dl
000185a2  1010                     adc byte ptr [rax], dl
000185a4  1010                     adc byte ptr [rax], dl
000185a6  1010                     adc byte ptr [rax], dl
000185a8  1010                     adc byte ptr [rax], dl
000185aa  1010                     adc byte ptr [rax], dl
000185ac  1010                     adc byte ptr [rax], dl
000185ae  1010                     adc byte ptr [rax], dl
000185b0  1010                     adc byte ptr [rax], dl
000185b2  1010                     adc byte ptr [rax], dl
000185b4  1010                     adc byte ptr [rax], dl
000185b6  1010                     adc byte ptr [rax], dl
000185b8  1010                     adc byte ptr [rax], dl
000185ba  1010                     adc byte ptr [rax], dl
000185bc  1010                     adc byte ptr [rax], dl
000185be  1010                     adc byte ptr [rax], dl
000185c0  1010                     adc byte ptr [rax], dl
000185c2  1010                     adc byte ptr [rax], dl
000185c4  1010                     adc byte ptr [rax], dl
000185c6  1010                     adc byte ptr [rax], dl
000185c8  0d100e100e               or eax, 0xe100e10
000185cd  1010                     adc byte ptr [rax], dl
000185cf  1010                     adc byte ptr [rax], dl
000185d1  1010                     adc byte ptr [rax], dl
000185d3  1010                     adc byte ptr [rax], dl
000185d5  1010                     adc byte ptr [rax], dl
000185d7  1010                     adc byte ptr [rax], dl
000185d9  100a                     adc byte ptr [rdx], cl
000185db  1010                     adc byte ptr [rax], dl
000185dd  1010                     adc byte ptr [rax], dl
