; `CValCompTMEncrParam::PvalInvokeSpecific'::`1'::dtor$1
; aetm_enclave.dll, primary RVA 0x609b0, 31 bytes in 1 chunk(s)

; chunk at RVA 0x609b0 (31 bytes)
000609b0  4055                     push rbp
000609b2  4883ec20                 sub rsp, 0x20
000609b6  488bea                   mov rbp, rdx
000609b9  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
000609c0  488b4d78                 mov rcx, qword ptr [rbp + 0x78]
000609c4  e8b78ffbff               call 0x19980
000609c9  4883c420                 add rsp, 0x20
000609cd  5d                       pop rbp
000609ce  c3                       ret
