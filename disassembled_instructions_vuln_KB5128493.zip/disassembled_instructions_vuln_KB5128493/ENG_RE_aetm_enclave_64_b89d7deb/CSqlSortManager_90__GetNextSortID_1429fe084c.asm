; CSqlSortManager_90::GetNextSortID
; aetm_enclave.dll, primary RVA 0x4bc90, 3551 bytes in 1 chunk(s)

; chunk at RVA 0x4bc90 (3551 bytes)
0004bc90  44894c2420               mov dword ptr [rsp + 0x20], r9d
0004bc95  48894c2408               mov qword ptr [rsp + 8], rcx
0004bc9a  53                       push rbx
0004bc9b  55                       push rbp
0004bc9c  56                       push rsi
0004bc9d  57                       push rdi
0004bc9e  4154                     push r12
0004bca0  4155                     push r13
0004bca2  4156                     push r14
0004bca4  4157                     push r15
0004bca6  4881ec98000000           sub rsp, 0x98
0004bcad  498bd8                   mov rbx, r8
0004bcb0  4c8be2                   mov r12, rdx
0004bcb3  33d2                     xor edx, edx
0004bcb5  41b812040000             mov r8d, 0x412
0004bcbb  8bca                     mov ecx, edx
0004bcbd  8954245c                 mov dword ptr [rsp + 0x5c], edx
0004bcc1  8bf2                     mov esi, edx
0004bcc3  89542450                 mov dword ptr [rsp + 0x50], edx
0004bcc7  410fb70424               movzx eax, word ptr [r12]
0004bccc  8bfa                     mov edi, edx
0004bcce  448b5b10                 mov r11d, dword ptr [rbx + 0x10]
0004bcd2  66413bc0                 cmp ax, r8w
0004bcd6  66898424f0000000         mov word ptr [rsp + 0xf0], ax
0004bcde  448bca                   mov r9d, edx
0004bce1  8b8388000000             mov eax, dword ptr [rbx + 0x88]
0004bce7  0f94c1                   sete cl
0004bcea  41c1eb1a                 shr r11d, 0x1a
0004bcee  4180e301                 and r11b, 1
0004bcf2  89542458                 mov dword ptr [rsp + 0x58], edx
0004bcf6  89542454                 mov dword ptr [rsp + 0x54], edx
0004bcfa  898c2484000000           mov dword ptr [rsp + 0x84], ecx
0004bd01  44895c2460               mov dword ptr [rsp + 0x60], r11d
0004bd06  398384000000             cmp dword ptr [rbx + 0x84], eax
0004bd0c  0f8c670c0000             jl 0x4c979
0004bd12  488b842418010000         mov rax, qword ptr [rsp + 0x118]
0004bd1a  4885c0                   test rax, rax
0004bd1d  7402                     je 0x4bd21
0004bd1f  8810                     mov byte ptr [rax], dl
0004bd21  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004bd28  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004bd30  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
0004bd33  4c8d733c                 lea r14, [rbx + 0x3c]
0004bd37  41bf01000000             mov r15d, 1
0004bd3d  83f904                   cmp ecx, 4
0004bd40  0f8d86000000             jge 0x4bdcc
0004bd46  488b4330                 mov rax, qword ptr [rbx + 0x30]
0004bd4a  660f1f440000             nop word ptr [rax + rax]
0004bd50  4885c0                   test rax, rax
0004bd53  7458                     je 0x4bdad
0004bd55  488b4318                 mov rax, qword ptr [rbx + 0x18]
0004bd59  4885c0                   test rax, rax
0004bd5c  740b                     je 0x4bd69
0004bd5e  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
0004bd62  ffd0                     call rax
0004bd64  0fb7c8                   movzx ecx, ax
0004bd67  eb12                     jmp 0x4bd7b
0004bd69  48635338                 movsxd rdx, dword ptr [rbx + 0x38]
0004bd6d  488b4328                 mov rax, qword ptr [rbx + 0x28]
0004bd71  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
0004bd75  8d4201                   lea eax, [rdx + 1]
0004bd78  894338                   mov dword ptr [rbx + 0x38], eax
0004bd7b  4863435c                 movsxd rax, dword ptr [rbx + 0x5c]
0004bd7f  66894c433c               mov word ptr [rbx + rax*2 + 0x3c], cx
0004bd84  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
0004bd87  48ff4b30                 dec qword ptr [rbx + 0x30]
0004bd8b  ffc1                     inc ecx
0004bd8d  488b4330                 mov rax, qword ptr [rbx + 0x30]
0004bd91  894b5c                   mov dword ptr [rbx + 0x5c], ecx
0004bd94  83f904                   cmp ecx, 4
0004bd97  7cb7                     jl 0x4bd50
0004bd99  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004bd9e  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004bda3  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004bdab  eb27                     jmp 0x4bdd4
0004bdad  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004bdb2  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004bdb7  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004bdbf  4863c1                   movsxd rax, ecx
0004bdc2  33c9                     xor ecx, ecx
0004bdc4  66894c433c               mov word ptr [rbx + rax*2 + 0x3c], cx
0004bdc9  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
0004bdcc  85c9                     test ecx, ecx
0004bdce  0f84840b0000             je 0x4c958
0004bdd4  837b0400                 cmp dword ptr [rbx + 4], 0
0004bdd8  7413                     je 0x4bded
0004bdda  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
0004bdde  6639433c                 cmp word ptr [rbx + 0x3c], ax
0004bde2  7509                     jne 0x4bded
0004bde4  413bcf                   cmp ecx, r15d
0004bde7  0f845d0b0000             je 0x4c94a
0004bded  4c638388000000           movsxd r8, dword ptr [rbx + 0x88]
0004bdf4  443b8380000000           cmp r8d, dword ptr [rbx + 0x80]
0004bdfb  0f8d500b0000             jge 0x4c951
0004be01  498b442408               mov rax, qword ptr [r12 + 8]
0004be06  0fb74b3c                 movzx ecx, word ptr [rbx + 0x3c]
0004be0a  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004be0d  235314                   and edx, dword ptr [rbx + 0x14]
0004be10  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004be14  42891480                 mov dword ptr [rax + r8*4], edx
0004be18  33d2                     xor edx, edx
0004be1a  85ed                     test ebp, ebp
0004be1c  740e                     je 0x4be2c
0004be1e  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004be25  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004be29  891488                   mov dword ptr [rax + rcx*4], edx
0004be2c  4032ed                   xor bpl, bpl
0004be2f  4585c9                   test r9d, r9d
0004be32  0f8532020000             jne 0x4c06a
0004be38  44394b04                 cmp dword ptr [rbx + 4], r9d
0004be3c  0f8480000000             je 0x4bec2
0004be42  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
0004be46  6639433c                 cmp word ptr [rbx + 0x3c], ax
0004be4a  7576                     jne 0x4bec2
0004be4c  44397b5c                 cmp dword ptr [rbx + 0x5c], r15d
0004be50  7e70                     jle 0x4bec2
0004be52  488d533e                 lea rdx, [rbx + 0x3e]
0004be56  458d411e                 lea r8d, [r9 + 0x1e]
0004be5a  488d4b3c                 lea rcx, [rbx + 0x3c]
0004be5e  e85c240100               call 0x5e2bf
0004be63  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004be66  0fb74b3c                 movzx ecx, word ptr [rbx + 0x3c]
0004be6a  498b442408               mov rax, qword ptr [r12 + 8]
0004be6f  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004be72  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004be79  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004be7d  235314                   and edx, dword ptr [rbx + 0x14]
0004be80  891488                   mov dword ptr [rax + rcx*4], edx
0004be83  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004be88  33c9                     xor ecx, ecx
0004be8a  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004be91  8bf1                     mov esi, ecx
0004be93  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
0004be97  450fb71490               movzx r10d, word ptr [r8 + rdx*4]
0004be9c  4d8d0c90                 lea r9, [r8 + rdx*4]
0004bea0  418bc2                   mov eax, r10d
0004bea3  c1e808                   shr eax, 8
0004bea6  83f80b                   cmp eax, 0xb
0004bea9  0f872e090000             ja 0x4c7dd
0004beaf  488d3d4a41fbff           lea rdi, [rip - 0x4beb6]
0004beb6  8b8c87d4c90400           mov ecx, dword ptr [rdi + rax*4 + 0x4c9d4]
0004bebd  4803cf                   add rcx, rdi
0004bec0  ffe1                     jmp rcx
0004bec2  4585d2                   test r10d, r10d
0004bec5  7408                     je 0x4becf
0004bec7  85ff                     test edi, edi
0004bec9  0f859b010000             jne 0x4c06a
0004becf  41837c241400             cmp dword ptr [r12 + 0x14], 0
0004bed5  0f848f010000             je 0x4c06a
0004bedb  448b535c                 mov r10d, dword ptr [rbx + 0x5c]
0004bedf  453bd7                   cmp r10d, r15d
0004bee2  0f8e82010000             jle 0x4c06a
0004bee8  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004beef  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004bef3  f6448803c0               test byte ptr [rax + rcx*4 + 3], 0xc0
0004bef8  4c8d0c88                 lea r9, [rax + rcx*4]
0004befc  0f8468010000             je 0x4c06a
0004bf02  41837c241800             cmp dword ptr [r12 + 0x18], 0
0004bf08  743d                     je 0x4bf47
0004bf0a  8954245c                 mov dword ptr [rsp + 0x5c], edx
0004bf0e  8bf2                     mov esi, edx
0004bf10  4183fa02                 cmp r10d, 2
0004bf14  7e31                     jle 0x4bf47
0004bf16  0fb7433e                 movzx eax, word ptr [rbx + 0x3e]
0004bf1a  663b430c                 cmp ax, word ptr [rbx + 0xc]
0004bf1e  7427                     je 0x4bf47
0004bf20  8bc8                     mov ecx, eax
0004bf22  498b442408               mov rax, qword ptr [r12 + 8]
0004bf27  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004bf2a  235314                   and edx, dword ptr [rbx + 0x14]
0004bf2d  413311                   xor edx, dword ptr [r9]
0004bf30  f7c2ffffffe7             test edx, 0xe7ffffff
0004bf36  750f                     jne 0x4bf47
0004bf38  418bf7                   mov esi, r15d
0004bf3b  44897c245c               mov dword ptr [rsp + 0x5c], r15d
0004bf40  4c8d733e                 lea r14, [rbx + 0x3e]
0004bf44  41ffca                   dec r10d
0004bf47  450fb74e02               movzx r9d, word ptr [r14 + 2]
0004bf4c  66443b4b0c               cmp r9w, word ptr [rbx + 0xc]
0004bf51  0f8404010000             je 0x4c05b
0004bf57  498b542420               mov rdx, qword ptr [r12 + 0x20]
0004bf5c  0fb74204                 movzx eax, word ptr [rdx + 4]
0004bf60  85c0                     test eax, eax
0004bf62  0f84f3000000             je 0x4c05b
0004bf68  410fb70e                 movzx ecx, word ptr [r14]
0004bf6c  0f1f4000                 nop dword ptr [rax]
0004bf70  66394a06                 cmp word ptr [rdx + 6], cx
0004bf74  761b                     jbe 0x4bf91
0004bf76  4883c210                 add rdx, 0x10
0004bf7a  412bc7                   sub eax, r15d
0004bf7d  75f1                     jne 0x4bf70
0004bf7f  498d46fe                 lea rax, [r14 - 2]
0004bf83  85f6                     test esi, esi
0004bf85  490f44c6                 cmove rax, r14
0004bf89  4c8bf0                   mov r14, rax
0004bf8c  e90e010000               jmp 0x4c09f
0004bf91  0f85c4000000             jne 0x4c05b
0004bf97  66443b4a0c               cmp r9w, word ptr [rdx + 0xc]
0004bf9c  0f82b9000000             jb 0x4c05b
0004bfa2  66443b4a0e               cmp r9w, word ptr [rdx + 0xe]
0004bfa7  0f87ae000000             ja 0x4c05b
0004bfad  0fb74a08                 movzx ecx, word ptr [rdx + 8]
0004bfb1  498b442428               mov rax, qword ptr [r12 + 0x28]
0004bfb6  440fb7420a               movzx r8d, word ptr [rdx + 0xa]
0004bfbb  488d3cc8                 lea rdi, [rax + rcx*8]
0004bfbf  4585c0                   test r8d, r8d
0004bfc2  0f848f000000             je 0x4c057
0004bfc8  6644390f                 cmp word ptr [rdi], r9w
0004bfcc  7616                     jbe 0x4bfe4
0004bfce  4883c708                 add rdi, 8
0004bfd2  452bc7                   sub r8d, r15d
0004bfd5  75f1                     jne 0x4bfc8
0004bfd7  eb7e                     jmp 0x4c057
0004bfd9  0f1f8000000000           nop dword ptr [rax]
0004bfe0  6644390f                 cmp word ptr [rdi], r9w
0004bfe4  7571                     jne 0x4c057
0004bfe6  0fb74f02                 movzx ecx, word ptr [rdi + 2]
0004bfea  6685c9                   test cx, cx
0004bfed  743c                     je 0x4c02b
0004bfef  4183fa02                 cmp r10d, 2
0004bff3  7e10                     jle 0x4c005
0004bff5  410fb74604               movzx eax, word ptr [r14 + 4]
0004bffa  663bc8                   cmp cx, ax
0004bffd  7506                     jne 0x4c005
0004bfff  6639430c                 cmp word ptr [rbx + 0xc], ax
0004c003  750b                     jne 0x4c010
0004c005  4883c708                 add rdi, 8
0004c009  452bc7                   sub r8d, r15d
0004c00c  75d2                     jne 0x4bfe0
0004c00e  eb47                     jmp 0x4c057
0004c010  85f6                     test esi, esi
0004c012  752f                     jne 0x4c043
0004c014  488d5340                 lea rdx, [rbx + 0x40]
0004c018  448d461c                 lea r8d, [rsi + 0x1c]
0004c01c  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c020  e89a220100               call 0x5e2bf
0004c025  83435cfe                 add dword ptr [rbx + 0x5c], -2
0004c029  eb18                     jmp 0x4c043
0004c02b  85f6                     test esi, esi
0004c02d  7514                     jne 0x4c043
0004c02f  488d533e                 lea rdx, [rbx + 0x3e]
0004c033  448d461e                 lea r8d, [rsi + 0x1e]
0004c037  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c03b  e87f220100               call 0x5e2bf
0004c040  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004c043  8b5704                   mov edx, dword ptr [rdi + 4]
0004c046  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c04d  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c051  235314                   and edx, dword ptr [rbx + 0x14]
0004c054  891488                   mov dword ptr [rax + rcx*4], edx
0004c057  8b7c2450                 mov edi, dword ptr [rsp + 0x50]
0004c05b  498d46fe                 lea rax, [r14 - 2]
0004c05f  85f6                     test esi, esi
0004c061  490f44c6                 cmove rax, r14
0004c065  4c8bf0                   mov r14, rax
0004c068  eb35                     jmp 0x4c09f
0004c06a  4584db                   test r11b, r11b
0004c06d  7430                     je 0x4c09f
0004c06f  b800280000               mov eax, 0x2800
0004c074  b9ff030000               mov ecx, 0x3ff
0004c079  6603433c                 add ax, word ptr [rbx + 0x3c]
0004c07d  663bc1                   cmp ax, cx
0004c080  771d                     ja 0x4c09f
0004c082  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c089  4c8bc3                   mov r8, rbx
0004c08c  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c090  498bd4                   mov rdx, r12
0004c093  4c8d0c88                 lea r9, [rax + rcx*4]
0004c097  e8842a0000               call 0x4eb20
0004c09c  0fb6e8                   movzx ebp, al
0004c09f  837b0400                 cmp dword ptr [rbx + 4], 0
0004c0a3  0f84dafdffff             je 0x4be83
0004c0a9  837c245400               cmp dword ptr [rsp + 0x54], 0
0004c0ae  0f85cffdffff             jne 0x4be83
0004c0b4  410fb706                 movzx eax, word ptr [r14]
0004c0b8  ff442458                 inc dword ptr [rsp + 0x58]
0004c0bc  83c0df                   add eax, -0x21
0004c0bf  83f83e                   cmp eax, 0x3e
0004c0c2  0f87bbfdffff             ja 0x4be83
0004c0c8  488d15313ffbff           lea rdx, [rip - 0x4c0cf]
0004c0cf  4898                     cdqe
0004c0d1  0fb6840230ca0400         movzx eax, byte ptr [rdx + rax + 0x4ca30]
0004c0d9  8b8c8204ca0400           mov ecx, dword ptr [rdx + rax*4 + 0x4ca04]
0004c0e0  4803ca                   add rcx, rdx
0004c0e3  ffe1                     jmp rcx
0004c0e5  85ff                     test edi, edi
0004c0e7  0f8596fdffff             jne 0x4be83
0004c0ed  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c0f4  bafcff0000               mov edx, 0xfffc
0004c0f9  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c0fd  458bdf                   mov r11d, r15d
0004c100  44897c2450               mov dword ptr [rsp + 0x50], r15d
0004c105  4533ff                   xor r15d, r15d
0004c108  44897c2458               mov dword ptr [rsp + 0x58], r15d
0004c10d  66891488                 mov word ptr [rax + rcx*4], dx
0004c111  33c9                     xor ecx, ecx
0004c113  898c24f8000000           mov dword ptr [rsp + 0xf8], ecx
0004c11a  e96bfdffff               jmp 0x4be8a
0004c11f  85ff                     test edi, edi
0004c121  0f845cfdffff             je 0x4be83
0004c127  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c12e  bafbff0000               mov edx, 0xfffb
0004c133  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c137  66891488                 mov word ptr [rax + rcx*4], dx
0004c13b  33c9                     xor ecx, ecx
0004c13d  448bd9                   mov r11d, ecx
0004c140  894c2450                 mov dword ptr [rsp + 0x50], ecx
0004c144  e941fdffff               jmp 0x4be8a
0004c149  85ff                     test edi, edi
0004c14b  0f8432fdffff             je 0x4be83
0004c151  44397c2458               cmp dword ptr [rsp + 0x58], r15d
0004c156  0f8527fdffff             jne 0x4be83
0004c15c  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
0004c163  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c168  0f841afdffff             je 0x4be88
0004c16e  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c175  baf9ff0000               mov edx, 0xfff9
0004c17a  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c17e  66891488                 mov word ptr [rax + rcx*4], dx
0004c182  33c9                     xor ecx, ecx
0004c184  894c2458                 mov dword ptr [rsp + 0x58], ecx
0004c188  e9fdfcffff               jmp 0x4be8a
0004c18d  85ff                     test edi, edi
0004c18f  0f84eefcffff             je 0x4be83
0004c195  44397c2458               cmp dword ptr [rsp + 0x58], r15d
0004c19a  0f85e3fcffff             jne 0x4be83
0004c1a0  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
0004c1a7  ebba                     jmp 0x4c163
0004c1a9  85ff                     test edi, edi
0004c1ab  0f84d2fcffff             je 0x4be83
0004c1b1  44397c2458               cmp dword ptr [rsp + 0x58], r15d
0004c1b6  0f84c7fcffff             je 0x4be83
0004c1bc  44397b5c                 cmp dword ptr [rbx + 0x5c], r15d
0004c1c0  0f8ebdfcffff             jle 0x4be83
0004c1c6  6641837e025d             cmp word ptr [r14 + 2], 0x5d
0004c1cc  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c1d1  0f84b1fcffff             je 0x4be88
0004c1d7  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c1de  bafaff0000               mov edx, 0xfffa
0004c1e3  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c1e7  66891488                 mov word ptr [rax + rcx*4], dx
0004c1eb  33c9                     xor ecx, ecx
0004c1ed  448bf9                   mov r15d, ecx
0004c1f0  e995fcffff               jmp 0x4be8a
0004c1f5  85ff                     test edi, edi
0004c1f7  0f8586fcffff             jne 0x4be83
0004c1fd  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
0004c204  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c209  0f8479fcffff             je 0x4be88
0004c20f  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c216  baf7ff0000               mov edx, 0xfff7
0004c21b  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c21f  66891488                 mov word ptr [rax + rcx*4], dx
0004c223  e960fcffff               jmp 0x4be88
0004c228  85ff                     test edi, edi
0004c22a  0f8553fcffff             jne 0x4be83
0004c230  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
0004c237  ebcb                     jmp 0x4c204
0004c239  85ff                     test edi, edi
0004c23b  0f8542fcffff             jne 0x4be83
0004c241  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
0004c248  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c24d  0f8435fcffff             je 0x4be88
0004c253  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c25a  bafdff0000               mov edx, 0xfffd
0004c25f  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c263  66891488                 mov word ptr [rax + rcx*4], dx
0004c267  e91cfcffff               jmp 0x4be88
0004c26c  85ff                     test edi, edi
0004c26e  0f850ffcffff             jne 0x4be83
0004c274  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
0004c27b  448b5c2450               mov r11d, dword ptr [rsp + 0x50]
0004c280  0f8402fcffff             je 0x4be88
0004c286  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c28d  bafeff0000               mov edx, 0xfffe
0004c292  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c296  66891488                 mov word ptr [rax + rcx*4], dx
0004c29a  e9e9fbffff               jmp 0x4be88
0004c29f  85ff                     test edi, edi
0004c2a1  0f85dcfbffff             jne 0x4be83
0004c2a7  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
0004c2ae  ebcb                     jmp 0x4c27b
0004c2b0  8b4310                   mov eax, dword ptr [rbx + 0x10]
0004c2b3  a802                     test al, 2
0004c2b5  751e                     jne 0x4c2d5
0004c2b7  0fbae01e                 bt eax, 0x1e
0004c2bb  0f8366010000             jae 0x4c427
0004c2c1  8b435c                   mov eax, dword ptr [rbx + 0x5c]
0004c2c4  394338                   cmp dword ptr [rbx + 0x38], eax
0004c2c7  0f855a010000             jne 0x4c427
0004c2cd  85d2                     test edx, edx
0004c2cf  0f8552010000             jne 0x4c427
0004c2d5  488d533e                 lea rdx, [rbx + 0x3e]
0004c2d9  41b81e000000             mov r8d, 0x1e
0004c2df  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c2e3  e8d71f0100               call 0x5e2bf
0004c2e8  488b8c2420010000         mov rcx, qword ptr [rsp + 0x120]
0004c2f0  be01000000               mov esi, 1
0004c2f5  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004c2f8  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c300  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c307  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c30f  4885c9                   test rcx, rcx
0004c312  0f8426010000             je 0x4c43e
0004c318  48ff01                   inc qword ptr [rcx]
0004c31b  e91e010000               jmp 0x4c43e
0004c320  498b442408               mov rax, qword ptr [r12 + 8]
0004c325  410fb70e                 movzx ecx, word ptr [r14]
0004c329  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c32c  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c334  8908                     mov dword ptr [rax], ecx
0004c336  f6431004                 test byte ptr [rbx + 0x10], 4
0004c33a  0f84ef000000             je 0x4c42f
0004c340  eb93                     jmp 0x4c2d5
0004c342  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c34a  33d2                     xor edx, edx
0004c34c  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c354  8910                     mov dword ptr [rax], edx
0004c356  4585d2                   test r10d, r10d
0004c359  7412                     je 0x4c36d
0004c35b  395308                   cmp dword ptr [rbx + 8], edx
0004c35e  0f84cd040000             je 0x4c831
0004c364  4585db                   test r11d, r11d
0004c367  0f85c4040000             jne 0x4c831
0004c36d  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c371  498bd6                   mov rdx, r14
0004c374  48638388000000           movsxd rax, dword ptr [rbx + 0x88]
0004c37b  4c63435c                 movsxd r8, dword ptr [rbx + 0x5c]
0004c37f  4d03c0                   add r8, r8
0004c382  0fb63c81                 movzx edi, byte ptr [rcx + rax*4]
0004c386  498d4e02                 lea rcx, [r14 + 2]
0004c38a  e8301f0100               call 0x5e2bf
0004c38f  8344245403               add dword ptr [rsp + 0x54], 3
0004c394  488d0cbd00000000         lea rcx, [rdi*4]
0004c39c  488d155d3cfbff           lea rdx, [rip - 0x4c3a3]
0004c3a3  0fb78411d0a33100         movzx eax, word ptr [rcx + rdx + 0x31a3d0]
0004c3ab  66418906                 mov word ptr [r14], ax
0004c3af  0fb78411d2a33100         movzx eax, word ptr [rcx + rdx + 0x31a3d2]
0004c3b7  6641894602               mov word ptr [r14 + 2], ax
0004c3bc  8b535c                   mov edx, dword ptr [rbx + 0x5c]
0004c3bf  c7436001000000           mov dword ptr [rbx + 0x60], 1
0004c3c6  ffc2                     inc edx
0004c3c8  89535c                   mov dword ptr [rbx + 0x5c], edx
0004c3cb  410fb74e02               movzx ecx, word ptr [r14 + 2]
0004c3d0  498b442408               mov rax, qword ptr [r12 + 8]
0004c3d5  807c880102               cmp byte ptr [rax + rcx*4 + 1], 2
0004c3da  488d2c88                 lea rbp, [rax + rcx*4]
0004c3de  7542                     jne 0x4c422
0004c3e0  4c63c2                   movsxd r8, edx
0004c3e3  498d4e04                 lea rcx, [r14 + 4]
0004c3e7  4d03c0                   add r8, r8
0004c3ea  498d5602                 lea rdx, [r14 + 2]
0004c3ee  e8cc1e0100               call 0x5e2bf
0004c3f3  0fb64d00                 movzx ecx, byte ptr [rbp]
0004c3f7  488d15023cfbff           lea rdx, [rip - 0x4c3fe]
0004c3fe  0fb7848ad0a33100         movzx eax, word ptr [rdx + rcx*4 + 0x31a3d0]
0004c406  6641894602               mov word ptr [r14 + 2], ax
0004c40b  0fb7848ad2a33100         movzx eax, word ptr [rdx + rcx*4 + 0x31a3d2]
0004c413  6641894604               mov word ptr [r14 + 4], ax
0004c418  ff435c                   inc dword ptr [rbx + 0x5c]
0004c41b  ff4360                   inc dword ptr [rbx + 0x60]
0004c41e  ff442454                 inc dword ptr [rsp + 0x54]
0004c422  be01000000               mov esi, 1
0004c427  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c42f  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c436  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c43e  33d2                     xor edx, edx
0004c440  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004c445  4585c9                   test r9d, r9d
0004c448  7e0a                     jle 0x4c454
0004c44a  41ffc9                   dec r9d
0004c44d  8910                     mov dword ptr [rax], edx
0004c44f  44894c2454               mov dword ptr [rsp + 0x54], r9d
0004c454  8b7c2450                 mov edi, dword ptr [rsp + 0x50]
0004c458  85f6                     test esi, esi
0004c45a  8b74245c                 mov esi, dword ptr [rsp + 0x5c]
0004c45e  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004c463  0f85c7f8ffff             jne 0x4bd30
0004c469  488d533e                 lea rdx, [rbx + 0x3e]
0004c46d  41b81e000000             mov r8d, 0x1e
0004c473  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c477  4585c9                   test r9d, r9d
0004c47a  0f84bd030000             je 0x4c83d
0004c480  e83a1e0100               call 0x5e2bf
0004c485  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004c488  ff8388000000             inc dword ptr [rbx + 0x88]
0004c48e  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004c493  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004c498  e98bf8ffff               jmp 0x4bd28
0004c49d  488b842418010000         mov rax, qword ptr [rsp + 0x118]
0004c4a5  4885c0                   test rax, rax
0004c4a8  7413                     je 0x4c4bd
0004c4aa  4180fa01                 cmp r10b, 1
0004c4ae  770d                     ja 0x4c4bd
0004c4b0  c60001                   mov byte ptr [rax], 1
0004c4b3  8b9388000000             mov edx, dword ptr [rbx + 0x88]
0004c4b9  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
0004c4bd  4863c2                   movsxd rax, edx
0004c4c0  41803c8001               cmp byte ptr [r8 + rax*4], 1
0004c4c5  7620                     jbe 0x4c4e7
0004c4c7  498b442408               mov rax, qword ptr [r12 + 8]
0004c4cc  410fb70e                 movzx ecx, word ptr [r14]
0004c4d0  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c4d3  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c4db  8908                     mov dword ptr [rax], ecx
0004c4dd  8b9388000000             mov edx, dword ptr [rbx + 0x88]
0004c4e3  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
0004c4e7  4863c2                   movsxd rax, edx
0004c4ea  4c8d8c24f8000000         lea r9, [rsp + 0xf8]
0004c4f2  4c89642438               mov qword ptr [rsp + 0x38], r12
0004c4f7  488d54247c               lea rdx, [rsp + 0x7c]
0004c4fc  498d0c80                 lea rcx, [r8 + rax*4]
0004c500  8b842484000000           mov eax, dword ptr [rsp + 0x84]
0004c507  448b4314                 mov r8d, dword ptr [rbx + 0x14]
0004c50b  89442430                 mov dword ptr [rsp + 0x30], eax
0004c50f  410fb7442440             movzx eax, word ptr [r12 + 0x40]
0004c515  6689442428               mov word ptr [rsp + 0x28], ax
0004c51a  488d842488000000         lea rax, [rsp + 0x88]
0004c522  4889442420               mov qword ptr [rsp + 0x20], rax
0004c527  e83476ffff               call 0x43b60
0004c52c  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c533  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c53b  85ed                     test ebp, ebp
0004c53d  7415                     je 0x4c554
0004c53f  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004c546  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
0004c54a  8b842488000000           mov eax, dword ptr [rsp + 0x88]
0004c551  890491                   mov dword ptr [rcx + rdx*4], eax
0004c554  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c55c  e9ddfeffff               jmp 0x4c43e
0004c561  498b442408               mov rax, qword ptr [r12 + 8]
0004c566  410fb70e                 movzx ecx, word ptr [r14]
0004c56a  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004c56d  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c575  418911                   mov dword ptr [r9], edx
0004c578  8910                     mov dword ptr [rax], edx
0004c57a  e9b0feffff               jmp 0x4c42f
0004c57f  b860110000               mov eax, 0x1160
0004c584  66413906                 cmp word ptr [r14], ax
0004c588  0f83bb010000             jae 0x4c749
0004c58e  448b4b5c                 mov r9d, dword ptr [rbx + 0x5c]
0004c592  488d842480000000         lea rax, [rsp + 0x80]
0004c59a  488b8c24e0000000         mov rcx, qword ptr [rsp + 0xe0]
0004c5a2  4d8bc6                   mov r8, r14
0004c5a5  4889442438               mov qword ptr [rsp + 0x38], rax
0004c5aa  498bd4                   mov rdx, r12
0004c5ad  488d442464               lea rax, [rsp + 0x64]
0004c5b2  c744243003000000         mov dword ptr [rsp + 0x30], 3
0004c5ba  4889442428               mov qword ptr [rsp + 0x28], rax
0004c5bf  488d8424e8000000         lea rax, [rsp + 0xe8]
0004c5c7  4889442420               mov qword ptr [rsp + 0x20], rax
0004c5cc  e85f470000               call 0x50d30
0004c5d1  8bf8                     mov edi, eax
0004c5d3  85c0                     test eax, eax
0004c5d5  0f8e6e010000             jle 0x4c749
0004c5db  0faee8                   lfence
0004c5de  0fb78424e8000000         movzx eax, word ptr [rsp + 0xe8]
0004c5e6  4533c0                   xor r8d, r8d
0004c5e9  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004c5f0  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c5f4  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c5fb  668944246c               mov word ptr [rsp + 0x6c], ax
0004c600  66c744246e0202           mov word ptr [rsp + 0x6e], 0x202
0004c607  8b44246c                 mov eax, dword ptr [rsp + 0x6c]
0004c60b  890491                   mov dword ptr [rcx + rdx*4], eax
0004c60e  85ed                     test ebp, ebp
0004c610  740f                     je 0x4c621
0004c612  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c619  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c61d  44890488                 mov dword ptr [rax + rcx*4], r8d
0004c621  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c628  41b900ff0000             mov r9d, 0xff00
0004c62e  488bd1                   mov rdx, rcx
0004c631  66c74424720202           mov word ptr [rsp + 0x72], 0x202
0004c638  8d4101                   lea eax, [rcx + 1]
0004c63b  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c63f  898388000000             mov dword ptr [rbx + 0x88], eax
0004c645  0fb6442464               movzx eax, byte ptr [rsp + 0x64]
0004c64a  66410bc1                 or ax, r9w
0004c64e  6689442470               mov word ptr [rsp + 0x70], ax
0004c653  8b442470                 mov eax, dword ptr [rsp + 0x70]
0004c657  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
0004c65b  85ed                     test ebp, ebp
0004c65d  740f                     je 0x4c66e
0004c65f  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c666  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c66a  44890488                 mov dword ptr [rax + rcx*4], r8d
0004c66e  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c675  488bd1                   mov rdx, rcx
0004c678  66c74424760202           mov word ptr [rsp + 0x76], 0x202
0004c67f  8d4101                   lea eax, [rcx + 1]
0004c682  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c686  898388000000             mov dword ptr [rbx + 0x88], eax
0004c68c  0fb6442465               movzx eax, byte ptr [rsp + 0x65]
0004c691  66410bc1                 or ax, r9w
0004c695  6689442474               mov word ptr [rsp + 0x74], ax
0004c69a  8b442474                 mov eax, dword ptr [rsp + 0x74]
0004c69e  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
0004c6a2  85ed                     test ebp, ebp
0004c6a4  740f                     je 0x4c6b5
0004c6a6  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c6ad  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c6b1  44890488                 mov dword ptr [rax + rcx*4], r8d
0004c6b5  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c6bc  488bd1                   mov rdx, rcx
0004c6bf  66c744247a0202           mov word ptr [rsp + 0x7a], 0x202
0004c6c6  8d4101                   lea eax, [rcx + 1]
0004c6c9  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c6cd  898388000000             mov dword ptr [rbx + 0x88], eax
0004c6d3  0fb6442466               movzx eax, byte ptr [rsp + 0x66]
0004c6d8  66410bc1                 or ax, r9w
0004c6dc  6689442478               mov word ptr [rsp + 0x78], ax
0004c6e1  8b442478                 mov eax, dword ptr [rsp + 0x78]
0004c6e5  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
0004c6e9  85ed                     test ebp, ebp
0004c6eb  740f                     je 0x4c6fc
0004c6ed  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c6f4  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c6f8  44890488                 mov dword ptr [rax + rcx*4], r8d
0004c6fc  ffcf                     dec edi
0004c6fe  4863c7                   movsxd rax, edi
0004c701  488d1400                 lea rdx, [rax + rax]
0004c705  498b442408               mov rax, qword ptr [r12 + 8]
0004c70a  420fb70c32               movzx ecx, word ptr [rdx + r14]
0004c70f  4883c23c                 add rdx, 0x3c
0004c713  4803d3                   add rdx, rbx
0004c716  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c719  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c721  8908                     mov dword ptr [rax], ecx
0004c723  b810000000               mov eax, 0x10
0004c728  2bc7                     sub eax, edi
0004c72a  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c72e  4c63c0                   movsxd r8, eax
0004c731  4d03c0                   add r8, r8
0004c734  e8861b0100               call 0x5e2bf
0004c739  297b5c                   sub dword ptr [rbx + 0x5c], edi
0004c73c  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c744  e9edfcffff               jmp 0x4c436
0004c749  448b942408010000         mov r10d, dword ptr [rsp + 0x108]
0004c751  4585d2                   test r10d, r10d
0004c754  7565                     jne 0x4c7bb
0004c756  498b442408               mov rax, qword ptr [r12 + 8]
0004c75b  410fb70e                 movzx ecx, word ptr [r14]
0004c75f  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004c762  b812040000               mov eax, 0x412
0004c767  89542468                 mov dword ptr [rsp + 0x68], edx
0004c76b  440fb6c2                 movzx r8d, dl
0004c76f  c1ea10                   shr edx, 0x10
0004c772  66398424f0000000         cmp word ptr [rsp + 0xf0], ax
0004c77a  7518                     jne 0x4c794
0004c77c  0fb6c2                   movzx eax, dl
0004c77f  420fb64c2048             movzx ecx, byte ptr [rax + r12 + 0x48]
0004c785  66c1e108                 shl cx, 8
0004c789  66410bc8                 or cx, r8w
0004c78d  66894c2468               mov word ptr [rsp + 0x68], cx
0004c792  eb10                     jmp 0x4c7a4
0004c794  0fb6c2                   movzx eax, dl
0004c797  66c1e008                 shl ax, 8
0004c79b  66410bc0                 or ax, r8w
0004c79f  6689442468               mov word ptr [rsp + 0x68], ax
0004c7a4  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004c7ab  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c7af  c644246a02               mov byte ptr [rsp + 0x6a], 2
0004c7b4  8b442468                 mov eax, dword ptr [rsp + 0x68]
0004c7b8  890491                   mov dword ptr [rcx + rdx*4], eax
0004c7bb  498b442408               mov rax, qword ptr [r12 + 8]
0004c7c0  410fb70e                 movzx ecx, word ptr [r14]
0004c7c4  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c7cb  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c7ce  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c7d6  8908                     mov dword ptr [rax], ecx
0004c7d8  e961fcffff               jmp 0x4c43e
0004c7dd  498b442408               mov rax, qword ptr [r12 + 8]
0004c7e2  410fb70e                 movzx ecx, word ptr [r14]
0004c7e6  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004c7e9  488b842400010000         mov rax, qword ptr [rsp + 0x100]
0004c7f1  8908                     mov dword ptr [rax], ecx
0004c7f3  4084ed                   test bpl, bpl
0004c7f6  0f8433fcffff             je 0x4c42f
0004c7fc  48638388000000           movsxd rax, dword ptr [rbx + 0x88]
0004c803  4c8d048500000000         lea r8, [rax*4]
0004c80b  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c80f  418b1400                 mov edx, dword ptr [r8 + rax]
0004c813  8bc2                     mov eax, edx
0004c815  c1ea18                   shr edx, 0x18
0004c818  48c1e810                 shr rax, 0x10
0004c81c  0fb6c8                   movzx ecx, al
0004c81f  488b4370                 mov rax, qword ptr [rbx + 0x70]
0004c823  c1e108                   shl ecx, 8
0004c826  0bca                     or ecx, edx
0004c828  41890c00                 mov dword ptr [r8 + rax], ecx
0004c82c  e9f6fbffff               jmp 0x4c427
0004c831  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c838  e903fcffff               jmp 0x4c440
0004c83d  e87d1a0100               call 0x5e2bf
0004c842  8b435c                   mov eax, dword ptr [rbx + 0x5c]
0004c845  ffc8                     dec eax
0004c847  89435c                   mov dword ptr [rbx + 0x5c], eax
0004c84a  4585ff                   test r15d, r15d
0004c84d  0f84de000000             je 0x4c931
0004c853  33ed                     xor ebp, ebp
0004c855  85c0                     test eax, eax
0004c857  7543                     jne 0x4c89c
0004c859  48396b30                 cmp qword ptr [rbx + 0x30], rbp
0004c85d  0f84c7000000             je 0x4c92a
0004c863  488b4318                 mov rax, qword ptr [rbx + 0x18]
0004c867  4885c0                   test rax, rax
0004c86a  740e                     je 0x4c87a
0004c86c  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
0004c870  ffd0                     call rax
0004c872  0fb7c8                   movzx ecx, ax
0004c875  8b435c                   mov eax, dword ptr [rbx + 0x5c]
0004c878  eb14                     jmp 0x4c88e
0004c87a  48635338                 movsxd rdx, dword ptr [rbx + 0x38]
0004c87e  488b4328                 mov rax, qword ptr [rbx + 0x28]
0004c882  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
0004c886  8d4201                   lea eax, [rdx + 1]
0004c889  894338                   mov dword ptr [rbx + 0x38], eax
0004c88c  8bc5                     mov eax, ebp
0004c88e  4898                     cdqe
0004c890  6641890c46               mov word ptr [r14 + rax*2], cx
0004c895  ff435c                   inc dword ptr [rbx + 0x5c]
0004c898  48ff4b30                 dec qword ptr [rbx + 0x30]
0004c89c  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004c8a3  41baf7ff0000             mov r10d, 0xfff7
0004c8a9  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c8ad  440fb70488               movzx r8d, word ptr [rax + rcx*4]
0004c8b2  4c8d0c88                 lea r9, [rax + rcx*4]
0004c8b6  66453bc2                 cmp r8w, r10w
0004c8ba  7525                     jne 0x4c8e1
0004c8bc  6641833e25               cmp word ptr [r14], 0x25
0004c8c1  751e                     jne 0x4c8e1
0004c8c3  41b81e000000             mov r8d, 0x1e
0004c8c9  488d533e                 lea rdx, [rbx + 0x3e]
0004c8cd  488d4b3c                 lea rcx, [rbx + 0x3c]
0004c8d1  e8e9190100               call 0x5e2bf
0004c8d6  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004c8d9  8b435c                   mov eax, dword ptr [rbx + 0x5c]
0004c8dc  e974ffffff               jmp 0x4c855
0004c8e1  410fb7c0                 movzx eax, r8w
0004c8e5  66c1e808                 shr ax, 8
0004c8e9  3c05                     cmp al, 5
0004c8eb  743d                     je 0x4c92a
0004c8ed  498b442408               mov rax, qword ptr [r12 + 8]
0004c8f2  410fb70e                 movzx ecx, word ptr [r14]
0004c8f6  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004c8f9  0fb7c2                   movzx eax, dx
0004c8fc  66c1e808                 shr ax, 8
0004c900  3c01                     cmp al, 1
0004c902  7526                     jne 0x4c92a
0004c904  66453bc2                 cmp r8w, r10w
0004c908  73b9                     jae 0x4c8c3
0004c90a  410fb64102               movzx eax, byte ptr [r9 + 2]
0004c90f  c1ea10                   shr edx, 0x10
0004c912  0fb6ca                   movzx ecx, dl
0004c915  6603c8                   add cx, ax
0004c918  b8ff000000               mov eax, 0xff
0004c91d  663bc8                   cmp cx, ax
0004c920  7602                     jbe 0x4c924
0004c922  8bc8                     mov ecx, eax
0004c924  41884902                 mov byte ptr [r9 + 2], cl
0004c928  eb99                     jmp 0x4c8c3
0004c92a  8bac2410010000           mov ebp, dword ptr [rsp + 0x110]
0004c931  ff8388000000             inc dword ptr [rbx + 0x88]
0004c937  85ff                     test edi, edi
0004c939  743e                     je 0x4c979
0004c93b  448b4c2454               mov r9d, dword ptr [rsp + 0x54]
0004c940  448b5c2460               mov r11d, dword ptr [rsp + 0x60]
0004c945  e9def3ffff               jmp 0x4bd28
0004c94a  b803000000               mov eax, 3
0004c94f  eb2a                     jmp 0x4c97b
0004c951  b802000000               mov eax, 2
0004c956  eb23                     jmp 0x4c97b
0004c958  48638388000000           movsxd rax, dword ptr [rbx + 0x88]
0004c95f  85ff                     test edi, edi
0004c961  742c                     je 0x4c98f
0004c963  488bc8                   mov rcx, rax
0004c966  bafbff0000               mov edx, 0xfffb
0004c96b  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004c96f  66891488                 mov word ptr [rax + rcx*4], dx
0004c973  ff8388000000             inc dword ptr [rbx + 0x88]
0004c979  33c0                     xor eax, eax
0004c97b  4881c498000000           add rsp, 0x98
0004c982  415f                     pop r15
0004c984  415e                     pop r14
0004c986  415d                     pop r13
0004c988  415c                     pop r12
0004c98a  5f                       pop rdi
0004c98b  5e                       pop rsi
0004c98c  5d                       pop rbp
0004c98d  5b                       pop rbx
0004c98e  c3                       ret
0004c98f  398384000000             cmp dword ptr [rbx + 0x84], eax
0004c995  75e2                     jne 0x4c979
0004c997  f7431000000008           test dword ptr [rbx + 0x10], 0x8000000
0004c99e  742c                     je 0x4c9cc
0004c9a0  498b4c2408               mov rcx, qword ptr [r12 + 8]
0004c9a5  448b8180000000           mov r8d, dword ptr [rcx + 0x80]
0004c9ac  44234314                 and r8d, dword ptr [rbx + 0x14]
0004c9b0  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
0004c9b4  44890481                 mov dword ptr [rcx + rax*4], r8d
0004c9b8  85ed                     test ebp, ebp
0004c9ba  7410                     je 0x4c9cc
0004c9bc  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
0004c9c3  33c0                     xor eax, eax
0004c9c5  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
0004c9c9  890491                   mov dword ptr [rcx + rdx*4], eax
0004c9cc  418bc7                   mov eax, r15d
0004c9cf  ebaa                     jmp 0x4c97b
0004c9d1  0f1f00                   nop dword ptr [rax]
