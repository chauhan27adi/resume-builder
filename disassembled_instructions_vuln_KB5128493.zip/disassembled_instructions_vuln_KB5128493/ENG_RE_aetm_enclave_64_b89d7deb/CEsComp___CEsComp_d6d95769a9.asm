; CEsComp::~CEsComp
; aetm_enclave.dll, primary RVA 0x8830, 27 bytes in 1 chunk(s)

; chunk at RVA 0x8830 (27 bytes)
00008830  48894c2408               mov qword ptr [rsp + 8], rcx
00008835  4883ec38                 sub rsp, 0x38
00008839  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00008842  4883c438                 add rsp, 0x38
00008846  e915710100               jmp 0x1f960
