; `CAEEncryptionProvider::CAEEncryptionProvider'::`1'::dtor$1
; aetm_enclave.dll, primary RVA 0x612d0, 28 bytes in 1 chunk(s)

; chunk at RVA 0x612d0 (28 bytes)
000612d0  4055                     push rbp
000612d2  4883ec20                 sub rsp, 0x20
000612d6  488bea                   mov rbp, rdx
000612d9  488b5578                 mov rdx, qword ptr [rbp + 0x78]
000612dd  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
000612e1  e89a86fbff               call 0x19980
000612e6  4883c420                 add rsp, 0x20
000612ea  5d                       pop rbp
000612eb  c3                       ret
