; ex_raise
; aetm_enclave.dll, primary RVA 0x19440, 791 bytes in 1 chunk(s)

; chunk at RVA 0x19440 (791 bytes)
00019440  44894c2420               mov dword ptr [rsp + 0x20], r9d
00019445  55                       push rbp
00019446  53                       push rbx
00019447  56                       push rsi
00019448  57                       push rdi
00019449  4156                     push r14
0001944b  4157                     push r15
0001944d  488dac24b8f7ffff         lea rbp, [rsp - 0x848]
00019455  4881ec48090000           sub rsp, 0x948
0001945c  488b05a51b0900           mov rax, qword ptr [rip + 0x91ba5]
00019463  4833c4                   xor rax, rsp
00019466  48898530080000           mov qword ptr [rbp + 0x830], rax
0001946d  418bd8                   mov ebx, r8d
00019470  4c8dbda0080000           lea r15, [rbp + 0x8a0]
00019477  8bf2                     mov esi, edx
00019479  448bf1                   mov r14d, ecx
0001947c  33d2                     xor edx, edx
0001947e  488d8db0030000           lea rcx, [rbp + 0x3b0]
00019485  41b880040000             mov r8d, 0x480
0001948b  418bf9                   mov edi, r9d
0001948e  e8384e0400               call 0x5e2cb
00019493  488d8520040000           lea rax, [rbp + 0x420]
0001949a  4489b5b4030000           mov dword ptr [rbp + 0x3b4], r14d
000194a1  48898520080000           mov qword ptr [rbp + 0x820], rax
000194a8  418bce                   mov ecx, r14d
000194ab  89b5b8030000             mov dword ptr [rbp + 0x3b8], esi
000194b1  488d8520080000           lea rax, [rbp + 0x820]
000194b8  48898528080000           mov qword ptr [rbp + 0x828], rax
000194bf  899dbc030000             mov dword ptr [rbp + 0x3bc], ebx
000194c5  89bdc0030000             mov dword ptr [rbp + 0x3c0], edi
000194cb  c785b003000004000000     mov dword ptr [rbp + 0x3b0], 4
000194d5  81e94b010000             sub ecx, 0x14b
000194db  0f84d8000000             je 0x195b9
000194e1  83e904                   sub ecx, 4
000194e4  0f8483000000             je 0x1956d
000194ea  83f906                   cmp ecx, 6
000194ed  0f8554010000             jne 0x19647
000194f3  8bce                     mov ecx, esi
000194f5  83e901                   sub ecx, 1
000194f8  7450                     je 0x1954a
000194fa  83e901                   sub ecx, 1
000194fd  7409                     je 0x19508
000194ff  83f901                   cmp ecx, 1
00019502  0f853f010000             jne 0x19647
00019508  418b17                   mov edx, dword ptr [r15]
0001950b  488d8db0030000           lea rcx, [rbp + 0x3b0]
00019512  e84995feff               call 0x2a60
00019517  418b5708                 mov edx, dword ptr [r15 + 8]
0001951b  488d8db0030000           lea rcx, [rbp + 0x3b0]
00019522  e83995feff               call 0x2a60
00019527  488d95b0030000           lea rdx, [rbp + 0x3b0]
0001952e  488d4c2430               lea rcx, [rsp + 0x30]
00019533  e8a895feff               call 0x2ae0
00019538  488d15b9f60800           lea rdx, [rip + 0x8f6b9]
0001953f  488d4c2430               lea rcx, [rsp + 0x30]
00019544  e85f4b0400               call 0x5e0a8
00019549  cc                       int3
0001954a  488d95b0030000           lea rdx, [rbp + 0x3b0]
00019551  488d4c2430               lea rcx, [rsp + 0x30]
00019556  e88595feff               call 0x2ae0
0001955b  488d1596f60800           lea rdx, [rip + 0x8f696]
00019562  488d4c2430               lea rcx, [rsp + 0x30]
00019567  e83c4b0400               call 0x5e0a8
0001956c  cc                       int3
0001956d  8d46db                   lea eax, [rsi - 0x25]
00019570  83f834                   cmp eax, 0x34
00019573  0f87ce000000             ja 0x19647
00019579  488d15806afeff           lea rdx, [rip - 0x19580]
00019580  4898                     cdqe
00019582  0fb68402b4960100         movzx eax, byte ptr [rdx + rax + 0x196b4]
0001958a  8b8c82ac960100           mov ecx, dword ptr [rdx + rax*4 + 0x196ac]
00019591  4803ca                   add rcx, rdx
00019594  ffe1                     jmp rcx
00019596  488d95b0030000           lea rdx, [rbp + 0x3b0]
0001959d  488d4c2430               lea rcx, [rsp + 0x30]
000195a2  e83995feff               call 0x2ae0
000195a7  488d154af60800           lea rdx, [rip + 0x8f64a]
000195ae  488d4c2430               lea rcx, [rsp + 0x30]
000195b3  e8f04a0400               call 0x5e0a8
000195b8  cc                       int3
000195b9  8d46ff                   lea eax, [rsi - 1]
000195bc  83f85e                   cmp eax, 0x5e
000195bf  0f8782000000             ja 0x19647
000195c5  488d15346afeff           lea rdx, [rip - 0x195cc]
000195cc  4898                     cdqe
000195ce  0fb68402f8960100         movzx eax, byte ptr [rdx + rax + 0x196f8]
000195d6  8b8c82ec960100           mov ecx, dword ptr [rdx + rax*4 + 0x196ec]
000195dd  4803ca                   add rcx, rdx
000195e0  ffe1                     jmp rcx
000195e2  498b17                   mov rdx, qword ptr [r15]
000195e5  488d8db0030000           lea rcx, [rbp + 0x3b0]
000195ec  e81ffeffff               call 0x19410
000195f1  418b5708                 mov edx, dword ptr [r15 + 8]
000195f5  488d8db0030000           lea rcx, [rbp + 0x3b0]
000195fc  e85f94feff               call 0x2a60
00019601  488d95b0030000           lea rdx, [rbp + 0x3b0]
00019608  488d4c2430               lea rcx, [rsp + 0x30]
0001960d  e8ce94feff               call 0x2ae0
00019612  488d15dff50800           lea rdx, [rip + 0x8f5df]
00019619  488d4c2430               lea rcx, [rsp + 0x30]
0001961e  e8854a0400               call 0x5e0a8
00019623  cc                       int3
00019624  488d95b0030000           lea rdx, [rbp + 0x3b0]
0001962b  488d4c2430               lea rcx, [rsp + 0x30]
00019630  e8ab94feff               call 0x2ae0
00019635  488d15bcf50800           lea rdx, [rip + 0x8f5bc]
0001963c  488d4c2430               lea rcx, [rsp + 0x30]
00019641  e8624a0400               call 0x5e0a8
00019646  cc                       int3
00019647  41b910000000             mov r9d, 0x10
0001964d  c744242001000000         mov dword ptr [rsp + 0x20], 1
00019655  ba4b010000               mov edx, 0x14b
0001965a  488d8db0030000           lea rcx, [rbp + 0x3b0]
00019661  458d414c                 lea r8d, [r9 + 0x4c]
00019665  e846fdffff               call 0x193b0
0001966a  488d8db0030000           lea rcx, [rbp + 0x3b0]
00019671  418bd6                   mov edx, r14d
00019674  e8e793feff               call 0x2a60
00019679  8bd6                     mov edx, esi
0001967b  488d8db0030000           lea rcx, [rbp + 0x3b0]
00019682  e8d993feff               call 0x2a60
00019687  488d95b0030000           lea rdx, [rbp + 0x3b0]
0001968e  488d4c2430               lea rcx, [rsp + 0x30]
00019693  e84894feff               call 0x2ae0
00019698  488d1559f50800           lea rdx, [rip + 0x8f559]
0001969f  488d4c2430               lea rcx, [rsp + 0x30]
000196a4  e8ff490400               call 0x5e0a8
000196a9  cc                       int3
000196aa  6690                     nop
000196ac  96                       xchg esi, eax
000196ad  95                       xchg ebp, eax
000196ae  0100                     add dword ptr [rax], eax
000196b0  4796                     xchg r14d, eax
000196b2  0100                     add dword ptr [rax], eax
000196b4  0001                     add byte ptr [rcx], al
000196b6  0101                     add dword ptr [rcx], eax
000196b8  0101                     add dword ptr [rcx], eax
000196ba  0101                     add dword ptr [rcx], eax
000196bc  0100                     add dword ptr [rax], eax
000196be  0100                     add dword ptr [rax], eax
000196c0  0000                     add byte ptr [rax], al
000196c2  0001                     add byte ptr [rcx], al
000196c4  0101                     add dword ptr [rcx], eax
000196c6  0101                     add dword ptr [rcx], eax
000196c8  0101                     add dword ptr [rcx], eax
000196ca  0101                     add dword ptr [rcx], eax
000196cc  0101                     add dword ptr [rcx], eax
000196ce  0101                     add dword ptr [rcx], eax
000196d0  0101                     add dword ptr [rcx], eax
000196d2  0101                     add dword ptr [rcx], eax
000196d4  0101                     add dword ptr [rcx], eax
000196d6  0101                     add dword ptr [rcx], eax
000196d8  0101                     add dword ptr [rcx], eax
000196da  0101                     add dword ptr [rcx], eax
000196dc  0101                     add dword ptr [rcx], eax
000196de  0101                     add dword ptr [rcx], eax
000196e0  0101                     add dword ptr [rcx], eax
000196e2  0101                     add dword ptr [rcx], eax
000196e4  0101                     add dword ptr [rcx], eax
000196e6  0100                     add dword ptr [rax], eax
000196e8  000f                     add byte ptr [rdi], cl
