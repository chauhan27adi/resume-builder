; std::unique_ptr<CAEStreamEncryptionProvider,MemObjDeleter>::~unique_ptr<CAEStreamEncryptionProvider,MemObjDeleter>
; aetm_enclave.dll, primary RVA 0x17350, 106 bytes in 1 chunk(s)

; chunk at RVA 0x17350 (106 bytes)
00017350  4057                     push rdi
00017352  4883ec30                 sub rsp, 0x30
00017356  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0001735f  48895c2440               mov qword ptr [rsp + 0x40], rbx
00017364  488bf9                   mov rdi, rcx
00017367  488b5908                 mov rbx, qword ptr [rcx + 8]
0001736b  4885db                   test rbx, rbx
0001736e  743f                     je 0x173af
00017370  488d0531d60400           lea rax, [rip + 0x4d631]
00017377  488903                   mov qword ptr [rbx], rax
0001737a  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0001737e  4885c9                   test rcx, rcx
00017381  740b                     je 0x1738e
00017383  488b01                   mov rax, qword ptr [rcx]
00017386  ba01000000               mov edx, 1
0001738b  ff5010                   call qword ptr [rax + 0x10]
0001738e  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
00017392  4885c9                   test rcx, rcx
00017395  740b                     je 0x173a2
00017397  488b01                   mov rax, qword ptr [rcx]
0001739a  ba01000000               mov edx, 1
0001739f  ff5010                   call qword ptr [rax + 0x10]
000173a2  488b0f                   mov rcx, qword ptr [rdi]
000173a5  488b01                   mov rax, qword ptr [rcx]
000173a8  488bd3                   mov rdx, rbx
000173ab  ff5028                   call qword ptr [rax + 0x28]
000173ae  90                       nop
000173af  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
000173b4  4883c430                 add rsp, 0x30
000173b8  5f                       pop rdi
000173b9  c3                       ret
