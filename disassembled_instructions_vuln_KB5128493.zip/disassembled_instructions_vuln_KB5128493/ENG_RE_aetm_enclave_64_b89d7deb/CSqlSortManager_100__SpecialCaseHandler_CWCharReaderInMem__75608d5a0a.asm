; CSqlSortManager_100::SpecialCaseHandler<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x56d50, 1640 bytes in 1 chunk(s)

; chunk at RVA 0x56d50 (1640 bytes)
00056d50  48895c2418               mov qword ptr [rsp + 0x18], rbx
00056d55  55                       push rbp
00056d56  56                       push rsi
00056d57  57                       push rdi
00056d58  4154                     push r12
00056d5a  4155                     push r13
00056d5c  4156                     push r14
00056d5e  4157                     push r15
00056d60  4881ec80000000           sub rsp, 0x80
00056d67  488b8424f0000000         mov rax, qword ptr [rsp + 0xf0]
00056d6f  488bfa                   mov rdi, rdx
00056d72  488b9c24e8000000         mov rbx, qword ptr [rsp + 0xe8]
00056d7a  458be8                   mov r13d, r8d
00056d7d  4c8bb42418010000         mov r14, qword ptr [rsp + 0x118]
00056d85  4c8b9c24e0000000         mov r11, qword ptr [rsp + 0xe0]
00056d8d  4c8bbc2410010000         mov r15, qword ptr [rsp + 0x110]
00056d95  488bac2420010000         mov rbp, qword ptr [rsp + 0x120]
00056d9d  488bb42440010000         mov rsi, qword ptr [rsp + 0x140]
00056da5  4c8b942448010000         mov r10, qword ptr [rsp + 0x148]
00056dad  4c8ba42450010000         mov r12, qword ptr [rsp + 0x150]
00056db5  4c8b842458010000         mov r8, qword ptr [rsp + 0x158]
00056dbd  4889442468               mov qword ptr [rsp + 0x68], rax
00056dc2  488b842408010000         mov rax, qword ptr [rsp + 0x108]
00056dca  4889442458               mov qword ptr [rsp + 0x58], rax
00056dcf  8b842428010000           mov eax, dword ptr [rsp + 0x128]
00056dd6  48894c2450               mov qword ptr [rsp + 0x50], rcx
00056ddb  89442444                 mov dword ptr [rsp + 0x44], eax
00056ddf  498b01                   mov rax, qword ptr [r9]
00056de2  488bc8                   mov rcx, rax
00056de5  4889542448               mov qword ptr [rsp + 0x48], rdx
00056dea  48c1e928                 shr rcx, 0x28
00056dee  0fb6d1                   movzx edx, cl
00056df1  4c894c2460               mov qword ptr [rsp + 0x60], r9
00056df6  83fa06                   cmp edx, 6
00056df9  0f877d050000             ja 0x5737c
00056dff  8bca                     mov ecx, edx
00056e01  488d15f891faff           lea rdx, [rip - 0x56e08]
00056e08  8b948a9c730500           mov edx, dword ptr [rdx + rcx*4 + 0x5739c]
00056e0f  488d0dea91faff           lea rcx, [rip - 0x56e16]
00056e16  4803d1                   add rdx, rcx
00056e19  ffe2                     jmp rdx
00056e1b  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
00056e23  0f8553050000             jne 0x5737c
00056e29  488b8c2430010000         mov rcx, qword ptr [rsp + 0x130]
00056e31  4183e502                 and r13d, 2
00056e35  488b16                   mov rdx, qword ptr [rsi]
00056e38  4883c102                 add rcx, 2
00056e3c  483bd1                   cmp rdx, rcx
00056e3f  730d                     jae 0x56e4e
00056e41  807afe14                 cmp byte ptr [rdx - 2], 0x14
00056e45  7707                     ja 0x56e4e
00056e47  bf01000000               mov edi, 1
00056e4c  eb02                     jmp 0x56e50
00056e4e  33ff                     xor edi, edi
00056e50  4585ed                   test r13d, r13d
00056e53  7408                     je 0x56e5d
00056e55  85ff                     test edi, edi
00056e57  0f851f050000             jne 0x5737c
00056e5d  498b12                   mov rdx, qword ptr [r10]
00056e60  483b942438010000         cmp rdx, qword ptr [rsp + 0x138]
00056e68  761b                     jbe 0x56e85
00056e6a  0fb6c8                   movzx ecx, al
00056e6d  0fb642ff                 movzx eax, byte ptr [rdx - 1]
00056e71  03c8                     add ecx, eax
00056e73  b8ff000000               mov eax, 0xff
00056e78  3bc8                     cmp ecx, eax
00056e7a  0f47c8                   cmova ecx, eax
00056e7d  884aff                   mov byte ptr [rdx - 1], cl
00056e80  e9f7040000               jmp 0x5737c
00056e85  8802                     mov byte ptr [rdx], al
00056e87  49ff02                   inc qword ptr [r10]
00056e8a  e9ed040000               jmp 0x5737c
00056e8f  448b5b08                 mov r11d, dword ptr [rbx + 8]
00056e93  4c8d530e                 lea r10, [rbx + 0xe]
00056e97  488bc8                   mov rcx, rax
00056e9a  48c1e820                 shr rax, 0x20
00056e9e  48c1e908                 shr rcx, 8
00056ea2  0fb6d1                   movzx edx, cl
00056ea5  0fb6c8                   movzx ecx, al
00056ea8  48c1e208                 shl rdx, 8
00056eac  480bd1                   or rdx, rcx
00056eaf  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00056eb4  488b81a8000000           mov rax, qword ptr [rcx + 0xa8]
00056ebb  440fb70490               movzx r8d, word ptr [rax + rdx*4]
00056ec0  0fb7749002               movzx esi, word ptr [rax + rdx*4 + 2]
00056ec5  488d530c                 lea rdx, [rbx + 0xc]
00056ec9  488b03                   mov rax, qword ptr [rbx]
00056ecc  493bc2                   cmp rax, r10
00056ecf  741a                     je 0x56eeb
00056ed1  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
00056ed5  4883c002                 add rax, 2
00056ed9  488903                   mov qword ptr [rbx], rax
00056edc  66448902                 mov word ptr [rdx], r8w
00056ee0  66418932                 mov word ptr [r10], si
00056ee4  4885c9                   test rcx, rcx
00056ee7  7523                     jne 0x56f0c
00056ee9  eb1a                     jmp 0x56f05
00056eeb  488b4310                 mov rax, qword ptr [rbx + 0x10]
00056eef  33ff                     xor edi, edi
00056ef1  48897b10                 mov qword ptr [rbx + 0x10], rdi
00056ef5  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
00056efa  488903                   mov qword ptr [rbx], rax
00056efd  66448902                 mov word ptr [rdx], r8w
00056f01  66418932                 mov word ptr [r10], si
00056f05  488b03                   mov rax, qword ptr [rbx]
00056f08  48894310                 mov qword ptr [rbx + 0x10], rax
00056f0c  488913                   mov qword ptr [rbx], rdx
00056f0f  418d4301                 lea eax, [r11 + 1]
00056f13  894308                   mov dword ptr [rbx + 8], eax
00056f16  488b4708                 mov rax, qword ptr [rdi + 8]
00056f1a  428b1480                 mov edx, dword ptr [rax + r8*4]
00056f1e  0fb7c2                   movzx eax, dx
00056f21  48c1e020                 shl rax, 0x20
00056f25  48c1ea10                 shr rdx, 0x10
00056f29  480bc2                   or rax, rdx
00056f2c  498901                   mov qword ptr [r9], rax
00056f2f  b801000000               mov eax, 1
00056f34  e945040000               jmp 0x5737e
00056f39  33ff                     xor edi, edi
00056f3b  4c8d442470               lea r8, [rsp + 0x70]
00056f40  498bd3                   mov rdx, r11
00056f43  897c2470                 mov dword ptr [rsp + 0x70], edi
00056f47  498bc9                   mov rcx, r9
00056f4a  e8e1b1ffff               call 0x52130
00056f4f  39bc24f8000000           cmp dword ptr [rsp + 0xf8], edi
00056f56  0f8535030000             jne 0x57291
00056f5c  8b4c2470                 mov ecx, dword ptr [rsp + 0x70]
00056f60  85c9                     test ecx, ecx
00056f62  0f8429030000             je 0x57291
00056f68  498b0424                 mov rax, qword ptr [r12]
00056f6c  4c63442444               movsxd r8, dword ptr [rsp + 0x44]
00056f71  8808                     mov byte ptr [rax], cl
00056f73  498b0c24                 mov rcx, qword ptr [r12]
00056f77  0fb6442471               movzx eax, byte ptr [rsp + 0x71]
00056f7c  41880408                 mov byte ptr [r8 + rcx], al
00056f80  410fbae510               bt r13d, 0x10
00056f85  7213                     jb 0x56f9a
00056f87  498b0c24                 mov rcx, qword ptr [r12]
00056f8b  438d0400                 lea eax, [r8 + r8]
00056f8f  4863d0                   movsxd rdx, eax
00056f92  0fb6442472               movzx eax, byte ptr [rsp + 0x72]
00056f97  88040a                   mov byte ptr [rdx + rcx], al
00056f9a  410fbae511               bt r13d, 0x11
00056f9f  7213                     jb 0x56fb4
00056fa1  498b0c24                 mov rcx, qword ptr [r12]
00056fa5  438d0440                 lea eax, [r8 + r8*2]
00056fa9  4863d0                   movsxd rdx, eax
00056fac  0fb6442473               movzx eax, byte ptr [rsp + 0x73]
00056fb1  88040a                   mov byte ptr [rdx + rcx], al
00056fb4  49ff0424                 inc qword ptr [r12]
00056fb8  b801000000               mov eax, 1
00056fbd  e9bc030000               jmp 0x5737e
00056fc2  33ff                     xor edi, edi
00056fc4  b960110000               mov ecx, 0x1160
00056fc9  49893b                   mov qword ptr [r11], rdi
00056fcc  488b03                   mov rax, qword ptr [rbx]
00056fcf  663908                   cmp word ptr [rax], cx
00056fd2  0f83c8020000             jae 0x572a0
00056fd8  488b542448               mov rdx, qword ptr [rsp + 0x48]
00056fdd  488d442444               lea rax, [rsp + 0x44]
00056fe2  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00056fe7  4c8d4c2440               lea r9, [rsp + 0x40]
00056fec  4889442430               mov qword ptr [rsp + 0x30], rax
00056ff1  4c8bc3                   mov r8, rbx
00056ff4  488d442470               lea rax, [rsp + 0x70]
00056ff9  c744242803000000         mov dword ptr [rsp + 0x28], 3
00057001  4889442420               mov qword ptr [rsp + 0x20], rax
00057006  e805a8ffff               call 0x51810
0005700b  448be8                   mov r13d, eax
0005700e  85c0                     test eax, eax
00057010  0f8e85020000             jle 0x5729b
00057016  39bc24f8000000           cmp dword ptr [rsp + 0xf8], edi
0005701d  0f84d2010000             je 0x571f5
00057023  48634d00                 movsxd rcx, dword ptr [rbp]
00057027  41bc07020000             mov r12d, 0x207
0005702d  440fb7442440             movzx r8d, word ptr [rsp + 0x40]
00057033  8bb42400010000           mov esi, dword ptr [rsp + 0x100]
0005703a  410fb7d0                 movzx edx, r8w
0005703e  4c8b4c2458               mov r9, qword ptr [rsp + 0x58]
00057043  66c1ea08                 shr dx, 8
00057047  42881431                 mov byte ptr [rcx + r14], dl
0005704b  48634d00                 movsxd rcx, dword ptr [rbp]
0005704f  8d4101                   lea eax, [rcx + 1]
00057052  894500                   mov dword ptr [rbp], eax
00057055  4688443101               mov byte ptr [rcx + r14 + 1], r8b
0005705a  ff4500                   inc dword ptr [rbp]
0005705d  837d0004                 cmp dword ptr [rbp], 4
00057061  0f8599000000             jne 0x57100
00057067  897d00                   mov dword ptr [rbp], edi
0005706a  458b01                   mov r8d, dword ptr [r9]
0005706d  418b16                   mov edx, dword ptr [r14]
00057070  85f6                     test esi, esi
00057072  7537                     jne 0x570ab
00057074  41c1c003                 rol r8d, 3
00057078  418bc0                   mov eax, r8d
0005707b  33c2                     xor eax, edx
0005707d  418901                   mov dword ptr [r9], eax
00057080  6645396602               cmp word ptr [r14 + 2], r12w
00057085  7405                     je 0x5708c
00057087  418907                   mov dword ptr [r15], eax
0005708a  eb74                     jmp 0x57100
0005708c  410fb706                 movzx eax, word ptr [r14]
00057090  66413bc4                 cmp ax, r12w
00057094  746a                     je 0x57100
00057096  0fb6c8                   movzx ecx, al
00057099  4133c8                   xor ecx, r8d
0005709c  41890f                   mov dword ptr [r15], ecx
0005709f  410fb64601               movzx eax, byte ptr [r14 + 1]
000570a4  c1c103                   rol ecx, 3
000570a7  33c8                     xor ecx, eax
000570a9  eb52                     jmp 0x570fd
000570ab  4569d020080000           imul r10d, r8d, 0x820
000570b2  418bc0                   mov eax, r8d
000570b5  c1e802                   shr eax, 2
000570b8  4403d0                   add r10d, eax
000570bb  418d0412                 lea eax, [r10 + rdx]
000570bf  4133c0                   xor eax, r8d
000570c2  418901                   mov dword ptr [r9], eax
000570c5  6645396602               cmp word ptr [r14 + 2], r12w
000570ca  7405                     je 0x570d1
000570cc  418907                   mov dword ptr [r15], eax
000570cf  eb2f                     jmp 0x57100
000570d1  410fb706                 movzx eax, word ptr [r14]
000570d5  66413bc4                 cmp ax, r12w
000570d9  7425                     je 0x57100
000570db  0fb6d0                   movzx edx, al
000570de  4103d2                   add edx, r10d
000570e1  4133d0                   xor edx, r8d
000570e4  69c220080000             imul eax, edx, 0x820
000570ea  418917                   mov dword ptr [r15], edx
000570ed  410fb64e01               movzx ecx, byte ptr [r14 + 1]
000570f2  03c8                     add ecx, eax
000570f4  8bc2                     mov eax, edx
000570f6  c1e802                   shr eax, 2
000570f9  03c8                     add ecx, eax
000570fb  33ca                     xor ecx, edx
000570fd  41890f                   mov dword ptr [r15], ecx
00057100  4c8b5c2468               mov r11, qword ptr [rsp + 0x68]
00057105  b800ff0000               mov eax, 0xff00
0005710a  0fb6542470               movzx edx, byte ptr [rsp + 0x70]
0005710f  660bd0                   or dx, ax
00057112  0fb7ca                   movzx ecx, dx
00057115  6641ff03                 inc word ptr [r11]
00057119  48634500                 movsxd rax, dword ptr [rbp]
0005711d  66c1e908                 shr cx, 8
00057121  42880c30                 mov byte ptr [rax + r14], cl
00057125  48634d00                 movsxd rcx, dword ptr [rbp]
00057129  8d4101                   lea eax, [rcx + 1]
0005712c  894500                   mov dword ptr [rbp], eax
0005712f  4288543101               mov byte ptr [rcx + r14 + 1], dl
00057134  ff4500                   inc dword ptr [rbp]
00057137  837d0004                 cmp dword ptr [rbp], 4
0005713b  0f85ae000000             jne 0x571ef
00057141  897d00                   mov dword ptr [rbp], edi
00057144  458b01                   mov r8d, dword ptr [r9]
00057147  418b16                   mov edx, dword ptr [r14]
0005714a  85f6                     test esi, esi
0005714c  7548                     jne 0x57196
0005714e  41c1c003                 rol r8d, 3
00057152  418bc0                   mov eax, r8d
00057155  33c2                     xor eax, edx
00057157  418901                   mov dword ptr [r9], eax
0005715a  6645396602               cmp word ptr [r14 + 2], r12w
0005715f  740c                     je 0x5716d
00057161  418907                   mov dword ptr [r15], eax
00057164  6641ff03                 inc word ptr [r11]
00057168  e9ba000000               jmp 0x57227
0005716d  410fb706                 movzx eax, word ptr [r14]
00057171  66413bc4                 cmp ax, r12w
00057175  7478                     je 0x571ef
00057177  0fb6c8                   movzx ecx, al
0005717a  4133c8                   xor ecx, r8d
0005717d  41890f                   mov dword ptr [r15], ecx
00057180  410fb64601               movzx eax, byte ptr [r14 + 1]
00057185  c1c103                   rol ecx, 3
00057188  33c8                     xor ecx, eax
0005718a  41890f                   mov dword ptr [r15], ecx
0005718d  6641ff03                 inc word ptr [r11]
00057191  e991000000               jmp 0x57227
00057196  4569d020080000           imul r10d, r8d, 0x820
0005719d  418bc0                   mov eax, r8d
000571a0  c1e802                   shr eax, 2
000571a3  4403d0                   add r10d, eax
000571a6  418d0412                 lea eax, [r10 + rdx]
000571aa  4133c0                   xor eax, r8d
000571ad  418901                   mov dword ptr [r9], eax
000571b0  6645396602               cmp word ptr [r14 + 2], r12w
000571b5  7409                     je 0x571c0
000571b7  418907                   mov dword ptr [r15], eax
000571ba  6641ff03                 inc word ptr [r11]
000571be  eb67                     jmp 0x57227
000571c0  410fb706                 movzx eax, word ptr [r14]
000571c4  66413bc4                 cmp ax, r12w
000571c8  7425                     je 0x571ef
000571ca  0fb6d0                   movzx edx, al
000571cd  4103d2                   add edx, r10d
000571d0  4133d0                   xor edx, r8d
000571d3  69c220080000             imul eax, edx, 0x820
000571d9  418917                   mov dword ptr [r15], edx
000571dc  410fb64e01               movzx ecx, byte ptr [r14 + 1]
000571e1  03c8                     add ecx, eax
000571e3  8bc2                     mov eax, edx
000571e5  c1e802                   shr eax, 2
000571e8  03c8                     add ecx, eax
000571ea  33ca                     xor ecx, edx
000571ec  41890f                   mov dword ptr [r15], ecx
000571ef  6641ff03                 inc word ptr [r11]
000571f3  eb32                     jmp 0x57227
000571f5  488b06                   mov rax, qword ptr [rsi]
000571f8  0fb7542440               movzx edx, word ptr [rsp + 0x40]
000571fd  0fb7ca                   movzx ecx, dx
00057200  66c1e908                 shr cx, 8
00057204  8808                     mov byte ptr [rax], cl
00057206  48ff06                   inc qword ptr [rsi]
00057209  488b06                   mov rax, qword ptr [rsi]
0005720c  8810                     mov byte ptr [rax], dl
0005720e  48ff06                   inc qword ptr [rsi]
00057211  488b06                   mov rax, qword ptr [rsi]
00057214  c600ff                   mov byte ptr [rax], 0xff
00057217  48ff06                   inc qword ptr [rsi]
0005721a  488b0e                   mov rcx, qword ptr [rsi]
0005721d  0fb6442470               movzx eax, byte ptr [rsp + 0x70]
00057222  8801                     mov byte ptr [rcx], al
00057224  48ff06                   inc qword ptr [rsi]
00057227  0fb64c2471               movzx ecx, byte ptr [rsp + 0x71]
0005722c  0fb6442472               movzx eax, byte ptr [rsp + 0x72]
00057231  c1e110                   shl ecx, 0x10
00057234  480bc8                   or rcx, rax
00057237  48b8020200ff00ff0000     movabs rax, 0xff00ff000202
00057241  48c1e110                 shl rcx, 0x10
00057245  480bc8                   or rcx, rax
00057248  488b442460               mov rax, qword ptr [rsp + 0x60]
0005724d  488908                   mov qword ptr [rax], rcx
00057250  4183fd01                 cmp r13d, 1
00057254  7e3b                     jle 0x57291
00057256  488b0b                   mov rcx, qword ptr [rbx]
00057259  488d430e                 lea rax, [rbx + 0xe]
0005725d  8b5308                   mov edx, dword ptr [rbx + 8]
00057260  458d45ff                 lea r8d, [r13 - 1]
00057264  483bc8                   cmp rcx, rax
00057267  7417                     je 0x57280
00057269  4a8d0c41                 lea rcx, [rcx + r8*2]
0005726d  412bd0                   sub edx, r8d
00057270  48890b                   mov qword ptr [rbx], rcx
00057273  b801000000               mov eax, 1
00057278  895308                   mov dword ptr [rbx + 8], edx
0005727b  e9fe000000               jmp 0x5737e
00057280  488b4310                 mov rax, qword ptr [rbx + 0x10]
00057284  488903                   mov qword ptr [rbx], rax
00057287  8d42ff                   lea eax, [rdx - 1]
0005728a  894308                   mov dword ptr [rbx + 8], eax
0005728d  48897b10                 mov qword ptr [rbx + 0x10], rdi
00057291  b801000000               mov eax, 1
00057296  e9e3000000               jmp 0x5737e
0005729b  4c8b4c2460               mov r9, qword ptr [rsp + 0x60]
000572a0  498b09                   mov rcx, qword ptr [r9]
000572a3  488bc1                   mov rax, rcx
000572a6  48c1e820                 shr rax, 0x20
000572aa  0fb6d0                   movzx edx, al
000572ad  48b8ffffffffff00ffff     movabs rax, 0xffff00ffffffffff
000572b7  4823c8                   and rcx, rax
000572ba  48c1e228                 shl rdx, 0x28
000572be  480bd1                   or rdx, rcx
000572c1  48b902ffffff00ffffff     movabs rcx, 0xffffff00ffffff02
000572cb  0fb6c2                   movzx eax, dl
000572ce  4823d1                   and rdx, rcx
000572d1  48c1e020                 shl rax, 0x20
000572d5  480bc2                   or rax, rdx
000572d8  4883c802                 or rax, 2
000572dc  498901                   mov qword ptr [r9], rax
000572df  b801000000               mov eax, 1
000572e4  e995000000               jmp 0x5737e
000572e9  488bc8                   mov rcx, rax
000572ec  48c1e920                 shr rcx, 0x20
000572f0  0fb6d1                   movzx edx, cl
000572f3  48c1e208                 shl rdx, 8
000572f7  0fb6c8                   movzx ecx, al
000572fa  48b802020000fffd0000     movabs rax, 0xfdff00000202
00057304  480bd1                   or rdx, rcx
00057307  48c1e210                 shl rdx, 0x10
0005730b  480bd0                   or rdx, rax
0005730e  b801000000               mov eax, 1
00057313  498911                   mov qword ptr [r9], rdx
00057316  498913                   mov qword ptr [r11], rdx
00057319  eb63                     jmp 0x5737e
0005731b  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
00057323  7557                     jne 0x5737c
00057325  488b16                   mov rdx, qword ptr [rsi]
00057328  488b842430010000         mov rax, qword ptr [rsp + 0x130]
00057330  48c1e202                 shl rdx, 2
00057334  488d048500000000         lea rax, [rax*4]
0005733c  662bd0                   sub dx, ax
0005733f  b803800000               mov eax, 0x8003
00057344  660bd0                   or dx, ax
00057347  498b00                   mov rax, qword ptr [r8]
0005734a  0fb7ca                   movzx ecx, dx
0005734d  66c1e908                 shr cx, 8
00057351  8808                     mov byte ptr [rax], cl
00057353  49ff00                   inc qword ptr [r8]
00057356  498b00                   mov rax, qword ptr [r8]
00057359  8810                     mov byte ptr [rax], dl
0005735b  49ff00                   inc qword ptr [r8]
0005735e  498b08                   mov rcx, qword ptr [r8]
00057361  498b01                   mov rax, qword ptr [r9]
00057364  48c1e828                 shr rax, 0x28
00057368  8801                     mov byte ptr [rcx], al
0005736a  49ff00                   inc qword ptr [r8]
0005736d  498b01                   mov rax, qword ptr [r9]
00057370  498b08                   mov rcx, qword ptr [r8]
00057373  48c1e820                 shr rax, 0x20
00057377  8801                     mov byte ptr [rcx], al
00057379  49ff00                   inc qword ptr [r8]
0005737c  33c0                     xor eax, eax
0005737e  488b9c24d0000000         mov rbx, qword ptr [rsp + 0xd0]
00057386  4881c480000000           add rsp, 0x80
0005738d  415f                     pop r15
0005738f  415e                     pop r14
00057391  415d                     pop r13
00057393  415c                     pop r12
00057395  5f                       pop rdi
00057396  5e                       pop rsi
00057397  5d                       pop rbp
00057398  c3                       ret
00057399  0f1f00                   nop dword ptr [rax]
0005739c  7c73                     jl 0x57411
0005739e  05001b6e05               add eax, 0x56e1b00
000573a3  008f6e050039             add byte ptr [rdi + 0x3900056e], cl
000573a9  6f                       outsd dx, dword ptr [rsi]
000573aa  0500c26f05               add eax, 0x56fc200
000573af  00e9                     add cl, ch
000573b1  7205                     jb 0x573b8
000573b3  001b                     add byte ptr [rbx], bl
000573b5  7305                     jae 0x573bc
