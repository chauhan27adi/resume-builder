; CTrustedMachine::RemovePrimaryDBMapping
; aetm_enclave.dll, primary RVA 0xd820, 361 bytes in 1 chunk(s)

; chunk at RVA 0xd820 (361 bytes)
0000d820  48895c2410               mov qword ptr [rsp + 0x10], rbx
0000d825  48896c2418               mov qword ptr [rsp + 0x18], rbp
0000d82a  4889742420               mov qword ptr [rsp + 0x20], rsi
0000d82f  57                       push rdi
0000d830  4883ec20                 sub rsp, 0x20
0000d834  488db9d87a5800           lea rdi, [rcx + 0x587ad8]
0000d83b  90                       nop
0000d83c  0fb681e87a5800           movzx eax, byte ptr [rcx + 0x587ae8]
0000d843  4c8d89d8aa5800           lea r9, [rcx + 0x58aad8]
0000d84a  8bf2                     mov esi, edx
0000d84c  488bd9                   mov rbx, rcx
0000d84f  4c8bc7                   mov r8, rdi
0000d852  493bf9                   cmp rdi, r9
0000d855  7313                     jae 0xd86a
0000d857  84c0                     test al, al
0000d859  750f                     jne 0xd86a
0000d85b  4983c018                 add r8, 0x18
0000d85f  90                       nop
0000d860  410fb64010               movzx eax, byte ptr [r8 + 0x10]
0000d865  4d3bc1                   cmp r8, r9
0000d868  72ed                     jb 0xd857
0000d86a  48bdabaaaaaaaaaaaa2a     movabs rbp, 0x2aaaaaaaaaaaaaab
0000d874  90                       nop
0000d875  410fb64110               movzx eax, byte ptr [r9 + 0x10]
0000d87a  4d8bd0                   mov r10, r8
0000d87d  4d3bc1                   cmp r8, r9
0000d880  0f84ee000000             je 0xd974
0000d886  90                       nop
0000d887  498bc8                   mov rcx, r8
0000d88a  410fb64010               movzx eax, byte ptr [r8 + 0x10]
0000d88f  482bcf                   sub rcx, rdi
0000d892  488bc5                   mov rax, rbp
0000d895  90                       nop
0000d896  48f7e9                   imul rcx
0000d899  48c1fa02                 sar rdx, 2
0000d89d  488bc2                   mov rax, rdx
0000d8a0  48c1e83f                 shr rax, 0x3f
0000d8a4  4803d0                   add rdx, rax
0000d8a7  498b4008                 mov rax, qword ptr [r8 + 8]
0000d8ab  48c1e820                 shr rax, 0x20
0000d8af  4863ca                   movsxd rcx, edx
0000d8b2  48c1e120                 shl rcx, 0x20
0000d8b6  480bc8                   or rcx, rax
0000d8b9  48894c2430               mov qword ptr [rsp + 0x30], rcx
0000d8be  48c1e920                 shr rcx, 0x20
0000d8c2  0faee8                   lfence
0000d8c5  488bc1                   mov rax, rcx
0000d8c8  25ff010000               and eax, 0x1ff
0000d8cd  488d0440                 lea rax, [rax + rax*2]
0000d8d1  488d14c3                 lea rdx, [rbx + rax*8]
0000d8d5  f048ff82e07a5800         lock inc qword ptr [rdx + 0x587ae0]
0000d8dd  81e1ff010000             and ecx, 0x1ff
0000d8e3  90                       nop
0000d8e4  488d0449                 lea rax, [rcx + rcx*2]
0000d8e8  440fb65cc710             movzx r11d, byte ptr [rdi + rax*8 + 0x10]
0000d8ee  90                       nop
0000d8ef  488b44c708               mov rax, qword ptr [rdi + rax*8 + 8]
0000d8f4  488b4c2430               mov rcx, qword ptr [rsp + 0x30]
0000d8f9  48c1e820                 shr rax, 0x20
0000d8fd  3bc1                     cmp eax, ecx
0000d8ff  750b                     jne 0xd90c
0000d901  4584db                   test r11b, r11b
0000d904  7406                     je 0xd90c
0000d906  41397004                 cmp dword ptr [r8 + 4], esi
0000d90a  7441                     je 0xd94d
0000d90c  0faee8                   lfence
0000d90f  f048ff8ae07a5800         lock dec qword ptr [rdx + 0x587ae0]
0000d917  4983c018                 add r8, 0x18
0000d91b  4d3bd1                   cmp r10, r9
0000d91e  90                       nop
0000d91f  4d0f43c2                 cmovae r8, r10
0000d923  410fb64010               movzx eax, byte ptr [r8 + 0x10]
0000d928  4d3bc1                   cmp r8, r9
0000d92b  0f8343ffffff             jae 0xd874
0000d931  84c0                     test al, al
0000d933  0f853bffffff             jne 0xd874
0000d939  4983c018                 add r8, 0x18
0000d93d  90                       nop
0000d93e  410fb64010               movzx eax, byte ptr [r8 + 0x10]
0000d943  4d3bc1                   cmp r8, r9
0000d946  72e9                     jb 0xd931
0000d948  e927ffffff               jmp 0xd874
0000d94d  48c1e920                 shr rcx, 0x20
0000d951  0faee8                   lfence
0000d954  81e1ff010000             and ecx, 0x1ff
0000d95a  488d542430               lea rdx, [rsp + 0x30]
0000d95f  488d0449                 lea rax, [rcx + rcx*2]
0000d963  488bcf                   mov rcx, rdi
0000d966  f048ff8cc3e07a5800       lock dec qword ptr [rbx + rax*8 + 0x587ae0]
0000d96f  e82c280000               call 0x101a0
0000d974  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
0000d979  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
0000d97e  488b742448               mov rsi, qword ptr [rsp + 0x48]
0000d983  4883c420                 add rsp, 0x20
0000d987  5f                       pop rdi
0000d988  c3                       ret
