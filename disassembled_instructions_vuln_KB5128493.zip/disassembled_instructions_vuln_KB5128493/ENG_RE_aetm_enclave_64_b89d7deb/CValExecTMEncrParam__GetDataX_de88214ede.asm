; CValExecTMEncrParam::GetDataX
; aetm_enclave.dll, primary RVA 0x14c40, 3392 bytes in 7 chunk(s)

; chunk at RVA 0x14c40 (88 bytes)
00014c40  4056                     push rsi
00014c42  57                       push rdi
00014c43  4156                     push r14
00014c45  4881ec80000000           sub rsp, 0x80
00014c4c  488b05b5630900           mov rax, qword ptr [rip + 0x963b5]
00014c53  4833c4                   xor rax, rsp
00014c56  4889442450               mov qword ptr [rsp + 0x50], rax
00014c5b  4d8bf0                   mov r14, r8
00014c5e  488bf1                   mov rsi, rcx
00014c61  4c8b02                   mov r8, qword ptr [rdx]
00014c64  4d85c0                   test r8, r8
00014c67  0f8438090000             je 0x155a5
00014c6d  8b4908                   mov ecx, dword ptr [rcx + 8]
00014c70  ffc1                     inc ecx
00014c72  48c1e105                 shl rcx, 5
00014c76  4903c8                   add rcx, r8
00014c79  493bc8                   cmp rcx, r8
00014c7c  0f8223090000             jb 0x155a5
00014c82  483b0daf0d4600           cmp rcx, qword ptr [rip + 0x460daf]
00014c89  760d                     jbe 0x14c98
00014c8b  4c3b05260c4600           cmp r8, qword ptr [rip + 0x460c26]
00014c92  0f820d090000             jb 0x155a5

; chunk at RVA 0x14c98 (81 bytes)
00014c98  48899c24b8000000         mov qword ptr [rsp + 0xb8], rbx
00014ca0  48896c2478               mov qword ptr [rsp + 0x78], rbp
00014ca5  4c897c2460               mov qword ptr [rsp + 0x60], r15
00014caa  0faee8                   lfence
00014cad  448b7e08                 mov r15d, dword ptr [rsi + 8]
00014cb1  498d5e08                 lea rbx, [r14 + 8]
00014cb5  0fb64630                 movzx eax, byte ptr [rsi + 0x30]
00014cb9  33ff                     xor edi, edi
00014cbb  48893b                   mov qword ptr [rbx], rdi
00014cbe  48897b08                 mov qword ptr [rbx + 8], rdi
00014cc2  897b10                   mov dword ptr [rbx + 0x10], edi
00014cc5  49c1e705                 shl r15, 5
00014cc9  6641897e02               mov word ptr [r14 + 2], di
00014cce  41884601                 mov byte ptr [r14 + 1], al
00014cd2  41883e                   mov byte ptr [r14], dil
00014cd5  43803c0703               cmp byte ptr [r15 + r8], 3
00014cda  88442440                 mov byte ptr [rsp + 0x40], al
00014cde  7509                     jne 0x14ce9
00014ce0  41c60603                 mov byte ptr [r14], 3
00014ce4  e9b6010000               jmp 0x14e9f

; chunk at RVA 0x14ce9 (438 bytes)
00014ce9  4c89642470               mov qword ptr [rsp + 0x70], r12
00014cee  478b640710               mov r12d, dword ptr [r15 + r8 + 0x10]
00014cf3  4f8b7c0708               mov r15, qword ptr [r15 + r8 + 8]
00014cf8  4c896c2468               mov qword ptr [rsp + 0x68], r13
00014cfd  897c2448                 mov dword ptr [rsp + 0x48], edi
00014d01  4d85ff                   test r15, r15
00014d04  0f84b30b0000             je 0x158bd
00014d0a  4b8d0427                 lea rax, [r15 + r12]
00014d0e  493bc7                   cmp rax, r15
00014d11  0f82a60b0000             jb 0x158bd
00014d17  483b051a0d4600           cmp rax, qword ptr [rip + 0x460d1a]
00014d1e  760d                     jbe 0x14d2d
00014d20  4c3b3d910b4600           cmp r15, qword ptr [rip + 0x460b91]
00014d27  0f82900b0000             jb 0x158bd
00014d2d  0faee8                   lfence
00014d30  f605112e450001           test byte ptr [rip + 0x452e11], 1
00014d37  7549                     jne 0x14d82
00014d39  4183fc08                 cmp r12d, 8
00014d3d  0f8284080000             jb 0x155c7
00014d43  488b86f0000000           mov rax, qword ptr [rsi + 0xf0]
00014d4a  493907                   cmp qword ptr [r15], rax
00014d4d  7533                     jne 0x14d82
00014d4f  83bef800000002           cmp dword ptr [rsi + 0xf8], 2
00014d56  722a                     jb 0x14d82
00014d58  4439a61c010000           cmp dword ptr [rsi + 0x11c], r12d
00014d5f  7521                     jne 0x14d82
00014d61  488b8e10010000           mov rcx, qword ptr [rsi + 0x110]
00014d68  4d8bc4                   mov r8, r12
00014d6b  498bd7                   mov rdx, r15
00014d6e  e834950400               call 0x5e2a7
00014d73  85c0                     test eax, eax
00014d75  750b                     jne 0x14d82
00014d77  8bbe20010000             mov edi, dword ptr [rsi + 0x120]
00014d7d  e9e4000000               jmp 0x14e66
00014d82  4c8b8ee0000000           mov r9, qword ptr [rsi + 0xe0]
00014d89  488d442448               lea rax, [rsp + 0x48]
00014d8e  40887c2430               mov byte ptr [rsp + 0x30], dil
00014d93  488d4e50                 lea rcx, [rsi + 0x50]
00014d97  4889442428               mov qword ptr [rsp + 0x28], rax
00014d9c  458bc4                   mov r8d, r12d
00014d9f  8b86e8000000             mov eax, dword ptr [rsi + 0xe8]
00014da5  498bd7                   mov rdx, r15
00014da8  89442420                 mov dword ptr [rsp + 0x20], eax
00014dac  e89f540000               call 0x1a250
00014db1  f605902d450001           test byte ptr [rip + 0x452d90], 1
00014db8  0f85a4000000             jne 0x14e62
00014dbe  4183fc08                 cmp r12d, 8
00014dc2  0f8223080000             jb 0x155eb
00014dc8  498b07                   mov rax, qword ptr [r15]
00014dcb  483b86f0000000           cmp rax, qword ptr [rsi + 0xf0]
00014dd2  757d                     jne 0x14e51
00014dd4  8b8ef8000000             mov ecx, dword ptr [rsi + 0xf8]
00014dda  83f902                   cmp ecx, 2
00014ddd  7372                     jae 0x14e51
00014ddf  8d4101                   lea eax, [rcx + 1]
00014de2  8986f8000000             mov dword ptr [rsi + 0xf8], eax
00014de8  83f802                   cmp eax, 2
00014deb  7575                     jne 0x14e62
00014ded  448b8618010000           mov r8d, dword ptr [rsi + 0x118]
00014df4  488b8e10010000           mov rcx, qword ptr [rsi + 0x110]
00014dfb  4585e4                   test r12d, r12d
00014dfe  743e                     je 0x14e3e
00014e00  4885c9                   test rcx, rcx
00014e03  750e                     jne 0x14e13
00014e05  ff158de30400             call qword ptr [rip + 0x4e38d]
00014e0b  c70016000000             mov dword ptr [rax], 0x16
00014e11  eb25                     jmp 0x14e38
00014e13  4d3bc4                   cmp r8, r12
00014e16  720d                     jb 0x14e25
00014e18  4d8bc4                   mov r8, r12
00014e1b  498bd7                   mov rdx, r15
00014e1e  e890940400               call 0x5e2b3
00014e23  eb19                     jmp 0x14e3e
00014e25  33d2                     xor edx, edx
00014e27  e89f940400               call 0x5e2cb
00014e2c  ff1566e30400             call qword ptr [rip + 0x4e366]
00014e32  c70022000000             mov dword ptr [rax], 0x22
00014e38  ff1562e30400             call qword ptr [rip + 0x4e362]
00014e3e  8b7c2448                 mov edi, dword ptr [rsp + 0x48]
00014e42  89be20010000             mov dword ptr [rsi + 0x120], edi
00014e48  4489a61c010000           mov dword ptr [rsi + 0x11c], r12d
00014e4f  eb15                     jmp 0x14e66
00014e51  c786f800000001000000     mov dword ptr [rsi + 0xf8], 1
00014e5b  488986f0000000           mov qword ptr [rsi + 0xf0], rax
00014e62  8b7c2448                 mov edi, dword ptr [rsp + 0x48]
00014e66  0fb65630                 movzx edx, byte ptr [rsi + 0x30]
00014e6a  4c8d3d8fb1feff           lea r15, [rip - 0x14e71]
00014e71  460fb6843a405a0600       movzx r8d, byte ptr [rdx + r15 + 0x65a40]
00014e7a  4380bc38405b060001       cmp byte ptr [r8 + r15 + 0x65b40], 1
00014e83  7545                     jne 0x14eca
00014e85  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
00014e8c  488903                   mov qword ptr [rbx], rax
00014e8f  8bc7                     mov eax, edi
00014e91  49894610                 mov qword ptr [r14 + 0x10], rax
00014e95  4c8b6c2468               mov r13, qword ptr [rsp + 0x68]
00014e9a  4c8b642470               mov r12, qword ptr [rsp + 0x70]

; chunk at RVA 0x14e9f (43 bytes)
00014e9f  488b6c2478               mov rbp, qword ptr [rsp + 0x78]
00014ea4  488b9c24b8000000         mov rbx, qword ptr [rsp + 0xb8]
00014eac  4c8b7c2460               mov r15, qword ptr [rsp + 0x60]
00014eb1  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
00014eb6  4833cc                   xor rcx, rsp
00014eb9  e8b27f0400               call 0x5ce70
00014ebe  4881c480000000           add rsp, 0x80
00014ec5  415e                     pop r14
00014ec7  5f                       pop rdi
00014ec8  5e                       pop rsi
00014ec9  c3                       ret

; chunk at RVA 0x14eca (1755 bytes)
00014eca  0fb6442440               movzx eax, byte ptr [rsp + 0x40]
00014ecf  83c0dc                   add eax, -0x24
00014ed2  83f85b                   cmp eax, 0x5b
00014ed5  77be                     ja 0x14e95
00014ed7  4898                     cdqe
00014ed9  410fb6840724590100       movzx eax, byte ptr [r15 + rax + 0x15924]
00014ee2  418b8c87e0580100         mov ecx, dword ptr [r15 + rax*4 + 0x158e0]
00014eea  4903cf                   add rcx, r15
00014eed  ffe1                     jmp rcx
00014eef  488b056a0b4600           mov rax, qword ptr [rip + 0x460b6a]
00014ef6  83ff08                   cmp edi, 8
00014ef9  740d                     je 0x14f08
00014efb  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00014f02  0f8507070000             jne 0x1560f
00014f08  488bbee0000000           mov rdi, qword ptr [rsi + 0xe0]
00014f0f  4885ff                   test rdi, rdi
00014f12  0f8493010000             je 0x150ab
00014f18  488b3f                   mov rdi, qword ptr [rdi]
00014f1b  4881ffff000000           cmp rdi, 0xff
00014f22  0f8697010000             jbe 0x150bf
00014f28  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00014f2f  0f85f4060000             jne 0x15629
00014f35  e985010000               jmp 0x150bf
00014f3a  488b0d1f0b4600           mov rcx, qword ptr [rip + 0x460b1f]
00014f41  83ff08                   cmp edi, 8
00014f44  740d                     je 0x14f53
00014f46  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014f4d  0f85f0060000             jne 0x15643
00014f53  488bbee0000000           mov rdi, qword ptr [rsi + 0xe0]
00014f5a  4885ff                   test rdi, rdi
00014f5d  743d                     je 0x14f9c
00014f5f  488b3f                   mov rdi, qword ptr [rdi]
00014f62  4885ff                   test rdi, rdi
00014f65  791d                     jns 0x14f84
00014f67  488bc7                   mov rax, rdi
00014f6a  48f7d8                   neg rax
00014f6d  483d00800000             cmp rax, 0x8000
00014f73  7639                     jbe 0x14fae
00014f75  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014f7c  0f85db060000             jne 0x1565d
00014f82  eb2a                     jmp 0x14fae
00014f84  4881ff00800000           cmp rdi, 0x8000
00014f8b  7221                     jb 0x14fae
00014f8d  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014f94  0f85dd060000             jne 0x15677
00014f9a  eb12                     jmp 0x14fae
00014f9c  ff15f6e10400             call qword ptr [rip + 0x4e1f6]
00014fa2  c70016000000             mov dword ptr [rax], 0x16
00014fa8  ff15f2e10400             call qword ptr [rip + 0x4e1f2]
00014fae  66893b                   mov word ptr [rbx], di
00014fb1  e9dffeffff               jmp 0x14e95
00014fb6  488b0da30a4600           mov rcx, qword ptr [rip + 0x460aa3]
00014fbd  83ff08                   cmp edi, 8
00014fc0  740d                     je 0x14fcf
00014fc2  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014fc9  0f85c2060000             jne 0x15691
00014fcf  488bbee0000000           mov rdi, qword ptr [rsi + 0xe0]
00014fd6  4885ff                   test rdi, rdi
00014fd9  743b                     je 0x15016
00014fdb  488b3f                   mov rdi, qword ptr [rdi]
00014fde  ba00000080               mov edx, 0x80000000
00014fe3  4885ff                   test rdi, rdi
00014fe6  791a                     jns 0x15002
00014fe8  488bc7                   mov rax, rdi
00014feb  48f7d8                   neg rax
00014fee  483bc2                   cmp rax, rdx
00014ff1  7635                     jbe 0x15028
00014ff3  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
00014ffa  0f85ab060000             jne 0x156ab
00015000  eb26                     jmp 0x15028
00015002  483bfa                   cmp rdi, rdx
00015005  7221                     jb 0x15028
00015007  80b905b3580000           cmp byte ptr [rcx + 0x58b305], 0
0001500e  0f85b1060000             jne 0x156c5
00015014  eb12                     jmp 0x15028
00015016  ff157ce10400             call qword ptr [rip + 0x4e17c]
0001501c  c70016000000             mov dword ptr [rax], 0x16
00015022  ff1578e10400             call qword ptr [rip + 0x4e178]
00015028  893b                     mov dword ptr [rbx], edi
0001502a  e966feffff               jmp 0x14e95
0001502f  83ff08                   cmp edi, 8
00015032  7414                     je 0x15048
00015034  488b05250a4600           mov rax, qword ptr [rip + 0x460a25]
0001503b  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00015042  0f8595060000             jne 0x156dd
00015048  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
0001504f  4885c0                   test rax, rax
00015052  740b                     je 0x1505f
00015054  488b38                   mov rdi, qword ptr [rax]
00015057  48893b                   mov qword ptr [rbx], rdi
0001505a  e936feffff               jmp 0x14e95
0001505f  33ff                     xor edi, edi
00015061  ff1531e10400             call qword ptr [rip + 0x4e131]
00015067  c70016000000             mov dword ptr [rax], 0x16
0001506d  ff152de10400             call qword ptr [rip + 0x4e12d]
00015073  48893b                   mov qword ptr [rbx], rdi
00015076  e91afeffff               jmp 0x14e95
0001507b  83ff08                   cmp edi, 8
0001507e  7414                     je 0x15094
00015080  488b05d9094600           mov rax, qword ptr [rip + 0x4609d9]
00015087  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001508e  0f8561060000             jne 0x156f5
00015094  488bbee0000000           mov rdi, qword ptr [rsi + 0xe0]
0001509b  4885ff                   test rdi, rdi
0001509e  740b                     je 0x150ab
000150a0  488b3f                   mov rdi, qword ptr [rdi]
000150a3  40883b                   mov byte ptr [rbx], dil
000150a6  e9eafdffff               jmp 0x14e95
000150ab  33ff                     xor edi, edi
000150ad  ff15e5e00400             call qword ptr [rip + 0x4e0e5]
000150b3  c70016000000             mov dword ptr [rax], 0x16
000150b9  ff15e1e00400             call qword ptr [rip + 0x4e0e1]
000150bf  40883b                   mov byte ptr [rbx], dil
000150c2  e9cefdffff               jmp 0x14e95
000150c7  83ff04                   cmp edi, 4
000150ca  7414                     je 0x150e0
000150cc  488b058d094600           mov rax, qword ptr [rip + 0x46098d]
000150d3  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000150da  0f852d060000             jne 0x1570d
000150e0  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
000150e7  4885c0                   test rax, rax
000150ea  7415                     je 0x15101
000150ec  8b00                     mov eax, dword ptr [rax]
000150ee  89442448                 mov dword ptr [rsp + 0x48], eax
000150f2  f30f10442448             movss xmm0, dword ptr [rsp + 0x48]
000150f8  f30f1103                 movss dword ptr [rbx], xmm0
000150fc  e994fdffff               jmp 0x14e95
00015101  89442448                 mov dword ptr [rsp + 0x48], eax
00015105  ff158de00400             call qword ptr [rip + 0x4e08d]
0001510b  c70016000000             mov dword ptr [rax], 0x16
00015111  ff1589e00400             call qword ptr [rip + 0x4e089]
00015117  f30f10442448             movss xmm0, dword ptr [rsp + 0x48]
0001511d  f30f1103                 movss dword ptr [rbx], xmm0
00015121  e96ffdffff               jmp 0x14e95
00015126  83ff08                   cmp edi, 8
00015129  7414                     je 0x1513f
0001512b  488b052e094600           mov rax, qword ptr [rip + 0x46092e]
00015132  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00015139  0f85e6050000             jne 0x15725
0001513f  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
00015146  4885c0                   test rax, rax
00015149  7417                     je 0x15162
0001514b  488b00                   mov rax, qword ptr [rax]
0001514e  4889442448               mov qword ptr [rsp + 0x48], rax
00015153  f20f10442448             movsd xmm0, qword ptr [rsp + 0x48]
00015159  f20f1103                 movsd qword ptr [rbx], xmm0
0001515d  e933fdffff               jmp 0x14e95
00015162  4889442448               mov qword ptr [rsp + 0x48], rax
00015167  ff152be00400             call qword ptr [rip + 0x4e02b]
0001516d  c70016000000             mov dword ptr [rax], 0x16
00015173  ff1527e00400             call qword ptr [rip + 0x4e027]
00015179  f20f10442448             movsd xmm0, qword ptr [rsp + 0x48]
0001517f  f20f1103                 movsd qword ptr [rbx], xmm0
00015183  e90dfdffff               jmp 0x14e95
00015188  83ff08                   cmp edi, 8
0001518b  0f845f030000             je 0x154f0
00015191  488b05c8084600           mov rax, qword ptr [rip + 0x4608c8]
00015198  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001519f  0f8598050000             jne 0x1573d
000151a5  e946030000               jmp 0x154f0
000151aa  83ff08                   cmp edi, 8
000151ad  7414                     je 0x151c3
000151af  488b05aa084600           mov rax, qword ptr [rip + 0x4608aa]
000151b6  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000151bd  0f8592050000             jne 0x15755
000151c3  488b8ee0000000           mov rcx, qword ptr [rsi + 0xe0]
000151ca  4c8d4630                 lea r8, [rsi + 0x30]
000151ce  4c8bcb                   mov r9, rbx
000151d1  897c2420                 mov dword ptr [rsp + 0x20], edi
000151d5  8bd7                     mov edx, edi
000151d7  e814240000               call 0x175f0
000151dc  488d4e30                 lea rcx, [rsi + 0x30]
000151e0  448bc0                   mov r8d, eax
000151e3  e8f8eeffff               call 0x140e0
000151e8  488b1571084600           mov rdx, qword ptr [rip + 0x460871]
000151ef  3c07                     cmp al, 7
000151f1  760d                     jbe 0x15200
000151f3  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
000151fa  0f856d050000             jne 0x1576d
00015200  0fb6c8                   movzx ecx, al
00015203  410fb6c0                 movzx eax, r8b
00015207  664139848fc8410600       cmp word ptr [r15 + rcx*4 + 0x641c8], ax
00015210  0f8463020000             je 0x15479
00015216  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
0001521d  0f8562050000             jne 0x15785
00015223  e951020000               jmp 0x15479
00015228  488d4e30                 lea rcx, [rsi + 0x30]
0001522c  e82f2cffff               call 0x7e60
00015231  440fb7c0                 movzx r8d, ax
00015235  413bf8                   cmp edi, r8d
00015238  7414                     je 0x1524e
0001523a  488b051f084600           mov rax, qword ptr [rip + 0x46081f]
00015241  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00015248  0f854f050000             jne 0x1579d
0001524e  4c8bbee0000000           mov r15, qword ptr [rsi + 0xe0]
00015255  498bf0                   mov rsi, r8
00015258  8bef                     mov ebp, edi
0001525a  85ff                     test edi, edi
0001525c  7467                     je 0x152c5
0001525e  4885db                   test rbx, rbx
00015261  751b                     jne 0x1527e
00015263  ff152fdf0400             call qword ptr [rip + 0x4df2f]
00015269  c70016000000             mov dword ptr [rax], 0x16
0001526f  ff152bdf0400             call qword ptr [rip + 0x4df2b]
00015275  41887e1b                 mov byte ptr [r14 + 0x1b], dil
00015279  e917fcffff               jmp 0x14e95
0001527e  4d85ff                   test r15, r15
00015281  741c                     je 0x1529f
00015283  483bf5                   cmp rsi, rbp
00015286  7217                     jb 0x1529f
00015288  4c8bc5                   mov r8, rbp
0001528b  498bd7                   mov rdx, r15
0001528e  488bcb                   mov rcx, rbx
00015291  e81d900400               call 0x5e2b3
00015296  41887e1b                 mov byte ptr [r14 + 0x1b], dil
0001529a  e9f6fbffff               jmp 0x14e95
0001529f  33d2                     xor edx, edx
000152a1  488bcb                   mov rcx, rbx
000152a4  e822900400               call 0x5e2cb
000152a9  4d85ff                   test r15, r15
000152ac  74b5                     je 0x15263
000152ae  483bf5                   cmp rsi, rbp
000152b1  7312                     jae 0x152c5
000152b3  ff15dfde0400             call qword ptr [rip + 0x4dedf]
000152b9  c70022000000             mov dword ptr [rax], 0x22
000152bf  ff15dbde0400             call qword ptr [rip + 0x4dedb]
000152c5  41887e1b                 mov byte ptr [r14 + 0x1b], dil
000152c9  e9c7fbffff               jmp 0x14e95
000152ce  488d4e30                 lea rcx, [rsi + 0x30]
000152d2  e8892bffff               call 0x7e60
000152d7  440fb7c0                 movzx r8d, ax
000152db  488b057e074600           mov rax, qword ptr [rip + 0x46077e]
000152e2  413bf8                   cmp edi, r8d
000152e5  740d                     je 0x152f4
000152e7  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000152ee  0f85c1040000             jne 0x157b5
000152f4  83ff04                   cmp edi, 4
000152f7  740d                     je 0x15306
000152f9  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00015300  0f85c7040000             jne 0x157cd
00015306  488b8ee0000000           mov rcx, qword ptr [rsi + 0xe0]
0001530d  8bc7                     mov eax, edi
0001530f  85ff                     test edi, edi
00015311  746a                     je 0x1537d
00015313  4885db                   test rbx, rbx
00015316  751e                     jne 0x15336
00015318  ff157ade0400             call qword ptr [rip + 0x4de7a]
0001531e  c70016000000             mov dword ptr [rax], 0x16
00015324  ff1576de0400             call qword ptr [rip + 0x4de76]
0001532a  8b03                     mov eax, dword ptr [rbx]
0001532c  c1c010                   rol eax, 0x10
0001532f  8903                     mov dword ptr [rbx], eax
00015331  e95ffbffff               jmp 0x14e95
00015336  4885c9                   test rcx, rcx
00015339  7420                     je 0x1535b
0001533b  4883f808                 cmp rax, 8
0001533f  771a                     ja 0x1535b
00015341  488bd1                   mov rdx, rcx
00015344  4c8bc0                   mov r8, rax
00015347  488bcb                   mov rcx, rbx
0001534a  e8648f0400               call 0x5e2b3
0001534f  8b03                     mov eax, dword ptr [rbx]
00015351  c1c010                   rol eax, 0x10
00015354  8903                     mov dword ptr [rbx], eax
00015356  e93afbffff               jmp 0x14e95
0001535b  33d2                     xor edx, edx
0001535d  488913                   mov qword ptr [rbx], rdx
00015360  4885c9                   test rcx, rcx
00015363  74b3                     je 0x15318
00015365  4883f808                 cmp rax, 8
00015369  7612                     jbe 0x1537d
0001536b  ff1527de0400             call qword ptr [rip + 0x4de27]
00015371  c70022000000             mov dword ptr [rax], 0x22
00015377  ff1523de0400             call qword ptr [rip + 0x4de23]
0001537d  8b03                     mov eax, dword ptr [rbx]
0001537f  c1c010                   rol eax, 0x10
00015382  8903                     mov dword ptr [rbx], eax
00015384  e90cfbffff               jmp 0x14e95
00015389  83ff05                   cmp edi, 5
0001538c  7414                     je 0x153a2
0001538e  488b05cb064600           mov rax, qword ptr [rip + 0x4606cb]
00015395  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001539c  0f8543040000             jne 0x157e5
000153a2  488b8ee0000000           mov rcx, qword ptr [rsi + 0xe0]
000153a9  4c8d4630                 lea r8, [rsi + 0x30]
000153ad  4c8bcb                   mov r9, rbx
000153b0  897c2420                 mov dword ptr [rsp + 0x20], edi
000153b4  8bd7                     mov edx, edi
000153b6  e835220000               call 0x175f0
000153bb  488d4e30                 lea rcx, [rsi + 0x30]
000153bf  448bc0                   mov r8d, eax
000153c2  e819edffff               call 0x140e0
000153c7  488b1592064600           mov rdx, qword ptr [rip + 0x460692]
000153ce  3c07                     cmp al, 7
000153d0  760d                     jbe 0x153df
000153d2  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
000153d9  0f851e040000             jne 0x157fd
000153df  0fb6c8                   movzx ecx, al
000153e2  410fb6c0                 movzx eax, r8b
000153e6  664139848f40420600       cmp word ptr [r15 + rcx*4 + 0x64240], ax
000153ef  0f8484000000             je 0x15479
000153f5  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
000153fc  0f8513040000             jne 0x15815
00015402  eb75                     jmp 0x15479
00015404  83ff0a                   cmp edi, 0xa
00015407  7414                     je 0x1541d
00015409  488b0550064600           mov rax, qword ptr [rip + 0x460650]
00015410  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00015417  0f8510040000             jne 0x1582d
0001541d  488b8ee0000000           mov rcx, qword ptr [rsi + 0xe0]
00015424  4c8d4630                 lea r8, [rsi + 0x30]
00015428  4c8bcb                   mov r9, rbx
0001542b  897c2420                 mov dword ptr [rsp + 0x20], edi
0001542f  8bd7                     mov edx, edi
00015431  e8ba210000               call 0x175f0
00015436  488d4e30                 lea rcx, [rsi + 0x30]
0001543a  448bc0                   mov r8d, eax
0001543d  e89eecffff               call 0x140e0
00015442  488b1517064600           mov rdx, qword ptr [rip + 0x460617]
00015449  3c07                     cmp al, 7
0001544b  760d                     jbe 0x1545a
0001544d  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
00015454  0f85eb030000             jne 0x15845
0001545a  0fb6c8                   movzx ecx, al
0001545d  410fb6c0                 movzx eax, r8b
00015461  664139848fb0420600       cmp word ptr [r15 + rcx*4 + 0x642b0], ax
0001546a  740d                     je 0x15479
0001546c  80ba05b3580000           cmp byte ptr [rdx + 0x58b305], 0
00015473  0f85e4030000             jne 0x1585d
00015479  4588461b                 mov byte ptr [r14 + 0x1b], r8b
0001547d  e913faffff               jmp 0x14e95
00015482  83ff11                   cmp edi, 0x11
00015485  7414                     je 0x1549b
00015487  488b05d2054600           mov rax, qword ptr [rip + 0x4605d2]
0001548e  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
00015495  0f85da030000             jne 0x15875
0001549b  80c210                   add dl, 0x10
0001549e  80fa01                   cmp dl, 1
000154a1  7607                     jbe 0x154aa
000154a3  440fb64e42               movzx r9d, byte ptr [rsi + 0x42]
000154a8  eb09                     jmp 0x154b3
000154aa  470fb68c87725b0600       movzx r9d, byte ptr [r15 + r8*4 + 0x65b72]
000154b3  488d4e30                 lea rcx, [rsi + 0x30]
000154b7  e824ecffff               call 0x140e0
000154bc  488b96e0000000           mov rdx, qword ptr [rsi + 0xe0]
000154c3  488bcb                   mov rcx, rbx
000154c6  448bc7                   mov r8d, edi
000154c9  88442420                 mov byte ptr [rsp + 0x20], al
000154cd  e89eebffff               call 0x14070
000154d2  e9bef9ffff               jmp 0x14e95
000154d7  83ff08                   cmp edi, 8
000154da  7414                     je 0x154f0
000154dc  488b057d054600           mov rax, qword ptr [rip + 0x46057d]
000154e3  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
000154ea  0f859d030000             jne 0x1588d
000154f0  488b86e0000000           mov rax, qword ptr [rsi + 0xe0]
000154f7  4885db                   test rbx, rbx
000154fa  741d                     je 0x15519
000154fc  4885c0                   test rax, rax
000154ff  7415                     je 0x15516
00015501  488b00                   mov rax, qword ptr [rax]
00015504  488903                   mov qword ptr [rbx], rax
00015507  8bc8                     mov ecx, eax
00015509  8b4304                   mov eax, dword ptr [rbx + 4]
0001550c  8903                     mov dword ptr [rbx], eax
0001550e  894b04                   mov dword ptr [rbx + 4], ecx
00015511  e97ff9ffff               jmp 0x14e95
00015516  488903                   mov qword ptr [rbx], rax
00015519  ff1579dc0400             call qword ptr [rip + 0x4dc79]
0001551f  c70016000000             mov dword ptr [rax], 0x16
00015525  ff1575dc0400             call qword ptr [rip + 0x4dc75]
0001552b  8b0b                     mov ecx, dword ptr [rbx]
0001552d  8b4304                   mov eax, dword ptr [rbx + 4]
00015530  8903                     mov dword ptr [rbx], eax
00015532  894b04                   mov dword ptr [rbx + 4], ecx
00015535  e95bf9ffff               jmp 0x14e95
0001553a  488d4e30                 lea rcx, [rsi + 0x30]
0001553e  e81d29ffff               call 0x7e60
00015543  440fb7c0                 movzx r8d, ax
00015547  413bf8                   cmp edi, r8d
0001554a  7414                     je 0x15560
0001554c  488b050d054600           mov rax, qword ptr [rip + 0x46050d]
00015553  80b805b3580000           cmp byte ptr [rax + 0x58b305], 0
0001555a  0f8545030000             jne 0x158a5
00015560  488b96e0000000           mov rdx, qword ptr [rsi + 0xe0]
00015567  448bc7                   mov r8d, edi
0001556a  85ff                     test edi, edi
0001556c  0f8423f9ffff             je 0x14e95
00015572  4885db                   test rbx, rbx
00015575  7417                     je 0x1558e
00015577  488bcb                   mov rcx, rbx
0001557a  4885d2                   test rdx, rdx
0001557d  740a                     je 0x15589
0001557f  e82f8d0400               call 0x5e2b3
00015584  e90cf9ffff               jmp 0x14e95
00015589  e83d8d0400               call 0x5e2cb
0001558e  ff1504dc0400             call qword ptr [rip + 0x4dc04]
00015594  c70016000000             mov dword ptr [rax], 0x16
0001559a  ff1500dc0400             call qword ptr [rip + 0x4dc00]
000155a0  e9f0f8ffff               jmp 0x14e95

; chunk at RVA 0x155a5 (34 bytes)
000155a5  33ff                     xor edi, edi
000155a7  4c8d0572970800           lea r8, [rip + 0x89772]
000155ae  488d155b960800           lea rdx, [rip + 0x8965b]
000155b5  48897c2420               mov qword ptr [rsp + 0x20], rdi
000155ba  448d4f68                 lea r9d, [rdi + 0x68]
000155be  8d4f01                   lea ecx, [rdi + 1]
000155c1  e85a3e0000               call 0x19420
000155c6  cc                       int3

; chunk at RVA 0x155c7 (953 bytes)
000155c7  41b91e010000             mov r9d, 0x11e
000155cd  48897c2420               mov qword ptr [rsp + 0x20], rdi
000155d2  4c8d0547970800           lea r8, [rip + 0x89747]
000155d9  b901000000               mov ecx, 1
000155de  488d15f3a10800           lea rdx, [rip + 0x8a1f3]
000155e5  e8363e0000               call 0x19420
000155ea  cc                       int3
000155eb  41b91e010000             mov r9d, 0x11e
000155f1  48897c2420               mov qword ptr [rsp + 0x20], rdi
000155f6  4c8d0523970800           lea r8, [rip + 0x89723]
000155fd  b901000000               mov ecx, 1
00015602  488d15cfa10800           lea rdx, [rip + 0x8a1cf]
00015609  e8123e0000               call 0x19420
0001560e  cc                       int3
0001560f  ba32000000               mov edx, 0x32
00015614  b94f010000               mov ecx, 0x14f
00015619  41b9c8000000             mov r9d, 0xc8
0001561f  448d42de                 lea r8d, [rdx - 0x22]
00015623  e8183e0000               call 0x19440
00015628  cc                       int3
00015629  ba32000000               mov edx, 0x32
0001562e  b94f010000               mov ecx, 0x14f
00015633  41b9c9000000             mov r9d, 0xc9
00015639  448d42de                 lea r8d, [rdx - 0x22]
0001563d  e8fe3d0000               call 0x19440
00015642  cc                       int3
00015643  ba32000000               mov edx, 0x32
00015648  b94f010000               mov ecx, 0x14f
0001564d  41b9ca000000             mov r9d, 0xca
00015653  448d42de                 lea r8d, [rdx - 0x22]
00015657  e8e43d0000               call 0x19440
0001565c  cc                       int3
0001565d  ba32000000               mov edx, 0x32
00015662  b94f010000               mov ecx, 0x14f
00015667  41b9cb000000             mov r9d, 0xcb
0001566d  448d42de                 lea r8d, [rdx - 0x22]
00015671  e8ca3d0000               call 0x19440
00015676  cc                       int3
00015677  ba32000000               mov edx, 0x32
0001567c  b94f010000               mov ecx, 0x14f
00015681  41b9cc000000             mov r9d, 0xcc
00015687  448d42de                 lea r8d, [rdx - 0x22]
0001568b  e8b03d0000               call 0x19440
00015690  cc                       int3
00015691  ba32000000               mov edx, 0x32
00015696  b94f010000               mov ecx, 0x14f
0001569b  41b9cd000000             mov r9d, 0xcd
000156a1  448d42de                 lea r8d, [rdx - 0x22]
000156a5  e8963d0000               call 0x19440
000156aa  cc                       int3
000156ab  ba32000000               mov edx, 0x32
000156b0  b94f010000               mov ecx, 0x14f
000156b5  41b9ce000000             mov r9d, 0xce
000156bb  448d42de                 lea r8d, [rdx - 0x22]
000156bf  e87c3d0000               call 0x19440
000156c4  cc                       int3
000156c5  ba32000000               mov edx, 0x32
000156ca  b94f010000               mov ecx, 0x14f
000156cf  448d4980                 lea r9d, [rcx - 0x80]
000156d3  448d42de                 lea r8d, [rdx - 0x22]
000156d7  e8643d0000               call 0x19440
000156dc  cc                       int3
000156dd  ba32000000               mov edx, 0x32
000156e2  b94f010000               mov ecx, 0x14f
000156e7  448d4981                 lea r9d, [rcx - 0x7f]
000156eb  448d42de                 lea r8d, [rdx - 0x22]
000156ef  e84c3d0000               call 0x19440
000156f4  cc                       int3
000156f5  ba32000000               mov edx, 0x32
000156fa  b94f010000               mov ecx, 0x14f
000156ff  448d4982                 lea r9d, [rcx - 0x7e]
00015703  448d42de                 lea r8d, [rdx - 0x22]
00015707  e8343d0000               call 0x19440
0001570c  cc                       int3
0001570d  ba32000000               mov edx, 0x32
00015712  b94f010000               mov ecx, 0x14f
00015717  448d4983                 lea r9d, [rcx - 0x7d]
0001571b  448d42de                 lea r8d, [rdx - 0x22]
0001571f  e81c3d0000               call 0x19440
00015724  cc                       int3
00015725  ba32000000               mov edx, 0x32
0001572a  b94f010000               mov ecx, 0x14f
0001572f  448d4984                 lea r9d, [rcx - 0x7c]
00015733  448d42de                 lea r8d, [rdx - 0x22]
00015737  e8043d0000               call 0x19440
0001573c  cc                       int3
0001573d  ba32000000               mov edx, 0x32
00015742  b94f010000               mov ecx, 0x14f
00015747  448d4985                 lea r9d, [rcx - 0x7b]
0001574b  448d42de                 lea r8d, [rdx - 0x22]
0001574f  e8ec3c0000               call 0x19440
00015754  cc                       int3
00015755  ba32000000               mov edx, 0x32
0001575a  b94f010000               mov ecx, 0x14f
0001575f  448d4986                 lea r9d, [rcx - 0x7a]
00015763  448d42de                 lea r8d, [rdx - 0x22]
00015767  e8d43c0000               call 0x19440
0001576c  cc                       int3
0001576d  ba32000000               mov edx, 0x32
00015772  b94f010000               mov ecx, 0x14f
00015777  448d4987                 lea r9d, [rcx - 0x79]
0001577b  448d42de                 lea r8d, [rdx - 0x22]
0001577f  e8bc3c0000               call 0x19440
00015784  cc                       int3
00015785  ba32000000               mov edx, 0x32
0001578a  b94f010000               mov ecx, 0x14f
0001578f  448d4988                 lea r9d, [rcx - 0x78]
00015793  448d42de                 lea r8d, [rdx - 0x22]
00015797  e8a43c0000               call 0x19440
0001579c  cc                       int3
0001579d  ba32000000               mov edx, 0x32
000157a2  b94f010000               mov ecx, 0x14f
000157a7  448d4989                 lea r9d, [rcx - 0x77]
000157ab  448d42de                 lea r8d, [rdx - 0x22]
000157af  e88c3c0000               call 0x19440
000157b4  cc                       int3
000157b5  ba32000000               mov edx, 0x32
000157ba  b94f010000               mov ecx, 0x14f
000157bf  448d498a                 lea r9d, [rcx - 0x76]
000157c3  448d42de                 lea r8d, [rdx - 0x22]
000157c7  e8743c0000               call 0x19440
000157cc  cc                       int3
000157cd  ba32000000               mov edx, 0x32
000157d2  b94f010000               mov ecx, 0x14f
000157d7  448d498b                 lea r9d, [rcx - 0x75]
000157db  448d42de                 lea r8d, [rdx - 0x22]
000157df  e85c3c0000               call 0x19440
000157e4  cc                       int3
000157e5  ba32000000               mov edx, 0x32
000157ea  b94f010000               mov ecx, 0x14f
000157ef  448d498c                 lea r9d, [rcx - 0x74]
000157f3  448d42de                 lea r8d, [rdx - 0x22]
000157f7  e8443c0000               call 0x19440
000157fc  cc                       int3
000157fd  ba32000000               mov edx, 0x32
00015802  b94f010000               mov ecx, 0x14f
00015807  448d498d                 lea r9d, [rcx - 0x73]
0001580b  448d42de                 lea r8d, [rdx - 0x22]
0001580f  e82c3c0000               call 0x19440
00015814  cc                       int3
00015815  ba32000000               mov edx, 0x32
0001581a  b94f010000               mov ecx, 0x14f
0001581f  448d498e                 lea r9d, [rcx - 0x72]
00015823  448d42de                 lea r8d, [rdx - 0x22]
00015827  e8143c0000               call 0x19440
0001582c  cc                       int3
0001582d  ba32000000               mov edx, 0x32
00015832  b94f010000               mov ecx, 0x14f
00015837  448d498f                 lea r9d, [rcx - 0x71]
0001583b  448d42de                 lea r8d, [rdx - 0x22]
0001583f  e8fc3b0000               call 0x19440
00015844  cc                       int3
00015845  ba32000000               mov edx, 0x32
0001584a  b94f010000               mov ecx, 0x14f
0001584f  448d4990                 lea r9d, [rcx - 0x70]
00015853  448d42de                 lea r8d, [rdx - 0x22]
00015857  e8e43b0000               call 0x19440
0001585c  cc                       int3
0001585d  ba32000000               mov edx, 0x32
00015862  b94f010000               mov ecx, 0x14f
00015867  448d4991                 lea r9d, [rcx - 0x6f]
0001586b  448d42de                 lea r8d, [rdx - 0x22]
0001586f  e8cc3b0000               call 0x19440
00015874  cc                       int3
00015875  ba32000000               mov edx, 0x32
0001587a  b94f010000               mov ecx, 0x14f
0001587f  448d4992                 lea r9d, [rcx - 0x6e]
00015883  448d42de                 lea r8d, [rdx - 0x22]
00015887  e8b43b0000               call 0x19440
0001588c  cc                       int3
0001588d  ba32000000               mov edx, 0x32
00015892  b94f010000               mov ecx, 0x14f
00015897  448d4993                 lea r9d, [rcx - 0x6d]
0001589b  448d42de                 lea r8d, [rdx - 0x22]
0001589f  e89c3b0000               call 0x19440
000158a4  cc                       int3
000158a5  ba32000000               mov edx, 0x32
000158aa  b94f010000               mov ecx, 0x14f
000158af  448d4994                 lea r9d, [rcx - 0x6c]
000158b3  448d42de                 lea r8d, [rdx - 0x22]
000158b7  e8843b0000               call 0x19440
000158bc  cc                       int3
000158bd  41b968000000             mov r9d, 0x68
000158c3  48897c2420               mov qword ptr [rsp + 0x20], rdi
000158c8  4c8d05f9930800           lea r8, [rip + 0x893f9]
000158cf  488d153a930800           lea rdx, [rip + 0x8933a]
000158d6  418d4999                 lea ecx, [r9 - 0x67]
000158da  e8413b0000               call 0x19420
000158df  cc                       int3
000158e0  3a5501                   cmp dl, byte ptr [rbp + 1]
000158e3  0028                     add byte ptr [rax], ch
000158e5  52                       push rdx
000158e6  0100                     add dword ptr [rax], eax
000158e8  895301                   mov dword ptr [rbx + 1], edx
000158eb  00aa51010004             add byte ptr [rdx + 0x4000151], ch
000158f1  54                       push rsp
000158f2  0100                     add dword ptr [rax], eax
000158f4  ef                       out dx, eax
000158f5  4e0100                   add qword ptr [rax], r8
000158f8  3a4f01                   cmp cl, byte ptr [rdi + 1]
000158fb  00b64f0100ce             add byte ptr [rsi - 0x31fffeb1], dh
00015901  52                       push rdx
00015902  0100                     add dword ptr [rax], eax
