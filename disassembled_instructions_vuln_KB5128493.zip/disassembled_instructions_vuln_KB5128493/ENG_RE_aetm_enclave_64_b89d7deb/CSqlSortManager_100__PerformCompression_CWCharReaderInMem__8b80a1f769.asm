; CSqlSortManager_100::PerformCompression<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x55ed0, 1480 bytes in 1 chunk(s)

; chunk at RVA 0x55ed0 (1480 bytes)
00055ed0  48895c2410               mov qword ptr [rsp + 0x10], rbx
00055ed5  48896c2418               mov qword ptr [rsp + 0x18], rbp
00055eda  4889742420               mov qword ptr [rsp + 0x20], rsi
00055edf  48894c2408               mov qword ptr [rsp + 8], rcx
00055ee4  57                       push rdi
00055ee5  4156                     push r14
00055ee7  4157                     push r15
00055ee9  4883ec20                 sub rsp, 0x20
00055eed  8b7208                   mov esi, dword ptr [rdx + 8]
00055ef0  4d8bf9                   mov r15, r9
00055ef3  4c8b32                   mov r14, qword ptr [rdx]
00055ef6  498bd8                   mov rbx, r8
00055ef9  4d8bd6                   mov r10, r14
00055efc  488bfa                   mov rdi, rdx
00055eff  448bde                   mov r11d, esi
00055f02  83fe02                   cmp esi, 2
00055f05  0f8279040000             jb 0x56384
00055f0b  33ed                     xor ebp, ebp
00055f0d  41396818                 cmp dword ptr [r8 + 0x18], ebp
00055f11  742e                     je 0x55f41
00055f13  83fe03                   cmp esi, 3
00055f16  7229                     jb 0x55f41
00055f18  4d8b4008                 mov r8, qword ptr [r8 + 8]
00055f1c  410fb70e                 movzx ecx, word ptr [r14]
00055f20  410fb74602               movzx eax, word ptr [r14 + 2]
00055f25  418b1488                 mov edx, dword ptr [r8 + rcx*4]
00055f29  41331480                 xor edx, dword ptr [r8 + rax*4]
00055f2d  f7c2ffffffe7             test edx, 0xe7ffffff
00055f33  750c                     jne 0x55f41
00055f35  bd01000000               mov ebp, 1
00055f3a  4d8d5602                 lea r10, [r14 + 2]
00055f3e  41ffcb                   dec r11d
00055f41  418b01                   mov eax, dword ptr [r9]
00055f44  33d2                     xor edx, edx
00055f46  488b5b30                 mov rbx, qword ptr [rbx + 0x30]
00055f4a  48c1e808                 shr rax, 8
00055f4e  0fb6c8                   movzx ecx, al
00055f51  48c1e906                 shr rcx, 6
00055f55  c744244000080203         mov dword ptr [rsp + 0x40], 0x3020800
00055f5d  0fb6440c40               movzx eax, byte ptr [rsp + rcx + 0x40]
00055f62  413bc3                   cmp eax, r11d
00055f65  440f46d8                 cmovbe r11d, eax
00055f69  4183c3fe                 add r11d, -2
00055f6d  4183fb06                 cmp r11d, 6
00055f71  0f870d040000             ja 0x56384
00055f77  4c8d0582a0faff           lea r8, [rip - 0x55f7e]
00055f7e  438b8c987c640500         mov ecx, dword ptr [r8 + r11*4 + 0x5647c]
00055f86  4903c8                   add rcx, r8
00055f89  ffe1                     jmp rcx
00055f8b  4c8b5b30                 mov r11, qword ptr [rbx + 0x30]
00055f8f  4d85db                   test r11, r11
00055f92  743d                     je 0x55fd1
00055f94  498bd2                   mov rdx, r10
00055f97  e814b4feff               call 0x413b0
00055f9c  33d2                     xor edx, edx
00055f9e  41f77308                 div dword ptr [r11 + 8]
00055fa2  8bca                     mov ecx, edx
00055fa4  48c1e105                 shl rcx, 5
00055fa8  49030b                   add rcx, qword ptr [r11]
00055fab  7422                     je 0x55fcf
00055fad  0f1f00                   nop dword ptr [rax]
00055fb0  488b410c                 mov rax, qword ptr [rcx + 0xc]
00055fb4  493b02                   cmp rax, qword ptr [r10]
00055fb7  750e                     jne 0x55fc7
00055fb9  488b4114                 mov rax, qword ptr [rcx + 0x14]
00055fbd  493b4208                 cmp rax, qword ptr [r10 + 8]
00055fc1  0f84d8030000             je 0x5639f
00055fc7  488b09                   mov rcx, qword ptr [rcx]
00055fca  4885c9                   test rcx, rcx
00055fcd  75e1                     jne 0x55fb0
00055fcf  33d2                     xor edx, edx
00055fd1  4c8b4b28                 mov r9, qword ptr [rbx + 0x28]
00055fd5  4d85c9                   test r9, r9
00055fd8  0f84dd000000             je 0x560bb
00055fde  450fb702                 movzx r8d, word ptr [r10]
00055fe2  410fb7520a               movzx edx, word ptr [r10 + 0xa]
00055fe7  418bc0                   mov eax, r8d
00055fea  c1e802                   shr eax, 2
00055fed  4169c820080000           imul ecx, r8d, 0x820
00055ff4  03c8                     add ecx, eax
00055ff6  410fb74202               movzx eax, word ptr [r10 + 2]
00055ffb  03c8                     add ecx, eax
00055ffd  4433c1                   xor r8d, ecx
00056000  410fb74a04               movzx ecx, word ptr [r10 + 4]
00056005  4169c020080000           imul eax, r8d, 0x820
0005600c  03c8                     add ecx, eax
0005600e  418bc0                   mov eax, r8d
00056011  c1e802                   shr eax, 2
00056014  03c8                     add ecx, eax
00056016  4433c1                   xor r8d, ecx
00056019  410fb74a06               movzx ecx, word ptr [r10 + 6]
0005601e  4169c020080000           imul eax, r8d, 0x820
00056025  03c8                     add ecx, eax
00056027  418bc0                   mov eax, r8d
0005602a  c1e802                   shr eax, 2
0005602d  03c8                     add ecx, eax
0005602f  4433c1                   xor r8d, ecx
00056032  410fb74a08               movzx ecx, word ptr [r10 + 8]
00056037  4169c020080000           imul eax, r8d, 0x820
0005603e  03c8                     add ecx, eax
00056040  418bc0                   mov eax, r8d
00056043  c1e802                   shr eax, 2
00056046  03c8                     add ecx, eax
00056048  4433c1                   xor r8d, ecx
0005604b  4169c020080000           imul eax, r8d, 0x820
00056052  418bc8                   mov ecx, r8d
00056055  c1e902                   shr ecx, 2
00056058  03d0                     add edx, eax
0005605a  03d1                     add edx, ecx
0005605c  4433c2                   xor r8d, edx
0005605f  410fb7520c               movzx edx, word ptr [r10 + 0xc]
00056064  4169c020080000           imul eax, r8d, 0x820
0005606b  418bc8                   mov ecx, r8d
0005606e  c1e902                   shr ecx, 2
00056071  03c2                     add eax, edx
00056073  33d2                     xor edx, edx
00056075  03c1                     add eax, ecx
00056077  4133c0                   xor eax, r8d
0005607a  41f77108                 div dword ptr [r9 + 8]
0005607e  8bca                     mov ecx, edx
00056080  48c1e105                 shl rcx, 5
00056084  490309                   add rcx, qword ptr [r9]
00056087  7430                     je 0x560b9
00056089  0f1f8000000000           nop dword ptr [rax]
00056090  488b410c                 mov rax, qword ptr [rcx + 0xc]
00056094  493b02                   cmp rax, qword ptr [r10]
00056097  7518                     jne 0x560b1
00056099  8b4114                   mov eax, dword ptr [rcx + 0x14]
0005609c  413b4208                 cmp eax, dword ptr [r10 + 8]
000560a0  750f                     jne 0x560b1
000560a2  0fb74118                 movzx eax, word ptr [rcx + 0x18]
000560a6  66413b420c               cmp ax, word ptr [r10 + 0xc]
000560ab  0f8400030000             je 0x563b1
000560b1  488b09                   mov rcx, qword ptr [rcx]
000560b4  4885c9                   test rcx, rcx
000560b7  75d7                     jne 0x56090
000560b9  33d2                     xor edx, edx
000560bb  4c8b4b20                 mov r9, qword ptr [rbx + 0x20]
000560bf  4d85c9                   test r9, r9
000560c2  0f84b8000000             je 0x56180
000560c8  450fb702                 movzx r8d, word ptr [r10]
000560cc  410fb75208               movzx edx, word ptr [r10 + 8]
000560d1  418bc0                   mov eax, r8d
000560d4  c1e802                   shr eax, 2
000560d7  4169c820080000           imul ecx, r8d, 0x820
000560de  03c8                     add ecx, eax
000560e0  410fb74202               movzx eax, word ptr [r10 + 2]
000560e5  03c8                     add ecx, eax
000560e7  4433c1                   xor r8d, ecx
000560ea  410fb74a04               movzx ecx, word ptr [r10 + 4]
000560ef  4169c020080000           imul eax, r8d, 0x820
000560f6  03c8                     add ecx, eax
000560f8  418bc0                   mov eax, r8d
000560fb  c1e802                   shr eax, 2
000560fe  03c8                     add ecx, eax
00056100  4433c1                   xor r8d, ecx
00056103  410fb74a06               movzx ecx, word ptr [r10 + 6]
00056108  4169c020080000           imul eax, r8d, 0x820
0005610f  03c8                     add ecx, eax
00056111  418bc0                   mov eax, r8d
00056114  c1e802                   shr eax, 2
00056117  03c8                     add ecx, eax
00056119  4433c1                   xor r8d, ecx
0005611c  4169c020080000           imul eax, r8d, 0x820
00056123  418bc8                   mov ecx, r8d
00056126  c1e902                   shr ecx, 2
00056129  03d0                     add edx, eax
0005612b  03d1                     add edx, ecx
0005612d  4433c2                   xor r8d, edx
00056130  410fb7520a               movzx edx, word ptr [r10 + 0xa]
00056135  4169c020080000           imul eax, r8d, 0x820
0005613c  418bc8                   mov ecx, r8d
0005613f  c1e902                   shr ecx, 2
00056142  03c2                     add eax, edx
00056144  33d2                     xor edx, edx
00056146  03c1                     add eax, ecx
00056148  4133c0                   xor eax, r8d
0005614b  41f77108                 div dword ptr [r9 + 8]
0005614f  498b01                   mov rax, qword ptr [r9]
00056152  488d1452                 lea rdx, [rdx + rdx*2]
00056156  488d0cd0                 lea rcx, [rax + rdx*8]
0005615a  4885c9                   test rcx, rcx
0005615d  741f                     je 0x5617e
0005615f  90                       nop
00056160  488b410c                 mov rax, qword ptr [rcx + 0xc]
00056164  493b02                   cmp rax, qword ptr [r10]
00056167  750d                     jne 0x56176
00056169  8b4114                   mov eax, dword ptr [rcx + 0x14]
0005616c  413b4208                 cmp eax, dword ptr [r10 + 8]
00056170  0f844d020000             je 0x563c3
00056176  488b09                   mov rcx, qword ptr [rcx]
00056179  4885c9                   test rcx, rcx
0005617c  75e2                     jne 0x56160
0005617e  33d2                     xor edx, edx
00056180  4c8b4b18                 mov r9, qword ptr [rbx + 0x18]
00056184  4d85c9                   test r9, r9
00056187  0f84a5000000             je 0x56232
0005618d  450fb702                 movzx r8d, word ptr [r10]
00056191  410fb74a02               movzx ecx, word ptr [r10 + 2]
00056196  410fb75206               movzx edx, word ptr [r10 + 6]
0005619b  4169c020080000           imul eax, r8d, 0x820
000561a2  03c8                     add ecx, eax
000561a4  418bc0                   mov eax, r8d
000561a7  c1e802                   shr eax, 2
000561aa  03c8                     add ecx, eax
000561ac  4433c1                   xor r8d, ecx
000561af  410fb74a04               movzx ecx, word ptr [r10 + 4]
000561b4  4169c020080000           imul eax, r8d, 0x820
000561bb  03c8                     add ecx, eax
000561bd  418bc0                   mov eax, r8d
000561c0  c1e802                   shr eax, 2
000561c3  03c8                     add ecx, eax
000561c5  4433c1                   xor r8d, ecx
000561c8  4169c020080000           imul eax, r8d, 0x820
000561cf  418bc8                   mov ecx, r8d
000561d2  c1e902                   shr ecx, 2
000561d5  03d0                     add edx, eax
000561d7  03d1                     add edx, ecx
000561d9  4433c2                   xor r8d, edx
000561dc  410fb75208               movzx edx, word ptr [r10 + 8]
000561e1  4169c020080000           imul eax, r8d, 0x820
000561e8  418bc8                   mov ecx, r8d
000561eb  c1e902                   shr ecx, 2
000561ee  03c2                     add eax, edx
000561f0  33d2                     xor edx, edx
000561f2  03c1                     add eax, ecx
000561f4  4133c0                   xor eax, r8d
000561f7  41f77108                 div dword ptr [r9 + 8]
000561fb  498b01                   mov rax, qword ptr [r9]
000561fe  488d1452                 lea rdx, [rdx + rdx*2]
00056202  488d0cd0                 lea rcx, [rax + rdx*8]
00056206  4885c9                   test rcx, rcx
00056209  7425                     je 0x56230
0005620b  0f1f440000               nop dword ptr [rax + rax]
00056210  488b410c                 mov rax, qword ptr [rcx + 0xc]
00056214  493b02                   cmp rax, qword ptr [r10]
00056217  750f                     jne 0x56228
00056219  0fb74114                 movzx eax, word ptr [rcx + 0x14]
0005621d  66413b4208               cmp ax, word ptr [r10 + 8]
00056222  0f84ad010000             je 0x563d5
00056228  488b09                   mov rcx, qword ptr [rcx]
0005622b  4885c9                   test rcx, rcx
0005622e  75e0                     jne 0x56210
00056230  33d2                     xor edx, edx
00056232  4c8b4b10                 mov r9, qword ptr [rbx + 0x10]
00056236  4d85c9                   test r9, r9
00056239  747c                     je 0x562b7
0005623b  450fb702                 movzx r8d, word ptr [r10]
0005623f  410fb75204               movzx edx, word ptr [r10 + 4]
00056244  418bc0                   mov eax, r8d
00056247  c1e802                   shr eax, 2
0005624a  4169c820080000           imul ecx, r8d, 0x820
00056251  03c8                     add ecx, eax
00056253  410fb74202               movzx eax, word ptr [r10 + 2]
00056258  03c8                     add ecx, eax
0005625a  4433c1                   xor r8d, ecx
0005625d  4169c020080000           imul eax, r8d, 0x820
00056264  418bc8                   mov ecx, r8d
00056267  c1e902                   shr ecx, 2
0005626a  03d0                     add edx, eax
0005626c  03d1                     add edx, ecx
0005626e  4433c2                   xor r8d, edx
00056271  410fb75206               movzx edx, word ptr [r10 + 6]
00056276  4169c020080000           imul eax, r8d, 0x820
0005627d  418bc8                   mov ecx, r8d
00056280  c1e902                   shr ecx, 2
00056283  03c2                     add eax, edx
00056285  33d2                     xor edx, edx
00056287  03c1                     add eax, ecx
00056289  4133c0                   xor eax, r8d
0005628c  41f77108                 div dword ptr [r9 + 8]
00056290  498b01                   mov rax, qword ptr [r9]
00056293  488d1452                 lea rdx, [rdx + rdx*2]
00056297  488d0cd0                 lea rcx, [rax + rdx*8]
0005629b  4885c9                   test rcx, rcx
0005629e  7415                     je 0x562b5
000562a0  488b410c                 mov rax, qword ptr [rcx + 0xc]
000562a4  493b02                   cmp rax, qword ptr [r10]
000562a7  0f843a010000             je 0x563e7
000562ad  488b09                   mov rcx, qword ptr [rcx]
000562b0  4885c9                   test rcx, rcx
000562b3  75eb                     jne 0x562a0
000562b5  33d2                     xor edx, edx
000562b7  4c8b4b08                 mov r9, qword ptr [rbx + 8]
000562bb  4d85c9                   test r9, r9
000562be  7471                     je 0x56331
000562c0  450fb702                 movzx r8d, word ptr [r10]
000562c4  4169d020080000           imul edx, r8d, 0x820
000562cb  418bc8                   mov ecx, r8d
000562ce  c1e902                   shr ecx, 2
000562d1  03d1                     add edx, ecx
000562d3  410fb74a02               movzx ecx, word ptr [r10 + 2]
000562d8  03d1                     add edx, ecx
000562da  4433c2                   xor r8d, edx
000562dd  410fb75204               movzx edx, word ptr [r10 + 4]
000562e2  4169c020080000           imul eax, r8d, 0x820
000562e9  418bc8                   mov ecx, r8d
000562ec  c1e902                   shr ecx, 2
000562ef  03c2                     add eax, edx
000562f1  33d2                     xor edx, edx
000562f3  03c1                     add eax, ecx
000562f5  4133c0                   xor eax, r8d
000562f8  41f77108                 div dword ptr [r9 + 8]
000562fc  498b01                   mov rax, qword ptr [r9]
000562ff  488d1452                 lea rdx, [rdx + rdx*2]
00056303  488d0cd0                 lea rcx, [rax + rdx*8]
00056307  4885c9                   test rcx, rcx
0005630a  7423                     je 0x5632f
0005630c  0f1f4000                 nop dword ptr [rax]
00056310  8b410c                   mov eax, dword ptr [rcx + 0xc]
00056313  413b02                   cmp eax, dword ptr [r10]
00056316  750f                     jne 0x56327
00056318  0fb74110                 movzx eax, word ptr [rcx + 0x10]
0005631c  66413b4204               cmp ax, word ptr [r10 + 4]
00056321  0f84d2000000             je 0x563f9
00056327  488b09                   mov rcx, qword ptr [rcx]
0005632a  4885c9                   test rcx, rcx
0005632d  75e1                     jne 0x56310
0005632f  33d2                     xor edx, edx
00056331  4c8b0b                   mov r9, qword ptr [rbx]
00056334  4d85c9                   test r9, r9
00056337  0f84e0000000             je 0x5641d
0005633d  450fb702                 movzx r8d, word ptr [r10]
00056341  410fb75202               movzx edx, word ptr [r10 + 2]
00056346  418bc8                   mov ecx, r8d
00056349  c1e902                   shr ecx, 2
0005634c  4169c020080000           imul eax, r8d, 0x820
00056353  03c2                     add eax, edx
00056355  33d2                     xor edx, edx
00056357  03c1                     add eax, ecx
00056359  4133c0                   xor eax, r8d
0005635c  41f77108                 div dword ptr [r9 + 8]
00056360  8bca                     mov ecx, edx
00056362  48c1e104                 shl rcx, 4
00056366  490309                   add rcx, qword ptr [r9]
00056369  7419                     je 0x56384
0005636b  0f1f440000               nop dword ptr [rax + rax]
00056370  8b410c                   mov eax, dword ptr [rcx + 0xc]
00056373  413b02                   cmp eax, dword ptr [r10]
00056376  0f848f000000             je 0x5640b
0005637c  488b09                   mov rcx, qword ptr [rcx]
0005637f  4885c9                   test rcx, rcx
00056382  75ec                     jne 0x56370
00056384  33c0                     xor eax, eax
00056386  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0005638b  488b6c2450               mov rbp, qword ptr [rsp + 0x50]
00056390  488b742458               mov rsi, qword ptr [rsp + 0x58]
00056395  4883c420                 add rsp, 0x20
00056399  415f                     pop r15
0005639b  415e                     pop r14
0005639d  5f                       pop rdi
0005639e  c3                       ret
0005639f  8b5108                   mov edx, dword ptr [rcx + 8]
000563a2  85d2                     test edx, edx
000563a4  0f8427fcffff             je 0x55fd1
000563aa  b808000000               mov eax, 8
000563af  eb78                     jmp 0x56429
000563b1  8b5108                   mov edx, dword ptr [rcx + 8]
000563b4  85d2                     test edx, edx
000563b6  0f84fffcffff             je 0x560bb
000563bc  b807000000               mov eax, 7
000563c1  eb66                     jmp 0x56429
000563c3  8b5108                   mov edx, dword ptr [rcx + 8]
000563c6  85d2                     test edx, edx
000563c8  0f84b2fdffff             je 0x56180
000563ce  b806000000               mov eax, 6
000563d3  eb54                     jmp 0x56429
000563d5  8b5108                   mov edx, dword ptr [rcx + 8]
000563d8  85d2                     test edx, edx
000563da  0f8452feffff             je 0x56232
000563e0  b805000000               mov eax, 5
000563e5  eb42                     jmp 0x56429
000563e7  8b5108                   mov edx, dword ptr [rcx + 8]
000563ea  85d2                     test edx, edx
000563ec  0f84c5feffff             je 0x562b7
000563f2  b804000000               mov eax, 4
000563f7  eb30                     jmp 0x56429
000563f9  8b5108                   mov edx, dword ptr [rcx + 8]
000563fc  85d2                     test edx, edx
000563fe  0f842dffffff             je 0x56331
00056404  b803000000               mov eax, 3
00056409  eb1e                     jmp 0x56429
0005640b  8b5108                   mov edx, dword ptr [rcx + 8]
0005640e  85d2                     test edx, edx
00056410  0f846effffff             je 0x56384
00056416  b802000000               mov eax, 2
0005641b  eb0c                     jmp 0x56429
0005641d  85d2                     test edx, edx
0005641f  0f845fffffff             je 0x56384
00056425  8b442440                 mov eax, dword ptr [rsp + 0x40]
00056429  85ed                     test ebp, ebp
0005642b  7531                     jne 0x5645e
0005642d  448d40ff                 lea r8d, [rax - 1]
00056431  488d470e                 lea rax, [rdi + 0xe]
00056435  4c3bf0                   cmp r14, rax
00056438  740f                     je 0x56449
0005643a  4b8d0c46                 lea rcx, [r14 + r8*2]
0005643e  412bf0                   sub esi, r8d
00056441  48890f                   mov qword ptr [rdi], rcx
00056444  897708                   mov dword ptr [rdi + 8], esi
00056447  eb15                     jmp 0x5645e
00056449  488b4710                 mov rax, qword ptr [rdi + 0x10]
0005644d  8d4eff                   lea ecx, [rsi - 1]
00056450  488907                   mov qword ptr [rdi], rax
00056453  894f08                   mov dword ptr [rdi + 8], ecx
00056456  48c7471000000000         mov qword ptr [rdi + 0x10], 0
0005645e  0fb7ca                   movzx ecx, dx
00056461  b801000000               mov eax, 1
00056466  48c1e120                 shl rcx, 0x20
0005646a  48c1ea10                 shr rdx, 0x10
0005646e  480bca                   or rcx, rdx
00056471  49890f                   mov qword ptr [r15], rcx
00056474  e90dffffff               jmp 0x56386
00056479  0f1f00                   nop dword ptr [rax]
0005647c  316305                   xor dword ptr [rbx + 5], esp
0005647f  00b762050032             add byte ptr [rdi + 0x32000562], dh
