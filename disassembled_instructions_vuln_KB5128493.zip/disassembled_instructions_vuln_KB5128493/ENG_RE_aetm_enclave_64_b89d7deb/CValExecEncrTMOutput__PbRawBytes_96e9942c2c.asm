; CValExecEncrTMOutput::PbRawBytes
; aetm_enclave.dll, primary RVA 0x16600, 1004 bytes in 18 chunk(s)

; chunk at RVA 0x16600 (53 bytes)
00016600  4883ec38                 sub rsp, 0x38
00016604  0fb681a8000000           movzx eax, byte ptr [rcx + 0xa8]
0001660b  4c8d0dee99feff           lea r9, [rip - 0x16612]
00016612  4c8bd2                   mov r10, rdx
00016615  4c8bc1                   mov r8, rcx
00016618  420fb69408405a0600       movzx edx, byte ptr [rax + r9 + 0x65a40]
00016621  4280bc0a405b060001       cmp byte ptr [rdx + r9 + 0x65b40], 1
0001662a  7509                     jne 0x16635
0001662c  498b4208                 mov rax, qword ptr [r10 + 8]
00016630  4883c438                 add rsp, 0x38
00016634  c3                       ret

; chunk at RVA 0x16635 (103 bytes)
00016635  48895c2430               mov qword ptr [rsp + 0x30], rbx
0001663a  83c0dc                   add eax, -0x24
0001663d  488d9990000000           lea rbx, [rcx + 0x90]
00016644  c60300                   mov byte ptr [rbx], 0
00016647  48c7819100000000000000   mov qword ptr [rcx + 0x91], 0
00016652  48c7819900000000000000   mov qword ptr [rcx + 0x99], 0
0001665d  83f85b                   cmp eax, 0x5b
00016660  0f87e9020000             ja 0x1694f
00016666  4898                     cdqe
00016668  410fb6840190690100       movzx eax, byte ptr [r9 + rax + 0x16990]
00016671  418b8c815c690100         mov ecx, dword ptr [r9 + rax*4 + 0x1695c]
00016679  4903c9                   add rcx, r9
0001667c  ffe1                     jmp rcx
0001667e  410fb64208               movzx eax, byte ptr [r10 + 8]
00016683  4885db                   test rbx, rbx
00016686  0f84b1020000             je 0x1693d
0001668c  488903                   mov qword ptr [rbx], rax
0001668f  488bc3                   mov rax, rbx
00016692  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016697  4883c438                 add rsp, 0x38
0001669b  c3                       ret

; chunk at RVA 0x1669c (30 bytes)
0001669c  490fbf4208               movsx rax, word ptr [r10 + 8]
000166a1  4885db                   test rbx, rbx
000166a4  0f8493020000             je 0x1693d
000166aa  488903                   mov qword ptr [rbx], rax
000166ad  488bc3                   mov rax, rbx
000166b0  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000166b5  4883c438                 add rsp, 0x38
000166b9  c3                       ret

; chunk at RVA 0x166ba (29 bytes)
000166ba  49634208                 movsxd rax, dword ptr [r10 + 8]
000166be  4885db                   test rbx, rbx
000166c1  0f8476020000             je 0x1693d
000166c7  488903                   mov qword ptr [rbx], rax
000166ca  488bc3                   mov rax, rbx
000166cd  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000166d2  4883c438                 add rsp, 0x38
000166d6  c3                       ret

; chunk at RVA 0x166d7 (29 bytes)
000166d7  498b4208                 mov rax, qword ptr [r10 + 8]
000166db  4885db                   test rbx, rbx
000166de  0f8459020000             je 0x1693d
000166e4  488903                   mov qword ptr [rbx], rax
000166e7  488bc3                   mov rax, rbx
000166ea  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000166ef  4883c438                 add rsp, 0x38
000166f3  c3                       ret

; chunk at RVA 0x166f4 (40 bytes)
000166f4  f3410f104208             movss xmm0, dword ptr [r10 + 8]
000166fa  f30f11442440             movss dword ptr [rsp + 0x40], xmm0
00016700  4885db                   test rbx, rbx
00016703  0f8434020000             je 0x1693d
00016709  8b442440                 mov eax, dword ptr [rsp + 0x40]
0001670d  8903                     mov dword ptr [rbx], eax
0001670f  488bc3                   mov rax, rbx
00016712  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016717  4883c438                 add rsp, 0x38
0001671b  c3                       ret

; chunk at RVA 0x1671c (42 bytes)
0001671c  f2410f104208             movsd xmm0, qword ptr [r10 + 8]
00016722  f20f11442450             movsd qword ptr [rsp + 0x50], xmm0
00016728  4885db                   test rbx, rbx
0001672b  0f840c020000             je 0x1693d
00016731  488b442450               mov rax, qword ptr [rsp + 0x50]
00016736  488903                   mov qword ptr [rbx], rax
00016739  488bc3                   mov rax, rbx
0001673c  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016741  4883c438                 add rsp, 0x38
00016745  c3                       ret

; chunk at RVA 0x16746 (43 bytes)
00016746  498d4208                 lea rax, [r10 + 8]
0001674a  4885db                   test rbx, rbx
0001674d  7422                     je 0x16771
0001674f  4885c0                   test rax, rax
00016752  741d                     je 0x16771
00016754  488b00                   mov rax, qword ptr [rax]
00016757  488903                   mov qword ptr [rbx], rax
0001675a  8bc8                     mov ecx, eax
0001675c  8b4304                   mov eax, dword ptr [rbx + 4]
0001675f  8903                     mov dword ptr [rbx], eax
00016761  488bc3                   mov rax, rbx
00016764  894b04                   mov dword ptr [rbx + 4], ecx
00016767  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0001676c  4883c438                 add rsp, 0x38
00016770  c3                       ret

; chunk at RVA 0x16771 (41 bytes)
00016771  ff1521ca0400             call qword ptr [rip + 0x4ca21]
00016777  c70016000000             mov dword ptr [rax], 0x16
0001677d  ff151dca0400             call qword ptr [rip + 0x4ca1d]
00016783  8b4304                   mov eax, dword ptr [rbx + 4]
00016786  8b0b                     mov ecx, dword ptr [rbx]
00016788  8903                     mov dword ptr [rbx], eax
0001678a  488bc3                   mov rax, rbx
0001678d  894b04                   mov dword ptr [rbx + 4], ecx
00016790  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016795  4883c438                 add rsp, 0x38
00016799  c3                       ret

; chunk at RVA 0x1679a (45 bytes)
0001679a  410fb6521b               movzx edx, byte ptr [r10 + 0x1b]
0001679f  498d4a08                 lea rcx, [r10 + 8]
000167a3  4c8bcb                   mov r9, rbx
000167a6  c744242011000000         mov dword ptr [rsp + 0x20], 0x11
000167ae  4981c0a8000000           add r8, 0xa8
000167b5  e8f6100000               call 0x178b0
000167ba  488bc3                   mov rax, rbx
000167bd  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000167c2  4883c438                 add rsp, 0x38
000167c6  c3                       ret

; chunk at RVA 0x167c7 (31 bytes)
000167c7  ff15cbc90400             call qword ptr [rip + 0x4c9cb]
000167cd  c70022000000             mov dword ptr [rax], 0x22
000167d3  ff15c7c90400             call qword ptr [rip + 0x4c9c7]
000167d9  488bc3                   mov rax, rbx
000167dc  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000167e1  4883c438                 add rsp, 0x38
000167e5  c3                       ret

; chunk at RVA 0x167e6 (69 bytes)
000167e6  498bd2                   mov rdx, r10
000167e9  498bc8                   mov rcx, r8
000167ec  e80f020000               call 0x16a00
000167f1  448bc0                   mov r8d, eax
000167f4  498d5208                 lea rdx, [r10 + 8]
000167f8  85c0                     test eax, eax
000167fa  7467                     je 0x16863
000167fc  4885db                   test rbx, rbx
000167ff  7450                     je 0x16851
00016801  4885d2                   test rdx, rdx
00016804  744b                     je 0x16851
00016806  4983f811                 cmp r8, 0x11
0001680a  771f                     ja 0x1682b
0001680c  0faee8                   lfence
0001680f  488bcb                   mov rcx, rbx
00016812  e89c7a0400               call 0x5e2b3
00016817  8b03                     mov eax, dword ptr [rbx]
00016819  c1c010                   rol eax, 0x10
0001681c  8903                     mov dword ptr [rbx], eax
0001681e  488bc3                   mov rax, rbx
00016821  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016826  4883c438                 add rsp, 0x38
0001682a  c3                       ret

; chunk at RVA 0x1682b (38 bytes)
0001682b  ff1567c90400             call qword ptr [rip + 0x4c967]
00016831  c70022000000             mov dword ptr [rax], 0x22
00016837  ff1563c90400             call qword ptr [rip + 0x4c963]
0001683d  8b03                     mov eax, dword ptr [rbx]
0001683f  c1c010                   rol eax, 0x10
00016842  8903                     mov dword ptr [rbx], eax
00016844  488bc3                   mov rax, rbx
00016847  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0001684c  4883c438                 add rsp, 0x38
00016850  c3                       ret

; chunk at RVA 0x16851 (38 bytes)
00016851  ff1541c90400             call qword ptr [rip + 0x4c941]
00016857  c70016000000             mov dword ptr [rax], 0x16
0001685d  ff153dc90400             call qword ptr [rip + 0x4c93d]
00016863  8b03                     mov eax, dword ptr [rbx]
00016865  c1c010                   rol eax, 0x10
00016868  8903                     mov dword ptr [rbx], eax
0001686a  488bc3                   mov rax, rbx
0001686d  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016872  4883c438                 add rsp, 0x38
00016876  c3                       ret

; chunk at RVA 0x16877 (100 bytes)
00016877  410fb780b8000000         movzx eax, word ptr [r8 + 0xb8]
0001687f  b9ffff0000               mov ecx, 0xffff
00016884  663bc1                   cmp ax, cx
00016887  740b                     je 0x16894
00016889  4280bc0a9073460000       cmp byte ptr [rdx + r9 + 0x467390], 0
00016892  7405                     je 0x16899
00016894  b8a41f0000               mov eax, 0x1fa4
00016899  440fb7c0                 movzx r8d, ax
0001689d  498d520b                 lea rdx, [r10 + 0xb]
000168a1  4d85c0                   test r8, r8
000168a4  0f84a5000000             je 0x1694f
000168aa  4885db                   test rbx, rbx
000168ad  0f848a000000             je 0x1693d
000168b3  4885d2                   test rdx, rdx
000168b6  0f8481000000             je 0x1693d
000168bc  4983f811                 cmp r8, 0x11
000168c0  0f8701ffffff             ja 0x167c7
000168c6  488bcb                   mov rcx, rbx
000168c9  e8e5790400               call 0x5e2b3
000168ce  488bc3                   mov rax, rbx
000168d1  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000168d6  4883c438                 add rsp, 0x38
000168da  c3                       ret

; chunk at RVA 0x168db (98 bytes)
000168db  4983c208                 add r10, 8
000168df  4885db                   test rbx, rbx
000168e2  0f8489feffff             je 0x16771
000168e8  4d85d2                   test r10, r10
000168eb  0f8480feffff             je 0x16771
000168f1  418b02                   mov eax, dword ptr [r10]
000168f4  8903                     mov dword ptr [rbx], eax
000168f6  e988feffff               jmp 0x16783
000168fb  498bd2                   mov rdx, r10
000168fe  498bc8                   mov rcx, r8
00016901  e8fa000000               call 0x16a00
00016906  448bc0                   mov r8d, eax
00016909  498d5208                 lea rdx, [r10 + 8]
0001690d  85c0                     test eax, eax
0001690f  743e                     je 0x1694f
00016911  4885db                   test rbx, rbx
00016914  7427                     je 0x1693d
00016916  4885d2                   test rdx, rdx
00016919  7422                     je 0x1693d
0001691b  4983f811                 cmp r8, 0x11
0001691f  0f87a2feffff             ja 0x167c7
00016925  0faee8                   lfence
00016928  488bcb                   mov rcx, rbx
0001692b  e883790400               call 0x5e2b3
00016930  488bc3                   mov rax, rbx
00016933  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016938  4883c438                 add rsp, 0x38
0001693c  c3                       ret

; chunk at RVA 0x1693d (31 bytes)
0001693d  ff1555c80400             call qword ptr [rip + 0x4c855]
00016943  c70016000000             mov dword ptr [rax], 0x16
00016949  ff1551c80400             call qword ptr [rip + 0x4c851]
0001694f  488bc3                   mov rax, rbx
00016952  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00016957  4883c438                 add rsp, 0x38
0001695b  c3                       ret

; chunk at RVA 0x1695c (144 bytes)
0001695c  fb                       sti
0001695d  6801009a67               push 0x679a0001
00016962  0100                     add dword ptr [rax], eax
00016964  7e66                     jle 0x169cc
00016966  0100                     add dword ptr [rax], eax
00016968  9c                       pushfq
00016969  660100                   add word ptr [rax], ax
0001696c  ba660100e6               mov edx, 0xe6000166
00016971  670100                   add dword ptr [eax], eax
00016974  f4                       hlt
00016975  660100                   add word ptr [rax], ax
00016978  46670100                 add dword ptr [eax], eax
0001697c  1c67                     sbb al, 0x67
0001697e  0100                     add dword ptr [rax], eax
00016980  7768                     ja 0x169ea
00016982  0100                     add dword ptr [rax], eax
00016984  db6801                   fld xword ptr [rax + 1]
00016987  00d7                     add bh, dl
00016989  660100                   add word ptr [rax], ax
0001698c  4f690100000c0c           imul r8, qword ptr [r9], 0xc0c0000
00016993  0c00                     or al, 0
00016995  0101                     add dword ptr [rcx], eax
00016997  010c0c                   add dword ptr [rsp + rcx], ecx
0001699a  0c0c                     or al, 0xc
0001699c  020c0c                   add cl, byte ptr [rsp + rcx]
0001699f  0c03                     or al, 3
000169a1  0c0c                     or al, 0xc
000169a3  0c04                     or al, 4
000169a5  0c05                     or al, 5
