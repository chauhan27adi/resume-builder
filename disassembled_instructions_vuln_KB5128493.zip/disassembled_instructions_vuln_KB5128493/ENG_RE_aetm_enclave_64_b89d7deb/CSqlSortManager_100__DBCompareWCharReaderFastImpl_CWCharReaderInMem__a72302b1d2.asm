; CSqlSortManager_100::DBCompareWCharReaderFastImpl<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x54830, 5776 bytes in 1 chunk(s)

; chunk at RVA 0x54830 (5776 bytes)
00054830  4489442418               mov dword ptr [rsp + 0x18], r8d
00054835  4889542410               mov qword ptr [rsp + 0x10], rdx
0005483a  48894c2408               mov qword ptr [rsp + 8], rcx
0005483f  55                       push rbp
00054840  53                       push rbx
00054841  56                       push rsi
00054842  57                       push rdi
00054843  4154                     push r12
00054845  4155                     push r13
00054847  4156                     push r14
00054849  4157                     push r15
0005484b  488d6c24e9               lea rbp, [rsp - 0x17]
00054850  4881ecd8000000           sub rsp, 0xd8
00054857  4c8b657f                 mov r12, qword ptr [rbp + 0x7f]
0005485b  33c0                     xor eax, eax
0005485d  8bd8                     mov ebx, eax
0005485f  488945bf                 mov qword ptr [rbp - 0x41], rax
00054863  8bf8                     mov edi, eax
00054865  488945b7                 mov qword ptr [rbp - 0x49], rax
00054869  448bf0                   mov r14d, eax
0005486c  8945a3                   mov dword ptr [rbp - 0x5d], eax
0005486f  8bf0                     mov esi, eax
00054871  c745f708000000           mov dword ptr [rbp - 9], 8
00054878  418bc8                   mov ecx, r8d
0005487b  4d8bf9                   mov r15, r9
0005487e  448bc8                   mov r9d, eax
00054881  c1e910                   shr ecx, 0x10
00054884  418bc0                   mov eax, r8d
00054887  83e103                   and ecx, 3
0005488a  83e001                   and eax, 1
0005488d  41ba07000000             mov r10d, 7
00054893  89450b                   mov dword ptr [rbp + 0xb], eax
00054896  41bb01000000             mov r11d, 1
0005489c  418bc0                   mov eax, r8d
0005489f  4489559f                 mov dword ptr [rbp - 0x61], r10d
000548a3  83e002                   and eax, 2
000548a6  44895dfb                 mov dword ptr [rbp - 5], r11d
000548aa  8945ff                   mov dword ptr [rbp - 1], eax
000548ad  458be8                   mov r13d, r8d
000548b0  418bc0                   mov eax, r8d
000548b3  2500000100               and eax, 0x10000
000548b8  8945df                   mov dword ptr [rbp - 0x21], eax
000548bb  418bc0                   mov eax, r8d
000548be  2500000200               and eax, 0x20000
000548c3  8945d3                   mov dword ptr [rbp - 0x2d], eax
000548c6  418bc0                   mov eax, r8d
000548c9  83e003                   and eax, 3
000548cc  4c8d05c1820400           lea r8, [rip + 0x482c1]
000548d3  8d0c88                   lea ecx, [rax + rcx*4]
000548d6  488d0523b7faff           lea rax, [rip - 0x548dd]
000548dd  0fb6848833050900         movzx eax, byte ptr [rax + rcx*4 + 0x90533]
000548e5  8845cc                   mov byte ptr [rbp - 0x34], al
000548e8  0c18                     or al, 0x18
000548ea  8845cb                   mov byte ptr [rbp - 0x35], al
000548ed  418b4708                 mov eax, dword ptr [r15 + 8]
000548f1  85c0                     test eax, eax
000548f3  747b                     je 0x54970
000548f5  41395c2408               cmp dword ptr [r12 + 8], ebx
000548fa  7474                     je 0x54970
000548fc  498b07                   mov rax, qword ptr [r15]
000548ff  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054903  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
00054907  448945cf                 mov dword ptr [rbp - 0x31], r8d
0005490b  0fb708                   movzx ecx, word ptr [rax]
0005490e  498b5308                 mov rdx, qword ptr [r11 + 8]
00054912  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00054915  0fb7d8                   movzx ebx, ax
00054918  48c1e810                 shr rax, 0x10
0005491c  48c1e320                 shl rbx, 0x20
00054920  480bd8                   or rbx, rax
00054923  498b0424                 mov rax, qword ptr [r12]
00054927  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0005492b  0fb708                   movzx ecx, word ptr [rax]
0005492e  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00054931  0fb64da6                 movzx ecx, byte ptr [rbp - 0x5a]
00054935  0fb655a5                 movzx edx, byte ptr [rbp - 0x5b]
00054939  48894de7                 mov qword ptr [rbp - 0x19], rcx
0005493d  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
00054941  884d77                   mov byte ptr [rbp + 0x77], cl
00054944  410fb6c9                 movzx ecx, r9b
00054948  0fb7f8                   movzx edi, ax
0005494b  884da7                   mov byte ptr [rbp - 0x59], cl
0005494e  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00054951  48c1e720                 shl rdi, 0x20
00054955  48c1e810                 shr rax, 0x10
00054959  894dab                   mov dword ptr [rbp - 0x55], ecx
0005495c  480bf8                   or rdi, rax
0005495f  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00054962  4533ed                   xor r13d, r13d
00054965  894dc7                   mov dword ptr [rbp - 0x39], ecx
00054968  8855a8                   mov byte ptr [rbp - 0x58], dl
0005496b  e9de000000               jmp 0x54a4e
00054970  0fb64da6                 movzx ecx, byte ptr [rbp - 0x5a]
00054974  0fb655a5                 movzx edx, byte ptr [rbp - 0x5b]
00054978  48894de7                 mov qword ptr [rbp - 0x19], rcx
0005497c  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
00054980  884d77                   mov byte ptr [rbp + 0x77], cl
00054983  0fb64da3                 movzx ecx, byte ptr [rbp - 0x5d]
00054987  884da7                   mov byte ptr [rbp - 0x59], cl
0005498a  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
0005498d  894dab                   mov dword ptr [rbp - 0x55], ecx
00054990  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00054993  894dcf                   mov dword ptr [rbp - 0x31], ecx
00054996  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00054999  894dc7                   mov dword ptr [rbp - 0x39], ecx
0005499c  8855a8                   mov byte ptr [rbp - 0x58], dl
0005499f  410fbae51b               bt r13d, 0x1b
000549a4  0f839b130000             jae 0x55d45
000549aa  85c0                     test eax, eax
000549ac  754e                     jne 0x549fc
000549ae  4139442408               cmp dword ptr [r12 + 8], eax
000549b3  0f848c130000             je 0x55d45
000549b9  45895f08                 mov dword ptr [r15 + 8], r11d
000549bd  4533ed                   xor r13d, r13d
000549c0  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
000549c4  4d8907                   mov qword ptr [r15], r8
000549c7  4d894718                 mov qword ptr [r15 + 0x18], r8
000549cb  4d896f10                 mov qword ptr [r15 + 0x10], r13
000549cf  498b5308                 mov rdx, qword ptr [r11 + 8]
000549d3  8b8280000000             mov eax, dword ptr [rdx + 0x80]
000549d9  0fb7d8                   movzx ebx, ax
000549dc  48c1e320                 shl rbx, 0x20
000549e0  48c1e810                 shr rax, 0x10
000549e4  480bd8                   or rbx, rax
000549e7  48895dbf                 mov qword ptr [rbp - 0x41], rbx
000549eb  4585c9                   test r9d, r9d
000549ee  7570                     jne 0x54a60
000549f0  498b0424                 mov rax, qword ptr [r12]
000549f4  0fb708                   movzx ecx, word ptr [rax]
000549f7  8b048a                   mov eax, dword ptr [rdx + rcx*4]
000549fa  eb44                     jmp 0x54a40
000549fc  45895c2408               mov dword ptr [r12 + 8], r11d
00054a01  4533ed                   xor r13d, r13d
00054a04  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054a08  4d890424                 mov qword ptr [r12], r8
00054a0c  4d89442418               mov qword ptr [r12 + 0x18], r8
00054a11  4d896c2410               mov qword ptr [r12 + 0x10], r13
00054a16  498b5308                 mov rdx, qword ptr [r11 + 8]
00054a1a  4585c9                   test r9d, r9d
00054a1d  751b                     jne 0x54a3a
00054a1f  498b07                   mov rax, qword ptr [r15]
00054a22  0fb708                   movzx ecx, word ptr [rax]
00054a25  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00054a28  0fb7d8                   movzx ebx, ax
00054a2b  48c1e320                 shl rbx, 0x20
00054a2f  48c1e810                 shr rax, 0x10
00054a33  480bd8                   or rbx, rax
00054a36  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054a3a  8b8280000000             mov eax, dword ptr [rdx + 0x80]
00054a40  0fb7f8                   movzx edi, ax
00054a43  48c1e720                 shl rdi, 0x20
00054a47  48c1e810                 shr rax, 0x10
00054a4b  480bf8                   or rdi, rax
00054a4e  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054a52  0f1f4000                 nop dword ptr [rax]
00054a56  66660f1f840000000000     nop word ptr [rax + rax]
00054a60  41837b1400               cmp dword ptr [r11 + 0x14], 0
00054a65  44896daf                 mov dword ptr [rbp - 0x51], r13d
00054a69  0f84af000000             je 0x54b1e
00054a6f  4d8b4338                 mov r8, qword ptr [r11 + 0x38]
00054a73  488bc3                   mov rax, rbx
00054a76  4d85c0                   test r8, r8
00054a79  7441                     je 0x54abc
00054a7b  48c1e828                 shr rax, 0x28
00054a7f  3cfe                     cmp al, 0xfe
00054a81  7514                     jne 0x54a97
00054a83  4c8d4dbf                 lea r9, [rbp - 0x41]
00054a87  498bd7                   mov rdx, r15
00054a8a  e8111a0000               call 0x564a0
00054a8f  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054a93  488b5dbf                 mov rbx, qword ptr [rbp - 0x41]
00054a97  488bc7                   mov rax, rdi
00054a9a  48c1e828                 shr rax, 0x28
00054a9e  3cfe                     cmp al, 0xfe
00054aa0  0f8578000000             jne 0x54b1e
00054aa6  4d8b4338                 mov r8, qword ptr [r11 + 0x38]
00054aaa  4c8d4db7                 lea r9, [rbp - 0x49]
00054aae  498bd4                   mov rdx, r12
00054ab1  e8ea190000               call 0x564a0
00054ab6  488b7db7                 mov rdi, qword ptr [rbp - 0x49]
00054aba  eb62                     jmp 0x54b1e
00054abc  48c1e808                 shr rax, 8
00054ac0  a8c0                     test al, 0xc0
00054ac2  741e                     je 0x54ae2
00054ac4  49837f1000               cmp qword ptr [r15 + 0x10], 0
00054ac9  7517                     jne 0x54ae2
00054acb  4c8d4dbf                 lea r9, [rbp - 0x41]
00054acf  4d8bc3                   mov r8, r11
00054ad2  498bd7                   mov rdx, r15
00054ad5  e8f6130000               call 0x55ed0
00054ada  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054ade  488b5dbf                 mov rbx, qword ptr [rbp - 0x41]
00054ae2  488bc7                   mov rax, rdi
00054ae5  48c1e808                 shr rax, 8
00054ae9  a8c0                     test al, 0xc0
00054aeb  741b                     je 0x54b08
00054aed  49837c241000             cmp qword ptr [r12 + 0x10], 0
00054af3  7513                     jne 0x54b08
00054af5  4c8d4db7                 lea r9, [rbp - 0x49]
00054af9  4d8bc3                   mov r8, r11
00054afc  498bd4                   mov rdx, r12
00054aff  e8cc130000               call 0x55ed0
00054b04  488b7db7                 mov rdi, qword ptr [rbp - 0x49]
00054b08  4881e3ff3fffff           and rbx, 0xffffffffffff3fff
00054b0f  4881e7ff3fffff           and rdi, 0xffffffffffff3fff
00054b16  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054b1a  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054b1e  4c8bdb                   mov r11, rbx
00054b21  4c8bef                   mov r13, rdi
00054b24  49c1eb28                 shr r11, 0x28
00054b28  49c1ed28                 shr r13, 0x28
00054b2c  4c895def                 mov qword ptr [rbp - 0x11], r11
00054b30  4c896dd7                 mov qword ptr [rbp - 0x29], r13
00054b34  4180fb06                 cmp r11b, 6
00054b38  0f86ec000000             jbe 0x54c2a
00054b3e  4180fd06                 cmp r13b, 6
00054b42  0f8641010000             jbe 0x54c89
00054b48  4c8bf3                   mov r14, rbx
00054b4b  488bf7                   mov rsi, rdi
00054b4e  448b559f                 mov r10d, dword ptr [rbp - 0x61]
00054b52  b803000000               mov eax, 3
00054b57  41b901000000             mov r9d, 1
00054b5d  488bd3                   mov rdx, rbx
00054b60  4c8bc7                   mov r8, rdi
00054b63  48c1ea10                 shr rdx, 0x10
00054b67  49c1e810                 shr r8, 0x10
00054b6b  413bd0                   cmp edx, r8d
00054b6e  0f85be110000             jne 0x55d32
00054b74  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054b78  33c0                     xor eax, eax
00054b7a  4c8beb                   mov r13, rbx
00054b7d  49c1ed28                 shr r13, 0x28
00054b81  4180fd14                 cmp r13b, 0x14
00054b85  0f96c0                   setbe al
00054b88  8945fb                   mov dword ptr [rbp - 5], eax
00054b8b  483bdf                   cmp rbx, rdi
00054b8e  0f8499100000             je 0x55c2d
00054b94  418d4540                 lea eax, [r13 + 0x40]
00054b98  3c30                     cmp al, 0x30
00054b9a  0f87c10f0000             ja 0x55b61
00054ba0  418b0b                   mov ecx, dword ptr [r11]
00054ba3  8bc1                     mov eax, ecx
00054ba5  25ff030000               and eax, 0x3ff
00054baa  83f804                   cmp eax, 4
00054bad  740c                     je 0x54bbb
00054baf  81f911040400             cmp ecx, 0x40411
00054bb5  0f85a60f0000             jne 0x55b61
00054bbb  0fb6cb                   movzx ecx, bl
00054bbe  c1e108                   shl ecx, 8
00054bc1  48c1eb08                 shr rbx, 8
00054bc5  0fb6db                   movzx ebx, bl
00054bc8  480bd9                   or rbx, rcx
00054bcb  8bc2                     mov eax, edx
00054bcd  400fb6cf                 movzx ecx, dil
00054bd1  480bd8                   or rbx, rax
00054bd4  48c1ef08                 shr rdi, 8
00054bd8  400fb6ff                 movzx edi, dil
00054bdc  c1e108                   shl ecx, 8
00054bdf  480bf9                   or rdi, rcx
00054be2  418bc0                   mov eax, r8d
00054be5  480bf8                   or rdi, rax
00054be8  48c1e310                 shl rbx, 0x10
00054bec  4881cb02020000           or rbx, 0x202
00054bf3  48c1e710                 shl rdi, 0x10
00054bf7  4881cf02020000           or rdi, 0x202
00054bfe  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054c02  488bcf                   mov rcx, rdi
00054c05  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054c09  488bc3                   mov rax, rbx
00054c0c  48c1e910                 shr rcx, 0x10
00054c10  48c1e810                 shr rax, 0x10
00054c14  3bc1                     cmp eax, ecx
00054c16  0f8411100000             je 0x55c2d
00054c1c  b803000000               mov eax, 3
00054c21  410f42c1                 cmovb eax, r9d
00054c25  e915120000               jmp 0x55e3f
00054c2a  4584db                   test r11b, r11b
00054c2d  755a                     jne 0x54c89
00054c2f  418b4f08                 mov ecx, dword ptr [r15 + 8]
00054c33  498d470e                 lea rax, [r15 + 0xe]
00054c37  498b17                   mov rdx, qword ptr [r15]
00054c3a  ffc9                     dec ecx
00054c3c  483bd0                   cmp rdx, rax
00054c3f  7406                     je 0x54c47
00054c41  488d4202                 lea rax, [rdx + 2]
00054c45  eb0c                     jmp 0x54c53
00054c47  498b4710                 mov rax, qword ptr [r15 + 0x10]
00054c4b  49c7471000000000         mov qword ptr [r15 + 0x10], 0
00054c53  498907                   mov qword ptr [r15], rax
00054c56  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
00054c5a  41894f08                 mov dword ptr [r15 + 8], ecx
00054c5e  85c9                     test ecx, ecx
00054c60  741c                     je 0x54c7e
00054c62  0fb708                   movzx ecx, word ptr [rax]
00054c65  498b4008                 mov rax, qword ptr [r8 + 8]
00054c69  8b1488                   mov edx, dword ptr [rax + rcx*4]
00054c6c  0fb7da                   movzx ebx, dx
00054c6f  48c1e320                 shl rbx, 0x20
00054c73  48c1ea10                 shr rdx, 0x10
00054c77  480bda                   or rbx, rdx
00054c7a  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054c7e  41ba01000000             mov r10d, 1
00054c84  458bca                   mov r9d, r10d
00054c87  eb0e                     jmp 0x54c97
00054c89  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
00054c8d  41ba01000000             mov r10d, 1
00054c93  448b4daf                 mov r9d, dword ptr [rbp - 0x51]
00054c97  4584ed                   test r13b, r13b
00054c9a  7555                     jne 0x54cf1
00054c9c  418b4c2408               mov ecx, dword ptr [r12 + 8]
00054ca1  498d44240e               lea rax, [r12 + 0xe]
00054ca6  498b1424                 mov rdx, qword ptr [r12]
00054caa  ffc9                     dec ecx
00054cac  483bd0                   cmp rdx, rax
00054caf  7406                     je 0x54cb7
00054cb1  488d4202                 lea rax, [rdx + 2]
00054cb5  eb0e                     jmp 0x54cc5
00054cb7  498b442410               mov rax, qword ptr [r12 + 0x10]
00054cbc  49c744241000000000       mov qword ptr [r12 + 0x10], 0
00054cc5  49890424                 mov qword ptr [r12], rax
00054cc9  41894c2408               mov dword ptr [r12 + 8], ecx
00054cce  85c9                     test ecx, ecx
00054cd0  741c                     je 0x54cee
00054cd2  0fb708                   movzx ecx, word ptr [rax]
00054cd5  498b4008                 mov rax, qword ptr [r8 + 8]
00054cd9  8b1488                   mov edx, dword ptr [rax + rcx*4]
00054cdc  0fb7fa                   movzx edi, dx
00054cdf  48c1e720                 shl rdi, 0x20
00054ce3  48c1ea10                 shr rdx, 0x10
00054ce7  480bfa                   or rdi, rdx
00054cea  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054cee  458bca                   mov r9d, r10d
00054cf1  837dff00                 cmp dword ptr [rbp - 1], 0
00054cf5  0f84b9000000             je 0x54db4
00054cfb  837dfb00                 cmp dword ptr [rbp - 5], 0
00054cff  0f84af000000             je 0x54db4
00054d05  4180fb01                 cmp r11b, 1
00054d09  754e                     jne 0x54d59
00054d0b  418b4f08                 mov ecx, dword ptr [r15 + 8]
00054d0f  498d470e                 lea rax, [r15 + 0xe]
00054d13  498b17                   mov rdx, qword ptr [r15]
00054d16  ffc9                     dec ecx
00054d18  483bd0                   cmp rdx, rax
00054d1b  7406                     je 0x54d23
00054d1d  488d4202                 lea rax, [rdx + 2]
00054d21  eb0c                     jmp 0x54d2f
00054d23  498b4710                 mov rax, qword ptr [r15 + 0x10]
00054d27  49c7471000000000         mov qword ptr [r15 + 0x10], 0
00054d2f  498907                   mov qword ptr [r15], rax
00054d32  41894f08                 mov dword ptr [r15 + 8], ecx
00054d36  85c9                     test ecx, ecx
00054d38  741c                     je 0x54d56
00054d3a  0fb708                   movzx ecx, word ptr [rax]
00054d3d  498b4008                 mov rax, qword ptr [r8 + 8]
00054d41  8b1488                   mov edx, dword ptr [rax + rcx*4]
00054d44  0fb7da                   movzx ebx, dx
00054d47  48c1e320                 shl rbx, 0x20
00054d4b  48c1ea10                 shr rdx, 0x10
00054d4f  480bda                   or rbx, rdx
00054d52  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054d56  458bca                   mov r9d, r10d
00054d59  4180fd01                 cmp r13b, 1
00054d5d  7555                     jne 0x54db4
00054d5f  418b4c2408               mov ecx, dword ptr [r12 + 8]
00054d64  498d44240e               lea rax, [r12 + 0xe]
00054d69  498b1424                 mov rdx, qword ptr [r12]
00054d6d  ffc9                     dec ecx
00054d6f  483bd0                   cmp rdx, rax
00054d72  7406                     je 0x54d7a
00054d74  488d4202                 lea rax, [rdx + 2]
00054d78  eb0e                     jmp 0x54d88
00054d7a  498b442410               mov rax, qword ptr [r12 + 0x10]
00054d7f  49c744241000000000       mov qword ptr [r12 + 0x10], 0
00054d88  49890424                 mov qword ptr [r12], rax
00054d8c  41894c2408               mov dword ptr [r12 + 8], ecx
00054d91  85c9                     test ecx, ecx
00054d93  741c                     je 0x54db1
00054d95  0fb708                   movzx ecx, word ptr [rax]
00054d98  498b4008                 mov rax, qword ptr [r8 + 8]
00054d9c  8b1488                   mov edx, dword ptr [rax + rcx*4]
00054d9f  0fb7fa                   movzx edi, dx
00054da2  48c1e720                 shl rdi, 0x20
00054da6  48c1ea10                 shr rdx, 0x10
00054daa  480bfa                   or rdi, rdx
00054dad  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054db1  458bca                   mov r9d, r10d
00054db4  4180fb02                 cmp r11b, 2
00054db8  0f85b7000000             jne 0x54e75
00054dbe  458b5f08                 mov r11d, dword ptr [r15 + 8]
00054dc2  4d8d4f0e                 lea r9, [r15 + 0xe]
00054dc6  488bc3                   mov rax, rbx
00054dc9  498d570c                 lea rdx, [r15 + 0xc]
00054dcd  48c1e808                 shr rax, 8
00054dd1  0fb6c8                   movzx ecx, al
00054dd4  48c1eb20                 shr rbx, 0x20
00054dd8  48c1e108                 shl rcx, 8
00054ddc  0fb6c3                   movzx eax, bl
00054ddf  480bc8                   or rcx, rax
00054de2  488b455f                 mov rax, qword ptr [rbp + 0x5f]
00054de6  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00054ded  448b0488                 mov r8d, dword ptr [rax + rcx*4]
00054df1  440fb71488               movzx r10d, word ptr [rax + rcx*4]
00054df6  498b07                   mov rax, qword ptr [r15]
00054df9  41c1e810                 shr r8d, 0x10
00054dfd  493bc1                   cmp rax, r9
00054e00  741a                     je 0x54e1c
00054e02  498b4f10                 mov rcx, qword ptr [r15 + 0x10]
00054e06  4883c002                 add rax, 2
00054e0a  498907                   mov qword ptr [r15], rax
00054e0d  66448912                 mov word ptr [rdx], r10w
00054e11  66458901                 mov word ptr [r9], r8w
00054e15  4885c9                   test rcx, rcx
00054e18  751e                     jne 0x54e38
00054e1a  eb15                     jmp 0x54e31
00054e1c  498b4710                 mov rax, qword ptr [r15 + 0x10]
00054e20  33c9                     xor ecx, ecx
00054e22  49894f10                 mov qword ptr [r15 + 0x10], rcx
00054e26  498907                   mov qword ptr [r15], rax
00054e29  66448912                 mov word ptr [rdx], r10w
00054e2d  66458901                 mov word ptr [r9], r8w
00054e31  498b07                   mov rax, qword ptr [r15]
00054e34  49894710                 mov qword ptr [r15 + 0x10], rax
00054e38  498917                   mov qword ptr [r15], rdx
00054e3b  418d4301                 lea eax, [r11 + 1]
00054e3f  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
00054e43  41894708                 mov dword ptr [r15 + 8], eax
00054e47  488b4567                 mov rax, qword ptr [rbp + 0x67]
00054e4b  488b4008                 mov rax, qword ptr [rax + 8]
00054e4f  428b1490                 mov edx, dword ptr [rax + r10*4]
00054e53  41ba01000000             mov r10d, 1
00054e59  0fb7da                   movzx ebx, dx
00054e5c  458bca                   mov r9d, r10d
00054e5f  48c1e320                 shl rbx, 0x20
00054e63  48c1ea10                 shr rdx, 0x10
00054e67  480bda                   or rbx, rdx
00054e6a  33d2                     xor edx, edx
00054e6c  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00054e70  448bf2                   mov r14d, edx
00054e73  eb02                     jmp 0x54e77
00054e75  33d2                     xor edx, edx
00054e77  4180fd02                 cmp r13b, 2
00054e7b  0f85c5000000             jne 0x54f46
00054e81  458b5c2408               mov r11d, dword ptr [r12 + 8]
00054e86  4d8d4c240e               lea r9, [r12 + 0xe]
00054e8b  488bc7                   mov rax, rdi
00054e8e  48c1ef20                 shr rdi, 0x20
00054e92  48c1e808                 shr rax, 8
00054e96  0fb6c8                   movzx ecx, al
00054e99  48c1e108                 shl rcx, 8
00054e9d  400fb6c7                 movzx eax, dil
00054ea1  480bc8                   or rcx, rax
00054ea4  488b455f                 mov rax, qword ptr [rbp + 0x5f]
00054ea8  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00054eaf  448b0488                 mov r8d, dword ptr [rax + rcx*4]
00054eb3  440fb71488               movzx r10d, word ptr [rax + rcx*4]
00054eb8  498b0424                 mov rax, qword ptr [r12]
00054ebc  41c1e810                 shr r8d, 0x10
00054ec0  493bc1                   cmp rax, r9
00054ec3  7421                     je 0x54ee6
00054ec5  498b4c2410               mov rcx, qword ptr [r12 + 0x10]
00054eca  498d54240c               lea rdx, [r12 + 0xc]
00054ecf  4883c002                 add rax, 2
00054ed3  49890424                 mov qword ptr [r12], rax
00054ed7  66448912                 mov word ptr [rdx], r10w
00054edb  66458901                 mov word ptr [r9], r8w
00054edf  4885c9                   test rcx, rcx
00054ee2  7526                     jne 0x54f0a
00054ee4  eb1b                     jmp 0x54f01
00054ee6  498b442410               mov rax, qword ptr [r12 + 0x10]
00054eeb  4989542410               mov qword ptr [r12 + 0x10], rdx
00054ef0  498d54240c               lea rdx, [r12 + 0xc]
00054ef5  49890424                 mov qword ptr [r12], rax
00054ef9  66448912                 mov word ptr [rdx], r10w
00054efd  66458901                 mov word ptr [r9], r8w
00054f01  498b0424                 mov rax, qword ptr [r12]
00054f05  4989442410               mov qword ptr [r12 + 0x10], rax
00054f0a  418d4301                 lea eax, [r11 + 1]
00054f0e  49891424                 mov qword ptr [r12], rdx
00054f12  4189442408               mov dword ptr [r12 + 8], eax
00054f17  41bb01000000             mov r11d, 1
00054f1d  488b4567                 mov rax, qword ptr [rbp + 0x67]
00054f21  458bcb                   mov r9d, r11d
00054f24  488b4008                 mov rax, qword ptr [rax + 8]
00054f28  428b1490                 mov edx, dword ptr [rax + r10*4]
00054f2c  0fb7fa                   movzx edi, dx
00054f2f  48c1e720                 shl rdi, 0x20
00054f33  48c1ea10                 shr rdx, 0x10
00054f37  480bfa                   or rdi, rdx
00054f3a  4533ed                   xor r13d, r13d
00054f3d  48897db7                 mov qword ptr [rbp - 0x49], rdi
00054f41  418bf5                   mov esi, r13d
00054f44  eb0e                     jmp 0x54f54
00054f46  4585c9                   test r9d, r9d
00054f49  742a                     je 0x54f75
00054f4b  41bb01000000             mov r11d, 1
00054f51  4533ed                   xor r13d, r13d
00054f54  418b4708                 mov eax, dword ptr [r15 + 8]
00054f58  85c0                     test eax, eax
00054f5a  0f849e0d0000             je 0x55cfe
00054f60  41837c240800             cmp dword ptr [r12 + 8], 0
00054f66  0f84920d0000             je 0x55cfe
00054f6c  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00054f70  e9ebfaffff               jmp 0x54a60
00054f75  410fb6c3                 movzx eax, r11b
00054f79  83f806                   cmp eax, 6
00054f7c  0f8748030000             ja 0x552ca
00054f82  4c8d0577b0faff           lea r8, [rip - 0x54f89]
00054f89  418b8c80545e0500         mov ecx, dword ptr [r8 + rax*4 + 0x55e54]
00054f91  4903c8                   add rcx, r8
00054f94  ffe1                     jmp rcx
00054f96  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00054f9a  4d8bc7                   mov r8, r15
00054f9d  e8ee150000               call 0x56590
00054fa2  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
00054fa6  440fb7e8                 movzx r13d, ax
00054faa  33d2                     xor edx, edx
00054fac  0fb6c3                   movzx eax, bl
00054faf  664403e8                 add r13w, ax
00054fb3  440fb7c2                 movzx r8d, dx
00054fb7  44385dd7                 cmp byte ptr [rbp - 0x29], r11b
00054fbb  0f8579000000             jne 0x5503a
00054fc1  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00054fc5  4d8bc4                   mov r8, r12
00054fc8  e8c3150000               call 0x56590
00054fcd  498b0c24                 mov rcx, qword ptr [r12]
00054fd1  440fb7c0                 movzx r8d, ax
00054fd5  400fb6c7                 movzx eax, dil
00054fd9  664403c0                 add r8w, ax
00054fdd  498d44240e               lea rax, [r12 + 0xe]
00054fe2  483bc8                   cmp rcx, rax
00054fe5  740d                     je 0x54ff4
00054fe7  41ff4c2408               dec dword ptr [r12 + 8]
00054fec  488d4102                 lea rax, [rcx + 2]
00054ff0  33d2                     xor edx, edx
00054ff2  eb11                     jmp 0x55005
00054ff4  498b442410               mov rax, qword ptr [r12 + 0x10]
00054ff9  33d2                     xor edx, edx
00054ffb  41ff4c2408               dec dword ptr [r12 + 8]
00055000  4989542410               mov qword ptr [r12 + 0x10], rdx
00055005  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005500a  4c8b4d67                 mov r9, qword ptr [rbp + 0x67]
0005500e  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
00055012  49890424                 mov qword ptr [r12], rax
00055016  85c9                     test ecx, ecx
00055018  7424                     je 0x5503e
0005501a  0fb708                   movzx ecx, word ptr [rax]
0005501d  498b4108                 mov rax, qword ptr [r9 + 8]
00055021  8b1488                   mov edx, dword ptr [rax + rcx*4]
00055024  0fb7fa                   movzx edi, dx
00055027  48c1e720                 shl rdi, 0x20
0005502b  48c1ea10                 shr rdx, 0x10
0005502f  480bfa                   or rdi, rdx
00055032  48897db7                 mov qword ptr [rbp - 0x49], rdi
00055036  33d2                     xor edx, edx
00055038  eb04                     jmp 0x5503e
0005503a  4c8b4d67                 mov r9, qword ptr [rbp + 0x67]
0005503e  66453be8                 cmp r13w, r8w
00055042  742a                     je 0x5506e
00055044  837d9f00                 cmp dword ptr [rbp - 0x61], 0
00055048  7f07                     jg 0x55051
0005504a  4183791000               cmp dword ptr [r9 + 0x10], 0
0005504f  741d                     je 0x5506e
00055051  41ba01000000             mov r10d, 1
00055057  89559f                   mov dword ptr [rbp - 0x61], edx
0005505a  66453be8                 cmp r13w, r8w
0005505e  418bc2                   mov eax, r10d
00055061  b903000000               mov ecx, 3
00055066  0f47c1                   cmova eax, ecx
00055069  8945ab                   mov dword ptr [rbp - 0x55], eax
0005506c  eb06                     jmp 0x55074
0005506e  41ba01000000             mov r10d, 1
00055074  418b4f08                 mov ecx, dword ptr [r15 + 8]
00055078  498d470e                 lea rax, [r15 + 0xe]
0005507c  498b17                   mov rdx, qword ptr [r15]
0005507f  ffc9                     dec ecx
00055081  483bd0                   cmp rdx, rax
00055084  7406                     je 0x5508c
00055086  488d4202                 lea rax, [rdx + 2]
0005508a  eb0a                     jmp 0x55096
0005508c  498b4710                 mov rax, qword ptr [r15 + 0x10]
00055090  33d2                     xor edx, edx
00055092  49895710                 mov qword ptr [r15 + 0x10], rdx
00055096  498907                   mov qword ptr [r15], rax
00055099  41894f08                 mov dword ptr [r15 + 8], ecx
0005509d  85c9                     test ecx, ecx
0005509f  741c                     je 0x550bd
000550a1  0fb708                   movzx ecx, word ptr [rax]
000550a4  498b4108                 mov rax, qword ptr [r9 + 8]
000550a8  8b1488                   mov edx, dword ptr [rax + rcx*4]
000550ab  0fb7da                   movzx ebx, dx
000550ae  48c1e320                 shl rbx, 0x20
000550b2  48c1ea10                 shr rdx, 0x10
000550b6  480bda                   or rbx, rdx
000550b9  48895dbf                 mov qword ptr [rbp - 0x41], rbx
000550bd  4c8b6dd7                 mov r13, qword ptr [rbp - 0x29]
000550c1  458bca                   mov r9d, r10d
000550c4  448955af                 mov dword ptr [rbp - 0x51], r10d
000550c8  e904020000               jmp 0x552d1
000550cd  4c8bf3                   mov r14, rbx
000550d0  4180fd06                 cmp r13b, 6
000550d4  0f84f3010000             je 0x552cd
000550da  448b459f                 mov r8d, dword ptr [rbp - 0x61]
000550de  4183f806                 cmp r8d, 6
000550e2  7f08                     jg 0x550ec
000550e4  7525                     jne 0x5510b
000550e6  837dcf00                 cmp dword ptr [rbp - 0x31], 0
000550ea  751f                     jne 0x5510b
000550ec  4183f806                 cmp r8d, 6
000550f0  448955cf                 mov dword ptr [rbp - 0x31], r10d
000550f4  8bc2                     mov eax, edx
000550f6  c745ab03000000           mov dword ptr [rbp - 0x55], 3
000550fd  0f4e45c7                 cmovle eax, dword ptr [rbp - 0x39]
00055101  8945c7                   mov dword ptr [rbp - 0x39], eax
00055104  c7459f06000000           mov dword ptr [rbp - 0x61], 6
0005510b  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005510f  498d470e                 lea rax, [r15 + 0xe]
00055113  498b17                   mov rdx, qword ptr [r15]
00055116  ffc9                     dec ecx
00055118  483bd0                   cmp rdx, rax
0005511b  7406                     je 0x55123
0005511d  488d4202                 lea rax, [rdx + 2]
00055121  eb0a                     jmp 0x5512d
00055123  498b4710                 mov rax, qword ptr [r15 + 0x10]
00055127  33d2                     xor edx, edx
00055129  49895710                 mov qword ptr [r15 + 0x10], rdx
0005512d  498907                   mov qword ptr [r15], rax
00055130  41894f08                 mov dword ptr [r15 + 8], ecx
00055134  85c9                     test ecx, ecx
00055136  7420                     je 0x55158
00055138  0fb708                   movzx ecx, word ptr [rax]
0005513b  488b4567                 mov rax, qword ptr [rbp + 0x67]
0005513f  488b4008                 mov rax, qword ptr [rax + 8]
00055143  8b1488                   mov edx, dword ptr [rax + rcx*4]
00055146  0fb7da                   movzx ebx, dx
00055149  48c1e320                 shl rbx, 0x20
0005514d  48c1ea10                 shr rdx, 0x10
00055151  480bda                   or rbx, rdx
00055154  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055158  458bca                   mov r9d, r10d
0005515b  e96d010000               jmp 0x552cd
00055160  4180fd06                 cmp r13b, 6
00055164  0f8463010000             je 0x552cd
0005516a  4180fd01                 cmp r13b, 1
0005516e  0f8459010000             je 0x552cd
00055174  89542450                 mov dword ptr [rsp + 0x50], edx
00055178  488bc2                   mov rax, rdx
0005517b  488bcb                   mov rcx, rbx
0005517e  4c8bf2                   mov r14, rdx
00055181  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00055185  4180fd04                 cmp r13b, 4
00055189  4d8bcc                   mov r9, r12
0005518c  4d8bc7                   mov r8, r15
0005518f  480f45c6                 cmovne rax, rsi
00055193  48c1e920                 shr rcx, 0x20
00055197  488bf0                   mov rsi, rax
0005519a  66894da3                 mov word ptr [rbp - 0x5d], cx
0005519e  488bc7                   mov rax, rdi
000551a1  48c1e310                 shl rbx, 0x10
000551a5  48c1e820                 shr rax, 0x20
000551a9  0bd9                     or ebx, ecx
000551ab  488b4d5f                 mov rcx, qword ptr [rbp + 0x5f]
000551af  668945af                 mov word ptr [rbp - 0x51], ax
000551b3  48c1e710                 shl rdi, 0x10
000551b7  0bf8                     or edi, eax
000551b9  895dd7                   mov dword ptr [rbp - 0x29], ebx
000551bc  488d4503                 lea rax, [rbp + 3]
000551c0  897db7                   mov dword ptr [rbp - 0x49], edi
000551c3  4889442448               mov qword ptr [rsp + 0x48], rax
000551c8  488d45f7                 lea rax, [rbp - 9]
000551cc  4889442440               mov qword ptr [rsp + 0x40], rax
000551d1  488d45af                 lea rax, [rbp - 0x51]
000551d5  4889442438               mov qword ptr [rsp + 0x38], rax
000551da  488d45a3                 lea rax, [rbp - 0x5d]
000551de  4889442430               mov qword ptr [rsp + 0x30], rax
000551e3  488d45b7                 lea rax, [rbp - 0x49]
000551e7  4889442428               mov qword ptr [rsp + 0x28], rax
000551ec  488d45d7                 lea rax, [rbp - 0x29]
000551f0  4889442420               mov qword ptr [rsp + 0x20], rax
000551f5  e8e6c1ffff               call 0x513e0
000551fa  448bc8                   mov r9d, eax
000551fd  8945af                   mov dword ptr [rbp - 0x51], eax
00055200  8b4503                   mov eax, dword ptr [rbp + 3]
00055203  83f802                   cmp eax, 2
00055206  0f85330c0000             jne 0x55e3f
0005520c  8b45b7                   mov eax, dword ptr [rbp - 0x49]
0005520f  8b4dd7                   mov ecx, dword ptr [rbp - 0x29]
00055212  0fb7d9                   movzx ebx, cx
00055215  0fb7f8                   movzx edi, ax
00055218  48c1e320                 shl rbx, 0x20
0005521c  48c1e720                 shl rdi, 0x20
00055220  48c1e910                 shr rcx, 0x10
00055224  48c1e810                 shr rax, 0x10
00055228  480bd9                   or rbx, rcx
0005522b  480bf8                   or rdi, rax
0005522e  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055232  48897db7                 mov qword ptr [rbp - 0x49], rdi
00055236  4585c9                   test r9d, r9d
00055239  744e                     je 0x55289
0005523b  41837f0800               cmp dword ptr [r15 + 8], 0
00055240  7447                     je 0x55289
00055242  41837c240800             cmp dword ptr [r12 + 8], 0
00055248  743f                     je 0x55289
0005524a  488b4567                 mov rax, qword ptr [rbp + 0x67]
0005524e  488b5008                 mov rdx, qword ptr [rax + 8]
00055252  498b07                   mov rax, qword ptr [r15]
00055255  0fb708                   movzx ecx, word ptr [rax]
00055258  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005525b  0fb7d8                   movzx ebx, ax
0005525e  48c1e810                 shr rax, 0x10
00055262  48c1e320                 shl rbx, 0x20
00055266  480bd8                   or rbx, rax
00055269  498b0424                 mov rax, qword ptr [r12]
0005526d  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055271  0fb708                   movzx ecx, word ptr [rax]
00055274  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00055277  0fb7f8                   movzx edi, ax
0005527a  48c1e720                 shl rdi, 0x20
0005527e  48c1e810                 shr rax, 0x10
00055282  480bf8                   or rdi, rax
00055285  48897db7                 mov qword ptr [rbp - 0x49], rdi
00055289  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
0005528d  41ba01000000             mov r10d, 1
00055293  eb3c                     jmp 0x552d1
00055295  488bc3                   mov rax, rbx
00055298  44894daf                 mov dword ptr [rbp - 0x51], r9d
0005529c  48c1e820                 shr rax, 0x20
000552a0  48ba02020000fffd0000     movabs rdx, 0xfdff00000202
000552aa  0fb6c8                   movzx ecx, al
000552ad  0fb6c3                   movzx eax, bl
000552b0  48c1e108                 shl rcx, 8
000552b4  488bd9                   mov rbx, rcx
000552b7  480bd8                   or rbx, rax
000552ba  48c1e310                 shl rbx, 0x10
000552be  480bda                   or rbx, rdx
000552c1  48895dbf                 mov qword ptr [rbp - 0x41], rbx
000552c5  4c8bf3                   mov r14, rbx
000552c8  eb11                     jmp 0x552db
000552ca  4c8bf3                   mov r14, rbx
000552cd  44894daf                 mov dword ptr [rbp - 0x51], r9d
000552d1  48ba02020000fffd0000     movabs rdx, 0xfdff00000202
000552db  410fb6c5                 movzx eax, r13b
000552df  83f806                   cmp eax, 6
000552e2  0f875b030000             ja 0x55643
000552e8  4c8d0511adfaff           lea r8, [rip - 0x552ef]
000552ef  418b8c80705e0500         mov ecx, dword ptr [r8 + rax*4 + 0x55e70]
000552f7  4903c8                   add rcx, r8
000552fa  ffe1                     jmp rcx
000552fc  453add                   cmp r11b, r13b
000552ff  0f8441030000             je 0x55646
00055305  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
00055309  4d8bc4                   mov r8, r12
0005530c  498bd5                   mov rdx, r13
0005530f  e87c120000               call 0x56590
00055314  440fb7c0                 movzx r8d, ax
00055318  400fb6c7                 movzx eax, dil
0005531c  4403c0                   add r8d, eax
0005531f  837d9f00                 cmp dword ptr [rbp - 0x61], 0
00055323  7f07                     jg 0x5532c
00055325  41837d1000               cmp dword ptr [r13 + 0x10], 0
0005532a  7418                     je 0x55344
0005532c  41ba01000000             mov r10d, 1
00055332  4585c0                   test r8d, r8d
00055335  7413                     je 0x5534a
00055337  4533c0                   xor r8d, r8d
0005533a  448955ab                 mov dword ptr [rbp - 0x55], r10d
0005533e  4489459f                 mov dword ptr [rbp - 0x61], r8d
00055342  eb09                     jmp 0x5534d
00055344  41ba01000000             mov r10d, 1
0005534a  4533c0                   xor r8d, r8d
0005534d  418b4c2408               mov ecx, dword ptr [r12 + 8]
00055352  498d44240e               lea rax, [r12 + 0xe]
00055357  498b1424                 mov rdx, qword ptr [r12]
0005535b  ffc9                     dec ecx
0005535d  483bd0                   cmp rdx, rax
00055360  7406                     je 0x55368
00055362  488d4202                 lea rax, [rdx + 2]
00055366  eb0a                     jmp 0x55372
00055368  498b442410               mov rax, qword ptr [r12 + 0x10]
0005536d  4d89442410               mov qword ptr [r12 + 0x10], r8
00055372  49890424                 mov qword ptr [r12], rax
00055376  41894c2408               mov dword ptr [r12 + 8], ecx
0005537b  85c9                     test ecx, ecx
0005537d  741c                     je 0x5539b
0005537f  0fb708                   movzx ecx, word ptr [rax]
00055382  498b4508                 mov rax, qword ptr [r13 + 8]
00055386  8b1488                   mov edx, dword ptr [rax + rcx*4]
00055389  0fb7fa                   movzx edi, dx
0005538c  48c1e720                 shl rdi, 0x20
00055390  48c1ea10                 shr rdx, 0x10
00055394  480bfa                   or rdi, rdx
00055397  48897db7                 mov qword ptr [rbp - 0x49], rdi
0005539b  458bca                   mov r9d, r10d
0005539e  e9a8020000               jmp 0x5564b
000553a3  488bf7                   mov rsi, rdi
000553a6  4180fb06                 cmp r11b, 6
000553aa  743f                     je 0x553eb
000553ac  448b459f                 mov r8d, dword ptr [rbp - 0x61]
000553b0  4183f806                 cmp r8d, 6
000553b4  7f10                     jg 0x553c6
000553b6  0f85fc000000             jne 0x554b8
000553bc  837dc700                 cmp dword ptr [rbp - 0x39], 0
000553c0  0f85f2000000             jne 0x554b8
000553c6  4533db                   xor r11d, r11d
000553c9  448955c7                 mov dword ptr [rbp - 0x39], r10d
000553cd  4183f806                 cmp r8d, 6
000553d1  448955ab                 mov dword ptr [rbp - 0x55], r10d
000553d5  418bc3                   mov eax, r11d
000553d8  c7459f06000000           mov dword ptr [rbp - 0x61], 6
000553df  0f4e45cf                 cmovle eax, dword ptr [rbp - 0x31]
000553e3  8945cf                   mov dword ptr [rbp - 0x31], eax
000553e6  e9d0000000               jmp 0x554bb
000553eb  837d9f06                 cmp dword ptr [rbp - 0x61], 6
000553ef  7f23                     jg 0x55414
000553f1  7575                     jne 0x55468
000553f3  837dcf00                 cmp dword ptr [rbp - 0x31], 0
000553f7  740c                     je 0x55405
000553f9  837dc700                 cmp dword ptr [rbp - 0x39], 0
000553fd  7569                     jne 0x55468
000553ff  448955ab                 mov dword ptr [rbp - 0x55], r10d
00055403  eb54                     jmp 0x55459
00055405  837dc700                 cmp dword ptr [rbp - 0x39], 0
00055409  7409                     je 0x55414
0005540b  c745ab03000000           mov dword ptr [rbp - 0x55], 3
00055412  eb45                     jmp 0x55459
00055414  488bc3                   mov rax, rbx
00055417  488bcf                   mov rcx, rdi
0005541a  48c1e820                 shr rax, 0x20
0005541e  48c1e920                 shr rcx, 0x20
00055422  3ac1                     cmp al, cl
00055424  7527                     jne 0x5544d
00055426  488bc3                   mov rax, rbx
00055429  488bcf                   mov rcx, rdi
0005542c  48c1e808                 shr rax, 8
00055430  48c1e908                 shr rcx, 8
00055434  3ac1                     cmp al, cl
00055436  7306                     jae 0x5543e
00055438  448955ab                 mov dword ptr [rbp - 0x55], r10d
0005543c  eb1b                     jmp 0x55459
0005543e  0f8602020000             jbe 0x55646
00055444  c745ab03000000           mov dword ptr [rbp - 0x55], 3
0005544b  eb0c                     jmp 0x55459
0005544d  ba03000000               mov edx, 3
00055452  410f42d2                 cmovb edx, r10d
00055456  8955ab                   mov dword ptr [rbp - 0x55], edx
00055459  448955c7                 mov dword ptr [rbp - 0x39], r10d
0005545d  448955cf                 mov dword ptr [rbp - 0x31], r10d
00055461  c7459f06000000           mov dword ptr [rbp - 0x61], 6
00055468  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005546c  498d470e                 lea rax, [r15 + 0xe]
00055470  498b17                   mov rdx, qword ptr [r15]
00055473  ffc9                     dec ecx
00055475  4533db                   xor r11d, r11d
00055478  483bd0                   cmp rdx, rax
0005547b  7406                     je 0x55483
0005547d  488d4202                 lea rax, [rdx + 2]
00055481  eb08                     jmp 0x5548b
00055483  498b4710                 mov rax, qword ptr [r15 + 0x10]
00055487  4d895f10                 mov qword ptr [r15 + 0x10], r11
0005548b  498907                   mov qword ptr [r15], rax
0005548e  41894f08                 mov dword ptr [r15 + 8], ecx
00055492  85c9                     test ecx, ecx
00055494  7425                     je 0x554bb
00055496  0fb708                   movzx ecx, word ptr [rax]
00055499  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005549d  498b4008                 mov rax, qword ptr [r8 + 8]
000554a1  8b1488                   mov edx, dword ptr [rax + rcx*4]
000554a4  0fb7da                   movzx ebx, dx
000554a7  48c1e320                 shl rbx, 0x20
000554ab  48c1ea10                 shr rdx, 0x10
000554af  480bda                   or rbx, rdx
000554b2  48895dbf                 mov qword ptr [rbp - 0x41], rbx
000554b6  eb07                     jmp 0x554bf
000554b8  4533db                   xor r11d, r11d
000554bb  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
000554bf  418b4c2408               mov ecx, dword ptr [r12 + 8]
000554c4  498d44240e               lea rax, [r12 + 0xe]
000554c9  498b1424                 mov rdx, qword ptr [r12]
000554cd  ffc9                     dec ecx
000554cf  483bd0                   cmp rdx, rax
000554d2  7406                     je 0x554da
000554d4  488d4202                 lea rax, [rdx + 2]
000554d8  eb0a                     jmp 0x554e4
000554da  498b442410               mov rax, qword ptr [r12 + 0x10]
000554df  4d895c2410               mov qword ptr [r12 + 0x10], r11
000554e4  49890424                 mov qword ptr [r12], rax
000554e8  41894c2408               mov dword ptr [r12 + 8], ecx
000554ed  85c9                     test ecx, ecx
000554ef  0f84a6feffff             je 0x5539b
000554f5  0fb708                   movzx ecx, word ptr [rax]
000554f8  498b4008                 mov rax, qword ptr [r8 + 8]
000554fc  e985feffff               jmp 0x55386
00055501  4585c9                   test r9d, r9d
00055504  0f8541010000             jne 0x5564b
0005550a  33d2                     xor edx, edx
0005550c  8bf2                     mov esi, edx
0005550e  4180fb04                 cmp r11b, 4
00055512  0f845c030000             je 0x55874
00055518  89542450                 mov dword ptr [rsp + 0x50], edx
0005551c  488bc7                   mov rax, rdi
0005551f  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00055523  488bcb                   mov rcx, rbx
00055526  48c1e820                 shr rax, 0x20
0005552a  4d8bcc                   mov r9, r12
0005552d  668945a3                 mov word ptr [rbp - 0x5d], ax
00055531  4d8bc7                   mov r8, r15
00055534  48c1e920                 shr rcx, 0x20
00055538  66894daf                 mov word ptr [rbp - 0x51], cx
0005553c  48c1e710                 shl rdi, 0x10
00055540  0bf8                     or edi, eax
00055542  48c1e310                 shl rbx, 0x10
00055546  0bd9                     or ebx, ecx
00055548  897dd7                   mov dword ptr [rbp - 0x29], edi
0005554b  488b4d5f                 mov rcx, qword ptr [rbp + 0x5f]
0005554f  488d4507                 lea rax, [rbp + 7]
00055553  4889442448               mov qword ptr [rsp + 0x48], rax
00055558  488d45f7                 lea rax, [rbp - 9]
0005555c  4889442440               mov qword ptr [rsp + 0x40], rax
00055561  488d45a3                 lea rax, [rbp - 0x5d]
00055565  4889442438               mov qword ptr [rsp + 0x38], rax
0005556a  488d45af                 lea rax, [rbp - 0x51]
0005556e  4889442430               mov qword ptr [rsp + 0x30], rax
00055573  488d45d7                 lea rax, [rbp - 0x29]
00055577  4889442428               mov qword ptr [rsp + 0x28], rax
0005557c  488d45b7                 lea rax, [rbp - 0x49]
00055580  4889442420               mov qword ptr [rsp + 0x20], rax
00055585  895db7                   mov dword ptr [rbp - 0x49], ebx
00055588  e853beffff               call 0x513e0
0005558d  448bc8                   mov r9d, eax
00055590  8945af                   mov dword ptr [rbp - 0x51], eax
00055593  8b4507                   mov eax, dword ptr [rbp + 7]
00055596  83f802                   cmp eax, 2
00055599  0f85a0080000             jne 0x55e3f
0005559f  8b45b7                   mov eax, dword ptr [rbp - 0x49]
000555a2  0fb7d8                   movzx ebx, ax
000555a5  48c1e810                 shr rax, 0x10
000555a9  48c1e320                 shl rbx, 0x20
000555ad  480bd8                   or rbx, rax
000555b0  8b45d7                   mov eax, dword ptr [rbp - 0x29]
000555b3  0fb7f8                   movzx edi, ax
000555b6  48c1e720                 shl rdi, 0x20
000555ba  48c1e810                 shr rax, 0x10
000555be  480bf8                   or rdi, rax
000555c1  48895dbf                 mov qword ptr [rbp - 0x41], rbx
000555c5  48897db7                 mov qword ptr [rbp - 0x49], rdi
000555c9  4585c9                   test r9d, r9d
000555cc  0f849d000000             je 0x5566f
000555d2  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
000555d6  41397708                 cmp dword ptr [r15 + 8], esi
000555da  7473                     je 0x5564f
000555dc  4139742408               cmp dword ptr [r12 + 8], esi
000555e1  746c                     je 0x5564f
000555e3  498b07                   mov rax, qword ptr [r15]
000555e6  498b5308                 mov rdx, qword ptr [r11 + 8]
000555ea  0fb708                   movzx ecx, word ptr [rax]
000555ed  8b048a                   mov eax, dword ptr [rdx + rcx*4]
000555f0  0fb7d8                   movzx ebx, ax
000555f3  48c1e810                 shr rax, 0x10
000555f7  48c1e320                 shl rbx, 0x20
000555fb  480bd8                   or rbx, rax
000555fe  498b0424                 mov rax, qword ptr [r12]
00055602  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055606  0fb708                   movzx ecx, word ptr [rax]
00055609  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005560c  0fb7f8                   movzx edi, ax
0005560f  48c1e720                 shl rdi, 0x20
00055613  48c1e810                 shr rax, 0x10
00055617  480bf8                   or rdi, rax
0005561a  48897db7                 mov qword ptr [rbp - 0x49], rdi
0005561e  eb2f                     jmp 0x5564f
00055620  488bc7                   mov rax, rdi
00055623  48c1e820                 shr rax, 0x20
00055627  0fb6c8                   movzx ecx, al
0005562a  400fb6c7                 movzx eax, dil
0005562e  48c1e108                 shl rcx, 8
00055632  488bf9                   mov rdi, rcx
00055635  480bf8                   or rdi, rax
00055638  48c1e710                 shl rdi, 0x10
0005563c  480bfa                   or rdi, rdx
0005563f  48897db7                 mov qword ptr [rbp - 0x49], rdi
00055643  488bf7                   mov rsi, rdi
00055646  4585c9                   test r9d, r9d
00055649  7428                     je 0x55673
0005564b  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
0005564f  418b4708                 mov eax, dword ptr [r15 + 8]
00055653  85c0                     test eax, eax
00055655  0f84b7060000             je 0x55d12
0005565b  41837c240800             cmp dword ptr [r12 + 8], 0
00055661  0f84ab060000             je 0x55d12
00055667  4533ed                   xor r13d, r13d
0005566a  e9f1f3ffff               jmp 0x54a60
0005566f  4c8b5def                 mov r11, qword ptr [rbp - 0x11]
00055673  4180fb03                 cmp r11b, 3
00055677  0f85f7010000             jne 0x55874
0005567d  33c0                     xor eax, eax
0005567f  4c8bc3                   mov r8, rbx
00055682  49c1e820                 shr r8, 0x20
00055686  8945a3                   mov dword ptr [rbp - 0x5d], eax
00055689  4180f801                 cmp r8b, 1
0005568d  0f87ce000000             ja 0x55761
00055693  498bd6                   mov rdx, r14
00055696  48c1ea28                 shr rdx, 0x28
0005569a  413ad3                   cmp dl, r11b
0005569d  7730                     ja 0x556cf
0005569f  440fb64da5               movzx r9d, byte ptr [rbp - 0x5b]
000556a4  48b800000000ffff0000     movabs rax, 0xffff00000000
000556ae  440fb655a3               movzx r10d, byte ptr [rbp - 0x5d]
000556b3  488bd8                   mov rbx, rax
000556b6  0fb655a6                 movzx edx, byte ptr [rbp - 0x5a]
000556ba  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
000556be  488945bf                 mov qword ptr [rbp - 0x41], rax
000556c2  44884da8                 mov byte ptr [rbp - 0x58], r9b
000556c6  448855a7                 mov byte ptr [rbp - 0x59], r10b
000556ca  e9e5000000               jmp 0x557b4
000556cf  498bce                   mov rcx, r14
000556d2  48c1e910                 shr rcx, 0x10
000556d6  8bc9                     mov ecx, ecx
000556d8  80fa22                   cmp dl, 0x22
000556db  755e                     jne 0x5573b
000556dd  498bd6                   mov rdx, r14
000556e0  48c1ea08                 shr rdx, 8
000556e4  440fb6d2                 movzx r10d, dl
000556e8  440fb6ca                 movzx r9d, dl
000556ec  4180e2c6                 and r10b, 0xc6
000556f0  4180e1e4                 and r9b, 0xe4
000556f4  448855a7                 mov byte ptr [rbp - 0x59], r10b
000556f8  44884da8                 mov byte ptr [rbp - 0x58], r9b
000556fc  4584c0                   test r8b, r8b
000556ff  7517                     jne 0x55718
00055701  48c1e110                 shl rcx, 0x10
00055705  0fb7c3                   movzx eax, bx
00055708  488bd9                   mov rbx, rcx
0005570b  480bd8                   or rbx, rax
0005570e  b104                     mov cl, 4
00055710  80e2c5                   and dl, 0xc5
00055713  e98c000000               jmp 0x557a4
00055718  b8000087ff               mov eax, 0xff870000
0005571d  4823c8                   and rcx, rax
00055720  0fb7c3                   movzx eax, bx
00055723  48c1e110                 shl rcx, 0x10
00055727  488bd9                   mov rbx, rcx
0005572a  b105                     mov cl, 5
0005572c  480bd8                   or rbx, rax
0005572f  488bd3                   mov rdx, rbx
00055732  48c1ea08                 shr rdx, 8
00055736  80e2c5                   and dl, 0xc5
00055739  eb69                     jmp 0x557a4
0005573b  0fb655a6                 movzx edx, byte ptr [rbp - 0x5a]
0005573f  440fb64da5               movzx r9d, byte ptr [rbp - 0x5b]
00055744  440fb655a3               movzx r10d, byte ptr [rbp - 0x5d]
00055749  48c1e110                 shl rcx, 0x10
0005574d  0fb6c3                   movzx eax, bl
00055750  488bd9                   mov rbx, rcx
00055753  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
00055757  480bd8                   or rbx, rax
0005575a  480fbaeb09               bts rbx, 9
0005575f  eb3b                     jmp 0x5579c
00055761  48b8ffffffffff22ffff     movabs rax, 0xffff22ffffffffff
0005576b  b103                     mov cl, 3
0005576d  4823d8                   and rbx, rax
00055770  48b80000000000220000     movabs rax, 0x220000000000
0005577a  480bd8                   or rbx, rax
0005577d  488bc3                   mov rax, rbx
00055780  4c8bf3                   mov r14, rbx
00055783  48c1e808                 shr rax, 8
00055787  440fb6d0                 movzx r10d, al
0005578b  440fb6c8                 movzx r9d, al
0005578f  4180e2c6                 and r10b, 0xc6
00055793  4180e1e4                 and r9b, 0xe4
00055797  24c5                     and al, 0xc5
00055799  0fb6d0                   movzx edx, al
0005579c  44884da8                 mov byte ptr [rbp - 0x58], r9b
000557a0  448855a7                 mov byte ptr [rbp - 0x59], r10b
000557a4  4881e3ff02ffff           and rbx, 0xffffffffffff02ff
000557ab  480fbaeb09               bts rbx, 9
000557b0  48895dbf                 mov qword ptr [rbp - 0x41], rbx
000557b4  8b459f                   mov eax, dword ptr [rbp - 0x61]
000557b7  884d77                   mov byte ptr [rbp + 0x77], cl
000557ba  488955e7                 mov qword ptr [rbp - 0x19], rdx
000557be  83f802                   cmp eax, 2
000557c1  0f8ead000000             jle 0x55874
000557c7  4180fd03                 cmp r13b, 3
000557cb  0f84ad000000             je 0x5587e
000557d1  4584d2                   test r10b, r10b
000557d4  7417                     je 0x557ed
000557d6  b803000000               mov eax, 3
000557db  41ba02000000             mov r10d, 2
000557e1  8945ab                   mov dword ptr [rbp - 0x55], eax
000557e4  4489559f                 mov dword ptr [rbp - 0x61], r10d
000557e8  e96af3ffff               jmp 0x54b57
000557ed  83f803                   cmp eax, 3
000557f0  0f8e56030000             jle 0x55b4c
000557f6  84c9                     test cl, cl
000557f8  7413                     je 0x5580d
000557fa  b803000000               mov eax, 3
000557ff  8945ab                   mov dword ptr [rbp - 0x55], eax
00055802  448bd0                   mov r10d, eax
00055805  89459f                   mov dword ptr [rbp - 0x61], eax
00055808  e94af3ffff               jmp 0x54b57
0005580d  83f804                   cmp eax, 4
00055810  0f8e36030000             jle 0x55b4c
00055816  837ddf00                 cmp dword ptr [rbp - 0x21], 0
0005581a  0f852c030000             jne 0x55b4c
00055820  4584c9                   test r9b, r9b
00055823  7417                     je 0x5583c
00055825  b803000000               mov eax, 3
0005582a  41ba04000000             mov r10d, 4
00055830  8945ab                   mov dword ptr [rbp - 0x55], eax
00055833  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055837  e91bf3ffff               jmp 0x54b57
0005583c  83f805                   cmp eax, 5
0005583f  0f8e07030000             jle 0x55b4c
00055845  837dd300                 cmp dword ptr [rbp - 0x2d], 0
00055849  0f85fd020000             jne 0x55b4c
0005584f  41b901000000             mov r9d, 1
00055855  84d2                     test dl, dl
00055857  0f84f7020000             je 0x55b54
0005585d  b803000000               mov eax, 3
00055862  41ba05000000             mov r10d, 5
00055868  8945ab                   mov dword ptr [rbp - 0x55], eax
0005586b  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005586f  e9e9f2ffff               jmp 0x54b5d
00055874  4180fd03                 cmp r13b, 3
00055878  0f85d0f2ffff             jne 0x54b4e
0005587e  33c0                     xor eax, eax
00055880  4c8bd7                   mov r10, rdi
00055883  49c1ea20                 shr r10, 0x20
00055887  8945a3                   mov dword ptr [rbp - 0x5d], eax
0005588a  4180fa01                 cmp r10b, 1
0005588e  0f87c0000000             ja 0x55954
00055894  488bd6                   mov rdx, rsi
00055897  48c1ea28                 shr rdx, 0x28
0005589b  80fa03                   cmp dl, 3
0005589e  7728                     ja 0x558c8
000558a0  440fb645a6               movzx r8d, byte ptr [rbp - 0x5a]
000558a5  48b800000000ffff0000     movabs rax, 0xffff00000000
000558af  440fb64da5               movzx r9d, byte ptr [rbp - 0x5b]
000558b4  488bf8                   mov rdi, rax
000558b7  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
000558bb  0fb655a3                 movzx edx, byte ptr [rbp - 0x5d]
000558bf  488945b7                 mov qword ptr [rbp - 0x49], rax
000558c3  e9d6000000               jmp 0x5599e
000558c8  488bce                   mov rcx, rsi
000558cb  48c1e910                 shr rcx, 0x10
000558cf  8bc9                     mov ecx, ecx
000558d1  80fa22                   cmp dl, 0x22
000558d4  7557                     jne 0x5592d
000558d6  4c8bc6                   mov r8, rsi
000558d9  49c1e808                 shr r8, 8
000558dd  410fb6d0                 movzx edx, r8b
000558e1  450fb6c8                 movzx r9d, r8b
000558e5  80e2c6                   and dl, 0xc6
000558e8  4180e1e4                 and r9b, 0xe4
000558ec  4584d2                   test r10b, r10b
000558ef  7518                     jne 0x55909
000558f1  48c1e110                 shl rcx, 0x10
000558f5  0fb7c7                   movzx eax, di
000558f8  488bf9                   mov rdi, rcx
000558fb  480bf8                   or rdi, rax
000558fe  b104                     mov cl, 4
00055900  4180e0c5                 and r8b, 0xc5
00055904  e985000000               jmp 0x5598e
00055909  b8000087ff               mov eax, 0xff870000
0005590e  4823c8                   and rcx, rax
00055911  0fb7c7                   movzx eax, di
00055914  48c1e110                 shl rcx, 0x10
00055918  488bf9                   mov rdi, rcx
0005591b  b105                     mov cl, 5
0005591d  480bf8                   or rdi, rax
00055920  4c8bc7                   mov r8, rdi
00055923  49c1e808                 shr r8, 8
00055927  4180e0c5                 and r8b, 0xc5
0005592b  eb61                     jmp 0x5598e
0005592d  440fb645a6               movzx r8d, byte ptr [rbp - 0x5a]
00055932  440fb64da5               movzx r9d, byte ptr [rbp - 0x5b]
00055937  0fb655a3                 movzx edx, byte ptr [rbp - 0x5d]
0005593b  48c1e110                 shl rcx, 0x10
0005593f  400fb6c7                 movzx eax, dil
00055943  488bf9                   mov rdi, rcx
00055946  0fb64da4                 movzx ecx, byte ptr [rbp - 0x5c]
0005594a  480bf8                   or rdi, rax
0005594d  480fbaef09               bts rdi, 9
00055952  eb3a                     jmp 0x5598e
00055954  48b8ffffffffff22ffff     movabs rax, 0xffff22ffffffffff
0005595e  b103                     mov cl, 3
00055960  4823f8                   and rdi, rax
00055963  48b80000000000220000     movabs rax, 0x220000000000
0005596d  480bf8                   or rdi, rax
00055970  488bc7                   mov rax, rdi
00055973  488bf7                   mov rsi, rdi
00055976  48c1e808                 shr rax, 8
0005597a  0fb6d0                   movzx edx, al
0005597d  440fb6c8                 movzx r9d, al
00055981  80e2c6                   and dl, 0xc6
00055984  4180e1e4                 and r9b, 0xe4
00055988  24c5                     and al, 0xc5
0005598a  440fb6c0                 movzx r8d, al
0005598e  4881e7ff02ffff           and rdi, 0xffffffffffff02ff
00055995  480fbaef09               bts rdi, 9
0005599a  48897db7                 mov qword ptr [rbp - 0x49], rdi
0005599e  448b559f                 mov r10d, dword ptr [rbp - 0x61]
000559a2  4183fa02                 cmp r10d, 2
000559a6  0f8ea6f1ffff             jle 0x54b52
000559ac  4180fb03                 cmp r11b, 3
000559b0  0f84b5000000             je 0x55a6b
000559b6  84d2                     test dl, dl
000559b8  741d                     je 0x559d7
000559ba  41b901000000             mov r9d, 1
000559c0  41ba02000000             mov r10d, 2
000559c6  44894dab                 mov dword ptr [rbp - 0x55], r9d
000559ca  4489559f                 mov dword ptr [rbp - 0x61], r10d
000559ce  418d4102                 lea eax, [r9 + 2]
000559d2  e986f1ffff               jmp 0x54b5d
000559d7  4183fa03                 cmp r10d, 3
000559db  0f8e71f1ffff             jle 0x54b52
000559e1  84c9                     test cl, cl
000559e3  741a                     je 0x559ff
000559e5  b803000000               mov eax, 3
000559ea  41b901000000             mov r9d, 1
000559f0  44894dab                 mov dword ptr [rbp - 0x55], r9d
000559f4  448bd0                   mov r10d, eax
000559f7  89459f                   mov dword ptr [rbp - 0x61], eax
000559fa  e95ef1ffff               jmp 0x54b5d
000559ff  4183fa04                 cmp r10d, 4
00055a03  0f8e49f1ffff             jle 0x54b52
00055a09  4584c9                   test r9b, r9b
00055a0c  7423                     je 0x55a31
00055a0e  837ddf00                 cmp dword ptr [rbp - 0x21], 0
00055a12  751d                     jne 0x55a31
00055a14  41b901000000             mov r9d, 1
00055a1a  41ba04000000             mov r10d, 4
00055a20  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055a24  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055a28  418d4102                 lea eax, [r9 + 2]
00055a2c  e92cf1ffff               jmp 0x54b5d
00055a31  41b901000000             mov r9d, 1
00055a37  418d4102                 lea eax, [r9 + 2]
00055a3b  4183fa05                 cmp r10d, 5
00055a3f  0f8e18f1ffff             jle 0x54b5d
00055a45  4584c0                   test r8b, r8b
00055a48  0f840ff1ffff             je 0x54b5d
00055a4e  837dd300                 cmp dword ptr [rbp - 0x2d], 0
00055a52  0f8505f1ffff             jne 0x54b5d
00055a58  41ba05000000             mov r10d, 5
00055a5e  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055a62  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055a66  e9f2f0ffff               jmp 0x54b5d
00055a6b  3855a7                   cmp byte ptr [rbp - 0x59], dl
00055a6e  7425                     je 0x55a95
00055a70  b803000000               mov eax, 3
00055a75  41b901000000             mov r9d, 1
00055a7b  448bd8                   mov r11d, eax
00055a7e  41ba02000000             mov r10d, 2
00055a84  450f42d9                 cmovb r11d, r9d
00055a88  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055a8c  44895dab                 mov dword ptr [rbp - 0x55], r11d
00055a90  e9c8f0ffff               jmp 0x54b5d
00055a95  4183fa03                 cmp r10d, 3
00055a99  0f8eb3f0ffff             jle 0x54b52
00055a9f  384d77                   cmp byte ptr [rbp + 0x77], cl
00055aa2  7421                     je 0x55ac5
00055aa4  b803000000               mov eax, 3
00055aa9  41b901000000             mov r9d, 1
00055aaf  448bd8                   mov r11d, eax
00055ab2  89459f                   mov dword ptr [rbp - 0x61], eax
00055ab5  450f42d9                 cmovb r11d, r9d
00055ab9  448bd0                   mov r10d, eax
00055abc  44895dab                 mov dword ptr [rbp - 0x55], r11d
00055ac0  e998f0ffff               jmp 0x54b5d
00055ac5  4183fa04                 cmp r10d, 4
00055ac9  0f8e83f0ffff             jle 0x54b52
00055acf  0fb64da8                 movzx ecx, byte ptr [rbp - 0x58]
00055ad3  413ac9                   cmp cl, r9b
00055ad6  742e                     je 0x55b06
00055ad8  837ddf00                 cmp dword ptr [rbp - 0x21], 0
00055adc  7528                     jne 0x55b06
00055ade  413ac9                   cmp cl, r9b
00055ae1  b803000000               mov eax, 3
00055ae6  448bd8                   mov r11d, eax
00055ae9  41b901000000             mov r9d, 1
00055aef  450f42d9                 cmovb r11d, r9d
00055af3  41ba04000000             mov r10d, 4
00055af9  44895dab                 mov dword ptr [rbp - 0x55], r11d
00055afd  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055b01  e957f0ffff               jmp 0x54b5d
00055b06  4183fa05                 cmp r10d, 5
00055b0a  0f8e42f0ffff             jle 0x54b52
00055b10  488b45e7                 mov rax, qword ptr [rbp - 0x19]
00055b14  413ac0                   cmp al, r8b
00055b17  0f8435f0ffff             je 0x54b52
00055b1d  837dd300                 cmp dword ptr [rbp - 0x2d], 0
00055b21  0f852bf0ffff             jne 0x54b52
00055b27  413ac0                   cmp al, r8b
00055b2a  41b903000000             mov r9d, 3
00055b30  b801000000               mov eax, 1
00055b35  41ba05000000             mov r10d, 5
00055b3b  440f42c8                 cmovb r9d, eax
00055b3f  4489559f                 mov dword ptr [rbp - 0x61], r10d
00055b43  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055b47  e906f0ffff               jmp 0x54b52
00055b4c  448bd0                   mov r10d, eax
00055b4f  e9feefffff               jmp 0x54b52
00055b54  448bd0                   mov r10d, eax
00055b57  b803000000               mov eax, 3
00055b5c  e9fcefffff               jmp 0x54b5d
00055b61  837dff00                 cmp dword ptr [rbp - 1], 0
00055b65  7406                     je 0x55b6d
00055b67  4180fd14                 cmp r13b, 0x14
00055b6b  765e                     jbe 0x55bcb
00055b6d  4585d2                   test r10d, r10d
00055b70  7f07                     jg 0x55b79
00055b72  41837b1000               cmp dword ptr [r11 + 0x10], 0
00055b77  7452                     je 0x55bcb
00055b79  4d8bc7                   mov r8, r15
00055b7c  498bd3                   mov rdx, r11
00055b7f  e80c0a0000               call 0x56590
00055b84  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00055b88  4d8bc4                   mov r8, r12
00055b8b  0fb6cb                   movzx ecx, bl
00055b8e  6603c1                   add ax, cx
00055b91  668945a3                 mov word ptr [rbp - 0x5d], ax
00055b95  e8f6090000               call 0x56590
00055b9a  400fb6cf                 movzx ecx, dil
00055b9e  41b801000000             mov r8d, 1
00055ba4  6603c1                   add ax, cx
00055ba7  663945a3                 cmp word ptr [rbp - 0x5d], ax
00055bab  7418                     je 0x55bc5
00055bad  41b903000000             mov r9d, 3
00055bb3  450f42c8                 cmovb r9d, r8d
00055bb7  33c0                     xor eax, eax
00055bb9  448bd0                   mov r10d, eax
00055bbc  89459f                   mov dword ptr [rbp - 0x61], eax
00055bbf  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055bc3  eb0c                     jmp 0x55bd1
00055bc5  448b559f                 mov r10d, dword ptr [rbp - 0x61]
00055bc9  eb06                     jmp 0x55bd1
00055bcb  41b801000000             mov r8d, 1
00055bd1  837dd300                 cmp dword ptr [rbp - 0x2d], 0
00055bd5  740c                     je 0x55be3
00055bd7  837d0b00                 cmp dword ptr [rbp + 0xb], 0
00055bdb  7406                     je 0x55be3
00055bdd  4180fd14                 cmp r13b, 0x14
00055be1  7646                     jbe 0x55c29
00055be3  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00055be7  4183fa01                 cmp r10d, 1
00055beb  7e40                     jle 0x55c2d
00055bed  0fb645cc                 movzx eax, byte ptr [rbp - 0x34]
00055bf1  4180fd14                 cmp r13b, 0x14
00055bf5  0fb64dcb                 movzx ecx, byte ptr [rbp - 0x35]
00055bf9  488bd7                   mov rdx, rdi
00055bfc  0f46c8                   cmovbe ecx, eax
00055bff  48c1ea08                 shr rdx, 8
00055c03  488bc3                   mov rax, rbx
00055c06  22d1                     and dl, cl
00055c08  48c1e808                 shr rax, 8
00055c0c  22c1                     and al, cl
00055c0e  3ac2                     cmp al, dl
00055c10  741b                     je 0x55c2d
00055c12  41b903000000             mov r9d, 3
00055c18  4489459f                 mov dword ptr [rbp - 0x61], r8d
00055c1c  450f42c8                 cmovb r9d, r8d
00055c20  458bd0                   mov r10d, r8d
00055c23  44894dab                 mov dword ptr [rbp - 0x55], r9d
00055c27  eb04                     jmp 0x55c2d
00055c29  4c8b5d67                 mov r11, qword ptr [rbp + 0x67]
00055c2d  4d8b4710                 mov r8, qword ptr [r15 + 0x10]
00055c31  418b4708                 mov eax, dword ptr [r15 + 8]
00055c35  4d85c0                   test r8, r8
00055c38  750f                     jne 0x55c49
00055c3a  49830702                 add qword ptr [r15], 2
00055c3e  ffc8                     dec eax
00055c40  41894708                 mov dword ptr [r15 + 8], eax
00055c44  4533ed                   xor r13d, r13d
00055c47  eb28                     jmp 0x55c71
00055c49  498b17                   mov rdx, qword ptr [r15]
00055c4c  498d4f0e                 lea rcx, [r15 + 0xe]
00055c50  4533ed                   xor r13d, r13d
00055c53  ffc8                     dec eax
00055c55  458bf5                   mov r14d, r13d
00055c58  41894708                 mov dword ptr [r15 + 8], eax
00055c5c  483bd1                   cmp rdx, rcx
00055c5f  7409                     je 0x55c6a
00055c61  488d4202                 lea rax, [rdx + 2]
00055c65  498907                   mov qword ptr [r15], rax
00055c68  eb07                     jmp 0x55c71
00055c6a  4d8907                   mov qword ptr [r15], r8
00055c6d  4d896f10                 mov qword ptr [r15 + 0x10], r13
00055c71  4d8b442410               mov r8, qword ptr [r12 + 0x10]
00055c76  418b4c2408               mov ecx, dword ptr [r12 + 8]
00055c7b  4d85c0                   test r8, r8
00055c7e  7512                     jne 0x55c92
00055c80  4983042402               add qword ptr [r12], 2
00055c85  4d8b0424                 mov r8, qword ptr [r12]
00055c89  ffc9                     dec ecx
00055c8b  41894c2408               mov dword ptr [r12 + 8], ecx
00055c90  eb27                     jmp 0x55cb9
00055c92  498b1424                 mov rdx, qword ptr [r12]
00055c96  498d44240e               lea rax, [r12 + 0xe]
00055c9b  ffc9                     dec ecx
00055c9d  498bf5                   mov rsi, r13
00055ca0  41894c2408               mov dword ptr [r12 + 8], ecx
00055ca5  483bd0                   cmp rdx, rax
00055ca8  7406                     je 0x55cb0
00055caa  4c8d4202                 lea r8, [rdx + 2]
00055cae  eb05                     jmp 0x55cb5
00055cb0  4d896c2410               mov qword ptr [r12 + 0x10], r13
00055cb5  4d890424                 mov qword ptr [r12], r8
00055cb9  418b4708                 mov eax, dword ptr [r15 + 8]
00055cbd  85c0                     test eax, eax
00055cbf  746b                     je 0x55d2c
00055cc1  85c9                     test ecx, ecx
00055cc3  7467                     je 0x55d2c
00055cc5  498b07                   mov rax, qword ptr [r15]
00055cc8  498b5308                 mov rdx, qword ptr [r11 + 8]
00055ccc  0fb708                   movzx ecx, word ptr [rax]
00055ccf  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00055cd2  0fb7d8                   movzx ebx, ax
00055cd5  48c1e810                 shr rax, 0x10
00055cd9  48c1e320                 shl rbx, 0x20
00055cdd  480bd8                   or rbx, rax
00055ce0  410fb700                 movzx eax, word ptr [r8]
00055ce4  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00055ce8  8b0c82                   mov ecx, dword ptr [rdx + rax*4]
00055ceb  0fb7f9                   movzx edi, cx
00055cee  48c1e720                 shl rdi, 0x20
00055cf2  48c1e910                 shr rcx, 0x10
00055cf6  480bf9                   or rdi, rcx
00055cf9  e950edffff               jmp 0x54a4e
00055cfe  448b559f                 mov r10d, dword ptr [rbp - 0x61]
00055d02  4c8d058b6e0400           lea r8, [rip + 0x46e8b]
00055d09  448b6d6f                 mov r13d, dword ptr [rbp + 0x6f]
00055d0d  e98decffff               jmp 0x5499f
00055d12  448b559f                 mov r10d, dword ptr [rbp - 0x61]
00055d16  448b6d6f                 mov r13d, dword ptr [rbp + 0x6f]
00055d1a  4c8d05736e0400           lea r8, [rip + 0x46e73]
00055d21  41bb01000000             mov r11d, 1
00055d27  e973ecffff               jmp 0x5499f
00055d2c  448b4daf                 mov r9d, dword ptr [rbp - 0x51]
00055d30  ebe4                     jmp 0x55d16
00055d32  48c1ef10                 shr rdi, 0x10
00055d36  48c1eb10                 shr rbx, 0x10
00055d3a  3bdf                     cmp ebx, edi
00055d3c  410f42c1                 cmovb eax, r9d
00055d40  e9fa000000               jmp 0x55e3f
00055d45  85c0                     test eax, eax
00055d47  7538                     jne 0x55d81
00055d49  4139442408               cmp dword ptr [r12 + 8], eax
00055d4e  0f84d7000000             je 0x55e2b
00055d54  4585ed                   test r13d, r13d
00055d57  791c                     jns 0x55d75
00055d59  49837c241000             cmp qword ptr [r12 + 0x10], 0
00055d5f  0f84c6000000             je 0x55e2b
00055d65  8b45ab                   mov eax, dword ptr [rbp - 0x55]
00055d68  4183fa07                 cmp r10d, 7
00055d6c  410f44c3                 cmove eax, r11d
00055d70  e9ca000000               jmp 0x55e3f
00055d75  4585c9                   test r9d, r9d
00055d78  4d8bfc                   mov r15, r12
00055d7b  480f45df                 cmovne rbx, rdi
00055d7f  eb06                     jmp 0x55d87
00055d81  41bb03000000             mov r11d, 3
00055d87  458b4708                 mov r8d, dword ptr [r15 + 8]
00055d8b  4585c0                   test r8d, r8d
00055d8e  0f8497000000             je 0x55e2b
00055d94  488d3d65a2faff           lea rdi, [rip - 0x55d9b]
00055d9b  0f1f440000               nop dword ptr [rax + rax]
00055da0  4585c9                   test r9d, r9d
00055da3  7407                     je 0x55dac
00055da5  33d2                     xor edx, edx
00055da7  448bca                   mov r9d, edx
00055daa  eb21                     jmp 0x55dcd
00055dac  498b07                   mov rax, qword ptr [r15]
00055daf  488b5567                 mov rdx, qword ptr [rbp + 0x67]
00055db3  0fb708                   movzx ecx, word ptr [rax]
00055db6  488b4208                 mov rax, qword ptr [rdx + 8]
00055dba  8b1488                   mov edx, dword ptr [rax + rcx*4]
00055dbd  0fb7da                   movzx ebx, dx
00055dc0  48c1e320                 shl rbx, 0x20
00055dc4  48c1ea10                 shr rdx, 0x10
00055dc8  480bda                   or rbx, rdx
00055dcb  33d2                     xor edx, edx
00055dcd  488bc3                   mov rax, rbx
00055dd0  48c1e828                 shr rax, 0x28
00055dd4  0fb6c8                   movzx ecx, al
00055dd7  83f90c                   cmp ecx, 0xc
00055dda  7717                     ja 0x55df3
00055ddc  8b8c8f8c5e0500           mov ecx, dword ptr [rdi + rcx*4 + 0x55e8c]
00055de3  4803cf                   add rcx, rdi
00055de6  ffe1                     jmp rcx
00055de8  41f6c502                 test r13b, 2
00055dec  7510                     jne 0x55dfe
00055dee  4585d2                   test r10d, r10d
00055df1  7e0b                     jle 0x55dfe
00055df3  418bc3                   mov eax, r11d
00055df6  eb47                     jmp 0x55e3f
00055df8  41f6c504                 test r13b, 4
00055dfc  74f5                     je 0x55df3
00055dfe  498b0f                   mov rcx, qword ptr [r15]
00055e01  498d470e                 lea rax, [r15 + 0xe]
00055e05  41ffc8                   dec r8d
00055e08  483bc8                   cmp rcx, rax
00055e0b  7406                     je 0x55e13
00055e0d  4883c102                 add rcx, 2
00055e11  eb08                     jmp 0x55e1b
00055e13  498b4f10                 mov rcx, qword ptr [r15 + 0x10]
00055e17  49895710                 mov qword ptr [r15 + 0x10], rdx
00055e1b  49890f                   mov qword ptr [r15], rcx
00055e1e  45894708                 mov dword ptr [r15 + 8], r8d
00055e22  4585c0                   test r8d, r8d
00055e25  0f8575ffffff             jne 0x55da0
00055e2b  448b4dab                 mov r9d, dword ptr [rbp - 0x55]
00055e2f  b802000000               mov eax, 2
00055e34  4183fa07                 cmp r10d, 7
00055e38  440f44c8                 cmove r9d, eax
00055e3c  418bc1                   mov eax, r9d
00055e3f  4881c4d8000000           add rsp, 0xd8
00055e46  415f                     pop r15
00055e48  415e                     pop r14
00055e4a  415d                     pop r13
00055e4c  415c                     pop r12
00055e4e  5f                       pop rdi
00055e4f  5e                       pop rsi
00055e50  5b                       pop rbx
00055e51  5d                       pop rbp
00055e52  c3                       ret
00055e53  90                       nop
00055e54  ca5205                   retf 0x552
00055e57  00964f0500ca             add byte ptr [rsi - 0x35fffab1], dl
00055e5d  52                       push rdx
00055e5e  0500cd5205               add eax, 0x552cd00
00055e63  006051                   add byte ptr [rax + 0x51], ah
00055e66  0500955205               add eax, 0x5529500
00055e6b  00cd                     add ch, cl
00055e6d  50                       push rax
00055e6e  0500435605               add eax, 0x5564300
00055e73  00fc                     add ah, bh
00055e75  52                       push rdx
00055e76  0500435605               add eax, 0x5564300
00055e7b  004656                   add byte ptr [rsi + 0x56], al
00055e7e  0500015505               add eax, 0x5550100
00055e83  0020                     add byte ptr [rax], ah
00055e85  56                       push rsi
00055e86  0500a35305               add eax, 0x553a300
00055e8b  00fe                     add dh, bh
00055e8d  5d                       pop rbp
00055e8e  0500e85d05               add eax, 0x55de800
00055e93  00f3                     add bl, dh
00055e95  5d                       pop rbp
00055e96  0500f35d05               add eax, 0x55df300
00055e9b  00f3                     add bl, dh
00055e9d  5d                       pop rbp
00055e9e  0500f35d05               add eax, 0x55df300
00055ea3  00f8                     add al, bh
00055ea5  5d                       pop rbp
00055ea6  0500f85d05               add eax, 0x55df800
00055eab  00f8                     add al, bh
00055ead  5d                       pop rbp
00055eae  0500f85d05               add eax, 0x55df800
00055eb3  00f8                     add al, bh
00055eb5  5d                       pop rbp
00055eb6  0500f85d05               add eax, 0x55df800
00055ebb  00f8                     add al, bh
00055ebd  5d                       pop rbp
