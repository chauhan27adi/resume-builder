; CTrustedMachine::GetEncryptionProviderForSystemSession
; aetm_enclave.dll, primary RVA 0xbff0, 741 bytes in 1 chunk(s)

; chunk at RVA 0xbff0 (741 bytes)
0000bff0  488bc4                   mov rax, rsp
0000bff3  57                       push rdi
0000bff4  4154                     push r12
0000bff6  4155                     push r13
0000bff8  4156                     push r14
0000bffa  4157                     push r15
0000bffc  4883ec50                 sub rsp, 0x50
0000c000  48c740b8feffffff         mov qword ptr [rax - 0x48], 0xfffffffffffffffe
0000c008  48895810                 mov qword ptr [rax + 0x10], rbx
0000c00c  48896818                 mov qword ptr [rax + 0x18], rbp
0000c010  48897020                 mov qword ptr [rax + 0x20], rsi
0000c014  498be8                   mov rbp, r8
0000c017  4c63e2                   movsxd r12, edx
0000c01a  4c8bf1                   mov r14, rcx
0000c01d  4c8db9c0da4700           lea r15, [rcx + 0x47dac0]
0000c024  498bdf                   mov rbx, r15
0000c027  498db700000900           lea rsi, [r15 + 0x90000]
0000c02e  4533ed                   xor r13d, r13d
0000c031  4c3bfe                   cmp r15, rsi
0000c034  7345                     jae 0xc07b
0000c036  66660f1f840000000000     nop word ptr [rax + rax]
0000c040  4c89ac2480000000         mov qword ptr [rsp + 0x80], r13
0000c048  48899c2480000000         mov qword ptr [rsp + 0x80], rbx
0000c050  f048ff4338               lock inc qword ptr [rbx + 0x38]
0000c055  90                       nop
0000c056  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000c05a  84c0                     test al, al
0000c05c  7518                     jne 0xc076
0000c05e  4883c348                 add rbx, 0x48
0000c062  488b842480000000         mov rax, qword ptr [rsp + 0x80]
0000c06a  f048ff4838               lock dec qword ptr [rax + 0x38]
0000c06f  483bde                   cmp rbx, rsi
0000c072  72cc                     jb 0xc040
0000c074  eb05                     jmp 0xc07b
0000c076  f048ff4b38               lock dec qword ptr [rbx + 0x38]
0000c07b  48ba398ee3388ee3380e     movabs rdx, 0xe38e38e38e38e39
0000c085  483bde                   cmp rbx, rsi
0000c088  0f842f020000             je 0xc2bd
0000c08e  4c897c2438               mov qword ptr [rsp + 0x38], r15
0000c093  4c896c2420               mov qword ptr [rsp + 0x20], r13
0000c098  48895c2420               mov qword ptr [rsp + 0x20], rbx
0000c09d  f048ff4338               lock inc qword ptr [rbx + 0x38]
0000c0a2  90                       nop
0000c0a3  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000c0a7  488bcb                   mov rcx, rbx
0000c0aa  492bcf                   sub rcx, r15
0000c0ad  488bc2                   mov rax, rdx
0000c0b0  48f7e9                   imul rcx
0000c0b3  48c1fa02                 sar rdx, 2
0000c0b7  488bc2                   mov rax, rdx
0000c0ba  48c1e83f                 shr rax, 0x3f
0000c0be  4803d0                   add rdx, rax
0000c0c1  90                       nop
0000c0c2  488b4338                 mov rax, qword ptr [rbx + 0x38]
0000c0c6  4863ca                   movsxd rcx, edx
0000c0c9  48c1e120                 shl rcx, 0x20
0000c0cd  48c1e820                 shr rax, 0x20
0000c0d1  480bc8                   or rcx, rax
0000c0d4  f048ff4b38               lock dec qword ptr [rbx + 0x38]
0000c0d9  48894c2440               mov qword ptr [rsp + 0x40], rcx
0000c0de  0faee8                   lfence
0000c0e1  48c1e920                 shr rcx, 0x20
0000c0e5  81e1ff1f0000             and ecx, 0x1fff
0000c0eb  488d0cc9                 lea rcx, [rcx + rcx*8]
0000c0ef  488b442438               mov rax, qword ptr [rsp + 0x38]
0000c0f4  f048ff44c838             lock inc qword ptr [rax + rcx*8 + 0x38]
0000c0fa  4c8b4c2440               mov r9, qword ptr [rsp + 0x40]
0000c0ff  498bd1                   mov rdx, r9
0000c102  48c1ea20                 shr rdx, 0x20
0000c106  488bc2                   mov rax, rdx
0000c109  25ff1f0000               and eax, 0x1fff
0000c10e  488d0cc0                 lea rcx, [rax + rax*8]
0000c112  488b442438               mov rax, qword ptr [rsp + 0x38]
0000c117  4c8d04c8                 lea r8, [rax + rcx*8]
0000c11b  90                       nop
0000c11c  410fb64840               movzx ecx, byte ptr [r8 + 0x40]
0000c121  90                       nop
0000c122  498b4038                 mov rax, qword ptr [r8 + 0x38]
0000c126  48c1e820                 shr rax, 0x20
0000c12a  413bc1                   cmp eax, r9d
0000c12d  7569                     jne 0xc198
0000c12f  84c9                     test cl, cl
0000c131  7465                     je 0xc198
0000c133  90                       nop
0000c134  410fb64841               movzx ecx, byte ptr [r8 + 0x41]
0000c139  90                       nop
0000c13a  498b4038                 mov rax, qword ptr [r8 + 0x38]
0000c13e  48c1e820                 shr rax, 0x20
0000c142  413bc1                   cmp eax, r9d
0000c145  0f855a010000             jne 0xc2a5
0000c14b  84c9                     test cl, cl
0000c14d  0f8452010000             je 0xc2a5
0000c153  81e2ff1f0000             and edx, 0x1fff
0000c159  488d0cd2                 lea rcx, [rdx + rdx*8]
0000c15d  488b442438               mov rax, qword ptr [rsp + 0x38]
0000c162  488d3cc8                 lea rdi, [rax + rcx*8]
0000c166  488b4508                 mov rax, qword ptr [rbp + 8]
0000c16a  48394708                 cmp qword ptr [rdi + 8], rax
0000c16e  7523                     jne 0xc193
0000c170  0fb74518                 movzx eax, word ptr [rbp + 0x18]
0000c174  663907                   cmp word ptr [rdi], ax
0000c177  751a                     jne 0xc193
0000c179  0fb75502                 movzx edx, word ptr [rbp + 2]
0000c17d  395704                   cmp dword ptr [rdi + 4], edx
0000c180  0f848c000000             je 0xc212
0000c186  498bce                   mov rcx, r14
0000c189  e8c2110000               call 0xd350
0000c18e  394704                   cmp dword ptr [rdi + 4], eax
0000c191  747f                     je 0xc212
0000c193  0faee8                   lfence
0000c196  eb16                     jmp 0xc1ae
0000c198  0faee8                   lfence
0000c19b  81e2ff1f0000             and edx, 0x1fff
0000c1a1  488d0cd2                 lea rcx, [rdx + rdx*8]
0000c1a5  488b442438               mov rax, qword ptr [rsp + 0x38]
0000c1aa  488d3cc8                 lea rdi, [rax + rcx*8]
0000c1ae  f048ff4f38               lock dec qword ptr [rdi + 0x38]
0000c1b3  483bde                   cmp rbx, rsi
0000c1b6  48ba398ee3388ee3380e     movabs rdx, 0xe38e38e38e38e39
0000c1c0  0f83c2feffff             jae 0xc088
0000c1c6  4883c348                 add rbx, 0x48
0000c1ca  483bde                   cmp rbx, rsi
0000c1cd  0f83b5feffff             jae 0xc088
0000c1d3  0f1f4000                 nop dword ptr [rax]
0000c1d7  660f1f840000000000       nop word ptr [rax + rax]
0000c1e0  4c896c2428               mov qword ptr [rsp + 0x28], r13
0000c1e5  48895c2428               mov qword ptr [rsp + 0x28], rbx
0000c1ea  488d4b38                 lea rcx, [rbx + 0x38]
0000c1ee  f048ff01                 lock inc qword ptr [rcx]
0000c1f2  90                       nop
0000c1f3  0fb64340                 movzx eax, byte ptr [rbx + 0x40]
0000c1f7  84c0                     test al, al
0000c1f9  7512                     jne 0xc20d
0000c1fb  4883c348                 add rbx, 0x48
0000c1ff  f048ff09                 lock dec qword ptr [rcx]
0000c203  483bde                   cmp rbx, rsi
0000c206  72d8                     jb 0xc1e0
0000c208  e96efeffff               jmp 0xc07b
0000c20d  e964feffff               jmp 0xc076
0000c212  498d96b85a4100           lea rdx, [r14 + 0x415ab8]
0000c219  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
0000c21d  488bc1                   mov rax, rcx
0000c220  48c1e820                 shr rax, 0x20
0000c224  25ff1f0000               and eax, 0x1fff
0000c229  488d0440                 lea rax, [rax + rax*2]
0000c22d  4803c0                   add rax, rax
0000c230  90                       nop
0000c231  440fb644c229             movzx r8d, byte ptr [rdx + rax*8 + 0x29]
0000c237  90                       nop
0000c238  488b44c220               mov rax, qword ptr [rdx + rax*8 + 0x20]
0000c23d  48c1e820                 shr rax, 0x20
0000c241  3bc1                     cmp eax, ecx
0000c243  7560                     jne 0xc2a5
0000c245  4584c0                   test r8b, r8b
0000c248  745b                     je 0xc2a5
0000c24a  488b4730                 mov rax, qword ptr [rdi + 0x30]
0000c24e  48c1e820                 shr rax, 0x20
0000c252  25ff1f0000               and eax, 0x1fff
0000c257  488d0c40                 lea rcx, [rax + rax*2]
0000c25b  48c1e104                 shl rcx, 4
0000c25f  4803ca                   add rcx, rdx
0000c262  4a8b04e1                 mov rax, qword ptr [rcx + r12*8]
0000c266  488b4c2440               mov rcx, qword ptr [rsp + 0x40]
0000c26b  48c1e920                 shr rcx, 0x20
0000c26f  0faee8                   lfence
0000c272  81e1ff1f0000             and ecx, 0x1fff
0000c278  488d14c9                 lea rdx, [rcx + rcx*8]
0000c27c  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
0000c281  f048ff4cd138             lock dec qword ptr [rcx + rdx*8 + 0x38]
0000c287  4c8d5c2450               lea r11, [rsp + 0x50]
0000c28c  498b5b38                 mov rbx, qword ptr [r11 + 0x38]
0000c290  498b6b40                 mov rbp, qword ptr [r11 + 0x40]
0000c294  498b7348                 mov rsi, qword ptr [r11 + 0x48]
0000c298  498be3                   mov rsp, r11
0000c29b  415f                     pop r15
0000c29d  415e                     pop r14
0000c29f  415d                     pop r13
0000c2a1  415c                     pop r12
0000c2a3  5f                       pop rdi
0000c2a4  c3                       ret
0000c2a5  ba5f000000               mov edx, 0x5f
0000c2aa  b94b010000               mov ecx, 0x14b
0000c2af  448d4aa2                 lea r9d, [rdx - 0x5e]
0000c2b3  448d42b2                 lea r8d, [rdx - 0x4e]
0000c2b7  e884d10000               call 0x19440
0000c2bc  90                       nop
0000c2bd  ba2e000000               mov edx, 0x2e
0000c2c2  b94f010000               mov ecx, 0x14f
0000c2c7  448d4ad7                 lea r9d, [rdx - 0x29]
0000c2cb  448d42e2                 lea r8d, [rdx - 0x1e]
0000c2cf  e86cd10000               call 0x19440
0000c2d4  cc                       int3
