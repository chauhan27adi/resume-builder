; CDatetime2::Deserialize
; aetm_enclave.dll, primary RVA 0x2f140, 288 bytes in 1 chunk(s)

; chunk at RVA 0x2f140 (288 bytes)
0002f140  48895c2408               mov qword ptr [rsp + 8], rbx
0002f145  4889742410               mov qword ptr [rsp + 0x10], rsi
0002f14a  57                       push rdi
0002f14b  4883ec20                 sub rsp, 0x20
0002f14f  410fb6c0                 movzx eax, r8b
0002f153  488d5a08                 lea rbx, [rdx + 8]
0002f157  44894118                 mov dword ptr [rcx + 0x18], r8d
0002f15b  488bf9                   mov rdi, rcx
0002f15e  4c8d059b0efdff           lea r8, [rip - 0x2f165]
0002f165  410fb6b48040420600       movzx esi, byte ptr [r8 + rax*4 + 0x64240]
0002f16e  48c7411000000000         mov qword ptr [rcx + 0x10], 0
0002f176  8d46fd                   lea eax, [rsi - 3]
0002f179  83f807                   cmp eax, 7
0002f17c  0f8787000000             ja 0x2f209
0002f182  4898                     cdqe
0002f184  418b8c8040f20200         mov ecx, dword ptr [r8 + rax*4 + 0x2f240]
0002f18c  4903c8                   add rcx, r8
0002f18f  ffe1                     jmp rcx
0002f191  0fb703                   movzx eax, word ptr [rbx]
0002f194  66894710                 mov word ptr [rdi + 0x10], ax
0002f198  0fb64302                 movzx eax, byte ptr [rbx + 2]
0002f19c  884712                   mov byte ptr [rdi + 0x12], al
0002f19f  eb77                     jmp 0x2f218
0002f1a1  8b03                     mov eax, dword ptr [rbx]
0002f1a3  894710                   mov dword ptr [rdi + 0x10], eax
0002f1a6  eb70                     jmp 0x2f218
0002f1a8  8b03                     mov eax, dword ptr [rbx]
0002f1aa  894710                   mov dword ptr [rdi + 0x10], eax
0002f1ad  0fb64304                 movzx eax, byte ptr [rbx + 4]
0002f1b1  884714                   mov byte ptr [rdi + 0x14], al
0002f1b4  eb62                     jmp 0x2f218
0002f1b6  8b03                     mov eax, dword ptr [rbx]
0002f1b8  894710                   mov dword ptr [rdi + 0x10], eax
0002f1bb  0fb74304                 movzx eax, word ptr [rbx + 4]
0002f1bf  66894714                 mov word ptr [rdi + 0x14], ax
0002f1c3  eb53                     jmp 0x2f218
0002f1c5  8b03                     mov eax, dword ptr [rbx]
0002f1c7  894710                   mov dword ptr [rdi + 0x10], eax
0002f1ca  0fb74304                 movzx eax, word ptr [rbx + 4]
0002f1ce  66894714                 mov word ptr [rdi + 0x14], ax
0002f1d2  0fb64306                 movzx eax, byte ptr [rbx + 6]
0002f1d6  884716                   mov byte ptr [rdi + 0x16], al
0002f1d9  eb3d                     jmp 0x2f218
0002f1db  488b03                   mov rax, qword ptr [rbx]
0002f1de  48894710                 mov qword ptr [rdi + 0x10], rax
0002f1e2  eb34                     jmp 0x2f218
0002f1e4  f20f1003                 movsd xmm0, qword ptr [rbx]
0002f1e8  f20f114710               movsd qword ptr [rdi + 0x10], xmm0
0002f1ed  0fb64308                 movzx eax, byte ptr [rbx + 8]
0002f1f1  884718                   mov byte ptr [rdi + 0x18], al
0002f1f4  eb22                     jmp 0x2f218
0002f1f6  f20f1003                 movsd xmm0, qword ptr [rbx]
0002f1fa  f20f114710               movsd qword ptr [rdi + 0x10], xmm0
0002f1ff  0fb74308                 movzx eax, word ptr [rbx + 8]
0002f203  66894718                 mov word ptr [rdi + 0x18], ax
0002f207  eb0f                     jmp 0x2f218
0002f209  4c8bc6                   mov r8, rsi
0002f20c  488d4f10                 lea rcx, [rdi + 0x10]
0002f210  488bd3                   mov rdx, rbx
0002f213  e89bf00200               call 0x5e2b3
0002f218  c7470800000000           mov dword ptr [rdi + 8], 0
0002f21f  0fb7041e                 movzx eax, word ptr [rsi + rbx]
0002f223  66894708                 mov word ptr [rdi + 8], ax
0002f227  0fb6441e02               movzx eax, byte ptr [rsi + rbx + 2]
0002f22c  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0002f231  488b742438               mov rsi, qword ptr [rsp + 0x38]
0002f236  88470a                   mov byte ptr [rdi + 0xa], al
0002f239  4883c420                 add rsp, 0x20
0002f23d  5f                       pop rdi
0002f23e  c3                       ret
0002f23f  90                       nop
0002f240  91                       xchg ecx, eax
0002f241  f1                       int1
0002f242  0200                     add al, byte ptr [rax]
0002f244  a1f10200a8f10200b6       movabs eax, dword ptr [0xb60002f1a80002f1]
0002f24d  f1                       int1
0002f24e  0200                     add al, byte ptr [rax]
