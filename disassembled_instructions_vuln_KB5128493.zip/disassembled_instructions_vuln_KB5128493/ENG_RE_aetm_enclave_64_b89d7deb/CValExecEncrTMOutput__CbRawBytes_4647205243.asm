; CValExecEncrTMOutput::CbRawBytes
; aetm_enclave.dll, primary RVA 0x16a00, 292 bytes in 1 chunk(s)

; chunk at RVA 0x16a00 (292 bytes)
00016a00  4883ec28                 sub rsp, 0x28
00016a04  4c8d0df595feff           lea r9, [rip - 0x16a0b]
00016a0b  4c8d81a8000000           lea r8, [rcx + 0xa8]
00016a12  410fb608                 movzx ecx, byte ptr [r8]
00016a16  420fb68409405a0600       movzx eax, byte ptr [rcx + r9 + 0x65a40]
00016a1f  4280bc08405b060001       cmp byte ptr [rax + r9 + 0x65b40], 1
00016a28  7508                     jne 0x16a32
00016a2a  8b4210                   mov eax, dword ptr [rdx + 0x10]
00016a2d  4883c428                 add rsp, 0x28
00016a31  c3                       ret
00016a32  8d41dc                   lea eax, [rcx - 0x24]
00016a35  83f85b                   cmp eax, 0x5b
00016a38  7764                     ja 0x16a9e
00016a3a  4898                     cdqe
00016a3c  410fb68401c86a0100       movzx eax, byte ptr [r9 + rax + 0x16ac8]
00016a45  418b8c81a86a0100         mov ecx, dword ptr [r9 + rax*4 + 0x16aa8]
00016a4d  4903c9                   add rcx, r9
00016a50  ffe1                     jmp rcx
00016a52  b803000000               mov eax, 3
00016a57  4883c428                 add rsp, 0x28
00016a5b  c3                       ret
00016a5c  b804000000               mov eax, 4
00016a61  4883c428                 add rsp, 0x28
00016a65  c3                       ret
00016a66  b805000000               mov eax, 5
00016a6b  4883c428                 add rsp, 0x28
00016a6f  c3                       ret
00016a70  b80a000000               mov eax, 0xa
00016a75  4883c428                 add rsp, 0x28
00016a79  c3                       ret
00016a7a  b811000000               mov eax, 0x11
00016a7f  4883c428                 add rsp, 0x28
00016a83  c3                       ret
00016a84  b808000000               mov eax, 8
00016a89  4883c428                 add rsp, 0x28
00016a8d  c3                       ret
00016a8e  498bc8                   mov rcx, r8
00016a91  e8ca13ffff               call 0x7e60
00016a96  0fb7c0                   movzx eax, ax
00016a99  4883c428                 add rsp, 0x28
00016a9d  c3                       ret
00016a9e  33c0                     xor eax, eax
00016aa0  4883c428                 add rsp, 0x28
00016aa4  c3                       ret
00016aa5  0f1f00                   nop dword ptr [rax]
00016aa8  8e6a01                   mov gs, word ptr [rdx + 1]
00016aab  00526a                   add byte ptr [rdx + 0x6a], dl
00016aae  0100                     add dword ptr [rax], eax
00016ab0  666a01                   push 1
00016ab3  00846a0100706a           add byte ptr [rdx + rbp*2 + 0x6a700001], al
00016aba  0100                     add dword ptr [rax], eax
00016abc  5c                       pop rsp
00016abd  6a01                     push 1
00016abf  007a6a                   add byte ptr [rdx + 0x6a], bh
00016ac2  0100                     add dword ptr [rax], eax
00016ac4  9e                       sahf
00016ac5  6a01                     push 1
00016ac7  0000                     add byte ptr [rax], al
