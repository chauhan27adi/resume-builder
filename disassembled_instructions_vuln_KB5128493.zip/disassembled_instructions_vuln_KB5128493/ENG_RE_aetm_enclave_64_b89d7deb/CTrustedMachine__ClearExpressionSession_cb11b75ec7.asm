; CTrustedMachine::ClearExpressionSession
; aetm_enclave.dll, primary RVA 0xbcc0, 802 bytes in 1 chunk(s)

; chunk at RVA 0xbcc0 (802 bytes)
0000bcc0  48895c2410               mov qword ptr [rsp + 0x10], rbx
0000bcc5  48894c2408               mov qword ptr [rsp + 8], rcx
0000bcca  55                       push rbp
0000bccb  56                       push rsi
0000bccc  57                       push rdi
0000bccd  4154                     push r12
0000bccf  4155                     push r13
0000bcd1  4156                     push r14
0000bcd3  4157                     push r15
0000bcd5  4883ec20                 sub rsp, 0x20
0000bcd9  488be9                   mov rbp, rcx
0000bcdc  488d7920                 lea rdi, [rcx + 0x20]
0000bce0  90                       nop
0000bce1  4c8bf2                   mov r14, rdx
0000bce4  488bcf                   mov rcx, rdi
0000bce7  0fb64548                 movzx eax, byte ptr [rbp + 0x48]
0000bceb  488d9d20300000           lea rbx, [rbp + 0x3020]
0000bcf2  483bfb                   cmp rdi, rbx
0000bcf5  7312                     jae 0xbd09
0000bcf7  84c0                     test al, al
0000bcf9  750e                     jne 0xbd09
0000bcfb  4883c130                 add rcx, 0x30
0000bcff  90                       nop
0000bd00  0fb64128                 movzx eax, byte ptr [rcx + 0x28]
0000bd04  483bcb                   cmp rcx, rbx
0000bd07  72ee                     jb 0xbcf7
0000bd09  48bdabaaaaaaaaaaaa2a     movabs rbp, 0x2aaaaaaaaaaaaaab
0000bd13  49bc00000000ffffffff     movabs r12, 0xffffffff00000000
0000bd1d  49bd0000000001000000     movabs r13, 0x100000000
0000bd27  660f1f840000000000       nop word ptr [rax + rax]
0000bd30  90                       nop
0000bd31  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000bd35  90                       nop
0000bd36  488bf1                   mov rsi, rcx
0000bd39  483bcb                   cmp rcx, rbx
0000bd3c  0f84f9000000             je 0xbe3b
0000bd42  0fb64128                 movzx eax, byte ptr [rcx + 0x28]
0000bd46  488bd1                   mov rdx, rcx
0000bd49  482bd7                   sub rdx, rdi
0000bd4c  90                       nop
0000bd4d  488bc5                   mov rax, rbp
0000bd50  48f7ea                   imul rdx
0000bd53  48c1fa03                 sar rdx, 3
0000bd57  488bc2                   mov rax, rdx
0000bd5a  48c1e83f                 shr rax, 0x3f
0000bd5e  4803d0                   add rdx, rax
0000bd61  488b4120                 mov rax, qword ptr [rcx + 0x20]
0000bd65  48c1e820                 shr rax, 0x20
0000bd69  90                       nop
0000bd6a  4c63c2                   movsxd r8, edx
0000bd6d  49c1e020                 shl r8, 0x20
0000bd71  4c0bc0                   or r8, rax
0000bd74  498bc0                   mov rax, r8
0000bd77  48c1e820                 shr rax, 0x20
0000bd7b  440fb6c8                 movzx r9d, al
0000bd7f  4c8bd0                   mov r10, rax
0000bd82  4b8d0449                 lea rax, [r9 + r9*2]
0000bd86  4803c0                   add rax, rax
0000bd89  0fb654c729               movzx edx, byte ptr [rdi + rax*8 + 0x29]
0000bd8e  90                       nop
0000bd8f  488b44c720               mov rax, qword ptr [rdi + rax*8 + 0x20]
0000bd94  48c1e820                 shr rax, 0x20
0000bd98  413bc0                   cmp eax, r8d
0000bd9b  7565                     jne 0xbe02
0000bd9d  84d2                     test dl, dl
0000bd9f  7461                     je 0xbe02
0000bda1  410fb6c2                 movzx eax, r10b
0000bda5  90                       nop
0000bda6  4c8d0440                 lea r8, [rax + rax*2]
0000bdaa  49c1e004                 shl r8, 4
0000bdae  4c03c7                   add r8, rdi
0000bdb1  498b4020                 mov rax, qword ptr [r8 + 0x20]
0000bdb5  85c0                     test eax, eax
0000bdb7  7549                     jne 0xbe02
0000bdb9  488bd0                   mov rdx, rax
0000bdbc  4923d4                   and rdx, r12
0000bdbf  4903d5                   add rdx, r13
0000bdc2  f0490fb15020             lock cmpxchg qword ptr [r8 + 0x20], rdx
0000bdc8  7538                     jne 0xbe02
0000bdca  41c6402800               mov byte ptr [r8 + 0x28], 0
0000bdcf  41c6402900               mov byte ptr [r8 + 0x29], 0
0000bdd4  90                       nop
0000bdd5  498b4020                 mov rax, qword ptr [r8 + 0x20]
0000bdd9  48c1e820                 shr rax, 0x20
0000bddd  83f8ff                   cmp eax, -1
0000bde0  7415                     je 0xbdf7
0000bde2  48638700340000           movsxd rax, dword ptr [rdi + 0x3400]
0000bde9  44898c8700300000         mov dword ptr [rdi + rax*4 + 0x3000], r9d
0000bdf1  ff8700340000             inc dword ptr [rdi + 0x3400]
0000bdf7  4c397110                 cmp qword ptr [rcx + 0x10], r14
0000bdfb  7505                     jne 0xbe02
0000bdfd  e88efdffff               call 0xbb90
0000be02  483bf3                   cmp rsi, rbx
0000be05  488d4e30                 lea rcx, [rsi + 0x30]
0000be09  90                       nop
0000be0a  480f43ce                 cmovae rcx, rsi
0000be0e  0fb64128                 movzx eax, byte ptr [rcx + 0x28]
0000be12  483bcb                   cmp rcx, rbx
0000be15  0f8315ffffff             jae 0xbd30
0000be1b  0f1f440000               nop dword ptr [rax + rax]
0000be20  84c0                     test al, al
0000be22  0f8508ffffff             jne 0xbd30
0000be28  4883c130                 add rcx, 0x30
0000be2c  90                       nop
0000be2d  0fb64128                 movzx eax, byte ptr [rcx + 0x28]
0000be31  483bcb                   cmp rcx, rbx
0000be34  72ea                     jb 0xbe20
0000be36  e9f5feffff               jmp 0xbd30
0000be3b  488b6c2460               mov rbp, qword ptr [rsp + 0x60]
0000be40  0fb68550340000           movzx eax, byte ptr [rbp + 0x3450]
0000be47  488db528340000           lea rsi, [rbp + 0x3428]
0000be4e  488dbd283a0000           lea rdi, [rbp + 0x3a28]
0000be55  488bde                   mov rbx, rsi
0000be58  483bf7                   cmp rsi, rdi
0000be5b  7315                     jae 0xbe72
0000be5d  0f1f00                   nop dword ptr [rax]
0000be60  84c0                     test al, al
0000be62  750e                     jne 0xbe72
0000be64  4883c330                 add rbx, 0x30
0000be68  90                       nop
0000be69  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000be6d  483bdf                   cmp rbx, rdi
0000be70  72ee                     jb 0xbe60
0000be72  4533ff                   xor r15d, r15d
0000be75  90                       nop
0000be76  0fb64728                 movzx eax, byte ptr [rdi + 0x28]
0000be7a  488beb                   mov rbp, rbx
0000be7d  483bdf                   cmp rbx, rdi
0000be80  0f8447010000             je 0xbfcd
0000be86  488b4b08                 mov rcx, qword ptr [rbx + 8]
0000be8a  4c8d7308                 lea r14, [rbx + 8]
0000be8e  4885c9                   test rcx, rcx
0000be91  7412                     je 0xbea5
0000be93  4d85f6                   test r14, r14
0000be96  740d                     je 0xbea5
0000be98  488b01                   mov rax, qword ptr [rcx]
0000be9b  ba01000000               mov edx, 1
0000bea0  ff10                     call qword ptr [rax]
0000bea2  4d893e                   mov qword ptr [r14], r15
0000bea5  488b0b                   mov rcx, qword ptr [rbx]
0000bea8  4885c9                   test rcx, rcx
0000beab  740b                     je 0xbeb8
0000bead  488b01                   mov rax, qword ptr [rcx]
0000beb0  ba01000000               mov edx, 1
0000beb5  ff5028                   call qword ptr [rax + 0x28]
0000beb8  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0000bebc  4885c9                   test rcx, rcx
0000bebf  740a                     je 0xbecb
0000bec1  bae81f0000               mov edx, 0x1fe8
0000bec6  e825110500               call 0x5cff0
0000becb  4c893b                   mov qword ptr [rbx], r15
0000bece  488bcb                   mov rcx, rbx
0000bed1  4d893e                   mov qword ptr [r14], r15
0000bed4  482bce                   sub rcx, rsi
0000bed7  48c74310ffffffff         mov qword ptr [rbx + 0x10], 0xffffffffffffffff
0000bedf  4c897b18                 mov qword ptr [rbx + 0x18], r15
0000bee3  90                       nop
0000bee4  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000bee8  90                       nop
0000bee9  48b8abaaaaaaaaaaaa2a     movabs rax, 0x2aaaaaaaaaaaaaab
0000bef3  48f7e9                   imul rcx
0000bef6  48c1fa03                 sar rdx, 3
0000befa  488bc2                   mov rax, rdx
0000befd  48c1e83f                 shr rax, 0x3f
0000bf01  4803d0                   add rdx, rax
0000bf04  488b4320                 mov rax, qword ptr [rbx + 0x20]
0000bf08  48c1e820                 shr rax, 0x20
0000bf0c  90                       nop
0000bf0d  4863ca                   movsxd rcx, edx
0000bf10  48c1e120                 shl rcx, 0x20
0000bf14  480bc8                   or rcx, rax
0000bf17  488bc1                   mov rax, rcx
0000bf1a  48c1e820                 shr rax, 0x20
0000bf1e  8bd0                     mov edx, eax
0000bf20  83e01f                   and eax, 0x1f
0000bf23  448bc8                   mov r9d, eax
0000bf26  488d0440                 lea rax, [rax + rax*2]
0000bf2a  4803c0                   add rax, rax
0000bf2d  440fb644c629             movzx r8d, byte ptr [rsi + rax*8 + 0x29]
0000bf33  90                       nop
0000bf34  488b44c620               mov rax, qword ptr [rsi + rax*8 + 0x20]
0000bf39  48c1e820                 shr rax, 0x20
0000bf3d  3bc1                     cmp eax, ecx
0000bf3f  7558                     jne 0xbf99
0000bf41  4584c0                   test r8b, r8b
0000bf44  7453                     je 0xbf99
0000bf46  83e21f                   and edx, 0x1f
0000bf49  90                       nop
0000bf4a  488d1452                 lea rdx, [rdx + rdx*2]
0000bf4e  48c1e204                 shl rdx, 4
0000bf52  4803d6                   add rdx, rsi
0000bf55  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000bf59  85c0                     test eax, eax
0000bf5b  753c                     jne 0xbf99
0000bf5d  488bc8                   mov rcx, rax
0000bf60  4923cc                   and rcx, r12
0000bf63  4903cd                   add rcx, r13
0000bf66  f0480fb14a20             lock cmpxchg qword ptr [rdx + 0x20], rcx
0000bf6c  752b                     jne 0xbf99
0000bf6e  44887a28                 mov byte ptr [rdx + 0x28], r15b
0000bf72  44887a29                 mov byte ptr [rdx + 0x29], r15b
0000bf76  90                       nop
0000bf77  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000bf7b  48c1e820                 shr rax, 0x20
0000bf7f  83f8ff                   cmp eax, -1
0000bf82  7415                     je 0xbf99
0000bf84  48638680060000           movsxd rax, dword ptr [rsi + 0x680]
0000bf8b  44898c8600060000         mov dword ptr [rsi + rax*4 + 0x600], r9d
0000bf93  ff8680060000             inc dword ptr [rsi + 0x680]
0000bf99  4883c330                 add rbx, 0x30
0000bf9d  90                       nop
0000bf9e  483bef                   cmp rbp, rdi
0000bfa1  480f43dd                 cmovae rbx, rbp
0000bfa5  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000bfa9  483bdf                   cmp rbx, rdi
0000bfac  0f83c3feffff             jae 0xbe75
0000bfb2  84c0                     test al, al
0000bfb4  0f85bbfeffff             jne 0xbe75
0000bfba  4883c330                 add rbx, 0x30
0000bfbe  90                       nop
0000bfbf  0fb64328                 movzx eax, byte ptr [rbx + 0x28]
0000bfc3  483bdf                   cmp rbx, rdi
0000bfc6  72ea                     jb 0xbfb2
0000bfc8  e9a8feffff               jmp 0xbe75
0000bfcd  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0000bfd2  4883c420                 add rsp, 0x20
0000bfd6  415f                     pop r15
0000bfd8  415e                     pop r14
0000bfda  415d                     pop r13
0000bfdc  415c                     pop r12
0000bfde  5f                       pop rdi
0000bfdf  5e                       pop rsi
0000bfe0  5d                       pop rbp
0000bfe1  c3                       ret
