; CXVariant::CmpCompare
; aetm_enclave.dll, primary RVA 0x3ba60, 1739 bytes in 1 chunk(s)

; chunk at RVA 0x3ba60 (1739 bytes)
0003ba60  4055                     push rbp
0003ba62  53                       push rbx
0003ba63  56                       push rsi
0003ba64  57                       push rdi
0003ba65  4156                     push r14
0003ba67  4881ec60010000           sub rsp, 0x160
0003ba6e  48c7842458010000feffffff mov qword ptr [rsp + 0x158], 0xfffffffffffffffe
0003ba7a  488dac2490000000         lea rbp, [rsp + 0x90]
0003ba82  4883e5c0                 and rbp, 0xffffffffffffffc0
0003ba86  488b057bf50600           mov rax, qword ptr [rip + 0x6f57b]
0003ba8d  4833c4                   xor rax, rsp
0003ba90  488985c0000000           mov qword ptr [rbp + 0xc0], rax
0003ba97  498bf9                   mov rdi, r9
0003ba9a  4c8bca                   mov r9, rdx
0003ba9d  488bd9                   mov rbx, rcx
0003baa0  440fb617                 movzx r10d, byte ptr [rdi]
0003baa4  0fb611                   movzx edx, byte ptr [rcx]
0003baa7  0fb6c2                   movzx eax, dl
0003baaa  488d354f45fcff           lea rsi, [rip - 0x3bab1]
0003bab1  41beffff0000             mov r14d, 0xffff
0003bab7  410ac2                   or al, r10b
0003baba  7458                     je 0x3bb14
0003babc  410fb601                 movzx eax, byte ptr [r9]
0003bac0  0fb68c30405a0600         movzx ecx, byte ptr [rax + rsi + 0x65a40]
0003bac8  80bc31a05c060000         cmp byte ptr [rcx + rsi + 0x65ca0], 0
0003bad0  7407                     je 0x3bad9
0003bad2  66453b7110               cmp r14w, word ptr [r9 + 0x10]
0003bad7  743b                     je 0x3bb14
0003bad9  410fb600                 movzx eax, byte ptr [r8]
0003badd  0fb68c30405a0600         movzx ecx, byte ptr [rax + rsi + 0x65a40]
0003bae5  80bc31a05c060000         cmp byte ptr [rcx + rsi + 0x65ca0], 0
0003baed  7407                     je 0x3baf6
0003baef  66453b7010               cmp r14w, word ptr [r8 + 0x10]
0003baf4  741e                     je 0x3bb14
0003baf6  443ad2                   cmp r10b, dl
0003baf9  7412                     je 0x3bb0d
0003bafb  b828000000               mov eax, 0x28
0003bb00  b930000000               mov ecx, 0x30
0003bb05  80fa03                   cmp dl, 3
0003bb08  0f45c1                   cmovne eax, ecx
0003bb0b  eb66                     jmp 0x3bb73
0003bb0d  b858000000               mov eax, 0x58
0003bb12  eb5f                     jmp 0x3bb73
0003bb14  410fb611                 movzx edx, byte ptr [r9]
0003bb18  410fb608                 movzx ecx, byte ptr [r8]
0003bb1c  440fb69c32405a0600       movzx r11d, byte ptr [rdx + rsi + 0x65a40]
0003bb25  4180bc33405b060000       cmp byte ptr [r11 + rsi + 0x65b40], 0
0003bb2e  7460                     je 0x3bb90
0003bb30  4180bc33a05c060000       cmp byte ptr [r11 + rsi + 0x65ca0], 0
0003bb39  7407                     je 0x3bb42
0003bb3b  66453b7110               cmp r14w, word ptr [r9 + 0x10]
0003bb40  742f                     je 0x3bb71
0003bb42  4c8bd1                   mov r10, rcx
0003bb45  0fb68431405a0600         movzx eax, byte ptr [rcx + rsi + 0x65a40]
0003bb4d  80bc30a05c060000         cmp byte ptr [rax + rsi + 0x65ca0], 0
0003bb55  7407                     je 0x3bb5e
0003bb57  66453b7010               cmp r14w, word ptr [r8 + 0x10]
0003bb5c  7413                     je 0x3bb71
0003bb5e  80faf0                   cmp dl, 0xf0
0003bb61  7530                     jne 0x3bb93
0003bb63  6645397110               cmp word ptr [r9 + 0x10], r14w
0003bb68  7529                     jne 0x3bb93
0003bb6a  41f6410108               test byte ptr [r9 + 1], 8
0003bb6f  7422                     je 0x3bb93
0003bb71  33c0                     xor eax, eax
0003bb73  488b8dc0000000           mov rcx, qword ptr [rbp + 0xc0]
0003bb7a  4833cc                   xor rcx, rsp
0003bb7d  e8ee120200               call 0x5ce70
0003bb82  4881c460010000           add rsp, 0x160
0003bb89  415e                     pop r14
0003bb8b  5f                       pop rdi
0003bb8c  5e                       pop rsi
0003bb8d  5b                       pop rbx
0003bb8e  5d                       pop rbp
0003bb8f  c3                       ret
0003bb90  4c8bd1                   mov r10, rcx
0003bb93  410fb68c33a8560600       movzx ecx, byte ptr [r11 + rsi + 0x656a8]
0003bb9c  410fb68432405a0600       movzx eax, byte ptr [r10 + rsi + 0x65a40]
0003bba5  3a8c30a8560600           cmp cl, byte ptr [rax + rsi + 0x656a8]
0003bbac  75c3                     jne 0x3bb71
0003bbae  8d42de                   lea eax, [rdx - 0x22]
0003bbb1  3dce000000               cmp eax, 0xce
0003bbb6  77b9                     ja 0x3bb71
0003bbb8  4898                     cdqe
0003bbba  0fb684065cc00300         movzx eax, byte ptr [rsi + rax + 0x3c05c]
0003bbc2  8b8c8608c00300           mov ecx, dword ptr [rsi + rax*4 + 0x3c008]
0003bbc9  4803ce                   add rcx, rsi
0003bbcc  ffe1                     jmp rcx
0003bbce  0fb65708                 movzx edx, byte ptr [rdi + 8]
0003bbd2  385308                   cmp byte ptr [rbx + 8], dl
0003bbd5  7219                     jb 0x3bbf0
0003bbd7  b804000000               mov eax, 4
0003bbdc  b902000000               mov ecx, 2
0003bbe1  0f44c1                   cmove eax, ecx
0003bbe4  eb8d                     jmp 0x3bb73
0003bbe6  0fb75708                 movzx edx, word ptr [rdi + 8]
0003bbea  66395308                 cmp word ptr [rbx + 8], dx
0003bbee  7de7                     jge 0x3bbd7
0003bbf0  b801000000               mov eax, 1
0003bbf5  e979ffffff               jmp 0x3bb73
0003bbfa  8b5708                   mov edx, dword ptr [rdi + 8]
0003bbfd  395308                   cmp dword ptr [rbx + 8], edx
0003bc00  7dd5                     jge 0x3bbd7
0003bc02  b801000000               mov eax, 1
0003bc07  e967ffffff               jmp 0x3bb73
0003bc0c  488b5708                 mov rdx, qword ptr [rdi + 8]
0003bc10  48395308                 cmp qword ptr [rbx + 8], rdx
0003bc14  7dc1                     jge 0x3bbd7
0003bc16  b801000000               mov eax, 1
0003bc1b  e953ffffff               jmp 0x3bb73
0003bc20  f30f104708               movss xmm0, dword ptr [rdi + 8]
0003bc25  f30f104b08               movss xmm1, dword ptr [rbx + 8]
0003bc2a  0f2fc1                   comiss xmm0, xmm1
0003bc2d  77c1                     ja 0x3bbf0
0003bc2f  0f2ec8                   ucomiss xmm1, xmm0
0003bc32  7a0b                     jp 0x3bc3f
0003bc34  b802000000               mov eax, 2
0003bc39  0f8434ffffff             je 0x3bb73
0003bc3f  b804000000               mov eax, 4
0003bc44  e92affffff               jmp 0x3bb73
0003bc49  f20f104708               movsd xmm0, qword ptr [rdi + 8]
0003bc4e  f20f104b08               movsd xmm1, qword ptr [rbx + 8]
0003bc53  660f2fc1                 comisd xmm0, xmm1
0003bc57  7797                     ja 0x3bbf0
0003bc59  660f2ec8                 ucomisd xmm1, xmm0
0003bc5d  ebd3                     jmp 0x3bc32
0003bc5f  488d5708                 lea rdx, [rdi + 8]
0003bc63  488d4b08                 lea rcx, [rbx + 8]
0003bc67  e8a40a0000               call 0x3c710
0003bc6c  e902ffffff               jmp 0x3bb73
0003bc71  0f57c0                   xorps xmm0, xmm0
0003bc74  0f294540                 movaps xmmword ptr [rbp + 0x40], xmm0
0003bc78  0f294550                 movaps xmmword ptr [rbp + 0x50], xmm0
0003bc7c  0f294560                 movaps xmmword ptr [rbp + 0x60], xmm0
0003bc80  0f294570                 movaps xmmword ptr [rbp + 0x70], xmm0
0003bc84  0f298580000000           movaps xmmword ptr [rbp + 0x80], xmm0
0003bc8b  0f298590000000           movaps xmmword ptr [rbp + 0x90], xmm0
0003bc92  0f2985a0000000           movaps xmmword ptr [rbp + 0xa0], xmm0
0003bc99  0f2985b0000000           movaps xmmword ptr [rbp + 0xb0], xmm0
0003bca0  488d35518f0200           lea rsi, [rip + 0x28f51]
0003bca7  48897540                 mov qword ptr [rbp + 0x40], rsi
0003bcab  488d0576910200           lea rax, [rip + 0x29176]
0003bcb2  48894540                 mov qword ptr [rbp + 0x40], rax
0003bcb6  660f7f8580000000         movdqa xmmword ptr [rbp + 0x80], xmm0
0003bcbe  33d2                     xor edx, edx
0003bcc0  48899590000000           mov qword ptr [rbp + 0x90], rdx
0003bcc7  899598000000             mov dword ptr [rbp + 0x98], edx
0003bccd  88959d000000             mov byte ptr [rbp + 0x9d], dl
0003bcd3  488d05568f0200           lea rax, [rip + 0x28f56]
0003bcda  48894540                 mov qword ptr [rbp + 0x40], rax
0003bcde  488d5540                 lea rdx, [rbp + 0x40]
0003bce2  498bc9                   mov rcx, r9
0003bce5  e816cdffff               call 0x38a00
0003bcea  8b4710                   mov eax, dword ptr [rdi + 0x10]
0003bced  488b4f08                 mov rcx, qword ptr [rdi + 8]
0003bcf1  8b5310                   mov edx, dword ptr [rbx + 0x10]
0003bcf4  4c8b4308                 mov r8, qword ptr [rbx + 8]
0003bcf8  89442440                 mov dword ptr [rsp + 0x40], eax
0003bcfc  48894c2438               mov qword ptr [rsp + 0x38], rcx
0003bd01  89542430                 mov dword ptr [rsp + 0x30], edx
0003bd05  4c89442428               mov qword ptr [rsp + 0x28], r8
0003bd0a  488d4540                 lea rax, [rbp + 0x40]
0003bd0e  4889442420               mov qword ptr [rsp + 0x20], rax
0003bd13  448b8d90000000           mov r9d, dword ptr [rbp + 0x90]
0003bd1a  4c8b8588000000           mov r8, qword ptr [rbp + 0x88]
0003bd21  8b9594000000             mov edx, dword ptr [rbp + 0x94]
0003bd27  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
0003bd2e  ff95a0000000             call qword ptr [rbp + 0xa0]
0003bd34  8bd0                     mov edx, eax
0003bd36  85c0                     test eax, eax
0003bd38  7907                     jns 0x3bd41
0003bd3a  b801000000               mov eax, 1
0003bd3f  eb0f                     jmp 0x3bd50
0003bd41  b804000000               mov eax, 4
0003bd46  b902000000               mov ecx, 2
0003bd4b  85d2                     test edx, edx
0003bd4d  0f44c1                   cmove eax, ecx
0003bd50  48897540                 mov qword ptr [rbp + 0x40], rsi
0003bd54  e91afeffff               jmp 0x3bb73
0003bd59  0f57c0                   xorps xmm0, xmm0
0003bd5c  0f294540                 movaps xmmword ptr [rbp + 0x40], xmm0
0003bd60  0f294550                 movaps xmmword ptr [rbp + 0x50], xmm0
0003bd64  0f294560                 movaps xmmword ptr [rbp + 0x60], xmm0
0003bd68  0f294570                 movaps xmmword ptr [rbp + 0x70], xmm0
0003bd6c  0f298580000000           movaps xmmword ptr [rbp + 0x80], xmm0
0003bd73  0f298590000000           movaps xmmword ptr [rbp + 0x90], xmm0
0003bd7a  0f2985a0000000           movaps xmmword ptr [rbp + 0xa0], xmm0
0003bd81  0f2985b0000000           movaps xmmword ptr [rbp + 0xb0], xmm0
0003bd88  488d35698e0200           lea rsi, [rip + 0x28e69]
0003bd8f  48897540                 mov qword ptr [rbp + 0x40], rsi
0003bd93  488d058e900200           lea rax, [rip + 0x2908e]
0003bd9a  48894540                 mov qword ptr [rbp + 0x40], rax
0003bd9e  660f7f8580000000         movdqa xmmword ptr [rbp + 0x80], xmm0
0003bda6  33d2                     xor edx, edx
0003bda8  48899590000000           mov qword ptr [rbp + 0x90], rdx
0003bdaf  899598000000             mov dword ptr [rbp + 0x98], edx
0003bdb5  88959d000000             mov byte ptr [rbp + 0x9d], dl
0003bdbb  488d056e8e0200           lea rax, [rip + 0x28e6e]
0003bdc2  48894540                 mov qword ptr [rbp + 0x40], rax
0003bdc6  488d5540                 lea rdx, [rbp + 0x40]
0003bdca  498bc9                   mov rcx, r9
0003bdcd  e82eccffff               call 0x38a00
0003bdd2  8b4710                   mov eax, dword ptr [rdi + 0x10]
0003bdd5  488b4f08                 mov rcx, qword ptr [rdi + 8]
0003bdd9  8b5310                   mov edx, dword ptr [rbx + 0x10]
0003bddc  4c8b4308                 mov r8, qword ptr [rbx + 8]
0003bde0  89442440                 mov dword ptr [rsp + 0x40], eax
0003bde4  48894c2438               mov qword ptr [rsp + 0x38], rcx
0003bde9  89542430                 mov dword ptr [rsp + 0x30], edx
0003bded  4c89442428               mov qword ptr [rsp + 0x28], r8
0003bdf2  488d4540                 lea rax, [rbp + 0x40]
0003bdf6  4889442420               mov qword ptr [rsp + 0x20], rax
0003bdfb  448b8d90000000           mov r9d, dword ptr [rbp + 0x90]
0003be02  4c8b8588000000           mov r8, qword ptr [rbp + 0x88]
0003be09  8b9594000000             mov edx, dword ptr [rbp + 0x94]
0003be0f  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
0003be16  ff95a0000000             call qword ptr [rbp + 0xa0]
0003be1c  8bd0                     mov edx, eax
0003be1e  85c0                     test eax, eax
0003be20  7907                     jns 0x3be29
0003be22  b801000000               mov eax, 1
0003be27  eb0f                     jmp 0x3be38
0003be29  b804000000               mov eax, 4
0003be2e  b902000000               mov ecx, 2
0003be33  85d2                     test edx, edx
0003be35  0f44c1                   cmove eax, ecx
0003be38  48897540                 mov qword ptr [rbp + 0x40], rsi
0003be3c  e932fdffff               jmp 0x3bb73
0003be41  41f6410110               test byte ptr [r9 + 1], 0x10
0003be46  7425                     je 0x3be6d
0003be48  80faf0                   cmp dl, 0xf0
0003be4b  7420                     je 0x3be6d
0003be4d  410fb6411a               movzx eax, byte ptr [r9 + 0x1a]
0003be52  84c0                     test al, al
0003be54  7917                     jns 0x3be6d
0003be56  c1e804                   shr eax, 4
0003be59  83e007                   and eax, 7
0003be5c  7d07                     jge 0x3be65
0003be5e  ffc8                     dec eax
0003be60  83c8f0                   or eax, 0xfffffff0
0003be63  ffc0                     inc eax
0003be65  3c02                     cmp al, 2
0003be67  0f8404fdffff             je 0x3bb71
0003be6d  448b4f10                 mov r9d, dword ptr [rdi + 0x10]
0003be71  4c8b4708                 mov r8, qword ptr [rdi + 8]
0003be75  8b5310                   mov edx, dword ptr [rbx + 0x10]
0003be78  488b4b08                 mov rcx, qword ptr [rbx + 8]
0003be7c  e8ef2cffff               call 0x2eb70
0003be81  8bd0                     mov edx, eax
0003be83  85c0                     test eax, eax
0003be85  0f89ac000000             jns 0x3bf37
0003be8b  b801000000               mov eax, 1
0003be90  e9defcffff               jmp 0x3bb73
0003be95  488b5308                 mov rdx, qword ptr [rbx + 8]
0003be99  483b5708                 cmp rdx, qword ptr [rdi + 8]
0003be9d  0f8d34fdffff             jge 0x3bbd7
0003bea3  b801000000               mov eax, 1
0003bea8  e9c6fcffff               jmp 0x3bb73
0003bead  8b5308                   mov edx, dword ptr [rbx + 8]
0003beb0  3b5708                   cmp edx, dword ptr [rdi + 8]
0003beb3  0f831efdffff             jae 0x3bbd7
0003beb9  b801000000               mov eax, 1
0003bebe  e9b0fcffff               jmp 0x3bb73
0003bec3  488bd7                   mov rdx, rdi
0003bec6  488bcb                   mov rcx, rbx
0003bec9  e8b234ffff               call 0x2f380
0003bece  e9a0fcffff               jmp 0x3bb73
0003bed3  8b5308                   mov edx, dword ptr [rbx + 8]
0003bed6  3b5708                   cmp edx, dword ptr [rdi + 8]
0003bed9  0f8df8fcffff             jge 0x3bbd7
0003bedf  b801000000               mov eax, 1
0003bee4  e98afcffff               jmp 0x3bb73
0003bee9  488bd7                   mov rdx, rdi
0003beec  488bcb                   mov rcx, rbx
0003beef  e8ec34ffff               call 0x2f3e0
0003bef4  e97afcffff               jmp 0x3bb73
0003bef9  488d4708                 lea rax, [rdi + 8]
0003befd  b908000000               mov ecx, 8
0003bf02  482bd8                   sub rbx, rax
0003bf05  0fb6540308               movzx edx, byte ptr [rbx + rax + 8]
0003bf0a  3a10                     cmp dl, byte ptr [rax]
0003bf0c  751e                     jne 0x3bf2c
0003bf0e  48ffc0                   inc rax
0003bf11  83e901                   sub ecx, 1
0003bf14  75ef                     jne 0x3bf05
0003bf16  33d2                     xor edx, edx
0003bf18  b804000000               mov eax, 4
0003bf1d  b902000000               mov ecx, 2
0003bf22  85d2                     test edx, edx
0003bf24  0f44c1                   cmove eax, ecx
0003bf27  e947fcffff               jmp 0x3bb73
0003bf2c  0f82befcffff             jb 0x3bbf0
0003bf32  ba01000000               mov edx, 1
0003bf37  b804000000               mov eax, 4
0003bf3c  b902000000               mov ecx, 2
0003bf41  85d2                     test edx, edx
0003bf43  0f44c1                   cmove eax, ecx
0003bf46  e928fcffff               jmp 0x3bb73
0003bf4b  410fb64813               movzx ecx, byte ptr [r8 + 0x13]
0003bf50  410fb64113               movzx eax, byte ptr [r9 + 0x13]
0003bf55  488d359c8c0200           lea rsi, [rip + 0x28c9c]
0003bf5c  48897500                 mov qword ptr [rbp], rsi
0003bf60  488d15698f0200           lea rdx, [rip + 0x28f69]
0003bf67  48895500                 mov qword ptr [rbp], rdx
0003bf6b  894508                   mov dword ptr [rbp + 8], eax
0003bf6e  894d0c                   mov dword ptr [rbp + 0xc], ecx
0003bf71  4c8d4500                 lea r8, [rbp]
0003bf75  488bd7                   mov rdx, rdi
0003bf78  488bcb                   mov rcx, rbx
0003bf7b  e82035ffff               call 0x2f4a0
0003bf80  90                       nop
0003bf81  48897500                 mov qword ptr [rbp], rsi
0003bf85  e9e9fbffff               jmp 0x3bb73
0003bf8a  410fb64813               movzx ecx, byte ptr [r8 + 0x13]
0003bf8f  410fb64113               movzx eax, byte ptr [r9 + 0x13]
0003bf94  488d355d8c0200           lea rsi, [rip + 0x28c5d]
0003bf9b  48897500                 mov qword ptr [rbp], rsi
0003bf9f  488d152a8f0200           lea rdx, [rip + 0x28f2a]
0003bfa6  48895500                 mov qword ptr [rbp], rdx
0003bfaa  894508                   mov dword ptr [rbp + 8], eax
0003bfad  894d0c                   mov dword ptr [rbp + 0xc], ecx
0003bfb0  4c8d4500                 lea r8, [rbp]
0003bfb4  488bd7                   mov rdx, rdi
0003bfb7  488bcb                   mov rcx, rbx
0003bfba  e8c136ffff               call 0x2f680
0003bfbf  90                       nop
0003bfc0  48897500                 mov qword ptr [rbp], rsi
0003bfc4  e9aafbffff               jmp 0x3bb73
0003bfc9  410fb64813               movzx ecx, byte ptr [r8 + 0x13]
0003bfce  410fb64113               movzx eax, byte ptr [r9 + 0x13]
0003bfd3  488d351e8c0200           lea rsi, [rip + 0x28c1e]
0003bfda  48897500                 mov qword ptr [rbp], rsi
0003bfde  488d15eb8e0200           lea rdx, [rip + 0x28eeb]
0003bfe5  48895500                 mov qword ptr [rbp], rdx
0003bfe9  894508                   mov dword ptr [rbp + 8], eax
0003bfec  894d0c                   mov dword ptr [rbp + 0xc], ecx
0003bfef  4c8d4500                 lea r8, [rbp]
0003bff3  488bd7                   mov rdx, rdi
0003bff6  488bcb                   mov rcx, rbx
0003bff9  e89238ffff               call 0x2f890
0003bffe  90                       nop
0003bfff  48897500                 mov qword ptr [rbp], rsi
0003c003  e96bfbffff               jmp 0x3bb73
0003c008  71bb                     jno 0x3bfc5
0003c00a  0300                     add eax, dword ptr [rax]
0003c00c  e9be0300c3               jmp 0xffffffffc303c3cf
0003c011  be03004bbf               mov esi, 0xbf4b0003
0003c016  0300                     add eax, dword ptr [rax]
0003c018  8abf0300c9bf             mov bh, byte ptr [rdi - 0x4036fffd]
0003c01e  0300                     add eax, dword ptr [rax]
