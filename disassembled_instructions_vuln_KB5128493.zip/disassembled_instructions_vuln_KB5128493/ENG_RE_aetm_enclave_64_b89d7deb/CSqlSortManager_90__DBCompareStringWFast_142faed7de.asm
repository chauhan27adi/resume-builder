; CSqlSortManager_90::DBCompareStringWFast
; aetm_enclave.dll, primary RVA 0x4a450, 6192 bytes in 3 chunk(s)

; chunk at RVA 0x4a450 (141 bytes)
0004a450  4489442418               mov dword ptr [rsp + 0x18], r8d
0004a455  4889542410               mov qword ptr [rsp + 0x10], rdx
0004a45a  48894c2408               mov qword ptr [rsp + 8], rcx
0004a45f  55                       push rbp
0004a460  56                       push rsi
0004a461  4154                     push r12
0004a463  4156                     push r14
0004a465  4157                     push r15
0004a467  488d6c24d0               lea rbp, [rsp - 0x30]
0004a46c  4881ec30010000           sub rsp, 0x130
0004a473  448bb580000000           mov r14d, dword ptr [rbp + 0x80]
0004a47a  4533d2                   xor r10d, r10d
0004a47d  4c8bbd88000000           mov r15, qword ptr [rbp + 0x88]
0004a484  4d8be1                   mov r12, r9
0004a487  448955b8                 mov dword ptr [rbp - 0x48], r10d
0004a48b  458bc8                   mov r9d, r8d
0004a48e  448955a0                 mov dword ptr [rbp - 0x60], r10d
0004a492  488bf2                   mov rsi, rdx
0004a495  448955b0                 mov dword ptr [rbp - 0x50], r10d
0004a499  458bc2                   mov r8d, r10d
0004a49c  c745fc08000000           mov dword ptr [rbp - 4], 8
0004a4a3  448955e0                 mov dword ptr [rbp - 0x20], r10d
0004a4a7  4585f6                   test r14d, r14d
0004a4aa  7405                     je 0x4a4b1
0004a4ac  4d85e4                   test r12, r12
0004a4af  741a                     je 0x4a4cb
0004a4b1  448b9d90000000           mov r11d, dword ptr [rbp + 0x90]
0004a4b8  4585db                   test r11d, r11d
0004a4bb  7405                     je 0x4a4c2
0004a4bd  4d85ff                   test r15, r15
0004a4c0  7409                     je 0x4a4cb
0004a4c2  41f7c1f8effc77           test r9d, 0x77fceff8
0004a4c9  7412                     je 0x4a4dd
0004a4cb  33c0                     xor eax, eax
0004a4cd  4881c430010000           add rsp, 0x130
0004a4d4  415f                     pop r15
0004a4d6  415e                     pop r14
0004a4d8  415c                     pop r12
0004a4da  5e                       pop rsi
0004a4db  5d                       pop rbp
0004a4dc  c3                       ret

; chunk at RVA 0x4a4dd (5947 bytes)
0004a4dd  4889bc2420010000         mov qword ptr [rsp + 0x120], rdi
0004a4e5  4585f6                   test r14d, r14d
0004a4e8  7911                     jns 0x4a4fb
0004a4ea  498bcc                   mov rcx, r12
0004a4ed  e85ed4ffff               call 0x47950
0004a4f2  448bf0                   mov r14d, eax
0004a4f5  898580000000             mov dword ptr [rbp + 0x80], eax
0004a4fb  4585db                   test r11d, r11d
0004a4fe  7911                     jns 0x4a511
0004a500  498bcf                   mov rcx, r15
0004a503  e848d4ffff               call 0x47950
0004a508  448bd8                   mov r11d, eax
0004a50b  898590000000             mov dword ptr [rbp + 0x90], eax
0004a511  418bc9                   mov ecx, r9d
0004a514  48899c2428010000         mov qword ptr [rsp + 0x128], rbx
0004a51c  c1e910                   shr ecx, 0x10
0004a51f  418bc1                   mov eax, r9d
0004a522  83e103                   and ecx, 3
0004a525  4c89ac2418010000         mov qword ptr [rsp + 0x118], r13
0004a52d  83e003                   and eax, 3
0004a530  bf07000000               mov edi, 7
0004a535  897d88                   mov dword ptr [rbp - 0x78], edi
0004a538  8d0c88                   lea ecx, [rax + rcx*4]
0004a53b  488d05be5afbff           lea rax, [rip - 0x4a542]
0004a542  8b848830050900           mov eax, dword ptr [rax + rcx*4 + 0x90530]
0004a549  448d4ffa                 lea r9d, [rdi - 6]
0004a54d  418bca                   mov ecx, r10d
0004a550  894590                   mov dword ptr [rbp - 0x70], eax
0004a553  0fb702                   movzx eax, word ptr [rdx]
0004a556  ba12040000               mov edx, 0x412
0004a55b  663bc2                   cmp ax, dx
0004a55e  668945a4                 mov word ptr [rbp - 0x5c], ax
0004a562  498bd2                   mov rdx, r10
0004a565  0f94c1                   sete cl
0004a568  488955d0                 mov qword ptr [rbp - 0x30], rdx
0004a56c  894df8                   mov dword ptr [rbp - 8], ecx
0004a56f  498bca                   mov rcx, r10
0004a572  48894de8                 mov qword ptr [rbp - 0x18], rcx
0004a576  448d57fc                 lea r10d, [rdi - 4]
0004a57a  4585f6                   test r14d, r14d
0004a57d  7467                     je 0x4a5e6
0004a57f  4585db                   test r11d, r11d
0004a582  7462                     je 0x4a5e6
0004a584  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004a588  410fb70424               movzx eax, word ptr [r12]
0004a58d  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004a590  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004a594  410fb707                 movzx eax, word ptr [r15]
0004a598  4423ef                   and r13d, edi
0004a59b  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004a59f  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
0004a5a2  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a5a8  8b8d80000000             mov ecx, dword ptr [rbp + 0x80]
0004a5ae  8945e4                   mov dword ptr [rbp - 0x1c], eax
0004a5b1  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a5b7  8945c8                   mov dword ptr [rbp - 0x38], eax
0004a5ba  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a5c0  8945c4                   mov dword ptr [rbp - 0x3c], eax
0004a5c3  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a5c9  8945bc                   mov dword ptr [rbp - 0x44], eax
0004a5cc  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a5d2  8945c0                   mov dword ptr [rbp - 0x40], eax
0004a5d5  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004a5db  8945b4                   mov dword ptr [rbp - 0x4c], eax
0004a5de  894d8c                   mov dword ptr [rbp - 0x74], ecx
0004a5e1  e9ee000000               jmp 0x4a6d4
0004a5e6  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a5ec  8b5d84                   mov ebx, dword ptr [rbp - 0x7c]
0004a5ef  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004a5f5  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004a5f9  8945e4                   mov dword ptr [rbp - 0x1c], eax
0004a5fc  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a602  8945c8                   mov dword ptr [rbp - 0x38], eax
0004a605  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a60b  8945c4                   mov dword ptr [rbp - 0x3c], eax
0004a60e  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a614  8945bc                   mov dword ptr [rbp - 0x44], eax
0004a617  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0004a61d  8945c0                   mov dword ptr [rbp - 0x40], eax
0004a620  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004a626  8945b4                   mov dword ptr [rbp - 0x4c], eax
0004a629  895d98                   mov dword ptr [rbp - 0x68], ebx
0004a62c  89558c                   mov dword ptr [rbp - 0x74], edx
0004a62f  eb0d                     jmp 0x4a63e
0004a631  488b4de8                 mov rcx, qword ptr [rbp - 0x18]
0004a635  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004a638  41ba03000000             mov r10d, 3
0004a63e  f7457000000008           test dword ptr [rbp + 0x70], 0x8000000
0004a645  0f84e2140000             je 0x4bb2d
0004a64b  4585f6                   test r14d, r14d
0004a64e  7547                     jne 0x4a697
0004a650  4585db                   test r11d, r11d
0004a653  0f848a150000             je 0x4bbe3
0004a659  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004a65d  4c8d65d8                 lea r12, [rbp - 0x28]
0004a661  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004a664  b820000000               mov eax, 0x20
0004a669  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
0004a66d  458bf1                   mov r14d, r9d
0004a670  668945d8                 mov word ptr [rbp - 0x28], ax
0004a674  448ba980000000           mov r13d, dword ptr [rcx + 0x80]
0004a67b  4423ef                   and r13d, edi
0004a67e  44898d80000000           mov dword ptr [rbp + 0x80], r9d
0004a685  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004a689  4585c0                   test r8d, r8d
0004a68c  754e                     jne 0x4a6dc
0004a68e  410fb707                 movzx eax, word ptr [r15]
0004a692  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
0004a695  eb3d                     jmp 0x4a6d4
0004a697  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004a69b  b820000000               mov eax, 0x20
0004a6a0  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004a6a3  4c8d7ddc                 lea r15, [rbp - 0x24]
0004a6a7  668945dc                 mov word ptr [rbp - 0x24], ax
0004a6ab  458bd9                   mov r11d, r9d
0004a6ae  44898d90000000           mov dword ptr [rbp + 0x90], r9d
0004a6b5  4585c0                   test r8d, r8d
0004a6b8  7510                     jne 0x4a6ca
0004a6ba  410fb70424               movzx eax, word ptr [r12]
0004a6bf  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004a6c3  4423ef                   and r13d, edi
0004a6c6  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004a6ca  8b9980000000             mov ebx, dword ptr [rcx + 0x80]
0004a6d0  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
0004a6d4  23df                     and ebx, edi
0004a6d6  895d84                   mov dword ptr [rbp - 0x7c], ebx
0004a6d9  895d98                   mov dword ptr [rbp - 0x68], ebx
0004a6dc  4533d2                   xor r10d, r10d
0004a6df  90                       nop
0004a6e0  837e1400                 cmp dword ptr [rsi + 0x14], 0
0004a6e4  448955a8                 mov dword ptr [rbp - 0x58], r10d
0004a6e8  448955f0                 mov dword ptr [rbp - 0x10], r10d
0004a6ec  0f84e5020000             je 0x4a9d7
0004a6f2  4885d2                   test rdx, rdx
0004a6f5  0f856d010000             jne 0x4a868
0004a6fb  418bc5                   mov eax, r13d
0004a6fe  c1e818                   shr eax, 0x18
0004a701  a8c0                     test al, 0xc0
0004a703  0f845f010000             je 0x4a868
0004a709  395618                   cmp dword ptr [rsi + 0x18], edx
0004a70c  7438                     je 0x4a746
0004a70e  4183fe01                 cmp r14d, 1
0004a712  7e2e                     jle 0x4a742
0004a714  410fb74c2402             movzx ecx, word ptr [r12 + 2]
0004a71a  418bd5                   mov edx, r13d
0004a71d  488b4608                 mov rax, qword ptr [rsi + 8]
0004a721  331488                   xor edx, dword ptr [rax + rcx*4]
0004a724  23d7                     and edx, edi
0004a726  f7c2ffffffe7             test edx, 0xe7ffffff
0004a72c  7514                     jne 0x4a742
0004a72e  4983c402                 add r12, 2
0004a732  44894db8                 mov dword ptr [rbp - 0x48], r9d
0004a736  41ffce                   dec r14d
0004a739  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004a740  eb04                     jmp 0x4a746
0004a742  448955b8                 mov dword ptr [rbp - 0x48], r10d
0004a746  33d2                     xor edx, edx
0004a748  418bce                   mov ecx, r14d
0004a74b  440fb7ca                 movzx r9d, dx
0004a74f  83e901                   sub ecx, 1
0004a752  7411                     je 0x4a765
0004a754  83f901                   cmp ecx, 1
0004a757  7406                     je 0x4a75f
0004a759  450fb7542404             movzx r10d, word ptr [r12 + 4]
0004a75f  450fb74c2402             movzx r9d, word ptr [r12 + 2]
0004a765  4c8b4620                 mov r8, qword ptr [rsi + 0x20]
0004a769  410fb70c24               movzx ecx, word ptr [r12]
0004a76e  410fb74004               movzx eax, word ptr [r8 + 4]
0004a773  85c0                     test eax, eax
0004a775  0f84d0000000             je 0x4a84b
0004a77b  0f1f440000               nop dword ptr [rax + rax]
0004a780  6641394806               cmp word ptr [r8 + 6], cx
0004a785  760e                     jbe 0x4a795
0004a787  4983c010                 add r8, 0x10
0004a78b  83e801                   sub eax, 1
0004a78e  75f0                     jne 0x4a780
0004a790  e9b6000000               jmp 0x4a84b
0004a795  0f85b0000000             jne 0x4a84b
0004a79b  66453b480c               cmp r9w, word ptr [r8 + 0xc]
0004a7a0  0f82a5000000             jb 0x4a84b
0004a7a6  66453b480e               cmp r9w, word ptr [r8 + 0xe]
0004a7ab  0f879a000000             ja 0x4a84b
0004a7b1  488b4628                 mov rax, qword ptr [rsi + 0x28]
0004a7b5  410fb74808               movzx ecx, word ptr [r8 + 8]
0004a7ba  488d14c8                 lea rdx, [rax + rcx*8]
0004a7be  410fb7400a               movzx eax, word ptr [r8 + 0xa]
0004a7c3  85c0                     test eax, eax
0004a7c5  0f8480000000             je 0x4a84b
0004a7cb  0f1f440000               nop dword ptr [rax + rax]
0004a7d0  6644390a                 cmp word ptr [rdx], r9w
0004a7d4  760f                     jbe 0x4a7e5
0004a7d6  4883c208                 add rdx, 8
0004a7da  83e801                   sub eax, 1
0004a7dd  75f1                     jne 0x4a7d0
0004a7df  eb6a                     jmp 0x4a84b
0004a7e1  6644390a                 cmp word ptr [rdx], r9w
0004a7e5  7564                     jne 0x4a84b
0004a7e7  0fb74a02                 movzx ecx, word ptr [rdx + 2]
0004a7eb  6685c9                   test cx, cx
0004a7ee  742c                     je 0x4a81c
0004a7f0  66413bca                 cmp cx, r10w
0004a7f4  740b                     je 0x4a801
0004a7f6  4883c208                 add rdx, 8
0004a7fa  83e801                   sub eax, 1
0004a7fd  75e2                     jne 0x4a7e1
0004a7ff  eb4a                     jmp 0x4a84b
0004a801  837db800                 cmp dword ptr [rbp - 0x48], 0
0004a805  750f                     jne 0x4a816
0004a807  4983c404                 add r12, 4
0004a80b  4183ee02                 sub r14d, 2
0004a80f  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004a816  410fb7ca                 movzx ecx, r10w
0004a81a  eb18                     jmp 0x4a834
0004a81c  837db800                 cmp dword ptr [rbp - 0x48], 0
0004a820  750e                     jne 0x4a830
0004a822  4983c402                 add r12, 2
0004a826  41ffce                   dec r14d
0004a829  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004a830  410fb7c9                 movzx ecx, r9w
0004a834  488b4608                 mov rax, qword ptr [rsi + 8]
0004a838  448b6a04                 mov r13d, dword ptr [rdx + 4]
0004a83c  4423ef                   and r13d, edi
0004a83f  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004a843  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004a846  23c7                     and eax, edi
0004a848  8945a0                   mov dword ptr [rbp - 0x60], eax
0004a84b  837db800                 cmp dword ptr [rbp - 0x48], 0
0004a84f  41b901000000             mov r9d, 1
0004a855  740e                     je 0x4a865
0004a857  4983ec02                 sub r12, 2
0004a85b  41ffc6                   inc r14d
0004a85e  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004a865  4533d2                   xor r10d, r10d
0004a868  48837de800               cmp qword ptr [rbp - 0x18], 0
0004a86d  0f8564010000             jne 0x4a9d7
0004a873  f64587c0                 test byte ptr [rbp - 0x79], 0xc0
0004a877  0f845a010000             je 0x4a9d7
0004a87d  837e1800                 cmp dword ptr [rsi + 0x18], 0
0004a881  743b                     je 0x4a8be
0004a883  4183fb01                 cmp r11d, 1
0004a887  7e2f                     jle 0x4a8b8
0004a889  410fb74f02               movzx ecx, word ptr [r15 + 2]
0004a88e  8bd3                     mov edx, ebx
0004a890  488b4608                 mov rax, qword ptr [rsi + 8]
0004a894  331488                   xor edx, dword ptr [rax + rcx*4]
0004a897  23d7                     and edx, edi
0004a899  f7c2ffffffe7             test edx, 0xe7ffffff
0004a89f  7517                     jne 0x4a8b8
0004a8a1  4983c702                 add r15, 2
0004a8a5  44894db8                 mov dword ptr [rbp - 0x48], r9d
0004a8a9  41ffcb                   dec r11d
0004a8ac  458bd1                   mov r10d, r9d
0004a8af  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004a8b6  eb0a                     jmp 0x4a8c2
0004a8b8  448955b8                 mov dword ptr [rbp - 0x48], r10d
0004a8bc  eb04                     jmp 0x4a8c2
0004a8be  448b55b8                 mov r10d, dword ptr [rbp - 0x48]
0004a8c2  33c0                     xor eax, eax
0004a8c4  418bcb                   mov ecx, r11d
0004a8c7  440fb7c8                 movzx r9d, ax
0004a8cb  440fb7c0                 movzx r8d, ax
0004a8cf  83e901                   sub ecx, 1
0004a8d2  740f                     je 0x4a8e3
0004a8d4  83f901                   cmp ecx, 1
0004a8d7  7405                     je 0x4a8de
0004a8d9  450fb74f04               movzx r9d, word ptr [r15 + 4]
0004a8de  450fb74702               movzx r8d, word ptr [r15 + 2]
0004a8e3  488b5620                 mov rdx, qword ptr [rsi + 0x20]
0004a8e7  410fb70f                 movzx ecx, word ptr [r15]
0004a8eb  0fb74204                 movzx eax, word ptr [rdx + 4]
0004a8ef  85c0                     test eax, eax
0004a8f1  0f84cd000000             je 0x4a9c4
0004a8f7  66394a06                 cmp word ptr [rdx + 6], cx
0004a8fb  760e                     jbe 0x4a90b
0004a8fd  4883c210                 add rdx, 0x10
0004a901  83e801                   sub eax, 1
0004a904  75f1                     jne 0x4a8f7
0004a906  e9b9000000               jmp 0x4a9c4
0004a90b  0f85b3000000             jne 0x4a9c4
0004a911  66443b420c               cmp r8w, word ptr [rdx + 0xc]
0004a916  0f82a8000000             jb 0x4a9c4
0004a91c  66443b420e               cmp r8w, word ptr [rdx + 0xe]
0004a921  0f879d000000             ja 0x4a9c4
0004a927  0fb74a08                 movzx ecx, word ptr [rdx + 8]
0004a92b  488b4628                 mov rax, qword ptr [rsi + 0x28]
0004a92f  488d04c8                 lea rax, [rax + rcx*8]
0004a933  0fb74a0a                 movzx ecx, word ptr [rdx + 0xa]
0004a937  85c9                     test ecx, ecx
0004a939  0f8485000000             je 0x4a9c4
0004a93f  90                       nop
0004a940  66443900                 cmp word ptr [rax], r8w
0004a944  760f                     jbe 0x4a955
0004a946  4883c008                 add rax, 8
0004a94a  83e901                   sub ecx, 1
0004a94d  75f1                     jne 0x4a940
0004a94f  eb73                     jmp 0x4a9c4
0004a951  66443900                 cmp word ptr [rax], r8w
0004a955  756d                     jne 0x4a9c4
0004a957  0fb75002                 movzx edx, word ptr [rax + 2]
0004a95b  6685d2                   test dx, dx
0004a95e  7436                     je 0x4a996
0004a960  66413bd1                 cmp dx, r9w
0004a964  740b                     je 0x4a971
0004a966  4883c008                 add rax, 8
0004a96a  83e901                   sub ecx, 1
0004a96d  75e2                     jne 0x4a951
0004a96f  eb53                     jmp 0x4a9c4
0004a971  4585d2                   test r10d, r10d
0004a974  750f                     jne 0x4a985
0004a976  4983c704                 add r15, 4
0004a97a  4183eb02                 sub r11d, 2
0004a97e  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004a985  8b5004                   mov edx, dword ptr [rax + 4]
0004a988  23d7                     and edx, edi
0004a98a  410fb7c9                 movzx ecx, r9w
0004a98e  895598                   mov dword ptr [rbp - 0x68], edx
0004a991  895584                   mov dword ptr [rbp - 0x7c], edx
0004a994  eb22                     jmp 0x4a9b8
0004a996  4585d2                   test r10d, r10d
0004a999  750e                     jne 0x4a9a9
0004a99b  4983c702                 add r15, 2
0004a99f  41ffcb                   dec r11d
0004a9a2  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004a9a9  8b4004                   mov eax, dword ptr [rax + 4]
0004a9ac  23c7                     and eax, edi
0004a9ae  410fb7c8                 movzx ecx, r8w
0004a9b2  894598                   mov dword ptr [rbp - 0x68], eax
0004a9b5  894584                   mov dword ptr [rbp - 0x7c], eax
0004a9b8  488b4608                 mov rax, qword ptr [rsi + 8]
0004a9bc  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004a9bf  23c7                     and eax, edi
0004a9c1  8945b0                   mov dword ptr [rbp - 0x50], eax
0004a9c4  4585d2                   test r10d, r10d
0004a9c7  740e                     je 0x4a9d7
0004a9c9  4983ef02                 sub r15, 2
0004a9cd  41ffc3                   inc r11d
0004a9d0  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004a9d7  440fb74d80               movzx r9d, word ptr [rbp - 0x80]
0004a9dc  440fb75584               movzx r10d, word ptr [rbp - 0x7c]
0004a9e1  410fb7f9                 movzx edi, r9w
0004a9e5  410fb7da                 movzx ebx, r10w
0004a9e9  66c1ef08                 shr di, 8
0004a9ed  66c1eb08                 shr bx, 8
0004a9f1  6644898d88000000         mov word ptr [rbp + 0x88], r9w
0004a9f9  6644895578               mov word ptr [rbp + 0x78], r10w
0004a9fe  4080ff0b                 cmp dil, 0xb
0004aa02  7614                     jbe 0x4aa18
0004aa04  80fb0b                   cmp bl, 0xb
0004aa07  7649                     jbe 0x4aa52
0004aa09  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004aa0c  895db0                   mov dword ptr [rbp - 0x50], ebx
0004aa0f  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004aa13  e9490f0000               jmp 0x4b961
0004aa18  4084ff                   test dil, dil
0004aa1b  7535                     jne 0x4aa52
0004aa1d  448b4590                 mov r8d, dword ptr [rbp - 0x70]
0004aa21  4983c402                 add r12, 2
0004aa25  4183ee01                 sub r14d, 1
0004aa29  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004aa30  7414                     je 0x4aa46
0004aa32  410fb70c24               movzx ecx, word ptr [r12]
0004aa37  488b4608                 mov rax, qword ptr [rsi + 8]
0004aa3b  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004aa3f  4523e8                   and r13d, r8d
0004aa42  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004aa46  ba01000000               mov edx, 1
0004aa4b  8bc2                     mov eax, edx
0004aa4d  8955a8                   mov dword ptr [rbp - 0x58], edx
0004aa50  eb0c                     jmp 0x4aa5e
0004aa52  448b4590                 mov r8d, dword ptr [rbp - 0x70]
0004aa56  ba01000000               mov edx, 1
0004aa5b  8b45a8                   mov eax, dword ptr [rbp - 0x58]
0004aa5e  84db                     test bl, bl
0004aa60  752a                     jne 0x4aa8c
0004aa62  4983c702                 add r15, 2
0004aa66  4183eb01                 sub r11d, 1
0004aa6a  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004aa71  7414                     je 0x4aa87
0004aa73  410fb70f                 movzx ecx, word ptr [r15]
0004aa77  488b4608                 mov rax, qword ptr [rsi + 8]
0004aa7b  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004aa7e  4123c0                   and eax, r8d
0004aa81  894598                   mov dword ptr [rbp - 0x68], eax
0004aa84  894584                   mov dword ptr [rbp - 0x7c], eax
0004aa87  8bc2                     mov eax, edx
0004aa89  8955a8                   mov dword ptr [rbp - 0x58], edx
0004aa8c  8b7570                   mov esi, dword ptr [rbp + 0x70]
0004aa8f  83e602                   and esi, 2
0004aa92  7467                     je 0x4aafb
0004aa94  4080ff01                 cmp dil, 1
0004aa98  752e                     jne 0x4aac8
0004aa9a  4983c402                 add r12, 2
0004aa9e  4183ee01                 sub r14d, 1
0004aaa2  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004aaa9  7418                     je 0x4aac3
0004aaab  4c8b6d68                 mov r13, qword ptr [rbp + 0x68]
0004aaaf  410fb70c24               movzx ecx, word ptr [r12]
0004aab4  498b4508                 mov rax, qword ptr [r13 + 8]
0004aab8  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004aabc  4523e8                   and r13d, r8d
0004aabf  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004aac3  8bc2                     mov eax, edx
0004aac5  8955a8                   mov dword ptr [rbp - 0x58], edx
0004aac8  80fb01                   cmp bl, 1
0004aacb  752e                     jne 0x4aafb
0004aacd  4983c702                 add r15, 2
0004aad1  4183eb01                 sub r11d, 1
0004aad5  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004aadc  7418                     je 0x4aaf6
0004aade  488b4568                 mov rax, qword ptr [rbp + 0x68]
0004aae2  410fb70f                 movzx ecx, word ptr [r15]
0004aae6  488b4008                 mov rax, qword ptr [rax + 8]
0004aaea  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004aaed  4123c0                   and eax, r8d
0004aaf0  894598                   mov dword ptr [rbp - 0x68], eax
0004aaf3  894584                   mov dword ptr [rbp - 0x7c], eax
0004aaf6  8bc2                     mov eax, edx
0004aaf8  8955a8                   mov dword ptr [rbp - 0x58], edx
0004aafb  498bd7                   mov rdx, r15
0004aafe  4d8bc4                   mov r8, r12
0004ab01  4080ff02                 cmp dil, 2
0004ab05  756a                     jne 0x4ab71
0004ab07  0fb64580                 movzx eax, byte ptr [rbp - 0x80]
0004ab0b  4c8d2dee54fbff           lea r13, [rip - 0x4ab12]
0004ab12  41ffc6                   inc r14d
0004ab15  c745e402000000           mov dword ptr [rbp - 0x1c], 2
0004ab1c  4c8d65d8                 lea r12, [rbp - 0x28]
0004ab20  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004ab27  410fb78c85d0a33100       movzx ecx, word ptr [r13 + rax*4 + 0x31a3d0]
0004ab30  410fb78485d2a33100       movzx eax, word ptr [r13 + rax*4 + 0x31a3d2]
0004ab39  668945da                 mov word ptr [rbp - 0x26], ax
0004ab3d  488b4568                 mov rax, qword ptr [rbp + 0x68]
0004ab41  66894dd8                 mov word ptr [rbp - 0x28], cx
0004ab45  488b4008                 mov rax, qword ptr [rax + 8]
0004ab49  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004ab4d  33c0                     xor eax, eax
0004ab4f  488b4dd0                 mov rcx, qword ptr [rbp - 0x30]
0004ab53  44236d90                 and r13d, dword ptr [rbp - 0x70]
0004ab57  4885c9                   test rcx, rcx
0004ab5a  8945a0                   mov dword ptr [rbp - 0x60], eax
0004ab5d  b801000000               mov eax, 1
0004ab62  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004ab66  4c0f45c1                 cmovne r8, rcx
0004ab6a  8945a8                   mov dword ptr [rbp - 0x58], eax
0004ab6d  4c8945d0                 mov qword ptr [rbp - 0x30], r8
0004ab71  80fb02                   cmp bl, 2
0004ab74  7574                     jne 0x4abea
0004ab76  0fb64584                 movzx eax, byte ptr [rbp - 0x7c]
0004ab7a  4c8d057f54fbff           lea r8, [rip - 0x4ab81]
0004ab81  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004ab85  4c8d7ddc                 lea r15, [rbp - 0x24]
0004ab89  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004ab8c  41ffc3                   inc r11d
0004ab8f  4533d2                   xor r10d, r10d
0004ab92  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004ab99  410fb78c80d0a33100       movzx ecx, word ptr [r8 + rax*4 + 0x31a3d0]
0004aba2  41b901000000             mov r9d, 1
0004aba8  410fb78480d2a33100       movzx eax, word ptr [r8 + rax*4 + 0x31a3d2]
0004abb1  458bc1                   mov r8d, r9d
0004abb4  66894ddc                 mov word ptr [rbp - 0x24], cx
0004abb8  668945de                 mov word ptr [rbp - 0x22], ax
0004abbc  488b4608                 mov rax, qword ptr [rsi + 8]
0004abc0  c745c802000000           mov dword ptr [rbp - 0x38], 2
0004abc7  448955b0                 mov dword ptr [rbp - 0x50], r10d
0004abcb  8b1c88                   mov ebx, dword ptr [rax + rcx*4]
0004abce  488b4de8                 mov rcx, qword ptr [rbp - 0x18]
0004abd2  23df                     and ebx, edi
0004abd4  4885c9                   test rcx, rcx
0004abd7  895d98                   mov dword ptr [rbp - 0x68], ebx
0004abda  895d84                   mov dword ptr [rbp - 0x7c], ebx
0004abdd  480f45d1                 cmovne rdx, rcx
0004abe1  488bca                   mov rcx, rdx
0004abe4  488955e8                 mov qword ptr [rbp - 0x18], rdx
0004abe8  eb1f                     jmp 0x4ac09
0004abea  85c0                     test eax, eax
0004abec  7439                     je 0x4ac27
0004abee  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004abf1  41b901000000             mov r9d, 1
0004abf7  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004abfb  4533d2                   xor r10d, r10d
0004abfe  448b45a8                 mov r8d, dword ptr [rbp - 0x58]
0004ac02  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004ac05  488b4de8                 mov rcx, qword ptr [rbp - 0x18]
0004ac09  8b558c                   mov edx, dword ptr [rbp - 0x74]
0004ac0c  4585f6                   test r14d, r14d
0004ac0f  0f8420faffff             je 0x4a635
0004ac15  4585db                   test r11d, r11d
0004ac18  0f8417faffff             je 0x4a635
0004ac1e  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
0004ac22  e9b9faffff               jmp 0x4a6e0
0004ac27  400fb6c7                 movzx eax, dil
0004ac2b  83f806                   cmp eax, 6
0004ac2e  0f8700030000             ja 0x4af34
0004ac34  488d15c553fbff           lea rdx, [rip - 0x4ac3b]
0004ac3b  8b8c8218bc0400           mov ecx, dword ptr [rdx + rax*4 + 0x4bc18]
0004ac42  4803ca                   add rcx, rdx
0004ac45  ffe1                     jmp rcx
0004ac47  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
0004ac4b  403adf                   cmp bl, dil
0004ac4e  0f84e8020000             je 0x4af3c
0004ac54  837d8800                 cmp dword ptr [rbp - 0x78], 0
0004ac58  7f07                     jg 0x4ac61
0004ac5a  4183781000               cmp dword ptr [r8 + 0x10], 0
0004ac5f  740c                     je 0x4ac6d
0004ac61  33c0                     xor eax, eax
0004ac63  c7458c03000000           mov dword ptr [rbp - 0x74], 3
0004ac6a  894588                   mov dword ptr [rbp - 0x78], eax
0004ac6d  418d46ff                 lea eax, [r14 - 1]
0004ac71  85c0                     test eax, eax
0004ac73  7427                     je 0x4ac9c
0004ac75  498b5008                 mov rdx, qword ptr [r8 + 8]
0004ac79  0f1f8000000000           nop dword ptr [rax]
0004ac80  410fb7442402             movzx eax, word ptr [r12 + 2]
0004ac86  807c820101               cmp byte ptr [rdx + rax*4 + 1], 1
0004ac8b  750f                     jne 0x4ac9c
0004ac8d  41ffce                   dec r14d
0004ac90  4983c402                 add r12, 2
0004ac94  418d46ff                 lea eax, [r14 - 1]
0004ac98  85c0                     test eax, eax
0004ac9a  75e4                     jne 0x4ac80
0004ac9c  4983c402                 add r12, 2
0004aca0  4183ee01                 sub r14d, 1
0004aca4  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004acab  7415                     je 0x4acc2
0004acad  498b4008                 mov rax, qword ptr [r8 + 8]
0004acb1  410fb70c24               movzx ecx, word ptr [r12]
0004acb6  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004acba  44236d90                 and r13d, dword ptr [rbp - 0x70]
0004acbe  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004acc2  c745a801000000           mov dword ptr [rbp - 0x58], 1
0004acc9  e96a020000               jmp 0x4af38
0004acce  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004acd2  80fb06                   cmp bl, 6
0004acd5  0f845d020000             je 0x4af38
0004acdb  8b4d88                   mov ecx, dword ptr [rbp - 0x78]
0004acde  83f906                   cmp ecx, 6
0004ace1  7f08                     jg 0x4aceb
0004ace3  7527                     jne 0x4ad0c
0004ace5  837dc400                 cmp dword ptr [rbp - 0x3c], 0
0004ace9  7521                     jne 0x4ad0c
0004aceb  33c0                     xor eax, eax
0004aced  c745c401000000           mov dword ptr [rbp - 0x3c], 1
0004acf4  83f906                   cmp ecx, 6
0004acf7  c7458c03000000           mov dword ptr [rbp - 0x74], 3
0004acfe  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004ad05  0f4e45bc                 cmovle eax, dword ptr [rbp - 0x44]
0004ad09  8945bc                   mov dword ptr [rbp - 0x44], eax
0004ad0c  4983c402                 add r12, 2
0004ad10  4183ee01                 sub r14d, 1
0004ad14  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004ad1b  74a5                     je 0x4acc2
0004ad1d  488b4568                 mov rax, qword ptr [rbp + 0x68]
0004ad21  488b4008                 mov rax, qword ptr [rax + 8]
0004ad25  eb8a                     jmp 0x4acb1
0004ad27  80fb06                   cmp bl, 6
0004ad2a  0f8408020000             je 0x4af38
0004ad30  80fb01                   cmp bl, 1
0004ad33  0f84ff010000             je 0x4af38
0004ad39  8b45b0                   mov eax, dword ptr [rbp - 0x50]
0004ad3c  4c8d8d80000000           lea r9, [rbp + 0x80]
0004ad43  488b5568                 mov rdx, qword ptr [rbp + 0x68]
0004ad47  4c8d4598                 lea r8, [rbp - 0x68]
0004ad4b  33c9                     xor ecx, ecx
0004ad4d  4c896598                 mov qword ptr [rbp - 0x68], r12
0004ad51  894da0                   mov dword ptr [rbp - 0x60], ecx
0004ad54  80fb04                   cmp bl, 4
0004ad57  4c897d00                 mov qword ptr [rbp], r15
0004ad5b  0f44c1                   cmove eax, ecx
0004ad5e  c745f001000000           mov dword ptr [rbp - 0x10], 1
0004ad65  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0004ad69  8945b0                   mov dword ptr [rbp - 0x50], eax
0004ad6c  8b45f8                   mov eax, dword ptr [rbp - 8]
0004ad6f  89442478                 mov dword ptr [rsp + 0x78], eax
0004ad73  488d45e0                 lea rax, [rbp - 0x20]
0004ad77  4889442470               mov qword ptr [rsp + 0x70], rax
0004ad7c  488d45fc                 lea rax, [rbp - 4]
0004ad80  4889442468               mov qword ptr [rsp + 0x68], rax
0004ad85  488d4578                 lea rax, [rbp + 0x78]
0004ad89  4889442460               mov qword ptr [rsp + 0x60], rax
0004ad8e  488d8588000000           lea rax, [rbp + 0x88]
0004ad95  4889442458               mov qword ptr [rsp + 0x58], rax
0004ad9a  488d4584                 lea rax, [rbp - 0x7c]
0004ad9e  4889442448               mov qword ptr [rsp + 0x48], rax
0004ada3  488d8590000000           lea rax, [rbp + 0x90]
0004adaa  44895c2440               mov dword ptr [rsp + 0x40], r11d
0004adaf  4889442438               mov qword ptr [rsp + 0x38], rax
0004adb4  488d4500                 lea rax, [rbp]
0004adb8  4889442430               mov qword ptr [rsp + 0x30], rax
0004adbd  488d4580                 lea rax, [rbp - 0x80]
0004adc1  4889442428               mov qword ptr [rsp + 0x28], rax
0004adc6  4489742420               mov dword ptr [rsp + 0x20], r14d
0004adcb  e8705b0000               call 0x50940
0004add0  8bc8                     mov ecx, eax
0004add2  8945a8                   mov dword ptr [rbp - 0x58], eax
0004add5  8b45e0                   mov eax, dword ptr [rbp - 0x20]
0004add8  83f802                   cmp eax, 2
0004addb  0f850f0e0000             jne 0x4bbf0
0004ade1  4c8b6598                 mov r12, qword ptr [rbp - 0x68]
0004ade5  4c8b7d00                 mov r15, qword ptr [rbp]
0004ade9  448bb580000000           mov r14d, dword ptr [rbp + 0x80]
0004adf0  448b9d90000000           mov r11d, dword ptr [rbp + 0x90]
0004adf7  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
0004adfb  440fb78d88000000         movzx r9d, word ptr [rbp + 0x88]
0004ae03  440fb75578               movzx r10d, word ptr [rbp + 0x78]
0004ae08  85c9                     test ecx, ecx
0004ae0a  7434                     je 0x4ae40
0004ae0c  4585f6                   test r14d, r14d
0004ae0f  7e2f                     jle 0x4ae40
0004ae11  4585db                   test r11d, r11d
0004ae14  7e2a                     jle 0x4ae40
0004ae16  498b4808                 mov rcx, qword ptr [r8 + 8]
0004ae1a  410fb70424               movzx eax, word ptr [r12]
0004ae1f  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004ae23  44236d90                 and r13d, dword ptr [rbp - 0x70]
0004ae27  410fb707                 movzx eax, word ptr [r15]
0004ae2b  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004ae2f  8b1481                   mov edx, dword ptr [rcx + rax*4]
0004ae32  235590                   and edx, dword ptr [rbp - 0x70]
0004ae35  895598                   mov dword ptr [rbp - 0x68], edx
0004ae38  895584                   mov dword ptr [rbp - 0x7c], edx
0004ae3b  e9ff000000               jmp 0x4af3f
0004ae40  8b5584                   mov edx, dword ptr [rbp - 0x7c]
0004ae43  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004ae47  895598                   mov dword ptr [rbp - 0x68], edx
0004ae4a  e9f0000000               jmp 0x4af3f
0004ae4f  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
0004ae53  410fb70424               movzx eax, word ptr [r12]
0004ae58  498b4808                 mov rcx, qword ptr [r8 + 8]
0004ae5c  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004ae60  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004ae64  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004ae68  80fb05                   cmp bl, 5
0004ae6b  7560                     jne 0x4aecd
0004ae6d  410fb707                 movzx eax, word ptr [r15]
0004ae71  450fb6cd                 movzx r9d, r13b
0004ae75  6641c1e108               shl r9w, 8
0004ae7a  8b1481                   mov edx, dword ptr [rcx + rax*4]
0004ae7d  8bc2                     mov eax, edx
0004ae7f  c1e810                   shr eax, 0x10
0004ae82  418bcd                   mov ecx, r13d
0004ae85  440fb6d0                 movzx r10d, al
0004ae89  0fb6c2                   movzx eax, dl
0004ae8c  66c1e008                 shl ax, 8
0004ae90  66440bd0                 or r10w, ax
0004ae94  c1e910                   shr ecx, 0x10
0004ae97  0fb6c1                   movzx eax, cl
0004ae9a  66440bc8                 or r9w, ax
0004ae9e  895598                   mov dword ptr [rbp - 0x68], edx
0004aea1  b812040000               mov eax, 0x412
0004aea6  895584                   mov dword ptr [rbp - 0x7c], edx
0004aea9  6644895578               mov word ptr [rbp + 0x78], r10w
0004aeae  6644898d88000000         mov word ptr [rbp + 0x88], r9w
0004aeb6  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004aeba  743d                     je 0x4aef9
0004aebc  b8fffe0000               mov eax, 0xfeff
0004aec1  668945a0                 mov word ptr [rbp - 0x60], ax
0004aec5  8b45a0                   mov eax, dword ptr [rbp - 0x60]
0004aec8  8945a0                   mov dword ptr [rbp - 0x60], eax
0004aecb  eb72                     jmp 0x4af3f
0004aecd  8b5598                   mov edx, dword ptr [rbp - 0x68]
0004aed0  b812040000               mov eax, 0x412
0004aed5  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004aed9  753e                     jne 0x4af19
0004aedb  450fb68846010000         movzx r9d, byte ptr [r8 + 0x146]
0004aee3  b8ff000000               mov eax, 0xff
0004aee8  6641c1e108               shl r9w, 8
0004aeed  66440bc8                 or r9w, ax
0004aef1  6644898d88000000         mov word ptr [rbp + 0x88], r9w
0004aef9  410fb68046010000         movzx eax, byte ptr [r8 + 0x146]
0004af01  b9ff000000               mov ecx, 0xff
0004af06  66c1e008                 shl ax, 8
0004af0a  660bc1                   or ax, cx
0004af0d  668945a0                 mov word ptr [rbp - 0x60], ax
0004af11  8b45a0                   mov eax, dword ptr [rbp - 0x60]
0004af14  8945a0                   mov dword ptr [rbp - 0x60], eax
0004af17  eb26                     jmp 0x4af3f
0004af19  b8fffe0000               mov eax, 0xfeff
0004af1e  668945a0                 mov word ptr [rbp - 0x60], ax
0004af22  448bc8                   mov r9d, eax
0004af25  66898588000000           mov word ptr [rbp + 0x88], ax
0004af2c  8b45a0                   mov eax, dword ptr [rbp - 0x60]
0004af2f  8945a0                   mov dword ptr [rbp - 0x60], eax
0004af32  eb0b                     jmp 0x4af3f
0004af34  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004af38  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
0004af3c  8b5598                   mov edx, dword ptr [rbp - 0x68]
0004af3f  0fb6c3                   movzx eax, bl
0004af42  83f806                   cmp eax, 6
0004af45  0f876d040000             ja 0x4b3b8
0004af4b  488d0dae50fbff           lea rcx, [rip - 0x4af52]
0004af52  8b8c8134bc0400           mov ecx, dword ptr [rcx + rax*4 + 0x4bc34]
0004af59  488d05a050fbff           lea rax, [rip - 0x4af60]
0004af60  4803c8                   add rcx, rax
0004af63  ffe1                     jmp rcx
0004af65  403adf                   cmp bl, dil
0004af68  0f844d040000             je 0x4b3bb
0004af6e  837d8800                 cmp dword ptr [rbp - 0x78], 0
0004af72  7f07                     jg 0x4af7b
0004af74  4183781000               cmp dword ptr [r8 + 0x10], 0
0004af79  7411                     je 0x4af8c
0004af7b  41b901000000             mov r9d, 1
0004af81  33c0                     xor eax, eax
0004af83  44894d8c                 mov dword ptr [rbp - 0x74], r9d
0004af87  894588                   mov dword ptr [rbp - 0x78], eax
0004af8a  eb06                     jmp 0x4af92
0004af8c  41b901000000             mov r9d, 1
0004af92  418d43ff                 lea eax, [r11 - 1]
0004af96  85c0                     test eax, eax
0004af98  7421                     je 0x4afbb
0004af9a  498b5008                 mov rdx, qword ptr [r8 + 8]
0004af9e  6690                     nop
0004afa0  410fb74702               movzx eax, word ptr [r15 + 2]
0004afa5  807c820101               cmp byte ptr [rdx + rax*4 + 1], 1
0004afaa  750f                     jne 0x4afbb
0004afac  41ffcb                   dec r11d
0004afaf  4983c702                 add r15, 2
0004afb3  418d43ff                 lea eax, [r11 - 1]
0004afb7  85c0                     test eax, eax
0004afb9  75e5                     jne 0x4afa0
0004afbb  4983c702                 add r15, 2
0004afbf  4183eb01                 sub r11d, 1
0004afc3  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004afca  7414                     je 0x4afe0
0004afcc  410fb70f                 movzx ecx, word ptr [r15]
0004afd0  498b4008                 mov rax, qword ptr [r8 + 8]
0004afd4  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004afd7  235590                   and edx, dword ptr [rbp - 0x70]
0004afda  895598                   mov dword ptr [rbp - 0x68], edx
0004afdd  895584                   mov dword ptr [rbp - 0x7c], edx
0004afe0  458bc1                   mov r8d, r9d
0004afe3  e9e6030000               jmp 0x4b3ce
0004afe8  8955b0                   mov dword ptr [rbp - 0x50], edx
0004afeb  4080ff06                 cmp dil, 6
0004afef  743e                     je 0x4b02f
0004aff1  8b4d88                   mov ecx, dword ptr [rbp - 0x78]
0004aff4  83f906                   cmp ecx, 6
0004aff7  7f10                     jg 0x4b009
0004aff9  0f8546010000             jne 0x4b145
0004afff  837dbc00                 cmp dword ptr [rbp - 0x44], 0
0004b003  0f853c010000             jne 0x4b145
0004b009  33c0                     xor eax, eax
0004b00b  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004b012  41b901000000             mov r9d, 1
0004b018  83f906                   cmp ecx, 6
0004b01b  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004b01f  0f4e45c4                 cmovle eax, dword ptr [rbp - 0x3c]
0004b023  8945c4                   mov dword ptr [rbp - 0x3c], eax
0004b026  44894d8c                 mov dword ptr [rbp - 0x74], r9d
0004b02a  e91c010000               jmp 0x4b14b
0004b02f  837d8806                 cmp dword ptr [rbp - 0x78], 6
0004b033  7f5b                     jg 0x4b090
0004b035  0f85d9000000             jne 0x4b114
0004b03b  837dc400                 cmp dword ptr [rbp - 0x3c], 0
0004b03f  7428                     je 0x4b069
0004b041  837dbc00                 cmp dword ptr [rbp - 0x44], 0
0004b045  41b901000000             mov r9d, 1
0004b04b  0f85c9000000             jne 0x4b11a
0004b051  44894d8c                 mov dword ptr [rbp - 0x74], r9d
0004b055  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004b059  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004b05d  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004b064  e9b1000000               jmp 0x4b11a
0004b069  837dbc00                 cmp dword ptr [rbp - 0x44], 0
0004b06d  7421                     je 0x4b090
0004b06f  41b901000000             mov r9d, 1
0004b075  c7458c03000000           mov dword ptr [rbp - 0x74], 3
0004b07c  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004b080  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004b084  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004b08b  e98a000000               jmp 0x4b11a
0004b090  0fb64584                 movzx eax, byte ptr [rbp - 0x7c]
0004b094  384580                   cmp byte ptr [rbp - 0x80], al
0004b097  7551                     jne 0x4b0ea
0004b099  0fb64d83                 movzx ecx, byte ptr [rbp - 0x7d]
0004b09d  8bc2                     mov eax, edx
0004b09f  c1e818                   shr eax, 0x18
0004b0a2  80e13f                   and cl, 0x3f
0004b0a5  243f                     and al, 0x3f
0004b0a7  3ac8                     cmp cl, al
0004b0a9  731b                     jae 0x4b0c6
0004b0ab  41b901000000             mov r9d, 1
0004b0b1  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004b0b8  44894d8c                 mov dword ptr [rbp - 0x74], r9d
0004b0bc  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004b0c0  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004b0c4  eb54                     jmp 0x4b11a
0004b0c6  0f86ef020000             jbe 0x4b3bb
0004b0cc  41b901000000             mov r9d, 1
0004b0d2  c7458c03000000           mov dword ptr [rbp - 0x74], 3
0004b0d9  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004b0dd  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004b0e1  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004b0e8  eb30                     jmp 0x4b11a
0004b0ea  0fb64584                 movzx eax, byte ptr [rbp - 0x7c]
0004b0ee  41b901000000             mov r9d, 1
0004b0f4  384580                   cmp byte ptr [rbp - 0x80], al
0004b0f7  b903000000               mov ecx, 3
0004b0fc  44894dbc                 mov dword ptr [rbp - 0x44], r9d
0004b100  410f42c9                 cmovb ecx, r9d
0004b104  44894dc4                 mov dword ptr [rbp - 0x3c], r9d
0004b108  894d8c                   mov dword ptr [rbp - 0x74], ecx
0004b10b  c7458806000000           mov dword ptr [rbp - 0x78], 6
0004b112  eb06                     jmp 0x4b11a
0004b114  41b901000000             mov r9d, 1
0004b11a  4983c402                 add r12, 2
0004b11e  4183ee01                 sub r14d, 1
0004b122  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004b129  7420                     je 0x4b14b
0004b12b  410fb70c24               movzx ecx, word ptr [r12]
0004b130  498b4008                 mov rax, qword ptr [r8 + 8]
0004b134  448b5590                 mov r10d, dword ptr [rbp - 0x70]
0004b138  448b2c88                 mov r13d, dword ptr [rax + rcx*4]
0004b13c  4523ea                   and r13d, r10d
0004b13f  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004b143  eb0a                     jmp 0x4b14f
0004b145  41b901000000             mov r9d, 1
0004b14b  448b5590                 mov r10d, dword ptr [rbp - 0x70]
0004b14f  4983c702                 add r15, 2
0004b153  4183eb01                 sub r11d, 1
0004b157  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004b15e  7414                     je 0x4b174
0004b160  410fb70f                 movzx ecx, word ptr [r15]
0004b164  498b4008                 mov rax, qword ptr [r8 + 8]
0004b168  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004b16b  4123d2                   and edx, r10d
0004b16e  895598                   mov dword ptr [rbp - 0x68], edx
0004b171  895584                   mov dword ptr [rbp - 0x7c], edx
0004b174  458bc1                   mov r8d, r9d
0004b177  e952020000               jmp 0x4b3ce
0004b17c  448b45a8                 mov r8d, dword ptr [rbp - 0x58]
0004b180  4585c0                   test r8d, r8d
0004b183  0f853f020000             jne 0x4b3c8
0004b189  33d2                     xor edx, edx
0004b18b  8955b0                   mov dword ptr [rbp - 0x50], edx
0004b18e  3955f0                   cmp dword ptr [rbp - 0x10], edx
0004b191  0f8511010000             jne 0x4b2a8
0004b197  8b45f8                   mov eax, dword ptr [rbp - 8]
0004b19a  4c8d8d80000000           lea r9, [rbp + 0x80]
0004b1a1  488b5568                 mov rdx, qword ptr [rbp + 0x68]
0004b1a5  4c8d4500                 lea r8, [rbp]
0004b1a9  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0004b1ad  89442478                 mov dword ptr [rsp + 0x78], eax
0004b1b1  488d45e0                 lea rax, [rbp - 0x20]
0004b1b5  4889442470               mov qword ptr [rsp + 0x70], rax
0004b1ba  488d45fc                 lea rax, [rbp - 4]
0004b1be  4889442468               mov qword ptr [rsp + 0x68], rax
0004b1c3  488d4578                 lea rax, [rbp + 0x78]
0004b1c7  4889442460               mov qword ptr [rsp + 0x60], rax
0004b1cc  488d8588000000           lea rax, [rbp + 0x88]
0004b1d3  4889442458               mov qword ptr [rsp + 0x58], rax
0004b1d8  488d4584                 lea rax, [rbp - 0x7c]
0004b1dc  4889442448               mov qword ptr [rsp + 0x48], rax
0004b1e1  488d8590000000           lea rax, [rbp + 0x90]
0004b1e8  44895c2440               mov dword ptr [rsp + 0x40], r11d
0004b1ed  4889442438               mov qword ptr [rsp + 0x38], rax
0004b1f2  488d45f0                 lea rax, [rbp - 0x10]
0004b1f6  4889442430               mov qword ptr [rsp + 0x30], rax
0004b1fb  488d4580                 lea rax, [rbp - 0x80]
0004b1ff  4889442428               mov qword ptr [rsp + 0x28], rax
0004b204  4489742420               mov dword ptr [rsp + 0x20], r14d
0004b209  4c896500                 mov qword ptr [rbp], r12
0004b20d  4c897df0                 mov qword ptr [rbp - 0x10], r15
0004b211  e82a570000               call 0x50940
0004b216  448bc0                   mov r8d, eax
0004b219  8945a8                   mov dword ptr [rbp - 0x58], eax
0004b21c  8b45e0                   mov eax, dword ptr [rbp - 0x20]
0004b21f  83f802                   cmp eax, 2
0004b222  0f85c8090000             jne 0x4bbf0
0004b228  4c8b6500                 mov r12, qword ptr [rbp]
0004b22c  4c8b7df0                 mov r15, qword ptr [rbp - 0x10]
0004b230  448bb580000000           mov r14d, dword ptr [rbp + 0x80]
0004b237  448b9d90000000           mov r11d, dword ptr [rbp + 0x90]
0004b23e  4585c0                   test r8d, r8d
0004b241  744c                     je 0x4b28f
0004b243  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b247  448d48ff                 lea r9d, [rax - 1]
0004b24b  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004b24e  4585f6                   test r14d, r14d
0004b251  7e2d                     jle 0x4b280
0004b253  4585db                   test r11d, r11d
0004b256  7e28                     jle 0x4b280
0004b258  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004b25c  410fb70424               movzx eax, word ptr [r12]
0004b261  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004b265  410fb707                 movzx eax, word ptr [r15]
0004b269  4423ef                   and r13d, edi
0004b26c  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004b270  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
0004b273  23df                     and ebx, edi
0004b275  895d98                   mov dword ptr [rbp - 0x68], ebx
0004b278  895d84                   mov dword ptr [rbp - 0x7c], ebx
0004b27b  e958010000               jmp 0x4b3d8
0004b280  8b5d84                   mov ebx, dword ptr [rbp - 0x7c]
0004b283  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004b287  895d98                   mov dword ptr [rbp - 0x68], ebx
0004b28a  e949010000               jmp 0x4b3d8
0004b28f  8b5584                   mov edx, dword ptr [rbp - 0x7c]
0004b292  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004b296  440fb78d88000000         movzx r9d, word ptr [rbp + 0x88]
0004b29e  440fb75578               movzx r10d, word ptr [rbp + 0x78]
0004b2a3  895598                   mov dword ptr [rbp - 0x68], edx
0004b2a6  33d2                     xor edx, edx
0004b2a8  4080ff03                 cmp dil, 3
0004b2ac  0f8539030000             jne 0x4b5eb
0004b2b2  488b4568                 mov rax, qword ptr [rbp + 0x68]
0004b2b6  458bc5                   mov r8d, r13d
0004b2b9  41c1e818                 shr r8d, 0x18
0004b2bd  807d8001                 cmp byte ptr [rbp - 0x80], 1
0004b2c1  8955ac                   mov dword ptr [rbp - 0x54], edx
0004b2c4  0fb74840                 movzx ecx, word ptr [rax + 0x40]
0004b2c8  0f87db010000             ja 0x4b4a9
0004b2ce  b8ffff0000               mov eax, 0xffff
0004b2d3  8bd0                     mov edx, eax
0004b2d5  8945c0                   mov dword ptr [rbp - 0x40], eax
0004b2d8  8b45a0                   mov eax, dword ptr [rbp - 0x60]
0004b2db  85c0                     test eax, eax
0004b2dd  0f84c2010000             je 0x4b4a5
0004b2e3  8b5590                   mov edx, dword ptr [rbp - 0x70]
0004b2e6  23d0                     and edx, eax
0004b2e8  0fb7c2                   movzx eax, dx
0004b2eb  8955c0                   mov dword ptr [rbp - 0x40], edx
0004b2ee  66c1e808                 shr ax, 8
0004b2f2  899580000000             mov dword ptr [rbp + 0x80], edx
0004b2f8  403ac7                   cmp al, dil
0004b2fb  0f83f5000000             jae 0x4b3f6
0004b301  b8ffff0000               mov eax, 0xffff
0004b306  8bd0                     mov edx, eax
0004b308  8945c0                   mov dword ptr [rbp - 0x40], eax
0004b30b  e9e7010000               jmp 0x4b4f7
0004b310  4080ff05                 cmp dil, 5
0004b314  7454                     je 0x4b36a
0004b316  498b4008                 mov rax, qword ptr [r8 + 8]
0004b31a  410fb70f                 movzx ecx, word ptr [r15]
0004b31e  8b1488                   mov edx, dword ptr [rax + rcx*4]
0004b321  b812040000               mov eax, 0x412
0004b326  895598                   mov dword ptr [rbp - 0x68], edx
0004b329  895584                   mov dword ptr [rbp - 0x7c], edx
0004b32c  899588000000             mov dword ptr [rbp + 0x88], edx
0004b332  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b336  7518                     jne 0x4b350
0004b338  450fb69046010000         movzx r10d, byte ptr [r8 + 0x146]
0004b340  b8ff000000               mov eax, 0xff
0004b345  6641c1e208               shl r10w, 8
0004b34a  66440bd0                 or r10w, ax
0004b34e  eb2b                     jmp 0x4b37b
0004b350  b8fffe0000               mov eax, 0xfeff
0004b355  448bd0                   mov r10d, eax
0004b358  66898588000000           mov word ptr [rbp + 0x88], ax
0004b35f  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004b365  8945b0                   mov dword ptr [rbp - 0x50], eax
0004b368  eb51                     jmp 0x4b3bb
0004b36a  b812040000               mov eax, 0x412
0004b36f  899588000000             mov dword ptr [rbp + 0x88], edx
0004b375  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b379  7526                     jne 0x4b3a1
0004b37b  410fb68046010000         movzx eax, byte ptr [r8 + 0x146]
0004b383  b9ff000000               mov ecx, 0xff
0004b388  66c1e008                 shl ax, 8
0004b38c  660bc1                   or ax, cx
0004b38f  66898588000000           mov word ptr [rbp + 0x88], ax
0004b396  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004b39c  8945b0                   mov dword ptr [rbp - 0x50], eax
0004b39f  eb1a                     jmp 0x4b3bb
0004b3a1  b8fffe0000               mov eax, 0xfeff
0004b3a6  66898588000000           mov word ptr [rbp + 0x88], ax
0004b3ad  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004b3b3  8945b0                   mov dword ptr [rbp - 0x50], eax
0004b3b6  eb03                     jmp 0x4b3bb
0004b3b8  8955b0                   mov dword ptr [rbp - 0x50], edx
0004b3bb  448b45a8                 mov r8d, dword ptr [rbp - 0x58]
0004b3bf  4585c0                   test r8d, r8d
0004b3c2  0f84defeffff             je 0x4b2a6
0004b3c8  41b901000000             mov r9d, 1
0004b3ce  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004b3d1  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b3d5  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b3d8  8b558c                   mov edx, dword ptr [rbp - 0x74]
0004b3db  4585f6                   test r14d, r14d
0004b3de  0f844df2ffff             je 0x4a631
0004b3e4  4585db                   test r11d, r11d
0004b3e7  0f8444f2ffff             je 0x4a631
0004b3ed  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
0004b3f1  e9e6f2ffff               jmp 0x4a6dc
0004b3f6  0f859a000000             jne 0x4b496
0004b3fc  80fa01                   cmp dl, 1
0004b3ff  770f                     ja 0x4b410
0004b401  b8ffff0000               mov eax, 0xffff
0004b406  8bd0                     mov edx, eax
0004b408  8945c0                   mov dword ptr [rbp - 0x40], eax
0004b40b  e9e7000000               jmp 0x4b4f7
0004b410  b812040000               mov eax, 0x412
0004b415  0fb6d2                   movzx edx, dl
0004b418  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b41c  0fb7c2                   movzx eax, dx
0004b41f  750a                     jne 0x4b42b
0004b421  4c8b6d68                 mov r13, qword ptr [rbp + 0x68]
0004b425  420fb64c2948             movzx ecx, byte ptr [rcx + r13 + 0x48]
0004b42b  66c1e108                 shl cx, 8
0004b42f  660bc1                   or ax, cx
0004b432  660bca                   or cx, dx
0004b435  0fb69583000000           movzx edx, byte ptr [rbp + 0x83]
0004b43c  66898580000000           mov word ptr [rbp + 0x80], ax
0004b443  80e23f                   and dl, 0x3f
0004b446  0fb6c2                   movzx eax, dl
0004b449  24c6                     and al, 0xc6
0004b44b  8845ac                   mov byte ptr [rbp - 0x54], al
0004b44e  0fb6c2                   movzx eax, dl
0004b451  24e4                     and al, 0xe4
0004b453  807d8000                 cmp byte ptr [rbp - 0x80], 0
0004b457  8845ae                   mov byte ptr [rbp - 0x52], al
0004b45a  b8ffff0000               mov eax, 0xffff
0004b45f  751c                     jne 0x4b47d
0004b461  80e2c5                   and dl, 0xc5
0004b464  c645ad04                 mov byte ptr [rbp - 0x53], 4
0004b468  8855af                   mov byte ptr [rbp - 0x51], dl
0004b46b  440fb7c9                 movzx r9d, cx
0004b46f  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004b475  8955c0                   mov dword ptr [rbp - 0x40], edx
0004b478  e980000000               jmp 0x4b4fd
0004b47d  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004b483  41b987ff0000             mov r9d, 0xff87
0004b489  664423c9                 and r9w, cx
0004b48d  c645ad05                 mov byte ptr [rbp - 0x53], 5
0004b491  8955c0                   mov dword ptr [rbp - 0x40], edx
0004b494  eb59                     jmp 0x4b4ef
0004b496  440fb78d80000000         movzx r9d, word ptr [rbp + 0x80]
0004b49e  b8ffff0000               mov eax, 0xffff
0004b4a3  eb52                     jmp 0x4b4f7
0004b4a5  8bc2                     mov eax, edx
0004b4a7  eb4e                     jmp 0x4b4f7
0004b4a9  0fb65580                 movzx edx, byte ptr [rbp - 0x80]
0004b4ad  b812040000               mov eax, 0x412
0004b4b2  44896da0                 mov dword ptr [rbp - 0x60], r13d
0004b4b6  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b4ba  750a                     jne 0x4b4c6
0004b4bc  4c8b6d68                 mov r13, qword ptr [rbp + 0x68]
0004b4c0  420fb64c2948             movzx ecx, byte ptr [rcx + r13 + 0x48]
0004b4c6  410fb6c0                 movzx eax, r8b
0004b4ca  66c1e108                 shl cx, 8
0004b4ce  2406                     and al, 6
0004b4d0  c645ad03                 mov byte ptr [rbp - 0x53], 3
0004b4d4  8845ac                   mov byte ptr [rbp - 0x54], al
0004b4d7  660bca                   or cx, dx
0004b4da  8b55c0                   mov edx, dword ptr [rbp - 0x40]
0004b4dd  410fb6c0                 movzx eax, r8b
0004b4e1  2424                     and al, 0x24
0004b4e3  440fb7c9                 movzx r9d, cx
0004b4e7  8845ae                   mov byte ptr [rbp - 0x52], al
0004b4ea  b8ffff0000               mov eax, 0xffff
0004b4ef  4180e005                 and r8b, 5
0004b4f3  448845af                 mov byte ptr [rbp - 0x51], r8b
0004b4f7  807d8001                 cmp byte ptr [rbp - 0x80], 1
0004b4fb  7717                     ja 0x4b514
0004b4fd  3bd0                     cmp edx, eax
0004b4ff  7513                     jne 0x4b514
0004b501  440fb7c8                 movzx r9d, ax
0004b505  894580                   mov dword ptr [rbp - 0x80], eax
0004b508  448be8                   mov r13d, eax
0004b50b  33c0                     xor eax, eax
0004b50d  8bc8                     mov ecx, eax
0004b50f  8945ac                   mov dword ptr [rbp - 0x54], eax
0004b512  eb10                     jmp 0x4b524
0004b514  8b4dac                   mov ecx, dword ptr [rbp - 0x54]
0004b517  6644894d80               mov word ptr [rbp - 0x80], r9w
0004b51c  c6458302                 mov byte ptr [rbp - 0x7d], 2
0004b520  448b6d80                 mov r13d, dword ptr [rbp - 0x80]
0004b524  837d8802                 cmp dword ptr [rbp - 0x78], 2
0004b528  0f8ebd000000             jle 0x4b5eb
0004b52e  80fb03                   cmp bl, 3
0004b531  0f84bd000000             je 0x4b5f4
0004b537  807dac00                 cmp byte ptr [rbp - 0x54], 0
0004b53b  7420                     je 0x4b55d
0004b53d  85f6                     test esi, esi
0004b53f  751c                     jne 0x4b55d
0004b541  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b544  ba03000000               mov edx, 3
0004b549  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b54d  bf02000000               mov edi, 2
0004b552  89558c                   mov dword ptr [rbp - 0x74], edx
0004b555  897d88                   mov dword ptr [rbp - 0x78], edi
0004b558  e90c040000               jmp 0x4b969
0004b55d  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004b560  83ff03                   cmp edi, 3
0004b563  7e7a                     jle 0x4b5df
0004b565  8bc1                     mov eax, ecx
0004b567  c1e808                   shr eax, 8
0004b56a  84c0                     test al, al
0004b56c  741d                     je 0x4b58b
0004b56e  85f6                     test esi, esi
0004b570  7519                     jne 0x4b58b
0004b572  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b575  ba03000000               mov edx, 3
0004b57a  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b57e  8bfa                     mov edi, edx
0004b580  89558c                   mov dword ptr [rbp - 0x74], edx
0004b583  895588                   mov dword ptr [rbp - 0x78], edx
0004b586  e9de030000               jmp 0x4b969
0004b58b  83ff04                   cmp edi, 4
0004b58e  7e4f                     jle 0x4b5df
0004b590  8bc1                     mov eax, ecx
0004b592  c1e810                   shr eax, 0x10
0004b595  84c0                     test al, al
0004b597  741c                     je 0x4b5b5
0004b599  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b59c  ba03000000               mov edx, 3
0004b5a1  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b5a5  bf04000000               mov edi, 4
0004b5aa  89558c                   mov dword ptr [rbp - 0x74], edx
0004b5ad  897d88                   mov dword ptr [rbp - 0x78], edi
0004b5b0  e9b4030000               jmp 0x4b969
0004b5b5  83ff05                   cmp edi, 5
0004b5b8  7e25                     jle 0x4b5df
0004b5ba  8bc1                     mov eax, ecx
0004b5bc  c1e818                   shr eax, 0x18
0004b5bf  84c0                     test al, al
0004b5c1  741c                     je 0x4b5df
0004b5c3  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b5c6  ba03000000               mov edx, 3
0004b5cb  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b5cf  bf05000000               mov edi, 5
0004b5d4  89558c                   mov dword ptr [rbp - 0x74], edx
0004b5d7  897d88                   mov dword ptr [rbp - 0x78], edi
0004b5da  e98a030000               jmp 0x4b969
0004b5df  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b5e2  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b5e6  e979030000               jmp 0x4b964
0004b5eb  80fb03                   cmp bl, 3
0004b5ee  0f8566030000             jne 0x4b95a
0004b5f4  8b4598                   mov eax, dword ptr [rbp - 0x68]
0004b5f7  33d2                     xor edx, edx
0004b5f9  488b5d68                 mov rbx, qword ptr [rbp + 0x68]
0004b5fd  448bc0                   mov r8d, eax
0004b600  41c1e818                 shr r8d, 0x18
0004b604  807d8401                 cmp byte ptr [rbp - 0x7c], 1
0004b608  899580000000             mov dword ptr [rbp + 0x80], edx
0004b60e  0fb74b40                 movzx ecx, word ptr [rbx + 0x40]
0004b612  0f87f6000000             ja 0x4b70e
0004b618  b8ffff0000               mov eax, 0xffff
0004b61d  8945b4                   mov dword ptr [rbp - 0x4c], eax
0004b620  8b45b0                   mov eax, dword ptr [rbp - 0x50]
0004b623  85c0                     test eax, eax
0004b625  0f84de000000             je 0x4b709
0004b62b  8b5d90                   mov ebx, dword ptr [rbp - 0x70]
0004b62e  23d8                     and ebx, eax
0004b630  8bc3                     mov eax, ebx
0004b632  895db4                   mov dword ptr [rbp - 0x4c], ebx
0004b635  66c1e808                 shr ax, 8
0004b639  899d88000000             mov dword ptr [rbp + 0x88], ebx
0004b63f  488b5d68                 mov rbx, qword ptr [rbp + 0x68]
0004b643  3c03                     cmp al, 3
0004b645  730f                     jae 0x4b656
0004b647  b9ffff0000               mov ecx, 0xffff
0004b64c  8bc1                     mov eax, ecx
0004b64e  894db4                   mov dword ptr [rbp - 0x4c], ecx
0004b651  e912010000               jmp 0x4b768
0004b656  8b45b4                   mov eax, dword ptr [rbp - 0x4c]
0004b659  0f85a0000000             jne 0x4b6ff
0004b65f  3c01                     cmp al, 1
0004b661  770f                     ja 0x4b672
0004b663  b9ffff0000               mov ecx, 0xffff
0004b668  8bc1                     mov eax, ecx
0004b66a  894db4                   mov dword ptr [rbp - 0x4c], ecx
0004b66d  e9f6000000               jmp 0x4b768
0004b672  0fb6d0                   movzx edx, al
0004b675  b812040000               mov eax, 0x412
0004b67a  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b67e  0fb7c2                   movzx eax, dx
0004b681  7505                     jne 0x4b688
0004b683  0fb64c1948               movzx ecx, byte ptr [rcx + rbx + 0x48]
0004b688  66c1e108                 shl cx, 8
0004b68c  660bc1                   or ax, cx
0004b68f  660bca                   or cx, dx
0004b692  0fb6958b000000           movzx edx, byte ptr [rbp + 0x8b]
0004b699  66898588000000           mov word ptr [rbp + 0x88], ax
0004b6a0  80e23f                   and dl, 0x3f
0004b6a3  0fb6c2                   movzx eax, dl
0004b6a6  24c6                     and al, 0xc6
0004b6a8  888580000000             mov byte ptr [rbp + 0x80], al
0004b6ae  0fb6c2                   movzx eax, dl
0004b6b1  24e4                     and al, 0xe4
0004b6b3  807d8400                 cmp byte ptr [rbp - 0x7c], 0
0004b6b7  888582000000             mov byte ptr [rbp + 0x82], al
0004b6bd  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0004b6c3  8945b4                   mov dword ptr [rbp - 0x4c], eax
0004b6c6  7524                     jne 0x4b6ec
0004b6c8  80e2c5                   and dl, 0xc5
0004b6cb  c6858100000004           mov byte ptr [rbp + 0x81], 4
0004b6d2  889583000000             mov byte ptr [rbp + 0x83], dl
0004b6d8  440fb7d1                 movzx r10d, cx
0004b6dc  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004b6e2  b9ffff0000               mov ecx, 0xffff
0004b6e7  e982000000               jmp 0x4b76e
0004b6ec  41ba87ff0000             mov r10d, 0xff87
0004b6f2  c6858100000005           mov byte ptr [rbp + 0x81], 5
0004b6f9  664423d1                 and r10w, cx
0004b6fd  eb53                     jmp 0x4b752
0004b6ff  440fb79588000000         movzx r10d, word ptr [rbp + 0x88]
0004b707  eb5a                     jmp 0x4b763
0004b709  8b45b4                   mov eax, dword ptr [rbp - 0x4c]
0004b70c  eb55                     jmp 0x4b763
0004b70e  0fb65584                 movzx edx, byte ptr [rbp - 0x7c]
0004b712  8945b0                   mov dword ptr [rbp - 0x50], eax
0004b715  b812040000               mov eax, 0x412
0004b71a  663945a4                 cmp word ptr [rbp - 0x5c], ax
0004b71e  7505                     jne 0x4b725
0004b720  0fb64c1948               movzx ecx, byte ptr [rcx + rbx + 0x48]
0004b725  410fb6c0                 movzx eax, r8b
0004b729  66c1e108                 shl cx, 8
0004b72d  2406                     and al, 6
0004b72f  c6858100000003           mov byte ptr [rbp + 0x81], 3
0004b736  888580000000             mov byte ptr [rbp + 0x80], al
0004b73c  660bca                   or cx, dx
0004b73f  410fb6c0                 movzx eax, r8b
0004b743  440fb7d1                 movzx r10d, cx
0004b747  2424                     and al, 0x24
0004b749  888582000000             mov byte ptr [rbp + 0x82], al
0004b74f  8b45b4                   mov eax, dword ptr [rbp - 0x4c]
0004b752  4180e005                 and r8b, 5
0004b756  44888583000000           mov byte ptr [rbp + 0x83], r8b
0004b75d  8b9580000000             mov edx, dword ptr [rbp + 0x80]
0004b763  b9ffff0000               mov ecx, 0xffff
0004b768  807d8401                 cmp byte ptr [rbp - 0x7c], 1
0004b76c  771c                     ja 0x4b78a
0004b76e  3bc1                     cmp eax, ecx
0004b770  7518                     jne 0x4b78a
0004b772  33c0                     xor eax, eax
0004b774  894d98                   mov dword ptr [rbp - 0x68], ecx
0004b777  8bd0                     mov edx, eax
0004b779  898580000000             mov dword ptr [rbp + 0x80], eax
0004b77f  440fb7d1                 movzx r10d, cx
0004b783  894d84                   mov dword ptr [rbp - 0x7c], ecx
0004b786  8bd9                     mov ebx, ecx
0004b788  eb0f                     jmp 0x4b799
0004b78a  6644895584               mov word ptr [rbp - 0x7c], r10w
0004b78f  c6458702                 mov byte ptr [rbp - 0x79], 2
0004b793  8b5d84                   mov ebx, dword ptr [rbp - 0x7c]
0004b796  895d98                   mov dword ptr [rbp - 0x68], ebx
0004b799  837d8802                 cmp dword ptr [rbp - 0x78], 2
0004b79d  0f8eba010000             jle 0x4b95d
0004b7a3  4080ff03                 cmp dil, 3
0004b7a7  0f84bb000000             je 0x4b868
0004b7ad  80bd8000000000           cmp byte ptr [rbp + 0x80], 0
0004b7b4  7420                     je 0x4b7d6
0004b7b6  85f6                     test esi, esi
0004b7b8  751c                     jne 0x4b7d6
0004b7ba  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b7be  b801000000               mov eax, 1
0004b7c3  bf02000000               mov edi, 2
0004b7c8  89458c                   mov dword ptr [rbp - 0x74], eax
0004b7cb  897d88                   mov dword ptr [rbp - 0x78], edi
0004b7ce  8d5002                   lea edx, [rax + 2]
0004b7d1  e998010000               jmp 0x4b96e
0004b7d6  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004b7d9  83ff03                   cmp edi, 3
0004b7dc  0f8e00feffff             jle 0x4b5e2
0004b7e2  8bc2                     mov eax, edx
0004b7e4  c1e808                   shr eax, 8
0004b7e7  84c0                     test al, al
0004b7e9  741f                     je 0x4b80a
0004b7eb  85f6                     test esi, esi
0004b7ed  751b                     jne 0x4b80a
0004b7ef  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b7f3  ba03000000               mov edx, 3
0004b7f8  b801000000               mov eax, 1
0004b7fd  895588                   mov dword ptr [rbp - 0x78], edx
0004b800  89458c                   mov dword ptr [rbp - 0x74], eax
0004b803  8bfa                     mov edi, edx
0004b805  e964010000               jmp 0x4b96e
0004b80a  83ff04                   cmp edi, 4
0004b80d  0f8ecffdffff             jle 0x4b5e2
0004b813  8bc2                     mov eax, edx
0004b815  c1e810                   shr eax, 0x10
0004b818  84c0                     test al, al
0004b81a  741c                     je 0x4b838
0004b81c  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b820  b801000000               mov eax, 1
0004b825  bf04000000               mov edi, 4
0004b82a  89458c                   mov dword ptr [rbp - 0x74], eax
0004b82d  897d88                   mov dword ptr [rbp - 0x78], edi
0004b830  8d5002                   lea edx, [rax + 2]
0004b833  e936010000               jmp 0x4b96e
0004b838  83ff05                   cmp edi, 5
0004b83b  0f8ea1fdffff             jle 0x4b5e2
0004b841  c1ea18                   shr edx, 0x18
0004b844  84d2                     test dl, dl
0004b846  0f8496fdffff             je 0x4b5e2
0004b84c  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b850  b801000000               mov eax, 1
0004b855  bf05000000               mov edi, 5
0004b85a  89458c                   mov dword ptr [rbp - 0x74], eax
0004b85d  897d88                   mov dword ptr [rbp - 0x78], edi
0004b860  8d5002                   lea edx, [rax + 2]
0004b863  e906010000               jmp 0x4b96e
0004b868  0fb645ac                 movzx eax, byte ptr [rbp - 0x54]
0004b86c  0fb68d80000000           movzx ecx, byte ptr [rbp + 0x80]
0004b873  3ac1                     cmp al, cl
0004b875  742c                     je 0x4b8a3
0004b877  85f6                     test esi, esi
0004b879  7528                     jne 0x4b8a3
0004b87b  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b87f  3ac1                     cmp al, cl
0004b881  ba03000000               mov edx, 3
0004b886  b801000000               mov eax, 1
0004b88b  448bc2                   mov r8d, edx
0004b88e  bf02000000               mov edi, 2
0004b893  440f42c0                 cmovb r8d, eax
0004b897  897d88                   mov dword ptr [rbp - 0x78], edi
0004b89a  4489458c                 mov dword ptr [rbp - 0x74], r8d
0004b89e  e9cb000000               jmp 0x4b96e
0004b8a3  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004b8a6  83ff03                   cmp edi, 3
0004b8a9  0f8e33fdffff             jle 0x4b5e2
0004b8af  448b45ac                 mov r8d, dword ptr [rbp - 0x54]
0004b8b3  8bca                     mov ecx, edx
0004b8b5  418bc0                   mov eax, r8d
0004b8b8  c1e908                   shr ecx, 8
0004b8bb  c1e808                   shr eax, 8
0004b8be  3ac1                     cmp al, cl
0004b8c0  7429                     je 0x4b8eb
0004b8c2  85f6                     test esi, esi
0004b8c4  7525                     jne 0x4b8eb
0004b8c6  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b8ca  ba03000000               mov edx, 3
0004b8cf  3ac1                     cmp al, cl
0004b8d1  895588                   mov dword ptr [rbp - 0x78], edx
0004b8d4  448bc2                   mov r8d, edx
0004b8d7  b801000000               mov eax, 1
0004b8dc  440f42c0                 cmovb r8d, eax
0004b8e0  8bfa                     mov edi, edx
0004b8e2  4489458c                 mov dword ptr [rbp - 0x74], r8d
0004b8e6  e983000000               jmp 0x4b96e
0004b8eb  83ff04                   cmp edi, 4
0004b8ee  0f8eeefcffff             jle 0x4b5e2
0004b8f4  418bc0                   mov eax, r8d
0004b8f7  8bca                     mov ecx, edx
0004b8f9  c1e810                   shr eax, 0x10
0004b8fc  c1e910                   shr ecx, 0x10
0004b8ff  3ac1                     cmp al, cl
0004b901  7423                     je 0x4b926
0004b903  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b907  ba03000000               mov edx, 3
0004b90c  448bc2                   mov r8d, edx
0004b90f  b801000000               mov eax, 1
0004b914  440f42c0                 cmovb r8d, eax
0004b918  bf04000000               mov edi, 4
0004b91d  4489458c                 mov dword ptr [rbp - 0x74], r8d
0004b921  897d88                   mov dword ptr [rbp - 0x78], edi
0004b924  eb48                     jmp 0x4b96e
0004b926  83ff05                   cmp edi, 5
0004b929  0f8eb3fcffff             jle 0x4b5e2
0004b92f  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b933  418bc0                   mov eax, r8d
0004b936  c1e818                   shr eax, 0x18
0004b939  c1ea18                   shr edx, 0x18
0004b93c  3ac2                     cmp al, dl
0004b93e  b801000000               mov eax, 1
0004b943  8d5002                   lea edx, [rax + 2]
0004b946  7426                     je 0x4b96e
0004b948  8bca                     mov ecx, edx
0004b94a  bf05000000               mov edi, 5
0004b94f  0f42c8                   cmovb ecx, eax
0004b952  897d88                   mov dword ptr [rbp - 0x78], edi
0004b955  894d8c                   mov dword ptr [rbp - 0x74], ecx
0004b958  eb14                     jmp 0x4b96e
0004b95a  8b5d98                   mov ebx, dword ptr [rbp - 0x68]
0004b95d  488b7568                 mov rsi, qword ptr [rbp + 0x68]
0004b961  8b7d88                   mov edi, dword ptr [rbp - 0x78]
0004b964  ba03000000               mov edx, 3
0004b969  b801000000               mov eax, 1
0004b96e  66453bca                 cmp r9w, r10w
0004b972  0f85ad010000             jne 0x4bb25
0004b978  f6457002                 test byte ptr [rbp + 0x70], 2
0004b97c  0f85d1000000             jne 0x4ba53
0004b982  85ff                     test edi, edi
0004b984  7f0a                     jg 0x4b990
0004b986  837e1000                 cmp dword ptr [rsi + 0x10], 0
0004b98a  0f84c3000000             je 0x4ba53
0004b990  48837dd000               cmp qword ptr [rbp - 0x30], 0
0004b995  440fb64582               movzx r8d, byte ptr [rbp - 0x7e]
0004b99a  440fb64d86               movzx r9d, byte ptr [rbp - 0x7a]
0004b99f  753d                     jne 0x4b9de
0004b9a1  418d46ff                 lea eax, [r14 - 1]
0004b9a5  85c0                     test eax, eax
0004b9a7  7435                     je 0x4b9de
0004b9a9  4c8b5608                 mov r10, qword ptr [rsi + 8]
0004b9ad  0f1f00                   nop dword ptr [rax]
0004b9b0  410fb7442402             movzx eax, word ptr [r12 + 2]
0004b9b6  418b0c82                 mov ecx, dword ptr [r10 + rax*4]
0004b9ba  0fb7c1                   movzx eax, cx
0004b9bd  66c1e808                 shr ax, 8
0004b9c1  3c01                     cmp al, 1
0004b9c3  7519                     jne 0x4b9de
0004b9c5  c1e910                   shr ecx, 0x10
0004b9c8  41ffce                   dec r14d
0004b9cb  0fb6c1                   movzx eax, cl
0004b9ce  4983c402                 add r12, 2
0004b9d2  664403c0                 add r8w, ax
0004b9d6  418d46ff                 lea eax, [r14 - 1]
0004b9da  85c0                     test eax, eax
0004b9dc  75d2                     jne 0x4b9b0
0004b9de  48837de800               cmp qword ptr [rbp - 0x18], 0
0004b9e3  7548                     jne 0x4ba2d
0004b9e5  418d43ff                 lea eax, [r11 - 1]
0004b9e9  85c0                     test eax, eax
0004b9eb  7440                     je 0x4ba2d
0004b9ed  4c8b5608                 mov r10, qword ptr [rsi + 8]
0004b9f1  0f1f4000                 nop dword ptr [rax]
0004b9f5  6666660f1f840000000000   nop word ptr [rax + rax]
0004ba00  410fb74702               movzx eax, word ptr [r15 + 2]
0004ba05  418b0c82                 mov ecx, dword ptr [r10 + rax*4]
0004ba09  0fb7c1                   movzx eax, cx
0004ba0c  66c1e808                 shr ax, 8
0004ba10  3c01                     cmp al, 1
0004ba12  7519                     jne 0x4ba2d
0004ba14  c1e910                   shr ecx, 0x10
0004ba17  41ffcb                   dec r11d
0004ba1a  0fb6c1                   movzx eax, cl
0004ba1d  4983c702                 add r15, 2
0004ba21  664403c8                 add r9w, ax
0004ba25  418d43ff                 lea eax, [r11 - 1]
0004ba29  85c0                     test eax, eax
0004ba2b  75d3                     jne 0x4ba00
0004ba2d  41ba03000000             mov r10d, 3
0004ba33  66453bc1                 cmp r8w, r9w
0004ba37  458d4afe                 lea r9d, [r10 - 2]
0004ba3b  7420                     je 0x4ba5d
0004ba3d  418bd2                   mov edx, r10d
0004ba40  410f42d1                 cmovb edx, r9d
0004ba44  4533c0                   xor r8d, r8d
0004ba47  418bf8                   mov edi, r8d
0004ba4a  44894588                 mov dword ptr [rbp - 0x78], r8d
0004ba4e  89558c                   mov dword ptr [rbp - 0x74], edx
0004ba51  eb10                     jmp 0x4ba63
0004ba53  41ba03000000             mov r10d, 3
0004ba59  458d4afe                 lea r9d, [r10 - 2]
0004ba5d  8b558c                   mov edx, dword ptr [rbp - 0x74]
0004ba60  4533c0                   xor r8d, r8d
0004ba63  8b4570                   mov eax, dword ptr [rbp + 0x70]
0004ba66  2501000200               and eax, 0x20001
0004ba6b  3d01000200               cmp eax, 0x20001
0004ba70  7427                     je 0x4ba99
0004ba72  83ff01                   cmp edi, 1
0004ba75  7e22                     jle 0x4ba99
0004ba77  0fb64587                 movzx eax, byte ptr [rbp - 0x79]
0004ba7b  0fb64d83                 movzx ecx, byte ptr [rbp - 0x7d]
0004ba7f  243f                     and al, 0x3f
0004ba81  80e13f                   and cl, 0x3f
0004ba84  3ac8                     cmp cl, al
0004ba86  7411                     je 0x4ba99
0004ba88  418bd2                   mov edx, r10d
0004ba8b  44894d88                 mov dword ptr [rbp - 0x78], r9d
0004ba8f  410f42d1                 cmovb edx, r9d
0004ba93  418bf9                   mov edi, r9d
0004ba96  89558c                   mov dword ptr [rbp - 0x74], edx
0004ba99  488b45d0                 mov rax, qword ptr [rbp - 0x30]
0004ba9d  4885c0                   test rax, rax
0004baa0  7411                     je 0x4bab3
0004baa2  836de401                 sub dword ptr [rbp - 0x1c], 1
0004baa6  750b                     jne 0x4bab3
0004baa8  4c8be0                   mov r12, rax
0004baab  4c8945d0                 mov qword ptr [rbp - 0x30], r8
0004baaf  448945a0                 mov dword ptr [rbp - 0x60], r8d
0004bab3  488b4de8                 mov rcx, qword ptr [rbp - 0x18]
0004bab7  4885c9                   test rcx, rcx
0004baba  7414                     je 0x4bad0
0004babc  836dc801                 sub dword ptr [rbp - 0x38], 1
0004bac0  750e                     jne 0x4bad0
0004bac2  4c8bf9                   mov r15, rcx
0004bac5  448945b0                 mov dword ptr [rbp - 0x50], r8d
0004bac9  498bc8                   mov rcx, r8
0004bacc  48894de8                 mov qword ptr [rbp - 0x18], rcx
0004bad0  448b45a8                 mov r8d, dword ptr [rbp - 0x58]
0004bad4  458d5bff                 lea r11d, [r11 - 1]
0004bad8  4983c402                 add r12, 2
0004badc  44899d90000000           mov dword ptr [rbp + 0x90], r11d
0004bae3  4983c702                 add r15, 2
0004bae7  4183ee01                 sub r14d, 1
0004baeb  4489b580000000           mov dword ptr [rbp + 0x80], r14d
0004baf2  0f8446ebffff             je 0x4a63e
0004baf8  4585db                   test r11d, r11d
0004bafb  7423                     je 0x4bb20
0004bafd  488b4e08                 mov rcx, qword ptr [rsi + 8]
0004bb01  410fb70424               movzx eax, word ptr [r12]
0004bb06  8b7d90                   mov edi, dword ptr [rbp - 0x70]
0004bb09  448b2c81                 mov r13d, dword ptr [rcx + rax*4]
0004bb0d  410fb707                 movzx eax, word ptr [r15]
0004bb11  4423ef                   and r13d, edi
0004bb14  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004bb18  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
0004bb1b  e9b0ebffff               jmp 0x4a6d0
0004bb20  e919ebffff               jmp 0x4a63e
0004bb25  0f42d0                   cmovb edx, eax
0004bb28  e9c1000000               jmp 0x4bbee
0004bb2d  4585f6                   test r14d, r14d
0004bb30  7544                     jne 0x4bb76
0004bb32  4585db                   test r11d, r11d
0004bb35  0f84a8000000             je 0x4bbe3
0004bb3b  448b5570                 mov r10d, dword ptr [rbp + 0x70]
0004bb3f  4585d2                   test r10d, r10d
0004bb42  791f                     jns 0x4bb63
0004bb44  4885c9                   test rcx, rcx
0004bb47  0f8496000000             je 0x4bbe3
0004bb4d  443975c8                 cmp dword ptr [rbp - 0x38], r14d
0004bb51  0f848c000000             je 0x4bbe3
0004bb57  83ff07                   cmp edi, 7
0004bb5a  410f44d1                 cmove edx, r9d
0004bb5e  e98b000000               jmp 0x4bbee
0004bb63  4585c0                   test r8d, r8d
0004bb66  4d8be7                   mov r12, r15
0004bb69  458bf3                   mov r14d, r11d
0004bb6c  440f45eb                 cmovne r13d, ebx
0004bb70  44896d80                 mov dword ptr [rbp - 0x80], r13d
0004bb74  eb07                     jmp 0x4bb7d
0004bb76  458bca                   mov r9d, r10d
0004bb79  448b5570                 mov r10d, dword ptr [rbp + 0x70]
0004bb7d  4585f6                   test r14d, r14d
0004bb80  7461                     je 0x4bbe3
0004bb82  4c8d1d7744fbff           lea r11, [rip - 0x4bb89]
0004bb89  0f1f8000000000           nop dword ptr [rax]
0004bb90  4585c0                   test r8d, r8d
0004bb93  7407                     je 0x4bb9c
0004bb95  33c0                     xor eax, eax
0004bb97  448bc0                   mov r8d, eax
0004bb9a  eb0f                     jmp 0x4bbab
0004bb9c  410fb70c24               movzx ecx, word ptr [r12]
0004bba1  488b4608                 mov rax, qword ptr [rsi + 8]
0004bba5  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
0004bba8  894d80                   mov dword ptr [rbp - 0x80], ecx
0004bbab  0fb74580                 movzx eax, word ptr [rbp - 0x80]
0004bbaf  c1e808                   shr eax, 8
0004bbb2  83f80b                   cmp eax, 0xb
0004bbb5  7717                     ja 0x4bbce
0004bbb7  418b8c8350bc0400         mov ecx, dword ptr [r11 + rax*4 + 0x4bc50]
0004bbbf  4903cb                   add rcx, r11
0004bbc2  ffe1                     jmp rcx
0004bbc4  41f6c202                 test r10b, 2
0004bbc8  750f                     jne 0x4bbd9
0004bbca  85ff                     test edi, edi
0004bbcc  7e0b                     jle 0x4bbd9
0004bbce  418bc1                   mov eax, r9d
0004bbd1  eb1d                     jmp 0x4bbf0
0004bbd3  41f6c204                 test r10b, 4
0004bbd7  74f5                     je 0x4bbce
0004bbd9  4983c402                 add r12, 2
0004bbdd  4183ee01                 sub r14d, 1
0004bbe1  75ad                     jne 0x4bb90
0004bbe3  83ff07                   cmp edi, 7
0004bbe6  b802000000               mov eax, 2
0004bbeb  0f44d0                   cmove edx, eax
0004bbee  8bc2                     mov eax, edx
0004bbf0  488b9c2428010000         mov rbx, qword ptr [rsp + 0x128]
0004bbf8  4c8bac2418010000         mov r13, qword ptr [rsp + 0x118]
0004bc00  488bbc2420010000         mov rdi, qword ptr [rsp + 0x120]
0004bc08  4881c430010000           add rsp, 0x130
0004bc0f  415f                     pop r15
0004bc11  415e                     pop r14
0004bc13  415c                     pop r12
0004bc15  5e                       pop rsi
0004bc16  5d                       pop rbp
0004bc17  c3                       ret

; chunk at RVA 0x4bc18 (104 bytes)
0004bc18  38af040047ac             cmp byte ptr [rdi - 0x53b8fffc], ch
0004bc1e  0400                     add al, 0
0004bc20  34af                     xor al, 0xaf
0004bc22  0400                     add al, 0
0004bc24  38af040027ad             cmp byte ptr [rdi - 0x52d8fffc], ch
0004bc2a  0400                     add al, 0
0004bc2c  4fae                     scasb al, byte ptr [rdi]
0004bc2e  0400                     add al, 0
