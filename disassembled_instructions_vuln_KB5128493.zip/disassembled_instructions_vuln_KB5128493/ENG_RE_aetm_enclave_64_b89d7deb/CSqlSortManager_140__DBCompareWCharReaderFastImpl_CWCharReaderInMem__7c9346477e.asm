; CSqlSortManager_140::DBCompareWCharReaderFastImpl<CWCharReaderInMem>
; aetm_enclave.dll, primary RVA 0x59e90, 6858 bytes in 1 chunk(s)

; chunk at RVA 0x59e90 (6858 bytes)
00059e90  4489442418               mov dword ptr [rsp + 0x18], r8d
00059e95  4889542410               mov qword ptr [rsp + 0x10], rdx
00059e9a  48894c2408               mov qword ptr [rsp + 8], rcx
00059e9f  55                       push rbp
00059ea0  53                       push rbx
00059ea1  56                       push rsi
00059ea2  57                       push rdi
00059ea3  4154                     push r12
00059ea5  4155                     push r13
00059ea7  4156                     push r14
00059ea9  4157                     push r15
00059eab  488d6c24e9               lea rbp, [rsp - 0x17]
00059eb0  4881ece8000000           sub rsp, 0xe8
00059eb7  4c8b7d7f                 mov r15, qword ptr [rbp + 0x7f]
00059ebb  33c0                     xor eax, eax
00059ebd  8bd8                     mov ebx, eax
00059ebf  488945af                 mov qword ptr [rbp - 0x51], rax
00059ec3  8bf8                     mov edi, eax
00059ec5  488945a7                 mov qword ptr [rbp - 0x59], rax
00059ec9  448bf0                   mov r14d, eax
00059ecc  894593                   mov dword ptr [rbp - 0x6d], eax
00059ecf  8bf0                     mov esi, eax
00059ed1  89459f                   mov dword ptr [rbp - 0x61], eax
00059ed4  41bb08000000             mov r11d, 8
00059eda  4d8be1                   mov r12, r9
00059edd  448bc8                   mov r9d, eax
00059ee0  44895d8f                 mov dword ptr [rbp - 0x71], r11d
00059ee4  418bc0                   mov eax, r8d
00059ee7  44895def                 mov dword ptr [rbp - 0x11], r11d
00059eeb  83e001                   and eax, 1
00059eee  418bc8                   mov ecx, r8d
00059ef1  894503                   mov dword ptr [rbp + 3], eax
00059ef4  41ba01000000             mov r10d, 1
00059efa  c1e910                   shr ecx, 0x10
00059efd  418bc0                   mov eax, r8d
00059f00  83e002                   and eax, 2
00059f03  448955f3                 mov dword ptr [rbp - 0xd], r10d
00059f07  8945f7                   mov dword ptr [rbp - 9], eax
00059f0a  83e103                   and ecx, 3
00059f0d  418bc0                   mov eax, r8d
00059f10  4c8bea                   mov r13, rdx
00059f13  2500000100               and eax, 0x10000
00059f18  8945df                   mov dword ptr [rbp - 0x21], eax
00059f1b  418bc0                   mov eax, r8d
00059f1e  2500000200               and eax, 0x20000
00059f23  8945cb                   mov dword ptr [rbp - 0x35], eax
00059f26  418bc0                   mov eax, r8d
00059f29  4123c3                   and eax, r11d
00059f2c  8945c3                   mov dword ptr [rbp - 0x3d], eax
00059f2f  418bc0                   mov eax, r8d
00059f32  83e003                   and eax, 3
00059f35  8d0c88                   lea ecx, [rax + rcx*4]
00059f38  488d05c160faff           lea rax, [rip - 0x59f3f]
00059f3f  0fb6848833050900         movzx eax, byte ptr [rax + rcx*4 + 0x90533]
00059f47  8845bc                   mov byte ptr [rbp - 0x44], al
00059f4a  0c18                     or al, 0x18
00059f4c  8845bb                   mov byte ptr [rbp - 0x45], al
00059f4f  418b442408               mov eax, dword ptr [r12 + 8]
00059f54  85c0                     test eax, eax
00059f56  0f8483000000             je 0x59fdf
00059f5c  41395f08                 cmp dword ptr [r15 + 8], ebx
00059f60  747d                     je 0x59fdf
00059f62  488b5208                 mov rdx, qword ptr [rdx + 8]
00059f66  498b0424                 mov rax, qword ptr [r12]
00059f6a  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
00059f6e  448945bf                 mov dword ptr [rbp - 0x41], r8d
00059f72  0fb708                   movzx ecx, word ptr [rax]
00059f75  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00059f78  0fb7d8                   movzx ebx, ax
00059f7b  48c1e810                 shr rax, 0x10
00059f7f  48c1e320                 shl rbx, 0x20
00059f83  480bd8                   or rbx, rax
00059f86  498b07                   mov rax, qword ptr [r15]
00059f89  48895daf                 mov qword ptr [rbp - 0x51], rbx
00059f8d  0fb708                   movzx ecx, word ptr [rax]
00059f90  8b048a                   mov eax, dword ptr [rdx + rcx*4]
00059f93  0fb64d96                 movzx ecx, byte ptr [rbp - 0x6a]
00059f97  0fb65595                 movzx edx, byte ptr [rbp - 0x6b]
00059f9b  48894de7                 mov qword ptr [rbp - 0x19], rcx
00059f9f  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
00059fa3  884d77                   mov byte ptr [rbp + 0x77], cl
00059fa6  410fb6c9                 movzx ecx, r9b
00059faa  0fb7f8                   movzx edi, ax
00059fad  884d9b                   mov byte ptr [rbp - 0x65], cl
00059fb0  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00059fb3  48c1e810                 shr rax, 0x10
00059fb7  48c1e720                 shl rdi, 0x20
00059fbb  894d97                   mov dword ptr [rbp - 0x69], ecx
00059fbe  480bf8                   or rdi, rax
00059fc1  0fb74d6f                 movzx ecx, word ptr [rbp + 0x6f]
00059fc5  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00059fc8  88559c                   mov byte ptr [rbp - 0x64], dl
00059fcb  0fb7556f                 movzx edx, word ptr [rbp + 0x6f]
00059fcf  66894db7                 mov word ptr [rbp - 0x49], cx
00059fd3  8945c7                   mov dword ptr [rbp - 0x39], eax
00059fd6  668955b9                 mov word ptr [rbp - 0x47], dx
00059fda  e9ef000000               jmp 0x5a0ce
00059fdf  0fb64d96                 movzx ecx, byte ptr [rbp - 0x6a]
00059fe3  0fb65595                 movzx edx, byte ptr [rbp - 0x6b]
00059fe7  48894de7                 mov qword ptr [rbp - 0x19], rcx
00059feb  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
00059fef  884d77                   mov byte ptr [rbp + 0x77], cl
00059ff2  0fb64d93                 movzx ecx, byte ptr [rbp - 0x6d]
00059ff6  884d9b                   mov byte ptr [rbp - 0x65], cl
00059ff9  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
00059ffc  894d97                   mov dword ptr [rbp - 0x69], ecx
00059fff  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
0005a002  894dc7                   mov dword ptr [rbp - 0x39], ecx
0005a005  8b4d6f                   mov ecx, dword ptr [rbp + 0x6f]
0005a008  894dbf                   mov dword ptr [rbp - 0x41], ecx
0005a00b  0fb74d6f                 movzx ecx, word ptr [rbp + 0x6f]
0005a00f  88559c                   mov byte ptr [rbp - 0x64], dl
0005a012  0fb7556f                 movzx edx, word ptr [rbp + 0x6f]
0005a016  66894db7                 mov word ptr [rbp - 0x49], cx
0005a01a  668955b9                 mov word ptr [rbp - 0x47], dx
0005a01e  33d2                     xor edx, edx
0005a020  410fbae01b               bt r8d, 0x1b
0005a025  0f83e1150000             jae 0x5b60c
0005a02b  85c0                     test eax, eax
0005a02d  7550                     jne 0x5a07f
0005a02f  41394708                 cmp dword ptr [r15 + 8], eax
0005a033  0f84d3150000             je 0x5b60c
0005a039  488d0d542b0400           lea rcx, [rip + 0x42b54]
0005a040  4589542408               mov dword ptr [r12 + 8], r10d
0005a045  49890c24                 mov qword ptr [r12], rcx
0005a049  49894c2418               mov qword ptr [r12 + 0x18], rcx
0005a04e  4989542410               mov qword ptr [r12 + 0x10], rdx
0005a053  498b5508                 mov rdx, qword ptr [r13 + 8]
0005a057  8b8280000000             mov eax, dword ptr [rdx + 0x80]
0005a05d  0fb7d8                   movzx ebx, ax
0005a060  48c1e320                 shl rbx, 0x20
0005a064  48c1e810                 shr rax, 0x10
0005a068  480bd8                   or rbx, rax
0005a06b  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a06f  4585c9                   test r9d, r9d
0005a072  755e                     jne 0x5a0d2
0005a074  498b07                   mov rax, qword ptr [r15]
0005a077  0fb708                   movzx ecx, word ptr [rax]
0005a07a  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005a07d  eb41                     jmp 0x5a0c0
0005a07f  45895708                 mov dword ptr [r15 + 8], r10d
0005a083  488d050a2b0400           lea rax, [rip + 0x42b0a]
0005a08a  498907                   mov qword ptr [r15], rax
0005a08d  49894718                 mov qword ptr [r15 + 0x18], rax
0005a091  49895710                 mov qword ptr [r15 + 0x10], rdx
0005a095  498b5508                 mov rdx, qword ptr [r13 + 8]
0005a099  4585c9                   test r9d, r9d
0005a09c  751c                     jne 0x5a0ba
0005a09e  498b0424                 mov rax, qword ptr [r12]
0005a0a2  0fb708                   movzx ecx, word ptr [rax]
0005a0a5  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005a0a8  0fb7d8                   movzx ebx, ax
0005a0ab  48c1e320                 shl rbx, 0x20
0005a0af  48c1e810                 shr rax, 0x10
0005a0b3  480bd8                   or rbx, rax
0005a0b6  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a0ba  8b8280000000             mov eax, dword ptr [rdx + 0x80]
0005a0c0  0fb7f8                   movzx edi, ax
0005a0c3  48c1e720                 shl rdi, 0x20
0005a0c7  48c1e810                 shr rax, 0x10
0005a0cb  480bf8                   or rdi, rax
0005a0ce  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a0d2  4533c9                   xor r9d, r9d
0005a0d5  6666660f1f840000000000   nop word ptr [rax + rax]
0005a0e0  41837d1400               cmp dword ptr [r13 + 0x14], 0
0005a0e5  44894d9f                 mov dword ptr [rbp - 0x61], r9d
0005a0e9  0f84a3000000             je 0x5a192
0005a0ef  4d8b4538                 mov r8, qword ptr [r13 + 0x38]
0005a0f3  488bc3                   mov rax, rbx
0005a0f6  4d85c0                   test r8, r8
0005a0f9  7439                     je 0x5a134
0005a0fb  48c1e828                 shr rax, 0x28
0005a0ff  3cfe                     cmp al, 0xfe
0005a101  7510                     jne 0x5a113
0005a103  4c8d4daf                 lea r9, [rbp - 0x51]
0005a107  498bd4                   mov rdx, r12
0005a10a  e891c3ffff               call 0x564a0
0005a10f  488b5daf                 mov rbx, qword ptr [rbp - 0x51]
0005a113  488bc7                   mov rax, rdi
0005a116  48c1e828                 shr rax, 0x28
0005a11a  3cfe                     cmp al, 0xfe
0005a11c  7574                     jne 0x5a192
0005a11e  4d8b4538                 mov r8, qword ptr [r13 + 0x38]
0005a122  4c8d4da7                 lea r9, [rbp - 0x59]
0005a126  498bd7                   mov rdx, r15
0005a129  e872c3ffff               call 0x564a0
0005a12e  488b7da7                 mov rdi, qword ptr [rbp - 0x59]
0005a132  eb5e                     jmp 0x5a192
0005a134  48c1e808                 shr rax, 8
0005a138  a8c0                     test al, 0xc0
0005a13a  741b                     je 0x5a157
0005a13c  49837c241000             cmp qword ptr [r12 + 0x10], 0
0005a142  7513                     jne 0x5a157
0005a144  4c8d4daf                 lea r9, [rbp - 0x51]
0005a148  4d8bc5                   mov r8, r13
0005a14b  498bd4                   mov rdx, r12
0005a14e  e87dbdffff               call 0x55ed0
0005a153  488b5daf                 mov rbx, qword ptr [rbp - 0x51]
0005a157  488bc7                   mov rax, rdi
0005a15a  48c1e808                 shr rax, 8
0005a15e  a8c0                     test al, 0xc0
0005a160  741a                     je 0x5a17c
0005a162  49837f1000               cmp qword ptr [r15 + 0x10], 0
0005a167  7513                     jne 0x5a17c
0005a169  4c8d4da7                 lea r9, [rbp - 0x59]
0005a16d  4d8bc5                   mov r8, r13
0005a170  498bd7                   mov rdx, r15
0005a173  e858bdffff               call 0x55ed0
0005a178  488b7da7                 mov rdi, qword ptr [rbp - 0x59]
0005a17c  4881e3ff3fffff           and rbx, 0xffffffffffff3fff
0005a183  4881e7ff3fffff           and rdi, 0xffffffffffff3fff
0005a18a  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a18e  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a192  498b0c24                 mov rcx, qword ptr [r12]
0005a196  41bd40db0000             mov r13d, 0xdb40
0005a19c  66443929                 cmp word ptr [rcx], r13w
0005a1a0  7527                     jne 0x5a1c9
0005a1a2  418b542408               mov edx, dword ptr [r12 + 8]
0005a1a7  4d8d44240e               lea r8, [r12 + 0xe]
0005a1ac  493bc8                   cmp rcx, r8
0005a1af  7455                     je 0x5a206
0005a1b1  83fa01                   cmp edx, 1
0005a1b4  760c                     jbe 0x5a1c2
0005a1b6  440fb74902               movzx r9d, word ptr [rcx + 2]
0005a1bb  6644894db7               mov word ptr [rbp - 0x49], r9w
0005a1c0  eb05                     jmp 0x5a1c7
0005a1c2  440fb74db7               movzx r9d, word ptr [rbp - 0x49]
0005a1c7  7750                     ja 0x5a219
0005a1c9  448b55c3                 mov r10d, dword ptr [rbp - 0x3d]
0005a1cd  4533db                   xor r11d, r11d
0005a1d0  498b0f                   mov rcx, qword ptr [r15]
0005a1d3  66443929                 cmp word ptr [rcx], r13w
0005a1d7  0f8520010000             jne 0x5a2fd
0005a1dd  418b5708                 mov edx, dword ptr [r15 + 8]
0005a1e1  4d8d470e                 lea r8, [r15 + 0xe]
0005a1e5  493bc8                   cmp rcx, r8
0005a1e8  0f84a4000000             je 0x5a292
0005a1ee  83fa01                   cmp edx, 1
0005a1f1  0f8692000000             jbe 0x5a289
0005a1f7  440fb74902               movzx r9d, word ptr [rcx + 2]
0005a1fc  6644894db9               mov word ptr [rbp - 0x47], r9w
0005a201  e988000000               jmp 0x5a28e
0005a206  83fa01                   cmp edx, 1
0005a209  76be                     jbe 0x5a1c9
0005a20b  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a210  440fb708                 movzx r9d, word ptr [rax]
0005a214  6644894db7               mov word ptr [rbp - 0x49], r9w
0005a219  41baef000000             mov r10d, 0xef
0005a21f  b800230000               mov eax, 0x2300
0005a224  4103c1                   add eax, r9d
0005a227  4533db                   xor r11d, r11d
0005a22a  66413bc2                 cmp ax, r10w
0005a22e  448b55c3                 mov r10d, dword ptr [rbp - 0x3d]
0005a232  779c                     ja 0x5a1d0
0005a234  418bdb                   mov ebx, r11d
0005a237  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a23b  4585d2                   test r10d, r10d
0005a23e  751c                     jne 0x5a25c
0005a240  418d4102                 lea eax, [r9 + 2]
0005a244  0fb6d8                   movzx ebx, al
0005a247  48b80000000000150000     movabs rax, 0x150000000000
0005a251  48c1e320                 shl rbx, 0x20
0005a255  480bd8                   or rbx, rax
0005a258  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a25c  8d42ff                   lea eax, [rdx - 1]
0005a25f  4189442408               mov dword ptr [r12 + 8], eax
0005a264  493bc8                   cmp rcx, r8
0005a267  740d                     je 0x5a276
0005a269  488d4102                 lea rax, [rcx + 2]
0005a26d  49890424                 mov qword ptr [r12], rax
0005a271  e95affffff               jmp 0x5a1d0
0005a276  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a27b  49890424                 mov qword ptr [r12], rax
0005a27f  4d895c2410               mov qword ptr [r12 + 0x10], r11
0005a284  e947ffffff               jmp 0x5a1d0
0005a289  440fb74db9               movzx r9d, word ptr [rbp - 0x47]
0005a28e  766d                     jbe 0x5a2fd
0005a290  eb12                     jmp 0x5a2a4
0005a292  83fa01                   cmp edx, 1
0005a295  7666                     jbe 0x5a2fd
0005a297  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a29b  440fb708                 movzx r9d, word ptr [rax]
0005a29f  6644894db9               mov word ptr [rbp - 0x47], r9w
0005a2a4  b800230000               mov eax, 0x2300
0005a2a9  41bdef000000             mov r13d, 0xef
0005a2af  4103c1                   add eax, r9d
0005a2b2  66413bc5                 cmp ax, r13w
0005a2b6  7745                     ja 0x5a2fd
0005a2b8  4c895da7                 mov qword ptr [rbp - 0x59], r11
0005a2bc  498bfb                   mov rdi, r11
0005a2bf  4585d2                   test r10d, r10d
0005a2c2  751c                     jne 0x5a2e0
0005a2c4  418d4102                 lea eax, [r9 + 2]
0005a2c8  0fb6f8                   movzx edi, al
0005a2cb  48b80000000000150000     movabs rax, 0x150000000000
0005a2d5  48c1e720                 shl rdi, 0x20
0005a2d9  480bf8                   or rdi, rax
0005a2dc  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a2e0  8d42ff                   lea eax, [rdx - 1]
0005a2e3  41894708                 mov dword ptr [r15 + 8], eax
0005a2e7  493bc8                   cmp rcx, r8
0005a2ea  7406                     je 0x5a2f2
0005a2ec  488d4102                 lea rax, [rcx + 2]
0005a2f0  eb08                     jmp 0x5a2fa
0005a2f2  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a2f6  4d895f10                 mov qword ptr [r15 + 0x10], r11
0005a2fa  498907                   mov qword ptr [r15], rax
0005a2fd  4c8bdb                   mov r11, rbx
0005a300  4c8bef                   mov r13, rdi
0005a303  49c1eb28                 shr r11, 0x28
0005a307  49c1ed28                 shr r13, 0x28
0005a30b  4c895dcf                 mov qword ptr [rbp - 0x31], r11
0005a30f  4c896dd7                 mov qword ptr [rbp - 0x29], r13
0005a313  4180fb06                 cmp r11b, 6
0005a317  0f861f010000             jbe 0x5a43c
0005a31d  4180fd06                 cmp r13b, 6
0005a321  0f867f010000             jbe 0x5a4a6
0005a327  4180fb15                 cmp r11b, 0x15
0005a32b  0f8475010000             je 0x5a4a6
0005a331  4180fd15                 cmp r13b, 0x15
0005a335  0f846b010000             je 0x5a4a6
0005a33b  4c8bf3                   mov r14, rbx
0005a33e  488bf7                   mov rsi, rdi
0005a341  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005a345  b803000000               mov eax, 3
0005a34a  41b901000000             mov r9d, 1
0005a350  488bd3                   mov rdx, rbx
0005a353  4c8bc7                   mov r8, rdi
0005a356  48c1ea10                 shr rdx, 0x10
0005a35a  49c1e810                 shr r8, 0x10
0005a35e  413bd0                   cmp edx, r8d
0005a361  0f8592120000             jne 0x5b5f9
0005a367  33c0                     xor eax, eax
0005a369  4c8beb                   mov r13, rbx
0005a36c  49c1ed28                 shr r13, 0x28
0005a370  4180fd14                 cmp r13b, 0x14
0005a374  0f96c0                   setbe al
0005a377  8945f3                   mov dword ptr [rbp - 0xd], eax
0005a37a  483bdf                   cmp rbx, rdi
0005a37d  0f848c000000             je 0x5a40f
0005a383  4c8b5567                 mov r10, qword ptr [rbp + 0x67]
0005a387  418d4540                 lea eax, [r13 + 0x40]
0005a38b  3c30                     cmp al, 0x30
0005a38d  0f87bc100000             ja 0x5b44f
0005a393  418b0a                   mov ecx, dword ptr [r10]
0005a396  8bc1                     mov eax, ecx
0005a398  25ff030000               and eax, 0x3ff
0005a39d  83f804                   cmp eax, 4
0005a3a0  740c                     je 0x5a3ae
0005a3a2  81f911040400             cmp ecx, 0x40411
0005a3a8  0f85a1100000             jne 0x5b44f
0005a3ae  0fb6cb                   movzx ecx, bl
0005a3b1  c1e108                   shl ecx, 8
0005a3b4  48c1eb08                 shr rbx, 8
0005a3b8  0fb6db                   movzx ebx, bl
0005a3bb  480bd9                   or rbx, rcx
0005a3be  8bc2                     mov eax, edx
0005a3c0  400fb6cf                 movzx ecx, dil
0005a3c4  480bd8                   or rbx, rax
0005a3c7  48c1ef08                 shr rdi, 8
0005a3cb  400fb6ff                 movzx edi, dil
0005a3cf  c1e108                   shl ecx, 8
0005a3d2  480bf9                   or rdi, rcx
0005a3d5  418bc0                   mov eax, r8d
0005a3d8  480bf8                   or rdi, rax
0005a3db  48c1e310                 shl rbx, 0x10
0005a3df  4881cb02020000           or rbx, 0x202
0005a3e6  48c1e710                 shl rdi, 0x10
0005a3ea  4881cf02020000           or rdi, 0x202
0005a3f1  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a3f5  488bcf                   mov rcx, rdi
0005a3f8  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a3fc  488bc3                   mov rax, rbx
0005a3ff  48c1e910                 shr rcx, 0x10
0005a403  48c1e810                 shr rax, 0x10
0005a407  3bc1                     cmp eax, ecx
0005a409  0f85dc110000             jne 0x5b5eb
0005a40f  41ba01000000             mov r10d, 1
0005a415  4d8b442410               mov r8, qword ptr [r12 + 0x10]
0005a41a  418b442408               mov eax, dword ptr [r12 + 8]
0005a41f  4d85c0                   test r8, r8
0005a422  0f85f7100000             jne 0x5b51f
0005a428  4983042402               add qword ptr [r12], 2
0005a42d  ffc8                     dec eax
0005a42f  4189442408               mov dword ptr [r12 + 8], eax
0005a434  4533c9                   xor r9d, r9d
0005a437  e911110000               jmp 0x5b54d
0005a43c  4584db                   test r11b, r11b
0005a43f  7565                     jne 0x5a4a6
0005a441  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005a446  498d44240e               lea rax, [r12 + 0xe]
0005a44b  498b1424                 mov rdx, qword ptr [r12]
0005a44f  ffc9                     dec ecx
0005a451  483bd0                   cmp rdx, rax
0005a454  7406                     je 0x5a45c
0005a456  488d4202                 lea rax, [rdx + 2]
0005a45a  eb0e                     jmp 0x5a46a
0005a45c  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a461  49c744241000000000       mov qword ptr [r12 + 0x10], 0
0005a46a  49890424                 mov qword ptr [r12], rax
0005a46e  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005a472  41894c2408               mov dword ptr [r12 + 8], ecx
0005a477  85c9                     test ecx, ecx
0005a479  741c                     je 0x5a497
0005a47b  0fb708                   movzx ecx, word ptr [rax]
0005a47e  498b4008                 mov rax, qword ptr [r8 + 8]
0005a482  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a485  0fb7da                   movzx ebx, dx
0005a488  48c1e320                 shl rbx, 0x20
0005a48c  48c1ea10                 shr rdx, 0x10
0005a490  480bda                   or rbx, rdx
0005a493  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a497  41ba01000000             mov r10d, 1
0005a49d  458bca                   mov r9d, r10d
0005a4a0  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a4a4  eb0e                     jmp 0x5a4b4
0005a4a6  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005a4aa  41ba01000000             mov r10d, 1
0005a4b0  448b4d9f                 mov r9d, dword ptr [rbp - 0x61]
0005a4b4  4584ed                   test r13b, r13b
0005a4b7  7552                     jne 0x5a50b
0005a4b9  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005a4bd  498d470e                 lea rax, [r15 + 0xe]
0005a4c1  498b17                   mov rdx, qword ptr [r15]
0005a4c4  ffc9                     dec ecx
0005a4c6  483bd0                   cmp rdx, rax
0005a4c9  7406                     je 0x5a4d1
0005a4cb  488d4202                 lea rax, [rdx + 2]
0005a4cf  eb0c                     jmp 0x5a4dd
0005a4d1  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a4d5  49c7471000000000         mov qword ptr [r15 + 0x10], 0
0005a4dd  498907                   mov qword ptr [r15], rax
0005a4e0  41894f08                 mov dword ptr [r15 + 8], ecx
0005a4e4  85c9                     test ecx, ecx
0005a4e6  741c                     je 0x5a504
0005a4e8  0fb708                   movzx ecx, word ptr [rax]
0005a4eb  498b4008                 mov rax, qword ptr [r8 + 8]
0005a4ef  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a4f2  0fb7fa                   movzx edi, dx
0005a4f5  48c1e720                 shl rdi, 0x20
0005a4f9  48c1ea10                 shr rdx, 0x10
0005a4fd  480bfa                   or rdi, rdx
0005a500  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a504  458bca                   mov r9d, r10d
0005a507  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a50b  837df700                 cmp dword ptr [rbp - 9], 0
0005a50f  0f84c1000000             je 0x5a5d6
0005a515  837df300                 cmp dword ptr [rbp - 0xd], 0
0005a519  0f84b7000000             je 0x5a5d6
0005a51f  4180fb01                 cmp r11b, 1
0005a523  7559                     jne 0x5a57e
0005a525  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005a52a  498d44240e               lea rax, [r12 + 0xe]
0005a52f  498b1424                 mov rdx, qword ptr [r12]
0005a533  ffc9                     dec ecx
0005a535  483bd0                   cmp rdx, rax
0005a538  7406                     je 0x5a540
0005a53a  488d4202                 lea rax, [rdx + 2]
0005a53e  eb0e                     jmp 0x5a54e
0005a540  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a545  49c744241000000000       mov qword ptr [r12 + 0x10], 0
0005a54e  49890424                 mov qword ptr [r12], rax
0005a552  41894c2408               mov dword ptr [r12 + 8], ecx
0005a557  85c9                     test ecx, ecx
0005a559  741c                     je 0x5a577
0005a55b  0fb708                   movzx ecx, word ptr [rax]
0005a55e  498b4008                 mov rax, qword ptr [r8 + 8]
0005a562  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a565  0fb7da                   movzx ebx, dx
0005a568  48c1e320                 shl rbx, 0x20
0005a56c  48c1ea10                 shr rdx, 0x10
0005a570  480bda                   or rbx, rdx
0005a573  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a577  458bca                   mov r9d, r10d
0005a57a  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a57e  4180fd01                 cmp r13b, 1
0005a582  7552                     jne 0x5a5d6
0005a584  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005a588  498d470e                 lea rax, [r15 + 0xe]
0005a58c  498b17                   mov rdx, qword ptr [r15]
0005a58f  ffc9                     dec ecx
0005a591  483bd0                   cmp rdx, rax
0005a594  7406                     je 0x5a59c
0005a596  488d4202                 lea rax, [rdx + 2]
0005a59a  eb0c                     jmp 0x5a5a8
0005a59c  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a5a0  49c7471000000000         mov qword ptr [r15 + 0x10], 0
0005a5a8  498907                   mov qword ptr [r15], rax
0005a5ab  41894f08                 mov dword ptr [r15 + 8], ecx
0005a5af  85c9                     test ecx, ecx
0005a5b1  741c                     je 0x5a5cf
0005a5b3  0fb708                   movzx ecx, word ptr [rax]
0005a5b6  498b4008                 mov rax, qword ptr [r8 + 8]
0005a5ba  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a5bd  0fb7fa                   movzx edi, dx
0005a5c0  48c1e720                 shl rdi, 0x20
0005a5c4  48c1ea10                 shr rdx, 0x10
0005a5c8  480bfa                   or rdi, rdx
0005a5cb  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a5cf  458bca                   mov r9d, r10d
0005a5d2  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a5d6  4180fb02                 cmp r11b, 2
0005a5da  0f85c8000000             jne 0x5a6a8
0005a5e0  458b5c2408               mov r11d, dword ptr [r12 + 8]
0005a5e5  4d8d4c240e               lea r9, [r12 + 0xe]
0005a5ea  488bc3                   mov rax, rbx
0005a5ed  498d54240c               lea rdx, [r12 + 0xc]
0005a5f2  48c1e808                 shr rax, 8
0005a5f6  0fb6c8                   movzx ecx, al
0005a5f9  48c1eb20                 shr rbx, 0x20
0005a5fd  48c1e108                 shl rcx, 8
0005a601  0fb6c3                   movzx eax, bl
0005a604  480bc8                   or rcx, rax
0005a607  488b455f                 mov rax, qword ptr [rbp + 0x5f]
0005a60b  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
0005a612  448b0488                 mov r8d, dword ptr [rax + rcx*4]
0005a616  440fb71488               movzx r10d, word ptr [rax + rcx*4]
0005a61b  498b0424                 mov rax, qword ptr [r12]
0005a61f  41c1e810                 shr r8d, 0x10
0005a623  493bc1                   cmp rax, r9
0005a626  741c                     je 0x5a644
0005a628  498b4c2410               mov rcx, qword ptr [r12 + 0x10]
0005a62d  4883c002                 add rax, 2
0005a631  49890424                 mov qword ptr [r12], rax
0005a635  66448912                 mov word ptr [rdx], r10w
0005a639  66458901                 mov word ptr [r9], r8w
0005a63d  4885c9                   test rcx, rcx
0005a640  7523                     jne 0x5a665
0005a642  eb18                     jmp 0x5a65c
0005a644  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a649  33c9                     xor ecx, ecx
0005a64b  49894c2410               mov qword ptr [r12 + 0x10], rcx
0005a650  49890424                 mov qword ptr [r12], rax
0005a654  66448912                 mov word ptr [rdx], r10w
0005a658  66458901                 mov word ptr [r9], r8w
0005a65c  498b0424                 mov rax, qword ptr [r12]
0005a660  4989442410               mov qword ptr [r12 + 0x10], rax
0005a665  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005a669  418d4301                 lea eax, [r11 + 1]
0005a66d  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005a671  49891424                 mov qword ptr [r12], rdx
0005a675  4189442408               mov dword ptr [r12 + 8], eax
0005a67a  498b4008                 mov rax, qword ptr [r8 + 8]
0005a67e  428b1490                 mov edx, dword ptr [rax + r10*4]
0005a682  41ba01000000             mov r10d, 1
0005a688  0fb7da                   movzx ebx, dx
0005a68b  458bca                   mov r9d, r10d
0005a68e  48c1e320                 shl rbx, 0x20
0005a692  48c1ea10                 shr rdx, 0x10
0005a696  480bda                   or rbx, rdx
0005a699  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a69d  33d2                     xor edx, edx
0005a69f  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a6a3  448bf2                   mov r14d, edx
0005a6a6  eb06                     jmp 0x5a6ae
0005a6a8  4c8b4567                 mov r8, qword ptr [rbp + 0x67]
0005a6ac  33d2                     xor edx, edx
0005a6ae  4180fd02                 cmp r13b, 2
0005a6b2  0f85b9000000             jne 0x5a771
0005a6b8  458b5f08                 mov r11d, dword ptr [r15 + 8]
0005a6bc  4d8d4f0e                 lea r9, [r15 + 0xe]
0005a6c0  488bc7                   mov rax, rdi
0005a6c3  48c1ef20                 shr rdi, 0x20
0005a6c7  48c1e808                 shr rax, 8
0005a6cb  0fb6c8                   movzx ecx, al
0005a6ce  48c1e108                 shl rcx, 8
0005a6d2  400fb6c7                 movzx eax, dil
0005a6d6  480bc8                   or rcx, rax
0005a6d9  488b455f                 mov rax, qword ptr [rbp + 0x5f]
0005a6dd  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
0005a6e4  448b0488                 mov r8d, dword ptr [rax + rcx*4]
0005a6e8  440fb71488               movzx r10d, word ptr [rax + rcx*4]
0005a6ed  498b07                   mov rax, qword ptr [r15]
0005a6f0  41c1e810                 shr r8d, 0x10
0005a6f4  493bc1                   cmp rax, r9
0005a6f7  741e                     je 0x5a717
0005a6f9  498b4f10                 mov rcx, qword ptr [r15 + 0x10]
0005a6fd  498d570c                 lea rdx, [r15 + 0xc]
0005a701  4883c002                 add rax, 2
0005a705  498907                   mov qword ptr [r15], rax
0005a708  66448912                 mov word ptr [rdx], r10w
0005a70c  66458901                 mov word ptr [r9], r8w
0005a710  4885c9                   test rcx, rcx
0005a713  7520                     jne 0x5a735
0005a715  eb17                     jmp 0x5a72e
0005a717  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a71b  49895710                 mov qword ptr [r15 + 0x10], rdx
0005a71f  498d570c                 lea rdx, [r15 + 0xc]
0005a723  498907                   mov qword ptr [r15], rax
0005a726  66448912                 mov word ptr [rdx], r10w
0005a72a  66458901                 mov word ptr [r9], r8w
0005a72e  498b07                   mov rax, qword ptr [r15]
0005a731  49894710                 mov qword ptr [r15 + 0x10], rax
0005a735  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005a739  418d4301                 lea eax, [r11 + 1]
0005a73d  498917                   mov qword ptr [r15], rdx
0005a740  41894708                 mov dword ptr [r15 + 8], eax
0005a744  498b4508                 mov rax, qword ptr [r13 + 8]
0005a748  428b1490                 mov edx, dword ptr [rax + r10*4]
0005a74c  41ba01000000             mov r10d, 1
0005a752  0fb7fa                   movzx edi, dx
0005a755  458bca                   mov r9d, r10d
0005a758  48c1e720                 shl rdi, 0x20
0005a75c  48c1ea10                 shr rdx, 0x10
0005a760  480bfa                   or rdi, rdx
0005a763  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a767  33d2                     xor edx, edx
0005a769  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a76d  8bf2                     mov esi, edx
0005a76f  eb09                     jmp 0x5a77a
0005a771  4585c9                   test r9d, r9d
0005a774  7425                     je 0x5a79b
0005a776  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005a77a  418b442408               mov eax, dword ptr [r12 + 8]
0005a77f  85c0                     test eax, eax
0005a781  740b                     je 0x5a78e
0005a783  41837f0800               cmp dword ptr [r15 + 8], 0
0005a788  0f8544f9ffff             jne 0x5a0d2
0005a78e  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005a792  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
0005a796  e985f8ffff               jmp 0x5a020
0005a79b  410fb6c3                 movzx eax, r11b
0005a79f  83f815                   cmp eax, 0x15
0005a7a2  0f87d5030000             ja 0x5ab7d
0005a7a8  488d0d5158faff           lea rcx, [rip - 0x5a7af]
0005a7af  8b8c8180b80500           mov ecx, dword ptr [rcx + rax*4 + 0x5b880]
0005a7b6  488d054358faff           lea rax, [rip - 0x5a7bd]
0005a7bd  4803c8                   add rcx, rax
0005a7c0  ffe1                     jmp rcx
0005a7c2  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005a7c6  4d8bc4                   mov r8, r12
0005a7c9  e892110000               call 0x5b960
0005a7ce  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005a7d2  440fb7e8                 movzx r13d, ax
0005a7d6  33d2                     xor edx, edx
0005a7d8  0fb6c3                   movzx eax, bl
0005a7db  664403e8                 add r13w, ax
0005a7df  440fb7c2                 movzx r8d, dx
0005a7e3  44385dd7                 cmp byte ptr [rbp - 0x29], r11b
0005a7e7  7571                     jne 0x5a85a
0005a7e9  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005a7ed  4d8bc7                   mov r8, r15
0005a7f0  e86b110000               call 0x5b960
0005a7f5  498b0f                   mov rcx, qword ptr [r15]
0005a7f8  440fb7c0                 movzx r8d, ax
0005a7fc  400fb6c7                 movzx eax, dil
0005a800  664403c0                 add r8w, ax
0005a804  498d470e                 lea rax, [r15 + 0xe]
0005a808  483bc8                   cmp rcx, rax
0005a80b  740c                     je 0x5a819
0005a80d  41ff4f08                 dec dword ptr [r15 + 8]
0005a811  488d4102                 lea rax, [rcx + 2]
0005a815  33d2                     xor edx, edx
0005a817  eb0e                     jmp 0x5a827
0005a819  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005a81d  33d2                     xor edx, edx
0005a81f  41ff4f08                 dec dword ptr [r15 + 8]
0005a823  49895710                 mov qword ptr [r15 + 0x10], rdx
0005a827  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005a82b  4c8b4d67                 mov r9, qword ptr [rbp + 0x67]
0005a82f  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005a833  498907                   mov qword ptr [r15], rax
0005a836  85c9                     test ecx, ecx
0005a838  7424                     je 0x5a85e
0005a83a  0fb708                   movzx ecx, word ptr [rax]
0005a83d  498b4108                 mov rax, qword ptr [r9 + 8]
0005a841  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a844  0fb7fa                   movzx edi, dx
0005a847  48c1e720                 shl rdi, 0x20
0005a84b  48c1ea10                 shr rdx, 0x10
0005a84f  480bfa                   or rdi, rdx
0005a852  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a856  33d2                     xor edx, edx
0005a858  eb04                     jmp 0x5a85e
0005a85a  4c8b4d67                 mov r9, qword ptr [rbp + 0x67]
0005a85e  66453be8                 cmp r13w, r8w
0005a862  742a                     je 0x5a88e
0005a864  837d8f00                 cmp dword ptr [rbp - 0x71], 0
0005a868  7f07                     jg 0x5a871
0005a86a  4183791000               cmp dword ptr [r9 + 0x10], 0
0005a86f  741d                     je 0x5a88e
0005a871  41ba01000000             mov r10d, 1
0005a877  89558f                   mov dword ptr [rbp - 0x71], edx
0005a87a  66453be8                 cmp r13w, r8w
0005a87e  418bc2                   mov eax, r10d
0005a881  b903000000               mov ecx, 3
0005a886  0f47c1                   cmova eax, ecx
0005a889  894597                   mov dword ptr [rbp - 0x69], eax
0005a88c  eb06                     jmp 0x5a894
0005a88e  41ba01000000             mov r10d, 1
0005a894  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005a899  498d44240e               lea rax, [r12 + 0xe]
0005a89e  498b1424                 mov rdx, qword ptr [r12]
0005a8a2  ffc9                     dec ecx
0005a8a4  483bd0                   cmp rdx, rax
0005a8a7  7406                     je 0x5a8af
0005a8a9  488d4202                 lea rax, [rdx + 2]
0005a8ad  eb0c                     jmp 0x5a8bb
0005a8af  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a8b4  33d2                     xor edx, edx
0005a8b6  4989542410               mov qword ptr [r12 + 0x10], rdx
0005a8bb  49890424                 mov qword ptr [r12], rax
0005a8bf  41894c2408               mov dword ptr [r12 + 8], ecx
0005a8c4  85c9                     test ecx, ecx
0005a8c6  741c                     je 0x5a8e4
0005a8c8  0fb708                   movzx ecx, word ptr [rax]
0005a8cb  498b4108                 mov rax, qword ptr [r9 + 8]
0005a8cf  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a8d2  0fb7da                   movzx ebx, dx
0005a8d5  48c1e320                 shl rbx, 0x20
0005a8d9  48c1ea10                 shr rdx, 0x10
0005a8dd  480bda                   or rbx, rdx
0005a8e0  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a8e4  4c8b6dd7                 mov r13, qword ptr [rbp - 0x29]
0005a8e8  458bca                   mov r9d, r10d
0005a8eb  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a8ef  e98c020000               jmp 0x5ab80
0005a8f4  488bc2                   mov rax, rdx
0005a8f7  453aeb                   cmp r13b, r11b
0005a8fa  754c                     jne 0x5a948
0005a8fc  498b17                   mov rdx, qword ptr [r15]
0005a8ff  498d4f0e                 lea rcx, [r15 + 0xe]
0005a903  488bc7                   mov rax, rdi
0005a906  483bd1                   cmp rdx, rcx
0005a909  7406                     je 0x5a911
0005a90b  488d4a02                 lea rcx, [rdx + 2]
0005a90f  eb0a                     jmp 0x5a91b
0005a911  498b4f10                 mov rcx, qword ptr [r15 + 0x10]
0005a915  33d2                     xor edx, edx
0005a917  49895710                 mov qword ptr [r15 + 0x10], rdx
0005a91b  41ff4f08                 dec dword ptr [r15 + 8]
0005a91f  418b5708                 mov edx, dword ptr [r15 + 8]
0005a923  49890f                   mov qword ptr [r15], rcx
0005a926  85d2                     test edx, edx
0005a928  741e                     je 0x5a948
0005a92a  0fb711                   movzx edx, word ptr [rcx]
0005a92d  498b4808                 mov rcx, qword ptr [r8 + 8]
0005a931  448b0491                 mov r8d, dword ptr [rcx + rdx*4]
0005a935  410fb7f8                 movzx edi, r8w
0005a939  48c1e720                 shl rdi, 0x20
0005a93d  49c1e810                 shr r8, 0x10
0005a941  490bf8                   or rdi, r8
0005a944  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005a948  837d8f06                 cmp dword ptr [rbp - 0x71], 6
0005a94c  7e22                     jle 0x5a970
0005a94e  488bcb                   mov rcx, rbx
0005a951  48c1e810                 shr rax, 0x10
0005a955  48c1e910                 shr rcx, 0x10
0005a959  3bc8                     cmp ecx, eax
0005a95b  7413                     je 0x5a970
0005a95d  ba03000000               mov edx, 3
0005a962  c7458f06000000           mov dword ptr [rbp - 0x71], 6
0005a969  410f42d2                 cmovb edx, r10d
0005a96d  895597                   mov dword ptr [rbp - 0x69], edx
0005a970  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005a975  498d44240e               lea rax, [r12 + 0xe]
0005a97a  498b1424                 mov rdx, qword ptr [r12]
0005a97e  ffc9                     dec ecx
0005a980  483bd0                   cmp rdx, rax
0005a983  7406                     je 0x5a98b
0005a985  488d4202                 lea rax, [rdx + 2]
0005a989  eb0c                     jmp 0x5a997
0005a98b  498b442410               mov rax, qword ptr [r12 + 0x10]
0005a990  33d2                     xor edx, edx
0005a992  4989542410               mov qword ptr [r12 + 0x10], rdx
0005a997  49890424                 mov qword ptr [r12], rax
0005a99b  41894c2408               mov dword ptr [r12 + 8], ecx
0005a9a0  85c9                     test ecx, ecx
0005a9a2  7420                     je 0x5a9c4
0005a9a4  0fb708                   movzx ecx, word ptr [rax]
0005a9a7  488b4567                 mov rax, qword ptr [rbp + 0x67]
0005a9ab  488b4008                 mov rax, qword ptr [rax + 8]
0005a9af  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005a9b2  0fb7da                   movzx ebx, dx
0005a9b5  48c1e320                 shl rbx, 0x20
0005a9b9  48c1ea10                 shr rdx, 0x10
0005a9bd  480bda                   or rbx, rdx
0005a9c0  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005a9c4  458bca                   mov r9d, r10d
0005a9c7  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005a9cb  e9b0010000               jmp 0x5ab80
0005a9d0  4c8bf3                   mov r14, rbx
0005a9d3  4180fd06                 cmp r13b, 6
0005a9d7  0f84a3010000             je 0x5ab80
0005a9dd  837d8f07                 cmp dword ptr [rbp - 0x71], 7
0005a9e1  7f0a                     jg 0x5a9ed
0005a9e3  758b                     jne 0x5a970
0005a9e5  837dc700                 cmp dword ptr [rbp - 0x39], 0
0005a9e9  7585                     jne 0x5a970
0005a9eb  eb03                     jmp 0x5a9f0
0005a9ed  8955bf                   mov dword ptr [rbp - 0x41], edx
0005a9f0  448955c7                 mov dword ptr [rbp - 0x39], r10d
0005a9f4  c7459703000000           mov dword ptr [rbp - 0x69], 3
0005a9fb  c7458f07000000           mov dword ptr [rbp - 0x71], 7
0005aa02  e969ffffff               jmp 0x5a970
0005aa07  4180fd06                 cmp r13b, 6
0005aa0b  0f846f010000             je 0x5ab80
0005aa11  4180fd01                 cmp r13b, 1
0005aa15  0f8465010000             je 0x5ab80
0005aa1b  89542450                 mov dword ptr [rsp + 0x50], edx
0005aa1f  488bc7                   mov rax, rdi
0005aa22  488bcb                   mov rcx, rbx
0005aa25  4c8bf2                   mov r14, rdx
0005aa28  4180fd04                 cmp r13b, 4
0005aa2c  4d8bcf                   mov r9, r15
0005aa2f  4d8bc4                   mov r8, r12
0005aa32  480f44f2                 cmove rsi, rdx
0005aa36  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005aa3a  48c1e820                 shr rax, 0x20
0005aa3e  6689459f                 mov word ptr [rbp - 0x61], ax
0005aa42  48c1e920                 shr rcx, 0x20
0005aa46  66894d93                 mov word ptr [rbp - 0x6d], cx
0005aa4a  48c1e710                 shl rdi, 0x10
0005aa4e  0bf8                     or edi, eax
0005aa50  48c1e310                 shl rbx, 0x10
0005aa54  0bd9                     or ebx, ecx
0005aa56  897da7                   mov dword ptr [rbp - 0x59], edi
0005aa59  488b4d5f                 mov rcx, qword ptr [rbp + 0x5f]
0005aa5d  488d45fb                 lea rax, [rbp - 5]
0005aa61  4889442448               mov qword ptr [rsp + 0x48], rax
0005aa66  488d45ef                 lea rax, [rbp - 0x11]
0005aa6a  4889442440               mov qword ptr [rsp + 0x40], rax
0005aa6f  488d459f                 lea rax, [rbp - 0x61]
0005aa73  4889442438               mov qword ptr [rsp + 0x38], rax
0005aa78  488d4593                 lea rax, [rbp - 0x6d]
0005aa7c  4889442430               mov qword ptr [rsp + 0x30], rax
0005aa81  488d45a7                 lea rax, [rbp - 0x59]
0005aa85  4889442428               mov qword ptr [rsp + 0x28], rax
0005aa8a  488d45d7                 lea rax, [rbp - 0x29]
0005aa8e  4889442420               mov qword ptr [rsp + 0x20], rax
0005aa93  895dd7                   mov dword ptr [rbp - 0x29], ebx
0005aa96  e84569ffff               call 0x513e0
0005aa9b  448bc8                   mov r9d, eax
0005aa9e  89459f                   mov dword ptr [rbp - 0x61], eax
0005aaa1  8b45fb                   mov eax, dword ptr [rbp - 5]
0005aaa4  83f802                   cmp eax, 2
0005aaa7  0f85bc0d0000             jne 0x5b869
0005aaad  8b45a7                   mov eax, dword ptr [rbp - 0x59]
0005aab0  41ba01000000             mov r10d, 1
0005aab6  8b4dd7                   mov ecx, dword ptr [rbp - 0x29]
0005aab9  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005aabd  0fb7d9                   movzx ebx, cx
0005aac0  0fb7f8                   movzx edi, ax
0005aac3  48c1e320                 shl rbx, 0x20
0005aac7  48c1e720                 shl rdi, 0x20
0005aacb  48c1e910                 shr rcx, 0x10
0005aacf  48c1e810                 shr rax, 0x10
0005aad3  480bd9                   or rbx, rcx
0005aad6  480bf8                   or rdi, rax
0005aad9  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005aadd  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005aae1  4585c9                   test r9d, r9d
0005aae4  0f8496000000             je 0x5ab80
0005aaea  41837c240800             cmp dword ptr [r12 + 8], 0
0005aaf0  0f848a000000             je 0x5ab80
0005aaf6  41837f0800               cmp dword ptr [r15 + 8], 0
0005aafb  49b802020000fffd0000     movabs r8, 0xfdff00000202
0005ab05  0f847f000000             je 0x5ab8a
0005ab0b  488b4567                 mov rax, qword ptr [rbp + 0x67]
0005ab0f  488b5008                 mov rdx, qword ptr [rax + 8]
0005ab13  498b0424                 mov rax, qword ptr [r12]
0005ab17  0fb708                   movzx ecx, word ptr [rax]
0005ab1a  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005ab1d  0fb7d8                   movzx ebx, ax
0005ab20  48c1e810                 shr rax, 0x10
0005ab24  48c1e320                 shl rbx, 0x20
0005ab28  480bd8                   or rbx, rax
0005ab2b  498b07                   mov rax, qword ptr [r15]
0005ab2e  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005ab32  0fb708                   movzx ecx, word ptr [rax]
0005ab35  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005ab38  0fb7f8                   movzx edi, ax
0005ab3b  48c1e720                 shl rdi, 0x20
0005ab3f  48c1e810                 shr rax, 0x10
0005ab43  480bf8                   or rdi, rax
0005ab46  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005ab4a  eb3e                     jmp 0x5ab8a
0005ab4c  488bc3                   mov rax, rbx
0005ab4f  49b802020000fffd0000     movabs r8, 0xfdff00000202
0005ab59  48c1e820                 shr rax, 0x20
0005ab5d  0fb6c8                   movzx ecx, al
0005ab60  0fb6c3                   movzx eax, bl
0005ab63  48c1e108                 shl rcx, 8
0005ab67  488bd9                   mov rbx, rcx
0005ab6a  480bd8                   or rbx, rax
0005ab6d  48c1e310                 shl rbx, 0x10
0005ab71  490bd8                   or rbx, r8
0005ab74  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005ab78  4c8bf3                   mov r14, rbx
0005ab7b  eb0d                     jmp 0x5ab8a
0005ab7d  4c8bf3                   mov r14, rbx
0005ab80  49b802020000fffd0000     movabs r8, 0xfdff00000202
0005ab8a  410fb6c5                 movzx eax, r13b
0005ab8e  83f815                   cmp eax, 0x15
0005ab91  0f87ab030000             ja 0x5af42
0005ab97  488d156254faff           lea rdx, [rip - 0x5ab9e]
0005ab9e  8b8c82d8b80500           mov ecx, dword ptr [rdx + rax*4 + 0x5b8d8]
0005aba5  4803ca                   add rcx, rdx
0005aba8  ffe1                     jmp rcx
0005abaa  453add                   cmp r11b, r13b
0005abad  0f8492030000             je 0x5af45
0005abb3  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005abb7  4d8bc7                   mov r8, r15
0005abba  498bd5                   mov rdx, r13
0005abbd  e89e0d0000               call 0x5b960
0005abc2  440fb7c0                 movzx r8d, ax
0005abc6  400fb6c7                 movzx eax, dil
0005abca  4403c0                   add r8d, eax
0005abcd  837d8f00                 cmp dword ptr [rbp - 0x71], 0
0005abd1  7f07                     jg 0x5abda
0005abd3  41837d1000               cmp dword ptr [r13 + 0x10], 0
0005abd8  7418                     je 0x5abf2
0005abda  41ba01000000             mov r10d, 1
0005abe0  4585c0                   test r8d, r8d
0005abe3  7413                     je 0x5abf8
0005abe5  4533c0                   xor r8d, r8d
0005abe8  44895597                 mov dword ptr [rbp - 0x69], r10d
0005abec  4489458f                 mov dword ptr [rbp - 0x71], r8d
0005abf0  eb09                     jmp 0x5abfb
0005abf2  41ba01000000             mov r10d, 1
0005abf8  4533c0                   xor r8d, r8d
0005abfb  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005abff  498d470e                 lea rax, [r15 + 0xe]
0005ac03  498b17                   mov rdx, qword ptr [r15]
0005ac06  ffc9                     dec ecx
0005ac08  483bd0                   cmp rdx, rax
0005ac0b  7406                     je 0x5ac13
0005ac0d  488d4202                 lea rax, [rdx + 2]
0005ac11  eb08                     jmp 0x5ac1b
0005ac13  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005ac17  4d894710                 mov qword ptr [r15 + 0x10], r8
0005ac1b  498907                   mov qword ptr [r15], rax
0005ac1e  41894f08                 mov dword ptr [r15 + 8], ecx
0005ac22  85c9                     test ecx, ecx
0005ac24  741c                     je 0x5ac42
0005ac26  0fb708                   movzx ecx, word ptr [rax]
0005ac29  498b4508                 mov rax, qword ptr [r13 + 8]
0005ac2d  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005ac30  0fb7fa                   movzx edi, dx
0005ac33  48c1e720                 shl rdi, 0x20
0005ac37  48c1ea10                 shr rdx, 0x10
0005ac3b  480bfa                   or rdi, rdx
0005ac3e  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005ac42  458bca                   mov r9d, r10d
0005ac45  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005ac49  e900030000               jmp 0x5af4e
0005ac4e  453add                   cmp r11b, r13b
0005ac51  0f84ee020000             je 0x5af45
0005ac57  837d8f06                 cmp dword ptr [rbp - 0x71], 6
0005ac5b  7e0b                     jle 0x5ac68
0005ac5d  44895597                 mov dword ptr [rbp - 0x69], r10d
0005ac61  c7458f06000000           mov dword ptr [rbp - 0x71], 6
0005ac68  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005ac6c  498d470e                 lea rax, [r15 + 0xe]
0005ac70  498b17                   mov rdx, qword ptr [r15]
0005ac73  ffc9                     dec ecx
0005ac75  483bd0                   cmp rdx, rax
0005ac78  7406                     je 0x5ac80
0005ac7a  488d4202                 lea rax, [rdx + 2]
0005ac7e  eb0a                     jmp 0x5ac8a
0005ac80  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005ac84  33d2                     xor edx, edx
0005ac86  49895710                 mov qword ptr [r15 + 0x10], rdx
0005ac8a  498907                   mov qword ptr [r15], rax
0005ac8d  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005ac91  41894f08                 mov dword ptr [r15 + 8], ecx
0005ac95  85c9                     test ecx, ecx
0005ac97  74a9                     je 0x5ac42
0005ac99  0fb708                   movzx ecx, word ptr [rax]
0005ac9c  458bca                   mov r9d, r10d
0005ac9f  498b4508                 mov rax, qword ptr [r13 + 8]
0005aca3  4489559f                 mov dword ptr [rbp - 0x61], r10d
0005aca7  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005acaa  0fb7fa                   movzx edi, dx
0005acad  48c1e720                 shl rdi, 0x20
0005acb1  48c1ea10                 shr rdx, 0x10
0005acb5  480bfa                   or rdi, rdx
0005acb8  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005acbc  e98d020000               jmp 0x5af4e
0005acc1  488bf7                   mov rsi, rdi
0005acc4  4180fb06                 cmp r11b, 6
0005acc8  7447                     je 0x5ad11
0005acca  837d8f07                 cmp dword ptr [rbp - 0x71], 7
0005acce  7f2b                     jg 0x5acfb
0005acd0  7506                     jne 0x5acd8
0005acd2  837dbf00                 cmp dword ptr [rbp - 0x41], 0
0005acd6  7428                     je 0x5ad00
0005acd8  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005acdc  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005ace0  498d470e                 lea rax, [r15 + 0xe]
0005ace4  498b17                   mov rdx, qword ptr [r15]
0005ace7  ffc9                     dec ecx
0005ace9  483bd0                   cmp rdx, rax
0005acec  0f84f9000000             je 0x5adeb
0005acf2  488d4202                 lea rax, [rdx + 2]
0005acf6  e920ffffff               jmp 0x5ac1b
0005acfb  33c0                     xor eax, eax
0005acfd  8945c7                   mov dword ptr [rbp - 0x39], eax
0005ad00  448955bf                 mov dword ptr [rbp - 0x41], r10d
0005ad04  44895597                 mov dword ptr [rbp - 0x69], r10d
0005ad08  c7458f07000000           mov dword ptr [rbp - 0x71], 7
0005ad0f  ebc7                     jmp 0x5acd8
0005ad11  837d8f07                 cmp dword ptr [rbp - 0x71], 7
0005ad15  7f23                     jg 0x5ad3a
0005ad17  7575                     jne 0x5ad8e
0005ad19  837dc700                 cmp dword ptr [rbp - 0x39], 0
0005ad1d  740c                     je 0x5ad2b
0005ad1f  837dbf00                 cmp dword ptr [rbp - 0x41], 0
0005ad23  7569                     jne 0x5ad8e
0005ad25  44895597                 mov dword ptr [rbp - 0x69], r10d
0005ad29  eb54                     jmp 0x5ad7f
0005ad2b  837dbf00                 cmp dword ptr [rbp - 0x41], 0
0005ad2f  7409                     je 0x5ad3a
0005ad31  c7459703000000           mov dword ptr [rbp - 0x69], 3
0005ad38  eb45                     jmp 0x5ad7f
0005ad3a  488bc3                   mov rax, rbx
0005ad3d  488bcf                   mov rcx, rdi
0005ad40  48c1e820                 shr rax, 0x20
0005ad44  48c1e920                 shr rcx, 0x20
0005ad48  3ac1                     cmp al, cl
0005ad4a  7527                     jne 0x5ad73
0005ad4c  488bc3                   mov rax, rbx
0005ad4f  488bcf                   mov rcx, rdi
0005ad52  48c1e808                 shr rax, 8
0005ad56  48c1e908                 shr rcx, 8
0005ad5a  3ac1                     cmp al, cl
0005ad5c  7306                     jae 0x5ad64
0005ad5e  44895597                 mov dword ptr [rbp - 0x69], r10d
0005ad62  eb1b                     jmp 0x5ad7f
0005ad64  0f86db010000             jbe 0x5af45
0005ad6a  c7459703000000           mov dword ptr [rbp - 0x69], 3
0005ad71  eb0c                     jmp 0x5ad7f
0005ad73  ba03000000               mov edx, 3
0005ad78  410f42d2                 cmovb edx, r10d
0005ad7c  895597                   mov dword ptr [rbp - 0x69], edx
0005ad7f  448955bf                 mov dword ptr [rbp - 0x41], r10d
0005ad83  448955c7                 mov dword ptr [rbp - 0x39], r10d
0005ad87  c7458f07000000           mov dword ptr [rbp - 0x71], 7
0005ad8e  418b4c2408               mov ecx, dword ptr [r12 + 8]
0005ad93  498d44240e               lea rax, [r12 + 0xe]
0005ad98  498b1424                 mov rdx, qword ptr [r12]
0005ad9c  ffc9                     dec ecx
0005ad9e  483bd0                   cmp rdx, rax
0005ada1  7406                     je 0x5ada9
0005ada3  488d4202                 lea rax, [rdx + 2]
0005ada7  eb0c                     jmp 0x5adb5
0005ada9  498b442410               mov rax, qword ptr [r12 + 0x10]
0005adae  33d2                     xor edx, edx
0005adb0  4989542410               mov qword ptr [r12 + 0x10], rdx
0005adb5  49890424                 mov qword ptr [r12], rax
0005adb9  41894c2408               mov dword ptr [r12 + 8], ecx
0005adbe  85c9                     test ecx, ecx
0005adc0  0f8412ffffff             je 0x5acd8
0005adc6  0fb708                   movzx ecx, word ptr [rax]
0005adc9  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005adcd  498b4508                 mov rax, qword ptr [r13 + 8]
0005add1  8b1488                   mov edx, dword ptr [rax + rcx*4]
0005add4  0fb7da                   movzx ebx, dx
0005add7  48c1e320                 shl rbx, 0x20
0005addb  48c1ea10                 shr rdx, 0x10
0005addf  480bda                   or rbx, rdx
0005ade2  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005ade6  e9f1feffff               jmp 0x5acdc
0005adeb  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005adef  33d2                     xor edx, edx
0005adf1  49895710                 mov qword ptr [r15 + 0x10], rdx
0005adf5  e921feffff               jmp 0x5ac1b
0005adfa  4585c9                   test r9d, r9d
0005adfd  0f8547010000             jne 0x5af4a
0005ae03  33c0                     xor eax, eax
0005ae05  8bf0                     mov esi, eax
0005ae07  4180fb04                 cmp r11b, 4
0005ae0b  0f8463030000             je 0x5b174
0005ae11  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005ae15  488bc7                   mov rax, rdi
0005ae18  48c1e820                 shr rax, 0x20
0005ae1c  488bcb                   mov rcx, rbx
0005ae1f  66894593                 mov word ptr [rbp - 0x6d], ax
0005ae23  4d8bcf                   mov r9, r15
0005ae26  48c1e920                 shr rcx, 0x20
0005ae2a  4d8bc4                   mov r8, r12
0005ae2d  66894d9f                 mov word ptr [rbp - 0x61], cx
0005ae31  48c1e710                 shl rdi, 0x10
0005ae35  0bf8                     or edi, eax
0005ae37  48c1e310                 shl rbx, 0x10
0005ae3b  33c0                     xor eax, eax
0005ae3d  897dd7                   mov dword ptr [rbp - 0x29], edi
0005ae40  89442450                 mov dword ptr [rsp + 0x50], eax
0005ae44  0bd9                     or ebx, ecx
0005ae46  488b4d5f                 mov rcx, qword ptr [rbp + 0x5f]
0005ae4a  488d45ff                 lea rax, [rbp - 1]
0005ae4e  4889442448               mov qword ptr [rsp + 0x48], rax
0005ae53  488d45ef                 lea rax, [rbp - 0x11]
0005ae57  4889442440               mov qword ptr [rsp + 0x40], rax
0005ae5c  488d4593                 lea rax, [rbp - 0x6d]
0005ae60  4889442438               mov qword ptr [rsp + 0x38], rax
0005ae65  488d459f                 lea rax, [rbp - 0x61]
0005ae69  4889442430               mov qword ptr [rsp + 0x30], rax
0005ae6e  488d45d7                 lea rax, [rbp - 0x29]
0005ae72  4889442428               mov qword ptr [rsp + 0x28], rax
0005ae77  488d45a7                 lea rax, [rbp - 0x59]
0005ae7b  4889442420               mov qword ptr [rsp + 0x20], rax
0005ae80  895da7                   mov dword ptr [rbp - 0x59], ebx
0005ae83  e85865ffff               call 0x513e0
0005ae88  448bc8                   mov r9d, eax
0005ae8b  89459f                   mov dword ptr [rbp - 0x61], eax
0005ae8e  8b45ff                   mov eax, dword ptr [rbp - 1]
0005ae91  83f802                   cmp eax, 2
0005ae94  0f85cf090000             jne 0x5b869
0005ae9a  8b45a7                   mov eax, dword ptr [rbp - 0x59]
0005ae9d  0fb7d8                   movzx ebx, ax
0005aea0  48c1e810                 shr rax, 0x10
0005aea4  48c1e320                 shl rbx, 0x20
0005aea8  480bd8                   or rbx, rax
0005aeab  8b45d7                   mov eax, dword ptr [rbp - 0x29]
0005aeae  0fb7f8                   movzx edi, ax
0005aeb1  48c1e720                 shl rdi, 0x20
0005aeb5  48c1e810                 shr rax, 0x10
0005aeb9  480bf8                   or rdi, rax
0005aebc  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005aec0  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005aec4  4585c9                   test r9d, r9d
0005aec7  0f84a2000000             je 0x5af6f
0005aecd  448d5601                 lea r10d, [rsi + 1]
0005aed1  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005aed5  4139742408               cmp dword ptr [r12 + 8], esi
0005aeda  7472                     je 0x5af4e
0005aedc  41397708                 cmp dword ptr [r15 + 8], esi
0005aee0  746c                     je 0x5af4e
0005aee2  498b0424                 mov rax, qword ptr [r12]
0005aee6  498b5508                 mov rdx, qword ptr [r13 + 8]
0005aeea  0fb708                   movzx ecx, word ptr [rax]
0005aeed  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005aef0  0fb7d8                   movzx ebx, ax
0005aef3  48c1e810                 shr rax, 0x10
0005aef7  48c1e320                 shl rbx, 0x20
0005aefb  480bd8                   or rbx, rax
0005aefe  498b07                   mov rax, qword ptr [r15]
0005af01  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005af05  0fb708                   movzx ecx, word ptr [rax]
0005af08  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005af0b  0fb7f8                   movzx edi, ax
0005af0e  48c1e720                 shl rdi, 0x20
0005af12  48c1e810                 shr rax, 0x10
0005af16  480bf8                   or rdi, rax
0005af19  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005af1d  eb2f                     jmp 0x5af4e
0005af1f  488bc7                   mov rax, rdi
0005af22  48c1e820                 shr rax, 0x20
0005af26  0fb6c8                   movzx ecx, al
0005af29  400fb6c7                 movzx eax, dil
0005af2d  48c1e108                 shl rcx, 8
0005af31  488bf9                   mov rdi, rcx
0005af34  480bf8                   or rdi, rax
0005af37  48c1e710                 shl rdi, 0x10
0005af3b  490bf8                   or rdi, r8
0005af3e  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005af42  488bf7                   mov rsi, rdi
0005af45  4585c9                   test r9d, r9d
0005af48  7429                     je 0x5af73
0005af4a  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005af4e  418b442408               mov eax, dword ptr [r12 + 8]
0005af53  85c0                     test eax, eax
0005af55  740b                     je 0x5af62
0005af57  41837f0800               cmp dword ptr [r15 + 8], 0
0005af5c  0f8570f1ffff             jne 0x5a0d2
0005af62  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005af66  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
0005af6a  e9aff0ffff               jmp 0x5a01e
0005af6f  4c8b5dcf                 mov r11, qword ptr [rbp - 0x31]
0005af73  33c0                     xor eax, eax
0005af75  4180fb03                 cmp r11b, 3
0005af79  0f85f5010000             jne 0x5b174
0005af7f  4c8bc3                   mov r8, rbx
0005af82  894593                   mov dword ptr [rbp - 0x6d], eax
0005af85  49c1e820                 shr r8, 0x20
0005af89  4180f801                 cmp r8b, 1
0005af8d  0f87cc000000             ja 0x5b05f
0005af93  498bd6                   mov rdx, r14
0005af96  48c1ea28                 shr rdx, 0x28
0005af9a  413ad3                   cmp dl, r11b
0005af9d  772e                     ja 0x5afcd
0005af9f  440fb64d95               movzx r9d, byte ptr [rbp - 0x6b]
0005afa4  48b900000000ffff0000     movabs rcx, 0xffff00000000
0005afae  0fb65596                 movzx edx, byte ptr [rbp - 0x6a]
0005afb2  488bd9                   mov rbx, rcx
0005afb5  48894daf                 mov qword ptr [rbp - 0x51], rcx
0005afb9  440fb6d0                 movzx r10d, al
0005afbd  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
0005afc1  44884d9c                 mov byte ptr [rbp - 0x64], r9b
0005afc5  88459b                   mov byte ptr [rbp - 0x65], al
0005afc8  e9e7000000               jmp 0x5b0b4
0005afcd  498bce                   mov rcx, r14
0005afd0  48c1e910                 shr rcx, 0x10
0005afd4  8bc9                     mov ecx, ecx
0005afd6  80fa22                   cmp dl, 0x22
0005afd9  755e                     jne 0x5b039
0005afdb  498bd6                   mov rdx, r14
0005afde  48c1ea08                 shr rdx, 8
0005afe2  440fb6d2                 movzx r10d, dl
0005afe6  440fb6ca                 movzx r9d, dl
0005afea  4180e2c6                 and r10b, 0xc6
0005afee  4180e1e4                 and r9b, 0xe4
0005aff2  4488559b                 mov byte ptr [rbp - 0x65], r10b
0005aff6  44884d9c                 mov byte ptr [rbp - 0x64], r9b
0005affa  4584c0                   test r8b, r8b
0005affd  7517                     jne 0x5b016
0005afff  48c1e110                 shl rcx, 0x10
0005b003  0fb7c3                   movzx eax, bx
0005b006  488bd9                   mov rbx, rcx
0005b009  480bd8                   or rbx, rax
0005b00c  b104                     mov cl, 4
0005b00e  80e2c5                   and dl, 0xc5
0005b011  e98c000000               jmp 0x5b0a2
0005b016  b8000087ff               mov eax, 0xff870000
0005b01b  4823c8                   and rcx, rax
0005b01e  0fb7c3                   movzx eax, bx
0005b021  48c1e110                 shl rcx, 0x10
0005b025  488bd9                   mov rbx, rcx
0005b028  b105                     mov cl, 5
0005b02a  480bd8                   or rbx, rax
0005b02d  488bd3                   mov rdx, rbx
0005b030  48c1ea08                 shr rdx, 8
0005b034  80e2c5                   and dl, 0xc5
0005b037  eb69                     jmp 0x5b0a2
0005b039  0fb65596                 movzx edx, byte ptr [rbp - 0x6a]
0005b03d  440fb64d95               movzx r9d, byte ptr [rbp - 0x6b]
0005b042  440fb65593               movzx r10d, byte ptr [rbp - 0x6d]
0005b047  48c1e110                 shl rcx, 0x10
0005b04b  0fb6c3                   movzx eax, bl
0005b04e  488bd9                   mov rbx, rcx
0005b051  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
0005b055  480bd8                   or rbx, rax
0005b058  480fbaeb09               bts rbx, 9
0005b05d  eb3b                     jmp 0x5b09a
0005b05f  48b8ffffffffff22ffff     movabs rax, 0xffff22ffffffffff
0005b069  b103                     mov cl, 3
0005b06b  4823d8                   and rbx, rax
0005b06e  48b80000000000220000     movabs rax, 0x220000000000
0005b078  480bd8                   or rbx, rax
0005b07b  488bc3                   mov rax, rbx
0005b07e  4c8bf3                   mov r14, rbx
0005b081  48c1e808                 shr rax, 8
0005b085  440fb6d0                 movzx r10d, al
0005b089  440fb6c8                 movzx r9d, al
0005b08d  4180e2c6                 and r10b, 0xc6
0005b091  4180e1e4                 and r9b, 0xe4
0005b095  24c5                     and al, 0xc5
0005b097  0fb6d0                   movzx edx, al
0005b09a  44884d9c                 mov byte ptr [rbp - 0x64], r9b
0005b09e  4488559b                 mov byte ptr [rbp - 0x65], r10b
0005b0a2  4881e3ff02ffff           and rbx, 0xffffffffffff02ff
0005b0a9  480fbaeb09               bts rbx, 9
0005b0ae  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005b0b2  33c0                     xor eax, eax
0005b0b4  837d8f02                 cmp dword ptr [rbp - 0x71], 2
0005b0b8  884d77                   mov byte ptr [rbp + 0x77], cl
0005b0bb  488955e7                 mov qword ptr [rbp - 0x19], rdx
0005b0bf  0f8eaf000000             jle 0x5b174
0005b0c5  4180fd03                 cmp r13b, 3
0005b0c9  0f84af000000             je 0x5b17e
0005b0cf  4584d2                   test r10b, r10b
0005b0d2  7417                     je 0x5b0eb
0005b0d4  b803000000               mov eax, 3
0005b0d9  41bb02000000             mov r11d, 2
0005b0df  894597                   mov dword ptr [rbp - 0x69], eax
0005b0e2  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b0e6  e95ff2ffff               jmp 0x5a34a
0005b0eb  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b0ef  4183fb03                 cmp r11d, 3
0005b0f3  0f8e4cf2ffff             jle 0x5a345
0005b0f9  84c9                     test cl, cl
0005b0fb  7413                     je 0x5b110
0005b0fd  b803000000               mov eax, 3
0005b102  894597                   mov dword ptr [rbp - 0x69], eax
0005b105  448bd8                   mov r11d, eax
0005b108  89458f                   mov dword ptr [rbp - 0x71], eax
0005b10b  e93af2ffff               jmp 0x5a34a
0005b110  4183fb04                 cmp r11d, 4
0005b114  0f8e2bf2ffff             jle 0x5a345
0005b11a  837ddf00                 cmp dword ptr [rbp - 0x21], 0
0005b11e  0f8521f2ffff             jne 0x5a345
0005b124  b803000000               mov eax, 3
0005b129  4584c9                   test r9b, r9b
0005b12c  7412                     je 0x5b140
0005b12e  41bb04000000             mov r11d, 4
0005b134  894597                   mov dword ptr [rbp - 0x69], eax
0005b137  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b13b  e90af2ffff               jmp 0x5a34a
0005b140  41b901000000             mov r9d, 1
0005b146  4183fb05                 cmp r11d, 5
0005b14a  0f8e00f2ffff             jle 0x5a350
0005b150  837dcb00                 cmp dword ptr [rbp - 0x35], 0
0005b154  0f85f6f1ffff             jne 0x5a350
0005b15a  84d2                     test dl, dl
0005b15c  0f84eef1ffff             je 0x5a350
0005b162  41bb05000000             mov r11d, 5
0005b168  894597                   mov dword ptr [rbp - 0x69], eax
0005b16b  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b16f  e9dcf1ffff               jmp 0x5a350
0005b174  4180fd03                 cmp r13b, 3
0005b178  0f85c3f1ffff             jne 0x5a341
0005b17e  4c8bd7                   mov r10, rdi
0005b181  894593                   mov dword ptr [rbp - 0x6d], eax
0005b184  49c1ea20                 shr r10, 0x20
0005b188  4180fa01                 cmp r10b, 1
0005b18c  0f87c0000000             ja 0x5b252
0005b192  488bd6                   mov rdx, rsi
0005b195  48c1ea28                 shr rdx, 0x28
0005b199  80fa03                   cmp dl, 3
0005b19c  7728                     ja 0x5b1c6
0005b19e  440fb64596               movzx r8d, byte ptr [rbp - 0x6a]
0005b1a3  48b800000000ffff0000     movabs rax, 0xffff00000000
0005b1ad  440fb64d95               movzx r9d, byte ptr [rbp - 0x6b]
0005b1b2  488bf8                   mov rdi, rax
0005b1b5  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
0005b1b9  0fb65593                 movzx edx, byte ptr [rbp - 0x6d]
0005b1bd  488945a7                 mov qword ptr [rbp - 0x59], rax
0005b1c1  e9d6000000               jmp 0x5b29c
0005b1c6  488bce                   mov rcx, rsi
0005b1c9  48c1e910                 shr rcx, 0x10
0005b1cd  8bc9                     mov ecx, ecx
0005b1cf  80fa22                   cmp dl, 0x22
0005b1d2  7557                     jne 0x5b22b
0005b1d4  4c8bc6                   mov r8, rsi
0005b1d7  49c1e808                 shr r8, 8
0005b1db  410fb6d0                 movzx edx, r8b
0005b1df  450fb6c8                 movzx r9d, r8b
0005b1e3  80e2c6                   and dl, 0xc6
0005b1e6  4180e1e4                 and r9b, 0xe4
0005b1ea  4584d2                   test r10b, r10b
0005b1ed  7518                     jne 0x5b207
0005b1ef  48c1e110                 shl rcx, 0x10
0005b1f3  0fb7c7                   movzx eax, di
0005b1f6  488bf9                   mov rdi, rcx
0005b1f9  480bf8                   or rdi, rax
0005b1fc  b104                     mov cl, 4
0005b1fe  4180e0c5                 and r8b, 0xc5
0005b202  e985000000               jmp 0x5b28c
0005b207  b8000087ff               mov eax, 0xff870000
0005b20c  4823c8                   and rcx, rax
0005b20f  0fb7c7                   movzx eax, di
0005b212  48c1e110                 shl rcx, 0x10
0005b216  488bf9                   mov rdi, rcx
0005b219  b105                     mov cl, 5
0005b21b  480bf8                   or rdi, rax
0005b21e  4c8bc7                   mov r8, rdi
0005b221  49c1e808                 shr r8, 8
0005b225  4180e0c5                 and r8b, 0xc5
0005b229  eb61                     jmp 0x5b28c
0005b22b  440fb64596               movzx r8d, byte ptr [rbp - 0x6a]
0005b230  440fb64d95               movzx r9d, byte ptr [rbp - 0x6b]
0005b235  0fb65593                 movzx edx, byte ptr [rbp - 0x6d]
0005b239  48c1e110                 shl rcx, 0x10
0005b23d  400fb6c7                 movzx eax, dil
0005b241  488bf9                   mov rdi, rcx
0005b244  0fb64d94                 movzx ecx, byte ptr [rbp - 0x6c]
0005b248  480bf8                   or rdi, rax
0005b24b  480fbaef09               bts rdi, 9
0005b250  eb3a                     jmp 0x5b28c
0005b252  48b8ffffffffff22ffff     movabs rax, 0xffff22ffffffffff
0005b25c  b103                     mov cl, 3
0005b25e  4823f8                   and rdi, rax
0005b261  48b80000000000220000     movabs rax, 0x220000000000
0005b26b  480bf8                   or rdi, rax
0005b26e  488bc7                   mov rax, rdi
0005b271  488bf7                   mov rsi, rdi
0005b274  48c1e808                 shr rax, 8
0005b278  0fb6d0                   movzx edx, al
0005b27b  440fb6c8                 movzx r9d, al
0005b27f  80e2c6                   and dl, 0xc6
0005b282  4180e1e4                 and r9b, 0xe4
0005b286  24c5                     and al, 0xc5
0005b288  440fb6c0                 movzx r8d, al
0005b28c  4881e7ff02ffff           and rdi, 0xffffffffffff02ff
0005b293  480fbaef09               bts rdi, 9
0005b298  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005b29c  837d8f02                 cmp dword ptr [rbp - 0x71], 2
0005b2a0  0f8e9bf0ffff             jle 0x5a341
0005b2a6  4180fb03                 cmp r11b, 3
0005b2aa  0f84b9000000             je 0x5b369
0005b2b0  84d2                     test dl, dl
0005b2b2  741d                     je 0x5b2d1
0005b2b4  41b901000000             mov r9d, 1
0005b2ba  41bb02000000             mov r11d, 2
0005b2c0  44894d97                 mov dword ptr [rbp - 0x69], r9d
0005b2c4  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b2c8  418d4102                 lea eax, [r9 + 2]
0005b2cc  e97ff0ffff               jmp 0x5a350
0005b2d1  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b2d5  4183fb03                 cmp r11d, 3
0005b2d9  0f8e66f0ffff             jle 0x5a345
0005b2df  84c9                     test cl, cl
0005b2e1  741a                     je 0x5b2fd
0005b2e3  b803000000               mov eax, 3
0005b2e8  41b901000000             mov r9d, 1
0005b2ee  44894d97                 mov dword ptr [rbp - 0x69], r9d
0005b2f2  448bd8                   mov r11d, eax
0005b2f5  89458f                   mov dword ptr [rbp - 0x71], eax
0005b2f8  e953f0ffff               jmp 0x5a350
0005b2fd  4183fb04                 cmp r11d, 4
0005b301  0f8e3ef0ffff             jle 0x5a345
0005b307  4584c9                   test r9b, r9b
0005b30a  7423                     je 0x5b32f
0005b30c  837ddf00                 cmp dword ptr [rbp - 0x21], 0
0005b310  751d                     jne 0x5b32f
0005b312  41b901000000             mov r9d, 1
0005b318  41bb04000000             mov r11d, 4
0005b31e  44894d97                 mov dword ptr [rbp - 0x69], r9d
0005b322  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b326  418d4102                 lea eax, [r9 + 2]
0005b32a  e921f0ffff               jmp 0x5a350
0005b32f  41b901000000             mov r9d, 1
0005b335  418d4102                 lea eax, [r9 + 2]
0005b339  4183fb05                 cmp r11d, 5
0005b33d  0f8e0df0ffff             jle 0x5a350
0005b343  4584c0                   test r8b, r8b
0005b346  0f8404f0ffff             je 0x5a350
0005b34c  837dcb00                 cmp dword ptr [rbp - 0x35], 0
0005b350  0f85faefffff             jne 0x5a350
0005b356  41bb05000000             mov r11d, 5
0005b35c  44894d97                 mov dword ptr [rbp - 0x69], r9d
0005b360  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b364  e9e7efffff               jmp 0x5a350
0005b369  38559b                   cmp byte ptr [rbp - 0x65], dl
0005b36c  7425                     je 0x5b393
0005b36e  b803000000               mov eax, 3
0005b373  41b901000000             mov r9d, 1
0005b379  448bd0                   mov r10d, eax
0005b37c  41bb02000000             mov r11d, 2
0005b382  450f42d1                 cmovb r10d, r9d
0005b386  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b38a  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b38e  e9bdefffff               jmp 0x5a350
0005b393  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b397  4183fb03                 cmp r11d, 3
0005b39b  0f8ea4efffff             jle 0x5a345
0005b3a1  384d77                   cmp byte ptr [rbp + 0x77], cl
0005b3a4  7421                     je 0x5b3c7
0005b3a6  b803000000               mov eax, 3
0005b3ab  41b901000000             mov r9d, 1
0005b3b1  448bd0                   mov r10d, eax
0005b3b4  89458f                   mov dword ptr [rbp - 0x71], eax
0005b3b7  450f42d1                 cmovb r10d, r9d
0005b3bb  448bd8                   mov r11d, eax
0005b3be  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b3c2  e989efffff               jmp 0x5a350
0005b3c7  4183fb04                 cmp r11d, 4
0005b3cb  0f8e74efffff             jle 0x5a345
0005b3d1  0fb64d9c                 movzx ecx, byte ptr [rbp - 0x64]
0005b3d5  413ac9                   cmp cl, r9b
0005b3d8  742e                     je 0x5b408
0005b3da  837ddf00                 cmp dword ptr [rbp - 0x21], 0
0005b3de  7528                     jne 0x5b408
0005b3e0  413ac9                   cmp cl, r9b
0005b3e3  b803000000               mov eax, 3
0005b3e8  448bd0                   mov r10d, eax
0005b3eb  41b901000000             mov r9d, 1
0005b3f1  450f42d1                 cmovb r10d, r9d
0005b3f5  41bb04000000             mov r11d, 4
0005b3fb  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b3ff  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b403  e948efffff               jmp 0x5a350
0005b408  4183fb05                 cmp r11d, 5
0005b40c  0f8e33efffff             jle 0x5a345
0005b412  488b4de7                 mov rcx, qword ptr [rbp - 0x19]
0005b416  413ac8                   cmp cl, r8b
0005b419  0f8426efffff             je 0x5a345
0005b41f  837dcb00                 cmp dword ptr [rbp - 0x35], 0
0005b423  b803000000               mov eax, 3
0005b428  448d48fe                 lea r9d, [rax - 2]
0005b42c  0f851eefffff             jne 0x5a350
0005b432  413ac8                   cmp cl, r8b
0005b435  448bd0                   mov r10d, eax
0005b438  41bb05000000             mov r11d, 5
0005b43e  450f42d1                 cmovb r10d, r9d
0005b442  44895d8f                 mov dword ptr [rbp - 0x71], r11d
0005b446  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b44a  e901efffff               jmp 0x5a350
0005b44f  837df700                 cmp dword ptr [rbp - 9], 0
0005b453  7406                     je 0x5b45b
0005b455  4180fd14                 cmp r13b, 0x14
0005b459  765b                     jbe 0x5b4b6
0005b45b  4585db                   test r11d, r11d
0005b45e  7f07                     jg 0x5b467
0005b460  41837a1000               cmp dword ptr [r10 + 0x10], 0
0005b465  744f                     je 0x5b4b6
0005b467  4d8bc4                   mov r8, r12
0005b46a  498bd2                   mov rdx, r10
0005b46d  e8ee040000               call 0x5b960
0005b472  488b5567                 mov rdx, qword ptr [rbp + 0x67]
0005b476  4d8bc7                   mov r8, r15
0005b479  0fb6cb                   movzx ecx, bl
0005b47c  6603c1                   add ax, cx
0005b47f  66894593                 mov word ptr [rbp - 0x6d], ax
0005b483  e8d8040000               call 0x5b960
0005b488  400fb6cf                 movzx ecx, dil
0005b48c  6603c1                   add ax, cx
0005b48f  66394593                 cmp word ptr [rbp - 0x6d], ax
0005b493  741d                     je 0x5b4b2
0005b495  b801000000               mov eax, 1
0005b49a  41ba03000000             mov r10d, 3
0005b4a0  440f42d0                 cmovb r10d, eax
0005b4a4  33c0                     xor eax, eax
0005b4a6  448bd8                   mov r11d, eax
0005b4a9  89458f                   mov dword ptr [rbp - 0x71], eax
0005b4ac  44895597                 mov dword ptr [rbp - 0x69], r10d
0005b4b0  eb04                     jmp 0x5b4b6
0005b4b2  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b4b6  837dcb00                 cmp dword ptr [rbp - 0x35], 0
0005b4ba  7410                     je 0x5b4cc
0005b4bc  837d0300                 cmp dword ptr [rbp + 3], 0
0005b4c0  740a                     je 0x5b4cc
0005b4c2  4180fd14                 cmp r13b, 0x14
0005b4c6  0f8643efffff             jbe 0x5a40f
0005b4cc  4183fb01                 cmp r11d, 1
0005b4d0  0f8e39efffff             jle 0x5a40f
0005b4d6  0fb645bc                 movzx eax, byte ptr [rbp - 0x44]
0005b4da  4180fd14                 cmp r13b, 0x14
0005b4de  0fb64dbb                 movzx ecx, byte ptr [rbp - 0x45]
0005b4e2  488bd7                   mov rdx, rdi
0005b4e5  0f46c8                   cmovbe ecx, eax
0005b4e8  48c1ea08                 shr rdx, 8
0005b4ec  488bc3                   mov rax, rbx
0005b4ef  22d1                     and dl, cl
0005b4f1  48c1e808                 shr rax, 8
0005b4f5  22c1                     and al, cl
0005b4f7  3ac2                     cmp al, dl
0005b4f9  0f8410efffff             je 0x5a40f
0005b4ff  41ba01000000             mov r10d, 1
0005b505  41bd03000000             mov r13d, 3
0005b50b  450f42ea                 cmovb r13d, r10d
0005b50f  4489558f                 mov dword ptr [rbp - 0x71], r10d
0005b513  44896d97                 mov dword ptr [rbp - 0x69], r13d
0005b517  458bda                   mov r11d, r10d
0005b51a  e9f6eeffff               jmp 0x5a415
0005b51f  498b1424                 mov rdx, qword ptr [r12]
0005b523  498d4c240e               lea rcx, [r12 + 0xe]
0005b528  4533c9                   xor r9d, r9d
0005b52b  ffc8                     dec eax
0005b52d  458bf1                   mov r14d, r9d
0005b530  4189442408               mov dword ptr [r12 + 8], eax
0005b535  483bd1                   cmp rdx, rcx
0005b538  740a                     je 0x5b544
0005b53a  488d4202                 lea rax, [rdx + 2]
0005b53e  49890424                 mov qword ptr [r12], rax
0005b542  eb09                     jmp 0x5b54d
0005b544  4d890424                 mov qword ptr [r12], r8
0005b548  4d894c2410               mov qword ptr [r12 + 0x10], r9
0005b54d  4d8b4710                 mov r8, qword ptr [r15 + 0x10]
0005b551  418b4f08                 mov ecx, dword ptr [r15 + 8]
0005b555  4d85c0                   test r8, r8
0005b558  750f                     jne 0x5b569
0005b55a  49830702                 add qword ptr [r15], 2
0005b55e  4d8b07                   mov r8, qword ptr [r15]
0005b561  ffc9                     dec ecx
0005b563  41894f08                 mov dword ptr [r15 + 8], ecx
0005b567  eb22                     jmp 0x5b58b
0005b569  498b17                   mov rdx, qword ptr [r15]
0005b56c  498d470e                 lea rax, [r15 + 0xe]
0005b570  ffc9                     dec ecx
0005b572  498bf1                   mov rsi, r9
0005b575  41894f08                 mov dword ptr [r15 + 8], ecx
0005b579  483bd0                   cmp rdx, rax
0005b57c  7406                     je 0x5b584
0005b57e  4c8d4202                 lea r8, [rdx + 2]
0005b582  eb04                     jmp 0x5b588
0005b584  4d894f10                 mov qword ptr [r15 + 0x10], r9
0005b588  4d8907                   mov qword ptr [r15], r8
0005b58b  418b442408               mov eax, dword ptr [r12 + 8]
0005b590  85c0                     test eax, eax
0005b592  7446                     je 0x5b5da
0005b594  85c9                     test ecx, ecx
0005b596  7442                     je 0x5b5da
0005b598  498b0424                 mov rax, qword ptr [r12]
0005b59c  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005b5a0  0fb708                   movzx ecx, word ptr [rax]
0005b5a3  498b5508                 mov rdx, qword ptr [r13 + 8]
0005b5a7  8b048a                   mov eax, dword ptr [rdx + rcx*4]
0005b5aa  0fb7d8                   movzx ebx, ax
0005b5ad  48c1e810                 shr rax, 0x10
0005b5b1  48c1e320                 shl rbx, 0x20
0005b5b5  480bd8                   or rbx, rax
0005b5b8  410fb700                 movzx eax, word ptr [r8]
0005b5bc  48895daf                 mov qword ptr [rbp - 0x51], rbx
0005b5c0  8b0c82                   mov ecx, dword ptr [rdx + rax*4]
0005b5c3  0fb7f9                   movzx edi, cx
0005b5c6  48c1e720                 shl rdi, 0x20
0005b5ca  48c1e910                 shr rcx, 0x10
0005b5ce  480bf9                   or rdi, rcx
0005b5d1  48897da7                 mov qword ptr [rbp - 0x59], rdi
0005b5d5  e906ebffff               jmp 0x5a0e0
0005b5da  448b4d9f                 mov r9d, dword ptr [rbp - 0x61]
0005b5de  4c8b6d67                 mov r13, qword ptr [rbp + 0x67]
0005b5e2  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
0005b5e6  e933eaffff               jmp 0x5a01e
0005b5eb  b803000000               mov eax, 3
0005b5f0  410f42c1                 cmovb eax, r9d
0005b5f4  e970020000               jmp 0x5b869
0005b5f9  48c1ef10                 shr rdi, 0x10
0005b5fd  48c1eb10                 shr rbx, 0x10
0005b601  3bdf                     cmp ebx, edi
0005b603  410f42c1                 cmovb eax, r9d
0005b607  e95d020000               jmp 0x5b869
0005b60c  85c0                     test eax, eax
0005b60e  0f85e7000000             jne 0x5b6fb
0005b614  458b4708                 mov r8d, dword ptr [r15 + 8]
0005b618  4585c0                   test r8d, r8d
0005b61b  0f8434020000             je 0x5b855
0005b621  39456f                   cmp dword ptr [rbp + 0x6f], eax
0005b624  0f8dc0000000             jge 0x5b6ea
0005b62a  498b17                   mov rdx, qword ptr [r15]
0005b62d  b840db0000               mov eax, 0xdb40
0005b632  663902                   cmp word ptr [rdx], ax
0005b635  0f8579000000             jne 0x5b6b4
0005b63b  4d8d4f0e                 lea r9, [r15 + 0xe]
0005b63f  493bd1                   cmp rdx, r9
0005b642  7414                     je 0x5b658
0005b644  4183f801                 cmp r8d, 1
0005b648  7606                     jbe 0x5b650
0005b64a  0fb74a02                 movzx ecx, word ptr [rdx + 2]
0005b64e  eb04                     jmp 0x5b654
0005b650  0fb74d6f                 movzx ecx, word ptr [rbp + 0x6f]
0005b654  765e                     jbe 0x5b6b4
0005b656  eb0d                     jmp 0x5b665
0005b658  4183f801                 cmp r8d, 1
0005b65c  7656                     jbe 0x5b6b4
0005b65e  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005b662  0fb708                   movzx ecx, word ptr [rax]
0005b665  b800230000               mov eax, 0x2300
0005b66a  beef000000               mov esi, 0xef
0005b66f  03c1                     add eax, ecx
0005b671  663bc6                   cmp ax, si
0005b674  773e                     ja 0x5b6b4
0005b676  33f6                     xor esi, esi
0005b678  8bfe                     mov edi, esi
0005b67a  3975c3                   cmp dword ptr [rbp - 0x3d], esi
0005b67d  7517                     jne 0x5b696
0005b67f  80c102                   add cl, 2
0005b682  48b80000000000150000     movabs rax, 0x150000000000
0005b68c  0fb6f9                   movzx edi, cl
0005b68f  48c1e720                 shl rdi, 0x20
0005b693  480bf8                   or rdi, rax
0005b696  418d40ff                 lea eax, [r8 - 1]
0005b69a  41894708                 mov dword ptr [r15 + 8], eax
0005b69e  493bd1                   cmp rdx, r9
0005b6a1  7406                     je 0x5b6a9
0005b6a3  488d4202                 lea rax, [rdx + 2]
0005b6a7  eb08                     jmp 0x5b6b1
0005b6a9  498b4710                 mov rax, qword ptr [r15 + 0x10]
0005b6ad  49897710                 mov qword ptr [r15 + 0x10], rsi
0005b6b1  498907                   mov qword ptr [r15], rax
0005b6b4  48c1eb28                 shr rbx, 0x28
0005b6b8  80fb15                   cmp bl, 0x15
0005b6bb  7412                     je 0x5b6cf
0005b6bd  48c1ef28                 shr rdi, 0x28
0005b6c1  4080ff15                 cmp dil, 0x15
0005b6c5  7508                     jne 0x5b6cf
0005b6c7  418bc2                   mov eax, r10d
0005b6ca  e99a010000               jmp 0x5b869
0005b6cf  49837f1000               cmp qword ptr [r15 + 0x10], 0
0005b6d4  0f847b010000             je 0x5b855
0005b6da  8b4597                   mov eax, dword ptr [rbp - 0x69]
0005b6dd  4183fb08                 cmp r11d, 8
0005b6e1  410f44c2                 cmove eax, r10d
0005b6e5  e97f010000               jmp 0x5b869
0005b6ea  4585c9                   test r9d, r9d
0005b6ed  4d8be7                   mov r12, r15
0005b6f0  be01000000               mov esi, 1
0005b6f5  480f45df                 cmovne rbx, rdi
0005b6f9  eb05                     jmp 0x5b700
0005b6fb  be03000000               mov esi, 3
0005b700  458b442408               mov r8d, dword ptr [r12 + 8]
0005b705  4585c0                   test r8d, r8d
0005b708  0f8447010000             je 0x5b855
0005b70e  440fb7556f               movzx r10d, word ptr [rbp + 0x6f]
0005b713  498d7c240e               lea rdi, [r12 + 0xe]
0005b718  448b75c3                 mov r14d, dword ptr [rbp - 0x3d]
0005b71c  41bf00dd0000             mov r15d, 0xdd00
0005b722  4585c9                   test r9d, r9d
0005b725  458bc8                   mov r9d, r8d
0005b728  7408                     je 0x5b732
0005b72a  89559f                   mov dword ptr [rbp - 0x61], edx
0005b72d  e9af000000               jmp 0x5b7e1
0005b732  498b4508                 mov rax, qword ptr [r13 + 8]
0005b736  4d8b1c24                 mov r11, qword ptr [r12]
0005b73a  410fb713                 movzx edx, word ptr [r11]
0005b73e  8b0c90                   mov ecx, dword ptr [rax + rdx*4]
0005b741  b840db0000               mov eax, 0xdb40
0005b746  0fb7d9                   movzx ebx, cx
0005b749  48c1e320                 shl rbx, 0x20
0005b74d  48c1e910                 shr rcx, 0x10
0005b751  480bd9                   or rbx, rcx
0005b754  663bd0                   cmp dx, ax
0005b757  0f857e000000             jne 0x5b7db
0005b75d  4c3bdf                   cmp r11, rdi
0005b760  740d                     je 0x5b76f
0005b762  4183f801                 cmp r8d, 1
0005b766  7673                     jbe 0x5b7db
0005b768  450fb75302               movzx r10d, word ptr [r11 + 2]
0005b76d  eb0f                     jmp 0x5b77e
0005b76f  4183f801                 cmp r8d, 1
0005b773  7666                     jbe 0x5b7db
0005b775  498b442410               mov rax, qword ptr [r12 + 0x10]
0005b77a  440fb710                 movzx r10d, word ptr [rax]
0005b77e  33d2                     xor edx, edx
0005b780  458bc8                   mov r9d, r8d
0005b783  66453bd7                 cmp r10w, r15w
0005b787  7254                     jb 0x5b7dd
0005b789  b8efdd0000               mov eax, 0xddef
0005b78e  66443bd0                 cmp r10w, ax
0005b792  7749                     ja 0x5b7dd
0005b794  8bda                     mov ebx, edx
0005b796  4585f6                   test r14d, r14d
0005b799  7518                     jne 0x5b7b3
0005b79b  418d4202                 lea eax, [r10 + 2]
0005b79f  0fb6d8                   movzx ebx, al
0005b7a2  48b80000000000150000     movabs rax, 0x150000000000
0005b7ac  48c1e320                 shl rbx, 0x20
0005b7b0  480bd8                   or rbx, rax
0005b7b3  458d48ff                 lea r9d, [r8 - 1]
0005b7b7  45894c2408               mov dword ptr [r12 + 8], r9d
0005b7bc  4c3bdf                   cmp r11, rdi
0005b7bf  740a                     je 0x5b7cb
0005b7c1  498d4302                 lea rax, [r11 + 2]
0005b7c5  49890424                 mov qword ptr [r12], rax
0005b7c9  eb12                     jmp 0x5b7dd
0005b7cb  498b442410               mov rax, qword ptr [r12 + 0x10]
0005b7d0  49890424                 mov qword ptr [r12], rax
0005b7d4  4989542410               mov qword ptr [r12 + 0x10], rdx
0005b7d9  eb02                     jmp 0x5b7dd
0005b7db  33d2                     xor edx, edx
0005b7dd  448b5d8f                 mov r11d, dword ptr [rbp - 0x71]
0005b7e1  488bc3                   mov rax, rbx
0005b7e4  48c1e828                 shr rax, 0x28
0005b7e8  0fb6c8                   movzx ecx, al
0005b7eb  83f915                   cmp ecx, 0x15
0005b7ee  7728                     ja 0x5b818
0005b7f0  4c8d050948faff           lea r8, [rip - 0x5b7f7]
0005b7f7  410fb6840844b90500       movzx eax, byte ptr [r8 + rcx + 0x5b944]
0005b800  418b8c8030b90500         mov ecx, dword ptr [r8 + rax*4 + 0x5b930]
0005b808  4903c8                   add rcx, r8
0005b80b  ffe1                     jmp rcx
0005b80d  f6456f02                 test byte ptr [rbp + 0x6f], 2
0005b811  750f                     jne 0x5b822
0005b813  4585db                   test r11d, r11d
0005b816  7e0a                     jle 0x5b822
0005b818  8bc6                     mov eax, esi
0005b81a  eb4d                     jmp 0x5b869
0005b81c  f6456f04                 test byte ptr [rbp + 0x6f], 4
0005b820  74f6                     je 0x5b818
0005b822  498b0424                 mov rax, qword ptr [r12]
0005b826  458d41ff                 lea r8d, [r9 - 1]
0005b82a  483bc7                   cmp rax, rdi
0005b82d  7406                     je 0x5b835
0005b82f  4883c002                 add rax, 2
0005b833  eb0a                     jmp 0x5b83f
0005b835  498b442410               mov rax, qword ptr [r12 + 0x10]
0005b83a  4989542410               mov qword ptr [r12 + 0x10], rdx
0005b83f  49890424                 mov qword ptr [r12], rax
0005b843  4589442408               mov dword ptr [r12 + 8], r8d
0005b848  448b4d9f                 mov r9d, dword ptr [rbp - 0x61]
0005b84c  4585c0                   test r8d, r8d
0005b84f  0f85cdfeffff             jne 0x5b722
0005b855  448b6d97                 mov r13d, dword ptr [rbp - 0x69]
0005b859  b802000000               mov eax, 2
0005b85e  4183fb08                 cmp r11d, 8
0005b862  440f44e8                 cmove r13d, eax
0005b866  418bc5                   mov eax, r13d
0005b869  4881c4e8000000           add rsp, 0xe8
0005b870  415f                     pop r15
0005b872  415e                     pop r14
0005b874  415d                     pop r13
0005b876  415c                     pop r12
0005b878  5f                       pop rdi
0005b879  5e                       pop rsi
0005b87a  5b                       pop rbx
0005b87b  5d                       pop rbp
0005b87c  c3                       ret
0005b87d  0f1f00                   nop dword ptr [rax]
0005b880  7dab                     jge 0x5b82d
0005b882  0500c2a705               add eax, 0x5a7c200
0005b887  007dab                   add byte ptr [rbp - 0x55], bh
0005b88a  050080ab05               add eax, 0x5ab8000
0005b88f  0007                     add byte ptr [rdi], al
0005b891  aa                       stosb byte ptr [rdi], al
0005b892  05004cab05               add eax, 0x5ab4c00
0005b897  00d0                     add al, dl
0005b899  a905007dab               test eax, 0xab7d0005
0005b89e  05007dab05               add eax, 0x5ab7d00
0005b8a3  007dab                   add byte ptr [rbp - 0x55], bh
0005b8a6  05007dab05               add eax, 0x5ab7d00
0005b8ab  007dab                   add byte ptr [rbp - 0x55], bh
0005b8ae  05007dab05               add eax, 0x5ab7d00
0005b8b3  007dab                   add byte ptr [rbp - 0x55], bh
0005b8b6  05007dab05               add eax, 0x5ab7d00
0005b8bb  007dab                   add byte ptr [rbp - 0x55], bh
0005b8be  05007dab05               add eax, 0x5ab7d00
0005b8c3  007dab                   add byte ptr [rbp - 0x55], bh
0005b8c6  05007dab05               add eax, 0x5ab7d00
0005b8cb  007dab                   add byte ptr [rbp - 0x55], bh
0005b8ce  05007dab05               add eax, 0x5ab7d00
0005b8d3  00f4                     add ah, dh
0005b8d5  a805                     test al, 5
0005b8d7  0042af                   add byte ptr [rdx - 0x51], al
0005b8da  0500aaab05               add eax, 0x5abaa00
0005b8df  0042af                   add byte ptr [rdx - 0x51], al
0005b8e2  050045af05               add eax, 0x5af4500
0005b8e7  00fa                     add dl, bh
0005b8e9  ad                       lodsd eax, dword ptr [rsi]
0005b8ea  05001faf05               add eax, 0x5af1f00
0005b8ef  00c1                     add cl, al
0005b8f1  ac                       lodsb al, byte ptr [rsi]
0005b8f2  050042af05               add eax, 0x5af4200
0005b8f7  0042af                   add byte ptr [rdx - 0x51], al
0005b8fa  050042af05               add eax, 0x5af4200
0005b8ff  0042af                   add byte ptr [rdx - 0x51], al
0005b902  050042af05               add eax, 0x5af4200
0005b907  0042af                   add byte ptr [rdx - 0x51], al
0005b90a  050042af05               add eax, 0x5af4200
0005b90f  0042af                   add byte ptr [rdx - 0x51], al
0005b912  050042af05               add eax, 0x5af4200
0005b917  0042af                   add byte ptr [rdx - 0x51], al
0005b91a  050042af05               add eax, 0x5af4200
0005b91f  0042af                   add byte ptr [rdx - 0x51], al
0005b922  050042af05               add eax, 0x5af4200
0005b927  0042af                   add byte ptr [rdx - 0x51], al
0005b92a  05004eac05               add eax, 0x5ac4e00
0005b92f  0022                     add byte ptr [rdx], ah
0005b931  b805000db8               mov eax, 0xb80d0005
0005b936  050018b805               add eax, 0x5b81800
0005b93b  001cb8                   add byte ptr [rax + rdi*4], bl
0005b93e  050018b805               add eax, 0x5b81800
0005b943  0000                     add byte ptr [rax], al
0005b945  0102                     add dword ptr [rdx], eax
0005b947  0202                     add al, byte ptr [rdx]
0005b949  0203                     add al, byte ptr [rbx]
0005b94b  0303                     add eax, dword ptr [rbx]
0005b94d  0303                     add eax, dword ptr [rbx]
0005b94f  0303                     add eax, dword ptr [rbx]
0005b951  0404                     add al, 4
0005b953  0404                     add al, 4
0005b955  0404                     add al, 4
0005b957  0404                     add al, 4
