; `CTrustedMachine::CTrustedMachine'::`1'::dtor$5
; aetm_enclave.dll, primary RVA 0x5fb10, 42 bytes in 1 chunk(s)

; chunk at RVA 0x5fb10 (42 bytes)
0005fb10  4055                     push rbp
0005fb12  4883ec20                 sub rsp, 0x20
0005fb16  488bea                   mov rbp, rdx
0005fb19  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
0005fb1d  4c8d0d8c9ffaff           lea r9, [rip - 0x56074]
0005fb24  41b800200000             mov r8d, 0x2000
0005fb2a  ba30000000               mov edx, 0x30
0005fb2f  e8ecd3ffff               call 0x5cf20
0005fb34  4883c420                 add rsp, 0x20
0005fb38  5d                       pop rbp
0005fb39  c3                       ret
