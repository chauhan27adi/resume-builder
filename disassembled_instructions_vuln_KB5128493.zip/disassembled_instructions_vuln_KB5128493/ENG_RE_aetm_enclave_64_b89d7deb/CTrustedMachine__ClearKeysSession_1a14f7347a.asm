; CTrustedMachine::ClearKeysSession
; aetm_enclave.dll, primary RVA 0xb8a0, 734 bytes in 3 chunk(s)

; chunk at RVA 0xb8a0 (17 bytes)
0000b8a0  4889742420               mov qword ptr [rsp + 0x20], rsi
0000b8a5  57                       push rdi
0000b8a6  4156                     push r14
0000b8a8  4157                     push r15
0000b8aa  4c8d91d0da5600           lea r10, [rcx + 0x56dad0]

; chunk at RVA 0xb8b1 (405 bytes)
0000b8b1  48896c2430               mov qword ptr [rsp + 0x30], rbp
0000b8b6  4c8d89d05a5800           lea r9, [rcx + 0x585ad0]
0000b8bd  90                       nop
0000b8be  0fb681f8da5600           movzx eax, byte ptr [rcx + 0x56daf8]
0000b8c5  488bf2                   mov rsi, rdx
0000b8c8  488bf9                   mov rdi, rcx
0000b8cb  4d8bc2                   mov r8, r10
0000b8ce  4d3bd1                   cmp r10, r9
0000b8d1  7313                     jae 0xb8e6
0000b8d3  84c0                     test al, al
0000b8d5  750f                     jne 0xb8e6
0000b8d7  4983c030                 add r8, 0x30
0000b8db  90                       nop
0000b8dc  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000b8e1  4d3bc1                   cmp r8, r9
0000b8e4  72ed                     jb 0xb8d3
0000b8e6  48bdabaaaaaaaaaaaa2a     movabs rbp, 0x2aaaaaaaaaaaaaab
0000b8f0  48895c2428               mov qword ptr [rsp + 0x28], rbx
0000b8f5  49be00000000ffffffff     movabs r14, 0xffffffff00000000
0000b8ff  49bf0000000001000000     movabs r15, 0x100000000
0000b909  0f1f8000000000           nop dword ptr [rax]
0000b910  90                       nop
0000b911  410fb64128               movzx eax, byte ptr [r9 + 0x28]
0000b916  4d8bd8                   mov r11, r8
0000b919  4d3bc1                   cmp r8, r9
0000b91c  0f8401010000             je 0xba23
0000b922  493930                   cmp qword ptr [r8], rsi
0000b925  0f85c2000000             jne 0xb9ed
0000b92b  90                       nop
0000b92c  498bc8                   mov rcx, r8
0000b92f  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000b934  492bca                   sub rcx, r10
0000b937  90                       nop
0000b938  488bc5                   mov rax, rbp
0000b93b  48f7e9                   imul rcx
0000b93e  48c1fa03                 sar rdx, 3
0000b942  488bc2                   mov rax, rdx
0000b945  48c1e83f                 shr rax, 0x3f
0000b949  4803d0                   add rdx, rax
0000b94c  498b4020                 mov rax, qword ptr [r8 + 0x20]
0000b950  48c1e820                 shr rax, 0x20
0000b954  90                       nop
0000b955  4863ca                   movsxd rcx, edx
0000b958  48c1e120                 shl rcx, 0x20
0000b95c  480bc8                   or rcx, rax
0000b95f  488bc1                   mov rax, rcx
0000b962  48c1e820                 shr rax, 0x20
0000b966  8bd0                     mov edx, eax
0000b968  25ff070000               and eax, 0x7ff
0000b96d  8bd8                     mov ebx, eax
0000b96f  488d0440                 lea rax, [rax + rax*2]
0000b973  4803c0                   add rax, rax
0000b976  450fb644c229             movzx r8d, byte ptr [r10 + rax*8 + 0x29]
0000b97c  90                       nop
0000b97d  498b44c220               mov rax, qword ptr [r10 + rax*8 + 0x20]
0000b982  48c1e820                 shr rax, 0x20
0000b986  3bc1                     cmp eax, ecx
0000b988  755c                     jne 0xb9e6
0000b98a  4584c0                   test r8b, r8b
0000b98d  7457                     je 0xb9e6
0000b98f  81e2ff070000             and edx, 0x7ff
0000b995  90                       nop
0000b996  488d1452                 lea rdx, [rdx + rdx*2]
0000b99a  48c1e204                 shl rdx, 4
0000b99e  4903d2                   add rdx, r10
0000b9a1  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000b9a5  85c0                     test eax, eax
0000b9a7  753d                     jne 0xb9e6
0000b9a9  488bc8                   mov rcx, rax
0000b9ac  4923ce                   and rcx, r14
0000b9af  4903cf                   add rcx, r15
0000b9b2  f0480fb14a20             lock cmpxchg qword ptr [rdx + 0x20], rcx
0000b9b8  752c                     jne 0xb9e6
0000b9ba  c6422800                 mov byte ptr [rdx + 0x28], 0
0000b9be  c6422900                 mov byte ptr [rdx + 0x29], 0
0000b9c2  90                       nop
0000b9c3  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000b9c7  48c1e820                 shr rax, 0x20
0000b9cb  83f8ff                   cmp eax, -1
0000b9ce  7416                     je 0xb9e6
0000b9d0  49638200a00100           movsxd rax, dword ptr [r10 + 0x1a000]
0000b9d7  41899c8200800100         mov dword ptr [r10 + rax*4 + 0x18000], ebx
0000b9df  41ff8200a00100           inc dword ptr [r10 + 0x1a000]
0000b9e6  48ff0d6b9f4600           dec qword ptr [rip + 0x469f6b]
0000b9ed  4d3bd9                   cmp r11, r9
0000b9f0  4d8d4330                 lea r8, [r11 + 0x30]
0000b9f4  90                       nop
0000b9f5  4d0f43c3                 cmovae r8, r11
0000b9f9  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000b9fe  4d3bc1                   cmp r8, r9
0000ba01  0f8309ffffff             jae 0xb910
0000ba07  84c0                     test al, al
0000ba09  0f8501ffffff             jne 0xb910
0000ba0f  4983c030                 add r8, 0x30
0000ba13  90                       nop
0000ba14  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000ba19  4d3bc1                   cmp r8, r9
0000ba1c  72e9                     jb 0xba07
0000ba1e  e9edfeffff               jmp 0xb910
0000ba23  488b6c2430               mov rbp, qword ptr [rsp + 0x30]
0000ba28  4c8d8fc85a5100           lea r9, [rdi + 0x515ac8]
0000ba2f  4c8d87c85a5600           lea r8, [rdi + 0x565ac8]
0000ba36  90                       nop
0000ba37  0fb687e85a5100           movzx eax, byte ptr [rdi + 0x515ae8]
0000ba3e  498bc9                   mov rcx, r9
0000ba41  4d3bc8                   cmp r9, r8
0000ba44  7312                     jae 0xba58

; chunk at RVA 0xba46 (312 bytes)
0000ba46  84c0                     test al, al
0000ba48  750e                     jne 0xba58
0000ba4a  4883c128                 add rcx, 0x28
0000ba4e  90                       nop
0000ba4f  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000ba53  493bc8                   cmp rcx, r8
0000ba56  72ee                     jb 0xba46
0000ba58  48bf6766666666666666     movabs rdi, 0x6666666666666667
0000ba62  90                       nop
0000ba63  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000ba68  4c8bd1                   mov r10, rcx
0000ba6b  493bc8                   cmp rcx, r8
0000ba6e  0f84fa000000             je 0xbb6e
0000ba74  48397108                 cmp qword ptr [rcx + 8], rsi
0000ba78  0f85bc000000             jne 0xbb3a
0000ba7e  90                       nop
0000ba7f  488bd1                   mov rdx, rcx
0000ba82  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000ba86  492bd1                   sub rdx, r9
0000ba89  90                       nop
0000ba8a  488bc7                   mov rax, rdi
0000ba8d  48f7ea                   imul rdx
0000ba90  48c1fa04                 sar rdx, 4
0000ba94  488bc2                   mov rax, rdx
0000ba97  48c1e83f                 shr rax, 0x3f
0000ba9b  4803d0                   add rdx, rax
0000ba9e  488b4118                 mov rax, qword ptr [rcx + 0x18]
0000baa2  48c1e820                 shr rax, 0x20
0000baa6  90                       nop
0000baa7  4863ca                   movsxd rcx, edx
0000baaa  48c1e120                 shl rcx, 0x20
0000baae  480bc8                   or rcx, rax
0000bab1  488bc1                   mov rax, rcx
0000bab4  48c1e820                 shr rax, 0x20
0000bab8  8bd0                     mov edx, eax
0000baba  25ff1f0000               and eax, 0x1fff
0000babf  8bd8                     mov ebx, eax
0000bac1  488d0480                 lea rax, [rax + rax*4]
0000bac5  450fb65cc121             movzx r11d, byte ptr [r9 + rax*8 + 0x21]
0000bacb  90                       nop
0000bacc  498b44c118               mov rax, qword ptr [r9 + rax*8 + 0x18]
0000bad1  48c1e820                 shr rax, 0x20
0000bad5  3bc1                     cmp eax, ecx
0000bad7  755a                     jne 0xbb33
0000bad9  4584db                   test r11b, r11b
0000badc  7455                     je 0xbb33
0000bade  81e2ff1f0000             and edx, 0x1fff
0000bae4  90                       nop
0000bae5  488d0492                 lea rax, [rdx + rdx*4]
0000bae9  498d14c1                 lea rdx, [r9 + rax*8]
0000baed  498b44c118               mov rax, qword ptr [r9 + rax*8 + 0x18]
0000baf2  85c0                     test eax, eax
0000baf4  753d                     jne 0xbb33
0000baf6  488bc8                   mov rcx, rax
0000baf9  4923ce                   and rcx, r14
0000bafc  4903cf                   add rcx, r15
0000baff  f0480fb14a18             lock cmpxchg qword ptr [rdx + 0x18], rcx
0000bb05  752c                     jne 0xbb33
0000bb07  c6422000                 mov byte ptr [rdx + 0x20], 0
0000bb0b  c6422100                 mov byte ptr [rdx + 0x21], 0
0000bb0f  90                       nop
0000bb10  488b4218                 mov rax, qword ptr [rdx + 0x18]
0000bb14  48c1e820                 shr rax, 0x20
0000bb18  83f8ff                   cmp eax, -1
0000bb1b  7416                     je 0xbb33
0000bb1d  49638100800500           movsxd rax, dword ptr [r9 + 0x58000]
0000bb24  41899c8100000500         mov dword ptr [r9 + rax*4 + 0x50000], ebx
0000bb2c  41ff8100800500           inc dword ptr [r9 + 0x58000]
0000bb33  48ff0d169e4600           dec qword ptr [rip + 0x469e16]
0000bb3a  4d3bd0                   cmp r10, r8
0000bb3d  498d4a28                 lea rcx, [r10 + 0x28]
0000bb41  90                       nop
0000bb42  490f43ca                 cmovae rcx, r10
0000bb46  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000bb4a  493bc8                   cmp rcx, r8
0000bb4d  0f830fffffff             jae 0xba62
0000bb53  84c0                     test al, al
0000bb55  0f8507ffffff             jne 0xba62
0000bb5b  4883c128                 add rcx, 0x28
0000bb5f  90                       nop
0000bb60  0fb64120                 movzx eax, byte ptr [rcx + 0x20]
0000bb64  493bc8                   cmp rcx, r8
0000bb67  72ea                     jb 0xbb53
0000bb69  e9f4feffff               jmp 0xba62
0000bb6e  488b5c2428               mov rbx, qword ptr [rsp + 0x28]
0000bb73  488b742438               mov rsi, qword ptr [rsp + 0x38]
0000bb78  415f                     pop r15
0000bb7a  415e                     pop r14
0000bb7c  5f                       pop rdi
0000bb7d  c3                       ret
