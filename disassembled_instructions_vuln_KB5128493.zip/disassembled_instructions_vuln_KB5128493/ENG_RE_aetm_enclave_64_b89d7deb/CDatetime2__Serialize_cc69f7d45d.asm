; CDatetime2::Serialize
; aetm_enclave.dll, primary RVA 0x2eff0, 312 bytes in 1 chunk(s)

; chunk at RVA 0x2eff0 (312 bytes)
0002eff0  48895c2418               mov qword ptr [rsp + 0x18], rbx
0002eff5  4889742420               mov qword ptr [rsp + 0x20], rsi
0002effa  57                       push rdi
0002effb  4883ec40                 sub rsp, 0x40
0002efff  33c0                     xor eax, eax
0002f001  c702032a0000             mov dword ptr [rdx], 0x2a03
0002f007  894218                   mov dword ptr [rdx + 0x18], eax
0002f00a  4c8d05ef0ffdff           lea r8, [rip - 0x2f011]
0002f011  48894208                 mov qword ptr [rdx + 8], rax
0002f015  488bf2                   mov rsi, rdx
0002f018  48894210                 mov qword ptr [rdx + 0x10], rax
0002f01c  8b4108                   mov eax, dword ptr [rcx + 8]
0002f01f  488b5110                 mov rdx, qword ptr [rcx + 0x10]
0002f023  89442430                 mov dword ptr [rsp + 0x30], eax
0002f027  0fb64118                 movzx eax, byte ptr [rcx + 0x18]
0002f02b  4889542420               mov qword ptr [rsp + 0x20], rdx
0002f030  410fb6bc8040420600       movzx edi, byte ptr [r8 + rax*4 + 0x64240]
0002f039  8d4703                   lea eax, [rdi + 3]
0002f03c  88461b                   mov byte ptr [rsi + 0x1b], al
0002f03f  8d47fd                   lea eax, [rdi - 3]
0002f042  83f807                   cmp eax, 7
0002f045  0f8784000000             ja 0x2f0cf
0002f04b  4898                     cdqe
0002f04d  418b8c8008f10200         mov ecx, dword ptr [r8 + rax*4 + 0x2f108]
0002f055  4903c8                   add rcx, r8
0002f058  ffe1                     jmp rcx
0002f05a  0fb6442422               movzx eax, byte ptr [rsp + 0x22]
0002f05f  66895608                 mov word ptr [rsi + 8], dx
0002f063  88460a                   mov byte ptr [rsi + 0xa], al
0002f066  eb78                     jmp 0x2f0e0
0002f068  895608                   mov dword ptr [rsi + 8], edx
0002f06b  eb73                     jmp 0x2f0e0
0002f06d  0fb6442424               movzx eax, byte ptr [rsp + 0x24]
0002f072  895608                   mov dword ptr [rsi + 8], edx
0002f075  88460c                   mov byte ptr [rsi + 0xc], al
0002f078  eb66                     jmp 0x2f0e0
0002f07a  0fb7442424               movzx eax, word ptr [rsp + 0x24]
0002f07f  895608                   mov dword ptr [rsi + 8], edx
0002f082  6689460c                 mov word ptr [rsi + 0xc], ax
0002f086  eb58                     jmp 0x2f0e0
0002f088  0fb7442424               movzx eax, word ptr [rsp + 0x24]
0002f08d  895608                   mov dword ptr [rsi + 8], edx
0002f090  6689460c                 mov word ptr [rsi + 0xc], ax
0002f094  0fb6442426               movzx eax, byte ptr [rsp + 0x26]
0002f099  88460e                   mov byte ptr [rsi + 0xe], al
0002f09c  eb42                     jmp 0x2f0e0
0002f09e  48895608                 mov qword ptr [rsi + 8], rdx
0002f0a2  eb3c                     jmp 0x2f0e0
0002f0a4  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
0002f0aa  0fb6442428               movzx eax, byte ptr [rsp + 0x28]
0002f0af  f20f114608               movsd qword ptr [rsi + 8], xmm0
0002f0b4  884610                   mov byte ptr [rsi + 0x10], al
0002f0b7  eb27                     jmp 0x2f0e0
0002f0b9  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
0002f0bf  0fb7442428               movzx eax, word ptr [rsp + 0x28]
0002f0c4  f20f114608               movsd qword ptr [rsi + 8], xmm0
0002f0c9  66894610                 mov word ptr [rsi + 0x10], ax
0002f0cd  eb11                     jmp 0x2f0e0
0002f0cf  4c8bc7                   mov r8, rdi
0002f0d2  488d542420               lea rdx, [rsp + 0x20]
0002f0d7  488d4e08                 lea rcx, [rsi + 8]
0002f0db  e8d3f10200               call 0x5e2b3
0002f0e0  0fb7442430               movzx eax, word ptr [rsp + 0x30]
0002f0e5  488b5c2460               mov rbx, qword ptr [rsp + 0x60]
0002f0ea  6689443708               mov word ptr [rdi + rsi + 8], ax
0002f0ef  0fb6442432               movzx eax, byte ptr [rsp + 0x32]
0002f0f4  8844370a                 mov byte ptr [rdi + rsi + 0xa], al
0002f0f8  c60600                   mov byte ptr [rsi], 0
0002f0fb  488b742468               mov rsi, qword ptr [rsp + 0x68]
0002f100  4883c440                 add rsp, 0x40
0002f104  5f                       pop rdi
0002f105  c3                       ret
0002f106  6690                     nop
0002f108  5a                       pop rdx
0002f109  f00200                   lock add al, byte ptr [rax]
0002f10c  68f002006d               push 0x6d0002f0
0002f111  f00200                   lock add al, byte ptr [rax]
0002f114  7af0                     jp 0x2f106
0002f116  0200                     add al, byte ptr [rax]
0002f118  88f0                     mov al, dh
0002f11a  0200                     add al, byte ptr [rax]
0002f11c  9e                       sahf
0002f11d  f00200                   lock add al, byte ptr [rax]
0002f120  a4                       movsb byte ptr [rdi], byte ptr [rsi]
0002f121  f00200                   lock add al, byte ptr [rax]
