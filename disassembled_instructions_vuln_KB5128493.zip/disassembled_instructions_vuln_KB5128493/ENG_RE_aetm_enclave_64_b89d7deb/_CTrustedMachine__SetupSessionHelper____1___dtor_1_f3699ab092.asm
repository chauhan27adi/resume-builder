; `CTrustedMachine::SetupSessionHelper'::`1'::dtor$1
; aetm_enclave.dll, primary RVA 0x60350, 34 bytes in 1 chunk(s)

; chunk at RVA 0x60350 (34 bytes)
00060350  4055                     push rbp
00060352  4883ec20                 sub rsp, 0x20
00060356  488bea                   mov rbp, rdx
00060359  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
00060360  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
00060367  e81496fbff               call 0x19980
0006036c  4883c420                 add rsp, 0x20
00060370  5d                       pop rbp
00060371  c3                       ret
