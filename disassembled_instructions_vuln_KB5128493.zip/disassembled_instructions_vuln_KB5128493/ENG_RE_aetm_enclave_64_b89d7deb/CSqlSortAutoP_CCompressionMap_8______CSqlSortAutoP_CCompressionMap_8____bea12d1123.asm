; CSqlSortAutoP<CCompressionMap<8> >::~CSqlSortAutoP<CCompressionMap<8> >
; aetm_enclave.dll, primary RVA 0x427a0, 136 bytes in 5 chunk(s)

; chunk at RVA 0x427a0 (30 bytes)
000427a0  4889742418               mov qword ptr [rsp + 0x18], rsi
000427a5  4156                     push r14
000427a7  4883ec20                 sub rsp, 0x20
000427ab  488b31                   mov rsi, qword ptr [rcx]
000427ae  4c8bf1                   mov r14, rcx
000427b1  4885f6                   test rsi, rsi
000427b4  7466                     je 0x4281c
000427b6  488b06                   mov rax, qword ptr [rsi]
000427b9  4885c0                   test rax, rax
000427bc  7456                     je 0x42814

; chunk at RVA 0x427be (12 bytes)
000427be  48897c2438               mov qword ptr [rsp + 0x38], rdi
000427c3  33ff                     xor edi, edi
000427c5  397e08                   cmp dword ptr [rsi + 8], edi
000427c8  763d                     jbe 0x42807

; chunk at RVA 0x427ca (61 bytes)
000427ca  48895c2430               mov qword ptr [rsp + 0x30], rbx
000427cf  90                       nop
000427d0  8bcf                     mov ecx, edi
000427d2  488bd0                   mov rdx, rax
000427d5  48c1e105                 shl rcx, 5
000427d9  488b0c01                 mov rcx, qword ptr [rcx + rax]
000427dd  4885c9                   test rcx, rcx
000427e0  7416                     je 0x427f8
000427e2  488b19                   mov rbx, qword ptr [rcx]
000427e5  e852b80100               call 0x5e03c
000427ea  488bcb                   mov rcx, rbx
000427ed  4885db                   test rbx, rbx
000427f0  75f0                     jne 0x427e2
000427f2  488b06                   mov rax, qword ptr [rsi]
000427f5  488bd0                   mov rdx, rax
000427f8  ffc7                     inc edi
000427fa  3b7e08                   cmp edi, dword ptr [rsi + 8]
000427fd  72d1                     jb 0x427d0
000427ff  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00042804  488bc2                   mov rax, rdx

; chunk at RVA 0x42807 (13 bytes)
00042807  488bc8                   mov rcx, rax
0004280a  e82db80100               call 0x5e03c
0004280f  488b7c2438               mov rdi, qword ptr [rsp + 0x38]

; chunk at RVA 0x42814 (20 bytes)
00042814  498b0e                   mov rcx, qword ptr [r14]
00042817  e820b80100               call 0x5e03c
0004281c  488b742440               mov rsi, qword ptr [rsp + 0x40]
00042821  4883c420                 add rsp, 0x20
00042825  415e                     pop r14
00042827  c3                       ret
