; `CTrustedMachine::InitTrustedMachine'::`1'::dtor$2
; aetm_enclave.dll, primary RVA 0x5fcd0, 32 bytes in 1 chunk(s)

; chunk at RVA 0x5fcd0 (32 bytes)
0005fcd0  4055                     push rbp
0005fcd2  4883ec20                 sub rsp, 0x20
0005fcd6  488bea                   mov rbp, rdx
0005fcd9  ba58000000               mov edx, 0x58
0005fcde  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
0005fce5  e806d3ffff               call 0x5cff0
0005fcea  4883c420                 add rsp, 0x20
0005fcee  5d                       pop rbp
0005fcef  c3                       ret
