; CTrustedMachine::GetPrimaryDBFromReplicaDB
; aetm_enclave.dll, primary RVA 0xd350, 543 bytes in 1 chunk(s)

; chunk at RVA 0xd350 (543 bytes)
0000d350  4055                     push rbp
0000d352  56                       push rsi
0000d353  57                       push rdi
0000d354  4883ec40                 sub rsp, 0x40
0000d358  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0000d361  48895c2468               mov qword ptr [rsp + 0x68], rbx
0000d366  8bfa                     mov edi, edx
0000d368  488d99d87a5800           lea rbx, [rcx + 0x587ad8]
0000d36f  488bcb                   mov rcx, rbx
0000d372  4c8d8b00300000           lea r9, [rbx + 0x3000]
0000d379  33f6                     xor esi, esi
0000d37b  493bd9                   cmp rbx, r9
0000d37e  7332                     jae 0xd3b2
0000d380  4889742460               mov qword ptr [rsp + 0x60], rsi
0000d385  48894c2460               mov qword ptr [rsp + 0x60], rcx
0000d38a  f048ff4108               lock inc qword ptr [rcx + 8]
0000d38f  90                       nop
0000d390  0fb64110                 movzx eax, byte ptr [rcx + 0x10]
0000d394  84c0                     test al, al
0000d396  7515                     jne 0xd3ad
0000d398  4883c118                 add rcx, 0x18
0000d39c  488b442460               mov rax, qword ptr [rsp + 0x60]
0000d3a1  f048ff4808               lock dec qword ptr [rax + 8]
0000d3a6  493bc9                   cmp rcx, r9
0000d3a9  72d5                     jb 0xd380
0000d3ab  eb05                     jmp 0xd3b2
0000d3ad  f048ff4908               lock dec qword ptr [rcx + 8]
0000d3b2  48bdabaaaaaaaaaaaa2a     movabs rbp, 0x2aaaaaaaaaaaaaab
0000d3bc  0f1f4000                 nop dword ptr [rax]
0000d3c0  493bc9                   cmp rcx, r9
0000d3c3  0f847f010000             je 0xd548
0000d3c9  48895c2428               mov qword ptr [rsp + 0x28], rbx
0000d3ce  4889742470               mov qword ptr [rsp + 0x70], rsi
0000d3d3  48894c2470               mov qword ptr [rsp + 0x70], rcx
0000d3d8  f048ff4108               lock inc qword ptr [rcx + 8]
0000d3dd  90                       nop
0000d3de  0fb64110                 movzx eax, byte ptr [rcx + 0x10]
0000d3e2  488bd1                   mov rdx, rcx
0000d3e5  482bd3                   sub rdx, rbx
0000d3e8  488bc5                   mov rax, rbp
0000d3eb  48f7ea                   imul rdx
0000d3ee  48c1fa02                 sar rdx, 2
0000d3f2  488bc2                   mov rax, rdx
0000d3f5  48c1e83f                 shr rax, 0x3f
0000d3f9  4803d0                   add rdx, rax
0000d3fc  90                       nop
0000d3fd  488b4108                 mov rax, qword ptr [rcx + 8]
0000d401  4c63c2                   movsxd r8, edx
0000d404  49c1e020                 shl r8, 0x20
0000d408  48c1e820                 shr rax, 0x20
0000d40c  4c0bc0                   or r8, rax
0000d40f  f048ff4908               lock dec qword ptr [rcx + 8]
0000d414  4c89442430               mov qword ptr [rsp + 0x30], r8
0000d419  0faee8                   lfence
0000d41c  49c1e820                 shr r8, 0x20
0000d420  4181e0ff010000           and r8d, 0x1ff
0000d427  4b8d1440                 lea rdx, [r8 + r8*2]
0000d42b  488b442428               mov rax, qword ptr [rsp + 0x28]
0000d430  f048ff44d008             lock inc qword ptr [rax + rdx*8 + 8]
0000d436  4c8b5c2430               mov r11, qword ptr [rsp + 0x30]
0000d43b  4d8bc3                   mov r8, r11
0000d43e  49c1e820                 shr r8, 0x20
0000d442  498bc0                   mov rax, r8
0000d445  25ff010000               and eax, 0x1ff
0000d44a  488d1440                 lea rdx, [rax + rax*2]
0000d44e  488b442428               mov rax, qword ptr [rsp + 0x28]
0000d453  4c8d14d0                 lea r10, [rax + rdx*8]
0000d457  90                       nop
0000d458  410fb65210               movzx edx, byte ptr [r10 + 0x10]
0000d45d  90                       nop
0000d45e  498b4208                 mov rax, qword ptr [r10 + 8]
0000d462  48c1e820                 shr rax, 0x20
0000d466  413bc3                   cmp eax, r11d
0000d469  7543                     jne 0xd4ae
0000d46b  84d2                     test dl, dl
0000d46d  743f                     je 0xd4ae
0000d46f  90                       nop
0000d470  410fb65211               movzx edx, byte ptr [r10 + 0x11]
0000d475  90                       nop
0000d476  498b4208                 mov rax, qword ptr [r10 + 8]
0000d47a  48c1e820                 shr rax, 0x20
0000d47e  413bc3                   cmp eax, r11d
0000d481  0f85d0000000             jne 0xd557
0000d487  84d2                     test dl, dl
0000d489  0f84c8000000             je 0xd557
0000d48f  4181e0ff010000           and r8d, 0x1ff
0000d496  4b8d1440                 lea rdx, [r8 + r8*2]
0000d49a  488b442428               mov rax, qword ptr [rsp + 0x28]
0000d49f  4c8d04d0                 lea r8, [rax + rdx*8]
0000d4a3  41397804                 cmp dword ptr [r8 + 4], edi
0000d4a7  746e                     je 0xd517
0000d4a9  0faee8                   lfence
0000d4ac  eb17                     jmp 0xd4c5
0000d4ae  0faee8                   lfence
0000d4b1  4181e0ff010000           and r8d, 0x1ff
0000d4b8  4b8d1440                 lea rdx, [r8 + r8*2]
0000d4bc  488b442428               mov rax, qword ptr [rsp + 0x28]
0000d4c1  4c8d04d0                 lea r8, [rax + rdx*8]
0000d4c5  f049ff4808               lock dec qword ptr [r8 + 8]
0000d4ca  493bc9                   cmp rcx, r9
0000d4cd  0f83f0feffff             jae 0xd3c3
0000d4d3  4883c118                 add rcx, 0x18
0000d4d7  493bc9                   cmp rcx, r9
0000d4da  0f83e3feffff             jae 0xd3c3
0000d4e0  4889742478               mov qword ptr [rsp + 0x78], rsi
0000d4e5  48894c2478               mov qword ptr [rsp + 0x78], rcx
0000d4ea  488d5108                 lea rdx, [rcx + 8]
0000d4ee  f048ff02                 lock inc qword ptr [rdx]
0000d4f2  90                       nop
0000d4f3  0fb64110                 movzx eax, byte ptr [rcx + 0x10]
0000d4f7  84c0                     test al, al
0000d4f9  7512                     jne 0xd50d
0000d4fb  4883c118                 add rcx, 0x18
0000d4ff  f048ff0a                 lock dec qword ptr [rdx]
0000d503  493bc9                   cmp rcx, r9
0000d506  72d8                     jb 0xd4e0
0000d508  e9b3feffff               jmp 0xd3c0
0000d50d  f048ff4908               lock dec qword ptr [rcx + 8]
0000d512  e9a9feffff               jmp 0xd3c0
0000d517  418b00                   mov eax, dword ptr [r8]
0000d51a  488b4c2430               mov rcx, qword ptr [rsp + 0x30]
0000d51f  48c1e920                 shr rcx, 0x20
0000d523  0faee8                   lfence
0000d526  81e1ff010000             and ecx, 0x1ff
0000d52c  488d1449                 lea rdx, [rcx + rcx*2]
0000d530  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
0000d535  f048ff4cd108             lock dec qword ptr [rcx + rdx*8 + 8]
0000d53b  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0000d540  4883c440                 add rsp, 0x40
0000d544  5f                       pop rdi
0000d545  5e                       pop rsi
0000d546  5d                       pop rbp
0000d547  c3                       ret
0000d548  33c0                     xor eax, eax
0000d54a  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0000d54f  4883c440                 add rsp, 0x40
0000d553  5f                       pop rdi
0000d554  5e                       pop rsi
0000d555  5d                       pop rbp
0000d556  c3                       ret
0000d557  ba5f000000               mov edx, 0x5f
0000d55c  448d4aa2                 lea r9d, [rdx - 0x5e]
0000d560  448d42b2                 lea r8d, [rdx - 0x4e]
0000d564  b94b010000               mov ecx, 0x14b
0000d569  e8d2be0000               call 0x19440
0000d56e  cc                       int3
