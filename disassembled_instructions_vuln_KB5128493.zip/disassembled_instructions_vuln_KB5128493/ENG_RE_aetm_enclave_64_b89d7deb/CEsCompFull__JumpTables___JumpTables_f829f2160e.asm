; CEsCompFull::JumpTables::~JumpTables
; aetm_enclave.dll, primary RVA 0x1efb0, 109 bytes in 5 chunk(s)

; chunk at RVA 0x1efb0 (17 bytes)
0001efb0  4053                     push rbx
0001efb2  4883ec20                 sub rsp, 0x20
0001efb6  488bd9                   mov rbx, rcx
0001efb9  488b09                   mov rcx, qword ptr [rcx]
0001efbc  4885c9                   test rcx, rcx
0001efbf  7456                     je 0x1f017

; chunk at RVA 0x1efc1 (13 bytes)
0001efc1  4889742430               mov qword ptr [rsp + 0x30], rsi
0001efc6  33f6                     xor esi, esi
0001efc8  40387308                 cmp byte ptr [rbx + 8], sil
0001efcc  7634                     jbe 0x1f002

; chunk at RVA 0x1efce (52 bytes)
0001efce  48897c2438               mov qword ptr [rsp + 0x38], rdi
0001efd3  33ff                     xor edi, edi
0001efd5  6666660f1f840000000000   nop word ptr [rax + rax]
0001efe0  488b0b                   mov rcx, qword ptr [rbx]
0001efe3  488b0c0f                 mov rcx, qword ptr [rdi + rcx]
0001efe7  e8f0de0300               call 0x5cedc
0001efec  0fb64308                 movzx eax, byte ptr [rbx + 8]
0001eff0  488d7f08                 lea rdi, [rdi + 8]
0001eff4  ffc6                     inc esi
0001eff6  3bf0                     cmp esi, eax
0001eff8  7ce6                     jl 0x1efe0
0001effa  488b0b                   mov rcx, qword ptr [rbx]
0001effd  488b7c2438               mov rdi, qword ptr [rsp + 0x38]

; chunk at RVA 0x1f002 (21 bytes)
0001f002  e8d5de0300               call 0x5cedc
0001f007  488b742430               mov rsi, qword ptr [rsp + 0x30]
0001f00c  48c70300000000           mov qword ptr [rbx], 0
0001f013  c6430800                 mov byte ptr [rbx + 8], 0

; chunk at RVA 0x1f017 (6 bytes)
0001f017  4883c420                 add rsp, 0x20
0001f01b  5b                       pop rbx
0001f01c  c3                       ret
