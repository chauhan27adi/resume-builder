; CSqlSortManager_100::GetNextSortID
; aetm_enclave.dll, primary RVA 0x53310, 4020 bytes in 1 chunk(s)

; chunk at RVA 0x53310 (4020 bytes)
00053310  48895c2408               mov qword ptr [rsp + 8], rbx
00053315  4889742410               mov qword ptr [rsp + 0x10], rsi
0005331a  48897c2418               mov qword ptr [rsp + 0x18], rdi
0005331f  55                       push rbp
00053320  4154                     push r12
00053322  4155                     push r13
00053324  4156                     push r14
00053326  4157                     push r15
00053328  488d6c24f0               lea rbp, [rsp - 0x10]
0005332d  4881ec10010000           sub rsp, 0x110
00053334  488b05cd7c0500           mov rax, qword ptr [rip + 0x57ccd]
0005333b  4833c4                   xor rax, rsp
0005333e  48894508                 mov qword ptr [rbp + 8], rax
00053342  4533e4                   xor r12d, r12d
00053345  44894d80                 mov dword ptr [rbp - 0x80], r9d
00053349  458b4810                 mov r9d, dword ptr [r8 + 0x10]
0005334d  498bf8                   mov rdi, r8
00053350  418bc1                   mov eax, r9d
00053353  4889542450               mov qword ptr [rsp + 0x50], rdx
00053358  d1e8                     shr eax, 1
0005335a  4c8bd2                   mov r10, rdx
0005335d  2401                     and al, 1
0005335f  41c1e91a                 shr r9d, 0x1a
00053363  4180e101                 and r9b, 1
00053367  894588                   mov dword ptr [rbp - 0x78], eax
0005336a  418b8088000000           mov eax, dword ptr [r8 + 0x88]
00053371  458bdc                   mov r11d, r12d
00053374  48894d90                 mov qword ptr [rbp - 0x70], rcx
00053378  4489642444               mov dword ptr [rsp + 0x44], r12d
0005337d  448964246c               mov dword ptr [rsp + 0x6c], r12d
00053382  4489642458               mov dword ptr [rsp + 0x58], r12d
00053387  44894c2460               mov dword ptr [rsp + 0x60], r9d
0005338c  c644244c01               mov byte ptr [rsp + 0x4c], 1
00053391  413b8084000000           cmp eax, dword ptr [r8 + 0x84]
00053398  0f850f0e0000             jne 0x541ad
0005339e  488b4578                 mov rax, qword ptr [rbp + 0x78]
000533a2  4885c0                   test rax, rax
000533a5  7403                     je 0x533aa
000533a7  448818                   mov byte ptr [rax], r11b
000533aa  0fb7442464               movzx eax, word ptr [rsp + 0x64]
000533af  4d8d703c                 lea r14, [r8 + 0x3c]
000533b3  8b5d70                   mov ebx, dword ptr [rbp + 0x70]
000533b6  668944245c               mov word ptr [rsp + 0x5c], ax
000533bb  eb13                     jmp 0x533d0
000533bd  0f1f00                   nop dword ptr [rax]
000533c0  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000533c5  4533e4                   xor r12d, r12d
000533c8  448b4c2460               mov r9d, dword ptr [rsp + 0x60]
000533cd  0f1f00                   nop dword ptr [rax]
000533d0  8b575c                   mov edx, dword ptr [rdi + 0x5c]
000533d3  418bf3                   mov esi, r11d
000533d6  83fa01                   cmp edx, 1
000533d9  7d5d                     jge 0x53438
000533db  488b4730                 mov rax, qword ptr [rdi + 0x30]
000533df  90                       nop
000533e0  4885c0                   test rax, rax
000533e3  7e44                     jle 0x53429
000533e5  488b4718                 mov rax, qword ptr [rdi + 0x18]
000533e9  4885c0                   test rax, rax
000533ec  740b                     je 0x533f9
000533ee  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000533f2  ffd0                     call rax
000533f4  0fb7c8                   movzx ecx, ax
000533f7  eb12                     jmp 0x5340b
000533f9  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000533fd  488b4728                 mov rax, qword ptr [rdi + 0x28]
00053401  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00053405  8d4201                   lea eax, [rdx + 1]
00053408  894738                   mov dword ptr [rdi + 0x38], eax
0005340b  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
0005340f  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00053414  8b575c                   mov edx, dword ptr [rdi + 0x5c]
00053417  48ff4f30                 dec qword ptr [rdi + 0x30]
0005341b  ffc2                     inc edx
0005341d  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053421  89575c                   mov dword ptr [rdi + 0x5c], edx
00053424  83fa01                   cmp edx, 1
00053427  7cb7                     jl 0x533e0
00053429  4c8b542450               mov r10, qword ptr [rsp + 0x50]
0005342e  448b4c2460               mov r9d, dword ptr [rsp + 0x60]
00053433  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
00053438  85d2                     test edx, edx
0005343a  0f84aa0d0000             je 0x541ea
00053440  8b8780000000             mov eax, dword ptr [rdi + 0x80]
00053446  398788000000             cmp dword ptr [rdi + 0x88], eax
0005344c  0f8d910d0000             jge 0x541e3
00053452  498b4208                 mov rax, qword ptr [r10 + 8]
00053456  41bd01000000             mov r13d, 1
0005345c  410fb70e                 movzx ecx, word ptr [r14]
00053460  4489642448               mov dword ptr [rsp + 0x48], r12d
00053465  4532e4                   xor r12b, r12b
00053468  448b3c88                 mov r15d, dword ptr [rax + rcx*4]
0005346c  418bc7                   mov eax, r15d
0005346f  44897c2440               mov dword ptr [rsp + 0x40], r15d
00053474  c1e818                   shr eax, 0x18
00053477  837f0400                 cmp dword ptr [rdi + 4], 0
0005347b  0f84a3000000             je 0x53524
00053481  663b4f0c                 cmp cx, word ptr [rdi + 0xc]
00053485  0f8599000000             jne 0x53524
0005348b  83fa02                   cmp edx, 2
0005348e  7d4d                     jge 0x534dd
00053490  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053494  4885c0                   test rax, rax
00053497  7e44                     jle 0x534dd
00053499  488b4718                 mov rax, qword ptr [rdi + 0x18]
0005349d  4885c0                   test rax, rax
000534a0  740b                     je 0x534ad
000534a2  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000534a6  ffd0                     call rax
000534a8  0fb7c8                   movzx ecx, ax
000534ab  eb12                     jmp 0x534bf
000534ad  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000534b1  488b4728                 mov rax, qword ptr [rdi + 0x28]
000534b5  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
000534b9  8d4201                   lea eax, [rdx + 1]
000534bc  894738                   mov dword ptr [rdi + 0x38], eax
000534bf  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
000534c3  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
000534c8  8b575c                   mov edx, dword ptr [rdi + 0x5c]
000534cb  48ff4f30                 dec qword ptr [rdi + 0x30]
000534cf  ffc2                     inc edx
000534d1  488b4730                 mov rax, qword ptr [rdi + 0x30]
000534d5  89575c                   mov dword ptr [rdi + 0x5c], edx
000534d8  83fa02                   cmp edx, 2
000534db  7cb7                     jl 0x53494
000534dd  413bd5                   cmp edx, r13d
000534e0  0f84f60c0000             je 0x541dc
000534e6  8d42ff                   lea eax, [rdx - 1]
000534e9  498bce                   mov rcx, r14
000534ec  4c63c0                   movsxd r8, eax
000534ef  488d573e                 lea rdx, [rdi + 0x3e]
000534f3  4d03c0                   add r8, r8
000534f6  e8c4ad0000               call 0x5e2bf
000534fb  ff4f5c                   dec dword ptr [rdi + 0x5c]
000534fe  4c8d05fbcafaff           lea r8, [rip - 0x53505]
00053505  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0005350a  410fb70e                 movzx ecx, word ptr [r14]
0005350e  8b542444                 mov edx, dword ptr [rsp + 0x44]
00053512  488b4308                 mov rax, qword ptr [rbx + 8]
00053516  448b3c88                 mov r15d, dword ptr [rax + rcx*4]
0005351a  44897c2440               mov dword ptr [rsp + 0x40], r15d
0005351f  e953040000               jmp 0x53977
00053524  32db                     xor bl, bl
00053526  41837a1400               cmp dword ptr [r10 + 0x14], 0
0005352b  0f8425010000             je 0x53656
00053531  8b4c2458                 mov ecx, dword ptr [rsp + 0x58]
00053535  a8c0                     test al, 0xc0
00053537  0f849a010000             je 0x536d7
0005353d  49837a3000               cmp qword ptr [r10 + 0x30], 0
00053542  0f848f010000             je 0x536d7
00053548  85c9                     test ecx, ecx
0005354a  0f8587010000             jne 0x536d7
00053550  4585db                   test r11d, r11d
00053553  0f857e010000             jne 0x536d7
00053559  83fa08                   cmp edx, 8
0005355c  7d52                     jge 0x535b0
0005355e  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053562  4885c0                   test rax, rax
00053565  7e44                     jle 0x535ab
00053567  488b4718                 mov rax, qword ptr [rdi + 0x18]
0005356b  4885c0                   test rax, rax
0005356e  740b                     je 0x5357b
00053570  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00053574  ffd0                     call rax
00053576  0fb7c8                   movzx ecx, ax
00053579  eb12                     jmp 0x5358d
0005357b  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
0005357f  488b4728                 mov rax, qword ptr [rdi + 0x28]
00053583  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00053587  8d4201                   lea eax, [rdx + 1]
0005358a  894738                   mov dword ptr [rdi + 0x38], eax
0005358d  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00053591  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00053596  8b575c                   mov edx, dword ptr [rdi + 0x5c]
00053599  48ff4f30                 dec qword ptr [rdi + 0x30]
0005359d  ffc2                     inc edx
0005359f  488b4730                 mov rax, qword ptr [rdi + 0x30]
000535a3  89575c                   mov dword ptr [rdi + 0x5c], edx
000535a6  83fa08                   cmp edx, 8
000535a9  7cb7                     jl 0x53562
000535ab  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000535b0  33c0                     xor eax, eax
000535b2  4c8975a8                 mov qword ptr [rbp - 0x58], r14
000535b6  488945b8                 mov qword ptr [rbp - 0x48], rax
000535ba  4c8d4d98                 lea r9, [rbp - 0x68]
000535be  0fbaf21f                 btr edx, 0x1f
000535c2  410fb7c7                 movzx eax, r15w
000535c6  48c1e020                 shl rax, 0x20
000535ca  498bcf                   mov rcx, r15
000535cd  48c1e910                 shr rcx, 0x10
000535d1  4d8bc2                   mov r8, r10
000535d4  480bc1                   or rax, rcx
000535d7  8955b0                   mov dword ptr [rbp - 0x50], edx
000535da  488d55a8                 lea rdx, [rbp - 0x58]
000535de  48894598                 mov qword ptr [rbp - 0x68], rax
000535e2  4c8975c0                 mov qword ptr [rbp - 0x40], r14
000535e6  e8e5280000               call 0x55ed0
000535eb  85c0                     test eax, eax
000535ed  7452                     je 0x53641
000535ef  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000535f2  498bce                   mov rcx, r14
000535f5  488b5da8                 mov rbx, qword ptr [rbp - 0x58]
000535f9  482b5dc0                 sub rbx, qword ptr [rbp - 0x40]
000535fd  48d1fb                   sar rbx, 1
00053600  2bc3                     sub eax, ebx
00053602  4c63c0                   movsxd r8, eax
00053605  4863c3                   movsxd rax, ebx
00053608  4d03c0                   add r8, r8
0005360b  4883c01e                 add rax, 0x1e
0005360f  488d1447                 lea rdx, [rdi + rax*2]
00053613  e8a7ac0000               call 0x5e2bf
00053618  488b4598                 mov rax, qword ptr [rbp - 0x68]
0005361c  295f5c                   sub dword ptr [rdi + 0x5c], ebx
0005361f  4c8bf8                   mov r15, rax
00053622  488bc8                   mov rcx, rax
00053625  49c1ef20                 shr r15, 0x20
00053629  48c1e110                 shl rcx, 0x10
0005362d  410fb6dd                 movzx ebx, r13b
00053631  440bf9                   or r15d, ecx
00053634  48c1e810                 shr rax, 0x10
00053638  440fb7c0                 movzx r8d, ax
0005363c  4489442448               mov dword ptr [rsp + 0x48], r8d
00053641  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00053646  4181e7ffffff3f           and r15d, 0x3fffffff
0005364d  44897c2440               mov dword ptr [rsp + 0x40], r15d
00053652  84db                     test bl, bl
00053654  7533                     jne 0x53689
00053656  4438642460               cmp byte ptr [rsp + 0x60], r12b
0005365b  742c                     je 0x53689
0005365d  b800280000               mov eax, 0x2800
00053662  b9ff030000               mov ecx, 0x3ff
00053667  66410306                 add ax, word ptr [r14]
0005366b  663bc1                   cmp ax, cx
0005366e  7719                     ja 0x53689
00053670  4c8d4c2440               lea r9, [rsp + 0x40]
00053675  4c8bc7                   mov r8, rdi
00053678  498bd2                   mov rdx, r10
0005367b  e8a0b4ffff               call 0x4eb20
00053680  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053685  440fb6e0                 movzx r12d, al
00053689  837f0400                 cmp dword ptr [rdi + 4], 0
0005368d  0f84d4020000             je 0x53967
00053693  837c245800               cmp dword ptr [rsp + 0x58], 0
00053698  0f85c9020000             jne 0x53967
0005369e  8b5c246c                 mov ebx, dword ptr [rsp + 0x6c]
000536a2  4c8d0557c9faff           lea r8, [rip - 0x536a9]
000536a9  410fb706                 movzx eax, word ptr [r14]
000536ad  ffc3                     inc ebx
000536af  83c0db                   add eax, -0x25
000536b2  895c246c                 mov dword ptr [rsp + 0x6c], ebx
000536b6  83f83a                   cmp eax, 0x3a
000536b9  0f87a2020000             ja 0x53961
000536bf  4898                     cdqe
000536c1  410fb6840070420500       movzx eax, byte ptr [r8 + rax + 0x54270]
000536ca  418b8c8054420500         mov ecx, dword ptr [r8 + rax*4 + 0x54254]
000536d2  4903c8                   add rcx, r8
000536d5  ffe1                     jmp rcx
000536d7  410fb7c7                 movzx eax, r15w
000536db  66c1e808                 shr ax, 8
000536df  3cfe                     cmp al, 0xfe
000536e1  0f855fffffff             jne 0x53646
000536e7  49837a3800               cmp qword ptr [r10 + 0x38], 0
000536ec  0f8454ffffff             je 0x53646
000536f2  85c9                     test ecx, ecx
000536f4  0f854cffffff             jne 0x53646
000536fa  4585db                   test r11d, r11d
000536fd  7409                     je 0x53708
000536ff  4584c9                   test r9b, r9b
00053702  0f843effffff             je 0x53646
00053708  83fa02                   cmp edx, 2
0005370b  7d52                     jge 0x5375f
0005370d  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053711  4885c0                   test rax, rax
00053714  7e44                     jle 0x5375a
00053716  488b4718                 mov rax, qword ptr [rdi + 0x18]
0005371a  4885c0                   test rax, rax
0005371d  740b                     je 0x5372a
0005371f  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00053723  ffd0                     call rax
00053725  0fb7c8                   movzx ecx, ax
00053728  eb12                     jmp 0x5373c
0005372a  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
0005372e  488b4728                 mov rax, qword ptr [rdi + 0x28]
00053732  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00053736  8d4201                   lea eax, [rdx + 1]
00053739  894738                   mov dword ptr [rdi + 0x38], eax
0005373c  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00053740  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00053745  8b575c                   mov edx, dword ptr [rdi + 0x5c]
00053748  48ff4f30                 dec qword ptr [rdi + 0x30]
0005374c  ffc2                     inc edx
0005374e  488b4730                 mov rax, qword ptr [rdi + 0x30]
00053752  89575c                   mov dword ptr [rdi + 0x5c], edx
00053755  83fa02                   cmp edx, 2
00053758  7cb7                     jl 0x53711
0005375a  4c8b542450               mov r10, qword ptr [rsp + 0x50]
0005375f  450fb706                 movzx r8d, word ptr [r14]
00053763  8bca                     mov ecx, edx
00053765  4d8b4a38                 mov r9, qword ptr [r10 + 0x38]
00053769  b8c0270000               mov eax, 0x27c0
0005376e  0fbaf11f                 btr ecx, 0x1f
00053772  4103c0                   add eax, r8d
00053775  6683f829                 cmp ax, 0x29
00053779  7723                     ja 0x5379e
0005377b  488d45f6                 lea rax, [rbp - 0xa]
0005377f  4c3bf0                   cmp r14, rax
00053782  742b                     je 0x537af
00053784  413bcd                   cmp ecx, r13d
00053787  760d                     jbe 0x53796
00053789  450fb75e02               movzx r11d, word ptr [r14 + 2]
0005378e  6644895c245c             mov word ptr [rsp + 0x5c], r11w
00053794  eb06                     jmp 0x5379c
00053796  440fb75c245c             movzx r11d, word ptr [rsp + 0x5c]
0005379c  7722                     ja 0x537c0
0005379e  4181e7ffffff3f           and r15d, 0x3fffffff
000537a5  44897c2440               mov dword ptr [rsp + 0x40], r15d
000537aa  e9a7feffff               jmp 0x53656
000537af  413bcd                   cmp ecx, r13d
000537b2  76ea                     jbe 0x5379e
000537b4  33c0                     xor eax, eax
000537b6  440fb718                 movzx r11d, word ptr [rax]
000537ba  6644895c245c             mov word ptr [rsp + 0x5c], r11w
000537c0  b800240000               mov eax, 0x2400
000537c5  b9ff030000               mov ecx, 0x3ff
000537ca  4103c3                   add eax, r11d
000537cd  663bc1                   cmp ax, cx
000537d0  77cc                     ja 0x5379e
000537d2  b8c9270000               mov eax, 0x27c9
000537d7  664403c0                 add r8w, ax
000537db  b800040000               mov eax, 0x400
000537e0  410fb7c8                 movzx ecx, r8w
000537e4  0fafc8                   imul ecx, eax
000537e7  664103cb                 add cx, r11w
000537eb  0fb7c1                   movzx eax, cx
000537ee  6641833c8100             cmp word ptr [r9 + rax*4], 0
000537f4  74a8                     je 0x5379e
000537f6  418b0481                 mov eax, dword ptr [r9 + rax*4]
000537fa  498bce                   mov rcx, r14
000537fd  0fb7d8                   movzx ebx, ax
00053800  48c1e810                 shr rax, 0x10
00053804  48c1e320                 shl rbx, 0x20
00053808  480bd8                   or rbx, rax
0005380b  8d42ff                   lea eax, [rdx - 1]
0005380e  4c63c0                   movsxd r8, eax
00053811  488d573e                 lea rdx, [rdi + 0x3e]
00053815  4d03c0                   add r8, r8
00053818  e8a2aa0000               call 0x5e2bf
0005381d  ff4f5c                   dec dword ptr [rdi + 0x5c]
00053820  488bc3                   mov rax, rbx
00053823  48c1e810                 shr rax, 0x10
00053827  440fb7c0                 movzx r8d, ax
0005382b  488bc3                   mov rax, rbx
0005382e  48c1e820                 shr rax, 0x20
00053832  48c1e310                 shl rbx, 0x10
00053836  0bc3                     or eax, ebx
00053838  4489442448               mov dword ptr [rsp + 0x48], r8d
0005383d  25ffffff3f               and eax, 0x3fffffff
00053842  448bf8                   mov r15d, eax
00053845  89442440                 mov dword ptr [rsp + 0x40], eax
00053849  e93bfeffff               jmp 0x53689
0005384e  8b542444                 mov edx, dword ptr [rsp + 0x44]
00053852  33db                     xor ebx, ebx
00053854  85d2                     test edx, edx
00053856  751d                     jne 0x53875
00053858  b8fcff0000               mov eax, 0xfffc
0005385d  895c246c                 mov dword ptr [rsp + 0x6c], ebx
00053861  418bd5                   mov edx, r13d
00053864  6689442440               mov word ptr [rsp + 0x40], ax
00053869  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
0005386e  89542444                 mov dword ptr [rsp + 0x44], edx
00053872  895d80                   mov dword ptr [rbp - 0x80], ebx
00053875  85f6                     test esi, esi
00053877  448beb                   mov r13d, ebx
0005387a  410f95c5                 setne r13b
0005387e  e9ef000000               jmp 0x53972
00053883  8b542444                 mov edx, dword ptr [rsp + 0x44]
00053887  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0005388c  85d2                     test edx, edx
0005388e  0f84e3000000             je 0x53977
00053894  b8fbff0000               mov eax, 0xfffb
00053899  33d2                     xor edx, edx
0005389b  6689442440               mov word ptr [rsp + 0x40], ax
000538a0  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
000538a5  89542444                 mov dword ptr [rsp + 0x44], edx
000538a9  e9c9000000               jmp 0x53977
000538ae  8b542444                 mov edx, dword ptr [rsp + 0x44]
000538b2  85d2                     test edx, edx
000538b4  0f84b8000000             je 0x53972
000538ba  413bdd                   cmp ebx, r13d
000538bd  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
000538c2  0f85af000000             jne 0x53977
000538c8  b8f9ff0000               mov eax, 0xfff9
000538cd  6689442440               mov word ptr [rsp + 0x40], ax
000538d2  33c0                     xor eax, eax
000538d4  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
000538d9  8944246c                 mov dword ptr [rsp + 0x6c], eax
000538dd  e995000000               jmp 0x53977
000538e2  ba02000000               mov edx, 2
000538e7  488bcf                   mov rcx, rdi
000538ea  e8f16affff               call 0x4a3e0
000538ef  8b542444                 mov edx, dword ptr [rsp + 0x44]
000538f3  85d2                     test edx, edx
000538f5  7474                     je 0x5396b
000538f7  413bdd                   cmp ebx, r13d
000538fa  7e6f                     jle 0x5396b
000538fc  4c8d05fdc6faff           lea r8, [rip - 0x53903]
00053903  44396f5c                 cmp dword ptr [rdi + 0x5c], r13d
00053907  7e69                     jle 0x53972
00053909  6641837e025d             cmp word ptr [r14 + 2], 0x5d
0005390f  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00053914  7461                     je 0x53977
00053916  b8faff0000               mov eax, 0xfffa
0005391b  4533ed                   xor r13d, r13d
0005391e  6689442440               mov word ptr [rsp + 0x40], ax
00053923  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053928  eb4d                     jmp 0x53977
0005392a  8b542444                 mov edx, dword ptr [rsp + 0x44]
0005392e  85d2                     test edx, edx
00053930  7540                     jne 0x53972
00053932  b8f7ff0000               mov eax, 0xfff7
00053937  6689442440               mov word ptr [rsp + 0x40], ax
0005393c  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053941  eb2f                     jmp 0x53972
00053943  8b542444                 mov edx, dword ptr [rsp + 0x44]
00053947  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0005394c  85d2                     test edx, edx
0005394e  7527                     jne 0x53977
00053950  b8feff0000               mov eax, 0xfffe
00053955  6689442440               mov word ptr [rsp + 0x40], ax
0005395a  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
0005395f  eb16                     jmp 0x53977
00053961  8b542444                 mov edx, dword ptr [rsp + 0x44]
00053965  eb0b                     jmp 0x53972
00053967  8b542444                 mov edx, dword ptr [rsp + 0x44]
0005396b  4c8d058ec6faff           lea r8, [rip - 0x53972]
00053972  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00053977  0fb7442440               movzx eax, word ptr [rsp + 0x40]
0005397c  4533f6                   xor r14d, r14d
0005397f  c1e808                   shr eax, 8
00053982  83f805                   cmp eax, 5
00053985  0f874d060000             ja 0x53fd8
0005398b  418b8c80ac420500         mov ecx, dword ptr [r8 + rax*4 + 0x542ac]
00053993  4903c8                   add rcx, r8
00053996  ffe1                     jmp rcx
00053998  8b475c                   mov eax, dword ptr [rdi + 0x5c]
0005399b  488d573e                 lea rdx, [rdi + 0x3e]
0005399f  ffc8                     dec eax
000539a1  488d4f3c                 lea rcx, [rdi + 0x3c]
000539a5  4c63c0                   movsxd r8, eax
000539a8  4d03c0                   add r8, r8
000539ab  e80fa90000               call 0x5e2bf
000539b0  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000539b7  41be01000000             mov r14d, 1
000539bd  ff4f5c                   dec dword ptr [rdi + 0x5c]
000539c0  4885c0                   test rax, rax
000539c3  7403                     je 0x539c8
000539c5  48ff00                   inc qword ptr [rax]
000539c8  8b742448                 mov esi, dword ptr [rsp + 0x48]
000539cc  33db                     xor ebx, ebx
000539ce  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
000539d2  448b642458               mov r12d, dword ptr [rsp + 0x58]
000539d7  4585e4                   test r12d, r12d
000539da  7e0a                     jle 0x539e6
000539dc  41ffcc                   dec r12d
000539df  8919                     mov dword ptr [rcx], ebx
000539e1  4489642458               mov dword ptr [rsp + 0x58], r12d
000539e6  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
000539eb  4585f6                   test r14d, r14d
000539ee  8b5d70                   mov ebx, dword ptr [rbp + 0x70]
000539f1  4c8d773c                 lea r14, [rdi + 0x3c]
000539f5  0f85c5f9ffff             jne 0x533c0
000539fb  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000539fe  4c8d773c                 lea r14, [rdi + 0x3c]
00053a02  ffc8                     dec eax
00053a04  488d573e                 lea rdx, [rdi + 0x3e]
00053a08  4c63c0                   movsxd r8, eax
00053a0b  498bce                   mov rcx, r14
00053a0e  4d03c0                   add r8, r8
00053a11  e8a9a80000               call 0x5e2bf
00053a16  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053a19  ffc8                     dec eax
00053a1b  89475c                   mov dword ptr [rdi + 0x5c], eax
00053a1e  4585e4                   test r12d, r12d
00053a21  0f8424060000             je 0x5404b
00053a27  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053a2e  488b4768                 mov rax, qword ptr [rdi + 0x68]
00053a32  44893c88                 mov dword ptr [rax + rcx*4], r15d
00053a36  85db                     test ebx, ebx
00053a38  740e                     je 0x53a48
00053a3a  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053a41  488b4770                 mov rax, qword ptr [rdi + 0x70]
00053a45  893488                   mov dword ptr [rax + rcx*4], esi
00053a48  ff8788000000             inc dword ptr [rdi + 0x88]
00053a4e  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
00053a53  e968f9ffff               jmp 0x533c0
00053a58  44387588                 cmp byte ptr [rbp - 0x78], r14b
00053a5c  7411                     je 0x53a6f
00053a5e  443874244c               cmp byte ptr [rsp + 0x4c], r14b
00053a63  740a                     je 0x53a6f
00053a65  44397710                 cmp dword ptr [rdi + 0x10], r14d
00053a69  0f8d29ffffff             jge 0x53998
00053a6f  f7471000000040           test dword ptr [rdi + 0x10], 0x40000000
00053a76  0f844cffffff             je 0x539c8
00053a7c  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053a7f  394738                   cmp dword ptr [rdi + 0x38], eax
00053a82  0f8540ffffff             jne 0x539c8
00053a88  4439b788000000           cmp dword ptr [rdi + 0x88], r14d
00053a8f  0f8533ffffff             jne 0x539c8
00053a95  e9fefeffff               jmp 0x53998
00053a9a  488b4560                 mov rax, qword ptr [rbp + 0x60]
00053a9e  448930                   mov dword ptr [rax], r14d
00053aa1  44397568                 cmp dword ptr [rbp + 0x68], r14d
00053aa5  7412                     je 0x53ab9
00053aa7  44397708                 cmp dword ptr [rdi + 8], r14d
00053aab  0f8417ffffff             je 0x539c8
00053ab1  85d2                     test edx, edx
00053ab3  0f850fffffff             jne 0x539c8
00053ab9  4c63475c                 movsxd r8, dword ptr [rdi + 0x5c]
00053abd  418bcf                   mov ecx, r15d
00053ac0  4d03c0                   add r8, r8
00053ac3  48c1e910                 shr rcx, 0x10
00053ac7  418bc7                   mov eax, r15d
00053aca  48c1e020                 shl rax, 0x20
00053ace  480bc1                   or rax, rcx
00053ad1  488bc8                   mov rcx, rax
00053ad4  48c1e820                 shr rax, 0x20
00053ad8  6681e100ff               and cx, 0xff00
00053add  0fb7d1                   movzx edx, cx
00053ae0  0fb6c8                   movzx ecx, al
00053ae3  488b4590                 mov rax, qword ptr [rbp - 0x70]
00053ae7  480bd1                   or rdx, rcx
00053aea  488d4f3e                 lea rcx, [rdi + 0x3e]
00053aee  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00053af5  8b1c90                   mov ebx, dword ptr [rax + rdx*4]
00053af8  488d573c                 lea rdx, [rdi + 0x3c]
00053afc  e8bea70000               call 0x5e2bf
00053b01  488b442450               mov rax, qword ptr [rsp + 0x50]
00053b06  8344245803               add dword ptr [rsp + 0x58], 3
00053b0b  66895f3c                 mov word ptr [rdi + 0x3c], bx
00053b0f  c1eb10                   shr ebx, 0x10
00053b12  66895f3e                 mov word ptr [rdi + 0x3e], bx
00053b16  8b575c                   mov edx, dword ptr [rdi + 0x5c]
00053b19  c7476001000000           mov dword ptr [rdi + 0x60], 1
00053b20  ffc2                     inc edx
00053b22  89575c                   mov dword ptr [rdi + 0x5c], edx
00053b25  0fb74f3e                 movzx ecx, word ptr [rdi + 0x3e]
00053b29  488b4008                 mov rax, qword ptr [rax + 8]
00053b2d  807c880102               cmp byte ptr [rax + rcx*4 + 1], 2
00053b32  4c8d3488                 lea r14, [rax + rcx*4]
00053b36  755b                     jne 0x53b93
00053b38  4c63c2                   movsxd r8, edx
00053b3b  488d4f40                 lea rcx, [rdi + 0x40]
00053b3f  4d03c0                   add r8, r8
00053b42  488d573e                 lea rdx, [rdi + 0x3e]
00053b46  e874a70000               call 0x5e2bf
00053b4b  418b0e                   mov ecx, dword ptr [r14]
00053b4e  8bc1                     mov eax, ecx
00053b50  48c1e910                 shr rcx, 0x10
00053b54  48c1e020                 shl rax, 0x20
00053b58  480bc1                   or rax, rcx
00053b5b  488bc8                   mov rcx, rax
00053b5e  48c1e820                 shr rax, 0x20
00053b62  6681e100ff               and cx, 0xff00
00053b67  0fb7d1                   movzx edx, cx
00053b6a  0fb6c8                   movzx ecx, al
00053b6d  488b4590                 mov rax, qword ptr [rbp - 0x70]
00053b71  480bd1                   or rdx, rcx
00053b74  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00053b7b  8b0490                   mov eax, dword ptr [rax + rdx*4]
00053b7e  6689473e                 mov word ptr [rdi + 0x3e], ax
00053b82  c1e810                   shr eax, 0x10
00053b85  66894740                 mov word ptr [rdi + 0x40], ax
00053b89  ff475c                   inc dword ptr [rdi + 0x5c]
00053b8c  ff4760                   inc dword ptr [rdi + 0x60]
00053b8f  ff442458                 inc dword ptr [rsp + 0x58]
00053b93  41be01000000             mov r14d, 1
00053b99  e92afeffff               jmp 0x539c8
00053b9e  807c244001               cmp byte ptr [rsp + 0x40], 1
00053ba3  770c                     ja 0x53bb1
00053ba5  488b4578                 mov rax, qword ptr [rbp + 0x78]
00053ba9  4885c0                   test rax, rax
00053bac  7403                     je 0x53bb1
00053bae  c60001                   mov byte ptr [rax], 1
00053bb1  33db                     xor ebx, ebx
00053bb3  418bc7                   mov eax, r15d
00053bb6  48c1e810                 shr rax, 0x10
00053bba  8bcb                     mov ecx, ebx
00053bbc  410fb7d7                 movzx edx, r15w
00053bc0  48c1e220                 shl rdx, 0x20
00053bc4  480bd0                   or rdx, rax
00053bc7  395d80                   cmp dword ptr [rbp - 0x80], ebx
00053bca  743d                     je 0x53c09
00053bcc  488b4560                 mov rax, qword ptr [rbp + 0x60]
00053bd0  448b00                   mov r8d, dword ptr [rax]
00053bd3  410fb7c8                 movzx ecx, r8w
00053bd7  418bc0                   mov eax, r8d
00053bda  48c1e120                 shl rcx, 0x20
00053bde  48c1e810                 shr rax, 0x10
00053be2  480bc8                   or rcx, rax
00053be5  6641c1e808               shr r8w, 8
00053bea  4180f822                 cmp r8b, 0x22
00053bee  7419                     je 0x53c09
00053bf0  395d70                   cmp dword ptr [rbp + 0x70], ebx
00053bf3  7414                     je 0x53c09
00053bf5  4c638788000000           movsxd r8, dword ptr [rdi + 0x88]
00053bfc  488b4770                 mov rax, qword ptr [rdi + 0x70]
00053c00  460fb74c80fc             movzx r9d, word ptr [rax + r8*4 - 4]
00053c06  490bc9                   or rcx, r9
00053c09  4c8bd2                   mov r10, rdx
00053c0c  895c2448                 mov dword ptr [rsp + 0x48], ebx
00053c10  49c1ea20                 shr r10, 0x20
00053c14  8bf3                     mov esi, ebx
00053c16  895c2440                 mov dword ptr [rsp + 0x40], ebx
00053c1a  4180fa01                 cmp r10b, 1
00053c1e  0f879e000000             ja 0x53cc2
00053c24  4c8bc1                   mov r8, rcx
00053c27  49c1e828                 shr r8, 0x28
00053c2b  4180f803                 cmp r8b, 3
00053c2f  770f                     ja 0x53c40
00053c31  48b800000000ffff0000     movabs rax, 0xffff00000000
00053c3b  e9e0000000               jmp 0x53d20
00053c40  488bc1                   mov rax, rcx
00053c43  48c1e810                 shr rax, 0x10
00053c47  4180f822                 cmp r8b, 0x22
00053c4b  7568                     jne 0x53cb5
00053c4d  4c8bc9                   mov r9, rcx
00053c50  49c1e908                 shr r9, 8
00053c54  450fb6c1                 movzx r8d, r9b
00053c58  4180e0c6                 and r8b, 0xc6
00053c5c  4488442440               mov byte ptr [rsp + 0x40], r8b
00053c61  450fb6c1                 movzx r8d, r9b
00053c65  4180e0e4                 and r8b, 0xe4
00053c69  4488442442               mov byte ptr [rsp + 0x42], r8b
00053c6e  440fb7c2                 movzx r8d, dx
00053c72  4584d2                   test r10b, r10b
00053c75  751a                     jne 0x53c91
00053c77  48c1e010                 shl rax, 0x10
00053c7b  490bc0                   or rax, r8
00053c7e  c644244104               mov byte ptr [rsp + 0x41], 4
00053c83  4180e1c5                 and r9b, 0xc5
00053c87  44884c2443               mov byte ptr [rsp + 0x43], r9b
00053c8c  e97c000000               jmp 0x53d0d
00053c91  ba000087ff               mov edx, 0xff870000
00053c96  c644244105               mov byte ptr [rsp + 0x41], 5
00053c9b  4823c2                   and rax, rdx
00053c9e  48c1e010                 shl rax, 0x10
00053ca2  490bc0                   or rax, r8
00053ca5  488bd0                   mov rdx, rax
00053ca8  48c1ea08                 shr rdx, 8
00053cac  80e2c5                   and dl, 0xc5
00053caf  88542443                 mov byte ptr [rsp + 0x43], dl
00053cb3  eb58                     jmp 0x53d0d
00053cb5  48c1e010                 shl rax, 0x10
00053cb9  440fb6c2                 movzx r8d, dl
00053cbd  490bc0                   or rax, r8
00053cc0  eb53                     jmp 0x53d15
00053cc2  488bc2                   mov rax, rdx
00053cc5  c644244103               mov byte ptr [rsp + 0x41], 3
00053cca  48b9ffffffffff22ffff     movabs rcx, 0xffff22ffffffffff
00053cd4  4823c1                   and rax, rcx
00053cd7  48b90000000000220000     movabs rcx, 0x220000000000
00053ce1  480bc1                   or rax, rcx
00053ce4  4c8bc0                   mov r8, rax
00053ce7  488bc8                   mov rcx, rax
00053cea  49c1e808                 shr r8, 8
00053cee  410fb6d0                 movzx edx, r8b
00053cf2  80e2c6                   and dl, 0xc6
00053cf5  88542440                 mov byte ptr [rsp + 0x40], dl
00053cf9  410fb6d0                 movzx edx, r8b
00053cfd  80e2e4                   and dl, 0xe4
00053d00  4180e0c5                 and r8b, 0xc5
00053d04  88542442                 mov byte ptr [rsp + 0x42], dl
00053d08  4488442443               mov byte ptr [rsp + 0x43], r8b
00053d0d  8b742440                 mov esi, dword ptr [rsp + 0x40]
00053d11  89742448                 mov dword ptr [rsp + 0x48], esi
00053d15  4825ff02ffff             and rax, 0xffffffffffff02ff
00053d1b  480fbae809               bts rax, 9
00053d20  488bd0                   mov rdx, rax
00053d23  48c1ea28                 shr rdx, 0x28
00053d27  80fa22                   cmp dl, 0x22
00053d2a  740e                     je 0x53d3a
00053d2c  488bd0                   mov rdx, rax
00053d2f  48c1ea10                 shr rdx, 0x10
00053d33  0fb7f2                   movzx esi, dx
00053d36  89742448                 mov dword ptr [rsp + 0x48], esi
00053d3a  488bd0                   mov rdx, rax
00053d3d  48c1e010                 shl rax, 0x10
00053d41  48c1ea20                 shr rdx, 0x20
00053d45  0bd0                     or edx, eax
00053d47  89542440                 mov dword ptr [rsp + 0x40], edx
00053d4b  448bfa                   mov r15d, edx
00053d4e  80fa01                   cmp dl, 1
00053d51  0f8677fcffff             jbe 0x539ce
00053d57  488bc1                   mov rax, rcx
00053d5a  48c1e110                 shl rcx, 0x10
00053d5e  48c1e820                 shr rax, 0x20
00053d62  0bc1                     or eax, ecx
00053d64  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00053d68  8901                     mov dword ptr [rcx], eax
00053d6a  e963fcffff               jmp 0x539d2
00053d6f  4c8d673c                 lea r12, [rdi + 0x3c]
00053d73  b860110000               mov eax, 0x1160
00053d78  6641390424               cmp word ptr [r12], ax
00053d7d  0f83e7010000             jae 0x53f6a
00053d83  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053d86  83f803                   cmp eax, 3
00053d89  7d4e                     jge 0x53dd9
00053d8b  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00053d8f  90                       nop
00053d90  4885c9                   test rcx, rcx
00053d93  7e44                     jle 0x53dd9
00053d95  488b4718                 mov rax, qword ptr [rdi + 0x18]
00053d99  4885c0                   test rax, rax
00053d9c  740b                     je 0x53da9
00053d9e  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00053da2  ffd0                     call rax
00053da4  0fb7c8                   movzx ecx, ax
00053da7  eb12                     jmp 0x53dbb
00053da9  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
00053dad  488b4728                 mov rax, qword ptr [rdi + 0x28]
00053db1  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00053db5  8d4201                   lea eax, [rdx + 1]
00053db8  894738                   mov dword ptr [rdi + 0x38], eax
00053dbb  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00053dbf  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00053dc4  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053dc7  48ff4f30                 dec qword ptr [rdi + 0x30]
00053dcb  ffc0                     inc eax
00053dcd  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
00053dd1  89475c                   mov dword ptr [rdi + 0x5c], eax
00053dd4  83f803                   cmp eax, 3
00053dd7  7cb7                     jl 0x53d90
00053dd9  488b4d90                 mov rcx, qword ptr [rbp - 0x70]
00053ddd  4c8d4c2464               lea r9, [rsp + 0x64]
00053de2  0fbaf01f                 btr eax, 0x1f
00053de6  4c8965c8                 mov qword ptr [rbp - 0x38], r12
00053dea  8945d0                   mov dword ptr [rbp - 0x30], eax
00053ded  4c8d45c8                 lea r8, [rbp - 0x38]
00053df1  488d4584                 lea rax, [rbp - 0x7c]
00053df5  4c8965e0                 mov qword ptr [rbp - 0x20], r12
00053df9  4889442430               mov qword ptr [rsp + 0x30], rax
00053dfe  4533ff                   xor r15d, r15d
00053e01  488d442468               lea rax, [rsp + 0x68]
00053e06  c744242803000000         mov dword ptr [rsp + 0x28], 3
00053e0e  488bd3                   mov rdx, rbx
00053e11  4889442420               mov qword ptr [rsp + 0x20], rax
00053e16  4c897dd8                 mov qword ptr [rbp - 0x28], r15
00053e1a  e8f1d9ffff               call 0x51810
00053e1f  8bf0                     mov esi, eax
00053e21  85c0                     test eax, eax
00053e23  0f8e41010000             jle 0x53f6a
00053e29  0faee8                   lfence
00053e2c  0fb7442464               movzx eax, word ptr [rsp + 0x64]
00053e31  48639788000000           movsxd rdx, dword ptr [rdi + 0x88]
00053e38  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
00053e3c  448b4570                 mov r8d, dword ptr [rbp + 0x70]
00053e40  6689442470               mov word ptr [rsp + 0x70], ax
00053e45  66c74424720202           mov word ptr [rsp + 0x72], 0x202
00053e4c  8b442470                 mov eax, dword ptr [rsp + 0x70]
00053e50  890491                   mov dword ptr [rcx + rdx*4], eax
00053e53  4585c0                   test r8d, r8d
00053e56  740f                     je 0x53e67
00053e58  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053e5f  488b4770                 mov rax, qword ptr [rdi + 0x70]
00053e63  44893c88                 mov dword ptr [rax + rcx*4], r15d
00053e67  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053e6e  41b900ff0000             mov r9d, 0xff00
00053e74  488bd1                   mov rdx, rcx
00053e77  66c74424760202           mov word ptr [rsp + 0x76], 0x202
00053e7e  8d4101                   lea eax, [rcx + 1]
00053e81  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
00053e85  898788000000             mov dword ptr [rdi + 0x88], eax
00053e8b  0fb6442468               movzx eax, byte ptr [rsp + 0x68]
00053e90  66410bc1                 or ax, r9w
00053e94  6689442474               mov word ptr [rsp + 0x74], ax
00053e99  8b442474                 mov eax, dword ptr [rsp + 0x74]
00053e9d  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
00053ea1  4585c0                   test r8d, r8d
00053ea4  740f                     je 0x53eb5
00053ea6  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053ead  488b4770                 mov rax, qword ptr [rdi + 0x70]
00053eb1  44893c88                 mov dword ptr [rax + rcx*4], r15d
00053eb5  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053ebc  488bd1                   mov rdx, rcx
00053ebf  66c744247a0202           mov word ptr [rsp + 0x7a], 0x202
00053ec6  8d4101                   lea eax, [rcx + 1]
00053ec9  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
00053ecd  898788000000             mov dword ptr [rdi + 0x88], eax
00053ed3  0fb6442469               movzx eax, byte ptr [rsp + 0x69]
00053ed8  66410bc1                 or ax, r9w
00053edc  6689442478               mov word ptr [rsp + 0x78], ax
00053ee1  8b442478                 mov eax, dword ptr [rsp + 0x78]
00053ee5  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
00053ee9  4585c0                   test r8d, r8d
00053eec  740f                     je 0x53efd
00053eee  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00053ef5  488b4770                 mov rax, qword ptr [rdi + 0x70]
00053ef9  44893c88                 mov dword ptr [rax + rcx*4], r15d
00053efd  0fb644246a               movzx eax, byte ptr [rsp + 0x6a]
00053f02  488d573c                 lea rdx, [rdi + 0x3c]
00053f06  ff8788000000             inc dword ptr [rdi + 0x88]
00053f0c  66410bc1                 or ax, r9w
00053f10  668944247c               mov word ptr [rsp + 0x7c], ax
00053f15  ffce                     dec esi
00053f17  4863c6                   movsxd rax, esi
00053f1a  498bcc                   mov rcx, r12
00053f1d  66c744247e0202           mov word ptr [rsp + 0x7e], 0x202
00053f24  448b7c247c               mov r15d, dword ptr [rsp + 0x7c]
00053f29  44897c2440               mov dword ptr [rsp + 0x40], r15d
00053f2e  488d1c00                 lea rbx, [rax + rax]
00053f32  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00053f35  2bc6                     sub eax, esi
00053f37  4803d3                   add rdx, rbx
00053f3a  4c63c0                   movsxd r8, eax
00053f3d  4d03c0                   add r8, r8
00053f40  e87aa30000               call 0x5e2bf
00053f45  29775c                   sub dword ptr [rdi + 0x5c], esi
00053f48  420fb70c23               movzx ecx, word ptr [rbx + r12]
00053f4d  33db                     xor ebx, ebx
00053f4f  488b442450               mov rax, qword ptr [rsp + 0x50]
00053f54  8b742448                 mov esi, dword ptr [rsp + 0x48]
00053f58  488b4008                 mov rax, qword ptr [rax + 8]
00053f5c  8b1488                   mov edx, dword ptr [rax + rcx*4]
00053f5f  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00053f63  8911                     mov dword ptr [rcx], edx
00053f65  e968faffff               jmp 0x539d2
00053f6a  410fb70c24               movzx ecx, word ptr [r12]
00053f6f  488b4308                 mov rax, qword ptr [rbx + 8]
00053f73  8b742448                 mov esi, dword ptr [rsp + 0x48]
00053f77  8b1488                   mov edx, dword ptr [rax + rcx*4]
00053f7a  8bc2                     mov eax, edx
00053f7c  c1e810                   shr eax, 0x10
00053f7f  0fb6c8                   movzx ecx, al
00053f82  89542440                 mov dword ptr [rsp + 0x40], edx
00053f86  c644244202               mov byte ptr [rsp + 0x42], 2
00053f8b  0fb6c2                   movzx eax, dl
00053f8e  66c1e008                 shl ax, 8
00053f92  660bc8                   or cx, ax
00053f95  66894c2440               mov word ptr [rsp + 0x40], cx
00053f9a  33db                     xor ebx, ebx
00053f9c  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00053fa0  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053fa5  8911                     mov dword ptr [rcx], edx
00053fa7  e926faffff               jmp 0x539d2
00053fac  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00053fb0  410fb6f7                 movzx esi, r15b
00053fb4  c1e608                   shl esi, 8
00053fb7  c7442440fffd0202         mov dword ptr [rsp + 0x40], 0x202fdff
00053fbf  448939                   mov dword ptr [rcx], r15d
00053fc2  0fb64102                 movzx eax, byte ptr [rcx + 2]
00053fc6  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00053fcb  0bf0                     or esi, eax
00053fcd  89742448                 mov dword ptr [rsp + 0x48], esi
00053fd1  33db                     xor ebx, ebx
00053fd3  e9faf9ffff               jmp 0x539d2
00053fd8  488b4560                 mov rax, qword ptr [rbp + 0x60]
00053fdc  410fb7cf                 movzx ecx, r15w
00053fe0  48c1e120                 shl rcx, 0x20
00053fe4  448938                   mov dword ptr [rax], r15d
00053fe7  418bc7                   mov eax, r15d
00053fea  48c1e810                 shr rax, 0x10
00053fee  480bc8                   or rcx, rax
00053ff1  488bc1                   mov rax, rcx
00053ff4  440fb6c9                 movzx r9d, cl
00053ff8  48c1e828                 shr rax, 0x28
00053ffc  0440                     add al, 0x40
00053ffe  3c30                     cmp al, 0x30
00054000  7724                     ja 0x54026
00054002  448b03                   mov r8d, dword ptr [rbx]
00054005  41b9ff030000             mov r9d, 0x3ff
0005400b  418bc0                   mov eax, r8d
0005400e  0fb6d1                   movzx edx, cl
00054011  4123c1                   and eax, r9d
00054014  83f804                   cmp eax, 4
00054017  741a                     je 0x54033
00054019  440fb6c9                 movzx r9d, cl
0005401d  4181f811040400           cmp r8d, 0x40411
00054024  740d                     je 0x54033
00054026  410fb6d1                 movzx edx, r9b
0005402a  4584e4                   test r12b, r12b
0005402d  0f8495f9ffff             je 0x539c8
00054033  48c1e908                 shr rcx, 8
00054037  0fb6c2                   movzx eax, dl
0005403a  0fb6f1                   movzx esi, cl
0005403d  c1e008                   shl eax, 8
00054040  0bf0                     or esi, eax
00054042  89742448                 mov dword ptr [rsp + 0x48], esi
00054046  e981f9ffff               jmp 0x539cc
0005404b  4585ed                   test r13d, r13d
0005404e  0f841f010000             je 0x54173
00054054  8b742460                 mov esi, dword ptr [rsp + 0x60]
00054058  c644244c01               mov byte ptr [rsp + 0x4c], 1
0005405d  8bc8                     mov ecx, eax
0005405f  83f801                   cmp eax, 1
00054062  7d4d                     jge 0x540b1
00054064  488b4730                 mov rax, qword ptr [rdi + 0x30]
00054068  4885c0                   test rax, rax
0005406b  7e44                     jle 0x540b1
0005406d  488b4718                 mov rax, qword ptr [rdi + 0x18]
00054071  4885c0                   test rax, rax
00054074  740b                     je 0x54081
00054076  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0005407a  ffd0                     call rax
0005407c  0fb7c8                   movzx ecx, ax
0005407f  eb12                     jmp 0x54093
00054081  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
00054085  488b4728                 mov rax, qword ptr [rdi + 0x28]
00054089  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
0005408d  8d4201                   lea eax, [rdx + 1]
00054090  894738                   mov dword ptr [rdi + 0x38], eax
00054093  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00054097  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
0005409c  8b4f5c                   mov ecx, dword ptr [rdi + 0x5c]
0005409f  48ff4f30                 dec qword ptr [rdi + 0x30]
000540a3  ffc1                     inc ecx
000540a5  488b4730                 mov rax, qword ptr [rdi + 0x30]
000540a9  894f5c                   mov dword ptr [rdi + 0x5c], ecx
000540ac  83f901                   cmp ecx, 1
000540af  7cb7                     jl 0x54068
000540b1  85c9                     test ecx, ecx
000540b3  0f84af000000             je 0x54168
000540b9  41b9f7ff0000             mov r9d, 0xfff7
000540bf  6644394c2440             cmp word ptr [rsp + 0x40], r9w
000540c5  7527                     jne 0x540ee
000540c7  6641833e25               cmp word ptr [r14], 0x25
000540cc  7520                     jne 0x540ee
000540ce  8d41ff                   lea eax, [rcx - 1]
000540d1  4c63c0                   movsxd r8, eax
000540d4  488d573e                 lea rdx, [rdi + 0x3e]
000540d8  4d03c0                   add r8, r8
000540db  498bce                   mov rcx, r14
000540de  e8dca10000               call 0x5e2bf
000540e3  ff4f5c                   dec dword ptr [rdi + 0x5c]
000540e6  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000540e9  e96fffffff               jmp 0x5405d
000540ee  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000540f3  450fb706                 movzx r8d, word ptr [r14]
000540f7  498b4208                 mov rax, qword ptr [r10 + 8]
000540fb  428b1480                 mov edx, dword ptr [rax + r8*4]
000540ff  8bc2                     mov eax, edx
00054101  c1e810                   shr eax, 0x10
00054104  66c1ea08                 shr dx, 8
00054108  84d2                     test dl, dl
0005410a  752f                     jne 0x5413b
0005410c  4084f6                   test sil, sil
0005410f  7457                     je 0x54168
00054111  b800280000               mov eax, 0x2800
00054116  664403c0                 add r8w, ax
0005411a  b8ff030000               mov eax, 0x3ff
0005411f  66443bc0                 cmp r8w, ax
00054123  7743                     ja 0x54168
00054125  4c8d4da0                 lea r9, [rbp - 0x60]
00054129  4c8bc7                   mov r8, rdi
0005412c  498bd2                   mov rdx, r10
0005412f  e8eca9ffff               call 0x4eb20
00054134  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00054137  ffc8                     dec eax
00054139  eb96                     jmp 0x540d1
0005413b  80fa01                   cmp dl, 1
0005413e  7528                     jne 0x54168
00054140  6644394c2440             cmp word ptr [rsp + 0x40], r9w
00054146  7386                     jae 0x540ce
00054148  0fb6d0                   movzx edx, al
0005414b  0fb6442442               movzx eax, byte ptr [rsp + 0x42]
00054150  6603d0                   add dx, ax
00054153  b8ff000000               mov eax, 0xff
00054158  663bd0                   cmp dx, ax
0005415b  7602                     jbe 0x5415f
0005415d  8bd0                     mov edx, eax
0005415f  88542442                 mov byte ptr [rsp + 0x42], dl
00054163  e966ffffff               jmp 0x540ce
00054168  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
0005416d  8b742448                 mov esi, dword ptr [rsp + 0x48]
00054171  eb05                     jmp 0x54178
00054173  c644244c00               mov byte ptr [rsp + 0x4c], 0
00054178  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005417f  488b4768                 mov rax, qword ptr [rdi + 0x68]
00054183  44893c88                 mov dword ptr [rax + rcx*4], r15d
00054187  85db                     test ebx, ebx
00054189  740e                     je 0x54199
0005418b  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00054192  488b4770                 mov rax, qword ptr [rdi + 0x70]
00054196  893488                   mov dword ptr [rax + rcx*4], esi
00054199  ff8788000000             inc dword ptr [rdi + 0x88]
0005419f  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
000541a4  4585db                   test r11d, r11d
000541a7  0f8513f2ffff             jne 0x533c0
000541ad  33c0                     xor eax, eax
000541af  488b4d08                 mov rcx, qword ptr [rbp + 8]
000541b3  4833cc                   xor rcx, rsp
000541b6  e8b58c0000               call 0x5ce70
000541bb  4c8d9c2410010000         lea r11, [rsp + 0x110]
000541c3  498b5b30                 mov rbx, qword ptr [r11 + 0x30]
000541c7  498b7338                 mov rsi, qword ptr [r11 + 0x38]
000541cb  498b7b40                 mov rdi, qword ptr [r11 + 0x40]
000541cf  498be3                   mov rsp, r11
000541d2  415f                     pop r15
000541d4  415e                     pop r14
000541d6  415d                     pop r13
000541d8  415c                     pop r12
000541da  5d                       pop rbp
000541db  c3                       ret
000541dc  b803000000               mov eax, 3
000541e1  ebcc                     jmp 0x541af
000541e3  b802000000               mov eax, 2
000541e8  ebc5                     jmp 0x541af
000541ea  4585db                   test r11d, r11d
000541ed  741a                     je 0x54209
000541ef  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000541f6  bafbff0000               mov edx, 0xfffb
000541fb  488b4768                 mov rax, qword ptr [rdi + 0x68]
000541ff  66891488                 mov word ptr [rax + rcx*4], dx
00054203  ff8788000000             inc dword ptr [rdi + 0x88]
00054209  8b9788000000             mov edx, dword ptr [rdi + 0x88]
0005420f  3b9784000000             cmp edx, dword ptr [rdi + 0x84]
00054215  7596                     jne 0x541ad
00054217  f7471000000008           test dword ptr [rdi + 0x10], 0x8000000
0005421e  7428                     je 0x54248
00054220  498b4a08                 mov rcx, qword ptr [r10 + 8]
00054224  4c63c2                   movsxd r8, edx
00054227  488b5768                 mov rdx, qword ptr [rdi + 0x68]
0005422b  8b8980000000             mov ecx, dword ptr [rcx + 0x80]
00054231  42890c82                 mov dword ptr [rdx + r8*4], ecx
00054235  85db                     test ebx, ebx
00054237  740f                     je 0x54248
00054239  48639788000000           movsxd rdx, dword ptr [rdi + 0x88]
00054240  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
00054244  44892491                 mov dword ptr [rcx + rdx*4], r12d
00054248  b801000000               mov eax, 1
0005424d  e95dffffff               jmp 0x541af
00054252  6690                     nop
00054254  2a39                     sub bh, byte ptr [rcx]
00054256  0500e23805               add eax, 0x538e200
0005425b  004e38                   add byte ptr [rsi + 0x38], cl
0005425e  0500833805               add eax, 0x5388300
00054263  00ae38050043             add byte ptr [rsi + 0x43000538], ch
00054269  390500613905             cmp dword ptr [rip + 0x5396100], eax
0005426f  0000                     add byte ptr [rax], al
