; CEsCompInfoSeg::~CEsCompInfoSeg
; aetm_enclave.dll, primary RVA 0x2c260, 86 bytes in 3 chunk(s)

; chunk at RVA 0x2c260 (17 bytes)
0002c260  4057                     push rdi
0002c262  4883ec20                 sub rsp, 0x20
0002c266  488bf9                   mov rdi, rcx
0002c269  488b09                   mov rcx, qword ptr [rcx]
0002c26c  4885c9                   test rcx, rcx
0002c26f  743f                     je 0x2c2b0

; chunk at RVA 0x2c271 (63 bytes)
0002c271  48895c2430               mov qword ptr [rsp + 0x30], rbx
0002c276  33db                     xor ebx, ebx
0002c278  395f08                   cmp dword ptr [rdi + 8], ebx
0002c27b  7629                     jbe 0x2c2a6
0002c27d  488bd1                   mov rdx, rcx
0002c280  4c8b04d9                 mov r8, qword ptr [rcx + rbx*8]
0002c284  4d85c0                   test r8, r8
0002c287  7413                     je 0x2c29c
0002c289  498b00                   mov rax, qword ptr [r8]
0002c28c  ba01000000               mov edx, 1
0002c291  498bc8                   mov rcx, r8
0002c294  ff10                     call qword ptr [rax]
0002c296  488b0f                   mov rcx, qword ptr [rdi]
0002c299  488bd1                   mov rdx, rcx
0002c29c  ffc3                     inc ebx
0002c29e  3b5f08                   cmp ebx, dword ptr [rdi + 8]
0002c2a1  72dd                     jb 0x2c280
0002c2a3  488bca                   mov rcx, rdx
0002c2a6  e8310c0300               call 0x5cedc
0002c2ab  488b5c2430               mov rbx, qword ptr [rsp + 0x30]

; chunk at RVA 0x2c2b0 (6 bytes)
0002c2b0  4883c420                 add rsp, 0x20
0002c2b4  5f                       pop rdi
0002c2b5  c3                       ret
