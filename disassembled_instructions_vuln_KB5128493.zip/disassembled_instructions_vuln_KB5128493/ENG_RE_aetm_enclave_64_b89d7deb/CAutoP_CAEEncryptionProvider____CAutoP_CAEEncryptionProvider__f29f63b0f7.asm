; CAutoP<CAEEncryptionProvider>::~CAutoP<CAEEncryptionProvider>
; aetm_enclave.dll, primary RVA 0x12a20, 94 bytes in 1 chunk(s)

; chunk at RVA 0x12a20 (94 bytes)
00012a20  4053                     push rbx
00012a22  4883ec20                 sub rsp, 0x20
00012a26  488b19                   mov rbx, qword ptr [rcx]
00012a29  4885db                   test rbx, rbx
00012a2c  744a                     je 0x12a78
00012a2e  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
00012a32  4885c9                   test rcx, rcx
00012a35  7413                     je 0x12a4a
00012a37  488b01                   mov rax, qword ptr [rcx]
00012a3a  ba01000000               mov edx, 1
00012a3f  ff5010                   call qword ptr [rax + 0x10]
00012a42  48c7437000000000         mov qword ptr [rbx + 0x70], 0
00012a4a  488b4b78                 mov rcx, qword ptr [rbx + 0x78]
00012a4e  4885c9                   test rcx, rcx
00012a51  7413                     je 0x12a66
00012a53  488b01                   mov rax, qword ptr [rcx]
00012a56  ba01000000               mov edx, 1
00012a5b  ff5010                   call qword ptr [rax + 0x10]
00012a5e  48c7437800000000         mov qword ptr [rbx + 0x78], 0
00012a66  ba80000000               mov edx, 0x80
00012a6b  488bcb                   mov rcx, rbx
00012a6e  4883c420                 add rsp, 0x20
00012a72  5b                       pop rbx
00012a73  e978a50400               jmp 0x5cff0
00012a78  4883c420                 add rsp, 0x20
00012a7c  5b                       pop rbx
00012a7d  c3                       ret
