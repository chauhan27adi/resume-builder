; `CAEStreamEncryptionProvider::CAEStreamEncryptionProvider'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x61300, 28 bytes in 1 chunk(s)

; chunk at RVA 0x61300 (28 bytes)
00061300  4055                     push rbp
00061302  4883ec20                 sub rsp, 0x20
00061306  488bea                   mov rbp, rdx
00061309  488b5568                 mov rdx, qword ptr [rbp + 0x68]
0006130d  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00061311  e86a86fbff               call 0x19980
00061316  4883c420                 add rsp, 0x20
0006131a  5d                       pop rbp
0006131b  c3                       ret
