; CTrustedMachine::ClearKey
; aetm_enclave.dll, primary RVA 0xdf60, 873 bytes in 6 chunk(s)

; chunk at RVA 0xdf60 (226 bytes)
0000df60  4055                     push rbp
0000df62  57                       push rdi
0000df63  4883ec38                 sub rsp, 0x38
0000df67  488da9c0da4700           lea rbp, [rcx + 0x47dac0]
0000df6e  90                       nop
0000df6f  0fb68100db4700           movzx eax, byte ptr [rcx + 0x47db00]
0000df76  4c8d99c0da5000           lea r11, [rcx + 0x50dac0]
0000df7d  488bf9                   mov rdi, rcx
0000df80  4c8bd5                   mov r10, rbp
0000df83  493beb                   cmp rbp, r11
0000df86  7318                     jae 0xdfa0
0000df88  84c0                     test al, al
0000df8a  7514                     jne 0xdfa0
0000df8c  4983c248                 add r10, 0x48
0000df90  90                       nop
0000df91  410fb64240               movzx eax, byte ptr [r10 + 0x40]
0000df96  4d3bd3                   cmp r10, r11
0000df99  72ed                     jb 0xdf88
0000df9b  0f1f440000               nop dword ptr [rax + rax]
0000dfa0  90                       nop
0000dfa1  410fb64340               movzx eax, byte ptr [r11 + 0x40]
0000dfa6  498bca                   mov rcx, r10
0000dfa9  4d3bd3                   cmp r10, r11
0000dfac  0f84f8020000             je 0xe2aa
0000dfb2  66413912                 cmp word ptr [r10], dx
0000dfb6  750c                     jne 0xdfc4
0000dfb8  45394204                 cmp dword ptr [r10 + 4], r8d
0000dfbc  7506                     jne 0xdfc4
0000dfbe  4d394a08                 cmp qword ptr [r10 + 8], r9
0000dfc2  7431                     je 0xdff5
0000dfc4  4983c248                 add r10, 0x48
0000dfc8  90                       nop
0000dfc9  493bcb                   cmp rcx, r11
0000dfcc  4c0f43d1                 cmovae r10, rcx
0000dfd0  410fb64240               movzx eax, byte ptr [r10 + 0x40]
0000dfd5  4d3bd3                   cmp r10, r11
0000dfd8  73c6                     jae 0xdfa0
0000dfda  660f1f440000             nop word ptr [rax + rax]
0000dfe0  84c0                     test al, al
0000dfe2  75bc                     jne 0xdfa0
0000dfe4  4983c248                 add r10, 0x48
0000dfe8  90                       nop
0000dfe9  410fb64240               movzx eax, byte ptr [r10 + 0x40]
0000dfee  4d3bd3                   cmp r10, r11
0000dff1  72ed                     jb 0xdfe0
0000dff3  ebab                     jmp 0xdfa0
0000dff5  482bcd                   sub rcx, rbp
0000dff8  90                       nop
0000dff9  410fb64240               movzx eax, byte ptr [r10 + 0x40]
0000dffe  90                       nop
0000dfff  48b8398ee3388ee3380e     movabs rax, 0xe38e38e38e38e39
0000e009  48f7e9                   imul rcx
0000e00c  48c1fa02                 sar rdx, 2
0000e010  488bc2                   mov rax, rdx
0000e013  48c1e83f                 shr rax, 0x3f
0000e017  4803d0                   add rdx, rax
0000e01a  498b4238                 mov rax, qword ptr [r10 + 0x38]
0000e01e  48c1e820                 shr rax, 0x20
0000e022  4863ca                   movsxd rcx, edx
0000e025  48c1e120                 shl rcx, 0x20
0000e029  480bc8                   or rcx, rax
0000e02c  48894c2450               mov qword ptr [rsp + 0x50], rcx
0000e031  4883f9ff                 cmp rcx, -1
0000e035  0f846f020000             je 0xe2aa
0000e03b  4c8d97c85a5100           lea r10, [rdi + 0x515ac8]

; chunk at RVA 0xe042 (12 bytes)
0000e042  4889742460               mov qword ptr [rsp + 0x60], rsi
0000e047  4c8d8fc85a5600           lea r9, [rdi + 0x565ac8]

; chunk at RVA 0xe04e (422 bytes)
0000e04e  4c89742468               mov qword ptr [rsp + 0x68], r14
0000e053  4c897c2430               mov qword ptr [rsp + 0x30], r15
0000e058  90                       nop
0000e059  0fb687e85a5100           movzx eax, byte ptr [rdi + 0x515ae8]
0000e060  4d8bc2                   mov r8, r10
0000e063  4d3bd1                   cmp r10, r9
0000e066  7313                     jae 0xe07b
0000e068  84c0                     test al, al
0000e06a  750f                     jne 0xe07b
0000e06c  4983c028                 add r8, 0x28
0000e070  90                       nop
0000e071  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000e076  4d3bc1                   cmp r8, r9
0000e079  72ed                     jb 0xe068
0000e07b  48be00000000ffffffff     movabs rsi, 0xffffffff00000000
0000e085  48895c2458               mov qword ptr [rsp + 0x58], rbx
0000e08a  49bf6766666666666666     movabs r15, 0x6666666666666667
0000e094  49be0000000001000000     movabs r14, 0x100000000
0000e09e  6690                     nop
0000e0a0  90                       nop
0000e0a1  410fb64120               movzx eax, byte ptr [r9 + 0x20]
0000e0a6  4d8bd8                   mov r11, r8
0000e0a9  4d3bc1                   cmp r8, r9
0000e0ac  0f8401010000             je 0xe1b3
0000e0b2  488b442450               mov rax, qword ptr [rsp + 0x50]
0000e0b7  493900                   cmp qword ptr [r8], rax
0000e0ba  0f85bd000000             jne 0xe17d
0000e0c0  90                       nop
0000e0c1  498bc8                   mov rcx, r8
0000e0c4  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000e0c9  492bca                   sub rcx, r10
0000e0cc  90                       nop
0000e0cd  498bc7                   mov rax, r15
0000e0d0  48f7e9                   imul rcx
0000e0d3  48c1fa04                 sar rdx, 4
0000e0d7  488bc2                   mov rax, rdx
0000e0da  48c1e83f                 shr rax, 0x3f
0000e0de  4803d0                   add rdx, rax
0000e0e1  498b4018                 mov rax, qword ptr [r8 + 0x18]
0000e0e5  48c1e820                 shr rax, 0x20
0000e0e9  90                       nop
0000e0ea  4863ca                   movsxd rcx, edx
0000e0ed  48c1e120                 shl rcx, 0x20
0000e0f1  480bc8                   or rcx, rax
0000e0f4  488bc1                   mov rax, rcx
0000e0f7  48c1e820                 shr rax, 0x20
0000e0fb  8bd0                     mov edx, eax
0000e0fd  25ff1f0000               and eax, 0x1fff
0000e102  8bd8                     mov ebx, eax
0000e104  488d0480                 lea rax, [rax + rax*4]
0000e108  450fb644c221             movzx r8d, byte ptr [r10 + rax*8 + 0x21]
0000e10e  90                       nop
0000e10f  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000e114  48c1e820                 shr rax, 0x20
0000e118  3bc1                     cmp eax, ecx
0000e11a  755a                     jne 0xe176
0000e11c  4584c0                   test r8b, r8b
0000e11f  7455                     je 0xe176
0000e121  81e2ff1f0000             and edx, 0x1fff
0000e127  90                       nop
0000e128  488d0492                 lea rax, [rdx + rdx*4]
0000e12c  498d14c2                 lea rdx, [r10 + rax*8]
0000e130  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000e135  85c0                     test eax, eax
0000e137  753d                     jne 0xe176
0000e139  488bc8                   mov rcx, rax
0000e13c  4823ce                   and rcx, rsi
0000e13f  4903ce                   add rcx, r14
0000e142  f0480fb14a18             lock cmpxchg qword ptr [rdx + 0x18], rcx
0000e148  752c                     jne 0xe176
0000e14a  c6422000                 mov byte ptr [rdx + 0x20], 0
0000e14e  c6422100                 mov byte ptr [rdx + 0x21], 0
0000e152  90                       nop
0000e153  488b4218                 mov rax, qword ptr [rdx + 0x18]
0000e157  48c1e820                 shr rax, 0x20
0000e15b  83f8ff                   cmp eax, -1
0000e15e  7416                     je 0xe176
0000e160  49638200800500           movsxd rax, dword ptr [r10 + 0x58000]
0000e167  41899c8200000500         mov dword ptr [r10 + rax*4 + 0x50000], ebx
0000e16f  41ff8200800500           inc dword ptr [r10 + 0x58000]
0000e176  48ff0dd3774600           dec qword ptr [rip + 0x4677d3]
0000e17d  4d3bd9                   cmp r11, r9
0000e180  4d8d4328                 lea r8, [r11 + 0x28]
0000e184  90                       nop
0000e185  4d0f43c3                 cmovae r8, r11
0000e189  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000e18e  4d3bc1                   cmp r8, r9
0000e191  0f8309ffffff             jae 0xe0a0
0000e197  84c0                     test al, al
0000e199  0f8501ffffff             jne 0xe0a0
0000e19f  4983c028                 add r8, 0x28
0000e1a3  90                       nop
0000e1a4  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000e1a9  4d3bc1                   cmp r8, r9
0000e1ac  72e9                     jb 0xe197
0000e1ae  e9edfeffff               jmp 0xe0a0
0000e1b3  488b4c2450               mov rcx, qword ptr [rsp + 0x50]
0000e1b8  90                       nop
0000e1b9  4c8b7c2430               mov r15, qword ptr [rsp + 0x30]
0000e1be  4c8b742468               mov r14, qword ptr [rsp + 0x68]
0000e1c3  48c1e920                 shr rcx, 0x20
0000e1c7  488bc1                   mov rax, rcx
0000e1ca  25ff1f0000               and eax, 0x1fff
0000e1cf  488d04c0                 lea rax, [rax + rax*8]
0000e1d3  488d34c500000000         lea rsi, [rax*8]
0000e1db  0fb6542e41               movzx edx, byte ptr [rsi + rbp + 0x41]
0000e1e0  90                       nop
0000e1e1  488b442e38               mov rax, qword ptr [rsi + rbp + 0x38]
0000e1e6  48c1e820                 shr rax, 0x20
0000e1ea  3b442450                 cmp eax, dword ptr [rsp + 0x50]
0000e1ee  0f85bd000000             jne 0xe2b1

; chunk at RVA 0xe1f4 (182 bytes)
0000e1f4  84d2                     test dl, dl
0000e1f6  0f84b5000000             je 0xe2b1
0000e1fc  81e1ff1f0000             and ecx, 0x1fff
0000e202  4881c7b85a4100           add rdi, 0x415ab8
0000e209  488d04c9                 lea rax, [rcx + rcx*8]
0000e20d  488d1cc500000000         lea rbx, [rax*8]
0000e215  488b4c2b30               mov rcx, qword ptr [rbx + rbp + 0x30]
0000e21a  90                       nop
0000e21b  488bc1                   mov rax, rcx
0000e21e  48c1e820                 shr rax, 0x20
0000e222  25ff1f0000               and eax, 0x1fff
0000e227  488d0440                 lea rax, [rax + rax*2]
0000e22b  4803c0                   add rax, rax
0000e22e  0fb654c729               movzx edx, byte ptr [rdi + rax*8 + 0x29]
0000e233  90                       nop
0000e234  488b44c720               mov rax, qword ptr [rdi + rax*8 + 0x20]
0000e239  48c1e820                 shr rax, 0x20
0000e23d  3bc1                     cmp eax, ecx
0000e23f  7570                     jne 0xe2b1
0000e241  84d2                     test dl, dl
0000e243  746c                     je 0xe2b1
0000e245  488b442b30               mov rax, qword ptr [rbx + rbp + 0x30]
0000e24a  48c1e820                 shr rax, 0x20
0000e24e  25ff1f0000               and eax, 0x1fff
0000e253  488d0c40                 lea rcx, [rax + rax*2]
0000e257  48c1e104                 shl rcx, 4
0000e25b  4803cf                   add rcx, rdi
0000e25e  e87db0ffff               call 0x92e0
0000e263  90                       nop
0000e264  0fb6542e41               movzx edx, byte ptr [rsi + rbp + 0x41]
0000e269  90                       nop
0000e26a  488b442e38               mov rax, qword ptr [rsi + rbp + 0x38]
0000e26f  48c1e820                 shr rax, 0x20
0000e273  3b442450                 cmp eax, dword ptr [rsp + 0x50]
0000e277  7538                     jne 0xe2b1
0000e279  84d2                     test dl, dl
0000e27b  7434                     je 0xe2b1
0000e27d  488d5530                 lea rdx, [rbp + 0x30]
0000e281  488bcf                   mov rcx, rdi
0000e284  4803d3                   add rdx, rbx
0000e287  e834220000               call 0x104c0
0000e28c  488d542450               lea rdx, [rsp + 0x50]
0000e291  488bcd                   mov rcx, rbp
0000e294  e867210000               call 0x10400
0000e299  48ff0da8764600           dec qword ptr [rip + 0x4676a8]
0000e2a0  488b5c2458               mov rbx, qword ptr [rsp + 0x58]
0000e2a5  488b742460               mov rsi, qword ptr [rsp + 0x60]

; chunk at RVA 0xe2aa (7 bytes)
0000e2aa  4883c438                 add rsp, 0x38
0000e2ae  5f                       pop rdi
0000e2af  5d                       pop rbp
0000e2b0  c3                       ret

; chunk at RVA 0xe2b1 (24 bytes)
0000e2b1  ba5f000000               mov edx, 0x5f
0000e2b6  b94b010000               mov ecx, 0x14b
0000e2bb  448d4aa2                 lea r9d, [rdx - 0x5e]
0000e2bf  448d42b2                 lea r8d, [rdx - 0x4e]
0000e2c3  e878b10000               call 0x19440
0000e2c8  cc                       int3
