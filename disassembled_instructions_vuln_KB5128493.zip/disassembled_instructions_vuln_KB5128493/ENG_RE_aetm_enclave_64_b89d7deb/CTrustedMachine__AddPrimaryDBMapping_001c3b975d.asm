; CTrustedMachine::AddPrimaryDBMapping
; aetm_enclave.dll, primary RVA 0xd580, 664 bytes in 1 chunk(s)

; chunk at RVA 0xd580 (664 bytes)
0000d580  4056                     push rsi
0000d582  57                       push rdi
0000d583  4156                     push r14
0000d585  4883ec50                 sub rsp, 0x50
0000d589  48c7442430feffffff       mov qword ptr [rsp + 0x30], 0xfffffffffffffffe
0000d592  48895c2478               mov qword ptr [rsp + 0x78], rbx
0000d597  4889ac2480000000         mov qword ptr [rsp + 0x80], rbp
0000d59f  418bf0                   mov esi, r8d
0000d5a2  8bea                     mov ebp, edx
0000d5a4  488bf9                   mov rdi, rcx
0000d5a7  4c8d99d87a5800           lea r11, [rcx + 0x587ad8]
0000d5ae  4d8bcb                   mov r9, r11
0000d5b1  4c8d91d8aa5800           lea r10, [rcx + 0x58aad8]
0000d5b8  90                       nop
0000d5b9  0fb681e87a5800           movzx eax, byte ptr [rcx + 0x587ae8]
0000d5c0  4d3bda                   cmp r11, r10
0000d5c3  7313                     jae 0xd5d8
0000d5c5  84c0                     test al, al
0000d5c7  750f                     jne 0xd5d8
0000d5c9  4983c118                 add r9, 0x18
0000d5cd  90                       nop
0000d5ce  410fb64110               movzx eax, byte ptr [r9 + 0x10]
0000d5d3  4d3bca                   cmp r9, r10
0000d5d6  72ed                     jb 0xd5c5
0000d5d8  49beabaaaaaaaaaaaa2a     movabs r14, 0x2aaaaaaaaaaaaaab
0000d5e2  4d8bc1                   mov r8, r9
0000d5e5  90                       nop
0000d5e6  410fb64210               movzx eax, byte ptr [r10 + 0x10]
0000d5eb  4d3bca                   cmp r9, r10
0000d5ee  0f84ef000000             je 0xd6e3
0000d5f4  90                       nop
0000d5f5  410fb64110               movzx eax, byte ptr [r9 + 0x10]
0000d5fa  498bc9                   mov rcx, r9
0000d5fd  492bcb                   sub rcx, r11
0000d600  498bc6                   mov rax, r14
0000d603  48f7e9                   imul rcx
0000d606  48c1fa02                 sar rdx, 2
0000d60a  488bc2                   mov rax, rdx
0000d60d  48c1e83f                 shr rax, 0x3f
0000d611  4803d0                   add rdx, rax
0000d614  90                       nop
0000d615  498b4108                 mov rax, qword ptr [r9 + 8]
0000d619  4863ca                   movsxd rcx, edx
0000d61c  48c1e120                 shl rcx, 0x20
0000d620  48c1e820                 shr rax, 0x20
0000d624  480bc8                   or rcx, rax
0000d627  48894c2470               mov qword ptr [rsp + 0x70], rcx
0000d62c  48c1e920                 shr rcx, 0x20
0000d630  0faee8                   lfence
0000d633  488bc1                   mov rax, rcx
0000d636  25ff010000               and eax, 0x1ff
0000d63b  488d0440                 lea rax, [rax + rax*2]
0000d63f  488d14c7                 lea rdx, [rdi + rax*8]
0000d643  f048ff82e07a5800         lock inc qword ptr [rdx + 0x587ae0]
0000d64b  81e1ff010000             and ecx, 0x1ff
0000d651  488d0449                 lea rax, [rcx + rcx*2]
0000d655  90                       nop
0000d656  410fb65cc310             movzx ebx, byte ptr [r11 + rax*8 + 0x10]
0000d65c  90                       nop
0000d65d  498b44c308               mov rax, qword ptr [r11 + rax*8 + 8]
0000d662  48c1e820                 shr rax, 0x20
0000d666  488b4c2470               mov rcx, qword ptr [rsp + 0x70]
0000d66b  3bc1                     cmp eax, ecx
0000d66d  750a                     jne 0xd679
0000d66f  84db                     test bl, bl
0000d671  7406                     je 0xd679
0000d673  41397104                 cmp dword ptr [r9 + 4], esi
0000d677  7443                     je 0xd6bc
0000d679  0faee8                   lfence
0000d67c  f048ff8ae07a5800         lock dec qword ptr [rdx + 0x587ae0]
0000d684  4983c118                 add r9, 0x18
0000d688  4d3bc2                   cmp r8, r10
0000d68b  4d0f43c8                 cmovae r9, r8
0000d68f  90                       nop
0000d690  410fb64110               movzx eax, byte ptr [r9 + 0x10]
0000d695  4d3bca                   cmp r9, r10
0000d698  0f8344ffffff             jae 0xd5e2
0000d69e  6690                     nop
0000d6a0  84c0                     test al, al
0000d6a2  0f853affffff             jne 0xd5e2
0000d6a8  4983c118                 add r9, 0x18
0000d6ac  90                       nop
0000d6ad  410fb64110               movzx eax, byte ptr [r9 + 0x10]
0000d6b2  4d3bca                   cmp r9, r10
0000d6b5  72e9                     jb 0xd6a0
0000d6b7  e926ffffff               jmp 0xd5e2
0000d6bc  48c1e920                 shr rcx, 0x20
0000d6c0  0faee8                   lfence
0000d6c3  81e1ff010000             and ecx, 0x1ff
0000d6c9  488d0449                 lea rax, [rcx + rcx*2]
0000d6cd  f048ff8cc7e07a5800       lock dec qword ptr [rdi + rax*8 + 0x587ae0]
0000d6d6  488d542470               lea rdx, [rsp + 0x70]
0000d6db  498bcb                   mov rcx, r11
0000d6de  e8bd2a0000               call 0x101a0
0000d6e3  49638b00380000           movsxd rcx, dword ptr [r11 + 0x3800]
0000d6ea  85c9                     test ecx, ecx
0000d6ec  7509                     jne 0xd6f7
0000d6ee  48c7c2ffffffff           mov rdx, 0xffffffffffffffff
0000d6f5  eb2d                     jmp 0xd724
0000d6f7  8d41ff                   lea eax, [rcx - 1]
0000d6fa  41898300380000           mov dword ptr [r11 + 0x3800], eax
0000d701  4963948bfc2f0000         movsxd rdx, dword ptr [r11 + rcx*4 + 0x2ffc]
0000d709  488d0452                 lea rax, [rdx + rdx*2]
0000d70d  41c644c31101             mov byte ptr [r11 + rax*8 + 0x11], 1
0000d713  90                       nop
0000d714  498b4cc308               mov rcx, qword ptr [r11 + rax*8 + 8]
0000d719  48c1e220                 shl rdx, 0x20
0000d71d  48c1e920                 shr rcx, 0x20
0000d721  480bd1                   or rdx, rcx
0000d724  4c895c2438               mov qword ptr [rsp + 0x38], r11
0000d729  4889542440               mov qword ptr [rsp + 0x40], rdx
0000d72e  4883faff                 cmp rdx, -1
0000d732  0f84a8000000             je 0xd7e0
0000d738  488bc2                   mov rax, rdx
0000d73b  48c1e820                 shr rax, 0x20
0000d73f  8bc8                     mov ecx, eax
0000d741  25ff010000               and eax, 0x1ff
0000d746  488d0440                 lea rax, [rax + rax*2]
0000d74a  4c8d04c500000000         lea r8, [rax*8]
0000d752  90                       nop
0000d753  470fb64c0311             movzx r9d, byte ptr [r11 + r8 + 0x11]
0000d759  90                       nop
0000d75a  4b8b440308               mov rax, qword ptr [r11 + r8 + 8]
0000d75f  48c1e820                 shr rax, 0x20
0000d763  3bc2                     cmp eax, edx
0000d765  0f8595000000             jne 0xd800
0000d76b  4584c9                   test r9b, r9b
0000d76e  0f848c000000             je 0xd800
0000d774  43892c03                 mov dword ptr [r11 + r8], ebp
0000d778  90                       nop
0000d779  470fb64c0311             movzx r9d, byte ptr [r11 + r8 + 0x11]
0000d77f  90                       nop
0000d780  4b8b440308               mov rax, qword ptr [r11 + r8 + 8]
0000d785  48c1e820                 shr rax, 0x20
0000d789  3bc2                     cmp eax, edx
0000d78b  7573                     jne 0xd800
0000d78d  4584c9                   test r9b, r9b
0000d790  746e                     je 0xd800
0000d792  4389740304               mov dword ptr [r11 + r8 + 4], esi
0000d797  488b442438               mov rax, qword ptr [rsp + 0x38]
0000d79c  90                       nop
0000d79d  460fb64c0011             movzx r9d, byte ptr [rax + r8 + 0x11]
0000d7a3  90                       nop
0000d7a4  4a8b440008               mov rax, qword ptr [rax + r8 + 8]
0000d7a9  48c1e820                 shr rax, 0x20
0000d7ad  3bc2                     cmp eax, edx
0000d7af  7519                     jne 0xd7ca
0000d7b1  4584c9                   test r9b, r9b
0000d7b4  7414                     je 0xd7ca
0000d7b6  81e1ff010000             and ecx, 0x1ff
0000d7bc  488d0c49                 lea rcx, [rcx + rcx*2]
0000d7c0  488b442438               mov rax, qword ptr [rsp + 0x38]
0000d7c5  c644c81001               mov byte ptr [rax + rcx*8 + 0x10], 1
0000d7ca  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
0000d7cf  488bac2480000000         mov rbp, qword ptr [rsp + 0x80]
0000d7d7  4883c450                 add rsp, 0x50
0000d7db  415e                     pop r14
0000d7dd  5f                       pop rdi
0000d7de  5e                       pop rsi
0000d7df  c3                       ret
0000d7e0  c744242000020000         mov dword ptr [rsp + 0x20], 0x200
0000d7e8  ba1b000000               mov edx, 0x1b
0000d7ed  b975010000               mov ecx, 0x175
0000d7f2  448d4ae6                 lea r9d, [rdx - 0x1a]
0000d7f6  448d42f5                 lea r8d, [rdx - 0xb]
0000d7fa  e841bc0000               call 0x19440
0000d7ff  cc                       int3
0000d800  ba5f000000               mov edx, 0x5f
0000d805  b94b010000               mov ecx, 0x14b
0000d80a  448d4aa2                 lea r9d, [rdx - 0x5e]
0000d80e  448d42b2                 lea r8d, [rdx - 0x4e]
0000d812  e829bc0000               call 0x19440
0000d817  cc                       int3
