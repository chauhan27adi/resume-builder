; CSqlSortAutoP<CCompressionMap<4> >::~CSqlSortAutoP<CCompressionMap<4> >
; aetm_enclave.dll, primary RVA 0x42830, 134 bytes in 5 chunk(s)

; chunk at RVA 0x42830 (30 bytes)
00042830  4889742418               mov qword ptr [rsp + 0x18], rsi
00042835  4156                     push r14
00042837  4883ec20                 sub rsp, 0x20
0004283b  488b31                   mov rsi, qword ptr [rcx]
0004283e  4c8bf1                   mov r14, rcx
00042841  4885f6                   test rsi, rsi
00042844  7464                     je 0x428aa
00042846  488b16                   mov rdx, qword ptr [rsi]
00042849  4885d2                   test rdx, rdx
0004284c  7454                     je 0x428a2

; chunk at RVA 0x4284e (12 bytes)
0004284e  48897c2438               mov qword ptr [rsp + 0x38], rdi
00042853  33ff                     xor edi, edi
00042855  397e08                   cmp dword ptr [rsi + 8], edi
00042858  763b                     jbe 0x42895

; chunk at RVA 0x4285a (59 bytes)
0004285a  48895c2430               mov qword ptr [rsp + 0x30], rbx
0004285f  90                       nop
00042860  488d0c7f                 lea rcx, [rdi + rdi*2]
00042864  488bc2                   mov rax, rdx
00042867  488b0cca                 mov rcx, qword ptr [rdx + rcx*8]
0004286b  4885c9                   test rcx, rcx
0004286e  7416                     je 0x42886
00042870  488b19                   mov rbx, qword ptr [rcx]
00042873  e8c4b70100               call 0x5e03c
00042878  488bcb                   mov rcx, rbx
0004287b  4885db                   test rbx, rbx
0004287e  75f0                     jne 0x42870
00042880  488b16                   mov rdx, qword ptr [rsi]
00042883  488bc2                   mov rax, rdx
00042886  ffc7                     inc edi
00042888  3b7e08                   cmp edi, dword ptr [rsi + 8]
0004288b  72d3                     jb 0x42860
0004288d  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00042892  488bd0                   mov rdx, rax

; chunk at RVA 0x42895 (13 bytes)
00042895  488bca                   mov rcx, rdx
00042898  e89fb70100               call 0x5e03c
0004289d  488b7c2438               mov rdi, qword ptr [rsp + 0x38]

; chunk at RVA 0x428a2 (20 bytes)
000428a2  498b0e                   mov rcx, qword ptr [r14]
000428a5  e892b70100               call 0x5e03c
000428aa  488b742440               mov rsi, qword ptr [rsp + 0x40]
000428af  4883c420                 add rsp, 0x20
000428b3  415e                     pop r14
000428b5  c3                       ret
