; CSqlSortManager_90::SpecialCaseHandler
; aetm_enclave.dll, primary RVA 0x4ec20, 4072 bytes in 1 chunk(s)

; chunk at RVA 0x4ec20 (4072 bytes)
0004ec20  48895c2418               mov qword ptr [rsp + 0x18], rbx
0004ec25  55                       push rbp
0004ec26  56                       push rsi
0004ec27  57                       push rdi
0004ec28  4154                     push r12
0004ec2a  4155                     push r13
0004ec2c  4156                     push r14
0004ec2e  4157                     push r15
0004ec30  4881ec90000000           sub rsp, 0x90
0004ec37  488b842440010000         mov rax, qword ptr [rsp + 0x140]
0004ec3f  4d8be9                   mov r13, r9
0004ec42  4c8b9c2490010000         mov r11, qword ptr [rsp + 0x190]
0004ec4a  4c8bca                   mov r9, rdx
0004ec4d  488b9c2418010000         mov rbx, qword ptr [rsp + 0x118]
0004ec55  488bac24f0000000         mov rbp, qword ptr [rsp + 0xf0]
0004ec5d  4c8bbc2408010000         mov r15, qword ptr [rsp + 0x108]
0004ec65  488bbc2410010000         mov rdi, qword ptr [rsp + 0x110]
0004ec6d  488bb42420010000         mov rsi, qword ptr [rsp + 0x120]
0004ec75  4c8bb42480010000         mov r14, qword ptr [rsp + 0x180]
0004ec7d  4c8ba42488010000         mov r12, qword ptr [rsp + 0x188]
0004ec85  4c8b942498010000         mov r10, qword ptr [rsp + 0x198]
0004ec8d  4889442468               mov qword ptr [rsp + 0x68], rax
0004ec92  8b842470010000           mov eax, dword ptr [rsp + 0x170]
0004ec99  89842488000000           mov dword ptr [rsp + 0x88], eax
0004eca0  498b4108                 mov rax, qword ptr [r9 + 8]
0004eca4  4889442458               mov qword ptr [rsp + 0x58], rax
0004eca9  410fb6c0                 movzx eax, r8b
0004ecad  ffc8                     dec eax
0004ecaf  48894c2478               mov qword ptr [rsp + 0x78], rcx
0004ecb4  488b8c2438010000         mov rcx, qword ptr [rsp + 0x138]
0004ecbc  4889542460               mov qword ptr [rsp + 0x60], rdx
0004ecc1  488b9424a0010000         mov rdx, qword ptr [rsp + 0x1a0]
0004ecc9  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
0004ecd1  4c895c2470               mov qword ptr [rsp + 0x70], r11
0004ecd6  83f80a                   cmp eax, 0xa
0004ecd9  0f87e10e0000             ja 0x4fbc0
0004ecdf  4898                     cdqe
0004ece1  4c8d051813fbff           lea r8, [rip - 0x4ece8]
0004ece8  418b8480dcfb0400         mov eax, dword ptr [r8 + rax*4 + 0x4fbdc]
0004ecf0  4903c0                   add rax, r8
0004ecf3  ffe0                     jmp rax
0004ecf5  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004ecfd  0f85bd0e0000             jne 0x4fbc0
0004ed03  498b0c24                 mov rcx, qword ptr [r12]
0004ed07  410fb64502               movzx eax, byte ptr [r13 + 2]
0004ed0c  483b8c2478010000         cmp rcx, qword ptr [rsp + 0x178]
0004ed14  7608                     jbe 0x4ed1e
0004ed16  0041ff                   add byte ptr [rcx - 1], al
0004ed19  e9a20e0000               jmp 0x4fbc0
0004ed1e  8801                     mov byte ptr [rcx], al
0004ed20  49ff0424                 inc qword ptr [r12]
0004ed24  e9970e0000               jmp 0x4fbc0
0004ed29  410fb64500               movzx eax, byte ptr [r13]
0004ed2e  4533d2                   xor r10d, r10d
0004ed31  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0004ed36  410fb78480d0a33100       movzx eax, word ptr [r8 + rax*4 + 0x31a3d0]
0004ed3f  41b807020000             mov r8d, 0x207
0004ed45  4c8d0c81                 lea r9, [rcx + rax*4]
0004ed49  410fb711                 movzx edx, word ptr [r9]
0004ed4d  44399424f8000000         cmp dword ptr [rsp + 0xf8], r10d
0004ed55  0f84ce000000             je 0x4ee29
0004ed5b  486306                   movsxd rax, dword ptr [rsi]
0004ed5e  0fb7ca                   movzx ecx, dx
0004ed61  66c1e908                 shr cx, 8
0004ed65  880c18                   mov byte ptr [rax + rbx], cl
0004ed68  48630e                   movsxd rcx, dword ptr [rsi]
0004ed6b  8d4101                   lea eax, [rcx + 1]
0004ed6e  8906                     mov dword ptr [rsi], eax
0004ed70  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004ed74  ff06                     inc dword ptr [rsi]
0004ed76  833e04                   cmp dword ptr [rsi], 4
0004ed79  0f85a4000000             jne 0x4ee23
0004ed7f  448916                   mov dword ptr [rsi], r10d
0004ed82  458b0f                   mov r9d, dword ptr [r15]
0004ed85  8b13                     mov edx, dword ptr [rbx]
0004ed87  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004ed8f  7541                     jne 0x4edd2
0004ed91  41c1c103                 rol r9d, 3
0004ed95  4133d1                   xor edx, r9d
0004ed98  418917                   mov dword ptr [r15], edx
0004ed9b  6644394302               cmp word ptr [rbx + 2], r8w
0004eda0  740b                     je 0x4edad
0004eda2  8917                     mov dword ptr [rdi], edx
0004eda4  66ff4500                 inc word ptr [rbp]
0004eda8  e9ba000000               jmp 0x4ee67
0004edad  0fb703                   movzx eax, word ptr [rbx]
0004edb0  66413bc0                 cmp ax, r8w
0004edb4  746d                     je 0x4ee23
0004edb6  0fb6c8                   movzx ecx, al
0004edb9  4133c9                   xor ecx, r9d
0004edbc  890f                     mov dword ptr [rdi], ecx
0004edbe  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004edc2  c1c103                   rol ecx, 3
0004edc5  33c8                     xor ecx, eax
0004edc7  890f                     mov dword ptr [rdi], ecx
0004edc9  66ff4500                 inc word ptr [rbp]
0004edcd  e995000000               jmp 0x4ee67
0004edd2  4169c920080000           imul ecx, r9d, 0x820
0004edd9  418bc1                   mov eax, r9d
0004eddc  c1e802                   shr eax, 2
0004eddf  03c8                     add ecx, eax
0004ede1  8d040a                   lea eax, [rdx + rcx]
0004ede4  4133c1                   xor eax, r9d
0004ede7  418907                   mov dword ptr [r15], eax
0004edea  6644394302               cmp word ptr [rbx + 2], r8w
0004edef  7408                     je 0x4edf9
0004edf1  8907                     mov dword ptr [rdi], eax
0004edf3  66ff4500                 inc word ptr [rbp]
0004edf7  eb6e                     jmp 0x4ee67
0004edf9  0fb703                   movzx eax, word ptr [rbx]
0004edfc  66413bc0                 cmp ax, r8w
0004ee00  7421                     je 0x4ee23
0004ee02  0fb6d0                   movzx edx, al
0004ee05  03d1                     add edx, ecx
0004ee07  4133d1                   xor edx, r9d
0004ee0a  69c220080000             imul eax, edx, 0x820
0004ee10  8917                     mov dword ptr [rdi], edx
0004ee12  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004ee16  03c8                     add ecx, eax
0004ee18  8bc2                     mov eax, edx
0004ee1a  c1e802                   shr eax, 2
0004ee1d  03c8                     add ecx, eax
0004ee1f  33ca                     xor ecx, edx
0004ee21  890f                     mov dword ptr [rdi], ecx
0004ee23  66ff4500                 inc word ptr [rbp]
0004ee27  eb3e                     jmp 0x4ee67
0004ee29  498b06                   mov rax, qword ptr [r14]
0004ee2c  66c1ea08                 shr dx, 8
0004ee30  8810                     mov byte ptr [rax], dl
0004ee32  49ff06                   inc qword ptr [r14]
0004ee35  410fb601                 movzx eax, byte ptr [r9]
0004ee39  498b0e                   mov rcx, qword ptr [r14]
0004ee3c  8801                     mov byte ptr [rcx], al
0004ee3e  49ff06                   inc qword ptr [r14]
0004ee41  498b0c24                 mov rcx, qword ptr [r12]
0004ee45  410fb64102               movzx eax, byte ptr [r9 + 2]
0004ee4a  8801                     mov byte ptr [rcx], al
0004ee4c  49ff0424                 inc qword ptr [r12]
0004ee50  410fb64903               movzx ecx, byte ptr [r9 + 3]
0004ee55  498b03                   mov rax, qword ptr [r11]
0004ee58  228c2460010000           and cl, byte ptr [rsp + 0x160]
0004ee5f  80e13f                   and cl, 0x3f
0004ee62  8808                     mov byte ptr [rax], cl
0004ee64  49ff03                   inc qword ptr [r11]
0004ee67  410fb64500               movzx eax, byte ptr [r13]
0004ee6c  488d0d8d11fbff           lea rcx, [rip - 0x4ee73]
0004ee73  0fb78481d2a33100         movzx eax, word ptr [rcx + rax*4 + 0x31a3d2]
0004ee7b  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0004ee80  440fb70c81               movzx r9d, word ptr [rcx + rax*4]
0004ee85  488d1481                 lea rdx, [rcx + rax*4]
0004ee89  410fb7c1                 movzx eax, r9w
0004ee8d  66c1e808                 shr ax, 8
0004ee91  3c02                     cmp al, 2
0004ee93  0f8578010000             jne 0x4f011
0004ee99  0f1f8000000000           nop dword ptr [rax]
0004eea0  8b02                     mov eax, dword ptr [rdx]
0004eea2  0fb6c8                   movzx ecx, al
0004eea5  41894500                 mov dword ptr [r13], eax
0004eea9  488d055011fbff           lea rax, [rip - 0x4eeb0]
0004eeb0  0fb78488d0a33100         movzx eax, word ptr [rax + rcx*4 + 0x31a3d0]
0004eeb8  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0004eebd  4c8d0c81                 lea r9, [rcx + rax*4]
0004eec1  410fb711                 movzx edx, word ptr [r9]
0004eec5  44399424f8000000         cmp dword ptr [rsp + 0xf8], r10d
0004eecd  0f84ce000000             je 0x4efa1
0004eed3  486306                   movsxd rax, dword ptr [rsi]
0004eed6  0fb7ca                   movzx ecx, dx
0004eed9  66c1e908                 shr cx, 8
0004eedd  880c18                   mov byte ptr [rax + rbx], cl
0004eee0  48630e                   movsxd rcx, dword ptr [rsi]
0004eee3  8d4101                   lea eax, [rcx + 1]
0004eee6  8906                     mov dword ptr [rsi], eax
0004eee8  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004eeec  ff06                     inc dword ptr [rsi]
0004eeee  833e04                   cmp dword ptr [rsi], 4
0004eef1  0f85a4000000             jne 0x4ef9b
0004eef7  448916                   mov dword ptr [rsi], r10d
0004eefa  458b0f                   mov r9d, dword ptr [r15]
0004eefd  8b13                     mov edx, dword ptr [rbx]
0004eeff  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004ef07  7541                     jne 0x4ef4a
0004ef09  41c1c103                 rol r9d, 3
0004ef0d  4133d1                   xor edx, r9d
0004ef10  418917                   mov dword ptr [r15], edx
0004ef13  6644394302               cmp word ptr [rbx + 2], r8w
0004ef18  740b                     je 0x4ef25
0004ef1a  8917                     mov dword ptr [rdi], edx
0004ef1c  66ff4500                 inc word ptr [rbp]
0004ef20  e9ba000000               jmp 0x4efdf
0004ef25  0fb703                   movzx eax, word ptr [rbx]
0004ef28  66413bc0                 cmp ax, r8w
0004ef2c  746d                     je 0x4ef9b
0004ef2e  0fb6c8                   movzx ecx, al
0004ef31  4133c9                   xor ecx, r9d
0004ef34  890f                     mov dword ptr [rdi], ecx
0004ef36  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004ef3a  c1c103                   rol ecx, 3
0004ef3d  33c8                     xor ecx, eax
0004ef3f  890f                     mov dword ptr [rdi], ecx
0004ef41  66ff4500                 inc word ptr [rbp]
0004ef45  e995000000               jmp 0x4efdf
0004ef4a  4169c920080000           imul ecx, r9d, 0x820
0004ef51  418bc1                   mov eax, r9d
0004ef54  c1e802                   shr eax, 2
0004ef57  03c8                     add ecx, eax
0004ef59  8d040a                   lea eax, [rdx + rcx]
0004ef5c  4133c1                   xor eax, r9d
0004ef5f  418907                   mov dword ptr [r15], eax
0004ef62  6644394302               cmp word ptr [rbx + 2], r8w
0004ef67  7408                     je 0x4ef71
0004ef69  8907                     mov dword ptr [rdi], eax
0004ef6b  66ff4500                 inc word ptr [rbp]
0004ef6f  eb6e                     jmp 0x4efdf
0004ef71  0fb703                   movzx eax, word ptr [rbx]
0004ef74  66413bc0                 cmp ax, r8w
0004ef78  7421                     je 0x4ef9b
0004ef7a  0fb6d0                   movzx edx, al
0004ef7d  03d1                     add edx, ecx
0004ef7f  4133d1                   xor edx, r9d
0004ef82  69c220080000             imul eax, edx, 0x820
0004ef88  8917                     mov dword ptr [rdi], edx
0004ef8a  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004ef8e  03c8                     add ecx, eax
0004ef90  8bc2                     mov eax, edx
0004ef92  c1e802                   shr eax, 2
0004ef95  03c8                     add ecx, eax
0004ef97  33ca                     xor ecx, edx
0004ef99  890f                     mov dword ptr [rdi], ecx
0004ef9b  66ff4500                 inc word ptr [rbp]
0004ef9f  eb3e                     jmp 0x4efdf
0004efa1  498b06                   mov rax, qword ptr [r14]
0004efa4  66c1ea08                 shr dx, 8
0004efa8  8810                     mov byte ptr [rax], dl
0004efaa  49ff06                   inc qword ptr [r14]
0004efad  410fb601                 movzx eax, byte ptr [r9]
0004efb1  498b0e                   mov rcx, qword ptr [r14]
0004efb4  8801                     mov byte ptr [rcx], al
0004efb6  49ff06                   inc qword ptr [r14]
0004efb9  498b0c24                 mov rcx, qword ptr [r12]
0004efbd  410fb64102               movzx eax, byte ptr [r9 + 2]
0004efc2  8801                     mov byte ptr [rcx], al
0004efc4  49ff0424                 inc qword ptr [r12]
0004efc8  410fb64903               movzx ecx, byte ptr [r9 + 3]
0004efcd  498b03                   mov rax, qword ptr [r11]
0004efd0  228c2460010000           and cl, byte ptr [rsp + 0x160]
0004efd7  80e13f                   and cl, 0x3f
0004efda  8808                     mov byte ptr [rax], cl
0004efdc  49ff03                   inc qword ptr [r11]
0004efdf  410fb64500               movzx eax, byte ptr [r13]
0004efe4  488d0d1510fbff           lea rcx, [rip - 0x4efeb]
0004efeb  0fb78481d2a33100         movzx eax, word ptr [rcx + rax*4 + 0x31a3d2]
0004eff3  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0004eff8  440fb70c81               movzx r9d, word ptr [rcx + rax*4]
0004effd  488d1481                 lea rdx, [rcx + rax*4]
0004f001  410fb7c1                 movzx eax, r9w
0004f005  66c1e808                 shr ax, 8
0004f009  3c02                     cmp al, 2
0004f00b  0f848ffeffff             je 0x4eea0
0004f011  44399424f8000000         cmp dword ptr [rsp + 0xf8], r10d
0004f019  7433                     je 0x4f04e
0004f01b  486306                   movsxd rax, dword ptr [rsi]
0004f01e  410fb7c9                 movzx ecx, r9w
0004f022  66c1e908                 shr cx, 8
0004f026  880c18                   mov byte ptr [rax + rbx], cl
0004f029  48630e                   movsxd rcx, dword ptr [rsi]
0004f02c  8d4101                   lea eax, [rcx + 1]
0004f02f  8906                     mov dword ptr [rsi], eax
0004f031  44884c1901               mov byte ptr [rcx + rbx + 1], r9b
0004f036  ff06                     inc dword ptr [rsi]
0004f038  833e04                   cmp dword ptr [rsi], 4
0004f03b  0f85f00a0000             jne 0x4fb31
0004f041  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004f049  e9410a0000               jmp 0x4fa8f
0004f04e  498b06                   mov rax, qword ptr [r14]
0004f051  6641c1e908               shr r9w, 8
0004f056  448808                   mov byte ptr [rax], r9b
0004f059  49ff06                   inc qword ptr [r14]
0004f05c  0fb602                   movzx eax, byte ptr [rdx]
0004f05f  498b0e                   mov rcx, qword ptr [r14]
0004f062  8801                     mov byte ptr [rcx], al
0004f064  49ff06                   inc qword ptr [r14]
0004f067  498b0c24                 mov rcx, qword ptr [r12]
0004f06b  0fb64202                 movzx eax, byte ptr [rdx + 2]
0004f06f  8801                     mov byte ptr [rcx], al
0004f071  49ff0424                 inc qword ptr [r12]
0004f075  0fb64a03                 movzx ecx, byte ptr [rdx + 3]
0004f079  498b03                   mov rax, qword ptr [r11]
0004f07c  228c2460010000           and cl, byte ptr [rsp + 0x160]
0004f083  80e13f                   and cl, 0x3f
0004f086  8808                     mov byte ptr [rax], cl
0004f088  e9300b0000               jmp 0x4fbbd
0004f08d  83bc242801000000         cmp dword ptr [rsp + 0x128], 0
0004f095  7551                     jne 0x4f0e8
0004f097  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f09f  0f851b0b0000             jne 0x4fbc0
0004f0a5  0fb74d00                 movzx ecx, word ptr [rbp]
0004f0a9  488b02                   mov rax, qword ptr [rdx]
0004f0ac  66c1e906                 shr cx, 6
0004f0b0  80c980                   or cl, 0x80
0004f0b3  8808                     mov byte ptr [rax], cl
0004f0b5  48ff02                   inc qword ptr [rdx]
0004f0b8  0fb64500                 movzx eax, byte ptr [rbp]
0004f0bc  488b0a                   mov rcx, qword ptr [rdx]
0004f0bf  c0e002                   shl al, 2
0004f0c2  0c03                     or al, 3
0004f0c4  8801                     mov byte ptr [rcx], al
0004f0c6  48ff02                   inc qword ptr [rdx]
0004f0c9  488b0a                   mov rcx, qword ptr [rdx]
0004f0cc  410fb64501               movzx eax, byte ptr [r13 + 1]
0004f0d1  8801                     mov byte ptr [rcx], al
0004f0d3  48ff02                   inc qword ptr [rdx]
0004f0d6  488b0a                   mov rcx, qword ptr [rdx]
0004f0d9  410fb64500               movzx eax, byte ptr [r13]
0004f0de  8801                     mov byte ptr [rcx], al
0004f0e0  48ff02                   inc qword ptr [rdx]
0004f0e3  e9d80a0000               jmp 0x4fbc0
0004f0e8  83bc243001000000         cmp dword ptr [rsp + 0x130], 0
0004f0f0  0f85ca0a0000             jne 0x4fbc0
0004f0f6  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f0fe  410fb75500               movzx edx, word ptr [r13]
0004f103  743a                     je 0x4f13f
0004f105  486306                   movsxd rax, dword ptr [rsi]
0004f108  0fb7ca                   movzx ecx, dx
0004f10b  66c1e908                 shr cx, 8
0004f10f  880c18                   mov byte ptr [rax + rbx], cl
0004f112  48630e                   movsxd rcx, dword ptr [rsi]
0004f115  8d4101                   lea eax, [rcx + 1]
0004f118  8906                     mov dword ptr [rsi], eax
0004f11a  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f11e  ff06                     inc dword ptr [rsi]
0004f120  833e04                   cmp dword ptr [rsi], 4
0004f123  0f85080a0000             jne 0x4fb31
0004f129  4533d2                   xor r10d, r10d
0004f12c  41b807020000             mov r8d, 0x207
0004f132  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004f13a  e950090000               jmp 0x4fa8f
0004f13f  498b06                   mov rax, qword ptr [r14]
0004f142  66c1ea08                 shr dx, 8
0004f146  8810                     mov byte ptr [rax], dl
0004f148  49ff06                   inc qword ptr [r14]
0004f14b  410fb64500               movzx eax, byte ptr [r13]
0004f150  498b0e                   mov rcx, qword ptr [r14]
0004f153  8801                     mov byte ptr [rcx], al
0004f155  49ff06                   inc qword ptr [r14]
0004f158  498b0c24                 mov rcx, qword ptr [r12]
0004f15c  410fb64502               movzx eax, byte ptr [r13 + 2]
0004f161  8801                     mov byte ptr [rcx], al
0004f163  49ff0424                 inc qword ptr [r12]
0004f167  410fb64d03               movzx ecx, byte ptr [r13 + 3]
0004f16c  498b03                   mov rax, qword ptr [r11]
0004f16f  228c2460010000           and cl, byte ptr [rsp + 0x160]
0004f176  80e13f                   and cl, 0x3f
0004f179  8808                     mov byte ptr [rax], cl
0004f17b  e93d0a0000               jmp 0x4fbbd
0004f180  450fb64500               movzx r8d, byte ptr [r13]
0004f185  410fb65503               movzx edx, byte ptr [r13 + 3]
0004f18a  22942460010000           and dl, byte ptr [rsp + 0x160]
0004f191  80cac4                   or dl, 0xc4
0004f194  4488442450               mov byte ptr [rsp + 0x50], r8b
0004f199  88542454                 mov byte ptr [rsp + 0x54], dl
0004f19d  4180f801                 cmp r8b, 1
0004f1a1  0f87e8010000             ja 0x4f38f
0004f1a7  488b09                   mov rcx, qword ptr [rcx]
0004f1aa  4883e902                 sub rcx, 2
0004f1ae  483b8c2448010000         cmp rcx, qword ptr [rsp + 0x148]
0004f1b6  722b                     jb 0x4f1e3
0004f1b8  0f1f840000000000         nop dword ptr [rax + rax]
0004f1c0  0fb701                   movzx eax, word ptr [rcx]
0004f1c3  4c8b442458               mov r8, qword ptr [rsp + 0x58]
0004f1c8  458b0480                 mov r8d, dword ptr [r8 + rax*4]
0004f1cc  458bc8                   mov r9d, r8d
0004f1cf  410fb7c0                 movzx eax, r8w
0004f1d3  41c1e918                 shr r9d, 0x18
0004f1d7  66c1e808                 shr ax, 8
0004f1db  3c03                     cmp al, 3
0004f1dd  7347                     jae 0x4f226
0004f1df  3c02                     cmp al, 2
0004f1e1  754f                     jne 0x4f232
0004f1e3  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f1eb  0f8487010000             je 0x4f378
0004f1f1  486306                   movsxd rax, dword ptr [rsi]
0004f1f4  c60418ff                 mov byte ptr [rax + rbx], 0xff
0004f1f8  48630e                   movsxd rcx, dword ptr [rsi]
0004f1fb  8d4101                   lea eax, [rcx + 1]
0004f1fe  8906                     mov dword ptr [rsi], eax
0004f200  c6441901ff               mov byte ptr [rcx + rbx + 1], 0xff
0004f205  ff06                     inc dword ptr [rsi]
0004f207  833e04                   cmp dword ptr [rsi], 4
0004f20a  0f8521090000             jne 0x4fb31
0004f210  4533d2                   xor r10d, r10d
0004f213  41b807020000             mov r8d, 0x207
0004f219  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004f221  e969080000               jmp 0x4fa8f
0004f226  0f85f3000000             jne 0x4f31f
0004f22c  4180f801                 cmp r8b, 1
0004f230  7710                     ja 0x4f242
0004f232  4883c1fe                 add rcx, -2
0004f236  483b8c2448010000         cmp rcx, qword ptr [rsp + 0x148]
0004f23e  7380                     jae 0x4f1c0
0004f240  eba1                     jmp 0x4f1e3
0004f242  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004f24a  0fb6842458010000         movzx eax, byte ptr [rsp + 0x158]
0004f252  450fb6c0                 movzx r8d, r8b
0004f256  740c                     je 0x4f264
0004f258  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
0004f25d  0fb64c0848               movzx ecx, byte ptr [rax + rcx + 0x48]
0004f262  eb03                     jmp 0x4f267
0004f264  0fb7c8                   movzx ecx, ax
0004f267  44228c2460010000         and r9b, byte ptr [rsp + 0x160]
0004f26f  8b8424f8000000           mov eax, dword ptr [rsp + 0xf8]
0004f276  4180c9c4                 or r9b, 0xc4
0004f27a  66c1e108                 shl cx, 8
0004f27e  66440bc1                 or r8w, cx
0004f282  85c0                     test eax, eax
0004f284  7531                     jne 0x4f2b7
0004f286  498b02                   mov rax, qword ptr [r10]
0004f289  410fb6c9                 movzx ecx, r9b
0004f28d  80e1c6                   and cl, 0xc6
0004f290  410fb6d1                 movzx edx, r9b
0004f294  80e2e4                   and dl, 0xe4
0004f297  8808                     mov byte ptr [rax], cl
0004f299  8b842488000000           mov eax, dword ptr [rsp + 0x88]
0004f2a0  03c0                     add eax, eax
0004f2a2  4863c8                   movsxd rcx, eax
0004f2a5  498b02                   mov rax, qword ptr [r10]
0004f2a8  881401                   mov byte ptr [rcx + rax], dl
0004f2ab  0fb6542454               movzx edx, byte ptr [rsp + 0x54]
0004f2b0  8b8424f8000000           mov eax, dword ptr [rsp + 0xf8]
0004f2b7  807c245000               cmp byte ptr [rsp + 0x50], 0
0004f2bc  7531                     jne 0x4f2ef
0004f2be  85c0                     test eax, eax
0004f2c0  755d                     jne 0x4f31f
0004f2c2  498b02                   mov rax, qword ptr [r10]
0004f2c5  4180e1c5                 and r9b, 0xc5
0004f2c9  4863942488000000         movsxd rdx, dword ptr [rsp + 0x88]
0004f2d1  c6040204                 mov byte ptr [rdx + rax], 4
0004f2d5  8d0452                   lea eax, [rdx + rdx*2]
0004f2d8  4863c8                   movsxd rcx, eax
0004f2db  498b02                   mov rax, qword ptr [r10]
0004f2de  44880c01                 mov byte ptr [rcx + rax], r9b
0004f2e2  8b8424f8000000           mov eax, dword ptr [rsp + 0xf8]
0004f2e9  85c0                     test eax, eax
0004f2eb  7532                     jne 0x4f31f
0004f2ed  eb2d                     jmp 0x4f31c
0004f2ef  b987ff0000               mov ecx, 0xff87
0004f2f4  664423c1                 and r8w, cx
0004f2f8  85c0                     test eax, eax
0004f2fa  7523                     jne 0x4f31f
0004f2fc  498b02                   mov rax, qword ptr [r10]
0004f2ff  80e2c5                   and dl, 0xc5
0004f302  4c638c2488000000         movsxd r9, dword ptr [rsp + 0x88]
0004f30a  41c6040105               mov byte ptr [r9 + rax], 5
0004f30f  438d0449                 lea eax, [r9 + r9*2]
0004f313  4863c8                   movsxd rcx, eax
0004f316  498b02                   mov rax, qword ptr [r10]
0004f319  881401                   mov byte ptr [rcx + rax], dl
0004f31c  49ff02                   inc qword ptr [r10]
0004f31f  b8ffff0000               mov eax, 0xffff
0004f324  66443bc0                 cmp r8w, ax
0004f328  0f84b5feffff             je 0x4f1e3
0004f32e  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f336  0f84d3000000             je 0x4f40f
0004f33c  486306                   movsxd rax, dword ptr [rsi]
0004f33f  410fb7c8                 movzx ecx, r8w
0004f343  66c1e908                 shr cx, 8
0004f347  880c18                   mov byte ptr [rax + rbx], cl
0004f34a  48630e                   movsxd rcx, dword ptr [rsi]
0004f34d  8d4101                   lea eax, [rcx + 1]
0004f350  8906                     mov dword ptr [rsi], eax
0004f352  4488441901               mov byte ptr [rcx + rbx + 1], r8b
0004f357  ff06                     inc dword ptr [rsi]
0004f359  833e04                   cmp dword ptr [rsi], 4
0004f35c  0f85cf070000             jne 0x4fb31
0004f362  4533d2                   xor r10d, r10d
0004f365  41b807020000             mov r8d, 0x207
0004f36b  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004f373  e917070000               jmp 0x4fa8f
0004f378  498b06                   mov rax, qword ptr [r14]
0004f37b  c600ff                   mov byte ptr [rax], 0xff
0004f37e  49ff06                   inc qword ptr [r14]
0004f381  498b06                   mov rax, qword ptr [r14]
0004f384  c600ff                   mov byte ptr [rax], 0xff
0004f387  49ff06                   inc qword ptr [r14]
0004f38a  e931080000               jmp 0x4fbc0
0004f38f  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004f397  0fb6842458010000         movzx eax, byte ptr [rsp + 0x158]
0004f39f  7408                     je 0x4f3a9
0004f3a1  460fb64c0848             movzx r9d, byte ptr [rax + r9 + 0x48]
0004f3a7  eb04                     jmp 0x4f3ad
0004f3a9  440fb7c8                 movzx r9d, ax
0004f3ad  6641c1e108               shl r9w, 8
0004f3b2  66450bc8                 or r9w, r8w
0004f3b6  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f3be  450fb7c1                 movzx r8d, r9w
0004f3c2  0f8574ffffff             jne 0x4f33c
0004f3c8  498b02                   mov rax, qword ptr [r10]
0004f3cb  0fb6ca                   movzx ecx, dl
0004f3ce  4c63842488000000         movsxd r8, dword ptr [rsp + 0x88]
0004f3d6  80e1c6                   and cl, 0xc6
0004f3d9  80e2e4                   and dl, 0xe4
0004f3dc  8808                     mov byte ptr [rax], cl
0004f3de  498b02                   mov rax, qword ptr [r10]
0004f3e1  41c6040003               mov byte ptr [r8 + rax], 3
0004f3e6  438d0400                 lea eax, [r8 + r8]
0004f3ea  4863c8                   movsxd rcx, eax
0004f3ed  498b02                   mov rax, qword ptr [r10]
0004f3f0  881401                   mov byte ptr [rcx + rax], dl
0004f3f3  438d0440                 lea eax, [r8 + r8*2]
0004f3f7  0fb6542454               movzx edx, byte ptr [rsp + 0x54]
0004f3fc  450fb7c1                 movzx r8d, r9w
0004f400  4863c8                   movsxd rcx, eax
0004f403  80e2c5                   and dl, 0xc5
0004f406  498b02                   mov rax, qword ptr [r10]
0004f409  881401                   mov byte ptr [rcx + rax], dl
0004f40c  49ff02                   inc qword ptr [r10]
0004f40f  498b06                   mov rax, qword ptr [r14]
0004f412  410fb7c8                 movzx ecx, r8w
0004f416  66c1e908                 shr cx, 8
0004f41a  8808                     mov byte ptr [rax], cl
0004f41c  49ff06                   inc qword ptr [r14]
0004f41f  498b06                   mov rax, qword ptr [r14]
0004f422  448800                   mov byte ptr [rax], r8b
0004f425  49ff06                   inc qword ptr [r14]
0004f428  410fb64502               movzx eax, byte ptr [r13 + 2]
0004f42d  498b0c24                 mov rcx, qword ptr [r12]
0004f431  8801                     mov byte ptr [rcx], al
0004f433  49ff0424                 inc qword ptr [r12]
0004f437  498b03                   mov rax, qword ptr [r11]
0004f43a  c60002                   mov byte ptr [rax], 2
0004f43d  e97b070000               jmp 0x4fbbd
0004f442  4c8b01                   mov r8, qword ptr [rcx]
0004f445  b860110000               mov eax, 0x1160
0004f44a  66413900                 cmp word ptr [r8], ax
0004f44e  0f8361040000             jae 0x4f8b5
0004f454  488b442468               mov rax, qword ptr [rsp + 0x68]
0004f459  448b8c2450010000         mov r9d, dword ptr [rsp + 0x150]
0004f461  488b542460               mov rdx, qword ptr [rsp + 0x60]
0004f466  488b4c2478               mov rcx, qword ptr [rsp + 0x78]
0004f46b  442b08                   sub r9d, dword ptr [rax]
0004f46e  488d442454               lea rax, [rsp + 0x54]
0004f473  4889442438               mov qword ptr [rsp + 0x38], rax
0004f478  41ffc1                   inc r9d
0004f47b  488d842488000000         lea rax, [rsp + 0x88]
0004f483  c744243003000000         mov dword ptr [rsp + 0x30], 3
0004f48b  4889442428               mov qword ptr [rsp + 0x28], rax
0004f490  488d442450               lea rax, [rsp + 0x50]
0004f495  4889442420               mov qword ptr [rsp + 0x20], rax
0004f49a  e891180000               call 0x50d30
0004f49f  448bd8                   mov r11d, eax
0004f4a2  85c0                     test eax, eax
0004f4a4  0f8e01040000             jle 0x4f8ab
0004f4aa  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f4b2  0f842e030000             je 0x4f7e6
0004f4b8  48630e                   movsxd rcx, dword ptr [rsi]
0004f4bb  4533d2                   xor r10d, r10d
0004f4be  440fb7442450             movzx r8d, word ptr [rsp + 0x50]
0004f4c4  448bb42400010000         mov r14d, dword ptr [rsp + 0x100]
0004f4cc  410fb7d0                 movzx edx, r8w
0004f4d0  66c1ea08                 shr dx, 8
0004f4d4  881419                   mov byte ptr [rcx + rbx], dl
0004f4d7  48630e                   movsxd rcx, dword ptr [rsi]
0004f4da  8d4101                   lea eax, [rcx + 1]
0004f4dd  8906                     mov dword ptr [rsi], eax
0004f4df  4488441901               mov byte ptr [rcx + rbx + 1], r8b
0004f4e4  41b807020000             mov r8d, 0x207
0004f4ea  ff06                     inc dword ptr [rsi]
0004f4ec  833e04                   cmp dword ptr [rsi], 4
0004f4ef  0f858b000000             jne 0x4f580
0004f4f5  448916                   mov dword ptr [rsi], r10d
0004f4f8  458b0f                   mov r9d, dword ptr [r15]
0004f4fb  8b13                     mov edx, dword ptr [rbx]
0004f4fd  4585f6                   test r14d, r14d
0004f500  7531                     jne 0x4f533
0004f502  41c1c103                 rol r9d, 3
0004f506  4133d1                   xor edx, r9d
0004f509  418917                   mov dword ptr [r15], edx
0004f50c  6644394302               cmp word ptr [rbx + 2], r8w
0004f511  7404                     je 0x4f517
0004f513  8917                     mov dword ptr [rdi], edx
0004f515  eb69                     jmp 0x4f580
0004f517  0fb703                   movzx eax, word ptr [rbx]
0004f51a  66413bc0                 cmp ax, r8w
0004f51e  7460                     je 0x4f580
0004f520  0fb6c8                   movzx ecx, al
0004f523  4133c9                   xor ecx, r9d
0004f526  890f                     mov dword ptr [rdi], ecx
0004f528  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f52c  c1c103                   rol ecx, 3
0004f52f  33c8                     xor ecx, eax
0004f531  eb4b                     jmp 0x4f57e
0004f533  4169c920080000           imul ecx, r9d, 0x820
0004f53a  418bc1                   mov eax, r9d
0004f53d  c1e802                   shr eax, 2
0004f540  03c8                     add ecx, eax
0004f542  8d040a                   lea eax, [rdx + rcx]
0004f545  4133c1                   xor eax, r9d
0004f548  418907                   mov dword ptr [r15], eax
0004f54b  6644394302               cmp word ptr [rbx + 2], r8w
0004f550  7404                     je 0x4f556
0004f552  8907                     mov dword ptr [rdi], eax
0004f554  eb2a                     jmp 0x4f580
0004f556  0fb703                   movzx eax, word ptr [rbx]
0004f559  66413bc0                 cmp ax, r8w
0004f55d  7421                     je 0x4f580
0004f55f  0fb6d0                   movzx edx, al
0004f562  03d1                     add edx, ecx
0004f564  4133d1                   xor edx, r9d
0004f567  69c220080000             imul eax, edx, 0x820
0004f56d  8917                     mov dword ptr [rdi], edx
0004f56f  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004f573  03c8                     add ecx, eax
0004f575  8bc2                     mov eax, edx
0004f577  c1e802                   shr eax, 2
0004f57a  03c8                     add ecx, eax
0004f57c  33ca                     xor ecx, edx
0004f57e  890f                     mov dword ptr [rdi], ecx
0004f580  66ff4500                 inc word ptr [rbp]
0004f584  41bd00ff0000             mov r13d, 0xff00
0004f58a  486306                   movsxd rax, dword ptr [rsi]
0004f58d  0fb6942488000000         movzx edx, byte ptr [rsp + 0x88]
0004f595  66410bd5                 or dx, r13w
0004f599  0fb7ca                   movzx ecx, dx
0004f59c  66c1e908                 shr cx, 8
0004f5a0  880c18                   mov byte ptr [rax + rbx], cl
0004f5a3  48630e                   movsxd rcx, dword ptr [rsi]
0004f5a6  8d4101                   lea eax, [rcx + 1]
0004f5a9  8906                     mov dword ptr [rsi], eax
0004f5ab  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f5af  ff06                     inc dword ptr [rsi]
0004f5b1  833e04                   cmp dword ptr [rsi], 4
0004f5b4  0f858b000000             jne 0x4f645
0004f5ba  448916                   mov dword ptr [rsi], r10d
0004f5bd  458b0f                   mov r9d, dword ptr [r15]
0004f5c0  8b13                     mov edx, dword ptr [rbx]
0004f5c2  4585f6                   test r14d, r14d
0004f5c5  7531                     jne 0x4f5f8
0004f5c7  41c1c103                 rol r9d, 3
0004f5cb  4133d1                   xor edx, r9d
0004f5ce  418917                   mov dword ptr [r15], edx
0004f5d1  6644394302               cmp word ptr [rbx + 2], r8w
0004f5d6  7404                     je 0x4f5dc
0004f5d8  8917                     mov dword ptr [rdi], edx
0004f5da  eb69                     jmp 0x4f645
0004f5dc  0fb703                   movzx eax, word ptr [rbx]
0004f5df  66413bc0                 cmp ax, r8w
0004f5e3  7460                     je 0x4f645
0004f5e5  0fb6c8                   movzx ecx, al
0004f5e8  4133c9                   xor ecx, r9d
0004f5eb  890f                     mov dword ptr [rdi], ecx
0004f5ed  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f5f1  c1c103                   rol ecx, 3
0004f5f4  33c8                     xor ecx, eax
0004f5f6  eb4b                     jmp 0x4f643
0004f5f8  4169c920080000           imul ecx, r9d, 0x820
0004f5ff  418bc1                   mov eax, r9d
0004f602  c1e802                   shr eax, 2
0004f605  03c8                     add ecx, eax
0004f607  8d040a                   lea eax, [rdx + rcx]
0004f60a  4133c1                   xor eax, r9d
0004f60d  418907                   mov dword ptr [r15], eax
0004f610  6644394302               cmp word ptr [rbx + 2], r8w
0004f615  7404                     je 0x4f61b
0004f617  8907                     mov dword ptr [rdi], eax
0004f619  eb2a                     jmp 0x4f645
0004f61b  0fb703                   movzx eax, word ptr [rbx]
0004f61e  66413bc0                 cmp ax, r8w
0004f622  7421                     je 0x4f645
0004f624  0fb6d0                   movzx edx, al
0004f627  03d1                     add edx, ecx
0004f629  4133d1                   xor edx, r9d
0004f62c  69c220080000             imul eax, edx, 0x820
0004f632  8917                     mov dword ptr [rdi], edx
0004f634  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004f638  03c8                     add ecx, eax
0004f63a  8bc2                     mov eax, edx
0004f63c  c1e802                   shr eax, 2
0004f63f  03c8                     add ecx, eax
0004f641  33ca                     xor ecx, edx
0004f643  890f                     mov dword ptr [rdi], ecx
0004f645  66ff4500                 inc word ptr [rbp]
0004f649  486306                   movsxd rax, dword ptr [rsi]
0004f64c  0fb6942489000000         movzx edx, byte ptr [rsp + 0x89]
0004f654  66410bd5                 or dx, r13w
0004f658  0fb7ca                   movzx ecx, dx
0004f65b  66c1e908                 shr cx, 8
0004f65f  880c18                   mov byte ptr [rax + rbx], cl
0004f662  48630e                   movsxd rcx, dword ptr [rsi]
0004f665  8d4101                   lea eax, [rcx + 1]
0004f668  8906                     mov dword ptr [rsi], eax
0004f66a  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f66e  ff06                     inc dword ptr [rsi]
0004f670  833e04                   cmp dword ptr [rsi], 4
0004f673  0f858b000000             jne 0x4f704
0004f679  448916                   mov dword ptr [rsi], r10d
0004f67c  458b0f                   mov r9d, dword ptr [r15]
0004f67f  8b13                     mov edx, dword ptr [rbx]
0004f681  4585f6                   test r14d, r14d
0004f684  7531                     jne 0x4f6b7
0004f686  41c1c103                 rol r9d, 3
0004f68a  4133d1                   xor edx, r9d
0004f68d  418917                   mov dword ptr [r15], edx
0004f690  6644394302               cmp word ptr [rbx + 2], r8w
0004f695  7404                     je 0x4f69b
0004f697  8917                     mov dword ptr [rdi], edx
0004f699  eb69                     jmp 0x4f704
0004f69b  0fb703                   movzx eax, word ptr [rbx]
0004f69e  66413bc0                 cmp ax, r8w
0004f6a2  7460                     je 0x4f704
0004f6a4  0fb6c8                   movzx ecx, al
0004f6a7  4133c9                   xor ecx, r9d
0004f6aa  890f                     mov dword ptr [rdi], ecx
0004f6ac  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f6b0  c1c103                   rol ecx, 3
0004f6b3  33c8                     xor ecx, eax
0004f6b5  eb4b                     jmp 0x4f702
0004f6b7  4169c920080000           imul ecx, r9d, 0x820
0004f6be  418bc1                   mov eax, r9d
0004f6c1  c1e802                   shr eax, 2
0004f6c4  03c8                     add ecx, eax
0004f6c6  8d040a                   lea eax, [rdx + rcx]
0004f6c9  4133c1                   xor eax, r9d
0004f6cc  418907                   mov dword ptr [r15], eax
0004f6cf  6644394302               cmp word ptr [rbx + 2], r8w
0004f6d4  7404                     je 0x4f6da
0004f6d6  8907                     mov dword ptr [rdi], eax
0004f6d8  eb2a                     jmp 0x4f704
0004f6da  0fb703                   movzx eax, word ptr [rbx]
0004f6dd  66413bc0                 cmp ax, r8w
0004f6e1  7421                     je 0x4f704
0004f6e3  0fb6d0                   movzx edx, al
0004f6e6  03d1                     add edx, ecx
0004f6e8  4133d1                   xor edx, r9d
0004f6eb  69c220080000             imul eax, edx, 0x820
0004f6f1  8917                     mov dword ptr [rdi], edx
0004f6f3  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004f6f7  03c8                     add ecx, eax
0004f6f9  8bc2                     mov eax, edx
0004f6fb  c1e802                   shr eax, 2
0004f6fe  03c8                     add ecx, eax
0004f700  33ca                     xor ecx, edx
0004f702  890f                     mov dword ptr [rdi], ecx
0004f704  66ff4500                 inc word ptr [rbp]
0004f708  486306                   movsxd rax, dword ptr [rsi]
0004f70b  0fb694248a000000         movzx edx, byte ptr [rsp + 0x8a]
0004f713  66410bd5                 or dx, r13w
0004f717  0fb7ca                   movzx ecx, dx
0004f71a  66c1e908                 shr cx, 8
0004f71e  880c18                   mov byte ptr [rax + rbx], cl
0004f721  48630e                   movsxd rcx, dword ptr [rsi]
0004f724  8d4101                   lea eax, [rcx + 1]
0004f727  8906                     mov dword ptr [rsi], eax
0004f729  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f72d  ff06                     inc dword ptr [rsi]
0004f72f  833e04                   cmp dword ptr [rsi], 4
0004f732  0f85a5000000             jne 0x4f7dd
0004f738  448916                   mov dword ptr [rsi], r10d
0004f73b  458b0f                   mov r9d, dword ptr [r15]
0004f73e  8b13                     mov edx, dword ptr [rbx]
0004f740  4585f6                   test r14d, r14d
0004f743  7541                     jne 0x4f786
0004f745  41c1c103                 rol r9d, 3
0004f749  4133d1                   xor edx, r9d
0004f74c  418917                   mov dword ptr [r15], edx
0004f74f  6644394302               cmp word ptr [rbx + 2], r8w
0004f754  740b                     je 0x4f761
0004f756  8917                     mov dword ptr [rdi], edx
0004f758  66ff4500                 inc word ptr [rbp]
0004f75c  e929010000               jmp 0x4f88a
0004f761  0fb703                   movzx eax, word ptr [rbx]
0004f764  66413bc0                 cmp ax, r8w
0004f768  7473                     je 0x4f7dd
0004f76a  0fb6c8                   movzx ecx, al
0004f76d  4133c9                   xor ecx, r9d
0004f770  890f                     mov dword ptr [rdi], ecx
0004f772  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f776  c1c103                   rol ecx, 3
0004f779  33c8                     xor ecx, eax
0004f77b  890f                     mov dword ptr [rdi], ecx
0004f77d  66ff4500                 inc word ptr [rbp]
0004f781  e904010000               jmp 0x4f88a
0004f786  4569d120080000           imul r10d, r9d, 0x820
0004f78d  418bc1                   mov eax, r9d
0004f790  c1e802                   shr eax, 2
0004f793  4403d0                   add r10d, eax
0004f796  428d0412                 lea eax, [rdx + r10]
0004f79a  4133c1                   xor eax, r9d
0004f79d  418907                   mov dword ptr [r15], eax
0004f7a0  6644394302               cmp word ptr [rbx + 2], r8w
0004f7a5  740b                     je 0x4f7b2
0004f7a7  8907                     mov dword ptr [rdi], eax
0004f7a9  66ff4500                 inc word ptr [rbp]
0004f7ad  e9d8000000               jmp 0x4f88a
0004f7b2  0fb703                   movzx eax, word ptr [rbx]
0004f7b5  66413bc0                 cmp ax, r8w
0004f7b9  7422                     je 0x4f7dd
0004f7bb  0fb6d0                   movzx edx, al
0004f7be  4103d2                   add edx, r10d
0004f7c1  4133d1                   xor edx, r9d
0004f7c4  69c220080000             imul eax, edx, 0x820
0004f7ca  8917                     mov dword ptr [rdi], edx
0004f7cc  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004f7d0  03c8                     add ecx, eax
0004f7d2  8bc2                     mov eax, edx
0004f7d4  c1e802                   shr eax, 2
0004f7d7  03c8                     add ecx, eax
0004f7d9  33ca                     xor ecx, edx
0004f7db  890f                     mov dword ptr [rdi], ecx
0004f7dd  66ff4500                 inc word ptr [rbp]
0004f7e1  e9a4000000               jmp 0x4f88a
0004f7e6  498b06                   mov rax, qword ptr [r14]
0004f7e9  41bd00ff0000             mov r13d, 0xff00
0004f7ef  0fb7542450               movzx edx, word ptr [rsp + 0x50]
0004f7f4  0fb7ca                   movzx ecx, dx
0004f7f7  66c1e908                 shr cx, 8
0004f7fb  8808                     mov byte ptr [rax], cl
0004f7fd  49ff06                   inc qword ptr [r14]
0004f800  498b06                   mov rax, qword ptr [r14]
0004f803  8810                     mov byte ptr [rax], dl
0004f805  49ff06                   inc qword ptr [r14]
0004f808  498b0e                   mov rcx, qword ptr [r14]
0004f80b  0fb6942488000000         movzx edx, byte ptr [rsp + 0x88]
0004f813  66410bd5                 or dx, r13w
0004f817  0fb7c2                   movzx eax, dx
0004f81a  66c1e808                 shr ax, 8
0004f81e  8801                     mov byte ptr [rcx], al
0004f820  49ff06                   inc qword ptr [r14]
0004f823  498b06                   mov rax, qword ptr [r14]
0004f826  8810                     mov byte ptr [rax], dl
0004f828  49ff06                   inc qword ptr [r14]
0004f82b  498b0e                   mov rcx, qword ptr [r14]
0004f82e  0fb6942489000000         movzx edx, byte ptr [rsp + 0x89]
0004f836  66410bd5                 or dx, r13w
0004f83a  0fb7c2                   movzx eax, dx
0004f83d  66c1e808                 shr ax, 8
0004f841  8801                     mov byte ptr [rcx], al
0004f843  49ff06                   inc qword ptr [r14]
0004f846  498b06                   mov rax, qword ptr [r14]
0004f849  8810                     mov byte ptr [rax], dl
0004f84b  49ff06                   inc qword ptr [r14]
0004f84e  498b0e                   mov rcx, qword ptr [r14]
0004f851  0fb694248a000000         movzx edx, byte ptr [rsp + 0x8a]
0004f859  66410bd5                 or dx, r13w
0004f85d  0fb7c2                   movzx eax, dx
0004f860  66c1e808                 shr ax, 8
0004f864  8801                     mov byte ptr [rcx], al
0004f866  49ff06                   inc qword ptr [r14]
0004f869  498b06                   mov rax, qword ptr [r14]
0004f86c  488b4c2470               mov rcx, qword ptr [rsp + 0x70]
0004f871  8810                     mov byte ptr [rax], dl
0004f873  49ff06                   inc qword ptr [r14]
0004f876  498b0424                 mov rax, qword ptr [r12]
0004f87a  c60002                   mov byte ptr [rax], 2
0004f87d  488b01                   mov rax, qword ptr [rcx]
0004f880  c60002                   mov byte ptr [rax], 2
0004f883  49ff0424                 inc qword ptr [r12]
0004f887  48ff01                   inc qword ptr [rcx]
0004f88a  488b442468               mov rax, qword ptr [rsp + 0x68]
0004f88f  41ffcb                   dec r11d
0004f892  488b8c2480000000         mov rcx, qword ptr [rsp + 0x80]
0004f89a  440118                   add dword ptr [rax], r11d
0004f89d  4963c3                   movsxd rax, r11d
0004f8a0  4803c0                   add rax, rax
0004f8a3  480101                   add qword ptr [rcx], rax
0004f8a6  e915030000               jmp 0x4fbc0
0004f8ab  4c8b5c2470               mov r11, qword ptr [rsp + 0x70]
0004f8b0  4c8b4c2460               mov r9, qword ptr [rsp + 0x60]
0004f8b5  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004f8bd  410fb64502               movzx eax, byte ptr [r13 + 2]
0004f8c2  7408                     je 0x4f8cc
0004f8c4  420fb64c0848             movzx ecx, byte ptr [rax + r9 + 0x48]
0004f8ca  eb03                     jmp 0x4f8cf
0004f8cc  0fb7c8                   movzx ecx, ax
0004f8cf  410fb64500               movzx eax, byte ptr [r13]
0004f8d4  66c1e108                 shl cx, 8
0004f8d8  660bc8                   or cx, ax
0004f8db  66898c2488000000         mov word ptr [rsp + 0x88], cx
0004f8e3  66c1e908                 shr cx, 8
0004f8e7  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f8ef  743b                     je 0x4f92c
0004f8f1  486306                   movsxd rax, dword ptr [rsi]
0004f8f4  880c18                   mov byte ptr [rax + rbx], cl
0004f8f7  48630e                   movsxd rcx, dword ptr [rsi]
0004f8fa  8d4101                   lea eax, [rcx + 1]
0004f8fd  8906                     mov dword ptr [rsi], eax
0004f8ff  0fb6842488000000         movzx eax, byte ptr [rsp + 0x88]
0004f907  88441901                 mov byte ptr [rcx + rbx + 1], al
0004f90b  ff06                     inc dword ptr [rsi]
0004f90d  833e04                   cmp dword ptr [rsi], 4
0004f910  0f851b020000             jne 0x4fb31
0004f916  4533d2                   xor r10d, r10d
0004f919  41b807020000             mov r8d, 0x207
0004f91f  4439942400010000         cmp dword ptr [rsp + 0x100], r10d
0004f927  e963010000               jmp 0x4fa8f
0004f92c  498b06                   mov rax, qword ptr [r14]
0004f92f  8808                     mov byte ptr [rax], cl
0004f931  49ff06                   inc qword ptr [r14]
0004f934  498b0e                   mov rcx, qword ptr [r14]
0004f937  0fb6842488000000         movzx eax, byte ptr [rsp + 0x88]
0004f93f  8801                     mov byte ptr [rcx], al
0004f941  49ff06                   inc qword ptr [r14]
0004f944  498b0424                 mov rax, qword ptr [r12]
0004f948  c60002                   mov byte ptr [rax], 2
0004f94b  410fb64d03               movzx ecx, byte ptr [r13 + 3]
0004f950  498b03                   mov rax, qword ptr [r11]
0004f953  80e13f                   and cl, 0x3f
0004f956  8808                     mov byte ptr [rax], cl
0004f958  49ff06                   inc qword ptr [r14]
0004f95b  e959020000               jmp 0x4fbb9
0004f960  83bc24f800000000         cmp dword ptr [rsp + 0xf8], 0
0004f968  0f84cc010000             je 0x4fb3a
0004f96e  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004f976  7416                     je 0x4f98e
0004f978  410fb69146010000         movzx edx, byte ptr [r9 + 0x146]
0004f980  b8ff000000               mov eax, 0xff
0004f985  66c1e208                 shl dx, 8
0004f989  660bd0                   or dx, ax
0004f98c  eb05                     jmp 0x4f993
0004f98e  bafffe0000               mov edx, 0xfeff
0004f993  486306                   movsxd rax, dword ptr [rsi]
0004f996  0fb7ca                   movzx ecx, dx
0004f999  448b9c2400010000         mov r11d, dword ptr [rsp + 0x100]
0004f9a1  4533d2                   xor r10d, r10d
0004f9a4  66c1e908                 shr cx, 8
0004f9a8  41b807020000             mov r8d, 0x207
0004f9ae  880c18                   mov byte ptr [rax + rbx], cl
0004f9b1  48630e                   movsxd rcx, dword ptr [rsi]
0004f9b4  8d4101                   lea eax, [rcx + 1]
0004f9b7  8906                     mov dword ptr [rsi], eax
0004f9b9  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004f9bd  ff06                     inc dword ptr [rsi]
0004f9bf  833e04                   cmp dword ptr [rsi], 4
0004f9c2  0f858b000000             jne 0x4fa53
0004f9c8  448916                   mov dword ptr [rsi], r10d
0004f9cb  458b0f                   mov r9d, dword ptr [r15]
0004f9ce  8b13                     mov edx, dword ptr [rbx]
0004f9d0  4585db                   test r11d, r11d
0004f9d3  7531                     jne 0x4fa06
0004f9d5  41c1c103                 rol r9d, 3
0004f9d9  4133d1                   xor edx, r9d
0004f9dc  418917                   mov dword ptr [r15], edx
0004f9df  6644394302               cmp word ptr [rbx + 2], r8w
0004f9e4  7404                     je 0x4f9ea
0004f9e6  8917                     mov dword ptr [rdi], edx
0004f9e8  eb69                     jmp 0x4fa53
0004f9ea  0fb703                   movzx eax, word ptr [rbx]
0004f9ed  66413bc0                 cmp ax, r8w
0004f9f1  7460                     je 0x4fa53
0004f9f3  0fb6c8                   movzx ecx, al
0004f9f6  4133c9                   xor ecx, r9d
0004f9f9  890f                     mov dword ptr [rdi], ecx
0004f9fb  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004f9ff  c1c103                   rol ecx, 3
0004fa02  33c8                     xor ecx, eax
0004fa04  eb4b                     jmp 0x4fa51
0004fa06  4169c920080000           imul ecx, r9d, 0x820
0004fa0d  418bc1                   mov eax, r9d
0004fa10  c1e802                   shr eax, 2
0004fa13  03c8                     add ecx, eax
0004fa15  8d040a                   lea eax, [rdx + rcx]
0004fa18  4133c1                   xor eax, r9d
0004fa1b  418907                   mov dword ptr [r15], eax
0004fa1e  6644394302               cmp word ptr [rbx + 2], r8w
0004fa23  7404                     je 0x4fa29
0004fa25  8907                     mov dword ptr [rdi], eax
0004fa27  eb2a                     jmp 0x4fa53
0004fa29  0fb703                   movzx eax, word ptr [rbx]
0004fa2c  66413bc0                 cmp ax, r8w
0004fa30  7421                     je 0x4fa53
0004fa32  0fb6d0                   movzx edx, al
0004fa35  03d1                     add edx, ecx
0004fa37  4133d1                   xor edx, r9d
0004fa3a  69c220080000             imul eax, edx, 0x820
0004fa40  8917                     mov dword ptr [rdi], edx
0004fa42  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004fa46  03c8                     add ecx, eax
0004fa48  8bc2                     mov eax, edx
0004fa4a  c1e802                   shr eax, 2
0004fa4d  03c8                     add ecx, eax
0004fa4f  33ca                     xor ecx, edx
0004fa51  890f                     mov dword ptr [rdi], ecx
0004fa53  66ff4500                 inc word ptr [rbp]
0004fa57  410fb64500               movzx eax, byte ptr [r13]
0004fa5c  410fb65502               movzx edx, byte ptr [r13 + 2]
0004fa61  66c1e008                 shl ax, 8
0004fa65  660bd0                   or dx, ax
0004fa68  486306                   movsxd rax, dword ptr [rsi]
0004fa6b  0fb7ca                   movzx ecx, dx
0004fa6e  66c1e908                 shr cx, 8
0004fa72  880c18                   mov byte ptr [rax + rbx], cl
0004fa75  48630e                   movsxd rcx, dword ptr [rsi]
0004fa78  8d4101                   lea eax, [rcx + 1]
0004fa7b  8906                     mov dword ptr [rsi], eax
0004fa7d  88541901                 mov byte ptr [rcx + rbx + 1], dl
0004fa81  ff06                     inc dword ptr [rsi]
0004fa83  833e04                   cmp dword ptr [rsi], 4
0004fa86  0f85a5000000             jne 0x4fb31
0004fa8c  4585db                   test r11d, r11d
0004fa8f  448916                   mov dword ptr [rsi], r10d
0004fa92  8b13                     mov edx, dword ptr [rbx]
0004fa94  458b0f                   mov r9d, dword ptr [r15]
0004fa97  7541                     jne 0x4fada
0004fa99  41c1c103                 rol r9d, 3
0004fa9d  4133d1                   xor edx, r9d
0004faa0  418917                   mov dword ptr [r15], edx
0004faa3  6644394302               cmp word ptr [rbx + 2], r8w
0004faa8  740b                     je 0x4fab5
0004faaa  8917                     mov dword ptr [rdi], edx
0004faac  66ff4500                 inc word ptr [rbp]
0004fab0  e90b010000               jmp 0x4fbc0
0004fab5  0fb703                   movzx eax, word ptr [rbx]
0004fab8  66413bc0                 cmp ax, r8w
0004fabc  7473                     je 0x4fb31
0004fabe  0fb6c8                   movzx ecx, al
0004fac1  4133c9                   xor ecx, r9d
0004fac4  890f                     mov dword ptr [rdi], ecx
0004fac6  0fb64301                 movzx eax, byte ptr [rbx + 1]
0004faca  c1c103                   rol ecx, 3
0004facd  33c8                     xor ecx, eax
0004facf  890f                     mov dword ptr [rdi], ecx
0004fad1  66ff4500                 inc word ptr [rbp]
0004fad5  e9e6000000               jmp 0x4fbc0
0004fada  4569d120080000           imul r10d, r9d, 0x820
0004fae1  418bc1                   mov eax, r9d
0004fae4  c1e802                   shr eax, 2
0004fae7  4403d0                   add r10d, eax
0004faea  428d0412                 lea eax, [rdx + r10]
0004faee  4133c1                   xor eax, r9d
0004faf1  418907                   mov dword ptr [r15], eax
0004faf4  6644394302               cmp word ptr [rbx + 2], r8w
0004faf9  740b                     je 0x4fb06
0004fafb  8907                     mov dword ptr [rdi], eax
0004fafd  66ff4500                 inc word ptr [rbp]
0004fb01  e9ba000000               jmp 0x4fbc0
0004fb06  0fb703                   movzx eax, word ptr [rbx]
0004fb09  66413bc0                 cmp ax, r8w
0004fb0d  7422                     je 0x4fb31
0004fb0f  0fb6d0                   movzx edx, al
0004fb12  4103d2                   add edx, r10d
0004fb15  4133d1                   xor edx, r9d
0004fb18  69c220080000             imul eax, edx, 0x820
0004fb1e  8917                     mov dword ptr [rdi], edx
0004fb20  0fb64b01                 movzx ecx, byte ptr [rbx + 1]
0004fb24  03c8                     add ecx, eax
0004fb26  8bc2                     mov eax, edx
0004fb28  c1e802                   shr eax, 2
0004fb2b  03c8                     add ecx, eax
0004fb2d  33ca                     xor ecx, edx
0004fb2f  890f                     mov dword ptr [rdi], ecx
0004fb31  66ff4500                 inc word ptr [rbp]
0004fb35  e986000000               jmp 0x4fbc0
0004fb3a  83bc246801000000         cmp dword ptr [rsp + 0x168], 0
0004fb42  7416                     je 0x4fb5a
0004fb44  410fb69146010000         movzx edx, byte ptr [r9 + 0x146]
0004fb4c  b8ff000000               mov eax, 0xff
0004fb51  66c1e208                 shl dx, 8
0004fb55  660bd0                   or dx, ax
0004fb58  eb05                     jmp 0x4fb5f
0004fb5a  bafffe0000               mov edx, 0xfeff
0004fb5f  498b06                   mov rax, qword ptr [r14]
0004fb62  6689942488000000         mov word ptr [rsp + 0x88], dx
0004fb6a  66c1ea08                 shr dx, 8
0004fb6e  8810                     mov byte ptr [rax], dl
0004fb70  49ff06                   inc qword ptr [r14]
0004fb73  498b0e                   mov rcx, qword ptr [r14]
0004fb76  0fb6842488000000         movzx eax, byte ptr [rsp + 0x88]
0004fb7e  8801                     mov byte ptr [rcx], al
0004fb80  49ff06                   inc qword ptr [r14]
0004fb83  410fb64500               movzx eax, byte ptr [r13]
0004fb88  410fb65502               movzx edx, byte ptr [r13 + 2]
0004fb8d  4d8b06                   mov r8, qword ptr [r14]
0004fb90  66c1e008                 shl ax, 8
0004fb94  660bd0                   or dx, ax
0004fb97  0fb7ca                   movzx ecx, dx
0004fb9a  66c1ea08                 shr dx, 8
0004fb9e  418810                   mov byte ptr [r8], dl
0004fba1  49ff06                   inc qword ptr [r14]
0004fba4  498b06                   mov rax, qword ptr [r14]
0004fba7  8808                     mov byte ptr [rax], cl
0004fba9  49ff06                   inc qword ptr [r14]
0004fbac  498b0424                 mov rax, qword ptr [r12]
0004fbb0  c60002                   mov byte ptr [rax], 2
0004fbb3  498b03                   mov rax, qword ptr [r11]
0004fbb6  c60002                   mov byte ptr [rax], 2
0004fbb9  49ff0424                 inc qword ptr [r12]
0004fbbd  49ff03                   inc qword ptr [r11]
0004fbc0  488b9c24e0000000         mov rbx, qword ptr [rsp + 0xe0]
0004fbc8  4881c490000000           add rsp, 0x90
0004fbcf  415f                     pop r15
0004fbd1  415e                     pop r14
0004fbd3  415d                     pop r13
0004fbd5  415c                     pop r12
0004fbd7  5f                       pop rdi
0004fbd8  5e                       pop rsi
0004fbd9  5d                       pop rbp
0004fbda  c3                       ret
0004fbdb  90                       nop
0004fbdc  f5                       cmc
0004fbdd  ec                       in al, dx
0004fbde  0400                     add al, 0
0004fbe0  29ed                     sub ebp, ebp
0004fbe2  0400                     add al, 0
0004fbe4  80f104                   xor cl, 4
0004fbe7  0042f4                   add byte ptr [rdx - 0xc], al
0004fbea  0400                     add al, 0
