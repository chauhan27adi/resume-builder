; TMatchPattern<wchar_t,CWCharBinaryHelper>::match_pattern_resumable
; aetm_enclave.dll, primary RVA 0x32990, 3268 bytes in 6 chunk(s)

; chunk at RVA 0x32990 (194 bytes)
00032990  4053                     push rbx
00032992  55                       push rbp
00032993  56                       push rsi
00032994  4157                     push r15
00032996  4881ece8000000           sub rsp, 0xe8
0003299d  488b0564860700           mov rax, qword ptr [rip + 0x78664]
000329a4  4833c4                   xor rax, rsp
000329a7  48898424c8000000         mov qword ptr [rsp + 0xc8], rax
000329af  4c8b9c2440010000         mov r11, qword ptr [rsp + 0x140]
000329b7  4533d2                   xor r10d, r10d
000329ba  488b842450010000         mov rax, qword ptr [rsp + 0x150]
000329c2  418bf0                   mov esi, r8d
000329c5  488bac2438010000         mov rbp, qword ptr [rsp + 0x138]
000329cd  488bda                   mov rbx, rdx
000329d0  4c8bbc2460010000         mov r15, qword ptr [rsp + 0x160]
000329d8  4c8bc2                   mov r8, rdx
000329db  4c898c24b8000000         mov qword ptr [rsp + 0xb8], r9
000329e3  4c8b8c2448010000         mov r9, qword ptr [rsp + 0x148]
000329eb  4c898c24a8000000         mov qword ptr [rsp + 0xa8], r9
000329f3  4c899c24a0000000         mov qword ptr [rsp + 0xa0], r11
000329fb  48898424b0000000         mov qword ptr [rsp + 0xb0], rax
00032a03  4889542460               mov qword ptr [rsp + 0x60], rdx
00032a08  4885c9                   test rcx, rcx
00032a0b  7440                     je 0x32a4d
00032a0d  448b4154                 mov r8d, dword ptr [rcx + 0x54]
00032a11  4585c0                   test r8d, r8d
00032a14  7434                     je 0x32a4a
00032a16  488b054b514300           mov rax, qword ptr [rip + 0x43514b]
00032a1d  418bca                   mov ecx, r10d
00032a20  480590070000             add rax, 0x790
00032a26  488b10                   mov rdx, qword ptr [rax]
00032a29  4885d2                   test rdx, rdx
00032a2c  7406                     je 0x32a34
00032a2e  44394210                 cmp dword ptr [rdx + 0x10], r8d
00032a32  7411                     je 0x32a45
00032a34  ffc1                     inc ecx
00032a36  4883c008                 add rax, 8
00032a3a  83f911                   cmp ecx, 0x11
00032a3d  0f8dbe0b0000             jge 0x33601
00032a43  ebe1                     jmp 0x32a26
00032a45  4c8bc3                   mov r8, rbx
00032a48  eb03                     jmp 0x32a4d
00032a4a  4c8bc2                   mov r8, rdx
00032a4d  b901000000               mov ecx, 1

; chunk at RVA 0x32a52 (441 bytes)
00032a52  4889bc2418010000         mov qword ptr [rsp + 0x118], rdi
00032a5a  498bfa                   mov rdi, r10
00032a5d  4c89a424e0000000         mov qword ptr [rsp + 0xe0], r12
00032a65  4c89ac24d8000000         mov qword ptr [rsp + 0xd8], r13
00032a6d  4d8bea                   mov r13, r10
00032a70  4c89b424d0000000         mov qword ptr [rsp + 0xd0], r14
00032a78  4d8bf2                   mov r14, r10
00032a7b  8d5124                   lea edx, [rcx + 0x24]
00032a7e  4c89542470               mov qword ptr [rsp + 0x70], r10
00032a83  4c89942490000000         mov qword ptr [rsp + 0x90], r10
00032a8b  4c89542448               mov qword ptr [rsp + 0x48], r10
00032a90  4c89942488000000         mov qword ptr [rsp + 0x88], r10
00032a98  4489542440               mov dword ptr [rsp + 0x40], r10d
00032a9d  4c89542438               mov qword ptr [rsp + 0x38], r10
00032aa2  4c89542468               mov qword ptr [rsp + 0x68], r10
00032aa7  4c89942480000000         mov qword ptr [rsp + 0x80], r10
00032aaf  4c89942498000000         mov qword ptr [rsp + 0x98], r10
00032ab7  4489542444               mov dword ptr [rsp + 0x44], r10d
00032abc  40887c2430               mov byte ptr [rsp + 0x30], dil
00032ac1  453817                   cmp byte ptr [r15], r10b
00032ac4  7410                     je 0x32ad6
00032ac6  4c8ba42430010000         mov r12, qword ptr [rsp + 0x130]
00032ace  41883f                   mov byte ptr [r15], dil
00032ad1  e942010000               jmp 0x32c18
00032ad6  498b4720                 mov rax, qword ptr [r15 + 0x20]
00032ada  410fb65728               movzx edx, byte ptr [r15 + 0x28]
00032adf  498b7f58                 mov rdi, qword ptr [r15 + 0x58]
00032ae3  458b5770                 mov r10d, dword ptr [r15 + 0x70]
00032ae7  418b7718                 mov esi, dword ptr [r15 + 0x18]
00032aeb  4d8b6708                 mov r12, qword ptr [r15 + 8]
00032aef  4d8b6f60                 mov r13, qword ptr [r15 + 0x60]
00032af3  4889442450               mov qword ptr [rsp + 0x50], rax
00032af8  498b4730                 mov rax, qword ptr [r15 + 0x30]
00032afc  4889442470               mov qword ptr [rsp + 0x70], rax
00032b01  498b4738                 mov rax, qword ptr [r15 + 0x38]
00032b05  4889842490000000         mov qword ptr [rsp + 0x90], rax
00032b0d  498b4740                 mov rax, qword ptr [r15 + 0x40]
00032b11  4889442448               mov qword ptr [rsp + 0x48], rax
00032b16  418b4748                 mov eax, dword ptr [r15 + 0x48]
00032b1a  89442440                 mov dword ptr [rsp + 0x40], eax
00032b1e  498b4750                 mov rax, qword ptr [r15 + 0x50]
00032b22  4889842480000000         mov qword ptr [rsp + 0x80], rax
00032b2a  498b4768                 mov rax, qword ptr [r15 + 0x68]
00032b2e  4889842498000000         mov qword ptr [rsp + 0x98], rax
00032b36  410fb64774               movzx eax, byte ptr [r15 + 0x74]
00032b3b  88442430                 mov byte ptr [rsp + 0x30], al
00032b3f  498b87c81f0000           mov rax, qword ptr [r15 + 0x1fc8]
00032b46  89542434                 mov dword ptr [rsp + 0x34], edx
00032b4a  48897c2458               mov qword ptr [rsp + 0x58], rdi
00032b4f  4489542444               mov dword ptr [rsp + 0x44], r10d
00032b54  4883f8ff                 cmp rax, -1
00032b58  7505                     jne 0x32b5f
00032b5a  498bde                   mov rbx, r14
00032b5d  eb04                     jmp 0x32b63
00032b5f  488d1c43                 lea rbx, [rbx + rax*2]
00032b63  498b87d01f0000           mov rax, qword ptr [r15 + 0x1fd0]
00032b6a  4883f8ff                 cmp rax, -1
00032b6e  750a                     jne 0x32b7a
00032b70  4c89b42488000000         mov qword ptr [rsp + 0x88], r14
00032b78  eb0c                     jmp 0x32b86
00032b7a  498d0440                 lea rax, [r8 + rax*2]
00032b7e  4889842488000000         mov qword ptr [rsp + 0x88], rax
00032b86  4585d2                   test r10d, r10d
00032b89  7421                     je 0x32bac
00032b8b  4d8b87b81f0000           mov r8, qword ptr [r15 + 0x1fb8]
00032b92  418b87c01f0000           mov eax, dword ptr [r15 + 0x1fc0]
00032b99  48d1e8                   shr rax, 1
00032b9c  4c89442438               mov qword ptr [rsp + 0x38], r8
00032ba1  4d8d1440                 lea r10, [r8 + rax*2]
00032ba5  4c89542478               mov qword ptr [rsp + 0x78], r10
00032baa  eb10                     jmp 0x32bbc
00032bac  4d8bc6                   mov r8, r14
00032baf  4c89742438               mov qword ptr [rsp + 0x38], r14
00032bb4  4d8bd6                   mov r10, r14
00032bb7  4c89742478               mov qword ptr [rsp + 0x78], r14
00032bbc  498b87d81f0000           mov rax, qword ptr [r15 + 0x1fd8]
00032bc3  4883f8ff                 cmp rax, -1
00032bc7  7507                     jne 0x32bd0
00032bc9  4c89742468               mov qword ptr [rsp + 0x68], r14
00032bce  eb09                     jmp 0x32bd9
00032bd0  498d0440                 lea rax, [r8 + rax*2]
00032bd4  4889442468               mov qword ptr [rsp + 0x68], rax
00032bd9  498b87e01f0000           mov rax, qword ptr [r15 + 0x1fe0]
00032be0  4883f8ff                 cmp rax, -1
00032be4  7404                     je 0x32bea
00032be6  4d8d3440                 lea r14, [r8 + rax*2]
00032bea  418b4714                 mov eax, dword ptr [r15 + 0x14]
00032bee  ffc8                     dec eax
00032bf0  83f805                   cmp eax, 5
00032bf3  771b                     ja 0x32c10
00032bf5  4c8d0504d4fcff           lea r8, [rip - 0x32bfc]
00032bfc  4898                     cdqe
00032bfe  418b8c803c360300         mov ecx, dword ptr [r8 + rax*4 + 0x3363c]
00032c06  4903c8                   add rcx, r8
00032c09  ffe1                     jmp rcx

; chunk at RVA 0x32c0b (5 bytes)
00032c0b  b901000000               mov ecx, 1

; chunk at RVA 0x32c10 (2545 bytes)
00032c10  ba25000000               mov edx, 0x25
00032c15  4533d2                   xor r10d, r10d
00032c18  4d8bca                   mov r9, r10
00032c1b  4c89542450               mov qword ptr [rsp + 0x50], r10
00032c20  c644243400               mov byte ptr [rsp + 0x34], 0
00032c25  85f6                     test esi, esi
00032c27  0f8e54080000             jle 0x33481
00032c2d  4885ed                   test rbp, rbp
00032c30  744c                     je 0x32c7e
00032c32  0fb703                   movzx eax, word ptr [rbx]
00032c35  66394500                 cmp word ptr [rbp], ax
00032c39  7543                     jne 0x32c7e
00032c3b  4d85e4                   test r12, r12
00032c3e  0f843c090000             je 0x33580
00032c44  4883c302                 add rbx, 2
00032c48  83ee02                   sub esi, 2
00032c4b  85f6                     test esi, esi
00032c4d  0f8e2d090000             jle 0x33580
00032c53  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00032c5b  498bd1                   mov rdx, r9
00032c5e  488d8c24c0000000         lea rcx, [rsp + 0xc0]
00032c66  41ffd3                   call r11
00032c69  84c0                     test al, al
00032c6b  0f848d000000             je 0x32cfe
00032c71  0fb78424c0000000         movzx eax, word ptr [rsp + 0xc0]
00032c79  663903                   cmp word ptr [rbx], ax
00032c7c  eb52                     jmp 0x32cd0
00032c7e  0fb703                   movzx eax, word ptr [rbx]
00032c81  663bd0                   cmp dx, ax
00032c84  0f848e000000             je 0x32d18
00032c8a  4d85e4                   test r12, r12
00032c8d  0f84ed080000             je 0x33580
00032c93  ba5b000000               mov edx, 0x5b
00032c98  663bd0                   cmp dx, ax
00032c9b  0f8480000000             je 0x32d21
00032ca1  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00032ca9  498bd1                   mov rdx, r9
00032cac  488d8c24c0000000         lea rcx, [rsp + 0xc0]
00032cb4  41ffd3                   call r11
00032cb7  84c0                     test al, al
00032cb9  7450                     je 0x32d0b
00032cbb  0fb703                   movzx eax, word ptr [rbx]
00032cbe  b95f000000               mov ecx, 0x5f
00032cc3  663bc8                   cmp cx, ax
00032cc6  740e                     je 0x32cd6
00032cc8  663b8424c0000000         cmp ax, word ptr [rsp + 0xc0]
00032cd0  0f85aa080000             jne 0x33580
00032cd6  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
00032cde  b901000000               mov ecx, 1
00032ce3  4983ec02                 sub r12, 2
00032ce7  48894c2450               mov qword ptr [rsp + 0x50], rcx
00032cec  4883c302                 add rbx, 2
00032cf0  448bc9                   mov r9d, ecx
00032cf3  83ee02                   sub esi, 2
00032cf6  8d5124                   lea edx, [rcx + 0x24]
00032cf9  e927ffffff               jmp 0x32c25
00032cfe  41c7471401000000         mov dword ptr [r15 + 0x14], 1
00032d06  e984070000               jmp 0x3348f
00032d0b  41c7471402000000         mov dword ptr [r15 + 0x14], 2
00032d13  e977070000               jmp 0x3348f
00032d18  83fe01                   cmp esi, 1
00032d1b  0f846f080000             je 0x33590
00032d21  418b87c01f0000           mov eax, dword ptr [r15 + 0x1fc0]
00032d28  4533d2                   xor r10d, r10d
00032d2b  48894c2448               mov qword ptr [rsp + 0x48], rcx
00032d30  4c8bd9                   mov r11, rcx
00032d33  4c89942488000000         mov qword ptr [rsp + 0x88], r10
00032d3b  458bea                   mov r13d, r10d
00032d3e  4c89542458               mov qword ptr [rsp + 0x58], r10
00032d43  418bfa                   mov edi, r10d
00032d46  4c89542470               mov qword ptr [rsp + 0x70], r10
00032d4b  89742444                 mov dword ptr [rsp + 0x44], esi
00032d4f  3bf0                     cmp esi, eax
00032d51  0f87c5080000             ja 0x3361c
00032d57  4d8b87b81f0000           mov r8, qword ptr [r15 + 0x1fb8]
00032d5e  8b542434                 mov edx, dword ptr [rsp + 0x34]
00032d62  4d8bf0                   mov r14, r8
00032d65  48d1e8                   shr rax, 1
00032d68  4c89442438               mov qword ptr [rsp + 0x38], r8
00032d6d  4d8d1440                 lea r10, [r8 + rax*2]
00032d71  4c89542478               mov qword ptr [rsp + 0x78], r10
00032d76  85f6                     test esi, esi
00032d78  0f8eaf030000             jle 0x3312d
00032d7e  4885ed                   test rbp, rbp
00032d81  0f84f6000000             je 0x32e7d
00032d87  0fb703                   movzx eax, word ptr [rbx]
00032d8a  66394500                 cmp word ptr [rbp], ax
00032d8e  0f85e9000000             jne 0x32e7d
00032d94  4d85e4                   test r12, r12
00032d97  0f8448060000             je 0x333e5
00032d9d  4883c302                 add rbx, 2
00032da1  83ee02                   sub esi, 2
00032da4  85f6                     test esi, esi
00032da6  0f8ed4070000             jle 0x33580
00032dac  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
00032db4  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00032dbc  4c3bef                   cmp r13, rdi
00032dbf  7546                     jne 0x32e07
00032dc1  498bd1                   mov rdx, r9
00032dc4  498bce                   mov rcx, r14
00032dc7  41ffd3                   call r11
00032dca  84c0                     test al, al
00032dcc  0f84a0050000             je 0x33372
00032dd2  8b542434                 mov edx, dword ptr [rsp + 0x34]
00032dd6  4883c702                 add rdi, 2
00032dda  4c8b542478               mov r10, qword ptr [rsp + 0x78]
00032ddf  48897c2458               mov qword ptr [rsp + 0x58], rdi
00032de4  84d2                     test dl, dl
00032de6  741f                     je 0x32e07
00032de8  4c3b642470               cmp r12, qword ptr [rsp + 0x70]
00032ded  7718                     ja 0x32e07
00032def  b820000000               mov eax, 0x20
00032df4  0fb6d2                   movzx edx, dl
00032df7  66413b06                 cmp ax, word ptr [r14]
00032dfb  b800000000               mov eax, 0
00032e00  0f45d0                   cmovne edx, eax
00032e03  89542434                 mov dword ptr [rsp + 0x34], edx
00032e07  410fb706                 movzx eax, word ptr [r14]
00032e0b  4983c502                 add r13, 2
00032e0f  663903                   cmp word ptr [rbx], ax
00032e12  0f845a020000             je 0x33072
00032e18  4c8b5c2448               mov r11, qword ptr [rsp + 0x48]
00032e1d  4c8b8c2488000000         mov r9, qword ptr [rsp + 0x88]
00032e25  4d85c9                   test r9, r9
00032e28  0f84ec050000             je 0x3341a
00032e2e  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
00032e36  49ffc3                   inc r11
00032e39  4c8b442468               mov r8, qword ptr [rsp + 0x68]
00032e3e  4883fb02                 cmp rbx, 2
00032e42  4c8b542478               mov r10, qword ptr [rsp + 0x78]
00032e47  8bc3                     mov eax, ebx
00032e49  b902000000               mov ecx, 2
00032e4e  4c895c2448               mov qword ptr [rsp + 0x48], r11
00032e53  0f47c1                   cmova eax, ecx
00032e56  8bc8                     mov ecx, eax
00032e58  482bd9                   sub rbx, rcx
00032e5b  48899c2480000000         mov qword ptr [rsp + 0x80], rbx
00032e63  4a8d1400                 lea rdx, [rax + r8]
00032e67  493bd2                   cmp rdx, r10
00032e6a  0f8341030000             jae 0x331b1
00032e70  4c8bc2                   mov r8, rdx
00032e73  4889542468               mov qword ptr [rsp + 0x68], rdx
00032e78  e944030000               jmp 0x331c1
00032e7d  b825000000               mov eax, 0x25
00032e82  663b03                   cmp ax, word ptr [rbx]
00032e85  0f8445020000             je 0x330d0
00032e8b  4d85e4                   test r12, r12
00032e8e  0f8451050000             je 0x333e5
00032e94  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
00032e9c  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00032ea4  4c3bef                   cmp r13, rdi
00032ea7  7545                     jne 0x32eee
00032ea9  498bd1                   mov rdx, r9
00032eac  498bce                   mov rcx, r14
00032eaf  41ffd3                   call r11
00032eb2  84c0                     test al, al
00032eb4  0f84c5040000             je 0x3337f
00032eba  8b542434                 mov edx, dword ptr [rsp + 0x34]
00032ebe  4883c702                 add rdi, 2
00032ec2  48897c2458               mov qword ptr [rsp + 0x58], rdi
00032ec7  84d2                     test dl, dl
00032ec9  7423                     je 0x32eee
00032ecb  4c3b642470               cmp r12, qword ptr [rsp + 0x70]
00032ed0  771c                     ja 0x32eee
00032ed2  b920000000               mov ecx, 0x20
00032ed7  0fb6d2                   movzx edx, dl
00032eda  66413b0e                 cmp cx, word ptr [r14]
00032ede  41b800000000             mov r8d, 0
00032ee4  410f45d0                 cmovne edx, r8d
00032ee8  89542434                 mov dword ptr [rsp + 0x34], edx
00032eec  eb03                     jmp 0x32ef1
00032eee  4533c0                   xor r8d, r8d
00032ef1  0fb703                   movzx eax, word ptr [rbx]
00032ef4  4983c502                 add r13, 2
00032ef8  b95f000000               mov ecx, 0x5f
00032efd  663bc8                   cmp cx, ax
00032f00  0f8467010000             je 0x3306d
00032f06  b95b000000               mov ecx, 0x5b
00032f0b  663bc8                   cmp cx, ax
00032f0e  0f854f010000             jne 0x33063
00032f14  488d5302                 lea rdx, [rbx + 2]
00032f18  b85d000000               mov eax, 0x5d
00032f1d  0f1f00                   nop dword ptr [rax]
00032f20  4883c302                 add rbx, 2
00032f24  83ee02                   sub esi, 2
00032f27  85f6                     test esi, esi
00032f29  0f8e51060000             jle 0x33580
00032f2f  4885ed                   test rbp, rbp
00032f32  741f                     je 0x32f53
00032f34  0fb703                   movzx eax, word ptr [rbx]
00032f37  66394500                 cmp word ptr [rbp], ax
00032f3b  7511                     jne 0x32f4e
00032f3d  4883c302                 add rbx, 2
00032f41  83ee02                   sub esi, 2
00032f44  85f6                     test esi, esi
00032f46  0f8e34060000             jle 0x33580
00032f4c  ebca                     jmp 0x32f18
00032f4e  b85d000000               mov eax, 0x5d
00032f53  663b03                   cmp ax, word ptr [rbx]
00032f56  75c8                     jne 0x32f20
00032f58  488bcb                   mov rcx, rbx
00032f5b  4032ff                   xor dil, dil
00032f5e  482bca                   sub rcx, rdx
00032f61  48d1f9                   sar rcx, 1
00032f64  03c9                     add ecx, ecx
00032f66  85c9                     test ecx, ecx
00032f68  0f8ee1000000             jle 0x3304f
00032f6e  b85e000000               mov eax, 0x5e
00032f73  663b02                   cmp ax, word ptr [rdx]
00032f76  751f                     jne 0x32f97
00032f78  4885ed                   test rbp, rbp
00032f7b  7406                     je 0x32f83
00032f7d  66394500                 cmp word ptr [rbp], ax
00032f81  7414                     je 0x32f97
00032f83  8d41fe                   lea eax, [rcx - 2]
00032f86  4883c202                 add rdx, 2
00032f8a  8bc8                     mov ecx, eax
00032f8c  40b701                   mov dil, 1
00032f8f  85c0                     test eax, eax
00032f91  0f8eb8000000             jle 0x3304f
00032f97  450fb71e                 movzx r11d, word ptr [r14]
00032f9b  0f1f440000               nop dword ptr [rax + rax]
00032fa0  4885ed                   test rbp, rbp
00032fa3  740d                     je 0x32fb2
00032fa5  0fb702                   movzx eax, word ptr [rdx]
00032fa8  66394500                 cmp word ptr [rbp], ax
00032fac  7504                     jne 0x32fb2
00032fae  b001                     mov al, 1
00032fb0  eb02                     jmp 0x32fb4
00032fb2  32c0                     xor al, al
00032fb4  84c0                     test al, al
00032fb6  4c8d5202                 lea r10, [rdx + 2]
00032fba  448d49fe                 lea r9d, [rcx - 2]
00032fbe  4c0f44d2                 cmove r10, rdx
00032fc2  440f44c9                 cmove r9d, ecx
00032fc6  66453b1a                 cmp r11w, word ptr [r10]
00032fca  7411                     je 0x32fdd
00032fcc  48c7c0ffffffff           mov rax, 0xffffffffffffffff
00032fd3  41b801000000             mov r8d, 1
00032fd9  440f42c0                 cmovb r8d, eax
00032fdd  418d49fe                 lea ecx, [r9 - 2]
00032fe1  498d5202                 lea rdx, [r10 + 2]
00032fe5  83f901                   cmp ecx, 1
00032fe8  7e50                     jle 0x3303a
00032fea  b82d000000               mov eax, 0x2d
00032fef  663b02                   cmp ax, word ptr [rdx]
00032ff2  7546                     jne 0x3303a
00032ff4  4885ed                   test rbp, rbp
00032ff7  7406                     je 0x32fff
00032ff9  66394500                 cmp word ptr [rbp], ax
00032ffd  743b                     je 0x3303a
00032fff  448d49fe                 lea r9d, [rcx - 2]
00033003  4885ed                   test rbp, rbp
00033006  740e                     je 0x33016
00033008  0fb74202                 movzx eax, word ptr [rdx + 2]
0003300c  66394500                 cmp word ptr [rbp], ax
00033010  7504                     jne 0x33016
00033012  b001                     mov al, 1
00033014  eb02                     jmp 0x33018
00033016  32c0                     xor al, al
00033018  84c0                     test al, al
0003301a  490f44d2                 cmove rdx, r10
0003301e  440f44c9                 cmove r9d, ecx
00033022  4585c0                   test r8d, r8d
00033025  7809                     js 0x33030
00033027  66443b5a04               cmp r11w, word ptr [rdx + 4]
0003302c  741d                     je 0x3304b
0003302e  721b                     jb 0x3304b
00033030  4883c206                 add rdx, 6
00033034  418d49fc                 lea ecx, [r9 - 4]
00033038  eb05                     jmp 0x3303f
0003303a  4585c0                   test r8d, r8d
0003303d  740c                     je 0x3304b
0003303f  85c9                     test ecx, ecx
00033041  7e0c                     jle 0x3304f
00033043  4533c0                   xor r8d, r8d
00033046  e955ffffff               jmp 0x32fa0
0003304b  4080f701                 xor dil, 1
0003304f  8b542434                 mov edx, dword ptr [rsp + 0x34]
00033053  4084ff                   test dil, dil
00033056  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
0003305b  0f84b7fdffff             je 0x32e18
00033061  eb0a                     jmp 0x3306d
00033063  66413b06                 cmp ax, word ptr [r14]
00033067  0f85abfdffff             jne 0x32e18
0003306d  4c8b542478               mov r10, qword ptr [rsp + 0x78]
00033072  4c8b4c2450               mov r9, qword ptr [rsp + 0x50]
00033077  4c8b5c2448               mov r11, qword ptr [rsp + 0x48]
0003307c  4d85c9                   test r9, r9
0003307f  4c8b442438               mov r8, qword ptr [rsp + 0x38]
00033084  498bc3                   mov rax, r11
00033087  490f45c1                 cmovne rax, r9
0003308b  4c8bc8                   mov r9, rax
0003308e  4889442450               mov qword ptr [rsp + 0x50], rax
00033093  498d4602                 lea rax, [r14 + 2]
00033097  493bc2                   cmp rax, r10
0003309a  7313                     jae 0x330af
0003309c  4983ec02                 sub r12, 2
000330a0  4883c302                 add rbx, 2
000330a4  83ee02                   sub esi, 2
000330a7  4c8bf0                   mov r14, rax
000330aa  e9c7fcffff               jmp 0x32d76
000330af  452bf2                   sub r14d, r10d
000330b2  4983ec02                 sub r12, 2
000330b6  4183c602                 add r14d, 2
000330ba  4883c302                 add rbx, 2
000330be  4d03f0                   add r14, r8
000330c1  83ee02                   sub esi, 2
000330c4  e9adfcffff               jmp 0x32d76
000330c9  0f1f8000000000           nop dword ptr [rax]
000330d0  4883c302                 add rbx, 2
000330d4  83ee02                   sub esi, 2
000330d7  0f84b7040000             je 0x33594
000330dd  0fb70b                   movzx ecx, word ptr [rbx]
000330e0  663bc1                   cmp ax, cx
000330e3  74eb                     je 0x330d0
000330e5  33c0                     xor eax, eax
000330e7  48899c2488000000         mov qword ptr [rsp + 0x88], rbx
000330ef  8bf8                     mov edi, eax
000330f1  4889442458               mov qword ptr [rsp + 0x58], rax
000330f6  8d41a5                   lea eax, [rcx - 0x5b]
000330f9  89742440                 mov dword ptr [rsp + 0x40], esi
000330fd  41bdfbff0000             mov r13d, 0xfffb
00033103  4d8bf0                   mov r14, r8
00033106  664185c5                 test r13w, ax
0003310a  7416                     je 0x33122
0003310c  4885ed                   test rbp, rbp
0003310f  7406                     je 0x33117
00033111  66394d00                 cmp word ptr [rbp], cx
00033115  740b                     je 0x33122
00033117  b001                     mov al, 1
00033119  88442430                 mov byte ptr [rsp + 0x30], al
0003311d  e9d2000000               jmp 0x331f4
00033122  32c0                     xor al, al
00033124  88442430                 mov byte ptr [rsp + 0x30], al
00033128  e9c7000000               jmp 0x331f4
0003312d  4d85e4                   test r12, r12
00033130  0f845e040000             je 0x33594
00033136  80bc245801000000         cmp byte ptr [rsp + 0x158], 0
0003313e  0f84d9fcffff             je 0x32e1d
00033144  84d2                     test dl, dl
00033146  0f85d1fcffff             jne 0x32e1d
0003314c  4883bc24a000000000       cmp qword ptr [rsp + 0xa0], 0
00033155  7542                     jne 0x33199
00033157  4c8b8424b8000000         mov r8, qword ptr [rsp + 0xb8]
0003315f  41ba20000000             mov r10d, 0x20
00033165  498bc0                   mov rax, r8
00033168  498bcc                   mov rcx, r12
0003316b  66453b10                 cmp r10w, word ptr [r8]
0003316f  0f85a8fcffff             jne 0x32e1d
00033175  6666660f1f840000000000   nop word ptr [rax + rax]
00033180  488d4002                 lea rax, [rax + 2]
00033184  4883e902                 sub rcx, 2
00033188  0f8406040000             je 0x33594
0003318e  66443b10                 cmp r10w, word ptr [rax]
00033192  74ec                     je 0x33180
00033194  e984fcffff               jmp 0x32e1d
00033199  b201                     mov dl, 1
0003319b  4c89642470               mov qword ptr [rsp + 0x70], r12
000331a0  89542434                 mov dword ptr [rsp + 0x34], edx
000331a4  4c898c2490000000         mov qword ptr [rsp + 0x90], r9
000331ac  e96cfcffff               jmp 0x32e1d
000331b1  452bc2                   sub r8d, r10d
000331b4  4403c0                   add r8d, eax
000331b7  4c03442438               add r8, qword ptr [rsp + 0x38]
000331bc  4c89442468               mov qword ptr [rsp + 0x68], r8
000331c1  488b842498000000         mov rax, qword ptr [rsp + 0x98]
000331c9  4c8be3                   mov r12, rbx
000331cc  8b742440                 mov esi, dword ptr [rsp + 0x40]
000331d0  498bd9                   mov rbx, r9
000331d3  8b542434                 mov edx, dword ptr [rsp + 0x34]
000331d7  482bf9                   sub rdi, rcx
000331da  4c8bc8                   mov r9, rax
000331dd  4889442450               mov qword ptr [rsp + 0x50], rax
000331e2  0fb6442430               movzx eax, byte ptr [rsp + 0x30]
000331e7  4d8bf0                   mov r14, r8
000331ea  4c8b442438               mov r8, qword ptr [rsp + 0x38]
000331ef  48897c2458               mov qword ptr [rsp + 0x58], rdi
000331f4  4d85e4                   test r12, r12
000331f7  0f84e8010000             je 0x333e5
000331fd  33c9                     xor ecx, ecx
000331ff  4c898c2498000000         mov qword ptr [rsp + 0x98], r9
00033207  448be9                   mov r13d, ecx
0003320a  84c0                     test al, al
0003320c  7512                     jne 0x33220
0003320e  4c89742468               mov qword ptr [rsp + 0x68], r14
00033213  4c89a42480000000         mov qword ptr [rsp + 0x80], r12
0003321b  e956fbffff               jmp 0x32d76
00033220  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
00033225  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
0003322d  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
00033235  eb03                     jmp 0x3323a
00033237  488bcf                   mov rcx, rdi
0003323a  498bfd                   mov rdi, r13
0003323d  4c3be9                   cmp r13, rcx
00033240  7549                     jne 0x3328b
00033242  498bd1                   mov rdx, r9
00033245  498bce                   mov rcx, r14
00033248  41ffd3                   call r11
0003324b  84c0                     test al, al
0003324d  0f8439010000             je 0x3338c
00033253  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
00033258  8b542434                 mov edx, dword ptr [rsp + 0x34]
0003325c  4883c102                 add rcx, 2
00033260  48894c2458               mov qword ptr [rsp + 0x58], rcx
00033265  84d2                     test dl, dl
00033267  7422                     je 0x3328b
00033269  4c3b642470               cmp r12, qword ptr [rsp + 0x70]
0003326e  771b                     ja 0x3328b
00033270  0fb6c2                   movzx eax, dl
00033273  ba20000000               mov edx, 0x20
00033278  66413b16                 cmp dx, word ptr [r14]
0003327c  ba00000000               mov edx, 0
00033281  0f45c2                   cmovne eax, edx
00033284  0fb6d0                   movzx edx, al
00033287  89542434                 mov dword ptr [rsp + 0x34], edx
0003328b  410fb706                 movzx eax, word ptr [r14]
0003328f  4983c502                 add r13, 2
00033293  663903                   cmp word ptr [rbx], ax
00033296  7462                     je 0x332fa
00033298  4983ec02                 sub r12, 2
0003329c  0f8443010000             je 0x333e5
000332a2  48ff442448               inc qword ptr [rsp + 0x48]
000332a7  498d4602                 lea rax, [r14 + 2]
000332ab  4c8b542478               mov r10, qword ptr [rsp + 0x78]
000332b0  4883e902                 sub rcx, 2
000332b4  48894c2458               mov qword ptr [rsp + 0x58], rcx
000332b9  4c8bef                   mov r13, rdi
000332bc  493bc2                   cmp rax, r10
000332bf  7318                     jae 0x332d9
000332c1  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
000332c9  4c8bf0                   mov r14, rax
000332cc  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
000332d4  e961ffffff               jmp 0x3323a
000332d9  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
000332e1  452bf2                   sub r14d, r10d
000332e4  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
000332ec  4183c602                 add r14d, 2
000332f0  4c03742438               add r14, qword ptr [rsp + 0x38]
000332f5  e940ffffff               jmp 0x3323a
000332fa  4c8b4c2450               mov r9, qword ptr [rsp + 0x50]
000332ff  4d8bc6                   mov r8, r14
00033302  4c8b5c2448               mov r11, qword ptr [rsp + 0x48]
00033307  4d85c9                   test r9, r9
0003330a  4c8b542478               mov r10, qword ptr [rsp + 0x78]
0003330f  4d0f44cb                 cmove r9, r11
00033313  4c89742468               mov qword ptr [rsp + 0x68], r14
00033318  4983c602                 add r14, 2
0003331c  4c89a42480000000         mov qword ptr [rsp + 0x80], r12
00033324  4c894c2450               mov qword ptr [rsp + 0x50], r9
00033329  4d3bf2                   cmp r14, r10
0003332c  731a                     jae 0x33348
0003332e  4c8b442438               mov r8, qword ptr [rsp + 0x38]
00033333  4983ec02                 sub r12, 2
00033337  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
0003333c  4883c302                 add rbx, 2
00033340  83ee02                   sub esi, 2
00033343  e92efaffff               jmp 0x32d76
00033348  488b7c2458               mov rdi, qword ptr [rsp + 0x58]
0003334d  4d8bf0                   mov r14, r8
00033350  4c8b442438               mov r8, qword ptr [rsp + 0x38]
00033355  4d2bf2                   sub r14, r10
00033358  4983c602                 add r14, 2
0003335c  4983ec02                 sub r12, 2
00033360  458bf6                   mov r14d, r14d
00033363  4883c302                 add rbx, 2
00033367  4d03f0                   add r14, r8
0003336a  83ee02                   sub esi, 2
0003336d  e904faffff               jmp 0x32d76
00033372  41c7471403000000         mov dword ptr [r15 + 0x14], 3
0003337a  e910010000               jmp 0x3348f
0003337f  41c7471404000000         mov dword ptr [r15 + 0x14], 4
00033387  e903010000               jmp 0x3348f
0003338c  488b442450               mov rax, qword ptr [rsp + 0x50]
00033391  49894720                 mov qword ptr [r15 + 0x20], rax
00033395  8b442434                 mov eax, dword ptr [rsp + 0x34]
00033399  41884728                 mov byte ptr [r15 + 0x28], al
0003339d  488b442470               mov rax, qword ptr [rsp + 0x70]
000333a2  49894730                 mov qword ptr [r15 + 0x30], rax
000333a6  488b842490000000         mov rax, qword ptr [rsp + 0x90]
000333ae  49894738                 mov qword ptr [r15 + 0x38], rax
000333b2  488b442448               mov rax, qword ptr [rsp + 0x48]
000333b7  49894740                 mov qword ptr [r15 + 0x40], rax
000333bb  8b442440                 mov eax, dword ptr [rsp + 0x40]
000333bf  41894748                 mov dword ptr [r15 + 0x48], eax
000333c3  488b842480000000         mov rax, qword ptr [rsp + 0x80]
000333cb  49894750                 mov qword ptr [r15 + 0x50], rax
000333cf  488b442458               mov rax, qword ptr [rsp + 0x58]
000333d4  49894758                 mov qword ptr [r15 + 0x58], rax
000333d8  41c7471405000000         mov dword ptr [r15 + 0x14], 5
000333e0  e9f1000000               jmp 0x334d6
000333e5  84d2                     test dl, dl
000333e7  0f8493010000             je 0x33580
000333ed  488b9424b0000000         mov rdx, qword ptr [rsp + 0xb0]
000333f5  4885d2                   test rdx, rdx
000333f8  0f84bd010000             je 0x335bb
000333fe  488b842490000000         mov rax, qword ptr [rsp + 0x90]
00033406  b901000000               mov ecx, 1
0003340b  4885c0                   test rax, rax
0003340e  480f45c8                 cmovne rcx, rax
00033412  48890a                   mov qword ptr [rdx], rcx
00033415  e9a1010000               jmp 0x335bb
0003341a  84d2                     test dl, dl
0003341c  0f845e010000             je 0x33580
00033422  4c8b4c2450               mov r9, qword ptr [rsp + 0x50]
00033427  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
0003342f  80bc245801000000         cmp byte ptr [rsp + 0x158], 0
00033437  0f843e010000             je 0x3357b
0003343d  4d85e4                   test r12, r12
00033440  0f8445010000             je 0x3358b
00033446  4c8b8c24a8000000         mov r9, qword ptr [rsp + 0xa8]
0003344e  498bd1                   mov rdx, r9
00033451  488d8c24c0000000         lea rcx, [rsp + 0xc0]
00033459  41ffd3                   call r11
0003345c  84c0                     test al, al
0003345e  7427                     je 0x33487
00033460  b820000000               mov eax, 0x20
00033465  663b8424c0000000         cmp ax, word ptr [rsp + 0xc0]
0003346d  0f850d010000             jne 0x33580
00033473  4c8b9c24a0000000         mov r11, qword ptr [rsp + 0xa0]
0003347b  4983ec02                 sub r12, 2
0003347f  ebbc                     jmp 0x3343d
00033481  8b542434                 mov edx, dword ptr [rsp + 0x34]
00033485  eba8                     jmp 0x3342f
00033487  41c7471406000000         mov dword ptr [r15 + 0x14], 6
0003348f  488b442450               mov rax, qword ptr [rsp + 0x50]
00033494  49894720                 mov qword ptr [r15 + 0x20], rax
00033498  8b442434                 mov eax, dword ptr [rsp + 0x34]
0003349c  41884728                 mov byte ptr [r15 + 0x28], al
000334a0  488b442470               mov rax, qword ptr [rsp + 0x70]
000334a5  49894730                 mov qword ptr [r15 + 0x30], rax
000334a9  488b842490000000         mov rax, qword ptr [rsp + 0x90]
000334b1  49894738                 mov qword ptr [r15 + 0x38], rax
000334b5  488b442448               mov rax, qword ptr [rsp + 0x48]
000334ba  49894740                 mov qword ptr [r15 + 0x40], rax
000334be  8b442440                 mov eax, dword ptr [rsp + 0x40]
000334c2  41894748                 mov dword ptr [r15 + 0x48], eax
000334c6  488b842480000000         mov rax, qword ptr [rsp + 0x80]
000334ce  49894750                 mov qword ptr [r15 + 0x50], rax
000334d2  49897f58                 mov qword ptr [r15 + 0x58], rdi
000334d6  488b842498000000         mov rax, qword ptr [rsp + 0x98]
000334de  488b542460               mov rdx, qword ptr [rsp + 0x60]
000334e3  49894768                 mov qword ptr [r15 + 0x68], rax
000334e7  8b442444                 mov eax, dword ptr [rsp + 0x44]
000334eb  41894770                 mov dword ptr [r15 + 0x70], eax
000334ef  0fb6442430               movzx eax, byte ptr [rsp + 0x30]
000334f4  41884774                 mov byte ptr [r15 + 0x74], al
000334f8  48c7c0ffffffff           mov rax, 0xffffffffffffffff
000334ff  4d896708                 mov qword ptr [r15 + 8], r12
00033503  41897718                 mov dword ptr [r15 + 0x18], esi
00033507  4d896f60                 mov qword ptr [r15 + 0x60], r13
0003350b  4885db                   test rbx, rbx
0003350e  7505                     jne 0x33515
00033510  488bd8                   mov rbx, rax
00033513  eb06                     jmp 0x3351b
00033515  482bda                   sub rbx, rdx
00033518  48d1fb                   sar rbx, 1
0003351b  488b8c2488000000         mov rcx, qword ptr [rsp + 0x88]
00033523  49899fc81f0000           mov qword ptr [r15 + 0x1fc8], rbx
0003352a  4885c9                   test rcx, rcx
0003352d  7505                     jne 0x33534
0003352f  488bc8                   mov rcx, rax
00033532  eb06                     jmp 0x3353a
00033534  482bca                   sub rcx, rdx
00033537  48d1f9                   sar rcx, 1
0003353a  488b542438               mov rdx, qword ptr [rsp + 0x38]
0003353f  49898fd01f0000           mov qword ptr [r15 + 0x1fd0], rcx
00033546  488b4c2468               mov rcx, qword ptr [rsp + 0x68]
0003354b  4885c9                   test rcx, rcx
0003354e  7505                     jne 0x33555
00033550  488bc8                   mov rcx, rax
00033553  eb06                     jmp 0x3355b
00033555  482bca                   sub rcx, rdx
00033558  48d1f9                   sar rcx, 1
0003355b  49898fd81f0000           mov qword ptr [r15 + 0x1fd8], rcx
00033562  4d85f6                   test r14, r14
00033565  7409                     je 0x33570
00033567  498bc6                   mov rax, r14
0003356a  482bc2                   sub rax, rdx
0003356d  48d1f8                   sar rax, 1
00033570  498987e01f0000           mov qword ptr [r15 + 0x1fe0], rax
00033577  32c0                     xor al, al
00033579  eb49                     jmp 0x335c4
0003357b  4d85e4                   test r12, r12
0003357e  7414                     je 0x33594
00033580  6641c747100100           mov word ptr [r15 + 0x10], 1
00033587  32c0                     xor al, al
00033589  eb39                     jmp 0x335c4
0003358b  4c8b4c2450               mov r9, qword ptr [rsp + 0x50]
00033590  8b542434                 mov edx, dword ptr [rsp + 0x34]
00033594  488b8c24b0000000         mov rcx, qword ptr [rsp + 0xb0]
0003359c  4885c9                   test rcx, rcx
0003359f  741a                     je 0x335bb
000335a1  84d2                     test dl, dl
000335a3  b801000000               mov eax, 1
000335a8  4c0f458c2490000000       cmovne r9, qword ptr [rsp + 0x90]
000335b1  4d85c9                   test r9, r9
000335b4  4c0f44c8                 cmove r9, rax
000335b8  4c8909                   mov qword ptr [rcx], r9
000335bb  b001                     mov al, 1
000335bd  6641c747100101           mov word ptr [r15 + 0x10], 0x101
000335c4  4c8bac24d8000000         mov r13, qword ptr [rsp + 0xd8]
000335cc  4c8ba424e0000000         mov r12, qword ptr [rsp + 0xe0]
000335d4  488bbc2418010000         mov rdi, qword ptr [rsp + 0x118]
000335dc  4c8bb424d0000000         mov r14, qword ptr [rsp + 0xd0]
000335e4  488b8c24c8000000         mov rcx, qword ptr [rsp + 0xc8]
000335ec  4833cc                   xor rcx, rsp
000335ef  e87c980200               call 0x5ce70
000335f4  4881c4e8000000           add rsp, 0xe8
000335fb  415f                     pop r15
000335fd  5e                       pop rsi
000335fe  5d                       pop rbp
000335ff  5b                       pop rbx
00033600  c3                       ret

; chunk at RVA 0x33601 (27 bytes)
00033601  ba4b000000               mov edx, 0x4b
00033606  4489442420               mov dword ptr [rsp + 0x20], r8d
0003360b  8d4ad0                   lea ecx, [rdx - 0x30]
0003360e  448d4ab6                 lea r9d, [rdx - 0x4a]
00033612  448d42c5                 lea r8d, [rdx - 0x3b]
00033616  e8255efeff               call 0x19440
0003361b  cc                       int3

; chunk at RVA 0x3361c (56 bytes)
0003361c  41b9d8040000             mov r9d, 0x4d8
00033622  4c89542420               mov qword ptr [rsp + 0x20], r10
00033627  4c8d05a2b70600           lea r8, [rip + 0x6b7a2]
0003362e  488d15f3c30600           lea rdx, [rip + 0x6c3f3]
00033635  e8e65dfeff               call 0x19420
0003363a  cc                       int3
0003363b  90                       nop
0003363c  5b                       pop rbx
0003363d  2c03                     sub al, 3
0003363f  00a92c0300bc             add byte ptr [rcx - 0x43fffcd4], ch
00033645  2d0300a42e               sub eax, 0x2ea40003
0003364a  0300                     add eax, dword ptr [rax]
