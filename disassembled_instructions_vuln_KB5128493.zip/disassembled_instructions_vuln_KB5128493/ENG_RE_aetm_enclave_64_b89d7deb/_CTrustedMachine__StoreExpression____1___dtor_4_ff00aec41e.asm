; `CTrustedMachine::StoreExpression'::`1'::dtor$4
; aetm_enclave.dll, primary RVA 0x5ffc0, 28 bytes in 1 chunk(s)

; chunk at RVA 0x5ffc0 (28 bytes)
0005ffc0  4055                     push rbp
0005ffc2  4883ec20                 sub rsp, 0x20
0005ffc6  488bea                   mov rbp, rdx
0005ffc9  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0005ffcd  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
0005ffd1  e8aa99fbff               call 0x19980
0005ffd6  4883c420                 add rsp, 0x20
0005ffda  5d                       pop rbp
0005ffdb  c3                       ret
