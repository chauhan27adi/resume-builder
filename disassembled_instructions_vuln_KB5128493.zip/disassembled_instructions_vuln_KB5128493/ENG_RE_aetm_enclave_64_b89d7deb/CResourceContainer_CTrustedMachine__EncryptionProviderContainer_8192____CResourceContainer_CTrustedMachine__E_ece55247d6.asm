; CResourceContainer<CTrustedMachine::EncryptionProviderContainer,8192>::~CResourceContainer<CTrustedMachine::EncryptionProviderContainer,8192>
; aetm_enclave.dll, primary RVA 0x9a30, 45 bytes in 1 chunk(s)

; chunk at RVA 0x9a30 (45 bytes)
00009a30  48894c2408               mov qword ptr [rsp + 8], rcx
00009a35  4883ec38                 sub rsp, 0x38
00009a39  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00009a42  4c8d0d67000000           lea r9, [rip + 0x67]
00009a49  ba30000000               mov edx, 0x30
00009a4e  41b800200000             mov r8d, 0x2000
00009a54  4883c438                 add rsp, 0x38
00009a58  e9c3340500               jmp 0x5cf20
