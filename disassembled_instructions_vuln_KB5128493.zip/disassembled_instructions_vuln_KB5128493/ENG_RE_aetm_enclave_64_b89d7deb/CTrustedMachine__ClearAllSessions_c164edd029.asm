; CTrustedMachine::ClearAllSessions
; aetm_enclave.dll, primary RVA 0xde40, 281 bytes in 1 chunk(s)

; chunk at RVA 0xde40 (281 bytes)
0000de40  48895c2408               mov qword ptr [rsp + 8], rbx
0000de45  48896c2410               mov qword ptr [rsp + 0x10], rbp
0000de4a  4889742418               mov qword ptr [rsp + 0x18], rsi
0000de4f  48897c2420               mov qword ptr [rsp + 0x20], rdi
0000de54  4156                     push r14
0000de56  4883ec20                 sub rsp, 0x20
0000de5a  488da9b03a0000           lea rbp, [rcx + 0x3ab0]
0000de61  90                       nop
0000de62  0fb681c8420000           movzx eax, byte ptr [rcx + 0x42c8]
0000de69  488d99b03a4100           lea rbx, [rcx + 0x413ab0]
0000de70  488bf1                   mov rsi, rcx
0000de73  4c8bc5                   mov r8, rbp
0000de76  483beb                   cmp rbp, rbx
0000de79  731e                     jae 0xde99
0000de7b  0f1f440000               nop dword ptr [rax + rax]
0000de80  84c0                     test al, al
0000de82  7515                     jne 0xde99
0000de84  4981c020080000           add r8, 0x820
0000de8b  90                       nop
0000de8c  410fb68018080000         movzx eax, byte ptr [r8 + 0x818]
0000de94  4c3bc3                   cmp r8, rbx
0000de97  72e7                     jb 0xde80
0000de99  49bec10ffcc00ffcc00f     movabs r14, 0xfc0fc0fc0fc0fc1
0000dea3  0f1f4000                 nop dword ptr [rax]
0000dea7  660f1f840000000000       nop word ptr [rax + rax]
0000deb0  90                       nop
0000deb1  0fb68318080000           movzx eax, byte ptr [rbx + 0x818]
0000deb8  498bf8                   mov rdi, r8
0000debb  4c3bc3                   cmp r8, rbx
0000debe  747e                     je 0xdf3e
0000dec0  90                       nop
0000dec1  498bc8                   mov rcx, r8
0000dec4  410fb68018080000         movzx eax, byte ptr [r8 + 0x818]
0000decc  482bcd                   sub rcx, rbp
0000decf  90                       nop
0000ded0  498bc6                   mov rax, r14
0000ded3  48f7e9                   imul rcx
0000ded6  488bce                   mov rcx, rsi
0000ded9  48c1fa07                 sar rdx, 7
0000dedd  488bc2                   mov rax, rdx
0000dee0  48c1e83f                 shr rax, 0x3f
0000dee4  4803d0                   add rdx, rax
0000dee7  498b8010080000           mov rax, qword ptr [r8 + 0x810]
0000deee  4863d2                   movsxd rdx, edx
0000def1  48c1e220                 shl rdx, 0x20
0000def5  48c1e820                 shr rax, 0x20
0000def9  480bd0                   or rdx, rax
0000defc  e86ffeffff               call 0xdd70
0000df01  483bfb                   cmp rdi, rbx
0000df04  4c8d8720080000           lea r8, [rdi + 0x820]
0000df0b  90                       nop
0000df0c  4c0f43c7                 cmovae r8, rdi
0000df10  410fb68018080000         movzx eax, byte ptr [r8 + 0x818]
0000df18  4c3bc3                   cmp r8, rbx
0000df1b  7393                     jae 0xdeb0
0000df1d  0f1f00                   nop dword ptr [rax]
0000df20  84c0                     test al, al
0000df22  758c                     jne 0xdeb0
0000df24  4981c020080000           add r8, 0x820
0000df2b  90                       nop
0000df2c  410fb68018080000         movzx eax, byte ptr [r8 + 0x818]
0000df34  4c3bc3                   cmp r8, rbx
0000df37  72e7                     jb 0xdf20
0000df39  e972ffffff               jmp 0xdeb0
0000df3e  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0000df43  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
0000df48  488b742440               mov rsi, qword ptr [rsp + 0x40]
0000df4d  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
0000df52  4883c420                 add rsp, 0x20
0000df56  415e                     pop r14
0000df58  c3                       ret
