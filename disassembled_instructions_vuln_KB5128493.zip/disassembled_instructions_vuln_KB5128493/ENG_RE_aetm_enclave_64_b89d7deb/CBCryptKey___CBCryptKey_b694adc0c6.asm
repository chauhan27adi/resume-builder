; CBCryptKey::~CBCryptKey
; aetm_enclave.dll, primary RVA 0x18700, 42 bytes in 1 chunk(s)

; chunk at RVA 0x18700 (42 bytes)
00018700  48894c2408               mov qword ptr [rsp + 8], rcx
00018705  4883ec38                 sub rsp, 0x38
00018709  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00018712  488b09                   mov rcx, qword ptr [rcx]
00018715  4885c9                   test rcx, rcx
00018718  740b                     je 0x18725
0001871a  4883c438                 add rsp, 0x38
0001871e  48ff25b3a90400           jmp qword ptr [rip + 0x4a9b3]
00018725  4883c438                 add rsp, 0x38
00018729  c3                       ret
