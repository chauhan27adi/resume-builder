; CSqlSortManager_140::GetNextSortID
; aetm_enclave.dll, primary RVA 0x58600, 4384 bytes in 1 chunk(s)

; chunk at RVA 0x58600 (4384 bytes)
00058600  48895c2408               mov qword ptr [rsp + 8], rbx
00058605  4889742410               mov qword ptr [rsp + 0x10], rsi
0005860a  48897c2418               mov qword ptr [rsp + 0x18], rdi
0005860f  55                       push rbp
00058610  4154                     push r12
00058612  4155                     push r13
00058614  4156                     push r14
00058616  4157                     push r15
00058618  488d6c24e0               lea rbp, [rsp - 0x20]
0005861d  4881ec20010000           sub rsp, 0x120
00058624  488b05dd290500           mov rax, qword ptr [rip + 0x529dd]
0005862b  4833c4                   xor rax, rsp
0005862e  48894510                 mov qword ptr [rbp + 0x10], rax
00058632  418b4010                 mov eax, dword ptr [r8 + 0x10]
00058636  4533e4                   xor r12d, r12d
00058639  44894d88                 mov dword ptr [rbp - 0x78], r9d
0005863d  498bf8                   mov rdi, r8
00058640  448bc8                   mov r9d, eax
00058643  48894d98                 mov qword ptr [rbp - 0x68], rcx
00058647  8bc8                     mov ecx, eax
00058649  41c1e91a                 shr r9d, 0x1a
0005864d  c1e803                   shr eax, 3
00058650  4180e101                 and r9b, 1
00058654  2401                     and al, 1
00058656  d1e9                     shr ecx, 1
00058658  80e101                   and cl, 1
0005865b  894594                   mov dword ptr [rbp - 0x6c], eax
0005865e  418b8088000000           mov eax, dword ptr [r8 + 0x88]
00058665  4c8bd2                   mov r10, rdx
00058668  458bdc                   mov r11d, r12d
0005866b  4889542450               mov qword ptr [rsp + 0x50], rdx
00058670  4489642444               mov dword ptr [rsp + 0x44], r12d
00058675  4489642474               mov dword ptr [rsp + 0x74], r12d
0005867a  448964245c               mov dword ptr [rsp + 0x5c], r12d
0005867f  894d90                   mov dword ptr [rbp - 0x70], ecx
00058682  44894c2468               mov dword ptr [rsp + 0x68], r9d
00058687  c644244801               mov byte ptr [rsp + 0x48], 1
0005868c  413b8084000000           cmp eax, dword ptr [r8 + 0x84]
00058693  0f855c0f0000             jne 0x595f5
00058699  488b8588000000           mov rax, qword ptr [rbp + 0x88]
000586a0  4885c0                   test rax, rax
000586a3  7403                     je 0x586a8
000586a5  448818                   mov byte ptr [rax], r11b
000586a8  0fb744246c               movzx eax, word ptr [rsp + 0x6c]
000586ad  4d8d703c                 lea r14, [r8 + 0x3c]
000586b1  8b9d80000000             mov ebx, dword ptr [rbp + 0x80]
000586b7  6689442464               mov word ptr [rsp + 0x64], ax
000586bc  eb12                     jmp 0x586d0
000586be  6690                     nop
000586c0  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000586c5  4533e4                   xor r12d, r12d
000586c8  448b4c2468               mov r9d, dword ptr [rsp + 0x68]
000586cd  0f1f00                   nop dword ptr [rax]
000586d0  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
000586d4  418bf3                   mov esi, r11d
000586d7  4183f801                 cmp r8d, 1
000586db  7d60                     jge 0x5873d
000586dd  488b4730                 mov rax, qword ptr [rdi + 0x30]
000586e1  4885c0                   test rax, rax
000586e4  7e48                     jle 0x5872e
000586e6  488b4718                 mov rax, qword ptr [rdi + 0x18]
000586ea  4885c0                   test rax, rax
000586ed  740b                     je 0x586fa
000586ef  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000586f3  ffd0                     call rax
000586f5  0fb7c8                   movzx ecx, ax
000586f8  eb12                     jmp 0x5870c
000586fa  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000586fe  488b4728                 mov rax, qword ptr [rdi + 0x28]
00058702  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00058706  8d4201                   lea eax, [rdx + 1]
00058709  894738                   mov dword ptr [rdi + 0x38], eax
0005870c  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00058710  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00058715  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
00058719  48ff4f30                 dec qword ptr [rdi + 0x30]
0005871d  41ffc0                   inc r8d
00058720  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058724  4489475c                 mov dword ptr [rdi + 0x5c], r8d
00058728  4183f801                 cmp r8d, 1
0005872c  7cb3                     jl 0x586e1
0005872e  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00058733  448b4c2468               mov r9d, dword ptr [rsp + 0x68]
00058738  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
0005873d  4585c0                   test r8d, r8d
00058740  0f84ec0e0000             je 0x59632
00058746  8b8780000000             mov eax, dword ptr [rdi + 0x80]
0005874c  398788000000             cmp dword ptr [rdi + 0x88], eax
00058752  0f8dd30e0000             jge 0x5962b
00058758  498b4208                 mov rax, qword ptr [r10 + 8]
0005875c  41bd01000000             mov r13d, 1
00058762  410fb70e                 movzx ecx, word ptr [r14]
00058766  4489642460               mov dword ptr [rsp + 0x60], r12d
0005876b  4532e4                   xor r12b, r12b
0005876e  c644245800               mov byte ptr [rsp + 0x58], 0
00058773  448b3c88                 mov r15d, dword ptr [rax + rcx*4]
00058777  418bc7                   mov eax, r15d
0005877a  44897c2440               mov dword ptr [rsp + 0x40], r15d
0005877f  c1e818                   shr eax, 0x18
00058782  837f0400                 cmp dword ptr [rdi + 4], 0
00058786  0f84a9000000             je 0x58835
0005878c  663b4f0c                 cmp cx, word ptr [rdi + 0xc]
00058790  0f859f000000             jne 0x58835
00058796  4183f802                 cmp r8d, 2
0005879a  7d51                     jge 0x587ed
0005879c  488b4730                 mov rax, qword ptr [rdi + 0x30]
000587a0  4885c0                   test rax, rax
000587a3  7e48                     jle 0x587ed
000587a5  488b4718                 mov rax, qword ptr [rdi + 0x18]
000587a9  4885c0                   test rax, rax
000587ac  740b                     je 0x587b9
000587ae  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000587b2  ffd0                     call rax
000587b4  0fb7c8                   movzx ecx, ax
000587b7  eb12                     jmp 0x587cb
000587b9  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000587bd  488b4728                 mov rax, qword ptr [rdi + 0x28]
000587c1  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
000587c5  8d4201                   lea eax, [rdx + 1]
000587c8  894738                   mov dword ptr [rdi + 0x38], eax
000587cb  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
000587cf  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
000587d4  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
000587d8  48ff4f30                 dec qword ptr [rdi + 0x30]
000587dc  41ffc0                   inc r8d
000587df  488b4730                 mov rax, qword ptr [rdi + 0x30]
000587e3  4489475c                 mov dword ptr [rdi + 0x5c], r8d
000587e7  4183f802                 cmp r8d, 2
000587eb  7cb3                     jl 0x587a0
000587ed  453bc5                   cmp r8d, r13d
000587f0  0f842e0e0000             je 0x59624
000587f6  418d40ff                 lea eax, [r8 - 1]
000587fa  498bce                   mov rcx, r14
000587fd  4c63c0                   movsxd r8, eax
00058800  488d573e                 lea rdx, [rdi + 0x3e]
00058804  4d03c0                   add r8, r8
00058807  e8b35a0000               call 0x5e2bf
0005880c  ff4f5c                   dec dword ptr [rdi + 0x5c]
0005880f  4c8d05ea77faff           lea r8, [rip - 0x58816]
00058816  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0005881b  410fb70e                 movzx ecx, word ptr [r14]
0005881f  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058823  488b4308                 mov rax, qword ptr [rbx + 8]
00058827  448b3c88                 mov r15d, dword ptr [rax + rcx*4]
0005882b  44897c2440               mov dword ptr [rsp + 0x40], r15d
00058830  e95a040000               jmp 0x58c8f
00058835  32db                     xor bl, bl
00058837  41837a1400               cmp dword ptr [r10 + 0x14], 0
0005883c  0f842a010000             je 0x5896c
00058842  8b4c245c                 mov ecx, dword ptr [rsp + 0x5c]
00058846  a8c0                     test al, 0xc0
00058848  0f849f010000             je 0x589ed
0005884e  49837a3000               cmp qword ptr [r10 + 0x30], 0
00058853  0f8494010000             je 0x589ed
00058859  85c9                     test ecx, ecx
0005885b  0f858c010000             jne 0x589ed
00058861  4585db                   test r11d, r11d
00058864  0f8583010000             jne 0x589ed
0005886a  4183f808                 cmp r8d, 8
0005886e  7d56                     jge 0x588c6
00058870  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058874  4885c0                   test rax, rax
00058877  7e48                     jle 0x588c1
00058879  488b4718                 mov rax, qword ptr [rdi + 0x18]
0005887d  4885c0                   test rax, rax
00058880  740b                     je 0x5888d
00058882  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00058886  ffd0                     call rax
00058888  0fb7c8                   movzx ecx, ax
0005888b  eb12                     jmp 0x5889f
0005888d  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
00058891  488b4728                 mov rax, qword ptr [rdi + 0x28]
00058895  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00058899  8d4201                   lea eax, [rdx + 1]
0005889c  894738                   mov dword ptr [rdi + 0x38], eax
0005889f  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
000588a3  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
000588a8  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
000588ac  48ff4f30                 dec qword ptr [rdi + 0x30]
000588b0  41ffc0                   inc r8d
000588b3  488b4730                 mov rax, qword ptr [rdi + 0x30]
000588b7  4489475c                 mov dword ptr [rdi + 0x5c], r8d
000588bb  4183f808                 cmp r8d, 8
000588bf  7cb3                     jl 0x58874
000588c1  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000588c6  33c0                     xor eax, eax
000588c8  4c8975b0                 mov qword ptr [rbp - 0x50], r14
000588cc  488945c0                 mov qword ptr [rbp - 0x40], rax
000588d0  4c8d4da0                 lea r9, [rbp - 0x60]
000588d4  410fbaf01f               btr r8d, 0x1f
000588d9  410fb7c7                 movzx eax, r15w
000588dd  48c1e020                 shl rax, 0x20
000588e1  488d55b0                 lea rdx, [rbp - 0x50]
000588e5  448945b8                 mov dword ptr [rbp - 0x48], r8d
000588e9  498bcf                   mov rcx, r15
000588ec  48c1e910                 shr rcx, 0x10
000588f0  4d8bc2                   mov r8, r10
000588f3  480bc1                   or rax, rcx
000588f6  4c8975c8                 mov qword ptr [rbp - 0x38], r14
000588fa  488945a0                 mov qword ptr [rbp - 0x60], rax
000588fe  e8cdd5ffff               call 0x55ed0
00058903  85c0                     test eax, eax
00058905  7450                     je 0x58957
00058907  8b475c                   mov eax, dword ptr [rdi + 0x5c]
0005890a  498bce                   mov rcx, r14
0005890d  488b5db0                 mov rbx, qword ptr [rbp - 0x50]
00058911  482b5dc8                 sub rbx, qword ptr [rbp - 0x38]
00058915  48d1fb                   sar rbx, 1
00058918  2bc3                     sub eax, ebx
0005891a  4c63c0                   movsxd r8, eax
0005891d  4863c3                   movsxd rax, ebx
00058920  4d03c0                   add r8, r8
00058923  4883c01e                 add rax, 0x1e
00058927  488d1447                 lea rdx, [rdi + rax*2]
0005892b  e88f590000               call 0x5e2bf
00058930  488b45a0                 mov rax, qword ptr [rbp - 0x60]
00058934  295f5c                   sub dword ptr [rdi + 0x5c], ebx
00058937  4c8bf8                   mov r15, rax
0005893a  488bc8                   mov rcx, rax
0005893d  49c1ef20                 shr r15, 0x20
00058941  48c1e110                 shl rcx, 0x10
00058945  410fb6dd                 movzx ebx, r13b
00058949  440bf9                   or r15d, ecx
0005894c  48c1e810                 shr rax, 0x10
00058950  0fb7d0                   movzx edx, ax
00058953  89542460                 mov dword ptr [rsp + 0x60], edx
00058957  4c8b542450               mov r10, qword ptr [rsp + 0x50]
0005895c  4181e7ffffff3f           and r15d, 0x3fffffff
00058963  44897c2440               mov dword ptr [rsp + 0x40], r15d
00058968  84db                     test bl, bl
0005896a  7533                     jne 0x5899f
0005896c  4438642468               cmp byte ptr [rsp + 0x68], r12b
00058971  742c                     je 0x5899f
00058973  b800280000               mov eax, 0x2800
00058978  b9ff030000               mov ecx, 0x3ff
0005897d  66410306                 add ax, word ptr [r14]
00058981  663bc1                   cmp ax, cx
00058984  7719                     ja 0x5899f
00058986  4c8d4c2440               lea r9, [rsp + 0x40]
0005898b  4c8bc7                   mov r8, rdi
0005898e  498bd2                   mov rdx, r10
00058991  e88a61ffff               call 0x4eb20
00058996  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
0005899b  440fb6e0                 movzx r12d, al
0005899f  837f0400                 cmp dword ptr [rdi + 4], 0
000589a3  0f84d6020000             je 0x58c7f
000589a9  837c245c00               cmp dword ptr [rsp + 0x5c], 0
000589ae  0f85cb020000             jne 0x58c7f
000589b4  8b5c2474                 mov ebx, dword ptr [rsp + 0x74]
000589b8  4c8d054176faff           lea r8, [rip - 0x589bf]
000589bf  410fb706                 movzx eax, word ptr [r14]
000589c3  ffc3                     inc ebx
000589c5  83c0db                   add eax, -0x25
000589c8  895c2474                 mov dword ptr [rsp + 0x74], ebx
000589cc  83f83a                   cmp eax, 0x3a
000589cf  0f87a4020000             ja 0x58c79
000589d5  4898                     cdqe
000589d7  410fb68400cc960500       movzx eax, byte ptr [r8 + rax + 0x596cc]
000589e0  418b8c80b0960500         mov ecx, dword ptr [r8 + rax*4 + 0x596b0]
000589e8  4903c8                   add rcx, r8
000589eb  ffe1                     jmp rcx
000589ed  410fb7c7                 movzx eax, r15w
000589f1  66c1e808                 shr ax, 8
000589f5  3cfe                     cmp al, 0xfe
000589f7  0f855fffffff             jne 0x5895c
000589fd  49837a3800               cmp qword ptr [r10 + 0x38], 0
00058a02  0f8454ffffff             je 0x5895c
00058a08  85c9                     test ecx, ecx
00058a0a  0f854cffffff             jne 0x5895c
00058a10  4585db                   test r11d, r11d
00058a13  7409                     je 0x58a1e
00058a15  4584c9                   test r9b, r9b
00058a18  0f843effffff             je 0x5895c
00058a1e  4183f802                 cmp r8d, 2
00058a22  7d56                     jge 0x58a7a
00058a24  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058a28  4885c0                   test rax, rax
00058a2b  7e48                     jle 0x58a75
00058a2d  488b4718                 mov rax, qword ptr [rdi + 0x18]
00058a31  4885c0                   test rax, rax
00058a34  740b                     je 0x58a41
00058a36  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00058a3a  ffd0                     call rax
00058a3c  0fb7c8                   movzx ecx, ax
00058a3f  eb12                     jmp 0x58a53
00058a41  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
00058a45  488b4728                 mov rax, qword ptr [rdi + 0x28]
00058a49  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00058a4d  8d4201                   lea eax, [rdx + 1]
00058a50  894738                   mov dword ptr [rdi + 0x38], eax
00058a53  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
00058a57  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00058a5c  448b475c                 mov r8d, dword ptr [rdi + 0x5c]
00058a60  48ff4f30                 dec qword ptr [rdi + 0x30]
00058a64  41ffc0                   inc r8d
00058a67  488b4730                 mov rax, qword ptr [rdi + 0x30]
00058a6b  4489475c                 mov dword ptr [rdi + 0x5c], r8d
00058a6f  4183f802                 cmp r8d, 2
00058a73  7cb3                     jl 0x58a28
00058a75  4c8b542450               mov r10, qword ptr [rsp + 0x50]
00058a7a  410fb716                 movzx edx, word ptr [r14]
00058a7e  418bc8                   mov ecx, r8d
00058a81  4d8b4a38                 mov r9, qword ptr [r10 + 0x38]
00058a85  b8c0270000               mov eax, 0x27c0
00058a8a  0fbaf11f                 btr ecx, 0x1f
00058a8e  03c2                     add eax, edx
00058a90  6683f829                 cmp ax, 0x29
00058a94  7723                     ja 0x58ab9
00058a96  488d45fe                 lea rax, [rbp - 2]
00058a9a  4c3bf0                   cmp r14, rax
00058a9d  742b                     je 0x58aca
00058a9f  413bcd                   cmp ecx, r13d
00058aa2  760d                     jbe 0x58ab1
00058aa4  450fb75e02               movzx r11d, word ptr [r14 + 2]
00058aa9  6644895c2464             mov word ptr [rsp + 0x64], r11w
00058aaf  eb06                     jmp 0x58ab7
00058ab1  440fb75c2464             movzx r11d, word ptr [rsp + 0x64]
00058ab7  7722                     ja 0x58adb
00058ab9  4181e7ffffff3f           and r15d, 0x3fffffff
00058ac0  44897c2440               mov dword ptr [rsp + 0x40], r15d
00058ac5  e9a2feffff               jmp 0x5896c
00058aca  413bcd                   cmp ecx, r13d
00058acd  76ea                     jbe 0x58ab9
00058acf  33c0                     xor eax, eax
00058ad1  440fb718                 movzx r11d, word ptr [rax]
00058ad5  6644895c2464             mov word ptr [rsp + 0x64], r11w
00058adb  b800240000               mov eax, 0x2400
00058ae0  b9ff030000               mov ecx, 0x3ff
00058ae5  4103c3                   add eax, r11d
00058ae8  663bc1                   cmp ax, cx
00058aeb  77cc                     ja 0x58ab9
00058aed  b8c9270000               mov eax, 0x27c9
00058af2  6603d0                   add dx, ax
00058af5  b800040000               mov eax, 0x400
00058afa  0fb7ca                   movzx ecx, dx
00058afd  0fafc8                   imul ecx, eax
00058b00  664103cb                 add cx, r11w
00058b04  0fb7c1                   movzx eax, cx
00058b07  6641833c8100             cmp word ptr [r9 + rax*4], 0
00058b0d  74aa                     je 0x58ab9
00058b0f  418b0481                 mov eax, dword ptr [r9 + rax*4]
00058b13  488d573e                 lea rdx, [rdi + 0x3e]
00058b17  0fb7d8                   movzx ebx, ax
00058b1a  498bce                   mov rcx, r14
00058b1d  48c1e810                 shr rax, 0x10
00058b21  48c1e320                 shl rbx, 0x20
00058b25  480bd8                   or rbx, rax
00058b28  418d40ff                 lea eax, [r8 - 1]
00058b2c  4c63c0                   movsxd r8, eax
00058b2f  4d03c0                   add r8, r8
00058b32  e888570000               call 0x5e2bf
00058b37  ff4f5c                   dec dword ptr [rdi + 0x5c]
00058b3a  488bc3                   mov rax, rbx
00058b3d  48c1e810                 shr rax, 0x10
00058b41  0fb7d0                   movzx edx, ax
00058b44  488bc3                   mov rax, rbx
00058b47  48c1e820                 shr rax, 0x20
00058b4b  48c1e310                 shl rbx, 0x10
00058b4f  0bc3                     or eax, ebx
00058b51  89542460                 mov dword ptr [rsp + 0x60], edx
00058b55  25ffffff3f               and eax, 0x3fffffff
00058b5a  448bf8                   mov r15d, eax
00058b5d  89442440                 mov dword ptr [rsp + 0x40], eax
00058b61  e939feffff               jmp 0x5899f
00058b66  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058b6a  33db                     xor ebx, ebx
00058b6c  85d2                     test edx, edx
00058b6e  751d                     jne 0x58b8d
00058b70  b8fcff0000               mov eax, 0xfffc
00058b75  895c2474                 mov dword ptr [rsp + 0x74], ebx
00058b79  418bd5                   mov edx, r13d
00058b7c  6689442440               mov word ptr [rsp + 0x40], ax
00058b81  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058b86  89542444                 mov dword ptr [rsp + 0x44], edx
00058b8a  895d88                   mov dword ptr [rbp - 0x78], ebx
00058b8d  85f6                     test esi, esi
00058b8f  448beb                   mov r13d, ebx
00058b92  410f95c5                 setne r13b
00058b96  e9ef000000               jmp 0x58c8a
00058b9b  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058b9f  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058ba4  85d2                     test edx, edx
00058ba6  0f84e3000000             je 0x58c8f
00058bac  b8fbff0000               mov eax, 0xfffb
00058bb1  33d2                     xor edx, edx
00058bb3  6689442440               mov word ptr [rsp + 0x40], ax
00058bb8  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058bbd  89542444                 mov dword ptr [rsp + 0x44], edx
00058bc1  e9c9000000               jmp 0x58c8f
00058bc6  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058bca  85d2                     test edx, edx
00058bcc  0f84b8000000             je 0x58c8a
00058bd2  413bdd                   cmp ebx, r13d
00058bd5  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058bda  0f85af000000             jne 0x58c8f
00058be0  b8f9ff0000               mov eax, 0xfff9
00058be5  6689442440               mov word ptr [rsp + 0x40], ax
00058bea  33c0                     xor eax, eax
00058bec  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058bf1  89442474                 mov dword ptr [rsp + 0x74], eax
00058bf5  e995000000               jmp 0x58c8f
00058bfa  ba02000000               mov edx, 2
00058bff  488bcf                   mov rcx, rdi
00058c02  e8d917ffff               call 0x4a3e0
00058c07  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058c0b  85d2                     test edx, edx
00058c0d  7474                     je 0x58c83
00058c0f  413bdd                   cmp ebx, r13d
00058c12  7e6f                     jle 0x58c83
00058c14  4c8d05e573faff           lea r8, [rip - 0x58c1b]
00058c1b  44396f5c                 cmp dword ptr [rdi + 0x5c], r13d
00058c1f  7e69                     jle 0x58c8a
00058c21  6641837e025d             cmp word ptr [r14 + 2], 0x5d
00058c27  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058c2c  7461                     je 0x58c8f
00058c2e  b8faff0000               mov eax, 0xfffa
00058c33  4533ed                   xor r13d, r13d
00058c36  6689442440               mov word ptr [rsp + 0x40], ax
00058c3b  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058c40  eb4d                     jmp 0x58c8f
00058c42  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058c46  85d2                     test edx, edx
00058c48  7540                     jne 0x58c8a
00058c4a  b8f7ff0000               mov eax, 0xfff7
00058c4f  6689442440               mov word ptr [rsp + 0x40], ax
00058c54  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058c59  eb2f                     jmp 0x58c8a
00058c5b  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058c5f  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058c64  85d2                     test edx, edx
00058c66  7527                     jne 0x58c8f
00058c68  b8feff0000               mov eax, 0xfffe
00058c6d  6689442440               mov word ptr [rsp + 0x40], ax
00058c72  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00058c77  eb16                     jmp 0x58c8f
00058c79  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058c7d  eb0b                     jmp 0x58c8a
00058c7f  8b542444                 mov edx, dword ptr [rsp + 0x44]
00058c83  4c8d057673faff           lea r8, [rip - 0x58c8a]
00058c8a  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
00058c8f  0fb7442440               movzx eax, word ptr [rsp + 0x40]
00058c94  4533f6                   xor r14d, r14d
00058c97  c1e808                   shr eax, 8
00058c9a  83f805                   cmp eax, 5
00058c9d  0f8792060000             ja 0x59335
00058ca3  418b8c8008970500         mov ecx, dword ptr [r8 + rax*4 + 0x59708]
00058cab  4903c8                   add rcx, r8
00058cae  ffe1                     jmp rcx
00058cb0  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00058cb3  488d573e                 lea rdx, [rdi + 0x3e]
00058cb7  ffc8                     dec eax
00058cb9  488d4f3c                 lea rcx, [rdi + 0x3c]
00058cbd  4c63c0                   movsxd r8, eax
00058cc0  4d03c0                   add r8, r8
00058cc3  e8f7550000               call 0x5e2bf
00058cc8  488b8590000000           mov rax, qword ptr [rbp + 0x90]
00058ccf  41be01000000             mov r14d, 1
00058cd5  ff4f5c                   dec dword ptr [rdi + 0x5c]
00058cd8  4885c0                   test rax, rax
00058cdb  7403                     je 0x58ce0
00058cdd  48ff00                   inc qword ptr [rax]
00058ce0  8b742460                 mov esi, dword ptr [rsp + 0x60]
00058ce4  33db                     xor ebx, ebx
00058ce6  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00058cea  448b64245c               mov r12d, dword ptr [rsp + 0x5c]
00058cef  4585e4                   test r12d, r12d
00058cf2  7e0a                     jle 0x58cfe
00058cf4  41ffcc                   dec r12d
00058cf7  8919                     mov dword ptr [rcx], ebx
00058cf9  448964245c               mov dword ptr [rsp + 0x5c], r12d
00058cfe  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
00058d03  4585f6                   test r14d, r14d
00058d06  8b9d80000000             mov ebx, dword ptr [rbp + 0x80]
00058d0c  4c8d773c                 lea r14, [rdi + 0x3c]
00058d10  0f85aaf9ffff             jne 0x586c0
00058d16  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00058d19  4c8d773c                 lea r14, [rdi + 0x3c]
00058d1d  ffc8                     dec eax
00058d1f  488d573e                 lea rdx, [rdi + 0x3e]
00058d23  4c63c0                   movsxd r8, eax
00058d26  498bce                   mov rcx, r14
00058d29  4d03c0                   add r8, r8
00058d2c  e88e550000               call 0x5e2bf
00058d31  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00058d34  ffc8                     dec eax
00058d36  89475c                   mov dword ptr [rdi + 0x5c], eax
00058d39  4585e4                   test r12d, r12d
00058d3c  0f8462060000             je 0x593a4
00058d42  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00058d49  488b4768                 mov rax, qword ptr [rdi + 0x68]
00058d4d  44893c88                 mov dword ptr [rax + rcx*4], r15d
00058d51  85db                     test ebx, ebx
00058d53  7422                     je 0x58d77
00058d55  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00058d5c  488b4770                 mov rax, qword ptr [rdi + 0x70]
00058d60  893488                   mov dword ptr [rax + rcx*4], esi
00058d63  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
00058d67  4885c9                   test rcx, rcx
00058d6a  740b                     je 0x58d77
00058d6c  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
00058d73  c6040800                 mov byte ptr [rax + rcx], 0
00058d77  ff8788000000             inc dword ptr [rdi + 0x88]
00058d7d  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
00058d82  e939f9ffff               jmp 0x586c0
00058d87  44387590                 cmp byte ptr [rbp - 0x70], r14b
00058d8b  7411                     je 0x58d9e
00058d8d  4438742448               cmp byte ptr [rsp + 0x48], r14b
00058d92  740a                     je 0x58d9e
00058d94  44397710                 cmp dword ptr [rdi + 0x10], r14d
00058d98  0f8d12ffffff             jge 0x58cb0
00058d9e  f7471000000040           test dword ptr [rdi + 0x10], 0x40000000
00058da5  0f8435ffffff             je 0x58ce0
00058dab  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00058dae  394738                   cmp dword ptr [rdi + 0x38], eax
00058db1  0f8529ffffff             jne 0x58ce0
00058db7  4439b788000000           cmp dword ptr [rdi + 0x88], r14d
00058dbe  0f851cffffff             jne 0x58ce0
00058dc4  e9e7feffff               jmp 0x58cb0
00058dc9  488b4570                 mov rax, qword ptr [rbp + 0x70]
00058dcd  448930                   mov dword ptr [rax], r14d
00058dd0  44397578                 cmp dword ptr [rbp + 0x78], r14d
00058dd4  7412                     je 0x58de8
00058dd6  44397708                 cmp dword ptr [rdi + 8], r14d
00058dda  0f8400ffffff             je 0x58ce0
00058de0  85d2                     test edx, edx
00058de2  0f85f8feffff             jne 0x58ce0
00058de8  4c63475c                 movsxd r8, dword ptr [rdi + 0x5c]
00058dec  418bcf                   mov ecx, r15d
00058def  4d03c0                   add r8, r8
00058df2  48c1e910                 shr rcx, 0x10
00058df6  418bc7                   mov eax, r15d
00058df9  48c1e020                 shl rax, 0x20
00058dfd  480bc1                   or rax, rcx
00058e00  488bc8                   mov rcx, rax
00058e03  48c1e820                 shr rax, 0x20
00058e07  6681e100ff               and cx, 0xff00
00058e0c  0fb7d1                   movzx edx, cx
00058e0f  0fb6c8                   movzx ecx, al
00058e12  488b4598                 mov rax, qword ptr [rbp - 0x68]
00058e16  480bd1                   or rdx, rcx
00058e19  488d4f3e                 lea rcx, [rdi + 0x3e]
00058e1d  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00058e24  8b1c90                   mov ebx, dword ptr [rax + rdx*4]
00058e27  488d573c                 lea rdx, [rdi + 0x3c]
00058e2b  e88f540000               call 0x5e2bf
00058e30  488b442450               mov rax, qword ptr [rsp + 0x50]
00058e35  8344245c03               add dword ptr [rsp + 0x5c], 3
00058e3a  66895f3c                 mov word ptr [rdi + 0x3c], bx
00058e3e  c1eb10                   shr ebx, 0x10
00058e41  66895f3e                 mov word ptr [rdi + 0x3e], bx
00058e45  8b575c                   mov edx, dword ptr [rdi + 0x5c]
00058e48  c7476001000000           mov dword ptr [rdi + 0x60], 1
00058e4f  ffc2                     inc edx
00058e51  89575c                   mov dword ptr [rdi + 0x5c], edx
00058e54  0fb74f3e                 movzx ecx, word ptr [rdi + 0x3e]
00058e58  488b4008                 mov rax, qword ptr [rax + 8]
00058e5c  807c880102               cmp byte ptr [rax + rcx*4 + 1], 2
00058e61  4c8d3488                 lea r14, [rax + rcx*4]
00058e65  755b                     jne 0x58ec2
00058e67  4c63c2                   movsxd r8, edx
00058e6a  488d4f40                 lea rcx, [rdi + 0x40]
00058e6e  4d03c0                   add r8, r8
00058e71  488d573e                 lea rdx, [rdi + 0x3e]
00058e75  e845540000               call 0x5e2bf
00058e7a  418b0e                   mov ecx, dword ptr [r14]
00058e7d  8bc1                     mov eax, ecx
00058e7f  48c1e910                 shr rcx, 0x10
00058e83  48c1e020                 shl rax, 0x20
00058e87  480bc1                   or rax, rcx
00058e8a  488bc8                   mov rcx, rax
00058e8d  48c1e820                 shr rax, 0x20
00058e91  6681e100ff               and cx, 0xff00
00058e96  0fb7d1                   movzx edx, cx
00058e99  0fb6c8                   movzx ecx, al
00058e9c  488b4598                 mov rax, qword ptr [rbp - 0x68]
00058ea0  480bd1                   or rdx, rcx
00058ea3  488b80a8000000           mov rax, qword ptr [rax + 0xa8]
00058eaa  8b0490                   mov eax, dword ptr [rax + rdx*4]
00058ead  6689473e                 mov word ptr [rdi + 0x3e], ax
00058eb1  c1e810                   shr eax, 0x10
00058eb4  66894740                 mov word ptr [rdi + 0x40], ax
00058eb8  ff475c                   inc dword ptr [rdi + 0x5c]
00058ebb  ff4760                   inc dword ptr [rdi + 0x60]
00058ebe  ff44245c                 inc dword ptr [rsp + 0x5c]
00058ec2  41be01000000             mov r14d, 1
00058ec8  e913feffff               jmp 0x58ce0
00058ecd  807c244001               cmp byte ptr [rsp + 0x40], 1
00058ed2  770f                     ja 0x58ee3
00058ed4  488b8588000000           mov rax, qword ptr [rbp + 0x88]
00058edb  4885c0                   test rax, rax
00058ede  7403                     je 0x58ee3
00058ee0  c60001                   mov byte ptr [rax], 1
00058ee3  33db                     xor ebx, ebx
00058ee5  418bc7                   mov eax, r15d
00058ee8  48c1e810                 shr rax, 0x10
00058eec  8bcb                     mov ecx, ebx
00058eee  410fb7d7                 movzx edx, r15w
00058ef2  48c1e220                 shl rdx, 0x20
00058ef6  480bd0                   or rdx, rax
00058ef9  395d88                   cmp dword ptr [rbp - 0x78], ebx
00058efc  7440                     je 0x58f3e
00058efe  488b4570                 mov rax, qword ptr [rbp + 0x70]
00058f02  448b00                   mov r8d, dword ptr [rax]
00058f05  410fb7c8                 movzx ecx, r8w
00058f09  418bc0                   mov eax, r8d
00058f0c  48c1e120                 shl rcx, 0x20
00058f10  48c1e810                 shr rax, 0x10
00058f14  480bc8                   or rcx, rax
00058f17  6641c1e808               shr r8w, 8
00058f1c  4180f822                 cmp r8b, 0x22
00058f20  741c                     je 0x58f3e
00058f22  399d80000000             cmp dword ptr [rbp + 0x80], ebx
00058f28  7414                     je 0x58f3e
00058f2a  4c638788000000           movsxd r8, dword ptr [rdi + 0x88]
00058f31  488b4770                 mov rax, qword ptr [rdi + 0x70]
00058f35  460fb74c80fc             movzx r9d, word ptr [rax + r8*4 - 4]
00058f3b  490bc9                   or rcx, r9
00058f3e  4c8bd2                   mov r10, rdx
00058f41  895c2440                 mov dword ptr [rsp + 0x40], ebx
00058f45  49c1ea20                 shr r10, 0x20
00058f49  8bf3                     mov esi, ebx
00058f4b  4180fa01                 cmp r10b, 1
00058f4f  0f879e000000             ja 0x58ff3
00058f55  4c8bc1                   mov r8, rcx
00058f58  49c1e828                 shr r8, 0x28
00058f5c  4180f803                 cmp r8b, 3
00058f60  770f                     ja 0x58f71
00058f62  48b800000000ffff0000     movabs rax, 0xffff00000000
00058f6c  e9dc000000               jmp 0x5904d
00058f71  488bc1                   mov rax, rcx
00058f74  48c1e810                 shr rax, 0x10
00058f78  4180f822                 cmp r8b, 0x22
00058f7c  7568                     jne 0x58fe6
00058f7e  4c8bc9                   mov r9, rcx
00058f81  49c1e908                 shr r9, 8
00058f85  450fb6c1                 movzx r8d, r9b
00058f89  4180e0c6                 and r8b, 0xc6
00058f8d  4488442440               mov byte ptr [rsp + 0x40], r8b
00058f92  450fb6c1                 movzx r8d, r9b
00058f96  4180e0e4                 and r8b, 0xe4
00058f9a  4488442442               mov byte ptr [rsp + 0x42], r8b
00058f9f  440fb7c2                 movzx r8d, dx
00058fa3  4584d2                   test r10b, r10b
00058fa6  751a                     jne 0x58fc2
00058fa8  48c1e010                 shl rax, 0x10
00058fac  490bc0                   or rax, r8
00058faf  c644244104               mov byte ptr [rsp + 0x41], 4
00058fb4  4180e1c5                 and r9b, 0xc5
00058fb8  44884c2443               mov byte ptr [rsp + 0x43], r9b
00058fbd  e97c000000               jmp 0x5903e
00058fc2  ba000087ff               mov edx, 0xff870000
00058fc7  c644244105               mov byte ptr [rsp + 0x41], 5
00058fcc  4823c2                   and rax, rdx
00058fcf  48c1e010                 shl rax, 0x10
00058fd3  490bc0                   or rax, r8
00058fd6  488bd0                   mov rdx, rax
00058fd9  48c1ea08                 shr rdx, 8
00058fdd  80e2c5                   and dl, 0xc5
00058fe0  88542443                 mov byte ptr [rsp + 0x43], dl
00058fe4  eb58                     jmp 0x5903e
00058fe6  440fb6c2                 movzx r8d, dl
00058fea  48c1e010                 shl rax, 0x10
00058fee  490bc0                   or rax, r8
00058ff1  eb4f                     jmp 0x59042
00058ff3  488bc2                   mov rax, rdx
00058ff6  c644244103               mov byte ptr [rsp + 0x41], 3
00058ffb  48b9ffffffffff22ffff     movabs rcx, 0xffff22ffffffffff
00059005  4823c1                   and rax, rcx
00059008  48b90000000000220000     movabs rcx, 0x220000000000
00059012  480bc1                   or rax, rcx
00059015  4c8bc0                   mov r8, rax
00059018  488bc8                   mov rcx, rax
0005901b  49c1e808                 shr r8, 8
0005901f  410fb6d0                 movzx edx, r8b
00059023  80e2c6                   and dl, 0xc6
00059026  88542440                 mov byte ptr [rsp + 0x40], dl
0005902a  410fb6d0                 movzx edx, r8b
0005902e  80e2e4                   and dl, 0xe4
00059031  4180e0c5                 and r8b, 0xc5
00059035  88542442                 mov byte ptr [rsp + 0x42], dl
00059039  4488442443               mov byte ptr [rsp + 0x43], r8b
0005903e  8b742440                 mov esi, dword ptr [rsp + 0x40]
00059042  4825ff02ffff             and rax, 0xffffffffffff02ff
00059048  480fbae809               bts rax, 9
0005904d  488bd0                   mov rdx, rax
00059050  48c1ea28                 shr rdx, 0x28
00059054  80fa22                   cmp dl, 0x22
00059057  740a                     je 0x59063
00059059  488bd0                   mov rdx, rax
0005905c  48c1ea10                 shr rdx, 0x10
00059060  0fb7f2                   movzx esi, dx
00059063  488bd0                   mov rdx, rax
00059066  48c1e010                 shl rax, 0x10
0005906a  48c1ea20                 shr rdx, 0x20
0005906e  0bd0                     or edx, eax
00059070  89542440                 mov dword ptr [rsp + 0x40], edx
00059074  448bfa                   mov r15d, edx
00059077  80fa01                   cmp dl, 1
0005907a  0f8666fcffff             jbe 0x58ce6
00059080  488bc1                   mov rax, rcx
00059083  48c1e110                 shl rcx, 0x10
00059087  48c1e820                 shr rax, 0x20
0005908b  0bc1                     or eax, ecx
0005908d  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00059091  8901                     mov dword ptr [rcx], eax
00059093  e952fcffff               jmp 0x58cea
00059098  4c8d673c                 lea r12, [rdi + 0x3c]
0005909c  b860110000               mov eax, 0x1160
000590a1  6641390424               cmp word ptr [r12], ax
000590a6  0f831f020000             jae 0x592cb
000590ac  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000590af  83f803                   cmp eax, 3
000590b2  7d4d                     jge 0x59101
000590b4  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
000590b8  4885c9                   test rcx, rcx
000590bb  7e44                     jle 0x59101
000590bd  488b4718                 mov rax, qword ptr [rdi + 0x18]
000590c1  4885c0                   test rax, rax
000590c4  740b                     je 0x590d1
000590c6  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000590ca  ffd0                     call rax
000590cc  0fb7c8                   movzx ecx, ax
000590cf  eb12                     jmp 0x590e3
000590d1  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000590d5  488b4728                 mov rax, qword ptr [rdi + 0x28]
000590d9  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
000590dd  8d4201                   lea eax, [rdx + 1]
000590e0  894738                   mov dword ptr [rdi + 0x38], eax
000590e3  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
000590e7  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
000590ec  8b475c                   mov eax, dword ptr [rdi + 0x5c]
000590ef  48ff4f30                 dec qword ptr [rdi + 0x30]
000590f3  ffc0                     inc eax
000590f5  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
000590f9  89475c                   mov dword ptr [rdi + 0x5c], eax
000590fc  83f803                   cmp eax, 3
000590ff  7cb7                     jl 0x590b8
00059101  488b4d98                 mov rcx, qword ptr [rbp - 0x68]
00059105  4c8d4c246c               lea r9, [rsp + 0x6c]
0005910a  0fbaf01f                 btr eax, 0x1f
0005910e  4c8965d0                 mov qword ptr [rbp - 0x30], r12
00059112  8945d8                   mov dword ptr [rbp - 0x28], eax
00059115  4c8d45d0                 lea r8, [rbp - 0x30]
00059119  488d458c                 lea rax, [rbp - 0x74]
0005911d  4c8965e8                 mov qword ptr [rbp - 0x18], r12
00059121  4889442430               mov qword ptr [rsp + 0x30], rax
00059126  4533ff                   xor r15d, r15d
00059129  488d442470               lea rax, [rsp + 0x70]
0005912e  c744242803000000         mov dword ptr [rsp + 0x28], 3
00059136  488bd3                   mov rdx, rbx
00059139  4889442420               mov qword ptr [rsp + 0x20], rax
0005913e  4c897de0                 mov qword ptr [rbp - 0x20], r15
00059142  e8c986ffff               call 0x51810
00059147  8bf0                     mov esi, eax
00059149  85c0                     test eax, eax
0005914b  0f8e7a010000             jle 0x592cb
00059151  0faee8                   lfence
00059154  0fb744246c               movzx eax, word ptr [rsp + 0x6c]
00059159  48639788000000           movsxd rdx, dword ptr [rdi + 0x88]
00059160  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
00059164  448b8580000000           mov r8d, dword ptr [rbp + 0x80]
0005916b  6689442478               mov word ptr [rsp + 0x78], ax
00059170  66c744247a0202           mov word ptr [rsp + 0x7a], 0x202
00059177  8b442478                 mov eax, dword ptr [rsp + 0x78]
0005917b  890491                   mov dword ptr [rcx + rdx*4], eax
0005917e  4585c0                   test r8d, r8d
00059181  7423                     je 0x591a6
00059183  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005918a  488b4770                 mov rax, qword ptr [rdi + 0x70]
0005918e  44893c88                 mov dword ptr [rax + rcx*4], r15d
00059192  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
00059196  4885c9                   test rcx, rcx
00059199  740b                     je 0x591a6
0005919b  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
000591a2  44883408                 mov byte ptr [rax + rcx], r14b
000591a6  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000591ad  41b900ff0000             mov r9d, 0xff00
000591b3  488bd1                   mov rdx, rcx
000591b6  66c744247e0202           mov word ptr [rsp + 0x7e], 0x202
000591bd  8d4101                   lea eax, [rcx + 1]
000591c0  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
000591c4  898788000000             mov dword ptr [rdi + 0x88], eax
000591ca  0fb6442470               movzx eax, byte ptr [rsp + 0x70]
000591cf  66410bc1                 or ax, r9w
000591d3  668944247c               mov word ptr [rsp + 0x7c], ax
000591d8  8b44247c                 mov eax, dword ptr [rsp + 0x7c]
000591dc  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
000591e0  4585c0                   test r8d, r8d
000591e3  7423                     je 0x59208
000591e5  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000591ec  488b4770                 mov rax, qword ptr [rdi + 0x70]
000591f0  44893c88                 mov dword ptr [rax + rcx*4], r15d
000591f4  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
000591f8  4885c9                   test rcx, rcx
000591fb  740b                     je 0x59208
000591fd  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
00059204  44883408                 mov byte ptr [rax + rcx], r14b
00059208  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005920f  488bd1                   mov rdx, rcx
00059212  66c745820202             mov word ptr [rbp - 0x7e], 0x202
00059218  8d4101                   lea eax, [rcx + 1]
0005921b  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
0005921f  898788000000             mov dword ptr [rdi + 0x88], eax
00059225  0fb6442471               movzx eax, byte ptr [rsp + 0x71]
0005922a  66410bc1                 or ax, r9w
0005922e  66894580                 mov word ptr [rbp - 0x80], ax
00059232  8b4580                   mov eax, dword ptr [rbp - 0x80]
00059235  89449104                 mov dword ptr [rcx + rdx*4 + 4], eax
00059239  4585c0                   test r8d, r8d
0005923c  7423                     je 0x59261
0005923e  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
00059245  488b4770                 mov rax, qword ptr [rdi + 0x70]
00059249  44893c88                 mov dword ptr [rax + rcx*4], r15d
0005924d  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
00059251  4885c9                   test rcx, rcx
00059254  740b                     je 0x59261
00059256  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
0005925d  44883408                 mov byte ptr [rax + rcx], r14b
00059261  0fb6442472               movzx eax, byte ptr [rsp + 0x72]
00059266  488d573c                 lea rdx, [rdi + 0x3c]
0005926a  ff8788000000             inc dword ptr [rdi + 0x88]
00059270  66410bc1                 or ax, r9w
00059274  66894584                 mov word ptr [rbp - 0x7c], ax
00059278  ffce                     dec esi
0005927a  4863c6                   movsxd rax, esi
0005927d  498bcc                   mov rcx, r12
00059280  66c745860202             mov word ptr [rbp - 0x7a], 0x202
00059286  448b7d84                 mov r15d, dword ptr [rbp - 0x7c]
0005928a  44897c2440               mov dword ptr [rsp + 0x40], r15d
0005928f  488d1c00                 lea rbx, [rax + rax]
00059293  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00059296  2bc6                     sub eax, esi
00059298  4803d3                   add rdx, rbx
0005929b  4c63c0                   movsxd r8, eax
0005929e  4d03c0                   add r8, r8
000592a1  e819500000               call 0x5e2bf
000592a6  29775c                   sub dword ptr [rdi + 0x5c], esi
000592a9  420fb70c23               movzx ecx, word ptr [rbx + r12]
000592ae  33db                     xor ebx, ebx
000592b0  488b442450               mov rax, qword ptr [rsp + 0x50]
000592b5  8b742460                 mov esi, dword ptr [rsp + 0x60]
000592b9  488b4008                 mov rax, qword ptr [rax + 8]
000592bd  8b1488                   mov edx, dword ptr [rax + rcx*4]
000592c0  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
000592c4  8911                     mov dword ptr [rcx], edx
000592c6  e91ffaffff               jmp 0x58cea
000592cb  410fb70c24               movzx ecx, word ptr [r12]
000592d0  488b4308                 mov rax, qword ptr [rbx + 8]
000592d4  8b742460                 mov esi, dword ptr [rsp + 0x60]
000592d8  8b1488                   mov edx, dword ptr [rax + rcx*4]
000592db  8bc2                     mov eax, edx
000592dd  c1e810                   shr eax, 0x10
000592e0  0fb6c8                   movzx ecx, al
000592e3  89542440                 mov dword ptr [rsp + 0x40], edx
000592e7  c644244202               mov byte ptr [rsp + 0x42], 2
000592ec  0fb6c2                   movzx eax, dl
000592ef  66c1e008                 shl ax, 8
000592f3  660bc8                   or cx, ax
000592f6  66894c2440               mov word ptr [rsp + 0x40], cx
000592fb  33db                     xor ebx, ebx
000592fd  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00059301  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
00059306  8911                     mov dword ptr [rcx], edx
00059308  e9ddf9ffff               jmp 0x58cea
0005930d  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00059311  410fb6f7                 movzx esi, r15b
00059315  c1e608                   shl esi, 8
00059318  c7442440fffd0202         mov dword ptr [rsp + 0x40], 0x202fdff
00059320  448939                   mov dword ptr [rcx], r15d
00059323  0fb64102                 movzx eax, byte ptr [rcx + 2]
00059327  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
0005932c  0bf0                     or esi, eax
0005932e  33db                     xor ebx, ebx
00059330  e9b5f9ffff               jmp 0x58cea
00059335  488b4570                 mov rax, qword ptr [rbp + 0x70]
00059339  410fb7cf                 movzx ecx, r15w
0005933d  48c1e120                 shl rcx, 0x20
00059341  448938                   mov dword ptr [rax], r15d
00059344  418bc7                   mov eax, r15d
00059347  48c1e810                 shr rax, 0x10
0005934b  480bc8                   or rcx, rax
0005934e  488bc1                   mov rax, rcx
00059351  440fb6c9                 movzx r9d, cl
00059355  48c1e828                 shr rax, 0x28
00059359  0440                     add al, 0x40
0005935b  3c30                     cmp al, 0x30
0005935d  7724                     ja 0x59383
0005935f  448b03                   mov r8d, dword ptr [rbx]
00059362  41b9ff030000             mov r9d, 0x3ff
00059368  418bc0                   mov eax, r8d
0005936b  0fb6d1                   movzx edx, cl
0005936e  4123c1                   and eax, r9d
00059371  83f804                   cmp eax, 4
00059374  741a                     je 0x59390
00059376  440fb6c9                 movzx r9d, cl
0005937a  4181f811040400           cmp r8d, 0x40411
00059381  740d                     je 0x59390
00059383  410fb6d1                 movzx edx, r9b
00059387  4584e4                   test r12b, r12b
0005938a  0f8450f9ffff             je 0x58ce0
00059390  48c1e908                 shr rcx, 8
00059394  0fb6c2                   movzx eax, dl
00059397  0fb6f1                   movzx esi, cl
0005939a  c1e008                   shl eax, 8
0005939d  0bf0                     or esi, eax
0005939f  e940f9ffff               jmp 0x58ce4
000593a4  4585ed                   test r13d, r13d
000593a7  0f84f6010000             je 0x595a3
000593ad  c644244801               mov byte ptr [rsp + 0x48], 1
000593b2  8bc8                     mov ecx, eax
000593b4  83f801                   cmp eax, 1
000593b7  7d50                     jge 0x59409
000593b9  488b4730                 mov rax, qword ptr [rdi + 0x30]
000593bd  0f1f00                   nop dword ptr [rax]
000593c0  4885c0                   test rax, rax
000593c3  7e44                     jle 0x59409
000593c5  488b4718                 mov rax, qword ptr [rdi + 0x18]
000593c9  4885c0                   test rax, rax
000593cc  740b                     je 0x593d9
000593ce  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
000593d2  ffd0                     call rax
000593d4  0fb7c8                   movzx ecx, ax
000593d7  eb12                     jmp 0x593eb
000593d9  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
000593dd  488b4728                 mov rax, qword ptr [rdi + 0x28]
000593e1  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
000593e5  8d4201                   lea eax, [rdx + 1]
000593e8  894738                   mov dword ptr [rdi + 0x38], eax
000593eb  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
000593ef  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
000593f4  8b4f5c                   mov ecx, dword ptr [rdi + 0x5c]
000593f7  48ff4f30                 dec qword ptr [rdi + 0x30]
000593fb  ffc1                     inc ecx
000593fd  488b4730                 mov rax, qword ptr [rdi + 0x30]
00059401  894f5c                   mov dword ptr [rdi + 0x5c], ecx
00059404  83f901                   cmp ecx, 1
00059407  7cb7                     jl 0x593c0
00059409  85c9                     test ecx, ecx
0005940b  0f848b010000             je 0x5959c
00059411  41b9f7ff0000             mov r9d, 0xfff7
00059417  6644394c2440             cmp word ptr [rsp + 0x40], r9w
0005941d  7527                     jne 0x59446
0005941f  6641833e25               cmp word ptr [r14], 0x25
00059424  7520                     jne 0x59446
00059426  8d41ff                   lea eax, [rcx - 1]
00059429  4c63c0                   movsxd r8, eax
0005942c  488d573e                 lea rdx, [rdi + 0x3e]
00059430  4d03c0                   add r8, r8
00059433  498bce                   mov rcx, r14
00059436  e8844e0000               call 0x5e2bf
0005943b  ff4f5c                   dec dword ptr [rdi + 0x5c]
0005943e  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00059441  e96cffffff               jmp 0x593b2
00059446  410fb706                 movzx eax, word ptr [r14]
0005944a  ba40db0000               mov edx, 0xdb40
0005944f  663bc2                   cmp ax, dx
00059452  757f                     jne 0x594d3
00059454  83f902                   cmp ecx, 2
00059457  7d56                     jge 0x594af
00059459  488b4730                 mov rax, qword ptr [rdi + 0x30]
0005945d  0f1f00                   nop dword ptr [rax]
00059460  4885c0                   test rax, rax
00059463  7e44                     jle 0x594a9
00059465  488b4718                 mov rax, qword ptr [rdi + 0x18]
00059469  4885c0                   test rax, rax
0005946c  740b                     je 0x59479
0005946e  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
00059472  ffd0                     call rax
00059474  0fb7c8                   movzx ecx, ax
00059477  eb12                     jmp 0x5948b
00059479  48635738                 movsxd rdx, dword ptr [rdi + 0x38]
0005947d  488b4728                 mov rax, qword ptr [rdi + 0x28]
00059481  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00059485  8d4201                   lea eax, [rdx + 1]
00059488  894738                   mov dword ptr [rdi + 0x38], eax
0005948b  4863475c                 movsxd rax, dword ptr [rdi + 0x5c]
0005948f  66894c473c               mov word ptr [rdi + rax*2 + 0x3c], cx
00059494  8b4f5c                   mov ecx, dword ptr [rdi + 0x5c]
00059497  48ff4f30                 dec qword ptr [rdi + 0x30]
0005949b  ffc1                     inc ecx
0005949d  488b4730                 mov rax, qword ptr [rdi + 0x30]
000594a1  894f5c                   mov dword ptr [rdi + 0x5c], ecx
000594a4  83f902                   cmp ecx, 2
000594a7  7cb7                     jl 0x59460
000594a9  41b9f7ff0000             mov r9d, 0xfff7
000594af  83f901                   cmp ecx, 1
000594b2  7e1b                     jle 0x594cf
000594b4  0fb7573e                 movzx edx, word ptr [rdi + 0x3e]
000594b8  b800230000               mov eax, 0x2300
000594bd  03c2                     add eax, edx
000594bf  41b8ef000000             mov r8d, 0xef
000594c5  66413bc0                 cmp ax, r8w
000594c9  0f868e000000             jbe 0x5955d
000594cf  410fb706                 movzx eax, word ptr [r14]
000594d3  4c8b542450               mov r10, qword ptr [rsp + 0x50]
000594d8  440fb7c0                 movzx r8d, ax
000594dc  498b4208                 mov rax, qword ptr [r10 + 8]
000594e0  428b1480                 mov edx, dword ptr [rax + r8*4]
000594e4  8bc2                     mov eax, edx
000594e6  c1e810                   shr eax, 0x10
000594e9  66c1ea08                 shr dx, 8
000594ed  84d2                     test dl, dl
000594ef  753b                     jne 0x5952c
000594f1  38542468                 cmp byte ptr [rsp + 0x68], dl
000594f5  0f84a1000000             je 0x5959c
000594fb  b800280000               mov eax, 0x2800
00059500  664403c0                 add r8w, ax
00059504  b8ff030000               mov eax, 0x3ff
00059509  66443bc0                 cmp r8w, ax
0005950d  0f8789000000             ja 0x5959c
00059513  4c8d4da8                 lea r9, [rbp - 0x58]
00059517  4c8bc7                   mov r8, rdi
0005951a  498bd2                   mov rdx, r10
0005951d  e8fe55ffff               call 0x4eb20
00059522  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00059525  ffc8                     dec eax
00059527  e9fdfeffff               jmp 0x59429
0005952c  80fa01                   cmp dl, 1
0005952f  756b                     jne 0x5959c
00059531  6644394c2440             cmp word ptr [rsp + 0x40], r9w
00059537  0f83e9feffff             jae 0x59426
0005953d  0fb6d0                   movzx edx, al
00059540  0fb6442442               movzx eax, byte ptr [rsp + 0x42]
00059545  6603d0                   add dx, ax
00059548  b8ff000000               mov eax, 0xff
0005954d  663bd0                   cmp dx, ax
00059550  7602                     jbe 0x59554
00059552  8bd0                     mov edx, eax
00059554  88542442                 mov byte ptr [rsp + 0x42], dl
00059558  e9c9feffff               jmp 0x59426
0005955d  807d9400                 cmp byte ptr [rbp - 0x6c], 0
00059561  7507                     jne 0x5956a
00059563  8d4202                   lea eax, [rdx + 2]
00059566  88442458                 mov byte ptr [rsp + 0x58], al
0005956a  8d41ff                   lea eax, [rcx - 1]
0005956d  498bce                   mov rcx, r14
00059570  4c63c0                   movsxd r8, eax
00059573  488d573e                 lea rdx, [rdi + 0x3e]
00059577  4d03c0                   add r8, r8
0005957a  e8404d0000               call 0x5e2bf
0005957f  ff4f5c                   dec dword ptr [rdi + 0x5c]
00059582  488d573e                 lea rdx, [rdi + 0x3e]
00059586  8b475c                   mov eax, dword ptr [rdi + 0x5c]
00059589  498bce                   mov rcx, r14
0005958c  ffc8                     dec eax
0005958e  4c63c0                   movsxd r8, eax
00059591  4d03c0                   add r8, r8
00059594  e8264d0000               call 0x5e2bf
00059599  ff4f5c                   dec dword ptr [rdi + 0x5c]
0005959c  448b7c2440               mov r15d, dword ptr [rsp + 0x40]
000595a1  eb05                     jmp 0x595a8
000595a3  c644244800               mov byte ptr [rsp + 0x48], 0
000595a8  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000595af  488b4768                 mov rax, qword ptr [rdi + 0x68]
000595b3  44893c88                 mov dword ptr [rax + rcx*4], r15d
000595b7  85db                     test ebx, ebx
000595b9  7426                     je 0x595e1
000595bb  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
000595c2  488b4770                 mov rax, qword ptr [rdi + 0x70]
000595c6  893488                   mov dword ptr [rax + rcx*4], esi
000595c9  488b4f78                 mov rcx, qword ptr [rdi + 0x78]
000595cd  4885c9                   test rcx, rcx
000595d0  740f                     je 0x595e1
000595d2  48638788000000           movsxd rax, dword ptr [rdi + 0x88]
000595d9  0fb6542458               movzx edx, byte ptr [rsp + 0x58]
000595de  881408                   mov byte ptr [rax + rcx], dl
000595e1  ff8788000000             inc dword ptr [rdi + 0x88]
000595e7  448b5c2444               mov r11d, dword ptr [rsp + 0x44]
000595ec  4585db                   test r11d, r11d
000595ef  0f85cbf0ffff             jne 0x586c0
000595f5  33c0                     xor eax, eax
000595f7  488b4d10                 mov rcx, qword ptr [rbp + 0x10]
000595fb  4833cc                   xor rcx, rsp
000595fe  e86d380000               call 0x5ce70
00059603  4c8d9c2420010000         lea r11, [rsp + 0x120]
0005960b  498b5b30                 mov rbx, qword ptr [r11 + 0x30]
0005960f  498b7338                 mov rsi, qword ptr [r11 + 0x38]
00059613  498b7b40                 mov rdi, qword ptr [r11 + 0x40]
00059617  498be3                   mov rsp, r11
0005961a  415f                     pop r15
0005961c  415e                     pop r14
0005961e  415d                     pop r13
00059620  415c                     pop r12
00059622  5d                       pop rbp
00059623  c3                       ret
00059624  b803000000               mov eax, 3
00059629  ebcc                     jmp 0x595f7
0005962b  b802000000               mov eax, 2
00059630  ebc5                     jmp 0x595f7
00059632  4585db                   test r11d, r11d
00059635  741a                     je 0x59651
00059637  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005963e  bafbff0000               mov edx, 0xfffb
00059643  488b4768                 mov rax, qword ptr [rdi + 0x68]
00059647  66891488                 mov word ptr [rax + rcx*4], dx
0005964b  ff8788000000             inc dword ptr [rdi + 0x88]
00059651  8b8f88000000             mov ecx, dword ptr [rdi + 0x88]
00059657  3b8f84000000             cmp ecx, dword ptr [rdi + 0x84]
0005965d  7596                     jne 0x595f5
0005965f  f7471000000008           test dword ptr [rdi + 0x10], 0x8000000
00059666  743b                     je 0x596a3
00059668  498b4208                 mov rax, qword ptr [r10 + 8]
0005966c  4863d1                   movsxd rdx, ecx
0005966f  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
00059673  8b8080000000             mov eax, dword ptr [rax + 0x80]
00059679  890491                   mov dword ptr [rcx + rdx*4], eax
0005967c  85db                     test ebx, ebx
0005967e  7423                     je 0x596a3
00059680  48639788000000           movsxd rdx, dword ptr [rdi + 0x88]
00059687  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
0005968b  44892491                 mov dword ptr [rcx + rdx*4], r12d
0005968f  488b5778                 mov rdx, qword ptr [rdi + 0x78]
00059693  4885d2                   test rdx, rdx
00059696  740b                     je 0x596a3
00059698  48638f88000000           movsxd rcx, dword ptr [rdi + 0x88]
0005969f  c6041100                 mov byte ptr [rcx + rdx], 0
000596a3  b801000000               mov eax, 1
000596a8  e94affffff               jmp 0x595f7
000596ad  0f1f00                   nop dword ptr [rax]
000596b0  428c0500fa8b05           mov word ptr [rip + 0x58bfa00], es
000596b7  00668b                   add byte ptr [rsi - 0x75], ah
000596ba  05009b8b05               add eax, 0x58b9b00
000596bf  00c6                     add dh, al
000596c1  8b05005b8c05             mov eax, dword ptr [rip + 0x58c5b00]
000596c7  00798c                   add byte ptr [rcx - 0x74], bh
000596ca  0500000606               add eax, 0x6060000
