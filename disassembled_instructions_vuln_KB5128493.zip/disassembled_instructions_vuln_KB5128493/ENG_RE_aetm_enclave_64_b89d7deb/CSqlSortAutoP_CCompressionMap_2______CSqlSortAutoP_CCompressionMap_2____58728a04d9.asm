; CSqlSortAutoP<CCompressionMap<2> >::~CSqlSortAutoP<CCompressionMap<2> >
; aetm_enclave.dll, primary RVA 0x428c0, 135 bytes in 5 chunk(s)

; chunk at RVA 0x428c0 (30 bytes)
000428c0  4889742418               mov qword ptr [rsp + 0x18], rsi
000428c5  4156                     push r14
000428c7  4883ec20                 sub rsp, 0x20
000428cb  488b31                   mov rsi, qword ptr [rcx]
000428ce  4c8bf1                   mov r14, rcx
000428d1  4885f6                   test rsi, rsi
000428d4  7465                     je 0x4293b
000428d6  488b06                   mov rax, qword ptr [rsi]
000428d9  4885c0                   test rax, rax
000428dc  7455                     je 0x42933

; chunk at RVA 0x428de (12 bytes)
000428de  48897c2438               mov qword ptr [rsp + 0x38], rdi
000428e3  33ff                     xor edi, edi
000428e5  397e08                   cmp dword ptr [rsi + 8], edi
000428e8  763c                     jbe 0x42926

; chunk at RVA 0x428ea (60 bytes)
000428ea  48895c2430               mov qword ptr [rsp + 0x30], rbx
000428ef  90                       nop
000428f0  8bcf                     mov ecx, edi
000428f2  488bd0                   mov rdx, rax
000428f5  4803c9                   add rcx, rcx
000428f8  488b0cc8                 mov rcx, qword ptr [rax + rcx*8]
000428fc  4885c9                   test rcx, rcx
000428ff  7416                     je 0x42917
00042901  488b19                   mov rbx, qword ptr [rcx]
00042904  e833b70100               call 0x5e03c
00042909  488bcb                   mov rcx, rbx
0004290c  4885db                   test rbx, rbx
0004290f  75f0                     jne 0x42901
00042911  488b06                   mov rax, qword ptr [rsi]
00042914  488bd0                   mov rdx, rax
00042917  ffc7                     inc edi
00042919  3b7e08                   cmp edi, dword ptr [rsi + 8]
0004291c  72d2                     jb 0x428f0
0004291e  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00042923  488bc2                   mov rax, rdx

; chunk at RVA 0x42926 (13 bytes)
00042926  488bc8                   mov rcx, rax
00042929  e80eb70100               call 0x5e03c
0004292e  488b7c2438               mov rdi, qword ptr [rsp + 0x38]

; chunk at RVA 0x42933 (20 bytes)
00042933  498b0e                   mov rcx, qword ptr [r14]
00042936  e801b70100               call 0x5e03c
0004293b  488b742440               mov rsi, qword ptr [rsp + 0x40]
00042940  4883c420                 add rsp, 0x20
00042944  415e                     pop r14
00042946  c3                       ret
