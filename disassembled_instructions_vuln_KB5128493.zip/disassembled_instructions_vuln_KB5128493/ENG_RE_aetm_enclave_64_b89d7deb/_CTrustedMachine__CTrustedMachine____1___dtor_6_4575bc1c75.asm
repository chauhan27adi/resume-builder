; `CTrustedMachine::CTrustedMachine'::`1'::dtor$6
; aetm_enclave.dll, primary RVA 0x5fb40, 42 bytes in 1 chunk(s)

; chunk at RVA 0x5fb40 (42 bytes)
0005fb40  4055                     push rbp
0005fb42  4883ec20                 sub rsp, 0x20
0005fb46  488bea                   mov rbp, rdx
0005fb49  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
0005fb4d  4c8d0d8c9ffaff           lea r9, [rip - 0x56074]
0005fb54  41b800080000             mov r8d, 0x800
0005fb5a  ba30000000               mov edx, 0x30
0005fb5f  e8bcd3ffff               call 0x5cf20
0005fb64  4883c420                 add rsp, 0x20
0005fb68  5d                       pop rbp
0005fb69  c3                       ret
