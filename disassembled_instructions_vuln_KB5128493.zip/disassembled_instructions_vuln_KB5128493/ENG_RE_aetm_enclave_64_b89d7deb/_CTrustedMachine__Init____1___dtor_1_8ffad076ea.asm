; `CTrustedMachine::Init'::`1'::dtor$1
; aetm_enclave.dll, primary RVA 0x5fdc0, 31 bytes in 1 chunk(s)

; chunk at RVA 0x5fdc0 (31 bytes)
0005fdc0  4055                     push rbp
0005fdc2  4883ec20                 sub rsp, 0x20
0005fdc6  488bea                   mov rbp, rdx
0005fdc9  488b5558                 mov rdx, qword ptr [rbp + 0x58]
0005fdcd  488b12                   mov rdx, qword ptr [rdx]
0005fdd0  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0005fdd4  e8a79bfbff               call 0x19980
0005fdd9  4883c420                 add rsp, 0x20
0005fddd  5d                       pop rbp
0005fdde  c3                       ret
