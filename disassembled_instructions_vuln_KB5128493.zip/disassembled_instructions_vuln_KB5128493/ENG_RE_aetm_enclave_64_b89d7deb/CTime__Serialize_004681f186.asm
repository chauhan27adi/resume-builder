; CTime::Serialize
; aetm_enclave.dll, primary RVA 0x2ed10, 284 bytes in 1 chunk(s)

; chunk at RVA 0x2ed10 (284 bytes)
0002ed10  48895c2418               mov qword ptr [rsp + 0x18], rbx
0002ed15  4889742420               mov qword ptr [rsp + 0x20], rsi
0002ed1a  57                       push rdi
0002ed1b  4883ec30                 sub rsp, 0x30
0002ed1f  33c0                     xor eax, eax
0002ed21  c70203290000             mov dword ptr [rdx], 0x2903
0002ed27  48894208                 mov qword ptr [rdx + 8], rax
0002ed2b  4c8d05ce12fdff           lea r8, [rip - 0x2ed32]
0002ed32  48894210                 mov qword ptr [rdx + 0x10], rax
0002ed36  488bf2                   mov rsi, rdx
0002ed39  894218                   mov dword ptr [rdx + 0x18], eax
0002ed3c  0fb64110                 movzx eax, byte ptr [rcx + 0x10]
0002ed40  488b5108                 mov rdx, qword ptr [rcx + 8]
0002ed44  4889542420               mov qword ptr [rsp + 0x20], rdx
0002ed49  410fb6bc8040420600       movzx edi, byte ptr [r8 + rax*4 + 0x64240]
0002ed52  8d47fd                   lea eax, [rdi - 3]
0002ed55  83f807                   cmp eax, 7
0002ed58  0f8784000000             ja 0x2ede2
0002ed5e  4898                     cdqe
0002ed60  418b8c800cee0200         mov ecx, dword ptr [r8 + rax*4 + 0x2ee0c]
0002ed68  4903c8                   add rcx, r8
0002ed6b  ffe1                     jmp rcx
0002ed6d  0fb6442422               movzx eax, byte ptr [rsp + 0x22]
0002ed72  66895608                 mov word ptr [rsi + 8], dx
0002ed76  88460a                   mov byte ptr [rsi + 0xa], al
0002ed79  eb78                     jmp 0x2edf3
0002ed7b  895608                   mov dword ptr [rsi + 8], edx
0002ed7e  eb73                     jmp 0x2edf3
0002ed80  0fb6442424               movzx eax, byte ptr [rsp + 0x24]
0002ed85  895608                   mov dword ptr [rsi + 8], edx
0002ed88  88460c                   mov byte ptr [rsi + 0xc], al
0002ed8b  eb66                     jmp 0x2edf3
0002ed8d  0fb7442424               movzx eax, word ptr [rsp + 0x24]
0002ed92  895608                   mov dword ptr [rsi + 8], edx
0002ed95  6689460c                 mov word ptr [rsi + 0xc], ax
0002ed99  eb58                     jmp 0x2edf3
0002ed9b  0fb7442424               movzx eax, word ptr [rsp + 0x24]
0002eda0  895608                   mov dword ptr [rsi + 8], edx
0002eda3  6689460c                 mov word ptr [rsi + 0xc], ax
0002eda7  0fb6442426               movzx eax, byte ptr [rsp + 0x26]
0002edac  88460e                   mov byte ptr [rsi + 0xe], al
0002edaf  eb42                     jmp 0x2edf3
0002edb1  48895608                 mov qword ptr [rsi + 8], rdx
0002edb5  eb3c                     jmp 0x2edf3
0002edb7  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
0002edbd  0fb6442428               movzx eax, byte ptr [rsp + 0x28]
0002edc2  f20f114608               movsd qword ptr [rsi + 8], xmm0
0002edc7  884610                   mov byte ptr [rsi + 0x10], al
0002edca  eb27                     jmp 0x2edf3
0002edcc  f20f10442420             movsd xmm0, qword ptr [rsp + 0x20]
0002edd2  0fb7442428               movzx eax, word ptr [rsp + 0x28]
0002edd7  f20f114608               movsd qword ptr [rsi + 8], xmm0
0002eddc  66894610                 mov word ptr [rsi + 0x10], ax
0002ede0  eb11                     jmp 0x2edf3
0002ede2  4c8bc7                   mov r8, rdi
0002ede5  488d542420               lea rdx, [rsp + 0x20]
0002edea  488d4e08                 lea rcx, [rsi + 8]
0002edee  e8c0f40200               call 0x5e2b3
0002edf3  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0002edf8  40887e1b                 mov byte ptr [rsi + 0x1b], dil
0002edfc  c60600                   mov byte ptr [rsi], 0
0002edff  488b742458               mov rsi, qword ptr [rsp + 0x58]
0002ee04  4883c430                 add rsp, 0x30
0002ee08  5f                       pop rdi
0002ee09  c3                       ret
0002ee0a  6690                     nop
0002ee0c  6d                       insd dword ptr [rdi], dx
0002ee0d  ed                       in eax, dx
0002ee0e  0200                     add al, byte ptr [rax]
0002ee10  7bed                     jnp 0x2edff
0002ee12  0200                     add al, byte ptr [rax]
0002ee14  80ed02                   sub ch, 2
0002ee17  008ded02009b             add byte ptr [rbp - 0x64fffd13], cl
0002ee1d  ed                       in eax, dx
0002ee1e  0200                     add al, byte ptr [rax]
0002ee20  b1ed                     mov cl, 0xed
0002ee22  0200                     add al, byte ptr [rax]
0002ee24  b7ed                     mov bh, 0xed
0002ee26  0200                     add al, byte ptr [rax]
0002ee28  cc                       int3
0002ee29  ed                       in eax, dx
0002ee2a  0200                     add al, byte ptr [rax]
