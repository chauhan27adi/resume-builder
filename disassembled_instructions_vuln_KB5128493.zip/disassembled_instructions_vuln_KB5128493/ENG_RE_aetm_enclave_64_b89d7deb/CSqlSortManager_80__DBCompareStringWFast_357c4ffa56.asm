; CSqlSortManager_80::DBCompareStringWFast
; aetm_enclave.dll, primary RVA 0x43cf0, 4800 bytes in 3 chunk(s)

; chunk at RVA 0x43cf0 (112 bytes)
00043cf0  4489442418               mov dword ptr [rsp + 0x18], r8d
00043cf5  4889542410               mov qword ptr [rsp + 0x10], rdx
00043cfa  55                       push rbp
00043cfb  56                       push rsi
00043cfc  57                       push rdi
00043cfd  4154                     push r12
00043cff  4156                     push r14
00043d01  4157                     push r15
00043d03  488d6c24e9               lea rbp, [rsp - 0x17]
00043d08  4881ec88000000           sub rsp, 0x88
00043d0f  448b756f                 mov r14d, dword ptr [rbp + 0x6f]
00043d13  33c9                     xor ecx, ecx
00043d15  4c8b7d77                 mov r15, qword ptr [rbp + 0x77]
00043d19  4d8be1                   mov r12, r9
00043d1c  894dd3                   mov dword ptr [rbp - 0x2d], ecx
00043d1f  458bc8                   mov r9d, r8d
00043d22  894dcf                   mov dword ptr [rbp - 0x31], ecx
00043d25  488bfa                   mov rdi, rdx
00043d28  894dcb                   mov dword ptr [rbp - 0x35], ecx
00043d2b  448bc1                   mov r8d, ecx
00043d2e  4585f6                   test r14d, r14d
00043d31  7405                     je 0x43d38
00043d33  4d85e4                   test r12, r12
00043d36  7415                     je 0x43d4d
00043d38  8b757f                   mov esi, dword ptr [rbp + 0x7f]
00043d3b  85f6                     test esi, esi
00043d3d  7405                     je 0x43d44
00043d3f  4d85ff                   test r15, r15
00043d42  7409                     je 0x43d4d
00043d44  41f7c1f8effc77           test r9d, 0x77fceff8
00043d4b  7413                     je 0x43d60
00043d4d  33c0                     xor eax, eax
00043d4f  4881c488000000           add rsp, 0x88
00043d56  415f                     pop r15
00043d58  415e                     pop r14
00043d5a  415c                     pop r12
00043d5c  5f                       pop rdi
00043d5d  5e                       pop rsi
00043d5e  5d                       pop rbp
00043d5f  c3                       ret

; chunk at RVA 0x43d60 (4552 bytes)
00043d60  4c89ac2480000000         mov qword ptr [rsp + 0x80], r13
00043d68  4585f6                   test r14d, r14d
00043d6b  790b                     jns 0x43d78
00043d6d  498bcc                   mov rcx, r12
00043d70  e8db3b0000               call 0x47950
00043d75  448bf0                   mov r14d, eax
00043d78  85f6                     test esi, esi
00043d7a  790a                     jns 0x43d86
00043d7c  498bcf                   mov rcx, r15
00043d7f  e8cc3b0000               call 0x47950
00043d84  8bf0                     mov esi, eax
00043d86  418bc9                   mov ecx, r9d
00043d89  48899c24c0000000         mov qword ptr [rsp + 0xc0], rbx
00043d91  83e103                   and ecx, 3
00043d94  488d0565c2fbff           lea rax, [rip - 0x43d9b]
00043d9b  418bd1                   mov edx, r9d
00043d9e  c1ea10                   shr edx, 0x10
00043da1  83e203                   and edx, 3
00043da4  8d0c91                   lea ecx, [rcx + rdx*4]
00043da7  33d2                     xor edx, edx
00043da9  448b948830050900         mov r10d, dword ptr [rax + rcx*4 + 0x90530]
00043db1  8bca                     mov ecx, edx
00043db3  44895577                 mov dword ptr [rbp + 0x77], r10d
00043db7  488955ff                 mov qword ptr [rbp - 1], rdx
00043dbb  488955f7                 mov qword ptr [rbp - 9], rdx
00043dbf  448d6a07                 lea r13d, [rdx + 7]
00043dc3  448d4a01                 lea r9d, [rdx + 1]
00043dc7  4585f6                   test r14d, r14d
00043dca  7458                     je 0x43e24
00043dcc  85f6                     test esi, esi
00043dce  7454                     je 0x43e24
00043dd0  488b4f08                 mov rcx, qword ptr [rdi + 8]
00043dd4  410fb70424               movzx eax, word ptr [r12]
00043dd9  448b1c81                 mov r11d, dword ptr [rcx + rax*4]
00043ddd  410fb707                 movzx eax, word ptr [r15]
00043de1  4523da                   and r11d, r10d
00043de4  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00043de8  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00043dec  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
00043def  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043df2  4123da                   and ebx, r10d
00043df5  8945ef                   mov dword ptr [rbp - 0x11], eax
00043df8  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043dfb  8945e3                   mov dword ptr [rbp - 0x1d], eax
00043dfe  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043e01  894567                   mov dword ptr [rbp + 0x67], eax
00043e04  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043e07  8945df                   mov dword ptr [rbp - 0x21], eax
00043e0a  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043e0d  8945d7                   mov dword ptr [rbp - 0x29], eax
00043e10  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043e13  895daf                   mov dword ptr [rbp - 0x51], ebx
00043e16  8945db                   mov dword ptr [rbp - 0x25], eax
00043e19  8b45af                   mov eax, dword ptr [rbp - 0x51]
00043e1c  8945c7                   mov dword ptr [rbp - 0x39], eax
00043e1f  e9cb000000               jmp 0x43eef
00043e24  448b5db3                 mov r11d, dword ptr [rbp - 0x4d]
00043e28  8b5db7                   mov ebx, dword ptr [rbp - 0x49]
00043e2b  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00043e2f  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043e32  8b556f                   mov edx, dword ptr [rbp + 0x6f]
00043e35  8945ef                   mov dword ptr [rbp - 0x11], eax
00043e38  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043e3b  8945e3                   mov dword ptr [rbp - 0x1d], eax
00043e3e  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043e41  8945df                   mov dword ptr [rbp - 0x21], eax
00043e44  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043e47  8945d7                   mov dword ptr [rbp - 0x29], eax
00043e4a  8b456f                   mov eax, dword ptr [rbp + 0x6f]
00043e4d  895daf                   mov dword ptr [rbp - 0x51], ebx
00043e50  8945db                   mov dword ptr [rbp - 0x25], eax
00043e53  8b45af                   mov eax, dword ptr [rbp - 0x51]
00043e56  8945c7                   mov dword ptr [rbp - 0x39], eax
00043e59  895567                   mov dword ptr [rbp + 0x67], edx
00043e5c  eb04                     jmp 0x43e62
00043e5e  488b4df7                 mov rcx, qword ptr [rbp - 9]
00043e62  f7455f00000008           test dword ptr [rbp + 0x5f], 0x8000000
00043e69  0f84fd0f0000             je 0x44e6c
00043e6f  4585f6                   test r14d, r14d
00043e72  7540                     jne 0x43eb4
00043e74  85f6                     test esi, esi
00043e76  0f84bc100000             je 0x44f38
00043e7c  488b4f08                 mov rcx, qword ptr [rdi + 8]
00043e80  4c8d65e7                 lea r12, [rbp - 0x19]
00043e84  b820000000               mov eax, 0x20
00043e89  458bf1                   mov r14d, r9d
00043e8c  668945e7                 mov word ptr [rbp - 0x19], ax
00043e90  448b9980000000           mov r11d, dword ptr [rcx + 0x80]
00043e97  4523da                   and r11d, r10d
00043e9a  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00043e9e  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00043ea2  4585c0                   test r8d, r8d
00043ea5  0f85ab0f0000             jne 0x44e56
00043eab  410fb707                 movzx eax, word ptr [r15]
00043eaf  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
00043eb2  eb33                     jmp 0x43ee7
00043eb4  488b4f08                 mov rcx, qword ptr [rdi + 8]
00043eb8  b820000000               mov eax, 0x20
00043ebd  668945eb                 mov word ptr [rbp - 0x15], ax
00043ec1  4c8d7deb                 lea r15, [rbp - 0x15]
00043ec5  418bf1                   mov esi, r9d
00043ec8  4585c0                   test r8d, r8d
00043ecb  7514                     jne 0x43ee1
00043ecd  410fb70424               movzx eax, word ptr [r12]
00043ed2  448b1c81                 mov r11d, dword ptr [rcx + rax*4]
00043ed6  4523da                   and r11d, r10d
00043ed9  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00043edd  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00043ee1  8b9980000000             mov ebx, dword ptr [rcx + 0x80]
00043ee7  4123da                   and ebx, r10d
00043eea  33d2                     xor edx, edx
00043eec  895daf                   mov dword ptr [rbp - 0x51], ebx
00043eef  895db7                   mov dword ptr [rbp - 0x49], ebx
00043ef2  837f1400                 cmp dword ptr [rdi + 0x14], 0
00043ef6  8955bf                   mov dword ptr [rbp - 0x41], edx
00043ef9  0f8430030000             je 0x4422f
00043eff  48837dff00               cmp qword ptr [rbp - 1], 0
00043f04  0f85a1000000             jne 0x43fab
00043f0a  418bc3                   mov eax, r11d
00043f0d  c1e818                   shr eax, 0x18
00043f10  a8c0                     test al, 0xc0
00043f12  0f8493000000             je 0x43fab
00043f18  837f1800                 cmp dword ptr [rdi + 0x18], 0
00043f1c  7431                     je 0x43f4f
00043f1e  4183fe01                 cmp r14d, 1
00043f22  0f8ed6000000             jle 0x43ffe
00043f28  410fb74c2402             movzx ecx, word ptr [r12 + 2]
00043f2e  418bd3                   mov edx, r11d
00043f31  488b4708                 mov rax, qword ptr [rdi + 8]
00043f35  331488                   xor edx, dword ptr [rax + rcx*4]
00043f38  f7c2ffffffe7             test edx, 0xe7ffffff
00043f3e  0f85ba000000             jne 0x43ffe
00043f44  4983c402                 add r12, 2
00043f48  44894dd3                 mov dword ptr [rbp - 0x2d], r9d
00043f4c  41ffce                   dec r14d
00043f4f  33c0                     xor eax, eax
00043f51  418bce                   mov ecx, r14d
00043f54  440fb7d0                 movzx r10d, ax
00043f58  440fb7c8                 movzx r9d, ax
00043f5c  83e901                   sub ecx, 1
00043f5f  7411                     je 0x43f72
00043f61  83f901                   cmp ecx, 1
00043f64  7406                     je 0x43f6c
00043f66  450fb7542404             movzx r10d, word ptr [r12 + 4]
00043f6c  450fb74c2402             movzx r9d, word ptr [r12 + 2]
00043f72  4c8b4720                 mov r8, qword ptr [rdi + 0x20]
00043f76  410fb70c24               movzx ecx, word ptr [r12]
00043f7b  410fb74004               movzx eax, word ptr [r8 + 4]
00043f80  85c0                     test eax, eax
00043f82  7410                     je 0x43f94
00043f84  6641394806               cmp word ptr [r8 + 6], cx
00043f89  767d                     jbe 0x44008
00043f8b  4983c010                 add r8, 0x10
00043f8f  83e801                   sub eax, 1
00043f92  75f0                     jne 0x43f84
00043f94  448b5577                 mov r10d, dword ptr [rbp + 0x77]
00043f98  837dd300                 cmp dword ptr [rbp - 0x2d], 0
00043f9c  41b901000000             mov r9d, 1
00043fa2  7407                     je 0x43fab
00043fa4  4983ec02                 sub r12, 2
00043fa8  41ffc6                   inc r14d
00043fab  48837df700               cmp qword ptr [rbp - 9], 0
00043fb0  0f8579020000             jne 0x4422f
00043fb6  f645bac0                 test byte ptr [rbp - 0x46], 0xc0
00043fba  0f846f020000             je 0x4422f
00043fc0  837f1800                 cmp dword ptr [rdi + 0x18], 0
00043fc4  0f8441010000             je 0x4410b
00043fca  83fe01                   cmp esi, 1
00043fcd  0f8e2f010000             jle 0x44102
00043fd3  410fb74f02               movzx ecx, word ptr [r15 + 2]
00043fd8  8bd3                     mov edx, ebx
00043fda  488b4708                 mov rax, qword ptr [rdi + 8]
00043fde  331488                   xor edx, dword ptr [rax + rcx*4]
00043fe1  f7c2ffffffe7             test edx, 0xe7ffffff
00043fe7  0f8515010000             jne 0x44102
00043fed  418bd9                   mov ebx, r9d
00043ff0  4983c702                 add r15, 2
00043ff4  895dd3                   mov dword ptr [rbp - 0x2d], ebx
00043ff7  ffce                     dec esi
00043ff9  e910010000               jmp 0x4410e
00043ffe  33c0                     xor eax, eax
00044000  8945d3                   mov dword ptr [rbp - 0x2d], eax
00044003  e949ffffff               jmp 0x43f51
00044008  758a                     jne 0x43f94
0004400a  66453b480c               cmp r9w, word ptr [r8 + 0xc]
0004400f  7283                     jb 0x43f94
00044011  66453b480e               cmp r9w, word ptr [r8 + 0xe]
00044016  0f8778ffffff             ja 0x43f94
0004401c  488b4728                 mov rax, qword ptr [rdi + 0x28]
00044020  410fb74808               movzx ecx, word ptr [r8 + 8]
00044025  488d14c8                 lea rdx, [rax + rcx*8]
00044029  410fb7400a               movzx eax, word ptr [r8 + 0xa]
0004402e  85c0                     test eax, eax
00044030  0f845effffff             je 0x43f94
00044036  6644390a                 cmp word ptr [rdx], r9w
0004403a  7618                     jbe 0x44054
0004403c  4883c208                 add rdx, 8
00044040  83e801                   sub eax, 1
00044043  75f1                     jne 0x44036
00044045  e94affffff               jmp 0x43f94
0004404a  660f1f440000             nop word ptr [rax + rax]
00044050  6644390a                 cmp word ptr [rdx], r9w
00044054  0f853affffff             jne 0x43f94
0004405a  0fb74a02                 movzx ecx, word ptr [rdx + 2]
0004405e  6685c9                   test cx, cx
00044061  745a                     je 0x440bd
00044063  66413bca                 cmp cx, r10w
00044067  740e                     je 0x44077
00044069  4883c208                 add rdx, 8
0004406d  83e801                   sub eax, 1
00044070  75de                     jne 0x44050
00044072  e91dffffff               jmp 0x43f94
00044077  448b5a04                 mov r11d, dword ptr [rdx + 4]
0004407b  44235d77                 and r11d, dword ptr [rbp + 0x77]
0004407f  488b4708                 mov rax, qword ptr [rdi + 8]
00044083  410fb7ca                 movzx ecx, r10w
00044087  448b5577                 mov r10d, dword ptr [rbp + 0x77]
0004408b  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
0004408f  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00044093  8b1488                   mov edx, dword ptr [rax + rcx*4]
00044096  498d442404               lea rax, [r12 + 4]
0004409b  8b4dd3                   mov ecx, dword ptr [rbp - 0x2d]
0004409e  4123d2                   and edx, r10d
000440a1  85c9                     test ecx, ecx
000440a3  8955cf                   mov dword ptr [rbp - 0x31], edx
000440a6  490f45c4                 cmovne rax, r12
000440aa  4c8be0                   mov r12, rax
000440ad  418d46fe                 lea eax, [r14 - 2]
000440b1  410f45c6                 cmovne eax, r14d
000440b5  448bf0                   mov r14d, eax
000440b8  e9dbfeffff               jmp 0x43f98
000440bd  488b4708                 mov rax, qword ptr [rdi + 8]
000440c1  448b5577                 mov r10d, dword ptr [rbp + 0x77]
000440c5  448b5a04                 mov r11d, dword ptr [rdx + 4]
000440c9  4523da                   and r11d, r10d
000440cc  410fb7c9                 movzx ecx, r9w
000440d0  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
000440d4  44895db3                 mov dword ptr [rbp - 0x4d], r11d
000440d8  8b0488                   mov eax, dword ptr [rax + rcx*4]
000440db  8b4dd3                   mov ecx, dword ptr [rbp - 0x2d]
000440de  4123c2                   and eax, r10d
000440e1  8945cf                   mov dword ptr [rbp - 0x31], eax
000440e4  85c9                     test ecx, ecx
000440e6  498d442402               lea rax, [r12 + 2]
000440eb  490f45c4                 cmovne rax, r12
000440ef  4c8be0                   mov r12, rax
000440f2  418d46ff                 lea eax, [r14 - 1]
000440f6  410f45c6                 cmovne eax, r14d
000440fa  448bf0                   mov r14d, eax
000440fd  e996feffff               jmp 0x43f98
00044102  33c0                     xor eax, eax
00044104  8bd8                     mov ebx, eax
00044106  8945d3                   mov dword ptr [rbp - 0x2d], eax
00044109  eb05                     jmp 0x44110
0004410b  8b5dd3                   mov ebx, dword ptr [rbp - 0x2d]
0004410e  33c0                     xor eax, eax
00044110  8bce                     mov ecx, esi
00044112  440fb7c8                 movzx r9d, ax
00044116  440fb7c0                 movzx r8d, ax
0004411a  83e901                   sub ecx, 1
0004411d  740f                     je 0x4412e
0004411f  83f901                   cmp ecx, 1
00044122  7405                     je 0x44129
00044124  450fb74f04               movzx r9d, word ptr [r15 + 4]
00044129  450fb74702               movzx r8d, word ptr [r15 + 2]
0004412e  488b5720                 mov rdx, qword ptr [rdi + 0x20]
00044132  410fb70f                 movzx ecx, word ptr [r15]
00044136  0fb74204                 movzx eax, word ptr [rdx + 4]
0004413a  85c0                     test eax, eax
0004413c  0f84e3000000             je 0x44225
00044142  66394a06                 cmp word ptr [rdx + 6], cx
00044146  760e                     jbe 0x44156
00044148  4883c210                 add rdx, 0x10
0004414c  83e801                   sub eax, 1
0004414f  75f1                     jne 0x44142
00044151  e9cf000000               jmp 0x44225
00044156  0f85c9000000             jne 0x44225
0004415c  66443b420c               cmp r8w, word ptr [rdx + 0xc]
00044161  0f82be000000             jb 0x44225
00044167  66443b420e               cmp r8w, word ptr [rdx + 0xe]
0004416c  0f87b3000000             ja 0x44225
00044172  0fb74a08                 movzx ecx, word ptr [rdx + 8]
00044176  488b4728                 mov rax, qword ptr [rdi + 0x28]
0004417a  488d04c8                 lea rax, [rax + rcx*8]
0004417e  0fb74a0a                 movzx ecx, word ptr [rdx + 0xa]
00044182  85c9                     test ecx, ecx
00044184  0f849b000000             je 0x44225
0004418a  660f1f440000             nop word ptr [rax + rax]
00044190  66443900                 cmp word ptr [rax], r8w
00044194  7612                     jbe 0x441a8
00044196  4883c008                 add rax, 8
0004419a  83e901                   sub ecx, 1
0004419d  75f1                     jne 0x44190
0004419f  e981000000               jmp 0x44225
000441a4  66443900                 cmp word ptr [rax], r8w
000441a8  757b                     jne 0x44225
000441aa  0fb75002                 movzx edx, word ptr [rax + 2]
000441ae  6685d2                   test dx, dx
000441b1  7440                     je 0x441f3
000441b3  66413bd1                 cmp dx, r9w
000441b7  740b                     je 0x441c4
000441b9  4883c008                 add rax, 8
000441bd  83e901                   sub ecx, 1
000441c0  75e2                     jne 0x441a4
000441c2  eb61                     jmp 0x44225
000441c4  8b5004                   mov edx, dword ptr [rax + 4]
000441c7  488b4708                 mov rax, qword ptr [rdi + 8]
000441cb  4123d2                   and edx, r10d
000441ce  410fb7c9                 movzx ecx, r9w
000441d2  8955af                   mov dword ptr [rbp - 0x51], edx
000441d5  8955b7                   mov dword ptr [rbp - 0x49], edx
000441d8  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
000441db  498d4704                 lea rax, [r15 + 4]
000441df  4123ca                   and ecx, r10d
000441e2  85db                     test ebx, ebx
000441e4  894dcb                   mov dword ptr [rbp - 0x35], ecx
000441e7  490f45c7                 cmovne rax, r15
000441eb  4c8bf8                   mov r15, rax
000441ee  8d46fe                   lea eax, [rsi - 2]
000441f1  eb2d                     jmp 0x44220
000441f3  8b4004                   mov eax, dword ptr [rax + 4]
000441f6  4123c2                   and eax, r10d
000441f9  410fb7c8                 movzx ecx, r8w
000441fd  8945af                   mov dword ptr [rbp - 0x51], eax
00044200  8945b7                   mov dword ptr [rbp - 0x49], eax
00044203  488b4708                 mov rax, qword ptr [rdi + 8]
00044207  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004420a  4123c2                   and eax, r10d
0004420d  8945cb                   mov dword ptr [rbp - 0x35], eax
00044210  85db                     test ebx, ebx
00044212  498d4702                 lea rax, [r15 + 2]
00044216  490f45c7                 cmovne rax, r15
0004421a  4c8bf8                   mov r15, rax
0004421d  8d46ff                   lea eax, [rsi - 1]
00044220  0f45c6                   cmovne eax, esi
00044223  8bf0                     mov esi, eax
00044225  85db                     test ebx, ebx
00044227  7406                     je 0x4422f
00044229  4983ef02                 sub r15, 2
0004422d  ffc6                     inc esi
0004422f  0fb75db3                 movzx ebx, word ptr [rbp - 0x4d]
00044233  0fb77db7                 movzx edi, word ptr [rbp - 0x49]
00044237  440fb7d3                 movzx r10d, bx
0004423b  440fb7cf                 movzx r9d, di
0004423f  6641c1ea08               shr r10w, 8
00044244  6641c1e908               shr r9w, 8
00044249  4180fa0b                 cmp r10b, 0xb
0004424d  7615                     jbe 0x44264
0004424f  4180f90b                 cmp r9b, 0xb
00044253  7649                     jbe 0x4429e
00044255  8b45af                   mov eax, dword ptr [rbp - 0x51]
00044258  8945cb                   mov dword ptr [rbp - 0x35], eax
0004425b  44895dcf                 mov dword ptr [rbp - 0x31], r11d
0004425f  e9c0080000               jmp 0x44b24
00044264  4584d2                   test r10b, r10b
00044267  7535                     jne 0x4429e
00044269  488b5557                 mov rdx, qword ptr [rbp + 0x57]
0004426d  4983c402                 add r12, 2
00044271  448b5d77                 mov r11d, dword ptr [rbp + 0x77]
00044275  4183ee01                 sub r14d, 1
00044279  7415                     je 0x44290
0004427b  410fb70c24               movzx ecx, word ptr [r12]
00044280  488b4208                 mov rax, qword ptr [rdx + 8]
00044284  8b0488                   mov eax, dword ptr [rax + rcx*4]
00044287  4123c3                   and eax, r11d
0004428a  89456f                   mov dword ptr [rbp + 0x6f], eax
0004428d  8945b3                   mov dword ptr [rbp - 0x4d], eax
00044290  41b801000000             mov r8d, 1
00044296  418bc0                   mov eax, r8d
00044299  8945bf                   mov dword ptr [rbp - 0x41], eax
0004429c  eb11                     jmp 0x442af
0004429e  448b5d77                 mov r11d, dword ptr [rbp + 0x77]
000442a2  41b801000000             mov r8d, 1
000442a8  8b45bf                   mov eax, dword ptr [rbp - 0x41]
000442ab  488b5557                 mov rdx, qword ptr [rbp + 0x57]
000442af  4584c9                   test r9b, r9b
000442b2  7523                     jne 0x442d7
000442b4  4983c702                 add r15, 2
000442b8  83ee01                   sub esi, 1
000442bb  7414                     je 0x442d1
000442bd  410fb70f                 movzx ecx, word ptr [r15]
000442c1  488b4208                 mov rax, qword ptr [rdx + 8]
000442c5  8b0488                   mov eax, dword ptr [rax + rcx*4]
000442c8  4123c3                   and eax, r11d
000442cb  8945af                   mov dword ptr [rbp - 0x51], eax
000442ce  8945b7                   mov dword ptr [rbp - 0x49], eax
000442d1  418bc0                   mov eax, r8d
000442d4  8945bf                   mov dword ptr [rbp - 0x41], eax
000442d7  448b5d5f                 mov r11d, dword ptr [rbp + 0x5f]
000442db  4183e302                 and r11d, 2
000442df  44895dbb                 mov dword ptr [rbp - 0x45], r11d
000442e3  7454                     je 0x44339
000442e5  4180fa01                 cmp r10b, 1
000442e9  7525                     jne 0x44310
000442eb  4983c402                 add r12, 2
000442ef  4183ee01                 sub r14d, 1
000442f3  7415                     je 0x4430a
000442f5  410fb70c24               movzx ecx, word ptr [r12]
000442fa  488b4208                 mov rax, qword ptr [rdx + 8]
000442fe  8b0488                   mov eax, dword ptr [rax + rcx*4]
00044301  234577                   and eax, dword ptr [rbp + 0x77]
00044304  89456f                   mov dword ptr [rbp + 0x6f], eax
00044307  8945b3                   mov dword ptr [rbp - 0x4d], eax
0004430a  418bc0                   mov eax, r8d
0004430d  8945bf                   mov dword ptr [rbp - 0x41], eax
00044310  4180f901                 cmp r9b, 1
00044314  7523                     jne 0x44339
00044316  4983c702                 add r15, 2
0004431a  83ee01                   sub esi, 1
0004431d  7414                     je 0x44333
0004431f  410fb70f                 movzx ecx, word ptr [r15]
00044323  488b4208                 mov rax, qword ptr [rdx + 8]
00044327  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004432a  234577                   and eax, dword ptr [rbp + 0x77]
0004432d  8945af                   mov dword ptr [rbp - 0x51], eax
00044330  8945b7                   mov dword ptr [rbp - 0x49], eax
00044333  418bc0                   mov eax, r8d
00044336  8945bf                   mov dword ptr [rbp - 0x41], eax
00044339  498bd7                   mov rdx, r15
0004433c  4d8bc4                   mov r8, r12
0004433f  4180fa02                 cmp r10b, 2
00044343  756d                     jne 0x443b2
00044345  0fb645b3                 movzx eax, byte ptr [rbp - 0x4d]
00044349  4c8d1db0bcfbff           lea r11, [rip - 0x44350]
00044350  488d0da9bcfbff           lea rcx, [rip - 0x44357]
00044357  c745ef02000000           mov dword ptr [rbp - 0x11], 2
0004435e  41ffc6                   inc r14d
00044361  4c8d65e7                 lea r12, [rbp - 0x19]
00044365  0fb78c8170a43500         movzx ecx, word ptr [rcx + rax*4 + 0x35a470]
0004436d  410fb7848372a43500       movzx eax, word ptr [r11 + rax*4 + 0x35a472]
00044376  448b5dbb                 mov r11d, dword ptr [rbp - 0x45]
0004437a  668945e9                 mov word ptr [rbp - 0x17], ax
0004437e  488b4557                 mov rax, qword ptr [rbp + 0x57]
00044382  66894de7                 mov word ptr [rbp - 0x19], cx
00044386  488b4008                 mov rax, qword ptr [rax + 8]
0004438a  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004438d  234577                   and eax, dword ptr [rbp + 0x77]
00044390  488b4dff                 mov rcx, qword ptr [rbp - 1]
00044394  89456f                   mov dword ptr [rbp + 0x6f], eax
00044397  8945b3                   mov dword ptr [rbp - 0x4d], eax
0004439a  33c0                     xor eax, eax
0004439c  4885c9                   test rcx, rcx
0004439f  8945cf                   mov dword ptr [rbp - 0x31], eax
000443a2  b801000000               mov eax, 1
000443a7  4c0f45c1                 cmovne r8, rcx
000443ab  8945bf                   mov dword ptr [rbp - 0x41], eax
000443ae  4c8945ff                 mov qword ptr [rbp - 1], r8
000443b2  4180f902                 cmp r9b, 2
000443b6  756c                     jne 0x44424
000443b8  0fb645b7                 movzx eax, byte ptr [rbp - 0x49]
000443bc  4c8d053dbcfbff           lea r8, [rip - 0x443c3]
000443c3  488b7d57                 mov rdi, qword ptr [rbp + 0x57]
000443c7  4c8d7deb                 lea r15, [rbp - 0x15]
000443cb  448b5577                 mov r10d, dword ptr [rbp + 0x77]
000443cf  ffc6                     inc esi
000443d1  41b901000000             mov r9d, 1
000443d7  c745e302000000           mov dword ptr [rbp - 0x1d], 2
000443de  410fb78c8070a43500       movzx ecx, word ptr [r8 + rax*4 + 0x35a470]
000443e7  410fb7848072a43500       movzx eax, word ptr [r8 + rax*4 + 0x35a472]
000443f0  458bc1                   mov r8d, r9d
000443f3  668945ed                 mov word ptr [rbp - 0x13], ax
000443f7  488b4708                 mov rax, qword ptr [rdi + 8]
000443fb  66894deb                 mov word ptr [rbp - 0x15], cx
000443ff  8b1c88                   mov ebx, dword ptr [rax + rcx*4]
00044402  33c0                     xor eax, eax
00044404  488b4df7                 mov rcx, qword ptr [rbp - 9]
00044408  4123da                   and ebx, r10d
0004440b  4885c9                   test rcx, rcx
0004440e  895daf                   mov dword ptr [rbp - 0x51], ebx
00044411  895db7                   mov dword ptr [rbp - 0x49], ebx
00044414  480f45d1                 cmovne rdx, rcx
00044418  8945cb                   mov dword ptr [rbp - 0x35], eax
0004441b  488bca                   mov rcx, rdx
0004441e  488955f7                 mov qword ptr [rbp - 9], rdx
00044422  eb1d                     jmp 0x44441
00044424  85c0                     test eax, eax
00044426  7438                     je 0x44460
00044428  8b5daf                   mov ebx, dword ptr [rbp - 0x51]
0004442b  41b901000000             mov r9d, 1
00044431  488b7d57                 mov rdi, qword ptr [rbp + 0x57]
00044435  448b45bf                 mov r8d, dword ptr [rbp - 0x41]
00044439  448b5577                 mov r10d, dword ptr [rbp + 0x77]
0004443d  488b4df7                 mov rcx, qword ptr [rbp - 9]
00044441  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044445  8b5567                   mov edx, dword ptr [rbp + 0x67]
00044448  4585f6                   test r14d, r14d
0004444b  0f8411faffff             je 0x43e62
00044451  85f6                     test esi, esi
00044453  0f8409faffff             je 0x43e62
00044459  33d2                     xor edx, edx
0004445b  e992faffff               jmp 0x43ef2
00044460  410fb6c2                 movzx eax, r10b
00044464  83f806                   cmp eax, 6
00044467  0f870d010000             ja 0x4457a
0004446d  488d158cbbfbff           lea rdx, [rip - 0x44474]
00044474  8b8c82484f0400           mov ecx, dword ptr [rdx + rax*4 + 0x44f48]
0004447b  4803ca                   add rcx, rdx
0004447e  ffe1                     jmp rcx
00044480  453aca                   cmp r9b, r10b
00044483  0f84fb000000             je 0x44584
00044489  4c8b4557                 mov r8, qword ptr [rbp + 0x57]
0004448d  4585ed                   test r13d, r13d
00044490  7f07                     jg 0x44499
00044492  4183781000               cmp dword ptr [r8 + 0x10], 0
00044497  740c                     je 0x444a5
00044499  33c0                     xor eax, eax
0004449b  c7456703000000           mov dword ptr [rbp + 0x67], 3
000444a2  448be8                   mov r13d, eax
000444a5  418d46ff                 lea eax, [r14 - 1]
000444a9  85c0                     test eax, eax
000444ab  741e                     je 0x444cb
000444ad  498b5008                 mov rdx, qword ptr [r8 + 8]
000444b1  410fb7442402             movzx eax, word ptr [r12 + 2]
000444b7  807c820101               cmp byte ptr [rdx + rax*4 + 1], 1
000444bc  750d                     jne 0x444cb
000444be  4983c402                 add r12, 2
000444c2  41ffce                   dec r14d
000444c5  4183fe01                 cmp r14d, 1
000444c9  75e6                     jne 0x444b1
000444cb  4983c402                 add r12, 2
000444cf  4183ee01                 sub r14d, 1
000444d3  7426                     je 0x444fb
000444d5  498b4008                 mov rax, qword ptr [r8 + 8]
000444d9  ba01000000               mov edx, 1
000444de  410fb70c24               movzx ecx, word ptr [r12]
000444e3  8955bf                   mov dword ptr [rbp - 0x41], edx
000444e6  448b0488                 mov r8d, dword ptr [rax + rcx*4]
000444ea  44234577                 and r8d, dword ptr [rbp + 0x77]
000444ee  4489456f                 mov dword ptr [rbp + 0x6f], r8d
000444f2  448945b3                 mov dword ptr [rbp - 0x4d], r8d
000444f6  e990000000               jmp 0x4458b
000444fb  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
000444ff  ba01000000               mov edx, 1
00044504  8955bf                   mov dword ptr [rbp - 0x41], edx
00044507  e97f000000               jmp 0x4458b
0004450c  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
00044510  448945cf                 mov dword ptr [rbp - 0x31], r8d
00044514  4180f906                 cmp r9b, 6
00044518  746e                     je 0x44588
0004451a  4183fd06                 cmp r13d, 6
0004451e  7f08                     jg 0x44528
00044520  7527                     jne 0x44549
00044522  837ddf00                 cmp dword ptr [rbp - 0x21], 0
00044526  7521                     jne 0x44549
00044528  33c0                     xor eax, eax
0004452a  c745df01000000           mov dword ptr [rbp - 0x21], 1
00044531  4183fd06                 cmp r13d, 6
00044535  c7456703000000           mov dword ptr [rbp + 0x67], 3
0004453c  41bd06000000             mov r13d, 6
00044542  0f4e45d7                 cmovle eax, dword ptr [rbp - 0x29]
00044546  8945d7                   mov dword ptr [rbp - 0x29], eax
00044549  4983c402                 add r12, 2
0004454d  4183ee01                 sub r14d, 1
00044551  741d                     je 0x44570
00044553  488b4557                 mov rax, qword ptr [rbp + 0x57]
00044557  410fb70c24               movzx ecx, word ptr [r12]
0004455c  488b4008                 mov rax, qword ptr [rax + 8]
00044560  448b0488                 mov r8d, dword ptr [rax + rcx*4]
00044564  44234577                 and r8d, dword ptr [rbp + 0x77]
00044568  4489456f                 mov dword ptr [rbp + 0x6f], r8d
0004456c  448945b3                 mov dword ptr [rbp - 0x4d], r8d
00044570  ba01000000               mov edx, 1
00044575  8955bf                   mov dword ptr [rbp - 0x41], edx
00044578  eb11                     jmp 0x4458b
0004457a  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
0004457e  448945cf                 mov dword ptr [rbp - 0x31], r8d
00044582  eb04                     jmp 0x44588
00044584  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
00044588  8b55bf                   mov edx, dword ptr [rbp - 0x41]
0004458b  410fb6c1                 movzx eax, r9b
0004458f  83f806                   cmp eax, 6
00044592  0f8702020000             ja 0x4479a
00044598  488d0d61bafbff           lea rcx, [rip - 0x4459f]
0004459f  8b8c81644f0400           mov ecx, dword ptr [rcx + rax*4 + 0x44f64]
000445a6  488d0553bafbff           lea rax, [rip - 0x445ad]
000445ad  4803c8                   add rcx, rax
000445b0  ffe1                     jmp rcx
000445b2  453aca                   cmp r9b, r10b
000445b5  0f84e5010000             je 0x447a0
000445bb  4c8b4557                 mov r8, qword ptr [rbp + 0x57]
000445bf  4585ed                   test r13d, r13d
000445c2  7f07                     jg 0x445cb
000445c4  4183781000               cmp dword ptr [r8 + 0x10], 0
000445c9  7411                     je 0x445dc
000445cb  41b901000000             mov r9d, 1
000445d1  33c0                     xor eax, eax
000445d3  44894d67                 mov dword ptr [rbp + 0x67], r9d
000445d7  448be8                   mov r13d, eax
000445da  eb06                     jmp 0x445e2
000445dc  41b901000000             mov r9d, 1
000445e2  8d46ff                   lea eax, [rsi - 1]
000445e5  85c0                     test eax, eax
000445e7  741e                     je 0x44607
000445e9  498b5008                 mov rdx, qword ptr [r8 + 8]
000445ed  0f1f00                   nop dword ptr [rax]
000445f0  410fb74702               movzx eax, word ptr [r15 + 2]
000445f5  807c820101               cmp byte ptr [rdx + rax*4 + 1], 1
000445fa  750b                     jne 0x44607
000445fc  4983c702                 add r15, 2
00044600  ffce                     dec esi
00044602  83fe01                   cmp esi, 1
00044605  75e9                     jne 0x445f0
00044607  4983c702                 add r15, 2
0004460b  83ee01                   sub esi, 1
0004460e  7414                     je 0x44624
00044610  410fb70f                 movzx ecx, word ptr [r15]
00044614  498b4008                 mov rax, qword ptr [r8 + 8]
00044618  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004461b  234577                   and eax, dword ptr [rbp + 0x77]
0004461e  8945af                   mov dword ptr [rbp - 0x51], eax
00044621  8945b7                   mov dword ptr [rbp - 0x49], eax
00044624  458bc1                   mov r8d, r9d
00044627  e982010000               jmp 0x447ae
0004462c  8b45af                   mov eax, dword ptr [rbp - 0x51]
0004462f  8945cb                   mov dword ptr [rbp - 0x35], eax
00044632  4180fa06                 cmp r10b, 6
00044636  743a                     je 0x44672
00044638  4183fd06                 cmp r13d, 6
0004463c  7f10                     jg 0x4464e
0004463e  0f8526010000             jne 0x4476a
00044644  837dd700                 cmp dword ptr [rbp - 0x29], 0
00044648  0f851c010000             jne 0x4476a
0004464e  41b901000000             mov r9d, 1
00044654  33c0                     xor eax, eax
00044656  4183fd06                 cmp r13d, 6
0004465a  44894dd7                 mov dword ptr [rbp - 0x29], r9d
0004465e  44894d67                 mov dword ptr [rbp + 0x67], r9d
00044662  0f4e45df                 cmovle eax, dword ptr [rbp - 0x21]
00044666  8945df                   mov dword ptr [rbp - 0x21], eax
00044669  458d6905                 lea r13d, [r9 + 5]
0004466d  e9fe000000               jmp 0x44770
00044672  4183fd06                 cmp r13d, 6
00044676  7f52                     jg 0x446ca
00044678  0f85ba000000             jne 0x44738
0004467e  837ddf00                 cmp dword ptr [rbp - 0x21], 0
00044682  7425                     je 0x446a9
00044684  837dd700                 cmp dword ptr [rbp - 0x29], 0
00044688  41b901000000             mov r9d, 1
0004468e  0f85aa000000             jne 0x4473e
00044694  44894d67                 mov dword ptr [rbp + 0x67], r9d
00044698  458d6905                 lea r13d, [r9 + 5]
0004469c  44894dd7                 mov dword ptr [rbp - 0x29], r9d
000446a0  44894ddf                 mov dword ptr [rbp - 0x21], r9d
000446a4  e995000000               jmp 0x4473e
000446a9  837dd700                 cmp dword ptr [rbp - 0x29], 0
000446ad  741b                     je 0x446ca
000446af  41b901000000             mov r9d, 1
000446b5  c7456703000000           mov dword ptr [rbp + 0x67], 3
000446bc  44894dd7                 mov dword ptr [rbp - 0x29], r9d
000446c0  44894ddf                 mov dword ptr [rbp - 0x21], r9d
000446c4  458d6905                 lea r13d, [r9 + 5]
000446c8  eb74                     jmp 0x4473e
000446ca  3845b3                   cmp byte ptr [rbp - 0x4d], al
000446cd  7549                     jne 0x44718
000446cf  0fb64db6                 movzx ecx, byte ptr [rbp - 0x4a]
000446d3  c1e818                   shr eax, 0x18
000446d6  80e13f                   and cl, 0x3f
000446d9  243f                     and al, 0x3f
000446db  3ac8                     cmp cl, al
000446dd  7318                     jae 0x446f7
000446df  41b901000000             mov r9d, 1
000446e5  44894d67                 mov dword ptr [rbp + 0x67], r9d
000446e9  44894dd7                 mov dword ptr [rbp - 0x29], r9d
000446ed  44894ddf                 mov dword ptr [rbp - 0x21], r9d
000446f1  458d6905                 lea r13d, [r9 + 5]
000446f5  eb47                     jmp 0x4473e
000446f7  0f86a3000000             jbe 0x447a0
000446fd  41b901000000             mov r9d, 1
00044703  c7456703000000           mov dword ptr [rbp + 0x67], 3
0004470a  44894dd7                 mov dword ptr [rbp - 0x29], r9d
0004470e  44894ddf                 mov dword ptr [rbp - 0x21], r9d
00044712  458d6905                 lea r13d, [r9 + 5]
00044716  eb26                     jmp 0x4473e
00044718  41b901000000             mov r9d, 1
0004471e  b803000000               mov eax, 3
00044723  410f42c1                 cmovb eax, r9d
00044727  44894dd7                 mov dword ptr [rbp - 0x29], r9d
0004472b  894567                   mov dword ptr [rbp + 0x67], eax
0004472e  44894ddf                 mov dword ptr [rbp - 0x21], r9d
00044732  458d6905                 lea r13d, [r9 + 5]
00044736  eb06                     jmp 0x4473e
00044738  41b901000000             mov r9d, 1
0004473e  4983c402                 add r12, 2
00044742  4183ee01                 sub r14d, 1
00044746  7428                     je 0x44770
00044748  488b5557                 mov rdx, qword ptr [rbp + 0x57]
0004474c  410fb70c24               movzx ecx, word ptr [r12]
00044751  448b5577                 mov r10d, dword ptr [rbp + 0x77]
00044755  488b4208                 mov rax, qword ptr [rdx + 8]
00044759  448b0488                 mov r8d, dword ptr [rax + rcx*4]
0004475d  4523c2                   and r8d, r10d
00044760  4489456f                 mov dword ptr [rbp + 0x6f], r8d
00044764  448945b3                 mov dword ptr [rbp - 0x4d], r8d
00044768  eb0e                     jmp 0x44778
0004476a  41b901000000             mov r9d, 1
00044770  448b5577                 mov r10d, dword ptr [rbp + 0x77]
00044774  488b5557                 mov rdx, qword ptr [rbp + 0x57]
00044778  4983c702                 add r15, 2
0004477c  83ee01                   sub esi, 1
0004477f  7414                     je 0x44795
00044781  410fb70f                 movzx ecx, word ptr [r15]
00044785  488b4208                 mov rax, qword ptr [rdx + 8]
00044789  8b0488                   mov eax, dword ptr [rax + rcx*4]
0004478c  4123c2                   and eax, r10d
0004478f  8945af                   mov dword ptr [rbp - 0x51], eax
00044792  8945b7                   mov dword ptr [rbp - 0x49], eax
00044795  458bc1                   mov r8d, r9d
00044798  eb14                     jmp 0x447ae
0004479a  8b45af                   mov eax, dword ptr [rbp - 0x51]
0004479d  8945cb                   mov dword ptr [rbp - 0x35], eax
000447a0  85d2                     test edx, edx
000447a2  7434                     je 0x447d8
000447a4  448b45bf                 mov r8d, dword ptr [rbp - 0x41]
000447a8  41b901000000             mov r9d, 1
000447ae  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
000447b2  8b5daf                   mov ebx, dword ptr [rbp - 0x51]
000447b5  8b5567                   mov edx, dword ptr [rbp + 0x67]
000447b8  488b7d57                 mov rdi, qword ptr [rbp + 0x57]
000447bc  448b5577                 mov r10d, dword ptr [rbp + 0x77]
000447c0  4585f6                   test r14d, r14d
000447c3  0f8495f6ffff             je 0x43e5e
000447c9  85f6                     test esi, esi
000447cb  0f848df6ffff             je 0x43e5e
000447d1  33d2                     xor edx, edx
000447d3  e91af7ffff               jmp 0x43ef2
000447d8  4180fa03                 cmp r10b, 3
000447dc  0f85e0010000             jne 0x449c2
000447e2  488b4557                 mov rax, qword ptr [rbp + 0x57]
000447e6  418bc8                   mov ecx, r8d
000447e9  c1e918                   shr ecx, 0x18
000447ec  0fb75040                 movzx edx, word ptr [rax + 0x40]
000447f0  33c0                     xor eax, eax
000447f2  807db301                 cmp byte ptr [rbp - 0x4d], 1
000447f6  8945c3                   mov dword ptr [rbp - 0x3d], eax
000447f9  0f87ae000000             ja 0x448ad
000447ff  8b45cf                   mov eax, dword ptr [rbp - 0x31]
00044802  41b8ffff0000             mov r8d, 0xffff
00044808  448945db                 mov dword ptr [rbp - 0x25], r8d
0004480c  85c0                     test eax, eax
0004480e  0f84c9000000             je 0x448dd
00044814  448b4577                 mov r8d, dword ptr [rbp + 0x77]
00044818  4423c0                   and r8d, eax
0004481b  410fb7c0                 movzx eax, r8w
0004481f  448945db                 mov dword ptr [rbp - 0x25], r8d
00044823  66c1e808                 shr ax, 8
00044827  4489456f                 mov dword ptr [rbp + 0x6f], r8d
0004482b  413ac2                   cmp al, r10b
0004482e  730f                     jae 0x4483f
00044830  41b8ffff0000             mov r8d, 0xffff
00044836  448945db                 mov dword ptr [rbp - 0x25], r8d
0004483a  e99e000000               jmp 0x448dd
0004483f  7566                     jne 0x448a7
00044841  4180f801                 cmp r8b, 1
00044845  770f                     ja 0x44856
00044847  41b8ffff0000             mov r8d, 0xffff
0004484d  448945db                 mov dword ptr [rbp - 0x25], r8d
00044851  e987000000               jmp 0x448dd
00044856  0fb7da                   movzx ebx, dx
00044859  410fb6c0                 movzx eax, r8b
0004485d  0fb65572                 movzx edx, byte ptr [rbp + 0x72]
00044861  80e23f                   and dl, 0x3f
00044864  66c1e308                 shl bx, 8
00044868  660bd8                   or bx, ax
0004486b  0fb6c2                   movzx eax, dl
0004486e  24c6                     and al, 0xc6
00044870  66895d6f                 mov word ptr [rbp + 0x6f], bx
00044874  448b456f                 mov r8d, dword ptr [rbp + 0x6f]
00044878  8845c3                   mov byte ptr [rbp - 0x3d], al
0004487b  0fb6c2                   movzx eax, dl
0004487e  24e4                     and al, 0xe4
00044880  448945db                 mov dword ptr [rbp - 0x25], r8d
00044884  807db300                 cmp byte ptr [rbp - 0x4d], 0
00044888  8845c5                   mov byte ptr [rbp - 0x3b], al
0004488b  750c                     jne 0x44899
0004488d  80e2c5                   and dl, 0xc5
00044890  c645c404                 mov byte ptr [rbp - 0x3c], 4
00044894  8855c6                   mov byte ptr [rbp - 0x3a], dl
00044897  eb4a                     jmp 0x448e3
00044899  b887ff0000               mov eax, 0xff87
0004489e  c645c405                 mov byte ptr [rbp - 0x3c], 5
000448a2  6623d8                   and bx, ax
000448a5  eb30                     jmp 0x448d7
000448a7  410fb7d8                 movzx ebx, r8w
000448ab  eb30                     jmp 0x448dd
000448ad  410fb6c0                 movzx eax, r8b
000448b1  0fb7da                   movzx ebx, dx
000448b4  66c1e308                 shl bx, 8
000448b8  660bd8                   or bx, ax
000448bb  448945cf                 mov dword ptr [rbp - 0x31], r8d
000448bf  448b45db                 mov r8d, dword ptr [rbp - 0x25]
000448c3  0fb6c1                   movzx eax, cl
000448c6  2406                     and al, 6
000448c8  c645c403                 mov byte ptr [rbp - 0x3c], 3
000448cc  8845c3                   mov byte ptr [rbp - 0x3d], al
000448cf  0fb6c1                   movzx eax, cl
000448d2  2424                     and al, 0x24
000448d4  8845c5                   mov byte ptr [rbp - 0x3b], al
000448d7  80e105                   and cl, 5
000448da  884dc6                   mov byte ptr [rbp - 0x3a], cl
000448dd  807db301                 cmp byte ptr [rbp - 0x4d], 1
000448e1  7719                     ja 0x448fc
000448e3  4181f8ffff0000           cmp r8d, 0xffff
000448ea  7510                     jne 0x448fc
000448ec  33c0                     xor eax, eax
000448ee  448945b3                 mov dword ptr [rbp - 0x4d], r8d
000448f2  8bc8                     mov ecx, eax
000448f4  8945c3                   mov dword ptr [rbp - 0x3d], eax
000448f7  418bd8                   mov ebx, r8d
000448fa  eb0f                     jmp 0x4490b
000448fc  8b4dc3                   mov ecx, dword ptr [rbp - 0x3d]
000448ff  66895db3                 mov word ptr [rbp - 0x4d], bx
00044903  c645b602                 mov byte ptr [rbp - 0x4a], 2
00044907  448b45b3                 mov r8d, dword ptr [rbp - 0x4d]
0004490b  4489456f                 mov dword ptr [rbp + 0x6f], r8d
0004490f  4183fd02                 cmp r13d, 2
00044913  0f8ea9000000             jle 0x449c2
00044919  4180f903                 cmp r9b, 3
0004491d  0f84a9000000             je 0x449cc
00044923  807dc300                 cmp byte ptr [rbp - 0x3d], 0
00044927  7419                     je 0x44942
00044929  4585db                   test r11d, r11d
0004492c  7514                     jne 0x44942
0004492e  b903000000               mov ecx, 3
00044933  458d6b02                 lea r13d, [r11 + 2]
00044937  894d67                   mov dword ptr [rbp + 0x67], ecx
0004493a  458bd8                   mov r11d, r8d
0004493d  e9e7010000               jmp 0x44b29
00044942  4183fd03                 cmp r13d, 3
00044946  0f8ed4010000             jle 0x44b20
0004494c  8bc1                     mov eax, ecx
0004494e  c1e808                   shr eax, 8
00044951  84c0                     test al, al
00044953  7419                     je 0x4496e
00044955  4585db                   test r11d, r11d
00044958  7514                     jne 0x4496e
0004495a  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
0004495e  b903000000               mov ecx, 3
00044963  894d67                   mov dword ptr [rbp + 0x67], ecx
00044966  448be9                   mov r13d, ecx
00044969  e9bb010000               jmp 0x44b29
0004496e  4183fd04                 cmp r13d, 4
00044972  0f8ea8010000             jle 0x44b20
00044978  8bc1                     mov eax, ecx
0004497a  c1e810                   shr eax, 0x10
0004497d  84c0                     test al, al
0004497f  7415                     je 0x44996
00044981  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044985  b903000000               mov ecx, 3
0004498a  894d67                   mov dword ptr [rbp + 0x67], ecx
0004498d  448d6901                 lea r13d, [rcx + 1]
00044991  e993010000               jmp 0x44b29
00044996  4183fd05                 cmp r13d, 5
0004499a  0f8e80010000             jle 0x44b20
000449a0  8bc1                     mov eax, ecx
000449a2  c1e818                   shr eax, 0x18
000449a5  84c0                     test al, al
000449a7  0f8473010000             je 0x44b20
000449ad  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
000449b1  b903000000               mov ecx, 3
000449b6  894d67                   mov dword ptr [rbp + 0x67], ecx
000449b9  448d6902                 lea r13d, [rcx + 2]
000449bd  e967010000               jmp 0x44b29
000449c2  4180f903                 cmp r9b, 3
000449c6  0f8554010000             jne 0x44b20
000449cc  488b4557                 mov rax, qword ptr [rbp + 0x57]
000449d0  33c9                     xor ecx, ecx
000449d2  440fb64db7               movzx r9d, byte ptr [rbp - 0x49]
000449d7  894dbb                   mov dword ptr [rbp - 0x45], ecx
000449da  440fb74040               movzx r8d, word ptr [rax + 0x40]
000449df  8b45af                   mov eax, dword ptr [rbp - 0x51]
000449e2  8bd0                     mov edx, eax
000449e4  c1ea18                   shr edx, 0x18
000449e7  4180f901                 cmp r9b, 1
000449eb  0f87a4000000             ja 0x44a95
000449f1  b8ffff0000               mov eax, 0xffff
000449f6  8945c7                   mov dword ptr [rbp - 0x39], eax
000449f9  394dcb                   cmp dword ptr [rbp - 0x35], ecx
000449fc  0f84c4000000             je 0x44ac6
00044a02  8b4577                   mov eax, dword ptr [rbp + 0x77]
00044a05  2345cb                   and eax, dword ptr [rbp - 0x35]
00044a08  8945c7                   mov dword ptr [rbp - 0x39], eax
00044a0b  8945af                   mov dword ptr [rbp - 0x51], eax
00044a0e  66c1e808                 shr ax, 8
00044a12  3c03                     cmp al, 3
00044a14  730d                     jae 0x44a23
00044a16  b8ffff0000               mov eax, 0xffff
00044a1b  8945c7                   mov dword ptr [rbp - 0x39], eax
00044a1e  e9a3000000               jmp 0x44ac6
00044a23  8b45c7                   mov eax, dword ptr [rbp - 0x39]
00044a26  7568                     jne 0x44a90
00044a28  3c01                     cmp al, 1
00044a2a  770d                     ja 0x44a39
00044a2c  b8ffff0000               mov eax, 0xffff
00044a31  8945c7                   mov dword ptr [rbp - 0x39], eax
00044a34  e98d000000               jmp 0x44ac6
00044a39  0fb64db2                 movzx ecx, byte ptr [rbp - 0x4e]
00044a3d  410fb7f8                 movzx edi, r8w
00044a41  0fb6c0                   movzx eax, al
00044a44  80e13f                   and cl, 0x3f
00044a47  66c1e708                 shl di, 8
00044a4b  660bf8                   or di, ax
00044a4e  0fb6c1                   movzx eax, cl
00044a51  24c6                     and al, 0xc6
00044a53  66897daf                 mov word ptr [rbp - 0x51], di
00044a57  8845bb                   mov byte ptr [rbp - 0x45], al
00044a5a  0fb6c1                   movzx eax, cl
00044a5d  24e4                     and al, 0xe4
00044a5f  8845bd                   mov byte ptr [rbp - 0x43], al
00044a62  4584c9                   test r9b, r9b
00044a65  7515                     jne 0x44a7c
00044a67  8b45af                   mov eax, dword ptr [rbp - 0x51]
00044a6a  80e1c5                   and cl, 0xc5
00044a6d  884dbe                   mov byte ptr [rbp - 0x42], cl
00044a70  c645bc04                 mov byte ptr [rbp - 0x44], 4
00044a74  8b4dbb                   mov ecx, dword ptr [rbp - 0x45]
00044a77  8945c7                   mov dword ptr [rbp - 0x39], eax
00044a7a  eb50                     jmp 0x44acc
00044a7c  b887ff0000               mov eax, 0xff87
00044a81  c645bc05                 mov byte ptr [rbp - 0x44], 5
00044a85  6623f8                   and di, ax
00044a88  8b45af                   mov eax, dword ptr [rbp - 0x51]
00044a8b  8945c7                   mov dword ptr [rbp - 0x39], eax
00044a8e  eb2d                     jmp 0x44abd
00044a90  0fb7f8                   movzx edi, ax
00044a93  eb31                     jmp 0x44ac6
00044a95  8945cb                   mov dword ptr [rbp - 0x35], eax
00044a98  410fb7f8                 movzx edi, r8w
00044a9c  0fb6c0                   movzx eax, al
00044a9f  66c1e708                 shl di, 8
00044aa3  660bf8                   or di, ax
00044aa6  c645bc03                 mov byte ptr [rbp - 0x44], 3
00044aaa  0fb6c2                   movzx eax, dl
00044aad  2406                     and al, 6
00044aaf  8845bb                   mov byte ptr [rbp - 0x45], al
00044ab2  0fb6c2                   movzx eax, dl
00044ab5  2424                     and al, 0x24
00044ab7  8845bd                   mov byte ptr [rbp - 0x43], al
00044aba  8b45c7                   mov eax, dword ptr [rbp - 0x39]
00044abd  80e205                   and dl, 5
00044ac0  8855be                   mov byte ptr [rbp - 0x42], dl
00044ac3  8b4dbb                   mov ecx, dword ptr [rbp - 0x45]
00044ac6  4180f901                 cmp r9b, 1
00044aca  7718                     ja 0x44ae4
00044acc  3dffff0000               cmp eax, 0xffff
00044ad1  7511                     jne 0x44ae4
00044ad3  8bf8                     mov edi, eax
00044ad5  8945af                   mov dword ptr [rbp - 0x51], eax
00044ad8  8945b7                   mov dword ptr [rbp - 0x49], eax
00044adb  33c0                     xor eax, eax
00044add  8bc8                     mov ecx, eax
00044adf  8945bb                   mov dword ptr [rbp - 0x45], eax
00044ae2  eb0e                     jmp 0x44af2
00044ae4  66897db7                 mov word ptr [rbp - 0x49], di
00044ae8  c645ba02                 mov byte ptr [rbp - 0x46], 2
00044aec  8b45b7                   mov eax, dword ptr [rbp - 0x49]
00044aef  8945af                   mov dword ptr [rbp - 0x51], eax
00044af2  4183fd02                 cmp r13d, 2
00044af6  7e28                     jle 0x44b20
00044af8  4180fa03                 cmp r10b, 3
00044afc  0f8490010000             je 0x44c92
00044b02  807dbb00                 cmp byte ptr [rbp - 0x45], 0
00044b06  0f8404010000             je 0x44c10
00044b0c  4585db                   test r11d, r11d
00044b0f  0f85fb000000             jne 0x44c10
00044b15  c7456701000000           mov dword ptr [rbp + 0x67], 1
00044b1c  458d6b02                 lea r13d, [r11 + 2]
00044b20  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044b24  b903000000               mov ecx, 3
00044b29  b801000000               mov eax, 1
00044b2e  663bdf                   cmp bx, di
00044b31  0f852b030000             jne 0x44e62
00044b37  f6455f02                 test byte ptr [rbp + 0x5f], 2
00044b3b  0f854e020000             jne 0x44d8f
00044b41  488b5d57                 mov rbx, qword ptr [rbp + 0x57]
00044b45  4585ed                   test r13d, r13d
00044b48  7f0a                     jg 0x44b54
00044b4a  837b1000                 cmp dword ptr [rbx + 0x10], 0
00044b4e  0f843b020000             je 0x44d8f
00044b54  488b7dff                 mov rdi, qword ptr [rbp - 1]
00044b58  440fb645b5               movzx r8d, byte ptr [rbp - 0x4b]
00044b5d  440fb64db9               movzx r9d, byte ptr [rbp - 0x47]
00044b62  4885ff                   test rdi, rdi
00044b65  7538                     jne 0x44b9f
00044b67  418d46ff                 lea eax, [r14 - 1]
00044b6b  85c0                     test eax, eax
00044b6d  7430                     je 0x44b9f
00044b6f  4c8b5308                 mov r10, qword ptr [rbx + 8]
00044b73  410fb7442402             movzx eax, word ptr [r12 + 2]
00044b79  418b0c82                 mov ecx, dword ptr [r10 + rax*4]
00044b7d  0fb7c1                   movzx eax, cx
00044b80  66c1e808                 shr ax, 8
00044b84  3c01                     cmp al, 1
00044b86  7517                     jne 0x44b9f
00044b88  c1e910                   shr ecx, 0x10
00044b8b  4983c402                 add r12, 2
00044b8f  0fb6c1                   movzx eax, cl
00044b92  41ffce                   dec r14d
00044b95  664403c0                 add r8w, ax
00044b99  4183fe01                 cmp r14d, 1
00044b9d  75d4                     jne 0x44b73
00044b9f  48837df700               cmp qword ptr [rbp - 9], 0
00044ba4  7543                     jne 0x44be9
00044ba6  8d46ff                   lea eax, [rsi - 1]
00044ba9  85c0                     test eax, eax
00044bab  743c                     je 0x44be9
00044bad  4c8b5308                 mov r10, qword ptr [rbx + 8]
00044bb1  0f1f4000                 nop dword ptr [rax]
00044bb5  6666660f1f840000000000   nop word ptr [rax + rax]
00044bc0  410fb74702               movzx eax, word ptr [r15 + 2]
00044bc5  418b0c82                 mov ecx, dword ptr [r10 + rax*4]
00044bc9  0fb7c1                   movzx eax, cx
00044bcc  66c1e808                 shr ax, 8
00044bd0  3c01                     cmp al, 1
00044bd2  7515                     jne 0x44be9
00044bd4  c1e910                   shr ecx, 0x10
00044bd7  4983c702                 add r15, 2
00044bdb  0fb6c1                   movzx eax, cl
00044bde  ffce                     dec esi
00044be0  664403c8                 add r9w, ax
00044be4  83fe01                   cmp esi, 1
00044be7  75d7                     jne 0x44bc0
00044be9  66453bc1                 cmp r8w, r9w
00044bed  41b901000000             mov r9d, 1
00044bf3  0f84a0010000             je 0x44d99
00044bf9  ba03000000               mov edx, 3
00044bfe  410f42d1                 cmovb edx, r9d
00044c02  4533c0                   xor r8d, r8d
00044c05  458be8                   mov r13d, r8d
00044c08  895567                   mov dword ptr [rbp + 0x67], edx
00044c0b  e98f010000               jmp 0x44d9f
00044c10  4183fd03                 cmp r13d, 3
00044c14  0f8e06ffffff             jle 0x44b20
00044c1a  8bc1                     mov eax, ecx
00044c1c  c1e808                   shr eax, 8
00044c1f  84c0                     test al, al
00044c21  741d                     je 0x44c40
00044c23  4585db                   test r11d, r11d
00044c26  7518                     jne 0x44c40
00044c28  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044c2c  b903000000               mov ecx, 3
00044c31  448be9                   mov r13d, ecx
00044c34  c7456701000000           mov dword ptr [rbp + 0x67], 1
00044c3b  e9e9feffff               jmp 0x44b29
00044c40  4183fd04                 cmp r13d, 4
00044c44  0f8ed6feffff             jle 0x44b20
00044c4a  8bc1                     mov eax, ecx
00044c4c  c1e810                   shr eax, 0x10
00044c4f  84c0                     test al, al
00044c51  7412                     je 0x44c65
00044c53  c7456701000000           mov dword ptr [rbp + 0x67], 1
00044c5a  41bd04000000             mov r13d, 4
00044c60  e9bbfeffff               jmp 0x44b20
00044c65  4183fd05                 cmp r13d, 5
00044c69  0f8eb1feffff             jle 0x44b20
00044c6f  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044c73  b801000000               mov eax, 1
00044c78  c1e918                   shr ecx, 0x18
00044c7b  84c9                     test cl, cl
00044c7d  8d4802                   lea ecx, [rax + 2]
00044c80  0f84a8feffff             je 0x44b2e
00044c86  894567                   mov dword ptr [rbp + 0x67], eax
00044c89  448d6804                 lea r13d, [rax + 4]
00044c8d  e99cfeffff               jmp 0x44b2e
00044c92  0fb645c3                 movzx eax, byte ptr [rbp - 0x3d]
00044c96  0fb655bb                 movzx edx, byte ptr [rbp - 0x45]
00044c9a  3ac2                     cmp al, dl
00044c9c  7429                     je 0x44cc7
00044c9e  4585db                   test r11d, r11d
00044ca1  7524                     jne 0x44cc7
00044ca3  3ac2                     cmp al, dl
00044ca5  458d6b02                 lea r13d, [r11 + 2]
00044ca9  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044cad  b903000000               mov ecx, 3
00044cb2  448bc1                   mov r8d, ecx
00044cb5  b801000000               mov eax, 1
00044cba  440f42c0                 cmovb r8d, eax
00044cbe  44894567                 mov dword ptr [rbp + 0x67], r8d
00044cc2  e967feffff               jmp 0x44b2e
00044cc7  4183fd03                 cmp r13d, 3
00044ccb  0f8e4ffeffff             jle 0x44b20
00044cd1  448b45c3                 mov r8d, dword ptr [rbp - 0x3d]
00044cd5  8bd1                     mov edx, ecx
00044cd7  418bc0                   mov eax, r8d
00044cda  c1ea08                   shr edx, 8
00044cdd  c1e808                   shr eax, 8
00044ce0  3ac2                     cmp al, dl
00044ce2  7428                     je 0x44d0c
00044ce4  4585db                   test r11d, r11d
00044ce7  7523                     jne 0x44d0c
00044ce9  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044ced  b903000000               mov ecx, 3
00044cf2  3ac2                     cmp al, dl
00044cf4  448bc1                   mov r8d, ecx
00044cf7  b801000000               mov eax, 1
00044cfc  448be9                   mov r13d, ecx
00044cff  440f42c0                 cmovb r8d, eax
00044d03  44894567                 mov dword ptr [rbp + 0x67], r8d
00044d07  e922feffff               jmp 0x44b2e
00044d0c  4183fd04                 cmp r13d, 4
00044d10  0f8e0afeffff             jle 0x44b20
00044d16  418bc0                   mov eax, r8d
00044d19  8bd1                     mov edx, ecx
00044d1b  c1e810                   shr eax, 0x10
00044d1e  c1ea10                   shr edx, 0x10
00044d21  3ac2                     cmp al, dl
00044d23  7422                     je 0x44d47
00044d25  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044d29  b903000000               mov ecx, 3
00044d2e  448bc1                   mov r8d, ecx
00044d31  b801000000               mov eax, 1
00044d36  440f42c0                 cmovb r8d, eax
00044d3a  44894567                 mov dword ptr [rbp + 0x67], r8d
00044d3e  448d6901                 lea r13d, [rcx + 1]
00044d42  e9e7fdffff               jmp 0x44b2e
00044d47  4183fd05                 cmp r13d, 5
00044d4b  7e31                     jle 0x44d7e
00044d4d  418bc0                   mov eax, r8d
00044d50  c1e918                   shr ecx, 0x18
00044d53  c1e818                   shr eax, 0x18
00044d56  3ac1                     cmp al, cl
00044d58  0f84c2fdffff             je 0x44b20
00044d5e  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044d62  b801000000               mov eax, 1
00044d67  ba03000000               mov edx, 3
00044d6c  0f42d0                   cmovb edx, eax
00044d6f  895567                   mov dword ptr [rbp + 0x67], edx
00044d72  448d6804                 lea r13d, [rax + 4]
00044d76  8d4802                   lea ecx, [rax + 2]
00044d79  e9b0fdffff               jmp 0x44b2e
00044d7e  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00044d82  b801000000               mov eax, 1
00044d87  8d4802                   lea ecx, [rax + 2]
00044d8a  e99ffdffff               jmp 0x44b2e
00044d8f  488b7dff                 mov rdi, qword ptr [rbp - 1]
00044d93  41b901000000             mov r9d, 1
00044d99  8b5567                   mov edx, dword ptr [rbp + 0x67]
00044d9c  4533c0                   xor r8d, r8d
00044d9f  8b455f                   mov eax, dword ptr [rbp + 0x5f]
00044da2  2501000200               and eax, 0x20001
00044da7  3d01000200               cmp eax, 0x20001
00044dac  7426                     je 0x44dd4
00044dae  4183fd01                 cmp r13d, 1
00044db2  7e20                     jle 0x44dd4
00044db4  0fb645ba                 movzx eax, byte ptr [rbp - 0x46]
00044db8  0fb64db6                 movzx ecx, byte ptr [rbp - 0x4a]
00044dbc  243f                     and al, 0x3f
00044dbe  80e13f                   and cl, 0x3f
00044dc1  3ac8                     cmp cl, al
00044dc3  740f                     je 0x44dd4
00044dc5  ba03000000               mov edx, 3
00044dca  458be9                   mov r13d, r9d
00044dcd  410f42d1                 cmovb edx, r9d
00044dd1  895567                   mov dword ptr [rbp + 0x67], edx
00044dd4  4885ff                   test rdi, rdi
00044dd7  7411                     je 0x44dea
00044dd9  836def01                 sub dword ptr [rbp - 0x11], 1
00044ddd  750b                     jne 0x44dea
00044ddf  4c8be7                   mov r12, rdi
00044de2  4c8945ff                 mov qword ptr [rbp - 1], r8
00044de6  448945cf                 mov dword ptr [rbp - 0x31], r8d
00044dea  488b4df7                 mov rcx, qword ptr [rbp - 9]
00044dee  4885c9                   test rcx, rcx
00044df1  7414                     je 0x44e07
00044df3  836de301                 sub dword ptr [rbp - 0x1d], 1
00044df7  750e                     jne 0x44e07
00044df9  4c8bf9                   mov r15, rcx
00044dfc  448945cb                 mov dword ptr [rbp - 0x35], r8d
00044e00  498bc8                   mov rcx, r8
00044e03  48894df7                 mov qword ptr [rbp - 9], rcx
00044e07  8b5daf                   mov ebx, dword ptr [rbp - 0x51]
00044e0a  4983c402                 add r12, 2
00044e0e  488b7d57                 mov rdi, qword ptr [rbp + 0x57]
00044e12  4983c702                 add r15, 2
00044e16  448b45bf                 mov r8d, dword ptr [rbp - 0x41]
00044e1a  ffce                     dec esi
00044e1c  448b5577                 mov r10d, dword ptr [rbp + 0x77]
00044e20  4183ee01                 sub r14d, 1
00044e24  0f8438f0ffff             je 0x43e62
00044e2a  85f6                     test esi, esi
00044e2c  742f                     je 0x44e5d
00044e2e  488b4f08                 mov rcx, qword ptr [rdi + 8]
00044e32  410fb70424               movzx eax, word ptr [r12]
00044e37  448b1c81                 mov r11d, dword ptr [rcx + rax*4]
00044e3b  410fb707                 movzx eax, word ptr [r15]
00044e3f  4523da                   and r11d, r10d
00044e42  44895d6f                 mov dword ptr [rbp + 0x6f], r11d
00044e46  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00044e4a  8b1c81                   mov ebx, dword ptr [rcx + rax*4]
00044e4d  4123da                   and ebx, r10d
00044e50  895daf                   mov dword ptr [rbp - 0x51], ebx
00044e53  895db7                   mov dword ptr [rbp - 0x49], ebx
00044e56  33d2                     xor edx, edx
00044e58  e995f0ffff               jmp 0x43ef2
00044e5d  e900f0ffff               jmp 0x43e62
00044e62  0f42c8                   cmovb ecx, eax
00044e65  8bc1                     mov eax, ecx
00044e67  e99b000000               jmp 0x44f07
00044e6c  4585f6                   test r14d, r14d
00044e6f  7543                     jne 0x44eb4
00044e71  85f6                     test esi, esi
00044e73  0f84bf000000             je 0x44f38
00044e79  448b555f                 mov r10d, dword ptr [rbp + 0x5f]
00044e7d  4585d2                   test r10d, r10d
00044e80  791f                     jns 0x44ea1
00044e82  4885c9                   test rcx, rcx
00044e85  0f84ad000000             je 0x44f38
00044e8b  443975e3                 cmp dword ptr [rbp - 0x1d], r14d
00044e8f  0f84a3000000             je 0x44f38
00044e95  4183fd07                 cmp r13d, 7
00044e99  410f44d1                 cmove edx, r9d
00044e9d  8bc2                     mov eax, edx
00044e9f  eb66                     jmp 0x44f07
00044ea1  4585c0                   test r8d, r8d
00044ea4  4d8be7                   mov r12, r15
00044ea7  448bf6                   mov r14d, esi
00044eaa  440f45db                 cmovne r11d, ebx
00044eae  44895db3                 mov dword ptr [rbp - 0x4d], r11d
00044eb2  eb0a                     jmp 0x44ebe
00044eb4  448b555f                 mov r10d, dword ptr [rbp + 0x5f]
00044eb8  41b903000000             mov r9d, 3
00044ebe  4c8d1d3bb1fbff           lea r11, [rip - 0x44ec5]
00044ec5  4585c0                   test r8d, r8d
00044ec8  7407                     je 0x44ed1
00044eca  33c0                     xor eax, eax
00044ecc  448bc0                   mov r8d, eax
00044ecf  eb0f                     jmp 0x44ee0
00044ed1  410fb70c24               movzx ecx, word ptr [r12]
00044ed6  488b4708                 mov rax, qword ptr [rdi + 8]
00044eda  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
00044edd  894db3                   mov dword ptr [rbp - 0x4d], ecx
00044ee0  0fb745b3                 movzx eax, word ptr [rbp - 0x4d]
00044ee4  c1e808                   shr eax, 8
00044ee7  83f80b                   cmp eax, 0xb
00044eea  7718                     ja 0x44f04
00044eec  418b8c83804f0400         mov ecx, dword ptr [r11 + rax*4 + 0x44f80]
00044ef4  4903cb                   add rcx, r11
00044ef7  ffe1                     jmp rcx
00044ef9  41f6c202                 test r10b, 2
00044efd  752f                     jne 0x44f2e
00044eff  4585ed                   test r13d, r13d
00044f02  7e2a                     jle 0x44f2e
00044f04  418bc1                   mov eax, r9d
00044f07  488b9c24c0000000         mov rbx, qword ptr [rsp + 0xc0]
00044f0f  4c8bac2480000000         mov r13, qword ptr [rsp + 0x80]
00044f17  4881c488000000           add rsp, 0x88
00044f1e  415f                     pop r15
00044f20  415e                     pop r14
00044f22  415c                     pop r12
00044f24  5f                       pop rdi
00044f25  5e                       pop rsi
00044f26  5d                       pop rbp
00044f27  c3                       ret

; chunk at RVA 0x44f28 (136 bytes)
00044f28  41f6c204                 test r10b, 4
00044f2c  74d6                     je 0x44f04
00044f2e  4983c402                 add r12, 2
00044f32  4183ee01                 sub r14d, 1
00044f36  758d                     jne 0x44ec5
00044f38  b802000000               mov eax, 2
00044f3d  4183fd07                 cmp r13d, 7
00044f41  0f44d0                   cmove edx, eax
00044f44  8bc2                     mov eax, edx
00044f46  ebbf                     jmp 0x44f07
00044f48  844504                   test byte ptr [rbp + 4], al
00044f4b  008044040084             add byte ptr [rax - 0x7bfffbbc], al
00044f51  450400                   add al, 0
00044f54  844504                   test byte ptr [rbp + 4], al
00044f57  00844504008445           add byte ptr [rbp + rax*2 + 0x45840004], al
00044f5e  0400                     add al, 0
00044f60  0c45                     or al, 0x45
00044f62  0400                     add al, 0
00044f64  a0470400b2450400a0       movabs al, byte ptr [0xa0000445b2000447]
00044f6d  470400                   add al, 0
00044f70  a0470400a0470400a0       movabs al, byte ptr [0xa0000447a0000447]
00044f79  470400                   add al, 0
00044f7c  2c46                     sub al, 0x46
00044f7e  0400                     add al, 0
00044f80  2e4f0400                 add al, 0
00044f84  f9                       stc
00044f85  4e0400                   add al, 0
00044f88  044f                     add al, 0x4f
00044f8a  0400                     add al, 0
00044f8c  044f                     add al, 0x4f
00044f8e  0400                     add al, 0
00044f90  2e4f0400                 add al, 0
00044f94  2e4f0400                 add al, 0
00044f98  284f04                   sub byte ptr [rdi + 4], cl
00044f9b  0028                     add byte ptr [rax], ch
00044f9d  4f0400                   add al, 0
00044fa0  284f04                   sub byte ptr [rdi + 4], cl
00044fa3  0028                     add byte ptr [rax], ch
00044fa5  4f0400                   add al, 0
00044fa8  284f04                   sub byte ptr [rdi + 4], cl
00044fab  0028                     add byte ptr [rax], ch
00044fad  4f0400                   add al, 0
