; CEsCompBase::~CEsCompBase
; aetm_enclave.dll, primary RVA 0x1f960, 199 bytes in 1 chunk(s)

; chunk at RVA 0x1f960 (199 bytes)
0001f960  48894c2408               mov qword ptr [rsp + 8], rcx
0001f965  57                       push rdi
0001f966  4883ec30                 sub rsp, 0x30
0001f96a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0001f973  48895c2448               mov qword ptr [rsp + 0x48], rbx
0001f978  488bf9                   mov rdi, rcx
0001f97b  488d0586510400           lea rax, [rip + 0x45186]
0001f982  488901                   mov qword ptr [rcx], rax
0001f985  f6410808                 test byte ptr [rcx + 8], 8
0001f989  488b4918                 mov rcx, qword ptr [rcx + 0x18]
0001f98d  7507                     jne 0x1f996
0001f98f  e848d50300               call 0x5cedc
0001f994  eb34                     jmp 0x1f9ca
0001f996  4885c9                   test rcx, rcx
0001f999  742f                     je 0x1f9ca
0001f99b  488d59f8                 lea rbx, [rcx - 8]
0001f99f  4c8d0d5aeb0000           lea r9, [rip + 0xeb5a]
0001f9a6  4c8b03                   mov r8, qword ptr [rbx]
0001f9a9  ba30000000               mov edx, 0x30
0001f9ae  e86dd50300               call 0x5cf20
0001f9b3  488b03                   mov rax, qword ptr [rbx]
0001f9b6  488d1440                 lea rdx, [rax + rax*2]
0001f9ba  48c1e204                 shl rdx, 4
0001f9be  4883c208                 add rdx, 8
0001f9c2  488bcb                   mov rcx, rbx
0001f9c5  e832d50300               call 0x5cefc
0001f9ca  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0001f9ce  e809d50300               call 0x5cedc
0001f9d3  90                       nop
0001f9d4  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
0001f9d8  4885c9                   test rcx, rcx
0001f9db  7437                     je 0x1fa14
0001f9dd  33db                     xor ebx, ebx
0001f9df  395f78                   cmp dword ptr [rdi + 0x78], ebx
0001f9e2  762a                     jbe 0x1fa0e
0001f9e4  488bd1                   mov rdx, rcx
0001f9e7  4c8b04d9                 mov r8, qword ptr [rcx + rbx*8]
0001f9eb  4d85c0                   test r8, r8
0001f9ee  7414                     je 0x1fa04
0001f9f0  498b00                   mov rax, qword ptr [r8]
0001f9f3  ba01000000               mov edx, 1
0001f9f8  498bc8                   mov rcx, r8
0001f9fb  ff10                     call qword ptr [rax]
0001f9fd  488b4f70                 mov rcx, qword ptr [rdi + 0x70]
0001fa01  488bd1                   mov rdx, rcx
0001fa04  ffc3                     inc ebx
0001fa06  3b5f78                   cmp ebx, dword ptr [rdi + 0x78]
0001fa09  72dc                     jb 0x1f9e7
0001fa0b  488bca                   mov rcx, rdx
0001fa0e  e8c9d40300               call 0x5cedc
0001fa13  90                       nop
0001fa14  488d4f28                 lea rcx, [rdi + 0x28]
0001fa18  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0001fa1d  4883c430                 add rsp, 0x30
0001fa21  5f                       pop rdi
0001fa22  e9b9c80000               jmp 0x2c2e0
