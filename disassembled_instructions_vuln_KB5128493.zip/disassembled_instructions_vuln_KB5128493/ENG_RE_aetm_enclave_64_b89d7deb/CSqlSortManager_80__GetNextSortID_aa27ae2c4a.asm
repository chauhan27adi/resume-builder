; CSqlSortManager_80::GetNextSortID
; aetm_enclave.dll, primary RVA 0x45020, 3003 bytes in 1 chunk(s)

; chunk at RVA 0x45020 (3003 bytes)
00045020  48895c2408               mov qword ptr [rsp + 8], rbx
00045025  44894c2420               mov dword ptr [rsp + 0x20], r9d
0004502a  55                       push rbp
0004502b  56                       push rsi
0004502c  57                       push rdi
0004502d  4154                     push r12
0004502f  4155                     push r13
00045031  4156                     push r14
00045033  4157                     push r15
00045035  4883ec40                 sub rsp, 0x40
00045039  418b8088000000           mov eax, dword ptr [r8 + 0x88]
00045040  4c8bea                   mov r13, rdx
00045043  33d2                     xor edx, edx
00045045  498bd8                   mov rbx, r8
00045048  448bda                   mov r11d, edx
0004504b  89542424                 mov dword ptr [rsp + 0x24], edx
0004504f  8bf2                     mov esi, edx
00045051  89542430                 mov dword ptr [rsp + 0x30], edx
00045055  8bea                     mov ebp, edx
00045057  8954242c                 mov dword ptr [rsp + 0x2c], edx
0004505b  8bfa                     mov edi, edx
0004505d  89942490000000           mov dword ptr [rsp + 0x90], edx
00045064  41398084000000           cmp dword ptr [r8 + 0x84], eax
0004506b  0f8c720a0000             jl 0x45ae3
00045071  488b8424b8000000         mov rax, qword ptr [rsp + 0xb8]
00045079  4885c0                   test rax, rax
0004507c  7402                     je 0x45080
0004507e  8810                     mov byte ptr [rax], dl
00045080  0fb7842490000000         movzx eax, word ptr [rsp + 0x90]
00045088  89442428                 mov dword ptr [rsp + 0x28], eax
0004508c  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
00045094  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
0004509c  0f1f4000                 nop dword ptr [rax]
000450a0  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
000450a3  4c8d733c                 lea r14, [rbx + 0x3c]
000450a7  41bf01000000             mov r15d, 1
000450ad  83f904                   cmp ecx, 4
000450b0  0f8d8e000000             jge 0x45144
000450b6  488b4330                 mov rax, qword ptr [rbx + 0x30]
000450ba  660f1f440000             nop word ptr [rax + rax]
000450c0  4885c0                   test rax, rax
000450c3  745b                     je 0x45120
000450c5  488b4318                 mov rax, qword ptr [rbx + 0x18]
000450c9  4885c0                   test rax, rax
000450cc  740b                     je 0x450d9
000450ce  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
000450d2  ffd0                     call rax
000450d4  0fb7c8                   movzx ecx, ax
000450d7  eb12                     jmp 0x450eb
000450d9  48635338                 movsxd rdx, dword ptr [rbx + 0x38]
000450dd  488b4328                 mov rax, qword ptr [rbx + 0x28]
000450e1  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
000450e5  8d4201                   lea eax, [rdx + 1]
000450e8  894338                   mov dword ptr [rbx + 0x38], eax
000450eb  4863435c                 movsxd rax, dword ptr [rbx + 0x5c]
000450ef  66894c433c               mov word ptr [rbx + rax*2 + 0x3c], cx
000450f4  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
000450f7  48ff4b30                 dec qword ptr [rbx + 0x30]
000450fb  ffc1                     inc ecx
000450fd  488b4330                 mov rax, qword ptr [rbx + 0x30]
00045101  894b5c                   mov dword ptr [rbx + 0x5c], ecx
00045104  83f904                   cmp ecx, 4
00045107  7cb7                     jl 0x450c0
00045109  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
0004510e  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
00045116  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
0004511e  eb2c                     jmp 0x4514c
00045120  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
00045128  4533db                   xor r11d, r11d
0004512b  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
00045133  4863c1                   movsxd rax, ecx
00045136  6644895c433c             mov word ptr [rbx + rax*2 + 0x3c], r11w
0004513c  8b4b5c                   mov ecx, dword ptr [rbx + 0x5c]
0004513f  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
00045144  85c9                     test ecx, ecx
00045146  0f8476090000             je 0x45ac2
0004514c  837b0400                 cmp dword ptr [rbx + 4], 0
00045150  7413                     je 0x45165
00045152  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
00045156  6639433c                 cmp word ptr [rbx + 0x3c], ax
0004515a  7509                     jne 0x45165
0004515c  413bcf                   cmp ecx, r15d
0004515f  0f844f090000             je 0x45ab4
00045165  4c638388000000           movsxd r8, dword ptr [rbx + 0x88]
0004516c  443b8380000000           cmp r8d, dword ptr [rbx + 0x80]
00045173  0f8d42090000             jge 0x45abb
00045179  498b4508                 mov rax, qword ptr [r13 + 8]
0004517d  0fb74b3c                 movzx ecx, word ptr [rbx + 0x3c]
00045181  8b1488                   mov edx, dword ptr [rax + rcx*4]
00045184  235314                   and edx, dword ptr [rbx + 0x14]
00045187  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004518b  42891480                 mov dword ptr [rax + r8*4], edx
0004518f  33d2                     xor edx, edx
00045191  4585c9                   test r9d, r9d
00045194  740e                     je 0x451a4
00045196  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004519d  488b4370                 mov rax, qword ptr [rbx + 0x70]
000451a1  891488                   mov dword ptr [rax + rcx*4], edx
000451a4  85ff                     test edi, edi
000451a6  0f8513020000             jne 0x453bf
000451ac  397b04                   cmp dword ptr [rbx + 4], edi
000451af  747d                     je 0x4522e
000451b1  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
000451b5  6639433c                 cmp word ptr [rbx + 0x3c], ax
000451b9  7573                     jne 0x4522e
000451bb  44397b5c                 cmp dword ptr [rbx + 0x5c], r15d
000451bf  7e6d                     jle 0x4522e
000451c1  488d533e                 lea rdx, [rbx + 0x3e]
000451c5  448d471e                 lea r8d, [rdi + 0x1e]
000451c9  488d4b3c                 lea rcx, [rbx + 0x3c]
000451cd  e8ed900100               call 0x5e2bf
000451d2  ff4b5c                   dec dword ptr [rbx + 0x5c]
000451d5  0fb74b3c                 movzx ecx, word ptr [rbx + 0x3c]
000451d9  498b4508                 mov rax, qword ptr [r13 + 8]
000451dd  8b1488                   mov edx, dword ptr [rax + rcx*4]
000451e0  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
000451e7  488b4368                 mov rax, qword ptr [rbx + 0x68]
000451eb  235314                   and edx, dword ptr [rbx + 0x14]
000451ee  891488                   mov dword ptr [rax + rcx*4], edx
000451f1  4c8d1508aefbff           lea r10, [rip - 0x451f8]
000451f8  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
000451ff  4533db                   xor r11d, r11d
00045202  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
00045209  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
0004520d  450fb70c90               movzx r9d, word ptr [r8 + rdx*4]
00045212  418bc1                   mov eax, r9d
00045215  c1e808                   shr eax, 8
00045218  83f80b                   cmp eax, 0xb
0004521b  0f8765070000             ja 0x45986
00045221  418b8c82405b0400         mov ecx, dword ptr [r10 + rax*4 + 0x45b40]
00045229  4903ca                   add rcx, r10
0004522c  ffe1                     jmp rcx
0004522e  4585d2                   test r10d, r10d
00045231  7408                     je 0x4523b
00045233  85f6                     test esi, esi
00045235  0f8584010000             jne 0x453bf
0004523b  41837d1400               cmp dword ptr [r13 + 0x14], 0
00045240  0f8479010000             je 0x453bf
00045246  448b535c                 mov r10d, dword ptr [rbx + 0x5c]
0004524a  453bd7                   cmp r10d, r15d
0004524d  0f8e6c010000             jle 0x453bf
00045253  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004525a  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004525e  f6448803c0               test byte ptr [rax + rcx*4 + 3], 0xc0
00045263  4c8d0c88                 lea r9, [rax + rcx*4]
00045267  0f8452010000             je 0x453bf
0004526d  41837d1800               cmp dword ptr [r13 + 0x18], 0
00045272  743d                     je 0x452b1
00045274  89542424                 mov dword ptr [rsp + 0x24], edx
00045278  448bda                   mov r11d, edx
0004527b  4183fa02                 cmp r10d, 2
0004527f  7e30                     jle 0x452b1
00045281  0fb7433e                 movzx eax, word ptr [rbx + 0x3e]
00045285  663b430c                 cmp ax, word ptr [rbx + 0xc]
00045289  7426                     je 0x452b1
0004528b  8bc8                     mov ecx, eax
0004528d  498b4508                 mov rax, qword ptr [r13 + 8]
00045291  8b1488                   mov edx, dword ptr [rax + rcx*4]
00045294  235314                   and edx, dword ptr [rbx + 0x14]
00045297  413311                   xor edx, dword ptr [r9]
0004529a  f7c2ffffffe7             test edx, 0xe7ffffff
000452a0  750f                     jne 0x452b1
000452a2  458bdf                   mov r11d, r15d
000452a5  44897c2424               mov dword ptr [rsp + 0x24], r15d
000452aa  4c8d733e                 lea r14, [rbx + 0x3e]
000452ae  41ffca                   dec r10d
000452b1  450fb74e02               movzx r9d, word ptr [r14 + 2]
000452b6  66443b4b0c               cmp r9w, word ptr [rbx + 0xc]
000452bb  0f84f5000000             je 0x453b6
000452c1  498b5520                 mov rdx, qword ptr [r13 + 0x20]
000452c5  0fb74204                 movzx eax, word ptr [rdx + 4]
000452c9  85c0                     test eax, eax
000452cb  0f84e5000000             je 0x453b6
000452d1  410fb70e                 movzx ecx, word ptr [r14]
000452d5  66394a06                 cmp word ptr [rdx + 6], cx
000452d9  760e                     jbe 0x452e9
000452db  4883c210                 add rdx, 0x10
000452df  412bc7                   sub eax, r15d
000452e2  75f1                     jne 0x452d5
000452e4  e9cd000000               jmp 0x453b6
000452e9  0f85c7000000             jne 0x453b6
000452ef  66443b4a0c               cmp r9w, word ptr [rdx + 0xc]
000452f4  0f82bc000000             jb 0x453b6
000452fa  66443b4a0e               cmp r9w, word ptr [rdx + 0xe]
000452ff  0f87b1000000             ja 0x453b6
00045305  0fb74a08                 movzx ecx, word ptr [rdx + 8]
00045309  498b4528                 mov rax, qword ptr [r13 + 0x28]
0004530d  440fb7420a               movzx r8d, word ptr [rdx + 0xa]
00045312  488d3cc8                 lea rdi, [rax + rcx*8]
00045316  4585c0                   test r8d, r8d
00045319  0f8490000000             je 0x453af
0004531f  90                       nop
00045320  6644390f                 cmp word ptr [rdi], r9w
00045324  760f                     jbe 0x45335
00045326  4883c708                 add rdi, 8
0004532a  452bc7                   sub r8d, r15d
0004532d  75f1                     jne 0x45320
0004532f  eb7e                     jmp 0x453af
00045331  6644390f                 cmp word ptr [rdi], r9w
00045335  7578                     jne 0x453af
00045337  0fb74f02                 movzx ecx, word ptr [rdi + 2]
0004533b  6685c9                   test cx, cx
0004533e  743d                     je 0x4537d
00045340  4183fa02                 cmp r10d, 2
00045344  7e10                     jle 0x45356
00045346  410fb74604               movzx eax, word ptr [r14 + 4]
0004534b  663bc8                   cmp cx, ax
0004534e  7506                     jne 0x45356
00045350  6639430c                 cmp word ptr [rbx + 0xc], ax
00045354  750b                     jne 0x45361
00045356  4883c708                 add rdi, 8
0004535a  452bc7                   sub r8d, r15d
0004535d  75d2                     jne 0x45331
0004535f  eb4e                     jmp 0x453af
00045361  4585db                   test r11d, r11d
00045364  7535                     jne 0x4539b
00045366  488d5340                 lea rdx, [rbx + 0x40]
0004536a  458d431c                 lea r8d, [r11 + 0x1c]
0004536e  488d4b3c                 lea rcx, [rbx + 0x3c]
00045372  e8488f0100               call 0x5e2bf
00045377  83435cfe                 add dword ptr [rbx + 0x5c], -2
0004537b  eb19                     jmp 0x45396
0004537d  4585db                   test r11d, r11d
00045380  7519                     jne 0x4539b
00045382  488d533e                 lea rdx, [rbx + 0x3e]
00045386  458d431e                 lea r8d, [r11 + 0x1e]
0004538a  488d4b3c                 lea rcx, [rbx + 0x3c]
0004538e  e82c8f0100               call 0x5e2bf
00045393  ff4b5c                   dec dword ptr [rbx + 0x5c]
00045396  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
0004539b  8b5704                   mov edx, dword ptr [rdi + 4]
0004539e  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
000453a5  488b4368                 mov rax, qword ptr [rbx + 0x68]
000453a9  235314                   and edx, dword ptr [rbx + 0x14]
000453ac  891488                   mov dword ptr [rax + rcx*4], edx
000453af  8bbc2490000000           mov edi, dword ptr [rsp + 0x90]
000453b6  4585db                   test r11d, r11d
000453b9  7404                     je 0x453bf
000453bb  4983ee02                 sub r14, 2
000453bf  837b0400                 cmp dword ptr [rbx + 4], 0
000453c3  0f8428feffff             je 0x451f1
000453c9  85ff                     test edi, edi
000453cb  0f8520feffff             jne 0x451f1
000453d1  410fb706                 movzx eax, word ptr [r14]
000453d5  4c8d1524acfbff           lea r10, [rip - 0x453dc]
000453dc  ffc5                     inc ebp
000453de  83c0df                   add eax, -0x21
000453e1  896c242c                 mov dword ptr [rsp + 0x2c], ebp
000453e5  83f83e                   cmp eax, 0x3e
000453e8  0f870afeffff             ja 0x451f8
000453ee  4898                     cdqe
000453f0  410fb684029c5b0400       movzx eax, byte ptr [r10 + rax + 0x45b9c]
000453f9  418b8c82705b0400         mov ecx, dword ptr [r10 + rax*4 + 0x45b70]
00045401  4903ca                   add rcx, r10
00045404  ffe1                     jmp rcx
00045406  85f6                     test esi, esi
00045408  0f85eafdffff             jne 0x451f8
0004540e  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045415  33ed                     xor ebp, ebp
00045417  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004541b  bafcff0000               mov edx, 0xfffc
00045420  418bf7                   mov esi, r15d
00045423  44897c2430               mov dword ptr [rsp + 0x30], r15d
00045428  896c242c                 mov dword ptr [rsp + 0x2c], ebp
0004542c  448bfd                   mov r15d, ebp
0004542f  89ac2498000000           mov dword ptr [rsp + 0x98], ebp
00045436  66891488                 mov word ptr [rax + rcx*4], dx
0004543a  e9c0fdffff               jmp 0x451ff
0004543f  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
00045446  4533db                   xor r11d, r11d
00045449  85f6                     test esi, esi
0004544b  0f84b1fdffff             je 0x45202
00045451  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045458  bafbff0000               mov edx, 0xfffb
0004545d  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045461  418bf3                   mov esi, r11d
00045464  44895c2430               mov dword ptr [rsp + 0x30], r11d
00045469  66891488                 mov word ptr [rax + rcx*4], dx
0004546d  e990fdffff               jmp 0x45202
00045472  85f6                     test esi, esi
00045474  0f847efdffff             je 0x451f8
0004547a  413bef                   cmp ebp, r15d
0004547d  0f8575fdffff             jne 0x451f8
00045483  4533db                   xor r11d, r11d
00045486  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
0004548d  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
00045494  0f8468fdffff             je 0x45202
0004549a  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
000454a1  baf9ff0000               mov edx, 0xfff9
000454a6  488b4368                 mov rax, qword ptr [rbx + 0x68]
000454aa  44895c242c               mov dword ptr [rsp + 0x2c], r11d
000454af  66891488                 mov word ptr [rax + rcx*4], dx
000454b3  e94afdffff               jmp 0x45202
000454b8  85f6                     test esi, esi
000454ba  0f8438fdffff             je 0x451f8
000454c0  413bef                   cmp ebp, r15d
000454c3  0f852ffdffff             jne 0x451f8
000454c9  4533db                   xor r11d, r11d
000454cc  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
000454d3  ebb8                     jmp 0x4548d
000454d5  85f6                     test esi, esi
000454d7  0f841bfdffff             je 0x451f8
000454dd  413bef                   cmp ebp, r15d
000454e0  0f8412fdffff             je 0x451f8
000454e6  44397b5c                 cmp dword ptr [rbx + 0x5c], r15d
000454ea  0f8e08fdffff             jle 0x451f8
000454f0  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
000454f7  4533db                   xor r11d, r11d
000454fa  6641837e025d             cmp word ptr [r14 + 2], 0x5d
00045500  0f84fcfcffff             je 0x45202
00045506  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
0004550d  bafaff0000               mov edx, 0xfffa
00045512  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045516  458bfb                   mov r15d, r11d
00045519  66891488                 mov word ptr [rax + rcx*4], dx
0004551d  e9e0fcffff               jmp 0x45202
00045522  85f6                     test esi, esi
00045524  0f85cefcffff             jne 0x451f8
0004552a  4533db                   xor r11d, r11d
0004552d  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
00045534  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
0004553b  0f84c1fcffff             je 0x45202
00045541  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045548  baf7ff0000               mov edx, 0xfff7
0004554d  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045551  66891488                 mov word ptr [rax + rcx*4], dx
00045555  e9a8fcffff               jmp 0x45202
0004555a  85f6                     test esi, esi
0004555c  0f8596fcffff             jne 0x451f8
00045562  4533db                   xor r11d, r11d
00045565  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
0004556c  ebc6                     jmp 0x45534
0004556e  85f6                     test esi, esi
00045570  0f8582fcffff             jne 0x451f8
00045576  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
0004557d  4533db                   xor r11d, r11d
00045580  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
00045587  0f8475fcffff             je 0x45202
0004558d  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045594  bafdff0000               mov edx, 0xfffd
00045599  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004559d  66891488                 mov word ptr [rax + rcx*4], dx
000455a1  e95cfcffff               jmp 0x45202
000455a6  85f6                     test esi, esi
000455a8  0f854afcffff             jne 0x451f8
000455ae  4533db                   xor r11d, r11d
000455b1  f7431000000010           test dword ptr [rbx + 0x10], 0x10000000
000455b8  8bac2498000000           mov ebp, dword ptr [rsp + 0x98]
000455bf  0f843dfcffff             je 0x45202
000455c5  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
000455cc  bafeff0000               mov edx, 0xfffe
000455d1  488b4368                 mov rax, qword ptr [rbx + 0x68]
000455d5  66891488                 mov word ptr [rax + rcx*4], dx
000455d9  e924fcffff               jmp 0x45202
000455de  85f6                     test esi, esi
000455e0  0f8512fcffff             jne 0x451f8
000455e6  4533db                   xor r11d, r11d
000455e9  f7431000000020           test dword ptr [rbx + 0x10], 0x20000000
000455f0  ebc6                     jmp 0x455b8
000455f2  8b4310                   mov eax, dword ptr [rbx + 0x10]
000455f5  a802                     test al, 2
000455f7  751e                     jne 0x45617
000455f9  0fbae01e                 bt eax, 0x1e
000455fd  0f83cd010000             jae 0x457d0
00045603  8b435c                   mov eax, dword ptr [rbx + 0x5c]
00045606  394338                   cmp dword ptr [rbx + 0x38], eax
00045609  0f85c1010000             jne 0x457d0
0004560f  85d2                     test edx, edx
00045611  0f85b9010000             jne 0x457d0
00045617  488d533e                 lea rdx, [rbx + 0x3e]
0004561b  41b81e000000             mov r8d, 0x1e
00045621  488d4b3c                 lea rcx, [rbx + 0x3c]
00045625  e8958c0100               call 0x5e2bf
0004562a  488b8c24c0000000         mov rcx, qword ptr [rsp + 0xc0]
00045632  41bb01000000             mov r11d, 1
00045638  ff4b5c                   dec dword ptr [rbx + 0x5c]
0004563b  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
00045643  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
0004564b  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
00045653  4885c9                   test rcx, rcx
00045656  7430                     je 0x45688
00045658  48ff01                   inc qword ptr [rcx]
0004565b  eb2b                     jmp 0x45688
0004565d  498b4508                 mov rax, qword ptr [r13 + 8]
00045661  410fb70e                 movzx ecx, word ptr [r14]
00045665  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
00045668  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
00045670  8908                     mov dword ptr [rax], ecx
00045672  f6431004                 test byte ptr [rbx + 0x10], 4
00045676  759f                     jne 0x45617
00045678  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
00045680  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
00045688  33d2                     xor edx, edx
0004568a  85ff                     test edi, edi
0004568c  7e0b                     jle 0x45699
0004568e  ffcf                     dec edi
00045690  8910                     mov dword ptr [rax], edx
00045692  89bc2490000000           mov dword ptr [rsp + 0x90], edi
00045699  8b742430                 mov esi, dword ptr [rsp + 0x30]
0004569d  4585db                   test r11d, r11d
000456a0  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
000456a5  8b6c242c                 mov ebp, dword ptr [rsp + 0x2c]
000456a9  0f85f1f9ffff             jne 0x450a0
000456af  41b81e000000             mov r8d, 0x1e
000456b5  488d533e                 lea rdx, [rbx + 0x3e]
000456b9  488d4b3c                 lea rcx, [rbx + 0x3c]
000456bd  e8fd8b0100               call 0x5e2bf
000456c2  83bc249000000000         cmp dword ptr [rsp + 0x90], 0
000456ca  0f84ea020000             je 0x459ba
000456d0  ff4b5c                   dec dword ptr [rbx + 0x5c]
000456d3  ff8388000000             inc dword ptr [rbx + 0x88]
000456d9  8bbc2490000000           mov edi, dword ptr [rsp + 0x90]
000456e0  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
000456e5  e9a2f9ffff               jmp 0x4508c
000456ea  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
000456f2  33d2                     xor edx, edx
000456f4  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
000456fc  8910                     mov dword ptr [rax], edx
000456fe  4585d2                   test r10d, r10d
00045701  7411                     je 0x45714
00045703  395308                   cmp dword ptr [rbx + 8], edx
00045706  0f84a1020000             je 0x459ad
0004570c  85f6                     test esi, esi
0004570e  0f8599020000             jne 0x459ad
00045714  4c63435c                 movsxd r8, dword ptr [rbx + 0x5c]
00045718  498d4e02                 lea rcx, [r14 + 2]
0004571c  4d03c0                   add r8, r8
0004571f  498bd6                   mov rdx, r14
00045722  e8988b0100               call 0x5e2bf
00045727  488b4368                 mov rax, qword ptr [rbx + 0x68]
0004572b  83c703                   add edi, 3
0004572e  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045735  89bc2490000000           mov dword ptr [rsp + 0x90], edi
0004573c  0fb61488                 movzx edx, byte ptr [rax + rcx*4]
00045740  488d0db9a8fbff           lea rcx, [rip - 0x45747]
00045747  0fb7849170a43500         movzx eax, word ptr [rcx + rdx*4 + 0x35a470]
0004574f  66418906                 mov word ptr [r14], ax
00045753  0fb7849172a43500         movzx eax, word ptr [rcx + rdx*4 + 0x35a472]
0004575b  6641894602               mov word ptr [r14 + 2], ax
00045760  8b535c                   mov edx, dword ptr [rbx + 0x5c]
00045763  c7436001000000           mov dword ptr [rbx + 0x60], 1
0004576a  ffc2                     inc edx
0004576c  89535c                   mov dword ptr [rbx + 0x5c], edx
0004576f  410fb74e02               movzx ecx, word ptr [r14 + 2]
00045774  498b4508                 mov rax, qword ptr [r13 + 8]
00045778  807c880102               cmp byte ptr [rax + rcx*4 + 1], 2
0004577d  488d2c88                 lea rbp, [rax + rcx*4]
00045781  7547                     jne 0x457ca
00045783  4c63c2                   movsxd r8, edx
00045786  498d4e04                 lea rcx, [r14 + 4]
0004578a  4d03c0                   add r8, r8
0004578d  498d5602                 lea rdx, [r14 + 2]
00045791  e8298b0100               call 0x5e2bf
00045796  0fb64d00                 movzx ecx, byte ptr [rbp]
0004579a  488d155fa8fbff           lea rdx, [rip - 0x457a1]
000457a1  0fb7848a70a43500         movzx eax, word ptr [rdx + rcx*4 + 0x35a470]
000457a9  6641894602               mov word ptr [r14 + 2], ax
000457ae  0fb7848a72a43500         movzx eax, word ptr [rdx + rcx*4 + 0x35a472]
000457b6  6641894604               mov word ptr [r14 + 4], ax
000457bb  ff435c                   inc dword ptr [rbx + 0x5c]
000457be  ff4360                   inc dword ptr [rbx + 0x60]
000457c1  ffc7                     inc edi
000457c3  89bc2490000000           mov dword ptr [rsp + 0x90], edi
000457ca  41bb01000000             mov r11d, 1
000457d0  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
000457d8  e99bfeffff               jmp 0x45678
000457dd  488b8424b8000000         mov rax, qword ptr [rsp + 0xb8]
000457e5  4885c0                   test rax, rax
000457e8  7413                     je 0x457fd
000457ea  4180f901                 cmp r9b, 1
000457ee  770d                     ja 0x457fd
000457f0  c60001                   mov byte ptr [rax], 1
000457f3  8b9388000000             mov edx, dword ptr [rbx + 0x88]
000457f9  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
000457fd  4863c2                   movsxd rax, edx
00045800  41803c8001               cmp byte ptr [r8 + rax*4], 1
00045805  761f                     jbe 0x45826
00045807  498b4508                 mov rax, qword ptr [r13 + 8]
0004580b  410fb70e                 movzx ecx, word ptr [r14]
0004580f  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
00045812  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
0004581a  8908                     mov dword ptr [rax], ecx
0004581c  8b9388000000             mov edx, dword ptr [rbx + 0x88]
00045822  4c8b4368                 mov r8, qword ptr [rbx + 0x68]
00045826  410fb74d40               movzx ecx, word ptr [r13 + 0x40]
0004582b  4863c2                   movsxd rax, edx
0004582e  450fb61480               movzx r10d, byte ptr [r8 + rax*4]
00045833  4d8d0c80                 lea r9, [r8 + rax*4]
00045837  410fb65103               movzx edx, byte ptr [r9 + 3]
0004583c  33c0                     xor eax, eax
0004583e  89442420                 mov dword ptr [rsp + 0x20], eax
00045842  4180fa01                 cmp r10b, 1
00045846  0f87c2000000             ja 0x4590e
0004584c  b8ffff0000               mov eax, 0xffff
00045851  85ed                     test ebp, ebp
00045853  0f849a000000             je 0x458f3
00045859  8bc5                     mov eax, ebp
0004585b  234314                   and eax, dword ptr [rbx + 0x14]
0004585e  440fb7c0                 movzx r8d, ax
00045862  89442434                 mov dword ptr [rsp + 0x34], eax
00045866  6641c1e808               shr r8w, 8
0004586b  4180f803                 cmp r8b, 3
0004586f  727d                     jb 0x458ee
00045871  7570                     jne 0x458e3
00045873  3c01                     cmp al, 1
00045875  7677                     jbe 0x458ee
00045877  0fb6c0                   movzx eax, al
0004587a  440fb7c1                 movzx r8d, cx
0004587e  0fb64c2437               movzx ecx, byte ptr [rsp + 0x37]
00045883  6641c1e008               shl r8w, 8
00045888  80e13f                   and cl, 0x3f
0004588b  66440bc0                 or r8w, ax
0004588f  0fb6c1                   movzx eax, cl
00045892  24c6                     and al, 0xc6
00045894  4489442428               mov dword ptr [rsp + 0x28], r8d
00045899  88442420                 mov byte ptr [rsp + 0x20], al
0004589d  0fb6c1                   movzx eax, cl
000458a0  24e4                     and al, 0xe4
000458a2  664489442434             mov word ptr [rsp + 0x34], r8w
000458a8  88442422                 mov byte ptr [rsp + 0x22], al
000458ac  4584d2                   test r10b, r10b
000458af  7512                     jne 0x458c3
000458b1  8b442434                 mov eax, dword ptr [rsp + 0x34]
000458b5  80e1c5                   and cl, 0xc5
000458b8  884c2423                 mov byte ptr [rsp + 0x23], cl
000458bc  c644242104               mov byte ptr [rsp + 0x21], 4
000458c1  eb35                     jmp 0x458f8
000458c3  b887ff0000               mov eax, 0xff87
000458c8  c644242105               mov byte ptr [rsp + 0x21], 5
000458cd  664423c0                 and r8w, ax
000458d1  8b442434                 mov eax, dword ptr [rsp + 0x34]
000458d5  80e205                   and dl, 5
000458d8  4489442428               mov dword ptr [rsp + 0x28], r8d
000458dd  88542423                 mov byte ptr [rsp + 0x23], dl
000458e1  eb15                     jmp 0x458f8
000458e3  440fb7c0                 movzx r8d, ax
000458e7  4489442428               mov dword ptr [rsp + 0x28], r8d
000458ec  eb0a                     jmp 0x458f8
000458ee  b8ffff0000               mov eax, 0xffff
000458f3  448b442428               mov r8d, dword ptr [rsp + 0x28]
000458f8  3dffff0000               cmp eax, 0xffff
000458fd  7548                     jne 0x45947
000458ff  33d2                     xor edx, edx
00045901  89442428                 mov dword ptr [rsp + 0x28], eax
00045905  89542420                 mov dword ptr [rsp + 0x20], edx
00045909  418901                   mov dword ptr [r9], eax
0004590c  eb44                     jmp 0x45952
0004590e  418b01                   mov eax, dword ptr [r9]
00045911  450fb7c2                 movzx r8d, r10w
00045915  89842498000000           mov dword ptr [rsp + 0x98], eax
0004591c  0fb6c2                   movzx eax, dl
0004591f  2406                     and al, 6
00045921  66c1e108                 shl cx, 8
00045925  88442420                 mov byte ptr [rsp + 0x20], al
00045929  66440bc1                 or r8w, cx
0004592d  0fb6c2                   movzx eax, dl
00045930  4489442428               mov dword ptr [rsp + 0x28], r8d
00045935  2424                     and al, 0x24
00045937  c644242103               mov byte ptr [rsp + 0x21], 3
0004593c  80e205                   and dl, 5
0004593f  88442422                 mov byte ptr [rsp + 0x22], al
00045943  88542423                 mov byte ptr [rsp + 0x23], dl
00045947  66458901                 mov word ptr [r9], r8w
0004594b  33d2                     xor edx, edx
0004594d  41c6410302               mov byte ptr [r9 + 3], 2
00045952  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
0004595a  448b9424a8000000         mov r10d, dword ptr [rsp + 0xa8]
00045962  4585c9                   test r9d, r9d
00045965  7439                     je 0x459a0
00045967  8b442420                 mov eax, dword ptr [rsp + 0x20]
0004596b  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
00045972  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
00045976  890491                   mov dword ptr [rcx + rdx*4], eax
00045979  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
00045981  e902fdffff               jmp 0x45688
00045986  498b4508                 mov rax, qword ptr [r13 + 8]
0004598a  410fb70e                 movzx ecx, word ptr [r14]
0004598e  8b0c88                   mov ecx, dword ptr [rax + rcx*4]
00045991  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
00045999  8908                     mov dword ptr [rax], ecx
0004599b  e9d8fcffff               jmp 0x45678
000459a0  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
000459a8  e9ddfcffff               jmp 0x4568a
000459ad  448b8c24b0000000         mov r9d, dword ptr [rsp + 0xb0]
000459b5  e9d0fcffff               jmp 0x4568a
000459ba  8b435c                   mov eax, dword ptr [rbx + 0x5c]
000459bd  ffc8                     dec eax
000459bf  89435c                   mov dword ptr [rbx + 0x5c], eax
000459c2  4585ff                   test r15d, r15d
000459c5  0f84ce000000             je 0x45a99
000459cb  0f1f440000               nop dword ptr [rax + rax]
000459d0  85c0                     test eax, eax
000459d2  7544                     jne 0x45a18
000459d4  48837b3000               cmp qword ptr [rbx + 0x30], 0
000459d9  0f84ba000000             je 0x45a99
000459df  488b4318                 mov rax, qword ptr [rbx + 0x18]
000459e3  4885c0                   test rax, rax
000459e6  740e                     je 0x459f6
000459e8  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
000459ec  ffd0                     call rax
000459ee  0fb7c8                   movzx ecx, ax
000459f1  8b435c                   mov eax, dword ptr [rbx + 0x5c]
000459f4  eb14                     jmp 0x45a0a
000459f6  48635338                 movsxd rdx, dword ptr [rbx + 0x38]
000459fa  488b4328                 mov rax, qword ptr [rbx + 0x28]
000459fe  0fb70c50                 movzx ecx, word ptr [rax + rdx*2]
00045a02  8d4201                   lea eax, [rdx + 1]
00045a05  894338                   mov dword ptr [rbx + 0x38], eax
00045a08  33c0                     xor eax, eax
00045a0a  4898                     cdqe
00045a0c  6641890c46               mov word ptr [r14 + rax*2], cx
00045a11  ff435c                   inc dword ptr [rbx + 0x5c]
00045a14  48ff4b30                 dec qword ptr [rbx + 0x30]
00045a18  48638b88000000           movsxd rcx, dword ptr [rbx + 0x88]
00045a1f  41baf7ff0000             mov r10d, 0xfff7
00045a25  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045a29  440fb70c88               movzx r9d, word ptr [rax + rcx*4]
00045a2e  4c8d0488                 lea r8, [rax + rcx*4]
00045a32  66453bca                 cmp r9w, r10w
00045a36  7525                     jne 0x45a5d
00045a38  6641833e25               cmp word ptr [r14], 0x25
00045a3d  751e                     jne 0x45a5d
00045a3f  41b81e000000             mov r8d, 0x1e
00045a45  488d533e                 lea rdx, [rbx + 0x3e]
00045a49  488d4b3c                 lea rcx, [rbx + 0x3c]
00045a4d  e86d880100               call 0x5e2bf
00045a52  ff4b5c                   dec dword ptr [rbx + 0x5c]
00045a55  8b435c                   mov eax, dword ptr [rbx + 0x5c]
00045a58  e973ffffff               jmp 0x459d0
00045a5d  498b4508                 mov rax, qword ptr [r13 + 8]
00045a61  410fb70e                 movzx ecx, word ptr [r14]
00045a65  8b1488                   mov edx, dword ptr [rax + rcx*4]
00045a68  0fb7c2                   movzx eax, dx
00045a6b  66c1e808                 shr ax, 8
00045a6f  3c01                     cmp al, 1
00045a71  7526                     jne 0x45a99
00045a73  66453bca                 cmp r9w, r10w
00045a77  73c6                     jae 0x45a3f
00045a79  410fb64002               movzx eax, byte ptr [r8 + 2]
00045a7e  c1ea10                   shr edx, 0x10
00045a81  0fb6ca                   movzx ecx, dl
00045a84  6603c8                   add cx, ax
00045a87  b8ff000000               mov eax, 0xff
00045a8c  663bc8                   cmp cx, ax
00045a8f  7602                     jbe 0x45a93
00045a91  8bc8                     mov ecx, eax
00045a93  41884802                 mov byte ptr [r8 + 2], cl
00045a97  eba6                     jmp 0x45a3f
00045a99  ff8388000000             inc dword ptr [rbx + 0x88]
00045a9f  85f6                     test esi, esi
00045aa1  7440                     je 0x45ae3
00045aa3  8bbc2490000000           mov edi, dword ptr [rsp + 0x90]
00045aaa  448b5c2424               mov r11d, dword ptr [rsp + 0x24]
00045aaf  e9d8f5ffff               jmp 0x4508c
00045ab4  b803000000               mov eax, 3
00045ab9  eb2a                     jmp 0x45ae5
00045abb  b802000000               mov eax, 2
00045ac0  eb23                     jmp 0x45ae5
00045ac2  48638388000000           movsxd rax, dword ptr [rbx + 0x88]
00045ac9  85f6                     test esi, esi
00045acb  7430                     je 0x45afd
00045acd  488bc8                   mov rcx, rax
00045ad0  bafbff0000               mov edx, 0xfffb
00045ad5  488b4368                 mov rax, qword ptr [rbx + 0x68]
00045ad9  66891488                 mov word ptr [rax + rcx*4], dx
00045add  ff8388000000             inc dword ptr [rbx + 0x88]
00045ae3  33c0                     xor eax, eax
00045ae5  488b9c2480000000         mov rbx, qword ptr [rsp + 0x80]
00045aed  4883c440                 add rsp, 0x40
00045af1  415f                     pop r15
00045af3  415e                     pop r14
00045af5  415d                     pop r13
00045af7  415c                     pop r12
00045af9  5f                       pop rdi
00045afa  5e                       pop rsi
00045afb  5d                       pop rbp
00045afc  c3                       ret
00045afd  398384000000             cmp dword ptr [rbx + 0x84], eax
00045b03  75de                     jne 0x45ae3
00045b05  f7431000000008           test dword ptr [rbx + 0x10], 0x8000000
00045b0c  742c                     je 0x45b3a
00045b0e  498b4d08                 mov rcx, qword ptr [r13 + 8]
00045b12  448b8180000000           mov r8d, dword ptr [rcx + 0x80]
00045b19  44234314                 and r8d, dword ptr [rbx + 0x14]
00045b1d  488b4b68                 mov rcx, qword ptr [rbx + 0x68]
00045b21  44890481                 mov dword ptr [rcx + rax*4], r8d
00045b25  4585c9                   test r9d, r9d
00045b28  7410                     je 0x45b3a
00045b2a  48639388000000           movsxd rdx, dword ptr [rbx + 0x88]
00045b31  33c0                     xor eax, eax
00045b33  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
00045b37  890491                   mov dword ptr [rcx + rdx*4], eax
00045b3a  418bc7                   mov eax, r15d
00045b3d  eba6                     jmp 0x45ae5
00045b3f  90                       nop
