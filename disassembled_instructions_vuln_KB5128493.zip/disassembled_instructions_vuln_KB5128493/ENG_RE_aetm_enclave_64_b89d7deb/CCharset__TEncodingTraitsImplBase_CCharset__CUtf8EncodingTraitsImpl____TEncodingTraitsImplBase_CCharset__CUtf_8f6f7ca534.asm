; CCharset::TEncodingTraitsImplBase<CCharset::CUtf8EncodingTraitsImpl>::~TEncodingTraitsImplBase<CCharset::CUtf8EncodingTraitsImpl>
; aetm_enclave.dll, primary RVA 0x34d90, 32 bytes in 1 chunk(s)

; chunk at RVA 0x34d90 (32 bytes)
00034d90  48894c2408               mov qword ptr [rsp + 8], rcx
00034d95  4883ec18                 sub rsp, 0x18
00034d99  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00034da1  488d05b8000300           lea rax, [rip + 0x300b8]
00034da8  488901                   mov qword ptr [rcx], rax
00034dab  4883c418                 add rsp, 0x18
00034daf  c3                       ret
