; CSqlSortManager_80::GetSortKey
; aetm_enclave.dll, primary RVA 0x47a30, 5424 bytes in 8 chunk(s)

; chunk at RVA 0x47a30 (140 bytes)
00047a30  4c894c2420               mov qword ptr [rsp + 0x20], r9
00047a35  4889542410               mov qword ptr [rsp + 0x10], rdx
00047a3a  55                       push rbp
00047a3b  53                       push rbx
00047a3c  56                       push rsi
00047a3d  4154                     push r12
00047a3f  4155                     push r13
00047a41  4157                     push r15
00047a43  488d6c24f9               lea rbp, [rsp - 7]
00047a48  4881ec98000000           sub rsp, 0x98
00047a4f  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00047a53  33c0                     xor eax, eax
00047a55  448bf8                   mov r15d, eax
00047a58  488945bf                 mov qword ptr [rbp - 0x41], rax
00047a5c  448be8                   mov r13d, eax
00047a5f  488945b7                 mov qword ptr [rbp - 0x49], rax
00047a63  448bd0                   mov r10d, eax
00047a66  488945af                 mov qword ptr [rbp - 0x51], rax
00047a6a  488945cf                 mov qword ptr [rbp - 0x31], rax
00047a6e  8bd8                     mov ebx, eax
00047a70  488945df                 mov qword ptr [rbp - 0x21], rax
00047a74  498bf1                   mov rsi, r9
00047a77  89458f                   mov dword ptr [rbp - 0x71], eax
00047a7a  458be0                   mov r12d, r8d
00047a7d  b801000000               mov eax, 1
00047a82  66894593                 mov word ptr [rbp - 0x6d], ax
00047a86  418bc3                   mov eax, r11d
00047a89  f7d8                     neg eax
00047a8b  1bd2                     sbb edx, edx
00047a8d  81e2a5b0b912             and edx, 0x12b9b0a5
00047a93  41f7c000030000           test r8d, 0x300
00047a9a  0f8581140000             jne 0x48f21
00047aa0  418bc0                   mov eax, r8d
00047aa3  25f8effc3e               and eax, 0x3efceff8
00047aa8  3d00040000               cmp eax, 0x400
00047aad  0f856e140000             jne 0x48f21
00047ab3  4d85c9                   test r9, r9
00047ab6  0f8465140000             je 0x48f21

; chunk at RVA 0x47abc (8 bytes)
00047abc  4889bc24d0000000         mov qword ptr [rsp + 0xd0], rdi

; chunk at RVA 0x47ac4 (4926 bytes)
00047ac4  4c89b42490000000         mov qword ptr [rsp + 0x90], r14
00047acc  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00047ad0  4585f6                   test r14d, r14d
00047ad3  7547                     jne 0x47b1c
00047ad5  488b85a7000000           mov rax, qword ptr [rbp + 0xa7]
00047adc  4c8bbd8f000000           mov r15, qword ptr [rbp + 0x8f]
00047ae3  4c8bad97000000           mov r13, qword ptr [rbp + 0x97]
00047aea  4c8b959f000000           mov r10, qword ptr [rbp + 0x9f]
00047af1  488b00                   mov rax, qword ptr [rax]
00047af4  488b8daf000000           mov rcx, qword ptr [rbp + 0xaf]
00047afb  4d8b3f                   mov r15, qword ptr [r15]
00047afe  4d8b6d00                 mov r13, qword ptr [r13]
00047b02  4d8b12                   mov r10, qword ptr [r10]
00047b05  488945cf                 mov qword ptr [rbp - 0x31], rax
00047b09  488b01                   mov rax, qword ptr [rcx]
00047b0c  488945df                 mov qword ptr [rbp - 0x21], rax
00047b10  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00047b14  4c896db7                 mov qword ptr [rbp - 0x49], r13
00047b18  4c8955af                 mov qword ptr [rbp - 0x51], r10
00047b1c  8b7d5f                   mov edi, dword ptr [rbp + 0x5f]
00047b1f  85ff                     test edi, edi
00047b21  790e                     jns 0x47b31
00047b23  488bce                   mov rcx, rsi
00047b26  e825feffff               call 0x47950
00047b2b  8d7801                   lea edi, [rax + 1]
00047b2e  897d5f                   mov dword ptr [rbp + 0x5f], edi
00047b31  41f6c401                 test r12b, 1
00047b35  4889759f                 mov qword ptr [rbp - 0x61], rsi
00047b39  b8ff000000               mov eax, 0xff
00047b3e  c7459701000000           mov dword ptr [rbp - 0x69], 1
00047b45  b9e7000000               mov ecx, 0xe7
00047b4a  0f44c8                   cmove ecx, eax
00047b4d  440fb6c9                 movzx r9d, cl
00047b51  410fb6c9                 movzx ecx, r9b
00047b55  80e1df                   and cl, 0xdf
00047b58  4181e000000100           and r8d, 0x10000
00047b5f  0fb6c1                   movzx eax, cl
00047b62  418bcc                   mov ecx, r12d
00047b65  410f44c1                 cmove eax, r9d
00047b69  448bca                   mov r9d, edx
00047b6c  440fb6c0                 movzx r8d, al
00047b70  410fb6c0                 movzx eax, r8b
00047b74  24fe                     and al, 0xfe
00047b76  0fb6c0                   movzx eax, al
00047b79  81e100000200             and ecx, 0x20000
00047b7f  410f44c0                 cmove eax, r8d
00047b83  8945a7                   mov dword ptr [rbp - 0x59], eax
00047b86  418bc4                   mov eax, r12d
00047b89  2500100000               and eax, 0x1000
00047b8e  4183e404                 and r12d, 4
00047b92  8945e7                   mov dword ptr [rbp - 0x19], eax
00047b95  b807020000               mov eax, 0x207
00047b9a  4489654f                 mov dword ptr [rbp + 0x4f], r12d
00047b9e  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00047ba3  83ff01                   cmp edi, 1
00047ba6  0f8c41120000             jl 0x48ded
00047bac  8d047f                   lea eax, [rdi + rdi*2]
00047baf  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047bb3  4898                     cdqe
00047bb5  488945d7                 mov qword ptr [rbp - 0x29], rax
00047bb9  0f1f8000000000           nop dword ptr [rax]
00047bc0  0fb706                   movzx eax, word ptr [rsi]
00047bc3  488b4d47                 mov rcx, qword ptr [rbp + 0x47]
00047bc7  488945ef                 mov qword ptr [rbp - 0x11], rax
00047bcb  4c8b7108                 mov r14, qword ptr [rcx + 8]
00047bcf  458b1c86                 mov r11d, dword ptr [r14 + rax*4]
00047bd3  458bd3                   mov r10d, r11d
00047bd6  44895dc7                 mov dword ptr [rbp - 0x39], r11d
00047bda  418bf3                   mov esi, r11d
00047bdd  41c1ea18                 shr r10d, 0x18
00047be1  450fb7c3                 movzx r8d, r11w
00047be5  c1ee10                   shr esi, 0x10
00047be8  6641c1e808               shr r8w, 8
00047bed  4180f80b                 cmp r8b, 0xb
00047bf1  0f86c6090000             jbe 0x485bd
00047bf7  488bc1                   mov rax, rcx
00047bfa  83781400                 cmp dword ptr [rax + 0x14], 0
00047bfe  0f8562010000             jne 0x47d66
00047c04  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00047c08  410fb7cb                 movzx ecx, r11w
00047c0c  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00047c10  4c63c3                   movsxd r8, ebx
00047c13  66c1e908                 shr cx, 8
00047c17  4585f6                   test r14d, r14d
00047c1a  0f84c7000000             je 0x47ce7
00047c20  42884c058f               mov byte ptr [rbp + r8 - 0x71], cl
00047c25  83c302                   add ebx, 2
00047c28  46885c0590               mov byte ptr [rbp + r8 - 0x70], r11b
00047c2d  4983c002                 add r8, 2
00047c31  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00047c36  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047c3a  4983f804                 cmp r8, 4
00047c3e  0f859d000000             jne 0x47ce1
00047c44  33c0                     xor eax, eax
00047c46  8bd8                     mov ebx, eax
00047c48  448bc0                   mov r8d, eax
00047c4b  39456f                   cmp dword ptr [rbp + 0x6f], eax
00047c4e  753f                     jne 0x47c8f
00047c50  41c1c103                 rol r9d, 3
00047c54  b907020000               mov ecx, 0x207
00047c59  418bc1                   mov eax, r9d
00047c5c  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00047c60  66394d91                 cmp word ptr [rbp - 0x6f], cx
00047c64  740c                     je 0x47c72
00047c66  66ff4593                 inc word ptr [rbp - 0x6d]
00047c6a  418bd1                   mov edx, r9d
00047c6d  e9a9000000               jmp 0x47d1b
00047c72  663bf9                   cmp di, cx
00047c75  746a                     je 0x47ce1
00047c77  418bd4                   mov edx, r12d
00047c7a  33d0                     xor edx, eax
00047c7c  8bc7                     mov eax, edi
00047c7e  c1e808                   shr eax, 8
00047c81  c1c203                   rol edx, 3
00047c84  33d0                     xor edx, eax
00047c86  66ff4593                 inc word ptr [rbp - 0x6d]
00047c8a  e98c000000               jmp 0x47d1b
00047c8f  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00047c92  418bc1                   mov eax, r9d
00047c95  4569d120080000           imul r10d, r9d, 0x820
00047c9c  458bd9                   mov r11d, r9d
00047c9f  c1e802                   shr eax, 2
00047ca2  4403d0                   add r10d, eax
00047ca5  4103ca                   add ecx, r10d
00047ca8  4433c9                   xor r9d, ecx
00047cab  b907020000               mov ecx, 0x207
00047cb0  66394d91                 cmp word ptr [rbp - 0x6f], cx
00047cb4  7409                     je 0x47cbf
00047cb6  66ff4593                 inc word ptr [rbp - 0x6d]
00047cba  418bd1                   mov edx, r9d
00047cbd  eb5c                     jmp 0x47d1b
00047cbf  663bf9                   cmp di, cx
00047cc2  741d                     je 0x47ce1
00047cc4  438d1422                 lea edx, [r10 + r12]
00047cc8  8bcf                     mov ecx, edi
00047cca  4133d3                   xor edx, r11d
00047ccd  c1e908                   shr ecx, 8
00047cd0  69c220080000             imul eax, edx, 0x820
00047cd6  03c8                     add ecx, eax
00047cd8  8bc2                     mov eax, edx
00047cda  c1e802                   shr eax, 2
00047cdd  03c8                     add ecx, eax
00047cdf  33d1                     xor edx, ecx
00047ce1  66ff4593                 inc word ptr [rbp - 0x6d]
00047ce5  eb34                     jmp 0x47d1b
00047ce7  0fb645a7                 movzx eax, byte ptr [rbp - 0x59]
00047ceb  41880f                   mov byte ptr [r15], cl
00047cee  4122c2                   and al, r10b
00047cf1  488b4daf                 mov rcx, qword ptr [rbp - 0x51]
00047cf5  243f                     and al, 0x3f
00047cf7  45885f01                 mov byte ptr [r15 + 1], r11b
00047cfb  4983c702                 add r15, 2
00047cff  41c1eb10                 shr r11d, 0x10
00047d03  45885d00                 mov byte ptr [r13], r11b
00047d07  49ffc5                   inc r13
00047d0a  8801                     mov byte ptr [rcx], al
00047d0c  48ffc1                   inc rcx
00047d0f  48894daf                 mov qword ptr [rbp - 0x51], rcx
00047d13  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00047d17  4c896db7                 mov qword ptr [rbp - 0x49], r13
00047d1b  448b5597                 mov r10d, dword ptr [rbp - 0x69]
00047d1f  4883c602                 add rsi, 2
00047d23  41ffc2                   inc r10d
00047d26  4889759f                 mov qword ptr [rbp - 0x61], rsi
00047d2a  44895597                 mov dword ptr [rbp - 0x69], r10d
00047d2e  443b555f                 cmp r10d, dword ptr [rbp + 0x5f]
00047d32  0f8fa6100000             jg 0x48dde
00047d38  0fb70e                   movzx ecx, word ptr [rsi]
00047d3b  488b4547                 mov rax, qword ptr [rbp + 0x47]
00047d3f  488b4008                 mov rax, qword ptr [rax + 8]
00047d43  448b1c88                 mov r11d, dword ptr [rax + rcx*4]
00047d47  458bd3                   mov r10d, r11d
00047d4a  410fb7c3                 movzx eax, r11w
00047d4e  41c1ea18                 shr r10d, 0x18
00047d52  66c1e808                 shr ax, 8
00047d56  418bcb                   mov ecx, r11d
00047d59  3c0b                     cmp al, 0xb
00047d5b  0f87b2feffff             ja 0x47c13
00047d61  e96c100000               jmp 0x48dd2
00047d66  4533c0                   xor r8d, r8d
00047d69  458be8                   mov r13d, r8d
00047d6c  41f6c2c0                 test r10b, 0xc0
00047d70  0f84ca000000             je 0x47e40
00047d76  8b4d5f                   mov ecx, dword ptr [rbp + 0x5f]
00047d79  410fb7f0                 movzx esi, r8w
00047d7d  448b5597                 mov r10d, dword ptr [rbp - 0x69]
00047d81  450fb7f8                 movzx r15d, r8w
00047d85  66448945c7               mov word ptr [rbp - 0x39], r8w
00047d8a  4c8b459f                 mov r8, qword ptr [rbp - 0x61]
00047d8e  412bca                   sub ecx, r10d
00047d91  741d                     je 0x47db0
00047d93  83e901                   sub ecx, 1
00047d96  7413                     je 0x47dab
00047d98  83f901                   cmp ecx, 1
00047d9b  7405                     je 0x47da2
00047d9d  410fb77006               movzx esi, word ptr [r8 + 6]
00047da2  410fb74004               movzx eax, word ptr [r8 + 4]
00047da7  668945c7                 mov word ptr [rbp - 0x39], ax
00047dab  450fb77802               movzx r15d, word ptr [r8 + 2]
00047db0  488b4547                 mov rax, qword ptr [rbp + 0x47]
00047db4  44396818                 cmp dword ptr [rax + 0x18], r13d
00047db8  743f                     je 0x47df9
00047dba  443b555f                 cmp r10d, dword ptr [rbp + 0x5f]
00047dbe  7d39                     jge 0x47df9
00047dc0  410fb74002               movzx eax, word ptr [r8 + 2]
00047dc5  418bcb                   mov ecx, r11d
00047dc8  41330c86                 xor ecx, dword ptr [r14 + rax*4]
00047dcc  f7c1ffffffe7             test ecx, 0xe7ffffff
00047dd2  7525                     jne 0x47df9
00047dd4  488b4547                 mov rax, qword ptr [rbp + 0x47]
00047dd8  4c8b5020                 mov r10, qword ptr [rax + 0x20]
00047ddc  410fb74204               movzx eax, word ptr [r10 + 4]
00047de1  85c0                     test eax, eax
00047de3  7414                     je 0x47df9
00047de5  6645397a06               cmp word ptr [r10 + 6], r15w
00047dea  0f86c5000000             jbe 0x47eb5
00047df0  4983c210                 add r10, 0x10
00047df4  83e801                   sub eax, 1
00047df7  75ec                     jne 0x47de5
00047df9  440fb775c7               movzx r14d, word ptr [rbp - 0x39]
00047dfe  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00047e02  4c8b4547                 mov r8, qword ptr [rbp + 0x47]
00047e06  4d8b5020                 mov r10, qword ptr [r8 + 0x20]
00047e0a  410fb74204               movzx eax, word ptr [r10 + 4]
00047e0f  85c0                     test eax, eax
00047e11  7421                     je 0x47e34
00047e13  488b4def                 mov rcx, qword ptr [rbp - 0x11]
00047e17  660f1f840000000000       nop word ptr [rax + rax]
00047e20  6641394a06               cmp word ptr [r10 + 6], cx
00047e25  0f8684040000             jbe 0x482af
00047e2b  4983c210                 add r10, 0x10
00047e2f  83e801                   sub eax, 1
00047e32  75ec                     jne 0x47e20
00047e34  4585ed                   test r13d, r13d
00047e37  0f85890f0000             jne 0x48dc6
00047e3d  4533c0                   xor r8d, r8d
00047e40  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00047e44  4585f6                   test r14d, r14d
00047e47  0f840d070000             je 0x4855a
00047e4d  4863c3                   movsxd rax, ebx
00047e50  410fb7cb                 movzx ecx, r11w
00047e54  ffc3                     inc ebx
00047e56  66c1e908                 shr cx, 8
00047e5a  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
00047e5e  4863c3                   movsxd rax, ebx
00047e61  ffc3                     inc ebx
00047e63  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
00047e68  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00047e6d  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047e71  83fb04                   cmp ebx, 4
00047e74  0f85d2060000             jne 0x4854c
00047e7a  837d6f00                 cmp dword ptr [rbp + 0x6f], 0
00047e7e  418bd8                   mov ebx, r8d
00047e81  0f856b060000             jne 0x484f2
00047e87  41c1c103                 rol r9d, 3
00047e8b  b907020000               mov ecx, 0x207
00047e90  418bc1                   mov eax, r9d
00047e93  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00047e97  66394d91                 cmp word ptr [rbp - 0x6f], cx
00047e9b  0f842c060000             je 0x484cd
00047ea1  66ff4593                 inc word ptr [rbp - 0x6d]
00047ea5  418bd1                   mov edx, r9d
00047ea8  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
00047eac  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00047eb0  e9ef060000               jmp 0x485a4
00047eb5  85c0                     test eax, eax
00047eb7  0f843cffffff             je 0x47df9
00047ebd  440fb775c7               movzx r14d, word ptr [rbp - 0x39]
00047ec2  6645397a06               cmp word ptr [r10 + 6], r15w
00047ec7  0f8531ffffff             jne 0x47dfe
00047ecd  66453b720c               cmp r14w, word ptr [r10 + 0xc]
00047ed2  0f8226ffffff             jb 0x47dfe
00047ed8  66453b720e               cmp r14w, word ptr [r10 + 0xe]
00047edd  0f871bffffff             ja 0x47dfe
00047ee3  488b4547                 mov rax, qword ptr [rbp + 0x47]
00047ee7  410fb74a08               movzx ecx, word ptr [r10 + 8]
00047eec  488b4028                 mov rax, qword ptr [rax + 0x28]
00047ef0  4c8d04c8                 lea r8, [rax + rcx*8]
00047ef4  410fb7420a               movzx eax, word ptr [r10 + 0xa]
00047ef9  85c0                     test eax, eax
00047efb  0f84fdfeffff             je 0x47dfe
00047f01  66453930                 cmp word ptr [r8], r14w
00047f05  760e                     jbe 0x47f15
00047f07  4983c008                 add r8, 8
00047f0b  83e801                   sub eax, 1
00047f0e  75f1                     jne 0x47f01
00047f10  e9e9feffff               jmp 0x47dfe
00047f15  85c0                     test eax, eax
00047f17  0f84e1feffff             je 0x47dfe
00047f1d  0f1f00                   nop dword ptr [rax]
00047f20  66453930                 cmp word ptr [r8], r14w
00047f24  0f85d4feffff             jne 0x47dfe
00047f2a  410fb74802               movzx ecx, word ptr [r8 + 2]
00047f2f  6685c9                   test cx, cx
00047f32  0f84c2020000             je 0x481fa
00047f38  663bce                   cmp cx, si
00047f3b  740e                     je 0x47f4b
00047f3d  4983c008                 add r8, 8
00047f41  83e801                   sub eax, 1
00047f44  75da                     jne 0x47f20
00047f46  e9b3feffff               jmp 0x47dfe
00047f4b  458b5804                 mov r11d, dword ptr [r8 + 4]
00047f4f  418bcb                   mov ecx, r11d
00047f52  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00047f56  450fb7c3                 movzx r8d, r11w
00047f5a  83459704                 add dword ptr [rbp - 0x69], 4
00047f5e  4883c608                 add rsi, 8
00047f62  c1e918                   shr ecx, 0x18
00047f65  6641c1e808               shr r8w, 8
00047f6a  4889759f                 mov qword ptr [rbp - 0x61], rsi
00047f6e  44396d67                 cmp dword ptr [rbp + 0x67], r13d
00047f72  0f842c020000             je 0x481a4
00047f78  448b6d6f                 mov r13d, dword ptr [rbp + 0x6f]
00047f7c  450fb6e0                 movzx r12d, r8b
00047f80  4863c3                   movsxd rax, ebx
00047f83  ffc3                     inc ebx
00047f85  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00047f8a  4863c3                   movsxd rax, ebx
00047f8d  ffc3                     inc ebx
00047f8f  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
00047f94  83fb04                   cmp ebx, 4
00047f97  0f8504010000             jne 0x480a1
00047f9d  33db                     xor ebx, ebx
00047f9f  4585ed                   test r13d, r13d
00047fa2  756f                     jne 0x48013
00047fa4  41c1c103                 rol r9d, 3
00047fa8  41bd07020000             mov r13d, 0x207
00047fae  418bc9                   mov ecx, r9d
00047fb1  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00047fb5  6644396d91               cmp word ptr [rbp - 0x6f], r13w
00047fba  7421                     je 0x47fdd
00047fbc  bb02000000               mov ebx, 2
00047fc1  4488458f                 mov byte ptr [rbp - 0x71], r8b
00047fc5  66015d93                 add word ptr [rbp - 0x6d], bx
00047fc9  418bd1                   mov edx, r9d
00047fcc  44885d90                 mov byte ptr [rbp - 0x70], r11b
00047fd0  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00047fd4  448d6bff                 lea r13d, [rbx - 1]
00047fd8  e925feffff               jmp 0x47e02
00047fdd  0fb7458f                 movzx eax, word ptr [rbp - 0x71]
00047fe1  66413bc5                 cmp ax, r13w
00047fe5  740e                     je 0x47ff5
00047fe7  0fb6558f                 movzx edx, byte ptr [rbp - 0x71]
00047feb  33d1                     xor edx, ecx
00047fed  c1e808                   shr eax, 8
00047ff0  c1c203                   rol edx, 3
00047ff3  33d0                     xor edx, eax
00047ff5  bb02000000               mov ebx, 2
00047ffa  4488458f                 mov byte ptr [rbp - 0x71], r8b
00047ffe  66015d93                 add word ptr [rbp - 0x6d], bx
00048002  44885d90                 mov byte ptr [rbp - 0x70], r11b
00048006  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
0004800a  448d6bff                 lea r13d, [rbx - 1]
0004800e  e9effdffff               jmp 0x47e02
00048013  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00048016  418bc1                   mov eax, r9d
00048019  4569d120080000           imul r10d, r9d, 0x820
00048020  418bf9                   mov edi, r9d
00048023  c1e802                   shr eax, 2
00048026  4403d0                   add r10d, eax
00048029  4103ca                   add ecx, r10d
0004802c  4433c9                   xor r9d, ecx
0004802f  b907020000               mov ecx, 0x207
00048034  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048038  7421                     je 0x4805b
0004803a  418bd1                   mov edx, r9d
0004803d  bb02000000               mov ebx, 2
00048042  4488458f                 mov byte ptr [rbp - 0x71], r8b
00048046  66015d93                 add word ptr [rbp - 0x6d], bx
0004804a  44885d90                 mov byte ptr [rbp - 0x70], r11b
0004804e  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048052  448d6bff                 lea r13d, [rbx - 1]
00048056  e9a7fdffff               jmp 0x47e02
0004805b  0fb7458f                 movzx eax, word ptr [rbp - 0x71]
0004805f  663bc1                   cmp ax, cx
00048062  7442                     je 0x480a6
00048064  0fb6558f                 movzx edx, byte ptr [rbp - 0x71]
00048068  8bc8                     mov ecx, eax
0004806a  4103d2                   add edx, r10d
0004806d  c1e908                   shr ecx, 8
00048070  33d7                     xor edx, edi
00048072  4488458f                 mov byte ptr [rbp - 0x71], r8b
00048076  69c220080000             imul eax, edx, 0x820
0004807c  bb02000000               mov ebx, 2
00048081  44885d90                 mov byte ptr [rbp - 0x70], r11b
00048085  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048089  448d6bff                 lea r13d, [rbx - 1]
0004808d  03c8                     add ecx, eax
0004808f  8bc2                     mov eax, edx
00048091  c1e802                   shr eax, 2
00048094  03c8                     add ecx, eax
00048096  33d1                     xor edx, ecx
00048098  66015d93                 add word ptr [rbp - 0x6d], bx
0004809c  e961fdffff               jmp 0x47e02
000480a1  b907020000               mov ecx, 0x207
000480a6  4863c3                   movsxd rax, ebx
000480a9  ffc3                     inc ebx
000480ab  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
000480b0  4863c3                   movsxd rax, ebx
000480b3  ffc3                     inc ebx
000480b5  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
000480ba  83fb04                   cmp ebx, 4
000480bd  0f85c8000000             jne 0x4818b
000480c3  33db                     xor ebx, ebx
000480c5  4585ed                   test r13d, r13d
000480c8  7544                     jne 0x4810e
000480ca  41c1c103                 rol r9d, 3
000480ce  418bc1                   mov eax, r9d
000480d1  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
000480d5  66394d91                 cmp word ptr [rbp - 0x6f], cx
000480d9  0f85a9000000             jne 0x48188
000480df  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
000480e3  663bf9                   cmp di, cx
000480e6  0f8487000000             je 0x48173
000480ec  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
000480f1  448d6b01                 lea r13d, [rbx + 1]
000480f5  418bd4                   mov edx, r12d
000480f8  33d0                     xor edx, eax
000480fa  8bc7                     mov eax, edi
000480fc  c1e808                   shr eax, 8
000480ff  c1c203                   rol edx, 3
00048102  33d0                     xor edx, eax
00048104  6683459302               add word ptr [rbp - 0x6d], 2
00048109  e9f4fcffff               jmp 0x47e02
0004810e  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00048111  418bc1                   mov eax, r9d
00048114  4569c120080000           imul r8d, r9d, 0x820
0004811b  458bd1                   mov r10d, r9d
0004811e  c1e802                   shr eax, 2
00048121  41bd07020000             mov r13d, 0x207
00048127  4403c0                   add r8d, eax
0004812a  4103c8                   add ecx, r8d
0004812d  4433c9                   xor r9d, ecx
00048130  6644396d91               cmp word ptr [rbp - 0x6f], r13w
00048135  7551                     jne 0x48188
00048137  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
0004813b  66413bfd                 cmp di, r13w
0004813f  7432                     je 0x48173
00048141  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048146  8bcf                     mov ecx, edi
00048148  c1e908                   shr ecx, 8
0004814b  41bd01000000             mov r13d, 1
00048151  438d1420                 lea edx, [r8 + r12]
00048155  4133d2                   xor edx, r10d
00048158  69c220080000             imul eax, edx, 0x820
0004815e  03c8                     add ecx, eax
00048160  8bc2                     mov eax, edx
00048162  c1e802                   shr eax, 2
00048165  03c8                     add ecx, eax
00048167  33d1                     xor edx, ecx
00048169  6683459302               add word ptr [rbp - 0x6d], 2
0004816e  e98ffcffff               jmp 0x47e02
00048173  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048178  41bd01000000             mov r13d, 1
0004817e  6683459302               add word ptr [rbp - 0x6d], 2
00048183  e97afcffff               jmp 0x47e02
00048188  418bd1                   mov edx, r9d
0004818b  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048190  41bd01000000             mov r13d, 1
00048196  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
0004819a  6683459302               add word ptr [rbp - 0x6d], 2
0004819f  e95efcffff               jmp 0x47e02
000481a4  488b45bf                 mov rax, qword ptr [rbp - 0x41]
000481a8  41bd01000000             mov r13d, 1
000481ae  224da7                   and cl, byte ptr [rbp - 0x59]
000481b1  80e13f                   and cl, 0x3f
000481b4  448800                   mov byte ptr [rax], r8b
000481b7  44885801                 mov byte ptr [rax + 1], r11b
000481bb  44884002                 mov byte ptr [rax + 2], r8b
000481bf  4c8b45b7                 mov r8, qword ptr [rbp - 0x49]
000481c3  44885803                 mov byte ptr [rax + 3], r11b
000481c7  4883c004                 add rax, 4
000481cb  488945bf                 mov qword ptr [rbp - 0x41], rax
000481cf  418bc3                   mov eax, r11d
000481d2  c1e810                   shr eax, 0x10
000481d5  418800                   mov byte ptr [r8], al
000481d8  41884001                 mov byte ptr [r8 + 1], al
000481dc  4983c002                 add r8, 2
000481e0  488b45af                 mov rax, qword ptr [rbp - 0x51]
000481e4  4c8945b7                 mov qword ptr [rbp - 0x49], r8
000481e8  8808                     mov byte ptr [rax], cl
000481ea  884801                   mov byte ptr [rax + 1], cl
000481ed  4883c002                 add rax, 2
000481f1  488945af                 mov qword ptr [rbp - 0x51], rax
000481f5  e908fcffff               jmp 0x47e02
000481fa  458b5804                 mov r11d, dword ptr [r8 + 4]
000481fe  418bcb                   mov ecx, r11d
00048201  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00048205  450fb7c3                 movzx r8d, r11w
00048209  83459703                 add dword ptr [rbp - 0x69], 3
0004820d  4883c606                 add rsi, 6
00048211  c1e918                   shr ecx, 0x18
00048214  6641c1e808               shr r8w, 8
00048219  4889759f                 mov qword ptr [rbp - 0x61], rsi
0004821d  44396d67                 cmp dword ptr [rbp + 0x67], r13d
00048221  7481                     je 0x481a4
00048223  448b6d6f                 mov r13d, dword ptr [rbp + 0x6f]
00048227  450fb6e0                 movzx r12d, r8b
0004822b  4863c3                   movsxd rax, ebx
0004822e  ffc3                     inc ebx
00048230  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048235  4863c3                   movsxd rax, ebx
00048238  ffc3                     inc ebx
0004823a  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
0004823f  83fb04                   cmp ebx, 4
00048242  0f8559feffff             jne 0x480a1
00048248  33db                     xor ebx, ebx
0004824a  4585ed                   test r13d, r13d
0004824d  0f8451fdffff             je 0x47fa4
00048253  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00048256  418bc1                   mov eax, r9d
00048259  4569d120080000           imul r10d, r9d, 0x820
00048260  418bf9                   mov edi, r9d
00048263  c1e802                   shr eax, 2
00048266  4403d0                   add r10d, eax
00048269  4103ca                   add ecx, r10d
0004826c  4433c9                   xor r9d, ecx
0004826f  b907020000               mov ecx, 0x207
00048274  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048278  0f85bcfdffff             jne 0x4803a
0004827e  0fb7458f                 movzx eax, word ptr [rbp - 0x71]
00048282  663bc1                   cmp ax, cx
00048285  0f841bfeffff             je 0x480a6
0004828b  0fb6558f                 movzx edx, byte ptr [rbp - 0x71]
0004828f  8bc8                     mov ecx, eax
00048291  c1e908                   shr ecx, 8
00048294  4103d2                   add edx, r10d
00048297  33d7                     xor edx, edi
00048299  69c220080000             imul eax, edx, 0x820
0004829f  03c8                     add ecx, eax
000482a1  8bc2                     mov eax, edx
000482a3  c1e802                   shr eax, 2
000482a6  03c8                     add ecx, eax
000482a8  33d1                     xor edx, ecx
000482aa  e98efdffff               jmp 0x4803d
000482af  0f857ffbffff             jne 0x47e34
000482b5  66453b7a0c               cmp r15w, word ptr [r10 + 0xc]
000482ba  0f8274fbffff             jb 0x47e34
000482c0  66453b7a0e               cmp r15w, word ptr [r10 + 0xe]
000482c5  0f8769fbffff             ja 0x47e34
000482cb  488b4547                 mov rax, qword ptr [rbp + 0x47]
000482cf  410fb74a08               movzx ecx, word ptr [r10 + 8]
000482d4  488b4028                 mov rax, qword ptr [rax + 0x28]
000482d8  4c8d04c8                 lea r8, [rax + rcx*8]
000482dc  410fb7420a               movzx eax, word ptr [r10 + 0xa]
000482e1  85c0                     test eax, eax
000482e3  0f844bfbffff             je 0x47e34
000482e9  0f1f8000000000           nop dword ptr [rax]
000482f0  66453938                 cmp word ptr [r8], r15w
000482f4  7612                     jbe 0x48308
000482f6  4983c008                 add r8, 8
000482fa  83e801                   sub eax, 1
000482fd  75f1                     jne 0x482f0
000482ff  e930fbffff               jmp 0x47e34
00048304  66453938                 cmp word ptr [r8], r15w
00048308  0f8526fbffff             jne 0x47e34
0004830e  410fb74802               movzx ecx, word ptr [r8 + 2]
00048313  6685c9                   test cx, cx
00048316  0f844a010000             je 0x48466
0004831c  66413bce                 cmp cx, r14w
00048320  740e                     je 0x48330
00048322  4983c008                 add r8, 8
00048326  83e801                   sub eax, 1
00048329  75d9                     jne 0x48304
0004832b  e904fbffff               jmp 0x47e34
00048330  418b4804                 mov ecx, dword ptr [r8 + 4]
00048334  4883c606                 add rsi, 6
00048338  83459703                 add dword ptr [rbp - 0x69], 3
0004833c  448bd1                   mov r10d, ecx
0004833f  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048343  440fb7c1                 movzx r8d, cx
00048347  41c1ea18                 shr r10d, 0x18
0004834b  6641c1e808               shr r8w, 8
00048350  4889759f                 mov qword ptr [rbp - 0x61], rsi
00048354  4585f6                   test r14d, r14d
00048357  0f84c9000000             je 0x48426
0004835d  4863c3                   movsxd rax, ebx
00048360  ffc3                     inc ebx
00048362  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048367  4863c3                   movsxd rax, ebx
0004836a  ffc3                     inc ebx
0004836c  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
00048370  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048375  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048379  83fb04                   cmp ebx, 4
0004837c  0f859b000000             jne 0x4841d
00048382  33db                     xor ebx, ebx
00048384  395d6f                   cmp dword ptr [rbp + 0x6f], ebx
00048387  753f                     jne 0x483c8
00048389  41c1c103                 rol r9d, 3
0004838d  b907020000               mov ecx, 0x207
00048392  418bc1                   mov eax, r9d
00048395  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00048399  66394d91                 cmp word ptr [rbp - 0x6f], cx
0004839d  740c                     je 0x483ab
0004839f  66ff4593                 inc word ptr [rbp - 0x6d]
000483a3  418bd1                   mov edx, r9d
000483a6  e91f0a0000               jmp 0x48dca
000483ab  663bf9                   cmp di, cx
000483ae  746d                     je 0x4841d
000483b0  418bd4                   mov edx, r12d
000483b3  33d0                     xor edx, eax
000483b5  8bc7                     mov eax, edi
000483b7  c1e808                   shr eax, 8
000483ba  c1c203                   rol edx, 3
000483bd  33d0                     xor edx, eax
000483bf  66ff4593                 inc word ptr [rbp - 0x6d]
000483c3  e9020a0000               jmp 0x48dca
000483c8  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
000483cb  418bc1                   mov eax, r9d
000483ce  4569c120080000           imul r8d, r9d, 0x820
000483d5  458bd1                   mov r10d, r9d
000483d8  c1e802                   shr eax, 2
000483db  4403c0                   add r8d, eax
000483de  4103c8                   add ecx, r8d
000483e1  4433c9                   xor r9d, ecx
000483e4  b907020000               mov ecx, 0x207
000483e9  66394d91                 cmp word ptr [rbp - 0x6f], cx
000483ed  740c                     je 0x483fb
000483ef  66ff4593                 inc word ptr [rbp - 0x6d]
000483f3  418bd1                   mov edx, r9d
000483f6  e9cf090000               jmp 0x48dca
000483fb  663bf9                   cmp di, cx
000483fe  741d                     je 0x4841d
00048400  438d1420                 lea edx, [r8 + r12]
00048404  8bcf                     mov ecx, edi
00048406  4133d2                   xor edx, r10d
00048409  c1e908                   shr ecx, 8
0004840c  69c220080000             imul eax, edx, 0x820
00048412  03c8                     add ecx, eax
00048414  8bc2                     mov eax, edx
00048416  c1e802                   shr eax, 2
00048419  03c8                     add ecx, eax
0004841b  33d1                     xor edx, ecx
0004841d  66ff4593                 inc word ptr [rbp - 0x6d]
00048421  e9a4090000               jmp 0x48dca
00048426  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
0004842a  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
0004842e  0fb645a7                 movzx eax, byte ptr [rbp - 0x59]
00048432  4122c2                   and al, r10b
00048435  458807                   mov byte ptr [r15], r8b
00048438  243f                     and al, 0x3f
0004843a  41884f01                 mov byte ptr [r15 + 1], cl
0004843e  4983c702                 add r15, 2
00048442  c1e910                   shr ecx, 0x10
00048445  41884d00                 mov byte ptr [r13], cl
00048449  49ffc5                   inc r13
0004844c  488b4daf                 mov rcx, qword ptr [rbp - 0x51]
00048450  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00048454  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048458  8801                     mov byte ptr [rcx], al
0004845a  48ffc1                   inc rcx
0004845d  48894daf                 mov qword ptr [rbp - 0x51], rcx
00048461  e96c090000               jmp 0x48dd2
00048466  418b4804                 mov ecx, dword ptr [r8 + 4]
0004846a  4883c604                 add rsi, 4
0004846e  83459702                 add dword ptr [rbp - 0x69], 2
00048472  8bc1                     mov eax, ecx
00048474  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048478  440fb7c1                 movzx r8d, cx
0004847c  c1e818                   shr eax, 0x18
0004847f  6641c1e808               shr r8w, 8
00048484  4889759f                 mov qword ptr [rbp - 0x61], rsi
00048488  4585f6                   test r14d, r14d
0004848b  0f85ccfeffff             jne 0x4835d
00048491  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
00048495  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00048499  2245a7                   and al, byte ptr [rbp - 0x59]
0004849c  243f                     and al, 0x3f
0004849e  458807                   mov byte ptr [r15], r8b
000484a1  41884f01                 mov byte ptr [r15 + 1], cl
000484a5  4983c702                 add r15, 2
000484a9  c1e910                   shr ecx, 0x10
000484ac  41884d00                 mov byte ptr [r13], cl
000484b0  49ffc5                   inc r13
000484b3  488b4daf                 mov rcx, qword ptr [rbp - 0x51]
000484b7  4c897dbf                 mov qword ptr [rbp - 0x41], r15
000484bb  4c896db7                 mov qword ptr [rbp - 0x49], r13
000484bf  8801                     mov byte ptr [rcx], al
000484c1  48ffc1                   inc rcx
000484c4  48894daf                 mov qword ptr [rbp - 0x51], rcx
000484c8  e905090000               jmp 0x48dd2
000484cd  663bf9                   cmp di, cx
000484d0  747a                     je 0x4854c
000484d2  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
000484d6  418bd4                   mov edx, r12d
000484d9  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
000484dd  33d0                     xor edx, eax
000484df  c1c203                   rol edx, 3
000484e2  8bc7                     mov eax, edi
000484e4  c1e808                   shr eax, 8
000484e7  33d0                     xor edx, eax
000484e9  66ff4593                 inc word ptr [rbp - 0x6d]
000484ed  e9b2000000               jmp 0x485a4
000484f2  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
000484f5  418bc1                   mov eax, r9d
000484f8  4569c120080000           imul r8d, r9d, 0x820
000484ff  458bd1                   mov r10d, r9d
00048502  c1e802                   shr eax, 2
00048505  4403c0                   add r8d, eax
00048508  4103c8                   add ecx, r8d
0004850b  4433c9                   xor r9d, ecx
0004850e  b907020000               mov ecx, 0x207
00048513  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048517  7411                     je 0x4852a
00048519  66ff4593                 inc word ptr [rbp - 0x6d]
0004851d  418bd1                   mov edx, r9d
00048520  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
00048524  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00048528  eb7a                     jmp 0x485a4
0004852a  663bf9                   cmp di, cx
0004852d  741d                     je 0x4854c
0004852f  438d1420                 lea edx, [r8 + r12]
00048533  8bcf                     mov ecx, edi
00048535  4133d2                   xor edx, r10d
00048538  c1e908                   shr ecx, 8
0004853b  69c220080000             imul eax, edx, 0x820
00048541  03c8                     add ecx, eax
00048543  8bc2                     mov eax, edx
00048545  c1e802                   shr eax, 2
00048548  03c8                     add ecx, eax
0004854a  33d1                     xor edx, ecx
0004854c  66ff4593                 inc word ptr [rbp - 0x6d]
00048550  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
00048554  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00048558  eb4a                     jmp 0x485a4
0004855a  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
0004855e  410fb7c3                 movzx eax, r11w
00048562  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00048566  66c1e808                 shr ax, 8
0004856a  418807                   mov byte ptr [r15], al
0004856d  418bc3                   mov eax, r11d
00048570  45885f01                 mov byte ptr [r15 + 1], r11b
00048574  4983c702                 add r15, 2
00048578  c1e810                   shr eax, 0x10
0004857b  41884500                 mov byte ptr [r13], al
0004857f  49ffc5                   inc r13
00048582  488b45af                 mov rax, qword ptr [rbp - 0x51]
00048586  41c1eb18                 shr r11d, 0x18
0004858a  44225da7                 and r11b, byte ptr [rbp - 0x59]
0004858e  4180e33f                 and r11b, 0x3f
00048592  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00048596  448818                   mov byte ptr [rax], r11b
00048599  48ffc0                   inc rax
0004859c  488945af                 mov qword ptr [rbp - 0x51], rax
000485a0  4c896db7                 mov qword ptr [rbp - 0x49], r13
000485a4  488b759f                 mov rsi, qword ptr [rbp - 0x61]
000485a8  8b4597                   mov eax, dword ptr [rbp - 0x69]
000485ab  4883c602                 add rsi, 2
000485af  ffc0                     inc eax
000485b1  4889759f                 mov qword ptr [rbp - 0x61], rsi
000485b5  894597                   mov dword ptr [rbp - 0x69], eax
000485b8  e918080000               jmp 0x48dd5
000485bd  410fb6c0                 movzx eax, r8b
000485c1  ffc8                     dec eax
000485c3  83f80a                   cmp eax, 0xa
000485c6  0f87e0070000             ja 0x48dac
000485cc  4898                     cdqe
000485ce  488d0d2b7afbff           lea rcx, [rip - 0x485d5]
000485d5  8b8c81348f0400           mov ecx, dword ptr [rcx + rax*4 + 0x48f34]
000485dc  488d051d7afbff           lea rax, [rip - 0x485e3]
000485e3  4803c8                   add rcx, rax
000485e6  ffe1                     jmp rcx
000485e8  448b7567                 mov r14d, dword ptr [rbp + 0x67]
000485ec  4585f6                   test r14d, r14d
000485ef  0f85bb070000             jne 0x48db0
000485f5  4c3bad87000000           cmp r13, qword ptr [rbp + 0x87]
000485fc  7609                     jbe 0x48607
000485fe  410075ff                 add byte ptr [r13 - 1], sil
00048602  e9a9070000               jmp 0x48db0
00048607  41c1eb10                 shr r11d, 0x10
0004860b  45885d00                 mov byte ptr [r13], r11b
0004860f  49ffc5                   inc r13
00048612  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048616  e995070000               jmp 0x48db0
0004861b  837d6700                 cmp dword ptr [rbp + 0x67], 0
0004861f  4c8d15da79fbff           lea r10, [rip - 0x48626]
00048626  410fb6c3                 movzx eax, r11b
0004862a  410fb6f3                 movzx esi, r11b
0004862e  410fb7848270a43500       movzx eax, word ptr [r10 + rax*4 + 0x35a470]
00048637  498d0c86                 lea rcx, [r14 + rax*4]
0004863b  0f84f3000000             je 0x48734
00048641  440fb701                 movzx r8d, word ptr [rcx]
00048645  4863c3                   movsxd rax, ebx
00048648  410fb7c8                 movzx ecx, r8w
0004864c  ffc3                     inc ebx
0004864e  66c1e908                 shr cx, 8
00048652  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
00048656  4863c3                   movsxd rax, ebx
00048659  ffc3                     inc ebx
0004865b  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048660  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048665  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048669  83fb04                   cmp ebx, 4
0004866c  0f85b8000000             jne 0x4872a
00048672  33c0                     xor eax, eax
00048674  8bd8                     mov ebx, eax
00048676  39456f                   cmp dword ptr [rbp + 0x6f], eax
00048679  754b                     jne 0x486c6
0004867b  41c1c103                 rol r9d, 3
0004867f  b907020000               mov ecx, 0x207
00048684  418bc1                   mov eax, r9d
00048687  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
0004868b  66394d91                 cmp word ptr [rbp - 0x6f], cx
0004868f  7410                     je 0x486a1
00048691  66ff4593                 inc word ptr [rbp - 0x6d]
00048695  418bd1                   mov edx, r9d
00048698  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
0004869c  e9d7000000               jmp 0x48778
000486a1  663bf9                   cmp di, cx
000486a4  0f8480000000             je 0x4872a
000486aa  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
000486ae  418bd4                   mov edx, r12d
000486b1  33d0                     xor edx, eax
000486b3  8bc7                     mov eax, edi
000486b5  c1e808                   shr eax, 8
000486b8  c1c203                   rol edx, 3
000486bb  33d0                     xor edx, eax
000486bd  66ff4593                 inc word ptr [rbp - 0x6d]
000486c1  e9b2000000               jmp 0x48778
000486c6  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
000486c9  418bc1                   mov eax, r9d
000486cc  4569c120080000           imul r8d, r9d, 0x820
000486d3  458bd1                   mov r10d, r9d
000486d6  c1e802                   shr eax, 2
000486d9  4403c0                   add r8d, eax
000486dc  4103c8                   add ecx, r8d
000486df  4433c9                   xor r9d, ecx
000486e2  b907020000               mov ecx, 0x207
000486e7  66394d91                 cmp word ptr [rbp - 0x6f], cx
000486eb  7414                     je 0x48701
000486ed  66ff4593                 inc word ptr [rbp - 0x6d]
000486f1  4c8d150879fbff           lea r10, [rip - 0x486f8]
000486f8  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
000486fc  418bd1                   mov edx, r9d
000486ff  eb77                     jmp 0x48778
00048701  663bf9                   cmp di, cx
00048704  741d                     je 0x48723
00048706  438d1420                 lea edx, [r8 + r12]
0004870a  8bcf                     mov ecx, edi
0004870c  4133d2                   xor edx, r10d
0004870f  c1e908                   shr ecx, 8
00048712  69c220080000             imul eax, edx, 0x820
00048718  03c8                     add ecx, eax
0004871a  8bc2                     mov eax, edx
0004871c  c1e802                   shr eax, 2
0004871f  03c8                     add ecx, eax
00048721  33d1                     xor edx, ecx
00048723  4c8d15d678fbff           lea r10, [rip - 0x4872a]
0004872a  66ff4593                 inc word ptr [rbp - 0x6d]
0004872e  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
00048732  eb44                     jmp 0x48778
00048734  0fb64101                 movzx eax, byte ptr [rcx + 1]
00048738  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
0004873c  418807                   mov byte ptr [r15], al
0004873f  0fb601                   movzx eax, byte ptr [rcx]
00048742  41884701                 mov byte ptr [r15 + 1], al
00048746  4983c702                 add r15, 2
0004874a  0fb64102                 movzx eax, byte ptr [rcx + 2]
0004874e  41884500                 mov byte ptr [r13], al
00048752  49ffc5                   inc r13
00048755  0fb64103                 movzx eax, byte ptr [rcx + 3]
00048759  2245a7                   and al, byte ptr [rbp - 0x59]
0004875c  243f                     and al, 0x3f
0004875e  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00048762  418803                   mov byte ptr [r11], al
00048765  49ffc3                   inc r11
00048768  488b4547                 mov rax, qword ptr [rbp + 0x47]
0004876c  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048770  4c895daf                 mov qword ptr [rbp - 0x51], r11
00048774  4c8b7008                 mov r14, qword ptr [rax + 8]
00048778  410fb784b272a43500       movzx eax, word ptr [r10 + rsi*4 + 0x35a472]
00048781  450fb70486               movzx r8d, word ptr [r14 + rax*4]
00048786  498d0c86                 lea rcx, [r14 + rax*4]
0004878a  410fb7c0                 movzx eax, r8w
0004878e  66c1e808                 shr ax, 8
00048792  3c02                     cmp al, 2
00048794  0f8574010000             jne 0x4890e
0004879a  4c63d3                   movsxd r10, ebx
0004879d  0f1f00                   nop dword ptr [rax]
000487a0  837d6700                 cmp dword ptr [rbp + 0x67], 0
000487a4  488d055578fbff           lea rax, [rip - 0x487ab]
000487ab  0fb631                   movzx esi, byte ptr [rcx]
000487ae  0fb784b070a43500         movzx eax, word ptr [rax + rsi*4 + 0x35a470]
000487b6  410fb70c86               movzx ecx, word ptr [r14 + rax*4]
000487bb  4d8d0486                 lea r8, [r14 + rax*4]
000487bf  0f84de000000             je 0x488a3
000487c5  0fb7c1                   movzx eax, cx
000487c8  83c302                   add ebx, 2
000487cb  66c1e808                 shr ax, 8
000487cf  428844158f               mov byte ptr [rbp + r10 - 0x71], al
000487d4  42884c1590               mov byte ptr [rbp + r10 - 0x70], cl
000487d9  4983c202                 add r10, 2
000487dd  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
000487e2  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
000487e6  4983fa04                 cmp r10, 4
000487ea  0f85a9000000             jne 0x48899
000487f0  33c0                     xor eax, eax
000487f2  8bd8                     mov ebx, eax
000487f4  448bd0                   mov r10d, eax
000487f7  39456f                   cmp dword ptr [rbp + 0x6f], eax
000487fa  7547                     jne 0x48843
000487fc  41c1c103                 rol r9d, 3
00048800  b907020000               mov ecx, 0x207
00048805  418bc1                   mov eax, r9d
00048808  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
0004880c  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048810  7410                     je 0x48822
00048812  66ff4593                 inc word ptr [rbp - 0x6d]
00048816  418bd1                   mov edx, r9d
00048819  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
0004881d  e9bc000000               jmp 0x488de
00048822  663bf9                   cmp di, cx
00048825  7472                     je 0x48899
00048827  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
0004882b  418bd4                   mov edx, r12d
0004882e  33d0                     xor edx, eax
00048830  8bc7                     mov eax, edi
00048832  c1e808                   shr eax, 8
00048835  c1c203                   rol edx, 3
00048838  33d0                     xor edx, eax
0004883a  66ff4593                 inc word ptr [rbp - 0x6d]
0004883e  e99b000000               jmp 0x488de
00048843  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00048846  418bc1                   mov eax, r9d
00048849  4569c120080000           imul r8d, r9d, 0x820
00048850  458bd9                   mov r11d, r9d
00048853  c1e802                   shr eax, 2
00048856  4403c0                   add r8d, eax
00048859  4103c8                   add ecx, r8d
0004885c  4433c9                   xor r9d, ecx
0004885f  b907020000               mov ecx, 0x207
00048864  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048868  740d                     je 0x48877
0004886a  66ff4593                 inc word ptr [rbp - 0x6d]
0004886e  418bd1                   mov edx, r9d
00048871  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
00048875  eb67                     jmp 0x488de
00048877  663bf9                   cmp di, cx
0004887a  741d                     je 0x48899
0004887c  438d1420                 lea edx, [r8 + r12]
00048880  8bcf                     mov ecx, edi
00048882  4133d3                   xor edx, r11d
00048885  c1e908                   shr ecx, 8
00048888  69c220080000             imul eax, edx, 0x820
0004888e  03c8                     add ecx, eax
00048890  8bc2                     mov eax, edx
00048892  c1e802                   shr eax, 2
00048895  03c8                     add ecx, eax
00048897  33d1                     xor edx, ecx
00048899  66ff4593                 inc word ptr [rbp - 0x6d]
0004889d  4c8b5daf                 mov r11, qword ptr [rbp - 0x51]
000488a1  eb3b                     jmp 0x488de
000488a3  66c1e908                 shr cx, 8
000488a7  41880f                   mov byte ptr [r15], cl
000488aa  410fb600                 movzx eax, byte ptr [r8]
000488ae  41884701                 mov byte ptr [r15 + 1], al
000488b2  4983c702                 add r15, 2
000488b6  410fb64002               movzx eax, byte ptr [r8 + 2]
000488bb  41884500                 mov byte ptr [r13], al
000488bf  49ffc5                   inc r13
000488c2  410fb64003               movzx eax, byte ptr [r8 + 3]
000488c7  2245a7                   and al, byte ptr [rbp - 0x59]
000488ca  243f                     and al, 0x3f
000488cc  418803                   mov byte ptr [r11], al
000488cf  49ffc3                   inc r11
000488d2  488b4547                 mov rax, qword ptr [rbp + 0x47]
000488d6  4c895daf                 mov qword ptr [rbp - 0x51], r11
000488da  4c8b7008                 mov r14, qword ptr [rax + 8]
000488de  488d051b77fbff           lea rax, [rip - 0x488e5]
000488e5  0fb784b072a43500         movzx eax, word ptr [rax + rsi*4 + 0x35a472]
000488ed  450fb70486               movzx r8d, word ptr [r14 + rax*4]
000488f2  498d0c86                 lea rcx, [r14 + rax*4]
000488f6  410fb7c0                 movzx eax, r8w
000488fa  66c1e808                 shr ax, 8
000488fe  3c02                     cmp al, 2
00048900  0f849afeffff             je 0x487a0
00048906  4c896db7                 mov qword ptr [rbp - 0x49], r13
0004890a  4c897dbf                 mov qword ptr [rbp - 0x41], r15
0004890e  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048912  4585f6                   test r14d, r14d
00048915  7460                     je 0x48977
00048917  4863c3                   movsxd rax, ebx
0004891a  410fb7c8                 movzx ecx, r8w
0004891e  ffc3                     inc ebx
00048920  66c1e908                 shr cx, 8
00048924  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
00048928  4863c3                   movsxd rax, ebx
0004892b  ffc3                     inc ebx
0004892d  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048932  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048937  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
0004893b  83fb04                   cmp ebx, 4
0004893e  0f8562040000             jne 0x48da6
00048944  33c0                     xor eax, eax
00048946  8bd8                     mov ebx, eax
00048948  39456f                   cmp dword ptr [rbp + 0x6f], eax
0004894b  0f8503040000             jne 0x48d54
00048951  41c1c103                 rol r9d, 3
00048955  b907020000               mov ecx, 0x207
0004895a  418bc1                   mov eax, r9d
0004895d  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00048961  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048965  0f84cf030000             je 0x48d3a
0004896b  66ff4593                 inc word ptr [rbp - 0x6d]
0004896f  418bd1                   mov edx, r9d
00048972  e939040000               jmp 0x48db0
00048977  6641c1e808               shr r8w, 8
0004897c  458807                   mov byte ptr [r15], r8b
0004897f  0fb601                   movzx eax, byte ptr [rcx]
00048982  41884701                 mov byte ptr [r15 + 1], al
00048986  4983c702                 add r15, 2
0004898a  0fb64102                 movzx eax, byte ptr [rcx + 2]
0004898e  41884500                 mov byte ptr [r13], al
00048992  49ffc5                   inc r13
00048995  0fb64103                 movzx eax, byte ptr [rcx + 3]
00048999  2245a7                   and al, byte ptr [rbp - 0x59]
0004899c  243f                     and al, 0x3f
0004899e  4c897dbf                 mov qword ptr [rbp - 0x41], r15
000489a2  418803                   mov byte ptr [r11], al
000489a5  49ffc3                   inc r11
000489a8  4c895daf                 mov qword ptr [rbp - 0x51], r11
000489ac  4c896db7                 mov qword ptr [rbp - 0x49], r13
000489b0  e9fb030000               jmp 0x48db0
000489b5  837de700                 cmp dword ptr [rbp - 0x19], 0
000489b9  7542                     jne 0x489fd
000489bb  448b7567                 mov r14d, dword ptr [rbp + 0x67]
000489bf  4585f6                   test r14d, r14d
000489c2  0f85e8030000             jne 0x48db0
000489c8  4c8b55df                 mov r10, qword ptr [rbp - 0x21]
000489cc  0fb74d93                 movzx ecx, word ptr [rbp - 0x6d]
000489d0  0fb7c1                   movzx eax, cx
000489d3  66c1e806                 shr ax, 6
000489d7  0c80                     or al, 0x80
000489d9  418802                   mov byte ptr [r10], al
000489dc  0fb6c1                   movzx eax, cl
000489df  c0e002                   shl al, 2
000489e2  0c03                     or al, 3
000489e4  45884202                 mov byte ptr [r10 + 2], r8b
000489e8  41884201                 mov byte ptr [r10 + 1], al
000489ec  45885a03                 mov byte ptr [r10 + 3], r11b
000489f0  4983c204                 add r10, 4
000489f4  4c8955df                 mov qword ptr [rbp - 0x21], r10
000489f8  e9b3030000               jmp 0x48db0
000489fd  837d4f00                 cmp dword ptr [rbp + 0x4f], 0
00048a01  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048a05  0f85a5030000             jne 0x48db0
00048a0b  4585f6                   test r14d, r14d
00048a0e  7459                     je 0x48a69
00048a10  4863c3                   movsxd rax, ebx
00048a13  ffc3                     inc ebx
00048a15  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048a1a  4863c3                   movsxd rax, ebx
00048a1d  ffc3                     inc ebx
00048a1f  44885c058f               mov byte ptr [rbp + rax - 0x71], r11b
00048a24  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048a29  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048a2d  83fb04                   cmp ebx, 4
00048a30  0f8570030000             jne 0x48da6
00048a36  33c0                     xor eax, eax
00048a38  8bd8                     mov ebx, eax
00048a3a  39456f                   cmp dword ptr [rbp + 0x6f], eax
00048a3d  0f8511030000             jne 0x48d54
00048a43  41c1c103                 rol r9d, 3
00048a47  b907020000               mov ecx, 0x207
00048a4c  418bc1                   mov eax, r9d
00048a4f  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00048a53  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048a57  0f84dd020000             je 0x48d3a
00048a5d  66ff4593                 inc word ptr [rbp - 0x6d]
00048a61  418bd1                   mov edx, r9d
00048a64  e947030000               jmp 0x48db0
00048a69  418bc3                   mov eax, r11d
00048a6c  458807                   mov byte ptr [r15], r8b
00048a6f  45885f01                 mov byte ptr [r15 + 1], r11b
00048a73  4983c702                 add r15, 2
00048a77  c1e810                   shr eax, 0x10
00048a7a  41884500                 mov byte ptr [r13], al
00048a7e  49ffc5                   inc r13
00048a81  488b45af                 mov rax, qword ptr [rbp - 0x51]
00048a85  41c1eb18                 shr r11d, 0x18
00048a89  44225da7                 and r11b, byte ptr [rbp - 0x59]
00048a8d  4180e33f                 and r11b, 0x3f
00048a91  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00048a95  448818                   mov byte ptr [rax], r11b
00048a98  48ffc0                   inc rax
00048a9b  488945af                 mov qword ptr [rbp - 0x51], rax
00048a9f  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048aa3  e908030000               jmp 0x48db0
00048aa8  0fb675a7                 movzx esi, byte ptr [rbp - 0x59]
00048aac  4122f2                   and sil, r10b
00048aaf  4080cec4                 or sil, 0xc4
00048ab3  4180fb01                 cmp r11b, 1
00048ab7  0f87f1010000             ja 0x48cae
00048abd  4c8b459f                 mov r8, qword ptr [rbp - 0x61]
00048ac1  4983c0fe                 add r8, -2
00048ac5  4c3b4557                 cmp r8, qword ptr [rbp + 0x57]
00048ac9  7223                     jb 0x48aee
00048acb  0f1f440000               nop dword ptr [rax + rax]
00048ad0  410fb700                 movzx eax, word ptr [r8]
00048ad4  418b0c86                 mov ecx, dword ptr [r14 + rax*4]
00048ad8  448bd1                   mov r10d, ecx
00048adb  0fb7c1                   movzx eax, cx
00048ade  41c1ea18                 shr r10d, 0x18
00048ae2  66c1e808                 shr ax, 8
00048ae6  3c03                     cmp al, 3
00048ae8  736a                     jae 0x48b54
00048aea  3c02                     cmp al, 2
00048aec  7571                     jne 0x48b5f
00048aee  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048af2  4585f6                   test r14d, r14d
00048af5  0f84a0010000             je 0x48c9b
00048afb  4863c3                   movsxd rax, ebx
00048afe  ffc3                     inc ebx
00048b00  c644058fff               mov byte ptr [rbp + rax - 0x71], 0xff
00048b05  4863c3                   movsxd rax, ebx
00048b08  ffc3                     inc ebx
00048b0a  c644058fff               mov byte ptr [rbp + rax - 0x71], 0xff
00048b0f  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048b14  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048b18  83fb04                   cmp ebx, 4
00048b1b  0f8585020000             jne 0x48da6
00048b21  33c0                     xor eax, eax
00048b23  8bd8                     mov ebx, eax
00048b25  39456f                   cmp dword ptr [rbp + 0x6f], eax
00048b28  0f8526020000             jne 0x48d54
00048b2e  41c1c103                 rol r9d, 3
00048b32  b907020000               mov ecx, 0x207
00048b37  418bc1                   mov eax, r9d
00048b3a  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00048b3e  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048b42  0f84f2010000             je 0x48d3a
00048b48  66ff4593                 inc word ptr [rbp - 0x6d]
00048b4c  418bd1                   mov edx, r9d
00048b4f  e95c020000               jmp 0x48db0
00048b54  0f85c0000000             jne 0x48c1a
00048b5a  80f901                   cmp cl, 1
00048b5d  7713                     ja 0x48b72
00048b5f  4983c0fe                 add r8, -2
00048b63  4c3b4557                 cmp r8, qword ptr [rbp + 0x57]
00048b67  0f8363ffffff             jae 0x48ad0
00048b6d  e97cffffff               jmp 0x48aee
00048b72  488b4547                 mov rax, qword ptr [rbp + 0x47]
00048b76  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048b7a  440fb64040               movzx r8d, byte ptr [rax + 0x40]
00048b7f  0fb6c1                   movzx eax, cl
00048b82  0fb64da7                 movzx ecx, byte ptr [rbp - 0x59]
00048b86  4122ca                   and cl, r10b
00048b89  6641c1e008               shl r8w, 8
00048b8e  4c8b55cf                 mov r10, qword ptr [rbp - 0x31]
00048b92  80c9c4                   or cl, 0xc4
00048b95  66440bc0                 or r8w, ax
00048b99  4585f6                   test r14d, r14d
00048b9c  7519                     jne 0x48bb7
00048b9e  4c8b6dd7                 mov r13, qword ptr [rbp - 0x29]
00048ba2  0fb6c1                   movzx eax, cl
00048ba5  24c6                     and al, 0xc6
00048ba7  418802                   mov byte ptr [r10], al
00048baa  0fb6c1                   movzx eax, cl
00048bad  24e4                     and al, 0xe4
00048baf  4388046a                 mov byte ptr [r10 + r13*2], al
00048bb3  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00048bb7  4584db                   test r11b, r11b
00048bba  752a                     jne 0x48be6
00048bbc  4585f6                   test r14d, r14d
00048bbf  7548                     jne 0x48c09
00048bc1  4c8b5dd7                 mov r11, qword ptr [rbp - 0x29]
00048bc5  80e1c5                   and cl, 0xc5
00048bc8  4585f6                   test r14d, r14d
00048bcb  4b8d045a                 lea rax, [r10 + r11*2]
00048bcf  43c6041304               mov byte ptr [r11 + r10], 4
00048bd4  41880c03                 mov byte ptr [r11 + rax], cl
00048bd8  498d4201                 lea rax, [r10 + 1]
00048bdc  490f45c2                 cmovne rax, r10
00048be0  488945cf                 mov qword ptr [rbp - 0x31], rax
00048be4  eb3c                     jmp 0x48c22
00048be6  b887ff0000               mov eax, 0xff87
00048beb  664423c0                 and r8w, ax
00048bef  4585f6                   test r14d, r14d
00048bf2  7515                     jne 0x48c09
00048bf4  488b4dd7                 mov rcx, qword ptr [rbp - 0x29]
00048bf8  4080e6c5                 and sil, 0xc5
00048bfc  498d044a                 lea rax, [r10 + rcx*2]
00048c00  42c6041105               mov byte ptr [rcx + r10], 5
00048c05  40883401                 mov byte ptr [rcx + rax], sil
00048c09  4585f6                   test r14d, r14d
00048c0c  498d4201                 lea rax, [r10 + 1]
00048c10  490f45c2                 cmovne rax, r10
00048c14  488945cf                 mov qword ptr [rbp - 0x31], rax
00048c18  eb08                     jmp 0x48c22
00048c1a  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048c1e  440fb7c1                 movzx r8d, cx
00048c22  b8ffff0000               mov eax, 0xffff
00048c27  66443bc0                 cmp r8w, ax
00048c2b  0f84c1feffff             je 0x48af2
00048c31  410fb6c8                 movzx ecx, r8b
00048c35  4585f6                   test r14d, r14d
00048c38  0f84c9000000             je 0x48d07
00048c3e  4863c3                   movsxd rax, ebx
00048c41  ffc3                     inc ebx
00048c43  6641c1e808               shr r8w, 8
00048c48  448844058f               mov byte ptr [rbp + rax - 0x71], r8b
00048c4d  4863c3                   movsxd rax, ebx
00048c50  ffc3                     inc ebx
00048c52  884c058f                 mov byte ptr [rbp + rax - 0x71], cl
00048c56  440fb6658f               movzx r12d, byte ptr [rbp - 0x71]
00048c5b  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048c5f  83fb04                   cmp ebx, 4
00048c62  0f853e010000             jne 0x48da6
00048c68  33c0                     xor eax, eax
00048c6a  8bd8                     mov ebx, eax
00048c6c  39456f                   cmp dword ptr [rbp + 0x6f], eax
00048c6f  0f85df000000             jne 0x48d54
00048c75  41c1c103                 rol r9d, 3
00048c79  b907020000               mov ecx, 0x207
00048c7e  418bc1                   mov eax, r9d
00048c81  44334d8f                 xor r9d, dword ptr [rbp - 0x71]
00048c85  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048c89  0f84ab000000             je 0x48d3a
00048c8f  66ff4593                 inc word ptr [rbp - 0x6d]
00048c93  418bd1                   mov edx, r9d
00048c96  e915010000               jmp 0x48db0
00048c9b  6641c707ffff             mov word ptr [r15], 0xffff
00048ca1  4983c702                 add r15, 2
00048ca5  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00048ca9  e902010000               jmp 0x48db0
00048cae  488b4547                 mov rax, qword ptr [rbp + 0x47]
00048cb2  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048cb6  440fb64040               movzx r8d, byte ptr [rax + 0x40]
00048cbb  6641c1e008               shl r8w, 8
00048cc0  410fb6c3                 movzx eax, r11b
00048cc4  66440bc0                 or r8w, ax
00048cc8  4585f6                   test r14d, r14d
00048ccb  0f8560ffffff             jne 0x48c31
00048cd1  488b4dcf                 mov rcx, qword ptr [rbp - 0x31]
00048cd5  400fb6c6                 movzx eax, sil
00048cd9  4c8b55d7                 mov r10, qword ptr [rbp - 0x29]
00048cdd  24c6                     and al, 0xc6
00048cdf  8801                     mov byte ptr [rcx], al
00048ce1  400fb6c6                 movzx eax, sil
00048ce5  41c6040a03               mov byte ptr [r10 + rcx], 3
00048cea  24e4                     and al, 0xe4
00048cec  42880451                 mov byte ptr [rcx + r10*2], al
00048cf0  4080e6c5                 and sil, 0xc5
00048cf4  4a8d0451                 lea rax, [rcx + r10*2]
00048cf8  48ffc1                   inc rcx
00048cfb  48894dcf                 mov qword ptr [rbp - 0x31], rcx
00048cff  410fb6c8                 movzx ecx, r8b
00048d03  41883402                 mov byte ptr [r10 + rax], sil
00048d07  0fb645c9                 movzx eax, byte ptr [rbp - 0x37]
00048d0b  6641c1e808               shr r8w, 8
00048d10  458807                   mov byte ptr [r15], r8b
00048d13  41884f01                 mov byte ptr [r15 + 1], cl
00048d17  4983c702                 add r15, 2
00048d1b  41884500                 mov byte ptr [r13], al
00048d1f  49ffc5                   inc r13
00048d22  488b45af                 mov rax, qword ptr [rbp - 0x51]
00048d26  4c897dbf                 mov qword ptr [rbp - 0x41], r15
00048d2a  4c896db7                 mov qword ptr [rbp - 0x49], r13
00048d2e  c60002                   mov byte ptr [rax], 2
00048d31  48ffc0                   inc rax
00048d34  488945af                 mov qword ptr [rbp - 0x51], rax
00048d38  eb76                     jmp 0x48db0
00048d3a  663bf9                   cmp di, cx
00048d3d  7467                     je 0x48da6
00048d3f  418bd4                   mov edx, r12d
00048d42  33d0                     xor edx, eax
00048d44  8bc7                     mov eax, edi
00048d46  c1e808                   shr eax, 8
00048d49  c1c203                   rol edx, 3
00048d4c  33d0                     xor edx, eax
00048d4e  66ff4593                 inc word ptr [rbp - 0x6d]
00048d52  eb5c                     jmp 0x48db0
00048d54  8b4d8f                   mov ecx, dword ptr [rbp - 0x71]
00048d57  418bc1                   mov eax, r9d
00048d5a  4569c120080000           imul r8d, r9d, 0x820
00048d61  458bd1                   mov r10d, r9d
00048d64  c1e802                   shr eax, 2
00048d67  4403c0                   add r8d, eax
00048d6a  4103c8                   add ecx, r8d
00048d6d  4433c9                   xor r9d, ecx
00048d70  b907020000               mov ecx, 0x207
00048d75  66394d91                 cmp word ptr [rbp - 0x6f], cx
00048d79  7409                     je 0x48d84
00048d7b  66ff4593                 inc word ptr [rbp - 0x6d]
00048d7f  418bd1                   mov edx, r9d
00048d82  eb2c                     jmp 0x48db0
00048d84  663bf9                   cmp di, cx
00048d87  741d                     je 0x48da6
00048d89  438d1420                 lea edx, [r8 + r12]
00048d8d  8bcf                     mov ecx, edi
00048d8f  4133d2                   xor edx, r10d
00048d92  c1e908                   shr ecx, 8
00048d95  69c220080000             imul eax, edx, 0x820
00048d9b  03c8                     add ecx, eax
00048d9d  8bc2                     mov eax, edx
00048d9f  c1e802                   shr eax, 2
00048da2  03c8                     add ecx, eax
00048da4  33d1                     xor edx, ecx
00048da6  66ff4593                 inc word ptr [rbp - 0x6d]
00048daa  eb04                     jmp 0x48db0
00048dac  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048db0  488b759f                 mov rsi, qword ptr [rbp - 0x61]
00048db4  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048db7  4883c602                 add rsi, 2
00048dbb  ffc0                     inc eax
00048dbd  4889759f                 mov qword ptr [rbp - 0x61], rsi
00048dc1  894597                   mov dword ptr [rbp - 0x69], eax
00048dc4  eb0f                     jmp 0x48dd5
00048dc6  448b7567                 mov r14d, dword ptr [rbp + 0x67]
00048dca  4c8b7dbf                 mov r15, qword ptr [rbp - 0x41]
00048dce  4c8b6db7                 mov r13, qword ptr [rbp - 0x49]
00048dd2  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048dd5  3b455f                   cmp eax, dword ptr [rbp + 0x5f]
00048dd8  0f8ee2edffff             jle 0x47bc0
00048dde  4c8b55af                 mov r10, qword ptr [rbp - 0x51]
00048de2  b807020000               mov eax, 0x207
00048de7  448b5d6f                 mov r11d, dword ptr [rbp + 0x6f]
00048deb  eb04                     jmp 0x48df1
00048ded  0fb77d8f                 movzx edi, word ptr [rbp - 0x71]
00048df1  4585f6                   test r14d, r14d
00048df4  4c8bb42490000000         mov r14, qword ptr [rsp + 0x90]
00048dfc  0f84c9000000             je 0x48ecb

; chunk at RVA 0x48e02 (79 bytes)
00048e02  85db                     test ebx, ebx
00048e04  0f849c000000             je 0x48ea6
00048e0a  663bf8                   cmp di, ax
00048e0d  0f8493000000             je 0x48ea6
00048e13  4585db                   test r11d, r11d
00048e16  7539                     jne 0x48e51
00048e18  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00048e20  41c1c103                 rol r9d, 3
00048e24  410fb6c4                 movzx eax, r12b
00048e28  4433c8                   xor r9d, eax
00048e2b  0fb64590                 movzx eax, byte ptr [rbp - 0x70]
00048e2f  41c1c103                 rol r9d, 3
00048e33  4433c8                   xor r9d, eax
00048e36  488b4577                 mov rax, qword ptr [rbp + 0x77]
00048e3a  448908                   mov dword ptr [rax], r9d
00048e3d  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048e40  4881c498000000           add rsp, 0x98
00048e47  415f                     pop r15
00048e49  415d                     pop r13
00048e4b  415c                     pop r12
00048e4d  5e                       pop rsi
00048e4e  5b                       pop rbx
00048e4f  5d                       pop rbp
00048e50  c3                       ret

; chunk at RVA 0x48e51 (85 bytes)
00048e51  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00048e59  418bc1                   mov eax, r9d
00048e5c  c1e802                   shr eax, 2
00048e5f  4169c920080000           imul ecx, r9d, 0x820
00048e66  03c8                     add ecx, eax
00048e68  410fb6c4                 movzx eax, r12b
00048e6c  03c8                     add ecx, eax
00048e6e  4133c9                   xor ecx, r9d
00048e71  448bc9                   mov r9d, ecx
00048e74  69c920080000             imul ecx, ecx, 0x820
00048e7a  418bc1                   mov eax, r9d
00048e7d  c1e802                   shr eax, 2
00048e80  03c8                     add ecx, eax
00048e82  0fb64590                 movzx eax, byte ptr [rbp - 0x70]
00048e86  03c8                     add ecx, eax
00048e88  488b4577                 mov rax, qword ptr [rbp + 0x77]
00048e8c  4433c9                   xor r9d, ecx
00048e8f  448908                   mov dword ptr [rax], r9d
00048e92  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048e95  4881c498000000           add rsp, 0x98
00048e9c  415f                     pop r15
00048e9e  415d                     pop r13
00048ea0  415c                     pop r12
00048ea2  5e                       pop rsi
00048ea3  5b                       pop rbx
00048ea4  5d                       pop rbp
00048ea5  c3                       ret

; chunk at RVA 0x48ea6 (37 bytes)
00048ea6  488b4577                 mov rax, qword ptr [rbp + 0x77]
00048eaa  448bca                   mov r9d, edx
00048ead  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00048eb5  8910                     mov dword ptr [rax], edx
00048eb7  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048eba  4881c498000000           add rsp, 0x98
00048ec1  415f                     pop r15
00048ec3  415d                     pop r13
00048ec5  415c                     pop r12
00048ec7  5e                       pop rsi
00048ec8  5b                       pop rbx
00048ec9  5d                       pop rbp
00048eca  c3                       ret

; chunk at RVA 0x48ecb (86 bytes)
00048ecb  488b858f000000           mov rax, qword ptr [rbp + 0x8f]
00048ed2  488b8da7000000           mov rcx, qword ptr [rbp + 0xa7]
00048ed9  488bbc24d0000000         mov rdi, qword ptr [rsp + 0xd0]
00048ee1  4c8938                   mov qword ptr [rax], r15
00048ee4  488b8597000000           mov rax, qword ptr [rbp + 0x97]
00048eeb  4c8928                   mov qword ptr [rax], r13
00048eee  488b859f000000           mov rax, qword ptr [rbp + 0x9f]
00048ef5  4c8910                   mov qword ptr [rax], r10
00048ef8  488b45cf                 mov rax, qword ptr [rbp - 0x31]
00048efc  488901                   mov qword ptr [rcx], rax
00048eff  488b45df                 mov rax, qword ptr [rbp - 0x21]
00048f03  488b8daf000000           mov rcx, qword ptr [rbp + 0xaf]
00048f0a  488901                   mov qword ptr [rcx], rax
00048f0d  8b4597                   mov eax, dword ptr [rbp - 0x69]
00048f10  4881c498000000           add rsp, 0x98
00048f17  415f                     pop r15
00048f19  415d                     pop r13
00048f1b  415c                     pop r12
00048f1d  5e                       pop rsi
00048f1e  5b                       pop rbx
00048f1f  5d                       pop rbp
00048f20  c3                       ret

; chunk at RVA 0x48f21 (63 bytes)
00048f21  33c0                     xor eax, eax
00048f23  4881c498000000           add rsp, 0x98
00048f2a  415f                     pop r15
00048f2c  415d                     pop r13
00048f2e  415c                     pop r12
00048f30  5e                       pop rsi
00048f31  5b                       pop rbx
00048f32  5d                       pop rbp
00048f33  c3                       ret
00048f34  e88504001b               call 0x1b0493be
00048f39  860400                   xchg byte ptr [rax + rax], al
00048f3c  a88a                     test al, 0x8a
00048f3e  0400                     add al, 0
00048f40  ac                       lodsb al, byte ptr [rsi]
00048f41  8d0400                   lea eax, [rax + rax]
00048f44  ac                       lodsb al, byte ptr [rsi]
00048f45  8d0400                   lea eax, [rax + rax]
00048f48  b589                     mov ch, 0x89
00048f4a  0400                     add al, 0
00048f4c  fd                       std
00048f4d  890400                   mov dword ptr [rax + rax], eax
00048f50  fd                       std
00048f51  890400                   mov dword ptr [rax + rax], eax
00048f54  fd                       std
00048f55  890400                   mov dword ptr [rax + rax], eax
00048f58  fd                       std
00048f59  890400                   mov dword ptr [rax + rax], eax
00048f5c  fd                       std
00048f5d  890400                   mov dword ptr [rax + rax], eax
