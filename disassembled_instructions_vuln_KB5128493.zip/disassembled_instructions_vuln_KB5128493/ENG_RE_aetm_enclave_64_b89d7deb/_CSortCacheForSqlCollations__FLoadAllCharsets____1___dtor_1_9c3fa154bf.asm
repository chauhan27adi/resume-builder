; `CSortCacheForSqlCollations::FLoadAllCharsets'::`1'::dtor$1
; aetm_enclave.dll, primary RVA 0x61b10, 31 bytes in 1 chunk(s)

; chunk at RVA 0x61b10 (31 bytes)
00061b10  4055                     push rbp
00061b12  4883ec20                 sub rsp, 0x20
00061b16  488bea                   mov rbp, rdx
00061b19  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00061b1d  488b12                   mov rdx, qword ptr [rdx]
00061b20  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
00061b24  e8577efbff               call 0x19980
00061b29  4883c420                 add rsp, 0x20
00061b2d  5d                       pop rbp
00061b2e  c3                       ret
