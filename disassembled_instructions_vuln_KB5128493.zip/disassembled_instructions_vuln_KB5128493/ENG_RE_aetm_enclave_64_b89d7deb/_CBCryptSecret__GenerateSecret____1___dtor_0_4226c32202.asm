; `CBCryptSecret::GenerateSecret'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x61700, 38 bytes in 1 chunk(s)

; chunk at RVA 0x61700 (38 bytes)
00061700  4055                     push rbp
00061702  4883ec20                 sub rsp, 0x20
00061706  488bea                   mov rbp, rdx
00061709  8b4530                   mov eax, dword ptr [rbp + 0x30]
0006170c  83e001                   and eax, 1
0006170f  85c0                     test eax, eax
00061711  740d                     je 0x61720
00061713  836530fe                 and dword ptr [rbp + 0x30], 0xfffffffe
00061717  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0006171b  e8d077fbff               call 0x18ef0
00061720  4883c420                 add rsp, 0x20
00061724  5d                       pop rbp
00061725  c3                       ret
