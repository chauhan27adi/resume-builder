; `CBCryptECDH384PublicKey::ImportKey'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x615b0, 38 bytes in 1 chunk(s)

; chunk at RVA 0x615b0 (38 bytes)
000615b0  4055                     push rbp
000615b2  4883ec20                 sub rsp, 0x20
000615b6  488bea                   mov rbp, rdx
000615b9  8b4540                   mov eax, dword ptr [rbp + 0x40]
000615bc  83e001                   and eax, 1
000615bf  85c0                     test eax, eax
000615c1  740d                     je 0x615d0
000615c3  836540fe                 and dword ptr [rbp + 0x40], 0xfffffffe
000615c7  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
000615cb  e8f078fbff               call 0x18ec0
000615d0  4883c420                 add rsp, 0x20
000615d4  5d                       pop rbp
000615d5  c3                       ret
