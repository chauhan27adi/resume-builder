; `PmoNewMemObj'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x60790, 28 bytes in 1 chunk(s)

; chunk at RVA 0x60790 (28 bytes)
00060790  4055                     push rbp
00060792  4883ec20                 sub rsp, 0x20
00060796  488bea                   mov rbp, rdx
00060799  488b5540                 mov rdx, qword ptr [rbp + 0x40]
0006079d  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
000607a1  e8da91fbff               call 0x19980
000607a6  4883c420                 add rsp, 0x20
000607aa  5d                       pop rbp
000607ab  c3                       ret
