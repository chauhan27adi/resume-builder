; std::unique_ptr<CAEEncryptionProvider,MemObjDeleter>::~unique_ptr<CAEEncryptionProvider,MemObjDeleter>
; aetm_enclave.dll, primary RVA 0x10120, 112 bytes in 1 chunk(s)

; chunk at RVA 0x10120 (112 bytes)
00010120  4057                     push rdi
00010122  4883ec30                 sub rsp, 0x30
00010126  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0001012f  48895c2440               mov qword ptr [rsp + 0x40], rbx
00010134  488bf9                   mov rdi, rcx
00010137  488b5908                 mov rbx, qword ptr [rcx + 8]
0001013b  4885db                   test rbx, rbx
0001013e  7445                     je 0x10185
00010140  488b4b70                 mov rcx, qword ptr [rbx + 0x70]
00010144  4885c9                   test rcx, rcx
00010147  7413                     je 0x1015c
00010149  488b01                   mov rax, qword ptr [rcx]
0001014c  ba01000000               mov edx, 1
00010151  ff5010                   call qword ptr [rax + 0x10]
00010154  48c7437000000000         mov qword ptr [rbx + 0x70], 0
0001015c  488b4b78                 mov rcx, qword ptr [rbx + 0x78]
00010160  4885c9                   test rcx, rcx
00010163  7413                     je 0x10178
00010165  488b01                   mov rax, qword ptr [rcx]
00010168  ba01000000               mov edx, 1
0001016d  ff5010                   call qword ptr [rax + 0x10]
00010170  48c7437800000000         mov qword ptr [rbx + 0x78], 0
00010178  488b0f                   mov rcx, qword ptr [rdi]
0001017b  488b01                   mov rax, qword ptr [rcx]
0001017e  488bd3                   mov rdx, rbx
00010181  ff5028                   call qword ptr [rax + 0x28]
00010184  90                       nop
00010185  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
0001018a  4883c430                 add rsp, 0x30
0001018e  5f                       pop rdi
0001018f  c3                       ret
