; TMatchPattern<char,CCharHelper>::match_pattern_resumable
; aetm_enclave.dll, primary RVA 0x33660, 3964 bytes in 4 chunk(s)

; chunk at RVA 0x33660 (198 bytes)
00033660  4053                     push rbx
00033662  56                       push rsi
00033663  4156                     push r14
00033665  4157                     push r15
00033667  4881ec38010000           sub rsp, 0x138
0003366e  488b0593790700           mov rax, qword ptr [rip + 0x77993]
00033675  4833c4                   xor rax, rsp
00033678  4889842410010000         mov qword ptr [rsp + 0x110], rax
00033680  488b842490010000         mov rax, qword ptr [rsp + 0x190]
00033688  4c8bf1                   mov r14, rcx
0003368b  4c8b9c24b0010000         mov r11, qword ptr [rsp + 0x1b0]
00033693  33c9                     xor ecx, ecx
00033695  4c8bbc2488010000         mov r15, qword ptr [rsp + 0x188]
0003369d  418bf0                   mov esi, r8d
000336a0  48898424e0000000         mov qword ptr [rsp + 0xe0], rax
000336a8  488bda                   mov rbx, rdx
000336ab  488b842498010000         mov rax, qword ptr [rsp + 0x198]
000336b3  48898424e8000000         mov qword ptr [rsp + 0xe8], rax
000336bb  488b8424a0010000         mov rax, qword ptr [rsp + 0x1a0]
000336c3  4c898c2400010000         mov qword ptr [rsp + 0x100], r9
000336cb  4c8bca                   mov r9, rdx
000336ce  48898424f0000000         mov qword ptr [rsp + 0xf0], rax
000336d6  4c899c24c8000000         mov qword ptr [rsp + 0xc8], r11
000336de  48899424b8000000         mov qword ptr [rsp + 0xb8], rdx
000336e6  4d85f6                   test r14, r14
000336e9  7437                     je 0x33722
000336eb  458b4654                 mov r8d, dword ptr [r14 + 0x54]
000336ef  4585c0                   test r8d, r8d
000336f2  742e                     je 0x33722
000336f4  488b056d444300           mov rax, qword ptr [rip + 0x43446d]
000336fb  480590070000             add rax, 0x790
00033701  488b10                   mov rdx, qword ptr [rax]
00033704  4885d2                   test rdx, rdx
00033707  7406                     je 0x3370f
00033709  44394210                 cmp dword ptr [rdx + 0x10], r8d
0003370d  7411                     je 0x33720
0003370f  ffc1                     inc ecx
00033711  4883c008                 add rax, 8
00033715  83f911                   cmp ecx, 0x11
00033718  0f8d680e0000             jge 0x34586
0003371e  ebe1                     jmp 0x33701
00033720  33c9                     xor ecx, ecx
00033722  41803b00                 cmp byte ptr [r11], 0

; chunk at RVA 0x33726 (3680 bytes)
00033726  4889ac2478010000         mov qword ptr [rsp + 0x178], rbp
0003372e  488be9                   mov rbp, rcx
00033731  4889bc2430010000         mov qword ptr [rsp + 0x130], rdi
00033739  488bf9                   mov rdi, rcx
0003373c  4c89a42428010000         mov qword ptr [rsp + 0x128], r12
00033744  4c89ac2420010000         mov qword ptr [rsp + 0x120], r13
0003374c  41bd01000000             mov r13d, 1
00033752  48898c24a8000000         mov qword ptr [rsp + 0xa8], rcx
0003375a  48898c24c0000000         mov qword ptr [rsp + 0xc0], rcx
00033762  48898c2480000000         mov qword ptr [rsp + 0x80], rcx
0003376a  48898c2490000000         mov qword ptr [rsp + 0x90], rcx
00033772  894c2470                 mov dword ptr [rsp + 0x70], ecx
00033776  48894c2468               mov qword ptr [rsp + 0x68], rcx
0003377b  48894c2478               mov qword ptr [rsp + 0x78], rcx
00033780  48898c24b0000000         mov qword ptr [rsp + 0xb0], rcx
00033788  48894c2460               mov qword ptr [rsp + 0x60], rcx
0003378d  48898c24d0000000         mov qword ptr [rsp + 0xd0], rcx
00033795  898c2488000000           mov dword ptr [rsp + 0x88], ecx
0003379c  c644245000               mov byte ptr [rsp + 0x50], 0
000337a1  7411                     je 0x337b4
000337a3  4c8ba42480010000         mov r12, qword ptr [rsp + 0x180]
000337ab  41c60300                 mov byte ptr [r11], 0
000337af  e9bf020000               jmp 0x33a73
000337b4  498b4320                 mov rax, qword ptr [r11 + 0x20]
000337b8  498b8bc81f0000           mov rcx, qword ptr [r11 + 0x1fc8]
000337bf  4d8b6308                 mov r12, qword ptr [r11 + 8]
000337c3  498b7b58                 mov rdi, qword ptr [r11 + 0x58]
000337c7  458b4370                 mov r8d, dword ptr [r11 + 0x70]
000337cb  418b7318                 mov esi, dword ptr [r11 + 0x18]
000337cf  4889842498000000         mov qword ptr [rsp + 0x98], rax
000337d7  410fb64328               movzx eax, byte ptr [r11 + 0x28]
000337dc  89442454                 mov dword ptr [rsp + 0x54], eax
000337e0  498b4330                 mov rax, qword ptr [r11 + 0x30]
000337e4  48898424a8000000         mov qword ptr [rsp + 0xa8], rax
000337ec  498b4338                 mov rax, qword ptr [r11 + 0x38]
000337f0  48898424c0000000         mov qword ptr [rsp + 0xc0], rax
000337f8  498b4340                 mov rax, qword ptr [r11 + 0x40]
000337fc  4889842480000000         mov qword ptr [rsp + 0x80], rax
00033804  418b4348                 mov eax, dword ptr [r11 + 0x48]
00033808  89442470                 mov dword ptr [rsp + 0x70], eax
0003380c  498b4350                 mov rax, qword ptr [r11 + 0x50]
00033810  48898424b0000000         mov qword ptr [rsp + 0xb0], rax
00033818  498b4360                 mov rax, qword ptr [r11 + 0x60]
0003381c  4889442460               mov qword ptr [rsp + 0x60], rax
00033821  498b4368                 mov rax, qword ptr [r11 + 0x68]
00033825  48898424d0000000         mov qword ptr [rsp + 0xd0], rax
0003382d  410fb64374               movzx eax, byte ptr [r11 + 0x74]
00033832  88442450                 mov byte ptr [rsp + 0x50], al
00033836  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
0003383e  4889bc24a0000000         mov qword ptr [rsp + 0xa0], rdi
00033846  4489842488000000         mov dword ptr [rsp + 0x88], r8d
0003384e  4883f9ff                 cmp rcx, -1
00033852  7506                     jne 0x3385a
00033854  33ed                     xor ebp, ebp
00033856  8bdd                     mov ebx, ebp
00033858  eb05                     jmp 0x3385f
0003385a  4803d9                   add rbx, rcx
0003385d  33ed                     xor ebp, ebp
0003385f  4883f9ff                 cmp rcx, -1
00033863  498d0409                 lea rax, [r9 + rcx]
00033867  498b8bd01f0000           mov rcx, qword ptr [r11 + 0x1fd0]
0003386e  4c8bd5                   mov r10, rbp
00033871  4c0f45d0                 cmovne r10, rax
00033875  488bd5                   mov rdx, rbp
00033878  4883f9ff                 cmp rcx, -1
0003387c  498d0409                 lea rax, [r9 + rcx]
00033880  480f45d0                 cmovne rdx, rax
00033884  4585c0                   test r8d, r8d
00033887  7420                     je 0x338a9
00033889  4d8b8bb81f0000           mov r9, qword ptr [r11 + 0x1fb8]
00033890  418b83c01f0000           mov eax, dword ptr [r11 + 0x1fc0]
00033897  4903c1                   add rax, r9
0003389a  4c894c2468               mov qword ptr [rsp + 0x68], r9
0003389f  48898424d8000000         mov qword ptr [rsp + 0xd8], rax
000338a7  eb10                     jmp 0x338b9
000338a9  4c8bcd                   mov r9, rbp
000338ac  48896c2468               mov qword ptr [rsp + 0x68], rbp
000338b1  4889ac24d8000000         mov qword ptr [rsp + 0xd8], rbp
000338b9  498b8bd81f0000           mov rcx, qword ptr [r11 + 0x1fd8]
000338c0  4c8bc5                   mov r8, rbp
000338c3  4883f9ff                 cmp rcx, -1
000338c7  4889942490000000         mov qword ptr [rsp + 0x90], rdx
000338cf  4a8d0409                 lea rax, [rcx + r9]
000338d3  498b8be01f0000           mov rcx, qword ptr [r11 + 0x1fe0]
000338da  4c0f45c0                 cmovne r8, rax
000338de  4883f9ff                 cmp rcx, -1
000338e2  4c89442478               mov qword ptr [rsp + 0x78], r8
000338e7  4a8d0409                 lea rax, [rcx + r9]
000338eb  4c8bcd                   mov r9, rbp
000338ee  4c0f45c8                 cmovne r9, rax
000338f2  418b4314                 mov eax, dword ptr [r11 + 0x14]
000338f6  ffc8                     dec eax
000338f8  498be9                   mov rbp, r9
000338fb  83f805                   cmp eax, 5
000338fe  0f876d010000             ja 0x33a71
00033904  4c8d1df5c6fcff           lea r11, [rip - 0x3390b]
0003390b  4898                     cdqe
0003390d  4889942490000000         mov qword ptr [rsp + 0x90], rdx
00033915  4c89442478               mov qword ptr [rsp + 0x78], r8
0003391a  418b8c83c4450300         mov ecx, dword ptr [r11 + rax*4 + 0x345c4]
00033922  4903cb                   add rcx, r11
00033925  ffe1                     jmp rcx
00033927  498bda                   mov rbx, r10
0003392a  4889942490000000         mov qword ptr [rsp + 0x90], rdx
00033932  4c89442478               mov qword ptr [rsp + 0x78], r8
00033937  e972010000               jmp 0x33aae
0003393c  4889942490000000         mov qword ptr [rsp + 0x90], rdx
00033944  4c89442478               mov qword ptr [rsp + 0x78], r8
00033949  e9a8010000               jmp 0x33af6
0003394e  498bda                   mov rbx, r10
00033951  4889942490000000         mov qword ptr [rsp + 0x90], rdx
00033959  4c89442478               mov qword ptr [rsp + 0x78], r8
0003395e  e9b5030000               jmp 0x33d18
00033963  4889942490000000         mov qword ptr [rsp + 0x90], rdx
0003396b  4c89442478               mov qword ptr [rsp + 0x78], r8
00033970  e9a2040000               jmp 0x33e17
00033975  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
0003397a  498bda                   mov rbx, r10
0003397d  4889942490000000         mov qword ptr [rsp + 0x90], rdx
00033985  4c89442478               mov qword ptr [rsp + 0x78], r8
0003398a  488bf9                   mov rdi, rcx
0003398d  483b8c24a0000000         cmp rcx, qword ptr [rsp + 0xa0]
00033995  754c                     jne 0x339e3
00033997  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
0003399f  488bcd                   mov rcx, rbp
000339a2  ff9424e0000000           call qword ptr [rsp + 0xe0]
000339a9  84c0                     test al, al
000339ab  0f8457090000             je 0x34308
000339b1  48ff8424a0000000         inc qword ptr [rsp + 0xa0]
000339b9  8b442454                 mov eax, dword ptr [rsp + 0x54]
000339bd  84c0                     test al, al
000339bf  741d                     je 0x339de
000339c1  4c3ba424a8000000         cmp r12, qword ptr [rsp + 0xa8]
000339c9  7713                     ja 0x339de
000339cb  807d0020                 cmp byte ptr [rbp], 0x20
000339cf  b900000000               mov ecx, 0
000339d4  0fb6c0                   movzx eax, al
000339d7  0f45c1                   cmovne eax, ecx
000339da  88442454                 mov byte ptr [rsp + 0x54], al
000339de  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
000339e3  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
000339e7  48ffc1                   inc rcx
000339ea  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
000339ee  418b5654                 mov edx, dword ptr [r14 + 0x54]
000339f2  44896c2440               mov dword ptr [rsp + 0x40], r13d
000339f7  48896c2438               mov qword ptr [rsp + 0x38], rbp
000339fc  48894c2460               mov qword ptr [rsp + 0x60], rcx
00033a01  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033a05  44896c2430               mov dword ptr [rsp + 0x30], r13d
00033a0a  48895c2428               mov qword ptr [rsp + 0x28], rbx
00033a0f  4c89742420               mov qword ptr [rsp + 0x20], r14
00033a14  41ff5668                 call qword ptr [r14 + 0x68]
00033a18  85c0                     test eax, eax
00033a1a  0f844c080000             je 0x3426c
00033a20  4983ec01                 sub r12, 1
00033a24  0f8448090000             je 0x34372
00033a2a  48ff842480000000         inc qword ptr [rsp + 0x80]
00033a32  488d4501                 lea rax, [rbp + 1]
00033a36  48ff8c24a0000000         dec qword ptr [rsp + 0xa0]
00033a3e  488bcf                   mov rcx, rdi
00033a41  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
00033a49  48894c2460               mov qword ptr [rsp + 0x60], rcx
00033a4e  493bc1                   cmp rax, r9
00033a51  0f8306080000             jae 0x3425d
00033a57  488be8                   mov rbp, rax
00033a5a  e92bffffff               jmp 0x3398a
00033a5f  4889942490000000         mov qword ptr [rsp + 0x90], rdx
00033a67  4c89442478               mov qword ptr [rsp + 0x78], r8
00033a6c  e957090000               jmp 0x343c8
00033a71  33c9                     xor ecx, ecx
00033a73  488bd1                   mov rdx, rcx
00033a76  48898c2498000000         mov qword ptr [rsp + 0x98], rcx
00033a7e  c644245400               mov byte ptr [rsp + 0x54], 0
00033a83  85f6                     test esi, esi
00033a85  0f8e24090000             jle 0x343af
00033a8b  4d85ff                   test r15, r15
00033a8e  744a                     je 0x33ada
00033a90  0fb603                   movzx eax, byte ptr [rbx]
00033a93  413807                   cmp byte ptr [r15], al
00033a96  7542                     jne 0x33ada
00033a98  4d85e4                   test r12, r12
00033a9b  0f84580a0000             je 0x344f9
00033aa1  48ffc3                   inc rbx
00033aa4  ffce                     dec esi
00033aa6  85f6                     test esi, esi
00033aa8  0f8e4b0a0000             jle 0x344f9
00033aae  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
00033ab6  488d8c2408010000         lea rcx, [rsp + 0x108]
00033abe  ff9424e0000000           call qword ptr [rsp + 0xe0]
00033ac5  84c0                     test al, al
00033ac7  754d                     jne 0x33b16
00033ac9  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00033ad1  44896a14                 mov dword ptr [rdx + 0x14], r13d
00033ad5  e9a8000000               jmp 0x33b82
00033ada  0fb603                   movzx eax, byte ptr [rbx]
00033add  3c25                     cmp al, 0x25
00033adf  0f8492010000             je 0x33c77
00033ae5  4d85e4                   test r12, r12
00033ae8  0f840b0a0000             je 0x344f9
00033aee  3c5b                     cmp al, 0x5b
00033af0  0f848a010000             je 0x33c80
00033af6  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
00033afe  488d8c2408010000         lea rcx, [rsp + 0x108]
00033b06  ff9424e0000000           call qword ptr [rsp + 0xe0]
00033b0d  84c0                     test al, al
00033b0f  7462                     je 0x33b73
00033b11  803b5f                   cmp byte ptr [rbx], 0x5f
00033b14  743d                     je 0x33b53
00033b16  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
00033b1a  488d842408010000         lea rax, [rsp + 0x108]
00033b22  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
00033b26  418b5654                 mov edx, dword ptr [r14 + 0x54]
00033b2a  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033b2e  44896c2440               mov dword ptr [rsp + 0x40], r13d
00033b33  4889442438               mov qword ptr [rsp + 0x38], rax
00033b38  44896c2430               mov dword ptr [rsp + 0x30], r13d
00033b3d  48895c2428               mov qword ptr [rsp + 0x28], rbx
00033b42  4c89742420               mov qword ptr [rsp + 0x20], r14
00033b47  41ff5668                 call qword ptr [r14 + 0x68]
00033b4b  85c0                     test eax, eax
00033b4d  0f85a6090000             jne 0x344f9
00033b53  49ffcc                   dec r12
00033b56  498bd5                   mov rdx, r13
00033b59  48ffc3                   inc rbx
00033b5c  4889942498000000         mov qword ptr [rsp + 0x98], rdx
00033b64  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
00033b6c  ffce                     dec esi
00033b6e  e910ffffff               jmp 0x33a83
00033b73  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00033b7b  c7421402000000           mov dword ptr [rdx + 0x14], 2
00033b82  488b842498000000         mov rax, qword ptr [rsp + 0x98]
00033b8a  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
00033b91  4c8b842490000000         mov r8, qword ptr [rsp + 0x90]
00033b99  48894220                 mov qword ptr [rdx + 0x20], rax
00033b9d  8b442454                 mov eax, dword ptr [rsp + 0x54]
00033ba1  884228                   mov byte ptr [rdx + 0x28], al
00033ba4  488b8424a8000000         mov rax, qword ptr [rsp + 0xa8]
00033bac  48894230                 mov qword ptr [rdx + 0x30], rax
00033bb0  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
00033bb8  48894238                 mov qword ptr [rdx + 0x38], rax
00033bbc  488b842480000000         mov rax, qword ptr [rsp + 0x80]
00033bc4  48894240                 mov qword ptr [rdx + 0x40], rax
00033bc8  8b442470                 mov eax, dword ptr [rsp + 0x70]
00033bcc  894248                   mov dword ptr [rdx + 0x48], eax
00033bcf  488b8424b0000000         mov rax, qword ptr [rsp + 0xb0]
00033bd7  48894250                 mov qword ptr [rdx + 0x50], rax
00033bdb  488b442460               mov rax, qword ptr [rsp + 0x60]
00033be0  48894260                 mov qword ptr [rdx + 0x60], rax
00033be4  488b8424d0000000         mov rax, qword ptr [rsp + 0xd0]
00033bec  48894268                 mov qword ptr [rdx + 0x68], rax
00033bf0  8b842488000000           mov eax, dword ptr [rsp + 0x88]
00033bf7  894270                   mov dword ptr [rdx + 0x70], eax
00033bfa  0fb6442450               movzx eax, byte ptr [rsp + 0x50]
00033bff  884274                   mov byte ptr [rdx + 0x74], al
00033c02  488bc3                   mov rax, rbx
00033c05  482b8424b8000000         sub rax, qword ptr [rsp + 0xb8]
00033c0d  4885db                   test rbx, rbx
00033c10  897218                   mov dword ptr [rdx + 0x18], esi
00033c13  4c896208                 mov qword ptr [rdx + 8], r12
00033c17  480f44c1                 cmove rax, rcx
00033c1b  48897a58                 mov qword ptr [rdx + 0x58], rdi
00033c1f  488982c81f0000           mov qword ptr [rdx + 0x1fc8], rax
00033c26  498bc0                   mov rax, r8
00033c29  482b8424b8000000         sub rax, qword ptr [rsp + 0xb8]
00033c31  4d85c0                   test r8, r8
00033c34  4c8b442478               mov r8, qword ptr [rsp + 0x78]
00033c39  480f44c1                 cmove rax, rcx
00033c3d  488982d01f0000           mov qword ptr [rdx + 0x1fd0], rax
00033c44  498bc0                   mov rax, r8
00033c47  482b442468               sub rax, qword ptr [rsp + 0x68]
00033c4c  4d85c0                   test r8, r8
00033c4f  480f44c1                 cmove rax, rcx
00033c53  488982d81f0000           mov qword ptr [rdx + 0x1fd8], rax
00033c5a  488bc5                   mov rax, rbp
00033c5d  482b442468               sub rax, qword ptr [rsp + 0x68]
00033c62  4885ed                   test rbp, rbp
00033c65  480f44c1                 cmove rax, rcx
00033c69  488982e01f0000           mov qword ptr [rdx + 0x1fe0], rax
00033c70  32c0                     xor al, al
00033c72  e9d1080000               jmp 0x34548
00033c77  413bf5                   cmp esi, r13d
00033c7a  0f8493080000             je 0x34513
00033c80  4c8b9c24c8000000         mov r11, qword ptr [rsp + 0xc8]
00033c88  33c9                     xor ecx, ecx
00033c8a  4d8bc5                   mov r8, r13
00033c8d  4c89ac2480000000         mov qword ptr [rsp + 0x80], r13
00033c95  48898c2490000000         mov qword ptr [rsp + 0x90], rcx
00033c9d  8bf9                     mov edi, ecx
00033c9f  48894c2460               mov qword ptr [rsp + 0x60], rcx
00033ca4  418b83c01f0000           mov eax, dword ptr [r11 + 0x1fc0]
00033cab  48898c24a0000000         mov qword ptr [rsp + 0xa0], rcx
00033cb3  48898c24a8000000         mov qword ptr [rsp + 0xa8], rcx
00033cbb  89b42488000000           mov dword ptr [rsp + 0x88], esi
00033cc2  3bf0                     cmp esi, eax
00033cc4  0f87d7080000             ja 0x345a1
00033cca  4d8b93b81f0000           mov r10, qword ptr [r11 + 0x1fb8]
00033cd1  4c89542468               mov qword ptr [rsp + 0x68], r10
00033cd6  498bea                   mov rbp, r10
00033cd9  4d8d0c02                 lea r9, [r10 + rax]
00033cdd  4c898c24d8000000         mov qword ptr [rsp + 0xd8], r9
00033ce5  85f6                     test esi, esi
00033ce7  0f8e6c040000             jle 0x34159
00033ced  4d85ff                   test r15, r15
00033cf0  0f840f010000             je 0x33e05
00033cf6  0fb603                   movzx eax, byte ptr [rbx]
00033cf9  413807                   cmp byte ptr [r15], al
00033cfc  0f8503010000             jne 0x33e05
00033d02  4d85e4                   test r12, r12
00033d05  0f8467060000             je 0x34372
00033d0b  48ffc3                   inc rbx
00033d0e  ffce                     dec esi
00033d10  85f6                     test esi, esi
00033d12  0f8ee1070000             jle 0x344f9
00033d18  488b442460               mov rax, qword ptr [rsp + 0x60]
00033d1d  483bc7                   cmp rax, rdi
00033d20  754f                     jne 0x33d71
00033d22  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
00033d2a  488bcd                   mov rcx, rbp
00033d2d  ff9424e0000000           call qword ptr [rsp + 0xe0]
00033d34  84c0                     test al, al
00033d36  0f84a4050000             je 0x342e0
00033d3c  8b442454                 mov eax, dword ptr [rsp + 0x54]
00033d40  48ffc7                   inc rdi
00033d43  4889bc24a0000000         mov qword ptr [rsp + 0xa0], rdi
00033d4b  84c0                     test al, al
00033d4d  741d                     je 0x33d6c
00033d4f  4c3ba424a8000000         cmp r12, qword ptr [rsp + 0xa8]
00033d57  7713                     ja 0x33d6c
00033d59  807d0020                 cmp byte ptr [rbp], 0x20
00033d5d  b900000000               mov ecx, 0
00033d62  0fb6c0                   movzx eax, al
00033d65  0f45c1                   cmovne eax, ecx
00033d68  89442454                 mov dword ptr [rsp + 0x54], eax
00033d6c  488b442460               mov rax, qword ptr [rsp + 0x60]
00033d71  48ffc0                   inc rax
00033d74  4889442460               mov qword ptr [rsp + 0x60], rax
00033d79  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
00033d7d  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
00033d81  418b5654                 mov edx, dword ptr [r14 + 0x54]
00033d85  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033d89  44896c2440               mov dword ptr [rsp + 0x40], r13d
00033d8e  48896c2438               mov qword ptr [rsp + 0x38], rbp
00033d93  44896c2430               mov dword ptr [rsp + 0x30], r13d
00033d98  48895c2428               mov qword ptr [rsp + 0x28], rbx
00033d9d  4c89742420               mov qword ptr [rsp + 0x20], r14
00033da2  41ff5668                 call qword ptr [r14 + 0x68]
00033da6  85c0                     test eax, eax
00033da8  0f8599020000             jne 0x34047
00033dae  488b942498000000         mov rdx, qword ptr [rsp + 0x98]
00033db6  4c8b842480000000         mov r8, qword ptr [rsp + 0x80]
00033dbe  4885d2                   test rdx, rdx
00033dc1  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
00033dc9  498bc0                   mov rax, r8
00033dcc  4c8b542468               mov r10, qword ptr [rsp + 0x68]
00033dd1  480f45c2                 cmovne rax, rdx
00033dd5  488bd0                   mov rdx, rax
00033dd8  4889842498000000         mov qword ptr [rsp + 0x98], rax
00033de0  488d4501                 lea rax, [rbp + 1]
00033de4  493bc1                   cmp rax, r9
00033de7  0f83f7020000             jae 0x340e4
00033ded  49ffcc                   dec r12
00033df0  48ffc3                   inc rbx
00033df3  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
00033dfb  ffce                     dec esi
00033dfd  488be8                   mov rbp, rax
00033e00  e9e0feffff               jmp 0x33ce5
00033e05  803b25                   cmp byte ptr [rbx], 0x25
00033e08  0f84f3020000             je 0x34101
00033e0e  4d85e4                   test r12, r12
00033e11  0f845b050000             je 0x34372
00033e17  488b442460               mov rax, qword ptr [rsp + 0x60]
00033e1c  483bc7                   cmp rax, rdi
00033e1f  754f                     jne 0x33e70
00033e21  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
00033e29  488bcd                   mov rcx, rbp
00033e2c  ff9424e0000000           call qword ptr [rsp + 0xe0]
00033e33  84c0                     test al, al
00033e35  0f84b9040000             je 0x342f4
00033e3b  8b4c2454                 mov ecx, dword ptr [rsp + 0x54]
00033e3f  48ffc7                   inc rdi
00033e42  4889bc24a0000000         mov qword ptr [rsp + 0xa0], rdi
00033e4a  84c9                     test cl, cl
00033e4c  741d                     je 0x33e6b
00033e4e  4c3ba424a8000000         cmp r12, qword ptr [rsp + 0xa8]
00033e56  7713                     ja 0x33e6b
00033e58  807d0020                 cmp byte ptr [rbp], 0x20
00033e5c  0fb6c1                   movzx eax, cl
00033e5f  b900000000               mov ecx, 0
00033e64  0f45c1                   cmovne eax, ecx
00033e67  88442454                 mov byte ptr [rsp + 0x54], al
00033e6b  488b442460               mov rax, qword ptr [rsp + 0x60]
00033e70  48ffc0                   inc rax
00033e73  4889442460               mov qword ptr [rsp + 0x60], rax
00033e78  0fb603                   movzx eax, byte ptr [rbx]
00033e7b  3c5f                     cmp al, 0x5f
00033e7d  0f842bffffff             je 0x33dae
00033e83  3c5b                     cmp al, 0x5b
00033e85  0f85eefeffff             jne 0x33d79
00033e8b  488d7b01                 lea rdi, [rbx + 1]
00033e8f  90                       nop
00033e90  48ffc3                   inc rbx
00033e93  ffce                     dec esi
00033e95  85f6                     test esi, esi
00033e97  0f8e5c060000             jle 0x344f9
00033e9d  4d85ff                   test r15, r15
00033ea0  7426                     je 0x33ec8
00033ea2  0fb603                   movzx eax, byte ptr [rbx]
00033ea5  413807                   cmp byte ptr [r15], al
00033ea8  751e                     jne 0x33ec8
00033eaa  48ffc3                   inc rbx
00033ead  ffce                     dec esi
00033eaf  85f6                     test esi, esi
00033eb1  7fdd                     jg 0x33e90
00033eb3  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00033ebb  32c0                     xor al, al
00033ebd  66c742100100             mov word ptr [rdx + 0x10], 1
00033ec3  e980060000               jmp 0x34548
00033ec8  803b5d                   cmp byte ptr [rbx], 0x5d
00033ecb  75c3                     jne 0x33e90
00033ecd  32c9                     xor cl, cl
00033ecf  448beb                   mov r13d, ebx
00033ed2  442bef                   sub r13d, edi
00033ed5  884c2458                 mov byte ptr [rsp + 0x58], cl
00033ed9  4585ed                   test r13d, r13d
00033edc  0f8e47010000             jle 0x34029
00033ee2  803f5e                   cmp byte ptr [rdi], 0x5e
00033ee5  7529                     jne 0x33f10
00033ee7  4d85ff                   test r15, r15
00033eea  7406                     je 0x33ef2
00033eec  41803f5e                 cmp byte ptr [r15], 0x5e
00033ef0  741e                     je 0x33f10
00033ef2  418d45ff                 lea eax, [r13 - 1]
00033ef6  48ffc7                   inc rdi
00033ef9  b101                     mov cl, 1
00033efb  448be8                   mov r13d, eax
00033efe  884c2458                 mov byte ptr [rsp + 0x58], cl
00033f02  85c0                     test eax, eax
00033f04  0f8e1f010000             jle 0x34029
00033f0a  660f1f440000             nop word ptr [rax + rax]
00033f10  4d85ff                   test r15, r15
00033f13  740d                     je 0x33f22
00033f15  0fb607                   movzx eax, byte ptr [rdi]
00033f18  413807                   cmp byte ptr [r15], al
00033f1b  7505                     jne 0x33f22
00033f1d  41b401                   mov r12b, 1
00033f20  eb03                     jmp 0x33f25
00033f22  4532e4                   xor r12b, r12b
00033f25  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
00033f29  488d4701                 lea rax, [rdi + 1]
00033f2d  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
00033f31  b901000000               mov ecx, 1
00033f36  418b5654                 mov edx, dword ptr [r14 + 0x54]
00033f3a  4584e4                   test r12b, r12b
00033f3d  894c2440                 mov dword ptr [rsp + 0x40], ecx
00033f41  480f44c7                 cmove rax, rdi
00033f45  4889442438               mov qword ptr [rsp + 0x38], rax
00033f4a  894c2430                 mov dword ptr [rsp + 0x30], ecx
00033f4e  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033f52  48896c2428               mov qword ptr [rsp + 0x28], rbp
00033f57  4c89742420               mov qword ptr [rsp + 0x20], r14
00033f5c  48898424f8000000         mov qword ptr [rsp + 0xf8], rax
00033f64  41ff5668                 call qword ptr [r14 + 0x68]
00033f68  4c8b8424f8000000         mov r8, qword ptr [rsp + 0xf8]
00033f70  418d4dff                 lea ecx, [r13 - 1]
00033f74  4584e4                   test r12b, r12b
00033f77  8bd0                     mov edx, eax
00033f79  410f44cd                 cmove ecx, r13d
00033f7d  498d7801                 lea rdi, [r8 + 1]
00033f81  448d69ff                 lea r13d, [rcx - 1]
00033f85  4183fd01                 cmp r13d, 1
00033f89  0f8e84000000             jle 0x34013
00033f8f  803f2d                   cmp byte ptr [rdi], 0x2d
00033f92  757f                     jne 0x34013
00033f94  4d85ff                   test r15, r15
00033f97  7406                     je 0x33f9f
00033f99  41803f2d                 cmp byte ptr [r15], 0x2d
00033f9d  7474                     je 0x34013
00033f9f  458d65ff                 lea r12d, [r13 - 1]
00033fa3  4d85ff                   test r15, r15
00033fa6  740d                     je 0x33fb5
00033fa8  0fb64701                 movzx eax, byte ptr [rdi + 1]
00033fac  413807                   cmp byte ptr [r15], al
00033faf  7504                     jne 0x33fb5
00033fb1  b001                     mov al, 1
00033fb3  eb02                     jmp 0x33fb7
00033fb5  32c0                     xor al, al
00033fb7  84c0                     test al, al
00033fb9  490f44f8                 cmove rdi, r8
00033fbd  4883c702                 add rdi, 2
00033fc1  84c0                     test al, al
00033fc3  450f44e5                 cmove r12d, r13d
00033fc7  85d2                     test edx, edx
00033fc9  783e                     js 0x34009
00033fcb  0faee8                   lfence
00033fce  458b4e50                 mov r9d, dword ptr [r14 + 0x50]
00033fd2  41bd01000000             mov r13d, 1
00033fd8  4d8b4648                 mov r8, qword ptr [r14 + 0x48]
00033fdc  418b5654                 mov edx, dword ptr [r14 + 0x54]
00033fe0  498b4e40                 mov rcx, qword ptr [r14 + 0x40]
00033fe4  44896c2440               mov dword ptr [rsp + 0x40], r13d
00033fe9  48897c2438               mov qword ptr [rsp + 0x38], rdi
00033fee  44896c2430               mov dword ptr [rsp + 0x30], r13d
00033ff3  48896c2428               mov qword ptr [rsp + 0x28], rbp
00033ff8  4c89742420               mov qword ptr [rsp + 0x20], r14
00033ffd  41ff5668                 call qword ptr [r14 + 0x68]
00034001  85c0                     test eax, eax
00034003  0f8ec1000000             jle 0x340ca
00034009  48ffc7                   inc rdi
0003400c  458d6c24fe               lea r13d, [r12 - 2]
00034011  eb08                     jmp 0x3401b
00034013  85d2                     test edx, edx
00034015  0f84bc000000             je 0x340d7
0003401b  4585ed                   test r13d, r13d
0003401e  0f8fecfeffff             jg 0x33f10
00034024  0fb64c2458               movzx ecx, byte ptr [rsp + 0x58]
00034029  41bd01000000             mov r13d, 1
0003402f  4c8ba42480010000         mov r12, qword ptr [rsp + 0x180]
00034037  488bbc24a0000000         mov rdi, qword ptr [rsp + 0xa0]
0003403f  84c9                     test cl, cl
00034041  0f8567fdffff             jne 0x33dae
00034047  488b942498000000         mov rdx, qword ptr [rsp + 0x98]
0003404f  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
00034057  4c8b842480000000         mov r8, qword ptr [rsp + 0x80]
0003405f  4c8b542468               mov r10, qword ptr [rsp + 0x68]
00034064  8b442454                 mov eax, dword ptr [rsp + 0x54]
00034068  0fb68c24a8010000         movzx ecx, byte ptr [rsp + 0x1a8]
00034070  4c8b9c2490000000         mov r11, qword ptr [rsp + 0x90]
00034078  4d85db                   test r11, r11
0003407b  0f8424030000             je 0x343a5
00034081  488b9c24b0000000         mov rbx, qword ptr [rsp + 0xb0]
00034089  49ffc0                   inc r8
0003408c  4883fb01                 cmp rbx, 1
00034090  4c89842480000000         mov qword ptr [rsp + 0x80], r8
00034098  4c8b442478               mov r8, qword ptr [rsp + 0x78]
0003409d  8bc3                     mov eax, ebx
0003409f  410f47c5                 cmova eax, r13d
000340a3  8bc8                     mov ecx, eax
000340a5  482bd9                   sub rbx, rcx
000340a8  48899c24b0000000         mov qword ptr [rsp + 0xb0], rbx
000340b0  4a8d1400                 lea rdx, [rax + r8]
000340b4  493bd1                   cmp rdx, r9
000340b7  0f8317010000             jae 0x341d4
000340bd  4c8bc2                   mov r8, rdx
000340c0  4889542478               mov qword ptr [rsp + 0x78], rdx
000340c5  e918010000               jmp 0x341e2
000340ca  0fb64c2458               movzx ecx, byte ptr [rsp + 0x58]
000340cf  4132cd                   xor cl, r13b
000340d2  e958ffffff               jmp 0x3402f
000340d7  0fb64c2458               movzx ecx, byte ptr [rsp + 0x58]
000340dc  80f101                   xor cl, 1
000340df  e945ffffff               jmp 0x34029
000340e4  412be9                   sub ebp, r9d
000340e7  49ffcc                   dec r12
000340ea  ffc5                     inc ebp
000340ec  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
000340f4  4903ea                   add rbp, r10
000340f7  48ffc3                   inc rbx
000340fa  ffce                     dec esi
000340fc  e9e4fbffff               jmp 0x33ce5
00034101  48ffc3                   inc rbx
00034104  83ee01                   sub esi, 1
00034107  0f8406040000             je 0x34513
0003410d  803b25                   cmp byte ptr [rbx], 0x25
00034110  74ef                     je 0x34101
00034112  0fb60b                   movzx ecx, byte ptr [rbx]
00034115  4533db                   xor r11d, r11d
00034118  418bfb                   mov edi, r11d
0003411b  4c899c24a0000000         mov qword ptr [rsp + 0xa0], r11
00034123  498bea                   mov rbp, r10
00034126  48899c2490000000         mov qword ptr [rsp + 0x90], rbx
0003412e  89742470                 mov dword ptr [rsp + 0x70], esi
00034132  8d41a5                   lea eax, [rcx - 0x5b]
00034135  a8fb                     test al, 0xfb
00034137  7415                     je 0x3414e
00034139  4d85ff                   test r15, r15
0003413c  7405                     je 0x34143
0003413e  41380f                   cmp byte ptr [r15], cl
00034141  740b                     je 0x3414e
00034143  b001                     mov al, 1
00034145  88442450                 mov byte ptr [rsp + 0x50], al
00034149  e9d4000000               jmp 0x34222
0003414e  32c0                     xor al, al
00034150  88442450                 mov byte ptr [rsp + 0x50], al
00034154  e9c9000000               jmp 0x34222
00034159  4d85e4                   test r12, r12
0003415c  0f84b1030000             je 0x34513
00034162  0fb68c24a8010000         movzx ecx, byte ptr [rsp + 0x1a8]
0003416a  8b442454                 mov eax, dword ptr [rsp + 0x54]
0003416e  84c9                     test cl, cl
00034170  0f84fafeffff             je 0x34070
00034176  84c0                     test al, al
00034178  0f85f2feffff             jne 0x34070
0003417e  4883bc24e000000000       cmp qword ptr [rsp + 0xe0], 0
00034187  7530                     jne 0x341b9
00034189  4c8b9c2400010000         mov r11, qword ptr [rsp + 0x100]
00034191  498bcc                   mov rcx, r12
00034194  498bc3                   mov rax, r11
00034197  41803b20                 cmp byte ptr [r11], 0x20
0003419b  0f85c3feffff             jne 0x34064
000341a1  488d4001                 lea rax, [rax + 1]
000341a5  4883e901                 sub rcx, 1
000341a9  0f8464030000             je 0x34513
000341af  803820                   cmp byte ptr [rax], 0x20
000341b2  74ed                     je 0x341a1
000341b4  e9abfeffff               jmp 0x34064
000341b9  b001                     mov al, 1
000341bb  4c89a424a8000000         mov qword ptr [rsp + 0xa8], r12
000341c3  89442454                 mov dword ptr [rsp + 0x54], eax
000341c7  48899424c0000000         mov qword ptr [rsp + 0xc0], rdx
000341cf  e99cfeffff               jmp 0x34070
000341d4  452bc1                   sub r8d, r9d
000341d7  4403c0                   add r8d, eax
000341da  4d03c2                   add r8, r10
000341dd  4c89442478               mov qword ptr [rsp + 0x78], r8
000341e2  488b8424d0000000         mov rax, qword ptr [rsp + 0xd0]
000341ea  482bf9                   sub rdi, rcx
000341ed  8b742470                 mov esi, dword ptr [rsp + 0x70]
000341f1  488bd0                   mov rdx, rax
000341f4  4889842498000000         mov qword ptr [rsp + 0x98], rax
000341fc  498be8                   mov rbp, r8
000341ff  0fb6442450               movzx eax, byte ptr [rsp + 0x50]
00034204  4c8be3                   mov r12, rbx
00034207  4c8b842480000000         mov r8, qword ptr [rsp + 0x80]
0003420f  48899c2480010000         mov qword ptr [rsp + 0x180], rbx
00034217  498bdb                   mov rbx, r11
0003421a  4889bc24a0000000         mov qword ptr [rsp + 0xa0], rdi
00034222  4d85e4                   test r12, r12
00034225  0f8447010000             je 0x34372
0003422b  4533db                   xor r11d, r11d
0003422e  48899424d0000000         mov qword ptr [rsp + 0xd0], rdx
00034236  418bcb                   mov ecx, r11d
00034239  48894c2460               mov qword ptr [rsp + 0x60], rcx
0003423e  84c0                     test al, al
00034240  0f8544f7ffff             jne 0x3398a
00034246  48896c2478               mov qword ptr [rsp + 0x78], rbp
0003424b  4c89a424b0000000         mov qword ptr [rsp + 0xb0], r12
00034253  4c895c2460               mov qword ptr [rsp + 0x60], r11
00034258  e988faffff               jmp 0x33ce5
0003425d  412be9                   sub ebp, r9d
00034260  ffc5                     inc ebp
00034262  48036c2468               add rbp, qword ptr [rsp + 0x68]
00034267  e91ef7ffff               jmp 0x3398a
0003426c  488b942498000000         mov rdx, qword ptr [rsp + 0x98]
00034274  4c8bc5                   mov r8, rbp
00034277  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
0003427f  4885d2                   test rdx, rdx
00034282  4c8b542468               mov r10, qword ptr [rsp + 0x68]
00034287  480f44942480000000       cmove rdx, qword ptr [rsp + 0x80]
00034290  48896c2478               mov qword ptr [rsp + 0x78], rbp
00034295  48ffc5                   inc rbp
00034298  4c89a424b0000000         mov qword ptr [rsp + 0xb0], r12
000342a0  4889942498000000         mov qword ptr [rsp + 0x98], rdx
000342a8  493be9                   cmp rbp, r9
000342ab  720e                     jb 0x342bb
000342ad  498be8                   mov rbp, r8
000342b0  492be9                   sub rbp, r9
000342b3  48ffc5                   inc rbp
000342b6  8bed                     mov ebp, ebp
000342b8  4903ea                   add rbp, r10
000342bb  488bbc24a0000000         mov rdi, qword ptr [rsp + 0xa0]
000342c3  49ffcc                   dec r12
000342c6  4c8b842480000000         mov r8, qword ptr [rsp + 0x80]
000342ce  48ffc3                   inc rbx
000342d1  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
000342d9  ffce                     dec esi
000342db  e905faffff               jmp 0x33ce5
000342e0  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
000342e8  c7421403000000           mov dword ptr [rdx + 0x14], 3
000342ef  e911010000               jmp 0x34405
000342f4  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
000342fc  c7421404000000           mov dword ptr [rdx + 0x14], 4
00034303  e9fd000000               jmp 0x34405
00034308  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00034310  488b842498000000         mov rax, qword ptr [rsp + 0x98]
00034318  48894220                 mov qword ptr [rdx + 0x20], rax
0003431c  8b442454                 mov eax, dword ptr [rsp + 0x54]
00034320  884228                   mov byte ptr [rdx + 0x28], al
00034323  488b8424a8000000         mov rax, qword ptr [rsp + 0xa8]
0003432b  48894230                 mov qword ptr [rdx + 0x30], rax
0003432f  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
00034337  48894238                 mov qword ptr [rdx + 0x38], rax
0003433b  488b842480000000         mov rax, qword ptr [rsp + 0x80]
00034343  48894240                 mov qword ptr [rdx + 0x40], rax
00034347  8b442470                 mov eax, dword ptr [rsp + 0x70]
0003434b  894248                   mov dword ptr [rdx + 0x48], eax
0003434e  488b8424b0000000         mov rax, qword ptr [rsp + 0xb0]
00034356  48894250                 mov qword ptr [rdx + 0x50], rax
0003435a  488b8424a0000000         mov rax, qword ptr [rsp + 0xa0]
00034362  48894258                 mov qword ptr [rdx + 0x58], rax
00034366  c7421405000000           mov dword ptr [rdx + 0x14], 5
0003436d  e9e1000000               jmp 0x34453
00034372  807c245400               cmp byte ptr [rsp + 0x54], 0
00034377  0f847c010000             je 0x344f9
0003437d  488b8c24f0000000         mov rcx, qword ptr [rsp + 0xf0]
00034385  4885c9                   test rcx, rcx
00034388  0f84aa010000             je 0x34538
0003438e  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
00034396  4885c0                   test rax, rax
00034399  4c0f45e8                 cmovne r13, rax
0003439d  4c8929                   mov qword ptr [rcx], r13
000343a0  e993010000               jmp 0x34538
000343a5  84c0                     test al, al
000343a7  0f844c010000             je 0x344f9
000343ad  eb08                     jmp 0x343b7
000343af  0fb68c24a8010000         movzx ecx, byte ptr [rsp + 0x1a8]
000343b7  84c9                     test cl, cl
000343b9  0f8435010000             je 0x344f4
000343bf  4d85e4                   test r12, r12
000343c2  0f8443010000             je 0x3450b
000343c8  488b9424e8000000         mov rdx, qword ptr [rsp + 0xe8]
000343d0  488d8c240c010000         lea rcx, [rsp + 0x10c]
000343d8  ff9424e0000000           call qword ptr [rsp + 0xe0]
000343df  84c0                     test al, al
000343e1  7413                     je 0x343f6
000343e3  80bc240c01000020         cmp byte ptr [rsp + 0x10c], 0x20
000343eb  0f8508010000             jne 0x344f9
000343f1  49ffcc                   dec r12
000343f4  ebc9                     jmp 0x343bf
000343f6  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
000343fe  c7421406000000           mov dword ptr [rdx + 0x14], 6
00034405  488b842498000000         mov rax, qword ptr [rsp + 0x98]
0003440d  48894220                 mov qword ptr [rdx + 0x20], rax
00034411  8b442454                 mov eax, dword ptr [rsp + 0x54]
00034415  884228                   mov byte ptr [rdx + 0x28], al
00034418  488b8424a8000000         mov rax, qword ptr [rsp + 0xa8]
00034420  48894230                 mov qword ptr [rdx + 0x30], rax
00034424  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
0003442c  48894238                 mov qword ptr [rdx + 0x38], rax
00034430  488b842480000000         mov rax, qword ptr [rsp + 0x80]
00034438  48894240                 mov qword ptr [rdx + 0x40], rax
0003443c  8b442470                 mov eax, dword ptr [rsp + 0x70]
00034440  894248                   mov dword ptr [rdx + 0x48], eax
00034443  488b8424b0000000         mov rax, qword ptr [rsp + 0xb0]
0003444b  48894250                 mov qword ptr [rdx + 0x50], rax
0003444f  48897a58                 mov qword ptr [rdx + 0x58], rdi
00034453  488b442460               mov rax, qword ptr [rsp + 0x60]
00034458  48c7c1ffffffff           mov rcx, 0xffffffffffffffff
0003445f  4c8b8c24b8000000         mov r9, qword ptr [rsp + 0xb8]
00034467  48894260                 mov qword ptr [rdx + 0x60], rax
0003446b  488b8424d0000000         mov rax, qword ptr [rsp + 0xd0]
00034473  48894268                 mov qword ptr [rdx + 0x68], rax
00034477  8b842488000000           mov eax, dword ptr [rsp + 0x88]
0003447e  894270                   mov dword ptr [rdx + 0x70], eax
00034481  0fb6442450               movzx eax, byte ptr [rsp + 0x50]
00034486  884274                   mov byte ptr [rdx + 0x74], al
00034489  4c896208                 mov qword ptr [rdx + 8], r12
0003448d  897218                   mov dword ptr [rdx + 0x18], esi
00034490  4885db                   test rbx, rbx
00034493  7505                     jne 0x3449a
00034495  488bd9                   mov rbx, rcx
00034498  eb03                     jmp 0x3449d
0003449a  492bd9                   sub rbx, r9
0003449d  488b842490000000         mov rax, qword ptr [rsp + 0x90]
000344a5  48899ac81f0000           mov qword ptr [rdx + 0x1fc8], rbx
000344ac  4885c0                   test rax, rax
000344af  7505                     jne 0x344b6
000344b1  488bc1                   mov rax, rcx
000344b4  eb03                     jmp 0x344b9
000344b6  492bc1                   sub rax, r9
000344b9  4c8b442468               mov r8, qword ptr [rsp + 0x68]
000344be  488982d01f0000           mov qword ptr [rdx + 0x1fd0], rax
000344c5  488b442478               mov rax, qword ptr [rsp + 0x78]
000344ca  4885c0                   test rax, rax
000344cd  7505                     jne 0x344d4
000344cf  488bc1                   mov rax, rcx
000344d2  eb03                     jmp 0x344d7
000344d4  492bc0                   sub rax, r8
000344d7  488982d81f0000           mov qword ptr [rdx + 0x1fd8], rax
000344de  4885ed                   test rbp, rbp
000344e1  7406                     je 0x344e9
000344e3  488bcd                   mov rcx, rbp
000344e6  492bc8                   sub rcx, r8
000344e9  48898ae01f0000           mov qword ptr [rdx + 0x1fe0], rcx
000344f0  32c0                     xor al, al
000344f2  eb54                     jmp 0x34548
000344f4  4d85e4                   test r12, r12
000344f7  741a                     je 0x34513
000344f9  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00034501  32c0                     xor al, al
00034503  66c742100100             mov word ptr [rdx + 0x10], 1
00034509  eb3d                     jmp 0x34548
0003450b  488b942498000000         mov rdx, qword ptr [rsp + 0x98]
00034513  488b8c24f0000000         mov rcx, qword ptr [rsp + 0xf0]
0003451b  4885c9                   test rcx, rcx
0003451e  7418                     je 0x34538
00034520  807c245400               cmp byte ptr [rsp + 0x54], 0
00034525  480f459424c0000000       cmovne rdx, qword ptr [rsp + 0xc0]
0003452e  4885d2                   test rdx, rdx
00034531  490f44d5                 cmove rdx, r13
00034535  488911                   mov qword ptr [rcx], rdx
00034538  488b9424c8000000         mov rdx, qword ptr [rsp + 0xc8]
00034540  b001                     mov al, 1
00034542  66c742100101             mov word ptr [rdx + 0x10], 0x101
00034548  4c8ba42428010000         mov r12, qword ptr [rsp + 0x128]
00034550  488bbc2430010000         mov rdi, qword ptr [rsp + 0x130]
00034558  488bac2478010000         mov rbp, qword ptr [rsp + 0x178]
00034560  4c8bac2420010000         mov r13, qword ptr [rsp + 0x120]
00034568  488b8c2410010000         mov rcx, qword ptr [rsp + 0x110]
00034570  4833cc                   xor rcx, rsp
00034573  e8f8880200               call 0x5ce70
00034578  4881c438010000           add rsp, 0x138
0003457f  415f                     pop r15
00034581  415e                     pop r14
00034583  5e                       pop rsi
00034584  5b                       pop rbx
00034585  c3                       ret

; chunk at RVA 0x34586 (27 bytes)
00034586  ba4b000000               mov edx, 0x4b
0003458b  4489442420               mov dword ptr [rsp + 0x20], r8d
00034590  8d4ad0                   lea ecx, [rdx - 0x30]
00034593  448d4ab6                 lea r9d, [rdx - 0x4a]
00034597  448d42c5                 lea r8d, [rdx - 0x3b]
0003459b  e8a04efeff               call 0x19440
000345a0  cc                       int3

; chunk at RVA 0x345a1 (59 bytes)
000345a1  48894c2420               mov qword ptr [rsp + 0x20], rcx
000345a6  4c8d0523a80600           lea r8, [rip + 0x6a823]
000345ad  418bcd                   mov ecx, r13d
000345b0  488d1571b40600           lea rdx, [rip + 0x6b471]
000345b7  41b9d8040000             mov r9d, 0x4d8
000345bd  e85e4efeff               call 0x19420
000345c2  cc                       int3
000345c3  90                       nop
