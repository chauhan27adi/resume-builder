; std::unique_ptr<unsigned char,MemObjArrayDeleter>::~unique_ptr<unsigned char,MemObjArrayDeleter>
; aetm_enclave.dll, primary RVA 0x11100, 37 bytes in 1 chunk(s)

; chunk at RVA 0x11100 (37 bytes)
00011100  4883ec38                 sub rsp, 0x38
00011104  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0001110d  488b5110                 mov rdx, qword ptr [rcx + 0x10]
00011111  4885d2                   test rdx, rdx
00011114  740a                     je 0x11120
00011116  488b09                   mov rcx, qword ptr [rcx]
00011119  488b01                   mov rax, qword ptr [rcx]
0001111c  ff5028                   call qword ptr [rax + 0x28]
0001111f  90                       nop
00011120  4883c438                 add rsp, 0x38
00011124  c3                       ret
