; CMemBufFormatter::~CMemBufFormatter
; aetm_enclave.dll, primary RVA 0x40c90, 173 bytes in 3 chunk(s)

; chunk at RVA 0x40c90 (30 bytes)
00040c90  4889742418               mov qword ptr [rsp + 0x18], rsi
00040c95  57                       push rdi
00040c96  4883ec20                 sub rsp, 0x20
00040c9a  488b5118                 mov rdx, qword ptr [rcx + 0x18]
00040c9e  488d7910                 lea rdi, [rcx + 0x10]
00040ca2  488bf1                   mov rsi, rcx
00040ca5  483bd7                   cmp rdx, rdi
00040ca8  0f8484000000             je 0x40d32

; chunk at RVA 0x40cae (132 bytes)
00040cae  48895c2430               mov qword ptr [rsp + 0x30], rbx
00040cb3  48896c2438               mov qword ptr [rsp + 0x38], rbp
00040cb8  33ed                     xor ebp, ebp
00040cba  660f1f440000             nop word ptr [rax + rax]
00040cc0  4885d2                   test rdx, rdx
00040cc3  488d42f8                 lea rax, [rdx - 8]
00040cc7  488bdd                   mov rbx, rbp
00040cca  480f45d8                 cmovne rbx, rax
00040cce  488b4308                 mov rax, qword ptr [rbx + 8]
00040cd2  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
00040cd6  48894808                 mov qword ptr [rax + 8], rcx
00040cda  488901                   mov qword ptr [rcx], rax
00040cdd  48896b10                 mov qword ptr [rbx + 0x10], rbp
00040ce1  48896b08                 mov qword ptr [rbx + 8], rbp
00040ce5  40386e28                 cmp byte ptr [rsi + 0x28], bpl
00040ce9  741f                     je 0x40d0a
00040ceb  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
00040cef  488b01                   mov rax, qword ptr [rcx]
00040cf2  ff5050                   call qword ptr [rax + 0x50]
00040cf5  41b801000000             mov r8d, 1
00040cfb  488bd3                   mov rdx, rbx
00040cfe  488bc8                   mov rcx, rax
00040d01  4c8b08                   mov r9, qword ptr [rax]
00040d04  41ff5110                 call qword ptr [r9 + 0x10]
00040d08  eb15                     jmp 0x40d1f
00040d0a  488b0b                   mov rcx, qword ptr [rbx]
00040d0d  e8cac10100               call 0x5cedc
00040d12  ba18000000               mov edx, 0x18
00040d17  488bcb                   mov rcx, rbx
00040d1a  e8d1c20100               call 0x5cff0
00040d1f  488b5708                 mov rdx, qword ptr [rdi + 8]
00040d23  483bd7                   cmp rdx, rdi
00040d26  7598                     jne 0x40cc0
00040d28  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
00040d2d  488b5c2430               mov rbx, qword ptr [rsp + 0x30]

; chunk at RVA 0x40d32 (11 bytes)
00040d32  488b742440               mov rsi, qword ptr [rsp + 0x40]
00040d37  4883c420                 add rsp, 0x20
00040d3b  5f                       pop rdi
00040d3c  c3                       ret
