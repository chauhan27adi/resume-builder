; `CEsRuntime::Startup'::`1'::dtor$0
; aetm_enclave.dll, primary RVA 0x618a0, 28 bytes in 1 chunk(s)

; chunk at RVA 0x618a0 (28 bytes)
000618a0  4055                     push rbp
000618a2  4883ec20                 sub rsp, 0x20
000618a6  488bea                   mov rbp, rdx
000618a9  488b5578                 mov rdx, qword ptr [rbp + 0x78]
000618ad  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
000618b1  e8ca80fbff               call 0x19980
000618b6  4883c420                 add rsp, 0x20
000618ba  5d                       pop rbp
000618bb  c3                       ret
