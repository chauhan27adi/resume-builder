; CTrustedMachine::AddVerifiedCEK
; aetm_enclave.dll, primary RVA 0xee50, 935 bytes in 1 chunk(s)

; chunk at RVA 0xee50 (935 bytes)
0000ee50  488bc4                   mov rax, rsp
0000ee53  57                       push rdi
0000ee54  4154                     push r12
0000ee56  4155                     push r13
0000ee58  4156                     push r14
0000ee5a  4157                     push r15
0000ee5c  4881ec80000000           sub rsp, 0x80
0000ee63  48c740a0feffffff         mov qword ptr [rax - 0x60], 0xfffffffffffffffe
0000ee6b  48895810                 mov qword ptr [rax + 0x10], rbx
0000ee6f  48896818                 mov qword ptr [rax + 0x18], rbp
0000ee73  48897020                 mov qword ptr [rax + 0x20], rsi
0000ee77  488b058ac10900           mov rax, qword ptr [rip + 0x9c18a]
0000ee7e  4833c4                   xor rax, rsp
0000ee81  4889442470               mov qword ptr [rsp + 0x70], rax
0000ee86  4d8be9                   mov r13, r9
0000ee89  4489442424               mov dword ptr [rsp + 0x24], r8d
0000ee8e  6689542420               mov word ptr [rsp + 0x20], dx
0000ee93  4c8be1                   mov r12, rcx
0000ee96  4c8bbc24d0000000         mov r15, qword ptr [rsp + 0xd0]
0000ee9e  488da9c0da4700           lea rbp, [rcx + 0x47dac0]
0000eea5  4c8bd5                   mov r10, rbp
0000eea8  4c8d99c0da5000           lea r11, [rcx + 0x50dac0]
0000eeaf  90                       nop
0000eeb0  0fb68100db4700           movzx eax, byte ptr [rcx + 0x47db00]
0000eeb7  493beb                   cmp rbp, r11
0000eeba  7317                     jae 0xeed3
0000eebc  0f1f4000                 nop dword ptr [rax]
0000eec0  84c0                     test al, al
0000eec2  750f                     jne 0xeed3
0000eec4  4983c248                 add r10, 0x48
0000eec8  90                       nop
0000eec9  410fb64240               movzx eax, byte ptr [r10 + 0x40]
0000eece  4d3bd3                   cmp r10, r11
0000eed1  72ed                     jb 0xeec0
0000eed3  498bca                   mov rcx, r10
0000eed6  90                       nop
0000eed7  410fb64340               movzx eax, byte ptr [r11 + 0x40]
0000eedc  4d3bd3                   cmp r10, r11
0000eedf  0f84a4000000             je 0xef89
0000eee5  66413912                 cmp word ptr [r10], dx
0000eee9  750c                     jne 0xeef7
0000eeeb  45394204                 cmp dword ptr [r10 + 4], r8d
0000eeef  7506                     jne 0xeef7
0000eef1  4d396a08                 cmp qword ptr [r10 + 8], r13
0000eef5  742e                     je 0xef25
0000eef7  4983c248                 add r10, 0x48
0000eefb  493bcb                   cmp rcx, r11
0000eefe  4c0f43d1                 cmovae r10, rcx
0000ef02  90                       nop
0000ef03  410fb64240               movzx eax, byte ptr [r10 + 0x40]
0000ef08  4d3bd3                   cmp r10, r11
0000ef0b  73c6                     jae 0xeed3
0000ef0d  0f1f00                   nop dword ptr [rax]
0000ef10  84c0                     test al, al
0000ef12  75bf                     jne 0xeed3
0000ef14  4983c248                 add r10, 0x48
0000ef18  90                       nop
0000ef19  410fb64240               movzx eax, byte ptr [r10 + 0x40]
0000ef1e  4d3bd3                   cmp r10, r11
0000ef21  72ed                     jb 0xef10
0000ef23  ebae                     jmp 0xeed3
0000ef25  90                       nop
0000ef26  410fb64240               movzx eax, byte ptr [r10 + 0x40]
0000ef2b  482bcd                   sub rcx, rbp
0000ef2e  48b8398ee3388ee3380e     movabs rax, 0xe38e38e38e38e39
0000ef38  48f7e9                   imul rcx
0000ef3b  48c1fa02                 sar rdx, 2
0000ef3f  488bc2                   mov rax, rdx
0000ef42  48c1e83f                 shr rax, 0x3f
0000ef46  4803c2                   add rax, rdx
0000ef49  90                       nop
0000ef4a  498b4a38                 mov rcx, qword ptr [r10 + 0x38]
0000ef4e  4898                     cdqe
0000ef50  48c1e020                 shl rax, 0x20
0000ef54  48c1e920                 shr rcx, 0x20
0000ef58  480bc1                   or rax, rcx
0000ef5b  488b4c2470               mov rcx, qword ptr [rsp + 0x70]
0000ef60  4833cc                   xor rcx, rsp
0000ef63  e808df0400               call 0x5ce70
0000ef68  4c8d9c2480000000         lea r11, [rsp + 0x80]
0000ef70  498b5b38                 mov rbx, qword ptr [r11 + 0x38]
0000ef74  498b6b40                 mov rbp, qword ptr [r11 + 0x40]
0000ef78  498b7348                 mov rsi, qword ptr [r11 + 0x48]
0000ef7c  498be3                   mov rsp, r11
0000ef7f  415f                     pop r15
0000ef81  415e                     pop r14
0000ef83  415d                     pop r13
0000ef85  415c                     pop r12
0000ef87  5f                       pop rdi
0000ef88  c3                       ret
0000ef89  48638d00800900           movsxd rcx, dword ptr [rbp + 0x98000]
0000ef90  48c7c3ffffffff           mov rbx, 0xffffffffffffffff
0000ef97  85c9                     test ecx, ecx
0000ef99  7505                     jne 0xefa0
0000ef9b  488bfb                   mov rdi, rbx
0000ef9e  eb2b                     jmp 0xefcb
0000efa0  8d41ff                   lea eax, [rcx - 1]
0000efa3  898500800900             mov dword ptr [rbp + 0x98000], eax
0000efa9  4863bc8dfcff0800         movsxd rdi, dword ptr [rbp + rcx*4 + 0x8fffc]
0000efb1  488d04ff                 lea rax, [rdi + rdi*8]
0000efb5  c644c54101               mov byte ptr [rbp + rax*8 + 0x41], 1
0000efba  90                       nop
0000efbb  488b4cc538               mov rcx, qword ptr [rbp + rax*8 + 0x38]
0000efc0  48c1e720                 shl rdi, 0x20
0000efc4  48c1e920                 shr rcx, 0x20
0000efc8  480bf9                   or rdi, rcx
0000efcb  48896c2428               mov qword ptr [rsp + 0x28], rbp
0000efd0  48897c2430               mov qword ptr [rsp + 0x30], rdi
0000efd5  498db424b85a4100         lea rsi, [r12 + 0x415ab8]
0000efdd  48638e00800600           movsxd rcx, dword ptr [rsi + 0x68000]
0000efe4  85c9                     test ecx, ecx
0000efe6  742e                     je 0xf016
0000efe8  8d41ff                   lea eax, [rcx - 1]
0000efeb  898600800600             mov dword ptr [rsi + 0x68000], eax
0000eff1  48639c8efcff0500         movsxd rbx, dword ptr [rsi + rcx*4 + 0x5fffc]
0000eff9  488d045b                 lea rax, [rbx + rbx*2]
0000effd  4803c0                   add rax, rax
0000f000  c644c62901               mov byte ptr [rsi + rax*8 + 0x29], 1
0000f005  90                       nop
0000f006  488b44c620               mov rax, qword ptr [rsi + rax*8 + 0x20]
0000f00b  48c1e320                 shl rbx, 0x20
0000f00f  48c1e820                 shr rax, 0x20
0000f013  480bd8                   or rbx, rax
0000f016  4889742438               mov qword ptr [rsp + 0x38], rsi
0000f01b  48895c2440               mov qword ptr [rsp + 0x40], rbx
0000f020  4883ffff                 cmp rdi, -1
0000f024  0f84b5010000             je 0xf1df
0000f02a  4d85ff                   test r15, r15
0000f02d  7415                     je 0xf044
0000f02f  410f1007                 movups xmm0, xmmword ptr [r15]
0000f033  0f11442450               movups xmmword ptr [rsp + 0x50], xmm0
0000f038  410f104f10               movups xmm1, xmmword ptr [r15 + 0x10]
0000f03d  0f114c2460               movups xmmword ptr [rsp + 0x60], xmm1
0000f042  eb1f                     jmp 0xf063
0000f044  0f57c0                   xorps xmm0, xmm0
0000f047  0f11442450               movups xmmword ptr [rsp + 0x50], xmm0
0000f04c  0f11442460               movups xmmword ptr [rsp + 0x60], xmm0
0000f051  ff1541410500             call qword ptr [rip + 0x54141]
0000f057  c70016000000             mov dword ptr [rax], 0x16
0000f05d  ff153d410500             call qword ptr [rip + 0x5413d]
0000f063  488bc3                   mov rax, rbx
0000f066  48c1e820                 shr rax, 0x20
0000f06a  25ff1f0000               and eax, 0x1fff
0000f06f  4c8d3440                 lea r14, [rax + rax*2]
0000f073  49c1e604                 shl r14, 4
0000f077  4903f6                   add rsi, r14
0000f07a  90                       nop
0000f07b  0fb64e29                 movzx ecx, byte ptr [rsi + 0x29]
0000f07f  90                       nop
0000f080  488b4620                 mov rax, qword ptr [rsi + 0x20]
0000f084  48c1e820                 shr rax, 0x20
0000f088  3bc3                     cmp eax, ebx
0000f08a  0f8537010000             jne 0xf1c7
0000f090  84c9                     test cl, cl
0000f092  0f842f010000             je 0xf1c7
0000f098  4d8b4c2408               mov r9, qword ptr [r12 + 8]
0000f09d  41b802000000             mov r8d, 2
0000f0a3  488d542450               lea rdx, [rsp + 0x50]
0000f0a8  488bce                   mov rcx, rsi
0000f0ab  e8a0a2ffff               call 0x9350
0000f0b0  4d8b4c2408               mov r9, qword ptr [r12 + 8]
0000f0b5  41b802000000             mov r8d, 2
0000f0bb  488d542450               lea rdx, [rsp + 0x50]
0000f0c0  488bce                   mov rcx, rsi
0000f0c3  e888a2ffff               call 0x9350
0000f0c8  488bc7                   mov rax, rdi
0000f0cb  48c1e820                 shr rax, 0x20
0000f0cf  8bf0                     mov esi, eax
0000f0d1  25ff1f0000               and eax, 0x1fff
0000f0d6  488d04c0                 lea rax, [rax + rax*8]
0000f0da  4c8d24c500000000         lea r12, [rax*8]
0000f0e2  90                       nop
0000f0e3  410fb64c2c41             movzx ecx, byte ptr [r12 + rbp + 0x41]
0000f0e9  90                       nop
0000f0ea  498b442c38               mov rax, qword ptr [r12 + rbp + 0x38]
0000f0ef  48c1e820                 shr rax, 0x20
0000f0f3  3bc7                     cmp eax, edi
0000f0f5  0f85cc000000             jne 0xf1c7
0000f0fb  84c9                     test cl, cl
0000f0fd  0f84c4000000             je 0xf1c7
0000f103  0fb7442420               movzx eax, word ptr [rsp + 0x20]
0000f108  664189042c               mov word ptr [r12 + rbp], ax
0000f10d  8b442424                 mov eax, dword ptr [rsp + 0x24]
0000f111  4189442c04               mov dword ptr [r12 + rbp + 4], eax
0000f116  4d896c2c08               mov qword ptr [r12 + rbp + 8], r13
0000f11b  49895c2c30               mov qword ptr [r12 + rbp + 0x30], rbx
0000f120  488d4510                 lea rax, [rbp + 0x10]
0000f124  4903c4                   add rax, r12
0000f127  7421                     je 0xf14a
0000f129  4d85ff                   test r15, r15
0000f12c  7412                     je 0xf140
0000f12e  410f1007                 movups xmm0, xmmword ptr [r15]
0000f132  0f1100                   movups xmmword ptr [rax], xmm0
0000f135  410f104f10               movups xmm1, xmmword ptr [r15 + 0x10]
0000f13a  0f114810                 movups xmmword ptr [rax + 0x10], xmm1
0000f13e  eb1c                     jmp 0xf15c
0000f140  0f57c0                   xorps xmm0, xmm0
0000f143  0f1100                   movups xmmword ptr [rax], xmm0
0000f146  0f114010                 movups xmmword ptr [rax + 0x10], xmm0
0000f14a  ff1548400500             call qword ptr [rip + 0x54048]
0000f150  c70016000000             mov dword ptr [rax], 0x16
0000f156  ff1544400500             call qword ptr [rip + 0x54044]
0000f15c  48ff05e5674600           inc qword ptr [rip + 0x4667e5]
0000f163  4883fbff                 cmp rbx, -1
0000f167  7424                     je 0xf18d
0000f169  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
0000f16e  90                       nop
0000f16f  420fb6543129             movzx edx, byte ptr [rcx + r14 + 0x29]
0000f175  90                       nop
0000f176  4a8b443120               mov rax, qword ptr [rcx + r14 + 0x20]
0000f17b  48c1e820                 shr rax, 0x20
0000f17f  3bc3                     cmp eax, ebx
0000f181  750a                     jne 0xf18d
0000f183  84d2                     test dl, dl
0000f185  7406                     je 0xf18d
0000f187  42c644312801             mov byte ptr [rcx + r14 + 0x28], 1
0000f18d  488b442428               mov rax, qword ptr [rsp + 0x28]
0000f192  90                       nop
0000f193  410fb6540441             movzx edx, byte ptr [r12 + rax + 0x41]
0000f199  90                       nop
0000f19a  498b4c0438               mov rcx, qword ptr [r12 + rax + 0x38]
0000f19f  48c1e920                 shr rcx, 0x20
0000f1a3  3bcf                     cmp ecx, edi
0000f1a5  7518                     jne 0xf1bf
0000f1a7  84d2                     test dl, dl
0000f1a9  7414                     je 0xf1bf
0000f1ab  81e6ff1f0000             and esi, 0x1fff
0000f1b1  488d14f6                 lea rdx, [rsi + rsi*8]
0000f1b5  488b4c2428               mov rcx, qword ptr [rsp + 0x28]
0000f1ba  c644d14001               mov byte ptr [rcx + rdx*8 + 0x40], 1
0000f1bf  488bc7                   mov rax, rdi
0000f1c2  e994fdffff               jmp 0xef5b
0000f1c7  ba5f000000               mov edx, 0x5f
0000f1cc  b94b010000               mov ecx, 0x14b
0000f1d1  448d4aa2                 lea r9d, [rdx - 0x5e]
0000f1d5  448d42b2                 lea r8d, [rdx - 0x4e]
0000f1d9  e862a20000               call 0x19440
0000f1de  cc                       int3
0000f1df  ba59000000               mov edx, 0x59
0000f1e4  b94b010000               mov ecx, 0x14b
0000f1e9  448d4aa9                 lea r9d, [rdx - 0x57]
0000f1ed  448d42b7                 lea r8d, [rdx - 0x49]
0000f1f1  e84aa20000               call 0x19440
0000f1f6  cc                       int3
