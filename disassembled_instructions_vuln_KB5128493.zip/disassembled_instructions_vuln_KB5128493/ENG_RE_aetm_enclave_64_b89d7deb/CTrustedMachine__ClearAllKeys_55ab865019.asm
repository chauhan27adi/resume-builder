; CTrustedMachine::ClearAllKeys
; aetm_enclave.dll, primary RVA 0xe7f0, 1230 bytes in 1 chunk(s)

; chunk at RVA 0xe7f0 (1230 bytes)
0000e7f0  48895c2410               mov qword ptr [rsp + 0x10], rbx
0000e7f5  48896c2418               mov qword ptr [rsp + 0x18], rbp
0000e7fa  4889742420               mov qword ptr [rsp + 0x20], rsi
0000e7ff  57                       push rdi
0000e800  4156                     push r14
0000e802  4c8d91d0da5600           lea r10, [rcx + 0x56dad0]
0000e809  90                       nop
0000e80a  0fb681f8da5600           movzx eax, byte ptr [rcx + 0x56daf8]
0000e811  4c8d89d05a5800           lea r9, [rcx + 0x585ad0]
0000e818  488bf9                   mov rdi, rcx
0000e81b  4d8bc2                   mov r8, r10
0000e81e  4d3bd1                   cmp r10, r9
0000e821  7313                     jae 0xe836
0000e823  84c0                     test al, al
0000e825  750f                     jne 0xe836
0000e827  4983c030                 add r8, 0x30
0000e82b  90                       nop
0000e82c  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000e831  4d3bc1                   cmp r8, r9
0000e834  72ed                     jb 0xe823
0000e836  48beabaaaaaaaaaaaa2a     movabs rsi, 0x2aaaaaaaaaaaaaab
0000e840  48bd00000000ffffffff     movabs rbp, 0xffffffff00000000
0000e84a  49be0000000001000000     movabs r14, 0x100000000
0000e854  0f1f4000                 nop dword ptr [rax]
0000e858  0f1f840000000000         nop dword ptr [rax + rax]
0000e860  90                       nop
0000e861  410fb64128               movzx eax, byte ptr [r9 + 0x28]
0000e866  90                       nop
0000e867  4d8bd8                   mov r11, r8
0000e86a  4d3bc1                   cmp r8, r9
0000e86d  0f84f9000000             je 0xe96c
0000e873  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000e878  498bc8                   mov rcx, r8
0000e87b  492bca                   sub rcx, r10
0000e87e  90                       nop
0000e87f  488bc6                   mov rax, rsi
0000e882  48f7e9                   imul rcx
0000e885  48c1fa03                 sar rdx, 3
0000e889  488bc2                   mov rax, rdx
0000e88c  48c1e83f                 shr rax, 0x3f
0000e890  4803d0                   add rdx, rax
0000e893  498b4020                 mov rax, qword ptr [r8 + 0x20]
0000e897  48c1e820                 shr rax, 0x20
0000e89b  90                       nop
0000e89c  4863ca                   movsxd rcx, edx
0000e89f  48c1e120                 shl rcx, 0x20
0000e8a3  480bc8                   or rcx, rax
0000e8a6  488bc1                   mov rax, rcx
0000e8a9  48c1e820                 shr rax, 0x20
0000e8ad  8bd0                     mov edx, eax
0000e8af  25ff070000               and eax, 0x7ff
0000e8b4  8bd8                     mov ebx, eax
0000e8b6  488d0440                 lea rax, [rax + rax*2]
0000e8ba  4803c0                   add rax, rax
0000e8bd  450fb644c229             movzx r8d, byte ptr [r10 + rax*8 + 0x29]
0000e8c3  90                       nop
0000e8c4  498b44c220               mov rax, qword ptr [r10 + rax*8 + 0x20]
0000e8c9  48c1e820                 shr rax, 0x20
0000e8cd  3bc1                     cmp eax, ecx
0000e8cf  755c                     jne 0xe92d
0000e8d1  4584c0                   test r8b, r8b
0000e8d4  7457                     je 0xe92d
0000e8d6  81e2ff070000             and edx, 0x7ff
0000e8dc  90                       nop
0000e8dd  488d1452                 lea rdx, [rdx + rdx*2]
0000e8e1  48c1e204                 shl rdx, 4
0000e8e5  4903d2                   add rdx, r10
0000e8e8  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000e8ec  85c0                     test eax, eax
0000e8ee  753d                     jne 0xe92d
0000e8f0  488bc8                   mov rcx, rax
0000e8f3  4823cd                   and rcx, rbp
0000e8f6  4903ce                   add rcx, r14
0000e8f9  f0480fb14a20             lock cmpxchg qword ptr [rdx + 0x20], rcx
0000e8ff  752c                     jne 0xe92d
0000e901  c6422800                 mov byte ptr [rdx + 0x28], 0
0000e905  c6422900                 mov byte ptr [rdx + 0x29], 0
0000e909  90                       nop
0000e90a  488b4220                 mov rax, qword ptr [rdx + 0x20]
0000e90e  48c1e820                 shr rax, 0x20
0000e912  83f8ff                   cmp eax, -1
0000e915  7416                     je 0xe92d
0000e917  49638200a00100           movsxd rax, dword ptr [r10 + 0x1a000]
0000e91e  41899c8200800100         mov dword ptr [r10 + rax*4 + 0x18000], ebx
0000e926  41ff8200a00100           inc dword ptr [r10 + 0x1a000]
0000e92d  48ff0d24704600           dec qword ptr [rip + 0x467024]
0000e934  4d8d4330                 lea r8, [r11 + 0x30]
0000e938  4d3bd9                   cmp r11, r9
0000e93b  90                       nop
0000e93c  4d0f43c3                 cmovae r8, r11
0000e940  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000e945  4d3bc1                   cmp r8, r9
0000e948  0f8312ffffff             jae 0xe860
0000e94e  6690                     nop
0000e950  84c0                     test al, al
0000e952  0f8508ffffff             jne 0xe860
0000e958  4983c030                 add r8, 0x30
0000e95c  90                       nop
0000e95d  410fb64028               movzx eax, byte ptr [r8 + 0x28]
0000e962  4d3bc1                   cmp r8, r9
0000e965  72e9                     jb 0xe950
0000e967  e9f4feffff               jmp 0xe860
0000e96c  0fb687e85a5100           movzx eax, byte ptr [rdi + 0x515ae8]
0000e973  4c8d97c85a5100           lea r10, [rdi + 0x515ac8]
0000e97a  4c8d8fc85a5600           lea r9, [rdi + 0x565ac8]
0000e981  4d8bc2                   mov r8, r10
0000e984  4d3bd1                   cmp r10, r9
0000e987  731a                     jae 0xe9a3
0000e989  0f1f8000000000           nop dword ptr [rax]
0000e990  84c0                     test al, al
0000e992  750f                     jne 0xe9a3
0000e994  4983c028                 add r8, 0x28
0000e998  90                       nop
0000e999  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000e99e  4d3bc1                   cmp r8, r9
0000e9a1  72ed                     jb 0xe990
0000e9a3  48be6766666666666666     movabs rsi, 0x6666666666666667
0000e9ad  0f1f00                   nop dword ptr [rax]
0000e9b0  90                       nop
0000e9b1  410fb64120               movzx eax, byte ptr [r9 + 0x20]
0000e9b6  90                       nop
0000e9b7  4d8bd8                   mov r11, r8
0000e9ba  4d3bc1                   cmp r8, r9
0000e9bd  0f84f9000000             je 0xeabc
0000e9c3  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000e9c8  498bc8                   mov rcx, r8
0000e9cb  492bca                   sub rcx, r10
0000e9ce  90                       nop
0000e9cf  488bc6                   mov rax, rsi
0000e9d2  48f7e9                   imul rcx
0000e9d5  48c1fa04                 sar rdx, 4
0000e9d9  488bc2                   mov rax, rdx
0000e9dc  48c1e83f                 shr rax, 0x3f
0000e9e0  4803d0                   add rdx, rax
0000e9e3  498b4018                 mov rax, qword ptr [r8 + 0x18]
0000e9e7  48c1e820                 shr rax, 0x20
0000e9eb  90                       nop
0000e9ec  4863ca                   movsxd rcx, edx
0000e9ef  48c1e120                 shl rcx, 0x20
0000e9f3  480bc8                   or rcx, rax
0000e9f6  488bc1                   mov rax, rcx
0000e9f9  48c1e820                 shr rax, 0x20
0000e9fd  8bd0                     mov edx, eax
0000e9ff  25ff1f0000               and eax, 0x1fff
0000ea04  8bd8                     mov ebx, eax
0000ea06  488d0480                 lea rax, [rax + rax*4]
0000ea0a  450fb644c221             movzx r8d, byte ptr [r10 + rax*8 + 0x21]
0000ea10  90                       nop
0000ea11  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000ea16  48c1e820                 shr rax, 0x20
0000ea1a  3bc1                     cmp eax, ecx
0000ea1c  755a                     jne 0xea78
0000ea1e  4584c0                   test r8b, r8b
0000ea21  7455                     je 0xea78
0000ea23  81e2ff1f0000             and edx, 0x1fff
0000ea29  90                       nop
0000ea2a  488d0492                 lea rax, [rdx + rdx*4]
0000ea2e  498d14c2                 lea rdx, [r10 + rax*8]
0000ea32  498b44c218               mov rax, qword ptr [r10 + rax*8 + 0x18]
0000ea37  85c0                     test eax, eax
0000ea39  753d                     jne 0xea78
0000ea3b  488bc8                   mov rcx, rax
0000ea3e  4823cd                   and rcx, rbp
0000ea41  4903ce                   add rcx, r14
0000ea44  f0480fb14a18             lock cmpxchg qword ptr [rdx + 0x18], rcx
0000ea4a  752c                     jne 0xea78
0000ea4c  c6422000                 mov byte ptr [rdx + 0x20], 0
0000ea50  c6422100                 mov byte ptr [rdx + 0x21], 0
0000ea54  90                       nop
0000ea55  488b4218                 mov rax, qword ptr [rdx + 0x18]
0000ea59  48c1e820                 shr rax, 0x20
0000ea5d  83f8ff                   cmp eax, -1
0000ea60  7416                     je 0xea78
0000ea62  49638200800500           movsxd rax, dword ptr [r10 + 0x58000]
0000ea69  41899c8200000500         mov dword ptr [r10 + rax*4 + 0x50000], ebx
0000ea71  41ff8200800500           inc dword ptr [r10 + 0x58000]
0000ea78  48ff0dd16e4600           dec qword ptr [rip + 0x466ed1]
0000ea7f  4d8d4328                 lea r8, [r11 + 0x28]
0000ea83  4d3bd9                   cmp r11, r9
0000ea86  90                       nop
0000ea87  4d0f43c3                 cmovae r8, r11
0000ea8b  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000ea90  4d3bc1                   cmp r8, r9
0000ea93  0f8317ffffff             jae 0xe9b0
0000ea99  0f1f8000000000           nop dword ptr [rax]
0000eaa0  84c0                     test al, al
0000eaa2  0f8508ffffff             jne 0xe9b0
0000eaa8  4983c028                 add r8, 0x28
0000eaac  90                       nop
0000eaad  410fb64020               movzx eax, byte ptr [r8 + 0x20]
0000eab2  4d3bc1                   cmp r8, r9
0000eab5  72e9                     jb 0xeaa0
0000eab7  e9f4feffff               jmp 0xe9b0
0000eabc  0fb68700db4700           movzx eax, byte ptr [rdi + 0x47db00]
0000eac3  4c8d9fc0da4700           lea r11, [rdi + 0x47dac0]
0000eaca  4c8d87c0da5000           lea r8, [rdi + 0x50dac0]
0000ead1  498bcb                   mov rcx, r11
0000ead4  4d3bd8                   cmp r11, r8
0000ead7  7319                     jae 0xeaf2
0000ead9  0f1f8000000000           nop dword ptr [rax]
0000eae0  84c0                     test al, al
0000eae2  750e                     jne 0xeaf2
0000eae4  4883c148                 add rcx, 0x48
0000eae8  90                       nop
0000eae9  0fb64140                 movzx eax, byte ptr [rcx + 0x40]
0000eaed  493bc8                   cmp rcx, r8
0000eaf0  72ee                     jb 0xeae0
0000eaf2  48be398ee3388ee3380e     movabs rsi, 0xe38e38e38e38e39
0000eafc  0f1f4000                 nop dword ptr [rax]
0000eb00  90                       nop
0000eb01  410fb64040               movzx eax, byte ptr [r8 + 0x40]
0000eb06  488bd9                   mov rbx, rcx
0000eb09  493bc8                   cmp rcx, r8
0000eb0c  0f8499010000             je 0xecab
0000eb12  488b5130                 mov rdx, qword ptr [rcx + 0x30]
0000eb16  4c8d97b85a4100           lea r10, [rdi + 0x415ab8]
0000eb1d  90                       nop
0000eb1e  488bc2                   mov rax, rdx
0000eb21  48c1e820                 shr rax, 0x20
0000eb25  25ff1f0000               and eax, 0x1fff
0000eb2a  488d0440                 lea rax, [rax + rax*2]
0000eb2e  4803c0                   add rax, rax
0000eb31  450fb64cc229             movzx r9d, byte ptr [r10 + rax*8 + 0x29]
0000eb37  90                       nop
0000eb38  498b44c220               mov rax, qword ptr [r10 + rax*8 + 0x20]
0000eb3d  48c1e820                 shr rax, 0x20
0000eb41  3bc2                     cmp eax, edx
0000eb43  7573                     jne 0xebb8
0000eb45  4584c9                   test r9b, r9b
0000eb48  746e                     je 0xebb8
0000eb4a  488b4130                 mov rax, qword ptr [rcx + 0x30]
0000eb4e  90                       nop
0000eb4f  48c1e820                 shr rax, 0x20
0000eb53  25ff1f0000               and eax, 0x1fff
0000eb58  4c8d0c40                 lea r9, [rax + rax*2]
0000eb5c  49c1e104                 shl r9, 4
0000eb60  4d03ca                   add r9, r10
0000eb63  498b4120                 mov rax, qword ptr [r9 + 0x20]
0000eb67  85c0                     test eax, eax
0000eb69  754d                     jne 0xebb8
0000eb6b  488bd0                   mov rdx, rax
0000eb6e  4823d5                   and rdx, rbp
0000eb71  4903d6                   add rdx, r14
0000eb74  f0490fb15120             lock cmpxchg qword ptr [r9 + 0x20], rdx
0000eb7a  753c                     jne 0xebb8
0000eb7c  41c6412800               mov byte ptr [r9 + 0x28], 0
0000eb81  41c6412900               mov byte ptr [r9 + 0x29], 0
0000eb86  90                       nop
0000eb87  498b4120                 mov rax, qword ptr [r9 + 0x20]
0000eb8b  48c1e820                 shr rax, 0x20
0000eb8f  83f8ff                   cmp eax, -1
0000eb92  7424                     je 0xebb8
0000eb94  488b5130                 mov rdx, qword ptr [rcx + 0x30]
0000eb98  49638200800600           movsxd rax, dword ptr [r10 + 0x68000]
0000eb9f  48c1ea20                 shr rdx, 0x20
0000eba3  81e2ff1f0000             and edx, 0x1fff
0000eba9  4189948200000600         mov dword ptr [r10 + rax*4 + 0x60000], edx
0000ebb1  41ff8200800600           inc dword ptr [r10 + 0x68000]
0000ebb8  90                       nop
0000ebb9  488bd1                   mov rdx, rcx
0000ebbc  0fb64140                 movzx eax, byte ptr [rcx + 0x40]
0000ebc0  492bd3                   sub rdx, r11
0000ebc3  90                       nop
0000ebc4  488bc6                   mov rax, rsi
0000ebc7  48f7ea                   imul rdx
0000ebca  48c1fa02                 sar rdx, 2
0000ebce  488bc2                   mov rax, rdx
0000ebd1  48c1e83f                 shr rax, 0x3f
0000ebd5  4803d0                   add rdx, rax
0000ebd8  488b4138                 mov rax, qword ptr [rcx + 0x38]
0000ebdc  48c1e820                 shr rax, 0x20
0000ebe0  90                       nop
0000ebe1  4863ca                   movsxd rcx, edx
0000ebe4  48c1e120                 shl rcx, 0x20
0000ebe8  480bc8                   or rcx, rax
0000ebeb  488bc1                   mov rax, rcx
0000ebee  48c1e820                 shr rax, 0x20
0000ebf2  8bd0                     mov edx, eax
0000ebf4  25ff1f0000               and eax, 0x1fff
0000ebf9  448bd0                   mov r10d, eax
0000ebfc  488d04c0                 lea rax, [rax + rax*8]
0000ec00  450fb64cc341             movzx r9d, byte ptr [r11 + rax*8 + 0x41]
0000ec06  90                       nop
0000ec07  498b44c338               mov rax, qword ptr [r11 + rax*8 + 0x38]
0000ec0c  48c1e820                 shr rax, 0x20
0000ec10  3bc1                     cmp eax, ecx
0000ec12  755a                     jne 0xec6e
0000ec14  4584c9                   test r9b, r9b
0000ec17  7455                     je 0xec6e
0000ec19  81e2ff1f0000             and edx, 0x1fff
0000ec1f  90                       nop
0000ec20  488d04d2                 lea rax, [rdx + rdx*8]
0000ec24  498d14c3                 lea rdx, [r11 + rax*8]
0000ec28  498b44c338               mov rax, qword ptr [r11 + rax*8 + 0x38]
0000ec2d  85c0                     test eax, eax
0000ec2f  753d                     jne 0xec6e
0000ec31  488bc8                   mov rcx, rax
0000ec34  4823cd                   and rcx, rbp
0000ec37  4903ce                   add rcx, r14
0000ec3a  f0480fb14a38             lock cmpxchg qword ptr [rdx + 0x38], rcx
0000ec40  752c                     jne 0xec6e
0000ec42  c6424000                 mov byte ptr [rdx + 0x40], 0
0000ec46  c6424100                 mov byte ptr [rdx + 0x41], 0
0000ec4a  90                       nop
0000ec4b  488b4238                 mov rax, qword ptr [rdx + 0x38]
0000ec4f  48c1e820                 shr rax, 0x20
0000ec53  83f8ff                   cmp eax, -1
0000ec56  7416                     je 0xec6e
0000ec58  49638300800900           movsxd rax, dword ptr [r11 + 0x98000]
0000ec5f  4589948300000900         mov dword ptr [r11 + rax*4 + 0x90000], r10d
0000ec67  41ff8300800900           inc dword ptr [r11 + 0x98000]
0000ec6e  48ff0dd36c4600           dec qword ptr [rip + 0x466cd3]
0000ec75  488d4b48                 lea rcx, [rbx + 0x48]
0000ec79  493bd8                   cmp rbx, r8
0000ec7c  90                       nop
0000ec7d  480f43cb                 cmovae rcx, rbx
0000ec81  0fb64140                 movzx eax, byte ptr [rcx + 0x40]
0000ec85  493bc8                   cmp rcx, r8
0000ec88  0f8372feffff             jae 0xeb00
0000ec8e  6690                     nop
0000ec90  84c0                     test al, al
0000ec92  0f8568feffff             jne 0xeb00
0000ec98  4883c148                 add rcx, 0x48
0000ec9c  90                       nop
0000ec9d  0fb64140                 movzx eax, byte ptr [rcx + 0x40]
0000eca1  493bc8                   cmp rcx, r8
0000eca4  72ea                     jb 0xec90
0000eca6  e955feffff               jmp 0xeb00
0000ecab  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0000ecb0  488b6c2428               mov rbp, qword ptr [rsp + 0x28]
0000ecb5  488b742430               mov rsi, qword ptr [rsp + 0x30]
0000ecba  415e                     pop r14
0000ecbc  5f                       pop rdi
0000ecbd  c3                       ret
