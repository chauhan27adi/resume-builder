; CEsCompValSeg::~CEsCompValSeg
; aetm_enclave.dll, primary RVA 0x2c2e0, 124 bytes in 5 chunk(s)

; chunk at RVA 0x2c2e0 (4 bytes)
0002c2e0  4883ec28                 sub rsp, 0x28

; chunk at RVA 0x2c2e4 (16 bytes)
0002c2e4  48895c2430               mov qword ptr [rsp + 0x30], rbx
0002c2e9  488bd9                   mov rbx, rcx
0002c2ec  488b09                   mov rcx, qword ptr [rcx]
0002c2ef  4885c9                   test rcx, rcx
0002c2f2  7434                     je 0x2c328

; chunk at RVA 0x2c2f4 (52 bytes)
0002c2f4  48897c2420               mov qword ptr [rsp + 0x20], rdi
0002c2f9  33ff                     xor edi, edi
0002c2fb  397b08                   cmp dword ptr [rbx + 8], edi
0002c2fe  7617                     jbe 0x2c317
0002c300  488b03                   mov rax, qword ptr [rbx]
0002c303  488b0cf8                 mov rcx, qword ptr [rax + rdi*8]
0002c307  488b01                   mov rax, qword ptr [rcx]
0002c30a  ff5048                   call qword ptr [rax + 0x48]
0002c30d  ffc7                     inc edi
0002c30f  3b7b08                   cmp edi, dword ptr [rbx + 8]
0002c312  72ec                     jb 0x2c300
0002c314  488b0b                   mov rcx, qword ptr [rbx]
0002c317  e8c00b0300               call 0x5cedc
0002c31c  488b7c2420               mov rdi, qword ptr [rsp + 0x20]
0002c321  48c70300000000           mov qword ptr [rbx], 0

; chunk at RVA 0x2c328 (33 bytes)
0002c328  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
0002c32c  4885c9                   test rcx, rcx
0002c32f  740a                     je 0x2c33b
0002c331  ba01000000               mov edx, 1
0002c336  e8b50c0300               call 0x5cff0
0002c33b  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0002c33f  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0002c344  4885c9                   test rcx, rcx
0002c347  740e                     je 0x2c357

; chunk at RVA 0x2c349 (19 bytes)
0002c349  ba01000000               mov edx, 1
0002c34e  4883c428                 add rsp, 0x28
0002c352  e9990c0300               jmp 0x5cff0
0002c357  4883c428                 add rsp, 0x28
0002c35b  c3                       ret
