; CBCryptRSAKey::~CBCryptRSAKey
; aetm_enclave.dll, primary RVA 0x186b0, 61 bytes in 1 chunk(s)

; chunk at RVA 0x186b0 (61 bytes)
000186b0  48894c2408               mov qword ptr [rsp + 8], rcx
000186b5  4883ec38                 sub rsp, 0x38
000186b9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000186c2  488d0517c20400           lea rax, [rip + 0x4c217]
000186c9  488901                   mov qword ptr [rcx], rax
000186cc  488d4108                 lea rax, [rcx + 8]
000186d0  4889442448               mov qword ptr [rsp + 0x48], rax
000186d5  488b08                   mov rcx, qword ptr [rax]
000186d8  4885c9                   test rcx, rcx
000186db  740b                     je 0x186e8
000186dd  4883c438                 add rsp, 0x38
000186e1  48ff25f0a90400           jmp qword ptr [rip + 0x4a9f0]
000186e8  4883c438                 add rsp, 0x38
000186ec  c3                       ret
