; XE_ILogReadMessageHandler::~XE_ILogReadMessageHandler
; sqldk.dll, primary RVA 0x1bbc20, 32 bytes in 1 chunk(s)

; chunk at RVA 0x1bbc20 (32 bytes)
001bbc20  48894c2408               mov qword ptr [rsp + 8], rcx
001bbc25  4883ec18                 sub rsp, 0x18
001bbc29  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
001bbc31  488d05e88f0c00           lea rax, [rip + 0xc8fe8]
001bbc38  488901                   mov qword ptr [rcx], rax
001bbc3b  4883c418                 add rsp, 0x18
001bbc3f  c3                       ret
