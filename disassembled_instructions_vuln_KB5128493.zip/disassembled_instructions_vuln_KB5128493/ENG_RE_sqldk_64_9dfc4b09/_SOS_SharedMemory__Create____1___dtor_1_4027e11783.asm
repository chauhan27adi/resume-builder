; `SOS_SharedMemory::Create'::`1'::dtor$1
; sqldk.dll, primary RVA 0x228790, 59 bytes in 1 chunk(s)

; chunk at RVA 0x228790 (59 bytes)
00228790  4055                     push rbp
00228792  4883ec30                 sub rsp, 0x30
00228796  488bea                   mov rbp, rdx
00228799  c644242806               mov byte ptr [rsp + 0x28], 6
0022879e  8b4540                   mov eax, dword ptr [rbp + 0x40]
002287a1  89442420                 mov dword ptr [rsp + 0x20], eax
002287a5  4c8d0d34140700           lea r9, [rip + 0x71434]
002287ac  41b801000000             mov r8d, 1
002287b2  488b9508010000           mov rdx, qword ptr [rbp + 0x108]
002287b9  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
002287c0  e8dbf5ddff               call 0x7da0
002287c5  4883c430                 add rsp, 0x30
002287c9  5d                       pop rbp
002287ca  c3                       ret
