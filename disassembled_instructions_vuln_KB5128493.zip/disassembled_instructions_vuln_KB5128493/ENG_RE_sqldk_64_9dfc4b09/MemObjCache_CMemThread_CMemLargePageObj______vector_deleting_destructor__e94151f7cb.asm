; MemObjCache<CMemThread<CMemLargePageObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13ec00, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13ec00 (79 bytes)
0013ec00  48894c2408               mov qword ptr [rsp + 8], rcx
0013ec05  57                       push rdi
0013ec06  4883ec30                 sub rsp, 0x30
0013ec0a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013ec13  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013ec18  8bda                     mov ebx, edx
0013ec1a  488bf9                   mov rdi, rcx
0013ec1d  488d05a4961000           lea rax, [rip + 0x1096a4]
0013ec24  488901                   mov qword ptr [rcx], rax
0013ec27  e8044bfdff               call 0x113730
0013ec2c  83e305                   and ebx, 5
0013ec2f  80fb05                   cmp bl, 5
0013ec32  750d                     jne 0x13ec41
0013ec34  baf0020000               mov edx, 0x2f0
0013ec39  488bcf                   mov rcx, rdi
0013ec3c  e8cf23ecff               call 0x1010
0013ec41  488bc7                   mov rax, rdi
0013ec44  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013ec49  4883c430                 add rsp, 0x30
0013ec4d  5f                       pop rdi
0013ec4e  c3                       ret
