; `XE_MetadataTracker::~XE_MetadataTracker'::`1'::dtor$6
; sqldk.dll, primary RVA 0x216780, 42 bytes in 1 chunk(s)

; chunk at RVA 0x216780 (42 bytes)
00216780  4055                     push rbp
00216782  4883ec20                 sub rsp, 0x20
00216786  488bea                   mov rbp, rdx
00216789  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
0021678d  4c8d0d5c11e3ff           lea r9, [rip - 0x1ceea4]
00216794  41b800040000             mov r8d, 0x400
0021679a  ba08000000               mov edx, 8
0021679f  e8bc84e1ff               call 0x2ec60
002167a4  4883c420                 add rsp, 0x20
002167a8  5d                       pop rbp
002167a9  c3                       ret
