; CMemAligned<CMemDbg<CMemLargePageObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xd06a0, 79 bytes in 1 chunk(s)

; chunk at RVA 0xd06a0 (79 bytes)
000d06a0  48894c2408               mov qword ptr [rsp + 8], rcx
000d06a5  57                       push rdi
000d06a6  4883ec30                 sub rsp, 0x30
000d06aa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d06b3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d06b8  8bda                     mov ebx, edx
000d06ba  488bf9                   mov rdi, rcx
000d06bd  488d05bcad1700           lea rax, [rip + 0x17adbc]
000d06c4  488901                   mov qword ptr [rcx], rax
000d06c7  e884320a00               call 0x173950
000d06cc  83e305                   and ebx, 5
000d06cf  80fb05                   cmp bl, 5
000d06d2  750d                     jne 0xd06e1
000d06d4  baa0050000               mov edx, 0x5a0
000d06d9  488bcf                   mov rcx, rdi
000d06dc  e82f09f3ff               call 0x1010
000d06e1  488bc7                   mov rax, rdi
000d06e4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d06e9  4883c430                 add rsp, 0x30
000d06ed  5f                       pop rdi
000d06ee  c3                       ret
