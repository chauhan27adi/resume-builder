; XE_PredicateExpr::~XE_PredicateExpr
; sqldk.dll, primary RVA 0x1fa290, 39 bytes in 1 chunk(s)

; chunk at RVA 0x1fa290 (39 bytes)
001fa290  48894c2408               mov qword ptr [rsp + 8], rcx
001fa295  4883ec18                 sub rsp, 0x18
001fa299  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
001fa2a1  488d05d8080b00           lea rax, [rip + 0xb08d8]
001fa2a8  488901                   mov qword ptr [rcx], rax
001fa2ab  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
001fa2b2  4883c418                 add rsp, 0x18
001fa2b6  c3                       ret
