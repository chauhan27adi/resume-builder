; XEPackage0::RingTarget::InsertEvent
; sqldk.dll, primary RVA 0x2a0b0, 197 bytes in 3 chunk(s)

; chunk at RVA 0x29d54 (121 bytes)
00029d54  48895c2410               mov qword ptr [rsp + 0x10], rbx
00029d59  4585d2                   test r10d, r10d
00029d5c  7424                     je 0x29d82
00029d5e  4d8b4848                 mov r9, qword ptr [r8 + 0x48]
00029d62  0f1f4000                 nop dword ptr [rax]
00029d66  66660f1f840000000000     nop word ptr [rax + rax]
00029d70  8bc1                     mov eax, ecx
00029d72  4803c0                   add rax, rax
00029d75  498b04c1                 mov rax, qword ptr [r9 + rax*8]
00029d79  4885c0                   test rax, rax
00029d7c  0f85825c1a00             jne 0x1cfa04
00029d82  498b5848                 mov rbx, qword ptr [r8 + 0x48]
00029d86  8bc1                     mov eax, ecx
00029d88  4803c0                   add rax, rax
00029d8b  4c8b0cc3                 mov r9, qword ptr [rbx + rax*8]
00029d8f  4d85c9                   test r9, r9
00029d92  0f858e5c1a00             jne 0x1cfa26
00029d98  413bca                   cmp ecx, r10d
00029d9b  0f84d25c1a00             je 0x1cfa73
00029da1  4d85db                   test r11, r11
00029da4  7504                     jne 0x29daa
00029da6  49895028                 mov qword ptr [r8 + 0x28], rdx
00029daa  8bc1                     mov eax, ecx
00029dac  4803c0                   add rax, rax
00029daf  488914c3                 mov qword ptr [rbx + rax*8], rdx
00029db3  41ff4020                 inc dword ptr [r8 + 0x20]
00029db7  498b4018                 mov rax, qword ptr [r8 + 0x18]
00029dbb  488902                   mov qword ptr [rdx], rax
00029dbe  49895018                 mov qword ptr [r8 + 0x18], rdx
00029dc2  488b5c2410               mov rbx, qword ptr [rsp + 0x10]
00029dc7  e923030000               jmp 0x2a0ef
00029dcc  cc                       int3

; chunk at RVA 0x2a0b0 (63 bytes)
0002a0b0  4057                     push rdi
0002a0b2  4c8b5928                 mov r11, qword ptr [rcx + 0x28]
0002a0b6  33ff                     xor edi, edi
0002a0b8  c7415401000000           mov dword ptr [rcx + 0x54], 1
0002a0bf  4c8bc1                   mov r8, rcx
0002a0c2  4d85db                   test r11, r11
0002a0c5  0f8483fcffff             je 0x29d4e
0002a0cb  498b4320                 mov rax, qword ptr [r11 + 0x20]
0002a0cf  482b4220                 sub rax, qword ptr [rdx + 0x20]
0002a0d3  4885c0                   test rax, rax
0002a0d6  0f8f72fcffff             jg 0x29d4e
0002a0dc  ff4120                   inc dword ptr [rcx + 0x20]
0002a0df  498b03                   mov rax, qword ptr [r11]
0002a0e2  488902                   mov qword ptr [rdx], rax
0002a0e5  498913                   mov qword ptr [r11], rdx
0002a0e8  48895128                 mov qword ptr [rcx + 0x28], rdx
0002a0ec  eb01                     jmp 0x2a0ef
0002a0ee  cc                       int3

; chunk at RVA 0x2a0ef (13 bytes)
0002a0ef  4183786401               cmp dword ptr [r8 + 0x64], 1
0002a0f4  0f8481591a00             je 0x1cfa7b
0002a0fa  5f                       pop rdi
0002a0fb  c3                       ret
