; MemoryNode::ShrinkUsingExternalCaches
; sqldk.dll, primary RVA 0x3cce0, 376 bytes in 3 chunk(s)

; chunk at RVA 0x38910 (336 bytes)
00038910  488970e0                 mov qword ptr [rax - 0x20], rsi
00038914  488bf9                   mov rdi, rcx
00038917  4c8970c8                 mov qword ptr [rax - 0x38], r14
0003891b  4533f6                   xor r14d, r14d
0003891e  4c8978c0                 mov qword ptr [rax - 0x40], r15
00038922  b802000000               mov eax, 2
00038927  8be8                     mov ebp, eax
00038929  898424b0000000           mov dword ptr [rsp + 0xb0], eax
00038930  488b0561b92d00           mov rax, qword ptr [rip + 0x2db961]
00038937  4885c0                   test rax, rax
0003893a  740b                     je 0x38947
0003893c  f6802006000010           test byte ptr [rax + 0x620], 0x10
00038943  490f45c6                 cmovne rax, r14
00038947  4885c0                   test rax, rax
0003894a  4c896c2478               mov qword ptr [rsp + 0x78], r13
0003894f  4c8db888050000           lea r15, [rax + 0x588]
00038956  4d0f44fe                 cmove r15, r14
0003895a  e801ffffff               call 0x38860
0003895f  4c89b424c0000000         mov qword ptr [rsp + 0xc0], r14
00038967  8bf0                     mov esi, eax
00038969  85c0                     test eax, eax
0003896b  7447                     je 0x389b4
0003896d  488b4f50                 mov rcx, qword ptr [rdi + 0x50]
00038971  48034f48                 add rcx, qword ptr [rdi + 0x48]
00038975  48034f40                 add rcx, qword ptr [rdi + 0x40]
00038979  833d18862e0001           cmp dword ptr [rip + 0x2e8618], 1
00038980  750b                     jne 0x3898d
00038982  488b4768                 mov rax, qword ptr [rdi + 0x68]
00038986  482b4760                 sub rax, qword ptr [rdi + 0x60]
0003898a  4803c8                   add rcx, rax
0003898d  4c8b87a8000000           mov r8, qword ptr [rdi + 0xa8]
00038994  488d4101                 lea rax, [rcx + 1]
00038998  4899                     cqo
0003899a  482bc2                   sub rax, rdx
0003899d  48d1f8                   sar rax, 1
000389a0  4c3bc0                   cmp r8, rax
000389a3  7e0f                     jle 0x389b4
000389a5  41bd01000000             mov r13d, 1
000389ab  4c3b8790000000           cmp r8, qword ptr [rdi + 0x90]
000389b2  7f03                     jg 0x389b7
000389b4  4d8bee                   mov r13, r14
000389b7  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000389c0  8b050ac62d00             mov eax, dword ptr [rip + 0x2dc60a]
000389c6  8b1dec8efcff             mov ebx, dword ptr [rip - 0x37114]
000389cc  48031cc1                 add rbx, qword ptr [rcx + rax*8]
000389d0  488b8300010000           mov rax, qword ptr [rbx + 0x100]
000389d7  4885c0                   test rax, rax
000389da  750e                     jne 0x389ea
000389dc  33c9                     xor ecx, ecx
000389de  e82db7ffff               call 0x34110
000389e3  488b8300010000           mov rax, qword ptr [rbx + 0x100]
000389ea  488b80e0030000           mov rax, qword ptr [rax + 0x3e0]
000389f1  4c89a42480000000         mov qword ptr [rsp + 0x80], r12
000389f9  4885c0                   test rax, rax
000389fc  0f84739c0600             je 0xa2675
00038a02  f6802006000004           test byte ptr [rax + 0x620], 4
00038a09  4c8da0b0030000           lea r12, [rax + 0x3b0]
00038a10  0f855f9c0600             jne 0xa2675
00038a16  4c89a424c8000000         mov qword ptr [rsp + 0xc8], r12
00038a1e  85f6                     test esi, esi
00038a20  0f857c9d0600             jne 0xa27a2
00038a26  8bdd                     mov ebx, ebp
00038a28  488b5750                 mov rdx, qword ptr [rdi + 0x50]
00038a2c  48035748                 add rdx, qword ptr [rdi + 0x48]
00038a30  48035740                 add rdx, qword ptr [rdi + 0x40]
00038a34  833d5d852e0001           cmp dword ptr [rip + 0x2e855d], 1
00038a3b  4c8b7c2468               mov r15, qword ptr [rsp + 0x68]
00038a40  4c8b742470               mov r14, qword ptr [rsp + 0x70]
00038a45  4c8b6c2478               mov r13, qword ptr [rsp + 0x78]
00038a4a  4c8ba42480000000         mov r12, qword ptr [rsp + 0x80]
00038a52  488bb42488000000         mov rsi, qword ptr [rsp + 0x88]
00038a5a  0f84da9e0600             je 0xa293a

; chunk at RVA 0x3cce0 (23 bytes)
0003cce0  488bc4                   mov rax, rsp
0003cce3  48895010                 mov qword ptr [rax + 0x10], rdx
0003cce7  53                       push rbx
0003cce8  55                       push rbp
0003cce9  57                       push rdi
0003ccea  4881ec90000000           sub rsp, 0x90
0003ccf1  e91abcffff               jmp 0x38910
0003ccf6  cc                       int3

; chunk at RVA 0xa293a (17 bytes)
000a293a  488b4768                 mov rax, qword ptr [rdi + 0x68]
000a293e  482b4760                 sub rax, qword ptr [rdi + 0x60]
000a2942  4803d0                   add rdx, rax
000a2945  e91661f9ff               jmp 0x38a60
000a294a  cc                       int3
