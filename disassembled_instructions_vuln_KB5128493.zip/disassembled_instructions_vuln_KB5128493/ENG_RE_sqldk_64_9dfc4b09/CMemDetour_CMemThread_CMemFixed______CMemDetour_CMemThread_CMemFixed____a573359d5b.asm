; CMemDetour<CMemThread<CMemFixed> >::~CMemDetour<CMemThread<CMemFixed> >
; sqldk.dll, primary RVA 0x103cf0, 59 bytes in 1 chunk(s)

; chunk at RVA 0x103cf0 (59 bytes)
00103cf0  48894c2408               mov qword ptr [rsp + 8], rcx
00103cf5  4883ec38                 sub rsp, 0x38
00103cf9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00103d02  488d05579a1400           lea rax, [rip + 0x149a57]
00103d09  488901                   mov qword ptr [rcx], rax
00103d0c  488d8120020000           lea rax, [rcx + 0x220]
00103d13  4889442448               mov qword ptr [rsp + 0x48], rax
00103d18  488d15215e1300           lea rdx, [rip + 0x135e21]
00103d1f  488910                   mov qword ptr [rax], rdx
00103d22  4883c438                 add rsp, 0x38
00103d26  e92589ffff               jmp 0xfc650
