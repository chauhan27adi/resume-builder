; XE_NotificationManager::`vector deleting destructor'
; sqldk.dll, primary RVA 0x1e1010, 63 bytes in 1 chunk(s)

; chunk at RVA 0x1e1010 (63 bytes)
001e1010  48894c2408               mov qword ptr [rsp + 8], rcx
001e1015  53                       push rbx
001e1016  4883ec30                 sub rsp, 0x30
001e101a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001e1023  488bd9                   mov rbx, rcx
001e1026  488d0513980c00           lea rax, [rip + 0xc9813]
001e102d  488901                   mov qword ptr [rcx], rax
001e1030  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
001e1037  f6c201                   test dl, 1
001e103a  740a                     je 0x1e1046
001e103c  ba18000000               mov edx, 0x18
001e1041  e8aa6de2ff               call 0x7df0
001e1046  488bc3                   mov rax, rbx
001e1049  4883c430                 add rsp, 0x30
001e104d  5b                       pop rbx
001e104e  c3                       ret
