; MemObjCache<CMemThread<CMemAligned<CMemProc> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcd6e0, 79 bytes in 1 chunk(s)

; chunk at RVA 0xcd6e0 (79 bytes)
000cd6e0  48894c2408               mov qword ptr [rsp + 8], rcx
000cd6e5  57                       push rdi
000cd6e6  4883ec30                 sub rsp, 0x30
000cd6ea  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cd6f3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cd6f8  8bda                     mov ebx, edx
000cd6fa  488bf9                   mov rdi, rcx
000cd6fd  488d055c7d1900           lea rax, [rip + 0x197d5c]
000cd704  488901                   mov qword ptr [rcx], rax
000cd707  e8a489ffff               call 0xc60b0
000cd70c  83e305                   and ebx, 5
000cd70f  80fb05                   cmp bl, 5
000cd712  750d                     jne 0xcd721
000cd714  bad0010000               mov edx, 0x1d0
000cd719  488bcf                   mov rcx, rdi
000cd71c  e8ef38f3ff               call 0x1010
000cd721  488bc7                   mov rax, rdi
000cd724  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cd729  4883c430                 add rsp, 0x30
000cd72d  5f                       pop rdi
000cd72e  c3                       ret
