; MemObjCache<CMemDbg<PageHeapMemObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e0e0, 76 bytes in 1 chunk(s)

; chunk at RVA 0x13e0e0 (76 bytes)
0013e0e0  48894c2408               mov qword ptr [rsp + 8], rcx
0013e0e5  57                       push rdi
0013e0e6  4883ec30                 sub rsp, 0x30
0013e0ea  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e0f3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e0f8  8bda                     mov ebx, edx
0013e0fa  488bf9                   mov rdi, rcx
0013e0fd  488d05f4b91000           lea rax, [rip + 0x10b9f4]
0013e104  488901                   mov qword ptr [rcx], rax
0013e107  e804430300               call 0x172410
0013e10c  f6c301                   test bl, 1
0013e10f  740d                     je 0x13e11e
0013e111  baa0040000               mov edx, 0x4a0
0013e116  488bcf                   mov rcx, rdi
0013e119  e8d29cecff               call 0x7df0
0013e11e  488bc7                   mov rax, rdi
0013e121  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e126  4883c430                 add rsp, 0x30
0013e12a  5f                       pop rdi
0013e12b  c3                       ret
