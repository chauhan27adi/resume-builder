; SOS_Mutex::~SOS_Mutex
; sqldk.dll, primary RVA 0x55850, 32 bytes in 1 chunk(s)

; chunk at RVA 0x55850 (32 bytes)
00055850  48894c2408               mov qword ptr [rsp + 8], rcx
00055855  4883ec18                 sub rsp, 0x18
00055859  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00055861  488d05d8421e00           lea rax, [rip + 0x1e42d8]
00055868  488901                   mov qword ptr [rcx], rax
0005586b  4883c418                 add rsp, 0x18
0005586f  c3                       ret
