; CMemDbg<CMemFixed>::~CMemDbg<CMemFixed>
; sqldk.dll, primary RVA 0x170f70, 99 bytes in 1 chunk(s)

; chunk at RVA 0x170f70 (99 bytes)
00170f70  48894c2408               mov qword ptr [rsp + 8], rcx
00170f75  53                       push rbx
00170f76  4883ec30                 sub rsp, 0x30
00170f7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00170f83  488bd9                   mov rbx, rcx
00170f86  488d0583ca0d00           lea rax, [rip + 0xdca83]
00170f8d  488901                   mov qword ptr [rcx], rax
00170f90  488d05414e0f00           lea rax, [rip + 0xf4e41]
00170f97  48898118010000           mov qword ptr [rcx + 0x118], rax
00170f9e  488d0513610d00           lea rax, [rip + 0xd6113]
00170fa5  488901                   mov qword ptr [rcx], rax
00170fa8  488d0559620d00           lea rax, [rip + 0xd6259]
00170faf  488901                   mov qword ptr [rcx], rax
00170fb2  4883c138                 add rcx, 0x38
00170fb6  e83512eaff               call 0x121f0
00170fbb  90                       nop
00170fbc  488d4b30                 lea rcx, [rbx + 0x30]
00170fc0  e82b12eaff               call 0x121f0
00170fc5  90                       nop
00170fc6  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
00170fcd  4883c430                 add rsp, 0x30
00170fd1  5b                       pop rbx
00170fd2  c3                       ret
