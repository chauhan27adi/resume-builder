; AutoSpinlockHolder<24,1,268435714>::~AutoSpinlockHolder<24,1,268435714>
; sqldk.dll, primary RVA 0x88b20, 27 bytes in 1 chunk(s)

; chunk at RVA 0x88b20 (27 bytes)
00088b20  48894c2408               mov qword ptr [rsp + 8], rcx
00088b25  4883ec38                 sub rsp, 0x38
00088b29  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00088b32  4883c438                 add rsp, 0x38
00088b36  e915c2f9ff               jmp 0x24d50
