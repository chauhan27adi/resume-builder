; MemObjCache<CMemDbg<CMemProc> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13dcc0, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13dcc0 (79 bytes)
0013dcc0  48894c2408               mov qword ptr [rsp + 8], rcx
0013dcc5  57                       push rdi
0013dcc6  4883ec30                 sub rsp, 0x30
0013dcca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013dcd3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013dcd8  8bda                     mov ebx, edx
0013dcda  488bf9                   mov rdi, rcx
0013dcdd  488d05dccc1000           lea rax, [rip + 0x10ccdc]
0013dce4  488901                   mov qword ptr [rcx], rax
0013dce7  e8f41d0300               call 0x16fae0
0013dcec  83e305                   and ebx, 5
0013dcef  80fb05                   cmp bl, 5
0013dcf2  750d                     jne 0x13dd01
0013dcf4  bac0040000               mov edx, 0x4c0
0013dcf9  488bcf                   mov rcx, rdi
0013dcfc  e80f33ecff               call 0x1010
0013dd01  488bc7                   mov rax, rdi
0013dd04  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013dd09  4883c430                 add rsp, 0x30
0013dd0d  5f                       pop rdi
0013dd0e  c3                       ret
