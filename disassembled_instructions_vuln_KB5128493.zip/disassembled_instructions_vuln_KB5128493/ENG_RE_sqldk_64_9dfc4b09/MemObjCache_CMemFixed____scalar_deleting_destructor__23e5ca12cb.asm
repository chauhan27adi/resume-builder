; MemObjCache<CMemFixed>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e4f0, 121 bytes in 1 chunk(s)

; chunk at RVA 0x13e4f0 (121 bytes)
0013e4f0  48894c2408               mov qword ptr [rsp + 8], rcx
0013e4f5  57                       push rdi
0013e4f6  4883ec30                 sub rsp, 0x30
0013e4fa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e503  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e508  8bda                     mov ebx, edx
0013e50a  488bf9                   mov rdi, rcx
0013e50d  488d057cac1000           lea rax, [rip + 0x10ac7c]
0013e514  488901                   mov qword ptr [rcx], rax
0013e517  488d059a8b1000           lea rax, [rip + 0x108b9a]
0013e51e  488901                   mov qword ptr [rcx], rax
0013e521  488d05e08c1000           lea rax, [rip + 0x108ce0]
0013e528  488901                   mov qword ptr [rcx], rax
0013e52b  4883c138                 add rcx, 0x38
0013e52f  e8bc3cedff               call 0x121f0
0013e534  90                       nop
0013e535  488d4f30                 lea rcx, [rdi + 0x30]
0013e539  e8b23cedff               call 0x121f0
0013e53e  90                       nop
0013e53f  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013e546  83e305                   and ebx, 5
0013e549  80fb05                   cmp bl, 5
0013e54c  750d                     jne 0x13e55b
0013e54e  ba58010000               mov edx, 0x158
0013e553  488bcf                   mov rcx, rdi
0013e556  e8b52aecff               call 0x1010
0013e55b  488bc7                   mov rax, rdi
0013e55e  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e563  4883c430                 add rsp, 0x30
0013e567  5f                       pop rdi
0013e568  c3                       ret
