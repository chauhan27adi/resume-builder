; `XE_Engine::Initialize'::`1'::dtor$2
; sqldk.dll, primary RVA 0x233f54, 56 bytes in 1 chunk(s)

; chunk at RVA 0x233f54 (56 bytes)
00233f54  4055                     push rbp
00233f56  4883ec30                 sub rsp, 0x30
00233f5a  488bea                   mov rbp, rdx
00233f5d  c644242806               mov byte ptr [rsp + 0x28], 6
00233f62  8b4530                   mov eax, dword ptr [rbp + 0x30]
00233f65  89442420                 mov dword ptr [rsp + 0x20], eax
00233f69  4c8d0d30680700           lea r9, [rip + 0x76830]
00233f70  41b801000000             mov r8d, 1
00233f76  488b1503e71700           mov rdx, qword ptr [rip + 0x17e703]
00233f7d  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00233f81  e83a5ffaff               call 0x1d9ec0
00233f86  4883c430                 add rsp, 0x30
00233f8a  5d                       pop rbp
00233f8b  c3                       ret
