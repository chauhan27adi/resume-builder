; XE_Tls::AllocateRecord
; sqldk.dll, primary RVA 0x34660, 373 bytes in 4 chunk(s)

; chunk at RVA 0x345af (163 bytes)
000345af  48895c2420               mov qword ptr [rsp + 0x20], rbx
000345b4  e877c91a00               call 0x1e0f30
000345b9  488bd8                   mov rbx, rax
000345bc  4885c0                   test rax, rax
000345bf  0f8449c91a00             je 0x1e0f0e
000345c5  0faee8                   lfence
000345c8  448bcd                   mov r9d, ebp
000345cb  0f1f440000               nop dword ptr [rax + rax]
000345d0  418bc9                   mov ecx, r9d
000345d3  4c8d048b                 lea r8, [rbx + rcx*4]
000345d7  660f1f840000000000       nop word ptr [rax + rax]
000345e0  418b00                   mov eax, dword ptr [r8]
000345e3  8bc8                     mov ecx, eax
000345e5  f7d1                     not ecx
000345e7  8bd1                     mov edx, ecx
000345e9  f7da                     neg edx
000345eb  23d1                     and edx, ecx
000345ed  0f84f7c81a00             je 0x1e0eea
000345f3  8bca                     mov ecx, edx
000345f5  0bc8                     or ecx, eax
000345f7  f0410fb108               lock cmpxchg dword ptr [r8], ecx
000345fc  75e2                     jne 0x345e0
000345fe  0fbcc2                   bsf eax, edx
00034601  41c1e105                 shl r9d, 5
00034605  89442458                 mov dword ptr [rsp + 0x58], eax
00034609  428d2c08                 lea ebp, [rax + r9]
0003460d  4881c5820b0000           add rbp, 0xb82
00034614  48c1e506                 shl rbp, 6
00034618  4803eb                   add rbp, rbx
0003461b  8bc6                     mov eax, esi
0003461d  498d0cc6                 lea rcx, [r14 + rax*8]
00034621  33c0                     xor eax, eax
00034623  f0480fb119               lock cmpxchg qword ptr [rcx], rbx
00034628  0f84cec81a00             je 0x1e0efc
0003462e  ff15c44a2000             call qword ptr [rip + 0x204ac4]
00034634  4c8bc3                   mov r8, rbx
00034637  33d2                     xor edx, edx
00034639  488bc8                   mov rcx, rax
0003463c  ff15be4a2000             call qword ptr [rip + 0x204abe]
00034642  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
00034647  4883c428                 add rsp, 0x28
0003464b  415e                     pop r14
0003464d  5f                       pop rdi
0003464e  5e                       pop rsi
0003464f  5d                       pop rbp
00034650  eb0e                     jmp 0x34660

; chunk at RVA 0x34660 (156 bytes)
00034660  4055                     push rbp
00034662  56                       push rsi
00034663  57                       push rdi
00034664  4156                     push r14
00034666  4883ec28                 sub rsp, 0x28
0003466a  33ed                     xor ebp, ebp
0003466c  4c8d35ed033100           lea r14, [rip + 0x3103ed]
00034673  8bfd                     mov edi, ebp
00034675  8bf5                     mov esi, ebp
00034677  81fe00010000             cmp esi, 0x100
0003467d  7370                     jae 0x346ef
0003467f  8bc6                     mov eax, esi
00034681  4d8b1cc6                 mov r11, qword ptr [r14 + rax*8]
00034685  4d85db                   test r11, r11
00034688  0f840cffffff             je 0x3459a
0003468e  488bfd                   mov rdi, rbp
00034691  448bd5                   mov r10d, ebp
00034694  418bc2                   mov eax, r10d
00034697  4d8d0c83                 lea r9, [r11 + rax*4]
0003469b  0f1f440000               nop dword ptr [rax + rax]
000346a0  458b01                   mov r8d, dword ptr [r9]
000346a3  418bc0                   mov eax, r8d
000346a6  f7d0                     not eax
000346a8  8bc8                     mov ecx, eax
000346aa  f7d9                     neg ecx
000346ac  23c8                     and ecx, eax
000346ae  750c                     jne 0x346bc
000346b0  41ffc2                   inc r10d
000346b3  4183fa20                 cmp r10d, 0x20
000346b7  72db                     jb 0x34694
000346b9  eb2d                     jmp 0x346e8
000346bb  cc                       int3
000346bc  8bd1                     mov edx, ecx
000346be  418bc0                   mov eax, r8d
000346c1  410bd0                   or edx, r8d
000346c4  f0410fb111               lock cmpxchg dword ptr [r9], edx
000346c9  75d5                     jne 0x346a0
000346cb  0fbcc1                   bsf eax, ecx
000346ce  41c1e205                 shl r10d, 5
000346d2  89442450                 mov dword ptr [rsp + 0x50], eax
000346d6  428d3c10                 lea edi, [rax + r10]
000346da  4881c7820b0000           add rdi, 0xb82
000346e1  48c1e706                 shl rdi, 6
000346e5  4903fb                   add rdi, r11
000346e8  ffc6                     inc esi
000346ea  4885ff                   test rdi, rdi
000346ed  7488                     je 0x34677
000346ef  488bc7                   mov rax, rdi
000346f2  4883c428                 add rsp, 0x28
000346f6  415e                     pop r14
000346f8  5f                       pop rdi
000346f9  5e                       pop rsi
000346fa  5d                       pop rbp
000346fb  c3                       ret

; chunk at RVA 0x1e0eea (36 bytes)
001e0eea  41ffc1                   inc r9d
001e0eed  4183f920                 cmp r9d, 0x20
001e0ef1  0f82d936e5ff             jb 0x345d0
001e0ef7  e91f37e5ff               jmp 0x3461b
001e0efc  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
001e0f01  488bc5                   mov rax, rbp
001e0f04  4883c428                 add rsp, 0x28
001e0f08  415e                     pop r14
001e0f0a  5f                       pop rdi
001e0f0b  5e                       pop rsi
001e0f0c  5d                       pop rbp
001e0f0d  c3                       ret

; chunk at RVA 0x1e0f0e (18 bytes)
001e0f0e  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
001e0f13  488bc7                   mov rax, rdi
001e0f16  4883c428                 add rsp, 0x28
001e0f1a  415e                     pop r14
001e0f1c  5f                       pop rdi
001e0f1d  5e                       pop rsi
001e0f1e  5d                       pop rbp
001e0f1f  c3                       ret
