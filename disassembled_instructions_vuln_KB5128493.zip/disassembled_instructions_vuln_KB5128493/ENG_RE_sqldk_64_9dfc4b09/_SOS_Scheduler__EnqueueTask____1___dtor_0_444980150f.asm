; `SOS_Scheduler::EnqueueTask'::`1'::dtor$0
; sqldk.dll, primary RVA 0x219e20, 69 bytes in 1 chunk(s)

; chunk at RVA 0x219e20 (69 bytes)
00219e20  4055                     push rbp
00219e22  4883ec30                 sub rsp, 0x30
00219e26  488bea                   mov rbp, rdx
00219e29  488b95e0000000           mov rdx, qword ptr [rbp + 0xe0]
00219e30  4881c2780e0000           add rdx, 0xe78
00219e37  c644242806               mov byte ptr [rsp + 0x28], 6
00219e3c  8b85f8000000             mov eax, dword ptr [rbp + 0xf8]
00219e42  89442420                 mov dword ptr [rsp + 0x20], eax
00219e46  4c8d0d03bd0400           lea r9, [rip + 0x4bd03]
00219e4d  41b801000000             mov r8d, 1
00219e53  488b12                   mov rdx, qword ptr [rdx]
00219e56  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
00219e5a  e841dfdeff               call 0x7da0
00219e5f  4883c430                 add rsp, 0x30
00219e63  5d                       pop rbp
00219e64  c3                       ret
