; XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker>::~XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker>
; sqldk.dll, primary RVA 0x1be2e0, 309 bytes in 1 chunk(s)

; chunk at RVA 0x1be2e0 (309 bytes)
001be2e0  48894c2408               mov qword ptr [rsp + 8], rcx
001be2e5  53                       push rbx
001be2e6  56                       push rsi
001be2e7  57                       push rdi
001be2e8  4883ec30                 sub rsp, 0x30
001be2ec  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001be2f5  488bf9                   mov rdi, rcx
001be2f8  488d0539ce0b00           lea rax, [rip + 0xbce39]
001be2ff  488901                   mov qword ptr [rcx], rax
001be302  488db168060000           lea rsi, [rcx + 0x668]
001be309  48833e00                 cmp qword ptr [rsi], 0
001be30d  7464                     je 0x1be373
001be30f  33db                     xor ebx, ebx
001be311  488b4128                 mov rax, qword ptr [rcx + 0x28]
001be315  3918                     cmp dword ptr [rax], ebx
001be317  7635                     jbe 0x1be34e
001be319  0f1f00                   nop dword ptr [rax]
001be31c  0f1f4000                 nop dword ptr [rax]
001be320  488d0cdd00000000         lea rcx, [rbx*8]
001be328  488b06                   mov rax, qword ptr [rsi]
001be32b  4c8b0401                 mov r8, qword ptr [rcx + rax]
001be32f  4d85c0                   test r8, r8
001be332  7410                     je 0x1be344
001be334  4d8b8088020000           mov r8, qword ptr [r8 + 0x288]
001be33b  488b1401                 mov rdx, qword ptr [rcx + rax]
001be33f  e8bc060000               call 0x1bea00
001be344  ffc3                     inc ebx
001be346  488b4728                 mov rax, qword ptr [rdi + 0x28]
001be34a  3b18                     cmp ebx, dword ptr [rax]
001be34c  72d2                     jb 0x1be320
001be34e  4883bf8807000000         cmp qword ptr [rdi + 0x788], 0
001be356  741b                     je 0x1be373
001be358  4c8b8770060000           mov r8, qword ptr [rdi + 0x670]
001be35f  4d8b8088020000           mov r8, qword ptr [r8 + 0x288]
001be366  488b9770060000           mov rdx, qword ptr [rdi + 0x670]
001be36d  e88e060000               call 0x1bea00
001be372  90                       nop
001be373  488b8fa0070000           mov rcx, qword ptr [rdi + 0x7a0]
001be37a  4883f9ff                 cmp rcx, -1
001be37e  7407                     je 0x1be387
001be380  ff154a6e1500             call qword ptr [rip + 0x156e4a]
001be386  90                       nop
001be387  488d8768070000           lea rax, [rdi + 0x768]
001be38e  4889442458               mov qword ptr [rsp + 0x58], rax
001be393  488d5810                 lea rbx, [rax + 0x10]
001be397  48895c2460               mov qword ptr [rsp + 0x60], rbx
001be39c  488b0b                   mov rcx, qword ptr [rbx]
001be39f  e8dca8e8ff               call 0x48c80
001be3a4  48c70300000000           mov qword ptr [rbx], 0
001be3ab  488bcb                   mov rcx, rbx
001be3ae  e82da6e8ff               call 0x489e0
001be3b3  90                       nop
001be3b4  4889742468               mov qword ptr [rsp + 0x68], rsi
001be3b9  488b0e                   mov rcx, qword ptr [rsi]
001be3bc  e8ef1f0000               call 0x1c03b0
001be3c1  48c70600000000           mov qword ptr [rsi], 0
001be3c8  488b0e                   mov rcx, qword ptr [rsi]
001be3cb  4885c9                   test rcx, rcx
001be3ce  742c                     je 0x1be3fc
001be3d0  488d59f8                 lea rbx, [rcx - 8]
001be3d4  4c8d0d3593e8ff           lea r9, [rip - 0x176ccb]
001be3db  4c8b03                   mov r8, qword ptr [rbx]
001be3de  ba08000000               mov edx, 8
001be3e3  e87808e7ff               call 0x2ec60
001be3e8  488b13                   mov rdx, qword ptr [rbx]
001be3eb  488d14d508000000         lea rdx, [rdx*8 + 8]
001be3f3  488bcb                   mov rcx, rbx
001be3f6  e8f599e4ff               call 0x7df0
001be3fb  90                       nop
001be3fc  488d4f10                 lea rcx, [rdi + 0x10]
001be400  48894c2450               mov qword ptr [rsp + 0x50], rcx
001be405  4883c118                 add rcx, 0x18
001be409  4883c430                 add rsp, 0x30
001be40d  5f                       pop rdi
001be40e  5e                       pop rsi
001be40f  5b                       pop rbx
001be410  e9bb93e8ff               jmp 0x477d0
