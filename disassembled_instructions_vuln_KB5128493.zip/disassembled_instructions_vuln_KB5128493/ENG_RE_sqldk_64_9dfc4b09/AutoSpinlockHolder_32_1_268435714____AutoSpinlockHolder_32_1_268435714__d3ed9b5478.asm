; AutoSpinlockHolder<32,1,268435714>::~AutoSpinlockHolder<32,1,268435714>
; sqldk.dll, primary RVA 0x6bbb0, 111 bytes in 1 chunk(s)

; chunk at RVA 0x6bbb0 (111 bytes)
0006bbb0  48894c2408               mov qword ptr [rsp + 8], rcx
0006bbb5  57                       push rdi
0006bbb6  4883ec30                 sub rsp, 0x30
0006bbba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0006bbc3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0006bbc8  488bd9                   mov rbx, rcx
0006bbcb  488b39                   mov rdi, qword ptr [rcx]
0006bbce  4885ff                   test rdi, rdi
0006bbd1  7441                     je 0x6bc14
0006bbd3  83790800                 cmp dword ptr [rcx + 8], 0
0006bbd7  743b                     je 0x6bc14
0006bbd9  803de1982a0000           cmp byte ptr [rip + 0x2a98e1], 0
0006bbe0  7427                     je 0x6bc09
0006bbe2  ff1560de1c00             call qword ptr [rip + 0x1cde60]
0006bbe8  448bc0                   mov r8d, eax
0006bbeb  b867666666               mov eax, 0x66666667
0006bbf0  41f7e8                   imul r8d
0006bbf3  d1fa                     sar edx, 1
0006bbf5  8bca                     mov ecx, edx
0006bbf7  c1e91f                   shr ecx, 0x1f
0006bbfa  03d1                     add edx, ecx
0006bbfc  8d0c92                   lea ecx, [rdx + rdx*4]
0006bbff  443bc1                   cmp r8d, ecx
0006bc02  7505                     jne 0x6bc09
0006bc04  e8f7720000               call 0x72f00
0006bc09  33c0                     xor eax, eax
0006bc0b  488907                   mov qword ptr [rdi], rax
0006bc0e  488903                   mov qword ptr [rbx], rax
0006bc11  894308                   mov dword ptr [rbx + 8], eax
0006bc14  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0006bc19  4883c430                 add rsp, 0x30
0006bc1d  5f                       pop rdi
0006bc1e  c3                       ret
