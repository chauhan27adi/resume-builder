; MemObjCache<CMemThread<CMemAligned<CMemDbg<CMemFixed> > > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e800, 128 bytes in 1 chunk(s)

; chunk at RVA 0x13e800 (128 bytes)
0013e800  48894c2408               mov qword ptr [rsp + 8], rcx
0013e805  57                       push rdi
0013e806  4883ec30                 sub rsp, 0x30
0013e80a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e813  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e818  8bda                     mov ebx, edx
0013e81a  488bf9                   mov rdi, rcx
0013e81d  488d05dc661200           lea rax, [rip + 0x1266dc]
0013e824  488901                   mov qword ptr [rcx], rax
0013e827  488d056aad1000           lea rax, [rip + 0x10ad6a]
0013e82e  488901                   mov qword ptr [rcx], rax
0013e831  488d81e0040000           lea rax, [rcx + 0x4e0]
0013e838  4889442450               mov qword ptr [rsp + 0x50], rax
0013e83d  488d0dfcb20f00           lea rcx, [rip + 0xfb2fc]
0013e844  48894830                 mov qword ptr [rax + 0x30], rcx
0013e848  488908                   mov qword ptr [rax], rcx
0013e84b  488d05d6ca1000           lea rax, [rip + 0x10cad6]
0013e852  488907                   mov qword ptr [rdi], rax
0013e855  488bcf                   mov rcx, rdi
0013e858  e813270300               call 0x170f70
0013e85d  83e305                   and ebx, 5
0013e860  80fb05                   cmp bl, 5
0013e863  750d                     jne 0x13e872
0013e865  ba08060000               mov edx, 0x608
0013e86a  488bcf                   mov rcx, rdi
0013e86d  e89e27ecff               call 0x1010
0013e872  488bc7                   mov rax, rdi
0013e875  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e87a  4883c430                 add rsp, 0x30
0013e87e  5f                       pop rdi
0013e87f  c3                       ret
