; OstreamStreamBuf::`vector deleting destructor'
; sqldk.dll, primary RVA 0x57a70, 67 bytes in 1 chunk(s)

; chunk at RVA 0x57a70 (67 bytes)
00057a70  48894c2408               mov qword ptr [rsp + 8], rcx
00057a75  57                       push rdi
00057a76  4883ec30                 sub rsp, 0x30
00057a7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00057a83  48895c2448               mov qword ptr [rsp + 0x48], rbx
00057a88  8bda                     mov ebx, edx
00057a8a  488bf9                   mov rdi, rcx
00057a8d  ff15351d1e00             call qword ptr [rip + 0x1e1d35]
00057a93  f6c301                   test bl, 1
00057a96  740d                     je 0x57aa5
00057a98  ba70010000               mov edx, 0x170
00057a9d  488bcf                   mov rcx, rdi
00057aa0  e84b03fbff               call 0x7df0
00057aa5  488bc7                   mov rax, rdi
00057aa8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00057aad  4883c430                 add rsp, 0x30
00057ab1  5f                       pop rdi
00057ab2  c3                       ret
