; AutoPermanentTaskLeakDetection::~AutoPermanentTaskLeakDetection
; sqldk.dll, primary RVA 0x732e0, 598 bytes in 1 chunk(s)

; chunk at RVA 0x732e0 (598 bytes)
000732e0  4053                     push rbx
000732e2  4883ec20                 sub rsp, 0x20
000732e6  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000732ef  8b05db1c2a00             mov eax, dword ptr [rip + 0x2a1cdb]
000732f5  8b1dbde5f8ff             mov ebx, dword ptr [rip - 0x71a43]
000732fb  48031cc1                 add rbx, qword ptr [rcx + rax*8]
000732ff  488b8b00010000           mov rcx, qword ptr [rbx + 0x100]
00073306  4885c9                   test rcx, rcx
00073309  750c                     jne 0x73317
0007330b  e8000efcff               call 0x34110
00073310  488b8b00010000           mov rcx, qword ptr [rbx + 0x100]
00073317  488b8958020000           mov rcx, qword ptr [rcx + 0x258]
0007331e  488d1d9bdd2a00           lea rbx, [rip + 0x2add9b]
00073325  4533c9                   xor r9d, r9d
00073328  0f1f840000000000         nop dword ptr [rax + rax]
00073330  4e8b94c9c8010000         mov r10, qword ptr [rcx + r9*8 + 0x1c8]
00073338  458bd9                   mov r11d, r9d
0007333b  4d85d2                   test r10, r10
0007333e  744f                     je 0x7338f
00073340  498bc2                   mov rax, r10
00073343  4899                     cqo
00073345  81e2ff1f0000             and edx, 0x1fff
0007334b  4803c2                   add rax, rdx
0007334e  48c1f80d                 sar rax, 0xd
00073352  488bd0                   mov rdx, rax
00073355  4d69c380030000           imul r8, r11, 0x380
0007335c  48f7da                   neg rdx
0007335f  f0490fc1941848030000     lock xadd qword ptr [r8 + rbx + 0x348], rdx
00073369  f0490fc1841808010000     lock xadd qword ptr [r8 + rbx + 0x108], rax
00073373  4c2991b0010000           sub qword ptr [rcx + 0x1b0], r10
0007337a  4183f940                 cmp r9d, 0x40
0007337e  7408                     je 0x73388
00073380  4e2994c9c8010000         sub qword ptr [rcx + r9*8 + 0x1c8], r10
00073388  4c2991c0010000           sub qword ptr [rcx + 0x1c0], r10
0007338f  4183f93f                 cmp r9d, 0x3f
00073393  740e                     je 0x733a3
00073395  418d4101                 lea eax, [r9 + 1]
00073399  4c8b94c1c8010000         mov r10, qword ptr [rcx + rax*8 + 0x1c8]
000733a1  eb07                     jmp 0x733aa
000733a3  4c8b91b0010000           mov r10, qword ptr [rcx + 0x1b0]
000733aa  4d85d2                   test r10, r10
000733ad  7453                     je 0x73402
000733af  498bc2                   mov rax, r10
000733b2  458d5901                 lea r11d, [r9 + 1]
000733b6  4899                     cqo
000733b8  81e2ff1f0000             and edx, 0x1fff
000733be  4803c2                   add rax, rdx
000733c1  48c1f80d                 sar rax, 0xd
000733c5  488bd0                   mov rdx, rax
000733c8  4d69c380030000           imul r8, r11, 0x380
000733cf  48f7da                   neg rdx
000733d2  f0490fc1941848030000     lock xadd qword ptr [r8 + rbx + 0x348], rdx
000733dc  f0490fc1841808010000     lock xadd qword ptr [r8 + rbx + 0x108], rax
000733e6  4c2991b0010000           sub qword ptr [rcx + 0x1b0], r10
000733ed  4183f93f                 cmp r9d, 0x3f
000733f1  7408                     je 0x733fb
000733f3  4e2994d9c8010000         sub qword ptr [rcx + r11*8 + 0x1c8], r10
000733fb  4c2991c0010000           sub qword ptr [rcx + 0x1c0], r10
00073402  4183f93e                 cmp r9d, 0x3e
00073406  740e                     je 0x73416
00073408  418d4102                 lea eax, [r9 + 2]
0007340c  4c8b94c1c8010000         mov r10, qword ptr [rcx + rax*8 + 0x1c8]
00073414  eb07                     jmp 0x7341d
00073416  4c8b91b0010000           mov r10, qword ptr [rcx + 0x1b0]
0007341d  4d85d2                   test r10, r10
00073420  7453                     je 0x73475
00073422  498bc2                   mov rax, r10
00073425  458d5902                 lea r11d, [r9 + 2]
00073429  4899                     cqo
0007342b  81e2ff1f0000             and edx, 0x1fff
00073431  4803c2                   add rax, rdx
00073434  48c1f80d                 sar rax, 0xd
00073438  488bd0                   mov rdx, rax
0007343b  4d69c380030000           imul r8, r11, 0x380
00073442  48f7da                   neg rdx
00073445  f0490fc1941848030000     lock xadd qword ptr [r8 + rbx + 0x348], rdx
0007344f  f0490fc1841808010000     lock xadd qword ptr [r8 + rbx + 0x108], rax
00073459  4c2991b0010000           sub qword ptr [rcx + 0x1b0], r10
00073460  4183f93e                 cmp r9d, 0x3e
00073464  7408                     je 0x7346e
00073466  4e2994d9c8010000         sub qword ptr [rcx + r11*8 + 0x1c8], r10
0007346e  4c2991c0010000           sub qword ptr [rcx + 0x1c0], r10
00073475  4183f93d                 cmp r9d, 0x3d
00073479  740e                     je 0x73489
0007347b  418d4103                 lea eax, [r9 + 3]
0007347f  4c8b94c1c8010000         mov r10, qword ptr [rcx + rax*8 + 0x1c8]
00073487  eb07                     jmp 0x73490
00073489  4c8b91b0010000           mov r10, qword ptr [rcx + 0x1b0]
00073490  4d85d2                   test r10, r10
00073493  7453                     je 0x734e8
00073495  498bc2                   mov rax, r10
00073498  458d5903                 lea r11d, [r9 + 3]
0007349c  4899                     cqo
0007349e  81e2ff1f0000             and edx, 0x1fff
000734a4  4803c2                   add rax, rdx
000734a7  48c1f80d                 sar rax, 0xd
000734ab  488bd0                   mov rdx, rax
000734ae  4d69c380030000           imul r8, r11, 0x380
000734b5  48f7da                   neg rdx
000734b8  f0490fc1941848030000     lock xadd qword ptr [r8 + rbx + 0x348], rdx
000734c2  f0490fc1841808010000     lock xadd qword ptr [r8 + rbx + 0x108], rax
000734cc  4c2991b0010000           sub qword ptr [rcx + 0x1b0], r10
000734d3  4183f93d                 cmp r9d, 0x3d
000734d7  7408                     je 0x734e1
000734d9  4e2994d9c8010000         sub qword ptr [rcx + r11*8 + 0x1c8], r10
000734e1  4c2991c0010000           sub qword ptr [rcx + 0x1c0], r10
000734e8  4183c104                 add r9d, 4
000734ec  4183f940                 cmp r9d, 0x40
000734f0  0f823afeffff             jb 0x73330
000734f6  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000734ff  8b05cb1a2a00             mov eax, dword ptr [rip + 0x2a1acb]
00073505  8b1dade3f8ff             mov ebx, dword ptr [rip - 0x71c53]
0007350b  48031cc1                 add rbx, qword ptr [rcx + rax*8]
0007350f  488b8b00010000           mov rcx, qword ptr [rbx + 0x100]
00073516  4885c9                   test rcx, rcx
00073519  750c                     jne 0x73527
0007351b  e8f00bfcff               call 0x34110
00073520  488b8b00010000           mov rcx, qword ptr [rbx + 0x100]
00073527  4533c0                   xor r8d, r8d
0007352a  33d2                     xor edx, edx
0007352c  4883c420                 add rsp, 0x20
00073530  5b                       pop rbx
00073531  e95af5f9ff               jmp 0x12a90
