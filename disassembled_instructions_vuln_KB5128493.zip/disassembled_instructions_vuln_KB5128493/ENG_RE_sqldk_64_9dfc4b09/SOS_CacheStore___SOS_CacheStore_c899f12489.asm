; SOS_CacheStore::~SOS_CacheStore
; sqldk.dll, primary RVA 0x180f90, 27 bytes in 1 chunk(s)

; chunk at RVA 0x180f90 (27 bytes)
00180f90  48894c2408               mov qword ptr [rsp + 8], rcx
00180f95  4883ec38                 sub rsp, 0x38
00180f99  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00180fa2  4883c438                 add rsp, 0x38
00180fa6  e985120000               jmp 0x182230
