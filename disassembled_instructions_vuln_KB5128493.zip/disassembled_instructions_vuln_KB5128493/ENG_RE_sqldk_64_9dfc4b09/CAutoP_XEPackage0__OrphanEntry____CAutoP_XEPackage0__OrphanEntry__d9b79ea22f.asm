; CAutoP<XEPackage0::OrphanEntry>::~CAutoP<XEPackage0::OrphanEntry>
; sqldk.dll, primary RVA 0x1ccb80, 68 bytes in 1 chunk(s)

; chunk at RVA 0x1ccb80 (68 bytes)
001ccb80  4053                     push rbx
001ccb82  4883ec30                 sub rsp, 0x30
001ccb86  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001ccb8f  488b19                   mov rbx, qword ptr [rcx]
001ccb92  48895c2440               mov qword ptr [rsp + 0x40], rbx
001ccb97  4885db                   test rbx, rbx
001ccb9a  7422                     je 0x1ccbbe
001ccb9c  837b2c00                 cmp dword ptr [rbx + 0x2c], 0
001ccba0  750a                     jne 0x1ccbac
001ccba2  488b4b10                 mov rcx, qword ptr [rbx + 0x10]
001ccba6  ff15a4841400             call qword ptr [rip + 0x1484a4]
001ccbac  ba48000000               mov edx, 0x48
001ccbb1  488bcb                   mov rcx, rbx
001ccbb4  4883c430                 add rsp, 0x30
001ccbb8  5b                       pop rbx
001ccbb9  e932b2e3ff               jmp 0x7df0
001ccbbe  4883c430                 add rsp, 0x30
001ccbc2  5b                       pop rbx
001ccbc3  c3                       ret
