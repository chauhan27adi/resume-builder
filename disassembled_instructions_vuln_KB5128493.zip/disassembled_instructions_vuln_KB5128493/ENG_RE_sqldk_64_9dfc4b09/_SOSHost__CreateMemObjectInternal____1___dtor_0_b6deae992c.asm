; `SOSHost::CreateMemObjectInternal'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2295e0, 53 bytes in 1 chunk(s)

; chunk at RVA 0x2295e0 (53 bytes)
002295e0  4055                     push rbp
002295e2  4883ec30                 sub rsp, 0x30
002295e6  488bea                   mov rbp, rdx
002295e9  c644242806               mov byte ptr [rsp + 0x28], 6
002295ee  8b4530                   mov eax, dword ptr [rbp + 0x30]
002295f1  89442420                 mov dword ptr [rsp + 0x20], eax
002295f5  4c8d0de4050700           lea r9, [rip + 0x705e4]
002295fc  41b801000000             mov r8d, 1
00229602  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00229606  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0022960a  e891e7ddff               call 0x7da0
0022960f  4883c430                 add rsp, 0x30
00229613  5d                       pop rbp
00229614  c3                       ret
