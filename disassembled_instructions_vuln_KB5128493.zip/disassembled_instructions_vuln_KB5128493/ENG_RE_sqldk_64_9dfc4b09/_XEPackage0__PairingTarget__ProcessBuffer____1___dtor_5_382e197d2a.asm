; `XEPackage0::PairingTarget::ProcessBuffer'::`1'::dtor$5
; sqldk.dll, primary RVA 0x230eb4, 41 bytes in 1 chunk(s)

; chunk at RVA 0x230eb4 (41 bytes)
00230eb4  4055                     push rbp
00230eb6  4883ec20                 sub rsp, 0x20
00230eba  488bea                   mov rbp, rdx
00230ebd  4c8b8568010000           mov r8, qword ptr [rbp + 0x168]
00230ec4  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
00230ecb  488b8db0000000           mov rcx, qword ptr [rbp + 0xb0]
00230ed2  e83901ddff               call 0x1010
00230ed7  4883c420                 add rsp, 0x20
00230edb  5d                       pop rbp
00230edc  c3                       ret
