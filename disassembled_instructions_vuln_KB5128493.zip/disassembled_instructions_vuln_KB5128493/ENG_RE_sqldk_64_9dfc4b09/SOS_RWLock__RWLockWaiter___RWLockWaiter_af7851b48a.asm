; SOS_RWLock::RWLockWaiter::~RWLockWaiter
; sqldk.dll, primary RVA 0x79320, 33 bytes in 1 chunk(s)

; chunk at RVA 0x79320 (33 bytes)
00079320  48894c2408               mov qword ptr [rsp + 8], rcx
00079325  4883ec18                 sub rsp, 0x18
00079329  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00079331  488d0508081c00           lea rax, [rip + 0x1c0808]
00079338  48894118                 mov qword ptr [rcx + 0x18], rax
0007933c  4883c418                 add rsp, 0x18
00079340  c3                       ret
