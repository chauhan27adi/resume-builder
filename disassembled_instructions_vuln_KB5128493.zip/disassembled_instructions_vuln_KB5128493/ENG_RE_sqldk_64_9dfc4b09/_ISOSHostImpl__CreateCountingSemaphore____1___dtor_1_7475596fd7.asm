; `ISOSHostImpl::CreateCountingSemaphore'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22b4d4, 56 bytes in 1 chunk(s)

; chunk at RVA 0x22b4d4 (56 bytes)
0022b4d4  4055                     push rbp
0022b4d6  4883ec30                 sub rsp, 0x30
0022b4da  488bea                   mov rbp, rdx
0022b4dd  c644242806               mov byte ptr [rsp + 0x28], 6
0022b4e2  8b4530                   mov eax, dword ptr [rbp + 0x30]
0022b4e5  89442420                 mov dword ptr [rsp + 0x20], eax
0022b4e9  4c8d0df0e60600           lea r9, [rip + 0x6e6f0]
0022b4f0  41b801000000             mov r8d, 1
0022b4f6  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0022b4fd  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0022b501  e89ac8ddff               call 0x7da0
0022b506  4883c430                 add rsp, 0x30
0022b50a  5d                       pop rbp
0022b50b  c3                       ret
