; SOSHost_AutoRecursiveMutex::~SOSHost_AutoRecursiveMutex
; sqldk.dll, primary RVA 0x1ea690, 68 bytes in 3 chunk(s)

; chunk at RVA 0x1ea690 (15 bytes)
001ea690  4053                     push rbx
001ea692  4883ec20                 sub rsp, 0x20
001ea696  83791000                 cmp dword ptr [rcx + 0x10], 0
001ea69a  488bd9                   mov rbx, rcx
001ea69d  762f                     jbe 0x1ea6ce

; chunk at RVA 0x1ea69f (47 bytes)
001ea69f  48897c2430               mov qword ptr [rsp + 0x30], rdi
001ea6a4  33ff                     xor edi, edi
001ea6a6  488b0b                   mov rcx, qword ptr [rbx]
001ea6a9  4883694001               sub qword ptr [rcx + 0x40], 1
001ea6ae  7513                     jne 0x1ea6c3
001ea6b0  f0093c24                 lock or dword ptr [rsp], edi
001ea6b4  33d2                     xor edx, edx
001ea6b6  48897930                 mov qword ptr [rcx + 0x30], rdi
001ea6ba  48897938                 mov qword ptr [rcx + 0x38], rdi
001ea6be  e86db7e1ff               call 0x5e30
001ea6c3  834310ff                 add dword ptr [rbx + 0x10], -1
001ea6c7  75dd                     jne 0x1ea6a6
001ea6c9  488b7c2430               mov rdi, qword ptr [rsp + 0x30]

; chunk at RVA 0x1ea6ce (6 bytes)
001ea6ce  4883c420                 add rsp, 0x20
001ea6d2  5b                       pop rbx
001ea6d3  c3                       ret
