; `NodeManager::InitNode'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21c800, 53 bytes in 1 chunk(s)

; chunk at RVA 0x21c800 (53 bytes)
0021c800  4055                     push rbp
0021c802  4883ec30                 sub rsp, 0x30
0021c806  488bea                   mov rbp, rdx
0021c809  c644242806               mov byte ptr [rsp + 0x28], 6
0021c80e  8b4540                   mov eax, dword ptr [rbp + 0x40]
0021c811  89442420                 mov dword ptr [rsp + 0x20], eax
0021c815  4c8d0d9cc50700           lea r9, [rip + 0x7c59c]
0021c81c  41b801000000             mov r8d, 1
0021c822  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0021c826  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
0021c82a  e871b5deff               call 0x7da0
0021c82f  4883c430                 add rsp, 0x30
0021c833  5d                       pop rbp
0021c834  c3                       ret
