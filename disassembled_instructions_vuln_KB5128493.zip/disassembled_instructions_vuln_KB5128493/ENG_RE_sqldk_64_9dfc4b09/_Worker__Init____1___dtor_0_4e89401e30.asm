; `Worker::Init'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21aee0, 66 bytes in 1 chunk(s)

; chunk at RVA 0x21aee0 (66 bytes)
0021aee0  4055                     push rbp
0021aee2  4883ec30                 sub rsp, 0x30
0021aee6  488bea                   mov rbp, rdx
0021aee9  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0021aeed  4881c2e8030000           add rdx, 0x3e8
0021aef4  c644242806               mov byte ptr [rsp + 0x28], 6
0021aef9  8b8588000000             mov eax, dword ptr [rbp + 0x88]
0021aeff  89442420                 mov dword ptr [rsp + 0x20], eax
0021af03  4c8d0d86f50500           lea r9, [rip + 0x5f586]
0021af0a  41b801000000             mov r8d, 1
0021af10  488b12                   mov rdx, qword ptr [rdx]
0021af13  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
0021af17  e884cedeff               call 0x7da0
0021af1c  4883c430                 add rsp, 0x30
0021af20  5d                       pop rbp
0021af21  c3                       ret
