; `XE_StubSession::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x23530e, 56 bytes in 1 chunk(s)

; chunk at RVA 0x23530e (56 bytes)
0023530e  4055                     push rbp
00235310  4883ec30                 sub rsp, 0x30
00235314  488bea                   mov rbp, rdx
00235317  c644242806               mov byte ptr [rsp + 0x28], 6
0023531c  8b4530                   mov eax, dword ptr [rbp + 0x30]
0023531f  89442420                 mov dword ptr [rsp + 0x20], eax
00235323  4c8d0dde550700           lea r9, [rip + 0x755de]
0023532a  41b801000000             mov r8d, 1
00235330  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
00235337  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
0023533b  e8804bfaff               call 0x1d9ec0
00235340  4883c430                 add rsp, 0x30
00235344  5d                       pop rbp
00235345  c3                       ret
