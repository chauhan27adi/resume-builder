; `XEPackage0::HistoryTarget::InitDictionary'::`1'::dtor$5
; sqldk.dll, primary RVA 0x232a0d, 45 bytes in 1 chunk(s)

; chunk at RVA 0x232a0d (45 bytes)
00232a0d  4055                     push rbp
00232a0f  4883ec20                 sub rsp, 0x20
00232a13  488bea                   mov rbp, rdx
00232a16  4c8b85f0000000           mov r8, qword ptr [rbp + 0xf0]
00232a1d  4981c030200000           add r8, 0x2030
00232a24  4d8b00                   mov r8, qword ptr [r8]
00232a27  488b5558                 mov rdx, qword ptr [rbp + 0x58]
00232a2b  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00232a2f  e8dce5dcff               call 0x1010
00232a34  4883c420                 add rsp, 0x20
00232a38  5d                       pop rbp
00232a39  c3                       ret
