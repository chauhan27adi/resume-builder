; CAutoRefc<XList<XE_EventEntry> >::~CAutoRefc<XList<XE_EventEntry> >
; sqldk.dll, primary RVA 0x1dc280, 63 bytes in 1 chunk(s)

; chunk at RVA 0x1dc280 (63 bytes)
001dc280  4883ec38                 sub rsp, 0x38
001dc284  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001dc28d  488b09                   mov rcx, qword ptr [rcx]
001dc290  4885c9                   test rcx, rcx
001dc293  7425                     je 0x1dc2ba
001dc295  b8ffffffff               mov eax, 0xffffffff
001dc29a  f00fc101                 lock xadd dword ptr [rcx], eax
001dc29e  83f801                   cmp eax, 1
001dc2a1  7517                     jne 0x1dc2ba
001dc2a3  48894c2440               mov qword ptr [rsp + 0x40], rcx
001dc2a8  c701adde0080             mov dword ptr [rcx], 0x8000dead
001dc2ae  8d502f                   lea edx, [rax + 0x2f]
001dc2b1  4883c438                 add rsp, 0x38
001dc2b5  e936bbe2ff               jmp 0x7df0
001dc2ba  4883c438                 add rsp, 0x38
001dc2be  c3                       ret
