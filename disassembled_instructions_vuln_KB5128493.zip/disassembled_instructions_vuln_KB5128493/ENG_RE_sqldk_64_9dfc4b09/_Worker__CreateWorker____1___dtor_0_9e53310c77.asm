; `Worker::CreateWorker'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21af30, 59 bytes in 1 chunk(s)

; chunk at RVA 0x21af30 (59 bytes)
0021af30  4055                     push rbp
0021af32  4883ec30                 sub rsp, 0x30
0021af36  488bea                   mov rbp, rdx
0021af39  c644242806               mov byte ptr [rsp + 0x28], 6
0021af3e  8b8598000000             mov eax, dword ptr [rbp + 0x98]
0021af44  89442420                 mov dword ptr [rsp + 0x20], eax
0021af48  4c8d0d41f50500           lea r9, [rip + 0x5f541]
0021af4f  41b801000000             mov r8d, 1
0021af55  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0021af5c  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0021af60  e83bcedeff               call 0x7da0
0021af65  4883c430                 add rsp, 0x30
0021af69  5d                       pop rbp
0021af6a  c3                       ret
