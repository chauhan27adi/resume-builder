; `XE_AssocMemory::Add'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235ac0, 53 bytes in 1 chunk(s)

; chunk at RVA 0x235ac0 (53 bytes)
00235ac0  4055                     push rbp
00235ac2  4883ec30                 sub rsp, 0x30
00235ac6  488bea                   mov rbp, rdx
00235ac9  c644242806               mov byte ptr [rsp + 0x28], 6
00235ace  8b4570                   mov eax, dword ptr [rbp + 0x70]
00235ad1  89442420                 mov dword ptr [rsp + 0x20], eax
00235ad5  4c8d0d8c4e0700           lea r9, [rip + 0x74e8c]
00235adc  41b801000000             mov r8d, 1
00235ae2  488b5578                 mov rdx, qword ptr [rbp + 0x78]
00235ae6  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00235aea  e8d143faff               call 0x1d9ec0
00235aef  4883c430                 add rsp, 0x30
00235af3  5d                       pop rbp
00235af4  c3                       ret
