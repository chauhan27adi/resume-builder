; `XE_Session::CreateCollections'::`1'::dtor$5
; sqldk.dll, primary RVA 0x234c74, 59 bytes in 1 chunk(s)

; chunk at RVA 0x234c74 (59 bytes)
00234c74  4055                     push rbp
00234c76  4883ec30                 sub rsp, 0x30
00234c7a  488bea                   mov rbp, rdx
00234c7d  c644242806               mov byte ptr [rsp + 0x28], 6
00234c82  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00234c88  89442420                 mov dword ptr [rsp + 0x20], eax
00234c8c  4c8d0de55b0700           lea r9, [rip + 0x75be5]
00234c93  41b801000000             mov r8d, 1
00234c99  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00234ca0  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00234ca4  e81752faff               call 0x1d9ec0
00234ca9  4883c430                 add rsp, 0x30
00234cad  5d                       pop rbp
00234cae  c3                       ret
