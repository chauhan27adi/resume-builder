; CMemPartitioned<CMemDetour<CMemThread<CMemLargePageObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcec10, 129 bytes in 1 chunk(s)

; chunk at RVA 0xcec10 (129 bytes)
000cec10  48894c2408               mov qword ptr [rsp + 8], rcx
000cec15  57                       push rdi
000cec16  4883ec30                 sub rsp, 0x30
000cec1a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cec23  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cec28  8bda                     mov ebx, edx
000cec2a  488bf9                   mov rdi, rcx
000cec2d  488d0514d71700           lea rax, [rip + 0x17d714]
000cec34  488901                   mov qword ptr [rcx], rax
000cec37  488d81a8030000           lea rax, [rcx + 0x3a8]
000cec3e  4889442450               mov qword ptr [rsp + 0x50], rax
000cec43  488d0df6ae1600           lea rcx, [rip + 0x16aef6]
000cec4a  488908                   mov qword ptr [rax], rcx
000cec4d  488d0554e01700           lea rax, [rip + 0x17e054]
000cec54  488907                   mov qword ptr [rdi], rax
000cec57  488d87e0020000           lea rax, [rdi + 0x2e0]
000cec5e  4889442458               mov qword ptr [rsp + 0x58], rax
000cec63  488908                   mov qword ptr [rax], rcx
000cec66  488bcf                   mov rcx, rdi
000cec69  e8c24a0400               call 0x113730
000cec6e  83e305                   and ebx, 5
000cec71  80fb05                   cmp bl, 5
000cec74  750d                     jne 0xcec83
000cec76  bae0030000               mov edx, 0x3e0
000cec7b  488bcf                   mov rcx, rdi
000cec7e  e88d23f3ff               call 0x1010
000cec83  488bc7                   mov rax, rdi
000cec86  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cec8b  4883c430                 add rsp, 0x30
000cec8f  5f                       pop rdi
000cec90  c3                       ret
