; CMemDetour<CMemThread<CMemProc> >::~CMemDetour<CMemThread<CMemProc> >
; sqldk.dll, primary RVA 0xd5ff0, 59 bytes in 1 chunk(s)

; chunk at RVA 0xd5ff0 (59 bytes)
000d5ff0  48894c2408               mov qword ptr [rsp + 8], rcx
000d5ff5  4883ec38                 sub rsp, 0x38
000d5ff9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d6002  488d05278e1700           lea rax, [rip + 0x178e27]
000d6009  488901                   mov qword ptr [rcx], rax
000d600c  488d81b8010000           lea rax, [rcx + 0x1b8]
000d6013  4889442448               mov qword ptr [rsp + 0x48], rax
000d6018  488d15213b1600           lea rdx, [rip + 0x163b21]
000d601f  488910                   mov qword ptr [rax], rdx
000d6022  4883c438                 add rsp, 0x38
000d6026  e965ccffff               jmp 0xd2c90
