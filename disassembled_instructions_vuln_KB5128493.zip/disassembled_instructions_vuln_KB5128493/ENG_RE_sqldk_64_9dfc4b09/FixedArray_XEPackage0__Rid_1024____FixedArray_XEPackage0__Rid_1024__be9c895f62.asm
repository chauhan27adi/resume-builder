; FixedArray<XEPackage0::Rid,1024>::~FixedArray<XEPackage0::Rid,1024>
; sqldk.dll, primary RVA 0x1bc050, 45 bytes in 1 chunk(s)

; chunk at RVA 0x1bc050 (45 bytes)
001bc050  48894c2408               mov qword ptr [rsp + 8], rcx
001bc055  4883ec38                 sub rsp, 0x38
001bc059  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001bc062  4c8d0d57faffff           lea r9, [rip - 0x5a9]
001bc069  ba10000000               mov edx, 0x10
001bc06e  41b800040000             mov r8d, 0x400
001bc074  4883c438                 add rsp, 0x38
001bc078  e9e32be7ff               jmp 0x2ec60
