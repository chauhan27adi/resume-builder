; CMemAligned<CMemDbg<CMemProc> >::~CMemAligned<CMemDbg<CMemProc> >
; sqldk.dll, primary RVA 0xc14e0, 37 bytes in 1 chunk(s)

; chunk at RVA 0xc14e0 (37 bytes)
000c14e0  48894c2408               mov qword ptr [rsp + 8], rcx
000c14e5  4883ec38                 sub rsp, 0x38
000c14e9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000c14f2  488d05e7df1800           lea rax, [rip + 0x18dfe7]
000c14f9  488901                   mov qword ptr [rcx], rax
000c14fc  4883c438                 add rsp, 0x38
000c1500  e9dbe50a00               jmp 0x16fae0
