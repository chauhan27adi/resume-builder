; SpinlockHolder<12,2,268435714>::~SpinlockHolder<12,2,268435714>
; sqldk.dll, primary RVA 0x9a500, 97 bytes in 1 chunk(s)

; chunk at RVA 0x9a500 (97 bytes)
0009a500  48895c2408               mov qword ptr [rsp + 8], rbx
0009a505  57                       push rdi
0009a506  4883ec20                 sub rsp, 0x20
0009a50a  488b39                   mov rdi, qword ptr [rcx]
0009a50d  488bd9                   mov rbx, rcx
0009a510  4885ff                   test rdi, rdi
0009a513  7441                     je 0x9a556
0009a515  83790800                 cmp dword ptr [rcx + 8], 0
0009a519  743b                     je 0x9a556
0009a51b  803d9faf270000           cmp byte ptr [rip + 0x27af9f], 0
0009a522  7427                     je 0x9a54b
0009a524  ff151ef51900             call qword ptr [rip + 0x19f51e]
0009a52a  448bc0                   mov r8d, eax
0009a52d  b867666666               mov eax, 0x66666667
0009a532  41f7e8                   imul r8d
0009a535  d1fa                     sar edx, 1
0009a537  8bca                     mov ecx, edx
0009a539  c1e91f                   shr ecx, 0x1f
0009a53c  03d1                     add edx, ecx
0009a53e  8d0c92                   lea ecx, [rdx + rdx*4]
0009a541  443bc1                   cmp r8d, ecx
0009a544  7505                     jne 0x9a54b
0009a546  e8a5070000               call 0x9acf0
0009a54b  33c0                     xor eax, eax
0009a54d  488907                   mov qword ptr [rdi], rax
0009a550  488903                   mov qword ptr [rbx], rax
0009a553  894308                   mov dword ptr [rbx + 8], eax
0009a556  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0009a55b  4883c420                 add rsp, 0x20
0009a55f  5f                       pop rdi
0009a560  c3                       ret
