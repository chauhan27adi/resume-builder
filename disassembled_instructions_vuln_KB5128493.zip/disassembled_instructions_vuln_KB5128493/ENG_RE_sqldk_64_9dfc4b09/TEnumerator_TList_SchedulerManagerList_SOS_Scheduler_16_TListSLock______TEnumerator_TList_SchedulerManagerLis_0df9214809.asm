; TEnumerator<TList<SchedulerManagerList,SOS_Scheduler,16,TListSLock> >::~TEnumerator<TList<SchedulerManagerList,SOS_Scheduler,16,TListSLock> >
; sqldk.dll, primary RVA 0x75120, 177 bytes in 1 chunk(s)

; chunk at RVA 0x75120 (177 bytes)
00075120  48895c2410               mov qword ptr [rsp + 0x10], rbx
00075125  48896c2418               mov qword ptr [rsp + 0x18], rbp
0007512a  4889742420               mov qword ptr [rsp + 0x20], rsi
0007512f  57                       push rdi
00075130  4883ec20                 sub rsp, 0x20
00075134  488b39                   mov rdi, qword ptr [rcx]
00075137  33ed                     xor ebp, ebp
00075139  488bd9                   mov rbx, rcx
0007513c  beffffffff               mov esi, 0xffffffff
00075141  4885ff                   test rdi, rdi
00075144  7429                     je 0x7516f
00075146  8bc6                     mov eax, esi
00075148  f00fc14728               lock xadd dword ptr [rdi + 0x28], eax
0007514d  83f801                   cmp eax, 1
00075150  751a                     jne 0x7516c
00075152  48396f18                 cmp qword ptr [rdi + 0x18], rbp
00075156  740c                     je 0x75164
00075158  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0007515c  488bd7                   mov rdx, rdi
0007515f  e88cb1f9ff               call 0x102f0
00075164  488bcf                   mov rcx, rdi
00075167  e8c46f0000               call 0x7c130
0007516c  48892b                   mov qword ptr [rbx], rbp
0007516f  488b7b08                 mov rdi, qword ptr [rbx + 8]
00075173  4885ff                   test rdi, rdi
00075176  7428                     je 0x751a0
00075178  f00fc17728               lock xadd dword ptr [rdi + 0x28], esi
0007517d  83fe01                   cmp esi, 1
00075180  751a                     jne 0x7519c
00075182  48396f18                 cmp qword ptr [rdi + 0x18], rbp
00075186  740c                     je 0x75194
00075188  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0007518c  488bd7                   mov rdx, rdi
0007518f  e85cb1f9ff               call 0x102f0
00075194  488bcf                   mov rcx, rdi
00075197  e8946f0000               call 0x7c130
0007519c  48896b08                 mov qword ptr [rbx + 8], rbp
000751a0  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
000751a4  4885c9                   test rcx, rcx
000751a7  740f                     je 0x751b8
000751a9  8b5320                   mov edx, dword ptr [rbx + 0x20]
000751ac  e89f0af9ff               call 0x5c50
000751b1  48896b18                 mov qword ptr [rbx + 0x18], rbp
000751b5  896b20                   mov dword ptr [rbx + 0x20], ebp
000751b8  488b742448               mov rsi, qword ptr [rsp + 0x48]
000751bd  48896b10                 mov qword ptr [rbx + 0x10], rbp
000751c1  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
000751c6  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
000751cb  4883c420                 add rsp, 0x20
000751cf  5f                       pop rdi
000751d0  c3                       ret
