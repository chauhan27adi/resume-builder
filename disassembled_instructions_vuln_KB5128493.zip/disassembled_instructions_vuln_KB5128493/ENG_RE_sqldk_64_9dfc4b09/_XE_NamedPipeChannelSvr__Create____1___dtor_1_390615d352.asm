; `XE_NamedPipeChannelSvr::Create'::`1'::dtor$1
; sqldk.dll, primary RVA 0x236a38, 37 bytes in 1 chunk(s)

; chunk at RVA 0x236a38 (37 bytes)
00236a38  4055                     push rbp
00236a3a  4883ec20                 sub rsp, 0x20
00236a3e  488bea                   mov rbp, rdx
00236a41  4533c0                   xor r8d, r8d
00236a44  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
00236a4b  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
00236a52  e8b9a5dcff               call 0x1010
00236a57  4883c420                 add rsp, 0x20
00236a5b  5d                       pop rbp
00236a5c  c3                       ret
