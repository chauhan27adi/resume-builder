; `TCacheStore<CacheClockAlgorithm>::Init'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22d3a1, 62 bytes in 1 chunk(s)

; chunk at RVA 0x22d3a1 (62 bytes)
0022d3a1  4055                     push rbp
0022d3a3  4883ec30                 sub rsp, 0x30
0022d3a7  488bea                   mov rbp, rdx
0022d3aa  c644242806               mov byte ptr [rsp + 0x28], 6
0022d3af  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0022d3b5  89442420                 mov dword ptr [rsp + 0x20], eax
0022d3b9  4c8d0d10d10400           lea r9, [rip + 0x4d110]
0022d3c0  41b801000000             mov r8d, 1
0022d3c6  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
0022d3cd  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
0022d3d4  e8c7a9ddff               call 0x7da0
0022d3d9  4883c430                 add rsp, 0x30
0022d3dd  5d                       pop rbp
0022d3de  c3                       ret
