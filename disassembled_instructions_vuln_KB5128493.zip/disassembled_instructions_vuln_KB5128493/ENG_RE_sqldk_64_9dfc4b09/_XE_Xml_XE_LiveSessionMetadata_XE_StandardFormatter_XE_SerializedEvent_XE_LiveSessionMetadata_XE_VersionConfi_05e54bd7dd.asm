; `XE_Xml<XE_LiveSessionMetadata,XE_StandardFormatter,XE_SerializedEvent<XE_LiveSessionMetadata,XE_VersionConfig> >::CacheObjectString'::`1'::dtor$0
; sqldk.dll, primary RVA 0x231540, 31 bytes in 1 chunk(s)

; chunk at RVA 0x231540 (31 bytes)
00231540  4055                     push rbp
00231542  4883ec20                 sub rsp, 0x20
00231546  488bea                   mov rbp, rdx
00231549  4533c0                   xor r8d, r8d
0023154c  488b5560                 mov rdx, qword ptr [rbp + 0x60]
00231550  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
00231554  e8b7fadcff               call 0x1010
00231559  4883c420                 add rsp, 0x20
0023155d  5d                       pop rbp
0023155e  c3                       ret
