; CAutoRg<XEPackage0::OrphanEntry>::~CAutoRg<XEPackage0::OrphanEntry>
; sqldk.dll, primary RVA 0x1ccb20, 79 bytes in 3 chunk(s)

; chunk at RVA 0x1ccb20 (23 bytes)
001ccb20  4883ec28                 sub rsp, 0x28
001ccb24  488b09                   mov rcx, qword ptr [rcx]
001ccb27  4885c9                   test rcx, rcx
001ccb2a  743f                     je 0x1ccb6b
001ccb2c  4c8b41f8                 mov r8, qword ptr [rcx - 8]
001ccb30  4c8d0d29c6ffff           lea r9, [rip - 0x39d7]

; chunk at RVA 0x1ccb37 (51 bytes)
001ccb37  48895c2420               mov qword ptr [rsp + 0x20], rbx
001ccb3c  ba48000000               mov edx, 0x48
001ccb41  488d59f8                 lea rbx, [rcx - 8]
001ccb45  e81621e6ff               call 0x2ec60
001ccb4a  488b03                   mov rax, qword ptr [rbx]
001ccb4d  488bcb                   mov rcx, rbx
001ccb50  488d14c0                 lea rdx, [rax + rax*8]
001ccb54  488d14d508000000         lea rdx, [rdx*8 + 8]
001ccb5c  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
001ccb61  4883c428                 add rsp, 0x28
001ccb65  e986b2e3ff               jmp 0x7df0

; chunk at RVA 0x1ccb6b (5 bytes)
001ccb6b  4883c428                 add rsp, 0x28
001ccb6f  c3                       ret
