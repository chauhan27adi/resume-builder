; AutoSpinlockHolder<50,1,268435714>::~AutoSpinlockHolder<50,1,268435714>
; sqldk.dll, primary RVA 0xa6dc0, 27 bytes in 1 chunk(s)

; chunk at RVA 0xa6dc0 (27 bytes)
000a6dc0  48894c2408               mov qword ptr [rsp + 8], rcx
000a6dc5  4883ec38                 sub rsp, 0x38
000a6dc9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000a6dd2  4883c438                 add rsp, 0x38
000a6dd6  e955050000               jmp 0xa7330
