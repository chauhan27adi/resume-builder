; XE_ParserFactory<XE_SerializedEvent<XE_Metadata,XE_VersionConfig> >::~XE_ParserFactory<XE_SerializedEvent<XE_Metadata,XE_VersionConfig> >
; sqldk.dll, primary RVA 0x1c65f0, 37 bytes in 1 chunk(s)

; chunk at RVA 0x1c65f0 (37 bytes)
001c65f0  48894c2408               mov qword ptr [rsp + 8], rcx
001c65f5  4883ec18                 sub rsp, 0x18
001c65f9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
001c6601  48894c2428               mov qword ptr [rsp + 0x28], rcx
001c6606  488d057b4b0b00           lea rax, [rip + 0xb4b7b]
001c660d  488901                   mov qword ptr [rcx], rax
001c6610  4883c418                 add rsp, 0x18
001c6614  c3                       ret
