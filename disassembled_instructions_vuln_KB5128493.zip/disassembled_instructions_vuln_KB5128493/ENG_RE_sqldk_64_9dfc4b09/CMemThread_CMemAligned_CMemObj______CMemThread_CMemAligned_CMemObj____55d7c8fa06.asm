; CMemThread<CMemAligned<CMemObj> >::~CMemThread<CMemAligned<CMemObj> >
; sqldk.dll, primary RVA 0x12e480, 121 bytes in 1 chunk(s)

; chunk at RVA 0x12e480 (121 bytes)
0012e480  48894c2408               mov qword ptr [rsp + 8], rcx
0012e485  53                       push rbx
0012e486  4883ec30                 sub rsp, 0x30
0012e48a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0012e493  488bd9                   mov rbx, rcx
0012e496  488d05239a1100           lea rax, [rip + 0x119a23]
0012e49d  488901                   mov qword ptr [rcx], rax
0012e4a0  488d8130010000           lea rax, [rcx + 0x130]
0012e4a7  4889442448               mov qword ptr [rsp + 0x48], rax
0012e4ac  488d0d8db61000           lea rcx, [rip + 0x10b68d]
0012e4b3  48894830                 mov qword ptr [rax + 0x30], rcx
0012e4b7  488908                   mov qword ptr [rax], rcx
0012e4ba  488d05c7d31100           lea rax, [rip + 0x11d3c7]
0012e4c1  488903                   mov qword ptr [rbx], rax
0012e4c4  488d059d8a1100           lea rax, [rip + 0x118a9d]
0012e4cb  488903                   mov qword ptr [rbx], rax
0012e4ce  488d05338d1100           lea rax, [rip + 0x118d33]
0012e4d5  488903                   mov qword ptr [rbx], rax
0012e4d8  488d4b38                 lea rcx, [rbx + 0x38]
0012e4dc  e80f3deeff               call 0x121f0
0012e4e1  90                       nop
0012e4e2  488d4b30                 lea rcx, [rbx + 0x30]
0012e4e6  e8053deeff               call 0x121f0
0012e4eb  90                       nop
0012e4ec  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0012e4f3  4883c430                 add rsp, 0x30
0012e4f7  5b                       pop rbx
0012e4f8  c3                       ret
