; LowMemoryGuardContext::~LowMemoryGuardContext
; sqldk.dll, primary RVA 0x94560, 33 bytes in 1 chunk(s)

; chunk at RVA 0x94560 (33 bytes)
00094560  48894c2408               mov qword ptr [rsp + 8], rcx
00094565  4883ec18                 sub rsp, 0x18
00094569  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00094571  488d05302f1b00           lea rax, [rip + 0x1b2f30]
00094578  48894140                 mov qword ptr [rcx + 0x40], rax
0009457c  4883c418                 add rsp, 0x18
00094580  c3                       ret
