; `XE_SessionProxyTargetImpl::RemoveTarget'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235030, 32 bytes in 1 chunk(s)

; chunk at RVA 0x235030 (32 bytes)
00235030  4055                     push rbp
00235032  4883ec20                 sub rsp, 0x20
00235036  488bea                   mov rbp, rdx
00235039  4c8b4548                 mov r8, qword ptr [rbp + 0x48]
0023503d  488b5558                 mov rdx, qword ptr [rbp + 0x58]
00235041  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
00235045  e8c6bfdcff               call 0x1010
0023504a  4883c420                 add rsp, 0x20
0023504e  5d                       pop rbp
0023504f  c3                       ret
