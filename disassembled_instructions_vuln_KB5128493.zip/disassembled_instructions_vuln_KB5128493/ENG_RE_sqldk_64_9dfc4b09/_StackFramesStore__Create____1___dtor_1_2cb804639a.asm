; `StackFramesStore::Create'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22dac4, 62 bytes in 1 chunk(s)

; chunk at RVA 0x22dac4 (62 bytes)
0022dac4  4055                     push rbp
0022dac6  4883ec30                 sub rsp, 0x30
0022daca  488bea                   mov rbp, rdx
0022dacd  c644242806               mov byte ptr [rsp + 0x28], 6
0022dad2  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022dad8  89442420                 mov dword ptr [rsp + 0x20], eax
0022dadc  4c8d0d45cd0600           lea r9, [rip + 0x6cd45]
0022dae3  41b801000000             mov r8d, 1
0022dae9  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
0022daf0  488b8da8000000           mov rcx, qword ptr [rbp + 0xa8]
0022daf7  e8a4a2ddff               call 0x7da0
0022dafc  4883c430                 add rsp, 0x30
0022db00  5d                       pop rbp
0022db01  c3                       ret
