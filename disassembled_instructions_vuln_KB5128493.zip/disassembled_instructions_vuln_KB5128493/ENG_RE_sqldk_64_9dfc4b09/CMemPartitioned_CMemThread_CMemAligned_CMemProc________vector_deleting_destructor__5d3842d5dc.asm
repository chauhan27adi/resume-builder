; CMemPartitioned<CMemThread<CMemAligned<CMemProc> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcde80, 104 bytes in 1 chunk(s)

; chunk at RVA 0xcde80 (104 bytes)
000cde80  48894c2408               mov qword ptr [rsp + 8], rcx
000cde85  57                       push rdi
000cde86  4883ec30                 sub rsp, 0x30
000cde8a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cde93  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cde98  8bda                     mov ebx, edx
000cde9a  488bf9                   mov rdi, rcx
000cde9d  488d05dc0c1800           lea rax, [rip + 0x180cdc]
000cdea4  488901                   mov qword ptr [rcx], rax
000cdea7  488d8110020000           lea rax, [rcx + 0x210]
000cdeae  4889442450               mov qword ptr [rsp + 0x50], rax
000cdeb3  488d0d86bc1600           lea rcx, [rip + 0x16bc86]
000cdeba  488908                   mov qword ptr [rax], rcx
000cdebd  488bcf                   mov rcx, rdi
000cdec0  e8eb81ffff               call 0xc60b0
000cdec5  83e305                   and ebx, 5
000cdec8  80fb05                   cmp bl, 5
000cdecb  750d                     jne 0xcdeda
000cdecd  ba48020000               mov edx, 0x248
000cded2  488bcf                   mov rcx, rdi
000cded5  e83631f3ff               call 0x1010
000cdeda  488bc7                   mov rax, rdi
000cdedd  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cdee2  4883c430                 add rsp, 0x30
000cdee6  5f                       pop rdi
000cdee7  c3                       ret
