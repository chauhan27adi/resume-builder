; `ISOSHostImpl::CreateAutoEvent'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22a31c, 62 bytes in 1 chunk(s)

; chunk at RVA 0x22a31c (62 bytes)
0022a31c  4055                     push rbp
0022a31e  4883ec30                 sub rsp, 0x30
0022a322  488bea                   mov rbp, rdx
0022a325  c644242806               mov byte ptr [rsp + 0x28], 6
0022a32a  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022a330  89442420                 mov dword ptr [rsp + 0x20], eax
0022a334  4c8d0da5f80600           lea r9, [rip + 0x6f8a5]
0022a33b  41b801000000             mov r8d, 1
0022a341  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0022a348  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
0022a34f  e84cdaddff               call 0x7da0
0022a354  4883c430                 add rsp, 0x30
0022a358  5d                       pop rbp
0022a359  c3                       ret
