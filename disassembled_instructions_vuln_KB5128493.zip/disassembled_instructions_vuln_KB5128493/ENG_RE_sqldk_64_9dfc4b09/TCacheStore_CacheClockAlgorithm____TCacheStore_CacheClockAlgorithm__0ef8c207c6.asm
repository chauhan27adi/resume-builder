; TCacheStore<CacheClockAlgorithm>::~TCacheStore<CacheClockAlgorithm>
; sqldk.dll, primary RVA 0x182230, 231 bytes in 1 chunk(s)

; chunk at RVA 0x182230 (231 bytes)
00182230  48894c2408               mov qword ptr [rsp + 8], rcx
00182235  57                       push rdi
00182236  4883ec30                 sub rsp, 0x30
0018223a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00182243  48895c2450               mov qword ptr [rsp + 0x50], rbx
00182248  488bf9                   mov rdi, rcx
0018224b  488d053ed90c00           lea rax, [rip + 0xcd93e]
00182252  488901                   mov qword ptr [rcx], rax
00182255  488d057c290e00           lea rax, [rip + 0xe297c]
0018225c  48894140                 mov qword ptr [rcx + 0x40], rax
00182260  488b8970060000           mov rcx, qword ptr [rcx + 0x670]
00182267  4885c9                   test rcx, rcx
0018226a  7428                     je 0x182294
0018226c  488d59f8                 lea rbx, [rcx - 8]
00182270  4c8d0d698deeff           lea r9, [rip - 0x117297]
00182277  4c8b03                   mov r8, qword ptr [rbx]
0018227a  ba38000000               mov edx, 0x38
0018227f  e8dcc9eaff               call 0x2ec60
00182284  486b1338                 imul rdx, qword ptr [rbx], 0x38
00182288  4883c208                 add rdx, 8
0018228c  488bcb                   mov rcx, rbx
0018228f  e85c5be8ff               call 0x7df0
00182294  33db                     xor ebx, ebx
00182296  48899f70060000           mov qword ptr [rdi + 0x670], rbx
0018229d  48899f58060000           mov qword ptr [rdi + 0x658], rbx
001822a4  48899f60060000           mov qword ptr [rdi + 0x660], rbx
001822ab  48899f78060000           mov qword ptr [rdi + 0x678], rbx
001822b2  48899f80060000           mov qword ptr [rdi + 0x680], rbx
001822b9  488b8f500a0000           mov rcx, qword ptr [rdi + 0xa50]
001822c0  4885c9                   test rcx, rcx
001822c3  7427                     je 0x1822ec
001822c5  488d5108                 lea rdx, [rcx + 8]
001822c9  b8ffffffff               mov eax, 0xffffffff
001822ce  f00fc102                 lock xadd dword ptr [rdx], eax
001822d2  83f801                   cmp eax, 1
001822d5  750e                     jne 0x1822e5
001822d7  4885d2                   test rdx, rdx
001822da  7409                     je 0x1822e5
001822dc  488b01                   mov rax, qword ptr [rcx]
001822df  8d5301                   lea edx, [rbx + 1]
001822e2  ff5048                   call qword ptr [rax + 0x48]
001822e5  48899f500a0000           mov qword ptr [rdi + 0xa50], rbx
001822ec  488d8f90060000           lea rcx, [rdi + 0x690]
001822f3  e8388cebff               call 0x3af30
001822f8  488d8f68080000           lea rcx, [rdi + 0x868]
001822ff  e82c8cebff               call 0x3af30
00182304  90                       nop
00182305  488bcf                   mov rcx, rdi
00182308  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0018230d  4883c430                 add rsp, 0x30
00182311  5f                       pop rdi
00182312  e9a91bffff               jmp 0x173ec0
