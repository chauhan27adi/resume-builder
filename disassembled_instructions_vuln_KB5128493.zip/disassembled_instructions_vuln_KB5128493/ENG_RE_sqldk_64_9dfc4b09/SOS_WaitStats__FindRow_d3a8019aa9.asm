; SOS_WaitStats::FindRow
; sqldk.dll, primary RVA 0x1a070, 233 bytes in 7 chunk(s)

; chunk at RVA 0x1a070 (6 bytes)
0001a070  4057                     push rdi
0001a072  4883ec50                 sub rsp, 0x50

; chunk at RVA 0x1a076 (34 bytes)
0001a076  48896c2448               mov qword ptr [rsp + 0x48], rbp
0001a07b  8bfa                     mov edi, edx
0001a07d  8bea                     mov ebp, edx
0001a07f  4c897c2420               mov qword ptr [rsp + 0x20], r15
0001a084  83e50f                   and ebp, 0xf
0001a087  4c8bf9                   mov r15, rcx
0001a08a  83791000                 cmp dword ptr [rcx + 0x10], 0
0001a08e  745a                     je 0x1a0ea
0001a090  658b042548000000         mov eax, dword ptr gs:[0x48]

; chunk at RVA 0x1a098 (62 bytes)
0001a098  48895c2468               mov qword ptr [rsp + 0x68], rbx
0001a09d  4c89642438               mov qword ptr [rsp + 0x38], r12
0001a0a2  4c896c2430               mov qword ptr [rsp + 0x30], r13
0001a0a7  4533ed                   xor r13d, r13d
0001a0aa  448be0                   mov r12d, eax
0001a0ad  418bdd                   mov ebx, r13d
0001a0b0  8b4118                   mov eax, dword ptr [rcx + 0x18]
0001a0b3  4c89742428               mov qword ptr [rsp + 0x28], r14
0001a0b8  85c0                     test eax, eax
0001a0ba  0f8580950100             jne 0x33640
0001a0c0  33c0                     xor eax, eax
0001a0c2  f04c0fb16118             lock cmpxchg qword ptr [rcx + 0x18], r12
0001a0c8  418bc5                   mov eax, r13d
0001a0cb  0f94c0                   sete al
0001a0ce  85c0                     test eax, eax
0001a0d0  0f846a950100             je 0x33640

; chunk at RVA 0x1a0d6 (20 bytes)
0001a0d6  4c8b642438               mov r12, qword ptr [rsp + 0x38]
0001a0db  4c8b6c2430               mov r13, qword ptr [rsp + 0x30]
0001a0e0  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0001a0e5  4c8b742428               mov r14, qword ptr [rsp + 0x28]

; chunk at RVA 0x1a0ea (29 bytes)
0001a0ea  498b44ef20               mov rax, qword ptr [r15 + rbp*8 + 0x20]
0001a0ef  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
0001a0f4  488b6c2448               mov rbp, qword ptr [rsp + 0x48]
0001a0f9  4885c0                   test rax, rax
0001a0fc  0f847a88ffff             je 0x1297c
0001a102  660f1f0400               nop word ptr [rax + rax]

; chunk at RVA 0x1a110 (15 bytes)
0001a110  397820                   cmp dword ptr [rax + 0x20], edi
0001a113  0f855688ffff             jne 0x1296f
0001a119  4883c450                 add rsp, 0x50
0001a11d  5f                       pop rdi
0001a11e  c3                       ret

; chunk at RVA 0x3364b (67 bytes)
0003364b  4889742440               mov qword ptr [rsp + 0x40], rsi
00033650  498bf5                   mov rsi, r13
00033653  3c84                     cmp al, 0x84
00033655  0f840ca31700             je 0x1ad967
0003365b  f60575142e0080           test byte ptr [rip + 0x2e1475], 0x80
00033662  498d4f18                 lea rcx, [r15 + 0x18]
00033666  0f845aa31700             je 0x1ad9c6
0003366c  4d8bc4                   mov r8, r12
0003366f  488bd6                   mov rdx, rsi
00033672  e829000000               call 0x336a0
00033677  eb01                     jmp 0x3367a
00033679  cc                       int3
0003367a  4885f6                   test rsi, rsi
0003367d  0f8552a31700             jne 0x1ad9d5
00033683  488b742440               mov rsi, qword ptr [rsp + 0x40]
00033688  e9496afeff               jmp 0x1a0d6
0003368d  cc                       int3
