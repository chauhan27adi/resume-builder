; `XE_Engine::CreatePredicateNode'::`1'::dtor$10
; sqldk.dll, primary RVA 0x233cbc, 56 bytes in 1 chunk(s)

; chunk at RVA 0x233cbc (56 bytes)
00233cbc  4055                     push rbp
00233cbe  4883ec30                 sub rsp, 0x30
00233cc2  488bea                   mov rbp, rdx
00233cc5  c644242806               mov byte ptr [rsp + 0x28], 6
00233cca  8b4570                   mov eax, dword ptr [rbp + 0x70]
00233ccd  89442420                 mov dword ptr [rsp + 0x20], eax
00233cd1  4c8d0d806e0700           lea r9, [rip + 0x76e80]
00233cd8  41b801000000             mov r8d, 1
00233cde  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
00233ce5  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00233ce9  e8d261faff               call 0x1d9ec0
00233cee  4883c430                 add rsp, 0x30
00233cf2  5d                       pop rbp
00233cf3  c3                       ret
