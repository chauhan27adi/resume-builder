; SOSHost_TaskAutoOnFlags::~SOSHost_TaskAutoOnFlags
; sqldk.dll, primary RVA 0x160600, 36 bytes in 1 chunk(s)

; chunk at RVA 0x160600 (36 bytes)
00160600  48894c2408               mov qword ptr [rsp + 8], rcx
00160605  4883ec18                 sub rsp, 0x18
00160609  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00160611  488b5108                 mov rdx, qword ptr [rcx + 8]
00160615  8b01                     mov eax, dword ptr [rcx]
00160617  f7d0                     not eax
00160619  218268020000             and dword ptr [rdx + 0x268], eax
0016061f  4883c418                 add rsp, 0x18
00160623  c3                       ret
