; AutoSpinlockHolder<18,1,268435714>::~AutoSpinlockHolder<18,1,268435714>
; sqldk.dll, primary RVA 0x7d280, 27 bytes in 1 chunk(s)

; chunk at RVA 0x7d280 (27 bytes)
0007d280  48894c2408               mov qword ptr [rsp + 8], rcx
0007d285  4883ec38                 sub rsp, 0x38
0007d289  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0007d292  4883c438                 add rsp, 0x38
0007d296  e97568f8ff               jmp 0x3b10
