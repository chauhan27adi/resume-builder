; MemObjCache<CMemProc>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13dbb0, 121 bytes in 1 chunk(s)

; chunk at RVA 0x13dbb0 (121 bytes)
0013dbb0  48894c2408               mov qword ptr [rsp + 8], rcx
0013dbb5  57                       push rdi
0013dbb6  4883ec30                 sub rsp, 0x30
0013dbba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013dbc3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013dbc8  8bda                     mov ebx, edx
0013dbca  488bf9                   mov rdi, rcx
0013dbcd  488d059cd01000           lea rax, [rip + 0x10d09c]
0013dbd4  488901                   mov qword ptr [rcx], rax
0013dbd7  488d057a971000           lea rax, [rip + 0x10977a]
0013dbde  488901                   mov qword ptr [rcx], rax
0013dbe1  488d0520961000           lea rax, [rip + 0x109620]
0013dbe8  488901                   mov qword ptr [rcx], rax
0013dbeb  4883c138                 add rcx, 0x38
0013dbef  e8fc45edff               call 0x121f0
0013dbf4  90                       nop
0013dbf5  488d4f30                 lea rcx, [rdi + 0x30]
0013dbf9  e8f245edff               call 0x121f0
0013dbfe  90                       nop
0013dbff  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013dc06  83e305                   and ebx, 5
0013dc09  80fb05                   cmp bl, 5
0013dc0c  750d                     jne 0x13dc1b
0013dc0e  baf0000000               mov edx, 0xf0
0013dc13  488bcf                   mov rcx, rdi
0013dc16  e8f533ecff               call 0x1010
0013dc1b  488bc7                   mov rax, rdi
0013dc1e  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013dc23  4883c430                 add rsp, 0x30
0013dc27  5f                       pop rdi
0013dc28  c3                       ret
