; XE_AutoRg<XE_AutoP<XE_Log> >::~XE_AutoRg<XE_AutoP<XE_Log> >
; sqldk.dll, primary RVA 0x1beed0, 99 bytes in 1 chunk(s)

; chunk at RVA 0x1beed0 (99 bytes)
001beed0  48894c2408               mov qword ptr [rsp + 8], rcx
001beed5  53                       push rbx
001beed6  4883ec30                 sub rsp, 0x30
001beeda  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001beee3  488bd9                   mov rbx, rcx
001beee6  488b09                   mov rcx, qword ptr [rcx]
001beee9  e8c2140000               call 0x1c03b0
001beeee  48c70300000000           mov qword ptr [rbx], 0
001beef5  488b0b                   mov rcx, qword ptr [rbx]
001beef8  4885c9                   test rcx, rcx
001beefb  7430                     je 0x1bef2d
001beefd  488d59f8                 lea rbx, [rcx - 8]
001bef01  4c8d0d0888e8ff           lea r9, [rip - 0x1777f8]
001bef08  4c8b03                   mov r8, qword ptr [rbx]
001bef0b  ba08000000               mov edx, 8
001bef10  e84bfde6ff               call 0x2ec60
001bef15  488b13                   mov rdx, qword ptr [rbx]
001bef18  488d14d508000000         lea rdx, [rdx*8 + 8]
001bef20  488bcb                   mov rcx, rbx
001bef23  4883c430                 add rsp, 0x30
001bef27  5b                       pop rbx
001bef28  e9c38ee4ff               jmp 0x7df0
001bef2d  4883c430                 add rsp, 0x30
001bef31  5b                       pop rbx
001bef32  c3                       ret
