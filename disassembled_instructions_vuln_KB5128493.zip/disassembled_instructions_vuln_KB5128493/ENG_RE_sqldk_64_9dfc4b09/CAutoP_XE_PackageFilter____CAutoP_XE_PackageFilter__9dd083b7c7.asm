; CAutoP<XE_PackageFilter>::~CAutoP<XE_PackageFilter>
; sqldk.dll, primary RVA 0x48ad0, 127 bytes in 1 chunk(s)

; chunk at RVA 0x48ad0 (127 bytes)
00048ad0  4053                     push rbx
00048ad2  4883ec30                 sub rsp, 0x30
00048ad6  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00048adf  488b19                   mov rbx, qword ptr [rcx]
00048ae2  48895c2440               mov qword ptr [rsp + 0x40], rbx
00048ae7  4885db                   test rbx, rbx
00048aea  745d                     je 0x48b49
00048aec  488d4b50                 lea rcx, [rbx + 0x50]
00048af0  48894c2448               mov qword ptr [rsp + 0x48], rcx
00048af5  4883c110                 add rcx, 0x10
00048af9  e8c28fffff               call 0x41ac0
00048afe  90                       nop
00048aff  488d4b38                 lea rcx, [rbx + 0x38]
00048b03  48894c2450               mov qword ptr [rsp + 0x50], rcx
00048b08  4883c110                 add rcx, 0x10
00048b0c  e8af8fffff               call 0x41ac0
00048b11  90                       nop
00048b12  488d4b20                 lea rcx, [rbx + 0x20]
00048b16  48894c2458               mov qword ptr [rsp + 0x58], rcx
00048b1b  4883c110                 add rcx, 0x10
00048b1f  e89c8fffff               call 0x41ac0
00048b24  90                       nop
00048b25  488d4b08                 lea rcx, [rbx + 8]
00048b29  48894c2440               mov qword ptr [rsp + 0x40], rcx
00048b2e  4883c110                 add rcx, 0x10
00048b32  e8898fffff               call 0x41ac0
00048b37  ba68000000               mov edx, 0x68
00048b3c  488bcb                   mov rcx, rbx
00048b3f  4883c430                 add rsp, 0x30
00048b43  5b                       pop rbx
00048b44  e9a7f2fbff               jmp 0x7df0
00048b49  4883c430                 add rsp, 0x30
00048b4d  5b                       pop rbx
00048b4e  c3                       ret
