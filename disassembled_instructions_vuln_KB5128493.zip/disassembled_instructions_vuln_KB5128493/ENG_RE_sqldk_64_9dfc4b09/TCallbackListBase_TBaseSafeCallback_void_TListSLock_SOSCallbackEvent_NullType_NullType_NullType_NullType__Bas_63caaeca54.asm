; TCallbackListBase<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType>,BaseSafeCallbackTraits<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType>,TListSLock,SOSCallbackEvent>::List>::~TCallbackListBase<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType>,BaseSafeCallbackTraits<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,NullType,NullType,NullType,NullType>,TListSLock,SOSCallbackEvent>::List>
; sqldk.dll, primary RVA 0x6b110, 151 bytes in 1 chunk(s)

; chunk at RVA 0x6b110 (151 bytes)
0006b110  48894c2408               mov qword ptr [rsp + 8], rcx
0006b115  57                       push rdi
0006b116  4883ec50                 sub rsp, 0x50
0006b11a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0006b123  48895c2468               mov qword ptr [rsp + 0x68], rbx
0006b128  4889742470               mov qword ptr [rsp + 0x70], rsi
0006b12d  488bf1                   mov rsi, rcx
0006b130  e86b20fcff               call 0x2d1a0
0006b135  85c0                     test eax, eax
0006b137  7558                     jne 0x6b191
0006b139  488bce                   mov rcx, rsi
0006b13c  e85f20fcff               call 0x2d1a0
0006b141  85c0                     test eax, eax
0006b143  754c                     jne 0x6b191
0006b145  0f57c0                   xorps xmm0, xmm0
0006b148  f30f7f442428             movdqu xmmword ptr [rsp + 0x28], xmm0
0006b14e  4533c0                   xor r8d, r8d
0006b151  488bd6                   mov rdx, rsi
0006b154  488d4c2428               lea rcx, [rsp + 0x28]
0006b159  e82221fcff               call 0x2d280
0006b15e  90                       nop
0006b15f  33ff                     xor edi, edi
0006b161  488d4c2428               lea rcx, [rsp + 0x28]
0006b166  e81523fcff               call 0x2d480
0006b16b  488bd8                   mov rbx, rax
0006b16e  4885ff                   test rdi, rdi
0006b171  740b                     je 0x6b17e
0006b173  488bd7                   mov rdx, rdi
0006b176  488bce                   mov rcx, rsi
0006b179  e872050000               call 0x6b6f0
0006b17e  488bfb                   mov rdi, rbx
0006b181  4885db                   test rbx, rbx
0006b184  75db                     jne 0x6b161
0006b186  488d4c2428               lea rcx, [rsp + 0x28]
0006b18b  e85036fcff               call 0x2e7e0
0006b190  90                       nop
0006b191  c706adde0080             mov dword ptr [rsi], 0x8000dead
0006b197  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0006b19c  488b742470               mov rsi, qword ptr [rsp + 0x70]
0006b1a1  4883c450                 add rsp, 0x50
0006b1a5  5f                       pop rdi
0006b1a6  c3                       ret
