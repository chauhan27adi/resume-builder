; XE_SessionBasicTargetImpl::`vector deleting destructor'
; sqldk.dll, primary RVA 0x1eeb20, 63 bytes in 1 chunk(s)

; chunk at RVA 0x1eeb20 (63 bytes)
001eeb20  48894c2408               mov qword ptr [rsp + 8], rcx
001eeb25  53                       push rbx
001eeb26  4883ec30                 sub rsp, 0x30
001eeb2a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001eeb33  488bd9                   mov rbx, rcx
001eeb36  488d053b6f0700           lea rax, [rip + 0x76f3b]
001eeb3d  488901                   mov qword ptr [rcx], rax
001eeb40  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
001eeb47  f6c201                   test dl, 1
001eeb4a  740a                     je 0x1eeb56
001eeb4c  ba18000000               mov edx, 0x18
001eeb51  e89a92e1ff               call 0x7df0
001eeb56  488bc3                   mov rax, rbx
001eeb59  4883c430                 add rsp, 0x30
001eeb5d  5b                       pop rbx
001eeb5e  c3                       ret
