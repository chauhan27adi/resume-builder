; `XEPackage0::CounterTarget::AddPackage'::`1'::dtor$8
; sqldk.dll, primary RVA 0x231972, 45 bytes in 1 chunk(s)

; chunk at RVA 0x231972 (45 bytes)
00231972  4055                     push rbp
00231974  4883ec20                 sub rsp, 0x20
00231978  488bea                   mov rbp, rdx
0023197b  488b8db0000000           mov rcx, qword ptr [rbp + 0xb0]
00231982  4c8d0d0758e1ff           lea r9, [rip - 0x1ea7f9]
00231989  41b880000000             mov r8d, 0x80
0023198f  ba18000000               mov edx, 0x18
00231994  e8c7d2dfff               call 0x2ec60
00231999  4883c420                 add rsp, 0x20
0023199d  5d                       pop rbp
0023199e  c3                       ret
