; CSessionTraceFlags::ClearSessionTrace
; sqldk.dll, primary RVA 0x1b4a20, 206 bytes in 1 chunk(s)

; chunk at RVA 0x1b4a20 (206 bytes)
001b4a20  4053                     push rbx
001b4a22  4883ec20                 sub rsp, 0x20
001b4a26  8bd9                     mov ebx, ecx
001b4a28  81f9ac3f0000             cmp ecx, 0x3fac
001b4a2e  0f83b2000000             jae 0x1b4ae6
001b4a34  85d2                     test edx, edx
001b4a36  7414                     je 0x1b4a4c
001b4a38  e803070000               call 0x1b5140
001b4a3d  4885c0                   test rax, rax
001b4a40  740a                     je 0x1b4a4c
001b4a42  83780c00                 cmp dword ptr [rax + 0xc], 0
001b4a46  0f849a000000             je 0x1b4ae6
001b4a4c  488b0da5d51700           mov rcx, qword ptr [rip + 0x17d5a5]
001b4a53  488b01                   mov rax, qword ptr [rcx]
001b4a56  ff5020                   call qword ptr [rax + 0x20]
001b4a59  4c8bc8                   mov r9, rax
001b4a5c  4885c0                   test rax, rax
001b4a5f  747d                     je 0x1b4ade
001b4a61  8bcb                     mov ecx, ebx
001b4a63  b8cdcccccc               mov eax, 0xcccccccd
001b4a68  f7e3                     mul ebx
001b4a6a  c1ea03                   shr edx, 3
001b4a6d  448d0492                 lea r8d, [rdx + rdx*4]
001b4a71  4503c0                   add r8d, r8d
001b4a74  412bc8                   sub ecx, r8d
001b4a77  4533d2                   xor r10d, r10d
001b4a7a  4c8d048d00000000         lea r8, [rcx*4]
001b4a82  43395c0104               cmp dword ptr [r9 + r8 + 4], ebx
001b4a87  7438                     je 0x1b4ac1
001b4a89  418bd2                   mov edx, r10d
001b4a8c  498d4104                 lea rax, [r9 + 4]
001b4a90  498bca                   mov rcx, r10
001b4a93  3918                     cmp dword ptr [rax], ebx
001b4a95  7420                     je 0x1b4ab7
001b4a97  ffc2                     inc edx
001b4a99  48ffc1                   inc rcx
001b4a9c  4883c004                 add rax, 4
001b4aa0  4883f90a                 cmp rcx, 0xa
001b4aa4  7ced                     jl 0x1b4a93
001b4aa6  4d8b4930                 mov r9, qword ptr [r9 + 0x30]
001b4aaa  4d85c9                   test r9, r9
001b4aad  75d3                     jne 0x1b4a82
001b4aaf  b001                     mov al, 1
001b4ab1  4883c420                 add rsp, 0x20
001b4ab5  5b                       pop rbx
001b4ab6  c3                       ret
001b4ab7  4863c2                   movsxd rax, edx
001b4aba  4589548104               mov dword ptr [r9 + rax*4 + 4], r10d
001b4abf  eb05                     jmp 0x1b4ac6
001b4ac1  4789540104               mov dword ptr [r9 + r8 + 4], r10d
001b4ac6  488b0d2bd51700           mov rcx, qword ptr [rip + 0x17d52b]
001b4acd  41b901000000             mov r9d, 1
001b4ad3  458bc1                   mov r8d, r9d
001b4ad6  8bd3                     mov edx, ebx
001b4ad8  488b01                   mov rax, qword ptr [rcx]
001b4adb  ff5010                   call qword ptr [rax + 0x10]
001b4ade  b001                     mov al, 1
001b4ae0  4883c420                 add rsp, 0x20
001b4ae4  5b                       pop rbx
001b4ae5  c3                       ret
001b4ae6  32c0                     xor al, al
001b4ae8  4883c420                 add rsp, 0x20
001b4aec  5b                       pop rbx
001b4aed  c3                       ret
