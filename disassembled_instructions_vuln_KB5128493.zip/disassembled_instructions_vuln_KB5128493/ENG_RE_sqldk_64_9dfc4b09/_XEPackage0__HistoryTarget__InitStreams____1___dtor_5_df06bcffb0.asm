; `XEPackage0::HistoryTarget::InitStreams'::`1'::dtor$5
; sqldk.dll, primary RVA 0x232b20, 31 bytes in 1 chunk(s)

; chunk at RVA 0x232b20 (31 bytes)
00232b20  4055                     push rbp
00232b22  4883ec20                 sub rsp, 0x20
00232b26  488bea                   mov rbp, rdx
00232b29  4533c0                   xor r8d, r8d
00232b2c  488b5558                 mov rdx, qword ptr [rbp + 0x58]
00232b30  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00232b34  e8d7e4dcff               call 0x1010
00232b39  4883c420                 add rsp, 0x20
00232b3d  5d                       pop rbp
00232b3e  c3                       ret
