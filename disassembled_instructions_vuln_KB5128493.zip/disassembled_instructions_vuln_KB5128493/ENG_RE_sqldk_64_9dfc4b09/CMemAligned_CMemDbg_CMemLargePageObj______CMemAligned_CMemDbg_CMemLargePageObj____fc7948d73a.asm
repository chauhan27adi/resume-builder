; CMemAligned<CMemDbg<CMemLargePageObj> >::~CMemAligned<CMemDbg<CMemLargePageObj> >
; sqldk.dll, primary RVA 0x112090, 37 bytes in 1 chunk(s)

; chunk at RVA 0x112090 (37 bytes)
00112090  48894c2408               mov qword ptr [rsp + 8], rcx
00112095  4883ec38                 sub rsp, 0x38
00112099  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001120a2  488d05d7931300           lea rax, [rip + 0x1393d7]
001120a9  488901                   mov qword ptr [rcx], rax
001120ac  4883c438                 add rsp, 0x38
001120b0  e99b180600               jmp 0x173950
