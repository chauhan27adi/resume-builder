; CMemThread<CMemFixed>::PbGetNewPages
; sqldk.dll, primary RVA 0x1be60, 179 bytes in 1 chunk(s)

; chunk at RVA 0x1be60 (179 bytes)
0001be60  48895c2408               mov qword ptr [rsp + 8], rbx
0001be65  48896c2410               mov qword ptr [rsp + 0x10], rbp
0001be6a  4889742418               mov qword ptr [rsp + 0x18], rsi
0001be6f  57                       push rdi
0001be70  4883ec20                 sub rsp, 0x20
0001be74  488d9908010000           lea rbx, [rcx + 0x108]
0001be7b  498bf0                   mov rsi, r8
0001be7e  48c7838000000000000000   mov qword ptr [rbx + 0x80], 0
0001be89  488bea                   mov rbp, rdx
0001be8c  488bf9                   mov rdi, rcx
0001be8f  b8ff7fffff               mov eax, 0xffff7fff
0001be94  f00fc14360               lock xadd dword ptr [rbx + 0x60], eax
0001be99  3d01800000               cmp eax, 0x8001
0001be9e  7411                     je 0x1beb1
0001bea0  488d4b30                 lea rcx, [rbx + 0x30]
0001bea4  e8e70cffff               call 0xcb90
0001bea9  488bcb                   mov rcx, rbx
0001beac  e8df0cffff               call 0xcb90
0001beb1  488b4f40                 mov rcx, qword ptr [rdi + 0x40]
0001beb5  4c8bc6                   mov r8, rsi
0001beb8  488bd5                   mov rdx, rbp
0001bebb  488b01                   mov rax, qword ptr [rcx]
0001bebe  ff10                     call qword ptr [rax]
0001bec0  65488b142558000000       mov rdx, qword ptr gs:[0x58]
0001bec9  488be8                   mov rbp, rax
0001becc  8b0dfe902f00             mov ecx, dword ptr [rip + 0x2f90fe]
0001bed2  8b35e059feff             mov esi, dword ptr [rip - 0x1a620]
0001bed8  480334ca                 add rsi, qword ptr [rdx + rcx*8]
0001bedc  488b9600010000           mov rdx, qword ptr [rsi + 0x100]
0001bee3  4885d2                   test rdx, rdx
0001bee6  0f8429010e00             je 0xfc015
0001beec  4c8d8790010000           lea r8, [rdi + 0x190]
0001bef3  488bcb                   mov rcx, rbx
0001bef6  e845bffeff               call 0x7e40
0001befb  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0001bf00  488bc5                   mov rax, rbp
0001bf03  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
0001bf08  488b742440               mov rsi, qword ptr [rsp + 0x40]
0001bf0d  4883c420                 add rsp, 0x20
0001bf11  5f                       pop rdi
0001bf12  c3                       ret
