; XE_CXFileWriter::~XE_CXFileWriter
; sqldk.dll, primary RVA 0x4e760, 290 bytes in 1 chunk(s)

; chunk at RVA 0x4e760 (290 bytes)
0004e760  48894c2408               mov qword ptr [rsp + 8], rcx
0004e765  53                       push rbx
0004e766  55                       push rbp
0004e767  56                       push rsi
0004e768  57                       push rdi
0004e769  4156                     push r14
0004e76b  4883ec30                 sub rsp, 0x30
0004e76f  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0004e778  488bf1                   mov rsi, rcx
0004e77b  e810120000               call 0x4f990
0004e780  488b9e58020000           mov rbx, qword ptr [rsi + 0x258]
0004e787  4533f6                   xor r14d, r14d
0004e78a  4885db                   test rbx, rbx
0004e78d  7462                     je 0x4e7f1
0004e78f  488d6bfc                 lea rbp, [rbx - 4]
0004e793  4883e5f8                 and rbp, 0xfffffffffffffff8
0004e797  418bfe                   mov edi, r14d
0004e79a  397d00                   cmp dword ptr [rbp], edi
0004e79d  7649                     jbe 0x4e7e8
0004e79f  4883c320                 add rbx, 0x20
0004e7a3  0f1f4000                 nop dword ptr [rax]
0004e7a7  660f1f840000000000       nop word ptr [rax + rax]
0004e7b0  488d43e0                 lea rax, [rbx - 0x20]
0004e7b4  4889442468               mov qword ptr [rsp + 0x68], rax
0004e7b9  48895c2470               mov qword ptr [rsp + 0x70], rbx
0004e7be  488b0b                   mov rcx, qword ptr [rbx]
0004e7c1  4885c9                   test rcx, rcx
0004e7c4  7406                     je 0x4e7cc
0004e7c6  ff1584682c00             call qword ptr [rip + 0x2c6884]
0004e7cc  4c8933                   mov qword ptr [rbx], r14
0004e7cf  33d2                     xor edx, edx
0004e7d1  488b0b                   mov rcx, qword ptr [rbx]
0004e7d4  e81796fbff               call 0x7df0
0004e7d9  48ffc7                   inc rdi
0004e7dc  4883c350                 add rbx, 0x50
0004e7e0  8b4500                   mov eax, dword ptr [rbp]
0004e7e3  483bf8                   cmp rdi, rax
0004e7e6  72c8                     jb 0x4e7b0
0004e7e8  488bcd                   mov rcx, rbp
0004e7eb  ff155f682c00             call qword ptr [rip + 0x2c685f]
0004e7f1  488b8ea0020000           mov rcx, qword ptr [rsi + 0x2a0]
0004e7f8  4883f9ff                 cmp rcx, -1
0004e7fc  7406                     je 0x4e804
0004e7fe  ff1514ad1e00             call qword ptr [rip + 0x1ead14]
0004e804  488b8eb8020000           mov rcx, qword ptr [rsi + 0x2b8]
0004e80b  4885c9                   test rcx, rcx
0004e80e  7430                     je 0x4e840
0004e810  4881b9d0bf000039707865   cmp qword ptr [rcx + 0xbfd0], 0x65787039
0004e81b  7523                     jne 0x4e840
0004e81d  488b99c8bf0000           mov rbx, qword ptr [rcx + 0xbfc8]
0004e824  33d2                     xor edx, edx
0004e826  41b828d00000             mov r8d, 0xd028
0004e82c  e8b360fbff               call 0x48e4
0004e831  4885db                   test rbx, rbx
0004e834  740a                     je 0x4e840
0004e836  488bcb                   mov rcx, rbx
0004e839  ff1511682c00             call qword ptr [rip + 0x2c6811]
0004e83f  90                       nop
0004e840  488d9e30020000           lea rbx, [rsi + 0x230]
0004e847  488b0b                   mov rcx, qword ptr [rbx]
0004e84a  4885c9                   test rcx, rcx
0004e84d  7406                     je 0x4e855
0004e84f  ff15fb672c00             call qword ptr [rip + 0x2c67fb]
0004e855  4c8933                   mov qword ptr [rbx], r14
0004e858  48895c2460               mov qword ptr [rsp + 0x60], rbx
0004e85d  488b0b                   mov rcx, qword ptr [rbx]
0004e860  4885c9                   test rcx, rcx
0004e863  7406                     je 0x4e86b
0004e865  ff15e5672c00             call qword ptr [rip + 0x2c67e5]
0004e86b  4c8933                   mov qword ptr [rbx], r14
0004e86e  33d2                     xor edx, edx
0004e870  488b0b                   mov rcx, qword ptr [rbx]
0004e873  4883c430                 add rsp, 0x30
0004e877  415e                     pop r14
0004e879  5f                       pop rdi
0004e87a  5e                       pop rsi
0004e87b  5d                       pop rbp
0004e87c  5b                       pop rbx
0004e87d  e96e95fbff               jmp 0x7df0
