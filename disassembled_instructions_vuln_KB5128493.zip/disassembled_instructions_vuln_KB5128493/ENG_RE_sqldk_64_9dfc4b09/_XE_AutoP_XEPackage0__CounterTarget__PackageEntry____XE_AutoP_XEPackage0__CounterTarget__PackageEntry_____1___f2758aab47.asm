; `XE_AutoP<XEPackage0::CounterTarget::PackageEntry>::~XE_AutoP<XEPackage0::CounterTarget::PackageEntry>'::`1'::dtor$1
; sqldk.dll, primary RVA 0x231af0, 42 bytes in 1 chunk(s)

; chunk at RVA 0x231af0 (42 bytes)
00231af0  4055                     push rbp
00231af2  4883ec20                 sub rsp, 0x20
00231af6  488bea                   mov rbp, rdx
00231af9  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
00231afd  4c8d0d8c56e1ff           lea r9, [rip - 0x1ea974]
00231b04  41b880000000             mov r8d, 0x80
00231b0a  ba18000000               mov edx, 0x18
00231b0f  e84cd1dfff               call 0x2ec60
00231b14  4883c420                 add rsp, 0x20
00231b18  5d                       pop rbp
00231b19  c3                       ret
