; CMemDbg<CMemLargePageObj>::~CMemDbg<CMemLargePageObj>
; sqldk.dll, primary RVA 0x173950, 109 bytes in 1 chunk(s)

; chunk at RVA 0x173950 (109 bytes)
00173950  48894c2408               mov qword ptr [rsp + 8], rcx
00173955  53                       push rbx
00173956  4883ec30                 sub rsp, 0x30
0017395a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00173963  488bd9                   mov rbx, rcx
00173966  488d05eb950d00           lea rax, [rip + 0xd95eb]
0017396d  488901                   mov qword ptr [rcx], rax
00173970  488d0561240f00           lea rax, [rip + 0xf2461]
00173977  488981d8010000           mov qword ptr [rcx + 0x1d8], rax
0017397e  488d0593340d00           lea rax, [rip + 0xd3493]
00173985  488901                   mov qword ptr [rcx], rax
00173988  488d05d9350d00           lea rax, [rip + 0xd35d9]
0017398f  488901                   mov qword ptr [rcx], rax
00173992  488d056f380d00           lea rax, [rip + 0xd386f]
00173999  488901                   mov qword ptr [rcx], rax
0017399c  4883c138                 add rcx, 0x38
001739a0  e84be8e9ff               call 0x121f0
001739a5  90                       nop
001739a6  488d4b30                 lea rcx, [rbx + 0x30]
001739aa  e841e8e9ff               call 0x121f0
001739af  90                       nop
001739b0  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
001739b7  4883c430                 add rsp, 0x30
001739bb  5b                       pop rbx
001739bc  c3                       ret
