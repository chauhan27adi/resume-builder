; `XE_Engine::Initialize'::`1'::dtor$7
; sqldk.dll, primary RVA 0x233e90, 53 bytes in 1 chunk(s)

; chunk at RVA 0x233e90 (53 bytes)
00233e90  4055                     push rbp
00233e92  4883ec30                 sub rsp, 0x30
00233e96  488bea                   mov rbp, rdx
00233e99  c644242806               mov byte ptr [rsp + 0x28], 6
00233e9e  8b4530                   mov eax, dword ptr [rbp + 0x30]
00233ea1  89442420                 mov dword ptr [rsp + 0x20], eax
00233ea5  4c8d0df4680700           lea r9, [rip + 0x768f4]
00233eac  41b801000000             mov r8d, 1
00233eb2  488b5558                 mov rdx, qword ptr [rbp + 0x58]
00233eb6  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00233eba  e80160faff               call 0x1d9ec0
00233ebf  4883c430                 add rsp, 0x30
00233ec3  5d                       pop rbp
00233ec4  c3                       ret
