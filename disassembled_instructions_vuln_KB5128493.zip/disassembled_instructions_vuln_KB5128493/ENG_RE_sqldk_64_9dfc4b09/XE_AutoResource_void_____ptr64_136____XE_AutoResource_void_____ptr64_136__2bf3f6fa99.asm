; XE_AutoResource<void * __ptr64,136>::~XE_AutoResource<void * __ptr64,136>
; sqldk.dll, primary RVA 0x476e0, 36 bytes in 1 chunk(s)

; chunk at RVA 0x476e0 (36 bytes)
000476e0  4053                     push rbx
000476e2  4883ec20                 sub rsp, 0x20
000476e6  488bd9                   mov rbx, rcx
000476e9  488b09                   mov rcx, qword ptr [rcx]
000476ec  4885c9                   test rcx, rcx
000476ef  7406                     je 0x476f7
000476f1  ff1591d92c00             call qword ptr [rip + 0x2cd991]
000476f7  48c70300000000           mov qword ptr [rbx], 0
000476fe  4883c420                 add rsp, 0x20
00047702  5b                       pop rbx
00047703  c3                       ret
