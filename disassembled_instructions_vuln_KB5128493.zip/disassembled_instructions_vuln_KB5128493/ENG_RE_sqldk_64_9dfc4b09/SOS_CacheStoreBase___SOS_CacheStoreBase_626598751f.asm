; SOS_CacheStoreBase::~SOS_CacheStoreBase
; sqldk.dll, primary RVA 0x173ec0, 190 bytes in 1 chunk(s)

; chunk at RVA 0x173ec0 (190 bytes)
00173ec0  48894c2408               mov qword ptr [rsp + 8], rcx
00173ec5  53                       push rbx
00173ec6  4883ec30                 sub rsp, 0x30
00173eca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00173ed3  488bd9                   mov rbx, rcx
00173ed6  488d051bbd0d00           lea rax, [rip + 0xdbd1b]
00173edd  488901                   mov qword ptr [rcx], rax
00173ee0  488d05f10c0f00           lea rax, [rip + 0xf0cf1]
00173ee7  48894140                 mov qword ptr [rcx + 0x40], rax
00173eeb  488b9140060000           mov rdx, qword ptr [rcx + 0x640]
00173ef2  4885d2                   test rdx, rdx
00173ef5  7447                     je 0x173f3e
00173ef7  488bc2                   mov rax, rdx
00173efa  41b800020000             mov r8d, 0x200
00173f00  482500e0ffff             and rax, 0xffffffffffffe000
00173f06  740b                     je 0x173f13
00173f08  6644394004               cmp word ptr [rax + 4], r8w
00173f0d  7504                     jne 0x173f13
00173f0f  488b4028                 mov rax, qword ptr [rax + 0x28]
00173f13  488b4008                 mov rax, qword ptr [rax + 8]
00173f17  488b4810                 mov rcx, qword ptr [rax + 0x10]
00173f1b  48f7d9                   neg rcx
00173f1e  4823ca                   and rcx, rdx
00173f21  740b                     je 0x173f2e
00173f23  6644394104               cmp word ptr [rcx + 4], r8w
00173f28  7504                     jne 0x173f2e
00173f2a  488b4928                 mov rcx, qword ptr [rcx + 0x28]
00173f2e  488b4908                 mov rcx, qword ptr [rcx + 8]
00173f32  f6412808                 test byte ptr [rcx + 0x28], 8
00173f36  7506                     jne 0x173f3e
00173f38  488b01                   mov rax, qword ptr [rcx]
00173f3b  ff5028                   call qword ptr [rax + 0x28]
00173f3e  48c7834006000000000000   mov qword ptr [rbx + 0x640], 0
00173f49  488d05a82d0d00           lea rax, [rip + 0xd2da8]
00173f50  488903                   mov qword ptr [rbx], rax
00173f53  488d057e0c0f00           lea rax, [rip + 0xf0c7e]
00173f5a  48894340                 mov qword ptr [rbx + 0x40], rax
00173f5e  488b8b18060000           mov rcx, qword ptr [rbx + 0x618]
00173f65  4885c9                   test rcx, rcx
00173f68  7407                     je 0x173f71
00173f6a  488b01                   mov rax, qword ptr [rcx]
00173f6d  ff5010                   call qword ptr [rax + 0x10]
00173f70  90                       nop
00173f71  488bcb                   mov rcx, rbx
00173f74  4883c430                 add rsp, 0x30
00173f78  5b                       pop rbx
00173f79  e91271ecff               jmp 0x3b090
