; CGlobalTraceFlags::FindDeclaredFlag
; sqldk.dll, primary RVA 0x1b5140, 99 bytes in 1 chunk(s)

; chunk at RVA 0x1b5140 (99 bytes)
001b5140  4883ec58                 sub rsp, 0x58
001b5144  488b053dbf1500           mov rax, qword ptr [rip + 0x15bf3d]
001b514b  4833c4                   xor rax, rsp
001b514e  4889442448               mov qword ptr [rsp + 0x48], rax
001b5153  33c0                     xor eax, eax
001b5155  488d1564211900           lea rdx, [rip + 0x192164]
001b515c  0f57c0                   xorps xmm0, xmm0
001b515f  4889442440               mov qword ptr [rsp + 0x40], rax
001b5164  0f11442430               movups xmmword ptr [rsp + 0x30], xmm0
001b5169  66894c2430               mov word ptr [rsp + 0x30], cx
001b516e  488d05abf4ffff           lea rax, [rip - 0xb55]
001b5175  488d4c2430               lea rcx, [rsp + 0x30]
001b517a  4889442420               mov qword ptr [rsp + 0x20], rax
001b517f  41b918000000             mov r9d, 0x18
001b5185  41b838160000             mov r8d, 0x1638
001b518b  ff15bf480800             call qword ptr [rip + 0x848bf]
001b5191  488b4c2448               mov rcx, qword ptr [rsp + 0x48]
001b5196  4833cc                   xor rcx, rsp
001b5199  e802f5e4ff               call 0x46a0
001b519e  4883c458                 add rsp, 0x58
001b51a2  c3                       ret
