; MemoryClerkInternal::~MemoryClerkInternal
; sqldk.dll, primary RVA 0x154d70, 75 bytes in 1 chunk(s)

; chunk at RVA 0x154d70 (75 bytes)
00154d70  48894c2408               mov qword ptr [rsp + 8], rcx
00154d75  53                       push rbx
00154d76  4883ec30                 sub rsp, 0x30
00154d7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00154d83  488bd9                   mov rbx, rcx
00154d86  488d056b1f0f00           lea rax, [rip + 0xf1f6b]
00154d8d  488901                   mov qword ptr [rcx], rax
00154d90  488d0541fe1000           lea rax, [rip + 0x10fe41]
00154d97  48894140                 mov qword ptr [rcx + 0x40], rax
00154d9b  488b8918060000           mov rcx, qword ptr [rcx + 0x618]
00154da2  4885c9                   test rcx, rcx
00154da5  7407                     je 0x154dae
00154da7  488b01                   mov rax, qword ptr [rcx]
00154daa  ff5010                   call qword ptr [rax + 0x10]
00154dad  90                       nop
00154dae  488bcb                   mov rcx, rbx
00154db1  4883c430                 add rsp, 0x30
00154db5  5b                       pop rbx
00154db6  e9d562eeff               jmp 0x3b090
