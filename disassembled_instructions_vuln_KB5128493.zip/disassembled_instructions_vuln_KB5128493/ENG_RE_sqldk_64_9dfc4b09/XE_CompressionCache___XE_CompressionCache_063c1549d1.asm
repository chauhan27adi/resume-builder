; XE_CompressionCache::~XE_CompressionCache
; sqldk.dll, primary RVA 0x45700, 153 bytes in 1 chunk(s)

; chunk at RVA 0x45700 (153 bytes)
00045700  48894c2408               mov qword ptr [rsp + 8], rcx
00045705  57                       push rdi
00045706  4883ec30                 sub rsp, 0x30
0004570a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00045713  48895c2448               mov qword ptr [rsp + 0x48], rbx
00045718  4889742450               mov qword ptr [rsp + 0x50], rsi
0004571d  488bf9                   mov rdi, rcx
00045720  488b5118                 mov rdx, qword ptr [rcx + 0x18]
00045724  33f6                     xor esi, esi
00045726  4885d2                   test rdx, rdx
00045729  744b                     je 0x45776
0004572b  488bc2                   mov rax, rdx
0004572e  6690                     nop
00045730  4c8d4718                 lea r8, [rdi + 0x18]
00045734  4885c0                   test rax, rax
00045737  7422                     je 0x4575b
00045739  0f1f00                   nop dword ptr [rax]
0004573c  0f1f4000                 nop dword ptr [rax]
00045740  488b08                   mov rcx, qword ptr [rax]
00045743  483bc2                   cmp rax, rdx
00045746  740d                     je 0x45755
00045748  4c8bc0                   mov r8, rax
0004574b  488bc1                   mov rax, rcx
0004574e  4885c9                   test rcx, rcx
00045751  75ed                     jne 0x45740
00045753  eb06                     jmp 0x4575b
00045755  498908                   mov qword ptr [r8], rcx
00045758  488930                   mov qword ptr [rax], rsi
0004575b  488d4afc                 lea rcx, [rdx - 4]
0004575f  4885c9                   test rcx, rcx
00045762  7406                     je 0x4576a
00045764  ff15e6f82c00             call qword ptr [rip + 0x2cf8e6]
0004576a  488b5718                 mov rdx, qword ptr [rdi + 0x18]
0004576e  488bc2                   mov rax, rdx
00045771  4885d2                   test rdx, rdx
00045774  75ba                     jne 0x45730
00045776  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
0004577a  4885c9                   test rcx, rcx
0004577d  7406                     je 0x45785
0004577f  ff1503f92c00             call qword ptr [rip + 0x2cf903]
00045785  48897720                 mov qword ptr [rdi + 0x20], rsi
00045789  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0004578e  488b742450               mov rsi, qword ptr [rsp + 0x50]
00045793  4883c430                 add rsp, 0x30
00045797  5f                       pop rdi
00045798  c3                       ret
