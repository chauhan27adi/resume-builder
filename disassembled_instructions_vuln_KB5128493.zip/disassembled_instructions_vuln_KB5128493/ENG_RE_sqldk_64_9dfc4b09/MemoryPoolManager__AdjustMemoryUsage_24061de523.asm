; MemoryPoolManager::AdjustMemoryUsage
; sqldk.dll, primary RVA 0xdc00, 3279 bytes in 1 chunk(s)

; chunk at RVA 0xdc00 (3279 bytes)
0000dc00  4489442418               mov dword ptr [rsp + 0x18], r8d
0000dc05  53                       push rbx
0000dc06  56                       push rsi
0000dc07  57                       push rdi
0000dc08  4154                     push r12
0000dc0a  4155                     push r13
0000dc0c  4156                     push r14
0000dc0e  4157                     push r15
0000dc10  4881ecb0020000           sub rsp, 0x2b0
0000dc17  48c78424a0010000feffffff mov qword ptr [rsp + 0x1a0], 0xfffffffffffffffe
0000dc23  0f29b424a0020000         movaps xmmword ptr [rsp + 0x2a0], xmm6
0000dc2b  418bf1                   mov esi, r9d
0000dc2e  488bda                   mov rbx, rdx
0000dc31  4c8bf1                   mov r14, rcx
0000dc34  4533e4                   xor r12d, r12d
0000dc37  4c89642428               mov qword ptr [rsp + 0x28], r12
0000dc3c  4c89642450               mov qword ptr [rsp + 0x50], r12
0000dc41  4c89642440               mov qword ptr [rsp + 0x40], r12
0000dc46  4c89642438               mov qword ptr [rsp + 0x38], r12
0000dc4b  4c89a42488000000         mov qword ptr [rsp + 0x88], r12
0000dc53  4c89642458               mov qword ptr [rsp + 0x58], r12
0000dc58  458bec                   mov r13d, r12d
0000dc5b  65488b142558000000       mov rdx, qword ptr gs:[0x58]
0000dc64  8b0566733000             mov eax, dword ptr [rip + 0x307366]
0000dc6a  8b3d483cffff             mov edi, dword ptr [rip - 0xc3b8]
0000dc70  48033cc2                 add rdi, qword ptr [rdx + rax*8]
0000dc74  488b8700010000           mov rax, qword ptr [rdi + 0x100]
0000dc7b  4885c0                   test rax, rax
0000dc7e  0f8407750900             je 0xa518b
0000dc84  f6806802000040           test byte ptr [rax + 0x268], 0x40
0000dc8b  0f8519790900             jne 0xa55aa
0000dc91  4c8d3d10173200           lea r15, [rip + 0x321710]
0000dc98  4c89bc24a8000000         mov qword ptr [rsp + 0xa8], r15
0000dca0  418bfc                   mov edi, r12d
0000dca3  4489a424b0000000         mov dword ptr [rsp + 0xb0], r12d
0000dcab  85f6                     test esi, esi
0000dcad  0f85ec740900             jne 0xa519f
0000dcb3  c78424780100007e004000   mov dword ptr [rsp + 0x178], 0x40007e
0000dcbe  4c89a42480010000         mov qword ptr [rsp + 0x180], r12
0000dcc6  4c89a42490010000         mov qword ptr [rsp + 0x190], r12
0000dcce  4c89a42488010000         mov qword ptr [rsp + 0x188], r12
0000dcd6  4c89a42498010000         mov qword ptr [rsp + 0x198], r12
0000dcde  4533c9                   xor r9d, r9d
0000dce1  4c8d842478010000         lea r8, [rsp + 0x178]
0000dce9  33d2                     xor edx, edx
0000dceb  498bcf                   mov rcx, r15
0000dcee  e8dd100000               call 0xedd0
0000dcf3  85c0                     test eax, eax
0000dcf5  0f85a6780900             jne 0xa55a1
0000dcfb  be01000000               mov esi, 1
0000dd00  89b424b0000000           mov dword ptr [rsp + 0xb0], esi
0000dd07  4983fe01                 cmp r14, 1
0000dd0b  4c0f4cf6                 cmovl r14, rsi
0000dd0f  4c89b424f0020000         mov qword ptr [rsp + 0x2f0], r14
0000dd17  488b05c2163200           mov rax, qword ptr [rip + 0x3216c2]
0000dd1e  4889842480000000         mov qword ptr [rsp + 0x80], rax
0000dd26  4c8b0573163200           mov r8, qword ptr [rip + 0x321673]
0000dd2d  4c3bc3                   cmp r8, rbx
0000dd30  490f47d8                 cmova rbx, r8
0000dd34  48899c24f8020000         mov qword ptr [rsp + 0x2f8], rbx
0000dd3c  48bf4b598638d6c56d34     movabs rdi, 0x346dc5d63886594b
0000dd46  448b1577773000           mov r10d, dword ptr [rip + 0x307777]
0000dd4d  4c8b0d74773000           mov r9, qword ptr [rip + 0x307774]
0000dd54  49c7c3ffffffff           mov r11, 0xffffffffffffffff
0000dd5b  4c895c2448               mov qword ptr [rsp + 0x48], r11
0000dd60  493bd8                   cmp rbx, r8
0000dd63  0f82bf740900             jb 0xa5228
0000dd69  488bcb                   mov rcx, rbx
0000dd6c  492bc8                   sub rcx, r8
0000dd6f  493bcb                   cmp rcx, r11
0000dd72  0f84a8740900             je 0xa5220
0000dd78  4585d2                   test r10d, r10d
0000dd7b  0f84b0740900             je 0xa5231
0000dd81  4869c1e8030000           imul rax, rcx, 0x3e8
0000dd88  33d2                     xor edx, edx
0000dd8a  49f7f1                   div r9
0000dd8d  488bd0                   mov rdx, rax
0000dd90  eb01                     jmp 0xdd93
0000dd92  cc                       int3
0000dd93  83fa64                   cmp edx, 0x64
0000dd96  0f8ca5740900             jl 0xa5241
0000dd9c  493bd8                   cmp rbx, r8
0000dd9f  0f82af740900             jb 0xa5254
0000dda5  488bcb                   mov rcx, rbx
0000dda8  492bc8                   sub rcx, r8
0000ddab  493bcb                   cmp rcx, r11
0000ddae  0f849b740900             je 0xa524f
0000ddb4  4585d2                   test r10d, r10d
0000ddb7  0f84a0740900             je 0xa525d
0000ddbd  4869c1e8030000           imul rax, rcx, 0x3e8
0000ddc4  33d2                     xor edx, edx
0000ddc6  49f7f1                   div r9
0000ddc9  4889442448               mov qword ptr [rsp + 0x48], rax
0000ddce  eb01                     jmp 0xddd1
0000ddd0  cc                       int3
0000ddd1  496bd61b                 imul rdx, r14, 0x1b
0000ddd5  48c1fa05                 sar rdx, 5
0000ddd9  48899424a0000000         mov qword ptr [rsp + 0xa0], rdx
0000dde1  488bc2                   mov rax, rdx
0000dde4  48c1f802                 sar rax, 2
0000dde8  488d0c40                 lea rcx, [rax + rax*2]
0000ddec  48894c2478               mov qword ptr [rsp + 0x78], rcx
0000ddf1  488bc2                   mov rax, rdx
0000ddf4  48c1f804                 sar rax, 4
0000ddf8  488d0c40                 lea rcx, [rax + rax*2]
0000ddfc  48894c2430               mov qword ptr [rsp + 0x30], rcx
0000de01  488bc2                   mov rax, rdx
0000de04  48c1f805                 sar rax, 5
0000de08  4883f801                 cmp rax, 1
0000de0c  480f4cc6                 cmovl rax, rsi
0000de10  4889842498000000         mov qword ptr [rsp + 0x98], rax
0000de18  488b05f9123200           mov rax, qword ptr [rip + 0x3212f9]
0000de1f  488905da123200           mov qword ptr [rip + 0x3212da], rax
0000de26  488915fb123200           mov qword ptr [rip + 0x3212fb], rdx
0000de2d  4c8925e4123200           mov qword ptr [rip + 0x3212e4], r12
0000de34  4c8925e5123200           mov qword ptr [rip + 0x3212e5], r12
0000de3b  488b0536133200           mov rax, qword ptr [rip + 0x321336]
0000de42  48890517133200           mov qword ptr [rip + 0x321317], rax
0000de49  48891538133200           mov qword ptr [rip + 0x321338], rdx
0000de50  4c892521133200           mov qword ptr [rip + 0x321321], r12
0000de57  4c892522133200           mov qword ptr [rip + 0x321322], r12
0000de5e  488b0573133200           mov rax, qword ptr [rip + 0x321373]
0000de65  48890554133200           mov qword ptr [rip + 0x321354], rax
0000de6c  48891575133200           mov qword ptr [rip + 0x321375], rdx
0000de73  4c89255e133200           mov qword ptr [rip + 0x32135e], r12
0000de7a  4c89255f133200           mov qword ptr [rip + 0x32135f], r12
0000de81  488b05b0133200           mov rax, qword ptr [rip + 0x3213b0]
0000de88  48890591133200           mov qword ptr [rip + 0x321391], rax
0000de8f  488915b2133200           mov qword ptr [rip + 0x3213b2], rdx
0000de96  4c89259b133200           mov qword ptr [rip + 0x32139b], r12
0000de9d  4c89259c133200           mov qword ptr [rip + 0x32139c], r12
0000dea4  488b05ed133200           mov rax, qword ptr [rip + 0x3213ed]
0000deab  488905ce133200           mov qword ptr [rip + 0x3213ce], rax
0000deb2  488915ef133200           mov qword ptr [rip + 0x3213ef], rdx
0000deb9  4c8925d8133200           mov qword ptr [rip + 0x3213d8], r12
0000dec0  4c8925d9133200           mov qword ptr [rip + 0x3213d9], r12
0000dec7  488b052a143200           mov rax, qword ptr [rip + 0x32142a]
0000dece  4889050b143200           mov qword ptr [rip + 0x32140b], rax
0000ded5  4889152c143200           mov qword ptr [rip + 0x32142c], rdx
0000dedc  4c892515143200           mov qword ptr [rip + 0x321415], r12
0000dee3  4c892516143200           mov qword ptr [rip + 0x321416], r12
0000deea  4c8935df313100           mov qword ptr [rip + 0x3131df], r14
0000def1  4c8b25f0333100           mov r12, qword ptr [rip + 0x3133f0]
0000def8  ff1552593000             call qword ptr [rip + 0x305952]
0000defe  4c8bf0                   mov r14, rax
0000df01  33c0                     xor eax, eax
0000df03  8bf0                     mov esi, eax
0000df05  448b3d44763000           mov r15d, dword ptr [rip + 0x307644]
0000df0c  0fb7f8                   movzx edi, ax
0000df0f  4585ff                   test r15d, r15d
0000df12  742a                     je 0xdf3e
0000df14  0f1f00                   nop dword ptr [rax]
0000df17  660f1f840000000000       nop word ptr [rax + rax]
0000df20  0fb7d7                   movzx edx, di
0000df23  488d0d66663000           lea rcx, [rip + 0x306666]
0000df2a  e8c179ffff               call 0x58f0
0000df2f  48037058                 add rsi, qword ptr [rax + 0x58]
0000df33  66ffc7                   inc di
0000df36  0fb7c7                   movzx eax, di
0000df39  413bc7                   cmp eax, r15d
0000df3c  72e2                     jb 0xdf20
0000df3e  488d4601                 lea rax, [rsi + 1]
0000df42  4899                     cqo
0000df44  482bc2                   sub rax, rdx
0000df47  48d1f8                   sar rax, 1
0000df4a  4c3bf0                   cmp r14, rax
0000df4d  490f4cc6                 cmovl rax, r14
0000df51  4c2bf0                   sub r14, rax
0000df54  4d2bf4                   sub r14, r12
0000df57  f04c0fc13588333100       lock xadd qword ptr [rip + 0x313388], r14
0000df60  488bbc2480000000         mov rdi, qword ptr [rsp + 0x80]
0000df68  4c8bcf                   mov r9, rdi
0000df6b  4c8b35636b3000           mov r14, qword ptr [rip + 0x306b63]
0000df72  f20f10354e5e2500         movsd xmm6, qword ptr [rip + 0x255e4e]
0000df7a  480fbcc7                 bsf rax, rdi
0000df7e  4c8b9c24f0020000         mov r11, qword ptr [rsp + 0x2f0]
0000df86  0f8446730900             je 0xa52d2
0000df8c  0f57d2                   xorps xmm2, xmm2
0000df8f  f2490f2ad3               cvtsi2sd xmm2, r11
0000df94  488d3565313100           lea rsi, [rip + 0x313165]
0000df9b  41bff0000000             mov r15d, 0xf0
0000dfa1  4533e4                   xor r12d, r12d
0000dfa4  0f1f4000                 nop dword ptr [rax]
0000dfa8  0f1f840000000000         nop dword ptr [rax + rax]
0000dfb0  448bd0                   mov r10d, eax
0000dfb3  4969d280030000           imul rdx, r10, 0x380
0000dfba  4803d6                   add rdx, rsi
0000dfbd  498bc4                   mov rax, r12
0000dfc0  4c8b82c8000000           mov r8, qword ptr [rdx + 0xc8]
0000dfc7  4c898290000000           mov qword ptr [rdx + 0x90], r8
0000dfce  83bad000000001           cmp dword ptr [rdx + 0xd0], 1
0000dfd5  0f8497720900             je 0xa5272
0000dfdb  498bc0                   mov rax, r8
0000dfde  488b8a28010000           mov rcx, qword ptr [rdx + 0x128]
0000dfe5  48898af0000000           mov qword ptr [rdx + 0xf0], rcx
0000dfec  83ba3001000001           cmp dword ptr [rdx + 0x130], 1
0000dff3  0f8489720900             je 0xa5282
0000dff9  4803c1                   add rax, rcx
0000dffc  4903c8                   add rcx, r8
0000dfff  4c8b8288010000           mov r8, qword ptr [rdx + 0x188]
0000e006  4c898250010000           mov qword ptr [rdx + 0x150], r8
0000e00d  83ba9001000001           cmp dword ptr [rdx + 0x190], 1
0000e014  0f8478720900             je 0xa5292
0000e01a  4903c0                   add rax, r8
0000e01d  4903c8                   add rcx, r8
0000e020  4c8b82e8010000           mov r8, qword ptr [rdx + 0x1e8]
0000e027  4c8982b0010000           mov qword ptr [rdx + 0x1b0], r8
0000e02e  83baf001000001           cmp dword ptr [rdx + 0x1f0], 1
0000e035  0f8467720900             je 0xa52a2
0000e03b  4903c0                   add rax, r8
0000e03e  4903c8                   add rcx, r8
0000e041  4c8b8248020000           mov r8, qword ptr [rdx + 0x248]
0000e048  4c898210020000           mov qword ptr [rdx + 0x210], r8
0000e04f  83ba5002000001           cmp dword ptr [rdx + 0x250], 1
0000e056  7506                     jne 0xe05e
0000e058  41f6c620                 test r14b, 0x20
0000e05c  7503                     jne 0xe061
0000e05e  4903c0                   add rax, r8
0000e061  4903c8                   add rcx, r8
0000e064  4c8b82a8020000           mov r8, qword ptr [rdx + 0x2a8]
0000e06b  4c898270020000           mov qword ptr [rdx + 0x270], r8
0000e072  83bab002000001           cmp dword ptr [rdx + 0x2b0], 1
0000e079  0f8433720900             je 0xa52b2
0000e07f  4903c0                   add rax, r8
0000e082  4903c8                   add rcx, r8
0000e085  4c8b8208030000           mov r8, qword ptr [rdx + 0x308]
0000e08c  4c8982d0020000           mov qword ptr [rdx + 0x2d0], r8
0000e093  83ba1003000001           cmp dword ptr [rdx + 0x310], 1
0000e09a  0f8422720900             je 0xa52c2
0000e0a0  4903c0                   add rax, r8
0000e0a3  4903c8                   add rcx, r8
0000e0a6  48894228                 mov qword ptr [rdx + 0x28], rax
0000e0aa  48894a30                 mov qword ptr [rdx + 0x30], rcx
0000e0ae  0f28c2                   movaps xmm0, xmm2
0000e0b1  f20f598218030000         mulsd xmm0, qword ptr [rdx + 0x318]
0000e0b9  f20f5ec6                 divsd xmm0, xmm6
0000e0bd  f2480f2cc8               cvttsd2si rcx, xmm0
0000e0c2  48894a18                 mov qword ptr [rdx + 0x18], rcx
0000e0c6  0f28ca                   movaps xmm1, xmm2
0000e0c9  f20f598a20030000         mulsd xmm1, qword ptr [rdx + 0x320]
0000e0d1  f20f5ece                 divsd xmm1, xmm6
0000e0d5  f2480f2cc1               cvttsd2si rax, xmm1
0000e0da  48894220                 mov qword ptr [rdx + 0x20], rax
0000e0de  4c895a50                 mov qword ptr [rdx + 0x50], r11
0000e0e2  4c03e9                   add r13, rcx
0000e0e5  b890000000               mov eax, 0x90
0000e0ea  4d85c0                   test r8, r8
0000e0ed  490f4fc7                 cmovg rax, r15
0000e0f1  4c010410                 add qword ptr [rax + rdx], r8
0000e0f5  4c89a2d0020000           mov qword ptr [rdx + 0x2d0], r12
0000e0fc  4d0fb3d1                 btr r9, r10
0000e100  490fbcc1                 bsf rax, r9
0000e104  0f85a6feffff             jne 0xdfb0
0000e10a  eb01                     jmp 0xe10d
0000e10c  cc                       int3
0000e10d  498bc3                   mov rax, r11
0000e110  492bc5                   sub rax, r13
0000e113  498bd4                   mov rdx, r12
0000e116  480f49d0                 cmovns rdx, rax
0000e11a  4889542470               mov qword ptr [rsp + 0x70], rdx
0000e11f  486bc21b                 imul rax, rdx, 0x1b
0000e123  48c1f805                 sar rax, 5
0000e127  4889842490000000         mov qword ptr [rsp + 0x90], rax
0000e12f  48897c2460               mov qword ptr [rsp + 0x60], rdi
0000e134  488d0d852f3100           lea rcx, [rip + 0x312f85]
0000e13b  480fbcc7                 bsf rax, rdi
0000e13f  4889442468               mov qword ptr [rsp + 0x68], rax
0000e144  0f8425720900             je 0xa536f
0000e14a  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
0000e14f  eb01                     jmp 0xe152
0000e151  cc                       int3
0000e152  4889442478               mov qword ptr [rsp + 0x78], rax
0000e157  4c69e080030000           imul r12, rax, 0x380
0000e15e  33c0                     xor eax, eax
0000e160  448bf8                   mov r15d, eax
0000e163  448be8                   mov r13d, eax
0000e166  8bf0                     mov esi, eax
0000e168  4c8d89b8000000           lea r9, [rcx + 0xb8]
0000e16f  4d03cc                   add r9, r12
0000e172  c744242002000000         mov dword ptr [rsp + 0x20], 2
0000e17a  eb01                     jmp 0xe17d
0000e17c  cc                       int3
0000e17d  4c8d0476                 lea r8, [rsi + rsi*2]
0000e181  49c1e005                 shl r8, 5
0000e185  4b8b7c0118               mov rdi, qword ptr [r9 + r8 + 0x18]
0000e18a  478b5c0158               mov r11d, dword ptr [r9 + r8 + 0x58]
0000e18f  4183fb01                 cmp r11d, 1
0000e193  0f8442710900             je 0xa52db
0000e199  48017c2428               add qword ptr [rsp + 0x28], rdi
0000e19e  4c8bd0                   mov r10, rax
0000e1a1  4183fb01                 cmp r11d, 1
0000e1a5  7433                     je 0xe1da
0000e1a7  488bc7                   mov rax, rdi
0000e1aa  4b2b0401                 sub rax, qword ptr [r9 + r8]
0000e1ae  4869c0e8030000           imul rax, rax, 0x3e8
0000e1b5  48634c2448               movsxd rcx, dword ptr [rsp + 0x48]
0000e1ba  4899                     cqo
0000e1bc  48f7f9                   idiv rcx
0000e1bf  4c8bd0                   mov r10, rax
0000e1c2  4b8b4c0110               mov rcx, qword ptr [r9 + r8 + 0x10]
0000e1c7  488d0449                 lea rax, [rcx + rcx*2]
0000e1cb  4899                     cqo
0000e1cd  83e203                   and edx, 3
0000e1d0  4803c2                   add rax, rdx
0000e1d3  48c1f802                 sar rax, 2
0000e1d7  4c03d0                   add r10, rax
0000e1da  4f89540110               mov qword ptr [r9 + r8 + 0x10], r10
0000e1df  488bd3                   mov rdx, rbx
0000e1e2  4b395c0130               cmp qword ptr [r9 + r8 + 0x30], rbx
0000e1e7  4b0f4c540130             cmovl rdx, qword ptr [r9 + r8 + 0x30]
0000e1ed  488b4c2430               mov rcx, qword ptr [rsp + 0x30]
0000e1f2  4c3bd1                   cmp r10, rcx
0000e1f5  490f4cca                 cmovl rcx, r10
0000e1f9  4803cf                   add rcx, rdi
0000e1fc  488bc7                   mov rax, rdi
0000e1ff  483bf9                   cmp rdi, rcx
0000e202  480f4ec1                 cmovle rax, rcx
0000e206  483bc2                   cmp rax, rdx
0000e209  480f4fd0                 cmovg rdx, rax
0000e20d  4b89540120               mov qword ptr [r9 + r8 + 0x20], rdx
0000e212  4533d2                   xor r10d, r10d
0000e215  4f89540130               mov qword ptr [r9 + r8 + 0x30], r10
0000e21a  4183fb01                 cmp r11d, 1
0000e21e  0f84ca700900             je 0xa52ee
0000e224  4c03fa                   add r15, rdx
0000e227  4801542440               add qword ptr [rsp + 0x40], rdx
0000e22c  4c03ea                   add r13, rdx
0000e22f  488d0d8a2e3100           lea rcx, [rip + 0x312e8a]
0000e236  498b440c60               mov rax, qword ptr [r12 + rcx + 0x60]
0000e23b  483bd0                   cmp rdx, rax
0000e23e  480f4cc2                 cmovl rax, rdx
0000e242  4183fb01                 cmp r11d, 1
0000e246  0f84b2700900             je 0xa52fe
0000e24c  4885f6                   test rsi, rsi
0000e24f  7506                     jne 0xe257
0000e251  4183fb02                 cmp r11d, 2
0000e255  7410                     je 0xe267
0000e257  4901bc0858e00000         add qword ptr [r8 + rcx + 0xe058], rdi
0000e25f  4901840860e00000         add qword ptr [r8 + rcx + 0xe060], rax
0000e267  4c8d4601                 lea r8, [rsi + 1]
0000e26b  4f8d0440                 lea r8, [r8 + r8*2]
0000e26f  49c1e005                 shl r8, 5
0000e273  4b8b7c0118               mov rdi, qword ptr [r9 + r8 + 0x18]
0000e278  478b5c0158               mov r11d, dword ptr [r9 + r8 + 0x58]
0000e27d  4183fb01                 cmp r11d, 1
0000e281  7506                     jne 0xe289
0000e283  41f6c620                 test r14b, 0x20
0000e287  753e                     jne 0xe2c7
0000e289  48017c2428               add qword ptr [rsp + 0x28], rdi
0000e28e  4183fb01                 cmp r11d, 1
0000e292  7433                     je 0xe2c7
0000e294  488bc7                   mov rax, rdi
0000e297  4b2b0401                 sub rax, qword ptr [r9 + r8]
0000e29b  4869c0e8030000           imul rax, rax, 0x3e8
0000e2a2  48634c2448               movsxd rcx, dword ptr [rsp + 0x48]
0000e2a7  4899                     cqo
0000e2a9  48f7f9                   idiv rcx
0000e2ac  4c8bd0                   mov r10, rax
0000e2af  4b8b4c0110               mov rcx, qword ptr [r9 + r8 + 0x10]
0000e2b4  488d0449                 lea rax, [rcx + rcx*2]
0000e2b8  4899                     cqo
0000e2ba  83e203                   and edx, 3
0000e2bd  4803c2                   add rax, rdx
0000e2c0  48c1f802                 sar rax, 2
0000e2c4  4c03d0                   add r10, rax
0000e2c7  4f89540110               mov qword ptr [r9 + r8 + 0x10], r10
0000e2cc  488bd3                   mov rdx, rbx
0000e2cf  4b395c0130               cmp qword ptr [r9 + r8 + 0x30], rbx
0000e2d4  4b0f4c540130             cmovl rdx, qword ptr [r9 + r8 + 0x30]
0000e2da  488b4c2430               mov rcx, qword ptr [rsp + 0x30]
0000e2df  4c3bd1                   cmp r10, rcx
0000e2e2  490f4cca                 cmovl rcx, r10
0000e2e6  4803cf                   add rcx, rdi
0000e2e9  488bc7                   mov rax, rdi
0000e2ec  483bf9                   cmp rdi, rcx
0000e2ef  480f4ec1                 cmovle rax, rcx
0000e2f3  483bc2                   cmp rax, rdx
0000e2f6  480f4fd0                 cmovg rdx, rax
0000e2fa  4b89540120               mov qword ptr [r9 + r8 + 0x20], rdx
0000e2ff  33c0                     xor eax, eax
0000e301  4b89440130               mov qword ptr [r9 + r8 + 0x30], rax
0000e306  4183fb01                 cmp r11d, 1
0000e30a  7506                     jne 0xe312
0000e30c  41f6c620                 test r14b, 0x20
0000e310  7508                     jne 0xe31a
0000e312  4c03fa                   add r15, rdx
0000e315  4801542440               add qword ptr [rsp + 0x40], rdx
0000e31a  4c03ea                   add r13, rdx
0000e31d  4c8d159c2d3100           lea r10, [rip + 0x312d9c]
0000e324  4b8b4c1460               mov rcx, qword ptr [r12 + r10 + 0x60]
0000e329  483bd1                   cmp rdx, rcx
0000e32c  480f4cca                 cmovl rcx, rdx
0000e330  4183fb01                 cmp r11d, 1
0000e334  7506                     jne 0xe33c
0000e336  41f6c620                 test r14b, 0x20
0000e33a  751b                     jne 0xe357
0000e33c  837c242001               cmp dword ptr [rsp + 0x20], 1
0000e341  0f84c76f0900             je 0xa530e
0000e347  4b01bc1058e00000         add qword ptr [r8 + r10 + 0xe058], rdi
0000e34f  4b018c1060e00000         add qword ptr [r8 + r10 + 0xe060], rcx
0000e357  4c8d4602                 lea r8, [rsi + 2]
0000e35b  4f8d0440                 lea r8, [r8 + r8*2]
0000e35f  49c1e005                 shl r8, 5
0000e363  4b8b7c0118               mov rdi, qword ptr [r9 + r8 + 0x18]
0000e368  478b5c0158               mov r11d, dword ptr [r9 + r8 + 0x58]
0000e36d  4183fb01                 cmp r11d, 1
0000e371  0f84a76f0900             je 0xa531e
0000e377  48017c2428               add qword ptr [rsp + 0x28], rdi
0000e37c  4c8bd0                   mov r10, rax
0000e37f  4183fb01                 cmp r11d, 1
0000e383  7433                     je 0xe3b8
0000e385  488bc7                   mov rax, rdi
0000e388  4b2b0401                 sub rax, qword ptr [r9 + r8]
0000e38c  4869c0e8030000           imul rax, rax, 0x3e8
0000e393  48634c2448               movsxd rcx, dword ptr [rsp + 0x48]
0000e398  4899                     cqo
0000e39a  48f7f9                   idiv rcx
0000e39d  4c8bd0                   mov r10, rax
0000e3a0  4b8b4c0110               mov rcx, qword ptr [r9 + r8 + 0x10]
0000e3a5  488d0449                 lea rax, [rcx + rcx*2]
0000e3a9  4899                     cqo
0000e3ab  83e203                   and edx, 3
0000e3ae  4803c2                   add rax, rdx
0000e3b1  48c1f802                 sar rax, 2
0000e3b5  4c03d0                   add r10, rax
0000e3b8  4f89540110               mov qword ptr [r9 + r8 + 0x10], r10
0000e3bd  488bd3                   mov rdx, rbx
0000e3c0  4b395c0130               cmp qword ptr [r9 + r8 + 0x30], rbx
0000e3c5  4b0f4c540130             cmovl rdx, qword ptr [r9 + r8 + 0x30]
0000e3cb  488b442430               mov rax, qword ptr [rsp + 0x30]
0000e3d0  4c3bd0                   cmp r10, rax
0000e3d3  490f4cc2                 cmovl rax, r10
0000e3d7  4803c7                   add rax, rdi
0000e3da  488bcf                   mov rcx, rdi
0000e3dd  483bf8                   cmp rdi, rax
0000e3e0  480f4ec8                 cmovle rcx, rax
0000e3e4  483bca                   cmp rcx, rdx
0000e3e7  480f4fd1                 cmovg rdx, rcx
0000e3eb  4b89540120               mov qword ptr [r9 + r8 + 0x20], rdx
0000e3f0  4bc744013000000000       mov qword ptr [r9 + r8 + 0x30], 0
0000e3f9  4183fb01                 cmp r11d, 1
0000e3fd  0f842e6f0900             je 0xa5331
0000e403  4c03fa                   add r15, rdx
0000e406  4801542440               add qword ptr [rsp + 0x40], rdx
0000e40b  4c03ea                   add r13, rdx
0000e40e  488d0dab2c3100           lea rcx, [rip + 0x312cab]
0000e415  4d8b540c60               mov r10, qword ptr [r12 + rcx + 0x60]
0000e41a  498bc2                   mov rax, r10
0000e41d  493bd2                   cmp rdx, r10
0000e420  480f4cc2                 cmovl rax, rdx
0000e424  4183fb01                 cmp r11d, 1
0000e428  0f84136f0900             je 0xa5341
0000e42e  837c242000               cmp dword ptr [rsp + 0x20], 0
0000e433  0f84186f0900             je 0xa5351
0000e439  4901bc0858e00000         add qword ptr [r8 + rcx + 0xe058], rdi
0000e441  4901840860e00000         add qword ptr [r8 + rcx + 0xe060], rax
0000e449  4d8b540c60               mov r10, qword ptr [r12 + rcx + 0x60]
0000e44e  8344242003               add dword ptr [rsp + 0x20], 3
0000e453  4883c603                 add rsi, 3
0000e457  4883fe06                 cmp rsi, 6
0000e45b  0f8c7c040000             jl 0xe8dd
0000e461  4d897c0c78               mov qword ptr [r12 + rcx + 0x78], r15
0000e466  4d89ac0c80000000         mov qword ptr [r12 + rcx + 0x80], r13
0000e46e  4c8b442468               mov r8, qword ptr [rsp + 0x68]
0000e473  4c8d0d462c3100           lea r9, [rip + 0x312c46]
0000e47a  4585c0                   test r8d, r8d
0000e47d  7442                     je 0xe4c1
0000e47f  498b540c58               mov rdx, qword ptr [r12 + rcx + 0x58]
0000e484  488b442470               mov rax, qword ptr [rsp + 0x70]
0000e489  4803c2                   add rax, rdx
0000e48c  4839842498000000         cmp qword ptr [rsp + 0x98], rax
0000e494  480f4f842498000000       cmovg rax, qword ptr [rsp + 0x98]
0000e49d  4f8b540c60               mov r10, qword ptr [r12 + r9 + 0x60]
0000e4a2  493bc2                   cmp rax, r10
0000e4a5  0f8cb66e0900             jl 0xa5361
0000e4ab  4b8b4c0c68               mov rcx, qword ptr [r12 + r9 + 0x68]
0000e4b0  482bca                   sub rcx, rdx
0000e4b3  b800000000               mov eax, 0
0000e4b8  480f49c1                 cmovns rax, rcx
0000e4bc  4801442450               add qword ptr [rsp + 0x50], rax
0000e4c1  498bcf                   mov rcx, r15
0000e4c4  4d3bfa                   cmp r15, r10
0000e4c7  490f4dca                 cmovge rcx, r10
0000e4cb  488bd1                   mov rdx, rcx
0000e4ce  4585c0                   test r8d, r8d
0000e4d1  740b                     je 0xe4de
0000e4d3  4b3b4c0c58               cmp rcx, qword ptr [r12 + r9 + 0x58]
0000e4d8  4b0f4d540c58             cmovge rdx, qword ptr [r12 + r9 + 0x58]
0000e4de  4801542438               add qword ptr [rsp + 0x38], rdx
0000e4e3  4c2bfa                   sub r15, rdx
0000e4e6  4c01bc2488000000         add qword ptr [rsp + 0x88], r15
0000e4ee  482bca                   sub rcx, rdx
0000e4f1  4c8b4c2458               mov r9, qword ptr [rsp + 0x58]
0000e4f6  4c03c9                   add r9, rcx
0000e4f9  4c894c2458               mov qword ptr [rsp + 0x58], r9
0000e4fe  488b4c2460               mov rcx, qword ptr [rsp + 0x60]
0000e503  488b442478               mov rax, qword ptr [rsp + 0x78]
0000e508  480fb3c1                 btr rcx, rax
0000e50c  48894c2460               mov qword ptr [rsp + 0x60], rcx
0000e511  480fbcc1                 bsf rax, rcx
0000e515  4889442468               mov qword ptr [rsp + 0x68], rax
0000e51a  0f85b0030000             jne 0xe8d0
0000e520  488b9c24f8020000         mov rbx, qword ptr [rsp + 0x2f8]
0000e528  488b542470               mov rdx, qword ptr [rsp + 0x70]
0000e52d  4c8b9c24f0020000         mov r11, qword ptr [rsp + 0x2f0]
0000e535  488bbc2480000000         mov rdi, qword ptr [rsp + 0x80]
0000e53d  4533e4                   xor r12d, r12d
0000e540  eb01                     jmp 0xe543
0000e542  cc                       int3
0000e543  488b05d60b3200           mov rax, qword ptr [rip + 0x320bd6]
0000e54a  483905c70b3200           cmp qword ptr [rip + 0x320bc7], rax
0000e551  480f4f05bf0b3200         cmovg rax, qword ptr [rip + 0x320bbf]
0000e559  488905782b3100           mov qword ptr [rip + 0x312b78], rax
0000e560  488bc2                   mov rax, rdx
0000e563  4c3bca                   cmp r9, rdx
0000e566  490f4cc1                 cmovl rax, r9
0000e56a  4803442438               add rax, qword ptr [rsp + 0x38]
0000e56f  4889442470               mov qword ptr [rsp + 0x70], rax
0000e574  498bcb                   mov rcx, r11
0000e577  482b4c2428               sub rcx, qword ptr [rsp + 0x28]
0000e57c  4d8bc4                   mov r8, r12
0000e57f  4c0f49c1                 cmovns r8, rcx
0000e583  4c898424c8000000         mov qword ptr [rsp + 0xc8], r8
0000e58b  4c2bd8                   sub r11, rax
0000e58e  498bc4                   mov rax, r12
0000e591  490f49c3                 cmovns rax, r11
0000e595  48898424d0000000         mov qword ptr [rsp + 0xd0], rax
0000e59d  488bc2                   mov rax, rdx
0000e5a0  482b442450               sub rax, qword ptr [rsp + 0x50]
0000e5a5  4d8bc4                   mov r8, r12
0000e5a8  4c0f49c0                 cmovns r8, rax
0000e5ac  4c89842498000000         mov qword ptr [rsp + 0x98], r8
0000e5b4  492bd1                   sub rdx, r9
0000e5b7  498bc4                   mov rax, r12
0000e5ba  480f49c2                 cmovns rax, rdx
0000e5be  4889442478               mov qword ptr [rsp + 0x78], rax
0000e5c3  833d362b310000           cmp dword ptr [rip + 0x312b36], 0
0000e5ca  0f84aa6d0900             je 0xa537a
0000e5d0  480fbcff                 bsf rdi, rdi
0000e5d4  0f84bc030000             je 0xe996
0000e5da  8bc7                     mov eax, edi
0000e5dc  48898424b8000000         mov qword ptr [rsp + 0xb8], rax
0000e5e4  4c69f880030000           imul r15, rax, 0x380
0000e5eb  4c897c2430               mov qword ptr [rsp + 0x30], r15
0000e5f0  4c8d15c92a3100           lea r10, [rip + 0x312ac9]
0000e5f7  4f8b4c1760               mov r9, qword ptr [r15 + r10 + 0x60]
0000e5fc  4d6bc11b                 imul r8, r9, 0x1b
0000e600  49c1f805                 sar r8, 5
0000e604  4c898424d8000000         mov qword ptr [rsp + 0xd8], r8
0000e60c  4c898424e0000000         mov qword ptr [rsp + 0xe0], r8
0000e614  498bd8                   mov rbx, r8
0000e617  48c1fb05                 sar rbx, 5
0000e61b  4883fb01                 cmp rbx, 1
0000e61f  b901000000               mov ecx, 1
0000e624  480f4cd9                 cmovl rbx, rcx
0000e628  4f8b5c1758               mov r11, qword ptr [r15 + r10 + 0x58]
0000e62d  498bc1                   mov rax, r9
0000e630  492bc3                   sub rax, r11
0000e633  498bd4                   mov rdx, r12
0000e636  480f49d0                 cmovns rdx, rax
0000e63a  4b8b741768               mov rsi, qword ptr [r15 + r10 + 0x68]
0000e63f  498bc1                   mov rax, r9
0000e642  482bc6                   sub rax, rsi
0000e645  4d8bec                   mov r13, r12
0000e648  4c0f49e8                 cmovns r13, rax
0000e64c  4f8b541778               mov r10, qword ptr [r15 + r10 + 0x78]
0000e651  498bc1                   mov rax, r9
0000e654  492bc2                   sub rax, r10
0000e657  4c0f49e0                 cmovns r12, rax
0000e65b  4885d2                   test rdx, rdx
0000e65e  0f8e81020000             jle 0xe8e5
0000e664  85ff                     test edi, edi
0000e666  0f8479020000             je 0xe8e5
0000e66c  48894c2468               mov qword ptr [rsp + 0x68], rcx
0000e671  498bcd                   mov rcx, r13
0000e674  493bd5                   cmp rdx, r13
0000e677  480f4cca                 cmovl rcx, rdx
0000e67b  482b8c2498000000         sub rcx, qword ptr [rsp + 0x98]
0000e683  b800000000               mov eax, 0
0000e688  480f49c1                 cmovns rax, rcx
0000e68c  4c2be8                   sub r13, rax
0000e68f  498bcc                   mov rcx, r12
0000e692  493bd4                   cmp rdx, r12
0000e695  480f4cca                 cmovl rcx, rdx
0000e699  482b4c2478               sub rcx, qword ptr [rsp + 0x78]
0000e69e  b800000000               mov eax, 0
0000e6a3  480f49c1                 cmovns rax, rcx
0000e6a7  4c2be0                   sub r12, rax
0000e6aa  488b942490000000         mov rdx, qword ptr [rsp + 0x90]
0000e6b2  4839542458               cmp qword ptr [rsp + 0x58], rdx
0000e6b7  0f8fdb6c0900             jg 0xa5398
0000e6bd  488bc3                   mov rax, rbx
0000e6c0  4c3bc3                   cmp r8, rbx
0000e6c3  490f4fc0                 cmovg rax, r8
0000e6c7  4889442450               mov qword ptr [rsp + 0x50], rax
0000e6cc  4c39ac24c8000000         cmp qword ptr [rsp + 0xc8], r13
0000e6d4  4c0f4cac24c8000000       cmovl r13, qword ptr [rsp + 0xc8]
0000e6dd  4c39a424d0000000         cmp qword ptr [rsp + 0xd0], r12
0000e6e5  4c0f4ca424d0000000       cmovl r12, qword ptr [rsp + 0xd0]
0000e6ee  4c89a424e8000000         mov qword ptr [rsp + 0xe8], r12
0000e6f6  483bf0                   cmp rsi, rax
0000e6f9  488bf0                   mov rsi, rax
0000e6fc  0f8dc66c0900             jge 0xa53c8
0000e702  4c3bd0                   cmp r10, rax
0000e705  0f8fbd6c0900             jg 0xa53c8
0000e70b  b901000000               mov ecx, 1
0000e710  8bc1                     mov eax, ecx
0000e712  4533c0                   xor r8d, r8d
0000e715  eb01                     jmp 0xe718
0000e717  cc                       int3
0000e718  488b9424a0000000         mov rdx, qword ptr [rsp + 0xa0]
0000e720  4839542470               cmp qword ptr [rsp + 0x70], rdx
0000e725  0f8fad6c0900             jg 0xa53d8
0000e72b  85c0                     test eax, eax
0000e72d  0f84a56c0900             je 0xa53d8
0000e733  418bc0                   mov eax, r8d
0000e736  4d8bd0                   mov r10, r8
0000e739  eb01                     jmp 0xe73c
0000e73b  cc                       int3
0000e73c  4c89542460               mov qword ptr [rsp + 0x60], r10
0000e741  4c8d0578293100           lea r8, [rip + 0x312978]
0000e748  4b8b4c0750               mov rcx, qword ptr [r15 + r8 + 0x50]
0000e74d  8b942400030000           mov edx, dword ptr [rsp + 0x300]
0000e754  493bc9                   cmp rcx, r9
0000e757  7c08                     jl 0xe761
0000e759  85c0                     test eax, eax
0000e75b  0f85826c0900             jne 0xa53e3
0000e761  4f894c0750               mov qword ptr [r15 + r8 + 0x50], r9
0000e766  498bc9                   mov rcx, r9
0000e769  4c8d0d50293100           lea r9, [rip + 0x312950]
0000e770  4f395c0f48               cmp qword ptr [r15 + r9 + 0x48], r11
0000e775  7f13                     jg 0xe78a
0000e777  488b442458               mov rax, qword ptr [rsp + 0x58]
0000e77c  483b842490000000         cmp rax, qword ptr [rsp + 0x90]
0000e784  0f8f676c0900             jg 0xa53f1
0000e78a  4f895c0f48               mov qword ptr [r15 + r9 + 0x48], r11
0000e78f  85ff                     test edi, edi
0000e791  751c                     jne 0xe7af
0000e793  482b4c2428               sub rcx, qword ptr [rsp + 0x28]
0000e798  b800000000               mov eax, 0
0000e79d  480f49c1                 cmovns rax, rcx
0000e7a1  480305300a3200           add rax, qword ptr [rip + 0x320a30]
0000e7a8  48890519293100           mov qword ptr [rip + 0x312919], rax
0000e7af  c744243800000000         mov dword ptr [rsp + 0x38], 0
0000e7b7  498db900010000           lea rdi, [r9 + 0x100]
0000e7be  4903ff                   add rdi, r15
0000e7c1  eb01                     jmp 0xe7c4
0000e7c3  cc                       int3
0000e7c4  4c8b5fd0                 mov r11, qword ptr [rdi - 0x30]
0000e7c8  8b5710                   mov edx, dword ptr [rdi + 0x10]
0000e7cb  83fa01                   cmp edx, 1
0000e7ce  0f8420010000             je 0xe8f4
0000e7d4  4f8d042b                 lea r8, [r11 + r13]
0000e7d8  493bf0                   cmp rsi, r8
0000e7db  4c0f4cc6                 cmovl r8, rsi
0000e7df  4d85d2                   test r10, r10
0000e7e2  0f85176c0900             jne 0xa53ff
0000e7e8  488b4fd8                 mov rcx, qword ptr [rdi - 0x28]
0000e7ec  4903cc                   add rcx, r12
0000e7ef  493bc8                   cmp rcx, r8
0000e7f2  4c0f4cc1                 cmovl r8, rcx
0000e7f6  4c8bcb                   mov r9, rbx
0000e7f9  4c3bc3                   cmp r8, rbx
0000e7fc  4d0f4fc8                 cmovg r9, r8
0000e800  83fa01                   cmp edx, 1
0000e803  0f843d010000             je 0xe946
0000e809  48837c246800             cmp qword ptr [rsp + 0x68], 0
0000e80f  7413                     je 0xe824
0000e811  488b442458               mov rax, qword ptr [rsp + 0x58]
0000e816  483b842490000000         cmp rax, qword ptr [rsp + 0x90]
0000e81e  0f8f4e6c0900             jg 0xa5472
0000e824  be01000000               mov esi, 1
0000e829  89742420                 mov dword ptr [rsp + 0x20], esi
0000e82d  41bc64000000             mov r12d, 0x64
0000e833  4c894fc0                 mov qword ptr [rdi - 0x40], r9
0000e837  488b8424d8000000         mov rax, qword ptr [rsp + 0xd8]
0000e83f  488947e0                 mov qword ptr [rdi - 0x20], rax
0000e843  448b3f                   mov r15d, dword ptr [rdi]
0000e846  488b47f0                 mov rax, qword ptr [rdi - 0x10]
0000e84a  4885c0                   test rax, rax
0000e84d  741e                     je 0xe86d
0000e84f  488d4fb8                 lea rcx, [rdi - 0x48]
0000e853  4c8d442420               lea r8, [rsp + 0x20]
0000e858  488b9424e0000000         mov rdx, qword ptr [rsp + 0xe0]
0000e860  ffd0                     call rax
0000e862  4c8b356c623000           mov r14, qword ptr [rip + 0x30626c]
0000e869  8b742420                 mov esi, dword ptr [rsp + 0x20]
0000e86d  8937                     mov dword ptr [rdi], esi
0000e86f  48833d0135320000         cmp qword ptr [rip + 0x323501], 0
0000e877  7413                     je 0xe88c
0000e879  413bf7                   cmp esi, r15d
0000e87c  0f85fe6b0900             jne 0xa5480
0000e882  41f6c640                 test r14b, 0x40
0000e886  0f85f46b0900             jne 0xa5480
0000e88c  4c8b7c2430               mov r15, qword ptr [rsp + 0x30]
0000e891  488b47d0                 mov rax, qword ptr [rdi - 0x30]
0000e895  488947b8                 mov qword ptr [rdi - 0x48], rax
0000e899  8b442438                 mov eax, dword ptr [rsp + 0x38]
0000e89d  ffc0                     inc eax
0000e89f  89442438                 mov dword ptr [rsp + 0x38], eax
0000e8a3  4883c760                 add rdi, 0x60
0000e8a7  83f806                   cmp eax, 6
0000e8aa  4c8ba424e8000000         mov r12, qword ptr [rsp + 0xe8]
0000e8b2  488b742450               mov rsi, qword ptr [rsp + 0x50]
0000e8b7  4c8b542460               mov r10, qword ptr [rsp + 0x60]
0000e8bc  0f8da0000000             jge 0xe962
0000e8c2  4c8d0df7273100           lea r9, [rip + 0x3127f7]
0000e8c9  e9f6feffff               jmp 0xe7c4
0000e8ce  cc                       int3
