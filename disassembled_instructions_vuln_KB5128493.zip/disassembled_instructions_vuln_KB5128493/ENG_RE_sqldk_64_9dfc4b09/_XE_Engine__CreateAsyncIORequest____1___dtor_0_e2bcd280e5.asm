; `XE_Engine::CreateAsyncIORequest'::`1'::dtor$0
; sqldk.dll, primary RVA 0x235600, 56 bytes in 1 chunk(s)

; chunk at RVA 0x235600 (56 bytes)
00235600  4055                     push rbp
00235602  4883ec30                 sub rsp, 0x30
00235606  488bea                   mov rbp, rdx
00235609  c644242806               mov byte ptr [rsp + 0x28], 6
0023560e  8b4558                   mov eax, dword ptr [rbp + 0x58]
00235611  89442420                 mov dword ptr [rsp + 0x20], eax
00235615  4c8d0dc45b0400           lea r9, [rip + 0x45bc4]
0023561c  41b801000000             mov r8d, 1
00235622  488b1557d01700           mov rdx, qword ptr [rip + 0x17d057]
00235629  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0023562d  e88e48faff               call 0x1d9ec0
00235632  4883c430                 add rsp, 0x30
00235636  5d                       pop rbp
00235637  c3                       ret
