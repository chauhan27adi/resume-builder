; XE_AutoP<ColumnDescriptor>::~XE_AutoP<ColumnDescriptor>
; sqldk.dll, primary RVA 0x41b50, 61 bytes in 1 chunk(s)

; chunk at RVA 0x41b50 (61 bytes)
00041b50  48894c2408               mov qword ptr [rsp + 8], rcx
00041b55  53                       push rbx
00041b56  4883ec30                 sub rsp, 0x30
00041b5a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00041b63  488bd9                   mov rbx, rcx
00041b66  488b09                   mov rcx, qword ptr [rcx]
00041b69  4885c9                   test rcx, rcx
00041b6c  7406                     je 0x41b74
00041b6e  ff15dc342d00             call qword ptr [rip + 0x2d34dc]
00041b74  48c70300000000           mov qword ptr [rbx], 0
00041b7b  ba10000000               mov edx, 0x10
00041b80  488b0b                   mov rcx, qword ptr [rbx]
00041b83  4883c430                 add rsp, 0x30
00041b87  5b                       pop rbx
00041b88  e96362fcff               jmp 0x7df0
