; CMemPartitioned<CMemThread<CMemAligned<CMemFixed> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce6a0, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce6a0 (104 bytes)
000ce6a0  48894c2408               mov qword ptr [rsp + 8], rcx
000ce6a5  57                       push rdi
000ce6a6  4883ec30                 sub rsp, 0x30
000ce6aa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce6b3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce6b8  8bda                     mov ebx, edx
000ce6ba  488bf9                   mov rdi, rcx
000ce6bd  488d05eced1700           lea rax, [rip + 0x17edec]
000ce6c4  488901                   mov qword ptr [rcx], rax
000ce6c7  488d8178020000           lea rax, [rcx + 0x278]
000ce6ce  4889442450               mov qword ptr [rsp + 0x50], rax
000ce6d3  488d0d66b41600           lea rcx, [rip + 0x16b466]
000ce6da  488908                   mov qword ptr [rax], rcx
000ce6dd  488bcf                   mov rcx, rdi
000ce6e0  e88b210300               call 0x100870
000ce6e5  83e305                   and ebx, 5
000ce6e8  80fb05                   cmp bl, 5
000ce6eb  750d                     jne 0xce6fa
000ce6ed  bab0020000               mov edx, 0x2b0
000ce6f2  488bcf                   mov rcx, rdi
000ce6f5  e81629f3ff               call 0x1010
000ce6fa  488bc7                   mov rax, rdi
000ce6fd  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce702  4883c430                 add rsp, 0x30
000ce706  5f                       pop rdi
000ce707  c3                       ret
