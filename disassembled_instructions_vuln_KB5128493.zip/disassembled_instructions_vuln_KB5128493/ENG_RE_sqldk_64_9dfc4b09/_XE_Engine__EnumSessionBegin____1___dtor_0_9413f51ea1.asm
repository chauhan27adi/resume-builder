; `XE_Engine::EnumSessionBegin'::`1'::dtor$0
; sqldk.dll, primary RVA 0x233850, 56 bytes in 1 chunk(s)

; chunk at RVA 0x233850 (56 bytes)
00233850  4055                     push rbp
00233852  4883ec30                 sub rsp, 0x30
00233856  488bea                   mov rbp, rdx
00233859  c644242806               mov byte ptr [rsp + 0x28], 6
0023385e  8b4560                   mov eax, dword ptr [rbp + 0x60]
00233861  89442420                 mov dword ptr [rsp + 0x20], eax
00233865  4c8d0d346f0700           lea r9, [rip + 0x76f34]
0023386c  41b801000000             mov r8d, 1
00233872  488b1507ee1700           mov rdx, qword ptr [rip + 0x17ee07]
00233879  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
0023387d  e83e66faff               call 0x1d9ec0
00233882  4883c430                 add rsp, 0x30
00233886  5d                       pop rbp
00233887  c3                       ret
