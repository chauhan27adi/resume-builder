; `XEPackage0::HistoryTarget::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2326a0, 32 bytes in 1 chunk(s)

; chunk at RVA 0x2326a0 (32 bytes)
002326a0  4055                     push rbp
002326a2  4883ec20                 sub rsp, 0x20
002326a6  488bea                   mov rbp, rdx
002326a9  4c8b4528                 mov r8, qword ptr [rbp + 0x28]
002326ad  488b5520                 mov rdx, qword ptr [rbp + 0x20]
002326b1  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
002326b5  e856e9dcff               call 0x1010
002326ba  4883c420                 add rsp, 0x20
002326be  5d                       pop rbp
002326bf  c3                       ret
