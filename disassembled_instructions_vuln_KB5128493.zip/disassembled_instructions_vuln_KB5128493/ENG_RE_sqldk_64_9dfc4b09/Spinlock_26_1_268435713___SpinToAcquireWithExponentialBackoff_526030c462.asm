; Spinlock<26,1,268435713>::SpinToAcquireWithExponentialBackoff
; sqldk.dll, primary RVA 0x3c370, 426 bytes in 1 chunk(s)

; chunk at RVA 0x3c370 (426 bytes)
0003c370  48895c2408               mov qword ptr [rsp + 8], rbx
0003c375  48896c2410               mov qword ptr [rsp + 0x10], rbp
0003c37a  56                       push rsi
0003c37b  57                       push rdi
0003c37c  4154                     push r12
0003c37e  4156                     push r14
0003c380  4157                     push r15
0003c382  4883ec50                 sub rsp, 0x50
0003c386  654c8b042558000000       mov r8, qword ptr gs:[0x58]
0003c38f  b81a000000               mov eax, 0x1a
0003c394  448b0d1d55fcff           mov r9d, dword ptr [rip - 0x3aae3]
0003c39b  4c8be2                   mov r12, rdx
0003c39e  6689442420               mov word ptr [rsp + 0x20], ax
0003c3a3  4c8bf1                   mov r14, rcx
0003c3a6  8b05248c2d00             mov eax, dword ptr [rip + 0x2d8c24]
0003c3ac  c744242401000000         mov dword ptr [rsp + 0x24], 1
0003c3b4  4d030cc0                 add r9, qword ptr [r8 + rax*8]
0003c3b8  0f843c940500             je 0x957fa
0003c3be  4d398910010000           cmp qword ptr [r9 + 0x110], r9
0003c3c5  0f852f940500             jne 0x957fa
0003c3cb  498b8100010000           mov rax, qword ptr [r9 + 0x100]
0003c3d2  4889442428               mov qword ptr [rsp + 0x28], rax
0003c3d7  4885c0                   test rax, rax
0003c3da  0f8423940500             je 0x95803
0003c3e0  488b80e0030000           mov rax, qword ptr [rax + 0x3e0]
0003c3e7  eb01                     jmp 0x3c3ea
0003c3e9  cc                       int3
0003c3ea  f60507872d0001           test byte ptr [rip + 0x2d8707], 1
0003c3f1  4889442430               mov qword ptr [rsp + 0x30], rax
0003c3f6  48c744243800000000       mov qword ptr [rsp + 0x38], 0
0003c3ff  c744244000000000         mov dword ptr [rsp + 0x40], 0
0003c407  741f                     je 0x3c428
0003c409  4885c0                   test rax, rax
0003c40c  741a                     je 0x3c428
0003c40e  0fb780a0000000           movzx eax, word ptr [rax + 0xa0]
0003c415  486bc858                 imul rcx, rax, 0x58
0003c419  488d0558602f00           lea rax, [rip + 0x2f6058]
0003c420  4803c8                   add rcx, rax
0003c423  48894c2438               mov qword ptr [rsp + 0x38], rcx
0003c428  8b05be862d00             mov eax, dword ptr [rip + 0x2d86be]
0003c42e  41b83c000000             mov r8d, 0x3c
0003c434  488b4c2438               mov rcx, qword ptr [rsp + 0x38]
0003c439  493bc0                   cmp rax, r8
0003c43c  8bf8                     mov edi, eax
0003c43e  410f47f8                 cmova edi, r8d
0003c442  4885c9                   test rcx, rcx
0003c445  7443                     je 0x3c48a
0003c447  488b4108                 mov rax, qword ptr [rcx + 8]
0003c44b  48ff80b8050000           inc qword ptr [rax + 0x5b8]
0003c452  488b5108                 mov rdx, qword ptr [rcx + 8]
0003c456  488b82b0050000           mov rax, qword ptr [rdx + 0x5b0]
0003c45d  4885c0                   test rax, rax
0003c460  7428                     je 0x3c48a
0003c462  488b8ab8050000           mov rcx, qword ptr [rdx + 0x5b8]
0003c469  4885c9                   test rcx, rcx
0003c46c  741c                     je 0x3c48a
0003c46e  33d2                     xor edx, edx
0003c470  48f7f1                   div rcx
0003c473  8bcf                     mov ecx, edi
0003c475  48d1e8                   shr rax, 1
0003c478  483bc7                   cmp rax, rdi
0003c47b  480f47c8                 cmova rcx, rax
0003c47f  486bff64                 imul rdi, rdi, 0x64
0003c483  483bcf                   cmp rcx, rdi
0003c486  480f42f9                 cmovb rdi, rcx
0003c48a  8b055c862d00             mov eax, dword ptr [rip + 0x2d865c]
0003c490  440fb63d28902d00         movzx r15d, byte ptr [rip + 0x2d9028]
0003c498  493bc0                   cmp rax, r8
0003c49b  488b35b6732d00           mov rsi, qword ptr [rip + 0x2d73b6]
0003c4a2  8be8                     mov ebp, eax
0003c4a4  490f47e8                 cmova rbp, r8
0003c4a8  33db                     xor ebx, ebx
0003c4aa  4584ff                   test r15b, r15b
0003c4ad  0f8558930500             jne 0x9580b
0003c4b3  488bd7                   mov rdx, rdi
0003c4b6  4885d2                   test rdx, rdx
0003c4b9  740f                     je 0x3c4ca
0003c4bb  660f1f0400               nop word ptr [rax + rax]
0003c4c0  f390                     pause
0003c4c2  4803de                   add rbx, rsi
0003c4c5  483bda                   cmp rbx, rdx
0003c4c8  72f6                     jb 0x3c4c0
0003c4ca  488b442438               mov rax, qword ptr [rsp + 0x38]
0003c4cf  4885c0                   test rax, rax
0003c4d2  740b                     je 0x3c4df
0003c4d4  488b4008                 mov rax, qword ptr [rax + 8]
0003c4d8  480198b0050000           add qword ptr [rax + 0x5b0], rbx
0003c4df  418b06                   mov eax, dword ptr [r14]
0003c4e2  85c0                     test eax, eax
0003c4e4  0f8537930500             jne 0x95821
0003c4ea  33c0                     xor eax, eax
0003c4ec  f04d0fb126               lock cmpxchg qword ptr [r14], r12
0003c4f1  b800000000               mov eax, 0
0003c4f6  0f94c0                   sete al
0003c4f9  85c0                     test eax, eax
0003c4fb  0f8420930500             je 0x95821
0003c501  4c8d5c2450               lea r11, [rsp + 0x50]
0003c506  498b5b30                 mov rbx, qword ptr [r11 + 0x30]
0003c50a  498b6b38                 mov rbp, qword ptr [r11 + 0x38]
0003c50e  498be3                   mov rsp, r11
0003c511  415f                     pop r15
0003c513  415e                     pop r14
0003c515  415c                     pop r12
0003c517  5f                       pop rdi
0003c518  5e                       pop rsi
0003c519  c3                       ret
