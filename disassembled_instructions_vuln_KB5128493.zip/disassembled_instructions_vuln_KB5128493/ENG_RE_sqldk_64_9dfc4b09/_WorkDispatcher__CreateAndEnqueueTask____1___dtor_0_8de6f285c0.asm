; `WorkDispatcher::CreateAndEnqueueTask'::`1'::dtor$0
; sqldk.dll, primary RVA 0x219660, 69 bytes in 1 chunk(s)

; chunk at RVA 0x219660 (69 bytes)
00219660  4055                     push rbp
00219662  4883ec30                 sub rsp, 0x30
00219666  488bea                   mov rbp, rdx
00219669  488b95b8000000           mov rdx, qword ptr [rbp + 0xb8]
00219670  4881c2780e0000           add rdx, 0xe78
00219677  c644242806               mov byte ptr [rsp + 0x28], 6
0021967c  8b85c0000000             mov eax, dword ptr [rbp + 0xc0]
00219682  89442420                 mov dword ptr [rsp + 0x20], eax
00219686  4c8d0dc3c40400           lea r9, [rip + 0x4c4c3]
0021968d  41b801000000             mov r8d, 1
00219693  488b12                   mov rdx, qword ptr [rdx]
00219696  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
0021969a  e801e7deff               call 0x7da0
0021969f  4883c430                 add rsp, 0x30
002196a3  5d                       pop rbp
002196a4  c3                       ret
