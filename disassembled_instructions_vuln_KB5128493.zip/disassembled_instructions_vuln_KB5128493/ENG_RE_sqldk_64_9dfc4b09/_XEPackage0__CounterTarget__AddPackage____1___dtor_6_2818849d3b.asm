; `XEPackage0::CounterTarget::AddPackage'::`1'::dtor$6
; sqldk.dll, primary RVA 0x23193f, 45 bytes in 1 chunk(s)

; chunk at RVA 0x23193f (45 bytes)
0023193f  4055                     push rbp
00231941  4883ec20                 sub rsp, 0x20
00231945  488bea                   mov rbp, rdx
00231948  488b8db0000000           mov rcx, qword ptr [rbp + 0xb0]
0023194f  4c8d0d3a58e1ff           lea r9, [rip - 0x1ea7c6]
00231956  41b880000000             mov r8d, 0x80
0023195c  ba18000000               mov edx, 0x18
00231961  e8fad2dfff               call 0x2ec60
00231966  4883c420                 add rsp, 0x20
0023196a  5d                       pop rbp
0023196b  c3                       ret
