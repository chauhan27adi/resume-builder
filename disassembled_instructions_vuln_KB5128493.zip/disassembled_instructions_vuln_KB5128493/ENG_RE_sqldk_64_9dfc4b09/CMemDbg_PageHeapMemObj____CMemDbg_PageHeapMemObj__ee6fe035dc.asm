; CMemDbg<PageHeapMemObj>::~CMemDbg<PageHeapMemObj>
; sqldk.dll, primary RVA 0x172410, 99 bytes in 1 chunk(s)

; chunk at RVA 0x172410 (99 bytes)
00172410  48894c2408               mov qword ptr [rsp + 8], rcx
00172415  53                       push rbx
00172416  4883ec30                 sub rsp, 0x30
0017241a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00172423  488bd9                   mov rbx, rcx
00172426  488d0543bf0d00           lea rax, [rip + 0xdbf43]
0017242d  488901                   mov qword ptr [rcx], rax
00172430  488d05a1390f00           lea rax, [rip + 0xf39a1]
00172437  48898190000000           mov qword ptr [rcx + 0x90], rax
0017243e  488d05dbc10d00           lea rax, [rip + 0xdc1db]
00172445  488901                   mov qword ptr [rcx], rax
00172448  488d05b94d0d00           lea rax, [rip + 0xd4db9]
0017244f  488901                   mov qword ptr [rcx], rax
00172452  4883c138                 add rcx, 0x38
00172456  e895fde9ff               call 0x121f0
0017245b  90                       nop
0017245c  488d4b30                 lea rcx, [rbx + 0x30]
00172460  e88bfde9ff               call 0x121f0
00172465  90                       nop
00172466  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0017246d  4883c430                 add rsp, 0x30
00172471  5b                       pop rbx
00172472  c3                       ret
