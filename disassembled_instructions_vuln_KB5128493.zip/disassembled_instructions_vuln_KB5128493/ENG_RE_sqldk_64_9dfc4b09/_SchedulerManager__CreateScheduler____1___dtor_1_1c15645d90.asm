; `SchedulerManager::CreateScheduler'::`1'::dtor$1
; sqldk.dll, primary RVA 0x218763, 59 bytes in 1 chunk(s)

; chunk at RVA 0x218763 (59 bytes)
00218763  4055                     push rbp
00218765  4883ec30                 sub rsp, 0x30
00218769  488bea                   mov rbp, rdx
0021876c  c644242806               mov byte ptr [rsp + 0x28], 6
00218771  8b85c8000000             mov eax, dword ptr [rbp + 0xc8]
00218777  89442420                 mov dword ptr [rsp + 0x20], eax
0021877b  4c8d0d761d0600           lea r9, [rip + 0x61d76]
00218782  41b801000000             mov r8d, 1
00218788  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0021878c  488b8dc0000000           mov rcx, qword ptr [rbp + 0xc0]
00218793  e808f6deff               call 0x7da0
00218798  4883c430                 add rsp, 0x30
0021879c  5d                       pop rbp
0021879d  c3                       ret
