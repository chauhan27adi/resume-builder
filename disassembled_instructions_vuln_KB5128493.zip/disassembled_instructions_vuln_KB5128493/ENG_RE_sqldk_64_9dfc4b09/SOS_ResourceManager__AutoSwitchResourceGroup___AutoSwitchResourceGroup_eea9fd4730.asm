; SOS_ResourceManager::AutoSwitchResourceGroup::~AutoSwitchResourceGroup
; sqldk.dll, primary RVA 0x361a0, 61 bytes in 1 chunk(s)

; chunk at RVA 0x361a0 (61 bytes)
000361a0  4053                     push rbx
000361a2  4883ec20                 sub rsp, 0x20
000361a6  488b01                   mov rax, qword ptr [rcx]
000361a9  488bd9                   mov rbx, rcx
000361ac  4885c0                   test rax, rax
000361af  7426                     je 0x361d7
000361b1  488b5108                 mov rdx, qword ptr [rcx + 8]
000361b5  483bd0                   cmp rdx, rax
000361b8  741d                     je 0x361d7
000361ba  488d0ddff62d00           lea rcx, [rip + 0x2df6df]
000361c1  e82a9fffff               call 0x300f0
000361c6  488b5b08                 mov rbx, qword ptr [rbx + 8]
000361ca  83bba400000003           cmp dword ptr [rbx + 0xa4], 3
000361d1  0f83091f0500             jae 0x880e0
000361d7  4883c420                 add rsp, 0x20
000361db  5b                       pop rbx
000361dc  c3                       ret
