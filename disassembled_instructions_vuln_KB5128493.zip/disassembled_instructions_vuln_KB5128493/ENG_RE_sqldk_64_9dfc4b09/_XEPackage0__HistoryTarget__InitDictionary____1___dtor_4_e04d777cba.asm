; `XEPackage0::HistoryTarget::InitDictionary'::`1'::dtor$4
; sqldk.dll, primary RVA 0x2329d4, 51 bytes in 1 chunk(s)

; chunk at RVA 0x2329d4 (51 bytes)
002329d4  4055                     push rbp
002329d6  4883ec20                 sub rsp, 0x20
002329da  488bea                   mov rbp, rdx
002329dd  4c8b85f0000000           mov r8, qword ptr [rbp + 0xf0]
002329e4  4981c030200000           add r8, 0x2030
002329eb  4d8b00                   mov r8, qword ptr [r8]
002329ee  488b9500010000           mov rdx, qword ptr [rbp + 0x100]
002329f5  488b8d08010000           mov rcx, qword ptr [rbp + 0x108]
002329fc  e80fe6dcff               call 0x1010
00232a01  4883c420                 add rsp, 0x20
00232a05  5d                       pop rbp
00232a06  c3                       ret
