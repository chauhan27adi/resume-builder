; TEnumerator<TList<ExternalPoolList,SOS_ExternalResourcePool,0,TListSLock> >::~TEnumerator<TList<ExternalPoolList,SOS_ExternalResourcePool,0,TListSLock> >
; sqldk.dll, primary RVA 0x1a5490, 187 bytes in 1 chunk(s)

; chunk at RVA 0x1a5490 (187 bytes)
001a5490  48895c2410               mov qword ptr [rsp + 0x10], rbx
001a5495  48896c2418               mov qword ptr [rsp + 0x18], rbp
001a549a  4889742420               mov qword ptr [rsp + 0x20], rsi
001a549f  57                       push rdi
001a54a0  4883ec20                 sub rsp, 0x20
001a54a4  488b39                   mov rdi, qword ptr [rcx]
001a54a7  33ed                     xor ebp, ebp
001a54a9  488bd9                   mov rbx, rcx
001a54ac  beffffffff               mov esi, 0xffffffff
001a54b1  4885ff                   test rdi, rdi
001a54b4  742e                     je 0x1a54e4
001a54b6  8bc6                     mov eax, esi
001a54b8  f00fc14718               lock xadd dword ptr [rdi + 0x18], eax
001a54bd  83f801                   cmp eax, 1
001a54c0  751f                     jne 0x1a54e1
001a54c2  48396f08                 cmp qword ptr [rdi + 8], rbp
001a54c6  740c                     je 0x1a54d4
001a54c8  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
001a54cc  488bd7                   mov rdx, rdi
001a54cf  e86ccbe6ff               call 0x12040
001a54d4  baf8010000               mov edx, 0x1f8
001a54d9  488bcf                   mov rcx, rdi
001a54dc  e80f29e6ff               call 0x7df0
001a54e1  48892b                   mov qword ptr [rbx], rbp
001a54e4  488b7b08                 mov rdi, qword ptr [rbx + 8]
001a54e8  4885ff                   test rdi, rdi
001a54eb  742d                     je 0x1a551a
001a54ed  f00fc17718               lock xadd dword ptr [rdi + 0x18], esi
001a54f2  83fe01                   cmp esi, 1
001a54f5  751f                     jne 0x1a5516
001a54f7  48396f08                 cmp qword ptr [rdi + 8], rbp
001a54fb  740c                     je 0x1a5509
001a54fd  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
001a5501  488bd7                   mov rdx, rdi
001a5504  e837cbe6ff               call 0x12040
001a5509  baf8010000               mov edx, 0x1f8
001a550e  488bcf                   mov rcx, rdi
001a5511  e8da28e6ff               call 0x7df0
001a5516  48896b08                 mov qword ptr [rbx + 8], rbp
001a551a  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001a551e  4885c9                   test rcx, rcx
001a5521  740f                     je 0x1a5532
001a5523  8b5320                   mov edx, dword ptr [rbx + 0x20]
001a5526  e82507e6ff               call 0x5c50
001a552b  48896b18                 mov qword ptr [rbx + 0x18], rbp
001a552f  896b20                   mov dword ptr [rbx + 0x20], ebp
001a5532  488b742448               mov rsi, qword ptr [rsp + 0x48]
001a5537  48896b10                 mov qword ptr [rbx + 0x10], rbp
001a553b  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
001a5540  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
001a5545  4883c420                 add rsp, 0x20
001a5549  5f                       pop rdi
001a554a  c3                       ret
