; `CXFixedTable::InitFixedTable'::`1'::dtor$0
; sqldk.dll, primary RVA 0x216c60, 37 bytes in 1 chunk(s)

; chunk at RVA 0x216c60 (37 bytes)
00216c60  4055                     push rbp
00216c62  4883ec20                 sub rsp, 0x20
00216c66  488bea                   mov rbp, rdx
00216c69  4533c0                   xor r8d, r8d
00216c6c  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
00216c73  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
00216c7a  e891a3deff               call 0x1010
00216c7f  4883c420                 add rsp, 0x20
00216c83  5d                       pop rbp
00216c84  c3                       ret
