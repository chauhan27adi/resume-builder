; XE_ResolvedObject<XEType>::~XE_ResolvedObject<XEType>
; sqldk.dll, primary RVA 0x40f60, 43 bytes in 1 chunk(s)

; chunk at RVA 0x40f60 (43 bytes)
00040f60  48894c2408               mov qword ptr [rsp + 8], rcx
00040f65  4883ec38                 sub rsp, 0x38
00040f69  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00040f72  488b4910                 mov rcx, qword ptr [rcx + 0x10]
00040f76  4885c9                   test rcx, rcx
00040f79  740b                     je 0x40f86
00040f7b  4883c438                 add rsp, 0x38
00040f7f  48ff252a442d00           jmp qword ptr [rip + 0x2d442a]
00040f86  4883c438                 add rsp, 0x38
00040f8a  c3                       ret
