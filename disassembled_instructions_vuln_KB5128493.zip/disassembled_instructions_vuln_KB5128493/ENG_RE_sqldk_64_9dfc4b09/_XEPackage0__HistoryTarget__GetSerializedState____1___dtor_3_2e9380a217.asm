; `XEPackage0::HistoryTarget::GetSerializedState'::`1'::dtor$3
; sqldk.dll, primary RVA 0x232761, 31 bytes in 1 chunk(s)

; chunk at RVA 0x232761 (31 bytes)
00232761  4055                     push rbp
00232763  4883ec20                 sub rsp, 0x20
00232767  488bea                   mov rbp, rdx
0023276a  4533c0                   xor r8d, r8d
0023276d  488b5568                 mov rdx, qword ptr [rbp + 0x68]
00232771  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00232775  e896e8dcff               call 0x1010
0023277a  4883c420                 add rsp, 0x20
0023277e  5d                       pop rbp
0023277f  c3                       ret
