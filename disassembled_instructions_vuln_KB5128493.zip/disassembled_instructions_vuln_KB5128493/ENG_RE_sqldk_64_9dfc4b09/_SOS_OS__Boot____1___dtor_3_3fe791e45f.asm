; `SOS_OS::Boot'::`1'::dtor$3
; sqldk.dll, primary RVA 0x21ce45, 59 bytes in 1 chunk(s)

; chunk at RVA 0x21ce45 (59 bytes)
0021ce45  4055                     push rbp
0021ce47  4883ec30                 sub rsp, 0x30
0021ce4b  488bea                   mov rbp, rdx
0021ce4e  c644242806               mov byte ptr [rsp + 0x28], 6
0021ce53  8b85f8000000             mov eax, dword ptr [rbp + 0xf8]
0021ce59  89442420                 mov dword ptr [rsp + 0x20], eax
0021ce5d  4c8d0d1cbf0700           lea r9, [rip + 0x7bf1c]
0021ce64  41b801000000             mov r8d, 1
0021ce6a  488b5538                 mov rdx, qword ptr [rbp + 0x38]
0021ce6e  488b8d08010000           mov rcx, qword ptr [rbp + 0x108]
0021ce75  e826afdeff               call 0x7da0
0021ce7a  4883c430                 add rsp, 0x30
0021ce7e  5d                       pop rbp
0021ce7f  c3                       ret
