; `ISOSHostImpl::CreateRecursiveMutex'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22a20c, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22a20c (59 bytes)
0022a20c  4055                     push rbp
0022a20e  4883ec30                 sub rsp, 0x30
0022a212  488bea                   mov rbp, rdx
0022a215  c644242806               mov byte ptr [rsp + 0x28], 6
0022a21a  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0022a220  89442420                 mov dword ptr [rsp + 0x20], eax
0022a224  4c8d0db5f90600           lea r9, [rip + 0x6f9b5]
0022a22b  41b801000000             mov r8d, 1
0022a231  488b5570                 mov rdx, qword ptr [rbp + 0x70]
0022a235  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
0022a23c  e85fdbddff               call 0x7da0
0022a241  4883c430                 add rsp, 0x30
0022a245  5d                       pop rbp
0022a246  c3                       ret
