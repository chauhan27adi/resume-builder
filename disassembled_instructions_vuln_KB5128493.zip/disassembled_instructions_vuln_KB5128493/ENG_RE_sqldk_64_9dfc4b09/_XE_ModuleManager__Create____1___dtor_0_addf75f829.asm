; `XE_ModuleManager::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2356b0, 62 bytes in 1 chunk(s)

; chunk at RVA 0x2356b0 (62 bytes)
002356b0  4055                     push rbp
002356b2  4883ec30                 sub rsp, 0x30
002356b6  488bea                   mov rbp, rdx
002356b9  c644242806               mov byte ptr [rsp + 0x28], 6
002356be  8b8588000000             mov eax, dword ptr [rbp + 0x88]
002356c4  89442420                 mov dword ptr [rsp + 0x20], eax
002356c8  4c8d0d71520700           lea r9, [rip + 0x75271]
002356cf  41b801000000             mov r8d, 1
002356d5  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
002356dc  488b8d90000000           mov rcx, qword ptr [rbp + 0x90]
002356e3  e8d847faff               call 0x1d9ec0
002356e8  4883c430                 add rsp, 0x30
002356ec  5d                       pop rbp
002356ed  c3                       ret
