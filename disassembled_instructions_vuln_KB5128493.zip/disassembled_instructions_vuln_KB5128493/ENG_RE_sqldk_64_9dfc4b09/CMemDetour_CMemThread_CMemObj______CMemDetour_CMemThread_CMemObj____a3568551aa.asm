; CMemDetour<CMemThread<CMemObj> >::~CMemDetour<CMemThread<CMemObj> >
; sqldk.dll, primary RVA 0x131920, 59 bytes in 1 chunk(s)

; chunk at RVA 0x131920 (59 bytes)
00131920  48894c2408               mov qword ptr [rsp + 8], rcx
00131925  4883ec38                 sub rsp, 0x38
00131929  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00131932  488d05b7a81100           lea rax, [rip + 0x11a8b7]
00131939  488901                   mov qword ptr [rcx], rax
0013193c  488d8140020000           lea rax, [rcx + 0x240]
00131943  4889442448               mov qword ptr [rsp + 0x48], rax
00131948  488d15f1811000           lea rdx, [rip + 0x1081f1]
0013194f  488910                   mov qword ptr [rax], rdx
00131952  4883c438                 add rsp, 0x38
00131956  e94588ffff               jmp 0x12a1a0
