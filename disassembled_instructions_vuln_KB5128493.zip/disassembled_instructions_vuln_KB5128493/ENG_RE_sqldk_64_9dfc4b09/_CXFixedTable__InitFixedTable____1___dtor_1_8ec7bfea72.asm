; `CXFixedTable::InitFixedTable'::`1'::dtor$1
; sqldk.dll, primary RVA 0x216c8b, 34 bytes in 1 chunk(s)

; chunk at RVA 0x216c8b (34 bytes)
00216c8b  4055                     push rbp
00216c8d  4883ec20                 sub rsp, 0x20
00216c91  488bea                   mov rbp, rdx
00216c94  4533c0                   xor r8d, r8d
00216c97  488b5578                 mov rdx, qword ptr [rbp + 0x78]
00216c9b  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
00216ca2  e869a3deff               call 0x1010
00216ca7  4883c420                 add rsp, 0x20
00216cab  5d                       pop rbp
00216cac  c3                       ret
