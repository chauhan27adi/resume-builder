; `XEPackage0::HistoryTarget::InitDictionary'::`1'::dtor$2
; sqldk.dll, primary RVA 0x23296b, 45 bytes in 1 chunk(s)

; chunk at RVA 0x23296b (45 bytes)
0023296b  4055                     push rbp
0023296d  4883ec20                 sub rsp, 0x20
00232971  488bea                   mov rbp, rdx
00232974  4c8b85f0000000           mov r8, qword ptr [rbp + 0xf0]
0023297b  4981c030200000           add r8, 0x2030
00232982  4d8b00                   mov r8, qword ptr [r8]
00232985  488b5568                 mov rdx, qword ptr [rbp + 0x68]
00232989  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
0023298d  e87ee6dcff               call 0x1010
00232992  4883c420                 add rsp, 0x20
00232996  5d                       pop rbp
00232997  c3                       ret
