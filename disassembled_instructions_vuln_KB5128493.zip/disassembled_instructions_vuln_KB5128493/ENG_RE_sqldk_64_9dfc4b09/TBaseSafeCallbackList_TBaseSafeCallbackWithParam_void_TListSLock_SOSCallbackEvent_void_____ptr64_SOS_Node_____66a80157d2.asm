; TBaseSafeCallbackList<TBaseSafeCallbackWithParam<void,TListSLock,SOSCallbackEvent,void * __ptr64,SOS_Node * __ptr64,unsigned __int64,unsigned __int64> >::~TBaseSafeCallbackList<TBaseSafeCallbackWithParam<void,TListSLock,SOSCallbackEvent,void * __ptr64,SOS_Node * __ptr64,unsigned __int64,unsigned __int64> >
; sqldk.dll, primary RVA 0x6ab30, 27 bytes in 1 chunk(s)

; chunk at RVA 0x6ab30 (27 bytes)
0006ab30  48894c2408               mov qword ptr [rsp + 8], rcx
0006ab35  4883ec38                 sub rsp, 0x38
0006ab39  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0006ab42  4883c438                 add rsp, 0x38
0006ab46  e915050000               jmp 0x6b060
