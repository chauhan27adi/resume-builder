; TEnumerator<TList<PoolList,SOS_ResourcePool,0,TListSLock> >::~TEnumerator<TList<PoolList,SOS_ResourcePool,0,TListSLock> >
; sqldk.dll, primary RVA 0x18e940, 203 bytes in 1 chunk(s)

; chunk at RVA 0x18e940 (203 bytes)
0018e940  48895c2410               mov qword ptr [rsp + 0x10], rbx
0018e945  48896c2418               mov qword ptr [rsp + 0x18], rbp
0018e94a  4889742420               mov qword ptr [rsp + 0x20], rsi
0018e94f  57                       push rdi
0018e950  4883ec20                 sub rsp, 0x20
0018e954  488b39                   mov rdi, qword ptr [rcx]
0018e957  33ed                     xor ebp, ebp
0018e959  488bd9                   mov rbx, rcx
0018e95c  beffffffff               mov esi, 0xffffffff
0018e961  4885ff                   test rdi, rdi
0018e964  7436                     je 0x18e99c
0018e966  8bc6                     mov eax, esi
0018e968  f00fc14718               lock xadd dword ptr [rdi + 0x18], eax
0018e96d  83f801                   cmp eax, 1
0018e970  7527                     jne 0x18e999
0018e972  48396f08                 cmp qword ptr [rdi + 8], rbp
0018e976  740c                     je 0x18e984
0018e978  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
0018e97c  488bd7                   mov rdx, rdi
0018e97f  e8bc36e8ff               call 0x12040
0018e984  488bcf                   mov rcx, rdi
0018e987  e864c0edff               call 0x6a9f0
0018e98c  bae80b0000               mov edx, 0xbe8
0018e991  488bcf                   mov rcx, rdi
0018e994  e85794e7ff               call 0x7df0
0018e999  48892b                   mov qword ptr [rbx], rbp
0018e99c  488b7b08                 mov rdi, qword ptr [rbx + 8]
0018e9a0  4885ff                   test rdi, rdi
0018e9a3  7435                     je 0x18e9da
0018e9a5  f00fc17718               lock xadd dword ptr [rdi + 0x18], esi
0018e9aa  83fe01                   cmp esi, 1
0018e9ad  7527                     jne 0x18e9d6
0018e9af  48396f08                 cmp qword ptr [rdi + 8], rbp
0018e9b3  740c                     je 0x18e9c1
0018e9b5  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
0018e9b9  488bd7                   mov rdx, rdi
0018e9bc  e87f36e8ff               call 0x12040
0018e9c1  488bcf                   mov rcx, rdi
0018e9c4  e827c0edff               call 0x6a9f0
0018e9c9  bae80b0000               mov edx, 0xbe8
0018e9ce  488bcf                   mov rcx, rdi
0018e9d1  e81a94e7ff               call 0x7df0
0018e9d6  48896b08                 mov qword ptr [rbx + 8], rbp
0018e9da  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0018e9de  4885c9                   test rcx, rcx
0018e9e1  740f                     je 0x18e9f2
0018e9e3  8b5320                   mov edx, dword ptr [rbx + 0x20]
0018e9e6  e86572e7ff               call 0x5c50
0018e9eb  48896b18                 mov qword ptr [rbx + 0x18], rbp
0018e9ef  896b20                   mov dword ptr [rbx + 0x20], ebp
0018e9f2  488b742448               mov rsi, qword ptr [rsp + 0x48]
0018e9f7  48896b10                 mov qword ptr [rbx + 0x10], rbp
0018e9fb  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
0018ea00  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
0018ea05  4883c420                 add rsp, 0x20
0018ea09  5f                       pop rdi
0018ea0a  c3                       ret
