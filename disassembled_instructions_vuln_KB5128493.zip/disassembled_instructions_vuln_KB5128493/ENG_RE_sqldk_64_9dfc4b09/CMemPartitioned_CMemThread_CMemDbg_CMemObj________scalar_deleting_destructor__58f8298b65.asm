; CMemPartitioned<CMemThread<CMemDbg<CMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcee90, 133 bytes in 1 chunk(s)

; chunk at RVA 0xcee90 (133 bytes)
000cee90  48894c2408               mov qword ptr [rsp + 8], rcx
000cee95  57                       push rdi
000cee96  4883ec30                 sub rsp, 0x30
000cee9a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ceea3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ceea8  8bda                     mov ebx, edx
000ceeaa  488bf9                   mov rdi, rcx
000ceead  488d0584cc1700           lea rax, [rip + 0x17cc84]
000ceeb4  488901                   mov qword ptr [rcx], rax
000ceeb7  488d8160060000           lea rax, [rcx + 0x660]
000ceebe  4889442450               mov qword ptr [rsp + 0x50], rax
000ceec3  488d0d76ac1600           lea rcx, [rip + 0x16ac76]
000ceeca  488908                   mov qword ptr [rax], rcx
000ceecd  488d05948e1700           lea rax, [rip + 0x178e94]
000ceed4  488907                   mov qword ptr [rdi], rax
000ceed7  488d87f8040000           lea rax, [rdi + 0x4f8]
000ceede  4889442458               mov qword ptr [rsp + 0x58], rax
000ceee3  48894830                 mov qword ptr [rax + 0x30], rcx
000ceee7  488908                   mov qword ptr [rax], rcx
000ceeea  488bcf                   mov rcx, rdi
000ceeed  e8eef60900               call 0x16e5e0
000ceef2  83e305                   and ebx, 5
000ceef5  80fb05                   cmp bl, 5
000ceef8  750d                     jne 0xcef07
000ceefa  ba98060000               mov edx, 0x698
000ceeff  488bcf                   mov rcx, rdi
000cef02  e80921f3ff               call 0x1010
000cef07  488bc7                   mov rax, rdi
000cef0a  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cef0f  4883c430                 add rsp, 0x30
000cef13  5f                       pop rdi
000cef14  c3                       ret
