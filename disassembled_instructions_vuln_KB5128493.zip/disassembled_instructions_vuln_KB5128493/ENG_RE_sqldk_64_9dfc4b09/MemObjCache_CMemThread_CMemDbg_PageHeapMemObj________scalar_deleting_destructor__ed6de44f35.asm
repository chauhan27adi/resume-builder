; MemObjCache<CMemThread<CMemDbg<PageHeapMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e260, 115 bytes in 1 chunk(s)

; chunk at RVA 0x13e260 (115 bytes)
0013e260  48894c2408               mov qword ptr [rsp + 8], rcx
0013e265  57                       push rdi
0013e266  4883ec30                 sub rsp, 0x30
0013e26a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e273  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e278  8bda                     mov ebx, edx
0013e27a  488bf9                   mov rdi, rcx
0013e27d  488d051c5f1200           lea rax, [rip + 0x125f1c]
0013e284  488901                   mov qword ptr [rcx], rax
0013e287  488d057ac01000           lea rax, [rip + 0x10c07a]
0013e28e  488901                   mov qword ptr [rcx], rax
0013e291  488d8150040000           lea rax, [rcx + 0x450]
0013e298  4889442450               mov qword ptr [rsp + 0x50], rax
0013e29d  488d0d9cb80f00           lea rcx, [rip + 0xfb89c]
0013e2a4  48894830                 mov qword ptr [rax + 0x30], rcx
0013e2a8  488908                   mov qword ptr [rax], rcx
0013e2ab  488bcf                   mov rcx, rdi
0013e2ae  e85d410300               call 0x172410
0013e2b3  f6c301                   test bl, 1
0013e2b6  740d                     je 0x13e2c5
0013e2b8  ba78050000               mov edx, 0x578
0013e2bd  488bcf                   mov rcx, rdi
0013e2c0  e82b9becff               call 0x7df0
0013e2c5  488bc7                   mov rax, rdi
0013e2c8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e2cd  4883c430                 add rsp, 0x30
0013e2d1  5f                       pop rdi
0013e2d2  c3                       ret
