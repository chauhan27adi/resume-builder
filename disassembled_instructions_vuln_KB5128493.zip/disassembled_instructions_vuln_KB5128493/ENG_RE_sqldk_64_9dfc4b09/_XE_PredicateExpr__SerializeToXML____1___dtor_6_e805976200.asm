; `XE_PredicateExpr::SerializeToXML'::`1'::dtor$6
; sqldk.dll, primary RVA 0x2361bb, 31 bytes in 1 chunk(s)

; chunk at RVA 0x2361bb (31 bytes)
002361bb  4055                     push rbp
002361bd  4883ec20                 sub rsp, 0x20
002361c1  488bea                   mov rbp, rdx
002361c4  4533c0                   xor r8d, r8d
002361c7  488b5540                 mov rdx, qword ptr [rbp + 0x40]
002361cb  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
002361cf  e83caedcff               call 0x1010
002361d4  4883c420                 add rsp, 0x20
002361d8  5d                       pop rbp
002361d9  c3                       ret
