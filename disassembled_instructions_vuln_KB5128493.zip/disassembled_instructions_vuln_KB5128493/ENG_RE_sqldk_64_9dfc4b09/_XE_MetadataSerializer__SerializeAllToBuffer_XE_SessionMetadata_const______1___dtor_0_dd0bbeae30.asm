; `XE_MetadataSerializer::SerializeAllToBuffer<XE_SessionMetadata const >'::`1'::dtor$0
; sqldk.dll, primary RVA 0x216a80, 45 bytes in 1 chunk(s)

; chunk at RVA 0x216a80 (45 bytes)
00216a80  4055                     push rbp
00216a82  4883ec20                 sub rsp, 0x20
00216a86  488bea                   mov rbp, rdx
00216a89  4c8d0d30b0e2ff           lea r9, [rip - 0x1d4fd0]
00216a90  41b800040000             mov r8d, 0x400
00216a96  ba08000000               mov edx, 8
00216a9b  488d8dc0000000           lea rcx, [rbp + 0xc0]
00216aa2  e8b981e1ff               call 0x2ec60
00216aa7  4883c420                 add rsp, 0x20
00216aab  5d                       pop rbp
00216aac  c3                       ret
