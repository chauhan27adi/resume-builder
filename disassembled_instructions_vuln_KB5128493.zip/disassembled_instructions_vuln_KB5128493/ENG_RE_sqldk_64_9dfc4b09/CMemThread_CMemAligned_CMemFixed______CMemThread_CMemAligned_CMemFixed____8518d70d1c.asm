; CMemThread<CMemAligned<CMemFixed> >::~CMemThread<CMemAligned<CMemFixed> >
; sqldk.dll, primary RVA 0x100870, 121 bytes in 1 chunk(s)

; chunk at RVA 0x100870 (121 bytes)
00100870  48894c2408               mov qword ptr [rsp + 8], rcx
00100875  53                       push rbx
00100876  4883ec30                 sub rsp, 0x30
0010087a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00100883  488bd9                   mov rbx, rcx
00100886  488d05b38b1400           lea rax, [rip + 0x148bb3]
0010088d  488901                   mov qword ptr [rcx], rax
00100890  488d8110010000           lea rax, [rcx + 0x110]
00100897  4889442448               mov qword ptr [rsp + 0x48], rax
0010089c  488d0d9d921300           lea rcx, [rip + 0x13929d]
001008a3  48894830                 mov qword ptr [rax + 0x30], rcx
001008a7  488908                   mov qword ptr [rax], rcx
001008aa  488d05c7a71400           lea rax, [rip + 0x14a7c7]
001008b1  488903                   mov qword ptr [rbx], rax
001008b4  488d05fd671400           lea rax, [rip + 0x1467fd]
001008bb  488903                   mov qword ptr [rbx], rax
001008be  488d0543691400           lea rax, [rip + 0x146943]
001008c5  488903                   mov qword ptr [rbx], rax
001008c8  488d4b38                 lea rcx, [rbx + 0x38]
001008cc  e81f19f1ff               call 0x121f0
001008d1  90                       nop
001008d2  488d4b30                 lea rcx, [rbx + 0x30]
001008d6  e81519f1ff               call 0x121f0
001008db  90                       nop
001008dc  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
001008e3  4883c430                 add rsp, 0x30
001008e7  5b                       pop rbx
001008e8  c3                       ret
