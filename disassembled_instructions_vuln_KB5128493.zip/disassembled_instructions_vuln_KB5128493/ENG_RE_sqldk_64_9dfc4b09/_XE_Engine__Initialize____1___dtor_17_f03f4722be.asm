; `XE_Engine::Initialize'::`1'::dtor$17
; sqldk.dll, primary RVA 0x233fef, 53 bytes in 1 chunk(s)

; chunk at RVA 0x233fef (53 bytes)
00233fef  4055                     push rbp
00233ff1  4883ec30                 sub rsp, 0x30
00233ff5  488bea                   mov rbp, rdx
00233ff8  c644242806               mov byte ptr [rsp + 0x28], 6
00233ffd  8b4530                   mov eax, dword ptr [rbp + 0x30]
00234000  89442420                 mov dword ptr [rsp + 0x20], eax
00234004  4c8d0d95670700           lea r9, [rip + 0x76795]
0023400b  41b801000000             mov r8d, 1
00234011  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00234015  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00234019  e8a25efaff               call 0x1d9ec0
0023401e  4883c430                 add rsp, 0x30
00234022  5d                       pop rbp
00234023  c3                       ret
