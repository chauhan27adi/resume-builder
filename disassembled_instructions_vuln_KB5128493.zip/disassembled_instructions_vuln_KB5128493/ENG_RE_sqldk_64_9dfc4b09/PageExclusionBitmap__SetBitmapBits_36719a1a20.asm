; PageExclusionBitmap::SetBitmapBits
; sqldk.dll, primary RVA 0xa610, 381 bytes in 7 chunk(s)

; chunk at RVA 0xa610 (32 bytes)
0000a610  4889742418               mov qword ptr [rsp + 0x18], rsi
0000a615  57                       push rdi
0000a616  488b3dc3693100           mov rdi, qword ptr [rip + 0x3169c3]
0000a61d  488bf2                   mov rsi, rdx
0000a620  450fb6d0                 movzx r10d, r8b
0000a624  4c8bc1                   mov r8, rcx
0000a627  4885ff                   test rdi, rdi
0000a62a  0f8442860000             je 0x12c72

; chunk at RVA 0xa630 (126 bytes)
0000a630  48895c2410               mov qword ptr [rsp + 0x10], rbx
0000a635  4c8bd9                   mov r11, rcx
0000a638  488bd9                   mov rbx, rcx
0000a63b  49c1eb10                 shr r11, 0x10
0000a63f  48c1eb0d                 shr rbx, 0xd
0000a643  4c8bcb                   mov r9, rbx
0000a646  48c1ea0d                 shr rdx, 0xd
0000a64a  4183e107                 and r9d, 7
0000a64e  4883fa08                 cmp rdx, 8
0000a652  0f875e850000             ja 0x12bb6
0000a658  b908000000               mov ecx, 8
0000a65d  8bc1                     mov eax, ecx
0000a65f  492bc1                   sub rax, r9
0000a662  483bc2                   cmp rax, rdx
0000a665  0f824b850000             jb 0x12bb6
0000a66b  420fb6041f               movzx eax, byte ptr [rdi + r11]
0000a670  2aca                     sub cl, dl
0000a672  412ac9                   sub cl, r9b
0000a675  baff000000               mov edx, 0xff
0000a67a  448bc2                   mov r8d, edx
0000a67d  41d3f8                   sar r8d, cl
0000a680  418bc9                   mov ecx, r9d
0000a683  d2e2                     shl dl, cl
0000a685  4422c2                   and r8b, dl
0000a688  4122c0                   and al, r8b
0000a68b  4584d2                   test r10b, r10b
0000a68e  0f846b180000             je 0xbeff
0000a694  413ac0                   cmp al, r8b
0000a697  0f84d0850000             je 0x12c6d
0000a69d  f04608041f               lock or byte ptr [rdi + r11], r8b
0000a6a2  488b5c2410               mov rbx, qword ptr [rsp + 0x10]
0000a6a7  488b742420               mov rsi, qword ptr [rsp + 0x20]
0000a6ac  5f                       pop rdi
0000a6ad  c3                       ret

; chunk at RVA 0xbeff (28 bytes)
0000beff  84c0                     test al, al
0000bf01  0f84666d0000             je 0x12c6d
0000bf07  41f6d0                   not r8b
0000bf0a  f04620041f               lock and byte ptr [rdi + r11], r8b
0000bf0f  488b5c2410               mov rbx, qword ptr [rsp + 0x10]
0000bf14  488b742420               mov rsi, qword ptr [rsp + 0x20]
0000bf19  5f                       pop rdi
0000bf1a  c3                       ret

; chunk at RVA 0x12bb6 (4 bytes)
00012bb6  498d1430                 lea rdx, [r8 + rsi]

; chunk at RVA 0x12bba (179 bytes)
00012bba  48896c2418               mov qword ptr [rsp + 0x18], rbp
00012bbf  0fb6cb                   movzx ecx, bl
00012bc2  4d8bc8                   mov r9, r8
00012bc5  80e13f                   and cl, 0x3f
00012bc8  49c1e913                 shr r9, 0x13
00012bcc  4c8d8200e0ffff           lea r8, [rdx - 0x2000]
00012bd3  48c7c3ffffffff           mov rbx, 0xffffffffffffffff
00012bda  49c1e813                 shr r8, 0x13
00012bde  488bf3                   mov rsi, rbx
00012be1  48d3e6                   shl rsi, cl
00012be4  4d8bd8                   mov r11, r8
00012be7  48c1ea0d                 shr rdx, 0xd
00012beb  b940000000               mov ecx, 0x40
00012bf0  80e23f                   and dl, 0x3f
00012bf3  4d2bd9                   sub r11, r9
00012bf6  2aca                     sub cl, dl
00012bf8  4e8d0ccf                 lea r9, [rdi + r9*8]
00012bfc  48d3eb                   shr rbx, cl
00012bff  4a8d3cc7                 lea rdi, [rdi + r8*8]
00012c03  33ed                     xor ebp, ebp
00012c05  498bc9                   mov rcx, r9
00012c08  448bc5                   mov r8d, ebp
00012c0b  4983c301                 add r11, 1
00012c0f  7457                     je 0x12c68
00012c11  0f1f00                   nop dword ptr [rax]
00012c14  0f1f4000                 nop dword ptr [rax]
00012c18  0f1f840000000000         nop dword ptr [rax + rax]
00012c20  4c3bc9                   cmp r9, rcx
00012c23  0f85a00f0200             jne 0x33bc9
00012c29  b201                     mov dl, 1
00012c2b  4983fb01                 cmp r11, 1
00012c2f  0f85a50f0200             jne 0x33bda
00012c35  488bc3                   mov rax, rbx
00012c38  4823c6                   and rax, rsi
00012c3b  eb01                     jmp 0x12c3e
00012c3d  cc                       int3
00012c3e  84d2                     test dl, dl
00012c40  0f84d9090200             je 0x3361f
00012c46  4584d2                   test r10b, r10b
00012c49  0f8561e30100             jne 0x30fb0
00012c4f  48f7d0                   not rax
00012c52  f0482101                 lock and qword ptr [rcx], rax
00012c56  eb01                     jmp 0x12c59
00012c58  cc                       int3
00012c59  41ffc0                   inc r8d
00012c5c  4883c108                 add rcx, 8
00012c60  418bc0                   mov eax, r8d
00012c63  493bc3                   cmp rax, r11
00012c66  72b8                     jb 0x12c20
00012c68  488b6c2418               mov rbp, qword ptr [rsp + 0x18]

; chunk at RVA 0x12c6d (5 bytes)
00012c6d  488b5c2410               mov rbx, qword ptr [rsp + 0x10]

; chunk at RVA 0x12c72 (7 bytes)
00012c72  488b742420               mov rsi, qword ptr [rsp + 0x20]
00012c77  5f                       pop rdi
00012c78  c3                       ret
