; CAutoRefc<XE_EventEntry>::~CAutoRefc<XE_EventEntry>
; sqldk.dll, primary RVA 0x1ee650, 80 bytes in 1 chunk(s)

; chunk at RVA 0x1ee650 (80 bytes)
001ee650  4053                     push rbx
001ee652  4883ec20                 sub rsp, 0x20
001ee656  488b19                   mov rbx, qword ptr [rcx]
001ee659  4885db                   test rbx, rbx
001ee65c  743c                     je 0x1ee69a
001ee65e  b8ffffffff               mov eax, 0xffffffff
001ee663  f00fc14310               lock xadd dword ptr [rbx + 0x10], eax
001ee668  83f801                   cmp eax, 1
001ee66b  752d                     jne 0x1ee69a
001ee66d  48837b0800               cmp qword ptr [rbx + 8], 0
001ee672  740c                     je 0x1ee680
001ee674  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001ee678  488bd3                   mov rdx, rbx
001ee67b  e8c0a6ffff               call 0x1e8d40
001ee680  488bcb                   mov rcx, rbx
001ee683  e848550000               call 0x1f3bd0
001ee688  baa8000000               mov edx, 0xa8
001ee68d  488bcb                   mov rcx, rbx
001ee690  4883c420                 add rsp, 0x20
001ee694  5b                       pop rbx
001ee695  e95697e1ff               jmp 0x7df0
001ee69a  4883c420                 add rsp, 0x20
001ee69e  5b                       pop rbx
001ee69f  c3                       ret
