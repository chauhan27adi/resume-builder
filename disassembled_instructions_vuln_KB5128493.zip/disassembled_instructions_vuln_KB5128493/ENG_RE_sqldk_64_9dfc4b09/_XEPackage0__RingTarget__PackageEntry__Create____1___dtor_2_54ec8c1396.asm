; `XEPackage0::RingTarget::PackageEntry::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x231ee5, 35 bytes in 1 chunk(s)

; chunk at RVA 0x231ee5 (35 bytes)
00231ee5  4055                     push rbp
00231ee7  4883ec20                 sub rsp, 0x20
00231eeb  488bea                   mov rbp, rdx
00231eee  4c8b4570                 mov r8, qword ptr [rbp + 0x70]
00231ef2  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
00231ef9  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
00231efd  e80ef1dcff               call 0x1010
00231f02  4883c420                 add rsp, 0x20
00231f06  5d                       pop rbp
00231f07  c3                       ret
