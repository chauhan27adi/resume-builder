; `XE_Session::CreateCollections'::`1'::dtor$4
; sqldk.dll, primary RVA 0x234c09, 59 bytes in 1 chunk(s)

; chunk at RVA 0x234c09 (59 bytes)
00234c09  4055                     push rbp
00234c0b  4883ec30                 sub rsp, 0x30
00234c0f  488bea                   mov rbp, rdx
00234c12  c644242806               mov byte ptr [rsp + 0x28], 6
00234c17  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00234c1d  89442420                 mov dword ptr [rsp + 0x20], eax
00234c21  4c8d0d505c0700           lea r9, [rip + 0x75c50]
00234c28  41b801000000             mov r8d, 1
00234c2e  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00234c35  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00234c39  e88252faff               call 0x1d9ec0
00234c3e  4883c430                 add rsp, 0x30
00234c42  5d                       pop rbp
00234c43  c3                       ret
