; DumpAnyXEObject
; sqldk.dll, primary RVA 0x1fac90, 1082 bytes in 13 chunk(s)

; chunk at RVA 0x1fac90 (78 bytes)
001fac90  4885d2                   test rdx, rdx
001fac93  0f8485010000             je 0x1fae1e
001fac99  55                       push rbp
001fac9a  53                       push rbx
001fac9b  56                       push rsi
001fac9c  488bec                   mov rbp, rsp
001fac9f  4881ec80000000           sub rsp, 0x80
001faca6  488b01                   mov rax, qword ptr [rcx]
001faca9  4c8d4204                 lea r8, [rdx + 4]
001facad  488bda                   mov rbx, rdx
001facb0  41b904000000             mov r9d, 4
001facb6  488d5530                 lea rdx, [rbp + 0x30]
001facba  488bf1                   mov rsi, rcx
001facbd  ff5058                   call qword ptr [rax + 0x58]
001facc0  85c0                     test eax, eax
001facc2  0f884c010000             js 0x1fae14
001facc8  8b4530                   mov eax, dword ptr [rbp + 0x30]
001faccb  c1e81c                   shr eax, 0x1c
001facce  83f808                   cmp eax, 8
001facd1  0f873d010000             ja 0x1fae14
001facd7  488d152253e0ff           lea rdx, [rip - 0x1facde]

; chunk at RVA 0x1facde (129 bytes)
001facde  4c89742470               mov qword ptr [rsp + 0x70], r14
001face3  8b8c82a8b01f00           mov ecx, dword ptr [rdx + rax*4 + 0x1fb0a8]
001facea  4803ca                   add rcx, rdx
001faced  ffe1                     jmp rcx
001facef  0faee8                   lfence
001facf2  4533f6                   xor r14d, r14d
001facf5  4c8975a0                 mov qword ptr [rbp - 0x60], r14
001facf9  0faee8                   lfence
001facfc  488b06                   mov rax, qword ptr [rsi]
001facff  458d4648                 lea r8d, [r14 + 0x48]
001fad03  488bd3                   mov rdx, rbx
001fad06  488bce                   mov rcx, rsi
001fad09  ff5060                   call qword ptr [rax + 0x60]
001fad0c  488b06                   mov rax, qword ptr [rsi]
001fad0f  4c8d4308                 lea r8, [rbx + 8]
001fad13  458d4e08                 lea r9d, [r14 + 8]
001fad17  488bce                   mov rcx, rsi
001fad1a  488d55a0                 lea rdx, [rbp - 0x60]
001fad1e  ff5058                   call qword ptr [rax + 0x58]
001fad21  85c0                     test eax, eax
001fad23  7816                     js 0x1fad3b
001fad25  0faee8                   lfence
001fad28  488b06                   mov rax, qword ptr [rsi]
001fad2b  41b800010000             mov r8d, 0x100
001fad31  488b55a0                 mov rdx, qword ptr [rbp - 0x60]
001fad35  488bce                   mov rcx, rsi
001fad38  ff5060                   call qword ptr [rax + 0x60]
001fad3b  488b06                   mov rax, qword ptr [rsi]
001fad3e  4c8d4324                 lea r8, [rbx + 0x24]
001fad42  41b902000000             mov r9d, 2
001fad48  6644897528               mov word ptr [rbp + 0x28], r14w
001fad4d  488d5528                 lea rdx, [rbp + 0x28]
001fad51  488bce                   mov rcx, rsi
001fad54  ff5058                   call qword ptr [rax + 0x58]
001fad57  85c0                     test eax, eax
001fad59  0f88b0000000             js 0x1fae0f

; chunk at RVA 0x1fad5f (176 bytes)
001fad5f  48897c2478               mov qword ptr [rsp + 0x78], rdi
001fad64  0faee8                   lfence
001fad67  0fb74528                 movzx eax, word ptr [rbp + 0x28]
001fad6b  4c8d4340                 lea r8, [rbx + 0x40]
001fad6f  bf00040000               mov edi, 0x400
001fad74  4c897538                 mov qword ptr [rbp + 0x38], r14
001fad78  483bc7                   cmp rax, rdi
001fad7b  488d5538                 lea rdx, [rbp + 0x38]
001fad7f  41b908000000             mov r9d, 8
001fad85  488bce                   mov rcx, rsi
001fad88  0f42f8                   cmovb edi, eax
001fad8b  488b06                   mov rax, qword ptr [rsi]
001fad8e  ff5058                   call qword ptr [rax + 0x58]
001fad91  85c0                     test eax, eax
001fad93  7875                     js 0x1fae0a
001fad95  0faee8                   lfence
001fad98  488b06                   mov rax, qword ptr [rsi]
001fad9b  4c8d04bf                 lea r8, [rdi + rdi*4]
001fad9f  488b5538                 mov rdx, qword ptr [rbp + 0x38]
001fada3  488bce                   mov rcx, rsi
001fada6  49c1e003                 shl r8, 3
001fadaa  ff5060                   call qword ptr [rax + 0x60]
001fadad  418bde                   mov ebx, r14d
001fadb0  4885ff                   test rdi, rdi
001fadb3  7455                     je 0x1fae0a
001fadb5  498bc6                   mov rax, r14
001fadb8  0f1f840000000000         nop dword ptr [rax + rax]
001fadc0  488d0c80                 lea rcx, [rax + rax*4]
001fadc4  4c8975a8                 mov qword ptr [rbp - 0x58], r14
001fadc8  488b4538                 mov rax, qword ptr [rbp + 0x38]
001fadcc  488d4901                 lea rcx, [rcx + 1]
001fadd0  41b908000000             mov r9d, 8
001fadd6  488d55a8                 lea rdx, [rbp - 0x58]
001fadda  4c8d04c8                 lea r8, [rax + rcx*8]
001fadde  488b06                   mov rax, qword ptr [rsi]
001fade1  488bce                   mov rcx, rsi
001fade4  ff5058                   call qword ptr [rax + 0x58]
001fade7  85c0                     test eax, eax
001fade9  7816                     js 0x1fae01
001fadeb  0faee8                   lfence
001fadee  488b06                   mov rax, qword ptr [rsi]
001fadf1  41b800010000             mov r8d, 0x100
001fadf7  488b55a8                 mov rdx, qword ptr [rbp - 0x58]
001fadfb  488bce                   mov rcx, rsi
001fadfe  ff5060                   call qword ptr [rax + 0x60]
001fae01  ffc3                     inc ebx
001fae03  8bc3                     mov eax, ebx
001fae05  483bc7                   cmp rax, rdi
001fae08  72b6                     jb 0x1fadc0
001fae0a  488b7c2478               mov rdi, qword ptr [rsp + 0x78]

; chunk at RVA 0x1fae0f (5 bytes)
001fae0f  4c8b742470               mov r14, qword ptr [rsp + 0x70]

; chunk at RVA 0x1fae14 (11 bytes)
001fae14  4881c480000000           add rsp, 0x80
001fae1b  5e                       pop rsi
001fae1c  5b                       pop rbx
001fae1d  5d                       pop rbp
001fae1e  c3                       ret

; chunk at RVA 0x1fae1f (89 bytes)
001fae1f  4533f6                   xor r14d, r14d
001fae22  4c8975b0                 mov qword ptr [rbp - 0x50], r14
001fae26  0faee8                   lfence
001fae29  488b06                   mov rax, qword ptr [rsi]
001fae2c  458d4648                 lea r8d, [r14 + 0x48]
001fae30  488bd3                   mov rdx, rbx
001fae33  488bce                   mov rcx, rsi
001fae36  ff5060                   call qword ptr [rax + 0x60]
001fae39  488b06                   mov rax, qword ptr [rsi]
001fae3c  4c8d4308                 lea r8, [rbx + 8]
001fae40  458d4e08                 lea r9d, [r14 + 8]
001fae44  488bce                   mov rcx, rsi
001fae47  488d55b0                 lea rdx, [rbp - 0x50]
001fae4b  ff5058                   call qword ptr [rax + 0x58]
001fae4e  85c0                     test eax, eax
001fae50  78bd                     js 0x1fae0f
001fae52  0faee8                   lfence
001fae55  488b06                   mov rax, qword ptr [rsi]
001fae58  41b800010000             mov r8d, 0x100
001fae5e  488b55b0                 mov rdx, qword ptr [rbp - 0x50]
001fae62  488bce                   mov rcx, rsi
001fae65  ff5060                   call qword ptr [rax + 0x60]
001fae68  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001fae6d  4881c480000000           add rsp, 0x80
001fae74  5e                       pop rsi
001fae75  5b                       pop rbx
001fae76  5d                       pop rbp
001fae77  c3                       ret

; chunk at RVA 0x1fae78 (93 bytes)
001fae78  4533f6                   xor r14d, r14d
001fae7b  4c8975b8                 mov qword ptr [rbp - 0x48], r14
001fae7f  0faee8                   lfence
001fae82  488b06                   mov rax, qword ptr [rsi]
001fae85  458d4638                 lea r8d, [r14 + 0x38]
001fae89  488bd3                   mov rdx, rbx
001fae8c  488bce                   mov rcx, rsi
001fae8f  ff5060                   call qword ptr [rax + 0x60]
001fae92  488b06                   mov rax, qword ptr [rsi]
001fae95  4c8d4308                 lea r8, [rbx + 8]
001fae99  458d4e08                 lea r9d, [r14 + 8]
001fae9d  488bce                   mov rcx, rsi
001faea0  488d55b8                 lea rdx, [rbp - 0x48]
001faea4  ff5058                   call qword ptr [rax + 0x58]
001faea7  85c0                     test eax, eax
001faea9  0f8860ffffff             js 0x1fae0f
001faeaf  0faee8                   lfence
001faeb2  488b06                   mov rax, qword ptr [rsi]
001faeb5  41b800010000             mov r8d, 0x100
001faebb  488b55b8                 mov rdx, qword ptr [rbp - 0x48]
001faebf  488bce                   mov rcx, rsi
001faec2  ff5060                   call qword ptr [rax + 0x60]
001faec5  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001faeca  4881c480000000           add rsp, 0x80
001faed1  5e                       pop rsi
001faed2  5b                       pop rbx
001faed3  5d                       pop rbp
001faed4  c3                       ret

; chunk at RVA 0x1faed5 (93 bytes)
001faed5  4533f6                   xor r14d, r14d
001faed8  4c8975c0                 mov qword ptr [rbp - 0x40], r14
001faedc  0faee8                   lfence
001faedf  488b06                   mov rax, qword ptr [rsi]
001faee2  458d4630                 lea r8d, [r14 + 0x30]
001faee6  488bd3                   mov rdx, rbx
001faee9  488bce                   mov rcx, rsi
001faeec  ff5060                   call qword ptr [rax + 0x60]
001faeef  488b06                   mov rax, qword ptr [rsi]
001faef2  4c8d4308                 lea r8, [rbx + 8]
001faef6  458d4e08                 lea r9d, [r14 + 8]
001faefa  488bce                   mov rcx, rsi
001faefd  488d55c0                 lea rdx, [rbp - 0x40]
001faf01  ff5058                   call qword ptr [rax + 0x58]
001faf04  85c0                     test eax, eax
001faf06  0f8803ffffff             js 0x1fae0f
001faf0c  0faee8                   lfence
001faf0f  488b06                   mov rax, qword ptr [rsi]
001faf12  41b800010000             mov r8d, 0x100
001faf18  488b55c0                 mov rdx, qword ptr [rbp - 0x40]
001faf1c  488bce                   mov rcx, rsi
001faf1f  ff5060                   call qword ptr [rax + 0x60]
001faf22  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001faf27  4881c480000000           add rsp, 0x80
001faf2e  5e                       pop rsi
001faf2f  5b                       pop rbx
001faf30  5d                       pop rbp
001faf31  c3                       ret

; chunk at RVA 0x1faf32 (93 bytes)
001faf32  4533f6                   xor r14d, r14d
001faf35  4c8975c8                 mov qword ptr [rbp - 0x38], r14
001faf39  0faee8                   lfence
001faf3c  488b06                   mov rax, qword ptr [rsi]
001faf3f  458d4650                 lea r8d, [r14 + 0x50]
001faf43  488bd3                   mov rdx, rbx
001faf46  488bce                   mov rcx, rsi
001faf49  ff5060                   call qword ptr [rax + 0x60]
001faf4c  488b06                   mov rax, qword ptr [rsi]
001faf4f  4c8d4308                 lea r8, [rbx + 8]
001faf53  458d4e08                 lea r9d, [r14 + 8]
001faf57  488bce                   mov rcx, rsi
001faf5a  488d55c8                 lea rdx, [rbp - 0x38]
001faf5e  ff5058                   call qword ptr [rax + 0x58]
001faf61  85c0                     test eax, eax
001faf63  0f88a6feffff             js 0x1fae0f
001faf69  0faee8                   lfence
001faf6c  488b06                   mov rax, qword ptr [rsi]
001faf6f  41b800010000             mov r8d, 0x100
001faf75  488b55c8                 mov rdx, qword ptr [rbp - 0x38]
001faf79  488bce                   mov rcx, rsi
001faf7c  ff5060                   call qword ptr [rax + 0x60]
001faf7f  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001faf84  4881c480000000           add rsp, 0x80
001faf8b  5e                       pop rsi
001faf8c  5b                       pop rbx
001faf8d  5d                       pop rbp
001faf8e  c3                       ret

; chunk at RVA 0x1faf8f (93 bytes)
001faf8f  4533f6                   xor r14d, r14d
001faf92  4c8975d0                 mov qword ptr [rbp - 0x30], r14
001faf96  0faee8                   lfence
001faf99  488b06                   mov rax, qword ptr [rsi]
001faf9c  458d4660                 lea r8d, [r14 + 0x60]
001fafa0  488bd3                   mov rdx, rbx
001fafa3  488bce                   mov rcx, rsi
001fafa6  ff5060                   call qword ptr [rax + 0x60]
001fafa9  488b06                   mov rax, qword ptr [rsi]
001fafac  4c8d4308                 lea r8, [rbx + 8]
001fafb0  458d4e08                 lea r9d, [r14 + 8]
001fafb4  488bce                   mov rcx, rsi
001fafb7  488d55d0                 lea rdx, [rbp - 0x30]
001fafbb  ff5058                   call qword ptr [rax + 0x58]
001fafbe  85c0                     test eax, eax
001fafc0  0f8849feffff             js 0x1fae0f
001fafc6  0faee8                   lfence
001fafc9  488b06                   mov rax, qword ptr [rsi]
001fafcc  41b800010000             mov r8d, 0x100
001fafd2  488b55d0                 mov rdx, qword ptr [rbp - 0x30]
001fafd6  488bce                   mov rcx, rsi
001fafd9  ff5060                   call qword ptr [rax + 0x60]
001fafdc  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001fafe1  4881c480000000           add rsp, 0x80
001fafe8  5e                       pop rsi
001fafe9  5b                       pop rbx
001fafea  5d                       pop rbp
001fafeb  c3                       ret

; chunk at RVA 0x1fafec (93 bytes)
001fafec  4533f6                   xor r14d, r14d
001fafef  4c8975d8                 mov qword ptr [rbp - 0x28], r14
001faff3  0faee8                   lfence
001faff6  488b06                   mov rax, qword ptr [rsi]
001faff9  458d4628                 lea r8d, [r14 + 0x28]
001faffd  488bd3                   mov rdx, rbx
001fb000  488bce                   mov rcx, rsi
001fb003  ff5060                   call qword ptr [rax + 0x60]
001fb006  488b06                   mov rax, qword ptr [rsi]
001fb009  4c8d4308                 lea r8, [rbx + 8]
001fb00d  458d4e08                 lea r9d, [r14 + 8]
001fb011  488bce                   mov rcx, rsi
001fb014  488d55d8                 lea rdx, [rbp - 0x28]
001fb018  ff5058                   call qword ptr [rax + 0x58]
001fb01b  85c0                     test eax, eax
001fb01d  0f88ecfdffff             js 0x1fae0f
001fb023  0faee8                   lfence
001fb026  488b06                   mov rax, qword ptr [rsi]
001fb029  41b800010000             mov r8d, 0x100
001fb02f  488b55d8                 mov rdx, qword ptr [rbp - 0x28]
001fb033  488bce                   mov rcx, rsi
001fb036  ff5060                   call qword ptr [rax + 0x60]
001fb039  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001fb03e  4881c480000000           add rsp, 0x80
001fb045  5e                       pop rsi
001fb046  5b                       pop rbx
001fb047  5d                       pop rbp
001fb048  c3                       ret

; chunk at RVA 0x1fb049 (93 bytes)
001fb049  4533f6                   xor r14d, r14d
001fb04c  4c8975e0                 mov qword ptr [rbp - 0x20], r14
001fb050  0faee8                   lfence
001fb053  488b06                   mov rax, qword ptr [rsi]
001fb056  458d4658                 lea r8d, [r14 + 0x58]
001fb05a  488bd3                   mov rdx, rbx
001fb05d  488bce                   mov rcx, rsi
001fb060  ff5060                   call qword ptr [rax + 0x60]
001fb063  488b06                   mov rax, qword ptr [rsi]
001fb066  4c8d4308                 lea r8, [rbx + 8]
001fb06a  458d4e08                 lea r9d, [r14 + 8]
001fb06e  488bce                   mov rcx, rsi
001fb071  488d55e0                 lea rdx, [rbp - 0x20]
001fb075  ff5058                   call qword ptr [rax + 0x58]
001fb078  85c0                     test eax, eax
001fb07a  0f888ffdffff             js 0x1fae0f
001fb080  0faee8                   lfence
001fb083  488b06                   mov rax, qword ptr [rsi]
001fb086  41b800010000             mov r8d, 0x100
001fb08c  488b55e0                 mov rdx, qword ptr [rbp - 0x20]
001fb090  488bce                   mov rcx, rsi
001fb093  ff5060                   call qword ptr [rax + 0x60]
001fb096  4c8b742470               mov r14, qword ptr [rsp + 0x70]
001fb09b  4881c480000000           add rsp, 0x80
001fb0a2  5e                       pop rsi
001fb0a3  5b                       pop rbx
001fb0a4  5d                       pop rbp
001fb0a5  c3                       ret

; chunk at RVA 0x1fb0a8 (36 bytes)
001fb0a8  ef                       out dx, eax
001fb0a9  ac                       lodsb al, byte ptr [rsi]
