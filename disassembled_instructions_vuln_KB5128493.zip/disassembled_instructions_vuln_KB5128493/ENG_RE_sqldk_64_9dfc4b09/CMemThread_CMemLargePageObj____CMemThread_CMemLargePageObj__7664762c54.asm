; CMemThread<CMemLargePageObj>::~CMemThread<CMemLargePageObj>
; sqldk.dll, primary RVA 0x113730, 121 bytes in 1 chunk(s)

; chunk at RVA 0x113730 (121 bytes)
00113730  48894c2408               mov qword ptr [rsp + 8], rcx
00113735  53                       push rbx
00113736  4883ec30                 sub rsp, 0x30
0011373a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00113743  488bd9                   mov rbx, rcx
00113746  488d05e3541300           lea rax, [rip + 0x1354e3]
0011374d  488901                   mov qword ptr [rcx], rax
00113750  488d81c8010000           lea rax, [rcx + 0x1c8]
00113757  4889442448               mov qword ptr [rsp + 0x48], rax
0011375c  488d0ddd631200           lea rcx, [rip + 0x1263dd]
00113763  48894830                 mov qword ptr [rax + 0x30], rcx
00113767  488908                   mov qword ptr [rax], rcx
0011376a  488d05a7361300           lea rax, [rip + 0x1336a7]
00113771  488903                   mov qword ptr [rbx], rax
00113774  488d05ed371300           lea rax, [rip + 0x1337ed]
0011377b  488903                   mov qword ptr [rbx], rax
0011377e  488d05833a1300           lea rax, [rip + 0x133a83]
00113785  488903                   mov qword ptr [rbx], rax
00113788  488d4b38                 lea rcx, [rbx + 0x38]
0011378c  e85feaefff               call 0x121f0
00113791  90                       nop
00113792  488d4b30                 lea rcx, [rbx + 0x30]
00113796  e855eaefff               call 0x121f0
0011379b  90                       nop
0011379c  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
001137a3  4883c430                 add rsp, 0x30
001137a7  5b                       pop rbx
001137a8  c3                       ret
