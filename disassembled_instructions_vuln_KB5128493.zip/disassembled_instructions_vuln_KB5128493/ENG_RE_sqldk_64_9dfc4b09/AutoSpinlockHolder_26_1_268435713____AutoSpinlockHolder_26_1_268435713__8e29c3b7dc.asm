; AutoSpinlockHolder<26,1,268435713>::~AutoSpinlockHolder<26,1,268435713>
; sqldk.dll, primary RVA 0x959d0, 27 bytes in 1 chunk(s)

; chunk at RVA 0x959d0 (27 bytes)
000959d0  48894c2408               mov qword ptr [rsp + 8], rcx
000959d5  4883ec38                 sub rsp, 0x38
000959d9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000959e2  4883c438                 add rsp, 0x38
000959e6  e965d7f8ff               jmp 0x23150
