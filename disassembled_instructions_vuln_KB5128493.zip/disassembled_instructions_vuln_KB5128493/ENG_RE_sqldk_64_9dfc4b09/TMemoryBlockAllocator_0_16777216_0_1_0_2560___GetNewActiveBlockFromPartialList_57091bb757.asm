; TMemoryBlockAllocator<0,16777216,0,1,0,2560>::GetNewActiveBlockFromPartialList
; sqldk.dll, primary RVA 0x1e7e0, 388 bytes in 1 chunk(s)

; chunk at RVA 0x1e7e0 (388 bytes)
0001e7e0  488bc4                   mov rax, rsp
0001e7e3  44884018                 mov byte ptr [rax + 0x18], r8b
0001e7e7  48894808                 mov qword ptr [rax + 8], rcx
0001e7eb  55                       push rbp
0001e7ec  56                       push rsi
0001e7ed  57                       push rdi
0001e7ee  4154                     push r12
0001e7f0  4155                     push r13
0001e7f2  4156                     push r14
0001e7f4  4157                     push r15
0001e7f6  488d68a9                 lea rbp, [rax - 0x57]
0001e7fa  4881ec90000000           sub rsp, 0x90
0001e801  48c7450ffeffffff         mov qword ptr [rbp + 0xf], 0xfffffffffffffffe
0001e809  48895810                 mov qword ptr [rax + 0x10], rbx
0001e80d  4c8bf9                   mov r15, rcx
0001e810  33ff                     xor edi, edi
0001e812  8bdf                     mov ebx, edi
0001e814  48895daf                 mov qword ptr [rbp - 0x51], rbx
0001e818  488d45b7                 lea rax, [rbp - 0x49]
0001e81c  488945bf                 mov qword ptr [rbp - 0x41], rax
0001e820  488d45b7                 lea rax, [rbp - 0x49]
0001e824  488945b7                 mov qword ptr [rbp - 0x49], rax
0001e828  440fb7ea                 movzx r13d, dx
0001e82c  4983c502                 add r13, 2
0001e830  49c1e507                 shl r13, 7
0001e834  4c03e9                   add r13, rcx
0001e837  4c896df7                 mov qword ptr [rbp - 9], r13
0001e83b  448d6706                 lea r12d, [rdi + 6]
0001e83f  440fb6757f               movzx r14d, byte ptr [rbp + 0x7f]
0001e844  4584c9                   test r9b, r9b
0001e847  0f8466460700             je 0x92eb3
0001e84d  8d7701                   lea esi, [rdi + 1]
0001e850  eb01                     jmp 0x1e853
0001e852  cc                       int3
0001e853  48895daf                 mov qword ptr [rbp - 0x51], rbx
0001e857  83fe02                   cmp esi, 2
0001e85a  7369                     jae 0x1e8c5
0001e85c  48897daf                 mov qword ptr [rbp - 0x51], rdi
0001e860  488d4dc7                 lea rcx, [rbp - 0x39]
0001e864  48894dcf                 mov qword ptr [rbp - 0x31], rcx
0001e868  488d45c7                 lea rax, [rbp - 0x39]
0001e86c  488945c7                 mov qword ptr [rbp - 0x39], rax
0001e870  4863fe                   movsxd rdi, esi
0001e873  4883c704                 add rdi, 4
0001e877  48c1e704                 shl rdi, 4
0001e87b  4903fd                   add rdi, r13
0001e87e  488bcf                   mov rcx, rdi
0001e881  ff1591a92100             call qword ptr [rip + 0x21a991]
0001e887  4c8bc0                   mov r8, rax
0001e88a  4885c0                   test rax, rax
0001e88d  0f85a6440700             jne 0x92d39
0001e893  488b5daf                 mov rbx, qword ptr [rbp - 0x51]
0001e897  4533ff                   xor r15d, r15d
0001e89a  660f1f440000             nop word ptr [rax + rax]
0001e8a0  488d45c7                 lea rax, [rbp - 0x39]
0001e8a4  488b55cf                 mov rdx, qword ptr [rbp - 0x31]
0001e8a8  483bd0                   cmp rdx, rax
0001e8ab  0f85c3450700             jne 0x92e74
0001e8b1  ffc6                     inc esi
0001e8b3  4885db                   test rbx, rbx
0001e8b6  4c8b7d5f                 mov r15, qword ptr [rbp + 0x5f]
0001e8ba  0f85a1000000             jne 0x1e961
0001e8c0  33ff                     xor edi, edi
0001e8c2  eb8f                     jmp 0x1e853
0001e8c4  cc                       int3
0001e8c5  4885db                   test rbx, rbx
0001e8c8  0f85a2000000             jne 0x1e970
0001e8ce  eb01                     jmp 0x1e8d1
0001e8d0  cc                       int3
0001e8d1  807d6f00                 cmp byte ptr [rbp + 0x6f], 0
0001e8d5  0f8495000000             je 0x1e970
0001e8db  498d7530                 lea rsi, [r13 + 0x30]
0001e8df  488975ff                 mov qword ptr [rbp - 1], rsi
0001e8e3  897d07                   mov dword ptr [rbp + 7], edi
0001e8e6  488bdf                   mov rbx, rdi
0001e8e9  658b042548000000         mov eax, dword ptr gs:[0x48]
0001e8f1  448bf0                   mov r14d, eax
0001e8f4  8b06                     mov eax, dword ptr [rsi]
0001e8f6  85c0                     test eax, eax
0001e8f8  0f85e2860100             jne 0x36fe0
0001e8fe  33c0                     xor eax, eax
0001e900  f04c0fb136               lock cmpxchg qword ptr [rsi], r14
0001e905  8bc7                     mov eax, edi
0001e907  0f94c0                   sete al
0001e90a  85c0                     test eax, eax
0001e90c  0f84ce860100             je 0x36fe0
0001e912  c7450701000000           mov dword ptr [rbp + 7], 1
0001e919  448bff                   mov r15d, edi
0001e91c  4983c538                 add r13, 0x38
0001e920  4c8b65f7                 mov r12, qword ptr [rbp - 9]
0001e924  488b5daf                 mov rbx, qword ptr [rbp - 0x51]
0001e928  0f1f840000000000         nop dword ptr [rax + rax]
0001e930  4183ff01                 cmp r15d, 1
0001e934  731d                     jae 0x1e953
0001e936  498b5d08                 mov rbx, qword ptr [r13 + 8]
0001e93a  493bdd                   cmp rbx, r13
0001e93d  0f851d490700             jne 0x93260
0001e943  488b5daf                 mov rbx, qword ptr [rbp - 0x51]
0001e947  41ffc7                   inc r15d
0001e94a  4983c510                 add r13, 0x10
0001e94e  4885db                   test rbx, rbx
0001e951  74dd                     je 0x1e930
0001e953  488d4dff                 lea rcx, [rbp - 1]
0001e957  e8a4ccffff               call 0x1b600
0001e95c  660f1f0400               nop word ptr [rax + rax]
0001e961  eb0d                     jmp 0x1e970
0001e963  cc                       int3
