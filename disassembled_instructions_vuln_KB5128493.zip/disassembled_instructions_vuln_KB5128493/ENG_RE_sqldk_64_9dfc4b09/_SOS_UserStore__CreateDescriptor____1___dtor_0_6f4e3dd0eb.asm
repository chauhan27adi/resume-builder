; `SOS_UserStore::CreateDescriptor'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22cd90, 72 bytes in 1 chunk(s)

; chunk at RVA 0x22cd90 (72 bytes)
0022cd90  4055                     push rbp
0022cd92  4883ec30                 sub rsp, 0x30
0022cd96  488bea                   mov rbp, rdx
0022cd99  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0022cda0  4881c2c0060000           add rdx, 0x6c0
0022cda7  c644242806               mov byte ptr [rsp + 0x28], 6
0022cdac  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022cdb2  89442420                 mov dword ptr [rsp + 0x20], eax
0022cdb6  4c8d0d538d0300           lea r9, [rip + 0x38d53]
0022cdbd  41b801000000             mov r8d, 1
0022cdc3  488b12                   mov rdx, qword ptr [rdx]
0022cdc6  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
0022cdcd  e8ceafddff               call 0x7da0
0022cdd2  4883c430                 add rsp, 0x30
0022cdd6  5d                       pop rbp
0022cdd7  c3                       ret
