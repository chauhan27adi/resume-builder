; `SOS_Scheduler::Start'::`1'::dtor$0
; sqldk.dll, primary RVA 0x219a50, 63 bytes in 1 chunk(s)

; chunk at RVA 0x219a50 (63 bytes)
00219a50  4055                     push rbp
00219a52  4883ec30                 sub rsp, 0x30
00219a56  488bea                   mov rbp, rdx
00219a59  488b5550                 mov rdx, qword ptr [rbp + 0x50]
00219a5d  4881c2780e0000           add rdx, 0xe78
00219a64  c644242806               mov byte ptr [rsp + 0x28], 6
00219a69  8b4540                   mov eax, dword ptr [rbp + 0x40]
00219a6c  89442420                 mov dword ptr [rsp + 0x20], eax
00219a70  4c8d0dd9c00400           lea r9, [rip + 0x4c0d9]
00219a77  41b801000000             mov r8d, 1
00219a7d  488b12                   mov rdx, qword ptr [rdx]
00219a80  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
00219a84  e817e3deff               call 0x7da0
00219a89  4883c430                 add rsp, 0x30
00219a8d  5d                       pop rbp
00219a8e  c3                       ret
