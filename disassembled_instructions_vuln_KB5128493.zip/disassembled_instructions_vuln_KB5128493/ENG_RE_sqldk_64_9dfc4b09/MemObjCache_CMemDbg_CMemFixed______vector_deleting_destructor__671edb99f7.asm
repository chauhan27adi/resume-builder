; MemObjCache<CMemDbg<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e600, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13e600 (79 bytes)
0013e600  48894c2408               mov qword ptr [rsp + 8], rcx
0013e605  57                       push rdi
0013e606  4883ec30                 sub rsp, 0x30
0013e60a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e613  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e618  8bda                     mov ebx, edx
0013e61a  488bf9                   mov rdi, rcx
0013e61d  488d05bca81000           lea rax, [rip + 0x10a8bc]
0013e624  488901                   mov qword ptr [rcx], rax
0013e627  e844290300               call 0x170f70
0013e62c  83e305                   and ebx, 5
0013e62f  80fb05                   cmp bl, 5
0013e632  750d                     jne 0x13e641
0013e634  ba28050000               mov edx, 0x528
0013e639  488bcf                   mov rcx, rdi
0013e63c  e8cf29ecff               call 0x1010
0013e641  488bc7                   mov rax, rdi
0013e644  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e649  4883c430                 add rsp, 0x30
0013e64d  5f                       pop rdi
0013e64e  c3                       ret
