; MemoryNode::ShouldShrinkExternalCache
; sqldk.dll, primary RVA 0x38860, 131 bytes in 1 chunk(s)

; chunk at RVA 0x38860 (131 bytes)
00038860  4883ec28                 sub rsp, 0x28
00038864  488b5150                 mov rdx, qword ptr [rcx + 0x50]
00038868  4c8bc1                   mov r8, rcx
0003886b  48035148                 add rdx, qword ptr [rcx + 0x48]
0003886f  48035140                 add rdx, qword ptr [rcx + 0x40]
00038873  833d1e872e0001           cmp dword ptr [rip + 0x2e871e], 1
0003887a  0f84c79d0600             je 0xa2647
00038880  498b8090000000           mov rax, qword ptr [r8 + 0x90]
00038887  488b89a8000000           mov rcx, qword ptr [rcx + 0xa8]
0003888e  483bc8                   cmp rcx, rax
00038891  480f4dc8                 cmovge rcx, rax
00038895  488d4201                 lea rax, [rdx + 1]
00038899  4899                     cqo
0003889b  482bc2                   sub rax, rdx
0003889e  48d1f8                   sar rax, 1
000388a1  483bc8                   cmp rcx, rax
000388a4  0f8cc19d0600             jl 0xa266b
000388aa  498bc8                   mov rcx, r8
000388ad  e88ed6fdff               call 0x15f40
000388b2  85c0                     test eax, eax
000388b4  0f85b19d0600             jne 0xa266b
000388ba  f60519c22d0001           test byte ptr [rip + 0x2dc219], 1
000388c1  7519                     jne 0x388dc
000388c3  f60511c22d0002           test byte ptr [rip + 0x2dc211], 2
000388ca  7510                     jne 0x388dc
000388cc  8d4801                   lea ecx, [rax + 1]
000388cf  e8acc5fdff               call 0x14e80
000388d4  85c0                     test eax, eax
000388d6  0f857c9d0600             jne 0xa2658
000388dc  33c0                     xor eax, eax
000388de  4883c428                 add rsp, 0x28
000388e2  c3                       ret
