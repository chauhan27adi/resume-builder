; `XE_Engine::CreatePredicateNode'::`1'::dtor$5
; sqldk.dll, primary RVA 0x233c30, 56 bytes in 1 chunk(s)

; chunk at RVA 0x233c30 (56 bytes)
00233c30  4055                     push rbp
00233c32  4883ec30                 sub rsp, 0x30
00233c36  488bea                   mov rbp, rdx
00233c39  c644242806               mov byte ptr [rsp + 0x28], 6
00233c3e  8b4570                   mov eax, dword ptr [rbp + 0x70]
00233c41  89442420                 mov dword ptr [rsp + 0x20], eax
00233c45  4c8d0d0c6f0700           lea r9, [rip + 0x76f0c]
00233c4c  41b801000000             mov r8d, 1
00233c52  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
00233c59  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00233c5d  e85e62faff               call 0x1d9ec0
00233c62  4883c430                 add rsp, 0x30
00233c66  5d                       pop rbp
00233c67  c3                       ret
