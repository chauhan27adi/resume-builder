; `XE_Engine::Initialize'::`1'::dtor$3
; sqldk.dll, primary RVA 0x234066, 56 bytes in 1 chunk(s)

; chunk at RVA 0x234066 (56 bytes)
00234066  4055                     push rbp
00234068  4883ec30                 sub rsp, 0x30
0023406c  488bea                   mov rbp, rdx
0023406f  c644242806               mov byte ptr [rsp + 0x28], 6
00234074  8b4530                   mov eax, dword ptr [rbp + 0x30]
00234077  89442420                 mov dword ptr [rsp + 0x20], eax
0023407b  4c8d0d1e670700           lea r9, [rip + 0x7671e]
00234082  41b801000000             mov r8d, 1
00234088  488b15f1e51700           mov rdx, qword ptr [rip + 0x17e5f1]
0023408f  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00234093  e8285efaff               call 0x1d9ec0
00234098  4883c430                 add rsp, 0x30
0023409c  5d                       pop rbp
0023409d  c3                       ret
