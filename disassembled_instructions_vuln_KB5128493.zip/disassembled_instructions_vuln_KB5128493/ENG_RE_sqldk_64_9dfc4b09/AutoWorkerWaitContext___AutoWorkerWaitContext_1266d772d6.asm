; AutoWorkerWaitContext::~AutoWorkerWaitContext
; sqldk.dll, primary RVA 0x95310, 60 bytes in 3 chunk(s)

; chunk at RVA 0x95310 (16 bytes)
00095310  4883ec28                 sub rsp, 0x28
00095314  488b01                   mov rax, qword ptr [rcx]
00095317  4885c0                   test rax, rax
0009531a  742b                     je 0x95347
0009531c  488b4008                 mov rax, qword ptr [rax + 8]

; chunk at RVA 0x95320 (39 bytes)
00095320  48895c2420               mov qword ptr [rsp + 0x20], rbx
00095325  81a020030000ffff7fff     and dword ptr [rax + 0x320], 0xff7fffff
0009532f  488b19                   mov rbx, qword ptr [rcx]
00095332  488bcb                   mov rcx, rbx
00095335  e8a6def6ff               call 0x31e0
0009533a  33c0                     xor eax, eax
0009533c  894318                   mov dword ptr [rbx + 0x18], eax
0009533f  488903                   mov qword ptr [rbx], rax
00095342  488b5c2420               mov rbx, qword ptr [rsp + 0x20]

; chunk at RVA 0x95347 (5 bytes)
00095347  4883c428                 add rsp, 0x28
0009534b  c3                       ret
