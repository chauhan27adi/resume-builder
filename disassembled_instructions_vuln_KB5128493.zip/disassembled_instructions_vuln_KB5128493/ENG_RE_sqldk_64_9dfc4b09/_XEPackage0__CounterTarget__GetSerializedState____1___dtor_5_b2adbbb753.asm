; `XEPackage0::CounterTarget::GetSerializedState'::`1'::dtor$5
; sqldk.dll, primary RVA 0x2317d4, 34 bytes in 1 chunk(s)

; chunk at RVA 0x2317d4 (34 bytes)
002317d4  4055                     push rbp
002317d6  4883ec20                 sub rsp, 0x20
002317da  488bea                   mov rbp, rdx
002317dd  4533c0                   xor r8d, r8d
002317e0  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
002317e7  488b4d78                 mov rcx, qword ptr [rbp + 0x78]
002317eb  e820f8dcff               call 0x1010
002317f0  4883c420                 add rsp, 0x20
002317f4  5d                       pop rbp
002317f5  c3                       ret
