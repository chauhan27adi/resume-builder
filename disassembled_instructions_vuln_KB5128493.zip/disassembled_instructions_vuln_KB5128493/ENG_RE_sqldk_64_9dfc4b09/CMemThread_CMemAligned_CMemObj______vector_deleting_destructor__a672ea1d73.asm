; CMemThread<CMemAligned<CMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13eeb0, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13eeb0 (55 bytes)
0013eeb0  48895c2408               mov qword ptr [rsp + 8], rbx
0013eeb5  57                       push rdi
0013eeb6  4883ec20                 sub rsp, 0x20
0013eeba  8bda                     mov ebx, edx
0013eebc  488bf9                   mov rdi, rcx
0013eebf  e8bcf5feff               call 0x12e480
0013eec4  83e305                   and ebx, 5
0013eec7  80fb05                   cmp bl, 5
0013eeca  750d                     jne 0x13eed9
0013eecc  ba08020000               mov edx, 0x208
0013eed1  488bcf                   mov rcx, rdi
0013eed4  e83721ecff               call 0x1010
0013eed9  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013eede  488bc7                   mov rax, rdi
0013eee1  4883c420                 add rsp, 0x20
0013eee5  5f                       pop rdi
0013eee6  c3                       ret
