; `XEPackage0::HistoryTarget::InitDictionary'::`1'::dtor$3
; sqldk.dll, primary RVA 0x23299e, 48 bytes in 1 chunk(s)

; chunk at RVA 0x23299e (48 bytes)
0023299e  4055                     push rbp
002329a0  4883ec20                 sub rsp, 0x20
002329a4  488bea                   mov rbp, rdx
002329a7  4c8b85f0000000           mov r8, qword ptr [rbp + 0xf0]
002329ae  4981c030200000           add r8, 0x2030
002329b5  4d8b00                   mov r8, qword ptr [r8]
002329b8  488b5578                 mov rdx, qword ptr [rbp + 0x78]
002329bc  488b8d80000000           mov rcx, qword ptr [rbp + 0x80]
002329c3  e848e6dcff               call 0x1010
002329c8  4883c420                 add rsp, 0x20
002329cc  5d                       pop rbp
002329cd  c3                       ret
