; CMemAligned<CMemDbg<CMemObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xd05c0, 79 bytes in 1 chunk(s)

; chunk at RVA 0xd05c0 (79 bytes)
000d05c0  48894c2408               mov qword ptr [rsp + 8], rcx
000d05c5  57                       push rdi
000d05c6  4883ec30                 sub rsp, 0x30
000d05ca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d05d3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d05d8  8bda                     mov ebx, edx
000d05da  488bf9                   mov rdi, rcx
000d05dd  488d054cb11700           lea rax, [rip + 0x17b14c]
000d05e4  488901                   mov qword ptr [rcx], rax
000d05e7  e8f4df0900               call 0x16e5e0
000d05ec  83e305                   and ebx, 5
000d05ef  80fb05                   cmp bl, 5
000d05f2  750d                     jne 0xd0601
000d05f4  ba00050000               mov edx, 0x500
000d05f9  488bcf                   mov rcx, rdi
000d05fc  e80f0af3ff               call 0x1010
000d0601  488bc7                   mov rax, rdi
000d0604  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d0609  4883c430                 add rsp, 0x30
000d060d  5f                       pop rdi
000d060e  c3                       ret
