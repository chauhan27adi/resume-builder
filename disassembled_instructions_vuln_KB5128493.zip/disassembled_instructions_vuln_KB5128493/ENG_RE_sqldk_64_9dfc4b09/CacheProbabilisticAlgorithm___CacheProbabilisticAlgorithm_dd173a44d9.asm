; CacheProbabilisticAlgorithm::~CacheProbabilisticAlgorithm
; sqldk.dll, primary RVA 0x180ae0, 34 bytes in 1 chunk(s)

; chunk at RVA 0x180ae0 (34 bytes)
00180ae0  48894c2408               mov qword ptr [rsp + 8], rcx
00180ae5  4883ec38                 sub rsp, 0x38
00180ae9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00180af2  4881c188b10000           add rcx, 0xb188
00180af9  4883c438                 add rsp, 0x38
00180afd  e9fe5cfeff               jmp 0x166800
