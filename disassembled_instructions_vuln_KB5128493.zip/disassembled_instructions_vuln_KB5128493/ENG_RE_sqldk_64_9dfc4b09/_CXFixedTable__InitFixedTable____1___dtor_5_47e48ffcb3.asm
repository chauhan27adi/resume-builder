; `CXFixedTable::InitFixedTable'::`1'::dtor$5
; sqldk.dll, primary RVA 0x216d24, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216d24 (31 bytes)
00216d24  4055                     push rbp
00216d26  4883ec20                 sub rsp, 0x20
00216d2a  488bea                   mov rbp, rdx
00216d2d  4533c0                   xor r8d, r8d
00216d30  488b5538                 mov rdx, qword ptr [rbp + 0x38]
00216d34  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00216d38  e8d3a2deff               call 0x1010
00216d3d  4883c420                 add rsp, 0x20
00216d41  5d                       pop rbp
00216d42  c3                       ret
