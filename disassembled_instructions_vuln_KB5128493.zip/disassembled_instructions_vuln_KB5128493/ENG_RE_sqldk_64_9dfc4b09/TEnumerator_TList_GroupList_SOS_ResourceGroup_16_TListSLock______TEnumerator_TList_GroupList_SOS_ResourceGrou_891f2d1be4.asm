; TEnumerator<TList<GroupList,SOS_ResourceGroup,16,TListSLock> >::~TEnumerator<TList<GroupList,SOS_ResourceGroup,16,TListSLock> >
; sqldk.dll, primary RVA 0x1a5560, 203 bytes in 1 chunk(s)

; chunk at RVA 0x1a5560 (203 bytes)
001a5560  48895c2410               mov qword ptr [rsp + 0x10], rbx
001a5565  48896c2418               mov qword ptr [rsp + 0x18], rbp
001a556a  4889742420               mov qword ptr [rsp + 0x20], rsi
001a556f  57                       push rdi
001a5570  4883ec20                 sub rsp, 0x20
001a5574  488b39                   mov rdi, qword ptr [rcx]
001a5577  33ed                     xor ebp, ebp
001a5579  488bd9                   mov rbx, rcx
001a557c  beffffffff               mov esi, 0xffffffff
001a5581  4885ff                   test rdi, rdi
001a5584  7436                     je 0x1a55bc
001a5586  8bc6                     mov eax, esi
001a5588  f00fc14728               lock xadd dword ptr [rdi + 0x28], eax
001a558d  83f801                   cmp eax, 1
001a5590  7527                     jne 0x1a55b9
001a5592  48396f18                 cmp qword ptr [rdi + 0x18], rbp
001a5596  740c                     je 0x1a55a4
001a5598  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
001a559c  488bd7                   mov rdx, rdi
001a559f  e84cade6ff               call 0x102f0
001a55a4  488bcf                   mov rcx, rdi
001a55a7  e844cfffff               call 0x1a24f0
001a55ac  ba880d0000               mov edx, 0xd88
001a55b1  488bcf                   mov rcx, rdi
001a55b4  e83728e6ff               call 0x7df0
001a55b9  48892b                   mov qword ptr [rbx], rbp
001a55bc  488b7b08                 mov rdi, qword ptr [rbx + 8]
001a55c0  4885ff                   test rdi, rdi
001a55c3  7435                     je 0x1a55fa
001a55c5  f00fc17728               lock xadd dword ptr [rdi + 0x28], esi
001a55ca  83fe01                   cmp esi, 1
001a55cd  7527                     jne 0x1a55f6
001a55cf  48396f18                 cmp qword ptr [rdi + 0x18], rbp
001a55d3  740c                     je 0x1a55e1
001a55d5  488b4f20                 mov rcx, qword ptr [rdi + 0x20]
001a55d9  488bd7                   mov rdx, rdi
001a55dc  e80fade6ff               call 0x102f0
001a55e1  488bcf                   mov rcx, rdi
001a55e4  e807cfffff               call 0x1a24f0
001a55e9  ba880d0000               mov edx, 0xd88
001a55ee  488bcf                   mov rcx, rdi
001a55f1  e8fa27e6ff               call 0x7df0
001a55f6  48896b08                 mov qword ptr [rbx + 8], rbp
001a55fa  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001a55fe  4885c9                   test rcx, rcx
001a5601  740f                     je 0x1a5612
001a5603  8b5320                   mov edx, dword ptr [rbx + 0x20]
001a5606  e84506e6ff               call 0x5c50
001a560b  48896b18                 mov qword ptr [rbx + 0x18], rbp
001a560f  896b20                   mov dword ptr [rbx + 0x20], ebp
001a5612  488b742448               mov rsi, qword ptr [rsp + 0x48]
001a5617  48896b10                 mov qword ptr [rbx + 0x10], rbp
001a561b  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
001a5620  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
001a5625  4883c420                 add rsp, 0x20
001a5629  5f                       pop rdi
001a562a  c3                       ret
