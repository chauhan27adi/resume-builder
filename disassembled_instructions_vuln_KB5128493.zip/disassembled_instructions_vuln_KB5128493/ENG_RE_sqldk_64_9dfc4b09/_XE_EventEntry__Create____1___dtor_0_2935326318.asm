; `XE_EventEntry::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2359c0, 59 bytes in 1 chunk(s)

; chunk at RVA 0x2359c0 (59 bytes)
002359c0  4055                     push rbp
002359c2  4883ec30                 sub rsp, 0x30
002359c6  488bea                   mov rbp, rdx
002359c9  c644242806               mov byte ptr [rsp + 0x28], 6
002359ce  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
002359d4  89442420                 mov dword ptr [rsp + 0x20], eax
002359d8  4c8d0d894f0700           lea r9, [rip + 0x74f89]
002359df  41b801000000             mov r8d, 1
002359e5  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
002359ec  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
002359f0  e8cb44faff               call 0x1d9ec0
002359f5  4883c430                 add rsp, 0x30
002359f9  5d                       pop rbp
002359fa  c3                       ret
