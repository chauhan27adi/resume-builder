; CMemDetour<CMemThread<CMemLargePageObj> >::~CMemDetour<CMemThread<CMemLargePageObj> >
; sqldk.dll, primary RVA 0x11af70, 59 bytes in 1 chunk(s)

; chunk at RVA 0x11af70 (59 bytes)
0011af70  48894c2408               mov qword ptr [rsp + 8], rcx
0011af75  4883ec38                 sub rsp, 0x38
0011af79  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0011af82  488d051f1d1300           lea rax, [rip + 0x131d1f]
0011af89  488901                   mov qword ptr [rcx], rax
0011af8c  488d81e0020000           lea rax, [rcx + 0x2e0]
0011af93  4889442448               mov qword ptr [rsp + 0x48], rax
0011af98  488d15a1eb1100           lea rdx, [rip + 0x11eba1]
0011af9f  488910                   mov qword ptr [rax], rdx
0011afa2  4883c438                 add rsp, 0x38
0011afa6  e98587ffff               jmp 0x113730
