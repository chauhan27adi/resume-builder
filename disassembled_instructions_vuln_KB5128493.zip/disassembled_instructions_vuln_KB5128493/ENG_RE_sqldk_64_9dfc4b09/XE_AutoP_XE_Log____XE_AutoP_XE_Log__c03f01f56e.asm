; XE_AutoP<XE_Log>::~XE_AutoP<XE_Log>
; sqldk.dll, primary RVA 0x47710, 50 bytes in 1 chunk(s)

; chunk at RVA 0x47710 (50 bytes)
00047710  48894c2408               mov qword ptr [rsp + 8], rcx
00047715  53                       push rbx
00047716  4883ec30                 sub rsp, 0x30
0004771a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00047723  488bd9                   mov rbx, rcx
00047726  488b09                   mov rcx, qword ptr [rcx]
00047729  e852150000               call 0x48c80
0004772e  48c70300000000           mov qword ptr [rbx], 0
00047735  488bcb                   mov rcx, rbx
00047738  4883c430                 add rsp, 0x30
0004773c  5b                       pop rbx
0004773d  e99e120000               jmp 0x489e0
