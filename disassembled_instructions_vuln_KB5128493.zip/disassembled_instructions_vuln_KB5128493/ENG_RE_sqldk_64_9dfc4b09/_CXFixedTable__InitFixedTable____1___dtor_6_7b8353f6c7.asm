; `CXFixedTable::InitFixedTable'::`1'::dtor$6
; sqldk.dll, primary RVA 0x216d49, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216d49 (31 bytes)
00216d49  4055                     push rbp
00216d4b  4883ec20                 sub rsp, 0x20
00216d4f  488bea                   mov rbp, rdx
00216d52  4533c0                   xor r8d, r8d
00216d55  488b5528                 mov rdx, qword ptr [rbp + 0x28]
00216d59  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
00216d5d  e8aea2deff               call 0x1010
00216d62  4883c420                 add rsp, 0x20
00216d66  5d                       pop rbp
00216d67  c3                       ret
