; SOS_MemoryNodeEnum::~SOS_MemoryNodeEnum
; sqldk.dll, primary RVA 0x9e280, 165 bytes in 1 chunk(s)

; chunk at RVA 0x9e280 (165 bytes)
0009e280  48894c2408               mov qword ptr [rsp + 8], rcx
0009e285  57                       push rdi
0009e286  4883ec30                 sub rsp, 0x30
0009e28a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0009e293  48895c2448               mov qword ptr [rsp + 0x48], rbx
0009e298  4889742450               mov qword ptr [rsp + 0x50], rsi
0009e29d  488bd9                   mov rbx, rcx
0009e2a0  488b09                   mov rcx, qword ptr [rcx]
0009e2a3  bfffffffff               mov edi, 0xffffffff
0009e2a8  33f6                     xor esi, esi
0009e2aa  4885c9                   test rcx, rcx
0009e2ad  7421                     je 0x9e2d0
0009e2af  8bc7                     mov eax, edi
0009e2b1  f00fc14118               lock xadd dword ptr [rcx + 0x18], eax
0009e2b6  83f801                   cmp eax, 1
0009e2b9  7512                     jne 0x9e2cd
0009e2bb  48397108                 cmp qword ptr [rcx + 8], rsi
0009e2bf  740c                     je 0x9e2cd
0009e2c1  488bd1                   mov rdx, rcx
0009e2c4  488b4910                 mov rcx, qword ptr [rcx + 0x10]
0009e2c8  e8733df7ff               call 0x12040
0009e2cd  488933                   mov qword ptr [rbx], rsi
0009e2d0  488b4b08                 mov rcx, qword ptr [rbx + 8]
0009e2d4  4885c9                   test rcx, rcx
0009e2d7  7420                     je 0x9e2f9
0009e2d9  f00fc17918               lock xadd dword ptr [rcx + 0x18], edi
0009e2de  83ff01                   cmp edi, 1
0009e2e1  7512                     jne 0x9e2f5
0009e2e3  48397108                 cmp qword ptr [rcx + 8], rsi
0009e2e7  740c                     je 0x9e2f5
0009e2e9  488bd1                   mov rdx, rcx
0009e2ec  488b4910                 mov rcx, qword ptr [rcx + 0x10]
0009e2f0  e84b3df7ff               call 0x12040
0009e2f5  48897308                 mov qword ptr [rbx + 8], rsi
0009e2f9  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0009e2fd  4885c9                   test rcx, rcx
0009e300  740f                     je 0x9e311
0009e302  8b5320                   mov edx, dword ptr [rbx + 0x20]
0009e305  e84679f6ff               call 0x5c50
0009e30a  48897318                 mov qword ptr [rbx + 0x18], rsi
0009e30e  897320                   mov dword ptr [rbx + 0x20], esi
0009e311  48897310                 mov qword ptr [rbx + 0x10], rsi
0009e315  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0009e31a  488b742450               mov rsi, qword ptr [rsp + 0x50]
0009e31f  4883c430                 add rsp, 0x30
0009e323  5f                       pop rdi
0009e324  c3                       ret
