; `SOS_Node::CreateMultipleTasksInternal'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21d4b0, 66 bytes in 1 chunk(s)

; chunk at RVA 0x21d4b0 (66 bytes)
0021d4b0  4055                     push rbp
0021d4b2  4883ec30                 sub rsp, 0x30
0021d4b6  488bea                   mov rbp, rdx
0021d4b9  488b5578                 mov rdx, qword ptr [rbp + 0x78]
0021d4bd  4881c2780e0000           add rdx, 0xe78
0021d4c4  c644242806               mov byte ptr [rsp + 0x28], 6
0021d4c9  8b4560                   mov eax, dword ptr [rbp + 0x60]
0021d4cc  89442420                 mov dword ptr [rsp + 0x20], eax
0021d4d0  4c8d0d79860400           lea r9, [rip + 0x48679]
0021d4d7  41b801000000             mov r8d, 1
0021d4dd  488b12                   mov rdx, qword ptr [rdx]
0021d4e0  488b8dc8000000           mov rcx, qword ptr [rbp + 0xc8]
0021d4e7  e8b4a8deff               call 0x7da0
0021d4ec  4883c430                 add rsp, 0x30
0021d4f0  5d                       pop rbp
0021d4f1  c3                       ret
