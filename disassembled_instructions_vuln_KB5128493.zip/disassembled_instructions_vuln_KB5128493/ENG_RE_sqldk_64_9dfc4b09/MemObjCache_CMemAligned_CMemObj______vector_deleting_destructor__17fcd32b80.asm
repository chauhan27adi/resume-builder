; MemObjCache<CMemAligned<CMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13eff0, 131 bytes in 1 chunk(s)

; chunk at RVA 0x13eff0 (131 bytes)
0013eff0  48894c2408               mov qword ptr [rsp + 8], rcx
0013eff5  57                       push rdi
0013eff6  4883ec30                 sub rsp, 0x30
0013effa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013f003  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013f008  8bda                     mov ebx, edx
0013f00a  488bf9                   mov rdi, rcx
0013f00d  488d05f4871000           lea rax, [rip + 0x1087f4]
0013f014  488901                   mov qword ptr [rcx], rax
0013f017  488d056ac81000           lea rax, [rip + 0x10c86a]
0013f01e  488901                   mov qword ptr [rcx], rax
0013f021  488d05407f1000           lea rax, [rip + 0x107f40]
0013f028  488901                   mov qword ptr [rcx], rax
0013f02b  488d05d6811000           lea rax, [rip + 0x1081d6]
0013f032  488901                   mov qword ptr [rcx], rax
0013f035  4883c138                 add rcx, 0x38
0013f039  e8b231edff               call 0x121f0
0013f03e  90                       nop
0013f03f  488d4f30                 lea rcx, [rdi + 0x30]
0013f043  e8a831edff               call 0x121f0
0013f048  90                       nop
0013f049  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013f050  83e305                   and ebx, 5
0013f053  80fb05                   cmp bl, 5
0013f056  750d                     jne 0x13f065
0013f058  ba80010000               mov edx, 0x180
0013f05d  488bcf                   mov rcx, rdi
0013f060  e8ab1fecff               call 0x1010
0013f065  488bc7                   mov rax, rdi
0013f068  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013f06d  4883c430                 add rsp, 0x30
0013f071  5f                       pop rdi
0013f072  c3                       ret
