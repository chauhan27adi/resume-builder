; CMemPartitioned<CMemThread<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce630, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce630 (104 bytes)
000ce630  48894c2408               mov qword ptr [rsp + 8], rcx
000ce635  57                       push rdi
000ce636  4883ec30                 sub rsp, 0x30
000ce63a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce643  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce648  8bda                     mov ebx, edx
000ce64a  488bf9                   mov rdi, rcx
000ce64d  488d0504ed1700           lea rax, [rip + 0x17ed04]
000ce654  488901                   mov qword ptr [rcx], rax
000ce657  488d8170020000           lea rax, [rcx + 0x270]
000ce65e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce663  488d0dd6b41600           lea rcx, [rip + 0x16b4d6]
000ce66a  488908                   mov qword ptr [rax], rcx
000ce66d  488bcf                   mov rcx, rdi
000ce670  e8dbdf0200               call 0xfc650
000ce675  83e305                   and ebx, 5
000ce678  80fb05                   cmp bl, 5
000ce67b  750d                     jne 0xce68a
000ce67d  baa8020000               mov edx, 0x2a8
000ce682  488bcf                   mov rcx, rdi
000ce685  e88629f3ff               call 0x1010
000ce68a  488bc7                   mov rax, rdi
000ce68d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce692  4883c430                 add rsp, 0x30
000ce696  5f                       pop rdi
000ce697  c3                       ret
