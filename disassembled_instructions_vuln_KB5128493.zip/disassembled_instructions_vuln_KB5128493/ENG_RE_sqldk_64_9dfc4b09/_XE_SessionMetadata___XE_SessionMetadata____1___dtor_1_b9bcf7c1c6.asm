; `XE_SessionMetadata::~XE_SessionMetadata'::`1'::dtor$1
; sqldk.dll, primary RVA 0x216660, 42 bytes in 1 chunk(s)

; chunk at RVA 0x216660 (42 bytes)
00216660  4055                     push rbp
00216662  4883ec20                 sub rsp, 0x20
00216666  488bea                   mov rbp, rdx
00216669  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0021666d  4c8d0d7c12e3ff           lea r9, [rip - 0x1ced84]
00216674  41b800040000             mov r8d, 0x400
0021667a  ba08000000               mov edx, 8
0021667f  e8dc85e1ff               call 0x2ec60
00216684  4883c420                 add rsp, 0x20
00216688  5d                       pop rbp
00216689  c3                       ret
