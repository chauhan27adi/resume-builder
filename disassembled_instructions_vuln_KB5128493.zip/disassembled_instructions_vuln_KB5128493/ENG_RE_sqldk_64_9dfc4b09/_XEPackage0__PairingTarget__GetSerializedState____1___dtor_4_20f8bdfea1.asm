; `XEPackage0::PairingTarget::GetSerializedState'::`1'::dtor$4
; sqldk.dll, primary RVA 0x231091, 31 bytes in 1 chunk(s)

; chunk at RVA 0x231091 (31 bytes)
00231091  4055                     push rbp
00231093  4883ec20                 sub rsp, 0x20
00231097  488bea                   mov rbp, rdx
0023109a  4533c0                   xor r8d, r8d
0023109d  488b5560                 mov rdx, qword ptr [rbp + 0x60]
002310a1  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
002310a5  e866ffdcff               call 0x1010
002310aa  4883c420                 add rsp, 0x20
002310ae  5d                       pop rbp
002310af  c3                       ret
