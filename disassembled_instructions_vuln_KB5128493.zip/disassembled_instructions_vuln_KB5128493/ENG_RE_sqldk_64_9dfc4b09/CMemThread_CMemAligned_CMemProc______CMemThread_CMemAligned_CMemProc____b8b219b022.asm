; CMemThread<CMemAligned<CMemProc> >::~CMemThread<CMemAligned<CMemProc> >
; sqldk.dll, primary RVA 0xc60b0, 121 bytes in 1 chunk(s)

; chunk at RVA 0xc60b0 (121 bytes)
000c60b0  48894c2408               mov qword ptr [rsp + 8], rcx
000c60b5  53                       push rbx
000c60b6  4883ec30                 sub rsp, 0x30
000c60ba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000c60c3  488bd9                   mov rbx, rcx
000c60c6  488d0563911800           lea rax, [rip + 0x189163]
000c60cd  488901                   mov qword ptr [rcx], rax
000c60d0  488d81a8000000           lea rax, [rcx + 0xa8]
000c60d7  4889442448               mov qword ptr [rsp + 0x48], rax
000c60dc  488d0d5d3a1700           lea rcx, [rip + 0x173a5d]
000c60e3  48894830                 mov qword ptr [rax + 0x30], rcx
000c60e7  488908                   mov qword ptr [rax], rcx
000c60ea  488d05e78f1800           lea rax, [rip + 0x188fe7]
000c60f1  488903                   mov qword ptr [rbx], rax
000c60f4  488d055d121800           lea rax, [rip + 0x18125d]
000c60fb  488903                   mov qword ptr [rbx], rax
000c60fe  488d0503111800           lea rax, [rip + 0x181103]
000c6105  488903                   mov qword ptr [rbx], rax
000c6108  488d4b38                 lea rcx, [rbx + 0x38]
000c610c  e8dfc0f4ff               call 0x121f0
000c6111  90                       nop
000c6112  488d4b30                 lea rcx, [rbx + 0x30]
000c6116  e8d5c0f4ff               call 0x121f0
000c611b  90                       nop
000c611c  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
000c6123  4883c430                 add rsp, 0x30
000c6127  5b                       pop rbx
000c6128  c3                       ret
