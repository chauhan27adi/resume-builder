; CGlobalTraceFlags::TurnOff
; sqldk.dll, primary RVA 0x1b4370, 576 bytes in 4 chunk(s)

; chunk at RVA 0x1b4370 (149 bytes)
001b4370  4053                     push rbx
001b4372  55                       push rbp
001b4373  57                       push rdi
001b4374  4883ec30                 sub rsp, 0x30
001b4378  0fb7e9                   movzx ebp, cx
001b437b  b9aa3f0000               mov ecx, 0x3faa
001b4380  8d45ff                   lea eax, [rbp - 1]
001b4383  663bc1                   cmp ax, cx
001b4386  0f871b020000             ja 0x1b45a7
001b438c  0faee8                   lfence
001b438f  83fa02                   cmp edx, 2
001b4392  7569                     jne 0x1b43fd
001b4394  0fb7cd                   movzx ecx, bp
001b4397  e8a40d0000               call 0x1b5140
001b439c  488bd8                   mov rbx, rax
001b439f  4885c0                   test rax, rax
001b43a2  741f                     je 0x1b43c3
001b43a4  488b0d4ddc1700           mov rcx, qword ptr [rip + 0x17dc4d]
001b43ab  488b11                   mov rdx, qword ptr [rcx]
001b43ae  ff12                     call qword ptr [rdx]
001b43b0  f680c301000004           test byte ptr [rax + 0x1c3], 4
001b43b7  750a                     jne 0x1b43c3
001b43b9  837b0c00                 cmp dword ptr [rbx + 0xc], 0
001b43bd  0f84e4010000             je 0x1b45a7
001b43c3  8bcd                     mov ecx, ebp
001b43c5  e806f9fcff               call 0x183cd0
001b43ca  488b0d27dc1700           mov rcx, qword ptr [rip + 0x17dc27]
001b43d1  4533c9                   xor r9d, r9d
001b43d4  8bd5                     mov edx, ebp
001b43d6  488b01                   mov rax, qword ptr [rcx]
001b43d9  458d4101                 lea r8d, [r9 + 1]
001b43dd  ff5010                   call qword ptr [rax + 0x10]
001b43e0  488b1d99762000           mov rbx, qword ptr [rip + 0x207699]
001b43e7  4885db                   test rbx, rbx
001b43ea  7411                     je 0x1b43fd
001b43ec  0f1f00                   nop dword ptr [rax]
001b43ef  90                       nop
001b43f0  8bcd                     mov ecx, ebp
001b43f2  ff5308                   call qword ptr [rbx + 8]
001b43f5  488b1b                   mov rbx, qword ptr [rbx]
001b43f8  4885db                   test rbx, rbx
001b43fb  75f3                     jne 0x1b43f0
001b43fd  658b042548000000         mov eax, dword ptr gs:[0x48]

; chunk at RVA 0x1b4405 (299 bytes)
001b4405  4889742450               mov qword ptr [rsp + 0x50], rsi
001b440a  4c89742458               mov qword ptr [rsp + 0x58], r14
001b440f  4533f6                   xor r14d, r14d
001b4412  8bf0                     mov esi, eax
001b4414  418bde                   mov ebx, r14d
001b4417  8b05cb6b2000             mov eax, dword ptr [rip + 0x206bcb]
001b441d  85c0                     test eax, eax
001b441f  7519                     jne 0x1b443a
001b4421  33c0                     xor eax, eax
001b4423  f0480fb135bc6b2000       lock cmpxchg qword ptr [rip + 0x206bbc], rsi
001b442c  418bc6                   mov eax, r14d
001b442f  0f94c0                   sete al
001b4432  85c0                     test eax, eax
001b4434  0f85c5000000             jne 0x1b44ff
001b443a  8b05b8061600             mov eax, dword ptr [rip + 0x1606b8]
001b4440  498bfe                   mov rdi, r14
001b4443  2584000000               and eax, 0x84
001b4448  3c84                     cmp al, 0x84
001b444a  7552                     jne 0x1b449e
001b444c  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
001b4455  8b05750b1600             mov eax, dword ptr [rip + 0x160b75]
001b445b  8b1557d4e4ff             mov edx, dword ptr [rip - 0x1b2ba9]
001b4461  480314c1                 add rdx, qword ptr [rcx + rax*8]
001b4465  7410                     je 0x1b4477
001b4467  48399210010000           cmp qword ptr [rdx + 0x110], rdx
001b446e  7507                     jne 0x1b4477
001b4470  488bba00010000           mov rdi, qword ptr [rdx + 0x100]
001b4477  4885ff                   test rdi, rdi
001b447a  7422                     je 0x1b449e
001b447c  391d42101600             cmp dword ptr [rip + 0x161042], ebx
001b4482  7412                     je 0x1b4496
001b4484  488d4c2460               lea rcx, [rsp + 0x60]
001b4489  ff1541500800             call qword ptr [rip + 0x85041]
001b448f  488b5c2460               mov rbx, qword ptr [rsp + 0x60]
001b4494  eb08                     jmp 0x1b449e
001b4496  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
001b449e  f6053206160080           test byte ptr [rip + 0x160632], 0x80
001b44a5  488d0d3c6b2000           lea rcx, [rip + 0x206b3c]
001b44ac  740d                     je 0x1b44bb
001b44ae  4c8bc6                   mov r8, rsi
001b44b1  488bd7                   mov rdx, rdi
001b44b4  e837070000               call 0x1b4bf0
001b44b9  eb08                     jmp 0x1b44c3
001b44bb  488bd6                   mov rdx, rsi
001b44be  e82d090000               call 0x1b4df0
001b44c3  4885ff                   test rdi, rdi
001b44c6  7437                     je 0x1b44ff
001b44c8  443935f50f1600           cmp dword ptr [rip + 0x160ff5], r14d
001b44cf  7412                     je 0x1b44e3
001b44d1  488d4c2468               lea rcx, [rsp + 0x68]
001b44d6  ff15f44f0800             call qword ptr [rip + 0x84ff4]
001b44dc  488b442468               mov rax, qword ptr [rsp + 0x68]
001b44e1  eb08                     jmp 0x1b44eb
001b44e3  488b04250800fe7f         mov rax, qword ptr [0x7ffe0008]
001b44eb  488bc8                   mov rcx, rax
001b44ee  482bcb                   sub rcx, rbx
001b44f1  483bc3                   cmp rax, rbx
001b44f4  490f42ce                 cmovb rcx, r14
001b44f8  48018f780c0000           add qword ptr [rdi + 0xc78], rcx
001b44ff  488b0df2da1700           mov rcx, qword ptr [rip + 0x17daf2]
001b4506  488b01                   mov rax, qword ptr [rcx]
001b4509  ff10                     call qword ptr [rax]
001b450b  488b742450               mov rsi, qword ptr [rsp + 0x50]
001b4510  488bcd                   mov rcx, rbp
001b4513  48c1e903                 shr rcx, 3
001b4517  4803c1                   add rax, rcx
001b451a  8bcd                     mov ecx, ebp
001b451c  83e107                   and ecx, 7
001b451f  0fb610                   movzx edx, byte ptr [rax]
001b4522  0fb3ca                   btr edx, ecx
001b4525  8810                     mov byte ptr [rax], dl
001b4527  443835930f1600           cmp byte ptr [rip + 0x160f93], r14b
001b452e  7427                     je 0x1b4557

; chunk at RVA 0x1b4530 (95 bytes)
001b4530  ff1512550800             call qword ptr [rip + 0x85512]
001b4536  448bc8                   mov r9d, eax
001b4539  b867666666               mov eax, 0x66666667
001b453e  41f7e9                   imul r9d
001b4541  d1fa                     sar edx, 1
001b4543  8bca                     mov ecx, edx
001b4545  c1e91f                   shr ecx, 0x1f
001b4548  03d1                     add edx, ecx
001b454a  8d0c92                   lea ecx, [rdx + rdx*4]
001b454d  443bc9                   cmp r9d, ecx
001b4550  7505                     jne 0x1b4557
001b4552  e8c90a0000               call 0x1b5020
001b4557  8bcd                     mov ecx, ebp
001b4559  4c8935886a2000           mov qword ptr [rip + 0x206a88], r14
001b4560  e86bf7fcff               call 0x183cd0
001b4565  488b0d8cda1700           mov rcx, qword ptr [rip + 0x17da8c]
001b456c  4533c9                   xor r9d, r9d
001b456f  8bd5                     mov edx, ebp
001b4571  488b01                   mov rax, qword ptr [rcx]
001b4574  458d4101                 lea r8d, [r9 + 1]
001b4578  ff5010                   call qword ptr [rax + 0x10]
001b457b  488b1dfe742000           mov rbx, qword ptr [rip + 0x2074fe]
001b4582  4c8b742458               mov r14, qword ptr [rsp + 0x58]
001b4587  4885db                   test rbx, rbx
001b458a  7411                     je 0x1b459d
001b458c  0f1f00                   nop dword ptr [rax]

; chunk at RVA 0x1b4590 (33 bytes)
001b4590  8bcd                     mov ecx, ebp
001b4592  ff5308                   call qword ptr [rbx + 8]
001b4595  488b1b                   mov rbx, qword ptr [rbx]
001b4598  4885db                   test rbx, rbx
001b459b  75f3                     jne 0x1b4590
001b459d  b001                     mov al, 1
001b459f  4883c430                 add rsp, 0x30
001b45a3  5f                       pop rdi
001b45a4  5d                       pop rbp
001b45a5  5b                       pop rbx
001b45a6  c3                       ret
001b45a7  32c0                     xor al, al
001b45a9  4883c430                 add rsp, 0x30
001b45ad  5f                       pop rdi
001b45ae  5d                       pop rbp
001b45af  5b                       pop rbx
001b45b0  c3                       ret
