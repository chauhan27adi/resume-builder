; `SOS_RingBuffer::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22db90, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22db90 (59 bytes)
0022db90  4055                     push rbp
0022db92  4883ec30                 sub rsp, 0x30
0022db96  488bea                   mov rbp, rdx
0022db99  c644242806               mov byte ptr [rsp + 0x28], 6
0022db9e  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022dba4  89442420                 mov dword ptr [rsp + 0x20], eax
0022dba8  4c8d0df9cc0600           lea r9, [rip + 0x6ccf9]
0022dbaf  41b801000000             mov r8d, 1
0022dbb5  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
0022dbbc  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022dbc0  e8dba1ddff               call 0x7da0
0022dbc5  4883c430                 add rsp, 0x30
0022dbc9  5d                       pop rbp
0022dbca  c3                       ret
