; CAutoRg<EventTypeEntry>::~CAutoRg<EventTypeEntry>
; sqldk.dll, primary RVA 0x4de40, 84 bytes in 3 chunk(s)

; chunk at RVA 0x4de40 (23 bytes)
0004de40  4883ec28                 sub rsp, 0x28
0004de44  488b09                   mov rcx, qword ptr [rcx]
0004de47  4885c9                   test rcx, rcx
0004de4a  7444                     je 0x4de90
0004de4c  4c8b41f8                 mov r8, qword ptr [rcx - 8]
0004de50  4c8d0d99f8ffff           lea r9, [rip - 0x767]

; chunk at RVA 0x4de57 (51 bytes)
0004de57  48895c2420               mov qword ptr [rsp + 0x20], rbx
0004de5c  ba18000000               mov edx, 0x18
0004de61  488d59f8                 lea rbx, [rcx - 8]
0004de65  e8f60dfeff               call 0x2ec60
0004de6a  488b03                   mov rax, qword ptr [rbx]
0004de6d  488bcb                   mov rcx, rbx
0004de70  488d1440                 lea rdx, [rax + rax*2]
0004de74  488d14d508000000         lea rdx, [rdx*8 + 8]
0004de7c  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0004de81  4883c428                 add rsp, 0x28
0004de85  e9669ffbff               jmp 0x7df0

; chunk at RVA 0x4de8b (10 bytes)
0004de8b  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0004de90  4883c428                 add rsp, 0x28
0004de94  c3                       ret
