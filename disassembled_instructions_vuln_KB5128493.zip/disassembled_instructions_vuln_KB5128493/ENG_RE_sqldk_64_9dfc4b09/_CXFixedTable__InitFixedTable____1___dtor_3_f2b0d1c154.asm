; `CXFixedTable::InitFixedTable'::`1'::dtor$3
; sqldk.dll, primary RVA 0x216cd8, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216cd8 (31 bytes)
00216cd8  4055                     push rbp
00216cda  4883ec20                 sub rsp, 0x20
00216cde  488bea                   mov rbp, rdx
00216ce1  4533c0                   xor r8d, r8d
00216ce4  488b5558                 mov rdx, qword ptr [rbp + 0x58]
00216ce8  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
00216cec  e81fa3deff               call 0x1010
00216cf1  4883c420                 add rsp, 0x20
00216cf5  5d                       pop rbp
00216cf6  c3                       ret
