; `XE_ModuleManager::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x235731, 62 bytes in 1 chunk(s)

; chunk at RVA 0x235731 (62 bytes)
00235731  4055                     push rbp
00235733  4883ec30                 sub rsp, 0x30
00235737  488bea                   mov rbp, rdx
0023573a  c644242806               mov byte ptr [rsp + 0x28], 6
0023573f  8b8588000000             mov eax, dword ptr [rbp + 0x88]
00235745  89442420                 mov dword ptr [rsp + 0x20], eax
00235749  4c8d0df0510700           lea r9, [rip + 0x751f0]
00235750  41b801000000             mov r8d, 1
00235756  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0023575d  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
00235764  e85747faff               call 0x1d9ec0
00235769  4883c430                 add rsp, 0x30
0023576d  5d                       pop rbp
0023576e  c3                       ret
