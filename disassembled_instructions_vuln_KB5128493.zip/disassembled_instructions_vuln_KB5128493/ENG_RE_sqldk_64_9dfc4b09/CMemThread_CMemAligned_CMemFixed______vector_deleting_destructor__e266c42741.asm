; CMemThread<CMemAligned<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e430, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13e430 (55 bytes)
0013e430  48895c2408               mov qword ptr [rsp + 8], rbx
0013e435  57                       push rdi
0013e436  4883ec20                 sub rsp, 0x20
0013e43a  8bda                     mov ebx, edx
0013e43c  488bf9                   mov rdi, rcx
0013e43f  e82c24fcff               call 0x100870
0013e444  83e305                   and ebx, 5
0013e447  80fb05                   cmp bl, 5
0013e44a  750d                     jne 0x13e459
0013e44c  bae8010000               mov edx, 0x1e8
0013e451  488bcf                   mov rcx, rdi
0013e454  e8b72becff               call 0x1010
0013e459  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013e45e  488bc7                   mov rax, rdi
0013e461  4883c420                 add rsp, 0x20
0013e465  5f                       pop rdi
0013e466  c3                       ret
