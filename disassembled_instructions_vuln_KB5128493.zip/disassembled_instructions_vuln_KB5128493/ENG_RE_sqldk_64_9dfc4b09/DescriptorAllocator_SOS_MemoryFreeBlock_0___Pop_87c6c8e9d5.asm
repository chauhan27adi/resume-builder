; DescriptorAllocator<SOS_MemoryFreeBlock,0>::Pop
; sqldk.dll, primary RVA 0x36a80, 416 bytes in 3 chunk(s)

; chunk at RVA 0x36a80 (85 bytes)
00036a80  89542410                 mov dword ptr [rsp + 0x10], edx
00036a84  4154                     push r12
00036a86  4155                     push r13
00036a88  4156                     push r14
00036a8a  4157                     push r15
00036a8c  4881ec88000000           sub rsp, 0x88
00036a93  4c8bf1                   mov r14, rcx
00036a96  8bc2                     mov eax, edx
00036a98  0fb689cc040000           movzx ecx, byte ptr [rcx + 0x4cc]
00036a9f  4d8bf8                   mov r15, r8
00036aa2  4533c0                   xor r8d, r8d
00036aa5  48d3e0                   shl rax, cl
00036aa8  4532ed                   xor r13b, r13b
00036aab  448bd2                   mov r10d, edx
00036aae  490386c0040000           add rax, qword ptr [r14 + 0x4c0]
00036ab5  4532e4                   xor r12b, r12b
00036ab8  4889442438               mov qword ptr [rsp + 0x38], rax
00036abd  4489442458               mov dword ptr [rsp + 0x58], r8d
00036ac2  4c89442460               mov qword ptr [rsp + 0x60], r8
00036ac7  4c89442468               mov qword ptr [rsp + 0x68], r8
00036acc  4d85c9                   test r9, r9
00036acf  0f85753e0600             jne 0x9a94a

; chunk at RVA 0x36ad5 (197 bytes)
00036ad5  48899c24c0000000         mov qword ptr [rsp + 0xc0], rbx
00036add  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00036ae2  4889ac2480000000         mov qword ptr [rsp + 0x80], rbp
00036aea  4889742478               mov qword ptr [rsp + 0x78], rsi
00036aef  48897c2470               mov qword ptr [rsp + 0x70], rdi
00036af4  488b7c2450               mov rdi, qword ptr [rsp + 0x50]
00036af9  c78424b000000001000000   mov dword ptr [rsp + 0xb0], 1
00036b04  0f1f4000                 nop dword ptr [rax]
00036b08  0f1f840000000000         nop dword ptr [rax + rax]
00036b10  488b7008                 mov rsi, qword ptr [rax + 8]
00036b14  4885f6                   test rsi, rsi
00036b17  0f841b010000             je 0x36c38
00036b1d  488bce                   mov rcx, rsi
00036b20  ff15f2262000             call qword ptr [rip + 0x2026f2]
00036b26  488be8                   mov rbp, rax
00036b29  4885c0                   test rax, rax
00036b2c  0f8554050000             jne 0x37086
00036b32  4533c0                   xor r8d, r8d
00036b35  418be8                   mov ebp, r8d
00036b38  488b5618                 mov rdx, qword ptr [rsi + 0x18]
00036b3c  4885d2                   test rdx, rdx
00036b3f  743e                     je 0x36b7f
00036b41  0f1f00                   nop dword ptr [rax]
00036b44  0f1f4000                 nop dword ptr [rax]
00036b48  0f1f840000000000         nop dword ptr [rax + rax]
00036b50  498be8                   mov rbp, r8
00036b53  483bd6                   cmp rdx, rsi
00036b56  7327                     jae 0x36b7f
00036b58  0faee8                   lfence
00036b5b  488d4a40                 lea rcx, [rdx + 0x40]
00036b5f  488bc2                   mov rax, rdx
00036b62  483bce                   cmp rcx, rsi
00036b65  490f44c8                 cmove rcx, r8
00036b69  f0480fb14e18             lock cmpxchg qword ptr [rsi + 0x18], rcx
00036b6f  0f85ab000000             jne 0x36c20
00036b75  0faee8                   lfence
00036b78  f0ff4e28                 lock dec dword ptr [rsi + 0x28]
00036b7c  488bea                   mov rbp, rdx
00036b7f  4885ed                   test rbp, rbp
00036b82  0f84a8000000             je 0x36c30
00036b88  488b742478               mov rsi, qword ptr [rsp + 0x78]
00036b8d  488b9c24c0000000         mov rbx, qword ptr [rsp + 0xc0]
00036b95  4584e4                   test r12b, r12b
00036b98  7466                     je 0x36c00

; chunk at RVA 0x36b9a (134 bytes)
00036b9a  833d23e92d0000           cmp dword ptr [rip + 0x2de923], 0
00036ba1  0f842f3f0600             je 0x9aad6
00036ba7  488d4c2440               lea rcx, [rsp + 0x40]
00036bac  ff151e292000             call qword ptr [rip + 0x20291e]
00036bb2  488b4c2440               mov rcx, qword ptr [rsp + 0x40]
00036bb7  eb01                     jmp 0x36bba
00036bb9  cc                       int3
00036bba  483bcf                   cmp rcx, rdi
00036bbd  0f82293f0600             jb 0x9aaec
00036bc3  482bcf                   sub rcx, rdi
00036bc6  4883f9ff                 cmp rcx, -1
00036bca  0f84143f0600             je 0x9aae4
00036bd0  833dede82d0000           cmp dword ptr [rip + 0x2de8ed], 0
00036bd7  0f84173f0600             je 0x9aaf4
00036bdd  33d2                     xor edx, edx
00036bdf  4869c1e8030000           imul rax, rcx, 0x3e8
00036be6  48f735dbe82d00           div qword ptr [rip + 0x2de8db]
00036bed  488bd0                   mov rdx, rax
00036bf0  eb01                     jmp 0x36bf3
00036bf2  cc                       int3
00036bf3  498b4620                 mov rax, qword ptr [r14 + 0x20]
00036bf7  483bd0                   cmp rdx, rax
00036bfa  0f870b3f0600             ja 0x9ab0b
00036c00  488b7c2470               mov rdi, qword ptr [rsp + 0x70]
00036c05  488bc5                   mov rax, rbp
00036c08  488bac2480000000         mov rbp, qword ptr [rsp + 0x80]
00036c10  4881c488000000           add rsp, 0x88
00036c17  415f                     pop r15
00036c19  415e                     pop r14
00036c1b  415d                     pop r13
00036c1d  415c                     pop r12
00036c1f  c3                       ret
