; `XE_MetadataTracker::~XE_MetadataTracker'::`1'::dtor$4
; sqldk.dll, primary RVA 0x21672f, 42 bytes in 1 chunk(s)

; chunk at RVA 0x21672f (42 bytes)
0021672f  4055                     push rbp
00216731  4883ec20                 sub rsp, 0x20
00216735  488bea                   mov rbp, rdx
00216738  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
0021673c  4c8d0dad11e3ff           lea r9, [rip - 0x1cee53]
00216743  41b800040000             mov r8d, 0x400
00216749  ba08000000               mov edx, 8
0021674e  e80d85e1ff               call 0x2ec60
00216753  4883c420                 add rsp, 0x20
00216757  5d                       pop rbp
00216758  c3                       ret
