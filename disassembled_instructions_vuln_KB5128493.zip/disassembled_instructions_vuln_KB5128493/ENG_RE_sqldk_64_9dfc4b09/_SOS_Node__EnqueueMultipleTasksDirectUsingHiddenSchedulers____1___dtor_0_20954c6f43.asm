; `SOS_Node::EnqueueMultipleTasksDirectUsingHiddenSchedulers'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21d210, 69 bytes in 1 chunk(s)

; chunk at RVA 0x21d210 (69 bytes)
0021d210  4055                     push rbp
0021d212  4883ec30                 sub rsp, 0x30
0021d216  488bea                   mov rbp, rdx
0021d219  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
0021d220  4881c2780e0000           add rdx, 0xe78
0021d227  c644242806               mov byte ptr [rsp + 0x28], 6
0021d22c  8b4550                   mov eax, dword ptr [rbp + 0x50]
0021d22f  89442420                 mov dword ptr [rsp + 0x20], eax
0021d233  4c8d0d16890400           lea r9, [rip + 0x48916]
0021d23a  41b801000000             mov r8d, 1
0021d240  488b12                   mov rdx, qword ptr [rdx]
0021d243  488b8d98000000           mov rcx, qword ptr [rbp + 0x98]
0021d24a  e851abdeff               call 0x7da0
0021d24f  4883c430                 add rsp, 0x30
0021d253  5d                       pop rbp
0021d254  c3                       ret
