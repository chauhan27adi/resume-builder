; MemObjCache<CMemThread<CMemProc> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13dd80, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13dd80 (79 bytes)
0013dd80  48894c2408               mov qword ptr [rsp + 8], rcx
0013dd85  57                       push rdi
0013dd86  4883ec30                 sub rsp, 0x30
0013dd8a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013dd93  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013dd98  8bda                     mov ebx, edx
0013dd9a  488bf9                   mov rdi, rcx
0013dd9d  488d056cc91000           lea rax, [rip + 0x10c96c]
0013dda4  488901                   mov qword ptr [rcx], rax
0013dda7  e8e44ef9ff               call 0xd2c90
0013ddac  83e305                   and ebx, 5
0013ddaf  80fb05                   cmp bl, 5
0013ddb2  750d                     jne 0x13ddc1
0013ddb4  bac8010000               mov edx, 0x1c8
0013ddb9  488bcf                   mov rcx, rdi
0013ddbc  e84f32ecff               call 0x1010
0013ddc1  488bc7                   mov rax, rdi
0013ddc4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013ddc9  4883c430                 add rsp, 0x30
0013ddcd  5f                       pop rdi
0013ddce  c3                       ret
