; `XE_TCollection<0,0>::IsValid'::`1'::dtor$2
; sqldk.dll, primary RVA 0x2358c4, 34 bytes in 1 chunk(s)

; chunk at RVA 0x2358c4 (34 bytes)
002358c4  4055                     push rbp
002358c6  4883ec20                 sub rsp, 0x20
002358ca  488bea                   mov rbp, rdx
002358cd  4533c0                   xor r8d, r8d
002358d0  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
002358d7  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
002358db  e830b7dcff               call 0x1010
002358e0  4883c420                 add rsp, 0x20
002358e4  5d                       pop rbp
002358e5  c3                       ret
