; `XE_Session::CreateCollections'::`1'::dtor$6
; sqldk.dll, primary RVA 0x234cd6, 59 bytes in 1 chunk(s)

; chunk at RVA 0x234cd6 (59 bytes)
00234cd6  4055                     push rbp
00234cd8  4883ec30                 sub rsp, 0x30
00234cdc  488bea                   mov rbp, rdx
00234cdf  c644242806               mov byte ptr [rsp + 0x28], 6
00234ce4  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00234cea  89442420                 mov dword ptr [rsp + 0x20], eax
00234cee  4c8d0d835b0700           lea r9, [rip + 0x75b83]
00234cf5  41b801000000             mov r8d, 1
00234cfb  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00234d02  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00234d06  e8b551faff               call 0x1d9ec0
00234d0b  4883c430                 add rsp, 0x30
00234d0f  5d                       pop rbp
00234d10  c3                       ret
