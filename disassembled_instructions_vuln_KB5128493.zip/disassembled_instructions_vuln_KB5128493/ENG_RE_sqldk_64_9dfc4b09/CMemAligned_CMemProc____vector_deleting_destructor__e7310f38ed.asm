; CMemAligned<CMemProc>::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcd620, 121 bytes in 1 chunk(s)

; chunk at RVA 0xcd620 (121 bytes)
000cd620  48894c2408               mov qword ptr [rsp + 8], rcx
000cd625  57                       push rdi
000cd626  4883ec30                 sub rsp, 0x30
000cd62a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cd633  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cd638  8bda                     mov ebx, edx
000cd63a  488bf9                   mov rdi, rcx
000cd63d  488d05941a1800           lea rax, [rip + 0x181a94]
000cd644  488901                   mov qword ptr [rcx], rax
000cd647  488d050a9d1700           lea rax, [rip + 0x179d0a]
000cd64e  488901                   mov qword ptr [rcx], rax
000cd651  488d05b09b1700           lea rax, [rip + 0x179bb0]
000cd658  488901                   mov qword ptr [rcx], rax
000cd65b  4883c138                 add rcx, 0x38
000cd65f  e88c4bf4ff               call 0x121f0
000cd664  90                       nop
000cd665  488d4f30                 lea rcx, [rdi + 0x30]
000cd669  e8824bf4ff               call 0x121f0
000cd66e  90                       nop
000cd66f  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
000cd676  83e305                   and ebx, 5
000cd679  80fb05                   cmp bl, 5
000cd67c  750d                     jne 0xcd68b
000cd67e  baa8000000               mov edx, 0xa8
000cd683  488bcf                   mov rcx, rdi
000cd686  e88539f3ff               call 0x1010
000cd68b  488bc7                   mov rax, rdi
000cd68e  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cd693  4883c430                 add rsp, 0x30
000cd697  5f                       pop rdi
000cd698  c3                       ret
