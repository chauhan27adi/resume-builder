; MemObjCache<CMemAligned<CMemProc> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13dc30, 131 bytes in 1 chunk(s)

; chunk at RVA 0x13dc30 (131 bytes)
0013dc30  48894c2408               mov qword ptr [rsp + 8], rcx
0013dc35  57                       push rdi
0013dc36  4883ec30                 sub rsp, 0x30
0013dc3a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013dc43  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013dc48  8bda                     mov ebx, edx
0013dc4a  488bf9                   mov rdi, rcx
0013dc4d  488d0514cc1000           lea rax, [rip + 0x10cc14]
0013dc54  488901                   mov qword ptr [rcx], rax
0013dc57  488d057a141100           lea rax, [rip + 0x11147a]
0013dc5e  488901                   mov qword ptr [rcx], rax
0013dc61  488d05f0961000           lea rax, [rip + 0x1096f0]
0013dc68  488901                   mov qword ptr [rcx], rax
0013dc6b  488d0596951000           lea rax, [rip + 0x109596]
0013dc72  488901                   mov qword ptr [rcx], rax
0013dc75  4883c138                 add rcx, 0x38
0013dc79  e87245edff               call 0x121f0
0013dc7e  90                       nop
0013dc7f  488d4f30                 lea rcx, [rdi + 0x30]
0013dc83  e86845edff               call 0x121f0
0013dc88  90                       nop
0013dc89  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013dc90  83e305                   and ebx, 5
0013dc93  80fb05                   cmp bl, 5
0013dc96  750d                     jne 0x13dca5
0013dc98  baf8000000               mov edx, 0xf8
0013dc9d  488bcf                   mov rcx, rdi
0013dca0  e86b33ecff               call 0x1010
0013dca5  488bc7                   mov rax, rdi
0013dca8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013dcad  4883c430                 add rsp, 0x30
0013dcb1  5f                       pop rdi
0013dcb2  c3                       ret
