; CMemDetour<CMemThread<CMemObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xced40, 104 bytes in 1 chunk(s)

; chunk at RVA 0xced40 (104 bytes)
000ced40  48894c2408               mov qword ptr [rsp + 8], rcx
000ced45  57                       push rdi
000ced46  4883ec30                 sub rsp, 0x30
000ced4a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ced53  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ced58  8bda                     mov ebx, edx
000ced5a  488bf9                   mov rdi, rcx
000ced5d  488d058cd41700           lea rax, [rip + 0x17d48c]
000ced64  488901                   mov qword ptr [rcx], rax
000ced67  488d8140020000           lea rax, [rcx + 0x240]
000ced6e  4889442450               mov qword ptr [rsp + 0x50], rax
000ced73  488d0dc6ad1600           lea rcx, [rip + 0x16adc6]
000ced7a  488908                   mov qword ptr [rax], rcx
000ced7d  488bcf                   mov rcx, rdi
000ced80  e81bb40500               call 0x12a1a0
000ced85  83e305                   and ebx, 5
000ced88  80fb05                   cmp bl, 5
000ced8b  750d                     jne 0xced9a
000ced8d  ba78020000               mov edx, 0x278
000ced92  488bcf                   mov rcx, rdi
000ced95  e87622f3ff               call 0x1010
000ced9a  488bc7                   mov rax, rdi
000ced9d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ceda2  4883c430                 add rsp, 0x30
000ceda6  5f                       pop rdi
000ceda7  c3                       ret
