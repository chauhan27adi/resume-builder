; `SOS_Node::CreateMemoryClerk'::`1'::dtor$0
; sqldk.dll, primary RVA 0x218ad0, 56 bytes in 1 chunk(s)

; chunk at RVA 0x218ad0 (56 bytes)
00218ad0  4055                     push rbp
00218ad2  4883ec30                 sub rsp, 0x30
00218ad6  488bea                   mov rbp, rdx
00218ad9  c644242806               mov byte ptr [rsp + 0x28], 6
00218ade  8b8588000000             mov eax, dword ptr [rbp + 0x88]
00218ae4  89442420                 mov dword ptr [rsp + 0x20], eax
00218ae8  4c8d0d091a0600           lea r9, [rip + 0x61a09]
00218aef  41b801000000             mov r8d, 1
00218af5  488b5538                 mov rdx, qword ptr [rbp + 0x38]
00218af9  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00218afd  e89ef2deff               call 0x7da0
00218b02  4883c430                 add rsp, 0x30
00218b06  5d                       pop rbp
00218b07  c3                       ret
