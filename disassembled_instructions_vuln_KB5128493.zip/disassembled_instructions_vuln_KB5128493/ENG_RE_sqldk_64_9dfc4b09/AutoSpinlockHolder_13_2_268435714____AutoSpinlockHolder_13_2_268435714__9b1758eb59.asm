; AutoSpinlockHolder<13,2,268435714>::~AutoSpinlockHolder<13,2,268435714>
; sqldk.dll, primary RVA 0x98f70, 111 bytes in 1 chunk(s)

; chunk at RVA 0x98f70 (111 bytes)
00098f70  48894c2408               mov qword ptr [rsp + 8], rcx
00098f75  57                       push rdi
00098f76  4883ec30                 sub rsp, 0x30
00098f7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00098f83  48895c2448               mov qword ptr [rsp + 0x48], rbx
00098f88  488bd9                   mov rbx, rcx
00098f8b  488b39                   mov rdi, qword ptr [rcx]
00098f8e  4885ff                   test rdi, rdi
00098f91  7441                     je 0x98fd4
00098f93  83790800                 cmp dword ptr [rcx + 8], 0
00098f97  743b                     je 0x98fd4
00098f99  803d21c5270000           cmp byte ptr [rip + 0x27c521], 0
00098fa0  7427                     je 0x98fc9
00098fa2  ff15a00a1a00             call qword ptr [rip + 0x1a0aa0]
00098fa8  448bc0                   mov r8d, eax
00098fab  b867666666               mov eax, 0x66666667
00098fb0  41f7e8                   imul r8d
00098fb3  d1fa                     sar edx, 1
00098fb5  8bca                     mov ecx, edx
00098fb7  c1e91f                   shr ecx, 0x1f
00098fba  03d1                     add edx, ecx
00098fbc  8d0c92                   lea ecx, [rdx + rdx*4]
00098fbf  443bc1                   cmp r8d, ecx
00098fc2  7505                     jne 0x98fc9
00098fc4  e8071e0000               call 0x9add0
00098fc9  33c0                     xor eax, eax
00098fcb  488907                   mov qword ptr [rdi], rax
00098fce  488903                   mov qword ptr [rbx], rax
00098fd1  894308                   mov dword ptr [rbx + 8], eax
00098fd4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00098fd9  4883c430                 add rsp, 0x30
00098fdd  5f                       pop rdi
00098fde  c3                       ret
