; CMemAligned<CMemObj>::`vector deleting destructor'
; sqldk.dll, primary RVA 0xd0620, 121 bytes in 1 chunk(s)

; chunk at RVA 0xd0620 (121 bytes)
000d0620  48894c2408               mov qword ptr [rsp + 8], rcx
000d0625  57                       push rdi
000d0626  4883ec30                 sub rsp, 0x30
000d062a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d0633  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d0638  8bda                     mov ebx, edx
000d063a  488bf9                   mov rdi, rcx
000d063d  488d0544b21700           lea rax, [rip + 0x17b244]
000d0644  488901                   mov qword ptr [rcx], rax
000d0647  488d051a691700           lea rax, [rip + 0x17691a]
000d064e  488901                   mov qword ptr [rcx], rax
000d0651  488d05b06b1700           lea rax, [rip + 0x176bb0]
000d0658  488901                   mov qword ptr [rcx], rax
000d065b  4883c138                 add rcx, 0x38
000d065f  e88c1bf4ff               call 0x121f0
000d0664  90                       nop
000d0665  488d4f30                 lea rcx, [rdi + 0x30]
000d0669  e8821bf4ff               call 0x121f0
000d066e  90                       nop
000d066f  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
000d0676  83e305                   and ebx, 5
000d0679  80fb05                   cmp bl, 5
000d067c  750d                     jne 0xd068b
000d067e  ba30010000               mov edx, 0x130
000d0683  488bcf                   mov rcx, rdi
000d0686  e88509f3ff               call 0x1010
000d068b  488bc7                   mov rax, rdi
000d068e  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d0693  4883c430                 add rsp, 0x30
000d0697  5f                       pop rdi
000d0698  c3                       ret
