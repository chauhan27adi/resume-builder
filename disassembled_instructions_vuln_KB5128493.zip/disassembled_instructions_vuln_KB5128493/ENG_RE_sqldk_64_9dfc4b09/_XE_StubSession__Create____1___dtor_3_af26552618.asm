; `XE_StubSession::Create'::`1'::dtor$3
; sqldk.dll, primary RVA 0x23535b, 56 bytes in 1 chunk(s)

; chunk at RVA 0x23535b (56 bytes)
0023535b  4055                     push rbp
0023535d  4883ec30                 sub rsp, 0x30
00235361  488bea                   mov rbp, rdx
00235364  c644242806               mov byte ptr [rsp + 0x28], 6
00235369  8b4530                   mov eax, dword ptr [rbp + 0x30]
0023536c  89442420                 mov dword ptr [rsp + 0x20], eax
00235370  4c8d0d91550700           lea r9, [rip + 0x75591]
00235377  41b801000000             mov r8d, 1
0023537d  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
00235384  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00235388  e8334bfaff               call 0x1d9ec0
0023538d  4883c430                 add rsp, 0x30
00235391  5d                       pop rbp
00235392  c3                       ret
