; `XEPackage0::RingTarget::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x231c10, 32 bytes in 1 chunk(s)

; chunk at RVA 0x231c10 (32 bytes)
00231c10  4055                     push rbp
00231c12  4883ec20                 sub rsp, 0x20
00231c16  488bea                   mov rbp, rdx
00231c19  4c8b4530                 mov r8, qword ptr [rbp + 0x30]
00231c1d  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00231c21  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
00231c25  e8e6f3dcff               call 0x1010
00231c2a  4883c420                 add rsp, 0x20
00231c2e  5d                       pop rbp
00231c2f  c3                       ret
