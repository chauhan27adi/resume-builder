; XE_AutoP<ColumnTransformRule>::~XE_AutoP<ColumnTransformRule>
; sqldk.dll, primary RVA 0x4d9d0, 61 bytes in 1 chunk(s)

; chunk at RVA 0x4d9d0 (61 bytes)
0004d9d0  48894c2408               mov qword ptr [rsp + 8], rcx
0004d9d5  53                       push rbx
0004d9d6  4883ec30                 sub rsp, 0x30
0004d9da  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0004d9e3  488bd9                   mov rbx, rcx
0004d9e6  488b09                   mov rcx, qword ptr [rcx]
0004d9e9  4885c9                   test rcx, rcx
0004d9ec  7406                     je 0x4d9f4
0004d9ee  ff155c762c00             call qword ptr [rip + 0x2c765c]
0004d9f4  48c70300000000           mov qword ptr [rbx], 0
0004d9fb  ba08000000               mov edx, 8
0004da00  488b0b                   mov rcx, qword ptr [rbx]
0004da03  4883c430                 add rsp, 0x30
0004da07  5b                       pop rbx
0004da08  e9e3a3fbff               jmp 0x7df0
