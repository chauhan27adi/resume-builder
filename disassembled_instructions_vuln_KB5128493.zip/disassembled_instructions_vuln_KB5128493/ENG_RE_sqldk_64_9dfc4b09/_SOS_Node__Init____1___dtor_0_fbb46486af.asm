; `SOS_Node::Init'::`1'::dtor$0
; sqldk.dll, primary RVA 0x218a10, 63 bytes in 1 chunk(s)

; chunk at RVA 0x218a10 (63 bytes)
00218a10  4055                     push rbp
00218a12  4883ec30                 sub rsp, 0x30
00218a16  488bea                   mov rbp, rdx
00218a19  488b5548                 mov rdx, qword ptr [rbp + 0x48]
00218a1d  4881c240010000           add rdx, 0x140
00218a24  c644242806               mov byte ptr [rsp + 0x28], 6
00218a29  8b4530                   mov eax, dword ptr [rbp + 0x30]
00218a2c  89442420                 mov dword ptr [rsp + 0x20], eax
00218a30  4c8d0df1ec0700           lea r9, [rip + 0x7ecf1]
00218a37  41b801000000             mov r8d, 1
00218a3d  488b12                   mov rdx, qword ptr [rdx]
00218a40  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00218a44  e857f3deff               call 0x7da0
00218a49  4883c430                 add rsp, 0x30
00218a4d  5d                       pop rbp
00218a4e  c3                       ret
