; `XEPackage0::HistoryTarget::InitDictionary'::`1'::dtor$1
; sqldk.dll, primary RVA 0x232919, 51 bytes in 1 chunk(s)

; chunk at RVA 0x232919 (51 bytes)
00232919  4055                     push rbp
0023291b  4883ec20                 sub rsp, 0x20
0023291f  488bea                   mov rbp, rdx
00232922  4c8b85f0000000           mov r8, qword ptr [rbp + 0xf0]
00232929  4981c030200000           add r8, 0x2030
00232930  4d8b00                   mov r8, qword ptr [r8]
00232933  488b9598000000           mov rdx, qword ptr [rbp + 0x98]
0023293a  488b8da0000000           mov rcx, qword ptr [rbp + 0xa0]
00232941  e8cae6dcff               call 0x1010
00232946  4883c420                 add rsp, 0x20
0023294a  5d                       pop rbp
0023294b  c3                       ret
