; CMemAligned<CMemDbg<CMemFixed> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xd0740, 79 bytes in 1 chunk(s)

; chunk at RVA 0xd0740 (79 bytes)
000d0740  48894c2408               mov qword ptr [rsp + 8], rcx
000d0745  57                       push rdi
000d0746  4883ec30                 sub rsp, 0x30
000d074a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d0753  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d0758  8bda                     mov ebx, edx
000d075a  488bf9                   mov rdi, rcx
000d075d  488d05c4ab1700           lea rax, [rip + 0x17abc4]
000d0764  488901                   mov qword ptr [rcx], rax
000d0767  e804080a00               call 0x170f70
000d076c  83e305                   and ebx, 5
000d076f  80fb05                   cmp bl, 5
000d0772  750d                     jne 0xd0781
000d0774  bae0040000               mov edx, 0x4e0
000d0779  488bcf                   mov rcx, rdi
000d077c  e88f08f3ff               call 0x1010
000d0781  488bc7                   mov rax, rdi
000d0784  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d0789  4883c430                 add rsp, 0x30
000d078d  5f                       pop rdi
000d078e  c3                       ret
