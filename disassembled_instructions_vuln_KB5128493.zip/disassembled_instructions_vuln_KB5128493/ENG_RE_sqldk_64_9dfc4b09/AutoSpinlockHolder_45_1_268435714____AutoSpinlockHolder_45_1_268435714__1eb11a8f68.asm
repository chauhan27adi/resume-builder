; AutoSpinlockHolder<45,1,268435714>::~AutoSpinlockHolder<45,1,268435714>
; sqldk.dll, primary RVA 0x1f6ba0, 111 bytes in 1 chunk(s)

; chunk at RVA 0x1f6ba0 (111 bytes)
001f6ba0  48894c2408               mov qword ptr [rsp + 8], rcx
001f6ba5  57                       push rdi
001f6ba6  4883ec30                 sub rsp, 0x30
001f6baa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001f6bb3  48895c2448               mov qword ptr [rsp + 0x48], rbx
001f6bb8  488bd9                   mov rbx, rcx
001f6bbb  488b39                   mov rdi, qword ptr [rcx]
001f6bbe  4885ff                   test rdi, rdi
001f6bc1  7441                     je 0x1f6c04
001f6bc3  83790800                 cmp dword ptr [rcx + 8], 0
001f6bc7  743b                     je 0x1f6c04
001f6bc9  803df1e8110000           cmp byte ptr [rip + 0x11e8f1], 0
001f6bd0  7427                     je 0x1f6bf9
001f6bd2  ff15702e0400             call qword ptr [rip + 0x42e70]
001f6bd8  448bc0                   mov r8d, eax
001f6bdb  b867666666               mov eax, 0x66666667
001f6be0  41f7e8                   imul r8d
001f6be3  d1fa                     sar edx, 1
001f6be5  8bca                     mov ecx, edx
001f6be7  c1e91f                   shr ecx, 0x1f
001f6bea  03d1                     add edx, ecx
001f6bec  8d0c92                   lea ecx, [rdx + rdx*4]
001f6bef  443bc1                   cmp r8d, ecx
001f6bf2  7505                     jne 0x1f6bf9
001f6bf4  e857060000               call 0x1f7250
001f6bf9  33c0                     xor eax, eax
001f6bfb  488907                   mov qword ptr [rdi], rax
001f6bfe  488903                   mov qword ptr [rbx], rax
001f6c01  894308                   mov dword ptr [rbx + 8], eax
001f6c04  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001f6c09  4883c430                 add rsp, 0x30
001f6c0d  5f                       pop rdi
001f6c0e  c3                       ret
