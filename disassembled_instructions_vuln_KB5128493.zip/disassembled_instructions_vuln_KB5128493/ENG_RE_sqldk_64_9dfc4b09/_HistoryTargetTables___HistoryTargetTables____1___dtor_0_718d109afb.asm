; `HistoryTargetTables::~HistoryTargetTables'::`1'::dtor$0
; sqldk.dll, primary RVA 0x216db0, 42 bytes in 1 chunk(s)

; chunk at RVA 0x216db0 (42 bytes)
00216db0  4055                     push rbp
00216db2  4883ec20                 sub rsp, 0x20
00216db6  488bea                   mov rbp, rdx
00216db9  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00216dbd  4c8d0dcc6ce3ff           lea r9, [rip - 0x1c9334]
00216dc4  41b800040000             mov r8d, 0x400
00216dca  ba08000000               mov edx, 8
00216dcf  e88c7ee1ff               call 0x2ec60
00216dd4  4883c420                 add rsp, 0x20
00216dd8  5d                       pop rbp
00216dd9  c3                       ret
