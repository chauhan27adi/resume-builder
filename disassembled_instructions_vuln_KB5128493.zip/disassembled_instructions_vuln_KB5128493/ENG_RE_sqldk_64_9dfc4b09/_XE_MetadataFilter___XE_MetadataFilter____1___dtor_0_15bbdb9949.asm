; `XE_MetadataFilter::~XE_MetadataFilter'::`1'::dtor$0
; sqldk.dll, primary RVA 0x216690, 42 bytes in 1 chunk(s)

; chunk at RVA 0x216690 (42 bytes)
00216690  4055                     push rbp
00216692  4883ec20                 sub rsp, 0x20
00216696  488bea                   mov rbp, rdx
00216699  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0021669d  4c8d0d4c12e3ff           lea r9, [rip - 0x1cedb4]
002166a4  41b800040000             mov r8d, 0x400
002166aa  ba08000000               mov edx, 8
002166af  e8ac85e1ff               call 0x2ec60
002166b4  4883c420                 add rsp, 0x20
002166b8  5d                       pop rbp
002166b9  c3                       ret
