; CAutoP<XE_LogWriter<XE_MetadataEncoder<XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker> > > >::~CAutoP<XE_LogWriter<XE_MetadataEncoder<XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker> > > >
; sqldk.dll, primary RVA 0x1be210, 66 bytes in 1 chunk(s)

; chunk at RVA 0x1be210 (66 bytes)
001be210  4053                     push rbx
001be212  4883ec30                 sub rsp, 0x30
001be216  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001be21f  488b19                   mov rbx, qword ptr [rcx]
001be222  48895c2440               mov qword ptr [rsp + 0x40], rbx
001be227  4885db                   test rbx, rbx
001be22a  7420                     je 0x1be24c
001be22c  488d4b08                 lea rcx, [rbx + 8]
001be230  48894c2440               mov qword ptr [rsp + 0x40], rcx
001be235  e8a6000000               call 0x1be2e0
001be23a  bac0070000               mov edx, 0x7c0
001be23f  488bcb                   mov rcx, rbx
001be242  4883c430                 add rsp, 0x30
001be246  5b                       pop rbx
001be247  e9a49be4ff               jmp 0x7df0
001be24c  4883c430                 add rsp, 0x30
001be250  5b                       pop rbx
001be251  c3                       ret
