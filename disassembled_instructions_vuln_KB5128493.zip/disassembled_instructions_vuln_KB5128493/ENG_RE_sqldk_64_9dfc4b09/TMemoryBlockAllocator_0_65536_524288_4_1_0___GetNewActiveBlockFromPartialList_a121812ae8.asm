; TMemoryBlockAllocator<0,65536,524288,4,1,0>::GetNewActiveBlockFromPartialList
; sqldk.dll, primary RVA 0x24310, 242 bytes in 1 chunk(s)

; chunk at RVA 0x24310 (242 bytes)
00024310  488bc4                   mov rax, rsp
00024313  48894808                 mov qword ptr [rax + 8], rcx
00024317  55                       push rbp
00024318  4154                     push r12
0002431a  4155                     push r13
0002431c  4156                     push r14
0002431e  4157                     push r15
00024320  488d68a9                 lea rbp, [rax - 0x57]
00024324  4881ec90000000           sub rsp, 0x90
0002432b  48c7451ffeffffff         mov qword ptr [rbp + 0x1f], 0xfffffffffffffffe
00024333  48895810                 mov qword ptr [rax + 0x10], rbx
00024337  48897018                 mov qword ptr [rax + 0x18], rsi
0002433b  48897820                 mov qword ptr [rax + 0x20], rdi
0002433f  450fb6e8                 movzx r13d, r8b
00024343  33ff                     xor edi, edi
00024345  8bdf                     mov ebx, edi
00024347  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0002434b  488d45c7                 lea rax, [rbp - 0x39]
0002434f  488945cf                 mov qword ptr [rbp - 0x31], rax
00024353  488d45c7                 lea rax, [rbp - 0x39]
00024357  488945c7                 mov qword ptr [rbp - 0x39], rax
0002435b  0fb7c2                   movzx eax, dx
0002435e  488d0440                 lea rax, [rax + rax*2]
00024362  48c1e006                 shl rax, 6
00024366  4803c1                   add rax, rcx
00024369  488945d7                 mov qword ptr [rbp - 0x29], rax
0002436d  4c8da000010000           lea r12, [rax + 0x100]
00024374  448d7f06                 lea r15d, [rdi + 6]
00024378  440fb6757f               movzx r14d, byte ptr [rbp + 0x7f]
0002437d  4584c9                   test r9b, r9b
00024380  0f8467d60600             je 0x919ed
00024386  8d7704                   lea esi, [rdi + 4]
00024389  eb01                     jmp 0x2438c
0002438b  cc                       int3
0002438c  48895dbf                 mov qword ptr [rbp - 0x41], rbx
00024390  83fe08                   cmp esi, 8
00024393  0f83ac000000             jae 0x24445
00024399  48897dbf                 mov qword ptr [rbp - 0x41], rdi
0002439d  488d55df                 lea rdx, [rbp - 0x21]
000243a1  488955e7                 mov qword ptr [rbp - 0x19], rdx
000243a5  488d4ddf                 lea rcx, [rbp - 0x21]
000243a9  48894ddf                 mov qword ptr [rbp - 0x21], rcx
000243ad  4863fe                   movsxd rdi, esi
000243b0  4883c711                 add rdi, 0x11
000243b4  48c1e704                 shl rdi, 4
000243b8  4803f8                   add rdi, rax
000243bb  488bcf                   mov rcx, rdi
000243be  ff15544e2100             call qword ptr [rip + 0x214e54]
000243c4  4c8bc0                   mov r8, rax
000243c7  4885c0                   test rax, rax
000243ca  0f85bd010000             jne 0x2458d
000243d0  488b5dbf                 mov rbx, qword ptr [rbp - 0x41]
000243d4  4533e4                   xor r12d, r12d
000243d7  488d45df                 lea rax, [rbp - 0x21]
000243db  488b55e7                 mov rdx, qword ptr [rbp - 0x19]
000243df  483bd0                   cmp rdx, rax
000243e2  0f8572d50600             jne 0x9195a
000243e8  ffc6                     inc esi
000243ea  4885db                   test rbx, rbx
000243ed  488b45d7                 mov rax, qword ptr [rbp - 0x29]
000243f1  4c8da000010000           lea r12, [rax + 0x100]
000243f8  7505                     jne 0x243ff
000243fa  33ff                     xor edi, edi
000243fc  eb8e                     jmp 0x2438c
000243fe  cc                       int3
000243ff  eb0f                     jmp 0x24410
00024401  cc                       int3
