; CMemDetour<CMemThread<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce5c0, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce5c0 (104 bytes)
000ce5c0  48894c2408               mov qword ptr [rsp + 8], rcx
000ce5c5  57                       push rdi
000ce5c6  4883ec30                 sub rsp, 0x30
000ce5ca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce5d3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce5d8  8bda                     mov ebx, edx
000ce5da  488bf9                   mov rdi, rcx
000ce5dd  488d057cf11700           lea rax, [rip + 0x17f17c]
000ce5e4  488901                   mov qword ptr [rcx], rax
000ce5e7  488d8120020000           lea rax, [rcx + 0x220]
000ce5ee  4889442450               mov qword ptr [rsp + 0x50], rax
000ce5f3  488d0d46b51600           lea rcx, [rip + 0x16b546]
000ce5fa  488908                   mov qword ptr [rax], rcx
000ce5fd  488bcf                   mov rcx, rdi
000ce600  e84be00200               call 0xfc650
000ce605  83e305                   and ebx, 5
000ce608  80fb05                   cmp bl, 5
000ce60b  750d                     jne 0xce61a
000ce60d  ba58020000               mov edx, 0x258
000ce612  488bcf                   mov rcx, rdi
000ce615  e8f629f3ff               call 0x1010
000ce61a  488bc7                   mov rax, rdi
000ce61d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce622  4883c430                 add rsp, 0x30
000ce626  5f                       pop rdi
000ce627  c3                       ret
