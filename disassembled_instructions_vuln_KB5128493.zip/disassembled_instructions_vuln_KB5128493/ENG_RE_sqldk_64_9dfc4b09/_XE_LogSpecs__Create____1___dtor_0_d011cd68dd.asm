; `XE_LogSpecs::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x215fb0, 34 bytes in 1 chunk(s)

; chunk at RVA 0x215fb0 (34 bytes)
00215fb0  4055                     push rbp
00215fb2  4883ec20                 sub rsp, 0x20
00215fb6  488bea                   mov rbp, rdx
00215fb9  4533c0                   xor r8d, r8d
00215fbc  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
00215fc3  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00215fc7  e844b0deff               call 0x1010
00215fcc  4883c420                 add rsp, 0x20
00215fd0  5d                       pop rbp
00215fd1  c3                       ret
