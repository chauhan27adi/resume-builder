; CMemPartitioned<CMemThread<CMemDbg<CMemLargePageObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xceae0, 133 bytes in 1 chunk(s)

; chunk at RVA 0xceae0 (133 bytes)
000ceae0  48894c2408               mov qword ptr [rsp + 8], rcx
000ceae5  57                       push rdi
000ceae6  4883ec30                 sub rsp, 0x30
000ceaea  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ceaf3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ceaf8  8bda                     mov ebx, edx
000ceafa  488bf9                   mov rdi, rcx
000ceafd  488d05ecda1700           lea rax, [rip + 0x17daec]
000ceb04  488901                   mov qword ptr [rcx], rax
000ceb07  488d8100070000           lea rax, [rcx + 0x700]
000ceb0e  4889442450               mov qword ptr [rsp + 0x50], rax
000ceb13  488d0d26b01600           lea rcx, [rip + 0x16b026]
000ceb1a  488908                   mov qword ptr [rax], rcx
000ceb1d  488d055c9e1700           lea rax, [rip + 0x179e5c]
000ceb24  488907                   mov qword ptr [rdi], rax
000ceb27  488d8798050000           lea rax, [rdi + 0x598]
000ceb2e  4889442458               mov qword ptr [rsp + 0x58], rax
000ceb33  48894830                 mov qword ptr [rax + 0x30], rcx
000ceb37  488908                   mov qword ptr [rax], rcx
000ceb3a  488bcf                   mov rcx, rdi
000ceb3d  e80e4e0a00               call 0x173950
000ceb42  83e305                   and ebx, 5
000ceb45  80fb05                   cmp bl, 5
000ceb48  750d                     jne 0xceb57
000ceb4a  ba38070000               mov edx, 0x738
000ceb4f  488bcf                   mov rcx, rdi
000ceb52  e8b924f3ff               call 0x1010
000ceb57  488bc7                   mov rax, rdi
000ceb5a  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ceb5f  4883c430                 add rsp, 0x30
000ceb63  5f                       pop rdi
000ceb64  c3                       ret
