; TList<SOS_Node,SOS_DispatcherPoolBase,8,TListSLock>::GetHead
; sqldk.dll, primary RVA 0x17ff0, 436 bytes in 6 chunk(s)

; chunk at RVA 0x17ff0 (20 bytes)
00017ff0  4053                     push rbx
00017ff2  4156                     push r14
00017ff4  4883ec38                 sub rsp, 0x38
00017ff8  658b042548000000         mov eax, dword ptr gs:[0x48]
00018000  4c8d7110                 lea r14, [rcx + 0x10]

; chunk at RVA 0x18004 (48 bytes)
00018004  48896c2430               mov qword ptr [rsp + 0x30], rbp
00018009  33db                     xor ebx, ebx
0001800b  8be8                     mov ebp, eax
0001800d  418b06                   mov eax, dword ptr [r14]
00018010  4889742428               mov qword ptr [rsp + 0x28], rsi
00018015  488bf1                   mov rsi, rcx
00018018  85c0                     test eax, eax
0001801a  0f85da731700             jne 0x18f3fa
00018020  33c0                     xor eax, eax
00018022  f0490fb12e               lock cmpxchg qword ptr [r14], rbp
00018027  8bc3                     mov eax, ebx
00018029  0f94c0                   sete al
0001802c  85c0                     test eax, eax
0001802e  0f84c6731700             je 0x18f3fa

; chunk at RVA 0x18034 (20 bytes)
00018034  488b4e08                 mov rcx, qword ptr [rsi + 8]
00018038  33db                     xor ebx, ebx
0001803a  488b6c2430               mov rbp, qword ptr [rsp + 0x30]
0001803f  483bce                   cmp rcx, rsi
00018042  0f85d70e0000             jne 0x18f1f

; chunk at RVA 0x18f1f (81 bytes)
00018f1f  4885c9                   test rcx, rcx
00018f22  488d41f8                 lea rax, [rcx - 8]
00018f26  480f45d8                 cmovne rbx, rax
00018f2a  4885db                   test rbx, rbx
00018f2d  0f8415f1ffff             je 0x18048
00018f33  0f1f00                   nop dword ptr [rax]
00018f36  66660f1f840000000000     nop word ptr [rax + rax]
00018f40  8b4b20                   mov ecx, dword ptr [rbx + 0x20]
00018f43  85c9                     test ecx, ecx
00018f45  0f849e651700             je 0x18f4e9
00018f4b  660f1f0400               nop word ptr [rax + rax]
00018f50  8d5101                   lea edx, [rcx + 1]
00018f53  8bc1                     mov eax, ecx
00018f55  f00fb15320               lock cmpxchg dword ptr [rbx + 0x20], edx
00018f5a  3bc8                     cmp ecx, eax
00018f5c  0f8577651700             jne 0x18f4d9
00018f62  85d2                     test edx, edx
00018f64  0f85def0ffff             jne 0x18048
00018f6a  e97a651700               jmp 0x18f4e9
00018f6f  cc                       int3

; chunk at RVA 0x18f400 (217 bytes)
0018f400  48897c2420               mov qword ptr [rsp + 0x20], rdi
0018f405  2584000000               and eax, 0x84
0018f40a  33ff                     xor edi, edi
0018f40c  3c84                     cmp al, 0x84
0018f40e  754b                     jne 0x18f45b
0018f410  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
0018f419  8b05b15b1800             mov eax, dword ptr [rip + 0x185bb1]
0018f41f  8b159324e7ff             mov edx, dword ptr [rip - 0x18db6d]
0018f425  480314c1                 add rdx, qword ptr [rcx + rax*8]
0018f429  7410                     je 0x18f43b
0018f42b  48399210010000           cmp qword ptr [rdx + 0x110], rdx
0018f432  7507                     jne 0x18f43b
0018f434  488bba00010000           mov rdi, qword ptr [rdx + 0x100]
0018f43b  4885ff                   test rdi, rdi
0018f43e  741b                     je 0x18f45b
0018f440  391d7e601800             cmp dword ptr [rip + 0x18607e], ebx
0018f446  746f                     je 0x18f4b7
0018f448  488d4c2450               lea rcx, [rsp + 0x50]
0018f44d  ff157da00a00             call qword ptr [rip + 0xaa07d]
0018f453  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
0018f458  eb01                     jmp 0x18f45b
0018f45a  cc                       int3
0018f45b  f6057556180080           test byte ptr [rip + 0x185675], 0x80
0018f462  498bce                   mov rcx, r14
0018f465  745b                     je 0x18f4c2
0018f467  4c8bc5                   mov r8, rbp
0018f46a  488bd7                   mov rdx, rdi
0018f46d  e80e55e9ff               call 0x24980
0018f472  eb01                     jmp 0x18f475
0018f474  cc                       int3
0018f475  4885ff                   test rdi, rdi
0018f478  7432                     je 0x18f4ac
0018f47a  833d4360180000           cmp dword ptr [rip + 0x186043], 0
0018f481  744b                     je 0x18f4ce
0018f483  488d4c2458               lea rcx, [rsp + 0x58]
0018f488  ff1542a00a00             call qword ptr [rip + 0xaa042]
0018f48e  488b4c2458               mov rcx, qword ptr [rsp + 0x58]
0018f493  eb01                     jmp 0x18f496
0018f495  cc                       int3
0018f496  33c0                     xor eax, eax
0018f498  488bd1                   mov rdx, rcx
0018f49b  482bd3                   sub rdx, rbx
0018f49e  483bcb                   cmp rcx, rbx
0018f4a1  480f43c2                 cmovae rax, rdx
0018f4a5  480187780c0000           add qword ptr [rdi + 0xc78], rax
0018f4ac  488b7c2420               mov rdi, qword ptr [rsp + 0x20]
0018f4b1  e97e8be8ff               jmp 0x18034
0018f4b6  cc                       int3
0018f4b7  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
0018f4bf  eb9a                     jmp 0x18f45b
0018f4c1  cc                       int3
0018f4c2  488bd5                   mov rdx, rbp
0018f4c5  e8d6adedff               call 0x6a2a0
0018f4ca  90                       nop
0018f4cb  eba8                     jmp 0x18f475
0018f4cd  cc                       int3
0018f4ce  488b0c250800fe7f         mov rcx, qword ptr [0x7ffe0008]
0018f4d6  ebbe                     jmp 0x18f496
0018f4d8  cc                       int3

; chunk at RVA 0x18f512 (50 bytes)
0018f512  ff1530a50a00             call qword ptr [rip + 0xaa530]
0018f518  448bc0                   mov r8d, eax
0018f51b  b867666666               mov eax, 0x66666667
0018f520  41f7e8                   imul r8d
0018f523  d1fa                     sar edx, 1
0018f525  8bca                     mov ecx, edx
0018f527  c1e91f                   shr ecx, 0x1f
0018f52a  03d1                     add edx, ecx
0018f52c  8d0c92                   lea ecx, [rdx + rdx*4]
0018f52f  443bc1                   cmp r8d, ecx
0018f532  0f85228be8ff             jne 0x1805a
0018f538  e8a3afedff               call 0x6a4e0
0018f53d  90                       nop
0018f53e  e9178be8ff               jmp 0x1805a
0018f543  cc                       int3
