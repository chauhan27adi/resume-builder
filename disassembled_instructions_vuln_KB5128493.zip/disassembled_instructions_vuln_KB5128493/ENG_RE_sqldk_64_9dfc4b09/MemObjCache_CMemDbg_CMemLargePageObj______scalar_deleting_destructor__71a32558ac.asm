; MemObjCache<CMemDbg<CMemLargePageObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13eb40, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13eb40 (79 bytes)
0013eb40  48894c2408               mov qword ptr [rsp + 8], rcx
0013eb45  57                       push rdi
0013eb46  4883ec30                 sub rsp, 0x30
0013eb4a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013eb53  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013eb58  8bda                     mov ebx, edx
0013eb5a  488bf9                   mov rdi, rcx
0013eb5d  488d05149a1000           lea rax, [rip + 0x109a14]
0013eb64  488901                   mov qword ptr [rcx], rax
0013eb67  e8e44d0300               call 0x173950
0013eb6c  83e305                   and ebx, 5
0013eb6f  80fb05                   cmp bl, 5
0013eb72  750d                     jne 0x13eb81
0013eb74  bae8050000               mov edx, 0x5e8
0013eb79  488bcf                   mov rcx, rdi
0013eb7c  e88f24ecff               call 0x1010
0013eb81  488bc7                   mov rax, rdi
0013eb84  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013eb89  4883c430                 add rsp, 0x30
0013eb8d  5f                       pop rdi
0013eb8e  c3                       ret
