; `CXFixedTable::InitFixedTable'::`1'::dtor$4
; sqldk.dll, primary RVA 0x216cfd, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216cfd (31 bytes)
00216cfd  4055                     push rbp
00216cff  4883ec20                 sub rsp, 0x20
00216d03  488bea                   mov rbp, rdx
00216d06  4533c0                   xor r8d, r8d
00216d09  488b5548                 mov rdx, qword ptr [rbp + 0x48]
00216d0d  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00216d11  e8faa2deff               call 0x1010
00216d16  4883c420                 add rsp, 0x20
00216d1a  5d                       pop rbp
00216d1b  c3                       ret
