; XE_SessionMetadata::~XE_SessionMetadata
; sqldk.dll, primary RVA 0x46ed0, 54 bytes in 1 chunk(s)

; chunk at RVA 0x46ed0 (54 bytes)
00046ed0  48894c2408               mov qword ptr [rsp + 8], rcx
00046ed5  4883ec38                 sub rsp, 0x38
00046ed9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00046ee2  4883c108                 add rcx, 8
00046ee6  48894c2448               mov qword ptr [rsp + 0x48], rcx
00046eeb  4c8d0dfe090000           lea r9, [rip + 0x9fe]
00046ef2  ba08000000               mov edx, 8
00046ef7  41b800040000             mov r8d, 0x400
00046efd  4883c438                 add rsp, 0x38
00046f01  e95a7dfeff               jmp 0x2ec60
