; DescriptorAllocator<SOS_MemoryFreeBlock,0>::InstallNewPageAsActive
; sqldk.dll, primary RVA 0x36de0, 446 bytes in 1 chunk(s)

; chunk at RVA 0x36de0 (446 bytes)
00036de0  4889542410               mov qword ptr [rsp + 0x10], rdx
00036de5  53                       push rbx
00036de6  55                       push rbp
00036de7  56                       push rsi
00036de8  57                       push rdi
00036de9  4154                     push r12
00036deb  4155                     push r13
00036ded  4156                     push r14
00036def  4157                     push r15
00036df1  4883ec68                 sub rsp, 0x68
00036df5  48c7442440feffffff       mov qword ptr [rsp + 0x40], 0xfffffffffffffffe
00036dfe  450fb7e1                 movzx r12d, r9w
00036e02  4c8be9                   mov r13, rcx
00036e05  6644898c24c8000000       mov word ptr [rsp + 0xc8], r9w
00036e0e  410fb7e9                 movzx ebp, r9w
00036e12  0fb689cc040000           movzx ecx, byte ptr [rcx + 0x4cc]
00036e19  418bc0                   mov eax, r8d
00036e1c  48d3e0                   shl rax, cl
00036e1f  490385c0040000           add rax, qword ptr [r13 + 0x4c0]
00036e26  48898424b0000000         mov qword ptr [rsp + 0xb0], rax
00036e2e  4533c0                   xor r8d, r8d
00036e31  44388424d0000000         cmp byte ptr [rsp + 0xd0], r8b
00036e39  7517                     jne 0x36e52
00036e3b  418d442401               lea eax, [r12 + 1]
00036e40  898424c8000000           mov dword ptr [rsp + 0xc8], eax
00036e47  66413b4508               cmp ax, word ptr [r13 + 8]
00036e4c  0f8480010000             je 0x36fd2
00036e52  4c8d0d078e2e00           lea r9, [rip + 0x2e8e07]
00036e59  4c8bb424d8000000         mov r14, qword ptr [rsp + 0xd8]
00036e61  0f1f4000                 nop dword ptr [rax]
00036e65  6666660f1f840000000000   nop word ptr [rax + rax]
00036e70  440fb7fd                 movzx r15d, bp
00036e74  4b8d3c7f                 lea rdi, [r15 + r15*2]
00036e78  48c1e706                 shl rdi, 6
00036e7c  4903fd                   add rdi, r13
00036e7f  488b8f58050000           mov rcx, qword ptr [rdi + 0x558]
00036e86  483b8f60050000           cmp rcx, qword ptr [rdi + 0x560]
00036e8d  400f92c6                 setb sil
00036e91  0f83cb000000             jae 0x36f62
00036e97  488d8768050000           lea rax, [rdi + 0x568]
00036e9e  b901000000               mov ecx, 1
00036ea3  8708                     xchg dword ptr [rax], ecx
00036ea5  898c24d0000000           mov dword ptr [rsp + 0xd0], ecx
00036eac  85c9                     test ecx, ecx
00036eae  0f85b5000000             jne 0x36f69
00036eb4  4889442438               mov qword ptr [rsp + 0x38], rax
00036eb9  488b9758050000           mov rdx, qword ptr [rdi + 0x558]
00036ec0  483b9760050000           cmp rdx, qword ptr [rdi + 0x560]
00036ec7  400f92c6                 setb sil
00036ecb  0f838e000000             jae 0x36f5f
00036ed1  4d85f6                   test r14, r14
00036ed4  0f85c61b0000             jne 0x38aa0
00036eda  498b9d58040000           mov rbx, qword ptr [r13 + 0x458]
00036ee1  4885db                   test rbx, rbx
00036ee4  0f84381c0000             je 0x38b22
00036eea  4c89442420               mov qword ptr [rsp + 0x20], r8
00036eef  4d8bce                   mov r9, r14
00036ef2  440fb7c5                 movzx r8d, bp
00036ef6  410fb7d4                 movzx edx, r12w
00036efa  488bcb                   mov rcx, rbx
00036efd  e8eef8ffff               call 0x367f0
00036f02  488bd0                   mov rdx, rax
00036f05  4885c0                   test rax, rax
00036f08  0f840a1c0000             je 0x38b18
00036f0e  c7403000000000           mov dword ptr [rax + 0x30], 0
00036f15  4c8b8424b8000000         mov r8, qword ptr [rsp + 0xb8]
00036f1d  498bc0                   mov rax, r8
00036f20  488b8c24b0000000         mov rcx, qword ptr [rsp + 0xb0]
00036f28  f0480fb15108             lock cmpxchg qword ptr [rcx + 8], rdx
00036f2e  0f856e420600             jne 0x9b1a2
00036f34  498bd0                   mov rdx, r8
00036f37  498bcd                   mov rcx, r13
00036f3a  e871000000               call 0x36fb0
00036f3f  48ff8758050000           inc qword ptr [rdi + 0x558]
00036f46  4533c0                   xor r8d, r8d
00036f49  eb01                     jmp 0x36f4c
00036f4b  cc                       int3
00036f4c  4c898778050000           mov qword ptr [rdi + 0x578], r8
00036f53  488b442438               mov rax, qword ptr [rsp + 0x38]
00036f58  4c8d0d018d2e00           lea r9, [rip + 0x2e8d01]
00036f5f  448900                   mov dword ptr [rax], r8d
00036f62  8b8c24d0000000           mov ecx, dword ptr [rsp + 0xd0]
00036f69  8d4501                   lea eax, [rbp + 1]
00036f6c  418be8                   mov ebp, r8d
00036f6f  66413b4508               cmp ax, word ptr [r13 + 8]
00036f74  660f45e8                 cmovne bp, ax
00036f78  4084f6                   test sil, sil
00036f7b  0f8407430600             je 0x9b288
00036f81  85c9                     test ecx, ecx
00036f83  0f8513430600             jne 0x9b29c
00036f89  400fb6c6                 movzx eax, sil
00036f8d  4883c468                 add rsp, 0x68
00036f91  415f                     pop r15
00036f93  415e                     pop r14
00036f95  415d                     pop r13
00036f97  415c                     pop r12
00036f99  5f                       pop rdi
00036f9a  5e                       pop rsi
00036f9b  5d                       pop rbp
00036f9c  5b                       pop rbx
00036f9d  c3                       ret
