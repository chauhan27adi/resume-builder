; SOS_IOCompRequest::Protect
; sqldk.dll, primary RVA 0x1aec0, 299 bytes in 5 chunk(s)

; chunk at RVA 0x1aec0 (21 bytes)
0001aec0  4883ec38                 sub rsp, 0x38
0001aec4  4c8d5120                 lea r10, [rcx + 0x20]
0001aec8  49f7c2ff0f0000           test r10, 0xfff
0001aecf  0f8442b90600             je 0x86817

; chunk at RVA 0x1aed5 (5 bytes)
0001aed5  4883c438                 add rsp, 0x38
0001aed9  c3                       ret

; chunk at RVA 0x86838 (9 bytes)
00086838  48895c2448               mov qword ptr [rsp + 0x48], rbx
0008683d  4c8d4124                 lea r8, [rcx + 0x24]

; chunk at RVA 0x86841 (128 bytes)
00086841  48897c2430               mov qword ptr [rsp + 0x30], rdi
00086846  488d1db3441f00           lea rbx, [rip + 0x1f44b3]
0008684d  bfffffffff               mov edi, 0xffffffff
00086852  41bb00010000             mov r11d, 0x100
00086858  8bd7                     mov edx, edi
0008685a  660f1f440000             nop word ptr [rax + rax]
00086860  410fb608                 movzx ecx, byte ptr [r8]
00086864  4d8d4004                 lea r8, [r8 + 4]
00086868  8bc2                     mov eax, edx
0008686a  c1ea08                   shr edx, 8
0008686d  4833c8                   xor rcx, rax
00086870  0fb6c1                   movzx eax, cl
00086873  410fb648fd               movzx ecx, byte ptr [r8 - 3]
00086878  331483                   xor edx, dword ptr [rbx + rax*4]
0008687b  8bc2                     mov eax, edx
0008687d  c1ea08                   shr edx, 8
00086880  4833c8                   xor rcx, rax
00086883  0fb6c1                   movzx eax, cl
00086886  410fb648fe               movzx ecx, byte ptr [r8 - 2]
0008688b  331483                   xor edx, dword ptr [rbx + rax*4]
0008688e  8bc2                     mov eax, edx
00086890  c1ea08                   shr edx, 8
00086893  4833c8                   xor rcx, rax
00086896  0fb6c1                   movzx eax, cl
00086899  410fb648ff               movzx ecx, byte ptr [r8 - 1]
0008689e  331483                   xor edx, dword ptr [rbx + rax*4]
000868a1  8bc2                     mov eax, edx
000868a3  c1ea08                   shr edx, 8
000868a6  4833c8                   xor rcx, rax
000868a9  0fb6c1                   movzx eax, cl
000868ac  331483                   xor edx, dword ptr [rbx + rax*4]
000868af  4983eb04                 sub r11, 4
000868b3  75ab                     jne 0x86860
000868b5  85d2                     test edx, edx
000868b7  0f44d7                   cmove edx, edi
000868ba  488b7c2430               mov rdi, qword ptr [rsp + 0x30]
000868bf  33db                     xor ebx, ebx

; chunk at RVA 0x868d0 (136 bytes)
000868d0  458bc1                   mov r8d, r9d
000868d3  418bc1                   mov eax, r9d
000868d6  f0410fb112               lock cmpxchg dword ptr [r10], edx
000868db  448bc8                   mov r9d, eax
000868de  8bd3                     mov edx, ebx
000868e0  413bc0                   cmp eax, r8d
000868e3  75eb                     jne 0x868d0
000868e5  4c8d4c2440               lea r9, [rsp + 0x40]
000868ea  ba00100000               mov edx, 0x1000
000868ef  41b802000000             mov r8d, 2
000868f5  498bca                   mov rcx, r10
000868f8  ff155a281b00             call qword ptr [rip + 0x1b285a]
000868fe  85c0                     test eax, eax
00086900  7521                     jne 0x86923
00086902  41b9d7080000             mov r9d, 0x8d7
00086908  48895c2420               mov qword ptr [rsp + 0x20], rbx
0008690d  4c8d05cc552200           lea r8, [rip + 0x2255cc]
00086914  488d15bd552200           lea rdx, [rip + 0x2255bd]
0008691b  8d4801                   lea ecx, [rax + 1]
0008691e  e89db41200               call 0x1b1dc0
00086923  837c244004               cmp dword ptr [rsp + 0x40], 4
00086928  7423                     je 0x8694d
0008692a  41b9dc080000             mov r9d, 0x8dc
00086930  48895c2420               mov qword ptr [rsp + 0x20], rbx
00086935  4c8d05a4552200           lea r8, [rip + 0x2255a4]
0008693c  b901000000               mov ecx, 1
00086941  488d15b8552200           lea rdx, [rip + 0x2255b8]
00086948  e873b41200               call 0x1b1dc0
0008694d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00086952  e97e45f9ff               jmp 0x1aed5
00086957  cc                       int3
