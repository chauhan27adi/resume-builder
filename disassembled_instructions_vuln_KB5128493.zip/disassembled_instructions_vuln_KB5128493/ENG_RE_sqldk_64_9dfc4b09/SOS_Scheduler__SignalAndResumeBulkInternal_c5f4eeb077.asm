; SOS_Scheduler::SignalAndResumeBulkInternal
; sqldk.dll, primary RVA 0x1e340, 303 bytes in 3 chunk(s)

; chunk at RVA 0x1e225 (218 bytes)
0001e225  4c89a42408410000         mov qword ptr [rsp + 0x4108], r12
0001e22d  4c89b42418410000         mov qword ptr [rsp + 0x4118], r14
0001e235  4c8d3564562f00           lea r14, [rip + 0x2f5664]
0001e23c  4c89bc24d0400000         mov qword ptr [rsp + 0x40d0], r15
0001e244  4533ff                   xor r15d, r15d
0001e247  458d6703                 lea r12d, [r15 + 3]
0001e24b  0f1f440000               nop dword ptr [rax + rax]
0001e250  4c8bcb                   mov r9, rbx
0001e253  4c8d5308                 lea r10, [rbx + 8]
0001e257  488b5b08                 mov rbx, qword ptr [rbx + 8]
0001e25b  483bde                   cmp rbx, rsi
0001e25e  4d8b4110                 mov r8, qword ptr [r9 + 0x10]
0001e262  490f44df                 cmove rbx, r15
0001e266  4d8b5918                 mov r11, qword ptr [r9 + 0x18]
0001e26a  418b4018                 mov eax, dword ptr [r8 + 0x18]
0001e26e  6690                     nop
0001e270  4863c8                   movsxd rcx, eax
0001e273  488d1449                 lea rdx, [rcx + rcx*2]
0001e277  4803d2                   add rdx, rdx
0001e27a  45387cd618               cmp byte ptr [r14 + rdx*8 + 0x18], r15b
0001e27f  740c                     je 0x1e28d
0001e281  8bc8                     mov ecx, eax
0001e283  f0450fb16018             lock cmpxchg dword ptr [r8 + 0x18], r12d
0001e289  3bc1                     cmp eax, ecx
0001e28b  75e3                     jne 0x1e270
0001e28d  4863c8                   movsxd rcx, eax
0001e290  488d0449                 lea rax, [rcx + rcx*2]
0001e294  4803c0                   add rax, rax
0001e297  418b54c61c               mov edx, dword ptr [r14 + rax*8 + 0x1c]
0001e29c  85d2                     test edx, edx
0001e29e  0f858f6b0600             jne 0x84e33
0001e2a4  4d8918                   mov qword ptr [r8], r11
0001e2a7  418b54c61c               mov edx, dword ptr [r14 + rax*8 + 0x1c]
0001e2ac  498b01                   mov rax, qword ptr [r9]
0001e2af  498b0a                   mov rcx, qword ptr [r10]
0001e2b2  48894808                 mov qword ptr [rax + 8], rcx
0001e2b6  488901                   mov qword ptr [rcx], rax
0001e2b9  498b4110                 mov rax, qword ptr [r9 + 0x10]
0001e2bd  4d893a                   mov qword ptr [r10], r15
0001e2c0  4d8939                   mov qword ptr [r9], r15
0001e2c3  f0ff4814                 lock dec dword ptr [rax + 0x14]
0001e2c7  85d2                     test edx, edx
0001e2c9  7510                     jne 0x1e2db
0001e2cb  448bc7                   mov r8d, edi
0001e2ce  488d4c2420               lea rcx, [rsp + 0x20]
0001e2d3  498bd1                   mov rdx, r9
0001e2d6  e855feffff               call 0x1e130
0001e2db  4885db                   test rbx, rbx
0001e2de  0f856cffffff             jne 0x1e250
0001e2e4  4c8bbc24d0400000         mov r15, qword ptr [rsp + 0x40d0]
0001e2ec  4c8bb42418410000         mov r14, qword ptr [rsp + 0x4118]
0001e2f4  4c8ba42408410000         mov r12, qword ptr [rsp + 0x4108]
0001e2fc  eb09                     jmp 0x1e307
0001e2fe  cc                       int3

; chunk at RVA 0x1e307 (43 bytes)
0001e307  448bc7                   mov r8d, edi
0001e30a  488d4c2420               lea rcx, [rsp + 0x20]
0001e30f  8bd5                     mov edx, ebp
0001e311  e86afbffff               call 0x1de80
0001e316  488b8c24c0400000         mov rcx, qword ptr [rsp + 0x40c0]
0001e31e  4833cc                   xor rcx, rsp
0001e321  e87a63feff               call 0x46a0
0001e326  4881c4d8400000           add rsp, 0x40d8
0001e32d  5f                       pop rdi
0001e32e  5e                       pop rsi
0001e32f  5d                       pop rbp
0001e330  5b                       pop rbx
0001e331  c3                       ret

; chunk at RVA 0x1e340 (42 bytes)
0001e340  4053                     push rbx
0001e342  55                       push rbp
0001e343  56                       push rsi
0001e344  57                       push rdi
0001e345  b8d8400000               mov eax, 0x40d8
0001e34a  e85141ffff               call 0x124a0
0001e34f  482be0                   sub rsp, rax
0001e352  488b052f2d2f00           mov rax, qword ptr [rip + 0x2f2d2f]
0001e359  4833c4                   xor rax, rsp
0001e35c  48898424c0400000         mov qword ptr [rsp + 0x40c0], rax
0001e364  e992feffff               jmp 0x1e1fb
0001e369  cc                       int3
