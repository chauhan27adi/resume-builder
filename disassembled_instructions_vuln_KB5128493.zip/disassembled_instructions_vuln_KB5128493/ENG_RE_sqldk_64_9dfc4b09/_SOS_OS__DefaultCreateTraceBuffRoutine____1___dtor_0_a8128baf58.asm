; `SOS_OS::DefaultCreateTraceBuffRoutine'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21cee0, 53 bytes in 1 chunk(s)

; chunk at RVA 0x21cee0 (53 bytes)
0021cee0  4055                     push rbp
0021cee2  4883ec30                 sub rsp, 0x30
0021cee6  488bea                   mov rbp, rdx
0021cee9  c644242806               mov byte ptr [rsp + 0x28], 6
0021ceee  8b4558                   mov eax, dword ptr [rbp + 0x58]
0021cef1  89442420                 mov dword ptr [rsp + 0x20], eax
0021cef5  4c8d0d54c20700           lea r9, [rip + 0x7c254]
0021cefc  41b801000000             mov r8d, 1
0021cf02  488b5550                 mov rdx, qword ptr [rbp + 0x50]
0021cf06  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0021cf0a  e891aedeff               call 0x7da0
0021cf0f  4883c430                 add rsp, 0x30
0021cf13  5d                       pop rbp
0021cf14  c3                       ret
