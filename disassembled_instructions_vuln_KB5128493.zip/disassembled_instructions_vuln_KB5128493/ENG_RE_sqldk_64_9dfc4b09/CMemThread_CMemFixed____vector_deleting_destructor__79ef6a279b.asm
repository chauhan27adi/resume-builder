; CMemThread<CMemFixed>::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e370, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13e370 (55 bytes)
0013e370  48895c2408               mov qword ptr [rsp + 8], rbx
0013e375  57                       push rdi
0013e376  4883ec20                 sub rsp, 0x20
0013e37a  8bda                     mov ebx, edx
0013e37c  488bf9                   mov rdi, rcx
0013e37f  e8cce2fbff               call 0xfc650
0013e384  83e305                   and ebx, 5
0013e387  80fb05                   cmp bl, 5
0013e38a  750d                     jne 0x13e399
0013e38c  bae0010000               mov edx, 0x1e0
0013e391  488bcf                   mov rcx, rdi
0013e394  e8772cecff               call 0x1010
0013e399  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013e39e  488bc7                   mov rax, rdi
0013e3a1  4883c420                 add rsp, 0x20
0013e3a5  5f                       pop rdi
0013e3a6  c3                       ret
