; TEnumerator<TList<ClockInfoInternalList,ClockInfo,88,CacheStoreClockSLock> >::~TEnumerator<TList<ClockInfoInternalList,ClockInfo,88,CacheStoreClockSLock> >
; sqldk.dll, primary RVA 0x164710, 177 bytes in 1 chunk(s)

; chunk at RVA 0x164710 (177 bytes)
00164710  48895c2410               mov qword ptr [rsp + 0x10], rbx
00164715  48896c2418               mov qword ptr [rsp + 0x18], rbp
0016471a  4889742420               mov qword ptr [rsp + 0x20], rsi
0016471f  57                       push rdi
00164720  4883ec20                 sub rsp, 0x20
00164724  488b39                   mov rdi, qword ptr [rcx]
00164727  33ed                     xor ebp, ebp
00164729  488bd9                   mov rbx, rcx
0016472c  beffffffff               mov esi, 0xffffffff
00164731  4885ff                   test rdi, rdi
00164734  7429                     je 0x16475f
00164736  8bc6                     mov eax, esi
00164738  f00fc14770               lock xadd dword ptr [rdi + 0x70], eax
0016473d  83f801                   cmp eax, 1
00164740  751a                     jne 0x16475c
00164742  48396f60                 cmp qword ptr [rdi + 0x60], rbp
00164746  740c                     je 0x164754
00164748  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
0016474c  488bd7                   mov rdx, rdi
0016474f  e8dc5fedff               call 0x3a730
00164754  488b07                   mov rax, qword ptr [rdi]
00164757  488bcf                   mov rcx, rdi
0016475a  ff10                     call qword ptr [rax]
0016475c  48892b                   mov qword ptr [rbx], rbp
0016475f  488b7b08                 mov rdi, qword ptr [rbx + 8]
00164763  4885ff                   test rdi, rdi
00164766  7428                     je 0x164790
00164768  f00fc17770               lock xadd dword ptr [rdi + 0x70], esi
0016476d  83fe01                   cmp esi, 1
00164770  751a                     jne 0x16478c
00164772  48396f60                 cmp qword ptr [rdi + 0x60], rbp
00164776  740c                     je 0x164784
00164778  488b4f68                 mov rcx, qword ptr [rdi + 0x68]
0016477c  488bd7                   mov rdx, rdi
0016477f  e8ac5fedff               call 0x3a730
00164784  488b07                   mov rax, qword ptr [rdi]
00164787  488bcf                   mov rcx, rdi
0016478a  ff10                     call qword ptr [rax]
0016478c  48896b08                 mov qword ptr [rbx + 8], rbp
00164790  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
00164794  4885c9                   test rcx, rcx
00164797  740f                     je 0x1647a8
00164799  8b5320                   mov edx, dword ptr [rbx + 0x20]
0016479c  e8af14eaff               call 0x5c50
001647a1  48896b18                 mov qword ptr [rbx + 0x18], rbp
001647a5  896b20                   mov dword ptr [rbx + 0x20], ebp
001647a8  488b742448               mov rsi, qword ptr [rsp + 0x48]
001647ad  48896b10                 mov qword ptr [rbx + 0x10], rbp
001647b1  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
001647b6  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
001647bb  4883c420                 add rsp, 0x20
001647bf  5f                       pop rdi
001647c0  c3                       ret
