; `XEPackage0::OrphanTempManager::CreateForMerge'::`1'::dtor$0
; sqldk.dll, primary RVA 0x231310, 41 bytes in 1 chunk(s)

; chunk at RVA 0x231310 (41 bytes)
00231310  4055                     push rbp
00231312  4883ec20                 sub rsp, 0x20
00231316  488bea                   mov rbp, rdx
00231319  4c8b85f8000000           mov r8, qword ptr [rbp + 0xf8]
00231320  488b95f0000000           mov rdx, qword ptr [rbp + 0xf0]
00231327  488b8d08010000           mov rcx, qword ptr [rbp + 0x108]
0023132e  e8ddfcdcff               call 0x1010
00231333  4883c420                 add rsp, 0x20
00231337  5d                       pop rbp
00231338  c3                       ret
