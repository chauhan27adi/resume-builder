; IMemObj::~IMemObj
; sqldk.dll, primary RVA 0x8b510, 65 bytes in 1 chunk(s)

; chunk at RVA 0x8b510 (65 bytes)
0008b510  48894c2408               mov qword ptr [rsp + 8], rcx
0008b515  53                       push rbx
0008b516  4883ec30                 sub rsp, 0x30
0008b51a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0008b523  488bd9                   mov rbx, rcx
0008b526  488d05dbbc1b00           lea rax, [rip + 0x1bbcdb]
0008b52d  488901                   mov qword ptr [rcx], rax
0008b530  4883c138                 add rcx, 0x38
0008b534  e8b76cf8ff               call 0x121f0
0008b539  90                       nop
0008b53a  488d4b30                 lea rcx, [rbx + 0x30]
0008b53e  e8ad6cf8ff               call 0x121f0
0008b543  90                       nop
0008b544  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0008b54b  4883c430                 add rsp, 0x30
0008b54f  5b                       pop rbx
0008b550  c3                       ret
