; TEnumerator<TList<NodeManager,SOS_Node,16,TListSLock> >::~TEnumerator<TList<NodeManager,SOS_Node,16,TListSLock> >
; sqldk.dll, primary RVA 0xb6520, 151 bytes in 1 chunk(s)

; chunk at RVA 0xb6520 (151 bytes)
000b6520  48895c2410               mov qword ptr [rsp + 0x10], rbx
000b6525  4889742418               mov qword ptr [rsp + 0x18], rsi
000b652a  57                       push rdi
000b652b  4883ec20                 sub rsp, 0x20
000b652f  488bd9                   mov rbx, rcx
000b6532  33f6                     xor esi, esi
000b6534  488b09                   mov rcx, qword ptr [rcx]
000b6537  bfffffffff               mov edi, 0xffffffff
000b653c  4885c9                   test rcx, rcx
000b653f  7421                     je 0xb6562
000b6541  8bc7                     mov eax, edi
000b6543  f00fc14128               lock xadd dword ptr [rcx + 0x28], eax
000b6548  83f801                   cmp eax, 1
000b654b  7512                     jne 0xb655f
000b654d  48397118                 cmp qword ptr [rcx + 0x18], rsi
000b6551  740c                     je 0xb655f
000b6553  488bd1                   mov rdx, rcx
000b6556  488b4920                 mov rcx, qword ptr [rcx + 0x20]
000b655a  e8919df5ff               call 0x102f0
000b655f  488933                   mov qword ptr [rbx], rsi
000b6562  488b4b08                 mov rcx, qword ptr [rbx + 8]
000b6566  4885c9                   test rcx, rcx
000b6569  7420                     je 0xb658b
000b656b  f00fc17928               lock xadd dword ptr [rcx + 0x28], edi
000b6570  83ff01                   cmp edi, 1
000b6573  7512                     jne 0xb6587
000b6575  48397118                 cmp qword ptr [rcx + 0x18], rsi
000b6579  740c                     je 0xb6587
000b657b  488bd1                   mov rdx, rcx
000b657e  488b4920                 mov rcx, qword ptr [rcx + 0x20]
000b6582  e8699df5ff               call 0x102f0
000b6587  48897308                 mov qword ptr [rbx + 8], rsi
000b658b  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
000b658f  4885c9                   test rcx, rcx
000b6592  740f                     je 0xb65a3
000b6594  8b5320                   mov edx, dword ptr [rbx + 0x20]
000b6597  e8b4f6f4ff               call 0x5c50
000b659c  48897318                 mov qword ptr [rbx + 0x18], rsi
000b65a0  897320                   mov dword ptr [rbx + 0x20], esi
000b65a3  48897310                 mov qword ptr [rbx + 0x10], rsi
000b65a7  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
000b65ac  488b742440               mov rsi, qword ptr [rsp + 0x40]
000b65b1  4883c420                 add rsp, 0x20
000b65b5  5f                       pop rdi
000b65b6  c3                       ret
