; `Worker::CreateWorker'::`1'::dtor$1
; sqldk.dll, primary RVA 0x21af80, 59 bytes in 1 chunk(s)

; chunk at RVA 0x21af80 (59 bytes)
0021af80  4055                     push rbp
0021af82  4883ec30                 sub rsp, 0x30
0021af86  488bea                   mov rbp, rdx
0021af89  c644242806               mov byte ptr [rsp + 0x28], 6
0021af8e  8b8598000000             mov eax, dword ptr [rbp + 0x98]
0021af94  89442420                 mov dword ptr [rsp + 0x20], eax
0021af98  4c8d0df1f40500           lea r9, [rip + 0x5f4f1]
0021af9f  41b801000000             mov r8d, 1
0021afa5  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
0021afac  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0021afb0  e8ebcddeff               call 0x7da0
0021afb5  4883c430                 add rsp, 0x30
0021afb9  5d                       pop rbp
0021afba  c3                       ret
