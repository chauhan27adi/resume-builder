; CMemAligned<CMemDbg<PageHeapMemObj> >::~CMemAligned<CMemDbg<PageHeapMemObj> >
; sqldk.dll, primary RVA 0xe4200, 37 bytes in 1 chunk(s)

; chunk at RVA 0xe4200 (37 bytes)
000e4200  48894c2408               mov qword ptr [rsp + 8], rcx
000e4205  4883ec38                 sub rsp, 0x38
000e4209  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000e4212  488d05b76f1600           lea rax, [rip + 0x166fb7]
000e4219  488901                   mov qword ptr [rcx], rax
000e421c  4883c438                 add rsp, 0x38
000e4220  e9ebe10800               jmp 0x172410
