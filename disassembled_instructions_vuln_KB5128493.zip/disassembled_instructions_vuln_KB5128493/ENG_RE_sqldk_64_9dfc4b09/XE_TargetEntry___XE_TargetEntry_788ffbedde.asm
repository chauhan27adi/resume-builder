; XE_TargetEntry::~XE_TargetEntry
; sqldk.dll, primary RVA 0x1f4a70, 196 bytes in 5 chunk(s)

; chunk at RVA 0x1f4a70 (33 bytes)
001f4a70  4056                     push rsi
001f4a72  4883ec20                 sub rsp, 0x20
001f4a76  488d7140                 lea rsi, [rcx + 0x40]
001f4a7a  488d05375f0b00           lea rax, [rip + 0xb5f37]
001f4a81  488901                   mov qword ptr [rcx], rax
001f4a84  488b4e08                 mov rcx, qword ptr [rsi + 8]
001f4a88  483bce                   cmp rcx, rsi
001f4a8b  0f849d000000             je 0x1f4b2e

; chunk at RVA 0x1f4a91 (37 bytes)
001f4a91  48895c2438               mov qword ptr [rsp + 0x38], rbx
001f4a96  488d41d8                 lea rax, [rcx - 0x28]
001f4a9a  48896c2440               mov qword ptr [rsp + 0x40], rbp
001f4a9f  33ed                     xor ebp, ebp
001f4aa1  4885c9                   test rcx, rcx
001f4aa4  8bdd                     mov ebx, ebp
001f4aa6  480f45d8                 cmovne rbx, rax
001f4aaa  4885db                   test rbx, rbx
001f4aad  7475                     je 0x1f4b24
001f4aaf  488b4b30                 mov rcx, qword ptr [rbx + 0x30]
001f4ab3  483bce                   cmp rcx, rsi

; chunk at RVA 0x1f4ab6 (110 bytes)
001f4ab6  48897c2448               mov qword ptr [rsp + 0x48], rdi
001f4abb  8bfd                     mov edi, ebp
001f4abd  480f44cd                 cmove rcx, rbp
001f4ac1  4885c9                   test rcx, rcx
001f4ac4  488d41d8                 lea rax, [rcx - 0x28]
001f4ac8  480f45f8                 cmovne rdi, rax
001f4acc  0f1f4000                 nop dword ptr [rax]
001f4ad0  b8ffffffff               mov eax, 0xffffffff
001f4ad5  f00fc14318               lock xadd dword ptr [rbx + 0x18], eax
001f4ada  83f801                   cmp eax, 1
001f4add  751a                     jne 0x1f4af9
001f4adf  48396b10                 cmp qword ptr [rbx + 0x10], rbp
001f4ae3  740c                     je 0x1f4af1
001f4ae5  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
001f4ae9  488bd3                   mov rdx, rbx
001f4aec  e8bf59ffff               call 0x1ea4b0
001f4af1  488bcb                   mov rcx, rbx
001f4af4  e8e7000000               call 0x1f4be0
001f4af9  488bdf                   mov rbx, rdi
001f4afc  4885ff                   test rdi, rdi
001f4aff  7419                     je 0x1f4b1a
001f4b01  488b4f30                 mov rcx, qword ptr [rdi + 0x30]
001f4b05  488bfd                   mov rdi, rbp
001f4b08  483bce                   cmp rcx, rsi
001f4b0b  480f44cd                 cmove rcx, rbp
001f4b0f  4885c9                   test rcx, rcx
001f4b12  488d41d8                 lea rax, [rcx - 0x28]
001f4b16  480f45f8                 cmovne rdi, rax
001f4b1a  4885db                   test rbx, rbx
001f4b1d  75b1                     jne 0x1f4ad0
001f4b1f  488b7c2448               mov rdi, qword ptr [rsp + 0x48]

; chunk at RVA 0x1f4b24 (10 bytes)
001f4b24  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
001f4b29  488b6c2440               mov rbp, qword ptr [rsp + 0x40]

; chunk at RVA 0x1f4b2e (6 bytes)
001f4b2e  4883c420                 add rsp, 0x20
001f4b32  5e                       pop rsi
001f4b33  c3                       ret
