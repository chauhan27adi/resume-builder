; `SOS_OS::Boot'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21cde0, 62 bytes in 1 chunk(s)

; chunk at RVA 0x21cde0 (62 bytes)
0021cde0  4055                     push rbp
0021cde2  4883ec30                 sub rsp, 0x30
0021cde6  488bea                   mov rbp, rdx
0021cde9  c644242806               mov byte ptr [rsp + 0x28], 6
0021cdee  8b85f8000000             mov eax, dword ptr [rbp + 0xf8]
0021cdf4  89442420                 mov dword ptr [rsp + 0x20], eax
0021cdf8  4c8d0d51c30700           lea r9, [rip + 0x7c351]
0021cdff  41b801000000             mov r8d, 1
0021ce05  488b157cf51800           mov rdx, qword ptr [rip + 0x18f57c]
0021ce0c  488b8d08010000           mov rcx, qword ptr [rbp + 0x108]
0021ce13  e888afdeff               call 0x7da0
0021ce18  4883c430                 add rsp, 0x30
0021ce1c  5d                       pop rbp
0021ce1d  c3                       ret
