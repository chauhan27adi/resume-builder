; `XEPackage0::BucketizingTarget::GetSerializedState'::`1'::dtor$4
; sqldk.dll, primary RVA 0x230861, 31 bytes in 1 chunk(s)

; chunk at RVA 0x230861 (31 bytes)
00230861  4055                     push rbp
00230863  4883ec20                 sub rsp, 0x20
00230867  488bea                   mov rbp, rdx
0023086a  4533c0                   xor r8d, r8d
0023086d  488b5570                 mov rdx, qword ptr [rbp + 0x70]
00230871  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
00230875  e89607ddff               call 0x1010
0023087a  4883c420                 add rsp, 0x20
0023087e  5d                       pop rbp
0023087f  c3                       ret
