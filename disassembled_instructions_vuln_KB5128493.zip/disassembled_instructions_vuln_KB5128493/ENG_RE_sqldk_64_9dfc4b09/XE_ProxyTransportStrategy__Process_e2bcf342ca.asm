; XE_ProxyTransportStrategy::Process
; sqldk.dll, primary RVA 0x1fed80, 1284 bytes in 1 chunk(s)

; chunk at RVA 0x1fed80 (1284 bytes)
001fed80  4055                     push rbp
001fed82  56                       push rsi
001fed83  57                       push rdi
001fed84  4154                     push r12
001fed86  4155                     push r13
001fed88  4156                     push r14
001fed8a  4157                     push r15
001fed8c  488dac2450c0ffff         lea rbp, [rsp - 0x3fb0]
001fed94  b8b0400000               mov eax, 0x40b0
001fed99  e80237e1ff               call 0x124a0
001fed9e  482be0                   sub rsp, rax
001feda1  48c7442440feffffff       mov qword ptr [rsp + 0x40], 0xfffffffffffffffe
001fedaa  48899c2400410000         mov qword ptr [rsp + 0x4100], rbx
001fedb2  488b05cf221100           mov rax, qword ptr [rip + 0x1122cf]
001fedb9  4833c4                   xor rax, rsp
001fedbc  488985a03f0000           mov qword ptr [rbp + 0x3fa0], rax
001fedc3  488bfa                   mov rdi, rdx
001fedc6  488bf1                   mov rsi, rcx
001fedc9  4533ed                   xor r13d, r13d
001fedcc  4c896c2438               mov qword ptr [rsp + 0x38], r13
001fedd1  44896c2434               mov dword ptr [rsp + 0x34], r13d
001fedd6  44896c2430               mov dword ptr [rsp + 0x30], r13d
001feddb  0f57c0                   xorps xmm0, xmm0
001fedde  33c0                     xor eax, eax
001fede0  0f11442470               movups xmmword ptr [rsp + 0x70], xmm0
001fede5  48894580                 mov qword ptr [rbp - 0x80], rax
001fede9  488b02                   mov rax, qword ptr [rdx]
001fedec  488d4c2430               lea rcx, [rsp + 0x30]
001fedf1  48894c2420               mov qword ptr [rsp + 0x20], rcx
001fedf6  4c8d4c2434               lea r9, [rsp + 0x34]
001fedfb  458d4508                 lea r8d, [r13 + 8]
001fedff  488d542438               lea rdx, [rsp + 0x38]
001fee04  488bcf                   mov rcx, rdi
001fee07  ff5008                   call qword ptr [rax + 8]
001fee0a  84c0                     test al, al
001fee0c  0f8420040000             je 0x1ff232
001fee12  488b442438               mov rax, qword ptr [rsp + 0x38]
001fee17  89442470                 mov dword ptr [rsp + 0x70], eax
001fee1b  c744247418000000         mov dword ptr [rsp + 0x74], 0x18
001fee23  83f805                   cmp eax, 5
001fee26  0f87e7030000             ja 0x1ff213
001fee2c  4863c8                   movsxd rcx, eax
001fee2f  4c8d05ca11e0ff           lea r8, [rip - 0x1fee36]
001fee36  418b94886cf21f00         mov edx, dword ptr [r8 + rcx*4 + 0x1ff26c]
001fee3e  4903d0                   add rdx, r8
001fee41  ffe2                     jmp rdx
001fee43  c78520040000ffffffff     mov dword ptr [rbp + 0x420], 0xffffffff
001fee4d  48894590                 mov qword ptr [rbp - 0x70], rax
001fee51  448b44243c               mov r8d, dword ptr [rsp + 0x3c]
001fee56  4183c0f8                 add r8d, -8
001fee5a  488b07                   mov rax, qword ptr [rdi]
001fee5d  488d4c2430               lea rcx, [rsp + 0x30]
001fee62  48894c2420               mov qword ptr [rsp + 0x20], rcx
001fee67  4c8d4c2434               lea r9, [rsp + 0x34]
001fee6c  488d5598                 lea rdx, [rbp - 0x68]
001fee70  488bcf                   mov rcx, rdi
001fee73  ff5008                   call qword ptr [rax + 8]
001fee76  84c0                     test al, al
001fee78  0f8495030000             je 0x1ff213
001fee7e  4c8b4598                 mov r8, qword ptr [rbp - 0x68]
001fee82  4c89442478               mov qword ptr [rsp + 0x78], r8
001fee87  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001fee8b  0f2845a0                 movaps xmm0, xmmword ptr [rbp - 0x60]
001fee8f  0f29442450               movaps xmmword ptr [rsp + 0x50], xmm0
001fee94  f20f104db0               movsd xmm1, qword ptr [rbp - 0x50]
001fee99  f20f114c2460             movsd qword ptr [rsp + 0x60], xmm1
001fee9f  488b01                   mov rax, qword ptr [rcx]
001feea2  488d5580                 lea rdx, [rbp - 0x80]
001feea6  4889542420               mov qword ptr [rsp + 0x20], rdx
001feeab  4c8d4c2450               lea r9, [rsp + 0x50]
001feeb0  488d55b8                 lea rdx, [rbp - 0x48]
001feeb4  ff10                     call qword ptr [rax]
001feeb6  e95f030000               jmp 0x1ff21a
001feebb  488b07                   mov rax, qword ptr [rdi]
001feebe  488d4c2430               lea rcx, [rsp + 0x30]
001feec3  48894c2420               mov qword ptr [rsp + 0x20], rcx
001feec8  4c8d4c2434               lea r9, [rsp + 0x34]
001feecd  41b808000000             mov r8d, 8
001feed3  488d542458               lea rdx, [rsp + 0x58]
001feed8  488bcf                   mov rcx, rdi
001feedb  ff5008                   call qword ptr [rax + 8]
001feede  84c0                     test al, al
001feee0  0f842d030000             je 0x1ff213
001feee6  488b542458               mov rdx, qword ptr [rsp + 0x58]
001feeeb  4889542478               mov qword ptr [rsp + 0x78], rdx
001feef0  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001feef4  488b01                   mov rax, qword ptr [rcx]
001feef7  4c8d4580                 lea r8, [rbp - 0x80]
001feefb  ff5008                   call qword ptr [rax + 8]
001feefe  e917030000               jmp 0x1ff21a
001fef03  4c8b6618                 mov r12, qword ptr [rsi + 0x18]
001fef07  4c89642450               mov qword ptr [rsp + 0x50], r12
001fef0c  4c896c2458               mov qword ptr [rsp + 0x58], r13
001fef11  4533c0                   xor r8d, r8d
001fef14  baffffffff               mov edx, 0xffffffff
001fef19  498bcc                   mov rcx, r12
001fef1c  ff156e611100             call qword ptr [rip + 0x11616e]
001fef22  458bfd                   mov r15d, r13d
001fef25  85c0                     test eax, eax
001fef27  410f94c7                 sete r15b
001fef2b  44897c2458               mov dword ptr [rsp + 0x58], r15d
001fef30  448b44243c               mov r8d, dword ptr [rsp + 0x3c]
001fef35  4183c0f8                 add r8d, -8
001fef39  488b07                   mov rax, qword ptr [rdi]
001fef3c  488b5610                 mov rdx, qword ptr [rsi + 0x10]
001fef40  4883c208                 add rdx, 8
001fef44  488d4c2430               lea rcx, [rsp + 0x30]
001fef49  48894c2420               mov qword ptr [rsp + 0x20], rcx
001fef4e  4c8d4c2434               lea r9, [rsp + 0x34]
001fef53  488bcf                   mov rcx, rdi
001fef56  ff5008                   call qword ptr [rax + 8]
001fef59  84c0                     test al, al
001fef5b  0f844e010000             je 0x1ff0af
001fef61  488b5e10                 mov rbx, qword ptr [rsi + 0x10]
001fef65  4c8d9b18020000           lea r11, [rbx + 0x218]
001fef6c  0fb78310020000           movzx eax, word ptr [rbx + 0x210]
001fef73  4c6bf038                 imul r14, rax, 0x38
001fef77  4d03f3                   add r14, r11
001fef7a  4d3bde                   cmp r11, r14
001fef7d  0f83f9000000             jae 0x1ff07c
001fef83  498d5310                 lea rdx, [r11 + 0x10]
001fef87  488b42f8                 mov rax, qword ptr [rdx - 8]
001fef8b  4885c0                   test rax, rax
001fef8e  7407                     je 0x1fef97
001fef90  4903c3                   add rax, r11
001fef93  488942f8                 mov qword ptr [rdx - 8], rax
001fef97  8b42f0                   mov eax, dword ptr [rdx - 0x10]
001fef9a  448bd0                   mov r10d, eax
001fef9d  4181e200fcff0f           and r10d, 0xffffc00
001fefa4  4181fa003c0000           cmp r10d, 0x3c00
001fefab  7522                     jne 0x1fefcf
001fefad  a9ff030000               test eax, 0x3ff
001fefb2  751b                     jne 0x1fefcf
001fefb4  8bc8                     mov ecx, eax
001fefb6  81e1000000f0             and ecx, 0xf0000000
001fefbc  81f900000060             cmp ecx, 0x60000000
001fefc2  750b                     jne 0x1fefcf
001fefc4  458bc5                   mov r8d, r13d
001fefc7  41b906000000             mov r9d, 6
001fefcd  eb2e                     jmp 0x1feffd
001fefcf  448bc0                   mov r8d, eax
001fefd2  4181e0ff030000           and r8d, 0x3ff
001fefd9  448bc8                   mov r9d, eax
001fefdc  41c1e91c                 shr r9d, 0x1c
001fefe0  4181fa00380000           cmp r10d, 0x3800
001fefe7  7409                     je 0x1feff2
001fefe9  4181fa00400000           cmp r10d, 0x4000
001feff0  7519                     jne 0x1ff00b
001feff2  4585c0                   test r8d, r8d
001feff5  7514                     jne 0x1ff00b
001feff7  4183f906                 cmp r9d, 6
001feffb  750e                     jne 0x1ff00b
001feffd  488b0a                   mov rcx, qword ptr [rdx]
001ff000  4885c9                   test rcx, rcx
001ff003  7406                     je 0x1ff00b
001ff005  4903cb                   add rcx, r11
001ff008  48890a                   mov qword ptr [rdx], rcx
001ff00b  4181fa003c0000           cmp r10d, 0x3c00
001ff012  750d                     jne 0x1ff021
001ff014  4585c0                   test r8d, r8d
001ff017  751c                     jne 0x1ff035
001ff019  4183f906                 cmp r9d, 6
001ff01d  7516                     jne 0x1ff035
001ff01f  eb2a                     jmp 0x1ff04b
001ff021  4181fa00380000           cmp r10d, 0x3800
001ff028  750b                     jne 0x1ff035
001ff02a  4585c0                   test r8d, r8d
001ff02d  7506                     jne 0x1ff035
001ff02f  4183f906                 cmp r9d, 6
001ff033  7416                     je 0x1ff04b
001ff035  c1e81c                   shr eax, 0x1c
001ff038  4181fa00400000           cmp r10d, 0x4000
001ff03f  751a                     jne 0x1ff05b
001ff041  4585c0                   test r8d, r8d
001ff044  7515                     jne 0x1ff05b
001ff046  83f806                   cmp eax, 6
001ff049  7510                     jne 0x1ff05b
001ff04b  488b4208                 mov rax, qword ptr [rdx + 8]
001ff04f  4885c0                   test rax, rax
001ff052  7407                     je 0x1ff05b
001ff054  4903c3                   add rax, r11
001ff057  48894208                 mov qword ptr [rdx + 8], rax
001ff05b  488b4218                 mov rax, qword ptr [rdx + 0x18]
001ff05f  4885c0                   test rax, rax
001ff062  7407                     je 0x1ff06b
001ff064  4903c3                   add rax, r11
001ff067  48894218                 mov qword ptr [rdx + 0x18], rax
001ff06b  4883c238                 add rdx, 0x38
001ff06f  488d42f0                 lea rax, [rdx - 0x10]
001ff073  493bc6                   cmp rax, r14
001ff076  0f820bffffff             jb 0x1fef87
001ff07c  488b4308                 mov rax, qword ptr [rbx + 8]
001ff080  4889442478               mov qword ptr [rsp + 0x78], rax
001ff085  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff089  488b01                   mov rax, qword ptr [rcx]
001ff08c  4c8d4310                 lea r8, [rbx + 0x10]
001ff090  488d5580                 lea rdx, [rbp - 0x80]
001ff094  4889542428               mov qword ptr [rsp + 0x28], rdx
001ff099  4c895c2420               mov qword ptr [rsp + 0x20], r11
001ff09e  440fb78b10020000         movzx r9d, word ptr [rbx + 0x210]
001ff0a6  488b5308                 mov rdx, qword ptr [rbx + 8]
001ff0aa  ff5010                   call qword ptr [rax + 0x10]
001ff0ad  eb07                     jmp 0x1ff0b6
001ff0af  c7458053000000           mov dword ptr [rbp - 0x80], 0x53
001ff0b6  4585ff                   test r15d, r15d
001ff0b9  0f845b010000             je 0x1ff21a
001ff0bf  498bcc                   mov rcx, r12
001ff0c2  ff15d05f1100             call qword ptr [rip + 0x115fd0]
001ff0c8  e94d010000               jmp 0x1ff21a
001ff0cd  488b07                   mov rax, qword ptr [rdi]
001ff0d0  488d4c2430               lea rcx, [rsp + 0x30]
001ff0d5  48894c2420               mov qword ptr [rsp + 0x20], rcx
001ff0da  4c8d4c2434               lea r9, [rsp + 0x34]
001ff0df  41b808020000             mov r8d, 0x208
001ff0e5  488d5598                 lea rdx, [rbp - 0x68]
001ff0e9  488bcf                   mov rcx, rdi
001ff0ec  ff5008                   call qword ptr [rax + 8]
001ff0ef  84c0                     test al, al
001ff0f1  0f841c010000             je 0x1ff213
001ff0f7  488b5598                 mov rdx, qword ptr [rbp - 0x68]
001ff0fb  4889542478               mov qword ptr [rsp + 0x78], rdx
001ff100  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff104  488b01                   mov rax, qword ptr [rcx]
001ff107  4c8d4d80                 lea r9, [rbp - 0x80]
001ff10b  4c8d45a0                 lea r8, [rbp - 0x60]
001ff10f  ff5018                   call qword ptr [rax + 0x18]
001ff112  e903010000               jmp 0x1ff21a
001ff117  488b07                   mov rax, qword ptr [rdi]
001ff11a  488d4c2430               lea rcx, [rsp + 0x30]
001ff11f  48894c2420               mov qword ptr [rsp + 0x20], rcx
001ff124  4c8d4c2434               lea r9, [rsp + 0x34]
001ff129  41b810000000             mov r8d, 0x10
001ff12f  488d542458               lea rdx, [rsp + 0x58]
001ff134  488bcf                   mov rcx, rdi
001ff137  ff5008                   call qword ptr [rax + 8]
001ff13a  84c0                     test al, al
001ff13c  0f84d1000000             je 0x1ff213
001ff142  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff146  488b01                   mov rax, qword ptr [rcx]
001ff149  488b542458               mov rdx, qword ptr [rsp + 0x58]
001ff14e  ff5038                   call qword ptr [rax + 0x38]
001ff151  8b4c2460                 mov ecx, dword ptr [rsp + 0x60]
001ff155  483bc1                   cmp rax, rcx
001ff158  7251                     jb 0x1ff1ab
001ff15a  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff15e  488b1f                   mov rbx, qword ptr [rdi]
001ff161  488b01                   mov rax, qword ptr [rcx]
001ff164  488b542458               mov rdx, qword ptr [rsp + 0x58]
001ff169  ff5040                   call qword ptr [rax + 0x40]
001ff16c  488bd0                   mov rdx, rax
001ff16f  488d442430               lea rax, [rsp + 0x30]
001ff174  4889442420               mov qword ptr [rsp + 0x20], rax
001ff179  4c8d4c2434               lea r9, [rsp + 0x34]
001ff17e  448b442460               mov r8d, dword ptr [rsp + 0x60]
001ff183  488bcf                   mov rcx, rdi
001ff186  ff5308                   call qword ptr [rbx + 8]
001ff189  84c0                     test al, al
001ff18b  0f8482000000             je 0x1ff213
001ff191  488b542458               mov rdx, qword ptr [rsp + 0x58]
001ff196  4889542478               mov qword ptr [rsp + 0x78], rdx
001ff19b  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff19f  488b01                   mov rax, qword ptr [rcx]
001ff1a2  4c8d4580                 lea r8, [rbp - 0x80]
001ff1a6  ff5020                   call qword ptr [rax + 0x20]
001ff1a9  eb6f                     jmp 0x1ff21a
001ff1ab  c7458036000000           mov dword ptr [rbp - 0x80], 0x36
001ff1b2  eb66                     jmp 0x1ff21a
001ff1b4  33d2                     xor edx, edx
001ff1b6  41b810400000             mov r8d, 0x4010
001ff1bc  488d4d90                 lea rcx, [rbp - 0x70]
001ff1c0  e81f57e0ff               call 0x48e4
001ff1c5  488b07                   mov rax, qword ptr [rdi]
001ff1c8  488d4c2430               lea rcx, [rsp + 0x30]
001ff1cd  48894c2420               mov qword ptr [rsp + 0x20], rcx
001ff1d2  4c8d4c2434               lea r9, [rsp + 0x34]
001ff1d7  41b808400000             mov r8d, 0x4008
001ff1dd  488d5598                 lea rdx, [rbp - 0x68]
001ff1e1  488bcf                   mov rcx, rdi
001ff1e4  ff5008                   call qword ptr [rax + 8]
001ff1e7  488b4e20                 mov rcx, qword ptr [rsi + 0x20]
001ff1eb  488b01                   mov rax, qword ptr [rcx]
001ff1ee  41b800040000             mov r8d, 0x400
001ff1f4  488d5580                 lea rdx, [rbp - 0x80]
001ff1f8  4889542420               mov qword ptr [rsp + 0x20], rdx
001ff1fd  4c8d4da0                 lea r9, [rbp - 0x60]
001ff201  488b5598                 mov rdx, qword ptr [rbp - 0x68]
001ff205  ff5028                   call qword ptr [rax + 0x28]
001ff208  488b4598                 mov rax, qword ptr [rbp - 0x68]
001ff20c  4889442478               mov qword ptr [rsp + 0x78], rax
001ff211  eb07                     jmp 0x1ff21a
001ff213  c7458053000000           mov dword ptr [rbp - 0x80], 0x53
001ff21a  488b07                   mov rax, qword ptr [rdi]
001ff21d  4c8d4c2430               lea r9, [rsp + 0x30]
001ff222  41b818000000             mov r8d, 0x18
001ff228  488d542470               lea rdx, [rsp + 0x70]
001ff22d  488bcf                   mov rcx, rdi
001ff230  ff10                     call qword ptr [rax]
001ff232  488b07                   mov rax, qword ptr [rdi]
001ff235  488bcf                   mov rcx, rdi
001ff238  ff5020                   call qword ptr [rax + 0x20]
001ff23b  84c0                     test al, al
001ff23d  0f94c0                   sete al
001ff240  488b8da03f0000           mov rcx, qword ptr [rbp + 0x3fa0]
001ff247  4833cc                   xor rcx, rsp
001ff24a  e85154e0ff               call 0x46a0
001ff24f  488b9c2400410000         mov rbx, qword ptr [rsp + 0x4100]
001ff257  4881c4b0400000           add rsp, 0x40b0
001ff25e  415f                     pop r15
001ff260  415e                     pop r14
001ff262  415d                     pop r13
001ff264  415c                     pop r12
001ff266  5f                       pop rdi
001ff267  5e                       pop rsi
001ff268  5d                       pop rbp
001ff269  c3                       ret
001ff26a  90                       nop
001ff26b  90                       nop
001ff26c  43ee                     out dx, al
