; CMemPartitioned<CMemThread<CMemAligned<CMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcee20, 104 bytes in 1 chunk(s)

; chunk at RVA 0xcee20 (104 bytes)
000cee20  48894c2408               mov qword ptr [rsp + 8], rcx
000cee25  57                       push rdi
000cee26  4883ec30                 sub rsp, 0x30
000cee2a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cee33  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cee38  8bda                     mov ebx, edx
000cee3a  488bf9                   mov rdi, rcx
000cee3d  488d05fcd01700           lea rax, [rip + 0x17d0fc]
000cee44  488901                   mov qword ptr [rcx], rax
000cee47  488d8198020000           lea rax, [rcx + 0x298]
000cee4e  4889442450               mov qword ptr [rsp + 0x50], rax
000cee53  488d0de6ac1600           lea rcx, [rip + 0x16ace6]
000cee5a  488908                   mov qword ptr [rax], rcx
000cee5d  488bcf                   mov rcx, rdi
000cee60  e81bf60500               call 0x12e480
000cee65  83e305                   and ebx, 5
000cee68  80fb05                   cmp bl, 5
000cee6b  750d                     jne 0xcee7a
000cee6d  bad0020000               mov edx, 0x2d0
000cee72  488bcf                   mov rcx, rdi
000cee75  e89621f3ff               call 0x1010
000cee7a  488bc7                   mov rax, rdi
000cee7d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cee82  4883c430                 add rsp, 0x30
000cee86  5f                       pop rdi
000cee87  c3                       ret
