; WaitForGraph::ReduceGraph
; sqldk.dll, primary RVA 0x13530, 184 bytes in 1 chunk(s)

; chunk at RVA 0x13530 (184 bytes)
00013530  48895c2408               mov qword ptr [rsp + 8], rbx
00013535  48896c2410               mov qword ptr [rsp + 0x10], rbp
0001353a  4889742418               mov qword ptr [rsp + 0x18], rsi
0001353f  57                       push rdi
00013540  4156                     push r14
00013542  4157                     push r15
00013544  4883ec20                 sub rsp, 0x20
00013548  83791c00                 cmp dword ptr [rcx + 0x1c], 0
0001354c  488bea                   mov rbp, rdx
0001354f  488bd9                   mov rbx, rcx
00013552  0f84c0010000             je 0x13718
00013558  4885d2                   test rdx, rdx
0001355b  0f85ae010000             jne 0x1370f
00013561  41bf01000000             mov r15d, 1
00013567  660f1f840000000000       nop word ptr [rax + rax]
00013570  4532f6                   xor r14b, r14b
00013573  33f6                     xor esi, esi
00013575  39731c                   cmp dword ptr [rbx + 0x1c], esi
00013578  7624                     jbe 0x1359e
0001357a  90                       nop
0001357b  0f1f440000               nop dword ptr [rax + rax]
00013580  488b4328                 mov rax, qword ptr [rbx + 0x28]
00013584  488b3cf0                 mov rdi, qword ptr [rax + rsi*8]
00013588  4885ff                   test rdi, rdi
0001358b  740a                     je 0x13597
0001358d  44397f30                 cmp dword ptr [rdi + 0x30], r15d
00013591  0f84b2020100             je 0x23849
00013597  ffc6                     inc esi
00013599  3b731c                   cmp esi, dword ptr [rbx + 0x1c]
0001359c  72e2                     jb 0x13580
0001359e  488b03                   mov rax, qword ptr [rbx]
000135a1  488bcb                   mov rcx, rbx
000135a4  ff5040                   call qword ptr [rax + 0x40]
000135a7  84c0                     test al, al
000135a9  0f85bc591900             jne 0x1a8f6b
000135af  4584f6                   test r14b, r14b
000135b2  75bc                     jne 0x13570
000135b4  4885ed                   test rbp, rbp
000135b7  0f85a4591900             jne 0x1a8f61
000135bd  396b48                   cmp dword ptr [rbx + 0x48], ebp
000135c0  eb01                     jmp 0x135c3
000135c2  cc                       int3
000135c3  0f864f010000             jbe 0x13718
000135c9  418bc7                   mov eax, r15d
000135cc  eb01                     jmp 0x135cf
000135ce  cc                       int3
000135cf  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
000135d4  488b6c2448               mov rbp, qword ptr [rsp + 0x48]
000135d9  488b742450               mov rsi, qword ptr [rsp + 0x50]
000135de  4883c420                 add rsp, 0x20
000135e2  415f                     pop r15
000135e4  415e                     pop r14
000135e6  5f                       pop rdi
000135e7  c3                       ret
