; DbgDataBuff::`vector deleting destructor'
; sqldk.dll, primary RVA 0xb8420, 67 bytes in 1 chunk(s)

; chunk at RVA 0xb8420 (67 bytes)
000b8420  48894c2408               mov qword ptr [rsp + 8], rcx
000b8425  57                       push rdi
000b8426  4883ec30                 sub rsp, 0x30
000b842a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000b8433  48895c2448               mov qword ptr [rsp + 0x48], rbx
000b8438  8bda                     mov ebx, edx
000b843a  488bf9                   mov rdi, rcx
000b843d  ff1585131800             call qword ptr [rip + 0x181385]
000b8443  f6c301                   test bl, 1
000b8446  740d                     je 0xb8455
000b8448  ba68010000               mov edx, 0x168
000b844d  488bcf                   mov rcx, rdi
000b8450  e89bf9f4ff               call 0x7df0
000b8455  488bc7                   mov rax, rdi
000b8458  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000b845d  4883c430                 add rsp, 0x30
000b8461  5f                       pop rdi
000b8462  c3                       ret
