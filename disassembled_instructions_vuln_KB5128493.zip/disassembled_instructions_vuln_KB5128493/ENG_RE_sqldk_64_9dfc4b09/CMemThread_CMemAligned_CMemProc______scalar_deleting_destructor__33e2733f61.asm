; CMemThread<CMemAligned<CMemProc> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcd6a0, 55 bytes in 1 chunk(s)

; chunk at RVA 0xcd6a0 (55 bytes)
000cd6a0  48895c2408               mov qword ptr [rsp + 8], rbx
000cd6a5  57                       push rdi
000cd6a6  4883ec20                 sub rsp, 0x20
000cd6aa  8bda                     mov ebx, edx
000cd6ac  488bf9                   mov rdi, rcx
000cd6af  e8fc89ffff               call 0xc60b0
000cd6b4  83e305                   and ebx, 5
000cd6b7  80fb05                   cmp bl, 5
000cd6ba  750d                     jne 0xcd6c9
000cd6bc  ba80010000               mov edx, 0x180
000cd6c1  488bcf                   mov rcx, rdi
000cd6c4  e84739f3ff               call 0x1010
000cd6c9  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
000cd6ce  488bc7                   mov rax, rdi
000cd6d1  4883c420                 add rsp, 0x20
000cd6d5  5f                       pop rdi
000cd6d6  c3                       ret
