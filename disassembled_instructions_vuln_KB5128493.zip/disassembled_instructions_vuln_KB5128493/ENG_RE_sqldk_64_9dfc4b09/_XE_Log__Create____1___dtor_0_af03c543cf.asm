; `XE_Log::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x215f00, 31 bytes in 1 chunk(s)

; chunk at RVA 0x215f00 (31 bytes)
00215f00  4055                     push rbp
00215f02  4883ec20                 sub rsp, 0x20
00215f06  488bea                   mov rbp, rdx
00215f09  4533c0                   xor r8d, r8d
00215f0c  488b5520                 mov rdx, qword ptr [rbp + 0x20]
00215f10  488b4d30                 mov rcx, qword ptr [rbp + 0x30]
00215f14  e8f7b0deff               call 0x1010
00215f19  4883c420                 add rsp, 0x20
00215f1d  5d                       pop rbp
00215f1e  c3                       ret
