; SOS_OnlineNodeEnum::GetNext
; sqldk.dll, primary RVA 0x3caa0, 229 bytes in 5 chunk(s)

; chunk at RVA 0x3c78e (64 bytes)
0003c78e  488bcb                   mov rcx, rbx
0003c791  e8fa960700               call 0xb5e90
0003c796  33d2                     xor edx, edx
0003c798  488bcb                   mov rcx, rbx
0003c79b  e840000000               call 0x3c7e0
0003c7a0  4885c0                   test rax, rax
0003c7a3  7424                     je 0x3c7c9
0003c7a5  0f1f00                   nop dword ptr [rax]
0003c7a8  0f1f840000000000         nop dword ptr [rax + rax]
0003c7b0  f6802006000010           test byte ptr [rax + 0x620], 0x10
0003c7b7  7410                     je 0x3c7c9
0003c7b9  488bd0                   mov rdx, rax
0003c7bc  488bcb                   mov rcx, rbx
0003c7bf  e81c000000               call 0x3c7e0
0003c7c4  4885c0                   test rax, rax
0003c7c7  75e7                     jne 0x3c7b0
0003c7c9  488b7c2468               mov rdi, qword ptr [rsp + 0x68]

; chunk at RVA 0x3c7ce (11 bytes)
0003c7ce  488b742460               mov rsi, qword ptr [rsp + 0x60]
0003c7d3  4883c450                 add rsp, 0x50
0003c7d7  5b                       pop rbx
0003c7d8  c3                       ret

; chunk at RVA 0x3caa0 (18 bytes)
0003caa0  4053                     push rbx
0003caa2  4883ec50                 sub rsp, 0x50
0003caa6  488bd9                   mov rbx, rcx
0003caa9  4885d2                   test rdx, rdx
0003caac  0f8445020000             je 0x3ccf7

; chunk at RVA 0x3cab2 (52 bytes)
0003cab2  488bcb                   mov rcx, rbx
0003cab5  e826fdffff               call 0x3c7e0
0003caba  488bd0                   mov rdx, rax
0003cabd  4885c0                   test rax, rax
0003cac0  740d                     je 0x3cacf
0003cac2  f6822006000010           test byte ptr [rdx + 0x620], 0x10
0003cac9  0f8513950700             jne 0xb5fe2
0003cacf  4885d2                   test rdx, rdx
0003cad2  7409                     je 0x3cadd
0003cad4  f6822006000002           test byte ptr [rdx + 0x620], 2
0003cadb  75d5                     jne 0x3cab2
0003cadd  488bc2                   mov rax, rdx
0003cae0  4883c450                 add rsp, 0x50
0003cae4  5b                       pop rbx
0003cae5  c3                       ret

; chunk at RVA 0x3ccf7 (84 bytes)
0003ccf7  4889742460               mov qword ptr [rsp + 0x60], rsi
0003ccfc  33f6                     xor esi, esi
0003ccfe  8bc6                     mov eax, esi
0003cd00  488bd0                   mov rdx, rax
0003cd03  488bcb                   mov rcx, rbx
0003cd06  e8d5faffff               call 0x3c7e0
0003cd0b  4885c0                   test rax, rax
0003cd0e  7430                     je 0x3cd40
0003cd10  f6802006000010           test byte ptr [rax + 0x620], 0x10
0003cd17  7410                     je 0x3cd29
0003cd19  488bd0                   mov rdx, rax
0003cd1c  488bcb                   mov rcx, rbx
0003cd1f  e8bcfaffff               call 0x3c7e0
0003cd24  4885c0                   test rax, rax
0003cd27  75e7                     jne 0x3cd10
0003cd29  4885c0                   test rax, rax
0003cd2c  7412                     je 0x3cd40
0003cd2e  f6802006000002           test byte ptr [rax + 0x620], 2
0003cd35  75c9                     jne 0x3cd00
0003cd37  4885c0                   test rax, rax
0003cd3a  0f858efaffff             jne 0x3c7ce
0003cd40  48897c2468               mov qword ptr [rsp + 0x68], rdi
0003cd45  e9fb910700               jmp 0xb5f45
0003cd4a  cc                       int3
