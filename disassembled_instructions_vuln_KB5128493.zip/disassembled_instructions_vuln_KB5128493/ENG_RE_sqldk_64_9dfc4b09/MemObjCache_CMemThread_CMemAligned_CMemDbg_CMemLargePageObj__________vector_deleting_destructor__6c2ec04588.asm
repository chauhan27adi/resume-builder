; MemObjCache<CMemThread<CMemAligned<CMemDbg<CMemLargePageObj> > > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13ed60, 128 bytes in 1 chunk(s)

; chunk at RVA 0x13ed60 (128 bytes)
0013ed60  48894c2408               mov qword ptr [rsp + 8], rcx
0013ed65  57                       push rdi
0013ed66  4883ec30                 sub rsp, 0x30
0013ed6a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013ed73  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013ed78  8bda                     mov ebx, edx
0013ed7a  488bf9                   mov rdi, rcx
0013ed7d  488d05ec591200           lea rax, [rip + 0x1259ec]
0013ed84  488901                   mov qword ptr [rcx], rax
0013ed87  488d0542991000           lea rax, [rip + 0x109942]
0013ed8e  488901                   mov qword ptr [rcx], rax
0013ed91  488d81a0050000           lea rax, [rcx + 0x5a0]
0013ed98  4889442450               mov qword ptr [rsp + 0x50], rax
0013ed9d  488d0d9cad0f00           lea rcx, [rip + 0xfad9c]
0013eda4  48894830                 mov qword ptr [rax + 0x30], rcx
0013eda8  488908                   mov qword ptr [rax], rcx
0013edab  488d05cec61000           lea rax, [rip + 0x10c6ce]
0013edb2  488907                   mov qword ptr [rdi], rax
0013edb5  488bcf                   mov rcx, rdi
0013edb8  e8934b0300               call 0x173950
0013edbd  83e305                   and ebx, 5
0013edc0  80fb05                   cmp bl, 5
0013edc3  750d                     jne 0x13edd2
0013edc5  bac8060000               mov edx, 0x6c8
0013edca  488bcf                   mov rcx, rdi
0013edcd  e83e22ecff               call 0x1010
0013edd2  488bc7                   mov rax, rdi
0013edd5  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013edda  4883c430                 add rsp, 0x30
0013edde  5f                       pop rdi
0013eddf  c3                       ret
