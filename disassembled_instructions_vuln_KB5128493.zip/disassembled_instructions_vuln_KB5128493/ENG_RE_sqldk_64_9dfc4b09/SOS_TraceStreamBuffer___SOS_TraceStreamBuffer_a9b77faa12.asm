; SOS_TraceStreamBuffer::~SOS_TraceStreamBuffer
; sqldk.dll, primary RVA 0x57af0, 29 bytes in 1 chunk(s)

; chunk at RVA 0x57af0 (29 bytes)
00057af0  48894c2408               mov qword ptr [rsp + 8], rcx
00057af5  4883ec38                 sub rsp, 0x38
00057af9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00057b02  4883c438                 add rsp, 0x38
00057b06  48ff25bb1c1e00           jmp qword ptr [rip + 0x1e1cbb]
