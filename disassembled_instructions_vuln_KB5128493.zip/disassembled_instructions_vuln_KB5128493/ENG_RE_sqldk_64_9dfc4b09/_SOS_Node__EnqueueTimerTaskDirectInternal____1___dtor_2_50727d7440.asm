; `SOS_Node::EnqueueTimerTaskDirectInternal'::`1'::dtor$2
; sqldk.dll, primary RVA 0x21d630, 63 bytes in 1 chunk(s)

; chunk at RVA 0x21d630 (63 bytes)
0021d630  4055                     push rbp
0021d632  4883ec30                 sub rsp, 0x30
0021d636  488bea                   mov rbp, rdx
0021d639  488b5560                 mov rdx, qword ptr [rbp + 0x60]
0021d63d  4881c2780e0000           add rdx, 0xe78
0021d644  c644242806               mov byte ptr [rsp + 0x28], 6
0021d649  8b4550                   mov eax, dword ptr [rbp + 0x50]
0021d64c  89442420                 mov dword ptr [rsp + 0x20], eax
0021d650  4c8d0df9840400           lea r9, [rip + 0x484f9]
0021d657  41b801000000             mov r8d, 1
0021d65d  488b12                   mov rdx, qword ptr [rdx]
0021d660  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
0021d664  e837a7deff               call 0x7da0
0021d669  4883c430                 add rsp, 0x30
0021d66d  5d                       pop rbp
0021d66e  c3                       ret
