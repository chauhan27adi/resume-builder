; CMemAligned<CMemLargePageObj>::~CMemAligned<CMemLargePageObj>
; sqldk.dll, primary RVA 0x1117f0, 95 bytes in 1 chunk(s)

; chunk at RVA 0x1117f0 (95 bytes)
001117f0  48894c2408               mov qword ptr [rsp + 8], rcx
001117f5  53                       push rbx
001117f6  4883ec30                 sub rsp, 0x30
001117fa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00111803  488bd9                   mov rbx, rcx
00111806  488d05cb9d1300           lea rax, [rip + 0x139dcb]
0011180d  488901                   mov qword ptr [rcx], rax
00111810  488d0501561300           lea rax, [rip + 0x135601]
00111817  488901                   mov qword ptr [rcx], rax
0011181a  488d0547571300           lea rax, [rip + 0x135747]
00111821  488901                   mov qword ptr [rcx], rax
00111824  488d05dd591300           lea rax, [rip + 0x1359dd]
0011182b  488901                   mov qword ptr [rcx], rax
0011182e  4883c138                 add rcx, 0x38
00111832  e8b909f0ff               call 0x121f0
00111837  90                       nop
00111838  488d4b30                 lea rcx, [rbx + 0x30]
0011183c  e8af09f0ff               call 0x121f0
00111841  90                       nop
00111842  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
00111849  4883c430                 add rsp, 0x30
0011184d  5b                       pop rbx
0011184e  c3                       ret
