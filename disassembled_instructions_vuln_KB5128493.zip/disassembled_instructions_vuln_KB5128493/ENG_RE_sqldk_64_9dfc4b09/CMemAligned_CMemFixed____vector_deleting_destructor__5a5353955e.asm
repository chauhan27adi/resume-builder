; CMemAligned<CMemFixed>::`vector deleting destructor'
; sqldk.dll, primary RVA 0xd07a0, 121 bytes in 1 chunk(s)

; chunk at RVA 0xd07a0 (121 bytes)
000d07a0  48894c2408               mov qword ptr [rsp + 8], rcx
000d07a5  57                       push rdi
000d07a6  4883ec30                 sub rsp, 0x30
000d07aa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d07b3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d07b8  8bda                     mov ebx, edx
000d07ba  488bf9                   mov rdi, rcx
000d07bd  488d05b4a81700           lea rax, [rip + 0x17a8b4]
000d07c4  488901                   mov qword ptr [rcx], rax
000d07c7  488d05ea681700           lea rax, [rip + 0x1768ea]
000d07ce  488901                   mov qword ptr [rcx], rax
000d07d1  488d05306a1700           lea rax, [rip + 0x176a30]
000d07d8  488901                   mov qword ptr [rcx], rax
000d07db  4883c138                 add rcx, 0x38
000d07df  e80c1af4ff               call 0x121f0
000d07e4  90                       nop
000d07e5  488d4f30                 lea rcx, [rdi + 0x30]
000d07e9  e8021af4ff               call 0x121f0
000d07ee  90                       nop
000d07ef  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
000d07f6  83e305                   and ebx, 5
000d07f9  80fb05                   cmp bl, 5
000d07fc  750d                     jne 0xd080b
000d07fe  ba10010000               mov edx, 0x110
000d0803  488bcf                   mov rcx, rdi
000d0806  e80508f3ff               call 0x1010
000d080b  488bc7                   mov rax, rdi
000d080e  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d0813  4883c430                 add rsp, 0x30
000d0817  5f                       pop rdi
000d0818  c3                       ret
