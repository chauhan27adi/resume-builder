; TAutoMutex<SOS_RecursiveMutex,4294967295>::~TAutoMutex<SOS_RecursiveMutex,4294967295>
; sqldk.dll, primary RVA 0x55740, 68 bytes in 3 chunk(s)

; chunk at RVA 0x55740 (15 bytes)
00055740  4053                     push rbx
00055742  4883ec20                 sub rsp, 0x20
00055746  83790800                 cmp dword ptr [rcx + 8], 0
0005574a  488bd9                   mov rbx, rcx
0005574d  762f                     jbe 0x5577e

; chunk at RVA 0x5574f (47 bytes)
0005574f  48897c2430               mov qword ptr [rsp + 0x30], rdi
00055754  33ff                     xor edi, edi
00055756  488b0b                   mov rcx, qword ptr [rbx]
00055759  4883694001               sub qword ptr [rcx + 0x40], 1
0005575e  7513                     jne 0x55773
00055760  f0093c24                 lock or dword ptr [rsp], edi
00055764  33d2                     xor edx, edx
00055766  48897930                 mov qword ptr [rcx + 0x30], rdi
0005576a  48897938                 mov qword ptr [rcx + 0x38], rdi
0005576e  e8bd06fbff               call 0x5e30
00055773  834308ff                 add dword ptr [rbx + 8], -1
00055777  75dd                     jne 0x55756
00055779  488b7c2430               mov rdi, qword ptr [rsp + 0x30]

; chunk at RVA 0x5577e (6 bytes)
0005577e  4883c420                 add rsp, 0x20
00055782  5b                       pop rbx
00055783  c3                       ret
