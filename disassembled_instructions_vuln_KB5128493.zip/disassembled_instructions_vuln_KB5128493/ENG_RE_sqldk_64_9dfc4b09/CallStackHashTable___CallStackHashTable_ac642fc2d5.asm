; CallStackHashTable::~CallStackHashTable
; sqldk.dll, primary RVA 0x63410, 120 bytes in 1 chunk(s)

; chunk at RVA 0x63410 (120 bytes)
00063410  48895c2408               mov qword ptr [rsp + 8], rbx
00063415  48896c2410               mov qword ptr [rsp + 0x10], rbp
0006341a  4889742418               mov qword ptr [rsp + 0x18], rsi
0006341f  57                       push rdi
00063420  4883ec20                 sub rsp, 0x20
00063424  488bf1                   mov rsi, rcx
00063427  488d5908                 lea rbx, [rcx + 8]
0006342b  bf80000000               mov edi, 0x80
00063430  33ed                     xor ebp, ebp
00063432  488b0b                   mov rcx, qword ptr [rbx]
00063435  4885c9                   test rcx, rcx
00063438  7411                     je 0x6344b
0006343a  33d2                     xor edx, edx
0006343c  41b800800000             mov r8d, 0x8000
00063442  ff1538611d00             call qword ptr [rip + 0x1d6138]
00063448  48892b                   mov qword ptr [rbx], rbp
0006344b  4883c308                 add rbx, 8
0006344f  4883ef01                 sub rdi, 1
00063453  75dd                     jne 0x63432
00063455  488b8e08040000           mov rcx, qword ptr [rsi + 0x408]
0006345c  4883f9ff                 cmp rcx, -1
00063460  7411                     je 0x63473
00063462  ff15b0601d00             call qword ptr [rip + 0x1d60b0]
00063468  48c78608040000ffffffff   mov qword ptr [rsi + 0x408], 0xffffffffffffffff
00063473  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00063478  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
0006347d  488b742440               mov rsi, qword ptr [rsp + 0x40]
00063482  4883c420                 add rsp, 0x20
00063486  5f                       pop rdi
00063487  c3                       ret
