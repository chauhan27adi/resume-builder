; TList<SchedulerManager,Worker,24,TListSLock>::AppendElem
; sqldk.dll, primary RVA 0x35d20, 266 bytes in 5 chunk(s)

; chunk at RVA 0x313f0 (66 bytes)
000313f0  48896c2438               mov qword ptr [rsp + 0x38], rbp
000313f5  498bec                   mov rbp, r12
000313f8  3c84                     cmp al, 0x84
000313fa  0f84110b0400             je 0x71f11
00031400  f605d0362e0080           test byte ptr [rip + 0x2e36d0], 0x80
00031407  488bcf                   mov rcx, rdi
0003140a  0f84600b0400             je 0x71f70
00031410  4d8bc6                   mov r8, r14
00031413  488bd5                   mov rdx, rbp
00031416  e86535ffff               call 0x24980
0003141b  eb01                     jmp 0x3141e
0003141d  cc                       int3
0003141e  4885ed                   test rbp, rbp
00031421  0f85580b0400             jne 0x71f7f
00031427  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
0003142c  e945490000               jmp 0x35d76
00031431  cc                       int3

; chunk at RVA 0x35d20 (20 bytes)
00035d20  4057                     push rdi
00035d22  4154                     push r12
00035d24  4883ec48                 sub rsp, 0x48
00035d28  658b042548000000         mov eax, dword ptr gs:[0x48]
00035d30  488d7910                 lea rdi, [rcx + 0x10]

; chunk at RVA 0x35d34 (66 bytes)
00035d34  48895c2440               mov qword ptr [rsp + 0x40], rbx
00035d39  4533e4                   xor r12d, r12d
00035d3c  4889742430               mov qword ptr [rsp + 0x30], rsi
00035d41  418bdc                   mov ebx, r12d
00035d44  4c89742428               mov qword ptr [rsp + 0x28], r14
00035d49  488bf1                   mov rsi, rcx
00035d4c  448bf0                   mov r14d, eax
00035d4f  8b07                     mov eax, dword ptr [rdi]
00035d51  4c897c2420               mov qword ptr [rsp + 0x20], r15
00035d56  4c8bfa                   mov r15, rdx
00035d59  85c0                     test eax, eax
00035d5b  0f8584b6ffff             jne 0x313e5
00035d61  33c0                     xor eax, eax
00035d63  f04c0fb137               lock cmpxchg qword ptr [rdi], r14
00035d68  418bc4                   mov eax, r12d
00035d6b  0f94c0                   sete al
00035d6e  85c0                     test eax, eax
00035d70  0f846fb6ffff             je 0x313e5

; chunk at RVA 0x35d76 (64 bytes)
00035d76  488b06                   mov rax, qword ptr [rsi]
00035d79  498d4f18                 lea rcx, [r15 + 0x18]
00035d7d  4c8b742428               mov r14, qword ptr [rsp + 0x28]
00035d82  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
00035d87  488901                   mov qword ptr [rcx], rax
00035d8a  488b06                   mov rax, qword ptr [rsi]
00035d8d  48894808                 mov qword ptr [rax + 8], rcx
00035d91  48890e                   mov qword ptr [rsi], rcx
00035d94  48897108                 mov qword ptr [rcx + 8], rsi
00035d98  ff4618                   inc dword ptr [rsi + 0x18]
00035d9b  49897728                 mov qword ptr [r15 + 0x28], rsi
00035d9f  4438251bf72d00           cmp byte ptr [rip + 0x2df71b], r12b
00035da6  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
00035dab  488b742430               mov rsi, qword ptr [rsp + 0x30]
00035db0  0f850ac20300             jne 0x71fc0

; chunk at RVA 0x71fc0 (50 bytes)
00071fc0  ff15827a1c00             call qword ptr [rip + 0x1c7a82]
00071fc6  448bc0                   mov r8d, eax
00071fc9  b867666666               mov eax, 0x66666667
00071fce  41f7e8                   imul r8d
00071fd1  d1fa                     sar edx, 1
00071fd3  8bca                     mov ecx, edx
00071fd5  c1e91f                   shr ecx, 0x1f
00071fd8  03d1                     add edx, ecx
00071fda  8d0c92                   lea ecx, [rdx + rdx*4]
00071fdd  443bc1                   cmp r8d, ecx
00071fe0  0f85d03dfcff             jne 0x35db6
00071fe6  e8f584ffff               call 0x6a4e0
00071feb  90                       nop
00071fec  e9c53dfcff               jmp 0x35db6
00071ff1  cc                       int3
