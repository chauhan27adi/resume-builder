; `XMLCXTargetConfigHelper::ParseFromString'::`1'::dtor$0
; sqldk.dll, primary RVA 0x217660, 34 bytes in 1 chunk(s)

; chunk at RVA 0x217660 (34 bytes)
00217660  4055                     push rbp
00217662  4883ec20                 sub rsp, 0x20
00217666  488bea                   mov rbp, rdx
00217669  4533c0                   xor r8d, r8d
0021766c  488b5570                 mov rdx, qword ptr [rbp + 0x70]
00217670  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
00217677  e89499deff               call 0x1010
0021767c  4883c420                 add rsp, 0x20
00217680  5d                       pop rbp
00217681  c3                       ret
