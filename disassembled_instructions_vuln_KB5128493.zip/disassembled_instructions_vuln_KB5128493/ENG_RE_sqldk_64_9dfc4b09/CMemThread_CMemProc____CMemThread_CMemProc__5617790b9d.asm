; CMemThread<CMemProc>::~CMemThread<CMemProc>
; sqldk.dll, primary RVA 0xd2c90, 111 bytes in 1 chunk(s)

; chunk at RVA 0xd2c90 (111 bytes)
000d2c90  48894c2408               mov qword ptr [rsp + 8], rcx
000d2c95  53                       push rbx
000d2c96  4883ec30                 sub rsp, 0x30
000d2c9a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d2ca3  488bd9                   mov rbx, rcx
000d2ca6  488d051b811700           lea rax, [rip + 0x17811b]
000d2cad  488901                   mov qword ptr [rcx], rax
000d2cb0  488d81a0000000           lea rax, [rcx + 0xa0]
000d2cb7  4889442448               mov qword ptr [rsp + 0x48], rax
000d2cbc  488d0d7d6e1600           lea rcx, [rip + 0x166e7d]
000d2cc3  48894830                 mov qword ptr [rax + 0x30], rcx
000d2cc7  488908                   mov qword ptr [rax], rcx
000d2cca  488d0587461700           lea rax, [rip + 0x174687]
000d2cd1  488903                   mov qword ptr [rbx], rax
000d2cd4  488d052d451700           lea rax, [rip + 0x17452d]
000d2cdb  488903                   mov qword ptr [rbx], rax
000d2cde  488d4b38                 lea rcx, [rbx + 0x38]
000d2ce2  e809f5f3ff               call 0x121f0
000d2ce7  90                       nop
000d2ce8  488d4b30                 lea rcx, [rbx + 0x30]
000d2cec  e8fff4f3ff               call 0x121f0
000d2cf1  90                       nop
000d2cf2  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
000d2cf9  4883c430                 add rsp, 0x30
000d2cfd  5b                       pop rbx
000d2cfe  c3                       ret
