; MemObjCache<CMemThread<CMemAligned<CMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13f1a0, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13f1a0 (79 bytes)
0013f1a0  48894c2408               mov qword ptr [rsp + 8], rcx
0013f1a5  57                       push rdi
0013f1a6  4883ec30                 sub rsp, 0x30
0013f1aa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013f1b3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013f1b8  8bda                     mov ebx, edx
0013f1ba  488bf9                   mov rdi, rcx
0013f1bd  488d0554541200           lea rax, [rip + 0x125454]
0013f1c4  488901                   mov qword ptr [rcx], rax
0013f1c7  e8b4f2feff               call 0x12e480
0013f1cc  83e305                   and ebx, 5
0013f1cf  80fb05                   cmp bl, 5
0013f1d2  750d                     jne 0x13f1e1
0013f1d4  ba58020000               mov edx, 0x258
0013f1d9  488bcf                   mov rcx, rdi
0013f1dc  e82f1eecff               call 0x1010
0013f1e1  488bc7                   mov rax, rdi
0013f1e4  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013f1e9  4883c430                 add rsp, 0x30
0013f1ed  5f                       pop rdi
0013f1ee  c3                       ret
