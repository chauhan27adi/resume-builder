; CMemFixed::~CMemFixed
; sqldk.dll, primary RVA 0x89440, 75 bytes in 1 chunk(s)

; chunk at RVA 0x89440 (75 bytes)
00089440  48894c2408               mov qword ptr [rsp + 8], rcx
00089445  53                       push rbx
00089446  4883ec30                 sub rsp, 0x30
0008944a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00089453  488bd9                   mov rbx, rcx
00089456  488d055bdc1b00           lea rax, [rip + 0x1bdc5b]
0008945d  488901                   mov qword ptr [rcx], rax
00089460  488d05a1dd1b00           lea rax, [rip + 0x1bdda1]
00089467  488901                   mov qword ptr [rcx], rax
0008946a  4883c138                 add rcx, 0x38
0008946e  e87d8df8ff               call 0x121f0
00089473  90                       nop
00089474  488d4b30                 lea rcx, [rbx + 0x30]
00089478  e8738df8ff               call 0x121f0
0008947d  90                       nop
0008947e  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
00089485  4883c430                 add rsp, 0x30
00089489  5b                       pop rbx
0008948a  c3                       ret
