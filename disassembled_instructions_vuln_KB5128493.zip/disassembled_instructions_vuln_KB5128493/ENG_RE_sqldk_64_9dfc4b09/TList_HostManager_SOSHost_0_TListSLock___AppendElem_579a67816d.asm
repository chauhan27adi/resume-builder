; TList<HostManager,SOSHost,0,TListSLock>::AppendElem
; sqldk.dll, primary RVA 0x11940, 262 bytes in 5 chunk(s)

; chunk at RVA 0x11940 (20 bytes)
00011940  4057                     push rdi
00011942  4154                     push r12
00011944  4883ec48                 sub rsp, 0x48
00011948  658b042548000000         mov eax, dword ptr gs:[0x48]
00011950  488d7910                 lea rdi, [rcx + 0x10]

; chunk at RVA 0x11954 (66 bytes)
00011954  48895c2440               mov qword ptr [rsp + 0x40], rbx
00011959  4533e4                   xor r12d, r12d
0001195c  4889742430               mov qword ptr [rsp + 0x30], rsi
00011961  418bdc                   mov ebx, r12d
00011964  4c89742428               mov qword ptr [rsp + 0x28], r14
00011969  488bf1                   mov rsi, rcx
0001196c  4c897c2420               mov qword ptr [rsp + 0x20], r15
00011971  4c8bf2                   mov r14, rdx
00011974  448bf8                   mov r15d, eax
00011977  8b07                     mov eax, dword ptr [rdi]
00011979  85c0                     test eax, eax
0001197b  0f85ff250200             jne 0x33f80
00011981  33c0                     xor eax, eax
00011983  f04c0fb13f               lock cmpxchg qword ptr [rdi], r15
00011988  418bc4                   mov eax, r12d
0001198b  0f94c0                   sete al
0001198e  85c0                     test eax, eax
00011990  0f84ea250200             je 0x33f80

; chunk at RVA 0x11996 (60 bytes)
00011996  488b06                   mov rax, qword ptr [rsi]
00011999  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
0001199e  488b5c2440               mov rbx, qword ptr [rsp + 0x40]
000119a3  498906                   mov qword ptr [r14], rax
000119a6  488b06                   mov rax, qword ptr [rsi]
000119a9  4c897008                 mov qword ptr [rax + 8], r14
000119ad  4c8936                   mov qword ptr [rsi], r14
000119b0  49897608                 mov qword ptr [r14 + 8], rsi
000119b4  ff4618                   inc dword ptr [rsi + 0x18]
000119b7  49897610                 mov qword ptr [r14 + 0x10], rsi
000119bb  443825ff3a3000           cmp byte ptr [rip + 0x303aff], r12b
000119c2  4c8b742428               mov r14, qword ptr [rsp + 0x28]
000119c7  488b742430               mov rsi, qword ptr [rsp + 0x30]
000119cc  0f850f2d0600             jne 0x746e1

; chunk at RVA 0x33f8b (66 bytes)
00033f8b  48896c2438               mov qword ptr [rsp + 0x38], rbp
00033f90  498bec                   mov rbp, r12
00033f93  3c84                     cmp al, 0x84
00033f95  0f8497060400             je 0x74632
00033f9b  f605350b2e0080           test byte ptr [rip + 0x2e0b35], 0x80
00033fa2  488bcf                   mov rcx, rdi
00033fa5  0f84e6060400             je 0x74691
00033fab  4d8bc7                   mov r8, r15
00033fae  488bd5                   mov rdx, rbp
00033fb1  e8ca09ffff               call 0x24980
00033fb6  eb01                     jmp 0x33fb9
00033fb8  cc                       int3
00033fb9  4885ed                   test rbp, rbp
00033fbc  0f85de060400             jne 0x746a0
00033fc2  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
00033fc7  e9cad9fdff               jmp 0x11996
00033fcc  cc                       int3

; chunk at RVA 0x746e1 (50 bytes)
000746e1  ff1561531c00             call qword ptr [rip + 0x1c5361]
000746e7  448bc0                   mov r8d, eax
000746ea  b867666666               mov eax, 0x66666667
000746ef  41f7e8                   imul r8d
000746f2  d1fa                     sar edx, 1
000746f4  8bca                     mov ecx, edx
000746f6  c1e91f                   shr ecx, 0x1f
000746f9  03d1                     add edx, ecx
000746fb  8d0c92                   lea ecx, [rdx + rdx*4]
000746fe  443bc1                   cmp r8d, ecx
00074701  0f85cbd2f9ff             jne 0x119d2
00074707  e8d45dffff               call 0x6a4e0
0007470c  90                       nop
0007470d  e9c0d2f9ff               jmp 0x119d2
00074712  cc                       int3
