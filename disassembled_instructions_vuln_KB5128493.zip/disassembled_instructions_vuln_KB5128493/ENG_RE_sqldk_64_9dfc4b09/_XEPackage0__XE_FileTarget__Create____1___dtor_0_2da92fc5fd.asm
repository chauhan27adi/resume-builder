; `XEPackage0::XE_FileTarget::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22fe90, 38 bytes in 1 chunk(s)

; chunk at RVA 0x22fe90 (38 bytes)
0022fe90  4055                     push rbp
0022fe92  4883ec20                 sub rsp, 0x20
0022fe96  488bea                   mov rbp, rdx
0022fe99  4c8b8580000000           mov r8, qword ptr [rbp + 0x80]
0022fea0  488b5558                 mov rdx, qword ptr [rbp + 0x58]
0022fea4  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
0022feab  e86011ddff               call 0x1010
0022feb0  4883c420                 add rsp, 0x20
0022feb4  5d                       pop rbp
0022feb5  c3                       ret
