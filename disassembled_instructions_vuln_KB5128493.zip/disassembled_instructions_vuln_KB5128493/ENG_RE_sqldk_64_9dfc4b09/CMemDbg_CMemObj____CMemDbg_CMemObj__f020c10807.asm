; CMemDbg<CMemObj>::~CMemDbg<CMemObj>
; sqldk.dll, primary RVA 0x16e5e0, 99 bytes in 1 chunk(s)

; chunk at RVA 0x16e5e0 (99 bytes)
0016e5e0  48894c2408               mov qword ptr [rsp + 8], rcx
0016e5e5  53                       push rbx
0016e5e6  4883ec30                 sub rsp, 0x30
0016e5ea  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0016e5f3  488bd9                   mov rbx, rcx
0016e5f6  488d05a3de0d00           lea rax, [rip + 0xddea3]
0016e5fd  488901                   mov qword ptr [rcx], rax
0016e600  488d05d1770f00           lea rax, [rip + 0xf77d1]
0016e607  48898138010000           mov qword ptr [rcx + 0x138], rax
0016e60e  488d0553890d00           lea rax, [rip + 0xd8953]
0016e615  488901                   mov qword ptr [rcx], rax
0016e618  488d05e98b0d00           lea rax, [rip + 0xd8be9]
0016e61f  488901                   mov qword ptr [rcx], rax
0016e622  4883c138                 add rcx, 0x38
0016e626  e8c53beaff               call 0x121f0
0016e62b  90                       nop
0016e62c  488d4b30                 lea rcx, [rbx + 0x30]
0016e630  e8bb3beaff               call 0x121f0
0016e635  90                       nop
0016e636  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0016e63d  4883c430                 add rsp, 0x30
0016e641  5b                       pop rbx
0016e642  c3                       ret
