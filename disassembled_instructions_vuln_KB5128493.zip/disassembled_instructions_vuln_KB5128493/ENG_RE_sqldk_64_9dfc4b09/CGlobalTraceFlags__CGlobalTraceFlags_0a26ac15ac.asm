; CGlobalTraceFlags::CGlobalTraceFlags
; sqldk.dll, primary RVA 0x1b5100, 49 bytes in 1 chunk(s)

; chunk at RVA 0x1b5100 (49 bytes)
001b5100  4053                     push rbx
001b5102  4883ec20                 sub rsp, 0x20
001b5106  488bd9                   mov rbx, rcx
001b5109  4c8d0d10f5ffff           lea r9, [rip - 0xaf0]
001b5110  488d0da9211900           lea rcx, [rip + 0x1921a9]
001b5117  ba38160000               mov edx, 0x1638
001b511c  41b818000000             mov r8d, 0x18
001b5122  ff1530490800             call qword ptr [rip + 0x84930]
001b5128  488bc3                   mov rax, rbx
001b512b  4883c420                 add rsp, 0x20
001b512f  5b                       pop rbx
001b5130  c3                       ret
