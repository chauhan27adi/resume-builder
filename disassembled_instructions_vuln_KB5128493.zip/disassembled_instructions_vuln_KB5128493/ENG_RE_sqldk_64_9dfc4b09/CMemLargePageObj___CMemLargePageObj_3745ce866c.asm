; CMemLargePageObj::~CMemLargePageObj
; sqldk.dll, primary RVA 0x89b00, 85 bytes in 1 chunk(s)

; chunk at RVA 0x89b00 (85 bytes)
00089b00  48894c2408               mov qword ptr [rsp + 8], rcx
00089b05  53                       push rbx
00089b06  4883ec30                 sub rsp, 0x30
00089b0a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00089b13  488bd9                   mov rbx, rcx
00089b16  488d05fbd21b00           lea rax, [rip + 0x1bd2fb]
00089b1d  488901                   mov qword ptr [rcx], rax
00089b20  488d0541d41b00           lea rax, [rip + 0x1bd441]
00089b27  488901                   mov qword ptr [rcx], rax
00089b2a  488d05d7d61b00           lea rax, [rip + 0x1bd6d7]
00089b31  488901                   mov qword ptr [rcx], rax
00089b34  4883c138                 add rcx, 0x38
00089b38  e8b386f8ff               call 0x121f0
00089b3d  90                       nop
00089b3e  488d4b30                 lea rcx, [rbx + 0x30]
00089b42  e8a986f8ff               call 0x121f0
00089b47  90                       nop
00089b48  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
00089b4f  4883c430                 add rsp, 0x30
00089b53  5b                       pop rbx
00089b54  c3                       ret
