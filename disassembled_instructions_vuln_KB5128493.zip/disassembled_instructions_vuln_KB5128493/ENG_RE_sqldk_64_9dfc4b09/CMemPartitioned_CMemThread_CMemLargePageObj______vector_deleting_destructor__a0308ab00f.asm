; CMemPartitioned<CMemThread<CMemLargePageObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce9e0, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce9e0 (104 bytes)
000ce9e0  48894c2408               mov qword ptr [rsp + 8], rcx
000ce9e5  57                       push rdi
000ce9e6  4883ec30                 sub rsp, 0x30
000ce9ea  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce9f3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce9f8  8bda                     mov ebx, edx
000ce9fa  488bf9                   mov rdi, rcx
000ce9fd  488d059cde1700           lea rax, [rip + 0x17de9c]
000cea04  488901                   mov qword ptr [rcx], rax
000cea07  488d8130030000           lea rax, [rcx + 0x330]
000cea0e  4889442450               mov qword ptr [rsp + 0x50], rax
000cea13  488d0d26b11600           lea rcx, [rip + 0x16b126]
000cea1a  488908                   mov qword ptr [rax], rcx
000cea1d  488bcf                   mov rcx, rdi
000cea20  e80b4d0400               call 0x113730
000cea25  83e305                   and ebx, 5
000cea28  80fb05                   cmp bl, 5
000cea2b  750d                     jne 0xcea3a
000cea2d  ba68030000               mov edx, 0x368
000cea32  488bcf                   mov rcx, rdi
000cea35  e8d625f3ff               call 0x1010
000cea3a  488bc7                   mov rax, rdi
000cea3d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cea42  4883c430                 add rsp, 0x30
000cea46  5f                       pop rdi
000cea47  c3                       ret
