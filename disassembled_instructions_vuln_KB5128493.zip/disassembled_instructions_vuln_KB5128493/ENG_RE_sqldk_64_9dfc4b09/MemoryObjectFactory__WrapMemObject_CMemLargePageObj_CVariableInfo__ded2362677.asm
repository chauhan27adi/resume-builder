; MemoryObjectFactory::WrapMemObject<CMemLargePageObj,CVariableInfo>
; sqldk.dll, primary RVA 0xca990, 5920 bytes in 1 chunk(s)

; chunk at RVA 0xca990 (5920 bytes)
000ca990  4c894c2420               mov qword ptr [rsp + 0x20], r9
000ca995  4c89442418               mov qword ptr [rsp + 0x18], r8
000ca99a  55                       push rbp
000ca99b  56                       push rsi
000ca99c  57                       push rdi
000ca99d  4154                     push r12
000ca99f  4155                     push r13
000ca9a1  4156                     push r14
000ca9a3  4157                     push r15
000ca9a5  488bec                   mov rbp, rsp
000ca9a8  4881ec80000000           sub rsp, 0x80
000ca9af  48c745c0feffffff         mov qword ptr [rbp - 0x40], 0xfffffffffffffffe
000ca9b7  48899c24c0000000         mov qword ptr [rsp + 0xc0], rbx
000ca9bf  4d8be1                   mov r12, r9
000ca9c2  498bf0                   mov rsi, r8
000ca9c5  8bc2                     mov eax, edx
000ca9c7  488d153256f3ff           lea rdx, [rip - 0xca9ce]
000ca9ce  4c8bacc200273100         mov r13, qword ptr [rdx + rax*8 + 0x312700]
000ca9d6  4c896d60                 mov qword ptr [rbp + 0x60], r13
000ca9da  8b7d78                   mov edi, dword ptr [rbp + 0x78]
000ca9dd  448bff                   mov r15d, edi
000ca9e0  4181e702002f01           and r15d, 0x12f0002
000ca9e7  4533f6                   xor r14d, r14d
000ca9ea  418bde                   mov ebx, r14d
000ca9ed  83f92a                   cmp ecx, 0x2a
000ca9f0  0f87ee150000             ja 0xcbfe4
000ca9f6  4863c1                   movsxd rax, ecx
000ca9f9  8b8c8204c00c00           mov ecx, dword ptr [rdx + rax*4 + 0xcc004]
000caa00  4803ca                   add rcx, rdx
000caa03  ffe1                     jmp rcx
000caa05  488bd6                   mov rdx, rsi
000caa08  b9c8010000               mov ecx, 0x1c8
000caa0d  e85e72f4ff               call 0x11c70
000caa12  488bd8                   mov rbx, rax
000caa15  48894560                 mov qword ptr [rbp + 0x60], rax
000caa19  4885c0                   test rax, rax
000caa1c  744b                     je 0xcaa69
000caa1e  c7400801000000           mov dword ptr [rax + 8], 1
000caa25  488d05dcc71700           lea rax, [rip + 0x17c7dc]
000caa2c  488903                   mov qword ptr [rbx], rax
000caa2f  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000caa37  44897318                 mov dword ptr [rbx + 0x18], r14d
000caa3b  4c897320                 mov qword ptr [rbx + 0x20], r14
000caa3f  44897328                 mov dword ptr [rbx + 0x28], r14d
000caa43  4c897330                 mov qword ptr [rbx + 0x30], r14
000caa47  4c897338                 mov qword ptr [rbx + 0x38], r14
000caa4b  4c897340                 mov qword ptr [rbx + 0x40], r14
000caa4f  4c897348                 mov qword ptr [rbx + 0x48], r14
000caa53  488d050ec51700           lea rax, [rip + 0x17c50e]
000caa5a  488903                   mov qword ptr [rbx], rax
000caa5d  488d05b4c31700           lea rax, [rip + 0x17c3b4]
000caa64  488903                   mov qword ptr [rbx], rax
000caa67  eb03                     jmp 0xcaa6c
000caa69  498bde                   mov rbx, r14
000caa6c  e9d9140000               jmp 0xcbf4a
000caa71  488bd6                   mov rdx, rsi
000caa74  b998050000               mov ecx, 0x598
000caa79  e8f271f4ff               call 0x11c70
000caa7e  488bd8                   mov rbx, rax
000caa81  48894560                 mov qword ptr [rbp + 0x60], rax
000caa85  4885c0                   test rax, rax
000caa88  7463                     je 0xcaaed
000caa8a  c7400801000000           mov dword ptr [rax + 8], 1
000caa91  488d0570c71700           lea rax, [rip + 0x17c770]
000caa98  488903                   mov qword ptr [rbx], rax
000caa9b  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000caaa3  44897318                 mov dword ptr [rbx + 0x18], r14d
000caaa7  4c897320                 mov qword ptr [rbx + 0x20], r14
000caaab  44897328                 mov dword ptr [rbx + 0x28], r14d
000caaaf  4c897330                 mov qword ptr [rbx + 0x30], r14
000caab3  4c897338                 mov qword ptr [rbx + 0x38], r14
000caab7  4c897340                 mov qword ptr [rbx + 0x40], r14
000caabb  4c897348                 mov qword ptr [rbx + 0x48], r14
000caabf  488d05a2c41700           lea rax, [rip + 0x17c4a2]
000caac6  488903                   mov qword ptr [rbx], rax
000caac9  488d0548c31700           lea rax, [rip + 0x17c348]
000caad0  488903                   mov qword ptr [rbx], rax
000caad3  488d057e241800           lea rax, [rip + 0x18247e]
000caada  488903                   mov qword ptr [rbx], rax
000caadd  488d05f4b21900           lea rax, [rip + 0x19b2f4]
000caae4  488983d8010000           mov qword ptr [rbx + 0x1d8], rax
000caaeb  eb03                     jmp 0xcaaf0
000caaed  498bde                   mov rbx, r14
000caaf0  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000caaf9  8b05d1a42400             mov eax, dword ptr [rip + 0x24a4d1]
000caaff  448b35b26df3ff           mov r14d, dword ptr [rip - 0xc924e]
000cab06  4c0334c1                 add r14, qword ptr [rcx + rax*8]
000cab0a  498b8600010000           mov rax, qword ptr [r14 + 0x100]
000cab11  4885c0                   test rax, rax
000cab14  750e                     jne 0xcab24
000cab16  33c9                     xor ecx, ecx
000cab18  e8f395f6ff               call 0x34110
000cab1d  498b8600010000           mov rax, qword ptr [r14 + 0x100]
000cab24  488b8058020000           mov rax, qword ptr [rax + 0x258]
000cab2b  488983c8010000           mov qword ptr [rbx + 0x1c8], rax
000cab32  c783d001000001000000     mov dword ptr [rbx + 0x1d0], 1
000cab3c  4489bbd4010000           mov dword ptr [rbx + 0x1d4], r15d
000cab43  4533f6                   xor r14d, r14d
000cab46  4489b380050000           mov dword ptr [rbx + 0x580], r14d
000cab4d  c1ef19                   shr edi, 0x19
000cab50  83e701                   and edi, 1
000cab53  89bb84050000             mov dword ptr [rbx + 0x584], edi
000cab59  4489b388050000           mov dword ptr [rbx + 0x588], r14d
000cab60  4c89b390050000           mov qword ptr [rbx + 0x590], r14
000cab67  488d8bd8010000           lea rcx, [rbx + 0x1d8]
000cab6e  4c8bcb                   mov r9, rbx
000cab71  458bc7                   mov r8d, r15d
000cab74  498bd5                   mov rdx, r13
000cab77  e834d80900               call 0x1683b0
000cab7c  e9cc130000               jmp 0xcbf4d
000cab81  488bd6                   mov rdx, rsi
000cab84  b940020000               mov ecx, 0x240
000cab89  e8e270f4ff               call 0x11c70
000cab8e  488bd8                   mov rbx, rax
000cab91  48894560                 mov qword ptr [rbp + 0x60], rax
000cab95  4885c0                   test rax, rax
000cab98  0f8493000000             je 0xcac31
000cab9e  c7400801000000           mov dword ptr [rax + 8], 1
000caba5  488d055cc61700           lea rax, [rip + 0x17c65c]
000cabac  488903                   mov qword ptr [rbx], rax
000cabaf  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000cabb7  44897318                 mov dword ptr [rbx + 0x18], r14d
000cabbb  4c897320                 mov qword ptr [rbx + 0x20], r14
000cabbf  44897328                 mov dword ptr [rbx + 0x28], r14d
000cabc3  4c897330                 mov qword ptr [rbx + 0x30], r14
000cabc7  4c897338                 mov qword ptr [rbx + 0x38], r14
000cabcb  4c897340                 mov qword ptr [rbx + 0x40], r14
000cabcf  4c897348                 mov qword ptr [rbx + 0x48], r14
000cabd3  488d058ec31700           lea rax, [rip + 0x17c38e]
000cabda  488903                   mov qword ptr [rbx], rax
000cabdd  488d0534c21700           lea rax, [rip + 0x17c234]
000cabe4  488903                   mov qword ptr [rbx], rax
000cabe7  488d05621f1800           lea rax, [rip + 0x181f62]
000cabee  488903                   mov qword ptr [rbx], rax
000cabf1  488d8b08020000           lea rcx, [rbx + 0x208]
000cabf8  48894dc8                 mov qword ptr [rbp - 0x38], rcx
000cabfc  488d4108                 lea rax, [rcx + 8]
000cac00  48894008                 mov qword ptr [rax + 8], rax
000cac04  488900                   mov qword ptr [rax], rax
000cac07  4c897118                 mov qword ptr [rcx + 0x18], r14
000cac0b  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cac12  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cac19  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cac21  488d0518ef1600           lea rax, [rip + 0x16ef18]
000cac28  488901                   mov qword ptr [rcx], rax
000cac2b  4c897130                 mov qword ptr [rcx + 0x30], r14
000cac2f  eb03                     jmp 0xcac34
000cac31  498bde                   mov rbx, r14
000cac34  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000cac3b  0fb64844                 movzx ecx, byte ptr [rax + 0x44]
000cac3f  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000cac46  c683d001000000           mov byte ptr [rbx + 0x1d0], 0
000cac4d  c683d101000000           mov byte ptr [rbx + 0x1d1], 0
000cac54  c683d201000000           mov byte ptr [rbx + 0x1d2], 0
000cac5b  4489b3f8010000           mov dword ptr [rbx + 0x1f8], r14d
000cac62  48c783fc01000001000000   mov qword ptr [rbx + 0x1fc], 1
000cac6d  4489b304020000           mov dword ptr [rbx + 0x204], r14d
000cac74  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cac7b  0f1000                   movups xmm0, xmmword ptr [rax]
000cac7e  0f1183d8010000           movups xmmword ptr [rbx + 0x1d8], xmm0
000cac85  0f104810                 movups xmm1, xmmword ptr [rax + 0x10]
000cac89  0f118be8010000           movups xmmword ptr [rbx + 0x1e8], xmm1
000cac90  c683d301000001           mov byte ptr [rbx + 0x1d3], 1
000cac97  f683dc01000001           test byte ptr [rbx + 0x1dc], 1
000cac9e  0fb683d3010000           movzx eax, byte ptr [rbx + 0x1d3]
000caca5  410f45c6                 cmovne eax, r14d
000caca9  8883d3010000             mov byte ptr [rbx + 0x1d3], al
000cacaf  84c9                     test cl, cl
000cacb1  0f8493120000             je 0xcbf4a
000cacb7  488bcb                   mov rcx, rbx
000cacba  e8d1940700               call 0x144190
000cacbf  e986120000               jmp 0xcbf4a
000cacc4  488bd6                   mov rdx, rsi
000cacc7  b9d0010000               mov ecx, 0x1d0
000caccc  e89f6ff4ff               call 0x11c70
000cacd1  488bf8                   mov rdi, rax
000cacd4  48894560                 mov qword ptr [rbp + 0x60], rax
000cacd8  4885c0                   test rax, rax
000cacdb  745c                     je 0xcad39
000cacdd  c7400801000000           mov dword ptr [rax + 8], 1
000cace4  488d051dc51700           lea rax, [rip + 0x17c51d]
000caceb  488907                   mov qword ptr [rdi], rax
000cacee  48c7471000200000         mov qword ptr [rdi + 0x10], 0x2000
000cacf6  44897718                 mov dword ptr [rdi + 0x18], r14d
000cacfa  4c897720                 mov qword ptr [rdi + 0x20], r14
000cacfe  44897728                 mov dword ptr [rdi + 0x28], r14d
000cad02  4c897730                 mov qword ptr [rdi + 0x30], r14
000cad06  4c897738                 mov qword ptr [rdi + 0x38], r14
000cad0a  4c897740                 mov qword ptr [rdi + 0x40], r14
000cad0e  4c897748                 mov qword ptr [rdi + 0x48], r14
000cad12  488d054fc21700           lea rax, [rip + 0x17c24f]
000cad19  488907                   mov qword ptr [rdi], rax
000cad1c  488d05f5c01700           lea rax, [rip + 0x17c0f5]
000cad23  488907                   mov qword ptr [rdi], rax
000cad26  488d05ab081800           lea rax, [rip + 0x1808ab]
000cad2d  488907                   mov qword ptr [rdi], rax
000cad30  4c89b7c8010000           mov qword ptr [rdi + 0x1c8], r14
000cad37  eb03                     jmp 0xcad3c
000cad39  498bfe                   mov rdi, r14
000cad3c  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cad43  0f1008                   movups xmm1, xmmword ptr [rax]
000cad46  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cad4a  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000cad4e  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cad52  66480f7eca               movq rdx, xmm1
000cad57  48c1ea20                 shr rdx, 0x20
000cad5b  f6c201                   test dl, 1
000cad5e  7564                     jne 0xcadc4
000cad60  81e22ffbffff             and edx, 0xfffffb2f
000cad66  81ca20020000             or edx, 0x220
000cad6c  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cad70  48c1e820                 shr rax, 0x20
000cad74  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000cad78  498bc8                   mov rcx, r8
000cad7b  48c1e920                 shr rcx, 0x20
000cad7f  49c1e810                 shr r8, 0x10
000cad83  89442438                 mov dword ptr [rsp + 0x38], eax
000cad87  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000cad8a  89442430                 mov dword ptr [rsp + 0x30], eax
000cad8e  894c2428                 mov dword ptr [rsp + 0x28], ecx
000cad92  664489442420             mov word ptr [rsp + 0x20], r8w
000cad98  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000cad9d  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000cada1  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000cada4  e86767f4ff               call 0x11510
000cada9  488987c8010000           mov qword ptr [rdi + 0x1c8], rax
000cadb0  4885c0                   test rax, rax
000cadb3  0f95c0                   setne al
000cadb6  498bde                   mov rbx, r14
000cadb9  84c0                     test al, al
000cadbb  480f45df                 cmovne rbx, rdi
000cadbf  e986110000               jmp 0xcbf4a
000cadc4  b001                     mov al, 1
000cadc6  498bde                   mov rbx, r14
000cadc9  84c0                     test al, al
000cadcb  480f45df                 cmovne rbx, rdi
000cadcf  e976110000               jmp 0xcbf4a
000cadd4  488bd6                   mov rdx, rsi
000cadd7  b9a0050000               mov ecx, 0x5a0
000caddc  e88f6ef4ff               call 0x11c70
000cade1  488bd8                   mov rbx, rax
000cade4  48894560                 mov qword ptr [rbp + 0x60], rax
000cade8  4885c0                   test rax, rax
000cadeb  7474                     je 0xcae61
000caded  c7400801000000           mov dword ptr [rax + 8], 1
000cadf4  488d050dc41700           lea rax, [rip + 0x17c40d]
000cadfb  488903                   mov qword ptr [rbx], rax
000cadfe  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000cae06  44897318                 mov dword ptr [rbx + 0x18], r14d
000cae0a  4c897320                 mov qword ptr [rbx + 0x20], r14
000cae0e  44897328                 mov dword ptr [rbx + 0x28], r14d
000cae12  4c897330                 mov qword ptr [rbx + 0x30], r14
000cae16  4c897338                 mov qword ptr [rbx + 0x38], r14
000cae1a  4c897340                 mov qword ptr [rbx + 0x40], r14
000cae1e  4c897348                 mov qword ptr [rbx + 0x48], r14
000cae22  488d053fc11700           lea rax, [rip + 0x17c13f]
000cae29  488903                   mov qword ptr [rbx], rax
000cae2c  488d05e5bf1700           lea rax, [rip + 0x17bfe5]
000cae33  488903                   mov qword ptr [rbx], rax
000cae36  488d051b211800           lea rax, [rip + 0x18211b]
000cae3d  488903                   mov qword ptr [rbx], rax
000cae40  488d0591af1900           lea rax, [rip + 0x19af91]
000cae47  488983d8010000           mov qword ptr [rbx + 0x1d8], rax
000cae4e  488d052b061800           lea rax, [rip + 0x18062b]
000cae55  488903                   mov qword ptr [rbx], rax
000cae58  4c89b398050000           mov qword ptr [rbx + 0x598], r14
000cae5f  eb03                     jmp 0xcae64
000cae61  498bde                   mov rbx, r14
000cae64  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cae6b  0f1008                   movups xmm1, xmmword ptr [rax]
000cae6e  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cae72  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000cae76  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cae7a  66480f7eca               movq rdx, xmm1
000cae7f  48c1ea20                 shr rdx, 0x20
000cae83  f6c201                   test dl, 1
000cae86  0f8564fcffff             jne 0xcaaf0
000cae8c  81e22ffbffff             and edx, 0xfffffb2f
000cae92  81ca20020000             or edx, 0x220
000cae98  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cae9c  48c1e820                 shr rax, 0x20
000caea0  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000caea4  498bc8                   mov rcx, r8
000caea7  48c1e920                 shr rcx, 0x20
000caeab  49c1e810                 shr r8, 0x10
000caeaf  89442438                 mov dword ptr [rsp + 0x38], eax
000caeb3  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000caeb6  89442430                 mov dword ptr [rsp + 0x30], eax
000caeba  894c2428                 mov dword ptr [rsp + 0x28], ecx
000caebe  664489442420             mov word ptr [rsp + 0x20], r8w
000caec4  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000caec9  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000caecd  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000caed0  e83b66f4ff               call 0x11510
000caed5  48898398050000           mov qword ptr [rbx + 0x598], rax
000caedc  4885c0                   test rax, rax
000caedf  0f95c0                   setne al
000caee2  84c0                     test al, al
000caee4  0f8506fcffff             jne 0xcaaf0
000caeea  498bde                   mov rbx, r14
000caeed  e9f2100000               jmp 0xcbfe4
000caef2  488bd6                   mov rdx, rsi
000caef5  b9a0020000               mov ecx, 0x2a0
000caefa  e8716df4ff               call 0x11c70
000caeff  48894560                 mov qword ptr [rbp + 0x60], rax
000caf03  4885c0                   test rax, rax
000caf06  740d                     je 0xcaf15
000caf08  488bc8                   mov rcx, rax
000caf0b  e800870400               call 0x113610
000caf10  488bd8                   mov rbx, rax
000caf13  eb03                     jmp 0xcaf18
000caf15  498bde                   mov rbx, r14
000caf18  e92d100000               jmp 0xcbf4a
000caf1d  488bd6                   mov rdx, rsi
000caf20  b918030000               mov ecx, 0x318
000caf25  e8466df4ff               call 0x11c70
000caf2a  48894560                 mov qword ptr [rbp + 0x60], rax
000caf2e  4885c0                   test rax, rax
000caf31  740d                     je 0xcaf40
000caf33  488bc8                   mov rcx, rax
000caf36  e8c52c0000               call 0xcdc00
000caf3b  488bd8                   mov rbx, rax
000caf3e  eb03                     jmp 0xcaf43
000caf40  498bde                   mov rbx, r14
000caf43  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000caf4a  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000caf4f  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000caf56  488bcb                   mov rcx, rbx
000caf59  e862000500               call 0x11afc0
000caf5e  e9e70f0000               jmp 0xcbf4a
000caf63  488bd6                   mov rdx, rsi
000caf66  b9a8020000               mov ecx, 0x2a8
000caf6b  e8006df4ff               call 0x11c70
000caf70  48894560                 mov qword ptr [rbp + 0x60], rax
000caf74  4885c0                   test rax, rax
000caf77  740d                     je 0xcaf86
000caf79  488bc8                   mov rcx, rax
000caf7c  e8efc90400               call 0x117970
000caf81  488bf8                   mov rdi, rax
000caf84  eb03                     jmp 0xcaf89
000caf86  498bfe                   mov rdi, r14
000caf89  e9aefdffff               jmp 0xcad3c
000caf8e  488bd6                   mov rdx, rsi
000caf91  b918020000               mov ecx, 0x218
000caf96  e8d56cf4ff               call 0x11c70
000caf9b  488bd8                   mov rbx, rax
000caf9e  48894560                 mov qword ptr [rbp + 0x60], rax
000cafa2  4885c0                   test rax, rax
000cafa5  0f8484000000             je 0xcb02f
000cafab  c7400801000000           mov dword ptr [rax + 8], 1
000cafb2  488d054fc21700           lea rax, [rip + 0x17c24f]
000cafb9  488903                   mov qword ptr [rbx], rax
000cafbc  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000cafc4  44897318                 mov dword ptr [rbx + 0x18], r14d
000cafc8  4c897320                 mov qword ptr [rbx + 0x20], r14
000cafcc  44897328                 mov dword ptr [rbx + 0x28], r14d
000cafd0  4c897330                 mov qword ptr [rbx + 0x30], r14
000cafd4  4c897338                 mov qword ptr [rbx + 0x38], r14
000cafd8  4c897340                 mov qword ptr [rbx + 0x40], r14
000cafdc  4c897348                 mov qword ptr [rbx + 0x48], r14
000cafe0  488d0581bf1700           lea rax, [rip + 0x17bf81]
000cafe7  488903                   mov qword ptr [rbx], rax
000cafea  488d0527be1700           lea rax, [rip + 0x17be27]
000caff1  488903                   mov qword ptr [rbx], rax
000caff4  488d052dd81700           lea rax, [rip + 0x17d82d]
000caffb  488903                   mov qword ptr [rbx], rax
000caffe  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000cb005  0f57c0                   xorps xmm0, xmm0
000cb008  33c0                     xor eax, eax
000cb00a  0f1183d0010000           movups xmmword ptr [rbx + 0x1d0], xmm0
000cb011  0f1183e0010000           movups xmmword ptr [rbx + 0x1e0], xmm0
000cb018  0f1183f0010000           movups xmmword ptr [rbx + 0x1f0], xmm0
000cb01f  0f118300020000           movups xmmword ptr [rbx + 0x200], xmm0
000cb026  48898310020000           mov qword ptr [rbx + 0x210], rax
000cb02d  eb03                     jmp 0xcb032
000cb02f  498bde                   mov rbx, r14
000cb032  e9130f0000               jmp 0xcbf4a
000cb037  488bd6                   mov rdx, rsi
000cb03a  b920020000               mov ecx, 0x220
000cb03f  e82c6cf4ff               call 0x11c70
000cb044  488bf8                   mov rdi, rax
000cb047  48894560                 mov qword ptr [rbp + 0x60], rax
000cb04b  4885c0                   test rax, rax
000cb04e  0f8495000000             je 0xcb0e9
000cb054  c7400801000000           mov dword ptr [rax + 8], 1
000cb05b  488d05a6c11700           lea rax, [rip + 0x17c1a6]
000cb062  488907                   mov qword ptr [rdi], rax
000cb065  48c7471000200000         mov qword ptr [rdi + 0x10], 0x2000
000cb06d  44897718                 mov dword ptr [rdi + 0x18], r14d
000cb071  4c897720                 mov qword ptr [rdi + 0x20], r14
000cb075  44897728                 mov dword ptr [rdi + 0x28], r14d
000cb079  4c897730                 mov qword ptr [rdi + 0x30], r14
000cb07d  4c897738                 mov qword ptr [rdi + 0x38], r14
000cb081  4c897740                 mov qword ptr [rdi + 0x40], r14
000cb085  4c897748                 mov qword ptr [rdi + 0x48], r14
000cb089  488d05d8be1700           lea rax, [rip + 0x17bed8]
000cb090  488907                   mov qword ptr [rdi], rax
000cb093  488d057ebd1700           lea rax, [rip + 0x17bd7e]
000cb09a  488907                   mov qword ptr [rdi], rax
000cb09d  488d0534051800           lea rax, [rip + 0x180534]
000cb0a4  488907                   mov qword ptr [rdi], rax
000cb0a7  4c89b7c8010000           mov qword ptr [rdi + 0x1c8], r14
000cb0ae  488d056bd31700           lea rax, [rip + 0x17d36b]
000cb0b5  488907                   mov qword ptr [rdi], rax
000cb0b8  4c89b7d0010000           mov qword ptr [rdi + 0x1d0], r14
000cb0bf  0f57c0                   xorps xmm0, xmm0
000cb0c2  33c0                     xor eax, eax
000cb0c4  0f1187d8010000           movups xmmword ptr [rdi + 0x1d8], xmm0
000cb0cb  0f1187e8010000           movups xmmword ptr [rdi + 0x1e8], xmm0
000cb0d2  0f1187f8010000           movups xmmword ptr [rdi + 0x1f8], xmm0
000cb0d9  0f118708020000           movups xmmword ptr [rdi + 0x208], xmm0
000cb0e0  48898718020000           mov qword ptr [rdi + 0x218], rax
000cb0e7  eb03                     jmp 0xcb0ec
000cb0e9  498bfe                   mov rdi, r14
000cb0ec  e94bfcffff               jmp 0xcad3c
000cb0f1  488bd6                   mov rdx, rsi
000cb0f4  b970060000               mov ecx, 0x670
000cb0f9  e8726bf4ff               call 0x11c70
000cb0fe  48894560                 mov qword ptr [rbp + 0x60], rax
000cb102  4885c0                   test rax, rax
000cb105  740d                     je 0xcb114
000cb107  488bc8                   mov rcx, rax
000cb10a  e811a60400               call 0x115720
000cb10f  488bd8                   mov rbx, rax
000cb112  eb03                     jmp 0xcb117
000cb114  498bde                   mov rbx, r14
000cb117  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000cb11e  c783d001000001000000     mov dword ptr [rbx + 0x1d0], 1
000cb128  4489bbd4010000           mov dword ptr [rbx + 0x1d4], r15d
000cb12f  4c89b380050000           mov qword ptr [rbx + 0x580], r14
000cb136  4489b388050000           mov dword ptr [rbx + 0x588], r14d
000cb13d  4c89b390050000           mov qword ptr [rbx + 0x590], r14
000cb144  488d8bd8010000           lea rcx, [rbx + 0x1d8]
000cb14b  4c8bcb                   mov r9, rbx
000cb14e  458bc7                   mov r8d, r15d
000cb151  498bd5                   mov rdx, r13
000cb154  e857d20900               call 0x1683b0
000cb159  e9ec0d0000               jmp 0xcbf4a
000cb15e  488bd6                   mov rdx, rsi
000cb161  b978060000               mov ecx, 0x678
000cb166  e8056bf4ff               call 0x11c70
000cb16b  48894560                 mov qword ptr [rbp + 0x60], rax
000cb16f  4885c0                   test rax, rax
000cb172  740d                     je 0xcb181
000cb174  488bc8                   mov rcx, rax
000cb177  e8e4ea0400               call 0x119c60
000cb17c  488bd8                   mov rbx, rax
000cb17f  eb03                     jmp 0xcb184
000cb181  498bde                   mov rbx, r14
000cb184  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cb18b  0f1008                   movups xmm1, xmmword ptr [rax]
000cb18e  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cb192  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000cb196  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cb19a  66480f7eca               movq rdx, xmm1
000cb19f  48c1ea20                 shr rdx, 0x20
000cb1a3  f6c201                   test dl, 1
000cb1a6  0f856bffffff             jne 0xcb117
000cb1ac  81e22ffbffff             and edx, 0xfffffb2f
000cb1b2  81ca20020000             or edx, 0x220
000cb1b8  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cb1bc  48c1e820                 shr rax, 0x20
000cb1c0  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000cb1c4  498bc8                   mov rcx, r8
000cb1c7  48c1e920                 shr rcx, 0x20
000cb1cb  49c1e810                 shr r8, 0x10
000cb1cf  89442438                 mov dword ptr [rsp + 0x38], eax
000cb1d3  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000cb1d6  89442430                 mov dword ptr [rsp + 0x30], eax
000cb1da  894c2428                 mov dword ptr [rsp + 0x28], ecx
000cb1de  664489442420             mov word ptr [rsp + 0x20], r8w
000cb1e4  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000cb1e9  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000cb1ed  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000cb1f0  e81b63f4ff               call 0x11510
000cb1f5  48898398050000           mov qword ptr [rbx + 0x598], rax
000cb1fc  4885c0                   test rax, rax
000cb1ff  0f95c0                   setne al
000cb202  84c0                     test al, al
000cb204  0f850dffffff             jne 0xcb117
000cb20a  498bde                   mov rbx, r14
000cb20d  e9d20d0000               jmp 0xcbfe4
000cb212  488bd6                   mov rdx, rsi
000cb215  b9e8050000               mov ecx, 0x5e8
000cb21a  e8516af4ff               call 0x11c70
000cb21f  488bd8                   mov rbx, rax
000cb222  48894560                 mov qword ptr [rbp + 0x60], rax
000cb226  4885c0                   test rax, rax
000cb229  0f849c000000             je 0xcb2cb
000cb22f  c7400801000000           mov dword ptr [rax + 8], 1
000cb236  488d05cbbf1700           lea rax, [rip + 0x17bfcb]
000cb23d  488903                   mov qword ptr [rbx], rax
000cb240  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000cb248  44897318                 mov dword ptr [rbx + 0x18], r14d
000cb24c  4c897320                 mov qword ptr [rbx + 0x20], r14
000cb250  44897328                 mov dword ptr [rbx + 0x28], r14d
000cb254  4c897330                 mov qword ptr [rbx + 0x30], r14
000cb258  4c897338                 mov qword ptr [rbx + 0x38], r14
000cb25c  4c897340                 mov qword ptr [rbx + 0x40], r14
000cb260  4c897348                 mov qword ptr [rbx + 0x48], r14
000cb264  488d05fdbc1700           lea rax, [rip + 0x17bcfd]
000cb26b  488903                   mov qword ptr [rbx], rax
000cb26e  488d05a3bb1700           lea rax, [rip + 0x17bba3]
000cb275  488903                   mov qword ptr [rbx], rax
000cb278  488d05d91c1800           lea rax, [rip + 0x181cd9]
000cb27f  488903                   mov qword ptr [rbx], rax
000cb282  488d054fab1900           lea rax, [rip + 0x19ab4f]
000cb289  488983d8010000           mov qword ptr [rbx + 0x1d8], rax
000cb290  488d05e1d21700           lea rax, [rip + 0x17d2e1]
000cb297  488903                   mov qword ptr [rbx], rax
000cb29a  4c89b398050000           mov qword ptr [rbx + 0x598], r14
000cb2a1  0f57c0                   xorps xmm0, xmm0
000cb2a4  33c0                     xor eax, eax
000cb2a6  0f1183a0050000           movups xmmword ptr [rbx + 0x5a0], xmm0
000cb2ad  0f1183b0050000           movups xmmword ptr [rbx + 0x5b0], xmm0
000cb2b4  0f1183c0050000           movups xmmword ptr [rbx + 0x5c0], xmm0
000cb2bb  0f1183d0050000           movups xmmword ptr [rbx + 0x5d0], xmm0
000cb2c2  488983e0050000           mov qword ptr [rbx + 0x5e0], rax
000cb2c9  eb03                     jmp 0xcb2ce
000cb2cb  498bde                   mov rbx, r14
000cb2ce  e91df8ffff               jmp 0xcaaf0
000cb2d3  488bd6                   mov rdx, rsi
000cb2d6  b9f0050000               mov ecx, 0x5f0
000cb2db  e89069f4ff               call 0x11c70
000cb2e0  488bd8                   mov rbx, rax
000cb2e3  48894560                 mov qword ptr [rbp + 0x60], rax
000cb2e7  4885c0                   test rax, rax
000cb2ea  0f84ad000000             je 0xcb39d
000cb2f0  c7400801000000           mov dword ptr [rax + 8], 1
000cb2f7  488d050abf1700           lea rax, [rip + 0x17bf0a]
000cb2fe  488903                   mov qword ptr [rbx], rax
000cb301  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000cb309  44897318                 mov dword ptr [rbx + 0x18], r14d
000cb30d  4c897320                 mov qword ptr [rbx + 0x20], r14
000cb311  44897328                 mov dword ptr [rbx + 0x28], r14d
000cb315  4c897330                 mov qword ptr [rbx + 0x30], r14
000cb319  4c897338                 mov qword ptr [rbx + 0x38], r14
000cb31d  4c897340                 mov qword ptr [rbx + 0x40], r14
000cb321  4c897348                 mov qword ptr [rbx + 0x48], r14
000cb325  488d053cbc1700           lea rax, [rip + 0x17bc3c]
000cb32c  488903                   mov qword ptr [rbx], rax
000cb32f  488d05e2ba1700           lea rax, [rip + 0x17bae2]
000cb336  488903                   mov qword ptr [rbx], rax
000cb339  488d05181c1800           lea rax, [rip + 0x181c18]
000cb340  488903                   mov qword ptr [rbx], rax
000cb343  488d058eaa1900           lea rax, [rip + 0x19aa8e]
000cb34a  488983d8010000           mov qword ptr [rbx + 0x1d8], rax
000cb351  488d0528011800           lea rax, [rip + 0x180128]
000cb358  488903                   mov qword ptr [rbx], rax
000cb35b  4c89b398050000           mov qword ptr [rbx + 0x598], r14
000cb362  488d0507ce1700           lea rax, [rip + 0x17ce07]
000cb369  488903                   mov qword ptr [rbx], rax
000cb36c  4c89b3a0050000           mov qword ptr [rbx + 0x5a0], r14
000cb373  0f57c0                   xorps xmm0, xmm0
000cb376  33c0                     xor eax, eax
000cb378  0f1183a8050000           movups xmmword ptr [rbx + 0x5a8], xmm0
000cb37f  0f1183b8050000           movups xmmword ptr [rbx + 0x5b8], xmm0
000cb386  0f1183c8050000           movups xmmword ptr [rbx + 0x5c8], xmm0
000cb38d  0f1183d8050000           movups xmmword ptr [rbx + 0x5d8], xmm0
000cb394  488983e8050000           mov qword ptr [rbx + 0x5e8], rax
000cb39b  eb03                     jmp 0xcb3a0
000cb39d  498bde                   mov rbx, r14
000cb3a0  e9bffaffff               jmp 0xcae64
000cb3a5  488bd6                   mov rdx, rsi
000cb3a8  b9f0020000               mov ecx, 0x2f0
000cb3ad  e8be68f4ff               call 0x11c70
000cb3b2  488bd8                   mov rbx, rax
000cb3b5  48894560                 mov qword ptr [rbp + 0x60], rax
000cb3b9  4885c0                   test rax, rax
000cb3bc  7444                     je 0xcb402
000cb3be  488bc8                   mov rcx, rax
000cb3c1  e84a820400               call 0x113610
000cb3c6  90                       nop
000cb3c7  488d05face1700           lea rax, [rip + 0x17cefa]
000cb3ce  488903                   mov qword ptr [rbx], rax
000cb3d1  4c89b3a0020000           mov qword ptr [rbx + 0x2a0], r14
000cb3d8  0f57c0                   xorps xmm0, xmm0
000cb3db  33c0                     xor eax, eax
000cb3dd  0f1183a8020000           movups xmmword ptr [rbx + 0x2a8], xmm0
000cb3e4  0f1183b8020000           movups xmmword ptr [rbx + 0x2b8], xmm0
000cb3eb  0f1183c8020000           movups xmmword ptr [rbx + 0x2c8], xmm0
000cb3f2  0f1183d8020000           movups xmmword ptr [rbx + 0x2d8], xmm0
000cb3f9  488983e8020000           mov qword ptr [rbx + 0x2e8], rax
000cb400  eb03                     jmp 0xcb405
000cb402  498bde                   mov rbx, r14
000cb405  e9400b0000               jmp 0xcbf4a
000cb40a  488bd6                   mov rdx, rsi
000cb40d  b9f8020000               mov ecx, 0x2f8
000cb412  e85968f4ff               call 0x11c70
000cb417  488bf8                   mov rdi, rax
000cb41a  48894560                 mov qword ptr [rbp + 0x60], rax
000cb41e  4885c0                   test rax, rax
000cb421  7444                     je 0xcb467
000cb423  488bc8                   mov rcx, rax
000cb426  e845c50400               call 0x117970
000cb42b  90                       nop
000cb42c  488d0595941900           lea rax, [rip + 0x199495]
000cb433  488907                   mov qword ptr [rdi], rax
000cb436  4c89b7a8020000           mov qword ptr [rdi + 0x2a8], r14
000cb43d  0f57c0                   xorps xmm0, xmm0
000cb440  33c0                     xor eax, eax
000cb442  0f1187b0020000           movups xmmword ptr [rdi + 0x2b0], xmm0
000cb449  0f1187c0020000           movups xmmword ptr [rdi + 0x2c0], xmm0
000cb450  0f1187d0020000           movups xmmword ptr [rdi + 0x2d0], xmm0
000cb457  0f1187e0020000           movups xmmword ptr [rdi + 0x2e0], xmm0
000cb45e  488987f0020000           mov qword ptr [rdi + 0x2f0], rax
000cb465  eb03                     jmp 0xcb46a
000cb467  498bfe                   mov rdi, r14
000cb46a  e9cdf8ffff               jmp 0xcad3c
000cb46f  488bd6                   mov rdx, rsi
000cb472  b9c0060000               mov ecx, 0x6c0
000cb477  e8f467f4ff               call 0x11c70
000cb47c  488bd8                   mov rbx, rax
000cb47f  48894560                 mov qword ptr [rbp + 0x60], rax
000cb483  4885c0                   test rax, rax
000cb486  7444                     je 0xcb4cc
000cb488  488bc8                   mov rcx, rax
000cb48b  e890a20400               call 0x115720
000cb490  90                       nop
000cb491  488d0588951900           lea rax, [rip + 0x199588]
000cb498  488903                   mov qword ptr [rbx], rax
000cb49b  4c89b370060000           mov qword ptr [rbx + 0x670], r14
000cb4a2  0f57c0                   xorps xmm0, xmm0
000cb4a5  33c0                     xor eax, eax
000cb4a7  0f118378060000           movups xmmword ptr [rbx + 0x678], xmm0
000cb4ae  0f118388060000           movups xmmword ptr [rbx + 0x688], xmm0
000cb4b5  0f118398060000           movups xmmword ptr [rbx + 0x698], xmm0
000cb4bc  0f1183a8060000           movups xmmword ptr [rbx + 0x6a8], xmm0
000cb4c3  488983b8060000           mov qword ptr [rbx + 0x6b8], rax
000cb4ca  eb03                     jmp 0xcb4cf
000cb4cc  498bde                   mov rbx, r14
000cb4cf  e943fcffff               jmp 0xcb117
000cb4d4  488bd6                   mov rdx, rsi
000cb4d7  b9c8060000               mov ecx, 0x6c8
000cb4dc  e88f67f4ff               call 0x11c70
000cb4e1  488bd8                   mov rbx, rax
000cb4e4  48894560                 mov qword ptr [rbp + 0x60], rax
000cb4e8  4885c0                   test rax, rax
000cb4eb  7444                     je 0xcb531
000cb4ed  488bc8                   mov rcx, rax
000cb4f0  e86be70400               call 0x119c60
000cb4f5  90                       nop
000cb4f6  488d0573921900           lea rax, [rip + 0x199273]
000cb4fd  488903                   mov qword ptr [rbx], rax
000cb500  4c89b378060000           mov qword ptr [rbx + 0x678], r14
000cb507  0f57c0                   xorps xmm0, xmm0
000cb50a  33c0                     xor eax, eax
000cb50c  0f118380060000           movups xmmword ptr [rbx + 0x680], xmm0
000cb513  0f118390060000           movups xmmword ptr [rbx + 0x690], xmm0
000cb51a  0f1183a0060000           movups xmmword ptr [rbx + 0x6a0], xmm0
000cb521  0f1183b0060000           movups xmmword ptr [rbx + 0x6b0], xmm0
000cb528  488983c0060000           mov qword ptr [rbx + 0x6c0], rax
000cb52f  eb03                     jmp 0xcb534
000cb531  498bde                   mov rbx, r14
000cb534  e94bfcffff               jmp 0xcb184
000cb539  488bd6                   mov rdx, rsi
000cb53c  b968030000               mov ecx, 0x368
000cb541  e82a67f4ff               call 0x11c70
000cb546  488bd8                   mov rbx, rax
000cb549  48894560                 mov qword ptr [rbp + 0x60], rax
000cb54d  4885c0                   test rax, rax
000cb550  7453                     je 0xcb5a5
000cb552  488bc8                   mov rcx, rax
000cb555  e8b6800400               call 0x113610
000cb55a  90                       nop
000cb55b  488d053e131800           lea rax, [rip + 0x18133e]
000cb562  488903                   mov qword ptr [rbx], rax
000cb565  488d8b30030000           lea rcx, [rbx + 0x330]
000cb56c  48894dc8                 mov qword ptr [rbp - 0x38], rcx
000cb570  488d4108                 lea rax, [rcx + 8]
000cb574  48894008                 mov qword ptr [rax + 8], rax
000cb578  488900                   mov qword ptr [rax], rax
000cb57b  4c897118                 mov qword ptr [rcx + 0x18], r14
000cb57f  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cb586  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cb58d  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cb595  488d05a4e51600           lea rax, [rip + 0x16e5a4]
000cb59c  488901                   mov qword ptr [rcx], rax
000cb59f  4c897130                 mov qword ptr [rcx + 0x30], r14
000cb5a3  eb03                     jmp 0xcb5a8
000cb5a5  498bde                   mov rbx, r14
000cb5a8  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000cb5af  418b4504                 mov eax, dword ptr [r13 + 4]
000cb5b3  2573020000               and eax, 0x273
000cb5b8  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000cb5bf  83f802                   cmp eax, 2
000cb5c2  7527                     jne 0xcb5eb
000cb5c4  803d255a250000           cmp byte ptr [rip + 0x255a25], 0
000cb5cb  741e                     je 0xcb5eb
000cb5cd  8b0519952400             mov eax, dword ptr [rip + 0x249519]
000cb5d3  83f801                   cmp eax, 1
000cb5d6  7613                     jbe 0xcb5eb
000cb5d8  c783c002000001000000     mov dword ptr [rbx + 0x2c0], 1
000cb5e2  448b3d03952400           mov r15d, dword ptr [rip + 0x249503]
000cb5e9  eb12                     jmp 0xcb5fd
000cb5eb  4489b3c0020000           mov dword ptr [rbx + 0x2c0], r14d
000cb5f2  418bcc                   mov ecx, r12d
000cb5f5  e8f6410700               call 0x13f7f0
000cb5fa  448bf8                   mov r15d, eax
000cb5fd  418bc7                   mov eax, r15d
000cb600  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cb608  4883e2f0                 and rdx, 0xfffffffffffffff0
000cb60c  4c89b3a0020000           mov qword ptr [rbx + 0x2a0], r14
000cb613  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cb617  0f87a1000000             ja 0xcb6be
000cb61d  0faee8                   lfence
000cb620  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb624  48c1e00d                 shl rax, 0xd
000cb628  4881faa01f0000           cmp rdx, 0x1fa0
000cb62f  762d                     jbe 0xcb65e
000cb631  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cb636  4c8bca                   mov r9, rdx
000cb639  4c8bc2                   mov r8, rdx
000cb63c  498bce                   mov rcx, r14
000cb63f  e86cd1f3ff               call 0x87b0
000cb644  66ff4614                 inc word ptr [rsi + 0x14]
000cb648  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb64c  48c1e00d                 shl rax, 0xd
000cb650  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cb655  8b4808                   mov ecx, dword ptr [rax + 8]
000cb658  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cb65c  eb52                     jmp 0xcb6b0
000cb65e  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cb663  418b4608                 mov eax, dword ptr [r14 + 8]
000cb667  483bc2                   cmp rax, rdx
000cb66a  7311                     jae 0xcb67d
000cb66c  0f1f00                   nop dword ptr [rax]
000cb66f  90                       nop
000cb670  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cb674  418b4608                 mov eax, dword ptr [r14 + 8]
000cb678  483bc2                   cmp rax, rdx
000cb67b  72f3                     jb 0xcb670
000cb67d  418b7e08                 mov edi, dword ptr [r14 + 8]
000cb681  4c8bca                   mov r9, rdx
000cb684  41b820000000             mov r8d, 0x20
000cb68a  498bce                   mov rcx, r14
000cb68d  e81ed1f3ff               call 0x87b0
000cb692  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cb696  7514                     jne 0xcb6ac
000cb698  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb69c  48c1e00d                 shl rax, 0xd
000cb6a0  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cb6a5  8b4808                   mov ecx, dword ptr [rax + 8]
000cb6a8  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cb6ac  66ff4614                 inc word ptr [rsi + 0x14]
000cb6b0  498d4610                 lea rax, [r14 + 0x10]
000cb6b4  488983a0020000           mov qword ptr [rbx + 0x2a0], rax
000cb6bb  4533f6                   xor r14d, r14d
000cb6be  4c896c2420               mov qword ptr [rsp + 0x20], r13
000cb6c3  458bcf                   mov r9d, r15d
000cb6c6  458bc4                   mov r8d, r12d
000cb6c9  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000cb6d0  488bcb                   mov rcx, rbx
000cb6d3  e8d8910700               call 0x1448b0
000cb6d8  85c0                     test eax, eax
000cb6da  0f8566080000             jne 0xcbf46
000cb6e0  498bde                   mov rbx, r14
000cb6e3  e9fc080000               jmp 0xcbfe4
000cb6e8  488bd6                   mov rdx, rsi
000cb6eb  b970030000               mov ecx, 0x370
000cb6f0  e87b65f4ff               call 0x11c70
000cb6f5  488bd8                   mov rbx, rax
000cb6f8  48894560                 mov qword ptr [rbp + 0x60], rax
000cb6fc  4885c0                   test rax, rax
000cb6ff  7453                     je 0xcb754
000cb701  488bc8                   mov rcx, rax
000cb704  e867c20400               call 0x117970
000cb709  90                       nop
000cb70a  488d05e7121800           lea rax, [rip + 0x1812e7]
000cb711  488903                   mov qword ptr [rbx], rax
000cb714  488d8b38030000           lea rcx, [rbx + 0x338]
000cb71b  48894dc8                 mov qword ptr [rbp - 0x38], rcx
000cb71f  488d4108                 lea rax, [rcx + 8]
000cb723  48894008                 mov qword ptr [rax + 8], rax
000cb727  488900                   mov qword ptr [rax], rax
000cb72a  4c897118                 mov qword ptr [rcx + 0x18], r14
000cb72e  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cb735  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cb73c  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cb744  488d05f5e31600           lea rax, [rip + 0x16e3f5]
000cb74b  488901                   mov qword ptr [rcx], rax
000cb74e  4c897130                 mov qword ptr [rcx + 0x30], r14
000cb752  eb03                     jmp 0xcb757
000cb754  498bde                   mov rbx, r14
000cb757  4c8bbd90000000           mov r15, qword ptr [rbp + 0x90]
000cb75e  418b4704                 mov eax, dword ptr [r15 + 4]
000cb762  2573020000               and eax, 0x273
000cb767  448bad88000000           mov r13d, dword ptr [rbp + 0x88]
000cb76e  83f802                   cmp eax, 2
000cb771  7527                     jne 0xcb79a
000cb773  803d7658250000           cmp byte ptr [rip + 0x255876], 0
000cb77a  741e                     je 0xcb79a
000cb77c  8b056a932400             mov eax, dword ptr [rip + 0x24936a]
000cb782  83f801                   cmp eax, 1
000cb785  7613                     jbe 0xcb79a
000cb787  c783c802000001000000     mov dword ptr [rbx + 0x2c8], 1
000cb791  448b2554932400           mov r12d, dword ptr [rip + 0x249354]
000cb798  eb12                     jmp 0xcb7ac
000cb79a  4489b3c8020000           mov dword ptr [rbx + 0x2c8], r14d
000cb7a1  418bcd                   mov ecx, r13d
000cb7a4  e847400700               call 0x13f7f0
000cb7a9  448be0                   mov r12d, eax
000cb7ac  418bc4                   mov eax, r12d
000cb7af  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cb7b7  4883e2f0                 and rdx, 0xfffffffffffffff0
000cb7bb  4c89b3a8020000           mov qword ptr [rbx + 0x2a8], r14
000cb7c2  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cb7c6  0f87a2000000             ja 0xcb86e
000cb7cc  0faee8                   lfence
000cb7cf  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb7d3  48c1e00d                 shl rax, 0xd
000cb7d7  4881faa01f0000           cmp rdx, 0x1fa0
000cb7de  762d                     jbe 0xcb80d
000cb7e0  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cb7e5  4c8bca                   mov r9, rdx
000cb7e8  4c8bc2                   mov r8, rdx
000cb7eb  498bce                   mov rcx, r14
000cb7ee  e8bdcff3ff               call 0x87b0
000cb7f3  66ff4614                 inc word ptr [rsi + 0x14]
000cb7f7  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb7fb  48c1e00d                 shl rax, 0xd
000cb7ff  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cb804  8b4808                   mov ecx, dword ptr [rax + 8]
000cb807  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cb80b  eb53                     jmp 0xcb860
000cb80d  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cb812  418b4608                 mov eax, dword ptr [r14 + 8]
000cb816  483bc2                   cmp rax, rdx
000cb819  7312                     jae 0xcb82d
000cb81b  0f1f0400                 nop dword ptr [rax + rax]
000cb81f  90                       nop
000cb820  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cb824  418b4608                 mov eax, dword ptr [r14 + 8]
000cb828  483bc2                   cmp rax, rdx
000cb82b  72f3                     jb 0xcb820
000cb82d  418b7e08                 mov edi, dword ptr [r14 + 8]
000cb831  4c8bca                   mov r9, rdx
000cb834  41b820000000             mov r8d, 0x20
000cb83a  498bce                   mov rcx, r14
000cb83d  e86ecff3ff               call 0x87b0
000cb842  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cb846  7514                     jne 0xcb85c
000cb848  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cb84c  48c1e00d                 shl rax, 0xd
000cb850  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cb855  8b4808                   mov ecx, dword ptr [rax + 8]
000cb858  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cb85c  66ff4614                 inc word ptr [rsi + 0x14]
000cb860  498d4610                 lea rax, [r14 + 0x10]
000cb864  488983a8020000           mov qword ptr [rbx + 0x2a8], rax
000cb86b  4533f6                   xor r14d, r14d
000cb86e  4c897c2420               mov qword ptr [rsp + 0x20], r15
000cb873  458bcc                   mov r9d, r12d
000cb876  458bc5                   mov r8d, r13d
000cb879  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000cb880  488bcb                   mov rcx, rbx
000cb883  e888980700               call 0x145110
000cb888  85c0                     test eax, eax
000cb88a  0f847af9ffff             je 0xcb20a
000cb890  410f100f                 movups xmm1, xmmword ptr [r15]
000cb894  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cb898  410f104710               movups xmm0, xmmword ptr [r15 + 0x10]
000cb89d  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cb8a1  66480f7eca               movq rdx, xmm1
000cb8a6  48c1ea20                 shr rdx, 0x20
000cb8aa  f6c201                   test dl, 1
000cb8ad  0f8593060000             jne 0xcbf46
000cb8b3  81e22ffbffff             and edx, 0xfffffb2f
000cb8b9  81ca20020000             or edx, 0x220
000cb8bf  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cb8c3  48c1e820                 shr rax, 0x20
000cb8c7  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000cb8cb  498bc8                   mov rcx, r8
000cb8ce  48c1e920                 shr rcx, 0x20
000cb8d2  49c1e810                 shr r8, 0x10
000cb8d6  89442438                 mov dword ptr [rsp + 0x38], eax
000cb8da  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000cb8dd  89442430                 mov dword ptr [rsp + 0x30], eax
000cb8e1  894c2428                 mov dword ptr [rsp + 0x28], ecx
000cb8e5  664489442420             mov word ptr [rsp + 0x20], r8w
000cb8eb  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000cb8f0  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000cb8f4  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000cb8f7  e8145cf4ff               call 0x11510
000cb8fc  488983c8010000           mov qword ptr [rbx + 0x1c8], rax
000cb903  4885c0                   test rax, rax
000cb906  0f95c0                   setne al
000cb909  84c0                     test al, al
000cb90b  0f8535060000             jne 0xcbf46
000cb911  498bde                   mov rbx, r14
000cb914  e9cb060000               jmp 0xcbfe4
000cb919  488bd6                   mov rdx, rsi
000cb91c  b938070000               mov ecx, 0x738
000cb921  e84a63f4ff               call 0x11c70
000cb926  488bd8                   mov rbx, rax
000cb929  48894560                 mov qword ptr [rbp + 0x60], rax
000cb92d  4885c0                   test rax, rax
000cb930  7453                     je 0xcb985
000cb932  488bc8                   mov rcx, rax
000cb935  e8e69d0400               call 0x115720
000cb93a  90                       nop
000cb93b  488d05ae0c1800           lea rax, [rip + 0x180cae]
000cb942  488903                   mov qword ptr [rbx], rax
000cb945  488d8b00070000           lea rcx, [rbx + 0x700]
000cb94c  48894dc8                 mov qword ptr [rbp - 0x38], rcx
000cb950  488d4108                 lea rax, [rcx + 8]
000cb954  48894008                 mov qword ptr [rax + 8], rax
000cb958  488900                   mov qword ptr [rax], rax
000cb95b  4c897118                 mov qword ptr [rcx + 0x18], r14
000cb95f  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cb966  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cb96d  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cb975  488d05c4e11600           lea rax, [rip + 0x16e1c4]
000cb97c  488901                   mov qword ptr [rcx], rax
000cb97f  4c897130                 mov qword ptr [rcx + 0x30], r14
000cb983  eb03                     jmp 0xcb988
000cb985  498bde                   mov rbx, r14
000cb988  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cb98f  8b4004                   mov eax, dword ptr [rax + 4]
000cb992  2573020000               and eax, 0x273
000cb997  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000cb99d  83f802                   cmp eax, 2
000cb9a0  7527                     jne 0xcb9c9
000cb9a2  803d4756250000           cmp byte ptr [rip + 0x255647], 0
000cb9a9  741e                     je 0xcb9c9
000cb9ab  8b053b912400             mov eax, dword ptr [rip + 0x24913b]
000cb9b1  83f801                   cmp eax, 1
000cb9b4  7613                     jbe 0xcb9c9
000cb9b6  c7839006000001000000     mov dword ptr [rbx + 0x690], 1
000cb9c0  448b2525912400           mov r12d, dword ptr [rip + 0x249125]
000cb9c7  eb11                     jmp 0xcb9da
000cb9c9  4489b390060000           mov dword ptr [rbx + 0x690], r14d
000cb9d0  8bcf                     mov ecx, edi
000cb9d2  e8193e0700               call 0x13f7f0
000cb9d7  448be0                   mov r12d, eax
000cb9da  418bc4                   mov eax, r12d
000cb9dd  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cb9e5  4883e2f0                 and rdx, 0xfffffffffffffff0
000cb9e9  4c89b370060000           mov qword ptr [rbx + 0x670], r14
000cb9f0  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cb9f4  0f87aa000000             ja 0xcbaa4
000cb9fa  0faee8                   lfence
000cb9fd  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cba01  48c1e00d                 shl rax, 0xd
000cba05  4881faa01f0000           cmp rdx, 0x1fa0
000cba0c  762d                     jbe 0xcba3b
000cba0e  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cba13  4c8bca                   mov r9, rdx
000cba16  4c8bc2                   mov r8, rdx
000cba19  498bce                   mov rcx, r14
000cba1c  e88fcdf3ff               call 0x87b0
000cba21  66ff4614                 inc word ptr [rsi + 0x14]
000cba25  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cba29  48c1e00d                 shl rax, 0xd
000cba2d  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cba32  8b4808                   mov ecx, dword ptr [rax + 8]
000cba35  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cba39  eb5b                     jmp 0xcba96
000cba3b  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cba40  418b4608                 mov eax, dword ptr [r14 + 8]
000cba44  483bc2                   cmp rax, rdx
000cba47  7314                     jae 0xcba5d
000cba49  0f1f00                   nop dword ptr [rax]
000cba4c  0f1f4000                 nop dword ptr [rax]
000cba50  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cba54  418b4608                 mov eax, dword ptr [r14 + 8]
000cba58  483bc2                   cmp rax, rdx
000cba5b  72f3                     jb 0xcba50
000cba5d  418b7e08                 mov edi, dword ptr [r14 + 8]
000cba61  4c8bca                   mov r9, rdx
000cba64  41b820000000             mov r8d, 0x20
000cba6a  498bce                   mov rcx, r14
000cba6d  e83ecdf3ff               call 0x87b0
000cba72  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cba76  7514                     jne 0xcba8c
000cba78  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cba7c  48c1e00d                 shl rax, 0xd
000cba80  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cba85  8b4808                   mov ecx, dword ptr [rax + 8]
000cba88  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cba8c  66ff4614                 inc word ptr [rsi + 0x14]
000cba90  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000cba96  498d4610                 lea rax, [r14 + 0x10]
000cba9a  48898370060000           mov qword ptr [rbx + 0x670], rax
000cbaa1  4533f6                   xor r14d, r14d
000cbaa4  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000cbaab  4889442420               mov qword ptr [rsp + 0x20], rax
000cbab0  458bcc                   mov r9d, r12d
000cbab3  448bc7                   mov r8d, edi
000cbab6  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000cbabd  488bcb                   mov rcx, rbx
000cbac0  e81b920700               call 0x144ce0
000cbac5  85c0                     test eax, eax
000cbac7  0f843df7ffff             je 0xcb20a
000cbacd  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000cbad4  c783d001000001000000     mov dword ptr [rbx + 0x1d0], 1
000cbade  4489bbd4010000           mov dword ptr [rbx + 0x1d4], r15d
000cbae5  48c7838005000000000000   mov qword ptr [rbx + 0x580], 0
000cbaf0  4489b388050000           mov dword ptr [rbx + 0x588], r14d
000cbaf7  4c89b390050000           mov qword ptr [rbx + 0x590], r14
000cbafe  488d8bd8010000           lea rcx, [rbx + 0x1d8]
000cbb05  4c8bcb                   mov r9, rbx
000cbb08  458bc7                   mov r8d, r15d
000cbb0b  498bd5                   mov rdx, r13
000cbb0e  e89dc80900               call 0x1683b0
000cbb13  e92e040000               jmp 0xcbf46
000cbb18  488bd6                   mov rdx, rsi
000cbb1b  b940070000               mov ecx, 0x740
000cbb20  e84b61f4ff               call 0x11c70
000cbb25  488bd8                   mov rbx, rax
000cbb28  488945c8                 mov qword ptr [rbp - 0x38], rax
000cbb2c  4885c0                   test rax, rax
000cbb2f  7453                     je 0xcbb84
000cbb31  488bc8                   mov rcx, rax
000cbb34  e827e10400               call 0x119c60
000cbb39  90                       nop
000cbb3a  488d05070c1800           lea rax, [rip + 0x180c07]
000cbb41  488903                   mov qword ptr [rbx], rax
000cbb44  488d8b08070000           lea rcx, [rbx + 0x708]
000cbb4b  48894dd0                 mov qword ptr [rbp - 0x30], rcx
000cbb4f  488d4108                 lea rax, [rcx + 8]
000cbb53  48894008                 mov qword ptr [rax + 8], rax
000cbb57  488900                   mov qword ptr [rax], rax
000cbb5a  4c897118                 mov qword ptr [rcx + 0x18], r14
000cbb5e  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cbb65  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cbb6c  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cbb74  488d05c5df1600           lea rax, [rip + 0x16dfc5]
000cbb7b  488901                   mov qword ptr [rcx], rax
000cbb7e  4c897130                 mov qword ptr [rcx + 0x30], r14
000cbb82  eb03                     jmp 0xcbb87
000cbb84  498bde                   mov rbx, r14
000cbb87  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000cbb8e  418b4504                 mov eax, dword ptr [r13 + 4]
000cbb92  2573020000               and eax, 0x273
000cbb97  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000cbb9d  83f802                   cmp eax, 2
000cbba0  7527                     jne 0xcbbc9
000cbba2  803d4754250000           cmp byte ptr [rip + 0x255447], 0
000cbba9  741e                     je 0xcbbc9
000cbbab  8b053b8f2400             mov eax, dword ptr [rip + 0x248f3b]
000cbbb1  83f801                   cmp eax, 1
000cbbb4  7613                     jbe 0xcbbc9
000cbbb6  c7839806000001000000     mov dword ptr [rbx + 0x698], 1
000cbbc0  448b25258f2400           mov r12d, dword ptr [rip + 0x248f25]
000cbbc7  eb11                     jmp 0xcbbda
000cbbc9  4489b398060000           mov dword ptr [rbx + 0x698], r14d
000cbbd0  8bcf                     mov ecx, edi
000cbbd2  e8193c0700               call 0x13f7f0
000cbbd7  448be0                   mov r12d, eax
000cbbda  418bc4                   mov eax, r12d
000cbbdd  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cbbe5  4883e2f0                 and rdx, 0xfffffffffffffff0
000cbbe9  4c89b378060000           mov qword ptr [rbx + 0x678], r14
000cbbf0  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cbbf4  0f87aa000000             ja 0xcbca4
000cbbfa  0faee8                   lfence
000cbbfd  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbc01  48c1e00d                 shl rax, 0xd
000cbc05  4881faa01f0000           cmp rdx, 0x1fa0
000cbc0c  762d                     jbe 0xcbc3b
000cbc0e  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cbc13  4c8bca                   mov r9, rdx
000cbc16  4c8bc2                   mov r8, rdx
000cbc19  498bce                   mov rcx, r14
000cbc1c  e88fcbf3ff               call 0x87b0
000cbc21  66ff4614                 inc word ptr [rsi + 0x14]
000cbc25  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbc29  48c1e00d                 shl rax, 0xd
000cbc2d  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cbc32  8b4808                   mov ecx, dword ptr [rax + 8]
000cbc35  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cbc39  eb5b                     jmp 0xcbc96
000cbc3b  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cbc40  418b4608                 mov eax, dword ptr [r14 + 8]
000cbc44  483bc2                   cmp rax, rdx
000cbc47  7314                     jae 0xcbc5d
000cbc49  0f1f00                   nop dword ptr [rax]
000cbc4c  0f1f4000                 nop dword ptr [rax]
000cbc50  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cbc54  418b4608                 mov eax, dword ptr [r14 + 8]
000cbc58  483bc2                   cmp rax, rdx
000cbc5b  72f3                     jb 0xcbc50
000cbc5d  418b7e08                 mov edi, dword ptr [r14 + 8]
000cbc61  4c8bca                   mov r9, rdx
000cbc64  41b820000000             mov r8d, 0x20
000cbc6a  498bce                   mov rcx, r14
000cbc6d  e83ecbf3ff               call 0x87b0
000cbc72  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cbc76  7514                     jne 0xcbc8c
000cbc78  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbc7c  48c1e00d                 shl rax, 0xd
000cbc80  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cbc85  8b4808                   mov ecx, dword ptr [rax + 8]
000cbc88  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cbc8c  66ff4614                 inc word ptr [rsi + 0x14]
000cbc90  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000cbc96  498d4610                 lea rax, [r14 + 0x10]
000cbc9a  48898378060000           mov qword ptr [rbx + 0x678], rax
000cbca1  4533f6                   xor r14d, r14d
000cbca4  4c896c2420               mov qword ptr [rsp + 0x20], r13
000cbca9  458bcc                   mov r9d, r12d
000cbcac  448bc7                   mov r8d, edi
000cbcaf  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000cbcb6  488bcb                   mov rcx, rbx
000cbcb9  e882980700               call 0x145540
000cbcbe  85c0                     test eax, eax
000cbcc0  0f8444f5ffff             je 0xcb20a
000cbcc6  410f104d00               movups xmm1, xmmword ptr [r13]
000cbccb  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000cbccf  410f104510               movups xmm0, xmmword ptr [r13 + 0x10]
000cbcd4  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000cbcd8  66480f7eca               movq rdx, xmm1
000cbcdd  48c1ea20                 shr rdx, 0x20
000cbce1  f6c201                   test dl, 1
000cbce4  755e                     jne 0xcbd44
000cbce6  81e22ffbffff             and edx, 0xfffffb2f
000cbcec  81ca20020000             or edx, 0x220
000cbcf2  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000cbcf6  48c1e820                 shr rax, 0x20
000cbcfa  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000cbcfe  498bc8                   mov rcx, r8
000cbd01  48c1e920                 shr rcx, 0x20
000cbd05  49c1e810                 shr r8, 0x10
000cbd09  89442438                 mov dword ptr [rsp + 0x38], eax
000cbd0d  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000cbd10  89442430                 mov dword ptr [rsp + 0x30], eax
000cbd14  894c2428                 mov dword ptr [rsp + 0x28], ecx
000cbd18  664489442420             mov word ptr [rsp + 0x20], r8w
000cbd1e  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000cbd23  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000cbd27  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000cbd2a  e8e157f4ff               call 0x11510
000cbd2f  48898398050000           mov qword ptr [rbx + 0x598], rax
000cbd36  4885c0                   test rax, rax
000cbd39  0f95c0                   setne al
000cbd3c  84c0                     test al, al
000cbd3e  0f84c6f4ffff             je 0xcb20a
000cbd44  4c89b3c8010000           mov qword ptr [rbx + 0x1c8], r14
000cbd4b  c783d001000001000000     mov dword ptr [rbx + 0x1d0], 1
000cbd55  4489bbd4010000           mov dword ptr [rbx + 0x1d4], r15d
000cbd5c  48c7838005000000000000   mov qword ptr [rbx + 0x580], 0
000cbd67  4489b388050000           mov dword ptr [rbx + 0x588], r14d
000cbd6e  4c89b390050000           mov qword ptr [rbx + 0x590], r14
000cbd75  488d8bd8010000           lea rcx, [rbx + 0x1d8]
000cbd7c  4c8bcb                   mov r9, rbx
000cbd7f  458bc7                   mov r8d, r15d
000cbd82  488b5560                 mov rdx, qword ptr [rbp + 0x60]
000cbd86  e825c60900               call 0x1683b0
000cbd8b  e9b6010000               jmp 0xcbf46
000cbd90  488bd6                   mov rdx, rsi
000cbd93  b9e0030000               mov ecx, 0x3e0
000cbd98  e8d35ef4ff               call 0x11c70
000cbd9d  488bd8                   mov rbx, rax
000cbda0  48894560                 mov qword ptr [rbp + 0x60], rax
000cbda4  4885c0                   test rax, rax
000cbda7  7453                     je 0xcbdfc
000cbda9  488bc8                   mov rcx, rax
000cbdac  e84f1e0000               call 0xcdc00
000cbdb1  90                       nop
000cbdb2  488d058f051800           lea rax, [rip + 0x18058f]
000cbdb9  488903                   mov qword ptr [rbx], rax
000cbdbc  488d8ba8030000           lea rcx, [rbx + 0x3a8]
000cbdc3  48894dd0                 mov qword ptr [rbp - 0x30], rcx
000cbdc7  488d4108                 lea rax, [rcx + 8]
000cbdcb  48894008                 mov qword ptr [rax + 8], rax
000cbdcf  488900                   mov qword ptr [rax], rax
000cbdd2  4c897118                 mov qword ptr [rcx + 0x18], r14
000cbdd6  c7412001000000           mov dword ptr [rcx + 0x20], 1
000cbddd  c7412401000000           mov dword ptr [rcx + 0x24], 1
000cbde4  48c7412801000000         mov qword ptr [rcx + 0x28], 1
000cbdec  488d054ddd1600           lea rax, [rip + 0x16dd4d]
000cbdf3  488901                   mov qword ptr [rcx], rax
000cbdf6  4c897130                 mov qword ptr [rcx + 0x30], r14
000cbdfa  eb03                     jmp 0xcbdff
000cbdfc  498bde                   mov rbx, r14
000cbdff  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000cbe06  418b4504                 mov eax, dword ptr [r13 + 4]
000cbe0a  2573020000               and eax, 0x273
000cbe0f  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000cbe16  83f802                   cmp eax, 2
000cbe19  7527                     jne 0xcbe42
000cbe1b  803dce51250000           cmp byte ptr [rip + 0x2551ce], 0
000cbe22  741e                     je 0xcbe42
000cbe24  8b05c28c2400             mov eax, dword ptr [rip + 0x248cc2]
000cbe2a  83f801                   cmp eax, 1
000cbe2d  7613                     jbe 0xcbe42
000cbe2f  c7833803000001000000     mov dword ptr [rbx + 0x338], 1
000cbe39  448b3dac8c2400           mov r15d, dword ptr [rip + 0x248cac]
000cbe40  eb12                     jmp 0xcbe54
000cbe42  4489b338030000           mov dword ptr [rbx + 0x338], r14d
000cbe49  418bcc                   mov ecx, r12d
000cbe4c  e89f390700               call 0x13f7f0
000cbe51  448bf8                   mov r15d, eax
000cbe54  418bc7                   mov eax, r15d
000cbe57  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000cbe5f  4883e2f0                 and rdx, 0xfffffffffffffff0
000cbe63  4c89b318030000           mov qword ptr [rbx + 0x318], r14
000cbe6a  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000cbe6e  0f879d000000             ja 0xcbf11
000cbe74  0faee8                   lfence
000cbe77  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbe7b  48c1e00d                 shl rax, 0xd
000cbe7f  4881faa01f0000           cmp rdx, 0x1fa0
000cbe86  762d                     jbe 0xcbeb5
000cbe88  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000cbe8d  4c8bca                   mov r9, rdx
000cbe90  4c8bc2                   mov r8, rdx
000cbe93  498bce                   mov rcx, r14
000cbe96  e815c9f3ff               call 0x87b0
000cbe9b  66ff4614                 inc word ptr [rsi + 0x14]
000cbe9f  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbea3  48c1e00d                 shl rax, 0xd
000cbea7  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cbeac  8b4808                   mov ecx, dword ptr [rax + 8]
000cbeaf  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cbeb3  eb4e                     jmp 0xcbf03
000cbeb5  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000cbeba  418b4608                 mov eax, dword ptr [r14 + 8]
000cbebe  483bc2                   cmp rax, rdx
000cbec1  730d                     jae 0xcbed0
000cbec3  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000cbec7  418b4608                 mov eax, dword ptr [r14 + 8]
000cbecb  483bc2                   cmp rax, rdx
000cbece  72f3                     jb 0xcbec3
000cbed0  418b7e08                 mov edi, dword ptr [r14 + 8]
000cbed4  4c8bca                   mov r9, rdx
000cbed7  41b820000000             mov r8d, 0x20
000cbedd  498bce                   mov rcx, r14
000cbee0  e8cbc8f3ff               call 0x87b0
000cbee5  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000cbee9  7514                     jne 0xcbeff
000cbeeb  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000cbeef  48c1e00d                 shl rax, 0xd
000cbef3  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000cbef8  8b4808                   mov ecx, dword ptr [rax + 8]
000cbefb  48894e18                 mov qword ptr [rsi + 0x18], rcx
000cbeff  66ff4614                 inc word ptr [rsi + 0x14]
000cbf03  498d4610                 lea rax, [r14 + 0x10]
000cbf07  48898318030000           mov qword ptr [rbx + 0x318], rax
000cbf0e  4533f6                   xor r14d, r14d
000cbf11  4c896c2420               mov qword ptr [rsp + 0x20], r13
000cbf16  458bcf                   mov r9d, r15d
000cbf19  458bc4                   mov r8d, r12d
000cbf1c  488bbd80000000           mov rdi, qword ptr [rbp + 0x80]
000cbf23  488bd7                   mov rdx, rdi
000cbf26  488bcb                   mov rcx, rbx
000cbf29  e8429a0700               call 0x145970
000cbf2e  85c0                     test eax, eax
000cbf30  0f84d4f2ffff             je 0xcb20a
000cbf36  440fb64744               movzx r8d, byte ptr [rdi + 0x44]
000cbf3b  498bd5                   mov rdx, r13
000cbf3e  488bcb                   mov rcx, rbx
000cbf41  e87af00400               call 0x11afc0
000cbf46  4c8b6558                 mov r12, qword ptr [rbp + 0x58]
000cbf4a  4533f6                   xor r14d, r14d
000cbf4d  4885db                   test rbx, rbx
000cbf50  0f848e000000             je 0xcbfe4
000cbf56  0fb77d70                 movzx edi, word ptr [rbp + 0x70]
000cbf5a  66897c2420               mov word ptr [rsp + 0x20], di
000cbf5f  440fb74d68               movzx r9d, word ptr [rbp + 0x68]
000cbf64  4d8bc4                   mov r8, r12
000cbf67  488bd6                   mov rdx, rsi
000cbf6a  488bcb                   mov rcx, rbx
000cbf6d  e89e5df4ff               call 0x11d10
000cbf72  48899b28010000           mov qword ptr [rbx + 0x128], rbx
000cbf79  4c89b3c0010000           mov qword ptr [rbx + 0x1c0], r14
000cbf80  4489b3b8010000           mov dword ptr [rbx + 0x1b8], r14d
000cbf87  4c89b3a8010000           mov qword ptr [rbx + 0x1a8], r14
000cbf8e  4c89b3b0010000           mov qword ptr [rbx + 0x1b0], r14
000cbf95  8d4f10                   lea ecx, [rdi + 0x10]
000cbf98  4883c110                 add rcx, 0x10
000cbf9c  4883f920                 cmp rcx, 0x20
000cbfa0  b820000000               mov eax, 0x20
000cbfa5  480f42c8                 cmovb rcx, rax
000cbfa9  48898ba0010000           mov qword ptr [rbx + 0x1a0], rcx
000cbfb0  0f57c0                   xorps xmm0, xmm0
000cbfb3  0f118330010000           movups xmmword ptr [rbx + 0x130], xmm0
000cbfba  0f118340010000           movups xmmword ptr [rbx + 0x140], xmm0
000cbfc1  0f118350010000           movups xmmword ptr [rbx + 0x150], xmm0
000cbfc8  0f118360010000           movups xmmword ptr [rbx + 0x160], xmm0
000cbfcf  0f118370010000           movups xmmword ptr [rbx + 0x170], xmm0
000cbfd6  0f118380010000           movups xmmword ptr [rbx + 0x180], xmm0
000cbfdd  0f118390010000           movups xmmword ptr [rbx + 0x190], xmm0
000cbfe4  488bc3                   mov rax, rbx
000cbfe7  488b9c24c0000000         mov rbx, qword ptr [rsp + 0xc0]
000cbfef  4881c480000000           add rsp, 0x80
000cbff6  415f                     pop r15
000cbff8  415e                     pop r14
000cbffa  415d                     pop r13
000cbffc  415c                     pop r12
000cbffe  5f                       pop rdi
000cbfff  5e                       pop rsi
000cc000  5d                       pop rbp
000cc001  c3                       ret
000cc002  90                       nop
000cc003  90                       nop
000cc004  05aa0c0071               add eax, 0x71000caa
000cc009  aa                       stosb byte ptr [rdi], al
000cc00a  0c00                     or al, 0
000cc00c  f2ae                     repne scasb al, byte ptr [rdi]
000cc00e  0c00                     or al, 0
000cc010  f1                       int1
000cc011  b00c                     mov al, 0xc
000cc013  008eaf0c0012             add byte ptr [rsi + 0x12000caf], cl
000cc019  b20c                     mov dl, 0xc
000cc01b  00a5b30c006f             add byte ptr [rbp + 0x6f000cb3], ah
000cc021  b40c                     mov ah, 0xc
000cc023  00e4                     add ah, ah
000cc025  bf0c00e4bf               mov edi, 0xbfe4000c
000cc02a  0c00                     or al, 0
000cc02c  39b50c0019b9             cmp dword ptr [rbp - 0x46e6fff4], esi
000cc032  0c00                     or al, 0
000cc034  e4bf                     in al, 0xbf
000cc036  0c00                     or al, 0
000cc038  e4bf                     in al, 0xbf
000cc03a  0c00                     or al, 0
000cc03c  e4bf                     in al, 0xbf
000cc03e  0c00                     or al, 0
000cc040  e4bf                     in al, 0xbf
000cc042  0c00                     or al, 0
