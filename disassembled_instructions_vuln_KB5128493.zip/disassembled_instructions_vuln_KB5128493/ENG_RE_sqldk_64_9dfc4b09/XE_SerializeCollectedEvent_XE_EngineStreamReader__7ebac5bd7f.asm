; XE_SerializeCollectedEvent<XE_EngineStreamReader>
; sqldk.dll, primary RVA 0x21c90, 443 bytes in 5 chunk(s)

; chunk at RVA 0x21c90 (20 bytes)
00021c90  4c894c2420               mov qword ptr [rsp + 0x20], r9
00021c95  53                       push rbx
00021c96  55                       push rbp
00021c97  4155                     push r13
00021c99  4156                     push r14
00021c9b  4157                     push r15
00021c9d  4883ec40                 sub rsp, 0x40
00021ca1  4d8be8                   mov r13, r8

; chunk at RVA 0x21ca4 (163 bytes)
00021ca4  48897c2430               mov qword ptr [rsp + 0x30], rdi
00021ca9  8bfa                     mov edi, edx
00021cab  4c8d7918                 lea r15, [rcx + 0x18]
00021caf  8b5104                   mov edx, dword ptr [rcx + 4]
00021cb2  4533f6                   xor r14d, r14d
00021cb5  83e2ca                   and edx, 0xffffffca
00021cb8  4c89bc2480000000         mov qword ptr [rsp + 0x80], r15
00021cc0  83ca0a                   or edx, 0xa
00021cc3  4803f9                   add rdi, rcx
00021cc6  895104                   mov dword ptr [rcx + 4], edx
00021cc9  418bee                   mov ebp, r14d
00021ccc  418b4104                 mov eax, dword ptr [r9 + 4]
00021cd0  8901                     mov dword ptr [rcx], eax
00021cd2  418b4008                 mov eax, dword ptr [r8 + 8]
00021cd6  41b800000080             mov r8d, 0x80000000
00021cdc  894114                   mov dword ptr [rcx + 0x14], eax
00021cdf  418bc6                   mov eax, r14d
00021ce2  6641394504               cmp word ptr [r13 + 4], ax
00021ce7  48897c2470               mov qword ptr [rsp + 0x70], rdi
00021cec  410f47c0                 cmova eax, r8d
00021cf0  0fbaf21f                 btr edx, 0x1f
00021cf4  0bc2                     or eax, edx
00021cf6  894104                   mov dword ptr [rcx + 4], eax
00021cf9  8b842490000000           mov eax, dword ptr [rsp + 0x90]
00021d00  894108                   mov dword ptr [rcx + 8], eax
00021d03  498b4520                 mov rax, qword ptr [r13 + 0x20]
00021d07  4889410c                 mov qword ptr [rcx + 0xc], rax
00021d0b  6641396d02               cmp word ptr [r13 + 2], bp
00021d10  0f86da000000             jbe 0x21df0
00021d16  498b5510                 mov rdx, qword ptr [r13 + 0x10]
00021d1a  498bcf                   mov rcx, r15
00021d1d  448b4208                 mov r8d, dword ptr [rdx + 8]
00021d21  488b12                   mov rdx, qword ptr [rdx]
00021d24  e8d7fefdff               call 0x1c00
00021d29  498b4510                 mov rax, qword ptr [r13 + 0x10]
00021d2d  b901000000               mov ecx, 1
00021d32  898c2490000000           mov dword ptr [rsp + 0x90], ecx
00021d39  8b6808                   mov ebp, dword ptr [rax + 8]
00021d3c  66413b4d02               cmp cx, word ptr [r13 + 2]
00021d41  0f83a9000000             jae 0x21df0

; chunk at RVA 0x21d47 (169 bytes)
00021d47  4889742438               mov qword ptr [rsp + 0x38], rsi
00021d4c  4c89642428               mov qword ptr [rsp + 0x28], r12
00021d51  0f1f4000                 nop dword ptr [rax]
00021d55  6666660f1f840000000000   nop word ptr [rax + rax]
00021d60  8bd9                     mov ebx, ecx
00021d62  48c1e304                 shl rbx, 4
00021d66  49035d10                 add rbx, qword ptr [r13 + 0x10]
00021d6a  448be5                   mov r12d, ebp
00021d6d  4d03e7                   add r12, r15
00021d70  448b7b08                 mov r15d, dword ptr [rbx + 8]
00021d74  664439730e               cmp word ptr [rbx + 0xe], r14w
00021d79  0f8521c91c00             jne 0x1ee6a0
00021d7f  488b13                   mov rdx, qword ptr [rbx]
00021d82  8bc7                     mov eax, edi
00021d84  412bc4                   sub eax, r12d
00021d87  498bcc                   mov rcx, r12
00021d8a  443bf8                   cmp r15d, eax
00021d8d  440f43f8                 cmovae r15d, eax
00021d91  458bc7                   mov r8d, r15d
00021d94  e867fefdff               call 0x1c00
00021d99  0fb7430c                 movzx eax, word ptr [rbx + 0xc]
00021d9d  4c8bbc2480000000         mov r15, qword ptr [rsp + 0x80]
00021da5  488d0c80                 lea rcx, [rax + rax*4]
00021da9  488b842488000000         mov rax, qword ptr [rsp + 0x88]
00021db1  488b4040                 mov rax, qword ptr [rax + 0x40]
00021db5  0fb754c810               movzx edx, word ptr [rax + rcx*8 + 0x10]
00021dba  8b8c2490000000           mov ecx, dword ptr [rsp + 0x90]
00021dc1  ffc1                     inc ecx
00021dc3  898c2490000000           mov dword ptr [rsp + 0x90], ecx
00021dca  42892c3a                 mov dword ptr [rdx + r15], ebp
00021dce  8b4308                   mov eax, dword ptr [rbx + 8]
00021dd1  4289443a04               mov dword ptr [rdx + r15 + 4], eax
00021dd6  036b08                   add ebp, dword ptr [rbx + 8]
00021dd9  410fb74502               movzx eax, word ptr [r13 + 2]
00021dde  3bc8                     cmp ecx, eax
00021de0  0f827affffff             jb 0x21d60
00021de6  4c8b642428               mov r12, qword ptr [rsp + 0x28]
00021deb  488b742438               mov rsi, qword ptr [rsp + 0x38]

; chunk at RVA 0x21df0 (16 bytes)
00021df0  488b7c2430               mov rdi, qword ptr [rsp + 0x30]
00021df5  6645397504               cmp word ptr [r13 + 4], r14w
00021dfa  0f87a65f0100             ja 0x37da6

; chunk at RVA 0x37db0 (75 bytes)
00037db0  8bcd                     mov ecx, ebp
00037db2  83c508                   add ebp, 8
00037db5  418bde                   mov ebx, r14d
00037db8  48c1e304                 shl rbx, 4
00037dbc  49035d18                 add rbx, qword ptr [r13 + 0x18]
00037dc0  488b03                   mov rax, qword ptr [rbx]
00037dc3  4a890439                 mov qword ptr [rcx + r15], rax
00037dc7  448b4304                 mov r8d, dword ptr [rbx + 4]
00037dcb  488b5308                 mov rdx, qword ptr [rbx + 8]
00037dcf  8bcd                     mov ecx, ebp
00037dd1  4903cf                   add rcx, r15
00037dd4  e8279efcff               call 0x1c00
00037dd9  410fb74504               movzx eax, word ptr [r13 + 4]
00037dde  41ffc6                   inc r14d
00037de1  036b04                   add ebp, dword ptr [rbx + 4]
00037de4  443bf0                   cmp r14d, eax
00037de7  72c7                     jb 0x37db0
00037de9  488b05f8272400           mov rax, qword ptr [rip + 0x2427f8]
00037df0  4a89443d00               mov qword ptr [rbp + r15], rax
00037df5  e906a0feff               jmp 0x21e00
00037dfa  cc                       int3
