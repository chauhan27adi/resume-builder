; `XE_CXFileWriter::OpenWriter'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2172c0, 37 bytes in 1 chunk(s)

; chunk at RVA 0x2172c0 (37 bytes)
002172c0  4055                     push rbp
002172c2  4883ec20                 sub rsp, 0x20
002172c6  488bea                   mov rbp, rdx
002172c9  4533c0                   xor r8d, r8d
002172cc  488b9590040000           mov rdx, qword ptr [rbp + 0x490]
002172d3  488b8da0040000           mov rcx, qword ptr [rbp + 0x4a0]
002172da  e8319ddeff               call 0x1010
002172df  4883c420                 add rsp, 0x20
002172e3  5d                       pop rbp
002172e4  c3                       ret
