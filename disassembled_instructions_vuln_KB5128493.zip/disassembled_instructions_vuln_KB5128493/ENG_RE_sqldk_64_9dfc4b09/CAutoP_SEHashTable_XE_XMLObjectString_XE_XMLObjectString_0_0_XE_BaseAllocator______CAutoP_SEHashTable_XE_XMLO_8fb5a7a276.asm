; CAutoP<SEHashTable<XE_XMLObjectString,XE_XMLObjectString,0,0,XE_BaseAllocator> >::~CAutoP<SEHashTable<XE_XMLObjectString,XE_XMLObjectString,0,0,XE_BaseAllocator> >
; sqldk.dll, primary RVA 0x1c7560, 60 bytes in 1 chunk(s)

; chunk at RVA 0x1c7560 (60 bytes)
001c7560  4053                     push rbx
001c7562  4883ec20                 sub rsp, 0x20
001c7566  488b19                   mov rbx, qword ptr [rcx]
001c7569  4885db                   test rbx, rbx
001c756c  7428                     je 0x1c7596
001c756e  488b0b                   mov rcx, qword ptr [rbx]
001c7571  4885c9                   test rcx, rcx
001c7574  740e                     je 0x1c7584
001c7576  ff15d4da1400             call qword ptr [rip + 0x14dad4]
001c757c  33c0                     xor eax, eax
001c757e  488903                   mov qword ptr [rbx], rax
001c7581  894308                   mov dword ptr [rbx + 8], eax
001c7584  ba20000000               mov edx, 0x20
001c7589  488bcb                   mov rcx, rbx
001c758c  4883c420                 add rsp, 0x20
001c7590  5b                       pop rbx
001c7591  e95a08e4ff               jmp 0x7df0
001c7596  4883c420                 add rsp, 0x20
001c759a  5b                       pop rbx
001c759b  c3                       ret
