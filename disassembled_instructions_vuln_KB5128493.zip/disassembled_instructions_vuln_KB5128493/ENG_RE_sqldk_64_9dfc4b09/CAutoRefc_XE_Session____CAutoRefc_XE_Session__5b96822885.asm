; CAutoRefc<XE_Session>::~CAutoRefc<XE_Session>
; sqldk.dll, primary RVA 0x1e7670, 67 bytes in 1 chunk(s)

; chunk at RVA 0x1e7670 (67 bytes)
001e7670  4053                     push rbx
001e7672  4883ec20                 sub rsp, 0x20
001e7676  488b19                   mov rbx, qword ptr [rcx]
001e7679  4885db                   test rbx, rbx
001e767c  742f                     je 0x1e76ad
001e767e  b8ffffffff               mov eax, 0xffffffff
001e7683  f00fc14318               lock xadd dword ptr [rbx + 0x18], eax
001e7688  83f801                   cmp eax, 1
001e768b  7520                     jne 0x1e76ad
001e768d  48837b1000               cmp qword ptr [rbx + 0x10], 0
001e7692  740c                     je 0x1e76a0
001e7694  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
001e7698  488bd3                   mov rdx, rbx
001e769b  e8e0180000               call 0x1e8f80
001e76a0  488bcb                   mov rcx, rbx
001e76a3  4883c420                 add rsp, 0x20
001e76a7  5b                       pop rbx
001e76a8  e9d35e0000               jmp 0x1ed580
001e76ad  4883c420                 add rsp, 0x20
001e76b1  5b                       pop rbx
001e76b2  c3                       ret
