; UtilDbccTraceOn
; sqldk.dll, primary RVA 0x1b4790, 377 bytes in 1 chunk(s)

; chunk at RVA 0x1b4790 (377 bytes)
001b4790  48895c2408               mov qword ptr [rsp + 8], rbx
001b4795  4889742410               mov qword ptr [rsp + 0x10], rsi
001b479a  57                       push rdi
001b479b  4883ec20                 sub rsp, 0x20
001b479f  0fbff2                   movsx esi, dx
001b47a2  8bd9                     mov ebx, ecx
001b47a4  4183f8ff                 cmp r8d, -1
001b47a8  0f840c010000             je 0x1b48ba
001b47ae  4585c0                   test r8d, r8d
001b47b1  7508                     jne 0x1b47bb
001b47b3  81f9ac3f0000             cmp ecx, 0x3fac
001b47b9  7212                     jb 0x1b47cd
001b47bb  32c0                     xor al, al
001b47bd  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001b47c2  488b742438               mov rsi, qword ptr [rsp + 0x38]
001b47c7  4883c420                 add rsp, 0x20
001b47cb  5f                       pop rdi
001b47cc  c3                       ret
001b47cd  4585c9                   test r9d, r9d
001b47d0  7410                     je 0x1b47e2
001b47d2  e869090000               call 0x1b5140
001b47d7  4885c0                   test rax, rax
001b47da  7406                     je 0x1b47e2
001b47dc  83780c00                 cmp dword ptr [rax + 0xc], 0
001b47e0  74d9                     je 0x1b47bb
001b47e2  488b0d0fd81700           mov rcx, qword ptr [rip + 0x17d80f]
001b47e9  488b01                   mov rax, qword ptr [rcx]
001b47ec  ff5020                   call qword ptr [rax + 0x20]
001b47ef  33d2                     xor edx, edx
001b47f1  4c8bc0                   mov r8, rax
001b47f4  4885c0                   test rax, rax
001b47f7  7467                     je 0x1b4860
001b47f9  b8cdcccccc               mov eax, 0xcccccccd
001b47fe  f7e3                     mul ebx
001b4800  8bc3                     mov eax, ebx
001b4802  c1ea03                   shr edx, 3
001b4805  8d0c92                   lea ecx, [rdx + rdx*4]
001b4808  03c9                     add ecx, ecx
001b480a  2bc1                     sub eax, ecx
001b480c  4c8d0c8500000000         lea r9, [rax*4]
001b4814  0f1f4000                 nop dword ptr [rax]
001b4818  0f1f840000000000         nop dword ptr [rax + rax]
001b4820  438b440104               mov eax, dword ptr [r9 + r8 + 4]
001b4825  85c0                     test eax, eax
001b4827  0f8486000000             je 0x1b48b3
001b482d  3bc3                     cmp eax, ebx
001b482f  7478                     je 0x1b48a9
001b4831  33d2                     xor edx, edx
001b4833  498d4004                 lea rax, [r8 + 4]
001b4837  33c9                     xor ecx, ecx
001b4839  0f1f8000000000           nop dword ptr [rax]
001b4840  833800                   cmp dword ptr [rax], 0
001b4843  7469                     je 0x1b48ae
001b4845  ffc2                     inc edx
001b4847  48ffc1                   inc rcx
001b484a  4883c004                 add rax, 4
001b484e  4883f90a                 cmp rcx, 0xa
001b4852  7cec                     jl 0x1b4840
001b4854  498bd0                   mov rdx, r8
001b4857  4d8b4030                 mov r8, qword ptr [r8 + 0x30]
001b485b  4d85c0                   test r8, r8
001b485e  75c0                     jne 0x1b4820
001b4860  488b0d91d71700           mov rcx, qword ptr [rip + 0x17d791]
001b4867  488b01                   mov rax, qword ptr [rcx]
001b486a  ff5018                   call qword ptr [rax + 0x18]
001b486d  4c8bc0                   mov r8, rax
001b4870  4885c0                   test rax, rax
001b4873  0f8442ffffff             je 0x1b47bb
001b4879  b8cdcccccc               mov eax, 0xcccccccd
001b487e  f7e3                     mul ebx
001b4880  8bc3                     mov eax, ebx
001b4882  c1ea03                   shr edx, 3
001b4885  8d0c92                   lea ecx, [rdx + rdx*4]
001b4888  03c9                     add ecx, ecx
001b488a  2bc1                     sub eax, ecx
001b488c  41895c8004               mov dword ptr [r8 + rax*4 + 4], ebx
001b4891  488b0d60d71700           mov rcx, qword ptr [rip + 0x17d760]
001b4898  41b901000000             mov r9d, 1
001b489e  4533c0                   xor r8d, r8d
001b48a1  8bd3                     mov edx, ebx
001b48a3  488b01                   mov rax, qword ptr [rcx]
001b48a6  ff5010                   call qword ptr [rax + 0x10]
001b48a9  40b701                   mov dil, 1
001b48ac  eb1b                     jmp 0x1b48c9
001b48ae  4863c2                   movsxd rax, edx
001b48b1  ebd9                     jmp 0x1b488c
001b48b3  43895c0104               mov dword ptr [r9 + r8 + 4], ebx
001b48b8  ebd7                     jmp 0x1b4891
001b48ba  418bd1                   mov edx, r9d
001b48bd  e8eef7ffff               call 0x1b40b0
001b48c2  0fb6f8                   movzx edi, al
001b48c5  84c0                     test al, al
001b48c7  7430                     je 0x1b48f9
001b48c9  488b0d28d71700           mov rcx, qword ptr [rip + 0x17d728]
001b48d0  488b11                   mov rdx, qword ptr [rcx]
001b48d3  ff12                     call qword ptr [rdx]
001b48d5  f6803901000002           test byte ptr [rax + 0x139], 2
001b48dc  7517                     jne 0x1b48f5
001b48de  81fbc9090000             cmp ebx, 0x9c9
001b48e4  740f                     je 0x1b48f5
001b48e6  448bc6                   mov r8d, esi
001b48e9  8bd3                     mov edx, ebx
001b48eb  b98e440000               mov ecx, 0x448e
001b48f0  e8eb2c0000               call 0x1b75e0
001b48f5  400fb6c7                 movzx eax, dil
001b48f9  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001b48fe  488b742438               mov rsi, qword ptr [rsp + 0x38]
001b4903  4883c420                 add rsp, 0x20
001b4907  5f                       pop rdi
001b4908  c3                       ret
