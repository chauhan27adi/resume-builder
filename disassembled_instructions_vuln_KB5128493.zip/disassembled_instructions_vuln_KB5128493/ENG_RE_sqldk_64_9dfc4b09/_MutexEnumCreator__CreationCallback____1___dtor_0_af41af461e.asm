; `MutexEnumCreator::CreationCallback'::`1'::dtor$0
; sqldk.dll, primary RVA 0x21c5a0, 53 bytes in 1 chunk(s)

; chunk at RVA 0x21c5a0 (53 bytes)
0021c5a0  4055                     push rbp
0021c5a2  4883ec30                 sub rsp, 0x30
0021c5a6  488bea                   mov rbp, rdx
0021c5a9  c644242806               mov byte ptr [rsp + 0x28], 6
0021c5ae  8b4550                   mov eax, dword ptr [rbp + 0x50]
0021c5b1  89442420                 mov dword ptr [rsp + 0x20], eax
0021c5b5  4c8d0da4c70700           lea r9, [rip + 0x7c7a4]
0021c5bc  41b801000000             mov r8d, 1
0021c5c2  488b5558                 mov rdx, qword ptr [rbp + 0x58]
0021c5c6  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0021c5ca  e8d1b7deff               call 0x7da0
0021c5cf  4883c430                 add rsp, 0x30
0021c5d3  5d                       pop rbp
0021c5d4  c3                       ret
