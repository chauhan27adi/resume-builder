; SOS_NoForceRemoveStoreController::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x179fe0, 63 bytes in 1 chunk(s)

; chunk at RVA 0x179fe0 (63 bytes)
00179fe0  48894c2408               mov qword ptr [rsp + 8], rcx
00179fe5  53                       push rbx
00179fe6  4883ec30                 sub rsp, 0x30
00179fea  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00179ff3  488bd9                   mov rbx, rcx
00179ff6  488d05635c0d00           lea rax, [rip + 0xd5c63]
00179ffd  488901                   mov qword ptr [rcx], rax
0017a000  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
0017a007  f6c201                   test dl, 1
0017a00a  740a                     je 0x17a016
0017a00c  ba10000000               mov edx, 0x10
0017a011  e8dadde8ff               call 0x7df0
0017a016  488bc3                   mov rax, rbx
0017a019  4883c430                 add rsp, 0x30
0017a01d  5b                       pop rbx
0017a01e  c3                       ret
