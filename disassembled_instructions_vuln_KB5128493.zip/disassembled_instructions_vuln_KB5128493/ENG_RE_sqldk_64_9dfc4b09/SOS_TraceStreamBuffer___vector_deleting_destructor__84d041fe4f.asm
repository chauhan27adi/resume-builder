; SOS_TraceStreamBuffer::`vector deleting destructor'
; sqldk.dll, primary RVA 0x57d00, 67 bytes in 1 chunk(s)

; chunk at RVA 0x57d00 (67 bytes)
00057d00  48894c2408               mov qword ptr [rsp + 8], rcx
00057d05  57                       push rdi
00057d06  4883ec30                 sub rsp, 0x30
00057d0a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00057d13  48895c2448               mov qword ptr [rsp + 0x48], rbx
00057d18  8bda                     mov ebx, edx
00057d1a  488bf9                   mov rdi, rcx
00057d1d  ff15a51a1e00             call qword ptr [rip + 0x1e1aa5]
00057d23  f6c301                   test bl, 1
00057d26  740d                     je 0x57d35
00057d28  ba68000000               mov edx, 0x68
00057d2d  488bcf                   mov rcx, rdi
00057d30  e8bb00fbff               call 0x7df0
00057d35  488bc7                   mov rax, rdi
00057d38  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00057d3d  4883c430                 add rsp, 0x30
00057d41  5f                       pop rdi
00057d42  c3                       ret
