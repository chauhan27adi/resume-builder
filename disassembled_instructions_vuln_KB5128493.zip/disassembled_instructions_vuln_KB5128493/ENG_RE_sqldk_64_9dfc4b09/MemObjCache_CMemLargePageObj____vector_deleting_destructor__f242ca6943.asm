; MemObjCache<CMemLargePageObj>::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13ea50, 131 bytes in 1 chunk(s)

; chunk at RVA 0x13ea50 (131 bytes)
0013ea50  48894c2408               mov qword ptr [rsp + 8], rcx
0013ea55  57                       push rdi
0013ea56  4883ec30                 sub rsp, 0x30
0013ea5a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013ea63  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013ea68  8bda                     mov ebx, edx
0013ea6a  488bf9                   mov rdi, rcx
0013ea6d  488d05b49d1000           lea rax, [rip + 0x109db4]
0013ea74  488901                   mov qword ptr [rcx], rax
0013ea77  488d059a831000           lea rax, [rip + 0x10839a]
0013ea7e  488901                   mov qword ptr [rcx], rax
0013ea81  488d05e0841000           lea rax, [rip + 0x1084e0]
0013ea88  488901                   mov qword ptr [rcx], rax
0013ea8b  488d0576871000           lea rax, [rip + 0x108776]
0013ea92  488901                   mov qword ptr [rcx], rax
0013ea95  4883c138                 add rcx, 0x38
0013ea99  e85237edff               call 0x121f0
0013ea9e  90                       nop
0013ea9f  488d4f30                 lea rcx, [rdi + 0x30]
0013eaa3  e84837edff               call 0x121f0
0013eaa8  90                       nop
0013eaa9  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013eab0  83e305                   and ebx, 5
0013eab3  80fb05                   cmp bl, 5
0013eab6  750d                     jne 0x13eac5
0013eab8  ba18020000               mov edx, 0x218
0013eabd  488bcf                   mov rcx, rdi
0013eac0  e84b25ecff               call 0x1010
0013eac5  488bc7                   mov rax, rdi
0013eac8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013eacd  4883c430                 add rsp, 0x30
0013ead1  5f                       pop rdi
0013ead2  c3                       ret
