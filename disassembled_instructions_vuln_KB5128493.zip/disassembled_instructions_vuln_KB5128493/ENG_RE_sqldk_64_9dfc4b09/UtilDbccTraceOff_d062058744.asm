; UtilDbccTraceOff
; sqldk.dll, primary RVA 0x1b4650, 306 bytes in 1 chunk(s)

; chunk at RVA 0x1b4650 (306 bytes)
001b4650  48895c2408               mov qword ptr [rsp + 8], rbx
001b4655  4889742410               mov qword ptr [rsp + 0x10], rsi
001b465a  57                       push rdi
001b465b  4883ec20                 sub rsp, 0x20
001b465f  0fbff2                   movsx esi, dx
001b4662  8bd9                     mov ebx, ecx
001b4664  4183f8ff                 cmp r8d, -1
001b4668  0f84c5000000             je 0x1b4733
001b466e  4585c0                   test r8d, r8d
001b4671  7508                     jne 0x1b467b
001b4673  81f9ac3f0000             cmp ecx, 0x3fac
001b4679  7212                     jb 0x1b468d
001b467b  32c0                     xor al, al
001b467d  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001b4682  488b742438               mov rsi, qword ptr [rsp + 0x38]
001b4687  4883c420                 add rsp, 0x20
001b468b  5f                       pop rdi
001b468c  c3                       ret
001b468d  4585c9                   test r9d, r9d
001b4690  7410                     je 0x1b46a2
001b4692  e8a90a0000               call 0x1b5140
001b4697  4885c0                   test rax, rax
001b469a  7406                     je 0x1b46a2
001b469c  83780c00                 cmp dword ptr [rax + 0xc], 0
001b46a0  74d9                     je 0x1b467b
001b46a2  488b0d4fd91700           mov rcx, qword ptr [rip + 0x17d94f]
001b46a9  488b01                   mov rax, qword ptr [rcx]
001b46ac  ff5020                   call qword ptr [rax + 0x20]
001b46af  4c8bc0                   mov r8, rax
001b46b2  4885c0                   test rax, rax
001b46b5  7477                     je 0x1b472e
001b46b7  b8cdcccccc               mov eax, 0xcccccccd
001b46bc  f7e3                     mul ebx
001b46be  8bc3                     mov eax, ebx
001b46c0  c1ea03                   shr edx, 3
001b46c3  8d0c92                   lea ecx, [rdx + rdx*4]
001b46c6  03c9                     add ecx, ecx
001b46c8  2bc1                     sub eax, ecx
001b46ca  4533d2                   xor r10d, r10d
001b46cd  4c8d0c8500000000         lea r9, [rax*4]
001b46d5  43395c0104               cmp dword ptr [r9 + r8 + 4], ebx
001b46da  7435                     je 0x1b4711
001b46dc  418bd2                   mov edx, r10d
001b46df  498d4004                 lea rax, [r8 + 4]
001b46e3  498bca                   mov rcx, r10
001b46e6  3918                     cmp dword ptr [rax], ebx
001b46e8  741d                     je 0x1b4707
001b46ea  ffc2                     inc edx
001b46ec  48ffc1                   inc rcx
001b46ef  4883c004                 add rax, 4
001b46f3  4883f90a                 cmp rcx, 0xa
001b46f7  7ced                     jl 0x1b46e6
001b46f9  4d8b4030                 mov r8, qword ptr [r8 + 0x30]
001b46fd  4d85c0                   test r8, r8
001b4700  75d3                     jne 0x1b46d5
001b4702  40b701                   mov dil, 1
001b4705  eb3b                     jmp 0x1b4742
001b4707  4863c2                   movsxd rax, edx
001b470a  4589548004               mov dword ptr [r8 + rax*4 + 4], r10d
001b470f  eb05                     jmp 0x1b4716
001b4711  4789540104               mov dword ptr [r9 + r8 + 4], r10d
001b4716  488b0ddbd81700           mov rcx, qword ptr [rip + 0x17d8db]
001b471d  41b901000000             mov r9d, 1
001b4723  458bc1                   mov r8d, r9d
001b4726  8bd3                     mov edx, ebx
001b4728  488b01                   mov rax, qword ptr [rcx]
001b472b  ff5010                   call qword ptr [rax + 0x10]
001b472e  40b701                   mov dil, 1
001b4731  eb0f                     jmp 0x1b4742
001b4733  418bd1                   mov edx, r9d
001b4736  e835fcffff               call 0x1b4370
001b473b  0fb6f8                   movzx edi, al
001b473e  84c0                     test al, al
001b4740  7430                     je 0x1b4772
001b4742  488b0dafd81700           mov rcx, qword ptr [rip + 0x17d8af]
001b4749  488b11                   mov rdx, qword ptr [rcx]
001b474c  ff12                     call qword ptr [rdx]
001b474e  f6803901000002           test byte ptr [rax + 0x139], 2
001b4755  7517                     jne 0x1b476e
001b4757  81fbc9090000             cmp ebx, 0x9c9
001b475d  740f                     je 0x1b476e
001b475f  448bc6                   mov r8d, esi
001b4762  8bd3                     mov edx, ebx
001b4764  b98f440000               mov ecx, 0x448f
001b4769  e8722e0000               call 0x1b75e0
001b476e  400fb6c7                 movzx eax, dil
001b4772  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001b4777  488b742438               mov rsi, qword ptr [rsp + 0x38]
001b477c  4883c420                 add rsp, 0x20
001b4780  5f                       pop rdi
001b4781  c3                       ret
