; XE_Session::~XE_Session
; sqldk.dll, primary RVA 0x1ead70, 352 bytes in 1 chunk(s)

; chunk at RVA 0x1ead70 (352 bytes)
001ead70  48894c2408               mov qword ptr [rsp + 8], rcx
001ead75  53                       push rbx
001ead76  56                       push rsi
001ead77  57                       push rdi
001ead78  4883ec30                 sub rsp, 0x30
001ead7c  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001ead85  488bf9                   mov rdi, rcx
001ead88  488d05f1fe0800           lea rax, [rip + 0x8fef1]
001ead8f  488901                   mov qword ptr [rcx], rax
001ead92  4881c140080000           add rcx, 0x840
001ead99  e822910000               call 0x1f3ec0
001ead9e  90                       nop
001ead9f  488d8798060000           lea rax, [rdi + 0x698]
001eada6  4889442458               mov qword ptr [rsp + 0x58], rax
001eadab  488d0d8eed0400           lea rcx, [rip + 0x4ed8e]
001eadb2  488908                   mov qword ptr [rax], rcx
001eadb5  488d8768050000           lea rax, [rdi + 0x568]
001eadbc  4889442460               mov qword ptr [rsp + 0x60], rax
001eadc1  488908                   mov qword ptr [rax], rcx
001eadc4  488b9fd8040000           mov rbx, qword ptr [rdi + 0x4d8]
001eadcb  beffffffff               mov esi, 0xffffffff
001eadd0  4885db                   test rbx, rbx
001eadd3  742d                     je 0x1eae02
001eadd5  8bc6                     mov eax, esi
001eadd7  f00fc103                 lock xadd dword ptr [rbx], eax
001eaddb  83f801                   cmp eax, 1
001eadde  7522                     jne 0x1eae02
001eade0  48895c2458               mov qword ptr [rsp + 0x58], rbx
001eade5  488bcb                   mov rcx, rbx
001eade8  e8a37e0000               call 0x1f2c90
001eaded  90                       nop
001eadee  c703adde0080             mov dword ptr [rbx], 0x8000dead
001eadf4  ba88000000               mov edx, 0x88
001eadf9  488bcb                   mov rcx, rbx
001eadfc  e8efcfe1ff               call 0x7df0
001eae01  90                       nop
001eae02  488b8fd0040000           mov rcx, qword ptr [rdi + 0x4d0]
001eae09  4885c9                   test rcx, rcx
001eae0c  741f                     je 0x1eae2d
001eae0e  8bc6                     mov eax, esi
001eae10  f00fc101                 lock xadd dword ptr [rcx], eax
001eae14  83f801                   cmp eax, 1
001eae17  7514                     jne 0x1eae2d
001eae19  48894c2458               mov qword ptr [rsp + 0x58], rcx
001eae1e  c701adde0080             mov dword ptr [rcx], 0x8000dead
001eae24  8d502f                   lea edx, [rax + 0x2f]
001eae27  e8c4cfe1ff               call 0x7df0
001eae2c  90                       nop
001eae2d  488b8fc8040000           mov rcx, qword ptr [rdi + 0x4c8]
001eae34  4885c9                   test rcx, rcx
001eae37  742c                     je 0x1eae65
001eae39  488d59f8                 lea rbx, [rcx - 8]
001eae3d  4c8d0d3c14ffff           lea r9, [rip - 0xebc4]
001eae44  4c8b03                   mov r8, qword ptr [rbx]
001eae47  ba08000000               mov edx, 8
001eae4c  e80f3ee4ff               call 0x2ec60
001eae51  488b13                   mov rdx, qword ptr [rbx]
001eae54  488d14d508000000         lea rdx, [rdx*8 + 8]
001eae5c  488bcb                   mov rcx, rbx
001eae5f  e88ccfe1ff               call 0x7df0
001eae64  90                       nop
001eae65  488b8fc0040000           mov rcx, qword ptr [rdi + 0x4c0]
001eae6c  4885c9                   test rcx, rcx
001eae6f  741f                     je 0x1eae90
001eae71  8bc6                     mov eax, esi
001eae73  f00fc101                 lock xadd dword ptr [rcx], eax
001eae77  83f801                   cmp eax, 1
001eae7a  7514                     jne 0x1eae90
001eae7c  48894c2458               mov qword ptr [rsp + 0x58], rcx
001eae81  c701adde0080             mov dword ptr [rcx], 0x8000dead
001eae87  8d502f                   lea edx, [rax + 0x2f]
001eae8a  e861cfe1ff               call 0x7df0
001eae8f  90                       nop
001eae90  488b8fb8040000           mov rcx, qword ptr [rdi + 0x4b8]
001eae97  4885c9                   test rcx, rcx
001eae9a  741d                     je 0x1eaeb9
001eae9c  f00fc131                 lock xadd dword ptr [rcx], esi
001eaea0  83fe01                   cmp esi, 1
001eaea3  7514                     jne 0x1eaeb9
001eaea5  48894c2458               mov qword ptr [rsp + 0x58], rcx
001eaeaa  c701adde0080             mov dword ptr [rcx], 0x8000dead
001eaeb0  8d562f                   lea edx, [rsi + 0x2f]
001eaeb3  e838cfe1ff               call 0x7df0
001eaeb8  90                       nop
001eaeb9  488b4f28                 mov rcx, qword ptr [rdi + 0x28]
001eaebd  4885c9                   test rcx, rcx
001eaec0  7406                     je 0x1eaec8
001eaec2  488b01                   mov rax, qword ptr [rcx]
001eaec5  ff5028                   call qword ptr [rax + 0x28]
001eaec8  4883c430                 add rsp, 0x30
001eaecc  5f                       pop rdi
001eaecd  5e                       pop rsi
001eaece  5b                       pop rbx
001eaecf  c3                       ret
