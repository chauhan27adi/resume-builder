; TEnumerator<TList<SOS_Node,SystemThread,184,TListSLock> >::~TEnumerator<TList<SOS_Node,SystemThread,184,TListSLock> >
; sqldk.dll, primary RVA 0x73730, 345 bytes in 1 chunk(s)

; chunk at RVA 0x73730 (345 bytes)
00073730  48895c2410               mov qword ptr [rsp + 0x10], rbx
00073735  48896c2418               mov qword ptr [rsp + 0x18], rbp
0007373a  4889742420               mov qword ptr [rsp + 0x20], rsi
0007373f  57                       push rdi
00073740  4883ec20                 sub rsp, 0x20
00073744  488b39                   mov rdi, qword ptr [rcx]
00073747  33ed                     xor ebp, ebp
00073749  488bd9                   mov rbx, rcx
0007374c  beffffffff               mov esi, 0xffffffff
00073751  4885ff                   test rdi, rdi
00073754  747d                     je 0x737d3
00073756  8bc6                     mov eax, esi
00073758  f00fc187d0000000         lock xadd dword ptr [rdi + 0xd0], eax
00073760  83f801                   cmp eax, 1
00073763  756b                     jne 0x737d0
00073765  4839afc0000000           cmp qword ptr [rdi + 0xc0], rbp
0007376c  7435                     je 0x737a3
0007376e  488b8fc8000000           mov rcx, qword ptr [rdi + 0xc8]
00073775  488bd7                   mov rdx, rdi
00073778  4883c140                 add rcx, 0x40
0007377c  e80f010000               call 0x73890
00073781  654c8b042558000000       mov r8, qword ptr gs:[0x58]
0007378a  8b0540182a00             mov eax, dword ptr [rip + 0x2a1840]
00073790  8b1522e1f8ff             mov edx, dword ptr [rip - 0x71ede]
00073796  490314c0                 add rdx, qword ptr [r8 + rax*8]
0007379a  488997f8000000           mov qword ptr [rdi + 0xf8], rdx
000737a1  eb20                     jmp 0x737c3
000737a3  65488b142558000000       mov rdx, qword ptr gs:[0x58]
000737ac  8b051e182a00             mov eax, dword ptr [rip + 0x2a181e]
000737b2  8b0d00e1f8ff             mov ecx, dword ptr [rip - 0x71f00]
000737b8  48030cc2                 add rcx, qword ptr [rdx + rax*8]
000737bc  48898ff8000000           mov qword ptr [rdi + 0xf8], rcx
000737c3  488b8f40010000           mov rcx, qword ptr [rdi + 0x140]
000737ca  ff1590591c00             call qword ptr [rip + 0x1c5990]
000737d0  48892b                   mov qword ptr [rbx], rbp
000737d3  488b7b08                 mov rdi, qword ptr [rbx + 8]
000737d7  4885ff                   test rdi, rdi
000737da  747c                     je 0x73858
000737dc  f00fc1b7d0000000         lock xadd dword ptr [rdi + 0xd0], esi
000737e4  83fe01                   cmp esi, 1
000737e7  756b                     jne 0x73854
000737e9  4839afc0000000           cmp qword ptr [rdi + 0xc0], rbp
000737f0  7435                     je 0x73827
000737f2  488b8fc8000000           mov rcx, qword ptr [rdi + 0xc8]
000737f9  488bd7                   mov rdx, rdi
000737fc  4883c140                 add rcx, 0x40
00073800  e88b000000               call 0x73890
00073805  654c8b042558000000       mov r8, qword ptr gs:[0x58]
0007380e  8b05bc172a00             mov eax, dword ptr [rip + 0x2a17bc]
00073814  8b159ee0f8ff             mov edx, dword ptr [rip - 0x71f62]
0007381a  490314c0                 add rdx, qword ptr [r8 + rax*8]
0007381e  488997f8000000           mov qword ptr [rdi + 0xf8], rdx
00073825  eb20                     jmp 0x73847
00073827  65488b142558000000       mov rdx, qword ptr gs:[0x58]
00073830  8b059a172a00             mov eax, dword ptr [rip + 0x2a179a]
00073836  8b0d7ce0f8ff             mov ecx, dword ptr [rip - 0x71f84]
0007383c  48030cc2                 add rcx, qword ptr [rdx + rax*8]
00073840  48898ff8000000           mov qword ptr [rdi + 0xf8], rcx
00073847  488b8f40010000           mov rcx, qword ptr [rdi + 0x140]
0007384e  ff150c591c00             call qword ptr [rip + 0x1c590c]
00073854  48896b08                 mov qword ptr [rbx + 8], rbp
00073858  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
0007385c  4885c9                   test rcx, rcx
0007385f  740f                     je 0x73870
00073861  8b5320                   mov edx, dword ptr [rbx + 0x20]
00073864  e8e723f9ff               call 0x5c50
00073869  48896b18                 mov qword ptr [rbx + 0x18], rbp
0007386d  896b20                   mov dword ptr [rbx + 0x20], ebp
00073870  488b742448               mov rsi, qword ptr [rsp + 0x48]
00073875  48896b10                 mov qword ptr [rbx + 0x10], rbp
00073879  488b5c2438               mov rbx, qword ptr [rsp + 0x38]
0007387e  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
00073883  4883c420                 add rsp, 0x20
00073887  5f                       pop rdi
00073888  c3                       ret
