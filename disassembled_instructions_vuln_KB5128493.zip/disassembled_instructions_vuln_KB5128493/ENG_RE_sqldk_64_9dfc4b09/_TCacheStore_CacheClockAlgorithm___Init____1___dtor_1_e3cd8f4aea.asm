; `TCacheStore<CacheClockAlgorithm>::Init'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22d360, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22d360 (59 bytes)
0022d360  4055                     push rbp
0022d362  4883ec30                 sub rsp, 0x30
0022d366  488bea                   mov rbp, rdx
0022d369  c644242806               mov byte ptr [rsp + 0x28], 6
0022d36e  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0022d374  89442420                 mov dword ptr [rsp + 0x20], eax
0022d378  4c8d0d51d10400           lea r9, [rip + 0x4d151]
0022d37f  41b801000000             mov r8d, 1
0022d385  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
0022d38c  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022d390  e80baaddff               call 0x7da0
0022d395  4883c430                 add rsp, 0x30
0022d399  5d                       pop rbp
0022d39a  c3                       ret
