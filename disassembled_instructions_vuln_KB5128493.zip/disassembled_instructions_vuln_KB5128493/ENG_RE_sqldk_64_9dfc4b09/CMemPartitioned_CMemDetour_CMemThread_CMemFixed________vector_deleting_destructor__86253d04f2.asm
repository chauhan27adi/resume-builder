; CMemPartitioned<CMemDetour<CMemThread<CMemFixed> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce840, 129 bytes in 1 chunk(s)

; chunk at RVA 0xce840 (129 bytes)
000ce840  48894c2408               mov qword ptr [rsp + 8], rcx
000ce845  57                       push rdi
000ce846  4883ec30                 sub rsp, 0x30
000ce84a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce853  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce858  8bda                     mov ebx, edx
000ce85a  488bf9                   mov rdi, rcx
000ce85d  488d059ce51700           lea rax, [rip + 0x17e59c]
000ce864  488901                   mov qword ptr [rcx], rax
000ce867  488d81e8020000           lea rax, [rcx + 0x2e8]
000ce86e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce873  488d0dc6b21600           lea rcx, [rip + 0x16b2c6]
000ce87a  488908                   mov qword ptr [rax], rcx
000ce87d  488d05dcee1700           lea rax, [rip + 0x17eedc]
000ce884  488907                   mov qword ptr [rdi], rax
000ce887  488d8720020000           lea rax, [rdi + 0x220]
000ce88e  4889442458               mov qword ptr [rsp + 0x58], rax
000ce893  488908                   mov qword ptr [rax], rcx
000ce896  488bcf                   mov rcx, rdi
000ce899  e8b2dd0200               call 0xfc650
000ce89e  83e305                   and ebx, 5
000ce8a1  80fb05                   cmp bl, 5
000ce8a4  750d                     jne 0xce8b3
000ce8a6  ba20030000               mov edx, 0x320
000ce8ab  488bcf                   mov rcx, rdi
000ce8ae  e85d27f3ff               call 0x1010
000ce8b3  488bc7                   mov rax, rdi
000ce8b6  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce8bb  4883c430                 add rsp, 0x30
000ce8bf  5f                       pop rdi
000ce8c0  c3                       ret
