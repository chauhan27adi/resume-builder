; CAutoRg<XMLEventTransformRule>::~CAutoRg<XMLEventTransformRule>
; sqldk.dll, primary RVA 0x4df20, 79 bytes in 3 chunk(s)

; chunk at RVA 0x4df20 (23 bytes)
0004df20  4883ec28                 sub rsp, 0x28
0004df24  488b09                   mov rcx, qword ptr [rcx]
0004df27  4885c9                   test rcx, rcx
0004df2a  743f                     je 0x4df6b
0004df2c  4c8b41f8                 mov r8, qword ptr [rcx - 8]
0004df30  4c8d0d99020000           lea r9, [rip + 0x299]

; chunk at RVA 0x4df37 (51 bytes)
0004df37  48895c2420               mov qword ptr [rsp + 0x20], rbx
0004df3c  ba28000000               mov edx, 0x28
0004df41  488d59f8                 lea rbx, [rcx - 8]
0004df45  e8160dfeff               call 0x2ec60
0004df4a  488b03                   mov rax, qword ptr [rbx]
0004df4d  488bcb                   mov rcx, rbx
0004df50  488d1480                 lea rdx, [rax + rax*4]
0004df54  488d14d508000000         lea rdx, [rdx*8 + 8]
0004df5c  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0004df61  4883c428                 add rsp, 0x28
0004df65  e9869efbff               jmp 0x7df0

; chunk at RVA 0x4df6b (5 bytes)
0004df6b  4883c428                 add rsp, 0x28
0004df6f  c3                       ret
