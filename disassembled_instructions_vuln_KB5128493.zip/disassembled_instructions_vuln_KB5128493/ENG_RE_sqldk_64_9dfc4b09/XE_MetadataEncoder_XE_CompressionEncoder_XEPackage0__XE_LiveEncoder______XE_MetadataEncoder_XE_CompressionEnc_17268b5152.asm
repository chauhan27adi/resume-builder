; XE_MetadataEncoder<XE_CompressionEncoder<XEPackage0::XE_LiveEncoder> >::~XE_MetadataEncoder<XE_CompressionEncoder<XEPackage0::XE_LiveEncoder> >
; sqldk.dll, primary RVA 0x1d2370, 36 bytes in 1 chunk(s)

; chunk at RVA 0x1d2370 (36 bytes)
001d2370  48894c2408               mov qword ptr [rsp + 8], rcx
001d2375  4883ec38                 sub rsp, 0x38
001d2379  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001d2382  48894c2448               mov qword ptr [rsp + 0x48], rcx
001d2387  4883c110                 add rcx, 0x10
001d238b  4883c438                 add rsp, 0x38
001d238f  e96c33e7ff               jmp 0x45700
