; `CXFixedTable::InitFixedTable'::`1'::dtor$7
; sqldk.dll, primary RVA 0x216d6e, 37 bytes in 1 chunk(s)

; chunk at RVA 0x216d6e (37 bytes)
00216d6e  4055                     push rbp
00216d70  4883ec20                 sub rsp, 0x20
00216d74  488bea                   mov rbp, rdx
00216d77  4533c0                   xor r8d, r8d
00216d7a  488b95e0000000           mov rdx, qword ptr [rbp + 0xe0]
00216d81  488b8df8000000           mov rcx, qword ptr [rbp + 0xf8]
00216d88  e883a2deff               call 0x1010
00216d8d  4883c420                 add rsp, 0x20
00216d91  5d                       pop rbp
00216d92  c3                       ret
