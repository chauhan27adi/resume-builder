; XEPackage0::HistoryTargetFailureInterface::~HistoryTargetFailureInterface
; sqldk.dll, primary RVA 0x1bbbb0, 32 bytes in 1 chunk(s)

; chunk at RVA 0x1bbbb0 (32 bytes)
001bbbb0  48894c2408               mov qword ptr [rsp + 8], rcx
001bbbb5  4883ec18                 sub rsp, 0x18
001bbbb9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
001bbbc1  488d0558900c00           lea rax, [rip + 0xc9058]
001bbbc8  488901                   mov qword ptr [rcx], rax
001bbbcb  4883c418                 add rsp, 0x18
001bbbcf  c3                       ret
