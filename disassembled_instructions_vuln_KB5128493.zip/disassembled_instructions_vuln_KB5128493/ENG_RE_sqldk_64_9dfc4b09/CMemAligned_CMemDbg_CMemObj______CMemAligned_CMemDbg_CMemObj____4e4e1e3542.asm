; CMemAligned<CMemDbg<CMemObj> >::~CMemAligned<CMemDbg<CMemObj> >
; sqldk.dll, primary RVA 0x1291a0, 37 bytes in 1 chunk(s)

; chunk at RVA 0x1291a0 (37 bytes)
001291a0  48894c2408               mov qword ptr [rsp + 8], rcx
001291a5  4883ec38                 sub rsp, 0x38
001291a9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001291b2  488d0577251200           lea rax, [rip + 0x122577]
001291b9  488901                   mov qword ptr [rcx], rax
001291bc  4883c438                 add rsp, 0x38
001291c0  e91b540400               jmp 0x16e5e0
