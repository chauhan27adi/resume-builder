; CMemThread<CMemProc>::PbGetNewPages
; sqldk.dll, primary RVA 0x32380, 179 bytes in 1 chunk(s)

; chunk at RVA 0x32380 (179 bytes)
00032380  48895c2408               mov qword ptr [rsp + 8], rbx
00032385  48896c2410               mov qword ptr [rsp + 0x10], rbp
0003238a  4889742418               mov qword ptr [rsp + 0x18], rsi
0003238f  57                       push rdi
00032390  4883ec20                 sub rsp, 0x20
00032394  488d99a0000000           lea rbx, [rcx + 0xa0]
0003239b  498bf0                   mov rsi, r8
0003239e  48c7838000000000000000   mov qword ptr [rbx + 0x80], 0
000323a9  488bea                   mov rbp, rdx
000323ac  488bf9                   mov rdi, rcx
000323af  b8ff7fffff               mov eax, 0xffff7fff
000323b4  f00fc14360               lock xadd dword ptr [rbx + 0x60], eax
000323b9  3d01800000               cmp eax, 0x8001
000323be  7411                     je 0x323d1
000323c0  488d4b30                 lea rcx, [rbx + 0x30]
000323c4  e8c7a7fdff               call 0xcb90
000323c9  488bcb                   mov rcx, rbx
000323cc  e8bfa7fdff               call 0xcb90
000323d1  488b4f40                 mov rcx, qword ptr [rdi + 0x40]
000323d5  4c8bc6                   mov r8, rsi
000323d8  488bd5                   mov rdx, rbp
000323db  488b01                   mov rax, qword ptr [rcx]
000323de  ff10                     call qword ptr [rax]
000323e0  65488b142558000000       mov rdx, qword ptr gs:[0x58]
000323e9  488be8                   mov rbp, rax
000323ec  8b0dde2b2e00             mov ecx, dword ptr [rip + 0x2e2bde]
000323f2  8b35c0f4fcff             mov esi, dword ptr [rip - 0x30b40]
000323f8  480334ca                 add rsi, qword ptr [rdx + rcx*8]
000323fc  488b9600010000           mov rdx, qword ptr [rsi + 0x100]
00032403  4885d2                   test rdx, rdx
00032406  0f8442020a00             je 0xd264e
0003240c  4c8d8728010000           lea r8, [rdi + 0x128]
00032413  488bcb                   mov rcx, rbx
00032416  e8255afdff               call 0x7e40
0003241b  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
00032420  488bc5                   mov rax, rbp
00032423  488b6c2438               mov rbp, qword ptr [rsp + 0x38]
00032428  488b742440               mov rsi, qword ptr [rsp + 0x40]
0003242d  4883c420                 add rsp, 0x20
00032431  5f                       pop rdi
00032432  c3                       ret
