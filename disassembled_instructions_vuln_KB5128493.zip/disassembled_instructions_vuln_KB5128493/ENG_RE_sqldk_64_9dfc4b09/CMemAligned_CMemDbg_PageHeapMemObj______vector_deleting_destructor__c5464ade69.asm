; CMemAligned<CMemDbg<PageHeapMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xd0820, 76 bytes in 1 chunk(s)

; chunk at RVA 0xd0820 (76 bytes)
000d0820  48894c2408               mov qword ptr [rsp + 8], rcx
000d0825  57                       push rdi
000d0826  4883ec30                 sub rsp, 0x30
000d082a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000d0833  48895c2448               mov qword ptr [rsp + 0x48], rbx
000d0838  8bda                     mov ebx, edx
000d083a  488bf9                   mov rdi, rcx
000d083d  488d058ca91700           lea rax, [rip + 0x17a98c]
000d0844  488901                   mov qword ptr [rcx], rax
000d0847  e8c41b0a00               call 0x172410
000d084c  f6c301                   test bl, 1
000d084f  740d                     je 0xd085e
000d0851  ba58040000               mov edx, 0x458
000d0856  488bcf                   mov rcx, rdi
000d0859  e89275f3ff               call 0x7df0
000d085e  488bc7                   mov rax, rdi
000d0861  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000d0866  4883c430                 add rsp, 0x30
000d086a  5f                       pop rdi
000d086b  c3                       ret
