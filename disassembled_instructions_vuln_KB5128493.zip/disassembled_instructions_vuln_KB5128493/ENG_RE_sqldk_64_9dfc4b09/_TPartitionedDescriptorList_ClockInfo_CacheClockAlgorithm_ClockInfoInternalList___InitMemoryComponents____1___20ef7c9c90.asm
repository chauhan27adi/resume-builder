; `TPartitionedDescriptorList<ClockInfo,CacheClockAlgorithm,ClockInfoInternalList>::InitMemoryComponents'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22d100, 53 bytes in 1 chunk(s)

; chunk at RVA 0x22d100 (53 bytes)
0022d100  4055                     push rbp
0022d102  4883ec30                 sub rsp, 0x30
0022d106  488bea                   mov rbp, rdx
0022d109  c644242806               mov byte ptr [rsp + 0x28], 6
0022d10e  8b4570                   mov eax, dword ptr [rbp + 0x70]
0022d111  89442420                 mov dword ptr [rsp + 0x20], eax
0022d115  4c8d0db4d30400           lea r9, [rip + 0x4d3b4]
0022d11c  41b801000000             mov r8d, 1
0022d122  488b5568                 mov rdx, qword ptr [rbp + 0x68]
0022d126  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0022d12a  e871acddff               call 0x7da0
0022d12f  4883c430                 add rsp, 0x30
0022d133  5d                       pop rbp
0022d134  c3                       ret
