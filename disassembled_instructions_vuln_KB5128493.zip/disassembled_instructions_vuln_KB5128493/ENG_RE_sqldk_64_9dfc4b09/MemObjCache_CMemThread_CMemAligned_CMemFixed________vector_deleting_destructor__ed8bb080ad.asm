; MemObjCache<CMemThread<CMemAligned<CMemFixed> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e720, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13e720 (79 bytes)
0013e720  48894c2408               mov qword ptr [rsp + 8], rcx
0013e725  57                       push rdi
0013e726  4883ec30                 sub rsp, 0x30
0013e72a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e733  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e738  8bda                     mov ebx, edx
0013e73a  488bf9                   mov rdi, rcx
0013e73d  488d0514691200           lea rax, [rip + 0x126914]
0013e744  488901                   mov qword ptr [rcx], rax
0013e747  e82421fcff               call 0x100870
0013e74c  83e305                   and ebx, 5
0013e74f  80fb05                   cmp bl, 5
0013e752  750d                     jne 0x13e761
0013e754  ba38020000               mov edx, 0x238
0013e759  488bcf                   mov rcx, rdi
0013e75c  e8af28ecff               call 0x1010
0013e761  488bc7                   mov rax, rdi
0013e764  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e769  4883c430                 add rsp, 0x30
0013e76d  5f                       pop rdi
0013e76e  c3                       ret
