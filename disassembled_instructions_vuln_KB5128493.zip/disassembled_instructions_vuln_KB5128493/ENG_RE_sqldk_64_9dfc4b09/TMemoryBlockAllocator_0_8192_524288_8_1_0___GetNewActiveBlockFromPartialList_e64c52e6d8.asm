; TMemoryBlockAllocator<0,8192,524288,8,1,0>::GetNewActiveBlockFromPartialList
; sqldk.dll, primary RVA 0x1aac0, 238 bytes in 1 chunk(s)

; chunk at RVA 0x1aac0 (238 bytes)
0001aac0  488bc4                   mov rax, rsp
0001aac3  48894808                 mov qword ptr [rax + 8], rcx
0001aac7  55                       push rbp
0001aac8  4154                     push r12
0001aaca  4155                     push r13
0001aacc  4156                     push r14
0001aace  4157                     push r15
0001aad0  488d68a9                 lea rbp, [rax - 0x57]
0001aad4  4881ec90000000           sub rsp, 0x90
0001aadb  48c7451ffeffffff         mov qword ptr [rbp + 0x1f], 0xfffffffffffffffe
0001aae3  48895810                 mov qword ptr [rax + 0x10], rbx
0001aae7  48897018                 mov qword ptr [rax + 0x18], rsi
0001aaeb  48897820                 mov qword ptr [rax + 0x20], rdi
0001aaef  450fb6e8                 movzx r13d, r8b
0001aaf3  33ff                     xor edi, edi
0001aaf5  8bdf                     mov ebx, edi
0001aaf7  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0001aafb  488d45c7                 lea rax, [rbp - 0x39]
0001aaff  488945cf                 mov qword ptr [rbp - 0x31], rax
0001ab03  488d45c7                 lea rax, [rbp - 0x39]
0001ab07  488945c7                 mov qword ptr [rbp - 0x39], rax
0001ab0b  0fb7c2                   movzx eax, dx
0001ab0e  488d0480                 lea rax, [rax + rax*4]
0001ab12  48c1e006                 shl rax, 6
0001ab16  4803c1                   add rax, rcx
0001ab19  488945d7                 mov qword ptr [rbp - 0x29], rax
0001ab1d  4c8da000010000           lea r12, [rax + 0x100]
0001ab24  448d7f06                 lea r15d, [rdi + 6]
0001ab28  440fb6757f               movzx r14d, byte ptr [rbp + 0x7f]
0001ab2d  4584c9                   test r9b, r9b
0001ab30  0f8437650700             je 0x9106d
0001ab36  8d7708                   lea esi, [rdi + 8]
0001ab39  eb01                     jmp 0x1ab3c
0001ab3b  cc                       int3
0001ab3c  48895dbf                 mov qword ptr [rbp - 0x41], rbx
0001ab40  83fe10                   cmp esi, 0x10
0001ab43  0f83300f0000             jae 0x1ba79
0001ab49  48897dbf                 mov qword ptr [rbp - 0x41], rdi
0001ab4d  488d55df                 lea rdx, [rbp - 0x21]
0001ab51  488955e7                 mov qword ptr [rbp - 0x19], rdx
0001ab55  488d4ddf                 lea rcx, [rbp - 0x21]
0001ab59  48894ddf                 mov qword ptr [rbp - 0x21], rcx
0001ab5d  4863fe                   movsxd rdi, esi
0001ab60  4883c711                 add rdi, 0x11
0001ab64  48c1e704                 shl rdi, 4
0001ab68  4803f8                   add rdi, rax
0001ab6b  488bcf                   mov rcx, rdi
0001ab6e  ff15a4e62100             call qword ptr [rip + 0x21e6a4]
0001ab74  4c8bc0                   mov r8, rax
0001ab77  4885c0                   test rax, rax
0001ab7a  7569                     jne 0x1abe5
0001ab7c  488b5dbf                 mov rbx, qword ptr [rbp - 0x41]
0001ab80  4533e4                   xor r12d, r12d
0001ab83  488d45df                 lea rax, [rbp - 0x21]
0001ab87  488b55e7                 mov rdx, qword ptr [rbp - 0x19]
0001ab8b  483bd0                   cmp rdx, rax
0001ab8e  0f8546640700             jne 0x90fda
0001ab94  ffc6                     inc esi
0001ab96  4885db                   test rbx, rbx
0001ab99  488b45d7                 mov rax, qword ptr [rbp - 0x29]
0001ab9d  4c8da000010000           lea r12, [rax + 0x100]
0001aba4  7505                     jne 0x1abab
0001aba6  33ff                     xor edi, edi
0001aba8  eb92                     jmp 0x1ab3c
0001abaa  cc                       int3
0001abab  eb03                     jmp 0x1abb0
0001abad  cc                       int3
