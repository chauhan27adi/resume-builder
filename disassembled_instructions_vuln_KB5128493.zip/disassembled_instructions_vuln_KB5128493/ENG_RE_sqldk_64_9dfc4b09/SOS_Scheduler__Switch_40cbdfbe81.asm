; SOS_Scheduler::Switch
; sqldk.dll, primary RVA 0x26e0, 466 bytes in 7 chunk(s)

; chunk at RVA 0x26e0 (105 bytes)
000026e0  4053                     push rbx
000026e2  56                       push rsi
000026e3  57                       push rdi
000026e4  4154                     push r12
000026e6  4883ec48                 sub rsp, 0x48
000026ea  498bf0                   mov rsi, r8
000026ed  488bfa                   mov rdi, rdx
000026f0  488bd9                   mov rbx, rcx
000026f3  f048ff81480e0000         lock inc qword ptr [rcx + 0xe48]
000026fb  4533e4                   xor r12d, r12d
000026fe  493bd0                   cmp rdx, r8
00002701  0f8535a70000             jne 0xce3c
00002707  ba01000000               mov edx, 1
0000270c  488bcf                   mov rcx, rdi
0000270f  e85c020000               call 0x2970
00002714  488b8760020000           mov rax, qword ptr [rdi + 0x260]
0000271b  4839b800140000           cmp qword ptr [rax + 0x1400], rdi
00002722  0f85a4c80700             jne 0x7efcc
00002728  4c396710                 cmp qword ptr [rdi + 0x10], r12
0000272c  0f85c4c80700             jne 0x7eff6
00002732  488bb758020000           mov rsi, qword ptr [rdi + 0x258]
00002739  4885f6                   test rsi, rsi
0000273c  7467                     je 0x27a5
0000273e  658b042548000000         mov eax, dword ptr gs:[0x48]
00002746  498bdc                   mov rbx, r12

; chunk at RVA 0x2749 (12 bytes)
00002749  4c89742438               mov qword ptr [rsp + 0x38], r14
0000274e  4c8db690000000           lea r14, [rsi + 0x90]

; chunk at RVA 0x2755 (40 bytes)
00002755  4c897c2430               mov qword ptr [rsp + 0x30], r15
0000275a  448bf8                   mov r15d, eax
0000275d  418b06                   mov eax, dword ptr [r14]
00002760  85c0                     test eax, eax
00002762  0f85b8c80700             jne 0x7f020
00002768  33c0                     xor eax, eax
0000276a  f04d0fb13e               lock cmpxchg qword ptr [r14], r15
0000276f  418bc4                   mov eax, r12d
00002772  0f94c0                   sete al
00002775  85c0                     test eax, eax
00002777  0f84a3c80700             je 0x7f020

; chunk at RVA 0x277d (32 bytes)
0000277d  83860801000002           add dword ptr [rsi + 0x108], 2
00002784  4c8b7c2430               mov r15, qword ptr [rsp + 0x30]
00002789  4c89a6c8000000           mov qword ptr [rsi + 0xc8], r12
00002790  4438252a2d3100           cmp byte ptr [rip + 0x312d2a], r12b
00002797  0f8561c90700             jne 0x7f0fe

; chunk at RVA 0x27a5 (16 bytes)
000027a5  8b87d4030000             mov eax, dword ptr [rdi + 0x3d4]
000027ab  4883c448                 add rsp, 0x48
000027af  415c                     pop r12
000027b1  5f                       pop rdi
000027b2  5e                       pop rsi
000027b3  5b                       pop rbx
000027b4  c3                       ret

; chunk at RVA 0x7f02b (211 bytes)
0007f02b  48896c2440               mov qword ptr [rsp + 0x40], rbp
0007f030  498bec                   mov rbp, r12
0007f033  3c84                     cmp al, 0x84
0007f035  754b                     jne 0x7f082
0007f037  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
0007f040  8b058a5f2900             mov eax, dword ptr [rip + 0x295f8a]
0007f046  8b156c28f8ff             mov edx, dword ptr [rip - 0x7d794]
0007f04c  480314c1                 add rdx, qword ptr [rcx + rax*8]
0007f050  7410                     je 0x7f062
0007f052  48399210010000           cmp qword ptr [rdx + 0x110], rdx
0007f059  7507                     jne 0x7f062
0007f05b  488baa00010000           mov rbp, qword ptr [rdx + 0x100]
0007f062  4885ed                   test rbp, rbp
0007f065  741b                     je 0x7f082
0007f067  391d57642900             cmp dword ptr [rip + 0x296457], ebx
0007f06d  746d                     je 0x7f0dc
0007f06f  488d4c2470               lea rcx, [rsp + 0x70]
0007f074  ff1556a41b00             call qword ptr [rip + 0x1ba456]
0007f07a  488b5c2470               mov rbx, qword ptr [rsp + 0x70]
0007f07f  eb01                     jmp 0x7f082
0007f081  cc                       int3
0007f082  f6054e5a290080           test byte ptr [rip + 0x295a4e], 0x80
0007f089  498bce                   mov rcx, r14
0007f08c  7459                     je 0x7f0e7
0007f08e  4d8bc7                   mov r8, r15
0007f091  488bd5                   mov rdx, rbp
0007f094  e8b74cfbff               call 0x33d50
0007f099  eb01                     jmp 0x7f09c
0007f09b  cc                       int3
0007f09c  4885ed                   test rbp, rbp
0007f09f  7430                     je 0x7f0d1
0007f0a1  4439251c642900           cmp dword ptr [rip + 0x29641c], r12d
0007f0a8  7449                     je 0x7f0f3
0007f0aa  488d4c2478               lea rcx, [rsp + 0x78]
0007f0af  ff151ba41b00             call qword ptr [rip + 0x1ba41b]
0007f0b5  488b442478               mov rax, qword ptr [rsp + 0x78]
0007f0ba  eb01                     jmp 0x7f0bd
0007f0bc  cc                       int3
0007f0bd  488bc8                   mov rcx, rax
0007f0c0  482bcb                   sub rcx, rbx
0007f0c3  483bc3                   cmp rax, rbx
0007f0c6  490f42cc                 cmovb rcx, r12
0007f0ca  48018d780c0000           add qword ptr [rbp + 0xc78], rcx
0007f0d1  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
0007f0d6  e9a236f8ff               jmp 0x277d
0007f0db  cc                       int3
0007f0dc  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
0007f0e4  eb9c                     jmp 0x7f082
0007f0e6  cc                       int3
0007f0e7  498bd7                   mov rdx, r15
0007f0ea  e8d18dffff               call 0x77ec0
0007f0ef  90                       nop
0007f0f0  ebaa                     jmp 0x7f09c
0007f0f2  cc                       int3
0007f0f3  488b04250800fe7f         mov rax, qword ptr [0x7ffe0008]
0007f0fb  ebc0                     jmp 0x7f0bd
0007f0fd  cc                       int3

; chunk at RVA 0x7f0fe (50 bytes)
0007f0fe  ff1544a91b00             call qword ptr [rip + 0x1ba944]
0007f104  448bc0                   mov r8d, eax
0007f107  b867666666               mov eax, 0x66666667
0007f10c  41f7e8                   imul r8d
0007f10f  d1fa                     sar edx, 1
0007f111  8bca                     mov ecx, edx
0007f113  c1e91f                   shr ecx, 0x1f
0007f116  03d1                     add edx, ecx
0007f118  8d0c92                   lea ecx, [rdx + rdx*4]
0007f11b  443bc1                   cmp r8d, ecx
0007f11e  0f857936f8ff             jne 0x279d
0007f124  e8d78fffff               call 0x78100
0007f129  90                       nop
0007f12a  e96e36f8ff               jmp 0x279d
0007f12f  cc                       int3
