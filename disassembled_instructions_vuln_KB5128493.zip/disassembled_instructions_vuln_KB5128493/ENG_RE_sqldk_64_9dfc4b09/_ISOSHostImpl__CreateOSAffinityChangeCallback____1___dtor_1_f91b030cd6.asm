; `ISOSHostImpl::CreateOSAffinityChangeCallback'::`1'::dtor$1
; sqldk.dll, primary RVA 0x229c94, 59 bytes in 1 chunk(s)

; chunk at RVA 0x229c94 (59 bytes)
00229c94  4055                     push rbp
00229c96  4883ec30                 sub rsp, 0x30
00229c9a  488bea                   mov rbp, rdx
00229c9d  c644242806               mov byte ptr [rsp + 0x28], 6
00229ca2  8b8598000000             mov eax, dword ptr [rbp + 0x98]
00229ca8  89442420                 mov dword ptr [rsp + 0x20], eax
00229cac  4c8d0d2dff0600           lea r9, [rip + 0x6ff2d]
00229cb3  41b801000000             mov r8d, 1
00229cb9  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
00229cc0  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00229cc4  e8d7e0ddff               call 0x7da0
00229cc9  4883c430                 add rsp, 0x30
00229ccd  5d                       pop rbp
00229cce  c3                       ret
