; `XEPackage0::CounterTarget::AddPackage'::`1'::dtor$3
; sqldk.dll, primary RVA 0x2318d9, 42 bytes in 1 chunk(s)

; chunk at RVA 0x2318d9 (42 bytes)
002318d9  4055                     push rbp
002318db  4883ec20                 sub rsp, 0x20
002318df  488bea                   mov rbp, rdx
002318e2  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
002318e6  4c8d0da358e1ff           lea r9, [rip - 0x1ea75d]
002318ed  41b880000000             mov r8d, 0x80
002318f3  ba18000000               mov edx, 0x18
002318f8  e863d3dfff               call 0x2ec60
002318fd  4883c420                 add rsp, 0x20
00231901  5d                       pop rbp
00231902  c3                       ret
