; `XEPackage0::XE_LiveTarget::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x232080, 32 bytes in 1 chunk(s)

; chunk at RVA 0x232080 (32 bytes)
00232080  4055                     push rbp
00232082  4883ec20                 sub rsp, 0x20
00232086  488bea                   mov rbp, rdx
00232089  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
0023208d  488b5548                 mov rdx, qword ptr [rbp + 0x48]
00232091  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00232095  e876efdcff               call 0x1010
0023209a  4883c420                 add rsp, 0x20
0023209e  5d                       pop rbp
0023209f  c3                       ret
