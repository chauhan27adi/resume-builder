; SOSHost_OSThreadCreateDestroyCallback::~SOSHost_OSThreadCreateDestroyCallback
; sqldk.dll, primary RVA 0x1607f0, 39 bytes in 1 chunk(s)

; chunk at RVA 0x1607f0 (39 bytes)
001607f0  48894c2408               mov qword ptr [rsp + 8], rcx
001607f5  4883ec38                 sub rsp, 0x38
001607f9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00160802  4883791800               cmp qword ptr [rcx + 0x18], 0
00160807  7409                     je 0x160812
00160809  4883c438                 add rsp, 0x38
0016080d  e99e98f0ff               jmp 0x6a0b0
00160812  4883c438                 add rsp, 0x38
00160816  c3                       ret
