; TSimpleHashTable_EntryAccessor<TCacheStore<CacheClockAlgorithm>::CacheEntryProxy,CacheStoreSLock,0,unsigned int>::~TSimpleHashTable_EntryAccessor<TCacheStore<CacheClockAlgorithm>::CacheEntryProxy,CacheStoreSLock,0,unsigned int>
; sqldk.dll, primary RVA 0x1653a0, 71 bytes in 1 chunk(s)

; chunk at RVA 0x1653a0 (71 bytes)
001653a0  4053                     push rbx
001653a2  4883ec20                 sub rsp, 0x20
001653a6  803d14011b0000           cmp byte ptr [rip + 0x1b0114], 0
001653ad  488b19                   mov rbx, qword ptr [rcx]
001653b0  7427                     je 0x1653d9
001653b2  ff1590460d00             call qword ptr [rip + 0xd4690]
001653b8  448bc0                   mov r8d, eax
001653bb  b867666666               mov eax, 0x66666667
001653c0  41f7e8                   imul r8d
001653c3  d1fa                     sar edx, 1
001653c5  8bca                     mov ecx, edx
001653c7  c1e91f                   shr ecx, 0x1f
001653ca  03d1                     add edx, ecx
001653cc  8d0c92                   lea ecx, [rdx + rdx*4]
001653cf  443bc1                   cmp r8d, ecx
001653d2  7505                     jne 0x1653d9
001653d4  e8e7feffff               call 0x1652c0
001653d9  48c7431800000000         mov qword ptr [rbx + 0x18], 0
001653e1  4883c420                 add rsp, 0x20
001653e5  5b                       pop rbx
001653e6  c3                       ret
