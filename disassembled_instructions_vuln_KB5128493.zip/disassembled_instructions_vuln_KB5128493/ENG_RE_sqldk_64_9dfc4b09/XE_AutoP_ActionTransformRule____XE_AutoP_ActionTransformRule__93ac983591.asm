; XE_AutoP<ActionTransformRule>::~XE_AutoP<ActionTransformRule>
; sqldk.dll, primary RVA 0x4d980, 61 bytes in 1 chunk(s)

; chunk at RVA 0x4d980 (61 bytes)
0004d980  48894c2408               mov qword ptr [rsp + 8], rcx
0004d985  53                       push rbx
0004d986  4883ec30                 sub rsp, 0x30
0004d98a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0004d993  488bd9                   mov rbx, rcx
0004d996  488b09                   mov rcx, qword ptr [rcx]
0004d999  4885c9                   test rcx, rcx
0004d99c  7406                     je 0x4d9a4
0004d99e  ff15ac762c00             call qword ptr [rip + 0x2c76ac]
0004d9a4  48c70300000000           mov qword ptr [rbx], 0
0004d9ab  ba0c000000               mov edx, 0xc
0004d9b0  488b0b                   mov rcx, qword ptr [rbx]
0004d9b3  4883c430                 add rsp, 0x30
0004d9b7  5b                       pop rbx
0004d9b8  e933a4fbff               jmp 0x7df0
