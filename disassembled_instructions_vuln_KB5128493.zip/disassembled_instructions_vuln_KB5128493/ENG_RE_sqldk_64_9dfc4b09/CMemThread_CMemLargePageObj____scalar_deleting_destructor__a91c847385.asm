; CMemThread<CMemLargePageObj>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13e890, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13e890 (55 bytes)
0013e890  48895c2408               mov qword ptr [rsp + 8], rbx
0013e895  57                       push rdi
0013e896  4883ec20                 sub rsp, 0x20
0013e89a  8bda                     mov ebx, edx
0013e89c  488bf9                   mov rdi, rcx
0013e89f  e88c4efdff               call 0x113730
0013e8a4  83e305                   and ebx, 5
0013e8a7  80fb05                   cmp bl, 5
0013e8aa  750d                     jne 0x13e8b9
0013e8ac  baa0020000               mov edx, 0x2a0
0013e8b1  488bcf                   mov rcx, rdi
0013e8b4  e85727ecff               call 0x1010
0013e8b9  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013e8be  488bc7                   mov rax, rdi
0013e8c1  4883c420                 add rsp, 0x20
0013e8c5  5f                       pop rdi
0013e8c6  c3                       ret
