; TCallbackListBase<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,unsigned long,NullType,NullType,NullType>,BaseSafeCallbackTraits<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,unsigned long,NullType,NullType,NullType>,TListSLock,SOSCallbackEvent>::List>::~TCallbackListBase<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,unsigned long,NullType,NullType,NullType>,BaseSafeCallbackTraits<TBaseSafeCallback<void,TListSLock,SOSCallbackEvent,unsigned long,NullType,NullType,NullType>,TListSLock,SOSCallbackEvent>::List>
; sqldk.dll, primary RVA 0x6b060, 159 bytes in 1 chunk(s)

; chunk at RVA 0x6b060 (159 bytes)
0006b060  48894c2408               mov qword ptr [rsp + 8], rcx
0006b065  57                       push rdi
0006b066  4883ec50                 sub rsp, 0x50
0006b06a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0006b073  48895c2468               mov qword ptr [rsp + 0x68], rbx
0006b078  4889742470               mov qword ptr [rsp + 0x70], rsi
0006b07d  488bf1                   mov rsi, rcx
0006b080  e81b21fcff               call 0x2d1a0
0006b085  85c0                     test eax, eax
0006b087  7560                     jne 0x6b0e9
0006b089  488bce                   mov rcx, rsi
0006b08c  e80f21fcff               call 0x2d1a0
0006b091  85c0                     test eax, eax
0006b093  7554                     jne 0x6b0e9
0006b095  0f57c0                   xorps xmm0, xmm0
0006b098  f30f7f442428             movdqu xmmword ptr [rsp + 0x28], xmm0
0006b09e  4533c0                   xor r8d, r8d
0006b0a1  488bd6                   mov rdx, rsi
0006b0a4  488d4c2428               lea rcx, [rsp + 0x28]
0006b0a9  e8d221fcff               call 0x2d280
0006b0ae  90                       nop
0006b0af  33db                     xor ebx, ebx
0006b0b1  488d4c2428               lea rcx, [rsp + 0x28]
0006b0b6  e8c523fcff               call 0x2d480
0006b0bb  488bf8                   mov rdi, rax
0006b0be  4885db                   test rbx, rbx
0006b0c1  7413                     je 0x6b0d6
0006b0c3  488bd3                   mov rdx, rbx
0006b0c6  488bce                   mov rcx, rsi
0006b0c9  e8e2f5ffff               call 0x6a6b0
0006b0ce  488bcb                   mov rcx, rbx
0006b0d1  e8daefffff               call 0x6a0b0
0006b0d6  488bdf                   mov rbx, rdi
0006b0d9  4885ff                   test rdi, rdi
0006b0dc  75d3                     jne 0x6b0b1
0006b0de  488d4c2428               lea rcx, [rsp + 0x28]
0006b0e3  e8f836fcff               call 0x2e7e0
0006b0e8  90                       nop
0006b0e9  c706adde0080             mov dword ptr [rsi], 0x8000dead
0006b0ef  488b5c2468               mov rbx, qword ptr [rsp + 0x68]
0006b0f4  488b742470               mov rsi, qword ptr [rsp + 0x70]
0006b0f9  4883c450                 add rsp, 0x50
0006b0fd  5f                       pop rdi
0006b0fe  c3                       ret
