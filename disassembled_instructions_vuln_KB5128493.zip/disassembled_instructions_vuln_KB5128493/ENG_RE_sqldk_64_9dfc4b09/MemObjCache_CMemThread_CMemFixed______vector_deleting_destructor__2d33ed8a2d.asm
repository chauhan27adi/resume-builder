; MemObjCache<CMemThread<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e6c0, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13e6c0 (79 bytes)
0013e6c0  48894c2408               mov qword ptr [rsp + 8], rcx
0013e6c5  57                       push rdi
0013e6c6  4883ec30                 sub rsp, 0x30
0013e6ca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e6d3  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e6d8  8bda                     mov ebx, edx
0013e6da  488bf9                   mov rdi, rcx
0013e6dd  488d05a4a61000           lea rax, [rip + 0x10a6a4]
0013e6e4  488901                   mov qword ptr [rcx], rax
0013e6e7  e864dffbff               call 0xfc650
0013e6ec  83e305                   and ebx, 5
0013e6ef  80fb05                   cmp bl, 5
0013e6f2  750d                     jne 0x13e701
0013e6f4  ba30020000               mov edx, 0x230
0013e6f9  488bcf                   mov rcx, rdi
0013e6fc  e80f29ecff               call 0x1010
0013e701  488bc7                   mov rax, rdi
0013e704  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e709  4883c430                 add rsp, 0x30
0013e70d  5f                       pop rdi
0013e70e  c3                       ret
