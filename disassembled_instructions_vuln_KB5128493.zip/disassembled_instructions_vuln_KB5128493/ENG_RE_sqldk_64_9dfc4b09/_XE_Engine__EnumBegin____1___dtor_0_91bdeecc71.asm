; `XE_Engine::EnumBegin'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2337c0, 56 bytes in 1 chunk(s)

; chunk at RVA 0x2337c0 (56 bytes)
002337c0  4055                     push rbp
002337c2  4883ec30                 sub rsp, 0x30
002337c6  488bea                   mov rbp, rdx
002337c9  c644242806               mov byte ptr [rsp + 0x28], 6
002337ce  8b4560                   mov eax, dword ptr [rbp + 0x60]
002337d1  89442420                 mov dword ptr [rsp + 0x20], eax
002337d5  4c8d0dc46f0700           lea r9, [rip + 0x76fc4]
002337dc  41b801000000             mov r8d, 1
002337e2  488b1597ee1700           mov rdx, qword ptr [rip + 0x17ee97]
002337e9  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
002337ed  e8ce66faff               call 0x1d9ec0
002337f2  4883c430                 add rsp, 0x30
002337f6  5d                       pop rbp
002337f7  c3                       ret
