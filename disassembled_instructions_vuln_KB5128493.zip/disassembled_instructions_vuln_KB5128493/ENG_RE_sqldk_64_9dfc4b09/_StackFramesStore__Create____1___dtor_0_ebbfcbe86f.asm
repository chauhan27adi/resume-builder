; `StackFramesStore::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22da80, 62 bytes in 1 chunk(s)

; chunk at RVA 0x22da80 (62 bytes)
0022da80  4055                     push rbp
0022da82  4883ec30                 sub rsp, 0x30
0022da86  488bea                   mov rbp, rdx
0022da89  c644242806               mov byte ptr [rsp + 0x28], 6
0022da8e  8b85a0000000             mov eax, dword ptr [rbp + 0xa0]
0022da94  89442420                 mov dword ptr [rsp + 0x20], eax
0022da98  4c8d0d89cd0600           lea r9, [rip + 0x6cd89]
0022da9f  41b801000000             mov r8d, 1
0022daa5  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
0022daac  488b8da8000000           mov rcx, qword ptr [rbp + 0xa8]
0022dab3  e8e8a2ddff               call 0x7da0
0022dab8  4883c430                 add rsp, 0x30
0022dabc  5d                       pop rbp
0022dabd  c3                       ret
