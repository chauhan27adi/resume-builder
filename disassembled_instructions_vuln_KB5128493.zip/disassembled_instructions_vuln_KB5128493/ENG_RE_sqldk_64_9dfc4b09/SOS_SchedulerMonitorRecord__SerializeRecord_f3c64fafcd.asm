; SOS_SchedulerMonitorRecord::SerializeRecord
; sqldk.dll, primary RVA 0x185e70, 1012 bytes in 1 chunk(s)

; chunk at RVA 0x185e70 (1012 bytes)
00185e70  48895c2408               mov qword ptr [rsp + 8], rbx
00185e75  4889742410               mov qword ptr [rsp + 0x10], rsi
00185e7a  57                       push rdi
00185e7b  4881eca0000000           sub rsp, 0xa0
00185e82  4c635918                 movsxd r11, dword ptr [rcx + 0x18]
00185e86  498bd9                   mov rbx, r9
00185e89  498bf8                   mov rdi, r8
00185e8c  488bf2                   mov rsi, rdx
00185e8f  4c8bd1                   mov r10, rcx
00185e92  4183fb0a                 cmp r11d, 0xa
00185e96  0f8787030000             ja 0x186223
00185e9c  4c8d055da1e7ff           lea r8, [rip - 0x185ea3]
00185ea3  438b849838621800         mov eax, dword ptr [r8 + r11*4 + 0x186238]
00185eab  4903c0                   add rax, r8
00185eae  ffe0                     jmp rax
00185eb0  8b4170                   mov eax, dword ptr [rcx + 0x70]
00185eb3  0fb7511c                 movzx edx, word ptr [rcx + 0x1c]
00185eb7  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
00185ebf  89842490000000           mov dword ptr [rsp + 0x90], eax
00185ec6  488b4168                 mov rax, qword ptr [rcx + 0x68]
00185eca  4889842488000000         mov qword ptr [rsp + 0x88], rax
00185ed2  8b4160                   mov eax, dword ptr [rcx + 0x60]
00185ed5  89842480000000           mov dword ptr [rsp + 0x80], eax
00185edc  488b4150                 mov rax, qword ptr [rcx + 0x50]
00185ee0  4889442478               mov qword ptr [rsp + 0x78], rax
00185ee5  488b4158                 mov rax, qword ptr [rcx + 0x58]
00185ee9  4889442470               mov qword ptr [rsp + 0x70], rax
00185eee  8b4148                   mov eax, dword ptr [rcx + 0x48]
00185ef1  89442468                 mov dword ptr [rsp + 0x68], eax
00185ef5  8b4144                   mov eax, dword ptr [rcx + 0x44]
00185ef8  89442460                 mov dword ptr [rsp + 0x60], eax
00185efc  8b4140                   mov eax, dword ptr [rcx + 0x40]
00185eff  89442458                 mov dword ptr [rsp + 0x58], eax
00185f03  488b4130                 mov rax, qword ptr [rcx + 0x30]
00185f07  4889442450               mov qword ptr [rsp + 0x50], rax
00185f0c  488b4128                 mov rax, qword ptr [rcx + 0x28]
00185f10  4889442448               mov qword ptr [rsp + 0x48], rax
00185f15  8b4120                   mov eax, dword ptr [rcx + 0x20]
00185f18  488bce                   mov rcx, rsi
00185f1b  89442440                 mov dword ptr [rsp + 0x40], eax
00185f1f  488b05c2b01900           mov rax, qword ptr [rip + 0x19b0c2]
00185f26  89542438                 mov dword ptr [rsp + 0x38], edx
00185f2a  488bd7                   mov rdx, rdi
00185f2d  4889442430               mov qword ptr [rsp + 0x30], rax
00185f32  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
00185f3a  4c8bc3                   mov r8, rbx
00185f3d  4889442428               mov qword ptr [rsp + 0x28], rax
00185f42  48c744242000000000       mov qword ptr [rsp + 0x20], 0
00185f4b  e81032ecff               call 0x49160
00185f50  e9ce020000               jmp 0x186223
00185f55  418b4270                 mov eax, dword ptr [r10 + 0x70]
00185f59  488bd7                   mov rdx, rdi
00185f5c  0fb7491c                 movzx ecx, word ptr [rcx + 0x1c]
00185f60  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
00185f68  89442470                 mov dword ptr [rsp + 0x70], eax
00185f6c  498b4268                 mov rax, qword ptr [r10 + 0x68]
00185f70  4889442468               mov qword ptr [rsp + 0x68], rax
00185f75  418b4260                 mov eax, dword ptr [r10 + 0x60]
00185f79  89442460                 mov dword ptr [rsp + 0x60], eax
00185f7d  498b4250                 mov rax, qword ptr [r10 + 0x50]
00185f81  4889442458               mov qword ptr [rsp + 0x58], rax
00185f86  498b4258                 mov rax, qword ptr [r10 + 0x58]
00185f8a  4889442450               mov qword ptr [rsp + 0x50], rax
00185f8f  418b4248                 mov eax, dword ptr [r10 + 0x48]
00185f93  89442448                 mov dword ptr [rsp + 0x48], eax
00185f97  418b4244                 mov eax, dword ptr [r10 + 0x44]
00185f9b  89442440                 mov dword ptr [rsp + 0x40], eax
00185f9f  488b0542b01900           mov rax, qword ptr [rip + 0x19b042]
00185fa6  894c2438                 mov dword ptr [rsp + 0x38], ecx
00185faa  488bce                   mov rcx, rsi
00185fad  4889442430               mov qword ptr [rsp + 0x30], rax
00185fb2  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
00185fba  4c8bc3                   mov r8, rbx
00185fbd  4889442428               mov qword ptr [rsp + 0x28], rax
00185fc2  48c744242000000000       mov qword ptr [rsp + 0x20], 0
00185fcb  e89031ecff               call 0x49160
00185fd0  e94e020000               jmp 0x186223
00185fd5  8b4170                   mov eax, dword ptr [rcx + 0x70]
00185fd8  4c8bc3                   mov r8, rbx
00185fdb  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
00185fe3  488bd7                   mov rdx, rdi
00185fe6  89442468                 mov dword ptr [rsp + 0x68], eax
00185fea  488b4168                 mov rax, qword ptr [rcx + 0x68]
00185fee  4889442460               mov qword ptr [rsp + 0x60], rax
00185ff3  8b4160                   mov eax, dword ptr [rcx + 0x60]
00185ff6  89442458                 mov dword ptr [rsp + 0x58], eax
00185ffa  488b4150                 mov rax, qword ptr [rcx + 0x50]
00185ffe  4889442450               mov qword ptr [rsp + 0x50], rax
00186003  488b4158                 mov rax, qword ptr [rcx + 0x58]
00186007  4889442448               mov qword ptr [rsp + 0x48], rax
0018600c  8b4148                   mov eax, dword ptr [rcx + 0x48]
0018600f  89442440                 mov dword ptr [rsp + 0x40], eax
00186013  8b4144                   mov eax, dword ptr [rcx + 0x44]
00186016  488bce                   mov rcx, rsi
00186019  89442438                 mov dword ptr [rsp + 0x38], eax
0018601d  488b05c4af1900           mov rax, qword ptr [rip + 0x19afc4]
00186024  4889442430               mov qword ptr [rsp + 0x30], rax
00186029  488b0570511100           mov rax, qword ptr [rip + 0x115170]
00186030  4889442428               mov qword ptr [rsp + 0x28], rax
00186035  48c744242000000000       mov qword ptr [rsp + 0x20], 0
0018603e  e81d31ecff               call 0x49160
00186043  e9db010000               jmp 0x186223
00186048  418b4270                 mov eax, dword ptr [r10 + 0x70]
0018604c  488bd7                   mov rdx, rdi
0018604f  0fb7491c                 movzx ecx, word ptr [rcx + 0x1c]
00186053  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
0018605b  89842488000000           mov dword ptr [rsp + 0x88], eax
00186062  498b4268                 mov rax, qword ptr [r10 + 0x68]
00186066  4889842480000000         mov qword ptr [rsp + 0x80], rax
0018606e  418b4260                 mov eax, dword ptr [r10 + 0x60]
00186072  89442478                 mov dword ptr [rsp + 0x78], eax
00186076  498b4258                 mov rax, qword ptr [r10 + 0x58]
0018607a  4889442470               mov qword ptr [rsp + 0x70], rax
0018607f  498b4250                 mov rax, qword ptr [r10 + 0x50]
00186083  4889442468               mov qword ptr [rsp + 0x68], rax
00186088  418b4248                 mov eax, dword ptr [r10 + 0x48]
0018608c  89442460                 mov dword ptr [rsp + 0x60], eax
00186090  418b4244                 mov eax, dword ptr [r10 + 0x44]
00186094  89442458                 mov dword ptr [rsp + 0x58], eax
00186098  418b4240                 mov eax, dword ptr [r10 + 0x40]
0018609c  89442450                 mov dword ptr [rsp + 0x50], eax
001860a0  498b4230                 mov rax, qword ptr [r10 + 0x30]
001860a4  4889442448               mov qword ptr [rsp + 0x48], rax
001860a9  498b4228                 mov rax, qword ptr [r10 + 0x28]
001860ad  4889442440               mov qword ptr [rsp + 0x40], rax
001860b2  488b052faf1900           mov rax, qword ptr [rip + 0x19af2f]
001860b9  894c2438                 mov dword ptr [rsp + 0x38], ecx
001860bd  488bce                   mov rcx, rsi
001860c0  4889442430               mov qword ptr [rsp + 0x30], rax
001860c5  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
001860cd  4c8bc3                   mov r8, rbx
001860d0  4889442428               mov qword ptr [rsp + 0x28], rax
001860d5  48c744242000000000       mov qword ptr [rsp + 0x20], 0
001860de  e87d30ecff               call 0x49160
001860e3  e93b010000               jmp 0x186223
001860e8  418b4270                 mov eax, dword ptr [r10 + 0x70]
001860ec  488bd7                   mov rdx, rdi
001860ef  0fb7491c                 movzx ecx, word ptr [rcx + 0x1c]
001860f3  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
001860fb  89842490000000           mov dword ptr [rsp + 0x90], eax
00186102  498b4268                 mov rax, qword ptr [r10 + 0x68]
00186106  4889842488000000         mov qword ptr [rsp + 0x88], rax
0018610e  418b4260                 mov eax, dword ptr [r10 + 0x60]
00186112  89842480000000           mov dword ptr [rsp + 0x80], eax
00186119  498b4250                 mov rax, qword ptr [r10 + 0x50]
0018611d  4889442478               mov qword ptr [rsp + 0x78], rax
00186122  498b4258                 mov rax, qword ptr [r10 + 0x58]
00186126  4889442470               mov qword ptr [rsp + 0x70], rax
0018612b  418b4248                 mov eax, dword ptr [r10 + 0x48]
0018612f  89442468                 mov dword ptr [rsp + 0x68], eax
00186133  418b4244                 mov eax, dword ptr [r10 + 0x44]
00186137  89442460                 mov dword ptr [rsp + 0x60], eax
0018613b  418b4240                 mov eax, dword ptr [r10 + 0x40]
0018613f  89442458                 mov dword ptr [rsp + 0x58], eax
00186143  498b4238                 mov rax, qword ptr [r10 + 0x38]
00186147  4889442450               mov qword ptr [rsp + 0x50], rax
0018614c  498b4230                 mov rax, qword ptr [r10 + 0x30]
00186150  4889442448               mov qword ptr [rsp + 0x48], rax
00186155  498b4228                 mov rax, qword ptr [r10 + 0x28]
00186159  4889442440               mov qword ptr [rsp + 0x40], rax
0018615e  488b0583ae1900           mov rax, qword ptr [rip + 0x19ae83]
00186165  894c2438                 mov dword ptr [rsp + 0x38], ecx
00186169  488bce                   mov rcx, rsi
0018616c  4889442430               mov qword ptr [rsp + 0x30], rax
00186171  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
00186179  4c8bc3                   mov r8, rbx
0018617c  4889442428               mov qword ptr [rsp + 0x28], rax
00186181  48c744242000000000       mov qword ptr [rsp + 0x20], 0
0018618a  e8d12fecff               call 0x49160
0018618f  e98f000000               jmp 0x186223
00186194  418b4270                 mov eax, dword ptr [r10 + 0x70]
00186198  488bd7                   mov rdx, rdi
0018619b  0fb7491c                 movzx ecx, word ptr [rcx + 0x1c]
0018619f  4c8b8c24d0000000         mov r9, qword ptr [rsp + 0xd0]
001861a7  89842480000000           mov dword ptr [rsp + 0x80], eax
001861ae  498b4268                 mov rax, qword ptr [r10 + 0x68]
001861b2  4889442478               mov qword ptr [rsp + 0x78], rax
001861b7  418b4260                 mov eax, dword ptr [r10 + 0x60]
001861bb  89442470                 mov dword ptr [rsp + 0x70], eax
001861bf  498b4250                 mov rax, qword ptr [r10 + 0x50]
001861c3  4889442468               mov qword ptr [rsp + 0x68], rax
001861c8  498b4258                 mov rax, qword ptr [r10 + 0x58]
001861cc  4889442460               mov qword ptr [rsp + 0x60], rax
001861d1  418b4248                 mov eax, dword ptr [r10 + 0x48]
001861d5  89442458                 mov dword ptr [rsp + 0x58], eax
001861d9  418b4244                 mov eax, dword ptr [r10 + 0x44]
001861dd  89442450                 mov dword ptr [rsp + 0x50], eax
001861e1  418b4240                 mov eax, dword ptr [r10 + 0x40]
001861e5  89442448                 mov dword ptr [rsp + 0x48], eax
001861e9  498b4228                 mov rax, qword ptr [r10 + 0x28]
001861ed  4889442440               mov qword ptr [rsp + 0x40], rax
001861f2  488b05efad1900           mov rax, qword ptr [rip + 0x19adef]
001861f9  894c2438                 mov dword ptr [rsp + 0x38], ecx
001861fd  488bce                   mov rcx, rsi
00186200  4889442430               mov qword ptr [rsp + 0x30], rax
00186205  4b8b84d880b12900         mov rax, qword ptr [r8 + r11*8 + 0x29b180]
0018620d  4c8bc3                   mov r8, rbx
00186210  4889442428               mov qword ptr [rsp + 0x28], rax
00186215  48c744242000000000       mov qword ptr [rsp + 0x20], 0
0018621e  e83d2fecff               call 0x49160
00186223  4c8d9c24a0000000         lea r11, [rsp + 0xa0]
0018622b  498b5b10                 mov rbx, qword ptr [r11 + 0x10]
0018622f  498b7318                 mov rsi, qword ptr [r11 + 0x18]
00186233  498be3                   mov rsp, r11
00186236  5f                       pop rdi
00186237  c3                       ret
00186238  b05e                     mov al, 0x5e
0018623a  1800                     sbb byte ptr [rax], al
0018623c  b05e                     mov al, 0x5e
0018623e  1800                     sbb byte ptr [rax], al
00186240  55                       push rbp
00186241  5f                       pop rdi
00186242  1800                     sbb byte ptr [rax], al
00186244  55                       push rbp
00186245  5f                       pop rdi
00186246  1800                     sbb byte ptr [rax], al
