; TList<SOS_Scheduler,SOS_Task,16,TListSLock>::AppendElem
; sqldk.dll, primary RVA 0xffa0, 287 bytes in 5 chunk(s)

; chunk at RVA 0xffa0 (20 bytes)
0000ffa0  4057                     push rdi
0000ffa2  4155                     push r13
0000ffa4  4883ec48                 sub rsp, 0x48
0000ffa8  658b042548000000         mov eax, dword ptr gs:[0x48]
0000ffb0  488d7910                 lea rdi, [rcx + 0x10]

; chunk at RVA 0xffb4 (81 bytes)
0000ffb4  48895c2478               mov qword ptr [rsp + 0x78], rbx
0000ffb9  4533ed                   xor r13d, r13d
0000ffbc  48896c2440               mov qword ptr [rsp + 0x40], rbp
0000ffc1  4885c9                   test rcx, rcx
0000ffc4  4c89642430               mov qword ptr [rsp + 0x30], r12
0000ffc9  418bdd                   mov ebx, r13d
0000ffcc  4c89742428               mov qword ptr [rsp + 0x28], r14
0000ffd1  4c8d61d0                 lea r12, [rcx - 0x30]
0000ffd5  8be8                     mov ebp, eax
0000ffd7  4d0f44e5                 cmove r12, r13
0000ffdb  8b07                     mov eax, dword ptr [rdi]
0000ffdd  4c8bf1                   mov r14, rcx
0000ffe0  4c897c2420               mov qword ptr [rsp + 0x20], r15
0000ffe5  4c8bfa                   mov r15, rdx
0000ffe8  85c0                     test eax, eax
0000ffea  0f8542d10100             jne 0x2d132
0000fff0  33c0                     xor eax, eax
0000fff2  f0480fb12f               lock cmpxchg qword ptr [rdi], rbp
0000fff7  418bc5                   mov eax, r13d
0000fffa  0f94c0                   sete al
0000fffd  85c0                     test eax, eax
0000ffff  0f842dd10100             je 0x2d132

; chunk at RVA 0x10005 (70 bytes)
00010005  498b06                   mov rax, qword ptr [r14]
00010008  498d4f10                 lea rcx, [r15 + 0x10]
0001000c  488b6c2440               mov rbp, qword ptr [rsp + 0x40]
00010011  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
00010016  488901                   mov qword ptr [rcx], rax
00010019  498b06                   mov rax, qword ptr [r14]
0001001c  48894808                 mov qword ptr [rax + 8], rcx
00010020  49890e                   mov qword ptr [r14], rcx
00010023  4c897108                 mov qword ptr [rcx + 8], r14
00010027  41ff4618                 inc dword ptr [r14 + 0x18]
0001002b  4c8b742428               mov r14, qword ptr [rsp + 0x28]
00010030  4d896720                 mov qword ptr [r15 + 0x20], r12
00010034  44382d86543000           cmp byte ptr [rip + 0x305486], r13b
0001003b  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
00010040  4c8b642430               mov r12, qword ptr [rsp + 0x30]
00010045  0f85e5830700             jne 0x88430

; chunk at RVA 0x2d13d (66 bytes)
0002d13d  4889742438               mov qword ptr [rsp + 0x38], rsi
0002d142  498bf5                   mov rsi, r13
0002d145  3c84                     cmp al, 0x84
0002d147  0f8434b20500             je 0x88381
0002d14d  f60583792e0080           test byte ptr [rip + 0x2e7983], 0x80
0002d154  488bcf                   mov rcx, rdi
0002d157  0f8483b20500             je 0x883e0
0002d15d  4c8bc5                   mov r8, rbp
0002d160  488bd6                   mov rdx, rsi
0002d163  e81878ffff               call 0x24980
0002d168  eb01                     jmp 0x2d16b
0002d16a  cc                       int3
0002d16b  4885f6                   test rsi, rsi
0002d16e  0f857bb20500             jne 0x883ef
0002d174  488b742438               mov rsi, qword ptr [rsp + 0x38]
0002d179  e9872efeff               jmp 0x10005
0002d17e  cc                       int3

; chunk at RVA 0x88430 (50 bytes)
00088430  ff1512161b00             call qword ptr [rip + 0x1b1612]
00088436  448bc0                   mov r8d, eax
00088439  b867666666               mov eax, 0x66666667
0008843e  41f7e8                   imul r8d
00088441  d1fa                     sar edx, 1
00088443  8bca                     mov ecx, edx
00088445  c1e91f                   shr ecx, 0x1f
00088448  03d1                     add edx, ecx
0008844a  8d0c92                   lea ecx, [rdx + rdx*4]
0008844d  443bc1                   cmp r8d, ecx
00088450  0f85f57bf8ff             jne 0x1004b
00088456  e88520feff               call 0x6a4e0
0008845b  90                       nop
0008845c  e9ea7bf8ff               jmp 0x1004b
00088461  cc                       int3
