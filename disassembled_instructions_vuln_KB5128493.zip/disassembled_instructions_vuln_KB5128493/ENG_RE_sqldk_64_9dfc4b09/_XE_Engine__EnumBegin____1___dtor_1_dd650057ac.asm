; `XE_Engine::EnumBegin'::`1'::dtor$1
; sqldk.dll, primary RVA 0x233800, 56 bytes in 1 chunk(s)

; chunk at RVA 0x233800 (56 bytes)
00233800  4055                     push rbp
00233802  4883ec30                 sub rsp, 0x30
00233806  488bea                   mov rbp, rdx
00233809  c644242806               mov byte ptr [rsp + 0x28], 6
0023380e  8b4560                   mov eax, dword ptr [rbp + 0x60]
00233811  89442420                 mov dword ptr [rsp + 0x20], eax
00233815  4c8d0d846f0700           lea r9, [rip + 0x76f84]
0023381c  41b801000000             mov r8d, 1
00233822  488b1557ee1700           mov rdx, qword ptr [rip + 0x17ee57]
00233829  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
0023382d  e88e66faff               call 0x1d9ec0
00233832  4883c430                 add rsp, 0x30
00233836  5d                       pop rbp
00233837  c3                       ret
