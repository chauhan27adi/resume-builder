; SOS_TraceStreamBufferT<256>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x57cb0, 67 bytes in 1 chunk(s)

; chunk at RVA 0x57cb0 (67 bytes)
00057cb0  48894c2408               mov qword ptr [rsp + 8], rcx
00057cb5  57                       push rdi
00057cb6  4883ec30                 sub rsp, 0x30
00057cba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00057cc3  48895c2448               mov qword ptr [rsp + 0x48], rbx
00057cc8  8bda                     mov ebx, edx
00057cca  488bf9                   mov rdi, rcx
00057ccd  ff15f51a1e00             call qword ptr [rip + 0x1e1af5]
00057cd3  f6c301                   test bl, 1
00057cd6  740d                     je 0x57ce5
00057cd8  ba68010000               mov edx, 0x168
00057cdd  488bcf                   mov rcx, rdi
00057ce0  e80b01fbff               call 0x7df0
00057ce5  488bc7                   mov rax, rdi
00057ce8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
00057ced  4883c430                 add rsp, 0x30
00057cf1  5f                       pop rdi
00057cf2  c3                       ret
