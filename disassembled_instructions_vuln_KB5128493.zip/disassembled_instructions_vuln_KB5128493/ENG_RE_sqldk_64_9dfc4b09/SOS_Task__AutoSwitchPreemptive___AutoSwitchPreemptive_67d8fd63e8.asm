; SOS_Task::AutoSwitchPreemptive::~AutoSwitchPreemptive
; sqldk.dll, primary RVA 0xbed80, 118 bytes in 1 chunk(s)

; chunk at RVA 0xbed80 (118 bytes)
000bed80  48894c2408               mov qword ptr [rsp + 8], rcx
000bed85  57                       push rdi
000bed86  4883ec30                 sub rsp, 0x30
000bed8a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000bed93  48895c2450               mov qword ptr [rsp + 0x50], rbx
000bed98  488bf9                   mov rdi, rcx
000bed9b  488d5910                 lea rbx, [rcx + 0x10]
000bed9f  48895c2448               mov qword ptr [rsp + 0x48], rbx
000beda4  833b00                   cmp dword ptr [rbx], 0
000beda7  742a                     je 0xbedd3
000beda9  488b5308                 mov rdx, qword ptr [rbx + 8]
000bedad  488b8a60020000           mov rcx, qword ptr [rdx + 0x260]
000bedb4  837b0400                 cmp dword ptr [rbx + 4], 0
000bedb8  740c                     je 0xbedc6
000bedba  818a2003000000080000     or dword ptr [rdx + 0x320], 0x800
000bedc4  eb0d                     jmp 0xbedd3
000bedc6  488b01                   mov rax, qword ptr [rcx]
000bedc9  41b801000000             mov r8d, 1
000bedcf  ff5010                   call qword ptr [rax + 0x10]
000bedd2  90                       nop
000bedd3  488d4b10                 lea rcx, [rbx + 0x10]
000bedd7  e8f456f5ff               call 0x144d0
000beddc  90                       nop
000beddd  488b4f08                 mov rcx, qword ptr [rdi + 8]
000bede1  8b07                     mov eax, dword ptr [rdi]
000bede3  f7d0                     not eax
000bede5  218168020000             and dword ptr [rcx + 0x268], eax
000bedeb  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
000bedf0  4883c430                 add rsp, 0x30
000bedf4  5f                       pop rdi
000bedf5  c3                       ret
