; `XEPackage0::XE_FileTarget::Create'::`1'::dtor$11
; sqldk.dll, primary RVA 0x22ff74, 35 bytes in 1 chunk(s)

; chunk at RVA 0x22ff74 (35 bytes)
0022ff74  4055                     push rbp
0022ff76  4883ec20                 sub rsp, 0x20
0022ff7a  488bea                   mov rbp, rdx
0022ff7d  4c8b8580000000           mov r8, qword ptr [rbp + 0x80]
0022ff84  488b5548                 mov rdx, qword ptr [rbp + 0x48]
0022ff88  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
0022ff8c  e87f10ddff               call 0x1010
0022ff91  4883c420                 add rsp, 0x20
0022ff95  5d                       pop rbp
0022ff96  c3                       ret
