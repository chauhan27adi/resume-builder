; `XE_MetadataFilter::AddPackage'::`1'::dtor$1
; sqldk.dll, primary RVA 0x2163a4, 34 bytes in 1 chunk(s)

; chunk at RVA 0x2163a4 (34 bytes)
002163a4  4055                     push rbp
002163a6  4883ec20                 sub rsp, 0x20
002163aa  488bea                   mov rbp, rdx
002163ad  4533c0                   xor r8d, r8d
002163b0  488b95c0000000           mov rdx, qword ptr [rbp + 0xc0]
002163b7  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
002163bb  e850acdeff               call 0x1010
002163c0  4883c420                 add rsp, 0x20
002163c4  5d                       pop rbp
002163c5  c3                       ret
