; XEPackage0::XE_LiveTarget::NotifyLogSetSizeError
; sqldk.dll, primary RVA 0x1d0e90, 51 bytes in 1 chunk(s)

; chunk at RVA 0x1d0e90 (51 bytes)
001d0e90  4883ec38                 sub rsp, 0x38
001d0e94  488d0535c30d00           lea rax, [rip + 0xdc335]
001d0e9b  41b961010000             mov r9d, 0x161
001d0ea1  4c8d0550ae0d00           lea r8, [rip + 0xdae50]
001d0ea8  4889442420               mov qword ptr [rsp + 0x20], rax
001d0ead  488d1588ae0d00           lea rdx, [rip + 0xdae88]
001d0eb4  b901000000               mov ecx, 1
001d0eb9  e8020ffeff               call 0x1b1dc0
001d0ebe  4883c438                 add rsp, 0x38
001d0ec2  c3                       ret
