; MemoryObjectFactory::WrapMemObject<PageHeapMemObj,CFixedInfo>
; sqldk.dll, primary RVA 0xc7870, 4052 bytes in 1 chunk(s)

; chunk at RVA 0xc7870 (4052 bytes)
000c7870  4c894c2420               mov qword ptr [rsp + 0x20], r9
000c7875  4c89442418               mov qword ptr [rsp + 0x18], r8
000c787a  55                       push rbp
000c787b  56                       push rsi
000c787c  57                       push rdi
000c787d  4154                     push r12
000c787f  4155                     push r13
000c7881  4156                     push r14
000c7883  4157                     push r15
000c7885  488bec                   mov rbp, rsp
000c7888  4883ec70                 sub rsp, 0x70
000c788c  48c745d0feffffff         mov qword ptr [rbp - 0x30], 0xfffffffffffffffe
000c7894  48899c24b0000000         mov qword ptr [rsp + 0xb0], rbx
000c789c  498bf8                   mov rdi, r8
000c789f  8bc2                     mov eax, edx
000c78a1  488d155887f3ff           lea rdx, [rip - 0xc78a8]
000c78a8  4c8bacc200273100         mov r13, qword ptr [rdx + rax*8 + 0x312700]
000c78b0  448b7578                 mov r14d, dword ptr [rbp + 0x78]
000c78b4  418bf6                   mov esi, r14d
000c78b7  81e602002f01             and esi, 0x12f0002
000c78bd  4533e4                   xor r12d, r12d
000c78c0  418bdc                   mov ebx, r12d
000c78c3  83f92a                   cmp ecx, 0x2a
000c78c6  0f87af0e0000             ja 0xc877b
000c78cc  4863c1                   movsxd rax, ecx
000c78cf  8b8c8298870c00           mov ecx, dword ptr [rdx + rax*4 + 0xc8798]
000c78d6  4803ca                   add rcx, rdx
000c78d9  ffe1                     jmp rcx
000c78db  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c78df  488d8380000000           lea rax, [rbx + 0x80]
000c78e6  49894028                 mov qword ptr [r8 + 0x28], rax
000c78ea  664183483001             or word ptr [r8 + 0x30], 1
000c78f0  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c78f4  4885db                   test rbx, rbx
000c78f7  744c                     je 0xc7945
000c78f9  c7430801000000           mov dword ptr [rbx + 8], 1
000c7900  488d0501f91700           lea rax, [rip + 0x17f901]
000c7907  488903                   mov qword ptr [rbx], rax
000c790a  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7912  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7916  4c896320                 mov qword ptr [rbx + 0x20], r12
000c791a  44896328                 mov dword ptr [rbx + 0x28], r12d
000c791e  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7922  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7926  4c896340                 mov qword ptr [rbx + 0x40], r12
000c792a  4c896348                 mov qword ptr [rbx + 0x48], r12
000c792e  488d05eb6c1800           lea rax, [rip + 0x186ceb]
000c7935  488903                   mov qword ptr [rbx], rax
000c7938  488d4368                 lea rax, [rbx + 0x68]
000c793c  48894008                 mov qword ptr [rax + 8], rax
000c7940  488900                   mov qword ptr [rax], rax
000c7943  eb03                     jmp 0xc7948
000c7945  498bdc                   mov rbx, r12
000c7948  e9060e0000               jmp 0xc8753
000c794d  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c7951  488d8350040000           lea rax, [rbx + 0x450]
000c7958  49894028                 mov qword ptr [r8 + 0x28], rax
000c795c  664183483001             or word ptr [r8 + 0x30], 1
000c7962  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c7966  4885db                   test rbx, rbx
000c7969  7464                     je 0xc79cf
000c796b  c7430801000000           mov dword ptr [rbx + 8], 1
000c7972  488d058ff81700           lea rax, [rip + 0x17f88f]
000c7979  488903                   mov qword ptr [rbx], rax
000c797c  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7984  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7988  4c896320                 mov qword ptr [rbx + 0x20], r12
000c798c  44896328                 mov dword ptr [rbx + 0x28], r12d
000c7990  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7994  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7998  4c896340                 mov qword ptr [rbx + 0x40], r12
000c799c  4c896348                 mov qword ptr [rbx + 0x48], r12
000c79a0  488d05796c1800           lea rax, [rip + 0x186c79]
000c79a7  488903                   mov qword ptr [rbx], rax
000c79aa  488d4368                 lea rax, [rbx + 0x68]
000c79ae  48894008                 mov qword ptr [rax + 8], rax
000c79b2  488900                   mov qword ptr [rax], rax
000c79b5  488d05b4691800           lea rax, [rip + 0x1869b4]
000c79bc  488903                   mov qword ptr [rbx], rax
000c79bf  488d0512e41900           lea rax, [rip + 0x19e412]
000c79c6  48898390000000           mov qword ptr [rbx + 0x90], rax
000c79cd  eb03                     jmp 0xc79d2
000c79cf  498bdc                   mov rbx, r12
000c79d2  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000c79db  8b05efd52400             mov eax, dword ptr [rip + 0x24d5ef]
000c79e1  8b3dd19ef3ff             mov edi, dword ptr [rip - 0xc612f]
000c79e7  48033cc1                 add rdi, qword ptr [rcx + rax*8]
000c79eb  488b8700010000           mov rax, qword ptr [rdi + 0x100]
000c79f2  4885c0                   test rax, rax
000c79f5  750e                     jne 0xc7a05
000c79f7  33c9                     xor ecx, ecx
000c79f9  e812c7f6ff               call 0x34110
000c79fe  488b8700010000           mov rax, qword ptr [rdi + 0x100]
000c7a05  488b8058020000           mov rax, qword ptr [rax + 0x258]
000c7a0c  48898380000000           mov qword ptr [rbx + 0x80], rax
000c7a13  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c7a1d  89b38c000000             mov dword ptr [rbx + 0x8c], esi
000c7a23  4489a338040000           mov dword ptr [rbx + 0x438], r12d
000c7a2a  418bc6                   mov eax, r14d
000c7a2d  c1e819                   shr eax, 0x19
000c7a30  83e001                   and eax, 1
000c7a33  89833c040000             mov dword ptr [rbx + 0x43c], eax
000c7a39  4489a340040000           mov dword ptr [rbx + 0x440], r12d
000c7a40  4c89a348040000           mov qword ptr [rbx + 0x448], r12
000c7a47  488d8b90000000           lea rcx, [rbx + 0x90]
000c7a4e  4c8bcb                   mov r9, rbx
000c7a51  448bc6                   mov r8d, esi
000c7a54  498bd5                   mov rdx, r13
000c7a57  e854090a00               call 0x1683b0
000c7a5c  e9f20c0000               jmp 0xc8753
000c7a61  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7a65  488d8100010000           lea rax, [rcx + 0x100]
000c7a6c  49894028                 mov qword ptr [r8 + 0x28], rax
000c7a70  664183483001             or word ptr [r8 + 0x30], 1
000c7a76  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7a7a  4885c9                   test rcx, rcx
000c7a7d  740a                     je 0xc7a89
000c7a7f  e83c5d0000               call 0xcd7c0
000c7a84  488bd8                   mov rbx, rax
000c7a87  eb03                     jmp 0xc7a8c
000c7a89  498bdc                   mov rbx, r12
000c7a8c  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000c7a93  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000c7a98  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000c7a9f  488bcb                   mov rcx, rbx
000c7aa2  e8e9b70100               call 0xe3290
000c7aa7  e9a70c0000               jmp 0xc8753
000c7aac  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c7ab0  488d8390000000           lea rax, [rbx + 0x90]
000c7ab7  49894028                 mov qword ptr [r8 + 0x28], rax
000c7abb  664183483001             or word ptr [r8 + 0x30], 1
000c7ac1  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c7ac5  4885db                   test rbx, rbx
000c7ac8  745d                     je 0xc7b27
000c7aca  c7430801000000           mov dword ptr [rbx + 8], 1
000c7ad1  488d0530f71700           lea rax, [rip + 0x17f730]
000c7ad8  488903                   mov qword ptr [rbx], rax
000c7adb  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7ae3  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7ae7  4c896320                 mov qword ptr [rbx + 0x20], r12
000c7aeb  44896328                 mov dword ptr [rbx + 0x28], r12d
000c7aef  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7af3  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7af7  4c896340                 mov qword ptr [rbx + 0x40], r12
000c7afb  4c896348                 mov qword ptr [rbx + 0x48], r12
000c7aff  488d051a6b1800           lea rax, [rip + 0x186b1a]
000c7b06  488903                   mov qword ptr [rbx], rax
000c7b09  488d4368                 lea rax, [rbx + 0x68]
000c7b0d  48894008                 mov qword ptr [rax + 8], rax
000c7b11  488900                   mov qword ptr [rax], rax
000c7b14  488d0505341800           lea rax, [rip + 0x183405]
000c7b1b  488903                   mov qword ptr [rbx], rax
000c7b1e  4c89a380000000           mov qword ptr [rbx + 0x80], r12
000c7b25  eb03                     jmp 0xc7b2a
000c7b27  498bdc                   mov rbx, r12
000c7b2a  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c7b31  0f1008                   movups xmm1, xmmword ptr [rax]
000c7b34  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c7b38  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c7b3c  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c7b40  66480f7eca               movq rdx, xmm1
000c7b45  48c1ea20                 shr rdx, 0x20
000c7b49  f6c201                   test dl, 1
000c7b4c  0f85010c0000             jne 0xc8753
000c7b52  81e22ffbffff             and edx, 0xfffffb2f
000c7b58  81ca20020000             or edx, 0x220
000c7b5e  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c7b62  48c1e820                 shr rax, 0x20
000c7b66  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c7b6a  498bc8                   mov rcx, r8
000c7b6d  48c1e920                 shr rcx, 0x20
000c7b71  49c1e810                 shr r8, 0x10
000c7b75  89442438                 mov dword ptr [rsp + 0x38], eax
000c7b79  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c7b7c  89442430                 mov dword ptr [rsp + 0x30], eax
000c7b80  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c7b84  664489442420             mov word ptr [rsp + 0x20], r8w
000c7b8a  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c7b8f  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c7b93  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c7b96  e87599f4ff               call 0x11510
000c7b9b  48898380000000           mov qword ptr [rbx + 0x80], rax
000c7ba2  4885c0                   test rax, rax
000c7ba5  0f95c0                   setne al
000c7ba8  84c0                     test al, al
000c7baa  0f85a30b0000             jne 0xc8753
000c7bb0  498bdc                   mov rbx, r12
000c7bb3  e9c30b0000               jmp 0xc877b
000c7bb8  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c7bbc  488d8360040000           lea rax, [rbx + 0x460]
000c7bc3  49894028                 mov qword ptr [r8 + 0x28], rax
000c7bc7  664183483001             or word ptr [r8 + 0x30], 1
000c7bcd  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c7bd1  4885db                   test rbx, rbx
000c7bd4  7475                     je 0xc7c4b
000c7bd6  c7430801000000           mov dword ptr [rbx + 8], 1
000c7bdd  488d0524f61700           lea rax, [rip + 0x17f624]
000c7be4  488903                   mov qword ptr [rbx], rax
000c7be7  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7bef  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7bf3  4c896320                 mov qword ptr [rbx + 0x20], r12
000c7bf7  44896328                 mov dword ptr [rbx + 0x28], r12d
000c7bfb  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7bff  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7c03  4c896340                 mov qword ptr [rbx + 0x40], r12
000c7c07  4c896348                 mov qword ptr [rbx + 0x48], r12
000c7c0b  488d050e6a1800           lea rax, [rip + 0x186a0e]
000c7c12  488903                   mov qword ptr [rbx], rax
000c7c15  488d4368                 lea rax, [rbx + 0x68]
000c7c19  48894008                 mov qword ptr [rax + 8], rax
000c7c1d  488900                   mov qword ptr [rax], rax
000c7c20  488d0549671800           lea rax, [rip + 0x186749]
000c7c27  488903                   mov qword ptr [rbx], rax
000c7c2a  488d05a7e11900           lea rax, [rip + 0x19e1a7]
000c7c31  48898390000000           mov qword ptr [rbx + 0x90], rax
000c7c38  488d0591351800           lea rax, [rip + 0x183591]
000c7c3f  488903                   mov qword ptr [rbx], rax
000c7c42  4c89a350040000           mov qword ptr [rbx + 0x450], r12
000c7c49  eb03                     jmp 0xc7c4e
000c7c4b  498bdc                   mov rbx, r12
000c7c4e  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c7c55  0f1008                   movups xmm1, xmmword ptr [rax]
000c7c58  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c7c5c  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c7c60  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c7c64  66480f7eca               movq rdx, xmm1
000c7c69  48c1ea20                 shr rdx, 0x20
000c7c6d  f6c201                   test dl, 1
000c7c70  0f855cfdffff             jne 0xc79d2
000c7c76  81e22ffbffff             and edx, 0xfffffb2f
000c7c7c  81ca20020000             or edx, 0x220
000c7c82  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c7c86  48c1e820                 shr rax, 0x20
000c7c8a  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c7c8e  498bc8                   mov rcx, r8
000c7c91  48c1e920                 shr rcx, 0x20
000c7c95  49c1e810                 shr r8, 0x10
000c7c99  89442438                 mov dword ptr [rsp + 0x38], eax
000c7c9d  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c7ca0  89442430                 mov dword ptr [rsp + 0x30], eax
000c7ca4  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c7ca8  664489442420             mov word ptr [rsp + 0x20], r8w
000c7cae  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c7cb3  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c7cb7  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c7cba  e85198f4ff               call 0x11510
000c7cbf  48898350040000           mov qword ptr [rbx + 0x450], rax
000c7cc6  4885c0                   test rax, rax
000c7cc9  0f95c0                   setne al
000c7ccc  84c0                     test al, al
000c7cce  0f85fefcffff             jne 0xc79d2
000c7cd4  498bdc                   mov rbx, r12
000c7cd7  e99f0a0000               jmp 0xc877b
000c7cdc  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7ce0  488d8160010000           lea rax, [rcx + 0x160]
000c7ce7  49894028                 mov qword ptr [r8 + 0x28], rax
000c7ceb  664183483001             or word ptr [r8 + 0x30], 1
000c7cf1  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7cf5  4885c9                   test rcx, rcx
000c7cf8  740a                     je 0xc7d04
000c7cfa  e811dd0100               call 0xe5a10
000c7cff  488bd8                   mov rbx, rax
000c7d02  eb03                     jmp 0xc7d07
000c7d04  498bdc                   mov rbx, r12
000c7d07  e9470a0000               jmp 0xc8753
000c7d0c  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7d10  488d81d0010000           lea rax, [rcx + 0x1d0]
000c7d17  49894028                 mov qword ptr [r8 + 0x28], rax
000c7d1b  664183483001             or word ptr [r8 + 0x30], 1
000c7d21  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7d25  4885c9                   test rcx, rcx
000c7d28  740a                     je 0xc7d34
000c7d2a  e8515b0000               call 0xcd880
000c7d2f  488bd8                   mov rbx, rax
000c7d32  eb03                     jmp 0xc7d37
000c7d34  498bdc                   mov rbx, r12
000c7d37  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000c7d3e  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000c7d43  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000c7d4a  488bcb                   mov rcx, rbx
000c7d4d  e83e550200               call 0xed290
000c7d52  e9fc090000               jmp 0xc8753
000c7d57  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7d5b  488d8160010000           lea rax, [rcx + 0x160]
000c7d62  49894028                 mov qword ptr [r8 + 0x28], rax
000c7d66  664183483001             or word ptr [r8 + 0x30], 1
000c7d6c  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7d70  4885c9                   test rcx, rcx
000c7d73  740a                     je 0xc7d7f
000c7d75  e8261f0200               call 0xe9ca0
000c7d7a  488bd8                   mov rbx, rax
000c7d7d  eb03                     jmp 0xc7d82
000c7d7f  498bdc                   mov rbx, r12
000c7d82  e9a3fdffff               jmp 0xc7b2a
000c7d87  498b5828                 mov rbx, qword ptr [r8 + 0x28]
000c7d8b  488d83d0000000           lea rax, [rbx + 0xd0]
000c7d92  49894028                 mov qword ptr [r8 + 0x28], rax
000c7d96  664183483001             or word ptr [r8 + 0x30], 1
000c7d9c  48895d58                 mov qword ptr [rbp + 0x58], rbx
000c7da0  4885db                   test rbx, rbx
000c7da3  0f8485000000             je 0xc7e2e
000c7da9  c7430801000000           mov dword ptr [rbx + 8], 1
000c7db0  488d0551f41700           lea rax, [rip + 0x17f451]
000c7db7  488903                   mov qword ptr [rbx], rax
000c7dba  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c7dc2  44896318                 mov dword ptr [rbx + 0x18], r12d
000c7dc6  4c896320                 mov qword ptr [rbx + 0x20], r12
000c7dca  44896328                 mov dword ptr [rbx + 0x28], r12d
000c7dce  4c896330                 mov qword ptr [rbx + 0x30], r12
000c7dd2  4c896338                 mov qword ptr [rbx + 0x38], r12
000c7dd6  4c896340                 mov qword ptr [rbx + 0x40], r12
000c7dda  4c896348                 mov qword ptr [rbx + 0x48], r12
000c7dde  488d053b681800           lea rax, [rip + 0x18683b]
000c7de5  488903                   mov qword ptr [rbx], rax
000c7de8  488d4368                 lea rax, [rbx + 0x68]
000c7dec  48894008                 mov qword ptr [rax + 8], rax
000c7df0  488900                   mov qword ptr [rax], rax
000c7df3  488d05ae1f1800           lea rax, [rip + 0x181fae]
000c7dfa  488903                   mov qword ptr [rbx], rax
000c7dfd  4c89a380000000           mov qword ptr [rbx + 0x80], r12
000c7e04  0f57c0                   xorps xmm0, xmm0
000c7e07  33c0                     xor eax, eax
000c7e09  0f118388000000           movups xmmword ptr [rbx + 0x88], xmm0
000c7e10  0f118398000000           movups xmmword ptr [rbx + 0x98], xmm0
000c7e17  0f1183a8000000           movups xmmword ptr [rbx + 0xa8], xmm0
000c7e1e  0f1183b8000000           movups xmmword ptr [rbx + 0xb8], xmm0
000c7e25  488983c8000000           mov qword ptr [rbx + 0xc8], rax
000c7e2c  eb03                     jmp 0xc7e31
000c7e2e  498bdc                   mov rbx, r12
000c7e31  e91d090000               jmp 0xc8753
000c7e36  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7e3a  488d81e0000000           lea rax, [rcx + 0xe0]
000c7e41  49894028                 mov qword ptr [r8 + 0x28], rax
000c7e45  664183483001             or word ptr [r8 + 0x30], 1
000c7e4b  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7e4f  4885c9                   test rcx, rcx
000c7e52  740a                     je 0xc7e5e
000c7e54  e8d7540200               call 0xed330
000c7e59  488bd8                   mov rbx, rax
000c7e5c  eb03                     jmp 0xc7e61
000c7e5e  498bdc                   mov rbx, r12
000c7e61  e9c4fcffff               jmp 0xc7b2a
000c7e66  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7e6a  488d8130050000           lea rax, [rcx + 0x530]
000c7e71  49894028                 mov qword ptr [r8 + 0x28], rax
000c7e75  664183483001             or word ptr [r8 + 0x30], 1
000c7e7b  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7e7f  4885c9                   test rcx, rcx
000c7e82  740a                     je 0xc7e8e
000c7e84  e857fc0100               call 0xe7ae0
000c7e89  488bd8                   mov rbx, rax
000c7e8c  eb03                     jmp 0xc7e91
000c7e8e  498bdc                   mov rbx, r12
000c7e91  4c89a380000000           mov qword ptr [rbx + 0x80], r12
000c7e98  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c7ea2  89b38c000000             mov dword ptr [rbx + 0x8c], esi
000c7ea8  4c89a338040000           mov qword ptr [rbx + 0x438], r12
000c7eaf  e985fbffff               jmp 0xc7a39
000c7eb4  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7eb8  488d8130050000           lea rax, [rcx + 0x530]
000c7ebf  49894028                 mov qword ptr [r8 + 0x28], rax
000c7ec3  664183483001             or word ptr [r8 + 0x30], 1
000c7ec9  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7ecd  4885c9                   test rcx, rcx
000c7ed0  740a                     je 0xc7edc
000c7ed2  e8b9400200               call 0xebf90
000c7ed7  488bd8                   mov rbx, rax
000c7eda  eb03                     jmp 0xc7edf
000c7edc  498bdc                   mov rbx, r12
000c7edf  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c7ee6  0f1008                   movups xmm1, xmmword ptr [rax]
000c7ee9  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c7eed  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c7ef1  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c7ef5  66480f7eca               movq rdx, xmm1
000c7efa  48c1ea20                 shr rdx, 0x20
000c7efe  f6c201                   test dl, 1
000c7f01  758e                     jne 0xc7e91
000c7f03  81e22ffbffff             and edx, 0xfffffb2f
000c7f09  81ca20020000             or edx, 0x220
000c7f0f  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c7f13  48c1e820                 shr rax, 0x20
000c7f17  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c7f1b  498bc8                   mov rcx, r8
000c7f1e  48c1e920                 shr rcx, 0x20
000c7f22  49c1e810                 shr r8, 0x10
000c7f26  89442438                 mov dword ptr [rsp + 0x38], eax
000c7f2a  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c7f2d  89442430                 mov dword ptr [rsp + 0x30], eax
000c7f31  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c7f35  664489442420             mov word ptr [rsp + 0x20], r8w
000c7f3b  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c7f40  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c7f44  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c7f47  e8c495f4ff               call 0x11510
000c7f4c  48898350040000           mov qword ptr [rbx + 0x450], rax
000c7f53  4885c0                   test rax, rax
000c7f56  0f95c0                   setne al
000c7f59  84c0                     test al, al
000c7f5b  0f8530ffffff             jne 0xc7e91
000c7f61  498bdc                   mov rbx, r12
000c7f64  e912080000               jmp 0xc877b
000c7f69  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7f6d  488d81a0040000           lea rax, [rcx + 0x4a0]
000c7f74  49894028                 mov qword ptr [r8 + 0x28], rax
000c7f78  664183483001             or word ptr [r8 + 0x30], 1
000c7f7e  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7f82  4885c9                   test rcx, rcx
000c7f85  740a                     je 0xc7f91
000c7f87  e864540200               call 0xed3f0
000c7f8c  488bd8                   mov rbx, rax
000c7f8f  eb03                     jmp 0xc7f94
000c7f91  498bdc                   mov rbx, r12
000c7f94  e939faffff               jmp 0xc79d2
000c7f99  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7f9d  488d81b0040000           lea rax, [rcx + 0x4b0]
000c7fa4  49894028                 mov qword ptr [r8 + 0x28], rax
000c7fa8  664183483001             or word ptr [r8 + 0x30], 1
000c7fae  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7fb2  4885c9                   test rcx, rcx
000c7fb5  740a                     je 0xc7fc1
000c7fb7  e8f4540200               call 0xed4b0
000c7fbc  488bd8                   mov rbx, rax
000c7fbf  eb03                     jmp 0xc7fc4
000c7fc1  498bdc                   mov rbx, r12
000c7fc4  e985fcffff               jmp 0xc7c4e
000c7fc9  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7fcd  488d81b0010000           lea rax, [rcx + 0x1b0]
000c7fd4  49894028                 mov qword ptr [r8 + 0x28], rax
000c7fd8  664183483001             or word ptr [r8 + 0x30], 1
000c7fde  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c7fe2  4885c9                   test rcx, rcx
000c7fe5  740a                     je 0xc7ff1
000c7fe7  e894550200               call 0xed580
000c7fec  488bd8                   mov rbx, rax
000c7fef  eb03                     jmp 0xc7ff4
000c7ff1  498bdc                   mov rbx, r12
000c7ff4  e95a070000               jmp 0xc8753
000c7ff9  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c7ffd  488d81b0010000           lea rax, [rcx + 0x1b0]
000c8004  49894028                 mov qword ptr [r8 + 0x28], rax
000c8008  664183483001             or word ptr [r8 + 0x30], 1
000c800e  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c8012  4885c9                   test rcx, rcx
000c8015  740a                     je 0xc8021
000c8017  e8d4550200               call 0xed5f0
000c801c  488bd8                   mov rbx, rax
000c801f  eb03                     jmp 0xc8024
000c8021  498bdc                   mov rbx, r12
000c8024  e901fbffff               jmp 0xc7b2a
000c8029  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c802d  488d8180050000           lea rax, [rcx + 0x580]
000c8034  49894028                 mov qword ptr [r8 + 0x28], rax
000c8038  664183483001             or word ptr [r8 + 0x30], 1
000c803e  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c8042  4885c9                   test rcx, rcx
000c8045  740a                     je 0xc8051
000c8047  e814560200               call 0xed660
000c804c  488bd8                   mov rbx, rax
000c804f  eb03                     jmp 0xc8054
000c8051  498bdc                   mov rbx, r12
000c8054  e938feffff               jmp 0xc7e91
000c8059  498b4828                 mov rcx, qword ptr [r8 + 0x28]
000c805d  488d8180050000           lea rax, [rcx + 0x580]
000c8064  49894028                 mov qword ptr [r8 + 0x28], rax
000c8068  664183483001             or word ptr [r8 + 0x30], 1
000c806e  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c8072  4885c9                   test rcx, rcx
000c8075  740a                     je 0xc8081
000c8077  e854560200               call 0xed6d0
000c807c  488bd8                   mov rbx, rax
000c807f  eb03                     jmp 0xc8084
000c8081  498bdc                   mov rbx, r12
000c8084  e956feffff               jmp 0xc7edf
000c8089  4d8d7828                 lea r15, [r8 + 0x28]
000c808d  498b0f                   mov rcx, qword ptr [r15]
000c8090  488d8120020000           lea rax, [rcx + 0x220]
000c8097  498907                   mov qword ptr [r15], rax
000c809a  498d7030                 lea rsi, [r8 + 0x30]
000c809e  66830e01                 or word ptr [rsi], 1
000c80a2  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c80a6  4885c9                   test rcx, rcx
000c80a9  740a                     je 0xc80b5
000c80ab  e850580000               call 0xcd900
000c80b0  488bd8                   mov rbx, rax
000c80b3  eb03                     jmp 0xc80b8
000c80b5  498bdc                   mov rbx, r12
000c80b8  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000c80bf  418b4504                 mov eax, dword ptr [r13 + 4]
000c80c3  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000c80ca  41be00020000             mov r14d, 0x200
000c80d0  a802                     test al, 2
000c80d2  743c                     je 0xc8110
000c80d4  a820                     test al, 0x20
000c80d6  7538                     jne 0xc8110
000c80d8  a810                     test al, 0x10
000c80da  7534                     jne 0xc8110
000c80dc  a801                     test al, 1
000c80de  7530                     jne 0xc8110
000c80e0  4185c6                   test r14d, eax
000c80e3  752b                     jne 0xc8110
000c80e5  a840                     test al, 0x40
000c80e7  7527                     jne 0xc8110
000c80e9  803d008f250000           cmp byte ptr [rip + 0x258f00], 0
000c80f0  741e                     je 0xc8110
000c80f2  8b05f4c92400             mov eax, dword ptr [rip + 0x24c9f4]
000c80f8  83f801                   cmp eax, 1
000c80fb  7613                     jbe 0xc8110
000c80fd  c7837801000001000000     mov dword ptr [rbx + 0x178], 1
000c8107  448b0ddec92400           mov r9d, dword ptr [rip + 0x24c9de]
000c810e  eb15                     jmp 0xc8125
000c8110  c7837801000000000000     mov dword ptr [rbx + 0x178], 0
000c811a  418bcc                   mov ecx, r12d
000c811d  e8ce760700               call 0x13f7f0
000c8122  448bc8                   mov r9d, eax
000c8125  418bc1                   mov eax, r9d
000c8128  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c8130  4883e0f0                 and rax, 0xfffffffffffffff0
000c8134  48c7835801000000000000   mov qword ptr [rbx + 0x158], 0
000c813f  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c8146  740b                     je 0xc8153
000c8148  6644397704               cmp word ptr [rdi + 4], r14w
000c814d  7504                     jne 0xc8153
000c814f  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c8153  498b0f                   mov rcx, qword ptr [r15]
000c8156  488d1401                 lea rdx, [rcx + rax]
000c815a  488d8700200000           lea rax, [rdi + 0x2000]
000c8161  483bd0                   cmp rdx, rax
000c8164  730e                     jae 0xc8174
000c8166  498917                   mov qword ptr [r15], rdx
000c8169  66830e01                 or word ptr [rsi], 1
000c816d  48898b58010000           mov qword ptr [rbx + 0x158], rcx
000c8174  4c896c2420               mov qword ptr [rsp + 0x20], r13
000c8179  458bc4                   mov r8d, r12d
000c817c  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000c8183  488bcb                   mov rcx, rbx
000c8186  e8f5920700               call 0x141480
000c818b  85c0                     test eax, eax
000c818d  0f85b9050000             jne 0xc874c
000c8193  33db                     xor ebx, ebx
000c8195  e9e1050000               jmp 0xc877b
000c819a  4d8d7828                 lea r15, [r8 + 0x28]
000c819e  498b0f                   mov rcx, qword ptr [r15]
000c81a1  488d8130020000           lea rax, [rcx + 0x230]
000c81a8  498907                   mov qword ptr [r15], rax
000c81ab  498d7030                 lea rsi, [r8 + 0x30]
000c81af  66830e01                 or word ptr [rsi], 1
000c81b3  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c81b7  4885c9                   test rcx, rcx
000c81ba  740a                     je 0xc81c6
000c81bc  e8bf570000               call 0xcd980
000c81c1  488bd8                   mov rbx, rax
000c81c4  eb03                     jmp 0xc81c9
000c81c6  498bdc                   mov rbx, r12
000c81c9  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000c81d0  418b4504                 mov eax, dword ptr [r13 + 4]
000c81d4  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000c81db  41be00020000             mov r14d, 0x200
000c81e1  a802                     test al, 2
000c81e3  743c                     je 0xc8221
000c81e5  a820                     test al, 0x20
000c81e7  7538                     jne 0xc8221
000c81e9  a810                     test al, 0x10
000c81eb  7534                     jne 0xc8221
000c81ed  a801                     test al, 1
000c81ef  7530                     jne 0xc8221
000c81f1  4185c6                   test r14d, eax
000c81f4  752b                     jne 0xc8221
000c81f6  a840                     test al, 0x40
000c81f8  7527                     jne 0xc8221
000c81fa  803def8d250000           cmp byte ptr [rip + 0x258def], 0
000c8201  741e                     je 0xc8221
000c8203  8b05e3c82400             mov eax, dword ptr [rip + 0x24c8e3]
000c8209  83f801                   cmp eax, 1
000c820c  7613                     jbe 0xc8221
000c820e  c7838001000001000000     mov dword ptr [rbx + 0x180], 1
000c8218  448b0dcdc82400           mov r9d, dword ptr [rip + 0x24c8cd]
000c821f  eb15                     jmp 0xc8236
000c8221  c7838001000000000000     mov dword ptr [rbx + 0x180], 0
000c822b  418bcc                   mov ecx, r12d
000c822e  e8bd750700               call 0x13f7f0
000c8233  448bc8                   mov r9d, eax
000c8236  418bc1                   mov eax, r9d
000c8239  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c8241  4883e0f0                 and rax, 0xfffffffffffffff0
000c8245  48c7836001000000000000   mov qword ptr [rbx + 0x160], 0
000c8250  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c8257  740b                     je 0xc8264
000c8259  6644397704               cmp word ptr [rdi + 4], r14w
000c825e  7504                     jne 0xc8264
000c8260  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c8264  498b0f                   mov rcx, qword ptr [r15]
000c8267  488d1401                 lea rdx, [rcx + rax]
000c826b  488d8700200000           lea rax, [rdi + 0x2000]
000c8272  483bd0                   cmp rdx, rax
000c8275  730e                     jae 0xc8285
000c8277  498917                   mov qword ptr [r15], rdx
000c827a  66830e01                 or word ptr [rsi], 1
000c827e  48898b60010000           mov qword ptr [rbx + 0x160], rcx
000c8285  4c896c2420               mov qword ptr [rsp + 0x20], r13
000c828a  458bc4                   mov r8d, r12d
000c828d  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000c8294  488bcb                   mov rcx, rbx
000c8297  e8449a0700               call 0x141ce0
000c829c  85c0                     test eax, eax
000c829e  0f84effeffff             je 0xc8193
000c82a4  410f104d00               movups xmm1, xmmword ptr [r13]
000c82a9  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c82ad  410f104510               movups xmm0, xmmword ptr [r13 + 0x10]
000c82b2  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c82b6  66480f7eca               movq rdx, xmm1
000c82bb  48c1ea20                 shr rdx, 0x20
000c82bf  f6c201                   test dl, 1
000c82c2  0f8584040000             jne 0xc874c
000c82c8  81e22ffbffff             and edx, 0xfffffb2f
000c82ce  81ca20020000             or edx, 0x220
000c82d4  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c82d8  48c1e820                 shr rax, 0x20
000c82dc  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c82e0  498bc8                   mov rcx, r8
000c82e3  48c1e920                 shr rcx, 0x20
000c82e7  49c1e810                 shr r8, 0x10
000c82eb  89442438                 mov dword ptr [rsp + 0x38], eax
000c82ef  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c82f2  89442430                 mov dword ptr [rsp + 0x30], eax
000c82f6  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c82fa  664489442420             mov word ptr [rsp + 0x20], r8w
000c8300  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c8305  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c8309  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c830c  e8ff91f4ff               call 0x11510
000c8311  48898380000000           mov qword ptr [rbx + 0x80], rax
000c8318  4885c0                   test rax, rax
000c831b  0f95c0                   setne al
000c831e  84c0                     test al, al
000c8320  0f8526040000             jne 0xc874c
000c8326  33db                     xor ebx, ebx
000c8328  e94e040000               jmp 0xc877b
000c832d  4d8d6028                 lea r12, [r8 + 0x28]
000c8331  498b0c24                 mov rcx, qword ptr [r12]
000c8335  488d81f0050000           lea rax, [rcx + 0x5f0]
000c833c  49890424                 mov qword ptr [r12], rax
000c8340  4d8d7830                 lea r15, [r8 + 0x30]
000c8344  6641830f01               or word ptr [r15], 1
000c8349  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c834d  4885c9                   test rcx, rcx
000c8350  740a                     je 0xc835c
000c8352  e8a9560000               call 0xcda00
000c8357  488bd8                   mov rbx, rax
000c835a  eb02                     jmp 0xc835e
000c835c  33db                     xor ebx, ebx
000c835e  4c8b9590000000           mov r10, qword ptr [rbp + 0x90]
000c8365  418b4204                 mov eax, dword ptr [r10 + 4]
000c8369  448b8588000000           mov r8d, dword ptr [rbp + 0x88]
000c8370  41be00020000             mov r14d, 0x200
000c8376  a802                     test al, 2
000c8378  743c                     je 0xc83b6
000c837a  a820                     test al, 0x20
000c837c  7538                     jne 0xc83b6
000c837e  a810                     test al, 0x10
000c8380  7534                     jne 0xc83b6
000c8382  a801                     test al, 1
000c8384  7530                     jne 0xc83b6
000c8386  4185c6                   test r14d, eax
000c8389  752b                     jne 0xc83b6
000c838b  a840                     test al, 0x40
000c838d  7527                     jne 0xc83b6
000c838f  803d5a8c250000           cmp byte ptr [rip + 0x258c5a], 0
000c8396  741e                     je 0xc83b6
000c8398  8b054ec72400             mov eax, dword ptr [rip + 0x24c74e]
000c839e  83f801                   cmp eax, 1
000c83a1  7613                     jbe 0xc83b6
000c83a3  c7834805000001000000     mov dword ptr [rbx + 0x548], 1
000c83ad  448b0d38c72400           mov r9d, dword ptr [rip + 0x24c738]
000c83b4  eb23                     jmp 0xc83d9
000c83b6  c7834805000000000000     mov dword ptr [rbx + 0x548], 0
000c83c0  418bc8                   mov ecx, r8d
000c83c3  e828740700               call 0x13f7f0
000c83c8  448bc8                   mov r9d, eax
000c83cb  448b8588000000           mov r8d, dword ptr [rbp + 0x88]
000c83d2  4c8b9590000000           mov r10, qword ptr [rbp + 0x90]
000c83d9  418bc1                   mov eax, r9d
000c83dc  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c83e4  4883e0f0                 and rax, 0xfffffffffffffff0
000c83e8  48c7832805000000000000   mov qword ptr [rbx + 0x528], 0
000c83f3  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c83fa  740b                     je 0xc8407
000c83fc  6644397704               cmp word ptr [rdi + 4], r14w
000c8401  7504                     jne 0xc8407
000c8403  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c8407  498b0c24                 mov rcx, qword ptr [r12]
000c840b  488d1401                 lea rdx, [rcx + rax]
000c840f  488d8700200000           lea rax, [rdi + 0x2000]
000c8416  483bd0                   cmp rdx, rax
000c8419  7310                     jae 0xc842b
000c841b  49891424                 mov qword ptr [r12], rdx
000c841f  6641830f01               or word ptr [r15], 1
000c8424  48898b28050000           mov qword ptr [rbx + 0x528], rcx
000c842b  4c89542420               mov qword ptr [rsp + 0x20], r10
000c8430  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000c8437  488bcb                   mov rcx, rbx
000c843a  e871940700               call 0x1418b0
000c843f  85c0                     test eax, eax
000c8441  0f844cfdffff             je 0xc8193
000c8447  4533e4                   xor r12d, r12d
000c844a  4c89a380000000           mov qword ptr [rbx + 0x80], r12
000c8451  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c845b  89b38c000000             mov dword ptr [rbx + 0x8c], esi
000c8461  4c89a338040000           mov qword ptr [rbx + 0x438], r12
000c8468  4489a340040000           mov dword ptr [rbx + 0x440], r12d
000c846f  4c89a348040000           mov qword ptr [rbx + 0x448], r12
000c8476  488d8b90000000           lea rcx, [rbx + 0x90]
000c847d  4c8bcb                   mov r9, rbx
000c8480  448bc6                   mov r8d, esi
000c8483  498bd5                   mov rdx, r13
000c8486  e825ff0900               call 0x1683b0
000c848b  e9bf020000               jmp 0xc874f
000c8490  4d8d6028                 lea r12, [r8 + 0x28]
000c8494  498b0c24                 mov rcx, qword ptr [r12]
000c8498  488d8100060000           lea rax, [rcx + 0x600]
000c849f  49890424                 mov qword ptr [r12], rax
000c84a3  4d8d7830                 lea r15, [r8 + 0x30]
000c84a7  6641830f01               or word ptr [r15], 1
000c84ac  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c84b0  4885c9                   test rcx, rcx
000c84b3  740a                     je 0xc84bf
000c84b5  e8c6550000               call 0xcda80
000c84ba  488bd8                   mov rbx, rax
000c84bd  eb02                     jmp 0xc84c1
000c84bf  33db                     xor ebx, ebx
000c84c1  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c84c8  8b4004                   mov eax, dword ptr [rax + 4]
000c84cb  448b8588000000           mov r8d, dword ptr [rbp + 0x88]
000c84d2  41be00020000             mov r14d, 0x200
000c84d8  a802                     test al, 2
000c84da  743c                     je 0xc8518
000c84dc  a820                     test al, 0x20
000c84de  7538                     jne 0xc8518
000c84e0  a810                     test al, 0x10
000c84e2  7534                     jne 0xc8518
000c84e4  a801                     test al, 1
000c84e6  7530                     jne 0xc8518
000c84e8  4185c6                   test r14d, eax
000c84eb  752b                     jne 0xc8518
000c84ed  a840                     test al, 0x40
000c84ef  7527                     jne 0xc8518
000c84f1  803df88a250000           cmp byte ptr [rip + 0x258af8], 0
000c84f8  741e                     je 0xc8518
000c84fa  8b05ecc52400             mov eax, dword ptr [rip + 0x24c5ec]
000c8500  83f801                   cmp eax, 1
000c8503  7613                     jbe 0xc8518
000c8505  c7835005000001000000     mov dword ptr [rbx + 0x550], 1
000c850f  448b0dd6c52400           mov r9d, dword ptr [rip + 0x24c5d6]
000c8516  eb1c                     jmp 0xc8534
000c8518  c7835005000000000000     mov dword ptr [rbx + 0x550], 0
000c8522  418bc8                   mov ecx, r8d
000c8525  e8c6720700               call 0x13f7f0
000c852a  448bc8                   mov r9d, eax
000c852d  448b8588000000           mov r8d, dword ptr [rbp + 0x88]
000c8534  418bc1                   mov eax, r9d
000c8537  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c853f  4883e0f0                 and rax, 0xfffffffffffffff0
000c8543  48c7833005000000000000   mov qword ptr [rbx + 0x530], 0
000c854e  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c8555  740b                     je 0xc8562
000c8557  6644397704               cmp word ptr [rdi + 4], r14w
000c855c  7504                     jne 0xc8562
000c855e  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c8562  498b0c24                 mov rcx, qword ptr [r12]
000c8566  488d1401                 lea rdx, [rcx + rax]
000c856a  488d8700200000           lea rax, [rdi + 0x2000]
000c8571  483bd0                   cmp rdx, rax
000c8574  7310                     jae 0xc8586
000c8576  49891424                 mov qword ptr [r12], rdx
000c857a  6641830f01               or word ptr [r15], 1
000c857f  48898b30050000           mov qword ptr [rbx + 0x530], rcx
000c8586  488bbd90000000           mov rdi, qword ptr [rbp + 0x90]
000c858d  48897c2420               mov qword ptr [rsp + 0x20], rdi
000c8592  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000c8599  488bcb                   mov rcx, rbx
000c859c  e86f9b0700               call 0x142110
000c85a1  85c0                     test eax, eax
000c85a3  0f84eafbffff             je 0xc8193
000c85a9  0f100f                   movups xmm1, xmmword ptr [rdi]
000c85ac  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c85b0  0f104710                 movups xmm0, xmmword ptr [rdi + 0x10]
000c85b4  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c85b8  66480f7eca               movq rdx, xmm1
000c85bd  48c1ea20                 shr rdx, 0x20
000c85c1  f6c201                   test dl, 1
000c85c4  0f857dfeffff             jne 0xc8447
000c85ca  81e22ffbffff             and edx, 0xfffffb2f
000c85d0  81ca20020000             or edx, 0x220
000c85d6  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c85da  48c1e820                 shr rax, 0x20
000c85de  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c85e2  498bc8                   mov rcx, r8
000c85e5  48c1e920                 shr rcx, 0x20
000c85e9  49c1e810                 shr r8, 0x10
000c85ed  89442438                 mov dword ptr [rsp + 0x38], eax
000c85f1  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c85f4  89442430                 mov dword ptr [rsp + 0x30], eax
000c85f8  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c85fc  664489442420             mov word ptr [rsp + 0x20], r8w
000c8602  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c8607  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c860b  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c860e  e8fd8ef4ff               call 0x11510
000c8613  48898350040000           mov qword ptr [rbx + 0x450], rax
000c861a  4885c0                   test rax, rax
000c861d  0f95c0                   setne al
000c8620  84c0                     test al, al
000c8622  0f851ffeffff             jne 0xc8447
000c8628  33db                     xor ebx, ebx
000c862a  e94c010000               jmp 0xc877b
000c862f  4d8d7828                 lea r15, [r8 + 0x28]
000c8633  498b0f                   mov rcx, qword ptr [r15]
000c8636  488d81a0020000           lea rax, [rcx + 0x2a0]
000c863d  498907                   mov qword ptr [r15], rax
000c8640  498d7030                 lea rsi, [r8 + 0x30]
000c8644  66830e01                 or word ptr [rsi], 1
000c8648  48894d58                 mov qword ptr [rbp + 0x58], rcx
000c864c  4885c9                   test rcx, rcx
000c864f  740a                     je 0xc865b
000c8651  e8aa540000               call 0xcdb00
000c8656  488bd8                   mov rbx, rax
000c8659  eb03                     jmp 0xc865e
000c865b  498bdc                   mov rbx, r12
000c865e  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000c8665  418b4504                 mov eax, dword ptr [r13 + 4]
000c8669  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000c8670  41be00020000             mov r14d, 0x200
000c8676  a802                     test al, 2
000c8678  743c                     je 0xc86b6
000c867a  a820                     test al, 0x20
000c867c  7538                     jne 0xc86b6
000c867e  a810                     test al, 0x10
000c8680  7534                     jne 0xc86b6
000c8682  a801                     test al, 1
000c8684  7530                     jne 0xc86b6
000c8686  4185c6                   test r14d, eax
000c8689  752b                     jne 0xc86b6
000c868b  a840                     test al, 0x40
000c868d  7527                     jne 0xc86b6
000c868f  803d5a89250000           cmp byte ptr [rip + 0x25895a], 0
000c8696  741e                     je 0xc86b6
000c8698  8b054ec42400             mov eax, dword ptr [rip + 0x24c44e]
000c869e  83f801                   cmp eax, 1
000c86a1  7613                     jbe 0xc86b6
000c86a3  c783f001000001000000     mov dword ptr [rbx + 0x1f0], 1
000c86ad  448b0d38c42400           mov r9d, dword ptr [rip + 0x24c438]
000c86b4  eb15                     jmp 0xc86cb
000c86b6  c783f001000000000000     mov dword ptr [rbx + 0x1f0], 0
000c86c0  418bcc                   mov ecx, r12d
000c86c3  e828710700               call 0x13f7f0
000c86c8  448bc8                   mov r9d, eax
000c86cb  418bc1                   mov eax, r9d
000c86ce  488d04c50f000000         lea rax, [rax*8 + 0xf]
000c86d6  4883e0f0                 and rax, 0xfffffffffffffff0
000c86da  48c783d001000000000000   mov qword ptr [rbx + 0x1d0], 0
000c86e5  4881e700e0ffff           and rdi, 0xffffffffffffe000
000c86ec  740b                     je 0xc86f9
000c86ee  6644397704               cmp word ptr [rdi + 4], r14w
000c86f3  7504                     jne 0xc86f9
000c86f5  488b7f28                 mov rdi, qword ptr [rdi + 0x28]
000c86f9  498b0f                   mov rcx, qword ptr [r15]
000c86fc  488d1401                 lea rdx, [rcx + rax]
000c8700  488d8700200000           lea rax, [rdi + 0x2000]
000c8707  483bd0                   cmp rdx, rax
000c870a  730e                     jae 0xc871a
000c870c  498917                   mov qword ptr [r15], rdx
000c870f  66830e01                 or word ptr [rsi], 1
000c8713  48898bd0010000           mov qword ptr [rbx + 0x1d0], rcx
000c871a  4c896c2420               mov qword ptr [rsp + 0x20], r13
000c871f  458bc4                   mov r8d, r12d
000c8722  488bbd80000000           mov rdi, qword ptr [rbp + 0x80]
000c8729  488bd7                   mov rdx, rdi
000c872c  488bcb                   mov rcx, rbx
000c872f  e80c9e0700               call 0x142540
000c8734  85c0                     test eax, eax
000c8736  0f8457faffff             je 0xc8193
000c873c  440fb64744               movzx r8d, byte ptr [rdi + 0x44]
000c8741  498bd5                   mov rdx, r13
000c8744  488bcb                   mov rcx, rbx
000c8747  e8444b0200               call 0xed290
000c874c  4533e4                   xor r12d, r12d
000c874f  448b7578                 mov r14d, dword ptr [rbp + 0x78]
000c8753  4885db                   test rbx, rbx
000c8756  7423                     je 0xc877b
000c8758  4c896350                 mov qword ptr [rbx + 0x50], r12
000c875c  4c896360                 mov qword ptr [rbx + 0x60], r12
000c8760  4c896358                 mov qword ptr [rbx + 0x58], r12
000c8764  c7437801000000           mov dword ptr [rbx + 0x78], 1
000c876b  41c1ee17                 shr r14d, 0x17
000c876f  4183e601                 and r14d, 1
000c8773  4489737c                 mov dword ptr [rbx + 0x7c], r14d
000c8777  834b2802                 or dword ptr [rbx + 0x28], 2
000c877b  488bc3                   mov rax, rbx
000c877e  488b9c24b0000000         mov rbx, qword ptr [rsp + 0xb0]
000c8786  4883c470                 add rsp, 0x70
000c878a  415f                     pop r15
000c878c  415e                     pop r14
000c878e  415d                     pop r13
000c8790  415c                     pop r12
000c8792  5f                       pop rdi
000c8793  5e                       pop rsi
000c8794  5d                       pop rbp
000c8795  c3                       ret
000c8796  90                       nop
000c8797  90                       nop
000c8798  db780c                   fstp xword ptr [rax + 0xc]
000c879b  004d79                   add byte ptr [rbp + 0x79], cl
000c879e  0c00                     or al, 0
000c87a0  dc7c0c00                 fdivr qword ptr [rsp + rcx]
000c87a4  667e0c                   jle 0xc87b3
000c87a7  00877d0c0069             add byte ptr [rdi + 0x69000c7d], al
000c87ad  7f0c                     jg 0xc87bb
000c87af  00c9                     add cl, cl
000c87b1  7f0c                     jg 0xc87bf
000c87b3  0029                     add byte ptr [rcx], ch
000c87b5  800c007b                 or byte ptr [rax + rax], 0x7b
000c87b9  870c00                   xchg dword ptr [rax + rax], ecx
000c87bc  7b87                     jnp 0xc8745
000c87be  0c00                     or al, 0
000c87c0  89800c002d83             mov dword ptr [rax - 0x7cd2fff4], eax
000c87c6  0c00                     or al, 0
000c87c8  7b87                     jnp 0xc8751
000c87ca  0c00                     or al, 0
000c87cc  7b87                     jnp 0xc8755
000c87ce  0c00                     or al, 0
000c87d0  7b87                     jnp 0xc8759
000c87d2  0c00                     or al, 0
000c87d4  7b87                     jnp 0xc875d
000c87d6  0c00                     or al, 0
000c87d8  ac                       lodsb al, byte ptr [rsi]
000c87d9  7a0c                     jp 0xc87e7
000c87db  00b87b0c0057             add byte ptr [rax + 0x57000c7b], bh
000c87e1  7d0c                     jge 0xc87ef
000c87e3  00b47e0c00367e           add byte ptr [rsi + rdi*2 + 0x7e36000c], dh
000c87ea  0c00                     or al, 0
000c87ec  99                       cdq
000c87ed  7f0c                     jg 0xc87fb
000c87ef  00f9                     add cl, bh
000c87f1  7f0c                     jg 0xc87ff
000c87f3  005980                   add byte ptr [rcx - 0x80], bl
000c87f6  0c00                     or al, 0
000c87f8  7b87                     jnp 0xc8781
000c87fa  0c00                     or al, 0
000c87fc  7b87                     jnp 0xc8785
000c87fe  0c00                     or al, 0
