; `XE_Session::CreateCollections'::`1'::dtor$3
; sqldk.dll, primary RVA 0x234ba7, 59 bytes in 1 chunk(s)

; chunk at RVA 0x234ba7 (59 bytes)
00234ba7  4055                     push rbp
00234ba9  4883ec30                 sub rsp, 0x30
00234bad  488bea                   mov rbp, rdx
00234bb0  c644242806               mov byte ptr [rsp + 0x28], 6
00234bb5  8b85b0000000             mov eax, dword ptr [rbp + 0xb0]
00234bbb  89442420                 mov dword ptr [rsp + 0x20], eax
00234bbf  4c8d0db25c0700           lea r9, [rip + 0x75cb2]
00234bc6  41b801000000             mov r8d, 1
00234bcc  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
00234bd3  488b4d50                 mov rcx, qword ptr [rbp + 0x50]
00234bd7  e8e452faff               call 0x1d9ec0
00234bdc  4883c430                 add rsp, 0x30
00234be0  5d                       pop rbp
00234be1  c3                       ret
