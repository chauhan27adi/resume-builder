; `XEPackage0::CounterTarget::AddPackage'::`1'::dtor$1
; sqldk.dll, primary RVA 0x2318b0, 35 bytes in 1 chunk(s)

; chunk at RVA 0x2318b0 (35 bytes)
002318b0  4055                     push rbp
002318b2  4883ec20                 sub rsp, 0x20
002318b6  488bea                   mov rbp, rdx
002318b9  4c8b85b8000000           mov r8, qword ptr [rbp + 0xb8]
002318c0  488b5538                 mov rdx, qword ptr [rbp + 0x38]
002318c4  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
002318c8  e843f7dcff               call 0x1010
002318cd  4883c420                 add rsp, 0x20
002318d1  5d                       pop rbp
002318d2  c3                       ret
