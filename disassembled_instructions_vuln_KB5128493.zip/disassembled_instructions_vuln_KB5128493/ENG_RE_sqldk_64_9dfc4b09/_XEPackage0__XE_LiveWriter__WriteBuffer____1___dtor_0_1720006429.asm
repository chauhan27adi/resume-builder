; `XEPackage0::XE_LiveWriter::WriteBuffer'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2321b0, 31 bytes in 1 chunk(s)

; chunk at RVA 0x2321b0 (31 bytes)
002321b0  4055                     push rbp
002321b2  4883ec20                 sub rsp, 0x20
002321b6  488bea                   mov rbp, rdx
002321b9  4533c0                   xor r8d, r8d
002321bc  488b5578                 mov rdx, qword ptr [rbp + 0x78]
002321c0  488b4d28                 mov rcx, qword ptr [rbp + 0x28]
002321c4  e847eedcff               call 0x1010
002321c9  4883c420                 add rsp, 0x20
002321cd  5d                       pop rbp
002321ce  c3                       ret
