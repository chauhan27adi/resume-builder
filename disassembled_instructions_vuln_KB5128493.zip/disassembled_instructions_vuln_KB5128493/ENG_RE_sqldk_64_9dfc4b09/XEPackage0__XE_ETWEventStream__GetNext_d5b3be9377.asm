; XEPackage0::XE_ETWEventStream::GetNext
; sqldk.dll, primary RVA 0x1c0870, 1132 bytes in 6 chunk(s)

; chunk at RVA 0x1c0870 (281 bytes)
001c0870  4053                     push rbx
001c0872  56                       push rsi
001c0873  57                       push rdi
001c0874  4156                     push r14
001c0876  4883ec28                 sub rsp, 0x28
001c087a  33f6                     xor esi, esi
001c087c  4d8bd0                   mov r10, r8
001c087f  488bfa                   mov rdi, rdx
001c0882  488bd9                   mov rbx, rcx
001c0885  49397010                 cmp qword ptr [r8 + 0x10], rsi
001c0889  744f                     je 0x1c08da
001c088b  4d8b08                   mov r9, qword ptr [r8]
001c088e  4d85c9                   test r9, r9
001c0891  7447                     je 0x1c08da
001c0893  4d8b5820                 mov r11, qword ptr [r8 + 0x20]
001c0897  448bc6                   mov r8d, esi
001c089a  660f1f440000             nop word ptr [rax + rax]
001c08a0  418bc0                   mov eax, r8d
001c08a3  4869c83fff0000           imul rcx, rax, 0xff3f
001c08aa  4903cb                   add rcx, r11
001c08ad  493bc9                   cmp rcx, r9
001c08b0  7409                     je 0x1c08bb
001c08b2  41ffc0                   inc r8d
001c08b5  4183f810                 cmp r8d, 0x10
001c08b9  72e5                     jb 0x1c08a0
001c08bb  418bc8                   mov ecx, r8d
001c08be  418bc0                   mov eax, r8d
001c08c1  83e11f                   and ecx, 0x1f
001c08c4  ba01000000               mov edx, 1
001c08c9  d3e2                     shl edx, cl
001c08cb  f7d2                     not edx
001c08cd  48c1e805                 shr rax, 5
001c08d1  f041219483f0f30f00       lock and dword ptr [r11 + rax*4 + 0xff3f0], edx
001c08da  498932                   mov qword ptr [r10], rsi
001c08dd  4c8d1d1cf7e3ff           lea r11, [rip - 0x1c08e4]
001c08e4  41897208                 mov dword ptr [r10 + 8], esi
001c08e8  41beff030000             mov r14d, 0x3ff
001c08ee  49897210                 mov qword ptr [r10 + 0x10], rsi
001c08f2  41c7421c01000000         mov dword ptr [r10 + 0x1c], 1
001c08fa  6641897218               mov word ptr [r10 + 0x18], si
001c08ff  48634320                 movsxd rax, dword ptr [rbx + 0x20]
001c0903  8bd0                     mov edx, eax
001c0905  83f808                   cmp eax, 8
001c0908  0f879d010000             ja 0x1c0aab
001c090e  418b8c83900c1c00         mov ecx, dword ptr [r11 + rax*4 + 0x1c0c90]
001c0916  4903cb                   add rcx, r11
001c0919  ffe1                     jmp rcx
001c091b  c7432001000000           mov dword ptr [rbx + 0x20], 1
001c0922  488b5308                 mov rdx, qword ptr [rbx + 8]
001c0926  440fb74a26               movzx r9d, word ptr [rdx + 0x26]
001c092b  664585c9                 test r9w, r9w
001c092f  0f8473020000             je 0x1c0ba8
001c0935  488b03                   mov rax, qword ptr [rbx]
001c0938  0fb74b18                 movzx ecx, word ptr [rbx + 0x18]
001c093c  48c1e104                 shl rcx, 4
001c0940  48034810                 add rcx, qword ptr [rax + 0x10]
001c0944  6683780201               cmp word ptr [rax + 2], 1
001c0949  4c8b01                   mov r8, qword ptr [rcx]
001c094c  0f86ff010000             jbe 0x1c0b51
001c0952  488b4240                 mov rax, qword ptr [rdx + 0x40]
001c0956  4b8d0c89                 lea rcx, [r9 + r9*4]
001c095a  440fb74cc810             movzx r9d, word ptr [rax + rcx*8 + 0x10]
001c0960  e9f0010000               jmp 0x1c0b55
001c0965  488bcb                   mov rcx, rbx
001c0968  e883030000               call 0x1c0cf0
001c096d  8bd0                     mov edx, eax
001c096f  894320                   mov dword ptr [rbx + 0x20], eax
001c0972  e934010000               jmp 0x1c0aab
001c0977  c7432003000000           mov dword ptr [rbx + 0x20], 3
001c097e  488b03                   mov rax, qword ptr [rbx]
001c0981  0fb77b18                 movzx edi, word ptr [rbx + 0x18]
001c0985  48c1e704                 shl rdi, 4

; chunk at RVA 0x1c0989 (210 bytes)
001c0989  4c89642468               mov qword ptr [rsp + 0x68], r12
001c098e  48037810                 add rdi, qword ptr [rax + 0x10]
001c0992  4c8b6308                 mov r12, qword ptr [rbx + 8]
001c0996  6639770e                 cmp word ptr [rdi + 0xe], si
001c099a  0f844b020000             je 0x1c0beb
001c09a0  397708                   cmp dword ptr [rdi + 8], esi
001c09a3  0f8642020000             jbe 0x1c0beb
001c09a9  48896c2458               mov qword ptr [rsp + 0x58], rbp
001c09ae  448bde                   mov r11d, esi
001c09b1  498b6a20                 mov rbp, qword ptr [r10 + 0x20]
001c09b5  4c897c2420               mov qword ptr [rsp + 0x20], r15
001c09ba  4c8bfe                   mov r15, rsi
001c09bd  0f1f00                   nop dword ptr [rax]
001c09c0  418bc3                   mov eax, r11d
001c09c3  4c8d0c8500000000         lea r9, [rax*4]
001c09cb  0f1f440000               nop dword ptr [rax + rax]
001c09d0  458b8429f0f30f00         mov r8d, dword ptr [r9 + rbp + 0xff3f0]
001c09d8  418bc0                   mov eax, r8d
001c09db  f7d0                     not eax
001c09dd  8bc8                     mov ecx, eax
001c09df  f7d9                     neg ecx
001c09e1  23c8                     and ecx, eax
001c09e3  4585db                   test r11d, r11d
001c09e6  0fb7d1                   movzx edx, cx
001c09e9  0f45d1                   cmovne edx, ecx
001c09ec  85d2                     test edx, edx
001c09ee  0f84e4010000             je 0x1c0bd8
001c09f4  8bca                     mov ecx, edx
001c09f6  418bc0                   mov eax, r8d
001c09f9  410bc8                   or ecx, r8d
001c09fc  f0410fb18c29f0f30f00     lock cmpxchg dword ptr [r9 + rbp + 0xff3f0], ecx
001c0a06  75c8                     jne 0x1c09d0
001c0a08  0fbcc2                   bsf eax, edx
001c0a0b  41c1e305                 shl r11d, 5
001c0a0f  4103c3                   add eax, r11d
001c0a12  4c69f83fff0000           imul r15, rax, 0xff3f
001c0a19  4c03fd                   add r15, rbp
001c0a1c  4d893a                   mov qword ptr [r10], r15
001c0a1f  8b4708                   mov eax, dword ptr [rdi + 8]
001c0a22  41894208                 mov dword ptr [r10 + 8], eax
001c0a26  488b17                   mov rdx, qword ptr [rdi]
001c0a29  49895210                 mov qword ptr [r10 + 0x10], rdx
001c0a2d  664523742404             and r14w, word ptr [r12 + 4]
001c0a33  410fb7ce                 movzx ecx, r14w
001c0a37  6645897218               mov word ptr [r10 + 0x18], r14w
001c0a3c  ff1516471500             call qword ptr [rip + 0x154716]
001c0a42  66ff4318                 inc word ptr [rbx + 0x18]
001c0a46  4c8b7c2420               mov r15, qword ptr [rsp + 0x20]
001c0a4b  488b6c2458               mov rbp, qword ptr [rsp + 0x58]
001c0a50  4c8b642468               mov r12, qword ptr [rsp + 0x68]
001c0a55  e9bf000000               jmp 0x1c0b19
001c0a5a  cc                       int3

; chunk at RVA 0x1c0a5b (381 bytes)
001c0a5b  488b03                   mov rax, qword ptr [rbx]
001c0a5e  0fb75318                 movzx edx, word ptr [rbx + 0x18]
001c0a62  4803d2                   add rdx, rdx
001c0a65  488b4810                 mov rcx, qword ptr [rax + 0x10]
001c0a69  0fb744d1fc               movzx eax, word ptr [rcx + rdx*8 - 4]
001c0a6e  488d1480                 lea rdx, [rax + rax*4]
001c0a72  488b4308                 mov rax, qword ptr [rbx + 8]
001c0a76  488b4840                 mov rcx, qword ptr [rax + 0x40]
001c0a7a  448b04d1                 mov r8d, dword ptr [rcx + rdx*8]
001c0a7e  418bc8                   mov ecx, r8d
001c0a81  81e100fcff0f             and ecx, 0xffffc00
001c0a87  81f900500000             cmp ecx, 0x5000
001c0a8d  7533                     jne 0x1c0ac2
001c0a8f  4585c6                   test r14d, r8d
001c0a92  752e                     jne 0x1c0ac2
001c0a94  418bc0                   mov eax, r8d
001c0a97  25000000f0               and eax, 0xf0000000
001c0a9c  3d00000060               cmp eax, 0x60000000
001c0aa1  751f                     jne 0x1c0ac2
001c0aa3  ba05000000               mov edx, 5
001c0aa8  895320                   mov dword ptr [rbx + 0x20], edx
001c0aab  ffca                     dec edx
001c0aad  83fa06                   cmp edx, 6
001c0ab0  7767                     ja 0x1c0b19
001c0ab2  4863c2                   movsxd rax, edx
001c0ab5  418b8c83c00c1c00         mov ecx, dword ptr [r11 + rax*4 + 0x1c0cc0]
001c0abd  4903cb                   add rcx, r11
001c0ac0  ffe1                     jmp rcx
001c0ac2  418bc0                   mov eax, r8d
001c0ac5  41c1e81c                 shr r8d, 0x1c
001c0ac9  4123c6                   and eax, r14d
001c0acc  81f9004c0000             cmp ecx, 0x4c00
001c0ad2  750f                     jne 0x1c0ae3
001c0ad4  85c0                     test eax, eax
001c0ad6  750b                     jne 0x1c0ae3
001c0ad8  4183f806                 cmp r8d, 6
001c0adc  7505                     jne 0x1c0ae3
001c0ade  8d5004                   lea edx, [rax + 4]
001c0ae1  ebc5                     jmp 0x1c0aa8
001c0ae3  488bcb                   mov rcx, rbx
001c0ae6  e805020000               call 0x1c0cf0
001c0aeb  8bd0                     mov edx, eax
001c0aed  ebb9                     jmp 0x1c0aa8
001c0aef  c7432007000000           mov dword ptr [rbx + 0x20], 7
001c0af6  488b0b                   mov rcx, qword ptr [rbx]
001c0af9  440fb7431a               movzx r8d, word ptr [rbx + 0x1a]
001c0afe  49c1e004                 shl r8, 4
001c0b02  4c034118                 add r8, qword ptr [rcx + 0x18]
001c0b06  498b4808                 mov rcx, qword ptr [r8 + 8]
001c0b0a  418b5004                 mov edx, dword ptr [r8 + 4]
001c0b0e  49890a                   mov qword ptr [r10], rcx
001c0b11  41895208                 mov dword ptr [r10 + 8], edx
001c0b15  66ff431a                 inc word ptr [rbx + 0x1a]
001c0b19  837b2008                 cmp dword ptr [rbx + 0x20], 8
001c0b1d  400f95c6                 setne sil
001c0b21  8bc6                     mov eax, esi
001c0b23  4883c428                 add rsp, 0x28
001c0b27  415e                     pop r14
001c0b29  5f                       pop rdi
001c0b2a  5e                       pop rsi
001c0b2b  5b                       pop rbx
001c0b2c  c3                       ret
001c0b2d  0fb7431c                 movzx eax, word ptr [rbx + 0x1c]
001c0b31  ba08000000               mov edx, 8
001c0b36  6639431a                 cmp word ptr [rbx + 0x1a], ax
001c0b3a  b906000000               mov ecx, 6
001c0b3f  0f42d1                   cmovb edx, ecx
001c0b42  e961ffffff               jmp 0x1c0aa8
001c0b47  ba08000000               mov edx, 8
001c0b4c  895320                   mov dword ptr [rbx + 0x20], edx
001c0b4f  ebc8                     jmp 0x1c0b19
001c0b51  448b4908                 mov r9d, dword ptr [rcx + 8]
001c0b55  66837a2401               cmp word ptr [rdx + 0x24], 1
001c0b5a  7645                     jbe 0x1c0ba1
001c0b5c  488b4240                 mov rax, qword ptr [rdx + 0x40]
001c0b60  8b00                     mov eax, dword ptr [rax]
001c0b62  a900fcff0f               test eax, 0xffffc00
001c0b67  7538                     jne 0x1c0ba1
001c0b69  4185c6                   test r14d, eax
001c0b6c  7533                     jne 0x1c0ba1
001c0b6e  25000000f0               and eax, 0xf0000000
001c0b73  3d00000030               cmp eax, 0x30000000
001c0b78  7527                     jne 0x1c0ba1
001c0b7a  410fb600                 movzx eax, byte ptr [r8]
001c0b7e  884705                   mov byte ptr [rdi + 5], al
001c0b81  410fb64001               movzx eax, byte ptr [r8 + 1]
001c0b86  884704                   mov byte ptr [rdi + 4], al
001c0b89  498d4002                 lea rax, [r8 + 2]
001c0b8d  498902                   mov qword ptr [r10], rax
001c0b90  418d41fe                 lea eax, [r9 - 2]
001c0b94  41894208                 mov dword ptr [r10 + 8], eax
001c0b98  66ff4318                 inc word ptr [rbx + 0x18]
001c0b9c  e978ffffff               jmp 0x1c0b19
001c0ba1  4d8902                   mov qword ptr [r10], r8
001c0ba4  45894a08                 mov dword ptr [r10 + 8], r9d
001c0ba8  66ff4318                 inc word ptr [rbx + 0x18]
001c0bac  e968ffffff               jmp 0x1c0b19
001c0bb1  488b03                   mov rax, qword ptr [rbx]
001c0bb4  0fb75318                 movzx edx, word ptr [rbx + 0x18]
001c0bb8  48c1e204                 shl rdx, 4
001c0bbc  488b4010                 mov rax, qword ptr [rax + 0x10]
001c0bc0  4883c008                 add rax, 8
001c0bc4  41c7420804000000         mov dword ptr [r10 + 8], 4
001c0bcc  4803c2                   add rax, rdx
001c0bcf  498902                   mov qword ptr [r10], rax
001c0bd2  e942ffffff               jmp 0x1c0b19
001c0bd7  cc                       int3

; chunk at RVA 0x1c0bd8 (19 bytes)
001c0bd8  41ffc3                   inc r11d
001c0bdb  4183fb01                 cmp r11d, 1
001c0bdf  0f82dbfdffff             jb 0x1c09c0
001c0be5  e932feffff               jmp 0x1c0a1c
001c0bea  cc                       int3

; chunk at RVA 0x1c0beb (28 bytes)
001c0beb  488b07                   mov rax, qword ptr [rdi]
001c0bee  8b4f08                   mov ecx, dword ptr [rdi + 8]
001c0bf1  4c8b642468               mov r12, qword ptr [rsp + 0x68]
001c0bf6  498902                   mov qword ptr [r10], rax
001c0bf9  41894a08                 mov dword ptr [r10 + 8], ecx
001c0bfd  66ff4318                 inc word ptr [rbx + 0x18]
001c0c01  e913ffffff               jmp 0x1c0b19
001c0c06  cc                       int3

; chunk at RVA 0x1c0c07 (213 bytes)
001c0c07  488d05a48f0e00           lea rax, [rip + 0xe8fa4]
001c0c0e  41c7420801000000         mov dword ptr [r10 + 8], 1
001c0c16  498902                   mov qword ptr [r10], rax
001c0c19  e9fbfeffff               jmp 0x1c0b19
001c0c1e  488d058b8f0e00           lea rax, [rip + 0xe8f8b]
001c0c25  41c7420802000000         mov dword ptr [r10 + 8], 2
001c0c2d  498902                   mov qword ptr [r10], rax
001c0c30  e9e4feffff               jmp 0x1c0b19
001c0c35  488b03                   mov rax, qword ptr [rbx]
001c0c38  488d5324                 lea rdx, [rbx + 0x24]
001c0c3c  440fb7431a               movzx r8d, word ptr [rbx + 0x1a]
001c0c41  49c1e004                 shl r8, 4
001c0c45  4c034018                 add r8, qword ptr [rax + 0x18]
001c0c49  8b83a4010000             mov eax, dword ptr [rbx + 0x1a4]
001c0c4f  83e00f                   and eax, 0xf
001c0c52  488d0440                 lea rax, [rax + rax*2]
001c0c56  488d14c2                 lea rdx, [rdx + rax*8]
001c0c5a  418b00                   mov eax, dword ptr [r8]
001c0c5d  894210                   mov dword ptr [rdx + 0x10], eax
001c0c60  4923c6                   and rax, r14
001c0c63  486bc838                 imul rcx, rax, 0x38
001c0c67  488b4310                 mov rax, qword ptr [rbx + 0x10]
001c0c6b  0f10440110               movups xmm0, xmmword ptr [rcx + rax + 0x10]
001c0c70  0f1102                   movups xmmword ptr [rdx], xmm0
001c0c73  418b4004                 mov eax, dword ptr [r8 + 4]
001c0c77  894214                   mov dword ptr [rdx + 0x14], eax
001c0c7a  498912                   mov qword ptr [r10], rdx
001c0c7d  41c7420818000000         mov dword ptr [r10 + 8], 0x18
001c0c85  ff83a4010000             inc dword ptr [rbx + 0x1a4]
001c0c8b  e989feffff               jmp 0x1c0b19
001c0c90  1b09                     sbb ecx, dword ptr [rcx]
001c0c92  1c00                     sbb al, 0
001c0c94  65091c00                 or dword ptr gs:[rax + rax], ebx
001c0c98  7709                     ja 0x1c0ca3
001c0c9a  1c00                     sbb al, 0
001c0c9c  5b                       pop rbx
001c0c9d  0a1c00                   or bl, byte ptr [rax + rax]
001c0ca0  65091c00                 or dword ptr gs:[rax + rax], ebx
001c0ca4  65091c00                 or dword ptr gs:[rax + rax], ebx
001c0ca8  ef                       out dx, eax
001c0ca9  0a1c00                   or bl, byte ptr [rax + rax]
001c0cac  2d0b1c0047               sub eax, 0x47001c0b
001c0cb1  0b1c00                   or ebx, dword ptr [rax + rax]
001c0cb4  90                       nop
001c0cb5  90                       nop
001c0cb6  90                       nop
001c0cb7  90                       nop
001c0cb8  90                       nop
001c0cb9  90                       nop
001c0cba  90                       nop
001c0cbb  90                       nop
001c0cbc  90                       nop
001c0cbd  90                       nop
001c0cbe  90                       nop
001c0cbf  90                       nop
001c0cc0  2209                     and cl, byte ptr [rcx]
001c0cc2  1c00                     sbb al, 0
001c0cc4  b10b                     mov cl, 0xb
001c0cc6  1c00                     sbb al, 0
001c0cc8  7e09                     jle 0x1c0cd3
001c0cca  1c00                     sbb al, 0
