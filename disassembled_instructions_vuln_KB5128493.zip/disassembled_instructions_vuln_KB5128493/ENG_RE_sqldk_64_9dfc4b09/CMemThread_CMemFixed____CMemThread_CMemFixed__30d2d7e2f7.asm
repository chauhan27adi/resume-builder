; CMemThread<CMemFixed>::~CMemThread<CMemFixed>
; sqldk.dll, primary RVA 0xfc650, 111 bytes in 1 chunk(s)

; chunk at RVA 0xfc650 (111 bytes)
000fc650  48894c2408               mov qword ptr [rsp + 8], rcx
000fc655  53                       push rbx
000fc656  4883ec30                 sub rsp, 0x30
000fc65a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000fc663  488bd9                   mov rbx, rcx
000fc666  488d05dbd11400           lea rax, [rip + 0x14d1db]
000fc66d  488901                   mov qword ptr [rcx], rax
000fc670  488d8108010000           lea rax, [rcx + 0x108]
000fc677  4889442448               mov qword ptr [rsp + 0x48], rax
000fc67c  488d0dbdd41300           lea rcx, [rip + 0x13d4bd]
000fc683  48894830                 mov qword ptr [rax + 0x30], rcx
000fc687  488908                   mov qword ptr [rax], rcx
000fc68a  488d0527aa1400           lea rax, [rip + 0x14aa27]
000fc691  488903                   mov qword ptr [rbx], rax
000fc694  488d056dab1400           lea rax, [rip + 0x14ab6d]
000fc69b  488903                   mov qword ptr [rbx], rax
000fc69e  488d4b38                 lea rcx, [rbx + 0x38]
000fc6a2  e8495bf1ff               call 0x121f0
000fc6a7  90                       nop
000fc6a8  488d4b30                 lea rcx, [rbx + 0x30]
000fc6ac  e83f5bf1ff               call 0x121f0
000fc6b1  90                       nop
000fc6b2  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
000fc6b9  4883c430                 add rsp, 0x30
000fc6bd  5b                       pop rbx
000fc6be  c3                       ret
