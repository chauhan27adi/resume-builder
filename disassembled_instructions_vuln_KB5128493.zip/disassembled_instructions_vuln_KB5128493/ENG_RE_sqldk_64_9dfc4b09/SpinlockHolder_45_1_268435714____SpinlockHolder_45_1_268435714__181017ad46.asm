; SpinlockHolder<45,1,268435714>::~SpinlockHolder<45,1,268435714>
; sqldk.dll, primary RVA 0x1f71e0, 97 bytes in 1 chunk(s)

; chunk at RVA 0x1f71e0 (97 bytes)
001f71e0  48895c2408               mov qword ptr [rsp + 8], rbx
001f71e5  57                       push rdi
001f71e6  4883ec20                 sub rsp, 0x20
001f71ea  488b39                   mov rdi, qword ptr [rcx]
001f71ed  488bd9                   mov rbx, rcx
001f71f0  4885ff                   test rdi, rdi
001f71f3  7441                     je 0x1f7236
001f71f5  83790800                 cmp dword ptr [rcx + 8], 0
001f71f9  743b                     je 0x1f7236
001f71fb  803dbfe2110000           cmp byte ptr [rip + 0x11e2bf], 0
001f7202  7427                     je 0x1f722b
001f7204  ff153e280400             call qword ptr [rip + 0x4283e]
001f720a  448bc0                   mov r8d, eax
001f720d  b867666666               mov eax, 0x66666667
001f7212  41f7e8                   imul r8d
001f7215  d1fa                     sar edx, 1
001f7217  8bca                     mov ecx, edx
001f7219  c1e91f                   shr ecx, 0x1f
001f721c  03d1                     add edx, ecx
001f721e  8d0c92                   lea ecx, [rdx + rdx*4]
001f7221  443bc1                   cmp r8d, ecx
001f7224  7505                     jne 0x1f722b
001f7226  e825000000               call 0x1f7250
001f722b  33c0                     xor eax, eax
001f722d  488907                   mov qword ptr [rdi], rax
001f7230  488903                   mov qword ptr [rbx], rax
001f7233  894308                   mov dword ptr [rbx + 8], eax
001f7236  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001f723b  4883c420                 add rsp, 0x20
001f723f  5f                       pop rdi
001f7240  c3                       ret
