; `XE_FileWriter<XE_FileWriterDefaultPolicy<1,&XEPackage0::DefaultFileExtension>,XE_MetadataTracker>::Initialize'::`1'::dtor$0
; sqldk.dll, primary RVA 0x230360, 34 bytes in 1 chunk(s)

; chunk at RVA 0x230360 (34 bytes)
00230360  4055                     push rbp
00230362  4883ec20                 sub rsp, 0x20
00230366  488bea                   mov rbp, rdx
00230369  4533c0                   xor r8d, r8d
0023036c  488b9528010000           mov rdx, qword ptr [rbp + 0x128]
00230373  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00230377  e8940cddff               call 0x1010
0023037c  4883c420                 add rsp, 0x20
00230380  5d                       pop rbp
00230381  c3                       ret
