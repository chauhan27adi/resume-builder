; `XE_NamedPipeChannel::Create'::`1'::dtor$1
; sqldk.dll, primary RVA 0x236998, 37 bytes in 1 chunk(s)

; chunk at RVA 0x236998 (37 bytes)
00236998  4055                     push rbp
0023699a  4883ec20                 sub rsp, 0x20
0023699e  488bea                   mov rbp, rdx
002369a1  4533c0                   xor r8d, r8d
002369a4  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
002369ab  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
002369b2  e859a6dcff               call 0x1010
002369b7  4883c420                 add rsp, 0x20
002369bb  5d                       pop rbp
002369bc  c3                       ret
