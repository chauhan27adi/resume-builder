; CAutoRg<XMLActionTransformRule>::~CAutoRg<XMLActionTransformRule>
; sqldk.dll, primary RVA 0x4dec0, 79 bytes in 3 chunk(s)

; chunk at RVA 0x4dec0 (23 bytes)
0004dec0  4883ec28                 sub rsp, 0x28
0004dec4  488b09                   mov rcx, qword ptr [rcx]
0004dec7  4885c9                   test rcx, rcx
0004deca  743f                     je 0x4df0b
0004decc  4c8b41f8                 mov r8, qword ptr [rcx - 8]
0004ded0  4c8d0dc9020000           lea r9, [rip + 0x2c9]

; chunk at RVA 0x4ded7 (51 bytes)
0004ded7  48895c2420               mov qword ptr [rsp + 0x20], rbx
0004dedc  ba18000000               mov edx, 0x18
0004dee1  488d59f8                 lea rbx, [rcx - 8]
0004dee5  e8760dfeff               call 0x2ec60
0004deea  488b03                   mov rax, qword ptr [rbx]
0004deed  488bcb                   mov rcx, rbx
0004def0  488d1440                 lea rdx, [rax + rax*2]
0004def4  488d14d508000000         lea rdx, [rdx*8 + 8]
0004defc  488b5c2420               mov rbx, qword ptr [rsp + 0x20]
0004df01  4883c428                 add rsp, 0x28
0004df05  e9e69efbff               jmp 0x7df0

; chunk at RVA 0x4df0b (5 bytes)
0004df0b  4883c428                 add rsp, 0x28
0004df0f  c3                       ret
