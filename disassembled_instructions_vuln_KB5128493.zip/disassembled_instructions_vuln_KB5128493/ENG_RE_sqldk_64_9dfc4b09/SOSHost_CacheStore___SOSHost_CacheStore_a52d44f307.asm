; SOSHost_CacheStore::~SOSHost_CacheStore
; sqldk.dll, primary RVA 0x180fc0, 48 bytes in 1 chunk(s)

; chunk at RVA 0x180fc0 (48 bytes)
00180fc0  48894c2408               mov qword ptr [rsp + 8], rcx
00180fc5  4883ec38                 sub rsp, 0x38
00180fc9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00180fd2  488d054feb0c00           lea rax, [rip + 0xceb4f]
00180fd9  488901                   mov qword ptr [rcx], rax
00180fdc  488d05f53b0e00           lea rax, [rip + 0xe3bf5]
00180fe3  48894140                 mov qword ptr [rcx + 0x40], rax
00180fe7  4883c438                 add rsp, 0x38
00180feb  e940120000               jmp 0x182230
