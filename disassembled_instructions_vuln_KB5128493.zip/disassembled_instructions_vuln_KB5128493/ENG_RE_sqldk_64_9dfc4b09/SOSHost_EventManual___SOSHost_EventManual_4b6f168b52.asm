; SOSHost_EventManual::~SOSHost_EventManual
; sqldk.dll, primary RVA 0xadc60, 67 bytes in 1 chunk(s)

; chunk at RVA 0xadc60 (67 bytes)
000adc60  48894c2408               mov qword ptr [rsp + 8], rcx
000adc65  53                       push rbx
000adc66  4883ec30                 sub rsp, 0x30
000adc6a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000adc73  488bd9                   mov rbx, rcx
000adc76  488d0553981900           lea rax, [rip + 0x199853]
000adc7d  488901                   mov qword ptr [rcx], rax
000adc80  488b8918010000           mov rcx, qword ptr [rcx + 0x118]
000adc87  4885c9                   test rcx, rcx
000adc8a  7407                     je 0xadc93
000adc8c  488b01                   mov rax, qword ptr [rcx]
000adc8f  ff5008                   call qword ptr [rax + 8]
000adc92  90                       nop
000adc93  488d0586981900           lea rax, [rip + 0x199886]
000adc9a  488903                   mov qword ptr [rbx], rax
000adc9d  4883c430                 add rsp, 0x30
000adca1  5b                       pop rbx
000adca2  c3                       ret
