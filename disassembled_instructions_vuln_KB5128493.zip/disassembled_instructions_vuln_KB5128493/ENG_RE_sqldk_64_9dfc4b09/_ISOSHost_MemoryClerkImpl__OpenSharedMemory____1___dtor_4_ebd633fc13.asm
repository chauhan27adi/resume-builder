; `ISOSHost_MemoryClerkImpl::OpenSharedMemory'::`1'::dtor$4
; sqldk.dll, primary RVA 0x22900c, 56 bytes in 1 chunk(s)

; chunk at RVA 0x22900c (56 bytes)
0022900c  4055                     push rbp
0022900e  4883ec30                 sub rsp, 0x30
00229012  488bea                   mov rbp, rdx
00229015  c644242806               mov byte ptr [rsp + 0x28], 6
0022901a  8b8580000000             mov eax, dword ptr [rbp + 0x80]
00229020  89442420                 mov dword ptr [rsp + 0x20], eax
00229024  4c8d0db50b0700           lea r9, [rip + 0x70bb5]
0022902b  41b801000000             mov r8d, 1
00229031  488b5538                 mov rdx, qword ptr [rbp + 0x38]
00229035  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00229039  e862edddff               call 0x7da0
0022903e  4883c430                 add rsp, 0x30
00229042  5d                       pop rbp
00229043  c3                       ret
