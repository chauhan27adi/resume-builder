; AutoSwitchPreemptive::~AutoSwitchPreemptive
; sqldk.dll, primary RVA 0xbee20, 83 bytes in 1 chunk(s)

; chunk at RVA 0xbee20 (83 bytes)
000bee20  48894c2408               mov qword ptr [rsp + 8], rcx
000bee25  53                       push rbx
000bee26  4883ec30                 sub rsp, 0x30
000bee2a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000bee33  488bd9                   mov rbx, rcx
000bee36  833900                   cmp dword ptr [rcx], 0
000bee39  742a                     je 0xbee65
000bee3b  488b5108                 mov rdx, qword ptr [rcx + 8]
000bee3f  488b8a60020000           mov rcx, qword ptr [rdx + 0x260]
000bee46  837b0400                 cmp dword ptr [rbx + 4], 0
000bee4a  740c                     je 0xbee58
000bee4c  818a2003000000080000     or dword ptr [rdx + 0x320], 0x800
000bee56  eb0d                     jmp 0xbee65
000bee58  488b01                   mov rax, qword ptr [rcx]
000bee5b  41b801000000             mov r8d, 1
000bee61  ff5010                   call qword ptr [rax + 0x10]
000bee64  90                       nop
000bee65  488d4b10                 lea rcx, [rbx + 0x10]
000bee69  4883c430                 add rsp, 0x30
000bee6d  5b                       pop rbx
000bee6e  e95d56f5ff               jmp 0x144d0
