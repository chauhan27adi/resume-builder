; `TSimpleHashTable<TCacheStore<CacheClockAlgorithm>::CacheEntryProxy,CacheStoreSLock,0,unsigned int>::Init'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22d500, 53 bytes in 1 chunk(s)

; chunk at RVA 0x22d500 (53 bytes)
0022d500  4055                     push rbp
0022d502  4883ec30                 sub rsp, 0x30
0022d506  488bea                   mov rbp, rdx
0022d509  c644242806               mov byte ptr [rsp + 0x28], 6
0022d50e  8b4568                   mov eax, dword ptr [rbp + 0x68]
0022d511  89442420                 mov dword ptr [rsp + 0x20], eax
0022d515  4c8d0db4cf0400           lea r9, [rip + 0x4cfb4]
0022d51c  41b801000000             mov r8d, 1
0022d522  488b5570                 mov rdx, qword ptr [rbp + 0x70]
0022d526  488b4d60                 mov rcx, qword ptr [rbp + 0x60]
0022d52a  e871a8ddff               call 0x7da0
0022d52f  4883c430                 add rsp, 0x30
0022d533  5d                       pop rbp
0022d534  c3                       ret
