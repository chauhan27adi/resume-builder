; `StackFramesStore::InsertStack'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22db40, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22db40 (59 bytes)
0022db40  4055                     push rbp
0022db42  4883ec30                 sub rsp, 0x30
0022db46  488bea                   mov rbp, rdx
0022db49  c644242806               mov byte ptr [rsp + 0x28], 6
0022db4e  8b8590000000             mov eax, dword ptr [rbp + 0x90]
0022db54  89442420                 mov dword ptr [rsp + 0x20], eax
0022db58  4c8d0df1cc0600           lea r9, [rip + 0x6ccf1]
0022db5f  41b801000000             mov r8d, 1
0022db65  488b95a8000000           mov rdx, qword ptr [rbp + 0xa8]
0022db6c  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
0022db70  e82ba2ddff               call 0x7da0
0022db75  4883c430                 add rsp, 0x30
0022db79  5d                       pop rbp
0022db7a  c3                       ret
