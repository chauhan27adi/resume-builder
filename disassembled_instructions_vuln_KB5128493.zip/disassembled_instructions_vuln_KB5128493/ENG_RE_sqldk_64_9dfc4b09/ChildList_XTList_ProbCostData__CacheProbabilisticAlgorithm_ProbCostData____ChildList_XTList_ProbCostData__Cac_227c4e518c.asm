; ChildList<XTList<ProbCostData>,CacheProbabilisticAlgorithm,ProbCostData>::~ChildList<XTList<ProbCostData>,CacheProbabilisticAlgorithm,ProbCostData>
; sqldk.dll, primary RVA 0x180b40, 28 bytes in 1 chunk(s)

; chunk at RVA 0x180b40 (28 bytes)
00180b40  48894c2408               mov qword ptr [rsp + 8], rcx
00180b45  4883ec18                 sub rsp, 0x18
00180b49  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
00180b51  c701adde0080             mov dword ptr [rcx], 0x8000dead
00180b57  4883c418                 add rsp, 0x18
00180b5b  c3                       ret
