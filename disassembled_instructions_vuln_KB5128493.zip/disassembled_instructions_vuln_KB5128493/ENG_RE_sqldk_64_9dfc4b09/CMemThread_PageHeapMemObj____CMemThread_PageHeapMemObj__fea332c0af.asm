; CMemThread<PageHeapMemObj>::~CMemThread<PageHeapMemObj>
; sqldk.dll, primary RVA 0xe5b20, 111 bytes in 1 chunk(s)

; chunk at RVA 0xe5b20 (111 bytes)
000e5b20  48894c2408               mov qword ptr [rsp + 8], rcx
000e5b25  53                       push rbx
000e5b26  4883ec30                 sub rsp, 0x30
000e5b2a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000e5b33  488bd9                   mov rbx, rcx
000e5b36  488d0523491600           lea rax, [rip + 0x164923]
000e5b3d  488901                   mov qword ptr [rcx], rax
000e5b40  488d8180000000           lea rax, [rcx + 0x80]
000e5b47  4889442448               mov qword ptr [rsp + 0x48], rax
000e5b4c  488d0ded3f1500           lea rcx, [rip + 0x153fed]
000e5b53  48894830                 mov qword ptr [rax + 0x30], rcx
000e5b57  488908                   mov qword ptr [rax], rcx
000e5b5a  488d05bf8a1600           lea rax, [rip + 0x168abf]
000e5b61  488903                   mov qword ptr [rbx], rax
000e5b64  488d059d161600           lea rax, [rip + 0x16169d]
000e5b6b  488903                   mov qword ptr [rbx], rax
000e5b6e  488d4b38                 lea rcx, [rbx + 0x38]
000e5b72  e879c6f2ff               call 0x121f0
000e5b77  90                       nop
000e5b78  488d4b30                 lea rcx, [rbx + 0x30]
000e5b7c  e86fc6f2ff               call 0x121f0
000e5b81  90                       nop
000e5b82  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
000e5b89  4883c430                 add rsp, 0x30
000e5b8d  5b                       pop rbx
000e5b8e  c3                       ret
