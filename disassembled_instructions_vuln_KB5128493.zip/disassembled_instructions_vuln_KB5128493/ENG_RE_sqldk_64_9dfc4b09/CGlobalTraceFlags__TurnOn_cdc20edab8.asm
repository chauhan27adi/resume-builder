; CGlobalTraceFlags::TurnOn
; sqldk.dll, primary RVA 0x1b40b0, 589 bytes in 3 chunk(s)

; chunk at RVA 0x1b40b0 (188 bytes)
001b40b0  4053                     push rbx
001b40b2  55                       push rbp
001b40b3  57                       push rdi
001b40b4  4883ec30                 sub rsp, 0x30
001b40b8  0fb7e9                   movzx ebp, cx
001b40bb  8bda                     mov ebx, edx
001b40bd  b9aa3f0000               mov ecx, 0x3faa
001b40c2  8d45ff                   lea eax, [rbp - 1]
001b40c5  663bc1                   cmp ax, cx
001b40c8  773f                     ja 0x1b4109
001b40ca  0faee8                   lfence
001b40cd  8d42ff                   lea eax, [rdx - 1]
001b40d0  83f801                   cmp eax, 1
001b40d3  0f8789000000             ja 0x1b4162
001b40d9  0fb7cd                   movzx ecx, bp
001b40dc  e85f100000               call 0x1b5140
001b40e1  488bf8                   mov rdi, rax
001b40e4  4885c0                   test rax, rax
001b40e7  743f                     je 0x1b4128
001b40e9  488b0d08df1700           mov rcx, qword ptr [rip + 0x17df08]
001b40f0  488b11                   mov rdx, qword ptr [rcx]
001b40f3  ff12                     call qword ptr [rdx]
001b40f5  f680c301000004           test byte ptr [rax + 0x1c3], 4
001b40fc  752a                     jne 0x1b4128
001b40fe  83fb01                   cmp ebx, 1
001b4101  7510                     jne 0x1b4113
001b4103  837f0800                 cmp dword ptr [rdi + 8], 0
001b4107  7559                     jne 0x1b4162
001b4109  32c0                     xor al, al
001b410b  4883c430                 add rsp, 0x30
001b410f  5f                       pop rdi
001b4110  5d                       pop rbp
001b4111  5b                       pop rbx
001b4112  c3                       ret
001b4113  83fb02                   cmp ebx, 2
001b4116  754a                     jne 0x1b4162
001b4118  837f0c00                 cmp dword ptr [rdi + 0xc], 0
001b411c  750f                     jne 0x1b412d
001b411e  32c0                     xor al, al
001b4120  4883c430                 add rsp, 0x30
001b4124  5f                       pop rdi
001b4125  5d                       pop rbp
001b4126  5b                       pop rbx
001b4127  c3                       ret
001b4128  83fb02                   cmp ebx, 2
001b412b  7535                     jne 0x1b4162
001b412d  8bcd                     mov ecx, ebp
001b412f  e8bcf7fcff               call 0x1838f0
001b4134  488b0dbdde1700           mov rcx, qword ptr [rip + 0x17debd]
001b413b  4533c9                   xor r9d, r9d
001b413e  4533c0                   xor r8d, r8d
001b4141  8bd5                     mov edx, ebp
001b4143  488b01                   mov rax, qword ptr [rcx]
001b4146  ff5010                   call qword ptr [rax + 0x10]
001b4149  488b1d30792000           mov rbx, qword ptr [rip + 0x207930]
001b4150  4885db                   test rbx, rbx
001b4153  740d                     je 0x1b4162
001b4155  8bcd                     mov ecx, ebp
001b4157  ff5308                   call qword ptr [rbx + 8]
001b415a  488b1b                   mov rbx, qword ptr [rbx]
001b415d  4885db                   test rbx, rbx
001b4160  75f3                     jne 0x1b4155
001b4162  658b042548000000         mov eax, dword ptr gs:[0x48]
001b416a  33db                     xor ebx, ebx

; chunk at RVA 0x1b416c (288 bytes)
001b416c  4889742450               mov qword ptr [rsp + 0x50], rsi
001b4171  8bf0                     mov esi, eax
001b4173  8b056f6e2000             mov eax, dword ptr [rip + 0x206e6f]
001b4179  85c0                     test eax, eax
001b417b  7518                     jne 0x1b4195
001b417d  33c0                     xor eax, eax
001b417f  f0480fb135606e2000       lock cmpxchg qword ptr [rip + 0x206e60], rsi
001b4188  8bc3                     mov eax, ebx
001b418a  0f94c0                   sete al
001b418d  85c0                     test eax, eax
001b418f  0f85c6000000             jne 0x1b425b
001b4195  8b055d091600             mov eax, dword ptr [rip + 0x16095d]
001b419b  33ff                     xor edi, edi
001b419d  2584000000               and eax, 0x84
001b41a2  3c84                     cmp al, 0x84
001b41a4  7552                     jne 0x1b41f8
001b41a6  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
001b41af  8b051b0e1600             mov eax, dword ptr [rip + 0x160e1b]
001b41b5  8b15fdd6e4ff             mov edx, dword ptr [rip - 0x1b2903]
001b41bb  480314c1                 add rdx, qword ptr [rcx + rax*8]
001b41bf  7410                     je 0x1b41d1
001b41c1  48399210010000           cmp qword ptr [rdx + 0x110], rdx
001b41c8  7507                     jne 0x1b41d1
001b41ca  488bba00010000           mov rdi, qword ptr [rdx + 0x100]
001b41d1  4885ff                   test rdi, rdi
001b41d4  7422                     je 0x1b41f8
001b41d6  391de8121600             cmp dword ptr [rip + 0x1612e8], ebx
001b41dc  7412                     je 0x1b41f0
001b41de  488d4c2460               lea rcx, [rsp + 0x60]
001b41e3  ff15e7520800             call qword ptr [rip + 0x852e7]
001b41e9  488b5c2460               mov rbx, qword ptr [rsp + 0x60]
001b41ee  eb08                     jmp 0x1b41f8
001b41f0  488b1c250800fe7f         mov rbx, qword ptr [0x7ffe0008]
001b41f8  f605d808160080           test byte ptr [rip + 0x1608d8], 0x80
001b41ff  488d0de26d2000           lea rcx, [rip + 0x206de2]
001b4206  740d                     je 0x1b4215
001b4208  4c8bc6                   mov r8, rsi
001b420b  488bd7                   mov rdx, rdi
001b420e  e8dd090000               call 0x1b4bf0
001b4213  eb08                     jmp 0x1b421d
001b4215  488bd6                   mov rdx, rsi
001b4218  e8d30b0000               call 0x1b4df0
001b421d  4885ff                   test rdi, rdi
001b4220  7439                     je 0x1b425b
001b4222  833d9b12160000           cmp dword ptr [rip + 0x16129b], 0
001b4229  7412                     je 0x1b423d
001b422b  488d4c2468               lea rcx, [rsp + 0x68]
001b4230  ff159a520800             call qword ptr [rip + 0x8529a]
001b4236  488b4c2468               mov rcx, qword ptr [rsp + 0x68]
001b423b  eb08                     jmp 0x1b4245
001b423d  488b0c250800fe7f         mov rcx, qword ptr [0x7ffe0008]
001b4245  33c0                     xor eax, eax
001b4247  488bd1                   mov rdx, rcx
001b424a  482bd3                   sub rdx, rbx
001b424d  483bcb                   cmp rcx, rbx
001b4250  480f43c2                 cmovae rax, rdx
001b4254  480187780c0000           add qword ptr [rdi + 0xc78], rax
001b425b  488b0d96dd1700           mov rcx, qword ptr [rip + 0x17dd96]
001b4262  488b01                   mov rax, qword ptr [rcx]
001b4265  ff10                     call qword ptr [rax]
001b4267  488b742450               mov rsi, qword ptr [rsp + 0x50]
001b426c  488bcd                   mov rcx, rbp
001b426f  48c1e903                 shr rcx, 3
001b4273  4803c1                   add rax, rcx
001b4276  8bcd                     mov ecx, ebp
001b4278  83e107                   and ecx, 7
001b427b  0fb610                   movzx edx, byte ptr [rax]
001b427e  0fabca                   bts edx, ecx
001b4281  8810                     mov byte ptr [rax], dl
001b4283  803d3712160000           cmp byte ptr [rip + 0x161237], 0
001b428a  7427                     je 0x1b42b3

; chunk at RVA 0x1b428c (113 bytes)
001b428c  ff15b6570800             call qword ptr [rip + 0x857b6]
001b4292  448bc0                   mov r8d, eax
001b4295  b867666666               mov eax, 0x66666667
001b429a  41f7e8                   imul r8d
001b429d  d1fa                     sar edx, 1
001b429f  8bca                     mov ecx, edx
001b42a1  c1e91f                   shr ecx, 0x1f
001b42a4  03d1                     add edx, ecx
001b42a6  8d0c92                   lea ecx, [rdx + rdx*4]
001b42a9  443bc1                   cmp r8d, ecx
001b42ac  7505                     jne 0x1b42b3
001b42ae  e86d0d0000               call 0x1b5020
001b42b3  8bcd                     mov ecx, ebp
001b42b5  48c705286d200000000000   mov qword ptr [rip + 0x206d28], 0
001b42c0  e82bf6fcff               call 0x1838f0
001b42c5  488b0d2cdd1700           mov rcx, qword ptr [rip + 0x17dd2c]
001b42cc  4533c9                   xor r9d, r9d
001b42cf  4533c0                   xor r8d, r8d
001b42d2  8bd5                     mov edx, ebp
001b42d4  488b01                   mov rax, qword ptr [rcx]
001b42d7  ff5010                   call qword ptr [rax + 0x10]
001b42da  488b1d9f772000           mov rbx, qword ptr [rip + 0x20779f]
001b42e1  4885db                   test rbx, rbx
001b42e4  740d                     je 0x1b42f3
001b42e6  8bcd                     mov ecx, ebp
001b42e8  ff5308                   call qword ptr [rbx + 8]
001b42eb  488b1b                   mov rbx, qword ptr [rbx]
001b42ee  4885db                   test rbx, rbx
001b42f1  75f3                     jne 0x1b42e6
001b42f3  b001                     mov al, 1
001b42f5  4883c430                 add rsp, 0x30
001b42f9  5f                       pop rdi
001b42fa  5d                       pop rbp
001b42fb  5b                       pop rbx
001b42fc  c3                       ret
