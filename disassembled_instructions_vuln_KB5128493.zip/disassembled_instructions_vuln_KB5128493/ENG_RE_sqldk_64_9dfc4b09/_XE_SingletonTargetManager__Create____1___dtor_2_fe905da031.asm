; `XE_SingletonTargetManager::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x235e44, 56 bytes in 1 chunk(s)

; chunk at RVA 0x235e44 (56 bytes)
00235e44  4055                     push rbp
00235e46  4883ec30                 sub rsp, 0x30
00235e4a  488bea                   mov rbp, rdx
00235e4d  c644242806               mov byte ptr [rsp + 0x28], 6
00235e52  8b4578                   mov eax, dword ptr [rbp + 0x78]
00235e55  89442420                 mov dword ptr [rsp + 0x20], eax
00235e59  4c8d0d304b0700           lea r9, [rip + 0x74b30]
00235e60  41b801000000             mov r8d, 1
00235e66  488b5570                 mov rdx, qword ptr [rbp + 0x70]
00235e6a  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
00235e71  e84a40faff               call 0x1d9ec0
00235e76  4883c430                 add rsp, 0x30
00235e7a  5d                       pop rbp
00235e7b  c3                       ret
