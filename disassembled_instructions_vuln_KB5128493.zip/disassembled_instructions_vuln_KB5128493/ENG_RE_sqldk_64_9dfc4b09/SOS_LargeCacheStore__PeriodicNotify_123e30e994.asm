; SOS_LargeCacheStore::PeriodicNotify
; sqldk.dll, primary RVA 0x16c80, 485 bytes in 5 chunk(s)

; chunk at RVA 0x16c80 (31 bytes)
00016c80  488bc4                   mov rax, rsp
00016c83  57                       push rdi
00016c84  4156                     push r14
00016c86  4157                     push r15
00016c88  4883ec50                 sub rsp, 0x50
00016c8c  f6416801                 test byte ptr [rcx + 0x68], 1
00016c90  4d8bf9                   mov r15, r9
00016c93  4d8bf0                   mov r14, r8
00016c96  488bf9                   mov rdi, rcx
00016c99  0f85ea000000             jne 0x16d89

; chunk at RVA 0x16c9f (46 bytes)
00016c9f  48895808                 mov qword ptr [rax + 8], rbx
00016ca3  488d99289afeff           lea rbx, [rcx - 0x165d8]
00016caa  48896810                 mov qword ptr [rax + 0x10], rbp
00016cae  48897018                 mov qword ptr [rax + 0x18], rsi
00016cb2  85d2                     test edx, edx
00016cb4  0f841f040000             je 0x170d9
00016cba  83fa01                   cmp edx, 1
00016cbd  0f85b4000000             jne 0x16d77
00016cc3  488b942490000000         mov rdx, qword ptr [rsp + 0x90]
00016ccb  33ed                     xor ebp, ebp

; chunk at RVA 0x16ccd (170 bytes)
00016ccd  0f2970d8                 movaps xmmword ptr [rax - 0x28], xmm6
00016cd1  488b02                   mov rax, qword ptr [rdx]
00016cd4  48894330                 mov qword ptr [rbx + 0x30], rax
00016cd8  488b4208                 mov rax, qword ptr [rdx + 8]
00016cdc  48894338                 mov qword ptr [rbx + 0x38], rax
00016ce0  488b4210                 mov rax, qword ptr [rdx + 0x10]
00016ce4  48894340                 mov qword ptr [rbx + 0x40], rax
00016ce8  896b48                   mov dword ptr [rbx + 0x48], ebp
00016ceb  498b01                   mov rax, qword ptr [r9]
00016cee  f20f105130               movsd xmm2, qword ptr [rcx + 0x30]
00016cf3  48894138                 mov qword ptr [rcx + 0x38], rax
00016cf7  488bcb                   mov rcx, rbx
00016cfa  f2410f1009               movsd xmm1, qword ptr [r9]
00016cff  e89c000000               call 0x16da0
00016d04  488d979893feff           lea rdx, [rdi - 0x16c68]
00016d0b  48894740                 mov qword ptr [rdi + 0x40], rax
00016d0f  488d8aa0070000           lea rcx, [rdx + 0x7a0]
00016d16  4885c9                   test rcx, rcx
00016d19  7408                     je 0x16d23
00016d1b  4533c0                   xor r8d, r8d
00016d1e  e84d32ffff               call 0x9f70
00016d23  488b07                   mov rax, qword ptr [rdi]
00016d26  488bcf                   mov rcx, rdi
00016d29  ff5018                   call qword ptr [rax + 0x18]
00016d2c  488bc8                   mov rcx, rax
00016d2f  0f57f6                   xorps xmm6, xmm6
00016d32  4885c0                   test rax, rax
00016d35  0f88cd0b1600             js 0x177908
00016d3b  f2480f2af0               cvtsi2sd xmm6, rax
00016d40  eb01                     jmp 0x16d43
00016d42  cc                       int3
00016d43  f20f5935fdd32400         mulsd xmm6, qword ptr [rip + 0x24d3fd]
00016d4b  0f57c0                   xorps xmm0, xmm0
00016d4e  f2480f2a87284cffff       cvtsi2sd xmm0, qword ptr [rdi - 0xb3d8]
00016d57  660f2fc6                 comisd xmm0, xmm6
00016d5b  0f87bf0b1600             ja 0x177920
00016d61  488b87284cffff           mov rax, qword ptr [rdi - 0xb3d8]
00016d68  0f28742440               movaps xmm6, xmmword ptr [rsp + 0x40]
00016d6d  488987f8fdffff           mov qword ptr [rdi - 0x208], rax
00016d74  eb01                     jmp 0x16d77
00016d76  cc                       int3

; chunk at RVA 0x16d89 (10 bytes)
00016d89  4883c450                 add rsp, 0x50
00016d8d  415f                     pop r15
00016d8f  415e                     pop r14
00016d91  5f                       pop rdi
00016d92  c3                       ret

; chunk at RVA 0x170d9 (228 bytes)
000170d9  be01000000               mov esi, 1
000170de  498bd6                   mov rdx, r14
000170e1  448bc6                   mov r8d, esi
000170e4  488bcb                   mov rcx, rbx
000170e7  e8e4000000               call 0x171d0
000170ec  4881c388b10000           add rbx, 0xb188
000170f3  8bd6                     mov edx, esi
000170f5  488bcb                   mov rcx, rbx
000170f8  e8c3f1ffff               call 0x162c0
000170fd  33ed                     xor ebp, ebp
000170ff  85c0                     test eax, eax
00017101  7533                     jne 0x17136
00017103  498b4e08                 mov rcx, qword ptr [r14 + 8]
00017107  488b4318                 mov rax, qword ptr [rbx + 0x18]
0001710b  493bce                   cmp rcx, r14
0001710e  f20f102542d02400         movsd xmm4, qword ptr [rip + 0x24d042]
00017116  480f44cd                 cmove rcx, rbp
0001711a  488908                   mov qword ptr [rax], rcx
0001711d  896b04                   mov dword ptr [rbx + 4], ebp
00017120  488b5318                 mov rdx, qword ptr [rbx + 0x18]
00017124  48392a                   cmp qword ptr [rdx], rbp
00017127  0f8594081600             jne 0x1779c1
0001712d  397304                   cmp dword ptr [rbx + 4], esi
00017130  0f8744091600             ja 0x177a7a
00017136  488b87089afeff           mov rax, qword ptr [rdi - 0x165f8]
0001713d  0f57c9                   xorps xmm1, xmm1
00017140  488bcb                   mov rcx, rbx
00017143  8b4028                   mov eax, dword ptr [rax + 0x28]
00017146  c1e002                   shl eax, 2
00017149  f2480f2ac8               cvtsi2sd xmm1, rax
0001714e  e8fdf4ffff               call 0x16650
00017153  0f57c9                   xorps xmm1, xmm1
00017156  f20f114730               movsd qword ptr [rdi + 0x30], xmm0
0001715b  660f2fc1                 comisd xmm0, xmm1
0001715f  7745                     ja 0x171a6
00017161  488b87284cffff           mov rax, qword ptr [rdi - 0xb3d8]
00017168  0f57d2                   xorps xmm2, xmm2
0001716b  480387f8fdffff           add rax, qword ptr [rdi - 0x208]
00017172  4899                     cqo
00017174  482bc2                   sub rax, rdx
00017177  488b97f0fdffff           mov rdx, qword ptr [rdi - 0x210]
0001717e  48d1f8                   sar rax, 1
00017181  488bc8                   mov rcx, rax
00017184  4885d2                   test rdx, rdx
00017187  0f881c091600             js 0x177aa9
0001718d  f2480f2ad2               cvtsi2sd xmm2, rdx
00017192  eb01                     jmp 0x17195
00017194  cc                       int3
00017195  f20f5e15b3cf2400         divsd xmm2, qword ptr [rip + 0x24cfb3]
0001719d  4885c9                   test rcx, rcx
000171a0  0f851e091600             jne 0x177ac4
000171a6  f2410f110f               movsd qword ptr [r15], xmm1
000171ab  f20f114f28               movsd qword ptr [rdi + 0x28], xmm1
000171b0  4889aff0fdffff           mov qword ptr [rdi - 0x210], rbp
000171b7  e9bbfbffff               jmp 0x16d77
000171bc  cc                       int3
