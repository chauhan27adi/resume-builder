; CMemThread<CMemProc>::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13daf0, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13daf0 (55 bytes)
0013daf0  48895c2408               mov qword ptr [rsp + 8], rbx
0013daf5  57                       push rdi
0013daf6  4883ec20                 sub rsp, 0x20
0013dafa  8bda                     mov ebx, edx
0013dafc  488bf9                   mov rdi, rcx
0013daff  e88c51f9ff               call 0xd2c90
0013db04  83e305                   and ebx, 5
0013db07  80fb05                   cmp bl, 5
0013db0a  750d                     jne 0x13db19
0013db0c  ba78010000               mov edx, 0x178
0013db11  488bcf                   mov rcx, rdi
0013db14  e8f734ecff               call 0x1010
0013db19  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013db1e  488bc7                   mov rax, rdi
0013db21  4883c420                 add rsp, 0x20
0013db25  5f                       pop rdi
0013db26  c3                       ret
