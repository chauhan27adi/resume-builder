; SOS_StoreAndClockAlgorithmControlInterface::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x1821c0, 63 bytes in 1 chunk(s)

; chunk at RVA 0x1821c0 (63 bytes)
001821c0  48894c2408               mov qword ptr [rsp + 8], rcx
001821c5  53                       push rbx
001821c6  4883ec30                 sub rsp, 0x30
001821ca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001821d3  488bd9                   mov rbx, rcx
001821d6  488d0583da0c00           lea rax, [rip + 0xcda83]
001821dd  488901                   mov qword ptr [rcx], rax
001821e0  c74108adde0080           mov dword ptr [rcx + 8], 0x8000dead
001821e7  f6c201                   test dl, 1
001821ea  740a                     je 0x1821f6
001821ec  ba10000000               mov edx, 0x10
001821f1  e8fa5be8ff               call 0x7df0
001821f6  488bc3                   mov rax, rbx
001821f9  4883c430                 add rsp, 0x30
001821fd  5b                       pop rbx
001821fe  c3                       ret
