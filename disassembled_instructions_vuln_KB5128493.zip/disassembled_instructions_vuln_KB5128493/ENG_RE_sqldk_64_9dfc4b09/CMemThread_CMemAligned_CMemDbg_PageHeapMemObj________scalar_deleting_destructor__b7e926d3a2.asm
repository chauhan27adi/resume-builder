; CMemThread<CMemAligned<CMemDbg<PageHeapMemObj> > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13df50, 115 bytes in 1 chunk(s)

; chunk at RVA 0x13df50 (115 bytes)
0013df50  48894c2408               mov qword ptr [rsp + 8], rcx
0013df55  57                       push rdi
0013df56  4883ec30                 sub rsp, 0x30
0013df5a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013df63  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013df68  8bda                     mov ebx, edx
0013df6a  488bf9                   mov rdi, rcx
0013df6d  488d053cc21000           lea rax, [rip + 0x10c23c]
0013df74  488901                   mov qword ptr [rcx], rax
0013df77  488d8158040000           lea rax, [rcx + 0x458]
0013df7e  4889442450               mov qword ptr [rsp + 0x50], rax
0013df83  488d0db6bb0f00           lea rcx, [rip + 0xfbbb6]
0013df8a  48894830                 mov qword ptr [rax + 0x30], rcx
0013df8e  488908                   mov qword ptr [rax], rcx
0013df91  488d0538d21000           lea rax, [rip + 0x10d238]
0013df98  488907                   mov qword ptr [rdi], rax
0013df9b  488bcf                   mov rcx, rdi
0013df9e  e86d440300               call 0x172410
0013dfa3  f6c301                   test bl, 1
0013dfa6  740d                     je 0x13dfb5
0013dfa8  ba30050000               mov edx, 0x530
0013dfad  488bcf                   mov rcx, rdi
0013dfb0  e83b9eecff               call 0x7df0
0013dfb5  488bc7                   mov rax, rdi
0013dfb8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013dfbd  4883c430                 add rsp, 0x30
0013dfc1  5f                       pop rdi
0013dfc2  c3                       ret
