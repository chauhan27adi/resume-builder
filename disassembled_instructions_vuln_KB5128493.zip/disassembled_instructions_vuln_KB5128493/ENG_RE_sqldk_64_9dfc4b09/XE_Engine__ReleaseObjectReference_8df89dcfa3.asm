; XE_Engine::ReleaseObjectReference
; sqldk.dll, primary RVA 0x1e3170, 460 bytes in 1 chunk(s)

; chunk at RVA 0x1e3170 (460 bytes)
001e3170  4057                     push rdi
001e3172  4883ec30                 sub rsp, 0x30
001e3176  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001e317f  48895c2448               mov qword ptr [rsp + 0x48], rbx
001e3184  488bd9                   mov rbx, rcx
001e3187  8bc1                     mov eax, ecx
001e3189  83e007                   and eax, 7
001e318c  83f805                   cmp eax, 5
001e318f  0f877d010000             ja 0x1e3312
001e3195  4898                     cdqe
001e3197  488d1562cee1ff           lea rdx, [rip - 0x1e319e]
001e319e  8b8c8224331e00           mov ecx, dword ptr [rdx + rax*4 + 0x1e3324]
001e31a5  4803ca                   add rcx, rdx
001e31a8  ffe1                     jmp rcx
001e31aa  4883e3f8                 and rbx, 0xfffffffffffffff8
001e31ae  b8ffffffff               mov eax, 0xffffffff
001e31b3  f00fc14328               lock xadd dword ptr [rbx + 0x28], eax
001e31b8  ffc8                     dec eax
001e31ba  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e31bf  4883c430                 add rsp, 0x30
001e31c3  5f                       pop rdi
001e31c4  c3                       ret
001e31c5  4883e3f8                 and rbx, 0xfffffffffffffff8
001e31c9  bfffffffff               mov edi, 0xffffffff
001e31ce  f00fc17b18               lock xadd dword ptr [rbx + 0x18], edi
001e31d3  83ef01                   sub edi, 1
001e31d6  751b                     jne 0x1e31f3
001e31d8  48837b1000               cmp qword ptr [rbx + 0x10], 0
001e31dd  740c                     je 0x1e31eb
001e31df  488bd3                   mov rdx, rbx
001e31e2  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
001e31e6  e8955d0000               call 0x1e8f80
001e31eb  488bcb                   mov rcx, rbx
001e31ee  e88da30000               call 0x1ed580
001e31f3  8bc7                     mov eax, edi
001e31f5  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e31fa  4883c430                 add rsp, 0x30
001e31fe  5f                       pop rdi
001e31ff  c3                       ret
001e3200  4883e3f8                 and rbx, 0xfffffffffffffff8
001e3204  bfffffffff               mov edi, 0xffffffff
001e3209  f00fc17b18               lock xadd dword ptr [rbx + 0x18], edi
001e320e  83ef01                   sub edi, 1
001e3211  75e0                     jne 0x1e31f3
001e3213  48837b1000               cmp qword ptr [rbx + 0x10], 0
001e3218  740c                     je 0x1e3226
001e321a  488bd3                   mov rdx, rbx
001e321d  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
001e3221  e88a720000               call 0x1ea4b0
001e3226  488bcb                   mov rcx, rbx
001e3229  e8b2190100               call 0x1f4be0
001e322e  8bc7                     mov eax, edi
001e3230  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e3235  4883c430                 add rsp, 0x30
001e3239  5f                       pop rdi
001e323a  c3                       ret
001e323b  4883e3f8                 and rbx, 0xfffffffffffffff8
001e323f  bfffffffff               mov edi, 0xffffffff
001e3244  f00fc13b                 lock xadd dword ptr [rbx], edi
001e3248  83ef01                   sub edi, 1
001e324b  75a6                     jne 0x1e31f3
001e324d  48895c2440               mov qword ptr [rsp + 0x40], rbx
001e3252  4885db                   test rbx, rbx
001e3255  749c                     je 0x1e31f3
001e3257  488bcb                   mov rcx, rbx
001e325a  e831fa0000               call 0x1f2c90
001e325f  90                       nop
001e3260  c703adde0080             mov dword ptr [rbx], 0x8000dead
001e3266  ba88000000               mov edx, 0x88
001e326b  488bcb                   mov rcx, rbx
001e326e  e87d4be2ff               call 0x7df0
001e3273  8bc7                     mov eax, edi
001e3275  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e327a  4883c430                 add rsp, 0x30
001e327e  5f                       pop rdi
001e327f  c3                       ret
001e3280  4883e3f8                 and rbx, 0xfffffffffffffff8
001e3284  bfffffffff               mov edi, 0xffffffff
001e3289  f00fc17b10               lock xadd dword ptr [rbx + 0x10], edi
001e328e  83ef01                   sub edi, 1
001e3291  0f855cffffff             jne 0x1e31f3
001e3297  48837b0800               cmp qword ptr [rbx + 8], 0
001e329c  740c                     je 0x1e32aa
001e329e  488bd3                   mov rdx, rbx
001e32a1  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001e32a5  e8965a0000               call 0x1e8d40
001e32aa  488bcb                   mov rcx, rbx
001e32ad  e81e090100               call 0x1f3bd0
001e32b2  baa8000000               mov edx, 0xa8
001e32b7  488bcb                   mov rcx, rbx
001e32ba  e8314be2ff               call 0x7df0
001e32bf  8bc7                     mov eax, edi
001e32c1  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e32c6  4883c430                 add rsp, 0x30
001e32ca  5f                       pop rdi
001e32cb  c3                       ret
001e32cc  4883e3f8                 and rbx, 0xfffffffffffffff8
001e32d0  488d4308                 lea rax, [rbx + 8]
001e32d4  bfffffffff               mov edi, 0xffffffff
001e32d9  f00fc138                 lock xadd dword ptr [rax], edi
001e32dd  83ef01                   sub edi, 1
001e32e0  0f850dffffff             jne 0x1e31f3
001e32e6  33c9                     xor ecx, ecx
001e32e8  4885c0                   test rax, rax
001e32eb  480f44d9                 cmove rbx, rcx
001e32ef  4885db                   test rbx, rbx
001e32f2  0f84fbfeffff             je 0x1e31f3
001e32f8  4c8b03                   mov r8, qword ptr [rbx]
001e32fb  8d5701                   lea edx, [rdi + 1]
001e32fe  488bcb                   mov rcx, rbx
001e3301  41ff5020                 call qword ptr [r8 + 0x20]
001e3305  8bc7                     mov eax, edi
001e3307  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e330c  4883c430                 add rsp, 0x30
001e3310  5f                       pop rdi
001e3311  c3                       ret
001e3312  b8ffffffff               mov eax, 0xffffffff
001e3317  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001e331c  4883c430                 add rsp, 0x30
001e3320  5f                       pop rdi
001e3321  c3                       ret
001e3322  90                       nop
001e3323  90                       nop
001e3324  aa                       stosb byte ptr [rdi], al
001e3325  311e                     xor dword ptr [rsi], ebx
001e3327  00c5                     add ch, al
001e3329  311e                     xor dword ptr [rsi], ebx
001e332b  0000                     add byte ptr [rax], al
001e332d  321e                     xor bl, byte ptr [rsi]
001e332f  00cc                     add ah, cl
001e3331  321e                     xor bl, byte ptr [rsi]
001e3333  003b                     add byte ptr [rbx], bh
001e3335  321e                     xor bl, byte ptr [rsi]
