; CMemPartitioned<CMemThread<CMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcedb0, 104 bytes in 1 chunk(s)

; chunk at RVA 0xcedb0 (104 bytes)
000cedb0  48894c2408               mov qword ptr [rsp + 8], rcx
000cedb5  57                       push rdi
000cedb6  4883ec30                 sub rsp, 0x30
000cedba  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cedc3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cedc8  8bda                     mov ebx, edx
000cedca  488bf9                   mov rdi, rcx
000cedcd  488d0514d01700           lea rax, [rip + 0x17d014]
000cedd4  488901                   mov qword ptr [rcx], rax
000cedd7  488d8190020000           lea rax, [rcx + 0x290]
000cedde  4889442450               mov qword ptr [rsp + 0x50], rax
000cede3  488d0d56ad1600           lea rcx, [rip + 0x16ad56]
000cedea  488908                   mov qword ptr [rax], rcx
000ceded  488bcf                   mov rcx, rdi
000cedf0  e8abb30500               call 0x12a1a0
000cedf5  83e305                   and ebx, 5
000cedf8  80fb05                   cmp bl, 5
000cedfb  750d                     jne 0xcee0a
000cedfd  bac8020000               mov edx, 0x2c8
000cee02  488bcf                   mov rcx, rdi
000cee05  e80622f3ff               call 0x1010
000cee0a  488bc7                   mov rax, rdi
000cee0d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cee12  4883c430                 add rsp, 0x30
000cee16  5f                       pop rdi
000cee17  c3                       ret
