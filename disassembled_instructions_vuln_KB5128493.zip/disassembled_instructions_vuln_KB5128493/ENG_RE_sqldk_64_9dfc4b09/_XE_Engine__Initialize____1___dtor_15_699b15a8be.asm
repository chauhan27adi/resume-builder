; `XE_Engine::Initialize'::`1'::dtor$15
; sqldk.dll, primary RVA 0x233f92, 53 bytes in 1 chunk(s)

; chunk at RVA 0x233f92 (53 bytes)
00233f92  4055                     push rbp
00233f94  4883ec30                 sub rsp, 0x30
00233f98  488bea                   mov rbp, rdx
00233f9b  c644242806               mov byte ptr [rsp + 0x28], 6
00233fa0  8b4530                   mov eax, dword ptr [rbp + 0x30]
00233fa3  89442420                 mov dword ptr [rsp + 0x20], eax
00233fa7  4c8d0df2670700           lea r9, [rip + 0x767f2]
00233fae  41b801000000             mov r8d, 1
00233fb4  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00233fb8  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00233fbc  e8ff5efaff               call 0x1d9ec0
00233fc1  4883c430                 add rsp, 0x30
00233fc5  5d                       pop rbp
00233fc6  c3                       ret
