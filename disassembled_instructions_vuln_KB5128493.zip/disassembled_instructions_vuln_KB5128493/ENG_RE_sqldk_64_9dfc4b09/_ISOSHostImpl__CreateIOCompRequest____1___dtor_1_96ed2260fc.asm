; `ISOSHostImpl::CreateIOCompRequest'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22afdc, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22afdc (59 bytes)
0022afdc  4055                     push rbp
0022afde  4883ec30                 sub rsp, 0x30
0022afe2  488bea                   mov rbp, rdx
0022afe5  c644242806               mov byte ptr [rsp + 0x28], 6
0022afea  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0022aff0  89442420                 mov dword ptr [rsp + 0x20], eax
0022aff4  4c8d0de5eb0600           lea r9, [rip + 0x6ebe5]
0022affb  41b801000000             mov r8d, 1
0022b001  488b9588000000           mov rdx, qword ptr [rbp + 0x88]
0022b008  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022b00c  e88fcdddff               call 0x7da0
0022b011  4883c430                 add rsp, 0x30
0022b015  5d                       pop rbp
0022b016  c3                       ret
