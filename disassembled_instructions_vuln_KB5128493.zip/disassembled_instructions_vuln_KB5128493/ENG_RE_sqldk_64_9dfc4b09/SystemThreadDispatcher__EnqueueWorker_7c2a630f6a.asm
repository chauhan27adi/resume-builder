; SystemThreadDispatcher::EnqueueWorker
; sqldk.dll, primary RVA 0x35840, 370 bytes in 1 chunk(s)

; chunk at RVA 0x35840 (370 bytes)
00035840  4055                     push rbp
00035842  56                       push rsi
00035843  57                       push rdi
00035844  4154                     push r12
00035846  4155                     push r13
00035848  4156                     push r14
0003584a  4157                     push r15
0003584c  4883ec40                 sub rsp, 0x40
00035850  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00035859  48899c2488000000         mov qword ptr [rsp + 0x88], rbx
00035861  458be8                   mov r13d, r8d
00035864  488bea                   mov rbp, rdx
00035867  488bf9                   mov rdi, rcx
0003586a  4533e4                   xor r12d, r12d
0003586d  44396108                 cmp dword ptr [rcx + 8], r12d
00035871  0f8551620300             jne 0x6bac8
00035877  4c8d7740                 lea r14, [rdi + 0x40]
0003587b  4c89742430               mov qword ptr [rsp + 0x30], r14
00035880  4489642438               mov dword ptr [rsp + 0x38], r12d
00035885  33db                     xor ebx, ebx
00035887  658b042548000000         mov eax, dword ptr gs:[0x48]
0003588f  448bf8                   mov r15d, eax
00035892  418b06                   mov eax, dword ptr [r14]
00035895  85c0                     test eax, eax
00035897  0f858d380000             jne 0x3912a
0003589d  33c0                     xor eax, eax
0003589f  f04d0fb13e               lock cmpxchg qword ptr [r14], r15
000358a4  8bc3                     mov eax, ebx
000358a6  0f94c0                   sete al
000358a9  85c0                     test eax, eax
000358ab  0f8479380000             je 0x3912a
000358b1  c744243801000000         mov dword ptr [rsp + 0x38], 1
000358b9  488d5720                 lea rdx, [rdi + 0x20]
000358bd  488b4a08                 mov rcx, qword ptr [rdx + 8]
000358c1  33db                     xor ebx, ebx
000358c3  483bca                   cmp rcx, rdx
000358c6  0f851affffff             jne 0x357e6
000358cc  837f0800                 cmp dword ptr [rdi + 8], 0
000358d0  0f8580620300             jne 0x6bb56
000358d6  488d5710                 lea rdx, [rdi + 0x10]
000358da  488d4d08                 lea rcx, [rbp + 8]
000358de  488b02                   mov rax, qword ptr [rdx]
000358e1  488901                   mov qword ptr [rcx], rax
000358e4  488b02                   mov rax, qword ptr [rdx]
000358e7  48894808                 mov qword ptr [rax + 8], rcx
000358eb  48890a                   mov qword ptr [rdx], rcx
000358ee  48895108                 mov qword ptr [rcx + 8], rdx
000358f2  488b742430               mov rsi, qword ptr [rsp + 0x30]
000358f7  4885f6                   test rsi, rsi
000358fa  7425                     je 0x35921
000358fc  803dbefb2d0000           cmp byte ptr [rip + 0x2dfbbe], 0
00035903  0f8563620300             jne 0x6bb6c
00035909  48c70600000000           mov qword ptr [rsi], 0
00035910  48c744243000000000       mov qword ptr [rsp + 0x30], 0
00035919  c744243800000000         mov dword ptr [rsp + 0x38], 0
00035921  4885db                   test rbx, rbx
00035924  751b                     jne 0x35941
00035926  418bc4                   mov eax, r12d
00035929  488b9c2488000000         mov rbx, qword ptr [rsp + 0x88]
00035931  4883c440                 add rsp, 0x40
00035935  415f                     pop r15
00035937  415e                     pop r14
00035939  415d                     pop r13
0003593b  415c                     pop r12
0003593d  5f                       pop rdi
0003593e  5e                       pop rsi
0003593f  5d                       pop rbp
00035940  c3                       ret
00035941  8b554c                   mov edx, dword ptr [rbp + 0x4c]
00035944  488bcb                   mov rcx, rbx
00035947  e834fbffff               call 0x35480
0003594c  488bd5                   mov rdx, rbp
0003594f  488bcb                   mov rcx, rbx
00035952  e8b983ffff               call 0x2dd10
00035957  83a308010000fc           and dword ptr [rbx + 0x108], 0xfffffffc
0003595e  f7852003000000004000     test dword ptr [rbp + 0x320], 0x400000
00035968  0f852d620300             jne 0x6bb9b
0003596e  488b8d70020000           mov rcx, qword ptr [rbp + 0x270]
00035975  654c8b0c2558000000       mov r9, qword ptr gs:[0x58]
0003597e  8b154cf62d00             mov edx, dword ptr [rip + 0x2df64c]
00035984  448b052dbffcff           mov r8d, dword ptr [rip - 0x340d3]
0003598b  4d0304d1                 add r8, qword ptr [r9 + rdx*8]
0003598f  4c8981f8000000           mov qword ptr [rcx + 0xf8], r8
00035996  488b8940010000           mov rcx, qword ptr [rcx + 0x140]
0003599d  ff15bd372000             call qword ptr [rip + 0x2037bd]
000359a3  488bcf                   mov rcx, rdi
000359a6  e815000000               call 0x359c0
000359ab  90                       nop
000359ac  e975ffffff               jmp 0x35926
000359b1  cc                       int3
