; `SOS_Node::CompleteStartIO'::`1'::dtor$0
; sqldk.dll, primary RVA 0x218f90, 66 bytes in 1 chunk(s)

; chunk at RVA 0x218f90 (66 bytes)
00218f90  4055                     push rbp
00218f92  4883ec30                 sub rsp, 0x30
00218f96  488bea                   mov rbp, rdx
00218f99  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
00218fa0  4881c240010000           add rdx, 0x140
00218fa7  c644242806               mov byte ptr [rsp + 0x28], 6
00218fac  8b4544                   mov eax, dword ptr [rbp + 0x44]
00218faf  89442420                 mov dword ptr [rsp + 0x20], eax
00218fb3  4c8d0d6ee70700           lea r9, [rip + 0x7e76e]
00218fba  41b801000000             mov r8d, 1
00218fc0  488b12                   mov rdx, qword ptr [rdx]
00218fc3  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00218fc7  e8d4eddeff               call 0x7da0
00218fcc  4883c430                 add rsp, 0x30
00218fd0  5d                       pop rbp
00218fd1  c3                       ret
