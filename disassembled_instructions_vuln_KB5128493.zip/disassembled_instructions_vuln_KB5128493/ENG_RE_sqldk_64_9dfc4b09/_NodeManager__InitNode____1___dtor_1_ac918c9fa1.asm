; `NodeManager::InitNode'::`1'::dtor$1
; sqldk.dll, primary RVA 0x21c83b, 53 bytes in 1 chunk(s)

; chunk at RVA 0x21c83b (53 bytes)
0021c83b  4055                     push rbp
0021c83d  4883ec30                 sub rsp, 0x30
0021c841  488bea                   mov rbp, rdx
0021c844  c644242806               mov byte ptr [rsp + 0x28], 6
0021c849  8b4540                   mov eax, dword ptr [rbp + 0x40]
0021c84c  89442420                 mov dword ptr [rsp + 0x20], eax
0021c850  4c8d0d61c50700           lea r9, [rip + 0x7c561]
0021c857  41b801000000             mov r8d, 1
0021c85d  488b5548                 mov rdx, qword ptr [rbp + 0x48]
0021c861  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
0021c865  e836b5deff               call 0x7da0
0021c86a  4883c430                 add rsp, 0x30
0021c86e  5d                       pop rbp
0021c86f  c3                       ret
