; CSessionTraceFlags::SetSessionTrace
; sqldk.dll, primary RVA 0x1b4910, 266 bytes in 1 chunk(s)

; chunk at RVA 0x1b4910 (266 bytes)
001b4910  4053                     push rbx
001b4912  4883ec20                 sub rsp, 0x20
001b4916  8bd9                     mov ebx, ecx
001b4918  81f9ac3f0000             cmp ecx, 0x3fac
001b491e  0f83ee000000             jae 0x1b4a12
001b4924  85d2                     test edx, edx
001b4926  7414                     je 0x1b493c
001b4928  e813080000               call 0x1b5140
001b492d  4885c0                   test rax, rax
001b4930  740a                     je 0x1b493c
001b4932  83780c00                 cmp dword ptr [rax + 0xc], 0
001b4936  0f84d6000000             je 0x1b4a12
001b493c  488b0db5d61700           mov rcx, qword ptr [rip + 0x17d6b5]
001b4943  488b01                   mov rax, qword ptr [rcx]
001b4946  ff5020                   call qword ptr [rax + 0x20]
001b4949  33d2                     xor edx, edx
001b494b  4c8bc8                   mov r9, rax
001b494e  4885c0                   test rax, rax
001b4951  745d                     je 0x1b49b0
001b4953  8bcb                     mov ecx, ebx
001b4955  b8cdcccccc               mov eax, 0xcccccccd
001b495a  f7e3                     mul ebx
001b495c  c1ea03                   shr edx, 3
001b495f  448d0492                 lea r8d, [rdx + rdx*4]
001b4963  4503c0                   add r8d, r8d
001b4966  412bc8                   sub ecx, r8d
001b4969  4c8d048d00000000         lea r8, [rcx*4]
001b4971  438b440104               mov eax, dword ptr [r9 + r8 + 4]
001b4976  85c0                     test eax, eax
001b4978  7473                     je 0x1b49ed
001b497a  3bc3                     cmp eax, ebx
001b497c  0f8488000000             je 0x1b4a0a
001b4982  33d2                     xor edx, edx
001b4984  498d4104                 lea rax, [r9 + 4]
001b4988  33c9                     xor ecx, ecx
001b498a  660f1f440000             nop word ptr [rax + rax]
001b4990  833800                   cmp dword ptr [rax], 0
001b4993  744e                     je 0x1b49e3
001b4995  ffc2                     inc edx
001b4997  48ffc1                   inc rcx
001b499a  4883c004                 add rax, 4
001b499e  4883f90a                 cmp rcx, 0xa
001b49a2  7cec                     jl 0x1b4990
001b49a4  498bd1                   mov rdx, r9
001b49a7  4d8b4930                 mov r9, qword ptr [r9 + 0x30]
001b49ab  4d85c9                   test r9, r9
001b49ae  75c1                     jne 0x1b4971
001b49b0  488b0d41d61700           mov rcx, qword ptr [rip + 0x17d641]
001b49b7  4c8b01                   mov r8, qword ptr [rcx]
001b49ba  41ff5018                 call qword ptr [r8 + 0x18]
001b49be  4c8bc8                   mov r9, rax
001b49c1  4885c0                   test rax, rax
001b49c4  744c                     je 0x1b4a12
001b49c6  8bcb                     mov ecx, ebx
001b49c8  b8cdcccccc               mov eax, 0xcccccccd
001b49cd  f7e3                     mul ebx
001b49cf  c1ea03                   shr edx, 3
001b49d2  448d0492                 lea r8d, [rdx + rdx*4]
001b49d6  4503c0                   add r8d, r8d
001b49d9  412bc8                   sub ecx, r8d
001b49dc  41895c8904               mov dword ptr [r9 + rcx*4 + 4], ebx
001b49e1  eb0f                     jmp 0x1b49f2
001b49e3  4863c2                   movsxd rax, edx
001b49e6  41895c8104               mov dword ptr [r9 + rax*4 + 4], ebx
001b49eb  eb05                     jmp 0x1b49f2
001b49ed  43895c0104               mov dword ptr [r9 + r8 + 4], ebx
001b49f2  488b0dffd51700           mov rcx, qword ptr [rip + 0x17d5ff]
001b49f9  41b901000000             mov r9d, 1
001b49ff  4533c0                   xor r8d, r8d
001b4a02  8bd3                     mov edx, ebx
001b4a04  488b01                   mov rax, qword ptr [rcx]
001b4a07  ff5010                   call qword ptr [rax + 0x10]
001b4a0a  b001                     mov al, 1
001b4a0c  4883c420                 add rsp, 0x20
001b4a10  5b                       pop rbx
001b4a11  c3                       ret
001b4a12  32c0                     xor al, al
001b4a14  4883c420                 add rsp, 0x20
001b4a18  5b                       pop rbx
001b4a19  c3                       ret
