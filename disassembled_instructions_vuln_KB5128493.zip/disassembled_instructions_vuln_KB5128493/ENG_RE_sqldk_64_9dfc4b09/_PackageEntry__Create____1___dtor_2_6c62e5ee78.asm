; `PackageEntry::Create'::`1'::dtor$2
; sqldk.dll, primary RVA 0x216f94, 35 bytes in 1 chunk(s)

; chunk at RVA 0x216f94 (35 bytes)
00216f94  4055                     push rbp
00216f96  4883ec20                 sub rsp, 0x20
00216f9a  488bea                   mov rbp, rdx
00216f9d  4c8b8590000000           mov r8, qword ptr [rbp + 0x90]
00216fa4  488b5548                 mov rdx, qword ptr [rbp + 0x48]
00216fa8  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00216fac  e85fa0deff               call 0x1010
00216fb1  4883c420                 add rsp, 0x20
00216fb5  5d                       pop rbp
00216fb6  c3                       ret
