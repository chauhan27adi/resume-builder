; CMemPartitioned<CMemThread<CMemProc> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xcde10, 104 bytes in 1 chunk(s)

; chunk at RVA 0xcde10 (104 bytes)
000cde10  48894c2408               mov qword ptr [rsp + 8], rcx
000cde15  57                       push rdi
000cde16  4883ec30                 sub rsp, 0x30
000cde1a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cde23  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cde28  8bda                     mov ebx, edx
000cde2a  488bf9                   mov rdi, rcx
000cde2d  488d05f40b1800           lea rax, [rip + 0x180bf4]
000cde34  488901                   mov qword ptr [rcx], rax
000cde37  488d8108020000           lea rax, [rcx + 0x208]
000cde3e  4889442450               mov qword ptr [rsp + 0x50], rax
000cde43  488d0df6bc1600           lea rcx, [rip + 0x16bcf6]
000cde4a  488908                   mov qword ptr [rax], rcx
000cde4d  488bcf                   mov rcx, rdi
000cde50  e83b4e0000               call 0xd2c90
000cde55  83e305                   and ebx, 5
000cde58  80fb05                   cmp bl, 5
000cde5b  750d                     jne 0xcde6a
000cde5d  ba40020000               mov edx, 0x240
000cde62  488bcf                   mov rcx, rdi
000cde65  e8a631f3ff               call 0x1010
000cde6a  488bc7                   mov rax, rdi
000cde6d  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cde72  4883c430                 add rsp, 0x30
000cde76  5f                       pop rdi
000cde77  c3                       ret
