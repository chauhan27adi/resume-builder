; CMemThread<CMemAligned<CMemDbg<PageHeapMemObj> > >::~CMemThread<CMemAligned<CMemDbg<PageHeapMemObj> > >
; sqldk.dll, primary RVA 0xec0d0, 73 bytes in 1 chunk(s)

; chunk at RVA 0xec0d0 (73 bytes)
000ec0d0  48894c2408               mov qword ptr [rsp + 8], rcx
000ec0d5  4883ec38                 sub rsp, 0x38
000ec0d9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ec0e2  488d05c7e01500           lea rax, [rip + 0x15e0c7]
000ec0e9  488901                   mov qword ptr [rcx], rax
000ec0ec  488d8158040000           lea rax, [rcx + 0x458]
000ec0f3  4889442448               mov qword ptr [rsp + 0x48], rax
000ec0f8  488d1541da1400           lea rdx, [rip + 0x14da41]
000ec0ff  48895030                 mov qword ptr [rax + 0x30], rdx
000ec103  488910                   mov qword ptr [rax], rdx
000ec106  488d05c3f01500           lea rax, [rip + 0x15f0c3]
000ec10d  488901                   mov qword ptr [rcx], rax
000ec110  4883c438                 add rsp, 0x38
000ec114  e9f7620800               jmp 0x172410
