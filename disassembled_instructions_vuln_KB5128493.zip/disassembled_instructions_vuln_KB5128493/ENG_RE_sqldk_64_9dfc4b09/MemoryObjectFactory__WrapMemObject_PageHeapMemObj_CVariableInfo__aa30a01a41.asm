; MemoryObjectFactory::WrapMemObject<PageHeapMemObj,CVariableInfo>
; sqldk.dll, primary RVA 0xc9850, 4408 bytes in 1 chunk(s)

; chunk at RVA 0xc9850 (4408 bytes)
000c9850  4c894c2420               mov qword ptr [rsp + 0x20], r9
000c9855  4c89442418               mov qword ptr [rsp + 0x18], r8
000c985a  55                       push rbp
000c985b  56                       push rsi
000c985c  57                       push rdi
000c985d  4154                     push r12
000c985f  4155                     push r13
000c9861  4156                     push r14
000c9863  4157                     push r15
000c9865  488bec                   mov rbp, rsp
000c9868  4883ec70                 sub rsp, 0x70
000c986c  48c745d0feffffff         mov qword ptr [rbp - 0x30], 0xfffffffffffffffe
000c9874  48899c24b0000000         mov qword ptr [rsp + 0xb0], rbx
000c987c  498bf0                   mov rsi, r8
000c987f  8bc2                     mov eax, edx
000c9881  488d157867f3ff           lea rdx, [rip - 0xc9888]
000c9888  4c8bbcc200273100         mov r15, qword ptr [rdx + rax*8 + 0x312700]
000c9890  4c897d58                 mov qword ptr [rbp + 0x58], r15
000c9894  448b6578                 mov r12d, dword ptr [rbp + 0x78]
000c9898  458bf4                   mov r14d, r12d
000c989b  4181e602002f01           and r14d, 0x12f0002
000c98a2  4533ed                   xor r13d, r13d
000c98a5  418bdd                   mov ebx, r13d
000c98a8  83f92a                   cmp ecx, 0x2a
000c98ab  0f8710100000             ja 0xca8c1
000c98b1  4863c1                   movsxd rax, ecx
000c98b4  8b8c82dca80c00           mov ecx, dword ptr [rdx + rax*4 + 0xca8dc]
000c98bb  4803ca                   add rcx, rdx
000c98be  ffe1                     jmp rcx
000c98c0  488bd6                   mov rdx, rsi
000c98c3  b980000000               mov ecx, 0x80
000c98c8  e8a383f4ff               call 0x11c70
000c98cd  488bd8                   mov rbx, rax
000c98d0  48894558                 mov qword ptr [rbp + 0x58], rax
000c98d4  4885c0                   test rax, rax
000c98d7  744c                     je 0xc9925
000c98d9  c7400801000000           mov dword ptr [rax + 8], 1
000c98e0  488d0521d91700           lea rax, [rip + 0x17d921]
000c98e7  488903                   mov qword ptr [rbx], rax
000c98ea  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c98f2  44896b18                 mov dword ptr [rbx + 0x18], r13d
000c98f6  4c896b20                 mov qword ptr [rbx + 0x20], r13
000c98fa  44896b28                 mov dword ptr [rbx + 0x28], r13d
000c98fe  4c896b30                 mov qword ptr [rbx + 0x30], r13
000c9902  4c896b38                 mov qword ptr [rbx + 0x38], r13
000c9906  4c896b40                 mov qword ptr [rbx + 0x40], r13
000c990a  4c896b48                 mov qword ptr [rbx + 0x48], r13
000c990e  488d050b4d1800           lea rax, [rip + 0x184d0b]
000c9915  488903                   mov qword ptr [rbx], rax
000c9918  488d4368                 lea rax, [rbx + 0x68]
000c991c  48894008                 mov qword ptr [rax + 8], rax
000c9920  488900                   mov qword ptr [rax], rax
000c9923  eb03                     jmp 0xc9928
000c9925  498bdd                   mov rbx, r13
000c9928  e96c0f0000               jmp 0xca899
000c992d  488bd6                   mov rdx, rsi
000c9930  b950040000               mov ecx, 0x450
000c9935  e83683f4ff               call 0x11c70
000c993a  488bd8                   mov rbx, rax
000c993d  48894558                 mov qword ptr [rbp + 0x58], rax
000c9941  4885c0                   test rax, rax
000c9944  7464                     je 0xc99aa
000c9946  c7400801000000           mov dword ptr [rax + 8], 1
000c994d  488d05b4d81700           lea rax, [rip + 0x17d8b4]
000c9954  488903                   mov qword ptr [rbx], rax
000c9957  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c995f  44896b18                 mov dword ptr [rbx + 0x18], r13d
000c9963  4c896b20                 mov qword ptr [rbx + 0x20], r13
000c9967  44896b28                 mov dword ptr [rbx + 0x28], r13d
000c996b  4c896b30                 mov qword ptr [rbx + 0x30], r13
000c996f  4c896b38                 mov qword ptr [rbx + 0x38], r13
000c9973  4c896b40                 mov qword ptr [rbx + 0x40], r13
000c9977  4c896b48                 mov qword ptr [rbx + 0x48], r13
000c997b  488d059e4c1800           lea rax, [rip + 0x184c9e]
000c9982  488903                   mov qword ptr [rbx], rax
000c9985  488d4368                 lea rax, [rbx + 0x68]
000c9989  48894008                 mov qword ptr [rax + 8], rax
000c998d  488900                   mov qword ptr [rax], rax
000c9990  488d05d9491800           lea rax, [rip + 0x1849d9]
000c9997  488903                   mov qword ptr [rbx], rax
000c999a  488d0537c41900           lea rax, [rip + 0x19c437]
000c99a1  48898390000000           mov qword ptr [rbx + 0x90], rax
000c99a8  eb03                     jmp 0xc99ad
000c99aa  498bdd                   mov rbx, r13
000c99ad  65488b0c2558000000       mov rcx, qword ptr gs:[0x58]
000c99b6  8b0514b62400             mov eax, dword ptr [rip + 0x24b614]
000c99bc  8b3df67ef3ff             mov edi, dword ptr [rip - 0xc810a]
000c99c2  48033cc1                 add rdi, qword ptr [rcx + rax*8]
000c99c6  488b8700010000           mov rax, qword ptr [rdi + 0x100]
000c99cd  4885c0                   test rax, rax
000c99d0  750e                     jne 0xc99e0
000c99d2  33c9                     xor ecx, ecx
000c99d4  e837a7f6ff               call 0x34110
000c99d9  488b8700010000           mov rax, qword ptr [rdi + 0x100]
000c99e0  488b8058020000           mov rax, qword ptr [rax + 0x258]
000c99e7  48898380000000           mov qword ptr [rbx + 0x80], rax
000c99ee  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c99f8  4489b38c000000           mov dword ptr [rbx + 0x8c], r14d
000c99ff  4489ab38040000           mov dword ptr [rbx + 0x438], r13d
000c9a06  418bc4                   mov eax, r12d
000c9a09  c1e819                   shr eax, 0x19
000c9a0c  83e001                   and eax, 1
000c9a0f  89833c040000             mov dword ptr [rbx + 0x43c], eax
000c9a15  4489ab40040000           mov dword ptr [rbx + 0x440], r13d
000c9a1c  4c89ab48040000           mov qword ptr [rbx + 0x448], r13
000c9a23  488d8b90000000           lea rcx, [rbx + 0x90]
000c9a2a  4c8bcb                   mov r9, rbx
000c9a2d  458bc6                   mov r8d, r14d
000c9a30  498bd7                   mov rdx, r15
000c9a33  e878e90900               call 0x1683b0
000c9a38  e95c0e0000               jmp 0xca899
000c9a3d  488bd6                   mov rdx, rsi
000c9a40  b9f8000000               mov ecx, 0xf8
000c9a45  e82682f4ff               call 0x11c70
000c9a4a  48894558                 mov qword ptr [rbp + 0x58], rax
000c9a4e  4885c0                   test rax, rax
000c9a51  740d                     je 0xc9a60
000c9a53  488bc8                   mov rcx, rax
000c9a56  e8653d0000               call 0xcd7c0
000c9a5b  488bd8                   mov rbx, rax
000c9a5e  eb03                     jmp 0xc9a63
000c9a60  498bdd                   mov rbx, r13
000c9a63  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000c9a6a  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000c9a6f  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000c9a76  488bcb                   mov rcx, rbx
000c9a79  e812980100               call 0xe3290
000c9a7e  e9160e0000               jmp 0xca899
000c9a83  488bd6                   mov rdx, rsi
000c9a86  b988000000               mov ecx, 0x88
000c9a8b  e8e081f4ff               call 0x11c70
000c9a90  488bf8                   mov rdi, rax
000c9a93  48894558                 mov qword ptr [rbp + 0x58], rax
000c9a97  4885c0                   test rax, rax
000c9a9a  745d                     je 0xc9af9
000c9a9c  c7400801000000           mov dword ptr [rax + 8], 1
000c9aa3  488d055ed71700           lea rax, [rip + 0x17d75e]
000c9aaa  488907                   mov qword ptr [rdi], rax
000c9aad  48c7471000200000         mov qword ptr [rdi + 0x10], 0x2000
000c9ab5  44896f18                 mov dword ptr [rdi + 0x18], r13d
000c9ab9  4c896f20                 mov qword ptr [rdi + 0x20], r13
000c9abd  44896f28                 mov dword ptr [rdi + 0x28], r13d
000c9ac1  4c896f30                 mov qword ptr [rdi + 0x30], r13
000c9ac5  4c896f38                 mov qword ptr [rdi + 0x38], r13
000c9ac9  4c896f40                 mov qword ptr [rdi + 0x40], r13
000c9acd  4c896f48                 mov qword ptr [rdi + 0x48], r13
000c9ad1  488d05484b1800           lea rax, [rip + 0x184b48]
000c9ad8  488907                   mov qword ptr [rdi], rax
000c9adb  488d4768                 lea rax, [rdi + 0x68]
000c9adf  48894008                 mov qword ptr [rax + 8], rax
000c9ae3  488900                   mov qword ptr [rax], rax
000c9ae6  488d0533141800           lea rax, [rip + 0x181433]
000c9aed  488907                   mov qword ptr [rdi], rax
000c9af0  4c89af80000000           mov qword ptr [rdi + 0x80], r13
000c9af7  eb03                     jmp 0xc9afc
000c9af9  498bfd                   mov rdi, r13
000c9afc  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c9b03  0f1008                   movups xmm1, xmmword ptr [rax]
000c9b06  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c9b0a  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c9b0e  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c9b12  66480f7eca               movq rdx, xmm1
000c9b17  48c1ea20                 shr rdx, 0x20
000c9b1b  f6c201                   test dl, 1
000c9b1e  7564                     jne 0xc9b84
000c9b20  81e22ffbffff             and edx, 0xfffffb2f
000c9b26  81ca20020000             or edx, 0x220
000c9b2c  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c9b30  48c1e820                 shr rax, 0x20
000c9b34  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c9b38  498bc8                   mov rcx, r8
000c9b3b  48c1e920                 shr rcx, 0x20
000c9b3f  49c1e810                 shr r8, 0x10
000c9b43  89442438                 mov dword ptr [rsp + 0x38], eax
000c9b47  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c9b4a  89442430                 mov dword ptr [rsp + 0x30], eax
000c9b4e  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c9b52  664489442420             mov word ptr [rsp + 0x20], r8w
000c9b58  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c9b5d  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c9b61  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c9b64  e8a779f4ff               call 0x11510
000c9b69  48898780000000           mov qword ptr [rdi + 0x80], rax
000c9b70  4885c0                   test rax, rax
000c9b73  0f95c0                   setne al
000c9b76  498bdd                   mov rbx, r13
000c9b79  84c0                     test al, al
000c9b7b  480f45df                 cmovne rbx, rdi
000c9b7f  e9150d0000               jmp 0xca899
000c9b84  b001                     mov al, 1
000c9b86  498bdd                   mov rbx, r13
000c9b89  84c0                     test al, al
000c9b8b  480f45df                 cmovne rbx, rdi
000c9b8f  e9050d0000               jmp 0xca899
000c9b94  488bd6                   mov rdx, rsi
000c9b97  b958040000               mov ecx, 0x458
000c9b9c  e8cf80f4ff               call 0x11c70
000c9ba1  488bd8                   mov rbx, rax
000c9ba4  48894558                 mov qword ptr [rbp + 0x58], rax
000c9ba8  4885c0                   test rax, rax
000c9bab  7475                     je 0xc9c22
000c9bad  c7400801000000           mov dword ptr [rax + 8], 1
000c9bb4  488d054dd61700           lea rax, [rip + 0x17d64d]
000c9bbb  488903                   mov qword ptr [rbx], rax
000c9bbe  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c9bc6  44896b18                 mov dword ptr [rbx + 0x18], r13d
000c9bca  4c896b20                 mov qword ptr [rbx + 0x20], r13
000c9bce  44896b28                 mov dword ptr [rbx + 0x28], r13d
000c9bd2  4c896b30                 mov qword ptr [rbx + 0x30], r13
000c9bd6  4c896b38                 mov qword ptr [rbx + 0x38], r13
000c9bda  4c896b40                 mov qword ptr [rbx + 0x40], r13
000c9bde  4c896b48                 mov qword ptr [rbx + 0x48], r13
000c9be2  488d05374a1800           lea rax, [rip + 0x184a37]
000c9be9  488903                   mov qword ptr [rbx], rax
000c9bec  488d4368                 lea rax, [rbx + 0x68]
000c9bf0  48894008                 mov qword ptr [rax + 8], rax
000c9bf4  488900                   mov qword ptr [rax], rax
000c9bf7  488d0572471800           lea rax, [rip + 0x184772]
000c9bfe  488903                   mov qword ptr [rbx], rax
000c9c01  488d05d0c11900           lea rax, [rip + 0x19c1d0]
000c9c08  48898390000000           mov qword ptr [rbx + 0x90], rax
000c9c0f  488d05ba151800           lea rax, [rip + 0x1815ba]
000c9c16  488903                   mov qword ptr [rbx], rax
000c9c19  4c89ab50040000           mov qword ptr [rbx + 0x450], r13
000c9c20  eb03                     jmp 0xc9c25
000c9c22  498bdd                   mov rbx, r13
000c9c25  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c9c2c  0f1008                   movups xmm1, xmmword ptr [rax]
000c9c2f  66480f7eca               movq rdx, xmm1
000c9c34  48c1ea20                 shr rdx, 0x20
000c9c38  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c9c3c  f6c201                   test dl, 1
000c9c3f  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c9c43  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c9c47  0f8560fdffff             jne 0xc99ad
000c9c4d  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c9c51  48c1e820                 shr rax, 0x20
000c9c55  89442438                 mov dword ptr [rsp + 0x38], eax
000c9c59  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c9c5d  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c9c60  498bc8                   mov rcx, r8
000c9c63  89442430                 mov dword ptr [rsp + 0x30], eax
000c9c67  48c1e920                 shr rcx, 0x20
000c9c6b  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c9c6f  49c1e810                 shr r8, 0x10
000c9c73  664489442420             mov word ptr [rsp + 0x20], r8w
000c9c79  81e22ffbffff             and edx, 0xfffffb2f
000c9c7f  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c9c84  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c9c88  81ca20020000             or edx, 0x220
000c9c8e  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c9c91  e87a78f4ff               call 0x11510
000c9c96  48898350040000           mov qword ptr [rbx + 0x450], rax
000c9c9d  4885c0                   test rax, rax
000c9ca0  0f95c0                   setne al
000c9ca3  84c0                     test al, al
000c9ca5  0f8502fdffff             jne 0xc99ad
000c9cab  498bdd                   mov rbx, r13
000c9cae  e90e0c0000               jmp 0xca8c1
000c9cb3  488bd6                   mov rdx, rsi
000c9cb6  b958010000               mov ecx, 0x158
000c9cbb  e8b07ff4ff               call 0x11c70
000c9cc0  48894558                 mov qword ptr [rbp + 0x58], rax
000c9cc4  4885c0                   test rax, rax
000c9cc7  740d                     je 0xc9cd6
000c9cc9  488bc8                   mov rcx, rax
000c9ccc  e83fbd0100               call 0xe5a10
000c9cd1  488bd8                   mov rbx, rax
000c9cd4  eb03                     jmp 0xc9cd9
000c9cd6  498bdd                   mov rbx, r13
000c9cd9  e9bb0b0000               jmp 0xca899
000c9cde  488bd6                   mov rdx, rsi
000c9ce1  b9d0010000               mov ecx, 0x1d0
000c9ce6  e8857ff4ff               call 0x11c70
000c9ceb  48894558                 mov qword ptr [rbp + 0x58], rax
000c9cef  4885c0                   test rax, rax
000c9cf2  740d                     je 0xc9d01
000c9cf4  488bc8                   mov rcx, rax
000c9cf7  e8843b0000               call 0xcd880
000c9cfc  488bd8                   mov rbx, rax
000c9cff  eb03                     jmp 0xc9d04
000c9d01  498bdd                   mov rbx, r13
000c9d04  488b8580000000           mov rax, qword ptr [rbp + 0x80]
000c9d0b  440fb64044               movzx r8d, byte ptr [rax + 0x44]
000c9d10  488b9590000000           mov rdx, qword ptr [rbp + 0x90]
000c9d17  488bcb                   mov rcx, rbx
000c9d1a  e871350200               call 0xed290
000c9d1f  e9750b0000               jmp 0xca899
000c9d24  488bd6                   mov rdx, rsi
000c9d27  b960010000               mov ecx, 0x160
000c9d2c  e83f7ff4ff               call 0x11c70
000c9d31  48894558                 mov qword ptr [rbp + 0x58], rax
000c9d35  4885c0                   test rax, rax
000c9d38  740d                     je 0xc9d47
000c9d3a  488bc8                   mov rcx, rax
000c9d3d  e85eff0100               call 0xe9ca0
000c9d42  488bf8                   mov rdi, rax
000c9d45  eb03                     jmp 0xc9d4a
000c9d47  498bfd                   mov rdi, r13
000c9d4a  e9adfdffff               jmp 0xc9afc
000c9d4f  488bd6                   mov rdx, rsi
000c9d52  b9d0000000               mov ecx, 0xd0
000c9d57  e8147ff4ff               call 0x11c70
000c9d5c  488bd8                   mov rbx, rax
000c9d5f  48894558                 mov qword ptr [rbp + 0x58], rax
000c9d63  4885c0                   test rax, rax
000c9d66  0f8485000000             je 0xc9df1
000c9d6c  c7400801000000           mov dword ptr [rax + 8], 1
000c9d73  488d058ed41700           lea rax, [rip + 0x17d48e]
000c9d7a  488903                   mov qword ptr [rbx], rax
000c9d7d  48c7431000200000         mov qword ptr [rbx + 0x10], 0x2000
000c9d85  44896b18                 mov dword ptr [rbx + 0x18], r13d
000c9d89  4c896b20                 mov qword ptr [rbx + 0x20], r13
000c9d8d  44896b28                 mov dword ptr [rbx + 0x28], r13d
000c9d91  4c896b30                 mov qword ptr [rbx + 0x30], r13
000c9d95  4c896b38                 mov qword ptr [rbx + 0x38], r13
000c9d99  4c896b40                 mov qword ptr [rbx + 0x40], r13
000c9d9d  4c896b48                 mov qword ptr [rbx + 0x48], r13
000c9da1  488d0578481800           lea rax, [rip + 0x184878]
000c9da8  488903                   mov qword ptr [rbx], rax
000c9dab  488d4368                 lea rax, [rbx + 0x68]
000c9daf  48894008                 mov qword ptr [rax + 8], rax
000c9db3  488900                   mov qword ptr [rax], rax
000c9db6  488d05ebff1700           lea rax, [rip + 0x17ffeb]
000c9dbd  488903                   mov qword ptr [rbx], rax
000c9dc0  4c89ab80000000           mov qword ptr [rbx + 0x80], r13
000c9dc7  0f57c0                   xorps xmm0, xmm0
000c9dca  33c0                     xor eax, eax
000c9dcc  0f118388000000           movups xmmword ptr [rbx + 0x88], xmm0
000c9dd3  0f118398000000           movups xmmword ptr [rbx + 0x98], xmm0
000c9dda  0f1183a8000000           movups xmmword ptr [rbx + 0xa8], xmm0
000c9de1  0f1183b8000000           movups xmmword ptr [rbx + 0xb8], xmm0
000c9de8  488983c8000000           mov qword ptr [rbx + 0xc8], rax
000c9def  eb03                     jmp 0xc9df4
000c9df1  498bdd                   mov rbx, r13
000c9df4  e9a00a0000               jmp 0xca899
000c9df9  488bd6                   mov rdx, rsi
000c9dfc  b9d8000000               mov ecx, 0xd8
000c9e01  e86a7ef4ff               call 0x11c70
000c9e06  48894558                 mov qword ptr [rbp + 0x58], rax
000c9e0a  4885c0                   test rax, rax
000c9e0d  740d                     je 0xc9e1c
000c9e0f  488bc8                   mov rcx, rax
000c9e12  e819350200               call 0xed330
000c9e17  488bf8                   mov rdi, rax
000c9e1a  eb03                     jmp 0xc9e1f
000c9e1c  498bfd                   mov rdi, r13
000c9e1f  e9d8fcffff               jmp 0xc9afc
000c9e24  488bd6                   mov rdx, rsi
000c9e27  b928050000               mov ecx, 0x528
000c9e2c  e83f7ef4ff               call 0x11c70
000c9e31  48894558                 mov qword ptr [rbp + 0x58], rax
000c9e35  4885c0                   test rax, rax
000c9e38  740d                     je 0xc9e47
000c9e3a  488bc8                   mov rcx, rax
000c9e3d  e89edc0100               call 0xe7ae0
000c9e42  488bd8                   mov rbx, rax
000c9e45  eb03                     jmp 0xc9e4a
000c9e47  498bdd                   mov rbx, r13
000c9e4a  4c89ab80000000           mov qword ptr [rbx + 0x80], r13
000c9e51  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000c9e5b  4489b38c000000           mov dword ptr [rbx + 0x8c], r14d
000c9e62  4c89ab38040000           mov qword ptr [rbx + 0x438], r13
000c9e69  e9a7fbffff               jmp 0xc9a15
000c9e6e  488bd6                   mov rdx, rsi
000c9e71  b930050000               mov ecx, 0x530
000c9e76  e8f57df4ff               call 0x11c70
000c9e7b  48894558                 mov qword ptr [rbp + 0x58], rax
000c9e7f  4885c0                   test rax, rax
000c9e82  740d                     je 0xc9e91
000c9e84  488bc8                   mov rcx, rax
000c9e87  e804210200               call 0xebf90
000c9e8c  488bd8                   mov rbx, rax
000c9e8f  eb03                     jmp 0xc9e94
000c9e91  498bdd                   mov rbx, r13
000c9e94  488b8590000000           mov rax, qword ptr [rbp + 0x90]
000c9e9b  0f1008                   movups xmm1, xmmword ptr [rax]
000c9e9e  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000c9ea2  0f104010                 movups xmm0, xmmword ptr [rax + 0x10]
000c9ea6  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000c9eaa  66480f7eca               movq rdx, xmm1
000c9eaf  48c1ea20                 shr rdx, 0x20
000c9eb3  f6c201                   test dl, 1
000c9eb6  7592                     jne 0xc9e4a
000c9eb8  81e22ffbffff             and edx, 0xfffffb2f
000c9ebe  81ca20020000             or edx, 0x220
000c9ec4  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000c9ec8  48c1e820                 shr rax, 0x20
000c9ecc  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000c9ed0  498bc8                   mov rcx, r8
000c9ed3  48c1e920                 shr rcx, 0x20
000c9ed7  49c1e810                 shr r8, 0x10
000c9edb  89442438                 mov dword ptr [rsp + 0x38], eax
000c9edf  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000c9ee2  89442430                 mov dword ptr [rsp + 0x30], eax
000c9ee6  894c2428                 mov dword ptr [rsp + 0x28], ecx
000c9eea  664489442420             mov word ptr [rsp + 0x20], r8w
000c9ef0  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000c9ef5  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000c9ef9  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000c9efc  e80f76f4ff               call 0x11510
000c9f01  48898350040000           mov qword ptr [rbx + 0x450], rax
000c9f08  4885c0                   test rax, rax
000c9f0b  0f95c0                   setne al
000c9f0e  84c0                     test al, al
000c9f10  0f8534ffffff             jne 0xc9e4a
000c9f16  498bdd                   mov rbx, r13
000c9f19  e9a3090000               jmp 0xca8c1
000c9f1e  488bd6                   mov rdx, rsi
000c9f21  b9a0040000               mov ecx, 0x4a0
000c9f26  e8457df4ff               call 0x11c70
000c9f2b  48894558                 mov qword ptr [rbp + 0x58], rax
000c9f2f  4885c0                   test rax, rax
000c9f32  740d                     je 0xc9f41
000c9f34  488bc8                   mov rcx, rax
000c9f37  e8b4340200               call 0xed3f0
000c9f3c  488bd8                   mov rbx, rax
000c9f3f  eb03                     jmp 0xc9f44
000c9f41  498bdd                   mov rbx, r13
000c9f44  e964faffff               jmp 0xc99ad
000c9f49  488bd6                   mov rdx, rsi
000c9f4c  b9a8040000               mov ecx, 0x4a8
000c9f51  e81a7df4ff               call 0x11c70
000c9f56  48894558                 mov qword ptr [rbp + 0x58], rax
000c9f5a  4885c0                   test rax, rax
000c9f5d  740d                     je 0xc9f6c
000c9f5f  488bc8                   mov rcx, rax
000c9f62  e849350200               call 0xed4b0
000c9f67  488bd8                   mov rbx, rax
000c9f6a  eb03                     jmp 0xc9f6f
000c9f6c  498bdd                   mov rbx, r13
000c9f6f  e9b1fcffff               jmp 0xc9c25
000c9f74  488bd6                   mov rdx, rsi
000c9f77  b9a8010000               mov ecx, 0x1a8
000c9f7c  e8ef7cf4ff               call 0x11c70
000c9f81  48894558                 mov qword ptr [rbp + 0x58], rax
000c9f85  4885c0                   test rax, rax
000c9f88  740d                     je 0xc9f97
000c9f8a  488bc8                   mov rcx, rax
000c9f8d  e8ee350200               call 0xed580
000c9f92  488bd8                   mov rbx, rax
000c9f95  eb03                     jmp 0xc9f9a
000c9f97  498bdd                   mov rbx, r13
000c9f9a  e9fa080000               jmp 0xca899
000c9f9f  488bd6                   mov rdx, rsi
000c9fa2  b9b0010000               mov ecx, 0x1b0
000c9fa7  e8c47cf4ff               call 0x11c70
000c9fac  48894558                 mov qword ptr [rbp + 0x58], rax
000c9fb0  4885c0                   test rax, rax
000c9fb3  740d                     je 0xc9fc2
000c9fb5  488bc8                   mov rcx, rax
000c9fb8  e833360200               call 0xed5f0
000c9fbd  488bf8                   mov rdi, rax
000c9fc0  eb03                     jmp 0xc9fc5
000c9fc2  498bfd                   mov rdi, r13
000c9fc5  e932fbffff               jmp 0xc9afc
000c9fca  488bd6                   mov rdx, rsi
000c9fcd  b978050000               mov ecx, 0x578
000c9fd2  e8997cf4ff               call 0x11c70
000c9fd7  48894558                 mov qword ptr [rbp + 0x58], rax
000c9fdb  4885c0                   test rax, rax
000c9fde  740d                     je 0xc9fed
000c9fe0  488bc8                   mov rcx, rax
000c9fe3  e878360200               call 0xed660
000c9fe8  488bd8                   mov rbx, rax
000c9feb  eb03                     jmp 0xc9ff0
000c9fed  498bdd                   mov rbx, r13
000c9ff0  e955feffff               jmp 0xc9e4a
000c9ff5  488bd6                   mov rdx, rsi
000c9ff8  b980050000               mov ecx, 0x580
000c9ffd  e86e7cf4ff               call 0x11c70
000ca002  48894558                 mov qword ptr [rbp + 0x58], rax
000ca006  4885c0                   test rax, rax
000ca009  740d                     je 0xca018
000ca00b  488bc8                   mov rcx, rax
000ca00e  e8bd360200               call 0xed6d0
000ca013  488bd8                   mov rbx, rax
000ca016  eb03                     jmp 0xca01b
000ca018  498bdd                   mov rbx, r13
000ca01b  e974feffff               jmp 0xc9e94
000ca020  488bd6                   mov rdx, rsi
000ca023  b920020000               mov ecx, 0x220
000ca028  e8437cf4ff               call 0x11c70
000ca02d  48894558                 mov qword ptr [rbp + 0x58], rax
000ca031  4885c0                   test rax, rax
000ca034  740d                     je 0xca043
000ca036  488bc8                   mov rcx, rax
000ca039  e8c2380000               call 0xcd900
000ca03e  488bd8                   mov rbx, rax
000ca041  eb03                     jmp 0xca046
000ca043  498bdd                   mov rbx, r13
000ca046  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000ca04d  418b4504                 mov eax, dword ptr [r13 + 4]
000ca051  2573020000               and eax, 0x273
000ca056  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000ca05d  83f802                   cmp eax, 2
000ca060  7527                     jne 0xca089
000ca062  803d876f250000           cmp byte ptr [rip + 0x256f87], 0
000ca069  741e                     je 0xca089
000ca06b  8b057baa2400             mov eax, dword ptr [rip + 0x24aa7b]
000ca071  83f801                   cmp eax, 1
000ca074  7613                     jbe 0xca089
000ca076  c7837801000001000000     mov dword ptr [rbx + 0x178], 1
000ca080  448b3d65aa2400           mov r15d, dword ptr [rip + 0x24aa65]
000ca087  eb15                     jmp 0xca09e
000ca089  c7837801000000000000     mov dword ptr [rbx + 0x178], 0
000ca093  418bcc                   mov ecx, r12d
000ca096  e855570700               call 0x13f7f0
000ca09b  448bf8                   mov r15d, eax
000ca09e  418bc7                   mov eax, r15d
000ca0a1  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca0a9  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca0ad  48c7835801000000000000   mov qword ptr [rbx + 0x158], 0
000ca0b8  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca0bc  0f879a000000             ja 0xca15c
000ca0c2  0faee8                   lfence
000ca0c5  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca0c9  48c1e00d                 shl rax, 0xd
000ca0cd  4881faa01f0000           cmp rdx, 0x1fa0
000ca0d4  762d                     jbe 0xca103
000ca0d6  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000ca0db  4c8bca                   mov r9, rdx
000ca0de  4c8bc2                   mov r8, rdx
000ca0e1  498bce                   mov rcx, r14
000ca0e4  e8c7e6f3ff               call 0x87b0
000ca0e9  66ff4614                 inc word ptr [rsi + 0x14]
000ca0ed  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca0f1  48c1e00d                 shl rax, 0xd
000ca0f5  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca0fa  8b4808                   mov ecx, dword ptr [rax + 8]
000ca0fd  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca101  eb4e                     jmp 0xca151
000ca103  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000ca108  418b4608                 mov eax, dword ptr [r14 + 8]
000ca10c  483bc2                   cmp rax, rdx
000ca10f  730d                     jae 0xca11e
000ca111  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000ca115  418b4608                 mov eax, dword ptr [r14 + 8]
000ca119  483bc2                   cmp rax, rdx
000ca11c  72f3                     jb 0xca111
000ca11e  418b7e08                 mov edi, dword ptr [r14 + 8]
000ca122  4c8bca                   mov r9, rdx
000ca125  41b820000000             mov r8d, 0x20
000ca12b  498bce                   mov rcx, r14
000ca12e  e87de6f3ff               call 0x87b0
000ca133  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca137  7514                     jne 0xca14d
000ca139  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca13d  48c1e00d                 shl rax, 0xd
000ca141  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca146  8b4808                   mov ecx, dword ptr [rax + 8]
000ca149  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca14d  66ff4614                 inc word ptr [rsi + 0x14]
000ca151  498d4610                 lea rax, [r14 + 0x10]
000ca155  48898358010000           mov qword ptr [rbx + 0x158], rax
000ca15c  4c896c2420               mov qword ptr [rsp + 0x20], r13
000ca161  458bcf                   mov r9d, r15d
000ca164  458bc4                   mov r8d, r12d
000ca167  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000ca16e  488bcb                   mov rcx, rbx
000ca171  e80a730700               call 0x141480
000ca176  85c0                     test eax, eax
000ca178  0f8514070000             jne 0xca892
000ca17e  33db                     xor ebx, ebx
000ca180  e93c070000               jmp 0xca8c1
000ca185  488bd6                   mov rdx, rsi
000ca188  b928020000               mov ecx, 0x228
000ca18d  e8de7af4ff               call 0x11c70
000ca192  48894558                 mov qword ptr [rbp + 0x58], rax
000ca196  4885c0                   test rax, rax
000ca199  740d                     je 0xca1a8
000ca19b  488bc8                   mov rcx, rax
000ca19e  e8dd370000               call 0xcd980
000ca1a3  488bd8                   mov rbx, rax
000ca1a6  eb03                     jmp 0xca1ab
000ca1a8  498bdd                   mov rbx, r13
000ca1ab  4c8bbd90000000           mov r15, qword ptr [rbp + 0x90]
000ca1b2  418b4704                 mov eax, dword ptr [r15 + 4]
000ca1b6  2573020000               and eax, 0x273
000ca1bb  448bad88000000           mov r13d, dword ptr [rbp + 0x88]
000ca1c2  83f802                   cmp eax, 2
000ca1c5  7527                     jne 0xca1ee
000ca1c7  803d226e250000           cmp byte ptr [rip + 0x256e22], 0
000ca1ce  741e                     je 0xca1ee
000ca1d0  8b0516a92400             mov eax, dword ptr [rip + 0x24a916]
000ca1d6  83f801                   cmp eax, 1
000ca1d9  7613                     jbe 0xca1ee
000ca1db  c7838001000001000000     mov dword ptr [rbx + 0x180], 1
000ca1e5  448b2500a92400           mov r12d, dword ptr [rip + 0x24a900]
000ca1ec  eb15                     jmp 0xca203
000ca1ee  c7838001000000000000     mov dword ptr [rbx + 0x180], 0
000ca1f8  418bcd                   mov ecx, r13d
000ca1fb  e8f0550700               call 0x13f7f0
000ca200  448be0                   mov r12d, eax
000ca203  418bc4                   mov eax, r12d
000ca206  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca20e  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca212  48c7836001000000000000   mov qword ptr [rbx + 0x160], 0
000ca21d  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca221  0f87a4000000             ja 0xca2cb
000ca227  0faee8                   lfence
000ca22a  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca22e  48c1e00d                 shl rax, 0xd
000ca232  4881faa01f0000           cmp rdx, 0x1fa0
000ca239  762d                     jbe 0xca268
000ca23b  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000ca240  4c8bca                   mov r9, rdx
000ca243  4c8bc2                   mov r8, rdx
000ca246  498bce                   mov rcx, r14
000ca249  e862e5f3ff               call 0x87b0
000ca24e  66ff4614                 inc word ptr [rsi + 0x14]
000ca252  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca256  48c1e00d                 shl rax, 0xd
000ca25a  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca25f  8b4808                   mov ecx, dword ptr [rax + 8]
000ca262  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca266  eb58                     jmp 0xca2c0
000ca268  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000ca26d  418b4608                 mov eax, dword ptr [r14 + 8]
000ca271  483bc2                   cmp rax, rdx
000ca274  7317                     jae 0xca28d
000ca276  660f1f0400               nop word ptr [rax + rax]
000ca27b  0f1f440000               nop dword ptr [rax + rax]
000ca280  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000ca284  418b4608                 mov eax, dword ptr [r14 + 8]
000ca288  483bc2                   cmp rax, rdx
000ca28b  72f3                     jb 0xca280
000ca28d  418b7e08                 mov edi, dword ptr [r14 + 8]
000ca291  4c8bca                   mov r9, rdx
000ca294  41b820000000             mov r8d, 0x20
000ca29a  498bce                   mov rcx, r14
000ca29d  e80ee5f3ff               call 0x87b0
000ca2a2  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca2a6  7514                     jne 0xca2bc
000ca2a8  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca2ac  48c1e00d                 shl rax, 0xd
000ca2b0  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca2b5  8b4808                   mov ecx, dword ptr [rax + 8]
000ca2b8  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca2bc  66ff4614                 inc word ptr [rsi + 0x14]
000ca2c0  498d4610                 lea rax, [r14 + 0x10]
000ca2c4  48898360010000           mov qword ptr [rbx + 0x160], rax
000ca2cb  4c897c2420               mov qword ptr [rsp + 0x20], r15
000ca2d0  458bcc                   mov r9d, r12d
000ca2d3  458bc5                   mov r8d, r13d
000ca2d6  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000ca2dd  488bcb                   mov rcx, rbx
000ca2e0  e8fb790700               call 0x141ce0
000ca2e5  85c0                     test eax, eax
000ca2e7  0f8491feffff             je 0xca17e
000ca2ed  410f100f                 movups xmm1, xmmword ptr [r15]
000ca2f1  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000ca2f5  410f104710               movups xmm0, xmmword ptr [r15 + 0x10]
000ca2fa  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000ca2fe  66480f7eca               movq rdx, xmm1
000ca303  48c1ea20                 shr rdx, 0x20
000ca307  f6c201                   test dl, 1
000ca30a  0f8582050000             jne 0xca892
000ca310  81e22ffbffff             and edx, 0xfffffb2f
000ca316  81ca20020000             or edx, 0x220
000ca31c  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000ca320  48c1e820                 shr rax, 0x20
000ca324  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000ca328  498bc8                   mov rcx, r8
000ca32b  48c1e920                 shr rcx, 0x20
000ca32f  49c1e810                 shr r8, 0x10
000ca333  89442438                 mov dword ptr [rsp + 0x38], eax
000ca337  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000ca33a  89442430                 mov dword ptr [rsp + 0x30], eax
000ca33e  894c2428                 mov dword ptr [rsp + 0x28], ecx
000ca342  664489442420             mov word ptr [rsp + 0x20], r8w
000ca348  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000ca34d  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000ca351  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000ca354  e8b771f4ff               call 0x11510
000ca359  48898380000000           mov qword ptr [rbx + 0x80], rax
000ca360  4885c0                   test rax, rax
000ca363  0f95c0                   setne al
000ca366  84c0                     test al, al
000ca368  0f8524050000             jne 0xca892
000ca36e  33db                     xor ebx, ebx
000ca370  e94c050000               jmp 0xca8c1
000ca375  488bd6                   mov rdx, rsi
000ca378  b9f0050000               mov ecx, 0x5f0
000ca37d  e8ee78f4ff               call 0x11c70
000ca382  48894560                 mov qword ptr [rbp + 0x60], rax
000ca386  4885c0                   test rax, rax
000ca389  740d                     je 0xca398
000ca38b  488bc8                   mov rcx, rax
000ca38e  e86d360000               call 0xcda00
000ca393  488bd8                   mov rbx, rax
000ca396  eb03                     jmp 0xca39b
000ca398  498bdd                   mov rbx, r13
000ca39b  488bbd90000000           mov rdi, qword ptr [rbp + 0x90]
000ca3a2  8b4704                   mov eax, dword ptr [rdi + 4]
000ca3a5  2573020000               and eax, 0x273
000ca3aa  448bad88000000           mov r13d, dword ptr [rbp + 0x88]
000ca3b1  83f802                   cmp eax, 2
000ca3b4  7527                     jne 0xca3dd
000ca3b6  803d336c250000           cmp byte ptr [rip + 0x256c33], 0
000ca3bd  741e                     je 0xca3dd
000ca3bf  8b0527a72400             mov eax, dword ptr [rip + 0x24a727]
000ca3c5  83f801                   cmp eax, 1
000ca3c8  7613                     jbe 0xca3dd
000ca3ca  c7834805000001000000     mov dword ptr [rbx + 0x548], 1
000ca3d4  448b2511a72400           mov r12d, dword ptr [rip + 0x24a711]
000ca3db  eb15                     jmp 0xca3f2
000ca3dd  c7834805000000000000     mov dword ptr [rbx + 0x548], 0
000ca3e7  418bcd                   mov ecx, r13d
000ca3ea  e801540700               call 0x13f7f0
000ca3ef  448be0                   mov r12d, eax
000ca3f2  418bc4                   mov eax, r12d
000ca3f5  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca3fd  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca401  48c7832805000000000000   mov qword ptr [rbx + 0x528], 0
000ca40c  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca410  0f87b0000000             ja 0xca4c6
000ca416  0faee8                   lfence
000ca419  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca41d  48c1e00d                 shl rax, 0xd
000ca421  4881faa01f0000           cmp rdx, 0x1fa0
000ca428  762d                     jbe 0xca457
000ca42a  4c8b7c30f0               mov r15, qword ptr [rax + rsi - 0x10]
000ca42f  4c8bca                   mov r9, rdx
000ca432  4c8bc2                   mov r8, rdx
000ca435  498bcf                   mov rcx, r15
000ca438  e873e3f3ff               call 0x87b0
000ca43d  66ff4614                 inc word ptr [rsi + 0x14]
000ca441  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca445  48c1e00d                 shl rax, 0xd
000ca449  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca44e  8b4808                   mov ecx, dword ptr [rax + 8]
000ca451  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca455  eb60                     jmp 0xca4b7
000ca457  4c8b7c30f8               mov r15, qword ptr [rax + rsi - 8]
000ca45c  418b4708                 mov eax, dword ptr [r15 + 8]
000ca460  483bc2                   cmp rax, rdx
000ca463  7318                     jae 0xca47d
000ca465  660f1f0400               nop word ptr [rax + rax]
000ca46a  660f1f440000             nop word ptr [rax + rax]
000ca470  4d8b7f18                 mov r15, qword ptr [r15 + 0x18]
000ca474  418b4708                 mov eax, dword ptr [r15 + 8]
000ca478  483bc2                   cmp rax, rdx
000ca47b  72f3                     jb 0xca470
000ca47d  418b7f08                 mov edi, dword ptr [r15 + 8]
000ca481  4c8bca                   mov r9, rdx
000ca484  41b820000000             mov r8d, 0x20
000ca48a  498bcf                   mov rcx, r15
000ca48d  e81ee3f3ff               call 0x87b0
000ca492  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca496  7514                     jne 0xca4ac
000ca498  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca49c  48c1e00d                 shl rax, 0xd
000ca4a0  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca4a5  8b4808                   mov ecx, dword ptr [rax + 8]
000ca4a8  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca4ac  66ff4614                 inc word ptr [rsi + 0x14]
000ca4b0  488bbd90000000           mov rdi, qword ptr [rbp + 0x90]
000ca4b7  498d4710                 lea rax, [r15 + 0x10]
000ca4bb  48898328050000           mov qword ptr [rbx + 0x528], rax
000ca4c2  4c8b7d58                 mov r15, qword ptr [rbp + 0x58]
000ca4c6  48897c2420               mov qword ptr [rsp + 0x20], rdi
000ca4cb  458bcc                   mov r9d, r12d
000ca4ce  458bc5                   mov r8d, r13d
000ca4d1  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000ca4d8  488bcb                   mov rcx, rbx
000ca4db  e8d0730700               call 0x1418b0
000ca4e0  85c0                     test eax, eax
000ca4e2  0f8496fcffff             je 0xca17e
000ca4e8  4533ed                   xor r13d, r13d
000ca4eb  4c89ab80000000           mov qword ptr [rbx + 0x80], r13
000ca4f2  c7838800000001000000     mov dword ptr [rbx + 0x88], 1
000ca4fc  4489b38c000000           mov dword ptr [rbx + 0x8c], r14d
000ca503  4c89ab38040000           mov qword ptr [rbx + 0x438], r13
000ca50a  4489ab40040000           mov dword ptr [rbx + 0x440], r13d
000ca511  4c89ab48040000           mov qword ptr [rbx + 0x448], r13
000ca518  488d8b90000000           lea rcx, [rbx + 0x90]
000ca51f  4c8bcb                   mov r9, rbx
000ca522  458bc6                   mov r8d, r14d
000ca525  498bd7                   mov rdx, r15
000ca528  e883de0900               call 0x1683b0
000ca52d  e963030000               jmp 0xca895
000ca532  488bd6                   mov rdx, rsi
000ca535  b9f8050000               mov ecx, 0x5f8
000ca53a  e83177f4ff               call 0x11c70
000ca53f  48894560                 mov qword ptr [rbp + 0x60], rax
000ca543  4885c0                   test rax, rax
000ca546  740d                     je 0xca555
000ca548  488bc8                   mov rcx, rax
000ca54b  e830350000               call 0xcda80
000ca550  488bd8                   mov rbx, rax
000ca553  eb03                     jmp 0xca558
000ca555  498bdd                   mov rbx, r13
000ca558  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000ca55f  418b4504                 mov eax, dword ptr [r13 + 4]
000ca563  2573020000               and eax, 0x273
000ca568  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000ca56e  83f802                   cmp eax, 2
000ca571  7527                     jne 0xca59a
000ca573  803d766a250000           cmp byte ptr [rip + 0x256a76], 0
000ca57a  741e                     je 0xca59a
000ca57c  8b056aa52400             mov eax, dword ptr [rip + 0x24a56a]
000ca582  83f801                   cmp eax, 1
000ca585  7613                     jbe 0xca59a
000ca587  c7835005000001000000     mov dword ptr [rbx + 0x550], 1
000ca591  448b2554a52400           mov r12d, dword ptr [rip + 0x24a554]
000ca598  eb14                     jmp 0xca5ae
000ca59a  c7835005000000000000     mov dword ptr [rbx + 0x550], 0
000ca5a4  8bcf                     mov ecx, edi
000ca5a6  e845520700               call 0x13f7f0
000ca5ab  448be0                   mov r12d, eax
000ca5ae  418bc4                   mov eax, r12d
000ca5b1  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca5b9  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca5bd  48c7833005000000000000   mov qword ptr [rbx + 0x530], 0
000ca5c8  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca5cc  0f87a4000000             ja 0xca676
000ca5d2  0faee8                   lfence
000ca5d5  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca5d9  48c1e00d                 shl rax, 0xd
000ca5dd  4881faa01f0000           cmp rdx, 0x1fa0
000ca5e4  762d                     jbe 0xca613
000ca5e6  4c8b7c30f0               mov r15, qword ptr [rax + rsi - 0x10]
000ca5eb  4c8bca                   mov r9, rdx
000ca5ee  4c8bc2                   mov r8, rdx
000ca5f1  498bcf                   mov rcx, r15
000ca5f4  e8b7e1f3ff               call 0x87b0
000ca5f9  66ff4614                 inc word ptr [rsi + 0x14]
000ca5fd  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca601  48c1e00d                 shl rax, 0xd
000ca605  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca60a  8b4808                   mov ecx, dword ptr [rax + 8]
000ca60d  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca611  eb54                     jmp 0xca667
000ca613  4c8b7c30f8               mov r15, qword ptr [rax + rsi - 8]
000ca618  418b4708                 mov eax, dword ptr [r15 + 8]
000ca61c  483bc2                   cmp rax, rdx
000ca61f  730d                     jae 0xca62e
000ca621  4d8b7f18                 mov r15, qword ptr [r15 + 0x18]
000ca625  418b4708                 mov eax, dword ptr [r15 + 8]
000ca629  483bc2                   cmp rax, rdx
000ca62c  72f3                     jb 0xca621
000ca62e  418b7f08                 mov edi, dword ptr [r15 + 8]
000ca632  4c8bca                   mov r9, rdx
000ca635  41b820000000             mov r8d, 0x20
000ca63b  498bcf                   mov rcx, r15
000ca63e  e86de1f3ff               call 0x87b0
000ca643  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca647  7514                     jne 0xca65d
000ca649  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca64d  48c1e00d                 shl rax, 0xd
000ca651  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca656  8b4808                   mov ecx, dword ptr [rax + 8]
000ca659  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca65d  66ff4614                 inc word ptr [rsi + 0x14]
000ca661  8bbd88000000             mov edi, dword ptr [rbp + 0x88]
000ca667  498d4710                 lea rax, [r15 + 0x10]
000ca66b  48898330050000           mov qword ptr [rbx + 0x530], rax
000ca672  4c8b7d58                 mov r15, qword ptr [rbp + 0x58]
000ca676  4c896c2420               mov qword ptr [rsp + 0x20], r13
000ca67b  458bcc                   mov r9d, r12d
000ca67e  448bc7                   mov r8d, edi
000ca681  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
000ca688  488bcb                   mov rcx, rbx
000ca68b  e8807a0700               call 0x142110
000ca690  85c0                     test eax, eax
000ca692  0f84e6faffff             je 0xca17e
000ca698  410f104d00               movups xmm1, xmmword ptr [r13]
000ca69d  0f114dd8                 movups xmmword ptr [rbp - 0x28], xmm1
000ca6a1  410f104510               movups xmm0, xmmword ptr [r13 + 0x10]
000ca6a6  0f1145e8                 movups xmmword ptr [rbp - 0x18], xmm0
000ca6aa  66480f7eca               movq rdx, xmm1
000ca6af  48c1ea20                 shr rdx, 0x20
000ca6b3  f6c201                   test dl, 1
000ca6b6  0f852cfeffff             jne 0xca4e8
000ca6bc  81e22ffbffff             and edx, 0xfffffb2f
000ca6c2  81ca20020000             or edx, 0x220
000ca6c8  488b45f0                 mov rax, qword ptr [rbp - 0x10]
000ca6cc  48c1e820                 shr rax, 0x20
000ca6d0  4c8b45e8                 mov r8, qword ptr [rbp - 0x18]
000ca6d4  498bc8                   mov rcx, r8
000ca6d7  48c1e920                 shr rcx, 0x20
000ca6db  49c1e810                 shr r8, 0x10
000ca6df  89442438                 mov dword ptr [rsp + 0x38], eax
000ca6e3  8b45f0                   mov eax, dword ptr [rbp - 0x10]
000ca6e6  89442430                 mov dword ptr [rsp + 0x30], eax
000ca6ea  894c2428                 mov dword ptr [rsp + 0x28], ecx
000ca6ee  664489442420             mov word ptr [rsp + 0x20], r8w
000ca6f4  440fb74de8               movzx r9d, word ptr [rbp - 0x18]
000ca6f9  4c8b45e0                 mov r8, qword ptr [rbp - 0x20]
000ca6fd  8b4dd8                   mov ecx, dword ptr [rbp - 0x28]
000ca700  e80b6ef4ff               call 0x11510
000ca705  48898350040000           mov qword ptr [rbx + 0x450], rax
000ca70c  4885c0                   test rax, rax
000ca70f  0f95c0                   setne al
000ca712  84c0                     test al, al
000ca714  0f85cefdffff             jne 0xca4e8
000ca71a  33db                     xor ebx, ebx
000ca71c  e9a0010000               jmp 0xca8c1
000ca721  488bd6                   mov rdx, rsi
000ca724  b998020000               mov ecx, 0x298
000ca729  e84275f4ff               call 0x11c70
000ca72e  48894558                 mov qword ptr [rbp + 0x58], rax
000ca732  4885c0                   test rax, rax
000ca735  740d                     je 0xca744
000ca737  488bc8                   mov rcx, rax
000ca73a  e8c1330000               call 0xcdb00
000ca73f  488bd8                   mov rbx, rax
000ca742  eb03                     jmp 0xca747
000ca744  498bdd                   mov rbx, r13
000ca747  4c8bad90000000           mov r13, qword ptr [rbp + 0x90]
000ca74e  418b4504                 mov eax, dword ptr [r13 + 4]
000ca752  2573020000               and eax, 0x273
000ca757  448ba588000000           mov r12d, dword ptr [rbp + 0x88]
000ca75e  83f802                   cmp eax, 2
000ca761  7527                     jne 0xca78a
000ca763  803d8668250000           cmp byte ptr [rip + 0x256886], 0
000ca76a  741e                     je 0xca78a
000ca76c  8b057aa32400             mov eax, dword ptr [rip + 0x24a37a]
000ca772  83f801                   cmp eax, 1
000ca775  7613                     jbe 0xca78a
000ca777  c783f001000001000000     mov dword ptr [rbx + 0x1f0], 1
000ca781  448b3d64a32400           mov r15d, dword ptr [rip + 0x24a364]
000ca788  eb15                     jmp 0xca79f
000ca78a  c783f001000000000000     mov dword ptr [rbx + 0x1f0], 0
000ca794  418bcc                   mov ecx, r12d
000ca797  e854500700               call 0x13f7f0
000ca79c  448bf8                   mov r15d, eax
000ca79f  418bc7                   mov eax, r15d
000ca7a2  488d14c50f000000         lea rdx, [rax*8 + 0xf]
000ca7aa  4883e2f0                 and rdx, 0xfffffffffffffff0
000ca7ae  48c783d001000000000000   mov qword ptr [rbx + 0x1d0], 0
000ca7b9  483b5618                 cmp rdx, qword ptr [rsi + 0x18]
000ca7bd  0f879a000000             ja 0xca85d
000ca7c3  0faee8                   lfence
000ca7c6  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca7ca  48c1e00d                 shl rax, 0xd
000ca7ce  4881faa01f0000           cmp rdx, 0x1fa0
000ca7d5  762d                     jbe 0xca804
000ca7d7  4c8b7430f0               mov r14, qword ptr [rax + rsi - 0x10]
000ca7dc  4c8bca                   mov r9, rdx
000ca7df  4c8bc2                   mov r8, rdx
000ca7e2  498bce                   mov rcx, r14
000ca7e5  e8c6dff3ff               call 0x87b0
000ca7ea  66ff4614                 inc word ptr [rsi + 0x14]
000ca7ee  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca7f2  48c1e00d                 shl rax, 0xd
000ca7f6  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca7fb  8b4808                   mov ecx, dword ptr [rax + 8]
000ca7fe  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca802  eb4e                     jmp 0xca852
000ca804  4c8b7430f8               mov r14, qword ptr [rax + rsi - 8]
000ca809  418b4608                 mov eax, dword ptr [r14 + 8]
000ca80d  483bc2                   cmp rax, rdx
000ca810  730d                     jae 0xca81f
000ca812  4d8b7618                 mov r14, qword ptr [r14 + 0x18]
000ca816  418b4608                 mov eax, dword ptr [r14 + 8]
000ca81a  483bc2                   cmp rax, rdx
000ca81d  72f3                     jb 0xca812
000ca81f  418b7e08                 mov edi, dword ptr [r14 + 8]
000ca823  4c8bca                   mov r9, rdx
000ca826  41b820000000             mov r8d, 0x20
000ca82c  498bce                   mov rcx, r14
000ca82f  e87cdff3ff               call 0x87b0
000ca834  483b7e18                 cmp rdi, qword ptr [rsi + 0x18]
000ca838  7514                     jne 0xca84e
000ca83a  48634610                 movsxd rax, dword ptr [rsi + 0x10]
000ca83e  48c1e00d                 shl rax, 0xd
000ca842  488b4430f0               mov rax, qword ptr [rax + rsi - 0x10]
000ca847  8b4808                   mov ecx, dword ptr [rax + 8]
000ca84a  48894e18                 mov qword ptr [rsi + 0x18], rcx
000ca84e  66ff4614                 inc word ptr [rsi + 0x14]
000ca852  498d4610                 lea rax, [r14 + 0x10]
000ca856  488983d0010000           mov qword ptr [rbx + 0x1d0], rax
000ca85d  4c896c2420               mov qword ptr [rsp + 0x20], r13
000ca862  458bcf                   mov r9d, r15d
000ca865  458bc4                   mov r8d, r12d
000ca868  488bbd80000000           mov rdi, qword ptr [rbp + 0x80]
000ca86f  488bd7                   mov rdx, rdi
000ca872  488bcb                   mov rcx, rbx
000ca875  e8c67c0700               call 0x142540
000ca87a  85c0                     test eax, eax
000ca87c  0f84fcf8ffff             je 0xca17e
000ca882  440fb64744               movzx r8d, byte ptr [rdi + 0x44]
000ca887  498bd5                   mov rdx, r13
000ca88a  488bcb                   mov rcx, rbx
000ca88d  e8fe290200               call 0xed290
000ca892  4533ed                   xor r13d, r13d
000ca895  448b6578                 mov r12d, dword ptr [rbp + 0x78]
000ca899  4885db                   test rbx, rbx
000ca89c  7423                     je 0xca8c1
000ca89e  4c896b50                 mov qword ptr [rbx + 0x50], r13
000ca8a2  4c896b60                 mov qword ptr [rbx + 0x60], r13
000ca8a6  4c896b58                 mov qword ptr [rbx + 0x58], r13
000ca8aa  c7437801000000           mov dword ptr [rbx + 0x78], 1
000ca8b1  41c1ec17                 shr r12d, 0x17
000ca8b5  4183e401                 and r12d, 1
000ca8b9  4489637c                 mov dword ptr [rbx + 0x7c], r12d
000ca8bd  834b2802                 or dword ptr [rbx + 0x28], 2
000ca8c1  488bc3                   mov rax, rbx
000ca8c4  488b9c24b0000000         mov rbx, qword ptr [rsp + 0xb0]
000ca8cc  4883c470                 add rsp, 0x70
000ca8d0  415f                     pop r15
000ca8d2  415e                     pop r14
000ca8d4  415d                     pop r13
000ca8d6  415c                     pop r12
000ca8d8  5f                       pop rdi
000ca8d9  5e                       pop rsi
000ca8da  5d                       pop rbp
000ca8db  c3                       ret
000ca8dc  c0980c002d990c           rcr byte ptr [rax - 0x66d2fff4], 0xc
000ca8e3  00b39c0c0024             add byte ptr [rbx + 0x24000c9c], dh
000ca8e9  9e                       sahf
000ca8ea  0c00                     or al, 0
000ca8ec  4f9d                     popfq
000ca8ee  0c00                     or al, 0
