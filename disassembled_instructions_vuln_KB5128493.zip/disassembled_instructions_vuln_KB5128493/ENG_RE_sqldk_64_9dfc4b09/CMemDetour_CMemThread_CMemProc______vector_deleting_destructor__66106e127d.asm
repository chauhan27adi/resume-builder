; CMemDetour<CMemThread<CMemProc> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcdda0, 104 bytes in 1 chunk(s)

; chunk at RVA 0xcdda0 (104 bytes)
000cdda0  48894c2408               mov qword ptr [rsp + 8], rcx
000cdda5  57                       push rdi
000cdda6  4883ec30                 sub rsp, 0x30
000cddaa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cddb3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cddb8  8bda                     mov ebx, edx
000cddba  488bf9                   mov rdi, rcx
000cddbd  488d056c101800           lea rax, [rip + 0x18106c]
000cddc4  488901                   mov qword ptr [rcx], rax
000cddc7  488d81b8010000           lea rax, [rcx + 0x1b8]
000cddce  4889442450               mov qword ptr [rsp + 0x50], rax
000cddd3  488d0d66bd1600           lea rcx, [rip + 0x16bd66]
000cddda  488908                   mov qword ptr [rax], rcx
000cdddd  488bcf                   mov rcx, rdi
000cdde0  e8ab4e0000               call 0xd2c90
000cdde5  83e305                   and ebx, 5
000cdde8  80fb05                   cmp bl, 5
000cddeb  750d                     jne 0xcddfa
000cdded  baf0010000               mov edx, 0x1f0
000cddf2  488bcf                   mov rcx, rdi
000cddf5  e81632f3ff               call 0x1010
000cddfa  488bc7                   mov rax, rdi
000cddfd  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cde02  4883c430                 add rsp, 0x30
000cde06  5f                       pop rdi
000cde07  c3                       ret
