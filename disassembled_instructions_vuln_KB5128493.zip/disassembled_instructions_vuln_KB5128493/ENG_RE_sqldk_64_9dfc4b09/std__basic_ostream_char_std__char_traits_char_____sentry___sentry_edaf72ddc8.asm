; std::basic_ostream<char,std::char_traits<char> >::sentry::~sentry
; sqldk.dll, primary RVA 0x58150, 75 bytes in 1 chunk(s)

; chunk at RVA 0x58150 (75 bytes)
00058150  48894c2408               mov qword ptr [rsp + 8], rcx
00058155  53                       push rbx
00058156  4883ec30                 sub rsp, 0x30
0005815a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00058163  488bd9                   mov rbx, rcx
00058166  ff1514161e00             call qword ptr [rip + 0x1e1614]
0005816c  84c0                     test al, al
0005816e  750a                     jne 0x5817a
00058170  488b0b                   mov rcx, qword ptr [rbx]
00058173  ff1517161e00             call qword ptr [rip + 0x1e1617]
00058179  90                       nop
0005817a  488b13                   mov rdx, qword ptr [rbx]
0005817d  488b02                   mov rax, qword ptr [rdx]
00058180  48634804                 movsxd rcx, dword ptr [rax + 4]
00058184  488b4c1148               mov rcx, qword ptr [rcx + rdx + 0x48]
00058189  4885c9                   test rcx, rcx
0005818c  7407                     je 0x58195
0005818e  488b01                   mov rax, qword ptr [rcx]
00058191  ff5010                   call qword ptr [rax + 0x10]
00058194  90                       nop
00058195  4883c430                 add rsp, 0x30
00058199  5b                       pop rbx
0005819a  c3                       ret
