; `XE_LogWriter<XE_MetadataEncoder<XE_CompressionEncoder<XEPackage0::XE_LiveEncoder> > >::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x232210, 31 bytes in 1 chunk(s)

; chunk at RVA 0x232210 (31 bytes)
00232210  4055                     push rbp
00232212  4883ec20                 sub rsp, 0x20
00232216  488bea                   mov rbp, rdx
00232219  4533c0                   xor r8d, r8d
0023221c  488b5528                 mov rdx, qword ptr [rbp + 0x28]
00232220  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00232224  e8e7eddcff               call 0x1010
00232229  4883c420                 add rsp, 0x20
0023222d  5d                       pop rbp
0023222e  c3                       ret
