; CAutoP<XEPackage0::BucketizingTarget::Entry>::~CAutoP<XEPackage0::BucketizingTarget::Entry>
; sqldk.dll, primary RVA 0x1c7140, 61 bytes in 1 chunk(s)

; chunk at RVA 0x1c7140 (61 bytes)
001c7140  4053                     push rbx
001c7142  4883ec30                 sub rsp, 0x30
001c7146  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001c714f  488b19                   mov rbx, qword ptr [rcx]
001c7152  48895c2440               mov qword ptr [rsp + 0x40], rbx
001c7157  4885db                   test rbx, rbx
001c715a  741b                     je 0x1c7177
001c715c  488d4b10                 lea rcx, [rbx + 0x10]
001c7160  e85ba9e7ff               call 0x41ac0
001c7165  ba20000000               mov edx, 0x20
001c716a  488bcb                   mov rcx, rbx
001c716d  4883c430                 add rsp, 0x30
001c7171  5b                       pop rbx
001c7172  e9790ce4ff               jmp 0x7df0
001c7177  4883c430                 add rsp, 0x30
001c717b  5b                       pop rbx
001c717c  c3                       ret
