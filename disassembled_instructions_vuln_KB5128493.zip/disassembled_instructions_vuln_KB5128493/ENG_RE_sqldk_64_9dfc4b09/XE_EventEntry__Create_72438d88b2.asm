; XE_EventEntry::Create
; sqldk.dll, primary RVA 0x1f35d0, 948 bytes in 1 chunk(s)

; chunk at RVA 0x1f35d0 (948 bytes)
001f35d0  6644894c2420             mov word ptr [rsp + 0x20], r9w
001f35d6  48894c2408               mov qword ptr [rsp + 8], rcx
001f35db  53                       push rbx
001f35dc  55                       push rbp
001f35dd  56                       push rsi
001f35de  57                       push rdi
001f35df  4155                     push r13
001f35e1  4156                     push r14
001f35e3  4157                     push r15
001f35e5  4883ec60                 sub rsp, 0x60
001f35e9  48c7442458feffffff       mov qword ptr [rsp + 0x58], 0xfffffffffffffffe
001f35f2  498be8                   mov rbp, r8
001f35f5  4c8bfa                   mov r15, rdx
001f35f8  4c8bf1                   mov r14, rcx
001f35fb  33f6                     xor esi, esi
001f35fd  410fb74026               movzx eax, word ptr [r8 + 0x26]
001f3602  450fb75024               movzx r10d, word ptr [r8 + 0x24]
001f3607  442bd0                   sub r10d, eax
001f360a  440fb7ac24d0000000       movzx r13d, word ptr [rsp + 0xd0]
001f3613  418d4501                 lea eax, [r13 + 1]
001f3617  4103c2                   add eax, r10d
001f361a  c1e004                   shl eax, 4
001f361d  3d10020000               cmp eax, 0x210
001f3622  0f8720030000             ja 0x1f3948
001f3628  c78424b000000060000000   mov dword ptr [rsp + 0xb0], 0x60
001f3633  488b4908                 mov rcx, qword ptr [rcx + 8]
001f3637  488b01                   mov rax, qword ptr [rcx]
001f363a  c644242006               mov byte ptr [rsp + 0x20], 6
001f363f  448d4e60                 lea r9d, [rsi + 0x60]
001f3643  4c8d051e730b00           lea r8, [rip + 0xb731e]
001f364a  418d5148                 lea edx, [r9 + 0x48]
001f364e  ff5050                   call qword ptr [rax + 0x50]
001f3651  488bf8                   mov rdi, rax
001f3654  4889442450               mov qword ptr [rsp + 0x50], rax
001f3659  448d4e01                 lea r9d, [rsi + 1]
001f365d  4885c0                   test rax, rax
001f3660  7472                     je 0x1f36d4
001f3662  488930                   mov qword ptr [rax], rsi
001f3665  48897008                 mov qword ptr [rax + 8], rsi
001f3669  44894810                 mov dword ptr [rax + 0x10], r9d
001f366d  48897018                 mov qword ptr [rax + 0x18], rsi
001f3671  48897020                 mov qword ptr [rax + 0x20], rsi
001f3675  48897028                 mov qword ptr [rax + 0x28], rsi
001f3679  0f280540ca0800           movaps xmm0, xmmword ptr [rip + 0x8ca40]
001f3680  0f114030                 movups xmmword ptr [rax + 0x30], xmm0
001f3684  0f280d45ca0800           movaps xmm1, xmmword ptr [rip + 0x8ca45]
001f368b  0f114840                 movups xmmword ptr [rax + 0x40], xmm1
001f368f  0f28054aca0800           movaps xmm0, xmmword ptr [rip + 0x8ca4a]
001f3696  0f114050                 movups xmmword ptr [rax + 0x50], xmm0
001f369a  0f280d4fca0800           movaps xmm1, xmmword ptr [rip + 0x8ca4f]
001f36a1  0f114860                 movups xmmword ptr [rax + 0x60], xmm1
001f36a5  0f280554ca0800           movaps xmm0, xmmword ptr [rip + 0x8ca54]
001f36ac  0f114070                 movups xmmword ptr [rax + 0x70], xmm0
001f36b0  0f280d59ca0800           movaps xmm1, xmmword ptr [rip + 0x8ca59]
001f36b7  0f118880000000           movups xmmword ptr [rax + 0x80], xmm1
001f36be  4889b090000000           mov qword ptr [rax + 0x90], rsi
001f36c5  480598000000             add rax, 0x98
001f36cb  48894008                 mov qword ptr [rax + 8], rax
001f36cf  488900                   mov qword ptr [rax], rax
001f36d2  eb03                     jmp 0x1f36d7
001f36d4  488bfe                   mov rdi, rsi
001f36d7  488bdf                   mov rbx, rdi
001f36da  48895c2450               mov qword ptr [rsp + 0x50], rbx
001f36df  4885ff                   test rdi, rdi
001f36e2  0f841d020000             je 0x1f3905
001f36e8  4c8b1509d51300           mov r10, qword ptr [rip + 0x13d509]
001f36ef  0fb74504                 movzx eax, word ptr [rbp + 4]
001f36f3  b9ff030000               mov ecx, 0x3ff
001f36f8  6623c1                   and ax, cx
001f36fb  4c8bc6                   mov r8, rsi
001f36fe  0fb7c0                   movzx eax, ax
001f3701  4c69d890010000           imul r11, rax, 0x190
001f3708  498b9230010000           mov rdx, qword ptr [r10 + 0x130]
001f370f  4903d3                   add rdx, r11
001f3712  8b4228                   mov eax, dword ptr [rdx + 0x28]
001f3715  85c0                     test eax, eax
001f3717  7426                     je 0x1f373f
001f3719  0f1f00                   nop dword ptr [rax]
001f371c  0f1f4000                 nop dword ptr [rax]
001f3720  8d4801                   lea ecx, [rax + 1]
001f3723  f00fb14a28               lock cmpxchg dword ptr [rdx + 0x28], ecx
001f3728  740b                     je 0x1f3735
001f372a  f390                     pause
001f372c  8b4228                   mov eax, dword ptr [rdx + 0x28]
001f372f  85c0                     test eax, eax
001f3731  75ed                     jne 0x1f3720
001f3733  eb0a                     jmp 0x1f373f
001f3735  4d8b8230010000           mov r8, qword ptr [r10 + 0x130]
001f373c  4d03c3                   add r8, r11
001f373f  488b8790000000           mov rax, qword ptr [rdi + 0x90]
001f3746  4885c0                   test rax, rax
001f3749  7404                     je 0x1f374f
001f374b  f0ff4828                 lock dec dword ptr [rax + 0x28]
001f374f  4c898790000000           mov qword ptr [rdi + 0x90], r8
001f3756  4d85c0                   test r8, r8
001f3759  0f84a1010000             je 0x1f3900
001f375f  4c897f38                 mov qword ptr [rdi + 0x38], r15
001f3763  48896f60                 mov qword ptr [rdi + 0x60], rbp
001f3767  488b9c24c8000000         mov rbx, qword ptr [rsp + 0xc8]
001f376f  4885db                   test rbx, rbx
001f3772  0f849f000000             je 0x1f3817
001f3778  8bd3                     mov edx, ebx
001f377a  83e207                   and edx, 7
001f377d  83fa05                   cmp edx, 5
001f3780  0f877a010000             ja 0x1f3900
001f3786  4863c2                   movsxd rax, edx
001f3789  4c8d0570c8e0ff           lea r8, [rip - 0x1f3790]
001f3790  418b8c806c391f00         mov ecx, dword ptr [r8 + rax*4 + 0x1f396c]
001f3798  4903c8                   add rcx, r8
001f379b  ffe1                     jmp rcx
001f379d  488bcb                   mov rcx, rbx
001f37a0  4883e1f8                 and rcx, 0xfffffffffffffff8
001f37a4  488d4128                 lea rax, [rcx + 0x28]
001f37a8  eb31                     jmp 0x1f37db
001f37aa  488bcb                   mov rcx, rbx
001f37ad  4883e1f8                 and rcx, 0xfffffffffffffff8
001f37b1  488d4118                 lea rax, [rcx + 0x18]
001f37b5  eb24                     jmp 0x1f37db
001f37b7  488bcb                   mov rcx, rbx
001f37ba  4883e1f8                 and rcx, 0xfffffffffffffff8
001f37be  488bc1                   mov rax, rcx
001f37c1  eb18                     jmp 0x1f37db
001f37c3  488bcb                   mov rcx, rbx
001f37c6  4883e1f8                 and rcx, 0xfffffffffffffff8
001f37ca  488d4110                 lea rax, [rcx + 0x10]
001f37ce  eb0b                     jmp 0x1f37db
001f37d0  488bcb                   mov rcx, rbx
001f37d3  4883e1f8                 and rcx, 0xfffffffffffffff8
001f37d7  488d4108                 lea rax, [rcx + 8]
001f37db  f0440fc108               lock xadd dword ptr [rax], r9d
001f37e0  41ffc1                   inc r9d
001f37e3  4183f9ff                 cmp r9d, -1
001f37e7  0f8413010000             je 0x1f3900
001f37ed  83fa03                   cmp edx, 3
001f37f0  480f45ce                 cmovne rcx, rsi
001f37f4  89b424b0000000           mov dword ptr [rsp + 0xb0], esi
001f37fb  488b01                   mov rax, qword ptr [rcx]
001f37fe  4c8bcf                   mov r9, rdi
001f3801  4c8d8424b0000000         lea r8, [rsp + 0xb0]
001f3809  498bd6                   mov rdx, r14
001f380c  ff5018                   call qword ptr [rax + 0x18]
001f380f  85c0                     test eax, eax
001f3811  0f84e9000000             je 0x1f3900
001f3817  48895f48                 mov qword ptr [rdi + 0x48], rbx
001f381b  4889742448               mov qword ptr [rsp + 0x48], rsi
001f3820  4889742438               mov qword ptr [rsp + 0x38], rsi
001f3825  4889742430               mov qword ptr [rsp + 0x30], rsi
001f382a  488d442448               lea rax, [rsp + 0x48]
001f382f  4889442428               mov qword ptr [rsp + 0x28], rax
001f3834  488b8424c0000000         mov rax, qword ptr [rsp + 0xc0]
001f383c  4889442420               mov qword ptr [rsp + 0x20], rax
001f3841  440fb78c24b8000000       movzx r9d, word ptr [rsp + 0xb8]
001f384a  4c8bc5                   mov r8, rbp
001f384d  ba18000000               mov edx, 0x18
001f3852  498bce                   mov rcx, r14
001f3855  e8660a0000               call 0x1f42c0
001f385a  85c0                     test eax, eax
001f385c  744a                     je 0x1f38a8
001f385e  488b442448               mov rax, qword ptr [rsp + 0x48]
001f3863  488bd6                   mov rdx, rsi
001f3866  4889542448               mov qword ptr [rsp + 0x48], rdx
001f386b  48894740                 mov qword ptr [rdi + 0x40], rax
001f386f  66399424d0000000         cmp word ptr [rsp + 0xd0], dx
001f3877  7422                     je 0x1f389b
001f3879  0faee8                   lfence
001f387c  4c8b8c24d8000000         mov r9, qword ptr [rsp + 0xd8]
001f3884  458bc5                   mov r8d, r13d
001f3887  498bd6                   mov rdx, r14
001f388a  488bcf                   mov rcx, rdi
001f388d  e8fe000000               call 0x1f3990
001f3892  85c0                     test eax, eax
001f3894  7412                     je 0x1f38a8
001f3896  488b542448               mov rdx, qword ptr [rsp + 0x48]
001f389b  488bde                   mov rbx, rsi
001f389e  48895c2450               mov qword ptr [rsp + 0x50], rbx
001f38a3  488bf7                   mov rsi, rdi
001f38a6  eb0a                     jmp 0x1f38b2
001f38a8  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
001f38ad  488b542448               mov rdx, qword ptr [rsp + 0x48]
001f38b2  4885d2                   test rdx, rdx
001f38b5  744e                     je 0x1f3905
001f38b7  488bc2                   mov rax, rdx
001f38ba  41b800020000             mov r8d, 0x200
001f38c0  482500e0ffff             and rax, 0xffffffffffffe000
001f38c6  740b                     je 0x1f38d3
001f38c8  6644394004               cmp word ptr [rax + 4], r8w
001f38cd  7504                     jne 0x1f38d3
001f38cf  488b4028                 mov rax, qword ptr [rax + 0x28]
001f38d3  488b4008                 mov rax, qword ptr [rax + 8]
001f38d7  488b4810                 mov rcx, qword ptr [rax + 0x10]
001f38db  48f7d9                   neg rcx
001f38de  4823ca                   and rcx, rdx
001f38e1  740b                     je 0x1f38ee
001f38e3  6644394104               cmp word ptr [rcx + 4], r8w
001f38e8  7504                     jne 0x1f38ee
001f38ea  488b4928                 mov rcx, qword ptr [rcx + 0x28]
001f38ee  488b4908                 mov rcx, qword ptr [rcx + 8]
001f38f2  f6412808                 test byte ptr [rcx + 0x28], 8
001f38f6  750d                     jne 0x1f3905
001f38f8  488b01                   mov rax, qword ptr [rcx]
001f38fb  ff5028                   call qword ptr [rax + 0x28]
001f38fe  eb05                     jmp 0x1f3905
001f3900  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
001f3905  4885db                   test rbx, rbx
001f3908  744e                     je 0x1f3958
001f390a  b8ffffffff               mov eax, 0xffffffff
001f390f  f00fc14310               lock xadd dword ptr [rbx + 0x10], eax
001f3914  83f801                   cmp eax, 1
001f3917  753f                     jne 0x1f3958
001f3919  488b5c2450               mov rbx, qword ptr [rsp + 0x50]
001f391e  48837b0800               cmp qword ptr [rbx + 8], 0
001f3923  740c                     je 0x1f3931
001f3925  488bd3                   mov rdx, rbx
001f3928  488b4b18                 mov rcx, qword ptr [rbx + 0x18]
001f392c  e80f54ffff               call 0x1e8d40
001f3931  488bcb                   mov rcx, rbx
001f3934  e897020000               call 0x1f3bd0
001f3939  baa8000000               mov edx, 0xa8
001f393e  488bcb                   mov rcx, rbx
001f3941  e8aa44e1ff               call 0x7df0
001f3946  eb10                     jmp 0x1f3958
001f3948  ba18000000               mov edx, 0x18
001f394d  8d4a0f                   lea ecx, [rdx + 0xf]
001f3950  4533c0                   xor r8d, r8d
001f3953  e8a8d4feff               call 0x1e0e00
001f3958  488bc6                   mov rax, rsi
001f395b  4883c460                 add rsp, 0x60
001f395f  415f                     pop r15
001f3961  415e                     pop r14
001f3963  415d                     pop r13
001f3965  5f                       pop rdi
001f3966  5e                       pop rsi
001f3967  5d                       pop rbp
001f3968  5b                       pop rbx
001f3969  c3                       ret
001f396a  90                       nop
001f396b  90                       nop
001f396c  9d                       popfq
