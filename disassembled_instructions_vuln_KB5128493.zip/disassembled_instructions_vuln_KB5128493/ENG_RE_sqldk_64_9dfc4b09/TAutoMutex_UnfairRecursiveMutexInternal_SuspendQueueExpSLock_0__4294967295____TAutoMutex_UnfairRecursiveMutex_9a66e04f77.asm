; TAutoMutex<UnfairRecursiveMutexInternal<SuspendQueueExpSLock,0>,4294967295>::~TAutoMutex<UnfairRecursiveMutexInternal<SuspendQueueExpSLock,0>,4294967295>
; sqldk.dll, primary RVA 0x94e30, 126 bytes in 3 chunk(s)

; chunk at RVA 0x94e30 (15 bytes)
00094e30  4057                     push rdi
00094e32  4883ec20                 sub rsp, 0x20
00094e36  83790800                 cmp dword ptr [rcx + 8], 0
00094e3a  488bf9                   mov rdi, rcx
00094e3d  7669                     jbe 0x94ea8

; chunk at RVA 0x94e3f (105 bytes)
00094e3f  48895c2430               mov qword ptr [rsp + 0x30], rbx
00094e44  4889742438               mov qword ptr [rsp + 0x38], rsi
00094e49  33f6                     xor esi, esi
00094e4b  0f1f440000               nop dword ptr [rax + rax]
00094e50  654c8b042558000000       mov r8, qword ptr gs:[0x58]
00094e59  8b0571012800             mov eax, dword ptr [rip + 0x280171]
00094e5f  8b1553caf6ff             mov edx, dword ptr [rip - 0x935ad]
00094e65  488b1f                   mov rbx, qword ptr [rdi]
00094e68  498b04c0                 mov rax, qword ptr [r8 + rax*8]
00094e6c  4839b41000010000         cmp qword ptr [rax + rdx + 0x100], rsi
00094e74  7507                     jne 0x94e7d
00094e76  33c9                     xor ecx, ecx
00094e78  e893f2f9ff               call 0x34110
00094e7d  48836b3801               sub qword ptr [rbx + 0x38], 1
00094e82  7514                     jne 0x94e98
00094e84  48897328                 mov qword ptr [rbx + 0x28], rsi
00094e88  488bcb                   mov rcx, rbx
00094e8b  48897330                 mov qword ptr [rbx + 0x30], rsi
00094e8f  48897320                 mov qword ptr [rbx + 0x20], rsi
00094e93  e858e1f8ff               call 0x22ff0
00094e98  834708ff                 add dword ptr [rdi + 8], -1
00094e9c  75b2                     jne 0x94e50
00094e9e  488b742438               mov rsi, qword ptr [rsp + 0x38]
00094ea3  488b5c2430               mov rbx, qword ptr [rsp + 0x30]

; chunk at RVA 0x94ea8 (6 bytes)
00094ea8  4883c420                 add rsp, 0x20
00094eac  5f                       pop rdi
00094ead  c3                       ret
