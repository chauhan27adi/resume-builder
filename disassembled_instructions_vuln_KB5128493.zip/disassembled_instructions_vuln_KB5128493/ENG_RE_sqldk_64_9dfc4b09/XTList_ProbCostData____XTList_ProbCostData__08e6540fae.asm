; XTList<ProbCostData>::~XTList<ProbCostData>
; sqldk.dll, primary RVA 0x6b210, 28 bytes in 1 chunk(s)

; chunk at RVA 0x6b210 (28 bytes)
0006b210  48894c2408               mov qword ptr [rsp + 8], rcx
0006b215  4883ec18                 sub rsp, 0x18
0006b219  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
0006b221  c701adde0080             mov dword ptr [rcx], 0x8000dead
0006b227  4883c418                 add rsp, 0x18
0006b22b  c3                       ret
