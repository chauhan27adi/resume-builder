; `ex_set_dump_trigger'::`1'::dtor$1
; sqldk.dll, primary RVA 0x217a30, 62 bytes in 1 chunk(s)

; chunk at RVA 0x217a30 (62 bytes)
00217a30  4055                     push rbp
00217a32  4883ec30                 sub rsp, 0x30
00217a36  488bea                   mov rbp, rdx
00217a39  c644242806               mov byte ptr [rsp + 0x28], 6
00217a3e  8b85c0000000             mov eax, dword ptr [rbp + 0xc0]
00217a44  89442420                 mov dword ptr [rsp + 0x20], eax
00217a48  4c8d0d49e60600           lea r9, [rip + 0x6e649]
00217a4f  41b801000000             mov r8d, 1
00217a55  488b15f43f1a00           mov rdx, qword ptr [rip + 0x1a3ff4]
00217a5c  488b8dc8000000           mov rcx, qword ptr [rbp + 0xc8]
00217a63  e83803dfff               call 0x7da0
00217a68  4883c430                 add rsp, 0x30
00217a6c  5d                       pop rbp
00217a6d  c3                       ret
