; SpinlockHolder<46,1,268435714>::~SpinlockHolder<46,1,268435714>
; sqldk.dll, primary RVA 0x1a6970, 97 bytes in 1 chunk(s)

; chunk at RVA 0x1a6970 (97 bytes)
001a6970  48895c2408               mov qword ptr [rsp + 8], rbx
001a6975  57                       push rdi
001a6976  4883ec20                 sub rsp, 0x20
001a697a  488b39                   mov rdi, qword ptr [rcx]
001a697d  488bd9                   mov rbx, rcx
001a6980  4885ff                   test rdi, rdi
001a6983  7441                     je 0x1a69c6
001a6985  83790800                 cmp dword ptr [rcx + 8], 0
001a6989  743b                     je 0x1a69c6
001a698b  803d2feb160000           cmp byte ptr [rip + 0x16eb2f], 0
001a6992  7427                     je 0x1a69bb
001a6994  ff15ae300900             call qword ptr [rip + 0x930ae]
001a699a  448bc0                   mov r8d, eax
001a699d  b867666666               mov eax, 0x66666667
001a69a2  41f7e8                   imul r8d
001a69a5  d1fa                     sar edx, 1
001a69a7  8bca                     mov ecx, edx
001a69a9  c1e91f                   shr ecx, 0x1f
001a69ac  03d1                     add edx, ecx
001a69ae  8d0c92                   lea ecx, [rdx + rdx*4]
001a69b1  443bc1                   cmp r8d, ecx
001a69b4  7505                     jne 0x1a69bb
001a69b6  e825000000               call 0x1a69e0
001a69bb  33c0                     xor eax, eax
001a69bd  488907                   mov qword ptr [rdi], rax
001a69c0  488903                   mov qword ptr [rbx], rax
001a69c3  894308                   mov dword ptr [rbx + 8], eax
001a69c6  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
001a69cb  4883c420                 add rsp, 0x20
001a69cf  5f                       pop rdi
001a69d0  c3                       ret
