; `XMLCXTargetConfigHelper::ParseEventList'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2175b0, 37 bytes in 1 chunk(s)

; chunk at RVA 0x2175b0 (37 bytes)
002175b0  4055                     push rbp
002175b2  4883ec20                 sub rsp, 0x20
002175b6  488bea                   mov rbp, rdx
002175b9  4533c0                   xor r8d, r8d
002175bc  488b95a0000000           mov rdx, qword ptr [rbp + 0xa0]
002175c3  488b8da8000000           mov rcx, qword ptr [rbp + 0xa8]
002175ca  e8419adeff               call 0x1010
002175cf  4883c420                 add rsp, 0x20
002175d3  5d                       pop rbp
002175d4  c3                       ret
