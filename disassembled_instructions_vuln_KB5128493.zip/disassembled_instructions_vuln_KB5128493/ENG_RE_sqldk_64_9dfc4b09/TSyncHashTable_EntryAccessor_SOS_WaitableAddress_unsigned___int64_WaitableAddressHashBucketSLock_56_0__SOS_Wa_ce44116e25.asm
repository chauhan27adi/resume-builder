; TSyncHashTable_EntryAccessor<SOS_WaitableAddress,unsigned __int64,WaitableAddressHashBucketSLock,56,0,&SOS_WaitableAddressManager::CookieHash>::~TSyncHashTable_EntryAccessor<SOS_WaitableAddress,unsigned __int64,WaitableAddressHashBucketSLock,56,0,&SOS_WaitableAddressManager::CookieHash>
; sqldk.dll, primary RVA 0xaef40, 71 bytes in 1 chunk(s)

; chunk at RVA 0xaef40 (71 bytes)
000aef40  4053                     push rbx
000aef42  4883ec20                 sub rsp, 0x20
000aef46  803d7465260000           cmp byte ptr [rip + 0x266574], 0
000aef4d  488b19                   mov rbx, qword ptr [rcx]
000aef50  7427                     je 0xaef79
000aef52  ff15f0aa1800             call qword ptr [rip + 0x18aaf0]
000aef58  448bc0                   mov r8d, eax
000aef5b  b867666666               mov eax, 0x66666667
000aef60  41f7e8                   imul r8d
000aef63  d1fa                     sar edx, 1
000aef65  8bca                     mov ecx, edx
000aef67  c1e91f                   shr ecx, 0x1f
000aef6a  03d1                     add edx, ecx
000aef6c  8d0c92                   lea ecx, [rdx + rdx*4]
000aef6f  443bc1                   cmp r8d, ecx
000aef72  7505                     jne 0xaef79
000aef74  e817030000               call 0xaf290
000aef79  48c7431000000000         mov qword ptr [rbx + 0x10], 0
000aef81  4883c420                 add rsp, 0x20
000aef85  5b                       pop rbx
000aef86  c3                       ret
