; SOS_NodeEnum::~SOS_NodeEnum
; sqldk.dll, primary RVA 0xb64f0, 27 bytes in 1 chunk(s)

; chunk at RVA 0xb64f0 (27 bytes)
000b64f0  48894c2408               mov qword ptr [rsp + 8], rcx
000b64f5  4883ec38                 sub rsp, 0x38
000b64f9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000b6502  4883c438                 add rsp, 0x38
000b6506  e90562f8ff               jmp 0x3c710
