; `ISOSHostImpl::CreateTaskCallback'::`1'::dtor$1
; sqldk.dll, primary RVA 0x229b94, 59 bytes in 1 chunk(s)

; chunk at RVA 0x229b94 (59 bytes)
00229b94  4055                     push rbp
00229b96  4883ec30                 sub rsp, 0x30
00229b9a  488bea                   mov rbp, rdx
00229b9d  c644242806               mov byte ptr [rsp + 0x28], 6
00229ba2  8b8598000000             mov eax, dword ptr [rbp + 0x98]
00229ba8  89442420                 mov dword ptr [rsp + 0x20], eax
00229bac  4c8d0d2d000700           lea r9, [rip + 0x7002d]
00229bb3  41b801000000             mov r8d, 1
00229bb9  488b9580000000           mov rdx, qword ptr [rbp + 0x80]
00229bc0  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
00229bc4  e8d7e1ddff               call 0x7da0
00229bc9  4883c430                 add rsp, 0x30
00229bcd  5d                       pop rbp
00229bce  c3                       ret
