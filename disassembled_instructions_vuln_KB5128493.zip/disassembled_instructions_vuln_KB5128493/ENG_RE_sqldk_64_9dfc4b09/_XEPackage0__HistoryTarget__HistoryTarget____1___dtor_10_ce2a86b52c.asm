; `XEPackage0::HistoryTarget::HistoryTarget'::`1'::dtor$10
; sqldk.dll, primary RVA 0x2324d4, 42 bytes in 1 chunk(s)

; chunk at RVA 0x2324d4 (42 bytes)
002324d4  4055                     push rbp
002324d6  4883ec20                 sub rsp, 0x20
002324da  488bea                   mov rbp, rdx
002324dd  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
002324e1  4c8d0da8b5e1ff           lea r9, [rip - 0x1e4a58]
002324e8  41b800040000             mov r8d, 0x400
002324ee  ba08000000               mov edx, 8
002324f3  e868c7dfff               call 0x2ec60
002324f8  4883c420                 add rsp, 0x20
002324fc  5d                       pop rbp
002324fd  c3                       ret
