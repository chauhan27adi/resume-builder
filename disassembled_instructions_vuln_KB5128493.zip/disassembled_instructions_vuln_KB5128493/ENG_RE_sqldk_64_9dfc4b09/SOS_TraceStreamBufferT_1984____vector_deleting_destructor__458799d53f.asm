; SOS_TraceStreamBufferT<1984>::`vector deleting destructor'
; sqldk.dll, primary RVA 0x1b6ef0, 67 bytes in 1 chunk(s)

; chunk at RVA 0x1b6ef0 (67 bytes)
001b6ef0  48894c2408               mov qword ptr [rsp + 8], rcx
001b6ef5  57                       push rdi
001b6ef6  4883ec30                 sub rsp, 0x30
001b6efa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001b6f03  48895c2448               mov qword ptr [rsp + 0x48], rbx
001b6f08  8bda                     mov ebx, edx
001b6f0a  488bf9                   mov rdi, rcx
001b6f0d  ff15b5280800             call qword ptr [rip + 0x828b5]
001b6f13  f6c301                   test bl, 1
001b6f16  740d                     je 0x1b6f25
001b6f18  ba28080000               mov edx, 0x828
001b6f1d  488bcf                   mov rcx, rdi
001b6f20  e8cb0ee5ff               call 0x7df0
001b6f25  488bc7                   mov rax, rdi
001b6f28  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
001b6f2d  4883c430                 add rsp, 0x30
001b6f31  5f                       pop rdi
001b6f32  c3                       ret
