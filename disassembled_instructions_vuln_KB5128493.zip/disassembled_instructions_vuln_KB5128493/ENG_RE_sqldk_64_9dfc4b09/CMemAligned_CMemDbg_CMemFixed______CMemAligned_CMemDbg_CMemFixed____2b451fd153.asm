; CMemAligned<CMemDbg<CMemFixed> >::~CMemAligned<CMemDbg<CMemFixed> >
; sqldk.dll, primary RVA 0xfb630, 37 bytes in 1 chunk(s)

; chunk at RVA 0xfb630 (37 bytes)
000fb630  48894c2408               mov qword ptr [rsp + 8], rcx
000fb635  4883ec38                 sub rsp, 0x38
000fb639  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000fb642  488d05dffc1400           lea rax, [rip + 0x14fcdf]
000fb649  488901                   mov qword ptr [rcx], rax
000fb64c  4883c438                 add rsp, 0x38
000fb650  e91b590700               jmp 0x170f70
