; XE_EventEnum::~XE_EventEnum
; sqldk.dll, primary RVA 0x1e15f0, 27 bytes in 1 chunk(s)

; chunk at RVA 0x1e15f0 (27 bytes)
001e15f0  48894c2408               mov qword ptr [rsp + 8], rcx
001e15f5  4883ec38                 sub rsp, 0x38
001e15f9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
001e1602  4883c438                 add rsp, 0x38
001e1606  e945610000               jmp 0x1e7750
