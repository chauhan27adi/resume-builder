; CMemPartitioned<CMemDetour<CMemThread<CMemProc> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce020, 129 bytes in 1 chunk(s)

; chunk at RVA 0xce020 (129 bytes)
000ce020  48894c2408               mov qword ptr [rsp + 8], rcx
000ce025  57                       push rdi
000ce026  4883ec30                 sub rsp, 0x30
000ce02a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce033  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce038  8bda                     mov ebx, edx
000ce03a  488bf9                   mov rdi, rcx
000ce03d  488d0584041800           lea rax, [rip + 0x180484]
000ce044  488901                   mov qword ptr [rcx], rax
000ce047  488d8180020000           lea rax, [rcx + 0x280]
000ce04e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce053  488d0de6ba1600           lea rcx, [rip + 0x16bae6]
000ce05a  488908                   mov qword ptr [rax], rcx
000ce05d  488d05cc0d1800           lea rax, [rip + 0x180dcc]
000ce064  488907                   mov qword ptr [rdi], rax
000ce067  488d87b8010000           lea rax, [rdi + 0x1b8]
000ce06e  4889442458               mov qword ptr [rsp + 0x58], rax
000ce073  488908                   mov qword ptr [rax], rcx
000ce076  488bcf                   mov rcx, rdi
000ce079  e8124c0000               call 0xd2c90
000ce07e  83e305                   and ebx, 5
000ce081  80fb05                   cmp bl, 5
000ce084  750d                     jne 0xce093
000ce086  bab8020000               mov edx, 0x2b8
000ce08b  488bcf                   mov rcx, rdi
000ce08e  e87d2ff3ff               call 0x1010
000ce093  488bc7                   mov rax, rdi
000ce096  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce09b  4883c430                 add rsp, 0x30
000ce09f  5f                       pop rdi
000ce0a0  c3                       ret
