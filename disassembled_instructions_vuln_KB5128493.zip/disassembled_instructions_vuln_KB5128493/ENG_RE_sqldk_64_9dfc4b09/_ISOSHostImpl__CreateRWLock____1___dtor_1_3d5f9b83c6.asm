; `ISOSHostImpl::CreateRWLock'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22b5bc, 59 bytes in 1 chunk(s)

; chunk at RVA 0x22b5bc (59 bytes)
0022b5bc  4055                     push rbp
0022b5be  4883ec30                 sub rsp, 0x30
0022b5c2  488bea                   mov rbp, rdx
0022b5c5  c644242806               mov byte ptr [rsp + 0x28], 6
0022b5ca  8b8580000000             mov eax, dword ptr [rbp + 0x80]
0022b5d0  89442420                 mov dword ptr [rsp + 0x20], eax
0022b5d4  4c8d0d05e60600           lea r9, [rip + 0x6e605]
0022b5db  41b801000000             mov r8d, 1
0022b5e1  488b5570                 mov rdx, qword ptr [rbp + 0x70]
0022b5e5  488b8d88000000           mov rcx, qword ptr [rbp + 0x88]
0022b5ec  e8afc7ddff               call 0x7da0
0022b5f1  4883c430                 add rsp, 0x30
0022b5f5  5d                       pop rbp
0022b5f6  c3                       ret
