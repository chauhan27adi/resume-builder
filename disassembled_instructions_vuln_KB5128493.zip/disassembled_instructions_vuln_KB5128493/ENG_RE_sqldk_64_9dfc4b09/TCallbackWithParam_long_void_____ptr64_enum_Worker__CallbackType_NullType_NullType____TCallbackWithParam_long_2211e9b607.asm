; TCallbackWithParam<long,void * __ptr64,enum Worker::CallbackType,NullType,NullType>::~TCallbackWithParam<long,void * __ptr64,enum Worker::CallbackType,NullType,NullType>
; sqldk.dll, primary RVA 0x8dae0, 50 bytes in 1 chunk(s)

; chunk at RVA 0x8dae0 (50 bytes)
0008dae0  48894c2408               mov qword ptr [rsp + 8], rcx
0008dae5  4883ec18                 sub rsp, 0x18
0008dae9  48c70424feffffff         mov qword ptr [rsp], 0xfffffffffffffffe
0008daf1  488b5108                 mov rdx, qword ptr [rcx + 8]
0008daf5  4885d2                   test rdx, rdx
0008daf8  7413                     je 0x8db0d
0008dafa  488b01                   mov rax, qword ptr [rcx]
0008dafd  48895008                 mov qword ptr [rax + 8], rdx
0008db01  488902                   mov qword ptr [rdx], rax
0008db04  33c0                     xor eax, eax
0008db06  48894108                 mov qword ptr [rcx + 8], rax
0008db0a  488901                   mov qword ptr [rcx], rax
0008db0d  4883c418                 add rsp, 0x18
0008db11  c3                       ret
