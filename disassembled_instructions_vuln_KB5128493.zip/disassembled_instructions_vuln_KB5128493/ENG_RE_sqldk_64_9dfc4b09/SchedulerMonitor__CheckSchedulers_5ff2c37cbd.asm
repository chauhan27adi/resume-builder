; SchedulerMonitor::CheckSchedulers
; sqldk.dll, primary RVA 0x18720, 1495 bytes in 1 chunk(s)

; chunk at RVA 0x18720 (1495 bytes)
00018720  488bc4                   mov rax, rsp
00018723  55                       push rbp
00018724  4154                     push r12
00018726  4155                     push r13
00018728  4156                     push r14
0001872a  4157                     push r15
0001872c  488da8d8f6ffff           lea rbp, [rax - 0x928]
00018733  4881ec000a0000           sub rsp, 0xa00
0001873a  48c74578feffffff         mov qword ptr [rbp + 0x78], 0xfffffffffffffffe
00018742  48895810                 mov qword ptr [rax + 0x10], rbx
00018746  48897018                 mov qword ptr [rax + 0x18], rsi
0001874a  48897820                 mov qword ptr [rax + 0x20], rdi
0001874e  488b0533892f00           mov rax, qword ptr [rip + 0x2f8933]
00018755  4833c4                   xor rax, rsp
00018758  488985f0080000           mov qword ptr [rbp + 0x8f0], rax
0001875f  8bfa                     mov edi, edx
00018761  89542438                 mov dword ptr [rsp + 0x38], edx
00018765  4c8bf9                   mov r15, rcx
00018768  48894c2440               mov qword ptr [rsp + 0x40], rcx
0001876d  be01000000               mov esi, 1
00018772  8bde                     mov ebx, esi
00018774  895c2420                 mov dword ptr [rsp + 0x20], ebx
00018778  4533f6                   xor r14d, r14d
0001877b  4489742430               mov dword ptr [rsp + 0x30], r14d
00018780  33d2                     xor edx, edx
00018782  41b800010000             mov r8d, 0x100
00018788  488d8df0070000           lea rcx, [rbp + 0x7f0]
0001878f  e850c1feff               call 0x48e4
00018794  33d2                     xor edx, edx
00018796  41b800010000             mov r8d, 0x100
0001879c  488d8df0060000           lea rcx, [rbp + 0x6f0]
000187a3  e83cc1feff               call 0x48e4
000187a8  b9e8010000               mov ecx, 0x1e8
000187ad  41b898010000             mov r8d, 0x198
000187b3  3bfe                     cmp edi, esi
000187b5  440f45c1                 cmovne r8d, ecx
000187b9  4d034718                 add r8, qword ptr [r15 + 0x18]
000187bd  ba68010000               mov edx, 0x168
000187c2  b9b8010000               mov ecx, 0x1b8
000187c7  3bfe                     cmp edi, esi
000187c9  0f45d1                   cmovne edx, ecx
000187cc  49035718                 add rdx, qword ptr [r15 + 0x18]
000187d0  448bce                   mov r9d, esi
000187d3  488d4d38                 lea rcx, [rbp + 0x38]
000187d7  e894f1ffff               call 0x17970
000187dc  90                       nop
000187dd  458bee                   mov r13d, r14d
000187e0  448d66fe                 lea r12d, [rsi - 2]
000187e4  498bf6                   mov rsi, r14
000187e7  4d85ed                   test r13, r13
000187ea  0f848cfaffff             je 0x1827c
000187f0  488b5d38                 mov rbx, qword ptr [rbp + 0x38]
000187f4  4885db                   test rbx, rbx
000187f7  0f84cb000000             je 0x188c8
000187fd  483b5d40                 cmp rbx, qword ptr [rbp + 0x40]
00018801  0f84b1020000             je 0x18ab8
00018807  4c8b7548                 mov r14, qword ptr [rbp + 0x48]
0001880b  4d8d7e10                 lea r15, [r14 + 0x10]
0001880f  33d2                     xor edx, edx
00018811  8bda                     mov ebx, edx
00018813  658b042548000000         mov eax, dword ptr gs:[0x48]
0001881b  8bf0                     mov esi, eax
0001881d  418b07                   mov eax, dword ptr [r15]
00018820  85c0                     test eax, eax
00018822  0f85c63d1700             jne 0x18c5ee
00018828  33c0                     xor eax, eax
0001882a  f0490fb137               lock cmpxchg qword ptr [r15], rsi
0001882f  8bc2                     mov eax, edx
00018831  0f94c0                   sete al
00018834  85c0                     test eax, eax
00018836  0f84b23d1700             je 0x18c5ee
0001883c  498b4d18                 mov rcx, qword ptr [r13 + 0x18]
00018840  493bce                   cmp rcx, r14
00018843  0f84813e1700             je 0x18c6ca
00018849  488d41f0                 lea rax, [rcx - 0x10]
0001884d  488bf2                   mov rsi, rdx
00018850  4885c9                   test rcx, rcx
00018853  480f45f0                 cmovne rsi, rax
00018857  4885f6                   test rsi, rsi
0001885a  743e                     je 0x1889a
0001885c  660f1f0400               nop word ptr [rax + rax]
00018861  0f1f4000                 nop dword ptr [rax]
00018865  6666660f1f840000000000   nop word ptr [rax + rax]
00018870  8b4e28                   mov ecx, dword ptr [rsi + 0x28]
00018873  85c9                     test ecx, ecx
00018875  0f846d3e1700             je 0x18c6e8
0001887b  660f1f0400               nop word ptr [rax + rax]
00018880  8d5101                   lea edx, [rcx + 1]
00018883  8bc1                     mov eax, ecx
00018885  f00fb15628               lock cmpxchg dword ptr [rsi + 0x28], edx
0001888a  3bc8                     cmp ecx, eax
0001888c  0f85443e1700             jne 0x18c6d6
00018892  85d2                     test edx, edx
00018894  0f844c3e1700             je 0x18c6e6
0001889a  4533f6                   xor r14d, r14d
0001889d  803d1dcc2f0000           cmp byte ptr [rip + 0x2fcc1d], 0
000188a4  0f85643e1700             jne 0x18c70e
000188aa  4d8937                   mov qword ptr [r15], r14
000188ad  48897538                 mov qword ptr [rbp + 0x38], rsi
000188b1  418bc4                   mov eax, r12d
000188b4  f0410fc14528             lock xadd dword ptr [r13 + 0x28], eax
000188ba  83f801                   cmp eax, 1
000188bd  0f847d3e1700             je 0x18c740
000188c3  4c8b7c2440               mov r15, qword ptr [rsp + 0x40]
000188c8  8b5c2420                 mov ebx, dword ptr [rsp + 0x20]
000188cc  4c8bee                   mov r13, rsi
000188cf  4889742470               mov qword ptr [rsp + 0x70], rsi
000188d4  4885f6                   test rsi, rsi
000188d7  0f840c020000             je 0x18ae9
000188dd  c744243001000000         mov dword ptr [rsp + 0x30], 1
000188e5  4c8bc6                   mov r8, rsi
000188e8  8bd7                     mov edx, edi
000188ea  498bcf                   mov rcx, r15
000188ed  e8def9ffff               call 0x182d0
000188f2  85db                     test ebx, ebx
000188f4  0f858cf9ffff             jne 0x18286
000188fa  418bde                   mov ebx, r14d
000188fd  895c2420                 mov dword ptr [rsp + 0x20], ebx
00018901  83ff01                   cmp edi, 1
00018904  0f85dafeffff             jne 0x187e4
0001890a  0f57c0                   xorps xmm0, xmm0
0001890d  f30f7f442478             movdqu xmmword ptr [rsp + 0x78], xmm0
00018913  4533ed                   xor r13d, r13d
00018916  4c896d90                 mov qword ptr [rbp - 0x70], r13
0001891a  44896d98                 mov dword ptr [rbp - 0x68], r13d
0001891e  4c896d88                 mov qword ptr [rbp - 0x78], r13
00018922  488d1dbf043000           lea rbx, [rip + 0x3004bf]
00018929  48895d88                 mov qword ptr [rbp - 0x78], rbx
0001892d  488bcb                   mov rcx, rbx
00018930  e8dbf7ffff               call 0x18110
00018935  4889442478               mov qword ptr [rsp + 0x78], rax
0001893a  488bcb                   mov rcx, rbx
0001893d  e88ef8ffff               call 0x181d0
00018942  48894580                 mov qword ptr [rbp - 0x80], rax
00018946  458bfd                   mov r15d, r13d
00018949  0f1f8000000000           nop dword ptr [rax]
00018950  498bdd                   mov rbx, r13
00018953  4d85ff                   test r15, r15
00018956  0f843df9ffff             je 0x18299
0001895c  488b4c2478               mov rcx, qword ptr [rsp + 0x78]
00018961  4885c9                   test rcx, rcx
00018964  7425                     je 0x1898b
00018966  483b4d80                 cmp rcx, qword ptr [rbp - 0x80]
0001896a  0f85cafcffff             jne 0x1863a
00018970  488b7c2478               mov rdi, qword ptr [rsp + 0x78]
00018975  4c896c2478               mov qword ptr [rsp + 0x78], r13
0001897a  418bc4                   mov eax, r12d
0001897d  f00fc14718               lock xadd dword ptr [rdi + 0x18], eax
00018982  83f801                   cmp eax, 1
00018985  0f84953e1700             je 0x18c820
0001898b  4c8bfb                   mov r15, rbx
0001898e  4885db                   test rbx, rbx
00018991  0f84a4000000             je 0x18a3b
00018997  488d8b600b0000           lea rcx, [rbx + 0xb60]
0001899e  488d9570060000           lea rdx, [rbp + 0x670]
000189a5  e876befeff               call 0x4820
000189aa  0fb78610140000           movzx eax, word ptr [rsi + 0x1410]
000189b1  488d0c80                 lea rcx, [rax + rax*4]
000189b5  488d14cd00000000         lea rdx, [rcx*8]
000189bd  4c8d059c723000           lea r8, [rip + 0x30729c]
000189c4  420fb7440210             movzx eax, word ptr [rdx + r8 + 0x10]
000189ca  488b8cc570060000         mov rcx, qword ptr [rbp + rax*8 + 0x670]
000189d2  4a234c0208               and rcx, qword ptr [rdx + r8 + 8]
000189d7  48858e18140000           test qword ptr [rsi + 0x1418], rcx
000189de  0f846cffffff             je 0x18950
000189e4  8b93300b0000             mov edx, dword ptr [rbx + 0xb30]
000189ea  833ddfce2f0001           cmp dword ptr [rip + 0x2fcedf], 1
000189f1  0f854c3e1700             jne 0x18c843
000189f7  81be680e000000001000     cmp dword ptr [rsi + 0xe68], 0x100000
00018a01  41b901000000             mov r9d, 1
00018a07  0f83363e1700             jae 0x18c843
00018a0d  448b865c140000           mov r8d, dword ptr [rsi + 0x145c]
00018a14  488d1c9500000000         lea rbx, [rdx*4]
00018a1c  488d8e80000000           lea rcx, [rsi + 0x80]
00018a23  e848dafeff               call 0x6470
00018a28  01841df0070000           add dword ptr [rbp + rbx + 0x7f0], eax
00018a2f  ff841df0060000           inc dword ptr [rbp + rbx + 0x6f0]
00018a36  e915ffffff               jmp 0x18950
00018a3b  488b4c2478               mov rcx, qword ptr [rsp + 0x78]
00018a40  4885c9                   test rcx, rcx
00018a43  4c8b6c2470               mov r13, qword ptr [rsp + 0x70]
00018a48  0f85fe3d1700             jne 0x18c84c
00018a4e  4533f6                   xor r14d, r14d
00018a51  488b4d80                 mov rcx, qword ptr [rbp - 0x80]
00018a55  4885c9                   test rcx, rcx
00018a58  7415                     je 0x18a6f
00018a5a  418bc4                   mov eax, r12d
00018a5d  f00fc14118               lock xadd dword ptr [rcx + 0x18], eax
00018a62  83f801                   cmp eax, 1
00018a65  0f84293e1700             je 0x18c894
00018a6b  4c897580                 mov qword ptr [rbp - 0x80], r14
00018a6f  4c897588                 mov qword ptr [rbp - 0x78], r14
00018a73  8b7c2438                 mov edi, dword ptr [rsp + 0x38]
00018a77  4c8b7c2440               mov r15, qword ptr [rsp + 0x40]
00018a7c  8b5c2420                 mov ebx, dword ptr [rsp + 0x20]
00018a80  e95ffdffff               jmp 0x187e4
00018a85  cc                       int3
00018a86  4c89742448               mov qword ptr [rsp + 0x48], r14
00018a8b  418bc4                   mov eax, r12d
00018a8e  f00fc14718               lock xadd dword ptr [rdi + 0x18], eax
00018a93  83f801                   cmp eax, 1
00018a96  0f8568010000             jne 0x18c04
00018a9c  48837f0800               cmp qword ptr [rdi + 8], 0
00018aa1  0f859e010000             jne 0x18c45
00018aa7  488bcf                   mov rcx, rdi
00018aaa  e8411f0500               call 0x6a9f0
00018aaf  488bcf                   mov rcx, rdi
00018ab2  e9f23e1700               jmp 0x18c9a9
00018ab7  cc                       int3
00018ab8  4c897538                 mov qword ptr [rbp + 0x38], r14
00018abc  418bc4                   mov eax, r12d
00018abf  f00fc14328               lock xadd dword ptr [rbx + 0x28], eax
00018ac4  83f801                   cmp eax, 1
00018ac7  0f85fbfdffff             jne 0x188c8
00018acd  48837b1800               cmp qword ptr [rbx + 0x18], 0
00018ad2  740c                     je 0x18ae0
00018ad4  488bd3                   mov rdx, rbx
00018ad7  488b4b20                 mov rcx, qword ptr [rbx + 0x20]
00018adb  e81078ffff               call 0x102f0
00018ae0  488bcb                   mov rcx, rbx
00018ae3  e848360600               call 0x7c130
00018ae8  90                       nop
00018ae9  488d4d38                 lea rcx, [rbp + 0x38]
00018aed  e8eeedffff               call 0x178e0
00018af2  83ff01                   cmp edi, 1
00018af5  0f85b2f7ffff             jne 0x182ad
00018afb  0f57c0                   xorps xmm0, xmm0
00018afe  f30f7f442448             movdqu xmmword ptr [rsp + 0x48], xmm0
00018b04  4c89742460               mov qword ptr [rsp + 0x60], r14
00018b09  4489742468               mov dword ptr [rsp + 0x68], r14d
00018b0e  4c89742458               mov qword ptr [rsp + 0x58], r14
00018b13  4c8d2dce023000           lea r13, [rip + 0x3002ce]
00018b1a  4c896c2458               mov qword ptr [rsp + 0x58], r13
00018b1f  498bcd                   mov rcx, r13
00018b22  e8e9f5ffff               call 0x18110
00018b27  488bf8                   mov rdi, rax
00018b2a  4889442448               mov qword ptr [rsp + 0x48], rax
00018b2f  498bcd                   mov rcx, r13
00018b32  e899f6ffff               call 0x181d0
00018b37  4889442450               mov qword ptr [rsp + 0x50], rax
00018b3c  498bf6                   mov rsi, r14
00018b3f  90                       nop
00018b40  498bde                   mov rbx, r14
00018b43  4885f6                   test rsi, rsi
00018b46  0f8458f7ffff             je 0x182a4
00018b4c  4885ff                   test rdi, rdi
00018b4f  0f84b4000000             je 0x18c09
00018b55  483b7c2450               cmp rdi, qword ptr [rsp + 0x50]
00018b5a  0f8426ffffff             je 0x18a86
00018b60  658b042548000000         mov eax, dword ptr gs:[0x48]
00018b68  448bf0                   mov r14d, eax
00018b6b  8b0587023000             mov eax, dword ptr [rip + 0x300287]
00018b71  85c0                     test eax, eax
00018b73  0f8510260200             jne 0x3b189
00018b79  33c0                     xor eax, eax
00018b7b  f04c0fb13574023000       lock cmpxchg qword ptr [rip + 0x300274], r14
00018b84  41b800000000             mov r8d, 0
00018b8a  418bc0                   mov eax, r8d
00018b8d  0f94c0                   sete al
00018b90  85c0                     test eax, eax
00018b92  0f84f4250200             je 0x3b18c
00018b98  4533f6                   xor r14d, r14d
00018b9b  488b5e08                 mov rbx, qword ptr [rsi + 8]
00018b9f  493bdd                   cmp rbx, r13
00018ba2  0f84a53d1700             je 0x18c94d
00018ba8  4885db                   test rbx, rbx
00018bab  742d                     je 0x18bda
00018bad  8b4b18                   mov ecx, dword ptr [rbx + 0x18]
00018bb0  85c9                     test ecx, ecx
00018bb2  0f848c3d1700             je 0x18c944
00018bb8  660f1f0400               nop word ptr [rax + rax]
00018bbd  0f1f00                   nop dword ptr [rax]
00018bc0  8d5101                   lea edx, [rcx + 1]
00018bc3  8bc1                     mov eax, ecx
00018bc5  f00fb15318               lock cmpxchg dword ptr [rbx + 0x18], edx
00018bca  3bc8                     cmp ecx, eax
00018bcc  0f8576260200             jne 0x3b248
00018bd2  85d2                     test edx, edx
00018bd4  0f846a3d1700             je 0x18c944
00018bda  803de0c82f0000           cmp byte ptr [rip + 0x2fc8e0], 0
00018be1  0f856f3d1700             jne 0x18c956
00018be7  4c89350a023000           mov qword ptr [rip + 0x30020a], r14
00018bee  48895c2448               mov qword ptr [rsp + 0x48], rbx
00018bf3  418bc4                   mov eax, r12d
00018bf6  f00fc14618               lock xadd dword ptr [rsi + 0x18], eax
00018bfb  83f801                   cmp eax, 1
00018bfe  0f84843d1700             je 0x18c988
00018c04  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
00018c09  488bf3                   mov rsi, rbx
00018c0c  4885db                   test rbx, rbx
00018c0f  745a                     je 0x18c6b
00018c11  448b83300b0000           mov r8d, dword ptr [rbx + 0xb30]
00018c18  428b8c85f0060000         mov ecx, dword ptr [rbp + r8*4 + 0x6f0]
00018c20  85c9                     test ecx, ecx
00018c22  0f8418ffffff             je 0x18b40
00018c28  33d2                     xor edx, edx
00018c2a  428b8485f0070000         mov eax, dword ptr [rbp + r8*4 + 0x7f0]
00018c32  f7f1                     div ecx
00018c34  498b4f18                 mov rcx, qword ptr [r15 + 0x18]
00018c38  4289848138060000         mov dword ptr [rcx + r8*4 + 0x638], eax
00018c40  e9fbfeffff               jmp 0x18b40
00018c45  488bd7                   mov rdx, rdi
00018c48  488b4f10                 mov rcx, qword ptr [rdi + 0x10]
00018c4c  e8ef93ffff               call 0x12040
00018c51  488bcf                   mov rcx, rdi
00018c54  e8971d0500               call 0x6a9f0
00018c59  bae80b0000               mov edx, 0xbe8
00018c5e  488bcf                   mov rcx, rdi
00018c61  e88af1feff               call 0x7df0
00018c66  488b7c2448               mov rdi, qword ptr [rsp + 0x48]
00018c6b  4885ff                   test rdi, rdi
00018c6e  0f85463d1700             jne 0x18c9ba
00018c74  488b442450               mov rax, qword ptr [rsp + 0x50]
00018c79  4885c0                   test rax, rax
00018c7c  7415                     je 0x18c93
00018c7e  f0440fc16018             lock xadd dword ptr [rax + 0x18], r12d
00018c84  4183fc01                 cmp r12d, 1
00018c88  0f84713d1700             je 0x18c9ff
00018c8e  4c89742450               mov qword ptr [rsp + 0x50], r14
00018c93  4c89742458               mov qword ptr [rsp + 0x58], r14
00018c98  498d9fe0010000           lea rbx, [r15 + 0x1e0]
00018c9f  498db718020000           lea rsi, [r15 + 0x218]
00018ca6  eb01                     jmp 0x18ca9
00018ca8  cc                       int3
00018ca9  837c243001               cmp dword ptr [rsp + 0x30], 1
00018cae  750b                     jne 0x18cbb
00018cb0  837c242001               cmp dword ptr [rsp + 0x20], 1
00018cb5  0f84783d1700             je 0x18ca33
00018cbb  833b01                   cmp dword ptr [rbx], 1
00018cbe  0f8366401700             jae 0x18cd2a
00018cc4  448933                   mov dword ptr [rbx], r14d
00018cc7  488b8df0080000           mov rcx, qword ptr [rbp + 0x8f0]
00018cce  4833cc                   xor rcx, rsp
00018cd1  e8cab9feff               call 0x46a0
00018cd6  4c8d9c24000a0000         lea r11, [rsp + 0xa00]
00018cde  498b5b38                 mov rbx, qword ptr [r11 + 0x38]
00018ce2  498b7340                 mov rsi, qword ptr [r11 + 0x40]
00018ce6  498b7b48                 mov rdi, qword ptr [r11 + 0x48]
00018cea  498be3                   mov rsp, r11
00018ced  415f                     pop r15
00018cef  415e                     pop r14
00018cf1  415d                     pop r13
00018cf3  415c                     pop r12
00018cf5  5d                       pop rbp
00018cf6  c3                       ret
