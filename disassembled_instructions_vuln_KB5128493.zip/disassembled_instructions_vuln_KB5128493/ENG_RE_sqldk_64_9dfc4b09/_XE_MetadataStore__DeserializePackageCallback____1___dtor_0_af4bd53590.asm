; `XE_MetadataStore::DeserializePackageCallback'::`1'::dtor$0
; sqldk.dll, primary RVA 0x2160e0, 31 bytes in 1 chunk(s)

; chunk at RVA 0x2160e0 (31 bytes)
002160e0  4055                     push rbp
002160e2  4883ec20                 sub rsp, 0x20
002160e6  488bea                   mov rbp, rdx
002160e9  4533c0                   xor r8d, r8d
002160ec  488b5570                 mov rdx, qword ptr [rbp + 0x70]
002160f0  488b4d78                 mov rcx, qword ptr [rbp + 0x78]
002160f4  e817afdeff               call 0x1010
002160f9  4883c420                 add rsp, 0x20
002160fd  5d                       pop rbp
002160fe  c3                       ret
