; CMemDetour<CMemThread<CMemLargePageObj> >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0xce970, 104 bytes in 1 chunk(s)

; chunk at RVA 0xce970 (104 bytes)
000ce970  48894c2408               mov qword ptr [rsp + 8], rcx
000ce975  57                       push rdi
000ce976  4883ec30                 sub rsp, 0x30
000ce97a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce983  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce988  8bda                     mov ebx, edx
000ce98a  488bf9                   mov rdi, rcx
000ce98d  488d0514e31700           lea rax, [rip + 0x17e314]
000ce994  488901                   mov qword ptr [rcx], rax
000ce997  488d81e0020000           lea rax, [rcx + 0x2e0]
000ce99e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce9a3  488d0d96b11600           lea rcx, [rip + 0x16b196]
000ce9aa  488908                   mov qword ptr [rax], rcx
000ce9ad  488bcf                   mov rcx, rdi
000ce9b0  e87b4d0400               call 0x113730
000ce9b5  83e305                   and ebx, 5
000ce9b8  80fb05                   cmp bl, 5
000ce9bb  750d                     jne 0xce9ca
000ce9bd  ba18030000               mov edx, 0x318
000ce9c2  488bcf                   mov rcx, rdi
000ce9c5  e84626f3ff               call 0x1010
000ce9ca  488bc7                   mov rax, rdi
000ce9cd  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce9d2  4883c430                 add rsp, 0x30
000ce9d6  5f                       pop rdi
000ce9d7  c3                       ret
