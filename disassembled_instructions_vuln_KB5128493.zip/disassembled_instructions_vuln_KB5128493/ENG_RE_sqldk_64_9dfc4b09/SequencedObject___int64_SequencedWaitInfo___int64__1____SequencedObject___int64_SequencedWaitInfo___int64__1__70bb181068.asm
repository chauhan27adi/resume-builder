; SequencedObject<__int64,SequencedWaitInfo<__int64>,1>::~SequencedObject<__int64,SequencedWaitInfo<__int64>,1>
; sqldk.dll, primary RVA 0x196070, 25 bytes in 1 chunk(s)

; chunk at RVA 0x196070 (25 bytes)
00196070  4883ec28                 sub rsp, 0x28
00196074  41b800000084             mov r8d, 0x84000000
0019607a  488d542438               lea rdx, [rsp + 0x38]
0019607f  e8ac010000               call 0x196230
00196084  4883c428                 add rsp, 0x28
00196088  c3                       ret
