; XEPackage0::XE_LiveTarget::NotifyLogCreateError
; sqldk.dll, primary RVA 0x1d0e50, 51 bytes in 1 chunk(s)

; chunk at RVA 0x1d0e50 (51 bytes)
001d0e50  4883ec38                 sub rsp, 0x38
001d0e54  488d0575c30d00           lea rax, [rip + 0xdc375]
001d0e5b  41b958010000             mov r9d, 0x158
001d0e61  4c8d0590ae0d00           lea r8, [rip + 0xdae90]
001d0e68  4889442420               mov qword ptr [rsp + 0x20], rax
001d0e6d  488d15c8ae0d00           lea rdx, [rip + 0xdaec8]
001d0e74  b901000000               mov ecx, 1
001d0e79  e8420ffeff               call 0x1b1dc0
001d0e7e  4883c438                 add rsp, 0x38
001d0e82  c3                       ret
