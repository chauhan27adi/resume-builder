; `XEPackage0::PairingTarget::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x230db0, 32 bytes in 1 chunk(s)

; chunk at RVA 0x230db0 (32 bytes)
00230db0  4055                     push rbp
00230db2  4883ec20                 sub rsp, 0x20
00230db6  488bea                   mov rbp, rdx
00230db9  4c8b4538                 mov r8, qword ptr [rbp + 0x38]
00230dbd  488b5530                 mov rdx, qword ptr [rbp + 0x30]
00230dc1  488b4d48                 mov rcx, qword ptr [rbp + 0x48]
00230dc5  e84602ddff               call 0x1010
00230dca  4883c420                 add rsp, 0x20
00230dce  5d                       pop rbp
00230dcf  c3                       ret
