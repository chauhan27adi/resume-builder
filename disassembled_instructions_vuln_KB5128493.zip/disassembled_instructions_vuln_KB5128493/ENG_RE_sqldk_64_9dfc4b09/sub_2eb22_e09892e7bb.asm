; sub_2eb22
; sqldk.dll, primary RVA 0x2eb22, 6 bytes in 1 chunk(s)

; chunk at RVA 0x2eb22 (6 bytes)
0002eb22  4883c420                 add rsp, 0x20
0002eb26  5f                       pop rdi
0002eb27  c3                       ret
