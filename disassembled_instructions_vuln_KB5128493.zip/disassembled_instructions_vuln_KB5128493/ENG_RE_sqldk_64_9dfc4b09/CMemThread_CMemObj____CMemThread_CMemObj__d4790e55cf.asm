; CMemThread<CMemObj>::~CMemThread<CMemObj>
; sqldk.dll, primary RVA 0x12a1a0, 111 bytes in 1 chunk(s)

; chunk at RVA 0x12a1a0 (111 bytes)
0012a1a0  48894c2408               mov qword ptr [rsp + 8], rcx
0012a1a5  53                       push rbx
0012a1a6  4883ec30                 sub rsp, 0x30
0012a1aa  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0012a1b3  488bd9                   mov rbx, rcx
0012a1b6  488d055bde1100           lea rax, [rip + 0x11de5b]
0012a1bd  488901                   mov qword ptr [rcx], rax
0012a1c0  488d8128010000           lea rax, [rcx + 0x128]
0012a1c7  4889442448               mov qword ptr [rsp + 0x48], rax
0012a1cc  488d0d6df91000           lea rcx, [rip + 0x10f96d]
0012a1d3  48894830                 mov qword ptr [rax + 0x30], rcx
0012a1d7  488908                   mov qword ptr [rax], rcx
0012a1da  488d0587cd1100           lea rax, [rip + 0x11cd87]
0012a1e1  488903                   mov qword ptr [rbx], rax
0012a1e4  488d051dd01100           lea rax, [rip + 0x11d01d]
0012a1eb  488903                   mov qword ptr [rbx], rax
0012a1ee  488d4b38                 lea rcx, [rbx + 0x38]
0012a1f2  e8f97feeff               call 0x121f0
0012a1f7  90                       nop
0012a1f8  488d4b30                 lea rcx, [rbx + 0x30]
0012a1fc  e8ef7feeff               call 0x121f0
0012a201  90                       nop
0012a202  c74308adde0080           mov dword ptr [rbx + 8], 0x8000dead
0012a209  4883c430                 add rsp, 0x30
0012a20d  5b                       pop rbx
0012a20e  c3                       ret
