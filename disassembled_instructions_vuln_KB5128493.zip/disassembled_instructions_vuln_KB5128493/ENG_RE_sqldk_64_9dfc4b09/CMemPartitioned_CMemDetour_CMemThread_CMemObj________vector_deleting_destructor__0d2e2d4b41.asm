; CMemPartitioned<CMemDetour<CMemThread<CMemObj> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xcefc0, 129 bytes in 1 chunk(s)

; chunk at RVA 0xcefc0 (129 bytes)
000cefc0  48894c2408               mov qword ptr [rsp + 8], rcx
000cefc5  57                       push rdi
000cefc6  4883ec30                 sub rsp, 0x30
000cefca  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000cefd3  48895c2448               mov qword ptr [rsp + 0x48], rbx
000cefd8  8bda                     mov ebx, edx
000cefda  488bf9                   mov rdi, rcx
000cefdd  488d05fcc91700           lea rax, [rip + 0x17c9fc]
000cefe4  488901                   mov qword ptr [rcx], rax
000cefe7  488d8108030000           lea rax, [rcx + 0x308]
000cefee  4889442450               mov qword ptr [rsp + 0x50], rax
000ceff3  488d0d46ab1600           lea rcx, [rip + 0x16ab46]
000ceffa  488908                   mov qword ptr [rax], rcx
000ceffd  488d05ecd11700           lea rax, [rip + 0x17d1ec]
000cf004  488907                   mov qword ptr [rdi], rax
000cf007  488d8740020000           lea rax, [rdi + 0x240]
000cf00e  4889442458               mov qword ptr [rsp + 0x58], rax
000cf013  488908                   mov qword ptr [rax], rcx
000cf016  488bcf                   mov rcx, rdi
000cf019  e882b10500               call 0x12a1a0
000cf01e  83e305                   and ebx, 5
000cf021  80fb05                   cmp bl, 5
000cf024  750d                     jne 0xcf033
000cf026  ba40030000               mov edx, 0x340
000cf02b  488bcf                   mov rcx, rdi
000cf02e  e8dd1ff3ff               call 0x1010
000cf033  488bc7                   mov rax, rdi
000cf036  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000cf03b  4883c430                 add rsp, 0x30
000cf03f  5f                       pop rdi
000cf040  c3                       ret
