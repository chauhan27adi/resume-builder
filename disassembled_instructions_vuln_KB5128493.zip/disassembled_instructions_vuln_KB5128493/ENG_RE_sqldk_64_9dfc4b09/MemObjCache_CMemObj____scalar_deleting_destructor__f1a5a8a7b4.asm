; MemObjCache<CMemObj>::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13ef70, 121 bytes in 1 chunk(s)

; chunk at RVA 0x13ef70 (121 bytes)
0013ef70  48894c2408               mov qword ptr [rsp + 8], rcx
0013ef75  57                       push rdi
0013ef76  4883ec30                 sub rsp, 0x30
0013ef7a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013ef83  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013ef88  8bda                     mov ebx, edx
0013ef8a  488bf9                   mov rdi, rcx
0013ef8d  488d057c8c1000           lea rax, [rip + 0x108c7c]
0013ef94  488901                   mov qword ptr [rcx], rax
0013ef97  488d05ca7f1000           lea rax, [rip + 0x107fca]
0013ef9e  488901                   mov qword ptr [rcx], rax
0013efa1  488d0560821000           lea rax, [rip + 0x108260]
0013efa8  488901                   mov qword ptr [rcx], rax
0013efab  4883c138                 add rcx, 0x38
0013efaf  e83c32edff               call 0x121f0
0013efb4  90                       nop
0013efb5  488d4f30                 lea rcx, [rdi + 0x30]
0013efb9  e83232edff               call 0x121f0
0013efbe  90                       nop
0013efbf  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013efc6  83e305                   and ebx, 5
0013efc9  80fb05                   cmp bl, 5
0013efcc  750d                     jne 0x13efdb
0013efce  ba78010000               mov edx, 0x178
0013efd3  488bcf                   mov rcx, rdi
0013efd6  e83520ecff               call 0x1010
0013efdb  488bc7                   mov rax, rdi
0013efde  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013efe3  4883c430                 add rsp, 0x30
0013efe7  5f                       pop rdi
0013efe8  c3                       ret
