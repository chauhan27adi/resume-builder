; `XEPackage0::BucketizingTarget::AllocateSlots'::`1'::dtor$1
; sqldk.dll, primary RVA 0x23094f, 41 bytes in 1 chunk(s)

; chunk at RVA 0x23094f (41 bytes)
0023094f  4055                     push rbp
00230951  4883ec20                 sub rsp, 0x20
00230955  488bea                   mov rbp, rdx
00230958  4c8b85a8000000           mov r8, qword ptr [rbp + 0xa8]
0023095f  488b95b0000000           mov rdx, qword ptr [rbp + 0xb0]
00230966  488b8db8000000           mov rcx, qword ptr [rbp + 0xb8]
0023096d  e89e06ddff               call 0x1010
00230972  4883c420                 add rsp, 0x20
00230976  5d                       pop rbp
00230977  c3                       ret
