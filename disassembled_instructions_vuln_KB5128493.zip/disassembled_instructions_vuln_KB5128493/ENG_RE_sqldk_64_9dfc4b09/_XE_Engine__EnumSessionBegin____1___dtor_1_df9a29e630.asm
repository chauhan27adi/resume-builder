; `XE_Engine::EnumSessionBegin'::`1'::dtor$1
; sqldk.dll, primary RVA 0x2338a0, 56 bytes in 1 chunk(s)

; chunk at RVA 0x2338a0 (56 bytes)
002338a0  4055                     push rbp
002338a2  4883ec30                 sub rsp, 0x30
002338a6  488bea                   mov rbp, rdx
002338a9  c644242806               mov byte ptr [rsp + 0x28], 6
002338ae  8b4560                   mov eax, dword ptr [rbp + 0x60]
002338b1  89442420                 mov dword ptr [rsp + 0x20], eax
002338b5  4c8d0de46e0700           lea r9, [rip + 0x76ee4]
002338bc  41b801000000             mov r8d, 1
002338c2  488b15b7ed1700           mov rdx, qword ptr [rip + 0x17edb7]
002338c9  488b4d68                 mov rcx, qword ptr [rbp + 0x68]
002338cd  e8ee65faff               call 0x1d9ec0
002338d2  4883c430                 add rsp, 0x30
002338d6  5d                       pop rbp
002338d7  c3                       ret
