; `XEPackage0::RingTarget::GetSerializedState'::`1'::dtor$4
; sqldk.dll, primary RVA 0x231da1, 31 bytes in 1 chunk(s)

; chunk at RVA 0x231da1 (31 bytes)
00231da1  4055                     push rbp
00231da3  4883ec20                 sub rsp, 0x20
00231da7  488bea                   mov rbp, rdx
00231daa  4533c0                   xor r8d, r8d
00231dad  488b5560                 mov rdx, qword ptr [rbp + 0x60]
00231db1  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00231db5  e856f2dcff               call 0x1010
00231dba  4883c420                 add rsp, 0x20
00231dbe  5d                       pop rbp
00231dbf  c3                       ret
