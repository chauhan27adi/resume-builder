; AutoMakeMicroSOSThread::FakeTaskFunc
; sqldk.dll, primary RVA 0x8c530, 53 bytes in 1 chunk(s)

; chunk at RVA 0x8c530 (53 bytes)
0008c530  4883ec38                 sub rsp, 0x38
0008c534  488d057dfc2100           lea rax, [rip + 0x21fc7d]
0008c53b  41b98e040000             mov r9d, 0x48e
0008c541  4c8d0538f52100           lea r8, [rip + 0x21f538]
0008c548  4889442420               mov qword ptr [rsp + 0x20], rax
0008c54d  488d15e8f72100           lea rdx, [rip + 0x21f7e8]
0008c554  b901000000               mov ecx, 1
0008c559  e862581200               call 0x1b1dc0
0008c55e  33c0                     xor eax, eax
0008c560  4883c438                 add rsp, 0x38
0008c564  c3                       ret
