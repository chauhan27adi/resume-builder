; MemObjCache<CMemThread<CMemAligned<CMemDbg<CMemObj> > > >::`scalar deleting destructor'
; sqldk.dll, primary RVA 0x13f280, 128 bytes in 1 chunk(s)

; chunk at RVA 0x13f280 (128 bytes)
0013f280  48894c2408               mov qword ptr [rsp + 8], rcx
0013f285  57                       push rdi
0013f286  4883ec30                 sub rsp, 0x30
0013f28a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013f293  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013f298  8bda                     mov ebx, edx
0013f29a  488bf9                   mov rdi, rcx
0013f29d  488d051c521200           lea rax, [rip + 0x12521c]
0013f2a4  488901                   mov qword ptr [rcx], rax
0013f2a7  488d050a881000           lea rax, [rip + 0x10880a]
0013f2ae  488901                   mov qword ptr [rcx], rax
0013f2b1  488d8100050000           lea rax, [rcx + 0x500]
0013f2b8  4889442450               mov qword ptr [rsp + 0x50], rax
0013f2bd  488d0d7ca80f00           lea rcx, [rip + 0xfa87c]
0013f2c4  48894830                 mov qword ptr [rax + 0x30], rcx
0013f2c8  488908                   mov qword ptr [rax], rcx
0013f2cb  488d055ec41000           lea rax, [rip + 0x10c45e]
0013f2d2  488907                   mov qword ptr [rdi], rax
0013f2d5  488bcf                   mov rcx, rdi
0013f2d8  e803f30200               call 0x16e5e0
0013f2dd  83e305                   and ebx, 5
0013f2e0  80fb05                   cmp bl, 5
0013f2e3  750d                     jne 0x13f2f2
0013f2e5  ba28060000               mov edx, 0x628
0013f2ea  488bcf                   mov rcx, rdi
0013f2ed  e81e1decff               call 0x1010
0013f2f2  488bc7                   mov rax, rdi
0013f2f5  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013f2fa  4883c430                 add rsp, 0x30
0013f2fe  5f                       pop rdi
0013f2ff  c3                       ret
