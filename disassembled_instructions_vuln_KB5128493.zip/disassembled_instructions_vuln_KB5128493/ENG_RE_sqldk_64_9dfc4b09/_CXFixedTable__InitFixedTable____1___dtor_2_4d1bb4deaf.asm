; `CXFixedTable::InitFixedTable'::`1'::dtor$2
; sqldk.dll, primary RVA 0x216cb3, 31 bytes in 1 chunk(s)

; chunk at RVA 0x216cb3 (31 bytes)
00216cb3  4055                     push rbp
00216cb5  4883ec20                 sub rsp, 0x20
00216cb9  488bea                   mov rbp, rdx
00216cbc  4533c0                   xor r8d, r8d
00216cbf  488b5568                 mov rdx, qword ptr [rbp + 0x68]
00216cc3  488b4d70                 mov rcx, qword ptr [rbp + 0x70]
00216cc7  e844a3deff               call 0x1010
00216ccc  4883c420                 add rsp, 0x20
00216cd0  5d                       pop rbp
00216cd1  c3                       ret
