; CMemThread<CMemObj>::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13edf0, 55 bytes in 1 chunk(s)

; chunk at RVA 0x13edf0 (55 bytes)
0013edf0  48895c2408               mov qword ptr [rsp + 8], rbx
0013edf5  57                       push rdi
0013edf6  4883ec20                 sub rsp, 0x20
0013edfa  8bda                     mov ebx, edx
0013edfc  488bf9                   mov rdi, rcx
0013edff  e89cb3feff               call 0x12a1a0
0013ee04  83e305                   and ebx, 5
0013ee07  80fb05                   cmp bl, 5
0013ee0a  750d                     jne 0x13ee19
0013ee0c  ba00020000               mov edx, 0x200
0013ee11  488bcf                   mov rcx, rdi
0013ee14  e8f721ecff               call 0x1010
0013ee19  488b5c2430               mov rbx, qword ptr [rsp + 0x30]
0013ee1e  488bc7                   mov rax, rdi
0013ee21  4883c420                 add rsp, 0x20
0013ee25  5f                       pop rdi
0013ee26  c3                       ret
