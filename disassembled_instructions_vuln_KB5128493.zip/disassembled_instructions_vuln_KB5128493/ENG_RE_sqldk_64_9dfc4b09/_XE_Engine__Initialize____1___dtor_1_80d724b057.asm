; `XE_Engine::Initialize'::`1'::dtor$1
; sqldk.dll, primary RVA 0x233f07, 56 bytes in 1 chunk(s)

; chunk at RVA 0x233f07 (56 bytes)
00233f07  4055                     push rbp
00233f09  4883ec30                 sub rsp, 0x30
00233f0d  488bea                   mov rbp, rdx
00233f10  c644242806               mov byte ptr [rsp + 0x28], 6
00233f15  8b4530                   mov eax, dword ptr [rbp + 0x30]
00233f18  89442420                 mov dword ptr [rsp + 0x20], eax
00233f1c  4c8d0d7d680700           lea r9, [rip + 0x7687d]
00233f23  41b801000000             mov r8d, 1
00233f29  488b1550e71700           mov rdx, qword ptr [rip + 0x17e750]
00233f30  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
00233f34  e8875ffaff               call 0x1d9ec0
00233f39  4883c430                 add rsp, 0x30
00233f3d  5d                       pop rbp
00233f3e  c3                       ret
