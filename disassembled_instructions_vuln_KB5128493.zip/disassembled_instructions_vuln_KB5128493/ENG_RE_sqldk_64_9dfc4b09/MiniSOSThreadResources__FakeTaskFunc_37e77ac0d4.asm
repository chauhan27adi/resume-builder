; MiniSOSThreadResources::FakeTaskFunc
; sqldk.dll, primary RVA 0x8bd00, 53 bytes in 1 chunk(s)

; chunk at RVA 0x8bd00 (53 bytes)
0008bd00  4883ec38                 sub rsp, 0x38
0008bd04  488d05f5042200           lea rax, [rip + 0x2204f5]
0008bd0b  41b9d0010000             mov r9d, 0x1d0
0008bd11  4c8d0568fd2100           lea r8, [rip + 0x21fd68]
0008bd18  4889442420               mov qword ptr [rsp + 0x20], rax
0008bd1d  488d1518002200           lea rdx, [rip + 0x220018]
0008bd24  b901000000               mov ecx, 1
0008bd29  e892601200               call 0x1b1dc0
0008bd2e  33c0                     xor eax, eax
0008bd30  4883c438                 add rsp, 0x38
0008bd34  c3                       ret
