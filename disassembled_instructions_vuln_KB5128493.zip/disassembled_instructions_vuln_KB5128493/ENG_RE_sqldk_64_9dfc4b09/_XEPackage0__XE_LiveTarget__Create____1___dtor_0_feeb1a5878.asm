; `XEPackage0::XE_LiveTarget::Create'::`1'::dtor$0
; sqldk.dll, primary RVA 0x231fe0, 32 bytes in 1 chunk(s)

; chunk at RVA 0x231fe0 (32 bytes)
00231fe0  4055                     push rbp
00231fe2  4883ec20                 sub rsp, 0x20
00231fe6  488bea                   mov rbp, rdx
00231fe9  4c8b4568                 mov r8, qword ptr [rbp + 0x68]
00231fed  488b5540                 mov rdx, qword ptr [rbp + 0x40]
00231ff1  488b4d58                 mov rcx, qword ptr [rbp + 0x58]
00231ff5  e816f0dcff               call 0x1010
00231ffa  4883c420                 add rsp, 0x20
00231ffe  5d                       pop rbp
00231fff  c3                       ret
