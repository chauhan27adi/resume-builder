; MemObjCache<CMemAligned<CMemFixed> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13e570, 131 bytes in 1 chunk(s)

; chunk at RVA 0x13e570 (131 bytes)
0013e570  48894c2408               mov qword ptr [rsp + 8], rcx
0013e575  57                       push rdi
0013e576  4883ec30                 sub rsp, 0x30
0013e57a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013e583  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013e588  8bda                     mov ebx, edx
0013e58a  488bf9                   mov rdi, rcx
0013e58d  488d0554ad1000           lea rax, [rip + 0x10ad54]
0013e594  488901                   mov qword ptr [rcx], rax
0013e597  488d05daca1000           lea rax, [rip + 0x10cada]
0013e59e  488901                   mov qword ptr [rcx], rax
0013e5a1  488d05108b1000           lea rax, [rip + 0x108b10]
0013e5a8  488901                   mov qword ptr [rcx], rax
0013e5ab  488d05568c1000           lea rax, [rip + 0x108c56]
0013e5b2  488901                   mov qword ptr [rcx], rax
0013e5b5  4883c138                 add rcx, 0x38
0013e5b9  e8323cedff               call 0x121f0
0013e5be  90                       nop
0013e5bf  488d4f30                 lea rcx, [rdi + 0x30]
0013e5c3  e8283cedff               call 0x121f0
0013e5c8  90                       nop
0013e5c9  c74708adde0080           mov dword ptr [rdi + 8], 0x8000dead
0013e5d0  83e305                   and ebx, 5
0013e5d3  80fb05                   cmp bl, 5
0013e5d6  750d                     jne 0x13e5e5
0013e5d8  ba60010000               mov edx, 0x160
0013e5dd  488bcf                   mov rcx, rdi
0013e5e0  e82b2aecff               call 0x1010
0013e5e5  488bc7                   mov rax, rdi
0013e5e8  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013e5ed  4883c430                 add rsp, 0x30
0013e5f1  5f                       pop rdi
0013e5f2  c3                       ret
