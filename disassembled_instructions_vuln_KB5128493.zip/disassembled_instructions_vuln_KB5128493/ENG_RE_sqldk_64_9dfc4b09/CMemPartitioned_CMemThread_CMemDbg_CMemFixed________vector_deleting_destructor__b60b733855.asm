; CMemPartitioned<CMemThread<CMemDbg<CMemFixed> > >::`vector deleting destructor'
; sqldk.dll, primary RVA 0xce710, 133 bytes in 1 chunk(s)

; chunk at RVA 0xce710 (133 bytes)
000ce710  48894c2408               mov qword ptr [rsp + 8], rcx
000ce715  57                       push rdi
000ce716  4883ec30                 sub rsp, 0x30
000ce71a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000ce723  48895c2448               mov qword ptr [rsp + 0x48], rbx
000ce728  8bda                     mov ebx, edx
000ce72a  488bf9                   mov rdi, rcx
000ce72d  488d0574e91700           lea rax, [rip + 0x17e974]
000ce734  488901                   mov qword ptr [rcx], rax
000ce737  488d8140060000           lea rax, [rcx + 0x640]
000ce73e  4889442450               mov qword ptr [rsp + 0x50], rax
000ce743  488d0df6b31600           lea rcx, [rip + 0x16b3f6]
000ce74a  488908                   mov qword ptr [rax], rcx
000ce74d  488d059caf1700           lea rax, [rip + 0x17af9c]
000ce754  488907                   mov qword ptr [rdi], rax
000ce757  488d87d8040000           lea rax, [rdi + 0x4d8]
000ce75e  4889442458               mov qword ptr [rsp + 0x58], rax
000ce763  48894830                 mov qword ptr [rax + 0x30], rcx
000ce767  488908                   mov qword ptr [rax], rcx
000ce76a  488bcf                   mov rcx, rdi
000ce76d  e8fe270a00               call 0x170f70
000ce772  83e305                   and ebx, 5
000ce775  80fb05                   cmp bl, 5
000ce778  750d                     jne 0xce787
000ce77a  ba78060000               mov edx, 0x678
000ce77f  488bcf                   mov rcx, rdi
000ce782  e88928f3ff               call 0x1010
000ce787  488bc7                   mov rax, rdi
000ce78a  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
000ce78f  4883c430                 add rsp, 0x30
000ce793  5f                       pop rdi
000ce794  c3                       ret
