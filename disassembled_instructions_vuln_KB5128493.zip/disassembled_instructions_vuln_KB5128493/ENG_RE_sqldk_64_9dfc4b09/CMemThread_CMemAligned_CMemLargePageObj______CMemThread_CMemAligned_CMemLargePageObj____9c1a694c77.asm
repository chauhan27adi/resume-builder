; CMemThread<CMemAligned<CMemLargePageObj> >::~CMemThread<CMemAligned<CMemLargePageObj> >
; sqldk.dll, primary RVA 0x117aa0, 63 bytes in 1 chunk(s)

; chunk at RVA 0x117aa0 (63 bytes)
00117aa0  48894c2408               mov qword ptr [rsp + 8], rcx
00117aa5  4883ec38                 sub rsp, 0x38
00117aa9  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
00117ab2  488d051f101300           lea rax, [rip + 0x13101f]
00117ab9  488901                   mov qword ptr [rcx], rax
00117abc  488d81d0010000           lea rax, [rcx + 0x1d0]
00117ac3  4889442448               mov qword ptr [rsp + 0x48], rax
00117ac8  488d1571201200           lea rdx, [rip + 0x122071]
00117acf  48895030                 mov qword ptr [rax + 0x30], rdx
00117ad3  488910                   mov qword ptr [rax], rdx
00117ad6  4883c438                 add rsp, 0x38
00117ada  e9119dffff               jmp 0x1117f0
