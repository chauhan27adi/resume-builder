; MemObjCache<CMemThread<CMemObj> >::`vector deleting destructor'
; sqldk.dll, primary RVA 0x13f140, 79 bytes in 1 chunk(s)

; chunk at RVA 0x13f140 (79 bytes)
0013f140  48894c2408               mov qword ptr [rsp + 8], rcx
0013f145  57                       push rdi
0013f146  4883ec30                 sub rsp, 0x30
0013f14a  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
0013f153  48895c2448               mov qword ptr [rsp + 0x48], rbx
0013f158  8bda                     mov ebx, edx
0013f15a  488bf9                   mov rdi, rcx
0013f15d  488d054c851000           lea rax, [rip + 0x10854c]
0013f164  488901                   mov qword ptr [rcx], rax
0013f167  e834b0feff               call 0x12a1a0
0013f16c  83e305                   and ebx, 5
0013f16f  80fb05                   cmp bl, 5
0013f172  750d                     jne 0x13f181
0013f174  ba50020000               mov edx, 0x250
0013f179  488bcf                   mov rcx, rdi
0013f17c  e88f1eecff               call 0x1010
0013f181  488bc7                   mov rax, rdi
0013f184  488b5c2448               mov rbx, qword ptr [rsp + 0x48]
0013f189  4883c430                 add rsp, 0x30
0013f18d  5f                       pop rdi
0013f18e  c3                       ret
