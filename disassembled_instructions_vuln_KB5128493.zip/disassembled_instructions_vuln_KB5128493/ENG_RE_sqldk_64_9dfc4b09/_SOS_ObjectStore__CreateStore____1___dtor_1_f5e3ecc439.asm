; `SOS_ObjectStore::CreateStore'::`1'::dtor$1
; sqldk.dll, primary RVA 0x22ce4b, 53 bytes in 1 chunk(s)

; chunk at RVA 0x22ce4b (53 bytes)
0022ce4b  4055                     push rbp
0022ce4d  4883ec30                 sub rsp, 0x30
0022ce51  488bea                   mov rbp, rdx
0022ce54  c644242806               mov byte ptr [rsp + 0x28], 6
0022ce59  8b4530                   mov eax, dword ptr [rbp + 0x30]
0022ce5c  89442420                 mov dword ptr [rsp + 0x20], eax
0022ce60  4c8d0da98c0300           lea r9, [rip + 0x38ca9]
0022ce67  41b801000000             mov r8d, 1
0022ce6d  488b5548                 mov rdx, qword ptr [rbp + 0x48]
0022ce71  488b4d38                 mov rcx, qword ptr [rbp + 0x38]
0022ce75  e826afddff               call 0x7da0
0022ce7a  4883c430                 add rsp, 0x30
0022ce7e  5d                       pop rbp
0022ce7f  c3                       ret
