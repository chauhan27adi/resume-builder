; `FixedArray<XEPackage0::Rid,1024>::~FixedArray<XEPackage0::Rid,1024>'::`1'::dtor$0
; sqldk.dll, primary RVA 0x22fdc0, 42 bytes in 1 chunk(s)

; chunk at RVA 0x22fdc0 (42 bytes)
0022fdc0  4055                     push rbp
0022fdc2  4883ec20                 sub rsp, 0x20
0022fdc6  488bea                   mov rbp, rdx
0022fdc9  488b4d40                 mov rcx, qword ptr [rbp + 0x40]
0022fdcd  4c8d0decbcf8ff           lea r9, [rip - 0x74314]
0022fdd4  41b800040000             mov r8d, 0x400
0022fdda  ba10000000               mov edx, 0x10
0022fddf  e87ceedfff               call 0x2ec60
0022fde4  4883c420                 add rsp, 0x20
0022fde8  5d                       pop rbp
0022fde9  c3                       ret
