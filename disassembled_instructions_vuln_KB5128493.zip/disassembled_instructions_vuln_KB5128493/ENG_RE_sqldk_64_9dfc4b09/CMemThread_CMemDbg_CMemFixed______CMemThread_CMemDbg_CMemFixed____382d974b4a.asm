; CMemThread<CMemDbg<CMemFixed> >::~CMemThread<CMemDbg<CMemFixed> >
; sqldk.dll, primary RVA 0xfe730, 63 bytes in 1 chunk(s)

; chunk at RVA 0xfe730 (63 bytes)
000fe730  48894c2408               mov qword ptr [rsp + 8], rcx
000fe735  4883ec38                 sub rsp, 0x38
000fe739  48c7442420feffffff       mov qword ptr [rsp + 0x20], 0xfffffffffffffffe
000fe742  488d05a7af1400           lea rax, [rip + 0x14afa7]
000fe749  488901                   mov qword ptr [rcx], rax
000fe74c  488d81d8040000           lea rax, [rcx + 0x4d8]
000fe753  4889442448               mov qword ptr [rsp + 0x48], rax
000fe758  488d15e1b31300           lea rdx, [rip + 0x13b3e1]
000fe75f  48895030                 mov qword ptr [rax + 0x30], rdx
000fe763  488910                   mov qword ptr [rax], rdx
000fe766  4883c438                 add rsp, 0x38
000fe76a  e901280700               jmp 0x170f70
