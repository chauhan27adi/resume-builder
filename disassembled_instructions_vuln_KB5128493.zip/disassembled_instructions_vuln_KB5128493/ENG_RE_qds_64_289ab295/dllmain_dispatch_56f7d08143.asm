; dllmain_dispatch
; qds.dll, primary RVA 0x10b0, 176 bytes in 1 chunk(s)

; chunk at RVA 0x10b0 (176 bytes)
000010b0  488bc4                   mov rax, rsp
000010b3  48895820                 mov qword ptr [rax + 0x20], rbx
000010b7  4c894018                 mov qword ptr [rax + 0x18], r8
000010bb  895010                   mov dword ptr [rax + 0x10], edx
000010be  48894808                 mov qword ptr [rax + 8], rcx
000010c2  56                       push rsi
000010c3  57                       push rdi
000010c4  4156                     push r14
000010c6  4883ec40                 sub rsp, 0x40
000010ca  498bf0                   mov rsi, r8
000010cd  8bfa                     mov edi, edx
000010cf  4c8bf1                   mov r14, rcx
000010d2  85d2                     test edx, edx
000010d4  0f849e4a0d00             je 0xd5b78
000010da  8d42ff                   lea eax, [rdx - 1]
000010dd  83f801                   cmp eax, 1
000010e0  7732                     ja 0x1114
000010e2  488b05cf000f00           mov rax, qword ptr [rip + 0xf00cf]
000010e9  4885c0                   test rax, rax
000010ec  0f859a4a0d00             jne 0xd5b8c
000010f2  c744243001000000         mov dword ptr [rsp + 0x30], 1
000010fa  eb01                     jmp 0x10fd
000010fc  cc                       int3
000010fd  4c8bc6                   mov r8, rsi
00001100  8bd7                     mov edx, edi
00001102  498bce                   mov rcx, r14
00001105  e826ffffff               call 0x1030
0000110a  8bd8                     mov ebx, eax
0000110c  89442430                 mov dword ptr [rsp + 0x30], eax
00001110  85c0                     test eax, eax
00001112  7425                     je 0x1139
00001114  4c8bc6                   mov r8, rsi
00001117  8bd7                     mov edx, edi
00001119  498bce                   mov rcx, r14
0000111c  e83f000000               call 0x1160
00001121  8bd8                     mov ebx, eax
00001123  89442430                 mov dword ptr [rsp + 0x30], eax
00001127  83ff01                   cmp edi, 1
0000112a  0f84764a0d00             je 0xd5ba6
00001130  85ff                     test edi, edi
00001132  7471                     je 0x11a5
00001134  83ff03                   cmp edi, 3
00001137  746c                     je 0x11a5
00001139  eb01                     jmp 0x113c
0000113b  cc                       int3
0000113c  8bc3                     mov eax, ebx
0000113e  488b5c2478               mov rbx, qword ptr [rsp + 0x78]
00001143  4883c440                 add rsp, 0x40
00001147  415e                     pop r14
00001149  5f                       pop rdi
0000114a  5e                       pop rsi
0000114b  c3                       ret
0000114c  90                       nop
0000114d  90                       nop
0000114e  90                       nop
0000114f  90                       nop
00001150  90                       nop
00001151  90                       nop
00001152  90                       nop
00001153  90                       nop
00001154  90                       nop
00001155  90                       nop
00001156  90                       nop
00001157  90                       nop
00001158  90                       nop
00001159  90                       nop
0000115a  90                       nop
0000115b  90                       nop
0000115c  90                       nop
0000115d  90                       nop
0000115e  90                       nop
0000115f  90                       nop
