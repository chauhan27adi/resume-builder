
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong *param_2,ulonglong param_3)

{
  undefined4 uVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  undefined8 uVar5;
  longlong lVar6;
  undefined *puVar7;
  undefined *puVar8;
  bool bVar9;
  undefined8 uStack_c0;
  undefined auStack_b8 [8];
  undefined auStack_b0 [24];
  longlong lStack_98;
  undefined4 auStack_90 [2];
  longlong lStack_88;
  undefined4 auStack_80 [2];
  longlong lStack_78;
  uint auStack_70 [4];
  undefined8 uStack_60;
  longlong lStack_58;
  longlong lStack_50;
  longlong lStack_48;
  undefined auStack_40 [8];
  undefined auStack_38 [16];
  undefined4 uStack_28;
  ulonglong uStack_20;
  
  puVar7 = auStack_b8;
  puVar8 = auStack_b8;
  uStack_20 = _DAT_ ^ (ulonglong)auStack_b8;
  lStack_58 = 0;
  uStack_60 = 0;
  uStack_28 = 0;
  auStack_38 = ZEXT816(0);
  uVar5 = (*_DAT_)(0);
  (*_DAT_)(uVar5);
  iVar3 = (*_DAT_)();
  auStack_70[2] = iVar3 << 0x10;
  uVar4 = (*_DAT_)();
  auStack_70[2] = auStack_70[2] | uVar4;
  if (*param_2 < param_3) {
    lStack_50 = 0;
    if (_DAT_ == 0) {
      iVar3 = (*_DAT_)(&lStack_50,0x108750,0,0);
      puVar7 = auStack_b8;
      if (iVar3 < 0) {
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(7);
        puVar7 = auStack_b0;
      }
      LOCK();
      bVar9 = _DAT_ == 0;
      if (bVar9) {
        _DAT_ = lStack_50;
      }
      UNLOCK();
      if (!bVar9) {
        *(undefined8 *)(puVar7 + -8) = 0x1000c3;
        (*_DAT_)(lStack_50,0);
      }
    }
    *(undefined4 *)(puVar7 + 0x30) = 0;
    *(undefined4 *)(puVar7 + 0x28) = 0;
    *(undefined8 *)(puVar7 + 0x20) = 0;
    *(undefined8 *)(puVar7 + -8) = 0x1000e9;
    iVar3 = (*_DAT_)(_DAT_,&uStack_60,0,0);
    puVar8 = puVar7;
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar8 = puVar7 + 8;
    }
    *(undefined8 *)(puVar8 + -8) = 0x100109;
    iVar3 = (*_DAT_)(uStack_60,auStack_70 + 2,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar8 = puVar8 + 8;
    }
    *(undefined8 *)(puVar8 + -8) = 0x10012c;
    iVar3 = (*_DAT_)(uStack_60,0x10f2dc,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar8 = puVar8 + 8;
    }
    *(undefined8 *)(puVar8 + -8) = 0x10014f;
    iVar3 = (*_DAT_)(uStack_60,0x10f2cc,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar8 = puVar8 + 8;
    }
    *(undefined8 *)(puVar8 + -8) = 0x100172;
    iVar3 = (*_DAT_)(uStack_60,0x10f2e4,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar8 = puVar8 + 8;
    }
    *(undefined8 *)(puVar8 + -8) = 0x100195;
    iVar3 = (*_DAT_)(uStack_60,0x10f2c8,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar8 = puVar8 + 8;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1001b5;
    iVar3 = (*_DAT_)(uStack_60,auStack_38,0x14);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar8 = puVar8 + 8;
    }
    *(undefined8 *)(puVar8 + -8) = 0x1001ca;
    (*_DAT_)(uStack_60);
    uStack_60 = 0;
    if (lStack_58 != 0) {
      *(undefined8 *)(puVar8 + -8) = 0x1001dd;
      (*_DAT_)();
    }
    lStack_48 = 0;
    if (_DAT_ == 0) {
      *(undefined8 *)(puVar8 + -8) = 0x100201;
      iVar3 = (*_DAT_)(&lStack_48,0x108760,0,0);
      if (iVar3 < 0) {
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(7);
        puVar8 = puVar8 + 8;
      }
      LOCK();
      bVar9 = _DAT_ == 0;
      if (bVar9) {
        _DAT_ = lStack_48;
      }
      UNLOCK();
      if (!bVar9) {
        *(undefined8 *)(puVar8 + -8) = 0x100229;
        (*_DAT_)(lStack_48,0);
      }
    }
    *(undefined4 *)(puVar8 + 0x30) = 0;
    *(undefined4 *)(puVar8 + 0x28) = 0x14;
    *(undefined **)(puVar8 + 0x20) = auStack_38;
    *(undefined8 *)(puVar8 + -8) = 0x100256;
    iVar3 = (*_DAT_)(_DAT_,&lStack_58,0,0);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar8 = puVar8 + 8;
    }
    lVar6 = lStack_58;
    uVar1 = *(undefined4 *)param_2;
    *(undefined4 *)(puVar8 + 0x48) = 0;
    *(undefined **)(puVar8 + 0x40) = auStack_40;
    *(undefined4 *)(puVar8 + 0x38) = uVar1;
    *(longlong *)(puVar8 + 0x30) = param_1;
    *(undefined4 *)(puVar8 + 0x28) = 0;
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x100296;
    iVar3 = (*_DAT_)(lVar6,param_1,uVar1,0);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar8 = puVar8 + 8;
    }
    *(uint *)(param_1 + *param_2) = auStack_70[2];
    *param_2 = *param_2 + 4;
    *(undefined8 *)(puVar8 + -8) = 0x1002b8;
    (*_DAT_)(lStack_58);
    puVar7 = auStack_38;
    for (lVar6 = 0x14; lVar6 != 0; lVar6 = lVar6 + -1) {
      *puVar7 = 0;
      puVar7 = puVar7 + 1;
    }
  }
  *(undefined8 *)(puVar8 + -8) = 0x1002d1;
  func_0x(uStack_20 ^ (ulonglong)puVar8);
  return;
}

