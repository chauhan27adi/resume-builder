
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong *param_2,ulonglong param_3)

{
  undefined4 uVar1;
  code *pcVar2;
  int iVar3;
  longlong lVar4;
  undefined *puVar5;
  undefined *puVar6;
  bool bVar7;
  undefined8 uStack_c0;
  undefined auStack_b8 [8];
  undefined auStack_b0 [24];
  longlong lStack_98;
  undefined4 auStack_90 [2];
  longlong lStack_88;
  undefined4 auStack_80 [2];
  longlong lStack_78;
  undefined4 auStack_70 [2];
  undefined8 uStack_68;
  longlong lStack_60;
  undefined4 auStack_58 [2];
  longlong lStack_50;
  longlong lStack_48;
  undefined auStack_40 [8];
  undefined auStack_38 [16];
  undefined4 uStack_28;
  ulonglong uStack_20;
  
  puVar6 = auStack_b8;
  puVar5 = auStack_b8;
  uStack_20 = _DAT_ ^ (ulonglong)auStack_b8;
  *param_2 = *param_2 - 4;
  uStack_28 = 0;
  lStack_60 = 0;
  uStack_68 = 0;
  auStack_38 = ZEXT816(0);
  if (*param_2 < param_3) {
    auStack_58[0] = *(undefined4 *)(*param_2 + param_1);
    lStack_50 = 0;
    if (_DAT_ == 0) {
      iVar3 = (*_DAT_)(&lStack_50,0x108460,0,0);
      puVar5 = auStack_b8;
      if (iVar3 < 0) {
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(7);
        puVar5 = auStack_b0;
      }
      LOCK();
      bVar7 = _DAT_ == 0;
      if (bVar7) {
        _DAT_ = lStack_50;
      }
      UNLOCK();
      if (!bVar7) {
        *(undefined8 *)(puVar5 + -8) = 0x1000a0;
        (*_DAT_)(lStack_50,0);
      }
    }
    *(undefined4 *)(puVar5 + 0x30) = 0;
    *(undefined4 *)(puVar5 + 0x28) = 0;
    *(undefined8 *)(puVar5 + 0x20) = 0;
    *(undefined8 *)(puVar5 + -8) = 0x1000c4;
    iVar3 = (*_DAT_)(_DAT_,&uStack_68,0,0);
    puVar6 = puVar5;
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar6 = puVar5 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1000e4;
    iVar3 = (*_DAT_)(uStack_68,auStack_58,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar6 = puVar6 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x100107;
    iVar3 = (*_DAT_)(uStack_68,0x10efec,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar6 = puVar6 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x10012a;
    iVar3 = (*_DAT_)(uStack_68,0x10efdc,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar6 = puVar6 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x10014d;
    iVar3 = (*_DAT_)(uStack_68,0x10eff4,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar6 = puVar6 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x100170;
    iVar3 = (*_DAT_)(uStack_68,0x10efd8,4);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar6 = puVar6 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x100190;
    iVar3 = (*_DAT_)(uStack_68,auStack_38,0x14);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar6 = puVar6 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x1001a5;
    (*_DAT_)(uStack_68);
    uStack_68 = 0;
    if (lStack_60 != 0) {
      *(undefined8 *)(puVar6 + -8) = 0x1001b8;
      (*_DAT_)();
    }
    lStack_48 = 0;
    if (_DAT_ == 0) {
      *(undefined8 *)(puVar6 + -8) = 0x1001dc;
      iVar3 = (*_DAT_)(&lStack_48,0x108470,0,0);
      if (iVar3 < 0) {
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(7);
        puVar6 = puVar6 + 8;
      }
      LOCK();
      bVar7 = _DAT_ == 0;
      if (bVar7) {
        _DAT_ = lStack_48;
      }
      UNLOCK();
      if (!bVar7) {
        *(undefined8 *)(puVar6 + -8) = 0x100204;
        (*_DAT_)(lStack_48,0);
      }
    }
    *(undefined4 *)(puVar6 + 0x30) = 0;
    *(undefined4 *)(puVar6 + 0x28) = 0x14;
    *(undefined **)(puVar6 + 0x20) = auStack_38;
    *(undefined8 *)(puVar6 + -8) = 0x100230;
    iVar3 = (*_DAT_)(_DAT_,&lStack_60,0,0);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar6 = puVar6 + 8;
    }
    lVar4 = lStack_60;
    uVar1 = *(undefined4 *)param_2;
    *(undefined4 *)(puVar6 + 0x48) = 0;
    *(undefined **)(puVar6 + 0x40) = auStack_40;
    *(undefined4 *)(puVar6 + 0x38) = uVar1;
    *(longlong *)(puVar6 + 0x30) = param_1;
    *(undefined4 *)(puVar6 + 0x28) = 0;
    *(undefined8 *)(puVar6 + 0x20) = 0;
    *(undefined8 *)(puVar6 + -8) = 0x10026e;
    iVar3 = (*_DAT_)(lVar4,param_1,uVar1,0);
    if (iVar3 < 0) {
      pcVar2 = (code *)swi(0x29);
      (*pcVar2)(7);
      puVar6 = puVar6 + 8;
    }
    *(undefined8 *)(puVar6 + -8) = 0x100283;
    (*_DAT_)(lStack_60);
    puVar5 = auStack_38;
    for (lVar4 = 0x14; lVar4 != 0; lVar4 = lVar4 + -1) {
      *puVar5 = 0;
      puVar5 = puVar5 + 1;
    }
  }
  *(undefined8 *)(puVar6 + -8) = 0x10029c;
  func_0x(uStack_20 ^ (ulonglong)puVar6);
  return;
}

