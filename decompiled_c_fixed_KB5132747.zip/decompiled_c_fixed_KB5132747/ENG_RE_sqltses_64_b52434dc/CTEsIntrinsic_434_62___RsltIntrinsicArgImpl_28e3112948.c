
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,char *param_2)

{
  uint uVar1;
  code *UNRECOVERED_JUMPTABLE;
  int iVar2;
  undefined8 uVar3;
  undefined8 uStackX_8;
  undefined8 uStackX_10;
  undefined8 uStackX_18;
  undefined8 uStackX_20;
  
  if (*param_2 != '\x03') {
    uStackX_8 = param_1;
    uVar1 = (*_DAT_)();
    if (((uVar1 & 0x1c) != 0) && ((*_DAT_)(), (uVar1 & 0x10) != 0)) {
      (*_DAT_)();
    }
    (*_DAT_)(0x9001f,0x8031f);
    uVar3 = (*_DAT_)(*(undefined8 *)(param_2 + 8));
    *(undefined8 *)(param_2 + 8) = uVar3;
    uVar1 = (*_DAT_)();
    if ((uVar1 & 0x1c) != 0) {
      (*_DAT_)();
      if ((uVar1 & 0x10) != 0) {
        (*_DAT_)();
      }
      if ((uVar1 & 8) == 0) {
        if ((uVar1 & 4) == 0) {
          if ((uVar1 & 0x10) == 0) {
            return;
          }
          iVar2 = 3;
        }
        else {
          iVar2 = 0;
        }
      }
      else {
        iVar2 = 2;
      }
      (**(code **)*_DAT_)(_DAT_,&uStackX_10);
      uVar3 = (**(code **)(*_DAT_ + 8))(_DAT_,uStackX_10);
      func_0x(uVar3,2);
      (**(code **)*_DAT_)(_DAT_,&uStackX_18);
      uVar3 = (**(code **)(*_DAT_ + 8))(_DAT_,uStackX_18);
      func_0x(uVar3,0x1000);
      (**(code **)*_DAT_)(_DAT_,&uStackX_20);
      (**(code **)(*_DAT_ + 0x20))(_DAT_,&uStackX_8,uStackX_20);
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)*(uint *)((longlong)iVar2 * 4 + 0x100244) - 0x2d5210);
                    /* WARNING: Could not recover jumptable at 0x0010014f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
  }
  return;
}

