
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1)

{
  longlong *plVar1;
  char cVar2;
  
  cVar2 = (*_DAT_)();
  if (cVar2 == '\0') {
    (*_DAT_)(*param_1);
  }
  plVar1 = *(longlong **)((longlong)*(int *)(**param_1 + 4) + 0x48 + (longlong)*param_1);
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x10))();
  }
  return;
}

