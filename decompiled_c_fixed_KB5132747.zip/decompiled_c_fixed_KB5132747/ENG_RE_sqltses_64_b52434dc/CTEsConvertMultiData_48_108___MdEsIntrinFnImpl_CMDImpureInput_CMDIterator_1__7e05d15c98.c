
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,ushort **param_2,longlong *param_3,longlong *param_4)

{
  short sVar1;
  byte *pbVar2;
  longlong lVar3;
  undefined auVar4 [16];
  bool bVar5;
  byte bVar6;
  byte bVar7;
  int iVar8;
  int iVar9;
  undefined8 uVar10;
  longlong lVar11;
  longlong lVar12;
  ushort *puVar13;
  ulonglong uVar14;
  byte bVar15;
  uint uVar16;
  short *psVar17;
  ushort uVar18;
  ushort uVar19;
  int iVar20;
  longlong *plVar21;
  longlong lVar22;
  longlong *plVar23;
  byte bVar24;
  uint uVar25;
  ulonglong uVar26;
  char cVar27;
  undefined8 in_R10;
  ulonglong uVar28;
  uint uVar29;
  short sVar30;
  ushort uVar31;
  short asStack_10858 [32648];
  undefined auStack_948 [32];
  ulonglong uStack_928;
  undefined4 uStack_920;
  uint uStack_918;
  uint uStack_910;
  uint uStack_908;
  uint uStack_900;
  longlong *plStack_8f8;
  uint uStack_8f0;
  longlong *plStack_8e8;
  ushort **ppuStack_8e0;
  longlong *plStack_8d8;
  char cStack_8d0;
  undefined uStack_8cf;
  ushort uStack_8ce;
  undefined uStack_8c8;
  undefined7 uStack_8c7;
  undefined4 uStack_8c0;
  undefined4 uStack_8bc;
  undefined4 uStack_8b8;
  undefined4 uStack_8b4;
  undefined8 uStack_8b0;
  undefined4 uStack_8a8;
  undefined8 uStack_8a0;
  undefined8 uStack_898;
  undefined4 uStack_890;
  undefined4 uStack_88c;
  undefined8 uStack_888;
  undefined8 uStack_880;
  undefined8 auStack_878 [2];
  ushort auStack_868 [4];
  short *psStack_860;
  short asStack_858 [1024];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_948;
  pbVar2 = (byte *)param_3[1];
  uVar28 = CONCAT71((int7)((ulonglong)in_R10 >> 8),1);
  cVar27 = '\0';
  bVar6 = *pbVar2;
  uVar26 = 0;
  uStack_8f0 = (uint)uVar28;
  lVar22 = 0x7fffffffffffffff;
  if ((byte)(bVar6 + 0x10) < 2) {
    bVar15 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x1993f0) * 4 + 0x199553);
    uVar16 = (uint)bVar15;
    bVar24 = *(byte *)(*(longlong *)(*param_1 + 0x20) + 0xc);
    uVar25 = (uint)bVar24;
    if ((bVar6 == 0xf0) || (bVar6 == 0xf1)) {
      bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x1993f0) * 4 + 0x199552);
    }
    else {
      bVar6 = pbVar2[0x12];
    }
  }
  else {
    bVar15 = pbVar2[0x13];
    uVar16 = (uint)bVar15;
    bVar6 = pbVar2[0x12];
    bVar24 = *(byte *)(*(longlong *)(*param_1 + 0x20) + 0xc);
    uVar25 = (uint)bVar24;
  }
  iVar20 = (bVar6 - uVar16) + uVar25;
  pbVar2 = (byte *)param_4[2];
  bVar6 = *pbVar2;
  if ((byte)(bVar6 + 0x10) < 2) {
    bVar7 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x1993f0) * 4 + 0x199552);
  }
  else {
    bVar7 = pbVar2[0x12];
  }
  if (bVar7 < 0x13) {
    if ((byte)(bVar6 + 0x10) < 2) {
      bVar6 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar6 + 0x1993f0) * 4 + 0x199552);
    }
    else {
      bVar6 = pbVar2[0x12];
    }
    uVar29 = (uint)bVar6;
  }
  else {
    uVar29 = 0x12;
  }
  plStack_8f8 = param_3;
  plStack_8e8 = param_4;
  ppuStack_8e0 = param_2;
  plStack_8d8 = param_1;
  if (bVar24 < bVar15) {
    (**(code **)*_DAT_)(_DAT_,&uStack_888);
    uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_888);
    iVar8 = func_0x(uVar10);
    uVar28 = (ulonglong)(uStack_8f0 & 0xff);
    if (iVar8 != 0) {
      uVar28 = uVar26;
    }
    if (((int)(uVar16 - uVar25) < 0x13) && (0 < iVar20 + 1)) {
      uVar26 = *(ulonglong *)((ulonglong)(uVar16 - uVar25) * 8 + 0x1df880);
      cVar27 = ((int)uVar29 < iVar20 + 1) + '\x05';
      bVar5 = false;
    }
    else {
      bVar5 = false;
      cVar27 = '\x04';
    }
  }
  else if (bVar15 < bVar24) {
    if ((int)(uVar25 - uVar16) < 0x13) {
      uVar26 = *(ulonglong *)((ulonglong)(uVar25 - uVar16) * 8 + 0x1df880);
      if ((int)uVar29 < iVar20) {
        cVar27 = (0x12 < iVar20) + '\x02';
        bVar5 = false;
      }
      else {
        bVar5 = false;
        cVar27 = '\x01';
      }
    }
    else {
      uVar28 = 0;
      bVar5 = false;
    }
  }
  else {
    cVar27 = '\0';
    if ((int)uVar29 < iVar20) {
      cVar27 = '\a';
    }
    bVar5 = (int)uVar29 >= iVar20;
  }
  bVar6 = *(byte *)(*(longlong *)(*plStack_8d8 + 0x20) + 0xd);
  if (bVar6 < 0x13) {
    lVar22 = *(longlong *)((ulonglong)bVar6 * 8 + 0x1df7e0);
  }
  uVar19 = 0;
  auStack_868[0] = 0;
  if (bVar5) {
    uVar19 = **param_2;
    lVar22 = *plStack_8e8;
    if (0 < (short)uVar19) {
      uVar26 = (ulonglong)uVar19;
      psVar17 = *(short **)(*param_2 + 4);
      lVar3 = *plStack_8f8;
      do {
        sVar30 = *psVar17;
        psVar17 = psVar17 + 1;
        *(undefined8 *)(lVar22 + (longlong)sVar30 * 8) =
             *(undefined8 *)((longlong)sVar30 * 8 + lVar3);
        uVar26 = uVar26 - 1;
      } while (uVar26 != 0);
    }
    *param_2 = auStack_868;
  }
  else if ((char)uVar28 != '\0') {
    psStack_860 = (short *)0x0;
    auStack_868[0] = 0xffff;
    uVar18 = 0;
    lVar3 = *plStack_8e8;
    switch(cVar27) {
    case '\x01':
      puVar13 = *param_2;
      if (0 < (short)*puVar13) {
        lVar22 = *plStack_8f8;
        uVar18 = uVar19;
        do {
          sVar30 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)(short)uVar19 * 2);
          uVar28 = *(ulonglong *)(lVar22 + (longlong)sVar30 * 8);
          *(ulonglong *)(lVar3 + (longlong)sVar30 * 8) = uVar28 * uVar26;
          if ((uVar28 & 1) != 0) {
            lVar11 = (longlong)(short)uVar18;
            uVar18 = uVar18 + 1;
            asStack_858[lVar11] = sVar30;
          }
          uVar19 = uVar19 + 1;
        } while ((short)uVar19 < (short)*puVar13);
      }
      break;
    case '\x02':
      puVar13 = *param_2;
      uVar18 = uVar19;
      if (0 < (short)*puVar13) {
        lVar11 = *plStack_8f8;
        do {
          sVar30 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)(short)uVar19 * 2);
          uVar28 = *(ulonglong *)(lVar11 + (longlong)sVar30 * 8);
          lVar12 = uVar28 * uVar26;
          if ((lVar12 - lVar22 != 0 && lVar22 <= lVar12) || (bVar5 = false, lVar12 < -lVar22)) {
            bVar5 = true;
          }
          *(longlong *)((longlong)sVar30 * 8 + lVar3) = lVar12;
          if (((uVar28 & 1) != 0) || (bVar5)) {
            lVar12 = (longlong)(short)uVar18;
            uVar18 = uVar18 + 1;
            asStack_858[lVar12] = sVar30;
          }
          uVar19 = uVar19 + 1;
        } while ((short)uVar19 < (short)*puVar13);
      }
      break;
    case '\x03':
      puVar13 = *param_2;
      if (0 < (short)*puVar13) {
        lVar11 = *plStack_8f8;
        uVar18 = uVar19;
        do {
          sVar30 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)(short)uVar19 * 2);
          lVar12 = (longlong)sVar30 * 8;
          uVar28 = *(ulonglong *)(lVar12 + lVar11);
          uVar14 = uVar26 * uVar28;
          bVar6 = 0;
          if ((uVar14 - lVar22 != 0 && lVar22 <= (longlong)uVar14) ||
             (SBORROW8(uVar14,-lVar22) != (longlong)(uVar14 + lVar22) < 0)) {
            bVar6 = 1;
          }
          *(ulonglong *)(lVar12 + lVar3) = uVar14;
          if (((uVar28 & 1) != 0) ||
             ((bool)(bVar6 | 1 < (SUB168(SEXT816((longlong)uVar26) * SEXT816((longlong)uVar28),8) <<
                                  1 | uVar14 >> 0x3f) + 1))) {
            lVar12 = (longlong)(short)uVar18;
            uVar18 = uVar18 + 1;
            asStack_858[lVar12] = sVar30;
          }
          uVar19 = uVar19 + 1;
          param_2 = ppuStack_8e0;
        } while ((short)uVar19 < (short)*puVar13);
      }
      break;
    case '\x04':
      puVar13 = *param_2;
      sVar30 = 0;
      if (0 < (short)*puVar13) {
        lVar22 = *plStack_8f8;
        do {
          sVar1 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar30 * 2);
          bVar6 = *(byte *)(lVar22 + (longlong)sVar1 * 8);
          *(undefined8 *)(lVar3 + (longlong)sVar1 * 8) = 0;
          if ((bVar6 & 1) != 0) {
            lVar11 = (longlong)(short)uVar19;
            uVar19 = uVar19 + 1;
            asStack_858[lVar11] = sVar1;
          }
          sVar30 = sVar30 + 1;
          uVar18 = uVar19;
        } while (sVar30 < (short)*puVar13);
      }
      break;
    case '\x05':
      puVar13 = *param_2;
      uVar18 = uVar19;
      if (0 < (short)*puVar13) {
        lVar22 = *plStack_8f8;
        do {
          sVar30 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)(short)uVar19 * 2);
          uVar28 = *(ulonglong *)(lVar22 + (longlong)sVar30 * 8);
          uVar14 = (longlong)uVar28 / (longlong)uVar26;
          *(ulonglong *)((longlong)sVar30 * 8 + lVar3) =
               (uVar14 >> 0x3f ^ 1) + uVar14 & 0xfffffffffffffffe;
          if ((uVar28 & 1) != 0) {
            lVar11 = (longlong)(short)uVar18;
            uVar18 = uVar18 + 1;
            asStack_858[lVar11] = sVar30;
          }
          uVar19 = uVar19 + 1;
        } while ((short)uVar19 < (short)*puVar13);
      }
      break;
    case '\x06':
      puVar13 = *param_2;
      uVar18 = uVar19;
      if (0 < (short)*puVar13) {
        lVar11 = *plStack_8f8;
        do {
          sVar30 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)(short)uVar19 * 2);
          uVar28 = *(ulonglong *)(lVar11 + (longlong)sVar30 * 8);
          if ((longlong)uVar28 < 1) {
            if (uVar28 == 0x8000000000000000) {
              auVar4._8_8_ = 0;
              auVar4._0_8_ = uVar26;
              lVar12 = SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x8000000000000000)) / auVar4,0);
            }
            else {
              lVar12 = -((longlong)uVar28 / (longlong)uVar26);
            }
            uVar14 = -(lVar12 + 1U & 0xfffffffffffffffe);
          }
          else {
            uVar14 = (longlong)uVar28 / (longlong)uVar26 + 1U & 0xfffffffffffffffe;
          }
          if ((lVar22 < (longlong)uVar14) || ((longlong)uVar14 < -lVar22)) {
            bVar5 = true;
          }
          else {
            bVar5 = false;
          }
          *(ulonglong *)((longlong)sVar30 * 8 + lVar3) = uVar14;
          if (((uVar28 & 1) != 0) || (bVar5)) {
            lVar12 = (longlong)(short)uVar18;
            uVar18 = uVar18 + 1;
            asStack_858[lVar12] = sVar30;
          }
          uVar19 = uVar19 + 1;
          param_2 = ppuStack_8e0;
        } while ((short)uVar19 < (short)*puVar13);
      }
      break;
    case '\a':
      puVar13 = *param_2;
      sVar30 = 0;
      uVar18 = uVar19;
      if (0 < (short)*puVar13) {
        lVar11 = *plStack_8f8;
        do {
          sVar1 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar30 * 2);
          uVar26 = *(ulonglong *)(lVar11 + (longlong)sVar1 * 8);
          if ((lVar22 < (longlong)uVar26) ||
             (bVar5 = false, SBORROW8(uVar26,-lVar22) != (longlong)(uVar26 + lVar22) < 0)) {
            bVar5 = true;
          }
          *(ulonglong *)((longlong)sVar1 * 8 + lVar3) = uVar26;
          if (((uVar26 & 1) != 0) || (bVar5)) {
            lVar12 = (longlong)(short)uVar18;
            uVar18 = uVar18 + 1;
            asStack_858[lVar12] = sVar1;
          }
          sVar30 = sVar30 + 1;
          param_2 = ppuStack_8e0;
        } while (sVar30 < (short)*puVar13);
      }
      break;
    default:
      puVar13 = *param_2;
      uVar18 = uVar19;
      uVar31 = uVar19;
      if (0 < (short)*puVar13) {
        do {
          sVar30 = *(short *)(*(longlong *)(puVar13 + 4) + (longlong)(short)uVar31 * 2);
          lVar22 = (longlong)sVar30 * 8;
          uVar26 = *(ulonglong *)(lVar22 + *plStack_8f8);
          uStack_928 = 0x1e2868;
          (*_DAT_)(1,0x1e1f60,0x1e20d8,0xdd);
          *(undefined8 *)(lVar22 + lVar3) = uStack_8b0;
          if ((uVar26 & 1) != 0) {
            lVar22 = (longlong)(short)uVar19;
            uVar19 = uVar19 + 1;
            asStack_858[lVar22] = sVar30;
          }
          puVar13 = *param_2;
          uVar31 = uVar31 + 1;
          uVar18 = uVar19;
        } while ((short)uVar31 < (short)*puVar13);
      }
    }
    *param_2 = auStack_868;
    auStack_868[0] = uVar18;
  }
  psStack_860 = asStack_858;
  puVar13 = *param_2;
  if (0 < (short)*puVar13) {
    lVar22 = *plStack_8e8;
    uStack_8c8 = 0;
    uStack_8c7 = 0;
    uStack_8c0 = 0;
    uStack_8bc = 0;
    cStack_8d0 = '\0';
    uStack_8cf = 0x30;
    uStack_8ce = 0;
    sVar30 = 0;
    uStack_8b8 = 0;
    plVar21 = plStack_8d8;
    plVar23 = plStack_8e8;
    do {
      lVar3 = (longlong)*(short *)(*(longlong *)(puVar13 + 4) + (longlong)sVar30 * 2) * 8;
      if (*(ulonglong *)(lVar3 + *plStack_8f8) == 1) {
        *(undefined8 *)(lVar3 + lVar22) = 1;
      }
      else {
        uVar26 = *(ulonglong *)(lVar3 + *plStack_8f8) >> 1;
        uStack_8c8 = (undefined)uVar26;
        cStack_8d0 = '\0';
        uStack_8cf = 0x30;
        uStack_8a8 = 0x6c00;
        uStack_8a0 = 0;
        uStack_898 = 0;
        uStack_890 = 0;
        uStack_8f0 = func_0x
                               (&uStack_8a0,uVar26 & 0xff,
                                *(undefined *)(*(longlong *)(*plVar21 + 0x20) + 0xd),
                                *(undefined *)(*(longlong *)(*plVar21 + 0x20) + 0xc));
        cStack_8d0 = (char)uStack_8a8;
        uStack_8cf = (undefined)((uint)uStack_8a8 >> 8);
        uStack_8c8 = (undefined)uStack_8a0;
        uStack_8c7 = (undefined7)((ulonglong)uStack_8a0 >> 8);
        uStack_8c0 = (undefined4)uStack_898;
        uStack_8bc = uStack_898._4_4_;
        uStack_8b8 = uStack_890;
        uStack_8b4 = uStack_88c;
        uStack_8ce = (ushort)((uint)uStack_8a8 >> 0x10) & 0xfffe;
        if (uStack_8f0 != 0) {
          (**(code **)*_DAT_)(_DAT_,&uStack_880);
          uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_880);
          iVar20 = func_0x(uVar10,0x800);
          (**(code **)*_DAT_)(_DAT_,auStack_878);
          uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,auStack_878[0]);
          iVar8 = func_0x(uVar10,0x10000000);
          (**(code **)*_DAT_)(_DAT_,&uStack_8b0);
          uVar10 = (**(code **)(*_DAT_ + 8))(_DAT_,uStack_8b0);
          iVar9 = func_0x(uVar10,0x1000);
          uStack_900 = (uint)(iVar20 != 0);
          uStack_908 = (uint)(iVar8 != 0);
          uStack_910 = (uint)(iVar9 != 0);
          uStack_918 = *(byte *)(*(longlong *)(*plStack_8d8 + 0x20) + 0x11) & 0x80;
          uStack_920 = 0;
          uStack_928 = uStack_928 & 0xffffffff00000000;
          func_0x(uStack_8f0,&cStack_8d0,0x6c,0x30);
          plVar21 = plStack_8d8;
          plVar23 = plStack_8e8;
        }
        if (cStack_8d0 == '\x03') {
          ppuStack_8e0 = (ushort **)0x1;
        }
        else {
          uStack_928 = uStack_928 & 0xffffffff00000000;
          func_0x
                    (&cStack_8d0,&ppuStack_8e0,plVar23[2],*(undefined8 *)(*plVar21 + 0x80));
        }
        *(ushort ***)(lVar3 + lVar22) = ppuStack_8e0;
      }
      puVar13 = *param_2;
      sVar30 = sVar30 + 1;
    } while (sVar30 < (short)*puVar13);
  }
  func_0x(uStack_58 ^ (ulonglong)auStack_948);
  return;
}

