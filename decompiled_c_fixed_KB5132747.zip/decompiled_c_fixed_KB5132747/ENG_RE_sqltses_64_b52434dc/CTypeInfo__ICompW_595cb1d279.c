
/* WARNING: Control flow encountered bad instruction data */

int FUN_(byte *param_1,undefined8 param_2,uint param_3,undefined8 param_4,uint param_5)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined8 in_stack_ffffffffffffffc8;
  undefined4 uVar5;
  
  uVar5 = (undefined4)((ulonglong)in_stack_ffffffffffffffc8 >> 0x20);
  if (*(char *)((ulonglong)*(byte *)((ulonglong)*param_1 + 0x559830) + 0x559930) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar1 = *(uint *)(param_1 + 0x14);
  if ((*(int *)((ulonglong)(uVar1 & 0x7f) * 0x20 + 0x555470) == 0x409) && ((uVar1 >> 0xc & 1) != 0))
  {
    param_5 = param_5 >> 1;
    uVar4 = func_0x(param_1);
    iVar3 = func_0x(uVar4 | 0x8000000,(byte)(uVar1 >> 0x11) & 0x7f,param_2,param_3 >> 1,
                            param_4,param_5);
  }
  else {
    cVar2 = func_0x(param_1);
    if (cVar2 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iVar3 = func_0x(0x8000000,param_2,param_3 >> 1,param_4,CONCAT44(uVar5,param_5 >> 1));
  }
  return iVar3 + -2;
}

