
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(double param_1,char *param_2)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  undefined4 uVar4;
  double dStackX_8;
  undefined8 uStackX_10;
  undefined8 uStackX_18;
  undefined8 uStackX_20;
  
  if (*param_2 == '\x03') {
    return;
  }
  dStackX_8 = param_1;
  func_0x(param_2 + 8,&dStackX_8);
  iVar1 = func_0x(param_2 + 8,dStackX_8 * _DAT_);
  if (iVar1 == 0) {
    return;
  }
  (**(code **)*_DAT_)(_DAT_,&uStackX_10);
  uVar3 = (**(code **)(*_DAT_ + 8))(_DAT_,uStackX_10);
  func_0x(uVar3,2);
  (**(code **)*_DAT_)(_DAT_,&uStackX_18);
  uVar3 = (**(code **)(*_DAT_ + 8))(_DAT_,uStackX_18);
  iVar2 = func_0x(uVar3,0x1000);
  (**(code **)*_DAT_)(_DAT_,&uStackX_20);
  (**(code **)(*_DAT_ + 0x20))(_DAT_,&dStackX_8,uStackX_20);
  switch(iVar1) {
  case 1:
    (**(code **)(*plRam00000000002c7aa8 + 8))(plRam00000000002c7aa8,1,1);
    uVar3 = func_0x(0x3c);
    (*_DAT_)(0x51,0xf,0x10,2,0x1c7840,uVar3);
    *param_2 = '\x03';
    break;
  case 3:
    uVar3 = 0x22;
    uVar4 = 0x51;
    goto code_r0x001001bb;
  case 4:
    uVar3 = 0x17;
    uVar4 = 0x24;
code_r0x001001bb:
    (*_DAT_)(uVar4,uVar3,0x10);
    *param_2 = '\x03';
    break;
  case 5:
    *(undefined8 *)(param_2 + 8) = 0;
    break;
  case 6:
    param_2[8] = '\x05';
    *(undefined8 *)(param_2 + 0xc) = 0;
    *(undefined8 *)(param_2 + 0x14) = 0;
    param_2[0xb] = '\x01';
    break;
  case 7:
    uVar3 = func_0x
                      (CONCAT71((int7)((ulonglong)*(uint *)((longlong)(iVar1 + -1) * 4 + 0x100204) -
                                       0x2d7cf0 >> 8),0x6c));
    (*_DAT_)(0x51,0xf,0x10,1,uVar3,uVar3);
  default:
    if (iVar2 == 0) {
      *(undefined8 *)(param_2 + 8) = 0;
      *param_2 = '\x03';
    }
    else {
      (*_DAT_)(0x24,2,0x19,0xf9);
    }
  }
  return;
}

