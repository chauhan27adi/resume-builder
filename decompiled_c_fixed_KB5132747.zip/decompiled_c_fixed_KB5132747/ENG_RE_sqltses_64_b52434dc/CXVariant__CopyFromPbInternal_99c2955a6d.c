
/* WARNING: Control flow encountered bad instruction data */

void FUN_(undefined *param_1,longlong param_2,uint param_3,byte *param_4)

{
  param_1[1] = *param_4;
  if (param_2 == 0) {
LAB_:
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *param_1 = 0;
  if ((*(short *)(param_4 + 0x10) != -1) &&
     (*(char *)((ulonglong)*(byte *)((ulonglong)*param_4 + 0x5570c0) + 0x5ed3e0) == '\0')) {
                    /* WARNING (jumptable): Sanity check requires truncation of jumptable */
                    /* WARNING: Could not find normalized switch variable to match jumptable */
    switch(*param_4) {
    case 0x1f:
      goto LAB_;
    default:
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  *(longlong *)(param_1 + 8) = param_2;
  *(ulonglong *)(param_1 + 0x10) = (ulonglong)param_3;
  return;
}

