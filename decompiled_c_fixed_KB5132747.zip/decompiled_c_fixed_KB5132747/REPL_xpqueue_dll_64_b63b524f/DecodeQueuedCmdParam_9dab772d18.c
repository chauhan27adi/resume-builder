
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(double *param_1,ulonglong param_2,undefined4 param_3,undefined4 param_4,
                 longlong *param_5,uint *param_6,int *param_7)

{
  undefined uVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  byte bVar6;
  byte bVar7;
  byte bVar8;
  ushort uVar9;
  ushort uVar10;
  ushort uVar11;
  ushort uVar12;
  ushort uVar13;
  short sVar14;
  float fVar15;
  undefined auVar16 [16];
  double dVar17;
  longlong *plVar18;
  uint *puVar19;
  int *piVar20;
  uint uVar21;
  int iVar22;
  int iVar23;
  longlong lVar24;
  undefined8 uVar25;
  longlong lVar26;
  short *psVar27;
  ulonglong uVar28;
  ulonglong uVar29;
  longlong lVar30;
  undefined8 *puVar31;
  uint uVar32;
  uint auStackX_8 [2];
  float afStackX_10 [2];
  uint auStackX_18 [2];
  ulonglong uStack_2168;
  double *pdStack_2160;
  undefined4 uStack_2158;
  undefined2 uStack_2154;
  undefined4 uStack_2150;
  undefined2 uStack_214c;
  undefined4 uStack_2148;
  undefined2 uStack_2144;
  undefined8 uStack_2140;
  undefined2 uStack_2138;
  undefined8 uStack_2130;
  undefined2 uStack_2128;
  undefined8 uStack_2120;
  undefined4 uStack_2118;
  undefined4 uStack_2108;
  undefined4 uStack_2104;
  undefined4 uStack_2100;
  undefined4 uStack_20fc;
  undefined4 uStack_20f8;
  undefined4 uStack_20f4;
  undefined4 uStack_20f0;
  undefined4 uStack_20ec;
  undefined4 uStack_20e8;
  undefined4 uStack_20e4;
  undefined4 uStack_20e0;
  undefined4 uStack_20dc;
  undefined4 uStack_20d8;
  undefined4 uStack_20d4;
  undefined4 uStack_20d0;
  undefined4 uStack_20cc;
  undefined8 uStack_20c8;
  undefined2 uStack_20c0;
  undefined4 uStack_20b8;
  undefined4 uStack_20b4;
  undefined4 uStack_20b0;
  undefined4 uStack_20ac;
  undefined4 uStack_20a8;
  undefined4 uStack_20a4;
  undefined4 uStack_20a0;
  undefined4 uStack_209c;
  undefined4 uStack_2098;
  undefined4 uStack_2094;
  undefined4 uStack_2090;
  undefined4 uStack_208c;
  undefined4 uStack_2088;
  undefined4 uStack_2084;
  undefined4 uStack_2080;
  undefined4 uStack_207c;
  undefined4 uStack_2078;
  undefined4 uStack_2074;
  undefined4 uStack_2070;
  undefined4 uStack_206c;
  undefined4 uStack_2068;
  undefined4 uStack_2064;
  undefined4 uStack_2060;
  undefined4 uStack_205c;
  undefined4 uStack_2058;
  undefined2 uStack_2054;
  short asStack_2048 [4096];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x100022;
  lVar24 = func_0x();
  piVar20 = param_7;
  puVar19 = param_6;
  plVar18 = param_5;
  lVar24 = -lVar24;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar24);
  uStack_2168 = 0;
  *(undefined4 *)((longlong)&param_7 + lVar24) = 0;
  uStack_2158 = _DAT_;
  uStack_2154 = _DAT_;
  uStack_2118 = _DAT_;
  uStack_2120 = _DAT_;
  uStack_2128 = _DAT_;
  uStack_2130 = _DAT_;
  uStack_20c0 = _DAT_;
  uStack_2108 = _DAT_;
  uStack_2104 = uRam0000000000106974;
  uStack_2100 = uRam0000000000106978;
  uStack_20fc = uRam000000000010697c;
  uStack_2058 = _DAT_;
  uStack_20e8 = _DAT_;
  uStack_20e4 = uRam0000000000106994;
  uStack_20e0 = uRam0000000000106998;
  uStack_20dc = uRam000000000010699c;
  uStack_2054 = _DAT_;
  uStack_20f8 = _DAT_;
  uStack_20f4 = uRam0000000000106984;
  uStack_20f0 = uRam0000000000106988;
  uStack_20ec = uRam000000000010698c;
  uStack_20c8 = _DAT_;
  uStack_2148 = _DAT_;
  uStack_20d8 = _DAT_;
  uStack_20d4 = uRam00000000001069a4;
  uStack_20d0 = uRam00000000001069a8;
  uStack_20cc = uRam00000000001069ac;
  uStack_20b8 = _DAT_;
  uStack_20b4 = uRam00000000001069c4;
  uStack_20b0 = uRam00000000001069c8;
  uStack_20ac = uRam00000000001069cc;
  uStack_2144 = _DAT_;
  uStack_2150 = _DAT_;
  uStack_20a8 = _DAT_;
  uStack_20a4 = uRam00000000001069d4;
  uStack_20a0 = uRam00000000001069d8;
  uStack_209c = uRam00000000001069dc;
  uStack_2098 = _DAT_;
  uStack_2094 = uRam00000000001069e4;
  uStack_2090 = uRam00000000001069e8;
  uStack_208c = uRam00000000001069ec;
  uStack_214c = _DAT_;
  uStack_2088 = _DAT_;
  uStack_2084 = uRam00000000001069f4;
  uStack_2080 = uRam00000000001069f8;
  uStack_207c = uRam00000000001069fc;
  uStack_2078 = _DAT_;
  uStack_2074 = uRam0000000000106a04;
  uStack_2070 = uRam0000000000106a08;
  uStack_206c = uRam0000000000106a0c;
  *(undefined4 *)(&stack0x00000044 + lVar24) = param_3;
  iVar22 = *piVar20;
  param_2 = param_2 & 0xffffffff;
  uVar29 = (ulonglong)*param_6;
  uStack_2138 = _DAT_;
  *(undefined4 *)((longlong)&param_7 + lVar24 + 4) = param_4;
  uStack_2068 = _DAT_;
  uStack_2064 = uRam0000000000106a14;
  uStack_2060 = uRam0000000000106a18;
  uStack_205c = uRam0000000000106a1c;
  *(undefined4 *)(&stack0x00000040 + lVar24) = 0x27;
  uStack_2140 = _DAT_;
  pdStack_2160 = param_1;
LAB_:
  iVar23 = (int)param_2;
  if ((uint)uVar29 < (uint)(iVar22 + 6 + iVar23)) {
    do {
      auVar16 = ZEXT816(2) * ZEXT416((int)(uVar29 >> 1) + 0x1001);
      uVar25 = auVar16._0_8_;
      if (auVar16._8_8_ != 0) {
        uVar25 = 0xffffffffffffffff;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1001dc;
      lVar26 = func_0x(uVar25);
      *puVar19 = *puVar19 + 0x2000;
      uVar32 = *puVar19;
      *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1001fb;
      func_0x(lVar26,0,(uVar32 & 0xfffffffe) + 2);
      if (*plVar18 != 0) {
        uVar32 = *puVar19;
        *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100214;
        (*_DAT_)(lVar26,(uVar32 >> 1) + 1);
        lVar30 = *plVar18;
        *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100222;
        func_0x(lVar30,2);
      }
      *plVar18 = lVar26;
      iVar22 = *piVar20;
      uVar29 = (ulonglong)*puVar19;
    } while (*puVar19 < (uint)(iVar22 + 6 + iVar23));
  }
  else {
    lVar26 = *plVar18;
  }
  uVar32 = (uint)uVar29;
  if (param_1 == (double *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x10072b;
    (*_DAT_)(lVar26,(uVar32 >> 1) + 1,&uStack_2140);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (*(short *)((longlong)&uStack_2140 + lVar30 * 2) != 0);
    *piVar20 = *piVar20 + (int)lVar30 * 2;
    goto LAB_;
  }
  switch(*(undefined4 *)(&stack0x00000044 + lVar24)) {
  case 2:
  case 3:
  case 8:
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100711;
    (*pcRam0000000000104d28)(lVar26,(uVar32 >> 1) + 1,param_1,param_2 >> 1);
    *piVar20 = *piVar20 + iVar23;
    goto LAB_;
  case 4:
    fVar15 = *(float *)param_1;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100445;
    func_0x(asStack_2048,0x1000,&uStack_2158,fVar15);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 5:
    sVar14 = *(short *)param_1;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100417;
    func_0x(asStack_2048,0x1000,&uStack_2158,(int)sVar14);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 6:
  case 7:
    if (iVar23 == 4) {
      puVar31 = &uStack_2130;
      dVar17 = (double)*(float *)param_1;
    }
    else {
      dVar17 = *param_1;
      puVar31 = &uStack_2120;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x10048f;
    func_0x(asStack_2048,0x1000,puVar31,dVar17);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 9:
    uVar9 = *(ushort *)((longlong)param_1 + 10);
    uVar10 = *(ushort *)(param_1 + 1);
    uVar11 = *(ushort *)((longlong)param_1 + 6);
    uVar12 = *(ushort *)((longlong)param_1 + 4);
    uVar13 = *(ushort *)((longlong)param_1 + 2);
    sVar14 = *(short *)param_1;
    *(float *)((longlong)afStackX_10 + lVar24) = *(float *)((longlong)param_1 + 0xc);
    *(uint *)((longlong)auStackX_8 + lVar24) = (uint)uVar9;
    *(uint *)(&stack0x00000000 + lVar24) = (uint)uVar10;
    *(uint *)(&stack0xfffffffffffffff8 + lVar24) = (uint)uVar11;
    *(uint *)(&stack0xfffffffffffffff0 + lVar24) = (uint)uVar12;
    *(uint *)(&stack0xffffffffffffffe8 + lVar24) = (uint)uVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1004fd;
    func_0x(asStack_2048,0x1000,&uStack_2108,(int)sVar14);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 0xfffffff5:
    bVar2 = *(byte *)((longlong)param_1 + 0xe);
    bVar3 = *(byte *)((longlong)param_1 + 0xd);
    bVar4 = *(byte *)((longlong)param_1 + 0xc);
    bVar5 = *(byte *)((longlong)param_1 + 0xb);
    bVar6 = *(byte *)((longlong)param_1 + 10);
    bVar7 = *(byte *)((longlong)param_1 + 9);
    bVar8 = *(byte *)(param_1 + 1);
    uVar9 = *(ushort *)((longlong)param_1 + 6);
    uVar10 = *(ushort *)((longlong)param_1 + 4);
    *(uint *)((longlong)&param_6 + lVar24) = (uint)*(byte *)((longlong)param_1 + 0xf);
    *(uint *)((longlong)&param_5 + lVar24) = (uint)bVar2;
    *(uint *)(&stack0x00000020 + lVar24) = (uint)bVar3;
    *(uint *)((longlong)auStackX_18 + lVar24) = (uint)bVar4;
    *(uint *)((longlong)afStackX_10 + lVar24) = (uint)bVar5;
    *(uint *)((longlong)auStackX_8 + lVar24) = (uint)bVar6;
    *(uint *)(&stack0x00000000 + lVar24) = (uint)bVar7;
    *(uint *)(&stack0xfffffffffffffff8 + lVar24) = (uint)bVar8;
    *(uint *)(&stack0xfffffffffffffff0 + lVar24) = (uint)uVar9;
    *(uint *)(&stack0xffffffffffffffe8 + lVar24) = (uint)uVar10;
    fVar15 = *(float *)pdStack_2160;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100593;
    func_0x(asStack_2048,0x1000,&uStack_20b8,fVar15);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
      param_1 = pdStack_2160;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 0xfffffff6:
  case 0xfffffff7:
  case 0xfffffff8:
    iVar22 = *(int *)((longlong)&param_7 + lVar24 + 4);
    if (iVar22 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1006a0;
      (*_DAT_)(lVar26,(uVar32 >> 1) + 1,&uStack_2148);
      *piVar20 = *piVar20 + 2;
      uVar29 = (ulonglong)*puVar19;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1006c1;
    (*pcRam0000000000104d28)(lVar26,(int)(uVar29 >> 1) + 1,param_1,param_2 >> 1);
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1006cd;
    iVar23 = (*pcRam0000000000104d18)(param_1,param_2 >> 1);
    *piVar20 = *piVar20 + iVar23 * 2;
    if (iVar22 == 0) goto LAB_;
    uVar32 = *puVar19;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1006f1;
    (*_DAT_)(lVar26,(uVar32 >> 1) + 1,&stack0x00000040 + lVar24);
    *piVar20 = *piVar20 + 2;
    goto code_r0x00100749;
  case 0xfffffff9:
  case 0xfffffffa:
    uVar1 = *(undefined *)param_1;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1003ae;
    func_0x(asStack_2048,0x1000,&uStack_2158,uVar1);
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  default:
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1005d0;
    func_0x(asStack_2048,0x1000,0x106a60,*(undefined4 *)(&stack0x00000044 + lVar24));
    lVar30 = -1;
    do {
      lVar30 = lVar30 + 1;
    } while (asStack_2048[lVar30] != 0);
    break;
  case 0xfffffffc:
  case 0xfffffffd:
  case 0xfffffffe:
    uVar28 = (ulonglong)*(uint *)((longlong)&param_7 + lVar24);
    if (*(uint *)((longlong)&param_7 + lVar24) == 0) {
      uVar28 = param_2;
    }
    *(int *)((longlong)&param_7 + lVar24) = (int)uVar28;
    iVar23 = (int)uVar28 * 4;
    param_2 = (ulonglong)(iVar23 + 4);
    if ((uint)(iVar23 + 10 + iVar22) <= uVar32) {
      *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100329;
      (*_DAT_)(lVar26,(uVar32 >> 1) + 1,0x106a44);
      *piVar20 = *piVar20 + 4;
      uVar32 = *(uint *)((longlong)&param_7 + lVar24);
      if (uVar32 == 0) goto LAB_;
      goto code_r0x00100340;
    }
    goto LAB_;
  case 0xffffffff:
  case 1:
  case 0xc:
    goto code_r0x00100278;
  }
  iVar22 = *piVar20;
  uVar21 = (int)lVar30 * 2;
  param_2 = (ulonglong)uVar21;
  uVar32 = *puVar19;
  uVar29 = (ulonglong)uVar32;
  if (iVar22 + 6 + uVar21 <= uVar32) {
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1003f5;
    (*_DAT_)(lVar26,(uVar32 >> 1) + 1,asStack_2048);
    *piVar20 = *piVar20 + uVar21;
    goto LAB_;
  }
  goto LAB_;
code_r0x00100278:
  uVar28 = (ulonglong)*(uint *)((longlong)&param_7 + lVar24);
  if (*(uint *)((longlong)&param_7 + lVar24) == 0) {
    uVar28 = param_2;
  }
  iVar23 = (int)uVar28;
  *(int *)((longlong)&param_7 + lVar24) = iVar23;
  param_2 = (ulonglong)(uint)(iVar23 * 2);
  if (iVar23 * 2 + 6U + iVar22 <= uVar32) goto code_r0x00100296;
  goto LAB_;
code_r0x00100296:
  if (*(int *)((longlong)&param_7 + lVar24 + 4) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1002b2;
    (*_DAT_)(lVar26,(uVar32 >> 1) + 1,&stack0x00000040 + lVar24);
    *piVar20 = *piVar20 + 2;
    iVar23 = *(int *)((longlong)&param_7 + lVar24);
  }
  uVar32 = iVar23 + 1;
  if (uVar32 < 0x1001) {
    psVar27 = asStack_2048;
    uVar32 = 0x1000;
  }
  else {
    uVar25 = SUB168(ZEXT816(2) * ZEXT416(uVar32),0);
    if (SUB168(ZEXT816(2) * ZEXT416(uVar32),8) != 0) {
      uVar25 = 0xffffffffffffffff;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x1002e6;
    psVar27 = (short *)func_0x(uVar25);
    iVar23 = *(int *)((longlong)&param_7 + lVar24);
  }
  *(uint *)(&stack0xfffffffffffffff0 + lVar24) = uVar32;
  *(short **)(&stack0xffffffffffffffe8 + lVar24) = psVar27;
  *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x10061d;
  iVar22 = (*pcRam0000000000104b90)(0,0,param_1,iVar23);
  psVar27[iVar22] = 0;
  uVar21 = *puVar19;
  *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x10063d;
  (*_DAT_)(lVar26,(uVar21 >> 1) + 1,psVar27);
  *piVar20 = *piVar20 + iVar22 * 2;
  if (*(int *)((longlong)&param_7 + lVar24 + 4) != 0) {
    uVar21 = *puVar19;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100660;
    (*_DAT_)(lVar26,(uVar21 >> 1) + 1,&stack0x00000040 + lVar24);
    *piVar20 = *piVar20 + 2;
  }
  if (0x1000 < uVar32) {
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x10067d;
    func_0x(psVar27);
  }
  goto LAB_;
  while( true ) {
    uVar1 = *(undefined *)param_1;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100365;
    func_0x(asStack_2048,0x1000,0x106a50,uVar1);
    uVar21 = *puVar19;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x10037c;
    (*_DAT_)(lVar26,(uVar21 >> 1) + 1,asStack_2048);
    param_1 = (double *)((longlong)param_1 + 1);
    *piVar20 = *piVar20 + 4;
    uVar21 = (int)uStack_2168 + 1;
    uStack_2168 = (ulonglong)uVar21;
    if (uVar32 <= uVar21) break;
code_r0x00100340:
    if (param_1 == (double *)0x0) break;
  }
LAB_:
  if (*(int *)((longlong)&param_7 + lVar24 + 4) != 0) {
code_r0x00100749:
    lVar30 = -1;
    uVar32 = *puVar19;
    *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x10075d;
    (*_DAT_)(lVar26,(uVar32 >> 1) + 1,&uStack_2150);
    do {
      lVar30 = lVar30 + 1;
    } while (*(short *)((longlong)&uStack_2150 + lVar30 * 2) != 0);
    *piVar20 = *piVar20 + (int)lVar30 * 2;
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar24) = 0x100782;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar24));
  return;
}

