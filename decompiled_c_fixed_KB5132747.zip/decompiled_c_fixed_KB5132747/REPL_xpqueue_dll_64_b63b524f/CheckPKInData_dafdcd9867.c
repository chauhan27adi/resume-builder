
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,uint param_2,uint *param_3,uint param_4,uint param_5,
                 longlong param_6,undefined8 param_7,longlong param_8)

{
  uint *puVar1;
  longlong lVar2;
  byte bVar3;
  uint uVar4;
  undefined (*pauVar5) [16];
  code *pcVar6;
  byte bVar7;
  int iVar8;
  uint uVar9;
  longlong lVar10;
  longlong lVar11;
  undefined8 uVar12;
  uint uVar13;
  uint *puVar14;
  uint uVar15;
  longlong lVar16;
  uint *puVar17;
  int iVar18;
  short *psVar19;
  ulonglong uVar20;
  undefined8 uVar21;
  undefined auStack_1e8 [32];
  uint uStack_1c8;
  undefined8 uStack_1c0;
  uint uStack_1b8;
  uint uStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_198;
  uint uStack_190;
  uint uStack_18c;
  uint *puStack_188;
  undefined8 uStack_180;
  undefined2 uStack_178;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined2 uStack_15c;
  undefined2 auStack_158 [136];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1e8;
  uVar15 = 0;
  uStack_180 = 0;
  uStack_178 = 0;
  uStack_160 = _DAT_;
  uStack_15c = _DAT_;
  uStack_170 = _DAT_;
  uStack_16c = uRam000000000010a73c;
  uStack_168 = uRam000000000010a740;
  uStack_164 = uRam000000000010a744;
  uStack_198 = param_1;
  if (param_4 == *param_3) {
    puVar17 = (uint *)((ulonglong)param_4 + (longlong)param_3);
    if ((param_3 + 1 < puVar17) && (puVar14 = param_3 + 2, param_2 <= param_3[1])) {
      uVar13 = uVar15;
      if (param_2 != 0xffffffff) {
        do {
          if (puVar17 <= puVar14) goto LAB_;
          uVar13 = uVar13 + 1;
          puVar14 = (uint *)((longlong)puVar14 + (ulonglong)*puVar14);
        } while (uVar13 < param_2 + 1);
      }
      if ((((puVar14 < puVar17) && ((uint *)((ulonglong)*puVar14 + (longlong)puVar14) <= puVar17))
          && (puVar14 + 1 < puVar17)) && ((uint *)((longlong)puVar14 + 9U) < puVar17)) {
        uVar13 = *(uint *)((longlong)puVar14 + 9U);
        puVar1 = (uint *)((longlong)puVar14 + 0x11);
        if (((puVar1 < puVar17) &&
            ((uint *)((ulonglong)uVar13 + (longlong)puVar1) <=
             (uint *)((ulonglong)*puVar14 + (longlong)puVar14))) && (uVar13 < 0x102)) {
          func_0x(auStack_158,puVar1,(ulonglong)uVar13);
          uVar20 = (ulonglong)uVar13 & 0xfffffffffffffffe;
          if (0x101 < uVar20) {
            func_0x();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
          }
          *(undefined2 *)((longlong)auStack_158 + uVar20) = 0;
          lVar10 = (*_DAT_)(auStack_158,param_7);
          if ((lVar10 != 0) && (lVar10 = (*_DAT_)(auStack_158,&uStack_170), lVar10 != 0)) {
            lVar16 = -1;
            lVar11 = -1;
            do {
              lVar2 = lVar11 * 2;
              lVar11 = lVar11 + 1;
            } while (*(short *)((longlong)&uStack_170 + lVar2 + 2) != 0);
            iVar18 = 3;
            (*_DAT_)(&uStack_180,5,lVar10 + lVar11 * 2,3);
            uVar21 = uStack_198;
            uStack_180 = uStack_180 & 0xffffffffffff;
            if (*(int *)(param_6 + 0x34) == 0) {
              uStack_1a8 = 0;
              uStack_1b0 = 6;
              uStack_1b8 = 0xe7;
              uStack_1c0 = CONCAT44(uStack_1c0._4_4_,6);
              uStack_1c8 = 0xe7;
              *(undefined *)(param_6 + 2) = 0xe7;
              *(undefined4 *)(param_6 + 4) = 6;
              *(undefined *)(param_6 + 8) = 0xe7;
              *(undefined4 *)(param_6 + 0xc) = 6;
              iVar8 = (*_DAT_)(uStack_198,1,param_6 + 0x10,*(undefined4 *)(param_6 + 0x30));
              if (iVar8 != 1) goto LAB_;
              *(undefined4 *)(param_6 + 0x34) = 1;
            }
            lVar10 = -1;
            do {
              lVar11 = lVar10 * 2;
              lVar10 = lVar10 + 1;
            } while (*(short *)((longlong)&uStack_180 + lVar11 + 2) != 0);
            (*_DAT_)(uVar21,1,(int)lVar10 * 2);
            (*_DAT_)(uVar21,1,&uStack_180);
            if (*(int *)(param_6 + 0x7c) == 0) {
              uStack_1a8 = 0;
              uStack_1b0 = 0x8c;
              uStack_1b8 = 0xe7;
              uStack_1c0 = CONCAT44(uStack_1c0._4_4_,0x8c);
              uStack_1c8 = 0xe7;
              *(undefined *)(param_6 + 0x4a) = 0xe7;
              *(undefined4 *)(param_6 + 0x4c) = 0x8c;
              *(undefined *)(param_6 + 0x50) = 0xe7;
              *(undefined4 *)(param_6 + 0x54) = 0x8c;
              iVar8 = (*_DAT_)(uVar21,2,param_6 + 0x58,*(undefined4 *)(param_6 + 0x78));
              if (iVar8 != 2) goto LAB_;
              *(undefined4 *)(param_6 + 0x7c) = 1;
            }
            do {
              lVar10 = lVar16 * 2;
              lVar16 = lVar16 + 1;
            } while (*(short *)(param_8 + 2 + lVar10) != 0);
            (*_DAT_)(uVar21,2,(int)lVar16 * 2);
            (*_DAT_)(uVar21,2,param_8);
            uVar13 = uVar15;
            do {
              if (puVar17 <= puVar14) goto LAB_;
              uVar13 = uVar13 + 1;
              puVar14 = (uint *)((longlong)puVar14 + (ulonglong)*puVar14);
            } while (uVar13 < 3);
            uStack_190 = 0;
            if (param_5 != 0) {
              psVar19 = (short *)(param_6 + 0x90);
              do {
                for (; uVar15 != (int)*psVar19 - 1U; uVar15 = uVar15 + 1) {
                  if (puVar17 <= puVar14) goto LAB_;
                  puVar14 = (uint *)((longlong)puVar14 + (ulonglong)*puVar14);
                }
                if (((puVar17 <= puVar14) ||
                    (puStack_188 = (uint *)((ulonglong)*puVar14 + (longlong)puVar14),
                    puVar17 < puStack_188)) || (puVar17 <= puVar14 + 1)) goto LAB_;
                bVar3 = *(byte *)(puVar14 + 1);
                if (puVar17 <= (uint *)((longlong)puVar14 + 5U)) goto LAB_;
                uVar13 = *(uint *)((longlong)puVar14 + 5U);
                if (puVar17 <= (uint *)((longlong)puVar14 + 9U)) goto LAB_;
                uVar4 = *(uint *)((longlong)puVar14 + 9U);
                uVar20 = (ulonglong)uVar4;
                if (puVar17 <= (uint *)((longlong)puVar14 + 0xdU)) goto LAB_;
                uStack_18c = *(uint *)((longlong)puVar14 + 0xdU);
                puVar14 = (uint *)((longlong)puVar14 + 0x11);
                if (((puVar17 <= puVar14) || (puStack_188 < (uint *)((longlong)puVar14 + uVar20)))
                   || ((*(int *)(psVar19 + 0x1a) != 0 && (bVar3 != *(byte *)(psVar19 + 1)))))
                goto LAB_;
                if (uStack_18c == 0) {
                  switch(bVar3) {
                  case 0x24:
                    uVar9 = 0x10;
                    break;
                  default:
                    goto LAB_;
                  case 0x30:
                  case 0x32:
                    uVar9 = 1;
                    break;
                  case 0x34:
                    uVar9 = 2;
                    break;
                  case 0x38:
                  case 0x3a:
                  case 0x3b:
                  case 0x7a:
                    uVar9 = 4;
                    break;
                  case 0x3c:
                  case 0x3d:
                  case 0x3e:
                  case 0x7f:
                    uVar9 = 8;
                  }
                  if (uVar4 < uVar9) goto LAB_;
                }
LAB_:
                if (*(int *)(psVar19 + 0x1a) == 0) {
                  *(byte *)(psVar19 + 1) = bVar3;
                  *(uint *)(psVar19 + 2) = uVar13;
                  *(byte *)(psVar19 + 4) = bVar3;
                  *(uint *)(psVar19 + 6) = uVar13;
                  if ((((byte)(bVar3 - 0x37) < 0x34) &&
                      ((0x8000000000101U >> ((ulonglong)(bVar3 - 0x37 & 0xff) & 0x3f) & 1) != 0)) ||
                     (bVar7 = bVar3, bVar3 == 0x6c)) {
                    uVar13 = 0x13;
                    *(undefined4 *)(psVar19 + 2) = 0x13;
                    *(undefined *)(psVar19 + 4) = 0x37;
                    *(undefined4 *)(psVar19 + 6) = 0x13;
                    bVar7 = 0x37;
                  }
                  uStack_1a8 = 0;
                  uStack_1b8 = (uint)bVar7;
                  uStack_1c0 = CONCAT44(uStack_1c0._4_4_,uVar13);
                  uStack_1c8 = (uint)bVar3;
                  uStack_1b0 = uVar13;
                  iVar8 = (*_DAT_)(uStack_198,iVar18,psVar19 + 8,
                                           *(undefined4 *)(psVar19 + 0x18));
                  if (iVar8 != iVar18) goto LAB_;
                  *(undefined4 *)(psVar19 + 0x1a) = 1;
                }
                uVar21 = uStack_198;
                if (uStack_18c == 0) {
                  if (((byte)(bVar3 - 0x37) < 0x36) &&
                     ((0x28000000000101U >> ((ulonglong)(byte)(bVar3 - 0x37) & 0x3f) & 1) != 0)) {
                    if (*(longlong *)(psVar19 + 0x1c) != 0) {
                      func_0x(*(longlong *)(psVar19 + 0x1c),1);
                    }
                    uVar12 = func_0x();
                    uVar21 = uStack_198;
                    *(undefined8 *)(psVar19 + 0x1c) = uVar12;
                    pauVar5 = *(undefined (**) [16])(psVar19 + 0x1c);
                    uStack_1b8 = 0x13;
                    *pauVar5 = ZEXT816(0);
                    *(undefined2 *)pauVar5[1] = 0;
                    pauVar5[1][2] = 0;
                    **(undefined **)(psVar19 + 0x1c) = *(undefined *)(psVar19 + 0x20);
                    *(undefined *)(*(longlong *)(psVar19 + 0x1c) + 1) =
                         *(undefined *)((longlong)psVar19 + 0x41);
                    uStack_1c0 = *(undefined8 *)(psVar19 + 0x1c);
                    uStack_1c8 = 0x37;
                    iVar8 = (*_DAT_)(uStack_198,0xe7,puVar14,uVar20);
                    if (iVar8 == -1) goto LAB_;
                    puVar14 = *(uint **)(psVar19 + 0x1c);
                    uVar20 = 0x13;
                  }
                  iVar8 = (*_DAT_)(uVar21,iVar18,uVar20);
                  if ((iVar8 != 1) || (iVar8 = (*_DAT_)(uVar21,iVar18,puVar14), iVar8 != 1))
                  goto LAB_;
                }
                else {
                  iVar8 = (*_DAT_)(uStack_198,iVar18,0);
                  if (iVar8 != 1) goto LAB_;
                  (*_DAT_)(uVar21,iVar18,0);
                }
                uVar15 = uVar15 + 1;
                uStack_190 = uStack_190 + 1;
                iVar18 = iVar18 + 1;
                psVar19 = psVar19 + 0x24;
                puVar14 = puStack_188;
              } while (uStack_190 < param_5);
            }
            (*_DAT_)(uVar21);
          }
        }
      }
    }
  }
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_1e8);
  return;
}

