
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong lStackX_8;
  undefined4 auStackX_20 [2];
  undefined8 uStack_30;
  
  uStack_30 = 0x10001d;
  lVar5 = func_0x();
  lVar5 = -lVar5;
  *(ulonglong *)(&stack0x00001ff8 + lVar5) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffd8 + lVar5);
  *(undefined8 *)(&stack0x00000050 + lVar5) = param_1;
  uVar8 = 1;
  bVar1 = true;
  *(undefined4 *)(&stack0x0000003c + lVar5) = 1;
  lVar7 = 0;
  *(undefined8 *)(&stack0x00000040 + lVar5) = 0;
  *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x100059;
  iVar2 = (*_DAT_)();
  if (iVar2 == 2) {
    *(undefined4 *)(&stack0x00000010 + lVar5) = 0x1fa0;
    *(undefined **)((longlong)&lStackX_8 + lVar5) = &stack0x00000030 + lVar5;
    *(undefined **)((longlong)auStackX_20 + lVar5 + -0x20) = &stack0x00000058 + lVar5;
    *(undefined **)(&stack0xfffffffffffffff8 + lVar5) = &stack0x00000034 + lVar5;
    *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x1000dd;
    iVar2 = func_0x(param_1,1,&stack0x00000028 + lVar5,&stack0x00000038 + lVar5);
    if (iVar2 == 1) {
      if ((*(int *)(&stack0x00000030 + lVar5) == 0) &&
         (iVar2 = *(int *)(&stack0x00000034 + lVar5), iVar2 != 0)) {
        if (((&stack0x00000028)[lVar5] - 0x25 & 0x77) == 0) {
          *(undefined4 *)(&stack0x0000002c + lVar5) = 0;
          *(undefined4 *)(&stack0x00000048 + lVar5) = 0;
          *(undefined **)((longlong)&lStackX_8 + lVar5) = &stack0x00000030 + lVar5;
          *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
          *(undefined **)(&stack0xfffffffffffffff8 + lVar5) = &stack0x00000034 + lVar5;
          *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x1001c3;
          iVar3 = (*_DAT_)(param_1,2,&stack0x00000028 + lVar5,&stack0x00000038 + lVar5);
          if (iVar3 == 1) {
            if ((&stack0x00000028)[lVar5] == -0x19) {
              if (*(int *)(&stack0x00000038 + lVar5) == 8000) {
                *(undefined **)((longlong)auStackX_20 + lVar5 + -0x20) = &stack0x0000002c + lVar5;
                *(undefined **)(&stack0xfffffffffffffff8 + lVar5) = &stack0x00000048 + lVar5;
                *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x1002d9;
                iVar2 = func_0x(5,&stack0x00000058 + lVar5,iVar2,&stack0x00000040 + lVar5);
                if (iVar2 < 0) {
                  *(undefined4 *)((longlong)auStackX_20 + lVar5) = 0xffffffff;
                  *(undefined8 *)(&stack0x00000018 + lVar5) = 0x108218;
                  *(undefined2 *)(&stack0x00000010 + lVar5) = 0;
                  *(undefined4 *)((longlong)&lStackX_8 + lVar5) = 0;
                  *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
                  (&stack0xfffffffffffffff8)[lVar5] = 0;
                  *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x10031d;
                  (*_DAT_)(param_1,2,0xc357,0x10);
                  lVar7 = *(longlong *)(&stack0x00000040 + lVar5);
                }
                else {
                  lVar7 = *(longlong *)(&stack0x00000040 + lVar5);
                  if ((*(int *)(&stack0x0000002c + lVar5) != 0) && (lVar7 != 0)) {
                    lVar6 = -1;
                    do {
                      lVar6 = lVar6 + 1;
                    } while (*(short *)(lVar7 + lVar6 * 2) != 0);
                    uVar4 = (int)lVar6 * 2;
                    *(uint *)(&stack0x0000002c + lVar5) = uVar4;
                    if (8000 < uVar4) {
                      uVar4 = 8000;
                    }
                    *(uint *)(&stack0x0000002c + lVar5) = uVar4;
                    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar5) = 0;
                    *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x100384;
                    iVar2 = (*_DAT_)(param_1,2,lVar7,uVar4);
                    if (iVar2 != 1) {
                      *(undefined4 *)((longlong)auStackX_20 + lVar5) = 0xffffffff;
                      *(undefined8 *)(&stack0x00000018 + lVar5) = 0x108248;
                      *(undefined2 *)(&stack0x00000010 + lVar5) = 0;
                      *(undefined4 *)((longlong)&lStackX_8 + lVar5) = 0;
                      *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
                      (&stack0xfffffffffffffff8)[lVar5] = 0;
                      *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x1003c9;
                      (*_DAT_)(param_1,2,0xc357,0x10);
                      goto LAB_;
                    }
                  }
                  *(undefined4 *)(&stack0x0000003c + lVar5) = 0;
                  bVar1 = false;
                }
              }
              else {
                *(undefined4 *)((longlong)auStackX_20 + lVar5) = 0xffffffff;
                *(undefined8 *)(&stack0x00000018 + lVar5) = 0x1081c0;
                *(undefined2 *)(&stack0x00000010 + lVar5) = 0;
                *(undefined4 *)((longlong)&lStackX_8 + lVar5) = 0;
                *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
                (&stack0xfffffffffffffff8)[lVar5] = 0;
                *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x1002a6;
                (*_DAT_)(param_1,2,0xc357,0x10);
              }
            }
            else {
              *(undefined4 *)((longlong)auStackX_20 + lVar5) = 0xffffffff;
              *(undefined8 *)(&stack0x00000018 + lVar5) = 0x108170;
              *(undefined2 *)(&stack0x00000010 + lVar5) = 0;
              *(undefined4 *)((longlong)&lStackX_8 + lVar5) = 0;
              *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
              (&stack0xfffffffffffffff8)[lVar5] = 0;
              *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x100254;
              (*_DAT_)(param_1,2,0xc357,0x10);
            }
          }
          else {
            *(undefined4 *)((longlong)auStackX_20 + lVar5) = 0xffffffff;
            *(undefined8 *)(&stack0x00000018 + lVar5) = 0x1080b0;
            *(undefined2 *)(&stack0x00000010 + lVar5) = 0;
            *(undefined4 *)((longlong)&lStackX_8 + lVar5) = 0;
            *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
            (&stack0xfffffffffffffff8)[lVar5] = 0;
            *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x100208;
            (*_DAT_)(param_1,2,0xc357,0x10);
          }
        }
        else {
          *(undefined4 *)((longlong)auStackX_20 + lVar5) = 0xffffffff;
          *(undefined8 *)(&stack0x00000018 + lVar5) = 0x108120;
          *(undefined2 *)(&stack0x00000010 + lVar5) = 0;
          *(undefined4 *)((longlong)&lStackX_8 + lVar5) = 0;
          *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
          (&stack0xfffffffffffffff8)[lVar5] = 0;
          *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x10018b;
          (*_DAT_)(param_1,2,0xc357,0x10);
        }
      }
      else {
        *(undefined4 *)((longlong)auStackX_20 + lVar5) = 0xffffffff;
        *(undefined8 *)(&stack0x00000018 + lVar5) = 0x1080e0;
        *(undefined2 *)(&stack0x00000010 + lVar5) = 0;
        *(undefined4 *)((longlong)&lStackX_8 + lVar5) = 0;
        *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
        (&stack0xfffffffffffffff8)[lVar5] = 0;
        *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x10041b;
        (*_DAT_)(param_1,2,0xc357,0x10);
      }
    }
    else {
      *(undefined4 *)((longlong)auStackX_20 + lVar5) = 0xffffffff;
      *(undefined8 *)(&stack0x00000018 + lVar5) = 0x1080b0;
      *(undefined2 *)(&stack0x00000010 + lVar5) = 0;
      *(undefined4 *)((longlong)&lStackX_8 + lVar5) = 0;
      *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
      (&stack0xfffffffffffffff8)[lVar5] = 0;
      *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x100122;
      (*_DAT_)(param_1,2,0xc357,0x10);
    }
  }
  else {
    *(undefined4 *)((longlong)auStackX_20 + lVar5) = 0xffffffff;
    *(undefined8 *)(&stack0x00000018 + lVar5) = 0x108080;
    *(undefined2 *)(&stack0x00000010 + lVar5) = 0;
    *(undefined4 *)((longlong)&lStackX_8 + lVar5) = 0;
    *(undefined8 *)((longlong)auStackX_20 + lVar5 + -0x20) = 0;
    (&stack0xfffffffffffffff8)[lVar5] = 0;
    *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x10009d;
    (*_DAT_)(param_1,2,0xc357,0x10);
    lVar7 = 0;
  }
LAB_:
  if (bVar1) {
    uVar8 = 3;
  }
  *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x10048b;
  (*_DAT_)(param_1,uVar8,0,0);
  if (lVar7 != 0) {
    *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x10049d;
    func_0x(lVar7,2);
  }
  *(undefined8 *)((longlong)&uStack_30 + lVar5) = 0x1004af;
  func_0x(*(ulonglong *)(&stack0x00001ff8 + lVar5) ^
                  (ulonglong)(&stack0xffffffffffffffd8 + lVar5));
  return;
}

