
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  longlong lVar1;
  int iVar2;
  
  lVar1 = *param_1;
  if (DAT_ != '\0') {
    iVar2 = (*_DAT_)();
    if (iVar2 == (iVar2 / 5) * 5) {
      func_0x();
    }
  }
  *(undefined8 *)(lVar1 + 0x18) = 0;
  return;
}

