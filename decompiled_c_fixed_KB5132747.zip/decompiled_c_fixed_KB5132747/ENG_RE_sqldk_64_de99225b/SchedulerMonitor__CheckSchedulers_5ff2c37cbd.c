
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2)

{
  ulonglong *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  longlong unaff_GS_OFFSET;
  bool bVar13;
  undefined auStack_a28 [32];
  int iStack_a08;
  int iStack_9f8;
  int iStack_9f0;
  longlong lStack_9e8;
  undefined auStack_9e0 [16];
  undefined8 uStack_9d0;
  undefined8 uStack_9c8;
  undefined4 uStack_9c0;
  longlong lStack_9b8;
  undefined auStack_9b0 [16];
  undefined8 uStack_9a0;
  undefined8 uStack_998;
  undefined4 uStack_990;
  longlong lStack_8f0;
  longlong lStack_8e8;
  longlong lStack_8e0;
  undefined8 uStack_8b0;
  ulonglong auStack_2b8 [16];
  uint auStack_238 [64];
  uint auStack_138 [64];
  ulonglong uStack_38;
  
  uStack_8b0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_a28;
  iStack_a08 = 1;
  iStack_9f8 = 0;
  iStack_9f0 = param_2;
  lStack_9e8 = param_1;
  func_0x(auStack_138,0,0x100);
  func_0x(auStack_238,0,0x100);
  lVar12 = 0x198;
  if (param_2 != 1) {
    lVar12 = 0x1e8;
  }
  lVar8 = 0x168;
  if (param_2 != 1) {
    lVar8 = 0x1b8;
  }
  func_0x(&lStack_8f0,lVar8 + *(longlong *)(param_1 + 0x18),
                  lVar12 + *(longlong *)(param_1 + 0x18),1);
  lVar12 = 0;
  while( true ) {
    lVar8 = lStack_8f0;
    iVar5 = iStack_a08;
    lVar7 = 0;
    if (lVar12 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (lStack_8f0 != 0) break;
LAB_:
    lStack_9b8 = lVar7;
    if (lVar7 == 0) goto LAB_;
    iStack_9f8 = 1;
    func_0x(param_1,param_2,lVar7);
    if (iVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    iStack_a08 = 0;
    lVar12 = lVar7;
    if (param_2 == 1) {
      auStack_9b0 = ZEXT816(0);
      uStack_998 = 0;
      uStack_990 = 0;
      uStack_9a0 = 0x3fff38;
      uVar6 = func_0x(0x3fff38);
      auStack_9b0._0_8_ = uVar6;
      uVar6 = func_0x(0x3fff38);
      auStack_9b0._8_8_ = uVar6;
      lVar12 = 0;
      while( true ) {
        if (lVar12 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        lVar8 = 0;
        if (auStack_9b0._0_8_ != 0) {
          if (auStack_9b0._0_8_ == auStack_9b0._8_8_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (_DAT_ != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          LOCK();
          bVar13 = _DAT_ != 0;
          uVar9 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
          if (bVar13) {
            uVar9 = _DAT_;
          }
          _DAT_ = uVar9;
          UNLOCK();
          if (bVar13) {
            return;
          }
          lVar8 = *(longlong *)(lVar12 + 8);
          if (lVar8 == 0x3fff38) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (lVar8 != 0) {
            iVar5 = *(int *)(lVar8 + 0x18);
            if (iVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            LOCK();
            iVar4 = *(int *)(lVar8 + 0x18);
            if (iVar5 == iVar4) {
              *(int *)(lVar8 + 0x18) = iVar5 + 1;
              iVar4 = iVar5;
            }
            UNLOCK();
            if (iVar5 != iVar4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            if (iVar5 + 1 == 0) {
              return;
            }
          }
          if (DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          _DAT_ = 0;
          auStack_9b0._0_8_ = lVar8;
          LOCK();
          piVar2 = (int *)(lVar12 + 0x18);
          iVar5 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar5 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
        if (lVar8 == 0) break;
        func_0x(lVar8 + 0xb60,auStack_2b8);
        lVar10 = (ulonglong)*(ushort *)(lVar7 + 0x1410) * 0x28;
        lVar12 = lVar8;
        if ((*(ulonglong *)(lVar7 + 0x1418) &
            auStack_2b8[*(ushort *)(lVar10 + 0x406dc0)] & *(ulonglong *)(lVar10 + 0x406db8)) != 0) {
          uVar9 = (ulonglong)*(uint *)(lVar8 + 0xb30);
          if ((_DAT_ != 1) || (0xfffff < *(uint *)(lVar7 + 0xe68))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          iVar5 = func_0x(lVar7 + 0x80,uVar9,*(undefined4 *)(lVar7 + 0x145c),1);
          auStack_138[uVar9] = auStack_138[uVar9] + iVar5;
          auStack_238[uVar9] = auStack_238[uVar9] + 1;
        }
      }
      if (auStack_9b0._0_8_ != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (auStack_9b0._8_8_ != 0) {
        LOCK();
        piVar2 = (int *)(auStack_9b0._8_8_ + 0x18);
        iVar5 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar5 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        auStack_9b0 = ZEXT816(0);
      }
      uStack_9a0 = 0;
      lVar12 = lStack_9b8;
      param_1 = lStack_9e8;
      param_2 = iStack_9f0;
    }
  }
  if (lStack_8f0 != lStack_8e8) {
    puVar1 = (ulonglong *)(lStack_8e0 + 0x10);
    if (*(int *)puVar1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    LOCK();
    uVar9 = *puVar1;
    if (uVar9 == 0) {
      *puVar1 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (uVar9 != 0) {
      return;
    }
    lVar8 = *(longlong *)(lVar12 + 0x18);
    if (lVar8 == lStack_8e0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar7 = 0;
    if (lVar8 != 0) {
      lVar7 = lVar8 + -0x10;
    }
    if (lVar7 != 0) {
      iVar4 = *(int *)(lVar7 + 0x28);
      if (iVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      iVar3 = *(int *)(lVar7 + 0x28);
      if (iVar4 == iVar3) {
        *(int *)(lVar7 + 0x28) = iVar4 + 1;
        iVar3 = iVar4;
      }
      UNLOCK();
      if (iVar4 != iVar3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (iVar4 + 1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if (DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *puVar1 = 0;
    LOCK();
    piVar2 = (int *)(lVar12 + 0x28);
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    param_1 = lStack_9e8;
    lStack_8f0 = lVar7;
    if (iVar4 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    goto LAB_;
  }
  lStack_8f0 = 0;
  LOCK();
  piVar2 = (int *)(lVar8 + 0x28);
  iVar4 = *piVar2;
  *piVar2 = *piVar2 + -1;
  UNLOCK();
  if (iVar4 != 1) goto LAB_;
  if (*(longlong *)(lVar8 + 0x18) != 0) {
    func_0x(*(undefined8 *)(lVar8 + 0x20));
  }
  func_0x(lVar8);
LAB_:
  func_0x(&lStack_8f0);
  if (param_2 != 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  auStack_9e0 = ZEXT816(0);
  uStack_9c8 = 0;
  uStack_9c0 = 0;
  uStack_9d0 = 0x3fff38;
  lVar8 = func_0x(0x3fff38);
  auStack_9e0._0_8_ = lVar8;
  lVar7 = func_0x(0x3fff38);
  lVar12 = 0;
  while( true ) {
    if (lVar12 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar10 = 0;
    lVar11 = lVar8;
    auStack_9e0._8_8_ = lVar7;
    if (lVar8 != 0) {
      if (lVar8 == lVar7) {
        auStack_9e0._0_8_ = 0;
        LOCK();
        piVar2 = (int *)(lVar8 + 0x18);
        iVar5 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        lVar10 = auStack_9e0._0_8_;
        lVar11 = auStack_9e0._0_8_;
        if (iVar5 == 1) {
          if (*(longlong *)(lVar8 + 8) == 0) {
            func_0x(lVar8);
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          func_0x(*(undefined8 *)(lVar8 + 0x10),lVar8);
          func_0x(lVar8);
          func_0x(lVar8,0xbe8);
          lVar11 = auStack_9e0._0_8_;
          break;
        }
      }
      else {
        if (_DAT_ != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        LOCK();
        bVar13 = _DAT_ != 0;
        uVar9 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
        if (bVar13) {
          uVar9 = _DAT_;
        }
        _DAT_ = uVar9;
        UNLOCK();
        if (bVar13) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        auStack_9e0._0_8_ = *(longlong *)(lVar12 + 8);
        if (auStack_9e0._0_8_ == 0x3fff38) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if (auStack_9e0._0_8_ != 0) {
          iVar5 = *(int *)(auStack_9e0._0_8_ + 0x18);
          if (iVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          LOCK();
          iVar4 = *(int *)(auStack_9e0._0_8_ + 0x18);
          if (iVar5 == iVar4) {
            *(int *)(auStack_9e0._0_8_ + 0x18) = iVar5 + 1;
            iVar4 = iVar5;
          }
          UNLOCK();
          if (iVar5 != iVar4) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (iVar5 + 1 == 0) {
            return;
          }
        }
        if (DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        _DAT_ = 0;
        LOCK();
        piVar2 = (int *)(lVar12 + 0x18);
        iVar5 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        lVar10 = auStack_9e0._0_8_;
        lVar11 = auStack_9e0._0_8_;
        if (iVar5 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
    }
    if (lVar10 == 0) break;
    uVar9 = (ulonglong)*(uint *)(lVar10 + 0xb30);
    lVar12 = lVar10;
    lVar8 = lVar11;
    if (auStack_238[uVar9] != 0) {
      *(uint *)(*(longlong *)(param_1 + 0x18) + 0x638 + uVar9 * 4) =
           auStack_138[uVar9] / auStack_238[uVar9];
    }
  }
  if (lVar11 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (auStack_9e0._8_8_ != 0) {
    LOCK();
    piVar2 = (int *)(auStack_9e0._8_8_ + 0x18);
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    auStack_9e0._8_8_ = 0;
  }
  uStack_9d0 = 0;
  if ((iStack_9f8 == 1) && (iStack_a08 == 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x1e0) == 0) {
    *(int *)(param_1 + 0x1e0) = 0;
    func_0x(uStack_38 ^ (ulonglong)auStack_a28);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

