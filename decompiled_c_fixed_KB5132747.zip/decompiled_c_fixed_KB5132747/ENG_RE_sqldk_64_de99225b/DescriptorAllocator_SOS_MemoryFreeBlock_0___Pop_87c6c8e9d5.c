
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00100122) */
/* WARNING: Removing unreachable block (ram,0x0017206f) */
/* WARNING: Removing unreachable block (ram,0x0010012f) */
/* WARNING: Removing unreachable block (ram,0x0017207d) */
/* WARNING: Removing unreachable block (ram,0x0010014b) */
/* WARNING: Removing unreachable block (ram,0x001720a9) */
/* WARNING: Removing unreachable block (ram,0x0010015d) */
/* WARNING: Removing unreachable block (ram,0x001001ea) */
/* WARNING: Removing unreachable block (ram,0x001720b4) */
/* WARNING: Removing unreachable block (ram,0x001001f7) */
/* WARNING: Removing unreachable block (ram,0x001720ca) */
/* WARNING: Removing unreachable block (ram,0x00100213) */
/* WARNING: Removing unreachable block (ram,0x001720c2) */
/* WARNING: Removing unreachable block (ram,0x00100220) */
/* WARNING: Removing unreachable block (ram,0x001720d2) */
/* WARNING: Removing unreachable block (ram,0x0010022d) */
/* WARNING: Removing unreachable block (ram,0x001720e9) */
/* WARNING: Removing unreachable block (ram,0x00171f61) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(longlong param_1,uint param_2,undefined8 param_3,longlong param_4)

{
  short sVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  char cVar4;
  longlong lVar5;
  ulonglong uVar6;
  bool bVar7;
  
  if (param_4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar2 = *(ulonglong *)
           (((ulonglong)param_2 << (*(byte *)(param_1 + 0x4cc) & 0x3f)) +
            *(longlong *)(param_1 + 0x4c0) + 8);
  if (uVar2 != 0) {
    lVar5 = (*_DAT_)(uVar2);
    if (lVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar3 = *(ulonglong *)(uVar2 + 0x18);
    uVar6 = 0;
    if ((uVar3 != 0) && (uVar6 = 0, uVar3 < uVar2)) {
      uVar6 = uVar3 + 0x40;
      if (uVar3 + 0x40 == uVar2) {
        uVar6 = 0;
      }
      LOCK();
      bVar7 = uVar3 == *(ulonglong *)(uVar2 + 0x18);
      if (bVar7) {
        *(ulonglong *)(uVar2 + 0x18) = uVar6;
      }
      UNLOCK();
      if (!bVar7) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      *(int *)(uVar2 + 0x28) = *(int *)(uVar2 + 0x28) + -1;
      UNLOCK();
      uVar6 = uVar3;
    }
    if (uVar6 != 0) {
      return uVar6;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  sVar1 = *(short *)(((ulonglong)param_2 << (*(byte *)(param_1 + 0x4cc) & 0x3f)) +
                    *(longlong *)(param_1 + 0x4c0));
  if (sVar1 == 0x40) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  cVar4 = func_0x(param_1,0,(ulonglong)param_2,sVar1,0);
  if ((cVar4 == '\0') && (cVar4 = func_0x(param_1,0,param_2,sVar1,0,param_3), cVar4 == '\0')
     ) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

