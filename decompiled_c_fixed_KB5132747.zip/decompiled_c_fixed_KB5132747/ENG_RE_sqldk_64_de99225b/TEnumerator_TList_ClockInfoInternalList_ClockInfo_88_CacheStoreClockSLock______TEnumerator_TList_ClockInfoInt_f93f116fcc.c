
void FUN_(longlong *param_1)

{
  undefined8 *puVar1;
  int iVar2;
  undefined8 *puVar3;
  
  puVar3 = (undefined8 *)*param_1;
  if (puVar3 != (undefined8 *)0x0) {
    LOCK();
    puVar1 = puVar3 + 0xe;
    iVar2 = *(int *)puVar1;
    *(int *)puVar1 = *(int *)puVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      if (puVar3[0xc] != 0) {
        func_0x(puVar3[0xd],puVar3);
      }
      (**(code **)*puVar3)(puVar3);
    }
    *param_1 = 0;
  }
  puVar3 = (undefined8 *)param_1[1];
  if (puVar3 != (undefined8 *)0x0) {
    LOCK();
    puVar1 = puVar3 + 0xe;
    iVar2 = *(int *)puVar1;
    *(int *)puVar1 = *(int *)puVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      if (puVar3[0xc] != 0) {
        func_0x(puVar3[0xd],puVar3);
      }
      (**(code **)*puVar3)(puVar3);
    }
    param_1[1] = 0;
  }
  if (param_1[3] != 0) {
    func_0x(param_1[3],*(undefined4 *)(param_1 + 4));
    param_1[3] = 0;
    *(undefined4 *)(param_1 + 4) = 0;
  }
  param_1[2] = 0;
  return;
}

