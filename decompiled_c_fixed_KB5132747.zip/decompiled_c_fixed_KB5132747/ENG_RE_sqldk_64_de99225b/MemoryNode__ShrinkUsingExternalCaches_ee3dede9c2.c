
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_(longlong param_1,longlong *param_2)

{
  undefined auVar1 [16];
  short sVar2;
  char cVar3;
  int iVar4;
  longlong **pplVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  uint uVar11;
  longlong lVar12;
  uint uVar13;
  longlong lVar14;
  longlong *plVar15;
  ushort uVar16;
  uint uVar17;
  undefined4 uVar18;
  longlong **pplVar19;
  longlong **pplVar20;
  longlong **pplVar21;
  longlong unaff_GS_OFFSET;
  ulonglong uStackX_18;
  undefined4 auStack_78 [2];
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  
  pplVar20 = (longlong **)0x0;
  pplVar5 = _DAT_;
  if ((_DAT_ != (longlong **)0x0) && ((*(byte *)(_DAT_ + 0xc4) & 0x10) != 0)) {
    pplVar5 = pplVar20;
  }
  pplVar21 = pplVar5 + 0xb1;
  if (pplVar5 == (longlong **)0x0) {
    pplVar21 = pplVar20;
  }
  iVar4 = func_0x();
  uStackX_18 = 0;
  if (iVar4 != 0) {
    lVar12 = *(longlong *)(param_1 + 0x50) + *(longlong *)(param_1 + 0x48) +
             *(longlong *)(param_1 + 0x40);
    if (_DAT_ == 1) {
      lVar12 = lVar12 + (*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60));
    }
    if (((lVar12 + 1) / 2 < *(longlong *)(param_1 + 0xa8)) &&
       (pplVar5 = (longlong **)0x1, *(longlong *)(param_1 + 0x90) < *(longlong *)(param_1 + 0xa8)))
    goto LAB_;
  }
  pplVar5 = pplVar20;
LAB_:
  lVar14 = (ulonglong)_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)_DAT_ * 8);
  lVar12 = *(longlong *)(lVar14 + 0x100);
  if (lVar12 == 0) {
    func_0x(0);
    lVar12 = *(longlong *)(lVar14 + 0x100);
  }
  lVar12 = *(longlong *)(lVar12 + 0x3e0);
  uVar17 = _DAT_;
  if ((lVar12 == 0) ||
     (pplVar19 = (longlong **)(lVar12 + 0x3b0), (*(byte *)(lVar12 + 0x620) & 4) != 0)) {
    pplVar19 = pplVar20;
  }
  do {
    _DAT_ = uVar17;
    if (iVar4 == 0) {
      uVar18 = 2;
LAB_:
      lVar12 = *(longlong *)(param_1 + 0x50) + *(longlong *)(param_1 + 0x48) +
               *(longlong *)(param_1 + 0x40);
      if (_DAT_ == 1) {
        lVar12 = lVar12 + (*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60));
      }
      lVar14 = *(longlong *)(param_1 + 0xa8);
      if (*(longlong *)(param_1 + 0x90) <= *(longlong *)(param_1 + 0xa8)) {
        lVar14 = *(longlong *)(param_1 + 0x90);
      }
      if (((lVar12 + 1) / 2 <= lVar14) && (iVar4 = func_0x(param_1), iVar4 == 0)) {
        uVar18 = 2;
      }
      return uVar18;
    }
    if (0 < *(longlong *)(param_1 + 0x70)) {
      uVar16 = 0;
      uVar13 = (uint)*(ushort *)(param_1 + 0x80);
      if (uVar17 != 0) {
        do {
          uVar6 = func_0x(0x372050,uVar13);
          func_0x(uVar6,1,0,0,0);
          sVar2 = (short)uVar13;
          uVar16 = uVar16 + 1;
          uVar11 = uVar13 + 1;
          uVar13 = 0;
          if (uVar11 < (uVar17 & 0xffff)) {
            uVar13 = (uint)(ushort)(sVar2 + 1);
          }
        } while (uVar16 < uVar17);
      }
    }
    if (pplVar19 != (longlong **)0x0) {
      func_0x(pplVar19,2);
    }
    lVar12 = *(longlong *)(param_1 + 0x70);
    lVar14 = func_0x(param_1);
    lVar14 = lVar14 - (lVar12 + 1) / 2;
    lVar7 = func_0x(param_1);
    if (pplVar21 != (longlong **)0x0) {
      plVar15 = (longlong *)0x0;
      if (*(int *)(pplVar21 + 9) != 0) {
        plVar15 = *pplVar21;
      }
      if (plVar15 != (longlong *)0x0) {
        uVar17 = (uint)(*(int *)(pplVar21 + 9) != 0);
        do {
          if ((pplVar5 == (longlong **)0x0) || (*(char *)(plVar15 + 2) != '\0')) {
            lVar12 = (**(code **)(*plVar15 + 0x18))(plVar15,0);
            cVar3 = (**(code **)(*plVar15 + 0x20))(plVar15);
            if (cVar3 != '\0') {
              LOCK();
              plVar15 = (longlong *)(param_1 + 0x100);
              lVar8 = *plVar15;
              *plVar15 = *plVar15 + lVar12;
              UNLOCK();
              if ((lVar8 < 0) || (lVar8 + lVar12 < 0)) {
                *(longlong *)(param_1 + 0x100) = lVar12;
              }
            }
          }
          plVar15 = (longlong *)0x0;
          if (uVar17 < *(uint *)(pplVar21 + 9)) {
            lVar12 = (longlong)(int)uVar17;
            uVar17 = uVar17 + 1;
            plVar15 = pplVar21[lVar12];
          }
        } while (plVar15 != (longlong *)0x0);
        lVar12 = *(longlong *)(param_1 + 0x70);
      }
    }
    lVar8 = func_0x(param_1);
    lVar8 = lVar8 - (lVar12 + 1) / 2;
    lVar12 = func_0x(param_1);
    if (*param_2 < lVar8) {
      if ((*(int *)(param_2 + 1) != 0) || (lVar14 < lVar8)) {
        uVar18 = 0;
        goto LAB_;
      }
LAB_:
      if (lVar7 <= lVar12) {
        uVar18 = 2;
        goto LAB_;
      }
    }
    else if (lVar8 <= lVar14) goto LAB_;
    uVar9 = (ulonglong)_DAT_;
    lVar14 = (ulonglong)_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + uVar9 * 8);
    lVar12 = *(longlong *)(lVar14 + 0x100);
    if (lVar12 == 0) {
      uVar9 = func_0x(0);
      lVar12 = *(longlong *)(lVar14 + 0x100);
    }
    uVar10 = rdtsc();
    uVar10 = CONCAT44((int)(uVar9 >> 0x20),(int)uVar10) | uVar10 & 0xffffffff00000000;
    uVar9 = *(ulonglong *)(lVar12 + 0x340);
    if ((uVar9 < uVar10) ||
       ((uVar9 != 0x7fffffffffffffff &&
        (*(ulonglong *)(*(longlong *)(lVar12 + 0x260) + 0xdf0) < uVar9 - uVar10)))) {
      uVar17 = *(uint *)(lVar12 + 0x268);
      *(uint *)(lVar12 + 0x268) = uVar17 | 1;
      func_0x(0,0x38fae0);
      *(uint *)(lVar12 + 0x268) = *(uint *)(lVar12 + 0x268) & (uVar17 | 0xfffffffe);
    }
    uStackX_18 = uStackX_18 + 1;
    auVar1._8_8_ = 0;
    auVar1._0_8_ = uStackX_18;
    lVar12 = SUB168(ZEXT816(0x624dd2f1a9fbe77) * auVar1,8);
    if (uStackX_18 == ((uStackX_18 - lVar12 >> 1) + lVar12 >> 9) * 1000) {
      auStack_78[0] = 0x400060;
      uStack_70 = 0;
      uStack_60 = 0;
      uStack_68 = 0;
      uStack_58 = 0;
      func_0x(1,auStack_78);
    }
    iVar4 = func_0x(param_1);
    uVar17 = _DAT_;
  } while( true );
}

