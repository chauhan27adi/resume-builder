
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00100861) */
/* WARNING: Removing unreachable block (ram,0x0010087f) */
/* WARNING: Removing unreachable block (ram,0x00100894) */
/* WARNING: Removing unreachable block (ram,0x0010089d) */
/* WARNING: Removing unreachable block (ram,0x00199d21) */
/* WARNING: Removing unreachable block (ram,0x001008ab) */
/* WARNING: Removing unreachable block (ram,0x001008b8) */
/* WARNING: Removing unreachable block (ram,0x001008bc) */
/* WARNING: Removing unreachable block (ram,0x001008c1) */
/* WARNING: Removing unreachable block (ram,0x001008c7) */
/* WARNING: Removing unreachable block (ram,0x001008cb) */
/* WARNING: Removing unreachable block (ram,0x001008d3) */
/* WARNING: Removing unreachable block (ram,0x001008d8) */
/* WARNING: Removing unreachable block (ram,0x001008de) */
/* WARNING: Removing unreachable block (ram,0x00100911) */
/* WARNING: Removing unreachable block (ram,0x000fff60) */
/* WARNING: Removing unreachable block (ram,0x00100920) */
/* WARNING: Removing unreachable block (ram,0x00100951) */
/* WARNING: Removing unreachable block (ram,0x00100959) */
/* WARNING: Removing unreachable block (ram,0x00100966) */
/* WARNING: Removing unreachable block (ram,0x0010096a) */
/* WARNING: Removing unreachable block (ram,0x0010097f) */
/* WARNING: Removing unreachable block (ram,0x00100983) */
/* WARNING: Removing unreachable block (ram,0x00100991) */
/* WARNING: Removing unreachable block (ram,0x00100995) */
/* WARNING: Removing unreachable block (ram,0x001009a8) */
/* WARNING: Removing unreachable block (ram,0x001009ac) */
/* WARNING: Removing unreachable block (ram,0x001009ba) */
/* WARNING: Removing unreachable block (ram,0x001009be) */
/* WARNING: Removing unreachable block (ram,0x00199d3a) */
/* WARNING: Removing unreachable block (ram,0x001009d0) */
/* WARNING: Removing unreachable block (ram,0x001009da) */
/* WARNING: Removing unreachable block (ram,0x00100a24) */
/* WARNING: Removing unreachable block (ram,0x00100a28) */
/* WARNING: Removing unreachable block (ram,0x00100a36) */
/* WARNING: Removing unreachable block (ram,0x00100a3a) */
/* WARNING: Removing unreachable block (ram,0x00100a48) */
/* WARNING: Removing unreachable block (ram,0x00100a4c) */
/* WARNING: Removing unreachable block (ram,0x00100a57) */
/* WARNING: Removing unreachable block (ram,0x00100a5b) */
/* WARNING: Removing unreachable block (ram,0x00100a64) */
/* WARNING: Removing unreachable block (ram,0x000fff75) */
/* WARNING: Removing unreachable block (ram,0x00100a6c) */
/* WARNING: Removing unreachable block (ram,0x00100a77) */
/* WARNING: Removing unreachable block (ram,0x00100a7b) */
/* WARNING: Removing unreachable block (ram,0x00100a88) */
/* WARNING: Removing unreachable block (ram,0x00100a8c) */
/* WARNING: Removing unreachable block (ram,0x00100a95) */
/* WARNING: Removing unreachable block (ram,0x00100a99) */
/* WARNING: Removing unreachable block (ram,0x00100aa3) */
/* WARNING: Removing unreachable block (ram,0x00100aa7) */
/* WARNING: Removing unreachable block (ram,0x00199d58) */
/* WARNING: Removing unreachable block (ram,0x00100abd) */
/* WARNING: Removing unreachable block (ram,0x00100ac3) */
/* WARNING: Removing unreachable block (ram,0x00100ac7) */
/* WARNING: Removing unreachable block (ram,0x00100ad4) */
/* WARNING: Removing unreachable block (ram,0x00100add) */
/* WARNING: Removing unreachable block (ram,0x00100ae5) */
/* WARNING: Removing unreachable block (ram,0x00100aee) */
/* WARNING: Removing unreachable block (ram,0x00100b02) */
/* WARNING: Removing unreachable block (ram,0x00199d88) */
/* WARNING: Removing unreachable block (ram,0x00100b0b) */
/* WARNING: Removing unreachable block (ram,0x00199d98) */
/* WARNING: Removing unreachable block (ram,0x00100b2b) */
/* WARNING: Removing unreachable block (ram,0x00100b33) */
/* WARNING: Removing unreachable block (ram,0x00100b59) */
/* WARNING: Removing unreachable block (ram,0x00100b61) */
/* WARNING: Removing unreachable block (ram,0x00100b77) */
/* WARNING: Removing unreachable block (ram,0x00199db1) */
/* WARNING: Removing unreachable block (ram,0x00100b8a) */
/* WARNING: Removing unreachable block (ram,0x00100b93) */
/* WARNING: Removing unreachable block (ram,0x00100b9d) */
/* WARNING: Removing unreachable block (ram,0x00100ba1) */
/* WARNING: Removing unreachable block (ram,0x00100baf) */
/* WARNING: Removing unreachable block (ram,0x00100bc4) */
/* WARNING: Removing unreachable block (ram,0x000fff84) */
/* WARNING: Removing unreachable block (ram,0x00100bd4) */
/* WARNING: Removing unreachable block (ram,0x00100bdb) */
/* WARNING: Removing unreachable block (ram,0x00100bdf) */
/* WARNING: Removing unreachable block (ram,0x00199dbf) */
/* WARNING: Removing unreachable block (ram,0x00100be8) */
/* WARNING: Removing unreachable block (ram,0x00100bf2) */
/* WARNING: Removing unreachable block (ram,0x00100bf6) */
/* WARNING: Removing unreachable block (ram,0x00100bfc) */
/* WARNING: Removing unreachable block (ram,0x00100c00) */
/* WARNING: Removing unreachable block (ram,0x000fffd6) */
/* WARNING: Removing unreachable block (ram,0x00100c09) */
/* WARNING: Removing unreachable block (ram,0x00100c11) */
/* WARNING: Removing unreachable block (ram,0x00199e32) */
/* WARNING: Removing unreachable block (ram,0x00100c24) */
/* WARNING: Removing unreachable block (ram,0x00100c4f) */
/* WARNING: Removing unreachable block (ram,0x00100c6d) */
/* WARNING: Removing unreachable block (ram,0x00100c79) */
/* WARNING: Removing unreachable block (ram,0x00100c82) */
/* WARNING: Removing unreachable block (ram,0x00199e40) */
/* WARNING: Removing unreachable block (ram,0x00100c8c) */
/* WARNING: Removing unreachable block (ram,0x00100ccb) */
/* WARNING: Removing unreachable block (ram,0x00100ce7) */
/* WARNING: Removing unreachable block (ram,0x00100cf7) */
/* WARNING: Removing unreachable block (ram,0x00100cbe) */
/* WARNING: Removing unreachable block (ram,0x00100cff) */
/* WARNING: Removing unreachable block (ram,0x00100d20) */
/* WARNING: Removing unreachable block (ram,0x00100d30) */
/* WARNING: Removing unreachable block (ram,0x00100d4d) */
/* WARNING: Removing unreachable block (ram,0x00199da3) */
/* WARNING: Removing unreachable block (ram,0x00199d11) */
/* WARNING: Removing unreachable block (ram,0x00199cce) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2,undefined8 param_3,int param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  double dVar4;
  ulonglong uVar5;
  uint uVar6;
  ulonglong uVar7;
  int iVar8;
  ulonglong uVar9;
  longlong lVar10;
  longlong lVar11;
  ulonglong uVar12;
  longlong lVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  longlong lVar17;
  ushort uVar18;
  ulonglong uVar19;
  longlong lVar20;
  longlong unaff_GS_OFFSET;
  int iStack_2a0;
  undefined4 auStack_170 [2];
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined8 uStack_158;
  undefined8 uStack_150;
  undefined8 uStack_148;
  
  uStack_148 = 0xfffffffffffffffe;
  lVar14 = *(longlong *)
            ((ulonglong)_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)_DAT_ * 8) +
            0x100);
  if (lVar14 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(lVar14 + 0x268) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_4 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  auStack_170[0] = 0x40007e;
  uStack_168 = 0;
  uStack_158 = 0;
  uStack_160 = 0;
  uStack_150 = 0;
  iVar8 = func_0x(0x423bb8,0,auStack_170,0);
  uVar7 = _DAT_;
  lVar14 = _DAT_;
  if (iVar8 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_1 < 1) {
    param_1 = 1;
  }
  if (param_2 < _DAT_) {
    param_2 = _DAT_;
  }
  if (param_2 < _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_2 - _DAT_ == -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (_DAT_ == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((int)(((param_2 - _DAT_) * 1000) / _DAT_) < 100) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_2 < _DAT_) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_2 - _DAT_ == -1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (_DAT_ == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar9 = ((param_2 - _DAT_) * 1000) / _DAT_;
  lVar15 = param_1 * 0x1b;
  _DAT_ = lVar15 >> 5;
  lVar16 = (lVar15 >> 7) * 3;
  lVar15 = (lVar15 >> 9) * 3;
  _DAT_ = _DAT_;
  _DAT_ = 0;
  _DAT_ = 0;
  _DAT_ = _DAT_;
  _DAT_ = 0;
  _DAT_ = 0;
  _DAT_ = _DAT_;
  _DAT_ = 0;
  _DAT_ = 0;
  _DAT_ = _DAT_;
  _DAT_ = 0;
  _DAT_ = 0;
  _DAT_ = _DAT_;
  _DAT_ = 0;
  _DAT_ = 0;
  _DAT_ = _DAT_;
  _DAT_ = 0;
  _DAT_ = 0;
  _DAT_ = param_1;
  _DAT_ = _DAT_;
  _DAT_ = _DAT_;
  _DAT_ = _DAT_;
  _DAT_ = _DAT_;
  _DAT_ = _DAT_;
  lVar10 = (*_DAT_)();
  uVar6 = _DAT_;
  lVar17 = 0;
  uVar18 = 0;
  if (_DAT_ != 0) {
    do {
      lVar11 = func_0x(0x408ee0,uVar18);
      lVar17 = lVar17 + *(longlong *)(lVar11 + 0x58);
      uVar18 = uVar18 + 1;
    } while (uVar18 < uVar6);
  }
  uVar5 = _DAT_;
  dVar4 = _DAT_;
  lVar17 = (lVar17 + 1) / 2;
  if (lVar10 < lVar17) {
    lVar17 = lVar10;
  }
  LOCK();
  _DAT_ = _DAT_ + ((lVar10 - lVar17) - lVar14);
  UNLOCK();
  uVar12 = 0;
  if (uVar7 != 0) {
    for (; (uVar7 >> uVar12 & 1) == 0; uVar12 = uVar12 + 1) {
    }
  }
  if (uVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar19 = uVar7;
  do {
    lVar10 = (uVar12 & 0xffffffff) * 0x380;
    lVar14 = *(longlong *)(lVar10 + 0x4159d8);
    *(longlong *)(lVar10 + 0x4159a0) = lVar14;
    if (*(int *)(lVar10 + 0x4159e0) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar17 = *(longlong *)(lVar10 + 0x415a38);
    *(longlong *)(lVar10 + 0x415a00) = lVar17;
    if (*(int *)(lVar10 + 0x415a40) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar11 = *(longlong *)(lVar10 + 0x415a98);
    *(longlong *)(lVar10 + 0x415a60) = lVar11;
    if (*(int *)(lVar10 + 0x415aa0) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar20 = *(longlong *)(&DAT_ + lVar10);
    *(longlong *)(lVar10 + 0x415ac0) = lVar20;
    if (*(int *)(lVar10 + 0x415b00) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar13 = lVar14 + lVar17 + lVar11 + lVar20;
    lVar1 = *(longlong *)(lVar10 + 0x415b58);
    *(longlong *)(lVar10 + 0x415b20) = lVar1;
    if ((*(int *)(lVar10 + 0x415b60) != 1) || ((uVar5 & 0x20) == 0)) {
      lVar13 = lVar13 + lVar1;
    }
    lVar2 = *(longlong *)(lVar10 + 0x415bb8);
    *(longlong *)(lVar10 + 0x415b80) = lVar2;
    if (*(int *)(lVar10 + 0x415bc0) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar3 = *(longlong *)(lVar10 + 0x415c18);
    *(longlong *)(lVar10 + 0x415be0) = lVar3;
    if (*(int *)(lVar10 + 0x415c20) == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(longlong *)(lVar10 + 0x415938) = lVar13 + lVar2 + lVar3;
    *(longlong *)(lVar10 + 0x415940) = lVar17 + lVar14 + lVar11 + lVar20 + lVar1 + lVar2 + lVar3;
    *(longlong *)(lVar10 + 0x415928) =
         (longlong)(((double)param_1 * *(double *)(lVar10 + 0x415c28)) / dVar4);
    *(longlong *)(lVar10 + 0x415930) =
         (longlong)(((double)param_1 * *(double *)(lVar10 + 0x415c30)) / dVar4);
    *(longlong *)(lVar10 + 0x415960) = param_1;
    lVar14 = 0x90;
    if (0 < lVar3) {
      lVar14 = 0xf0;
    }
    *(longlong *)(&DAT_ + lVar14 + lVar10) =
         *(longlong *)(&DAT_ + lVar14 + lVar10) + lVar3;
    *(undefined8 *)(lVar10 + 0x415be0) = 0;
    uVar19 = uVar19 & ~(1L << (uVar12 & 0x3f));
    uVar12 = 0;
    if (uVar19 != 0) {
      for (; (uVar19 >> uVar12 & 1) == 0; uVar12 = uVar12 + 1) {
      }
    }
  } while (uVar19 != 0);
  lVar14 = 0;
  if (uVar7 != 0) {
    for (; (uVar7 >> lVar14 & 1) == 0; lVar14 = lVar14 + 1) {
    }
  }
  if (uVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar14 = lVar14 * 0x380;
  lVar17 = 0;
  lVar10 = *(longlong *)(lVar14 + 0x4159a0);
  iVar8 = *(int *)(lVar14 + 0x4159e0);
  if (iVar8 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iStack_2a0 = (int)uVar9;
  if (iVar8 != 1) {
    lVar17 = *(longlong *)(lVar14 + 0x415998) * 3;
    lVar17 = ((lVar10 - *(longlong *)(lVar14 + 0x415988)) * 1000) / (longlong)iStack_2a0 +
             ((longlong)(lVar17 + (ulonglong)((uint)(lVar17 >> 0x3f) & 3)) >> 2);
  }
  *(longlong *)(lVar14 + 0x415998) = lVar17;
  lVar11 = lVar16;
  if (*(longlong *)(lVar14 + 0x4159b8) < lVar16) {
    lVar11 = *(longlong *)(lVar14 + 0x4159b8);
  }
  lVar20 = lVar15;
  if (lVar17 < lVar15) {
    lVar20 = lVar17;
  }
  lVar17 = lVar10;
  if (lVar10 <= lVar20 + lVar10) {
    lVar17 = lVar20 + lVar10;
  }
  if (lVar11 < lVar17) {
    lVar11 = lVar17;
  }
  *(longlong *)(lVar14 + 0x4159a8) = lVar11;
  lVar17 = 0;
  *(undefined8 *)(lVar14 + 0x4159b8) = 0;
  if (iVar8 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar20 = *(longlong *)(lVar14 + 0x415930);
  if (lVar11 < *(longlong *)(lVar14 + 0x415930)) {
    lVar20 = lVar11;
  }
  if (iVar8 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar8 != 2) {
    _DAT_ = _DAT_ + lVar10;
    _DAT_ = _DAT_ + lVar20;
  }
  lVar10 = *(longlong *)(lVar14 + 0x415a00);
  iVar8 = *(int *)(lVar14 + 0x415a40);
  if (((iVar8 != 1) || ((uVar5 & 0x20) == 0)) && (iVar8 != 1)) {
    lVar17 = *(longlong *)(lVar14 + 0x4159f8) * 3;
    lVar17 = ((lVar10 - *(longlong *)(lVar14 + 0x4159e8)) * 1000) / (longlong)iStack_2a0 +
             ((longlong)(lVar17 + (ulonglong)((uint)(lVar17 >> 0x3f) & 3)) >> 2);
  }
  *(longlong *)(lVar14 + 0x4159f8) = lVar17;
  lVar11 = lVar16;
  if (*(longlong *)(lVar14 + 0x415a18) < lVar16) {
    lVar11 = *(longlong *)(lVar14 + 0x415a18);
  }
  lVar20 = lVar15;
  if (lVar17 < lVar15) {
    lVar20 = lVar17;
  }
  lVar17 = lVar10;
  if (lVar10 <= lVar20 + lVar10) {
    lVar17 = lVar20 + lVar10;
  }
  if (lVar11 < lVar17) {
    lVar11 = lVar17;
  }
  *(longlong *)(lVar14 + 0x415a08) = lVar11;
  lVar20 = 0;
  *(undefined8 *)(lVar14 + 0x415a18) = 0;
  lVar17 = *(longlong *)(lVar14 + 0x415930);
  if (lVar11 < *(longlong *)(lVar14 + 0x415930)) {
    lVar17 = lVar11;
  }
  if ((iVar8 != 1) || ((uVar5 & 0x20) == 0)) {
    _DAT_ = _DAT_ + lVar10;
    _DAT_ = _DAT_ + lVar17;
  }
  lVar10 = *(longlong *)(lVar14 + 0x415a60);
  iVar8 = *(int *)(lVar14 + 0x415aa0);
  if (iVar8 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar8 != 1) {
    lVar17 = *(longlong *)(lVar14 + 0x415a58) * 3;
    lVar20 = ((lVar10 - *(longlong *)(lVar14 + 0x415a48)) * 1000) / (longlong)iStack_2a0 +
             ((longlong)(lVar17 + (ulonglong)((uint)(lVar17 >> 0x3f) & 3)) >> 2);
  }
  *(longlong *)(lVar14 + 0x415a58) = lVar20;
  if (*(longlong *)(lVar14 + 0x415a78) < lVar16) {
    lVar16 = *(longlong *)(lVar14 + 0x415a78);
  }
  if (lVar20 < lVar15) {
    lVar15 = lVar20;
  }
  lVar17 = lVar10;
  if (lVar10 <= lVar15 + lVar10) {
    lVar17 = lVar15 + lVar10;
  }
  if (lVar16 < lVar17) {
    lVar16 = lVar17;
  }
  *(longlong *)(lVar14 + 0x415a68) = lVar16;
  *(undefined8 *)(lVar14 + 0x415a78) = 0;
  if (iVar8 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar15 = *(longlong *)(lVar14 + 0x415930);
  if (lVar16 < *(longlong *)(lVar14 + 0x415930)) {
    lVar15 = lVar16;
  }
  if (iVar8 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  _DAT_ = _DAT_ + lVar10;
  _DAT_ = _DAT_ + lVar15;
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

