
undefined8 FUN_(longlong param_1,uint param_2)

{
  code *pcVar1;
  undefined8 uVar2;
  longlong unaff_GS_OFFSET;
  bool bVar3;
  
  if (*(int *)(param_1 + 0x10) != 0) {
    if (*(int *)(param_1 + 0x18) == 0) {
      LOCK();
      bVar3 = *(ulonglong *)(param_1 + 0x18) == 0;
      if (bVar3) {
        *(ulonglong *)(param_1 + 0x18) = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      }
      UNLOCK();
      if (bVar3) goto LAB_;
    }
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
  }
LAB_:
  if (*(longlong *)(param_1 + 0x20 + (ulonglong)(param_2 & 0xf) * 8) == 0) {
    return 0;
  }
  pcVar1 = (code *)swi(3);
  uVar2 = (*pcVar1)();
  return uVar2;
}

