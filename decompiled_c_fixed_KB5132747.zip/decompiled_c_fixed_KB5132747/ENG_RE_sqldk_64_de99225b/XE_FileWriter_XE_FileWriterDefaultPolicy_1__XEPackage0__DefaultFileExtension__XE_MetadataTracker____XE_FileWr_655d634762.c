
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  uint uVar4;
  ulonglong uVar5;
  
  *param_1 = 0x1bce28;
  plVar1 = param_1 + 0xcd;
  if (*plVar1 != 0) {
    uVar5 = 0;
    if (*(int *)param_1[5] != 0) {
      do {
        lVar2 = uVar5 * 8;
        lVar3 = *(longlong *)(lVar2 + *plVar1);
        if (lVar3 != 0) {
          func_0x(lVar2,*(undefined8 *)(lVar2 + *plVar1),*(undefined8 *)(lVar3 + 0x288));
        }
        uVar4 = (int)uVar5 + 1;
        uVar5 = (ulonglong)uVar4;
      } while (uVar4 < *(uint *)param_1[5]);
    }
    if (param_1[0xf1] != 0) {
      func_0x();
    }
  }
  if (param_1[0xf4] != -1) {
    (*_DAT_)();
  }
  param_1 = param_1 + 0xef;
  func_0x(*param_1);
  *param_1 = 0;
  func_0x(param_1);
  func_0x(*plVar1);
  *plVar1 = 0;
  lVar2 = *plVar1;
  if (lVar2 != 0) {
    plVar1 = (longlong *)(lVar2 + -8);
    func_0x(lVar2,8,*plVar1,0xfffffffffff89600);
    func_0x(plVar1,*plVar1 * 8 + 8);
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

