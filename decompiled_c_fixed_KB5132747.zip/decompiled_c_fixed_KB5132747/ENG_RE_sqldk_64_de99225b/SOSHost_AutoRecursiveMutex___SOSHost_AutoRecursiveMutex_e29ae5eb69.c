
void FUN_(longlong *param_1)

{
  longlong *plVar1;
  int iVar2;
  longlong lVar3;
  
  iVar2 = *(int *)(param_1 + 2);
  while (iVar2 != 0) {
    lVar3 = *param_1;
    plVar1 = (longlong *)(lVar3 + 0x40);
    *plVar1 = *plVar1 + -1;
    if (*plVar1 == 0) {
      LOCK();
      UNLOCK();
      *(undefined8 *)(lVar3 + 0x30) = 0;
      *(undefined8 *)(lVar3 + 0x38) = 0;
      func_0x(lVar3,0);
    }
    plVar1 = param_1 + 2;
    *(int *)plVar1 = *(int *)plVar1 + -1;
    iVar2 = *(int *)plVar1;
  }
  return;
}

