
void FUN_(uint *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  
  if (param_1[4] != 0) {
    lVar1 = *(longlong *)(param_1 + 6);
    if (param_1[5] == 0) {
      (**(code **)(**(longlong **)(lVar1 + 0x260) + 0x10))
                (*(longlong **)(lVar1 + 0x260),lVar1,1,param_4,0xfffffffffffffffe);
    }
    else {
      *(uint *)(lVar1 + 800) = *(uint *)(lVar1 + 800) | 0x800;
    }
  }
  func_0x(param_1 + 8);
  *(uint *)(*(longlong *)(param_1 + 2) + 0x268) =
       *(uint *)(*(longlong *)(param_1 + 2) + 0x268) & ~*param_1;
  return;
}

