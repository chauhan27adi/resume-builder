
/* WARNING: Control flow encountered bad instruction data */

void FUN_(longlong *param_1)

{
  longlong lVar1;
  
  lVar1 = *param_1;
  if (lVar1 != 0) {
    func_0x(lVar1,0x48,*(undefined8 *)(lVar1 + -8),0xfc640);
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}

