
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 *param_2,int param_3,short *param_4,int param_5)

{
  ushort *puVar1;
  longlong lVar2;
  undefined4 uVar3;
  longlong lVar4;
  code *pcVar5;
  ushort *puVar6;
  char cVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  longlong lVar11;
  undefined4 *puVar12;
  undefined8 uVar13;
  byte bVar14;
  uint uVar15;
  short sVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  uint *puVar21;
  ulonglong uVar22;
  byte *pbVar23;
  ushort *puVar24;
  ushort uVar25;
  ulonglong uVar26;
  undefined auStack_388 [32];
  undefined8 uStack_368;
  undefined2 auStack_358 [4];
  undefined4 auStack_350 [2];
  undefined8 uStack_348;
  undefined8 uStack_340;
  undefined4 uStack_338;
  uint uStack_330;
  undefined4 uStack_32c;
  uint uStack_328;
  uint uStack_324;
  int aiStack_320 [2];
  uint auStack_318 [2];
  longlong lStack_310;
  longlong lStack_308;
  longlong lStack_300;
  short *psStack_2f8;
  undefined8 uStack_2f0;
  longlong lStack_2e8;
  undefined4 uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined8 uStack_2d0;
  undefined8 uStack_2c8;
  undefined4 uStack_2c0;
  undefined4 auStack_2b8 [2];
  undefined8 uStack_2b0;
  undefined8 uStack_2a8;
  longlong lStack_2a0;
  undefined8 uStack_298;
  undefined8 uStack_290;
  undefined auStack_288 [16];
  undefined auStack_268 [14];
  undefined uStack_25a;
  undefined2 auStack_258 [256];
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_388;
  lVar2 = param_1 + 200;
  puVar21 = (uint *)0x4;
  uVar13 = *(undefined8 *)(*(longlong *)(param_1 + 0x90) + 0x80);
  uStack_25a = 1;
  uStack_330 = 0x200;
  aiStack_320[0] = param_3;
  lStack_308 = param_1;
  psStack_2f8 = param_4;
  uStack_2f0 = uVar13;
  if ((*(byte *)(param_1 + 0xd8) & 4) == 0) {
    lVar11 = func_0x();
    if (lVar11 != 0) {
      lVar11 = func_0x();
      puVar21 = (uint *)(lVar11 + 0x10);
    }
    *puVar21 = *puVar21 | 2;
    (*_DAT_)(0x59,0x43,0x10,6);
  }
  func_0x(*(undefined8 *)(param_1 + 0xe0),0,*(undefined4 *)(param_1 + 0xf0));
  lVar11 = 0;
  if ((((*(short *)(param_1 + 0x22) == 1) || (param_5 == 0)) || (aiStack_320[0] != 0)) ||
     ((*(short *)(param_1 + 0x22) != 2 && (*(short *)(param_1 + 0xb4) == 0)))) {
    func_0x(lVar2,param_4);
  }
  else {
    lVar11 = 1;
  }
  auStack_358[0] = *(undefined2 *)(param_2 + 1);
  pbVar23 = *(byte **)(*(longlong *)(param_1 + 0xb8) + 8);
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar16 = *(short *)(pbVar23 + 0x10);
  if ((sVar16 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar23 + 0xa4d3e0) + 0x1404478) != '\0')) {
    sVar16 = 0x1fa4;
  }
  uStack_368._0_4_ = 0;
  lStack_300 = lVar11;
  (*_DAT_)(auStack_350,auStack_358,sVar16);
  (*_DAT_)(*(undefined8 *)(*(longlong *)(param_1 + 0xc0) + 8),auStack_350,0xffffffff,0);
  uStack_32c = *param_2;
  lVar4 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar16 = *(short *)(lVar4 + 0x50);
  if ((sVar16 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar4 + 0x40) + 0xa4d3e0) + 0x1404478) !=
      '\0')) {
    sVar16 = 0x1fa4;
  }
  uStack_368._0_4_ = 0;
  (*_DAT_)(auStack_350,&uStack_32c,sVar16);
  (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0x20,auStack_350,0xffffffff,0)
  ;
  lVar4 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar16 = *(short *)(lVar4 + 0x90);
  if ((sVar16 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar4 + 0x80) + 0xa4d3e0) + 0x1404478) !=
      '\0')) {
    sVar16 = 0x1fa4;
  }
  uStack_368._0_4_ = 0;
  (*_DAT_)(auStack_350,aiStack_320,sVar16);
  (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0x40,auStack_350,0xffffffff,0)
  ;
  auStack_358[0] = *(undefined2 *)(param_1 + 0xb4);
  lVar4 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar16 = *(short *)(lVar4 + 0xd0);
  if ((sVar16 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar4 + 0xc0) + 0xa4d3e0) + 0x1404478) !=
      '\0')) {
    sVar16 = 0x1fa4;
  }
  uStack_368 = (uint *)((ulonglong)uStack_368._4_4_ << 0x20);
  (*_DAT_)(auStack_350,auStack_358,sVar16);
  (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0x60,auStack_350,0xffffffff,0)
  ;
  sVar16 = *(short *)(param_1 + 0xb4);
  uVar26 = 4;
  if (sVar16 != 0) {
    puVar12 = (undefined4 *)
              func_0x(*(undefined8 *)(*(longlong *)(param_1 + 0x90) + 0x80),param_4);
    uVar3 = *puVar12;
    auStack_358[0] = *(undefined2 *)(puVar12 + 1);
    lVar4 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
    auStack_350[0] = 3;
    uStack_348 = 0;
    uStack_340 = 0;
    uStack_338 = 0;
    sVar16 = *(short *)(lVar4 + 0x110);
    if ((sVar16 == -1) ||
       (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar4 + 0x100) + 0xa4d3e0) + 0x1404478)
        != '\0')) {
      sVar16 = 0x1fa4;
    }
    uStack_368 = (uint *)((ulonglong)uStack_368 & 0xffffffff00000000);
    (*_DAT_)(auStack_350,auStack_358,sVar16);
    (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0x80,auStack_350,0xffffffff,
                     0);
    lVar4 = *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8);
    auStack_350[0] = 3;
    uStack_348 = 0;
    uStack_340 = 0;
    uStack_338 = 0;
    sVar16 = *(short *)(lVar4 + 0x150);
    if ((sVar16 == -1) ||
       (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar4 + 0x140) + 0xa4d3e0) + 0x1404478)
        != '\0')) {
      sVar16 = 0x1fa4;
    }
    uStack_368 = (uint *)((ulonglong)uStack_368 & 0xffffffff00000000);
    uStack_32c = uVar3;
    (*_DAT_)(auStack_350,&uStack_32c,sVar16);
    (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + 0xa0,auStack_350,0xffffffff,
                     0);
    sVar16 = *(short *)(param_1 + 0xb4);
    uVar26 = 6;
  }
  lStack_310 = 0;
  uStack_2d0 = 0;
  uStack_2d8 = 0;
  lStack_2e8 = *(longlong *)(*(longlong *)(param_1 + 0x90) + 0x80);
  uStack_2e0 = 7;
  if (sVar16 == 0) {
    uStack_2e0 = 3;
  }
  uStack_2c8 = 0;
  uStack_2c0 = 0;
  lVar4 = **(longlong **)(*(longlong *)(lStack_2e8 + 8) + 0x160);
  if (sVar16 == 0) {
    uStack_2dc = *(undefined4 *)(lVar4 + 0x10);
  }
  else {
    uStack_2dc = *(undefined4 *)(lVar4 + 0x1c);
  }
  iVar10 = func_0x(&lStack_2e8,&lStack_310);
  lVar4 = lStack_310;
  while (lStack_310 = lVar4, iVar10 != 0) {
    auStack_2b8[0] = 0;
    auStack_288 = ZEXT816(0);
    uStack_290 = 0;
    if (lVar11 == 0) {
      if ((*(byte *)(lVar4 + 0x21) & 8) == 0) {
        uStack_2b0 = *(undefined8 *)(param_1 + 0x90);
        uStack_2a8 = *(undefined8 *)(param_1 + 0x100);
        uStack_368 = &uStack_328;
        uStack_298 = 0;
        uStack_324 = 0;
        uStack_328 = 0;
        lStack_2a0 = lVar2;
        if ((char)*(byte *)(lVar4 + 0x21) < '\0') {
          lVar11 = func_0x(auStack_2b8,*(undefined4 *)(lVar4 + 0x3c),lVar4,&uStack_324);
        }
        else {
          lVar11 = func_0x(auStack_2b8,0,*(undefined4 *)(lVar4 + 0x24));
        }
        uVar17 = uStack_328;
        if ((uStack_328 & 4) != 0) {
          (*_DAT_)(6,0x54,0x16,3);
        }
        if ((lVar11 == 0) ||
           (((cVar7 = *(char *)(lVar4 + 0x34), uStack_324 == 0 &&
             (((10 < (byte)(cVar7 + 0x5bU) || ((0x505U >> ((byte)(cVar7 + 0x5bU) & 0x1f) & 1) == 0))
              && (cVar7 != -0x11)))) && (cVar7 != -0x19)))) {
          *(undefined *)(uVar26 * 0x20 + *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8)) = 3;
          lVar11 = lStack_300;
        }
        else {
          pbVar23 = (byte *)(uVar26 * 0x40 + *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8));
          if ((uVar17 & 2) == 0) {
            auStack_350[0] = 3;
            uStack_348 = 0;
            uStack_340 = 0;
            uStack_338 = 0;
            uVar25 = *(ushort *)(pbVar23 + 0x10);
            if ((uVar25 == 0xffff) ||
               (uVar8 = uVar25,
               *(char *)((ulonglong)*(byte *)((ulonglong)*pbVar23 + 0xa4d3e0) + 0x1404478) != '\0'))
            {
              uVar8 = 0x1fa4;
            }
            uVar17 = uStack_324;
            if (uVar8 < uStack_324) {
              if ((uVar25 == 0xffff) ||
                 (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar23 + 0xa4d3e0) + 0x1404478) !=
                  '\0')) {
                uVar25 = 0x1fa4;
              }
              uVar17 = (uint)uVar25;
            }
            uStack_368 = (uint *)CONCAT44(uStack_368._4_4_,1);
            (*_DAT_)(auStack_350,lVar11,uVar17,pbVar23);
          }
          else {
            auStack_350[0] = 0xe700;
            uStack_338 = 0;
            uStack_348 = 0xdb6160;
            uStack_340 = 0x18;
          }
          if (0 < *(int *)(param_1 + 0xb0)) {
            puVar12 = (undefined4 *)
                      (*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + uVar26 * 0x20);
            if ((*(byte *)((longlong)puVar12 + 2) & 1) != 0) {
              (*_DAT_)(puVar12,pbVar23);
            }
            *puVar12 = 3;
            *(undefined8 *)(puVar12 + 2) = 0;
            *(undefined8 *)(puVar12 + 4) = 0;
            puVar12[6] = 0;
          }
          uStack_368 = (uint *)0x0;
          (*_DAT_)(*(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) + uVar26 * 0x20,
                           *(undefined8 *)(param_1 + 0x30),pbVar23,auStack_350);
          lVar11 = lStack_300;
        }
        goto LAB_;
      }
    }
    else {
      *(undefined *)(uVar26 * 0x20 + *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8)) = 3;
LAB_:
      uVar26 = (ulonglong)(ushort)((short)uVar26 + 1);
    }
    iVar10 = func_0x(&lStack_2e8);
    uVar13 = uStack_2f0;
    param_4 = psStack_2f8;
    lVar4 = lStack_310;
  }
  if (*(short *)(param_1 + 0xb4) == 0) {
    uStack_368 = (uint *)0x0;
    func_0x(auStack_268,uVar13,param_4,0);
    uStack_368 = (uint *)CONCAT44(uStack_368._4_4_,1);
    func_0x(auStack_268,auStack_258,&uStack_330,0);
    if (0x1ff < uStack_330) {
      uStack_330 = 0x1fe;
    }
    if (0x1ff < ((longlong)(int)uStack_330 & 0xfffffffffffffffeU)) {
      func_0x();
      pcVar5 = (code *)swi(3);
      (*pcVar5)();
      return;
    }
    *(undefined2 *)((longlong)auStack_258 + ((longlong)(int)uStack_330 & 0xfffffffffffffffeU)) = 0;
    lVar11 = uVar26 * 0x20;
    lVar2 = *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8);
    *(undefined4 *)(lVar11 + lVar2) = 0xe703;
    *(undefined8 *)(lVar11 + 8 + lVar2) = 0;
    *(undefined8 *)(lVar11 + 0x10 + lVar2) = 0;
    *(undefined4 *)(lVar11 + 0x18 + lVar2) = 0;
    lVar2 = *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8);
    *(undefined2 **)(lVar11 + 8 + lVar2) = auStack_258;
    *(ulonglong *)(lVar11 + 0x10 + lVar2) = (ulonglong)uStack_330;
    *(undefined *)(lVar11 + *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8)) = 0;
  }
  else {
    *(undefined *)(uVar26 * 0x20 + *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8)) = 3;
  }
  auStack_318[0] = *(uint *)(param_4 + 2);
  puVar1 = (ushort *)(param_4 + 1);
  uVar25 = (short)uVar26 + 1;
  if (*param_4 == 0) {
    if (auStack_318[0] == 0) {
      pbVar23 = *(byte **)(param_4 + 4);
      iVar10 = 0;
      uVar17 = *(uint *)(param_4 + 8);
      uVar26 = (ulonglong)uVar17;
      *puVar1 = 0;
      *(uint *)(param_4 + 10) = uVar17;
      bVar14 = *pbVar23;
      if ((bVar14 & 0x10) != 0) {
        uVar17 = uVar17 + 2 + (*(ushort *)(pbVar23 + uVar26) + 7 >> 3);
        uVar26 = (ulonglong)uVar17;
        *(uint *)(param_4 + 10) = uVar17;
        bVar14 = *pbVar23;
      }
      if ((bVar14 & 0x20) == 0) {
        *(int *)(param_4 + 2) = (int)uVar26;
        param_4[0xe] = 0;
        *(int *)(param_4 + 0xc) = (int)uVar26;
      }
      else {
        puVar24 = (ushort *)(pbVar23 + uVar26);
        uVar8 = *puVar24;
        param_4[0xe] = uVar8;
        if (uVar8 == 0) {
          cVar7 = func_0x(0x13d8720);
          if ((cVar7 != '\0') && (cVar7 = func_0x(), cVar7 != '\0')) {
            cVar7 = func_0x(0x13d8720);
            if (cVar7 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_368 = (uint *)0x0;
              (*_DAT_)(1,0xcc812c,0xde8218,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_4 + 4),3);
          uVar8 = param_4[0xe];
          uVar26 = (ulonglong)*(uint *)(param_4 + 10);
        }
        uVar15 = (uint)uVar8;
        uVar17 = (int)uVar26 + (uVar15 + 1) * 2;
        *(uint *)(param_4 + 0xc) = uVar17;
        if (0x1f9e < uVar17) {
          cVar7 = func_0x(0x13d8720);
          if ((cVar7 != '\0') && (cVar7 = func_0x(), cVar7 != '\0')) {
            cVar7 = func_0x(0x13d8720);
            if (cVar7 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_368 = (uint *)0x0;
              (*_DAT_)(1,0xcc812c,0xde8218,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_4 + 4),4);
          uVar15 = (uint)(ushort)param_4[0xe];
          uVar17 = *(uint *)(param_4 + 0xc);
        }
        uVar18 = puVar24[uVar15] & 0x7fff;
        *(uint *)(param_4 + 2) = uVar18;
        if (uVar18 < uVar17) {
          cVar7 = func_0x(0x13d8720);
          if ((cVar7 != '\0') && (cVar7 = func_0x(), cVar7 != '\0')) {
            cVar7 = func_0x(0x13d8720);
            if (cVar7 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_368 = (uint *)0x0;
              (*_DAT_)(1,0xcc812c,0xde8218,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_4 + 4),4);
          uVar17 = *(uint *)(param_4 + 0xc);
          uVar15 = (uint)(ushort)param_4[0xe];
          uVar18 = *(uint *)(param_4 + 2);
        }
        puVar6 = puVar24;
        if ((short)uVar15 != 0) {
          do {
            uVar19 = puVar6[1] & 0x7fff;
            if ((uVar19 < uVar17) || (uVar18 = *(uint *)(param_4 + 2), uVar18 < uVar19)) {
              cVar7 = func_0x(0x13d8720);
              if ((cVar7 != '\0') && (cVar7 = func_0x(), cVar7 != '\0')) {
                cVar7 = func_0x(0x13d8720);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_368 = (uint *)0x0;
                  (*_DAT_)(1,0xcc812c,0xde8218,0x82a);
                }
              }
              func_0x(*(undefined8 *)(param_4 + 4),4);
              uVar18 = *(uint *)(param_4 + 2);
            }
            uVar15 = (uint)(ushort)param_4[0xe];
            iVar10 = iVar10 + 1;
            param_1 = lStack_308;
            puVar6 = puVar6 + 1;
            uVar17 = uVar19;
          } while (iVar10 < (int)uVar15);
        }
        uVar26 = (ulonglong)uVar18;
        if ((short)puVar24[(ulonglong)(uVar15 - 1) + 1] < 0) {
          pbVar23 = *(byte **)(param_4 + 4);
          do {
            uVar17 = *(ushort *)
                      (pbVar23 + (ulonglong)uVar15 * 2 + (ulonglong)*(uint *)(param_4 + 10)) &
                     0x7fff;
            if (uVar15 == 1) {
              uVar18 = *(uint *)(param_4 + 0xc);
              uVar20 = (ulonglong)uVar18;
LAB_:
              if ((uVar17 < (uint)uVar20) ||
                 (auStack_318[0] = *(uint *)(param_4 + 2), auStack_318[0] < uVar17))
              goto LAB_;
            }
            else {
              uVar18 = *(uint *)(param_4 + 0xc);
              uVar20 = (ulonglong)
                       (*(ushort *)
                         (pbVar23 + (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(param_4 + 10) - 2)
                         ) & 0x7fff);
              if (uVar18 <= (*(ushort *)
                              (pbVar23 +
                              (ulonglong)uVar15 * 2 + ((ulonglong)*(uint *)(param_4 + 10) - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
              func_0x(pbVar23,7);
              uVar18 = *(uint *)(param_4 + 0xc);
              auStack_318[0] = *(uint *)(param_4 + 2);
            }
            uVar26 = (ulonglong)auStack_318[0];
            uVar15 = (uint)uVar20;
            if ((uVar15 < uVar18) || (auStack_318[0] < uVar15)) goto LAB_;
            pbVar23 = *(byte **)(param_4 + 4);
            if (*(ushort *)(pbVar23 + uVar20) == 5) {
              *puVar1 = *puVar1 | 2;
              param_4[0xe] = param_4[0xe] + -1;
              uVar22 = uVar20 & 0xffff;
              param_4[0x15] = (short)uVar20;
              uVar26 = *(ulonglong *)(param_4 + 4);
              uVar8 = param_4[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar22 + 2 + uVar26) >> 0xe & 1) != 0) {
                uVar8 = *(ushort *)(uVar22 + 2 + uVar26) & 0x3800 | param_4[0x16] & 0xc7ffU;
              }
              param_4[0x16] = uVar8;
              uVar9 = (uVar8 ^ *(ushort *)(uVar22 + 2 + uVar26)) & 0x7ff ^ uVar8;
              param_4[0x16] = uVar9;
              uVar20 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar22 + (uVar8 >> 0xb & 7) * 2 +
                       uVar26;
              if (uVar20 < uVar22 + uVar26) {
                func_0x(uVar22 + uVar26,0x19);
                uVar9 = param_4[0x16];
                uVar22 = (ulonglong)(ushort)param_4[0x15];
                uVar26 = (ulonglong)*(uint *)(param_4 + 4);
              }
              if (uVar17 - uVar15 <
                  (((uVar9 & 0x7ff) * 2 - (int)uVar22) - (int)uVar26) + (int)uVar20) {
                func_0x(uVar22 + *(longlong *)(param_4 + 4),0x19);
                uVar9 = param_4[0x16];
              }
              if ((uVar9 & 0x3800) != 0) {
                puVar24 = (ushort *)
                          (*(longlong *)(param_4 + 4) + (ulonglong)(ushort)param_4[0x15] + 4);
                iVar10 = 0;
                if ((uVar9 & 0x3800) != 0) {
                  do {
                    if ((uVar9 & 0x7ff) < (*puVar24 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_4[0x15] + *(longlong *)(param_4 + 4),
                                      0x1a);
                      uVar9 = param_4[0x16];
                    }
                    iVar10 = iVar10 + 1;
                    puVar24 = puVar24 + 1;
                  } while (iVar10 < (int)(uVar9 >> 0xb & 7));
                }
              }
              uVar26 = (ulonglong)*(uint *)(param_4 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar23 + uVar20) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar8 = param_4[0xe] - 1;
            param_4[0xe] = uVar8;
            if (uVar8 == 0) goto LAB_;
            uVar15 = (uint)uVar8;
          } while ((short)puVar24[(ulonglong)(uVar8 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar23 = *(byte **)(param_4 + 4);
        }
      }
      if ((*pbVar23 & 0x40) == 0) {
        *(undefined4 *)(param_4 + 0x13) = 0;
      }
      else {
        *(int *)(param_4 + 0x13) = (int)uVar26;
        *(int *)(param_4 + 2) = (int)uVar26 + 0xe;
        uVar13 = func_0x(puVar1);
        func_0x(uVar13,&lStack_308);
        iVar10 = func_0x(&lStack_308);
        *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + iVar10;
        uVar26 = (ulonglong)*(uint *)(param_4 + 2);
      }
      if ((*(ulonglong *)(param_4 + 0xf) != 0) &&
         (*(ulonglong *)(param_4 + 0xf) < uVar26 + *(longlong *)(param_4 + 4))) {
        cVar7 = func_0x(0x13d8720);
        if ((cVar7 != '\0') && (cVar7 = func_0x(), cVar7 != '\0')) {
          cVar7 = func_0x(0x13d8720);
          if (cVar7 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_368 = (uint *)0x0;
            (*_DAT_)(1,0xcc812c,0xde8218,0x886);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 4),0x12);
        uVar26 = (ulonglong)*(uint *)(param_4 + 2);
      }
      auStack_318[0] = (uint)uVar26;
      if ((auStack_318[0] == 0) || (0x3f3c < auStack_318[0])) {
        cVar7 = func_0x(0x13d8720);
        if ((cVar7 != '\0') && (cVar7 = func_0x(), cVar7 != '\0')) {
          cVar7 = func_0x(0x13d8720);
          if (cVar7 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_368 = (uint *)0x0;
            (*_DAT_)(1,0xcc812c,0xde8218,0x88b);
          }
        }
        func_0x(*(undefined8 *)(param_4 + 4),5);
        auStack_318[0] = *(uint *)(param_4 + 2);
      }
    }
LAB_:
    if (8 < auStack_318[0]) goto LAB_;
    bVar14 = **(byte **)(param_4 + 4) & 0xe;
  }
  else {
    if (auStack_318[0] == 0) {
      func_0x(puVar1);
      auStack_318[0] = *(uint *)(param_4 + 2);
    }
    if (8 < auStack_318[0]) goto LAB_;
    bVar14 = **(byte **)(param_4 + 4) & 0x1c;
  }
  if ((bVar14 == 0) || (bVar14 == 0xc)) {
    auStack_318[0] = 9;
  }
LAB_:
  pbVar23 = (byte *)((ulonglong)uVar25 * 0x40 + *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8));
  auStack_350[0] = 3;
  uStack_348 = 0;
  uStack_340 = 0;
  uStack_338 = 0;
  sVar16 = *(short *)(pbVar23 + 0x10);
  if ((sVar16 == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*pbVar23 + 0xa4d3e0) + 0x1404478) != '\0')) {
    sVar16 = 0x1fa4;
  }
  uStack_368 = (uint *)((ulonglong)uStack_368._4_4_ << 0x20);
  (*_DAT_)(auStack_350,auStack_318,sVar16);
  (*_DAT_)((ulonglong)uVar25 * 0x20 + *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8),
                   auStack_350,0xffffffff,0);
  (*_DAT_)(*(undefined8 *)(param_1 + 0xa8),
                   *(undefined8 *)(*(longlong *)(param_1 + 0xc0) + 8));
  *(int *)(param_1 + 0xb0) = *(int *)(param_1 + 0xb0) + 1;
  func_0x(uStack_58 ^ (ulonglong)auStack_388);
  return;
}

