
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined2 param_1,uint *param_2,uint *param_3)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar6;
  uint *puVar7;
  longlong unaff_GS_OFFSET;
  undefined auStack_138 [32];
  undefined8 uStack_118;
  undefined8 uStack_110;
  undefined uStack_108;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  undefined4 auStack_e8 [2];
  undefined8 uStack_e0;
  undefined4 uStack_d8;
  undefined auStack_d0 [16];
  undefined8 uStack_c0;
  longlong lStack_b8;
  undefined2 uStack_b0;
  undefined8 uStack_a8;
  int iStack_a0;
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  longlong lStack_58;
  uint uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  uint *puVar5;
  
  uStack_c0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_138;
  if ((DAT_ & 0x20) != 0) {
    puVar7 = (uint *)0x0;
    uStack_e0 = 0;
    uStack_d8 = 1;
    auStack_d0._0_8_ =
         *(longlong **)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
          0x90);
    auStack_d0._8_8_ = 0;
    cVar1 = (**(code **)(*(longlong *)auStack_d0._0_8_ + 0x1d0))();
    if (cVar1 == '\0') {
      uStack_f8 = 0;
      uStack_100 = 0;
      uStack_108 = 0;
      uStack_110 = CONCAT44(uStack_110._4_4_,2);
      uStack_118 = CONCAT44(uStack_118._4_4_,1);
      (**(code **)(*(longlong *)auStack_d0._0_8_ + 8))(auStack_d0._0_8_,0x1ad5390,0x20);
      uStack_e0 = CONCAT44(uStack_e0._4_4_,2);
    }
    else {
      (**(code **)(*(longlong *)auStack_d0._0_8_ + 0xe8))
                (auStack_d0._0_8_,1,1,(longlong)&uStack_e0 + 4);
      uStack_d8 = 1;
      uStack_e0 = CONCAT44(uStack_e0._4_4_,4);
    }
    iVar2 = func_0x(param_1,0x1ad5390);
    if (iVar2 != 0) {
      uStack_a8 = (**(code **)(*(longlong *)auStack_d0._0_8_ + 0x1b0))();
      lStack_b8 = 0;
      auStack_98 = ZEXT816(0);
      auStack_88 = ZEXT816(0);
      auStack_78 = ZEXT816(0);
      auStack_68 = ZEXT816(0);
      lStack_58 = 0;
      uStack_50 = 0;
      uStack_48 = 0;
      uStack_40 = 0;
      uStack_b0 = param_1;
      iStack_a0 = iVar2;
      iVar2 = func_0x(&lStack_b8,3,1);
      if (iVar2 != 0) {
        uStack_110 = lStack_b8;
        uStack_118 = uStack_48;
        iVar2 = (**(code **)(*(longlong *)auStack_98._8_8_ + 0x18))(auStack_98._8_8_,0,1);
        if (iVar2 == 0) {
          auStack_e8[0] = 0;
          puVar6 = puVar7;
          if (((lStack_b8 != 0) && (lStack_58 != 0)) && (uStack_50 != 0)) {
            uVar3 = func_0x(&lStack_b8,0x1ad53b8,auStack_e8);
            if (((lStack_58 != 0) && (uVar3 - 1 < 0xfffffffe)) &&
               (puVar6 = (uint *)0x0, uStack_50 != 0)) {
              puVar5 = puVar7;
              do {
                if (*(ulonglong *)((longlong)puVar5 * 0x58 + lStack_58) == (ulonglong)uVar3) {
                  puVar6 = (uint *)((longlong)puVar5 * 0x58 + lStack_58);
                  if (puVar6 != (uint *)0x0) goto LAB_;
                  break;
                }
                uVar4 = (int)puVar5 + 1;
                puVar5 = (uint *)(ulonglong)uVar4;
              } while (uVar4 < uStack_50);
            }
            uStack_118 = CONCAT44(uStack_118._4_4_,iStack_a0);
            (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
            puVar6 = (uint *)(*(longlong *)(puVar6 + 2) + lStack_b8);
          }
          *param_2 = *puVar6;
          auStack_e8[0] = 0;
          if (((lStack_b8 != 0) && (lStack_58 != 0)) && (uStack_50 != 0)) {
            uVar3 = func_0x(&lStack_b8,0x1ad52c0,auStack_e8);
            puVar6 = puVar7;
            if (((lStack_58 != 0) && (uVar3 - 1 < 0xfffffffe)) && (uStack_50 != 0)) {
              do {
                if (*(ulonglong *)((longlong)puVar7 * 0x58 + lStack_58) == (ulonglong)uVar3) {
                  puVar6 = (uint *)((longlong)puVar7 * 0x58 + lStack_58);
                  if (puVar6 != (uint *)0x0) goto LAB_;
                  break;
                }
                uVar4 = (int)puVar7 + 1;
                puVar7 = (uint *)(ulonglong)uVar4;
                puVar6 = (uint *)0x0;
              } while (uVar4 < uStack_50);
            }
            uStack_118 = CONCAT44(uStack_118._4_4_,iStack_a0);
            (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
            puVar7 = (uint *)(lStack_b8 + *(longlong *)(puVar6 + 2));
          }
          uVar3 = *puVar7;
          *param_3 = uVar3;
          if (10 < *param_2) {
            *param_2 = 10;
            uVar3 = *param_3;
          }
          if (10 < uVar3) {
            *param_3 = 10;
          }
        }
      }
      func_0x(&lStack_b8);
    }
    func_0x(&uStack_e0,0);
    func_0x(0x1ad52e0,*param_2,*param_3);
    if ((int)uStack_e0 != 0) {
      func_0x(&uStack_e0,0);
    }
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_138);
  return;
}

