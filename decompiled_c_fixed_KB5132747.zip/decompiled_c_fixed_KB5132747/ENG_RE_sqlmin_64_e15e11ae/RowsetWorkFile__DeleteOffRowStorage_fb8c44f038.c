
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2)

{
  byte *pbVar1;
  byte *pbVar2;
  longlong lVar3;
  byte bVar4;
  ushort uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined auVar8 [16];
  char cVar9;
  int iVar10;
  int iVar11;
  ulonglong uVar12;
  undefined *puVar13;
  uint uVar14;
  short sVar15;
  uint uVar16;
  undefined *puVar17;
  ulonglong uVar18;
  undefined8 uStack_150;
  undefined auStack_148 [32];
  undefined8 *apuStack_128 [2];
  undefined8 uStack_118;
  undefined2 uStack_110;
  uint uStack_108;
  int iStack_104;
  undefined4 auStack_100 [2];
  undefined2 uStack_f8;
  ushort uStack_f6;
  undefined4 uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined2 uStack_e0;
  short sStack_de;
  short sStack_dc;
  undefined2 uStack_da;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  undefined4 uStack_c8;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [2];
  undefined auStack_ae [2];
  undefined auStack_ac [12];
  uint uStack_a0;
  undefined4 uStack_9c;
  short sStack_98;
  short sStack_96;
  short sStack_94;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined2 uStack_88;
  undefined6 uStack_86;
  uint uStack_80;
  undefined4 uStack_7c;
  short *psStack_78;
  short *psStack_70;
  short sStack_68;
  undefined6 uStack_66;
  undefined auStack_60 [8];
  undefined8 uStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_118;
  puVar17 = (undefined *)0x0;
  pbStack_f0 = (byte *)0x0;
  uStack_f8 = 0xffff;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d8 = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_e8 = (undefined *)0x0;
  puVar13 = auStack_148;
  if ((*(byte *)(*(longlong *)(param_1 + 0x10) + 0x4c) & 1) == 0) goto LAB_;
  uVar12 = param_2 & 0xffffffffffffe000;
  sVar15 = 3;
  iVar11 = (int)((longlong)((uVar12 - param_2) + 0x1ffe) >> 1);
  iStack_c4 = iVar11;
  if (*(char *)(uVar12 + 2) < '\0') {
    pbVar1 = (byte *)(uVar12 + 0x60);
    sStack_98 = 0;
    sStack_96 = 0;
    sStack_94 = 0;
    _auStack_ae = SUB1614(ZEXT816(0),2);
    auStack_b0 = (undefined  [2])0xffff;
    uStack_8a = 0;
    auStack_ac._4_8_ = 0;
    uStack_80 = 0;
    uStack_7c = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    psStack_78 = (short *)0x0;
    _auStack_60 = ZEXT812(0);
    uStack_58._4_4_ = 0;
    auVar8 = _auStack_60;
    uStack_58 = 0;
    uStack_50 = 0;
    psStack_70 = (short *)0x0;
    sStack_68 = 0;
    uStack_66 = 0;
    auStack_c0 = ZEXT816(0);
    uVar6 = 0;
    if (*(short *)(uVar12 + 0x24) == 0) {
LAB_:
      auStack_c0._8_8_ = uVar6;
      uStack_118 = *(undefined8 *)(uVar12 + 0x28);
      uStack_110 = *(undefined2 *)(uVar12 + 0x30);
    }
    else {
      cVar9 = *(char *)(uVar12 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(uVar12 + 0x18) != 99) {
LAB_:
          if (cVar9 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar9 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uVar12 + 0x18) != 99) goto LAB_;
      }
      uStack_118 = CONCAT26(uStack_118._6_2_,*(undefined6 *)(uVar12 + 0x20));
      uStack_150 = 0x10015b;
      _auStack_60 = auVar8;
      cVar9 = func_0x(&uStack_118,0x7b3240);
      uVar6 = auStack_c0._8_8_;
      if (cVar9 == '\0') goto LAB_;
      uStack_150 = 0x10016b;
      func_0x(uVar12,&uStack_118);
    }
    uVar6 = uStack_118;
    auStack_60 = (undefined  [8])uStack_118;
    uStack_58._4_4_ = *(undefined4 *)(uVar12 + 0x20);
    auStack_c0._0_8_ = pbVar1;
    lVar3 = (ulonglong)*pbVar1 * 6;
    uVar18 = (ulonglong)*(short *)(lVar3 + 0x831b24);
    uStack_118 = CONCAT44((int)((ulonglong)uStack_118 >> 0x20),*(undefined4 *)(lVar3 + 0x831b20));
    uStack_58._0_2_ = uStack_110;
    auStack_60 = (undefined  [8])uVar6;
    auStack_b0 = (undefined  [2])0xffff;
    uVar16 = 0;
    _auStack_b0 = _auStack_b0 & 0xffffffff;
    auStack_ac._4_8_ = 0;
    uStack_92 = 0;
    uStack_90 = 0;
    uStack_88 = 0;
    uStack_86 = 0;
    uStack_a0 = 0;
    uStack_9c = 0;
    sStack_68 = 0;
    psStack_78 = (short *)0x0;
    psStack_70 = (short *)0x0;
    uVar14 = uStack_a0;
    if ((*pbVar1 & 2) != 0) {
      pbVar2 = pbVar1 + uVar18;
      auStack_ac._4_8_ = pbVar2;
      if ((pbVar1[uVar18] & 1) == 0) {
        auVar8._14_2_ = 0;
        auVar8._0_14_ = _auStack_ae;
        _auStack_b0 = auVar8 << 0x10;
        uStack_8a = 0;
        uStack_88 = 0;
        uVar14 = uVar16;
        switch(*pbVar2 & 0xe) {
        default:
          uVar5 = *(ushort *)(pbVar2 + 2);
          uVar14 = (uint)uVar5;
          if (0x1f9d < uVar5 - 1) {
            uStack_150 = 0x10041f;
            func_0x(pbVar2,6);
          }
          break;
        case 4:
          uVar14 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar14 = 1;
        }
      }
      else {
        bVar4 = *pbVar2;
        switch(bVar4 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            auStack_ae = (undefined  [2])
                         ((*(ushort *)(pbVar2 + 1) & 0x7f) << 8 | *(ushort *)(pbVar2 + 1) >> 8);
            sStack_98 = 3;
          }
          else {
            auStack_ae = (undefined  [2])(ushort)pbVar2[1];
            sStack_98 = 2;
          }
          auStack_b0 = (undefined  [2])0x1;
          sStack_94 = (short)((ushort)auStack_ae + 1 >> 1) + sStack_98;
          if ((ushort)auStack_ae < 0x1f) {
            uStack_80 = 0;
            sStack_96 = 0;
            uStack_88 = 0;
            uStack_86 = 0;
            uStack_a0 = 0;
            uStack_9c = 0;
            uVar14 = uStack_a0;
          }
          else {
            iVar10 = (ushort)auStack_ae - 1;
            uStack_80 = 0;
            uStack_88 = 0;
            uStack_86 = 0;
            uStack_a0 = 0;
            uStack_9c = 0;
            sStack_96 = ((short)(iVar10 / 0x1e) + (short)(iVar10 >> 0x1f)) -
                        (short)((longlong)iVar10 * 0x88888889 >> 0x3f);
            uVar14 = uStack_a0;
          }
          break;
        case 4:
          if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
            uVar16 = 1;
            auStack_ac._0_4_ = 0xf;
          }
          else {
            auStack_ac._0_4_ = 1;
          }
          sStack_98 = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_8a = 0;
          _auStack_b0 = 1;
          uStack_88 = 0;
          uStack_86 = 0;
          uStack_a0 = 0;
          uStack_9c = 0;
          uVar14 = uStack_a0;
          uStack_80 = uVar16;
          break;
        case 8:
          sStack_98 = 0;
          sStack_96 = 0;
          sStack_94 = 0;
          uStack_8a = 0;
          _auStack_b0 = 0x900000001;
          uStack_80 = 0;
          uStack_88 = 0;
          uStack_86 = 0;
          uStack_a0 = 0;
          uStack_9c = 0;
          uVar14 = uStack_a0;
        }
      }
    }
    uStack_a0 = uVar14;
    uStack_90 = 0;
    uStack_92 = 0;
    if ((*(byte *)auStack_c0._0_8_ & 4) != 0) {
      if (uStack_118._2_2_ != 0) {
        uVar18 = (ulonglong)*(ushort *)(uVar12 + 0x61 + (longlong)uStack_118._2_2_ * 2);
      }
      psStack_78 = (short *)(pbVar1 + uVar18);
      psStack_70 = psStack_78 + 1;
      sStack_68 = (*psStack_78 + 1) * 2;
    }
    if (auStack_c0._8_8_ != 0) {
      uStack_150 = 0x1004bc;
      func_0x(auStack_c0._8_8_,auStack_c0);
    }
    puVar17 = auStack_c0;
  }
  pbStack_f0 = (byte *)(*(ushort *)(uVar12 + (0xfff - (longlong)iVar11) * 2) + uVar12);
  if ((*pbStack_f0 & 1) == 0) {
    uStack_f8 = 0;
    uStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
    uVar14 = (uint)*(ushort *)(uVar12 + 0xe);
    switch(*pbStack_f0 & 0xe) {
    default:
      uVar14 = (uint)*(ushort *)(pbStack_f0 + 2);
      if (0x1f9d < *(ushort *)(pbStack_f0 + 2) - 1) {
        uStack_150 = 0x1006f6;
        func_0x(pbStack_f0,6);
      }
      break;
    case 4:
      uVar14 = 9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar14 = 1;
    }
    uStack_e8 = (undefined *)CONCAT44(uStack_e8._4_4_,uVar14);
    uStack_da = (undefined2)(uVar12 + 0x2000);
    uStack_d8 = (undefined6)(uVar12 + 0x2000 >> 0x10);
  }
  else {
    uStack_f8 = 1;
    bVar4 = *pbStack_f0;
    uStack_e8 = puVar17;
    switch(bVar4 & 0x1c) {
    default:
      if ((char)pbStack_f0[1] < '\0') {
        uStack_e0 = 3;
        uStack_f6 = (*(ushort *)(pbStack_f0 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_f0 + 1) >> 8;
      }
      else {
        uStack_f6 = (ushort)pbStack_f0[1];
        sVar15 = 2;
        uStack_e0 = 2;
      }
      sStack_dc = ((ushort)(uStack_f6 + 1) >> 1) + sVar15;
      if (uStack_f6 < 0x1f) {
        sStack_de = 0;
        uStack_d0 = (undefined2)(uVar12 + 0x2000);
        uStack_ce = (undefined6)(uVar12 + 0x2000 >> 0x10);
        uStack_f4 = 0;
        uStack_c8 = 0;
      }
      else {
        iVar11 = uStack_f6 - 1;
        uStack_f4 = 0;
        uStack_c8 = 0;
        sStack_de = ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                    (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
        uStack_d0 = (undefined2)(uVar12 + 0x2000);
        uStack_ce = (undefined6)(uVar12 + 0x2000 >> 0x10);
      }
      break;
    case 4:
      if (((bVar4 & 0x1c) == 4) && ((bVar4 & 2) != 0)) {
        uStack_e0 = 0;
        sStack_de = 0;
        sStack_dc = 0;
        uStack_da = 0;
        uStack_d0 = (undefined2)(uVar12 + 0x2000);
        uStack_ce = (undefined6)(uVar12 + 0x2000 >> 0x10);
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_f4 = 0xf;
        uStack_c8 = 1;
      }
      else {
        uStack_e0 = 0;
        sStack_de = 0;
        sStack_dc = 0;
        uStack_da = 0;
        uStack_d0 = (undefined2)(uVar12 + 0x2000);
        uStack_ce = (undefined6)(uVar12 + 0x2000 >> 0x10);
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_f4 = 1;
        uStack_c8 = 0;
      }
      break;
    case 8:
      uStack_e0 = 0;
      sStack_de = 0;
      sStack_dc = 0;
      uStack_da = 0;
      uStack_d0 = (undefined2)(uVar12 + 0x2000);
      uStack_ce = (undefined6)(uVar12 + 0x2000 >> 0x10);
      uStack_f6 = 0;
      uStack_d8 = 0;
      uStack_d2 = 0;
      uStack_f4 = 9;
      uStack_c8 = 0;
    }
  }
  *(undefined8 *)(param_1 + 0x70) = 0;
  *(undefined2 **)(param_1 + 0x68) = &uStack_f8;
  apuStack_128[0] = (undefined8 *)&uStack_108;
  uStack_108 = 0;
  uStack_150 = 0x100774;
  apuStack_128[1] = &uStack_118;
  func_0x
            (*(undefined8 *)(param_1 + 0x88),*(undefined8 *)(param_1 + 0x98),auStack_100,&iStack_104
            );
  puVar13 = auStack_148;
  if (iStack_104 != 0) {
    uVar12 = (ulonglong)uStack_108 + 0xf;
    if (uVar12 <= uStack_108) {
      uVar12 = 0xffffffffffffff0;
    }
    uVar12 = uVar12 & 0xfffffffffffffff0;
    uStack_150 = 0x10079d;
    func_0x();
    lVar3 = -uVar12;
    puVar13 = auStack_148 + lVar3;
    uVar6 = *(undefined8 *)(param_1 + 0x98);
    uVar7 = *(undefined8 *)(param_1 + 0x88);
    *(longlong *)((longlong)apuStack_128 + lVar3) = (longlong)&uStack_118 + lVar3;
    *(undefined8 *)(auStack_148 + lVar3 + -8) = 0x1007c1;
    func_0x(uVar7,uVar6,auStack_100[0]);
    *(undefined8 *)(auStack_148 + lVar3 + -8) = 0x1007d5;
    func_0x(param_1 + 0x80,2);
  }
LAB_:
  uVar12 = uStack_48 ^ (ulonglong)&uStack_118;
  *(undefined8 *)(puVar13 + -8) = 0x1007e4;
  func_0x(uVar12);
  return;
}

