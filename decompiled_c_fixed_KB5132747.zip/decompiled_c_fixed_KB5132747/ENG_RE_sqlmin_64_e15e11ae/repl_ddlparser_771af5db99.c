
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  short sVar4;
  uint uVar5;
  undefined8 uVar6;
  undefined2 uVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  longlong lVar11;
  undefined4 *puVar12;
  longlong *plVar13;
  undefined8 uVar14;
  longlong lVar15;
  longlong lVar16;
  longlong lVar17;
  ulonglong uVar18;
  longlong lVar19;
  longlong lVar20;
  undefined8 *puVar21;
  byte *pbVar22;
  ushort uVar23;
  longlong lVar24;
  longlong lVar25;
  longlong unaff_GS_OFFSET;
  longlong lStackX_8;
  undefined4 auStackX_10 [2];
  longlong lStackX_18;
  undefined auStackX_20 [8];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  *(undefined8 *)(&stack0x00000138 + lVar11) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00000fb8 + lVar11) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11);
  *(undefined8 *)(&stack0x00000050 + lVar11) = param_1;
  lVar20 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar25 = *(longlong *)(lVar20 + 0x100);
  if (lVar25 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100078;
    (*_DAT_)(0);
    lVar25 = *(longlong *)(lVar20 + 0x100);
  }
  uVar14 = *(undefined8 *)(lVar25 + 1000);
  *(undefined4 *)(&stack0x00000040 + lVar11) = 1;
  uVar6 = **(undefined8 **)
            (*(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
            + 0x40);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000c1;
  iVar8 = func_0x(uVar6,4);
  uVar23 = 0;
  *(undefined8 *)(&stack0x00000078 + lVar11) = 0x18574b8;
  *(undefined8 *)(&stack0x00000078 + lVar11) = 0x17ec8f0;
  *(undefined8 *)(&stack0x00000080 + lVar11) = 0;
  *(undefined (*) [16])(&stack0x00000088 + lVar11) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000098 + lVar11) = 0;
  *(undefined2 *)(&stack0x000000a0 + lVar11) = 0;
  *(undefined8 *)(&stack0x000000a4 + lVar11) = 0;
  *(undefined8 *)(&stack0x000000b0 + lVar11) = 0;
  uVar7 = *(undefined2 *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x50) + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10014d;
  puVar12 = (undefined4 *)func_0x(uVar7);
  uVar9 = *puVar12;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100155;
  uVar9 = (*_DAT_)(uVar9);
  lVar25 = **(longlong **)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x40);
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = uVar9;
  uVar9 = *(undefined4 *)(lVar25 + 0x2c);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10019a;
  func_0x(&stack0x00000078 + lVar11,uVar14,5,uVar9);
  puVar21 = (undefined8 *)0x2251ac0;
  lVar25 = -1;
  do {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1001ad;
    uVar7 = (*_DAT_)();
    lVar20 = lVar25;
    do {
      lVar20 = lVar20 + 1;
    } while (*(short *)(puVar21[1] + lVar20 * 2) != 0);
    *(undefined4 *)((longlong)&lStackX_18 + lVar11) = 0;
    *(undefined4 *)((longlong)auStackX_10 + lVar11) = 1;
    *(undefined2 *)((longlong)&lStackX_8 + lVar11) = 0;
    *(undefined8 *)(auStackX_20 + lVar11 + -0x20) = 0;
    *(undefined2 *)(&stack0xfffffffffffffff8 + lVar11) = uVar7;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 1;
    (&stack0xffffffffffffffe8)[lVar11] = (char)lVar20;
    uVar14 = *puVar21;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1001f9;
    (*_DAT_)(&stack0x00000078 + lVar11,uVar23,uVar14);
    uVar23 = uVar23 + 1;
    puVar21 = puVar21 + 2;
  } while (uVar23 < 5);
  *(undefined4 *)(&stack0x00000030 + lVar11) = 0;
  uVar14 = *(undefined8 *)(&stack0x00000050 + lVar11);
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = _DAT_;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10023a;
  func_0x(&stack0x00000170 + lVar11,0,0,0);
  *(undefined4 *)(&stack0x00000030 + lVar11) = 1;
  lVar20 = *(longlong *)
            (*(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
            + 0x70);
  *(undefined4 *)(auStackX_20 + lVar11 + -0x20) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar11) = 0;
  *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
  uVar6 = *(undefined8 *)(lVar20 + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100295;
  (*_DAT_)(uVar6,&stack0x00000078 + lVar11,0xe0,iVar8 != 0);
  auStackX_20[lVar11] = 0;
  *(undefined *)((longlong)&lStackX_18 + lVar11) = 1;
  *(undefined4 *)((longlong)auStackX_10 + lVar11) = 0;
  *(undefined4 *)((longlong)&lStackX_8 + lVar11) = 0;
  *(undefined4 *)(auStackX_20 + lVar11 + -0x20) = 0;
  (&stack0xfffffffffffffff8)[lVar11] = 0;
  (&stack0xfffffffffffffff0)[lVar11] = 0;
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002d7;
  (*_DAT_)(&stack0x000001e8 + lVar11,param_2,param_3,1);
  *(uint *)(&stack0x00000428 + lVar11) = *(uint *)(&stack0x00000428 + lVar11) | 0x1000000;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002f8;
  func_0x(&stack0x00000978 + lVar11,0,0x208);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10030d;
  func_0x(&stack0x00000868 + lVar11,0,0x102);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100321;
  plVar13 = (longlong *)(*_DAT_)(&stack0x000001e8 + lVar11,uVar14,0);
  if (((plVar13 != (longlong *)0x0) && (lVar20 = *plVar13, lVar20 != 0)) &&
     (*(char *)(lVar20 + 0x19) == '\t')) {
    sVar4 = *(short *)(lVar20 + 0xa6);
    *(short *)(&stack0x00000058 + lVar11) = sVar4;
    if (sVar4 == 0xd8) {
      *(longlong *)(&stack0x00000048 + lVar11) = lVar20;
      uVar7 = *(undefined2 *)(*(longlong *)(lVar20 + 0x68) + 0x48);
      uVar14 = *(undefined8 *)(*(longlong *)(lVar20 + 0x68) + 0x40);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10037f;
      func_0x(&stack0x00000140 + lVar11,uVar14,uVar7);
      iVar8 = *(int *)(&stack0x00000168 + lVar11);
      *(int *)(&stack0x000000b8 + lVar11) = iVar8 * 2;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10039d;
      uVar14 = (*_DAT_)();
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) =
           *(undefined8 *)(&stack0x00000150 + lVar11);
      *(int *)(&stack0xffffffffffffffe8 + lVar11) = (iVar8 * 2) / 2;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003ca;
      iVar8 = func_0x(&stack0x00000c98 + lVar11,0x81,0x190e828,uVar14);
      *(int *)(&stack0x00000028 + lVar11) = iVar8;
      if (iVar8 < 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003eb;
        func_0x(0x1ab5220,0x4df,*(undefined4 *)(&stack0x00000028 + lVar11));
      }
      iVar8 = *(int *)(&stack0x0000016c + lVar11);
      *(int *)(&stack0x000000bc + lVar11) = iVar8 * 2;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100408;
      uVar14 = (*_DAT_)();
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) =
           *(undefined8 *)(&stack0x00000158 + lVar11);
      *(int *)(&stack0xffffffffffffffe8 + lVar11) = (iVar8 * 2) / 2;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100435;
      iVar8 = func_0x(&stack0x00000b88 + lVar11,0x81,0x190e828,uVar14);
      *(int *)(&stack0x00000028 + lVar11) = iVar8;
      if (iVar8 < 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100456;
        func_0x(0x1ab5220,0x4e2,*(undefined4 *)(&stack0x00000028 + lVar11));
      }
      while (lVar20 = *(longlong *)(&stack0x00000048 + lVar11), lVar20 != 0) {
        *(undefined4 *)(&stack0x0000002c + lVar11) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100499;
        func_0x(&stack0x00000978 + lVar11,0,0x208);
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004ae;
        func_0x(&stack0x00000868 + lVar11,0,0x102);
        cVar2 = *(char *)(lVar20 + 0x19);
        lVar24 = lVar25;
        if (cVar2 == '\x12') {
          puVar21 = (undefined8 *)(lVar20 + 0x20);
          *(undefined8 **)(&stack0x00000050 + lVar11) = puVar21;
          uVar5 = *(uint *)(lVar20 + 0x40);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004d1;
          uVar14 = (*_DAT_)();
          *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(lVar20 + 0x38);
          *(uint *)(&stack0xffffffffffffffe8 + lVar11) = uVar5 >> 1;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1004fa;
          iVar8 = func_0x(&stack0x00000978 + lVar11,0x81,0x190e828,uVar14);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (iVar8 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10051b;
            func_0x(0x1ab5220,0x4ec,*(undefined4 *)(&stack0x00000028 + lVar11));
            puVar21 = *(undefined8 **)(&stack0x00000050 + lVar11);
          }
          if ((*(byte *)((longlong)puVar21 + 0xb) & 0x40) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100587;
            uVar14 = (*_DAT_)();
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x18d33e8;
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1005af;
            iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
            *(int *)(&stack0x00000028 + lVar11) = iVar8;
            if (iVar8 < 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1005d0;
              func_0x(0x1ab5220,0x4f5,*(undefined4 *)(&stack0x00000028 + lVar11));
              puVar21 = *(undefined8 **)(&stack0x00000050 + lVar11);
            }
            uVar5 = *(uint *)(puVar21 + 2);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1005e3;
            uVar14 = (*_DAT_)();
            *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *puVar21;
            *(uint *)(&stack0xffffffffffffffe8 + lVar11) = uVar5 >> 1;
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10060b;
            iVar8 = func_0x(&stack0x00000868 + lVar11,0x81,0x190e828,uVar14);
            *(int *)(&stack0x00000028 + lVar11) = iVar8;
            lVar20 = 0;
            if (iVar8 < 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10062c;
              func_0x(0x1ab5220,0x4f7,*(undefined4 *)(&stack0x00000028 + lVar11));
            }
            do {
              if ((*(short *)(&stack0x00000868 + lVar20 * 2 + lVar11) !=
                   *(short *)(lVar20 * 2 + 0x1869ea0)) ||
                 (*(short *)(&stack0x0000086a + lVar20 * 2 + lVar11) !=
                  *(short *)(lVar20 * 2 + 0x1869ea2))) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10066a;
                uVar14 = (*_DAT_)();
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1845358;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100692;
                iVar8 = func_0x(&stack0x00000868 + lVar11,0x81,0x18e12a8,uVar14);
                *(int *)(&stack0x00000028 + lVar11) = iVar8;
                if (iVar8 < 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006b3;
                  func_0x(0x1ab5220,0x4fb,*(undefined4 *)(&stack0x00000028 + lVar11));
                }
                break;
              }
              lVar20 = lVar20 + 2;
            } while (lVar20 != 10);
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10052f;
            uVar14 = (*_DAT_)();
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x18d3410;
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100557;
            iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
            *(int *)(&stack0x00000028 + lVar11) = iVar8;
            if (iVar8 < 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10057c;
              func_0x(0x1ab5220,0x4f0,*(undefined4 *)(&stack0x00000028 + lVar11));
            }
          }
          lVar20 = **(longlong **)(&stack0x00000048 + lVar11);
          if ((lVar20 != 0) && (*(char *)(lVar20 + 0x19) == '\x0f')) {
            cVar2 = *(char *)(lVar20 + 0x20);
            if (cVar2 == '\a') {
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006e2;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1ab5248;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10070a;
              iVar8 = func_0x(&stack0x00000868 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10072b;
                func_0x(0x1ab5220,0x508,*(undefined4 *)(&stack0x00000028 + lVar11));
              }
            }
            else if (cVar2 == '\b') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10073e;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1a380f8;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100766;
              iVar8 = func_0x(&stack0x00000868 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100787;
                func_0x(0x1ab5220,0x50e,*(undefined4 *)(&stack0x00000028 + lVar11));
                *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
                goto LAB_;
              }
            }
            else if (cVar2 == '\x0f') goto LAB_;
          }
          goto LAB_;
        }
        if (cVar2 != '\x0f') {
          if (((cVar2 == '\t') && (lVar20 = **(longlong **)(&stack0x00000048 + lVar11), lVar20 != 0)
              ) && (*(char *)(lVar20 + 0x19) == '\x0f')) {
            pbVar22 = (byte *)(lVar20 + 0x20);
            *(byte **)(&stack0x00000060 + lVar11) = pbVar22;
            if (*pbVar22 == 0x13) {
              *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101319;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = _DAT_;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101341;
              iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101362;
                func_0x(0x1ab5220,0x5dd,*(undefined4 *)(&stack0x00000028 + lVar11));
              }
              goto LAB_;
            }
            if (*pbVar22 == 0x19) {
              *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101177;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x18d3410;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10119f;
              iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1011c0;
                func_0x(0x1ab5220,0x5c8,*(undefined4 *)(&stack0x00000028 + lVar11));
                pbVar22 = *(byte **)(&stack0x00000060 + lVar11);
              }
              if ((*(uint *)(pbVar22 + 4) & 0x200) == 0) {
                if ((*(uint *)(pbVar22 + 4) >> 8 & 1) == 0) {
                  *(undefined4 *)(&stack0x0000002c + lVar11) = 0;
                }
                else {
                  bVar3 = *pbVar22;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101245;
                  uVar14 = (*_DAT_)();
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
                       *(undefined8 *)((ulonglong)bVar3 * 0x10 + 0x2251878);
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10126e;
                  iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
                  *(int *)(&stack0x00000028 + lVar11) = iVar8;
                  if (iVar8 < 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10128f;
                    func_0x(0x1ab5220,0x5d1,*(undefined4 *)(&stack0x00000028 + lVar11));
                    pbVar22 = *(byte **)(&stack0x00000060 + lVar11);
                  }
                }
              }
              else {
                bVar3 = *pbVar22;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1011db;
                uVar14 = (*_DAT_)();
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
                     *(undefined8 *)((ulonglong)bVar3 * 0x10 + 0x2251870);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101204;
                iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
                *(int *)(&stack0x00000028 + lVar11) = iVar8;
                if (iVar8 < 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101229;
                  func_0x(0x1ab5220,0x5cc,*(undefined4 *)(&stack0x00000028 + lVar11));
                  pbVar22 = *(byte **)(&stack0x00000060 + lVar11);
                }
              }
              iVar8 = *(int *)(pbVar22 + 0xd8);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012b1;
              (*_DAT_)();
              *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(pbVar22 + 0xd0);
              *(int *)(&stack0xffffffffffffffe8 + lVar11) = iVar8 / 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012dd;
              iVar8 = func_0x(&stack0x00000978 + lVar11,0x81,0x190e828);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012fe;
                func_0x(0x1ab5220,0x5d6,*(undefined4 *)(&stack0x00000028 + lVar11));
              }
              goto LAB_;
            }
          }
          goto LAB_;
        }
        lVar20 = *(longlong *)(&stack0x00000048 + lVar11);
        pbVar22 = (byte *)(lVar20 + 0x20);
        *(byte **)(&stack0x00000038 + lVar11) = pbVar22;
        uVar18 = (ulonglong)*pbVar22;
        switch(*pbVar22) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 0xd:
        case 0xe:
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1007e0;
          uVar14 = (*_DAT_)();
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
               *(undefined8 *)(uVar18 * 0x10 + 0x2251870);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100809;
          iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (iVar8 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10082a;
            func_0x(0x1ab5220,0x525,*(undefined4 *)(&stack0x00000028 + lVar11));
            pbVar22 = *(byte **)(&stack0x00000038 + lVar11);
          }
          piVar1 = (int *)(pbVar22 + 0xd8);
          iVar8 = *piVar1;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100845;
          uVar14 = (*_DAT_)();
          *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(pbVar22 + 0xd0);
          *(int *)(&stack0xffffffffffffffe8 + lVar11) = iVar8 / 2;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100871;
          iVar8 = func_0x(&stack0x00000978 + lVar11,0x81,0x190e828,uVar14);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (iVar8 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100892;
            func_0x(0x1ab5220,0x527,*(undefined4 *)(&stack0x00000028 + lVar11));
            pbVar22 = *(byte **)(&stack0x00000038 + lVar11);
          }
          bVar3 = *pbVar22;
          if ((bVar3 == 1) || (bVar3 == 2)) {
            if ((*(longlong **)(pbVar22 + 0x28) != (longlong *)0x0) &&
               (**(longlong **)(pbVar22 + 0x28) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100ae7;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1ab5200;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b0f;
              iVar8 = func_0x(&stack0x00000868 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b34;
                func_0x(0x1ab5220,0x554,*(undefined4 *)(&stack0x00000028 + lVar11));
                *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
                break;
              }
            }
          }
          else if (bVar3 == 5) {
            if (((*piVar1 == 0) && (*(longlong *)(pbVar22 + 8) != 0)) &&
               (lVar20 = lVar25, *(char *)(*(longlong *)(pbVar22 + 8) + 0x19) == '\x01')) {
              do {
                lVar20 = lVar20 + 1;
              } while (*(short *)(&stack0x00000868 + lVar20 * 2 + lVar11) != 0);
              *(longlong *)(&stack0x000000c0 + lVar11) = lVar20 * 2;
              lVar19 = lVar25;
              do {
                lVar19 = lVar19 + 1;
              } while (*(short *)(&stack0x00000978 + lVar19 * 2 + lVar11) != 0);
              *(longlong *)(&stack0x000000c8 + lVar11) = lVar19 * 2;
              lVar17 = lVar25;
              do {
                lVar17 = lVar17 + 1;
              } while (*(short *)(&stack0x00000b88 + lVar17 * 2 + lVar11) != 0);
              *(longlong *)(&stack0x000000d0 + lVar11) = lVar17 * 2;
              lVar16 = lVar25;
              do {
                lVar16 = lVar16 + 1;
              } while (*(short *)(&stack0x00000c98 + lVar16 * 2 + lVar11) != 0);
              *(longlong *)(&stack0x000000d8 + lVar11) = lVar16 * 2;
              lVar15 = lVar25;
              do {
                lVar15 = lVar15 + 1;
              } while (*(short *)(&stack0x00000758 + lVar15 * 2 + lVar11) != 0);
              *(longlong *)(&stack0x000000e0 + lVar11) = lVar15 * 2;
              *(undefined **)((longlong)&lStackX_18 + lVar11) = &stack0x00000078 + lVar11;
              *(int *)((longlong)auStackX_10 + lVar11) = (int)(lVar20 * 2);
              *(undefined **)((longlong)&lStackX_8 + lVar11) = &stack0x00000868 + lVar11;
              *(int *)(auStackX_20 + lVar11 + -0x20) = (int)(lVar19 * 2);
              *(undefined **)(&stack0xfffffffffffffff8 + lVar11) = &stack0x00000978 + lVar11;
              *(int *)(&stack0xfffffffffffffff0 + lVar11) = (int)(lVar17 * 2);
              *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000b88 + lVar11;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1009d4;
              func_0x(&stack0x00000758 + lVar11,lVar15 * 2 & 0xffffffff,
                              &stack0x00000c98 + lVar11,lVar16 * 2 & 0xffffffff);
              lVar20 = *(longlong *)(pbVar22 + 8);
              if (lVar20 == -0x20) {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a00;
                (*pcRam000000000173e400)(1,0x1c69f00,0x1c444e8,0x541);
              }
              uVar23 = *(ushort *)(lVar20 + 0x48);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a0c;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(lVar20 + 0x40);
              *(uint *)(&stack0xffffffffffffffe8 + lVar11) = (uint)(uVar23 >> 1);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a35;
              iVar8 = func_0x(&stack0x00000978 + lVar11,0x81,0x190e828,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a56;
                func_0x(0x1ab5220,0x544,*(undefined4 *)(&stack0x00000028 + lVar11));
                pbVar22 = *(byte **)(&stack0x00000038 + lVar11);
              }
            }
            if ((*(ushort *)(pbVar22 + 2) & 0x200) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a70;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1ab51e8;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a98;
              iVar8 = func_0x(&stack0x00000868 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100abd;
                func_0x(0x1ab5220,0x54a,*(undefined4 *)(&stack0x00000028 + lVar11));
                *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
                break;
              }
            }
          }
LAB_:
          *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
          break;
        default:
          goto LAB_;
        case 7:
        case 0xf:
          *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
          if ((*(uint *)(lVar20 + 0x24) >> 9 & 1) == 0) {
            if ((*(uint *)(lVar20 + 0x24) >> 8 & 1) == 0) {
              *(undefined4 *)(&stack0x0000002c + lVar11) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100dce;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
                   *(undefined8 *)(uVar18 * 0x10 + 0x2251878);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100df7;
              iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e18;
                func_0x(0x1ab5220,0x587,*(undefined4 *)(&stack0x00000028 + lVar11));
                pbVar22 = *(byte **)(&stack0x00000038 + lVar11);
              }
            }
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d67;
            uVar14 = (*_DAT_)();
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
                 *(undefined8 *)(uVar18 * 0x10 + 0x2251870);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d90;
            iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
            *(int *)(&stack0x00000028 + lVar11) = iVar8;
            if (iVar8 < 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100db5;
              func_0x(0x1ab5220,0x582,*(undefined4 *)(&stack0x00000028 + lVar11));
              pbVar22 = *(byte **)(&stack0x00000038 + lVar11);
            }
          }
          iVar8 = *(int *)(pbVar22 + 0xd8);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e37;
          uVar14 = (*_DAT_)();
          *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(pbVar22 + 0xd0);
          *(int *)(&stack0xffffffffffffffe8 + lVar11) = iVar8 / 2;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e63;
          iVar8 = func_0x(&stack0x00000978 + lVar11,0x81,0x190e828,uVar14);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (iVar8 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e84;
            func_0x(0x1ab5220,0x58c,*(undefined4 *)(&stack0x00000028 + lVar11));
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e8a;
          (*_DAT_)();
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1ab5248;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100eab;
          iVar8 = func_0x(&stack0x00000868 + lVar11,0x81,0x18e12a8);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (iVar8 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100ed0;
            func_0x(0x1ab5220,0x58e,*(undefined4 *)(&stack0x00000028 + lVar11));
          }
          goto LAB_;
        case 10:
        case 0xc:
          *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
          if ((*(uint *)(lVar20 + 0x24) >> 9 & 1) == 0) {
            if ((*(uint *)(lVar20 + 0x24) >> 8 & 1) == 0) {
              *(undefined4 *)(&stack0x0000002c + lVar11) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c8b;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
                   *(undefined8 *)(uVar18 * 0x10 + 0x2251878);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cb4;
              iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cd5;
                func_0x(0x1ab5220,0x573,*(undefined4 *)(&stack0x00000028 + lVar11));
                pbVar22 = *(byte **)(&stack0x00000038 + lVar11);
              }
            }
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c24;
            uVar14 = (*_DAT_)();
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
                 *(undefined8 *)(uVar18 * 0x10 + 0x2251870);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c4d;
            iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
            *(int *)(&stack0x00000028 + lVar11) = iVar8;
            if (iVar8 < 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c72;
              func_0x(0x1ab5220,0x56e,*(undefined4 *)(&stack0x00000028 + lVar11));
              pbVar22 = *(byte **)(&stack0x00000038 + lVar11);
            }
          }
          iVar8 = *(int *)(pbVar22 + 0xd8);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cf4;
          (*_DAT_)();
          *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(pbVar22 + 0xd0);
          *(int *)(&stack0xffffffffffffffe8 + lVar11) = iVar8 / 2;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d20;
          iVar8 = func_0x(&stack0x00000978 + lVar11,0x81,0x190e828);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (iVar8 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d45;
            func_0x(0x1ab5220,0x578,*(undefined4 *)(&stack0x00000028 + lVar11));
          }
LAB_:
          if (*(int *)(&stack0x0000002c + lVar11) != 0) break;
          goto LAB_;
        case 0xb:
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b4d;
          uVar14 = (*_DAT_)();
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
               *(undefined8 *)(uVar18 * 0x10 + 0x2251870);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b76;
          iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (iVar8 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b97;
            func_0x(0x1ab5220,0x561,*(undefined4 *)(&stack0x00000028 + lVar11));
            pbVar22 = *(byte **)(&stack0x00000038 + lVar11);
          }
          lVar20 = *(longlong *)(pbVar22 + 8);
          uVar23 = *(ushort *)(lVar20 + 0x48);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100bac;
          uVar14 = (*_DAT_)();
          *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(lVar20 + 0x40);
          *(uint *)(&stack0xffffffffffffffe8 + lVar11) = (uint)(uVar23 >> 1);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100bd5;
          iVar8 = func_0x(&stack0x00000978 + lVar11,0x81,0x190e828,uVar14);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (-1 < iVar8) goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100bfa;
          func_0x(0x1ab5220,0x563,*(undefined4 *)(&stack0x00000028 + lVar11));
          *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
          break;
        case 0x12:
          uVar9 = *(undefined4 *)(*(undefined8 **)(lVar20 + 0x58) + 1);
          uVar14 = **(undefined8 **)(lVar20 + 0x58);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101031;
          func_0x(&stack0x000001b0 + lVar11,uVar14,uVar9);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101052;
          iVar8 = func_0x
                            (&stack0x000001b0 + lVar11,&stack0x00000da8 + lVar11,0x208,0x5b);
          *(int *)(&stack0x0000005c + lVar11) = iVar8;
          *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
          bVar3 = *pbVar22;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10106f;
          uVar14 = (*_DAT_)();
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
               *(undefined8 *)((ulonglong)bVar3 * 0x10 + 0x2251870);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101098;
          iVar10 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
          *(int *)(&stack0x00000028 + lVar11) = iVar10;
          if (iVar10 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1010b9;
            func_0x(0x1ab5220,0x5b5,*(undefined4 *)(&stack0x00000028 + lVar11));
            iVar8 = *(int *)(&stack0x0000005c + lVar11);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1010cc;
          uVar14 = (*_DAT_)();
          *(undefined **)(&stack0xfffffffffffffff0 + lVar11) = &stack0x00000da8 + lVar11;
          *(ulonglong *)(&stack0xffffffffffffffe8 + lVar11) = (ulonglong)(longlong)iVar8 >> 1;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1010fa;
          iVar8 = func_0x(&stack0x00000978 + lVar11,0x81,0x190e828,uVar14);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (iVar8 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10111f;
            func_0x(0x1ab5220,0x5b7,*(undefined4 *)(&stack0x00000028 + lVar11));
          }
          break;
        case 0x16:
          *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
          if (*(longlong *)(lVar20 + 0x68) != 0) {
            if (*(char *)(*(longlong *)(lVar20 + 0x68) + 2) == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f55;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
                   *(undefined8 *)(uVar18 * 0x10 + 0x2251878);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f7e;
              iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100fa3;
                func_0x(0x1ab5220,0x59e,*(undefined4 *)(&stack0x00000028 + lVar11));
              }
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100efc;
              uVar14 = (*_DAT_)();
              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
                   *(undefined8 *)(uVar18 * 0x10 + 0x2251870);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f25;
              iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
              *(int *)(&stack0x00000028 + lVar11) = iVar8;
              if (iVar8 < 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f4a;
                func_0x(0x1ab5220,0x599,*(undefined4 *)(&stack0x00000028 + lVar11));
              }
            }
            break;
          }
          *(undefined4 *)(&stack0x0000002c + lVar11) = 0;
          goto LAB_;
        case 0x18:
          *(undefined4 *)(&stack0x0000002c + lVar11) = 1;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100fc6;
          uVar14 = (*_DAT_)();
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) =
               *(undefined8 *)(uVar18 * 0x10 + 0x2251870);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100fef;
          iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
          *(int *)(&stack0x00000028 + lVar11) = iVar8;
          if (iVar8 < 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101014;
            func_0x(0x1ab5220,0x5aa,*(undefined4 *)(&stack0x00000028 + lVar11));
          }
        }
LAB_:
        do {
          lVar24 = lVar24 + 1;
        } while (*(short *)(&stack0x00000868 + lVar24 * 2 + lVar11) != 0);
        *(longlong *)(&stack0x000000e8 + lVar11) = lVar24 * 2;
        lVar20 = lVar25;
        do {
          lVar20 = lVar20 + 1;
        } while (*(short *)(&stack0x00000978 + lVar20 * 2 + lVar11) != 0);
        *(longlong *)(&stack0x000000f0 + lVar11) = lVar20 * 2;
        lVar19 = lVar25;
        do {
          lVar19 = lVar19 + 1;
        } while (*(short *)(&stack0x00000b88 + lVar19 * 2 + lVar11) != 0);
        *(longlong *)(&stack0x000000f8 + lVar11) = lVar19 * 2;
        lVar17 = lVar25;
        do {
          lVar17 = lVar17 + 1;
        } while (*(short *)(&stack0x00000c98 + lVar17 * 2 + lVar11) != 0);
        *(longlong *)(&stack0x00000100 + lVar11) = lVar17 * 2;
        lVar17 = lVar25;
        do {
          lVar17 = lVar17 + 1;
        } while (*(short *)(&stack0x00000758 + lVar17 * 2 + lVar11) != 0);
        *(longlong *)(&stack0x00000108 + lVar11) = lVar17 * 2;
        *(undefined **)((longlong)&lStackX_18 + lVar11) = &stack0x00000078 + lVar11;
        *(int *)((longlong)auStackX_10 + lVar11) = (int)(lVar24 * 2);
        *(undefined **)((longlong)&lStackX_8 + lVar11) = &stack0x00000868 + lVar11;
        *(int *)(auStackX_20 + lVar11 + -0x20) = (int)(lVar20 * 2);
        *(undefined **)(&stack0xfffffffffffffff8 + lVar11) = &stack0x00000978 + lVar11;
        *(int *)(&stack0xfffffffffffffff0 + lVar11) = (int)(lVar19 * 2);
        *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000b88 + lVar11;
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101464;
        func_0x(&stack0x00000758 + lVar11,lVar17 * 2 & 0xffffffff,&stack0x00000c98 + lVar11)
        ;
LAB_:
        *(undefined8 *)(&stack0x00000048 + lVar11) = **(undefined8 **)(&stack0x00000048 + lVar11);
      }
    }
    else if ((sVar4 == 0x151) &&
            (lVar20 = *(longlong *)
                       (*(longlong *)(*(longlong *)(&stack0x00000228 + lVar11) + 0xb0) + 0x18),
            *(char *)(lVar20 + 0x91d) == '\x02')) {
      uVar5 = *(uint *)(lVar20 + 0x918);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1014b8;
      uVar14 = (*_DAT_)();
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = *(undefined8 *)(lVar20 + 0x910);
      *(uint *)(&stack0xffffffffffffffe8 + lVar11) = uVar5 >> 1;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1014e4;
      iVar8 = func_0x(&stack0x00000978 + lVar11,0x81,0x190e828,uVar14);
      *(int *)(&stack0x00000028 + lVar11) = iVar8;
      if (iVar8 < 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101505;
        func_0x(0x1ab5220,0x5fd,*(undefined4 *)(&stack0x00000028 + lVar11));
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10150b;
      uVar14 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1ab51c0;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101533;
      iVar8 = func_0x(&stack0x00000868 + lVar11,0x81,0x18e12a8,uVar14);
      *(int *)(&stack0x00000028 + lVar11) = iVar8;
      if (iVar8 < 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101554;
        func_0x(0x1ab5220,0x600,*(undefined4 *)(&stack0x00000028 + lVar11));
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10155a;
      uVar14 = (*_DAT_)();
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0x1ab51d0;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101582;
      iVar8 = func_0x(&stack0x00000758 + lVar11,0x81,0x18e12a8,uVar14);
      *(int *)(&stack0x00000028 + lVar11) = iVar8;
      lVar20 = lVar25;
      if (iVar8 < 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1015a3;
        func_0x(0x1ab5220,0x603,*(undefined4 *)(&stack0x00000028 + lVar11));
      }
      do {
        lVar20 = lVar20 + 1;
      } while (*(short *)(&stack0x00000868 + lVar20 * 2 + lVar11) != 0);
      *(longlong *)(&stack0x00000110 + lVar11) = lVar20 * 2;
      lVar24 = lVar25;
      do {
        lVar24 = lVar24 + 1;
      } while (*(short *)(&stack0x00000978 + lVar24 * 2 + lVar11) != 0);
      *(longlong *)(&stack0x00000118 + lVar11) = lVar24 * 2;
      do {
        lVar25 = lVar25 + 1;
      } while (*(short *)(&stack0x00000758 + lVar25 * 2 + lVar11) != 0);
      *(longlong *)(&stack0x00000120 + lVar11) = lVar25 * 2;
      *(undefined **)((longlong)&lStackX_18 + lVar11) = &stack0x00000078 + lVar11;
      *(int *)((longlong)auStackX_10 + lVar11) = (int)(lVar20 * 2);
      *(undefined **)((longlong)&lStackX_8 + lVar11) = &stack0x00000868 + lVar11;
      *(int *)(auStackX_20 + lVar11 + -0x20) = (int)(lVar24 * 2);
      *(undefined **)(&stack0xfffffffffffffff8 + lVar11) = &stack0x00000978 + lVar11;
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101655;
      func_0x(&stack0x00000758 + lVar11,lVar25 * 2 & 0xffffffff,0,0);
    }
  }
  *(undefined4 *)(&stack0x00000030 + lVar11) = 0;
  lVar25 = *(longlong *)
            (*(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
            + 0x70);
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
  uVar14 = *(undefined8 *)(lVar25 + 0x18);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1016a5;
  (*_DAT_)(uVar14,*(int *)(&stack0x00000040 + lVar11) == 0,&stack0x00000068 + lVar11,0);
  **(undefined8 **)
    (*(longlong *)
      ((ulonglong)*_DAT_ +
      *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) + 0x78)
       = *(undefined8 *)(&stack0x00000068 + lVar11);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1016e4;
  (*_DAT_)(&stack0x000001e8 + lVar11);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1016f2;
  func_0x(&stack0x00000170 + lVar11);
  lVar20 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar25 = *(longlong *)(lVar20 + 0x100);
  if (lVar25 == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101724;
    (*_DAT_)();
    lVar25 = *(longlong *)(lVar20 + 0x100);
  }
  if (*(int *)(lVar25 + 0x22c) != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10173a;
    (*_DAT_)();
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101749;
  (*_DAT_)(&stack0x00000078 + lVar11);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10175d;
  func_0x
            (*(ulonglong *)(&stack0x00000fb8 + lVar11) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar11));
  return;
}

