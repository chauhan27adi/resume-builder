
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,undefined8 param_3,undefined8 param_4,
                 undefined8 *param_5,int *param_6)

{
  ushort *puVar1;
  longlong *plVar2;
  undefined8 uVar3;
  short *psVar4;
  byte bVar5;
  char cVar6;
  int iVar7;
  uint *puVar8;
  undefined8 uVar9;
  longlong lVar10;
  undefined8 *puVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  ushort uVar14;
  ushort uVar15;
  uint uVar16;
  short *psVar17;
  longlong lVar18;
  undefined *puVar19;
  int iVar20;
  uint uVar21;
  int *piVar22;
  ushort uVar23;
  short sVar24;
  byte *pbVar25;
  ulonglong uVar26;
  undefined4 uVar27;
  uint uVar28;
  uint uVar29;
  ushort *puVar30;
  ushort *puVar31;
  ulonglong uVar32;
  undefined auStack_f8 [80];
  int aiStack_a8 [2];
  uint uStack_a0;
  undefined4 uStack_9c;
  int *piStack_98;
  uint auStack_90 [2];
  ushort *puStack_88;
  uint uStack_80;
  uint uStack_7c;
  int iStack_78;
  int iStack_74;
  longlong lStack_70;
  longlong lStack_68;
  ushort *puStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  short *psStack_48;
  longlong lStack_40;
  undefined8 uStack_38;
  ulonglong uStack_30;
  
  puVar19 = auStack_f8;
  uStack_30 = _DAT_ ^ (ulonglong)aiStack_a8;
  uVar28 = 0;
  uVar27 = 0;
  uStack_a0 = 0;
  uStack_9c = (uStack_9c >> 0x10 & 0xffe0) << 0x10;
  piStack_98 = (int *)0x0;
  lVar10 = *(longlong *)(param_1 + 0x58);
  lStack_68 = 0;
  lVar18 = *(longlong *)(lVar10 + 8);
  iStack_78 = -1;
  psVar17 = param_2;
  lStack_70 = lVar10;
  uStack_58 = param_4;
  uStack_50 = param_3;
  psStack_48 = param_2;
  lStack_40 = param_1;
  if (*(int *)(lVar18 + 0x100) == 2) {
    if ((*(byte *)(lVar18 + 0x42) & 4) == 0) {
      uVar13 = (ulonglong)*(uint *)(lVar18 + 0xb0);
      if (0x1f9e < *(uint *)(lVar18 + 0xb0)) {
        uVar13 = 0x1f9e;
      }
    }
    else {
      uVar13 = 0x1f9e;
    }
    uVar27 = (undefined4)uVar13;
    uVar12 = uVar13 + 0xf;
    if (uVar12 <= uVar13) {
      uVar12 = 0xffffffffffffff0;
    }
    uVar12 = uVar12 & 0xfffffffffffffff0;
    func_0x();
    puVar19 = auStack_f8 + -uVar12;
    lStack_68 = (longlong)aiStack_a8 + -uVar12;
  }
  lVar18 = lStack_68;
  puVar1 = (ushort *)(psVar17 + 1);
  *param_6 = 0;
  *param_5 = 0;
  if (*psVar17 == 0) {
    *(undefined8 *)(puVar19 + -8) = 0x100100;
    uStack_80 = func_0x(puVar1);
    lVar10 = lStack_70;
  }
  else {
    uStack_80 = (uint)*puVar1;
  }
  uVar16 = uStack_80;
  if (0 < (int)uStack_80) {
    do {
      uVar21 = ~uVar28;
      if ((uVar21 & 0xc0000000) == 0x80000000) {
        uVar9 = **(undefined8 **)(*(longlong *)(lVar10 + 8) + 0x160);
        *(undefined8 *)(puVar19 + -8) = 0x100163;
        puVar8 = (uint *)func_0x(uVar9,uVar21 & 0x1fffffff);
        lVar10 = lStack_70;
      }
      else {
        uVar9 = *(undefined8 *)(*(longlong *)(lVar10 + 8) + 0x160);
        *(undefined8 *)(puVar19 + -8) = 0x100148;
        puVar8 = (uint *)func_0x(uVar9);
      }
      if (puVar8 == (uint *)0x0) {
        *(undefined8 *)(puVar19 + -8) = 0x10017a;
        func_0x(lVar10,uVar21,&uStack_a0);
      }
      else {
        uStack_a0 = *puVar8;
        uStack_9c = puVar8[1];
        piStack_98 = *(int **)(puVar8 + 2);
      }
      *(undefined8 *)(puVar19 + -8) = 0x10018f;
      iVar7 = func_0x(param_2,&uStack_a0);
      if (iVar7 != 0) {
        iVar7 = 0;
        piVar22 = (int *)0x0;
        auStack_90[0] = 0;
        if (*param_2 == 0) {
          if ((uStack_a0 & 0xc0000000) == 0x80000000) {
            *(undefined8 *)(puVar19 + -8) = 0x100a72;
            iVar7 = func_0x(puVar1);
            if (iVar7 == 0) {
              aiStack_a8[0] = 0;
              iVar7 = aiStack_a8[0];
            }
            else {
              *(undefined8 *)(puVar19 + -8) = 0x100a8b;
              piVar22 = (int *)func_0x(psVar17 + 0x15,&uStack_a0,aiStack_a8,&puStack_88);
              iVar7 = aiStack_a8[0];
            }
          }
          else {
            uVar23 = uStack_9c._2_2_ >> 4 & 1;
            uVar16 = uStack_80;
            if (uVar23 != 0) {
              bVar5 = **(byte **)(psVar17 + 4);
              if ((bVar5 & 0x10) == 0) {
                if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                  piVar22 = piStack_98 + 1;
                  iVar7 = *piStack_98;
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(psVar17 + 8) <= (int)uStack_a0) ||
                      (*(ushort *)(*(byte **)(psVar17 + 4) + *(uint *)(psVar17 + 8)) <
                       (ushort)uStack_9c)) goto LAB_;
            }
            if ((int)uStack_a0 < 0) {
              if (*(int *)(psVar17 + 2) == 0) {
                pbVar25 = *(byte **)(psVar17 + 4);
                uVar16 = *(uint *)(psVar17 + 8);
                uVar13 = (ulonglong)uVar16;
                *puVar1 = 0;
                *(uint *)(psVar17 + 10) = uVar16;
                bVar5 = *pbVar25;
                if ((bVar5 & 0x10) != 0) {
                  uVar16 = uVar16 + 2 + (*(ushort *)(pbVar25 + uVar13) + 7 >> 3);
                  uVar13 = (ulonglong)uVar16;
                  *(uint *)(psVar17 + 10) = uVar16;
                  bVar5 = *pbVar25;
                }
                if ((bVar5 & 0x20) == 0) {
                  *(int *)(psVar17 + 2) = (int)uVar13;
                  psVar17[0xe] = 0;
                  *(int *)(psVar17 + 0xc) = (int)uVar13;
                }
                else {
                  puVar31 = (ushort *)(pbVar25 + uVar13);
                  uVar23 = *puVar31;
                  psVar17[0xe] = uVar23;
                  puStack_88 = puVar31;
                  if (uVar23 == 0) {
                    *(undefined8 *)(puVar19 + -8) = 0x100361;
                    cVar6 = func_0x(0x11c39f0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)(puVar19 + -8) = 0x10036a;
                      lVar10 = func_0x();
                      if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar19 + -8) = 0x100384;
                        cVar6 = func_0x(0x11c39f0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)(puVar19 + -8) = 0x1003a0;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar19 + 0x20) = 0;
                          *(undefined8 *)(puVar19 + -8) = 0x1003c6;
                          (*_DAT_)(1,0xab33fc,0xbd34e8,0x80f);
                        }
                      }
                    }
                    uVar9 = *(undefined8 *)(psVar17 + 4);
                    *(undefined8 *)(puVar19 + -8) = 0x1003d4;
                    func_0x(uVar9,3);
                    uVar13 = (ulonglong)*(uint *)(psVar17 + 10);
                    uVar23 = psVar17[0xe];
                  }
                  uVar16 = (int)uVar13 + (uVar23 + 1) * 2;
                  *(uint *)(psVar17 + 0xc) = uVar16;
                  if (0x1f9e < uVar16) {
                    *(undefined8 *)(puVar19 + -8) = 0x100404;
                    cVar6 = func_0x(0x11c39f0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)(puVar19 + -8) = 0x10040d;
                      lVar10 = func_0x();
                      if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar19 + -8) = 0x100427;
                        cVar6 = func_0x(0x11c39f0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)(puVar19 + -8) = 0x100443;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar19 + 0x20) = 0;
                          *(undefined8 *)(puVar19 + -8) = 0x100469;
                          (*_DAT_)(1,0xab33fc,0xbd34e8,0x816);
                        }
                      }
                    }
                    uVar9 = *(undefined8 *)(psVar17 + 4);
                    *(undefined8 *)(puVar19 + -8) = 0x100477;
                    func_0x(uVar9,4);
                    uVar23 = psVar17[0xe];
                    uVar16 = *(uint *)(psVar17 + 0xc);
                  }
                  uVar13 = (ulonglong)uVar23;
                  uVar23 = puVar31[uVar13];
                  *(uint *)(psVar17 + 2) = uVar23 & 0x7fff;
                  if ((uVar23 & 0x7fff) < uVar16) {
                    *(undefined8 *)(puVar19 + -8) = 0x1004a7;
                    cVar6 = func_0x(0x11c39f0);
                    if (cVar6 != '\0') {
                      *(undefined8 *)(puVar19 + -8) = 0x1004b0;
                      lVar10 = func_0x();
                      if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar19 + -8) = 0x1004ca;
                        cVar6 = func_0x(0x11c39f0);
                        if (cVar6 == '\0') {
                          *(undefined8 *)(puVar19 + -8) = 0x1004e6;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar19 + 0x20) = 0;
                          *(undefined8 *)(puVar19 + -8) = 0x10050c;
                          (*_DAT_)(1,0xab33fc,0xbd34e8,0x81d);
                        }
                      }
                    }
                    uVar9 = *(undefined8 *)(psVar17 + 4);
                    *(undefined8 *)(puVar19 + -8) = 0x10051a;
                    func_0x(uVar9,4);
                    uVar16 = *(uint *)(psVar17 + 0xc);
                    uVar13 = (ulonglong)(ushort)psVar17[0xe];
                  }
                  puVar30 = puVar31;
                  if ((short)uVar13 != 0) {
                    do {
                      puVar31 = puVar31 + 1;
                      uVar21 = *puVar31 & 0x7fff;
                      if ((uVar21 < uVar16) || (*(uint *)(psVar17 + 2) < uVar21)) {
                        *(undefined8 *)(puVar19 + -8) = 0x10055f;
                        cVar6 = func_0x(0x11c39f0);
                        if (cVar6 != '\0') {
                          *(undefined8 *)(puVar19 + -8) = 0x100568;
                          lVar10 = func_0x();
                          if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar19 + -8) = 0x100582;
                            cVar6 = func_0x(0x11c39f0);
                            if (cVar6 == '\0') {
                              *(undefined8 *)(puVar19 + -8) = 0x10059e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar19 + 0x20) = 0;
                              *(undefined8 *)(puVar19 + -8) = 0x1005c4;
                              (*_DAT_)(1,0xab33fc,0xbd34e8,0x82a);
                            }
                          }
                        }
                        uVar9 = *(undefined8 *)(psVar17 + 4);
                        *(undefined8 *)(puVar19 + -8) = 0x1005d2;
                        func_0x(uVar9,4);
                      }
                      uVar13 = (ulonglong)(ushort)psVar17[0xe];
                      iVar7 = iVar7 + 1;
                      puVar30 = puStack_88;
                      uVar16 = uVar21;
                    } while (iVar7 < (int)(uint)(ushort)psVar17[0xe]);
                  }
                  if ((short)puVar30[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
                    pbVar25 = *(byte **)(psVar17 + 4);
                    do {
                      uVar16 = *(ushort *)
                                (pbVar25 + uVar13 * 2 + (ulonglong)*(uint *)(psVar17 + 10)) & 0x7fff
                      ;
                      if ((int)uVar13 == 1) {
                        uVar21 = *(uint *)(psVar17 + 0xc);
                        uVar12 = (ulonglong)uVar21;
LAB_:
                        if ((uVar16 < (uint)uVar12) || (*(uint *)(psVar17 + 2) < uVar16))
                        goto LAB_;
                      }
                      else {
                        uVar21 = *(uint *)(psVar17 + 0xc);
                        uVar12 = (ulonglong)
                                 (*(ushort *)
                                   (pbVar25 + uVar13 * 2 + ((ulonglong)*(uint *)(psVar17 + 10) - 2))
                                 & 0x7fff);
                        if (uVar21 <= (*(ushort *)
                                        (pbVar25 +
                                        uVar13 * 2 + ((ulonglong)*(uint *)(psVar17 + 10) - 2)) &
                                      0x7fff)) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar19 + -8) = 0x100658;
                        func_0x(pbVar25,7);
                        uVar21 = *(uint *)(psVar17 + 0xc);
                      }
                      uVar29 = (uint)uVar12;
                      if ((uVar29 < uVar21) || (*(uint *)(psVar17 + 2) < uVar29)) goto LAB_;
                      pbVar25 = *(byte **)(psVar17 + 4);
                      if (*(ushort *)(pbVar25 + uVar12) == 5) {
                        *puVar1 = *puVar1 | 2;
                        psVar17[0xe] = psVar17[0xe] + -1;
                        uVar26 = uVar12 & 0xffff;
                        psVar17[0x15] = (short)uVar12;
                        uVar13 = *(ulonglong *)(psVar17 + 4);
                        uVar23 = psVar17[0x16] & 0xc7ffU;
                        if ((*(ushort *)(uVar26 + 2 + uVar13) >> 0xe & 1) != 0) {
                          uVar23 = *(ushort *)(uVar26 + 2 + uVar13) & 0x3800 |
                                   psVar17[0x16] & 0xc7ffU;
                        }
                        psVar17[0x16] = uVar23;
                        uVar15 = (uVar23 ^ *(ushort *)(uVar26 + 2 + uVar13)) & 0x7ff ^ uVar23;
                        psVar17[0x16] = uVar15;
                        uVar12 = uVar13 + 4 +
                                 (ulonglong)((uVar15 & 0x7ff) * 2) +
                                 uVar26 + (uVar23 >> 0xb & 7) * 2;
                        if (uVar12 < uVar26 + uVar13) {
                          *(undefined8 *)(puVar19 + -8) = 0x100764;
                          func_0x(uVar26 + uVar13,0x19);
                          uVar15 = psVar17[0x16];
                          uVar26 = (ulonglong)(ushort)psVar17[0x15];
                          uVar13 = (ulonglong)*(uint *)(psVar17 + 4);
                        }
                        if (uVar16 - uVar29 <
                            (((uVar15 & 0x7ff) * 2 - (int)uVar26) - (int)uVar13) + (int)uVar12) {
                          lVar10 = *(longlong *)(psVar17 + 4);
                          *(undefined8 *)(puVar19 + -8) = 0x10079c;
                          func_0x(uVar26 + lVar10,0x19);
                          uVar15 = psVar17[0x16];
                        }
                        if ((uVar15 & 0x3800) != 0) {
                          puVar31 = (ushort *)
                                    (*(longlong *)(psVar17 + 4) +
                                    (ulonglong)(ushort)psVar17[0x15] + 4);
                          iVar7 = 0;
                          if ((uVar15 & 0x3800) != 0) {
                            do {
                              if ((uVar15 & 0x7ff) < (*puVar31 & 0x7ff)) {
                                uVar23 = psVar17[0x15];
                                lVar10 = *(longlong *)(psVar17 + 4);
                                *(undefined8 *)(puVar19 + -8) = 0x1007f7;
                                func_0x((ulonglong)uVar23 + lVar10,0x1a);
                                uVar15 = psVar17[0x16];
                              }
                              iVar7 = iVar7 + 1;
                              puVar31 = puVar31 + 1;
                            } while (iVar7 < (int)(uVar15 >> 0xb & 7));
                          }
                        }
                        goto LAB_;
                      }
                      if (*(ushort *)(pbVar25 + uVar12) < 0x400) goto LAB_;
                      *puVar1 = *puVar1 | 1;
                      uVar23 = psVar17[0xe] - 1;
                      psVar17[0xe] = uVar23;
                      if (uVar23 == 0) goto LAB_;
                      uVar13 = (ulonglong)uVar23;
                    } while ((short)puVar30[(ulonglong)(uVar23 - 1) + 1] < 0);
                    uVar13 = (ulonglong)*(uint *)(psVar17 + 2);
                  }
                  else {
LAB_:
                    pbVar25 = *(byte **)(psVar17 + 4);
                    uVar13 = (ulonglong)*(uint *)(psVar17 + 2);
                  }
                }
                if ((*pbVar25 & 0x40) == 0) {
                  *(undefined4 *)(psVar17 + 0x13) = 0;
                }
                else {
                  *(int *)(psVar17 + 0x13) = (int)uVar13;
                  *(int *)(psVar17 + 2) = (int)uVar13 + 0xe;
                  *(undefined8 *)(puVar19 + -8) = 0x10083e;
                  uVar9 = func_0x(puVar1);
                  *(undefined8 *)(puVar19 + -8) = 0x10084a;
                  func_0x(uVar9,&puStack_60);
                  *(undefined8 *)(puVar19 + -8) = 0x100853;
                  iVar7 = func_0x(&puStack_60);
                  *(int *)(psVar17 + 2) = *(int *)(psVar17 + 2) + iVar7;
                  uVar13 = (ulonglong)*(uint *)(psVar17 + 2);
                }
                iVar7 = (int)uVar13;
                if ((*(ulonglong *)(psVar17 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar17 + 0xf) < uVar13 + *(longlong *)(psVar17 + 4))) {
                  *(undefined8 *)(puVar19 + -8) = 0x100888;
                  cVar6 = func_0x(0x11c39f0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)(puVar19 + -8) = 0x100891;
                    lVar10 = func_0x();
                    if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar19 + -8) = 0x1008ab;
                      cVar6 = func_0x(0x11c39f0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)(puVar19 + -8) = 0x1008c7;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar19 + 0x20) = 0;
                        *(undefined8 *)(puVar19 + -8) = 0x1008ed;
                        (*_DAT_)(1,0xab33fc,0xbd34e8,0x886);
                      }
                    }
                  }
                  uVar9 = *(undefined8 *)(psVar17 + 4);
                  *(undefined8 *)(puVar19 + -8) = 0x1008fb;
                  func_0x(uVar9,0x12);
                  iVar7 = *(int *)(psVar17 + 2);
                }
                if (0x3f3b < iVar7 - 1U) {
                  *(undefined8 *)(puVar19 + -8) = 0x100914;
                  cVar6 = func_0x(0x11c39f0);
                  if (cVar6 != '\0') {
                    *(undefined8 *)(puVar19 + -8) = 0x10091d;
                    lVar10 = func_0x();
                    if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar19 + -8) = 0x100937;
                      cVar6 = func_0x(0x11c39f0);
                      if (cVar6 == '\0') {
                        *(undefined8 *)(puVar19 + -8) = 0x100953;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar19 + 0x20) = 0;
                        *(undefined8 *)(puVar19 + -8) = 0x100979;
                        (*_DAT_)(1,0xab33fc,0xbd34e8,0x88b);
                      }
                    }
                  }
                  uVar9 = *(undefined8 *)(psVar17 + 4);
                  *(undefined8 *)(puVar19 + -8) = 0x100987;
                  func_0x(uVar9,5);
                }
              }
LAB_:
              sVar24 = -(short)uStack_a0;
              param_2 = psStack_48;
              uVar16 = uStack_80;
              if ((uStack_9c & 0x100000) != 0) {
                bVar5 = **(byte **)(psVar17 + 4);
                if ((bVar5 & 0x10) == 0) {
                  if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                    piVar22 = piStack_98 + 1;
                    iVar7 = *piStack_98;
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(psVar17 + 8) <= (int)uStack_a0) ||
                        (*(ushort *)(*(byte **)(psVar17 + 4) + *(uint *)(psVar17 + 8)) <
                         (ushort)uStack_9c)) goto LAB_;
              }
              piVar22 = *(int **)(psVar17 + 4);
              if ((uint)(ushort)psVar17[0xe] < (uint)(int)sVar24) {
                iVar7 = 0;
              }
              else {
                uVar16 = *(ushort *)
                          ((longlong)piVar22 +
                          (longlong)sVar24 * 2 + (ulonglong)*(uint *)(psVar17 + 10)) & 0x7fff;
                if (sVar24 == 1) {
                  uVar21 = *(uint *)(psVar17 + 0xc);
LAB_:
                  if ((uVar16 < uVar21) || (*(uint *)(psVar17 + 2) < uVar16)) goto LAB_;
                }
                else {
                  uVar21 = *(ushort *)
                            ((longlong)piVar22 +
                            (longlong)sVar24 * 2 + ((ulonglong)*(uint *)(psVar17 + 10) - 2)) &
                           0x7fff;
                  if (*(uint *)(psVar17 + 0xc) <= uVar21) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar19 + -8) = 0x100a3b;
                  func_0x(piVar22,7);
                  piVar22 = *(int **)(psVar17 + 4);
                }
                piVar22 = (int *)((longlong)piVar22 + (ulonglong)uVar21);
                param_2 = psStack_48;
                iVar7 = uVar16 - uVar21;
                uVar16 = uStack_80;
              }
            }
            else if ((uStack_9c & 0x80000) == 0) {
              if (uVar23 != 0) {
                bVar5 = **(byte **)(psVar17 + 4);
                if ((bVar5 & 0x10) == 0) {
                  if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                    iVar7 = *piStack_98;
                    piVar22 = piStack_98 + 1;
                    if (iVar7 != 0x1f9e) {
                      *(undefined8 *)(puVar19 + 0x20) = 0;
                      *(undefined8 *)(puVar19 + -8) = 0x1002b6;
                      (*_DAT_)(1,0xc61840,0xc601a8,0x381);
                      uVar16 = uStack_80;
                    }
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(psVar17 + 8) <= (int)uStack_a0) ||
                        (*(ushort *)(*(byte **)(psVar17 + 4) + *(uint *)(psVar17 + 8)) <
                         (ushort)uStack_9c)) goto LAB_;
              }
              piVar22 = (int *)((longlong)(int)uStack_a0 + *(longlong *)(psVar17 + 4));
              aiStack_a8[0] = 0x1f9e;
              iVar7 = aiStack_a8[0];
            }
            else {
              piVar22 = (int *)0x838090;
              aiStack_a8[0] = 1;
              iVar7 = aiStack_a8[0];
              if ((*(byte *)((longlong)(int)uStack_a0 + *(longlong *)(psVar17 + 4)) &
                  (byte)(1 << (uStack_9c._2_1_ & 7))) == 0) {
                piVar22 = (int *)0x838091;
              }
            }
          }
        }
        else {
          uStack_7c = 0;
          *(uint **)(puVar19 + 0x20) = &uStack_7c;
          *(undefined8 *)(puVar19 + -8) = 0x100ab4;
          piVar22 = (int *)func_0x(puVar1,&uStack_a0);
          iVar7 = aiStack_a8[0];
          if ((((*param_2 != 0) && (plVar2 = *(longlong **)(param_2 + 8), plVar2 != (longlong *)0x0)
               ) && (*plVar2 != 0)) && (((uStack_9c & 0x80000) == 0 && ((uStack_7c & 1) == 0)))) {
            if ((piVar22 == (int *)0x0) || (piVar22 == (int *)0x838090)) {
              piVar22 = (int *)0x0;
              aiStack_a8[0] = 0;
              iVar7 = aiStack_a8[0];
            }
            else {
              *(uint *)(puVar19 + 0x38) = uStack_7c;
              *(int **)(puVar19 + 0x30) = aiStack_a8;
              *(undefined4 *)(puVar19 + 0x28) = uVar27;
              *(longlong *)(puVar19 + 0x20) = lVar18;
              *(undefined8 *)(puVar19 + -8) = 0x100b12;
              piVar22 = (int *)func_0x(plVar2,&uStack_a0,piVar22,iVar7);
              iVar7 = aiStack_a8[0];
            }
          }
        }
LAB_:
        aiStack_a8[0] = iVar7;
        lVar10 = lStack_40;
        uVar3 = uStack_50;
        uVar9 = uStack_58;
        *(uint **)(puVar19 + 0x40) = auStack_90;
        *(undefined8 **)(puVar19 + 0x38) = param_5;
        *(int *)(puVar19 + 0x30) = aiStack_a8[0];
        *(int **)(puVar19 + 0x28) = piVar22;
        *(uint **)(puVar19 + 0x20) = &uStack_a0;
        *(undefined8 *)(puVar19 + -8) = 0x100b5a;
        func_0x(lVar10,param_2,uVar3,uVar9);
        if ((*param_6 == 0) && (auStack_90[0] == 0)) {
          iVar7 = 0;
        }
        else {
          iVar7 = 1;
        }
        *param_6 = iVar7;
      }
      uVar28 = uVar28 + 1;
      lVar10 = lStack_70;
      lVar18 = lStack_68;
    } while ((int)uVar28 < (int)uVar16);
  }
  uVar28 = 0;
  *(undefined8 *)(puVar19 + -8) = 0x100b98;
  iVar7 = func_0x(param_2);
  lStack_68 = (longlong)iVar7;
  if (0 < lStack_68) {
    puStack_88 = (ushort *)0x0;
    auStack_90[0] = 0;
    do {
      if (*(int *)(psVar17 + 2) == 0) {
        pbVar25 = *(byte **)(psVar17 + 4);
        uVar16 = *(uint *)(psVar17 + 8);
        uVar13 = (ulonglong)uVar16;
        *puVar1 = 0;
        *(uint *)(psVar17 + 10) = uVar16;
        bVar5 = *pbVar25;
        if ((bVar5 & 0x10) != 0) {
          uVar16 = uVar16 + 2 + (*(ushort *)(pbVar25 + uVar13) + 7 >> 3);
          uVar13 = (ulonglong)uVar16;
          *(uint *)(psVar17 + 10) = uVar16;
          bVar5 = *pbVar25;
        }
        if ((bVar5 & 0x20) == 0) {
          *(int *)(psVar17 + 2) = (int)uVar13;
          psVar17[0xe] = 0;
          *(int *)(psVar17 + 0xc) = (int)uVar13;
        }
        else {
          puVar31 = (ushort *)(pbVar25 + uVar13);
          uVar23 = *puVar31;
          psVar17[0xe] = uVar23;
          puStack_60 = puVar31;
          if (uVar23 == 0) {
            *(undefined8 *)(puVar19 + -8) = 0x100c28;
            cVar6 = func_0x(0x11c39f0);
            if (cVar6 != '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x100c31;
              lVar10 = func_0x();
              if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                *(undefined8 *)(puVar19 + -8) = 0x100c4b;
                cVar6 = func_0x(0x11c39f0);
                if (cVar6 == '\0') {
                  *(undefined8 *)(puVar19 + -8) = 0x100c67;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar19 + 0x20) = 0;
                  *(undefined8 *)(puVar19 + -8) = 0x100c8d;
                  (*_DAT_)(1,0xab33fc,0xbd34e8,0x80f);
                }
              }
            }
            uVar9 = *(undefined8 *)(psVar17 + 4);
            *(undefined8 *)(puVar19 + -8) = 0x100c9b;
            func_0x(uVar9,3);
            uVar13 = (ulonglong)*(uint *)(psVar17 + 10);
            uVar23 = psVar17[0xe];
          }
          uVar16 = (int)uVar13 + (uVar23 + 1) * 2;
          *(uint *)(psVar17 + 0xc) = uVar16;
          if (0x1f9e < uVar16) {
            *(undefined8 *)(puVar19 + -8) = 0x100ccb;
            cVar6 = func_0x(0x11c39f0);
            if (cVar6 != '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x100cd4;
              lVar10 = func_0x();
              if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                *(undefined8 *)(puVar19 + -8) = 0x100cee;
                cVar6 = func_0x(0x11c39f0);
                if (cVar6 == '\0') {
                  *(undefined8 *)(puVar19 + -8) = 0x100d0a;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar19 + 0x20) = 0;
                  *(undefined8 *)(puVar19 + -8) = 0x100d30;
                  (*_DAT_)(1,0xab33fc,0xbd34e8,0x816);
                }
              }
            }
            uVar9 = *(undefined8 *)(psVar17 + 4);
            *(undefined8 *)(puVar19 + -8) = 0x100d3e;
            func_0x(uVar9,4);
            uVar23 = psVar17[0xe];
            uVar16 = *(uint *)(psVar17 + 0xc);
          }
          uVar13 = (ulonglong)uVar23;
          uVar23 = puVar31[uVar13];
          *(uint *)(psVar17 + 2) = uVar23 & 0x7fff;
          if ((uVar23 & 0x7fff) < uVar16) {
            *(undefined8 *)(puVar19 + -8) = 0x100d6e;
            cVar6 = func_0x(0x11c39f0);
            if (cVar6 != '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x100d77;
              lVar10 = func_0x();
              if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                *(undefined8 *)(puVar19 + -8) = 0x100d91;
                cVar6 = func_0x(0x11c39f0);
                if (cVar6 == '\0') {
                  *(undefined8 *)(puVar19 + -8) = 0x100dad;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar19 + 0x20) = 0;
                  *(undefined8 *)(puVar19 + -8) = 0x100dd3;
                  (*_DAT_)(1,0xab33fc,0xbd34e8,0x81d);
                }
              }
            }
            uVar9 = *(undefined8 *)(psVar17 + 4);
            *(undefined8 *)(puVar19 + -8) = 0x100de1;
            func_0x(uVar9,4);
            uVar16 = *(uint *)(psVar17 + 0xc);
            uVar13 = (ulonglong)(ushort)psVar17[0xe];
          }
          uVar12 = 0;
          puVar30 = puVar31;
          if ((short)uVar13 != 0) {
            do {
              puVar31 = puVar31 + 1;
              uVar21 = *puVar31 & 0x7fff;
              if ((uVar21 < uVar16) || (*(uint *)(psVar17 + 2) < uVar21)) {
                *(undefined8 *)(puVar19 + -8) = 0x100e1f;
                cVar6 = func_0x(0x11c39f0);
                if (cVar6 != '\0') {
                  *(undefined8 *)(puVar19 + -8) = 0x100e28;
                  lVar10 = func_0x();
                  if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar19 + -8) = 0x100e42;
                    cVar6 = func_0x(0x11c39f0);
                    if (cVar6 == '\0') {
                      *(undefined8 *)(puVar19 + -8) = 0x100e5e;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar19 + 0x20) = 0;
                      *(undefined8 *)(puVar19 + -8) = 0x100e84;
                      (*_DAT_)(1,0xab33fc,0xbd34e8,0x82a);
                    }
                  }
                }
                uVar9 = *(undefined8 *)(psVar17 + 4);
                *(undefined8 *)(puVar19 + -8) = 0x100e92;
                func_0x(uVar9,4);
              }
              uVar13 = (ulonglong)(ushort)psVar17[0xe];
              uVar29 = (int)uVar12 + 1;
              uVar12 = (ulonglong)uVar29;
              puVar30 = puStack_60;
              uVar16 = uVar21;
            } while ((int)uVar29 < (int)(uint)(ushort)psVar17[0xe]);
          }
          if ((short)puVar30[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
            pbVar25 = *(byte **)(psVar17 + 4);
            do {
              uVar16 = *(ushort *)(pbVar25 + uVar13 * 2 + (ulonglong)*(uint *)(psVar17 + 10)) &
                       0x7fff;
              if ((int)uVar13 == 1) {
                uVar21 = *(uint *)(psVar17 + 0xc);
                uVar29 = uVar21;
LAB_:
                if ((uVar16 < uVar21) || (*(uint *)(psVar17 + 2) < uVar16)) goto LAB_;
              }
              else {
                uVar29 = *(uint *)(psVar17 + 0xc);
                uVar21 = *(ushort *)
                          (pbVar25 + uVar13 * 2 + ((ulonglong)*(uint *)(psVar17 + 10) - 2)) & 0x7fff
                ;
                if (uVar29 <= uVar21) goto LAB_;
LAB_:
                *(undefined8 *)(puVar19 + -8) = 0x100f18;
                func_0x(pbVar25,7);
                uVar29 = *(uint *)(psVar17 + 0xc);
              }
              if ((uVar21 < uVar29) || (*(uint *)(psVar17 + 2) < uVar21)) goto LAB_;
              pbVar25 = *(byte **)(psVar17 + 4);
              if (*(ushort *)(pbVar25 + uVar21) == 5) {
                *puVar1 = *puVar1 | 2;
                psVar17[0xe] = psVar17[0xe] + -1;
                uVar12 = *(ulonglong *)(psVar17 + 4);
                uVar26 = (ulonglong)(uVar21 & 0xffff);
                uVar23 = psVar17[0x16] & 0xc7ff;
                uVar13 = uVar26 + uVar12;
                psVar17[0x15] = (short)uVar21;
                if ((*(ushort *)(uVar13 + 2) >> 0xe & 1) != 0) {
                  uVar23 = *(ushort *)(uVar13 + 2) & 0x3800 | uVar23;
                }
                psVar17[0x16] = uVar23;
                uVar15 = (uVar23 ^ *(ushort *)(uVar13 + 2)) & 0x7ff ^ uVar23;
                psVar17[0x16] = uVar15;
                uVar32 = (ulonglong)((uVar15 & 0x7ff) * 2) + 4 + uVar12 + (uVar23 >> 0xb & 7) * 2 +
                         uVar26;
                if (uVar32 < uVar13) {
                  *(undefined8 *)(puVar19 + -8) = 0x101025;
                  func_0x(uVar13,0x19);
                  uVar15 = psVar17[0x16];
                  uVar26 = (ulonglong)(ushort)psVar17[0x15];
                  uVar12 = (ulonglong)*(uint *)(psVar17 + 4);
                }
                if (uVar16 - uVar21 <
                    (((uVar15 & 0x7ff) * 2 - (int)uVar26) - (int)uVar12) + (int)uVar32) {
                  lVar10 = *(longlong *)(psVar17 + 4);
                  *(undefined8 *)(puVar19 + -8) = 0x101060;
                  func_0x(uVar26 + lVar10,0x19);
                  uVar15 = psVar17[0x16];
                }
                if ((uVar15 & 0x3800) != 0) {
                  puVar31 = (ushort *)
                            (*(longlong *)(psVar17 + 4) + (ulonglong)(ushort)psVar17[0x15] + 4);
                  iVar7 = 0;
                  if ((uVar15 & 0x3800) != 0) {
                    do {
                      if ((uVar15 & 0x7ff) < (*puVar31 & 0x7ff)) {
                        uVar23 = psVar17[0x15];
                        lVar10 = *(longlong *)(psVar17 + 4);
                        *(undefined8 *)(puVar19 + -8) = 0x1010c6;
                        func_0x((ulonglong)uVar23 + lVar10,0x1a);
                        uVar15 = psVar17[0x16];
                      }
                      iVar7 = iVar7 + 1;
                      puVar31 = puVar31 + 1;
                    } while (iVar7 < (int)(uVar15 >> 0xb & 7));
                  }
                }
                goto LAB_;
              }
              if (*(ushort *)(pbVar25 + uVar21) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar23 = psVar17[0xe] - 1;
              psVar17[0xe] = uVar23;
              if (uVar23 == 0) goto LAB_;
              uVar13 = (ulonglong)uVar23;
            } while ((short)puVar30[(ulonglong)(uVar23 - 1) + 1] < 0);
            uVar13 = (ulonglong)*(uint *)(psVar17 + 2);
          }
          else {
LAB_:
            pbVar25 = *(byte **)(psVar17 + 4);
            uVar13 = (ulonglong)*(uint *)(psVar17 + 2);
          }
        }
        if ((*pbVar25 & 0x40) == 0) {
          *(undefined4 *)(psVar17 + 0x13) = 0;
        }
        else {
          *(int *)(psVar17 + 0x13) = (int)uVar13;
          *(int *)(psVar17 + 2) = (int)uVar13 + 0xe;
          *(undefined8 *)(puVar19 + -8) = 0x101112;
          puVar11 = (undefined8 *)func_0x(puVar1);
          uStack_38 = *puVar11;
          *(undefined8 *)(puVar19 + -8) = 0x101122;
          iVar7 = func_0x(&uStack_38);
          *(int *)(psVar17 + 2) = *(int *)(psVar17 + 2) + iVar7;
          uVar13 = (ulonglong)*(uint *)(psVar17 + 2);
        }
        iVar7 = (int)uVar13;
        if ((*(ulonglong *)(psVar17 + 0xf) != 0) &&
           (*(ulonglong *)(psVar17 + 0xf) < uVar13 + *(longlong *)(psVar17 + 4))) {
          *(undefined8 *)(puVar19 + -8) = 0x101157;
          cVar6 = func_0x(0x11c39f0);
          if (cVar6 != '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x101160;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              *(undefined8 *)(puVar19 + -8) = 0x10117a;
              cVar6 = func_0x(0x11c39f0);
              if (cVar6 == '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x101196;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar19 + 0x20) = 0;
                *(undefined8 *)(puVar19 + -8) = 0x1011bc;
                (*_DAT_)(1,0xab33fc,0xbd34e8,0x886);
              }
            }
          }
          uVar9 = *(undefined8 *)(psVar17 + 4);
          *(undefined8 *)(puVar19 + -8) = 0x1011ca;
          func_0x(uVar9,0x12);
          iVar7 = *(int *)(psVar17 + 2);
        }
        if (0x3f3b < iVar7 - 1U) {
          *(undefined8 *)(puVar19 + -8) = 0x1011e3;
          cVar6 = func_0x(0x11c39f0);
          if (cVar6 != '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x1011ec;
            lVar10 = func_0x();
            if ((lVar10 != 0) && (*(char *)(lVar10 + 0x499) != '\0')) {
              *(undefined8 *)(puVar19 + -8) = 0x101206;
              cVar6 = func_0x(0x11c39f0);
              if (cVar6 == '\0') {
                *(undefined8 *)(puVar19 + -8) = 0x101222;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar19 + 0x20) = 0;
                *(undefined8 *)(puVar19 + -8) = 0x101248;
                (*_DAT_)(1,0xab33fc,0xbd34e8,0x88b);
              }
            }
          }
          uVar9 = *(undefined8 *)(psVar17 + 4);
          *(undefined8 *)(puVar19 + -8) = 0x101256;
          func_0x(uVar9,5);
        }
      }
LAB_:
      *(undefined8 *)(puVar19 + -8) = 0x10125e;
      iVar7 = func_0x();
      if (iVar7 == 0) {
        *(undefined8 *)(puVar19 + -8) = 0x10139d;
        iVar7 = func_0x(puVar1);
        uVar13 = 0;
        if (iVar7 == 0) {
          *(undefined8 *)(puVar19 + 0x20) = 0;
          *(undefined8 *)(puVar19 + -8) = 0x1013c5;
          (*_DAT_)(1,0xc6f118,0xc601a8,0xd7a);
          uVar13 = 0;
        }
      }
      else {
        uVar23 = psVar17[0x16];
        uVar13 = 0;
        if (uVar28 < (uVar23 & 0x7ff)) {
          uVar12 = (ulonglong)(ushort)psVar17[0x15];
          lVar18 = *(longlong *)(psVar17 + 4);
          uVar15 = 0;
          lVar10 = lVar18 + uVar12;
          if ((uVar23 & 0x3800) == 0) {
            uVar14 = *(ushort *)(lVar10 + 2);
LAB_:
            uVar15 = uVar14 >> 0xb & 7;
          }
          else if ((uVar23 >> 0xb & 7) != 0) {
            do {
              if (((uVar13 == 0) || ((*(ushort *)(lVar10 + 2 + uVar13 * 2) & 0x7ff) <= uVar28)) &&
                 (uVar14 = *(ushort *)(lVar10 + 4 + uVar13 * 2),
                 (int)uVar28 <= (int)((uVar14 & 0x7ff) - 1))) goto LAB_;
              uVar13 = uVar13 + 1;
            } while ((longlong)uVar13 < (longlong)(ulonglong)(uVar23 >> 0xb & 7));
          }
          uVar21 = uVar23 >> 0xb & 7;
          uVar13 = (ulonglong)(uVar21 * 2);
          iStack_78 = (uint)*(ushort *)(uVar13 + (longlong)(puStack_88 + 1) * 2 + lVar18 + uVar12) +
                      (uint)uVar15 * 0x10000;
          uVar16 = (uVar23 & 0x7ff) * 2;
          lVar18 = uVar16 + uVar13 + lVar18 + uVar12;
          if (puStack_88 == (ushort *)0x0) {
            uVar16 = (uVar16 + uVar21) * 2 + 4;
          }
          else {
            uVar16 = *(ushort *)(lVar18 + 2 + (longlong)puStack_88 * 2) & 0x7fff;
          }
          aiStack_a8[0] = (*(ushort *)(lVar18 + 4 + (longlong)puStack_88 * 2) & 0x7fff) - uVar16;
          auStack_90[0] = (uint)(*(ushort *)(lVar18 + 4 + (longlong)puStack_88 * 2) >> 0xf);
          uVar13 = (ulonglong)uVar16 + lVar10;
        }
        else {
          *(undefined8 *)(puVar19 + 0x20) = 0;
          *(undefined8 *)(puVar19 + -8) = 0x101393;
          (*_DAT_)(1,0xc6f0e8,0xc6f0b0,0x41a);
        }
      }
      iVar7 = iStack_78;
      iVar20 = 0;
      if (auStack_90[0] != 0) {
        iStack_74 = 0;
        uVar9 = **(undefined8 **)(*(longlong *)(lStack_70 + 8) + 0x160);
        *(undefined8 *)(puVar19 + -8) = 0x1013e9;
        puVar8 = (uint *)func_0x(uVar9,iVar7);
        lVar10 = lStack_40;
        psVar4 = psStack_48;
        uVar3 = uStack_50;
        uVar9 = uStack_58;
        uVar16 = *puVar8;
        uVar21 = puVar8[1];
        piVar22 = *(int **)(puVar8 + 2);
        *(int **)(puVar19 + 0x40) = &iStack_74;
        *(undefined8 **)(puVar19 + 0x38) = param_5;
        *(int *)(puVar19 + 0x30) = aiStack_a8[0];
        *(ulonglong *)(puVar19 + 0x28) = uVar13;
        *(uint **)(puVar19 + 0x20) = &uStack_a0;
        uStack_a0 = uVar16;
        uStack_9c = uVar21;
        piStack_98 = piVar22;
        *(undefined8 *)(puVar19 + -8) = 0x10142f;
        func_0x(lVar10,psVar4,uVar3,uVar9);
        if ((*param_6 != 0) || (iStack_74 != 0)) {
          iVar20 = 1;
        }
        *param_6 = iVar20;
      }
      uVar28 = uVar28 + 1;
      puStack_88 = (ushort *)((longlong)puStack_88 + 1);
    } while ((longlong)puStack_88 < lStack_68);
  }
  uVar13 = uStack_30 ^ (ulonglong)aiStack_a8;
  *(undefined8 *)(puVar19 + -8) = 0x10146c;
  func_0x(uVar13);
  return;
}

