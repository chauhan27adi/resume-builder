
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x01f1ef53) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  short *psVar2;
  ushort uVar3;
  undefined2 uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  code *pcVar8;
  longlong lVar9;
  undefined8 uVar10;
  short sVar11;
  int iVar12;
  int iVar13;
  longlong lVar14;
  longlong lVar15;
  longlong *plVar16;
  undefined8 unaff_RBX;
  int *piVar17;
  undefined uVar18;
  bool bVar19;
  short sStackX_18;
  undefined auStackX_1a [2];
  uint uStackX_1c;
  longlong lStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  psVar2 = (short *)((longlong)&sStackX_18 + lVar14);
  *(undefined8 *)(&stack0x00002240 + lVar14) = unaff_RBX;
  *(ulonglong *)(&stack0x000021e8 + lVar14) = _DAT_ ^ (ulonglong)psVar2;
  *(undefined8 *)(&stack0x00000140 + lVar14) = *(undefined8 *)(&stack0x00002258 + lVar14);
  *(longlong *)(&stack0x00000060 + lVar14) = param_1;
  *psVar2 = -1;
  *(undefined8 *)((longlong)&lStackX_20 + lVar14) = 0;
  *(undefined4 *)((longlong)&sStackX_18 + lVar14 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar14) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100087;
  func_0x(&stack0x00000248 + lVar14,0,0x1f9e);
  *(undefined4 *)(&stack0x000000ac + lVar14) = 0;
  *(undefined8 *)(&stack0x000000c0 + lVar14) = 0;
  *(undefined4 *)(&stack0x000000c8 + lVar14) = 0;
  uVar18 = 0;
  if ((*(char *)(param_1 + 0x1bc) != '\0') && (1 < *(int *)(param_1 + 0x30))) {
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100432;
    func_0x(*(ulonglong *)(&stack0x000021e8 + lVar14) ^ (ulonglong)psVar2);
    return;
  }
  if (param_3 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar1 = (undefined8 *)(param_1 + 0x1c8);
  if ((*(int *)(param_1 + 0x1f0) == *(int *)(param_3 + 1)) &&
     (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x1dc) * 0x10000)) {
    pcVar8 = *(code **)*puVar1;
    *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1000f2;
    sVar11 = (*pcVar8)(puVar1);
    if (*(short *)((longlong)param_3 + 0xc) == sVar11) {
      if (param_3[0x15] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar3 = *(ushort *)((longlong)param_3 + 0x62);
      if ((*(ushort *)(param_3 + 7) & 0x400) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(longlong *)(&stack0x000000a0 + lVar14) = param_3[0xe];
      *(longlong **)(&stack0x00000098 + lVar14) = param_3;
      *(uint *)(&stack0x000000a8 + lVar14) = (uint)uVar3;
      *(undefined8 *)(&stack0x000000b0 + lVar14) = param_4;
      *(undefined8 *)(&stack0x000000b8 + lVar14) = 0;
      *(undefined8 *)(&stack0x000000f0 + lVar14) = 0;
      if (puVar1 != (undefined8 *)0x0) {
        lVar15 = **(longlong **)(*(longlong *)(param_1 + 0x1d0) + 0x160);
        *(undefined8 *)(&stack0x000000c0 + lVar14) = *(undefined8 *)(lVar15 + 0xa8);
        *(undefined4 *)(&stack0x000000c8 + lVar14) = *(undefined4 *)(lVar15 + 0xb0);
      }
      *(uint *)(&stack0x000000ac + lVar14) = *(uint *)(&stack0x000000ac + lVar14) | 0x10;
      uVar5 = *(uint *)(param_1 + 0x40);
      if (*(char *)(param_1 + 0x1bc) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar15 = param_1 + 0x1c8;
      *(undefined4 *)(&stack0x0000005c + lVar14) = 0x1f7c;
      lVar9 = *(longlong *)(param_1 + 0x1d0);
      *(longlong *)(&stack0x00000118 + lVar14) = lVar15;
      if (*(int *)(lVar9 + 0x100) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)(param_3 + 7) & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *psVar2 = 0;
      *(undefined8 *)(&stack0x00000078 + lVar14) = 0;
      plVar16 = (longlong *)0x0;
      if (((&stack0x000000ac)[lVar14] & 0x10) != 0) {
        plVar16 = param_3;
      }
      iVar13 = *(int *)(plVar16 + 2);
      bVar19 = (uVar5 & 4) == 0;
      *(int *)(&stack0x0000006c + lVar14) = -iVar13;
      iVar6 = *(int *)((longlong)plVar16 + 0x14);
      if (bVar19) {
        uVar18 = 6;
      }
      iVar12 = 4;
      if (bVar19) {
        iVar12 = 1;
      }
      (&stack0xfffffffffffffff0)[lVar14] = uVar18;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar14) = *(undefined4 *)(plVar16 + 3);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100247;
      func_0x((longlong)&sStackX_18 + lVar14 + 2,&stack0x00000248 + lVar14,0x1f9e,
                      iVar6 - iVar12);
      if (-iVar13 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      piVar17 = *(int **)(&stack0x000000a0 + lVar14);
      *(undefined4 *)(&stack0x00000080 + lVar14) = 0;
      *(int **)(&stack0x00000050 + lVar14) = piVar17;
      uVar3 = *(ushort *)(*(longlong *)(&stack0x00000098 + lVar14) + 0x62);
      *(uint *)(&stack0x000000fc + lVar14) = (uint)uVar3;
      *(undefined8 *)(&stack0x00000088 + lVar14) = 0;
      iVar13 = 0;
      if (uVar3 != 0) {
        do {
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10029e;
          func_0x(&stack0x00000098 + lVar14,piVar17,&stack0x00000058 + lVar14);
          if ((&stack0x00000058)[lVar14] == '\x03') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(short *)(piVar17 + 1) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1002bd;
            func_0x((longlong)&sStackX_18 + lVar14 + 2,piVar17);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1002d0;
          func_0x(&stack0x00000098 + lVar14,piVar17,&stack0x00000088 + lVar14);
          if (*(char *)(piVar17 + 0x10) != '\x01') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (((uint)piVar17[0x10] >> 8 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          iVar13 = *piVar17;
          uVar4 = *(undefined2 *)(piVar17 + 0xf);
          *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100308;
          func_0x((longlong)iVar13 + *(longlong *)((longlong)&lStackX_20 + lVar14),
                          *(undefined8 *)(&stack0x00000088 + lVar14),uVar4);
          iVar13 = *(int *)(&stack0x00000080 + lVar14);
          piVar17 = piVar17 + 0x14;
          *(int **)(&stack0x00000050 + lVar14) = piVar17;
          *(uint *)(&stack0x00000080 + lVar14) = iVar13 + 1U;
        } while (iVar13 + 1U < *(uint *)(&stack0x000000fc + lVar14));
        iVar13 = *(int *)(&stack0x0000006c + lVar14);
        lVar15 = *(longlong *)(&stack0x00000118 + lVar14);
      }
      if (iVar13 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x10034c;
      iVar13 = func_0x(lVar15);
      if (iVar13 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar5 = *(uint *)((longlong)&sStackX_18 + lVar14 + 4);
      if (*psVar2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (uVar5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (uVar5 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar10 = *(undefined8 *)(*(longlong *)(&stack0x00000060 + lVar14) + 0x18);
      *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x100392;
      lVar15 = func_0x(uVar10,uVar5);
      *(longlong *)(&stack0x00000050 + lVar14) = lVar15;
      if (lVar15 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*psVar2 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar7 = *(uint *)((longlong)&sStackX_18 + lVar14 + 4);
      if (uVar7 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (uVar7 < 9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (uVar7 != 0) {
        if ((*(longlong *)((longlong)&lStackX_20 + lVar14) == 0) || (uVar5 < uVar7)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar14) = 0x1003f6;
        func_0x(lVar15,*(longlong *)((longlong)&lStackX_20 + lVar14),uVar7);
      }
      if (*(longlong *)(&stack0x00000140 + lVar14) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      goto LAB_;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

