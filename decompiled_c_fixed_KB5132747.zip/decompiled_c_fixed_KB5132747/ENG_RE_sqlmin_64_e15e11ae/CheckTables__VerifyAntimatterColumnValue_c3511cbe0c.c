
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,longlong param_2)

{
  ushort *puVar1;
  undefined4 uVar2;
  longlong *plVar3;
  ushort *puVar4;
  byte bVar5;
  char cVar6;
  ushort uVar7;
  ushort uVar8;
  int iVar9;
  longlong lVar10;
  uint *puVar11;
  undefined8 uVar12;
  longlong lVar13;
  uint *puVar14;
  uint uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  uint uVar18;
  uint *puVar19;
  ulonglong uVar20;
  short sVar21;
  byte *pbVar22;
  uint uVar23;
  ushort *puVar24;
  undefined auStack_148 [32];
  uint *puStack_128;
  undefined8 uStack_120;
  uint *puStack_118;
  uint uStack_110;
  undefined4 uStack_108;
  undefined4 uStack_100;
  int iStack_f8;
  undefined4 uStack_f0;
  uint *puStack_e8;
  undefined4 uStack_e0;
  undefined8 uStack_d8;
  undefined4 uStack_d0;
  undefined8 uStack_c8;
  undefined2 uStack_c0;
  undefined4 uStack_b8;
  undefined8 uStack_b0;
  undefined4 uStack_a8;
  undefined2 uStack_a0;
  uint uStack_98;
  uint uStack_94;
  undefined4 uStack_90;
  undefined8 uStack_8c;
  undefined4 uStack_84;
  undefined auStack_80 [4];
  uint uStack_7c;
  undefined auStack_78 [8];
  longlong lStack_70;
  undefined8 uStack_68;
  uint auStack_60 [8];
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_148;
  puVar14 = (uint *)0x0;
  uStack_98 = 0;
  lVar13 = *(longlong *)(*(longlong *)(param_2 + 0x98) + 0x80);
  lStack_70 = param_2;
  uStack_68 = param_1;
  if (lVar13 == 0) {
    lVar10 = func_0x();
    if (lVar10 == 0) {
      puVar11 = (uint *)0x4;
    }
    else {
      lVar10 = func_0x();
      puVar11 = (uint *)(lVar10 + 0x10);
    }
    *puVar11 = *puVar11 | 2;
    (*_DAT_)(0x59,0x43,0x10,0xd6);
  }
  lVar13 = *(longlong *)(lVar13 + 8);
  if ((((*(int *)(lVar13 + 0xe8) == 0) || ((*(byte *)(lVar13 + 0x108) & 0x40) != 0)) ||
      ((*(byte *)(lVar13 + 0x41) & 8) == 0)) || (*(longlong **)(lVar13 + 0x160) == (longlong *)0x0))
  goto LAB_;
  lVar13 = **(longlong **)(lVar13 + 0x160);
  uVar15 = *(uint *)(lVar13 + 100);
  if (uVar15 == 0xffffffff) goto LAB_;
  puVar11 = *(uint **)(lVar13 + 8);
  if (uVar15 < *puVar11) {
    uVar17 = (ulonglong)uVar15 / (ulonglong)puVar11[9];
    uVar16 = (ulonglong)uVar15 % (ulonglong)puVar11[9];
    lVar13 = *(longlong *)(puVar11 + 4);
  }
  else {
    uVar17 = (ulonglong)(uVar15 - *puVar11) / (ulonglong)puVar11[0x11];
    uVar16 = (ulonglong)(uVar15 - *puVar11) % (ulonglong)puVar11[0x11];
    lVar13 = *(longlong *)(puVar11 + 0xc);
  }
  puVar11 = (uint *)(uVar16 * 0x1c0 + *(longlong *)(lVar13 + uVar17 * 8));
  if (puVar11 == (uint *)0x0) goto LAB_;
  puVar1 = (ushort *)(param_2 + 0xa2);
  bVar5 = *(byte *)(puVar11 + 8);
  if (*(short *)(param_2 + 0xa0) == 0) {
    uVar18 = *puVar11;
    if ((uVar18 & 0xc0000000) == 0x80000000) {
      iVar9 = func_0x(puVar1);
      if (iVar9 != 0) {
        puVar19 = (uint *)func_0x(param_2 + 0xca,puVar11,&uStack_98,auStack_80);
        uVar15 = uStack_98;
        goto LAB_;
      }
LAB_:
      puVar19 = (uint *)0x0;
      uVar15 = uStack_98;
    }
    else {
      uVar7 = 1;
      if (((bVar5 & 2) != 0) || ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0)) {
        pbVar22 = *(byte **)(param_2 + 0xa8);
        if ((*pbVar22 & 0x10) == 0) {
          uVar7 = 1;
          uVar8 = 0;
          if ((1 << (*pbVar22 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
          if ((bVar5 & 2) != 0) goto LAB_;
        }
        else {
          uVar15 = *(uint *)(param_2 + 0xb0);
          if ((int)uVar15 <= (int)uVar18) {
LAB_:
            uVar8 = ~(*(ushort *)((longlong)puVar11 + 6) >> 4) & 1;
            uVar7 = 0;
            goto LAB_;
          }
          if ((uint)*(ushort *)(pbVar22 + uVar15) < (uint)*(ushort *)(puVar11 + 1))
          goto LAB_;
          if ((bVar5 & 2) == 0) goto LAB_;
          uVar23 = *(ushort *)(puVar11 + 1) - 1;
          uVar8 = pbVar22[(ulonglong)(uVar23 >> 3) + (ulonglong)uVar15 + 2] >> ((byte)uVar23 & 7) &
                  1;
LAB_:
          if (uVar8 != 0) goto LAB_;
        }
        if ((uVar7 == 0) && ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0)) {
          puVar19 = *(uint **)(puVar11 + 2) + 1;
          uVar15 = **(uint **)(puVar11 + 2);
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar18 < 0) {
        if (*(int *)(param_2 + 0xa4) == 0) {
          pbVar22 = *(byte **)(param_2 + 0xa8);
          uVar15 = *(uint *)(param_2 + 0xb0);
          uVar17 = (ulonglong)uVar15;
          *puVar1 = 0;
          *(uint *)(param_2 + 0xb4) = uVar15;
          bVar5 = *pbVar22;
          if ((bVar5 & 0x10) != 0) {
            uVar15 = uVar15 + 2 + (*(ushort *)(pbVar22 + uVar17) + 7 >> 3);
            uVar17 = (ulonglong)uVar15;
            *(uint *)(param_2 + 0xb4) = uVar15;
            bVar5 = *pbVar22;
          }
          if ((bVar5 & 0x20) == 0) {
            *(int *)(param_2 + 0xa4) = (int)uVar17;
            *(undefined2 *)(param_2 + 0xbc) = 0;
            *(int *)(param_2 + 0xb8) = (int)uVar17;
          }
          else {
            puVar24 = (ushort *)(pbVar22 + uVar17);
            uVar7 = *puVar24;
            *(ushort *)(param_2 + 0xbc) = uVar7;
            if (uVar7 == 0) {
              cVar6 = func_0x(0x149ce30);
              if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
                cVar6 = func_0x(0x149ce30);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  puStack_128 = (uint *)0x0;
                  (*_DAT_)(1,0xd8c83c,0xeac928,0x80f);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),3);
              uVar17 = (ulonglong)*(uint *)(param_2 + 0xb4);
              uVar7 = *(ushort *)(param_2 + 0xbc);
            }
            uVar15 = (int)uVar17 + (uVar7 + 1) * 2;
            *(uint *)(param_2 + 0xb8) = uVar15;
            if (0x1f9e < uVar15) {
              cVar6 = func_0x(0x149ce30);
              if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
                cVar6 = func_0x(0x149ce30);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_128 = (uint *)0x0;
                  (*_DAT_)(1,0xd8c83c,0xeac928,0x816);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
              uVar7 = *(ushort *)(param_2 + 0xbc);
              uVar15 = *(uint *)(param_2 + 0xb8);
            }
            uVar17 = (ulonglong)uVar7;
            uVar7 = puVar24[uVar17];
            *(uint *)(param_2 + 0xa4) = uVar7 & 0x7fff;
            if ((uVar7 & 0x7fff) < uVar15) {
              cVar6 = func_0x(0x149ce30);
              if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
                cVar6 = func_0x(0x149ce30);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_128 = (uint *)0x0;
                  (*_DAT_)(1,0xd8c83c,0xeac928,0x81d);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
              uVar15 = *(uint *)(param_2 + 0xb8);
              uVar17 = (ulonglong)*(ushort *)(param_2 + 0xbc);
            }
            puVar19 = puVar14;
            puVar4 = puVar24;
            if ((short)uVar17 != 0) {
              do {
                uVar18 = puVar4[1] & 0x7fff;
                if ((uVar18 < uVar15) || (*(uint *)(param_2 + 0xa4) < uVar18)) {
                  cVar6 = func_0x(0x149ce30);
                  if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
                    cVar6 = func_0x(0x149ce30);
                    if (cVar6 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      puStack_128 = (uint *)0x0;
                      (*_DAT_)(1,0xd8c83c,0xeac928,0x82a);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 0xa8),4);
                }
                uVar17 = (ulonglong)*(ushort *)(param_2 + 0xbc);
                uVar23 = (int)puVar19 + 1;
                puVar19 = (uint *)(ulonglong)uVar23;
                puVar4 = puVar4 + 1;
                uVar15 = uVar18;
              } while ((int)uVar23 < (int)(uint)*(ushort *)(param_2 + 0xbc));
            }
            if ((short)puVar24[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
              pbVar22 = *(byte **)(param_2 + 0xa8);
              do {
                uVar15 = *(ushort *)(pbVar22 + uVar17 * 2 + (ulonglong)*(uint *)(param_2 + 0xb4)) &
                         0x7fff;
                if ((int)uVar17 == 1) {
                  uVar18 = *(uint *)(param_2 + 0xb8);
                  uVar23 = uVar18;
LAB_:
                  if ((uVar15 < uVar18) || (*(uint *)(param_2 + 0xa4) < uVar15)) goto LAB_;
                }
                else {
                  uVar23 = *(uint *)(param_2 + 0xb8);
                  uVar18 = *(ushort *)
                            (pbVar22 + uVar17 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2)) &
                           0x7fff;
                  if (uVar23 <= uVar18) goto LAB_;
LAB_:
                  func_0x(pbVar22,7);
                  uVar23 = *(uint *)(param_2 + 0xb8);
                }
                if ((uVar18 < uVar23) || (*(uint *)(param_2 + 0xa4) < uVar18)) goto LAB_;
                pbVar22 = *(byte **)(param_2 + 0xa8);
                if (*(ushort *)(pbVar22 + uVar18) == 5) {
                  *puVar1 = *puVar1 | 2;
                  *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
                  uVar7 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
                  uVar16 = (ulonglong)(uVar18 & 0xffff);
                  *(short *)(param_2 + 0xca) = (short)uVar18;
                  uVar17 = *(ulonglong *)(param_2 + 0xa8);
                  if ((*(ushort *)(uVar16 + 2 + uVar17) >> 0xe & 1) != 0) {
                    uVar7 = *(ushort *)(uVar16 + 2 + uVar17) & 0x3800 | uVar7;
                  }
                  *(ushort *)(param_2 + 0xcc) = uVar7;
                  uVar8 = (uVar7 ^ *(ushort *)(uVar16 + 2 + uVar17)) & 0x7ff ^ uVar7;
                  *(ushort *)(param_2 + 0xcc) = uVar8;
                  uVar20 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar17 + (uVar7 >> 0xb & 7) * 2 +
                           uVar16;
                  if (uVar20 < uVar16 + uVar17) {
                    func_0x(uVar16 + uVar17,0x19);
                    uVar8 = *(ushort *)(param_2 + 0xcc);
                    uVar16 = (ulonglong)*(ushort *)(param_2 + 0xca);
                    uVar17 = (ulonglong)*(uint *)(param_2 + 0xa8);
                  }
                  if (uVar15 - uVar18 <
                      (((uVar8 & 0x7ff) * 2 - (int)uVar16) - (int)uVar17) + (int)uVar20) {
                    func_0x(uVar16 + *(longlong *)(param_2 + 0xa8),0x19);
                    uVar8 = *(ushort *)(param_2 + 0xcc);
                  }
                  if (((uVar8 & 0x3800) != 0) &&
                     (puVar24 = (ushort *)
                                (*(longlong *)(param_2 + 0xa8) + 4 +
                                (ulonglong)*(ushort *)(param_2 + 0xca)), puVar19 = puVar14,
                     (uVar8 & 0x3800) != 0)) {
                    do {
                      if ((uVar8 & 0x7ff) < (*puVar24 & 0x7ff)) {
                        func_0x((ulonglong)*(ushort *)(param_2 + 0xca) +
                                        *(longlong *)(param_2 + 0xa8),0x1a);
                        uVar8 = *(ushort *)(param_2 + 0xcc);
                      }
                      uVar15 = (int)puVar19 + 1;
                      puVar24 = puVar24 + 1;
                      puVar19 = (uint *)(ulonglong)uVar15;
                    } while ((int)uVar15 < (int)(uVar8 >> 0xb & 7));
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar22 + uVar18) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar7 = *(short *)(param_2 + 0xbc) - 1;
                *(ushort *)(param_2 + 0xbc) = uVar7;
                if (uVar7 == 0) goto LAB_;
                uVar17 = (ulonglong)uVar7;
              } while ((short)puVar24[(ulonglong)(uVar7 - 1) + 1] < 0);
              uVar17 = (ulonglong)*(uint *)(param_2 + 0xa4);
            }
            else {
LAB_:
              pbVar22 = *(byte **)(param_2 + 0xa8);
              uVar17 = (ulonglong)*(uint *)(param_2 + 0xa4);
            }
          }
          if ((*pbVar22 & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0xc6) = 0;
          }
          else {
            *(int *)(param_2 + 0xc6) = (int)uVar17;
            *(int *)(param_2 + 0xa4) = (int)uVar17 + 0xe;
            uVar12 = func_0x(puVar1);
            func_0x(uVar12,auStack_78);
            iVar9 = func_0x(auStack_78);
            *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + iVar9;
            uVar17 = (ulonglong)*(uint *)(param_2 + 0xa4);
          }
          iVar9 = (int)uVar17;
          if ((*(ulonglong *)(param_2 + 0xbe) != 0) &&
             (*(ulonglong *)(param_2 + 0xbe) < uVar17 + *(longlong *)(param_2 + 0xa8))) {
            cVar6 = func_0x(0x149ce30);
            if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
              cVar6 = func_0x(0x149ce30);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                puStack_128 = (uint *)0x0;
                (*_DAT_)(1,0xd8c83c,0xeac928,0x886);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
            iVar9 = *(int *)(param_2 + 0xa4);
          }
          if (0x3f3b < iVar9 - 1U) {
            cVar6 = func_0x(0x149ce30);
            if ((cVar6 != '\0') && (cVar6 = func_0x(), cVar6 != '\0')) {
              cVar6 = func_0x(0x149ce30);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                puStack_128 = (uint *)0x0;
                (*_DAT_)(1,0xd8c83c,0xeac928,0x88b);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 0xa8),5);
          }
        }
LAB_:
        sVar21 = -*(short *)puVar11;
        param_1 = uStack_68;
        if ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0) {
          bVar5 = **(byte **)(param_2 + 0xa8);
          if ((bVar5 & 0x10) == 0) {
            if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar19 = *(uint **)(puVar11 + 2) + 1;
              param_2 = lStack_70;
              uVar15 = **(uint **)(puVar11 + 2);
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_2 + 0xb0) <= (int)*puVar11) ||
                  (*(ushort *)(*(byte **)(param_2 + 0xa8) + *(uint *)(param_2 + 0xb0)) <
                   *(ushort *)(puVar11 + 1))) goto LAB_;
        }
        puVar19 = *(uint **)(param_2 + 0xa8);
        lVar13 = (longlong)sVar21;
        if ((uint)*(ushort *)(param_2 + 0xbc) < (uint)(int)sVar21) {
          uStack_98 = 0;
          param_2 = lStack_70;
          uVar15 = uStack_98;
        }
        else {
          uVar15 = *(uint *)(param_2 + 0xb4);
          if (sVar21 == 1) {
            uVar18 = *(uint *)(param_2 + 0xb8);
            uVar15 = *(ushort *)((longlong)puVar19 + lVar13 * 2 + (ulonglong)uVar15) & 0x7fff;
LAB_:
            if ((uVar15 < uVar18) || (*(uint *)(param_2 + 0xa4) < uVar15)) goto LAB_;
          }
          else {
            puVar1 = (ushort *)((longlong)puVar19 + lVar13 * 2 + (ulonglong)uVar15);
            uVar18 = *(ushort *)((longlong)puVar19 + lVar13 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
            puVar19 = *(uint **)(param_2 + 0xa8);
            uVar15 = *puVar1 & 0x7fff;
            if (*(uint *)(param_2 + 0xb8) <= uVar18) goto LAB_;
LAB_:
            func_0x(puVar19,7);
            puVar19 = *(uint **)(param_2 + 0xa8);
          }
          puVar19 = (uint *)((longlong)puVar19 + (ulonglong)uVar18);
          param_1 = uStack_68;
          param_2 = lStack_70;
          uVar15 = uVar15 - uVar18;
        }
      }
      else {
        uVar7 = *(ushort *)((longlong)puVar11 + 6);
        if ((uVar7 & 8) == 0) {
          uVar23 = (uint)*(ushort *)(puVar11 + 0xe);
          if ((uVar7 & 0x10) != 0) {
            bVar5 = **(byte **)(param_2 + 0xa8);
            if ((bVar5 & 0x10) == 0) {
              if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                uVar15 = **(uint **)(puVar11 + 2);
                puVar19 = *(uint **)(puVar11 + 2) + 1;
                if ((uVar23 != 0) && (uVar15 != uVar23)) {
                  puStack_128 = (uint *)0x0;
                  (*_DAT_)(1,0xf3ac80,0xf395e8,0x381);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_2 + 0xb0) <= (int)uVar18) ||
                    (*(ushort *)(*(byte **)(param_2 + 0xa8) + *(uint *)(param_2 + 0xb0)) <
                     *(ushort *)(puVar11 + 1))) goto LAB_;
          }
          puVar19 = (uint *)((longlong)(int)*puVar11 + *(longlong *)(param_2 + 0xa8));
          uVar15 = uVar23;
        }
        else {
          puVar19 = (uint *)0xb114d0;
          uStack_98 = 1;
          uVar15 = uStack_98;
          if ((*(byte *)((longlong)(int)uVar18 + *(longlong *)(param_2 + 0xa8)) &
              (byte)(1 << ((byte)uVar7 & 7))) == 0) {
            puVar19 = (uint *)0xb114d1;
          }
        }
      }
    }
  }
  else {
    puStack_128 = &uStack_94;
    uStack_94 = 0;
    puVar19 = (uint *)func_0x(puVar1,puVar11,uVar16,&uStack_98);
    uVar15 = uStack_98;
    if (((*(short *)(param_2 + 0xa0) != 0) &&
        (plVar3 = *(longlong **)(param_2 + 0xb0), plVar3 != (longlong *)0x0)) &&
       ((*plVar3 != 0 && (((*(byte *)((longlong)puVar11 + 6) & 8) == 0 && ((uStack_94 & 1) == 0)))))
       ) {
      if ((puVar19 == (uint *)0x0) || (puVar19 == (uint *)0xb114d0)) {
        uStack_98 = 0;
        puVar19 = puVar14;
        uVar15 = uStack_98;
      }
      else {
        uStack_110 = uStack_94;
        puStack_118 = &uStack_98;
        puStack_128 = &uStack_7c;
        uStack_120 = (undefined8 *)CONCAT44(uStack_120._4_4_,4);
        puVar19 = (uint *)func_0x(plVar3,puVar11,puVar19,uStack_98);
        uVar15 = uStack_98;
      }
    }
  }
LAB_:
  uStack_98 = uVar15;
  if ((puVar19 != (uint *)0x0) && (*(byte *)puVar19 != 0)) {
    auStack_60[0] = (uint)*(byte *)puVar19;
    lVar13 = func_0x();
    uStack_90 = *(undefined4 *)(lVar13 + 0x68);
    uStack_8c = 0;
    uStack_84 = 0;
    lVar13 = func_0x();
    if ((lVar13 != 0) && (lVar13 = func_0x(), *(longlong *)(lVar13 + 0x30) != 0)) {
      lVar13 = func_0x();
      uVar15 = *(uint *)(*(longlong *)(lVar13 + 0x30) + 0xc);
      if ((uVar15 < 0xe) && ((0x2640U >> (uVar15 & 0x1f) & 1) != 0)) {
        lVar13 = func_0x();
        if (*(longlong *)(lVar13 + 0xa0) != 0) {
          puVar14 = *(uint **)(*(longlong *)(lVar13 + 0xa0) + 8);
        }
      }
    }
    uVar2 = *(undefined4 *)(param_2 + 0xd4);
    LOCK();
    puVar11 = puVar14 + 2;
    uVar15 = *puVar11;
    *puVar11 = *puVar11 + 1;
    UNLOCK();
    uStack_a0 = 0;
    puStack_e8 = auStack_60;
    uStack_a8 = 0;
    uStack_b0 = 0;
    uStack_b8 = 0;
    iStack_f8 = uVar15 + 1;
    uStack_c0 = 1;
    uStack_c8 = 0;
    uStack_d0 = 0;
    uStack_d8 = 0;
    uStack_e0 = 0;
    uStack_f0 = 1;
    uStack_120 = &uStack_8c;
    uStack_100 = 1;
    uStack_108 = 0x10;
    uStack_110 = 0x146c;
    puStack_118 = (uint *)((ulonglong)puStack_118 & 0xffffffff00000000);
    puStack_128 = (uint *)(param_2 + 0x60);
    func_0x(puVar14,&uStack_90,param_2 + 0x154,uVar2);
    func_0x(param_1,2,(uint *)(param_2 + 0x60));
  }
LAB_:
  func_0x(uStack_40 ^ (ulonglong)auStack_148);
  return;
}

