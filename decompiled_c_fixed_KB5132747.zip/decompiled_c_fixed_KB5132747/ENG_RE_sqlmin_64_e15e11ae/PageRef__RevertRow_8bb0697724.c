
/* WARNING: Removing unreachable block (ram,0x00102886) */
/* WARNING: Removing unreachable block (ram,0x001022a1) */
/* WARNING: Removing unreachable block (ram,0x00102355) */
/* WARNING: Removing unreachable block (ram,0x001028d5) */
/* WARNING: Removing unreachable block (ram,0x00102927) */
/* WARNING: Removing unreachable block (ram,0x001028da) */
/* WARNING: Removing unreachable block (ram,0x001028e6) */
/* WARNING: Removing unreachable block (ram,0x001028e1) */
/* WARNING: Removing unreachable block (ram,0x001028ea) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,longlong param_3,undefined8 *param_4,
                 uint param_5,short **param_6,uint param_7,longlong *param_8,int param_9,
                 uint param_10,int param_11)

{
  ushort *puVar1;
  undefined2 uVar2;
  uint *puVar3;
  byte *pbVar4;
  bool bVar5;
  char cVar6;
  ushort uVar7;
  ushort uVar8;
  int iVar9;
  longlong lVar10;
  longlong lVar11;
  ulonglong *puVar12;
  ulonglong uVar13;
  short *psVar14;
  longlong *plVar15;
  undefined8 uVar16;
  longlong lVar17;
  uint uVar18;
  uint uVar19;
  code *UNRECOVERED_JUMPTABLE;
  byte bVar20;
  byte bVar21;
  longlong **pplVar22;
  uint uVar23;
  ulonglong uVar24;
  ushort *puVar25;
  ulonglong uVar26;
  short sVar27;
  int iVar28;
  undefined8 *puVar29;
  uint uVar30;
  int iVar31;
  undefined8 *puVar32;
  bool bVar33;
  undefined auStack_728 [32];
  undefined8 uStack_708;
  undefined8 uStack_700;
  ushort *puStack_6f8;
  char cStack_6d8;
  ushort auStack_6d4 [2];
  uint uStack_6d0;
  undefined2 uStack_6cc;
  longlong **pplStack_6c8;
  undefined2 uStack_6c0;
  undefined4 uStack_6bc;
  byte *pbStack_6b8;
  undefined8 uStack_6b0;
  undefined8 uStack_6a2;
  undefined2 uStack_69a;
  undefined2 uStack_698;
  undefined6 uStack_696;
  short asStack_688 [2];
  uint uStack_684;
  longlong *plStack_680;
  int iStack_678;
  longlong *plStack_670;
  undefined8 *puStack_668;
  short **ppsStack_660;
  undefined8 uStack_658;
  int iStack_650;
  longlong lStack_648;
  int iStack_640;
  longlong lStack_638;
  short sStack_630;
  undefined4 uStack_628;
  undefined2 uStack_624;
  undefined4 uStack_620;
  undefined2 uStack_61c;
  short *psStack_618;
  undefined8 *puStack_610;
  undefined8 uStack_608;
  undefined2 uStack_600;
  undefined8 uStack_5f8;
  ushort uStack_5f0;
  undefined8 uStack_5e8;
  ushort uStack_5e0;
  undefined4 uStack_5d8;
  undefined2 uStack_5d4;
  undefined8 uStack_5c8;
  undefined auStack_5b8 [96];
  undefined8 uStack_558;
  short sStack_550;
  undefined auStack_548 [2];
  undefined2 uStack_546;
  undefined4 uStack_538;
  undefined2 uStack_534;
  undefined uStack_532;
  undefined uStack_531;
  longlong lStack_518;
  undefined4 uStack_510;
  ushort uStack_50c;
  ushort uStack_50a;
  undefined2 auStack_508 [64];
  undefined auStack_488 [528];
  undefined auStack_278 [528];
  undefined8 uStack_68;
  undefined *apuStack_58 [3];
  ulonglong uStack_40;
  
  uStack_5c8 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_728;
  ppsStack_660 = param_6;
  plStack_680 = param_8;
  iStack_678 = 0;
  asStack_688[0] = 0;
  uStack_684 = 1;
  plStack_670 = (longlong *)0x0;
  uStack_6d0 = 0;
  uStack_658 = 0;
  auStack_6d4[0] = 0;
  psStack_618 = (short *)0x0;
  iStack_650 = 0;
  uStack_620 = 0;
  uStack_61c = 0;
  lStack_648 = 0;
  iStack_640 = 0;
  pplStack_6c8 = param_1;
  puStack_668 = param_4;
  lStack_638 = param_3;
  uStack_608 = param_2;
  cVar6 = (**(code **)(*param_8 + 8))();
  if (cVar6 == '\0') {
    uStack_708 = (longlong *)0x0;
    (*_DAT_)(1,0x14be578,0x1494b70,0x16d3);
  }
  if (param_11 == 0) {
    lVar10 = func_0x(_DAT_,*param_1,1,0);
    *(ushort *)(lVar10 + 4) = *(ushort *)(lVar10 + 4) & 0xedff;
    *(undefined4 *)(lVar10 + 0x40) = 1;
    plVar15 = *param_1;
    if (*(short *)((longlong)plVar15 + 0x2c) != 2) {
      lVar10 = plVar15[0x12];
      if (lVar10 == 0) {
        func_0x(plVar15);
        lVar10 = plVar15[0x12];
        plVar15 = *param_1;
      }
      if (((*(byte *)(*(longlong *)(lVar10 + 0x6b0) + 0x3c) & 1) != 0) &&
         (*(longlong *)(*(longlong *)(lVar10 + 0x6b0) + 0x280) == 0)) {
        lVar10 = plVar15[0x12];
        if (lVar10 == 0) {
          func_0x(plVar15);
          lVar10 = plVar15[0x12];
        }
        cVar6 = func_0x(lVar10);
        if (cVar6 == '\0') goto LAB_;
      }
      plVar15 = *param_1;
      lVar10 = plVar15[0x12];
      if (lVar10 == 0) {
        func_0x(plVar15);
        lVar10 = plVar15[0x12];
      }
      if ((*(byte *)(lVar10 + 0x1cd0) & 0x20) == 0) {
        lVar10 = **param_1;
        if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
          uStack_5f8 = *(undefined8 *)(lVar10 + 0x28);
          uStack_5f0 = *(ushort *)(lVar10 + 0x30);
        }
        else {
          cVar6 = *(char *)(lVar10 + 1);
          if (cVar6 == '\v') {
            if (*(int *)(lVar10 + 0x18) != 99) {
LAB_:
              if (cVar6 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar6 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar10 + 0x18) != 99) goto LAB_;
          }
          uStack_5d8 = *(undefined4 *)(lVar10 + 0x20);
          uStack_5d4 = *(undefined2 *)(lVar10 + 0x24);
          cVar6 = func_0x(&uStack_5d8);
          if (cVar6 == '\0') goto LAB_;
          func_0x(lVar10,&uStack_5f8);
        }
        uVar7 = uStack_5f0;
        plVar15 = *param_1;
        lVar10 = plVar15[0x12];
        if (lVar10 == 0) {
          func_0x(plVar15);
          lVar10 = plVar15[0x12];
        }
        lVar11 = func_0x
                           (*(undefined8 *)(lVar10 + 0x6a0),
                            *(undefined2 *)((longlong)plVar15 + 0x74),0);
        plVar15 = *param_1;
        lVar10 = plVar15[0x12];
        if (lVar10 == 0) {
          func_0x(plVar15);
          lVar10 = plVar15[0x12];
          plVar15 = *param_1;
        }
        if (*(int *)(*(longlong *)(lVar10 + 0x7a8) + 0x58) == 0) {
          if ((uint)uStack_5f8 < *(uint *)(lVar11 + 0x130)) goto LAB_;
          if (*(uint *)(lVar11 + 0x130) == (uint)uStack_5f8) {
            if ((uStack_5f8._4_4_ < *(uint *)(lVar11 + 0x134)) ||
               ((*(uint *)(lVar11 + 0x134) == uStack_5f8._4_4_ &&
                (uVar7 < *(ushort *)(lVar11 + 0x138))))) goto LAB_;
          }
        }
        else {
LAB_:
          lVar10 = plVar15[0x12];
          if (lVar10 == 0) {
            func_0x(plVar15);
            lVar10 = plVar15[0x12];
            plVar15 = *param_1;
          }
          if (((*(byte *)(*(longlong *)(lVar10 + 0x6b0) + 0x3c) & 1) == 0) ||
             (*(longlong *)(*(longlong *)(lVar10 + 0x6b0) + 0x280) != 0)) {
            lVar10 = plVar15[0x12];
            if (lVar10 == 0) {
              func_0x(plVar15);
              lVar10 = plVar15[0x12];
              plVar15 = *param_1;
            }
            func_0x(lVar10,*plVar15 + 0x20);
            goto LAB_;
          }
        }
        lVar10 = plVar15[0x12];
        if (lVar10 == 0) {
          func_0x(plVar15);
          lVar10 = plVar15[0x12];
          plVar15 = *param_1;
        }
        lVar11 = *plVar15;
        if ((*(int *)(*(longlong *)(lVar10 + 0x7a8) + 0x110) != 0) &&
           (uVar18 = *(uint *)(lVar11 + 0x20) & 0xfffffff8, uVar18 != (uVar18 / 0x7cd00) * 0x7cd00))
        {
          lVar10 = plVar15[0x12];
          if (lVar10 == 0) {
            func_0x(plVar15);
            lVar10 = plVar15[0x12];
            lVar11 = **param_1;
          }
          func_0x(*(undefined8 *)(lVar10 + 0x7a8),lVar11 + 0x20);
        }
      }
    }
LAB_:
    lVar10 = **param_1;
    if ((*(ushort *)(lVar10 + 4) & 0x2000) != 0) {
      if (*(short *)(lVar10 + 0x24) == 0) {
LAB_:
        uStack_5e8 = *(undefined8 *)(lVar10 + 0x28);
        uStack_5e0 = *(ushort *)(lVar10 + 0x30);
      }
      else {
        cVar6 = *(char *)(lVar10 + 1);
        if (cVar6 == '\v') {
          if (*(int *)(lVar10 + 0x18) != 99) {
LAB_:
            if (cVar6 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar6 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar10 + 0x18) != 99) goto LAB_;
        }
        uStack_628 = *(undefined4 *)(lVar10 + 0x20);
        uStack_624 = *(undefined2 *)(lVar10 + 0x24);
        cVar6 = func_0x(&uStack_628);
        if (cVar6 == '\0') goto LAB_;
        func_0x(lVar10,&uStack_5e8);
      }
      uVar7 = uStack_5e0;
      plVar15 = *param_1;
      lVar10 = plVar15[0x12];
      if (lVar10 == 0) {
        func_0x(plVar15);
        lVar10 = plVar15[0x12];
      }
      puVar3 = *(uint **)(*(longlong *)(lVar10 + 0x6b0) + 0x2c0);
      if (((*(short *)((longlong)puVar3 + 10) != 2) || ((uint)uStack_5e8 != 0)) &&
         ((uint)uStack_5e8 <= *puVar3)) {
        if ((uint)uStack_5e8 == *puVar3) {
          if ((puVar3[1] < uStack_5e8._4_4_) ||
             ((uStack_5e8._4_4_ == puVar3[1] && (*(ushort *)(puVar3 + 2) < uVar7))))
          goto LAB_;
        }
        func_0x(param_1);
      }
    }
  }
LAB_:
  uVar26 = 0;
  uStack_68 = **param_1;
  cStack_6d8 = *(char *)(uStack_68 + 2);
  if ((param_5 < *(ushort *)(uStack_68 + 0x16)) &&
     (uVar7 = *(ushort *)(uStack_68 + (0xfff - (longlong)(int)param_5) * 2), uVar7 != 0)) {
    uStack_6bc = 0;
    uStack_6a2 = 0;
    uStack_698 = 0;
    uStack_696 = 0;
    uStack_6b0 = 0;
    pbStack_6b8 = (byte *)(uStack_68 + (ulonglong)uVar7);
    if ((*pbStack_6b8 & 1) != 0) {
      uStack_6c0 = 1;
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_6b8 & 0x1c) + 0x102adc)
                              * 4 + 0x102acc) - 0x148f980);
                    /* WARNING: Could not emulate address calculation at 0x001004fd */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
      return;
    }
    uStack_6c0 = 0;
    uStack_69a = 0;
    uStack_698 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001006b4 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_6b8 & 0xe) * 4 + 0x102afc) - 0x148f980)
    )((longlong)(int)(*pbStack_6b8 & 0xe),0xfffffffffeb70680,pbStack_6b8);
    return;
  }
  if (param_6 != (short **)0x0) {
    psVar14 = *param_6;
    puVar1 = (ushort *)(psVar14 + 1);
    psStack_618 = psVar14;
    if (*psVar14 == 0) {
      uStack_6d0 = *(uint *)(psVar14 + 2);
      uVar18 = uStack_6d0;
      if (uStack_6d0 == 0) {
        *puVar1 = 0;
        uVar18 = *(uint *)(psVar14 + 8);
        uVar13 = (ulonglong)uVar18;
        *(uint *)(psVar14 + 10) = uVar18;
        pbVar4 = *(byte **)(psVar14 + 4);
        bVar20 = *pbVar4;
        if ((bVar20 & 0x10) != 0) {
          uVar18 = uVar18 + 2 + (*(ushort *)(pbVar4 + uVar13) + 7 >> 3);
          uVar13 = (ulonglong)uVar18;
          *(uint *)(psVar14 + 10) = uVar18;
          bVar20 = *pbVar4;
        }
        if ((bVar20 & 0x20) == 0) {
          *(int *)(psVar14 + 2) = (int)uVar13;
          psVar14[0xe] = 0;
          *(int *)(psVar14 + 0xc) = (int)uVar13;
          uStack_6d0 = 0;
        }
        else {
          puVar32 = (undefined8 *)(pbVar4 + uVar13);
          uVar7 = *(ushort *)puVar32;
          psVar14[0xe] = uVar7;
          puStack_610 = puVar32;
          if (uVar7 == 0) {
            cVar6 = func_0x(0x1a1fc40);
            if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1a1fc40);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x130f64c,0x142f738,0x80f);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),3);
            uVar7 = psVar14[0xe];
            uVar13 = (ulonglong)*(uint *)(psVar14 + 10);
          }
          uVar19 = (uint)uVar7;
          uVar18 = (int)uVar13 + (uVar19 + 1) * 2;
          *(uint *)(psVar14 + 0xc) = uVar18;
          if (0x1f9e < uVar18) {
            cVar6 = func_0x(0x1a1fc40);
            if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1a1fc40);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x130f64c,0x142f738,0x816);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),4);
            uVar19 = (uint)(ushort)psVar14[0xe];
            uVar18 = *(uint *)(psVar14 + 0xc);
          }
          uStack_6d0 = *(ushort *)((longlong)puVar32 + (ulonglong)uVar19 * 2) & 0x7fff;
          *(uint *)(psVar14 + 2) = uStack_6d0;
          if (uStack_6d0 < uVar18) {
            cVar6 = func_0x(0x1a1fc40);
            if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1a1fc40);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x130f64c,0x142f738,0x81d);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),4);
            uVar18 = *(uint *)(psVar14 + 0xc);
            uVar19 = (uint)(ushort)psVar14[0xe];
            uStack_6d0 = *(uint *)(psVar14 + 2);
          }
          puVar29 = puVar32;
          if ((short)uVar19 != 0) {
            do {
              puVar32 = (undefined8 *)((longlong)puVar32 + 2);
              uVar23 = *(ushort *)puVar32 & 0x7fff;
              if ((uVar23 < uVar18) || (uStack_6d0 = *(uint *)(psVar14 + 2), uStack_6d0 < uVar23)) {
                cVar6 = func_0x(0x1a1fc40);
                if ((cVar6 != '\0') &&
                   ((lVar10 = func_0x(), lVar10 != 0 &&
                    (*(char *)(lVar10 + 0x499) != '\0')))) {
                  cVar6 = func_0x(0x1a1fc40);
                  if (cVar6 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_708 = (longlong *)0x0;
                    (*_DAT_)(1,0x130f64c,0x142f738,0x82a);
                  }
                }
                func_0x(*(undefined8 *)(psVar14 + 4),4);
                uStack_6d0 = *(uint *)(psVar14 + 2);
              }
              uVar30 = (int)uVar26 + 1;
              uVar26 = (ulonglong)uVar30;
              uVar19 = (uint)(ushort)psVar14[0xe];
              param_1 = pplStack_6c8;
              puVar29 = puStack_610;
              uVar18 = uVar23;
            } while ((int)uVar30 < (int)uVar19);
          }
          if (*(short *)((longlong)puVar29 + (ulonglong)(uVar19 - 1) * 2 + 2) < 0) {
            lVar10 = *(longlong *)(psVar14 + 4);
LAB_:
            uVar23 = *(ushort *)
                      ((ulonglong)*(uint *)(psVar14 + 10) + lVar10 + (ulonglong)uVar19 * 2) & 0x7fff
            ;
            if (uVar19 == 1) {
              uVar19 = *(uint *)(psVar14 + 0xc);
              uVar30 = uVar19;
LAB_:
              if ((uVar23 < uVar19) || (uStack_6d0 = *(uint *)(psVar14 + 2), uStack_6d0 < uVar23))
              goto LAB_;
            }
            else {
              uVar19 = *(ushort *)
                        ((ulonglong)*(uint *)(psVar14 + 10) + lVar10 + -2 + (ulonglong)uVar19 * 2) &
                       0x7fff;
              uVar30 = *(uint *)(psVar14 + 0xc);
              if (uVar30 <= uVar19) goto LAB_;
LAB_:
              func_0x(lVar10,7);
              uVar30 = *(uint *)(psVar14 + 0xc);
              uStack_6d0 = *(uint *)(psVar14 + 2);
            }
            uVar13 = (ulonglong)uStack_6d0;
            uVar18 = uStack_6d0;
            if ((uVar30 <= uVar19) && (uVar19 <= uStack_6d0)) {
              lVar10 = *(longlong *)(psVar14 + 4);
              if (*(ushort *)((ulonglong)uVar19 + lVar10) == 5) {
                *puVar1 = *puVar1 | 2;
                psVar14[0xe] = psVar14[0xe] + -1;
                uVar26 = (ulonglong)(uVar19 & 0xffff);
                psVar14[0x15] = (short)uVar19;
                uVar7 = psVar14[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar26 + 2 + lVar10) >> 0xe & 1) != 0) {
                  uVar7 = *(ushort *)(uVar26 + 2 + lVar10) & 0x3800 | psVar14[0x16] & 0xc7ffU;
                }
                psVar14[0x16] = uVar7;
                uVar8 = (uVar7 ^ *(ushort *)(uVar26 + 2 + lVar10)) & 0x7ff ^ uVar7;
                psVar14[0x16] = uVar8;
                uVar13 = *(ulonglong *)(psVar14 + 4);
                uVar24 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar13 + (uVar7 >> 0xb & 7) * 2 +
                         uVar26;
                if (uVar24 < uVar26 + uVar13) {
                  func_0x(uVar26 + uVar13,0x19);
                  uVar8 = psVar14[0x16];
                  uVar26 = (ulonglong)(ushort)psVar14[0x15];
                  uVar13 = (ulonglong)*(uint *)(psVar14 + 4);
                }
                if (uVar23 - uVar19 <
                    (((uVar8 & 0x7ff) * 2 - (int)uVar26) - (int)uVar13) + (int)uVar24) {
                  func_0x(uVar26 + *(longlong *)(psVar14 + 4),0x19);
                  uVar8 = psVar14[0x16];
                }
                if ((uVar8 & 0x3800) != 0) {
                  puVar25 = (ushort *)
                            (*(longlong *)(psVar14 + 4) + (ulonglong)(ushort)psVar14[0x15] + 4);
                  iVar31 = 0;
                  if ((uVar8 & 0x3800) != 0) {
                    do {
                      if ((uVar8 & 0x7ff) < (*puVar25 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)psVar14[0x15] +
                                        *(longlong *)(psVar14 + 4),0x1a);
                        uVar8 = psVar14[0x16];
                      }
                      iVar31 = iVar31 + 1;
                      puVar25 = puVar25 + 1;
                    } while (iVar31 < (int)(uVar8 >> 0xb & 7));
                  }
                }
                uVar13 = (ulonglong)*(uint *)(psVar14 + 2);
              }
              else if (0x3ff < *(ushort *)((ulonglong)uVar19 + lVar10)) goto code_r0x0010123e;
              goto LAB_;
            }
            goto LAB_;
          }
          uVar13 = (ulonglong)uStack_6d0;
        }
LAB_:
        iVar31 = 0;
        if ((**(byte **)(psVar14 + 4) & 0x40) == 0) {
          *(undefined4 *)(psVar14 + 0x13) = 0;
        }
        else {
          *(int *)(psVar14 + 0x13) = *(int *)(psVar14 + 2);
          *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + 0xe;
          puVar12 = (ulonglong *)func_0x(puVar1);
          uVar8 = (ushort)(*puVar12 >> 0x30);
          uVar7 = uVar8;
          if ((((uint)(int)(short)uVar8 >> 1 ^ (int)(short)uVar8) & 0x2000) != 0) {
            uVar7 = uVar8 & 0xdfff;
            if ((uVar8 >> 0xe & 1) != 0) {
              uVar7 = uVar8 | 0x2000;
            }
          }
          if (uVar7 == 0xfffc) {
            iVar31 = (int)((*puVar12 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + iVar31;
          uVar13 = (ulonglong)*(uint *)(psVar14 + 2);
        }
        uStack_6d0 = (uint)uVar13;
        if ((*(ulonglong *)(psVar14 + 0xf) != 0) &&
           (*(ulonglong *)(psVar14 + 0xf) < uVar13 + *(longlong *)(psVar14 + 4))) {
          cVar6 = func_0x(0x1a1fc40);
          if ((cVar6 != '\0') &&
             ((lVar10 = func_0x(), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            cVar6 = func_0x(0x1a1fc40);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_708 = (longlong *)0x0;
              (*_DAT_)(1,0x130f64c,0x142f738,0x886);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),0x12);
          uStack_6d0 = *(uint *)(psVar14 + 2);
          uVar13 = (ulonglong)uStack_6d0;
        }
        uVar18 = (uint)uVar13;
        if ((uVar18 == 0) || (0x3f3c < uVar18)) {
          cVar6 = func_0x(0x1a1fc40);
          if ((cVar6 != '\0') &&
             ((lVar10 = func_0x(), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            cVar6 = func_0x(0x1a1fc40);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_708 = (longlong *)0x0;
              (*_DAT_)(1,0x130f64c,0x142f738,0x88b);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),5);
          uStack_6d0 = *(uint *)(psVar14 + 2);
          uVar18 = uStack_6d0;
        }
      }
LAB_:
      param_6 = ppsStack_660;
      if ((uVar18 < 9) &&
         (((**(byte **)(psVar14 + 4) & 0xe) == 0 || ((**(byte **)(psVar14 + 4) & 0xe) == 0xc)))) {
        uStack_6d0 = 9;
      }
    }
    else {
      uStack_6d0 = *(uint *)(psVar14 + 2);
      if (uStack_6d0 == 0) {
        func_0x(puVar1);
        uStack_6d0 = *(uint *)(psVar14 + 2);
      }
      if ((uStack_6d0 < 9) &&
         (((**(byte **)(psVar14 + 4) & 0x1c) == 0 || ((**(byte **)(psVar14 + 4) & 0x1c) == 0xc)))) {
        uStack_6d0 = 9;
      }
    }
    iVar31 = 0;
    if (cStack_6d8 < '\0') {
      psVar14 = param_6[1];
    }
    else {
      psVar14 = *param_6;
    }
    puVar1 = (ushort *)(psVar14 + 1);
    uVar18 = *(uint *)(psVar14 + 2);
    uVar26 = (ulonglong)uVar18;
    if (*psVar14 == 0) {
      if (uVar18 == 0) {
        *puVar1 = 0;
        uVar18 = *(uint *)(psVar14 + 8);
        uVar26 = (ulonglong)uVar18;
        *(uint *)(psVar14 + 10) = uVar18;
        pbVar4 = *(byte **)(psVar14 + 4);
        bVar20 = *pbVar4;
        if ((bVar20 & 0x10) != 0) {
          uVar18 = uVar18 + 2 + (*(ushort *)(pbVar4 + uVar26) + 7 >> 3);
          uVar26 = (ulonglong)uVar18;
          *(uint *)(psVar14 + 10) = uVar18;
          bVar20 = *pbVar4;
        }
        iVar9 = (int)uVar26;
        if ((bVar20 & 0x20) == 0) {
          *(int *)(psVar14 + 2) = iVar9;
          psVar14[0xe] = 0;
          *(int *)(psVar14 + 0xc) = iVar9;
        }
        else {
          puVar32 = (undefined8 *)(pbVar4 + uVar26);
          uVar7 = *(ushort *)puVar32;
          psVar14[0xe] = uVar7;
          puStack_610 = puVar32;
          if (uVar7 == 0) {
            cVar6 = func_0x(0x1a1fc40);
            if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1a1fc40);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x130f64c,0x142f738,0x80f);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),3);
            uVar7 = psVar14[0xe];
            iVar9 = *(int *)(psVar14 + 10);
          }
          uVar19 = (uint)uVar7;
          uVar18 = iVar9 + (uVar19 + 1) * 2;
          *(uint *)(psVar14 + 0xc) = uVar18;
          if (0x1f9e < uVar18) {
            cVar6 = func_0x(0x1a1fc40);
            if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1a1fc40);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x130f64c,0x142f738,0x816);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),4);
            uVar19 = (uint)(ushort)psVar14[0xe];
            uVar18 = *(uint *)(psVar14 + 0xc);
          }
          uVar23 = *(ushort *)((longlong)puVar32 + (ulonglong)uVar19 * 2) & 0x7fff;
          *(uint *)(psVar14 + 2) = uVar23;
          if (uVar23 < uVar18) {
            cVar6 = func_0x(0x1a1fc40);
            if (((cVar6 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1a1fc40);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_708 = (longlong *)0x0;
                (*_DAT_)(1,0x130f64c,0x142f738,0x81d);
              }
            }
            func_0x(*(undefined8 *)(psVar14 + 4),4);
            uVar18 = *(uint *)(psVar14 + 0xc);
            uVar19 = (uint)(ushort)psVar14[0xe];
            uVar23 = *(uint *)(psVar14 + 2);
          }
          puVar29 = puVar32;
          if ((short)uVar19 != 0) {
            do {
              puVar32 = (undefined8 *)((longlong)puVar32 + 2);
              uVar30 = *(ushort *)puVar32 & 0x7fff;
              if ((uVar30 < uVar18) || (uVar23 = *(uint *)(psVar14 + 2), uVar23 < uVar30)) {
                cVar6 = func_0x(0x1a1fc40);
                if ((cVar6 != '\0') &&
                   ((lVar10 = func_0x(), lVar10 != 0 &&
                    (*(char *)(lVar10 + 0x499) != '\0')))) {
                  cVar6 = func_0x(0x1a1fc40);
                  if (cVar6 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_708 = (longlong *)0x0;
                    (*_DAT_)(1,0x130f64c,0x142f738,0x82a);
                  }
                }
                func_0x(*(undefined8 *)(psVar14 + 4),4);
                uVar23 = *(uint *)(psVar14 + 2);
              }
              iVar31 = iVar31 + 1;
              uVar19 = (uint)(ushort)psVar14[0xe];
              puVar29 = puStack_610;
              uVar18 = uVar30;
            } while (iVar31 < (int)uVar19);
          }
          uVar26 = (ulonglong)uVar23;
          if (*(short *)((longlong)puVar29 + (ulonglong)(uVar19 - 1) * 2 + 2) < 0) {
            lVar10 = *(longlong *)(psVar14 + 4);
LAB_:
            uVar18 = *(ushort *)
                      ((ulonglong)*(uint *)(psVar14 + 10) + lVar10 + (ulonglong)uVar19 * 2) & 0x7fff
            ;
            if (uVar19 == 1) {
              uVar19 = *(uint *)(psVar14 + 0xc);
              uVar13 = (ulonglong)uVar19;
LAB_:
              if ((uVar18 < (uint)uVar13) || (uVar23 = *(uint *)(psVar14 + 2), uVar23 < uVar18))
              goto LAB_;
            }
            else {
              uVar23 = *(ushort *)
                        ((ulonglong)*(uint *)(psVar14 + 10) + lVar10 + -2 + (ulonglong)uVar19 * 2) &
                       0x7fff;
              uVar13 = (ulonglong)uVar23;
              uVar19 = *(uint *)(psVar14 + 0xc);
              if (uVar19 <= uVar23) goto LAB_;
LAB_:
              func_0x(lVar10,7);
              uVar19 = *(uint *)(psVar14 + 0xc);
              uVar23 = *(uint *)(psVar14 + 2);
            }
            uVar26 = (ulonglong)uVar23;
            uVar30 = (uint)uVar13;
            if ((uVar19 <= uVar30) && (uVar30 <= uVar23)) {
              lVar10 = *(longlong *)(psVar14 + 4);
              if (*(ushort *)(uVar13 + lVar10) == 5) {
                *puVar1 = *puVar1 | 2;
                psVar14[0xe] = psVar14[0xe] + -1;
                uVar26 = uVar13 & 0xffff;
                psVar14[0x15] = (short)uVar13;
                uVar7 = psVar14[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar26 + 2 + lVar10) >> 0xe & 1) != 0) {
                  uVar7 = *(ushort *)(uVar26 + 2 + lVar10) & 0x3800 | psVar14[0x16] & 0xc7ffU;
                }
                psVar14[0x16] = uVar7;
                uVar8 = (uVar7 ^ *(ushort *)(uVar26 + 2 + lVar10)) & 0x7ff ^ uVar7;
                psVar14[0x16] = uVar8;
                uVar13 = *(ulonglong *)(psVar14 + 4);
                uVar24 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar13 + (uVar7 >> 0xb & 7) * 2 +
                         uVar26;
                if (uVar24 < uVar26 + uVar13) {
                  func_0x(uVar26 + uVar13,0x19);
                  uVar8 = psVar14[0x16];
                  uVar26 = (ulonglong)(ushort)psVar14[0x15];
                  uVar13 = (ulonglong)*(uint *)(psVar14 + 4);
                }
                if (uVar18 - uVar30 <
                    (((uVar8 & 0x7ff) * 2 - (int)uVar26) - (int)uVar13) + (int)uVar24) {
                  func_0x(uVar26 + *(longlong *)(psVar14 + 4),0x19);
                  uVar8 = psVar14[0x16];
                }
                if ((uVar8 & 0x3800) != 0) {
                  puVar25 = (ushort *)
                            (*(longlong *)(psVar14 + 4) + (ulonglong)(ushort)psVar14[0x15] + 4);
                  iVar31 = 0;
                  if ((uVar8 & 0x3800) != 0) {
                    do {
                      if ((uVar8 & 0x7ff) < (*puVar25 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)psVar14[0x15] +
                                        *(longlong *)(psVar14 + 4),0x1a);
                        uVar8 = psVar14[0x16];
                      }
                      iVar31 = iVar31 + 1;
                      puVar25 = puVar25 + 1;
                    } while (iVar31 < (int)(uVar8 >> 0xb & 7));
                  }
                }
                uVar26 = (ulonglong)*(uint *)(psVar14 + 2);
              }
              else if (0x3ff < *(ushort *)(uVar13 + lVar10)) goto code_r0x001019b5;
              goto LAB_;
            }
            goto LAB_;
          }
        }
LAB_:
        iVar31 = 0;
        if ((**(byte **)(psVar14 + 4) & 0x40) == 0) {
          *(undefined4 *)(psVar14 + 0x13) = 0;
        }
        else {
          *(int *)(psVar14 + 0x13) = *(int *)(psVar14 + 2);
          *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + 0xe;
          puVar12 = (ulonglong *)func_0x(puVar1);
          uVar8 = (ushort)(*puVar12 >> 0x30);
          uVar7 = uVar8;
          if ((((uint)(int)(short)uVar8 >> 1 ^ (int)(short)uVar8) & 0x2000) != 0) {
            uVar7 = uVar8 & 0xdfff;
            if ((uVar8 >> 0xe & 1) != 0) {
              uVar7 = uVar8 | 0x2000;
            }
          }
          if (uVar7 == 0xfffc) {
            iVar31 = (int)((*puVar12 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + iVar31;
          uVar26 = (ulonglong)*(uint *)(psVar14 + 2);
        }
        if ((*(ulonglong *)(psVar14 + 0xf) != 0) &&
           (*(ulonglong *)(psVar14 + 0xf) < uVar26 + *(longlong *)(psVar14 + 4))) {
          cVar6 = func_0x(0x1a1fc40);
          if ((cVar6 != '\0') &&
             ((lVar10 = func_0x(), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            cVar6 = func_0x(0x1a1fc40);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_708 = (longlong *)0x0;
              (*_DAT_)(1,0x130f64c,0x142f738,0x886);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),0x12);
          uVar26 = (ulonglong)*(uint *)(psVar14 + 2);
        }
        if (((uint)uVar26 == 0) || (0x3f3c < (uint)uVar26)) {
          cVar6 = func_0x(0x1a1fc40);
          if ((cVar6 != '\0') &&
             ((lVar10 = func_0x(), lVar10 != 0 &&
              (*(char *)(lVar10 + 0x499) != '\0')))) {
            cVar6 = func_0x(0x1a1fc40);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_708 = (longlong *)0x0;
              (*_DAT_)(1,0x130f64c,0x142f738,0x88b);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),5);
          uVar26 = (ulonglong)*(uint *)(psVar14 + 2);
        }
      }
LAB_:
      param_1 = pplStack_6c8;
      if (((uint)uVar26 < 9) &&
         (((**(byte **)(psVar14 + 4) & 0xe) == 0 || ((**(byte **)(psVar14 + 4) & 0xe) == 0xc)))) {
        uVar26 = 9;
      }
    }
    else {
      if (uVar18 == 0) {
        func_0x(puVar1);
        uVar26 = (ulonglong)*(uint *)(psVar14 + 2);
      }
      if (((uint)uVar26 < 9) &&
         (((**(byte **)(psVar14 + 4) & 0x1c) == 0 || ((**(byte **)(psVar14 + 4) & 0x1c) == 0xc)))) {
        uVar26 = 9;
      }
    }
  }
  uVar18 = param_10;
  if ((param_10 >> 0x12 & 1) != 0) {
    uStack_708 = (longlong *)0x0;
    (*_DAT_)(1,0x14ca2b8,0x1494b70,0x16f5);
  }
  uStack_658 = *puStack_668;
  plVar15 = *param_1;
  if ((param_7 >> 0x16 & 1) == 0) {
    if (((*(uint *)((longlong)plVar15 + 100) >> 0x13 & 1) != 0) &&
       (1 < (byte)(*(char *)(**pplStack_6c8 + 1) - 3U))) {
      uStack_708 = (longlong *)0x0;
      (*_DAT_)(1,0x14ca320,0x1494b70,0x9dd);
    }
LAB_:
    bVar5 = false;
  }
  else {
    lVar10 = plVar15[0x12];
    if (lVar10 == 0) {
      func_0x(plVar15);
      lVar10 = plVar15[0x12];
    }
    pplVar22 = pplStack_6c8;
    lVar10 = *(longlong *)(lVar10 + 0x6b0);
    sVar27 = *(short *)(lVar10 + 0x28);
    if (sVar27 == 2) {
      uVar19 = *(uint *)(**pplStack_6c8 + 0x18);
      uVar7 = *(ushort *)(**pplStack_6c8 + 6);
      if (((uVar19 & 0xe0000000) == 0x80000000) && (uVar7 < 0x100)) {
LAB_:
        bVar5 = true;
      }
      else if (uVar19 == _DAT_) {
        uVar8 = 0;
        if (uVar7 != 1) {
          uVar8 = uVar7;
        }
        uVar7 = _DAT_;
        if (_DAT_ == 1) {
          uVar7 = 0;
        }
        if (uVar8 != uVar7) goto LAB_;
        bVar5 = true;
      }
      else {
LAB_:
        if ((~*(uint *)(plStack_680 + 0x43) & 1) == 0) goto LAB_;
        bVar5 = true;
      }
    }
    else {
LAB_:
      if ((*(uint *)((longlong)*pplStack_6c8 + 100) >> 0x13 & 1) == 0) {
        if ((*(byte *)(lVar10 + 0x278) & 0xc) != 0) {
          if ((*(uint *)((longlong)*pplStack_6c8 + 100) >> 0x13 & 1) != 0) goto LAB_;
          if ((~*(uint *)(plStack_680 + 0x43) & 1) != 0) {
            uStack_708 = (longlong *)0x0;
            (*_DAT_)(1,0x14ca2f0,0x1494b70,0x958);
          }
          plVar15 = *pplVar22;
          if ((((*(byte *)(*plVar15 + 4) & 0x20) != 0) &&
              ((*(uint *)((longlong)plVar15 + 100) & 2) != 0)) && (sVar27 != 2)) {
            uStack_708 = (longlong *)0x0;
            (*_DAT_)(1,0x14ca4d0,0x1494b70,0x96a);
          }
          goto LAB_;
        }
        if ((~*(uint *)(plStack_680 + 0x43) & 1) != 0) {
          (*_DAT_)(auStack_5b8);
          (*_DAT_)(auStack_488);
          (*_DAT_)(auStack_278);
          uVar16 = (*_DAT_)();
          puVar32 = (undefined8 *)(*_DAT_)(uVar16,0,0x6c0);
          puStack_610 = puVar32;
          if (puVar32 != (undefined8 *)0x0) {
            puVar32 = (undefined8 *)func_0x(puVar32,0);
          }
          if (puVar32 == (undefined8 *)0x0) {
LAB_:
            plVar15 = (longlong *)(*_DAT_)();
            uStack_708 = (longlong *)CONCAT44(uStack_708._4_4_,0xffffffff);
            (**(code **)(*plVar15 + 0xa8))(plVar15,0x13492f0,0x21,1);
          }
          else {
            iVar31 = (*_DAT_)(auStack_5b8,puVar32);
            if (iVar31 == 0) {
              (**(code **)*puVar32)(puVar32,1);
              goto LAB_;
            }
            bVar20 = DAT_ >> 1;
            bVar21 = DAT_ >> 5;
            lVar11 = func_0x();
            (*_DAT_)(0x9c9,*(undefined2 *)
                                    (*(longlong *)(*(longlong *)(lVar11 + 0x50) + 0x48) + 0x10),0,0)
            ;
            lVar11 = func_0x();
            (*_DAT_)(0xe15,*(undefined2 *)
                                    (*(longlong *)(*(longlong *)(lVar11 + 0x50) + 0x48) + 0x10),0,0)
            ;
            (*_DAT_)(auStack_488,auStack_5b8,0x13492c0);
            func_0x(lVar10,auStack_5b8);
            (*_DAT_)(auStack_278,auStack_5b8,0x1349390);
            func_0x(*pplStack_6c8,auStack_5b8,0);
            if ((bVar21 & 1) == 0) {
              lVar10 = func_0x();
              (*_DAT_)(0xe15,*(undefined2 *)
                                      (*(longlong *)(*(longlong *)(lVar10 + 0x50) + 0x48) + 0x10),0,
                               0);
            }
            pplVar22 = pplStack_6c8;
            if ((bVar20 & 1) == 0) {
              lVar10 = func_0x();
              (*_DAT_)(0x9c9,*(undefined2 *)
                                      (*(longlong *)(*(longlong *)(lVar10 + 0x50) + 0x48) + 0x10),0,
                               0);
              pplVar22 = pplStack_6c8;
            }
          }
          if ((~*(uint *)(plStack_680 + 0x43) & 1) != 0) {
            uStack_708 = (longlong *)0x0;
            (*_DAT_)(1,0x14ca2f0,0x1494b70,0x9ae);
          }
          (*_DAT_)(auStack_278);
          (*_DAT_)(auStack_488);
          (*_DAT_)();
        }
        if (((*(uint *)((longlong)*pplVar22 + 100) >> 0x13 & 1) != 0) &&
           (1 < (byte)(*(char *)(**pplVar22 + 1) - 3U))) {
          uStack_708 = (longlong *)0x0;
          (*_DAT_)(1,0x14ca320,0x1494b70,0x9b8);
        }
        goto LAB_;
      }
      bVar5 = true;
    }
  }
  lVar10 = uStack_68;
  if (*(char *)(uStack_68 + 1) == '\x03') {
LAB_:
    iVar31 = 0;
LAB_:
    iVar9 = func_0x(plStack_680);
    if (iVar9 == 0) {
      (**(code **)(*plStack_680 + 0x270))();
    }
    func_0x(plStack_680[6] + 0x19c8);
    uStack_708 = plStack_680 + 5;
    iVar9 = 0;
    lVar11 = (ulonglong)*(ushort *)(lVar10 + 0x16) - 1;
    if (-1 < lVar11) {
      psVar14 = (short *)(lVar10 + (0xfff - lVar11) * 2);
      do {
        if (*psVar14 != 0) break;
        iVar9 = iVar9 + 1;
        psVar14 = psVar14 + 1;
        lVar11 = lVar11 + -1;
      } while (-1 < lVar11);
    }
    iStack_650 = (uint)*(ushort *)(lVar10 + 0x1c) + iVar9 * 2;
    uStack_684 = ~(uVar18 >> 0xf) & 0x10;
    uVar7 = (short)(1 << ((byte)*(undefined2 *)(lVar10 + 4) & 2)) - 1;
    puStack_6f8 = auStack_6d4;
    uStack_700 = (longlong *)&uStack_620;
    plStack_670 = uStack_708;
    func_0x(lVar10,0,(short)uVar26 + uVar7 & ~uVar7,uStack_684);
  }
  else {
    if ((*(char *)(uStack_68 + 1) == '\x01') && ((param_7 & 1) == 0)) {
      if (((*(uint *)(uStack_68 + 0x18) & 0xe0000000) != 0x80000000) ||
         (iVar31 = 1, 0xff < *(ushort *)(uStack_68 + 6))) goto LAB_;
      goto LAB_;
    }
    iVar31 = 2;
  }
  puStack_6f8 = (ushort *)asStack_688;
  uStack_700 = (longlong *)&iStack_678;
  uStack_708 = plStack_670;
  iVar9 = func_0x(lVar10,param_5,uVar26,uStack_684);
  if (iVar9 != 0) goto LAB_;
  uVar18 = uVar18 & 0x200;
  if (uVar18 != 0) {
    auStack_6d4[0] = auStack_6d4[0] | 0x200;
  }
  if (param_9 != 0) {
    func_0x(&lStack_648,uStack_608);
  }
  pplVar22 = pplStack_6c8;
  if (iVar31 == 2) {
    if (psStack_618 != (short *)0x0) {
      pbVar4 = *(byte **)(psStack_618 + 4);
      if (*psStack_618 == 0) {
        bVar20 = *pbVar4 & 0xe;
        bVar33 = false;
        if (bVar20 == 2) {
          bVar33 = (pbVar4[1] & 1) != 0;
        }
        else if (((bVar20 - 10 & 0xf9) == 0) && (bVar20 != 0x10)) {
          bVar33 = true;
        }
      }
      else {
        bVar33 = ((*pbVar4 & 0x1c) - 4 & 0xffffffe7) == 0;
      }
      if (bVar33) {
        if (*(short *)(uStack_68 + 0x3a) == 0) goto LAB_;
        if ((*(short *)(uStack_68 + 0x3a) == 1) && (*(int *)(uStack_68 + 8) == 0)) {
          bVar33 = *(short *)(uStack_68 + 0xc) == 0;
          goto LAB_;
        }
      }
    }
  }
  else {
    iVar28 = 0;
    iVar9 = 0;
    lVar10 = 0;
    while( true ) {
      iVar28 = iVar28 + 1;
      iVar9 = iVar9 + 1;
      lVar10 = lVar10 + 1;
      if ((int)(uint)*(ushort *)(uStack_68 + 0x16) <= iVar9) break;
      psVar14 = (short *)(uStack_68 + (0xfff - lVar10) * 2);
      while (*psVar14 == 0) {
        iVar9 = iVar9 + 1;
        lVar10 = lVar10 + 1;
        psVar14 = psVar14 + -1;
        if ((int)(uint)*(ushort *)(uStack_68 + 0x16) <= iVar9) goto LAB_;
      }
      if (lVar10 == -1) break;
    }
LAB_:
    if (psStack_618 == (short *)0x0) {
      bVar33 = iVar28 == 1;
    }
    else {
      pbVar4 = *(byte **)(psStack_618 + 4);
      bVar33 = false;
      if (*psStack_618 == 0) {
        bVar20 = *pbVar4 & 0xe;
        if (bVar20 == 2) {
          bVar33 = (pbVar4[1] & 1) != 0;
        }
        else if (((bVar20 - 10 & 0xf9) == 0) && (bVar20 != 0x10)) {
          bVar33 = true;
        }
      }
      else {
        bVar33 = ((*pbVar4 & 0x1c) - 4 & 0xffffffe7) == 0;
      }
      if (!bVar33) goto LAB_;
      bVar33 = *(short *)(uStack_68 + 0x3a) == 0;
    }
LAB_:
    if (bVar33) {
LAB_:
      if (((byte)*(undefined2 *)((longlong)*pplStack_6c8 + 0x62) >> 2 & 1) == 0) {
        func_0x
                  (*pplStack_6c8,(*(short *)((longlong)*pplStack_6c8 + 0x2c) != 2) + '\x02',1);
        LOCK();
        puVar3 = (uint *)(*(longlong *)(plStack_680[6] + 0x6b0) + 0x1540);
        *puVar3 = *puVar3 & 0xfffffff7;
        UNLOCK();
      }
    }
  }
LAB_:
  lVar10 = uStack_68;
  if (bVar5) {
    if (*(short *)(uStack_68 + 0x24) == 0) {
LAB_:
      lStack_638 = *(longlong *)(lVar10 + 0x28);
      sStack_630 = *(short *)(lVar10 + 0x30);
    }
    else {
      cVar6 = *(char *)(uStack_68 + 1);
      if (cVar6 == '\v') {
        if (*(int *)(uStack_68 + 0x18) != 99) {
LAB_:
          if (cVar6 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar6 != '\b') goto LAB_;
LAB_:
        if (*(int *)(uStack_68 + 0x18) != 99) goto LAB_;
      }
      uStack_6d0 = *(uint *)(uStack_68 + 0x20);
      uStack_6cc = *(undefined2 *)(uStack_68 + 0x24);
      cVar6 = func_0x(&uStack_6d0);
      if (cVar6 == '\0') goto LAB_;
      func_0x(lVar10,&lStack_638);
    }
    plVar15 = *pplVar22;
    lVar11 = plVar15[0x12];
    uStack_558 = lStack_638;
    sStack_550 = sStack_630;
    if (lVar11 == 0) {
      func_0x(plVar15);
      lVar11 = plVar15[0x12];
      plVar15 = *pplVar22;
    }
    func_0x(*(undefined8 *)(lVar11 + 0x758),plVar15,0);
    plVar15 = plStack_680;
  }
  else {
    uStack_538 = 0;
    uStack_534 = 0;
    uStack_50a = 0;
    uStack_532 = 0x7b;
    uVar2 = *(undefined2 *)((longlong)*pplVar22 + 0x62);
    uStack_531 = func_0x(uStack_68,param_7);
    uStack_700 = (longlong *)(CONCAT71(uStack_700._1_7_,(byte)uVar2 >> 3) & 0xffffffffffffff01);
    uStack_708 = (longlong *)((ulonglong)uStack_708 & 0xffffffffffff0000);
    func_0x(auStack_548,puStack_668,lVar10,param_5);
    plVar15 = plStack_680;
    lStack_518 = lStack_638;
    uStack_50c = auStack_6d4[0] & 0xfbff;
    uStack_510 = 0;
    uVar7 = 1;
    if (ppsStack_660 == (short **)0x0) {
      auStack_508[uStack_50a] = 0;
    }
    else {
      auStack_508[uStack_50a] = (short)uStack_6d0;
      uStack_68._4_4_ = uStack_6d0;
      apuStack_58[1] = *(undefined **)(psStack_618 + 4);
      uVar7 = 2;
    }
    if (param_9 == 0) {
      auStack_508[(ushort)(uStack_50a + 1)] = 0;
    }
    else {
      auStack_508[(ushort)(uStack_50a + 1)] = 4;
      *(undefined4 *)((longlong)&uStack_68 + (ulonglong)uVar7 * 4) = 4;
      apuStack_58[uVar7] = (undefined *)&param_9;
      uVar7 = uVar7 + 1;
    }
    uStack_50a = uStack_50a + 2;
    uStack_546 = 0x3e;
    uStack_68 = CONCAT44(uStack_68._4_4_,(uint)uStack_50a * 2 + 0x40);
    apuStack_58[0] = auStack_548;
    uStack_708 = &uStack_558;
    (**(code **)(*plStack_680 + 0x288))(plStack_680,uVar7,&uStack_68,apuStack_58);
    if ((DAT_ != '\0') || (pplVar22 = pplStack_6c8, (DAT_ & 0x10) != 0)) {
      uVar16 = func_0x();
      pplVar22 = pplStack_6c8;
      puStack_6f8 = (ushort *)((ulonglong)puStack_6f8 & 0xffffffffffff0000);
      uStack_700 = (longlong *)0x0;
      uStack_708 = (longlong *)((ulonglong)uStack_708 & 0xffffffffffff0000);
      func_0x(*pplStack_6c8,uVar16);
    }
  }
  if (asStack_688[0] != 0) {
    sVar27 = 0;
    uVar7 = *(ushort *)(lVar10 + 0x16);
    lVar11 = (ulonglong)uVar7 - 1;
    if ((longlong)(ulonglong)(ushort)(uVar7 - asStack_688[0]) <= lVar11) {
      psVar14 = (short *)(lVar10 + (0xfff - lVar11) * 2);
      do {
        if (*psVar14 != 0) break;
        sVar27 = sVar27 + 1;
        lVar11 = lVar11 + -1;
        psVar14 = psVar14 + 1;
      } while ((longlong)(ulonglong)(ushort)(uVar7 - asStack_688[0]) <= lVar11);
    }
    *(ushort *)(lVar10 + 0x16) = uVar7 - sVar27;
    *(short *)(lVar10 + 0x1c) = *(short *)(lVar10 + 0x1c) + sVar27 * 2;
  }
  if (iStack_678 != 0) {
    func_0x(lVar10,0xffffffff);
  }
  if (cStack_6d8 < '\0') {
    psVar14 = ppsStack_660[1];
  }
  else {
    psVar14 = *ppsStack_660;
  }
  uStack_700 = plStack_670;
  uStack_708 = (longlong *)CONCAT62(uStack_708._2_6_,auStack_6d4[0]);
  func_0x(lVar10,param_5,psVar14,uStack_684);
  if (((*(short *)(lVar10 + 0x30) != sStack_550) || (*(int *)(lVar10 + 0x28) != (int)uStack_558)) ||
     (*(int *)(lVar10 + 0x2c) != uStack_558._4_4_)) {
    *(longlong *)(lVar10 + 0x28) = uStack_558;
    *(short *)(lVar10 + 0x30) = sStack_550;
    *(ushort *)(lVar10 + 4) = *(ushort *)(lVar10 + 4) & 0xffdf;
  }
  uStack_608 = 0;
  uStack_600 = 0;
  func_0x(_DAT_,*pplVar22,0,&uStack_608);
  lVar11 = lStack_648;
  if ((DAT_ & 2) != 0) {
    LOCK();
    *(uint *)((longlong)*pplVar22 + 100) = *(uint *)((longlong)*pplVar22 + 100) & 0xffffffef;
    UNLOCK();
  }
  lVar17 = (longlong)param_9;
  iVar9 = 0;
  if (param_9 != 0) {
    func_0x(*(undefined8 *)(lStack_648 + 8));
    func_0x(*(undefined8 *)(lVar11 + 8),lVar17);
    pplVar22 = pplStack_6c8;
    if (iStack_640 != 0) {
      func_0x(*(longlong *)(lStack_648 + 8) + 0x630,2);
      iStack_640 = 0;
    }
    lStack_648 = 0;
  }
  if (iVar31 == 0) {
    lVar11 = (ulonglong)*(ushort *)(lVar10 + 0x16) - 1;
    if (-1 < lVar11) {
      psVar14 = (short *)(lVar10 + (0xfff - lVar11) * 2);
      iVar9 = 0;
      do {
        if (*psVar14 != 0) break;
        iVar9 = iVar9 + 1;
        psVar14 = psVar14 + 1;
        lVar11 = lVar11 + -1;
      } while (-1 < lVar11);
    }
    if (uVar18 == 0) {
      uStack_700 = (longlong *)
                   CONCAT44(uStack_700._4_4_,(uint)*(ushort *)(lVar10 + 0x1c) + iVar9 * 2);
      uStack_708 = (longlong *)CONCAT44(uStack_708._4_4_,iStack_650);
      func_0x(pplVar22,&uStack_658,plVar15,1);
    }
  }
LAB_:
  if (lStack_648 != 0) {
    if (iStack_640 != 0) {
      func_0x(*(longlong *)(lStack_648 + 8) + 0x630,2);
      iStack_640 = 0;
    }
    lStack_648 = 0;
  }
  func_0x(uStack_40 ^ (ulonglong)auStack_728);
  return;
code_r0x0010123e:
  *puVar1 = *puVar1 | 1;
  uVar7 = psVar14[0xe] - 1;
  psVar14[0xe] = uVar7;
  if ((uVar7 == 0) ||
     (uVar19 = (uint)uVar7, -1 < *(short *)((longlong)puVar29 + (ulonglong)(uVar7 - 1) * 2 + 2)))
  goto LAB_;
  goto LAB_;
code_r0x001019b5:
  *puVar1 = *puVar1 | 1;
  uVar7 = psVar14[0xe] - 1;
  psVar14[0xe] = uVar7;
  if ((uVar7 == 0) ||
     (uVar19 = (uint)uVar7, -1 < *(short *)((longlong)puVar29 + (ulonglong)(uVar7 - 1) * 2 + 2)))
  goto LAB_;
  goto LAB_;
}

