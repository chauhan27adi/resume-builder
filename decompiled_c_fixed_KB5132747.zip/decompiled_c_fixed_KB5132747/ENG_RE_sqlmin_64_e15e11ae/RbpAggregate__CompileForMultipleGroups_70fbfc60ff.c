
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(int param_1,int param_2,char param_3,char param_4)

{
  int iVar1;
  undefined8 uVar2;
  
  if (param_4 != '\0') {
    switch(param_1) {
    case 1:
      uVar2 = 0x103f60;
      if (param_3 != '\0') {
        uVar2 = 0x104220;
      }
      return uVar2;
    case 2:
      uVar2 = 0x104000;
      if (param_3 != '\0') {
        uVar2 = 0x1042e0;
      }
      return uVar2;
    case 3:
      uVar2 = 0x104440;
      if (param_3 != '\0') {
        uVar2 = 0x1043a0;
      }
      return uVar2;
    case 4:
      uVar2 = 0x104140;
      if (param_3 != '\0') {
        uVar2 = 0x104590;
      }
      return uVar2;
    case 5:
      uVar2 = 0x1040a0;
      if (param_3 != '\0') {
        uVar2 = 0x1044e0;
      }
      return uVar2;
    default:
      (*_DAT_)(1,0x18192b0,0x181c500,0x264,0x1412f20);
      return 0;
    case 7:
      goto LAB_;
    }
  }
  if (param_2 < 0x11) {
    iVar1 = 2;
  }
  else {
    iVar1 = 8;
    if (param_2 < 0x21) {
      iVar1 = 4;
    }
  }
  if (param_1 != 7) {
    if (iVar1 != 2) {
      if (iVar1 == 4) {
        if (param_1 == 1) {
          return 0x103ca0;
        }
        if (param_1 == 2) {
          return 0x103d50;
        }
        if (param_1 == 4) {
          return 0x103e90;
        }
        if (param_1 != 5) {
          (*_DAT_)(1,0x18192b0,0x181c500,0x202,0x1412f20);
          return 0;
        }
        return 0x103e00;
      }
      if (iVar1 != 8) {
        (*_DAT_)(1,0x18192b0,0x181c500,0x218,0x1412f20);
        return 0;
      }
      if (param_1 == 1) {
        return 0x103f60;
      }
      if (param_1 == 2) {
        return 0x104000;
      }
      if (param_1 != 4) {
        if (param_1 != 5) {
          (*_DAT_)(1,0x18192b0,0x181c500,0x213,0x1412f20);
          return 0;
        }
        return 0x1040a0;
      }
      return 0x104140;
    }
    if (param_1 == 1) {
      return 0x1039d0;
    }
    if (param_1 == 2) {
      return 0x103a80;
    }
    if (param_1 == 4) {
      return 0x103bc0;
    }
    if (param_1 == 5) {
      return 0x103b30;
    }
    (*_DAT_)(1,0x18192b0,0x181c500,0x1f1,0x1412f20);
  }
LAB_:
  return 0;
}

