
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(longlong param_1,short *param_2)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  longlong *in_RAX;
  uint *puVar9;
  longlong lVar10;
  undefined8 uVar11;
  uint *puVar12;
  uint *puVar13;
  short sVar14;
  uint uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  uint *puVar18;
  uint uVar19;
  ulonglong uVar20;
  byte *pbVar21;
  uint uVar22;
  ushort *puVar23;
  uint *puVar24;
  undefined4 auStackX_8 [2];
  uint auStackX_18 [2];
  undefined auStackX_20 [8];
  undefined auStack_48 [8];
  undefined auStack_40 [8];
  
  puVar18 = (uint *)0x0;
  lVar10 = *(longlong *)(param_1 + 8);
  uVar6 = 0;
  auStackX_8[0] = 0;
  if ((((*(byte *)(lVar10 + 0x41) & 8) == 0) && ((*(byte *)(lVar10 + 0x108) & 0x40) == 0)) ||
     (in_RAX = *(longlong **)(lVar10 + 0x160), in_RAX == (longlong *)0x0)) {
LAB_:
    return (ulonglong)in_RAX & 0xffffffffffffff00;
  }
  lVar10 = *in_RAX;
  uVar15 = *(uint *)(lVar10 + 100);
  in_RAX = (longlong *)(ulonglong)uVar15;
  if (uVar15 == 0xffffffff) goto LAB_;
  puVar9 = *(uint **)(lVar10 + 8);
  if (uVar15 < *puVar9) {
    uVar17 = (ulonglong)uVar15 / (ulonglong)puVar9[9];
    uVar16 = (ulonglong)uVar15 % (ulonglong)puVar9[9];
    puVar9 = *(uint **)(puVar9 + 4);
  }
  else {
    uVar17 = (ulonglong)(uVar15 - *puVar9) / (ulonglong)puVar9[0x11];
    uVar16 = (ulonglong)(uVar15 - *puVar9) % (ulonglong)puVar9[0x11];
    puVar9 = *(uint **)(puVar9 + 0xc);
  }
  puVar24 = (uint *)(uVar16 * 0x1c0 + *(longlong *)(puVar9 + uVar17 * 2));
  if (puVar24 == (uint *)0x0) goto LAB_;
  bVar4 = *(byte *)(puVar24 + 8);
  puVar1 = (ushort *)(param_2 + 1);
  if (*param_2 == 0) {
    uVar15 = *puVar24;
    puVar9 = (uint *)(ulonglong)(uVar15 & 0xc0000000);
    if ((uVar15 & 0xc0000000) == 0x80000000) {
      puVar9 = (uint *)func_0x(puVar1);
      puVar13 = (uint *)0x0;
      if ((int)puVar9 != 0) {
        puVar9 = (uint *)func_0x(param_2 + 0x15,puVar24,auStackX_8,auStackX_20);
        puVar13 = puVar9;
      }
    }
    else {
      if (((bVar4 & 2) != 0) || ((*(byte *)((longlong)puVar24 + 6) & 0x10) != 0)) {
        pbVar21 = *(byte **)(param_2 + 4);
        if ((*pbVar21 & 0x10) == 0) {
          if ((1 << (*pbVar21 & 0xe) & 0x1105U) != 0) goto LAB_;
          puVar9 = (uint *)0x1;
LAB_:
          if ((bVar4 & 2) != 0) goto LAB_;
        }
        else {
          uVar19 = *(uint *)(param_2 + 8);
          if ((int)uVar19 <= (int)uVar15) {
LAB_:
            uVar6 = ~(*(ushort *)((longlong)puVar24 + 6) >> 4) & 1;
            puVar9 = puVar18;
            goto LAB_;
          }
          puVar9 = (uint *)(ulonglong)*(ushort *)(pbVar21 + uVar19);
          if ((uint)*(ushort *)(pbVar21 + uVar19) < (uint)*(ushort *)(puVar24 + 1))
          goto LAB_;
          if ((bVar4 & 2) == 0) goto LAB_;
          uVar22 = *(ushort *)(puVar24 + 1) - 1;
          puVar9 = (uint *)0x1;
          uVar6 = pbVar21[(ulonglong)(uVar22 >> 3) + (ulonglong)uVar19 + 2] >> ((byte)uVar22 & 7) &
                  1;
LAB_:
          puVar13 = puVar18;
          if (uVar6 != 0) goto LAB_;
        }
        if (((int)puVar9 == 0) && ((*(byte *)((longlong)puVar24 + 6) & 0x10) != 0)) {
          puVar9 = (uint *)(ulonglong)**(uint **)(puVar24 + 2);
          puVar13 = *(uint **)(puVar24 + 2) + 1;
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar15 < 0) {
        if (*(int *)(param_2 + 2) == 0) {
          pbVar21 = *(byte **)(param_2 + 4);
          uVar15 = *(uint *)(param_2 + 8);
          uVar17 = (ulonglong)uVar15;
          *puVar1 = 0;
          *(uint *)(param_2 + 10) = uVar15;
          bVar4 = *pbVar21;
          if ((bVar4 & 0x10) != 0) {
            uVar15 = uVar15 + 2 + (*(ushort *)(pbVar21 + uVar17) + 7 >> 3);
            uVar17 = (ulonglong)uVar15;
            *(uint *)(param_2 + 10) = uVar15;
            bVar4 = *pbVar21;
          }
          if ((bVar4 & 0x20) == 0) {
            *(int *)(param_2 + 2) = (int)uVar17;
            param_2[0xe] = 0;
            *(int *)(param_2 + 0xc) = (int)uVar17;
          }
          else {
            puVar23 = (ushort *)(pbVar21 + uVar17);
            uVar6 = *puVar23;
            param_2[0xe] = uVar6;
            if (uVar6 == 0) {
              cVar5 = func_0x(0x1f15480);
              if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
                 (*(char *)(lVar10 + 0x499) != '\0')) {
                cVar5 = func_0x(0x1f15480);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x1804e8c,0x1924f78,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),3);
              uVar17 = (ulonglong)*(uint *)(param_2 + 10);
              uVar6 = param_2[0xe];
            }
            uVar15 = (int)uVar17 + (uVar6 + 1) * 2;
            *(uint *)(param_2 + 0xc) = uVar15;
            if (0x1f9e < uVar15) {
              cVar5 = func_0x(0x1f15480);
              if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
                 (*(char *)(lVar10 + 0x499) != '\0')) {
                cVar5 = func_0x(0x1f15480);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x1804e8c,0x1924f78,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar6 = param_2[0xe];
              uVar15 = *(uint *)(param_2 + 0xc);
            }
            uVar17 = (ulonglong)uVar6;
            uVar6 = puVar23[uVar17];
            *(uint *)(param_2 + 2) = uVar6 & 0x7fff;
            if ((uVar6 & 0x7fff) < uVar15) {
              cVar5 = func_0x(0x1f15480);
              if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
                 (*(char *)(lVar10 + 0x499) != '\0')) {
                cVar5 = func_0x(0x1f15480);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x1804e8c,0x1924f78,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar15 = *(uint *)(param_2 + 0xc);
              uVar17 = (ulonglong)(ushort)param_2[0xe];
            }
            puVar9 = puVar18;
            puVar3 = puVar23;
            if ((short)uVar17 != 0) {
              do {
                uVar19 = puVar3[1] & 0x7fff;
                if ((uVar19 < uVar15) || (*(uint *)(param_2 + 2) < uVar19)) {
                  cVar5 = func_0x(0x1f15480);
                  if ((cVar5 != '\0') &&
                     ((lVar10 = func_0x(), lVar10 != 0 &&
                      (*(char *)(lVar10 + 0x499) != '\0')))) {
                    cVar5 = func_0x(0x1f15480);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x1804e8c,0x1924f78,0x82a,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 4),4);
                }
                uVar17 = (ulonglong)(ushort)param_2[0xe];
                uVar22 = (int)puVar9 + 1;
                puVar9 = (uint *)(ulonglong)uVar22;
                puVar3 = puVar3 + 1;
                uVar15 = uVar19;
              } while ((int)uVar22 < (int)(uint)(ushort)param_2[0xe]);
            }
            if ((short)puVar23[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
              pbVar21 = *(byte **)(param_2 + 4);
              do {
                uVar15 = *(ushort *)(pbVar21 + uVar17 * 2 + (ulonglong)*(uint *)(param_2 + 10)) &
                         0x7fff;
                if ((int)uVar17 == 1) {
                  uVar19 = *(uint *)(param_2 + 0xc);
                  uVar22 = uVar19;
LAB_:
                  if ((uVar15 < uVar19) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
                }
                else {
                  uVar22 = *(uint *)(param_2 + 0xc);
                  uVar19 = *(ushort *)
                            (pbVar21 + uVar17 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                           0x7fff;
                  if (uVar22 <= uVar19) goto LAB_;
LAB_:
                  func_0x(pbVar21,7);
                  uVar22 = *(uint *)(param_2 + 0xc);
                }
                if ((uVar19 < uVar22) || (*(uint *)(param_2 + 2) < uVar19)) goto LAB_;
                pbVar21 = *(byte **)(param_2 + 4);
                if (*(ushort *)(pbVar21 + uVar19) == 5) {
                  *puVar1 = *puVar1 | 2;
                  param_2[0xe] = param_2[0xe] + -1;
                  uVar16 = (ulonglong)(uVar19 & 0xffff);
                  param_2[0x15] = (short)uVar19;
                  uVar17 = *(ulonglong *)(param_2 + 4);
                  uVar6 = param_2[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar16 + 2 + uVar17) >> 0xe & 1) != 0) {
                    uVar6 = *(ushort *)(uVar16 + 2 + uVar17) & 0x3800 | param_2[0x16] & 0xc7ffU;
                  }
                  param_2[0x16] = uVar6;
                  uVar7 = (uVar6 ^ *(ushort *)(uVar16 + 2 + uVar17)) & 0x7ff ^ uVar6;
                  param_2[0x16] = uVar7;
                  uVar20 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar17 + (uVar6 >> 0xb & 7) * 2 +
                           uVar16;
                  if (uVar20 < uVar16 + uVar17) {
                    func_0x(uVar16 + uVar17,0x19);
                    uVar7 = param_2[0x16];
                    uVar16 = (ulonglong)(ushort)param_2[0x15];
                    uVar17 = (ulonglong)*(uint *)(param_2 + 4);
                  }
                  if (uVar15 - uVar19 <
                      (((uVar7 & 0x7ff) * 2 - (int)uVar16) - (int)uVar17) + (int)uVar20) {
                    func_0x(uVar16 + *(longlong *)(param_2 + 4),0x19);
                    uVar7 = param_2[0x16];
                  }
                  if (((uVar7 & 0x3800) != 0) &&
                     (puVar23 = (ushort *)
                                (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                     (uVar7 & 0x3800) != 0)) {
                    do {
                      if ((uVar7 & 0x7ff) < (*puVar23 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)param_2[0x15] +
                                        *(longlong *)(param_2 + 4),0x1a);
                        uVar7 = param_2[0x16];
                      }
                      uVar15 = (int)puVar18 + 1;
                      puVar18 = (uint *)(ulonglong)uVar15;
                      puVar23 = puVar23 + 1;
                    } while ((int)uVar15 < (int)(uVar7 >> 0xb & 7));
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar21 + uVar19) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar6 = param_2[0xe] - 1;
                param_2[0xe] = uVar6;
                if (uVar6 == 0) goto LAB_;
                uVar17 = (ulonglong)uVar6;
              } while ((short)puVar23[(ulonglong)(uVar6 - 1) + 1] < 0);
              uVar17 = (ulonglong)*(uint *)(param_2 + 2);
            }
            else {
LAB_:
              pbVar21 = *(byte **)(param_2 + 4);
              uVar17 = (ulonglong)*(uint *)(param_2 + 2);
            }
          }
          if ((*pbVar21 & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0x13) = 0;
          }
          else {
            *(int *)(param_2 + 0x13) = (int)uVar17;
            *(int *)(param_2 + 2) = (int)uVar17 + 0xe;
            uVar11 = func_0x(puVar1);
            func_0x(uVar11,auStack_40);
            iVar8 = func_0x(auStack_40);
            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar8;
            uVar17 = (ulonglong)*(uint *)(param_2 + 2);
          }
          iVar8 = (int)uVar17;
          if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
             (*(ulonglong *)(param_2 + 0xf) < uVar17 + *(longlong *)(param_2 + 4))) {
            cVar5 = func_0x(0x1f15480);
            if ((cVar5 != '\0') &&
               ((lVar10 = func_0x(), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              cVar5 = func_0x(0x1f15480);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x1804e8c,0x1924f78,0x886,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),0x12);
            iVar8 = *(int *)(param_2 + 2);
          }
          if (0x3f3b < iVar8 - 1U) {
            cVar5 = func_0x(0x1f15480);
            if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
               (*(char *)(lVar10 + 0x499) != '\0')) {
              cVar5 = func_0x(0x1f15480);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x1804e8c,0x1924f78,0x88b,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),5);
          }
        }
LAB_:
        sVar14 = -*(short *)puVar24;
        if ((*(byte *)((longlong)puVar24 + 6) & 0x10) != 0) {
          bVar4 = **(byte **)(param_2 + 4);
          if ((bVar4 & 0x10) == 0) {
            if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar9 = *(uint **)(puVar24 + 2);
              puVar13 = *(uint **)(puVar24 + 2) + 1;
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_2 + 8) <= (int)*puVar24) ||
                  (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
                   *(ushort *)(puVar24 + 1))) goto LAB_;
        }
        puVar9 = (uint *)(ulonglong)(ushort)param_2[0xe];
        puVar13 = *(uint **)(param_2 + 4);
        lVar10 = (longlong)sVar14;
        if ((uint)(int)sVar14 <= (uint)(ushort)param_2[0xe]) {
          uVar15 = *(uint *)(param_2 + 10);
          if (sVar14 == 1) {
            uVar6 = *(ushort *)((longlong)puVar13 + lVar10 * 2 + (ulonglong)uVar15);
            uVar15 = *(uint *)(param_2 + 0xc);
LAB_:
            if (((uVar6 & 0x7fff) < uVar15) || (*(uint *)(param_2 + 2) < (uVar6 & 0x7fff)))
            goto LAB_;
          }
          else {
            uVar6 = *(ushort *)((longlong)puVar13 + lVar10 * 2 + (ulonglong)uVar15);
            uVar15 = *(ushort *)((longlong)puVar13 + lVar10 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
            puVar13 = *(uint **)(param_2 + 4);
            if (*(uint *)(param_2 + 0xc) <= uVar15) goto LAB_;
LAB_:
            func_0x(puVar13,7);
            puVar13 = *(uint **)(param_2 + 4);
          }
          puVar9 = (uint *)(ulonglong)uVar15;
          puVar13 = (uint *)((longlong)puVar13 + (longlong)puVar9);
        }
      }
      else {
        uVar6 = *(ushort *)((longlong)puVar24 + 6);
        if ((uVar6 & 8) == 0) {
          if ((uVar6 & 0x10) != 0) {
            bVar4 = **(byte **)(param_2 + 4);
            puVar9 = (uint *)0x0;
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar9 = *(uint **)(puVar24 + 2);
                puVar13 = puVar9 + 1;
                if ((*(ushort *)(puVar24 + 0xe) != 0) &&
                   (*puVar9 != (uint)*(ushort *)(puVar24 + 0xe))) {
                  puVar9 = (uint *)(*_DAT_)(1,0x19b32d0,0x19b1c38,0x381,0);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_2 + 8) <= (int)uVar15) ||
                    (puVar9 = (uint *)(ulonglong)*(ushort *)(puVar24 + 1),
                    *(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) <
                    *(ushort *)(puVar24 + 1))) goto LAB_;
          }
          puVar13 = (uint *)((longlong)(int)*puVar24 + *(longlong *)(param_2 + 4));
        }
        else {
          puVar9 = (uint *)0x1589b21;
          puVar13 = (uint *)0x1589b20;
          if ((*(byte *)(*(longlong *)(param_2 + 4) + (longlong)(int)uVar15) &
              (byte)(1 << ((byte)uVar6 & 7))) == 0) {
            puVar13 = (uint *)0x1589b21;
          }
        }
      }
    }
  }
  else {
    auStackX_18[0] = 0;
    puVar12 = (uint *)func_0x(puVar1,puVar24,uVar16,auStackX_8,auStackX_18);
    puVar9 = puVar12;
    puVar13 = puVar12;
    if (((((*param_2 != 0) && (plVar2 = *(longlong **)(param_2 + 8), plVar2 != (longlong *)0x0)) &&
         ((*plVar2 != 0 &&
          (((*(byte *)((longlong)puVar24 + 6) & 8) == 0 && ((auStackX_18[0] & 1) == 0)))))) &&
        (puVar9 = puVar18, puVar13 = puVar18, puVar12 != (uint *)0x0)) &&
       (puVar12 != (uint *)0x1589b20)) {
      puVar9 = (uint *)func_0x
                                 (plVar2,puVar24,puVar12,auStackX_8[0],auStack_48,4,auStackX_8,
                                  auStackX_18[0]);
      puVar13 = puVar9;
    }
  }
LAB_:
  if (puVar13 != (uint *)0x0) {
    return (ulonglong)*(byte *)puVar13;
  }
LAB_:
  return (ulonglong)puVar9 & 0xffffffffffffff00;
}

