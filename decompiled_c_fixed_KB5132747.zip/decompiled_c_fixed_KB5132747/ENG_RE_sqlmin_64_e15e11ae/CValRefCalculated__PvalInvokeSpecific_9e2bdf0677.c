
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 * FUN_(longlong param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  longlong lVar2;
  int iVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  
  uVar4 = func_0x();
  if (uVar4 < 0x20000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar3 = (*(int *)(param_1 + 0x54) << 0x1c) >> 0x1c;
  if (iVar3 == 2) {
    if (**(char **)(param_1 + 0x40) != '\x03') {
      puVar5 = (undefined8 *)(param_1 + 0x28);
      if (param_1 == 0x20) {
        puVar5 = (undefined8 *)0x0;
      }
      return puVar5;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (iVar3 == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar5 = (undefined8 *)(*_DAT_)(0x10,*param_2,0x2571748,0x6bd,1);
  if (puVar5 != (undefined8 *)0x0) {
    uVar1 = *(undefined8 *)(param_1 + 0x40);
    lVar2 = param_2[0x33];
    *puVar5 = 0x252d990;
    (*_DAT_)(lVar2,uVar1,*(longlong *)(lVar2 + 0x1a8) + 0x138,puVar5 + 1);
    return puVar5;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

