
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_(short *param_1,uint *param_2,undefined8 param_3,int param_4,int *param_5,
                  int **param_6,int *param_7,undefined8 param_8,undefined4 param_9)

{
  longlong *plVar1;
  bool bVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  ushort uVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  longlong lVar10;
  undefined8 uVar11;
  longlong lVar12;
  uint uVar13;
  short sVar14;
  uint uVar15;
  ulonglong uVar16;
  uint uVar17;
  ushort *puVar18;
  ushort *puVar19;
  ulonglong uVar20;
  byte *pbVar21;
  longlong lVar22;
  ulonglong uVar23;
  int iVar24;
  ushort *puStackX_8;
  undefined auStack_38 [8];
  undefined auStack_30 [8];
  
  if (*param_1 != 0) {
    if (*param_1 != 1) {
      (*_DAT_)(1,0xb7b4e0,0xbd7588,0xd3,0x775150);
      return (int *)0x0;
    }
    puStackX_8 = (ushort *)((ulonglong)puStackX_8 & 0xffffffff00000000);
    piVar8 = (int *)func_0x(param_1 + 1,param_2,param_3,param_5,&puStackX_8);
    if ((((*param_1 != 0) && (plVar1 = *(longlong **)(param_1 + 8), plVar1 != (longlong *)0x0)) &&
        (*plVar1 != 0)) &&
       (((*(byte *)((longlong)param_2 + 6) & 8) == 0 && (((ulonglong)puStackX_8 & 1) == 0)))) {
      if ((piVar8 == (int *)0x0) || (piVar8 == (int *)0x77e880)) {
        *param_5 = 0;
        piVar8 = (int *)0x0;
      }
      else {
        piVar8 = (int *)func_0x
                                  (plVar1,param_2,piVar8,*param_5,param_8,param_9,param_5,
                                   puStackX_8._0_4_);
      }
    }
    piVar9 = (int *)func_0x(param_1 + 1,param_2);
    *param_6 = piVar9;
    return piVar8;
  }
  uVar15 = *param_2;
  if ((uVar15 & 0xc0000000) == 0x80000000) {
    iVar7 = func_0x(param_1 + 1);
    if (iVar7 != 0) {
      piVar8 = (int *)func_0x(param_1 + 0x15,param_2,param_5,auStack_38);
      goto LAB_;
    }
LAB_:
    piVar8 = (int *)0x0;
    *param_5 = 0;
    goto LAB_;
  }
  iVar7 = 0;
  uVar5 = 0;
  bVar2 = true;
  if ((param_4 != 0) || ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
    pbVar21 = *(byte **)(param_1 + 4);
    if ((*pbVar21 & 0x10) == 0) {
      if ((1 << (*pbVar21 & 0xe) & 0x1105U) != 0) goto LAB_;
LAB_:
      if (param_4 != 0) goto LAB_;
    }
    else {
      uVar17 = *(uint *)(param_1 + 8);
      if ((int)uVar17 <= (int)uVar15) {
LAB_:
        uVar5 = ~(*(ushort *)((longlong)param_2 + 6) >> 4) & 1;
        bVar2 = false;
        goto LAB_;
      }
      if ((uint)*(ushort *)(pbVar21 + uVar17) < (uint)*(ushort *)(param_2 + 1)) goto LAB_;
      if (param_4 == 0) goto LAB_;
      uVar13 = *(ushort *)(param_2 + 1) - 1;
      uVar5 = pbVar21[(ulonglong)uVar17 + (ulonglong)(uVar13 >> 3) + 2] >> ((byte)uVar13 & 7) & 1;
LAB_:
      if (uVar5 != 0) goto LAB_;
    }
    if ((bVar2) || ((*(byte *)((longlong)param_2 + 6) & 0x10) == 0)) goto LAB_;
    goto LAB_;
  }
LAB_:
  if (-1 < (int)uVar15) {
    uVar5 = *(ushort *)((longlong)param_2 + 6);
    if ((uVar5 & 8) != 0) {
      piVar8 = (int *)0x77e880;
      bVar3 = *(byte *)((longlong)(int)uVar15 + *(longlong *)(param_1 + 4));
      *param_5 = 1;
      if ((bVar3 & (byte)(1 << ((byte)uVar5 & 7))) == 0) {
        piVar8 = (int *)0x77e881;
      }
      goto LAB_;
    }
    iVar7 = (int)param_3;
    if ((uVar5 & 0x10) != 0) {
      bVar3 = **(byte **)(param_1 + 4);
      if ((bVar3 & 0x10) == 0) {
        if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
          iVar24 = **(int **)(param_2 + 2);
          piVar8 = *(int **)(param_2 + 2) + 1;
          if ((iVar7 != 0) && (iVar24 != iVar7)) {
            (*_DAT_)(1,0xba8030,0xba6998,0x381,0);
          }
          *param_5 = iVar24;
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uVar15) ||
              (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
               *(ushort *)(param_2 + 1))) goto LAB_;
    }
    *param_5 = iVar7;
    piVar8 = (int *)((longlong)(int)*param_2 + *(longlong *)(param_1 + 4));
    goto LAB_;
  }
  if (*(int *)(param_1 + 2) == 0) {
    pbVar21 = *(byte **)(param_1 + 4);
    uVar15 = *(uint *)(param_1 + 8);
    uVar16 = (ulonglong)uVar15;
    param_1[1] = 0;
    *(uint *)(param_1 + 10) = uVar15;
    bVar3 = *pbVar21;
    if ((bVar3 & 0x10) != 0) {
      uVar15 = uVar15 + 2 + (*(ushort *)(pbVar21 + uVar16) + 7 >> 3);
      uVar16 = (ulonglong)uVar15;
      *(uint *)(param_1 + 10) = uVar15;
      bVar3 = *pbVar21;
    }
    if ((bVar3 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar16;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar16;
    }
    else {
      puVar18 = (ushort *)(pbVar21 + uVar16);
      uVar5 = *puVar18;
      param_1[0xe] = uVar5;
      puStackX_8 = puVar18;
      if (uVar5 == 0) {
        cVar4 = func_0x(0x110a1e0);
        if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar4 = func_0x(0x110a1e0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9f9bec,0xb19cd8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar16 = (ulonglong)*(uint *)(param_1 + 10);
        uVar5 = param_1[0xe];
      }
      uVar15 = (int)uVar16 + (uVar5 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar15;
      if (0x1f9e < uVar15) {
        cVar4 = func_0x(0x110a1e0);
        if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar4 = func_0x(0x110a1e0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9f9bec,0xb19cd8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar5 = param_1[0xe];
        uVar15 = *(uint *)(param_1 + 0xc);
      }
      uVar16 = (ulonglong)uVar5;
      uVar5 = puVar18[uVar16];
      *(uint *)(param_1 + 2) = uVar5 & 0x7fff;
      if ((uVar5 & 0x7fff) < uVar15) {
        cVar4 = func_0x(0x110a1e0);
        if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
           (*(char *)(lVar10 + 0x499) != '\0')) {
          cVar4 = func_0x(0x110a1e0);
          if (cVar4 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9f9bec,0xb19cd8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar15 = *(uint *)(param_1 + 0xc);
        uVar16 = (ulonglong)(ushort)param_1[0xe];
      }
      puVar19 = puVar18;
      iVar24 = iVar7;
      if ((short)uVar16 != 0) {
        do {
          puVar18 = puVar18 + 1;
          uVar17 = *puVar18 & 0x7fff;
          if ((uVar17 < uVar15) || (*(uint *)(param_1 + 2) < uVar17)) {
            cVar4 = func_0x(0x110a1e0);
            if ((cVar4 != '\0') &&
               ((lVar10 = func_0x(), lVar10 != 0 &&
                (*(char *)(lVar10 + 0x499) != '\0')))) {
              cVar4 = func_0x(0x110a1e0);
              if (cVar4 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9f9bec,0xb19cd8,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
          }
          uVar16 = (ulonglong)(ushort)param_1[0xe];
          iVar24 = iVar24 + 1;
          puVar19 = puStackX_8;
          uVar15 = uVar17;
        } while (iVar24 < (int)(uint)(ushort)param_1[0xe]);
      }
      puVar18 = puStackX_8;
      if ((short)puVar19[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
        pbVar21 = *(byte **)(param_1 + 4);
        do {
          uVar15 = *(ushort *)(pbVar21 + uVar16 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff;
          if ((int)uVar16 == 1) {
            uVar17 = *(uint *)(param_1 + 0xc);
            uVar13 = uVar17;
LAB_:
            if ((uVar15 < uVar17) || (*(uint *)(param_1 + 2) < uVar15)) goto LAB_;
          }
          else {
            uVar13 = *(uint *)(param_1 + 0xc);
            uVar17 = *(ushort *)(pbVar21 + uVar16 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
                     0x7fff;
            if (uVar13 <= uVar17) goto LAB_;
LAB_:
            func_0x(pbVar21,7);
            uVar13 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar17 < uVar13) || (*(uint *)(param_1 + 2) < uVar17)) goto LAB_;
          pbVar21 = *(byte **)(param_1 + 4);
          if (*(ushort *)(pbVar21 + uVar17) == 5) {
            param_1[1] = param_1[1] | 2;
            param_1[0xe] = param_1[0xe] + -1;
            uVar23 = (ulonglong)(uVar17 & 0xffff);
            uVar6 = param_1[0x16] & 0xc7ff;
            param_1[0x15] = (short)uVar17;
            uVar16 = *(ulonglong *)(param_1 + 4);
            uVar5 = *(ushort *)(uVar16 + 2 + uVar23);
            if ((uVar5 >> 0xe & 1) != 0) {
              uVar6 = uVar5 & 0x3800 | uVar6;
            }
            param_1[0x16] = uVar6;
            uVar5 = (uVar6 ^ *(ushort *)(uVar23 + 2 + uVar16)) & 0x7ff ^ uVar6;
            param_1[0x16] = uVar5;
            uVar20 = uVar16 + 4 + (ulonglong)((uVar5 & 0x7ff) * 2) + uVar23 + (uVar6 >> 0xb & 7) * 2
            ;
            if (uVar20 < uVar23 + uVar16) {
              func_0x(uVar23 + uVar16,0x19);
              uVar5 = param_1[0x16];
              uVar23 = (ulonglong)(ushort)param_1[0x15];
              uVar16 = (ulonglong)*(uint *)(param_1 + 4);
            }
            if (uVar15 - uVar17 < (((uVar5 & 0x7ff) * 2 - (int)uVar23) - (int)uVar16) + (int)uVar20)
            {
              func_0x(uVar23 + *(longlong *)(param_1 + 4),0x19);
              uVar5 = param_1[0x16];
            }
            if (((uVar5 & 0x3800) != 0) &&
               (puVar18 = (ushort *)
                          (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
               (uVar5 & 0x3800) != 0)) {
              do {
                if ((uVar5 & 0x7ff) < (*puVar18 & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),0x1a
                                 );
                  uVar5 = param_1[0x16];
                }
                iVar7 = iVar7 + 1;
                puVar18 = puVar18 + 1;
              } while (iVar7 < (int)(uVar5 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar21 + uVar17) < 0x400) goto LAB_;
          param_1[1] = param_1[1] | 1;
          uVar5 = param_1[0xe] - 1;
          param_1[0xe] = uVar5;
          if (uVar5 == 0) goto LAB_;
          uVar16 = (ulonglong)uVar5;
        } while ((short)puVar18[(ulonglong)(uVar5 - 1) + 1] < 0);
        uVar16 = (ulonglong)*(uint *)(param_1 + 2);
      }
      else {
LAB_:
        pbVar21 = *(byte **)(param_1 + 4);
        uVar16 = (ulonglong)*(uint *)(param_1 + 2);
      }
    }
    if ((*pbVar21 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = (int)uVar16;
      *(int *)(param_1 + 2) = (int)uVar16 + 0xe;
      uVar11 = func_0x(param_1 + 1);
      func_0x(uVar11,auStack_30);
      iVar7 = func_0x(auStack_30);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar7;
      uVar16 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar7 = (int)uVar16;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar16 + *(longlong *)(param_1 + 4))) {
      cVar4 = func_0x(0x110a1e0);
      if ((cVar4 != '\0') &&
         ((lVar10 = func_0x(), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0'))))
      {
        cVar4 = func_0x(0x110a1e0);
        if (cVar4 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9f9bec,0xb19cd8,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar7 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar7 - 1U) {
      cVar4 = func_0x(0x110a1e0);
      if (((cVar4 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
         (*(char *)(lVar10 + 0x499) != '\0')) {
        cVar4 = func_0x(0x110a1e0);
        if (cVar4 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9f9bec,0xb19cd8,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar14 = -*(short *)param_2;
  if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
    bVar3 = **(byte **)(param_1 + 4);
    if ((bVar3 & 0x10) == 0) {
      if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
        piVar8 = *(int **)(param_2 + 2) + 1;
        *param_5 = **(int **)(param_2 + 2);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)*param_2) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
             *(ushort *)(param_2 + 1))) goto LAB_;
  }
  lVar10 = (longlong)sVar14;
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar14) {
    *param_5 = 0;
    piVar8 = *(int **)(param_1 + 4);
    goto LAB_;
  }
  lVar22 = *(longlong *)(param_1 + 4);
  lVar12 = (ulonglong)*(uint *)(param_1 + 10) + lVar22;
  if (sVar14 == 1) {
    uVar15 = *(uint *)(param_1 + 0xc);
    uVar17 = *(ushort *)(lVar12 + lVar10 * 2) & 0x7fff;
LAB_:
    if ((uVar17 < uVar15) || (*(uint *)(param_1 + 2) < uVar17)) goto LAB_;
  }
  else {
    uVar15 = *(ushort *)(lVar12 + -2 + lVar10 * 2) & 0x7fff;
    lVar22 = *(longlong *)(param_1 + 4);
    uVar17 = *(ushort *)(lVar12 + lVar10 * 2) & 0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar15) goto LAB_;
LAB_:
    func_0x(lVar22,7);
  }
  *param_5 = uVar17 - uVar15;
  piVar8 = (int *)((ulonglong)uVar15 + *(longlong *)(param_1 + 4));
LAB_:
  *param_6 = piVar8;
  *param_7 = *param_5;
  return piVar8;
}

