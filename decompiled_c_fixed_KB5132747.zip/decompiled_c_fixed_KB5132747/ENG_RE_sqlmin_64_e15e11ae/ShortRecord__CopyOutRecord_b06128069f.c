
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,ulonglong param_3,short *param_4,int param_5)

{
  short *psVar1;
  short *psVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  undefined8 uVar7;
  longlong lVar8;
  byte *pbVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  ulonglong uVar13;
  undefined4 uVar14;
  short sVar15;
  ushort uVar16;
  ulonglong uVar17;
  uint uVar18;
  uint uVar19;
  ulonglong uVar20;
  int iVar21;
  ushort *puVar22;
  ulonglong uVar23;
  undefined auStack_58 [24];
  
  uVar14 = (undefined4)param_3;
  if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
    uVar7 = (**(code **)**(undefined8 **)(param_1 + 0x10))();
    param_3 = param_3 & 0xffffffff;
    *(undefined8 *)(param_1 + 8) = uVar7;
  }
  psVar2 = *(short **)(param_1 + 8);
  sVar15 = *psVar2;
  *param_4 = sVar15;
  if (sVar15 != 0) {
    if ((((param_5 == 0) || (*psVar2 == 0)) || (*(longlong **)(psVar2 + 8) == (longlong *)0x0)) ||
       (**(longlong **)(psVar2 + 8) == 0)) {
      func_0x(param_4 + 1,param_2,param_3,psVar2 + 1);
      if (*psVar2 == 0) {
        *(undefined8 *)(param_4 + 8) = 0;
      }
      else {
        *(undefined8 *)(param_4 + 8) = *(undefined8 *)(psVar2 + 8);
      }
    }
    else {
      func_0x(param_4,param_2,param_3,psVar2);
    }
    goto LAB_;
  }
  uVar18 = *(uint *)(psVar2 + 2);
  iVar10 = 0;
  psVar1 = param_4 + 1;
  if (uVar18 == 0) {
    pbVar9 = *(byte **)(psVar2 + 4);
    uVar18 = *(uint *)(psVar2 + 8);
    uVar17 = (ulonglong)uVar18;
    psVar2[1] = 0;
    *(uint *)(psVar2 + 10) = uVar18;
    bVar4 = *pbVar9;
    if ((bVar4 & 0x10) != 0) {
      uVar18 = uVar18 + 2 + (*(ushort *)(pbVar9 + uVar17) + 7 >> 3);
      uVar17 = (ulonglong)uVar18;
      *(uint *)(psVar2 + 10) = uVar18;
      bVar4 = *pbVar9;
    }
    iVar21 = (int)uVar17;
    if ((bVar4 & 0x20) == 0) {
      *(int *)(psVar2 + 2) = iVar21;
      psVar2[0xe] = 0;
      *(int *)(psVar2 + 0xc) = iVar21;
    }
    else {
      puVar22 = (ushort *)(pbVar9 + uVar17);
      uVar16 = *puVar22;
      psVar2[0xe] = uVar16;
      if (uVar16 == 0) {
        cVar5 = func_0x(0x110fe10);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x110fe10);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9ff81c,0xb1f908,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(psVar2 + 4),3);
        iVar21 = *(int *)(psVar2 + 10);
        pbVar9 = *(byte **)(psVar2 + 4);
        uVar16 = psVar2[0xe];
      }
      uVar18 = iVar21 + (uVar16 + 1) * 2;
      *(uint *)(psVar2 + 0xc) = uVar18;
      if (0x1f9e < uVar18) {
        cVar5 = func_0x(0x110fe10);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x110fe10);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ff81c,0xb1f908,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(psVar2 + 4),4);
        uVar16 = psVar2[0xe];
        pbVar9 = *(byte **)(psVar2 + 4);
        uVar18 = *(uint *)(psVar2 + 0xc);
      }
      uVar17 = (ulonglong)uVar16;
      uVar16 = puVar22[uVar17];
      *(uint *)(psVar2 + 2) = uVar16 & 0x7fff;
      if ((uVar16 & 0x7fff) < uVar18) {
        cVar5 = func_0x(0x110fe10);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x110fe10);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ff81c,0xb1f908,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(psVar2 + 4),4);
        uVar18 = *(uint *)(psVar2 + 0xc);
        uVar17 = (ulonglong)(ushort)psVar2[0xe];
        pbVar9 = *(byte **)(psVar2 + 4);
      }
      puVar3 = puVar22;
      iVar21 = iVar10;
      if ((short)uVar17 != 0) {
        do {
          uVar11 = puVar3[1] & 0x7fff;
          if ((uVar11 < uVar18) || (*(uint *)(psVar2 + 2) < uVar11)) {
            cVar5 = func_0x(0x110fe10);
            if ((cVar5 != '\0') &&
               ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x110fe10);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9ff81c,0xb1f908,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(psVar2 + 4),4);
          }
          uVar17 = (ulonglong)(ushort)psVar2[0xe];
          iVar21 = iVar21 + 1;
          puVar3 = puVar3 + 1;
          uVar18 = uVar11;
        } while (iVar21 < (int)(uint)(ushort)psVar2[0xe]);
        pbVar9 = *(byte **)(psVar2 + 4);
      }
      uVar13 = uVar17;
      if ((short)puVar22[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
        do {
          sVar15 = (short)uVar17;
          uVar11 = *(ushort *)(pbVar9 + uVar13 * 2 + (ulonglong)*(uint *)(psVar2 + 10)) & 0x7fff;
          if ((int)uVar13 == 1) {
            uVar12 = *(uint *)(psVar2 + 0xc);
            uVar19 = uVar12;
LAB_:
            if ((uVar11 < uVar12) || (uVar18 = *(uint *)(psVar2 + 2), uVar18 < uVar11))
            goto LAB_;
          }
          else {
            uVar19 = *(uint *)(psVar2 + 0xc);
            uVar12 = *(ushort *)(pbVar9 + uVar13 * 2 + ((ulonglong)*(uint *)(psVar2 + 10) - 2)) &
                     0x7fff;
            if (uVar19 <= uVar12) goto LAB_;
LAB_:
            func_0x(pbVar9,7);
            uVar19 = *(uint *)(psVar2 + 0xc);
            uVar18 = *(uint *)(psVar2 + 2);
            pbVar9 = *(byte **)(psVar2 + 4);
            sVar15 = psVar2[0xe];
          }
          if ((uVar12 < uVar19) || (uVar18 < uVar12)) goto LAB_;
          if (*(ushort *)(pbVar9 + uVar12) == 5) {
            psVar2[1] = psVar2[1] | 2;
            psVar2[0xe] = sVar15 + -1;
            uVar20 = (ulonglong)(uVar12 & 0xffff);
            uVar16 = psVar2[0x16] & 0xc7ff;
            uVar13 = *(ulonglong *)(psVar2 + 4);
            uVar17 = uVar13 + uVar20;
            psVar2[0x15] = (short)uVar12;
            if ((*(ushort *)(uVar17 + 2) >> 0xe & 1) != 0) {
              uVar16 = *(ushort *)(uVar17 + 2) & 0x3800 | uVar16;
            }
            psVar2[0x16] = uVar16;
            uVar6 = (uVar16 ^ *(ushort *)(uVar17 + 2)) & 0x7ff ^ uVar16;
            psVar2[0x16] = uVar6;
            uVar23 = uVar13 + 4 +
                     (ulonglong)((uVar6 & 0x7ff) * 2) + (uVar16 >> 0xb & 7) * 2 + uVar20;
            if (uVar23 < uVar17) {
              func_0x(uVar17,0x19);
              uVar6 = psVar2[0x16];
              uVar20 = (ulonglong)(ushort)psVar2[0x15];
              uVar13 = (ulonglong)*(uint *)(psVar2 + 4);
            }
            if (uVar11 - uVar12 < (((uVar6 & 0x7ff) * 2 - (int)uVar20) - (int)uVar13) + (int)uVar23)
            {
              func_0x(uVar20 + *(longlong *)(psVar2 + 4),0x19);
              uVar6 = psVar2[0x16];
            }
            if (((uVar6 & 0x3800) != 0) &&
               (puVar22 = (ushort *)
                          (*(longlong *)(psVar2 + 4) + 4 + (ulonglong)(ushort)psVar2[0x15]),
               iVar21 = iVar10, (uVar6 & 0x3800) != 0)) {
              do {
                if ((uVar6 & 0x7ff) < (*puVar22 & 0x7ff)) {
                  func_0x((ulonglong)(ushort)psVar2[0x15] + *(longlong *)(psVar2 + 4),0x1a);
                  uVar6 = psVar2[0x16];
                }
                iVar21 = iVar21 + 1;
                puVar22 = puVar22 + 1;
              } while (iVar21 < (int)(uVar6 >> 0xb & 7));
            }
            pbVar9 = *(byte **)(psVar2 + 4);
            goto LAB_;
          }
          if (*(ushort *)(pbVar9 + uVar12) < 0x400) goto LAB_;
          psVar2[1] = psVar2[1] | 1;
          uVar16 = sVar15 - 1;
          psVar2[0xe] = uVar16;
          if (uVar16 == 0) goto LAB_;
          uVar17 = (ulonglong)uVar16;
          uVar13 = (ulonglong)(uint)uVar16;
        } while ((short)puVar22[(ulonglong)(uVar16 - 1) + 1] < 0);
        uVar17 = (ulonglong)*(uint *)(psVar2 + 2);
      }
      else {
LAB_:
        uVar17 = (ulonglong)*(uint *)(psVar2 + 2);
      }
    }
    if ((*pbVar9 & 0x40) == 0) {
      *(undefined4 *)(psVar2 + 0x13) = 0;
    }
    else {
      *(int *)(psVar2 + 0x13) = (int)uVar17;
      *(int *)(psVar2 + 2) = (int)uVar17 + 0xe;
      uVar7 = func_0x(psVar2 + 1);
      func_0x(uVar7,auStack_58);
      iVar21 = func_0x(auStack_58);
      *(int *)(psVar2 + 2) = *(int *)(psVar2 + 2) + iVar21;
      uVar17 = (ulonglong)*(uint *)(psVar2 + 2);
      pbVar9 = *(byte **)(psVar2 + 4);
    }
    uVar18 = (uint)uVar17;
    if ((*(byte **)(psVar2 + 0xf) != (byte *)0x0) && (*(byte **)(psVar2 + 0xf) < pbVar9 + uVar17)) {
      cVar5 = func_0x(0x110fe10);
      if ((cVar5 != '\0') &&
         ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))) {
        cVar5 = func_0x(0x110fe10);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9ff81c,0xb1f908,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(psVar2 + 4),0x12);
      uVar18 = *(uint *)(psVar2 + 2);
    }
    if ((uVar18 == 0) || (0x3f3c < uVar18)) {
      cVar5 = func_0x(0x110fe10);
      if ((cVar5 != '\0') &&
         ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))) {
        cVar5 = func_0x(0x110fe10);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9ff81c,0xb1f908,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(psVar2 + 4),5);
      uVar18 = *(uint *)(psVar2 + 2);
    }
  }
LAB_:
  if ((uVar18 < 9) &&
     (((**(byte **)(psVar2 + 4) & 0xe) == 0 || ((**(byte **)(psVar2 + 4) & 0xe) == 0xc)))) {
    uVar18 = 9;
  }
  *(undefined4 *)(param_4 + 8) = *(undefined4 *)(psVar2 + 8);
  *psVar1 = psVar2[1];
  *(undefined4 *)(param_4 + 2) = *(undefined4 *)(psVar2 + 2);
  param_4[0xe] = psVar2[0xe];
  *(undefined4 *)(param_4 + 10) = *(undefined4 *)(psVar2 + 10);
  *(undefined4 *)(param_4 + 0xc) = *(undefined4 *)(psVar2 + 0xc);
  *(undefined4 *)(param_4 + 0x13) = *(undefined4 *)(psVar2 + 0x13);
  func_0x(param_2,uVar14,*(undefined8 *)(psVar2 + 4),uVar18);
  *(undefined8 *)(param_4 + 4) = param_2;
  iVar21 = func_0x(psVar1);
  if (iVar21 == 0) goto LAB_;
  puVar22 = (ushort *)((ulonglong)*(uint *)(param_4 + 10) + *(longlong *)(param_4 + 4));
  uVar18 = *puVar22 - 1;
  if ((*(byte *)psVar1 & 1) == 0) {
    uVar18 = (uint)*puVar22;
  }
  uVar11 = puVar22[(int)uVar18] & 0x7fff;
  if (uVar18 == 1) {
    uVar18 = *(uint *)(param_4 + 0xc);
LAB_:
    if ((uVar11 < uVar18) || (*(uint *)(param_4 + 2) < uVar11)) goto LAB_;
  }
  else {
    uVar18 = puVar22[(longlong)(int)uVar18 + -1] & 0x7fff;
    if (*(uint *)(param_4 + 0xc) <= uVar18) goto LAB_;
LAB_:
    func_0x(*(longlong *)(param_4 + 4),7);
  }
  uVar13 = *(ulonglong *)(param_4 + 4);
  uVar20 = (ulonglong)(uVar18 & 0xffff);
  uVar16 = param_4[0x16] & 0xc7ff;
  uVar17 = uVar20 + uVar13;
  param_4[0x15] = (short)uVar18;
  if ((*(ushort *)(uVar17 + 2) >> 0xe & 1) != 0) {
    uVar16 = *(ushort *)(uVar17 + 2) & 0x3800 | uVar16;
  }
  param_4[0x16] = uVar16;
  uVar6 = (uVar16 ^ *(ushort *)(uVar17 + 2)) & 0x7ff ^ uVar16;
  param_4[0x16] = uVar6;
  uVar23 = (ulonglong)((uVar6 & 0x7ff) * 2) + 4 + (uVar16 >> 0xb & 7) * 2 + uVar20 + uVar13;
  if (uVar23 < uVar17) {
    func_0x(uVar17,0x19);
    uVar6 = param_4[0x16];
    uVar20 = (ulonglong)(ushort)param_4[0x15];
    uVar13 = (ulonglong)*(uint *)(param_4 + 4);
  }
  if (uVar11 - uVar18 < (((uVar6 & 0x7ff) * 2 - (int)uVar20) - (int)uVar13) + (int)uVar23) {
    func_0x(uVar20 + *(longlong *)(param_4 + 4),0x19);
    uVar6 = param_4[0x16];
  }
  if (((uVar6 & 0x3800) != 0) &&
     (puVar22 = (ushort *)(*(longlong *)(param_4 + 4) + 4 + (ulonglong)(ushort)param_4[0x15]),
     (uVar6 & 0x3800) != 0)) {
    do {
      if ((uVar6 & 0x7ff) < (*puVar22 & 0x7ff)) {
        func_0x((ulonglong)(ushort)param_4[0x15] + *(longlong *)(param_4 + 4),0x1a);
        uVar6 = param_4[0x16];
      }
      iVar10 = iVar10 + 1;
      puVar22 = puVar22 + 1;
    } while (iVar10 < (int)(uVar6 >> 0xb & 7));
  }
LAB_:
  if (*param_4 == 0) {
    func_0x();
  }
  else {
    func_0x(param_4 + 1);
  }
  if (*(longlong **)(param_1 + 0x10) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x10) + 8))();
  }
  return;
}

