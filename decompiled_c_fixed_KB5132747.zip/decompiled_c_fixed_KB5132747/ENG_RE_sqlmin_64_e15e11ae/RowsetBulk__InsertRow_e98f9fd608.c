
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,longlong param_4)

{
  short *psVar1;
  undefined8 *puVar2;
  short *psVar3;
  longlong *plVar4;
  undefined2 *puVar5;
  ushort *puVar6;
  bool bVar7;
  char cVar8;
  byte bVar9;
  short sVar10;
  undefined2 uVar11;
  ushort uVar12;
  ushort uVar13;
  uint uVar14;
  undefined4 uVar15;
  int iVar16;
  undefined4 uVar17;
  longlong lVar18;
  longlong lVar19;
  longlong lVar20;
  longlong lVar21;
  undefined4 *puVar22;
  undefined *puVar23;
  undefined8 uVar24;
  undefined8 uVar25;
  ulonglong *puVar26;
  uint *puVar27;
  byte *pbVar28;
  undefined uVar29;
  undefined8 uVar30;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar31;
  longlong *plVar32;
  ulonglong uVar33;
  uint uVar34;
  uint uVar35;
  undefined8 unaff_RBX;
  ulonglong uVar36;
  uint *puVar37;
  undefined *puVar38;
  undefined *puVar39;
  int iVar40;
  int iVar41;
  undefined *puVar42;
  byte *pbVar43;
  longlong lVar44;
  byte *pbVar45;
  uint uVar46;
  uint *puVar47;
  uint uVar48;
  uint *puVar49;
  ulonglong uVar50;
  int *piVar51;
  ulonglong uVar52;
  char *pcVar53;
  uint **ppuVar54;
  ushort *puVar55;
  uint *puVar56;
  short sStackX_18;
  ushort uStackX_1a;
  uint uStackX_1c;
  uint *puStackX_20;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar18 = func_0x();
  lVar18 = -lVar18;
  puVar38 = &stack0xffffffffffffffc8 + lVar18;
  psVar3 = (short *)((longlong)&sStackX_18 + lVar18);
  *(undefined8 *)(&stack0x000057c0 + lVar18) = unaff_RBX;
  *(ulonglong *)(&stack0x00005768 + lVar18) = _DAT_ ^ (ulonglong)psVar3;
  lVar21 = 0;
  lVar44 = *(longlong *)(param_1 + 0x188);
  *(uint *)(&stack0x000001bc + lVar18) = *(uint *)(&stack0x000001bc + lVar18) & 0xfffffff8;
  *(undefined8 *)(&stack0x000001f0 + lVar18) = *(undefined8 *)(&stack0x000057d8 + lVar18);
  *psVar3 = -1;
  lVar19 = *(longlong *)(param_1 + 0x178);
  *(longlong *)(&stack0x00000070 + lVar18) = param_1;
  *(undefined8 *)((longlong)&puStackX_20 + lVar18) = 0;
  iVar16 = 0;
  *(undefined4 *)((longlong)&sStackX_18 + lVar18 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar18) = 0;
  *(undefined4 *)(&stack0x0000010c + lVar18) = 0;
  *(undefined8 *)(&stack0x00000120 + lVar18) = 0;
  *(undefined4 *)(&stack0x00000128 + lVar18) = 0;
  *(undefined8 *)(&stack0x000001f8 + lVar18) = 0x842820;
  *(undefined8 *)(&stack0x00000210 + lVar18) = 0;
  *(undefined8 *)(&stack0x000001c0 + lVar18) = 0;
  *(longlong *)(&stack0x000000a0 + lVar18) = lVar44;
  *(longlong *)(&stack0x00000178 + lVar18) = lVar19;
  *(undefined (*) [16])(&stack0x00000200 + lVar18) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000088 + lVar18) = *(undefined8 *)(lVar19 + 0xd0);
  puVar39 = &stack0xffffffffffffffc8 + lVar18;
  if (param_3 != (longlong *)0x0) {
    puVar2 = (undefined8 *)(param_1 + 0x180);
    if ((*(int *)(param_1 + 0x1a8) == *(int *)(param_3 + 1)) &&
       (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x194) * 0x10000)) {
      UNRECOVERED_JUMPTABLE = *(code **)*puVar2;
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10011d;
      sVar10 = (*UNRECOVERED_JUMPTABLE)(puVar2);
      if (*(short *)((longlong)param_3 + 0xc) != sVar10) goto LAB_;
      if (param_3[0x15] != 0) {
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar18) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar18);
        UNLOCK();
      }
    }
    else {
LAB_:
      *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x10013e;
      func_0x(param_3,puVar2);
    }
    uVar13 = *(ushort *)(param_3 + 7);
    uVar12 = *(ushort *)((longlong)param_3 + 0x62);
    uVar31 = (uint)uVar12;
    if ((uVar13 & 0x400) == 0) {
      *(longlong *)(&stack0x00000100 + lVar18) = param_3[0xe];
      *(longlong **)(&stack0x000000f8 + lVar18) = param_3;
      *(uint *)(&stack0x00000108 + lVar18) = (uint)uVar12;
      *(longlong *)(&stack0x00000110 + lVar18) = param_4;
      *(undefined8 *)(&stack0x00000118 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000150 + lVar18) = 0;
      if (puVar2 != (undefined8 *)0x0) {
        lVar21 = **(longlong **)(*(longlong *)(param_1 + 0x188) + 0x160);
        *(undefined8 *)(&stack0x00000120 + lVar18) = *(undefined8 *)(lVar21 + 0xa8);
        *(undefined4 *)(&stack0x00000128 + lVar18) = *(undefined4 *)(lVar21 + 0xb0);
      }
      *(uint *)(&stack0x0000010c + lVar18) = *(uint *)(&stack0x0000010c + lVar18) | 0x10;
      puVar38 = &stack0xffffffffffffffc8 + lVar18;
    }
    else {
      if (uVar12 == 0) {
        uVar31 = 0;
        lVar44 = lVar21;
      }
      else {
        iVar16 = (uint)uVar12 * 8;
        *(undefined8 *)((longlong)&uStack_40 + lVar18) = 0x1001e1;
        lVar19 = func_0x();
        lVar19 = -lVar19;
        lVar44 = (longlong)&sStackX_18 + lVar19 + lVar18;
        *(undefined8 *)((longlong)&uStack_40 + lVar19 + lVar18) = 0x1001fe;
        lVar20 = func_0x();
        lVar20 = -lVar20;
        puVar38 = &stack0xffffffffffffffc8 + lVar20 + lVar19 + lVar18;
        uVar12 = *(ushort *)(param_3 + 0xb);
        lVar21 = (longlong)&sStackX_18 + lVar20 + lVar19 + lVar18;
        uVar33 = (ulonglong)*(uint *)((longlong)param_3 + 0x54);
        if ((*(uint *)((longlong)param_3 + 0x54) < 0x1f9f) ||
           (uVar33 = (ulonglong)uVar12, 0x1f9d < uVar12)) {
          if ((int)uVar33 == 0) goto LAB_;
        }
        else {
          uVar33 = 0x1f9e;
        }
        *(undefined2 **)(&stack0x00000148 + lVar18) = (undefined2 *)(param_1 + 0x4f0);
        *(longlong *)(param_1 + 0x508) = *(longlong *)(param_1 + 0x500);
        *(ushort *)(param_1 + 0x4f2) = -(ushort)(*(longlong *)(param_1 + 0x500) != 0) & 8000;
        *(undefined2 *)(param_1 + 0x4f0) = 0;
        *(undefined8 *)(param_1 + 0x4f8) = 0;
        *(undefined4 *)(param_1 + 0x4f4) = 0;
        uVar36 = uVar33 + 0xf;
        if (uVar36 <= uVar33) {
          uVar36 = 0xffffffffffffff0;
        }
        uVar36 = uVar36 & 0xfffffffffffffff0;
        *(undefined8 *)((longlong)&uStack_40 + lVar20 + lVar19 + lVar18) = 0x100276;
        func_0x();
        puVar38 = &stack0xffffffffffffffc8 + -uVar36 + lVar20 + lVar19 + lVar18;
        *(ushort *)(param_1 + 0x4f6) = uVar12;
        *(ushort *)(param_1 + 0x4f4) = (short)uVar33 - uVar12;
        *(ulonglong *)(param_1 + 0x4f8) = (longlong)&sStackX_18 + -uVar36 + lVar20 + lVar19 + lVar18
        ;
        uVar31 = (uint)*(ushort *)((longlong)param_3 + 0x62);
        uVar13 = *(ushort *)(param_3 + 7);
      }
LAB_:
      *(uint *)(&stack0x00000108 + lVar18) = uVar31 & 0xffff;
      *(undefined8 *)(&stack0x00000118 + lVar18) = 0;
      *(undefined8 *)(&stack0x00000150 + lVar18) = 0;
      *(longlong *)(&stack0x00000100 + lVar18) = param_3[0xe];
      *(longlong **)(&stack0x000000f8 + lVar18) = param_3;
      *(longlong *)(&stack0x00000110 + lVar18) = param_4;
      if (puVar2 != (undefined8 *)0x0) {
        lVar19 = **(longlong **)(*(longlong *)(param_1 + 0x188) + 0x160);
        *(undefined8 *)(&stack0x00000120 + lVar18) = *(undefined8 *)(lVar19 + 0xa8);
        *(undefined4 *)(&stack0x00000128 + lVar18) = *(undefined4 *)(lVar19 + 0xb0);
      }
      uVar31 = *(uint *)(&stack0x0000010c + lVar18);
      *(uint *)(&stack0x0000010c + lVar18) = uVar31 | 0x10;
      if (((uVar13 & 0x400) != 0) && (param_4 != 0)) {
        *(longlong *)(&stack0x00000130 + lVar18) = lVar44;
        *(uint *)(&stack0x0000010c + lVar18) = uVar31 | 0x14;
        *(int *)(&stack0x00000140 + lVar18) = iVar16;
        *(longlong *)(&stack0x00000138 + lVar18) = lVar21;
        *(int *)(&stack0x00000144 + lVar18) = iVar16;
        if (lVar44 != 0) {
          *(uint *)(&stack0x0000010c + lVar18) = uVar31 | 0x16;
          *(undefined8 *)(puVar38 + -8) = 0x100375;
          func_0x(&stack0x000000f8 + lVar18);
          *(uint *)(&stack0x0000010c + lVar18) = *(uint *)(&stack0x0000010c + lVar18) | 8;
        }
      }
    }
    lVar44 = *(longlong *)(&stack0x000000a0 + lVar18);
    puVar39 = puVar38;
  }
  *(longlong *)(&stack0x00000188 + lVar18) = param_1 + 0x2f0;
  *(undefined4 *)(&stack0x00000198 + lVar18) = 1;
  *(undefined **)(&stack0x00000190 + lVar18) = &stack0x000001f8 + lVar18;
  *(undefined4 *)(&stack0x0000019c + lVar18) = 1;
  *(longlong *)(&stack0x000001a0 + lVar18) = param_1 + 0x180;
  lVar21 = *(longlong *)(param_1 + 0x188);
  lVar19 = lVar21;
  if (*(longlong *)(lVar21 + 0x478) != 0) {
    lVar19 = *(longlong *)(lVar21 + 0x478);
  }
  if ((*(short *)(lVar19 + 0x440) == 0) && (*(short *)(lVar21 + 0xce) == 0)) {
    uVar31 = *(uint *)(&stack0x000001bc + lVar18);
  }
  else {
    uVar31 = *(uint *)(&stack0x000001bc + lVar18) | 1;
    *(uint *)(&stack0x000001bc + lVar18) = uVar31;
  }
  lVar21 = *(longlong *)(&stack0x000001a0 + lVar18);
  if ((0x1f7c < *(uint *)(*(longlong *)(lVar21 + 8) + 0xb0)) &&
     ((*(byte *)(*(longlong *)(lVar21 + 8) + 0x106) & 4) == 0)) {
    uVar31 = uVar31 | 2;
    *(uint *)(&stack0x000001bc + lVar18) = uVar31;
  }
  *(undefined4 *)(&stack0x000001a8 + lVar18) = *(undefined4 *)(*(longlong *)(lVar21 + 0x20) + 0x664)
  ;
  *(ulonglong *)(&stack0x000001b0 + lVar18) = (ulonglong)*(uint6 *)(lVar21 + 0x14) << 0x10;
  uVar15 = *(undefined4 *)(param_1 + 0x238);
  uVar25 = *(undefined8 *)(param_1 + 0x230);
  *(undefined2 *)(&stack0x000001b8 + lVar18) = *(undefined2 *)(*(longlong *)(lVar21 + 0x20) + 0x660)
  ;
  uVar24 = *(undefined8 *)(param_1 + 0x228);
  *(uint *)(&stack0x000001bc + lVar18) = uVar31 | 4;
  *(undefined8 *)(param_1 + 0x230) = uVar24;
  *(undefined8 *)(param_1 + 0x228) = uVar25;
  *(undefined8 *)(puVar39 + -8) = 0x1004a7;
  func_0x(uVar24,0,uVar15);
  uVar31 = *(uint *)(param_1 + 0x238);
  bVar9 = *(byte *)(lVar44 + 0x106);
  uVar25 = *(undefined8 *)(param_1 + 0x230);
  iVar16 = *(int *)(*(longlong *)(param_1 + 0x188) + 0x100);
  *(uint *)(&stack0x00000064 + lVar18) = uVar31;
  if ((iVar16 == 0) || (iVar16 == 3 || iVar16 == 4)) {
    bVar7 = false;
  }
  else {
    bVar7 = true;
  }
  puVar38 = *(undefined **)(&stack0x000000f8 + lVar18);
  if ((puVar38[0x38] & 0x20) == 0) {
    puVar42 = (undefined *)0x0;
    if (bVar7) {
      *(undefined8 *)(&stack0x00000058 + lVar18) = 0;
      puVar23 = puVar42;
      if (((&stack0x0000010c)[lVar18] & 0x10) != 0) {
        puVar23 = puVar38;
      }
      uVar15 = *(undefined4 *)(puVar23 + 0x18);
      uVar17 = *(undefined4 *)(puVar23 + 0x14);
      uVar34 = -*(int *)(puVar23 + 0x10);
      *(uint *)(&stack0x00000098 + lVar18) = uVar34;
      *(undefined2 *)(puVar39 + 0x28) = 1;
      *(undefined4 *)(puVar39 + 0x20) = uVar15;
      if ((bVar9 & 1) == 0) {
        *(undefined8 *)(puVar39 + -8) = 0x1024c3;
        func_0x(psVar3,uVar25,uVar31,uVar17);
      }
      else {
        *(undefined8 *)(puVar39 + -8) = 0x1024bc;
        func_0x();
      }
      if (uVar34 != 0) {
        *(undefined8 *)(puVar39 + -8) = 0x1024e4;
        lVar21 = func_0x();
        lVar21 = -lVar21;
        puVar42 = puVar39 + lVar21 + 0x50;
        *(undefined **)(&stack0x00000058 + lVar18) = puVar42;
        *(undefined8 *)(puVar39 + lVar21 + -8) = 0x1024fa;
        func_0x(puVar42,0);
        puVar39 = puVar39 + lVar21;
      }
      uVar13 = *(ushort *)(*(longlong *)(&stack0x000000f8 + lVar18) + 0x62);
      *(undefined8 *)(&stack0x000000a8 + lVar18) = 0;
      if (uVar13 != 0) {
        puVar47 = (uint *)(*(longlong *)(&stack0x00000100 + lVar18) + 0x38);
        *(ulonglong *)(&stack0x00000078 + lVar18) = (ulonglong)uVar13;
        do {
          uVar31 = puVar47[-0xe];
          puVar37 = puVar47 + -0xe;
          *(undefined8 *)(puVar39 + -8) = 0x10254a;
          func_0x(&stack0x000000f8 + lVar18,puVar37,&stack0x00000055 + lVar18);
          if ((&stack0x00000055)[lVar18] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar47 + 4) + 0xc) & 0x400) == 0) &&
               ((puVar47[2] & 0x4000) == 0)) {
              *(undefined8 *)(puVar39 + -8) = 0x102859;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar39 + -8) = 0x10286b;
            func_0x(psVar3,puVar37,0,0);
            if ((int)uVar31 < 0) {
              *(uint *)(puVar42 + (longlong)(int)~uVar31 * 0x20 + 0xc) =
                   *(uint *)(puVar42 + (longlong)(int)~uVar31 * 0x20 + 0xc) | 2;
            }
          }
          else {
            if (*(short *)(puVar47 + -0xd) != 0) {
              if (*psVar3 == 0) {
                *(undefined8 *)(puVar39 + -8) = 0x10256e;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar39 + -8) = 0x102575;
                func_0x((longlong)&sStackX_18 + lVar18 + 2,puVar37);
              }
            }
            *(undefined8 *)(puVar39 + -8) = 0x10258b;
            func_0x(&stack0x000000f8 + lVar18,puVar37,&stack0x000000a8 + lVar18);
            cVar8 = *(char *)(puVar47 + 2);
            if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
              lVar21 = *(longlong *)(&stack0x000000a8 + lVar18);
              if ((puVar47[2] >> 8 & 1) == 0) {
                uVar31 = *puVar37;
                lVar44 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                uVar11 = *(undefined2 *)(puVar47 + 1);
                *(undefined8 *)(puVar39 + -8) = 0x102711;
                func_0x((int)uVar31 + lVar44,lVar21,uVar11);
              }
              else {
                if (((puVar47[2] & 0x8000) == 0) || (((&stack0x0000010c)[lVar18] & 8) == 0)) {
                  lVar44 = *(longlong *)(&stack0x00000110 + lVar18);
                  if ((*(byte *)(*(longlong *)(puVar47 + 4) + 0x2a) & 0x10) != 0) {
                    lVar44 = *(longlong *)(&stack0x00000118 + lVar18);
                  }
                  uVar31 = *(uint *)(lVar44 + *(longlong *)(*(longlong *)(puVar47 + 4) + 0x18));
                }
                else {
                  uVar31 = *(uint *)(*(longlong *)(&stack0x00000130 + lVar18) +
                                    (ulonglong)*puVar47 * 8);
                }
                uVar34 = (uint)*(ushort *)(puVar47 + 1);
                if (uVar31 < uVar34) {
                  iVar16 = uVar34 - uVar31;
                }
                else {
                  iVar16 = 0;
                  if (uVar34 < uVar31) {
                    *(undefined8 *)(puVar39 + -8) = 0x10277c;
                    (*_DAT_)(6,0x5c,0x16);
                    iVar16 = 0;
                  }
                }
                lVar44 = (longlong)(int)*puVar37 + *(longlong *)((longlong)&puStackX_20 + lVar18);
                uVar29 = *(undefined *)(*(longlong *)(puVar47 + 4) + 0x24);
                if ((lVar21 != 0) && (uVar31 != 0)) {
                  *(undefined8 *)(puVar39 + -8) = 0x1027a4;
                  func_0x(lVar44,lVar21,uVar31);
                }
                if (iVar16 != 0) {
                  *(undefined8 *)(puVar39 + -8) = 0x1027b9;
                  func_0x((ulonglong)uVar31 + lVar44,uVar29,iVar16);
                }
              }
            }
            else if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
              uVar34 = puVar47[2];
              piVar51 = *(int **)(&stack0x000000a8 + lVar18);
              if (((uVar34 >> 0xd & 1) == 0) || (*piVar51 != 0)) {
                if (((uVar34 & 0x8000) == 0) || (((&stack0x0000010c)[lVar18] & 8) == 0)) {
                  lVar21 = *(longlong *)(puVar47 + 4);
                  if ((uVar34 >> 8 & 1) == 0) {
                    uVar34 = (uint)*(ushort *)(lVar21 + 2);
                  }
                  else {
                    lVar44 = *(longlong *)(&stack0x00000110 + lVar18);
                    if ((*(byte *)(lVar21 + 0x2a) & 0x10) != 0) {
                      lVar44 = *(longlong *)(&stack0x00000118 + lVar18);
                    }
                    uVar34 = *(uint *)(lVar44 + *(longlong *)(lVar21 + 0x18));
                  }
                }
                else {
                  uVar34 = *(uint *)(*(longlong *)(&stack0x00000130 + lVar18) +
                                    (ulonglong)*puVar47 * 8);
                }
              }
              else {
                uVar34 = 0;
              }
              if (*(ushort *)(puVar47 + 1) < uVar34) {
                *(undefined8 *)(puVar39 + -8) = 0x1026bc;
                (*_DAT_)(6,0x52,0x16);
                piVar51 = *(int **)(&stack0x000000a8 + lVar18);
              }
              *(undefined4 *)(puVar39 + 0x28) = 0;
              *(uint **)(puVar39 + 0x20) = puVar37;
              *(undefined8 *)(puVar39 + -8) = 0x1026e7;
              func_0x(puVar42 + (longlong)(int)~uVar31 * 0x20,piVar51,uVar34);
            }
            else if (cVar8 == '\b') {
              if (*psVar3 == 0) {
                uVar25 = *(undefined8 *)(&stack0x000000a8 + lVar18);
                *(undefined8 *)(puVar39 + -8) = 0x102601;
                func_0x(psVar3,puVar37,uVar25);
              }
              else {
                uVar25 = *(undefined8 *)(&stack0x000000a8 + lVar18);
                *(undefined4 *)(puVar39 + 0x28) = 0;
                *(uint **)(puVar39 + 0x20) = puVar37;
                *(undefined8 *)(puVar39 + -8) = 0x102633;
                func_0x(puVar42 + (longlong)(int)~uVar31 * 0x20,uVar25,1);
              }
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0x8184c0;
              *(undefined8 *)(puVar39 + -8) = 0x1025dc;
              (*_DAT_)(1,0xc1e850,0xc4b218);
            }
          }
          puVar42 = *(undefined **)(&stack0x00000058 + lVar18);
          puVar47 = puVar47 + 0x14;
          plVar4 = (longlong *)(&stack0x00000078 + lVar18);
          *plVar4 = *plVar4 + -1;
        } while (*plVar4 != 0);
        uVar34 = *(uint *)(&stack0x00000098 + lVar18);
        uVar31 = *(uint *)(&stack0x00000064 + lVar18);
      }
      if (uVar34 != 0) {
        lVar21 = *(longlong *)(&stack0x00000058 + lVar18);
        if (*psVar3 == 0) {
          puVar55 = (ushort *)0x0;
          do {
            uVar33 = (ulonglong)uVar34;
            uVar35 = uVar34 - 1;
            if (*(int *)((ulonglong)uVar35 * 0x20 + 8 + lVar21) != 0) {
              pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
              *(ushort *)(&stack0x00000034 + lVar18) = (ushort)uVar34;
              iVar16 = *(int *)(&stack0x0000002c + lVar18) + 2 + uVar34 * 2;
              *(int *)(&stack0x00000030 + lVar18) = iVar16;
              *(int *)((longlong)&sStackX_18 + lVar18 + 4) = iVar16;
              *pbVar28 = *pbVar28 | 0x20;
              uVar35 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
              if (uVar35 < 0x1f7d) {
                puVar55 = (ushort *)
                          ((ulonglong)*(uint *)(&stack0x0000002c + lVar18) +
                          *(longlong *)((longlong)&puStackX_20 + lVar18));
                *puVar55 = (ushort)uVar34;
                uVar35 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
              }
              if (uVar34 != 0) {
                puVar47 = (uint *)(lVar21 + 0xc);
                do {
                  puVar55 = puVar55 + 1;
                  uVar34 = puVar47[-1];
                  uVar36 = (ulonglong)uVar35;
                  uVar35 = uVar35 + uVar34;
                  lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                  *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar35;
                  if ((uVar35 < 0x1f7d) && (uVar35 <= uVar31)) {
                    *puVar55 = (ushort)((*puVar47 & 1) << 0xf) | (ushort)uVar35 & 0x7fff;
                    uVar25 = *(undefined8 *)(puVar47 + -3);
                    *(undefined8 *)(puVar39 + -8) = 0x10291d;
                    func_0x(uVar36 + lVar21,uVar34,uVar25,uVar34);
                    uVar35 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                  }
                  puVar47 = puVar47 + 8;
                  uVar33 = uVar33 - 1;
                } while (uVar33 != 0);
              }
              break;
            }
            uVar34 = uVar35;
          } while (uVar35 != 0);
        }
        else {
          *(undefined **)(puVar39 + 0x28) = &stack0x000001d4 + lVar18;
          *(longlong *)(puVar39 + 0x20) = lVar21;
          *(undefined8 *)(puVar39 + -8) = 0x102956;
          func_0x((longlong)&sStackX_18 + lVar18 + 2,uVar31,0x1f7c,uVar34);
        }
      }
    }
    else {
      *psVar3 = 0;
      puVar23 = puVar42;
      if (((&stack0x0000010c)[lVar18] & 0x10) != 0) {
        puVar23 = puVar38;
      }
      *(undefined8 *)(&stack0x00000090 + lVar18) = 0;
      uVar34 = -*(int *)(puVar23 + 0x10);
      *(uint *)(&stack0x00000098 + lVar18) = uVar34;
      uVar29 = 0;
      if ((bVar9 & 1) == 0) {
        uVar29 = 6;
      }
      iVar16 = *(int *)(puVar23 + 0x14);
      puVar39[0x28] = uVar29;
      iVar40 = 4;
      if ((bVar9 & 1) == 0) {
        iVar40 = 1;
      }
      *(undefined4 *)(puVar39 + 0x20) = *(undefined4 *)(puVar23 + 0x18);
      *(undefined8 *)(puVar39 + -8) = 0x10055f;
      func_0x((longlong)&sStackX_18 + lVar18 + 2,uVar25,uVar31,iVar16 - iVar40);
      if (uVar34 != 0) {
        *(undefined8 *)(puVar39 + -8) = 0x100587;
        lVar21 = func_0x();
        lVar21 = -lVar21;
        puVar42 = puVar39 + lVar21 + 0x50;
        *(undefined **)(&stack0x00000090 + lVar18) = puVar42;
        *(undefined8 *)(puVar39 + lVar21 + -8) = 0x10059d;
        func_0x(puVar42,0);
        puVar39 = puVar39 + lVar21;
      }
      puVar47 = *(uint **)(&stack0x00000100 + lVar18);
      *(undefined4 *)(&stack0x00000060 + lVar18) = 0;
      *(uint **)(&stack0x00000058 + lVar18) = puVar47;
      uVar13 = *(ushort *)(*(longlong *)(&stack0x000000f8 + lVar18) + 0x62);
      *(uint *)(&stack0x00000068 + lVar18) = (uint)uVar13;
      *(undefined8 *)(&stack0x000000e8 + lVar18) = 0;
      if (uVar13 != 0) {
        do {
          uVar31 = *puVar47;
          *(undefined8 *)(puVar39 + -8) = 0x1005eb;
          func_0x(&stack0x000000f8 + lVar18,puVar47,&stack0x00000054 + lVar18);
          if ((&stack0x00000054)[lVar18] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar47 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar47[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar39 + -8) = 0x1023a0;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar39 + -8) = 0x1023b2;
            func_0x((longlong)&sStackX_18 + lVar18 + 2,puVar47,0,0);
            if ((int)uVar31 < 0) {
              *(uint *)(puVar42 + (longlong)(int)~uVar31 * 0x20 + 0xc) =
                   *(uint *)(puVar42 + (longlong)(int)~uVar31 * 0x20 + 0xc) | 2;
            }
          }
          else {
            if (*(short *)(puVar47 + 1) != 0) {
              *(undefined8 *)(puVar39 + -8) = 0x100609;
              func_0x((longlong)&sStackX_18 + lVar18 + 2,puVar47);
            }
            *(undefined8 *)(puVar39 + -8) = 0x10061f;
            func_0x(&stack0x000000f8 + lVar18,puVar47,&stack0x000000e8 + lVar18);
            cVar8 = *(char *)(puVar47 + 0x10);
            if ((cVar8 == '\x01') || (cVar8 == '\x02')) {
              lVar21 = *(longlong *)(&stack0x000000e8 + lVar18);
              if ((puVar47[0x10] >> 8 & 1) == 0) {
                uVar31 = *puVar47;
                lVar44 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                uVar11 = *(undefined2 *)(puVar47 + 0xf);
                *(undefined8 *)(puVar39 + -8) = 0x1022c1;
                func_0x((int)uVar31 + lVar44,lVar21,uVar11);
              }
              else {
                if (((puVar47[0x10] & 0x8000) == 0) || (((&stack0x0000010c)[lVar18] & 8) == 0)) {
                  lVar44 = *(longlong *)(&stack0x00000110 + lVar18);
                  if ((*(byte *)(*(longlong *)(puVar47 + 0x12) + 0x2a) & 0x10) != 0) {
                    lVar44 = *(longlong *)(&stack0x00000118 + lVar18);
                  }
                  uVar31 = *(uint *)(lVar44 + *(longlong *)(*(longlong *)(puVar47 + 0x12) + 0x18));
                }
                else {
                  uVar31 = *(uint *)(*(longlong *)(&stack0x00000130 + lVar18) +
                                    (ulonglong)puVar47[0xe] * 8);
                }
                uVar34 = (uint)*(ushort *)(puVar47 + 0xf);
                if (uVar31 < uVar34) {
                  iVar16 = uVar34 - uVar31;
                }
                else {
                  iVar16 = 0;
                  if (uVar34 < uVar31) {
                    *(undefined8 *)(puVar39 + -8) = 0x10232b;
                    (*_DAT_)(6,0x5c,0x16);
                    iVar16 = 0;
                  }
                }
                lVar44 = (longlong)(int)*puVar47 + *(longlong *)((longlong)&puStackX_20 + lVar18);
                uVar29 = *(undefined *)(*(longlong *)(puVar47 + 0x12) + 0x24);
                if ((lVar21 != 0) && (uVar31 != 0)) {
                  *(undefined8 *)(puVar39 + -8) = 0x102353;
                  func_0x(lVar44,lVar21,uVar31);
                }
                if (iVar16 != 0) {
                  *(undefined8 *)(puVar39 + -8) = 0x10236b;
                  func_0x((ulonglong)uVar31 + lVar44,uVar29,iVar16);
                }
              }
            }
            else if ((cVar8 == '\x03') || (cVar8 == '\x04')) {
              uVar34 = puVar47[0x10];
              piVar51 = *(int **)(&stack0x000000e8 + lVar18);
              if (((uVar34 >> 0xd & 1) == 0) || (*piVar51 != 0)) {
                if (((uVar34 & 0x8000) == 0) || (((&stack0x0000010c)[lVar18] & 8) == 0)) {
                  lVar21 = *(longlong *)(puVar47 + 0x12);
                  if ((uVar34 >> 8 & 1) == 0) {
                    uVar34 = (uint)*(ushort *)(lVar21 + 2);
                  }
                  else {
                    lVar44 = *(longlong *)(&stack0x00000110 + lVar18);
                    if ((*(byte *)(lVar21 + 0x2a) & 0x10) != 0) {
                      lVar44 = *(longlong *)(&stack0x00000118 + lVar18);
                    }
                    uVar34 = *(uint *)(lVar44 + *(longlong *)(lVar21 + 0x18));
                  }
                }
                else {
                  uVar34 = *(uint *)(*(longlong *)(&stack0x00000130 + lVar18) +
                                    (ulonglong)puVar47[0xe] * 8);
                }
              }
              else {
                uVar34 = 0;
              }
              if (*(ushort *)(puVar47 + 0xf) < uVar34) {
                *(undefined8 *)(puVar39 + -8) = 0x10226b;
                (*_DAT_)(6,0x52,0x16);
                piVar51 = *(int **)(&stack0x000000e8 + lVar18);
              }
              *(undefined4 *)(puVar39 + 0x28) = 0;
              *(uint **)(puVar39 + 0x20) = puVar47;
              *(undefined8 *)(puVar39 + -8) = 0x102296;
              func_0x(puVar42 + (longlong)(int)~uVar31 * 0x20,piVar51,uVar34);
            }
            else if (cVar8 == '\b') {
              uVar31 = *puVar47;
              pcVar53 = *(char **)(&stack0x000000e8 + lVar18);
              *(char **)(&stack0x00000078 + lVar18) = pcVar53;
              if ((int)uVar31 < 0) {
                if ((uVar31 & 0xc0000000) == 0x80000000) {
                  *(undefined8 *)(puVar39 + -8) = 0x10180a;
                  func_0x(&stack0x000003c8 + lVar18);
                  iVar16 = 0;
                  *(undefined4 *)(&stack0x00000080 + lVar18) = 0;
                  if (*(int *)((longlong)&sStackX_18 + lVar18 + 4) == 0) {
                    pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                    uVar31 = *(uint *)(&stack0x00000028 + lVar18);
                    uVar33 = (ulonglong)uVar31;
                    *(undefined2 *)((longlong)&sStackX_18 + lVar18 + 2) = 0;
                    *(uint *)(&stack0x0000002c + lVar18) = uVar31;
                    if ((*pbVar28 & 0x10) != 0) {
                      uVar31 = uVar31 + 2 + (*(ushort *)(pbVar28 + uVar33) + 7 >> 3);
                      uVar33 = (ulonglong)uVar31;
                      *(uint *)(&stack0x0000002c + lVar18) = uVar31;
                    }
                    uVar31 = (uint)uVar33;
                    if ((*pbVar28 & 0x20) == 0) {
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31;
                      *(undefined2 *)(&stack0x00000034 + lVar18) = 0;
                      *(uint *)(&stack0x00000030 + lVar18) = uVar31;
                    }
                    else {
                      puVar55 = (ushort *)(pbVar28 + uVar33);
                      *(ushort **)(&stack0x00000168 + lVar18) = puVar55;
                      uVar13 = *puVar55;
                      *(ushort *)(&stack0x00000034 + lVar18) = uVar13;
                      if (uVar13 == 0) {
                        *(undefined8 *)(puVar39 + -8) = 0x10187a;
                        cVar8 = func_0x(0x11ad550);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x101883;
                          lVar21 = func_0x();
                          if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar39 + -8) = 0x10189d;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x1018b9;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar39 + 0x20) = 0;
                              *(undefined8 *)(puVar39 + -8) = 0x1018df;
                              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x80f);
                            }
                          }
                        }
                        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                        *(undefined8 *)(puVar39 + -8) = 0x1018ed;
                        func_0x(uVar25,3);
                        uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                        uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                        pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                      }
                      uVar34 = (int)uVar33 + (uVar13 + 1) * 2;
                      *(uint *)(&stack0x00000030 + lVar18) = uVar34;
                      if (0x1f9e < uVar34) {
                        *(undefined8 *)(puVar39 + -8) = 0x101922;
                        cVar8 = func_0x(0x11ad550);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x10192b;
                          lVar21 = func_0x();
                          if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar39 + -8) = 0x101945;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x101961;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar39 + 0x20) = 0;
                              *(undefined8 *)(puVar39 + -8) = 0x101987;
                              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x816);
                            }
                          }
                        }
                        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                        *(undefined8 *)(puVar39 + -8) = 0x101995;
                        func_0x(uVar25,4);
                        uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                        uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                        uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                        pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                      }
                      uVar36 = (ulonglong)uVar13;
                      uVar31 = puVar55[uVar36] & 0x7fff;
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31;
                      if (uVar31 < uVar34) {
                        *(undefined8 *)(puVar39 + -8) = 0x1019d0;
                        cVar8 = func_0x(0x11ad550);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x1019d9;
                          lVar21 = func_0x();
                          if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar39 + -8) = 0x1019f3;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x101a0f;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar39 + 0x20) = 0;
                              *(undefined8 *)(puVar39 + -8) = 0x101a35;
                              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x81d);
                            }
                          }
                        }
                        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                        *(undefined8 *)(puVar39 + -8) = 0x101a43;
                        func_0x(uVar25,4);
                        uVar36 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar18);
                        uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                        uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                        uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                        pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                      }
                      if ((short)uVar36 != 0) {
                        do {
                          puVar55 = puVar55 + 1;
                          uVar35 = *puVar55 & 0x7fff;
                          if ((uVar35 < uVar34) || (uVar31 < uVar35)) {
                            *(undefined8 *)(puVar39 + -8) = 0x101a93;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 != '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x101a9c;
                              lVar21 = func_0x();
                              if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar39 + -8) = 0x101ab6;
                                cVar8 = func_0x(0x11ad550);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)(puVar39 + -8) = 0x101ad2;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar39 + 0x20) = 0;
                                  *(undefined8 *)(puVar39 + -8) = 0x101af6;
                                  (*_DAT_)(1,0xa9cf5c,0xbbd048,0x82a);
                                }
                              }
                            }
                            uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                            *(undefined8 *)(puVar39 + -8) = 0x101b04;
                            func_0x(uVar25,4);
                            uVar36 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar18);
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                            pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                          }
                          iVar16 = iVar16 + 1;
                          uVar34 = uVar35;
                        } while (iVar16 < (int)uVar36);
                        uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                        uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                        puVar55 = *(ushort **)(&stack0x00000168 + lVar18);
                        pcVar53 = *(char **)(&stack0x00000078 + lVar18);
                      }
                      while ((short)puVar55[(ulonglong)((int)uVar36 - 1) + 1] < 0) {
                        uVar35 = uVar34;
                        if ((int)uVar36 != 1) {
                          uVar35 = *(ushort *)(pbVar28 + uVar36 * 2 + (uVar33 - 2)) & 0x7fff;
                        }
                        uVar46 = *(ushort *)(pbVar28 + uVar36 * 2 + uVar33) & 0x7fff;
                        if (((uVar35 < uVar34) || (uVar46 < uVar35)) || (uVar31 < uVar46)) {
                          *(undefined8 *)(puVar39 + -8) = 0x101ba8;
                          func_0x(pbVar28,7);
                          uVar36 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar18);
                          uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                          uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                          uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                          pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                        }
                        if ((uVar35 < uVar34) || (uVar31 < uVar35)) goto LAB_;
                        if (*(ushort *)(pbVar28 + uVar35) == 5) {
                          puVar55 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                          *puVar55 = *puVar55 | 2;
                          uVar33 = (ulonglong)(uVar35 & 0xffff);
                          pbVar45 = pbVar28 + uVar33;
                          *(short *)(&stack0x00000034 + lVar18) = (short)uVar36 + -1;
                          *(short *)(&stack0x00000042 + lVar18) = (short)uVar35;
                          uVar13 = *(ushort *)(&stack0x00000044 + lVar18);
                          if ((*(ushort *)(pbVar45 + 2) & 0x4000) == 0) {
                            uVar13 = uVar13 & 0xc7ff;
                          }
                          else {
                            uVar13 = uVar13 ^ (*(ushort *)(pbVar45 + 2) ^ uVar13) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar18) = uVar13;
                          uVar12 = (uVar13 ^ *(ushort *)(pbVar45 + 2)) & 0x7ff ^ uVar13;
                          uVar36 = (ulonglong)uVar12;
                          *(ushort *)(&stack0x00000044 + lVar18) = uVar12;
                          pbVar43 = pbVar28 + uVar33 + (uVar36 & 0x7ff) * 2 +
                                                       (ulonglong)((uVar13 >> 0xb & 7) * 2) + 4;
                          if (pbVar43 < pbVar45) {
                            *(undefined8 *)(puVar39 + -8) = 0x101ce3;
                            func_0x(pbVar45,0x19);
                            uVar36 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                            uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                            pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                          }
                          if (uVar46 - uVar35 <
                              (((*(uint *)(&stack0x00000044 + lVar18) & 0x7ff) * 2 - (int)uVar33) -
                              *(int *)((longlong)&puStackX_20 + lVar18)) + (int)pbVar43) {
                            *(undefined8 *)(puVar39 + -8) = 0x101d1d;
                            func_0x(pbVar28 + uVar33,0x19);
                            uVar36 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                            uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                            pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                          }
                          iVar16 = 0;
                          if (((uVar36 & 0x3800) != 0) &&
                             (puVar55 = (ushort *)(pbVar28 + uVar33 + 4), (uVar36 & 0x3800) != 0)) {
                            do {
                              if (((ushort)uVar36 & 0x7ff) < (*puVar55 & 0x7ff)) {
                                *(undefined8 *)(puVar39 + -8) = 0x101d85;
                                func_0x(pbVar28 + uVar33,0x1a);
                                uVar36 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                                uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                                pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                              }
                              iVar16 = iVar16 + 1;
                              puVar55 = puVar55 + 1;
                            } while (iVar16 < (int)(*(uint *)(&stack0x00000044 + lVar18) >> 0xb & 7)
                                    );
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                          }
                          break;
                        }
                        if (*(ushort *)(pbVar28 + uVar35) < 0x400) break;
                        puVar6 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                        *puVar6 = *puVar6 | 1;
                        uVar13 = (short)uVar36 - 1;
                        uVar36 = (ulonglong)uVar13;
                        *(ushort *)(&stack0x00000034 + lVar18) = uVar13;
                        if (uVar13 == 0) break;
                      }
                    }
                    if ((*pbVar28 & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar18) = 0;
                    }
                    else {
                      *(uint *)(&stack0x0000003e + lVar18) = uVar31;
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31 + 0xe;
                      *(undefined8 *)(puVar39 + -8) = 0x101c1d;
                      uVar25 = func_0x((longlong)&sStackX_18 + lVar18 + 2);
                      *(undefined8 *)(puVar39 + -8) = 0x101c2c;
                      func_0x(uVar25,&stack0x00000170 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x101c38;
                      iVar16 = func_0x(&stack0x00000170 + lVar18);
                      pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                      uVar31 = *(int *)((longlong)&sStackX_18 + lVar18 + 4) + iVar16;
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31;
                    }
                    if ((*(byte **)(&stack0x00000036 + lVar18) != (byte *)0x0) &&
                       (*(byte **)(&stack0x00000036 + lVar18) < pbVar28 + uVar31)) {
                      *(undefined8 *)(puVar39 + -8) = 0x101dee;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x101df7;
                        lVar21 = func_0x();
                        if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar39 + -8) = 0x101e11;
                          cVar8 = func_0x(0x11ad550);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar39 + -8) = 0x101e2d;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar39 + 0x20) = 0;
                            *(undefined8 *)(puVar39 + -8) = 0x101e53;
                            (*_DAT_)(1,0xa9cf5c,0xbbd048,0x886);
                          }
                        }
                      }
                      uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x101e61;
                      func_0x(uVar25,0x12);
                      uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                    }
                    if (0x3f3b < uVar31 - 1) {
                      *(undefined8 *)(puVar39 + -8) = 0x101e7c;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x101e85;
                        lVar21 = func_0x();
                        if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar39 + -8) = 0x101e9f;
                          cVar8 = func_0x(0x11ad550);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar39 + -8) = 0x101ebb;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar39 + 0x20) = 0;
                            *(undefined8 *)(puVar39 + -8) = 0x101ee1;
                            (*_DAT_)(1,0xa9cf5c,0xbbd048,0x88b);
                          }
                        }
                      }
                      uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x101eef;
                      func_0x(uVar25,5);
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar39 + -8) = 0x101ef8;
                  func_0x((longlong)&sStackX_18 + lVar18 + 2);
                  bVar9 = **(byte **)((longlong)&puStackX_20 + lVar18) >> 6;
                  if ((bVar9 & 1) != 0) {
                    *(undefined8 *)(puVar39 + -8) = 0x101f1a;
                    func_0x
                              ((longlong)&sStackX_18 + lVar18 + 2,&stack0x000003c8 + lVar18);
                  }
                  if ((*(byte *)((longlong)&sStackX_18 + lVar18 + 2) & 1) != 0) {
                    *(undefined8 *)(puVar39 + -8) = 0x101f32;
                    puVar22 = (undefined4 *)
                              func_0x((longlong)&sStackX_18 + lVar18 + 2,0x400,
                                              &stack0x00000080 + lVar18);
                    *(undefined4 *)(&stack0x00000160 + lVar18) = *puVar22;
                    *(undefined2 *)(&stack0x00000164 + lVar18) = *(undefined2 *)(puVar22 + 1);
                    *(undefined2 *)(&stack0x00000166 + lVar18) =
                         *(undefined2 *)((longlong)puVar22 + 6);
                  }
                  if ((**(byte **)((longlong)&puStackX_20 + lVar18) & 0x20) == 0) {
                    *(undefined8 *)(puVar39 + -8) = 0x101f62;
                    func_0x((longlong)&sStackX_18 + lVar18 + 2);
                  }
                  lVar44 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18) +
                           *(longlong *)((longlong)&puStackX_20 + lVar18);
                  *(undefined8 *)(puVar39 + -8) = 0x101f72;
                  iVar16 = func_0x((longlong)&sStackX_18 + lVar18 + 2);
                  lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                  if (iVar16 == 0) {
                    puVar55 = (ushort *)(lVar21 + (ulonglong)*(uint *)(&stack0x0000002c + lVar18));
                    uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                    uVar33 = (ulonglong)uVar13;
                    uVar31 = 0;
                    uVar34 = *(uint *)(&stack0x0000002c + lVar18) + (uVar13 + 1) * 2;
                    if (*puVar55 != 0) {
                      do {
                        uVar35 = uVar31 & 0xffff;
                        uVar36 = (ulonglong)uVar31;
                        uVar31 = uVar31 + 1;
                        puVar55[(ulonglong)uVar35 + 1] =
                             puVar55[(ulonglong)uVar35 + 1] ^
                             (puVar55[uVar36 + 1] + 2 ^ puVar55[(ulonglong)uVar35 + 1]) & 0x7fff;
                      } while (uVar31 < *puVar55);
                      lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                    }
                    iVar16 = *(int *)((longlong)&sStackX_18 + lVar18 + 4);
                    *(undefined8 *)(puVar39 + -8) = 0x10205c;
                    func_0x
                              ((ulonglong)uVar34 + 2 + lVar21,(ulonglong)uVar34 + lVar21,
                               iVar16 - uVar34);
                    iVar16 = *(int *)(&stack0x00000030 + lVar18);
                    piVar51 = (int *)((longlong)&sStackX_18 + lVar18 + 4);
                    *piVar51 = *piVar51 + 2;
                    uVar31 = iVar16 + 2;
                    *(uint *)(&stack0x00000030 + lVar18) = uVar31;
                    if (uVar13 != 0) {
                      uVar31 = puVar55[(ulonglong)(uVar13 - 1) + 1] & 0x7fff;
                    }
                    if ((uint)uVar13 < uVar13 + 1) {
                      do {
                        uVar36 = uVar33 & 0xffff;
                        uVar34 = (int)uVar33 + 1;
                        uVar33 = (ulonglong)uVar34;
                        puVar55[uVar36 + 1] = (ushort)uVar31 & 0x7fff;
                      } while (uVar34 < uVar13 + 1);
                    }
                    *puVar55 = *puVar55 + 1;
                    *(undefined8 *)(puVar39 + -8) = 0x1020aa;
                    func_0x((longlong)&sStackX_18 + lVar18 + 2);
                    iVar40 = 0;
                    uVar13 = *(ushort *)
                              (lVar44 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar18) * 2);
                    *(undefined8 *)(puVar39 + -8) = 0x1020c2;
                    func_0x(&stack0x00000228 + lVar18);
                    *(undefined4 *)(puVar39 + 0x28) = 0;
                    *(uint **)(puVar39 + 0x20) = puVar47;
                    *(undefined8 *)(puVar39 + -8) = 0x1020e7;
                    func_0x(&stack0x00000218 + lVar18,pcVar53,1,0);
                    *(undefined **)(puVar39 + 0x28) = &stack0x00000158 + lVar18;
                    *(undefined **)(puVar39 + 0x20) = &stack0x00000218 + lVar18;
                    *(undefined8 *)(puVar39 + -8) = 0x10211a;
                    func_0x(&stack0x00000042 + lVar18,uVar13 & 0x7fff,0x1f9e);
                    iVar16 = *(int *)(&stack0x00000158 + lVar18);
                  }
                  else {
                    uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                    uVar31 = *(uint *)(&stack0x00000030 + lVar18);
                    if (uVar13 != 0) {
                      uVar31 = *(ushort *)
                                ((ulonglong)*(uint *)(&stack0x0000002c + lVar18) + lVar21 +
                                (ulonglong)uVar13 * 2) & 0x7fff;
                    }
                    uVar34 = *(ushort *)
                              ((ulonglong)*(uint *)(&stack0x0000002c + lVar18) + lVar21 + 2 +
                              (ulonglong)(uint)uVar13 * 2) & 0x7fff;
                    if (((uVar31 < *(uint *)(&stack0x00000030 + lVar18)) || (uVar34 < uVar31)) ||
                       (*(uint *)((longlong)&sStackX_18 + lVar18 + 4) < uVar34)) {
                      *(undefined8 *)(puVar39 + -8) = 0x101fc5;
                      func_0x(lVar21,7);
                    }
                    iVar40 = uVar34 - uVar31;
                    *(undefined8 *)(puVar39 + -8) = 0x101fdc;
                    iVar16 = func_0x(&stack0x00000042 + lVar18,puVar47,pcVar53);
                  }
                  iVar40 = (iVar16 - iVar40) + *(int *)((longlong)&sStackX_18 + lVar18 + 4);
                  *(int *)((longlong)&sStackX_18 + lVar18 + 4) = iVar40;
                  if ((*(byte *)((longlong)&sStackX_18 + lVar18 + 2) & 1) != 0) {
                    *(ushort *)
                     (lVar44 + 2 + (ulonglong)(*(ushort *)(&stack0x00000034 + lVar18) + 1) * 2) =
                         (ushort)iVar40 | 0x8000;
                    iVar40 = (*(int *)((longlong)&sStackX_18 + lVar18 + 4) -
                             *(int *)(&stack0x00000080 + lVar18)) + -2;
                  }
                  lVar21 = (longlong)&sStackX_18 + lVar18 + 2;
                  *(ushort *)(lVar44 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar18) * 2) =
                       (ushort)iVar40 | 0x8000;
                  if (iVar16 == 0) {
                    uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                    *(undefined8 *)(puVar39 + -8) = 0x10216e;
                    func_0x(lVar21,uVar13 + 1);
                    if ((**(byte **)((longlong)&puStackX_20 + lVar18) & 0x20) != 0) {
                      *(short *)(&stack0x00000034 + lVar18) =
                           *(short *)(&stack0x00000034 + lVar18) + 1;
                      puVar55 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                      *puVar55 = *puVar55 & 0xfffd;
                      *(undefined8 *)(puVar39 + -8) = 0x10218d;
                      func_0x(&stack0x00000042 + lVar18);
                    }
                  }
                  else {
                    puVar55 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                    *puVar55 = *puVar55 | 2;
                    *(undefined8 *)(puVar39 + -8) = 0x1021a0;
                    uVar11 = func_0x(lVar21,&stack0x000001d0 + lVar18);
                    *(undefined2 *)(&stack0x00000042 + lVar18) = uVar11;
                  }
                  if ((*(byte *)((longlong)&sStackX_18 + lVar18 + 2) & 1) != 0) {
                    uVar15 = *(undefined4 *)(&stack0x00000080 + lVar18);
                    *(undefined8 *)(puVar39 + -8) = 0x1021c3;
                    func_0x((longlong)&sStackX_18 + lVar18 + 2,0x400,uVar15);
                  }
                  if ((bVar9 & 1) != 0) {
                    *(undefined8 *)(puVar39 + -8) = 0x1021d8;
                    func_0x
                              ((longlong)&sStackX_18 + lVar18 + 2,&stack0x000003c8 + lVar18);
                  }
                }
                else {
                  if (*(int *)((longlong)&sStackX_18 + lVar18 + 4) == 0) {
                    pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                    iVar16 = 0;
                    uVar31 = *(uint *)(&stack0x00000028 + lVar18);
                    uVar33 = (ulonglong)uVar31;
                    *(undefined2 *)((longlong)&sStackX_18 + lVar18 + 2) = 0;
                    *(uint *)(&stack0x0000002c + lVar18) = uVar31;
                    if ((*pbVar28 & 0x10) != 0) {
                      uVar31 = uVar31 + 2 + (*(ushort *)(pbVar28 + uVar33) + 7 >> 3);
                      uVar33 = (ulonglong)uVar31;
                      *(uint *)(&stack0x0000002c + lVar18) = uVar31;
                    }
                    uVar31 = (uint)uVar33;
                    if ((*pbVar28 & 0x20) == 0) {
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31;
                      *(undefined2 *)(&stack0x00000034 + lVar18) = 0;
                      *(uint *)(&stack0x00000030 + lVar18) = uVar31;
                    }
                    else {
                      puVar55 = (ushort *)(pbVar28 + uVar33);
                      *(ushort **)(&stack0x00000168 + lVar18) = puVar55;
                      uVar13 = *puVar55;
                      *(ushort *)(&stack0x00000034 + lVar18) = uVar13;
                      if (uVar13 == 0) {
                        *(undefined8 *)(puVar39 + -8) = 0x100e9f;
                        cVar8 = func_0x(0x11ad550);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x100ea8;
                          lVar21 = func_0x();
                          if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar39 + -8) = 0x100ec2;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x100ede;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar39 + 0x20) = 0;
                              *(undefined8 *)(puVar39 + -8) = 0x100f04;
                              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x80f);
                            }
                          }
                        }
                        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                        *(undefined8 *)(puVar39 + -8) = 0x100f12;
                        func_0x(uVar25,3);
                        uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                        uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                        pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                      }
                      uVar34 = (int)uVar33 + (uVar13 + 1) * 2;
                      *(uint *)(&stack0x00000030 + lVar18) = uVar34;
                      if (0x1f9e < uVar34) {
                        *(undefined8 *)(puVar39 + -8) = 0x100f47;
                        cVar8 = func_0x(0x11ad550);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x100f50;
                          lVar21 = func_0x();
                          if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar39 + -8) = 0x100f6a;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x100f86;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar39 + 0x20) = 0;
                              *(undefined8 *)(puVar39 + -8) = 0x100fac;
                              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x816);
                            }
                          }
                        }
                        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                        *(undefined8 *)(puVar39 + -8) = 0x100fba;
                        func_0x(uVar25,4);
                        uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                        uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                        uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                        pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                      }
                      uVar36 = (ulonglong)uVar13;
                      uVar31 = puVar55[uVar36] & 0x7fff;
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31;
                      if (uVar31 < uVar34) {
                        *(undefined8 *)(puVar39 + -8) = 0x100ff5;
                        cVar8 = func_0x(0x11ad550);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x100ffe;
                          lVar21 = func_0x();
                          if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar39 + -8) = 0x101018;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x101034;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar39 + 0x20) = 0;
                              *(undefined8 *)(puVar39 + -8) = 0x10105a;
                              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x81d);
                            }
                          }
                        }
                        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                        *(undefined8 *)(puVar39 + -8) = 0x101068;
                        func_0x(uVar25,4);
                        uVar36 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar18);
                        uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                        uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                        uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                        pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                      }
                      iVar40 = iVar16;
                      if ((short)uVar36 != 0) {
                        do {
                          puVar55 = puVar55 + 1;
                          uVar35 = *puVar55 & 0x7fff;
                          if ((uVar35 < uVar34) || (uVar31 < uVar35)) {
                            *(undefined8 *)(puVar39 + -8) = 0x1010c0;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 != '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x1010c9;
                              lVar21 = func_0x();
                              if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar39 + -8) = 0x1010e3;
                                cVar8 = func_0x(0x11ad550);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)(puVar39 + -8) = 0x1010ff;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar39 + 0x20) = 0;
                                  *(undefined8 *)(puVar39 + -8) = 0x101123;
                                  (*_DAT_)(1,0xa9cf5c,0xbbd048,0x82a);
                                }
                              }
                            }
                            uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                            *(undefined8 *)(puVar39 + -8) = 0x101131;
                            func_0x(uVar25,4);
                            uVar36 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar18);
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                            pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                          }
                          iVar40 = iVar40 + 1;
                          uVar34 = uVar35;
                        } while (iVar40 < (int)uVar36);
                        uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                        uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                        puVar55 = *(ushort **)(&stack0x00000168 + lVar18);
                        puVar47 = *(uint **)(&stack0x00000058 + lVar18);
                      }
                      while ((short)puVar55[(ulonglong)((int)uVar36 - 1) + 1] < 0) {
                        uVar35 = uVar34;
                        if ((int)uVar36 != 1) {
                          uVar35 = *(ushort *)(pbVar28 + uVar36 * 2 + (uVar33 - 2)) & 0x7fff;
                        }
                        uVar46 = *(ushort *)(pbVar28 + uVar36 * 2 + uVar33) & 0x7fff;
                        if (((uVar35 < uVar34) || (uVar46 < uVar35)) || (uVar31 < uVar46)) {
                          *(undefined8 *)(puVar39 + -8) = 0x1011c0;
                          func_0x(pbVar28,7);
                          uVar36 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar18);
                          uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                          uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                          uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                          pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                        }
                        if ((uVar35 < uVar34) || (uVar31 < uVar35)) goto LAB_;
                        if (*(ushort *)(pbVar28 + uVar35) == 5) {
                          puVar55 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                          *puVar55 = *puVar55 | 2;
                          uVar33 = (ulonglong)(uVar35 & 0xffff);
                          pbVar45 = pbVar28 + uVar33;
                          *(short *)(&stack0x00000034 + lVar18) = (short)uVar36 + -1;
                          *(short *)(&stack0x00000042 + lVar18) = (short)uVar35;
                          uVar13 = *(ushort *)(&stack0x00000044 + lVar18);
                          if ((*(ushort *)(pbVar45 + 2) & 0x4000) == 0) {
                            uVar13 = uVar13 & 0xc7ff;
                          }
                          else {
                            uVar13 = uVar13 ^ (*(ushort *)(pbVar45 + 2) ^ uVar13) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar18) = uVar13;
                          uVar12 = (uVar13 ^ *(ushort *)(pbVar45 + 2)) & 0x7ff ^ uVar13;
                          uVar36 = (ulonglong)uVar12;
                          *(ushort *)(&stack0x00000044 + lVar18) = uVar12;
                          pbVar43 = pbVar28 + uVar33 + (uVar36 & 0x7ff) * 2 +
                                                       (ulonglong)((uVar13 >> 0xb & 7) * 2) + 4;
                          if (pbVar43 < pbVar45) {
                            *(undefined8 *)(puVar39 + -8) = 0x1012b9;
                            func_0x(pbVar45,0x19);
                            uVar36 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                            uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                            pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                          }
                          if (uVar46 - uVar35 <
                              (((*(uint *)(&stack0x00000044 + lVar18) & 0x7ff) * 2 - (int)uVar33) -
                              *(int *)((longlong)&puStackX_20 + lVar18)) + (int)pbVar43) {
                            *(undefined8 *)(puVar39 + -8) = 0x1012f3;
                            func_0x(pbVar28 + uVar33,0x19);
                            uVar36 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                            uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                            pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                          }
                          if (((uVar36 & 0x3800) != 0) &&
                             (puVar55 = (ushort *)(pbVar28 + uVar33 + 4), (uVar36 & 0x3800) != 0)) {
                            do {
                              if (((ushort)uVar36 & 0x7ff) < (*puVar55 & 0x7ff)) {
                                *(undefined8 *)(puVar39 + -8) = 0x101355;
                                func_0x(pbVar28 + uVar33,0x1a);
                                uVar36 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                                uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                                pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                              }
                              iVar16 = iVar16 + 1;
                              puVar55 = puVar55 + 1;
                            } while (iVar16 < (int)(*(uint *)(&stack0x00000044 + lVar18) >> 0xb & 7)
                                    );
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                          }
                          break;
                        }
                        if (*(ushort *)(pbVar28 + uVar35) < 0x400) break;
                        puVar6 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                        *puVar6 = *puVar6 | 1;
                        uVar13 = (short)uVar36 - 1;
                        uVar36 = (ulonglong)uVar13;
                        *(ushort *)(&stack0x00000034 + lVar18) = uVar13;
                        if (uVar13 == 0) break;
                      }
                    }
                    if ((*pbVar28 & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar18) = 0;
                    }
                    else {
                      *(uint *)(&stack0x0000003e + lVar18) = uVar31;
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31 + 0xe;
                      *(undefined8 *)(puVar39 + -8) = 0x1013a7;
                      uVar25 = func_0x((longlong)&sStackX_18 + lVar18 + 2);
                      *(undefined8 *)(puVar39 + -8) = 0x1013b6;
                      func_0x(uVar25,&stack0x000001e8 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x1013c2;
                      iVar16 = func_0x(&stack0x000001e8 + lVar18);
                      pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                      uVar31 = *(int *)((longlong)&sStackX_18 + lVar18 + 4) + iVar16;
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31;
                    }
                    if ((*(byte **)(&stack0x00000036 + lVar18) != (byte *)0x0) &&
                       (*(byte **)(&stack0x00000036 + lVar18) < pbVar28 + uVar31)) {
                      *(undefined8 *)(puVar39 + -8) = 0x1013ff;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x101408;
                        lVar21 = func_0x();
                        if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar39 + -8) = 0x101422;
                          cVar8 = func_0x(0x11ad550);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar39 + -8) = 0x10143e;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar39 + 0x20) = 0;
                            *(undefined8 *)(puVar39 + -8) = 0x101464;
                            (*_DAT_)(1,0xa9cf5c,0xbbd048);
                          }
                        }
                      }
                      uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x101472;
                      func_0x(uVar25,0x12);
                      uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                    }
                    if (0x3f3b < uVar31 - 1) {
                      *(undefined8 *)(puVar39 + -8) = 0x10148d;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x101496;
                        lVar21 = func_0x();
                        if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar39 + -8) = 0x1014b0;
                          cVar8 = func_0x(0x11ad550);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar39 + -8) = 0x1014cc;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar39 + 0x20) = 0;
                            *(undefined8 *)(puVar39 + -8) = 0x1014f2;
                            (*_DAT_)(1,0xa9cf5c,0xbbd048);
                          }
                        }
                      }
                      uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x101500;
                      func_0x(uVar25,5);
                    }
                  }
LAB_:
                  uVar31 = -*puVar47;
                  *(undefined8 *)(puVar39 + -8) = 0x101513;
                  func_0x(&stack0x000002e8 + lVar18);
                  pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                  bVar9 = *pbVar28;
                  if ((bVar9 >> 6 & 1) != 0) {
                    *(undefined8 *)(puVar39 + -8) = 0x101535;
                    func_0x
                              ((longlong)&sStackX_18 + lVar18 + 2,&stack0x000002e8 + lVar18);
                    pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                  }
                  if ((*pbVar28 & 0x20) == 0) {
                    *(undefined8 *)(puVar39 + -8) = 0x101548;
                    func_0x((longlong)&sStackX_18 + lVar18 + 2);
                    pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                  }
                  uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                  uVar35 = (uint)uVar13;
                  uVar34 = (uint)uVar13;
                  if (uVar34 < uVar31) {
                    puVar55 = (ushort *)(pbVar28 + *(uint *)(&stack0x0000002c + lVar18));
                    uVar35 = *(uint *)(&stack0x0000002c + lVar18) + 2 + uVar34 * 2;
                    uVar48 = 0;
                    uVar46 = (uVar31 - uVar13) * 2;
                    if (*puVar55 != 0) {
                      do {
                        uVar14 = uVar48 & 0xffff;
                        uVar33 = (ulonglong)uVar48;
                        uVar48 = uVar48 + 1;
                        puVar55[(ulonglong)uVar14 + 1] =
                             puVar55[(ulonglong)uVar14 + 1] ^
                             ((short)uVar46 + puVar55[uVar33 + 1] ^ puVar55[(ulonglong)uVar14 + 1])
                             & 0x7fff;
                      } while (uVar48 < *puVar55);
                      pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                      puVar47 = *(uint **)(&stack0x00000058 + lVar18);
                    }
                    iVar16 = *(int *)((longlong)&sStackX_18 + lVar18 + 4);
                    *(undefined8 *)(puVar39 + -8) = 0x1015dd;
                    func_0x
                              (pbVar28 + (ulonglong)uVar35 + (ulonglong)uVar46,pbVar28 + uVar35,
                               iVar16 - uVar35);
                    iVar16 = *(int *)(&stack0x00000030 + lVar18);
                    piVar51 = (int *)((longlong)&sStackX_18 + lVar18 + 4);
                    *piVar51 = *piVar51 + uVar46;
                    uVar46 = iVar16 + uVar46;
                    *(uint *)(&stack0x00000030 + lVar18) = uVar46;
                    if (uVar13 != 0) {
                      uVar46 = puVar55[(ulonglong)(uVar34 - 1) + 1] & 0x7fff;
                    }
                    do {
                      uVar35 = uVar34 & 0xffff;
                      uVar34 = uVar34 + 1;
                      puVar55[(ulonglong)uVar35 + 1] = (ushort)uVar46 & 0x7fff;
                    } while (uVar34 < uVar31);
                    *puVar55 = *puVar55 + (short)(uVar31 - uVar13);
                    *(undefined8 *)(puVar39 + -8) = 0x10161c;
                    iVar16 = func_0x((longlong)&sStackX_18 + lVar18 + 2);
                    if (iVar16 != 0) {
                      *(undefined8 *)(puVar39 + -8) = 0x101630;
                      uVar11 = func_0x
                                         ((longlong)&sStackX_18 + lVar18 + 2,
                                          &stack0x000001c8 + lVar18);
                      *(undefined2 *)(&stack0x00000042 + lVar18) = uVar11;
                    }
                    pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                    uVar35 = uVar31 & 0xffff;
                    *(short *)(&stack0x00000034 + lVar18) = (short)uVar31;
                  }
                  uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                  if (uVar35 < uVar31) {
                    uVar36 = (ulonglong)
                             (*(ushort *)(pbVar28 + (ulonglong)uVar35 * 2 + uVar33) & 0x7fff);
                    iVar16 = 0;
LAB_:
                    uVar15 = *(undefined4 *)((longlong)&sStackX_18 + lVar18 + 4);
                    puVar55 = (ushort *)(pbVar28 + uVar33);
                    *(undefined8 *)(puVar39 + -8) = 0x1016d1;
                    uVar15 = func_0x(uVar15,iVar16 + (int)uVar36);
                    lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                    *(undefined8 *)(puVar39 + -8) = 0x1016ed;
                    func_0x(lVar21 + 1 + uVar36,iVar16 + lVar21 + uVar36,uVar15);
                    uVar31 = uVar31 - 1;
                    if ((int)uVar31 < (int)(uint)*puVar55) {
                      do {
                        uVar33 = (ulonglong)uVar31;
                        lVar21 = (longlong)(int)uVar31;
                        uVar31 = uVar31 + 1;
                        puVar55[(uVar33 & 0xffff) + 1] =
                             puVar55[(uVar33 & 0xffff) + 1] ^
                             ((puVar55[lVar21 + 1] - (short)iVar16) + 1 ^
                             puVar55[(uVar33 & 0xffff) + 1]) & 0x7fff;
                      } while ((int)uVar31 < (int)(uint)*puVar55);
                      puVar47 = *(uint **)(&stack0x00000058 + lVar18);
                    }
                    piVar51 = (int *)((longlong)&sStackX_18 + lVar18 + 4);
                    *piVar51 = *piVar51 + (1 - iVar16);
                    *(undefined8 *)(puVar39 + -8) = 0x101744;
                    iVar16 = func_0x((longlong)&sStackX_18 + lVar18 + 2);
                    if (iVar16 != 0) {
                      *(undefined8 *)(puVar39 + -8) = 0x101758;
                      uVar11 = func_0x
                                         ((longlong)&sStackX_18 + lVar18 + 2,
                                          &stack0x000001cc + lVar18);
                      *(undefined2 *)(&stack0x00000042 + lVar18) = uVar11;
                    }
                    pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                  }
                  else {
                    uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                    if (uVar31 != 1) {
                      uVar34 = *(ushort *)(pbVar28 + (longlong)(int)uVar31 * 2 + (uVar33 - 2)) &
                               0x7fff;
                    }
                    uVar36 = (ulonglong)uVar34;
                    uVar35 = *(ushort *)(pbVar28 + (longlong)(int)uVar31 * 2 + uVar33) & 0x7fff;
                    if (((uVar34 < *(uint *)(&stack0x00000030 + lVar18)) || (uVar35 < uVar34)) ||
                       (*(uint *)((longlong)&sStackX_18 + lVar18 + 4) < uVar35)) {
                      *(undefined8 *)(puVar39 + -8) = 0x101693;
                      func_0x(pbVar28,7);
                      uVar33 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18);
                      pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                    }
                    iVar16 = uVar35 - uVar34;
                    if (iVar16 != 1) goto LAB_;
                  }
                  pbVar28[uVar36] = **(byte **)(&stack0x00000078 + lVar18);
                  if ((bVar9 >> 6 & 1) != 0) {
                    *(undefined8 *)(puVar39 + -8) = 0x101783;
                    func_0x
                              ((longlong)&sStackX_18 + lVar18 + 2,&stack0x000002e8 + lVar18);
                  }
                }
              }
              else {
                bVar9 = (byte)*(ushort *)((longlong)puVar47 + 6);
                if ((*(ushort *)((longlong)puVar47 + 6) & 8) == 0) {
                  if (*(int *)((longlong)&sStackX_18 + lVar18 + 4) == 0) {
                    pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                    iVar16 = 0;
                    uVar31 = *(uint *)(&stack0x00000028 + lVar18);
                    *(undefined2 *)((longlong)&sStackX_18 + lVar18 + 2) = 0;
                    *(uint *)(&stack0x0000002c + lVar18) = uVar31;
                    if ((*pbVar28 & 0x10) != 0) {
                      *(uint *)(&stack0x0000002c + lVar18) =
                           uVar31 + 2 + (*(ushort *)(pbVar28 + uVar31) + 7 >> 3);
                    }
                    if ((**(byte **)((longlong)&puStackX_20 + lVar18) & 0x20) == 0) {
                      uVar31 = *(uint *)(&stack0x0000002c + lVar18);
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31;
                      *(uint *)(&stack0x00000030 + lVar18) = uVar31;
                      *(undefined2 *)(&stack0x00000034 + lVar18) = 0;
                    }
                    else {
                      puVar55 = (ushort *)
                                (*(byte **)((longlong)&puStackX_20 + lVar18) +
                                *(uint *)(&stack0x0000002c + lVar18));
                      uVar13 = *puVar55;
                      *(ushort *)(&stack0x00000034 + lVar18) = uVar13;
                      if (uVar13 == 0) {
                        *(undefined8 *)(puVar39 + -8) = 0x100778;
                        cVar8 = func_0x(0x11ad550);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x100781;
                          lVar21 = func_0x();
                          if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar39 + -8) = 0x10079b;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x1007b7;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar39 + 0x20) = 0;
                              *(undefined8 *)(puVar39 + -8) = 0x1007dd;
                              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x80f);
                            }
                          }
                        }
                        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                        *(undefined8 *)(puVar39 + -8) = 0x1007eb;
                        func_0x(uVar25,3);
                        uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                      }
                      uVar34 = *(int *)(&stack0x0000002c + lVar18) + 2 + (uint)uVar13 * 2;
                      *(uint *)(&stack0x00000030 + lVar18) = uVar34;
                      if (0x1f9e < uVar34) {
                        *(undefined8 *)(puVar39 + -8) = 0x10081b;
                        cVar8 = func_0x(0x11ad550);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x100824;
                          lVar21 = func_0x();
                          if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar39 + -8) = 0x10083e;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x10085a;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar39 + 0x20) = 0;
                              *(undefined8 *)(puVar39 + -8) = 0x100880;
                              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x816);
                            }
                          }
                        }
                        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                        *(undefined8 *)(puVar39 + -8) = 0x10088e;
                        func_0x(uVar25,4);
                        uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                        uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                      }
                      uVar33 = (ulonglong)uVar13;
                      uVar31 = puVar55[uVar33] & 0x7fff;
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31;
                      if (uVar31 < uVar34) {
                        *(undefined8 *)(puVar39 + -8) = 0x1008c2;
                        cVar8 = func_0x(0x11ad550);
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x1008cb;
                          lVar21 = func_0x();
                          if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar39 + -8) = 0x1008e5;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 == '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x100901;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar39 + 0x20) = 0;
                              *(undefined8 *)(puVar39 + -8) = 0x100927;
                              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x81d);
                            }
                          }
                        }
                        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                        *(undefined8 *)(puVar39 + -8) = 0x100935;
                        func_0x(uVar25,4);
                        uVar33 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar18);
                        uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                        uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                      }
                      puVar6 = puVar55;
                      iVar40 = iVar16;
                      if ((short)uVar33 != 0) {
                        do {
                          uVar35 = puVar6[1] & 0x7fff;
                          if ((uVar35 < uVar34) || (uVar31 < uVar35)) {
                            *(undefined8 *)(puVar39 + -8) = 0x100980;
                            cVar8 = func_0x(0x11ad550);
                            if (cVar8 != '\0') {
                              *(undefined8 *)(puVar39 + -8) = 0x100989;
                              lVar21 = func_0x();
                              if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar39 + -8) = 0x1009a3;
                                cVar8 = func_0x(0x11ad550);
                                if (cVar8 == '\0') {
                                  *(undefined8 *)(puVar39 + -8) = 0x1009bf;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar39 + 0x20) = 0;
                                  *(undefined8 *)(puVar39 + -8) = 0x1009e5;
                                  (*_DAT_)(1,0xa9cf5c,0xbbd048,0x82a);
                                }
                              }
                            }
                            uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                            *(undefined8 *)(puVar39 + -8) = 0x1009f3;
                            func_0x(uVar25,4);
                            uVar33 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar18);
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                          }
                          iVar40 = iVar40 + 1;
                          puVar6 = puVar6 + 1;
                          uVar34 = uVar35;
                        } while (iVar40 < (int)uVar33);
                        uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                      }
                      while ((short)puVar55[(ulonglong)((int)uVar33 - 1) + 1] < 0) {
                        lVar21 = (ulonglong)*(uint *)(&stack0x0000002c + lVar18) +
                                 *(longlong *)((longlong)&puStackX_20 + lVar18);
                        uVar35 = uVar34;
                        if ((int)uVar33 != 1) {
                          uVar35 = *(ushort *)(lVar21 + -2 + uVar33 * 2) & 0x7fff;
                        }
                        uVar46 = *(ushort *)(lVar21 + uVar33 * 2) & 0x7fff;
                        if (((uVar35 < uVar34) || (uVar46 < uVar35)) || (uVar31 < uVar46)) {
                          uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                          *(undefined8 *)(puVar39 + -8) = 0x100a6f;
                          func_0x(uVar25,7);
                          uVar33 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar18);
                          uVar34 = *(uint *)(&stack0x00000030 + lVar18);
                          uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                        }
                        if ((uVar35 < uVar34) || (uVar31 < uVar35)) goto LAB_;
                        uVar13 = *(ushort *)
                                  ((ulonglong)uVar35 +
                                  *(longlong *)((longlong)&puStackX_20 + lVar18));
                        if (uVar13 == 5) {
                          puVar55 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                          *puVar55 = *puVar55 | 2;
                          uVar52 = (ulonglong)(uVar35 & 0xffff);
                          uVar36 = *(longlong *)((longlong)&puStackX_20 + lVar18) + uVar52;
                          *(short *)(&stack0x00000034 + lVar18) = (short)uVar33 + -1;
                          *(short *)(&stack0x00000042 + lVar18) = (short)uVar35;
                          uVar13 = *(ushort *)(&stack0x00000044 + lVar18);
                          if ((*(ushort *)(uVar36 + 2) & 0x4000) == 0) {
                            uVar13 = uVar13 & 0xc7ff;
                          }
                          else {
                            uVar13 = uVar13 ^ (*(ushort *)(uVar36 + 2) ^ uVar13) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar18) = uVar13;
                          uVar12 = (uVar13 ^ *(ushort *)(uVar36 + 2)) & 0x7ff ^ uVar13;
                          uVar50 = (ulonglong)uVar12;
                          *(ushort *)(&stack0x00000044 + lVar18) = uVar12;
                          uVar33 = (ulonglong)((uVar13 >> 0xb & 7) * 2) +
                                   *(longlong *)((longlong)&puStackX_20 + lVar18) + 4 +
                                   (uVar50 & 0x7ff) * 2 + uVar52;
                          if (uVar33 < uVar36) {
                            *(undefined8 *)(puVar39 + -8) = 0x100b6b;
                            func_0x(uVar36,0x19);
                            uVar50 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                            uVar52 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                          }
                          if (uVar46 - uVar35 <
                              (((*(uint *)(&stack0x00000044 + lVar18) & 0x7ff) * 2 - (int)uVar52) -
                              *(int *)((longlong)&puStackX_20 + lVar18)) + (int)uVar33) {
                            lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                            *(undefined8 *)(puVar39 + -8) = 0x100ba2;
                            func_0x(uVar52 + lVar21,0x19);
                            uVar50 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                            uVar52 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                          }
                          if (((uVar50 & 0x3800) != 0) &&
                             (puVar55 = (ushort *)
                                        (*(longlong *)((longlong)&puStackX_20 + lVar18) + 4 + uVar52
                                        ), (uVar50 & 0x3800) != 0)) {
                            do {
                              if (((ushort)uVar50 & 0x7ff) < (*puVar55 & 0x7ff)) {
                                lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                                *(undefined8 *)(puVar39 + -8) = 0x100c06;
                                func_0x(uVar52 + lVar21,0x1a);
                                uVar50 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                                uVar52 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                              }
                              iVar16 = iVar16 + 1;
                              puVar55 = puVar55 + 1;
                            } while (iVar16 < (int)(*(uint *)(&stack0x00000044 + lVar18) >> 0xb & 7)
                                    );
                            uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                          }
                          break;
                        }
                        if (uVar13 < 0x400) break;
                        puVar6 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                        *puVar6 = *puVar6 | 1;
                        uVar13 = (short)uVar33 - 1;
                        uVar33 = (ulonglong)uVar13;
                        *(ushort *)(&stack0x00000034 + lVar18) = uVar13;
                        if (uVar13 == 0) break;
                      }
                    }
                    if ((**(byte **)((longlong)&puStackX_20 + lVar18) & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar18) = 0;
                    }
                    else {
                      *(uint *)(&stack0x0000003e + lVar18) = uVar31;
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31 + 0xe;
                      *(undefined8 *)(puVar39 + -8) = 0x100c5e;
                      uVar25 = func_0x((longlong)&sStackX_18 + lVar18 + 2);
                      *(undefined8 *)(puVar39 + -8) = 0x100c6d;
                      func_0x(uVar25,&stack0x000001e0 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x100c79;
                      iVar16 = func_0x(&stack0x000001e0 + lVar18);
                      uVar31 = *(int *)((longlong)&sStackX_18 + lVar18 + 4) + iVar16;
                      *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar31;
                    }
                    if ((*(ulonglong *)(&stack0x00000036 + lVar18) != 0) &&
                       (*(ulonglong *)(&stack0x00000036 + lVar18) <
                        (ulonglong)uVar31 + *(longlong *)((longlong)&puStackX_20 + lVar18))) {
                      *(undefined8 *)(puVar39 + -8) = 0x100cb3;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x100cbc;
                        lVar21 = func_0x();
                        if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar39 + -8) = 0x100cd6;
                          cVar8 = func_0x(0x11ad550);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar39 + -8) = 0x100cf2;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar39 + 0x20) = 0;
                            *(undefined8 *)(puVar39 + -8) = 0x100d16;
                            (*_DAT_)(1,0xa9cf5c,0xbbd048);
                          }
                        }
                      }
                      uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x100d24;
                      func_0x(uVar25,0x12);
                      uVar31 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                    }
                    if (0x3f3b < uVar31 - 1) {
                      *(undefined8 *)(puVar39 + -8) = 0x100d3f;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x100d48;
                        lVar21 = func_0x();
                        if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar39 + -8) = 0x100d62;
                          cVar8 = func_0x(0x11ad550);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar39 + -8) = 0x100d7e;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar39 + 0x20) = 0;
                            *(undefined8 *)(puVar39 + -8) = 0x100da2;
                            (*_DAT_)(1,0xa9cf5c,0xbbd048);
                          }
                        }
                      }
                      uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x100db0;
                      func_0x(uVar25,5);
                    }
                  }
LAB_:
                  uVar31 = *(uint *)(&stack0x00000028 + lVar18);
                  uVar34 = *puVar47 + 1;
                  if (uVar31 < uVar34) {
                    *(undefined8 *)(puVar39 + -8) = 0x100dd1;
                    func_0x((longlong)&sStackX_18 + lVar18 + 2,0,uVar34 - uVar31);
                    if ((1 << (**(byte **)((longlong)&puStackX_20 + lVar18) & 0xe) & 0x1105U) != 0)
                    {
                      *(short *)(*(byte **)((longlong)&puStackX_20 + lVar18) + 2) = (short)uVar34;
                    }
                    *(uint *)(&stack0x00000028 + lVar18) = uVar34;
                  }
                  if (pcVar53 != (char *)0x0) {
                    *(char *)((longlong)(int)*puVar47 +
                             *(longlong *)((longlong)&puStackX_20 + lVar18)) = *pcVar53;
                  }
                }
                else {
                  uVar34 = *(uint *)(&stack0x00000028 + lVar18);
                  uVar35 = uVar31 + 1;
                  cVar8 = *pcVar53;
                  if (uVar34 < uVar35) {
                    *(undefined8 *)(puVar39 + -8) = 0x1006b8;
                    func_0x((longlong)&sStackX_18 + lVar18 + 2,0,uVar35 - uVar34);
                    pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                    if ((1 << (*pbVar28 & 0xe) & 0x1105U) != 0) {
                      *(short *)(pbVar28 + 2) = (short)uVar35;
                      pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                    }
                    *(uint *)(&stack0x00000028 + lVar18) = uVar35;
                    bVar9 = *(byte *)((longlong)puVar47 + 6);
                  }
                  else {
                    pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
                  }
                  if (cVar8 == '\0') {
                    pbVar28[(int)uVar31] = pbVar28[(int)uVar31] & ~(byte)(1 << (bVar9 & 7));
                  }
                  else {
                    pbVar28[(int)uVar31] = pbVar28[(int)uVar31] | (byte)(1 << (bVar9 & 7));
                  }
                }
              }
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0x8184c0;
              *(undefined8 *)(puVar39 + -8) = 0x10066f;
              (*_DAT_)(1,0xc1e850,0xc4b218);
            }
          }
          iVar16 = *(int *)(&stack0x00000060 + lVar18);
          puVar42 = *(undefined **)(&stack0x00000090 + lVar18);
          puVar47 = puVar47 + 0x14;
          *(uint *)(&stack0x00000060 + lVar18) = iVar16 + 1U;
          *(uint **)(&stack0x00000058 + lVar18) = puVar47;
        } while (iVar16 + 1U < *(uint *)(&stack0x00000068 + lVar18));
        uVar34 = *(uint *)(&stack0x00000098 + lVar18);
        uVar31 = *(uint *)(&stack0x00000064 + lVar18);
      }
      puVar55 = (ushort *)0x0;
      if (uVar34 != 0) {
        lVar21 = *(longlong *)(&stack0x00000090 + lVar18);
        do {
          uVar33 = (ulonglong)uVar34;
          uVar35 = uVar34 - 1;
          if (*(int *)((ulonglong)uVar35 * 0x20 + 8 + lVar21) != 0) {
            pbVar28 = *(byte **)((longlong)&puStackX_20 + lVar18);
            *(ushort *)(&stack0x00000034 + lVar18) = (ushort)uVar34;
            iVar16 = *(int *)(&stack0x0000002c + lVar18) + 2 + uVar34 * 2;
            *(int *)(&stack0x00000030 + lVar18) = iVar16;
            *(int *)((longlong)&sStackX_18 + lVar18 + 4) = iVar16;
            *pbVar28 = *pbVar28 | 0x20;
            uVar35 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
            if (uVar35 < 0x1f7d) {
              puVar55 = (ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000002c + lVar18) +
                        *(longlong *)((longlong)&puStackX_20 + lVar18));
              *puVar55 = (ushort)uVar34;
              uVar35 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
            }
            if (uVar34 != 0) {
              puVar47 = (uint *)(lVar21 + 0xc);
              do {
                puVar55 = puVar55 + 1;
                uVar34 = puVar47[-1];
                uVar36 = (ulonglong)uVar35;
                uVar35 = uVar35 + uVar34;
                lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar35;
                if ((uVar35 < 0x1f7d) && (uVar35 <= uVar31)) {
                  *puVar55 = (ushort)((*puVar47 & 1) << 0xf) | (ushort)uVar35 & 0x7fff;
                  uVar25 = *(undefined8 *)(puVar47 + -3);
                  *(undefined8 *)(puVar39 + -8) = 0x10245d;
                  func_0x(uVar36 + lVar21,uVar34,uVar25,uVar34);
                  uVar35 = *(uint *)((longlong)&sStackX_18 + lVar18 + 4);
                }
                puVar47 = puVar47 + 8;
                uVar33 = uVar33 - 1;
              } while (uVar33 != 0);
            }
            break;
          }
          uVar34 = uVar35;
        } while (uVar35 != 0);
      }
    }
  }
  else {
    if (bVar7) {
      uVar24 = 0x1258fa0;
      uVar30 = 0x12083c8;
    }
    else {
      uVar24 = 0x121fa08;
      uVar30 = 0x1208390;
    }
    if ((bVar9 & 1) == 0) {
      uVar24 = uVar30;
    }
    *(undefined8 *)(&stack0x00000200 + lVar18) = uVar24;
    *(undefined8 *)(&stack0x00000208 + lVar18) = 0;
    *(longlong *)(puVar39 + 0x40) = param_1 + 0x4c8;
    *(undefined **)(puVar39 + 0x38) = &stack0x000001d8 + lVar18;
    *(undefined4 *)(puVar39 + 0x30) = 0x1f7c;
    *(uint *)(puVar39 + 0x28) = uVar31;
    *(undefined8 *)(puVar39 + 0x20) = uVar25;
    *(undefined8 *)(puVar39 + -8) = 0x102ab2;
    func_0x(&stack0x00000188 + lVar18,&stack0x000000f8 + lVar18,2,psVar3);
  }
  lVar21 = *(longlong *)(&stack0x00000070 + lVar18);
  *(undefined8 *)(puVar39 + -8) = 0x102969;
  func_0x(lVar21 + 0x180);
  plVar4 = *(longlong **)(&stack0x00000178 + lVar18);
  lVar44 = plVar4[0x1a];
  if ((*(byte *)(lVar21 + 0x4b8) & 1) == 0) {
    UNRECOVERED_JUMPTABLE = *(code **)*plVar4;
    *(undefined8 *)(puVar39 + -8) = 0x10298d;
    cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
    if (cVar8 == '\0') {
      UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x88);
      *(undefined8 *)(puVar39 + -8) = 0x1029a1;
      cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
      if (cVar8 != '\0') {
        if (*(char *)(lVar21 + 0x4b9) != '\0') goto LAB_;
        if (lVar44 == 0) {
          UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x18);
          *(undefined8 *)(puVar39 + -8) = 0x1029c5;
          cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
          if (cVar8 == '\0') goto LAB_;
        }
        if ((*(byte *)(plVar4 + 0x4a) & 4) == 0) {
          if ((*(byte *)(plVar4 + 0x4a) & 0x5a) == 0) {
            if ((*(byte *)(plVar4 + 0x43) & 1) != 0) {
              if (plVar4[0x1a] == 0) {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x88);
                *(undefined8 *)(puVar39 + -8) = 0x102a0b;
                cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                if (cVar8 != '\0') {
                  UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x18);
                  *(undefined8 *)(puVar39 + -8) = 0x102a1c;
                  cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                  if (cVar8 == '\0') {
                    *(byte *)(plVar4 + 0x4a) = *(byte *)(plVar4 + 0x4a) | 4;
                    goto LAB_;
                  }
                }
              }
              *(undefined8 *)(puVar39 + -8) = 0x102abf;
              iVar16 = func_0x(plVar4);
              if (iVar16 == 0) {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x270);
                *(undefined8 *)(puVar39 + -8) = 0x102acf;
                (*UNRECOVERED_JUMPTABLE)(plVar4);
              }
              if ((*(byte *)(plVar4 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar4 + 0x4a) & 0x52) == 2) {
                  lVar19 = plVar4[0x1a];
                  *(undefined8 *)(puVar39 + -8) = 0x102b07;
                  cVar8 = func_0x(lVar19);
                  if (((cVar8 != '\0') && (*(char *)(plVar4[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(plVar4[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                    *(undefined8 *)(puVar39 + 0x20) = 0;
                    *(undefined8 *)(puVar39 + -8) = 0x102b4c;
                    func_0x(0x11adc90,0x1c,0x10,1);
                  }
                }
                uVar31 = (uint)((*(byte *)(plVar4 + 0x4a) & 0x5a) != 0);
              }
              else {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x1e8);
                *(undefined8 *)(puVar39 + -8) = 0x102ae4;
                uVar25 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                *(undefined8 *)(puVar39 + -8) = 0x102aec;
                uVar31 = func_0x(uVar25);
              }
              if (uVar31 != 0) goto LAB_;
            }
          }
          else {
LAB_:
            if (((*(byte *)(plVar4 + 0x4a) & 0x40) != 0) && (*(char *)(lVar21 + 0x4ba) != '\0'))
            goto LAB_;
          }
        }
      }
LAB_:
      if ((*(byte *)(lVar21 + 0x4b8) & 0x1c) != 0) goto LAB_;
      if (*(longlong *)(lVar21 + 0x4c0) != 0) {
        *(undefined8 *)(puVar39 + -8) = 0x102b97;
        iVar16 = func_0x();
        if (((iVar16 != 0) &&
            (iVar16 = *(int *)(*(longlong *)(*(longlong *)(lVar21 + 0x4c0) + 8) + 0x100),
            iVar16 != 0)) && (1 < iVar16 - 3U)) {
          *(undefined8 *)(puVar39 + 0x20) = 0;
          *(undefined8 *)(puVar39 + -8) = 0x102bdc;
          (*_DAT_)(1,0xc4bf60,0xc4bfb0,0x116);
        }
        uVar25 = *(undefined8 *)(lVar21 + 0x4c0);
        *(undefined8 *)(puVar39 + -8) = 0x102be8;
        iVar16 = func_0x(uVar25);
        if (((iVar16 != 0) &&
            (lVar19 = *(longlong *)(*(longlong *)(lVar21 + 0x4c0) + 8),
            (*(byte *)(lVar19 + 0x109) & 1) == 0)) &&
           ((iVar16 = *(int *)(lVar19 + 0x100), iVar16 != 0 && (1 < iVar16 - 3U)))) {
          *(undefined8 *)(puVar39 + 0x20) = 0;
          *(undefined8 *)(puVar39 + -8) = 0x102c36;
          (*_DAT_)(1,0xc4bfe0,0xc4bfb0,0x119);
        }
      }
      if ((lVar44 == 0) || ((*(int *)(lVar44 + 0x78) < 1 && (*(int *)(lVar44 + 0x74) < 1)))) {
        if ((*(byte *)(plVar4 + 0x4a) & 4) == 0) {
          if ((*(byte *)(plVar4 + 0x4a) & 0x5a) != 0) {
LAB_:
            if (lVar44 != 0) goto LAB_;
            goto LAB_;
          }
          if ((*(byte *)(plVar4 + 0x43) & 1) != 0) {
            if (plVar4[0x1a] == 0) {
              UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x88);
              *(undefined8 *)(puVar39 + -8) = 0x102c89;
              cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
              if (cVar8 != '\0') {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x18);
                *(undefined8 *)(puVar39 + -8) = 0x102c96;
                cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                if (cVar8 == '\0') {
                  *(byte *)(plVar4 + 0x4a) = *(byte *)(plVar4 + 0x4a) | 4;
                  goto LAB_;
                }
              }
            }
            *(undefined8 *)(puVar39 + -8) = 0x102cae;
            iVar16 = func_0x(plVar4);
            if (iVar16 == 0) {
              UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x270);
              *(undefined8 *)(puVar39 + -8) = 0x102cbe;
              (*UNRECOVERED_JUMPTABLE)(plVar4);
            }
            if ((*(byte *)(plVar4 + 0x43) & 4) == 0) {
              if ((*(byte *)(plVar4 + 0x4a) & 0x52) == 2) {
                lVar19 = plVar4[0x1a];
                *(undefined8 *)(puVar39 + -8) = 0x102cf6;
                cVar8 = func_0x(lVar19);
                if (((cVar8 != '\0') && (*(char *)(plVar4[0x1a] + 0x130) == '\0')) &&
                   (*(undefined *)(plVar4[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                  *(undefined8 *)(puVar39 + 0x20) = 0;
                  *(undefined8 *)(puVar39 + -8) = 0x102d3b;
                  func_0x(0x11adc90,0x1c,0x10,1);
                }
              }
              uVar31 = (uint)((*(byte *)(plVar4 + 0x4a) & 0x5a) != 0);
            }
            else {
              UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x1e8);
              *(undefined8 *)(puVar39 + -8) = 0x102cd3;
              uVar25 = (*UNRECOVERED_JUMPTABLE)(plVar4);
              *(undefined8 *)(puVar39 + -8) = 0x102cdb;
              uVar31 = func_0x(uVar25);
            }
            if (uVar31 != 0) goto LAB_;
          }
        }
      }
      else {
LAB_:
        if ((*(byte *)(lVar21 + 0x4b8) & 0x1c) == 0) {
          if (*(longlong *)(lVar21 + 0x4c0) != 0) {
            *(undefined8 *)(puVar39 + -8) = 0x102d7c;
            iVar16 = func_0x();
            if (((iVar16 != 0) &&
                (iVar16 = *(int *)(*(longlong *)(*(longlong *)(lVar21 + 0x4c0) + 8) + 0x100),
                iVar16 != 0)) && (1 < iVar16 - 3U)) {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x102dc1;
              (*_DAT_)(1,0xc4bf60,0xc4bfb0,0x116);
            }
            uVar25 = *(undefined8 *)(lVar21 + 0x4c0);
            *(undefined8 *)(puVar39 + -8) = 0x102dcd;
            iVar16 = func_0x(uVar25);
            if (((iVar16 != 0) &&
                (lVar19 = *(longlong *)(*(longlong *)(lVar21 + 0x4c0) + 8),
                (*(byte *)(lVar19 + 0x109) & 1) == 0)) &&
               ((iVar16 = *(int *)(lVar19 + 0x100), iVar16 != 0 && (1 < iVar16 - 3U)))) {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x102e1b;
              (*_DAT_)(1,0xc4bfe0,0xc4bfb0,0x119);
            }
          }
          if ((*(int *)(lVar44 + 0x78) < 1) && (*(int *)(lVar44 + 0x74) < 1)) {
            if ((*(byte *)(plVar4 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar4 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar4 + 0x43) & 1) != 0) {
                  if (plVar4[0x1a] == 0) {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x88);
                    *(undefined8 *)(puVar39 + -8) = 0x102e69;
                    cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                    if (cVar8 != '\0') {
                      UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x18);
                      *(undefined8 *)(puVar39 + -8) = 0x102e76;
                      cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                      if (cVar8 == '\0') {
                        *(byte *)(plVar4 + 0x4a) = *(byte *)(plVar4 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)(puVar39 + -8) = 0x102e8e;
                  iVar16 = func_0x(plVar4);
                  if (iVar16 == 0) {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x270);
                    *(undefined8 *)(puVar39 + -8) = 0x102e9e;
                    (*UNRECOVERED_JUMPTABLE)(plVar4);
                  }
                  if ((*(byte *)(plVar4 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar4 + 0x4a) & 0x52) == 2) {
                      lVar19 = plVar4[0x1a];
                      *(undefined8 *)(puVar39 + -8) = 0x102ed6;
                      cVar8 = func_0x(lVar19);
                      if (((cVar8 != '\0') && (*(char *)(plVar4[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar4[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(puVar39 + 0x20) = 0;
                        *(undefined8 *)(puVar39 + -8) = 0x102f1b;
                        func_0x(0x11adc90,0x1c,0x10,1);
                      }
                    }
                    uVar31 = (uint)((*(byte *)(plVar4 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x1e8);
                    *(undefined8 *)(puVar39 + -8) = 0x102eb3;
                    uVar25 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                    *(undefined8 *)(puVar39 + -8) = 0x102ebb;
                    uVar31 = func_0x(uVar25);
                  }
                  if (uVar31 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if ((*(byte *)(plVar4 + 0x4a) & 0x10) != 0) goto LAB_;
              }
            }
LAB_:
            if ((*(byte *)(plVar4 + 0x4a) & 4) == 0) {
              if ((*(byte *)(plVar4 + 0x4a) & 0x5a) == 0) {
                if ((*(byte *)(plVar4 + 0x43) & 1) != 0) {
                  if (plVar4[0x1a] == 0) {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x88);
                    *(undefined8 *)(puVar39 + -8) = 0x102f73;
                    cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                    if (cVar8 != '\0') {
                      UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x18);
                      *(undefined8 *)(puVar39 + -8) = 0x102f80;
                      cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                      if (cVar8 == '\0') {
                        *(byte *)(plVar4 + 0x4a) = *(byte *)(plVar4 + 0x4a) | 4;
                        goto LAB_;
                      }
                    }
                  }
                  *(undefined8 *)(puVar39 + -8) = 0x102f98;
                  iVar16 = func_0x(plVar4);
                  if (iVar16 == 0) {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x270);
                    *(undefined8 *)(puVar39 + -8) = 0x102fa8;
                    (*UNRECOVERED_JUMPTABLE)(plVar4);
                  }
                  if ((*(byte *)(plVar4 + 0x43) & 4) == 0) {
                    if ((*(byte *)(plVar4 + 0x4a) & 0x52) == 2) {
                      lVar19 = plVar4[0x1a];
                      *(undefined8 *)(puVar39 + -8) = 0x102fe0;
                      cVar8 = func_0x(lVar19);
                      if (((cVar8 != '\0') && (*(char *)(plVar4[0x1a] + 0x130) == '\0')) &&
                         (*(undefined *)(plVar4[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                        *(undefined8 *)(puVar39 + 0x20) = 0;
                        *(undefined8 *)(puVar39 + -8) = 0x103025;
                        func_0x(0x11adc90,0x1c,0x10,1);
                      }
                    }
                    uVar31 = (uint)((*(byte *)(plVar4 + 0x4a) & 0x5a) != 0);
                  }
                  else {
                    UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x1e8);
                    *(undefined8 *)(puVar39 + -8) = 0x102fbd;
                    uVar25 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                    *(undefined8 *)(puVar39 + -8) = 0x102fc5;
                    uVar31 = func_0x(uVar25);
                  }
                  if (uVar31 != 0) goto LAB_;
                }
              }
              else {
LAB_:
                if ((*(byte *)(plVar4 + 0x4a) & 0x40) != 0) goto LAB_;
              }
            }
          }
        }
LAB_:
        *(undefined8 *)(puVar39 + -8) = 0x103049;
        func_0x(lVar44,0);
LAB_:
        *(undefined8 *)(puVar39 + -8) = 0x103051;
        iVar16 = func_0x(plVar4);
        if (iVar16 == 0) {
          UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x270);
          *(undefined8 *)(puVar39 + -8) = 0x103061;
          (*UNRECOVERED_JUMPTABLE)(plVar4);
        }
        if (*(longlong *)(lVar21 + 0x208) != 0) {
          UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x88);
          *(undefined8 *)(puVar39 + -8) = 0x103077;
          cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
          if (cVar8 != '\0') {
            UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x18);
            *(undefined8 *)(puVar39 + -8) = 0x103084;
            cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
            if ((((cVar8 == '\0') &&
                 ((*(longlong *)(*(longlong *)(lVar21 + 0x188) + 0x70) != 0 ||
                  (*(int *)(*(longlong *)(*(longlong *)(lVar21 + 0x1a0) + 0x710) + 0x40) != 0)))) &&
                (iVar16 = *(int *)(*(longlong *)(lVar21 + 0x188) + 0x100), iVar16 != 0)) &&
               (1 < iVar16 - 3U)) goto LAB_;
          }
        }
        lVar44 = *(longlong *)(&stack0x00000088 + lVar18);
        if ((lVar44 != 0) &&
           (((0 < *(int *)(lVar44 + 0x78) || (0 < *(int *)(lVar44 + 0x74))) &&
            ((*(byte *)(*(longlong *)(lVar21 + 0x48) + 0x70) & 1) != 0)))) {
          uVar25 = *(undefined8 *)(lVar21 + 0x178);
          uVar24 = *(undefined8 *)(lVar21 + 0x290);
          *(undefined8 *)(puVar39 + -8) = 0x1030f9;
          func_0x(uVar24,uVar25,psVar3,0);
        }
        lVar44 = plVar4[0x1a];
        if ((*(byte *)(lVar21 + 0x4b8) & 0x24) == 0) {
          if ((*(byte *)(plVar4 + 0x4a) & 4) == 0) {
            if ((*(byte *)(plVar4 + 0x4a) & 0x5a) != 0) goto LAB_;
            if ((*(byte *)(plVar4 + 0x43) & 1) != 0) {
              if (lVar44 == 0) {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x88);
                *(undefined8 *)(puVar39 + -8) = 0x103143;
                cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                if (cVar8 != '\0') {
                  UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x18);
                  *(undefined8 *)(puVar39 + -8) = 0x103150;
                  cVar8 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                  if (cVar8 == '\0') {
                    *(byte *)(plVar4 + 0x4a) = *(byte *)(plVar4 + 0x4a) | 4;
                    goto LAB_;
                  }
                }
              }
              *(undefined8 *)(puVar39 + -8) = 0x103168;
              iVar16 = func_0x(plVar4);
              if (iVar16 == 0) {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x270);
                *(undefined8 *)(puVar39 + -8) = 0x103178;
                (*UNRECOVERED_JUMPTABLE)(plVar4);
              }
              if ((*(byte *)(plVar4 + 0x43) & 4) == 0) {
                if ((*(byte *)(plVar4 + 0x4a) & 0x52) == 2) {
                  lVar19 = plVar4[0x1a];
                  *(undefined8 *)(puVar39 + -8) = 0x1031b0;
                  cVar8 = func_0x(lVar19);
                  if (((cVar8 != '\0') && (*(char *)(plVar4[0x1a] + 0x130) == '\0')) &&
                     (*(undefined *)(plVar4[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                    plVar32 = (longlong *)0x0;
                    if (_DAT_ != 0) {
                      plVar32 = (longlong *)(_DAT_ + 0xe000);
                    }
                    if ((plVar32 != (longlong *)0x0) && (*plVar32 != 0)) {
                      LOCK();
                      plVar32 = (longlong *)(*plVar32 + 0x10);
                      *plVar32 = *plVar32 + 1;
                      UNLOCK();
                    }
                  }
                }
                uVar31 = (uint)((*(byte *)(plVar4 + 0x4a) & 0x5a) != 0);
              }
              else {
                UNRECOVERED_JUMPTABLE = *(code **)(*plVar4 + 0x1e8);
                *(undefined8 *)(puVar39 + -8) = 0x10318d;
                uVar25 = (*UNRECOVERED_JUMPTABLE)(plVar4);
                *(undefined8 *)(puVar39 + -8) = 0x103195;
                uVar31 = func_0x(uVar25);
              }
              if (uVar31 != 0) goto LAB_;
            }
          }
          if ((lVar44 == 0) || (*(int *)(lVar44 + 0x74) < 1)) goto LAB_;
        }
LAB_:
        uVar29 = *(undefined *)(lVar21 + 0x4b4);
        uVar25 = *(undefined8 *)(lVar21 + 0x178);
        puVar39[0x20] = 0;
        *(undefined8 *)(puVar39 + -8) = 0x103243;
        func_0x(psVar3,uVar25,uVar29,0);
      }
    }
  }
LAB_:
  lVar44 = *(longlong *)(lVar21 + 0x208);
  if (lVar44 != 0) {
    *(undefined8 *)(puVar39 + -8) = 0x10325f;
    func_0x(lVar44,psVar3,lVar21 + 0x27c);
    goto LAB_;
  }
  lVar44 = *(longlong *)(lVar21 + 0x240);
  *(undefined4 *)(&stack0x00000060 + lVar18) = 0;
  *(undefined2 *)(&stack0x00000238 + lVar18) = 0xffff;
  *(undefined8 *)(&stack0x00000240 + lVar18) = 0;
  uVar11 = 9;
  *(undefined4 *)(&stack0x0000023c + lVar18) = 0;
  *(undefined8 *)(&stack0x00000256 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000260 + lVar18) = 0;
  *(undefined8 *)(&stack0x00000248 + lVar18) = 0;
  *(undefined4 *)(&stack0x0000026c + lVar18) = 0xffffffff;
  *(undefined8 *)(&stack0x00000058 + lVar18) = 0;
  if (lVar44 != 0) {
    *(undefined8 *)(puVar39 + -8) = 0x1032bc;
    iVar16 = func_0x(lVar21 + -8);
    if (iVar16 == 1) {
      if (((*(byte *)(*(longlong *)(&stack0x000000a0 + lVar18) + 0x106) & 0x40) == 0) &&
         ((*(byte *)(*(longlong *)(&stack0x000000a0 + lVar18) + 0x108) & 8) == 0)) {
        *(undefined8 *)(puVar39 + 0x20) = 0;
        *(undefined8 *)(puVar39 + -8) = 0x1032fd;
        (*_DAT_)(1,0xc79e90,0xc24b70,0x3a9);
      }
      *(undefined4 *)(&stack0x00000060 + lVar18) = 1;
    }
    else if (iVar16 == 3) {
      pbVar28 = *(byte **)(lVar21 + 0x228);
      *(undefined4 *)(&stack0x000000b4 + lVar18) = 0;
      *(undefined8 *)(&stack0x000000ce + lVar18) = 0;
      *(undefined8 *)(&stack0x000000d8 + lVar18) = 0;
      *(undefined8 *)(&stack0x000000c0 + lVar18) = 0;
      bVar9 = *pbVar28;
      *(byte **)(&stack0x000000b8 + lVar18) = pbVar28;
      if ((bVar9 & 1) != 0) {
        *(undefined2 *)(&stack0x000000b0 + lVar18) = 1;
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar28 & 0x1c) + 0x104920) *
                                4 + 0x104910) - 0x1d02070);
                    /* WARNING: Could not emulate address calculation at 0x0010337f */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return;
      }
      *(undefined2 *)(&stack0x000000b0 + lVar18) = 0;
      *(undefined4 *)(&stack0x000000d6 + lVar18) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010352a */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar28 & 0xe) * 4 + 0x104940) - 0x1d02070))
                ();
      return;
    }
  }
  uVar31 = *(uint *)(lVar21 + 0x518);
  uVar15 = *(undefined4 *)(lVar21 + 0x51c);
  puVar2 = *(undefined8 **)(lVar21 + 0x178);
  if ((uVar31 < *(uint *)(*(longlong *)(lVar21 + 0x188) + 0xb4)) &&
     ((((byte)*(undefined4 *)(puVar2 + 0x43) & 5) != 1 || ((*(byte *)(puVar2 + 0x5b) & 2) == 0)))) {
    UNRECOVERED_JUMPTABLE = *(code **)*puVar2;
    *(undefined8 *)(puVar39 + -8) = 0x103664;
    cVar8 = (*UNRECOVERED_JUMPTABLE)();
    if (cVar8 == '\0') {
      *(undefined4 *)(puVar39 + 0x28) = uVar15;
      *(uint *)(puVar39 + 0x20) = uVar31;
      *(undefined8 *)(puVar39 + -8) = 0x10368c;
      func_0x(lVar21 + 0x180,0,psVar3,lVar21 + 0x298);
    }
  }
  puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
  iVar16 = *(int *)(**(longlong **)(*(longlong *)(lVar21 + 0x188) + 0x160) + 0x1c);
  iVar40 = iVar16 + -1;
  if ((*(byte *)(*(longlong *)(lVar21 + 0x188) + 0x106) & 0x40) == 0) {
    iVar40 = iVar16;
  }
  uVar31 = (uint)(iVar40 != 0);
  lVar44 = *(longlong *)(&stack0x00000070 + lVar18);
  ppuVar54 = (uint **)(lVar21 + 0x268);
  *(uint *)(&stack0x00000064 + lVar18) = uVar31;
  sVar10 = *psVar3;
  *(uint ***)(&stack0x00000090 + lVar18) = ppuVar54;
  *(uint **)(lVar44 + 0x260) = puVar47;
  *(longlong *)(&stack0x00000078 + lVar18) = lVar44 + 0x272;
  if (sVar10 == 0) {
    if (*(int *)((longlong)&sStackX_18 + lVar18 + 4) == 0) {
      uVar31 = *(uint *)(&stack0x00000028 + lVar18);
      uVar33 = (ulonglong)uVar31;
      iVar16 = 0;
      *(undefined2 *)((longlong)&sStackX_18 + lVar18 + 2) = 0;
      *(uint *)(&stack0x0000002c + lVar18) = uVar31;
      if ((*(byte *)puVar47 & 0x10) != 0) {
        uVar31 = uVar31 + 2 + (*(ushort *)(uVar33 + (longlong)puVar47) + 7 >> 3);
        uVar33 = (ulonglong)uVar31;
        *(uint *)(&stack0x0000002c + lVar18) = uVar31;
      }
      iVar40 = 0;
      if ((*(byte *)puVar47 & 0x20) == 0) {
        *(int *)((longlong)&sStackX_18 + lVar18 + 4) = (int)uVar33;
        *(undefined2 *)(&stack0x00000034 + lVar18) = 0;
        *(int *)(&stack0x00000030 + lVar18) = (int)uVar33;
      }
      else {
        puVar55 = (ushort *)(uVar33 + (longlong)puVar47);
        uVar13 = *puVar55;
        *(ushort *)(&stack0x00000034 + lVar18) = uVar13;
        if (uVar13 == 0) {
          *(undefined8 *)(puVar39 + -8) = 0x103753;
          cVar8 = func_0x(0x11ad550);
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar39 + -8) = 0x10375c;
            lVar21 = func_0x();
            if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
              *(undefined8 *)(puVar39 + -8) = 0x103776;
              cVar8 = func_0x(0x11ad550);
              if (cVar8 == '\0') {
                *(undefined8 *)(puVar39 + -8) = 0x103792;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar39 + 0x20) = 0;
                *(undefined8 *)(puVar39 + -8) = 0x1037b5;
                (*_DAT_)(1,0xa9cf5c,0xbbd048,0x80f);
              }
            }
          }
          uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
          *(undefined8 *)(puVar39 + -8) = 0x1037c3;
          func_0x(uVar25,3);
          puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
        }
        uVar31 = *(int *)(&stack0x0000002c + lVar18) +
                 (*(ushort *)(&stack0x00000034 + lVar18) + 1) * 2;
        *(uint *)(&stack0x00000030 + lVar18) = uVar31;
        if (0x1f9e < uVar31) {
          *(undefined8 *)(puVar39 + -8) = 0x1037ee;
          cVar8 = func_0x(0x11ad550);
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar39 + -8) = 0x1037f7;
            lVar21 = func_0x();
            if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
              *(undefined8 *)(puVar39 + -8) = 0x103811;
              cVar8 = func_0x(0x11ad550);
              if (cVar8 == '\0') {
                *(undefined8 *)(puVar39 + -8) = 0x10382d;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar39 + 0x20) = 0;
                *(undefined8 *)(puVar39 + -8) = 0x103850;
                (*_DAT_)(1,0xa9cf5c,0xbbd048,0x816);
              }
            }
          }
          uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
          *(undefined8 *)(puVar39 + -8) = 0x10385e;
          func_0x(uVar25,4);
          puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
        }
        uVar13 = puVar55[*(ushort *)(&stack0x00000034 + lVar18)];
        *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar13 & 0x7fff;
        if ((uVar13 & 0x7fff) < *(uint *)(&stack0x00000030 + lVar18)) {
          *(undefined8 *)(puVar39 + -8) = 0x10388c;
          cVar8 = func_0x(0x11ad550);
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar39 + -8) = 0x103895;
            lVar21 = func_0x();
            if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
              *(undefined8 *)(puVar39 + -8) = 0x1038af;
              cVar8 = func_0x(0x11ad550);
              if (cVar8 == '\0') {
                *(undefined8 *)(puVar39 + -8) = 0x1038cb;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar39 + 0x20) = 0;
                *(undefined8 *)(puVar39 + -8) = 0x1038ee;
                (*_DAT_)(1,0xa9cf5c,0xbbd048,0x81d);
              }
            }
          }
          uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
          *(undefined8 *)(puVar39 + -8) = 0x1038fc;
          func_0x(uVar25,4);
          puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
        }
        uVar31 = *(uint *)(&stack0x00000030 + lVar18);
        puVar6 = puVar55;
        iVar41 = iVar16;
        if (*(short *)(&stack0x00000034 + lVar18) != 0) {
          do {
            uVar34 = puVar6[1] & 0x7fff;
            if ((uVar34 < uVar31) || (*(uint *)((longlong)&sStackX_18 + lVar18 + 4) < uVar34)) {
              *(undefined8 *)(puVar39 + -8) = 0x103940;
              cVar8 = func_0x(0x11ad550);
              if (cVar8 != '\0') {
                *(undefined8 *)(puVar39 + -8) = 0x103949;
                lVar21 = func_0x();
                if ((lVar21 != 0) && (*(char *)(lVar21 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar39 + -8) = 0x103963;
                  cVar8 = func_0x(0x11ad550);
                  if (cVar8 == '\0') {
                    *(undefined8 *)(puVar39 + -8) = 0x10397f;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar39 + 0x20) = 0;
                    *(undefined8 *)(puVar39 + -8) = 0x1039a3;
                    (*_DAT_)(1,0xa9cf5c,0xbbd048,0x82a);
                  }
                }
              }
              uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
              *(undefined8 *)(puVar39 + -8) = 0x1039b1;
              func_0x(uVar25,4);
              puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
            }
            iVar41 = iVar41 + 1;
            uVar31 = uVar34;
            puVar6 = puVar6 + 1;
          } while (iVar41 < (int)(uint)*(ushort *)(&stack0x00000034 + lVar18));
          ppuVar54 = *(uint ***)(&stack0x00000090 + lVar18);
        }
        while( true ) {
          uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
          if (-1 < (short)puVar55[(ulonglong)(uVar13 - 1) + 1]) break;
          if (uVar13 == 1) {
            uVar31 = *(uint *)(&stack0x00000030 + lVar18);
          }
          else {
            uVar31 = *(ushort *)
                      ((longlong)puVar47 +
                      (ulonglong)uVar13 * 2 + ((ulonglong)*(uint *)(&stack0x0000002c + lVar18) - 2))
                     & 0x7fff;
          }
          uVar34 = *(ushort *)
                    ((longlong)puVar47 +
                    (ulonglong)uVar13 * 2 + (ulonglong)*(uint *)(&stack0x0000002c + lVar18)) &
                   0x7fff;
          if (((uVar31 < *(uint *)(&stack0x00000030 + lVar18)) || (uVar34 < uVar31)) ||
             (*(uint *)((longlong)&sStackX_18 + lVar18 + 4) < uVar34)) {
            *(undefined8 *)(puVar39 + -8) = 0x103a2d;
            func_0x(puVar47,7);
            puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
          }
          if ((uVar31 < *(uint *)(&stack0x00000030 + lVar18)) ||
             (*(uint *)((longlong)&sStackX_18 + lVar18 + 4) < uVar31)) goto LAB_;
          if (*(ushort *)((longlong)puVar47 + (ulonglong)uVar31) == 5) {
            puVar55 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
            *puVar55 = *puVar55 | 2;
            *(short *)(&stack0x00000034 + lVar18) = *(short *)(&stack0x00000034 + lVar18) + -1;
            uVar13 = *(ushort *)(&stack0x00000044 + lVar18);
            uVar33 = (ulonglong)(uVar31 & 0xffff);
            pbVar28 = (byte *)((longlong)puVar47 + uVar33);
            *(short *)(&stack0x00000042 + lVar18) = (short)uVar31;
            if ((*(ushort *)(pbVar28 + 2) >> 0xe & 1) == 0) {
              uVar13 = uVar13 & 0xc7ff;
            }
            else {
              uVar13 = uVar13 ^ (*(ushort *)(pbVar28 + 2) ^ uVar13) & 0x3800;
            }
            *(ushort *)(&stack0x00000044 + lVar18) = uVar13;
            uVar12 = (uVar13 ^ *(ushort *)(pbVar28 + 2)) & 0x7ff ^ uVar13;
            *(ushort *)(&stack0x00000044 + lVar18) = uVar12;
            pbVar45 = (byte *)((longlong)puVar47 +
                              uVar33 + (ulonglong)((uVar12 & 0x7ff) * 2) + 4 +
                                       (ulonglong)((uVar13 >> 0xb & 7) * 2));
            if (pbVar45 < pbVar28) {
              *(undefined8 *)(puVar39 + -8) = 0x103b0e;
              func_0x(pbVar28,0x19);
              uVar12 = *(ushort *)(&stack0x00000044 + lVar18);
              uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
              puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
            }
            if (uVar34 - uVar31 <
                (((*(uint *)(&stack0x00000044 + lVar18) & 0x7ff) * 2 - (int)uVar33) -
                *(int *)((longlong)&puStackX_20 + lVar18)) + (int)pbVar45) {
              *(undefined8 *)(puVar39 + -8) = 0x103b44;
              func_0x((byte *)(uVar33 + (longlong)puVar47),0x19);
              uVar12 = *(ushort *)(&stack0x00000044 + lVar18);
              uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
              puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
            }
            if (((uVar12 & 0x3800) != 0) &&
               (puVar55 = (ushort *)((longlong)puVar47 + uVar33 + 4), (uVar12 & 0x3800) != 0)) {
              do {
                if ((uVar12 & 0x7ff) < (*puVar55 & 0x7ff)) {
                  *(undefined8 *)(puVar39 + -8) = 0x103ba5;
                  func_0x((byte *)(uVar33 + (longlong)puVar47),0x1a);
                  uVar12 = *(ushort *)(&stack0x00000044 + lVar18);
                  uVar33 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                  puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
                }
                iVar16 = iVar16 + 1;
                puVar55 = puVar55 + 1;
              } while (iVar16 < (int)(*(uint *)(&stack0x00000044 + lVar18) >> 0xb & 7));
            }
            break;
          }
          if (*(ushort *)((longlong)puVar47 + (ulonglong)uVar31) < 0x400) break;
          puVar6 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
          *puVar6 = *puVar6 | 1;
          psVar1 = (short *)(&stack0x00000034 + lVar18);
          *psVar1 = *psVar1 + -1;
          if (*psVar1 == 0) break;
        }
      }
      if ((*(byte *)puVar47 & 0x40) == 0) {
        *(undefined4 *)(&stack0x0000003e + lVar18) = 0;
      }
      else {
        uVar15 = *(undefined4 *)((longlong)&sStackX_18 + lVar18 + 4);
        piVar51 = (int *)((longlong)&sStackX_18 + lVar18 + 4);
        *piVar51 = *piVar51 + 0xe;
        *(undefined4 *)(&stack0x0000003e + lVar18) = uVar15;
        *(undefined8 *)(puVar39 + -8) = 0x103bfa;
        puVar26 = (ulonglong *)func_0x((longlong)&sStackX_18 + lVar18 + 2);
        uVar12 = (ushort)(*puVar26 >> 0x30);
        uVar13 = uVar12;
        if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
          uVar13 = uVar12 & 0xdfff;
          if ((uVar12 >> 0xe & 1) != 0) {
            uVar13 = uVar12 | 0x2000;
          }
        }
        if (uVar13 == 0xfffc) {
          iVar40 = (int)((*puVar26 >> 0x20 & 0xffff) >> 5);
        }
        piVar51 = (int *)((longlong)&sStackX_18 + lVar18 + 4);
        *piVar51 = *piVar51 + iVar40;
        puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
      }
      if ((*(byte **)(&stack0x00000036 + lVar18) != (byte *)0x0) &&
         (*(byte **)(&stack0x00000036 + lVar18) <
          (byte *)((ulonglong)*(uint *)((longlong)&sStackX_18 + lVar18 + 4) + (longlong)puVar47))) {
        *(undefined8 *)(puVar39 + -8) = 0x103c78;
        cVar8 = func_0x(0x11ad550);
        if (cVar8 != '\0') {
          *(undefined8 *)(puVar39 + -8) = 0x103c81;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar39 + -8) = 0x103c91;
            cVar8 = func_0x(0x11ad550);
            if (cVar8 == '\0') {
              *(undefined8 *)(puVar39 + -8) = 0x103cad;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x103cd0;
              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x886);
            }
          }
        }
        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
        *(undefined8 *)(puVar39 + -8) = 0x103cde;
        func_0x(uVar25,0x12);
        puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
      }
      if (0x3f3b < *(int *)((longlong)&sStackX_18 + lVar18 + 4) - 1U) {
        *(undefined8 *)(puVar39 + -8) = 0x103cfa;
        cVar8 = func_0x(0x11ad550);
        if (cVar8 != '\0') {
          *(undefined8 *)(puVar39 + -8) = 0x103d03;
          cVar8 = func_0x();
          if (cVar8 != '\0') {
            *(undefined8 *)(puVar39 + -8) = 0x103d13;
            cVar8 = func_0x(0x11ad550);
            if (cVar8 == '\0') {
              *(undefined8 *)(puVar39 + -8) = 0x103d2f;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(puVar39 + 0x20) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x103d52;
              (*_DAT_)(1,0xa9cf5c,0xbbd048,0x88b);
            }
          }
        }
        uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
        *(undefined8 *)(puVar39 + -8) = 0x103d60;
        func_0x(uVar25,5);
        puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
      }
LAB_:
      lVar44 = *(longlong *)(&stack0x00000070 + lVar18);
    }
    if ((8 < *(uint *)((longlong)&sStackX_18 + lVar18 + 4)) ||
       ((uVar11 = 9, (*(byte *)puVar47 & 0xe) != 0 && ((*(byte *)puVar47 & 0xe) != 0xc)))) {
      uVar11 = (undefined2)*(undefined4 *)((longlong)&sStackX_18 + lVar18 + 4);
    }
    uVar31 = *(uint *)(&stack0x00000064 + lVar18);
  }
  else {
    if (*(int *)((longlong)&sStackX_18 + lVar18 + 4) == 0) {
      *(undefined8 *)(puVar39 + -8) = 0x103d97;
      func_0x((longlong)&sStackX_18 + lVar18 + 2);
      puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
      lVar44 = *(longlong *)(&stack0x00000070 + lVar18);
    }
    if ((8 < *(uint *)((longlong)&sStackX_18 + lVar18 + 4)) ||
       (((*(byte *)puVar47 & 0x1c) != 0 && ((*(byte *)puVar47 & 0x1c) != 0xc)))) {
      uVar11 = (undefined2)*(undefined4 *)((longlong)&sStackX_18 + lVar18 + 4);
    }
  }
  uVar34 = 0;
  *(undefined2 *)(lVar44 + 0x270) = uVar11;
  *(undefined4 *)(&stack0x00000088 + lVar18) = 0;
  if (uVar31 != 0) {
    do {
      puVar37 = (uint *)0x0;
      lVar21 = **(longlong **)(*(longlong *)(lVar44 + 0x188) + 0x160);
      puVar27 = *(uint **)(lVar21 + 0x38);
      puVar49 = (uint *)(lVar21 + 0x30);
      if (puVar27 == puVar49) {
        puVar27 = puVar37;
      }
      puVar56 = puVar37;
      if (puVar27 != (uint *)0x0) {
        puVar56 = puVar27 + -0x58;
      }
      if (uVar34 != 0) {
        uVar33 = (ulonglong)uVar34;
        do {
          puVar27 = *(uint **)(puVar56 + 0x5a);
          if (*(uint **)(puVar56 + 0x5a) == puVar49) {
            puVar27 = puVar37;
          }
          puVar56 = puVar37;
          if (puVar27 != (uint *)0x0) {
            puVar56 = puVar27 + -0x58;
          }
          uVar33 = uVar33 - 1;
        } while (uVar33 != 0);
      }
      bVar9 = *(byte *)(puVar56 + 8);
      uVar35 = 0;
      if (*psVar3 == 0) {
        uVar46 = *puVar56;
        if ((uVar46 & 0xc0000000) == 0x80000000) {
          *(undefined8 *)(puVar39 + -8) = 0x104759;
          iVar16 = func_0x((longlong)&sStackX_18 + lVar18 + 2);
          if (iVar16 == 0) {
            *(undefined4 *)(&stack0x00000050 + lVar18) = 0;
          }
          else {
            *(undefined8 *)(puVar39 + -8) = 0x104774;
            puVar37 = (uint *)func_0x(&stack0x00000042 + lVar18,puVar56,
                                              &stack0x00000050 + lVar18,&stack0x00000178 + lVar18);
          }
          goto LAB_;
        }
        if (((bVar9 & 2) == 0) && ((*(byte *)((longlong)puVar56 + 6) & 0x10) == 0)) {
LAB_:
          if ((int)uVar46 < 0) {
            if (*(int *)((longlong)&sStackX_18 + lVar18 + 4) == 0) {
              *(undefined4 *)(&stack0x0000002c + lVar18) =
                   *(undefined4 *)(&stack0x00000028 + lVar18);
              *(undefined2 *)((longlong)&sStackX_18 + lVar18 + 2) = 0;
              *(undefined8 *)(puVar39 + -8) = 0x104007;
              pbVar28 = (byte *)func_0x((longlong)&sStackX_18 + lVar18 + 2);
              if ((*pbVar28 & 0x10) != 0) {
                if ((**(byte **)((longlong)&puStackX_20 + lVar18) & 0x10) != 0) {
                  uVar35 = (uint)*(ushort *)
                                  (*(byte **)((longlong)&puStackX_20 + lVar18) +
                                  *(uint *)(&stack0x00000028 + lVar18));
                }
                *(uint *)(&stack0x0000002c + lVar18) =
                     (uVar35 + 7 >> 3) + *(int *)(&stack0x0000002c + lVar18) + 2;
              }
              *(undefined8 *)(puVar39 + -8) = 0x10403a;
              pbVar28 = (byte *)func_0x((longlong)&sStackX_18 + lVar18 + 2);
              if ((*pbVar28 & 0x20) == 0) {
                uVar15 = *(undefined4 *)(&stack0x0000002c + lVar18);
                *(undefined4 *)((longlong)&sStackX_18 + lVar18 + 4) = uVar15;
                *(undefined4 *)(&stack0x00000030 + lVar18) = uVar15;
                *(undefined2 *)(&stack0x00000034 + lVar18) = 0;
              }
              else {
                uVar31 = *(uint *)(&stack0x0000002c + lVar18);
                puVar55 = (ushort *)
                          ((ulonglong)uVar31 + *(longlong *)((longlong)&puStackX_20 + lVar18));
                *(ushort **)(&stack0x00000170 + lVar18) = puVar55;
                uVar13 = *puVar55;
                *(ushort *)(&stack0x00000034 + lVar18) = uVar13;
                if (uVar13 == 0) {
                  *(undefined8 *)(puVar39 + -8) = 0x10406d;
                  cVar8 = func_0x(0x11ad550);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar39 + -8) = 0x104076;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar39 + -8) = 0x104086;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x1040a2;
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar39 + 0x20) = 0;
                        *(undefined8 *)(puVar39 + -8) = 0x1040c5;
                        (*_DAT_)(1,0xa9cf5c,0xbbd048,0x80f);
                      }
                    }
                  }
                  uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                  *(undefined8 *)(puVar39 + -8) = 0x1040d3;
                  func_0x(uVar25,3);
                  uVar31 = *(uint *)(&stack0x0000002c + lVar18);
                }
                uVar31 = uVar31 + (*(ushort *)(&stack0x00000034 + lVar18) + 1) * 2;
                *(uint *)(&stack0x00000030 + lVar18) = uVar31;
                if (0x1f9e < uVar31) {
                  *(undefined8 *)(puVar39 + -8) = 0x1040f6;
                  cVar8 = func_0x(0x11ad550);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar39 + -8) = 0x1040ff;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar39 + -8) = 0x10410f;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x10412b;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar39 + 0x20) = 0;
                        *(undefined8 *)(puVar39 + -8) = 0x10414e;
                        (*_DAT_)(1,0xa9cf5c,0xbbd048,0x816);
                      }
                    }
                  }
                  uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                  *(undefined8 *)(puVar39 + -8) = 0x10415c;
                  func_0x(uVar25,4);
                  uVar31 = *(uint *)(&stack0x00000030 + lVar18);
                }
                uVar13 = puVar55[*(ushort *)(&stack0x00000034 + lVar18)];
                *(uint *)((longlong)&sStackX_18 + lVar18 + 4) = uVar13 & 0x7fff;
                if ((uVar13 & 0x7fff) < uVar31) {
                  *(undefined8 *)(puVar39 + -8) = 0x104182;
                  cVar8 = func_0x(0x11ad550);
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar39 + -8) = 0x10418b;
                    cVar8 = func_0x();
                    if (cVar8 != '\0') {
                      *(undefined8 *)(puVar39 + -8) = 0x10419b;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 == '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x1041b7;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar39 + 0x20) = 0;
                        *(undefined8 *)(puVar39 + -8) = 0x1041da;
                        (*_DAT_)(1,0xa9cf5c,0xbbd048,0x81d);
                      }
                    }
                  }
                  uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                  *(undefined8 *)(puVar39 + -8) = 0x1041e8;
                  func_0x(uVar25,4);
                  uVar31 = *(uint *)(&stack0x00000030 + lVar18);
                }
                if (*(short *)(&stack0x00000034 + lVar18) != 0) {
                  do {
                    puVar55 = puVar55 + 1;
                    uVar34 = *puVar55 & 0x7fff;
                    if ((uVar34 < uVar31) ||
                       (*(uint *)((longlong)&sStackX_18 + lVar18 + 4) < uVar34)) {
                      *(undefined8 *)(puVar39 + -8) = 0x10422b;
                      cVar8 = func_0x(0x11ad550);
                      if (cVar8 != '\0') {
                        *(undefined8 *)(puVar39 + -8) = 0x104234;
                        cVar8 = func_0x();
                        if (cVar8 != '\0') {
                          *(undefined8 *)(puVar39 + -8) = 0x104244;
                          cVar8 = func_0x(0x11ad550);
                          if (cVar8 == '\0') {
                            *(undefined8 *)(puVar39 + -8) = 0x104260;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar39 + 0x20) = 0;
                            *(undefined8 *)(puVar39 + -8) = 0x104284;
                            (*_DAT_)(1,0xa9cf5c,0xbbd048,0x82a);
                          }
                        }
                      }
                      uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                      *(undefined8 *)(puVar39 + -8) = 0x104292;
                      func_0x(uVar25,4);
                    }
                    uVar35 = (int)puVar37 + 1;
                    puVar37 = (uint *)(ulonglong)uVar35;
                    uVar31 = uVar34;
                  } while ((int)uVar35 < (int)(uint)*(ushort *)(&stack0x00000034 + lVar18));
                  puVar55 = *(ushort **)(&stack0x00000170 + lVar18);
                  uVar34 = *(uint *)(&stack0x00000088 + lVar18);
                  ppuVar54 = *(uint ***)(&stack0x00000090 + lVar18);
                }
                while( true ) {
                  uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                  *(undefined8 *)(puVar39 + -8) = 0x1042cf;
                  iVar16 = func_0x(puVar55 + 1,uVar13 - 1);
                  if (iVar16 == 0) break;
                  uVar13 = *(ushort *)(&stack0x00000034 + lVar18);
                  puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
                  if (uVar13 == 1) {
                    uVar31 = *(uint *)(&stack0x00000030 + lVar18);
                  }
                  else {
                    uVar31 = *(ushort *)
                              ((longlong)puVar47 +
                              (ulonglong)uVar13 * 2 +
                              ((ulonglong)*(uint *)(&stack0x0000002c + lVar18) - 2)) & 0x7fff;
                  }
                  uVar35 = *(ushort *)
                            ((longlong)puVar47 +
                            (ulonglong)uVar13 * 2 + (ulonglong)*(uint *)(&stack0x0000002c + lVar18))
                           & 0x7fff;
                  if (((uVar31 < *(uint *)(&stack0x00000030 + lVar18)) || (uVar35 < uVar31)) ||
                     (*(uint *)((longlong)&sStackX_18 + lVar18 + 4) < uVar35)) {
                    *(undefined8 *)(puVar39 + -8) = 0x10431e;
                    func_0x(puVar47,7);
                    puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
                  }
                  if ((uVar31 < *(uint *)(&stack0x00000030 + lVar18)) ||
                     (*(uint *)((longlong)&sStackX_18 + lVar18 + 4) < uVar31)) goto LAB_;
                  uVar13 = *(ushort *)((longlong)puVar47 + (ulonglong)uVar31);
                  if (uVar13 == 5) {
                    puVar55 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                    *puVar55 = *puVar55 | 2;
                    *(short *)(&stack0x00000034 + lVar18) =
                         *(short *)(&stack0x00000034 + lVar18) + -1;
                    *(short *)(&stack0x00000042 + lVar18) = (short)uVar31;
                    pbVar28 = (byte *)(((ulonglong)uVar31 & 0xffff) + (longlong)puVar47);
                    *(undefined8 *)(puVar39 + -8) = 0x104385;
                    iVar16 = func_0x(pbVar28);
                    if (iVar16 == 0) {
                      *(ushort *)(&stack0x00000044 + lVar18) =
                           *(ushort *)(&stack0x00000044 + lVar18) & 0xc7ff;
                    }
                    else {
                      *(undefined8 *)(puVar39 + -8) = 0x104391;
                      sVar10 = func_0x(pbVar28);
                      *(ushort *)(&stack0x00000044 + lVar18) =
                           *(ushort *)(&stack0x00000044 + lVar18) ^
                           (sVar10 << 0xb ^ *(ushort *)(&stack0x00000044 + lVar18)) & 0x3800;
                    }
                    *(undefined8 *)(puVar39 + -8) = 0x1043c6;
                    uVar12 = func_0x(pbVar28);
                    uVar52 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                    uVar13 = *(ushort *)(&stack0x00000044 + lVar18);
                    uVar12 = (uVar12 ^ *(ushort *)(&stack0x00000044 + lVar18)) & 0x7ff ^ uVar13;
                    uVar36 = (ulonglong)uVar12;
                    *(ushort *)(&stack0x00000044 + lVar18) = uVar12;
                    lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                    uVar33 = (ulonglong)((uVar13 >> 0xb & 7) * 2) + lVar21 +
                             ((uVar36 & 0x7ff) + 2) * 2 + uVar52;
                    if (uVar33 < lVar21 + uVar52) {
                      *(undefined8 *)(puVar39 + -8) = 0x10441e;
                      func_0x(lVar21 + uVar52,0x19);
                      uVar36 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                      uVar52 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                      lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                    }
                    if (uVar35 - uVar31 <
                        (((*(uint *)(&stack0x00000044 + lVar18) & 0x7ff) * 2 - (int)uVar52) -
                        *(int *)((longlong)&puStackX_20 + lVar18)) + (int)uVar33) {
                      *(undefined8 *)(puVar39 + -8) = 0x104453;
                      func_0x(uVar52 + lVar21,0x19);
                      uVar36 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar18);
                      uVar52 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar18);
                      lVar21 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                    }
                    if ((uVar36 & 0x3800) != 0) {
                      iVar16 = 0;
                      if ((uVar36 & 0x3800) != 0) {
                        do {
                          *(undefined8 *)(puVar39 + -8) = 0x10448b;
                          uVar13 = func_0x(uVar52 + lVar21 + 4,iVar16);
                          if ((*(ushort *)(&stack0x00000044 + lVar18) & 0x7ff) < uVar13) {
                            uVar13 = *(ushort *)(&stack0x00000042 + lVar18);
                            lVar44 = *(longlong *)((longlong)&puStackX_20 + lVar18);
                            *(undefined8 *)(puVar39 + -8) = 0x1044a9;
                            func_0x((ulonglong)uVar13 + lVar44,0x1a);
                          }
                          iVar16 = iVar16 + 1;
                        } while (iVar16 < (int)(*(uint *)(&stack0x00000044 + lVar18) >> 0xb & 7));
                      }
                    }
                    break;
                  }
                  if (uVar13 < 0x400) break;
                  puVar6 = (ushort *)((longlong)&sStackX_18 + lVar18 + 2);
                  *puVar6 = *puVar6 | 1;
                  psVar1 = (short *)(&stack0x00000034 + lVar18);
                  *psVar1 = *psVar1 + -1;
                  if (*psVar1 == 0) break;
                }
              }
              *(undefined8 *)(puVar39 + -8) = 0x1044d7;
              iVar16 = func_0x((longlong)&sStackX_18 + lVar18 + 2);
              if (iVar16 == 0) {
                *(undefined4 *)(&stack0x0000003e + lVar18) = 0;
              }
              else {
                iVar16 = *(int *)((longlong)&sStackX_18 + lVar18 + 4);
                *(int *)(&stack0x0000003e + lVar18) = iVar16;
                *(int *)((longlong)&sStackX_18 + lVar18 + 4) = iVar16 + 0xe;
                *(undefined8 *)(puVar39 + -8) = 0x1044f0;
                puVar26 = (ulonglong *)func_0x((longlong)&sStackX_18 + lVar18 + 2);
                iVar16 = 0;
                uVar12 = (ushort)(*puVar26 >> 0x30);
                uVar13 = uVar12;
                if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
                  uVar13 = uVar12 & 0xdfff;
                  if ((uVar12 >> 0xe & 1) != 0) {
                    uVar13 = uVar12 | 0x2000;
                  }
                }
                if (uVar13 == 0xfffc) {
                  iVar16 = (int)((*puVar26 >> 0x20 & 0xffff) >> 5);
                }
                piVar51 = (int *)((longlong)&sStackX_18 + lVar18 + 4);
                *piVar51 = *piVar51 + iVar16;
              }
              puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
              if ((*(byte **)(&stack0x00000036 + lVar18) != (byte *)0x0) &&
                 (*(byte **)(&stack0x00000036 + lVar18) <
                  (byte *)((ulonglong)*(uint *)((longlong)&sStackX_18 + lVar18 + 4) +
                          (longlong)puVar47))) {
                *(undefined8 *)(puVar39 + -8) = 0x10457c;
                cVar8 = func_0x(0x11ad550);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar39 + -8) = 0x104585;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar39 + -8) = 0x104595;
                    cVar8 = func_0x(0x11ad550);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar39 + -8) = 0x1045b1;
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar39 + 0x20) = 0;
                      *(undefined8 *)(puVar39 + -8) = 0x1045d7;
                      (*_DAT_)(1,0xa9cf5c,0xbbd048,0x886);
                    }
                  }
                }
                uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                *(undefined8 *)(puVar39 + -8) = 0x1045e5;
                func_0x(uVar25,0x12);
                puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
              }
              if (0x3f3b < *(int *)((longlong)&sStackX_18 + lVar18 + 4) - 1U) {
                *(undefined8 *)(puVar39 + -8) = 0x104601;
                cVar8 = func_0x(0x11ad550);
                if (cVar8 != '\0') {
                  *(undefined8 *)(puVar39 + -8) = 0x10460a;
                  cVar8 = func_0x();
                  if (cVar8 != '\0') {
                    *(undefined8 *)(puVar39 + -8) = 0x10461a;
                    cVar8 = func_0x(0x11ad550);
                    if (cVar8 == '\0') {
                      *(undefined8 *)(puVar39 + -8) = 0x104636;
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar39 + 0x20) = 0;
                      *(undefined8 *)(puVar39 + -8) = 0x10465c;
                      (*_DAT_)(1,0xa9cf5c,0xbbd048,0x88b);
                    }
                  }
                }
                uVar25 = *(undefined8 *)((longlong)&puStackX_20 + lVar18);
                *(undefined8 *)(puVar39 + -8) = 0x10466a;
                func_0x(uVar25,5);
                puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
              }
            }
LAB_:
            sVar10 = -*(short *)puVar56;
            if ((*(byte *)((longlong)puVar56 + 6) & 0x10) != 0) {
              if ((*(byte *)puVar47 & 0x10) == 0) {
                if ((1 << (*(byte *)puVar47 & 0xe) & 0x1105U) != 0) {
LAB_:
                  uVar31 = *(uint *)(&stack0x00000064 + lVar18);
                  puVar37 = *(undefined4 **)(puVar56 + 2) + 1;
                  *(undefined4 *)(&stack0x00000050 + lVar18) = **(undefined4 **)(puVar56 + 2);
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(&stack0x00000028 + lVar18) <= (int)*puVar56) ||
                      (*(ushort *)
                        ((ulonglong)*(uint *)(&stack0x00000028 + lVar18) + (longlong)puVar47) <
                       *(ushort *)(puVar56 + 1))) goto LAB_;
            }
            if ((uint)*(ushort *)(&stack0x00000034 + lVar18) < (uint)(int)sVar10) {
              uVar31 = *(uint *)(&stack0x00000064 + lVar18);
              *(undefined4 *)(&stack0x00000050 + lVar18) = 0;
              puVar37 = puVar47;
            }
            else {
              if (sVar10 == 1) {
                uVar35 = *(uint *)(&stack0x00000030 + lVar18);
              }
              else {
                uVar35 = *(ushort *)
                          ((longlong)puVar47 +
                          (longlong)sVar10 * 2 +
                          ((ulonglong)*(uint *)(&stack0x0000002c + lVar18) - 2)) & 0x7fff;
              }
              uVar31 = *(ushort *)
                        ((longlong)puVar47 +
                        (longlong)sVar10 * 2 + (ulonglong)*(uint *)(&stack0x0000002c + lVar18)) &
                       0x7fff;
              if (((uVar35 < *(uint *)(&stack0x00000030 + lVar18)) || (uVar31 < uVar35)) ||
                 (*(uint *)((longlong)&sStackX_18 + lVar18 + 4) < uVar31)) {
                *(undefined8 *)(puVar39 + -8) = 0x10471e;
                func_0x(puVar47,7);
                puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
              }
              *(uint *)(&stack0x00000050 + lVar18) = uVar31 - uVar35;
              uVar31 = *(uint *)(&stack0x00000064 + lVar18);
              puVar37 = (uint *)((ulonglong)uVar35 + (longlong)puVar47);
            }
          }
          else {
            uVar13 = *(ushort *)((longlong)puVar56 + 6);
            if ((uVar13 & 8) == 0) {
              uVar35 = (uint)*(ushort *)(puVar56 + 0xe);
              if ((uVar13 & 0x10) != 0) {
                if ((*(byte *)puVar47 & 0x10) == 0) {
                  if ((1 << (*(byte *)puVar47 & 0xe) & 0x1105U) != 0) {
LAB_:
                    puVar37 = *(uint **)(puVar56 + 2);
                    uVar31 = *puVar37;
                    if ((uVar35 != 0) && (uVar31 != uVar35)) {
                      *(undefined8 *)(puVar39 + 0x20) = 0;
                      *(undefined8 *)(puVar39 + -8) = 0x103fb0;
                      (*_DAT_)(1,0xc4b3a0,0xc49d08,0x381);
                      puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
                    }
                    *(uint *)(&stack0x00000050 + lVar18) = uVar31;
                    uVar31 = *(uint *)(&stack0x00000064 + lVar18);
                    puVar37 = puVar37 + 1;
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(&stack0x00000028 + lVar18) <= (int)uVar46) ||
                        (*(ushort *)
                          ((ulonglong)*(uint *)(&stack0x00000028 + lVar18) + (longlong)puVar47) <
                         *(ushort *)(puVar56 + 1))) goto LAB_;
              }
              uVar31 = *(uint *)(&stack0x00000064 + lVar18);
              *(uint *)(&stack0x00000050 + lVar18) = uVar35;
              puVar37 = (uint *)((longlong)(int)*puVar56 + (longlong)puVar47);
            }
            else {
              bVar9 = *(byte *)((longlong)puVar47 + (longlong)(int)uVar46);
              uVar31 = *(uint *)(&stack0x00000064 + lVar18);
              puVar37 = (uint *)0x821bf0;
              *(undefined4 *)(&stack0x00000050 + lVar18) = 1;
              if ((bVar9 & (byte)(1 << ((byte)uVar13 & 7))) == 0) {
                puVar37 = (uint *)0x821bf1;
              }
            }
          }
        }
        else if ((*(byte *)puVar47 & 0x10) == 0) {
          if ((1 << (*(byte *)puVar47 & 0xe) & 0x1105U) != 0) goto LAB_;
          puVar27 = (uint *)0x1;
          puVar49 = puVar37;
LAB_:
          uVar31 = (uint)puVar49;
          iVar16 = (int)puVar27;
          if ((bVar9 & 2) != 0) goto LAB_;
LAB_:
          if ((iVar16 != 0) || ((*(byte *)((longlong)puVar56 + 6) & 0x10) == 0)) goto LAB_;
          puVar22 = *(undefined4 **)(puVar56 + 2);
          uVar31 = *(uint *)(&stack0x00000064 + lVar18);
          *(undefined4 *)(&stack0x00000050 + lVar18) = *puVar22;
          puVar37 = puVar22 + 1;
        }
        else {
          if (*(int *)(&stack0x00000028 + lVar18) <= (int)uVar46) {
LAB_:
            puVar49 = (uint *)(ulonglong)(~(uint)(*(ushort *)((longlong)puVar56 + 6) >> 4) & 1);
            puVar27 = puVar37;
            goto LAB_;
          }
          if ((uint)*(ushort *)((ulonglong)*(uint *)(&stack0x00000028 + lVar18) + (longlong)puVar47)
              < (uint)*(ushort *)(puVar56 + 1)) goto LAB_;
          if ((bVar9 & 2) == 0) goto LAB_;
          uVar31 = *(ushort *)(puVar56 + 1) - 1;
          iVar16 = 1;
          uVar31 = *(byte *)((longlong)puVar47 +
                            (ulonglong)*(uint *)(&stack0x00000028 + lVar18) +
                            (ulonglong)(uVar31 >> 3) + 2) >> ((byte)uVar31 & 7) & 1;
LAB_:
          if (uVar31 == 0) goto LAB_;
          uVar31 = *(uint *)(&stack0x00000064 + lVar18);
          *(undefined4 *)(&stack0x00000050 + lVar18) = 0;
        }
      }
      else {
        *(undefined4 *)(&stack0x00000088 + lVar18) = 0;
        *(undefined **)(puVar39 + 0x20) = &stack0x00000088 + lVar18;
        *(undefined8 *)(puVar39 + -8) = 0x10479a;
        puVar37 = (uint *)func_0x((longlong)&sStackX_18 + lVar18 + 2,puVar56,puVar49,
                                          &stack0x00000050 + lVar18);
        if ((((*psVar3 != 0) &&
             (plVar4 = *(longlong **)(&stack0x00000028 + lVar18), plVar4 != (longlong *)0x0)) &&
            (*plVar4 != 0)) &&
           (((*(byte *)((longlong)puVar56 + 6) & 8) == 0 &&
            ((*(uint *)(&stack0x00000088 + lVar18) & 1) == 0)))) {
          if ((puVar37 == (uint *)0x0) || (puVar37 == (uint *)0x821bf0)) {
            puVar37 = (uint *)0x0;
            *(undefined4 *)(&stack0x00000050 + lVar18) = 0;
          }
          else {
            uVar15 = *(undefined4 *)(&stack0x00000050 + lVar18);
            *(uint *)(puVar39 + 0x38) = *(uint *)(&stack0x00000088 + lVar18);
            *(undefined **)(puVar39 + 0x30) = &stack0x00000050 + lVar18;
            *(undefined4 *)(puVar39 + 0x28) = 0;
            *(undefined8 *)(puVar39 + 0x20) = 0;
            *(undefined8 *)(puVar39 + -8) = 0x1047f2;
            puVar37 = (uint *)func_0x(plVar4,puVar56,puVar37,uVar15);
          }
        }
LAB_:
        puVar47 = *(uint **)((longlong)&puStackX_20 + lVar18);
      }
LAB_:
      puVar5 = *(undefined2 **)(&stack0x00000078 + lVar18);
      uVar34 = uVar34 + 1;
      uVar11 = *(undefined2 *)(&stack0x00000050 + lVar18);
      lVar44 = *(longlong *)(&stack0x00000070 + lVar18);
      *ppuVar54 = puVar37;
      ppuVar54 = ppuVar54 + 1;
      *puVar5 = uVar11;
      *(uint ***)(&stack0x00000090 + lVar18) = ppuVar54;
      *(undefined2 **)(&stack0x00000078 + lVar18) = puVar5 + 1;
      *(uint *)(&stack0x00000088 + lVar18) = uVar34;
    } while (uVar34 < uVar31);
  }
  lVar21 = *(longlong *)(&stack0x00000070 + lVar18);
  lVar44 = *(longlong *)(&stack0x000000a0 + lVar18);
  iVar16 = *(int *)(&stack0x00000060 + lVar18);
  *(short *)(lVar21 + 0x276) = (short)iVar16;
  bVar9 = *(byte *)(lVar44 + 0x106) & 0x40;
  if ((bVar9 == 0) && ((*(byte *)(lVar44 + 0x108) & 8) == 0)) {
    uVar25 = *(undefined8 *)(&stack0x00000058 + lVar18);
    uVar15 = (undefined4)uVar25;
LAB_:
    if ((*(byte *)(lVar44 + 0x108) & 8) != 0) goto LAB_;
LAB_:
    uVar17 = 0;
  }
  else {
    if (iVar16 == 0) {
      uVar25 = *(undefined8 *)(&stack0x00000058 + lVar18);
      uVar15 = (undefined4)uVar25;
    }
    else {
      uVar25 = *(undefined8 *)(lVar21 + 0x230);
      uVar15 = *(undefined4 *)(lVar21 + 0x238);
    }
    if (bVar9 == 0) goto LAB_;
LAB_:
    if (iVar16 == 0) goto LAB_;
    uVar17 = 1;
  }
  uVar24 = *(undefined8 *)(lVar21 + 0x200);
  *(undefined4 *)(puVar39 + 0x28) = uVar15;
  *(undefined8 *)(puVar39 + 0x20) = uVar25;
  *(undefined8 *)(puVar39 + -8) = 0x1048ca;
  func_0x(uVar24,lVar21 + 600,&stack0x00000238 + lVar18,uVar17);
LAB_:
  *(longlong *)(lVar21 + 0x240) = *(longlong *)(lVar21 + 0x240) + 1;
  if (*(longlong **)(&stack0x000001f0 + lVar18) != (longlong *)0x0) {
    **(longlong **)(&stack0x000001f0 + lVar18) = lVar21 + 0x38;
  }
  uVar33 = *(ulonglong *)(&stack0x00005768 + lVar18);
  *(undefined8 *)(puVar39 + -8) = 0x1048f5;
  func_0x(uVar33 ^ (ulonglong)psVar3);
  return;
}

