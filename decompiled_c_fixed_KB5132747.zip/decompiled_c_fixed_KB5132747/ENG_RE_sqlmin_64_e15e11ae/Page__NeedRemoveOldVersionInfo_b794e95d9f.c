
longlong FUN_(longlong param_1,undefined8 param_2)

{
  byte bVar1;
  byte bVar2;
  bool bVar3;
  undefined8 *puVar4;
  int iVar5;
  ushort uVar6;
  uint uVar7;
  ushort uVar9;
  ushort *puVar10;
  undefined8 uStackX_10;
  ushort uStack_66;
  undefined4 uStack_64;
  byte *pbStack_60;
  undefined8 uStack_58;
  short sStack_50;
  short sStack_4e;
  short sStack_4c;
  undefined2 uStack_4a;
  undefined6 uStack_48;
  undefined2 uStack_42;
  undefined2 uStack_40;
  undefined6 uStack_3e;
  uint uStack_38;
  undefined8 *puVar8;
  
  uStack_4a = 0;
  uStack_48 = 0;
  uStack_3e = 0;
  uStack_58 = 0;
  if (*(short *)(param_1 + 0x16) == 0) {
    return 0xffffff00;
  }
  puVar10 = (ushort *)(param_1 + 0x1ffe);
  puVar8 = (undefined8 *)0x0;
  uStackX_10 = param_2;
  do {
    uVar9 = *puVar10;
    if (uVar9 != 0) {
      pbStack_60 = (byte *)((ulonglong)uVar9 + param_1);
      bVar1 = *(byte *)((ulonglong)uVar9 + param_1);
      if ((bVar1 & 1) == 0) {
        bVar2 = bVar1 >> 6;
      }
      else {
        bVar2 = bVar1 >> 1;
      }
      if ((bVar2 & 1) != 0) {
        if ((bVar1 & 1) == 0) {
          bVar3 = false;
          uStack_64 = 0;
          uStack_42 = 0;
          uStack_40 = 0;
          uVar7 = (uint)*(ushort *)(param_1 + 0xe);
          switch(*pbStack_60 & 0xe) {
          default:
            uVar7 = (uint)*(ushort *)(pbStack_60 + 2);
            if (0x1f9d < *(ushort *)(pbStack_60 + 2) - 1) {
              func_0x(pbStack_60,6);
            }
            break;
          case 4:
            uVar7 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar7 = 1;
          }
          uStack_58 = CONCAT44(uStack_58._4_4_,uVar7);
          uStack_4a = (undefined2)(param_1 + 0x2000);
          uStack_48 = (undefined6)((ulonglong)(param_1 + 0x2000) >> 0x10);
        }
        else {
          bVar3 = true;
          bVar1 = *pbStack_60;
          switch(bVar1 & 0x1c) {
          default:
            if ((char)pbStack_60[1] < '\0') {
              sStack_50 = 3;
              uStack_66 = (*(ushort *)(pbStack_60 + 1) & 0x7f) << 8 |
                          *(ushort *)(pbStack_60 + 1) >> 8;
            }
            else {
              uStack_66 = (ushort)pbStack_60[1];
              sStack_50 = 2;
            }
            sStack_4c = (short)(uStack_66 + 1 >> 1) + sStack_50;
            if (uStack_66 < 0x1f) {
              sStack_4e = 0;
              uStack_40 = (undefined2)(param_1 + 0x2000);
              uStack_3e = (undefined6)((ulonglong)(param_1 + 0x2000) >> 0x10);
              uStack_64 = 0;
              uStack_38 = 0;
              uStack_58 = 0;
            }
            else {
              iVar5 = uStack_66 - 1;
              uStack_64 = 0;
              uStack_38 = 0;
              uStack_58 = 0;
              sStack_4e = ((short)(iVar5 / 0x1e) + (short)(iVar5 >> 0x1f)) -
                          (short)((longlong)iVar5 * 0x88888889 >> 0x3f);
              uStack_40 = (undefined2)(param_1 + 0x2000);
              uStack_3e = (undefined6)((ulonglong)(param_1 + 0x2000) >> 0x10);
            }
            break;
          case 4:
            if (((bVar1 & 0x1c) == 4) && ((bVar1 & 2) != 0)) {
              sStack_50 = 0;
              sStack_4e = 0;
              sStack_4c = 0;
              uStack_4a = 0;
              uStack_40 = (undefined2)(param_1 + 0x2000);
              uStack_3e = (undefined6)((ulonglong)(param_1 + 0x2000) >> 0x10);
              uStack_66 = 0;
              uStack_48 = 0;
              uStack_42 = 0;
              uStack_64 = 0xf;
              uStack_38 = 1;
              uStack_58 = 0;
            }
            else {
              sStack_50 = 0;
              sStack_4e = 0;
              sStack_4c = 0;
              uStack_4a = 0;
              uStack_40 = (undefined2)(param_1 + 0x2000);
              uStack_3e = (undefined6)((ulonglong)(param_1 + 0x2000) >> 0x10);
              uStack_66 = 0;
              uStack_48 = 0;
              uStack_42 = 0;
              uStack_64 = 1;
              uStack_38 = 0;
              uStack_58 = 0;
            }
            break;
          case 8:
            sStack_50 = 0;
            sStack_4e = 0;
            sStack_4c = 0;
            uStack_4a = 0;
            uStack_40 = (undefined2)(param_1 + 0x2000);
            uStack_3e = (undefined6)((ulonglong)(param_1 + 0x2000) >> 0x10);
            uStack_66 = 0;
            uStack_48 = 0;
            uStack_42 = 0;
            uStack_64 = 9;
            uStack_38 = 0;
            uStack_58 = 0;
          }
        }
        if (bVar3) {
          func_0x(&uStack_66);
          puVar4 = (undefined8 *)0x0;
          if ((*pbStack_60 & 2) != 0) {
            puVar4 = (undefined8 *)(pbStack_60 + uStack_38);
          }
        }
        else {
          puVar4 = (undefined8 *)func_0x();
        }
        if (bVar3) {
          func_0x(&uStack_66,&uStackX_10);
        }
        else {
          func_0x();
        }
        if ((uStackX_10._4_2_ != 0) || ((int)uStackX_10 != 0)) {
          uVar9 = (ushort)((ulonglong)*puVar4 >> 0x30);
          if ((int)*puVar4 < 0) {
            uVar6 = uVar9;
            if ((((uint)(int)(short)uVar9 >> 1 ^ (int)(short)uVar9) & 0x2000) != 0) {
              uVar6 = uVar9 & 0xdfff;
              if ((uVar9 >> 0xe & 1) != 0) {
                uVar6 = uVar9 | 0x2000;
              }
            }
            if (uVar6 == 0xfffc) {
              (*pcRam0000000000fc12b0)(1,0x14eded0,0x14c7640,0x4ec,0);
            }
          }
          else {
            uVar6 = uVar9;
            if ((((uint)(int)(short)uVar9 >> 1 ^ (int)(short)uVar9) & 0x2000) != 0) {
              uVar6 = uVar9 & 0xdfff;
              if ((uVar9 >> 0xe & 1) != 0) {
                uVar6 = uVar9 | 0x2000;
              }
            }
            if (uVar6 != 0xfffc) {
              return 1;
            }
          }
        }
      }
    }
    uVar7 = (int)puVar8 + 1;
    puVar8 = (undefined8 *)(ulonglong)uVar7;
    puVar10 = puVar10 + -1;
    if ((int)(uint)*(ushort *)(param_1 + 0x16) <= (int)uVar7) {
      return (ulonglong)(byte)(*(ushort *)(param_1 + 0x16) >> 8) << 8;
    }
  } while( true );
}

