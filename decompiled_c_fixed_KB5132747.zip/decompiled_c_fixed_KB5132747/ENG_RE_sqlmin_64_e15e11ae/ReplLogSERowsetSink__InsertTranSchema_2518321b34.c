
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined2 param_2,undefined8 param_3)

{
  longlong lVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  ulonglong uVar6;
  undefined4 uVar7;
  undefined auStack_f8 [32];
  undefined8 uStack_d8;
  undefined4 auStack_c8 [2];
  undefined8 uStack_c0;
  longlong lStack_b8;
  undefined2 uStack_b0;
  undefined8 uStack_a8;
  int iStack_a0;
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  longlong lStack_58;
  uint uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  ulonglong uStack_38;
  ulonglong uVar5;
  
  uStack_c0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_f8;
  uVar7 = 0x35;
  if (*(int *)(param_1 + 0x24f8) == 0x34) {
    uVar7 = 0x34;
  }
  iVar2 = func_0x(param_2,0x1aaa9b0);
  if (iVar2 == 0) {
    func_0x(0x4977,0x10,3,0x1aaa9b0);
  }
  else {
    uVar6 = 0;
    lStack_b8 = 0;
    auStack_98 = ZEXT816(0);
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    auStack_68 = ZEXT816(0);
    lStack_58 = 0;
    uStack_50 = 0;
    uStack_48 = 0;
    uStack_40 = 0;
    uStack_b0 = param_2;
    uStack_a8 = param_3;
    iStack_a0 = iVar2;
    iVar2 = func_0x(&lStack_b8,3,2,0);
    if (iVar2 == 0) {
      func_0x(0x49aa,0x10,7,0x1aaa9b0);
    }
    else {
      auStack_c8[0] = 0;
      if ((((lStack_b8 != 0) && ((undefined4 *)(param_1 + 0x2510) != (undefined4 *)0x0)) &&
          (lStack_58 != 0)) &&
         (((uStack_50 != 0 &&
           (uVar3 = func_0x(&lStack_b8,0x1846550,auStack_c8), lStack_58 != 0)) &&
          ((uVar3 - 1 < 0xfffffffe && (uStack_50 != 0)))))) {
        uVar5 = uVar6;
        do {
          if (*(ulonglong *)(lStack_58 + uVar5 * 0x58) == (ulonglong)uVar3) {
            lVar1 = lStack_58 + uVar5 * 0x58;
            if (lVar1 != 0) {
              *(undefined8 *)(lStack_b8 + *(longlong *)(lVar1 + 0x10)) = 4;
              *(undefined4 *)(lStack_b8 + *(longlong *)(lVar1 + 8)) =
                   *(undefined4 *)(param_1 + 0x2510);
            }
            break;
          }
          uVar4 = (int)uVar5 + 1;
          uVar5 = (ulonglong)uVar4;
        } while (uVar4 < uStack_50);
      }
      auStack_c8[0] = 0;
      if (((lStack_b8 != 0) && (param_1 + 0x2524 != 0)) &&
         ((lStack_58 != 0 &&
          ((((uStack_50 != 0 &&
             (uVar3 = func_0x(&lStack_b8,0x1aaa9d0,auStack_c8), lStack_58 != 0)) &&
            (uVar3 - 1 < 0xfffffffe)) && (uStack_50 != 0)))))) {
        uVar5 = uVar6;
        do {
          if (*(ulonglong *)(lStack_58 + uVar5 * 0x58) == (ulonglong)uVar3) {
            lVar1 = lStack_58 + uVar5 * 0x58;
            if (lVar1 != 0) {
              *(undefined8 *)(lStack_b8 + *(longlong *)(lVar1 + 0x10)) = 10;
              func_0x(*(longlong *)(lVar1 + 8) + lStack_b8,param_1 + 0x2524,10);
            }
            break;
          }
          uVar4 = (int)uVar5 + 1;
          uVar5 = (ulonglong)uVar4;
        } while (uVar4 < uStack_50);
      }
      auStack_c8[0] = 0;
      if (((((lStack_b8 != 0) && (param_1 + 0x252e != 0)) &&
           ((lStack_58 != 0 &&
            ((uStack_50 != 0 &&
             (uVar3 = func_0x(&lStack_b8,0x1aaa9a0,auStack_c8), lStack_58 != 0)))))) &&
          (uVar3 - 1 < 0xfffffffe)) && (uStack_50 != 0)) {
        uVar5 = uVar6;
        do {
          if (*(ulonglong *)(lStack_58 + uVar5 * 0x58) == (ulonglong)uVar3) {
            lVar1 = lStack_58 + uVar5 * 0x58;
            if (lVar1 != 0) {
              *(undefined8 *)(lStack_b8 + *(longlong *)(lVar1 + 0x10)) = 10;
              func_0x(*(longlong *)(lVar1 + 8) + lStack_b8,param_1 + 0x252e,10);
            }
            break;
          }
          uVar4 = (int)uVar5 + 1;
          uVar5 = (ulonglong)uVar4;
        } while (uVar4 < uStack_50);
      }
      if (uStack_50 == 4) {
        auStack_c8[0] = 0;
        if ((((lStack_b8 != 0) && (lStack_58 != 0)) &&
            (uVar3 = func_0x(&lStack_b8,0x1aaa978,auStack_c8), lStack_58 != 0)) &&
           ((uVar3 - 1 < 0xfffffffe && (uStack_50 != 0)))) {
          do {
            if (*(ulonglong *)(uVar6 * 0x58 + lStack_58) == (ulonglong)uVar3) {
              lVar1 = lStack_58 + uVar6 * 0x58;
              if (lVar1 != 0) {
                *(undefined8 *)(lStack_b8 + *(longlong *)(lVar1 + 0x10)) = 4;
                *(undefined4 *)(lStack_b8 + *(longlong *)(lVar1 + 8)) = uVar7;
              }
              break;
            }
            uVar4 = (int)uVar6 + 1;
            uVar6 = (ulonglong)uVar4;
          } while (uVar4 < uStack_50);
        }
        uStack_d8 = auStack_c8;
        iVar2 = (**(code **)(*(longlong *)auStack_68._0_8_ + 0x28))
                          (auStack_68._0_8_,0,uStack_48,lStack_b8);
        if (iVar2 != 0) {
          uStack_d8 = (undefined4 *)CONCAT44(uStack_d8._4_4_,iVar2);
          (*_DAT_)(0xbc,2,0x10,1);
        }
      }
    }
    func_0x(&lStack_b8);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_f8);
  return;
}

