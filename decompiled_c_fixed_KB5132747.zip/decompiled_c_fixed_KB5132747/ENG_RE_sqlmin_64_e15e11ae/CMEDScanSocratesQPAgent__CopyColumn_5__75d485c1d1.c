
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined4 *puVar2;
  longlong lVar3;
  
  lVar3 = (ulonglong)*(uint *)(param_1 + 0x6c) * 0x50 +
          *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x20);
  switch(param_3) {
  case 1:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 8;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x10;
    return;
  case 2:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 1;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x4a;
    return;
  case 3:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x28;
    return;
  case 4:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x2c;
    return;
  case 5:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x30;
    return;
  case 6:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x34;
    return;
  case 7:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 2;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x40;
    return;
  case 8:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 8;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x18;
    return;
  case 9:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 1;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x4b;
    return;
  case 10:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 1;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x4c;
    return;
  case 0xb:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 2;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x42;
    return;
  case 0xc:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 4;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x38;
    return;
  case 0xd:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 2;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x44;
    return;
  case 0xe:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 2;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x46;
    return;
  case 0xf:
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4) = 2;
    *(longlong *)(*(longlong *)(param_1 + 0x18) + (param_2 & 0xffffffff) * 8) = lVar3 + 0x48;
    return;
  case 0x10:
    lVar1 = (param_2 & 0xffffffff) * 8;
    puVar2 = (undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4);
    if (*(char *)(lVar3 + 0x4d) == '\0') {
      *puVar2 = 0x10;
      *(longlong *)(lVar1 + *(longlong *)(param_1 + 0x18)) = lVar3;
      return;
    }
    break;
  case 0x11:
    lVar1 = (param_2 & 0xffffffff) * 8;
    puVar2 = (undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4);
    if (*(char *)(lVar3 + 0x4e) == '\0') {
      *puVar2 = 8;
      *(longlong *)(lVar1 + *(longlong *)(param_1 + 0x18)) = lVar3 + 0x20;
      return;
    }
    break;
  case 0x12:
    lVar1 = (param_2 & 0xffffffff) * 8;
    puVar2 = (undefined4 *)(*(longlong *)(param_1 + 0x10) + (param_2 & 0xffffffff) * 4);
    if (*(char *)(lVar3 + 0x4f) == '\0') {
      *puVar2 = 4;
      *(longlong *)(lVar1 + *(longlong *)(param_1 + 0x18)) = lVar3 + 0x3c;
      return;
    }
    break;
  default:
    (*_DAT_)(1,0,0x23afef8,0x3fe,0x21c64c8);
    return;
  }
  *puVar2 = 0;
  *(undefined8 *)(lVar1 + *(longlong *)(param_1 + 0x18)) = 0;
  return;
}

