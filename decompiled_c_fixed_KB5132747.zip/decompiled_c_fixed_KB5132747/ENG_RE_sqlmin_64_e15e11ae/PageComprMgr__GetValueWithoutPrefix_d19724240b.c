
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ushort * FUN_(byte **param_1,undefined (*param_2) [16],ushort *param_3,uint param_4,
                     byte param_5,uint *param_6,uint *param_7)

{
  ushort *puVar1;
  longlong *plVar2;
  bool bVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  int iVar7;
  byte *pbVar8;
  longlong lVar9;
  undefined8 uVar10;
  uint uVar11;
  short sVar12;
  uint uVar13;
  ulonglong uVar14;
  ushort *puVar15;
  ushort *puVar16;
  byte *pbVar17;
  byte *pbVar18;
  ushort uVar19;
  uint uVar20;
  undefined4 auStackX_18 [2];
  uint auStackX_20 [2];
  ushort *puStack_58;
  undefined auStack_50 [6];
  byte bStack_4a;
  longlong lStack_48;
  
  pbVar18 = (byte *)0x0;
  *param_6 = 0;
  *param_7 = param_4;
  if ((param_3 == (ushort *)0x0) || (param_3 == (ushort *)0x14d8a80)) {
    *param_7 = 0;
    return (ushort *)0x0;
  }
  if ((param_5 & 4) != 0) {
    bVar4 = *(byte *)param_3;
    puVar1 = (ushort *)param_1[10];
    if (bVar4 == 0) {
      param_3 = (ushort *)(param_1[9] + (uint)*(ushort *)(param_1 + 0xb));
      uVar13 = (uint)*puVar1 - (uint)*(ushort *)(param_1 + 0xb);
    }
    else {
      param_3 = (ushort *)(param_1[9] + (uint)puVar1[(ulonglong)bVar4 - 1]);
      uVar13 = (uint)puVar1[bVar4] - (uint)puVar1[(ulonglong)bVar4 - 1];
    }
    *param_7 = uVar13;
  }
  if ((**param_1 & 2) == 0) {
    return param_3;
  }
  _auStack_50 = *param_2;
  uVar19 = SUB162(_auStack_50,6);
  if ((SUB168(_auStack_50,0) >> 0x30 & 0x10) != 0) {
    uVar19 = uVar19 & 0xffef;
    _auStack_50 = SUB168(_auStack_50,0) & 0xffefffffffffffff;
    lStack_48 = 0;
  }
  auStackX_20[0] = param_4;
  if (param_1[1] != (byte *)0x0) {
    pbVar8 = (byte *)func_0x(param_1[1] + 0x18,auStack_50,auStackX_18);
    goto LAB_;
  }
  puVar1 = (ushort *)((longlong)param_1 + 0x12);
  if (*(short *)(param_1 + 2) != 0) {
    auStackX_20[0] = 0;
    pbVar17 = (byte *)func_0x(puVar1,auStack_50,uVar19,auStackX_18,auStackX_20);
    pbVar8 = pbVar17;
    if ((((((*(short *)(param_1 + 2) != 0) &&
           (plVar2 = (longlong *)param_1[4], plVar2 != (longlong *)0x0)) && (*plVar2 != 0)) &&
         (((_auStack_50 & (undefined  [16])0x8000000000000) == (undefined  [16])0x0 &&
          ((auStackX_20[0] & 1) == 0)))) && (pbVar8 = pbVar18, pbVar17 != (byte *)0x0)) &&
       (pbVar17 != (byte *)0x14d8a80)) {
      pbVar8 = (byte *)func_0x
                                 (plVar2,auStack_50,pbVar17,auStackX_18[0],0,0,auStackX_18,
                                  auStackX_20[0]);
    }
    goto LAB_;
  }
  if ((auStack_50._0_4_ & 0xc0000000) == 0x80000000) {
    iVar7 = func_0x(puVar1);
    pbVar8 = (byte *)0x0;
    if (iVar7 != 0) {
      pbVar8 = (byte *)func_0x((longlong)param_1 + 0x3a,auStack_50,auStackX_18,auStackX_20);
    }
    goto LAB_;
  }
  pbVar17 = param_1[3];
  bVar4 = *pbVar17;
  bVar3 = false;
  if ((bVar4 & 0x10) == 0) {
    if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
      uVar19 = ~(uVar19 >> 4);
      bVar3 = false;
      goto LAB_;
    }
  }
  else {
    uVar13 = *(uint *)(param_1 + 4);
    if ((int)auStack_50._0_4_ < (int)uVar13) {
      if ((uint)*(ushort *)(pbVar17 + uVar13) < (uint)(ushort)auStack_50._4_2_) {
        uVar19 = ~(uVar19 >> 4);
      }
      else {
        uVar11 = (ushort)auStack_50._4_2_ - 1;
        bVar3 = true;
        uVar19 = (ushort)(pbVar17[(ulonglong)(uVar11 >> 3) + (ulonglong)uVar13 + 2] >>
                         ((byte)uVar11 & 7));
      }
    }
    else {
      uVar19 = ~(uVar19 >> 4);
    }
LAB_:
    pbVar8 = pbVar18;
    if ((uVar19 & 1) != 0) goto LAB_;
    if ((!bVar3) && ((_auStack_50 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0)) {
      pbVar8 = (byte *)(lStack_48 + 4);
      goto LAB_;
    }
  }
  if (-1 < (int)auStack_50._0_4_) {
    if ((_auStack_50 & (undefined  [16])0x8000000000000) != (undefined  [16])0x0) {
      pbVar8 = (byte *)0x14d8a80;
      if ((pbVar17[(int)auStack_50._0_4_] & (byte)(1 << (bStack_4a & 7))) == 0) {
        pbVar8 = (byte *)0x14d8a81;
      }
      goto LAB_;
    }
    if ((_auStack_50 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
          pbVar8 = (byte *)(lStack_48 + 4);
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_1 + 4) <= (int)auStack_50._0_4_) ||
              (*(ushort *)(pbVar17 + *(uint *)(param_1 + 4)) < (ushort)auStack_50._4_2_))
      goto LAB_;
    }
    pbVar8 = pbVar17 + (int)auStack_50._0_4_;
    goto LAB_;
  }
  if (*(int *)((longlong)param_1 + 0x14) == 0) {
    uVar13 = *(uint *)(param_1 + 4);
    uVar14 = (ulonglong)uVar13;
    *(uint *)((longlong)param_1 + 0x24) = uVar13;
    *puVar1 = 0;
    bVar4 = *pbVar17;
    if ((bVar4 & 0x10) != 0) {
      uVar13 = uVar13 + 2 + (*(ushort *)(pbVar17 + uVar14) + 7 >> 3);
      uVar14 = (ulonglong)uVar13;
      *(uint *)((longlong)param_1 + 0x24) = uVar13;
      bVar4 = *pbVar17;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)((longlong)param_1 + 0x14) = (int)uVar14;
      *(undefined2 *)((longlong)param_1 + 0x2c) = 0;
      *(int *)(param_1 + 5) = (int)uVar14;
    }
    else {
      puVar15 = (ushort *)(pbVar17 + uVar14);
      uVar19 = *puVar15;
      *(ushort *)((longlong)param_1 + 0x2c) = uVar19;
      puStack_58 = puVar15;
      if (uVar19 == 0) {
        cVar5 = func_0x(0x1e643e0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1e643e0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x1753dec,0x1873ed8,0x80f,0);
          }
        }
        func_0x(param_1[3],3);
        uVar19 = *(ushort *)((longlong)param_1 + 0x2c);
        uVar14 = (ulonglong)*(uint *)((longlong)param_1 + 0x24);
      }
      uVar13 = (int)uVar14 + (uVar19 + 1) * 2;
      *(uint *)(param_1 + 5) = uVar13;
      if (0x1f9e < uVar13) {
        cVar5 = func_0x(0x1e643e0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1e643e0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1753dec,0x1873ed8,0x816,0);
          }
        }
        func_0x(param_1[3],4);
        uVar19 = *(ushort *)((longlong)param_1 + 0x2c);
        uVar13 = *(uint *)(param_1 + 5);
      }
      uVar14 = (ulonglong)uVar19;
      uVar19 = puVar15[uVar14];
      *(uint *)((longlong)param_1 + 0x14) = uVar19 & 0x7fff;
      if ((uVar19 & 0x7fff) < uVar13) {
        cVar5 = func_0x(0x1e643e0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1e643e0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1753dec,0x1873ed8,0x81d,0);
          }
        }
        func_0x(param_1[3],4);
        uVar13 = *(uint *)(param_1 + 5);
        uVar14 = (ulonglong)*(ushort *)((longlong)param_1 + 0x2c);
      }
      puVar16 = puVar15;
      pbVar8 = pbVar18;
      if ((short)uVar14 != 0) {
        do {
          puVar15 = puVar15 + 1;
          uVar11 = *puVar15 & 0x7fff;
          if ((uVar11 < uVar13) || (*(uint *)((longlong)param_1 + 0x14) < uVar11)) {
            cVar5 = func_0x(0x1e643e0);
            if ((cVar5 != '\0') &&
               ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x1e643e0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x1753dec,0x1873ed8,0x82a,0);
              }
            }
            func_0x(param_1[3],4);
          }
          uVar14 = (ulonglong)*(ushort *)((longlong)param_1 + 0x2c);
          uVar20 = (int)pbVar8 + 1;
          puVar16 = puStack_58;
          pbVar8 = (byte *)(ulonglong)uVar20;
          uVar13 = uVar11;
        } while ((int)uVar20 < (int)(uint)*(ushort *)((longlong)param_1 + 0x2c));
      }
      puVar15 = puStack_58;
      if ((short)puVar16[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
        pbVar17 = param_1[3];
        do {
          uVar13 = *(ushort *)
                    (pbVar17 + uVar14 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x24)) & 0x7fff
          ;
          if ((int)uVar14 == 1) {
            uVar11 = *(uint *)(param_1 + 5);
            uVar20 = uVar11;
LAB_:
            if ((uVar13 < uVar11) || (*(uint *)((longlong)param_1 + 0x14) < uVar13))
            goto LAB_;
          }
          else {
            uVar20 = *(uint *)(param_1 + 5);
            uVar11 = *(ushort *)
                      (pbVar17 + uVar14 * 2 + ((ulonglong)*(uint *)((longlong)param_1 + 0x24) - 2))
                     & 0x7fff;
            if (uVar20 <= uVar11) goto LAB_;
LAB_:
            func_0x(pbVar17,7);
            uVar20 = *(uint *)(param_1 + 5);
          }
          if ((uVar11 < uVar20) || (*(uint *)((longlong)param_1 + 0x14) < uVar11))
          goto LAB_;
          pbVar17 = param_1[3];
          if (*(ushort *)(pbVar17 + uVar11) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)((longlong)param_1 + 0x2c) = *(short *)((longlong)param_1 + 0x2c) + -1;
            uVar19 = *(ushort *)((longlong)param_1 + 0x3c) & 0xc7ff;
            uVar14 = (ulonglong)(uVar11 & 0xffff);
            *(short *)((longlong)param_1 + 0x3a) = (short)uVar11;
            pbVar8 = param_1[3];
            if ((*(ushort *)(pbVar8 + uVar14 + 2) >> 0xe & 1) != 0) {
              uVar19 = *(ushort *)(pbVar8 + uVar14 + 2) & 0x3800 | uVar19;
            }
            *(ushort *)((longlong)param_1 + 0x3c) = uVar19;
            uVar6 = (uVar19 ^ *(ushort *)(pbVar8 + uVar14 + 2)) & 0x7ff ^ uVar19;
            *(ushort *)((longlong)param_1 + 0x3c) = uVar6;
            pbVar17 = pbVar8 + uVar14 + (ulonglong)((uVar6 & 0x7ff) * 2) + 4 +
                                        (ulonglong)((uVar19 >> 0xb & 7) * 2);
            if (pbVar17 < pbVar8 + uVar14) {
              func_0x(pbVar8 + uVar14,0x19);
              uVar6 = *(ushort *)((longlong)param_1 + 0x3c);
              uVar14 = (ulonglong)*(ushort *)((longlong)param_1 + 0x3a);
              pbVar8 = (byte *)(ulonglong)*(uint *)(param_1 + 3);
            }
            if (uVar13 - uVar11 < (((uVar6 & 0x7ff) * 2 - (int)uVar14) - (int)pbVar8) + (int)pbVar17
               ) {
              func_0x(param_1[3] + uVar14,0x19);
              uVar6 = *(ushort *)((longlong)param_1 + 0x3c);
            }
            if (((uVar6 & 0x3800) != 0) &&
               (puVar15 = (ushort *)
                          (param_1[3] + (ulonglong)*(ushort *)((longlong)param_1 + 0x3a) + 4),
               (uVar6 & 0x3800) != 0)) {
              do {
                if ((uVar6 & 0x7ff) < (*puVar15 & 0x7ff)) {
                  func_0x(param_1[3] + *(ushort *)((longlong)param_1 + 0x3a),0x1a);
                  uVar6 = *(ushort *)((longlong)param_1 + 0x3c);
                }
                uVar13 = (int)pbVar18 + 1;
                pbVar18 = (byte *)(ulonglong)uVar13;
                puVar15 = puVar15 + 1;
              } while ((int)uVar13 < (int)(uVar6 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar17 + uVar11) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar19 = *(short *)((longlong)param_1 + 0x2c) - 1;
          *(ushort *)((longlong)param_1 + 0x2c) = uVar19;
          if (uVar19 == 0) goto LAB_;
          uVar14 = (ulonglong)uVar19;
        } while ((short)puVar15[(ulonglong)(uVar19 - 1) + 1] < 0);
        uVar14 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
      }
      else {
LAB_:
        pbVar17 = param_1[3];
        uVar14 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
      }
    }
    if ((*pbVar17 & 0x40) == 0) {
      *(undefined4 *)((longlong)param_1 + 0x36) = 0;
    }
    else {
      *(int *)((longlong)param_1 + 0x36) = (int)uVar14;
      *(int *)((longlong)param_1 + 0x14) = (int)uVar14 + 0xe;
      uVar10 = func_0x(puVar1);
      func_0x(uVar10,&puStack_58);
      iVar7 = func_0x(&puStack_58);
      *(int *)((longlong)param_1 + 0x14) = *(int *)((longlong)param_1 + 0x14) + iVar7;
      uVar14 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
    }
    iVar7 = (int)uVar14;
    if ((*(byte **)((longlong)param_1 + 0x2e) != (byte *)0x0) &&
       (*(byte **)((longlong)param_1 + 0x2e) < param_1[3] + uVar14)) {
      cVar5 = func_0x(0x1e643e0);
      if ((cVar5 != '\0') &&
         ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))) {
        cVar5 = func_0x(0x1e643e0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x1753dec,0x1873ed8,0x886,0);
        }
      }
      func_0x(param_1[3],0x12);
      iVar7 = *(int *)((longlong)param_1 + 0x14);
    }
    if (0x3f3b < iVar7 - 1U) {
      cVar5 = func_0x(0x1e643e0);
      if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
         (*(char *)(lVar9 + 0x499) != '\0')) {
        cVar5 = func_0x(0x1e643e0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x1753dec,0x1873ed8,0x88b,0);
        }
      }
      func_0x(param_1[3],5);
    }
  }
LAB_:
  sVar12 = -auStack_50._0_2_;
  param_4 = auStackX_20[0];
  if ((_auStack_50 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
    bVar4 = *param_1[3];
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
        pbVar8 = (byte *)(lStack_48 + 4);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(param_1 + 4) <= (int)auStack_50._0_4_) ||
            (*(ushort *)(param_1[3] + *(uint *)(param_1 + 4)) < (ushort)auStack_50._4_2_))
    goto LAB_;
  }
  pbVar8 = param_1[3];
  if ((uint)*(ushort *)((longlong)param_1 + 0x2c) < (uint)(int)sVar12) goto LAB_;
  if (sVar12 == 1) {
    uVar13 = *(uint *)(param_1 + 5);
LAB_:
    if (((*(ushort *)
           (pbVar8 + (longlong)sVar12 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x24)) & 0x7fff
         ) < uVar13) ||
       (*(uint *)((longlong)param_1 + 0x14) <
        (*(ushort *)(pbVar8 + (longlong)sVar12 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x24))
        & 0x7fff))) goto LAB_;
  }
  else {
    uVar13 = *(ushort *)
              (pbVar8 + (longlong)sVar12 * 2 + ((ulonglong)*(uint *)((longlong)param_1 + 0x24) - 2))
             & 0x7fff;
    if (*(uint *)(param_1 + 5) <= uVar13) goto LAB_;
LAB_:
    func_0x(pbVar8,7);
    pbVar8 = param_1[3];
  }
  pbVar8 = pbVar8 + uVar13;
  param_4 = auStackX_20[0];
LAB_:
  if ((pbVar8 != (byte *)0x0) && (param_4 != 0)) {
    bVar4 = *(byte *)param_3;
    uVar13 = *param_7;
    if ((char)bVar4 < '\0') {
      uVar19 = *param_3;
      param_3 = param_3 + 1;
      uVar11 = (uVar19 & 0x7f) << 8 | (uint)(uVar19 >> 8);
      *param_6 = uVar11;
      *param_7 = (uVar13 - 2) + uVar11;
    }
    else {
      *param_6 = (uint)bVar4;
      param_3 = (ushort *)((longlong)param_3 + 1);
      *param_7 = (uint)bVar4 + (uVar13 - 1);
    }
  }
  return param_3;
}

