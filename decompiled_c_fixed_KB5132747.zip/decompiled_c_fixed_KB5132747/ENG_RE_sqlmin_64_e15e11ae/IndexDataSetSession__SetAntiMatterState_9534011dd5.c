
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,undefined param_3)

{
  undefined2 uVar1;
  uint *puVar2;
  code *pcVar3;
  char *pcVar4;
  ushort *puVar5;
  byte bVar6;
  char cVar7;
  int iVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong lVar11;
  undefined8 uVar12;
  ulonglong uVar13;
  uint uVar14;
  byte *pbVar15;
  ulonglong uVar16;
  uint uVar17;
  undefined8 unaff_RDI;
  ulonglong uVar18;
  undefined4 uVar19;
  short sVar20;
  ushort uVar21;
  ushort uVar22;
  uint uVar23;
  undefined8 unaff_R12;
  ushort *puVar24;
  ulonglong uVar25;
  undefined8 unaff_R14;
  uint uVar26;
  undefined8 unaff_R15;
  undefined8 auStackX_8 [2];
  uint auStackX_18 [2];
  undefined auStackX_20 [8];
  longlong lStack_2028;
  undefined auStack_2020 [8];
  longlong lStack_2018;
  undefined auStack_2010 [8];
  undefined auStack_2008 [16];
  undefined8 uStack_1ff8;
  undefined auStack_1fe8 [8096];
  ulonglong uStack_48;
  undefined8 uStack_28;
  
  uStack_28 = 0x100018;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffe0 + lVar9);
  uVar13 = 0;
  auStackX_20[lVar9] = param_3;
  uStack_1ff8 = 0;
  *(undefined8 *)(&stack0x00000030 + lVar9) = 0;
  *(undefined4 *)(&stack0x0000002c + lVar9) = 0;
  *(undefined8 *)(&stack0x00000046 + lVar9) = 0;
  *(undefined8 *)(&stack0x00000050 + lVar9) = 0;
  auStack_2008 = ZEXT816(0);
  *(undefined8 *)(&stack0x00000038 + lVar9) = 0;
  *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100072;
  lStack_2018 = param_1;
  func_0x(auStack_1fe8,0,0x1f9e);
  lVar11 = *(longlong *)(*(longlong *)(param_1 + 0x10) + 8);
  if ((((*(byte *)(lVar11 + 0x41) & 8) != 0) || ((*(byte *)(lVar11 + 0x108) & 0x40) != 0)) &&
     (*(longlong **)(lVar11 + 0x160) != (longlong *)0x0)) {
    lVar11 = **(longlong **)(lVar11 + 0x160);
    uVar14 = *(uint *)(lVar11 + 100);
    if (uVar14 != 0xffffffff) {
      puVar2 = *(uint **)(lVar11 + 8);
      if (uVar14 < *puVar2) {
        uVar18 = (ulonglong)uVar14 / (ulonglong)puVar2[9];
        uVar14 = uVar14 % puVar2[9];
        lVar11 = *(longlong *)(puVar2 + 4);
      }
      else {
        uVar18 = (ulonglong)(uVar14 - *puVar2) / (ulonglong)puVar2[0x11];
        uVar14 = (uVar14 - *puVar2) % puVar2[0x11];
        lVar11 = *(longlong *)(puVar2 + 0xc);
      }
      lStack_2028 = (ulonglong)uVar14 * 0x1c0 + *(longlong *)(lVar11 + uVar18 * 8);
      if (lStack_2028 != 0) {
        *(uint *)(param_2 + 2) = *(uint *)(param_2 + 2) & 0xfffffeff;
        uVar14 = *(uint *)(param_2 + 2);
        *(undefined8 *)(&stack0x00002058 + lVar9) = unaff_R14;
        if (((char)uVar14 < '\0') || ((*(byte *)((longlong)param_2 + 0x34) & 1) == 0)) {
          *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x10012d;
          plVar10 = (longlong *)func_0x(param_2,0);
        }
        else if ((uVar14 >> 0xd & 1) == 0) {
          plVar10 = param_2 + 9;
        }
        else {
          plVar10 = (longlong *)param_2[0x29];
        }
        sVar20 = *(short *)plVar10;
        *(short *)(&stack0x00000028 + lVar9) = sVar20;
        if (sVar20 == 0) {
          uVar14 = *(uint *)((longlong)plVar10 + 4);
          *(undefined8 *)(&stack0x000020a8 + lVar9) = unaff_RDI;
          *(undefined8 *)(&stack0x00002050 + lVar9) = unaff_R15;
          if (uVar14 == 0) {
            pbVar15 = (byte *)plVar10[1];
            uVar14 = *(uint *)(plVar10 + 2);
            uVar18 = (ulonglong)uVar14;
            *(short *)((longlong)plVar10 + 2) = 0;
            *(uint *)((longlong)plVar10 + 0x14) = uVar14;
            bVar6 = *pbVar15;
            if ((bVar6 & 0x10) != 0) {
              uVar14 = uVar14 + 2 + (*(ushort *)(pbVar15 + uVar18) + 7 >> 3);
              uVar18 = (ulonglong)uVar14;
              *(uint *)((longlong)plVar10 + 0x14) = uVar14;
              bVar6 = *pbVar15;
            }
            iVar8 = (int)uVar18;
            *(undefined8 *)(&stack0x00002060 + lVar9) = unaff_R12;
            if ((bVar6 & 0x20) == 0) {
              *(int *)((longlong)plVar10 + 4) = iVar8;
              *(short *)((longlong)plVar10 + 0x1c) = 0;
              *(int *)(plVar10 + 3) = iVar8;
            }
            else {
              puVar24 = (ushort *)(pbVar15 + uVar18);
              uVar21 = *puVar24;
              *(ushort *)((longlong)plVar10 + 0x1c) = uVar21;
              if (uVar21 == 0) {
                *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1001c6;
                cVar7 = func_0x(0x1f43130);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1001cf;
                  lVar11 = func_0x();
                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1001e9;
                    cVar7 = func_0x(0x1f43130);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100205;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(auStackX_20 + lVar9 + -0x20) = 0;
                      *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x10022b;
                      (*_DAT_)(1,0x1832b3c,0x1952c28,0x80f);
                    }
                  }
                }
                lVar11 = plVar10[1];
                *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100239;
                func_0x(lVar11,3);
                iVar8 = *(int *)((longlong)plVar10 + 0x14);
                pbVar15 = (byte *)plVar10[1];
                uVar21 = *(ushort *)((longlong)plVar10 + 0x1c);
              }
              uVar14 = iVar8 + (uVar21 + 1) * 2;
              *(uint *)(plVar10 + 3) = uVar14;
              if (0x1f9e < uVar14) {
                *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x10026e;
                cVar7 = func_0x(0x1f43130);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100277;
                  lVar11 = func_0x();
                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100291;
                    cVar7 = func_0x(0x1f43130);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1002ad;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(auStackX_20 + lVar9 + -0x20) = 0;
                      *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1002d3;
                      (*_DAT_)(1,0x1832b3c,0x1952c28,0x816);
                    }
                  }
                }
                lVar11 = plVar10[1];
                *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1002e1;
                func_0x(lVar11,4);
                uVar21 = *(ushort *)((longlong)plVar10 + 0x1c);
                pbVar15 = (byte *)plVar10[1];
                uVar14 = *(uint *)(plVar10 + 3);
              }
              uVar18 = (ulonglong)uVar21;
              uVar21 = puVar24[uVar18];
              *(uint *)((longlong)plVar10 + 4) = uVar21 & 0x7fff;
              if ((uVar21 & 0x7fff) < uVar14) {
                *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100315;
                cVar7 = func_0x(0x1f43130);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x10031e;
                  lVar11 = func_0x();
                  if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100338;
                    cVar7 = func_0x(0x1f43130);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100354;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(auStackX_20 + lVar9 + -0x20) = 0;
                      *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x10037a;
                      (*_DAT_)(1,0x1832b3c,0x1952c28,0x81d);
                    }
                  }
                }
                lVar11 = plVar10[1];
                *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100388;
                func_0x(lVar11,4);
                uVar14 = *(uint *)(plVar10 + 3);
                uVar18 = (ulonglong)*(ushort *)((longlong)plVar10 + 0x1c);
                pbVar15 = (byte *)plVar10[1];
              }
              puVar5 = puVar24;
              if ((short)uVar18 != 0) {
                do {
                  uVar17 = puVar5[1] & 0x7fff;
                  if ((uVar17 < uVar14) || (*(uint *)((longlong)plVar10 + 4) < uVar17)) {
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1003d3;
                    cVar7 = func_0x(0x1f43130);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1003dc;
                      lVar11 = func_0x();
                      if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1003f6;
                        cVar7 = func_0x(0x1f43130);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100412;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(auStackX_20 + lVar9 + -0x20) = 0;
                          *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x10043c;
                          (*_DAT_)(1,0x1832b3c,0x1952c28,0x82a);
                        }
                      }
                    }
                    lVar11 = plVar10[1];
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x10044a;
                    func_0x(lVar11,4);
                  }
                  uVar18 = (ulonglong)*(ushort *)((longlong)plVar10 + 0x1c);
                  uVar26 = (int)uVar13 + 1;
                  uVar13 = (ulonglong)uVar26;
                  puVar5 = puVar5 + 1;
                  uVar14 = uVar17;
                } while ((int)uVar26 < (int)(uint)*(ushort *)((longlong)plVar10 + 0x1c));
                pbVar15 = (byte *)plVar10[1];
              }
              uVar13 = uVar18;
              if ((short)puVar24[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
                do {
                  sVar20 = (short)uVar18;
                  uVar17 = *(ushort *)
                            (pbVar15 + uVar13 * 2 + (ulonglong)*(uint *)((longlong)plVar10 + 0x14))
                           & 0x7fff;
                  if ((int)uVar13 == 1) {
                    uVar26 = *(uint *)(plVar10 + 3);
                    uVar23 = uVar26;
LAB_:
                    if ((uVar17 < uVar26) ||
                       (uVar14 = *(uint *)((longlong)plVar10 + 4), uVar14 < uVar17))
                    goto LAB_;
                  }
                  else {
                    uVar23 = *(uint *)(plVar10 + 3);
                    uVar26 = *(ushort *)
                              (pbVar15 +
                              uVar13 * 2 + ((ulonglong)*(uint *)((longlong)plVar10 + 0x14) - 2)) &
                             0x7fff;
                    if (uVar23 <= uVar26) goto LAB_;
LAB_:
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1004e3;
                    func_0x(pbVar15,7);
                    uVar23 = *(uint *)(plVar10 + 3);
                    uVar14 = *(uint *)((longlong)plVar10 + 4);
                    pbVar15 = (byte *)plVar10[1];
                    sVar20 = *(short *)((longlong)plVar10 + 0x1c);
                  }
                  if ((uVar26 < uVar23) || (uVar14 < uVar26)) goto LAB_;
                  if (*(ushort *)(pbVar15 + uVar26) == 5) {
                    *(ushort *)((longlong)plVar10 + 2) = *(ushort *)((longlong)plVar10 + 2) | 2;
                    *(short *)((longlong)plVar10 + 0x1c) = sVar20 + -1;
                    uVar16 = (ulonglong)(uVar26 & 0xffff);
                    uVar18 = plVar10[1];
                    uVar13 = uVar16 + uVar18;
                    *(short *)((longlong)plVar10 + 0x2a) = (short)uVar26;
                    uVar21 = *(ushort *)((longlong)plVar10 + 0x2c) & 0xc7ff;
                    if ((*(ushort *)(uVar13 + 2) & 0x4000) != 0) {
                      uVar21 = *(ushort *)(uVar13 + 2) & 0x3800 | uVar21;
                    }
                    *(ushort *)((longlong)plVar10 + 0x2c) = uVar21;
                    uVar22 = (uVar21 ^ *(ushort *)(uVar13 + 2)) & 0x7ff ^ uVar21;
                    *(ushort *)((longlong)plVar10 + 0x2c) = uVar22;
                    uVar25 = (ulonglong)((uVar22 & 0x7ff) * 2) + 4 +
                             uVar16 + (uVar21 >> 0xb & 7) * 2 + uVar18;
                    if (uVar25 < uVar13) {
                      *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100604;
                      func_0x(uVar13,0x19);
                      uVar22 = *(ushort *)((longlong)plVar10 + 0x2c);
                      uVar16 = (ulonglong)*(ushort *)((longlong)plVar10 + 0x2a);
                      uVar18 = (ulonglong)*(uint *)(plVar10 + 1);
                    }
                    uVar14 = (uint)uVar22;
                    if (uVar17 - uVar26 <
                        (((uVar14 & 0x7ff) * 2 - (int)uVar16) - (int)uVar18) + (int)uVar25) {
                      lVar11 = plVar10[1];
                      *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100640;
                      func_0x(uVar16 + lVar11,0x19);
                      uVar14 = (uint)*(ushort *)((longlong)plVar10 + 0x2c);
                    }
                    if ((uVar14 & 0x3800) != 0) {
                      puVar24 = (ushort *)
                                (plVar10[1] + (ulonglong)*(ushort *)((longlong)plVar10 + 0x2a) + 4);
                      iVar8 = 0;
                      if ((uVar14 & 0x3800) != 0) {
                        do {
                          if (((ushort)uVar14 & 0x7ff) < (*puVar24 & 0x7ff)) {
                            uVar21 = *(ushort *)((longlong)plVar10 + 0x2a);
                            lVar11 = plVar10[1];
                            *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1006a7;
                            func_0x((ulonglong)uVar21 + lVar11,0x1a);
                            uVar14 = (uint)*(ushort *)((longlong)plVar10 + 0x2c);
                          }
                          iVar8 = iVar8 + 1;
                          puVar24 = puVar24 + 1;
                        } while (iVar8 < (int)(uVar14 >> 0xb & 7));
                      }
                    }
                    pbVar15 = (byte *)plVar10[1];
                    goto LAB_;
                  }
                  if (*(ushort *)(pbVar15 + uVar26) < 0x400) goto LAB_;
                  *(ushort *)((longlong)plVar10 + 2) = *(ushort *)((longlong)plVar10 + 2) | 1;
                  uVar21 = sVar20 - 1;
                  *(ushort *)((longlong)plVar10 + 0x1c) = uVar21;
                  if (uVar21 == 0) goto LAB_;
                  uVar18 = (ulonglong)uVar21;
                  uVar13 = (ulonglong)(uint)uVar21;
                } while ((short)puVar24[(ulonglong)(uVar21 - 1) + 1] < 0);
                uVar18 = (ulonglong)*(uint *)((longlong)plVar10 + 4);
              }
              else {
LAB_:
                uVar18 = (ulonglong)*(uint *)((longlong)plVar10 + 4);
              }
            }
            if ((*pbVar15 & 0x40) == 0) {
              *(undefined4 *)((longlong)plVar10 + 0x26) = 0;
            }
            else {
              *(int *)((longlong)plVar10 + 0x26) = (int)uVar18;
              *(int *)((longlong)plVar10 + 4) = (int)uVar18 + 0xe;
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1006fe;
              uVar12 = func_0x((short *)((longlong)plVar10 + 2));
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x10070a;
              func_0x(uVar12,auStack_2020);
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100713;
              iVar8 = func_0x(auStack_2020);
              *(int *)((longlong)plVar10 + 4) = *(int *)((longlong)plVar10 + 4) + iVar8;
              uVar18 = (ulonglong)*(uint *)((longlong)plVar10 + 4);
              pbVar15 = (byte *)plVar10[1];
            }
            uVar14 = (uint)uVar18;
            if ((*(byte **)((longlong)plVar10 + 0x1e) != (byte *)0x0) &&
               (*(byte **)((longlong)plVar10 + 0x1e) < pbVar15 + uVar18)) {
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100750;
              cVar7 = func_0x(0x1f43130);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100759;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100773;
                  cVar7 = func_0x(0x1f43130);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x10078f;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(auStackX_20 + lVar9 + -0x20) = 0;
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1007b5;
                    (*_DAT_)(1,0x1832b3c,0x1952c28,0x886);
                  }
                }
              }
              lVar11 = plVar10[1];
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1007c3;
              func_0x(lVar11,0x12);
              uVar14 = *(uint *)((longlong)plVar10 + 4);
            }
            if ((uVar14 == 0) || (0x3f3c < uVar14)) {
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1007e3;
              cVar7 = func_0x(0x1f43130);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1007ec;
                lVar11 = func_0x();
                if ((lVar11 != 0) && (*(char *)(lVar11 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100806;
                  cVar7 = func_0x(0x1f43130);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100822;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(auStackX_20 + lVar9 + -0x20) = 0;
                    *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100848;
                    (*_DAT_)(1,0x1832b3c,0x1952c28,0x88b);
                  }
                }
              }
              lVar11 = plVar10[1];
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100856;
              func_0x(lVar11,5);
              uVar14 = *(uint *)((longlong)plVar10 + 4);
            }
          }
LAB_:
          if ((uVar14 < 9) &&
             (((*(byte *)plVar10[1] & 0xe) == 0 || ((*(byte *)plVar10[1] & 0xe) == 0xc)))) {
            uVar14 = 9;
          }
          *(undefined4 *)(&stack0x00000038 + lVar9) = *(undefined4 *)(plVar10 + 2);
          *(short *)(&stack0x0000002a + lVar9) = *(short *)((longlong)plVar10 + 2);
          *(undefined4 *)(&stack0x0000002c + lVar9) = *(undefined4 *)((longlong)plVar10 + 4);
          *(short *)(&stack0x00000044 + lVar9) = *(short *)((longlong)plVar10 + 0x1c);
          *(undefined4 *)(&stack0x0000003c + lVar9) = *(undefined4 *)((longlong)plVar10 + 0x14);
          *(undefined4 *)(&stack0x00000040 + lVar9) = *(undefined4 *)(plVar10 + 3);
          *(undefined4 *)(&stack0x0000004e + lVar9) = *(undefined4 *)((longlong)plVar10 + 0x26);
          lVar11 = plVar10[1];
          *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1008ce;
          func_0x(auStack_1fe8,0x1f9e,lVar11,uVar14);
          *(undefined **)(&stack0x00000030 + lVar9) = auStack_1fe8;
          *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1008e1;
          iVar8 = func_0x(&stack0x0000002a + lVar9);
          if (iVar8 != 0) {
            lVar11 = *(longlong *)(&stack0x00000030 + lVar9);
            puVar24 = (ushort *)((ulonglong)*(uint *)(&stack0x0000003c + lVar9) + lVar11);
            uVar14 = *puVar24 - 1;
            if (((&stack0x0000002a)[lVar9] & 1) == 0) {
              uVar14 = (uint)*puVar24;
            }
            uVar17 = *(uint *)(&stack0x00000040 + lVar9);
            if (uVar14 != 1) {
              uVar17 = puVar24[(longlong)(int)uVar14 + -1] & 0x7fff;
            }
            uVar14 = puVar24[(int)uVar14] & 0x7fff;
            if (((uVar17 < *(uint *)(&stack0x00000040 + lVar9)) || (uVar14 < uVar17)) ||
               (*(uint *)(&stack0x0000002c + lVar9) < uVar14)) {
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100946;
              func_0x(lVar11,7);
              lVar11 = *(longlong *)(&stack0x00000030 + lVar9);
            }
            uVar21 = *(ushort *)(&stack0x00000054 + lVar9);
            uVar18 = (ulonglong)(uVar17 & 0xffff);
            uVar13 = lVar11 + uVar18;
            *(short *)(&stack0x00000052 + lVar9) = (short)uVar17;
            if ((*(ushort *)(uVar13 + 2) & 0x4000) == 0) {
              uVar21 = uVar21 & 0xc7ff;
            }
            else {
              uVar21 = uVar21 ^ (uVar21 ^ *(ushort *)(uVar13 + 2)) & 0x3800;
            }
            *(ushort *)(&stack0x00000054 + lVar9) = uVar21;
            uVar22 = (uVar21 ^ *(ushort *)(uVar13 + 2)) & 0x7ff ^ uVar21;
            uVar25 = (ulonglong)uVar22;
            *(ushort *)(&stack0x00000054 + lVar9) = uVar22;
            uVar16 = (ulonglong)((uVar21 >> 0xb & 7) * 2) + 4 + lVar11 + (uVar25 & 0x7ff) * 2 +
                     uVar18;
            if (uVar16 < uVar13) {
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x1009df;
              func_0x(uVar13,0x19);
              uVar25 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar9);
              uVar18 = (ulonglong)*(ushort *)(&stack0x00000052 + lVar9);
              lVar11 = *(longlong *)(&stack0x00000030 + lVar9);
            }
            if (uVar14 - uVar17 <
                (((*(uint *)(&stack0x00000054 + lVar9) & 0x7ff) * 2 - (int)uVar18) -
                *(int *)(&stack0x00000030 + lVar9)) + (int)uVar16) {
              *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100a1a;
              func_0x(uVar18 + lVar11,0x19);
              uVar25 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar9);
              uVar18 = (ulonglong)*(ushort *)(&stack0x00000052 + lVar9);
              lVar11 = *(longlong *)(&stack0x00000030 + lVar9);
            }
            iVar8 = 0;
            if (((uVar25 & 0x3800) != 0) &&
               (puVar24 = (ushort *)(lVar11 + 4 + uVar18), (uVar25 & 0x3800) != 0)) {
              do {
                if (((ushort)uVar25 & 0x7ff) < (*puVar24 & 0x7ff)) {
                  *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100a85;
                  func_0x(uVar18 + lVar11,0x1a);
                  uVar25 = (ulonglong)*(ushort *)(&stack0x00000054 + lVar9);
                  uVar18 = (ulonglong)*(ushort *)(&stack0x00000052 + lVar9);
                  lVar11 = *(longlong *)(&stack0x00000030 + lVar9);
                }
                iVar8 = iVar8 + 1;
                puVar24 = puVar24 + 1;
              } while (iVar8 < (int)(*(uint *)(&stack0x00000054 + lVar9) >> 0xb & 7));
            }
          }
        }
        else if (((*(short *)plVar10 == 0) || ((longlong *)plVar10[2] == (longlong *)0x0)) ||
                (*(longlong *)plVar10[2] == 0)) {
          *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100af2;
          func_0x(&stack0x0000002a + lVar9,auStack_1fe8,0x1f9e,
                          (short *)((longlong)plVar10 + 2));
          if (*(short *)plVar10 != 0) {
            uVar13 = plVar10[2];
          }
          *(ulonglong *)(&stack0x00000038 + lVar9) = uVar13;
        }
        else {
          *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100ad8;
          func_0x(&stack0x00000028 + lVar9,auStack_1fe8,0x1f9e,plVar10);
        }
        lVar11 = lStack_2018;
        puVar2 = *(uint **)(lStack_2018 + 0x108);
        if (((*(byte *)(*(longlong *)(**(longlong **)(puVar2 + 8) + 8) + 0x107) & 0x40) == 0) ||
           ((*puVar2 & 0x1000000) != 0)) {
          uVar12 = 0;
        }
        else {
          uVar12 = 1;
        }
        *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100b5f;
        func_0x(param_2,puVar2 + 0x24,uVar12,auStack_2010);
        pcVar3 = *(code **)(*param_2 + 8);
        *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100b69;
        (*pcVar3)(param_2);
        uVar1 = *(undefined2 *)(lStack_2028 + 0x38);
        *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100b80;
        func_0x(&stack0x00000028 + lVar9,lStack_2028,auStackX_20 + lVar9,uVar1);
        pcVar4 = *(char **)(lVar11 + 0x380);
        if ((((pcVar4 == (char *)0x0) || (pcVar4[3] == '\0')) || (*pcVar4 == '\0')) ||
           (uVar19 = 2, pcVar4[1] == '\0')) {
          uVar19 = *(undefined4 *)(lVar11 + 0x2f0);
        }
        *(uint *)((longlong)auStackX_18 + lVar9) = **(uint **)(lVar11 + 0x108) >> 0x1b & 1;
        *(undefined8 *)((longlong)auStackX_8 + lVar9 + 8) = 0;
        *(undefined8 *)((longlong)auStackX_8 + lVar9) = 0;
        *(undefined **)(auStackX_20 + lVar9 + -0x20) = auStack_2010;
        *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100be0;
        func_0x(param_2,&stack0x00000028 + lVar9,uVar19,0);
      }
    }
  }
  *(undefined8 *)((longlong)&uStack_28 + lVar9) = 0x100bf7;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffe0 + lVar9));
  return;
}

