
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong *param_1)

{
  ushort *puVar1;
  uint uVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  undefined8 *puVar11;
  longlong lVar12;
  ulonglong uVar13;
  uint uVar14;
  ulonglong uVar15;
  uint uVar16;
  uint uVar17;
  ulonglong uVar18;
  byte *pbVar19;
  ulonglong uVar20;
  ushort *puVar21;
  uint uVar22;
  int iStackX_8;
  undefined8 uStackX_10;
  
  uVar2 = *(uint *)(param_1 + 2);
  uVar13 = 0;
  uVar16 = 0;
  if (*(uint *)((longlong)param_1 + 0xc) <= uVar2) {
    return 0;
  }
  lVar12 = param_1[4];
  puVar1 = (ushort *)(lVar12 + 2);
  if (*(int *)(lVar12 + 4) == 0) {
    pbVar19 = *(byte **)(lVar12 + 8);
    uVar14 = *(uint *)(lVar12 + 0x10);
    uVar15 = (ulonglong)uVar14;
    *puVar1 = 0;
    *(uint *)(lVar12 + 0x14) = uVar14;
    bVar4 = *pbVar19;
    if ((bVar4 & 0x10) != 0) {
      uVar14 = uVar14 + 2 + (*(ushort *)(pbVar19 + uVar15) + 7 >> 3);
      uVar15 = (ulonglong)uVar14;
      *(uint *)(lVar12 + 0x14) = uVar14;
      bVar4 = *pbVar19;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(lVar12 + 4) = (int)uVar15;
      *(undefined2 *)(lVar12 + 0x1c) = 0;
      *(int *)(lVar12 + 0x18) = (int)uVar15;
    }
    else {
      puVar21 = (ushort *)(pbVar19 + uVar15);
      uVar6 = *puVar21;
      *(ushort *)(lVar12 + 0x1c) = uVar6;
      if (uVar6 == 0) {
        cVar5 = func_0x(0x17898a0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x17898a0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x10792ac,0x1199398,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(lVar12 + 8),3);
        uVar15 = (ulonglong)*(uint *)(lVar12 + 0x14);
        uVar6 = *(ushort *)(lVar12 + 0x1c);
      }
      uVar14 = (int)uVar15 + (uVar6 + 1) * 2;
      *(uint *)(lVar12 + 0x18) = uVar14;
      if (0x1f9e < uVar14) {
        cVar5 = func_0x(0x17898a0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x17898a0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x10792ac,0x1199398,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(lVar12 + 8),4);
        uVar6 = *(ushort *)(lVar12 + 0x1c);
        uVar14 = *(uint *)(lVar12 + 0x18);
      }
      uVar15 = (ulonglong)uVar6;
      uVar6 = puVar21[uVar15];
      *(uint *)(lVar12 + 4) = uVar6 & 0x7fff;
      if ((uVar6 & 0x7fff) < uVar14) {
        cVar5 = func_0x(0x17898a0);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x17898a0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x10792ac,0x1199398,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(lVar12 + 8),4);
        uVar14 = *(uint *)(lVar12 + 0x18);
        uVar15 = (ulonglong)*(ushort *)(lVar12 + 0x1c);
      }
      uVar20 = uVar13;
      puVar3 = puVar21;
      if ((short)uVar15 != 0) {
        do {
          uVar17 = puVar3[1] & 0x7fff;
          if ((uVar17 < uVar14) || (*(uint *)(lVar12 + 4) < uVar17)) {
            cVar5 = func_0x(0x17898a0);
            if ((cVar5 != '\0') &&
               ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x17898a0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x10792ac,0x1199398,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(lVar12 + 8),4);
          }
          uVar15 = (ulonglong)*(ushort *)(lVar12 + 0x1c);
          uVar22 = (int)uVar20 + 1;
          uVar20 = (ulonglong)uVar22;
          puVar3 = puVar3 + 1;
          uVar14 = uVar17;
        } while ((int)uVar22 < (int)(uint)*(ushort *)(lVar12 + 0x1c));
      }
      if ((short)puVar21[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
        lVar9 = *(longlong *)(lVar12 + 8);
        do {
          lVar10 = (ulonglong)*(uint *)(lVar12 + 0x14) + lVar9;
          uVar14 = *(ushort *)(lVar10 + uVar15 * 2) & 0x7fff;
          if ((int)uVar15 == 1) {
            uVar17 = *(uint *)(lVar12 + 0x18);
            uVar22 = uVar17;
LAB_:
            if ((uVar14 < uVar17) || (*(uint *)(lVar12 + 4) < uVar14)) goto LAB_;
          }
          else {
            uVar22 = *(uint *)(lVar12 + 0x18);
            uVar17 = *(ushort *)(lVar10 + -2 + uVar15 * 2) & 0x7fff;
            if (uVar22 <= uVar17) goto LAB_;
LAB_:
            func_0x(lVar9,7);
            uVar22 = *(uint *)(lVar12 + 0x18);
          }
          if ((uVar17 < uVar22) || (*(uint *)(lVar12 + 4) < uVar17)) goto LAB_;
          lVar9 = *(longlong *)(lVar12 + 8);
          if (*(ushort *)(lVar9 + (ulonglong)uVar17) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(lVar12 + 0x1c) = *(short *)(lVar12 + 0x1c) + -1;
            uVar6 = *(ushort *)(lVar12 + 0x2c) & 0xc7ff;
            uVar20 = (ulonglong)(uVar17 & 0xffff);
            *(short *)(lVar12 + 0x2a) = (short)uVar17;
            uVar15 = *(ulonglong *)(lVar12 + 8);
            if ((*(ushort *)(uVar20 + 2 + uVar15) >> 0xe & 1) != 0) {
              uVar6 = *(ushort *)(uVar20 + 2 + uVar15) & 0x3800 | uVar6;
            }
            *(ushort *)(lVar12 + 0x2c) = uVar6;
            uVar7 = (uVar6 ^ *(ushort *)(uVar20 + 2 + uVar15)) & 0x7ff ^ uVar6;
            *(ushort *)(lVar12 + 0x2c) = uVar7;
            uVar18 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar15 + (uVar6 >> 0xb & 7) * 2 + uVar20
            ;
            if (uVar18 < uVar20 + uVar15) {
              func_0x(uVar20 + uVar15,0x19);
              uVar7 = *(ushort *)(lVar12 + 0x2c);
              uVar20 = (ulonglong)*(ushort *)(lVar12 + 0x2a);
              uVar15 = (ulonglong)*(uint *)(lVar12 + 8);
            }
            if (uVar14 - uVar17 < (((uVar7 & 0x7ff) * 2 - (int)uVar20) - (int)uVar15) + (int)uVar18)
            {
              func_0x(uVar20 + *(longlong *)(lVar12 + 8),0x19);
              uVar7 = *(ushort *)(lVar12 + 0x2c);
            }
            if (((uVar7 & 0x3800) != 0) &&
               (puVar21 = (ushort *)
                          (*(longlong *)(lVar12 + 8) + 4 + (ulonglong)*(ushort *)(lVar12 + 0x2a)),
               uVar15 = uVar13, (uVar7 & 0x3800) != 0)) {
              do {
                if ((uVar7 & 0x7ff) < (*puVar21 & 0x7ff)) {
                  func_0x((ulonglong)*(ushort *)(lVar12 + 0x2a) + *(longlong *)(lVar12 + 8),
                                  0x1a);
                  uVar7 = *(ushort *)(lVar12 + 0x2c);
                }
                uVar14 = (int)uVar15 + 1;
                puVar21 = puVar21 + 1;
                uVar15 = (ulonglong)uVar14;
              } while ((int)uVar14 < (int)(uVar7 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(lVar9 + (ulonglong)uVar17) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar6 = *(short *)(lVar12 + 0x1c) - 1;
          *(ushort *)(lVar12 + 0x1c) = uVar6;
          if (uVar6 == 0) goto LAB_;
          uVar15 = (ulonglong)uVar6;
        } while ((short)puVar21[(ulonglong)(uVar6 - 1) + 1] < 0);
        pbVar19 = *(byte **)(lVar12 + 8);
        uVar15 = (ulonglong)*(uint *)(lVar12 + 4);
      }
      else {
LAB_:
        pbVar19 = *(byte **)(lVar12 + 8);
        uVar15 = (ulonglong)*(uint *)(lVar12 + 4);
      }
    }
    if ((*pbVar19 & 0x40) == 0) {
      *(undefined4 *)(lVar12 + 0x26) = 0;
    }
    else {
      *(int *)(lVar12 + 0x26) = (int)uVar15;
      *(int *)(lVar12 + 4) = (int)uVar15 + 0xe;
      puVar11 = (undefined8 *)func_0x(puVar1);
      uStackX_10 = *puVar11;
      iVar8 = func_0x(&uStackX_10);
      *(int *)(lVar12 + 4) = *(int *)(lVar12 + 4) + iVar8;
      uVar15 = (ulonglong)*(uint *)(lVar12 + 4);
    }
    iVar8 = (int)uVar15;
    if ((*(ulonglong *)(lVar12 + 0x1e) != 0) &&
       (*(ulonglong *)(lVar12 + 0x1e) < uVar15 + *(longlong *)(lVar12 + 8))) {
      cVar5 = func_0x(0x17898a0);
      if ((cVar5 != '\0') &&
         ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))) {
        cVar5 = func_0x(0x17898a0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x10792ac,0x1199398,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(lVar12 + 8),0x12);
      iVar8 = *(int *)(lVar12 + 4);
    }
    if (0x3f3b < iVar8 - 1U) {
      cVar5 = func_0x(0x17898a0);
      if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
         (*(char *)(lVar9 + 0x499) != '\0')) {
        cVar5 = func_0x(0x17898a0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x10792ac,0x1199398,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(lVar12 + 8),5);
    }
  }
LAB_:
  iVar8 = func_0x(puVar1);
  if (iVar8 == 0) {
    iVar8 = func_0x(puVar1);
    if (iVar8 == 0) {
      (*_DAT_)(1,0x1234fc8,0x1226058,0xd7a,0);
    }
  }
  else {
    if ((-1 < (int)uVar2) && ((int)uVar2 < (int)(*(ushort *)(lVar12 + 0x2c) & 0x7ff))) {
      uVar6 = *(ushort *)(lVar12 + 0x2c);
      lVar9 = *(longlong *)(lVar12 + 8) + (ulonglong)*(ushort *)(lVar12 + 0x2a);
      if ((uVar6 & 0x3800) == 0) {
        uVar16 = (uint)(*(ushort *)(lVar9 + 2) >> 0xb & 7);
      }
      else if ((uVar6 >> 0xb & 7) != 0) {
        do {
          if (((uVar13 == 0) || ((int)(*(ushort *)(lVar9 + 2 + uVar13 * 2) & 0x7ff) <= (int)uVar2))
             && (uVar7 = *(ushort *)(lVar9 + 4 + uVar13 * 2),
                (int)uVar2 <= (int)((uVar7 & 0x7ff) - 1))) {
            uVar16 = (uint)(uVar7 >> 0xb & 7);
            break;
          }
          uVar13 = uVar13 + 1;
        } while ((longlong)uVar13 < (longlong)(ulonglong)(uVar6 >> 0xb & 7));
      }
      iStackX_8 = (uint)*(ushort *)
                         ((ulonglong)((uVar6 >> 0xb & 7) * 2) + *(longlong *)(lVar12 + 8) +
                          (longlong)(int)uVar2 * 2 + 4 + (ulonglong)*(ushort *)(lVar12 + 0x2a)) +
                  uVar16 * 0x10000;
      goto LAB_;
    }
    (*_DAT_)(1,0x1234f98,0x1234f60,0x41a,0);
  }
  iStackX_8 = (int)param_1;
LAB_:
  lVar12 = func_0x(**(undefined8 **)(*(longlong *)(*param_1 + 8) + 0x160),iStackX_8)
  ;
  *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + 1;
  param_1[3] = lVar12;
  return 1;
}

