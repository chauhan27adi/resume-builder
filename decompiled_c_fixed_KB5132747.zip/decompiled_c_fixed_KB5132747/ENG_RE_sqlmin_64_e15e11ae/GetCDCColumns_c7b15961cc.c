
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2)

{
  undefined2 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined auVar4 [16];
  char cVar5;
  int iVar6;
  uint uVar7;
  longlong lVar8;
  undefined8 uVar9;
  uint uVar10;
  undefined4 *puVar12;
  longlong lVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  longlong unaff_GS_OFFSET;
  undefined auStack_1f8 [32];
  undefined8 uStack_1d8;
  undefined8 uStack_1d0;
  ulonglong uStack_1c8;
  undefined8 uStack_1c0;
  undefined4 uStack_1b8;
  uint auStack_1a8 [2];
  int aiStack_1a0 [2];
  undefined4 auStack_198 [2];
  undefined8 uStack_190;
  undefined4 uStack_188;
  undefined auStack_180 [24];
  undefined auStack_168 [16];
  undefined auStack_158 [16];
  undefined auStack_148 [16];
  undefined auStack_138 [16];
  undefined auStack_128 [16];
  undefined8 uStack_118;
  undefined8 uStack_108;
  undefined auStack_100 [16];
  undefined auStack_f0 [16];
  undefined auStack_e0 [24];
  longlong lStack_c8;
  undefined2 uStack_c0;
  undefined8 uStack_b8;
  int iStack_b0;
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  longlong lStack_68;
  uint uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  ulonglong uVar11;
  
  uStack_108 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1f8;
  lVar3 = *(longlong *)
           (*(longlong *)((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)) + 8
           + (ulonglong)*_DAT_);
  lVar13 = *(longlong *)((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)) +
           (ulonglong)*_DAT_;
  lVar8 = *(longlong *)(lVar13 + 0x100);
  auStack_198[0] = param_2;
  if (lVar8 == 0) {
    (*_DAT_)(0);
    lVar8 = *(longlong *)(lVar13 + 0x100);
  }
  lVar8 = *(longlong *)(lVar8 + 600);
  uVar15 = 0;
  uStack_190 = 0;
  uStack_188 = 1;
  auStack_180._0_16_ = ZEXT816(0);
  aiStack_1a0[0] = 0;
  if ((lVar3 == 0) || (lVar8 == 0)) {
    uStack_1d8 = 0;
    (*_DAT_)(1,0x1c5f508,0x1c39a80,0x395);
  }
  if (*(longlong *)(param_1 + 0x28) != 0) {
    uStack_1d8 = 0;
    (*_DAT_)(1,0x1c5f530,0x1c39a80,0x396);
  }
  uVar1 = *(undefined2 *)
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
             + 0x50) + 8);
  uStack_188 = 1;
  auStack_180._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  cVar5 = (**(code **)(*(longlong *)auStack_180._0_8_ + 0x1d0))();
  if (cVar5 == '\0') {
    uStack_1b8 = 0;
    uStack_1c0 = 0;
    uStack_1c8 = uStack_1c8 & 0xffffffffffffff00;
    uStack_1d0 = (undefined8 *)CONCAT44(uStack_1d0._4_4_,2);
    uStack_1d8 = CONCAT44(uStack_1d8._4_4_,1);
    (**(code **)(*(longlong *)auStack_180._0_8_ + 8))(auStack_180._0_8_,0x1aaac10,0x20,1);
    uStack_190 = CONCAT44(uStack_190._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_180._0_8_ + 0xe8))
              (auStack_180._0_8_,1,1,(longlong)&uStack_190 + 4);
    uStack_188 = 1;
    uStack_190 = CONCAT44(uStack_190._4_4_,4);
  }
  iVar6 = func_0x(uVar1,0x1aaac38);
  if (iVar6 == 0) {
    func_0x(0x4977,0x10,1,0x1aaac38);
  }
  else {
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0xb70) = 0;
    uStack_b8 = (**(code **)(*(longlong *)auStack_180._0_8_ + 0x1b0))();
    lStack_c8 = 0;
    auStack_a8 = ZEXT816(0);
    auStack_98 = ZEXT816(0);
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    lStack_68 = 0;
    uStack_60 = 0;
    uStack_58 = 0;
    uStack_50 = 0;
    uStack_c0 = uVar1;
    iStack_b0 = iVar6;
    iVar6 = func_0x(&lStack_c8,3,1);
    if (iVar6 == 0) {
      func_0x(0x49aa,0x10,2,0x1aaabc8);
    }
    else {
      auStack_1a8[0] = 4;
      auStack_e0._0_4_ = func_0x(&lStack_c8,0x184bad8,auStack_1a8);
      auStack_100 = ZEXT816(0);
      auStack_f0 = ZEXT816(0);
      auStack_e0._4_12_ = SUB1612(ZEXT816(0),4);
      uStack_118 = 0;
      auStack_128 = ZEXT416(auStack_1a8[0]) << 0x40;
      auStack_158 = ZEXT816(0);
      auStack_168 = ZEXT416((uint)auStack_e0._0_4_);
      auStack_138._0_12_ = ZEXT412(1) << 0x40;
      auStack_138._12_4_ = 0;
      auStack_148._8_8_ = 0;
      auStack_148._0_8_ = auStack_100;
      uStack_1c8 = 0;
      uStack_1d0 = &uStack_50;
      uStack_1d8 = 0;
      (**(code **)(*(longlong *)auStack_98._8_8_ + 0x20))(auStack_98._8_8_,2,1,auStack_168);
      uStack_1c8 = uStack_1c8 & 0xffffffff00000000;
      uStack_1d0 = (undefined8 *)auStack_198;
      uStack_1d8 = 1;
      (**(code **)(*(longlong *)auStack_88._8_8_ + 0x28))(auStack_88._8_8_,uStack_50,1,auStack_198);
      uStack_1d0 = (undefined8 *)lStack_c8;
      lVar3 = (longlong)uStack_1d0;
      while( true ) {
        uStack_1d0 = (undefined8 *)lVar3;
        uStack_1d8 = uStack_58;
        iVar6 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1,0);
        if (iVar6 != 0) break;
        if (((*(uint *)(lVar8 + 0xbc) & 4) != 0) &&
           ((iVar6 = func_0x(), iVar6 != 0 ||
            (((lVar3 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
              lVar3 != 0 && (*(char *)(*(longlong *)(lVar3 + 0x38) + 8) != '\0')) &&
             (iVar6 = func_0x(), iVar6 == 0)))))) goto LAB_;
        auStack_1a8[0] = 0;
        lVar3 = lStack_c8;
        if (((lStack_c8 != 0) && (lVar3 = lStack_c8, lStack_68 != 0)) &&
           (lVar3 = lStack_c8, uStack_60 != 0)) {
          uVar7 = func_0x(&lStack_c8,0x1845d50,auStack_1a8);
          uVar14 = uVar15;
          if (((lStack_68 != 0) && (uVar7 - 1 < 0xfffffffe)) && (uVar14 = 0, uStack_60 != 0)) {
            uVar11 = uVar15;
            do {
              if (*(ulonglong *)(uVar11 * 0x58 + lStack_68) == (ulonglong)uVar7) {
                uVar14 = lStack_68 + uVar11 * 0x58;
                if (uVar14 != 0) goto LAB_;
                break;
              }
              uVar10 = (int)uVar11 + 1;
              uVar11 = (ulonglong)uVar10;
            } while (uVar10 < uStack_60);
          }
          uStack_1d8 = CONCAT44(uStack_1d8._4_4_,iStack_b0);
          (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
          lVar3 = lStack_c8;
          if (((*(longlong *)(uVar14 + 8) + lStack_c8 != 0) &&
              (lVar3 = lStack_c8, *(longlong *)(lStack_c8 + *(longlong *)(uVar14 + 0x10)) == 4)) &&
             (lVar3 = lStack_c8, *(int *)(lStack_c8 + *(longlong *)(uVar14 + 0x18)) != 3)) {
            *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
            auStack_1a8[0] = 0;
            lVar3 = lStack_c8;
            if (((lStack_c8 != 0) && (lVar3 = lStack_c8, lStack_68 != 0)) &&
               (lVar3 = lStack_c8, uStack_60 != 0)) {
              uVar7 = func_0x(&lStack_c8,0x1aaabf8,auStack_1a8);
              uVar14 = uVar15;
              if (((lStack_68 != 0) && (uVar7 - 1 < 0xfffffffe)) && (uVar14 = 0, uStack_60 != 0)) {
                uVar11 = uVar15;
                do {
                  if (*(ulonglong *)(uVar11 * 0x58 + lStack_68) == (ulonglong)uVar7) {
                    uVar14 = lStack_68 + uVar11 * 0x58;
                    if (uVar14 != 0) goto LAB_;
                    break;
                  }
                  uVar10 = (int)uVar11 + 1;
                  uVar11 = (ulonglong)uVar10;
                } while (uVar10 < uStack_60);
              }
              uStack_1d8 = CONCAT44(uStack_1d8._4_4_,iStack_b0);
              (*_DAT_)(0xbb,0x38,0x10);
LAB_:
              lVar3 = lStack_c8;
              uVar11 = *(ulonglong *)(*(longlong *)(uVar14 + 0x10) + lStack_c8);
              lVar13 = *(longlong *)(uVar14 + 8) + lStack_c8;
              if (((lVar13 != 0) && (uVar11 - 1 < 4)) &&
                 ((*(int *)(lStack_c8 + *(longlong *)(uVar14 + 0x18)) != 3 &&
                  (func_0x(aiStack_1a0,lVar13,uVar11 & 0xffffffff),
                  aiStack_1a0[0] == 0)))) {
                *(int *)(param_1 + 0xb70) = *(int *)(param_1 + 0xb70) + 1;
              }
            }
          }
        }
      }
      if (*(uint *)(param_1 + 0x24) != 0) {
        auVar4 = ZEXT816(4) * ZEXT416(*(uint *)(param_1 + 0x24));
        uVar9 = auVar4._0_8_;
        if (auVar4._8_8_ != 0) {
          uVar9 = 0xffffffffffffffff;
        }
        uStack_1d0 = (undefined8 *)CONCAT71(uStack_1d0._1_7_,6);
        uStack_1d8 = CONCAT44(uStack_1d8._4_4_,0x3cf);
        uVar9 = (*_DAT_)(uVar9,_DAT_,1,0x1aaad18);
        *(undefined8 *)(param_1 + 0x28) = uVar9;
        uStack_1d8 = 0;
        func_0x(uVar1,0x1f,(ulonglong)*(uint *)(param_1 + 0x24) << 2,1);
        if (*(longlong *)(param_1 + 0x28) == 0) {
          uStack_1d8 = 0;
          (*_DAT_)(1,0x1c5f518,0x1c39a80,0x3d2);
        }
        if (*(uint *)(param_1 + 0xb70) != 0) {
          auVar4 = ZEXT816(4) * ZEXT416(*(uint *)(param_1 + 0xb70));
          uVar9 = auVar4._0_8_;
          if (auVar4._8_8_ != 0) {
            uVar9 = 0xffffffffffffffff;
          }
          uStack_1d0 = (undefined8 *)CONCAT71(uStack_1d0._1_7_,6);
          uStack_1d8 = CONCAT44(uStack_1d8._4_4_,0x3d7);
          uVar9 = (*_DAT_)(uVar9,_DAT_,1,0x1aaad18);
          *(undefined8 *)(param_1 + 0xb38) = uVar9;
          uStack_1d8 = 0;
          func_0x(uVar1,0x30,(ulonglong)*(uint *)(param_1 + 0xb70) << 2,1);
          if (*(longlong *)(param_1 + 0xb38) == 0) {
            uStack_1d8 = 0;
            (*_DAT_)(1,0x1c5f548,0x1c39a80,0x3d8);
          }
          *(undefined4 *)(param_1 + 0x24) = 0;
          *(undefined4 *)(param_1 + 0xb70) = 0;
          iVar6 = (**(code **)(*(longlong *)auStack_88._0_8_ + 0x38))(auStack_88._0_8_,0);
          if (iVar6 != 0) {
            uStack_1d8 = CONCAT44(uStack_1d8._4_4_,iVar6);
            func_0x(0x497a,0x10,1,0x1aaab18);
          }
          uStack_1d0 = (undefined8 *)lStack_c8;
          lVar3 = (longlong)uStack_1d0;
          while( true ) {
            uStack_1d0 = (undefined8 *)lVar3;
            uStack_1d8 = uStack_58;
            iVar6 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1,0);
            if ((iVar6 != 0) ||
               (((*(uint *)(lVar8 + 0xbc) & 4) != 0 &&
                ((iVar6 = func_0x(), iVar6 != 0 ||
                 (((lVar3 = *(longlong *)
                             ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              )), lVar3 != 0 && (*(char *)(*(longlong *)(lVar3 + 0x38) + 8) != '\0')
                   ) && (iVar6 = func_0x(), iVar6 == 0)))))))) break;
            auStack_1a8[0] = 0;
            lVar3 = lStack_c8;
            if (((lStack_c8 != 0) && (lVar3 = lStack_c8, lStack_68 != 0)) &&
               (lVar3 = lStack_c8, uStack_60 != 0)) {
              uVar7 = func_0x(&lStack_c8,0x1845d50,auStack_1a8);
              uVar14 = uVar15;
              if (((lStack_68 != 0) && (uVar7 - 1 < 0xfffffffe)) && (uVar14 = 0, uStack_60 != 0)) {
                uVar11 = uVar15;
                do {
                  if (*(ulonglong *)(uVar11 * 0x58 + lStack_68) == (ulonglong)uVar7) {
                    uVar14 = lStack_68 + uVar11 * 0x58;
                    if (uVar14 != 0) goto LAB_;
                    break;
                  }
                  uVar10 = (int)uVar11 + 1;
                  uVar11 = (ulonglong)uVar10;
                } while (uVar10 < uStack_60);
              }
              uStack_1d8 = CONCAT44(uStack_1d8._4_4_,iStack_b0);
              (*_DAT_)(0xbb,0x38,0x10);
LAB_:
              puVar12 = (undefined4 *)(*(longlong *)(uVar14 + 8) + lStack_c8);
              lVar3 = lStack_c8;
              if (((puVar12 != (undefined4 *)0x0) &&
                  (lVar3 = lStack_c8, *(longlong *)(lStack_c8 + *(longlong *)(uVar14 + 0x10)) == 4))
                 && (lVar3 = lStack_c8, *(int *)(lStack_c8 + *(longlong *)(uVar14 + 0x18)) != 3)) {
                uVar2 = *puVar12;
                *(undefined4 *)
                 (*(longlong *)(param_1 + 0x28) + (ulonglong)*(uint *)(param_1 + 0x24) * 4) = uVar2;
                *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
                auStack_1a8[0] = 0;
                lVar3 = lStack_c8;
                if (((lStack_c8 != 0) && (lVar3 = lStack_c8, lStack_68 != 0)) &&
                   (lVar3 = lStack_c8, uStack_60 != 0)) {
                  uVar7 = func_0x(&lStack_c8,0x1aaabf8,auStack_1a8);
                  uVar14 = uVar15;
                  if (((lStack_68 != 0) && (uVar7 - 1 < 0xfffffffe)) && (uVar14 = 0, uStack_60 != 0)
                     ) {
                    uVar11 = uVar15;
                    do {
                      if (*(ulonglong *)(uVar11 * 0x58 + lStack_68) == (ulonglong)uVar7) {
                        uVar14 = lStack_68 + uVar11 * 0x58;
                        if (uVar14 != 0) goto LAB_;
                        break;
                      }
                      uVar10 = (int)uVar11 + 1;
                      uVar11 = (ulonglong)uVar10;
                    } while (uVar10 < uStack_60);
                  }
                  uStack_1d8 = CONCAT44(uStack_1d8._4_4_,iStack_b0);
                  (*_DAT_)(0xbb,0x38,0x10);
LAB_:
                  lVar3 = lStack_c8;
                  uVar11 = *(ulonglong *)(*(longlong *)(uVar14 + 0x10) + lStack_c8);
                  lVar13 = *(longlong *)(uVar14 + 8) + lStack_c8;
                  if ((((lVar13 != 0) && (uVar11 - 1 < 4)) &&
                      (*(int *)(lStack_c8 + *(longlong *)(uVar14 + 0x18)) != 3)) &&
                     (func_0x(aiStack_1a0,lVar13,uVar11 & 0xffffffff),
                     aiStack_1a0[0] == 0)) {
                    *(undefined4 *)
                     (*(longlong *)(param_1 + 0xb38) + (ulonglong)*(uint *)(param_1 + 0xb70) * 4) =
                         uVar2;
                    *(int *)(param_1 + 0xb70) = *(int *)(param_1 + 0xb70) + 1;
                    lVar3 = lStack_c8;
                  }
                }
              }
            }
          }
        }
      }
    }
LAB_:
    func_0x(&lStack_c8);
  }
  func_0x(&uStack_190,0);
  if ((int)uStack_190 != 0) {
    func_0x(&uStack_190,0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_1f8);
  return;
}

