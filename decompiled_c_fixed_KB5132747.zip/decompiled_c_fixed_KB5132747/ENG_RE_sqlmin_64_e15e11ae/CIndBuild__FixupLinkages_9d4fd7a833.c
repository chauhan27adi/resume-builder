
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  ushort *puVar4;
  bool bVar5;
  undefined auVar6 [16];
  uint **ppuVar7;
  undefined auVar8 [16];
  char cVar9;
  ushort uVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  uint *puVar17;
  short *psVar18;
  undefined8 uVar19;
  ushort uVar20;
  undefined4 uVar21;
  ulonglong uVar22;
  ulonglong uVar23;
  int iVar24;
  ulonglong uVar25;
  uint uVar26;
  int *piVar27;
  byte **ppbVar28;
  byte **ppbVar29;
  byte *pbVar30;
  ulonglong uVar31;
  uint uVar32;
  byte **ppbVar33;
  ulonglong uVar34;
  short sVar35;
  ulonglong uVar36;
  int *piVar37;
  longlong *plVar38;
  longlong *plVar39;
  ulonglong uVar40;
  undefined2 uVar41;
  longlong lVar42;
  longlong lVar43;
  undefined *puVar44;
  ulonglong uVar45;
  ushort *puVar46;
  undefined uVar47;
  longlong unaff_GS_OFFSET;
  undefined auStack_b38 [32];
  undefined8 uStack_b18;
  undefined8 uStack_b10;
  undefined8 uStack_b08;
  uint uStack_b00;
  undefined uStack_af8;
  undefined4 uStack_af0;
  longlong lStack_ae8;
  undefined4 *puStack_ae0;
  int aiStack_ad8 [2];
  longlong *plStack_ad0;
  undefined uStack_ac8;
  uint uStack_ac4;
  uint uStack_ac0;
  longlong *plStack_ab8;
  undefined uStack_ab0;
  uint uStack_aac;
  uint uStack_aa8;
  undefined uStack_aa0;
  int iStack_a9c;
  short sStack_a98;
  int iStack_a94;
  short sStack_a90;
  uint uStack_a8c;
  undefined4 uStack_a88;
  longlong *plStack_a80;
  uint uStack_a78;
  uint uStack_a74;
  uint uStack_a70;
  undefined4 uStack_a6c;
  undefined8 uStack_a68;
  ushort uStack_a60;
  undefined8 uStack_a58;
  ushort uStack_a50;
  undefined8 uStack_a48;
  ushort uStack_a40;
  undefined8 uStack_a38;
  undefined2 uStack_a30;
  undefined8 uStack_a28;
  undefined2 uStack_a20;
  undefined8 uStack_a18;
  undefined2 uStack_a10;
  undefined8 uStack_a08;
  undefined2 uStack_a00;
  undefined8 uStack_9f8;
  ushort uStack_9f0;
  undefined auStack_9e8 [4];
  undefined4 uStack_9e4;
  undefined4 uStack_9e0;
  undefined4 uStack_9dc;
  undefined8 uStack_9d8;
  undefined2 uStack_9d0;
  undefined4 uStack_9c8;
  undefined2 uStack_9c4;
  undefined4 uStack_9c0;
  undefined2 uStack_9bc;
  undefined4 uStack_9b8;
  undefined2 uStack_9b4;
  undefined4 uStack_9b0;
  undefined2 uStack_9ac;
  undefined4 uStack_9a8;
  undefined2 uStack_9a4;
  undefined4 uStack_9a0;
  undefined2 uStack_99c;
  uint uStack_998;
  undefined2 uStack_994;
  undefined4 uStack_990;
  undefined2 uStack_98c;
  undefined4 uStack_988;
  undefined2 uStack_984;
  undefined4 uStack_980;
  undefined2 uStack_97c;
  undefined4 uStack_978;
  undefined2 uStack_974;
  undefined auStack_970 [4];
  undefined4 uStack_96c;
  undefined2 uStack_968;
  undefined8 uStack_960;
  undefined2 uStack_958;
  undefined8 uStack_950;
  undefined4 uStack_948;
  undefined8 uStack_944;
  undefined4 uStack_93c;
  undefined8 uStack_938;
  undefined4 uStack_930;
  undefined8 uStack_92c;
  undefined4 uStack_924;
  longlong lStack_920;
  longlong lStack_918;
  longlong *plStack_910;
  undefined4 uStack_908;
  undefined8 uStack_900;
  ushort uStack_8f8;
  undefined8 uStack_8f0;
  ushort uStack_8e8;
  undefined8 uStack_8e0;
  undefined2 uStack_8d8;
  undefined8 uStack_8d0;
  undefined2 uStack_8c8;
  undefined auStack_8c0 [4];
  undefined auStack_8bc [4];
  undefined auStack_8b8 [4];
  undefined auStack_8b4 [4];
  undefined auStack_8b0 [4];
  undefined auStack_8ac [4];
  undefined auStack_8a8 [8];
  undefined auStack_8a0 [8];
  undefined auStack_898 [4];
  undefined auStack_894 [4];
  uint uStack_890;
  undefined8 uStack_88c;
  uint uStack_878;
  undefined8 uStack_874;
  undefined8 uStack_860;
  undefined auStack_858 [8];
  undefined4 uStack_850;
  undefined4 uStack_848;
  uint **ppuStack_840;
  undefined *puStack_838;
  undefined8 uStack_830;
  uint *puStack_828;
  undefined4 uStack_820;
  undefined4 uStack_81c;
  longlong lStack_818;
  undefined4 uStack_810;
  undefined4 uStack_80c;
  longlong lStack_808;
  undefined4 uStack_800;
  undefined4 uStack_7fc;
  short *psStack_7f8;
  int iStack_7f0;
  undefined4 uStack_7ec;
  short *psStack_7e8;
  int iStack_7e0;
  undefined4 uStack_7dc;
  undefined8 uStack_7d8;
  undefined4 uStack_7d0;
  undefined4 uStack_7cc;
  undefined auStack_7c8 [448];
  undefined8 uStack_608;
  undefined8 uStack_600;
  uint uStack_5f8;
  short sStack_5f4;
  int iStack_5f2;
  undefined uStack_5ee;
  undefined uStack_5ed;
  undefined auStack_5b8 [8];
  undefined4 uStack_5b0;
  undefined4 uStack_5a8;
  uint **ppuStack_5a0;
  undefined *puStack_598;
  undefined8 uStack_590;
  uint *puStack_588;
  undefined4 uStack_580;
  undefined4 uStack_57c;
  longlong lStack_578;
  undefined4 uStack_570;
  undefined4 uStack_56c;
  longlong lStack_568;
  undefined4 uStack_560;
  undefined4 uStack_55c;
  short *psStack_558;
  int iStack_550;
  undefined4 uStack_54c;
  short *psStack_548;
  int iStack_540;
  undefined4 uStack_53c;
  undefined8 uStack_538;
  undefined4 uStack_530;
  undefined4 uStack_52c;
  undefined auStack_528 [448];
  undefined8 uStack_368;
  undefined8 uStack_360;
  uint uStack_358;
  short sStack_354;
  int iStack_352;
  undefined uStack_34e;
  undefined uStack_34d;
  short sStack_318;
  ushort uStack_316;
  uint uStack_314;
  int *piStack_310;
  undefined8 uStack_308;
  undefined4 uStack_300;
  ushort uStack_2fc;
  undefined2 uStack_2fa;
  undefined6 uStack_2f8;
  undefined2 uStack_2f2;
  undefined2 uStack_2f0;
  ushort uStack_2ee;
  ushort uStack_2ec;
  undefined2 uStack_2ea;
  undefined4 uStack_2e8;
  int iStack_2e4;
  undefined auStack_2e0 [16];
  undefined auStack_2d0 [8];
  undefined8 uStack_2c8;
  undefined8 uStack_2c0;
  undefined6 uStack_2b8;
  undefined2 uStack_2b2;
  undefined6 uStack_2b0;
  undefined2 uStack_2aa;
  undefined8 uStack_2a8;
  undefined auStack_2a0 [16];
  undefined auStack_290 [16];
  undefined auStack_280 [16];
  undefined8 uStack_270;
  undefined2 uStack_268;
  ushort uStack_266;
  undefined4 uStack_264;
  byte *pbStack_260;
  undefined8 uStack_258;
  undefined2 uStack_250;
  short sStack_24e;
  short sStack_24c;
  undefined2 uStack_24a;
  undefined6 uStack_248;
  undefined2 uStack_242;
  undefined2 uStack_240;
  undefined6 uStack_23e;
  undefined4 uStack_238;
  int iStack_234;
  undefined auStack_230 [16];
  undefined auStack_220 [2];
  undefined auStack_21e [6];
  undefined8 uStack_218;
  uint uStack_210;
  undefined4 uStack_20c;
  short sStack_208;
  short sStack_206;
  short sStack_204;
  undefined2 uStack_202;
  undefined6 uStack_200;
  undefined2 uStack_1fa;
  undefined2 uStack_1f8;
  undefined6 uStack_1f6;
  uint uStack_1f0;
  undefined4 uStack_1ec;
  short *psStack_1e8;
  short *psStack_1e0;
  short sStack_1d8;
  undefined6 uStack_1d6;
  undefined auStack_1d0 [10];
  undefined auStack_1c6 [6];
  undefined8 uStack_1c0;
  ushort uStack_1b8;
  ushort uStack_1b6;
  undefined4 uStack_1b4;
  byte *pbStack_1b0;
  undefined8 uStack_1a8;
  undefined2 uStack_1a0;
  ushort uStack_19e;
  short sStack_19c;
  undefined2 uStack_19a;
  undefined6 uStack_198;
  ushort uStack_192;
  undefined2 uStack_190;
  undefined6 uStack_18e;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined auStack_180 [16];
  undefined auStack_170 [8];
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined6 uStack_158;
  undefined2 uStack_152;
  undefined6 uStack_150;
  undefined2 uStack_14a;
  undefined8 uStack_148;
  undefined auStack_140 [16];
  undefined auStack_130 [16];
  undefined auStack_120 [16];
  undefined8 uStack_110;
  uint auStack_108 [2];
  short asStack_100 [24];
  short asStack_d0 [24];
  short asStack_a0 [24];
  short asStack_70 [24];
  ulonglong uStack_40;
  
  uStack_860 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_b38;
  sStack_318 = -1;
  piStack_310 = (int *)0x0;
  uStack_314 = 0;
  uStack_2fa = 0;
  uStack_2f8 = 0;
  uStack_2f0 = 0;
  uStack_2ee = 0;
  uStack_2ec = 0;
  uStack_2ea = 0;
  uStack_308 = (byte **)0x0;
  iStack_2e4 = 0xffffffff;
  plStack_910 = param_1 + 4;
  lStack_920 = param_1[5];
  plStack_a80 = param_1;
  if ((*(int *)((longlong)param_1 + 0xf5c) == 0) && (*(short *)(param_1 + 0x1ec) == 0)) {
LAB_:
    func_0x(uStack_40 ^ (ulonglong)auStack_b38);
    return;
  }
  plStack_ad0 = (longlong *)0x0;
  uStack_ac8 = 0;
  uStack_ac4 = 0;
  plStack_ab8 = (longlong *)0x0;
  uStack_ab0 = 0;
  uStack_aac = 0;
  iStack_a94 = *(int *)((longlong)param_1 + 0xf5c);
  sStack_a90 = *(short *)(param_1 + 0x1ec);
  iStack_a9c = *(int *)((longlong)param_1 + 0xf54);
  sStack_a98 = *(short *)(param_1 + 0x1eb);
  uStack_a6c = 2;
code_r0x0010011f:
  lVar16 = *(longlong *)(*plStack_a80 + 0x30);
  lVar14 = 0;
  uStack_88c = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar43 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar43 != 0) && (lVar43 = **(longlong **)(lVar43 + 0x38), lVar43 != 0)) {
      iVar11 = (*_DAT_)(lVar43,0x337);
      if (iVar11 != 0) goto LAB_;
    }
    lVar43 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar43 != 0) {
      lVar14 = *(longlong *)(lVar43 + 0x60);
    }
  }
LAB_:
  lVar43 = *(longlong *)(lVar16 + 0x728);
LAB_:
  plVar39 = plStack_ad0;
  lVar15 = 0;
  iVar11 = 0;
  uStack_a78 = 0;
  if (plStack_ad0 != (longlong *)0x0) {
    iVar24 = (int)(short)uStack_ac4;
    if (((*(ushort *)((longlong)plStack_ad0 + 0x62) & 0x400) == 0) || (iVar24 < 3)) {
      if (((byte)*(undefined2 *)((longlong)plStack_ad0 + 0x62) >> 3 & 1) != 0) {
        if (iVar24 == 3) {
          iVar24 = 4;
        }
        else if (iVar24 < 2) goto LAB_;
        if ((((*(uint *)((longlong)plStack_ad0 + 100) & 8) != 0) &&
            (lVar42 = plStack_ad0[0x12], lVar42 != 0)) && (*(longlong *)(lVar42 + 0x758) != 0)) {
          func_0x(*(undefined8 *)(lVar42 + 0x758),plStack_ad0,iVar24);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar39 + 100) & 8) != 0)) &&
         ((2 < iVar24 &&
          (((*(uint *)((longlong)plVar39 + 100) & 0xc0000000) != 0x40000000 && (*plVar39 != 0))))))
      {
        iVar13 = (*_DAT_)(*plVar39,0x2000,2,auStack_8ac);
        if (iVar13 != 0) {
          LOCK();
          *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      func_0x(plVar39 + 0x13,iVar24);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        func_0x(plVar39,0,iVar24);
      }
      uStack_ac4 = uStack_ac4 & 0xffff0000;
      plStack_ad0 = (longlong *)0x0;
    }
    else {
      func_0x(&plStack_ad0);
    }
  }
  if (*(longlong *)(lVar16 + 0x728) != 0) {
    func_0x(&plStack_ad0,&iStack_a94,lVar16);
    plVar39 = plStack_ad0;
    if (plStack_ad0 != (longlong *)0x0) {
      iVar24 = (int)(short)uStack_ac4;
      if (((*(ushort *)((longlong)plStack_ad0 + 0x62) & 0x400) == 0) || (iVar24 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_ad0 + 0x62) >> 3 & 1) != 0) {
          if (iVar24 == 3) {
            iVar24 = 4;
          }
          else if (iVar24 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_ad0 + 100) & 8) != 0) &&
              (lVar42 = plStack_ad0[0x12], lVar42 != 0)) && (*(longlong *)(lVar42 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar42 + 0x758),plStack_ad0,iVar24);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar39 + 100) & 8) != 0)) &&
           ((2 < iVar24 &&
            (((*(uint *)((longlong)plVar39 + 100) & 0xc0000000) != 0x40000000 && (*plVar39 != 0)))))
           ) {
          iVar13 = (*_DAT_)(*plVar39,0x2000,2,auStack_894);
          if (iVar13 != 0) {
            LOCK();
            *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        func_0x(plVar39 + 0x13,iVar24);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar39,0,iVar24);
        }
        uStack_ac4 = uStack_ac4 & 0xffff0000;
        plStack_ad0 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_ad0);
      }
    }
  }
  func_0x(lVar16,&iStack_a94);
  uStack_b10 = &uStack_890;
  uStack_b18 = (uint *)CONCAT44(uStack_b18._4_4_,4);
  plStack_ad0 = (longlong *)func_0x(_DAT_,lVar16,&iStack_a94,&uStack_a78);
  if (lVar14 != 0) {
    uVar45 = (ulonglong)(*(uint *)(lVar14 + 0x500) & 0xf);
    if (*(longlong *)(lVar14 + 0x508 + uVar45 * 8) != *plStack_ad0) {
      *(longlong *)(lVar14 + 0x508 + uVar45 * 8) = *plStack_ad0;
      *(longlong *)(lVar14 + 0x500) = *(longlong *)(lVar14 + 0x500) + 1;
    }
  }
  uStack_ac4 = (uStack_a78 >> 3 & 1) << 0x18 | uStack_ac4 & 0xff0004 | 4;
  uStack_ac0 = uStack_a78 >> 4 & 1 | uStack_ac0 & 0xffffff00;
  if (((lVar43 != 0) && (lVar14 != 0)) && (lVar14 == *(longlong *)(lVar16 + 0x1c38))) {
    *(longlong *)(lVar43 + 0x5b28) = *(longlong *)(lVar43 + 0x5b28) + 1;
    if ((int)uStack_88c != 0) {
      *(longlong *)(lVar43 + 0x5b30) = *(longlong *)(lVar43 + 0x5b30) + 1;
      *(longlong *)(lVar43 + 0x5b38) = *(longlong *)(lVar43 + 0x5b38) + (ulonglong)uStack_890;
      if (0xffffff < uStack_ac4) {
        *(longlong *)(lVar43 + 0x5b40) = *(longlong *)(lVar43 + 0x5b40) + 1;
        *(longlong *)(lVar43 + 0x5b48) = *(longlong *)(lVar43 + 0x5b48) + (ulonglong)uStack_890;
      }
    }
  }
  cVar9 = func_0x(lVar16);
  if (((cVar9 == '\0') || (*(char *)(lVar16 + 0x2050) == '\0')) ||
     ((iStack_a94 == 0 || ((iStack_a94 == 9 && (sStack_a90 == 1)))))) goto LAB_;
  lVar42 = *plStack_ad0;
  if (*(short *)(lVar42 + 0x24) == 0) {
LAB_:
    uStack_a48 = *(undefined8 *)(lVar42 + 0x28);
    uStack_a40 = *(ushort *)(lVar42 + 0x30);
  }
  else {
    cVar9 = *(char *)(lVar42 + 1);
    if (cVar9 == '\v') {
      if (*(int *)(lVar42 + 0x18) != 99) {
LAB_:
        if (cVar9 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar9 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar42 + 0x18) != 99) goto LAB_;
    }
    uStack_9c8 = *(undefined4 *)(lVar42 + 0x20);
    uStack_9c4 = *(undefined2 *)(lVar42 + 0x24);
    cVar9 = func_0x(&uStack_9c8);
    if (cVar9 == '\0') goto LAB_;
    func_0x(lVar42,&uStack_a48);
  }
  uVar26 = *(uint *)(lVar16 + 0x2108);
  do {
    uVar12 = uVar26 & 0xfffffffe;
    uStack_944 = *(undefined8 *)(lVar16 + 0x20fc);
    uStack_93c = *(undefined4 *)(lVar16 + 0x2104);
    LOCK();
    UNLOCK();
    uVar26 = *(uint *)(lVar16 + 0x2108);
  } while (uVar12 != uVar26);
  if ((uint)uStack_a48 <= (uint)uStack_944) {
    if ((uint)uStack_944 != (uint)uStack_a48) goto LAB_;
    uVar26 = (uint)((ulonglong)uStack_944 >> 0x20);
    if ((uStack_a48._4_4_ <= uVar26) &&
       ((uVar26 != uStack_a48._4_4_ || (uStack_a40 <= (ushort)uStack_93c)))) goto LAB_;
  }
  if ((*(char *)(lVar16 + 0x6ac8) == '\0') &&
     (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) != *(longlong *)(lVar16 + 0x2120))) {
    cVar9 = func_0x(lVar16);
    if (cVar9 == '\0') {
      uVar26 = *(uint *)(lVar16 + 0x2108);
      do {
        uVar12 = uVar26 & 0xfffffffe;
        uStack_950 = *(undefined8 *)(lVar16 + 0x20fc);
        uStack_948 = *(undefined4 *)(lVar16 + 0x2104);
        LOCK();
        UNLOCK();
        uVar26 = *(uint *)(lVar16 + 0x2108);
      } while (uVar12 != uVar26);
      uVar10 = (ushort)uStack_948;
      uStack_8e8 = (ushort)uStack_948;
      lVar14 = *plStack_ad0;
      uStack_8f0 = uStack_950;
      if (*(short *)(lVar14 + 0x24) == 0) {
LAB_:
        uStack_a68 = *(undefined8 *)(lVar14 + 0x28);
        uStack_a60 = *(ushort *)(lVar14 + 0x30);
      }
      else {
        cVar9 = *(char *)(lVar14 + 1);
        if (cVar9 == '\v') {
          if (*(int *)(lVar14 + 0x18) != 99) {
LAB_:
            if (cVar9 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar9 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar14 + 0x18) != 99) goto LAB_;
        }
        uStack_9b8 = *(undefined4 *)(lVar14 + 0x20);
        uStack_9b4 = *(undefined2 *)(lVar14 + 0x24);
        cVar9 = func_0x(&uStack_9b8);
        if (cVar9 == '\0') goto LAB_;
        func_0x(lVar14,&uStack_a68);
      }
      if ((uint)uStack_950 < (uint)uStack_a68) {
LAB_:
        lVar14 = *(longlong *)(lVar16 + 0x6b0);
        func_0x(&uStack_a68,asStack_100,auStack_9e8);
        func_0x(&uStack_8f0,asStack_d0,auStack_9e8);
        if ((_DAT_ & 0x10000) != 0) {
          uStack_850 = 0x60000;
          uStack_848 = 0;
          ppuStack_840 = &puStack_828;
          puStack_838 = auStack_7c8;
          uStack_608 = 0;
          uStack_830 = 0;
          uStack_600 = 0;
          puStack_828 = &uStack_5f8;
          uStack_820 = 0x34;
          uStack_81c = 5;
          uStack_810 = 0x10;
          uStack_80c = 5;
          uStack_800 = 0x10;
          uStack_7fc = 6;
          uStack_7ec = 7;
          uStack_7dc = 8;
          uStack_7d8 = 0;
          uStack_7d0 = 0;
          uStack_7cc = 9;
          uStack_5f8 = (uint)*(ushort *)(lVar16 + 0x6b8);
          sStack_5f4 = sStack_a90;
          iStack_5f2 = iStack_a94;
          uStack_5ee = 0xff;
          uStack_5ed = *(undefined *)(*plStack_ad0 + 1);
          lStack_818 = lVar14 + 0x254;
          lStack_808 = lVar14 + 0x244;
          lVar16 = -1;
          do {
            lVar16 = lVar16 + 1;
          } while (asStack_100[lVar16] != 0);
          iStack_7f0 = (int)lVar16 * 2;
          psStack_7f8 = asStack_100;
          lVar16 = -1;
          do {
            lVar16 = lVar16 + 1;
          } while (asStack_d0[lVar16] != 0);
          iStack_7e0 = (int)lVar16 * 2;
          psStack_7e8 = asStack_d0;
          uStack_9e4 = 0;
          puVar17 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar14,&uStack_9e4);
          ppuVar7 = ppuStack_840;
          if (puVar17 != (uint *)0x0) {
            lVar16 = -1;
            do {
              lVar16 = lVar16 + 1;
            } while (*(short *)((longlong)puVar17 + lVar16 * 2) != 0);
            iVar11 = (int)lVar16 * 2;
          }
          ppuStack_840[10] = puVar17;
          *(int *)(ppuVar7 + 0xb) = iVar11;
          *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
          func_0x(auStack_858);
        }
      }
      else if ((uint)uStack_950 == (uint)uStack_a68) {
        uVar26 = (uint)((ulonglong)uStack_a68 >> 0x20);
        if ((uStack_950._4_4_ < uVar26) || ((uStack_950._4_4_ == uVar26 && (uVar10 < uStack_a60))))
        goto LAB_;
      }
LAB_:
      lVar16 = *(longlong *)(*plStack_a80 + 0x30);
      uStack_874 = 0;
      if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
        lVar14 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)
                   (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
        if ((lVar14 != 0) && (lVar14 = **(longlong **)(lVar14 + 0x38), lVar14 != 0)) {
          iVar11 = (*_DAT_)(lVar14,0x337);
          if (iVar11 != 0) goto LAB_;
        }
        lVar14 = *(longlong *)
                  ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
        if (lVar14 != 0) {
          lVar15 = *(longlong *)(lVar14 + 0x60);
        }
      }
LAB_:
      lVar14 = *(longlong *)(lVar16 + 0x728);
      do {
        plVar39 = plStack_ab8;
        iVar11 = 0;
        uStack_a74 = 0;
        if (plStack_ab8 != (longlong *)0x0) {
          iVar24 = (int)(short)uStack_aac;
          if (((*(ushort *)((longlong)plStack_ab8 + 0x62) & 0x400) == 0) || (iVar24 < 3)) {
            if (((byte)*(undefined2 *)((longlong)plStack_ab8 + 0x62) >> 3 & 1) != 0) {
              if (iVar24 == 3) {
                iVar24 = 4;
              }
              else if (iVar24 < 2) goto LAB_;
              if ((((*(uint *)((longlong)plStack_ab8 + 100) & 8) != 0) &&
                  (lVar43 = plStack_ab8[0x12], lVar43 != 0)) && (*(longlong *)(lVar43 + 0x758) != 0)
                 ) {
                func_0x(*(undefined8 *)(lVar43 + 0x758),plStack_ab8,iVar24);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar39 + 100) & 8) != 0)) &&
               ((2 < iVar24 &&
                (((*(uint *)((longlong)plVar39 + 100) & 0xc0000000) != 0x40000000 && (*plVar39 != 0)
                 ))))) {
              iVar13 = (*_DAT_)(*plVar39,0x2000,2,auStack_8b0);
              if (iVar13 != 0) {
                LOCK();
                *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            func_0x(plVar39 + 0x13,iVar24);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(plVar39,0,iVar24);
            }
            uStack_aac = uStack_aac & 0xffff0000;
            plStack_ab8 = (longlong *)0x0;
          }
          else {
            func_0x(&plStack_ab8);
          }
        }
        if (*(longlong *)(lVar16 + 0x728) != 0) {
          func_0x(&plStack_ab8,&iStack_a9c,lVar16);
          plVar39 = plStack_ab8;
          if (plStack_ab8 != (longlong *)0x0) {
            iVar24 = (int)(short)uStack_aac;
            if (((*(ushort *)((longlong)plStack_ab8 + 0x62) & 0x400) == 0) || (iVar24 < 3)) {
              if (((byte)*(undefined2 *)((longlong)plStack_ab8 + 0x62) >> 3 & 1) != 0) {
                if (iVar24 == 3) {
                  iVar24 = 4;
                }
                else if (iVar24 < 2) goto LAB_;
                if ((((*(uint *)((longlong)plStack_ab8 + 100) & 8) != 0) &&
                    (lVar43 = plStack_ab8[0x12], lVar43 != 0)) &&
                   (*(longlong *)(lVar43 + 0x758) != 0)) {
                  func_0x(*(undefined8 *)(lVar43 + 0x758),plStack_ab8,iVar24);
                }
              }
LAB_:
              if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar39 + 100) & 8) != 0))
                 && ((2 < iVar24 &&
                     (((*(uint *)((longlong)plVar39 + 100) & 0xc0000000) != 0x40000000 &&
                      (*plVar39 != 0)))))) {
                iVar13 = (*_DAT_)(*plVar39,0x2000,2,auStack_8b4);
                if (iVar13 != 0) {
                  LOCK();
                  *(uint *)((longlong)plVar39 + 100) =
                       *(uint *)((longlong)plVar39 + 100) & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *(uint *)((longlong)plVar39 + 100) =
                       *(uint *)((longlong)plVar39 + 100) | 0x40000000;
                  UNLOCK();
                }
              }
              func_0x(plVar39 + 0x13,iVar24);
              if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                func_0x(plVar39,0,iVar24);
              }
              uStack_aac = uStack_aac & 0xffff0000;
              plStack_ab8 = (longlong *)0x0;
            }
            else {
              func_0x(&plStack_ab8);
            }
          }
        }
        func_0x(lVar16,&iStack_a9c);
        uStack_b10 = &uStack_878;
        uStack_b18 = (uint *)CONCAT44(uStack_b18._4_4_,4);
        plStack_ab8 = (longlong *)
                      func_0x(_DAT_,lVar16,&iStack_a9c,&uStack_a74);
        if (lVar15 != 0) {
          uVar45 = (ulonglong)(*(uint *)(lVar15 + 0x500) & 0xf);
          if (*(longlong *)(lVar15 + 0x508 + uVar45 * 8) != *plStack_ab8) {
            *(longlong *)(lVar15 + 0x508 + uVar45 * 8) = *plStack_ab8;
            *(longlong *)(lVar15 + 0x500) = *(longlong *)(lVar15 + 0x500) + 1;
          }
        }
        uStack_aac = (uStack_a74 >> 3 & 1) << 0x18 | uStack_aac & 0xff0004 | 4;
        uStack_aa8 = uStack_a74 >> 4 & 1 | uStack_aa8 & 0xffffff00;
        if (((lVar14 != 0) && (lVar15 != 0)) && (lVar15 == *(longlong *)(lVar16 + 0x1c38))) {
          *(longlong *)(lVar14 + 0x5b28) = *(longlong *)(lVar14 + 0x5b28) + 1;
          if ((int)uStack_874 != 0) {
            *(longlong *)(lVar14 + 0x5b30) = *(longlong *)(lVar14 + 0x5b30) + 1;
            *(longlong *)(lVar14 + 0x5b38) = *(longlong *)(lVar14 + 0x5b38) + (ulonglong)uStack_878;
            if (0xffffff < uStack_aac) {
              *(longlong *)(lVar14 + 0x5b40) = *(longlong *)(lVar14 + 0x5b40) + 1;
              *(longlong *)(lVar14 + 0x5b48) =
                   *(longlong *)(lVar14 + 0x5b48) + (ulonglong)uStack_878;
            }
          }
        }
        cVar9 = func_0x(lVar16);
        if (((cVar9 == '\0') || (*(char *)(lVar16 + 0x2050) == '\0')) ||
           ((iStack_a9c == 0 || ((iStack_a9c == 9 && (sStack_a98 == 1)))))) goto LAB_;
        lVar43 = *plStack_ab8;
        if (*(short *)(lVar43 + 0x24) == 0) {
LAB_:
          uStack_9f8 = *(undefined8 *)(lVar43 + 0x28);
          uStack_9f0 = *(ushort *)(lVar43 + 0x30);
        }
        else {
          cVar9 = *(char *)(lVar43 + 1);
          if (cVar9 == '\v') {
            if (*(int *)(lVar43 + 0x18) != 99) {
LAB_:
              if (cVar9 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar9 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar43 + 0x18) != 99) goto LAB_;
          }
          uStack_9b0 = *(undefined4 *)(lVar43 + 0x20);
          uStack_9ac = *(undefined2 *)(lVar43 + 0x24);
          cVar9 = func_0x(&uStack_9b0);
          if (cVar9 == '\0') goto LAB_;
          func_0x(lVar43,&uStack_9f8);
        }
        uVar26 = *(uint *)(lVar16 + 0x2108);
        do {
          uVar12 = uVar26 & 0xfffffffe;
          uStack_938 = *(undefined8 *)(lVar16 + 0x20fc);
          uStack_930 = *(undefined4 *)(lVar16 + 0x2104);
          LOCK();
          UNLOCK();
          uVar26 = *(uint *)(lVar16 + 0x2108);
        } while (uVar12 != uVar26);
        if ((uint)uStack_9f8 <= (uint)uStack_938) {
          if ((uint)uStack_938 == (uint)uStack_9f8) {
            uVar26 = (uint)((ulonglong)uStack_938 >> 0x20);
            if ((uVar26 < uStack_9f8._4_4_) ||
               ((uVar26 == uStack_9f8._4_4_ && ((ushort)uStack_930 < uStack_9f0))))
            goto LAB_;
          }
          goto LAB_;
        }
LAB_:
        if ((*(char *)(lVar16 + 0x6ac8) == '\0') &&
           (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8) + 0x60) != *(longlong *)(lVar16 + 0x2120))) {
          cVar9 = func_0x(lVar16);
          if (cVar9 == '\0') {
            uVar26 = *(uint *)(lVar16 + 0x2108);
            do {
              uVar12 = uVar26 & 0xfffffffe;
              uStack_92c = *(undefined8 *)(lVar16 + 0x20fc);
              uStack_924 = *(undefined4 *)(lVar16 + 0x2104);
              LOCK();
              UNLOCK();
              uVar26 = *(uint *)(lVar16 + 0x2108);
            } while (uVar12 != uVar26);
            uVar10 = (ushort)uStack_924;
            uStack_8f8 = (ushort)uStack_924;
            lVar14 = *plStack_ab8;
            uStack_900 = uStack_92c;
            if (*(short *)(lVar14 + 0x24) == 0) {
LAB_:
              uStack_a58 = *(undefined8 *)(lVar14 + 0x28);
              uStack_a50 = *(ushort *)(lVar14 + 0x30);
            }
            else {
              cVar9 = *(char *)(lVar14 + 1);
              if (cVar9 == '\v') {
                if (*(int *)(lVar14 + 0x18) != 99) {
LAB_:
                  if (cVar9 != '\t') goto LAB_;
                  goto LAB_;
                }
              }
              else {
                if (cVar9 != '\b') goto LAB_;
LAB_:
                if (*(int *)(lVar14 + 0x18) != 99) goto LAB_;
              }
              uStack_9a0 = *(undefined4 *)(lVar14 + 0x20);
              uStack_99c = *(undefined2 *)(lVar14 + 0x24);
              cVar9 = func_0x(&uStack_9a0);
              if (cVar9 == '\0') goto LAB_;
              func_0x(lVar14,&uStack_a58);
            }
            if ((uint)uStack_92c < (uint)uStack_a58) {
LAB_:
              lVar14 = *(longlong *)(lVar16 + 0x6b0);
              func_0x(&uStack_a58,asStack_a0,auStack_970);
              func_0x(&uStack_900,asStack_70,auStack_970);
              if ((_DAT_ & 0x10000) != 0) {
                uStack_5b0 = 0x60000;
                uStack_5a8 = 0;
                ppuStack_5a0 = &puStack_588;
                puStack_598 = auStack_528;
                uStack_368 = 0;
                uStack_590 = 0;
                uStack_360 = 0;
                puStack_588 = &uStack_358;
                uStack_580 = 0x34;
                uStack_57c = 5;
                uStack_570 = 0x10;
                uStack_56c = 5;
                uStack_560 = 0x10;
                uStack_55c = 6;
                uStack_54c = 7;
                uStack_53c = 8;
                uStack_538 = 0;
                uStack_530 = 0;
                uStack_52c = 9;
                uStack_358 = (uint)*(ushort *)(lVar16 + 0x6b8);
                sStack_354 = sStack_a98;
                iStack_352 = iStack_a9c;
                uStack_34e = 0xff;
                uStack_34d = *(undefined *)(*plStack_ab8 + 1);
                lStack_578 = lVar14 + 0x254;
                lStack_568 = lVar14 + 0x244;
                lVar16 = -1;
                do {
                  lVar16 = lVar16 + 1;
                } while (asStack_a0[lVar16] != 0);
                iStack_550 = (int)lVar16 * 2;
                psStack_558 = asStack_a0;
                lVar16 = -1;
                do {
                  lVar16 = lVar16 + 1;
                } while (asStack_70[lVar16] != 0);
                iStack_540 = (int)lVar16 * 2;
                psStack_548 = asStack_70;
                uStack_9e0 = 0;
                puVar17 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar14,&uStack_9e0);
                ppuVar7 = ppuStack_5a0;
                if (puVar17 != (uint *)0x0) {
                  lVar16 = -1;
                  do {
                    lVar16 = lVar16 + 1;
                  } while (*(short *)((longlong)puVar17 + lVar16 * 2) != 0);
                  iVar11 = (int)lVar16 * 2;
                }
                ppuStack_5a0[10] = puVar17;
                *(int *)(ppuVar7 + 0xb) = iVar11;
                *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
                func_0x(auStack_5b8);
              }
            }
            else if ((uint)uStack_92c == (uint)uStack_a58) {
              uVar26 = (uint)((ulonglong)uStack_a58 >> 0x20);
              if ((uStack_92c._4_4_ < uVar26) ||
                 ((uStack_92c._4_4_ == uVar26 && (uVar10 < uStack_a50)))) goto LAB_;
            }
            goto LAB_;
          }
        }
        if (*(longlong *)
             (*(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8) + 0x60) == *(longlong *)(lVar16 + 0x2120)) goto LAB_;
        cVar9 = func_0x(lVar16);
        if (cVar9 != '\0') goto LAB_;
        if (lVar15 == 0) {
          lVar15 = func_0x();
        }
        lVar43 = *plStack_ab8;
        if (*(short *)(lVar43 + 0x24) == 0) {
LAB_:
          uStack_9d8 = *(undefined8 *)(lVar43 + 0x28);
          uStack_9d0 = *(undefined2 *)(lVar43 + 0x30);
        }
        else {
          cVar9 = *(char *)(lVar43 + 1);
          if (cVar9 == '\v') {
            if (*(int *)(lVar43 + 0x18) != 99) {
LAB_:
              if (cVar9 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar9 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar43 + 0x18) != 99) goto LAB_;
          }
          uStack_9a8 = *(undefined4 *)(lVar43 + 0x20);
          uStack_9a4 = *(undefined2 *)(lVar43 + 0x24);
          cVar9 = func_0x(&uStack_9a8);
          if (cVar9 == '\0') goto LAB_;
          func_0x(lVar43,&uStack_9d8);
        }
        uVar41 = uStack_9d0;
        uVar19 = uStack_9d8;
        plVar39 = plStack_ab8;
        if (plStack_ab8 != (longlong *)0x0) {
          iVar11 = (int)(short)uStack_aac;
          if (((*(ushort *)((longlong)plStack_ab8 + 0x62) >> 10 & 1) == 0) || (iVar11 < 3)) {
            if (((byte)*(undefined2 *)((longlong)plStack_ab8 + 0x62) >> 3 & 1) != 0) {
              if (iVar11 == 3) {
                iVar11 = 4;
              }
              else if (iVar11 < 2) goto LAB_;
              if ((((*(uint *)((longlong)plStack_ab8 + 100) & 8) != 0) &&
                  (lVar43 = plStack_ab8[0x12], lVar43 != 0)) && (*(longlong *)(lVar43 + 0x758) != 0)
                 ) {
                func_0x(*(undefined8 *)(lVar43 + 0x758),plStack_ab8,iVar11);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar39 + 100) & 8) != 0)) &&
               ((2 < iVar11 &&
                (((*(uint *)((longlong)plVar39 + 100) & 0xc0000000) != 0x40000000 && (*plVar39 != 0)
                 ))))) {
              iVar24 = (*_DAT_)(*plVar39,0x2000,2,auStack_8b8);
              if (iVar24 != 0) {
                LOCK();
                *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            func_0x(plVar39 + 0x13,iVar11);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              func_0x(plVar39,0,iVar11);
            }
            uStack_aac = uStack_aac & 0xffff0000;
            plStack_ab8 = (longlong *)0x0;
          }
          else {
            func_0x(&plStack_ab8);
          }
        }
        uStack_b18 = (uint *)0x0;
        uStack_8e0 = uVar19;
        uStack_8d8 = uVar41;
        func_0x(*(undefined8 *)(lVar16 + 0x728),&uStack_8e0,4);
      } while( true );
    }
  }
  if (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) == *(longlong *)(lVar16 + 0x2120)) goto LAB_;
  cVar9 = func_0x(lVar16);
  if (cVar9 != '\0') goto LAB_;
  if (lVar14 == 0) {
    lVar14 = func_0x();
  }
  lVar15 = *plStack_ad0;
  if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
    uStack_960 = *(undefined8 *)(lVar15 + 0x28);
    uStack_958 = *(undefined2 *)(lVar15 + 0x30);
  }
  else {
    cVar9 = *(char *)(lVar15 + 1);
    if (cVar9 == '\v') {
      if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
        if (cVar9 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar9 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
    }
    uStack_9c0 = *(undefined4 *)(lVar15 + 0x20);
    uStack_9bc = *(undefined2 *)(lVar15 + 0x24);
    cVar9 = func_0x(&uStack_9c0);
    if (cVar9 == '\0') goto LAB_;
    func_0x(lVar15,&uStack_960);
  }
  uVar41 = uStack_958;
  uVar19 = uStack_960;
  plVar39 = plStack_ad0;
  if (plStack_ad0 != (longlong *)0x0) {
    iVar11 = (int)(short)uStack_ac4;
    if (((*(ushort *)((longlong)plStack_ad0 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
      if (((byte)*(undefined2 *)((longlong)plStack_ad0 + 0x62) >> 3 & 1) != 0) {
        if (iVar11 == 3) {
          iVar11 = 4;
        }
        else if (iVar11 < 2) goto LAB_;
        if ((((*(uint *)((longlong)plStack_ad0 + 100) & 8) != 0) &&
            (lVar15 = plStack_ad0[0x12], lVar15 != 0)) && (*(longlong *)(lVar15 + 0x758) != 0)) {
          func_0x(*(undefined8 *)(lVar15 + 0x758),plStack_ad0,iVar11);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar39 + 100) & 8) != 0)) &&
         ((2 < iVar11 &&
          (((*(uint *)((longlong)plVar39 + 100) & 0xc0000000) != 0x40000000 && (*plVar39 != 0))))))
      {
        iVar24 = (*_DAT_)(*plVar39,0x2000,2,auStack_898);
        if (iVar24 != 0) {
          LOCK();
          *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar39 + 100) = *(uint *)((longlong)plVar39 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      func_0x(plVar39 + 0x13,iVar11);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        func_0x(plVar39,0,iVar11);
      }
      uStack_ac4 = uStack_ac4 & 0xffff0000;
      plStack_ad0 = (longlong *)0x0;
    }
    else {
      func_0x(&plStack_ad0);
    }
  }
  uStack_b18 = (uint *)0x0;
  uStack_8d0 = uVar19;
  uStack_8c8 = uVar41;
  func_0x(*(undefined8 *)(lVar16 + 0x728),&uStack_8d0,4);
  goto LAB_;
LAB_:
  plVar39 = plStack_a80;
  lVar16 = *plStack_ad0;
  lVar14 = *plStack_ab8;
  uVar21 = 2;
  if (1 < *(int *)(plStack_a80 + 3) + 1U) {
    uVar21 = 0;
  }
  uStack_96c = *(undefined4 *)(lVar14 + 0x20);
  uStack_968 = *(undefined2 *)(lVar14 + 0x24);
  uStack_b08 = (int *)plStack_a80[1];
  uStack_b18 = &uStack_96c;
  lStack_918 = lVar14;
  uStack_b10._0_4_ = uVar21;
  func_0x(&plStack_ad0,plStack_a80[5] + 0x3c0,0x10,6);
  uVar21 = 2;
  if (1 < *(int *)(plVar39 + 3) + 1U) {
    uVar21 = 0;
  }
  uStack_998 = *(uint *)(lVar16 + 0x20);
  uStack_994 = *(undefined2 *)(lVar16 + 0x24);
  uStack_b08 = (int *)plVar39[1];
  uStack_b10 = (uint *)CONCAT44(uStack_b10._4_4_,uVar21);
  uStack_b18 = &uStack_998;
  func_0x(&plStack_ab8,plVar39[5] + 0x3c0,8,6);
  if ((*(char *)(lVar16 + 1) == '\x01') ||
     (((*(char *)(lVar16 + 1) == '\x02' && (*(char *)(lVar16 + 3) == '\0')) &&
      (1 < *(ushort *)(lVar16 + 6))))) {
    uStack_268 = 0xffff;
    puVar44 = (undefined *)0x0;
    pbStack_260 = (byte *)0x0;
    uStack_264 = 0;
    uStack_24a = 0;
    uStack_248 = 0;
    uStack_240 = 0;
    uStack_23e = 0;
    uStack_258 = (undefined *)0x0;
    uStack_1b8 = 0xffff;
    pbStack_1b0 = (byte *)0x0;
    uStack_1b4 = 0;
    uStack_19a = 0;
    uStack_198 = 0;
    uStack_190 = 0;
    uStack_18e = 0;
    uStack_1a8 = (byte **)0x0;
    uVar26 = (uint)*(ushort *)(**(longlong **)(plVar39[5] + 0x160) + 0x1c);
    uVar10 = *(ushort *)(lVar16 + 0x16);
    iStack_234 = uVar10 - 1;
    uStack_a8c = uVar26;
    if (*(char *)(lVar16 + 2) < '\0') {
      pbVar1 = (byte *)(lVar16 + 0x60);
      sStack_208 = 0;
      sStack_206 = 0;
      sStack_204 = 0;
      uStack_1fa = 0;
      uStack_1f0 = SUB164(ZEXT816(0),0);
      uStack_1f0 = 0;
      uStack_1ec = SUB164(ZEXT816(0),4);
      uStack_1ec = 0;
      psStack_1e0 = (short *)0x0;
      sStack_1d8 = 0;
      uStack_1d6 = 0;
      auStack_230._8_8_ = 0;
      _auStack_21e = SUB1614(ZEXT816(0),2);
      auStack_220 = (undefined  [2])0xffff;
      uStack_218 = 0;
      uStack_202 = 0;
      uStack_200 = 0;
      uStack_1f8 = 0;
      uStack_1f6 = 0;
      uStack_210 = 0;
      uStack_20c = 0;
      psStack_1e8 = (short *)0x0;
      _auStack_1d0 = ZEXT812(0);
      auStack_1c6._2_4_ = 0;
      uStack_1c0 = 0;
      puVar44 = auStack_230;
      uVar19 = 0;
      if (*(short *)(lVar16 + 0x24) == 0) {
LAB_:
        auStack_230._8_8_ = uVar19;
        uStack_a28 = *(undefined8 *)(lVar16 + 0x28);
        uStack_a20 = *(undefined2 *)(lVar16 + 0x30);
      }
      else {
        cVar9 = *(char *)(lVar16 + 1);
        if (cVar9 == '\v') {
          if (*(int *)(lVar16 + 0x18) != 99) {
LAB_:
            if (cVar9 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar9 != '\b') goto LAB_;
LAB_:
          uVar19 = auStack_230._8_8_;
          if (*(int *)(lVar16 + 0x18) != 99) goto LAB_;
        }
        uStack_980 = *(undefined4 *)(lVar16 + 0x20);
        uStack_97c = *(undefined2 *)(lVar16 + 0x24);
        auStack_230 = ZEXT816(0);
        cVar9 = func_0x(&uStack_980);
        uVar19 = auStack_230._8_8_;
        if (cVar9 == '\0') goto LAB_;
        func_0x(lVar16,&uStack_a28);
      }
      auStack_230._0_8_ = pbVar1;
      auStack_1d0._8_2_ = uStack_a20;
      auStack_1d0._0_8_ = uStack_a28;
      auStack_1c6._2_4_ = *(undefined4 *)(lVar16 + 0x20);
      uStack_a88 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x109ebd0);
      uVar45 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x109ebd4);
      auStack_220 = (undefined  [2])0xffff;
      uVar12 = 0;
      _auStack_220 = _auStack_220 & 0xffffffff;
      uStack_218 = 0;
      uStack_202 = 0;
      uStack_200 = 0;
      uStack_1f8 = 0;
      uStack_1f6 = 0;
      uStack_210 = 0;
      uStack_20c = 0;
      psStack_1e8 = (short *)0x0;
      psStack_1e0 = (short *)0x0;
      sStack_1d8 = 0;
      if ((*pbVar1 & 2) != 0) {
        pbVar30 = pbVar1 + uVar45;
        uStack_218 = pbVar30;
        auVar6 = _auStack_220;
        if ((*pbVar30 & 1) == 0) {
          auVar6._14_2_ = 0;
          auVar6._0_14_ = _auStack_21e;
          _auStack_220 = auVar6 << 0x10;
          uStack_1fa = 0;
          uStack_1f8 = 0;
          switch(*pbVar30 & 0xe) {
          default:
            uVar12 = (uint)*(ushort *)(pbVar30 + 2);
            if (0x1f9d < *(ushort *)(pbVar30 + 2) - 1) {
              func_0x(pbVar30,6);
            }
            break;
          case 4:
            uVar12 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar12 = 1;
          }
          uStack_210 = uVar12;
          uStack_202 = 0;
          uStack_200 = 0;
        }
        else {
          auStack_220 = (undefined  [2])0x1;
          auVar8 = _auStack_220;
          bVar3 = *pbVar30;
          stack0xfffffffffffffde4 = auVar6._4_12_;
          switch(bVar3 & 0x1c) {
          default:
            if ((char)pbVar30[1] < '\0') {
              sStack_208 = 3;
              auStack_21e._0_2_ =
                   (*(ushort *)(pbVar30 + 1) & 0x7f) << 8 | *(ushort *)(pbVar30 + 1) >> 8;
            }
            else {
              sStack_208 = 2;
              auStack_21e._0_2_ = ZEXT12(pbVar30[1]);
            }
            auStack_220 = (undefined  [2])0x1;
            sStack_204 = (short)((ushort)auStack_21e._0_2_ + 1 >> 1) + sStack_208;
            if ((ushort)auStack_21e._0_2_ < 0x1f) {
              sStack_206 = 0;
              uStack_1f0 = 0;
              uStack_1f8 = 0;
              uStack_1f6 = 0;
              uStack_210 = 0;
              uStack_20c = 0;
            }
            else {
              iVar11 = (ushort)auStack_21e._0_2_ - 1;
              sStack_206 = ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                           (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
              uStack_1f0 = 0;
              uStack_1f8 = 0;
              uStack_1f6 = 0;
              uStack_210 = 0;
              uStack_20c = 0;
            }
            break;
          case 4:
            _auStack_220 = auVar8._0_4_;
            if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
              uVar12 = 1;
              _auStack_220 = CONCAT44(0xf,_auStack_220);
              uVar19 = _auStack_220;
            }
            else {
              _auStack_220 = CONCAT44(1,_auStack_220);
              uVar19 = _auStack_220;
            }
            _auStack_220 = uVar19;
            uStack_1fa = 0;
            sStack_204 = 0;
            auStack_220 = SUB82(uVar19,0);
            auStack_21e._0_2_ = 0;
            sStack_208 = 0;
            sStack_206 = 0;
            uStack_1f0 = uVar12;
            uStack_1f8 = 0;
            uStack_1f6 = 0;
            uStack_210 = 0;
            uStack_20c = 0;
            break;
          case 8:
            sStack_208 = 0;
            sStack_206 = 0;
            sStack_204 = 0;
            uStack_1fa = 0;
            _auStack_220 = 0x900000001;
            uStack_1f0 = 0;
            uStack_1f8 = 0;
            uStack_1f6 = 0;
            uStack_210 = 0;
            uStack_20c = 0;
          }
        }
      }
      uStack_200 = 0;
      uStack_202 = 0;
      if ((*(byte *)auStack_230._0_8_ & 4) != 0) {
        if (uStack_a88._2_2_ != 0) {
          uVar45 = (ulonglong)*(ushort *)(lVar16 + 0x61 + (longlong)uStack_a88._2_2_ * 2);
        }
        psStack_1e8 = (short *)(pbVar1 + uVar45);
        psStack_1e0 = psStack_1e8 + 1;
        sStack_1d8 = (*psStack_1e8 + 1) * 2;
      }
      if (auStack_230._8_8_ != 0) {
        func_0x(auStack_230._8_8_,auStack_230);
      }
    }
    uVar12 = (uint)*(ushort *)(lVar16 + 0xe);
    pbStack_260 = (byte *)((ulonglong)*(ushort *)(lVar16 + (0x1000 - (ulonglong)uVar10) * 2) +
                          lVar16);
    if ((*pbStack_260 & 1) == 0) {
      uStack_268 = 0;
      uStack_264 = 0;
      uStack_242 = 0;
      uStack_240 = 0;
      switch(*pbStack_260 & 0xe) {
      default:
        uVar12 = (uint)*(ushort *)(pbStack_260 + 2);
        if (0x1f9d < *(ushort *)(pbStack_260 + 2) - 1) {
          func_0x(pbStack_260,6);
        }
        break;
      case 4:
        uVar12 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar12 = 1;
      }
      uStack_258 = (undefined *)CONCAT44(uStack_258._4_4_,uVar12);
      uStack_24a = (undefined2)(lVar16 + 0x2000);
      uStack_248 = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
    }
    else {
      uStack_268 = 1;
      bVar3 = *pbStack_260;
      switch(bVar3 & 0x1c) {
      default:
        if ((char)pbStack_260[1] < '\0') {
          uStack_266 = (*(ushort *)(pbStack_260 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_260 + 1) >> 8;
          uStack_250 = 3;
          sVar35 = 3;
        }
        else {
          uStack_266 = (ushort)pbStack_260[1];
          uStack_250 = 2;
          sVar35 = 2;
        }
        sStack_24c = (short)(uStack_266 + 1 >> 1) + sVar35;
        if (uStack_266 < 0x1f) {
          sStack_24e = 0;
          uStack_264 = 0;
          uStack_238 = 0;
        }
        else {
          iVar11 = uStack_266 - 1;
          sStack_24e = ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                       (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
          uStack_264 = 0;
          uStack_238 = 0;
        }
        break;
      case 4:
        if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
          uStack_250 = 0;
          sStack_24e = 0;
          sStack_24c = 0;
          uStack_24a = 0;
          uStack_266 = 0;
          uStack_248 = 0;
          uStack_242 = 0;
          uStack_264 = 0xf;
          uStack_238 = 1;
        }
        else {
          uStack_250 = 0;
          sStack_24e = 0;
          sStack_24c = 0;
          uStack_24a = 0;
          uStack_266 = 0;
          uStack_248 = 0;
          uStack_242 = 0;
          uStack_264 = 1;
          uStack_238 = 0;
        }
        break;
      case 8:
        uStack_250 = 0;
        sStack_24e = 0;
        sStack_24c = 0;
        uStack_24a = 0;
        uStack_266 = 0;
        uStack_248 = 0;
        uStack_242 = 0;
        uStack_264 = 9;
        uStack_238 = 0;
      }
      uStack_240 = (undefined2)(lVar16 + 0x2000);
      uStack_23e = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
      uStack_258 = puVar44;
    }
    lVar16 = lStack_918;
    ppbVar33 = (byte **)0x0;
    uStack_184 = 0;
    ppbVar29 = ppbVar33;
    if (*(char *)(lStack_918 + 2) < '\0') {
      pbVar1 = (byte *)(lStack_918 + 0x60);
      if ((uStack_1b8 == 0) || (ppbVar28 = uStack_1a8, uStack_1a8 == (byte **)0x0)) {
        uStack_158 = 0;
        uStack_14a = 0;
        auStack_130 = ZEXT816(0);
        auStack_180 = ZEXT816(0);
        stack0xfffffffffffffe92 = SUB1614(ZEXT816(0),2);
        auStack_170._0_2_ = 0xffff;
        uStack_168 = 0;
        uStack_152 = 0;
        uStack_150 = 0;
        uStack_148 = 0;
        uStack_160 = 0;
        auStack_140 = ZEXT816(0);
        auStack_120._0_12_ = ZEXT812(0);
        auStack_120._12_4_ = 0;
        uStack_110 = 0;
        ppbVar28 = (byte **)auStack_180;
      }
      if (*(short *)(lStack_918 + 0x24) == 0) {
code_r0x001043a6:
        uStack_a38 = *(undefined8 *)(lVar16 + 0x28);
        uStack_a30 = *(undefined2 *)(lVar16 + 0x30);
      }
      else {
        cVar9 = *(char *)(lStack_918 + 1);
        if (cVar9 == '\v') {
          if (*(int *)(lStack_918 + 0x18) != 99) {
code_r0x00104367:
            if (cVar9 != '\t') goto code_r0x001043a6;
            goto code_r0x0010436b;
          }
        }
        else {
          if (cVar9 != '\b') goto code_r0x00104367;
code_r0x0010436b:
          if (*(int *)(lStack_918 + 0x18) != 99) goto code_r0x001043a6;
        }
        uStack_978 = *(undefined4 *)(lStack_918 + 0x20);
        uStack_974 = *(undefined2 *)(lStack_918 + 0x24);
        cVar9 = func_0x(&uStack_978);
        ppbVar29 = ppbVar33;
        if (cVar9 == '\0') goto code_r0x001043a6;
        func_0x(lVar16,&uStack_a38);
        ppbVar29 = ppbVar33;
      }
      *ppbVar28 = pbVar1;
      *(undefined4 *)(ppbVar28 + 0xc) = (undefined4)uStack_a38;
      *(int *)((longlong)ppbVar28 + 100) = (int)((ulonglong)uStack_a38 >> 0x20);
      *(undefined2 *)(ppbVar28 + 0xd) = uStack_a30;
      *(undefined4 *)((longlong)ppbVar28 + 0x6c) = *(undefined4 *)(lVar16 + 0x20);
      *(undefined2 *)(ppbVar28 + 0xe) = *(undefined2 *)(lVar16 + 0x24);
      uVar41 = SUB82(ppbVar29,0);
      *(undefined2 *)((longlong)ppbVar28 + 0x72) = uVar41;
      uStack_a88 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x109ebd0);
      uVar45 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x109ebd4);
      *(undefined2 *)(ppbVar28 + 2) = 0xffff;
      ppbVar28[3] = (byte *)ppbVar29;
      uVar12 = (uint)ppbVar29;
      *(uint *)((longlong)ppbVar28 + 0x14) = uVar12;
      *(byte ***)((longlong)ppbVar28 + 0x2e) = ppbVar29;
      ppbVar28[7] = (byte *)ppbVar29;
      ppbVar28[4] = (byte *)ppbVar29;
      ppbVar28[9] = (byte *)ppbVar29;
      ppbVar28[10] = (byte *)ppbVar29;
      *(undefined2 *)(ppbVar28 + 0xb) = uVar41;
      if ((**ppbVar28 & 2) != 0) {
        pbVar30 = pbVar1 + uVar45;
        if ((*pbVar30 & 1) == 0) {
          *(undefined2 *)(ppbVar28 + 2) = uVar41;
          ppbVar28[3] = pbVar30;
          *(uint *)((longlong)ppbVar28 + 0x14) = uVar12;
          *(uint *)((longlong)ppbVar28 + 0x36) = uVar12;
          switch(*pbVar30 & 0xe) {
          default:
            uVar12 = (uint)*(ushort *)(pbVar30 + 2);
            if (0x1f9d < *(ushort *)(pbVar30 + 2) - 1) {
              func_0x(pbVar30,6);
              ppbVar29 = (byte **)0x0;
            }
            break;
          case 4:
            uVar12 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar12 = 1;
          }
          *(uint *)(ppbVar28 + 4) = uVar12;
          *(byte ***)((longlong)ppbVar28 + 0x2e) = ppbVar29;
        }
        else {
          *(undefined2 *)(ppbVar28 + 2) = 1;
          ppbVar28[3] = pbVar30;
          bVar3 = *pbVar30;
          switch(bVar3 & 0x1c) {
          default:
            if ((char)pbVar30[1] < '\0') {
              uVar10 = *(ushort *)(pbVar30 + 1);
              *(ushort *)((longlong)ppbVar28 + 0x12) = uVar10;
              sVar35 = 3;
              uVar10 = (uVar10 & 0x7f) << 8 | uVar10 >> 8;
            }
            else {
              sVar35 = 2;
              uVar10 = (ushort)pbVar30[1];
            }
            *(ushort *)((longlong)ppbVar28 + 0x12) = uVar10;
            *(short *)(ppbVar28 + 5) = sVar35;
            *(short *)((longlong)ppbVar28 + 0x2c) =
                 (short)(*(ushort *)((longlong)ppbVar28 + 0x12) + 1 >> 1) + sVar35;
            if (*(ushort *)((longlong)ppbVar28 + 0x12) < 0x1f) {
              *(undefined2 *)((longlong)ppbVar28 + 0x2a) = uVar41;
              *(uint *)((longlong)ppbVar28 + 0x14) = uVar12;
              *(uint *)(ppbVar28 + 8) = uVar12;
              ppbVar28[7] = (byte *)ppbVar29;
              ppbVar28[4] = (byte *)ppbVar29;
            }
            else {
              iVar11 = *(ushort *)((longlong)ppbVar28 + 0x12) - 1;
              *(short *)((longlong)ppbVar28 + 0x2a) =
                   ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                   (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
              *(uint *)((longlong)ppbVar28 + 0x14) = uVar12;
              *(uint *)(ppbVar28 + 8) = uVar12;
              ppbVar28[7] = (byte *)ppbVar29;
              ppbVar28[4] = (byte *)ppbVar29;
            }
            break;
          case 4:
            if (((bVar3 & 0x1c) != 4) || (uVar32 = 1, (bVar3 & 2) == 0)) {
              uVar32 = uVar12;
            }
            *(uint *)((longlong)ppbVar28 + 0x14) = uVar12;
            ppbVar28[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar28 + 0x12) = uVar41;
            ppbVar28[6] = (byte *)0x0;
            ppbVar28[4] = (byte *)ppbVar29;
            *(uint *)(ppbVar28 + 8) = uVar12;
            ppbVar28[7] = (byte *)ppbVar29;
            ppbVar28[3] = pbVar30;
            if (uVar32 == 0) {
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 1;
              *(uint *)(ppbVar28 + 8) = uVar12;
              ppbVar28[7] = (byte *)ppbVar29;
              ppbVar28[4] = (byte *)ppbVar29;
            }
            else {
              *(undefined4 *)((longlong)ppbVar28 + 0x14) = 0xf;
              *(uint *)(ppbVar28 + 8) = uVar12;
              *(undefined4 *)(ppbVar28 + 8) = 1;
              ppbVar28[7] = (byte *)ppbVar29;
              ppbVar28[4] = (byte *)ppbVar29;
            }
            break;
          case 8:
            ppbVar28[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar28 + 0x12) = uVar41;
            ppbVar28[6] = (byte *)0x0;
            ppbVar28[4] = (byte *)ppbVar29;
            ppbVar28[7] = (byte *)ppbVar29;
            ppbVar28[3] = pbVar30;
            *(undefined4 *)((longlong)ppbVar28 + 0x14) = 9;
            *(uint *)(ppbVar28 + 8) = uVar12;
            ppbVar28[7] = (byte *)ppbVar29;
            ppbVar28[4] = (byte *)ppbVar29;
          }
        }
      }
      if ((**ppbVar28 & 4) != 0) {
        if (uStack_a88._2_2_ != 0) {
          uVar45 = (ulonglong)*(ushort *)(lVar16 + 0x61 + (longlong)uStack_a88._2_2_ * 2);
        }
        psVar18 = (short *)(pbVar1 + uVar45);
        ppbVar28[9] = (byte *)psVar18;
        sVar35 = *psVar18;
        ppbVar28[10] = (byte *)(psVar18 + 1);
        *(short *)(ppbVar28 + 0xb) = (sVar35 + 1) * 2;
      }
      ppbVar33 = ppbVar28;
      if (ppbVar28[1] != (byte *)0x0) {
        func_0x(ppbVar28[1],ppbVar28);
        ppbVar29 = (byte **)0x0;
      }
    }
    uVar12 = (uint)*(ushort *)(lVar16 + 0xe);
    pbStack_1b0 = (byte *)((ulonglong)*(ushort *)(lVar16 + 0x1ffe) + lVar16);
    uVar10 = (ushort)ppbVar29;
    uStack_1b4 = SUB84(ppbVar29,0);
    if ((*pbStack_1b0 & 1) == 0) {
      uStack_190 = (undefined2)((ulonglong)ppbVar29 >> 0x10);
      uStack_1b8 = uVar10;
      uStack_192 = uVar10;
      switch(*pbStack_1b0 & 0xe) {
      default:
        uVar12 = (uint)*(ushort *)(pbStack_1b0 + 2);
        if (0x1f9d < *(ushort *)(pbStack_1b0 + 2) - 1) {
          func_0x(pbStack_1b0,6);
        }
        break;
      case 4:
        uVar12 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar12 = 1;
      }
      uStack_1a8 = (byte **)CONCAT44(uStack_1a8._4_4_,uVar12);
      uStack_19a = (undefined2)(lVar16 + 0x2000);
      uStack_198 = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
    }
    else {
      uStack_1b8 = 1;
      bVar3 = *pbStack_1b0;
      uStack_1b6 = uVar10;
      uStack_188 = uStack_1b4;
      switch(bVar3 & 0x1c) {
      default:
        if ((char)pbStack_1b0[1] < '\0') {
          uStack_1b6 = (*(ushort *)(pbStack_1b0 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_1b0 + 1) >> 8;
          uStack_1a0 = 3;
          uStack_a6c = CONCAT22(uStack_a6c._2_2_,3);
        }
        else {
          uStack_1b6 = (ushort)pbStack_1b0[1];
          uStack_1a0 = 2;
        }
        sStack_19c = (short)(uStack_1b6 + 1 >> 1) + (short)uStack_a6c;
        uStack_19e = uVar10;
        if (0x1e < uStack_1b6) {
          iVar11 = uStack_1b6 - 1;
          uStack_19e = ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                       (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
        }
        break;
      case 4:
        if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
          uStack_1a0 = 0;
          uStack_19e = 0;
          sStack_19c = 0;
          uStack_19a = 0;
          uStack_198 = 0;
          uStack_192 = 0;
          uStack_1b4 = 0xf;
          uStack_188 = 1;
        }
        else {
          uStack_1a0 = 0;
          uStack_19e = 0;
          sStack_19c = 0;
          uStack_19a = 0;
          uStack_198 = 0;
          uStack_192 = 0;
          uStack_1b4 = 1;
        }
        break;
      case 8:
        uStack_1a0 = 0;
        uStack_19e = 0;
        sStack_19c = 0;
        uStack_19a = 0;
        uStack_198 = 0;
        uStack_192 = 0;
        uStack_1b4 = 9;
      }
      uStack_190 = (undefined2)(lVar16 + 0x2000);
      uStack_18e = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
      uStack_1a8 = ppbVar33;
    }
    plVar39 = plStack_a80;
    lVar16 = plStack_a80[0x10];
    if (lVar16 == 0) {
      func_0x(plStack_a80[0x19],uVar26,plStack_a80 + 0x10);
      if ((*(byte *)(plVar39[5] + 0x42) & 4) == 0) {
        uVar26 = *(uint *)(plVar39[5] + 0xb4);
        if (0xa58 < uVar26) {
          uVar26 = 0xa58;
        }
      }
      else {
        uVar26 = 0xa58;
      }
      *(uint *)((longlong)plVar39 + 0x94) = uVar26;
      uStack_b18 = (uint *)CONCAT71(uStack_b18._1_7_,5);
      lVar14 = (*pcRam0000000000f22ed8)(uVar26,plVar39[0x19],0x12e1140,0x121b);
      plVar39[0x11] = lVar14;
      lVar16 = plVar39[0x10];
    }
    else {
      lVar14 = plStack_a80[0x11];
    }
    uVar21 = *(undefined4 *)((longlong)plVar39 + 0x94);
    uVar45 = 0;
    uStack_9dc = 0;
    uVar26 = *(uint *)(**(longlong **)(plVar39[5] + 0x160) + 0x1c);
    iVar11 = *(int *)(plVar39[5] + 0x100);
    if ((iVar11 == 0) || (iVar11 - 3U < 2)) {
      uVar47 = 0;
    }
    else {
      uVar47 = 1;
    }
    uStack_aa0 = 0;
    *(undefined8 *)(lVar16 + 0x10) = 0;
    *(undefined4 *)(lVar16 + 8) = 0;
    uVar34 = uVar45;
    plVar38 = plVar39 + 4;
    plVar39 = plVar39 + 4;
    if (uVar26 != 0) {
      do {
        if (uVar45 == 0) {
          uVar22 = *(ulonglong *)(**(longlong **)(plVar38[1] + 0x160) + 0x38);
        }
        else {
          uVar22 = *(ulonglong *)(uVar45 + 0x168);
        }
        if (uVar22 == **(longlong **)(plVar38[1] + 0x160) + 0x30U) {
          uVar22 = 0;
        }
        uVar45 = 0;
        if (uVar22 != 0) {
          uVar45 = uVar22 - 0x160;
        }
        puStack_ae0 = &uStack_9dc;
        uStack_af8 = 0;
        uStack_b00 = uStack_b00 & 0xffffff00;
        uStack_b08 = (int *)CONCAT71(uStack_b08._1_7_,uVar47);
        uStack_b10 = (uint *)((ulonglong)uStack_b10 & 0xffffffff00000000);
        uStack_b18 = (uint *)&uStack_aa0;
        uStack_af0 = uVar21;
        lStack_ae8 = lVar14;
        func_0x(lVar16,uVar34,&uStack_268,uVar45);
        uVar12 = (int)uVar34 + 1;
        uVar34 = (ulonglong)uVar12;
        plVar38 = plStack_910;
        plVar39 = plStack_910;
      } while (uVar12 < uVar26);
    }
    uVar31 = 0;
    uVar45 = uVar31;
    uVar34 = uVar31;
    uVar22 = uVar31;
    if (uStack_a8c != 0) {
      do {
        uVar40 = **(longlong **)(plVar39[1] + 0x160) + 0x30;
        uVar36 = *(ulonglong *)(**(longlong **)(plVar39[1] + 0x160) + 0x38);
        if (uVar36 == uVar40) {
          uVar36 = uVar31;
        }
        uVar25 = uVar31;
        if (uVar36 != 0) {
          uVar25 = uVar36 - 0x160;
        }
        uVar36 = uVar45;
        if ((int)uVar22 != 0) {
          do {
            uVar23 = *(ulonglong *)(uVar25 + 0x168);
            if (*(ulonglong *)(uVar25 + 0x168) == uVar40) {
              uVar23 = uVar31;
            }
            uVar25 = uVar31;
            if (uVar23 != 0) {
              uVar25 = uVar23 - 0x160;
            }
            uVar36 = uVar36 - 1;
          } while (uVar36 != 0);
        }
        uVar47 = 0x83;
        if (-1 < *(char *)(uVar25 + 0x20)) {
          uVar47 = 0x85;
        }
        *(undefined *)(*(longlong *)plStack_a80[0x10] + 0xe + uVar34) = uVar47;
        uVar26 = (int)uVar22 + 1;
        plVar39 = plStack_a80 + 4;
        uVar45 = uVar45 + 1;
        uVar34 = uVar34 + 0x10;
        uVar22 = (ulonglong)uVar26;
      } while (uVar26 < uStack_a8c);
    }
    uStack_b18 = (uint *)((ulonglong)uStack_b18 & 0xffffffff00000000);
    iVar11 = func_0x(&uStack_1b8,plStack_a80[0x10],uStack_a8c,plStack_a80 + 4);
    if (iVar11 == 0) {
      uStack_b18 = (uint *)0x0;
      (*pcRam0000000000f22f00)(1,0x14602a0,0x142a390,0x1240);
    }
    func_0x(&plStack_ab8);
    func_0x(&plStack_ad0);
    goto LAB_;
  }
  uVar10 = *(ushort *)(lVar16 + 0x16);
  iStack_2e4 = uVar10 - 1;
  if (*(char *)(lVar16 + 2) < '\0') {
    pbVar1 = (byte *)(lVar16 + 0x60);
    if ((sStack_318 == 0) || (ppbVar33 = uStack_308, uStack_308 == (byte **)0x0)) {
      uStack_2b8 = 0;
      uStack_2aa = 0;
      auStack_290 = ZEXT816(0);
      auStack_2e0 = ZEXT816(0);
      stack0xfffffffffffffd32 = SUB1614(ZEXT816(0),2);
      auStack_2d0._0_2_ = 0xffff;
      uStack_2c8 = 0;
      uStack_2b2 = 0;
      uStack_2b0 = 0;
      uStack_2a8 = 0;
      uStack_2c0 = 0;
      auStack_2a0 = ZEXT816(0);
      auStack_280._0_12_ = ZEXT812(0);
      auStack_280._12_4_ = 0;
      uStack_270 = 0;
      ppbVar33 = (byte **)auStack_2e0;
    }
    pbVar30 = (byte *)0x0;
    if (*(short *)(lVar16 + 0x24) == 0) {
LAB_:
      uStack_a08 = *(undefined8 *)(lVar16 + 0x28);
      uStack_a00 = *(undefined2 *)(lVar16 + 0x30);
    }
    else {
      cVar9 = *(char *)(lVar16 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(lVar16 + 0x18) != 99) {
LAB_:
          if (cVar9 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar9 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar16 + 0x18) != 99) goto LAB_;
      }
      uStack_990 = *(undefined4 *)(lVar16 + 0x20);
      uStack_98c = *(undefined2 *)(lVar16 + 0x24);
      cVar9 = func_0x(&uStack_990);
      if (cVar9 == '\0') goto LAB_;
      func_0x(lVar16,&uStack_a08);
    }
    *ppbVar33 = pbVar1;
    *(undefined4 *)(ppbVar33 + 0xc) = (undefined4)uStack_a08;
    *(int *)((longlong)ppbVar33 + 100) = (int)((ulonglong)uStack_a08 >> 0x20);
    *(undefined2 *)(ppbVar33 + 0xd) = uStack_a00;
    *(undefined4 *)((longlong)ppbVar33 + 0x6c) = *(undefined4 *)(lVar16 + 0x20);
    *(undefined2 *)(ppbVar33 + 0xe) = *(undefined2 *)(lVar16 + 0x24);
    uVar41 = SUB82(pbVar30,0);
    *(undefined2 *)((longlong)ppbVar33 + 0x72) = uVar41;
    uStack_908 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x109ebd0);
    uVar45 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x109ebd4);
    *(undefined2 *)(ppbVar33 + 2) = 0xffff;
    ppbVar33[3] = pbVar30;
    uVar26 = (uint)pbVar30;
    *(uint *)((longlong)ppbVar33 + 0x14) = uVar26;
    *(byte **)((longlong)ppbVar33 + 0x2e) = pbVar30;
    ppbVar33[7] = pbVar30;
    ppbVar33[4] = pbVar30;
    ppbVar33[9] = pbVar30;
    ppbVar33[10] = pbVar30;
    *(undefined2 *)(ppbVar33 + 0xb) = uVar41;
    if ((**ppbVar33 & 2) != 0) {
      pbVar2 = pbVar1 + uVar45;
      if ((*pbVar2 & 1) == 0) {
        *(undefined2 *)(ppbVar33 + 2) = uVar41;
        ppbVar33[3] = pbVar2;
        *(uint *)((longlong)ppbVar33 + 0x14) = uVar26;
        *(uint *)((longlong)ppbVar33 + 0x36) = uVar26;
        switch(*pbVar2 & 0xe) {
        default:
          uVar26 = (uint)*(ushort *)(pbVar2 + 2);
          if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
            func_0x(pbVar2,6);
            pbVar30 = (byte *)0x0;
          }
          break;
        case 4:
          uVar26 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar26 = 1;
        }
        *(uint *)(ppbVar33 + 4) = uVar26;
        *(byte **)((longlong)ppbVar33 + 0x2e) = pbVar30;
      }
      else {
        *(undefined2 *)(ppbVar33 + 2) = 1;
        ppbVar33[3] = pbVar2;
        bVar3 = *pbVar2;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbVar2[1] < '\0') {
            uVar20 = *(ushort *)(pbVar2 + 1);
            *(ushort *)((longlong)ppbVar33 + 0x12) = uVar20;
            sVar35 = 3;
            uVar20 = (uVar20 & 0x7f) << 8 | uVar20 >> 8;
          }
          else {
            sVar35 = 2;
            uVar20 = (ushort)pbVar2[1];
          }
          *(ushort *)((longlong)ppbVar33 + 0x12) = uVar20;
          *(short *)(ppbVar33 + 5) = sVar35;
          *(short *)((longlong)ppbVar33 + 0x2c) =
               (short)(*(ushort *)((longlong)ppbVar33 + 0x12) + 1 >> 1) + sVar35;
          if (*(ushort *)((longlong)ppbVar33 + 0x12) < 0x1f) {
            *(undefined2 *)((longlong)ppbVar33 + 0x2a) = uVar41;
            *(uint *)((longlong)ppbVar33 + 0x14) = uVar26;
            *(uint *)(ppbVar33 + 8) = uVar26;
            ppbVar33[7] = pbVar30;
            ppbVar33[4] = pbVar30;
          }
          else {
            iVar11 = *(ushort *)((longlong)ppbVar33 + 0x12) - 1;
            *(short *)((longlong)ppbVar33 + 0x2a) =
                 ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                 (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
            *(uint *)((longlong)ppbVar33 + 0x14) = uVar26;
            *(uint *)(ppbVar33 + 8) = uVar26;
            ppbVar33[7] = pbVar30;
            ppbVar33[4] = pbVar30;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) != 4) || (uVar12 = 1, (bVar3 & 2) == 0)) {
            uVar12 = uVar26;
          }
          *(uint *)((longlong)ppbVar33 + 0x14) = uVar26;
          ppbVar33[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar33 + 0x12) = uVar41;
          ppbVar33[6] = (byte *)0x0;
          ppbVar33[4] = pbVar30;
          *(uint *)(ppbVar33 + 8) = uVar26;
          ppbVar33[7] = pbVar30;
          ppbVar33[3] = pbVar2;
          if (uVar12 == 0) {
            *(undefined4 *)((longlong)ppbVar33 + 0x14) = 1;
            *(uint *)(ppbVar33 + 8) = uVar26;
            ppbVar33[7] = pbVar30;
            ppbVar33[4] = pbVar30;
          }
          else {
            *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0xf;
            *(uint *)(ppbVar33 + 8) = uVar26;
            *(undefined4 *)(ppbVar33 + 8) = 1;
            ppbVar33[7] = pbVar30;
            ppbVar33[4] = pbVar30;
          }
          break;
        case 8:
          ppbVar33[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar33 + 0x12) = uVar41;
          ppbVar33[6] = (byte *)0x0;
          ppbVar33[4] = pbVar30;
          ppbVar33[7] = pbVar30;
          ppbVar33[3] = pbVar2;
          *(undefined4 *)((longlong)ppbVar33 + 0x14) = 9;
          *(uint *)(ppbVar33 + 8) = uVar26;
          ppbVar33[7] = pbVar30;
          ppbVar33[4] = pbVar30;
        }
      }
    }
    if ((**ppbVar33 & 4) != 0) {
      if (uStack_908._2_2_ != 0) {
        uVar45 = (ulonglong)*(ushort *)(lVar16 + 0x61 + (longlong)uStack_908._2_2_ * 2);
      }
      psVar18 = (short *)(pbVar1 + uVar45);
      ppbVar33[9] = (byte *)psVar18;
      sVar35 = *psVar18;
      ppbVar33[10] = (byte *)(psVar18 + 1);
      *(short *)(ppbVar33 + 0xb) = (sVar35 + 1) * 2;
    }
    if (ppbVar33[1] != (byte *)0x0) {
      func_0x(ppbVar33[1],ppbVar33);
    }
  }
  else {
    ppbVar33 = (byte **)0x0;
  }
  ppbVar29 = (byte **)(ulonglong)*(ushort *)(lVar16 + 0xe);
  piStack_310 = (int *)((ulonglong)*(ushort *)(lVar16 + (0x1000 - (ulonglong)uVar10) * 2) + lVar16);
  if ((*(byte *)piStack_310 & 1) == 0) {
    sStack_318 = 0;
    uStack_314 = 0;
    uStack_2f2 = 0;
    uStack_2f0 = 0;
    switch(*(byte *)piStack_310 & 0xe) {
    default:
      ppbVar29 = (byte **)(ulonglong)*(ushort *)((longlong)piStack_310 + 2);
      if (0x1f9d < *(ushort *)((longlong)piStack_310 + 2) - 1) {
        func_0x(piStack_310,6);
      }
      break;
    case 4:
      ppbVar29 = (byte **)0x9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      ppbVar29 = (byte **)0x1;
    }
    uStack_308 = (byte **)CONCAT44(uStack_308._4_4_,(int)ppbVar29);
    uStack_2fa = (undefined2)(lVar16 + 0x2000);
    uStack_2f8 = (undefined6)((ulonglong)(lVar16 + 0x2000) >> 0x10);
    ppbVar33 = ppbVar29;
  }
  else {
    sStack_318 = 1;
    bVar3 = *(byte *)piStack_310;
    switch(bVar3 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)piStack_310 + 1) < '\0') {
        uStack_316 = (*(ushort *)((longlong)piStack_310 + 1) & 0x7f) << 8 |
                     *(ushort *)((longlong)piStack_310 + 1) >> 8;
        uStack_300._0_2_ = 3;
        sVar35 = 3;
      }
      else {
        uStack_316 = (ushort)*(byte *)((longlong)piStack_310 + 1);
        uStack_300._0_2_ = 2;
        sVar35 = 2;
      }
      uStack_2fc = (short)(uStack_316 + 1 >> 1) + sVar35;
      if (uStack_316 < 0x1f) {
        uStack_300._2_2_ = 0;
        uStack_314 = 0;
        uStack_2e8 = 0;
      }
      else {
        iVar11 = uStack_316 - 1;
        uStack_300._2_2_ =
             ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
             (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
        uStack_314 = 0;
        uStack_2e8 = 0;
      }
      break;
    case 4:
      if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
        uStack_300._0_2_ = 0;
        uStack_300._2_2_ = 0;
        uStack_2fc = 0;
        uStack_2fa = 0;
        uStack_316 = 0;
        uStack_2f8 = 0;
        uStack_2f2 = 0;
        uStack_314 = 0xf;
        uStack_2e8 = 1;
      }
      else {
        uStack_300._0_2_ = 0;
        uStack_300._2_2_ = 0;
        uStack_2fc = 0;
        uStack_2fa = 0;
        uStack_316 = 0;
        uStack_2f8 = 0;
        uStack_2f2 = 0;
        uStack_314 = 1;
        uStack_2e8 = 0;
      }
      break;
    case 8:
      uStack_300._0_2_ = 0;
      uStack_300._2_2_ = 0;
      uStack_2fc = 0;
      uStack_2fa = 0;
      uStack_316 = 0;
      uStack_2f8 = 0;
      uStack_2f2 = 0;
      uStack_314 = 9;
      uStack_2e8 = 0;
    }
    lVar16 = lVar16 + 0x2000;
    uStack_2f0 = (undefined2)lVar16;
    uStack_2ee = (ushort)((ulonglong)lVar16 >> 0x10);
    uStack_2ec = (ushort)((ulonglong)lVar16 >> 0x20);
    uStack_2ea = (undefined2)((ulonglong)lVar16 >> 0x30);
    ppbVar29 = (byte **)((ulonglong)ppbVar33 & 0xffffffff);
    uStack_308 = ppbVar33;
  }
  lVar16 = lStack_920;
  uVar26 = (uint)ppbVar29;
  puVar17 = (uint *)(lStack_920 + 0x210);
  lVar43 = lVar16;
  if (sStack_318 == 0) {
    uVar12 = *puVar17;
    if ((uVar12 & 0xc0000000) == 0x80000000) {
      iVar11 = func_0x(&uStack_316);
      if (iVar11 == 0) {
        aiStack_ad8[0] = 0;
        piVar27 = (int *)0x0;
        iVar11 = aiStack_ad8[0];
      }
      else {
        piVar27 = (int *)func_0x(&uStack_2ee,puVar17,aiStack_ad8,auStack_8bc);
        iVar11 = aiStack_ad8[0];
      }
    }
    else {
      uVar10 = *(ushort *)(lStack_920 + 0x216);
      if ((uVar10 & 0x10) == 0) {
code_r0x00101fc9:
        if ((int)uVar12 < 0) {
          piVar27 = piStack_310;
          if (uStack_314 == 0) {
            uStack_316 = 0;
            uVar12 = uVar26;
            if ((*(byte *)piStack_310 & 0x10) != 0) {
              uVar12 = uVar26 + 2 +
                       (*(ushort *)((longlong)piStack_310 + (longlong)ppbVar29) + 7 >> 3);
            }
            uStack_308 = (byte **)CONCAT44(uVar12,(uint)uStack_308);
            if ((*(byte *)piStack_310 & 0x20) != 0) {
              puVar46 = (ushort *)((ulonglong)uVar12 + (longlong)piStack_310);
              uStack_2fc = *puVar46;
              if (uStack_2fc == 0) {
                cVar9 = func_0x(0x19b5380);
                if (cVar9 != '\0') {
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    cVar9 = func_0x(0x19b5380);
                    if (cVar9 == '\0') {
                      (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_b18 = (uint *)0x0;
                      (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x80f);
                    }
                  }
                }
                func_0x(piStack_310,3);
              }
              uStack_300 = uStack_308._4_4_ + (uStack_2fc + 1) * 2;
              if (0x1f9e < uStack_300) {
                cVar9 = func_0x(0x19b5380);
                if (cVar9 != '\0') {
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    cVar9 = func_0x(0x19b5380);
                    if (cVar9 == '\0') {
                      (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_b18 = (uint *)0x0;
                      (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x816);
                    }
                  }
                }
                func_0x(piStack_310,4);
              }
              uStack_314 = puVar46[uStack_2fc] & 0x7fff;
              if (uStack_314 < uStack_300) {
                cVar9 = func_0x(0x19b5380);
                if (cVar9 != '\0') {
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    cVar9 = func_0x(0x19b5380);
                    if (cVar9 == '\0') {
                      (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_b18 = (uint *)0x0;
                      (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x81d);
                    }
                  }
                }
                func_0x(piStack_310,4);
              }
              iVar11 = 0;
              piVar27 = piStack_310;
              puVar4 = puVar46;
              uVar12 = uStack_300;
              if (uStack_2fc != 0) {
                do {
                  uVar26 = puVar4[1] & 0x7fff;
                  if ((uVar26 < uStack_300) || (uStack_314 < uVar26)) {
                    uStack_300 = uVar12;
                    cVar9 = func_0x(0x19b5380);
                    if (cVar9 != '\0') {
                      cVar9 = func_0x();
                      if (cVar9 != '\0') {
                        cVar9 = func_0x(0x19b5380);
                        if (cVar9 == '\0') {
                          (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_b18 = (uint *)0x0;
                          (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x82a);
                        }
                      }
                    }
                    func_0x(piStack_310,4);
                    piVar27 = piStack_310;
                    uVar12 = uStack_300;
                  }
                  iVar11 = iVar11 + 1;
                  uStack_300 = uVar26;
                  puVar4 = puVar4 + 1;
                  lVar43 = lStack_920;
                  lVar14 = lStack_918;
                } while (iVar11 < (int)(uint)uStack_2fc);
              }
              do {
                if (-1 < (short)puVar46[(ulonglong)(uStack_2fc - 1) + 1]) {
code_r0x00102453:
                  uVar26 = (uint)uStack_308;
                  goto code_r0x00102617;
                }
                uVar26 = uVar12;
                if (uStack_2fc != 1) {
                  uVar26 = *(ushort *)
                            ((longlong)piVar27 +
                            (ulonglong)uStack_2fc * 2 + (((ulonglong)uStack_308 >> 0x20) - 2)) &
                           0x7fff;
                }
                uVar32 = *(ushort *)
                          ((longlong)piVar27 +
                          (ulonglong)uStack_2fc * 2 + ((ulonglong)uStack_308 >> 0x20)) & 0x7fff;
                if (((uVar26 < uVar12) || (uVar32 < uVar26)) || (uStack_314 < uVar32)) {
                  uStack_300 = uVar12;
                  func_0x(piVar27,7);
                  piVar27 = piStack_310;
                  uVar12 = uStack_300;
                }
                uStack_300 = uVar12;
                if ((uVar26 < uVar12) || (uStack_314 < uVar26)) goto code_r0x001027ac;
                if (*(ushort *)((longlong)piVar27 + (ulonglong)uVar26) == 5) {
                  uStack_316 = uStack_316 | 2;
                  uStack_2fc = uStack_2fc - 1;
                  uVar45 = (ulonglong)(uVar26 & 0xffff);
                  uStack_2ee = (ushort)uVar26;
                  pbVar1 = (byte *)((longlong)piVar27 + uVar45);
                  if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                    uVar10 = uStack_2ec & 0xc7ff;
                  }
                  else {
                    uVar10 = uStack_2ec ^ (*(ushort *)(pbVar1 + 2) ^ uStack_2ec) & 0x3800;
                  }
                  uStack_2ec = (uVar10 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar10;
                  pbVar30 = (byte *)((ulonglong)((uVar10 >> 0xb & 7) * 2) + 4 + uVar45 +
                                     ((ulonglong)uStack_2ec & 0x7ff) * 2 + (longlong)piVar27);
                  if (pbVar30 < pbVar1) {
                    func_0x(pbVar1,0x19);
                    uVar45 = (ulonglong)uStack_2ee;
                    piVar27 = piStack_310;
                  }
                  uVar12 = uStack_300;
                  if (uVar32 - uVar26 <
                      (((uStack_2ec & 0x7ff) * 2 - (int)uVar45) - (int)piStack_310) + (int)pbVar30)
                  {
                    func_0x((byte *)(uVar45 + (longlong)piVar27),0x19);
                    uVar45 = (ulonglong)uStack_2ee;
                    piVar27 = piStack_310;
                    uVar12 = uStack_300;
                  }
                  iVar11 = 0;
                  if (((uStack_2ec & 0x3800) != 0) &&
                     (puVar46 = (ushort *)((longlong)piVar27 + uVar45 + 4), uVar10 = uStack_2ec,
                     (uStack_2ec & 0x3800) != 0)) {
                    do {
                      if ((uVar10 & 0x7ff) < (*puVar46 & 0x7ff)) {
                        uStack_300 = uVar12;
                        func_0x((byte *)(uVar45 + (longlong)piVar27),0x1a);
                        uVar45 = (ulonglong)uStack_2ee;
                        piVar27 = piStack_310;
                        uVar10 = uStack_2ec;
                        uVar12 = uStack_300;
                      }
                      iVar11 = iVar11 + 1;
                      puVar46 = puVar46 + 1;
                    } while (iVar11 < (int)((uStack_2ec & 0x3800) >> 0xb));
                    uVar26 = (uint)uStack_308;
                    goto code_r0x00102617;
                  }
                  goto code_r0x00102453;
                }
                if (*(ushort *)((longlong)piVar27 + (ulonglong)uVar26) < 0x400)
                goto code_r0x00102453;
                uStack_316 = uStack_316 | 1;
                uStack_2fc = uStack_2fc - 1;
                if (uStack_2fc == 0) goto code_r0x00102453;
              } while( true );
            }
            uStack_2fc = 0;
            uStack_314 = uVar12;
code_r0x00102617:
            if ((*(byte *)piVar27 & 0x40) == 0) {
              uStack_2f2 = 0;
              uStack_2f0 = 0;
            }
            else {
              uStack_2f2 = (undefined2)uStack_314;
              uStack_2f0 = (undefined2)(uStack_314 >> 0x10);
              uStack_314 = uStack_314 + 0xe;
              uStack_300 = uVar12;
              uVar19 = func_0x(&uStack_316);
              func_0x(uVar19,auStack_8a8);
              iVar11 = func_0x(auStack_8a8);
              uStack_314 = uStack_314 + iVar11;
              piVar27 = piStack_310;
              uVar26 = (uint)uStack_308;
              uVar12 = uStack_300;
            }
            uStack_300 = uVar12;
            if (((byte *)CONCAT62(uStack_2f8,uStack_2fa) != (byte *)0x0) &&
               ((byte *)CONCAT62(uStack_2f8,uStack_2fa) <
                (byte *)((ulonglong)uStack_314 + (longlong)piVar27))) {
              cVar9 = func_0x(0x19b5380);
              if (cVar9 != '\0') {
                cVar9 = func_0x();
                if (cVar9 != '\0') {
                  cVar9 = func_0x(0x19b5380);
                  if (cVar9 == '\0') {
                    (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_b18 = (uint *)0x0;
                    (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x886);
                  }
                }
              }
              func_0x(piStack_310,0x12);
              piVar27 = piStack_310;
              uVar26 = (uint)uStack_308;
            }
            if (uStack_314 - 1 < 0x3f3c) goto code_r0x001027b2;
            cVar9 = func_0x(0x19b5380);
            if (cVar9 != '\0') {
              cVar9 = func_0x();
              if (cVar9 != '\0') {
                cVar9 = func_0x(0x19b5380);
                if (cVar9 == '\0') {
                  (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  uStack_b18 = (uint *)0x0;
                  (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x88b);
                }
              }
            }
            func_0x(piStack_310,5);
            piVar27 = piStack_310;
code_r0x001027ac:
            uVar26 = (uint)uStack_308;
          }
code_r0x001027b2:
          sVar35 = -*(short *)puVar17;
          if ((*(byte *)(lVar16 + 0x216) & 0x10) != 0) {
            if ((*(byte *)piVar27 & 0x10) == 0) {
              if ((1 << (*(byte *)piVar27 & 0xe) & 0x1105U) != 0) {
code_r0x00102819:
                piVar27 = *(int **)(lVar16 + 0x218) + 1;
                iVar11 = **(int **)(lVar16 + 0x218);
                goto code_r0x00102981;
              }
            }
            else if (((int)uVar26 <= (int)*puVar17) ||
                    (*(ushort *)((ulonglong)uVar26 + (longlong)piVar27) <
                     *(ushort *)(lVar16 + 0x214))) goto code_r0x00102819;
          }
          if ((uint)uStack_2fc < (uint)(int)sVar35) {
            iVar11 = 0;
          }
          else {
            piVar37 = piVar27;
            uVar26 = uStack_300;
            if (sVar35 != 1) {
              piVar37 = piStack_310;
              uVar26 = *(ushort *)
                        ((longlong)piVar27 +
                        (longlong)sVar35 * 2 + (((ulonglong)uStack_308 >> 0x20) - 2)) & 0x7fff;
            }
            uVar12 = *(ushort *)
                      ((longlong)piVar27 + (longlong)sVar35 * 2 + ((ulonglong)uStack_308 >> 0x20)) &
                     0x7fff;
            if (((uVar26 < uStack_300) || (uVar12 < uVar26)) || (uStack_314 < uVar12)) {
              func_0x(piVar37,7);
              piVar37 = piStack_310;
            }
            piVar27 = (int *)((ulonglong)uVar26 + (longlong)piVar37);
            iVar11 = uVar12 - uVar26;
          }
        }
        else if ((uVar10 & 8) == 0) {
          if ((uVar10 & 0x10) != 0) {
            if ((*(byte *)piStack_310 & 0x10) == 0) {
              if ((1 << (*(byte *)piStack_310 & 0xe) & 0x1105U) != 0) goto code_r0x00102025;
            }
            else if (((int)uVar26 <= (int)uVar12) ||
                    (*(ushort *)((longlong)ppbVar29 + (longlong)piStack_310) <
                     *(ushort *)(lStack_920 + 0x214))) {
code_r0x00102025:
              piVar27 = *(int **)(lStack_920 + 0x218) + 1;
              iVar11 = **(int **)(lStack_920 + 0x218);
              if (iVar11 != 6) {
                uStack_b18 = (uint *)0x0;
                (*pcRam0000000000f22f00)(1,0x14531d0,0x1451b38,0x381);
              }
              goto code_r0x00102981;
            }
          }
          aiStack_ad8[0] = 6;
          piVar27 = (int *)((longlong)(int)*puVar17 + (longlong)piStack_310);
          iVar11 = aiStack_ad8[0];
        }
        else {
          aiStack_ad8[0] = 1;
          piVar27 = (int *)0x1029a20;
          iVar11 = aiStack_ad8[0];
          if ((*(byte *)((longlong)piStack_310 + (longlong)(int)uVar12) &
              (byte)(1 << ((byte)uVar10 & 7))) == 0) {
            piVar27 = (int *)0x1029a21;
          }
        }
      }
      else if ((*(byte *)piStack_310 & 0x10) == 0) {
        if ((1 << (*(byte *)piStack_310 & 0xe) & 0x1105U) == 0) goto code_r0x00101fc9;
        piVar27 = *(int **)(lStack_920 + 0x218) + 1;
        iVar11 = **(int **)(lStack_920 + 0x218);
      }
      else {
        if (((int)uVar12 < (int)ppbVar33) &&
           (*(ushort *)(lStack_920 + 0x214) <=
            *(ushort *)((longlong)ppbVar29 + (longlong)piStack_310))) goto code_r0x00101fc9;
        piVar27 = *(int **)(lStack_920 + 0x218) + 1;
        iVar11 = **(int **)(lStack_920 + 0x218);
      }
    }
  }
  else {
    uStack_a70 = 0;
    uStack_b18 = &uStack_a70;
    piVar27 = (int *)func_0x(&uStack_316,puVar17);
    iVar11 = aiStack_ad8[0];
    if ((((sStack_318 != 0) && (uStack_308 != (byte **)0x0)) && (*uStack_308 != (byte *)0x0)) &&
       (((*(byte *)(lVar16 + 0x216) & 8) == 0 && ((uStack_a70 & 1) == 0)))) {
      if ((piVar27 == (int *)0x0) || (piVar27 == (int *)0x1029a20)) {
        aiStack_ad8[0] = 0;
        piVar27 = (int *)0x0;
        iVar11 = aiStack_ad8[0];
      }
      else {
        uStack_b00 = uStack_a70;
        uStack_b08 = aiStack_ad8;
        uStack_b10 = (uint *)CONCAT44(uStack_b10._4_4_,6);
        uStack_b18 = auStack_108;
        piVar27 = (int *)func_0x(uStack_308,puVar17,piVar27,aiStack_ad8[0]);
        iVar11 = aiStack_ad8[0];
      }
    }
  }
code_r0x00102981:
  aiStack_ad8[0] = iVar11;
  ppbVar33 = (byte **)0x0;
  iStack_a94 = *piVar27;
  sStack_a90 = *(short *)(piVar27 + 1);
  iStack_2e4 = 0;
  if (*(char *)(lVar14 + 2) < '\0') {
    pbVar1 = (byte *)(lVar14 + 0x60);
    if ((sStack_318 == 0) || (ppbVar33 = uStack_308, uStack_308 == (byte **)0x0)) {
      uStack_2b8 = 0;
      uStack_2aa = 0;
      auStack_290 = ZEXT816(0);
      auStack_2e0 = ZEXT816(0);
      stack0xfffffffffffffd32 = SUB1614(ZEXT816(0),2);
      auStack_2d0._0_2_ = 0xffff;
      uStack_2c8 = 0;
      uStack_2b2 = 0;
      uStack_2b0 = 0;
      uStack_2a8 = 0;
      uStack_2c0 = 0;
      auStack_2a0 = ZEXT816(0);
      auStack_280._0_12_ = ZEXT812(0);
      auStack_280._12_4_ = 0;
      uStack_270 = 0;
      ppbVar33 = (byte **)auStack_2e0;
    }
    uVar41 = 0xffff;
    if (*(short *)(lVar14 + 0x24) == 0) {
code_r0x00102ac6:
      uStack_a18 = *(undefined8 *)(lVar14 + 0x28);
      uStack_a10 = *(undefined2 *)(lVar14 + 0x30);
    }
    else {
      cVar9 = *(char *)(lVar14 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(lVar14 + 0x18) != 99) {
code_r0x00102a84:
          if (cVar9 != '\t') goto code_r0x00102ac6;
          goto code_r0x00102a88;
        }
      }
      else {
        if (cVar9 != '\b') goto code_r0x00102a84;
code_r0x00102a88:
        if (*(int *)(lVar14 + 0x18) != 99) goto code_r0x00102ac6;
      }
      uStack_988 = *(undefined4 *)(lVar14 + 0x20);
      uStack_984 = *(undefined2 *)(lVar14 + 0x24);
      uVar41 = 0xffff;
      cVar9 = func_0x(&uStack_988);
      if (cVar9 == '\0') goto code_r0x00102ac6;
      func_0x(lVar14,&uStack_a18);
    }
    *ppbVar33 = pbVar1;
    *(undefined4 *)(ppbVar33 + 0xc) = (undefined4)uStack_a18;
    *(int *)((longlong)ppbVar33 + 100) = (int)((ulonglong)uStack_a18 >> 0x20);
    *(undefined2 *)(ppbVar33 + 0xd) = uStack_a10;
    *(undefined4 *)((longlong)ppbVar33 + 0x6c) = *(undefined4 *)(lVar14 + 0x20);
    *(undefined2 *)(ppbVar33 + 0xe) = *(undefined2 *)(lVar14 + 0x24);
    *(undefined2 *)((longlong)ppbVar33 + 0x72) = 0;
    uStack_a88 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x109ebd0);
    uVar45 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x109ebd4);
    *(undefined2 *)(ppbVar33 + 2) = uVar41;
    ppbVar33[3] = (byte *)0x0;
    *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar33 + 0x2e) = 0;
    ppbVar33[7] = (byte *)0x0;
    ppbVar33[4] = (byte *)0x0;
    ppbVar33[9] = (byte *)0x0;
    ppbVar33[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar33 + 0xb) = 0;
    if ((**ppbVar33 & 2) != 0) {
      pbVar30 = pbVar1 + uVar45;
      uVar26 = 0;
      if ((*pbVar30 & 1) == 0) {
        *(undefined2 *)(ppbVar33 + 2) = 0;
        ppbVar33[3] = pbVar30;
        *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar33 + 0x36) = 0;
        switch(*pbVar30 & 0xe) {
        default:
          uVar26 = (uint)*(ushort *)(pbVar30 + 2);
          if (0x1f9d < *(ushort *)(pbVar30 + 2) - 1) {
            func_0x(pbVar30,6);
          }
          break;
        case 4:
          uVar26 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar26 = 1;
        }
        *(uint *)(ppbVar33 + 4) = uVar26;
        *(undefined8 *)((longlong)ppbVar33 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar33 + 2) = 1;
        ppbVar33[3] = pbVar30;
        bVar3 = *pbVar30;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbVar30[1] < '\0') {
            uVar10 = *(ushort *)(pbVar30 + 1);
            *(ushort *)((longlong)ppbVar33 + 0x12) = uVar10;
            sVar35 = 3;
            uVar10 = (uVar10 & 0x7f) << 8 | uVar10 >> 8;
          }
          else {
            sVar35 = 2;
            uVar10 = (ushort)pbVar30[1];
          }
          *(ushort *)((longlong)ppbVar33 + 0x12) = uVar10;
          *(short *)(ppbVar33 + 5) = sVar35;
          *(short *)((longlong)ppbVar33 + 0x2c) =
               (short)(*(ushort *)((longlong)ppbVar33 + 0x12) + 1 >> 1) + sVar35;
          if (*(ushort *)((longlong)ppbVar33 + 0x12) < 0x1f) {
            *(undefined2 *)((longlong)ppbVar33 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
            *(undefined4 *)(ppbVar33 + 8) = 0;
            ppbVar33[7] = (byte *)0x0;
            ppbVar33[4] = (byte *)0x0;
          }
          else {
            iVar11 = *(ushort *)((longlong)ppbVar33 + 0x12) - 1;
            *(short *)((longlong)ppbVar33 + 0x2a) =
                 ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
                 (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
            *(undefined4 *)(ppbVar33 + 8) = 0;
            ppbVar33[7] = (byte *)0x0;
            ppbVar33[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) != 4) || (bVar5 = true, (bVar3 & 2) == 0)) {
            bVar5 = false;
          }
          *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0;
          ppbVar33[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar33 + 0x12) = 0;
          ppbVar33[6] = (byte *)0x0;
          ppbVar33[4] = (byte *)0x0;
          *(undefined4 *)(ppbVar33 + 8) = 0;
          ppbVar33[7] = (byte *)0x0;
          ppbVar33[3] = pbVar30;
          if (bVar5) {
            *(undefined4 *)((longlong)ppbVar33 + 0x14) = 0xf;
            *(undefined4 *)(ppbVar33 + 8) = 0;
            *(undefined4 *)(ppbVar33 + 8) = 1;
            ppbVar33[7] = (byte *)0x0;
            ppbVar33[4] = (byte *)0x0;
          }
          else {
            *(undefined4 *)((longlong)ppbVar33 + 0x14) = 1;
            *(undefined4 *)(ppbVar33 + 8) = 0;
            ppbVar33[7] = (byte *)0x0;
            ppbVar33[4] = (byte *)0x0;
          }
          break;
        case 8:
          ppbVar33[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar33 + 0x12) = 0;
          ppbVar33[6] = (byte *)0x0;
          ppbVar33[4] = (byte *)0x0;
          ppbVar33[7] = (byte *)0x0;
          ppbVar33[3] = pbVar30;
          *(undefined4 *)((longlong)ppbVar33 + 0x14) = 9;
          *(undefined4 *)(ppbVar33 + 8) = 0;
          ppbVar33[7] = (byte *)0x0;
          ppbVar33[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar33 & 4) != 0) {
      if (uStack_a88._2_2_ != 0) {
        uVar45 = (ulonglong)*(ushort *)(lVar14 + 0x61 + (longlong)uStack_a88._2_2_ * 2);
      }
      psVar18 = (short *)(pbVar1 + uVar45);
      ppbVar33[9] = (byte *)psVar18;
      sVar35 = *psVar18;
      ppbVar33[10] = (byte *)(psVar18 + 1);
      *(short *)(ppbVar33 + 0xb) = (sVar35 + 1) * 2;
    }
    if (ppbVar33[1] != (byte *)0x0) {
      func_0x(ppbVar33[1],ppbVar33);
    }
  }
  piStack_310 = (int *)((ulonglong)*(ushort *)(lVar14 + 0x1ffe) + lVar14);
  if ((*(byte *)piStack_310 & 1) == 0) {
    sStack_318 = 0;
    uStack_314 = 0;
    uStack_2f2 = 0;
    uStack_2f0 = 0;
    ppbVar33 = (byte **)(ulonglong)*(ushort *)(lVar14 + 0xe);
    switch(*(byte *)piStack_310 & 0xe) {
    default:
      ppbVar33 = (byte **)(ulonglong)*(ushort *)((longlong)piStack_310 + 2);
      if (0x1f9d < *(ushort *)((longlong)piStack_310 + 2) - 1) {
        func_0x(piStack_310,6);
      }
      break;
    case 4:
      ppbVar33 = (byte **)0x9;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      ppbVar33 = (byte **)0x1;
    }
    uStack_308 = (byte **)CONCAT44(uStack_308._4_4_,(int)ppbVar33);
    uStack_2fa = (undefined2)(lVar14 + 0x2000);
    uStack_2f8 = (undefined6)((ulonglong)(lVar14 + 0x2000) >> 0x10);
    ppbVar29 = ppbVar33;
  }
  else {
    sStack_318 = 1;
    bVar3 = *(byte *)piStack_310;
    switch(bVar3 & 0x1c) {
    default:
      if ((char)*(byte *)((longlong)piStack_310 + 1) < '\0') {
        uStack_316 = (*(ushort *)((longlong)piStack_310 + 1) & 0x7f) << 8 |
                     *(ushort *)((longlong)piStack_310 + 1) >> 8;
        uStack_300._0_2_ = 3;
        sVar35 = 3;
      }
      else {
        uStack_316 = (ushort)*(byte *)((longlong)piStack_310 + 1);
        uStack_300._0_2_ = 2;
        sVar35 = 2;
      }
      uStack_2fc = (short)(uStack_316 + 1 >> 1) + sVar35;
      if (uStack_316 < 0x1f) {
        uStack_300._2_2_ = 0;
        uStack_314 = 0;
        uStack_2e8 = 0;
      }
      else {
        iVar11 = uStack_316 - 1;
        uStack_300._2_2_ =
             ((short)(iVar11 / 0x1e) + (short)(iVar11 >> 0x1f)) -
             (short)((longlong)iVar11 * 0x88888889 >> 0x3f);
        uStack_314 = 0;
        uStack_2e8 = 0;
      }
      break;
    case 4:
      if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
        uStack_300._0_2_ = 0;
        uStack_300._2_2_ = 0;
        uStack_2fc = 0;
        uStack_2fa = 0;
        uStack_316 = 0;
        uStack_2f8 = 0;
        uStack_2f2 = 0;
        uStack_314 = 0xf;
        uStack_2e8 = 1;
      }
      else {
        uStack_300._0_2_ = 0;
        uStack_300._2_2_ = 0;
        uStack_2fc = 0;
        uStack_2fa = 0;
        uStack_316 = 0;
        uStack_2f8 = 0;
        uStack_2f2 = 0;
        uStack_314 = 1;
        uStack_2e8 = 0;
      }
      break;
    case 8:
      uStack_300._0_2_ = 0;
      uStack_300._2_2_ = 0;
      uStack_2fc = 0;
      uStack_2fa = 0;
      uStack_316 = 0;
      uStack_2f8 = 0;
      uStack_2f2 = 0;
      uStack_314 = 9;
      uStack_2e8 = 0;
    }
    lVar14 = lVar14 + 0x2000;
    uStack_2f0 = (undefined2)lVar14;
    uStack_2ee = (ushort)((ulonglong)lVar14 >> 0x10);
    uStack_2ec = (ushort)((ulonglong)lVar14 >> 0x20);
    uStack_2ea = (undefined2)((ulonglong)lVar14 >> 0x30);
    ppbVar29 = (byte **)((ulonglong)ppbVar33 & 0xffffffff);
    uStack_308 = ppbVar33;
  }
  uVar26 = (uint)ppbVar29;
  puVar17 = (uint *)(lVar43 + 0x210);
  if (sStack_318 == 0) {
    uVar12 = *puVar17;
    if ((uVar12 & 0xc0000000) == 0x80000000) {
      iVar11 = func_0x(&uStack_316);
      if (iVar11 == 0) {
code_r0x00103a95:
        piVar27 = (int *)0x0;
        aiStack_ad8[0] = 0;
        iVar11 = aiStack_ad8[0];
      }
      else {
        piVar27 = (int *)func_0x(&uStack_2ee,puVar17,aiStack_ad8,auStack_8c0);
        iVar11 = aiStack_ad8[0];
      }
    }
    else {
      uVar10 = *(ushort *)(lVar43 + 0x216);
      if ((uVar10 & 0x10) == 0) {
code_r0x0010312b:
        if ((int)uVar12 < 0) {
          piVar27 = piStack_310;
          if (uStack_314 == 0) {
            uStack_316 = 0;
            uVar12 = uVar26;
            if ((*(byte *)piStack_310 & 0x10) != 0) {
              uVar12 = uVar26 + 2 +
                       (*(ushort *)((longlong)piStack_310 + (longlong)ppbVar29) + 7 >> 3);
            }
            uStack_308 = (byte **)CONCAT44(uVar12,(uint)uStack_308);
            if ((*(byte *)piStack_310 & 0x20) == 0) {
              uStack_2fc = 0;
              uStack_314 = uVar12;
            }
            else {
              puVar46 = (ushort *)((ulonglong)uVar12 + (longlong)piStack_310);
              uStack_2fc = *puVar46;
              if (uStack_2fc == 0) {
                cVar9 = func_0x(0x19b5380);
                if (cVar9 != '\0') {
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    cVar9 = func_0x(0x19b5380);
                    if (cVar9 == '\0') {
                      (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_b18 = (uint *)0x0;
                      (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x80f);
                    }
                  }
                }
                func_0x(piStack_310,3);
              }
              uStack_300 = uStack_308._4_4_ + (uStack_2fc + 1) * 2;
              if (0x1f9e < uStack_300) {
                cVar9 = func_0x(0x19b5380);
                if (cVar9 != '\0') {
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    cVar9 = func_0x(0x19b5380);
                    if (cVar9 == '\0') {
                      (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_b18 = (uint *)0x0;
                      (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x816);
                    }
                  }
                }
                func_0x(piStack_310,4);
              }
              uStack_314 = puVar46[uStack_2fc] & 0x7fff;
              if (uStack_314 < uStack_300) {
                cVar9 = func_0x(0x19b5380);
                if (cVar9 != '\0') {
                  cVar9 = func_0x();
                  if (cVar9 != '\0') {
                    cVar9 = func_0x(0x19b5380);
                    if (cVar9 == '\0') {
                      (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_b18 = (uint *)0x0;
                      (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x81d);
                    }
                  }
                }
                func_0x(piStack_310,4);
              }
              iVar11 = 0;
              piVar27 = piStack_310;
              puVar4 = puVar46;
              uVar12 = uStack_300;
              if (uStack_2fc != 0) {
                do {
                  uVar26 = puVar4[1] & 0x7fff;
                  if ((uVar26 < uStack_300) || (uStack_314 < uVar26)) {
                    uStack_300 = uVar12;
                    cVar9 = func_0x(0x19b5380);
                    if (cVar9 != '\0') {
                      cVar9 = func_0x();
                      if (cVar9 != '\0') {
                        cVar9 = func_0x(0x19b5380);
                        if (cVar9 == '\0') {
                          (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_b18 = (uint *)0x0;
                          (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x82a);
                        }
                      }
                    }
                    func_0x(piStack_310,4);
                    piVar27 = piStack_310;
                    uVar12 = uStack_300;
                  }
                  iVar11 = iVar11 + 1;
                  uStack_300 = uVar26;
                  puVar4 = puVar4 + 1;
                } while (iVar11 < (int)(uint)uStack_2fc);
              }
              while ((short)puVar46[(ulonglong)(uStack_2fc - 1) + 1] < 0) {
                uVar26 = uVar12;
                if (uStack_2fc != 1) {
                  uVar26 = *(ushort *)
                            ((longlong)piVar27 +
                            (ulonglong)uStack_2fc * 2 + (((ulonglong)uStack_308 >> 0x20) - 2)) &
                           0x7fff;
                }
                uVar32 = *(ushort *)
                          ((longlong)piVar27 +
                          (ulonglong)uStack_2fc * 2 + ((ulonglong)uStack_308 >> 0x20)) & 0x7fff;
                if (((uVar26 < uVar12) || (uVar32 < uVar26)) || (uStack_314 < uVar32)) {
                  uStack_300 = uVar12;
                  func_0x(piVar27,7);
                  piVar27 = piStack_310;
                  uVar12 = uStack_300;
                }
                uStack_300 = uVar12;
                if ((uVar26 < uVar12) || (uStack_314 < uVar26)) {
                  uVar26 = (uint)uStack_308;
                  goto code_r0x001038e9;
                }
                if (*(ushort *)((longlong)piVar27 + (ulonglong)uVar26) == 5) {
                  uStack_316 = uStack_316 | 2;
                  uStack_2fc = uStack_2fc - 1;
                  uVar45 = (ulonglong)(uVar26 & 0xffff);
                  uStack_2ee = (ushort)uVar26;
                  pbVar1 = (byte *)((longlong)piVar27 + uVar45);
                  if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                    uVar10 = uStack_2ec & 0xc7ff;
                  }
                  else {
                    uVar10 = uStack_2ec ^ (*(ushort *)(pbVar1 + 2) ^ uStack_2ec) & 0x3800;
                  }
                  uStack_2ec = (uVar10 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar10;
                  pbVar30 = (byte *)((ulonglong)((uVar10 >> 0xb & 7) * 2) + 4 + uVar45 +
                                     ((ulonglong)uStack_2ec & 0x7ff) * 2 + (longlong)piVar27);
                  if (pbVar30 < pbVar1) {
                    func_0x(pbVar1,0x19);
                    uVar45 = (ulonglong)uStack_2ee;
                    piVar27 = piStack_310;
                  }
                  uVar12 = uStack_300;
                  if (uVar32 - uVar26 <
                      (((uStack_2ec & 0x7ff) * 2 - (int)uVar45) - (int)piStack_310) + (int)pbVar30)
                  {
                    func_0x((byte *)(uVar45 + (longlong)piVar27),0x19);
                    uVar45 = (ulonglong)uStack_2ee;
                    piVar27 = piStack_310;
                    uVar12 = uStack_300;
                  }
                  iVar11 = 0;
                  if (((uStack_2ec & 0x3800) != 0) &&
                     (puVar46 = (ushort *)((longlong)piVar27 + uVar45 + 4), uVar10 = uStack_2ec,
                     (uStack_2ec & 0x3800) != 0)) {
                    do {
                      if ((uVar10 & 0x7ff) < (*puVar46 & 0x7ff)) {
                        uStack_300 = uVar12;
                        func_0x((byte *)(uVar45 + (longlong)piVar27),0x1a);
                        uVar45 = (ulonglong)uStack_2ee;
                        piVar27 = piStack_310;
                        uVar10 = uStack_2ec;
                        uVar12 = uStack_300;
                      }
                      iVar11 = iVar11 + 1;
                      puVar46 = puVar46 + 1;
                    } while (iVar11 < (int)((uStack_2ec & 0x3800) >> 0xb));
                    uVar26 = (uint)uStack_308;
                    goto code_r0x0010374f;
                  }
                  break;
                }
                if (*(ushort *)((longlong)piVar27 + (ulonglong)uVar26) < 0x400) break;
                uStack_316 = uStack_316 | 1;
                uStack_2fc = uStack_2fc - 1;
                if (uStack_2fc == 0) break;
              }
              uVar26 = (uint)uStack_308;
            }
code_r0x0010374f:
            if ((*(byte *)piVar27 & 0x40) == 0) {
              uStack_2f2 = 0;
              uStack_2f0 = 0;
            }
            else {
              uStack_2f2 = (undefined2)uStack_314;
              uStack_2f0 = (undefined2)(uStack_314 >> 0x10);
              uStack_314 = uStack_314 + 0xe;
              uStack_300 = uVar12;
              uVar19 = func_0x(&uStack_316);
              func_0x(uVar19,auStack_8a0);
              iVar11 = func_0x(auStack_8a0);
              uStack_314 = uStack_314 + iVar11;
              piVar27 = piStack_310;
              uVar26 = (uint)uStack_308;
              uVar12 = uStack_300;
            }
            uStack_300 = uVar12;
            if (((byte *)CONCAT62(uStack_2f8,uStack_2fa) != (byte *)0x0) &&
               ((byte *)CONCAT62(uStack_2f8,uStack_2fa) <
                (byte *)((ulonglong)uStack_314 + (longlong)piVar27))) {
              cVar9 = func_0x(0x19b5380);
              if (cVar9 != '\0') {
                cVar9 = func_0x();
                if (cVar9 != '\0') {
                  cVar9 = func_0x(0x19b5380);
                  if (cVar9 == '\0') {
                    (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_b18 = (uint *)0x0;
                    (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x886);
                  }
                }
              }
              func_0x(piStack_310,0x12);
              piVar27 = piStack_310;
              uVar26 = (uint)uStack_308;
            }
            if (0x3f3b < uStack_314 - 1) {
              cVar9 = func_0x(0x19b5380);
              if (cVar9 != '\0') {
                cVar9 = func_0x();
                if (cVar9 != '\0') {
                  cVar9 = func_0x(0x19b5380);
                  if (cVar9 == '\0') {
                    (*pcRam0000000000f22f08)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_b18 = (uint *)0x0;
                    (*pcRam0000000000f22f00)(1,0x12a4d8c,0x13c4e78,0x88b);
                  }
                }
              }
              func_0x(piStack_310,5);
              piVar27 = piStack_310;
              uVar26 = (uint)uStack_308;
            }
          }
code_r0x001038e9:
          sVar35 = -*(short *)puVar17;
          if ((*(byte *)(lVar43 + 0x216) & 0x10) != 0) {
            if ((*(byte *)piVar27 & 0x10) == 0) {
              if ((1 << (*(byte *)piVar27 & 0xe) & 0x1105U) != 0) {
code_r0x0010394e:
                piVar27 = *(int **)(lVar43 + 0x218) + 1;
                iVar11 = **(int **)(lVar43 + 0x218);
                goto code_r0x00103a9d;
              }
            }
            else if (((int)uVar26 <= (int)*puVar17) ||
                    (*(ushort *)((ulonglong)uVar26 + (longlong)piVar27) <
                     *(ushort *)(lVar43 + 0x214))) goto code_r0x0010394e;
          }
          iVar11 = 0;
          if ((uint)(int)sVar35 <= (uint)uStack_2fc) {
            piVar37 = piVar27;
            uVar26 = uStack_300;
            if (sVar35 != 1) {
              piVar37 = piStack_310;
              uVar26 = *(ushort *)
                        ((longlong)piVar27 +
                        (longlong)sVar35 * 2 + (((ulonglong)uStack_308 >> 0x20) - 2)) & 0x7fff;
            }
            uVar12 = *(ushort *)
                      ((longlong)piVar27 + (longlong)sVar35 * 2 + ((ulonglong)uStack_308 >> 0x20)) &
                     0x7fff;
            if (((uVar26 < uStack_300) || (uVar12 < uVar26)) || (uStack_314 < uVar12)) {
              func_0x(piVar37,7);
              piVar37 = piStack_310;
            }
            piVar27 = (int *)((ulonglong)uVar26 + (longlong)piVar37);
            iVar11 = uVar12 - uVar26;
          }
        }
        else if ((uVar10 & 8) == 0) {
          if ((uVar10 & 0x10) == 0) {
code_r0x0010315e:
            aiStack_ad8[0] = 6;
            piVar27 = (int *)((longlong)(int)*puVar17 + (longlong)piStack_310);
            iVar11 = aiStack_ad8[0];
          }
          else {
            if ((*(byte *)piStack_310 & 0x10) == 0) {
              if ((1 << (*(byte *)piStack_310 & 0xe) & 0x1105U) == 0) goto code_r0x0010315e;
            }
            else if (((int)uVar12 < (int)uVar26) &&
                    (*(ushort *)(lVar43 + 0x214) <=
                     *(ushort *)((longlong)ppbVar29 + (longlong)piStack_310)))
            goto code_r0x0010315e;
            piVar27 = *(int **)(lVar43 + 0x218) + 1;
            iVar11 = **(int **)(lVar43 + 0x218);
            if (iVar11 != 6) {
              uStack_b18 = (uint *)0x0;
              (*pcRam0000000000f22f00)(1,0x14531d0,0x1451b38,0x381);
            }
          }
        }
        else {
          aiStack_ad8[0] = 1;
          piVar27 = (int *)0x1029a20;
          iVar11 = aiStack_ad8[0];
          if ((*(byte *)((longlong)piStack_310 + (longlong)(int)uVar12) &
              (byte)(1 << ((byte)uVar10 & 7))) == 0) {
            piVar27 = (int *)0x1029a21;
          }
        }
      }
      else if ((*(byte *)piStack_310 & 0x10) == 0) {
        if ((1 << (*(byte *)piStack_310 & 0xe) & 0x1105U) == 0) goto code_r0x0010312b;
        piVar27 = *(int **)(lVar43 + 0x218) + 1;
        iVar11 = **(int **)(lVar43 + 0x218);
      }
      else {
        if (((int)uVar12 < (int)ppbVar33) &&
           (*(ushort *)(lVar43 + 0x214) <= *(ushort *)((longlong)ppbVar29 + (longlong)piStack_310)))
        goto code_r0x0010312b;
        piVar27 = *(int **)(lVar43 + 0x218) + 1;
        iVar11 = **(int **)(lVar43 + 0x218);
      }
    }
  }
  else {
    uStack_a8c = 0;
    uStack_b18 = &uStack_a8c;
    piVar27 = (int *)func_0x(&uStack_316,puVar17);
    iVar11 = aiStack_ad8[0];
    if ((((sStack_318 != 0) && (uStack_308 != (byte **)0x0)) && (*uStack_308 != (byte *)0x0)) &&
       (((*(byte *)(lVar43 + 0x216) & 8) == 0 && ((uStack_a8c & 1) == 0)))) {
      if ((piVar27 == (int *)0x0) || (piVar27 == (int *)0x1029a20)) goto code_r0x00103a95;
      uStack_b00 = uStack_a8c;
      uStack_b08 = aiStack_ad8;
      uStack_b10 = (uint *)CONCAT44(uStack_b10._4_4_,6);
      uStack_b18 = auStack_108;
      piVar27 = (int *)func_0x(uStack_308,puVar17,piVar27,aiStack_ad8[0]);
      iVar11 = aiStack_ad8[0];
    }
  }
code_r0x00103a9d:
  aiStack_ad8[0] = iVar11;
  iStack_a9c = *piVar27;
  sStack_a98 = *(short *)(piVar27 + 1);
  goto code_r0x0010011f;
}

