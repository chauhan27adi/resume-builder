
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,longlong *param_3,ulonglong param_4,int *param_5)

{
  ushort *puVar1;
  longlong lVar2;
  uint6 uVar3;
  ushort *puVar4;
  byte bVar5;
  char cVar6;
  ushort uVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  undefined4 *puVar12;
  longlong lVar13;
  undefined8 uVar14;
  ushort uVar15;
  ushort uVar16;
  uint uVar17;
  ulonglong uVar18;
  undefined4 uVar19;
  int *piVar20;
  uint uVar21;
  ulonglong uVar22;
  byte *pbVar23;
  ulonglong uVar24;
  ulonglong uVar25;
  ushort *puVar26;
  int iStackX_18;
  longlong lStack_78;
  undefined auStack_70 [8];
  int *piStack_68;
  longlong lStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  
  param_4 = param_4 & 0xffffffff;
  puVar1 = (ushort *)(param_2 + 1);
  uStack_58 = 0;
  uStack_54 = (uint)(uStack_54._2_2_ & 0xffe0) << 0x10;
  uStack_50 = 0;
  if (*param_2 == 0) {
    uVar8 = func_0x(puVar1);
  }
  else {
    uVar8 = (uint)*puVar1;
  }
  iVar9 = func_0x(param_2);
  uVar3 = *(uint6 *)(*(longlong *)(param_1 + 0x18) + 0x14);
  uVar19 = *(undefined4 *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 0x20) + 0x664);
  iVar10 = func_0x(param_2);
  if (*param_2 == 0) {
    uVar11 = func_0x(puVar1);
  }
  else {
    uVar11 = (uint)*puVar1;
  }
  iVar10 = (uVar11 + iVar10) * 10 + 0x10;
  func_0x(param_3,0,param_4);
  if (param_3 == (longlong *)0x0) {
    puVar12 = (undefined4 *)(*_DAT_)();
    *puVar12 = 0x16;
    (*_DAT_)();
    param_3 = (longlong *)0x8;
LAB_:
    if (param_4 - 8 < 4) {
      func_0x(param_3,0,param_4 - 8);
      puVar12 = (undefined4 *)(*_DAT_)();
      *puVar12 = 0x22;
      (*_DAT_)();
    }
    else {
      *(undefined4 *)param_3 = uVar19;
    }
    piVar20 = (int *)((longlong)param_3 + 4);
    if (piVar20 != (int *)0x0) goto LAB_;
    puVar12 = (undefined4 *)(*_DAT_)();
    *puVar12 = 0x16;
  }
  else {
    if (param_4 < 8) {
      func_0x(param_3,0,param_4);
      puVar12 = (undefined4 *)(*_DAT_)();
      *puVar12 = 0x22;
      (*_DAT_)();
    }
    else {
      *param_3 = (ulonglong)uVar3 << 0x10;
    }
    param_3 = param_3 + 1;
    if (param_3 != (longlong *)0x0) goto LAB_;
    puVar12 = (undefined4 *)(*_DAT_)();
    *puVar12 = 0x16;
    (*_DAT_)();
    piVar20 = (int *)0x4;
LAB_:
    if (3 < param_4 - 0xc) {
      *piVar20 = iVar9 + uVar8;
      goto LAB_;
    }
    func_0x(piVar20,0,param_4 - 0xc);
    puVar12 = (undefined4 *)(*_DAT_)();
    *puVar12 = 0x22;
  }
  (*_DAT_)();
LAB_:
  if (iVar9 + uVar8 != 0) {
    piVar20 = piVar20 + 1;
    uVar18 = 0;
    uVar25 = uVar18;
    piStack_68 = piVar20;
    if (0 < (int)uVar8) {
      do {
        uVar11 = ~(uint)uVar18;
        if ((uVar11 & 0xc0000000) == 0x80000000) {
          puVar12 = (undefined4 *)
                    func_0x
                              (**(undefined8 **)
                                 (*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) + 0x160),
                               uVar11 & 0x1fffffff);
        }
        else {
          puVar12 = (undefined4 *)
                    func_0x
                              (*(undefined8 *)
                                (*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) + 0x160));
        }
        if (puVar12 == (undefined4 *)0x0) {
          uVar19 = 0xffffffff;
          func_0x(*(undefined8 *)(param_1 + 0x18),uVar11,&uStack_58);
        }
        else {
          uStack_58 = *puVar12;
          uStack_54 = puVar12[1];
          uStack_50 = *(undefined8 *)(puVar12 + 2);
          uVar19 = puVar12[0xf];
        }
        func_0x(param_2,uVar19,&uStack_58,(longlong)piVar20 + uVar25 * 10);
        uVar25 = (ulonglong)((int)uVar25 + 1);
        uVar11 = (uint)uVar18 + 1;
        uVar18 = (ulonglong)uVar11;
      } while ((int)uVar11 < (int)uVar8);
    }
    uVar8 = 0;
    lStack_60 = (longlong)iVar9;
    if (0 < lStack_60) {
      lStack_78 = 0;
      iStackX_18 = iVar10;
LAB_:
      iVar9 = 0;
      if (*(int *)(param_2 + 2) == 0) {
        pbVar23 = *(byte **)(param_2 + 4);
        uVar11 = *(uint *)(param_2 + 8);
        uVar18 = (ulonglong)uVar11;
        *puVar1 = 0;
        *(uint *)(param_2 + 10) = uVar11;
        bVar5 = *pbVar23;
        if ((bVar5 & 0x10) != 0) {
          uVar11 = uVar11 + 2 + (*(ushort *)(pbVar23 + uVar18) + 7 >> 3);
          uVar18 = (ulonglong)uVar11;
          *(uint *)(param_2 + 10) = uVar11;
          bVar5 = *pbVar23;
        }
        if ((bVar5 & 0x20) == 0) {
          *(int *)(param_2 + 2) = (int)uVar18;
          param_2[0xe] = 0;
          *(int *)(param_2 + 0xc) = (int)uVar18;
        }
        else {
          puVar26 = (ushort *)(pbVar23 + uVar18);
          uVar7 = *puVar26;
          param_2[0xe] = uVar7;
          if (uVar7 == 0) {
            cVar6 = func_0x(0x110f3b0);
            if (((cVar6 != '\0') && (lVar13 = func_0x(), lVar13 != 0)) &&
               (*(char *)(lVar13 + 0x499) != '\0')) {
              cVar6 = func_0x(0x110f3b0);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x9fedbc,0xb1eea8,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),3);
            uVar18 = (ulonglong)*(uint *)(param_2 + 10);
            uVar7 = param_2[0xe];
          }
          uVar11 = (int)uVar18 + (uVar7 + 1) * 2;
          *(uint *)(param_2 + 0xc) = uVar11;
          if (0x1f9e < uVar11) {
            cVar6 = func_0x(0x110f3b0);
            if (((cVar6 != '\0') && (lVar13 = func_0x(), lVar13 != 0)) &&
               (*(char *)(lVar13 + 0x499) != '\0')) {
              cVar6 = func_0x(0x110f3b0);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9fedbc,0xb1eea8,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar7 = param_2[0xe];
            uVar11 = *(uint *)(param_2 + 0xc);
          }
          uVar18 = (ulonglong)uVar7;
          uVar7 = puVar26[uVar18];
          *(uint *)(param_2 + 2) = uVar7 & 0x7fff;
          if ((uVar7 & 0x7fff) < uVar11) {
            cVar6 = func_0x(0x110f3b0);
            if (((cVar6 != '\0') && (lVar13 = func_0x(), lVar13 != 0)) &&
               (*(char *)(lVar13 + 0x499) != '\0')) {
              cVar6 = func_0x(0x110f3b0);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9fedbc,0xb1eea8,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar11 = *(uint *)(param_2 + 0xc);
            uVar18 = (ulonglong)(ushort)param_2[0xe];
          }
          puVar4 = puVar26;
          if ((short)uVar18 != 0) {
            do {
              uVar21 = puVar4[1] & 0x7fff;
              if ((uVar21 < uVar11) || (*(uint *)(param_2 + 2) < uVar21)) {
                cVar6 = func_0x(0x110f3b0);
                if ((cVar6 != '\0') &&
                   ((lVar13 = func_0x(), lVar13 != 0 &&
                    (*(char *)(lVar13 + 0x499) != '\0')))) {
                  cVar6 = func_0x(0x110f3b0);
                  if (cVar6 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x9fedbc,0xb1eea8,0x82a,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),4);
              }
              uVar18 = (ulonglong)(ushort)param_2[0xe];
              iVar9 = iVar9 + 1;
              puVar4 = puVar4 + 1;
              uVar11 = uVar21;
            } while (iVar9 < (int)(uint)(ushort)param_2[0xe]);
          }
          if ((short)puVar26[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
            lVar13 = *(longlong *)(param_2 + 4);
            do {
              uVar11 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar13 + uVar18 * 2) &
                       0x7fff;
              if ((int)uVar18 == 1) {
                uVar21 = *(uint *)(param_2 + 0xc);
                uVar17 = uVar21;
LAB_:
                if ((uVar11 < uVar21) || (*(uint *)(param_2 + 2) < uVar11)) goto LAB_;
              }
              else {
                uVar17 = *(uint *)(param_2 + 0xc);
                uVar21 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar13 + -2 + uVar18 * 2)
                         & 0x7fff;
                if (uVar17 <= uVar21) goto LAB_;
LAB_:
                func_0x(lVar13,7);
                uVar17 = *(uint *)(param_2 + 0xc);
              }
              if ((uVar21 < uVar17) || (*(uint *)(param_2 + 2) < uVar21)) goto LAB_;
              lVar13 = *(longlong *)(param_2 + 4);
              if (*(ushort *)(lVar13 + (ulonglong)uVar21) == 5) {
                *puVar1 = *puVar1 | 2;
                param_2[0xe] = param_2[0xe] + -1;
                uVar24 = (ulonglong)(uVar21 & 0xffff);
                param_2[0x15] = (short)uVar21;
                uVar18 = *(ulonglong *)(param_2 + 4);
                uVar7 = param_2[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar24 + 2 + uVar18) >> 0xe & 1) != 0) {
                  uVar7 = *(ushort *)(uVar24 + 2 + uVar18) & 0x3800 | param_2[0x16] & 0xc7ffU;
                }
                param_2[0x16] = uVar7;
                uVar16 = (uVar7 ^ *(ushort *)(uVar24 + 2 + uVar18)) & 0x7ff ^ uVar7;
                param_2[0x16] = uVar16;
                uVar22 = (ulonglong)((uVar16 & 0x7ff) * 2) + 4 + uVar18 + (uVar7 >> 0xb & 7) * 2 +
                         uVar24;
                if (uVar22 < uVar24 + uVar18) {
                  func_0x(uVar24 + uVar18,0x19);
                  uVar16 = param_2[0x16];
                  uVar24 = (ulonglong)(ushort)param_2[0x15];
                  uVar18 = (ulonglong)*(uint *)(param_2 + 4);
                }
                if (uVar11 - uVar21 <
                    (((uVar16 & 0x7ff) * 2 - (int)uVar24) - (int)uVar18) + (int)uVar22) {
                  func_0x(uVar24 + *(longlong *)(param_2 + 4),0x19);
                  uVar16 = param_2[0x16];
                }
                iVar9 = 0;
                if (((uVar16 & 0x3800) != 0) &&
                   (puVar26 = (ushort *)
                              (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                   (uVar16 & 0x3800) != 0)) goto LAB_;
                break;
              }
              if (*(ushort *)(lVar13 + (ulonglong)uVar21) < 0x400) break;
              *puVar1 = *puVar1 | 1;
              uVar7 = param_2[0xe] - 1;
              param_2[0xe] = uVar7;
              if ((uVar7 == 0) ||
                 (uVar18 = (ulonglong)uVar7, -1 < (short)puVar26[(ulonglong)(uVar7 - 1) + 1]))
              break;
            } while( true );
          }
          pbVar23 = *(byte **)(param_2 + 4);
          uVar18 = (ulonglong)*(uint *)(param_2 + 2);
        }
        goto LAB_;
      }
      goto LAB_;
    }
  }
LAB_:
  *param_5 = iVar10;
  return;
LAB_:
  do {
    if ((uVar16 & 0x7ff) < (*puVar26 & 0x7ff)) {
      func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),0x1a);
      uVar16 = param_2[0x16];
    }
    iVar9 = iVar9 + 1;
    puVar26 = puVar26 + 1;
  } while (iVar9 < (int)(uVar16 >> 0xb & 7));
  pbVar23 = *(byte **)(param_2 + 4);
  uVar18 = (ulonglong)*(uint *)(param_2 + 2);
LAB_:
  if ((*pbVar23 & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0x13) = 0;
  }
  else {
    *(int *)(param_2 + 0x13) = (int)uVar18;
    *(int *)(param_2 + 2) = (int)uVar18 + 0xe;
    uVar14 = func_0x(puVar1);
    func_0x(uVar14,auStack_70);
    iVar9 = func_0x(auStack_70);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar9;
    uVar18 = (ulonglong)*(uint *)(param_2 + 2);
  }
  iVar9 = (int)uVar18;
  if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
     (*(ulonglong *)(param_2 + 0xf) < uVar18 + *(longlong *)(param_2 + 4))) {
    cVar6 = func_0x(0x110f3b0);
    if ((cVar6 != '\0') &&
       ((lVar13 = func_0x(), lVar13 != 0 && (*(char *)(lVar13 + 0x499) != '\0')))) {
      cVar6 = func_0x(0x110f3b0);
      if (cVar6 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0x9fedbc,0xb1eea8,0x886,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),0x12);
    iVar9 = *(int *)(param_2 + 2);
  }
  if (0x3f3b < iVar9 - 1U) {
    cVar6 = func_0x(0x110f3b0);
    if (((cVar6 != '\0') && (lVar13 = func_0x(), lVar13 != 0)) &&
       (*(char *)(lVar13 + 0x499) != '\0')) {
      cVar6 = func_0x(0x110f3b0);
      if (cVar6 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0x9fedbc,0xb1eea8,0x88b,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),5);
  }
LAB_:
  iVar9 = func_0x(puVar1);
  if (iVar9 == 0) {
    iVar9 = func_0x(puVar1);
    if (iVar9 == 0) {
      (*_DAT_)(1,0xbbaad8,0xbabb68,0xd7a,0);
    }
  }
  else {
    uVar7 = param_2[0x16];
    lVar13 = 0;
    if (uVar8 < (uVar7 & 0x7ff)) {
      uVar16 = 0;
      lVar2 = *(longlong *)(param_2 + 4) + (ulonglong)(ushort)param_2[0x15];
      if ((uVar7 & 0x3800) == 0) {
        uVar15 = *(ushort *)(lVar2 + 2);
LAB_:
        uVar16 = uVar15 >> 0xb & 7;
      }
      else if ((uVar7 >> 0xb & 7) != 0) {
        do {
          if (((lVar13 == 0) || ((*(ushort *)(lVar2 + 2 + lVar13 * 2) & 0x7ff) <= uVar8)) &&
             (uVar15 = *(ushort *)(lVar2 + 4 + lVar13 * 2),
             (int)uVar8 <= (int)((uVar15 & 0x7ff) - 1))) goto LAB_;
          lVar13 = lVar13 + 1;
        } while (lVar13 < (longlong)(ulonglong)(uVar7 >> 0xb & 7));
      }
      iStackX_18 = (uint)*(ushort *)
                          ((ulonglong)((uVar7 >> 0xb & 7) * 2) + *(longlong *)(param_2 + 4) +
                           lStack_78 * 2 + 4 + (ulonglong)(ushort)param_2[0x15]) +
                   (uint)uVar16 * 0x10000;
    }
    else {
      (*_DAT_)(1,0xbbaaa8,0xbbaa70,0x41a,0);
    }
  }
  lVar13 = func_0x
                     (**(undefined8 **)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) + 0x160),
                      iStackX_18);
  func_0x(param_2,*(undefined4 *)(lVar13 + 0x3c),lVar13,
                  (longlong)piStack_68 + (longlong)(int)uVar25 * 10);
  uVar25 = (ulonglong)((int)uVar25 + 1);
  lStack_78 = lStack_78 + 1;
  uVar8 = uVar8 + 1;
  if (lStack_60 <= lStack_78) goto LAB_;
  goto LAB_;
}

