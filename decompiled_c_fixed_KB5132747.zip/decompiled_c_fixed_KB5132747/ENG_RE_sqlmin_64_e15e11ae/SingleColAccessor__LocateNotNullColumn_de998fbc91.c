
/* WARNING: Control flow encountered bad instruction data */

uint FUN_(longlong param_1,undefined8 *param_2,ulonglong *param_3,longlong *param_4)

{
  ushort uVar1;
  ushort uVar2;
  short *psVar3;
  byte *pbVar4;
  longlong lVar5;
  ushort *puVar6;
  char cVar7;
  byte bVar8;
  short sVar9;
  uint uVar10;
  ulonglong uVar11;
  uint uVar12;
  ushort *puVar13;
  uint uVar14;
  
  cVar7 = (**(code **)*param_2)(param_2);
  if (cVar7 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(param_1 + 0x24) & 0x25) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar14 = 0;
  if (*(int *)(param_1 + 0x60) < 1) {
    *param_3 = 0;
    psVar3 = (short *)param_2[4];
    if (*psVar3 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(psVar3 + 2) == 0) {
      pbVar4 = *(byte **)(psVar3 + 4);
      uVar10 = *(uint *)(psVar3 + 8);
      uVar11 = (ulonglong)uVar10;
      psVar3[1] = 0;
      *(uint *)(psVar3 + 10) = uVar10;
      bVar8 = *pbVar4;
      if ((bVar8 & 0x10) != 0) {
        uVar10 = uVar10 + 2 + (*(ushort *)(pbVar4 + uVar11) + 7 >> 3);
        uVar11 = (ulonglong)uVar10;
        *(uint *)(psVar3 + 10) = uVar10;
        bVar8 = *pbVar4;
      }
      if ((bVar8 & 0x20) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar13 = (ushort *)(pbVar4 + uVar11);
      uVar1 = *puVar13;
      psVar3[0xe] = uVar1;
      if (uVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar10 = (int)uVar11 + (uVar1 + 1) * 2;
      *(uint *)(psVar3 + 0xc) = uVar10;
      if (0x1f9e < uVar10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar2 = puVar13[uVar1];
      *(uint *)(psVar3 + 2) = uVar2 & 0x7fff;
      if ((uVar2 & 0x7fff) < uVar10) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      puVar6 = puVar13;
      if (uVar1 != 0) {
        do {
          uVar12 = puVar6[1] & 0x7fff;
          if ((uVar12 < uVar10) || (*(uint *)(psVar3 + 2) < uVar12)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar1 = psVar3[0xe];
          uVar14 = uVar14 + 1;
          uVar10 = uVar12;
          puVar6 = puVar6 + 1;
        } while ((int)uVar14 < (int)(uint)uVar1);
      }
      if ((short)puVar13[(ulonglong)(uVar1 - 1) + 1] < 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((**(byte **)(psVar3 + 4) & 0x40) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined4 *)(psVar3 + 0x13) = 0;
      if ((*(ulonglong *)(psVar3 + 0xf) != 0) &&
         (*(ulonglong *)(psVar3 + 0xf) <
          (ulonglong)*(uint *)(psVar3 + 2) + *(longlong *)(psVar3 + 4))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (0x3f3b < *(uint *)(psVar3 + 2) - 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    sVar9 = -*(short *)(int *)(param_1 + 0x60);
    if ((*(byte *)(param_1 + 0x66) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((uint)(ushort)psVar3[0xe] < (uint)(int)sVar9) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar14 = *(ushort *)
              ((ulonglong)*(uint *)(psVar3 + 10) + *(longlong *)(psVar3 + 4) + (longlong)sVar9 * 2)
             & 0x7fff;
    if (sVar9 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar10 = *(ushort *)
              ((ulonglong)*(uint *)(psVar3 + 10) + *(longlong *)(psVar3 + 4) + -2 +
              (longlong)sVar9 * 2) & 0x7fff;
    if (((uVar10 < *(uint *)(psVar3 + 0xc)) || (uVar14 < uVar10)) ||
       (*(uint *)(psVar3 + 2) < uVar14)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(uint *)param_3 = uVar14 - uVar10;
    *param_4 = (ulonglong)uVar10 + *(longlong *)(psVar3 + 4);
    if ((ulonglong)*(ushort *)(param_1 + 0x70) < *param_3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar14 = *(uint *)(param_1 + 0x24) >> 6 & 1;
  }
  else {
    lVar5 = param_2[4];
    if ((*(byte *)(param_1 + 0x66) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(uint *)param_3 = (uint)*(ushort *)(param_1 + 0x70);
    *param_4 = (longlong)*(int *)(param_1 + 0x60) + *(longlong *)(lVar5 + 8);
  }
  return uVar14;
}

