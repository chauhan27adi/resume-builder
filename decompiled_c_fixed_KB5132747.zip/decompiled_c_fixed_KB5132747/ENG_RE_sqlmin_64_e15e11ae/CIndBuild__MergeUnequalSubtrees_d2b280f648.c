
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,longlong **param_3)

{
  byte *pbVar1;
  ushort uVar2;
  short sVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  char cVar7;
  uint uVar8;
  short *psVar9;
  int iVar10;
  code *UNRECOVERED_JUMPTABLE_00;
  uint uVar11;
  byte **ppbVar12;
  ulonglong uVar13;
  undefined auStack_938 [72];
  longlong lStack_8f0;
  undefined4 uStack_8d8;
  undefined8 uStack_8d0;
  longlong lStack_898;
  undefined8 uStack_890;
  undefined2 uStack_888;
  undefined8 uStack_880;
  undefined2 uStack_878;
  undefined4 uStack_838;
  undefined2 uStack_834;
  longlong **pplStack_828;
  undefined4 uStack_80c;
  undefined2 uStack_808;
  longlong **pplStack_7c8;
  undefined8 uStack_708;
  short sStack_1b8;
  undefined4 uStack_1b4;
  byte *pbStack_1b0;
  byte **ppbStack_1a8;
  undefined8 uStack_19a;
  undefined2 uStack_192;
  undefined2 uStack_190;
  undefined6 uStack_18e;
  int iStack_184;
  undefined auStack_180 [16];
  undefined auStack_170 [8];
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined6 uStack_158;
  undefined2 uStack_152;
  undefined6 uStack_150;
  undefined2 uStack_14a;
  undefined8 uStack_148;
  undefined auStack_140 [16];
  undefined auStack_130 [16];
  undefined auStack_120 [16];
  undefined8 uStack_110;
  ulonglong uStack_40;
  
  uStack_708 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_938;
  lVar4 = **param_2;
  lVar5 = **param_3;
  sStack_1b8 = -1;
  pbStack_1b0 = (byte *)0x0;
  uVar11 = 0;
  uStack_1b4 = 0;
  uStack_19a = 0;
  uStack_190 = 0;
  uStack_18e = 0;
  ppbStack_1a8 = (byte **)0x0;
  uStack_8d0 = *(undefined8 *)(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0xf50) = 1;
  if (*(char *)(lVar4 + 1) == '\x01') {
    uVar8 = 1;
  }
  else {
    uVar8 = uVar11;
    if ((*(char *)(lVar4 + 1) == '\x02') && (*(char *)(lVar4 + 3) == '\0')) {
      uVar8 = (uint)(1 < *(ushort *)(lVar4 + 6));
    }
  }
  if (*(char *)(lVar5 + 1) == '\x01') {
    uVar11 = 1;
  }
  else if ((*(char *)(lVar5 + 1) == '\x02') && (*(char *)(lVar5 + 3) == '\0')) {
    uVar11 = (uint)(1 < *(ushort *)(lVar5 + 6));
  }
  lStack_8f0 = lVar4;
  lStack_898 = param_1;
  pplStack_828 = param_3;
  pplStack_7c8 = param_2;
  if (uVar8 == uVar11) {
    if (uVar8 == 0) {
      iVar10 = (uint)*(byte *)(lVar4 + 3) - (uint)*(byte *)(lVar5 + 3);
      goto LAB_;
    }
  }
  else {
    iVar10 = (uVar8 ^ 1) * 2 + -1;
LAB_:
    if (0 < iVar10) {
      *(undefined4 *)(param_1 + 0xf50) = 0;
      lVar6 = *(longlong *)(param_1 + 0x60);
      *(undefined4 *)(lVar6 + 0x14) = *(undefined4 *)(lVar4 + 0x20);
      *(undefined2 *)(lVar6 + 0x18) = *(undefined2 *)(lVar4 + 0x24);
      *(undefined2 *)(lVar6 + 0x1a) = 0;
      func_0x(param_1,lVar5);
      func_0x(param_1,lVar5,param_2);
      *(undefined4 *)(param_1 + 0xf54) = *(undefined4 *)(lVar5 + 0x20);
      *(undefined2 *)(param_1 + 0xf58) = *(undefined2 *)(lVar5 + 0x24);
      lVar4 = **param_2;
      uVar2 = *(ushort *)(lVar4 + 0x16);
      iStack_184 = uVar2 - 1;
      if (-1 < *(char *)(lVar4 + 2)) goto LAB_;
      pbVar1 = (byte *)(lVar4 + 0x60);
      if ((sStack_1b8 == 0) || (ppbVar12 = ppbStack_1a8, ppbStack_1a8 == (byte **)0x0)) {
        uStack_158 = 0;
        uStack_14a = 0;
        auStack_130 = ZEXT816(0);
        auStack_180 = ZEXT816(0);
        stack0xfffffffffffffe92 = SUB1614(ZEXT816(0),2);
        auStack_170._0_2_ = 0xffff;
        uStack_168 = 0;
        uStack_152 = 0;
        uStack_150 = 0;
        uStack_148 = 0;
        uStack_160 = 0;
        auStack_140 = ZEXT816(0);
        auStack_120._0_12_ = ZEXT812(0);
        auStack_120._12_4_ = 0;
        uStack_110 = 0;
        ppbVar12 = (byte **)auStack_180;
      }
      if (*(short *)(lVar4 + 0x24) == 0) {
LAB_:
        uStack_890 = *(undefined8 *)(lVar4 + 0x28);
        uStack_888 = *(undefined2 *)(lVar4 + 0x30);
      }
      else {
        cVar7 = *(char *)(lVar4 + 1);
        if (cVar7 == '\v') {
          if (*(int *)(lVar4 + 0x18) != 99) {
LAB_:
            if (cVar7 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar7 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar4 + 0x18) != 99) goto LAB_;
        }
        uStack_838 = *(undefined4 *)(lVar4 + 0x20);
        uStack_834 = *(undefined2 *)(lVar4 + 0x24);
        cVar7 = func_0x(&uStack_838,0x1027c90);
        if (cVar7 == '\0') goto LAB_;
        func_0x(lVar4,&uStack_890);
      }
      *ppbVar12 = pbVar1;
      *(undefined4 *)(ppbVar12 + 0xc) = (undefined4)uStack_890;
      *(int *)((longlong)ppbVar12 + 100) = (int)((ulonglong)uStack_890 >> 0x20);
      *(undefined2 *)(ppbVar12 + 0xd) = uStack_888;
      *(undefined4 *)((longlong)ppbVar12 + 0x6c) = *(undefined4 *)(lVar4 + 0x20);
      *(undefined2 *)(ppbVar12 + 0xe) = *(undefined2 *)(lVar4 + 0x24);
      *(undefined2 *)((longlong)ppbVar12 + 0x72) = 0;
      uStack_8d8 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x10a6570);
      uVar13 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x10a6574);
      *(undefined2 *)(ppbVar12 + 2) = 0xffff;
      ppbVar12[3] = (byte *)0x0;
      *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
      ppbVar12[7] = (byte *)0x0;
      ppbVar12[4] = (byte *)0x0;
      ppbVar12[9] = (byte *)0x0;
      ppbVar12[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar12 + 0xb) = 0;
      if ((**ppbVar12 & 2) != 0) {
        pbVar1 = pbVar1 + uVar13;
        if ((*pbVar1 & 1) == 0) {
          *(undefined2 *)(ppbVar12 + 2) = 0;
          ppbVar12[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar12 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100504 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x103c3c) - 0x14f28a0
                    ))();
          return;
        }
        *(undefined2 *)(ppbVar12 + 2) = 1;
        ppbVar12[3] = pbVar1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x103c1c) * 4
                               + 0x103c0c) - 0x14f28a0);
                    /* WARNING: Could not emulate address calculation at 0x00100373 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      if ((**ppbVar12 & 4) != 0) {
        uStack_8d8._2_2_ = (short)((uint)uStack_8d8 >> 0x10);
        if (uStack_8d8._2_2_ != 0) {
          uVar13 = (ulonglong)*(ushort *)(lVar4 + 0x61 + (longlong)uStack_8d8._2_2_ * 2);
        }
        psVar9 = (short *)(pbVar1 + uVar13);
        ppbVar12[9] = (byte *)psVar9;
        sVar3 = *psVar9;
        ppbVar12[10] = (byte *)(psVar9 + 1);
        *(short *)(ppbVar12 + 0xb) = (sVar3 + 1) * 2;
      }
      if (ppbVar12[1] != (byte *)0x0) {
        func_0x(ppbVar12[1],ppbVar12);
      }
LAB_:
      pbStack_1b0 = (byte *)((ulonglong)*(ushort *)(lVar4 + (0x1000 - (ulonglong)uVar2) * 2) + lVar4
                            );
      if ((*pbStack_1b0 & 1) == 0) {
        sStack_1b8 = 0;
        uStack_1b4 = 0;
        uStack_192 = 0;
        uStack_190 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007c7 */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1b0 & 0xe) * 4 + 0x103ca8) -
                  0x14f28a0))((longlong)(int)(*pbStack_1b0 & 0xe),0x1027c90,pbStack_1b0);
        return;
      }
      sStack_1b8 = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1b0 & 0x1c) + 0x103c88)
                              * 4 + 0x103c78) - 0x14f28a0);
                    /* WARNING: Could not emulate address calculation at 0x0010061b */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
  }
  lVar6 = *(longlong *)(param_1 + 0x60);
  *(undefined4 *)(lVar6 + 0x14) = *(undefined4 *)(lVar5 + 0x20);
  *(undefined2 *)(lVar6 + 0x18) = *(undefined2 *)(lVar5 + 0x24);
  *(undefined2 *)(lVar6 + 0x1a) = 0;
  func_0x(param_1,lVar4);
  func_0x(param_1,lVar4,param_3);
  lVar4 = **param_3;
  iStack_184 = 0;
  if (-1 < *(char *)(lVar4 + 2)) goto LAB_;
  pbVar1 = (byte *)(lVar4 + 0x60);
  if ((sStack_1b8 == 0) || (ppbVar12 = ppbStack_1a8, ppbStack_1a8 == (byte **)0x0)) {
    uStack_158 = 0;
    uStack_14a = 0;
    auStack_130 = ZEXT816(0);
    auStack_180 = ZEXT816(0);
    stack0xfffffffffffffe92 = SUB1614(ZEXT816(0),2);
    auStack_170._0_2_ = 0xffff;
    uStack_168 = 0;
    uStack_152 = 0;
    uStack_150 = 0;
    uStack_148 = 0;
    uStack_160 = 0;
    auStack_140 = ZEXT816(0);
    auStack_120._0_12_ = ZEXT812(0);
    auStack_120._12_4_ = 0;
    uStack_110 = 0;
    ppbVar12 = (byte **)auStack_180;
  }
  if (*(short *)(lVar4 + 0x24) == 0) {
LAB_:
    uStack_880 = *(undefined8 *)(lVar4 + 0x28);
    uStack_878 = *(undefined2 *)(lVar4 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar4 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar4 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar4 + 0x18) != 99) goto LAB_;
    }
    uStack_80c = *(undefined4 *)(lVar4 + 0x20);
    uStack_808 = *(undefined2 *)(lVar4 + 0x24);
    cVar7 = func_0x(&uStack_80c);
    if (cVar7 == '\0') goto LAB_;
    func_0x(lVar4,&uStack_880);
  }
  *ppbVar12 = pbVar1;
  *(undefined4 *)(ppbVar12 + 0xc) = (undefined4)uStack_880;
  *(int *)((longlong)ppbVar12 + 100) = (int)((ulonglong)uStack_880 >> 0x20);
  *(undefined2 *)(ppbVar12 + 0xd) = uStack_878;
  *(undefined4 *)((longlong)ppbVar12 + 0x6c) = *(undefined4 *)(lVar4 + 0x20);
  *(undefined2 *)(ppbVar12 + 0xe) = *(undefined2 *)(lVar4 + 0x24);
  *(undefined2 *)((longlong)ppbVar12 + 0x72) = 0;
  uStack_8d8 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x10a6570);
  uVar13 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x10a6574);
  *(undefined2 *)(ppbVar12 + 2) = 0xffff;
  ppbVar12[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
  ppbVar12[7] = (byte *)0x0;
  ppbVar12[4] = (byte *)0x0;
  ppbVar12[9] = (byte *)0x0;
  ppbVar12[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar12 + 0xb) = 0;
  if ((**ppbVar12 & 2) != 0) {
    pbVar1 = pbVar1 + uVar13;
    if ((*pbVar1 & 1) == 0) {
      *(undefined2 *)(ppbVar12 + 2) = 0;
      ppbVar12[3] = pbVar1;
      *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar12 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010162c */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x103d14) - 0x14f28a0))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar12 + 2) = 1;
    ppbVar12[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x103cf4) * 4 +
                           0x103ce4) - 0x14f28a0);
                    /* WARNING: Could not emulate address calculation at 0x0010148b */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar12 & 4) != 0) {
    uStack_8d8._2_2_ = (short)((uint)uStack_8d8 >> 0x10);
    if (uStack_8d8._2_2_ != 0) {
      uVar13 = (ulonglong)*(ushort *)(lVar4 + 0x61 + (longlong)uStack_8d8._2_2_ * 2);
    }
    psVar9 = (short *)(pbVar1 + uVar13);
    ppbVar12[9] = (byte *)psVar9;
    sVar3 = *psVar9;
    ppbVar12[10] = (byte *)(psVar9 + 1);
    *(short *)(ppbVar12 + 0xb) = (sVar3 + 1) * 2;
  }
  if (ppbVar12[1] != (byte *)0x0) {
    func_0x(ppbVar12[1],ppbVar12);
  }
LAB_:
  pbStack_1b0 = (byte *)((ulonglong)*(ushort *)(lVar4 + 0x1ffe) + lVar4);
  if ((*pbStack_1b0 & 1) == 0) {
    sStack_1b8 = 0;
    uStack_1b4 = 0;
    uStack_192 = 0;
    uStack_190 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00101900 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1b0 & 0xe) * 4 + 0x103d80) - 0x14f28a0)
    )((longlong)(int)(*pbStack_1b0 & 0xe),9,pbStack_1b0,pbStack_1b0);
    return;
  }
  sStack_1b8 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1b0 & 0x1c) + 0x103d60) * 4
                         + 0x103d50) - 0x14f28a0);
                    /* WARNING: Could not emulate address calculation at 0x00101737 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_1b0,pbStack_1b0,pbStack_1b0);
  return;
}

