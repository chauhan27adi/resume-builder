
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2)

{
  byte *pbVar1;
  ushort *puVar2;
  char cVar3;
  byte bVar4;
  undefined4 uVar5;
  int iVar6;
  undefined8 uVar7;
  ushort uVar8;
  ulonglong uVar9;
  longlong lVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  ulonglong uVar14;
  byte *pbVar15;
  byte *pbVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  ushort *puVar19;
  uint uVar20;
  int iVar21;
  undefined auStack_fa8 [32];
  undefined8 uStack_f88;
  uint uStack_f80;
  ulonglong uStack_f78;
  undefined8 uStack_f70;
  undefined4 uStack_f68;
  longlong lStack_f60;
  longlong lStack_f58;
  longlong lStack_f50;
  longlong lStack_f48;
  longlong lStack_f40;
  undefined4 uStack_f38;
  longlong lStack_f30;
  longlong lStack_f28;
  longlong lStack_f20;
  longlong lStack_f18;
  undefined8 uStack_f10;
  undefined8 uStack_f08;
  undefined8 uStack_f00;
  undefined8 uStack_ef8;
  longlong lStack_ef0;
  undefined8 uStack_ee8;
  longlong lStack_ee0;
  longlong lStack_ed8;
  longlong lStack_ed0;
  longlong lStack_ec8;
  longlong lStack_ec0;
  longlong lStack_eb8;
  longlong lStack_eb0;
  undefined8 uStack_ea8;
  undefined4 auStack_ea0 [2];
  int iStack_e98;
  undefined8 uStack_e90;
  undefined auStack_e88 [16];
  short sStack_e78;
  ushort uStack_e76;
  uint uStack_e74;
  byte *pbStack_e70;
  undefined8 uStack_e68;
  uint uStack_e60;
  ushort uStack_e5c;
  byte *pbStack_e5a;
  undefined2 uStack_e52;
  undefined2 uStack_e50;
  ushort uStack_e4e;
  ushort uStack_e4c;
  undefined2 uStack_e4a;
  undefined auStack_e44 [2060];
  undefined4 uStack_638;
  uint uStack_634;
  byte abStack_630 [1528];
  ulonglong uStack_38;
  
  uStack_e90 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_fa8;
  lStack_eb0 = 0;
  uStack_ea8 = 0;
  pbStack_e70 = (byte *)0x0;
  uStack_e74 = 0;
  pbStack_e5a = (byte *)0x0;
  uStack_e50 = 0;
  uStack_e4e = 0;
  uStack_e4c = 0;
  uStack_e4a = 0;
  uStack_e68 = 0;
  auStack_ea0[0] = 3;
  lStack_eb8 = param_1;
  iStack_e98 = param_2;
  func_0x(auStack_e44,0,0x800);
  sStack_e78 = 0;
  uStack_f80 = uStack_f80 & 0xffffff00;
  uStack_f88._0_4_ = 0x3c;
  func_0x(&uStack_e76,auStack_e44);
  uStack_f88 = (ulonglong)uStack_f88._4_4_ << 0x20;
  func_0x(auStack_e88,4,1,0);
  func_0x(&sStack_e78,auStack_e88,auStack_ea0,4);
  if (param_2 != 0) {
    lStack_eb0 = param_1 + 0x2d78;
    uStack_ea8._4_4_ = 2;
    uStack_f68 = 0;
    uStack_f70 = 0;
    uStack_f78 = 0;
    uStack_f80 = 0;
    uStack_f88 = 0;
    uVar5 = func_0x(lStack_eb0,2,0xffffffff,0);
    uStack_ea8 = CONCAT44(uStack_ea8._4_4_,uVar5);
  }
  lVar10 = lStack_eb8;
  lStack_ec0 = lStack_eb8 + 0x6c8;
  lStack_ec8 = lStack_eb8 + 0x2078;
  lStack_ed0 = lStack_eb8 + 0x2068;
  lStack_ed8 = lStack_eb8 + 0x205c;
  lStack_ee0 = lStack_eb8 + 0x2050;
  lStack_ef0 = lStack_eb8 + 0x6d8;
  lStack_f18 = lStack_eb8 + 0x2044;
  lStack_f20 = lStack_eb8 + 0x1288;
  lStack_f28 = lStack_eb8 + 0x127c;
  lStack_f30 = lStack_eb8 + 0x1270;
  lStack_f40 = lStack_eb8 + 0x12a0;
  lStack_f48 = lStack_eb8 + 0x6b8;
  uStack_ee8 = 0x1236d40;
  uStack_ef8 = 0x1236d40;
  uStack_f00 = 0x1236d40;
  uStack_f08 = 0x1be48a0;
  uStack_f10 = 0x1be48a0;
  uStack_f38 = *(undefined4 *)(lStack_eb8 + 0x126c);
  lStack_f50 = lStack_eb8 + 0x6ac;
  lStack_f58 = lStack_eb8 + 0x6a0;
  lStack_f60 = lStack_eb8 + 0x694;
  uStack_f68 = *(undefined4 *)(lStack_eb8 + 0x650);
  uStack_f70 = *(undefined8 *)(lStack_eb8 + 0x700);
  iVar6 = 0;
  uStack_f78 = uStack_f78 & 0xffffffff00000000;
  uStack_f80 = *(undefined4 *)(lStack_eb8 + 0x6f4);
  uStack_f88 = uStack_f88 & 0xffffffff00000000;
  func_0x(&sStack_e78,*(undefined4 *)(lStack_eb8 + 0xc),*(undefined2 *)(lStack_eb8 + 0x10),
                  lStack_eb8 + 0x678);
  func_0x(&sStack_e78);
  if (sStack_e78 == 0) {
    pbVar16 = pbStack_e70;
    uVar11 = uStack_e74;
    if (uStack_e74 == 0) {
      uStack_e76 = 0;
      uVar18 = uStack_e68 & 0xffffffff;
      uVar11 = (uint)uStack_e68;
      if ((*pbStack_e70 & 0x10) != 0) {
        uVar11 = (uint)uStack_e68 + 2 + (*(ushort *)(pbStack_e70 + uVar18) + 7 >> 3);
        uVar18 = (ulonglong)uVar11;
      }
      uStack_e68 = CONCAT44(uVar11,(uint)uStack_e68);
      uStack_e60 = (uint)uVar18;
      if ((*pbStack_e70 & 0x20) == 0) {
        uStack_e5c = 0;
        uStack_e74 = uStack_e60;
      }
      else {
        puVar19 = (ushort *)(pbStack_e70 + uVar18);
        uStack_e5c = *puVar19;
        if (uStack_e5c == 0) {
          cVar3 = func_0x(0x1b46600);
          if ((cVar3 != '\0') && (cVar3 = func_0x(), cVar3 != '\0')) {
            cVar3 = func_0x(0x1b46600);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_f88 = 0;
              (*_DAT_)(1,0x143600c,0x15560f8,0x80f);
            }
          }
          func_0x(pbStack_e70,3);
        }
        uStack_e60 = uStack_e68._4_4_ + 2 + (uint)uStack_e5c * 2;
        if (0x1f9e < uStack_e60) {
          cVar3 = func_0x(0x1b46600);
          if ((cVar3 != '\0') && (cVar3 = func_0x(), cVar3 != '\0')) {
            cVar3 = func_0x(0x1b46600);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_f88 = 0;
              (*_DAT_)(1,0x143600c,0x15560f8,0x816);
            }
          }
          func_0x(pbStack_e70,4);
        }
        uVar9 = (ulonglong)uStack_e5c;
        uStack_e74 = puVar19[uVar9] & 0x7fff;
        if (uStack_e74 < uStack_e60) {
          cVar3 = func_0x(0x1b46600);
          if ((cVar3 != '\0') && (cVar3 = func_0x(), cVar3 != '\0')) {
            cVar3 = func_0x(0x1b46600);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_f88 = 0;
              (*_DAT_)(1,0x143600c,0x15560f8,0x81d);
            }
          }
          func_0x(pbStack_e70,4);
          uVar9 = (ulonglong)uStack_e5c;
        }
        uVar18 = (ulonglong)uStack_e74;
        pbVar16 = pbStack_e70;
        puVar2 = puVar19;
        iVar21 = iVar6;
        uVar11 = uStack_e60;
        uVar12 = uStack_e60;
        if ((short)uVar9 != 0) {
          do {
            uVar12 = puVar2[1] & 0x7fff;
            if ((uVar12 < uVar11) || ((uint)uVar18 < uVar12)) {
              cVar3 = func_0x(0x1b46600);
              if ((cVar3 != '\0') && (cVar3 = func_0x(), cVar3 != '\0')) {
                cVar3 = func_0x(0x1b46600);
                if (cVar3 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_f88 = 0;
                  (*_DAT_)(1,0x143600c,0x15560f8,0x82a);
                }
              }
              func_0x(pbStack_e70,4);
              uVar9 = (ulonglong)uStack_e5c;
              uVar18 = (ulonglong)uStack_e74;
              pbVar16 = pbStack_e70;
            }
            iVar21 = iVar21 + 1;
            puVar2 = puVar2 + 1;
            uVar11 = uVar12;
            uVar12 = uStack_e60;
          } while (iVar21 < (int)uVar9);
        }
        while ((short)puVar19[(ulonglong)((int)uVar9 - 1) + 1] < 0) {
          if ((int)uVar9 == 1) {
            uVar14 = 1;
            uVar13 = uVar12;
          }
          else {
            uVar13 = *(ushort *)(pbVar16 + uVar9 * 2 + ((uStack_e68 >> 0x20) - 2)) & 0x7fff;
            uVar14 = uVar9;
          }
          uVar20 = *(ushort *)(pbVar16 + uVar14 * 2 + (uStack_e68 >> 0x20)) & 0x7fff;
          if (((uVar13 < uVar12) || (uVar20 < uVar13)) || ((uint)uVar18 < uVar20)) {
            func_0x(pbVar16,7);
            uVar9 = (ulonglong)uStack_e5c;
            uVar18 = (ulonglong)uStack_e74;
            pbVar16 = pbStack_e70;
            uVar12 = uStack_e60;
          }
          uVar11 = (uint)uVar18;
          lVar10 = lStack_eb8;
          if ((uVar13 < uVar12) || (uVar11 < uVar13)) goto LAB_;
          if (*(ushort *)(pbVar16 + uVar13) == 5) {
            uStack_e76 = uStack_e76 | 2;
            uStack_e5c = (short)uVar9 - 1;
            uVar9 = (ulonglong)(uVar13 & 0xffff);
            uStack_e4e = (ushort)uVar13;
            pbVar1 = pbVar16 + uVar9;
            if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
              uVar8 = uStack_e4c & 0xc7ff;
            }
            else {
              uVar8 = uStack_e4c ^ (uStack_e4c ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
            }
            uStack_e4c = (uVar8 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar8;
            uVar17 = (ulonglong)uStack_e4c;
            uVar14 = uVar17 & 0x7ff;
            lVar10 = (ulonglong)((uVar8 >> 0xb & 7) * 2) + 4 + uVar9;
            pbVar15 = pbVar16;
            if (pbVar16 + lVar10 + uVar14 * 2 < pbVar1) {
              func_0x(pbVar1,0x19);
              uVar17 = (ulonglong)uStack_e4c;
              uVar9 = (ulonglong)uStack_e4e;
              uVar18 = (ulonglong)uStack_e74;
              pbVar15 = pbStack_e70;
            }
            if (uVar20 - uVar13 <
                (((uStack_e4c & 0x7ff) * 2 - (int)uVar9) - (int)pbStack_e70) +
                (int)(pbVar16 + lVar10 + uVar14 * 2)) {
              func_0x(pbVar15 + uVar9,0x19);
              uVar17 = (ulonglong)uStack_e4c;
              uVar9 = (ulonglong)uStack_e4e;
              uVar18 = (ulonglong)uStack_e74;
              pbVar15 = pbStack_e70;
            }
            pbVar16 = pbVar15;
            if (((uVar17 & 0x3800) != 0) &&
               (puVar19 = (ushort *)(pbVar15 + uVar9 + 4), (uVar17 & 0x3800) != 0)) {
              do {
                if (((ushort)uVar17 & 0x7ff) < (*puVar19 & 0x7ff)) {
                  func_0x(pbVar15 + uVar9,0x1a);
                  uVar17 = (ulonglong)uStack_e4c;
                  uVar9 = (ulonglong)uStack_e4e;
                  pbVar15 = pbStack_e70;
                }
                iVar6 = iVar6 + 1;
                puVar19 = puVar19 + 1;
              } while (iVar6 < (int)((uStack_e4c & 0x3800) >> 0xb));
              uVar18 = (ulonglong)uStack_e74;
              pbVar16 = pbVar15;
            }
            break;
          }
          if (*(ushort *)(pbVar16 + uVar13) < 0x400) break;
          uStack_e76 = uStack_e76 | 1;
          uStack_e5c = (short)uVar9 - 1;
          uVar9 = (ulonglong)uStack_e5c;
          if (uStack_e5c == 0) break;
        }
      }
      if ((*pbVar16 & 0x40) == 0) {
        uStack_e52 = 0;
        uStack_e50 = 0;
      }
      else {
        uStack_e52 = (undefined2)uVar18;
        uStack_e50 = (undefined2)(uVar18 >> 0x10);
        uStack_e74 = (int)uVar18 + 0xe;
        uVar7 = func_0x(&uStack_e76);
        func_0x(uVar7,auStack_ea0);
        iVar6 = func_0x(auStack_ea0);
        uStack_e74 = uStack_e74 + iVar6;
        uVar18 = (ulonglong)uStack_e74;
        pbVar16 = pbStack_e70;
      }
      uVar11 = (uint)uVar18;
      if ((pbStack_e5a != (byte *)0x0) && (pbStack_e5a < pbVar16 + uVar18)) {
        cVar3 = func_0x(0x1b46600);
        if ((cVar3 != '\0') && (cVar3 = func_0x(), cVar3 != '\0')) {
          cVar3 = func_0x(0x1b46600);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_f88 = 0;
            (*_DAT_)(1,0x143600c,0x15560f8,0x886);
          }
        }
        func_0x(pbStack_e70,0x12);
        pbVar16 = pbStack_e70;
        uVar11 = uStack_e74;
      }
      lVar10 = lStack_eb8;
      if (0x3f3b < uVar11 - 1) {
        cVar3 = func_0x(0x1b46600);
        if ((cVar3 != '\0') && (cVar3 = func_0x(), cVar3 != '\0')) {
          cVar3 = func_0x(0x1b46600);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_f88 = 0;
            (*_DAT_)(1,0x143600c,0x15560f8,0x88b);
          }
        }
        func_0x(pbStack_e70,5);
        pbVar16 = pbStack_e70;
        lVar10 = lStack_eb8;
        uVar11 = uStack_e74;
      }
    }
LAB_:
    if (8 < uVar11) goto LAB_;
    bVar4 = *pbVar16 & 0xe;
  }
  else {
    if (uStack_e74 == 0) {
      func_0x(&uStack_e76);
    }
    pbVar16 = pbStack_e70;
    uVar11 = uStack_e74;
    if (8 < uStack_e74) goto LAB_;
    bVar4 = *pbStack_e70 & 0x1c;
  }
  if ((bVar4 == 0) || (bVar4 == 0xc)) {
    uVar11 = 9;
  }
LAB_:
  func_0x(&uStack_634,0,0x5fc);
  uStack_638 = 4;
  iVar6 = 0x600;
  if (*(char *)(lVar10 + 0x2dac) == '\0') {
    iVar6 = uVar11 + 8;
  }
  func_0x(abStack_630,0x5f8,pbVar16,uVar11);
  pbVar16 = abStack_630;
  uVar18 = (ulonglong)(iVar6 - 8U);
  uStack_634 = 0xffffffff;
  if (iVar6 - 8U != 0) {
    do {
      uStack_634 = uStack_634 >> 8 ^
                   *(uint *)((ulonglong)((uStack_634 ^ *pbVar16) & 0xff) * 4 + 0x11d29c0);
      pbVar16 = pbVar16 + 1;
      uVar18 = uVar18 - 1;
    } while (uVar18 != 0);
  }
  func_0x(lVar10 + 0x18,&uStack_638,iVar6,iStack_e98);
  if ((int)uStack_ea8 != 0) {
    func_0x(lStack_eb0,uStack_ea8._4_4_);
    uStack_ea8 = uStack_ea8 & 0xffffffff00000000;
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_fa8);
  return;
}

