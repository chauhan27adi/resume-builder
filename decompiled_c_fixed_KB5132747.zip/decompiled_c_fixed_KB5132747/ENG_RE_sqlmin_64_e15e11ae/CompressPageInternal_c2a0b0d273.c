
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,longlong param_3,undefined8 param_4)

{
  byte *pbVar1;
  uint *puVar2;
  uint *puVar3;
  longlong **pplVar4;
  undefined8 uVar5;
  ushort *puVar6;
  char cVar7;
  byte bVar8;
  ushort uVar9;
  short sVar10;
  uint uVar11;
  int iVar12;
  int iVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  short *psVar17;
  undefined8 uVar18;
  byte **ppbVar19;
  byte **ppbVar20;
  ushort uVar21;
  uint uVar22;
  byte **ppbVar23;
  undefined *puVar24;
  undefined *puVar25;
  undefined *puVar26;
  longlong lVar27;
  uint uVar28;
  longlong lVar29;
  byte **ppbVar30;
  byte *pbVar31;
  undefined2 uVar32;
  longlong *plVar33;
  undefined4 uVar34;
  uint uVar35;
  byte *pbVar36;
  ulonglong uVar37;
  ulonglong uVar38;
  ulonglong uVar39;
  ushort *puVar40;
  longlong unaff_GS_OFFSET;
  bool bVar41;
  char acStackX_8 [4];
  uint auStackX_c [3];
  longlong *plStackX_18;
  uint auStackX_20 [2];
  undefined8 uStack_58;
  undefined auStack_50 [8];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar14 = func_0x();
  lVar14 = -lVar14;
  puVar26 = &stack0xffffffffffffffc0 + lVar14;
  puVar25 = &stack0xffffffffffffffc0 + lVar14;
  puVar24 = &stack0xffffffffffffffc0 + lVar14;
  puVar2 = (uint *)((longlong)auStackX_20 + lVar14 + -0x20);
  *(undefined8 *)(&stack0x000001c0 + lVar14) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x0000bbc0 + lVar14) = _DAT_ ^ (ulonglong)puVar2;
  *(undefined8 *)(&stack0x00000140 + lVar14) = param_4;
  *(longlong *)(&stack0x00000040 + lVar14) = param_3;
  *(longlong ***)((longlong)&plStackX_18 + lVar14) = param_2;
  *(undefined8 *)(&stack0x00000098 + lVar14) = *(undefined8 *)(&stack0x0000bc40 + lVar14);
  *(undefined (*) [16])(&stack0x00000280 + lVar14) = ZEXT816(0);
  *(undefined2 *)(&stack0x00000290 + lVar14) = 0xffff;
  ppbVar23 = (byte **)0x0;
  *(undefined8 *)(&stack0x00000298 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000294 + lVar14) = 0;
  *(undefined8 *)(&stack0x000002ae + lVar14) = 0;
  *(undefined8 *)(&stack0x000002b8 + lVar14) = 0;
  *(undefined8 *)(&stack0x000002a0 + lVar14) = 0;
  *(undefined8 *)(&stack0x000002c8 + lVar14) = 0;
  *(undefined8 *)(&stack0x000002e0 + lVar14) = 0;
  *(undefined4 *)(&stack0x000002e8 + lVar14) = 0;
  *(undefined2 *)(&stack0x000002f2 + lVar14) = 0;
  lVar15 = param_1;
  if (param_1 == 0) {
    lVar15 = **param_2;
  }
  *(longlong *)(&stack0x00000028 + lVar14) = lVar15;
  uVar21 = *(ushort *)(lVar15 + 0x16);
  *(uint *)((longlong)auStackX_c + lVar14) = (uint)uVar21;
  uVar9 = *(ushort *)(**(longlong **)(*(longlong *)(param_3 + 8) + 0x160) + 0x10);
  *(ushort *)puVar2 = uVar9;
  *(undefined4 *)(&stack0x00000030 + lVar14) = 0;
  bVar8 = -(*(char *)(lVar15 + 2) >> 7);
  *(uint *)((longlong)auStackX_c + lVar14 + 4) = (uint)bVar8;
  if ((uVar21 == 1) && (bVar8 == 0)) goto LAB_;
  *(undefined2 *)(&stack0x000001c8 + lVar14) = 0xffff;
  *(undefined8 *)(&stack0x000001d0 + lVar14) = 0;
  *(undefined4 *)(&stack0x000001cc + lVar14) = 0;
  *(undefined8 *)(&stack0x000001e6 + lVar14) = 0;
  *(undefined8 *)(&stack0x000001f0 + lVar14) = 0;
  *(undefined4 *)(&stack0x000001fc + lVar14) = 0xffffffff;
  *(undefined8 *)(&stack0x00000300 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000308 + lVar14) = 0;
  *(undefined2 *)(&stack0x00000310 + lVar14) = 0xffff;
  *(undefined8 *)(&stack0x00000318 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000314 + lVar14) = 0;
  *(undefined8 *)(&stack0x0000032e + lVar14) = 0;
  *(undefined8 *)(&stack0x00000338 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000320 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000348 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000360 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000368 + lVar14) = 0;
  *(undefined2 *)(&stack0x00000372 + lVar14) = 0;
  *(undefined (*) [16])(&stack0x00000380 + lVar14) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000390 + lVar14) = ZEXT816(0);
  *(undefined8 *)(&stack0x000003a0 + lVar14) = 0;
  *(undefined8 *)(&stack0x000003a8 + lVar14) = 0;
  *(undefined8 *)(&stack0x000003b0 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000dd8 + lVar14) = 0;
  *(undefined8 *)(&stack0x00005870 + lVar14) = 0;
  *(undefined4 *)(&stack0x00007c78 + lVar14) = 0;
  *(undefined (*) [16])(&stack0x00000de0 + lVar14) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000df0 + lVar14) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000e00 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000e08 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000e10 + lVar14) = 0;
  *(undefined4 *)(&stack0x00001838 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000e04 + lVar14) = 1;
  *(undefined (*) [16])(&stack0x00000210 + lVar14) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000220 + lVar14) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000230 + lVar14) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000240 + lVar14) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000250 + lVar14) = ZEXT816(0);
  *(undefined (*) [16])(&stack0x00000260 + lVar14) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000270 + lVar14) = 0;
  *(undefined (*) [16])(&stack0x00000200 + lVar14) = ZEXT816(0);
  *(undefined2 *)(&stack0x00000210 + lVar14) = 0xffff;
  *(undefined8 *)(&stack0x00000218 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000214 + lVar14) = 0;
  *(undefined8 *)(&stack0x0000022e + lVar14) = 0;
  *(undefined8 *)(&stack0x00000238 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000220 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000248 + lVar14) = 0;
  *(undefined8 *)(&stack0x00000260 + lVar14) = 0;
  *(undefined4 *)(&stack0x00000268 + lVar14) = 0;
  *(undefined2 *)(&stack0x00000272 + lVar14) = 0;
  *(undefined **)(&stack0x000001d8 + lVar14) = &stack0x00000200 + lVar14;
  ppbVar20 = (byte **)(&stack0x00000200 + lVar14);
  if (*(short *)(&stack0x000001c8 + lVar14) == 0) {
    ppbVar20 = ppbVar23;
  }
  if ((ppbVar20[1] == (byte *)0x0) &&
     (ppbVar20[1] = &stack0x00000de0 + lVar14, *ppbVar20 != (byte *)0x0)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1002c1;
    func_0x(&stack0x00000de0 + lVar14);
  }
  *(undefined **)(&stack0x00000388 + lVar14) = &stack0x00005870 + lVar14;
  *(undefined4 *)(&stack0x000003a4 + lVar14) = 1;
  if ((*(longlong *)(&stack0x00000308 + lVar14) == 0) &&
     (*(undefined **)(&stack0x00000308 + lVar14) = &stack0x00000380 + lVar14,
     *(longlong *)(&stack0x00000300 + lVar14) != 0)) {
    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10030a;
    func_0x(&stack0x00000380 + lVar14,&stack0x00000300 + lVar14);
  }
  uVar21 = (ushort)*(uint *)((longlong)auStackX_c + lVar14);
  uVar11 = 0;
  ppbVar20 = ppbVar23;
  if (uVar21 == 0) {
    lVar16 = *(longlong *)(&stack0x00000040 + lVar14);
    if ((*(char *)(*(longlong *)(lVar16 + 8) + 0x751) != '\0') && (bVar8 == 0)) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar14) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100349;
      (*_DAT_)(1,0x1913a20,0x18e6b08,0xb8);
    }
    uVar22 = *(uint *)(&stack0x0000bc48 + lVar14);
    lVar15 = *(longlong *)(&stack0x00000028 + lVar14);
LAB_:
    ppbVar30 = (byte **)(ulonglong)*(uint *)((longlong)auStackX_c + lVar14);
    puVar25 = puVar24;
LAB_:
    ppbVar19 = (byte **)(&stack0x00000300 + lVar14);
    if (*(longlong *)(&stack0x00000300 + lVar14) == 0) {
      ppbVar19 = ppbVar23;
    }
    *(undefined2 *)(&stack0x00000188 + lVar14) = 0xffff;
    *(undefined8 *)(&stack0x00000190 + lVar14) = 0;
    *(undefined4 *)(&stack0x0000018c + lVar14) = 0;
    *(undefined8 *)(&stack0x000001a6 + lVar14) = 0;
    *(undefined8 *)(&stack0x000001b0 + lVar14) = 0;
    *(undefined8 *)(&stack0x00000198 + lVar14) = 0;
    *(undefined **)(&stack0x00000160 + lVar14) = &stack0x00007c80 + lVar14;
    *(undefined4 *)(&stack0x00000168 + lVar14) = 0x3f3c;
    *(byte ***)(&stack0x00000170 + lVar14) = ppbVar20;
    *(short *)(&stack0x00000178 + lVar14) = (short)ppbVar30;
    *(byte ***)(&stack0x00000180 + lVar14) = ppbVar19;
    puVar26 = puVar25;
    if (param_2 == (longlong **)0x0) {
      uVar28 = 1;
      if ((*(char *)(lVar15 + 1) == '\x01') && ((uVar22 & 1) == 0)) {
        uVar28 = uVar11;
      }
      *(undefined8 *)(puVar25 + -8) = 0x1036dc;
      func_0x(lVar15,&stack0x00000160 + lVar14,uVar28);
    }
    else {
      lVar15 = *(longlong *)(lVar16 + 8);
      *(uint *)(puVar25 + 0x28) = uVar22;
      *(undefined **)(puVar25 + 0x20) = &stack0x00000160 + lVar14;
      uVar18 = *(undefined8 *)(&stack0x00000140 + lVar14);
      *(undefined8 *)(puVar25 + -8) = 0x1036b9;
      func_0x(param_2,ppbVar30,lVar15 + 0x3c0,uVar18);
    }
  }
  else {
    if (uVar21 == 1) {
      lVar15 = *(longlong *)(&stack0x00000028 + lVar14);
      if (*(short *)(lVar15 + 0x1ffe) != 0) {
        *(undefined8 *)(&stack0x00000060 + lVar14) = 0;
        *(undefined4 *)(&stack0x0000005c + lVar14) = 0;
        *(undefined8 *)(&stack0x00000076 + lVar14) = 0;
        *(undefined8 *)(&stack0x00000080 + lVar14) = 0;
        *(undefined8 *)(&stack0x00000068 + lVar14) = 0;
        *(undefined4 *)((longlong)auStackX_20 + lVar14) = 2;
        if (param_2 != (longlong **)0x0) {
          plVar33 = *param_2;
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1003cc;
          lVar15 = func_0x(_DAT_,plVar33,1,0);
          *(ushort *)(lVar15 + 4) = *(ushort *)(lVar15 + 4) & 0xedff;
          *(undefined4 *)(lVar15 + 0x40) = 1;
          plVar33 = *param_2;
          if (*(short *)((longlong)plVar33 + 0x2c) != 2) {
            lVar15 = plVar33[0x12];
            if (lVar15 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1003fa;
              func_0x(plVar33);
              lVar15 = plVar33[0x12];
              plVar33 = *param_2;
            }
            if (((*(byte *)(*(longlong *)(lVar15 + 0x6b0) + 0x3c) & 1) != 0) &&
               (*(longlong *)(*(longlong *)(lVar15 + 0x6b0) + 0x280) == 0)) {
              lVar15 = plVar33[0x12];
              if (lVar15 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10042f;
                func_0x(plVar33);
                lVar15 = plVar33[0x12];
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10043b;
              cVar7 = func_0x(lVar15);
              if (cVar7 == '\0') goto LAB_;
            }
            plVar33 = *param_2;
            lVar15 = plVar33[0x12];
            if (lVar15 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10045a;
              func_0x(plVar33);
              lVar15 = plVar33[0x12];
            }
            if ((*(byte *)(lVar15 + 0x1cd0) & 0x20) == 0) {
              lVar15 = **param_2;
              if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x00000110 + lVar14) = *(undefined8 *)(lVar15 + 0x28);
                uVar21 = *(ushort *)(lVar15 + 0x30);
              }
              else {
                cVar7 = *(char *)(lVar15 + 1);
                if (cVar7 == '\v') {
                  if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
                    if (cVar7 != '\t') goto LAB_;
                    goto LAB_;
                  }
                }
                else {
                  if (cVar7 != '\b') goto LAB_;
LAB_:
                  if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
                }
                *puVar2 = *(uint *)(lVar15 + 0x20);
                *(undefined2 *)((longlong)auStackX_20 + lVar14 + -0x1c) =
                     *(undefined2 *)(lVar15 + 0x24);
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1004b6;
                cVar7 = func_0x(puVar2);
                if (cVar7 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1004c9;
                func_0x(lVar15,&stack0x00000110 + lVar14);
                uVar21 = *(ushort *)(&stack0x00000118 + lVar14);
              }
              param_2 = *(longlong ***)((longlong)&plStackX_18 + lVar14);
              plVar33 = *param_2;
              lVar15 = plVar33[0x12];
              if (lVar15 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100501;
                func_0x(plVar33);
                lVar15 = plVar33[0x12];
              }
              uVar32 = *(undefined2 *)((longlong)plVar33 + 0x74);
              uVar18 = *(undefined8 *)(lVar15 + 0x6a0);
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10051c;
              lVar16 = func_0x(uVar18,uVar32,0);
              plVar33 = *param_2;
              lVar15 = plVar33[0x12];
              if (lVar15 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100539;
                func_0x(plVar33);
                lVar15 = plVar33[0x12];
                plVar33 = *param_2;
              }
              if (((*(int *)(*(longlong *)(lVar15 + 0x7a8) + 0x58) != 0) ||
                  (*(uint *)(&stack0x00000110 + lVar14) < *(uint *)(lVar16 + 0x130))) ||
                 ((*(uint *)(lVar16 + 0x130) == *(uint *)(&stack0x00000110 + lVar14) &&
                  ((*(uint *)(&stack0x00000114 + lVar14) < *(uint *)(lVar16 + 0x134) ||
                   ((*(uint *)(lVar16 + 0x134) == *(uint *)(&stack0x00000114 + lVar14) &&
                    (uVar21 < *(ushort *)(lVar16 + 0x138))))))))) {
                lVar15 = plVar33[0x12];
                if (lVar15 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100591;
                  func_0x(plVar33);
                  lVar15 = plVar33[0x12];
                  plVar33 = *param_2;
                }
                if (((*(byte *)(*(longlong *)(lVar15 + 0x6b0) + 0x3c) & 1) == 0) ||
                   (*(longlong *)(*(longlong *)(lVar15 + 0x6b0) + 0x280) != 0)) {
                  lVar15 = plVar33[0x12];
                  if (lVar15 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100653;
                    func_0x(plVar33);
                    lVar15 = plVar33[0x12];
                    plVar33 = *param_2;
                  }
                  lVar16 = *plVar33;
                  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100669;
                  func_0x(lVar15,lVar16 + 0x20);
                  goto LAB_;
                }
              }
              lVar15 = plVar33[0x12];
              if (lVar15 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1005d1;
                func_0x(plVar33);
                lVar15 = plVar33[0x12];
                plVar33 = *param_2;
              }
              lVar16 = *plVar33;
              if ((*(int *)(*(longlong *)(lVar15 + 0x7a8) + 0x110) != 0) &&
                 (uVar22 = *(uint *)(lVar16 + 0x20) & 0xfffffff8,
                 uVar22 != (uVar22 / 0x7cd00) * 0x7cd00)) {
                lVar15 = plVar33[0x12];
                if (lVar15 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100620;
                  func_0x(plVar33);
                  lVar15 = plVar33[0x12];
                  lVar16 = **param_2;
                }
                uVar18 = *(undefined8 *)(lVar15 + 0x7a8);
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10063d;
                func_0x(uVar18,lVar16 + 0x20);
              }
            }
          }
LAB_:
          lVar15 = **param_2;
          if ((*(ushort *)(lVar15 + 4) & 0x2000) != 0) {
            if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
              *(undefined8 *)(&stack0x00000120 + lVar14) = *(undefined8 *)(lVar15 + 0x28);
              uVar21 = *(ushort *)(lVar15 + 0x30);
            }
            else {
              cVar7 = *(char *)(lVar15 + 1);
              if (cVar7 == '\v') {
                if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
                  if (cVar7 != '\t') goto LAB_;
                  goto LAB_;
                }
              }
              else {
                if (cVar7 != '\b') goto LAB_;
LAB_:
                if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
              }
              *(undefined4 *)(&stack0x000000e0 + lVar14) = *(undefined4 *)(lVar15 + 0x20);
              *(undefined2 *)(&stack0x000000e4 + lVar14) = *(undefined2 *)(lVar15 + 0x24);
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006d0;
              cVar7 = func_0x(&stack0x000000e0 + lVar14);
              if (cVar7 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1006e3;
              func_0x(lVar15,&stack0x00000120 + lVar14);
              uVar21 = *(ushort *)(&stack0x00000128 + lVar14);
            }
            plVar33 = *param_2;
            lVar15 = plVar33[0x12];
            if (lVar15 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100716;
              func_0x(plVar33);
              lVar15 = plVar33[0x12];
            }
            puVar3 = *(uint **)(*(longlong *)(lVar15 + 0x6b0) + 0x2c0);
            uVar22 = *(uint *)(&stack0x00000120 + lVar14);
            if ((((*(short *)((longlong)puVar3 + 10) != 2) || (uVar22 != 0)) && (uVar22 <= *puVar3))
               && ((uVar22 != *puVar3 ||
                   ((*(uint *)(&stack0x00000124 + lVar14) <= puVar3[1] &&
                    ((*(uint *)(&stack0x00000124 + lVar14) != puVar3[1] ||
                     (uVar21 <= *(ushort *)(puVar3 + 2))))))))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x100765;
              func_0x(param_2);
            }
          }
          if (param_1 == 0) {
            lVar15 = **param_2;
            *(longlong *)(&stack0x00000028 + lVar14) = lVar15;
          }
          else {
            *(longlong *)(&stack0x00000028 + lVar14) = param_1;
            lVar15 = param_1;
          }
        }
        puVar24 = auStack_50 + lVar14;
        *(undefined **)(&stack0x00000108 + lVar14) = &stack0xfffffffffffffff0 + lVar14;
        *(undefined4 *)(&stack0x000001fc + lVar14) = 0;
        *(undefined4 *)((longlong)auStackX_c + lVar14 + 4) = 9;
        uVar34 = 0xf;
        *puVar2 = 0xf;
        if (*(char *)(lVar15 + 2) < '\0') {
          pbVar31 = (byte *)(lVar15 + 0x60);
          if ((*(short *)(&stack0x000001c8 + lVar14) == 0) ||
             (ppbVar20 = *(byte ***)(&stack0x000001d8 + lVar14), ppbVar20 == (byte **)0x0)) {
            *(undefined (*) [16])(&stack0x00000210 + lVar14) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000220 + lVar14) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000230 + lVar14) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000240 + lVar14) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000250 + lVar14) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000260 + lVar14) = ZEXT816(0);
            *(undefined8 *)(&stack0x00000270 + lVar14) = 0;
            *(undefined (*) [16])(&stack0x00000200 + lVar14) = ZEXT816(0);
            *(undefined2 *)(&stack0x00000210 + lVar14) = 0xffff;
            *(undefined8 *)(&stack0x00000218 + lVar14) = 0;
            *(undefined4 *)(&stack0x00000214 + lVar14) = 0;
            *(undefined8 *)(&stack0x0000022e + lVar14) = 0;
            *(undefined8 *)(&stack0x00000238 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000220 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000248 + lVar14) = 0;
            *(undefined8 *)(&stack0x00000260 + lVar14) = 0;
            *(undefined4 *)(&stack0x00000268 + lVar14) = 0;
            *(undefined2 *)(&stack0x00000272 + lVar14) = 0;
            ppbVar20 = (byte **)(&stack0x00000200 + lVar14);
          }
          if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
            *(undefined8 *)(&stack0x00000130 + lVar14) = *(undefined8 *)(lVar15 + 0x28);
            uVar32 = *(undefined2 *)(lVar15 + 0x30);
          }
          else {
            cVar7 = *(char *)(lVar15 + 1);
            if (cVar7 == '\v') {
              if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
                if (cVar7 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar7 != '\b') goto LAB_;
LAB_:
              if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
            }
            *(undefined4 *)(&stack0x000000e8 + lVar14) = *(undefined4 *)(lVar15 + 0x20);
            *(undefined2 *)(&stack0x000000ec + lVar14) = *(undefined2 *)(lVar15 + 0x24);
            *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1008da;
            cVar7 = func_0x(&stack0x000000e8 + lVar14);
            if (cVar7 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1008ed;
            func_0x(lVar15,&stack0x00000130 + lVar14);
            uVar32 = *(undefined2 *)(&stack0x00000138 + lVar14);
          }
          *ppbVar20 = pbVar31;
          uVar18 = *(undefined8 *)(&stack0x00000130 + lVar14);
          *(undefined4 *)(ppbVar20 + 0xc) = *(undefined4 *)(&stack0x00000130 + lVar14);
          *(int *)((longlong)ppbVar20 + 100) = (int)((ulonglong)uVar18 >> 0x20);
          *(undefined2 *)(ppbVar20 + 0xd) = uVar32;
          *(undefined4 *)((longlong)ppbVar20 + 0x6c) = *(undefined4 *)(lVar15 + 0x20);
          *(undefined2 *)(ppbVar20 + 0xe) = *(undefined2 *)(lVar15 + 0x24);
          *(undefined2 *)((longlong)ppbVar20 + 0x72) = 0;
          bVar8 = *pbVar31;
          *(undefined4 *)(&stack0x00000048 + lVar14) =
               *(undefined4 *)((ulonglong)bVar8 * 6 + 0x155bf40);
          uVar39 = (ulonglong)*(short *)((ulonglong)bVar8 * 6 + 0x155bf44);
          *(undefined2 *)(ppbVar20 + 2) = 0xffff;
          ppbVar20[3] = (byte *)0x0;
          *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
          ppbVar20[7] = (byte *)0x0;
          ppbVar20[4] = (byte *)0x0;
          ppbVar20[9] = (byte *)0x0;
          ppbVar20[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar20 + 0xb) = 0;
          if ((**ppbVar20 & 2) != 0) {
            pbVar1 = pbVar31 + uVar39;
            if ((*pbVar1 & 1) == 0) {
              *(undefined2 *)(ppbVar20 + 2) = 0;
              ppbVar20[3] = pbVar1;
              *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar20 + 0x36) = 0;
              uVar22 = uVar11;
              switch(*pbVar1 & 0xe) {
              default:
                uVar22 = (uint)*(ushort *)(pbVar1 + 2);
                if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                  *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x100b6d;
                  func_0x(pbVar1,6);
                }
                break;
              case 4:
                uVar22 = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar22 = 1;
              }
              *(uint *)(ppbVar20 + 4) = uVar22;
              *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
            }
            else {
              *(undefined2 *)(ppbVar20 + 2) = 1;
              ppbVar20[3] = pbVar1;
              bVar8 = *pbVar1;
              switch(bVar8 & 0x1c) {
              default:
                if ((char)pbVar1[1] < '\0') {
                  uVar21 = *(ushort *)(pbVar1 + 1);
                  *(ushort *)((longlong)ppbVar20 + 0x12) = uVar21;
                  sVar10 = 3;
                  uVar21 = (uVar21 & 0x7f) << 8 | uVar21 >> 8;
                }
                else {
                  sVar10 = 2;
                  uVar21 = (ushort)pbVar1[1];
                }
                *(ushort *)((longlong)ppbVar20 + 0x12) = uVar21;
                *(short *)(ppbVar20 + 5) = sVar10;
                uVar21 = *(ushort *)((longlong)ppbVar20 + 0x12);
                *(short *)((longlong)ppbVar20 + 0x2c) = (short)(uVar21 + 1 >> 1) + sVar10;
                if (uVar21 < 0x1f) {
                  *(undefined2 *)((longlong)ppbVar20 + 0x2a) = 0;
                  *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
                  *(undefined4 *)(ppbVar20 + 8) = 0;
                  ppbVar20[7] = (byte *)0x0;
                  ppbVar20[4] = (byte *)0x0;
                }
                else {
                  iVar13 = uVar21 - 1;
                  *(short *)((longlong)ppbVar20 + 0x2a) =
                       ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                       (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
                  *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
                  *(undefined4 *)(ppbVar20 + 8) = 0;
                  ppbVar20[7] = (byte *)0x0;
                  ppbVar20[4] = (byte *)0x0;
                }
                break;
              case 4:
                if (((bVar8 & 0x1c) != 4) || (bVar41 = true, (bVar8 & 2) == 0)) {
                  bVar41 = false;
                }
                if (!bVar41) {
                  uVar34 = 1;
                }
                else {
                  *(undefined4 *)(ppbVar20 + 8) = 0;
                }
                ppbVar20[5] = (byte *)0x0;
                *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
                ppbVar20[6] = (byte *)0x0;
                ppbVar20[4] = (byte *)0x0;
                ppbVar20[7] = (byte *)0x0;
                ppbVar20[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar20 + 0x14) = uVar34;
                *(uint *)(ppbVar20 + 8) = (uint)bVar41;
                ppbVar20[7] = (byte *)0x0;
                ppbVar20[4] = (byte *)0x0;
                break;
              case 8:
                ppbVar20[5] = (byte *)0x0;
                *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
                ppbVar20[6] = (byte *)0x0;
                ppbVar20[4] = (byte *)0x0;
                ppbVar20[7] = (byte *)0x0;
                ppbVar20[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar20 + 0x14) = 9;
                *(undefined4 *)(ppbVar20 + 8) = 0;
                ppbVar20[7] = (byte *)0x0;
                ppbVar20[4] = (byte *)0x0;
              }
            }
          }
          if ((**ppbVar20 & 4) != 0) {
            if (*(short *)(&stack0x0000004a + lVar14) != 0) {
              uVar39 = (ulonglong)
                       *(ushort *)
                        (lVar15 + 0x61 + (longlong)*(short *)(&stack0x0000004a + lVar14) * 2);
            }
            psVar17 = (short *)(pbVar31 + uVar39);
            ppbVar20[9] = (byte *)psVar17;
            sVar10 = *psVar17;
            ppbVar20[10] = (byte *)(psVar17 + 1);
            *(short *)(ppbVar20 + 0xb) = (sVar10 + 1) * 2;
          }
          pbVar31 = ppbVar20[1];
          if (pbVar31 != (byte *)0x0) {
            *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x100c00;
            func_0x(pbVar31,ppbVar20);
          }
        }
        uVar39 = (ulonglong)*(ushort *)(lVar15 + 0xe);
        pbVar31 = (byte *)((ulonglong)*(ushort *)(lVar15 + 0x1ffe) + lVar15);
        bVar8 = *pbVar31;
        *(byte **)(&stack0x000001d0 + lVar14) = pbVar31;
        if ((bVar8 & 1) == 0) {
          *(undefined2 *)(&stack0x000001c8 + lVar14) = 0;
          *puVar2 = 0;
          *(undefined4 *)(&stack0x000001cc + lVar14) = 0;
          *(undefined4 *)(&stack0x000001ee + lVar14) = 0;
          switch(*pbVar31 & 0xe) {
          default:
            uVar39 = (ulonglong)*(ushort *)(pbVar31 + 2);
            if (0x1f9d < *(ushort *)(pbVar31 + 2) - 1) {
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x100e42;
              func_0x(pbVar31,6);
              pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
              *puVar2 = *(uint *)(&stack0x000001cc + lVar14);
            }
            break;
          case 4:
            uVar39 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar39 = 1;
          }
          *(int *)(&stack0x000001d8 + lVar14) = (int)uVar39;
          *(longlong *)(&stack0x000001e6 + lVar14) = lVar15 + 0x2000;
          ppbVar20 = *(byte ***)(&stack0x000001d8 + lVar14);
        }
        else {
          *(undefined2 *)(&stack0x000001c8 + lVar14) = 1;
          bVar8 = *pbVar31;
          switch(bVar8 & 0x1c) {
          default:
            if ((char)pbVar31[1] < '\0') {
              uVar21 = (*(ushort *)(pbVar31 + 1) & 0x7f) << 8 | *(ushort *)(pbVar31 + 1) >> 8;
              *(ushort *)(&stack0x000001ca + lVar14) = uVar21;
              *(undefined2 *)(&stack0x000001e0 + lVar14) = 3;
              *(undefined2 *)((longlong)auStackX_20 + lVar14) = 3;
            }
            else {
              uVar21 = (ushort)pbVar31[1];
              *(ushort *)(&stack0x000001ca + lVar14) = uVar21;
              *(undefined2 *)(&stack0x000001e0 + lVar14) = 2;
            }
            *(short *)(&stack0x000001e4 + lVar14) =
                 (short)(uVar21 + 1 >> 1) + (short)*(undefined4 *)((longlong)auStackX_20 + lVar14);
            if (uVar21 < 0x1f) {
              *(undefined2 *)(&stack0x000001e2 + lVar14) = 0;
              *puVar2 = 0;
              *(undefined4 *)(&stack0x000001cc + lVar14) = 0;
              *(undefined4 *)(&stack0x000001f8 + lVar14) = 0;
            }
            else {
              iVar13 = uVar21 - 1;
              *(short *)(&stack0x000001e2 + lVar14) =
                   ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                   (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
              *puVar2 = 0;
              *(undefined4 *)(&stack0x000001cc + lVar14) = 0;
              *(undefined4 *)(&stack0x000001f8 + lVar14) = 0;
            }
            break;
          case 4:
            if (((bVar8 & 0x1c) != 4) || ((bVar8 & 2) == 0)) {
              *(undefined8 *)(&stack0x000001e0 + lVar14) = 0;
              *(undefined2 *)(&stack0x000001ca + lVar14) = 0;
              *(undefined8 *)(&stack0x000001e8 + lVar14) = 0;
              uVar22 = 1;
              *(undefined4 *)(&stack0x000001cc + lVar14) = 1;
              *(undefined4 *)(&stack0x000001f8 + lVar14) = 0;
              goto code_r0x00100ddf;
            }
            *(undefined8 *)(&stack0x000001e0 + lVar14) = 0;
            *(undefined2 *)(&stack0x000001ca + lVar14) = 0;
            *(undefined8 *)(&stack0x000001e8 + lVar14) = 0;
            *(undefined4 *)(&stack0x000001cc + lVar14) = 0xf;
            *(undefined4 *)(&stack0x000001f8 + lVar14) = 1;
            break;
          case 8:
            *(undefined8 *)(&stack0x000001e0 + lVar14) = 0;
            *(undefined2 *)(&stack0x000001ca + lVar14) = 0;
            *(undefined8 *)(&stack0x000001e8 + lVar14) = 0;
            uVar22 = 9;
            *(undefined4 *)(&stack0x000001cc + lVar14) = 9;
            *(undefined4 *)(&stack0x000001f8 + lVar14) = 0;
code_r0x00100ddf:
            *puVar2 = uVar22;
          }
          *(longlong *)(&stack0x000001f0 + lVar14) = lVar15 + 0x2000;
          *(byte ***)(&stack0x000001d8 + lVar14) = ppbVar20;
          uVar39 = (ulonglong)ppbVar20 & 0xffffffff;
        }
        *(short *)(&stack0x00000058 + lVar14) = *(short *)(&stack0x000001c8 + lVar14);
        if (*(short *)(&stack0x000001c8 + lVar14) == 0) {
          uVar38 = (ulonglong)*puVar2;
          if (*puVar2 == 0) {
            *(undefined2 *)(&stack0x000001ca + lVar14) = 0;
            *(int *)(&stack0x000001dc + lVar14) = (int)uVar39;
            uVar38 = uVar39;
            if ((*pbVar31 & 0x10) != 0) {
              uVar22 = (int)uVar39 + 2 + (*(ushort *)(pbVar31 + uVar39) + 7 >> 3);
              uVar38 = (ulonglong)uVar22;
              *(uint *)(&stack0x000001dc + lVar14) = uVar22;
            }
            if ((*pbVar31 & 0x20) == 0) {
              *(int *)(&stack0x000001cc + lVar14) = (int)uVar38;
              *(undefined2 *)(&stack0x000001e4 + lVar14) = 0;
              *(int *)(&stack0x000001e0 + lVar14) = (int)uVar38;
            }
            else {
              puVar40 = (ushort *)(pbVar31 + uVar38);
              *(ushort **)(&stack0x00000098 + lVar14) = puVar40;
              uVar21 = *puVar40;
              *(ushort *)(&stack0x000001e4 + lVar14) = uVar21;
              if (uVar21 == 0) {
                *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x100f03;
                cVar7 = func_0x(0x1e726f0);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x100f10;
                  lVar16 = func_0x();
                  if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x100f32;
                    cVar7 = func_0x(0x1e726f0);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x100f4e;
                      (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffd0 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x100fc5;
                      (*_DAT_)(1,0x17620fc,0x18821e8,0x80f);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x100fd6;
                func_0x(*(undefined8 *)(&stack0x000001d0 + lVar14),3);
                pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
              }
              uVar22 = *(int *)(&stack0x000001dc + lVar14) +
                       (*(ushort *)(&stack0x000001e4 + lVar14) + 1) * 2;
              *(uint *)(&stack0x000001e0 + lVar14) = uVar22;
              if (0x1f9e < uVar22) {
                *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101012;
                cVar7 = func_0x(0x1e726f0);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10101b;
                  lVar16 = func_0x();
                  if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101035;
                    cVar7 = func_0x(0x1e726f0);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10104f;
                      (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffd0 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101073;
                      (*_DAT_)(1,0x17620fc,0x18821e8,0x816);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101081;
                func_0x(*(undefined8 *)(&stack0x000001d0 + lVar14),4);
                pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
              }
              uVar22 = puVar40[*(ushort *)(&stack0x000001e4 + lVar14)] & 0x7fff;
              *puVar2 = uVar22;
              *(uint *)(&stack0x000001cc + lVar14) = uVar22;
              if (uVar22 < *(uint *)(&stack0x000001e0 + lVar14)) {
                *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1010bf;
                cVar7 = func_0x(0x1e726f0);
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1010c8;
                  lVar16 = func_0x();
                  if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1010e2;
                    cVar7 = func_0x(0x1e726f0);
                    if (cVar7 == '\0') {
                      *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1010fe;
                      (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffd0 + lVar14) = 0;
                      *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101122;
                      (*_DAT_)(1,0x17620fc,0x18821e8,0x81d);
                    }
                  }
                }
                *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101130;
                func_0x(*(undefined8 *)(&stack0x000001d0 + lVar14),4);
                pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                uVar22 = *(uint *)(&stack0x000001cc + lVar14);
                *puVar2 = uVar22;
              }
              uVar38 = (ulonglong)uVar22;
              uVar22 = *(uint *)(&stack0x000001e0 + lVar14);
              ppbVar20 = ppbVar23;
              if (*(short *)(&stack0x000001e4 + lVar14) != 0) {
                do {
                  puVar40 = puVar40 + 1;
                  uVar28 = *puVar40 & 0x7fff;
                  if ((uVar28 < uVar22) || ((uint)uVar38 < uVar28)) {
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101192;
                    cVar7 = func_0x(0x1e726f0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10119b;
                      lVar15 = func_0x();
                      if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1011b5;
                        cVar7 = func_0x(0x1e726f0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1011d1;
                          (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffd0 + lVar14) = 0;
                          *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1011f5;
                          (*_DAT_)(1,0x17620fc,0x18821e8,0x82a);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101204;
                    func_0x(*(undefined8 *)(&stack0x000001d0 + lVar14),4);
                    pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                    uVar38 = (ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                  }
                  uVar35 = (int)ppbVar20 + 1;
                  ppbVar20 = (byte **)(ulonglong)uVar35;
                  uVar22 = uVar28;
                } while ((int)uVar35 < (int)(uint)*(ushort *)(&stack0x000001e4 + lVar14));
                *puVar2 = (uint)uVar38;
                puVar40 = *(ushort **)(&stack0x00000098 + lVar14);
                lVar15 = *(longlong *)(&stack0x00000028 + lVar14);
              }
              while( true ) {
                uVar21 = *(ushort *)(&stack0x000001e4 + lVar14);
                if (-1 < (short)puVar40[(ulonglong)(uVar21 - 1) + 1]) break;
                if (uVar21 == 1) {
                  uVar22 = *(uint *)(&stack0x000001e0 + lVar14);
                }
                else {
                  uVar22 = *(ushort *)
                            (pbVar31 +
                            (ulonglong)uVar21 * 2 +
                            ((ulonglong)*(uint *)(&stack0x000001dc + lVar14) - 2)) & 0x7fff;
                }
                uVar28 = *(ushort *)
                          (pbVar31 +
                          (ulonglong)uVar21 * 2 + (ulonglong)*(uint *)(&stack0x000001dc + lVar14)) &
                         0x7fff;
                if (((uVar22 < *(uint *)(&stack0x000001e0 + lVar14)) || (uVar28 < uVar22)) ||
                   ((uint)uVar38 < uVar28)) {
                  *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1012a6;
                  func_0x(pbVar31,7);
                  pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                  uVar38 = (ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                  *puVar2 = *(uint *)(&stack0x000001cc + lVar14);
                }
                if ((uVar22 < *(uint *)(&stack0x000001e0 + lVar14)) || ((uint)uVar38 < uVar22))
                goto code_r0x0010166d;
                if (*(ushort *)(pbVar31 + uVar22) == 5) {
                  *(ushort *)(&stack0x000001ca + lVar14) =
                       *(ushort *)(&stack0x000001ca + lVar14) | 2;
                  *(short *)(&stack0x000001e4 + lVar14) = *(short *)(&stack0x000001e4 + lVar14) + -1
                  ;
                  uVar39 = (ulonglong)(uVar22 & 0xffff);
                  *(short *)(&stack0x000001f2 + lVar14) = (short)uVar22;
                  pbVar1 = pbVar31 + uVar39;
                  uVar21 = *(ushort *)(&stack0x000001f4 + lVar14);
                  if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                    uVar21 = uVar21 & 0xc7ff;
                  }
                  else {
                    uVar21 = uVar21 ^ (*(ushort *)(pbVar1 + 2) ^ uVar21) & 0x3800;
                  }
                  *(ushort *)(&stack0x000001f4 + lVar14) = uVar21;
                  uVar9 = (uVar21 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar21;
                  *(ushort *)(&stack0x000001f4 + lVar14) = uVar9;
                  pbVar36 = pbVar31 + (ulonglong)((uVar9 & 0x7ff) * 2) + 4 +
                                      uVar39 + (uVar21 >> 0xb & 7) * 2;
                  if (pbVar36 < pbVar1) {
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1013b1;
                    func_0x(pbVar1,0x19);
                    uVar9 = *(ushort *)(&stack0x000001f4 + lVar14);
                    uVar39 = (ulonglong)*(ushort *)(&stack0x000001f2 + lVar14);
                    pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                    uVar35 = *(uint *)(&stack0x000001cc + lVar14);
                  }
                  else {
                    uVar35 = *puVar2;
                  }
                  if (uVar28 - uVar22 <
                      (((*(uint *)(&stack0x000001f4 + lVar14) & 0x7ff) * 2 - (int)uVar39) -
                      *(int *)(&stack0x000001d0 + lVar14)) + (int)pbVar36) {
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101404;
                    func_0x(pbVar31 + uVar39,0x19);
                    uVar9 = *(ushort *)(&stack0x000001f4 + lVar14);
                    uVar39 = (ulonglong)*(ushort *)(&stack0x000001f2 + lVar14);
                    pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                    uVar35 = *(uint *)(&stack0x000001cc + lVar14);
                  }
                  uVar38 = (ulonglong)uVar35;
                  if (((uVar9 & 0x3800) != 0) &&
                     (puVar40 = (ushort *)(pbVar31 + uVar39 + 4), ppbVar20 = ppbVar23,
                     (uVar9 & 0x3800) != 0)) {
                    do {
                      if ((uVar9 & 0x7ff) < (*puVar40 & 0x7ff)) {
                        *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101475;
                        func_0x(pbVar31 + uVar39,0x1a);
                        uVar9 = *(ushort *)(&stack0x000001f4 + lVar14);
                        uVar39 = (ulonglong)*(ushort *)(&stack0x000001f2 + lVar14);
                        pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                      }
                      uVar22 = (int)ppbVar20 + 1;
                      puVar40 = puVar40 + 1;
                      ppbVar20 = (byte **)(ulonglong)uVar22;
                    } while ((int)uVar22 < (int)(*(uint *)(&stack0x000001f4 + lVar14) >> 0xb & 7));
                    uVar38 = (ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                  }
                  break;
                }
                if (*(ushort *)(pbVar31 + uVar22) < 0x400) break;
                *(ushort *)(&stack0x000001ca + lVar14) = *(ushort *)(&stack0x000001ca + lVar14) | 1;
                psVar17 = (short *)(&stack0x000001e4 + lVar14);
                *psVar17 = *psVar17 + -1;
                if (*psVar17 == 0) break;
              }
            }
            if ((*pbVar31 & 0x40) == 0) {
              *(undefined4 *)(&stack0x000001ee + lVar14) = 0;
            }
            else {
              *(int *)(&stack0x000001ee + lVar14) = (int)uVar38;
              *(int *)(&stack0x000001cc + lVar14) = (int)uVar38 + 0xe;
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1014e4;
              uVar18 = func_0x(&stack0x000001ca + lVar14);
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1014f3;
              func_0x(uVar18,&stack0x00000148 + lVar14);
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1014ff;
              iVar13 = func_0x(&stack0x00000148 + lVar14);
              uVar38 = (ulonglong)(uint)(*(int *)(&stack0x000001cc + lVar14) + iVar13);
              *(int *)(&stack0x000001cc + lVar14) = *(int *)(&stack0x000001cc + lVar14) + iVar13;
              pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
            }
            if ((*(byte **)(&stack0x000001e6 + lVar14) != (byte *)0x0) &&
               (*(byte **)(&stack0x000001e6 + lVar14) < pbVar31 + uVar38)) {
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10154a;
              cVar7 = func_0x(0x1e726f0);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101553;
                lVar16 = func_0x();
                if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10156d;
                  cVar7 = func_0x(0x1e726f0);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101589;
                    (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffd0 + lVar14) = 0;
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1015af;
                    (*_DAT_)(1,0x17620fc,0x18821e8,0x886);
                  }
                }
              }
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1015c0;
              func_0x(*(undefined8 *)(&stack0x000001d0 + lVar14),0x12);
              pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
              uVar38 = (ulonglong)*(uint *)(&stack0x000001cc + lVar14);
            }
            if (0x3f3b < (int)uVar38 - 1U) {
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1015e9;
              cVar7 = func_0x(0x1e726f0);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1015f2;
                lVar16 = func_0x();
                if ((lVar16 != 0) && (*(char *)(lVar16 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10160c;
                  cVar7 = func_0x(0x1e726f0);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101628;
                    (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffd0 + lVar14) = 0;
                    *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10164e;
                    (*_DAT_)(1,0x17620fc,0x18821e8,0x88b);
                  }
                }
              }
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10165f;
              func_0x(*(undefined8 *)(&stack0x000001d0 + lVar14),5);
              pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
              uVar38 = (ulonglong)*(uint *)(&stack0x000001cc + lVar14);
            }
          }
code_r0x0010166d:
          uVar22 = (uint)uVar38;
          if ((8 < uVar22) || (((*pbVar31 & 0xe) != 0 && ((*pbVar31 & 0xe) != 0xc)))) {
            *(uint *)((longlong)auStackX_c + lVar14 + 4) = uVar22;
          }
          *(undefined4 *)(&stack0x00000068 + lVar14) = *(undefined4 *)(&stack0x000001d8 + lVar14);
          *(undefined2 *)(&stack0x0000005a + lVar14) = *(undefined2 *)(&stack0x000001ca + lVar14);
          *(uint *)(&stack0x0000005c + lVar14) = uVar22;
          *(undefined2 *)(&stack0x00000074 + lVar14) = *(undefined2 *)(&stack0x000001e4 + lVar14);
          *(undefined4 *)(&stack0x0000006c + lVar14) = *(undefined4 *)(&stack0x000001dc + lVar14);
          *(undefined4 *)(&stack0x00000070 + lVar14) = *(undefined4 *)(&stack0x000001e0 + lVar14);
          *(undefined4 *)(&stack0x0000007e + lVar14) = *(undefined4 *)(&stack0x000001ee + lVar14);
          uVar34 = *(undefined4 *)((longlong)auStackX_c + lVar14 + 4);
          *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1016d9;
          func_0x(&stack0x00007c80 + lVar14,0x3f3c,pbVar31,uVar34);
          *(undefined **)(&stack0x00000060 + lVar14) = &stack0x00007c80 + lVar14;
          *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1016ed;
          iVar13 = func_0x(&stack0x0000005a + lVar14);
          if (iVar13 != 0) {
            lVar16 = *(longlong *)(&stack0x00000060 + lVar14);
            puVar40 = (ushort *)((ulonglong)*(uint *)(&stack0x0000006c + lVar14) + lVar16);
            uVar22 = *puVar40 - 1;
            if (((&stack0x0000005a)[lVar14] & 1) == 0) {
              uVar22 = (uint)*puVar40;
            }
            uVar28 = *(uint *)(&stack0x00000070 + lVar14);
            if (uVar22 != 1) {
              uVar28 = puVar40[(longlong)(int)uVar22 + -1] & 0x7fff;
            }
            uVar22 = puVar40[(int)uVar22] & 0x7fff;
            if (((uVar28 < *(uint *)(&stack0x00000070 + lVar14)) || (uVar22 < uVar28)) ||
               (*(uint *)(&stack0x0000005c + lVar14) < uVar22)) {
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10174d;
              func_0x(lVar16,7);
              lVar16 = *(longlong *)(&stack0x00000060 + lVar14);
            }
            uVar38 = (ulonglong)(uVar28 & 0xffff);
            *(short *)(&stack0x00000082 + lVar14) = (short)uVar28;
            uVar39 = uVar38 + lVar16;
            uVar21 = *(ushort *)(&stack0x00000084 + lVar14);
            if ((*(ushort *)(uVar39 + 2) >> 0xe & 1) == 0) {
              uVar21 = uVar21 & 0xc7ff;
            }
            else {
              uVar21 = uVar21 ^ (*(ushort *)(uVar39 + 2) ^ uVar21) & 0x3800;
            }
            *(ushort *)(&stack0x00000084 + lVar14) = uVar21;
            uVar9 = (uVar21 ^ *(ushort *)(uVar39 + 2)) & 0x7ff ^ uVar21;
            *(ushort *)(&stack0x00000084 + lVar14) = uVar9;
            uVar37 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 +
                     lVar16 + (ulonglong)((uVar21 >> 0xb & 7) * 2) + uVar38;
            if (uVar37 < uVar39) {
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1017e7;
              func_0x(uVar39,0x19);
              uVar9 = *(ushort *)(&stack0x00000084 + lVar14);
              uVar38 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar14);
              lVar16 = *(longlong *)(&stack0x00000060 + lVar14);
            }
            if (uVar22 - uVar28 <
                (((*(uint *)(&stack0x00000084 + lVar14) & 0x7ff) * 2 - (int)uVar38) -
                *(int *)(&stack0x00000060 + lVar14)) + (int)uVar37) {
              *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101827;
              func_0x(uVar38 + lVar16,0x19);
              uVar9 = *(ushort *)(&stack0x00000084 + lVar14);
              uVar38 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar14);
              lVar16 = *(longlong *)(&stack0x00000060 + lVar14);
            }
            if (((uVar9 & 0x3800) != 0) &&
               (puVar40 = (ushort *)(lVar16 + 4 + uVar38), ppbVar20 = ppbVar23,
               (uVar9 & 0x3800) != 0)) {
              do {
                if ((uVar9 & 0x7ff) < (*puVar40 & 0x7ff)) {
                  *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x101895;
                  func_0x(uVar38 + lVar16,0x1a);
                  uVar9 = *(ushort *)(&stack0x00000084 + lVar14);
                  uVar38 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar14);
                  lVar16 = *(longlong *)(&stack0x00000060 + lVar14);
                }
                uVar22 = (int)ppbVar20 + 1;
                puVar40 = puVar40 + 1;
                ppbVar20 = (byte **)(ulonglong)uVar22;
              } while ((int)uVar22 < (int)(*(uint *)(&stack0x00000084 + lVar14) >> 0xb & 7));
              ppbVar20 = *(byte ***)(&stack0x00000108 + lVar14);
              *(undefined2 *)ppbVar20 = 0;
              uVar22 = *(uint *)(&stack0x0000bc48 + lVar14);
              puVar24 = auStack_50 + lVar14;
              goto code_r0x00103609;
            }
          }
code_r0x00101945:
          ppbVar20 = *(byte ***)(&stack0x00000108 + lVar14);
          *(undefined2 *)ppbVar20 = 0;
          uVar22 = *(uint *)(&stack0x0000bc48 + lVar14);
          puVar24 = auStack_50 + lVar14;
        }
        else {
          if ((ppbVar20 == (byte **)0x0) || (*ppbVar20 == (byte *)0x0)) {
            *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x10192e;
            func_0x(&stack0x0000005a + lVar14,&stack0x00007c80 + lVar14,0x3f3c,
                            &stack0x000001ca + lVar14);
            ppbVar20 = *(byte ***)(&stack0x000001d8 + lVar14);
            if (*(short *)(&stack0x000001c8 + lVar14) == 0) {
              ppbVar20 = ppbVar23;
            }
            *(byte ***)(&stack0x00000068 + lVar14) = ppbVar20;
            goto code_r0x00101945;
          }
          *(undefined8 *)((longlong)&uStack_58 + lVar14) = 0x1018fc;
          func_0x(&stack0x00000058 + lVar14,&stack0x00007c80 + lVar14,0x3f3c,
                          &stack0x000001c8 + lVar14);
          ppbVar20 = *(byte ***)(&stack0x00000108 + lVar14);
          *(undefined2 *)ppbVar20 = 0;
          uVar22 = *(uint *)(&stack0x0000bc48 + lVar14);
        }
code_r0x00103609:
        lVar16 = *(longlong *)(&stack0x00000040 + lVar14);
        param_2 = *(longlong ***)((longlong)&plStackX_18 + lVar14);
        goto LAB_;
      }
      uVar22 = *(uint *)(&stack0x0000bc48 + lVar14);
      lVar16 = *(longlong *)(&stack0x00000040 + lVar14);
      ppbVar30 = ppbVar23;
      goto LAB_;
    }
    if (*(int *)((longlong)auStackX_c + lVar14 + 4) == 0) {
LAB_:
      if (param_2 != (longlong **)0x0) {
        plVar33 = *param_2;
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101d99;
        lVar15 = func_0x(_DAT_,plVar33,1,0);
        *(ushort *)(lVar15 + 4) = *(ushort *)(lVar15 + 4) & 0xedff;
        *(undefined4 *)(lVar15 + 0x40) = 1;
        plVar33 = *param_2;
        if (*(short *)((longlong)plVar33 + 0x2c) != 2) {
          lVar15 = plVar33[0x12];
          if (lVar15 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101dcc;
            func_0x(plVar33);
            lVar15 = plVar33[0x12];
            plVar33 = *param_2;
          }
          if (((*(byte *)(*(longlong *)(lVar15 + 0x6b0) + 0x3c) & 1) != 0) &&
             (*(longlong *)(*(longlong *)(lVar15 + 0x6b0) + 0x280) == 0)) {
            lVar15 = plVar33[0x12];
            if (lVar15 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101e01;
              func_0x(plVar33);
              lVar15 = plVar33[0x12];
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101e0d;
            cVar7 = func_0x(lVar15);
            if (cVar7 == '\0') goto LAB_;
          }
          plVar33 = *param_2;
          lVar15 = plVar33[0x12];
          if (lVar15 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101e2c;
            func_0x(plVar33);
            lVar15 = plVar33[0x12];
          }
          if ((*(byte *)(lVar15 + 0x1cd0) & 0x20) == 0) {
            lVar15 = **param_2;
            if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
              *(undefined8 *)(&stack0x000000b0 + lVar14) = *(undefined8 *)(lVar15 + 0x28);
              uVar21 = *(ushort *)(lVar15 + 0x30);
              *(ushort *)(&stack0x000000b8 + lVar14) = uVar21;
            }
            else {
              cVar7 = *(char *)(lVar15 + 1);
              if (cVar7 == '\v') {
                if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
                  if (cVar7 != '\t') goto LAB_;
                  goto LAB_;
                }
              }
              else {
                if (cVar7 != '\b') goto LAB_;
LAB_:
                if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
              }
              *(undefined4 *)(&stack0x000000f8 + lVar14) = *(undefined4 *)(lVar15 + 0x20);
              *(undefined2 *)(&stack0x000000fc + lVar14) = *(undefined2 *)(lVar15 + 0x24);
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101e91;
              cVar7 = func_0x(&stack0x000000f8 + lVar14);
              if (cVar7 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101ea4;
              func_0x(lVar15,&stack0x000000b0 + lVar14);
              uVar21 = *(ushort *)(&stack0x000000b8 + lVar14);
            }
            pplVar4 = *(longlong ***)((longlong)&plStackX_18 + lVar14);
            plVar33 = *pplVar4;
            lVar15 = plVar33[0x12];
            if (lVar15 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101ee4;
              func_0x(plVar33);
              lVar15 = plVar33[0x12];
            }
            uVar32 = *(undefined2 *)((longlong)plVar33 + 0x74);
            uVar18 = *(undefined8 *)(lVar15 + 0x6a0);
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101eff;
            lVar16 = func_0x(uVar18,uVar32,0);
            plVar33 = *pplVar4;
            lVar15 = plVar33[0x12];
            if (lVar15 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101f1c;
              func_0x(plVar33);
              lVar15 = plVar33[0x12];
              plVar33 = **(longlong ***)((longlong)&plStackX_18 + lVar14);
            }
            if (((*(int *)(*(longlong *)(lVar15 + 0x7a8) + 0x58) != 0) ||
                (*(uint *)(&stack0x000000b0 + lVar14) < *(uint *)(lVar16 + 0x130))) ||
               ((*(uint *)(lVar16 + 0x130) == *(uint *)(&stack0x000000b0 + lVar14) &&
                ((*(uint *)(&stack0x000000b4 + lVar14) < *(uint *)(lVar16 + 0x134) ||
                 ((*(uint *)(lVar16 + 0x134) == *(uint *)(&stack0x000000b4 + lVar14) &&
                  (uVar21 < *(ushort *)(lVar16 + 0x138))))))))) {
              lVar15 = plVar33[0x12];
              if (lVar15 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101f78;
                func_0x(plVar33);
                lVar15 = plVar33[0x12];
                param_2 = *(longlong ***)((longlong)&plStackX_18 + lVar14);
                plVar33 = *param_2;
              }
              else {
                param_2 = *(longlong ***)((longlong)&plStackX_18 + lVar14);
              }
              if (((*(byte *)(*(longlong *)(lVar15 + 0x6b0) + 0x3c) & 1) == 0) ||
                 (*(longlong *)(*(longlong *)(lVar15 + 0x6b0) + 0x280) != 0)) {
                lVar15 = plVar33[0x12];
                if (lVar15 == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x102048;
                  func_0x(plVar33);
                  lVar15 = plVar33[0x12];
                  plVar33 = *param_2;
                }
                lVar16 = *plVar33;
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x10205e;
                func_0x(lVar15,lVar16 + 0x20);
                goto LAB_;
              }
            }
            lVar15 = plVar33[0x12];
            if (lVar15 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101fbf;
              func_0x(plVar33);
              lVar15 = plVar33[0x12];
              param_2 = *(longlong ***)((longlong)&plStackX_18 + lVar14);
              plVar33 = *param_2;
            }
            else {
              param_2 = *(longlong ***)((longlong)&plStackX_18 + lVar14);
            }
            lVar16 = *plVar33;
            if ((*(int *)(*(longlong *)(lVar15 + 0x7a8) + 0x110) != 0) &&
               (uVar22 = *(uint *)(lVar16 + 0x20) & 0xfffffff8,
               uVar22 != (uVar22 / 0x7cd00) * 0x7cd00)) {
              lVar15 = plVar33[0x12];
              if (lVar15 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x102015;
                func_0x(plVar33);
                lVar15 = plVar33[0x12];
                lVar16 = **param_2;
              }
              uVar18 = *(undefined8 *)(lVar15 + 0x7a8);
              *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x102032;
              func_0x(uVar18,lVar16 + 0x20);
            }
          }
        }
LAB_:
        lVar15 = **param_2;
        if ((*(ushort *)(lVar15 + 4) & 0x2000) != 0) {
          if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
            *(undefined8 *)(&stack0x000000c0 + lVar14) = *(undefined8 *)(lVar15 + 0x28);
            uVar21 = *(ushort *)(lVar15 + 0x30);
            *(ushort *)(&stack0x000000c8 + lVar14) = uVar21;
          }
          else {
            cVar7 = *(char *)(lVar15 + 1);
            if (cVar7 == '\v') {
              if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
                if (cVar7 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar7 != '\b') goto LAB_;
LAB_:
              if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
            }
            *(undefined4 *)(&stack0x00000050 + lVar14) = *(undefined4 *)(lVar15 + 0x20);
            *(undefined2 *)(&stack0x00000054 + lVar14) = *(undefined2 *)(lVar15 + 0x24);
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1020b6;
            cVar7 = func_0x(&stack0x00000050 + lVar14);
            if (cVar7 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1020c9;
            func_0x(lVar15,&stack0x000000c0 + lVar14);
            uVar21 = *(ushort *)(&stack0x000000c8 + lVar14);
          }
          plVar33 = *param_2;
          lVar15 = plVar33[0x12];
          if (lVar15 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x102103;
            func_0x(plVar33);
            lVar15 = plVar33[0x12];
          }
          puVar3 = *(uint **)(*(longlong *)(lVar15 + 0x6b0) + 0x2c0);
          uVar22 = *(uint *)(&stack0x000000c0 + lVar14);
          if ((((*(short *)((longlong)puVar3 + 10) != 2) || (uVar22 != 0)) && (uVar22 <= *puVar3))
             && ((uVar22 != *puVar3 ||
                 ((*(uint *)(&stack0x000000c4 + lVar14) <= puVar3[1] &&
                  ((*(uint *)(&stack0x000000c4 + lVar14) != puVar3[1] ||
                   (uVar21 <= *(ushort *)(puVar3 + 2))))))))) {
            *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x102152;
            func_0x(param_2);
          }
        }
        if (param_1 == 0) {
          *(longlong *)(&stack0x00000028 + lVar14) = **param_2;
        }
        else {
          *(longlong *)(&stack0x00000028 + lVar14) = param_1;
        }
        uVar9 = *(ushort *)puVar2;
      }
      uVar22 = *(uint *)((longlong)auStackX_c + lVar14);
      uVar38 = ((ulonglong)uVar22 & 0xffff) * 2;
      uVar39 = uVar38 + 0xf;
      if (uVar39 <= uVar38) {
        uVar39 = 0xffffffffffffff0;
      }
      uVar39 = uVar39 & 0xfffffffffffffff0;
      *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x102196;
      func_0x();
      lVar16 = -uVar39;
      *(longlong *)(&stack0x00000108 + lVar14) = (longlong)auStackX_20 + lVar16 + lVar14 + -0x20;
      if (*_DAT_ != '\0') {
        if (_DAT_ != 0) {
          ppbVar20 = (byte **)(_DAT_ + 0x6800);
        }
        if ((ppbVar20 != (byte **)0x0) && (*ppbVar20 != (byte *)0x0)) {
          LOCK();
          plVar33 = (longlong *)(*ppbVar20 + 0x148);
          *plVar33 = *plVar33 + 1;
          UNLOCK();
        }
      }
      lVar15 = *(longlong *)(*(longlong *)(*(longlong *)(&stack0x00000040 + lVar14) + 8) + 0x488);
      if (((lVar15 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
        if (*(longlong *)(lVar15 + 0x20) != 0) {
          lVar29 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar27 = *(longlong *)(lVar29 + 0x100);
          if (lVar27 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102251;
            (*_DAT_)(0);
            lVar27 = *(longlong *)(lVar29 + 0x100);
            uVar22 = *(uint *)((longlong)auStackX_c + lVar14);
          }
          ppbVar20 = ppbVar23;
          if (*(longlong *)(lVar27 + 0x260) != 0) {
            ppbVar20 = (byte **)(ulonglong)*(uint *)(*(longlong *)(lVar27 + 0x260) + 0xe68);
          }
          if ((uint)ppbVar20 < *(uint *)(_DAT_ + 8)) {
            lVar15 = *(longlong *)(*(longlong *)(lVar15 + 0x20) + (longlong)ppbVar20 * 8);
            *(longlong *)(lVar15 + 0x120) = *(longlong *)(lVar15 + 0x120) + 1;
            goto LAB_;
          }
        }
        LOCK();
        plVar33 = (longlong *)(*(longlong *)(lVar15 + 0x18) + 0x120);
        *plVar33 = *plVar33 + 1;
        UNLOCK();
      }
LAB_:
      *(uint *)(&stack0x00000038 + lVar14) = (uint)uVar9;
      uVar28 = (int)((ulonglong)(longlong)(int)((uint)uVar9 * (uVar22 & 0xffff) + -1) >> 9) + 1;
      puVar40 = *(ushort **)(&stack0x00000098 + lVar14);
      if ((int)uVar28 <= (int)(uint)*puVar40) {
        uVar28 = (uint)*puVar40;
      }
      uVar34 = *(undefined4 *)(&stack0x0000bc48 + lVar14);
      *(undefined4 *)((longlong)auStackX_20 + lVar14) = uVar34;
      if (uVar28 < 0x20) {
        puVar40[0x80] = uVar9;
        puVar40[0x81] = (ushort)uVar22;
        if (*(longlong *)(puVar40 + 0x8c) == 0) {
          lVar27 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar15 = *(longlong *)(lVar27 + 0x100);
          if (lVar15 == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10233c;
            (*_DAT_)(0);
            lVar15 = *(longlong *)(lVar27 + 0x100);
          }
          *(undefined8 *)(puVar40 + 0x8c) = *(undefined8 *)(lVar15 + 1000);
        }
        ppbVar20 = ppbVar23;
        ppbVar30 = ppbVar23;
        if (0 < (int)uVar28) {
          do {
            if ((int)(uint)*puVar40 <= (int)ppbVar20) {
              (&stack0xffffffffffffffe0)[lVar16 + lVar14] = 5;
              uVar18 = *(undefined8 *)(puVar40 + 0x8c);
              *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10238b;
              uVar18 = (*_DAT_)(0x2000,uVar18,0x176ddf8,0x4c5);
              *(undefined8 *)(puVar40 + (longlong)ppbVar30 * 4 + 4) = uVar18;
              *puVar40 = *puVar40 + 1;
            }
            uVar18 = *(undefined8 *)(puVar40 + (longlong)ppbVar30 * 4 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1023a4;
            func_0x(uVar18,0,0x2000);
            ppbVar30 = (byte **)((longlong)ppbVar30 + 1);
            ppbVar20 = (byte **)(ulonglong)((int)ppbVar20 + 1);
          } while ((longlong)ppbVar30 < (longlong)(int)uVar28);
        }
        uVar21 = puVar40[0x88];
        if (uVar21 < uVar9) {
          if (*(longlong *)(puVar40 + 0x84) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1023d1;
            (*_DAT_)();
            *(undefined8 *)(puVar40 + 0x84) = 0;
          }
          uVar18 = SUB168(ZEXT816(0x10) * ZEXT216(uVar9),0);
          if (SUB168(ZEXT816(0x10) * ZEXT216(uVar9),8) != 0) {
            uVar18 = 0xffffffffffffffff;
          }
          (&stack0xffffffffffffffe0)[lVar16 + lVar14] = 5;
          uVar5 = *(undefined8 *)(puVar40 + 0x8c);
          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102411;
          uVar18 = (*_DAT_)(uVar18,uVar5,0x176ddf8,0x4da);
          *(undefined8 *)(puVar40 + 0x84) = uVar18;
          puVar40[0x88] = uVar9;
          uVar21 = uVar9;
        }
        else {
          uVar18 = *(undefined8 *)(puVar40 + 0x84);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10243f;
        func_0x(uVar18,0,(ulonglong)uVar21 << 4);
        if ((*(int *)((longlong)auStackX_c + lVar14 + 4) != 0) &&
           ((**(byte **)(&stack0x00000280 + lVar14) & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102460;
          func_0x(puVar40,&stack0x00000280 + lVar14);
        }
        if ((*(byte *)((longlong)auStackX_20 + lVar14) & 1) == 0) {
          lVar15 = *(longlong *)(*(longlong *)(&stack0x00000040 + lVar14) + 0x20);
          if (((*(char *)(lVar15 + 0x1cdf) == '\0') || (*(char *)(lVar15 + 0x1cdc) == '\0')) ||
             (bVar8 = *(byte *)(*(longlong *)(*(longlong *)(&stack0x00000040 + lVar14) + 8) + 0x109)
             , acStackX_8[lVar14] = '\x01', (bVar8 & 0x40) == 0)) goto LAB_;
        }
        else {
LAB_:
          acStackX_8[lVar14] = '\0';
        }
        uVar39 = 0;
        *(undefined2 *)puVar2 = 0;
        uVar22 = *(uint *)((longlong)auStackX_c + lVar14);
        lVar15 = *(longlong *)(&stack0x00000028 + lVar14);
        bVar41 = (short)uVar22 != 0;
        while (bVar41) {
          if (*(short *)(lVar15 + (0xfff - uVar39) * 2) != 0) {
            *(int *)(&stack0x000001fc + lVar14) = (int)uVar39;
            ppbVar20 = ppbVar23;
            if (*(char *)(lVar15 + 2) < '\0') {
              pbVar31 = (byte *)(lVar15 + 0x60);
              if ((*(short *)(&stack0x000001c8 + lVar14) == 0) ||
                 (ppbVar20 = *(byte ***)(&stack0x000001d8 + lVar14), ppbVar20 == (byte **)0x0)) {
                *(undefined (*) [16])(&stack0x00000210 + lVar14) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000220 + lVar14) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000230 + lVar14) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000240 + lVar14) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000250 + lVar14) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00000260 + lVar14) = ZEXT816(0);
                *(undefined8 *)(&stack0x00000270 + lVar14) = 0;
                *(undefined (*) [16])(&stack0x00000200 + lVar14) = ZEXT816(0);
                *(undefined2 *)(&stack0x00000210 + lVar14) = 0xffff;
                *(undefined8 *)(&stack0x00000218 + lVar14) = 0;
                *(undefined4 *)(&stack0x00000214 + lVar14) = 0;
                *(undefined8 *)(&stack0x0000022e + lVar14) = 0;
                *(undefined8 *)(&stack0x00000238 + lVar14) = 0;
                *(undefined8 *)(&stack0x00000220 + lVar14) = 0;
                *(undefined8 *)(&stack0x00000248 + lVar14) = 0;
                *(undefined8 *)(&stack0x00000260 + lVar14) = 0;
                *(undefined4 *)(&stack0x00000268 + lVar14) = 0;
                *(undefined2 *)(&stack0x00000272 + lVar14) = 0;
                ppbVar20 = (byte **)(&stack0x00000200 + lVar14);
              }
              if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x000000d0 + lVar14) = *(undefined8 *)(lVar15 + 0x28);
                sVar10 = *(short *)(lVar15 + 0x30);
                *(short *)(&stack0x000000d8 + lVar14) = sVar10;
              }
              else {
                cVar7 = *(char *)(lVar15 + 1);
                if (cVar7 == '\v') {
                  if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
                    if (cVar7 != '\t') goto LAB_;
                    goto LAB_;
                  }
                }
                else {
                  if (cVar7 != '\b') goto LAB_;
LAB_:
                  if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
                }
                *(undefined4 *)(&stack0x00000100 + lVar14) = *(undefined4 *)(lVar15 + 0x20);
                *(undefined2 *)(&stack0x00000104 + lVar14) = *(undefined2 *)(lVar15 + 0x24);
                *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102619;
                cVar7 = func_0x(&stack0x00000100 + lVar14);
                if (cVar7 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10262c;
                func_0x(lVar15,&stack0x000000d0 + lVar14);
                sVar10 = *(short *)(&stack0x000000d8 + lVar14);
              }
              iVar13 = *(int *)(&stack0x000000d0 + lVar14);
              iVar12 = (int)((ulonglong)*(undefined8 *)(&stack0x000000d0 + lVar14) >> 0x20);
              if (((((pbVar31 != *ppbVar20) || (sVar10 != *(short *)(ppbVar20 + 0xd))) ||
                   (iVar13 != *(int *)(ppbVar20 + 0xc))) ||
                  ((iVar12 != *(int *)((longlong)ppbVar20 + 100) ||
                   (*(int *)(lVar15 + 0x20) != *(int *)((longlong)ppbVar20 + 0x6c))))) ||
                 (*(short *)(lVar15 + 0x24) != *(short *)(ppbVar20 + 0xe))) {
                *ppbVar20 = pbVar31;
                *(int *)(ppbVar20 + 0xc) = iVar13;
                *(int *)((longlong)ppbVar20 + 100) = iVar12;
                *(short *)(ppbVar20 + 0xd) = sVar10;
                *(undefined4 *)((longlong)ppbVar20 + 0x6c) = *(undefined4 *)(lVar15 + 0x20);
                *(undefined2 *)(ppbVar20 + 0xe) = *(undefined2 *)(lVar15 + 0x24);
                *(undefined2 *)((longlong)ppbVar20 + 0x72) = 0;
                bVar8 = *pbVar31;
                *(undefined4 *)(&stack0x00000050 + lVar14) =
                     *(undefined4 *)((ulonglong)bVar8 * 6 + 0x155bf40);
                uVar38 = (ulonglong)*(short *)((ulonglong)bVar8 * 6 + 0x155bf44);
                *(undefined2 *)(ppbVar20 + 2) = 0xffff;
                ppbVar20[3] = (byte *)0x0;
                *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
                *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
                ppbVar20[7] = (byte *)0x0;
                ppbVar20[4] = (byte *)0x0;
                ppbVar20[9] = (byte *)0x0;
                ppbVar20[10] = (byte *)0x0;
                *(undefined2 *)(ppbVar20 + 0xb) = 0;
                if ((**ppbVar20 & 2) != 0) {
                  pbVar1 = pbVar31 + uVar38;
                  if ((*pbVar1 & 1) == 0) {
                    *(undefined2 *)(ppbVar20 + 2) = 0;
                    ppbVar20[3] = pbVar1;
                    *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
                    *(undefined4 *)((longlong)ppbVar20 + 0x36) = 0;
                    uVar22 = uVar11;
                    switch(*pbVar1 & 0xe) {
                    default:
                      uVar22 = (uint)*(ushort *)(pbVar1 + 2);
                      if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1028e2;
                        func_0x(pbVar1,6);
                      }
                      break;
                    case 4:
                      uVar22 = 9;
                      break;
                    case 6:
                    case 10:
                      break;
                    case 0xe:
                      uVar22 = 1;
                    }
                    *(uint *)(ppbVar20 + 4) = uVar22;
                    *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
                  }
                  else {
                    *(undefined2 *)(ppbVar20 + 2) = 1;
                    ppbVar20[3] = pbVar1;
                    bVar8 = *pbVar1;
                    switch(bVar8 & 0x1c) {
                    default:
                      if ((char)pbVar1[1] < '\0') {
                        uVar21 = *(ushort *)(pbVar1 + 1);
                        *(ushort *)((longlong)ppbVar20 + 0x12) = uVar21;
                        sVar10 = 3;
                        uVar21 = (uVar21 & 0x7f) << 8 | uVar21 >> 8;
                      }
                      else {
                        sVar10 = 2;
                        uVar21 = (ushort)pbVar1[1];
                      }
                      *(ushort *)((longlong)ppbVar20 + 0x12) = uVar21;
                      *(short *)(ppbVar20 + 5) = sVar10;
                      uVar21 = *(ushort *)((longlong)ppbVar20 + 0x12);
                      *(short *)((longlong)ppbVar20 + 0x2c) = (short)(uVar21 + 1 >> 1) + sVar10;
                      if (uVar21 < 0x1f) {
                        *(undefined2 *)((longlong)ppbVar20 + 0x2a) = 0;
                        *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
                        *(undefined4 *)(ppbVar20 + 8) = 0;
                        ppbVar20[7] = (byte *)0x0;
                        ppbVar20[4] = (byte *)0x0;
                      }
                      else {
                        iVar13 = uVar21 - 1;
                        *(short *)((longlong)ppbVar20 + 0x2a) =
                             ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                             (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
                        *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
                        *(undefined4 *)(ppbVar20 + 8) = 0;
                        ppbVar20[7] = (byte *)0x0;
                        ppbVar20[4] = (byte *)0x0;
                      }
                      break;
                    case 4:
                      if (((bVar8 & 0x1c) != 4) || (uVar22 = 1, (bVar8 & 2) == 0)) {
                        uVar22 = uVar11;
                      }
                      if (uVar22 == 0) {
                        uVar34 = 1;
                      }
                      else {
                        *(undefined4 *)(ppbVar20 + 8) = 0;
                        uVar34 = 0xf;
                      }
                      ppbVar20[5] = (byte *)0x0;
                      *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
                      ppbVar20[6] = (byte *)0x0;
                      ppbVar20[4] = (byte *)0x0;
                      ppbVar20[7] = (byte *)0x0;
                      ppbVar20[3] = pbVar1;
                      *(undefined4 *)((longlong)ppbVar20 + 0x14) = uVar34;
                      *(uint *)(ppbVar20 + 8) = (uint)(uVar22 != 0);
                      ppbVar20[7] = (byte *)0x0;
                      ppbVar20[4] = (byte *)0x0;
                      break;
                    case 8:
                      ppbVar20[5] = (byte *)0x0;
                      *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
                      ppbVar20[6] = (byte *)0x0;
                      ppbVar20[4] = (byte *)0x0;
                      ppbVar20[7] = (byte *)0x0;
                      ppbVar20[3] = pbVar1;
                      *(undefined4 *)((longlong)ppbVar20 + 0x14) = 9;
                      *(undefined4 *)(ppbVar20 + 8) = 0;
                      ppbVar20[7] = (byte *)0x0;
                      ppbVar20[4] = (byte *)0x0;
                    }
                  }
                }
                if ((**ppbVar20 & 4) != 0) {
                  if (*(short *)(&stack0x00000052 + lVar14) != 0) {
                    uVar38 = (ulonglong)
                             *(ushort *)
                              (lVar15 + 0x61 + (longlong)*(short *)(&stack0x00000052 + lVar14) * 2);
                  }
                  psVar17 = (short *)(pbVar31 + uVar38);
                  ppbVar20[9] = (byte *)psVar17;
                  sVar10 = *psVar17;
                  ppbVar20[10] = (byte *)(psVar17 + 1);
                  *(short *)(ppbVar20 + 0xb) = (sVar10 + 1) * 2;
                }
                pbVar31 = ppbVar20[1];
                if (pbVar31 != (byte *)0x0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10296e;
                  func_0x(pbVar31,ppbVar20);
                }
              }
            }
            uVar21 = *(ushort *)(lVar15 + 0xe);
            pbVar31 = (byte *)((ulonglong)*(ushort *)(lVar15 + (0xfff - uVar39) * 2) + lVar15);
            bVar8 = *pbVar31;
            *(byte **)(&stack0x000001d0 + lVar14) = pbVar31;
            ppbVar30 = ppbVar23;
            if ((bVar8 & 1) == 0) {
              *(undefined2 *)(&stack0x000001c8 + lVar14) = 0;
              *(undefined4 *)(&stack0x000001cc + lVar14) = 0;
              *(undefined4 *)(&stack0x000001ee + lVar14) = 0;
              uVar22 = (uint)uVar21;
              switch(*pbVar31 & 0xe) {
              default:
                uVar21 = *(ushort *)(pbVar31 + 2);
                ppbVar30 = (byte **)0x0;
                uVar22 = (uint)uVar21;
                if (0x1f9d < uVar21 - 1) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102bb5;
                  func_0x(pbVar31,6);
                  pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                  ppbVar30 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                  uVar22 = (uint)uVar21;
                }
                break;
              case 4:
                uVar22 = 9;
                ppbVar30 = (byte **)0x0;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar22 = 1;
              }
              *(uint *)(&stack0x000001d8 + lVar14) = uVar22;
              ppbVar20 = (byte **)(lVar15 + 0x2000);
              if (lVar15 == 0) {
                ppbVar20 = ppbVar23;
              }
              *(byte ***)(&stack0x000001e6 + lVar14) = ppbVar20;
              ppbVar20 = (byte **)(ulonglong)uVar22;
            }
            else {
              *(undefined2 *)(&stack0x000001c8 + lVar14) = 1;
              bVar8 = *pbVar31;
              switch(bVar8 & 0x1c) {
              default:
                if ((char)pbVar31[1] < '\0') {
                  *(ushort *)(&stack0x000001ca + lVar14) =
                       (*(ushort *)(pbVar31 + 1) & 0x7f) << 8 | *(ushort *)(pbVar31 + 1) >> 8;
                  sVar10 = 3;
                  *(undefined2 *)(&stack0x000001e0 + lVar14) = 3;
                }
                else {
                  *(ushort *)(&stack0x000001ca + lVar14) = (ushort)pbVar31[1];
                  sVar10 = 2;
                  *(undefined2 *)(&stack0x000001e0 + lVar14) = 2;
                }
                uVar21 = *(ushort *)(&stack0x000001ca + lVar14);
                *(short *)(&stack0x000001e4 + lVar14) = (short)(uVar21 + 1 >> 1) + sVar10;
                if (uVar21 < 0x1f) {
                  *(undefined2 *)(&stack0x000001e2 + lVar14) = 0;
                  *(undefined4 *)(&stack0x000001cc + lVar14) = 0;
                  *(undefined4 *)(&stack0x000001f8 + lVar14) = 0;
                }
                else {
                  iVar13 = uVar21 - 1;
                  *(short *)(&stack0x000001e2 + lVar14) =
                       ((short)(iVar13 / 0x1e) + (short)(iVar13 >> 0x1f)) -
                       (short)((longlong)iVar13 * 0x88888889 >> 0x3f);
                  ppbVar30 = (byte **)0x0;
                  *(undefined4 *)(&stack0x000001cc + lVar14) = 0;
                  *(undefined4 *)(&stack0x000001f8 + lVar14) = 0;
                }
                break;
              case 4:
                if (((bVar8 & 0x1c) == 4) && ((bVar8 & 2) != 0)) {
                  *(undefined8 *)(&stack0x000001e0 + lVar14) = 0;
                  *(undefined2 *)(&stack0x000001ca + lVar14) = 0;
                  *(undefined8 *)(&stack0x000001e8 + lVar14) = 0;
                  ppbVar30 = (byte **)0xf;
                  *(undefined4 *)(&stack0x000001cc + lVar14) = 0xf;
                  *(undefined4 *)(&stack0x000001f8 + lVar14) = 1;
                }
                else {
                  *(undefined8 *)(&stack0x000001e0 + lVar14) = 0;
                  *(undefined2 *)(&stack0x000001ca + lVar14) = 0;
                  *(undefined8 *)(&stack0x000001e8 + lVar14) = 0;
                  ppbVar30 = (byte **)0x1;
                  *(undefined4 *)(&stack0x000001cc + lVar14) = 1;
                  *(undefined4 *)(&stack0x000001f8 + lVar14) = 0;
                }
                break;
              case 8:
                *(undefined8 *)(&stack0x000001e0 + lVar14) = 0;
                *(undefined2 *)(&stack0x000001ca + lVar14) = 0;
                *(undefined8 *)(&stack0x000001e8 + lVar14) = 0;
                ppbVar30 = (byte **)0x9;
                *(undefined4 *)(&stack0x000001cc + lVar14) = 9;
                *(undefined4 *)(&stack0x000001f8 + lVar14) = 0;
              }
              ppbVar19 = (byte **)(lVar15 + 0x2000);
              if (lVar15 == 0) {
                ppbVar19 = ppbVar23;
              }
              *(byte ***)(&stack0x000001f0 + lVar14) = ppbVar19;
              *(byte ***)(&stack0x000001d8 + lVar14) = ppbVar20;
            }
            uVar22 = (uint)ppbVar30;
            if (*(short *)(&stack0x000001c8 + lVar14) == 0) {
              if (uVar22 == 0) {
                *(undefined2 *)(&stack0x000001ca + lVar14) = 0;
                *(uint *)(&stack0x000001dc + lVar14) = *(uint *)(&stack0x000001d8 + lVar14);
                bVar8 = *pbVar31;
                *(int *)(&stack0x000001dc + lVar14) = (int)ppbVar20;
                if ((bVar8 & 0x10) != 0) {
                  uVar22 = uVar11;
                  if ((*pbVar31 & 0x10) != 0) {
                    uVar22 = (uint)*(ushort *)(pbVar31 + *(uint *)(&stack0x000001d8 + lVar14));
                  }
                  uVar22 = (int)ppbVar20 + 2 + (uVar22 + 7 >> 3);
                  ppbVar20 = (byte **)(ulonglong)uVar22;
                  *(uint *)(&stack0x000001dc + lVar14) = uVar22;
                }
                if ((*pbVar31 & 0x20) == 0) {
                  ppbVar30 = (byte **)((ulonglong)ppbVar20 & 0xffffffff);
                  *(int *)(&stack0x000001cc + lVar14) = (int)ppbVar20;
                  *(undefined2 *)(&stack0x000001e4 + lVar14) = 0;
                  *(int *)(&stack0x000001e0 + lVar14) = (int)ppbVar20;
                }
                else {
                  puVar40 = (ushort *)(pbVar31 + ((ulonglong)ppbVar20 & 0xffffffff));
                  uVar21 = *puVar40;
                  *(ushort *)(&stack0x000001e4 + lVar14) = uVar21;
                  if (uVar21 == 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102cc3;
                    cVar7 = func_0x(0x1e726f0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102ccc;
                      lVar27 = func_0x();
                      if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102ce6;
                        cVar7 = func_0x(0x1e726f0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102d02;
                          (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar14) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102d26;
                          (*_DAT_)(1,0x17620fc,0x18821e8,0x80f);
                        }
                      }
                    }
                    uVar18 = *(undefined8 *)(&stack0x000001d0 + lVar14);
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102d37;
                    func_0x(uVar18,3);
                    uVar21 = *(ushort *)(&stack0x000001e4 + lVar14);
                    ppbVar20 = (byte **)(ulonglong)*(uint *)(&stack0x000001dc + lVar14);
                    pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                  }
                  uVar22 = (int)ppbVar20 + (uVar21 + 1) * 2;
                  *(uint *)(&stack0x000001e0 + lVar14) = uVar22;
                  if (0x1f9e < uVar22) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102d76;
                    cVar7 = func_0x(0x1e726f0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102d7f;
                      lVar27 = func_0x();
                      if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102d99;
                        cVar7 = func_0x(0x1e726f0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102db5;
                          (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar14) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102dd9;
                          (*_DAT_)(1,0x17620fc,0x18821e8,0x816);
                        }
                      }
                    }
                    uVar18 = *(undefined8 *)(&stack0x000001d0 + lVar14);
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102dea;
                    func_0x(uVar18,4);
                    uVar21 = *(ushort *)(&stack0x000001e4 + lVar14);
                    uVar22 = *(uint *)(&stack0x000001e0 + lVar14);
                    ppbVar20 = (byte **)(ulonglong)*(uint *)(&stack0x000001dc + lVar14);
                    pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                  }
                  uVar39 = (ulonglong)uVar21;
                  uVar28 = puVar40[uVar39] & 0x7fff;
                  *(uint *)(&stack0x000001cc + lVar14) = uVar28;
                  if (uVar28 < uVar22) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102e30;
                    cVar7 = func_0x(0x1e726f0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102e39;
                      lVar27 = func_0x();
                      if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102e53;
                        cVar7 = func_0x(0x1e726f0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102e6f;
                          (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar14) = 0;
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102e93;
                          (*_DAT_)(1,0x17620fc,0x18821e8,0x81d);
                        }
                      }
                    }
                    uVar18 = *(undefined8 *)(&stack0x000001d0 + lVar14);
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102ea4;
                    func_0x(uVar18,4);
                    uVar39 = (ulonglong)*(ushort *)(&stack0x000001e4 + lVar14);
                    uVar22 = *(uint *)(&stack0x000001e0 + lVar14);
                    ppbVar20 = (byte **)(ulonglong)*(uint *)(&stack0x000001dc + lVar14);
                    pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                    uVar28 = *(uint *)(&stack0x000001cc + lVar14);
                  }
                  ppbVar30 = (byte **)(ulonglong)uVar28;
                  ppbVar19 = ppbVar23;
                  puVar6 = puVar40;
                  if ((short)uVar39 != 0) {
                    do {
                      uVar28 = puVar6[1] & 0x7fff;
                      if ((uVar28 < uVar22) || ((uint)ppbVar30 < uVar28)) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102f03;
                        cVar7 = func_0x(0x1e726f0);
                        if (cVar7 != '\0') {
                          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102f0c;
                          lVar15 = func_0x();
                          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102f26;
                            cVar7 = func_0x(0x1e726f0);
                            if (cVar7 == '\0') {
                              *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102f42;
                              (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar14) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102f66;
                              (*_DAT_)(1,0x17620fc,0x18821e8,0x82a);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(&stack0x000001d0 + lVar14);
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x102f75;
                        func_0x(uVar18,4);
                        uVar39 = (ulonglong)*(ushort *)(&stack0x000001e4 + lVar14);
                        pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                        ppbVar30 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                      }
                      uVar35 = (int)ppbVar19 + 1;
                      ppbVar19 = (byte **)(ulonglong)uVar35;
                      puVar6 = puVar6 + 1;
                      uVar22 = uVar28;
                    } while ((int)uVar35 < (int)uVar39);
                    lVar15 = *(longlong *)(&stack0x00000028 + lVar14);
                    uVar22 = *(uint *)(&stack0x000001e0 + lVar14);
                    ppbVar20 = (byte **)(ulonglong)*(uint *)(&stack0x000001dc + lVar14);
                  }
                  while( true ) {
                    sVar10 = (short)uVar39;
                    if (-1 < (short)puVar40[(ulonglong)((int)uVar39 - 1) + 1]) break;
                    uVar28 = uVar22;
                    if ((int)uVar39 != 1) {
                      uVar28 = *(ushort *)
                                (pbVar31 + uVar39 * 2 + (((ulonglong)ppbVar20 & 0xffffffff) - 2)) &
                               0x7fff;
                    }
                    uVar35 = *(ushort *)(pbVar31 + uVar39 * 2 + ((ulonglong)ppbVar20 & 0xffffffff))
                             & 0x7fff;
                    if (((uVar28 < uVar22) || (uVar35 < uVar28)) || ((uint)ppbVar30 < uVar35)) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10300a;
                      func_0x(pbVar31,7);
                      sVar10 = *(short *)(&stack0x000001e4 + lVar14);
                      uVar22 = *(uint *)(&stack0x000001e0 + lVar14);
                      ppbVar20 = (byte **)(ulonglong)*(uint *)(&stack0x000001dc + lVar14);
                      pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                      ppbVar30 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                    }
                    if ((uVar28 < uVar22) || ((uint)ppbVar30 < uVar28)) goto code_r0x001033ed;
                    if (*(ushort *)(pbVar31 + uVar28) == 5) {
                      *(ushort *)(&stack0x000001ca + lVar14) =
                           *(ushort *)(&stack0x000001ca + lVar14) | 2;
                      *(short *)(&stack0x000001e4 + lVar14) = sVar10 + -1;
                      uVar39 = (ulonglong)(uVar28 & 0xffff);
                      *(short *)(&stack0x000001f2 + lVar14) = (short)uVar28;
                      pbVar1 = pbVar31 + uVar39;
                      uVar21 = *(ushort *)(&stack0x000001f4 + lVar14);
                      if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                        uVar21 = uVar21 & 0xc7ff;
                      }
                      else {
                        uVar21 = uVar21 ^ (*(ushort *)(pbVar1 + 2) ^ uVar21) & 0x3800;
                      }
                      *(ushort *)(&stack0x000001f4 + lVar14) = uVar21;
                      uVar9 = (uVar21 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar21;
                      *(ushort *)(&stack0x000001f4 + lVar14) = uVar9;
                      pbVar36 = pbVar31 + (ulonglong)((uVar21 >> 0xb & 7) * 2) + 4 + uVar39 +
                                          ((ulonglong)uVar9 & 0x7ff) * 2;
                      if (pbVar36 < pbVar1) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103129;
                        func_0x(pbVar1,0x19);
                        uVar9 = *(ushort *)(&stack0x000001f4 + lVar14);
                        uVar39 = (ulonglong)*(ushort *)(&stack0x000001f2 + lVar14);
                        pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                        ppbVar30 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                      }
                      if (uVar35 - uVar28 <
                          (((*(uint *)(&stack0x000001f4 + lVar14) & 0x7ff) * 2 - (int)uVar39) -
                          *(int *)(&stack0x000001d0 + lVar14)) + (int)pbVar36) {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10317a;
                        func_0x(pbVar31 + uVar39,0x19);
                        uVar9 = *(ushort *)(&stack0x000001f4 + lVar14);
                        uVar39 = (ulonglong)*(ushort *)(&stack0x000001f2 + lVar14);
                        pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                        ppbVar30 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                      }
                      if (((uVar9 & 0x3800) != 0) &&
                         (puVar40 = (ushort *)(pbVar31 + uVar39 + 4), ppbVar20 = ppbVar23,
                         (uVar9 & 0x3800) != 0)) {
                        do {
                          if ((uVar9 & 0x7ff) < (*puVar40 & 0x7ff)) {
                            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1031f3;
                            func_0x(pbVar31 + uVar39,0x1a);
                            uVar9 = *(ushort *)(&stack0x000001f4 + lVar14);
                            uVar39 = (ulonglong)*(ushort *)(&stack0x000001f2 + lVar14);
                            pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                          }
                          uVar22 = (int)ppbVar20 + 1;
                          puVar40 = puVar40 + 1;
                          ppbVar20 = (byte **)(ulonglong)uVar22;
                        } while ((int)uVar22 <
                                 (int)(*(uint *)(&stack0x000001f4 + lVar14) >> 0xb & 7));
                        ppbVar30 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                      }
                      break;
                    }
                    if (*(ushort *)(pbVar31 + uVar28) < 0x400) break;
                    *(ushort *)(&stack0x000001ca + lVar14) =
                         *(ushort *)(&stack0x000001ca + lVar14) | 1;
                    uVar21 = sVar10 - 1;
                    uVar39 = (ulonglong)uVar21;
                    *(ushort *)(&stack0x000001e4 + lVar14) = uVar21;
                    if (uVar21 == 0) break;
                  }
                }
                if ((*pbVar31 & 0x40) == 0) {
                  *(undefined4 *)(&stack0x000001ee + lVar14) = 0;
                }
                else {
                  *(int *)(&stack0x000001ee + lVar14) = (int)ppbVar30;
                  *(int *)(&stack0x000001cc + lVar14) = (int)ppbVar30 + 0xe;
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103268;
                  uVar18 = func_0x(&stack0x000001ca + lVar14);
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103277;
                  func_0x(uVar18,&stack0x00000150 + lVar14);
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103283;
                  iVar13 = func_0x(&stack0x00000150 + lVar14);
                  ppbVar30 = (byte **)(ulonglong)
                                      (uint)(*(int *)(&stack0x000001cc + lVar14) + iVar13);
                  *(int *)(&stack0x000001cc + lVar14) = *(int *)(&stack0x000001cc + lVar14) + iVar13
                  ;
                  pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                }
                if ((*(byte **)(&stack0x000001e6 + lVar14) != (byte *)0x0) &&
                   (*(byte **)(&stack0x000001e6 + lVar14) <
                    (byte *)((longlong)ppbVar30 + (longlong)pbVar31))) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1032ce;
                  cVar7 = func_0x(0x1e726f0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1032d7;
                    lVar27 = func_0x();
                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1032f1;
                      cVar7 = func_0x(0x1e726f0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10330d;
                        (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103331;
                        (*_DAT_)(1,0x17620fc,0x18821e8,0x886);
                      }
                    }
                  }
                  uVar18 = *(undefined8 *)(&stack0x000001d0 + lVar14);
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103342;
                  func_0x(uVar18,0x12);
                  pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                  ppbVar30 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                }
                if (0x3f3b < (int)ppbVar30 - 1U) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10336b;
                  cVar7 = func_0x(0x1e726f0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103374;
                    lVar27 = func_0x();
                    if ((lVar27 != 0) && (*(char *)(lVar27 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10338e;
                      cVar7 = func_0x(0x1e726f0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1033aa;
                        (*pcRam00000000013e0278)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar16 + lVar14) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1033ce;
                        (*_DAT_)(1,0x17620fc,0x18821e8,0x88b);
                      }
                    }
                  }
                  uVar18 = *(undefined8 *)(&stack0x000001d0 + lVar14);
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1033df;
                  func_0x(uVar18,5);
                  pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                  ppbVar30 = (byte **)(ulonglong)*(uint *)(&stack0x000001cc + lVar14);
                }
              }
code_r0x001033ed:
              uVar22 = (uint)ppbVar30;
              if (uVar22 < 9) {
                bVar8 = *pbVar31 & 0xe;
joined_r0x0010342b:
                if ((bVar8 == 0) || (bVar8 == 0xc)) {
                  uVar22 = 9;
                }
              }
            }
            else {
              if (uVar22 == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103410;
                func_0x(&stack0x000001ca + lVar14);
                pbVar31 = *(byte **)(&stack0x000001d0 + lVar14);
                uVar22 = *(uint *)(&stack0x000001cc + lVar14);
              }
              if (uVar22 < 9) {
                bVar8 = *pbVar31 & 0x1c;
                goto joined_r0x0010342b;
              }
            }
            *(uint *)(&stack0x00000030 + lVar14) = *(int *)(&stack0x00000030 + lVar14) + uVar22;
            if (*(short *)(&stack0x000001c8 + lVar14) == 0) {
              if ((*pbVar31 & 0x10) != 0) {
                uVar21 = *(ushort *)(pbVar31 + *(uint *)(&stack0x000001d8 + lVar14));
                goto code_r0x00103460;
              }
            }
            else {
              uVar21 = *(ushort *)(&stack0x000001ca + lVar14);
code_r0x00103460:
              puVar26 = &stack0xffffffffffffffc0 + lVar16 + lVar14;
              if (*(uint *)(&stack0x00000038 + lVar14) < (uint)uVar21) goto LAB_;
            }
            if (acStackX_8[lVar14] != '\0') {
              if (*(short *)(&stack0x000001c8 + lVar14) == 0) {
                bVar8 = *pbVar31 >> 6;
              }
              else {
                bVar8 = *pbVar31 >> 1;
              }
              if ((bVar8 & 1) != 0) {
                if (*(short *)(&stack0x000001c8 + lVar14) == 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1034a8;
                  func_0x();
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1034af;
                  func_0x(&stack0x000001ca + lVar14,&stack0x00000090 + lVar14);
                }
                *(int *)(&stack0x00000048 + lVar14) = *(int *)(&stack0x00000090 + lVar14);
                *(short *)(&stack0x0000004c + lVar14) = *(short *)(&stack0x00000094 + lVar14);
                lVar27 = *(longlong *)(&stack0x00000140 + lVar14);
                if ((*(short *)(lVar27 + 0x2c) != *(short *)(&stack0x00000094 + lVar14)) ||
                   (*(int *)(lVar27 + 0x28) != *(int *)(&stack0x00000090 + lVar14))) {
                  lVar27 = *(longlong *)(lVar27 + 0x30);
                  *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1034e9;
                  cVar7 = func_0x(lVar27 + 0x19c8,&stack0x00000048 + lVar14);
                  puVar26 = &stack0xffffffffffffffc0 + lVar16 + lVar14;
                  if (cVar7 != '\0') goto LAB_;
                }
              }
            }
            uVar34 = *(undefined4 *)((longlong)auStackX_c + lVar14 + 4);
            uVar32 = *(undefined2 *)puVar2;
            puVar40 = *(ushort **)(&stack0x00000098 + lVar14);
            *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x10350b;
            func_0x(puVar40,uVar32,&stack0x000001c8 + lVar14,uVar34);
            uVar39 = (ulonglong)*(ushort *)puVar2;
            uVar22 = *(uint *)((longlong)auStackX_c + lVar14);
          }
          uVar21 = (short)uVar39 + 1;
          uVar39 = (ulonglong)uVar21;
          *(ushort *)puVar2 = uVar21;
          bVar41 = uVar21 < (ushort)uVar22;
        }
        *(undefined2 *)(&stack0x00001850 + lVar14) = 0xffff;
        *(undefined8 *)(&stack0x00001858 + lVar14) = 0;
        *(undefined4 *)(&stack0x00001854 + lVar14) = 0;
        *(undefined8 *)(&stack0x0000186e + lVar14) = 0;
        *(undefined8 *)(&stack0x00001878 + lVar14) = 0;
        *(undefined8 *)(&stack0x00001860 + lVar14) = 0;
        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103579;
        func_0x(&stack0x00001884 + lVar14,0,0x1f9e);
        *(undefined2 *)(&stack0x00005860 + lVar14) = 0;
        *(undefined4 *)(&stack0x00005864 + lVar14) = 0;
        *(ushort **)(&stack0x00001840 + lVar14) = puVar40;
        *(uint *)(&stack0x00001848 + lVar14) = uVar22 & 0xffff;
        *(undefined4 *)(&stack0x0000184c + lVar14) = *(undefined4 *)(&stack0x00000038 + lVar14);
        *(short *)(&stack0x00003850 + lVar14) = (short)uVar22;
        *(undefined8 *)(&stack0x00003824 + lVar14) = 0;
        *(undefined2 *)(&stack0x00005868 + lVar14) = 0;
        *(undefined8 *)(&stack0x00003830 + lVar14) = 0;
        *(undefined **)(&stack0xfffffffffffffff8 + lVar16 + lVar14) = &stack0x00000300 + lVar14;
        *(uint *)(&stack0xfffffffffffffff0 + lVar16 + lVar14) = uVar22 & 0xffff;
        ppbVar20 = *(byte ***)(&stack0x00000108 + lVar14);
        *(byte ***)(&stack0xffffffffffffffe8 + lVar16 + lVar14) = ppbVar20;
        *(undefined4 *)(&stack0xffffffffffffffe0 + lVar16 + lVar14) = 0x3f3c;
        uVar34 = *(undefined4 *)(&stack0x00000030 + lVar14);
        *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x1035fc;
        iVar13 = func_0x(&stack0x00001840 + lVar14,uVar34,lVar15,&stack0x00007c80 + lVar14);
        if (iVar13 == 0) {
          uVar22 = *(uint *)((longlong)auStackX_20 + lVar14);
          puVar24 = &stack0xffffffffffffffc0 + lVar16 + lVar14;
          goto code_r0x00103609;
        }
        param_2 = *(longlong ***)((longlong)&plStackX_18 + lVar14);
        uVar34 = *(undefined4 *)((longlong)auStackX_20 + lVar14);
      }
      else {
        lVar15 = *(longlong *)(&stack0x00000028 + lVar14);
      }
      puVar26 = &stack0xffffffffffffffc0 + lVar16 + lVar14;
      if (*(int *)((longlong)auStackX_c + lVar14 + 4) != 0) {
        if (param_2 == (longlong **)0x0) {
          *(undefined2 *)(lVar15 + 0x61) = 0;
          puVar26 = &stack0xffffffffffffffc0 + lVar16 + lVar14;
        }
        else {
          *(undefined4 *)(&stack0xffffffffffffffe0 + lVar16 + lVar14) = uVar34;
          *(undefined8 *)((longlong)&uStack_48 + lVar16 + lVar14) = 0x103718;
          func_0x(param_2);
          puVar26 = &stack0xffffffffffffffc0 + lVar16 + lVar14;
        }
      }
    }
    else {
      uVar21 = uVar21 >> 2;
      if (uVar21 < 2) {
        uVar21 = 1;
      }
      else if (100 < (*(uint *)((longlong)auStackX_c + lVar14) & 0xfffc)) {
        uVar21 = 0x19;
      }
      puVar26 = &stack0xffffffffffffffc0 + lVar14;
      if (uVar21 <= *(ushort *)(lVar15 + 0x61)) {
        if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x000000a0 + lVar14) = *(undefined8 *)(lVar15 + 0x28);
          uVar32 = *(undefined2 *)(lVar15 + 0x30);
          *(undefined2 *)(&stack0x000000a8 + lVar14) = uVar32;
        }
        else {
          cVar7 = *(char *)(lVar15 + 1);
          if (cVar7 == '\v') {
            if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
              if (cVar7 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar7 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
          }
          *(undefined4 *)(&stack0x000000f0 + lVar14) = *(undefined4 *)(lVar15 + 0x20);
          *(undefined2 *)(&stack0x000000f4 + lVar14) = *(undefined2 *)(lVar15 + 0x24);
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1019dd;
          cVar7 = func_0x(&stack0x000000f0 + lVar14);
          if (cVar7 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x1019f0;
          func_0x(lVar15,&stack0x000000a0 + lVar14);
          uVar32 = *(undefined2 *)(&stack0x000000a8 + lVar14);
        }
        pbVar31 = (byte *)(lVar15 + 0x60);
        *(byte **)(&stack0x00000280 + lVar14) = pbVar31;
        *(undefined4 *)(&stack0x000002e0 + lVar14) = *(undefined4 *)(&stack0x000000a0 + lVar14);
        *(int *)(&stack0x000002e4 + lVar14) =
             (int)((ulonglong)*(undefined8 *)(&stack0x000000a0 + lVar14) >> 0x20);
        *(undefined2 *)(&stack0x000002e8 + lVar14) = uVar32;
        *(undefined4 *)(&stack0x000002ec + lVar14) = *(undefined4 *)(lVar15 + 0x20);
        *(undefined2 *)(&stack0x000002f0 + lVar14) = *(undefined2 *)(lVar15 + 0x24);
        *(undefined2 *)(&stack0x000002f2 + lVar14) = 0;
        bVar8 = *pbVar31;
        *(undefined4 *)(&stack0x00000048 + lVar14) =
             *(undefined4 *)((ulonglong)bVar8 * 6 + 0x155bf40);
        uVar39 = (ulonglong)*(short *)((ulonglong)bVar8 * 6 + 0x155bf44);
        *(undefined2 *)(&stack0x00000290 + lVar14) = 0xffff;
        *(undefined8 *)(&stack0x00000298 + lVar14) = 0;
        *(undefined4 *)(&stack0x00000294 + lVar14) = 0;
        *(undefined8 *)(&stack0x000002ae + lVar14) = 0;
        *(undefined8 *)(&stack0x000002b8 + lVar14) = 0;
        *(undefined8 *)(&stack0x000002a0 + lVar14) = 0;
        *(undefined8 *)(&stack0x000002c8 + lVar14) = 0;
        *(undefined8 *)(&stack0x000002d0 + lVar14) = 0;
        *(undefined2 *)(&stack0x000002d8 + lVar14) = 0;
        if ((*pbVar31 & 2) != 0) {
          pbVar1 = pbVar31 + uVar39;
          bVar8 = *pbVar1;
          *(byte **)(&stack0x00000298 + lVar14) = pbVar1;
          if ((bVar8 & 1) == 0) {
            *(undefined2 *)(&stack0x00000290 + lVar14) = 0;
            *(undefined4 *)(&stack0x000002b6 + lVar14) = 0;
            uVar22 = uVar11;
            switch(*pbVar1 & 0xe) {
            default:
              uVar22 = (uint)*(ushort *)(pbVar1 + 2);
              if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101cb8;
                func_0x(pbVar1,6);
              }
              break;
            case 4:
              uVar22 = 9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar22 = 1;
            }
            *(uint *)(&stack0x000002a0 + lVar14) = uVar22;
          }
          else {
            *(undefined2 *)(&stack0x00000290 + lVar14) = 1;
            bVar8 = *pbVar1;
            switch(bVar8 & 0x1c) {
            default:
              if ((char)pbVar1[1] < '\0') {
                uVar21 = (*(ushort *)(pbVar1 + 1) & 0x7f) << 8 | *(ushort *)(pbVar1 + 1) >> 8;
                *(ushort *)(&stack0x00000292 + lVar14) = uVar21;
                uVar32 = 3;
                sVar10 = 3;
              }
              else {
                uVar21 = (ushort)pbVar1[1];
                *(ushort *)(&stack0x00000292 + lVar14) = uVar21;
                uVar32 = 2;
                sVar10 = 2;
              }
              *(undefined2 *)(&stack0x000002a8 + lVar14) = uVar32;
              *(short *)(&stack0x000002ac + lVar14) = (short)(uVar21 + 1 >> 1) + sVar10;
              if (uVar21 < 0x1f) {
                *(undefined2 *)(&stack0x000002aa + lVar14) = 0;
                *(undefined4 *)(&stack0x000002c0 + lVar14) = 0;
              }
              else {
                *(short *)(&stack0x000002aa + lVar14) = (short)((int)(uVar21 - 1) / 0x1e);
                *(undefined4 *)(&stack0x000002c0 + lVar14) = 0;
              }
              break;
            case 4:
              if (((bVar8 & 0x1c) == 4) && ((bVar8 & 2) != 0)) {
                *(undefined4 *)(&stack0x000002a8 + lVar14) = 0;
                *(undefined2 *)(&stack0x00000292 + lVar14) = 0;
                *(undefined2 *)(&stack0x000002ac + lVar14) = 0;
                *(undefined2 *)(&stack0x000002b6 + lVar14) = 0;
                *(undefined4 *)(&stack0x00000294 + lVar14) = 0xf;
                *(undefined4 *)(&stack0x000002c0 + lVar14) = 1;
              }
              else {
                *(undefined4 *)(&stack0x000002a8 + lVar14) = 0;
                *(undefined2 *)(&stack0x00000292 + lVar14) = 0;
                *(undefined2 *)(&stack0x000002ac + lVar14) = 0;
                *(undefined2 *)(&stack0x000002b6 + lVar14) = 0;
                *(undefined4 *)(&stack0x00000294 + lVar14) = 1;
                *(undefined4 *)(&stack0x000002c0 + lVar14) = 0;
              }
              break;
            case 8:
              *(undefined4 *)(&stack0x000002a8 + lVar14) = 0;
              *(undefined2 *)(&stack0x00000292 + lVar14) = 0;
              *(undefined2 *)(&stack0x000002ac + lVar14) = 0;
              *(undefined2 *)(&stack0x000002b6 + lVar14) = 0;
              *(undefined4 *)(&stack0x00000294 + lVar14) = 9;
              *(undefined4 *)(&stack0x000002c0 + lVar14) = 0;
            }
          }
        }
        if ((**(byte **)(&stack0x00000280 + lVar14) & 4) != 0) {
          if (*(short *)(&stack0x0000004a + lVar14) != 0) {
            uVar39 = (ulonglong)
                     *(ushort *)
                      (lVar15 + 0x61 + (longlong)*(short *)(&stack0x0000004a + lVar14) * 2);
          }
          psVar17 = (short *)(pbVar31 + uVar39);
          *(short **)(&stack0x000002c8 + lVar14) = psVar17;
          sVar10 = *psVar17;
          *(short **)(&stack0x000002d0 + lVar14) = psVar17 + 1;
          *(short *)(&stack0x000002d8 + lVar14) = (sVar10 + 1) * 2;
        }
        if (*(longlong *)(&stack0x00000288 + lVar14) != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101d56;
          func_0x
                    (*(longlong *)(&stack0x00000288 + lVar14),&stack0x00000280 + lVar14);
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar14) = 0x101d5e;
        uVar21 = func_0x(pbVar31);
        *(uint *)(&stack0x00000030 + lVar14) = (uint)uVar21;
        param_2 = *(longlong ***)((longlong)&plStackX_18 + lVar14);
        goto LAB_;
      }
    }
  }
LAB_:
  if (*(short *)(&stack0x00000e02 + lVar14) != 0) {
    uVar18 = *(undefined8 *)(&stack0x00000e08 + lVar14);
    *(undefined8 *)(puVar26 + -8) = 0x10373d;
    (*_DAT_)(uVar18);
    uVar18 = *(undefined8 *)(&stack0x00000e10 + lVar14);
    *(undefined8 *)(puVar26 + -8) = 0x10374a;
    (*_DAT_)(uVar18);
  }
  if (*(short *)(&stack0x000003a2 + lVar14) != 0) {
    uVar18 = *(undefined8 *)(&stack0x000003a8 + lVar14);
    *(undefined8 *)(puVar26 + -8) = 0x103762;
    (*_DAT_)(uVar18);
    uVar18 = *(undefined8 *)(&stack0x000003b0 + lVar14);
    *(undefined8 *)(puVar26 + -8) = 0x10376f;
    (*_DAT_)(uVar18);
  }
LAB_:
  uVar39 = *(ulonglong *)(&stack0x0000bbc0 + lVar14);
  *(undefined8 *)(puVar26 + -8) = 0x103780;
  func_0x(uVar39 ^ (ulonglong)puVar2);
  return;
}

