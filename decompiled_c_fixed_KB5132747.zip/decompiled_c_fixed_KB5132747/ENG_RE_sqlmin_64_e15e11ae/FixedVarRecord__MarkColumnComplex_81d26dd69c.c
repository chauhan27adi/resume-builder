
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ushort *param_1,uint *param_2,int param_3)

{
  ushort *puVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  int iVar5;
  longlong lVar6;
  undefined8 *puVar7;
  ushort uVar8;
  byte *pbVar9;
  longlong lVar11;
  ulonglong uVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  ushort uVar16;
  uint uVar17;
  ushort uVar18;
  uint uVar19;
  ushort *puVar20;
  undefined8 uStackX_8;
  ulonglong uVar10;
  
  uVar13 = 0;
  if (*(int *)(param_1 + 1) == 0) {
    pbVar9 = *(byte **)(param_1 + 3);
    uVar17 = *(uint *)(param_1 + 7);
    uVar10 = (ulonglong)uVar17;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar17;
    bVar2 = *pbVar9;
    if ((bVar2 & 0x10) != 0) {
      uVar17 = uVar17 + 2 + (*(ushort *)(pbVar9 + uVar10) + 7 >> 3);
      uVar10 = (ulonglong)uVar17;
      *(uint *)(param_1 + 9) = uVar17;
      bVar2 = *pbVar9;
    }
    if ((bVar2 & 0x20) == 0) {
      *(int *)(param_1 + 1) = (int)uVar10;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = (int)uVar10;
    }
    else {
      puVar20 = (ushort *)(pbVar9 + uVar10);
      uVar4 = *puVar20;
      param_1[0xd] = uVar4;
      if (uVar4 == 0) {
        cVar3 = func_0x(0x10fcff0);
        if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
           (*(char *)(lVar6 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10fcff0);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9ec9fc,0xb0cae8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar10 = (ulonglong)*(uint *)(param_1 + 9);
        uVar4 = param_1[0xd];
      }
      uVar17 = (int)uVar10 + (uVar4 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar17;
      if (0x1f9e < uVar17) {
        cVar3 = func_0x(0x10fcff0);
        if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
           (*(char *)(lVar6 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10fcff0);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ec9fc,0xb0cae8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar4 = param_1[0xd];
        uVar17 = *(uint *)(param_1 + 0xb);
      }
      uVar10 = (ulonglong)uVar4;
      uVar4 = puVar20[uVar10];
      *(uint *)(param_1 + 1) = uVar4 & 0x7fff;
      if ((uVar4 & 0x7fff) < uVar17) {
        cVar3 = func_0x(0x10fcff0);
        if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
           (*(char *)(lVar6 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10fcff0);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ec9fc,0xb0cae8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar17 = *(uint *)(param_1 + 0xb);
        uVar10 = (ulonglong)param_1[0xd];
      }
      puVar1 = puVar20;
      uVar19 = uVar13;
      if ((short)uVar10 != 0) {
        do {
          uVar14 = puVar1[1] & 0x7fff;
          if ((uVar14 < uVar17) || (*(uint *)(param_1 + 1) < uVar14)) {
            cVar3 = func_0x(0x10fcff0);
            if ((cVar3 != '\0') &&
               ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0')
                ))) {
              cVar3 = func_0x(0x10fcff0);
              if (cVar3 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9ec9fc,0xb0cae8,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 3),4);
          }
          uVar10 = (ulonglong)param_1[0xd];
          uVar19 = uVar19 + 1;
          puVar1 = puVar1 + 1;
          uVar17 = uVar14;
        } while ((int)uVar19 < (int)(uint)param_1[0xd]);
      }
      if ((short)puVar20[(ulonglong)((int)uVar10 - 1) + 1] < 0) {
        pbVar9 = *(byte **)(param_1 + 3);
        do {
          uVar17 = *(ushort *)(pbVar9 + uVar10 * 2 + (ulonglong)*(uint *)(param_1 + 9)) & 0x7fff;
          if ((int)uVar10 == 1) {
            uVar19 = *(uint *)(param_1 + 0xb);
            uVar14 = uVar19;
LAB_:
            if ((uVar17 < uVar19) || (*(uint *)(param_1 + 1) < uVar17)) goto LAB_;
          }
          else {
            uVar14 = *(uint *)(param_1 + 0xb);
            uVar19 = *(ushort *)(pbVar9 + uVar10 * 2 + ((ulonglong)*(uint *)(param_1 + 9) - 2)) &
                     0x7fff;
            if (uVar14 <= uVar19) goto LAB_;
LAB_:
            func_0x(pbVar9,7);
            uVar14 = *(uint *)(param_1 + 0xb);
          }
          if ((uVar19 < uVar14) || (*(uint *)(param_1 + 1) < uVar19)) goto LAB_;
          pbVar9 = *(byte **)(param_1 + 3);
          if (*(ushort *)(pbVar9 + uVar19) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = param_1[0xd] - 1;
            uVar12 = (ulonglong)(uVar19 & 0xffff);
            param_1[0x14] = (ushort)uVar19;
            uVar10 = *(ulonglong *)(param_1 + 3);
            uVar4 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(uVar12 + 2 + uVar10) >> 0xe & 1) != 0) {
              uVar4 = *(ushort *)(uVar12 + 2 + uVar10) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar4;
            uVar16 = (uVar4 ^ *(ushort *)(uVar12 + 2 + uVar10)) & 0x7ff ^ uVar4;
            param_1[0x15] = uVar16;
            uVar15 = uVar10 + 4 +
                     (ulonglong)((uVar16 & 0x7ff) * 2) + uVar12 + (uVar4 >> 0xb & 7) * 2;
            if (uVar15 < uVar12 + uVar10) {
              func_0x(uVar12 + uVar10,0x19);
              uVar16 = param_1[0x15];
              uVar12 = (ulonglong)param_1[0x14];
              uVar10 = (ulonglong)*(uint *)(param_1 + 3);
            }
            if (uVar17 - uVar19 < (((uVar16 & 0x7ff) * 2 - (int)uVar12) - (int)uVar10) + (int)uVar15
               ) {
              func_0x(uVar12 + *(longlong *)(param_1 + 3),0x19);
              uVar16 = param_1[0x15];
            }
            if (((uVar16 & 0x3800) != 0) &&
               (puVar20 = (ushort *)(*(longlong *)(param_1 + 3) + 4 + (ulonglong)param_1[0x14]),
               uVar17 = uVar13, (uVar16 & 0x3800) != 0)) {
              do {
                if ((uVar16 & 0x7ff) < (*puVar20 & 0x7ff)) {
                  func_0x((ulonglong)param_1[0x14] + *(longlong *)(param_1 + 3),0x1a);
                  uVar16 = param_1[0x15];
                }
                uVar17 = uVar17 + 1;
                puVar20 = puVar20 + 1;
              } while ((int)uVar17 < (int)(uVar16 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar9 + uVar19) < 0x400) goto LAB_;
          *param_1 = *param_1 | 1;
          uVar4 = param_1[0xd] - 1;
          param_1[0xd] = uVar4;
          if (uVar4 == 0) goto LAB_;
          uVar10 = (ulonglong)uVar4;
        } while ((short)puVar20[(ulonglong)(uVar4 - 1) + 1] < 0);
        uVar10 = (ulonglong)*(uint *)(param_1 + 1);
      }
      else {
LAB_:
        pbVar9 = *(byte **)(param_1 + 3);
        uVar10 = (ulonglong)*(uint *)(param_1 + 1);
      }
    }
    if ((*pbVar9 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar10;
      *(int *)(param_1 + 1) = (int)uVar10 + 0xe;
      puVar7 = (undefined8 *)func_0x(param_1);
      uStackX_8 = *puVar7;
      iVar5 = func_0x(&uStackX_8);
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar5;
      uVar10 = (ulonglong)*(uint *)(param_1 + 1);
    }
    iVar5 = (int)uVar10;
    if ((*(ulonglong *)(param_1 + 0xe) != 0) &&
       (*(ulonglong *)(param_1 + 0xe) < uVar10 + *(longlong *)(param_1 + 3))) {
      cVar3 = func_0x(0x10fcff0);
      if ((cVar3 != '\0') &&
         ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0')))) {
        cVar3 = func_0x(0x10fcff0);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9ec9fc,0xb0cae8,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      iVar5 = *(int *)(param_1 + 1);
    }
    if (0x3f3b < iVar5 - 1U) {
      cVar3 = func_0x(0x10fcff0);
      if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
         (*(char *)(lVar6 + 0x499) != '\0')) {
        cVar3 = func_0x(0x10fcff0);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9ec9fc,0xb0cae8,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
    }
  }
LAB_:
  uVar17 = *param_2;
  if ((uVar17 & 0xc0000000) != 0x80000000) {
    uVar17 = ~uVar17;
    puVar20 = (ushort *)((ulonglong)*(uint *)(param_1 + 9) + *(longlong *)(param_1 + 3));
    if (*puVar20 <= uVar17) {
      return;
    }
    if (param_3 != 0) {
      puVar20[(ulonglong)uVar17 + 1] = puVar20[(ulonglong)uVar17 + 1] | 0x8000;
      return;
    }
    puVar20[(ulonglong)uVar17 + 1] = puVar20[(ulonglong)uVar17 + 1] & 0x7fff;
    return;
  }
  uVar4 = param_1[0x15];
  uVar10 = (ulonglong)param_1[0x14];
  lVar11 = *(longlong *)(param_1 + 3);
  uVar18 = (ushort)(uVar17 >> 0x10) & 7;
  lVar6 = uVar10 + lVar11;
  uVar16 = uVar4 >> 0xb & 7;
  if (uVar16 == 0) {
    uVar16 = uVar4;
    if (uVar18 != (*(ushort *)(lVar6 + 2) >> 0xb & 7)) {
      return;
    }
    goto LAB_;
  }
  uVar10 = 0;
  uVar8 = 0;
  if (uVar16 == 0) {
LAB_:
    if (uVar18 < (*(ushort *)(lVar6 + 4) >> 0xb & 7)) {
      return;
    }
  }
  else {
    do {
      uVar8 = (ushort)uVar10;
      if (uVar18 <= (*(ushort *)(lVar6 + 4 + uVar10 * 2) >> 0xb & 7)) break;
      uVar8 = uVar8 + 1;
      uVar10 = (ulonglong)uVar8;
    } while (uVar8 < uVar16);
    if (uVar8 == 0) goto LAB_;
  }
  if (uVar16 <= uVar8) {
    return;
  }
  if (uVar8 != 0) {
    uVar13 = *(ushort *)(lVar6 + 2 + (ulonglong)uVar8 * 2) & 0x7ff;
  }
  uVar4 = param_1[0x15];
  lVar11 = *(longlong *)(param_1 + 3);
  uVar10 = (ulonglong)param_1[0x14];
  uVar16 = *(ushort *)(lVar6 + 4 + (ulonglong)uVar8 * 2);
LAB_:
  uVar12 = (ulonglong)((uVar4 >> 0xb & 7) * 2);
  iVar5 = (uVar16 & 0x7ff) - 1;
  do {
    uVar19 = (int)(iVar5 + uVar13) >> 1;
    uVar16 = *(ushort *)(uVar10 + lVar11 + uVar12 + 4 + (longlong)(int)uVar19 * 2);
    if (uVar16 < (ushort)uVar17) {
      uVar13 = uVar19 + 1;
    }
    else {
      if (uVar16 <= (ushort)uVar17) {
        lVar11 = (uVar4 & 0x7ff) * 2 + uVar12 + ((ulonglong)uVar19 + 2) * 2 + lVar11;
        if (param_3 == 0) {
          puVar20 = (ushort *)(lVar11 + uVar10);
          *puVar20 = *puVar20 & 0x7fff;
          return;
        }
        puVar20 = (ushort *)(lVar11 + uVar10);
        *puVar20 = *puVar20 | 0x8000;
        return;
      }
      iVar5 = uVar19 - 1;
    }
  } while ((int)uVar13 <= iVar5);
  return;
}

