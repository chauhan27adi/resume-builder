
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ushort *param_1,longlong param_2,byte param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  short sVar3;
  undefined4 uVar4;
  ushort *puVar5;
  char cVar6;
  ushort uVar7;
  int iVar8;
  undefined8 uVar9;
  ulonglong *puVar10;
  longlong lVar11;
  ushort uVar12;
  code *UNRECOVERED_JUMPTABLE;
  byte *pbVar13;
  ushort *puVar14;
  int iVar15;
  byte bVar16;
  uint uVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  uint uVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  ushort *puVar25;
  ulonglong uVar26;
  uint uVar27;
  bool bVar28;
  undefined auStack_198 [32];
  undefined8 uStack_178;
  byte **ppbStack_170;
  ulonglong uStack_168;
  undefined8 uStack_160;
  undefined4 uStack_158;
  uint uStack_150;
  int iStack_148;
  uint uStack_140;
  uint *puStack_138;
  uint uStack_130;
  undefined8 *puStack_128;
  undefined4 uStack_120;
  undefined8 uStack_118;
  undefined2 uStack_110;
  undefined4 uStack_108;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  undefined2 uStack_f0;
  byte *pbStack_e8;
  undefined4 uStack_e0;
  uint auStack_d8 [2];
  ushort *puStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  undefined8 uStack_b8;
  uint uStack_b0;
  uint uStack_ac;
  undefined8 auStack_88 [8];
  ulonglong uStack_48;
  
  uStack_b8 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_198;
  uVar27 = 0;
  sVar3 = *(short *)(param_2 + 0xa0);
  pbVar13 = *(byte **)(param_2 + 0xa8);
  uVar20 = 1;
  iVar15 = 0;
  if (sVar3 == 0) {
    uVar23 = (uint)*pbVar13;
    bVar16 = *pbVar13 & 0xe;
    if (bVar16 == 2) {
      bVar28 = (pbVar13[1] & 1) != 0;
    }
    else {
      bVar28 = false;
      if (((bVar16 - 10 & 0xf9) == 0) && (bVar28 = false, bVar16 != 0x10)) {
        bVar28 = true;
      }
    }
  }
  else {
    uVar23 = (uint)*pbVar13;
    bVar28 = ((uVar23 & 0x1c) - 4 & 0xffffffe7) == 0;
  }
  uVar22 = 9;
  bVar16 = (byte)uVar23;
  uVar21 = 9;
  pbStack_e8 = pbVar13;
  puStack_d0 = param_1;
  if (bVar28) {
    if (sVar3 == 0) goto LAB_;
    uVar24 = uVar20;
    if (((bVar16 & 0x1c) != 4) || ((uVar23 & 2) == 0)) {
      if ((uVar23 & 0x1c) != 4) {
        if ((uVar23 & 0x1c) == 0x10) {
          uVar24 = 9;
        }
        else {
          uVar24 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
        }
      }
      goto LAB_;
    }
    if ((uVar23 & 0x1c) != 4) {
      if ((uVar23 & 0x1c) == 0x10) {
        uVar24 = 9;
      }
      else {
        uVar24 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
      }
    }
  }
  else {
    if ((sVar3 != 0) || ((bVar16 & 0xe) != 8)) goto LAB_;
LAB_:
    uVar24 = *(uint *)(param_2 + 0xb0);
    if ((bVar16 & 0xe) != 0xe) {
LAB_:
      if (uVar24 < 0xe) {
        if (sVar3 == 0) {
          uVar20 = *(uint *)(param_2 + 0xb0);
        }
        else {
          bVar16 = **(byte **)(param_2 + 0xa8) & 0x1c;
          if ((bVar16 != 4) && (uVar20 = uVar22, bVar16 != 0x10)) {
            uVar20 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
          }
        }
        pbStack_e8 = *(byte **)(param_2 + 0x154);
        uStack_e0 = *(undefined4 *)(param_2 + 0x15c);
        ppbStack_170 = (byte **)(ulonglong)uVar20;
        uStack_168 = 0xe;
        uStack_178 = (undefined4 *)CONCAT44(uStack_178._4_4_,8);
        func_0x(&pbStack_e8,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,0xe73610);
      }
      else {
        uStack_b0 = *(ushort *)(pbVar13 + 0xc) & 0xf;
        if (((uStack_b0 < 2) ||
            (uVar12 = *(ushort *)(pbVar13 + 0xc) & 0xf, (ushort)(uVar12 - 3) < 4)) || (uVar12 == 8))
        {
          uVar27 = 1;
        }
        if ((param_3 == 3) == uVar27) {
          if (uStack_b0 < 9) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)*(uint *)((longlong)(int)uStack_b0 * 4 + 0x102164) - 0x1a0d470)
            ;
                    /* WARNING: Could not emulate address calculation at 0x001013a8 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          auStack_88[0] = *(undefined8 *)(pbVar13 + 4);
          lVar11 = func_0x();
          auStack_d8[0] = *(uint *)(lVar11 + 0x68);
          pbStack_e8 = (byte *)0x0;
          uStack_e0 = 0;
          uVar4 = *(undefined4 *)(param_2 + 0xd4);
          lVar11 = *(longlong *)(*(longlong *)(param_1 + 0xb4) + 8);
          LOCK();
          piVar1 = (int *)(lVar11 + 8);
          iStack_148 = *piVar1;
          *piVar1 = *piVar1 + uVar20;
          UNLOCK();
          iStack_148 = iStack_148 + 1;
          uStack_f0 = 0;
          uStack_f8 = 0;
          uStack_100 = 0;
          uStack_108 = 0;
          uStack_110 = (undefined2)uVar20;
          uStack_118 = 0;
          uStack_120 = 0;
          puStack_128 = auStack_88;
          puStack_138 = &uStack_b0;
          uStack_158 = 0x10;
          uStack_160 = CONCAT44(uStack_160._4_4_,0x2302);
          uStack_168 = uStack_168 & 0xffffffff00000000;
          ppbStack_170 = &pbStack_e8;
          uStack_178 = (undefined4 *)(param_2 + 0x60);
          uStack_150 = uVar20;
          uStack_140 = uVar20;
          uStack_130 = uVar20;
          func_0x(lVar11,auStack_d8,param_2 + 0x154,uVar4);
          func_0x(param_1,2,(undefined4 *)(param_2 + 0x60));
        }
        else {
          auStack_88[0] = *(undefined8 *)(pbVar13 + 4);
          uStack_ac = (uint)param_3;
          lVar11 = func_0x();
          auStack_d8[0] = *(uint *)(lVar11 + 0x68);
          pbStack_e8 = (byte *)0x0;
          uStack_e0 = 0;
          uVar4 = *(undefined4 *)(param_2 + 0xd4);
          lVar11 = *(longlong *)(*(longlong *)(param_1 + 0xb4) + 8);
          LOCK();
          piVar1 = (int *)(lVar11 + 8);
          iStack_148 = *piVar1;
          *piVar1 = *piVar1 + uVar20;
          UNLOCK();
          iStack_148 = iStack_148 + 1;
          puVar2 = (undefined4 *)(param_2 + 0x60);
          uStack_f0 = 0;
          uStack_f8 = 0;
          uStack_100 = 0;
          uStack_108 = 0;
          uStack_110 = (undefined2)uVar20;
          uStack_118 = 0;
          uStack_120 = 0;
          puStack_128 = auStack_88;
          puStack_138 = &uStack_b0;
          uStack_140 = 2;
          uStack_158 = 0x10;
          uStack_160 = CONCAT44(uStack_160._4_4_,0x2303);
          uStack_168 = uStack_168 & 0xffffffff00000000;
          ppbStack_170 = &pbStack_e8;
          uStack_178 = puVar2;
          uStack_150 = uVar20;
          uStack_130 = uVar20;
          func_0x(lVar11,auStack_d8,param_2 + 0x154,uVar4);
          uStack_c0 = *(undefined8 *)(pbVar13 + 4);
          if (*(longlong *)(param_1 + 0x154) != 0) {
            puVar14 = param_1 + 0xf8;
            uStack_c8._0_4_ = 0;
            uStack_c8._4_4_ = 4;
            uStack_158 = 0;
            uStack_160 = 0;
            uStack_168 = 0;
            ppbStack_170 = (byte **)((ulonglong)ppbStack_170 & 0xffffffff00000000);
            uStack_178 = (undefined4 *)0x0;
            puStack_d0 = puVar14;
            uStack_c8._0_4_ = func_0x(puVar14,4,0xffffffff);
            func_0x(*(undefined8 *)(param_1 + 0x154),&uStack_c0,*puVar2);
            func_0x(puVar14,4);
            uStack_c8 = (ulonglong)uStack_c8._4_4_ << 0x20;
          }
          func_0x(param_1,2,puVar2);
        }
      }
      goto LAB_;
    }
  }
  if (uVar24 == 1) goto LAB_;
  if (sVar3 == 0) {
    auStack_d8[0] = *(uint *)(param_2 + 0xb0);
    puVar14 = (ushort *)(param_2 + 0xa2);
    uVar20 = *(uint *)(param_2 + 0xa4);
    if (uVar20 == 0) {
      *puVar14 = 0;
      uVar20 = *(uint *)(param_2 + 0xb0);
      uVar18 = (ulonglong)uVar20;
      *(uint *)(param_2 + 0xb4) = uVar20;
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar16 = *pbVar13;
      if ((bVar16 & 0x10) != 0) {
        uVar20 = uVar20 + 2 + (*(ushort *)(pbVar13 + uVar18) + 7 >> 3);
        uVar18 = (ulonglong)uVar20;
        *(uint *)(param_2 + 0xb4) = uVar20;
        bVar16 = *pbVar13;
      }
      if ((bVar16 & 0x20) == 0) {
        *(int *)(param_2 + 0xa4) = (int)uVar18;
        *(undefined2 *)(param_2 + 0xbc) = 0;
        *(int *)(param_2 + 0xb8) = (int)uVar18;
      }
      else {
        puVar25 = (ushort *)(pbVar13 + uVar18);
        uVar12 = *puVar25;
        *(ushort *)(param_2 + 0xbc) = uVar12;
        puStack_d0 = puVar25;
        if (uVar12 == 0) {
          cVar6 = func_0x(0x14a2150);
          if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
             (*(char *)(lVar11 + 0x499) != '\0')) {
            cVar6 = func_0x(0x14a2150);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd91b5c,0xeb1c48,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),3);
          uVar18 = (ulonglong)*(uint *)(param_2 + 0xb4);
          pbVar13 = *(byte **)(param_2 + 0xa8);
          uVar12 = *(ushort *)(param_2 + 0xbc);
        }
        uVar20 = (int)uVar18 + (uVar12 + 1) * 2;
        *(uint *)(param_2 + 0xb8) = uVar20;
        if (0x1f9e < uVar20) {
          cVar6 = func_0x(0x14a2150);
          if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
             (*(char *)(lVar11 + 0x499) != '\0')) {
            cVar6 = func_0x(0x14a2150);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd91b5c,0xeb1c48,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),4);
          uVar12 = *(ushort *)(param_2 + 0xbc);
          pbVar13 = *(byte **)(param_2 + 0xa8);
          uVar20 = *(uint *)(param_2 + 0xb8);
        }
        uVar18 = (ulonglong)uVar12;
        uVar12 = puVar25[uVar18];
        *(uint *)(param_2 + 0xa4) = uVar12 & 0x7fff;
        if ((uVar12 & 0x7fff) < uVar20) {
          cVar6 = func_0x(0x14a2150);
          if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
             (*(char *)(lVar11 + 0x499) != '\0')) {
            cVar6 = func_0x(0x14a2150);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd91b5c,0xeb1c48,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),4);
          uVar20 = *(uint *)(param_2 + 0xb8);
          uVar18 = (ulonglong)*(ushort *)(param_2 + 0xbc);
          pbVar13 = *(byte **)(param_2 + 0xa8);
        }
        uVar23 = uVar27;
        if ((short)uVar18 != 0) {
          do {
            puVar25 = puVar25 + 1;
            uVar24 = *puVar25 & 0x7fff;
            if ((uVar24 < uVar20) || (*(uint *)(param_2 + 0xa4) < uVar24)) {
              cVar6 = func_0x(0x14a2150);
              if ((cVar6 != '\0') &&
                 ((lVar11 = func_0x(), lVar11 != 0 &&
                  (*(char *)(lVar11 + 0x499) != '\0')))) {
                cVar6 = func_0x(0x14a2150);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_178 = (undefined4 *)0x0;
                  (*_DAT_)(1,0xd91b5c,0xeb1c48,0x82a);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
            }
            uVar23 = uVar23 + 1;
            uVar18 = (ulonglong)*(ushort *)(param_2 + 0xbc);
            uVar20 = uVar24;
          } while ((int)uVar23 < (int)(uint)*(ushort *)(param_2 + 0xbc));
          pbVar13 = *(byte **)(param_2 + 0xa8);
          puVar25 = puStack_d0;
        }
        puVar5 = puStack_d0;
        if ((short)puVar25[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
          do {
            uVar23 = *(ushort *)(pbVar13 + uVar18 * 2 + (ulonglong)*(uint *)(param_2 + 0xb4)) &
                     0x7fff;
            if ((int)uVar18 == 1) {
              uVar24 = *(uint *)(param_2 + 0xb8);
              uVar17 = uVar24;
LAB_:
              if ((uVar23 < uVar24) || (uVar20 = *(uint *)(param_2 + 0xa4), uVar20 < uVar23))
              goto LAB_;
            }
            else {
              uVar24 = *(ushort *)
                        (pbVar13 + uVar18 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2)) & 0x7fff
              ;
              uVar17 = *(uint *)(param_2 + 0xb8);
              if (uVar17 <= uVar24) goto LAB_;
LAB_:
              func_0x(pbVar13,7);
              uVar17 = *(uint *)(param_2 + 0xb8);
              uVar20 = *(uint *)(param_2 + 0xa4);
              pbVar13 = *(byte **)(param_2 + 0xa8);
            }
            if ((uVar24 < uVar17) || (uVar20 < uVar24)) goto LAB_;
            if (*(ushort *)(pbVar13 + uVar24) == 5) {
              *puVar14 = *puVar14 | 2;
              *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
              *(short *)(param_2 + 0xca) = (short)uVar24;
              uVar18 = *(ulonglong *)(param_2 + 0xa8);
              uVar12 = *(ushort *)((ulonglong)(uVar24 & 0xffff) + 2 + uVar18);
              uVar7 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
              if ((uVar12 >> 0xe & 1) != 0) {
                uVar7 = uVar12 & 0x3800 | uVar7;
              }
              *(ushort *)(param_2 + 0xcc) = uVar7;
              uVar12 = (uVar7 ^ *(ushort *)((ulonglong)(uVar24 & 0xffff) + 2 + uVar18)) & 0x7ff ^
                       uVar7;
              *(ushort *)(param_2 + 0xcc) = uVar12;
              uVar19 = (ulonglong)*(ushort *)(param_2 + 0xca);
              uVar26 = uVar18 + 4 +
                       (ulonglong)((uVar12 & 0x7ff) * 2) + uVar19 + (uVar7 >> 0xb & 7) * 2;
              if (uVar26 < uVar19 + uVar18) {
                func_0x(uVar19 + uVar18,0x19);
                uVar12 = *(ushort *)(param_2 + 0xcc);
                uVar19 = (ulonglong)*(ushort *)(param_2 + 0xca);
                uVar18 = (ulonglong)*(uint *)(param_2 + 0xa8);
              }
              if (uVar23 - uVar24 <
                  (((uVar12 & 0x7ff) * 2 - (int)uVar19) - (int)uVar18) + (int)uVar26) {
                func_0x(uVar19 + *(longlong *)(param_2 + 0xa8),0x19);
                uVar12 = *(ushort *)(param_2 + 0xcc);
              }
              if (((uVar12 & 0x3800) != 0) &&
                 (puVar25 = (ushort *)
                            (*(longlong *)(param_2 + 0xa8) + 4 +
                            (ulonglong)*(ushort *)(param_2 + 0xca)), uVar20 = uVar27,
                 (uVar12 & 0x3800) != 0)) {
                do {
                  if ((uVar12 & 0x7ff) < (*puVar25 & 0x7ff)) {
                    func_0x((ulonglong)*(ushort *)(param_2 + 0xca) +
                                    *(longlong *)(param_2 + 0xa8),0x1a);
                    uVar12 = *(ushort *)(param_2 + 0xcc);
                  }
                  uVar20 = uVar20 + 1;
                  puVar25 = puVar25 + 1;
                } while ((int)uVar20 < (int)(uVar12 >> 0xb & 7));
              }
              pbVar13 = *(byte **)(param_2 + 0xa8);
              goto LAB_;
            }
            if (*(ushort *)(pbVar13 + uVar24) < 0x400) goto LAB_;
            *puVar14 = *puVar14 | 1;
            uVar12 = *(short *)(param_2 + 0xbc) - 1;
            *(ushort *)(param_2 + 0xbc) = uVar12;
            if (uVar12 == 0) goto LAB_;
            uVar18 = (ulonglong)uVar12;
          } while ((short)puVar5[(ulonglong)(uVar12 - 1) + 1] < 0);
          uVar18 = (ulonglong)*(uint *)(param_2 + 0xa4);
        }
        else {
LAB_:
          uVar18 = (ulonglong)*(uint *)(param_2 + 0xa4);
        }
      }
      if ((*pbVar13 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0xc6) = 0;
      }
      else {
        *(int *)(param_2 + 0xc6) = (int)uVar18;
        *(int *)(param_2 + 0xa4) = (int)uVar18 + 0xe;
        uVar9 = func_0x(puVar14);
        func_0x(uVar9,&uStack_c0);
        iVar8 = func_0x(&uStack_c0);
        *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + iVar8;
        uVar18 = (ulonglong)*(uint *)(param_2 + 0xa4);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
      uVar20 = (uint)uVar18;
      if ((*(byte **)(param_2 + 0xbe) != (byte *)0x0) &&
         (*(byte **)(param_2 + 0xbe) < pbVar13 + uVar18)) {
        cVar6 = func_0x(0x14a2150);
        if ((cVar6 != '\0') &&
           ((lVar11 = func_0x(), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))
           )) {
          cVar6 = func_0x(0x14a2150);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_178 = (undefined4 *)0x0;
            (*_DAT_)(1,0xd91b5c,0xeb1c48,0x886);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
        uVar20 = *(uint *)(param_2 + 0xa4);
      }
      if ((uVar20 == 0) || (0x3f3c < uVar20)) {
        cVar6 = func_0x(0x14a2150);
        if ((cVar6 != '\0') &&
           ((lVar11 = func_0x(), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))
           )) {
          cVar6 = func_0x(0x14a2150);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_178 = (undefined4 *)0x0;
            (*_DAT_)(1,0xd91b5c,0xeb1c48,0x88b);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 0xa8),5);
        uVar20 = *(uint *)(param_2 + 0xa4);
      }
    }
LAB_:
    if (uVar20 < 9) {
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar16 = *pbVar13;
      if (((bVar16 & 0xe) != 0) && ((bVar16 & 0xe) != 0xc)) goto LAB_;
      uVar23 = 9;
    }
    else {
LAB_:
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar16 = *pbVar13;
      uVar23 = uVar20;
    }
    if ((bVar16 & 0x40) != 0) {
      uVar23 = *(uint *)(param_2 + 0xc6);
    }
  }
  else {
    if ((uVar23 & 0x1c) == 4) {
      auStack_d8[0] = 1;
    }
    else if ((uVar23 & 0x1c) == 0x10) {
      auStack_d8[0] = 9;
    }
    else {
      auStack_d8[0] = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
    }
    uVar20 = *(uint *)(param_2 + 0xa4);
    if (uVar20 == 0) {
      func_0x(param_2 + 0xa2);
      uVar20 = *(uint *)(param_2 + 0xa4);
      if (uVar20 == 0) {
        func_0x(param_2 + 0xa2);
        uVar20 = *(uint *)(param_2 + 0xa4);
      }
    }
    if (uVar20 < 9) {
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar16 = *pbVar13;
      if (((bVar16 & 0x1c) != 0) && ((bVar16 & 0x1c) != 0xc)) goto LAB_;
      uVar23 = 9;
    }
    else {
LAB_:
      pbVar13 = *(byte **)(param_2 + 0xa8);
      bVar16 = *pbVar13;
      uVar23 = uVar20;
    }
    if ((bVar16 & 2) != 0) {
      uVar23 = *(uint *)(param_2 + 0xd0);
    }
  }
  puVar14 = (ushort *)(param_2 + 0xa2);
  if (auStack_d8[0] == uVar23) goto LAB_;
  if (*(short *)(param_2 + 0xa0) == 0) {
    if (uVar20 == 0) {
      *puVar14 = 0;
      uVar20 = *(uint *)(param_2 + 0xb0);
      uVar18 = (ulonglong)uVar20;
      *(uint *)(param_2 + 0xb4) = uVar20;
      if ((*pbVar13 & 0x10) != 0) {
        uVar20 = uVar20 + 2 + (*(ushort *)(pbVar13 + uVar18) + 7 >> 3);
        uVar18 = (ulonglong)uVar20;
        *(uint *)(param_2 + 0xb4) = uVar20;
      }
      if ((*pbVar13 & 0x20) == 0) {
        *(int *)(param_2 + 0xa4) = (int)uVar18;
        *(undefined2 *)(param_2 + 0xbc) = 0;
        *(int *)(param_2 + 0xb8) = (int)uVar18;
      }
      else {
        puVar25 = (ushort *)(pbVar13 + uVar18);
        uVar12 = *puVar25;
        *(ushort *)(param_2 + 0xbc) = uVar12;
        puStack_d0 = puVar25;
        if (uVar12 == 0) {
          cVar6 = func_0x(0x14a2150);
          if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
             (*(char *)(lVar11 + 0x499) != '\0')) {
            cVar6 = func_0x(0x14a2150);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd91b5c,0xeb1c48,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),3);
          uVar18 = (ulonglong)*(uint *)(param_2 + 0xb4);
          pbVar13 = *(byte **)(param_2 + 0xa8);
          uVar12 = *(ushort *)(param_2 + 0xbc);
        }
        uVar20 = (int)uVar18 + (uVar12 + 1) * 2;
        *(uint *)(param_2 + 0xb8) = uVar20;
        if (0x1f9e < uVar20) {
          cVar6 = func_0x(0x14a2150);
          if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
             (*(char *)(lVar11 + 0x499) != '\0')) {
            cVar6 = func_0x(0x14a2150);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd91b5c,0xeb1c48,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),4);
          uVar12 = *(ushort *)(param_2 + 0xbc);
          pbVar13 = *(byte **)(param_2 + 0xa8);
          uVar20 = *(uint *)(param_2 + 0xb8);
        }
        uVar18 = (ulonglong)uVar12;
        uVar12 = puVar25[uVar18];
        *(uint *)(param_2 + 0xa4) = uVar12 & 0x7fff;
        if ((uVar12 & 0x7fff) < uVar20) {
          cVar6 = func_0x(0x14a2150);
          if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
             (*(char *)(lVar11 + 0x499) != '\0')) {
            cVar6 = func_0x(0x14a2150);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_178 = (undefined4 *)0x0;
              (*_DAT_)(1,0xd91b5c,0xeb1c48,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 0xa8),4);
          uVar20 = *(uint *)(param_2 + 0xb8);
          uVar18 = (ulonglong)*(ushort *)(param_2 + 0xbc);
          pbVar13 = *(byte **)(param_2 + 0xa8);
        }
        uVar23 = uVar27;
        if ((short)uVar18 != 0) {
          do {
            puVar25 = puVar25 + 1;
            uVar24 = *puVar25 & 0x7fff;
            if ((uVar24 < uVar20) || (*(uint *)(param_2 + 0xa4) < uVar24)) {
              cVar6 = func_0x(0x14a2150);
              if ((cVar6 != '\0') &&
                 ((lVar11 = func_0x(), lVar11 != 0 &&
                  (*(char *)(lVar11 + 0x499) != '\0')))) {
                cVar6 = func_0x(0x14a2150);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_178 = (undefined4 *)0x0;
                  (*_DAT_)(1,0xd91b5c,0xeb1c48,0x82a);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 0xa8),4);
            }
            uVar23 = uVar23 + 1;
            uVar18 = (ulonglong)*(ushort *)(param_2 + 0xbc);
            uVar20 = uVar24;
          } while ((int)uVar23 < (int)(uint)*(ushort *)(param_2 + 0xbc));
          pbVar13 = *(byte **)(param_2 + 0xa8);
          puVar25 = puStack_d0;
        }
        puVar5 = puStack_d0;
        if ((short)puVar25[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
          do {
            uVar23 = *(ushort *)(pbVar13 + uVar18 * 2 + (ulonglong)*(uint *)(param_2 + 0xb4)) &
                     0x7fff;
            if ((int)uVar18 == 1) {
              uVar24 = *(uint *)(param_2 + 0xb8);
              uVar17 = uVar24;
LAB_:
              if ((uVar23 < uVar24) || (uVar20 = *(uint *)(param_2 + 0xa4), uVar20 < uVar23))
              goto LAB_;
            }
            else {
              uVar24 = *(ushort *)
                        (pbVar13 + uVar18 * 2 + ((ulonglong)*(uint *)(param_2 + 0xb4) - 2)) & 0x7fff
              ;
              uVar17 = *(uint *)(param_2 + 0xb8);
              if (uVar17 <= uVar24) goto LAB_;
LAB_:
              func_0x(pbVar13,7);
              uVar17 = *(uint *)(param_2 + 0xb8);
              uVar20 = *(uint *)(param_2 + 0xa4);
              pbVar13 = *(byte **)(param_2 + 0xa8);
            }
            if ((uVar24 < uVar17) || (uVar20 < uVar24)) goto LAB_;
            if (*(ushort *)(pbVar13 + uVar24) == 5) {
              *puVar14 = *puVar14 | 2;
              *(short *)(param_2 + 0xbc) = *(short *)(param_2 + 0xbc) + -1;
              *(short *)(param_2 + 0xca) = (short)uVar24;
              uVar18 = *(ulonglong *)(param_2 + 0xa8);
              uVar12 = *(ushort *)((ulonglong)(uVar24 & 0xffff) + 2 + uVar18);
              uVar7 = *(ushort *)(param_2 + 0xcc) & 0xc7ff;
              if ((uVar12 >> 0xe & 1) != 0) {
                uVar7 = uVar12 & 0x3800 | uVar7;
              }
              *(ushort *)(param_2 + 0xcc) = uVar7;
              uVar12 = (uVar7 ^ *(ushort *)((ulonglong)(uVar24 & 0xffff) + 2 + uVar18)) & 0x7ff ^
                       uVar7;
              *(ushort *)(param_2 + 0xcc) = uVar12;
              uVar19 = (ulonglong)*(ushort *)(param_2 + 0xca);
              uVar26 = (ulonglong)((uVar12 & 0x7ff) * 2) + 4 + uVar18 + (uVar7 >> 0xb & 7) * 2 +
                       uVar19;
              if (uVar26 < uVar19 + uVar18) {
                func_0x(uVar19 + uVar18,0x19);
                uVar12 = *(ushort *)(param_2 + 0xcc);
                uVar19 = (ulonglong)*(ushort *)(param_2 + 0xca);
                uVar18 = (ulonglong)*(uint *)(param_2 + 0xa8);
              }
              if (uVar23 - uVar24 <
                  (((uVar12 & 0x7ff) * 2 - (int)uVar19) - (int)uVar18) + (int)uVar26) {
                func_0x(uVar19 + *(longlong *)(param_2 + 0xa8),0x19);
                uVar12 = *(ushort *)(param_2 + 0xcc);
              }
              if (((uVar12 & 0x3800) != 0) &&
                 (puVar25 = (ushort *)
                            (*(longlong *)(param_2 + 0xa8) + 4 +
                            (ulonglong)*(ushort *)(param_2 + 0xca)), (uVar12 & 0x3800) != 0)) {
                do {
                  if ((uVar12 & 0x7ff) < (*puVar25 & 0x7ff)) {
                    func_0x((ulonglong)*(ushort *)(param_2 + 0xca) +
                                    *(longlong *)(param_2 + 0xa8),0x1a);
                    uVar12 = *(ushort *)(param_2 + 0xcc);
                  }
                  uVar27 = uVar27 + 1;
                  puVar25 = puVar25 + 1;
                } while ((int)uVar27 < (int)(uVar12 >> 0xb & 7));
              }
              pbVar13 = *(byte **)(param_2 + 0xa8);
              goto LAB_;
            }
            if (*(ushort *)(pbVar13 + uVar24) < 0x400) goto LAB_;
            *puVar14 = *puVar14 | 1;
            uVar12 = *(short *)(param_2 + 0xbc) - 1;
            *(ushort *)(param_2 + 0xbc) = uVar12;
            if (uVar12 == 0) goto LAB_;
            uVar18 = (ulonglong)uVar12;
          } while ((short)puVar5[(ulonglong)(uVar12 - 1) + 1] < 0);
          uVar18 = (ulonglong)*(uint *)(param_2 + 0xa4);
        }
        else {
LAB_:
          uVar18 = (ulonglong)*(uint *)(param_2 + 0xa4);
        }
      }
      if ((*pbVar13 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0xc6) = 0;
      }
      else {
        *(int *)(param_2 + 0xc6) = (int)uVar18;
        *(int *)(param_2 + 0xa4) = (int)uVar18 + 0xe;
        puVar10 = (ulonglong *)func_0x(puVar14);
        uVar12 = (ushort)(*puVar10 >> 0x30);
        if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
          if ((uVar12 >> 0xe & 1) == 0) {
            uVar12 = uVar12 & 0xdfff;
          }
          else {
            uVar12 = uVar12 | 0x2000;
          }
        }
        if (uVar12 == 0xfffc) {
          iVar15 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_2 + 0xa4) = *(int *)(param_2 + 0xa4) + iVar15;
        uVar18 = (ulonglong)*(uint *)(param_2 + 0xa4);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
      uVar20 = (uint)uVar18;
      if ((*(byte **)(param_2 + 0xbe) != (byte *)0x0) &&
         (*(byte **)(param_2 + 0xbe) < pbVar13 + uVar18)) {
        cVar6 = func_0x(0x14a2150);
        if ((cVar6 != '\0') &&
           ((lVar11 = func_0x(), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))
           )) {
          cVar6 = func_0x(0x14a2150);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_178 = (undefined4 *)0x0;
            (*_DAT_)(1,0xd91b5c,0xeb1c48,0x886);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 0xa8),0x12);
        uVar20 = *(uint *)(param_2 + 0xa4);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
      if ((uVar20 == 0) || (0x3f3c < uVar20)) {
        cVar6 = func_0x(0x14a2150);
        if ((cVar6 != '\0') &&
           ((lVar11 = func_0x(), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))
           )) {
          cVar6 = func_0x(0x14a2150);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_178 = (undefined4 *)0x0;
            (*_DAT_)(1,0xd91b5c,0xeb1c48,0x88b);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 0xa8),5);
        uVar20 = *(uint *)(param_2 + 0xa4);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
    }
LAB_:
    if (uVar20 < 9) {
      bVar16 = *pbVar13;
      if (((bVar16 & 0xe) != 0) && ((bVar16 & 0xe) != 0xc)) goto LAB_;
    }
    else {
LAB_:
      bVar16 = *pbVar13;
      uVar21 = uVar20;
    }
    if ((bVar16 & 0x40) != 0) {
      uVar21 = *(uint *)(param_2 + 0xc6);
    }
  }
  else {
    if (uVar20 == 0) {
      func_0x(puVar14);
      uVar20 = *(uint *)(param_2 + 0xa4);
      pbVar13 = *(byte **)(param_2 + 0xa8);
      if (uVar20 == 0) {
        func_0x(puVar14);
        uVar20 = *(uint *)(param_2 + 0xa4);
        pbVar13 = *(byte **)(param_2 + 0xa8);
      }
    }
    if ((uVar20 < 9) && (((*pbVar13 & 0x1c) == 0 || ((*pbVar13 & 0x1c) == 0xc)))) {
      uVar20 = uVar21;
    }
    uVar21 = uVar20;
    if ((*pbVar13 & 2) != 0) {
      uVar21 = *(uint *)(param_2 + 0xd0);
    }
  }
  if (*(short *)(param_2 + 0xa0) == 0) {
    uVar22 = *(uint *)(param_2 + 0xb0);
  }
  else if ((*pbVar13 & 0x1c) == 4) {
    uVar22 = 1;
  }
  else if ((*pbVar13 & 0x1c) != 0x10) {
    uVar22 = (uint)*(ushort *)(param_2 + 0xbc) + (uint)*(ushort *)(param_2 + 0xba);
  }
  pbStack_e8 = *(byte **)(param_2 + 0x154);
  uStack_e0 = *(undefined4 *)(param_2 + 0x15c);
  uStack_168 = (ulonglong)uVar21;
  ppbStack_170 = (byte **)(ulonglong)uVar22;
  uStack_178 = (undefined4 *)CONCAT44(uStack_178._4_4_,7);
  func_0x(&pbStack_e8,*(undefined4 *)(param_2 + 0xd4),param_2 + 0x60,0xe73560);
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_198);
  return;
}

