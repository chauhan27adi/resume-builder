
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,byte *param_2,undefined8 param_3,undefined4 param_4)

{
  byte *pbVar1;
  ushort *puVar2;
  byte bVar3;
  ushort *puVar4;
  undefined *puVar5;
  char cVar6;
  short sVar7;
  int iVar8;
  uint uVar9;
  longlong lVar10;
  short *psVar11;
  longlong lVar12;
  undefined8 uVar13;
  ushort uVar14;
  int iVar15;
  undefined4 uVar16;
  ulonglong uVar17;
  longlong lVar18;
  undefined2 uVar19;
  undefined8 uVar20;
  uint uVar21;
  undefined8 unaff_RBX;
  byte **ppbVar22;
  byte *pbVar23;
  ulonglong uVar24;
  undefined *puVar25;
  undefined8 unaff_RSI;
  ulonglong uVar26;
  undefined8 unaff_RDI;
  ushort uVar27;
  byte *pbVar29;
  uint uVar30;
  ushort *puVar31;
  ushort auStackX_8 [2];
  undefined4 uStackX_c;
  undefined2 auStackX_10 [2];
  uint auStackX_14 [3];
  undefined8 uStackX_20;
  undefined8 uStack_30;
  ulonglong uVar28;
  
  uStack_30 = 0x100014;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  puVar25 = &stack0xffffffffffffffd8 + lVar10;
  puVar2 = (ushort *)((longlong)auStackX_8 + lVar10);
  *(undefined8 *)(&stack0x00002270 + lVar10) = unaff_RBX;
  *(undefined8 *)(&stack0x00002278 + lVar10) = unaff_RSI;
  *(undefined8 *)(&stack0x00002280 + lVar10) = unaff_RDI;
  *(ulonglong *)(&stack0x00002228 + lVar10) = _DAT_ ^ (ulonglong)puVar2;
  uVar14 = *(ushort *)(param_1 + 0x16);
  uVar26 = (ulonglong)uVar14;
  lVar12 = 0;
  *(undefined4 *)(&stack0x00000034 + lVar10) = param_4;
  *(longlong *)(&stack0x00000098 + lVar10) = param_1;
  uVar20 = 0xffffffff;
  *(undefined2 *)(&stack0x00000048 + lVar10) = 0xffff;
  *(undefined2 *)(&stack0x00000218 + lVar10) = 0xffff;
  *(undefined2 *)(&stack0x00000108 + lVar10) = 0xffff;
  *(undefined4 *)(&stack0x0000013c + lVar10) = 0xffffffff;
  *(undefined2 *)(&stack0x000001b8 + lVar10) = 0xffff;
  *(undefined8 *)(&stack0x00000050 + lVar10) = 0;
  *(undefined4 *)(&stack0x0000004c + lVar10) = 0;
  *(undefined8 *)(&stack0x00000066 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000070 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000058 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar10) = 0;
  *puVar2 = uVar14;
  *(undefined4 *)((longlong)auStackX_14 + lVar10) = 0;
  *(undefined (*) [16])(&stack0x00000208 + lVar10) = ZEXT816(0);
  *(undefined8 *)(&stack0x00000220 + lVar10) = 0;
  *(undefined4 *)(&stack0x0000021c + lVar10) = 0;
  *(undefined8 *)(&stack0x00000236 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000240 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000228 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000250 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000268 + lVar10) = 0;
  *(undefined4 *)(&stack0x00000270 + lVar10) = 0;
  *(undefined2 *)(&stack0x0000027a + lVar10) = 0;
  *(undefined8 *)(&stack0x00000110 + lVar10) = 0;
  *(undefined4 *)(&stack0x0000010c + lVar10) = 0;
  *(undefined8 *)(&stack0x00000126 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000130 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000118 + lVar10) = 0;
  *(undefined8 *)(&stack0x000001c0 + lVar10) = 0;
  *(undefined4 *)(&stack0x000001bc + lVar10) = 0;
  *(undefined8 *)(&stack0x000001d6 + lVar10) = 0;
  *(undefined8 *)(&stack0x000001e0 + lVar10) = 0;
  *(undefined8 *)(&stack0x000001c8 + lVar10) = 0;
  *(undefined8 *)(&stack0x000001f0 + lVar10) = 0;
  *(undefined4 *)(&stack0x000001f8 + lVar10) = 0;
  if (uVar14 != 0) {
    uVar17 = uVar26 * 2 + 0xf;
    if (uVar17 <= uVar26 * 2) {
      uVar17 = 0xffffffffffffff0;
    }
    uVar17 = uVar17 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_30 + lVar10) = 0x100169;
    func_0x();
    puVar25 = &stack0xffffffffffffffd8 + -uVar17 + lVar10;
    lVar12 = (longlong)auStackX_8 + -uVar17 + lVar10;
    *(longlong *)(&stack0x00000040 + lVar10) = lVar12;
  }
  sVar7 = 3;
  if (((param_2 != (byte *)0x0) || (*(int *)(&stack0x00000274 + lVar10) != 0)) ||
     (*(short *)(&stack0x00000278 + lVar10) != 0)) {
    bVar3 = *param_2;
    *(byte **)(&stack0x00000208 + lVar10) = param_2;
    uVar30 = 0;
    *(undefined4 *)(&stack0x00000274 + lVar10) = 0;
    *(undefined2 *)(&stack0x00000278 + lVar10) = 0;
    *(undefined8 *)(&stack0x00000258 + lVar10) = 0;
    *(undefined2 *)(&stack0x00000260 + lVar10) = 0;
    lVar18 = (ulonglong)bVar3 * 6;
    uVar17 = (ulonglong)*(short *)(lVar18 + 0x1558584);
    *(undefined4 *)((longlong)&uStackX_c + lVar10) = *(undefined4 *)(lVar18 + 0x1558580);
    if ((bVar3 & 2) != 0) {
      bVar3 = param_2[uVar17];
      pbVar29 = param_2 + uVar17;
      *(byte **)(&stack0x00000220 + lVar10) = pbVar29;
      if ((bVar3 & 1) == 0) {
        *(undefined2 *)(&stack0x00000218 + lVar10) = 0;
        *(undefined4 *)(&stack0x0000023e + lVar10) = 0;
        switch(*pbVar29 & 0xe) {
        default:
          uVar30 = (uint)*(ushort *)(pbVar29 + 2);
          if (0x1f9d < *(ushort *)(pbVar29 + 2) - 1) {
            *(undefined8 *)(puVar25 + -8) = 0x1003f6;
            func_0x(pbVar29,6);
          }
          break;
        case 4:
          uVar30 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar30 = 1;
        }
        *(uint *)(&stack0x00000228 + lVar10) = uVar30;
        uVar26 = (ulonglong)*puVar2;
      }
      else {
        *(undefined2 *)(&stack0x00000218 + lVar10) = 1;
        bVar3 = *pbVar29;
        switch(bVar3 & 0x1c) {
        default:
          if ((char)pbVar29[1] < '\0') {
            uVar14 = *(ushort *)(pbVar29 + 1);
            *(undefined2 *)(&stack0x00000230 + lVar10) = 3;
            uVar14 = (uVar14 & 0x7f) << 8 | uVar14 >> 8;
            *(ushort *)(&stack0x0000021a + lVar10) = uVar14;
          }
          else {
            uVar14 = (ushort)pbVar29[1];
            *(ushort *)(&stack0x0000021a + lVar10) = uVar14;
            *(undefined2 *)(&stack0x00000230 + lVar10) = 2;
            sVar7 = 2;
          }
          *(ushort *)(&stack0x00000234 + lVar10) = ((ushort)(uVar14 + 1) >> 1) + sVar7;
          if (uVar14 < 0x1f) {
            *(undefined2 *)(&stack0x00000232 + lVar10) = 0;
            *(undefined4 *)(&stack0x00000248 + lVar10) = 0;
          }
          else {
            iVar15 = uVar14 - 1;
            *(undefined4 *)(&stack0x00000248 + lVar10) = 0;
            *(short *)(&stack0x00000232 + lVar10) =
                 ((short)(iVar15 / 0x1e) + (short)(iVar15 >> 0x1f)) -
                 (short)((longlong)iVar15 * 0x88888889 >> 0x3f);
          }
          break;
        case 4:
          if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
            *(undefined4 *)(&stack0x00000230 + lVar10) = 0;
            *(undefined2 *)(&stack0x0000021a + lVar10) = 0;
            *(undefined2 *)(&stack0x00000234 + lVar10) = 0;
            *(undefined2 *)(&stack0x0000023e + lVar10) = 0;
            *(undefined4 *)(&stack0x0000021c + lVar10) = 0xf;
            *(undefined4 *)(&stack0x00000248 + lVar10) = 1;
          }
          else {
            *(undefined4 *)(&stack0x00000230 + lVar10) = 0;
            *(undefined2 *)(&stack0x0000021a + lVar10) = 0;
            *(undefined2 *)(&stack0x00000234 + lVar10) = 0;
            *(undefined2 *)(&stack0x0000023e + lVar10) = 0;
            *(undefined4 *)(&stack0x0000021c + lVar10) = 1;
            *(undefined4 *)(&stack0x00000248 + lVar10) = 0;
          }
          break;
        case 8:
          *(undefined4 *)(&stack0x00000230 + lVar10) = 0;
          *(undefined2 *)(&stack0x0000021a + lVar10) = 0;
          *(undefined2 *)(&stack0x00000234 + lVar10) = 0;
          *(undefined2 *)(&stack0x0000023e + lVar10) = 0;
          *(undefined4 *)(&stack0x0000021c + lVar10) = 9;
          *(undefined4 *)(&stack0x00000248 + lVar10) = 0;
        }
      }
    }
    if ((**(byte **)(&stack0x00000208 + lVar10) & 4) != 0) {
      sVar7 = *(short *)((longlong)&uStackX_c + lVar10 + 2);
      if (sVar7 != 0) {
        uVar17 = (ulonglong)*(ushort *)(param_2 + (longlong)sVar7 * 2 + 1);
      }
      psVar11 = (short *)(param_2 + uVar17);
      *(short **)(&stack0x00000250 + lVar10) = psVar11;
      sVar7 = *psVar11;
      *(short **)(&stack0x00000258 + lVar10) = psVar11 + 1;
      *(short *)(&stack0x00000260 + lVar10) = (sVar7 + 1) * 2;
    }
    lVar18 = *(longlong *)(&stack0x00000210 + lVar10);
    if (lVar18 != 0) {
      *(undefined8 *)(puVar25 + -8) = 0x100493;
      func_0x(lVar18,&stack0x00000208 + lVar10);
    }
    uVar20 = 0xffffffff;
  }
  lVar18 = 0;
  uVar19 = (undefined2)uVar20;
  *(undefined4 *)((longlong)auStackX_14 + lVar10 + 4) = 0;
  uVar30 = 0;
  sVar7 = (short)uVar26;
  if (sVar7 != 0) {
    *(undefined8 *)(&stack0x00000038 + lVar10) = 0;
    do {
      ppbVar22 = (byte **)0x0;
      if ((uVar30 < *(ushort *)(param_1 + 0x16)) &&
         (*(short *)(param_1 + (0xfff - lVar18) * 2) != 0)) {
        cVar6 = *(char *)(param_1 + 2);
        *(uint *)(&stack0x0000013c + lVar10) = uVar30;
        if (cVar6 < '\0') {
          pbVar29 = (byte *)(param_1 + 0x60);
          if ((*(short *)(&stack0x00000108 + lVar10) == 0) ||
             (ppbVar22 = *(byte ***)(&stack0x00000118 + lVar10), ppbVar22 == (byte **)0x0)) {
            ppbVar22 = (byte **)(&stack0x00000140 + lVar10);
            *(undefined (*) [16])(&stack0x00000150 + lVar10) = ZEXT816(0);
            *(undefined8 *)(&stack0x000001b0 + lVar10) = 0;
            *(undefined (*) [16])(&stack0x00000160 + lVar10) = ZEXT816(0);
            *(short *)(&stack0x00000150 + lVar10) = (short)uVar20;
            *(undefined (*) [16])(&stack0x00000170 + lVar10) = ZEXT816(0);
            *(undefined8 *)(&stack0x00000158 + lVar10) = 0;
            *(undefined (*) [16])(&stack0x000001a0 + lVar10) = ZEXT816(0);
            *(undefined4 *)(&stack0x00000154 + lVar10) = 0;
            *(undefined (*) [16])(&stack0x00000180 + lVar10) = ZEXT816(0);
            *(undefined8 *)(&stack0x0000016e + lVar10) = 0;
            *(undefined8 *)(&stack0x00000178 + lVar10) = 0;
            *(undefined8 *)(&stack0x00000160 + lVar10) = 0;
            *(undefined8 *)(&stack0x00000188 + lVar10) = 0;
            *(undefined8 *)(&stack0x000001a0 + lVar10) = 0;
            *(undefined4 *)(&stack0x000001a8 + lVar10) = 0;
            *(undefined2 *)(&stack0x000001b2 + lVar10) = 0;
            *(undefined (*) [16])(&stack0x00000190 + lVar10) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000140 + lVar10) = ZEXT816(0);
          }
          if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
            sVar7 = *(short *)(param_1 + 0x30);
            *(undefined8 *)((longlong)&uStackX_20 + lVar10) = *(undefined8 *)(param_1 + 0x28);
            *(short *)(&stack0x00000028 + lVar10) = sVar7;
          }
          else {
            cVar6 = *(char *)(param_1 + 1);
            if (cVar6 == '\v') {
              if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
                if (cVar6 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar6 != '\b') goto LAB_;
LAB_:
              if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
            }
            *(undefined4 *)((longlong)&uStackX_c + lVar10) = *(undefined4 *)(param_1 + 0x20);
            *(undefined2 *)((longlong)&uStackX_c + lVar10 + 4) = *(undefined2 *)(param_1 + 0x24);
            *(undefined8 *)(puVar25 + -8) = 0x1005f4;
            cVar6 = func_0x((longlong)&uStackX_c + lVar10);
            if (cVar6 == '\0') goto LAB_;
            *(undefined8 *)(puVar25 + -8) = 0x100604;
            func_0x(param_1,(longlong)&uStackX_20 + lVar10);
            sVar7 = *(short *)(&stack0x00000028 + lVar10);
          }
          iVar15 = *(int *)((longlong)&uStackX_20 + lVar10);
          iVar8 = (int)((ulonglong)*(undefined8 *)((longlong)&uStackX_20 + lVar10) >> 0x20);
          if ((((pbVar29 != *ppbVar22) || (sVar7 != *(short *)(ppbVar22 + 0xd))) ||
              (iVar15 != *(int *)(ppbVar22 + 0xc))) ||
             (((iVar8 != *(int *)((longlong)ppbVar22 + 100) ||
               (*(int *)(param_1 + 0x20) != *(int *)((longlong)ppbVar22 + 0x6c))) ||
              (*(short *)(param_1 + 0x24) != *(short *)(ppbVar22 + 0xe))))) {
            *ppbVar22 = pbVar29;
            *(short *)(ppbVar22 + 0xd) = sVar7;
            *(int *)(ppbVar22 + 0xc) = iVar15;
            *(int *)((longlong)ppbVar22 + 100) = iVar8;
            *(undefined4 *)((longlong)ppbVar22 + 0x6c) = *(undefined4 *)(param_1 + 0x20);
            *(undefined2 *)(ppbVar22 + 0xe) = *(undefined2 *)(param_1 + 0x24);
            *(undefined2 *)((longlong)ppbVar22 + 0x72) = 0;
            uVar26 = (ulonglong)*(short *)((ulonglong)*pbVar29 * 6 + 0x1558584);
            *(undefined4 *)(&stack0x00000080 + lVar10) =
                 *(undefined4 *)((ulonglong)*pbVar29 * 6 + 0x1558580);
            *(undefined2 *)(ppbVar22 + 2) = 0xffff;
            ppbVar22[3] = (byte *)0x0;
            uVar21 = 0;
            *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
            *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
            ppbVar22[7] = (byte *)0x0;
            ppbVar22[4] = (byte *)0x0;
            ppbVar22[9] = (byte *)0x0;
            ppbVar22[10] = (byte *)0x0;
            *(undefined2 *)(ppbVar22 + 0xb) = 0;
            if ((**ppbVar22 & 2) != 0) {
              pbVar1 = pbVar29 + uVar26;
              if ((pbVar29[uVar26] & 1) == 0) {
                *(undefined2 *)(ppbVar22 + 2) = 0;
                ppbVar22[3] = pbVar1;
                *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar22 + 0x36) = 0;
                switch(*pbVar1 & 0xe) {
                default:
                  uVar21 = (uint)*(ushort *)(pbVar1 + 2);
                  if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
                    *(undefined8 *)(puVar25 + -8) = 0x1008c9;
                    func_0x(pbVar1,6);
                  }
                  break;
                case 4:
                  uVar21 = 9;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar21 = 1;
                }
                *(uint *)(ppbVar22 + 4) = uVar21;
                *(undefined8 *)((longlong)ppbVar22 + 0x2e) = 0;
              }
              else {
                *(undefined2 *)(ppbVar22 + 2) = 1;
                ppbVar22[3] = pbVar1;
                bVar3 = *pbVar1;
                switch(bVar3 & 0x1c) {
                default:
                  if ((char)pbVar1[1] < '\0') {
                    uVar14 = *(ushort *)(pbVar1 + 1);
                    sVar7 = 3;
                    *(ushort *)((longlong)ppbVar22 + 0x12) = uVar14;
                    uVar14 = (uVar14 & 0x7f) << 8 | uVar14 >> 8;
                  }
                  else {
                    sVar7 = 2;
                    uVar14 = (ushort)pbVar1[1];
                  }
                  *(ushort *)((longlong)ppbVar22 + 0x12) = uVar14;
                  *(short *)(ppbVar22 + 5) = sVar7;
                  uVar14 = *(ushort *)((longlong)ppbVar22 + 0x12);
                  *(short *)((longlong)ppbVar22 + 0x2c) = (short)(uVar14 + 1 >> 1) + sVar7;
                  if (uVar14 < 0x1f) {
                    *(undefined2 *)((longlong)ppbVar22 + 0x2a) = 0;
                    *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
                    *(undefined4 *)(ppbVar22 + 8) = 0;
                    ppbVar22[7] = (byte *)0x0;
                    ppbVar22[4] = (byte *)0x0;
                  }
                  else {
                    iVar15 = uVar14 - 1;
                    *(short *)((longlong)ppbVar22 + 0x2a) =
                         ((short)(iVar15 / 0x1e) + (short)(iVar15 >> 0x1f)) -
                         (short)((longlong)iVar15 * 0x88888889 >> 0x3f);
                    *(undefined4 *)((longlong)ppbVar22 + 0x14) = 0;
                    *(undefined4 *)(ppbVar22 + 8) = 0;
                    ppbVar22[7] = (byte *)0x0;
                    ppbVar22[4] = (byte *)0x0;
                  }
                  break;
                case 4:
                  if (((bVar3 & 0x1c) != 4) || (uVar9 = 1, (bVar3 & 2) == 0)) {
                    uVar9 = uVar21;
                  }
                  if (uVar9 == 0) {
                    uVar16 = 1;
                  }
                  else {
                    *(undefined4 *)(ppbVar22 + 8) = 0;
                    uVar16 = 0xf;
                  }
                  ppbVar22[5] = (byte *)0x0;
                  *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
                  ppbVar22[6] = (byte *)0x0;
                  ppbVar22[4] = (byte *)0x0;
                  ppbVar22[7] = (byte *)0x0;
                  ppbVar22[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar22 + 0x14) = uVar16;
                  *(uint *)(ppbVar22 + 8) = (uint)(uVar9 != 0);
                  ppbVar22[7] = (byte *)0x0;
                  ppbVar22[4] = (byte *)0x0;
                  break;
                case 8:
                  ppbVar22[7] = (byte *)0x0;
                  ppbVar22[7] = (byte *)0x0;
                  ppbVar22[5] = (byte *)0x0;
                  *(undefined2 *)((longlong)ppbVar22 + 0x12) = 0;
                  ppbVar22[6] = (byte *)0x0;
                  ppbVar22[4] = (byte *)0x0;
                  ppbVar22[3] = pbVar1;
                  *(undefined4 *)((longlong)ppbVar22 + 0x14) = 9;
                  *(undefined4 *)(ppbVar22 + 8) = 0;
                  ppbVar22[4] = (byte *)0x0;
                }
              }
            }
            if ((**ppbVar22 & 4) != 0) {
              if (*(short *)(&stack0x00000082 + lVar10) != 0) {
                uVar26 = (ulonglong)
                         *(ushort *)
                          (param_1 + 0x61 + (longlong)*(short *)(&stack0x00000082 + lVar10) * 2);
              }
              psVar11 = (short *)(pbVar29 + uVar26);
              ppbVar22[9] = (byte *)psVar11;
              sVar7 = *psVar11;
              ppbVar22[10] = (byte *)(psVar11 + 1);
              *(short *)(ppbVar22 + 0xb) = (sVar7 + 1) * 2;
            }
            pbVar29 = ppbVar22[1];
            if (pbVar29 != (byte *)0x0) {
              *(undefined8 *)(puVar25 + -8) = 0x100958;
              func_0x(pbVar29,ppbVar22);
            }
          }
        }
        uVar17 = 0;
        uVar21 = (uint)*(ushort *)(param_1 + 0xe);
        pbVar29 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - lVar18) * 2) + param_1);
        bVar3 = *pbVar29;
        *(byte **)(&stack0x00000110 + lVar10) = pbVar29;
        uVar26 = uVar17;
        if ((bVar3 & 1) == 0) {
          *(undefined2 *)(&stack0x00000108 + lVar10) = 0;
          *(undefined4 *)(&stack0x0000010c + lVar10) = 0;
          *(undefined4 *)(&stack0x0000012e + lVar10) = 0;
          switch(*pbVar29 & 0xe) {
          default:
            uVar21 = (uint)*(ushort *)(pbVar29 + 2);
            uVar26 = 0;
            if (0x1f9d < *(ushort *)(pbVar29 + 2) - 1) {
              *(undefined8 *)(puVar25 + -8) = 0x100bbc;
              func_0x(pbVar29,6);
              pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
              uVar26 = (ulonglong)*(uint *)(&stack0x0000010c + lVar10);
            }
            break;
          case 4:
            uVar21 = 9;
            uVar26 = 0;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar21 = 1;
          }
          *(uint *)(&stack0x00000118 + lVar10) = uVar21;
          ppbVar22 = *(byte ***)(&stack0x00000118 + lVar10);
          lVar12 = param_1 + 0x2000;
          if (param_1 == 0) {
            lVar12 = 0;
          }
          *(longlong *)(&stack0x00000126 + lVar10) = lVar12;
        }
        else {
          *(undefined2 *)(&stack0x00000108 + lVar10) = 1;
          bVar3 = *pbVar29;
          switch(bVar3 & 0x1c) {
          default:
            if ((char)pbVar29[1] < '\0') {
              uVar14 = *(ushort *)(pbVar29 + 1);
              sVar7 = 3;
              *(undefined2 *)(&stack0x00000120 + lVar10) = 3;
              *(ushort *)(&stack0x0000010a + lVar10) = (uVar14 & 0x7f) << 8 | uVar14 >> 8;
            }
            else {
              *(ushort *)(&stack0x0000010a + lVar10) = (ushort)pbVar29[1];
              sVar7 = 2;
              *(undefined2 *)(&stack0x00000120 + lVar10) = 2;
            }
            uVar14 = *(ushort *)(&stack0x0000010a + lVar10);
            *(short *)(&stack0x00000124 + lVar10) = (short)(uVar14 + 1 >> 1) + sVar7;
            if (uVar14 < 0x1f) {
              *(undefined2 *)(&stack0x00000122 + lVar10) = 0;
              *(undefined4 *)(&stack0x0000010c + lVar10) = 0;
              *(undefined4 *)(&stack0x00000138 + lVar10) = 0;
            }
            else {
              iVar15 = uVar14 - 1;
              *(undefined4 *)(&stack0x0000010c + lVar10) = 0;
              *(undefined4 *)(&stack0x00000138 + lVar10) = 0;
              *(short *)(&stack0x00000122 + lVar10) =
                   ((short)(iVar15 / 0x1e) + (short)(iVar15 >> 0x1f)) -
                   (short)((longlong)iVar15 * 0x88888889 >> 0x3f);
            }
            break;
          case 4:
            if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
              uVar26 = 0xf;
              *(undefined8 *)(&stack0x00000120 + lVar10) = 0;
              *(undefined4 *)(&stack0x0000010c + lVar10) = 0xf;
              *(undefined2 *)(&stack0x0000010a + lVar10) = 0;
              *(undefined8 *)(&stack0x00000128 + lVar10) = 0;
              *(undefined4 *)(&stack0x00000138 + lVar10) = 1;
            }
            else {
              *(undefined8 *)(&stack0x00000120 + lVar10) = 0;
              uVar26 = 1;
              *(undefined2 *)(&stack0x0000010a + lVar10) = 0;
              *(undefined8 *)(&stack0x00000128 + lVar10) = 0;
              *(undefined4 *)(&stack0x0000010c + lVar10) = 1;
              *(undefined4 *)(&stack0x00000138 + lVar10) = 0;
            }
            break;
          case 8:
            uVar26 = 9;
            *(undefined8 *)(&stack0x00000120 + lVar10) = 0;
            *(undefined4 *)(&stack0x0000010c + lVar10) = 9;
            *(undefined2 *)(&stack0x0000010a + lVar10) = 0;
            *(undefined8 *)(&stack0x00000128 + lVar10) = 0;
            *(undefined4 *)(&stack0x00000138 + lVar10) = 0;
          }
          *(byte ***)(&stack0x00000118 + lVar10) = ppbVar22;
          uVar24 = param_1 + 0x2000;
          if (param_1 == 0) {
            uVar24 = uVar17;
          }
          *(ulonglong *)(&stack0x00000130 + lVar10) = uVar24;
        }
        *(undefined8 *)(&stack0x00000050 + lVar10) = 0;
        *(undefined2 *)(&stack0x00000048 + lVar10) = 0xffff;
        uVar17 = (ulonglong)pbVar29 & 0xffffffffffffe000;
        *(undefined4 *)(&stack0x0000004c + lVar10) = 0;
        *(undefined8 *)(&stack0x00000066 + lVar10) = 0;
        *(undefined8 *)(&stack0x00000070 + lVar10) = 0;
        *(undefined8 *)(&stack0x00000058 + lVar10) = 0;
        cVar6 = *(char *)(uVar17 + 2);
        if (cVar6 < '\0') {
          if (*(longlong *)(&stack0x000001f0 + lVar10) == 0) {
            *(undefined8 *)(puVar25 + -8) = 0x100c73;
            lVar12 = func_0x();
            *(undefined4 *)(&stack0x000001f8 + lVar10) = 0x1f9e;
            *(undefined **)(&stack0x000001f0 + lVar10) = puVar25 + -lVar12 + 0x30;
            cVar6 = *(char *)(uVar17 + 2);
            puVar25 = puVar25 + -lVar12;
          }
          if (-1 < cVar6) goto code_r0x00100c97;
          uVar20 = *(undefined8 *)(&stack0x000001f0 + lVar10);
          uVar16 = *(undefined4 *)(&stack0x000001f8 + lVar10);
          *(undefined4 *)(&stack0x00000030 + lVar10) = uVar16;
          *(undefined8 *)(&stack0x00000088 + lVar10) = uVar20;
          *(short *)(&stack0x000001b8 + lVar10) = *(short *)(&stack0x00000108 + lVar10);
          if (*(short *)(&stack0x00000108 + lVar10) == 0) {
            if ((int)uVar26 == 0) {
              uVar30 = *(uint *)(&stack0x00000118 + lVar10);
              *(uint *)(&stack0x0000011c + lVar10) = uVar30;
              *(undefined2 *)(&stack0x0000010a + lVar10) = 0;
              if ((*pbVar29 & 0x10) != 0) {
                *(uint *)(&stack0x0000011c + lVar10) =
                     uVar30 + 2 + (*(ushort *)(pbVar29 + uVar30) + 7 >> 3);
              }
              if ((*pbVar29 & 0x20) == 0) {
                uVar30 = *(uint *)(&stack0x0000011c + lVar10);
                uVar26 = (ulonglong)uVar30;
                *(uint *)(&stack0x0000010c + lVar10) = uVar30;
                *(uint *)(&stack0x00000120 + lVar10) = uVar30;
                *(undefined2 *)(&stack0x00000124 + lVar10) = 0;
              }
              else {
                puVar31 = (ushort *)(pbVar29 + *(uint *)(&stack0x0000011c + lVar10));
                uVar14 = *puVar31;
                *(ushort *)(&stack0x00000124 + lVar10) = uVar14;
                if (uVar14 == 0) {
                  *(undefined8 *)(puVar25 + -8) = 0x100d3d;
                  cVar6 = func_0x(0x1e6ed30);
                  if (cVar6 != '\0') {
                    *(undefined8 *)(puVar25 + -8) = 0x100d46;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar25 + -8) = 0x100d60;
                      cVar6 = func_0x(0x1e6ed30);
                      if (cVar6 == '\0') {
                        *(undefined8 *)(puVar25 + -8) = 0x100d7c;
                        (*pcRam00000000013dc8b8)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        *(undefined8 *)(puVar25 + 0x20) = 0;
                        *(undefined8 *)(puVar25 + -8) = 0x100dbb;
                        (*pcRam00000000013dc8b0)(1,0x175e73c,0x187e828,0x80f);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(&stack0x00000110 + lVar10);
                  *(undefined8 *)(puVar25 + -8) = 0x100d8f;
                  func_0x(uVar13,3);
                  pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
                }
                uVar30 = *(int *)(&stack0x0000011c + lVar10) +
                         (*(ushort *)(&stack0x00000124 + lVar10) + 1) * 2;
                *(uint *)(&stack0x00000120 + lVar10) = uVar30;
                if (0x1f9e < uVar30) {
                  *(undefined8 *)(puVar25 + -8) = 0x100def;
                  cVar6 = func_0x(0x1e6ed30);
                  if (cVar6 != '\0') {
                    *(undefined8 *)(puVar25 + -8) = 0x100df8;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar25 + -8) = 0x100e12;
                      cVar6 = func_0x(0x1e6ed30);
                      if (cVar6 == '\0') {
                        *(undefined8 *)(puVar25 + -8) = 0x100e2e;
                        (*pcRam00000000013dc8b8)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar25 + 0x20) = 0;
                        *(undefined8 *)(puVar25 + -8) = 0x100e51;
                        (*pcRam00000000013dc8b0)(1,0x175e73c,0x187e828,0x816);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(&stack0x00000110 + lVar10);
                  *(undefined8 *)(puVar25 + -8) = 0x100e62;
                  func_0x(uVar13,4);
                  pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
                }
                uVar30 = puVar31[*(ushort *)(&stack0x00000124 + lVar10)] & 0x7fff;
                *(uint *)(&stack0x0000010c + lVar10) = uVar30;
                if (uVar30 < *(uint *)(&stack0x00000120 + lVar10)) {
                  *(undefined8 *)(puVar25 + -8) = 0x100e9c;
                  cVar6 = func_0x(0x1e6ed30);
                  if (cVar6 != '\0') {
                    *(undefined8 *)(puVar25 + -8) = 0x100ea5;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar25 + -8) = 0x100ebf;
                      cVar6 = func_0x(0x1e6ed30);
                      if (cVar6 == '\0') {
                        *(undefined8 *)(puVar25 + -8) = 0x100edb;
                        (*pcRam00000000013dc8b8)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar25 + 0x20) = 0;
                        *(undefined8 *)(puVar25 + -8) = 0x100efe;
                        (*pcRam00000000013dc8b0)(1,0x175e73c,0x187e828,0x81d);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(&stack0x00000110 + lVar10);
                  *(undefined8 *)(puVar25 + -8) = 0x100f0f;
                  func_0x(uVar13,4);
                  uVar30 = *(uint *)(&stack0x0000010c + lVar10);
                  pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
                }
                uVar26 = (ulonglong)uVar30;
                uVar30 = *(uint *)(&stack0x00000120 + lVar10);
                iVar15 = 0;
                puVar4 = puVar31;
                if (*(short *)(&stack0x00000124 + lVar10) != 0) {
                  do {
                    uVar21 = puVar4[1] & 0x7fff;
                    if ((uVar21 < uVar30) || ((uint)uVar26 < uVar21)) {
                      *(undefined8 *)(puVar25 + -8) = 0x100f62;
                      cVar6 = func_0x(0x1e6ed30);
                      if (cVar6 != '\0') {
                        *(undefined8 *)(puVar25 + -8) = 0x100f6b;
                        lVar12 = func_0x();
                        if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar25 + -8) = 0x100f85;
                          cVar6 = func_0x(0x1e6ed30);
                          if (cVar6 == '\0') {
                            *(undefined8 *)(puVar25 + -8) = 0x100fa1;
                            (*pcRam00000000013dc8b8)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar25 + 0x20) = 0;
                            *(undefined8 *)(puVar25 + -8) = 0x100fc5;
                            (*pcRam00000000013dc8b0)(1,0x175e73c,0x187e828,0x82a);
                          }
                        }
                      }
                      uVar20 = *(undefined8 *)(&stack0x00000110 + lVar10);
                      *(undefined8 *)(puVar25 + -8) = 0x100fd6;
                      func_0x(uVar20,4);
                      uVar26 = (ulonglong)*(uint *)(&stack0x0000010c + lVar10);
                      pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
                    }
                    iVar15 = iVar15 + 1;
                    uVar30 = uVar21;
                    puVar4 = puVar4 + 1;
                  } while (iVar15 < (int)(uint)*(ushort *)(&stack0x00000124 + lVar10));
                  uVar20 = *(undefined8 *)(&stack0x00000088 + lVar10);
                  uVar16 = *(undefined4 *)(&stack0x00000030 + lVar10);
                }
                while( true ) {
                  uVar14 = *(ushort *)(&stack0x00000124 + lVar10);
                  if (-1 < (short)puVar31[(ulonglong)(uVar14 - 1) + 1]) break;
                  if (uVar14 == 1) {
                    uVar30 = *(uint *)(&stack0x00000120 + lVar10);
                  }
                  else {
                    uVar30 = *(ushort *)
                              (pbVar29 +
                              (ulonglong)uVar14 * 2 +
                              ((ulonglong)*(uint *)(&stack0x0000011c + lVar10) - 2)) & 0x7fff;
                  }
                  uVar21 = *(ushort *)
                            (pbVar29 +
                            (ulonglong)uVar14 * 2 + (ulonglong)*(uint *)(&stack0x0000011c + lVar10))
                           & 0x7fff;
                  if (((uVar30 < *(uint *)(&stack0x00000120 + lVar10)) || (uVar21 < uVar30)) ||
                     ((uint)uVar26 < uVar21)) {
                    *(undefined8 *)(puVar25 + -8) = 0x101070;
                    func_0x(pbVar29,7);
                    uVar26 = (ulonglong)*(uint *)(&stack0x0000010c + lVar10);
                    pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
                  }
                  if ((uVar30 < *(uint *)(&stack0x00000120 + lVar10)) || ((uint)uVar26 < uVar30))
                  goto code_r0x00101438;
                  if (*(ushort *)(pbVar29 + uVar30) == 5) {
                    *(ushort *)(&stack0x0000010a + lVar10) =
                         *(ushort *)(&stack0x0000010a + lVar10) | 2;
                    *(short *)(&stack0x00000124 + lVar10) =
                         *(short *)(&stack0x00000124 + lVar10) + -1;
                    uVar14 = *(ushort *)(&stack0x00000134 + lVar10);
                    uVar17 = (ulonglong)(uVar30 & 0xffff);
                    pbVar1 = pbVar29 + uVar17;
                    *(short *)(&stack0x00000132 + lVar10) = (short)uVar30;
                    if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                      uVar14 = uVar14 & 0xc7ff;
                    }
                    else {
                      uVar14 = uVar14 ^ (uVar14 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                    }
                    *(ushort *)(&stack0x00000134 + lVar10) = uVar14;
                    uVar27 = (uVar14 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar14;
                    uVar24 = (ulonglong)uVar27;
                    *(ushort *)(&stack0x00000134 + lVar10) = uVar27;
                    pbVar23 = pbVar29 + uVar17 + (uVar24 & 0x7ff) * 2 +
                                                 (ulonglong)((uVar14 >> 0xb & 7) * 2) + 4;
                    if (pbVar23 < pbVar1) {
                      *(undefined8 *)(puVar25 + -8) = 0x101175;
                      func_0x(pbVar1,0x19);
                      uVar24 = (ulonglong)*(ushort *)(&stack0x00000134 + lVar10);
                      uVar17 = (ulonglong)*(ushort *)(&stack0x00000132 + lVar10);
                      uVar26 = (ulonglong)*(uint *)(&stack0x0000010c + lVar10);
                      pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
                    }
                    if (uVar21 - uVar30 <
                        (((*(uint *)(&stack0x00000134 + lVar10) & 0x7ff) * 2 - (int)uVar17) -
                        *(int *)(&stack0x00000110 + lVar10)) + (int)pbVar23) {
                      *(undefined8 *)(puVar25 + -8) = 0x1011c1;
                      func_0x(pbVar29 + uVar17,0x19);
                      uVar24 = (ulonglong)*(ushort *)(&stack0x00000134 + lVar10);
                      uVar17 = (ulonglong)*(ushort *)(&stack0x00000132 + lVar10);
                      uVar26 = (ulonglong)*(uint *)(&stack0x0000010c + lVar10);
                      pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
                    }
                    iVar15 = 0;
                    if (((uVar24 & 0x3800) != 0) &&
                       (puVar31 = (ushort *)(pbVar29 + uVar17 + 4), (uVar24 & 0x3800) != 0)) {
                      do {
                        if (((ushort)uVar24 & 0x7ff) < (*puVar31 & 0x7ff)) {
                          *(undefined8 *)(puVar25 + -8) = 0x101235;
                          func_0x(pbVar29 + uVar17,0x1a);
                          uVar24 = (ulonglong)*(ushort *)(&stack0x00000134 + lVar10);
                          uVar17 = (ulonglong)*(ushort *)(&stack0x00000132 + lVar10);
                          pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
                        }
                        iVar15 = iVar15 + 1;
                        puVar31 = puVar31 + 1;
                      } while (iVar15 < (int)(*(uint *)(&stack0x00000134 + lVar10) >> 0xb & 7));
                      uVar26 = (ulonglong)*(uint *)(&stack0x0000010c + lVar10);
                    }
                    break;
                  }
                  if (*(ushort *)(pbVar29 + uVar30) < 0x400) break;
                  *(ushort *)(&stack0x0000010a + lVar10) =
                       *(ushort *)(&stack0x0000010a + lVar10) | 1;
                  psVar11 = (short *)(&stack0x00000124 + lVar10);
                  *psVar11 = *psVar11 + -1;
                  if (*psVar11 == 0) break;
                }
              }
              if ((*pbVar29 & 0x40) == 0) {
                *(undefined4 *)(&stack0x0000012e + lVar10) = 0;
              }
              else {
                *(int *)(&stack0x0000012e + lVar10) = (int)uVar26;
                *(int *)(&stack0x0000010c + lVar10) = (int)uVar26 + 0xe;
                *(undefined8 *)(puVar25 + -8) = 0x1012ae;
                uVar13 = func_0x(&stack0x0000010a + lVar10);
                *(undefined8 *)(puVar25 + -8) = 0x1012bd;
                func_0x(uVar13,&stack0x00000090 + lVar10);
                *(undefined8 *)(puVar25 + -8) = 0x1012c9;
                iVar15 = func_0x(&stack0x00000090 + lVar10);
                pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
                uVar26 = (ulonglong)(uint)(*(int *)(&stack0x0000010c + lVar10) + iVar15);
                *(int *)(&stack0x0000010c + lVar10) = *(int *)(&stack0x0000010c + lVar10) + iVar15;
              }
              if ((*(byte **)(&stack0x00000126 + lVar10) != (byte *)0x0) &&
                 (*(byte **)(&stack0x00000126 + lVar10) < pbVar29 + uVar26)) {
                *(undefined8 *)(puVar25 + -8) = 0x101315;
                cVar6 = func_0x(0x1e6ed30);
                if (cVar6 != '\0') {
                  *(undefined8 *)(puVar25 + -8) = 0x10131e;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar25 + -8) = 0x101338;
                    cVar6 = func_0x(0x1e6ed30);
                    if (cVar6 == '\0') {
                      *(undefined8 *)(puVar25 + -8) = 0x101354;
                      (*pcRam00000000013dc8b8)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      *(undefined8 *)(puVar25 + 0x20) = 0;
                      *(undefined8 *)(puVar25 + -8) = 0x10137a;
                      (*pcRam00000000013dc8b0)(1,0x175e73c,0x187e828,0x886);
                    }
                  }
                }
                uVar13 = *(undefined8 *)(&stack0x00000110 + lVar10);
                *(undefined8 *)(puVar25 + -8) = 0x10138b;
                func_0x(uVar13,0x12);
                uVar26 = (ulonglong)*(uint *)(&stack0x0000010c + lVar10);
                pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
              }
              if (0x3f3b < (int)uVar26 - 1U) {
                *(undefined8 *)(puVar25 + -8) = 0x1013b4;
                cVar6 = func_0x(0x1e6ed30);
                if (cVar6 != '\0') {
                  *(undefined8 *)(puVar25 + -8) = 0x1013bd;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar25 + -8) = 0x1013d7;
                    cVar6 = func_0x(0x1e6ed30);
                    if (cVar6 == '\0') {
                      *(undefined8 *)(puVar25 + -8) = 0x1013f3;
                      (*pcRam00000000013dc8b8)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      *(undefined8 *)(puVar25 + 0x20) = 0;
                      *(undefined8 *)(puVar25 + -8) = 0x101419;
                      (*pcRam00000000013dc8b0)(1,0x175e73c,0x187e828,0x88b);
                    }
                  }
                }
                uVar13 = *(undefined8 *)(&stack0x00000110 + lVar10);
                *(undefined8 *)(puVar25 + -8) = 0x10142a;
                func_0x(uVar13,5);
                uVar26 = (ulonglong)*(uint *)(&stack0x0000010c + lVar10);
                pbVar29 = *(byte **)(&stack0x00000110 + lVar10);
              }
            }
code_r0x00101438:
            uVar21 = (uint)uVar26;
            uVar30 = uVar21;
            if ((uVar21 < 9) && (((*pbVar29 & 0xe) == 0 || ((*pbVar29 & 0xe) == 0xc)))) {
              uVar30 = 9;
            }
            *(undefined4 *)(&stack0x000001c8 + lVar10) = *(undefined4 *)(&stack0x00000118 + lVar10);
            *(undefined2 *)(&stack0x000001ba + lVar10) = *(undefined2 *)(&stack0x0000010a + lVar10);
            *(undefined2 *)(&stack0x000001d4 + lVar10) = *(undefined2 *)(&stack0x00000124 + lVar10);
            *(undefined4 *)(&stack0x000001cc + lVar10) = *(undefined4 *)(&stack0x0000011c + lVar10);
            *(undefined4 *)(&stack0x000001d0 + lVar10) = *(undefined4 *)(&stack0x00000120 + lVar10);
            *(uint *)(&stack0x000001bc + lVar10) = uVar21;
            *(undefined4 *)(&stack0x000001de + lVar10) = *(undefined4 *)(&stack0x0000012e + lVar10);
            *(undefined8 *)(puVar25 + -8) = 0x1014b7;
            func_0x(uVar20,uVar16,pbVar29,uVar30);
            *(undefined8 *)(&stack0x000001c0 + lVar10) = uVar20;
            *(undefined8 *)(puVar25 + -8) = 0x1014ca;
            iVar15 = func_0x(&stack0x000001ba + lVar10);
            if (iVar15 != 0) {
              lVar12 = *(longlong *)(&stack0x000001c0 + lVar10);
              puVar31 = (ushort *)((ulonglong)*(uint *)(&stack0x000001cc + lVar10) + lVar12);
              uVar30 = *puVar31 - 1;
              if (((&stack0x000001ba)[lVar10] & 1) == 0) {
                uVar30 = (uint)*puVar31;
              }
              uVar21 = *(uint *)(&stack0x000001d0 + lVar10);
              if (uVar30 != 1) {
                uVar21 = puVar31[(longlong)(int)uVar30 + -1] & 0x7fff;
              }
              uVar30 = puVar31[(int)uVar30] & 0x7fff;
              if (((uVar21 < *(uint *)(&stack0x000001d0 + lVar10)) || (uVar30 < uVar21)) ||
                 (*(uint *)(&stack0x000001bc + lVar10) < uVar30)) {
                *(undefined8 *)(puVar25 + -8) = 0x101539;
                func_0x(lVar12,7);
                lVar12 = *(longlong *)(&stack0x000001c0 + lVar10);
              }
              uVar14 = *(ushort *)(&stack0x000001e4 + lVar10);
              uVar17 = (ulonglong)(uVar21 & 0xffff);
              uVar26 = lVar12 + uVar17;
              *(short *)(&stack0x000001e2 + lVar10) = (short)uVar21;
              if ((*(ushort *)(uVar26 + 2) & 0x4000) == 0) {
                uVar14 = uVar14 & 0xc7ff;
              }
              else {
                uVar14 = uVar14 ^ (uVar14 ^ *(ushort *)(uVar26 + 2)) & 0x3800;
              }
              *(ushort *)(&stack0x000001e4 + lVar10) = uVar14;
              uVar27 = (uVar14 ^ *(ushort *)(uVar26 + 2)) & 0x7ff ^ uVar14;
              uVar28 = (ulonglong)uVar27;
              *(ushort *)(&stack0x000001e4 + lVar10) = uVar27;
              uVar24 = (ulonglong)((uVar14 >> 0xb & 7) * 2) + 4 + lVar12 + (uVar28 & 0x7ff) * 2 +
                       uVar17;
              if (uVar24 < uVar26) {
                *(undefined8 *)(puVar25 + -8) = 0x1015dc;
                func_0x(uVar26,0x19);
                uVar28 = (ulonglong)*(ushort *)(&stack0x000001e4 + lVar10);
                uVar17 = (ulonglong)*(ushort *)(&stack0x000001e2 + lVar10);
                lVar12 = *(longlong *)(&stack0x000001c0 + lVar10);
              }
              if (uVar30 - uVar21 <
                  (((*(uint *)(&stack0x000001e4 + lVar10) & 0x7ff) * 2 - (int)uVar17) -
                  *(int *)(&stack0x000001c0 + lVar10)) + (int)uVar24) {
                *(undefined8 *)(puVar25 + -8) = 0x101620;
                func_0x(uVar17 + lVar12,0x19);
                uVar28 = (ulonglong)*(ushort *)(&stack0x000001e4 + lVar10);
                uVar17 = (ulonglong)*(ushort *)(&stack0x000001e2 + lVar10);
                lVar12 = *(longlong *)(&stack0x000001c0 + lVar10);
              }
              if ((uVar28 & 0x3800) != 0) {
                puVar31 = (ushort *)(lVar12 + 4 + uVar17);
                iVar15 = 0;
                if ((uVar28 & 0x3800) != 0) {
                  do {
                    if (((ushort)uVar28 & 0x7ff) < (*puVar31 & 0x7ff)) {
                      *(undefined8 *)(puVar25 + -8) = 0x101693;
                      func_0x(uVar17 + lVar12,0x1a);
                      uVar28 = (ulonglong)*(ushort *)(&stack0x000001e4 + lVar10);
                      uVar17 = (ulonglong)*(ushort *)(&stack0x000001e2 + lVar10);
                      lVar12 = *(longlong *)(&stack0x000001c0 + lVar10);
                    }
                    iVar15 = iVar15 + 1;
                    puVar31 = puVar31 + 1;
                  } while (iVar15 < (int)(*(uint *)(&stack0x000001e4 + lVar10) >> 0xb & 7));
                }
              }
            }
          }
          else if ((ppbVar22 == (byte **)0x0) || (*ppbVar22 == (byte *)0x0)) {
            uVar16 = *(undefined4 *)(&stack0x000001f8 + lVar10);
            uVar20 = *(undefined8 *)(&stack0x000001f0 + lVar10);
            *(undefined8 *)(puVar25 + -8) = 0x101711;
            func_0x(&stack0x000001ba + lVar10,uVar20,uVar16,&stack0x0000010a + lVar10);
            uVar20 = *(undefined8 *)(&stack0x00000118 + lVar10);
            if (*(short *)(&stack0x00000108 + lVar10) == 0) {
              uVar20 = 0;
            }
            *(undefined8 *)(&stack0x000001c8 + lVar10) = uVar20;
          }
          else {
            uVar16 = *(undefined4 *)(&stack0x000001f8 + lVar10);
            uVar20 = *(undefined8 *)(&stack0x000001f0 + lVar10);
            *(undefined8 *)(puVar25 + -8) = 0x1016ee;
            func_0x(&stack0x000001b8 + lVar10,uVar20,uVar16,&stack0x00000108 + lVar10);
          }
          param_1 = *(longlong *)(&stack0x00000098 + lVar10);
          puVar5 = &stack0x000001b8;
          uVar30 = *(uint *)((longlong)auStackX_14 + lVar10 + 4);
        }
        else {
code_r0x00100c97:
          puVar5 = &stack0x00000108;
        }
        uVar21 = *(uint *)((longlong)auStackX_14 + lVar10);
        *(undefined **)(puVar25 + 0x20) = &stack0x00000208 + lVar10;
        *(undefined8 *)(puVar25 + -8) = 0x10176d;
        func_0x(&stack0x00000048 + lVar10,&stack0x00000288 + (ulonglong)uVar21 + lVar10,
                        0x1f9e - uVar21,(longlong)puVar5 + lVar10);
        lVar12 = *(longlong *)(&stack0x00000040 + lVar10);
        *(short *)(lVar12 + *(longlong *)(&stack0x00000038 + lVar10) * 2) = (short)uVar21;
        if (*(short *)(&stack0x00000048 + lVar10) == 0) {
          *(undefined8 *)(puVar25 + -8) = 0x10178a;
          iVar15 = func_0x(&stack0x0000004a + lVar10);
        }
        else {
          iVar15 = *(int *)(&stack0x0000004c + lVar10);
          if (iVar15 == 0) {
            *(undefined8 *)(puVar25 + -8) = 0x10179c;
            func_0x(&stack0x0000004a + lVar10);
            iVar15 = *(int *)(&stack0x0000004c + lVar10);
          }
        }
        lVar18 = *(longlong *)(&stack0x00000038 + lVar10);
        *(uint *)((longlong)auStackX_14 + lVar10) = uVar21 + iVar15;
        uVar26 = (ulonglong)*puVar2;
        uVar20 = 0xffffffff;
      }
      else {
        *(short *)(lVar12 + lVar18 * 2) = (short)uVar20;
      }
      uVar19 = (undefined2)uVar20;
      uVar30 = uVar30 + 1;
      sVar7 = (short)uVar26;
      lVar18 = lVar18 + 1;
      *(uint *)((longlong)auStackX_14 + lVar10 + 4) = uVar30;
      *(longlong *)(&stack0x00000038 + lVar10) = lVar18;
    } while ((int)uVar30 < (int)uVar26);
  }
  uVar16 = *(undefined4 *)(&stack0x00000034 + lVar10);
  *(undefined **)(&stack0x000000a8 + lVar10) = &stack0x00000288 + lVar10;
  *(undefined2 *)(&stack0x000000d0 + lVar10) = uVar19;
  *(undefined **)(&stack0x000000c8 + lVar10) = &stack0x00000208 + lVar10;
  *(undefined8 *)(&stack0x000000d8 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000d4 + lVar10) = 0;
  *(undefined8 *)(&stack0x000000ee + lVar10) = 0;
  *(undefined8 *)(&stack0x000000f8 + lVar10) = 0;
  *(undefined8 *)(&stack0x000000e0 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000b0 + lVar10) = 0x1f9e;
  *(longlong *)(&stack0x000000b8 + lVar10) = lVar12;
  *(short *)(&stack0x000000c0 + lVar10) = sVar7;
  *(undefined8 *)(puVar25 + -8) = 0x101845;
  func_0x(param_1,&stack0x000000a8 + lVar10,uVar16);
  uVar26 = *(ulonglong *)(&stack0x00002228 + lVar10);
  *(undefined8 *)(puVar25 + -8) = 0x101854;
  func_0x(uVar26 ^ (ulonglong)puVar2);
  return;
}

