
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00121e31) */
/* WARNING: Removing unreachable block (ram,0x0012264b) */
/* WARNING: Removing unreachable block (ram,0x011d2eec) */
/* WARNING: Removing unreachable block (ram,0x011d2d1d) */

undefined8
FUN_(ulonglong param_1,undefined8 param_2,uint param_3,uint param_4,short param_5,
            undefined4 *param_6,undefined8 param_7,int param_8,int *param_9,undefined8 param_10,
            longlong *param_11,undefined8 param_12)

{
  longlong lVar1;
  int *piVar2;
  longlong *plVar3;
  int iVar4;
  int iStackX_8;
  undefined2 uStackX_c;
  undefined8 uStackX_10;
  undefined4 uStackX_18;
  ulonglong uVar5;
  undefined uVar6;
  undefined4 *puVar7;
  undefined4 uStack_a0;
  undefined2 uStack_9c;
  undefined2 uStack_9a;
  undefined8 uStack_98;
  undefined auStack_88 [16];
  undefined4 uStack_78;
  undefined uStack_74;
  uint auStack_68 [2];
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  
  plVar3 = param_11;
  piVar2 = param_9;
  uStack_50 = 0xfffffffffffffffe;
  iStackX_8 = 0;
  uStackX_c = 0;
  uStackX_18 = 0;
  uStack_60 = 0;
  uStack_58 = 0;
  auStack_88 = ZEXT816(0);
  uStack_78 = 0;
  uStack_74 = 0;
  uStack_98 = 0;
  if (*(short *)(param_9 + 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (((param_3 & 8) == 0) && (param_4 != 2)) {
    if (param_4 == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    param_3 = param_3 | 2;
  }
  auStack_68[0] = (uint)((param_3 & 2) == 0);
  lVar1 = *(longlong *)(param_1 + 0x30);
  if (param_5 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_9 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(short *)(lVar1 + 0x6b8) == 2) && (param_5 != 1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_11 != (longlong *)0x0) && (*param_11 != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar7 = &param_8;
  uVar5 = (ulonglong)param_4;
  uStackX_10 = param_2;
  iVar4 = func_0x(auStack_68,0x2e13410,param_7,param_1,param_3,uVar5,param_5,&iStackX_8,0x10
                          ,puVar7);
  uVar6 = (undefined)((ushort)param_5 >> 8);
  if (iVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_4 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uStack_a0 = *param_6;
  uStack_9c = *(undefined2 *)(param_6 + 1);
  uStack_9a = *(undefined2 *)((longlong)param_6 + 6);
  func_0x(*(undefined8 *)(lVar1 + 0x718),&uStack_a0,auStack_88);
  if ((auStack_88._0_8_ != 0) && (*(longlong *)(auStack_88._0_8_ + 0x98) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_8 == iStackX_8) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  param_11._0_4_ = 0;
  param_11._4_2_ = 0;
  func_0x
            (param_12,param_6,param_4,0,param_1,uVar5,CONCAT11(uVar6,10),&param_8,0,
             (ulonglong)puVar7 & 0xffffffffffffff00,0x5a,0,uStackX_18,&iStackX_8,&param_11,piVar2,0)
  ;
  func_0x(param_12,2,0xffffffff,0,param_1 & 0xffffffff00000000,0,1);
  if ((plVar3 != (longlong *)0x0) && (*plVar3 != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (auStack_88._0_8_ != 0) {
    func_0x(auStack_88);
  }
  return 1;
}

