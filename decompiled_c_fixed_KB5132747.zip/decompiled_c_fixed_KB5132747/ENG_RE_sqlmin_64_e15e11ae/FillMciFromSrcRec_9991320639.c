
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,short *param_3,longlong *param_4,
                 undefined8 param_5,int param_6,int param_7,longlong param_8,longlong param_9,
                 uint *param_10)

{
  ushort *puVar1;
  int *piVar2;
  uint *puVar3;
  undefined2 uVar4;
  code *pcVar5;
  longlong *plVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  byte bVar12;
  char cVar13;
  ushort uVar14;
  uint uVar15;
  int *piVar16;
  longlong lVar17;
  undefined8 uVar18;
  byte bVar19;
  uint uVar20;
  ulonglong uVar21;
  longlong lVar22;
  ushort uVar23;
  ushort uVar24;
  uint uVar25;
  ulonglong uVar26;
  undefined *puVar27;
  uint *puVar28;
  uint uVar29;
  uint uVar30;
  ulonglong uVar31;
  byte *pbVar32;
  ulonglong uVar33;
  int iVar34;
  int iVar35;
  short *psVar36;
  ushort *puVar37;
  ushort *puVar38;
  longlong lVar39;
  longlong unaff_GS_OFFSET;
  undefined auStack_d8 [64];
  uint uStack_98;
  uint uStack_94;
  uint uStack_90;
  undefined8 uStack_88;
  short *psStack_80;
  uint uStack_78;
  int iStack_74;
  undefined8 uStack_70;
  longlong lStack_68;
  uint uStack_60;
  longlong lStack_58;
  longlong lStack_50;
  undefined auStack_48 [8];
  undefined auStack_40 [8];
  longlong *plStack_38;
  ulonglong uStack_30;
  
  puVar27 = auStack_d8;
  uStack_30 = _DAT_ ^ (ulonglong)&uStack_98;
  uVar33 = 0;
  uStack_90 = 0;
  lStack_68 = 0;
  lVar17 = *(longlong *)(param_2 + 8);
  iStack_74 = -1;
  psStack_80 = param_3;
  lStack_58 = param_2;
  lStack_50 = param_1;
  plStack_38 = param_4;
  if (*(int *)(lVar17 + 0x100) == 2) {
    if ((*(byte *)(lVar17 + 0x42) & 4) == 0) {
      uVar33 = (ulonglong)*(uint *)(lVar17 + 0xb0);
      if (0x1f9e < *(uint *)(lVar17 + 0xb0)) {
        uVar33 = 0x1f9e;
      }
    }
    else {
      uVar33 = 0x1f9e;
    }
    uStack_90 = (uint)uVar33;
    uVar21 = uVar33 + 0xf;
    if (uVar21 <= uVar33) {
      uVar21 = 0xffffffffffffff0;
    }
    uVar21 = uVar21 & 0xfffffffffffffff0;
    func_0x();
    puVar27 = auStack_d8 + -uVar21;
    lStack_68 = (longlong)&uStack_98 + -uVar21;
  }
  lVar17 = lStack_68;
  if (param_4 != (longlong *)0x0) {
    pcVar5 = *(code **)*param_4;
    *(undefined8 *)(puVar27 + -8) = 0x1000ce;
    param_3 = (short *)(*pcVar5)(param_4);
    psStack_80 = param_3;
  }
  puVar1 = (ushort *)(param_3 + 1);
  if (*param_3 == 0) {
    *(undefined8 *)(puVar27 + -8) = 0x1000e8;
    uVar15 = func_0x(puVar1);
  }
  else {
    uVar15 = (uint)*puVar1;
  }
  uVar15 = param_6 + uVar15;
  uStack_78 = 0;
  uStack_88 = CONCAT44(uStack_88._4_4_,uVar15);
  psVar36 = param_3;
  if (0 < (int)uVar15) {
    do {
      uStack_94 = uVar15;
      uVar21 = 0;
      uStack_60 = ~uStack_78;
      if ((uStack_60 & 0xc0000000) == 0x80000000) {
        uVar15 = uStack_60 & 0x1fffffff;
        uVar18 = **(undefined8 **)(*(longlong *)(param_2 + 8) + 0x160);
        *(undefined8 *)(puVar27 + -8) = 0x100163;
        piVar16 = (int *)func_0x(uVar18,uVar15);
        uVar21 = 0;
      }
      else {
        uVar18 = *(undefined8 *)(*(longlong *)(param_2 + 8) + 0x160);
        *(undefined8 *)(puVar27 + -8) = 0x100148;
        piVar16 = (int *)func_0x(uVar18);
      }
      if ((piVar16 != (int *)0x0) && ((*(byte *)((longlong)piVar16 + 0x21) & 0x10) != 0)) {
        uVar31 = (ulonglong)*(uint *)(*(longlong *)(param_1 + 8) + 0x14);
        lVar22 = *(longlong *)(*(longlong *)(param_1 + 8) + 0x18);
        if (uVar31 != 0) {
          uVar26 = uVar21;
          do {
            if (*(int *)(*(longlong *)(lVar22 + 0x48) + 4) == piVar16[9]) {
              if (lVar22 != 0) goto LAB_;
              break;
            }
            uVar26 = uVar26 + 1;
            lVar22 = lVar22 + 0x50;
          } while (uVar26 < uVar31);
        }
        if ((*(byte *)(piVar16 + 8) & 0x40) != 0) {
          if (*psVar36 == 0) {
            pbVar32 = *(byte **)(psVar36 + 4);
            if ((*pbVar32 & 0x10) == 0) {
              uVar26 = uVar31;
              uVar15 = (uint)uVar21;
              if ((1 << (*pbVar32 & 0xe) & 0x1105U) != 0) {
LAB_:
                uVar31 = uVar26;
                uVar15 = ~(uint)(*(ushort *)((longlong)piVar16 + 6) >> 4) & 1;
              }
            }
            else {
              uVar26 = (ulonglong)*(uint *)(psVar36 + 8);
              if (*piVar16 < (int)*(uint *)(psVar36 + 8)) {
                if ((uint)*(ushort *)(pbVar32 + uVar26) < (uint)*(ushort *)(piVar16 + 1))
                goto LAB_;
                uVar15 = *(ushort *)(piVar16 + 1) - 1;
                uVar31 = uVar26;
                uVar15 = pbVar32[(uVar15 >> 3) + uVar26 + 2] >> ((byte)uVar15 & 7) & 1;
              }
              else {
                uVar15 = ~(uint)(*(ushort *)((longlong)piVar16 + 6) >> 4) & 1;
              }
            }
          }
          else {
            uVar14 = *(ushort *)(piVar16 + 1);
            uVar31 = (ulonglong)uVar14;
            if (*puVar1 < uVar14) {
              uVar15 = ~(uint)(*(ushort *)((longlong)piVar16 + 6) >> 4) & 1;
            }
            else {
              bVar12 = *(byte *)((longlong)((int)(uVar14 - 1) / 2) + (ulonglong)(ushort)param_3[0xc]
                                + *(longlong *)(param_3 + 4));
              uVar31 = (ulonglong)uVar14 & 0xffffffffffffff01;
              bVar19 = bVar12 >> 4;
              if ((uVar14 & 1) != 0) {
                bVar19 = bVar12 & 0xf;
              }
              uVar15 = (uint)CONCAT71((int7)(uVar21 >> 8),bVar19 == 0);
            }
          }
          if (uVar15 != 0) goto LAB_;
        }
        if (*psVar36 == 0) {
          iVar35 = *piVar16;
          if (*(int *)(param_3 + 2) == 0) {
            pbVar32 = *(byte **)(param_3 + 4);
            uVar15 = *(uint *)(param_3 + 8);
            uVar33 = (ulonglong)uVar15;
            *puVar1 = (ushort)uVar21;
            *(uint *)(param_3 + 10) = uVar15;
            bVar12 = *pbVar32;
            if ((bVar12 & 0x10) != 0) {
              uVar15 = uVar15 + 2 + (*(ushort *)(pbVar32 + uVar33) + 7 >> 3);
              uVar33 = (ulonglong)uVar15;
              *(uint *)(param_3 + 10) = uVar15;
              bVar12 = *pbVar32;
            }
            if ((bVar12 & 0x20) == 0) {
              *(int *)(param_3 + 2) = (int)uVar33;
              param_3[0xe] = (ushort)uVar21;
              *(int *)(param_3 + 0xc) = (int)uVar33;
            }
            else {
              puVar37 = (ushort *)(pbVar32 + uVar33);
              uVar14 = *puVar37;
              param_3[0xe] = uVar14;
              uStack_70 = puVar37;
              if (uVar14 == 0) {
                *(undefined8 *)(puVar27 + -8) = 0x100316;
                cVar13 = func_0x(0x11ccbf0);
                if (cVar13 != '\0') {
                  *(undefined8 *)(puVar27 + -8) = 0x10031f;
                  lVar17 = func_0x();
                  if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar27 + -8) = 0x100339;
                    cVar13 = func_0x();
                    if (cVar13 == '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x100355;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar27 + 0x20) = 0;
                      *(undefined8 *)(puVar27 + -8) = 0x10037d;
                      (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x80f);
                    }
                  }
                }
                uVar18 = *(undefined8 *)(param_3 + 4);
                *(undefined8 *)(puVar27 + -8) = 0x10038b;
                func_0x(uVar18,3);
                uVar33 = (ulonglong)*(uint *)(param_3 + 10);
                uVar14 = param_3[0xe];
              }
              uVar15 = (int)uVar33 + (uVar14 + 1) * 2;
              *(uint *)(param_3 + 0xc) = uVar15;
              if (0x1f9e < uVar15) {
                *(undefined8 *)(puVar27 + -8) = 0x1003bb;
                cVar13 = func_0x(0x11ccbf0);
                if (cVar13 != '\0') {
                  *(undefined8 *)(puVar27 + -8) = 0x1003c4;
                  lVar17 = func_0x();
                  if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar27 + -8) = 0x1003de;
                    cVar13 = func_0x(0x11ccbf0);
                    if (cVar13 == '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x1003fa;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar27 + 0x20) = 0;
                      *(undefined8 *)(puVar27 + -8) = 0x100420;
                      (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x816);
                    }
                  }
                }
                uVar18 = *(undefined8 *)(param_3 + 4);
                *(undefined8 *)(puVar27 + -8) = 0x10042e;
                func_0x(uVar18,4);
                uVar14 = param_3[0xe];
                uVar15 = *(uint *)(param_3 + 0xc);
              }
              uVar33 = (ulonglong)uVar14;
              uVar14 = puVar37[uVar33];
              *(uint *)(param_3 + 2) = uVar14 & 0x7fff;
              if ((uVar14 & 0x7fff) < uVar15) {
                *(undefined8 *)(puVar27 + -8) = 0x10045e;
                cVar13 = func_0x(0x11ccbf0);
                if (cVar13 != '\0') {
                  *(undefined8 *)(puVar27 + -8) = 0x100467;
                  lVar17 = func_0x();
                  if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar27 + -8) = 0x100481;
                    cVar13 = func_0x(0x11ccbf0);
                    if (cVar13 == '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x10049d;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar27 + 0x20) = 0;
                      *(undefined8 *)(puVar27 + -8) = 0x1004c3;
                      (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x81d);
                    }
                  }
                }
                uVar18 = *(undefined8 *)(param_3 + 4);
                *(undefined8 *)(puVar27 + -8) = 0x1004d1;
                func_0x(uVar18,4);
                uVar15 = *(uint *)(param_3 + 0xc);
                uVar33 = (ulonglong)(ushort)param_3[0xe];
              }
              iVar34 = 0;
              puVar38 = puVar37;
              if ((short)uVar33 != 0) {
                do {
                  puVar37 = puVar37 + 1;
                  uVar29 = *puVar37 & 0x7fff;
                  if ((uVar29 < uVar15) || (*(uint *)(param_3 + 2) < uVar29)) {
                    *(undefined8 *)(puVar27 + -8) = 0x10050f;
                    cVar13 = func_0x(0x11ccbf0);
                    if (cVar13 != '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x100518;
                      lVar17 = func_0x();
                      if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar27 + -8) = 0x100532;
                        cVar13 = func_0x(0x11ccbf0);
                        if (cVar13 == '\0') {
                          *(undefined8 *)(puVar27 + -8) = 0x10054e;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar27 + 0x20) = 0;
                          *(undefined8 *)(puVar27 + -8) = 0x100574;
                          (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x82a);
                        }
                      }
                    }
                    uVar18 = *(undefined8 *)(param_3 + 4);
                    *(undefined8 *)(puVar27 + -8) = 0x100582;
                    func_0x(uVar18,4);
                  }
                  uVar33 = (ulonglong)(ushort)param_3[0xe];
                  iVar34 = iVar34 + 1;
                  puVar38 = uStack_70;
                  uVar15 = uVar29;
                } while (iVar34 < (int)(uint)(ushort)param_3[0xe]);
              }
              if ((short)puVar38[(ulonglong)((int)uVar33 - 1) + 1] < 0) {
                pbVar32 = *(byte **)(param_3 + 4);
                do {
                  uVar15 = *(ushort *)(pbVar32 + uVar33 * 2 + (ulonglong)*(uint *)(param_3 + 10)) &
                           0x7fff;
                  if ((int)uVar33 == 1) {
                    uVar29 = *(uint *)(param_3 + 0xc);
                    uVar20 = uVar29;
LAB_:
                    if ((uVar15 < uVar29) || (*(uint *)(param_3 + 2) < uVar15)) goto LAB_;
                  }
                  else {
                    uVar20 = *(uint *)(param_3 + 0xc);
                    uVar29 = *(ushort *)
                              (pbVar32 + uVar33 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                             0x7fff;
                    if (uVar20 <= uVar29) goto LAB_;
LAB_:
                    *(undefined8 *)(puVar27 + -8) = 0x100608;
                    func_0x(pbVar32,7);
                    uVar20 = *(uint *)(param_3 + 0xc);
                  }
                  if ((uVar29 < uVar20) || (*(uint *)(param_3 + 2) < uVar29)) goto LAB_;
                  pbVar32 = *(byte **)(param_3 + 4);
                  if (*(ushort *)(pbVar32 + uVar29) == 5) {
                    *puVar1 = *puVar1 | 2;
                    param_3[0xe] = param_3[0xe] + -1;
                    uVar21 = (ulonglong)(uVar29 & 0xffff);
                    param_3[0x15] = (short)uVar29;
                    uVar33 = *(ulonglong *)(param_3 + 4);
                    uVar14 = param_3[0x16] & 0xc7ffU;
                    if ((*(ushort *)(uVar21 + 2 + uVar33) >> 0xe & 1) != 0) {
                      uVar14 = *(ushort *)(uVar21 + 2 + uVar33) & 0x3800 | param_3[0x16] & 0xc7ffU;
                    }
                    param_3[0x16] = uVar14;
                    uVar24 = (uVar14 ^ *(ushort *)(uVar21 + 2 + uVar33)) & 0x7ff ^ uVar14;
                    param_3[0x16] = uVar24;
                    uVar31 = (ulonglong)((uVar24 & 0x7ff) * 2) + 4 +
                             uVar21 + (uVar14 >> 0xb & 7) * 2 + uVar33;
                    if (uVar31 < uVar21 + uVar33) {
                      *(undefined8 *)(puVar27 + -8) = 0x100715;
                      func_0x(uVar21 + uVar33,0x19);
                      uVar24 = param_3[0x16];
                      uVar21 = (ulonglong)(ushort)param_3[0x15];
                      uVar33 = (ulonglong)*(uint *)(param_3 + 4);
                    }
                    if (uVar15 - uVar29 <
                        (((uVar24 & 0x7ff) * 2 - (int)uVar21) - (int)uVar33) + (int)uVar31) {
                      lVar17 = *(longlong *)(param_3 + 4);
                      *(undefined8 *)(puVar27 + -8) = 0x10074d;
                      func_0x(uVar21 + lVar17,0x19);
                      uVar24 = param_3[0x16];
                    }
                    iVar34 = 0;
                    if (((uVar24 & 0x3800) != 0) &&
                       (puVar37 = (ushort *)
                                  (*(longlong *)(param_3 + 4) + 4 + (ulonglong)(ushort)param_3[0x15]
                                  ), (uVar24 & 0x3800) != 0)) {
                      do {
                        if ((uVar24 & 0x7ff) < (*puVar37 & 0x7ff)) {
                          uVar14 = param_3[0x15];
                          lVar17 = *(longlong *)(param_3 + 4);
                          *(undefined8 *)(puVar27 + -8) = 0x1007a7;
                          func_0x((ulonglong)uVar14 + lVar17,0x1a);
                          uVar24 = param_3[0x16];
                        }
                        iVar34 = iVar34 + 1;
                        puVar37 = puVar37 + 1;
                      } while (iVar34 < (int)(uVar24 >> 0xb & 7));
                    }
                    goto LAB_;
                  }
                  if (*(ushort *)(pbVar32 + uVar29) < 0x400) goto LAB_;
                  *puVar1 = *puVar1 | 1;
                  uVar14 = param_3[0xe] - 1;
                  param_3[0xe] = uVar14;
                  if (uVar14 == 0) goto LAB_;
                  uVar33 = (ulonglong)uVar14;
                } while ((short)puVar38[(ulonglong)(uVar14 - 1) + 1] < 0);
                uVar33 = (ulonglong)*(uint *)(param_3 + 2);
                uVar21 = 0;
              }
              else {
LAB_:
                uVar21 = 0;
                pbVar32 = *(byte **)(param_3 + 4);
                uVar33 = (ulonglong)*(uint *)(param_3 + 2);
              }
            }
            if ((*pbVar32 & 0x40) == 0) {
              *(int *)(param_3 + 0x13) = (int)uVar21;
            }
            else {
              *(int *)(param_3 + 0x13) = (int)uVar33;
              *(int *)(param_3 + 2) = (int)uVar33 + 0xe;
              *(undefined8 *)(puVar27 + -8) = 0x1007f0;
              uVar18 = func_0x(puVar1);
              *(undefined8 *)(puVar27 + -8) = 0x1007fc;
              func_0x(uVar18,auStack_48);
              *(undefined8 *)(puVar27 + -8) = 0x100805;
              iVar34 = func_0x(auStack_48);
              *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar34;
              uVar33 = (ulonglong)*(uint *)(param_3 + 2);
            }
            iVar34 = (int)uVar33;
            if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
               (*(ulonglong *)(param_3 + 0xf) < uVar33 + *(longlong *)(param_3 + 4))) {
              *(undefined8 *)(puVar27 + -8) = 0x10083b;
              cVar13 = func_0x(0x11ccbf0);
              if (cVar13 != '\0') {
                *(undefined8 *)(puVar27 + -8) = 0x100844;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar27 + -8) = 0x10085e;
                  cVar13 = func_0x(0x11ccbf0);
                  if (cVar13 == '\0') {
                    *(undefined8 *)(puVar27 + -8) = 0x10087a;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar27 + 0x20) = 0;
                    *(undefined8 *)(puVar27 + -8) = 0x1008a0;
                    (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x886);
                  }
                }
              }
              uVar18 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar27 + -8) = 0x1008ae;
              func_0x(uVar18,0x12);
              iVar34 = *(int *)(param_3 + 2);
            }
            if (0x3f3b < iVar34 - 1U) {
              *(undefined8 *)(puVar27 + -8) = 0x1008c7;
              cVar13 = func_0x(0x11ccbf0);
              if (cVar13 != '\0') {
                *(undefined8 *)(puVar27 + -8) = 0x1008d0;
                lVar17 = func_0x();
                if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar27 + -8) = 0x1008ea;
                  cVar13 = func_0x(0x11ccbf0);
                  if (cVar13 == '\0') {
                    *(undefined8 *)(puVar27 + -8) = 0x100906;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar27 + 0x20) = 0;
                    *(undefined8 *)(puVar27 + -8) = 0x10092c;
                    (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x88b);
                  }
                }
              }
              uVar18 = *(undefined8 *)(param_3 + 4);
              *(undefined8 *)(puVar27 + -8) = 0x10093a;
              func_0x(uVar18,5);
            }
LAB_:
            uVar21 = 0;
          }
          uVar15 = (uint)uVar21;
          if ((*(byte *)((longlong)piVar16 + 6) & 0x10) != 0) {
            bVar12 = **(byte **)(param_3 + 4);
            if ((bVar12 & 0x10) != 0) {
              if ((*piVar16 < (int)*(uint *)(param_3 + 8)) &&
                 (*(ushort *)(piVar16 + 1) <=
                  *(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)))) goto LAB_;
LAB_:
              uStack_98 = **(uint **)(piVar16 + 2);
              puVar28 = *(uint **)(piVar16 + 2) + 1;
              uStack_94 = uVar15;
              goto LAB_;
            }
            if ((1 << (bVar12 & 0xe) & 0x1105U) != 0) goto LAB_;
          }
LAB_:
          uVar29 = -iVar35;
          if ((ushort)param_3[0xe] < uVar29) {
            puVar28 = *(uint **)(param_3 + 4);
            uStack_98 = uVar15;
            uStack_94 = uVar15;
          }
          else {
            lVar17 = *(longlong *)(param_3 + 4);
            lVar22 = (ulonglong)*(uint *)(param_3 + 10) + lVar17;
            uVar15 = *(ushort *)(lVar22 + (longlong)(int)uVar29 * 2) & 0x7fff;
            if (uVar29 == 1) {
              uVar33 = (ulonglong)*(uint *)(param_3 + 0xc);
LAB_:
              if ((uVar15 < (uint)uVar33) || (*(uint *)(param_3 + 2) < uVar15)) goto LAB_;
            }
            else {
              uVar20 = *(ushort *)(lVar22 + -2 + (longlong)(int)uVar29 * 2) & 0x7fff;
              uVar33 = (ulonglong)uVar20;
              if (*(uint *)(param_3 + 0xc) <= uVar20) goto LAB_;
LAB_:
              *(undefined8 *)(puVar27 + -8) = 0x1009e7;
              func_0x(lVar17,7);
            }
            uStack_98 = uVar15 - (int)uVar33;
            if (uStack_98 == 0) {
              puVar28 = (uint *)(uVar33 + *(longlong *)(param_3 + 4));
              uStack_94 = 0;
            }
            else {
              puVar28 = (uint *)(uVar33 + *(longlong *)(param_3 + 4));
              uStack_94 = (uint)(*(ushort *)(lVar22 + 2 + (ulonglong)(uVar29 - 1) * 2) >> 0xf);
            }
          }
        }
        else {
          uStack_70 = (ushort *)CONCAT44(uStack_70._4_4_,(uint)uVar21);
          *(undefined8 **)(puVar27 + 0x20) = &uStack_70;
          *(undefined8 *)(puVar27 + -8) = 0x100a46;
          puVar28 = (uint *)func_0x(puVar1,piVar16,uVar31,&uStack_98);
          uVar15 = uStack_98;
          uVar29 = (uint)uStack_70;
          if ((((*psVar36 == 0) || (plVar6 = *(longlong **)(psVar36 + 8), plVar6 == (longlong *)0x0)
               ) || (*plVar6 == 0)) ||
             (((*(byte *)((longlong)piVar16 + 6) & 8) != 0 || (((ulonglong)uStack_70 & 1) != 0)))) {
LAB_:
            uStack_94 = uVar29 & 1;
            if (puVar28 != (uint *)0x0) goto LAB_;
          }
          else {
            if ((puVar28 != (uint *)0x0) && (puVar28 != (uint *)0x841290)) {
              *(uint *)(puVar27 + 0x38) = (uint)uStack_70;
              *(uint **)(puVar27 + 0x30) = &uStack_98;
              *(int *)(puVar27 + 0x28) = (int)uVar33;
              *(longlong *)(puVar27 + 0x20) = lVar17;
              *(undefined8 *)(puVar27 + -8) = 0x100aaf;
              puVar28 = (uint *)func_0x(plVar6,piVar16,puVar28,uVar15);
              goto LAB_;
            }
            uStack_98 = 0;
          }
          uStack_94 = uVar29 & 1;
          puVar28 = *(uint **)(psVar36 + 4);
        }
LAB_:
        uVar15 = uStack_98;
        param_2 = lStack_58;
        param_1 = lStack_50;
        if (0x18 < uStack_98) {
          uVar29 = *(uint *)(param_8 + 4);
          lVar17 = (ulonglong)uVar29 * 0x40;
          pbVar32 = (byte *)(*(longlong *)(param_8 + 8) + 0x18 + lVar17);
          *pbVar32 = *pbVar32 & 0xfb;
          if (*(uint *)(param_8 + 0x20) < *(int *)(param_8 + 0x10) + uStack_98) {
            lVar39 = (ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
            lVar22 = *(longlong *)(lVar39 + 0x100);
            if (lVar22 == 0) {
              *(undefined8 *)(puVar27 + -8) = 0x100b2f;
              (*_DAT_)(0);
              lVar22 = *(longlong *)(lVar39 + 0x100);
            }
            uVar18 = *(undefined8 *)(lVar22 + 1000);
            puVar27[0x20] = 5;
            *(undefined8 *)(puVar27 + -8) = 0x100b5a;
            lVar22 = (*_DAT_)(0x1f9e,uVar18,0xbdac58,0xda);
            if (lVar22 != 0) {
              *(undefined8 *)(puVar27 + -8) = 0x100b72;
              func_0x(lVar22,0,0x1f9e);
            }
            *(undefined4 *)(param_8 + 0x10) = 0;
            *(longlong *)(param_8 + 0x18) = lVar22;
            pbVar32 = (byte *)(*(longlong *)(param_8 + 8) + 0x18 + lVar17);
            *pbVar32 = *pbVar32 | 4;
            *(undefined4 *)(param_8 + 0x20) = 0x1f9e;
          }
          iVar35 = piVar16[1];
          iVar34 = piVar16[2];
          iVar7 = piVar16[3];
          piVar2 = (int *)(*(longlong *)(param_8 + 8) + 8 + lVar17);
          *piVar2 = *piVar16;
          piVar2[1] = iVar35;
          piVar2[2] = iVar34;
          piVar2[3] = iVar7;
          *(undefined4 *)(lVar17 + *(longlong *)(param_8 + 8)) = 0;
          pbVar32 = (byte *)(*(longlong *)(param_8 + 8) + 0x18 + lVar17);
          *pbVar32 = *pbVar32 & 0xfe;
          pbVar32 = (byte *)(*(longlong *)(param_8 + 8) + 0x18 + lVar17);
          *pbVar32 = *pbVar32 & 0xfd;
          lVar17 = *(longlong *)(param_8 + 8) + lVar17;
          *(ulonglong *)(lVar17 + 0x20) =
               (ulonglong)*(uint *)(param_8 + 0x10) + *(longlong *)(param_8 + 0x18);
          *(uint *)(lVar17 + 0x28) = uVar15;
          uVar20 = *(uint *)(lVar17 + 0x2c) & 0xfffffffa | uStack_94 & 0xfffffffb;
          *(uint *)(lVar17 + 0x2c) = uVar20;
          iVar35 = *piVar16;
          iVar34 = piVar16[1];
          iVar7 = piVar16[2];
          iVar8 = piVar16[3];
          *(uint *)(lVar17 + 0x2c) = uVar20 & 0xfffffff5;
          *(int *)(lVar17 + 0x30) = iVar35;
          *(int *)(lVar17 + 0x34) = iVar34;
          *(int *)(lVar17 + 0x38) = iVar7;
          *(int *)(lVar17 + 0x3c) = iVar8;
          uVar20 = *(uint *)(param_8 + 0x10);
          iVar35 = *(int *)(param_8 + 0x20);
          lVar17 = *(longlong *)(param_8 + 0x18);
          *(undefined8 *)(puVar27 + -8) = 0x100c2b;
          func_0x((ulonglong)uVar20 + lVar17,iVar35 - uVar20,puVar28,uVar15);
          *(int *)(param_8 + 4) = *(int *)(param_8 + 4) + 1;
          *(int *)(param_8 + 0x10) = *(int *)(param_8 + 0x10) + uVar15;
          uVar4 = *(undefined2 *)((longlong)piVar16 + 0x3a);
          puVar28 = (uint *)((ulonglong)*param_10 * 0x20 + param_9);
          *puVar28 = uStack_98;
          puVar28[4] = uStack_60;
          *(ulonglong *)(puVar28 + 2) = (ulonglong)uVar29;
          puVar28[5] = 2;
          *(undefined2 *)(puVar28 + 6) = uVar4;
          *param_10 = *param_10 + 1;
          param_2 = lStack_58;
          param_1 = lStack_50;
        }
      }
LAB_:
      uStack_78 = uStack_78 + 1;
      uVar33 = (ulonglong)uStack_90;
      psVar36 = psStack_80;
      lVar17 = lStack_68;
      uVar15 = uStack_94;
    } while ((int)uStack_78 < (int)uStack_88);
  }
  if (param_7 == 0) {
    *(undefined8 *)(puVar27 + -8) = 0x100cb4;
    iVar35 = func_0x(psVar36);
  }
  else {
    iVar35 = 0;
  }
  lStack_68 = (longlong)iVar35;
  uStack_90 = 0;
  if (0 < lStack_68) {
    uStack_88 = 0;
    do {
      uVar29 = uStack_90;
      psStack_80 = (short *)0x0;
      if (*(int *)(param_3 + 2) == 0) {
        pbVar32 = *(byte **)(param_3 + 4);
        uVar20 = *(uint *)(param_3 + 8);
        uVar33 = (ulonglong)uVar20;
        *puVar1 = 0;
        *(uint *)(param_3 + 10) = uVar20;
        bVar12 = *pbVar32;
        if ((bVar12 & 0x10) != 0) {
          uVar20 = uVar20 + 2 + (*(ushort *)(pbVar32 + uVar33) + 7 >> 3);
          uVar33 = (ulonglong)uVar20;
          *(uint *)(param_3 + 10) = uVar20;
          bVar12 = *pbVar32;
        }
        if ((bVar12 & 0x20) == 0) {
          *(int *)(param_3 + 2) = (int)uVar33;
          param_3[0xe] = 0;
          *(int *)(param_3 + 0xc) = (int)uVar33;
        }
        else {
          puVar37 = (ushort *)(pbVar32 + uVar33);
          uVar14 = *puVar37;
          param_3[0xe] = uVar14;
          if (uVar14 == 0) {
            *(undefined8 *)(puVar27 + -8) = 0x100d46;
            cVar13 = func_0x(0x11ccbf0);
            if (cVar13 != '\0') {
              *(undefined8 *)(puVar27 + -8) = 0x100d4f;
              lVar17 = func_0x();
              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                *(undefined8 *)(puVar27 + -8) = 0x100d69;
                cVar13 = func_0x(0x11ccbf0);
                if (cVar13 == '\0') {
                  *(undefined8 *)(puVar27 + -8) = 0x100d85;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar27 + 0x20) = 0;
                  *(undefined8 *)(puVar27 + -8) = 0x100dab;
                  (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x80f);
                }
              }
            }
            uVar18 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar27 + -8) = 0x100db9;
            func_0x(uVar18,3);
            uVar33 = (ulonglong)*(uint *)(param_3 + 10);
            uVar14 = param_3[0xe];
          }
          uVar20 = (int)uVar33 + (uVar14 + 1) * 2;
          *(uint *)(param_3 + 0xc) = uVar20;
          if (0x1f9e < uVar20) {
            *(undefined8 *)(puVar27 + -8) = 0x100de9;
            cVar13 = func_0x(0x11ccbf0);
            if (cVar13 != '\0') {
              *(undefined8 *)(puVar27 + -8) = 0x100df2;
              lVar17 = func_0x();
              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                *(undefined8 *)(puVar27 + -8) = 0x100e0c;
                cVar13 = func_0x(0x11ccbf0);
                if (cVar13 == '\0') {
                  *(undefined8 *)(puVar27 + -8) = 0x100e28;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar27 + 0x20) = 0;
                  *(undefined8 *)(puVar27 + -8) = 0x100e4e;
                  (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x816);
                }
              }
            }
            uVar18 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar27 + -8) = 0x100e5c;
            func_0x(uVar18,4);
            uVar14 = param_3[0xe];
            uVar20 = *(uint *)(param_3 + 0xc);
          }
          uVar33 = (ulonglong)uVar14;
          uVar14 = puVar37[uVar33];
          *(uint *)(param_3 + 2) = uVar14 & 0x7fff;
          if ((uVar14 & 0x7fff) < uVar20) {
            *(undefined8 *)(puVar27 + -8) = 0x100e8c;
            cVar13 = func_0x(0x11ccbf0);
            if (cVar13 != '\0') {
              *(undefined8 *)(puVar27 + -8) = 0x100e95;
              lVar17 = func_0x();
              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                *(undefined8 *)(puVar27 + -8) = 0x100eaf;
                cVar13 = func_0x(0x11ccbf0);
                if (cVar13 == '\0') {
                  *(undefined8 *)(puVar27 + -8) = 0x100ecb;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar27 + 0x20) = 0;
                  *(undefined8 *)(puVar27 + -8) = 0x100ef1;
                  (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x81d);
                }
              }
            }
            uVar18 = *(undefined8 *)(param_3 + 4);
            *(undefined8 *)(puVar27 + -8) = 0x100eff;
            func_0x(uVar18,4);
            uVar20 = *(uint *)(param_3 + 0xc);
            uVar33 = (ulonglong)(ushort)param_3[0xe];
          }
          iVar35 = 0;
          puVar38 = puVar37;
          if ((short)uVar33 != 0) {
            do {
              uVar30 = puVar38[1] & 0x7fff;
              if ((uVar30 < uVar20) || (*(uint *)(param_3 + 2) < uVar30)) {
                *(undefined8 *)(puVar27 + -8) = 0x100f3f;
                cVar13 = func_0x(0x11ccbf0);
                if (cVar13 != '\0') {
                  *(undefined8 *)(puVar27 + -8) = 0x100f48;
                  lVar17 = func_0x();
                  if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar27 + -8) = 0x100f62;
                    cVar13 = func_0x(0x11ccbf0);
                    if (cVar13 == '\0') {
                      *(undefined8 *)(puVar27 + -8) = 0x100f7e;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar27 + 0x20) = 0;
                      *(undefined8 *)(puVar27 + -8) = 0x100fa4;
                      (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x82a);
                    }
                  }
                }
                uVar18 = *(undefined8 *)(param_3 + 4);
                *(undefined8 *)(puVar27 + -8) = 0x100fb2;
                func_0x(uVar18,4);
              }
              uVar33 = (ulonglong)(ushort)param_3[0xe];
              iVar35 = iVar35 + 1;
              puVar38 = puVar38 + 1;
              uVar29 = uStack_90;
              uVar20 = uVar30;
            } while (iVar35 < (int)(uint)(ushort)param_3[0xe]);
          }
          if ((short)puVar37[(ulonglong)((int)uVar33 - 1) + 1] < 0) {
            pbVar32 = *(byte **)(param_3 + 4);
            do {
              uVar20 = *(ushort *)(pbVar32 + uVar33 * 2 + (ulonglong)*(uint *)(param_3 + 10)) &
                       0x7fff;
              if ((int)uVar33 == 1) {
                uVar30 = *(uint *)(param_3 + 0xc);
                uVar25 = uVar30;
LAB_:
                if ((uVar20 < uVar30) || (*(uint *)(param_3 + 2) < uVar20)) goto LAB_;
              }
              else {
                uVar25 = *(uint *)(param_3 + 0xc);
                uVar30 = *(ushort *)
                          (pbVar32 + uVar33 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) & 0x7fff
                ;
                if (uVar25 <= uVar30) goto LAB_;
LAB_:
                *(undefined8 *)(puVar27 + -8) = 0x101038;
                func_0x(pbVar32,7);
                uVar25 = *(uint *)(param_3 + 0xc);
              }
              if ((uVar30 < uVar25) || (*(uint *)(param_3 + 2) < uVar30)) goto LAB_;
              pbVar32 = *(byte **)(param_3 + 4);
              if (*(ushort *)(pbVar32 + uVar30) == 5) {
                *puVar1 = *puVar1 | 2;
                param_3[0xe] = param_3[0xe] + -1;
                uVar21 = (ulonglong)(uVar30 & 0xffff);
                param_3[0x15] = (short)uVar30;
                uVar33 = *(ulonglong *)(param_3 + 4);
                uVar14 = param_3[0x16] & 0xc7ffU;
                if ((*(ushort *)(uVar21 + 2 + uVar33) >> 0xe & 1) != 0) {
                  uVar14 = *(ushort *)(uVar21 + 2 + uVar33) & 0x3800 | param_3[0x16] & 0xc7ffU;
                }
                param_3[0x16] = uVar14;
                uVar24 = (uVar14 ^ *(ushort *)(uVar21 + 2 + uVar33)) & 0x7ff ^ uVar14;
                param_3[0x16] = uVar24;
                uVar31 = (ulonglong)((uVar24 & 0x7ff) * 2) + 4 + uVar21 + (uVar14 >> 0xb & 7) * 2 +
                         uVar33;
                if (uVar31 < uVar21 + uVar33) {
                  *(undefined8 *)(puVar27 + -8) = 0x101145;
                  func_0x(uVar21 + uVar33,0x19);
                  uVar24 = param_3[0x16];
                  uVar21 = (ulonglong)(ushort)param_3[0x15];
                  uVar33 = (ulonglong)*(uint *)(param_3 + 4);
                }
                if (uVar20 - uVar30 <
                    (((uVar24 & 0x7ff) * 2 - (int)uVar21) - (int)uVar33) + (int)uVar31) {
                  lVar17 = *(longlong *)(param_3 + 4);
                  *(undefined8 *)(puVar27 + -8) = 0x10117d;
                  func_0x(uVar21 + lVar17,0x19);
                  uVar24 = param_3[0x16];
                }
                iVar35 = 0;
                if (((uVar24 & 0x3800) != 0) &&
                   (puVar37 = (ushort *)
                              (*(longlong *)(param_3 + 4) + 4 + (ulonglong)(ushort)param_3[0x15]),
                   (uVar24 & 0x3800) != 0)) {
                  do {
                    if ((uVar24 & 0x7ff) < (*puVar37 & 0x7ff)) {
                      uVar14 = param_3[0x15];
                      lVar17 = *(longlong *)(param_3 + 4);
                      *(undefined8 *)(puVar27 + -8) = 0x1011d7;
                      func_0x((ulonglong)uVar14 + lVar17,0x1a);
                      uVar24 = param_3[0x16];
                    }
                    iVar35 = iVar35 + 1;
                    puVar37 = puVar37 + 1;
                  } while (iVar35 < (int)(uVar24 >> 0xb & 7));
                }
                goto LAB_;
              }
              if (*(ushort *)(pbVar32 + uVar30) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar14 = param_3[0xe] - 1;
              param_3[0xe] = uVar14;
              if (uVar14 == 0) goto LAB_;
              uVar33 = (ulonglong)uVar14;
            } while ((short)puVar37[(ulonglong)(uVar14 - 1) + 1] < 0);
            uVar33 = (ulonglong)*(uint *)(param_3 + 2);
          }
          else {
LAB_:
            pbVar32 = *(byte **)(param_3 + 4);
            uVar33 = (ulonglong)*(uint *)(param_3 + 2);
          }
        }
        if ((*pbVar32 & 0x40) == 0) {
          *(undefined4 *)(param_3 + 0x13) = 0;
        }
        else {
          *(int *)(param_3 + 0x13) = (int)uVar33;
          *(int *)(param_3 + 2) = (int)uVar33 + 0xe;
          *(undefined8 *)(puVar27 + -8) = 0x101220;
          uVar18 = func_0x(puVar1);
          *(undefined8 *)(puVar27 + -8) = 0x10122c;
          func_0x(uVar18,auStack_40);
          *(undefined8 *)(puVar27 + -8) = 0x101235;
          iVar35 = func_0x(auStack_40);
          *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar35;
          uVar33 = (ulonglong)*(uint *)(param_3 + 2);
        }
        iVar35 = (int)uVar33;
        if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
           (*(ulonglong *)(param_3 + 0xf) < uVar33 + *(longlong *)(param_3 + 4))) {
          *(undefined8 *)(puVar27 + -8) = 0x10126b;
          cVar13 = func_0x(0x11ccbf0);
          if (cVar13 != '\0') {
            *(undefined8 *)(puVar27 + -8) = 0x101274;
            lVar17 = func_0x();
            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
              *(undefined8 *)(puVar27 + -8) = 0x10128e;
              cVar13 = func_0x(0x11ccbf0);
              if (cVar13 == '\0') {
                *(undefined8 *)(puVar27 + -8) = 0x1012aa;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(puVar27 + 0x20) = 0;
                *(undefined8 *)(puVar27 + -8) = 0x1012d0;
                (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x886);
              }
            }
          }
          uVar18 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)(puVar27 + -8) = 0x1012de;
          func_0x(uVar18,0x12);
          iVar35 = *(int *)(param_3 + 2);
        }
        if (0x3f3b < iVar35 - 1U) {
          *(undefined8 *)(puVar27 + -8) = 0x1012f7;
          cVar13 = func_0x(0x11ccbf0);
          if (cVar13 != '\0') {
            *(undefined8 *)(puVar27 + -8) = 0x101300;
            lVar17 = func_0x();
            if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
              *(undefined8 *)(puVar27 + -8) = 0x10131a;
              cVar13 = func_0x(0x11ccbf0);
              if (cVar13 == '\0') {
                *(undefined8 *)(puVar27 + -8) = 0x101336;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(puVar27 + 0x20) = 0;
                *(undefined8 *)(puVar27 + -8) = 0x10135c;
                (*_DAT_)(1,0xabc5fc,0xbdc6e8,0x88b);
              }
            }
          }
          uVar18 = *(undefined8 *)(param_3 + 4);
          *(undefined8 *)(puVar27 + -8) = 0x10136a;
          func_0x(uVar18,5);
        }
      }
LAB_:
      *(undefined8 *)(puVar27 + -8) = 0x101372;
      iVar35 = func_0x();
      if (iVar35 == 0) {
        *(undefined8 *)(puVar27 + -8) = 0x1014b9;
        iVar35 = func_0x(puVar1);
        if (iVar35 == 0) {
          *(undefined8 *)(puVar27 + 0x20) = 0;
          *(undefined8 *)(puVar27 + -8) = 0x1014e1;
          (*_DAT_)(1,0xc78318,0xc693a8,0xd7a);
        }
      }
      else {
        uVar14 = param_3[0x16];
        lVar17 = 0;
        psStack_80 = (short *)0x0;
        if (uVar29 < (uVar14 & 0x7ff)) {
          uVar33 = (ulonglong)(ushort)param_3[0x15];
          lVar39 = *(longlong *)(param_3 + 4);
          uVar24 = 0;
          lVar22 = lVar39 + uVar33;
          if ((uVar14 & 0x3800) == 0) {
            uVar23 = *(ushort *)(lVar22 + 2);
LAB_:
            uVar24 = uVar23 >> 0xb & 7;
          }
          else if ((uVar14 >> 0xb & 7) != 0) {
            do {
              if (((lVar17 == 0) || ((*(ushort *)(lVar22 + 2 + lVar17 * 2) & 0x7ff) <= uVar29)) &&
                 (uVar23 = *(ushort *)(lVar22 + 4 + lVar17 * 2),
                 (int)uVar29 <= (int)((uVar23 & 0x7ff) - 1))) goto LAB_;
              lVar17 = lVar17 + 1;
            } while (lVar17 < (longlong)(ulonglong)(uVar14 >> 0xb & 7));
          }
          uVar20 = uVar14 >> 0xb & 7;
          uVar21 = (ulonglong)(uVar20 * 2);
          uVar15 = (uVar14 & 0x7ff) * 2;
          iStack_74 = (uint)*(ushort *)(uVar21 + (uStack_88 + 2) * 2 + lVar39 + uVar33) +
                      (uint)uVar24 * 0x10000;
          lVar17 = uVar21 + uVar15 + lVar39 + uVar33;
          if (uStack_88 == 0) {
            uVar20 = (uVar15 + uVar20) * 2 + 4;
          }
          else {
            uVar20 = *(ushort *)(lVar17 + 2 + uStack_88 * 2) & 0x7fff;
          }
          uStack_98 = (*(ushort *)(lVar17 + 4 + uStack_88 * 2) & 0x7fff) - uVar20;
          uVar15 = (uint)(*(ushort *)(lVar17 + 4 + uStack_88 * 2) >> 0xf);
          psStack_80 = (short *)((ulonglong)uVar20 + lVar22);
        }
        else {
          *(undefined8 *)(puVar27 + 0x20) = 0;
          *(undefined8 *)(puVar27 + -8) = 0x1014af;
          (*_DAT_)(1,0xc782e8,0xc782b0,0x41a);
        }
      }
      iVar35 = iStack_74;
      uVar20 = uStack_98;
      uVar18 = **(undefined8 **)(*(longlong *)(lStack_58 + 8) + 0x160);
      *(undefined8 *)(puVar27 + -8) = 0x101500;
      puVar28 = (uint *)func_0x(uVar18,iVar35);
      if ((puVar28 != (uint *)0x0) &&
         (uVar33 = 0, (*(byte *)((longlong)puVar28 + 0x21) & 0x10) != 0)) {
        uVar21 = (ulonglong)*(uint *)(*(longlong *)(lStack_50 + 8) + 0x14);
        lVar17 = *(longlong *)(*(longlong *)(lStack_50 + 8) + 0x18);
        if (uVar21 != 0) {
          do {
            if (*(int *)(*(longlong *)(lVar17 + 0x48) + 4) == iVar35) {
              if (lVar17 != 0) goto LAB_;
              break;
            }
            uVar33 = uVar33 + 1;
            lVar17 = lVar17 + 0x50;
          } while (uVar33 < uVar21);
        }
        if (0x18 < uVar20) {
          uVar29 = *(uint *)(param_8 + 4);
          lVar17 = (ulonglong)uVar29 * 0x40;
          pbVar32 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_8 + 8));
          *pbVar32 = *pbVar32 & 0xfb;
          if (*(uint *)(param_8 + 0x20) < *(int *)(param_8 + 0x10) + uVar20) {
            lVar39 = (ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
            lVar22 = *(longlong *)(lVar39 + 0x100);
            if (lVar22 == 0) {
              *(undefined8 *)(puVar27 + -8) = 0x1015b9;
              (*_DAT_)(0);
              lVar22 = *(longlong *)(lVar39 + 0x100);
            }
            uVar18 = *(undefined8 *)(lVar22 + 1000);
            puVar27[0x20] = 5;
            *(undefined8 *)(puVar27 + -8) = 0x1015e4;
            lVar22 = (*_DAT_)(0x1f9e,uVar18,0xbdac58,0xda);
            if (lVar22 == 0) {
              lVar22 = 0;
            }
            else {
              *(undefined8 *)(puVar27 + -8) = 0x1015fc;
              func_0x(lVar22,0,0x1f9e);
            }
            *(longlong *)(param_8 + 0x18) = lVar22;
            *(undefined4 *)(param_8 + 0x10) = 0;
            pbVar32 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_8 + 8));
            *pbVar32 = *pbVar32 | 4;
            *(undefined4 *)(param_8 + 0x20) = 0x1f9e;
          }
          psVar36 = psStack_80;
          uVar30 = puVar28[1];
          uVar25 = puVar28[2];
          uVar9 = puVar28[3];
          puVar3 = (uint *)(lVar17 + 8 + *(longlong *)(param_8 + 8));
          *puVar3 = *puVar28;
          puVar3[1] = uVar30;
          puVar3[2] = uVar25;
          puVar3[3] = uVar9;
          *(undefined4 *)(lVar17 + *(longlong *)(param_8 + 8)) = 0;
          pbVar32 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_8 + 8));
          *pbVar32 = *pbVar32 & 0xfe;
          pbVar32 = (byte *)(lVar17 + 0x18 + *(longlong *)(param_8 + 8));
          *pbVar32 = *pbVar32 & 0xfd;
          lVar17 = *(longlong *)(param_8 + 8) + lVar17;
          uVar30 = *(uint *)(lVar17 + 0x2c);
          *(ulonglong *)(lVar17 + 0x20) =
               (ulonglong)*(uint *)(param_8 + 0x10) + *(longlong *)(param_8 + 0x18);
          *(uint *)(lVar17 + 0x28) = uVar20;
          *(uint *)(lVar17 + 0x2c) = uVar30 & 0xfffffffa | uVar15 & 1;
          uVar25 = *puVar28;
          uVar9 = puVar28[1];
          uVar10 = puVar28[2];
          uVar11 = puVar28[3];
          *(uint *)(lVar17 + 0x2c) = uVar30 & 0xfffffff0 | uVar15 & 1;
          *(uint *)(lVar17 + 0x30) = uVar25;
          *(uint *)(lVar17 + 0x34) = uVar9;
          *(uint *)(lVar17 + 0x38) = uVar10;
          *(uint *)(lVar17 + 0x3c) = uVar11;
          uVar30 = *(uint *)(param_8 + 0x10);
          iVar35 = *(int *)(param_8 + 0x20);
          lVar17 = *(longlong *)(param_8 + 0x18);
          *(undefined8 *)(puVar27 + -8) = 0x10169f;
          func_0x((ulonglong)uVar30 + lVar17,iVar35 - uVar30,psVar36,uVar20);
          *(int *)(param_8 + 4) = *(int *)(param_8 + 4) + 1;
          *(int *)(param_8 + 0x10) = *(int *)(param_8 + 0x10) + uVar20;
          uVar4 = *(undefined2 *)((longlong)puVar28 + 0x3a);
          uVar20 = *puVar28;
          puVar28 = (uint *)((ulonglong)*param_10 * 0x20 + param_9);
          *(ulonglong *)(puVar28 + 2) = (ulonglong)uVar29;
          *puVar28 = uStack_98;
          puVar28[4] = uVar20;
          puVar28[5] = 2;
          *(undefined2 *)(puVar28 + 6) = uVar4;
          *param_10 = *param_10 + 1;
          uVar29 = uStack_90;
        }
      }
LAB_:
      uStack_90 = uVar29 + 1;
      uStack_88 = uStack_88 + 1;
    } while (uStack_88 < lStack_68);
  }
  if (plStack_38 != (longlong *)0x0) {
    pcVar5 = *(code **)(*plStack_38 + 8);
    *(undefined8 *)(puVar27 + -8) = 0x101711;
    (*pcVar5)();
  }
  uVar33 = uStack_30 ^ (ulonglong)&uStack_98;
  *(undefined8 *)(puVar27 + -8) = 0x10171d;
  func_0x(uVar33);
  return;
}

