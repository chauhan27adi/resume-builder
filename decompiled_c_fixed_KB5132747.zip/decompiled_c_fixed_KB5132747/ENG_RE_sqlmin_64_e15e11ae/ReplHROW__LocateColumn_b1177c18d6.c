
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,byte *param_2,uint *param_3,undefined8 param_4,undefined4 *param_5)

{
  undefined4 uVar1;
  byte *pbVar2;
  ushort *puVar3;
  bool bVar4;
  byte bVar5;
  char cVar6;
  ushort uVar7;
  int iVar8;
  int iVar9;
  undefined8 uVar10;
  ushort uVar11;
  uint uVar12;
  short sVar13;
  longlong lVar14;
  ulonglong uVar15;
  longlong lVar16;
  uint *puVar17;
  uint uVar18;
  uint *puVar19;
  ulonglong uVar20;
  longlong *plVar21;
  ulonglong uVar22;
  uint uVar23;
  ushort *puVar24;
  uint uVar25;
  bool bVar26;
  undefined auStack_258 [32];
  undefined8 uStack_238;
  undefined8 uStack_230;
  undefined8 uStack_228;
  undefined8 uStack_220;
  undefined4 uStack_218;
  uint uStack_208;
  ushort uStack_204;
  ushort uStack_202;
  uint *puStack_200;
  ushort uStack_1f8;
  uint uStack_1f4;
  uint uStack_1f0;
  uint *puStack_1e8;
  uint uStack_1e0;
  uint uStack_1dc;
  undefined4 *puStack_1d8;
  undefined auStack_1d0 [8];
  undefined auStack_1c8 [8];
  longlong *plStack_1c0;
  undefined8 uStack_1b8;
  undefined8 uStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined4 uStack_198;
  undefined uStack_194;
  undefined8 uStack_190;
  longlong lStack_188;
  short *psStack_180;
  undefined8 uStack_178;
  undefined4 uStack_170;
  undefined8 uStack_168;
  uint auStack_158 [68];
  ulonglong uStack_48;
  
  uStack_168 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_258;
  puStack_1d8 = param_5;
  puVar17 = (uint *)0x0;
  bVar4 = false;
  uVar25 = 0;
  *param_5 = 0;
  uStack_208 = 0;
  uVar11 = 0;
  uStack_204 = 0;
  uStack_202 = uStack_202 & 0xffe0;
  puStack_200 = (uint *)0x0;
  uStack_1dc = 0;
  lVar16 = *(longlong *)(param_1 + 0x20);
  puStack_1e8 = param_3;
  if (*(uint *)(lVar16 + 0x230) == 0) {
LAB_:
    uStack_238 = *(uint **)(param_1 + 0x24);
    func_0x(0x49a1,0x10,1,*(int *)(param_2 + 0x20));
LAB_:
    func_0x(uStack_48 ^ (ulonglong)auStack_258);
    return;
  }
  puVar19 = puVar17;
  while ((*(int *)(*(longlong *)(lVar16 + 0x238) + 0x20 + (longlong)puVar19 * 0x30) !=
          *(int *)(param_2 + 0x20) ||
         (plVar21 = *(longlong **)(lVar16 + 0x250), plVar21 == (longlong *)0x0))) {
LAB_:
    uVar12 = (int)puVar19 + 1;
    puVar19 = (uint *)(ulonglong)uVar12;
    if (*(uint *)(lVar16 + 0x230) <= uVar12) goto LAB_;
  }
  while (*plVar21 != *(longlong *)(param_1 + 0x24)) {
    plVar21 = (longlong *)plVar21[7];
    if (plVar21 == (longlong *)0x0) goto LAB_;
  }
  lVar14 = (longlong)puVar19 * 0x30 + plVar21[2];
  uStack_1f0 = *(uint *)(lVar14 + 0x24);
  uStack_1f8 = *(ushort *)(plVar21[5] + (longlong)puVar19 * 2);
  bVar5 = *(byte *)(lVar14 + 0x28);
  lVar16 = (longlong)puVar19 * 0x106 + *(longlong *)(lVar16 + 0x228);
  uVar7 = *(ushort *)(lVar16 + 0x102);
  uVar10 = (*_DAT_)();
  uStack_238 = (uint *)CONCAT44(uStack_238._4_4_,(uint)uVar7);
  uStack_230 = (uint *)lVar16;
  iVar8 = func_0x(auStack_158,0x80,0x18de558,uVar10);
  if (iVar8 < 0) {
    uStack_228 = (uint *)CONCAT44(uStack_228._4_4_,iVar8);
    uStack_230 = (uint *)CONCAT44(uStack_230._4_4_,0x51);
    uStack_238 = (uint *)0x1a87958;
    (*_DAT_)(4,7,0x10,1);
  }
  uVar12 = (uint)uVar7 + (uint)uVar7;
  if (0x100 < (uint)uVar7 + (uint)uVar7) {
    uVar12 = 0x100;
  }
  uStack_208 = uStack_1f0;
  if ((uStack_1f0 & 0xc0000000) == 0x80000000) {
    uVar11 = uStack_202 & 0xfff0;
  }
  else {
    uStack_204 = uStack_1f8;
    if (*param_2 == 0x68) {
      uVar11 = 8;
    }
    uVar11 = uStack_202 & 0xfff0 | (ushort)(bVar5 & 7) | uVar11;
  }
  uStack_202 = uVar11 & 0xffef;
  if ((*(short *)(param_2 + 0x10) != -1) &&
     (*(char *)((ulonglong)*(byte *)((ulonglong)*param_2 + 0x1815270) + 0x21cc308) == '\0')) {
    *puStack_1d8 = 0;
    iVar8 = func_0x(param_1,&uStack_208);
    if (iVar8 == 0) {
      iVar8 = func_0x(param_1,param_2,&uStack_208);
      if (iVar8 != 0) {
        uVar11 = *(ushort *)(param_2 + 0x10);
        if ((uVar11 == 0xffff) ||
           (*(char *)((ulonglong)*(byte *)((ulonglong)*param_2 + 0x1815270) + 0x21cc308) != '\0')) {
          uVar11 = 0x1fa4;
        }
        if ((uVar11 != 0) && (*(uint *)(param_1 + 0x30) < (uint)uVar11)) {
          if (*(longlong *)(param_1 + 0x2c) != 0) {
            (*_DAT_)(*(longlong *)(param_1 + 0x2c),1);
            uStack_238 = (uint *)0x0;
            func_0x(**(undefined2 **)(param_1 + 0x20),0x32,0);
          }
          uStack_230 = (uint *)CONCAT71(uStack_230._1_7_,6);
          uStack_238 = (uint *)CONCAT44(uStack_238._4_4_,0xea);
          uVar10 = (*_DAT_)(uVar11,_DAT_,1,0x1a87958);
          *(undefined8 *)(param_1 + 0x2c) = uVar10;
          uStack_238 = (uint *)0x0;
          func_0x(**(undefined2 **)(param_1 + 0x20),0x32,uVar11);
          if (*(longlong *)(param_1 + 0x2c) == 0) {
            uStack_238 = (uint *)0x0;
            (*_DAT_)(1,0x1c3a468,0x1c142e0,0xec);
          }
          *(uint *)(param_1 + 0x30) = (uint)uVar11;
        }
      }
      uStack_178 = *(undefined8 *)(param_1 + 0x2c);
      uStack_170 = *(undefined4 *)(param_1 + 0x30);
      sVar13 = *(short *)(param_2 + 0x10);
      if ((sVar13 == -1) ||
         (*(char *)((ulonglong)*(byte *)((ulonglong)*param_2 + 0x1815270) + 0x21cc308) != '\0')) {
        sVar13 = 0x1fa4;
      }
      uStack_218 = 0;
      uStack_220 = 0;
      uStack_228 = &uStack_1dc;
      uStack_230 = puStack_1e8;
      uStack_238 = (uint *)CONCAT44(uStack_238._4_4_,(uint)(uStack_204 != 0));
      psStack_180 = param_1;
      func_0x(&psStack_180,param_2,&uStack_208,sVar13);
    }
    else {
      lVar16 = *(longlong *)(param_1 + 0x1c);
      if (lVar16 == 0) {
        uStack_238 = (uint *)0x0;
        (*_DAT_)(1,0x1c3a448,0x1c142e0,0xca);
        lVar16 = *(longlong *)(param_1 + 0x1c);
      }
      uVar1 = *(undefined4 *)(param_2 + 0x20);
      *(uint *)(lVar16 + 0x88) = uVar12;
      *(undefined4 *)(lVar16 + 400) = uVar1;
      uVar10 = (*_DAT_)();
      uStack_238 = (uint *)(ulonglong)(uVar12 >> 1);
      uStack_230 = auStack_158;
      iVar8 = func_0x(lVar16 + 0x8c,0x81,0x18de558,uVar10);
      if (iVar8 < 0) {
        uStack_228 = (uint *)CONCAT44(uStack_228._4_4_,iVar8);
        uStack_230 = (uint *)CONCAT44(uStack_230._4_4_,0x260);
        uStack_238 = (uint *)0x1a87958;
        (*_DAT_)(4,7,0x10,1);
      }
      iVar8 = *(int *)(param_1 + 0x28);
      lVar16 = *(longlong *)(param_1 + 0x1c);
      lVar14 = *(longlong *)(lVar16 + 0x10);
      if (lVar14 == 0) {
        *(undefined4 *)(lVar16 + 0x4c) = 1;
      }
      else {
        if (*(int *)(lVar14 + 0x78) != iVar8) {
          *(int *)(lVar14 + 0x78) = iVar8;
          *(undefined4 *)(lVar16 + 0x4c) = 1;
        }
        lVar14 = lVar16 + 0x58;
        if (iVar8 == 0) {
          lVar14 = lVar16 + 0x68;
        }
        *(longlong *)(lVar16 + 0x78) = lVar14;
      }
      lVar16 = *(longlong *)(lVar16 + 0x18);
      if ((lVar16 != 0) && (*(int *)(lVar16 + 0x30) != iVar8)) {
        *(int *)(lVar16 + 0x30) = iVar8;
      }
      *(uint *)(*(longlong *)(param_1 + 0x1c) + 0x54) = *(uint *)(param_2 + 0x28) >> 0xb & 1;
      func_0x(*(undefined8 *)(param_1 + 0x1c),uStack_1f0,uStack_1f8,puStack_1e8);
    }
    goto LAB_;
  }
  *puStack_1d8 = 1;
  iVar8 = func_0x(param_1,&uStack_208);
  lVar16 = *(longlong *)(param_1 + 0x1c);
  if (lVar16 == 0) {
    uStack_238 = (uint *)0x0;
    (*_DAT_)(1,0x1c3a448,0x1c142e0,0xa9);
    lVar16 = *(longlong *)(param_1 + 0x1c);
  }
  uVar1 = *(undefined4 *)(param_2 + 0x20);
  *(uint *)(lVar16 + 0x88) = uVar12;
  *(undefined4 *)(lVar16 + 400) = uVar1;
  uVar10 = (*_DAT_)();
  uStack_238 = (uint *)(ulonglong)(uVar12 >> 1);
  uStack_230 = auStack_158;
  iVar9 = func_0x(lVar16 + 0x8c,0x81,0x18de558,uVar10);
  if (iVar9 < 0) {
    uStack_228 = (uint *)CONCAT44(uStack_228._4_4_,iVar9);
    uStack_230 = (uint *)CONCAT44(uStack_230._4_4_,0x260);
    uStack_238 = (uint *)0x1a87958;
    (*_DAT_)(4,7,0x10,1);
  }
  iVar9 = *(int *)(param_1 + 0x28);
  lVar16 = *(longlong *)(param_1 + 0x1c);
  lVar14 = *(longlong *)(lVar16 + 0x10);
  if (lVar14 == 0) {
    *(undefined4 *)(lVar16 + 0x4c) = 1;
  }
  else {
    if (*(int *)(lVar14 + 0x78) != iVar9) {
      *(int *)(lVar14 + 0x78) = iVar9;
      *(undefined4 *)(lVar16 + 0x4c) = 1;
    }
    lVar14 = 0x58;
    if (iVar9 == 0) {
      lVar14 = 0x68;
    }
    *(longlong *)(lVar16 + 0x78) = lVar14 + lVar16;
  }
  lVar16 = *(longlong *)(lVar16 + 0x18);
  if ((lVar16 != 0) && (*(int *)(lVar16 + 0x30) != iVar9)) {
    *(int *)(lVar16 + 0x30) = iVar9;
  }
  *(uint *)(*(longlong *)(param_1 + 0x1c) + 0x54) = *(uint *)(param_2 + 0x28) >> 0xb & 1;
  if (iVar8 != 0) {
    func_0x(*(undefined8 *)(param_1 + 0x1c),uStack_1f0,uStack_1f8,puStack_1e8);
    goto LAB_;
  }
  uStack_1f4 = 0;
  uVar11 = *(ushort *)(param_2 + 0x10);
  if ((uVar11 == 0xffff) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*param_2 + 0x1815270) + 0x21cc308) != '\0')) {
    uVar11 = 0x1fa4;
  }
  bVar26 = uStack_204 != 0;
  if (*param_1 != 0) {
    uStack_1e0 = 0;
    uStack_238 = &uStack_1e0;
    puVar19 = (uint *)func_0x(param_1 + 1,&uStack_208);
    uVar25 = uStack_1f4;
    if ((((*param_1 != 0) && (plVar21 = *(longlong **)(param_1 + 8), plVar21 != (longlong *)0x0)) &&
        (*plVar21 != 0)) && (((uStack_202 & 8) == 0 && ((uStack_1e0 & 1) == 0)))) {
      if ((puVar19 == (uint *)0x0) || (puVar19 == (uint *)0x1814c50)) {
        uStack_1f4 = 0;
        puVar19 = puVar17;
        uVar25 = uStack_1f4;
      }
      else {
        uStack_220 = CONCAT44(uStack_220._4_4_,uStack_1e0);
        uStack_228 = &uStack_1f4;
        uStack_230 = (uint *)((ulonglong)uStack_230 & 0xffffffff00000000);
        uStack_238 = (uint *)0x0;
        puVar19 = (uint *)func_0x(plVar21,&uStack_208,puVar19,uStack_1f4);
        uVar25 = uStack_1f4;
      }
    }
    goto LAB_;
  }
  if ((uStack_208 & 0xc0000000) == 0x80000000) {
    iVar8 = func_0x(param_1 + 1);
    if (iVar8 == 0) {
      puVar19 = (uint *)0x0;
      uVar25 = uStack_1f4;
    }
    else {
      puVar19 = (uint *)func_0x(param_1 + 0x15,&uStack_208,&uStack_1f4,auStack_1d0);
      uVar25 = uStack_1f4;
    }
    goto LAB_;
  }
  if ((bVar26) || ((uStack_202 & 0x10) != 0)) {
    pbVar2 = *(byte **)(param_1 + 4);
    if ((*pbVar2 & 0x10) == 0) {
      if ((1 << (*pbVar2 & 0xe) & 0x1105U) != 0) goto LAB_;
      bVar4 = true;
      uVar12 = uVar25;
LAB_:
      if (bVar26) goto LAB_;
    }
    else {
      uVar12 = *(uint *)(param_1 + 8);
      if ((int)uVar12 <= (int)uStack_208) {
LAB_:
        uVar12 = ~(uint)(uStack_202 >> 4) & 1;
        goto LAB_;
      }
      if ((uint)*(ushort *)(pbVar2 + uVar12) < (uint)uStack_204) goto LAB_;
      if (!bVar26) goto LAB_;
      uVar18 = uStack_204 - 1;
      uVar12 = pbVar2[(ulonglong)uVar12 + (ulonglong)(uVar18 >> 3) + 2] >> ((byte)uVar18 & 7) & 1;
      bVar4 = true;
LAB_:
      puVar19 = puVar17;
      if (uVar12 != 0) goto LAB_;
    }
    if ((!bVar4) && ((uStack_202 & 0x10) != 0)) {
      puVar19 = puStack_200 + 1;
      uVar25 = *puStack_200;
      goto LAB_;
    }
  }
LAB_:
  if (-1 < (int)uStack_208) {
    if ((uStack_202 & 8) != 0) {
      puVar19 = (uint *)0x1814c50;
      if ((*(byte *)((longlong)(int)uStack_208 + *(longlong *)(param_1 + 4)) &
          (byte)(1 << ((byte)uStack_202 & 7))) == 0) {
        puVar19 = (uint *)0x1814c51;
      }
      uStack_1f4 = 1;
      uVar25 = uStack_1f4;
      goto LAB_;
    }
    uVar12 = (uint)uVar11;
    if ((uStack_202 & 0x10) != 0) {
      bVar5 = **(byte **)(param_1 + 4);
      if ((bVar5 & 0x10) == 0) {
        if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar19 = puStack_200 + 1;
          uVar25 = *puStack_200;
          if ((uVar12 != 0) && (uVar25 != uVar12)) {
            uStack_238 = (uint *)0x0;
            (*_DAT_)(1,0x1c3e400,0x1c3cd68,0x381);
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_208) ||
              (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < uStack_204))
      goto LAB_;
    }
    puVar19 = (uint *)((longlong)(int)uStack_208 + *(longlong *)(param_1 + 4));
    uVar25 = uVar12;
    goto LAB_;
  }
  if (*(int *)(param_1 + 2) != 0) goto LAB_;
  param_1[1] = 0;
  uVar12 = *(uint *)(param_1 + 8);
  uVar15 = (ulonglong)uVar12;
  *(uint *)(param_1 + 10) = uVar12;
  pbVar2 = *(byte **)(param_1 + 4);
  bVar5 = *pbVar2;
  if ((bVar5 & 0x10) != 0) {
    uVar12 = uVar12 + 2 + (*(ushort *)(pbVar2 + uVar15) + 7 >> 3);
    uVar15 = (ulonglong)uVar12;
    *(uint *)(param_1 + 10) = uVar12;
    bVar5 = *pbVar2;
  }
  if ((bVar5 & 0x20) == 0) {
    *(int *)(param_1 + 2) = (int)uVar15;
    param_1[0xe] = 0;
    *(int *)(param_1 + 0xc) = (int)uVar15;
    goto LAB_;
  }
  puVar24 = (ushort *)(pbVar2 + uVar15);
  uVar11 = *puVar24;
  param_1[0xe] = uVar11;
  if (uVar11 == 0) {
    cVar6 = func_0x(0x21a05b0);
    if (((cVar6 != '\0') && (lVar16 = func_0x(), lVar16 != 0)) &&
       (*(char *)(lVar16 + 0x499) != '\0')) {
      cVar6 = func_0x(0x21a05b0);
      if (cVar6 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3eb);
      }
      else {
        uStack_238 = (uint *)0x0;
        (*_DAT_)(1,0x1a8ffbc,0x1bb00a8,0x80f);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 4),3);
    uVar15 = (ulonglong)*(uint *)(param_1 + 10);
    uVar11 = param_1[0xe];
  }
  uVar12 = (int)uVar15 + (uVar11 + 1) * 2;
  *(uint *)(param_1 + 0xc) = uVar12;
  if (0x1f9e < uVar12) {
    cVar6 = func_0x(0x21a05b0);
    if (((cVar6 != '\0') && (lVar16 = func_0x(), lVar16 != 0)) &&
       (*(char *)(lVar16 + 0x499) != '\0')) {
      cVar6 = func_0x(0x21a05b0);
      if (cVar6 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3ec);
      }
      else {
        uStack_238 = (uint *)0x0;
        (*_DAT_)(1,0x1a8ffbc,0x1bb00a8,0x816);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 4),4);
    uVar11 = param_1[0xe];
    uVar12 = *(uint *)(param_1 + 0xc);
  }
  uVar15 = (ulonglong)uVar11;
  uVar11 = puVar24[uVar15];
  *(uint *)(param_1 + 2) = uVar11 & 0x7fff;
  if ((uVar11 & 0x7fff) < uVar12) {
    cVar6 = func_0x(0x21a05b0);
    if (((cVar6 != '\0') && (lVar16 = func_0x(), lVar16 != 0)) &&
       (*(char *)(lVar16 + 0x499) != '\0')) {
      cVar6 = func_0x(0x21a05b0);
      if (cVar6 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3ec);
      }
      else {
        uStack_238 = (uint *)0x0;
        (*_DAT_)(1,0x1a8ffbc,0x1bb00a8,0x81d);
      }
    }
    func_0x(*(undefined8 *)(param_1 + 4),4);
    uVar12 = *(uint *)(param_1 + 0xc);
    uVar15 = (ulonglong)(ushort)param_1[0xe];
  }
  puVar19 = puVar17;
  puVar3 = puVar24;
  if ((short)uVar15 != 0) {
    do {
      uVar18 = puVar3[1] & 0x7fff;
      if ((uVar18 < uVar12) || (*(uint *)(param_1 + 2) < uVar18)) {
        cVar6 = func_0x(0x21a05b0);
        if ((cVar6 != '\0') &&
           ((lVar16 = func_0x(), lVar16 != 0 && (*(char *)(lVar16 + 0x499) != '\0'))
           )) {
          cVar6 = func_0x(0x21a05b0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            uStack_238 = (uint *)0x0;
            (*_DAT_)(1,0x1a8ffbc,0x1bb00a8,0x82a);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
      }
      uVar23 = (int)puVar19 + 1;
      uVar15 = (ulonglong)(ushort)param_1[0xe];
      puVar19 = (uint *)(ulonglong)uVar23;
      puVar3 = puVar3 + 1;
      uVar12 = uVar18;
    } while ((int)uVar23 < (int)(uint)(ushort)param_1[0xe]);
  }
  if (-1 < (short)puVar24[(ulonglong)((int)uVar15 - 1) + 1]) goto LAB_;
  lVar16 = *(longlong *)(param_1 + 4);
LAB_:
  uVar12 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar16 + uVar15 * 2) & 0x7fff;
  if ((int)uVar15 == 1) {
    uVar18 = *(uint *)(param_1 + 0xc);
    uVar23 = uVar18;
LAB_:
    if ((uVar12 < uVar18) || (*(uint *)(param_1 + 2) < uVar12)) goto LAB_;
  }
  else {
    uVar18 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar16 + -2 + uVar15 * 2) & 0x7fff;
    uVar23 = *(uint *)(param_1 + 0xc);
    if (uVar23 <= uVar18) goto LAB_;
LAB_:
    func_0x(lVar16,7);
    uVar23 = *(uint *)(param_1 + 0xc);
  }
  if ((uVar23 <= uVar18) && (uVar18 <= *(uint *)(param_1 + 2))) {
    lVar16 = *(longlong *)(param_1 + 4);
    if (*(ushort *)(lVar16 + (ulonglong)uVar18) != 5) goto code_r0x00100bf9;
    param_1[1] = param_1[1] | 2;
    param_1[0xe] = param_1[0xe] + -1;
    uVar15 = (ulonglong)(uVar18 & 0xffff);
    param_1[0x15] = (short)uVar18;
    uVar11 = param_1[0x16] & 0xc7ffU;
    if ((*(ushort *)(lVar16 + 2 + uVar15) >> 0xe & 1) != 0) {
      uVar11 = *(ushort *)(lVar16 + 2 + uVar15) & 0x3800 | param_1[0x16] & 0xc7ffU;
    }
    param_1[0x16] = uVar11;
    uVar7 = (uVar11 ^ *(ushort *)(lVar16 + 2 + uVar15)) & 0x7ff ^ uVar11;
    param_1[0x16] = uVar7;
    uVar22 = *(ulonglong *)(param_1 + 4);
    uVar20 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar22 + (uVar11 >> 0xb & 7) * 2 + uVar15;
    if (uVar20 < uVar22 + uVar15) {
      func_0x(uVar22 + uVar15,0x19);
      uVar7 = param_1[0x16];
      uVar15 = (ulonglong)(ushort)param_1[0x15];
      uVar22 = (ulonglong)*(uint *)(param_1 + 4);
    }
    if (uVar12 - uVar18 < (((uVar7 & 0x7ff) * 2 - (int)uVar15) - (int)uVar22) + (int)uVar20) {
      func_0x(uVar15 + *(longlong *)(param_1 + 4),0x19);
      uVar7 = param_1[0x16];
    }
    if (((uVar7 & 0x3800) != 0) &&
       (puVar24 = (ushort *)(*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
       (uVar7 & 0x3800) != 0)) {
      do {
        if ((uVar7 & 0x7ff) < (*puVar24 & 0x7ff)) {
          func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),0x1a);
          uVar7 = param_1[0x16];
        }
        uVar12 = (int)puVar17 + 1;
        puVar17 = (uint *)(ulonglong)uVar12;
        puVar24 = puVar24 + 1;
      } while ((int)uVar12 < (int)(uVar7 >> 0xb & 7));
    }
LAB_:
    uVar15 = (ulonglong)*(uint *)(param_1 + 2);
    goto LAB_;
  }
  goto LAB_;
code_r0x00100bf9:
  if (*(ushort *)(lVar16 + (ulonglong)uVar18) < 0x400) goto LAB_;
  param_1[1] = param_1[1] | 1;
  uVar11 = param_1[0xe] - 1;
  param_1[0xe] = uVar11;
  if (uVar11 == 0) goto LAB_;
  uVar15 = (ulonglong)uVar11;
  if (-1 < (short)puVar24[(ulonglong)(uVar11 - 1) + 1]) {
    uVar15 = (ulonglong)*(uint *)(param_1 + 2);
LAB_:
    if ((**(byte **)(param_1 + 4) & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = (int)uVar15;
      *(int *)(param_1 + 2) = (int)uVar15 + 0xe;
      uVar10 = func_0x(param_1 + 1);
      func_0x(uVar10,auStack_1c8);
      iVar8 = func_0x(auStack_1c8);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar8;
      uVar15 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar8 = (int)uVar15;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar15 + *(longlong *)(param_1 + 4))) {
      cVar6 = func_0x(0x21a05b0);
      if ((cVar6 != '\0') &&
         ((lVar16 = func_0x(), lVar16 != 0 && (*(char *)(lVar16 + 0x499) != '\0'))))
      {
        cVar6 = func_0x(0x21a05b0);
        if (cVar6 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          uStack_238 = (uint *)0x0;
          (*_DAT_)(1,0x1a8ffbc,0x1bb00a8,0x886);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar8 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar8 - 1U) {
      cVar6 = func_0x(0x21a05b0);
      if (((cVar6 != '\0') && (lVar16 = func_0x(), lVar16 != 0)) &&
         (*(char *)(lVar16 + 0x499) != '\0')) {
        cVar6 = func_0x(0x21a05b0);
        if (cVar6 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          uStack_238 = (uint *)0x0;
          (*_DAT_)(1,0x1a8ffbc,0x1bb00a8,0x88b);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
LAB_:
    sVar13 = -(short)uStack_208;
    if ((uStack_202 & 0x10) == 0) {
LAB_:
      lVar16 = (longlong)sVar13;
      puVar19 = *(uint **)(param_1 + 4);
      if ((uint)(int)sVar13 <= (uint)(ushort)param_1[0xe]) {
        uVar25 = *(uint *)(param_1 + 10);
        if (sVar13 == 1) {
          uVar12 = *(uint *)(param_1 + 0xc);
          uVar25 = *(ushort *)((longlong)puVar19 + lVar16 * 2 + (ulonglong)uVar25) & 0x7fff;
LAB_:
          if ((uVar25 < uVar12) || (*(uint *)(param_1 + 2) < uVar25)) goto LAB_;
        }
        else {
          uVar12 = *(ushort *)((longlong)puVar19 + lVar16 * 2 + ((ulonglong)uVar25 - 2)) & 0x7fff;
          uVar25 = *(ushort *)((longlong)puVar19 + lVar16 * 2 + (ulonglong)uVar25) & 0x7fff;
          puVar19 = *(uint **)(param_1 + 4);
          if (*(uint *)(param_1 + 0xc) <= uVar12) goto LAB_;
LAB_:
          func_0x(puVar19,7);
          puVar19 = *(uint **)(param_1 + 4);
        }
        puVar19 = (uint *)((longlong)puVar19 + (ulonglong)uVar12);
        uVar25 = uVar25 - uVar12;
      }
    }
    else {
      bVar5 = **(byte **)(param_1 + 4);
      if ((bVar5 & 0x10) == 0) {
        if ((1 << (bVar5 & 0xe) & 0x1105U) == 0) goto LAB_;
      }
      else if (((int)uStack_208 < (int)*(uint *)(param_1 + 8)) &&
              (uStack_204 <= *(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8))))
      goto LAB_;
      puVar19 = puStack_200 + 1;
      uVar25 = *puStack_200;
    }
LAB_:
    uStack_1f4 = uVar25;
    uVar25 = uStack_1f4;
    uVar11 = uStack_1f8;
    lVar16 = *(longlong *)(param_1 + 0x1c);
    *(undefined4 *)(lVar16 + 0x50) = 1;
    if (puVar19 != (uint *)0x0) {
      iVar8 = func_0x(lVar16);
      if (iVar8 == 0) {
        uStack_238 = (uint *)0x1c3a300;
        (*_DAT_)(1,0x1c118b0,0x1c142e0,0x33d);
        *puStack_1e8 = 0;
        goto LAB_;
      }
      func_0x(lVar16);
      uStack_1a0 = *(undefined8 *)(lVar16 + 8);
      uStack_1a8 = *(undefined8 *)(lVar16 + 0x10);
      uStack_194 = 0;
      uStack_198 = 0;
      uStack_190 = 0;
      uStack_1b0 = 0;
      uStack_1b8 = 0x1809c88;
      lStack_188 = lVar16;
      iVar8 = func_0x(&uStack_1b8,puVar19,uVar25);
      if (iVar8 == 0) {
        uStack_228 = (uint *)CONCAT44(uStack_228._4_4_,uVar25);
        uStack_238 = (uint *)0x1c3a320;
        uStack_230 = puVar19;
        (*_DAT_)(1,0x1c118b0,0x1c142e0,0x34b);
        uStack_1b8 = 0x1809ba0;
        *puStack_1e8 = 0;
        goto LAB_;
      }
      *(uint *)(lVar16 + 0x20) = (uint)uVar11;
      *(uint *)(lVar16 + 0x24) = uStack_1f0;
      *(undefined4 *)(lVar16 + 0x4c) = 0;
      uStack_1b8 = 0x1809ba0;
      if (*(longlong *)(lVar16 + 0x30) == 0) {
        uStack_238 = (uint *)0x1c3a378;
        (*_DAT_)(1,0x1c118b0,0x1c142e0,0x35a);
        *puStack_1e8 = 0;
        goto LAB_;
      }
      plStack_1c0 = (longlong *)0x0;
      plStack_1c0 = (longlong *)
                    (**(code **)(**(longlong **)(lVar16 + 0x30) + 8))
                              (*(longlong **)(lVar16 + 0x30),0);
      if (plStack_1c0 != (longlong *)0x0) {
        (**(code **)(*plStack_1c0 + 0x10))(plStack_1c0);
        *puStack_1e8 = *(uint *)(lVar16 + 0x38);
        goto LAB_;
      }
      uStack_238 = (uint *)0x1c3a2d0;
      (*_DAT_)(1,0x1c118b0,0x1c142e0,0x364);
    }
    *puStack_1e8 = 0;
    goto LAB_;
  }
  goto LAB_;
}

