
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,int param_3,longlong param_4,undefined2 param_5)

{
  byte *pbVar1;
  undefined2 uVar2;
  short sVar3;
  undefined8 uVar4;
  longlong *plVar5;
  ushort uVar6;
  uint **ppuVar7;
  char cVar8;
  undefined4 uVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  longlong lVar15;
  longlong *plVar16;
  longlong lVar17;
  uint *puVar18;
  longlong lVar19;
  short *psVar20;
  code *UNRECOVERED_JUMPTABLE_00;
  undefined8 unaff_RBX;
  byte **ppbVar21;
  uint uVar22;
  longlong lVar23;
  longlong lVar24;
  ulonglong uVar25;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [8];
  uint uStack_49a4;
  int iStack_4998;
  short sStack_4994;
  undefined2 uStack_4990;
  undefined4 uStack_498c;
  undefined8 uStack_4988;
  undefined8 uStack_4980;
  undefined8 uStack_4972;
  undefined8 uStack_4968;
  int iStack_4958;
  undefined4 uStack_4950;
  undefined2 uStack_494c;
  undefined8 uStack_4948;
  undefined4 uStack_4940;
  uint uStack_493c;
  undefined8 uStack_4938;
  ushort uStack_4930;
  undefined8 uStack_4928;
  undefined4 uStack_4920;
  undefined2 uStack_491c;
  undefined2 uStack_491a;
  undefined8 uStack_4918;
  ushort uStack_4910;
  undefined auStack_4908 [4];
  undefined4 uStack_4904;
  undefined4 uStack_4900;
  undefined2 uStack_48fc;
  undefined4 uStack_48f8;
  undefined2 uStack_48f4;
  undefined8 uStack_48f0;
  undefined2 uStack_48e8;
  undefined8 uStack_48e0;
  undefined2 uStack_48d8;
  undefined8 uStack_48d0;
  undefined2 uStack_48c8;
  undefined8 uStack_48c0;
  ushort uStack_48b8;
  undefined auStack_48b0 [4];
  undefined auStack_48ac [4];
  undefined auStack_48a8 [8];
  undefined8 auStack_48a0 [2];
  longlong *plStack_4890;
  uint uStack_4888;
  undefined8 uStack_4884;
  longlong lStack_4870;
  undefined8 auStack_4868 [2];
  undefined8 uStack_4858;
  undefined4 uStack_4850;
  undefined4 uStack_4840;
  undefined uStack_4838;
  undefined4 uStack_4830;
  undefined auStack_4828 [16];
  undefined2 uStack_4800;
  undefined4 uStack_47fc;
  undefined8 uStack_47f8;
  undefined8 uStack_47f0;
  undefined8 uStack_47e2;
  undefined8 uStack_47d8;
  undefined8 uStack_47c8;
  undefined auStack_47b8 [8];
  undefined4 uStack_47b0;
  undefined4 uStack_47a8;
  uint **ppuStack_47a0;
  undefined *puStack_4798;
  undefined8 uStack_4790;
  uint *puStack_4788;
  undefined4 uStack_4780;
  undefined4 uStack_477c;
  longlong lStack_4778;
  undefined4 uStack_4770;
  undefined4 uStack_476c;
  longlong lStack_4768;
  undefined4 uStack_4760;
  undefined4 uStack_475c;
  short *psStack_4758;
  int iStack_4750;
  undefined4 uStack_474c;
  short *psStack_4748;
  int iStack_4740;
  undefined4 uStack_473c;
  undefined8 uStack_4738;
  undefined4 uStack_4730;
  undefined4 uStack_472c;
  undefined auStack_4728 [448];
  undefined8 uStack_4568;
  undefined8 uStack_4560;
  uint uStack_4558;
  short sStack_4554;
  int iStack_4552;
  undefined uStack_454e;
  undefined uStack_454d;
  short sStack_4518;
  undefined4 uStack_4514;
  byte *pbStack_4510;
  byte **ppbStack_4508;
  undefined8 uStack_44fa;
  undefined2 uStack_44f2;
  undefined2 uStack_44f0;
  undefined6 uStack_44ee;
  int iStack_44e4;
  undefined auStack_44e0 [16];
  undefined auStack_44d0 [8];
  undefined8 uStack_44c8;
  undefined8 uStack_44c0;
  undefined6 uStack_44b8;
  undefined2 uStack_44b2;
  undefined6 uStack_44b0;
  undefined2 uStack_44aa;
  undefined8 uStack_44a8;
  undefined auStack_44a0 [16];
  undefined auStack_4490 [16];
  undefined auStack_4480 [16];
  undefined8 uStack_4470;
  undefined auStack_4468 [16];
  undefined2 uStack_4458;
  undefined4 uStack_4454;
  undefined8 uStack_4450;
  undefined8 uStack_4448;
  undefined8 uStack_443a;
  undefined8 uStack_4430;
  undefined8 uStack_4420;
  undefined8 uStack_4408;
  undefined4 uStack_4400;
  undefined2 uStack_43f6;
  short asStack_43e8 [24];
  short asStack_43b8 [8632];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  iStack_4958 = param_3;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  uStack_47c8 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004a10 + lVar15) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15);
  sStack_4518 = -1;
  pbStack_4510 = (byte *)0x0;
  uStack_4514 = 0;
  uStack_44fa = 0;
  uStack_44f0 = 0;
  uStack_44ee = 0;
  ppbStack_4508 = (byte **)0x0;
  iStack_44e4 = 0xffffffff;
  uStack_4990 = 0xffff;
  uStack_4988 = 0;
  uStack_498c = 0;
  uStack_4972 = 0;
  uStack_4968 = 0;
  uStack_4980 = 0;
  uStack_4800 = 0xffff;
  uStack_47f8 = 0;
  uStack_47fc = 0;
  uStack_47e2 = 0;
  uStack_47d8 = 0;
  uStack_47f0 = 0;
  auStack_4828 = ZEXT816(0);
  auStack_4468 = ZEXT816(0);
  uStack_4458 = 0xffff;
  uStack_4450 = 0;
  uStack_4454 = 0;
  uStack_443a = 0;
  uStack_4430 = 0;
  uStack_4448 = 0;
  uStack_4420 = 0;
  uStack_4408 = 0;
  uStack_4400 = 0;
  uStack_43f6 = 0;
  uStack_4920 = *(undefined4 *)(param_4 + 4);
  uStack_491c = *(undefined2 *)(param_4 + 8);
  uStack_491a = param_5;
  *(undefined8 *)(&stack0x00000040 + lVar15) = 0;
  uStack_49a4 = 0;
  (&stack0x00000038)[lVar15] = 5;
  auStack_4868[0] = 0xac2760;
  uStack_4858 = 0;
  uStack_4850 = 0;
  uStack_4840 = 0xffffffff;
  uStack_4830 = 0x80000000;
  uStack_4838 = 0;
  uVar2 = *(undefined2 *)(param_2 + 2);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001b6;
  lStack_4870 = param_1;
  plVar16 = (longlong *)func_0x(uVar2);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001c8;
  plStack_4890 = plVar16;
  func_0x(param_1);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001cd;
  uVar9 = func_0x();
  *(undefined4 *)((longlong)auStackX_8 + lVar15 + 0x18) = 0;
  *(undefined4 *)((longlong)auStackX_8 + lVar15 + 0x10) = 0;
  *(undefined4 *)((longlong)auStackX_8 + lVar15 + 8) = 1;
  *(undefined4 *)((longlong)auStackX_8 + lVar15) = uVar9;
  *(undefined4 *)((longlong)auStackX_8 + lVar15 + -8) = 1;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
  *(undefined8 **)(&stack0xffffffffffffffe8 + lVar15) = auStack_48a0;
  uVar4 = *(undefined8 *)(param_1 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100216;
  func_0x(plVar16,uVar4,auStack_4868,&stack0x00000038 + lVar15);
  (&stack0xffffffffffffffe8)[lVar15] = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100233;
  func_0x(plVar16,auStack_48a0[0],(&stack0x00000038)[lVar15],0);
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plVar16 + 0x270);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10023f;
  (*UNRECOVERED_JUMPTABLE_00)(plVar16);
  iStack_4998 = *(int *)(param_2 + 4);
  sStack_4994 = *(short *)(param_2 + 8);
  lVar19 = plVar16[6];
  lVar17 = 0;
  uStack_4884 = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar23 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar23 != 0) && (lVar23 = **(longlong **)(lVar23 + 0x38), lVar23 != 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1002ad;
      iVar10 = (*_DAT_)(lVar23,0x337);
      if (iVar10 != 0) goto LAB_;
    }
    lVar23 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar23 != 0) {
      lVar17 = *(longlong *)(lVar23 + 0x60);
    }
  }
LAB_:
  lVar23 = *(longlong *)(lVar19 + 0x728);
  do {
    uStack_493c = 0;
    lVar24 = *(longlong *)(&stack0x00000040 + lVar15);
    if (lVar24 != 0) {
      iVar10 = (int)(short)(ushort)uStack_49a4;
      if (((*(ushort *)(lVar24 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
        plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
        if (((byte)*(undefined2 *)(lVar24 + 0x62) >> 3 & 1) != 0) {
          if (iVar10 == 3) {
            iVar10 = 4;
          }
          else if (iVar10 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)(&stack0x00000040 + lVar15) + 100) & 8) != 0) &&
              (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000040 + lVar15) + 0x90), lVar24 != 0)
              ) && (*(longlong *)(lVar24 + 0x758) != 0)) {
            uVar4 = *(undefined8 *)(lVar24 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100386;
            func_0x(uVar4,*(undefined8 *)(&stack0x00000040 + lVar15),iVar10);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar16 + 100) & 8) != 0)) &&
           ((2 < iVar10 &&
            (((*(uint *)((longlong)plVar16 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar24 = *plVar16, lVar24 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003c4;
          iVar11 = (*_DAT_)(lVar24,0x2000,2,auStack_48b0);
          if (iVar11 != 0) {
            LOCK();
            *(uint *)((longlong)plVar16 + 100) = *(uint *)((longlong)plVar16 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar16 + 100) = *(uint *)((longlong)plVar16 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003e6;
        func_0x(plVar16 + 0x13,iVar10);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100405;
          func_0x(plVar16,0,iVar10);
        }
        uStack_49a4 = uStack_49a4 & 0xffff0000;
        *(undefined8 *)(&stack0x00000040 + lVar15) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100321;
        func_0x(&stack0x00000040 + lVar15);
      }
    }
    if (*(longlong *)(lVar19 + 0x728) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100437;
      func_0x(&stack0x00000040 + lVar15,&iStack_4998,lVar19);
      lVar24 = *(longlong *)(&stack0x00000040 + lVar15);
      if (lVar24 != 0) {
        iVar10 = (int)(short)(ushort)uStack_49a4;
        if (((*(ushort *)(lVar24 + 0x62) & 0x400) == 0) || (iVar10 < 3)) {
          plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
          if (((byte)*(undefined2 *)(lVar24 + 0x62) >> 3 & 1) != 0) {
            if (iVar10 == 3) {
              iVar10 = 4;
            }
            else if (iVar10 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(&stack0x00000040 + lVar15) + 100) & 8) != 0) &&
                (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000040 + lVar15) + 0x90),
                lVar24 != 0)) && (*(longlong *)(lVar24 + 0x758) != 0)) {
              uVar4 = *(undefined8 *)(lVar24 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1004c6;
              func_0x(uVar4,*(undefined8 *)(&stack0x00000040 + lVar15),iVar10);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar16 + 100) & 8) != 0)) &&
             ((2 < iVar10 &&
              (((*(uint *)((longlong)plVar16 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar24 = *plVar16, lVar24 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100504;
            iVar11 = (*_DAT_)(lVar24,0x2000,2,auStack_48ac);
            if (iVar11 != 0) {
              LOCK();
              *(uint *)((longlong)plVar16 + 100) = *(uint *)((longlong)plVar16 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar16 + 100) = *(uint *)((longlong)plVar16 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100526;
          func_0x(plVar16 + 0x13,iVar10);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100545;
            func_0x(plVar16,0,iVar10);
          }
          uStack_49a4 = uStack_49a4 & 0xffff0000;
          *(undefined8 *)(&stack0x00000040 + lVar15) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100461;
          func_0x(&stack0x00000040 + lVar15);
        }
      }
    }
    uVar14 = uStack_49a4;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10055f;
    func_0x(lVar19,&iStack_4998);
    *(uint **)(&stack0xfffffffffffffff0 + lVar15) = &uStack_4888;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 4;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10058a;
    plVar16 = (longlong *)func_0x(_DAT_,lVar19,&iStack_4998,&uStack_493c);
    *(longlong **)(&stack0x00000040 + lVar15) = plVar16;
    if (lVar17 != 0) {
      uVar25 = (ulonglong)(*(uint *)(lVar17 + 0x500) & 0xf);
      if (*(longlong *)(lVar17 + 0x508 + uVar25 * 8) != *plVar16) {
        *(longlong *)(lVar17 + 0x508 + uVar25 * 8) = *plVar16;
        *(longlong *)(lVar17 + 0x500) = *(longlong *)(lVar17 + 0x500) + 1;
      }
    }
    uVar22 = uStack_49a4 & 0xff0004 | 4;
    uStack_49a4 = (uStack_493c >> 3 & 1) << 0x18 | uVar22;
    if (((lVar23 != 0) && (lVar17 != 0)) && (lVar17 == *(longlong *)(lVar19 + 0x1c38))) {
      *(longlong *)(lVar23 + 0x5b28) = *(longlong *)(lVar23 + 0x5b28) + 1;
      if ((int)uStack_4884 != 0) {
        *(longlong *)(lVar23 + 0x5b30) = *(longlong *)(lVar23 + 0x5b30) + 1;
        *(longlong *)(lVar23 + 0x5b38) = *(longlong *)(lVar23 + 0x5b38) + (ulonglong)uStack_4888;
        if (0xffffff < uStack_49a4) {
          *(longlong *)(lVar23 + 0x5b40) = *(longlong *)(lVar23 + 0x5b40) + 1;
          *(longlong *)(lVar23 + 0x5b48) = *(longlong *)(lVar23 + 0x5b48) + (ulonglong)uStack_4888;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10065a;
    cVar8 = func_0x(lVar19);
    iVar10 = 0;
    if (((cVar8 == '\0') || (*(char *)(lVar19 + 0x2050) == '\0')) ||
       ((iStack_4998 == 0 || ((iStack_4998 == 9 && (sStack_4994 == 1)))))) goto LAB_;
    lVar24 = **(longlong **)(&stack0x00000040 + lVar15);
    if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
      uStack_4918 = *(undefined8 *)(lVar24 + 0x28);
      uStack_4910 = *(ushort *)(lVar24 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar24 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar24 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar24 + 0x18) != 99) goto LAB_;
      }
      uStack_4900 = *(undefined4 *)(lVar24 + 0x20);
      uStack_48fc = *(undefined2 *)(lVar24 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1006e0;
      cVar8 = func_0x(&uStack_4900);
      if (cVar8 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1006f0;
      func_0x(lVar24,&uStack_4918);
    }
    uVar13 = *(uint *)(lVar19 + 0x2108);
    do {
      uVar12 = uVar13 & 0xfffffffe;
      uStack_4948 = *(undefined8 *)(lVar19 + 0x20fc);
      uStack_4940 = *(undefined4 *)(lVar19 + 0x2104);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
      UNLOCK();
      uVar13 = *(uint *)(lVar19 + 0x2108);
    } while (uVar12 != uVar13);
    if ((uint)uStack_4918 <= (uint)uStack_4948) {
      if ((uint)uStack_4948 != (uint)uStack_4918) goto LAB_;
      uVar13 = (uint)((ulonglong)uStack_4948 >> 0x20);
      if ((uStack_4918._4_4_ <= uVar13) &&
         ((uVar13 != uStack_4918._4_4_ || (uStack_4910 <= (ushort)uStack_4940)))) goto LAB_;
    }
    if ((*(char *)(lVar19 + 0x6ac8) == '\0') &&
       (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) != *(longlong *)(lVar19 + 0x2120))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007aa;
      cVar8 = func_0x(lVar19);
      if (cVar8 == '\0') {
        uVar14 = *(uint *)(lVar19 + 0x2108);
        do {
          uVar22 = uVar14 & 0xfffffffe;
          uStack_4948 = *(undefined8 *)(lVar19 + 0x20fc);
          uStack_4940 = *(undefined4 *)(lVar19 + 0x2104);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
          UNLOCK();
          uVar14 = *(uint *)(lVar19 + 0x2108);
        } while (uVar22 != uVar14);
        uVar6 = (ushort)uStack_4940;
        uStack_48b8 = (ushort)uStack_4940;
        lVar23 = **(longlong **)(&stack0x00000040 + lVar15);
        uStack_48c0 = uStack_4948;
        if (*(short *)(lVar23 + 0x24) == 0) {
LAB_:
          uStack_4938 = *(undefined8 *)(lVar23 + 0x28);
          uStack_4930 = *(ushort *)(lVar23 + 0x30);
        }
        else {
          cVar8 = *(char *)(lVar23 + 1);
          if (cVar8 == '\v') {
            if (*(int *)(lVar23 + 0x18) != 99) {
LAB_:
              if (cVar8 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar8 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar23 + 0x18) != 99) goto LAB_;
          }
          uStack_4928 = CONCAT26(uStack_4928._6_2_,*(undefined6 *)(lVar23 + 0x20));
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a64;
          cVar8 = func_0x(&uStack_4928);
          if (cVar8 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a74;
          func_0x(lVar23,&uStack_4938);
        }
        if ((uint)uStack_4948 < (uint)uStack_4938) {
LAB_:
          lVar23 = *(longlong *)(lVar19 + 0x6b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100ad6;
          func_0x(&uStack_4938,asStack_43e8,auStack_4908);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100aea;
          func_0x(&uStack_48c0,asStack_43b8,auStack_4908);
          if ((_DAT_ & 0x10000) != 0) {
            uStack_47b0 = 0x60000;
            uStack_47a8 = 0;
            ppuStack_47a0 = &puStack_4788;
            puStack_4798 = auStack_4728;
            uStack_4568 = 0;
            uStack_4790 = 0;
            uStack_4560 = 0;
            puStack_4788 = &uStack_4558;
            uStack_4780 = 0x34;
            uStack_477c = 5;
            uStack_4770 = 0x10;
            uStack_476c = 5;
            uStack_4760 = 0x10;
            uStack_475c = 6;
            uStack_474c = 7;
            uStack_473c = 8;
            uStack_4738 = 0;
            uStack_4730 = 0;
            uStack_472c = 9;
            uStack_4558 = (uint)*(ushort *)(lVar19 + 0x6b8);
            sStack_4554 = sStack_4994;
            iStack_4552 = iStack_4998;
            uStack_454e = 1;
            uStack_454d = *(undefined *)(**(longlong **)(&stack0x00000040 + lVar15) + 1);
            lStack_4778 = lVar23 + 0x254;
            lStack_4768 = lVar23 + 0x244;
            lVar19 = -1;
            do {
              lVar19 = lVar19 + 1;
            } while (asStack_43e8[lVar19] != 0);
            iStack_4750 = (int)lVar19 * 2;
            psStack_4758 = asStack_43e8;
            lVar19 = -1;
            do {
              lVar19 = lVar19 + 1;
            } while (asStack_43b8[lVar19] != 0);
            iStack_4740 = (int)lVar19 * 2;
            psStack_4748 = asStack_43b8;
            uStack_4904 = 0;
            UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100cb4;
            puVar18 = (uint *)(*UNRECOVERED_JUMPTABLE_00)(lVar23,&uStack_4904);
            ppuVar7 = ppuStack_47a0;
            if (puVar18 != (uint *)0x0) {
              lVar19 = -1;
              do {
                lVar19 = lVar19 + 1;
              } while (*(short *)((longlong)puVar18 + lVar19 * 2) != 0);
              iVar10 = (int)lVar19 * 2;
            }
            ppuStack_47a0[10] = puVar18;
            *(int *)(ppuVar7 + 0xb) = iVar10;
            *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100cee;
            func_0x(auStack_47b8);
          }
        }
        else if ((uint)uStack_4948 == (uint)uStack_4938) {
          uVar14 = (uint)((ulonglong)uStack_4938 >> 0x20);
          if ((uStack_4948._4_4_ < uVar14) ||
             ((uStack_4948._4_4_ == uVar14 && (uVar6 < uStack_4930)))) goto LAB_;
        }
LAB_:
        uVar25 = 8;
        if ((1 < (short)(ushort)uStack_49a4) &&
           (*(char *)(**(longlong **)(&stack0x00000040 + lVar15) + 1) != '\x01')) {
          if (lVar17 != 0) {
            *(longlong *)(lVar17 + 0x588) = **(longlong **)(&stack0x00000040 + lVar15);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d1a;
          lVar19 = func_0x();
          if (lVar19 != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d24;
            lVar19 = func_0x();
            if (*(longlong *)(lVar19 + 0x30) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d30;
              lVar19 = func_0x();
              uVar14 = *(uint *)(*(longlong *)(lVar19 + 0x30) + 0xc);
              if ((uVar14 < 0xe) && ((0x2640U >> (uVar14 & 0x1f) & 1) != 0)) goto LAB_;
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d50;
          func_0x(0,uVar25 & 0xffffffff);
        }
LAB_:
        lVar19 = **(longlong **)(&stack0x00000040 + lVar15);
        iStack_44e4 = iStack_4958;
        uStack_4928 = lVar19;
        if (-1 < *(char *)(lVar19 + 2)) goto LAB_;
        pbVar1 = (byte *)(lVar19 + 0x60);
        if ((sStack_4518 == 0) || (ppbVar21 = ppbStack_4508, ppbStack_4508 == (byte **)0x0)) {
          uStack_44b8 = 0;
          uStack_44aa = 0;
          auStack_4490 = ZEXT816(0);
          auStack_44e0 = ZEXT816(0);
          stack0xffffffffffffbb32 = SUB1614(ZEXT816(0),2);
          auStack_44d0._0_2_ = 0xffff;
          uStack_44c8 = 0;
          uStack_44b2 = 0;
          uStack_44b0 = 0;
          uStack_44a8 = 0;
          uStack_44c0 = 0;
          auStack_44a0 = ZEXT816(0);
          auStack_4480._0_12_ = ZEXT812(0);
          auStack_4480._12_4_ = 0;
          uStack_4470 = 0;
          ppbVar21 = (byte **)auStack_44e0;
        }
        if (*(short *)(lVar19 + 0x24) == 0) {
LAB_:
          uStack_48e0 = *(undefined8 *)(lVar19 + 0x28);
          uStack_48d8 = *(undefined2 *)(lVar19 + 0x30);
        }
        else {
          cVar8 = *(char *)(lVar19 + 1);
          if (cVar8 == '\v') {
            if (*(int *)(lVar19 + 0x18) != 99) {
LAB_:
              if (cVar8 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar8 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar19 + 0x18) != 99) goto LAB_;
          }
          uStack_4950 = *(undefined4 *)(lVar19 + 0x20);
          uStack_494c = *(undefined2 *)(lVar19 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100e8f;
          cVar8 = func_0x(&uStack_4950,0xac2820,0xac2820);
          if (cVar8 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100e9f;
          func_0x(lVar19,&uStack_48e0);
        }
        *ppbVar21 = pbVar1;
        *(undefined4 *)(ppbVar21 + 0xc) = (undefined4)uStack_48e0;
        *(int *)((longlong)ppbVar21 + 100) = (int)((ulonglong)uStack_48e0 >> 0x20);
        *(undefined2 *)(ppbVar21 + 0xd) = uStack_48d8;
        *(undefined4 *)((longlong)ppbVar21 + 0x6c) = *(undefined4 *)(lVar19 + 0x20);
        *(undefined2 *)(ppbVar21 + 0xe) = *(undefined2 *)(lVar19 + 0x24);
        *(undefined2 *)((longlong)ppbVar21 + 0x72) = 0;
        uStack_4950 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0xb41100);
        uVar25 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0xb41104);
        *(undefined2 *)(ppbVar21 + 2) = 0xffff;
        ppbVar21[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar21 + 0x2e) = 0;
        ppbVar21[7] = (byte *)0x0;
        ppbVar21[4] = (byte *)0x0;
        ppbVar21[9] = (byte *)0x0;
        ppbVar21[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar21 + 0xb) = 0;
        if ((**ppbVar21 & 2) != 0) {
          pbVar1 = pbVar1 + uVar25;
          if ((*pbVar1 & 1) == 0) {
            *(undefined2 *)(ppbVar21 + 2) = 0;
            ppbVar21[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar21 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001010f5 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x10201c) -
                      0x1a57d10))();
            return;
          }
          *(undefined2 *)(ppbVar21 + 2) = 1;
          ppbVar21[3] = pbVar1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x101ffc) *
                                  4 + 0x101fec) - 0x1a57d10);
                    /* WARNING: Could not emulate address calculation at 0x00100f65 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if ((**ppbVar21 & 4) != 0) {
          uStack_4950._2_2_ = (short)((uint)uStack_4950 >> 0x10);
          if (uStack_4950._2_2_ != 0) {
            uVar25 = (ulonglong)*(ushort *)(lVar19 + 0x61 + (longlong)uStack_4950._2_2_ * 2);
          }
          psVar20 = (short *)(pbVar1 + uVar25);
          ppbVar21[9] = (byte *)psVar20;
          sVar3 = *psVar20;
          ppbVar21[10] = (byte *)(psVar20 + 1);
          *(short *)(ppbVar21 + 0xb) = (sVar3 + 1) * 2;
        }
        pbVar1 = ppbVar21[1];
        if (pbVar1 != (byte *)0x0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1011b2;
          func_0x(pbVar1,ppbVar21);
        }
LAB_:
        pbStack_4510 = (byte *)((ulonglong)*(ushort *)(lVar19 + (0xfff - (longlong)iStack_4958) * 2)
                               + lVar19);
        if ((*pbStack_4510 & 1) == 0) {
          sStack_4518 = 0;
          uStack_4514 = 0;
          uStack_44f2 = 0;
          uStack_44f0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001013ec */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_4510 & 0xe) * 4 + 0x102088) -
                    0x1a57d10))(0xfff - (longlong)iStack_4958,0xac2820);
          return;
        }
        sStack_4518 = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_4510 & 0x1c) + 0x102068) * 4 +
                               0x102058) - 0x1a57d10);
                    /* WARNING: Could not emulate address calculation at 0x00101213 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_4510,0xac2820);
        return;
      }
    }
    if (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) == *(longlong *)(lVar19 + 0x2120)) goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007ee;
    cVar8 = func_0x(lVar19);
    if (cVar8 != '\0') goto LAB_;
    if (lVar17 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100800;
      lVar17 = func_0x();
    }
    plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
    lVar24 = *plVar16;
    if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
      uStack_48f0 = *(undefined8 *)(lVar24 + 0x28);
      uStack_48e8 = *(undefined2 *)(lVar24 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar24 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar24 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar24 + 0x18) != 99) goto LAB_;
      }
      uStack_48f8 = *(undefined4 *)(lVar24 + 0x20);
      uStack_48f4 = *(undefined2 *)(lVar24 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100850;
      cVar8 = func_0x(&uStack_48f8);
      if (cVar8 == '\0') {
        plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
        goto LAB_;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100860;
      func_0x(lVar24,&uStack_48f0);
      plVar16 = *(longlong **)(&stack0x00000040 + lVar15);
    }
    if (plVar16 != (longlong *)0x0) {
      uStack_49a4._0_2_ = (ushort)uVar22;
      if (((*(ushort *)((longlong)plVar16 + 0x62) & 0x400) == 0) || ((ushort)uStack_49a4 < 3)) {
        plVar5 = *(longlong **)(&stack0x00000040 + lVar15);
        if (((byte)*(undefined2 *)((longlong)plVar16 + 0x62) >> 3 & 1) != 0) {
          if ((ushort)uStack_49a4 == 3) {
            uStack_49a4._0_2_ = 4;
          }
          else if ((ushort)uStack_49a4 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)(&stack0x00000040 + lVar15) + 100) & 8) != 0) &&
              (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000040 + lVar15) + 0x90), lVar24 != 0)
              ) && (*(longlong *)(lVar24 + 0x758) != 0)) {
            uVar4 = *(undefined8 *)(lVar24 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10090f;
            func_0x
                      (uVar4,*(undefined8 *)(&stack0x00000040 + lVar15),(ushort)uStack_49a4);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar5 + 100) & 8) != 0)) &&
           ((2 < (ushort)uStack_49a4 &&
            (((*(uint *)((longlong)plVar5 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar24 = *plVar5, lVar24 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100953;
          iVar10 = (*_DAT_)(lVar24,0x2000,2,auStack_48a8);
          if (iVar10 != 0) {
            LOCK();
            *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100975;
        func_0x(plVar5 + 0x13,(ushort)uStack_49a4);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100994;
          func_0x(plVar5,0,(ushort)uStack_49a4);
        }
        uStack_49a4 = uVar14 & 0xff0000;
        *(undefined8 *)(&stack0x00000040 + lVar15) = 0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1008aa;
        func_0x(&stack0x00000040 + lVar15);
      }
    }
    uStack_48d0 = uStack_48f0;
    uStack_48c8 = uStack_48e8;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
    uVar4 = *(undefined8 *)(lVar19 + 0x728);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1009d7;
    func_0x(uVar4,&uStack_48d0,4);
  } while( true );
}

