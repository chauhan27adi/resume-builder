
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 *param_2)

{
  ulonglong *puVar1;
  longlong *plVar2;
  undefined auVar3 [16];
  undefined auVar4 [16];
  undefined auVar5 [16];
  ushort uVar6;
  undefined uVar7;
  int iVar8;
  int iVar9;
  longlong lVar10;
  undefined2 *puVar11;
  undefined8 uVar12;
  longlong lVar13;
  ulonglong uVar14;
  uint *puVar15;
  longlong unaff_GS_OFFSET;
  bool bVar16;
  undefined auStack_738 [32];
  undefined8 uStack_718;
  char *pcStack_710;
  char cStack_708;
  char acStack_707 [3];
  ushort uStack_704;
  longlong lStack_700;
  char cStack_6f8;
  byte bStack_6f7;
  char cStack_6f6;
  char cStack_6f5;
  char cStack_6f4;
  undefined uStack_6f3;
  undefined uStack_6f2;
  undefined8 uStack_6f0;
  short sStack_6e8;
  int iStack_6e0;
  int iStack_6dc;
  int iStack_6d8;
  uint auStack_6d4 [3];
  longlong lStack_6c8;
  ulonglong *puStack_6c0;
  ulonglong *puStack_6b8;
  ulonglong *puStack_6b0;
  ulonglong *puStack_6a8;
  ulonglong uStack_6a0;
  longlong lStack_698;
  ulonglong uStack_690;
  longlong lStack_688;
  ulonglong uStack_680;
  longlong lStack_678;
  ulonglong uStack_670;
  longlong lStack_668;
  undefined4 uStack_640;
  ulonglong uStack_638;
  undefined8 uStack_630;
  longlong lStack_628;
  longlong lStack_620;
  ulonglong uStack_618;
  longlong lStack_610;
  ulonglong uStack_608;
  longlong lStack_600;
  ulonglong uStack_5f8;
  longlong lStack_5e8;
  undefined8 *puStack_5e0;
  longlong lStack_5d8;
  undefined4 uStack_5d0;
  undefined4 uStack_5cc;
  undefined2 uStack_5c8;
  undefined4 uStack_5c0;
  uint uStack_5bc;
  undefined4 uStack_5b8;
  undefined4 uStack_5b4;
  undefined4 uStack_5b0;
  int iStack_5ac;
  int iStack_5a8;
  uint uStack_5a4;
  int iStack_5a0;
  int iStack_59c;
  int iStack_598;
  int iStack_594;
  int iStack_590;
  uint uStack_588;
  uint uStack_580;
  int iStack_57c;
  int iStack_578;
  uint uStack_574;
  int iStack_570;
  int iStack_56c;
  ulonglong uStack_548;
  ulonglong uStack_540;
  ulonglong uStack_538;
  ulonglong uStack_530;
  ulonglong uStack_528;
  ulonglong uStack_520;
  undefined8 uStack_518;
  undefined8 uStack_510;
  undefined2 *puStack_508;
  undefined8 uStack_500;
  byte *pbStack_4f8;
  ulonglong uStack_4f0;
  ulonglong uStack_4e8;
  ulonglong uStack_4e0;
  ulonglong uStack_4d8;
  ulonglong uStack_4d0;
  ulonglong uStack_4c8;
  longlong lStack_4c0;
  undefined8 uStack_4b8;
  uint uStack_4b0;
  longlong lStack_4a8;
  ulonglong uStack_4a0;
  ulonglong uStack_498;
  ulonglong uStack_490;
  ulonglong uStack_488;
  ulonglong uStack_480;
  ulonglong uStack_478;
  ulonglong uStack_470;
  ulonglong uStack_468;
  ulonglong uStack_460;
  ulonglong uStack_458;
  ulonglong uStack_450;
  ulonglong uStack_448;
  undefined *puStack_430;
  undefined8 *puStack_428;
  int iStack_420;
  int iStack_41c;
  uint uStack_418;
  undefined8 uStack_408;
  undefined8 uStack_400;
  undefined auStack_3f8 [16];
  undefined auStack_3e8 [16];
  undefined4 uStack_3d8;
  undefined uStack_3d4;
  undefined8 uStack_3d0;
  undefined8 uStack_3b8;
  longlong lStack_3b0;
  undefined2 *puStack_3a8;
  undefined8 uStack_3a0;
  longlong lStack_398;
  longlong lStack_390;
  longlong *plStack_388;
  longlong lStack_380;
  longlong lStack_378;
  undefined8 uStack_370;
  ulonglong uStack_368;
  longlong lStack_360;
  longlong lStack_358;
  longlong *plStack_350;
  ulonglong *puStack_348;
  longlong lStack_340;
  longlong *plStack_338;
  longlong lStack_330;
  longlong lStack_328;
  longlong lStack_320;
  longlong *plStack_318;
  longlong lStack_310;
  longlong lStack_308;
  undefined8 uStack_300;
  longlong lStack_2f8;
  longlong lStack_2f0;
  longlong lStack_2e8;
  ulonglong uStack_2e0;
  ulonglong uStack_2d8;
  longlong lStack_2d0;
  longlong lStack_2c8;
  longlong *plStack_2c0;
  ulonglong *puStack_2b8;
  ulonglong uStack_2b0;
  longlong lStack_2a8;
  longlong lStack_2a0;
  longlong *plStack_298;
  ulonglong *puStack_290;
  longlong lStack_288;
  undefined8 uStack_210;
  ulonglong uStack_208;
  longlong lStack_200;
  longlong lStack_1f8;
  longlong *plStack_1f0;
  ulonglong *puStack_1e8;
  longlong lStack_1e0;
  undefined auStack_1d8 [24];
  undefined auStack_1c0 [16];
  longlong lStack_1b0;
  undefined8 auStack_1a0 [11];
  undefined8 uStack_148;
  undefined8 auStack_118 [8];
  int iStack_d4;
  uint auStack_78 [2];
  longlong *plStack_70;
  undefined uStack_68;
  undefined4 uStack_64;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined2 uStack_40;
  undefined2 uStack_3e;
  ulonglong uStack_38;
  
  uStack_210 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_738;
  lStack_6c8 = param_1;
  func_0x(auStack_1d8,*(undefined8 *)(param_1 + 0x2b0));
  lVar13 = 0;
  uStack_3d0 = 0;
  func_0x(&uStack_408);
  uStack_408 = 0;
  uStack_400 = 0;
  auStack_3f8 = ZEXT816(0);
  auStack_3e8 = ZEXT816(0);
  uStack_3d8 = 0;
  uStack_3d4 = 0;
  func_0x(&uStack_408);
  iStack_6e0 = 0;
  iStack_6d8 = 0;
  lStack_628 = 0;
  auStack_6d4[0] = 0;
  *param_2 = 0;
  func_0x(&uStack_408,0,0);
  puVar1 = (ulonglong *)(param_1 + 0x1500);
  uStack_638 = 0;
  lStack_698 = 0;
  uStack_6a0 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
  puStack_6c0 = puVar1;
  if (*(int *)puVar1 == 0) {
    LOCK();
    uStack_208 = *puVar1;
    bVar16 = uStack_208 == 0;
    if (bVar16) {
      *puVar1 = uStack_6a0;
      uStack_208 = 0;
    }
    UNLOCK();
    uStack_4b0 = (uint)bVar16;
    if (uStack_4b0 == 0) goto LAB_;
  }
  else {
LAB_:
    if (((byte)*_DAT_ & 0x84) == 0x84) {
      lStack_5d8 = 0;
      lStack_200 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      lStack_1f8 = (ulonglong)*_DAT_ +
                   *(longlong *)(lStack_200 + (ulonglong)*_DAT_ * 8);
      if ((lStack_1f8 == 0) || (*(longlong *)(lStack_1f8 + 0x110) != lStack_1f8)) {
        lVar10 = 0;
      }
      else {
        lVar10 = *(longlong *)(lStack_1f8 + 0x100);
        lStack_5d8 = lVar10;
      }
    }
    else {
      lVar10 = 0;
    }
    lStack_698 = lVar10;
    if (lVar10 != 0) {
      iStack_420 = *_DAT_;
      if (iStack_420 == 0) {
        uStack_540 = _DAT_;
        uStack_638 = _DAT_;
        uStack_538 = _DAT_;
      }
      else {
        (*_DAT_)(&uStack_548);
        uStack_638 = uStack_548;
        uStack_538 = uStack_548;
      }
    }
    if (*(char *)(_DAT_ + 199) < '\0') {
      func_0x(puStack_6c0,lVar10,uStack_6a0);
    }
    else {
      func_0x(puStack_6c0,uStack_6a0);
    }
    if (lVar10 != 0) {
      iStack_41c = *_DAT_;
      if (iStack_41c == 0) {
        uStack_528 = _DAT_;
        uStack_530 = _DAT_;
        lVar10 = lStack_698;
      }
      else {
        (*_DAT_)(&uStack_530);
      }
      lStack_700 = lVar13;
      if (uStack_638 <= uStack_530) {
        lStack_700 = uStack_530 - uStack_638;
      }
      plStack_1f0 = (longlong *)(lVar10 + 0xc78);
      *plStack_1f0 = *plStack_1f0 + lStack_700;
      uStack_520 = uStack_530;
    }
  }
  if (*(longlong *)(param_1 + 0x958) == 0) {
    *(undefined8 **)(param_1 + 0x958) = &uStack_408;
  }
  else {
    iStack_6e0 = 1;
  }
  iVar9 = iStack_6e0;
  cStack_6f8 = *_DAT_;
  puStack_1e8 = puVar1;
  if ((cStack_6f8 != '\0') && (iVar8 = (*_DAT_)(), iVar8 == (iVar8 / 5) * 5)) {
    func_0x();
  }
  *puVar1 = 0;
  if (iVar9 != 0) {
    func_0x(auStack_1d8);
    goto LAB_;
  }
  func_0x(0x8158,*(undefined4 *)(param_1 + 0x3a0),param_1 + 0x3a8);
  uStack_418 = (uint)*(ushort *)(param_1 + 0x28);
  func_0x(*(ushort *)(param_1 + 0x28),0);
  func_0x(auStack_1d8);
  uStack_704 = 1;
  while (uVar6 = uStack_704, lVar10 = *(longlong *)(*(longlong *)(param_1 + 0x1210) + 0x6a0),
        uStack_704 <= *(ushort *)(lVar10 + 0x74)) {
    lVar10 = func_0x(lVar10,uStack_704);
    lStack_4c0 = lVar10;
    if ((lVar10 != 0) && ((*(uint *)(lVar10 + 100) & 0x40) == 0)) {
      if (*(int *)(lVar10 + 0x68) == 5) {
        if ((*(byte *)(lVar10 + 0x7c) & 1) != 0) goto LAB_;
      }
      else if (((*(int *)(lVar10 + 0x68) == 10) || ((*(byte *)(lVar10 + 0x7c) & 1) == 0)) ||
              ((*(uint *)(lVar10 + 100) & 0x90000000) != 0)) {
        iStack_6d8 = 1;
      }
      else {
LAB_:
        uStack_5c0 = 0x329c;
        uStack_718 = (char *)CONCAT71(uStack_718._1_7_,5);
        lStack_1e0 = (*_DAT_)(0x60,*(undefined8 *)(param_1 + 0x2b0),0x14e09c8,0x329c);
        if (lStack_1e0 == 0) {
          uStack_518 = 0;
        }
        else {
          uStack_518 = func_0x(lStack_1e0,auStack_1d8);
        }
        func_0x(uStack_518,*(undefined8 *)(*(longlong *)(param_1 + 0x1210) + 0x6a0),uVar6,
                        lVar10);
        uStack_5bc = *(uint *)(lVar10 + 0x80);
        func_0x(&uStack_408,uStack_5bc >> 3);
      }
    }
    uStack_704 = uVar6 + 1;
  }
  if ((DAT_ != '\0') && (*(longlong *)(param_1 + 0x14c8) != 0)) {
    uStack_630 = 0;
    uStack_3b8 = func_0x(*(undefined8 *)(param_1 + 0x1210));
    func_0x(uStack_3b8,*(undefined8 *)(param_1 + 0x2b0),&uStack_630);
    uStack_5b8 = 0x32b0;
    uStack_718 = (char *)CONCAT71(uStack_718._1_7_,5);
    lStack_3b0 = (*_DAT_)(0x60,*(undefined8 *)(param_1 + 0x2b0),0x14e09c8,0x32b0);
    if (lStack_3b0 == 0) {
      uStack_510 = 0;
    }
    else {
      uStack_510 = func_0x(lStack_3b0,auStack_1d8);
    }
    func_0x(uStack_510,0,*(undefined8 *)(param_1 + 0x1210));
    (*_DAT_)(uStack_630);
  }
  if (((((_DAT_ & 1) != 0) || ((_DAT_ == 0 && (DAT_ != '\0')))) ||
      (DAT_ != '\0')) &&
     ((((((_DAT_ & 4) == 0 && (DAT_ == '\0')) && ((DAT_ & 4) == 0)) &&
       ((DAT_ != '\0' && ((DAT_ & 0x80) == 0)))) && (DAT_ == '\0')))) {
    puStack_508 = (undefined2 *)0x0;
    uStack_5b4 = 1;
    uStack_718 = (char *)CONCAT71(uStack_718._1_7_,5);
    puVar11 = (undefined2 *)(*_DAT_)(2,*(undefined8 *)(param_1 + 0x2b0),0x14e09c8,0x32c2);
    puStack_3a8 = puVar11;
    if (puVar11 != (undefined2 *)0x0) {
      (*_DAT_)(0);
    }
    *puVar11 = 0;
    puStack_508 = puVar11;
    uVar12 = func_0x(*(undefined2 *)(param_1 + 0x28),param_1 + 0x3a8);
    uStack_640 = 0;
    lVar10 = lVar13;
    uStack_3a0 = uVar12;
    while ((int)lVar10 == 0) {
      func_0x(&uStack_408,uVar12,0);
      uStack_5b0 = 0x32cf;
      uStack_718 = (char *)CONCAT71(uStack_718._1_7_,5);
      lStack_398 = (*_DAT_)(0x60,*(undefined8 *)(param_1 + 0x2b0),0x14e09c8,0x32cf);
      if (lStack_398 == 0) {
        uStack_500 = 0;
      }
      else {
        uStack_500 = func_0x(lStack_398,auStack_1d8);
      }
      func_0x(uStack_500,puVar11[lVar10]);
      uStack_640 = 1;
      lVar10 = 1;
    }
    (*_DAT_)(puVar11);
  }
  iVar9 = func_0x(auStack_1d8);
  if ((iVar9 != 0) && ((DAT_ & 0x10) == 0)) {
    lStack_390 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    plStack_388 = (longlong *)
                  ((ulonglong)*_DAT_ +
                  *(longlong *)(lStack_390 + (ulonglong)*_DAT_ * 8));
    lStack_380 = *plStack_388;
    if ((lStack_380 == 0) ||
       ((lStack_378 = **(longlong **)(lStack_380 + 0x38), lStack_378 == 0 ||
        (iStack_5ac = (*_DAT_)(lStack_378,0x138c), iStack_5ac == 0)))) {
      uStack_370 = *(undefined8 *)(param_1 + 0x1210);
      uStack_718 = (char *)0x0;
      func_0x(uStack_370,0,1,1);
      pbStack_4f8 = *(byte **)(param_1 + 0x8a8);
      switch(*pbStack_4f8 & 0x1f) {
      case 1:
      case 3:
        bStack_6f7 = *pbStack_4f8 & 0x1f;
        if (bStack_6f7 == 3) goto code_r0x00100835;
        break;
      case 2:
      case 4:
      case 6:
code_r0x00100835:
        lStack_628 = *(longlong *)(param_1 + 0x8a8) + 0x30;
      }
      lVar10 = lStack_628;
      func_0x(param_1,0,0,1);
      if (((DAT_ == '\0') || (*(longlong *)(param_1 + 0x14c8) == 0)) &&
         (plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x1210) + 0x6c8),
         iVar9 = (**(code **)(*plVar2 + 0x280))(plVar2,lVar10,auStack_6d4), iVar9 == 0)) {
        func_0x(0x815a,*(undefined4 *)(param_1 + 0x3a0),param_1 + 0x3a8);
        func_0x(auStack_1d8);
        goto LAB_;
      }
      iVar9 = func_0x(*(undefined8 *)(param_1 + 0x1210));
      if (iVar9 == 1) {
        iStack_6dc = 0;
        cStack_708 = '\0';
        pcStack_710 = acStack_707;
        uStack_718 = &cStack_708;
        iStack_5a8 = func_0x(param_1,*(undefined8 *)(param_1 + 0x8a8),600,&iStack_6dc);
        if (((iStack_5a8 < 0) || (cStack_708 != '\0')) || (iStack_6dc < 0)) {
          puVar1 = (ulonglong *)(param_1 + 0x1500);
          uStack_618 = 0;
          lStack_688 = 0;
          uStack_690 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
          puStack_6b8 = puVar1;
          if (*(int *)puVar1 == 0) {
            LOCK();
            uStack_368 = *puVar1;
            bVar16 = uStack_368 == 0;
            if (bVar16) {
              *puVar1 = uStack_690;
              uStack_368 = 0;
            }
            UNLOCK();
            uStack_5a4 = (uint)bVar16;
            if (uStack_5a4 == 0) goto LAB_;
          }
          else {
LAB_:
            if (((byte)*_DAT_ & 0x84) == 0x84) {
              lStack_620 = 0;
              lStack_360 = *(longlong *)(unaff_GS_OFFSET + 0x58);
              lStack_358 = (ulonglong)*_DAT_ +
                           *(longlong *)(lStack_360 + (ulonglong)*_DAT_ * 8);
              if ((lStack_358 == 0) || (*(longlong *)(lStack_358 + 0x110) != lStack_358)) {
                lVar10 = 0;
              }
              else {
                lVar10 = *(longlong *)(lStack_358 + 0x100);
                lStack_620 = lVar10;
              }
            }
            else {
              lVar10 = 0;
            }
            lStack_688 = lVar10;
            if (lVar10 != 0) {
              iStack_5a0 = *_DAT_;
              if (iStack_5a0 == 0) {
                uStack_4e8 = _DAT_;
                uStack_618 = _DAT_;
                uStack_4e0 = _DAT_;
              }
              else {
                (*_DAT_)(&uStack_4f0);
                uStack_618 = uStack_4f0;
                uStack_4e0 = uStack_4f0;
              }
            }
            if (*(char *)(_DAT_ + 199) < '\0') {
              func_0x(puStack_6b8,lVar10,uStack_690);
            }
            else {
              func_0x(puStack_6b8,uStack_690);
            }
            if (lVar10 != 0) {
              iStack_59c = *_DAT_;
              if (iStack_59c == 0) {
                uStack_4d0 = _DAT_;
                uStack_4d8 = _DAT_;
                lVar10 = lStack_688;
              }
              else {
                (*_DAT_)(&uStack_4d8);
              }
              if (uStack_618 <= uStack_4d8) {
                lVar13 = uStack_4d8 - uStack_618;
              }
              plStack_350 = (longlong *)(lVar10 + 0xc78);
              *plStack_350 = *plStack_350 + lVar13;
              lStack_700 = lVar13;
              uStack_4c8 = uStack_4d8;
            }
          }
          *(undefined8 *)(param_1 + 0x958) = 0;
          cStack_6f6 = *_DAT_;
          puStack_348 = puVar1;
          if ((cStack_6f6 != '\0') && (iVar9 = (*_DAT_)(), iVar9 == (iVar9 / 5) * 5)) {
            func_0x();
          }
          *puVar1 = 0;
          func_0x(0x815a,*(undefined4 *)(param_1 + 0x3a0),param_1 + 0x3a8);
          func_0x(auStack_1d8);
          goto LAB_;
        }
      }
      uStack_704 = 1;
      while (uVar6 = uStack_704, lVar10 = *(longlong *)(*(longlong *)(param_1 + 0x1210) + 0x6a0),
            uStack_704 <= *(ushort *)(lVar10 + 0x74)) {
        lVar10 = func_0x(lVar10,uStack_704,1);
        lStack_4c0 = lVar10;
        if ((((lVar10 != 0) && ((*(byte *)(lVar10 + 0x7c) & 1) != 0)) &&
            ((*(byte *)(lVar10 + 100) & 0x40) == 0)) && (*(longlong *)(lVar10 + 0x378) != 0)) {
          (*_DAT_)();
          *(undefined8 *)(lVar10 + 0x378) = 0;
        }
        uStack_704 = uVar6 + 1;
      }
      if (iStack_6d8 == 0) {
LAB_:
        uVar14 = CONCAT71(_DAT_,DAT_);
LAB_:
        uStack_4b8 = 0;
        if ((uVar14 & 8) == 0) {
          lStack_320 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          plStack_318 = (longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)(lStack_320 + (ulonglong)*_DAT_ * 8));
          lStack_310 = *plStack_318;
          if (((lStack_310 != 0) &&
              (lStack_308 = **(longlong **)(lStack_310 + 0x38), lStack_308 != 0)) &&
             (iStack_594 = (*_DAT_)(lStack_308,0x1393), iStack_594 != 0)) goto LAB_;
        }
        else {
LAB_:
          iStack_590 = func_0x(param_1,&uStack_4b8);
          if (iStack_590 == 0) {
            uStack_718 = (char *)0x0;
            (*_DAT_)(1,0x167a774,0x1649238,0x3359);
          }
        }
        iVar9 = func_0x(*(undefined8 *)(param_1 + 0x1210));
        if ((iVar9 == 1) && (acStack_707[0] != '\0')) {
          uStack_6f0 = 0;
          sStack_6e8 = 0;
          do {
            uStack_588 = (uint)*(ushort *)(param_1 + 0x28);
            func_0x(*(ushort *)(param_1 + 0x28),0);
            uStack_300 = *(undefined8 *)(param_1 + 0x1210);
            auStack_78[0] = 0;
            plStack_70 = (longlong *)0x0;
            uStack_68 = 0;
            uStack_64 = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            uStack_40 = 0;
            uStack_3e = 0;
            auStack_58 = ZEXT816(0);
            lStack_5e8 = 0;
            func_0x(auStack_78,0,uStack_300,0);
            func_0x(auStack_78,2);
            if ((auStack_78[0] & 1) == 0) {
              lStack_2f8 = *plStack_70;
              lStack_5e8 = (ulonglong)*(ushort *)(lStack_2f8 + 0x1ffe) + lStack_2f8;
            }
            else {
              lStack_5e8 = auStack_58._0_8_;
            }
            uStack_6f0 = *(undefined8 *)(lStack_5e8 + 0x5fc);
            sStack_6e8 = *(short *)(lStack_5e8 + 0x604);
            if ((auStack_78[0] & 1) == 0) {
              func_0x(&plStack_70);
              if (auStack_58._0_8_ != 0) {
                (*_DAT_)(auStack_58._0_8_,0x6fa);
                auVar3._8_8_ = 0;
                auVar3._0_8_ = auStack_58._8_8_;
                auStack_58 = auVar3 << 0x40;
              }
            }
            func_0x(auStack_78,0);
            if ((plStack_70 != (longlong *)0x0) || ((auStack_78[0] & 1) != 0)) {
              if ((auStack_78[0] & 1) == 0) {
                func_0x(&plStack_70);
                if (auStack_58._0_8_ != 0) {
                  (*_DAT_)(auStack_58._0_8_,0x6fa);
                  auVar4._8_8_ = 0;
                  auVar4._0_8_ = auStack_58._8_8_;
                  auStack_58 = auVar4 << 0x40;
                }
              }
              func_0x(auStack_78,0);
            }
            if (auStack_58._0_8_ != 0) {
              (*_DAT_)(auStack_58._0_8_,0x6fa);
              auVar5._8_8_ = 0;
              auVar5._0_8_ = auStack_58._8_8_;
              auStack_58 = auVar5 << 0x40;
            }
            func_0x(&plStack_70);
            uStack_5d0 = 0;
            uStack_5cc = 0;
            uStack_5c8 = 0;
            if (((sStack_6e8 == 0) && ((uint)uStack_6f0 == 0)) && (uStack_6f0._4_4_ == 0)) {
              uStack_718 = (char *)0x0;
              (*_DAT_)(1,0x167a780,0x1649238);
            }
            lStack_2f0 = *(longlong *)(unaff_GS_OFFSET + 0x58);
            lVar10 = (ulonglong)*_DAT_ +
                     *(longlong *)(lStack_2f0 + (ulonglong)*_DAT_ * 8);
            lStack_4a8 = *(longlong *)(lVar10 + 0x100);
            puVar15 = _DAT_;
            lStack_2e8 = lVar10;
            if (lStack_4a8 == 0) {
              puVar15 = (uint *)(*_DAT_)();
              lStack_4a8 = *(longlong *)(lVar10 + 0x100);
            }
            uVar14 = rdtsc();
            uStack_2e0 = CONCAT44((int)((ulonglong)puVar15 >> 0x20),(int)uVar14) |
                         uVar14 & 0xffffffff00000000;
            uVar14 = *(ulonglong *)(lStack_4a8 + 0x340);
            if ((uVar14 < uStack_2e0) ||
               ((uVar14 != 0x7fffffffffffffff &&
                (*(ulonglong *)(*(longlong *)(lStack_4a8 + 0x260) + 0xdf0) < uVar14 - uStack_2e0))))
            {
              (*_DAT_)();
            }
          } while ((uint)uStack_6f0 < auStack_6d4[0]);
        }
        (*_DAT_)(*(undefined8 *)(param_1 + 0x8a8),param_1);
        func_0x(0x8159,*(undefined4 *)(param_1 + 0x3a0),param_1 + 0x3a8);
        *param_2 = 1;
      }
      else {
        uVar14 = CONCAT71(_DAT_,DAT_);
        if ((DAT_ & 4) != 0) goto LAB_;
        lStack_340 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        plStack_338 = (longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)(lStack_340 + (ulonglong)*_DAT_ * 8));
        lStack_330 = *plStack_338;
        if (((lStack_330 != 0) && (lStack_328 = **(longlong **)(lStack_330 + 0x38), lStack_328 != 0)
            ) && (iStack_598 = (*_DAT_)(lStack_328,0x1392), iStack_598 != 0))
        goto LAB_;
        func_0x(0x8164,*(undefined4 *)(param_1 + 0x3a0),param_1 + 0x3a8);
      }
      puVar1 = (ulonglong *)(param_1 + 0x1500);
      uStack_608 = 0;
      lStack_678 = 0;
      uStack_680 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
      puStack_6b0 = puVar1;
      if (*(int *)puVar1 == 0) {
        LOCK();
        uStack_2d8 = *puVar1;
        bVar16 = uStack_2d8 == 0;
        if (bVar16) {
          *puVar1 = uStack_680;
          uStack_2d8 = 0;
        }
        UNLOCK();
        uStack_580 = (uint)bVar16;
        if (uStack_580 == 0) goto LAB_;
      }
      else {
LAB_:
        if (((byte)*_DAT_ & 0x84) == 0x84) {
          lStack_610 = 0;
          lStack_2d0 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          lStack_2c8 = (ulonglong)*_DAT_ +
                       *(longlong *)(lStack_2d0 + (ulonglong)*_DAT_ * 8);
          if ((lStack_2c8 == 0) || (*(longlong *)(lStack_2c8 + 0x110) != lStack_2c8)) {
            lVar10 = 0;
          }
          else {
            lVar10 = *(longlong *)(lStack_2c8 + 0x100);
            lStack_610 = lVar10;
          }
        }
        else {
          lVar10 = 0;
        }
        lStack_678 = lVar10;
        if (lVar10 != 0) {
          iStack_57c = *_DAT_;
          if (iStack_57c == 0) {
            uStack_498 = _DAT_;
            uStack_608 = _DAT_;
            uStack_490 = _DAT_;
          }
          else {
            (*_DAT_)(&uStack_4a0);
            uStack_608 = uStack_4a0;
            uStack_490 = uStack_4a0;
          }
        }
        if (*(char *)(_DAT_ + 199) < '\0') {
          func_0x(puStack_6b0,lVar10,uStack_680);
        }
        else {
          func_0x(puStack_6b0,uStack_680);
        }
        if (lVar10 != 0) {
          iStack_578 = *_DAT_;
          if (iStack_578 == 0) {
            uStack_480 = _DAT_;
            uStack_488 = _DAT_;
            lVar10 = lStack_678;
          }
          else {
            (*_DAT_)(&uStack_488);
          }
          if (uStack_608 <= uStack_488) {
            lVar13 = uStack_488 - uStack_608;
          }
          plStack_2c0 = (longlong *)(lVar10 + 0xc78);
          *plStack_2c0 = *plStack_2c0 + lVar13;
          lStack_700 = lVar13;
          uStack_478 = uStack_488;
        }
      }
      *(undefined8 *)(param_1 + 0x958) = 0;
      cStack_6f5 = *_DAT_;
      puStack_2b8 = puVar1;
      if ((cStack_6f5 != '\0') && (iVar9 = (*_DAT_)(), iVar9 == (iVar9 / 5) * 5)) {
        func_0x();
      }
      *puVar1 = 0;
      lVar10 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar13 = *(longlong *)(lVar10 + 0x100);
      if (lVar13 == 0) {
        (*_DAT_)();
        lVar13 = *(longlong *)(lVar10 + 0x100);
      }
      if (*(int *)(lVar13 + 0x22c) != 0) {
        (*_DAT_)();
      }
      if (iStack_d4 == 0) {
        func_0x(auStack_1d8);
      }
      puStack_5e0 = auStack_118;
      auStack_118[0] = 0x11b4b20;
      uStack_148 = 0x11b4ad0;
      puStack_428 = auStack_1a0;
      auStack_1a0[0] = 0x11b4b20;
      puStack_430 = auStack_1c0;
      if (lStack_1b0 != 0) {
        (*_DAT_)();
      }
      goto LAB_;
    }
  }
  puVar1 = (ulonglong *)(param_1 + 0x1500);
  uStack_5f8 = 0;
  lStack_668 = 0;
  uStack_670 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
  puStack_6a8 = puVar1;
  if (*(int *)puVar1 == 0) {
    LOCK();
    uStack_2b0 = *puVar1;
    bVar16 = uStack_2b0 == 0;
    if (bVar16) {
      *puVar1 = uStack_670;
      uStack_2b0 = 0;
    }
    UNLOCK();
    uStack_574 = (uint)bVar16;
    if (uStack_574 == 0) goto LAB_;
  }
  else {
LAB_:
    if (((byte)*_DAT_ & 0x84) == 0x84) {
      lStack_600 = 0;
      lStack_2a8 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      lStack_2a0 = (ulonglong)*_DAT_ +
                   *(longlong *)(lStack_2a8 + (ulonglong)*_DAT_ * 8);
      if ((lStack_2a0 == 0) || (*(longlong *)(lStack_2a0 + 0x110) != lStack_2a0)) {
        lVar10 = 0;
      }
      else {
        lVar10 = *(longlong *)(lStack_2a0 + 0x100);
        lStack_600 = lVar10;
      }
    }
    else {
      lVar10 = 0;
    }
    lStack_668 = lVar10;
    if (lVar10 != 0) {
      iStack_570 = *_DAT_;
      if (iStack_570 == 0) {
        uStack_468 = _DAT_;
        uStack_5f8 = _DAT_;
        uStack_460 = _DAT_;
      }
      else {
        (*_DAT_)(&uStack_470);
        uStack_5f8 = uStack_470;
        uStack_460 = uStack_470;
      }
    }
    if (*(char *)(_DAT_ + 199) < '\0') {
      func_0x(puStack_6a8,lVar10,uStack_670);
    }
    else {
      func_0x(puStack_6a8,uStack_670);
    }
    if (lVar10 != 0) {
      iStack_56c = *_DAT_;
      if (iStack_56c == 0) {
        uStack_450 = _DAT_;
        uStack_458 = _DAT_;
        lVar10 = lStack_668;
      }
      else {
        (*_DAT_)(&uStack_458);
      }
      if (uStack_5f8 <= uStack_458) {
        lVar13 = uStack_458 - uStack_5f8;
      }
      plStack_298 = (longlong *)(lVar10 + 0xc78);
      *plStack_298 = *plStack_298 + lVar13;
      lStack_700 = lVar13;
      uStack_448 = uStack_458;
    }
  }
  *(undefined8 *)(param_1 + 0x958) = 0;
  cStack_6f4 = *_DAT_;
  puStack_290 = puVar1;
  if ((cStack_6f4 != '\0') && (iVar9 = (*_DAT_)(), iVar9 == (iVar9 / 5) * 5)) {
    func_0x();
  }
  *puVar1 = 0;
  uVar7 = (undefined)_DAT_;
  if ((DAT_ == '\0') || (uStack_6f3 = uVar7, (_DAT_ & 1) != 0)) {
    lVar13 = *(longlong *)(param_1 + 0x8a8);
LAB_:
    lStack_288 = lVar13;
    if ((DAT_ != '\0') && (uStack_6f2 = uVar7, (_DAT_ & 1) == 0)) {
      *(undefined4 *)(lVar13 + 0x264) = 3;
      func_0x(lVar13 + 0x268,1,0);
      lVar13 = *(longlong *)(param_1 + 0x8a8);
    }
    func_0x(param_1,lVar13);
    uVar12 = 0x815a;
  }
  else {
    lVar13 = *(longlong *)(param_1 + 0x8a8);
    if (*(int *)(lVar13 + 0x264) != 2) goto LAB_;
    uVar12 = 0x8336;
  }
  func_0x(uVar12,*(undefined4 *)(param_1 + 0x3a0),param_1 + 0x3a8);
  func_0x(auStack_1d8);
LAB_:
  func_0x(uStack_38 ^ (ulonglong)auStack_738);
  return;
}

