
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,short *param_3,longlong param_4,uint param_5,
                 uint param_6)

{
  ushort *puVar1;
  longlong *plVar2;
  longlong lVar3;
  ushort *puVar4;
  bool bVar5;
  byte bVar6;
  char cVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  uint uVar11;
  longlong lVar12;
  undefined8 uVar13;
  uint *puVar14;
  ulonglong uVar15;
  longlong lVar16;
  uint uVar17;
  longlong lVar18;
  undefined *puVar19;
  uint *puVar20;
  uint *puVar21;
  ulonglong uVar22;
  short sVar23;
  byte *pbVar24;
  uint uVar25;
  ulonglong uVar26;
  uint *puVar27;
  uint *puVar28;
  ushort *puVar29;
  uint uVar30;
  uint *puVar31;
  uint *puVar32;
  undefined auStack_f8 [80];
  uint uStack_a8;
  int iStack_a4;
  int iStack_a0;
  uint uStack_9c;
  uint uStack_98;
  uint uStack_94;
  uint uStack_90;
  uint uStack_8c;
  uint uStack_88;
  uint uStack_84;
  int iStack_80;
  longlong lStack_78;
  longlong lStack_70;
  longlong lStack_68;
  undefined auStack_60 [8];
  longlong *plStack_58;
  longlong lStack_50;
  undefined auStack_48 [8];
  short *psStack_40;
  ulonglong uStack_38;
  
  puVar19 = auStack_f8;
  uStack_38 = _DAT_ ^ (ulonglong)&uStack_a8;
  lVar12 = *(longlong *)(param_1 + 8);
  puVar32 = (uint *)0x0;
  uStack_a8 = 0;
  uStack_9c = 0;
  iStack_a4 = 0;
  uStack_94 = 0;
  lStack_68 = 0;
  uStack_84 = 0;
  iStack_a0 = 0;
  puVar21 = puVar32;
  puVar28 = puVar32;
  lStack_70 = param_4;
  plStack_58 = param_2;
  lStack_50 = param_1;
  psStack_40 = param_3;
  if (*(int *)(lVar12 + 0x100) == 2) {
    if ((*(byte *)(lVar12 + 0x42) & 4) == 0) {
      puVar28 = (uint *)(ulonglong)*(uint *)(lVar12 + 0xb0);
      if (0x1f9e < *(uint *)(lVar12 + 0xb0)) {
        puVar28 = (uint *)0x1f9e;
      }
    }
    else {
      puVar28 = (uint *)0x1f9e;
    }
    uStack_94 = (uint)puVar28;
    puVar14 = (uint *)((longlong)puVar28 + 0xf);
    if (puVar14 <= puVar28) {
      puVar14 = (uint *)0xffffffffffffff0;
    }
    uVar15 = (ulonglong)puVar14 & 0xfffffffffffffff0;
    func_0x();
    puVar19 = auStack_f8 + -uVar15;
    lStack_68 = (longlong)&uStack_a8 + -uVar15;
  }
  iStack_80 = *(int *)(lVar12 + 0xf4);
  uStack_98 = 0;
  uVar11 = *(uint *)(**(longlong **)(lVar12 + 0x160) + 0x1c);
  uStack_8c = *(uint *)(lStack_70 + 0x40);
  if (uVar11 <= *(uint *)(lStack_70 + 0x40)) {
    uStack_8c = uVar11;
  }
  uStack_88 = uVar11;
  if (uVar11 != 0) {
    lStack_78 = 0;
    puVar14 = puVar32;
    puVar27 = puVar32;
    puVar31 = puVar32;
    uVar17 = uStack_8c;
    do {
      lVar12 = **(longlong **)(*(longlong *)(lStack_50 + 8) + 0x160);
      if (puVar27 == (uint *)0x0) {
        puVar20 = *(uint **)(lVar12 + 0x38);
      }
      else {
        puVar20 = *(uint **)(puVar27 + 0x5a);
      }
      if (puVar20 == (uint *)(lVar12 + 0x30)) {
        puVar20 = puVar32;
      }
      puVar27 = puVar32;
      if (puVar20 != (uint *)0x0) {
        puVar27 = puVar20 + -0x58;
      }
      if (param_2 == (longlong *)0x0) {
        puVar1 = (ushort *)(param_3 + 1);
        bVar6 = *(byte *)(puVar27 + 8);
        if (*param_3 == 0) {
          uVar17 = *puVar27;
          if ((uVar17 & 0xc0000000) == 0x80000000) {
            *(undefined8 *)(puVar19 + -8) = 0x100a96;
            iVar10 = func_0x(puVar1);
            if (iVar10 != 0) {
              *(undefined8 *)(puVar19 + -8) = 0x100ab2;
              puVar20 = (uint *)func_0x(param_3 + 0x15,puVar27,&uStack_a8,auStack_60);
              uVar11 = uStack_a8;
              goto LAB_;
            }
LAB_:
            puVar20 = (uint *)0x0;
            uStack_a8 = 0;
            uVar11 = uStack_a8;
          }
          else {
            if (((bVar6 & 2) != 0) || ((*(byte *)((longlong)puVar27 + 6) & 0x10) != 0)) {
              pbVar24 = *(byte **)(param_3 + 4);
              if ((*pbVar24 & 0x10) == 0) {
                if ((1 << (*pbVar24 & 0xe) & 0x1105U) != 0) goto LAB_;
                bVar5 = true;
                uVar8 = 0;
LAB_:
                if ((bVar6 & 2) != 0) goto LAB_;
              }
              else {
                uVar11 = *(uint *)(param_3 + 8);
                if ((int)uVar11 <= (int)uVar17) {
LAB_:
                  uVar8 = ~(*(ushort *)((longlong)puVar27 + 6) >> 4) & 1;
                  bVar5 = false;
                  goto LAB_;
                }
                if ((uint)*(ushort *)(pbVar24 + uVar11) < (uint)*(ushort *)(puVar27 + 1))
                goto LAB_;
                if ((bVar6 & 2) == 0) goto LAB_;
                uVar25 = *(ushort *)(puVar27 + 1) - 1;
                bVar5 = true;
                uVar8 = pbVar24[(ulonglong)uVar11 + (ulonglong)(uVar25 >> 3) + 2] >>
                        ((byte)uVar25 & 7) & 1;
LAB_:
                if (uVar8 != 0) goto LAB_;
              }
              if ((!bVar5) && ((*(byte *)((longlong)puVar27 + 6) & 0x10) != 0)) {
                puVar20 = *(uint **)(puVar27 + 2) + 1;
                uVar11 = **(uint **)(puVar27 + 2);
                goto LAB_;
              }
            }
LAB_:
            if ((int)uVar17 < 0) {
              if (*(int *)(param_3 + 2) == 0) {
                pbVar24 = *(byte **)(param_3 + 4);
                uVar11 = *(uint *)(param_3 + 8);
                uVar15 = (ulonglong)uVar11;
                *puVar1 = 0;
                *(uint *)(param_3 + 10) = uVar11;
                bVar6 = *pbVar24;
                if ((bVar6 & 0x10) != 0) {
                  uVar11 = uVar11 + 2 + (*(ushort *)(pbVar24 + uVar15) + 7 >> 3);
                  uVar15 = (ulonglong)uVar11;
                  *(uint *)(param_3 + 10) = uVar11;
                  bVar6 = *pbVar24;
                }
                if ((bVar6 & 0x20) == 0) {
                  *(int *)(param_3 + 2) = (int)uVar15;
                  param_3[0xe] = 0;
                  *(int *)(param_3 + 0xc) = (int)uVar15;
                }
                else {
                  puVar29 = (ushort *)(pbVar24 + uVar15);
                  uVar8 = *puVar29;
                  param_3[0xe] = uVar8;
                  if (uVar8 == 0) {
                    *(undefined8 *)(puVar19 + -8) = 0x1003aa;
                    cVar7 = func_0x(0x1f13ce0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar19 + -8) = 0x1003b3;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar19 + -8) = 0x1003cd;
                        cVar7 = func_0x(0x1f13ce0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar19 + -8) = 0x1003e9;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar19 + 0x20) = 0;
                          *(undefined8 *)(puVar19 + -8) = 0x10040f;
                          (*_DAT_)(1,0x18036ec,0x19237d8,0x80f);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(param_3 + 4);
                    *(undefined8 *)(puVar19 + -8) = 0x10041d;
                    func_0x(uVar13,3);
                    uVar15 = (ulonglong)*(uint *)(param_3 + 10);
                    uVar8 = param_3[0xe];
                  }
                  uVar11 = (int)uVar15 + (uVar8 + 1) * 2;
                  *(uint *)(param_3 + 0xc) = uVar11;
                  if (0x1f9e < uVar11) {
                    *(undefined8 *)(puVar19 + -8) = 0x10044e;
                    cVar7 = func_0x(0x1f13ce0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar19 + -8) = 0x100457;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar19 + -8) = 0x100471;
                        cVar7 = func_0x(0x1f13ce0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar19 + -8) = 0x10048d;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar19 + 0x20) = 0;
                          *(undefined8 *)(puVar19 + -8) = 0x1004b3;
                          (*_DAT_)(1,0x18036ec,0x19237d8,0x816);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(param_3 + 4);
                    *(undefined8 *)(puVar19 + -8) = 0x1004c1;
                    func_0x(uVar13,4);
                    uVar8 = param_3[0xe];
                    uVar11 = *(uint *)(param_3 + 0xc);
                  }
                  uVar15 = (ulonglong)uVar8;
                  uVar8 = puVar29[uVar15];
                  *(uint *)(param_3 + 2) = uVar8 & 0x7fff;
                  if ((uVar8 & 0x7fff) < uVar11) {
                    *(undefined8 *)(puVar19 + -8) = 0x1004f2;
                    cVar7 = func_0x(0x1f13ce0);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar19 + -8) = 0x1004fb;
                      lVar12 = func_0x();
                      if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar19 + -8) = 0x100515;
                        cVar7 = func_0x(0x1f13ce0);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar19 + -8) = 0x100531;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar19 + 0x20) = 0;
                          *(undefined8 *)(puVar19 + -8) = 0x100557;
                          (*_DAT_)(1,0x18036ec,0x19237d8,0x81d);
                        }
                      }
                    }
                    uVar13 = *(undefined8 *)(param_3 + 4);
                    *(undefined8 *)(puVar19 + -8) = 0x100565;
                    func_0x(uVar13,4);
                    uVar11 = *(uint *)(param_3 + 0xc);
                    uVar15 = (ulonglong)(ushort)param_3[0xe];
                  }
                  puVar21 = puVar32;
                  puVar4 = puVar29;
                  if ((short)uVar15 != 0) {
                    do {
                      uVar17 = puVar4[1] & 0x7fff;
                      if ((uVar17 < uVar11) || (*(uint *)(param_3 + 2) < uVar17)) {
                        *(undefined8 *)(puVar19 + -8) = 0x10059f;
                        cVar7 = func_0x(0x1f13ce0);
                        if (cVar7 != '\0') {
                          *(undefined8 *)(puVar19 + -8) = 0x1005a8;
                          lVar12 = func_0x();
                          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar19 + -8) = 0x1005c2;
                            cVar7 = func_0x(0x1f13ce0);
                            if (cVar7 == '\0') {
                              *(undefined8 *)(puVar19 + -8) = 0x1005de;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar19 + 0x20) = 0;
                              *(undefined8 *)(puVar19 + -8) = 0x100604;
                              (*_DAT_)(1,0x18036ec,0x19237d8,0x82a);
                            }
                          }
                        }
                        uVar13 = *(undefined8 *)(param_3 + 4);
                        *(undefined8 *)(puVar19 + -8) = 0x100612;
                        func_0x(uVar13,4);
                      }
                      uVar15 = (ulonglong)(ushort)param_3[0xe];
                      uVar25 = (int)puVar21 + 1;
                      puVar21 = (uint *)(ulonglong)uVar25;
                      puVar4 = puVar4 + 1;
                      uVar11 = uVar17;
                    } while ((int)uVar25 < (int)(uint)(ushort)param_3[0xe]);
                  }
                  if ((short)puVar29[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                    pbVar24 = *(byte **)(param_3 + 4);
                    do {
                      uVar11 = *(ushort *)
                                (pbVar24 + uVar15 * 2 + (ulonglong)*(uint *)(param_3 + 10)) & 0x7fff
                      ;
                      if ((int)uVar15 == 1) {
                        uVar17 = *(uint *)(param_3 + 0xc);
                        uVar25 = uVar17;
LAB_:
                        if ((uVar11 < uVar17) || (*(uint *)(param_3 + 2) < uVar11))
                        goto LAB_;
                      }
                      else {
                        uVar25 = *(uint *)(param_3 + 0xc);
                        uVar17 = *(ushort *)
                                  (pbVar24 + uVar15 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2))
                                 & 0x7fff;
                        if (uVar25 <= uVar17) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar19 + -8) = 0x100688;
                        func_0x(pbVar24,7);
                        uVar25 = *(uint *)(param_3 + 0xc);
                      }
                      if ((uVar17 < uVar25) || (*(uint *)(param_3 + 2) < uVar17)) goto LAB_;
                      pbVar24 = *(byte **)(param_3 + 4);
                      if (*(ushort *)(pbVar24 + uVar17) == 5) {
                        *puVar1 = *puVar1 | 2;
                        param_3[0xe] = param_3[0xe] + -1;
                        uVar22 = (ulonglong)(uVar17 & 0xffff);
                        param_3[0x15] = (short)uVar17;
                        uVar15 = *(ulonglong *)(param_3 + 4);
                        uVar8 = param_3[0x16] & 0xc7ffU;
                        if ((*(ushort *)(uVar22 + 2 + uVar15) >> 0xe & 1) != 0) {
                          uVar8 = *(ushort *)(uVar22 + 2 + uVar15) & 0x3800 |
                                  param_3[0x16] & 0xc7ffU;
                        }
                        param_3[0x16] = uVar8;
                        uVar26 = (ulonglong)(ushort)param_3[0x15];
                        uVar9 = (uVar8 ^ *(ushort *)(uVar22 + 2 + uVar15)) & 0x7ff ^ uVar8;
                        param_3[0x16] = uVar9;
                        uVar22 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 +
                                 uVar15 + (uVar8 >> 0xb & 7) * 2 + uVar26;
                        if (uVar22 < uVar26 + uVar15) {
                          *(undefined8 *)(puVar19 + -8) = 0x100796;
                          func_0x(uVar26 + uVar15,0x19);
                          uVar9 = param_3[0x16];
                          uVar26 = (ulonglong)(ushort)param_3[0x15];
                          uVar15 = (ulonglong)*(uint *)(param_3 + 4);
                        }
                        if (uVar11 - uVar17 <
                            (((uVar9 & 0x7ff) * 2 - (int)uVar26) - (int)uVar15) + (int)uVar22) {
                          lVar12 = *(longlong *)(param_3 + 4);
                          *(undefined8 *)(puVar19 + -8) = 0x1007ce;
                          func_0x(uVar26 + lVar12,0x19);
                          uVar9 = param_3[0x16];
                        }
                        if (((uVar9 & 0x3800) != 0) &&
                           (puVar29 = (ushort *)
                                      (*(longlong *)(param_3 + 4) + 4 +
                                      (ulonglong)(ushort)param_3[0x15]), puVar21 = puVar32,
                           (uVar9 & 0x3800) != 0)) {
                          do {
                            if ((uVar9 & 0x7ff) < (*puVar29 & 0x7ff)) {
                              uVar8 = param_3[0x15];
                              lVar12 = *(longlong *)(param_3 + 4);
                              *(undefined8 *)(puVar19 + -8) = 0x100827;
                              func_0x((ulonglong)uVar8 + lVar12,0x1a);
                              uVar9 = param_3[0x16];
                            }
                            uVar11 = (int)puVar21 + 1;
                            puVar21 = (uint *)(ulonglong)uVar11;
                            puVar29 = puVar29 + 1;
                          } while ((int)uVar11 < (int)(uVar9 >> 0xb & 7));
                        }
                        goto LAB_;
                      }
                      if (*(ushort *)(pbVar24 + uVar17) < 0x400) goto LAB_;
                      *puVar1 = *puVar1 | 1;
                      uVar8 = param_3[0xe] - 1;
                      param_3[0xe] = uVar8;
                      if (uVar8 == 0) goto LAB_;
                      uVar15 = (ulonglong)uVar8;
                    } while ((short)puVar29[(ulonglong)(uVar8 - 1) + 1] < 0);
                    uVar15 = (ulonglong)*(uint *)(param_3 + 2);
                  }
                  else {
LAB_:
                    pbVar24 = *(byte **)(param_3 + 4);
                    uVar15 = (ulonglong)*(uint *)(param_3 + 2);
                  }
                }
                if ((*pbVar24 & 0x40) == 0) {
                  *(undefined4 *)(param_3 + 0x13) = 0;
                }
                else {
                  *(int *)(param_3 + 0x13) = (int)uVar15;
                  *(int *)(param_3 + 2) = (int)uVar15 + 0xe;
                  *(undefined8 *)(puVar19 + -8) = 0x10086d;
                  uVar13 = func_0x(puVar1);
                  *(undefined8 *)(puVar19 + -8) = 0x100879;
                  func_0x(uVar13,auStack_48);
                  *(undefined8 *)(puVar19 + -8) = 0x100882;
                  iVar10 = func_0x(auStack_48);
                  *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar10;
                  uVar15 = (ulonglong)*(uint *)(param_3 + 2);
                }
                iVar10 = (int)uVar15;
                if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
                   (*(ulonglong *)(param_3 + 0xf) < uVar15 + *(longlong *)(param_3 + 4))) {
                  *(undefined8 *)(puVar19 + -8) = 0x1008b8;
                  cVar7 = func_0x(0x1f13ce0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar19 + -8) = 0x1008c1;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar19 + -8) = 0x1008db;
                      cVar7 = func_0x(0x1f13ce0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar19 + -8) = 0x1008f7;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar19 + 0x20) = 0;
                        *(undefined8 *)(puVar19 + -8) = 0x10091d;
                        (*_DAT_)(1,0x18036ec,0x19237d8,0x886);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(param_3 + 4);
                  *(undefined8 *)(puVar19 + -8) = 0x10092b;
                  func_0x(uVar13,0x12);
                  iVar10 = *(int *)(param_3 + 2);
                }
                if (0x3f3b < iVar10 - 1U) {
                  *(undefined8 *)(puVar19 + -8) = 0x100944;
                  cVar7 = func_0x(0x1f13ce0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)(puVar19 + -8) = 0x10094d;
                    lVar12 = func_0x();
                    if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar19 + -8) = 0x100967;
                      cVar7 = func_0x(0x1f13ce0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)(puVar19 + -8) = 0x100983;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar19 + 0x20) = 0;
                        *(undefined8 *)(puVar19 + -8) = 0x1009a9;
                        (*_DAT_)(1,0x18036ec,0x19237d8,0x88b);
                      }
                    }
                  }
                  uVar13 = *(undefined8 *)(param_3 + 4);
                  *(undefined8 *)(puVar19 + -8) = 0x1009b7;
                  func_0x(uVar13,5);
                }
              }
LAB_:
              sVar23 = -*(short *)puVar27;
              if ((*(byte *)((longlong)puVar27 + 6) & 0x10) != 0) {
                bVar6 = **(byte **)(param_3 + 4);
                if ((bVar6 & 0x10) == 0) {
                  if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
                    puVar31 = (uint *)(ulonglong)uStack_84;
                    puVar20 = *(uint **)(puVar27 + 2) + 1;
                    uVar11 = **(uint **)(puVar27 + 2);
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(param_3 + 8) <= (int)*puVar27) ||
                        (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                         *(ushort *)(puVar27 + 1))) goto LAB_;
              }
              puVar20 = *(uint **)(param_3 + 4);
              if ((uint)(ushort)param_3[0xe] < (uint)(int)sVar23) {
                puVar31 = (uint *)(ulonglong)uStack_84;
                uStack_a8 = 0;
                uVar11 = uStack_a8;
              }
              else {
                uVar11 = *(ushort *)
                          ((longlong)puVar20 +
                          (longlong)sVar23 * 2 + (ulonglong)*(uint *)(param_3 + 10)) & 0x7fff;
                if (sVar23 == 1) {
                  uVar17 = *(uint *)(param_3 + 0xc);
LAB_:
                  if ((uVar11 < uVar17) || (*(uint *)(param_3 + 2) < uVar11)) goto LAB_;
                }
                else {
                  uVar17 = *(ushort *)
                            ((longlong)puVar20 +
                            (longlong)sVar23 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                           0x7fff;
                  if (*(uint *)(param_3 + 0xc) <= uVar17) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar19 + -8) = 0x100a6b;
                  func_0x(puVar20,7);
                  puVar20 = *(uint **)(param_3 + 4);
                }
                puVar20 = (uint *)((longlong)puVar20 + (ulonglong)uVar17);
                puVar31 = (uint *)(ulonglong)uStack_84;
                uVar11 = uVar11 - uVar17;
              }
            }
            else {
              uVar8 = *(ushort *)((longlong)puVar27 + 6);
              if ((uVar8 & 8) == 0) {
                uVar25 = (uint)*(ushort *)(puVar27 + 0xe);
                if ((uVar8 & 0x10) != 0) {
                  bVar6 = **(byte **)(param_3 + 4);
                  if ((bVar6 & 0x10) == 0) {
                    if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
                      uVar11 = **(uint **)(puVar27 + 2);
                      puVar20 = *(uint **)(puVar27 + 2) + 1;
                      if ((uVar25 != 0) && (uVar11 != uVar25)) {
                        *(undefined8 *)(puVar19 + 0x20) = 0;
                        *(undefined8 *)(puVar19 + -8) = 0x10030a;
                        (*_DAT_)(1,0x19b1b30,0x19b0498,0x381);
                      }
                      goto LAB_;
                    }
                  }
                  else if (((int)*(uint *)(param_3 + 8) <= (int)uVar17) ||
                          (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                           *(ushort *)(puVar27 + 1))) goto LAB_;
                }
                puVar20 = (uint *)((longlong)(int)*puVar27 + *(longlong *)(param_3 + 4));
                uVar11 = uVar25;
              }
              else {
                puVar20 = (uint *)0x1588380;
                uStack_a8 = 1;
                uVar11 = uStack_a8;
                if ((*(byte *)((longlong)(int)uVar17 + *(longlong *)(param_3 + 4)) &
                    (byte)(1 << ((byte)uVar8 & 7))) == 0) {
                  puVar20 = (uint *)0x1588381;
                }
              }
            }
          }
        }
        else {
          uStack_90 = 0;
          *(uint **)(puVar19 + 0x20) = &uStack_90;
          *(undefined8 *)(puVar19 + -8) = 0x100b4e;
          puVar20 = (uint *)func_0x(puVar1,puVar27,uVar17,&uStack_a8);
          uVar11 = uStack_a8;
          if ((((*param_3 != 0) && (plVar2 = *(longlong **)(param_3 + 8), plVar2 != (longlong *)0x0)
               ) && (*plVar2 != 0)) &&
             (((*(byte *)((longlong)puVar27 + 6) & 8) == 0 && ((uStack_90 & 1) == 0)))) {
            if ((puVar20 == (uint *)0x0) || (puVar20 == (uint *)0x1588380)) {
              uStack_a8 = 0;
              puVar20 = (uint *)0x0;
              uVar11 = uStack_a8;
            }
            else {
              *(uint *)(puVar19 + 0x38) = uStack_90;
              *(uint **)(puVar19 + 0x30) = &uStack_a8;
              lVar12 = lStack_68;
              *(int *)(puVar19 + 0x28) = (int)puVar28;
              *(longlong *)(puVar19 + 0x20) = lVar12;
              *(undefined8 *)(puVar19 + -8) = 0x100bc3;
              puVar20 = (uint *)func_0x(plVar2,puVar27,puVar20,uVar11);
              uVar11 = uStack_a8;
            }
          }
        }
LAB_:
        uStack_a8 = uVar11;
        puVar21 = (uint *)(ulonglong)uStack_9c;
        uVar11 = uStack_88;
        uVar17 = uStack_8c;
      }
      else {
        uStack_a8 = (uint)*(ushort *)(*param_2 + 0xc + lStack_78 * 0x10);
        puVar20 = *(uint **)(*param_2 + lStack_78 * 0x10);
        uStack_98 = (uint)puVar14;
      }
      lVar12 = lStack_70;
      iVar10 = iStack_80;
      if (((puVar20 != (uint *)0x0) || (uStack_a8 != 0)) ||
         (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar27 + 0xd) + 0x15889a0) +
                   0x1589b30) == '\0')) {
        if (*(byte *)(puVar27 + 0xd) == 0x68) {
          iStack_a0 = iStack_a0 + 1;
          if (uStack_98 < uVar17) {
            iStack_a4 = iStack_a4 + 1;
          }
        }
        else {
          if (*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(puVar27 + 0xd) + 0x15889a0) +
                       0x1589b30) == '\0') {
            uVar8 = *(ushort *)(puVar27 + 0xe);
            if (0x1f9e < uVar8) {
              uVar8 = 0x1f9e;
            }
            uStack_a8 = (uint)uVar8;
          }
          uStack_84 = (int)puVar31 + uStack_a8;
          puVar31 = (uint *)(ulonglong)uStack_84;
          if (uStack_98 < uVar17) {
            uStack_9c = (int)puVar21 + uStack_a8;
            puVar21 = (uint *)(ulonglong)uStack_9c;
          }
        }
      }
      uVar30 = (uint)puVar31;
      uVar25 = (uint)puVar21;
      uStack_98 = uStack_98 + 1;
      puVar14 = (uint *)(ulonglong)uStack_98;
      puVar28 = (uint *)(ulonglong)uStack_94;
      lStack_78 = lStack_78 + 1;
      param_2 = plStack_58;
      param_3 = psStack_40;
    } while (uStack_98 < uVar11);
    if (iStack_a4 != 0) {
      uVar17 = iStack_a4 >> 0x1f & 7;
      uVar11 = iStack_a4 + uVar17;
      uVar25 = uVar25 + (uint)((uVar11 & 7) != uVar17) + ((int)uVar11 >> 3);
    }
    if (iStack_a0 != 0) {
      uVar17 = iStack_a0 >> 0x1f & 7;
      uVar11 = iStack_a0 + uVar17;
      uVar30 = uVar30 + (uint)((uVar11 & 7) != uVar17) + ((int)uVar11 >> 3);
    }
    lVar18 = -1;
    if (param_5 < uVar25) {
      lVar3 = *(longlong *)(lStack_70 + 0x18);
      lVar16 = -1;
      do {
        lVar16 = lVar16 + 1;
      } while (*(short *)(lVar3 + lVar16 * 2) != 0);
      *(uint *)(puVar19 + 0x40) = (iStack_80 != 1) + 0x8a9a;
      *(uint *)(puVar19 + 0x38) = param_5;
      *(longlong *)(puVar19 + 0x30) = lVar3;
      *(int *)(puVar19 + 0x28) = (int)lVar16 * 2;
      *(uint *)(puVar19 + 0x20) = uVar25;
      *(undefined8 *)(puVar19 + -8) = 0x100cfa;
      (*_DAT_)(0x13,0x2e,0x10,3);
    }
    if (param_6 < uVar30) {
      lVar12 = *(longlong *)(lVar12 + 0x18);
      do {
        lVar18 = lVar18 + 1;
      } while (*(short *)(lVar12 + lVar18 * 2) != 0);
      *(uint *)(puVar19 + 0x40) = (iVar10 != 1) + 0x8a9a;
      *(uint *)(puVar19 + 0x38) = param_6;
      *(longlong *)(puVar19 + 0x30) = lVar12;
      *(int *)(puVar19 + 0x28) = (int)lVar18 * 2;
      *(uint *)(puVar19 + 0x20) = uVar30;
      *(undefined8 *)(puVar19 + -8) = 0x100d5a;
      (*_DAT_)(0x13,0x2e,0x10,3);
    }
  }
  uVar15 = uStack_38 ^ (ulonglong)&uStack_a8;
  *(undefined8 *)(puVar19 + -8) = 0x100d66;
  func_0x(uVar15);
  return;
}

