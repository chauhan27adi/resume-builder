
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(uint *param_1,longlong param_2,uint *param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  ushort uVar4;
  uint uVar5;
  int iVar6;
  longlong unaff_GS_OFFSET;
  
  lVar1 = **(longlong **)(param_1 + 8);
  lVar2 = (*(longlong **)(param_1 + 8))[1];
  if (lVar1 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)(lVar1 + 8);
  if (*(char *)(param_2 + 0x2050) != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(param_1 + 0x49) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar5 = 0xffffffff;
  *param_3 = 0xffffffff;
  if ((*(byte *)param_1 & 8) == 0) {
    if ((param_1[0x48] & 0x20) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  else {
    uVar5 = param_1[0x4f];
    *param_3 = uVar5;
    if ((uVar5 == 0x10000000) || (uVar5 == 0x100000)) {
      if ((param_1[0x48] & 0x20) != 0) {
        param_1[0x48] = param_1[0x48] | 1;
        uVar5 = *param_3;
      }
      if (uVar5 == 0x10000000) {
        *param_1 = *param_1 | 0x40;
        uVar5 = 0x1000;
        *param_3 = 0x1000;
      }
    }
  }
  if (uVar5 == 0xffffffff) {
    if ((((*(byte *)(lVar1 + 0x106) & 4) == 0) && ((*(byte *)(lVar1 + 0x107) & 1) == 0)) &&
       (*(char *)(*(longlong *)(lVar2 + 0x30) + 0x2050) != '\0')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *param_3 = *(uint *)(*(longlong *)
                          (*(longlong *)
                            (*(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              ) + 8 + (ulonglong)*_DAT_) + 0x68) + 0x1c);
    if ((*(byte *)(lVar1 + 0x106) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    param_1[0x48] = param_1[0x48] | 1;
    uVar5 = *param_3;
  }
  if ((*(byte *)param_1 & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar5 == 0x100) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar5 != 0x1000000) {
    if (((*(byte *)(param_2 + 0x1cd0) & 1) == 0) && (*(int *)(param_2 + 0x674) != 5)) {
      uVar4 = _DAT_;
      if (*(char *)(*(longlong *)(param_2 + 0x6b0) + 0x939) != '\0') {
        uVar4 = 0x388;
      }
      if (uVar4 <= *(ushort *)(param_2 + 0x67e)) {
        uVar4 = 1;
        if ((DAT_ & 2) == 0) {
          uVar4 = 0x3bd;
        }
        if (*(ushort *)(param_2 + 0x67e) <= uVar4) goto LAB_;
      }
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
LAB_:
  if (*param_3 == 0x1000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((DAT_ & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar1 = *(longlong *)
           ((ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
  if ((lVar1 != 0) && (**(longlong **)(lVar1 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  plVar3 = *(longlong **)(lVar2 + 0x290);
  if (plVar3 != (longlong *)0x0) {
    iVar6 = (**(code **)(*plVar3 + 400))(plVar3);
    if (iVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar5 = *param_3;
    if (uVar5 == 0x1000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (uVar5 == 0x1000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (uVar5 != 0x10000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(longlong *)(param_2 + 0x1b8) = *(longlong *)(param_2 + 0x1b8) + 1;
  }
  return;
}

