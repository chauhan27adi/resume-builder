
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                 undefined8 param_5,longlong param_6)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong unaff_GS_OFFSET;
  undefined auStack_2d8 [72];
  undefined8 uStack_290;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined8 uStack_278;
  longlong **pplStack_268;
  undefined8 uStack_260;
  undefined2 uStack_258;
  longlong lStack_218;
  undefined2 uStack_208;
  undefined4 uStack_204;
  byte *pbStack_200;
  undefined8 uStack_1f8;
  undefined8 uStack_1ea;
  undefined2 uStack_1e2;
  undefined2 uStack_1e0;
  undefined6 uStack_1de;
  undefined4 uStack_1d4;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_2d8;
  uStack_208 = 0xffff;
  pbStack_200 = (byte *)0x0;
  uStack_204 = 0;
  uStack_1ea = 0;
  uStack_1e0 = 0;
  uStack_1de = 0;
  uStack_1f8 = 0;
  uStack_290 = param_2;
  uStack_284 = param_3;
  uStack_278 = param_4;
  pplStack_268 = param_1;
  lVar3 = func_0x(_DAT_,*param_1,1);
  *(ushort *)(lVar3 + 4) = *(ushort *)(lVar3 + 4) & 0xedff;
  *(undefined4 *)(lVar3 + 0x40) = 1;
  lStack_218 = lVar3;
  if (*(short *)((longlong)*param_1 + 0x2c) != 2) {
    lVar4 = (*param_1)[0x12];
    if (lVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)(*(longlong *)(lVar4 + 0x6b0) + 0x3c) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*param_1)[0x12] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(byte *)((*param_1)[0x12] + 0x1cd0) & 0x20) == 0) {
      lVar4 = **param_1;
      if (*(short *)(lVar4 + 0x24) != 0) {
        cVar1 = *(char *)(lVar4 + 1);
        if (cVar1 == '\v') {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((cVar1 == '\b') || (cVar1 == '\t')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
      uStack_260 = *(undefined8 *)(lVar4 + 0x28);
      uStack_258 = *(undefined2 *)(lVar4 + 0x30);
      lVar4 = (*param_1)[0x12];
      if (lVar4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar4 = func_0x(*(undefined8 *)(lVar4 + 0x6a0),
                              *(undefined2 *)((longlong)*param_1 + 0x74),0);
      plVar2 = *param_1;
      if (plVar2[0x12] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(int *)(*(longlong *)(plVar2[0x12] + 0x7a8) + 0x58) == 0) &&
         (*(uint *)(lVar4 + 0x130) <= (uint)uStack_260)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (plVar2[0x12] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)(*(longlong *)(plVar2[0x12] + 0x6b0) + 0x3c) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (plVar2[0x12] == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(plVar2[0x12],*plVar2 + 0x20);
    }
  }
  if ((*(ushort *)(**param_1 + 4) & 0x2000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_6 != 0) {
    if ((DAT_ & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    lVar4 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar4 != 0) && (**(longlong **)(lVar4 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  uStack_1d4 = 0;
  uStack_288 = 9;
  if (*(char *)(lVar3 + 2) < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pbStack_200 = (byte *)((ulonglong)*(ushort *)(lVar3 + 0x1ffe) + lVar3);
  if ((*pbStack_200 & 1) == 0) {
    uStack_208 = 0;
    uStack_204 = 0;
    uStack_1e2 = 0;
    uStack_1e0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010029e */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_200 & 0xe) * 4 + 0xfffbc) - 0x28350))
              (0x24f21e0);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

