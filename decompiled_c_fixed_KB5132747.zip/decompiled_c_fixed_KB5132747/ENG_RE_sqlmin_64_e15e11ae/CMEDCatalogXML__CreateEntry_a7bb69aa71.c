
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,undefined4 param_3)

{
  ushort uVar1;
  char cVar2;
  undefined4 uVar3;
  undefined8 *puVar4;
  undefined auStack_268 [32];
  undefined4 uStack_248;
  undefined4 uStack_240;
  undefined uStack_238;
  undefined auStack_228 [8];
  undefined4 auStack_220 [2];
  undefined4 auStack_218 [2];
  undefined4 auStack_210 [2];
  undefined auStack_208 [4];
  undefined auStack_204 [12];
  undefined8 *puStack_1f8;
  undefined8 *puStack_1f0;
  undefined auStack_1e4 [4];
  undefined8 uStack_1e0;
  undefined8 *puStack_1d8;
  undefined8 *puStack_1d0;
  undefined8 *puStack_1c8;
  undefined8 *puStack_1c0;
  undefined auStack_1b8 [260];
  char cStack_b4;
  undefined4 uStack_88;
  undefined uStack_84;
  undefined4 *puStack_80;
  undefined4 uStack_78;
  undefined4 uStack_70;
  undefined uStack_6c;
  undefined4 *puStack_68;
  undefined4 uStack_60;
  ulonglong uStack_38;
  
  uStack_1e0 = 0xfffffffffffffffe;
  uStack_38 = _DAT_ ^ (ulonglong)auStack_268;
  if (param_2 == 0xc) {
    func_0x(param_1,param_3);
  }
  else {
    if (param_2 != 0xb) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    func_0x(auStack_1b8);
    auStack_228[0] = 0x1b;
    uStack_238 = 1;
    uStack_240 = 0;
    uStack_248 = 0;
    auStack_210[0] = param_3;
    func_0x(auStack_1b8,param_1 + 0x18,0x2c);
    uStack_88 = 1;
    uStack_84 = 0x81;
    puStack_80 = (undefined4 *)auStack_228;
    uStack_78 = 1;
    uStack_70 = 2;
    uStack_6c = 0x81;
    puStack_68 = auStack_210;
    uStack_60 = 4;
    func_0x(auStack_1b8,2,&uStack_88);
    cVar2 = func_0x(auStack_1b8);
    if (cVar2 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    auStack_220[0] = 0x5e0;
    puStack_1f0 = (undefined8 *)**(undefined8 **)(param_1 + 8);
    uStack_248 = CONCAT31(uStack_248._1_3_,6);
    puVar4 = (undefined8 *)(*_DAT_)(0x80,puStack_1f0,0x253eae8,0x5e0);
    if (puVar4 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar1 = *(ushort *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 0x30) + 0x6b8);
    *(undefined4 *)(puVar4 + 1) = 1;
    *(undefined4 *)((longlong)puVar4 + 0xc) = 3;
    puVar4[2] = 0;
    *(undefined4 *)(puVar4 + 3) = 0;
    *(undefined2 *)((longlong)puVar4 + 0x1c) = 0;
    puVar4[4] = 0;
    *puVar4 = 0x2510738;
    *puVar4 = 0x250f8c0;
    *(uint *)(puVar4 + 5) = (uint)uVar1;
    *(undefined4 *)((longlong)puVar4 + 0x2c) = param_3;
    *(undefined4 *)((longlong)puVar4 + 0x34) = 0xffffffff;
    puVar4[7] = 0;
    *(undefined4 *)(puVar4 + 8) = 0;
    puVar4[9] = 0;
    puStack_1d8 = puVar4 + 10;
    *puStack_1d8 = 0;
    *(undefined4 *)(puVar4 + 0xb) = 0;
    puStack_1c8 = puVar4 + 0xc;
    *puStack_1c8 = 0;
    *(undefined4 *)(puVar4 + 0xd) = 0;
    puStack_1c0 = puVar4 + 0xe;
    *puStack_1c0 = 0;
    *(undefined4 *)(puVar4 + 0xf) = 0;
    if (cStack_b4 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_240._0_1_ = 0x38;
    uStack_248 = 4;
    puStack_1f8 = puVar4;
    puStack_1f0 = puVar4;
    puStack_1d0 = puStack_1d8;
    cVar2 = func_0x(auStack_1b8,4,auStack_208,auStack_220);
    if (cVar2 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined4 *)(puVar4 + 6) = auStack_220[0];
    uStack_240._0_1_ = 0;
    uStack_248 = CONCAT31(uStack_248._1_3_,1);
    uVar3 = func_0x(auStack_1b8,3,**(undefined8 **)(param_1 + 8),puVar4 + 7);
    *(undefined4 *)(puVar4 + 8) = uVar3;
    if (cStack_b4 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_240 = CONCAT31(uStack_240._1_3_,0x7f);
    uStack_248 = 8;
    cVar2 = func_0x(auStack_1b8,8,auStack_204,&puStack_1f8);
    if (cVar2 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puVar4[9] = puStack_1f8;
    auStack_228[0] = 0x50;
    uStack_88 = 2;
    uStack_84 = 0x81;
    puStack_80 = auStack_220;
    uStack_78 = 4;
    uStack_70 = 1;
    uStack_6c = 0x81;
    puStack_68 = (undefined4 *)auStack_228;
    uStack_60 = 1;
    uStack_238 = 1;
    uStack_240 = 0;
    uStack_248 = 0;
    auStack_220[0] = param_3;
    func_0x(auStack_1b8,param_1 + 0x18,0x4a);
    func_0x(auStack_1b8,2,&uStack_88);
    cVar2 = func_0x(auStack_1b8);
    while (cVar2 != '\0') {
      if (cStack_b4 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uStack_240._1_3_ = (undefined3)(uStack_240 >> 8);
      uStack_240 = CONCAT31(uStack_240._1_3_,0x38);
      uStack_248 = 4;
      cVar2 = func_0x(auStack_1b8,4,auStack_1e4,auStack_218);
      if (cVar2 == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      func_0x(puVar4 + 10,**(undefined8 **)(param_1 + 8),auStack_218[0]);
      cVar2 = func_0x(auStack_1b8);
    }
    uStack_240 = uStack_240 & 0xffffff00;
    uStack_248 = 0;
    func_0x(auStack_1b8,param_1 + 0x18,0x3b,param_3);
    cVar2 = func_0x(auStack_1b8);
    if (cVar2 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    puStack_1f0 = (undefined8 *)0x0;
    func_0x(auStack_1b8);
    func_0x(auStack_1b8);
  }
  func_0x(uStack_38 ^ (ulonglong)auStack_268);
  return;
}

