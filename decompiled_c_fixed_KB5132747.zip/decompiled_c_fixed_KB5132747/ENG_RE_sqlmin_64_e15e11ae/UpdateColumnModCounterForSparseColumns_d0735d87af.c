
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong param_3)

{
  ushort uVar1;
  short sVar2;
  code *pcVar3;
  ushort *puVar4;
  undefined *puVar5;
  byte bVar6;
  char cVar7;
  ushort uVar8;
  ushort uVar9;
  uint uVar10;
  undefined4 uVar11;
  int iVar12;
  longlong lVar13;
  longlong lVar14;
  longlong lVar15;
  undefined8 uVar16;
  longlong lVar17;
  undefined8 *puVar18;
  ulonglong uVar19;
  byte *pbVar20;
  ushort *puVar21;
  undefined *puVar22;
  uint uVar23;
  uint uVar24;
  uint *puVar25;
  ulonglong uVar26;
  ushort uVar27;
  ushort *puVar28;
  ulonglong uVar29;
  ulonglong uVar30;
  longlong lVar31;
  ulonglong uVar32;
  uint uVar33;
  longlong *plVar34;
  longlong *plVar35;
  ulonglong uVar36;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_160;
  undefined auStack_158 [32];
  undefined8 auStack_138 [2];
  uint auStack_128 [2];
  longlong lStack_120;
  uint uStack_118;
  uint uStack_114;
  uint auStack_110 [2];
  undefined8 uStack_108;
  undefined8 uStack_100;
  ulonglong uStack_f8;
  uint auStack_f0 [2];
  longlong *plStack_e8;
  ushort *puStack_e0;
  longlong lStack_d8;
  longlong lStack_d0;
  uint uStack_c8;
  undefined4 uStack_c4;
  uint uStack_c0;
  uint uStack_bc;
  longlong *plStack_b8;
  longlong lStack_b0;
  longlong *plStack_a8;
  longlong lStack_a0;
  longlong *plStack_98;
  longlong lStack_90;
  undefined auStack_88 [8];
  longlong lStack_80;
  longlong lStack_78;
  ushort *puStack_70;
  undefined auStack_68 [8];
  undefined auStack_60 [8];
  undefined auStack_58 [8];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_128;
  uVar30 = 0;
  uStack_f8 = 0;
  uStack_160 = 0x10004f;
  lStack_120 = param_2;
  plStack_e8 = param_1;
  lStack_d8 = param_3;
  lVar13 = (**(code **)*param_1)();
  uStack_160 = 0x10005a;
  uVar10 = func_0x(lVar13);
  uStack_160 = 0x100069;
  uStack_118 = uVar10;
  uVar11 = func_0x(param_2);
  uStack_108 = CONCAT44(uStack_108._4_4_,uVar11);
  puVar5 = auStack_158;
  if ((int)uVar10 < 1) {
LAB_:
    puVar22 = puVar5;
    pcVar3 = *(code **)(*param_1 + 8);
    *(undefined8 *)(puVar22 + -8) = 0x100989;
    (*pcVar3)(param_1);
    if ((int)uVar10 < 1) goto LAB_;
  }
  else {
    uVar19 = (longlong)(int)uVar10 * 0x20 + 0xf;
    if (uVar19 <= (ulonglong)((longlong)(int)uVar10 * 0x20)) {
      uVar19 = 0xffffffffffffff0;
    }
    uVar19 = uVar19 & 0xfffffffffffffff0;
    uStack_160 = 0x10009e;
    func_0x();
    lVar31 = -uVar19;
    puVar22 = auStack_158 + lVar31;
    puVar21 = (ushort *)(lVar13 + 2);
    uStack_f8 = (longlong)auStack_128 + lVar31;
    puStack_70 = puVar21;
    if (*(int *)(lVar13 + 4) == 0) {
      pbVar20 = *(byte **)(lVar13 + 8);
      uVar10 = *(uint *)(lVar13 + 0x10);
      uVar19 = (ulonglong)uVar10;
      *puVar21 = 0;
      *(uint *)(lVar13 + 0x14) = uVar10;
      bVar6 = *pbVar20;
      if ((bVar6 & 0x10) != 0) {
        uVar10 = uVar10 + 2 + (*(ushort *)(pbVar20 + uVar19) + 7 >> 3);
        uVar19 = (ulonglong)uVar10;
        *(uint *)(lVar13 + 0x14) = uVar10;
        bVar6 = *pbVar20;
      }
      if ((bVar6 & 0x20) == 0) {
        *(int *)(lVar13 + 4) = (int)uVar19;
        *(undefined2 *)(lVar13 + 0x1c) = 0;
        *(int *)(lVar13 + 0x18) = (int)uVar19;
      }
      else {
        puVar28 = (ushort *)(pbVar20 + uVar19);
        uVar8 = *puVar28;
        *(ushort *)(lVar13 + 0x1c) = uVar8;
        if (uVar8 == 0) {
          *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100119;
          cVar7 = func_0x(0x11d6690);
          if (cVar7 != '\0') {
            *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100122;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10013c;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 == '\0') {
                *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100158;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)((longlong)auStack_138 + lVar31) = 0;
                *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10017e;
                (*_DAT_)(1,0xac609c,0xbe6188,0x80f);
              }
            }
          }
          uVar16 = *(undefined8 *)(lVar13 + 8);
          *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10018c;
          func_0x(uVar16,3);
          uVar8 = *(ushort *)(lVar13 + 0x1c);
          uVar19 = (ulonglong)*(uint *)(lVar13 + 0x14);
        }
        uVar10 = (int)uVar19 + (uVar8 + 1) * 2;
        *(uint *)(lVar13 + 0x18) = uVar10;
        if (0x1f9e < uVar10) {
          *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1001bc;
          cVar7 = func_0x(0x11d6690);
          if (cVar7 != '\0') {
            *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1001c5;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1001df;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 == '\0') {
                *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1001fb;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)auStack_138 + lVar31) = 0;
                *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100221;
                (*_DAT_)(1,0xac609c,0xbe6188,0x816);
              }
            }
          }
          uVar16 = *(undefined8 *)(lVar13 + 8);
          *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10022f;
          func_0x(uVar16,4);
          uVar8 = *(ushort *)(lVar13 + 0x1c);
          uVar10 = *(uint *)(lVar13 + 0x18);
        }
        uVar19 = (ulonglong)uVar8;
        uVar8 = puVar28[uVar19];
        *(uint *)(lVar13 + 4) = uVar8 & 0x7fff;
        if ((uVar8 & 0x7fff) < uVar10) {
          *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10025e;
          cVar7 = func_0x(0x11d6690);
          if (cVar7 != '\0') {
            *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100267;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100281;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 == '\0') {
                *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10029d;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)auStack_138 + lVar31) = 0;
                *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1002c3;
                (*_DAT_)(1,0xac609c,0xbe6188,0x81d);
              }
            }
          }
          uVar16 = *(undefined8 *)(lVar13 + 8);
          *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1002d1;
          func_0x(uVar16,4);
          uVar10 = *(uint *)(lVar13 + 0x18);
          uVar19 = (ulonglong)*(ushort *)(lVar13 + 0x1c);
        }
        puVar4 = puVar28;
        if ((short)uVar19 != 0) {
          do {
            uVar23 = puVar4[1] & 0x7fff;
            if ((uVar23 < uVar10) || (*(uint *)(lVar13 + 4) < uVar23)) {
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100313;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 != '\0') {
                *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10031c;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100336;
                  cVar7 = func_0x(0x11d6690);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100352;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)auStack_138 + lVar31) = 0;
                    *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10037c;
                    (*_DAT_)(1,0xac609c,0xbe6188,0x82a);
                  }
                }
              }
              uVar16 = *(undefined8 *)(lVar13 + 8);
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10038a;
              func_0x(uVar16,4);
            }
            uVar19 = (ulonglong)*(ushort *)(lVar13 + 0x1c);
            uVar33 = (int)uVar30 + 1;
            uVar30 = (ulonglong)uVar33;
            puVar4 = puVar4 + 1;
            uVar10 = uVar23;
          } while ((int)uVar33 < (int)(uint)*(ushort *)(lVar13 + 0x1c));
        }
        if ((short)puVar28[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
          lVar14 = *(longlong *)(lVar13 + 8);
          do {
            lVar15 = (ulonglong)*(uint *)(lVar13 + 0x14) + lVar14;
            uVar10 = *(ushort *)(lVar15 + uVar19 * 2) & 0x7fff;
            if ((int)uVar19 == 1) {
              uVar23 = *(uint *)(lVar13 + 0x18);
              uVar30 = (ulonglong)uVar23;
LAB_:
              if ((uVar10 < (uint)uVar30) || (*(uint *)(lVar13 + 4) < uVar10)) goto LAB_;
            }
            else {
              uVar23 = *(uint *)(lVar13 + 0x18);
              uVar33 = *(ushort *)(lVar15 + -2 + uVar19 * 2) & 0x7fff;
              uVar30 = (ulonglong)uVar33;
              if (uVar23 <= uVar33) goto LAB_;
LAB_:
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100408;
              func_0x(lVar14,7);
              uVar23 = *(uint *)(lVar13 + 0x18);
            }
            uVar33 = (uint)uVar30;
            if ((uVar33 < uVar23) || (*(uint *)(lVar13 + 4) < uVar33)) goto LAB_;
            lVar14 = *(longlong *)(lVar13 + 8);
            if (*(ushort *)(uVar30 + lVar14) == 5) {
              *puVar21 = *puVar21 | 2;
              *(short *)(lVar13 + 0x1c) = *(short *)(lVar13 + 0x1c) + -1;
              uVar8 = *(ushort *)(lVar13 + 0x2c) & 0xc7ff;
              uVar19 = uVar30 & 0xffff;
              *(short *)(lVar13 + 0x2a) = (short)uVar30;
              uVar30 = *(ulonglong *)(lVar13 + 8);
              if ((*(ushort *)(uVar19 + 2 + uVar30) >> 0xe & 1) != 0) {
                uVar8 = *(ushort *)(uVar19 + 2 + uVar30) & 0x3800 | uVar8;
              }
              *(ushort *)(lVar13 + 0x2c) = uVar8;
              uVar9 = (uVar8 ^ *(ushort *)(uVar19 + 2 + uVar30)) & 0x7ff ^ uVar8;
              *(ushort *)(lVar13 + 0x2c) = uVar9;
              uVar32 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar19 + (uVar8 >> 0xb & 7) * 2 +
                       uVar30;
              if (uVar32 < uVar19 + uVar30) {
                *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100510;
                func_0x(uVar19 + uVar30,0x19);
                uVar9 = *(ushort *)(lVar13 + 0x2c);
                uVar19 = (ulonglong)*(ushort *)(lVar13 + 0x2a);
                uVar30 = (ulonglong)*(uint *)(lVar13 + 8);
              }
              if (uVar10 - uVar33 <
                  (((uVar9 & 0x7ff) * 2 - (int)uVar19) - (int)uVar30) + (int)uVar32) {
                lVar14 = *(longlong *)(lVar13 + 8);
                *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100548;
                func_0x(uVar19 + lVar14,0x19);
                uVar9 = *(ushort *)(lVar13 + 0x2c);
              }
              if ((uVar9 & 0x3800) != 0) {
                puVar28 = (ushort *)
                          (*(longlong *)(lVar13 + 8) + (ulonglong)*(ushort *)(lVar13 + 0x2a) + 4);
                iVar12 = 0;
                if ((uVar9 & 0x3800) != 0) {
                  do {
                    if ((uVar9 & 0x7ff) < (*puVar28 & 0x7ff)) {
                      uVar8 = *(ushort *)(lVar13 + 0x2a);
                      lVar14 = *(longlong *)(lVar13 + 8);
                      *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1005a7;
                      func_0x((ulonglong)uVar8 + lVar14,0x1a);
                      uVar9 = *(ushort *)(lVar13 + 0x2c);
                    }
                    iVar12 = iVar12 + 1;
                    puVar28 = puVar28 + 1;
                  } while (iVar12 < (int)(uVar9 >> 0xb & 7));
                }
              }
              goto LAB_;
            }
            if (*(ushort *)(uVar30 + lVar14) < 0x400) goto LAB_;
            *puVar21 = *puVar21 | 1;
            uVar8 = *(short *)(lVar13 + 0x1c) - 1;
            *(ushort *)(lVar13 + 0x1c) = uVar8;
            if (uVar8 == 0) goto LAB_;
            uVar19 = (ulonglong)uVar8;
          } while ((short)puVar28[(ulonglong)(uVar8 - 1) + 1] < 0);
          pbVar20 = *(byte **)(lVar13 + 8);
          uVar19 = (ulonglong)*(uint *)(lVar13 + 4);
        }
        else {
LAB_:
          pbVar20 = *(byte **)(lVar13 + 8);
          uVar19 = (ulonglong)*(uint *)(lVar13 + 4);
        }
      }
      if ((*pbVar20 & 0x40) == 0) {
        *(undefined4 *)(lVar13 + 0x26) = 0;
      }
      else {
        *(int *)(lVar13 + 0x26) = (int)uVar19;
        *(int *)(lVar13 + 4) = (int)uVar19 + 0xe;
        *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1005f2;
        uVar16 = func_0x(puVar21);
        *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100601;
        func_0x(uVar16,auStack_88);
        *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10060d;
        iVar12 = func_0x(auStack_88);
        *(int *)(lVar13 + 4) = *(int *)(lVar13 + 4) + iVar12;
        uVar19 = (ulonglong)*(uint *)(lVar13 + 4);
      }
      iVar12 = (int)uVar19;
      if ((*(ulonglong *)(lVar13 + 0x1e) != 0) &&
         (*(ulonglong *)(lVar13 + 0x1e) < uVar19 + *(longlong *)(lVar13 + 8))) {
        *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100645;
        cVar7 = func_0x(0x11d6690);
        if (cVar7 != '\0') {
          *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10064e;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100668;
            cVar7 = func_0x(0x11d6690);
            if (cVar7 == '\0') {
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100684;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)((longlong)auStack_138 + lVar31) = 0;
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1006aa;
              (*_DAT_)(1,0xac609c,0xbe6188,0x886);
            }
          }
        }
        uVar16 = *(undefined8 *)(lVar13 + 8);
        *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1006b8;
        func_0x(uVar16,0x12);
        iVar12 = *(int *)(lVar13 + 4);
      }
      if (0x3f3b < iVar12 - 1U) {
        *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1006d2;
        cVar7 = func_0x(0x11d6690);
        if (cVar7 != '\0') {
          *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1006db;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x1006f5;
            cVar7 = func_0x(0x11d6690);
            if (cVar7 == '\0') {
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100711;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)((longlong)auStack_138 + lVar31) = 0;
              *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100737;
              (*_DAT_)(1,0xac609c,0xbe6188,0x88b);
            }
          }
        }
        uVar16 = *(undefined8 *)(lVar13 + 8);
        *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100745;
        func_0x(uVar16,5);
      }
    }
LAB_:
    *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10074d;
    iVar12 = func_0x(puVar21);
    uVar30 = uStack_f8;
    puVar5 = auStack_158 + lVar31;
    uVar10 = uStack_118;
    if (iVar12 == 0) goto LAB_;
    uVar8 = *(ushort *)(lVar13 + 0x2c);
    uVar23 = uVar8 & 0x7ff;
    uStack_100 = CONCAT44(uStack_100._4_4_,(uint)uVar8) & 0xffffffff000007ff;
    if (uVar23 < uStack_118) {
      if ((uVar8 & 0x7ff) != 0) goto code_r0x00100782;
    }
    else {
      uStack_100 = CONCAT44(uStack_100._4_4_,uStack_118);
      uVar23 = uStack_118;
code_r0x00100782:
      lVar15 = *(longlong *)(lVar13 + 8);
      uVar19 = (ulonglong)*(ushort *)(lVar13 + 0x2a);
      uVar33 = *(ushort *)(lVar13 + 0x2c) >> 0xb & 7;
      uVar10 = (*(ushort *)(lVar13 + 0x2c) & 0x7ff) * 2;
      lVar14 = uVar19 + lVar15;
      uVar30 = (ulonglong)(uVar33 * 2);
      lStack_78 = lVar15 + 4 + uVar19 + uVar30;
      lStack_80 = uVar30 + 4 + uVar10 + uVar19 + lVar15;
      puStack_e0 = (ushort *)(lVar14 + 4);
      uVar10 = (((uint)*(ushort *)(lVar13 + 0x2a) + (uVar10 + 2 + uVar33) * 2) - (int)lVar14) +
               (int)lVar15;
      auStack_128[0] = 0;
      uVar30 = 0;
      lVar13 = 0;
      uVar8 = uStack_c4._2_2_;
      lStack_d0 = lVar14;
      do {
        uVar9 = puVar21[0x15];
        if ((uVar9 & 0x3800) == 0) {
          uVar27 = *(ushort *)((ulonglong)puVar21[0x14] + 2 + *(longlong *)(puVar21 + 3));
        }
        else {
          if ((int)(uVar9 >> 0xb & 7) <= (int)auStack_128[0]) {
            *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100835;
            func_0x(lVar14,0x1b);
          }
          uVar27 = *puStack_e0;
          uVar9 = uVar27;
        }
        lVar15 = (ulonglong)(uVar9 & 0x7ff) - 1;
        if (lVar13 <= lVar15) {
          puVar25 = (uint *)(uStack_f8 + 0xc + lVar13 * 0x20);
          puVar28 = (ushort *)(lStack_80 + lVar13 * 2);
          uVar19 = uVar30;
          uVar9 = uVar8;
          do {
            puVar21 = puStack_70;
            lVar14 = lStack_d0;
            uVar30 = uVar19;
            uVar8 = uVar9;
            if ((longlong)(ulonglong)uVar23 <= lVar13) break;
            lVar13 = lVar13 + 1;
            uVar33 = (uint)*(ushort *)((lStack_78 - lStack_80) + (longlong)puVar28) +
                     (uint)(uVar27 >> 0xb & 7) * 0x10000 | 0x80000000;
            uVar1 = *puVar28;
            uVar8 = uVar9 & 0xfff0;
            uVar30 = (ulonglong)((int)uVar19 + 1);
            uStack_c4 = (uVar9 & 0xfff0) << 0x10;
            uVar9 = *(ushort *)(lStack_80 + uVar19 * 2);
            *(ulonglong *)(puVar25 + -3) = (ulonglong)uVar10 + lStack_d0;
            puVar25[-1] = (uVar1 & 0x7fff) - uVar10;
            *puVar25 = (uint)(uVar9 >> 0xf) | *puVar25 & 0xfffffff0;
            puVar25[1] = uVar33;
            puVar25[2] = uStack_c4;
            puVar25[3] = uStack_c0;
            puVar25[4] = uStack_bc;
            puVar25 = puVar25 + 8;
            uVar10 = *puVar28 & 0x7fff;
            puVar28 = puVar28 + 1;
            uVar19 = uVar30;
            uVar9 = uVar8;
            uStack_c8 = uVar33;
          } while (lVar13 <= lVar15);
        }
        auStack_128[0] = auStack_128[0] + 1;
        puStack_e0 = puStack_e0 + 1;
      } while (lVar13 < (longlong)(ulonglong)uVar23);
      param_1 = plStack_e8;
      uVar23 = (uint)uStack_100;
    }
    uVar30 = uStack_f8;
    uVar10 = uStack_118;
    puVar5 = auStack_158 + lVar31;
    if ((int)uStack_118 <= (int)uVar23) goto LAB_;
    uVar33 = uStack_118 - uVar23;
    lVar13 = (longlong)(int)uVar23 * 0x20 + uStack_f8;
    *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x10096f;
    func_0x(lVar13,0,(ulonglong)uVar33 << 5);
    pcVar3 = *(code **)(*param_1 + 8);
    *(undefined8 *)(auStack_158 + lVar31 + -8) = 0x100979;
    (*pcVar3)(param_1);
  }
  uStack_114 = *(uint *)(uVar30 + 0x10) & 0x1fffffff;
LAB_:
  lVar13 = lStack_120;
  lVar31 = (longlong)(int)uStack_108;
  uVar23 = 0;
  auStack_128[0] = 0;
  if (0 < (int)uStack_108) {
    puVar21 = (ushort *)(lStack_120 + 2);
    if (*(int *)(lStack_120 + 4) == 0) {
      pbVar20 = *(byte **)(lStack_120 + 8);
      uVar33 = *(uint *)(lStack_120 + 0x10);
      uVar30 = (ulonglong)uVar33;
      *puVar21 = 0;
      *(uint *)(lStack_120 + 0x14) = uVar33;
      bVar6 = *pbVar20;
      if ((bVar6 & 0x10) != 0) {
        uVar33 = uVar33 + 2 + (*(ushort *)(pbVar20 + uVar30) + 7 >> 3);
        uVar30 = (ulonglong)uVar33;
        *(uint *)(lStack_120 + 0x14) = uVar33;
        bVar6 = *pbVar20;
      }
      if ((bVar6 & 0x20) == 0) {
        *(int *)(lStack_120 + 4) = (int)uVar30;
        *(undefined2 *)(lStack_120 + 0x1c) = 0;
        *(int *)(lStack_120 + 0x18) = (int)uVar30;
        lVar14 = lStack_120;
      }
      else {
        puVar28 = (ushort *)(pbVar20 + uVar30);
        uVar8 = *puVar28;
        *(ushort *)(lStack_120 + 0x1c) = uVar8;
        if (uVar8 == 0) {
          *(undefined8 *)(puVar22 + -8) = 0x100a1e;
          cVar7 = func_0x(0x11d6690);
          if (cVar7 != '\0') {
            *(undefined8 *)(puVar22 + -8) = 0x100a27;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)(puVar22 + -8) = 0x100a41;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 == '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x100a5d;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(puVar22 + 0x20) = 0;
                *(undefined8 *)(puVar22 + -8) = 0x100a83;
                (*_DAT_)(1,0xac609c,0xbe6188,0x80f);
              }
            }
          }
          uVar16 = *(undefined8 *)(lVar13 + 8);
          *(undefined8 *)(puVar22 + -8) = 0x100a91;
          func_0x(uVar16,3);
          uVar8 = *(ushort *)(lVar13 + 0x1c);
          uVar30 = (ulonglong)*(uint *)(lVar13 + 0x14);
        }
        uVar33 = (int)uVar30 + (uVar8 + 1) * 2;
        *(uint *)(lVar13 + 0x18) = uVar33;
        if (0x1f9e < uVar33) {
          *(undefined8 *)(puVar22 + -8) = 0x100ac1;
          cVar7 = func_0x(0x11d6690);
          if (cVar7 != '\0') {
            *(undefined8 *)(puVar22 + -8) = 0x100aca;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)(puVar22 + -8) = 0x100ae4;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 == '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x100b00;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar22 + 0x20) = 0;
                *(undefined8 *)(puVar22 + -8) = 0x100b26;
                (*_DAT_)(1,0xac609c,0xbe6188,0x816);
              }
            }
          }
          uVar16 = *(undefined8 *)(lVar13 + 8);
          *(undefined8 *)(puVar22 + -8) = 0x100b34;
          func_0x(uVar16,4);
          uVar8 = *(ushort *)(lVar13 + 0x1c);
          uVar33 = *(uint *)(lVar13 + 0x18);
        }
        uVar30 = (ulonglong)uVar8;
        uVar8 = puVar28[uVar30];
        *(uint *)(lVar13 + 4) = uVar8 & 0x7fff;
        if ((uVar8 & 0x7fff) < uVar33) {
          *(undefined8 *)(puVar22 + -8) = 0x100b62;
          cVar7 = func_0x(0x11d6690);
          if (cVar7 != '\0') {
            *(undefined8 *)(puVar22 + -8) = 0x100b6b;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)(puVar22 + -8) = 0x100b85;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 == '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x100ba1;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(puVar22 + 0x20) = 0;
                *(undefined8 *)(puVar22 + -8) = 0x100bc7;
                (*_DAT_)(1,0xac609c,0xbe6188,0x81d);
              }
            }
          }
          uVar16 = *(undefined8 *)(lVar13 + 8);
          *(undefined8 *)(puVar22 + -8) = 0x100bd5;
          func_0x(uVar16,4);
          uVar33 = *(uint *)(lVar13 + 0x18);
          uVar30 = (ulonglong)*(ushort *)(lVar13 + 0x1c);
        }
        lVar14 = lVar13;
        puVar4 = puVar28;
        if ((short)uVar30 != 0) {
          do {
            uVar24 = puVar4[1] & 0x7fff;
            if ((uVar24 < uVar33) || (*(uint *)(lVar13 + 4) < uVar24)) {
              *(undefined8 *)(puVar22 + -8) = 0x100c0f;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x100c18;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x100c32;
                  cVar7 = func_0x(0x11d6690);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x100c4e;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x100c74;
                    (*_DAT_)(1,0xac609c,0xbe6188,0x82a);
                  }
                }
              }
              uVar16 = *(undefined8 *)(lVar13 + 8);
              *(undefined8 *)(puVar22 + -8) = 0x100c82;
              func_0x(uVar16,4);
            }
            uVar30 = (ulonglong)*(ushort *)(lVar13 + 0x1c);
            uVar23 = uVar23 + 1;
            lVar14 = lStack_120;
            puVar4 = puVar4 + 1;
            uVar10 = uStack_118;
            uVar33 = uVar24;
          } while ((int)uVar23 < (int)(uint)*(ushort *)(lVar13 + 0x1c));
        }
        if ((short)puVar28[(ulonglong)((int)uVar30 - 1) + 1] < 0) {
          lVar15 = *(longlong *)(lVar13 + 8);
LAB_:
          lVar17 = (ulonglong)*(uint *)(lVar13 + 0x14) + lVar15;
          if ((int)uVar30 == 1) {
            uVar23 = *(uint *)(lVar13 + 0x18);
            uVar24 = *(ushort *)(lVar17 + uVar30 * 2) & 0x7fff;
            uVar33 = uVar23;
LAB_:
            if ((uVar24 < uVar23) || (*(uint *)(lVar13 + 4) < uVar24)) goto LAB_;
          }
          else {
            uVar33 = *(uint *)(lVar14 + 0x18);
            uVar24 = *(ushort *)(lVar17 + uVar30 * 2) & 0x7fff;
            uVar23 = *(ushort *)(lVar17 + -2 + uVar30 * 2) & 0x7fff;
            if (uVar33 <= uVar23) goto LAB_;
LAB_:
            *(undefined8 *)(puVar22 + -8) = 0x100d11;
            func_0x(lVar15,7);
            uVar33 = *(uint *)(lStack_120 + 0x18);
          }
          if ((uVar23 < uVar33) || (*(uint *)(lVar13 + 4) < uVar23)) goto LAB_;
          lVar15 = *(longlong *)(lVar13 + 8);
          if (*(ushort *)((ulonglong)uVar23 + lVar15) == 5) {
            *puVar21 = *puVar21 | 2;
            *(short *)(lVar13 + 0x1c) = *(short *)(lVar13 + 0x1c) + -1;
            uVar19 = *(ulonglong *)(lVar13 + 8);
            uVar32 = (ulonglong)(uVar23 & 0xffff);
            uVar8 = *(ushort *)(lVar13 + 0x2c) & 0xc7ff;
            uVar30 = uVar32 + uVar19;
            *(short *)(lVar13 + 0x2a) = (short)uVar23;
            if ((*(ushort *)(uVar30 + 2) >> 0xe & 1) != 0) {
              uVar8 = *(ushort *)(uVar30 + 2) & 0x3800 | uVar8;
            }
            *(ushort *)(lVar13 + 0x2c) = uVar8;
            uVar9 = (uVar8 ^ *(ushort *)(uVar30 + 2)) & 0x7ff ^ uVar8;
            *(ushort *)(lVar13 + 0x2c) = uVar9;
            uVar29 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar19 + (uVar8 >> 0xb & 7) * 2 + uVar32
            ;
            if (uVar29 < uVar30) {
              *(undefined8 *)(puVar22 + -8) = 0x100e21;
              func_0x(uVar30,0x19);
              uVar9 = *(ushort *)(lVar13 + 0x2c);
              uVar32 = (ulonglong)*(ushort *)(lVar13 + 0x2a);
              uVar19 = (ulonglong)*(uint *)(lVar13 + 8);
            }
            if (uVar24 - uVar23 < (((uVar9 & 0x7ff) * 2 - (int)uVar32) - (int)uVar19) + (int)uVar29)
            {
              lVar14 = *(longlong *)(lVar13 + 8);
              *(undefined8 *)(puVar22 + -8) = 0x100e5c;
              func_0x(uVar32 + lVar14,0x19);
              uVar9 = *(ushort *)(lVar13 + 0x2c);
            }
            iVar12 = 0;
            if (((uVar9 & 0x3800) != 0) &&
               (puVar28 = (ushort *)
                          (*(longlong *)(lVar13 + 8) + 4 + (ulonglong)*(ushort *)(lVar13 + 0x2a)),
               (uVar9 & 0x3800) != 0)) {
              do {
                if ((uVar9 & 0x7ff) < (*puVar28 & 0x7ff)) {
                  uVar8 = *(ushort *)(lVar13 + 0x2a);
                  lVar14 = *(longlong *)(lVar13 + 8);
                  *(undefined8 *)(puVar22 + -8) = 0x100ec6;
                  func_0x((ulonglong)uVar8 + lVar14,0x1a);
                  uVar9 = *(ushort *)(lVar13 + 0x2c);
                }
                iVar12 = iVar12 + 1;
                puVar28 = puVar28 + 1;
              } while (iVar12 < (int)(uVar9 >> 0xb & 7));
            }
            pbVar20 = *(byte **)(lStack_120 + 8);
            uVar30 = (ulonglong)*(uint *)(lStack_120 + 4);
            lVar14 = lStack_120;
            goto LAB_;
          }
          lVar14 = lStack_120;
          if (0x3ff < *(ushort *)((ulonglong)uVar23 + lVar15)) goto code_r0x00100d4b;
        }
LAB_:
        pbVar20 = *(byte **)(lVar14 + 8);
        uVar30 = (ulonglong)*(uint *)(lVar14 + 4);
      }
LAB_:
      if ((*pbVar20 & 0x40) == 0) {
        *(undefined4 *)(lVar13 + 0x26) = 0;
      }
      else {
        *(int *)(lVar13 + 0x26) = (int)uVar30;
        *(int *)(lVar13 + 4) = (int)uVar30 + 0xe;
        *(undefined8 *)(puVar22 + -8) = 0x100f19;
        uVar16 = func_0x(puVar21);
        *(undefined8 *)(puVar22 + -8) = 0x100f28;
        func_0x(uVar16,auStack_68);
        *(undefined8 *)(puVar22 + -8) = 0x100f34;
        iVar12 = func_0x(auStack_68);
        *(int *)(lVar13 + 4) = *(int *)(lVar13 + 4) + iVar12;
        uVar30 = (ulonglong)*(uint *)(lVar13 + 4);
      }
      iVar12 = (int)uVar30;
      if ((*(ulonglong *)(lVar13 + 0x1e) != 0) &&
         (*(ulonglong *)(lVar13 + 0x1e) < uVar30 + *(longlong *)(lVar13 + 8))) {
        *(undefined8 *)(puVar22 + -8) = 0x100f6d;
        cVar7 = func_0x(0x11d6690);
        if (cVar7 != '\0') {
          *(undefined8 *)(puVar22 + -8) = 0x100f76;
          lVar15 = func_0x();
          if ((lVar15 != 0) && (*(char *)(lVar15 + 0x499) != '\0')) {
            *(undefined8 *)(puVar22 + -8) = 0x100f90;
            cVar7 = func_0x(0x11d6690);
            if (cVar7 == '\0') {
              *(undefined8 *)(puVar22 + -8) = 0x100fac;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x100fd2;
              (*_DAT_)(1,0xac609c,0xbe6188,0x886);
            }
          }
        }
        uVar16 = *(undefined8 *)(lVar13 + 8);
        *(undefined8 *)(puVar22 + -8) = 0x100fe0;
        func_0x(uVar16,0x12);
        iVar12 = *(int *)(lVar14 + 4);
      }
      if (0x3f3b < iVar12 - 1U) {
        *(undefined8 *)(puVar22 + -8) = 0x100ff9;
        cVar7 = func_0x(0x11d6690);
        if (cVar7 != '\0') {
          *(undefined8 *)(puVar22 + -8) = 0x101002;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)(puVar22 + -8) = 0x10101c;
            cVar7 = func_0x(0x11d6690);
            if (cVar7 == '\0') {
              *(undefined8 *)(puVar22 + -8) = 0x101038;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x10105e;
              (*_DAT_)(1,0xac609c,0xbe6188,0x88b);
            }
          }
        }
        uVar16 = *(undefined8 *)(lVar13 + 8);
        *(undefined8 *)(puVar22 + -8) = 0x10106c;
        func_0x(uVar16,5);
      }
    }
LAB_:
    *(undefined8 *)(puVar22 + -8) = 0x101074;
    iVar12 = func_0x(puVar21);
    if (iVar12 == 0) {
      *(undefined8 *)(puVar22 + -8) = 0x10115f;
      iVar12 = func_0x(puVar21);
      uVar23 = auStack_128[0];
      if (iVar12 == 0) {
        *(undefined8 *)(puVar22 + 0x20) = 0;
        *(undefined8 *)(puVar22 + -8) = 0x101188;
        (*_DAT_)(1,0xc81db8,0xc72e48,0xd7a);
        uVar23 = auStack_128[0];
      }
    }
    else {
      lVar14 = 0;
      uVar8 = 0;
      if ((*(ushort *)(lVar13 + 0x2c) & 0x7ff) == 0) {
        *(undefined8 *)(puVar22 + 0x20) = 0;
        *(undefined8 *)(puVar22 + -8) = 0x10114f;
        (*_DAT_)(1,0xc81d88,0xc81d50,0x41a);
        uVar23 = 0;
      }
      else {
        uVar30 = (ulonglong)*(ushort *)(lVar13 + 0x2a);
        lVar15 = *(longlong *)(lVar13 + 8);
        if ((*(ushort *)(lVar13 + 0x2c) & 0x3800) == 0) {
          uVar27 = *(ushort *)(lVar15 + 2 + uVar30);
LAB_:
          uVar8 = uVar27 >> 0xb & 7;
        }
        else {
          uVar9 = *(ushort *)(lVar13 + 0x2c) >> 0xb;
          if ((uVar9 & 7) != 0) {
            do {
              if (((lVar14 == 0) || ((*(ushort *)(lVar15 + uVar30 + 2 + lVar14 * 2) & 0x7ff) == 0))
                 && (uVar27 = *(ushort *)(lVar15 + uVar30 + 4 + lVar14 * 2),
                    -1 < (int)((uVar27 & 0x7ff) - 1))) goto LAB_;
              lVar14 = lVar14 + 1;
            } while (lVar14 < (longlong)(ulonglong)(uVar9 & 7));
          }
        }
        auStack_110[0] =
             (uint)*(ushort *)
                    ((ulonglong)((*(ushort *)(lVar13 + 0x2c) >> 0xb & 7) * 2) + lVar15 + 4 + uVar30)
             + (uint)uVar8 * 0x10000;
        uVar23 = 0;
      }
    }
  }
  uVar30 = 0;
  lVar13 = (longlong)(int)uVar10;
  uVar33 = 0;
  uStack_108 = lVar13;
  uStack_100 = lVar31;
  if (0 < (int)uVar10) {
    uStack_118 = 0;
    uVar19 = uVar30;
    uVar32 = uVar30;
    do {
      lVar31 = lStack_120;
      iVar12 = 0;
      uVar33 = (uint)uVar30;
      if ((longlong)uStack_100 <= (longlong)uVar19) break;
      if (uStack_114 < auStack_110[0]) {
        uStack_118 = uVar33 + 1;
        auStack_f0[0] = uStack_114;
        uVar32 = uVar32 + 1;
        uVar29 = uVar19;
        if ((longlong)uVar32 < lVar13) {
          uStack_114 = *(uint *)(uVar32 * 0x20 + 0x10 + uStack_f8) & 0x1fffffff;
        }
      }
      else if (auStack_110[0] < uStack_114) {
        auStack_128[0] = uVar23 + 1;
        auStack_f0[0] = auStack_110[0];
        uVar29 = uVar19 + 1;
        if ((longlong)uVar29 < (longlong)uStack_100) {
          puVar21 = (ushort *)(lStack_120 + 2);
          if (*(int *)(lStack_120 + 4) == 0) {
            pbVar20 = *(byte **)(lStack_120 + 8);
            uVar10 = *(uint *)(lStack_120 + 0x10);
            uVar30 = (ulonglong)uVar10;
            *puVar21 = 0;
            *(uint *)(lStack_120 + 0x14) = uVar10;
            bVar6 = *pbVar20;
            if ((bVar6 & 0x10) != 0) {
              uVar10 = uVar10 + 2 + (*(ushort *)(pbVar20 + uVar30) + 7 >> 3);
              uVar30 = (ulonglong)uVar10;
              *(uint *)(lStack_120 + 0x14) = uVar10;
              bVar6 = *pbVar20;
            }
            if ((bVar6 & 0x20) == 0) {
              *(int *)(lStack_120 + 4) = (int)uVar30;
              *(undefined2 *)(lStack_120 + 0x1c) = 0;
              *(int *)(lStack_120 + 0x18) = (int)uVar30;
              lVar13 = lStack_120;
            }
            else {
              plVar34 = (longlong *)(pbVar20 + uVar30);
              uVar8 = *(ushort *)plVar34;
              *(ushort *)(lStack_120 + 0x1c) = uVar8;
              plStack_e8 = plVar34;
              if (uVar8 == 0) {
                *(undefined8 *)(puVar22 + -8) = 0x101286;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 != '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x10128f;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar22 + -8) = 0x1012a9;
                    cVar7 = func_0x(0x11d6690);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x1012c5;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar22 + 0x20) = 0;
                      *(undefined8 *)(puVar22 + -8) = 0x1012eb;
                      (*_DAT_)(1,0xac609c,0xbe6188,0x80f);
                    }
                  }
                }
                uVar16 = *(undefined8 *)(lVar31 + 8);
                *(undefined8 *)(puVar22 + -8) = 0x1012f9;
                func_0x(uVar16,3);
                uVar30 = (ulonglong)*(uint *)(lVar31 + 0x14);
                uVar8 = *(ushort *)(lVar31 + 0x1c);
              }
              uVar10 = (int)uVar30 + (uVar8 + 1) * 2;
              *(uint *)(lVar31 + 0x18) = uVar10;
              if (0x1f9e < uVar10) {
                *(undefined8 *)(puVar22 + -8) = 0x101329;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 != '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x101332;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar22 + -8) = 0x10134c;
                    cVar7 = func_0x(0x11d6690);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x101368;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar22 + 0x20) = 0;
                      *(undefined8 *)(puVar22 + -8) = 0x10138e;
                      (*_DAT_)(1,0xac609c,0xbe6188,0x816);
                    }
                  }
                }
                uVar16 = *(undefined8 *)(lVar31 + 8);
                *(undefined8 *)(puVar22 + -8) = 0x10139c;
                func_0x(uVar16,4);
                uVar8 = *(ushort *)(lVar31 + 0x1c);
                uVar10 = *(uint *)(lVar31 + 0x18);
              }
              uVar30 = (ulonglong)uVar8;
              uVar23 = *(ushort *)((longlong)plVar34 + uVar30 * 2) & 0x7fff;
              *(uint *)(lVar31 + 4) = uVar23;
              if (uVar23 < uVar10) {
                *(undefined8 *)(puVar22 + -8) = 0x1013cc;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 != '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x1013d5;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar22 + -8) = 0x1013ef;
                    cVar7 = func_0x(0x11d6690);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x10140b;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar22 + 0x20) = 0;
                      *(undefined8 *)(puVar22 + -8) = 0x101431;
                      (*_DAT_)(1,0xac609c,0xbe6188,0x81d);
                    }
                  }
                }
                uVar16 = *(undefined8 *)(lVar31 + 8);
                *(undefined8 *)(puVar22 + -8) = 0x10143f;
                func_0x(uVar16,4);
                uVar10 = *(uint *)(lVar31 + 0x18);
                uVar30 = (ulonglong)*(ushort *)(lVar31 + 0x1c);
              }
              lVar13 = lVar31;
              plVar35 = plVar34;
              if ((short)uVar30 != 0) {
                do {
                  plVar34 = (longlong *)((longlong)plVar34 + 2);
                  uVar23 = *(ushort *)plVar34 & 0x7fff;
                  if ((uVar23 < uVar10) || (*(uint *)(lVar31 + 4) < uVar23)) {
                    *(undefined8 *)(puVar22 + -8) = 0x10147f;
                    cVar7 = func_0x(0x11d6690);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x101488;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar22 + -8) = 0x1014a2;
                        cVar7 = func_0x(0x11d6690);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar22 + -8) = 0x1014be;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar22 + 0x20) = 0;
                          *(undefined8 *)(puVar22 + -8) = 0x1014e4;
                          (*_DAT_)(1,0xac609c,0xbe6188,0x82a);
                        }
                      }
                    }
                    uVar16 = *(undefined8 *)(lVar31 + 8);
                    *(undefined8 *)(puVar22 + -8) = 0x1014f2;
                    func_0x(uVar16,4);
                  }
                  uVar30 = (ulonglong)*(ushort *)(lVar31 + 0x1c);
                  iVar12 = iVar12 + 1;
                  lVar13 = lStack_120;
                  plVar35 = plStack_e8;
                  uVar10 = uVar23;
                } while (iVar12 < (int)(uint)*(ushort *)(lVar31 + 0x1c));
              }
              if (*(short *)((longlong)plVar35 + (ulonglong)((int)uVar30 - 1) * 2 + 2) < 0) {
                lVar14 = *(longlong *)(lVar31 + 8);
LAB_:
                lVar15 = (ulonglong)*(uint *)(lVar31 + 0x14) + lVar14;
                if ((int)uVar30 == 1) {
                  uVar10 = *(uint *)(lVar31 + 0x18);
                  uVar33 = *(ushort *)(lVar15 + uVar30 * 2) & 0x7fff;
                  uVar23 = uVar10;
LAB_:
                  if ((uVar33 < uVar10) || (*(uint *)(lVar31 + 4) < uVar33)) goto LAB_;
                }
                else {
                  uVar23 = *(uint *)(lVar13 + 0x18);
                  uVar33 = *(ushort *)(lVar15 + uVar30 * 2) & 0x7fff;
                  uVar10 = *(ushort *)(lVar15 + -2 + uVar30 * 2) & 0x7fff;
                  if (uVar23 <= uVar10) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar22 + -8) = 0x101582;
                  func_0x(lVar14,7);
                  uVar23 = *(uint *)(lStack_120 + 0x18);
                }
                if ((uVar10 < uVar23) || (*(uint *)(lVar31 + 4) < uVar10)) goto LAB_;
                lVar14 = *(longlong *)(lVar31 + 8);
                if (*(ushort *)(lVar14 + (ulonglong)uVar10) == 5) {
                  *puVar21 = *puVar21 | 2;
                  *(short *)(lVar31 + 0x1c) = *(short *)(lVar31 + 0x1c) + -1;
                  uVar30 = *(ulonglong *)(lVar31 + 8);
                  uVar8 = *(ushort *)(lVar31 + 0x2c) & 0xc7ff;
                  uVar36 = (ulonglong)(uVar10 & 0xffff);
                  *(short *)(lVar31 + 0x2a) = (short)uVar10;
                  if ((*(ushort *)(uVar36 + 2 + uVar30) >> 0xe & 1) != 0) {
                    uVar8 = *(ushort *)(uVar36 + 2 + uVar30) & 0x3800 | uVar8;
                  }
                  *(ushort *)(lVar31 + 0x2c) = uVar8;
                  uVar26 = (ulonglong)*(ushort *)(lVar31 + 0x2a);
                  uVar9 = (uVar8 ^ *(ushort *)(uVar36 + 2 + uVar30)) & 0x7ff ^ uVar8;
                  *(ushort *)(lVar31 + 0x2c) = uVar9;
                  uVar36 = uVar26 + 4 +
                           (ulonglong)((uVar9 & 0x7ff) * 2) + uVar30 + (uVar8 >> 0xb & 7) * 2;
                  if (uVar36 < uVar26 + uVar30) {
                    *(undefined8 *)(puVar22 + -8) = 0x101694;
                    func_0x(uVar26 + uVar30,0x19);
                    uVar9 = *(ushort *)(lVar31 + 0x2c);
                    uVar26 = (ulonglong)*(ushort *)(lVar31 + 0x2a);
                    uVar30 = (ulonglong)*(uint *)(lVar31 + 8);
                  }
                  if (uVar33 - uVar10 <
                      (((uVar9 & 0x7ff) * 2 - (int)uVar26) - (int)uVar30) + (int)uVar36) {
                    lVar13 = *(longlong *)(lVar31 + 8);
                    *(undefined8 *)(puVar22 + -8) = 0x1016cc;
                    func_0x(uVar26 + lVar13,0x19);
                    uVar9 = *(ushort *)(lVar31 + 0x2c);
                  }
                  iVar12 = 0;
                  if (((uVar9 & 0x3800) != 0) &&
                     (puVar28 = (ushort *)
                                (*(longlong *)(lVar31 + 8) + 4 +
                                (ulonglong)*(ushort *)(lVar31 + 0x2a)), (uVar9 & 0x3800) != 0)) {
                    do {
                      if ((uVar9 & 0x7ff) < (*puVar28 & 0x7ff)) {
                        uVar8 = *(ushort *)(lVar31 + 0x2a);
                        lVar13 = *(longlong *)(lVar31 + 8);
                        *(undefined8 *)(puVar22 + -8) = 0x101727;
                        func_0x((ulonglong)uVar8 + lVar13,0x1a);
                        uVar9 = *(ushort *)(lVar31 + 0x2c);
                      }
                      iVar12 = iVar12 + 1;
                      puVar28 = puVar28 + 1;
                    } while (iVar12 < (int)(uVar9 >> 0xb & 7));
                  }
                  pbVar20 = *(byte **)(lStack_120 + 8);
                  uVar30 = (ulonglong)*(uint *)(lStack_120 + 4);
                  lVar13 = lStack_120;
                  goto LAB_;
                }
                lVar13 = lStack_120;
                if (0x3ff < *(ushort *)(lVar14 + (ulonglong)uVar10)) goto code_r0x001015bc;
              }
LAB_:
              pbVar20 = *(byte **)(lVar13 + 8);
              uVar30 = (ulonglong)*(uint *)(lVar13 + 4);
            }
LAB_:
            if ((*pbVar20 & 0x40) == 0) {
              *(undefined4 *)(lVar31 + 0x26) = 0;
            }
            else {
              *(int *)(lVar31 + 0x26) = (int)uVar30;
              *(int *)(lVar31 + 4) = (int)uVar30 + 0xe;
              *(undefined8 *)(puVar22 + -8) = 0x101771;
              uVar16 = func_0x(puVar21);
              *(undefined8 *)(puVar22 + -8) = 0x101780;
              func_0x(uVar16,auStack_60);
              *(undefined8 *)(puVar22 + -8) = 0x10178c;
              iVar12 = func_0x(auStack_60);
              *(int *)(lVar31 + 4) = *(int *)(lVar31 + 4) + iVar12;
              uVar30 = (ulonglong)*(uint *)(lVar31 + 4);
            }
            iVar12 = (int)uVar30;
            if ((*(ulonglong *)(lVar31 + 0x1e) != 0) &&
               (*(ulonglong *)(lVar31 + 0x1e) < uVar30 + *(longlong *)(lVar31 + 8))) {
              *(undefined8 *)(puVar22 + -8) = 0x1017c2;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x1017cb;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x1017e5;
                  cVar7 = func_0x(0x11d6690);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x101801;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x101827;
                    (*_DAT_)(1,0xac609c,0xbe6188,0x886);
                  }
                }
              }
              uVar16 = *(undefined8 *)(lVar31 + 8);
              *(undefined8 *)(puVar22 + -8) = 0x101835;
              func_0x(uVar16,0x12);
              iVar12 = *(int *)(lVar13 + 4);
            }
            if (0x3f3b < iVar12 - 1U) {
              *(undefined8 *)(puVar22 + -8) = 0x10184e;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x101857;
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x101871;
                  cVar7 = func_0x(0x11d6690);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x10188d;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x1018b3;
                    (*_DAT_)(1,0xac609c,0xbe6188,0x88b);
                  }
                }
              }
              uVar16 = *(undefined8 *)(lVar31 + 8);
              *(undefined8 *)(puVar22 + -8) = 0x1018c1;
              func_0x(uVar16,5);
            }
          }
LAB_:
          *(undefined8 *)(puVar22 + -8) = 0x1018c9;
          iVar12 = func_0x(puVar21);
          if (iVar12 == 0) {
            *(undefined8 *)(puVar22 + -8) = 0x1019d2;
            iVar12 = func_0x(puVar21);
            if (iVar12 == 0) {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x1019ff;
              (*_DAT_)(1,0xc81db8,0xc72e48,0xd7a);
            }
          }
          else if (((longlong)uVar29 < 0) ||
                  ((int)(*(ushort *)(lVar31 + 0x2c) & 0x7ff) <= (int)auStack_128[0])) {
            *(undefined8 *)(puVar22 + 0x20) = 0;
            *(undefined8 *)(puVar22 + -8) = 0x1019c2;
            (*_DAT_)(1,0xc81d88,0xc81d50,0x41a);
          }
          else {
            lVar14 = 0;
            uVar30 = (ulonglong)*(ushort *)(lVar31 + 0x2a);
            lVar13 = *(longlong *)(lVar31 + 8);
            if ((*(ushort *)(lVar31 + 0x2c) & 0x3800) == 0) {
              uVar8 = *(ushort *)(lVar13 + 2 + uVar30);
LAB_:
              uVar27 = uVar8 >> 0xb & 7;
            }
            else {
              uVar9 = *(ushort *)(lVar31 + 0x2c) >> 0xb;
              uVar27 = 0;
              if ((uVar9 & 7) != 0) {
                do {
                  if (lVar14 == 0) {
                    uVar10 = 0;
                  }
                  else {
                    uVar10 = *(ushort *)(lVar13 + uVar30 + 2 + lVar14 * 2) & 0x7ff;
                  }
                  if (((int)uVar10 <= (int)auStack_128[0]) &&
                     (uVar8 = *(ushort *)(lVar13 + uVar30 + 4 + lVar14 * 2),
                     (int)auStack_128[0] <= (int)((uVar8 & 0x7ff) - 1))) goto LAB_;
                  lVar14 = lVar14 + 1;
                } while (lVar14 < (longlong)(ulonglong)(uVar9 & 7));
              }
            }
LAB_:
            auStack_110[0] =
                 (uint)*(ushort *)
                        ((ulonglong)((*(ushort *)(lVar31 + 0x2c) >> 0xb & 7) * 2) + lVar13 +
                         (uVar19 + 1) * 2 + 4 + uVar30) + (uint)uVar27 * 0x10000;
          }
LAB_:
          uVar29 = uVar19 + 1;
          lVar13 = uStack_108;
        }
      }
      else {
        uStack_118 = uVar33 + 1;
        uVar32 = uVar32 + 1;
        auStack_f0[0] = uStack_114;
        if ((longlong)uVar32 < lVar13) {
          uStack_114 = *(uint *)(uVar32 * 0x20 + 0x10 + uStack_f8) & 0x1fffffff;
        }
        auStack_128[0] = uVar23 + 1;
        uVar29 = uVar19 + 1;
        if ((longlong)uVar29 < (longlong)uStack_100) {
          puVar21 = (ushort *)(lStack_120 + 2);
          if (*(int *)(lStack_120 + 4) == 0) {
            pbVar20 = *(byte **)(lStack_120 + 8);
            uVar10 = *(uint *)(lStack_120 + 0x10);
            uVar30 = (ulonglong)uVar10;
            *puVar21 = 0;
            *(uint *)(lStack_120 + 0x14) = uVar10;
            bVar6 = *pbVar20;
            if ((bVar6 & 0x10) != 0) {
              uVar10 = uVar10 + 2 + (*(ushort *)(pbVar20 + uVar30) + 7 >> 3);
              uVar30 = (ulonglong)uVar10;
              *(uint *)(lStack_120 + 0x14) = uVar10;
              bVar6 = *pbVar20;
            }
            if ((bVar6 & 0x20) == 0) {
              *(int *)(lStack_120 + 4) = (int)uVar30;
              *(undefined2 *)(lStack_120 + 0x1c) = 0;
              *(int *)(lStack_120 + 0x18) = (int)uVar30;
              lVar13 = lStack_120;
            }
            else {
              plVar34 = (longlong *)(pbVar20 + uVar30);
              uVar8 = *(ushort *)plVar34;
              *(ushort *)(lStack_120 + 0x1c) = uVar8;
              plStack_e8 = plVar34;
              if (uVar8 == 0) {
                *(undefined8 *)(puVar22 + -8) = 0x101ab1;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 != '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x101aba;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar22 + -8) = 0x101ad4;
                    cVar7 = func_0x(0x11d6690);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x101af0;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(puVar22 + 0x20) = 0;
                      *(undefined8 *)(puVar22 + -8) = 0x101b16;
                      (*_DAT_)(1,0xac609c,0xbe6188,0x80f);
                    }
                  }
                }
                uVar16 = *(undefined8 *)(lVar31 + 8);
                *(undefined8 *)(puVar22 + -8) = 0x101b24;
                func_0x(uVar16,3);
                uVar30 = (ulonglong)*(uint *)(lVar31 + 0x14);
                uVar8 = *(ushort *)(lVar31 + 0x1c);
              }
              uVar10 = (int)uVar30 + (uVar8 + 1) * 2;
              *(uint *)(lVar31 + 0x18) = uVar10;
              if (0x1f9e < uVar10) {
                *(undefined8 *)(puVar22 + -8) = 0x101b54;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 != '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x101b5d;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar22 + -8) = 0x101b77;
                    cVar7 = func_0x(0x11d6690);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x101b93;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar22 + 0x20) = 0;
                      *(undefined8 *)(puVar22 + -8) = 0x101bb9;
                      (*_DAT_)(1,0xac609c,0xbe6188,0x816);
                    }
                  }
                }
                uVar16 = *(undefined8 *)(lVar31 + 8);
                *(undefined8 *)(puVar22 + -8) = 0x101bc7;
                func_0x(uVar16,4);
                uVar8 = *(ushort *)(lVar31 + 0x1c);
                uVar10 = *(uint *)(lVar31 + 0x18);
              }
              uVar30 = (ulonglong)uVar8;
              uVar23 = *(ushort *)((longlong)plVar34 + uVar30 * 2) & 0x7fff;
              *(uint *)(lVar31 + 4) = uVar23;
              if (uVar23 < uVar10) {
                *(undefined8 *)(puVar22 + -8) = 0x101bf7;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 != '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x101c00;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar22 + -8) = 0x101c1a;
                    cVar7 = func_0x(0x11d6690);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x101c36;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar22 + 0x20) = 0;
                      *(undefined8 *)(puVar22 + -8) = 0x101c5c;
                      (*_DAT_)(1,0xac609c,0xbe6188,0x81d);
                    }
                  }
                }
                uVar16 = *(undefined8 *)(lVar31 + 8);
                *(undefined8 *)(puVar22 + -8) = 0x101c6a;
                func_0x(uVar16,4);
                uVar10 = *(uint *)(lVar31 + 0x18);
                uVar30 = (ulonglong)*(ushort *)(lVar31 + 0x1c);
              }
              lVar13 = lVar31;
              plVar35 = plVar34;
              if ((short)uVar30 != 0) {
                do {
                  plVar34 = (longlong *)((longlong)plVar34 + 2);
                  uVar23 = *(ushort *)plVar34 & 0x7fff;
                  if ((uVar23 < uVar10) || (*(uint *)(lVar31 + 4) < uVar23)) {
                    *(undefined8 *)(puVar22 + -8) = 0x101caf;
                    cVar7 = func_0x(0x11d6690);
                    if (cVar7 != '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x101cb8;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar22 + -8) = 0x101cd2;
                        cVar7 = func_0x(0x11d6690);
                        if (cVar7 == '\0') {
                          *(undefined8 *)(puVar22 + -8) = 0x101cee;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar22 + 0x20) = 0;
                          *(undefined8 *)(puVar22 + -8) = 0x101d14;
                          (*_DAT_)(1,0xac609c,0xbe6188,0x82a);
                        }
                      }
                    }
                    uVar16 = *(undefined8 *)(lVar31 + 8);
                    *(undefined8 *)(puVar22 + -8) = 0x101d22;
                    func_0x(uVar16,4);
                  }
                  uVar30 = (ulonglong)*(ushort *)(lVar31 + 0x1c);
                  iVar12 = iVar12 + 1;
                  lVar13 = lStack_120;
                  plVar35 = plStack_e8;
                  uVar10 = uVar23;
                } while (iVar12 < (int)(uint)*(ushort *)(lVar31 + 0x1c));
              }
              if (*(short *)((longlong)plVar35 + (ulonglong)((int)uVar30 - 1) * 2 + 2) < 0) {
                lVar14 = *(longlong *)(lVar31 + 8);
LAB_:
                lVar15 = (ulonglong)*(uint *)(lVar31 + 0x14) + lVar14;
                if ((int)uVar30 == 1) {
                  uVar10 = *(uint *)(lVar31 + 0x18);
                  uVar33 = *(ushort *)(lVar15 + uVar30 * 2) & 0x7fff;
                  uVar23 = uVar10;
LAB_:
                  if ((uVar33 < uVar10) || (*(uint *)(lVar31 + 4) < uVar33)) goto LAB_;
                }
                else {
                  uVar23 = *(uint *)(lVar13 + 0x18);
                  uVar33 = *(ushort *)(lVar15 + uVar30 * 2) & 0x7fff;
                  uVar10 = *(ushort *)(lVar15 + -2 + uVar30 * 2) & 0x7fff;
                  if (uVar23 <= uVar10) goto LAB_;
LAB_:
                  *(undefined8 *)(puVar22 + -8) = 0x101db2;
                  func_0x(lVar14,7);
                  uVar23 = *(uint *)(lStack_120 + 0x18);
                }
                if ((uVar10 < uVar23) || (*(uint *)(lVar31 + 4) < uVar10)) goto LAB_;
                lVar14 = *(longlong *)(lVar31 + 8);
                if (*(ushort *)(lVar14 + (ulonglong)uVar10) == 5) {
                  *puVar21 = *puVar21 | 2;
                  *(short *)(lVar31 + 0x1c) = *(short *)(lVar31 + 0x1c) + -1;
                  uVar30 = *(ulonglong *)(lVar31 + 8);
                  uVar8 = *(ushort *)(lVar31 + 0x2c) & 0xc7ff;
                  uVar36 = (ulonglong)(uVar10 & 0xffff);
                  *(short *)(lVar31 + 0x2a) = (short)uVar10;
                  if ((*(ushort *)(uVar36 + 2 + uVar30) >> 0xe & 1) != 0) {
                    uVar8 = *(ushort *)(uVar36 + 2 + uVar30) & 0x3800 | uVar8;
                  }
                  *(ushort *)(lVar31 + 0x2c) = uVar8;
                  uVar26 = (ulonglong)*(ushort *)(lVar31 + 0x2a);
                  uVar9 = (uVar8 ^ *(ushort *)(uVar36 + 2 + uVar30)) & 0x7ff ^ uVar8;
                  *(ushort *)(lVar31 + 0x2c) = uVar9;
                  uVar36 = uVar30 + 4 +
                           (ulonglong)((uVar9 & 0x7ff) * 2) + uVar26 + (uVar8 >> 0xb & 7) * 2;
                  if (uVar36 < uVar26 + uVar30) {
                    *(undefined8 *)(puVar22 + -8) = 0x101ec4;
                    func_0x(uVar26 + uVar30,0x19);
                    uVar9 = *(ushort *)(lVar31 + 0x2c);
                    uVar26 = (ulonglong)*(ushort *)(lVar31 + 0x2a);
                    uVar30 = (ulonglong)*(uint *)(lVar31 + 8);
                  }
                  if (uVar33 - uVar10 <
                      (((uVar9 & 0x7ff) * 2 - (int)uVar26) - (int)uVar30) + (int)uVar36) {
                    lVar13 = *(longlong *)(lVar31 + 8);
                    *(undefined8 *)(puVar22 + -8) = 0x101efc;
                    func_0x(uVar26 + lVar13,0x19);
                    uVar9 = *(ushort *)(lVar31 + 0x2c);
                  }
                  iVar12 = 0;
                  if (((uVar9 & 0x3800) != 0) &&
                     (puVar28 = (ushort *)
                                (*(longlong *)(lVar31 + 8) + 4 +
                                (ulonglong)*(ushort *)(lVar31 + 0x2a)), (uVar9 & 0x3800) != 0)) {
                    do {
                      if ((uVar9 & 0x7ff) < (*puVar28 & 0x7ff)) {
                        uVar8 = *(ushort *)(lVar31 + 0x2a);
                        lVar13 = *(longlong *)(lVar31 + 8);
                        *(undefined8 *)(puVar22 + -8) = 0x101f57;
                        func_0x((ulonglong)uVar8 + lVar13,0x1a);
                        uVar9 = *(ushort *)(lVar31 + 0x2c);
                      }
                      iVar12 = iVar12 + 1;
                      puVar28 = puVar28 + 1;
                    } while (iVar12 < (int)(uVar9 >> 0xb & 7));
                  }
                  pbVar20 = *(byte **)(lStack_120 + 8);
                  uVar30 = (ulonglong)*(uint *)(lStack_120 + 4);
                  lVar13 = lStack_120;
                  goto LAB_;
                }
                lVar13 = lStack_120;
                if (0x3ff < *(ushort *)(lVar14 + (ulonglong)uVar10)) goto code_r0x00101dec;
              }
LAB_:
              pbVar20 = *(byte **)(lVar13 + 8);
              uVar30 = (ulonglong)*(uint *)(lVar13 + 4);
            }
LAB_:
            if ((*pbVar20 & 0x40) == 0) {
              *(undefined4 *)(lVar31 + 0x26) = 0;
            }
            else {
              *(int *)(lVar31 + 0x26) = (int)uVar30;
              *(int *)(lVar31 + 4) = (int)uVar30 + 0xe;
              *(undefined8 *)(puVar22 + -8) = 0x101fa1;
              uVar16 = func_0x(puVar21);
              *(undefined8 *)(puVar22 + -8) = 0x101fb0;
              func_0x(uVar16,auStack_58);
              *(undefined8 *)(puVar22 + -8) = 0x101fbc;
              iVar12 = func_0x(auStack_58);
              *(int *)(lVar31 + 4) = *(int *)(lVar31 + 4) + iVar12;
              uVar30 = (ulonglong)*(uint *)(lVar31 + 4);
            }
            iVar12 = (int)uVar30;
            if ((*(ulonglong *)(lVar31 + 0x1e) != 0) &&
               (*(ulonglong *)(lVar31 + 0x1e) < uVar30 + *(longlong *)(lVar31 + 8))) {
              *(undefined8 *)(puVar22 + -8) = 0x101ff2;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x101ffb;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x102015;
                  cVar7 = func_0x(0x11d6690);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x102031;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x102057;
                    (*_DAT_)(1,0xac609c,0xbe6188,0x886);
                  }
                }
              }
              uVar16 = *(undefined8 *)(lVar31 + 8);
              *(undefined8 *)(puVar22 + -8) = 0x102065;
              func_0x(uVar16,0x12);
              iVar12 = *(int *)(lVar13 + 4);
            }
            if (0x3f3b < iVar12 - 1U) {
              *(undefined8 *)(puVar22 + -8) = 0x10207e;
              cVar7 = func_0x(0x11d6690);
              if (cVar7 != '\0') {
                *(undefined8 *)(puVar22 + -8) = 0x102087;
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar22 + -8) = 0x1020a1;
                  cVar7 = func_0x(0x11d6690);
                  if (cVar7 == '\0') {
                    *(undefined8 *)(puVar22 + -8) = 0x1020bd;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(puVar22 + 0x20) = 0;
                    *(undefined8 *)(puVar22 + -8) = 0x1020e3;
                    (*_DAT_)(1,0xac609c,0xbe6188,0x88b);
                  }
                }
              }
              uVar16 = *(undefined8 *)(lVar31 + 8);
              *(undefined8 *)(puVar22 + -8) = 0x1020f1;
              func_0x(uVar16,5);
            }
          }
LAB_:
          *(undefined8 *)(puVar22 + -8) = 0x1020f9;
          iVar12 = func_0x(puVar21);
          if (iVar12 == 0) {
            *(undefined8 *)(puVar22 + -8) = 0x1021d5;
            iVar12 = func_0x(puVar21);
            if (iVar12 == 0) {
              *(undefined8 *)(puVar22 + 0x20) = 0;
              *(undefined8 *)(puVar22 + -8) = 0x1021fe;
              (*_DAT_)(1,0xc81db8,0xc72e48,0xd7a);
            }
          }
          else {
            if ((-1 < (longlong)uVar29) &&
               ((int)auStack_128[0] < (int)(*(ushort *)(lVar31 + 0x2c) & 0x7ff))) {
              lVar14 = 0;
              uVar30 = (ulonglong)*(ushort *)(lVar31 + 0x2a);
              lVar13 = *(longlong *)(lVar31 + 8);
              if ((*(ushort *)(lVar31 + 0x2c) & 0x3800) == 0) {
                uVar8 = *(ushort *)(lVar13 + 2 + uVar30);
                goto LAB_;
              }
              uVar9 = *(ushort *)(lVar31 + 0x2c) >> 0xb;
              uVar27 = 0;
              if ((uVar9 & 7) != 0) {
                do {
                  if (lVar14 == 0) {
                    uVar10 = 0;
                  }
                  else {
                    uVar10 = *(ushort *)(lVar13 + uVar30 + 2 + lVar14 * 2) & 0x7ff;
                  }
                  if (((int)uVar10 <= (int)auStack_128[0]) &&
                     (uVar8 = *(ushort *)(lVar13 + uVar30 + 4 + lVar14 * 2),
                     (int)auStack_128[0] <= (int)((uVar8 & 0x7ff) - 1))) goto LAB_;
                  lVar14 = lVar14 + 1;
                  uVar27 = 0;
                } while (lVar14 < (longlong)(ulonglong)(uVar9 & 7));
              }
              goto LAB_;
            }
            *(undefined8 *)(puVar22 + 0x20) = 0;
            *(undefined8 *)(puVar22 + -8) = 0x1021c8;
            (*_DAT_)(1,0xc81d88,0xc81d50,0x41a);
          }
          goto LAB_;
        }
      }
      lVar31 = lStack_d8;
      uVar30 = 0;
      uVar16 = *(undefined8 *)(*(longlong *)(lStack_d8 + 8) + 0x160);
      *(undefined8 *)(puVar22 + -8) = 0x102223;
      func_0x(uVar16,&plStack_b8,auStack_f0);
      lVar31 = *(longlong *)(lVar31 + 8);
      if ((((*(longlong *)(lVar31 + 0x90) == 0) || (DAT_ == '\0')) ||
          (*(longlong *)(*(longlong *)(*(longlong *)(lVar31 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
         (*(uint *)(lVar31 + 0xf4) < 2)) {
        if (*(int *)(lVar31 + 0x480) == 0) {
          *(undefined8 *)(puVar22 + -8) = 0x10226c;
          func_0x();
        }
        plVar34 = plStack_b8;
        if (plStack_b8[1] != 0) {
          lVar14 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar31 = *(longlong *)(lVar14 + 0x100);
          if (lVar31 == 0) {
            *(undefined8 *)(puVar22 + -8) = 0x1022aa;
            (*_DAT_)(0);
            lVar31 = *(longlong *)(lVar14 + 0x100);
          }
          if (*(longlong *)(lVar31 + 0x260) != 0) {
            uVar30 = (ulonglong)*(uint *)(*(longlong *)(lVar31 + 0x260) + 0xe68);
          }
          if ((uint)uVar30 < *(uint *)(_DAT_ + 8)) {
            lVar31 = *(longlong *)(plVar34[1] + uVar30 * 8);
            *(longlong *)(lVar31 + lStack_b0 * 8) = *(longlong *)(lVar31 + lStack_b0 * 8) + 1;
            goto LAB_;
          }
        }
        LOCK();
        plVar34 = (longlong *)(*plStack_b8 + lStack_b0 * 8);
        *plVar34 = *plVar34 + 1;
        UNLOCK();
      }
LAB_:
      uVar30 = (ulonglong)uStack_118;
      uVar19 = uVar29;
      uVar33 = uStack_118;
      uVar23 = auStack_128[0];
    } while ((longlong)uVar32 < lVar13);
  }
  lVar31 = (longlong)(int)uVar33;
  if (lVar31 < lVar13) {
    puVar25 = (uint *)(uStack_f8 + 0x10 + lVar31 * 0x20);
    do {
      lVar14 = lStack_d8;
      uVar16 = *(undefined8 *)(*(longlong *)(lStack_d8 + 8) + 0x160);
      *(undefined8 *)(puVar22 + -8) = 0x10235f;
      func_0x(uVar16,&plStack_a8,&uStack_114);
      lVar14 = *(longlong *)(lVar14 + 8);
      if ((((*(longlong *)(lVar14 + 0x90) == 0) || (DAT_ == '\0')) ||
          (*(longlong *)(*(longlong *)(*(longlong *)(lVar14 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
         (*(uint *)(lVar14 + 0xf4) < 2)) {
        if (*(int *)(lVar14 + 0x480) == 0) {
          *(undefined8 *)(puVar22 + -8) = 0x1023a8;
          func_0x();
        }
        plVar34 = plStack_a8;
        if (plStack_a8[1] != 0) {
          lVar15 = (ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
          lVar14 = *(longlong *)(lVar15 + 0x100);
          if (lVar14 == 0) {
            *(undefined8 *)(puVar22 + -8) = 0x1023ed;
            (*_DAT_)(0);
            lVar14 = *(longlong *)(lVar15 + 0x100);
          }
          if (*(longlong *)(lVar14 + 0x260) == 0) {
            uVar30 = 0;
          }
          else {
            uVar30 = (ulonglong)*(uint *)(*(longlong *)(lVar14 + 0x260) + 0xe68);
          }
          if ((uint)uVar30 < *(uint *)(_DAT_ + 8)) {
            lVar14 = *(longlong *)(plVar34[1] + uVar30 * 8);
            *(longlong *)(lVar14 + lStack_a0 * 8) = *(longlong *)(lVar14 + lStack_a0 * 8) + 1;
            goto LAB_;
          }
        }
        LOCK();
        plVar34 = (longlong *)(*plStack_a8 + lStack_a0 * 8);
        *plVar34 = *plVar34 + 1;
        UNLOCK();
      }
LAB_:
      lVar31 = lVar31 + 1;
      puVar25 = puVar25 + 8;
      if (lVar13 <= lVar31) break;
      uStack_114 = *puVar25 & 0x1fffffff;
    } while( true );
  }
  uVar19 = (ulonglong)(int)auStack_128[0];
  uVar30 = uVar19;
  lVar31 = lStack_120;
  lVar13 = uStack_100;
  if ((longlong)uVar19 < (longlong)uStack_100) {
LAB_:
    lVar14 = lStack_d8;
    uVar32 = 0;
    uVar16 = *(undefined8 *)(*(longlong *)(lStack_d8 + 8) + 0x160);
    *(undefined8 *)(puVar22 + -8) = 0x1024af;
    func_0x(uVar16,&plStack_98,auStack_110);
    lVar14 = *(longlong *)(lVar14 + 8);
    if ((((*(longlong *)(lVar14 + 0x90) == 0) || (DAT_ == '\0')) ||
        (*(longlong *)(*(longlong *)(*(longlong *)(lVar14 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
       (*(uint *)(lVar14 + 0xf4) < 2)) {
      if (*(int *)(lVar14 + 0x480) == 0) {
        *(undefined8 *)(puVar22 + -8) = 0x1024f8;
        func_0x();
      }
      plVar34 = plStack_98;
      if (plStack_98[1] != 0) {
        lVar15 = (ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
        lVar14 = *(longlong *)(lVar15 + 0x100);
        if (lVar14 == 0) {
          *(undefined8 *)(puVar22 + -8) = 0x10253d;
          (*_DAT_)(0);
          lVar14 = *(longlong *)(lVar15 + 0x100);
        }
        if (*(longlong *)(lVar14 + 0x260) != 0) {
          uVar32 = (ulonglong)*(uint *)(*(longlong *)(lVar14 + 0x260) + 0xe68);
        }
        if ((uint)uVar32 < *(uint *)(_DAT_ + 8)) {
          lVar14 = *(longlong *)(plVar34[1] + uVar32 * 8);
          *(longlong *)(lVar14 + lStack_90 * 8) = *(longlong *)(lVar14 + lStack_90 * 8) + 1;
          goto LAB_;
        }
      }
      LOCK();
      plVar34 = (longlong *)(*plStack_98 + lStack_90 * 8);
      *plVar34 = *plVar34 + 1;
      UNLOCK();
    }
LAB_:
    auStack_128[0] = (int)uVar19 + 1;
    uVar30 = uVar30 + 1;
    if ((longlong)uVar30 < lVar13) {
      puVar21 = (ushort *)(lVar31 + 2);
      lVar14 = lVar31;
      if (*(int *)(lVar31 + 4) == 0) {
        pbVar20 = *(byte **)(lVar31 + 8);
        uVar10 = *(uint *)(lVar31 + 0x10);
        uVar19 = (ulonglong)uVar10;
        *puVar21 = 0;
        *(uint *)(lVar31 + 0x14) = uVar10;
        bVar6 = *pbVar20;
        if ((bVar6 & 0x10) != 0) {
          uVar10 = uVar10 + 2 + (*(ushort *)(pbVar20 + uVar19) + 7 >> 3);
          uVar19 = (ulonglong)uVar10;
          *(uint *)(lVar31 + 0x14) = uVar10;
          bVar6 = *pbVar20;
        }
        if ((bVar6 & 0x20) == 0) {
          *(int *)(lVar31 + 4) = (int)uVar19;
          *(undefined2 *)(lVar31 + 0x1c) = 0;
          *(int *)(lVar31 + 0x18) = (int)uVar19;
        }
        else {
          puVar28 = (ushort *)(pbVar20 + uVar19);
          uVar8 = *puVar28;
          *(ushort *)(lVar31 + 0x1c) = uVar8;
          if (uVar8 == 0) {
            *(undefined8 *)(puVar22 + -8) = 0x10261d;
            cVar7 = func_0x(0x11d6690);
            if (cVar7 != '\0') {
              *(undefined8 *)(puVar22 + -8) = 0x102626;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)(puVar22 + -8) = 0x102640;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 == '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x10265c;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(puVar22 + 0x20) = 0;
                  *(undefined8 *)(puVar22 + -8) = 0x102682;
                  (*_DAT_)(1,0xac609c,0xbe6188,0x80f);
                }
              }
            }
            uVar16 = *(undefined8 *)(lVar31 + 8);
            *(undefined8 *)(puVar22 + -8) = 0x102690;
            func_0x(uVar16,3);
            uVar19 = (ulonglong)*(uint *)(lVar31 + 0x14);
            uVar8 = *(ushort *)(lVar31 + 0x1c);
          }
          uVar10 = (int)uVar19 + (uVar8 + 1) * 2;
          *(uint *)(lVar31 + 0x18) = uVar10;
          if (0x1f9e < uVar10) {
            *(undefined8 *)(puVar22 + -8) = 0x1026c0;
            cVar7 = func_0x(0x11d6690);
            if (cVar7 != '\0') {
              *(undefined8 *)(puVar22 + -8) = 0x1026c9;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)(puVar22 + -8) = 0x1026e3;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 == '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x1026ff;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar22 + 0x20) = 0;
                  *(undefined8 *)(puVar22 + -8) = 0x102725;
                  (*_DAT_)(1,0xac609c,0xbe6188,0x816);
                }
              }
            }
            uVar16 = *(undefined8 *)(lVar31 + 8);
            *(undefined8 *)(puVar22 + -8) = 0x102733;
            func_0x(uVar16,4);
            uVar8 = *(ushort *)(lVar31 + 0x1c);
            uVar10 = *(uint *)(lVar31 + 0x18);
          }
          uVar19 = (ulonglong)uVar8;
          uVar8 = puVar28[uVar19];
          *(uint *)(lVar31 + 4) = uVar8 & 0x7fff;
          if ((uVar8 & 0x7fff) < uVar10) {
            *(undefined8 *)(puVar22 + -8) = 0x102763;
            cVar7 = func_0x(0x11d6690);
            if (cVar7 != '\0') {
              *(undefined8 *)(puVar22 + -8) = 0x10276c;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)(puVar22 + -8) = 0x102786;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 == '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x1027a2;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar22 + 0x20) = 0;
                  *(undefined8 *)(puVar22 + -8) = 0x1027c8;
                  (*_DAT_)(1,0xac609c,0xbe6188,0x81d);
                }
              }
            }
            uVar16 = *(undefined8 *)(lVar31 + 8);
            *(undefined8 *)(puVar22 + -8) = 0x1027d6;
            func_0x(uVar16,4);
            uVar10 = *(uint *)(lVar31 + 0x18);
            uVar19 = (ulonglong)*(ushort *)(lVar31 + 0x1c);
          }
          iVar12 = 0;
          puVar4 = puVar28;
          if ((short)uVar19 != 0) {
            do {
              uVar23 = puVar4[1] & 0x7fff;
              if ((uVar23 < uVar10) || (*(uint *)(lVar31 + 4) < uVar23)) {
                *(undefined8 *)(puVar22 + -8) = 0x10281f;
                cVar7 = func_0x(0x11d6690);
                if (cVar7 != '\0') {
                  *(undefined8 *)(puVar22 + -8) = 0x102828;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)(puVar22 + -8) = 0x102842;
                    cVar7 = func_0x(0x11d6690);
                    if (cVar7 == '\0') {
                      *(undefined8 *)(puVar22 + -8) = 0x10285e;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(puVar22 + 0x20) = 0;
                      *(undefined8 *)(puVar22 + -8) = 0x102884;
                      (*_DAT_)(1,0xac609c,0xbe6188,0x82a);
                    }
                  }
                }
                uVar16 = *(undefined8 *)(lVar31 + 8);
                *(undefined8 *)(puVar22 + -8) = 0x102892;
                func_0x(uVar16,4);
              }
              uVar19 = (ulonglong)*(ushort *)(lVar31 + 0x1c);
              iVar12 = iVar12 + 1;
              lVar14 = lStack_120;
              puVar4 = puVar4 + 1;
              uVar10 = uVar23;
            } while (iVar12 < (int)(uint)*(ushort *)(lVar31 + 0x1c));
          }
          if ((short)puVar28[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
            lVar13 = *(longlong *)(lVar31 + 8);
            do {
              lVar15 = (ulonglong)*(uint *)(lVar31 + 0x14) + lVar13;
              uVar10 = *(ushort *)(lVar15 + uVar19 * 2) & 0x7fff;
              if ((int)uVar19 == 1) {
                uVar23 = *(uint *)(lVar31 + 0x18);
                uVar33 = uVar23;
LAB_:
                if ((uVar10 < uVar23) || (*(uint *)(lVar31 + 4) < uVar10)) goto LAB_;
              }
              else {
                uVar33 = *(uint *)(lVar14 + 0x18);
                uVar23 = *(ushort *)(lVar15 + -2 + uVar19 * 2) & 0x7fff;
                if (uVar33 <= uVar23) goto LAB_;
LAB_:
                *(undefined8 *)(puVar22 + -8) = 0x102919;
                func_0x(lVar13,7);
                uVar33 = *(uint *)(lVar14 + 0x18);
              }
              if ((uVar23 < uVar33) || (*(uint *)(lVar31 + 4) < uVar23)) goto LAB_;
              lVar13 = *(longlong *)(lVar31 + 8);
              if (*(ushort *)(lVar13 + (ulonglong)uVar23) == 5) {
                *puVar21 = *puVar21 | 2;
                *(short *)(lVar31 + 0x1c) = *(short *)(lVar31 + 0x1c) + -1;
                uVar32 = *(ulonglong *)(lVar31 + 8);
                uVar29 = (ulonglong)(uVar23 & 0xffff);
                uVar8 = *(ushort *)(lVar31 + 0x2c) & 0xc7ff;
                uVar19 = uVar29 + uVar32;
                *(short *)(lVar31 + 0x2a) = (short)uVar23;
                if ((*(ushort *)(uVar19 + 2) >> 0xe & 1) != 0) {
                  uVar8 = *(ushort *)(uVar19 + 2) & 0x3800 | uVar8;
                }
                *(ushort *)(lVar31 + 0x2c) = uVar8;
                uVar9 = (uVar8 ^ *(ushort *)(uVar19 + 2)) & 0x7ff ^ uVar8;
                *(ushort *)(lVar31 + 0x2c) = uVar9;
                uVar36 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar32 + (uVar8 >> 0xb & 7) * 2 +
                         uVar29;
                if (uVar36 < uVar19) {
                  *(undefined8 *)(puVar22 + -8) = 0x102a22;
                  func_0x(uVar19,0x19);
                  uVar9 = *(ushort *)(lVar31 + 0x2c);
                  uVar29 = (ulonglong)*(ushort *)(lVar31 + 0x2a);
                  uVar32 = (ulonglong)*(uint *)(lVar31 + 8);
                }
                if (uVar10 - uVar23 <
                    (((uVar9 & 0x7ff) * 2 - (int)uVar29) - (int)uVar32) + (int)uVar36) {
                  lVar13 = *(longlong *)(lVar31 + 8);
                  *(undefined8 *)(puVar22 + -8) = 0x102a5d;
                  func_0x(uVar29 + lVar13,0x19);
                  uVar9 = *(ushort *)(lVar31 + 0x2c);
                }
                iVar12 = 0;
                if (((uVar9 & 0x3800) != 0) &&
                   (puVar28 = (ushort *)
                              (*(longlong *)(lVar31 + 8) + 4 + (ulonglong)*(ushort *)(lVar31 + 0x2a)
                              ), (uVar9 & 0x3800) != 0)) goto LAB_;
                break;
              }
              if (*(ushort *)(lVar13 + (ulonglong)uVar23) < 0x400) break;
              *puVar21 = *puVar21 | 1;
              uVar8 = *(short *)(lVar31 + 0x1c) - 1;
              *(ushort *)(lVar31 + 0x1c) = uVar8;
              if ((uVar8 == 0) ||
                 (uVar19 = (ulonglong)uVar8, -1 < (short)puVar28[(ulonglong)(uVar8 - 1) + 1]))
              break;
            } while( true );
          }
          pbVar20 = *(byte **)(lVar14 + 8);
          uVar19 = (ulonglong)*(uint *)(lVar14 + 4);
        }
        goto LAB_;
      }
      goto LAB_;
    }
  }
  uVar30 = uStack_48 ^ (ulonglong)auStack_128;
  *(undefined8 *)(puVar22 + -8) = 0x102dc5;
  func_0x(uVar30);
  return;
code_r0x00100d4b:
  sVar2 = *(short *)(lVar13 + 0x1c);
  *puVar21 = *puVar21 | 1;
  uVar8 = sVar2 - 1;
  *(ushort *)(lVar13 + 0x1c) = uVar8;
  if ((uVar8 == 0) || (uVar30 = (ulonglong)uVar8, -1 < (short)puVar28[(ulonglong)(uVar8 - 1) + 1]))
  goto LAB_;
  goto LAB_;
code_r0x00101dec:
  sVar2 = *(short *)(lVar31 + 0x1c);
  *puVar21 = *puVar21 | 1;
  uVar8 = sVar2 - 1;
  *(ushort *)(lVar31 + 0x1c) = uVar8;
  if ((uVar8 == 0) ||
     (uVar30 = (ulonglong)uVar8, -1 < *(short *)((longlong)plVar35 + (ulonglong)(uVar8 - 1) * 2 + 2)
     )) goto LAB_;
  goto LAB_;
code_r0x001015bc:
  sVar2 = *(short *)(lVar31 + 0x1c);
  *puVar21 = *puVar21 | 1;
  uVar8 = sVar2 - 1;
  *(ushort *)(lVar31 + 0x1c) = uVar8;
  if ((uVar8 == 0) ||
     (uVar30 = (ulonglong)uVar8, -1 < *(short *)((longlong)plVar35 + (ulonglong)(uVar8 - 1) * 2 + 2)
     )) goto LAB_;
  goto LAB_;
LAB_:
  do {
    if ((uVar9 & 0x7ff) < (*puVar28 & 0x7ff)) {
      uVar8 = *(ushort *)(lVar31 + 0x2a);
      lVar13 = *(longlong *)(lVar31 + 8);
      *(undefined8 *)(puVar22 + -8) = 0x102ac6;
      func_0x((ulonglong)uVar8 + lVar13,0x1a);
      uVar9 = *(ushort *)(lVar31 + 0x2c);
    }
    iVar12 = iVar12 + 1;
    puVar28 = puVar28 + 1;
  } while (iVar12 < (int)(uVar9 >> 0xb & 7));
  pbVar20 = *(byte **)(lVar14 + 8);
  uVar19 = (ulonglong)*(uint *)(lVar14 + 4);
LAB_:
  if ((*pbVar20 & 0x40) == 0) {
    *(undefined4 *)(lVar31 + 0x26) = 0;
  }
  else {
    *(int *)(lVar31 + 0x26) = (int)uVar19;
    *(int *)(lVar31 + 4) = (int)uVar19 + 0xe;
    *(undefined8 *)(puVar22 + -8) = 0x102b12;
    puVar18 = (undefined8 *)func_0x(puVar21);
    uStack_50 = *puVar18;
    *(undefined8 *)(puVar22 + -8) = 0x102b28;
    iVar12 = func_0x(&uStack_50);
    *(int *)(lVar31 + 4) = *(int *)(lVar31 + 4) + iVar12;
    uVar19 = (ulonglong)*(uint *)(lVar31 + 4);
  }
  iVar12 = (int)uVar19;
  if ((*(ulonglong *)(lVar31 + 0x1e) != 0) &&
     (*(ulonglong *)(lVar31 + 0x1e) < uVar19 + *(longlong *)(lVar31 + 8))) {
    *(undefined8 *)(puVar22 + -8) = 0x102b5e;
    cVar7 = func_0x(0x11d6690);
    if (cVar7 != '\0') {
      *(undefined8 *)(puVar22 + -8) = 0x102b67;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)(puVar22 + -8) = 0x102b81;
        cVar7 = func_0x(0x11d6690);
        if (cVar7 == '\0') {
          *(undefined8 *)(puVar22 + -8) = 0x102b9d;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(puVar22 + 0x20) = 0;
          *(undefined8 *)(puVar22 + -8) = 0x102bc3;
          (*_DAT_)(1,0xac609c,0xbe6188,0x886);
        }
      }
    }
    uVar16 = *(undefined8 *)(lVar31 + 8);
    *(undefined8 *)(puVar22 + -8) = 0x102bd1;
    func_0x(uVar16,0x12);
    iVar12 = *(int *)(lVar14 + 4);
  }
  if (0x3f3b < iVar12 - 1U) {
    *(undefined8 *)(puVar22 + -8) = 0x102beb;
    cVar7 = func_0x(0x11d6690);
    if (cVar7 != '\0') {
      *(undefined8 *)(puVar22 + -8) = 0x102bf4;
      lVar13 = func_0x();
      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
        *(undefined8 *)(puVar22 + -8) = 0x102c0e;
        cVar7 = func_0x(0x11d6690);
        if (cVar7 == '\0') {
          *(undefined8 *)(puVar22 + -8) = 0x102c2a;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(puVar22 + 0x20) = 0;
          *(undefined8 *)(puVar22 + -8) = 0x102c50;
          (*_DAT_)(1,0xac609c,0xbe6188,0x88b);
        }
      }
    }
    uVar16 = *(undefined8 *)(lVar31 + 8);
    *(undefined8 *)(puVar22 + -8) = 0x102c5e;
    func_0x(uVar16,5);
  }
LAB_:
  *(undefined8 *)(puVar22 + -8) = 0x102c66;
  iVar12 = func_0x(puVar21);
  if (iVar12 == 0) {
    *(undefined8 *)(puVar22 + -8) = 0x102d79;
    iVar12 = func_0x(puVar21);
    lVar13 = uStack_100;
    uVar19 = (ulonglong)auStack_128[0];
    lVar31 = lVar14;
    if (iVar12 == 0) {
      *(undefined8 *)(puVar22 + 0x20) = 0;
      *(undefined8 *)(puVar22 + -8) = 0x102db1;
      (*_DAT_)(1,0xc81db8,0xc72e48,0xd7a);
    }
  }
  else {
    uVar19 = (ulonglong)auStack_128[0];
    if (((longlong)uVar30 < 0) || ((int)(*(ushort *)(lVar31 + 0x2c) & 0x7ff) <= (int)auStack_128[0])
       ) {
      *(undefined8 *)(puVar22 + 0x20) = 0;
      *(undefined8 *)(puVar22 + -8) = 0x102d65;
      (*_DAT_)(1,0xc81d88,0xc81d50,0x41a);
      lVar31 = lVar14;
      lVar13 = uStack_100;
    }
    else {
      lVar15 = 0;
      uVar8 = 0;
      uVar32 = (ulonglong)*(ushort *)(lVar31 + 0x2a);
      lVar13 = *(longlong *)(lVar31 + 8);
      if ((*(ushort *)(lVar31 + 0x2c) & 0x3800) == 0) {
        uVar27 = *(ushort *)(lVar13 + 2 + uVar32);
LAB_:
        uVar8 = uVar27 >> 0xb & 7;
      }
      else {
        uVar9 = *(ushort *)(lVar31 + 0x2c) >> 0xb;
        if ((uVar9 & 7) != 0) {
          do {
            if (lVar15 == 0) {
              uVar10 = 0;
            }
            else {
              uVar10 = *(ushort *)(lVar13 + uVar32 + 2 + lVar15 * 2) & 0x7ff;
            }
            if (((int)uVar10 <= (int)auStack_128[0]) &&
               (uVar27 = *(ushort *)(lVar13 + uVar32 + 4 + lVar15 * 2),
               (int)auStack_128[0] <= (int)((uVar27 & 0x7ff) - 1))) goto LAB_;
            lVar15 = lVar15 + 1;
          } while (lVar15 < (longlong)(ulonglong)(uVar9 & 7));
        }
      }
      auStack_110[0] =
           (uint)*(ushort *)
                  ((ulonglong)((*(ushort *)(lVar31 + 0x2c) >> 0xb & 7) * 2) + lVar13 + uVar30 * 2 +
                   4 + uVar32) + (uint)uVar8 * 0x10000;
      lVar31 = lVar14;
      lVar13 = uStack_100;
    }
  }
  goto LAB_;
}

