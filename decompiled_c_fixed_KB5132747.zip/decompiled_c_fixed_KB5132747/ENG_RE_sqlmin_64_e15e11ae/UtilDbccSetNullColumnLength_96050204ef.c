
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint *param_2,uint param_3,ulonglong param_4,short param_5)

{
  byte *pbVar1;
  ushort *puVar2;
  undefined2 uVar3;
  ushort uVar4;
  short sVar5;
  undefined8 uVar6;
  longlong *plVar7;
  uint **ppuVar8;
  char cVar9;
  undefined4 uVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  longlong lVar15;
  longlong lVar16;
  longlong lVar17;
  longlong lVar18;
  uint *puVar19;
  short *psVar20;
  code *UNRECOVERED_JUMPTABLE_00;
  undefined8 unaff_RBX;
  byte **ppbVar21;
  longlong lVar22;
  ulonglong uVar23;
  longlong unaff_GS_OFFSET;
  undefined4 auStackX_8 [8];
  undefined auStack_2558 [8];
  undefined2 uStack_2550;
  undefined4 uStack_254c;
  undefined8 uStack_2548;
  undefined8 uStack_2540;
  undefined8 uStack_2532;
  undefined8 uStack_2528;
  longlong *plStack_2518;
  undefined uStack_2510;
  uint uStack_250c;
  uint uStack_2508;
  uint uStack_2500;
  uint uStack_24fc;
  short sStack_24f8;
  undefined4 uStack_24f4;
  uint auStack_24f0 [2];
  undefined4 uStack_24e8;
  undefined2 uStack_24e4;
  undefined8 uStack_24e0;
  undefined4 uStack_24d8;
  uint uStack_24d4;
  undefined8 uStack_24c8;
  ushort uStack_24c0;
  longlong *plStack_24b8;
  undefined8 uStack_24b0;
  ushort uStack_24a8;
  undefined auStack_24a0 [4];
  undefined4 uStack_249c;
  undefined2 uStack_2498;
  undefined4 uStack_2494;
  undefined2 uStack_2490;
  undefined4 uStack_248c;
  undefined2 uStack_2488;
  undefined8 uStack_2480;
  undefined2 uStack_2478;
  undefined8 uStack_2470;
  undefined2 uStack_2468;
  longlong lStack_2460;
  undefined8 uStack_2458;
  undefined2 uStack_2450;
  undefined8 uStack_2448;
  ushort uStack_2440;
  longlong lStack_2438;
  undefined auStack_2430 [4];
  undefined auStack_242c [4];
  undefined auStack_2428 [8];
  uint uStack_2420;
  undefined8 uStack_241c;
  undefined8 auStack_2408 [2];
  undefined8 uStack_23f8;
  longlong lStack_23f0;
  ulonglong uStack_23e8;
  undefined4 uStack_23e0;
  undefined4 uStack_23d0;
  undefined uStack_23c8;
  undefined4 uStack_23c0;
  undefined auStack_23b8 [16];
  undefined8 uStack_23a8;
  undefined auStack_2398 [8];
  undefined4 uStack_2390;
  undefined4 uStack_2388;
  uint **ppuStack_2380;
  undefined *puStack_2378;
  undefined8 uStack_2370;
  uint *puStack_2368;
  undefined4 uStack_2360;
  undefined4 uStack_235c;
  longlong lStack_2358;
  undefined4 uStack_2350;
  undefined4 uStack_234c;
  longlong lStack_2348;
  undefined4 uStack_2340;
  undefined4 uStack_233c;
  short *psStack_2338;
  int iStack_2330;
  undefined4 uStack_232c;
  short *psStack_2328;
  int iStack_2320;
  undefined4 uStack_231c;
  undefined8 uStack_2318;
  undefined4 uStack_2310;
  undefined4 uStack_230c;
  undefined auStack_2308 [448];
  undefined8 uStack_2148;
  undefined8 uStack_2140;
  uint uStack_2138;
  short sStack_2134;
  uint uStack_2132;
  undefined uStack_212e;
  undefined uStack_212d;
  short sStack_20f8;
  undefined4 uStack_20f4;
  byte *pbStack_20f0;
  byte **ppbStack_20e8;
  undefined8 uStack_20da;
  undefined2 uStack_20d2;
  undefined2 uStack_20d0;
  undefined6 uStack_20ce;
  uint uStack_20c4;
  undefined auStack_20c0 [16];
  undefined auStack_20b0 [8];
  undefined8 uStack_20a8;
  undefined8 uStack_20a0;
  undefined6 uStack_2098;
  undefined2 uStack_2092;
  undefined6 uStack_2090;
  undefined2 uStack_208a;
  undefined8 uStack_2088;
  undefined auStack_2080 [16];
  undefined auStack_2070 [16];
  undefined auStack_2060 [16];
  undefined8 uStack_2050;
  short asStack_2048 [24];
  short asStack_2018 [4072];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  uStack_24d4 = param_3;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  uStack_23a8 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000025d0 + lVar15) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15);
  auStack_2558[0] = 5;
  lVar18 = 0;
  plStack_2518 = (longlong *)0x0;
  uStack_2510 = 0;
  uStack_250c = 0;
  plStack_24b8 = (longlong *)0x0;
  uStack_23f8 = 0xaba5b0;
  uStack_23e8 = 0;
  uStack_23e0 = 0;
  uStack_23d0 = 0xffffffff;
  uStack_23c0 = 0x80000000;
  uStack_23c8 = 0;
  *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1000e7;
  lStack_2460 = param_1;
  func_0x(auStack_23b8,(int)param_5,param_4 & 0xffff,0);
  uVar3 = *(undefined2 *)((longlong)param_2 + 2);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1000f0;
  lVar16 = func_0x(uVar3);
  uVar13 = *param_2;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1000fd;
  lVar17 = func_0x(uVar13 >> 0x10);
  uVar13 = param_2[1];
  uVar4 = *(ushort *)(param_2 + 2);
  if (((uVar4 == 0) || (lVar17 == 0)) || (*(ushort *)(*(longlong *)(lVar17 + 0x6a0) + 0x74) < uVar4)
     ) {
LAB_:
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100151;
    (*_DAT_)(0x19,0,0x19,0);
  }
  else {
    uVar6 = *(undefined8 *)(lVar17 + 0x6a0);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100131;
    lVar17 = func_0x(uVar6,uVar4,1);
    if ((lVar17 == 0) || (*(uint *)(lVar17 + 0x80) <= uVar13)) goto LAB_;
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10016a;
  func_0x(&plStack_24b8,0xb606b0,0x1a,lVar16);
  uVar6 = *(undefined8 *)(lVar16 + 0x30);
  UNRECOVERED_JUMPTABLE_00 = *(code **)(*plStack_24b8 + 0x118);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10017b;
  lVar17 = (*UNRECOVERED_JUMPTABLE_00)(plStack_24b8,uVar6);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10018a;
  lStack_2438 = lVar17;
  uVar10 = func_0x();
  *(undefined4 *)((longlong)auStackX_8 + lVar15 + 0x18) = 0;
  *(undefined4 *)((longlong)auStackX_8 + lVar15 + 0x10) = 0;
  *(undefined4 *)((longlong)auStackX_8 + lVar15 + 8) = 1;
  *(undefined4 *)((longlong)auStackX_8 + lVar15) = uVar10;
  *(undefined4 *)((longlong)auStackX_8 + lVar15 + -8) = 1;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar15) = 0;
  *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
  *(undefined8 **)(&stack0xffffffffffffffe8 + lVar15) = auStack_2408;
  uVar6 = *(undefined8 *)(param_1 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001cf;
  func_0x(lVar16,uVar6,&uStack_23f8,auStack_2558);
  (&stack0xffffffffffffffe8)[lVar15] = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001eb;
  func_0x(lVar16,auStack_2408[0],auStack_2558[0],0);
  uStack_24fc = param_2[1];
  sStack_24f8 = *(short *)(param_2 + 2);
  lVar16 = *(longlong *)(lVar17 + 0x30);
  uStack_241c = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar17 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar17 != 0) && (lVar17 = **(longlong **)(lVar17 + 0x38), lVar17 != 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100257;
      iVar11 = (*_DAT_)(lVar17,0x337);
      if (iVar11 != 0) goto LAB_;
    }
    lVar17 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    lVar18 = 0;
    if (lVar17 != 0) {
      lVar18 = *(longlong *)(lVar17 + 0x60);
    }
  }
LAB_:
  lVar17 = *(longlong *)(lVar16 + 0x728);
  do {
    plVar7 = plStack_2518;
    uStack_2500 = 0;
    if (plStack_2518 != (longlong *)0x0) {
      iVar11 = (int)(short)uStack_250c;
      if (((*(ushort *)((longlong)plStack_2518 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_2518 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_2518 + 100) & 8) != 0) &&
              (lVar22 = plStack_2518[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0)) {
            uVar6 = *(undefined8 *)(lVar22 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100333;
            func_0x(uVar6,plStack_2518,iVar11);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar7 + 100) & 8) != 0)) &&
           ((2 < iVar11 &&
            (((*(uint *)((longlong)plVar7 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar22 = *plVar7, lVar22 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100378;
          iVar14 = (*_DAT_)(lVar22,0x2000,2,auStack_2430);
          if (iVar14 != 0) {
            LOCK();
            *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10039a;
        func_0x(plVar7 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003b9;
          func_0x(plVar7,0,iVar11);
        }
        uStack_250c = uStack_250c & 0xffff0000;
        plStack_2518 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1002d2;
        func_0x(&plStack_2518);
      }
    }
    if (*(longlong *)(lVar16 + 0x728) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003eb;
      func_0x(&plStack_2518,&uStack_24fc,lVar16);
      plVar7 = plStack_2518;
      if (plStack_2518 != (longlong *)0x0) {
        iVar11 = (int)(short)uStack_250c;
        if (((*(ushort *)((longlong)plStack_2518 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
          if (((byte)*(undefined2 *)((longlong)plStack_2518 + 0x62) >> 3 & 1) != 0) {
            if (iVar11 == 3) {
              iVar11 = 4;
            }
            else if (iVar11 < 2) goto LAB_;
            if ((((*(uint *)((longlong)plStack_2518 + 100) & 8) != 0) &&
                (lVar22 = plStack_2518[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0))
            {
              uVar6 = *(undefined8 *)(lVar22 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100474;
              func_0x(uVar6,plStack_2518,iVar11);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar7 + 100) & 8) != 0)) &&
             ((2 < iVar11 &&
              (((*(uint *)((longlong)plVar7 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar22 = *plVar7, lVar22 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1004b5;
            iVar14 = (*_DAT_)(lVar22,0x2000,2,auStack_242c);
            if (iVar14 != 0) {
              LOCK();
              *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1004d7;
          func_0x(plVar7 + 0x13,iVar11);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1004f6;
            func_0x(plVar7,0,iVar11);
          }
          uStack_250c = uStack_250c & 0xffff0000;
          plStack_2518 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100413;
          func_0x(&plStack_2518);
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100511;
    func_0x(lVar16,&uStack_24fc);
    *(uint **)(&stack0xfffffffffffffff0 + lVar15) = &uStack_2420;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 4;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100539;
    plStack_2518 = (longlong *)
                   func_0x(_DAT_,lVar16,&uStack_24fc,&uStack_2500);
    if (lVar18 != 0) {
      uVar23 = (ulonglong)(*(uint *)(lVar18 + 0x500) & 0xf);
      if (*(longlong *)(lVar18 + 0x508 + uVar23 * 8) != *plStack_2518) {
        *(longlong *)(lVar18 + 0x508 + uVar23 * 8) = *plStack_2518;
        *(longlong *)(lVar18 + 0x500) = *(longlong *)(lVar18 + 0x500) + 1;
      }
    }
    uStack_250c = (uStack_2500 >> 3 & 1) << 0x18 | uStack_250c & 0xff0004 | 4;
    uStack_2508 = uStack_2500 >> 4 & 1 | uStack_2508 & 0xffffff00;
    if (((lVar17 != 0) && (lVar18 != 0)) && (lVar18 == *(longlong *)(lVar16 + 0x1c38))) {
      *(longlong *)(lVar17 + 0x5b28) = *(longlong *)(lVar17 + 0x5b28) + 1;
      if ((int)uStack_241c != 0) {
        *(longlong *)(lVar17 + 0x5b30) = *(longlong *)(lVar17 + 0x5b30) + 1;
        *(longlong *)(lVar17 + 0x5b38) = *(longlong *)(lVar17 + 0x5b38) + (ulonglong)uStack_2420;
        if (0xffffff < uStack_250c) {
          *(longlong *)(lVar17 + 0x5b40) = *(longlong *)(lVar17 + 0x5b40) + 1;
          *(longlong *)(lVar17 + 0x5b48) = *(longlong *)(lVar17 + 0x5b48) + (ulonglong)uStack_2420;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100607;
    cVar9 = func_0x(lVar16);
    uStack_24f4 = 9;
    if (((cVar9 == '\0') || (*(char *)(lVar16 + 0x2050) == '\0')) ||
       ((uStack_24fc == 0 || ((uStack_24fc == 9 && (sStack_24f8 == 1)))))) goto LAB_;
    lVar22 = *plStack_2518;
    if (*(short *)(lVar22 + 0x24) == 0) {
LAB_:
      uStack_24b0 = *(undefined8 *)(lVar22 + 0x28);
      uStack_24a8 = *(ushort *)(lVar22 + 0x30);
    }
    else {
      cVar9 = *(char *)(lVar22 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(lVar22 + 0x18) != 99) {
LAB_:
          if (cVar9 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar9 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar22 + 0x18) != 99) goto LAB_;
      }
      uStack_249c = *(undefined4 *)(lVar22 + 0x20);
      uStack_2498 = *(undefined2 *)(lVar22 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100688;
      cVar9 = func_0x(&uStack_249c);
      if (cVar9 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100698;
      func_0x(lVar22,&uStack_24b0);
    }
    uVar13 = *(uint *)(lVar16 + 0x2108);
    do {
      uVar12 = uVar13 & 0xfffffffe;
      uStack_24e0 = *(undefined8 *)(lVar16 + 0x20fc);
      uStack_24d8 = *(undefined4 *)(lVar16 + 0x2104);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
      UNLOCK();
      uVar13 = *(uint *)(lVar16 + 0x2108);
    } while (uVar12 != uVar13);
    if ((uint)uStack_24b0 <= (uint)uStack_24e0) {
      if ((uint)uStack_24e0 != (uint)uStack_24b0) goto LAB_;
      uVar13 = (uint)((ulonglong)uStack_24e0 >> 0x20);
      if ((uStack_24b0._4_4_ <= uVar13) &&
         ((uVar13 != uStack_24b0._4_4_ || (uStack_24a8 <= (ushort)uStack_24d8)))) goto LAB_;
    }
    if ((*(char *)(lVar16 + 0x6ac8) == '\0') &&
       (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) != *(longlong *)(lVar16 + 0x2120))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10074e;
      cVar9 = func_0x(lVar16);
      if (cVar9 == '\0') {
        uVar13 = *(uint *)(lVar16 + 0x2108);
        do {
          uVar12 = uVar13 & 0xfffffffe;
          uStack_24e0 = *(undefined8 *)(lVar16 + 0x20fc);
          uStack_24d8 = *(undefined4 *)(lVar16 + 0x2104);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
          UNLOCK();
          uVar13 = *(uint *)(lVar16 + 0x2108);
        } while (uVar12 != uVar13);
        uVar4 = (ushort)uStack_24d8;
        uStack_2440 = (ushort)uStack_24d8;
        lVar18 = *plStack_2518;
        uStack_2448 = uStack_24e0;
        if (*(short *)(lVar18 + 0x24) == 0) {
LAB_:
          uStack_24c8 = *(undefined8 *)(lVar18 + 0x28);
          uStack_24c0 = *(ushort *)(lVar18 + 0x30);
        }
        else {
          cVar9 = *(char *)(lVar18 + 1);
          if (cVar9 == '\v') {
            if (*(int *)(lVar18 + 0x18) != 99) {
LAB_:
              if (cVar9 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar9 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar18 + 0x18) != 99) goto LAB_;
          }
          uStack_248c = *(undefined4 *)(lVar18 + 0x20);
          uStack_2488 = *(undefined2 *)(lVar18 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a0d;
          cVar9 = func_0x(&uStack_248c);
          if (cVar9 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a1d;
          func_0x(lVar18,&uStack_24c8);
        }
        if ((uint)uStack_24e0 < (uint)uStack_24c8) {
LAB_:
          lVar18 = *(longlong *)(lVar16 + 0x6b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a7f;
          func_0x(&uStack_24c8,asStack_2048,auStack_24a0);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100a96;
          func_0x(&uStack_2448,asStack_2018,auStack_24a0);
          if ((_DAT_ & 0x10000) != 0) {
            uStack_2390 = 0x60000;
            iVar11 = 0;
            uStack_2388 = 0;
            ppuStack_2380 = &puStack_2368;
            puStack_2378 = auStack_2308;
            uStack_2148 = 0;
            uStack_2370 = 0;
            uStack_2140 = 0;
            puStack_2368 = &uStack_2138;
            uStack_2360 = 0x34;
            uStack_235c = 5;
            uStack_2350 = 0x10;
            uStack_234c = 5;
            uStack_2340 = 0x10;
            uStack_233c = 6;
            uStack_232c = 7;
            uStack_231c = 8;
            uStack_2318 = 0;
            uStack_2310 = 0;
            uStack_230c = 9;
            uStack_2138 = (uint)*(ushort *)(lVar16 + 0x6b8);
            sStack_2134 = sStack_24f8;
            uStack_2132 = uStack_24fc;
            uStack_212e = 0xff;
            uStack_212d = *(undefined *)(*plStack_2518 + 1);
            lStack_2358 = lVar18 + 0x254;
            lStack_2348 = lVar18 + 0x244;
            lVar16 = -1;
            do {
              lVar16 = lVar16 + 1;
            } while (asStack_2048[lVar16] != 0);
            iStack_2330 = (int)lVar16 * 2;
            psStack_2338 = asStack_2048;
            lVar16 = -1;
            do {
              lVar16 = lVar16 + 1;
            } while (asStack_2018[lVar16] != 0);
            iStack_2320 = (int)lVar16 * 2;
            psStack_2328 = asStack_2018;
            auStack_24f0[0] = 0;
            UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c55;
            puVar19 = (uint *)(*UNRECOVERED_JUMPTABLE_00)(lVar18,auStack_24f0);
            ppuVar8 = ppuStack_2380;
            if (puVar19 != (uint *)0x0) {
              lVar18 = -1;
              do {
                lVar18 = lVar18 + 1;
              } while (*(short *)((longlong)puVar19 + lVar18 * 2) != 0);
              iVar11 = (int)lVar18 * 2;
            }
            ppuStack_2380[10] = puVar19;
            *(int *)(ppuVar8 + 0xb) = iVar11;
            *(undefined4 *)((longlong)ppuVar8 + 0x5c) = 9;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c8e;
            func_0x(auStack_2398);
          }
        }
        else if ((uint)uStack_24e0 == (uint)uStack_24c8) {
          uVar13 = (uint)((ulonglong)uStack_24c8 >> 0x20);
          if ((uStack_24e0._4_4_ < uVar13) ||
             ((uStack_24e0._4_4_ == uVar13 && (uVar4 < uStack_24c0)))) goto LAB_;
        }
LAB_:
        plVar7 = plStack_24b8;
        uVar13 = uStack_24d4;
        lVar18 = *plStack_2518;
        if ((*(ushort *)(lVar18 + 0x16) <= uStack_24d4) ||
           (puVar2 = (ushort *)(lVar18 + (0xfff - (longlong)(int)uStack_24d4) * 2), *puVar2 == 0)) {
          puVar19 = (uint *)0x4;
          UNRECOVERED_JUMPTABLE_00 = *(code **)(*plStack_24b8 + 0x1b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102dbf;
          (*UNRECOVERED_JUMPTABLE_00)(plStack_24b8);
          UNRECOVERED_JUMPTABLE_00 = *(code **)*plVar7;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102dce;
          (*UNRECOVERED_JUMPTABLE_00)(plVar7,1);
          plStack_24b8 = (longlong *)0x0;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102dd7;
          lVar18 = func_0x();
          if (lVar18 != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102de1;
            lVar18 = func_0x();
            if (*(longlong *)(lVar18 + 0x30) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102ded;
              lVar18 = func_0x();
              uVar13 = *(uint *)(*(longlong *)(lVar18 + 0x30) + 0xc);
              if ((uVar13 < 0xe) && ((0x2640U >> (uVar13 & 0x1f) & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e08;
                lVar18 = func_0x();
                if ((*(longlong *)(lVar18 + 0xa0) != 0) &&
                   (*(longlong *)(*(longlong *)(lVar18 + 0xa0) + 8) != 0)) goto LAB_;
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e20;
          lVar18 = func_0x();
          if (lVar18 != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e2a;
            lVar18 = func_0x();
            puVar19 = (uint *)(lVar18 + 0x10);
          }
          *puVar19 = *puVar19 | 2;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e49;
          (*_DAT_)(0x59,0x43,0x10,0x9f);
LAB_:
          uStack_23f8 = 0xaba5b0;
          if ((int)uStack_23e8 == 3) {
            uStack_23e8 = uStack_23e8 & 0xffffffff00000000;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e7d;
            func_0x(lStack_23f0 + 0x530,1);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e87;
          func_0x(&plStack_2518);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102e96;
          func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15));
          return;
        }
        uStack_2550 = 0xffff;
        uStack_2548 = 0;
        uStack_254c = 0;
        uStack_2532 = 0;
        uStack_2528 = 0;
        uStack_2540 = 0;
        sStack_20f8 = -1;
        pbStack_20f0 = (byte *)0x0;
        uStack_20f4 = 0;
        uStack_20da = 0;
        uStack_20d0 = 0;
        uStack_20ce = 0;
        ppbStack_20e8 = (byte **)0x0;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d14;
        auStack_24f0[0] = func_0x(lStack_2460);
        if ((auStack_24f0[0] & 1) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d20;
          lVar16 = func_0x();
          if (lVar16 == 0) {
            puVar19 = (uint *)0x4;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d2a;
            lVar16 = func_0x();
            puVar19 = (uint *)(lVar16 + 0x10);
          }
          *puVar19 = *puVar19 | 2;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100d4e;
          (*_DAT_)(0x59,0x43,0x10,0x9e);
        }
        uStack_20c4 = uVar13;
        if (-1 < *(char *)(lVar18 + 2)) goto LAB_;
        pbVar1 = (byte *)(lVar18 + 0x60);
        if ((sStack_20f8 == 0) || (ppbVar21 = ppbStack_20e8, ppbStack_20e8 == (byte **)0x0)) {
          uStack_2098 = 0;
          uStack_208a = 0;
          auStack_2070 = ZEXT816(0);
          auStack_20c0 = ZEXT816(0);
          stack0xffffffffffffdf52 = SUB1614(ZEXT816(0),2);
          auStack_20b0._0_2_ = 0xffff;
          uStack_20a8 = 0;
          uStack_2092 = 0;
          uStack_2090 = 0;
          uStack_2088 = 0;
          uStack_20a0 = 0;
          auStack_2080 = ZEXT816(0);
          auStack_2060._0_12_ = ZEXT812(0);
          auStack_2060._12_4_ = 0;
          uStack_2050 = 0;
          ppbVar21 = (byte **)auStack_20c0;
        }
        if (*(short *)(lVar18 + 0x24) == 0) {
LAB_:
          uStack_2470 = *(undefined8 *)(lVar18 + 0x28);
          uStack_2468 = *(undefined2 *)(lVar18 + 0x30);
        }
        else {
          cVar9 = *(char *)(lVar18 + 1);
          if (cVar9 == '\v') {
            if (*(int *)(lVar18 + 0x18) != 99) {
LAB_:
              if (cVar9 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar9 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar18 + 0x18) != 99) goto LAB_;
          }
          uStack_24e8 = *(undefined4 *)(lVar18 + 0x20);
          uStack_24e4 = *(undefined2 *)(lVar18 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100e70;
          cVar9 = func_0x(&uStack_24e8);
          if (cVar9 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100e80;
          func_0x(lVar18,&uStack_2470);
        }
        *ppbVar21 = pbVar1;
        *(undefined4 *)(ppbVar21 + 0xc) = (undefined4)uStack_2470;
        *(int *)((longlong)ppbVar21 + 100) = (int)((ulonglong)uStack_2470 >> 0x20);
        *(undefined2 *)(ppbVar21 + 0xd) = uStack_2468;
        *(undefined4 *)((longlong)ppbVar21 + 0x6c) = *(undefined4 *)(lVar18 + 0x20);
        *(undefined2 *)(ppbVar21 + 0xe) = *(undefined2 *)(lVar18 + 0x24);
        *(undefined2 *)((longlong)ppbVar21 + 0x72) = 0;
        uStack_24e8 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0xb38f50);
        uVar23 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0xb38f54);
        *(undefined2 *)(ppbVar21 + 2) = 0xffff;
        ppbVar21[3] = (byte *)0x0;
        *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
        *(undefined8 *)((longlong)ppbVar21 + 0x2e) = 0;
        ppbVar21[7] = (byte *)0x0;
        ppbVar21[4] = (byte *)0x0;
        ppbVar21[9] = (byte *)0x0;
        ppbVar21[10] = (byte *)0x0;
        *(undefined2 *)(ppbVar21 + 0xb) = 0;
        if ((**ppbVar21 & 2) != 0) {
          pbVar1 = pbVar1 + uVar23;
          if ((*pbVar1 & 1) == 0) {
            *(undefined2 *)(ppbVar21 + 2) = 0;
            ppbVar21[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar21 + 0x14) = 0;
            *(undefined4 *)((longlong)ppbVar21 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001010e5 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x102ee4) -
                      0x1a5fec0))();
            return;
          }
          *(undefined2 *)(ppbVar21 + 2) = 1;
          ppbVar21[3] = pbVar1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x102ec4) *
                                  4 + 0x102eb4) - 0x1a5fec0);
                    /* WARNING: Could not emulate address calculation at 0x00100f46 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if ((**ppbVar21 & 4) != 0) {
          uStack_24e8._2_2_ = (short)((uint)uStack_24e8 >> 0x10);
          if (uStack_24e8._2_2_ != 0) {
            uVar23 = (ulonglong)*(ushort *)(lVar18 + 0x61 + (longlong)uStack_24e8._2_2_ * 2);
          }
          psVar20 = (short *)(pbVar1 + uVar23);
          ppbVar21[9] = (byte *)psVar20;
          sVar5 = *psVar20;
          ppbVar21[10] = (byte *)(psVar20 + 1);
          *(short *)(ppbVar21 + 0xb) = (sVar5 + 1) * 2;
        }
        pbVar1 = ppbVar21[1];
        if (pbVar1 != (byte *)0x0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1011a8;
          func_0x(pbVar1,ppbVar21);
        }
LAB_:
        pbStack_20f0 = (byte *)((ulonglong)*puVar2 + lVar18);
        if ((*pbStack_20f0 & 1) == 0) {
          sStack_20f8 = 0;
          uStack_20f4 = 0;
          uStack_20d2 = 0;
          uStack_20d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001013ea */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_20f0 & 0xe) * 4 + 0x102f50) -
                    0x1a5fec0))(0xaba670);
          return;
        }
        sStack_20f8 = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_20f0 & 0x1c) + 0x102f30) * 4 +
                               0x102f20) - 0x1a5fec0);
                    /* WARNING: Could not emulate address calculation at 0x00101202 */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbStack_20f0,0xaba670);
        return;
      }
    }
    if (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) == *(longlong *)(lVar16 + 0x2120)) goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100792;
    cVar9 = func_0x(lVar16);
    if (cVar9 != '\0') goto LAB_;
    if (lVar18 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007a4;
      lVar18 = func_0x();
    }
    lVar22 = *plStack_2518;
    if (*(short *)(lVar22 + 0x24) == 0) {
LAB_:
      uStack_2480 = *(undefined8 *)(lVar22 + 0x28);
      uStack_2478 = *(undefined2 *)(lVar22 + 0x30);
    }
    else {
      cVar9 = *(char *)(lVar22 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(lVar22 + 0x18) != 99) {
LAB_:
          if (cVar9 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar9 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar22 + 0x18) != 99) goto LAB_;
      }
      uStack_2494 = *(undefined4 *)(lVar22 + 0x20);
      uStack_2490 = *(undefined2 *)(lVar22 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007f3;
      cVar9 = func_0x(&uStack_2494);
      if (cVar9 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100803;
      func_0x(lVar22,&uStack_2480);
    }
    plVar7 = plStack_2518;
    if (plStack_2518 != (longlong *)0x0) {
      iVar11 = (int)(short)uStack_250c;
      if (((*(ushort *)((longlong)plStack_2518 + 0x62) & 0x400) == 0) || (iVar11 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_2518 + 0x62) >> 3 & 1) != 0) {
          if (iVar11 == 3) {
            iVar11 = 4;
          }
          else if (iVar11 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_2518 + 100) & 8) != 0) &&
              (lVar22 = plStack_2518[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0)) {
            uVar6 = *(undefined8 *)(lVar22 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1008ab;
            func_0x(uVar6,plStack_2518,iVar11);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar7 + 100) & 8) != 0)) &&
           ((2 < iVar11 &&
            (((*(uint *)((longlong)plVar7 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar22 = *plVar7, lVar22 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1008ec;
          iVar14 = (*_DAT_)(lVar22,0x2000,2,auStack_2428);
          if (iVar14 != 0) {
            LOCK();
            *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar7 + 100) = *(uint *)((longlong)plVar7 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10090e;
        func_0x(plVar7 + 0x13,iVar11);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10092d;
          func_0x(plVar7,0,iVar11);
        }
        uStack_250c = uStack_250c & 0xffff0000;
        plStack_2518 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10084a;
        func_0x(&plStack_2518);
      }
    }
    uStack_2458 = uStack_2480;
    uStack_2450 = uStack_2478;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
    uVar6 = *(undefined8 *)(lVar16 + 0x728);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10097b;
    func_0x(uVar6,&uStack_2458,4,4);
  } while( true );
}

