
/* WARNING: Switch with 1 destination removed at 0x00100064 : 10 cases all go to same destination */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 in_stack_ffffffffffffffd8;
  undefined4 uVar3;
  
  uVar3 = (undefined4)((ulonglong)in_stack_ffffffffffffffd8 >> 0x20);
  if (*(char *)(param_1 + 0x18) == '\0') {
    uVar3 = 0;
    (*_DAT_)(1,0x23d0fe8,0x23c13b0,0x1f7,0);
  }
  iVar1 = *(int *)(param_1 + 0x14);
  if (iVar1 - 1U < 10) {
    uVar2 = (*pcRam0000000001ebd4b0)();
    iVar1 = func_0x(param_2,param_3,0x21d7450,uVar2,CONCAT44(uVar3,iVar1));
    if (-1 < iVar1) {
      return;
    }
  }
  else {
    (*_DAT_)(1,0x23c0cb0,0x23c13b0,0x20e,0x1fba920);
    iVar1 = -0x7fffbffb;
  }
  (*_DAT_)(4,7,0x10,1,0x21d7428,0x214,iVar1);
  return;
}

