
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong **param_3,undefined4 param_4)

{
  byte bVar1;
  undefined2 uVar2;
  int iVar3;
  undefined8 *puVar4;
  code *pcVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong lVar8;
  ulonglong uVar9;
  char cVar10;
  short sVar11;
  int iVar12;
  longlong lVar13;
  ulonglong uVar14;
  uint *puVar15;
  ushort *puVar16;
  undefined2 *puVar17;
  longlong lVar18;
  longlong *plVar19;
  undefined4 *puVar20;
  longlong *plVar21;
  int *piVar22;
  undefined4 uVar23;
  ushort uVar24;
  uint uVar25;
  longlong unaff_GS_OFFSET;
  undefined8 auStackX_8 [2];
  undefined4 auStackX_18 [4];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  *(undefined8 *)(&stack0x00000b88 + lVar13) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00001c68 + lVar13) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar13);
  *(undefined4 *)(&stack0x000002b8 + lVar13) = param_4;
  *(longlong ***)(&stack0x00000360 + lVar13) = param_3;
  *(undefined8 *)(&stack0x00000400 + lVar13) = param_2;
  *(longlong *)(&stack0x000005e0 + lVar13) = param_1;
  *(longlong *)(&stack0x00000450 + lVar13) = param_1;
  *(longlong ***)(&stack0x00000458 + lVar13) = param_3;
  *(undefined8 *)(&stack0x00000470 + lVar13) = *(undefined8 *)(&stack0x00001cd8 + lVar13);
  *(undefined4 *)(&stack0x00000054 + lVar13) = 0;
  *(undefined2 *)(&stack0x00000058 + lVar13) = 0;
  *(undefined8 *)(&stack0x00000038 + lVar13) = 0;
  (&stack0x00000040)[lVar13] = 0;
  uVar25 = *(uint *)(&stack0x00000044 + lVar13);
  *(uint *)(&stack0x00000044 + lVar13) = uVar25 & 0xffff0000;
  *(uint *)(&stack0x00000044 + lVar13) = uVar25 & 0xff000000;
  *(undefined4 *)(&stack0x00000044 + lVar13) = 0;
  *(undefined8 *)(&stack0x000000d0 + lVar13) = 0;
  (&stack0x000000d8)[lVar13] = 0;
  uVar25 = *(uint *)(&stack0x000000dc + lVar13);
  *(uint *)(&stack0x000000dc + lVar13) = uVar25 & 0xffff0000;
  *(uint *)(&stack0x000000dc + lVar13) = uVar25 & 0xff000000;
  *(undefined4 *)(&stack0x000000dc + lVar13) = 0;
  puVar4 = (undefined8 *)**(longlong **)(param_1 + 8);
  *(undefined8 **)(&stack0x000005e8 + lVar13) = puVar4;
  *(ulonglong *)(&stack0x00000468 + lVar13) = (ulonglong)*(uint6 *)((longlong)puVar4 + 0x14) << 0x10
  ;
  lVar18 = puVar4[1];
  *(undefined4 *)(&stack0x000000e8 + lVar13) = *(undefined4 *)(lVar18 + 0x3c0);
  *(undefined2 *)(&stack0x000000ec + lVar13) = *(undefined2 *)(lVar18 + 0x3c4);
  *(undefined2 *)(&stack0x000000ee + lVar13) = 0;
  uVar23 = 2;
  if (*(int *)(param_1 + 0xfc) == 3) {
    uVar23 = 0;
  }
  *(undefined4 *)(&stack0x000001cc + lVar13) = uVar23;
  *(undefined2 *)(&stack0x00000698 + lVar13) = 0xffff;
  *(undefined8 *)(&stack0x000006a0 + lVar13) = 0;
  *(undefined4 *)(&stack0x0000069c + lVar13) = 0;
  *(undefined8 *)(&stack0x000006b6 + lVar13) = 0;
  *(undefined8 *)(&stack0x000006c0 + lVar13) = 0;
  *(undefined8 *)(&stack0x000006a8 + lVar13) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1001a2;
  func_0x(&stack0x00001208 + lVar13,0,0xa58);
  *(undefined (*) [16])(&stack0x00000ee0 + lVar13) = ZEXT816(0);
  *(undefined4 *)(&stack0x00000690 + lVar13) = 0;
  *(undefined8 *)(&stack0x00000658 + lVar13) = 0;
  *(undefined8 **)(&stack0x00000660 + lVar13) = puVar4;
  pcVar5 = *(code **)*puVar4;
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1001cd;
  sVar11 = (*pcVar5)(puVar4);
  if (sVar11 == 2) {
    uVar23 = 2;
  }
  *(undefined4 *)(&stack0x00000694 + lVar13) = uVar23;
  if (*_DAT_ != '\0') {
    plVar21 = (longlong *)0x0;
    if (_DAT_ != 0) {
      plVar21 = (longlong *)(_DAT_ + 0x6800);
    }
    if ((plVar21 != (longlong *)0x0) && (*plVar21 != 0)) {
      LOCK();
      plVar21 = (longlong *)(*plVar21 + 0x90);
      *plVar21 = *plVar21 + 1;
      UNLOCK();
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10023e;
      func_0x(param_1,0x2456888);
      *(undefined8 *)(&stack0x00000658 + lVar13) = *(undefined8 *)(param_1 + 0x110);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10025d;
      func_0x(&stack0x00000658 + lVar13,param_2);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10026d;
      func_0x(&stack0x00000658 + lVar13,param_3);
      lVar18 = **param_3;
      *(longlong *)(&stack0x00000b90 + lVar13) = lVar18;
      *(int **)(&stack0x00000b98 + lVar13) = (int *)(lVar18 + 0x10);
      iVar12 = *(int *)(lVar18 + 0x10);
      *(int *)(&stack0x00000494 + lVar13) = iVar12;
      uVar2 = *(undefined2 *)(lVar18 + 0x14);
      *(undefined2 *)(&stack0x00000498 + lVar13) = uVar2;
      *(int *)(&stack0x00000054 + lVar13) = iVar12;
      *(undefined2 *)(&stack0x00000058 + lVar13) = uVar2;
      *(undefined4 *)(&stack0x00000488 + lVar13) = 0;
      *(undefined2 *)(&stack0x0000048c + lVar13) = 0;
      if (iVar12 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar21 = *(longlong **)(param_1 + 8);
      *(longlong **)(&stack0x00000460 + lVar13) = plVar21;
      *(undefined8 *)(&stack0x000003d0 + lVar13) = *(undefined8 *)(param_1 + 0x10);
      *(undefined4 *)(&stack0x00000270 + lVar13) = 0;
      *(undefined4 *)(&stack0x00000274 + lVar13) = 0;
      *(undefined2 *)(&stack0x00000278 + lVar13) = 0;
      lVar18 = *plVar21;
      *(longlong *)(&stack0x000005d0 + lVar13) = lVar18;
      *(undefined4 *)(&stack0x00000634 + lVar13) = 0;
      *(undefined4 *)(&stack0x00000638 + lVar13) = 0;
      lVar6 = *(longlong *)(lVar18 + 0x20);
      *(longlong *)(&stack0x00000060 + lVar13) = lVar6;
      *(uint6 **)(&stack0x00000ba0 + lVar13) = (uint6 *)(lVar18 + 0x14);
      lVar18 = (ulonglong)*(uint6 *)(lVar18 + 0x14) * 0x10000;
      *(longlong *)(&stack0x00000ba8 + lVar13) = lVar18;
      if (*(longlong *)(lVar6 + 2000) == lVar18) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      (&stack0x00000068)[lVar13] = 0;
      if (*(longlong *)(lVar6 + 0x7d8) == lVar18) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      (&stack0x00000069)[lVar13] = 0;
      lVar18 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00000bb0 + lVar13) = lVar18;
      lVar18 = (ulonglong)*_DAT_ + *(longlong *)(lVar18 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00000bb8 + lVar13) = lVar18;
      lVar18 = *(longlong *)(lVar18 + 0x100);
      *(longlong *)(&stack0x00000590 + lVar13) = lVar18;
      if (lVar18 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(longlong *)(&stack0x00000bc0 + lVar13) = lVar18;
      uVar9 = rdtsc();
      uVar14 = CONCAT44((int)((ulonglong)_DAT_ >> 0x20),(int)uVar9) |
               uVar9 & 0xffffffff00000000;
      *(ulonglong *)(&stack0x00000bc8 + lVar13) = uVar14;
      uVar9 = *(ulonglong *)(lVar18 + 0x340);
      if ((uVar9 < uVar14) ||
         ((uVar9 != 0x7fffffffffffffff &&
          (*(ulonglong *)(*(longlong *)(lVar18 + 0x260) + 0xdf0) < uVar9 - uVar14)))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      lVar18 = *(longlong *)(lVar18 + 600);
      *(longlong *)(&stack0x00000598 + lVar13) = lVar18;
      puVar15 = (uint *)(lVar18 + 0xbc);
      *(uint **)(&stack0x00000bd0 + lVar13) = puVar15;
      if ((*puVar15 & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined4 *)(&stack0x000001d0 + lVar13) = 0;
      *(undefined4 *)(&stack0x000004a0 + lVar13) = 0;
      *(undefined4 *)(&stack0x000004a4 + lVar13) = 0;
      *(undefined2 *)(&stack0x000004a8 + lVar13) = 0;
      (&stack0x0000006c)[lVar13] = 0;
      (&stack0x00000050)[lVar13] = 0xff;
      *(undefined **)(&stack0x00000478 + lVar13) = &stack0x00000630 + lVar13;
      *(undefined4 *)(&stack0x00000ecc + lVar13) = 0;
      *(undefined4 *)(&stack0x00000ed0 + lVar13) = 0;
      cVar10 = *_DAT_;
      (&stack0x00000190)[lVar13] = cVar10;
      if ((cVar10 != '\0') &&
         ((&stack0x00000191)[lVar13] = DAT_ >> 7, -1 < (char)DAT_)) {
        *(undefined4 *)(&stack0x00000370 + lVar13) = 0;
        lVar18 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00000be0 + lVar13) = lVar18;
        plVar21 = (longlong *)
                  ((ulonglong)*_DAT_ + *(longlong *)(lVar18 + (ulonglong)*_DAT_ * 8)
                  );
        *(longlong **)(&stack0x00000bf0 + lVar13) = plVar21;
        lVar18 = *plVar21;
        *(longlong *)(&stack0x00000bf8 + lVar13) = lVar18;
        if ((lVar18 != 0) &&
           (lVar18 = **(longlong **)(lVar18 + 0x38),
           *(longlong *)(&stack0x00000be8 + lVar13) = lVar18, lVar18 != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        *(undefined8 *)(&stack0x000005a0 + lVar13) = 0;
        lVar18 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00000c00 + lVar13) = lVar18;
        lVar18 = (ulonglong)*_DAT_ + *(longlong *)(lVar18 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00000c08 + lVar13) = lVar18;
        lVar18 = *(longlong *)(lVar18 + 8);
        *(longlong *)(&stack0x00000c10 + lVar13) = lVar18;
        lVar6 = *(longlong *)(&stack0x00000060 + lVar13);
        if (lVar18 != 0) {
          *(undefined8 *)(&stack0x000001f8 + lVar13) = *(undefined8 *)(lVar18 + 0x60);
          *(longlong *)(&stack0x000005a8 + lVar13) = *(longlong *)(lVar6 + 0x728);
          *(undefined4 *)(&stack0x000001d4 + lVar13) = 0;
          if (*(longlong *)(&stack0x00000038 + lVar13) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(longlong *)(lVar6 + 0x728) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1005cf;
          func_0x(lVar6,&stack0x00000054 + lVar13);
          *(undefined8 *)(&stack0xfffffffffffffff0 + lVar13) =
               *(undefined8 *)(&stack0x00000478 + lVar13);
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) = 4;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100603;
          plVar21 = (longlong *)
                    func_0x
                              (_DAT_,lVar6,&stack0x00000054 + lVar13,
                               &stack0x000001d4 + lVar13);
          *(longlong **)(&stack0x00000038 + lVar13) = plVar21;
          uVar25 = *(uint *)(&stack0x00000044 + lVar13) & 0xffff0004 | 4;
          *(uint *)(&stack0x00000044 + lVar13) = uVar25;
          if (*(longlong *)(&stack0x000001f8 + lVar13) != 0) {
            lVar18 = *plVar21;
            *(longlong *)(&stack0x00000750 + lVar13) = lVar18;
            plVar19 = (longlong *)(*(longlong *)(&stack0x000001f8 + lVar13) + 0x500);
            *(longlong **)(&stack0x00000758 + lVar13) = plVar19;
            plVar21 = plVar19 + (ulonglong)(*(uint *)plVar19 & 0xf) + 1;
            *(longlong **)(&stack0x00000760 + lVar13) = plVar21;
            if (*plVar21 != lVar18) {
              *plVar21 = lVar18;
              *plVar19 = *plVar19 + 1;
              uVar25 = *(uint *)(&stack0x00000044 + lVar13);
            }
          }
          *(uint *)(&stack0x00000044 + lVar13) =
               (*(uint *)(&stack0x000001d4 + lVar13) >> 3 & 1) << 0x18 | uVar25 & 0xffffff;
          *(uint *)(&stack0x00000048 + lVar13) =
               *(uint *)(&stack0x000001d4 + lVar13) >> 4 & 1 |
               *(uint *)(&stack0x00000048 + lVar13) & 0xffffff00;
          if (*(longlong *)(&stack0x000005a8 + lVar13) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1006be;
          cVar10 = func_0x(lVar6);
          if (cVar10 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((1 < *(short *)(&stack0x00000044 + lVar13)) && ((&stack0x00000050)[lVar13] != -1)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined4 *)(&stack0x000004d0 + lVar13) = 0;
          *(undefined4 *)(&stack0x000004d4 + lVar13) = 0;
          *(undefined2 *)(&stack0x000004d8 + lVar13) = 0;
          if (((*(short *)(&stack0x00000278 + lVar13) != 0) ||
              (*(int *)(&stack0x00000270 + lVar13) != 0)) ||
             (*(int *)(&stack0x00000274 + lVar13) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          lVar18 = *(longlong *)(&stack0x000003d0 + lVar13);
          piVar22 = (int *)(lVar18 + 4);
          *piVar22 = *piVar22 + 1;
          if (*(longlong *)(lVar18 + 0x58) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(uint *)(&stack0x00000044 + lVar13) & 0xff000000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(int *)(&stack0x00000634 + lVar13) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          (&stack0x00000199)[lVar13] = 0;
          (&stack0x0000019a)[lVar13] = 1;
          *(undefined4 *)(&stack0x000001e0 + lVar13) = 0;
          *(undefined2 *)(&stack0x000001e4 + lVar13) = 0;
          *(undefined2 *)(&stack0x000001e6 + lVar13) = 0;
          lVar18 = **(longlong **)(&stack0x00000460 + lVar13);
          *(longlong *)(&stack0x000005d8 + lVar13) = lVar18;
          lVar6 = **(longlong **)(&stack0x00000038 + lVar13);
          *(longlong *)(&stack0x00000938 + lVar13) = lVar6;
          lVar18 = *(longlong *)(lVar18 + 8);
          piVar22 = (int *)(lVar18 + 0x3c0);
          *(int **)(&stack0x00000940 + lVar13) = piVar22;
          *(undefined4 *)(&stack0x00000298 + lVar13) = 0;
          if (*(int *)(lVar6 + 0x18) != *piVar22) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(short *)(lVar6 + 6) != *(short *)(lVar18 + 0x3c4)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined4 *)(&stack0x00000298 + lVar13) = 1;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1007f8;
          func_0x(&stack0x00000658 + lVar13,&stack0x00000038 + lVar13);
          plVar21 = *param_3;
          lVar18 = *(longlong *)(&stack0x000005e0 + lVar13);
          lVar6 = *plVar21;
          *(longlong *)(&stack0x00000998 + lVar13) = lVar6;
          bVar1 = *(byte *)(lVar6 + 3);
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar13) = 1;
          *(uint *)(&stack0xffffffffffffffe8 + lVar13) = (uint)bVar1;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100840;
          func_0x(lVar18,&stack0x000000d0 + lVar13,plVar21 + 0xe,&stack0x00000054 + lVar13);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100855;
          func_0x(&stack0x00000658 + lVar13,&stack0x000000d0 + lVar13);
          *(undefined **)(&stack0x000009a0 + lVar13) = &stack0x00000248 + lVar13;
          puVar20 = (undefined4 *)(*(longlong *)(&stack0x000000d0 + lVar13) + 0x70);
          *(undefined4 **)(&stack0x000009a8 + lVar13) = puVar20;
          *(undefined4 *)(&stack0x00000248 + lVar13) = *puVar20;
          *(undefined2 *)(&stack0x0000024c + lVar13) =
               *(undefined2 *)(*(longlong *)(&stack0x000000d0 + lVar13) + 0x74);
          uVar7 = *(undefined8 *)(lVar18 + 0x110);
          *(undefined8 *)(&stack0x000009b0 + lVar13) = uVar7;
          *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = uVar7;
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar13) =
               *(undefined4 *)(&stack0x000001cc + lVar13);
          *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000248 + lVar13;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1008d1;
          func_0x(param_3,&stack0x000000e8 + lVar13,0x10,6);
          *(undefined4 *)(&stack0x00000360 + lVar13) = 0;
          *(undefined2 *)(&stack0x00000364 + lVar13) = 0;
          if (*(int *)(&stack0x00000054 + lVar13) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined **)(&stack0x000009b8 + lVar13) = &stack0x00000250 + lVar13;
          puVar20 = (undefined4 *)(*(longlong *)(&stack0x000000d0 + lVar13) + 0x70);
          *(undefined4 **)(&stack0x000009c0 + lVar13) = puVar20;
          *(undefined4 *)(&stack0x00000250 + lVar13) = *puVar20;
          *(undefined2 *)(&stack0x00000254 + lVar13) =
               *(undefined2 *)(*(longlong *)(&stack0x000000d0 + lVar13) + 0x74);
          uVar7 = *(undefined8 *)(lVar18 + 0x110);
          *(undefined8 *)(&stack0x000009c8 + lVar13) = uVar7;
          *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = uVar7;
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar13) =
               *(undefined4 *)(&stack0x000001cc + lVar13);
          *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00000250 + lVar13;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10096b;
          func_0x(&stack0x00000038 + lVar13,&stack0x000000e8 + lVar13,8,6);
          *(longlong *)(&stack0x000009d0 + lVar13) = **param_3;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10098d;
          iVar12 = func_0x(lVar18);
          *(int *)(&stack0x000004e0 + lVar13) = iVar12;
          if (*(char *)(*(longlong *)(*(longlong *)(&stack0x000005e8 + lVar13) + 0x20) + 0x1cdf) !=
              '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          (&stack0x0000019d)[lVar13] = 0;
          lVar6 = **param_3;
          *(longlong *)(&stack0x000009d8 + lVar13) = lVar6;
          uVar24 = *(ushort *)(lVar6 + 0x16);
          *(undefined *)((longlong)auStackX_18 + lVar13 + -0x18) = 0;
          *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = *(undefined8 *)(lVar18 + 0x110);
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar13) = *(undefined4 *)(lVar18 + 0x100);
          *(uint *)(&stack0xffffffffffffffe8 + lVar13) = (uint)uVar24 - iVar12;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a0d;
          func_0x
                    (&stack0x000000d0 + lVar13,&stack0x000000e8 + lVar13,param_3,iVar12);
          lVar6 = *(longlong *)(lVar18 + 0x110);
          lVar8 = **param_3;
          uVar23 = *(undefined4 *)(lVar18 + 0x100);
          if (lVar6 == *(longlong *)(*(longlong *)(lVar18 + 8) + 8)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(longlong *)(&stack0x000009e0 + lVar13) = lVar8;
          uVar24 = *(ushort *)(lVar8 + 0x16);
          *(longlong *)(&stack0xfffffffffffffff8 + lVar13) = lVar6;
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar13) = uVar23;
          *(longlong *)(&stack0xffffffffffffffe8 + lVar13) =
               *(longlong *)(&stack0x000000d0 + lVar13) + 0x70;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a6e;
          func_0x(param_3,&stack0x000000e8 + lVar13,iVar12,(uint)uVar24 - iVar12);
          *(undefined4 *)(&stack0x00000350 + lVar13) = 0;
          *(undefined2 *)(&stack0x00000354 + lVar13) = 0;
          uVar7 = **(undefined8 **)(&stack0x000000d0 + lVar13);
          *(undefined8 *)(&stack0x000009f0 + lVar13) = uVar7;
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar13) = 0xa58;
          *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0x00001208 + lVar13;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100ac0;
          func_0x(lVar18,uVar7,&stack0x00000350 + lVar13,&stack0x00000698 + lVar13);
          *(undefined **)(&stack0x00000ee0 + lVar13) = &stack0x00000698 + lVar13;
          uVar7 = *(undefined8 *)(lVar18 + 0x110);
          *(undefined8 *)(&stack0x000009f8 + lVar13) = uVar7;
          uVar23 = *(undefined4 *)(lVar18 + 0x100);
          *(undefined4 *)(&stack0x000004e8 + lVar13) = uVar23;
          iVar3 = *(int *)(&stack0x000002b8 + lVar13);
          *(undefined4 *)((longlong)auStackX_18 + lVar13 + 8) = 0;
          *(undefined4 *)((longlong)auStackX_18 + lVar13) = 0;
          *(undefined8 *)((longlong)auStackX_8 + lVar13 + 8) = 0;
          *(undefined8 *)((longlong)auStackX_8 + lVar13) = uVar7;
          *(undefined4 *)((longlong)auStackX_18 + lVar13 + -0x18) = 0;
          *(undefined4 *)(&stack0xfffffffffffffff8 + lVar13) = uVar23;
          *(undefined **)(&stack0xfffffffffffffff0 + lVar13) = &stack0x00000ee0 + lVar13;
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) = 1;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b43;
          func_0x
                    (*(undefined8 *)(&stack0x00000400 + lVar13),
                     *(undefined8 *)(&stack0x00000468 + lVar13),&stack0x000000e8 + lVar13,iVar3 + 1)
          ;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b50;
          func_0x(&stack0x00000658 + lVar13);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100b58;
          func_0x(lVar18);
          *(undefined4 *)(&stack0x00000400 + lVar13) = 2;
          *(undefined4 *)(&stack0x00000404 + lVar13) = 0x100;
          if ((_DAT_ & 0x100) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          iVar3 = **(int **)(&stack0x00000470 + lVar13);
          if (iVar3 < iVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          **(int **)(&stack0x00000470 + lVar13) = iVar3 - iVar12;
          if (*param_3 != (longlong *)0x0) {
            puVar16 = (ushort *)((longlong)*param_3 + 0x62);
            *(ushort **)(&stack0x00000a38 + lVar13) = puVar16;
            uVar24 = *puVar16;
            *(ushort *)(&stack0x00000150 + lVar13) = uVar24;
            if ((uVar24 & 0x400) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(int *)(&stack0x000000b0 + lVar13) = (int)*(short *)((longlong)param_3 + 0xc);
            plVar21 = *param_3;
            *(longlong **)(&stack0x000001a8 + lVar13) = plVar21;
            puVar17 = (undefined2 *)((longlong)plVar21 + 0x62);
            *(undefined2 **)(&stack0x00000a40 + lVar13) = puVar17;
            uVar2 = *puVar17;
            *(undefined2 *)(&stack0x00000158 + lVar13) = uVar2;
            if (((byte)uVar2 >> 3 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            (&stack0x0000019e)[lVar13] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c33;
            func_0x
                      (*(longlong *)(&stack0x000001a8 + lVar13) + 0x98,
                       *(undefined4 *)(&stack0x000000b0 + lVar13));
            if (_DAT_ != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(uint *)((longlong)param_3 + 0xc) = *(uint *)((longlong)param_3 + 0xc) & 0xffff0000;
            *param_3 = (longlong *)0x0;
          }
          *param_3 = *(longlong **)(&stack0x000000d0 + lVar13);
          *(uint *)((longlong)param_3 + 0xc) = *(uint *)((longlong)param_3 + 0xc) & 0xffff0000;
          *(uint *)((longlong)param_3 + 0xc) =
               *(uint *)((longlong)param_3 + 0xc) | (uint)*(ushort *)(&stack0x000000dc + lVar13);
          *(undefined8 *)(&stack0x000000d0 + lVar13) = 0;
          *(uint *)(&stack0x000000dc + lVar13) = *(uint *)(&stack0x000000dc + lVar13) & 0xffff0000;
          if (*(longlong *)(&stack0x00000038 + lVar13) != 0) {
            puVar17 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar13) + 0x62);
            *(undefined2 **)(&stack0x00000ac8 + lVar13) = puVar17;
            *(undefined2 *)(&stack0x00000180 + lVar13) = *puVar17;
            if ((*(ushort *)(&stack0x00000180 + lVar13) & 0x400) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(int *)(&stack0x000000c8 + lVar13) = (int)*(short *)(&stack0x00000044 + lVar13);
            *(undefined8 *)(&stack0x000003e8 + lVar13) = *(undefined8 *)(&stack0x00000038 + lVar13);
            *(undefined2 **)(&stack0x00000ad0 + lVar13) = puVar17;
            uVar2 = *puVar17;
            *(undefined2 *)(&stack0x00000188 + lVar13) = uVar2;
            if (((byte)uVar2 >> 3 & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            (&stack0x000000f4)[lVar13] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100d27;
            func_0x
                      (*(longlong *)(&stack0x000003e8 + lVar13) + 0x98,
                       *(undefined4 *)(&stack0x000000c8 + lVar13));
            if (_DAT_ != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            *(uint *)(&stack0x00000044 + lVar13) = *(uint *)(&stack0x00000044 + lVar13) & 0xffff0000
            ;
            *(undefined8 *)(&stack0x00000038 + lVar13) = 0;
          }
          lVar6 = *(longlong *)
                   ((ulonglong)*_DAT_ +
                    *(longlong *)
                     (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 0x100
                   );
          if (lVar6 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*(int *)(lVar6 + 0x22c) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          lVar6 = **param_3;
          if (*(ushort *)(lVar6 + 0x1c) < 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar24 = (ushort)((1 << ((byte)*(undefined2 *)(lVar6 + 4) & 2)) + -1);
          if (((uint)(ushort)(uVar24 + *(short *)(*(longlong *)(**(longlong **)(lVar18 + 8) + 8) +
                                                 0xb4) & ~uVar24) <= *(ushort *)(lVar6 + 0x1c) - 2)
             && (1 < *(ushort *)(lVar6 + 0x16))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100def;
            func_0x(&stack0x000000d0 + lVar13);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100dfa;
            func_0x(&stack0x00000038 + lVar13);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e0a;
            func_0x
                      (*(ulonglong *)(&stack0x00001c68 + lVar13) ^
                       (ulonglong)(&stack0xffffffffffffffc8 + lVar13));
            return;
          }
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

