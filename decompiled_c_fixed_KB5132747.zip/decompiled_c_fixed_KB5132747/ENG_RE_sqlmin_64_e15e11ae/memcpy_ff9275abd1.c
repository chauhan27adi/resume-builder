
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined (*param_1) [32],undefined (*param_2) [32],ulonglong param_3)

{
  code *UNRECOVERED_JUMPTABLE;
  undefined auVar1 [32];
  
  if (param_3 < 0x10) {
    UNRECOVERED_JUMPTABLE = (code *)((ulonglong)*(uint *)(param_3 * 4 + 0x331a380) + 0xf2380);
                    /* WARNING: Could not emulate address calculation at 0x00100015 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(param_1,param_2,param_3,UNRECOVERED_JUMPTABLE);
    return;
  }
  if (param_3 < 0x21) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_2 < param_1) && (param_1 < (undefined (*) [32])(*param_2 + param_3))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (_DAT_ < 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_3 < 0x2001) {
    auVar1 = vmovdqu_avx(*param_2);
    vmovdqu_avx(*(undefined (*) [32])(param_2[-1] + param_3));
    if (param_3 < 0x101) {
                    /* WARNING: Could not emulate address calculation at 0x00100087 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((param_3 + 0x1f >> 5) * 4 + 0x331a3c0) + 0xf2380))
                (auVar1._0_8_);
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

