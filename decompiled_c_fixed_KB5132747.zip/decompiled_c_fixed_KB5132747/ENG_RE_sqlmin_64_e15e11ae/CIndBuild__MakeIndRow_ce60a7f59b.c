
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,undefined8 param_3,undefined4 param_4)

{
  byte *pbVar1;
  byte *pbVar2;
  undefined2 uVar3;
  short sVar4;
  char cVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong lVar8;
  short *psVar9;
  code *UNRECOVERED_JUMPTABLE_00;
  byte **ppbVar10;
  ulonglong uVar11;
  undefined auStack_338 [4];
  undefined4 uStack_334;
  undefined8 uStack_330;
  undefined8 uStack_328;
  undefined8 uStack_31a;
  undefined8 uStack_310;
  undefined uStack_2ff;
  undefined2 uStack_2fc;
  undefined4 uStack_2f8;
  longlong lStack_2f0;
  undefined4 uStack_2d8;
  undefined2 uStack_2d4;
  undefined8 uStack_2c8;
  undefined2 uStack_2c0;
  longlong lStack_2b0;
  undefined8 uStack_2a8;
  undefined4 uStack_29c;
  undefined2 uStack_298;
  longlong lStack_290;
  short sStack_1d8;
  undefined4 uStack_1d4;
  byte *pbStack_1d0;
  byte **ppbStack_1c8;
  undefined8 uStack_1ba;
  undefined2 uStack_1b2;
  undefined2 uStack_1b0;
  undefined6 uStack_1ae;
  undefined4 uStack_1a4;
  undefined auStack_1a0 [16];
  undefined auStack_190 [8];
  undefined8 uStack_188;
  undefined8 uStack_180;
  undefined6 uStack_178;
  undefined2 uStack_172;
  undefined6 uStack_170;
  undefined2 uStack_16a;
  undefined8 uStack_168;
  undefined auStack_160 [16];
  undefined auStack_150 [16];
  undefined auStack_140 [16];
  undefined8 uStack_130;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_338;
  lStack_2f0 = param_1 + 0x20;
  lStack_290 = *(longlong *)(param_1 + 0x28);
  pbStack_1d0 = (byte *)0x0;
  uStack_29c = *(undefined4 *)(param_2 + 0x20);
  uStack_298 = *(undefined2 *)(param_2 + 0x24);
  sStack_1d8 = -1;
  uStack_1d4 = 0;
  uStack_1ba = 0;
  uStack_1b0 = 0;
  uStack_1ae = 0;
  ppbStack_1c8 = (byte **)0x0;
  uStack_330 = 0;
  uStack_334 = 0;
  uStack_31a = 0;
  uStack_310 = 0;
  uStack_328 = 0;
  uVar3 = *(undefined2 *)(**(longlong **)(lStack_290 + 0x160) + 0x1c);
  if ((*(int *)(lStack_290 + 0x100) == 0) || (uStack_2ff = 1, *(int *)(lStack_290 + 0x100) - 3U < 2)
     ) {
    uStack_2ff = 0;
  }
  uStack_2fc = uVar3;
  uStack_2f8 = param_4;
  lStack_2b0 = param_1;
  uStack_2a8 = param_3;
  if (*(longlong *)(param_1 + 0x80) == 0) {
    func_0x(*(undefined8 *)(param_1 + 200),uVar3,(longlong *)(param_1 + 0x80));
    if ((*(byte *)(*(longlong *)(param_1 + 0x28) + 0x42) & 4) == 0) {
      uVar6 = *(uint *)(*(longlong *)(param_1 + 0x28) + 0xb4);
      if (0xa58 < uVar6) {
        uVar6 = 0xa58;
      }
    }
    else {
      uVar6 = 0xa58;
    }
    *(uint *)(param_1 + 0x94) = uVar6;
    uVar7 = (*_DAT_)(uVar6,*(undefined8 *)(param_1 + 200),0x12f6f20,0x717,5);
    *(undefined8 *)(param_1 + 0x88) = uVar7;
  }
  if (*(longlong *)(param_1 + 0x70) != 0) {
    func_0x();
    *(undefined8 *)(param_1 + 0x70) = 0;
  }
  lVar8 = func_0x(*(undefined8 *)(param_1 + 200),uVar3);
  *(longlong *)(param_1 + 0x70) = lVar8;
  *(undefined2 *)(lVar8 + 0x62) = uVar3;
  uStack_1a4 = 0;
  if (-1 < *(char *)(param_2 + 2)) goto LAB_;
  pbVar1 = (byte *)(param_2 + 0x60);
  if ((sStack_1d8 == 0) || (ppbVar10 = ppbStack_1c8, ppbStack_1c8 == (byte **)0x0)) {
    ppbVar10 = (byte **)auStack_1a0;
    uStack_178 = 0;
    stack0xfffffffffffffe72 = SUB1614(ZEXT816(0),2);
    auStack_190._0_2_ = 0xffff;
    uStack_16a = 0;
    uStack_188 = 0;
    uStack_172 = 0;
    uStack_170 = 0;
    uStack_168 = 0;
    uStack_180 = 0;
    auStack_160 = ZEXT816(0);
    auStack_140._0_12_ = ZEXT812(0);
    auStack_140._12_4_ = 0;
    uStack_130 = 0;
    auStack_150 = ZEXT816(0);
    auStack_1a0 = ZEXT816(0);
  }
  if (*(short *)(param_2 + 0x24) == 0) {
LAB_:
    uStack_2c8 = *(undefined8 *)(param_2 + 0x28);
    uStack_2c0 = *(undefined2 *)(param_2 + 0x30);
  }
  else {
    cVar5 = *(char *)(param_2 + 1);
    if (cVar5 == '\v') {
      if (*(int *)(param_2 + 0x18) != 99) {
LAB_:
        if (cVar5 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar5 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_2 + 0x18) != 99) goto LAB_;
    }
    uStack_2d8 = *(undefined4 *)(param_2 + 0x20);
    uStack_2d4 = *(undefined2 *)(param_2 + 0x24);
    cVar5 = func_0x(&uStack_2d8);
    if (cVar5 == '\0') goto LAB_;
    func_0x(param_2,&uStack_2c8);
  }
  *ppbVar10 = pbVar1;
  *(undefined4 *)(ppbVar10 + 0xc) = (undefined4)uStack_2c8;
  *(undefined2 *)(ppbVar10 + 0xd) = uStack_2c0;
  *(int *)((longlong)ppbVar10 + 100) = (int)((ulonglong)uStack_2c8 >> 0x20);
  *(undefined4 *)((longlong)ppbVar10 + 0x6c) = *(undefined4 *)(param_2 + 0x20);
  *(undefined2 *)(ppbVar10 + 0xe) = *(undefined2 *)(param_2 + 0x24);
  *(undefined2 *)((longlong)ppbVar10 + 0x72) = 0;
  uStack_2d8 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x10b49b0);
  uVar11 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x10b49b4);
  *(undefined2 *)(ppbVar10 + 2) = 0xffff;
  ppbVar10[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
  ppbVar10[7] = (byte *)0x0;
  ppbVar10[4] = (byte *)0x0;
  ppbVar10[9] = (byte *)0x0;
  ppbVar10[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar10 + 0xb) = 0;
  if ((**ppbVar10 & 2) != 0) {
    pbVar2 = pbVar1 + uVar11;
    if ((pbVar1[uVar11] & 1) == 0) {
      *(undefined2 *)(ppbVar10 + 2) = 0;
      *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar10 + 0x36) = 0;
      ppbVar10[3] = pbVar2;
                    /* WARNING: Could not emulate address calculation at 0x00100519 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x10473c) - 0x14e4460))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar10 + 2) = 1;
    ppbVar10[3] = pbVar2;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x10471c) * 4 +
                           0x10470c) - 0x14e4460);
                    /* WARNING: Could not emulate address calculation at 0x0010037a */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar10 & 4) != 0) {
    uStack_2d8._2_2_ = (short)((uint)uStack_2d8 >> 0x10);
    if (uStack_2d8._2_2_ != 0) {
      uVar11 = (ulonglong)*(ushort *)(param_2 + 0x61 + (longlong)uStack_2d8._2_2_ * 2);
    }
    psVar9 = (short *)(pbVar1 + uVar11);
    ppbVar10[9] = (byte *)psVar9;
    sVar4 = *psVar9;
    ppbVar10[10] = (byte *)(psVar9 + 1);
    *(short *)(ppbVar10 + 0xb) = (sVar4 + 1) * 2;
  }
  if (ppbVar10[1] != (byte *)0x0) {
    func_0x(ppbVar10[1],ppbVar10);
  }
LAB_:
  pbStack_1d0 = (byte *)((ulonglong)*(ushort *)(param_2 + 0x1ffe) + param_2);
  if ((*pbStack_1d0 & 1) == 0) {
    sStack_1d8 = 0;
    uStack_1d4 = 0;
    uStack_1b2 = 0;
    uStack_1b0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100862 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_1d0 & 0xe) * 4 + 0x1047b0) - 0x14e4460)
    )(0x10360d0);
    return;
  }
  sStack_1d8 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_1d0 & 0x1c) + 0x104790) * 4
                         + 0x104780) - 0x14e4460);
                    /* WARNING: Could not emulate address calculation at 0x00100636 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

