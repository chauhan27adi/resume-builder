
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2)

{
  ushort uVar1;
  undefined2 uVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  char cVar8;
  byte bVar9;
  int iVar10;
  undefined2 *puVar11;
  uint *puVar12;
  undefined8 uVar13;
  ushort *puVar14;
  
  (*_DAT_)(param_2 + 0x9c8,param_2 + 0x1738);
  if (*(longlong *)(param_2 + 0x48) != 0) {
    puVar14 = (ushort *)(*(longlong *)(param_2 + 0x48) + 0x62);
    *(ushort **)(param_2 + 0x1368) = puVar14;
    uVar1 = *puVar14;
    *(ushort *)(param_2 + 0x580) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)(param_2 + 0x54) < 3)) {
      *(int *)(param_2 + 0xb8) = (int)*(short *)(param_2 + 0x54);
      *(undefined8 *)(param_2 + 0x608) = *(undefined8 *)(param_2 + 0x48);
      *(ushort **)(param_2 + 0x1370) = puVar14;
      uVar1 = *puVar14;
      *(ushort *)(param_2 + 0x588) = uVar1;
      if (((byte)uVar1 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xb8) == 3) {
          *(undefined4 *)(param_2 + 0xb8) = 4;
        }
        else if (*(int *)(param_2 + 0xb8) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x48) + 100);
        *(uint **)(param_2 + 0x1378) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x8b0) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar5 = *(longlong *)(*(longlong *)(param_2 + 0x48) + 0x90), lVar5 != 0)) &&
           (*(longlong *)(param_2 + 0x1380) = lVar5, *(longlong *)(lVar5 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar5 + 0x758),*(undefined8 *)(param_2 + 0x48),
                     *(undefined4 *)(param_2 + 0xb8));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0x8e8) = 0x32f;
      cVar8 = DAT_ >> 7;
      *(char *)(param_2 + 0x12d) = -cVar8;
      if (-cVar8 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x608) + 100);
        *(uint **)(param_2 + 5000) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x948) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xb8))) {
          *(uint **)(param_2 + 0x1390) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x958) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar5 = **(longlong **)(param_2 + 0x608), lVar5 != 0)) {
            *(undefined4 *)(param_2 + 0x960) = 2;
            iVar10 = (*_DAT_)(lVar5,0x2000,2,param_2 + 0x964);
            if (iVar10 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar5 = *(longlong *)(param_2 + 0x608);
      uVar4 = *(undefined4 *)(param_2 + 0xb8);
      func_0x(lVar5 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0x968) = 0xe79;
        bVar9 = DAT_ >> 1;
        *(byte *)(param_2 + 0x12e) = bVar9;
        if ((bVar9 & 1) != 0) {
          func_0x(lVar5,0,uVar4);
        }
      }
      *(uint *)(param_2 + 0x54) = *(uint *)(param_2 + 0x54) & 0xffff0000;
      *(undefined8 *)(param_2 + 0x48) = 0;
    }
    else {
      func_0x(param_2 + 0x48);
    }
  }
  lVar5 = *(longlong *)(param_2 + 0x920);
  if (*(int *)(lVar5 + 0xd0) == 2) goto LAB_;
  *(longlong **)(param_2 + 0x610) = (longlong *)(lVar5 + 0x68);
  lVar6 = *(longlong *)(lVar5 + 0x68);
  if (lVar6 != 0) {
    puVar14 = (ushort *)(lVar6 + 0x62);
    *(ushort **)(param_2 + 0x1398) = puVar14;
    uVar1 = *puVar14;
    *(ushort *)(param_2 + 0x618) = uVar1;
    plVar7 = *(longlong **)(param_2 + 0x610);
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)((longlong)plVar7 + 0xc) < 3)) {
      *(int *)(param_2 + 0xc0) = (int)*(short *)((longlong)plVar7 + 0xc);
      lVar6 = *plVar7;
      *(longlong *)(param_2 + 0x278) = lVar6;
      puVar11 = (undefined2 *)(lVar6 + 0x62);
      *(undefined2 **)(param_2 + 0x13a0) = puVar11;
      uVar2 = *puVar11;
      *(undefined2 *)(param_2 + 0x620) = uVar2;
      if (((byte)uVar2 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xc0) == 3) {
          *(undefined4 *)(param_2 + 0xc0) = 4;
        }
        else if (*(int *)(param_2 + 0xc0) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x278) + 100);
        *(uint **)(param_2 + 0x13a8) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x970) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0x278) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x13b0) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0x278),
                     *(undefined4 *)(param_2 + 0xc0));
        }
      }
LAB_:
      cVar8 = DAT_ >> 7;
      *(char *)(param_2 + 0x12f) = -cVar8;
      if (-cVar8 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x278) + 100);
        *(uint **)(param_2 + 0x13b8) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x978) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xc0))) {
          *(uint **)(param_2 + 0x13c0) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0x980) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) && (**(longlong **)(param_2 + 0x278) != 0)) {
            iVar10 = (*_DAT_)(**(longlong **)(param_2 + 0x278),0x2000,2,param_2 + 0x780);
            if (iVar10 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0x278);
      uVar4 = *(undefined4 *)(param_2 + 0xc0);
      func_0x(lVar6 + 0x98,uVar4);
      if ((_DAT_ != 0) && ((DAT_ >> 1 & 1) != 0)) {
        func_0x(lVar6,0,uVar4);
      }
      *(uint *)((longlong)plVar7 + 0xc) = *(uint *)((longlong)plVar7 + 0xc) & 0xffff0000;
      **(undefined8 **)(param_2 + 0x610) = 0;
    }
    else {
      func_0x(plVar7);
    }
  }
  *(undefined4 *)(lVar5 + 0x80) = 0xffffffff;
  if (*(int *)(lVar5 + 0x90) != 0) {
    func_0x(*(undefined8 *)(lVar5 + 0x88),*(undefined4 *)(lVar5 + 0x94));
    *(undefined4 *)(lVar5 + 0x90) = 0;
  }
  *(undefined4 *)(param_2 + 0x118) = 0;
  *(undefined2 *)(param_2 + 0x11c) = 0;
  *(undefined4 *)(lVar5 + 0x9c) = 0;
  *(undefined2 *)(lVar5 + 0xa0) = 0;
  *(undefined4 *)(param_2 + 0x6a8) = 0;
  *(undefined4 *)(param_2 + 0x6ac) = 0;
  *(undefined2 *)(param_2 + 0x6b0) = 0;
  *(undefined8 *)(lVar5 + 0xbc) = *(undefined8 *)(param_2 + 0x6a8);
  *(undefined2 *)(lVar5 + 0xc4) = 0;
  *(undefined4 *)(lVar5 + 0xd0) = 2;
LAB_:
  uVar13 = (*_DAT_)(param_2 + 0x9c8);
  (*_DAT_)(uVar13);
  (*_DAT_)(param_2 + 0x9c8);
  return 0xfffffffffefbefa4;
}

