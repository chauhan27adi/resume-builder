
undefined8 FUN_(longlong param_1,ushort param_2,int *param_3)

{
  short *psVar1;
  code *pcVar2;
  uint uVar3;
  undefined8 uVar4;
  uint uVar5;
  int iVar6;
  char *pcVar7;
  ushort uVar8;
  byte *pbVar9;
  longlong lVar10;
  ushort uVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  int iVar15;
  byte *pbVar16;
  longlong lVar17;
  ulonglong uVar18;
  longlong lVar19;
  
  uVar11 = *(ushort *)(param_1 + 0x1c);
  pbVar16 = *(byte **)(param_1 + 6);
  pbVar9 = pbVar16 + uVar11;
  if (*(short *)(param_1 + 0x24) == 1) {
    uVar3 = *(uint *)(param_1 + 2);
    uVar8 = (*(ushort *)(pbVar9 + 3) & 0x7fff) + uVar11 + *(short *)(param_1 + 0x22);
    iVar13 = (uint)uVar8 - (uint)uVar11;
    if (uVar8 != uVar3) {
      func_0x(pbVar9,pbVar16 + uVar8,uVar3 - uVar8);
      uVar3 = *(uint *)(param_1 + 2);
      uVar11 = *(ushort *)(param_1 + 0x1c);
      pbVar16 = *(byte **)(param_1 + 6);
    }
    *(uint *)(param_1 + 2) = uVar3 - iVar13;
    *(undefined4 *)(param_1 + 0x1e) = 0;
    *(undefined2 *)(param_1 + 0x22) = 0;
    if (*(int *)(param_1 + 0x2e) != 0) {
      *(int *)(param_1 + 0x2e) = *(int *)(param_1 + 0x2e) - iVar13;
    }
    *param_3 = *param_3 + ((uint)uVar11 - (uint)uVar8);
    *pbVar16 = *pbVar16 & 0xdf;
  }
  else {
    uVar3 = func_0x();
    uVar18 = (ulonglong)*(ushort *)(param_1 + 0x1c);
    lVar17 = *(longlong *)(param_1 + 6);
    uVar8 = 0;
    uVar11 = *(ushort *)(uVar18 + lVar17 + 3 + (ulonglong)uVar3 * 2) & 0x7fff;
    if (uVar3 != 0) {
      uVar8 = *(ushort *)(uVar18 + lVar17 + 3 + (ulonglong)(uVar3 - 1) * 2) & 0x7fff;
    }
    if (uVar11 < uVar8) {
      func_0x(lVar17,0x13);
      uVar18 = (ulonglong)*(ushort *)(param_1 + 0x1c);
      lVar17 = *(longlong *)(param_1 + 6);
    }
    uVar14 = *(uint *)(param_1 + 2);
    uVar12 = (uint)uVar11 - (uint)uVar8;
    uVar11 = (ushort)uVar18;
    lVar19 = (ulonglong)uVar8 + uVar18 + lVar17 + (ulonglong)*(ushort *)(param_1 + 0x22);
    lVar10 = (ulonglong)uVar12 + lVar19;
    uVar5 = (int)lVar10 - (int)lVar17 & 0xffff;
    if (uVar5 != uVar14) {
      func_0x(lVar19,lVar10,uVar14 - uVar5);
      uVar14 = *(uint *)(param_1 + 2);
      uVar11 = *(ushort *)(param_1 + 0x1c);
      lVar17 = *(longlong *)(param_1 + 6);
    }
    iVar13 = *param_3;
    iVar15 = uVar14 - uVar12;
    iVar6 = *(int *)(param_1 + 0x2e);
    *(int *)(param_1 + 2) = iVar15;
    if (iVar6 != 0) {
      iVar6 = iVar6 - uVar12;
      *(int *)(param_1 + 0x2e) = iVar6;
    }
    uVar8 = (short)uVar3 * 2 + *(short *)(param_1 + 0x1e) + uVar11;
    if (iVar15 != uVar8 + 2) {
      func_0x
                ((ulonglong)uVar8 + lVar17,(ulonglong)uVar8 + lVar17 + 2,(iVar15 - (uint)uVar8) + -2
                );
      iVar15 = *(int *)(param_1 + 2);
      iVar6 = *(int *)(param_1 + 0x2e);
    }
    *(int *)(param_1 + 2) = iVar15 + -2;
    *(short *)(param_1 + 0x20) = *(short *)(param_1 + 0x20) + -2;
    *(short *)(param_1 + 0x22) = *(short *)(param_1 + 0x22) + -2;
    if (iVar6 != 0) {
      *(int *)(param_1 + 0x2e) = iVar6 + -2;
    }
    psVar1 = (short *)((ulonglong)uVar11 + lVar17 + 1);
    *psVar1 = *psVar1 + -1;
    *param_3 = (iVar13 - uVar12) + -2;
    if (uVar3 < *(ushort *)(pbVar9 + 1)) {
      pcVar2 = (code *)swi(3);
      uVar4 = (*pcVar2)();
      return uVar4;
    }
    if ((*(ushort *)(param_1 + 0x18) != 0) &&
       (uVar3 = (int)(param_2 - 1) / 0x1e, (ushort)uVar3 < *(ushort *)(param_1 + 0x18))) {
      pcVar7 = (char *)((ulonglong)*(ushort *)(param_1 + 0x20) + (ulonglong)(uVar3 & 0xffff) +
                        (ulonglong)*(ushort *)(param_1 + 0x1c) + *(longlong *)(param_1 + 6));
      *pcVar7 = *pcVar7 + -1;
    }
  }
  *(short *)(param_1 + 0x24) = *(short *)(param_1 + 0x24) + -1;
  pbVar9 = (byte *)((longlong)((int)(param_2 - 1) / 2) + (ulonglong)*(ushort *)(param_1 + 0x16) +
                   *(longlong *)(param_1 + 6));
  if ((param_2 & 1) != 0) {
    *pbVar9 = *pbVar9 & 0xf1 | 1;
    return 1;
  }
  *pbVar9 = *pbVar9 & 0xf | 0x10;
  return 1;
}

