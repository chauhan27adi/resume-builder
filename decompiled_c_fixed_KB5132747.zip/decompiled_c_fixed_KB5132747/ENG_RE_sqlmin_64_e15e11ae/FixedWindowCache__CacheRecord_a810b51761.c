
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong *param_2,longlong param_3,undefined8 *param_4)

{
  uint *puVar1;
  ushort uVar2;
  undefined4 uVar3;
  ushort *puVar4;
  byte bVar5;
  bool bVar6;
  short *psVar7;
  uint *puVar8;
  undefined8 *puVar9;
  char cVar10;
  short sVar11;
  ushort uVar12;
  ushort uVar13;
  undefined2 uVar14;
  undefined4 uVar15;
  longlong lVar16;
  longlong lVar17;
  undefined8 uVar18;
  undefined4 *puVar19;
  byte *pbVar20;
  longlong *plVar21;
  undefined uVar22;
  int iVar23;
  ulonglong uVar24;
  uint uVar25;
  longlong lVar26;
  uint *puVar27;
  undefined *puVar28;
  undefined *puVar29;
  undefined *puVar30;
  uint uVar31;
  int *piVar32;
  ushort *puVar33;
  short *psVar34;
  uint uVar35;
  uint uVar36;
  ulonglong uVar37;
  ulonglong uVar38;
  uint uVar39;
  longlong *plVar40;
  byte bVar41;
  int iVar42;
  ushort *puVar43;
  undefined8 uStack_310;
  undefined auStack_308 [80];
  longlong lStack_2b8;
  short *psStack_2b0;
  uint *puStack_2a8;
  undefined uStack_2a0;
  uint uStack_29c;
  int iStack_298;
  uint uStack_294;
  uint uStack_290;
  int *piStack_288;
  uint uStack_280;
  undefined auStack_27c [4];
  int *piStack_278;
  longlong *plStack_270;
  longlong *plStack_268;
  uint *puStack_260;
  uint uStack_258;
  uint uStack_254;
  longlong lStack_250;
  longlong lStack_248;
  undefined8 uStack_240;
  undefined4 uStack_238;
  longlong lStack_230;
  undefined *puStack_218;
  undefined8 uStack_210;
  longlong lStack_208;
  int iStack_200;
  int iStack_1f8;
  uint uStack_1f4;
  undefined4 uStack_1f0;
  undefined2 uStack_1ec;
  undefined2 uStack_1ea;
  longlong lStack_1e8;
  int iStack_1e0;
  undefined8 *puStack_1d8;
  undefined auStack_1d0 [4];
  undefined auStack_1cc [4];
  undefined auStack_1c8 [8];
  undefined auStack_1c0 [8];
  undefined auStack_1b8 [4];
  short sStack_1b4;
  ushort uStack_1b2;
  longlong lStack_1b0;
  longlong lStack_1a8;
  undefined8 uStack_190;
  undefined auStack_188 [16];
  undefined auStack_178 [16];
  undefined auStack_168 [64];
  undefined auStack_128 [224];
  ulonglong uStack_48;
  
  puVar28 = auStack_308;
  uStack_190 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&lStack_2b8;
  lVar26 = ((*param_1 + -1) % (longlong)*(int *)(param_1 + 1)) * 0x50 + param_1[2];
  *param_1 = *param_1 + 1;
  puStack_1d8 = param_4;
  if (*(longlong *)(lVar26 + 0x10) != 0) {
    lStack_208 = 0;
    iStack_200 = 0;
    *(undefined8 *)(lVar26 + 0x10) = 0;
    *(undefined8 *)(lVar26 + 8) = 0xffff;
    *(undefined8 *)(lVar26 + 0x20) = 0;
    *(undefined8 *)(lVar26 + 0x28) = 0;
    *(undefined8 *)(lVar26 + 0x18) = 0;
    *(undefined4 *)(lVar26 + 0x38) = 0;
    *(undefined8 *)(lVar26 + 0x30) = 0;
    uStack_310 = 0x1000bf;
    func_0x(&lStack_208,param_4);
    lVar17 = lStack_208;
    uStack_310 = 0x1000cf;
    func_0x(*(undefined8 *)(lStack_208 + 8));
    uStack_310 = 0x1000db;
    func_0x(*(undefined8 *)(lVar17 + 8),0xffffffffffffffff);
    if (iStack_200 != 0) {
      uStack_310 = 0x1000f8;
      func_0x(*(longlong *)(lVar17 + 8) + 0x630,2);
      iStack_200 = 0;
    }
    lStack_208 = 0;
  }
  iVar23 = 0;
  uStack_310 = 0x10011a;
  func_0x(auStack_168);
  lStack_1e8 = 0;
  iStack_1e0 = 0;
  uStack_254 = 0;
  uStack_240 = 0;
  uStack_238 = 0;
  uStack_310 = 0x100143;
  func_0x(auStack_1b8);
  lVar17 = param_4[1];
  bVar41 = *(byte *)(lVar17 + 0x106) & 1;
  puVar29 = auStack_308;
  uVar31 = uStack_254;
  if (param_2 == (longlong *)0x0) goto LAB_;
  if ((*(int *)(param_4 + 5) == *(int *)(param_2 + 1)) &&
     (*param_2 == (ulonglong)*(uint6 *)((longlong)param_4 + 0x14) * 0x10000)) {
    uStack_310 = 0x100191;
    sVar11 = (**(code **)*param_4)(param_4);
    if (*(short *)((longlong)param_2 + 0xc) != sVar11) goto LAB_;
    if (param_2[0x15] != 0) {
      LOCK();
      UNLOCK();
    }
  }
  else {
LAB_:
    uStack_310 = 0x1001b3;
    func_0x(param_2,param_4);
  }
  uVar12 = *(ushort *)(param_2 + 7);
  uVar13 = *(ushort *)((longlong)param_2 + 0x62);
  plStack_268 = param_2;
  lStack_250 = param_3;
  if ((uVar12 >> 10 & 1) == 0) {
    lStack_248 = 0;
    uStack_210 = 0;
    puStack_260 = (uint *)param_2[0xe];
    lVar17 = param_4[1];
    uStack_240 = *(undefined8 *)(**(longlong **)(lVar17 + 0x160) + 0xa8);
    uStack_238 = *(undefined4 *)(**(longlong **)(lVar17 + 0x160) + 0xb0);
    puVar29 = auStack_308;
    uStack_258 = (uint)uVar13;
    uVar31 = uStack_254 | 0x10;
    goto LAB_;
  }
  if (uVar13 == 0) {
    uVar13 = 0;
    piVar32 = (int *)0x0;
    plVar40 = (longlong *)0x0;
  }
  else {
    iVar23 = (uint)uVar13 * 8;
    uStack_310 = 0x10023b;
    lVar17 = func_0x();
    lVar17 = -lVar17;
    piStack_288 = (int *)((longlong)&lStack_2b8 + lVar17);
    *(undefined8 *)(auStack_308 + lVar17 + -8) = 0x10025c;
    lVar16 = func_0x();
    lVar16 = -lVar16;
    puVar28 = auStack_308 + lVar16 + lVar17;
    plVar40 = (longlong *)((longlong)&lStack_2b8 + lVar16 + lVar17);
    uVar2 = *(ushort *)(param_2 + 0xb);
    uVar31 = *(uint *)((longlong)param_2 + 0x54);
    uVar35 = 0x1f9e;
    plStack_270 = plVar40;
    if (uVar31 < 0x1f9f) {
LAB_:
      piVar32 = piStack_288;
      param_4 = puStack_1d8;
      uVar35 = uVar31;
      if (uVar31 == 0) goto LAB_;
    }
    else if (0x1f9d < uVar2) {
      uVar31 = (uint)uVar2;
      goto LAB_;
    }
    puStack_218 = auStack_1b8;
    *(undefined8 *)(auStack_308 + lVar16 + lVar17 + -8) = 0x1002a4;
    func_0x(auStack_1b8);
    uVar24 = (ulonglong)uVar35 + 0xf;
    if (uVar24 <= uVar35) {
      uVar24 = 0xffffffffffffff0;
    }
    uVar24 = uVar24 & 0xfffffffffffffff0;
    *(undefined8 *)(auStack_308 + lVar16 + lVar17 + -8) = 0x1002c5;
    func_0x();
    puVar28 = auStack_308 + -uVar24 + lVar16 + lVar17;
    lStack_1b0 = (longlong)&lStack_2b8 + -uVar24 + lVar16 + lVar17;
    sStack_1b4 = (short)uVar35 - uVar2;
    uVar13 = *(ushort *)((longlong)param_2 + 0x62);
    uVar12 = *(ushort *)(param_2 + 7);
    piVar32 = piStack_288;
    plVar40 = plStack_270;
    param_4 = puStack_1d8;
    uStack_1b2 = uVar2;
  }
LAB_:
  uVar35 = (uint)uVar13;
  lStack_248 = 0;
  uStack_210 = 0;
  puStack_260 = (uint *)param_2[0xe];
  lVar17 = param_4[1];
  uStack_240 = *(undefined8 *)(**(longlong **)(lVar17 + 0x160) + 0xa8);
  uStack_238 = *(undefined4 *)(**(longlong **)(lVar17 + 0x160) + 0xb0);
  puVar29 = puVar28;
  uStack_258 = uVar35;
  uVar31 = uStack_254 | 0x10;
  if (((uVar12 >> 10 & 1) != 0) && (param_3 != 0)) {
    uStack_254 = uStack_254 | 0x14;
    *(int *)(puVar28 + 0x30) = iVar23;
    *(longlong **)(puVar28 + 0x28) = plVar40;
    *(int *)(puVar28 + 0x20) = iVar23;
    *(undefined8 *)(puVar28 + -8) = 0x100395;
    func_0x(&plStack_268,param_4,uVar35,piVar32);
    lVar17 = param_4[1];
    uVar31 = uStack_254;
  }
LAB_:
  uStack_254 = uVar31;
  plVar40 = (longlong *)0x0;
  psVar34 = (short *)(lVar26 + 8);
  uVar31 = *(uint *)(lVar26 + 0x48);
  uVar18 = *(undefined8 *)(lVar26 + 0x40);
  uVar35 = *(uint *)(lVar17 + 0xb0);
  if ((*(int *)(lVar17 + 0x100) == 0) || (*(int *)(lVar17 + 0x100) - 3U < 2)) {
    bVar6 = false;
  }
  else {
    bVar6 = true;
  }
  puVar30 = puVar29;
  psStack_2b0 = psVar34;
  uStack_29c = uVar35;
  uStack_294 = uVar31;
  if ((*(byte *)(plStack_268 + 7) & 0x20) == 0) {
    if (bVar6) {
      plVar21 = plVar40;
      if ((uStack_254 & 0x10) != 0) {
        plVar21 = plStack_268;
      }
      uVar36 = -*(int *)(plVar21 + 2);
      uVar15 = *(undefined4 *)(plVar21 + 3);
      uVar3 = *(undefined4 *)((longlong)plVar21 + 0x14);
      uStack_290 = uVar36;
      *(undefined2 *)(puVar29 + 0x28) = 1;
      *(undefined4 *)(puVar29 + 0x20) = uVar15;
      if (bVar41 == 0) {
        *(undefined8 *)(puVar29 + -8) = 0x10234e;
        func_0x(psVar34,uVar18,uVar31,uVar3);
      }
      else {
        *(undefined8 *)(puVar29 + -8) = 0x102347;
        func_0x();
      }
      if (uVar36 != 0) {
        *(undefined8 *)(puVar29 + -8) = 0x102378;
        lVar26 = func_0x();
        lVar26 = -lVar26;
        puVar30 = puVar29 + lVar26;
        plVar40 = (longlong *)(puVar29 + lVar26 + 0x50);
        *(undefined8 *)(puVar29 + lVar26 + -8) = 0x10238a;
        func_0x(plVar40,0);
      }
      puStack_2a8 = (uint *)0x0;
      if (*(ushort *)((longlong)plStack_268 + 0x62) != 0) {
        puVar27 = puStack_260 + 0xe;
        uVar24 = (ulonglong)*(ushort *)((longlong)plStack_268 + 0x62);
        do {
          puVar1 = puVar27 + -0xe;
          uVar31 = *puVar1;
          *(undefined8 *)(puVar30 + -8) = 0x1023c8;
          func_0x(&plStack_268,puVar1,&lStack_2b8);
          if ((char)lStack_2b8 == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar27 + 4) + 0xc) & 0x400) == 0) &&
               ((puVar27[2] & 0x4000) == 0)) {
              *(undefined8 *)(puVar30 + -8) = 0x1026ad;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar30 + -8) = 0x1026be;
            func_0x(psVar34,puVar1,0,0);
            if ((int)uVar31 < 0) {
              puVar1 = (uint *)((longlong)(int)~uVar31 * 0x20 + 0xc + (longlong)plVar40);
              *puVar1 = *puVar1 | 2;
            }
          }
          else {
            if (*(short *)(puVar27 + -0xd) != 0) {
              if (*psVar34 == 0) {
                *(undefined8 *)(puVar30 + -8) = 0x1023eb;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar30 + -8) = 0x1023f2;
                func_0x(psVar34 + 1,puVar1);
              }
            }
            *(undefined8 *)(puVar30 + -8) = 0x102402;
            func_0x(&plStack_268,puVar1,&puStack_2a8);
            puVar8 = puStack_2a8;
            cVar10 = *(char *)(puVar27 + 2);
            if ((cVar10 == '\x01') || (cVar10 == '\x02')) {
              if ((puVar27[2] >> 8 & 1) == 0) {
                uVar31 = *puVar1;
                lVar26 = *(longlong *)(psVar34 + 4);
                uVar14 = *(undefined2 *)(puVar27 + 1);
                *(undefined8 *)(puVar30 + -8) = 0x102578;
                func_0x((int)uVar31 + lVar26,puVar8,uVar14);
              }
              else {
                if (((puVar27[2] >> 0xf & 1) == 0) || ((uStack_254 & 8) == 0)) {
                  lVar26 = lStack_250;
                  if ((*(byte *)(*(longlong *)(puVar27 + 4) + 0x2a) & 0x10) != 0) {
                    lVar26 = lStack_248;
                  }
                  uVar31 = *(uint *)(*(longlong *)(*(longlong *)(puVar27 + 4) + 0x18) + lVar26);
                }
                else {
                  uVar31 = *(uint *)(lStack_230 + (ulonglong)*puVar27 * 8);
                }
                uVar35 = (uint)*(ushort *)(puVar27 + 1);
                if (uVar31 < uVar35) {
                  iVar23 = uVar35 - uVar31;
                }
                else {
                  iVar23 = 0;
                  if (uVar35 < uVar31) {
                    *(undefined8 *)(puVar30 + -8) = 0x1025dc;
                    (*_DAT_)(6,0x5c,0x16);
                    iVar23 = 0;
                  }
                }
                uStack_2a0 = *(undefined *)(*(longlong *)(puVar27 + 4) + 0x24);
                uVar35 = *puVar1;
                lVar26 = *(longlong *)(psStack_2b0 + 4);
                if ((puVar8 != (uint *)0x0) && (uVar31 != 0)) {
                  *(undefined8 *)(puVar30 + -8) = 0x102609;
                  func_0x((int)uVar35 + lVar26,puVar8,uVar31);
                }
                uVar22 = uStack_2a0;
                psVar34 = psStack_2b0;
                if (iVar23 != 0) {
                  *(undefined8 *)(puVar30 + -8) = 0x102622;
                  func_0x((ulonglong)uVar31 + (int)uVar35 + lVar26,uVar22,iVar23);
                  psVar34 = psStack_2b0;
                }
              }
            }
            else if ((cVar10 == '\x03') || (cVar10 == '\x04')) {
              uVar35 = puVar27[2];
              if (((uVar35 >> 0xd & 1) == 0) || (*puStack_2a8 != 0)) {
                if (((uVar35 & 0x8000) == 0) || ((uStack_254 & 8) == 0)) {
                  lVar26 = *(longlong *)(puVar27 + 4);
                  if ((uVar35 >> 8 & 1) == 0) {
                    uVar35 = (uint)*(ushort *)(lVar26 + 2);
                  }
                  else {
                    lVar17 = lStack_250;
                    if ((*(byte *)(lVar26 + 0x2a) & 0x10) != 0) {
                      lVar17 = lStack_248;
                    }
                    uVar35 = *(uint *)(*(longlong *)(lVar26 + 0x18) + lVar17);
                  }
                }
                else {
                  uVar35 = *(uint *)(lStack_230 + (ulonglong)*puVar27 * 8);
                }
              }
              else {
                uVar35 = 0;
              }
              if (*(ushort *)(puVar27 + 1) < uVar35) {
                *(undefined8 *)(puVar30 + -8) = 0x102522;
                (*_DAT_)(6,0x52,0x16);
              }
              puVar8 = puStack_2a8;
              *(undefined4 *)(puVar30 + 0x28) = 0;
              *(uint **)(puVar30 + 0x20) = puVar1;
              *(undefined8 *)(puVar30 + -8) = 0x10254e;
              func_0x(plVar40 + (longlong)(int)~uVar31 * 4,puVar8,uVar35);
              psVar34 = psStack_2b0;
            }
            else if (cVar10 == '\b') {
              if (*psVar34 == 0) {
                *(undefined8 *)(puVar30 + -8) = 0x10247a;
                func_0x(psVar34,puVar1,puVar8);
              }
              else {
                *(undefined4 *)(puVar30 + 0x28) = 0;
                *(uint **)(puVar30 + 0x20) = puVar1;
                puVar1 = puStack_2a8;
                *(undefined8 *)(puVar30 + -8) = 0x1024a9;
                func_0x(plVar40 + (longlong)(int)~uVar31 * 4,puVar1,1);
              }
            }
            else {
              *(undefined8 *)(puVar30 + 0x20) = 0x787590;
              *(undefined8 *)(puVar30 + -8) = 0x10245a;
              (*_DAT_)(1,0xb8d920,0xbba2e8);
            }
          }
          puVar27 = puVar27 + 0x14;
          uVar24 = uVar24 - 1;
          uVar35 = uStack_29c;
          uVar36 = uStack_290;
        } while (uVar24 != 0);
      }
      uVar31 = uStack_294;
      psVar7 = psStack_2b0;
      puVar33 = (ushort *)0x0;
      if (uVar36 != 0) {
        if (*psVar34 == 0) {
          do {
            uVar24 = (ulonglong)uVar36;
            uVar35 = uVar36 - 1;
            if (*(int *)(plVar40 + (ulonglong)uVar35 * 4 + 1) != 0) {
              psVar34[0xe] = (ushort)uVar36;
              iVar23 = *(int *)(psVar34 + 10) + 2 + uVar36 * 2;
              *(int *)(psVar34 + 0xc) = iVar23;
              *(int *)(psVar34 + 2) = iVar23;
              **(byte **)(psVar34 + 4) = **(byte **)(psVar34 + 4) | 0x20;
              if (*(uint *)(psVar34 + 2) <= uStack_29c) {
                puVar33 = (ushort *)
                          ((ulonglong)*(uint *)(psVar34 + 10) + *(longlong *)(psVar34 + 4));
                *puVar33 = (ushort)uVar36;
              }
              if (uVar36 != 0) {
                puVar27 = (uint *)((longlong)plVar40 + 0xc);
                uVar35 = uStack_29c;
                do {
                  puVar33 = puVar33 + 1;
                  uVar39 = *(uint *)(psVar7 + 2);
                  lVar26 = *(longlong *)(psVar7 + 4);
                  uVar25 = puVar27[-1];
                  uVar36 = uVar39 + uVar25;
                  *(uint *)(psVar7 + 2) = uVar36;
                  if ((uVar36 <= uVar35) && (uVar36 <= uVar31)) {
                    *puVar33 = (ushort)((*puVar27 & 1) << 0xf) | (ushort)uVar36 & 0x7fff;
                    uVar18 = *(undefined8 *)(puVar27 + -3);
                    *(undefined8 *)(puVar30 + -8) = 0x102771;
                    func_0x((ulonglong)uVar39 + lVar26,uVar25,uVar18,uVar25);
                    uVar35 = uStack_29c;
                  }
                  puVar27 = puVar27 + 8;
                  uVar24 = uVar24 - 1;
                } while (uVar24 != 0);
              }
              break;
            }
            uVar36 = uVar35;
          } while (uVar35 != 0);
        }
        else {
          *(undefined **)(puVar30 + 0x28) = auStack_27c;
          *(longlong **)(puVar30 + 0x20) = plVar40;
          uVar31 = uStack_294;
          *(undefined8 *)(puVar30 + -8) = 0x1027a4;
          func_0x(psVar34 + 1,uVar31,uVar35,uVar36);
        }
      }
    }
    else {
      *psVar34 = 0;
      puVar33 = (ushort *)(lVar26 + 10);
      plStack_270 = (longlong *)0x0;
      plVar21 = (longlong *)0x0;
      if ((uStack_254 & 0x10) != 0) {
        plVar21 = plStack_268;
      }
      uVar35 = -*(int *)(plVar21 + 2);
      uVar22 = 0;
      if (bVar41 == 0) {
        uVar22 = 6;
      }
      iVar23 = 4;
      if (bVar41 == 0) {
        iVar23 = 1;
      }
      iVar42 = *(int *)((longlong)plVar21 + 0x14);
      uStack_290 = uVar35;
      puVar29[0x28] = uVar22;
      *(undefined4 *)(puVar29 + 0x20) = *(undefined4 *)(plVar21 + 3);
      *(undefined8 *)(puVar29 + -8) = 0x10044f;
      func_0x(puVar33,uVar18,uVar31,iVar42 - iVar23);
      if (uVar35 != 0) {
        *(undefined8 *)(puVar29 + -8) = 0x100477;
        lVar17 = func_0x();
        lVar17 = -lVar17;
        puVar30 = puVar29 + lVar17;
        plVar40 = (longlong *)(puVar29 + lVar17 + 0x50);
        plStack_270 = plVar40;
        *(undefined8 *)(puVar29 + lVar17 + -8) = 0x10048d;
        func_0x(plVar40,0);
      }
      uStack_1f4 = (uint)*(ushort *)((longlong)plStack_268 + 0x62);
      piStack_278 = (int *)0x0;
      uStack_280 = 0;
      puStack_2a8 = puStack_260;
      puVar27 = puStack_260;
      if (uStack_1f4 != 0) {
        do {
          uVar31 = *puVar27;
          puStack_2a8 = puVar27;
          *(undefined8 *)(puVar30 + -8) = 0x1004d4;
          func_0x(&plStack_268,puVar27,&lStack_2b8);
          if ((char)lStack_2b8 == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar27 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar27[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar30 + -8) = 0x10223e;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar30 + -8) = 0x10224f;
            func_0x(puVar33,puVar27,0,0);
            puStack_2a8 = puVar27;
            if ((int)uVar31 < 0) {
              puVar1 = (uint *)((longlong)(int)~uVar31 * 0x20 + 0xc + (longlong)plVar40);
              *puVar1 = *puVar1 | 2;
            }
          }
          else {
            if (*(short *)(puVar27 + 1) != 0) {
              *(undefined8 *)(puVar30 + -8) = 0x1004f2;
              func_0x(puVar33,puVar27);
            }
            *(undefined8 *)(puVar30 + -8) = 0x100502;
            func_0x(&plStack_268,puVar27,&piStack_278);
            piVar32 = piStack_278;
            cVar10 = *(char *)(puVar27 + 0x10);
            if ((cVar10 == '\x01') || (cVar10 == '\x02')) {
              if ((puVar27[0x10] >> 8 & 1) == 0) {
                uVar31 = *puVar27;
                lVar17 = *(longlong *)(lVar26 + 0x10);
                uVar14 = *(undefined2 *)(puVar27 + 0xf);
                *(undefined8 *)(puVar30 + -8) = 0x10215b;
                func_0x((int)uVar31 + lVar17,piVar32,uVar14);
                puStack_2a8 = puVar27;
              }
              else {
                if (((puVar27[0x10] & 0x8000) == 0) || ((uStack_254 & 8) == 0)) {
                  lVar17 = lStack_250;
                  if ((*(byte *)(*(longlong *)(puVar27 + 0x12) + 0x2a) & 0x10) != 0) {
                    lVar17 = lStack_248;
                  }
                  uVar31 = *(uint *)(*(longlong *)(*(longlong *)(puVar27 + 0x12) + 0x18) + lVar17);
                }
                else {
                  uVar31 = *(uint *)(lStack_230 + (ulonglong)puVar27[0xe] * 8);
                }
                uVar35 = (uint)*(ushort *)(puVar27 + 0xf);
                if (uVar31 < uVar35) {
                  iVar23 = uVar35 - uVar31;
                }
                else {
                  iVar23 = 0;
                  if (uVar35 < uVar31) {
                    *(undefined8 *)(puVar30 + -8) = 0x1021c3;
                    (*_DAT_)(6,0x5c,0x16);
                    iVar23 = 0;
                  }
                }
                uVar22 = *(undefined *)(*(longlong *)(puVar27 + 0x12) + 0x24);
                lVar17 = (longlong)(int)*puStack_2a8 + *(longlong *)(lVar26 + 0x10);
                if ((piVar32 != (int *)0x0) && (uVar31 != 0)) {
                  *(undefined8 *)(puVar30 + -8) = 0x1021ef;
                  func_0x(lVar17,piVar32,uVar31);
                }
                if (iVar23 != 0) {
                  *(undefined8 *)(puVar30 + -8) = 0x102208;
                  func_0x((ulonglong)uVar31 + lVar17,uVar22,iVar23);
                }
              }
            }
            else if ((cVar10 == '\x03') || (cVar10 == '\x04')) {
              uVar35 = puVar27[0x10];
              if (((uVar35 >> 0xd & 1) == 0) || (*piStack_278 != 0)) {
                if (((uVar35 & 0x8000) == 0) || ((uStack_254 & 8) == 0)) {
                  lVar17 = *(longlong *)(puVar27 + 0x12);
                  if ((uVar35 >> 8 & 1) == 0) {
                    uVar35 = (uint)*(ushort *)(lVar17 + 2);
                  }
                  else {
                    lVar16 = lStack_250;
                    if ((*(byte *)(lVar17 + 0x2a) & 0x10) != 0) {
                      lVar16 = lStack_248;
                    }
                    uVar35 = *(uint *)(*(longlong *)(lVar17 + 0x18) + lVar16);
                  }
                }
                else {
                  uVar35 = *(uint *)(lStack_230 + (ulonglong)puVar27[0xe] * 8);
                }
              }
              else {
                uVar35 = 0;
              }
              if (*(ushort *)(puVar27 + 0xf) < uVar35) {
                *(undefined8 *)(puVar30 + -8) = 0x102103;
                (*_DAT_)(6,0x52,0x16);
              }
              piVar32 = piStack_278;
              *(undefined4 *)(puVar30 + 0x28) = 0;
              *(uint **)(puVar30 + 0x20) = puVar27;
              *(undefined8 *)(puVar30 + -8) = 0x10212c;
              func_0x(plVar40 + (longlong)(int)~uVar31 * 4,piVar32,uVar35);
              puStack_2a8 = puVar27;
            }
            else if (cVar10 == '\b') {
              piStack_288 = piStack_278;
              uVar31 = *puVar27;
              lVar17 = (longlong)(int)uVar31;
              if ((int)uVar31 < 0) {
                if ((uVar31 & 0xc0000000) == 0x80000000) {
                  *(undefined8 *)(puVar30 + -8) = 0x101716;
                  func_0x(auStack_128);
                  iVar23 = 0;
                  iStack_298 = 0;
                  if (*(int *)(lVar26 + 0xc) == 0) {
                    *puVar33 = 0;
                    uVar31 = *(uint *)(lVar26 + 0x18);
                    uVar24 = (ulonglong)uVar31;
                    *(uint *)(lVar26 + 0x1c) = uVar31;
                    pbVar20 = *(byte **)(lVar26 + 0x10);
                    bVar41 = *pbVar20;
                    if ((bVar41 & 0x10) != 0) {
                      uVar31 = uVar31 + (*(ushort *)(pbVar20 + uVar24) + 7 >> 3) + 2;
                      uVar24 = (ulonglong)uVar31;
                      *(uint *)(lVar26 + 0x1c) = uVar31;
                      bVar41 = *pbVar20;
                    }
                    if ((bVar41 & 0x20) == 0) {
                      *(int *)(lVar26 + 0xc) = (int)uVar24;
                      *(undefined2 *)(lVar26 + 0x24) = 0;
                      *(int *)(lVar26 + 0x20) = (int)uVar24;
                    }
                    else {
                      puVar43 = (ushort *)(pbVar20 + uVar24);
                      uVar12 = *puVar43;
                      *(ushort *)(lVar26 + 0x24) = uVar12;
                      if (uVar12 == 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x101785;
                        cVar10 = func_0x(0x111c620);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar30 + -8) = 0x10178e;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar30 + -8) = 0x1017a8;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x1017c4;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar30 + 0x20) = 0;
                              *(undefined8 *)(puVar30 + -8) = 0x1017ea;
                              (*_DAT_)(1,0xa0c02c,0xb2c118,0x80f);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(lVar26 + 0x10);
                        *(undefined8 *)(puVar30 + -8) = 0x1017f8;
                        func_0x(uVar18,3);
                        uVar24 = (ulonglong)*(uint *)(lVar26 + 0x1c);
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                        uVar12 = *(ushort *)(lVar26 + 0x24);
                      }
                      uVar31 = (int)uVar24 + (uVar12 + 1) * 2;
                      *(uint *)(lVar26 + 0x20) = uVar31;
                      if (0x1f9e < uVar31) {
                        *(undefined8 *)(puVar30 + -8) = 0x101829;
                        cVar10 = func_0x(0x111c620);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar30 + -8) = 0x101832;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar30 + -8) = 0x10184c;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x101868;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar30 + 0x20) = 0;
                              *(undefined8 *)(puVar30 + -8) = 0x10188e;
                              (*_DAT_)(1,0xa0c02c,0xb2c118,0x816);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(lVar26 + 0x10);
                        *(undefined8 *)(puVar30 + -8) = 0x10189c;
                        func_0x(uVar18,4);
                        uVar12 = *(ushort *)(lVar26 + 0x24);
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                        uVar31 = *(uint *)(lVar26 + 0x20);
                      }
                      uVar24 = (ulonglong)uVar12;
                      uVar35 = puVar43[uVar24] & 0x7fff;
                      *(uint *)(lVar26 + 0xc) = uVar35;
                      if (uVar35 < uVar31) {
                        *(undefined8 *)(puVar30 + -8) = 0x1018cb;
                        cVar10 = func_0x(0x111c620);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar30 + -8) = 0x1018d4;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar30 + -8) = 0x1018ee;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x10190a;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar30 + 0x20) = 0;
                              *(undefined8 *)(puVar30 + -8) = 0x101930;
                              (*_DAT_)(1,0xa0c02c,0xb2c118,0x81d);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(lVar26 + 0x10);
                        *(undefined8 *)(puVar30 + -8) = 0x10193e;
                        func_0x(uVar18,4);
                        uVar31 = *(uint *)(lVar26 + 0x20);
                        uVar24 = (ulonglong)*(ushort *)(lVar26 + 0x24);
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                        uVar35 = *(uint *)(lVar26 + 0xc);
                      }
                      puVar4 = puVar43;
                      iVar42 = iVar23;
                      if ((short)uVar24 != 0) {
                        do {
                          uVar36 = puVar4[1] & 0x7fff;
                          if ((uVar36 < uVar31) ||
                             (uVar35 = *(uint *)(lVar26 + 0xc), uVar35 < uVar36)) {
                            *(undefined8 *)(puVar30 + -8) = 0x101981;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x10198a;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x1019a4;
                                cVar10 = func_0x(0x111c620);
                                if (cVar10 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x1019c0;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x1019e6;
                                  (*_DAT_)(1,0xa0c02c,0xb2c118,0x82a);
                                }
                              }
                            }
                            uVar18 = *(undefined8 *)(lVar26 + 0x10);
                            *(undefined8 *)(puVar30 + -8) = 0x1019f4;
                            func_0x(uVar18,4);
                            uVar35 = *(uint *)(lVar26 + 0xc);
                          }
                          iVar42 = iVar42 + 1;
                          uVar24 = (ulonglong)*(ushort *)(lVar26 + 0x24);
                          uVar31 = uVar36;
                          puVar4 = puVar4 + 1;
                        } while (iVar42 < (int)(uint)*(ushort *)(lVar26 + 0x24));
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                      }
                      uVar37 = uVar24;
                      if ((short)puVar43[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                        do {
                          sVar11 = (short)uVar37;
                          uVar31 = *(ushort *)
                                    (pbVar20 + uVar24 * 2 + (ulonglong)*(uint *)(lVar26 + 0x1c)) &
                                   0x7fff;
                          if ((int)uVar24 == 1) {
                            uVar35 = *(uint *)(lVar26 + 0x20);
                            uVar36 = uVar35;
LAB_:
                            if ((uVar31 < uVar35) ||
                               (uVar39 = *(uint *)(lVar26 + 0xc), uVar39 < uVar31))
                            goto LAB_;
                          }
                          else {
                            uVar35 = *(ushort *)
                                      (pbVar20 +
                                      uVar24 * 2 + ((ulonglong)*(uint *)(lVar26 + 0x1c) - 2)) &
                                     0x7fff;
                            uVar36 = *(uint *)(lVar26 + 0x20);
                            if (uVar36 <= uVar35) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar30 + -8) = 0x101a79;
                            func_0x(pbVar20,7);
                            uVar36 = *(uint *)(lVar26 + 0x20);
                            uVar39 = *(uint *)(lVar26 + 0xc);
                            pbVar20 = *(byte **)(lVar26 + 0x10);
                            sVar11 = *(short *)(lVar26 + 0x24);
                          }
                          if ((uVar35 < uVar36) || (uVar39 < uVar35)) goto LAB_;
                          if (*(ushort *)(pbVar20 + uVar35) == 5) {
                            *puVar33 = *puVar33 | 2;
                            *(short *)(lVar26 + 0x24) = sVar11 + -1;
                            uVar37 = (ulonglong)(uVar35 & 0xffff);
                            *(short *)(lVar26 + 0x32) = (short)uVar35;
                            uVar24 = *(ulonglong *)(lVar26 + 0x10);
                            uVar12 = *(ushort *)(uVar24 + 2 + uVar37);
                            uVar13 = *(ushort *)(lVar26 + 0x34) & 0xc7ff;
                            if ((uVar12 >> 0xe & 1) != 0) {
                              uVar13 = uVar12 & 0x3800 | uVar13;
                            }
                            *(ushort *)(lVar26 + 0x34) = uVar13;
                            uVar12 = (uVar13 ^ *(ushort *)(uVar37 + 2 + uVar24)) & 0x7ff ^ uVar13;
                            *(ushort *)(lVar26 + 0x34) = uVar12;
                            uVar38 = (ulonglong)((uVar12 & 0x7ff) * 2) + 4 +
                                     uVar24 + (uVar13 >> 0xb & 7) * 2 + uVar37;
                            if (uVar38 < uVar37 + uVar24) {
                              *(undefined8 *)(puVar30 + -8) = 0x101b87;
                              func_0x(uVar37 + uVar24,0x19);
                              uVar12 = *(ushort *)(lVar26 + 0x34);
                              uVar37 = (ulonglong)*(ushort *)(lVar26 + 0x32);
                              uVar24 = (ulonglong)*(uint *)(lVar26 + 0x10);
                            }
                            if (uVar31 - uVar35 <
                                (((uVar12 & 0x7ff) * 2 - (int)uVar37) - (int)uVar24) + (int)uVar38)
                            {
                              lVar17 = *(longlong *)(lVar26 + 0x10);
                              *(undefined8 *)(puVar30 + -8) = 0x101bbf;
                              func_0x(uVar37 + lVar17,0x19);
                              uVar12 = *(ushort *)(lVar26 + 0x34);
                            }
                            if (((uVar12 & 0x3800) != 0) &&
                               (puVar43 = (ushort *)
                                          (*(longlong *)(lVar26 + 0x10) + 4 +
                                          (ulonglong)*(ushort *)(lVar26 + 0x32)),
                               (uVar12 & 0x3800) != 0)) {
                              do {
                                if ((uVar12 & 0x7ff) < (*puVar43 & 0x7ff)) {
                                  uVar12 = *(ushort *)(lVar26 + 0x32);
                                  lVar17 = *(longlong *)(lVar26 + 0x10);
                                  *(undefined8 *)(puVar30 + -8) = 0x101c17;
                                  func_0x((ulonglong)uVar12 + lVar17,0x1a);
                                  uVar12 = *(ushort *)(lVar26 + 0x34);
                                }
                                iVar23 = iVar23 + 1;
                                puVar43 = puVar43 + 1;
                              } while (iVar23 < (int)(uVar12 >> 0xb & 7));
                            }
                            uVar35 = *(uint *)(psStack_2b0 + 2);
                            goto LAB_;
                          }
                          if (*(ushort *)(pbVar20 + uVar35) < 0x400) break;
                          *puVar33 = *puVar33 | 1;
                          uVar12 = sVar11 - 1;
                          *(ushort *)(lVar26 + 0x24) = uVar12;
                          if (uVar12 == 0) break;
                          uVar24 = (ulonglong)(uint)uVar12;
                          uVar37 = (ulonglong)uVar12;
                        } while ((short)puVar43[(ulonglong)(uVar12 - 1) + 1] < 0);
                        uVar24 = (ulonglong)uVar39;
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                      }
                      else {
LAB_:
                        uVar24 = (ulonglong)uVar35;
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                      }
                    }
                    if ((*pbVar20 & 0x40) == 0) {
                      *(undefined4 *)(lVar26 + 0x2e) = 0;
                    }
                    else {
                      *(int *)(lVar26 + 0x2e) = (int)uVar24;
                      *(int *)(lVar26 + 0xc) = (int)uVar24 + 0xe;
                      *(undefined8 *)(puVar30 + -8) = 0x101c60;
                      uVar18 = func_0x(puVar33);
                      *(undefined8 *)(puVar30 + -8) = 0x101c6f;
                      func_0x(uVar18,&lStack_208);
                      *(undefined8 *)(puVar30 + -8) = 0x101c7b;
                      iVar23 = func_0x(&lStack_208);
                      *(int *)(lVar26 + 0xc) = *(int *)(lVar26 + 0xc) + iVar23;
                      uVar24 = (ulonglong)*(uint *)(lVar26 + 0xc);
                      pbVar20 = *(byte **)(lVar26 + 0x10);
                    }
                    if ((*(byte **)(lVar26 + 0x26) != (byte *)0x0) &&
                       (*(byte **)(lVar26 + 0x26) < pbVar20 + uVar24)) {
                      *(undefined8 *)(puVar30 + -8) = 0x101cb5;
                      cVar10 = func_0x(0x111c620);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar30 + -8) = 0x101cbe;
                        lVar17 = func_0x();
                        if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar30 + -8) = 0x101cd8;
                          cVar10 = func_0x(0x111c620);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x101cf4;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar30 + 0x20) = 0;
                            *(undefined8 *)(puVar30 + -8) = 0x101d1a;
                            (*_DAT_)(1,0xa0c02c,0xb2c118,0x886);
                          }
                        }
                      }
                      uVar18 = *(undefined8 *)(lVar26 + 0x10);
                      *(undefined8 *)(puVar30 + -8) = 0x101d28;
                      func_0x(uVar18,0x12);
                      uVar24 = (ulonglong)*(uint *)(lVar26 + 0xc);
                    }
                    if (0x3f3b < (int)uVar24 - 1U) {
                      *(undefined8 *)(puVar30 + -8) = 0x101d43;
                      cVar10 = func_0x(0x111c620);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar30 + -8) = 0x101d4c;
                        lVar17 = func_0x();
                        if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar30 + -8) = 0x101d66;
                          cVar10 = func_0x(0x111c620);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x101d82;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar30 + 0x20) = 0;
                            *(undefined8 *)(puVar30 + -8) = 0x101da8;
                            (*_DAT_)(1,0xa0c02c,0xb2c118,0x88b);
                          }
                        }
                      }
                      uVar18 = *(undefined8 *)(lVar26 + 0x10);
                      *(undefined8 *)(puVar30 + -8) = 0x101db6;
                      func_0x(uVar18,5);
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar30 + -8) = 0x101dbe;
                  func_0x(puVar33);
                  bVar41 = **(byte **)(lVar26 + 0x10) >> 6;
                  if ((bVar41 & 1) != 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x101ddf;
                    func_0x(puVar33,auStack_128);
                  }
                  if ((*(byte *)puVar33 & 1) != 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x101df5;
                    puVar19 = (undefined4 *)func_0x(puVar33,0x400,&iStack_298);
                    uStack_1f0 = *puVar19;
                    uStack_1ec = *(undefined2 *)(puVar19 + 1);
                    uStack_1ea = *(undefined2 *)((longlong)puVar19 + 6);
                  }
                  pbVar20 = *(byte **)(lVar26 + 0x10);
                  if ((*pbVar20 & 0x20) == 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x101e24;
                    func_0x(puVar33);
                    pbVar20 = *(byte **)(lVar26 + 0x10);
                  }
                  uVar31 = *(uint *)(lVar26 + 0x1c);
                  *(undefined8 *)(puVar30 + -8) = 0x101e37;
                  iVar23 = func_0x(puVar33);
                  lVar17 = *(longlong *)(lVar26 + 0x10);
                  uVar12 = *(ushort *)(lVar26 + 0x24);
                  uVar24 = (ulonglong)uVar12;
                  puVar43 = (ushort *)(lVar17 + (ulonglong)*(uint *)(lVar26 + 0x1c));
                  uVar35 = (uint)uVar12;
                  if (iVar23 == 0) {
                    uVar39 = *(uint *)(lVar26 + 0x1c) + 2 + (uint)uVar12 * 2;
                    uVar36 = 0;
                    if (*puVar43 != 0) {
                      do {
                        uVar13 = puVar43[(ulonglong)uVar36 + 1];
                        puVar43[(ulonglong)(uVar36 & 0xffff) + 1] =
                             puVar43[(ulonglong)(uVar36 & 0xffff) + 1] & 0x8000;
                        puVar43[(ulonglong)(uVar36 & 0xffff) + 1] =
                             puVar43[(ulonglong)(uVar36 & 0xffff) + 1] |
                             (uVar13 & 0x7fff) + 2 & 0x7fff;
                        uVar36 = uVar36 + 1;
                      } while (uVar36 < *puVar43);
                      lVar17 = *(longlong *)(lVar26 + 0x10);
                    }
                    lVar17 = (ulonglong)uVar39 + lVar17;
                    iVar23 = *(int *)(lVar26 + 0xc);
                    *(undefined8 *)(puVar30 + -8) = 0x101f16;
                    func_0x(lVar17 + 2,lVar17,iVar23 - uVar39);
                    *(int *)(lVar26 + 0xc) = *(int *)(lVar26 + 0xc) + 2;
                    *(int *)(lVar26 + 0x20) = *(int *)(lVar26 + 0x20) + 2;
                    uVar13 = (ushort)*(undefined4 *)(lVar26 + 0x20);
                    if (uVar35 != 0) {
                      uVar13 = puVar43[(ulonglong)(uVar12 - 1) + 1] & 0x7fff;
                    }
                    if (uVar35 < uVar12 + 1) {
                      do {
                        puVar43[(uVar24 & 0xffff) + 1] = uVar13 & 0x7fff;
                        uVar35 = (int)uVar24 + 1;
                        uVar24 = (ulonglong)uVar35;
                      } while (uVar35 < uVar12 + 1);
                    }
                    *puVar43 = *puVar43 + 1;
                    *(undefined8 *)(puVar30 + -8) = 0x101f59;
                    func_0x(puVar33);
                    iVar42 = 0;
                    uVar12 = *(ushort *)
                              (pbVar20 +
                              (ulonglong)*(ushort *)(lVar26 + 0x24) * 2 + (ulonglong)uVar31 + 2);
                    *(undefined8 *)(puVar30 + -8) = 0x101f72;
                    func_0x(auStack_178);
                    *(undefined4 *)(puVar30 + 0x28) = 0;
                    *(uint **)(puVar30 + 0x20) = puStack_2a8;
                    piVar32 = piStack_288;
                    *(undefined8 *)(puVar30 + -8) = 0x101f97;
                    func_0x(auStack_188,piVar32,1);
                    *(int **)(puVar30 + 0x28) = &iStack_1f8;
                    *(undefined **)(puVar30 + 0x20) = auStack_188;
                    *(undefined8 *)(puVar30 + -8) = 0x101fcc;
                    func_0x(lVar26 + 0x32,uVar12 & 0x7fff,0x1f9e);
                    iVar23 = iStack_1f8;
                  }
                  else {
                    if (uVar35 == 0) {
                      uVar35 = *(uint *)(psStack_2b0 + 0xc);
                      uVar36 = puVar43[uVar24 + 1] & 0x7fff;
LAB_:
                      if ((uVar36 < uVar35) || (*(uint *)(lVar26 + 0xc) < uVar36))
                      goto LAB_;
                    }
                    else {
                      uVar35 = puVar43[uVar24] & 0x7fff;
                      uVar36 = puVar43[uVar24 + 1] & 0x7fff;
                      if (*(uint *)(psStack_2b0 + 0xc) <= uVar35) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar30 + -8) = 0x101e8c;
                      func_0x(lVar17,7);
                    }
                    piVar32 = piStack_288;
                    puVar27 = puStack_2a8;
                    iVar42 = uVar36 - uVar35;
                    *(undefined8 *)(puVar30 + -8) = 0x101ea8;
                    iVar23 = func_0x(lVar26 + 0x32,puVar27,piVar32);
                  }
                  iVar42 = (iVar23 - iVar42) + *(int *)(lVar26 + 0xc);
                  *(int *)(lVar26 + 0xc) = iVar42;
                  if ((*(byte *)puVar33 & 1) != 0) {
                    *(ushort *)
                     (pbVar20 + (ulonglong)*(ushort *)(lVar26 + 0x24) * 2 + (ulonglong)uVar31 + 4) =
                         (ushort)iVar42 | 0x8000;
                    iVar42 = (*(int *)(lVar26 + 0xc) - iStack_298) + -2;
                  }
                  *(ushort *)
                   (pbVar20 + (ulonglong)*(ushort *)(lVar26 + 0x24) * 2 + (ulonglong)uVar31 + 2) =
                       (ushort)iVar42 | 0x8000;
                  if (iVar23 == 0) {
                    uVar12 = *(ushort *)(lVar26 + 0x24);
                    *(undefined8 *)(puVar30 + -8) = 0x10201e;
                    func_0x(puVar33,uVar12 + 1);
                    if ((**(byte **)(lVar26 + 0x10) & 0x20) != 0) {
                      *(short *)(lVar26 + 0x24) = *(short *)(lVar26 + 0x24) + 1;
                      *puVar33 = *puVar33 & 0xfffd;
                      *(undefined8 *)(puVar30 + -8) = 0x10203b;
                      func_0x((undefined2 *)(lVar26 + 0x32));
                    }
                  }
                  else {
                    *puVar33 = *puVar33 | 2;
                    *(undefined8 *)(puVar30 + -8) = 0x10204a;
                    uVar14 = func_0x(puVar33,auStack_27c);
                    *(undefined2 *)(lVar26 + 0x32) = uVar14;
                  }
                  iVar23 = iStack_298;
                  if ((*(byte *)puVar33 & 1) != 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x10206b;
                    func_0x(puVar33,0x400,iVar23);
                  }
                  if ((bVar41 & 1) != 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x102083;
                    func_0x(puVar33,auStack_128);
                  }
                }
                else {
                  if (*(int *)(lVar26 + 0xc) == 0) {
                    iVar23 = 0;
                    *puVar33 = 0;
                    uVar31 = *(uint *)(lVar26 + 0x18);
                    uVar24 = (ulonglong)uVar31;
                    *(uint *)(lVar26 + 0x1c) = uVar31;
                    pbVar20 = *(byte **)(lVar26 + 0x10);
                    bVar41 = *pbVar20;
                    if ((bVar41 & 0x10) != 0) {
                      uVar31 = uVar31 + (*(ushort *)(pbVar20 + uVar24) + 7 >> 3) + 2;
                      uVar24 = (ulonglong)uVar31;
                      *(uint *)(lVar26 + 0x1c) = uVar31;
                      bVar41 = *pbVar20;
                    }
                    if ((bVar41 & 0x20) == 0) {
                      *(int *)(lVar26 + 0xc) = (int)uVar24;
                      *(undefined2 *)(lVar26 + 0x24) = 0;
                      *(int *)(lVar26 + 0x20) = (int)uVar24;
                    }
                    else {
                      puVar43 = (ushort *)(pbVar20 + uVar24);
                      uVar12 = *puVar43;
                      *(ushort *)(lVar26 + 0x24) = uVar12;
                      if (uVar12 == 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x100d79;
                        cVar10 = func_0x(0x111c620);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar30 + -8) = 0x100d82;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar30 + -8) = 0x100d9c;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100db8;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar30 + 0x20) = 0;
                              *(undefined8 *)(puVar30 + -8) = 0x100dde;
                              (*_DAT_)(1,0xa0c02c,0xb2c118,0x80f);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(lVar26 + 0x10);
                        *(undefined8 *)(puVar30 + -8) = 0x100dec;
                        func_0x(uVar18,3);
                        uVar24 = (ulonglong)*(uint *)(lVar26 + 0x1c);
                        uVar12 = *(ushort *)(lVar26 + 0x24);
                      }
                      uVar31 = (int)uVar24 + (uVar12 + 1) * 2;
                      *(uint *)(lVar26 + 0x20) = uVar31;
                      if (0x1f9e < uVar31) {
                        *(undefined8 *)(puVar30 + -8) = 0x100e1c;
                        cVar10 = func_0x(0x111c620);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar30 + -8) = 0x100e25;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar30 + -8) = 0x100e3f;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100e5b;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar30 + 0x20) = 0;
                              *(undefined8 *)(puVar30 + -8) = 0x100e81;
                              (*_DAT_)(1,0xa0c02c,0xb2c118,0x816);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(lVar26 + 0x10);
                        *(undefined8 *)(puVar30 + -8) = 0x100e8f;
                        func_0x(uVar18,4);
                        uVar12 = *(ushort *)(lVar26 + 0x24);
                        uVar31 = *(uint *)(lVar26 + 0x20);
                      }
                      uVar24 = (ulonglong)uVar12;
                      uVar12 = puVar43[uVar24];
                      *(uint *)(lVar26 + 0xc) = uVar12 & 0x7fff;
                      if ((uVar12 & 0x7fff) < uVar31) {
                        *(undefined8 *)(puVar30 + -8) = 0x100ebc;
                        cVar10 = func_0x(0x111c620);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar30 + -8) = 0x100ec5;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar30 + -8) = 0x100edf;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100efb;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar30 + 0x20) = 0;
                              *(undefined8 *)(puVar30 + -8) = 0x100f21;
                              (*_DAT_)(1,0xa0c02c,0xb2c118,0x81d);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(lVar26 + 0x10);
                        *(undefined8 *)(puVar30 + -8) = 0x100f2f;
                        func_0x(uVar18,4);
                        uVar31 = *(uint *)(lVar26 + 0x20);
                        uVar24 = (ulonglong)*(ushort *)(lVar26 + 0x24);
                      }
                      puVar4 = puVar43;
                      if ((short)uVar24 != 0) {
                        do {
                          uVar35 = puVar4[1] & 0x7fff;
                          if ((uVar35 < uVar31) || (*(uint *)(lVar26 + 0xc) < uVar35)) {
                            *(undefined8 *)(puVar30 + -8) = 0x100f6c;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100f75;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x100f8f;
                                cVar10 = func_0x(0x111c620);
                                if (cVar10 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x100fab;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x100fd1;
                                  (*_DAT_)(1,0xa0c02c,0xb2c118,0x82a);
                                }
                              }
                            }
                            uVar18 = *(undefined8 *)(lVar26 + 0x10);
                            *(undefined8 *)(puVar30 + -8) = 0x100fdf;
                            func_0x(uVar18,4);
                          }
                          iVar23 = iVar23 + 1;
                          uVar24 = (ulonglong)*(ushort *)(lVar26 + 0x24);
                          puVar27 = puStack_2a8;
                          puVar4 = puVar4 + 1;
                          uVar31 = uVar35;
                        } while (iVar23 < (int)(uint)*(ushort *)(lVar26 + 0x24));
                      }
                      if ((short)puVar43[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                        do {
                          uVar31 = *(ushort *)
                                    (pbVar20 + uVar24 * 2 + (ulonglong)*(uint *)(lVar26 + 0x1c)) &
                                   0x7fff;
                          if ((int)uVar24 == 1) {
                            uVar35 = *(uint *)(lVar26 + 0x20);
                            uVar37 = (ulonglong)uVar35;
LAB_:
                            if ((uVar31 < (uint)uVar37) || (*(uint *)(lVar26 + 0xc) < uVar31))
                            goto LAB_;
                          }
                          else {
                            uVar37 = (ulonglong)
                                     (*(ushort *)
                                       (pbVar20 +
                                       uVar24 * 2 + ((ulonglong)*(uint *)(lVar26 + 0x1c) - 2)) &
                                     0x7fff);
                            uVar35 = *(uint *)(lVar26 + 0x20);
                            if (uVar35 <= (*(ushort *)
                                            (pbVar20 +
                                            uVar24 * 2 + ((ulonglong)*(uint *)(lVar26 + 0x1c) - 2))
                                          & 0x7fff)) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar30 + -8) = 0x101054;
                            func_0x(pbVar20,7);
                            uVar35 = *(uint *)(lVar26 + 0x20);
                          }
                          uVar36 = (uint)uVar37;
                          if ((uVar36 < uVar35) || (*(uint *)(lVar26 + 0xc) < uVar36))
                          goto LAB_;
                          pbVar20 = *(byte **)(lVar26 + 0x10);
                          if (*(ushort *)(pbVar20 + uVar37) == 5) {
                            *puVar33 = *puVar33 | 2;
                            *(short *)(lVar26 + 0x24) = *(short *)(lVar26 + 0x24) + -1;
                            uVar24 = uVar37 & 0xffff;
                            *(short *)(lVar26 + 0x32) = (short)uVar37;
                            uVar12 = *(ushort *)(lVar26 + 0x34) & 0xc7ff;
                            if ((*(ushort *)(pbVar20 + uVar24 + 2) >> 0xe & 1) != 0) {
                              uVar12 = *(ushort *)(pbVar20 + uVar24 + 2) & 0x3800 | uVar12;
                            }
                            *(ushort *)(lVar26 + 0x34) = uVar12;
                            uVar13 = (uVar12 ^ *(ushort *)(pbVar20 + uVar24 + 2)) & 0x7ff ^ uVar12;
                            *(ushort *)(lVar26 + 0x34) = uVar13;
                            uVar37 = *(ulonglong *)(lVar26 + 0x10);
                            uVar38 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 +
                                     uVar37 + (uVar12 >> 0xb & 7) * 2 + uVar24;
                            if (uVar38 < uVar37 + uVar24) {
                              *(undefined8 *)(puVar30 + -8) = 0x101160;
                              func_0x(uVar37 + uVar24,0x19);
                              uVar13 = *(ushort *)(lVar26 + 0x34);
                              uVar24 = (ulonglong)*(ushort *)(lVar26 + 0x32);
                              uVar37 = (ulonglong)*(uint *)(lVar26 + 0x10);
                            }
                            if (uVar31 - uVar36 <
                                (((uVar13 & 0x7ff) * 2 - (int)uVar24) - (int)uVar37) + (int)uVar38)
                            {
                              lVar17 = *(longlong *)(lVar26 + 0x10);
                              *(undefined8 *)(puVar30 + -8) = 0x101198;
                              func_0x(uVar24 + lVar17,0x19);
                              uVar13 = *(ushort *)(lVar26 + 0x34);
                            }
                            if ((uVar13 & 0x3800) != 0) {
                              puVar43 = (ushort *)
                                        (*(longlong *)(lVar26 + 0x10) +
                                        (ulonglong)*(ushort *)(lVar26 + 0x32) + 4);
                              iVar23 = 0;
                              if ((uVar13 & 0x3800) != 0) {
                                do {
                                  if ((uVar13 & 0x7ff) < (*puVar43 & 0x7ff)) {
                                    uVar12 = *(ushort *)(lVar26 + 0x32);
                                    lVar17 = *(longlong *)(lVar26 + 0x10);
                                    *(undefined8 *)(puVar30 + -8) = 0x1011f7;
                                    func_0x((ulonglong)uVar12 + lVar17,0x1a);
                                    uVar13 = *(ushort *)(lVar26 + 0x34);
                                  }
                                  iVar23 = iVar23 + 1;
                                  puVar43 = puVar43 + 1;
                                } while (iVar23 < (int)(uVar13 >> 0xb & 7));
                              }
                            }
                            goto LAB_;
                          }
                          if (*(ushort *)(pbVar20 + uVar37) < 0x400) goto LAB_;
                          *puVar33 = *puVar33 | 1;
                          uVar12 = *(short *)(lVar26 + 0x24) - 1;
                          *(ushort *)(lVar26 + 0x24) = uVar12;
                          if (uVar12 == 0) goto LAB_;
                          uVar24 = (ulonglong)uVar12;
                        } while ((short)puVar43[(ulonglong)(uVar12 - 1) + 1] < 0);
                        uVar24 = (ulonglong)*(uint *)(lVar26 + 0xc);
                      }
                      else {
LAB_:
                        uVar24 = (ulonglong)*(uint *)(lVar26 + 0xc);
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                      }
                    }
                    if ((*pbVar20 & 0x40) == 0) {
                      *(undefined4 *)(lVar26 + 0x2e) = 0;
                    }
                    else {
                      *(int *)(lVar26 + 0x2e) = (int)uVar24;
                      *(int *)(lVar26 + 0xc) = (int)uVar24 + 0xe;
                      *(undefined8 *)(puVar30 + -8) = 0x10123d;
                      uVar18 = func_0x(puVar33);
                      *(undefined8 *)(puVar30 + -8) = 0x10124c;
                      func_0x(uVar18,auStack_1c0);
                      *(undefined8 *)(puVar30 + -8) = 0x101258;
                      iVar23 = func_0x(auStack_1c0);
                      *(int *)(lVar26 + 0xc) = *(int *)(lVar26 + 0xc) + iVar23;
                      uVar24 = (ulonglong)*(uint *)(lVar26 + 0xc);
                    }
                    iVar23 = (int)uVar24;
                    if ((*(ulonglong *)(lVar26 + 0x26) != 0) &&
                       (*(ulonglong *)(lVar26 + 0x26) < uVar24 + *(longlong *)(lVar26 + 0x10))) {
                      *(undefined8 *)(puVar30 + -8) = 0x10128d;
                      cVar10 = func_0x(0x111c620);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar30 + -8) = 0x101296;
                        lVar17 = func_0x();
                        if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar30 + -8) = 0x1012b0;
                          cVar10 = func_0x(0x111c620);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x1012cc;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar30 + 0x20) = 0;
                            *(undefined8 *)(puVar30 + -8) = 0x1012f2;
                            (*_DAT_)(1,0xa0c02c,0xb2c118);
                          }
                        }
                      }
                      uVar18 = *(undefined8 *)(lVar26 + 0x10);
                      *(undefined8 *)(puVar30 + -8) = 0x101300;
                      func_0x(uVar18,0x12);
                      iVar23 = *(int *)(lVar26 + 0xc);
                    }
                    if (0x3f3b < iVar23 - 1U) {
                      *(undefined8 *)(puVar30 + -8) = 0x101319;
                      cVar10 = func_0x(0x111c620);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar30 + -8) = 0x101322;
                        lVar17 = func_0x();
                        if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar30 + -8) = 0x10133c;
                          cVar10 = func_0x(0x111c620);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x101358;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar30 + 0x20) = 0;
                            *(undefined8 *)(puVar30 + -8) = 0x10137e;
                            (*_DAT_)(1,0xa0c02c,0xb2c118);
                          }
                        }
                      }
                      uVar18 = *(undefined8 *)(lVar26 + 0x10);
                      *(undefined8 *)(puVar30 + -8) = 0x10138c;
                      func_0x(uVar18,5);
                    }
                  }
LAB_:
                  uVar31 = -*puVar27;
                  *(undefined8 *)(puVar30 + -8) = 0x10139f;
                  func_0x(auStack_128);
                  pbVar20 = *(byte **)(lVar26 + 0x10);
                  bVar41 = *pbVar20;
                  bVar5 = bVar41 >> 6;
                  if ((bVar5 & 1) != 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x1013c3;
                    func_0x(puVar33,auStack_128);
                    pbVar20 = *(byte **)(lVar26 + 0x10);
                    bVar41 = *pbVar20;
                  }
                  if ((bVar41 & 0x20) == 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x1013d7;
                    func_0x(puVar33);
                    pbVar20 = *(byte **)(lVar26 + 0x10);
                  }
                  uVar12 = *(ushort *)(lVar26 + 0x24);
                  uVar35 = (uint)uVar12;
                  if (uVar12 < uVar31) {
                    iVar23 = uVar31 - uVar12;
                    puVar43 = (ushort *)(pbVar20 + *(uint *)(lVar26 + 0x1c));
                    uVar36 = *(uint *)(lVar26 + 0x1c) + 2 + uVar35 * 2;
                    uVar39 = iVar23 * 2;
                    uVar25 = 0;
                    if (*puVar43 != 0) {
                      do {
                        uVar12 = puVar43[(ulonglong)uVar25 + 1];
                        puVar43[(ulonglong)(uVar25 & 0xffff) + 1] =
                             puVar43[(ulonglong)(uVar25 & 0xffff) + 1] & 0x8000;
                        puVar43[(ulonglong)(uVar25 & 0xffff) + 1] =
                             puVar43[(ulonglong)(uVar25 & 0xffff) + 1] |
                             (uVar12 & 0x7fff) + (short)uVar39 & 0x7fff;
                        uVar25 = uVar25 + 1;
                      } while (uVar25 < *puVar43);
                      pbVar20 = *(byte **)(lVar26 + 0x10);
                    }
                    iVar42 = *(int *)(lVar26 + 0xc);
                    *(undefined8 *)(puVar30 + -8) = 0x10146c;
                    func_0x
                              (pbVar20 + (ulonglong)uVar39 + (ulonglong)uVar36,pbVar20 + uVar36,
                               iVar42 - uVar36);
                    *(int *)(lVar26 + 0xc) = *(int *)(lVar26 + 0xc) + uVar39;
                    *(int *)(lVar26 + 0x20) = *(int *)(lVar26 + 0x20) + uVar39;
                    uVar12 = (ushort)*(undefined4 *)(lVar26 + 0x20);
                    if (uVar35 != 0) {
                      uVar12 = puVar43[(ulonglong)(uVar35 - 1) + 1] & 0x7fff;
                    }
                    do {
                      puVar43[(ulonglong)(uVar35 & 0xffff) + 1] = uVar12 & 0x7fff;
                      uVar35 = uVar35 + 1;
                    } while (uVar35 < uVar31);
                    *puVar43 = *puVar43 + (short)iVar23;
                    *(undefined8 *)(puVar30 + -8) = 0x1014ab;
                    iVar23 = func_0x(puVar33);
                    if (iVar23 != 0) {
                      *(undefined8 *)(puVar30 + -8) = 0x1014be;
                      uVar14 = func_0x(puVar33,auStack_1d0);
                      *(undefined2 *)(lVar26 + 0x32) = uVar14;
                    }
                    *(short *)(lVar26 + 0x24) = (short)uVar31;
                    uVar35 = uVar31 & 0xffff;
                    pbVar20 = *(byte **)(lVar26 + 0x10);
                  }
                  uVar36 = *(uint *)(lVar26 + 0x1c);
                  if (uVar35 < uVar31) {
                    uVar24 = (ulonglong)
                             (*(ushort *)(pbVar20 + (ulonglong)uVar35 * 2 + (ulonglong)uVar36) &
                             0x7fff);
                    iVar23 = 0;
LAB_:
                    puVar43 = (ushort *)(pbVar20 + *(uint *)(lVar26 + 0x1c));
                    lVar17 = uVar24 + *(longlong *)(lVar26 + 0x10);
                    uVar15 = *(undefined4 *)(lVar26 + 0xc);
                    *(undefined8 *)(puVar30 + -8) = 0x10156b;
                    uVar15 = func_0x(uVar15,(int)uVar24 + iVar23);
                    *(undefined8 *)(puVar30 + -8) = 0x10157d;
                    func_0x(lVar17 + 1,iVar23 + lVar17,uVar15);
                    uVar31 = uVar31 - 1;
                    if ((int)uVar31 < (int)(uint)*puVar43) {
                      do {
                        uVar12 = puVar43[(longlong)(int)uVar31 + 1];
                        puVar43[((ulonglong)uVar31 & 0xffff) + 1] =
                             puVar43[((ulonglong)uVar31 & 0xffff) + 1] & 0x8000;
                        puVar43[((ulonglong)uVar31 & 0xffff) + 1] =
                             puVar43[((ulonglong)uVar31 & 0xffff) + 1] |
                             ((uVar12 & 0x7fff) - (short)iVar23) + 1 & 0x7fff;
                        uVar31 = uVar31 + 1;
                      } while ((int)uVar31 < (int)(uint)*puVar43);
                    }
                    *(int *)(lVar26 + 0xc) = *(int *)(lVar26 + 0xc) + (1 - iVar23);
                    *(undefined8 *)(puVar30 + -8) = 0x1015e2;
                    iVar23 = func_0x(puVar33);
                    if (iVar23 != 0) {
                      *(undefined8 *)(puVar30 + -8) = 0x1015f5;
                      uVar14 = func_0x(puVar33,auStack_1cc);
                      *(undefined2 *)(lVar26 + 0x32) = uVar14;
                    }
                  }
                  else {
                    if (uVar31 == 1) {
                      uVar24 = (ulonglong)*(uint *)(psStack_2b0 + 0xc);
                      uVar35 = *(ushort *)(pbVar20 + (ulonglong)uVar36 + 2) & 0x7fff;
LAB_:
                      if ((uVar35 < (uint)uVar24) || (*(uint *)(lVar26 + 0xc) < uVar35))
                      goto LAB_;
                    }
                    else {
                      uVar24 = (ulonglong)
                               (*(ushort *)
                                 (pbVar20 + (longlong)(int)uVar31 * 2 + ((ulonglong)uVar36 - 2)) &
                               0x7fff);
                      uVar35 = *(ushort *)(pbVar20 + (longlong)(int)uVar31 * 2 + (ulonglong)uVar36)
                               & 0x7fff;
                      if (*(uint *)(psStack_2b0 + 0xc) <=
                          (*(ushort *)
                            (pbVar20 + (longlong)(int)uVar31 * 2 + ((ulonglong)uVar36 - 2)) & 0x7fff
                          )) goto LAB_;
LAB_:
                      *(undefined8 *)(puVar30 + -8) = 0x101533;
                      func_0x(pbVar20,7);
                      pbVar20 = *(byte **)(lVar26 + 0x10);
                    }
                    iVar23 = uVar35 - (int)uVar24;
                    if (iVar23 != 1) goto LAB_;
                  }
                  *(char *)(*(longlong *)(lVar26 + 0x10) + uVar24) = *(char *)piStack_288;
                  if ((bVar5 & 1) != 0) {
                    *(undefined8 *)(puVar30 + -8) = 0x10161e;
                    func_0x(puVar33,auStack_128);
                  }
                }
              }
              else {
                uVar35 = (uint)*(ushort *)((longlong)puVar27 + 6);
                if ((*(ushort *)((longlong)puVar27 + 6) & 8) == 0) {
                  if (*(int *)(lVar26 + 0xc) == 0) {
                    iVar23 = 0;
                    *puVar33 = 0;
                    uVar31 = *(uint *)(lVar26 + 0x18);
                    uVar24 = (ulonglong)uVar31;
                    *(uint *)(lVar26 + 0x1c) = uVar31;
                    pbVar20 = *(byte **)(lVar26 + 0x10);
                    bVar41 = *pbVar20;
                    if ((bVar41 & 0x10) != 0) {
                      uVar31 = uVar31 + 2 + (*(ushort *)(pbVar20 + uVar24) + 7 >> 3);
                      uVar24 = (ulonglong)uVar31;
                      *(uint *)(lVar26 + 0x1c) = uVar31;
                      bVar41 = *pbVar20;
                    }
                    if ((bVar41 & 0x20) == 0) {
                      *(int *)(lVar26 + 0xc) = (int)uVar24;
                      *(undefined2 *)(lVar26 + 0x24) = 0;
                      *(int *)(lVar26 + 0x20) = (int)uVar24;
                    }
                    else {
                      puVar43 = (ushort *)(pbVar20 + uVar24);
                      uVar12 = *puVar43;
                      *(ushort *)(lVar26 + 0x24) = uVar12;
                      if (uVar12 == 0) {
                        *(undefined8 *)(puVar30 + -8) = 0x100662;
                        cVar10 = func_0x(0x111c620);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar30 + -8) = 0x10066b;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar30 + -8) = 0x100685;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x1006a1;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar30 + 0x20) = 0;
                              *(undefined8 *)(puVar30 + -8) = 0x1006c7;
                              (*_DAT_)(1,0xa0c02c,0xb2c118,0x80f);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(lVar26 + 0x10);
                        *(undefined8 *)(puVar30 + -8) = 0x1006d5;
                        func_0x(uVar18,3);
                        uVar24 = (ulonglong)*(uint *)(lVar26 + 0x1c);
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                        uVar12 = *(ushort *)(lVar26 + 0x24);
                      }
                      uVar31 = (int)uVar24 + (uVar12 + 1) * 2;
                      *(uint *)(lVar26 + 0x20) = uVar31;
                      if (0x1f9e < uVar31) {
                        *(undefined8 *)(puVar30 + -8) = 0x100709;
                        cVar10 = func_0x(0x111c620);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar30 + -8) = 0x100712;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar30 + -8) = 0x10072c;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100748;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar30 + 0x20) = 0;
                              *(undefined8 *)(puVar30 + -8) = 0x10076e;
                              (*_DAT_)(1,0xa0c02c,0xb2c118,0x816);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(lVar26 + 0x10);
                        *(undefined8 *)(puVar30 + -8) = 0x10077c;
                        func_0x(uVar18,4);
                        uVar12 = *(ushort *)(lVar26 + 0x24);
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                        uVar31 = *(uint *)(lVar26 + 0x20);
                      }
                      uVar24 = (ulonglong)uVar12;
                      uVar12 = puVar43[uVar24];
                      *(uint *)(lVar26 + 0xc) = uVar12 & 0x7fff;
                      if ((uVar12 & 0x7fff) < uVar31) {
                        *(undefined8 *)(puVar30 + -8) = 0x1007ad;
                        cVar10 = func_0x(0x111c620);
                        if (cVar10 != '\0') {
                          *(undefined8 *)(puVar30 + -8) = 0x1007b6;
                          lVar17 = func_0x();
                          if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar30 + -8) = 0x1007d0;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 == '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x1007ec;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar30 + 0x20) = 0;
                              *(undefined8 *)(puVar30 + -8) = 0x100812;
                              (*_DAT_)(1,0xa0c02c,0xb2c118,0x81d);
                            }
                          }
                        }
                        uVar18 = *(undefined8 *)(lVar26 + 0x10);
                        *(undefined8 *)(puVar30 + -8) = 0x100820;
                        func_0x(uVar18,4);
                        uVar31 = *(uint *)(lVar26 + 0x20);
                        uVar24 = (ulonglong)*(ushort *)(lVar26 + 0x24);
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                      }
                      puVar4 = puVar43;
                      if ((short)uVar24 != 0) {
                        do {
                          uVar35 = puVar4[1] & 0x7fff;
                          if ((uVar35 < uVar31) || (*(uint *)(lVar26 + 0xc) < uVar35)) {
                            *(undefined8 *)(puVar30 + -8) = 0x10085d;
                            cVar10 = func_0x(0x111c620);
                            if (cVar10 != '\0') {
                              *(undefined8 *)(puVar30 + -8) = 0x100866;
                              lVar17 = func_0x();
                              if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar30 + -8) = 0x100880;
                                cVar10 = func_0x(0x111c620);
                                if (cVar10 == '\0') {
                                  *(undefined8 *)(puVar30 + -8) = 0x10089c;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar30 + 0x20) = 0;
                                  *(undefined8 *)(puVar30 + -8) = 0x1008c2;
                                  (*_DAT_)(1,0xa0c02c,0xb2c118,0x82a);
                                }
                              }
                            }
                            uVar18 = *(undefined8 *)(lVar26 + 0x10);
                            *(undefined8 *)(puVar30 + -8) = 0x1008d0;
                            func_0x(uVar18,4);
                          }
                          iVar23 = iVar23 + 1;
                          uVar24 = (ulonglong)*(ushort *)(lVar26 + 0x24);
                          uVar31 = uVar35;
                          puVar4 = puVar4 + 1;
                        } while (iVar23 < (int)(uint)*(ushort *)(lVar26 + 0x24));
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                        puVar27 = puStack_2a8;
                      }
                      if ((short)puVar43[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
                        do {
                          uVar31 = *(ushort *)
                                    (pbVar20 + uVar24 * 2 + (ulonglong)*(uint *)(lVar26 + 0x1c)) &
                                   0x7fff;
                          if ((int)uVar24 == 1) {
                            uVar35 = *(uint *)(lVar26 + 0x20);
                            uVar37 = (ulonglong)uVar35;
LAB_:
                            if ((uVar31 < (uint)uVar37) || (*(uint *)(lVar26 + 0xc) < uVar31))
                            goto LAB_;
                          }
                          else {
                            uVar37 = (ulonglong)
                                     (*(ushort *)
                                       (pbVar20 +
                                       uVar24 * 2 + ((ulonglong)*(uint *)(lVar26 + 0x1c) - 2)) &
                                     0x7fff);
                            uVar35 = *(uint *)(lVar26 + 0x20);
                            if (uVar35 <= (*(ushort *)
                                            (pbVar20 +
                                            uVar24 * 2 + ((ulonglong)*(uint *)(lVar26 + 0x1c) - 2))
                                          & 0x7fff)) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar30 + -8) = 0x100952;
                            func_0x(pbVar20,7);
                            uVar35 = *(uint *)(lVar26 + 0x20);
                            pbVar20 = *(byte **)(lVar26 + 0x10);
                          }
                          uVar36 = (uint)uVar37;
                          if ((uVar36 < uVar35) || (*(uint *)(lVar26 + 0xc) < uVar36))
                          goto LAB_;
                          if (*(ushort *)(pbVar20 + uVar37) == 5) {
                            *puVar33 = *puVar33 | 2;
                            *(short *)(lVar26 + 0x24) = *(short *)(lVar26 + 0x24) + -1;
                            uVar38 = uVar37 & 0xffff;
                            *(short *)(lVar26 + 0x32) = (short)uVar37;
                            uVar24 = *(ulonglong *)(lVar26 + 0x10);
                            uVar12 = *(ushort *)(uVar24 + 2 + uVar38);
                            uVar13 = *(ushort *)(lVar26 + 0x34) & 0xc7ff;
                            if ((uVar12 >> 0xe & 1) != 0) {
                              uVar13 = uVar12 & 0x3800 | uVar13;
                            }
                            *(ushort *)(lVar26 + 0x34) = uVar13;
                            uVar12 = (uVar13 ^ *(ushort *)(uVar38 + 2 + uVar24)) & 0x7ff ^ uVar13;
                            *(ushort *)(lVar26 + 0x34) = uVar12;
                            uVar37 = (ulonglong)((uVar12 & 0x7ff) * 2) + 4 +
                                     uVar24 + (uVar13 >> 0xb & 7) * 2 + uVar38;
                            if (uVar37 < uVar38 + uVar24) {
                              *(undefined8 *)(puVar30 + -8) = 0x100a5f;
                              func_0x(uVar38 + uVar24,0x19);
                              uVar12 = *(ushort *)(lVar26 + 0x34);
                              uVar38 = (ulonglong)*(ushort *)(lVar26 + 0x32);
                              uVar24 = (ulonglong)*(uint *)(lVar26 + 0x10);
                            }
                            if (uVar31 - uVar36 <
                                (((uVar12 & 0x7ff) * 2 - (int)uVar38) - (int)uVar24) + (int)uVar37)
                            {
                              lVar17 = *(longlong *)(lVar26 + 0x10);
                              *(undefined8 *)(puVar30 + -8) = 0x100a97;
                              func_0x(uVar38 + lVar17,0x19);
                              uVar12 = *(ushort *)(lVar26 + 0x34);
                            }
                            if ((uVar12 & 0x3800) != 0) {
                              puVar43 = (ushort *)
                                        (*(longlong *)(lVar26 + 0x10) +
                                        (ulonglong)*(ushort *)(lVar26 + 0x32) + 4);
                              iVar23 = 0;
                              if ((uVar12 & 0x3800) != 0) {
                                do {
                                  if ((uVar12 & 0x7ff) < (*puVar43 & 0x7ff)) {
                                    uVar12 = *(ushort *)(lVar26 + 0x32);
                                    lVar17 = *(longlong *)(lVar26 + 0x10);
                                    *(undefined8 *)(puVar30 + -8) = 0x100af7;
                                    func_0x((ulonglong)uVar12 + lVar17,0x1a);
                                    uVar12 = *(ushort *)(lVar26 + 0x34);
                                  }
                                  iVar23 = iVar23 + 1;
                                  puVar43 = puVar43 + 1;
                                } while (iVar23 < (int)(uVar12 >> 0xb & 7));
                              }
                            }
                            goto LAB_;
                          }
                          if (*(ushort *)(pbVar20 + uVar37) < 0x400) goto LAB_;
                          *puVar33 = *puVar33 | 1;
                          uVar12 = *(short *)(lVar26 + 0x24) - 1;
                          *(ushort *)(lVar26 + 0x24) = uVar12;
                          if (uVar12 == 0) goto LAB_;
                          uVar24 = (ulonglong)uVar12;
                        } while ((short)puVar43[(ulonglong)(uVar12 - 1) + 1] < 0);
                        uVar24 = (ulonglong)*(uint *)(lVar26 + 0xc);
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                      }
                      else {
LAB_:
                        uVar24 = (ulonglong)*(uint *)(lVar26 + 0xc);
                        pbVar20 = *(byte **)(lVar26 + 0x10);
                      }
                    }
                    if ((*pbVar20 & 0x40) == 0) {
                      *(undefined4 *)(lVar26 + 0x2e) = 0;
                    }
                    else {
                      *(int *)(lVar26 + 0x2e) = (int)uVar24;
                      *(int *)(lVar26 + 0xc) = (int)uVar24 + 0xe;
                      *(undefined8 *)(puVar30 + -8) = 0x100b3e;
                      uVar18 = func_0x(puVar33);
                      *(undefined8 *)(puVar30 + -8) = 0x100b4d;
                      func_0x(uVar18,auStack_1c8);
                      *(undefined8 *)(puVar30 + -8) = 0x100b59;
                      iVar23 = func_0x(auStack_1c8);
                      *(int *)(lVar26 + 0xc) = *(int *)(lVar26 + 0xc) + iVar23;
                      uVar24 = (ulonglong)*(uint *)(lVar26 + 0xc);
                      pbVar20 = *(byte **)(lVar26 + 0x10);
                    }
                    iVar23 = (int)uVar24;
                    if ((*(byte **)(lVar26 + 0x26) != (byte *)0x0) &&
                       (*(byte **)(lVar26 + 0x26) < pbVar20 + uVar24)) {
                      *(undefined8 *)(puVar30 + -8) = 0x100b91;
                      cVar10 = func_0x(0x111c620);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar30 + -8) = 0x100b9a;
                        lVar17 = func_0x();
                        if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar30 + -8) = 0x100bb4;
                          cVar10 = func_0x(0x111c620);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x100bd0;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar30 + 0x20) = 0;
                            *(undefined8 *)(puVar30 + -8) = 0x100bf6;
                            (*_DAT_)(1,0xa0c02c,0xb2c118);
                          }
                        }
                      }
                      uVar18 = *(undefined8 *)(lVar26 + 0x10);
                      *(undefined8 *)(puVar30 + -8) = 0x100c04;
                      func_0x(uVar18,0x12);
                      iVar23 = *(int *)(lVar26 + 0xc);
                    }
                    if (0x3f3b < iVar23 - 1U) {
                      *(undefined8 *)(puVar30 + -8) = 0x100c1d;
                      cVar10 = func_0x(0x111c620);
                      if (cVar10 != '\0') {
                        *(undefined8 *)(puVar30 + -8) = 0x100c26;
                        lVar17 = func_0x();
                        if ((lVar17 != 0) && (*(char *)(lVar17 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar30 + -8) = 0x100c40;
                          cVar10 = func_0x(0x111c620);
                          if (cVar10 == '\0') {
                            *(undefined8 *)(puVar30 + -8) = 0x100c5c;
                            (*_DAT_)(0x22,0x44,0x15);
                          }
                          else {
                            *(undefined8 *)(puVar30 + 0x20) = 0;
                            *(undefined8 *)(puVar30 + -8) = 0x100c82;
                            (*_DAT_)(1,0xa0c02c,0xb2c118);
                          }
                        }
                      }
                      uVar18 = *(undefined8 *)(lVar26 + 0x10);
                      *(undefined8 *)(puVar30 + -8) = 0x100c90;
                      func_0x(uVar18,5);
                    }
                  }
LAB_:
                  uVar35 = *puVar27;
                  uVar31 = uVar35 + 1;
                  uVar36 = *(uint *)(lVar26 + 0x18);
                  if (uVar36 < uVar31) {
                    *(undefined8 *)(puVar30 + -8) = 0x100cb1;
                    func_0x(puVar33,0,uVar31 - uVar36);
                    if ((1 << (**(byte **)(lVar26 + 0x10) & 0xe) & 0x1105U) != 0) {
                      *(short *)(*(byte **)(lVar26 + 0x10) + 2) = (short)uVar31;
                    }
                    *(uint *)(lVar26 + 0x18) = uVar31;
                    uVar35 = *puVar27;
                  }
                  puStack_2a8 = puVar27;
                  if (piStack_288 != (int *)0x0) {
                    *(char *)((longlong)(int)uVar35 + *(longlong *)(lVar26 + 0x10)) =
                         *(char *)piStack_288;
                  }
                }
                else {
                  cVar10 = *(char *)piStack_278;
                  uVar31 = uVar31 + 1;
                  uVar36 = *(uint *)(lVar26 + 0x18);
                  if (uVar36 < uVar31) {
                    *(undefined8 *)(puVar30 + -8) = 0x1005a1;
                    func_0x(puVar33,0,uVar31 - uVar36);
                    if ((1 << (**(byte **)(lVar26 + 0x10) & 0xe) & 0x1105U) != 0) {
                      *(short *)(*(byte **)(lVar26 + 0x10) + 2) = (short)uVar31;
                    }
                    *(uint *)(lVar26 + 0x18) = uVar31;
                    uVar35 = (uint)*(byte *)((longlong)puVar27 + 6);
                  }
                  lVar16 = *(longlong *)(lVar26 + 0x10);
                  if (cVar10 == '\0') {
                    *(byte *)(lVar16 + lVar17) =
                         *(byte *)(lVar16 + lVar17) & ~(byte)(1 << (uVar35 & 7));
                    puStack_2a8 = puVar27;
                  }
                  else {
                    *(byte *)(lVar16 + lVar17) =
                         *(byte *)(lVar16 + lVar17) | (byte)(1 << (uVar35 & 7));
                    puStack_2a8 = puVar27;
                  }
                }
              }
            }
            else {
              *(undefined8 *)(puVar30 + 0x20) = 0x787590;
              *(undefined8 *)(puVar30 + -8) = 0x10055c;
              (*_DAT_)(1,0xb8d920,0xbba2e8);
              puStack_2a8 = puVar27;
            }
          }
          puStack_2a8 = puStack_2a8 + 0x14;
          uStack_280 = uStack_280 + 1;
          puVar27 = puStack_2a8;
          plVar40 = plStack_270;
          uVar35 = uStack_290;
        } while (uStack_280 < uStack_1f4);
      }
      uVar31 = uStack_294;
      puVar33 = (ushort *)0x0;
      do {
        uVar36 = uVar35;
        if (uVar36 == 0) goto LAB_;
        uVar24 = (ulonglong)uVar36;
        uVar35 = uVar36 - 1;
      } while (*(int *)(plStack_270 + (ulonglong)(uVar36 - 1) * 4 + 1) == 0);
      *(ushort *)(lVar26 + 0x24) = (ushort)uVar36;
      iVar23 = *(int *)(lVar26 + 0x1c) + 2 + uVar36 * 2;
      *(int *)(lVar26 + 0x20) = iVar23;
      *(int *)(lVar26 + 0xc) = iVar23;
      **(byte **)(lVar26 + 0x10) = **(byte **)(lVar26 + 0x10) | 0x20;
      if (*(uint *)(lVar26 + 0xc) <= uStack_29c) {
        puVar33 = (ushort *)((ulonglong)*(uint *)(lVar26 + 0x1c) + *(longlong *)(lVar26 + 0x10));
        *puVar33 = (ushort)uVar36;
      }
      if (uVar36 != 0) {
        puVar27 = (uint *)((longlong)plStack_270 + 0xc);
        uVar35 = uStack_29c;
        do {
          puVar33 = puVar33 + 1;
          uVar39 = *(uint *)(lVar26 + 0xc);
          lVar17 = *(longlong *)(lVar26 + 0x10);
          uVar25 = puVar27[-1];
          uVar36 = uVar39 + uVar25;
          *(uint *)(lVar26 + 0xc) = uVar36;
          if ((uVar36 <= uVar35) && (uVar36 <= uVar31)) {
            *puVar33 = (ushort)((*puVar27 & 1) << 0xf) | (ushort)uVar36 & 0x7fff;
            uVar18 = *(undefined8 *)(puVar27 + -3);
            *(undefined8 *)(puVar30 + -8) = 0x1022ef;
            func_0x((ulonglong)uVar39 + lVar17,uVar25,uVar18,uVar25);
            uVar35 = uStack_29c;
          }
          puVar27 = puVar27 + 8;
          uVar24 = uVar24 - 1;
        } while (uVar24 != 0);
      }
    }
  }
  else {
    *(undefined8 *)(puVar29 + 0x40) = 0;
    *(undefined **)(puVar29 + 0x38) = auStack_27c;
    *(uint *)(puVar29 + 0x30) = uVar35;
    *(uint *)(puVar29 + 0x28) = uVar31;
    *(undefined8 *)(puVar29 + 0x20) = uVar18;
    *(undefined8 *)(puVar29 + -8) = 0x1027de;
    func_0x(auStack_168,&plStack_268,2,psVar34);
  }
LAB_:
  puVar9 = puStack_1d8;
  if (((*(uint *)((longlong)puStack_1d8 + 0x14) & 0xe0000000) != 0x80000000) ||
     (0xff < *(ushort *)(puStack_1d8 + 3))) {
    *(undefined8 *)(puVar30 + -8) = 0x1016b0;
    func_0x(puVar9,1);
  }
  *(undefined8 *)(puVar30 + -8) = 0x1016bf;
  func_0x(&lStack_1e8,puVar9);
  lVar26 = lStack_1e8;
  uVar18 = *(undefined8 *)(lStack_1e8 + 8);
  *(undefined8 *)(puVar30 + -8) = 0x1016cf;
  func_0x(uVar18);
  uVar18 = *(undefined8 *)(lVar26 + 8);
  *(undefined8 *)(puVar30 + -8) = 0x1016db;
  func_0x(uVar18,1);
  if (iStack_1e0 != 0) {
    lVar26 = *(longlong *)(lVar26 + 8);
    *(undefined8 *)(puVar30 + -8) = 0x1016fd;
    func_0x(lVar26 + 0x630,2);
    iStack_1e0 = 0;
  }
  lStack_1e8 = 0;
  lVar26 = lStack_1a8;
  while (lVar26 != 0) {
    lVar17 = *(longlong *)(lVar26 + 8000);
    *(undefined8 *)(puVar30 + -8) = 0x102812;
    (*_DAT_)(lVar26,0x1f48);
    lVar26 = lVar17;
  }
  uVar24 = uStack_48 ^ (ulonglong)&lStack_2b8;
  *(undefined8 *)(puVar30 + -8) = 0x10282c;
  func_0x(uVar24);
  return;
}

