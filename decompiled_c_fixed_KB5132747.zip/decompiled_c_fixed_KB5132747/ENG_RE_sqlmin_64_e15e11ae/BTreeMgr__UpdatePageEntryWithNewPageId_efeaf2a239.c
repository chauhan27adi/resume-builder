
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  byte *pbVar1;
  uint *puVar2;
  byte bVar3;
  ushort *puVar4;
  undefined auVar5 [16];
  char cVar6;
  int iVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong lVar11;
  ushort uVar12;
  uint uVar13;
  uint uVar14;
  longlong *plVar15;
  longlong lVar16;
  uint uVar17;
  uint *puVar18;
  short sVar19;
  ulonglong uVar20;
  ushort *puVar21;
  uint uVar22;
  byte *pbVar23;
  uint uVar24;
  longlong unaff_GS_OFFSET;
  undefined auStack_1f8 [32];
  undefined8 uStack_1d8;
  undefined4 uStack_1d0;
  undefined8 uStack_1c8;
  undefined8 uStack_1c0;
  undefined4 uStack_1b8;
  undefined4 uStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined4 uStack_198;
  undefined8 uStack_190;
  undefined4 uStack_188;
  undefined4 uStack_180;
  undefined8 uStack_178;
  undefined8 uStack_170;
  uint uStack_168;
  uint uStack_164;
  longlong lStack_160;
  undefined8 uStack_158;
  undefined2 uStack_150;
  undefined4 uStack_148;
  undefined4 uStack_140;
  undefined2 uStack_13c;
  undefined4 uStack_138;
  undefined2 uStack_134;
  undefined2 uStack_132;
  undefined8 uStack_130;
  longlong lStack_128;
  undefined8 uStack_120;
  longlong lStack_118;
  longlong **pplStack_110;
  longlong lStack_108;
  short sStack_100;
  ushort uStack_fe;
  uint uStack_fc;
  uint *puStack_f8;
  undefined8 uStack_f0;
  undefined4 uStack_e8;
  ushort uStack_e4;
  undefined2 uStack_e2;
  undefined6 uStack_e0;
  undefined2 uStack_da;
  undefined2 uStack_d8;
  ushort uStack_d6;
  ushort uStack_d4;
  undefined2 uStack_d2;
  undefined4 uStack_d0;
  uint uStack_cc;
  undefined auStack_c8 [16];
  undefined auStack_b8 [2];
  undefined auStack_b6 [2];
  undefined auStack_b4 [12];
  uint uStack_a8;
  undefined4 uStack_a4;
  short sStack_a0;
  short sStack_9e;
  short sStack_9c;
  undefined2 uStack_9a;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined2 uStack_90;
  undefined6 uStack_8e;
  uint uStack_88;
  undefined4 uStack_84;
  short *psStack_80;
  short *psStack_78;
  short sStack_70;
  undefined6 uStack_6e;
  undefined auStack_68 [10];
  undefined auStack_5e [6];
  undefined8 uStack_58;
  uint auStack_50 [2];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1f8;
  plVar15 = (longlong *)0x0;
  uVar14 = 0;
  uVar24 = 1;
  lStack_108 = **(longlong **)(param_1 + 8);
  lStack_160 = *(longlong *)(lStack_108 + 8);
  uStack_138 = *(undefined4 *)(lStack_160 + 0x3c0);
  uStack_134 = *(undefined2 *)(lStack_160 + 0x3c4);
  uStack_132 = *(undefined2 *)(lStack_160 + 0x3c6);
  uVar13 = 0;
  uStack_130 = param_2;
  lStack_128 = param_1;
  uStack_120 = param_4;
  if (*(int *)(param_1 + 0x40) == 0) {
    uStack_164 = *(uint *)(param_1 + 0x30);
    sStack_100 = 0xffff;
    pplStack_110 = (longlong **)(param_1 + 0x18);
    puStack_f8 = (uint *)0x0;
    uStack_fc = 0;
    uStack_e2 = 0;
    uStack_e0 = 0;
    uStack_d8 = 0;
    uStack_d6 = 0;
    uStack_d4 = 0;
    uStack_d2 = 0;
    uStack_f0 = (longlong *)0x0;
    lStack_118 = (ulonglong)*(uint6 *)(lStack_108 + 0x14) << 0x10;
    lVar8 = **pplStack_110;
    plVar10 = plVar15;
    uStack_cc = uStack_164;
    if (*(char *)(lVar8 + 2) < '\0') {
      pbVar1 = (byte *)(lVar8 + 0x60);
      _auStack_b6 = SUB1614(ZEXT816(0),2);
      auStack_b8 = (undefined  [2])0xffff;
      sStack_a0 = 0;
      sStack_9e = 0;
      sStack_9c = 0;
      uStack_92 = 0;
      auStack_b4._4_8_ = 0;
      uStack_88 = 0;
      uStack_84 = 0;
      uStack_9a = 0;
      uStack_98 = 0;
      uStack_90 = 0;
      uStack_8e = 0;
      uStack_a8 = 0;
      uStack_a4 = 0;
      psStack_80 = (short *)0x0;
      _auStack_68 = ZEXT812(0);
      auStack_5e._2_4_ = 0;
      uStack_58 = 0;
      psStack_78 = (short *)0x0;
      sStack_70 = 0;
      uStack_6e = 0;
      auStack_c8 = ZEXT816(0);
      uVar9 = 0;
      if (*(short *)(lVar8 + 0x24) == 0) {
LAB_:
        auStack_c8._8_8_ = uVar9;
        uStack_158 = *(undefined8 *)(lVar8 + 0x28);
        uStack_150 = *(undefined2 *)(lVar8 + 0x30);
      }
      else {
        cVar6 = *(char *)(lVar8 + 1);
        if (cVar6 == '\v') {
          if (*(int *)(lVar8 + 0x18) != 99) {
LAB_:
            if (cVar6 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar6 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar8 + 0x18) != 99) goto LAB_;
        }
        uStack_140 = *(undefined4 *)(lVar8 + 0x20);
        uStack_13c = *(undefined2 *)(lVar8 + 0x24);
        cVar6 = func_0x(&uStack_140);
        uVar9 = auStack_c8._8_8_;
        if (cVar6 == '\0') goto LAB_;
        func_0x(lVar8,&uStack_158);
      }
      auStack_68._8_2_ = uStack_150;
      auStack_68._0_8_ = uStack_158;
      auStack_c8._0_8_ = pbVar1;
      auStack_5e._2_4_ = *(undefined4 *)(lVar8 + 0x20);
      auStack_b8 = (undefined  [2])0xffff;
      _auStack_b8 = _auStack_b8 & 0xffffffff;
      auStack_b4._4_8_ = 0;
      uStack_9a = 0;
      uStack_98 = 0;
      uStack_148 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x17aa690);
      uVar20 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x17aa694);
      uStack_90 = 0;
      uStack_8e = 0;
      uStack_a8 = 0;
      uStack_a4 = 0;
      psStack_80 = (short *)0x0;
      psStack_78 = (short *)0x0;
      sStack_70 = 0;
      uVar17 = uStack_a8;
      if ((*pbVar1 & 2) != 0) {
        pbVar23 = pbVar1 + uVar20;
        auStack_b4._4_8_ = pbVar23;
        if ((pbVar1[uVar20] & 1) == 0) {
          auVar5._14_2_ = 0;
          auVar5._0_14_ = _auStack_b6;
          _auStack_b8 = auVar5 << 0x10;
          uStack_92 = 0;
          uStack_90 = 0;
          uVar17 = uVar13;
          switch(*pbVar23 & 0xe) {
          default:
            uVar12 = *(ushort *)(pbVar23 + 2);
            uVar17 = (uint)uVar12;
            if (0x1f9d < uVar12 - 1) {
              func_0x(pbVar23,6);
            }
            break;
          case 4:
            uVar17 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar17 = uVar24;
          }
        }
        else {
          bVar3 = *pbVar23;
          switch(bVar3 & 0x1c) {
          default:
            if ((char)pbVar23[1] < '\0') {
              sStack_a0 = 3;
              auStack_b6 = (undefined  [2])
                           ((*(ushort *)(pbVar23 + 1) & 0x7f) << 8 | *(ushort *)(pbVar23 + 1) >> 8);
            }
            else {
              sStack_a0 = 2;
              auStack_b6 = (undefined  [2])(ushort)pbVar23[1];
            }
            auStack_b8 = (undefined  [2])0x1;
            sStack_9c = (short)((ushort)auStack_b6 + 1 >> 1) + sStack_a0;
            if ((ushort)auStack_b6 < 0x1f) {
              sStack_9e = 0;
              uStack_88 = 0;
              uStack_90 = 0;
              uStack_8e = 0;
              uStack_a8 = 0;
              uStack_a4 = 0;
              uVar17 = uStack_a8;
            }
            else {
              iVar7 = (ushort)auStack_b6 - 1;
              uStack_88 = 0;
              uStack_90 = 0;
              uStack_8e = 0;
              uStack_a8 = 0;
              uStack_a4 = 0;
              sStack_9e = ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                          (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
              uVar17 = uStack_a8;
            }
            break;
          case 4:
            auStack_b4._0_4_ = uVar24;
            uStack_88 = uVar13;
            if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
              auStack_b4._0_4_ = 0xf;
              uStack_88 = uVar24;
            }
            sStack_a0 = 0;
            sStack_9e = 0;
            sStack_9c = 0;
            uStack_92 = 0;
            _auStack_b8 = 1;
            uStack_90 = 0;
            uStack_8e = 0;
            uStack_a8 = 0;
            uStack_a4 = 0;
            uVar17 = uStack_a8;
            break;
          case 8:
            sStack_a0 = 0;
            sStack_9e = 0;
            sStack_9c = 0;
            uStack_92 = 0;
            _auStack_b8 = 0x900000001;
            uStack_88 = 0;
            uStack_90 = 0;
            uStack_8e = 0;
            uStack_a8 = 0;
            uStack_a4 = 0;
            uVar17 = uStack_a8;
          }
        }
      }
      uStack_a8 = uVar17;
      uStack_98 = 0;
      uStack_9a = 0;
      if ((*(byte *)auStack_c8._0_8_ & 4) != 0) {
        if (uStack_148._2_2_ != 0) {
          uVar20 = (ulonglong)*(ushort *)(lVar8 + 0x61 + (longlong)uStack_148._2_2_ * 2);
        }
        psStack_80 = (short *)(pbVar1 + uVar20);
        psStack_78 = psStack_80 + 1;
        sStack_70 = (*psStack_80 + 1) * 2;
      }
      plVar10 = (longlong *)auStack_c8;
      if (auStack_c8._8_8_ != 0) {
        func_0x(auStack_c8._8_8_,auStack_c8);
      }
    }
    lVar11 = lStack_160;
    sVar19 = 2;
    puStack_f8 = (uint *)((ulonglong)*(ushort *)(lVar8 + (0xfff - (longlong)(int)uStack_164) * 2) +
                         lVar8);
    if ((*(byte *)puStack_f8 & 1) == 0) {
      sStack_100 = 0;
      uStack_fc = 0;
      uStack_da = 0;
      uStack_d8 = 0;
      uVar17 = (uint)*(ushort *)(lVar8 + 0xe);
      switch(*(byte *)puStack_f8 & 0xe) {
      default:
        uVar17 = (uint)*(ushort *)((longlong)puStack_f8 + 2);
        if (0x1f9d < *(ushort *)((longlong)puStack_f8 + 2) - 1) {
          func_0x(puStack_f8,6);
        }
        break;
      case 4:
        uVar17 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar17 = uVar24;
      }
      uStack_f0 = (longlong *)CONCAT44(uStack_f0._4_4_,uVar17);
      uStack_e2 = (undefined2)(lVar8 + 0x2000);
      uStack_e0 = (undefined6)((ulonglong)(lVar8 + 0x2000) >> 0x10);
      plVar10 = (longlong *)(ulonglong)uVar17;
    }
    else {
      sStack_100 = 1;
      bVar3 = *(byte *)puStack_f8;
      switch(bVar3 & 0x1c) {
      default:
        if ((char)*(byte *)((longlong)puStack_f8 + 1) < '\0') {
          uStack_fe = (*(ushort *)((longlong)puStack_f8 + 1) & 0x7f) << 8 |
                      *(ushort *)((longlong)puStack_f8 + 1) >> 8;
          uStack_e8._0_2_ = 3;
          sVar19 = 3;
        }
        else {
          uStack_fe = (ushort)*(byte *)((longlong)puStack_f8 + 1);
          uStack_e8._0_2_ = 2;
        }
        uStack_e4 = ((ushort)(uStack_fe + 1) >> 1) + sVar19;
        if (uStack_fe < 0x1f) {
          uStack_e8._2_2_ = 0;
          uStack_fc = 0;
          uStack_d0 = 0;
        }
        else {
          iVar7 = uStack_fe - 1;
          uStack_fc = 0;
          uStack_d0 = 0;
          uStack_e8._2_2_ =
               ((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
               (short)((longlong)iVar7 * 0x88888889 >> 0x3f);
        }
        break;
      case 4:
        if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
          uStack_e8._0_2_ = 0;
          uStack_e8._2_2_ = 0;
          uStack_e4 = 0;
          uStack_e2 = 0;
          uStack_fe = 0;
          uStack_e0 = 0;
          uStack_da = 0;
          uStack_fc = 0xf;
          uStack_d0 = 1;
        }
        else {
          uStack_e8._0_2_ = 0;
          uStack_e8._2_2_ = 0;
          uStack_e4 = 0;
          uStack_e2 = 0;
          uStack_fe = 0;
          uStack_e0 = 0;
          uStack_da = 0;
          uStack_fc = 1;
          uStack_d0 = 0;
        }
        break;
      case 8:
        uStack_e8._0_2_ = 0;
        uStack_e8._2_2_ = 0;
        uStack_e4 = 0;
        uStack_e2 = 0;
        uStack_fe = 0;
        uStack_e0 = 0;
        uStack_da = 0;
        uStack_fc = 9;
        uStack_d0 = 0;
      }
      lVar8 = lVar8 + 0x2000;
      uStack_d8 = (undefined2)lVar8;
      uStack_d6 = (ushort)((ulonglong)lVar8 >> 0x10);
      uStack_d4 = (ushort)((ulonglong)lVar8 >> 0x20);
      uStack_d2 = (undefined2)((ulonglong)lVar8 >> 0x30);
      uStack_f0 = plVar10;
    }
    puVar2 = (uint *)(lVar11 + 0x210);
    if (sStack_100 == 0) {
      uVar24 = *puVar2;
      if ((uVar24 & 0xc0000000) == 0x80000000) {
        iVar7 = func_0x(&uStack_fe);
        if (iVar7 != 0) {
          plVar10 = (longlong *)func_0x(&uStack_d6,puVar2,&uStack_168,&uStack_148);
          goto code_r0x00100fae;
        }
        uStack_168 = 0;
        uVar17 = uVar13;
      }
      else {
        uVar12 = *(ushort *)(lVar11 + 0x216);
        if ((uVar12 & 0x10) != 0) {
          if ((*(byte *)puStack_f8 & 0x10) == 0) {
            if ((1 << (*(byte *)puStack_f8 & 0xe) & 0x1105U) == 0) goto code_r0x00100706;
          }
          else if ((int)uVar24 < (int)plVar10) {
            if (*(ushort *)(((ulonglong)plVar10 & 0xffffffff) + (longlong)puStack_f8) <
                *(ushort *)(lVar11 + 0x214)) {
              uStack_168 = **(uint **)(lVar11 + 0x218);
              uVar17 = (int)*(uint **)(lVar11 + 0x218) + 4;
              goto code_r0x00100fb1;
            }
            goto code_r0x00100706;
          }
          goto code_r0x00100e8b;
        }
code_r0x00100706:
        if ((int)uVar24 < 0) {
          puVar18 = puStack_f8;
          if (uStack_fc == 0) {
            uVar20 = (ulonglong)uStack_f0 & 0xffffffff;
            uStack_fe = 0;
            uVar24 = (uint)uStack_f0;
            if ((*(byte *)puStack_f8 & 0x10) != 0) {
              uVar24 = (uint)uStack_f0 + 2 + (*(ushort *)(uVar20 + (longlong)puStack_f8) + 7 >> 3);
              uVar20 = (ulonglong)uVar24;
            }
            uStack_f0 = (longlong *)CONCAT44(uVar24,(uint)uStack_f0);
            uVar24 = (uint)uVar20;
            if ((*(byte *)puStack_f8 & 0x20) == 0) {
              uStack_e4 = 0;
              uStack_fc = uVar24;
            }
            else {
              puVar21 = (ushort *)(uVar20 + (longlong)puStack_f8);
              uStack_e4 = *puVar21;
              if (uStack_e4 == 0) {
                cVar6 = func_0x(0x20c0e40);
                if (((cVar6 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
                   (*(char *)(lVar8 + 0x499) != '\0')) {
                  cVar6 = func_0x(0x20c0e40);
                  if (cVar6 == '\0') {
                    (*pcRam000000000162e9c8)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_1d8 = (uint *)0x0;
                    (*pcRam000000000162e9c0)(1,0x19b084c,0x1ad0938,0x80f);
                  }
                }
                func_0x(puStack_f8,3);
              }
              uStack_e8 = uStack_f0._4_4_ + (uStack_e4 + 1) * 2;
              if (0x1f9e < uStack_e8) {
                cVar6 = func_0x(0x20c0e40);
                if (cVar6 != '\0') {
                  lVar8 = func_0x();
                  if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
                    cVar6 = func_0x(0x20c0e40);
                    if (cVar6 == '\0') {
                      (*pcRam000000000162e9c8)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_1d8 = (uint *)0x0;
                      (*pcRam000000000162e9c0)(1,0x19b084c,0x1ad0938,0x816);
                    }
                  }
                }
                func_0x(puStack_f8,4);
              }
              uStack_fc = puVar21[uStack_e4] & 0x7fff;
              if (uStack_fc < uStack_e8) {
                cVar6 = func_0x(0x20c0e40);
                if (cVar6 != '\0') {
                  lVar8 = func_0x();
                  if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
                    cVar6 = func_0x(0x20c0e40);
                    if (cVar6 == '\0') {
                      (*pcRam000000000162e9c8)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_1d8 = (uint *)0x0;
                      (*pcRam000000000162e9c0)(1,0x19b084c,0x1ad0938,0x81d);
                    }
                  }
                }
                func_0x(puStack_f8,4);
              }
              puVar18 = puStack_f8;
              plVar10 = plVar15;
              puVar4 = puVar21;
              uVar24 = uStack_e8;
              if (uStack_e4 != 0) {
                do {
                  uVar17 = puVar4[1] & 0x7fff;
                  if ((uVar17 < uStack_e8) || (uStack_fc < uVar17)) {
                    uStack_e8 = uVar24;
                    cVar6 = func_0x(0x20c0e40);
                    if (cVar6 != '\0') {
                      lVar8 = func_0x();
                      if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
                        cVar6 = func_0x(0x20c0e40);
                        if (cVar6 == '\0') {
                          (*pcRam000000000162e9c8)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_1d8 = (uint *)0x0;
                          (*pcRam000000000162e9c0)(1,0x19b084c,0x1ad0938,0x82a);
                        }
                      }
                    }
                    func_0x(puStack_f8,4);
                    puVar18 = puStack_f8;
                    uVar24 = uStack_e8;
                  }
                  uVar22 = (int)plVar10 + 1;
                  plVar10 = (longlong *)(ulonglong)uVar22;
                  uStack_e8 = uVar17;
                  puVar4 = puVar4 + 1;
                } while ((int)uVar22 < (int)(uint)uStack_e4);
              }
              while( true ) {
                if (-1 < (short)puVar21[(ulonglong)(uStack_e4 - 1) + 1]) break;
                uVar17 = uVar24;
                if (uStack_e4 != 1) {
                  uVar17 = *(ushort *)
                            ((longlong)puVar18 +
                            (ulonglong)uStack_e4 * 2 + (((ulonglong)uStack_f0 >> 0x20) - 2)) &
                           0x7fff;
                }
                uVar22 = *(ushort *)
                          ((longlong)puVar18 +
                          (ulonglong)uStack_e4 * 2 + ((ulonglong)uStack_f0 >> 0x20)) & 0x7fff;
                if (((uVar17 < uVar24) || (uVar22 < uVar17)) || (uStack_fc < uVar22)) {
                  uStack_e8 = uVar24;
                  func_0x(puVar18,7);
                  puVar18 = puStack_f8;
                  uVar24 = uStack_e8;
                }
                uStack_e8 = uVar24;
                if ((uVar17 < uVar24) || (uStack_fc < uVar17)) goto code_r0x00100e29;
                if (*(ushort *)((longlong)puVar18 + (ulonglong)uVar17) == 5) {
                  uStack_fe = uStack_fe | 2;
                  uStack_e4 = uStack_e4 - 1;
                  uVar20 = (ulonglong)(uVar17 & 0xffff);
                  pbVar1 = (byte *)(uVar20 + (longlong)puVar18);
                  uStack_d6 = (ushort)uVar17;
                  if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                    uVar12 = uStack_d4 & 0xc7ff;
                  }
                  else {
                    uVar12 = uStack_d4 ^ (uStack_d4 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                  }
                  uStack_d4 = (uVar12 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar12;
                  pbVar23 = (byte *)((longlong)puVar18 +
                                    uVar20 + (ulonglong)((uStack_d4 & 0x7ff) * 2) + 4 +
                                             (ulonglong)((uVar12 >> 0xb & 7) * 2));
                  if (pbVar23 < pbVar1) {
                    func_0x(pbVar1,0x19);
                    uVar20 = (ulonglong)uStack_d6;
                    puVar18 = puStack_f8;
                  }
                  uVar24 = uStack_e8;
                  if (uVar22 - uVar17 <
                      (((uStack_d4 & 0x7ff) * 2 - (int)uVar20) - (int)puStack_f8) + (int)pbVar23) {
                    func_0x((byte *)(uVar20 + (longlong)puVar18),0x19);
                    uVar20 = (ulonglong)uStack_d6;
                    puVar18 = puStack_f8;
                    uVar24 = uStack_e8;
                  }
                  if (((uStack_d4 & 0x3800) != 0) &&
                     (puVar21 = (ushort *)((longlong)puVar18 + uVar20 + 4), uVar12 = uStack_d4,
                     (uStack_d4 & 0x3800) != 0)) {
                    do {
                      if ((uVar12 & 0x7ff) < (*puVar21 & 0x7ff)) {
                        uStack_e8 = uVar24;
                        func_0x((byte *)(uVar20 + (longlong)puVar18),0x1a);
                        uVar20 = (ulonglong)uStack_d6;
                        puVar18 = puStack_f8;
                        uVar12 = uStack_d4;
                        uVar24 = uStack_e8;
                      }
                      uVar17 = (int)plVar15 + 1;
                      plVar15 = (longlong *)(ulonglong)uVar17;
                      puVar21 = puVar21 + 1;
                    } while ((int)uVar17 < (int)((uStack_d4 & 0x3800) >> 0xb));
                  }
                  break;
                }
                if (*(ushort *)((longlong)puVar18 + (ulonglong)uVar17) < 0x400) break;
                uStack_fe = uStack_fe | 1;
                uStack_e4 = uStack_e4 - 1;
                if (uStack_e4 == 0) break;
              }
            }
            if ((*(byte *)puVar18 & 0x40) == 0) {
              uStack_da = 0;
              uStack_d8 = 0;
            }
            else {
              uStack_da = (undefined2)uStack_fc;
              uStack_d8 = (undefined2)(uStack_fc >> 0x10);
              uStack_fc = uStack_fc + 0xe;
              uStack_e8 = uVar24;
              uVar9 = func_0x(&uStack_fe);
              func_0x(uVar9,&lStack_160);
              iVar7 = func_0x(&lStack_160);
              uStack_fc = uStack_fc + iVar7;
              puVar18 = puStack_f8;
              uVar24 = uStack_e8;
            }
            uStack_e8 = uVar24;
            if (((byte *)CONCAT62(uStack_e0,uStack_e2) != (byte *)0x0) &&
               ((byte *)CONCAT62(uStack_e0,uStack_e2) <
                (byte *)((ulonglong)uStack_fc + (longlong)puVar18))) {
              cVar6 = func_0x(0x20c0e40);
              if (cVar6 != '\0') {
                lVar8 = func_0x();
                if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
                  cVar6 = func_0x(0x20c0e40);
                  if (cVar6 == '\0') {
                    (*pcRam000000000162e9c8)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_1d8 = (uint *)0x0;
                    (*pcRam000000000162e9c0)(1,0x19b084c,0x1ad0938,0x886);
                  }
                }
              }
              func_0x(puStack_f8,0x12);
              puVar18 = puStack_f8;
            }
            if (0x3f3b < uStack_fc - 1) {
              cVar6 = func_0x(0x20c0e40);
              if (cVar6 != '\0') {
                lVar8 = func_0x();
                if ((lVar8 != 0) && (*(char *)(lVar8 + 0x499) != '\0')) {
                  cVar6 = func_0x(0x20c0e40);
                  if (cVar6 == '\0') {
                    (*pcRam000000000162e9c8)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_1d8 = (uint *)0x0;
                    (*pcRam000000000162e9c0)(1,0x19b084c,0x1ad0938,0x88b);
                  }
                }
              }
              func_0x(puStack_f8,5);
              puVar18 = puStack_f8;
            }
          }
code_r0x00100e29:
          sVar19 = -*(short *)puVar2;
          if ((*(byte *)(lVar11 + 0x216) & 0x10) != 0) {
            if ((*(byte *)puVar18 & 0x10) == 0) {
              if ((1 << (*(byte *)puVar18 & 0xe) & 0x1105U) != 0) {
code_r0x00100e8b:
                uStack_168 = **(uint **)(lVar11 + 0x218);
                uVar17 = (int)*(uint **)(lVar11 + 0x218) + 4;
                goto code_r0x00100fb1;
              }
            }
            else if (((int)(uint)uStack_f0 <= (int)*puVar2) ||
                    (*(ushort *)(((ulonglong)uStack_f0 & 0xffffffff) + (longlong)puVar18) <
                     *(ushort *)(lVar11 + 0x214))) goto code_r0x00100e8b;
          }
          if ((uint)uStack_e4 < (uint)(int)sVar19) {
code_r0x00100eec:
            uVar17 = (uint)puVar18;
            uStack_168 = uVar13;
          }
          else {
            uVar13 = uStack_e8;
            if (sVar19 != 1) {
              uVar13 = *(ushort *)
                        ((longlong)puVar18 +
                        (longlong)sVar19 * 2 + (((ulonglong)uStack_f0 >> 0x20) - 2)) & 0x7fff;
            }
            uVar24 = *(ushort *)
                      ((longlong)puVar18 + (longlong)sVar19 * 2 + ((ulonglong)uStack_f0 >> 0x20)) &
                     0x7fff;
            if (((uVar13 < uStack_e8) || (uVar24 < uVar13)) || (uStack_fc < uVar24)) {
              func_0x(puVar18,7);
              puVar18 = puStack_f8;
            }
            uStack_168 = uVar24 - uVar13;
            uVar17 = uVar13 + (int)puVar18;
          }
        }
        else {
          if ((uVar12 & 8) != 0) {
            uVar17 = 0x17354e0;
            uStack_168 = 1;
            if ((*(byte *)((longlong)puStack_f8 + (longlong)(int)uVar24) &
                (byte)(1 << ((byte)uVar12 & 7))) == 0) {
              uVar17 = 0x17354e1;
            }
            goto code_r0x00100fb1;
          }
          if ((uVar12 & 0x10) != 0) {
            if ((*(byte *)puStack_f8 & 0x10) == 0) {
              if ((1 << (*(byte *)puStack_f8 & 0xe) & 0x1105U) != 0) {
code_r0x0010078b:
                uVar13 = **(uint **)(lVar11 + 0x218);
                puVar18 = *(uint **)(lVar11 + 0x218) + 1;
                if (uVar13 != 6) {
                  uStack_1d8 = (uint *)0x0;
                  (*pcRam000000000162e9c0)(1,0x1b5ec90,0x1b5d5f8,0x381);
                  uVar17 = (uint)puVar18;
                  uStack_168 = uVar13;
                  goto code_r0x00100fb1;
                }
                goto code_r0x00100eec;
              }
            }
            else if (((int)(uint)uStack_f0 <= (int)uVar24) ||
                    (*(ushort *)(((ulonglong)uStack_f0 & 0xffffffff) + (longlong)puStack_f8) <
                     *(ushort *)(lVar11 + 0x214))) goto code_r0x0010078b;
          }
          uStack_168 = 6;
          uVar17 = (int)puStack_f8 + uVar24;
        }
      }
    }
    else {
      uStack_1d8 = &uStack_164;
      uStack_164 = 0;
      plVar10 = (longlong *)func_0x(&uStack_fe,puVar2);
      if ((((sStack_100 != 0) && (uStack_f0 != (longlong *)0x0)) && (*uStack_f0 != 0)) &&
         (((*(byte *)(lVar11 + 0x216) & 8) == 0 && ((uStack_164 & 1) == 0)))) {
        if ((plVar10 == (longlong *)0x0) || (plVar10 == (longlong *)0x17354e0)) {
          uStack_168 = 0;
          plVar10 = plVar15;
        }
        else {
          uStack_1c0 = CONCAT44(uStack_1c0._4_4_,uStack_164);
          uStack_1c8 = &uStack_168;
          uStack_1d8 = auStack_50;
          uStack_1d0 = 6;
          plVar10 = (longlong *)func_0x(uStack_f0,puVar2,plVar10,uStack_168);
        }
      }
code_r0x00100fae:
      uVar17 = (uint)plVar10;
    }
code_r0x00100fb1:
    uStack_170 = 0;
    uStack_178 = 0;
    uStack_180 = 0;
    uStack_188 = 0;
    uStack_190 = 0;
    uStack_198 = 0;
    uStack_1a0 = 0;
    uStack_1a8 = uStack_130;
    uStack_1b8 = *(undefined4 *)(lStack_128 + 0x100);
    uStack_1b0 = 0;
    uStack_1c0 = uStack_120;
    uStack_1c8 = (uint *)CONCAT44(uStack_1c8._4_4_,6);
    uStack_1d0 = 6;
    uStack_1d8 = (uint *)CONCAT44(uStack_1d8._4_4_,uVar17 - (int)puStack_f8);
    iVar7 = func_0x
                      (pplStack_110,lStack_118,&uStack_138,*(undefined4 *)(lStack_128 + 0x30));
    if (iVar7 != 0) {
      uStack_1d8 = (uint *)0x0;
      (*pcRam000000000162e9c0)(1,0x1b5e960,0x1b350f8,0x358);
    }
  }
  else {
    (**(code **)(**(longlong **)(lStack_108 + 8) + 0xa0))
              (*(longlong **)(lStack_108 + 8),param_2,param_4);
  }
  lVar8 = *(longlong *)(*(longlong *)(lStack_108 + 8) + 0x488);
  if (((lVar8 != 0) && (*_DAT_ != '\0')) && ((DAT_ & 2) == 0)) {
    if (*(longlong *)(lVar8 + 0x20) != 0) {
      lVar16 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar11 = *(longlong *)(lVar16 + 0x100);
      if (lVar11 == 0) {
        (*_DAT_)(0);
        lVar11 = *(longlong *)(lVar16 + 0x100);
      }
      if (*(longlong *)(lVar11 + 0x260) != 0) {
        uVar14 = *(uint *)(*(longlong *)(lVar11 + 0x260) + 0xe68);
      }
      if (uVar14 < *(uint *)(_DAT_ + 8)) {
        lVar8 = *(longlong *)(*(longlong *)(lVar8 + 0x20) + (ulonglong)uVar14 * 8);
        *(longlong *)(lVar8 + 0x30) = *(longlong *)(lVar8 + 0x30) + 1;
        goto LAB_;
      }
    }
    LOCK();
    plVar15 = (longlong *)(*(longlong *)(lVar8 + 0x18) + 0x30);
    *plVar15 = *plVar15 + 1;
    UNLOCK();
  }
LAB_:
  func_0x(uStack_48 ^ (ulonglong)auStack_1f8);
  return;
}

