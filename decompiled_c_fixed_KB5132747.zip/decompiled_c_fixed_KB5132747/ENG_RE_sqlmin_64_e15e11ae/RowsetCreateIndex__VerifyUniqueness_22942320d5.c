
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,longlong param_3)

{
  ushort *puVar1;
  longlong lVar2;
  longlong *plVar3;
  short *psVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  longlong lVar8;
  undefined8 uVar9;
  ulonglong *puVar10;
  uint *puVar11;
  uint uVar12;
  byte bVar13;
  uint uVar14;
  ulonglong uVar15;
  int iVar16;
  uint uVar17;
  uint *puVar18;
  ulonglong uVar19;
  short sVar20;
  uint *puVar21;
  ulonglong uVar22;
  byte *pbVar23;
  ulonglong uVar24;
  ushort *puVar25;
  uint **ppuVar26;
  int iVar27;
  int iVar28;
  uint *puVar29;
  uint uVar30;
  ushort *puVar31;
  short *psVar32;
  undefined auStack_108 [32];
  undefined8 uStack_e8;
  longlong *plStack_e0;
  uint *puStack_d8;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  uint auStack_b8 [2];
  longlong lStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  byte abStack_98 [8];
  longlong lStack_90;
  undefined2 *puStack_88;
  ushort *puStack_80;
  short *psStack_78;
  longlong lStack_70;
  longlong lStack_68;
  undefined auStack_60 [8];
  undefined8 uStack_58;
  uint *puStack_50;
  undefined2 uStack_48;
  undefined2 auStack_46 [3];
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_108;
  lStack_68 = param_1 + 0x2c8;
  ppuVar26 = &puStack_50;
  lStack_b0 = *(longlong *)(param_1 + 0x48);
  puVar1 = (ushort *)(param_1 + 0x192);
  iVar27 = *(int *)(**(longlong **)(*(longlong *)(lStack_b0 + 8) + 0x160) + 0x1c);
  iVar16 = iVar27 + -1;
  if ((*(byte *)(*(longlong *)(lStack_b0 + 8) + 0x106) & 0x40) == 0) {
    iVar16 = iVar27;
  }
  puStack_88 = auStack_46;
  uStack_58 = *(undefined8 *)(param_1 + 0x198);
  uVar17 = (uint)(iVar16 != 0);
  uVar14 = *(uint *)(param_1 + 0x194);
  iVar27 = 0;
  uStack_a8 = (uint **)CONCAT44(uStack_a8._4_4_,uVar17);
  uStack_a0 = ppuVar26;
  lStack_90 = param_3;
  psStack_78 = param_2;
  lStack_70 = param_1;
  if (*(short *)(param_1 + 400) == 0) {
    if (uVar14 == 0) {
      pbVar23 = *(byte **)(param_1 + 0x198);
      uVar14 = *(uint *)(param_1 + 0x1a0);
      uVar15 = (ulonglong)uVar14;
      *puVar1 = 0;
      *(uint *)(param_1 + 0x1a4) = uVar14;
      bVar13 = *pbVar23;
      if ((bVar13 & 0x10) != 0) {
        uVar14 = uVar14 + 2 + (*(ushort *)(pbVar23 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar14;
        *(uint *)(param_1 + 0x1a4) = uVar14;
        bVar13 = *pbVar23;
      }
      if ((bVar13 & 0x20) == 0) {
        *(int *)(param_1 + 0x194) = (int)uVar15;
        *(undefined2 *)(param_1 + 0x1ac) = 0;
        *(int *)(param_1 + 0x1a8) = (int)uVar15;
      }
      else {
        puVar31 = (ushort *)(pbVar23 + uVar15);
        uVar6 = *puVar31;
        *(ushort *)(param_1 + 0x1ac) = uVar6;
        if (uVar6 == 0) {
          cVar5 = func_0x(0x118f5b0);
          if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar5 = func_0x(0x118f5b0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_e8 = (undefined8 *)0x0;
              (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 0x198),3);
          uVar15 = (ulonglong)*(uint *)(param_1 + 0x1a4);
          uVar6 = *(ushort *)(param_1 + 0x1ac);
        }
        uVar14 = (int)uVar15 + (uVar6 + 1) * 2;
        *(uint *)(param_1 + 0x1a8) = uVar14;
        if (0x1f9e < uVar14) {
          cVar5 = func_0x(0x118f5b0);
          if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar5 = func_0x(0x118f5b0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_e8 = (undefined8 *)0x0;
              (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 0x198),4);
          uVar6 = *(ushort *)(param_1 + 0x1ac);
          uVar14 = *(uint *)(param_1 + 0x1a8);
        }
        uVar15 = (ulonglong)uVar6;
        uVar6 = puVar31[uVar15];
        *(uint *)(param_1 + 0x194) = uVar6 & 0x7fff;
        if ((uVar6 & 0x7fff) < uVar14) {
          cVar5 = func_0x(0x118f5b0);
          if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar5 = func_0x(0x118f5b0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_e8 = (undefined8 *)0x0;
              (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 0x198),4);
          uVar14 = *(uint *)(param_1 + 0x1a8);
          uVar15 = (ulonglong)*(ushort *)(param_1 + 0x1ac);
        }
        puVar25 = puVar31;
        if ((short)uVar15 != 0) {
          do {
            uVar17 = puVar25[1] & 0x7fff;
            if ((uVar17 < uVar14) || (*(uint *)(param_1 + 0x194) < uVar17)) {
              cVar5 = func_0x(0x118f5b0);
              if ((cVar5 != '\0') &&
                 ((lVar8 = func_0x(), lVar8 != 0 &&
                  (*(char *)(lVar8 + 0x499) != '\0')))) {
                cVar5 = func_0x(0x118f5b0);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_e8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x82a);
                }
              }
              func_0x(*(undefined8 *)(param_1 + 0x198),4);
            }
            uVar15 = (ulonglong)*(ushort *)(param_1 + 0x1ac);
            iVar27 = iVar27 + 1;
            puVar25 = puVar25 + 1;
            uVar14 = uVar17;
          } while (iVar27 < (int)(uint)*(ushort *)(param_1 + 0x1ac));
        }
        if ((short)puVar31[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          pbVar23 = *(byte **)(param_1 + 0x198);
          do {
            uVar17 = *(ushort *)(pbVar23 + uVar15 * 2 + (ulonglong)*(uint *)(param_1 + 0x1a4)) &
                     0x7fff;
            if ((int)uVar15 == 1) {
              uVar30 = *(uint *)(param_1 + 0x1a8);
              uVar19 = (ulonglong)uVar30;
LAB_:
              if ((uVar17 < (uint)uVar19) || (uVar14 = *(uint *)(param_1 + 0x194), uVar14 < uVar17))
              goto LAB_;
            }
            else {
              uVar30 = *(uint *)(param_1 + 0x1a8);
              uVar19 = (ulonglong)
                       (*(ushort *)
                         (pbVar23 + uVar15 * 2 + ((ulonglong)*(uint *)(param_1 + 0x1a4) - 2)) &
                       0x7fff);
              if (uVar30 <= (*(ushort *)
                              (pbVar23 + uVar15 * 2 + ((ulonglong)*(uint *)(param_1 + 0x1a4) - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
              func_0x(pbVar23,7);
              uVar30 = *(uint *)(param_1 + 0x1a8);
              uVar14 = *(uint *)(param_1 + 0x194);
            }
            uVar12 = (uint)uVar19;
            if ((uVar12 < uVar30) || (uVar14 < uVar12)) goto LAB_;
            pbVar23 = *(byte **)(param_1 + 0x198);
            if (*(ushort *)(pbVar23 + uVar19) == 5) {
              *puVar1 = *puVar1 | 2;
              *(short *)(param_1 + 0x1ac) = *(short *)(param_1 + 0x1ac) + -1;
              uVar6 = *(ushort *)(param_1 + 0x1bc) & 0xc7ff;
              uVar22 = uVar19 & 0xffff;
              *(short *)(param_1 + 0x1ba) = (short)uVar19;
              uVar15 = *(ulonglong *)(param_1 + 0x198);
              if ((*(ushort *)(uVar22 + 2 + uVar15) >> 0xe & 1) != 0) {
                uVar6 = *(ushort *)(uVar22 + 2 + uVar15) & 0x3800 | uVar6;
              }
              *(ushort *)(param_1 + 0x1bc) = uVar6;
              uVar7 = (uVar6 ^ *(ushort *)(uVar22 + 2 + uVar15)) & 0x7ff ^ uVar6;
              *(ushort *)(param_1 + 0x1bc) = uVar7;
              uVar19 = uVar15 + 4 +
                       (ulonglong)((uVar7 & 0x7ff) * 2) + uVar22 + (uVar6 >> 0xb & 7) * 2;
              if (uVar19 < uVar22 + uVar15) {
                func_0x(uVar22 + uVar15,0x19);
                uVar7 = *(ushort *)(param_1 + 0x1bc);
                uVar22 = (ulonglong)*(ushort *)(param_1 + 0x1ba);
                uVar15 = (ulonglong)*(uint *)(param_1 + 0x198);
              }
              if (uVar17 - uVar12 <
                  (((uVar7 & 0x7ff) * 2 - (int)uVar22) - (int)uVar15) + (int)uVar19) {
                func_0x(uVar22 + *(longlong *)(param_1 + 0x198),0x19);
                uVar7 = *(ushort *)(param_1 + 0x1bc);
              }
              if ((uVar7 & 0x3800) != 0) {
                puVar31 = (ushort *)
                          (*(longlong *)(param_1 + 0x198) +
                          (ulonglong)*(ushort *)(param_1 + 0x1ba) + 4);
                iVar27 = 0;
                if ((uVar7 & 0x3800) != 0) {
                  do {
                    if ((uVar7 & 0x7ff) < (*puVar31 & 0x7ff)) {
                      func_0x((ulonglong)*(ushort *)(param_1 + 0x1ba) +
                                      *(longlong *)(param_1 + 0x198),0x1a);
                      uVar7 = *(ushort *)(param_1 + 0x1bc);
                    }
                    iVar27 = iVar27 + 1;
                    puVar31 = puVar31 + 1;
                  } while (iVar27 < (int)(uVar7 >> 0xb & 7));
                }
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar23 + uVar19) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar6 = *(short *)(param_1 + 0x1ac) - 1;
            *(ushort *)(param_1 + 0x1ac) = uVar6;
            if (uVar6 == 0) goto LAB_;
            uVar15 = (ulonglong)uVar6;
          } while ((short)puVar31[(ulonglong)(uVar6 - 1) + 1] < 0);
          uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
        }
        else {
LAB_:
          pbVar23 = *(byte **)(param_1 + 0x198);
          uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
        }
      }
      if ((*pbVar23 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x1b6) = 0;
      }
      else {
        *(int *)(param_1 + 0x1b6) = (int)uVar15;
        *(int *)(param_1 + 0x194) = (int)uVar15 + 0xe;
        uVar9 = func_0x(puVar1);
        func_0x(uVar9,&puStack_80);
        iVar27 = func_0x(&puStack_80);
        *(int *)(param_1 + 0x194) = *(int *)(param_1 + 0x194) + iVar27;
        uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
      }
      uVar14 = (uint)uVar15;
      if ((*(ulonglong *)(param_1 + 0x1ae) != 0) &&
         (*(ulonglong *)(param_1 + 0x1ae) < uVar15 + *(longlong *)(param_1 + 0x198))) {
        cVar5 = func_0x(0x118f5b0);
        if ((cVar5 != '\0') &&
           ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))))
        {
          cVar5 = func_0x(0x118f5b0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_e8 = (undefined8 *)0x0;
            (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x886);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 0x198),0x12);
        uVar14 = *(uint *)(param_1 + 0x194);
      }
      if ((uVar14 == 0) || (0x3f3c < uVar14)) {
        cVar5 = func_0x(0x118f5b0);
        if ((cVar5 != '\0') &&
           ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))))
        {
          cVar5 = func_0x(0x118f5b0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_e8 = (undefined8 *)0x0;
            (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x88b);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 0x198),5);
        uVar14 = *(uint *)(param_1 + 0x194);
      }
    }
LAB_:
    if ((uVar14 < 9) &&
       ((bVar13 = **(byte **)(param_1 + 0x198) & 0xe, bVar13 == 0 || (bVar13 == 0xc)))) {
      uVar14 = 9;
    }
    lVar8 = lStack_70;
    uVar17 = (uint)uStack_a8;
  }
  else {
    if (uVar14 == 0) {
      func_0x(puVar1);
      uVar14 = *(uint *)(param_1 + 0x194);
    }
    lVar8 = param_1;
    if ((uVar14 < 9) &&
       (((**(byte **)(param_1 + 0x198) & 0x1c) == 0 ||
        ((**(byte **)(param_1 + 0x198) & 0x1c) == 0xc)))) {
      uVar14 = 9;
    }
  }
  uVar15 = 0;
  uStack_48 = (undefined2)uVar14;
  if (uVar17 != 0) {
    do {
      puVar18 = (uint *)0x0;
      lVar2 = **(longlong **)(*(longlong *)(lStack_b0 + 8) + 0x160);
      puVar11 = *(uint **)(lVar2 + 0x38);
      puVar21 = (uint *)(lVar2 + 0x30);
      if (puVar11 == puVar21) {
        puVar11 = puVar18;
      }
      puVar29 = puVar18;
      if (puVar11 != (uint *)0x0) {
        puVar29 = puVar11 + -0x58;
      }
      iVar27 = (int)uVar15;
      if (iVar27 != 0) {
        do {
          puVar11 = *(uint **)(puVar29 + 0x5a);
          if (*(uint **)(puVar29 + 0x5a) == puVar21) {
            puVar11 = puVar18;
          }
          puVar29 = puVar18;
          if (puVar11 != (uint *)0x0) {
            puVar29 = puVar11 + -0x58;
          }
          uVar15 = uVar15 - 1;
        } while (uVar15 != 0);
      }
      bVar13 = *(byte *)(puVar29 + 8);
      if (*(short *)(lVar8 + 400) == 0) {
        uVar14 = *puVar29;
        if ((uVar14 & 0xc0000000) == 0x80000000) {
          iVar16 = func_0x(puVar1);
          if (iVar16 == 0) {
            auStack_b8[0] = 0;
          }
          else {
            puVar18 = (uint *)func_0x(param_1 + 0x1ba,puVar29,auStack_b8,&uStack_a0);
          }
        }
        else {
          uVar17 = (uint)uStack_a8;
          if (((bVar13 & 2) != 0) || ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0)) {
            pbVar23 = *(byte **)(param_1 + 0x198);
            if ((*pbVar23 & 0x10) == 0) {
              if ((1 << (*pbVar23 & 0xe) & 0x1105U) != 0) goto LAB_;
              puVar11 = (uint *)0x1;
              puVar21 = puVar18;
LAB_:
              uVar30 = (uint)puVar21;
              iVar16 = (int)puVar11;
              if ((bVar13 & 2) != 0) goto LAB_;
            }
            else {
              uVar30 = *(uint *)(param_1 + 0x1a0);
              if ((int)uVar30 <= (int)uVar14) {
LAB_:
                puVar21 = (uint *)(ulonglong)(~(uint)(*(ushort *)((longlong)puVar29 + 6) >> 4) & 1);
                puVar11 = puVar18;
                goto LAB_;
              }
              if ((uint)*(ushort *)(pbVar23 + uVar30) < (uint)*(ushort *)(puVar29 + 1))
              goto LAB_;
              if ((bVar13 & 2) == 0) goto LAB_;
              uVar12 = *(ushort *)(puVar29 + 1) - 1;
              iVar16 = 1;
              uVar30 = pbVar23[(ulonglong)uVar30 + (ulonglong)(uVar12 >> 3) + 2] >>
                       ((byte)uVar12 & 7) & 1;
LAB_:
              if (uVar30 != 0) {
                auStack_b8[0] = 0;
                goto LAB_;
              }
            }
            if ((iVar16 == 0) && ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0)) {
              puVar18 = *(uint **)(puVar29 + 2) + 1;
              auStack_b8[0] = **(uint **)(puVar29 + 2);
              goto LAB_;
            }
          }
LAB_:
          if ((int)uVar14 < 0) {
            if (*(int *)(param_1 + 0x194) == 0) {
              pbVar23 = *(byte **)(param_1 + 0x198);
              uVar14 = *(uint *)(param_1 + 0x1a0);
              uVar15 = (ulonglong)uVar14;
              *puVar1 = 0;
              *(uint *)(param_1 + 0x1a4) = uVar14;
              bVar13 = *pbVar23;
              if ((bVar13 & 0x10) != 0) {
                uVar14 = uVar14 + 2 + (*(ushort *)(pbVar23 + uVar15) + 7 >> 3);
                uVar15 = (ulonglong)uVar14;
                *(uint *)(param_1 + 0x1a4) = uVar14;
                bVar13 = *pbVar23;
              }
              if ((bVar13 & 0x20) == 0) {
                *(int *)(param_1 + 0x194) = (int)uVar15;
                *(undefined2 *)(param_1 + 0x1ac) = 0;
                *(int *)(param_1 + 0x1a8) = (int)uVar15;
              }
              else {
                puVar31 = (ushort *)(pbVar23 + uVar15);
                uVar6 = *puVar31;
                *(ushort *)(param_1 + 0x1ac) = uVar6;
                puStack_80 = puVar31;
                if (uVar6 == 0) {
                  cVar5 = func_0x(0x118f5b0);
                  if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
                     (*(char *)(lVar8 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x118f5b0);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_e8 = (undefined8 *)0x0;
                      (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x80f);
                    }
                  }
                  func_0x(*(undefined8 *)(param_1 + 0x198),3);
                  uVar15 = (ulonglong)*(uint *)(param_1 + 0x1a4);
                  uVar6 = *(ushort *)(param_1 + 0x1ac);
                }
                uVar14 = (int)uVar15 + (uVar6 + 1) * 2;
                *(uint *)(param_1 + 0x1a8) = uVar14;
                if (0x1f9e < uVar14) {
                  cVar5 = func_0x(0x118f5b0);
                  if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
                     (*(char *)(lVar8 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x118f5b0);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_e8 = (undefined8 *)0x0;
                      (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x816);
                    }
                  }
                  func_0x(*(undefined8 *)(param_1 + 0x198),4);
                  uVar6 = *(ushort *)(param_1 + 0x1ac);
                  uVar14 = *(uint *)(param_1 + 0x1a8);
                }
                uVar15 = (ulonglong)uVar6;
                uVar6 = puVar31[uVar15];
                *(uint *)(param_1 + 0x194) = uVar6 & 0x7fff;
                if ((uVar6 & 0x7fff) < uVar14) {
                  cVar5 = func_0x(0x118f5b0);
                  if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
                     (*(char *)(lVar8 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x118f5b0);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_e8 = (undefined8 *)0x0;
                      (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x81d);
                    }
                  }
                  func_0x(*(undefined8 *)(param_1 + 0x198),4);
                  uVar14 = *(uint *)(param_1 + 0x1a8);
                  uVar15 = (ulonglong)*(ushort *)(param_1 + 0x1ac);
                }
                puVar25 = puVar31;
                if ((short)uVar15 != 0) {
                  do {
                    puVar31 = puVar31 + 1;
                    uVar17 = *puVar31 & 0x7fff;
                    if ((uVar17 < uVar14) || (*(uint *)(param_1 + 0x194) < uVar17)) {
                      cVar5 = func_0x(0x118f5b0);
                      if ((cVar5 != '\0') &&
                         ((lVar8 = func_0x(), lVar8 != 0 &&
                          (*(char *)(lVar8 + 0x499) != '\0')))) {
                        cVar5 = func_0x(0x118f5b0);
                        if (cVar5 == '\0') {
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_e8 = (undefined8 *)0x0;
                          (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x82a);
                        }
                      }
                      func_0x(*(undefined8 *)(param_1 + 0x198),4);
                    }
                    uVar15 = (ulonglong)*(ushort *)(param_1 + 0x1ac);
                    uVar30 = (int)puVar18 + 1;
                    puVar18 = (uint *)(ulonglong)uVar30;
                    puVar25 = puStack_80;
                    uVar14 = uVar17;
                  } while ((int)uVar30 < (int)(uint)*(ushort *)(param_1 + 0x1ac));
                }
                if ((short)puVar25[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                  pbVar23 = *(byte **)(param_1 + 0x198);
                  do {
                    uVar14 = *(ushort *)
                              (pbVar23 + uVar15 * 2 + (ulonglong)*(uint *)(param_1 + 0x1a4)) &
                             0x7fff;
                    if ((int)uVar15 == 1) {
                      uVar17 = *(uint *)(param_1 + 0x1a8);
                      uVar19 = (ulonglong)uVar17;
LAB_:
                      if ((uVar14 < (uint)uVar19) || (*(uint *)(param_1 + 0x194) < uVar14))
                      goto LAB_;
                    }
                    else {
                      uVar17 = *(uint *)(param_1 + 0x1a8);
                      uVar19 = (ulonglong)
                               (*(ushort *)
                                 (pbVar23 + uVar15 * 2 + ((ulonglong)*(uint *)(param_1 + 0x1a4) - 2)
                                 ) & 0x7fff);
                      if (uVar17 <= (*(ushort *)
                                      (pbVar23 +
                                      uVar15 * 2 + ((ulonglong)*(uint *)(param_1 + 0x1a4) - 2)) &
                                    0x7fff)) goto LAB_;
LAB_:
                      func_0x(pbVar23,7);
                      uVar17 = *(uint *)(param_1 + 0x1a8);
                    }
                    uVar30 = (uint)uVar19;
                    if ((uVar30 < uVar17) || (*(uint *)(param_1 + 0x194) < uVar30))
                    goto LAB_;
                    pbVar23 = *(byte **)(param_1 + 0x198);
                    if (*(ushort *)(pbVar23 + uVar19) == 5) {
                      *puVar1 = *puVar1 | 2;
                      *(short *)(param_1 + 0x1ac) = *(short *)(param_1 + 0x1ac) + -1;
                      uVar6 = *(ushort *)(param_1 + 0x1bc) & 0xc7ff;
                      uVar22 = uVar19 & 0xffff;
                      *(short *)(param_1 + 0x1ba) = (short)uVar19;
                      uVar15 = *(ulonglong *)(param_1 + 0x198);
                      if ((*(ushort *)(uVar22 + 2 + uVar15) >> 0xe & 1) != 0) {
                        uVar6 = *(ushort *)(uVar22 + 2 + uVar15) & 0x3800 | uVar6;
                      }
                      *(ushort *)(param_1 + 0x1bc) = uVar6;
                      uVar7 = (uVar6 ^ *(ushort *)(uVar22 + 2 + uVar15)) & 0x7ff ^ uVar6;
                      *(ushort *)(param_1 + 0x1bc) = uVar7;
                      uVar19 = uVar15 + 4 +
                               (ulonglong)((uVar7 & 0x7ff) * 2) + uVar22 + (uVar6 >> 0xb & 7) * 2;
                      if (uVar19 < uVar22 + uVar15) {
                        func_0x(uVar22 + uVar15,0x19);
                        uVar7 = *(ushort *)(param_1 + 0x1bc);
                        uVar22 = (ulonglong)*(ushort *)(param_1 + 0x1ba);
                        uVar15 = (ulonglong)*(uint *)(param_1 + 0x198);
                      }
                      if (uVar14 - uVar30 <
                          (((uVar7 & 0x7ff) * 2 - (int)uVar22) - (int)uVar15) + (int)uVar19) {
                        func_0x(uVar22 + *(longlong *)(param_1 + 0x198),0x19);
                        uVar7 = *(ushort *)(param_1 + 0x1bc);
                      }
                      if ((uVar7 & 0x3800) != 0) {
                        puVar31 = (ushort *)
                                  (*(longlong *)(param_1 + 0x198) +
                                  (ulonglong)*(ushort *)(param_1 + 0x1ba) + 4);
                        iVar16 = 0;
                        if ((uVar7 & 0x3800) != 0) {
                          do {
                            if ((uVar7 & 0x7ff) < (*puVar31 & 0x7ff)) {
                              func_0x((ulonglong)*(ushort *)(param_1 + 0x1ba) +
                                              *(longlong *)(param_1 + 0x198),0x1a);
                              uVar7 = *(ushort *)(param_1 + 0x1bc);
                            }
                            iVar16 = iVar16 + 1;
                            puVar31 = puVar31 + 1;
                          } while (iVar16 < (int)(uVar7 >> 0xb & 7));
                        }
                      }
                      goto LAB_;
                    }
                    if (*(ushort *)(pbVar23 + uVar19) < 0x400) goto LAB_;
                    *puVar1 = *puVar1 | 1;
                    uVar6 = *(short *)(param_1 + 0x1ac) - 1;
                    *(ushort *)(param_1 + 0x1ac) = uVar6;
                    if (uVar6 == 0) goto LAB_;
                    uVar15 = (ulonglong)uVar6;
                  } while ((short)puVar25[(ulonglong)(uVar6 - 1) + 1] < 0);
                  uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
                }
                else {
LAB_:
                  pbVar23 = *(byte **)(param_1 + 0x198);
                  uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
                }
              }
              iVar16 = 0;
              if ((*pbVar23 & 0x40) == 0) {
                *(undefined4 *)(param_1 + 0x1b6) = 0;
              }
              else {
                *(int *)(param_1 + 0x1b6) = (int)uVar15;
                *(int *)(param_1 + 0x194) = (int)uVar15 + 0xe;
                puVar10 = (ulonglong *)func_0x(puVar1);
                uVar7 = (ushort)(*puVar10 >> 0x30);
                uVar6 = uVar7;
                if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
                  uVar6 = uVar7 & 0xdfff;
                  if ((uVar7 >> 0xe & 1) != 0) {
                    uVar6 = uVar7 | 0x2000;
                  }
                }
                if (uVar6 == 0xfffc) {
                  iVar16 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(param_1 + 0x194) = *(int *)(param_1 + 0x194) + iVar16;
                uVar15 = (ulonglong)*(uint *)(param_1 + 0x194);
              }
              iVar16 = (int)uVar15;
              if ((*(ulonglong *)(param_1 + 0x1ae) != 0) &&
                 (*(ulonglong *)(param_1 + 0x1ae) < uVar15 + *(longlong *)(param_1 + 0x198))) {
                cVar5 = func_0x(0x118f5b0);
                if ((cVar5 != '\0') &&
                   ((lVar8 = func_0x(), lVar8 != 0 &&
                    (*(char *)(lVar8 + 0x499) != '\0')))) {
                  cVar5 = func_0x(0x118f5b0);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_e8 = (undefined8 *)0x0;
                    (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x886);
                  }
                }
                func_0x(*(undefined8 *)(param_1 + 0x198),0x12);
                iVar16 = *(int *)(param_1 + 0x194);
              }
              if (0x3f3b < iVar16 - 1U) {
                cVar5 = func_0x(0x118f5b0);
                if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
                   (*(char *)(lVar8 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x118f5b0);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_e8 = (undefined8 *)0x0;
                    (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x88b);
                  }
                }
                func_0x(*(undefined8 *)(param_1 + 0x198),5);
              }
            }
LAB_:
            sVar20 = -*(short *)puVar29;
            ppuVar26 = uStack_a0;
            lVar8 = lStack_70;
            uVar17 = (uint)uStack_a8;
            if ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0) {
              bVar13 = **(byte **)(param_1 + 0x198);
              if ((bVar13 & 0x10) == 0) {
                if ((1 << (bVar13 & 0xe) & 0x1105U) != 0) {
LAB_:
                  auStack_b8[0] = **(uint **)(puVar29 + 2);
                  puVar18 = *(uint **)(puVar29 + 2) + 1;
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(param_1 + 0x1a0) <= (int)*puVar29) ||
                      (*(ushort *)(*(byte **)(param_1 + 0x198) + *(uint *)(param_1 + 0x1a0)) <
                       *(ushort *)(puVar29 + 1))) goto LAB_;
            }
            puVar18 = *(uint **)(param_1 + 0x198);
            if ((uint)*(ushort *)(param_1 + 0x1ac) < (uint)(int)sVar20) {
              auStack_b8[0] = 0;
            }
            else {
              uVar14 = *(ushort *)
                        ((longlong)puVar18 +
                        (longlong)sVar20 * 2 + (ulonglong)*(uint *)(param_1 + 0x1a4)) & 0x7fff;
              if (sVar20 == 1) {
                uVar17 = *(uint *)(param_1 + 0x1a8);
LAB_:
                if ((uVar14 < uVar17) || (*(uint *)(param_1 + 0x194) < uVar14)) goto LAB_;
              }
              else {
                uVar17 = *(ushort *)
                          ((longlong)puVar18 +
                          (longlong)sVar20 * 2 + ((ulonglong)*(uint *)(param_1 + 0x1a4) - 2)) &
                         0x7fff;
                if (*(uint *)(param_1 + 0x1a8) <= uVar17) goto LAB_;
LAB_:
                func_0x(puVar18,7);
                puVar18 = *(uint **)(param_1 + 0x198);
              }
              auStack_b8[0] = uVar14 - uVar17;
              puVar18 = (uint *)((longlong)puVar18 + (ulonglong)uVar17);
              ppuVar26 = uStack_a0;
              lVar8 = lStack_70;
              uVar17 = (uint)uStack_a8;
            }
          }
          else {
            uVar6 = *(ushort *)((longlong)puVar29 + 6);
            if ((uVar6 & 8) == 0) {
              uVar30 = (uint)*(ushort *)(puVar29 + 0xe);
              if ((uVar6 & 0x10) != 0) {
                bVar13 = **(byte **)(param_1 + 0x198);
                if ((bVar13 & 0x10) == 0) {
                  if ((1 << (bVar13 & 0xe) & 0x1105U) != 0) {
LAB_:
                    uVar14 = **(uint **)(puVar29 + 2);
                    puVar18 = *(uint **)(puVar29 + 2) + 1;
                    if ((uVar30 != 0) && (uVar14 != uVar30)) {
                      uStack_e8 = (undefined8 *)0x0;
                      (*_DAT_)(1,0xc2d400,0xc2bd68,0x381);
                    }
                    uVar17 = (uint)uStack_a8;
                    auStack_b8[0] = uVar14;
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(param_1 + 0x1a0) <= (int)uVar14) ||
                        (*(ushort *)(*(byte **)(param_1 + 0x198) + *(uint *)(param_1 + 0x1a0)) <
                         *(ushort *)(puVar29 + 1))) goto LAB_;
              }
              puVar18 = (uint *)((longlong)(int)*puVar29 + *(longlong *)(param_1 + 0x198));
              auStack_b8[0] = uVar30;
            }
            else {
              puVar18 = (uint *)0x803c50;
              auStack_b8[0] = 1;
              if ((*(byte *)((longlong)(int)uVar14 + *(longlong *)(param_1 + 0x198)) &
                  (byte)(1 << ((byte)uVar6 & 7))) == 0) {
                puVar18 = (uint *)0x803c51;
              }
            }
          }
        }
      }
      else {
        uStack_e8 = &uStack_a0;
        uStack_a0 = (uint **)((ulonglong)uStack_a0 & 0xffffffff00000000);
        puVar18 = (uint *)func_0x(puVar1,puVar29,puVar21,auStack_b8);
        if ((((*(short *)(lVar8 + 400) != 0) &&
             (plVar3 = *(longlong **)(lVar8 + 0x1a0), plVar3 != (longlong *)0x0)) && (*plVar3 != 0))
           && (((*(byte *)((longlong)puVar29 + 6) & 8) == 0 && (((ulonglong)uStack_a0 & 1) == 0))))
        {
          if ((puVar18 == (uint *)0x0) || (puVar18 == (uint *)0x803c50)) {
            puVar18 = (uint *)0x0;
            auStack_b8[0] = 0;
          }
          else {
            uStack_d0 = CONCAT44(uStack_d0._4_4_,(uint)uStack_a0);
            puStack_d8 = auStack_b8;
            plStack_e0 = (longlong *)((ulonglong)plStack_e0 & 0xffffffff00000000);
            uStack_e8 = (undefined8 *)0x0;
            puVar18 = (uint *)func_0x(plVar3,puVar29,puVar18,auStack_b8[0]);
          }
        }
      }
LAB_:
      uVar14 = iVar27 + 1;
      uVar15 = (ulonglong)uVar14;
      *ppuVar26 = puVar18;
      ppuVar26 = ppuVar26 + 1;
      *puStack_88 = (undefined2)auStack_b8[0];
      puStack_88 = puStack_88 + 1;
      uStack_a0 = ppuVar26;
    } while (uVar14 < uVar17);
  }
  psVar4 = psStack_78;
  iVar28 = 0;
  lStack_b0 = *(longlong *)(lVar8 + 0x48);
  puVar1 = (ushort *)(psStack_78 + 1);
  ppuVar26 = (uint **)(lStack_90 + 0x10);
  iVar27 = *(int *)(**(longlong **)(*(longlong *)(lStack_b0 + 8) + 0x160) + 0x1c);
  iVar16 = iVar27 + -1;
  if ((*(byte *)(*(longlong *)(lStack_b0 + 8) + 0x106) & 0x40) == 0) {
    iVar16 = iVar27;
  }
  puStack_88 = (undefined2 *)(lStack_90 + 0x1a);
  uVar17 = (uint)(iVar16 != 0);
  *(undefined8 *)(lStack_90 + 8) = *(undefined8 *)(psStack_78 + 4);
  uVar14 = *(uint *)(psStack_78 + 2);
  uStack_a0 = (uint **)CONCAT44(uStack_a0._4_4_,uVar17);
  uStack_a8 = ppuVar26;
  if (*psStack_78 == 0) {
    if (uVar14 == 0) {
      pbVar23 = *(byte **)(psStack_78 + 4);
      uVar14 = *(uint *)(psStack_78 + 8);
      uVar15 = (ulonglong)uVar14;
      *puVar1 = 0;
      *(uint *)(psStack_78 + 10) = uVar14;
      bVar13 = *pbVar23;
      if ((bVar13 & 0x10) != 0) {
        uVar14 = uVar14 + 2 + (*(ushort *)(pbVar23 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar14;
        *(uint *)(psStack_78 + 10) = uVar14;
        bVar13 = *pbVar23;
      }
      if ((bVar13 & 0x20) == 0) {
        *(int *)(psStack_78 + 2) = (int)uVar15;
        psStack_78[0xe] = 0;
        *(int *)(psStack_78 + 0xc) = (int)uVar15;
      }
      else {
        puVar31 = (ushort *)(pbVar23 + uVar15);
        uVar6 = *puVar31;
        psStack_78[0xe] = uVar6;
        if (uVar6 == 0) {
          cVar5 = func_0x(0x118f5b0);
          if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar5 = func_0x(0x118f5b0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_e8 = (undefined8 *)0x0;
              (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar4 + 4),3);
          uVar15 = (ulonglong)*(uint *)(psVar4 + 10);
          uVar6 = psVar4[0xe];
        }
        uVar14 = (int)uVar15 + (uVar6 + 1) * 2;
        *(uint *)(psVar4 + 0xc) = uVar14;
        if (0x1f9e < uVar14) {
          cVar5 = func_0x(0x118f5b0);
          if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar5 = func_0x(0x118f5b0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_e8 = (undefined8 *)0x0;
              (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar4 + 4),4);
          uVar6 = psVar4[0xe];
          uVar14 = *(uint *)(psVar4 + 0xc);
        }
        uVar15 = (ulonglong)uVar6;
        uVar6 = puVar31[uVar15];
        *(uint *)(psVar4 + 2) = uVar6 & 0x7fff;
        if ((uVar6 & 0x7fff) < uVar14) {
          cVar5 = func_0x(0x118f5b0);
          if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar5 = func_0x(0x118f5b0);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_e8 = (undefined8 *)0x0;
              (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar4 + 4),4);
          uVar14 = *(uint *)(psVar4 + 0xc);
          uVar15 = (ulonglong)(ushort)psVar4[0xe];
        }
        puVar25 = puVar31;
        if ((short)uVar15 != 0) {
          do {
            uVar17 = puVar25[1] & 0x7fff;
            if ((uVar17 < uVar14) || (*(uint *)(psVar4 + 2) < uVar17)) {
              cVar5 = func_0x(0x118f5b0);
              if ((cVar5 != '\0') &&
                 ((lVar8 = func_0x(), lVar8 != 0 &&
                  (*(char *)(lVar8 + 0x499) != '\0')))) {
                cVar5 = func_0x(0x118f5b0);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_e8 = (undefined8 *)0x0;
                  (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x82a);
                }
              }
              func_0x(*(undefined8 *)(psVar4 + 4),4);
            }
            uVar15 = (ulonglong)(ushort)psVar4[0xe];
            iVar28 = iVar28 + 1;
            ppuVar26 = uStack_a8;
            puVar25 = puVar25 + 1;
            uVar14 = uVar17;
          } while (iVar28 < (int)(uint)(ushort)psVar4[0xe]);
        }
        if ((short)puVar31[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          pbVar23 = *(byte **)(psVar4 + 4);
          do {
            uVar17 = *(ushort *)(pbVar23 + uVar15 * 2 + (ulonglong)*(uint *)(psVar4 + 10)) & 0x7fff;
            if ((int)uVar15 == 1) {
              uVar30 = *(uint *)(psVar4 + 0xc);
              uVar19 = (ulonglong)uVar30;
LAB_:
              if ((uVar17 < (uint)uVar19) || (uVar14 = *(uint *)(psVar4 + 2), uVar14 < uVar17))
              goto LAB_;
            }
            else {
              uVar30 = *(uint *)(psVar4 + 0xc);
              uVar19 = (ulonglong)
                       (*(ushort *)(pbVar23 + uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2))
                       & 0x7fff);
              if (uVar30 <= (*(ushort *)
                              (pbVar23 + uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
              func_0x(pbVar23,7);
              uVar30 = *(uint *)(psVar4 + 0xc);
              uVar14 = *(uint *)(psVar4 + 2);
            }
            uVar12 = (uint)uVar19;
            if ((uVar12 < uVar30) || (uVar14 < uVar12)) goto LAB_;
            pbVar23 = *(byte **)(psVar4 + 4);
            if (*(ushort *)(pbVar23 + uVar19) == 5) {
              *puVar1 = *puVar1 | 2;
              psVar4[0xe] = psVar4[0xe] + -1;
              uVar22 = *(ulonglong *)(psVar4 + 4);
              uVar24 = uVar19 & 0xffff;
              uVar6 = psVar4[0x16] & 0xc7ff;
              uVar15 = uVar22 + uVar24;
              psVar4[0x15] = (short)uVar19;
              if ((*(ushort *)(uVar15 + 2) >> 0xe & 1) != 0) {
                uVar6 = *(ushort *)(uVar15 + 2) & 0x3800 | uVar6;
              }
              psVar4[0x16] = uVar6;
              uVar7 = (uVar6 ^ *(ushort *)(uVar15 + 2)) & 0x7ff ^ uVar6;
              psVar4[0x16] = uVar7;
              uVar19 = uVar22 + 4 +
                       (ulonglong)((uVar7 & 0x7ff) * 2) + uVar24 + (uVar6 >> 0xb & 7) * 2;
              if (uVar19 < uVar15) {
                func_0x(uVar15,0x19);
                uVar7 = psVar4[0x16];
                uVar24 = (ulonglong)(ushort)psVar4[0x15];
                uVar22 = (ulonglong)*(uint *)(psVar4 + 4);
              }
              if (uVar17 - uVar12 <
                  (((uVar7 & 0x7ff) * 2 - (int)uVar24) - (int)uVar22) + (int)uVar19) {
                func_0x(uVar24 + *(longlong *)(psVar4 + 4),0x19);
                uVar7 = psVar4[0x16];
              }
              if ((uVar7 & 0x3800) != 0) {
                puVar31 = (ushort *)
                          (*(longlong *)(psVar4 + 4) + (ulonglong)(ushort)psVar4[0x15] + 4);
                iVar27 = 0;
                if ((uVar7 & 0x3800) != 0) {
                  do {
                    if ((uVar7 & 0x7ff) < (*puVar31 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)psVar4[0x15] + *(longlong *)(psVar4 + 4),
                                      0x1a);
                      uVar7 = psVar4[0x16];
                    }
                    iVar27 = iVar27 + 1;
                    puVar31 = puVar31 + 1;
                  } while (iVar27 < (int)(uVar7 >> 0xb & 7));
                }
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar23 + uVar19) < 0x400) goto LAB_;
            sVar20 = psVar4[0xe];
            *puVar1 = *puVar1 | 1;
            uVar6 = sVar20 - 1;
            psVar4[0xe] = uVar6;
            if (uVar6 == 0) goto LAB_;
            uVar15 = (ulonglong)uVar6;
          } while ((short)puVar31[(ulonglong)(uVar6 - 1) + 1] < 0);
          uVar15 = (ulonglong)*(uint *)(psVar4 + 2);
        }
        else {
LAB_:
          pbVar23 = *(byte **)(psVar4 + 4);
          uVar15 = (ulonglong)*(uint *)(psVar4 + 2);
        }
      }
      iVar27 = 0;
      if ((*pbVar23 & 0x40) == 0) {
        *(undefined4 *)(psVar4 + 0x13) = 0;
      }
      else {
        *(int *)(psVar4 + 0x13) = (int)uVar15;
        *(int *)(psVar4 + 2) = (int)uVar15 + 0xe;
        puVar10 = (ulonglong *)func_0x(puVar1);
        uVar7 = (ushort)(*puVar10 >> 0x30);
        uVar6 = uVar7;
        if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
          uVar6 = uVar7 & 0xdfff;
          if ((uVar7 >> 0xe & 1) != 0) {
            uVar6 = uVar7 | 0x2000;
          }
        }
        if (uVar6 == 0xfffc) {
          iVar27 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar4 + 2) = *(int *)(psVar4 + 2) + iVar27;
        uVar15 = (ulonglong)*(uint *)(psVar4 + 2);
      }
      uVar14 = (uint)uVar15;
      if ((*(ulonglong *)(psVar4 + 0xf) != 0) &&
         (*(ulonglong *)(psVar4 + 0xf) < uVar15 + *(longlong *)(psVar4 + 4))) {
        cVar5 = func_0x(0x118f5b0);
        if ((cVar5 != '\0') &&
           ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))))
        {
          cVar5 = func_0x(0x118f5b0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_e8 = (undefined8 *)0x0;
            (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x886);
          }
        }
        func_0x(*(undefined8 *)(psVar4 + 4),0x12);
        uVar14 = *(uint *)(psVar4 + 2);
      }
      if ((uVar14 == 0) || (0x3f3c < uVar14)) {
        cVar5 = func_0x(0x118f5b0);
        if ((cVar5 != '\0') &&
           ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0'))))
        {
          cVar5 = func_0x(0x118f5b0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_e8 = (undefined8 *)0x0;
            (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x88b);
          }
        }
        func_0x(*(undefined8 *)(psVar4 + 4),5);
        uVar14 = *(uint *)(psVar4 + 2);
      }
    }
LAB_:
    if ((uVar14 < 9) &&
       (((**(byte **)(psVar4 + 4) & 0xe) == 0 || ((**(byte **)(psVar4 + 4) & 0xe) == 0xc)))) {
      uVar14 = 9;
    }
    psVar32 = psStack_78;
    uVar17 = (uint)uStack_a0;
  }
  else {
    if (uVar14 == 0) {
      func_0x(puVar1);
      uVar14 = *(uint *)(psVar4 + 2);
    }
    psVar32 = psVar4;
    if ((uVar14 < 9) &&
       (((**(byte **)(psVar4 + 4) & 0x1c) == 0 || ((**(byte **)(psVar4 + 4) & 0x1c) == 0xc)))) {
      uVar14 = 9;
    }
  }
  uVar15 = 0;
  *(short *)(lStack_90 + 0x18) = (short)uVar14;
  if (uVar17 != 0) {
    do {
      puVar18 = (uint *)0x0;
      lVar8 = **(longlong **)(*(longlong *)(lStack_b0 + 8) + 0x160);
      puVar11 = *(uint **)(lVar8 + 0x38);
      puVar21 = (uint *)(lVar8 + 0x30);
      if (puVar11 == puVar21) {
        puVar11 = puVar18;
      }
      puVar29 = puVar18;
      if (puVar11 != (uint *)0x0) {
        puVar29 = puVar11 + -0x58;
      }
      iVar27 = (int)uVar15;
      if (iVar27 != 0) {
        do {
          puVar11 = *(uint **)(puVar29 + 0x5a);
          if (*(uint **)(puVar29 + 0x5a) == puVar21) {
            puVar11 = puVar18;
          }
          puVar29 = puVar18;
          if (puVar11 != (uint *)0x0) {
            puVar29 = puVar11 + -0x58;
          }
          uVar15 = uVar15 - 1;
        } while (uVar15 != 0);
      }
      bVar13 = *(byte *)(puVar29 + 8);
      if (*psVar32 == 0) {
        uVar14 = *puVar29;
        if ((uVar14 & 0xc0000000) == 0x80000000) {
          iVar16 = func_0x(puVar1);
          if (iVar16 == 0) {
            auStack_b8[0] = 0;
          }
          else {
            puVar18 = (uint *)func_0x(psVar4 + 0x15,puVar29,auStack_b8,&uStack_a8);
          }
        }
        else {
          uVar17 = (uint)uStack_a0;
          if (((bVar13 & 2) != 0) || ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0)) {
            pbVar23 = *(byte **)(psVar4 + 4);
            if ((*pbVar23 & 0x10) == 0) {
              if ((1 << (*pbVar23 & 0xe) & 0x1105U) != 0) goto LAB_;
              puVar11 = (uint *)0x1;
              puVar21 = puVar18;
LAB_:
              uVar30 = (uint)puVar21;
              iVar16 = (int)puVar11;
              if ((bVar13 & 2) != 0) goto LAB_;
            }
            else {
              uVar30 = *(uint *)(psVar4 + 8);
              if ((int)uVar30 <= (int)uVar14) {
LAB_:
                puVar21 = (uint *)(ulonglong)(~(uint)(*(ushort *)((longlong)puVar29 + 6) >> 4) & 1);
                puVar11 = puVar18;
                goto LAB_;
              }
              if ((uint)*(ushort *)(pbVar23 + uVar30) < (uint)*(ushort *)(puVar29 + 1))
              goto LAB_;
              if ((bVar13 & 2) == 0) goto LAB_;
              uVar12 = *(ushort *)(puVar29 + 1) - 1;
              iVar16 = 1;
              uVar30 = pbVar23[(ulonglong)(uVar12 >> 3) + (ulonglong)uVar30 + 2] >>
                       ((byte)uVar12 & 7) & 1;
LAB_:
              if (uVar30 != 0) {
                auStack_b8[0] = 0;
                goto LAB_;
              }
            }
            if ((iVar16 == 0) && ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0)) {
              puVar18 = *(uint **)(puVar29 + 2) + 1;
              auStack_b8[0] = **(uint **)(puVar29 + 2);
              goto LAB_;
            }
          }
LAB_:
          if ((int)uVar14 < 0) {
            if (*(int *)(psVar4 + 2) == 0) {
              pbVar23 = *(byte **)(psVar4 + 4);
              uVar14 = *(uint *)(psVar4 + 8);
              uVar15 = (ulonglong)uVar14;
              *puVar1 = 0;
              *(uint *)(psVar4 + 10) = uVar14;
              bVar13 = *pbVar23;
              if ((bVar13 & 0x10) != 0) {
                uVar14 = uVar14 + 2 + (*(ushort *)(pbVar23 + uVar15) + 7 >> 3);
                uVar15 = (ulonglong)uVar14;
                *(uint *)(psVar4 + 10) = uVar14;
                bVar13 = *pbVar23;
              }
              if ((bVar13 & 0x20) == 0) {
                *(int *)(psVar4 + 2) = (int)uVar15;
                psVar4[0xe] = 0;
                *(int *)(psVar4 + 0xc) = (int)uVar15;
              }
              else {
                puVar31 = (ushort *)(pbVar23 + uVar15);
                uVar6 = *puVar31;
                psVar4[0xe] = uVar6;
                puStack_80 = puVar31;
                if (uVar6 == 0) {
                  cVar5 = func_0x(0x118f5b0);
                  if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
                     (*(char *)(lVar8 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x118f5b0);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_e8 = (undefined8 *)0x0;
                      (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x80f);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar4 + 4),3);
                  uVar15 = (ulonglong)*(uint *)(psVar4 + 10);
                  uVar6 = psVar4[0xe];
                }
                uVar14 = (int)uVar15 + (uVar6 + 1) * 2;
                *(uint *)(psVar4 + 0xc) = uVar14;
                if (0x1f9e < uVar14) {
                  cVar5 = func_0x(0x118f5b0);
                  if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
                     (*(char *)(lVar8 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x118f5b0);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_e8 = (undefined8 *)0x0;
                      (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x816);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar4 + 4),4);
                  uVar6 = psVar4[0xe];
                  uVar14 = *(uint *)(psVar4 + 0xc);
                }
                uVar15 = (ulonglong)uVar6;
                uVar6 = puVar31[uVar15];
                *(uint *)(psVar4 + 2) = uVar6 & 0x7fff;
                if ((uVar6 & 0x7fff) < uVar14) {
                  cVar5 = func_0x(0x118f5b0);
                  if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
                     (*(char *)(lVar8 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x118f5b0);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_e8 = (undefined8 *)0x0;
                      (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x81d);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar4 + 4),4);
                  uVar14 = *(uint *)(psVar4 + 0xc);
                  uVar15 = (ulonglong)(ushort)psVar4[0xe];
                }
                puVar25 = puVar31;
                if ((short)uVar15 != 0) {
                  do {
                    puVar31 = puVar31 + 1;
                    uVar17 = *puVar31 & 0x7fff;
                    if ((uVar17 < uVar14) || (*(uint *)(psVar4 + 2) < uVar17)) {
                      cVar5 = func_0x(0x118f5b0);
                      if ((cVar5 != '\0') &&
                         ((lVar8 = func_0x(), lVar8 != 0 &&
                          (*(char *)(lVar8 + 0x499) != '\0')))) {
                        cVar5 = func_0x(0x118f5b0);
                        if (cVar5 == '\0') {
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_e8 = (undefined8 *)0x0;
                          (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x82a);
                        }
                      }
                      func_0x(*(undefined8 *)(psVar4 + 4),4);
                    }
                    uVar15 = (ulonglong)(ushort)psVar4[0xe];
                    uVar30 = (int)puVar18 + 1;
                    puVar18 = (uint *)(ulonglong)uVar30;
                    puVar25 = puStack_80;
                    uVar14 = uVar17;
                  } while ((int)uVar30 < (int)(uint)(ushort)psVar4[0xe]);
                }
                if ((short)puVar25[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
                  pbVar23 = *(byte **)(psVar4 + 4);
                  do {
                    uVar14 = *(ushort *)(pbVar23 + uVar15 * 2 + (ulonglong)*(uint *)(psVar4 + 10)) &
                             0x7fff;
                    if ((int)uVar15 == 1) {
                      uVar17 = *(uint *)(psVar4 + 0xc);
                      uVar19 = (ulonglong)uVar17;
LAB_:
                      if ((uVar14 < (uint)uVar19) || (*(uint *)(psVar4 + 2) < uVar14))
                      goto LAB_;
                    }
                    else {
                      uVar17 = *(uint *)(psVar4 + 0xc);
                      uVar19 = (ulonglong)
                               (*(ushort *)
                                 (pbVar23 + uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2)) &
                               0x7fff);
                      if (uVar17 <= (*(ushort *)
                                      (pbVar23 +
                                      uVar15 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2)) & 0x7fff
                                    )) goto LAB_;
LAB_:
                      func_0x(pbVar23,7);
                      uVar17 = *(uint *)(psVar4 + 0xc);
                    }
                    uVar30 = (uint)uVar19;
                    if ((uVar30 < uVar17) || (*(uint *)(psVar4 + 2) < uVar30)) goto LAB_;
                    pbVar23 = *(byte **)(psVar4 + 4);
                    if (*(ushort *)(pbVar23 + uVar19) == 5) {
                      *puVar1 = *puVar1 | 2;
                      psVar4[0xe] = psVar4[0xe] + -1;
                      uVar15 = *(ulonglong *)(psVar4 + 4);
                      uVar22 = uVar19 & 0xffff;
                      psVar4[0x15] = (short)uVar19;
                      uVar6 = psVar4[0x16] & 0xc7ffU;
                      if ((*(ushort *)(uVar22 + 2 + uVar15) >> 0xe & 1) != 0) {
                        uVar6 = *(ushort *)(uVar22 + 2 + uVar15) & 0x3800 | psVar4[0x16] & 0xc7ffU;
                      }
                      psVar4[0x16] = uVar6;
                      uVar24 = (ulonglong)(ushort)psVar4[0x15];
                      uVar7 = (uVar6 ^ *(ushort *)(uVar22 + 2 + uVar15)) & 0x7ff ^ uVar6;
                      psVar4[0x16] = uVar7;
                      uVar19 = uVar15 + 4 +
                               (ulonglong)((uVar7 & 0x7ff) * 2) + uVar24 + (uVar6 >> 0xb & 7) * 2;
                      if (uVar19 < uVar24 + uVar15) {
                        func_0x(uVar24 + uVar15,0x19);
                        uVar7 = psVar4[0x16];
                        uVar24 = (ulonglong)(ushort)psVar4[0x15];
                        uVar15 = (ulonglong)*(uint *)(psVar4 + 4);
                      }
                      if (uVar14 - uVar30 <
                          (((uVar7 & 0x7ff) * 2 - (int)uVar24) - (int)uVar15) + (int)uVar19) {
                        func_0x(uVar24 + *(longlong *)(psVar4 + 4),0x19);
                        uVar7 = psVar4[0x16];
                      }
                      if ((uVar7 & 0x3800) != 0) {
                        puVar31 = (ushort *)
                                  (*(longlong *)(psVar4 + 4) + (ulonglong)(ushort)psVar4[0x15] + 4);
                        iVar16 = 0;
                        if ((uVar7 & 0x3800) != 0) {
                          do {
                            if ((uVar7 & 0x7ff) < (*puVar31 & 0x7ff)) {
                              func_0x((ulonglong)(ushort)psVar4[0x15] +
                                              *(longlong *)(psVar4 + 4),0x1a);
                              uVar7 = psVar4[0x16];
                            }
                            iVar16 = iVar16 + 1;
                            puVar31 = puVar31 + 1;
                          } while (iVar16 < (int)(uVar7 >> 0xb & 7));
                        }
                      }
                      goto LAB_;
                    }
                    if (*(ushort *)(pbVar23 + uVar19) < 0x400) goto LAB_;
                    sVar20 = psVar4[0xe];
                    *puVar1 = *puVar1 | 1;
                    uVar6 = sVar20 - 1;
                    psVar4[0xe] = uVar6;
                    if (uVar6 == 0) goto LAB_;
                    uVar15 = (ulonglong)uVar6;
                  } while ((short)puVar25[(ulonglong)(uVar6 - 1) + 1] < 0);
                  uVar15 = (ulonglong)*(uint *)(psVar4 + 2);
                }
                else {
LAB_:
                  pbVar23 = *(byte **)(psVar4 + 4);
                  uVar15 = (ulonglong)*(uint *)(psVar4 + 2);
                }
              }
              iVar16 = 0;
              if ((*pbVar23 & 0x40) == 0) {
                *(undefined4 *)(psVar4 + 0x13) = 0;
              }
              else {
                *(int *)(psVar4 + 0x13) = (int)uVar15;
                *(int *)(psVar4 + 2) = (int)uVar15 + 0xe;
                puVar10 = (ulonglong *)func_0x(puVar1);
                uVar7 = (ushort)(*puVar10 >> 0x30);
                uVar6 = uVar7;
                if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
                  uVar6 = uVar7 & 0xdfff;
                  if ((uVar7 >> 0xe & 1) != 0) {
                    uVar6 = uVar7 | 0x2000;
                  }
                }
                if (uVar6 == 0xfffc) {
                  iVar16 = (int)((*puVar10 >> 0x20 & 0xffff) >> 5);
                }
                *(int *)(psVar4 + 2) = *(int *)(psVar4 + 2) + iVar16;
                uVar15 = (ulonglong)*(uint *)(psVar4 + 2);
              }
              iVar16 = (int)uVar15;
              if ((*(ulonglong *)(psVar4 + 0xf) != 0) &&
                 (*(ulonglong *)(psVar4 + 0xf) < uVar15 + *(longlong *)(psVar4 + 4))) {
                cVar5 = func_0x(0x118f5b0);
                if ((cVar5 != '\0') &&
                   ((lVar8 = func_0x(), lVar8 != 0 &&
                    (*(char *)(lVar8 + 0x499) != '\0')))) {
                  cVar5 = func_0x(0x118f5b0);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_e8 = (undefined8 *)0x0;
                    (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x886);
                  }
                }
                func_0x(*(undefined8 *)(psVar4 + 4),0x12);
                iVar16 = *(int *)(psVar4 + 2);
              }
              if (0x3f3b < iVar16 - 1U) {
                cVar5 = func_0x(0x118f5b0);
                if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
                   (*(char *)(lVar8 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x118f5b0);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_e8 = (undefined8 *)0x0;
                    (*_DAT_)(1,0xa7efbc,0xb9f0a8,0x88b);
                  }
                }
                func_0x(*(undefined8 *)(psVar4 + 4),5);
              }
            }
LAB_:
            sVar20 = -*(short *)puVar29;
            ppuVar26 = uStack_a8;
            psVar32 = psStack_78;
            uVar17 = (uint)uStack_a0;
            if ((*(byte *)((longlong)puVar29 + 6) & 0x10) != 0) {
              bVar13 = **(byte **)(psVar4 + 4);
              if ((bVar13 & 0x10) == 0) {
                if ((1 << (bVar13 & 0xe) & 0x1105U) != 0) {
LAB_:
                  auStack_b8[0] = **(uint **)(puVar29 + 2);
                  puVar18 = *(uint **)(puVar29 + 2) + 1;
                  goto LAB_;
                }
              }
              else if (((int)*(uint *)(psVar4 + 8) <= (int)*puVar29) ||
                      (*(ushort *)(*(byte **)(psVar4 + 4) + *(uint *)(psVar4 + 8)) <
                       *(ushort *)(puVar29 + 1))) goto LAB_;
            }
            puVar18 = *(uint **)(psVar4 + 4);
            if ((uint)(ushort)psVar4[0xe] < (uint)(int)sVar20) {
              auStack_b8[0] = 0;
            }
            else {
              uVar14 = *(ushort *)
                        ((longlong)puVar18 +
                        (longlong)sVar20 * 2 + (ulonglong)*(uint *)(psVar4 + 10)) & 0x7fff;
              if (sVar20 == 1) {
                uVar17 = *(uint *)(psVar4 + 0xc);
LAB_:
                if ((uVar14 < uVar17) || (*(uint *)(psVar4 + 2) < uVar14)) goto LAB_;
              }
              else {
                uVar17 = *(ushort *)
                          ((longlong)puVar18 +
                          (longlong)sVar20 * 2 + ((ulonglong)*(uint *)(psVar4 + 10) - 2)) & 0x7fff;
                if (*(uint *)(psVar4 + 0xc) <= uVar17) goto LAB_;
LAB_:
                func_0x(puVar18,7);
                puVar18 = *(uint **)(psVar4 + 4);
              }
              auStack_b8[0] = uVar14 - uVar17;
              puVar18 = (uint *)((longlong)puVar18 + (ulonglong)uVar17);
              ppuVar26 = uStack_a8;
              psVar32 = psStack_78;
              uVar17 = (uint)uStack_a0;
            }
          }
          else {
            uVar6 = *(ushort *)((longlong)puVar29 + 6);
            if ((uVar6 & 8) == 0) {
              uVar30 = (uint)*(ushort *)(puVar29 + 0xe);
              if ((uVar6 & 0x10) != 0) {
                bVar13 = **(byte **)(psVar4 + 4);
                if ((bVar13 & 0x10) == 0) {
                  if ((1 << (bVar13 & 0xe) & 0x1105U) != 0) {
LAB_:
                    uVar14 = **(uint **)(puVar29 + 2);
                    puVar18 = *(uint **)(puVar29 + 2) + 1;
                    if ((uVar30 != 0) && (uVar14 != uVar30)) {
                      uStack_e8 = (undefined8 *)0x0;
                      (*_DAT_)(1,0xc2d400,0xc2bd68,0x381);
                    }
                    uVar17 = (uint)uStack_a0;
                    auStack_b8[0] = uVar14;
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(psVar4 + 8) <= (int)uVar14) ||
                        (*(ushort *)(*(byte **)(psVar4 + 4) + *(uint *)(psVar4 + 8)) <
                         *(ushort *)(puVar29 + 1))) goto LAB_;
              }
              puVar18 = (uint *)((longlong)(int)*puVar29 + *(longlong *)(psVar4 + 4));
              auStack_b8[0] = uVar30;
            }
            else {
              puVar18 = (uint *)0x803c50;
              auStack_b8[0] = 1;
              if ((*(byte *)((longlong)(int)uVar14 + *(longlong *)(psVar4 + 4)) &
                  (byte)(1 << ((byte)uVar6 & 7))) == 0) {
                puVar18 = (uint *)0x803c51;
              }
            }
          }
        }
      }
      else {
        uStack_e8 = &uStack_a8;
        uStack_a8 = (uint **)((ulonglong)uStack_a8 & 0xffffffff00000000);
        puVar18 = (uint *)func_0x(puVar1,puVar29,puVar21,auStack_b8);
        if ((((*psVar32 != 0) && (plVar3 = *(longlong **)(psVar32 + 8), plVar3 != (longlong *)0x0))
            && (*plVar3 != 0)) &&
           (((*(byte *)((longlong)puVar29 + 6) & 8) == 0 && (((ulonglong)uStack_a8 & 1) == 0)))) {
          if ((puVar18 == (uint *)0x0) || (puVar18 == (uint *)0x803c50)) {
            puVar18 = (uint *)0x0;
            auStack_b8[0] = 0;
          }
          else {
            uStack_d0 = CONCAT44(uStack_d0._4_4_,(uint)uStack_a8);
            puStack_d8 = auStack_b8;
            plStack_e0 = (longlong *)((ulonglong)plStack_e0 & 0xffffffff00000000);
            uStack_e8 = (undefined8 *)0x0;
            puVar18 = (uint *)func_0x(plVar3,puVar29,puVar18,auStack_b8[0]);
          }
        }
      }
LAB_:
      uVar14 = iVar27 + 1;
      uVar15 = (ulonglong)uVar14;
      *ppuVar26 = puVar18;
      ppuVar26 = ppuVar26 + 1;
      *puStack_88 = (undefined2)auStack_b8[0];
      puStack_88 = puStack_88 + 1;
      uStack_a8 = ppuVar26;
    } while (uVar14 < uVar17);
  }
  lVar8 = lStack_70;
  uStack_d0 = lStack_90 + 0x1c;
  uStack_c8 = 1;
  puStack_d8 = (uint *)abStack_98;
  plStack_e0 = &lStack_68;
  uStack_e8 = (undefined8 *)
              CONCAT62(uStack_e8._2_6_,
                       *(undefined2 *)(*(longlong *)(*(longlong *)(lStack_70 + 0x48) + 8) + 0xb8));
  func_0x
            (auStack_60,lStack_90,*(undefined8 *)(lStack_70 + 0x138),
             *(undefined4 *)(lStack_70 + 0x240));
  if (((abStack_98[0] & 1) != 0) &&
     ((*(byte *)(*(longlong *)(*(longlong *)(lVar8 + 0x48) + 8) + 0x106) & 0x40) == 0)) {
    func_0x(lVar8,lStack_90);
  }
  func_0x(uStack_40 ^ (ulonglong)auStack_108);
  return;
}

