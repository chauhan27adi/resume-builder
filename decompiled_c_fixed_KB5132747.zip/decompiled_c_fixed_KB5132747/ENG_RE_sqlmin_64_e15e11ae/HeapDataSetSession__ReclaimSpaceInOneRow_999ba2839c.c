
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2,longlong *param_3,undefined8 param_4)

{
  code *pcVar1;
  byte *pbVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  ushort *puVar5;
  byte bVar6;
  char cVar7;
  char cVar8;
  int iVar9;
  int iVar10;
  longlong lVar11;
  short *psVar12;
  longlong lVar13;
  undefined8 uVar14;
  ulonglong *puVar15;
  short sVar16;
  ushort uVar17;
  ulonglong uVar18;
  ushort *puVar19;
  ulonglong uVar20;
  ulonglong uVar21;
  longlong lVar22;
  longlong lVar23;
  byte *pbVar24;
  uint uVar25;
  int iVar26;
  uint uVar27;
  uint uVar28;
  ushort uVar29;
  byte *pbVar30;
  uint uVar31;
  ushort *puVar32;
  ulonglong uVar33;
  longlong unaff_GS_OFFSET;
  bool bVar34;
  undefined8 uStackX_8;
  uint uStackX_10;
  ushort uStackX_14;
  byte *pbStackX_16;
  undefined auStackX_1e [4];
  ushort uStackX_22;
  uint uStackX_24;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  *(undefined8 *)(&stack0x00000090 + lVar11) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002058 + lVar11) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar11);
  *(undefined8 *)(&stack0x00000048 + lVar11) = param_4;
  *(longlong **)(&stack0x00000080 + lVar11) = param_3;
  uVar27 = (uint)param_2;
  uVar18 = param_2 & 0xffffffff;
  *(uint *)(&stack0x00000050 + lVar11) = uVar27;
  *(longlong *)(&stack0x00000068 + lVar11) = param_1;
  lVar13 = *(longlong *)(&stack0x000020c8 + lVar11);
  *(longlong *)(&stack0x00000078 + lVar11) = lVar13;
  *(undefined8 *)(&stack0x00000070 + lVar11) = *(undefined8 *)(&stack0x000020d0 + lVar11);
  *(undefined2 *)(&stack0xfffffffffffffff8 + lVar11) = 0xffff;
  iVar26 = 0;
  *(undefined8 *)(auStackX_1e + lVar11 + -0x1e) = 0;
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar11) = 0;
  *(undefined8 *)((longlong)&uStackX_14 + lVar11 + 2) = 0;
  *(undefined8 *)(auStackX_1e + lVar11 + 2) = 0;
  *(undefined8 *)((longlong)&uStackX_8 + lVar11) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1000b9;
  func_0x(&stack0x000000b8 + lVar11,0,0x1f9e);
  *(undefined4 *)(&stack0x0000005c + lVar11) = 0;
  *(undefined4 *)(&stack0x0000003c + lVar11) = 0;
  *(undefined4 *)(&stack0x00000058 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000038 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000044 + lVar11) = 0;
  *(undefined4 *)(&stack0x00000040 + lVar11) = 0;
  cVar8 = *(char *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 0x30) + 0x1cde);
  (&stack0x00000030)[lVar11] = cVar8;
  uVar25 = uVar27 & 0xc2;
  *(uint *)(&stack0x00000054 + lVar11) = uVar25;
  if ((lVar13 != 0) && ((param_2 & 8) != 0)) {
    iVar26 = 1;
  }
  *(int *)(&stack0x00000034 + lVar11) = iVar26;
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100122;
  psVar12 = (short *)func_0x(param_3,1);
  if (cVar8 != '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100137;
    iVar9 = func_0x(param_3,0,0);
    if (iVar9 != 0) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100163;
      (*_DAT_)(1,0x190fbe8,0x19073e8,0x1d5b);
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100172;
    psVar12 = (short *)func_0x(param_3,1);
    if (psVar12 == (short *)0x0) {
      pcVar1 = *(code **)(*param_3 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100183;
      (*pcVar1)(param_3);
      goto LAB_;
    }
  }
  if (((((param_2 & 0x10) != 0) || ((param_2 & 0xc2) != 0)) || (iVar26 != 0)) ||
     (iVar26 = 0, (uVar27 >> 8 & 1) != 0)) {
    sVar16 = *psVar12;
    *(short *)(&stack0xfffffffffffffff8 + lVar11) = sVar16;
    if (sVar16 == 0) {
      puVar19 = (ushort *)(psVar12 + 1);
      uVar25 = *(uint *)(psVar12 + 2);
      if (uVar25 == 0) {
        iVar26 = 0;
        *puVar19 = 0;
        uVar25 = *(uint *)(psVar12 + 8);
        uVar18 = (ulonglong)uVar25;
        *(uint *)(psVar12 + 10) = uVar25;
        pbVar30 = *(byte **)(psVar12 + 4);
        bVar6 = *pbVar30;
        if ((bVar6 & 0x10) != 0) {
          uVar25 = uVar25 + 2 + (*(ushort *)(pbVar30 + uVar18) + 7 >> 3);
          uVar18 = (ulonglong)uVar25;
          *(uint *)(psVar12 + 10) = uVar25;
          bVar6 = *pbVar30;
        }
        iVar9 = (int)uVar18;
        if ((bVar6 & 0x20) == 0) {
          *(int *)(psVar12 + 2) = iVar9;
          psVar12[0xe] = 0;
          *(int *)(psVar12 + 0xc) = iVar9;
        }
        else {
          puVar32 = (ushort *)(pbVar30 + uVar18);
          uVar17 = *puVar32;
          psVar12[0xe] = uVar17;
          if (uVar17 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100220;
            cVar7 = func_0x(0x1e93050);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100229;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100243;
                cVar7 = func_0x(0x1e93050);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10025f;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100285;
                  (*_DAT_)(1,0x1782a5c,0x18a2b48,0x80f);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar12 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100293;
            func_0x(uVar14,3);
            iVar9 = *(int *)(psVar12 + 10);
            pbVar30 = *(byte **)(psVar12 + 4);
            uVar17 = psVar12[0xe];
          }
          uVar25 = iVar9 + (uVar17 + 1) * 2;
          *(uint *)(psVar12 + 0xc) = uVar25;
          if (0x1f9e < uVar25) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002c7;
            cVar7 = func_0x(0x1e93050);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002d0;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1002ea;
                cVar7 = func_0x(0x1e93050);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100306;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10032c;
                  (*_DAT_)(1,0x1782a5c,0x18a2b48,0x816);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar12 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10033a;
            func_0x(uVar14,4);
            uVar17 = psVar12[0xe];
            pbVar30 = *(byte **)(psVar12 + 4);
            uVar25 = *(uint *)(psVar12 + 0xc);
          }
          uVar18 = (ulonglong)uVar17;
          uVar17 = puVar32[uVar18];
          *(uint *)(psVar12 + 2) = uVar17 & 0x7fff;
          if ((uVar17 & 0x7fff) < uVar25) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10036d;
            cVar7 = func_0x(0x1e93050);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100376;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100390;
                cVar7 = func_0x(0x1e93050);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003ac;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003d2;
                  (*_DAT_)(1,0x1782a5c,0x18a2b48,0x81d);
                }
              }
            }
            uVar14 = *(undefined8 *)(psVar12 + 4);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1003e0;
            func_0x(uVar14,4);
            uVar25 = *(uint *)(psVar12 + 0xc);
            uVar18 = (ulonglong)(ushort)psVar12[0xe];
            pbVar30 = *(byte **)(psVar12 + 4);
          }
          puVar5 = puVar32;
          if ((short)uVar18 != 0) {
            do {
              uVar27 = puVar5[1] & 0x7fff;
              if ((uVar27 < uVar25) || (*(uint *)(psVar12 + 2) < uVar27)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100420;
                cVar8 = func_0x(0x1e93050);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100429;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100443;
                    cVar8 = func_0x(0x1e93050);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10045f;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100485;
                      (*_DAT_)(1,0x1782a5c,0x18a2b48,0x82a);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(psVar12 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100493;
                func_0x(uVar14,4);
              }
              iVar26 = iVar26 + 1;
              uVar18 = (ulonglong)(ushort)psVar12[0xe];
              puVar5 = puVar5 + 1;
              uVar25 = uVar27;
            } while (iVar26 < (int)(uint)(ushort)psVar12[0xe]);
            pbVar30 = *(byte **)(psVar12 + 4);
            cVar8 = (&stack0x00000030)[lVar11];
          }
          uVar20 = uVar18;
          if ((short)puVar32[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
LAB_:
            sVar16 = (short)uVar18;
            uVar27 = *(ushort *)(pbVar30 + uVar20 * 2 + (ulonglong)*(uint *)(psVar12 + 10)) & 0x7fff
            ;
            if ((int)uVar20 == 1) {
              uVar31 = *(uint *)(psVar12 + 0xc);
              uVar18 = (ulonglong)uVar31;
LAB_:
              if ((uVar27 < (uint)uVar18) || (uVar25 = *(uint *)(psVar12 + 2), uVar25 < uVar27))
              goto LAB_;
            }
            else {
              uVar18 = (ulonglong)
                       (*(ushort *)(pbVar30 + uVar20 * 2 + ((ulonglong)*(uint *)(psVar12 + 10) - 2))
                       & 0x7fff);
              uVar31 = *(uint *)(psVar12 + 0xc);
              if (uVar31 <= (*(ushort *)
                              (pbVar30 + uVar20 * 2 + ((ulonglong)*(uint *)(psVar12 + 10) - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100530;
              func_0x(pbVar30,7);
              uVar31 = *(uint *)(psVar12 + 0xc);
              uVar25 = *(uint *)(psVar12 + 2);
              pbVar30 = *(byte **)(psVar12 + 4);
              sVar16 = psVar12[0xe];
            }
            uVar28 = (uint)uVar18;
            if ((uVar28 < uVar31) || (uVar25 < uVar28)) goto LAB_;
            if (*(ushort *)(pbVar30 + uVar18) == 5) {
              *puVar19 = *puVar19 | 2;
              psVar12[0xe] = sVar16 + -1;
              uVar21 = uVar18 & 0xffff;
              psVar12[0x15] = (short)uVar18;
              uVar20 = *(ulonglong *)(psVar12 + 4);
              uVar18 = uVar20 + uVar21;
              uVar17 = psVar12[0x16] & 0xc7ff;
              if ((*(ushort *)(uVar18 + 2) >> 0xe & 1) != 0) {
                uVar17 = *(ushort *)(uVar18 + 2) & 0x3800 | uVar17;
              }
              psVar12[0x16] = uVar17;
              uVar29 = (uVar17 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar17;
              psVar12[0x16] = uVar29;
              uVar33 = (ulonglong)((uVar29 & 0x7ff) * 2) + 4 + uVar21 + (uVar17 >> 0xb & 7) * 2 +
                       uVar20;
              if (uVar33 < uVar18) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10064a;
                func_0x(uVar18,0x19);
                uVar29 = psVar12[0x16];
                uVar21 = (ulonglong)(ushort)psVar12[0x15];
                uVar20 = (ulonglong)*(uint *)(psVar12 + 4);
              }
              if (uVar27 - uVar28 <
                  (((uVar29 & 0x7ff) * 2 - (int)uVar21) - (int)uVar20) + (int)uVar33) {
                lVar13 = *(longlong *)(psVar12 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100683;
                func_0x(uVar21 + lVar13,0x19);
                uVar29 = psVar12[0x16];
              }
              if ((uVar29 & 0x3800) != 0) {
                puVar32 = (ushort *)
                          (*(longlong *)(psVar12 + 4) + (ulonglong)(ushort)psVar12[0x15] + 4);
                iVar26 = 0;
                if ((uVar29 & 0x3800) != 0) {
                  do {
                    if ((uVar29 & 0x7ff) < (*puVar32 & 0x7ff)) {
                      uVar17 = psVar12[0x15];
                      lVar13 = *(longlong *)(psVar12 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1006e7;
                      func_0x((ulonglong)uVar17 + lVar13,0x1a);
                      uVar29 = psVar12[0x16];
                    }
                    iVar26 = iVar26 + 1;
                    puVar32 = puVar32 + 1;
                  } while (iVar26 < (int)(uVar29 >> 0xb & 7));
                }
              }
              pbVar30 = *(byte **)(psVar12 + 4);
              uVar18 = (ulonglong)*(uint *)(psVar12 + 2);
              goto LAB_;
            }
            if (0x3ff < *(ushort *)(pbVar30 + uVar18)) {
              *puVar19 = *puVar19 | 1;
              uVar17 = sVar16 - 1;
              psVar12[0xe] = uVar17;
              if (uVar17 != 0) goto code_r0x0010057e;
            }
          }
LAB_:
          uVar18 = (ulonglong)*(uint *)(psVar12 + 2);
        }
LAB_:
        if ((*pbVar30 & 0x40) == 0) {
          *(undefined4 *)(psVar12 + 0x13) = 0;
        }
        else {
          *(int *)(psVar12 + 0x13) = (int)uVar18;
          *(int *)(psVar12 + 2) = (int)uVar18 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100747;
          uVar14 = func_0x(puVar19);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100757;
          func_0x(uVar14,&stack0x00000060 + lVar11);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100764;
          iVar26 = func_0x(&stack0x00000060 + lVar11);
          *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + iVar26;
          uVar18 = (ulonglong)*(uint *)(psVar12 + 2);
          pbVar30 = *(byte **)(psVar12 + 4);
        }
        uVar25 = (uint)uVar18;
        if ((*(byte **)(psVar12 + 0xf) != (byte *)0x0) &&
           (*(byte **)(psVar12 + 0xf) < pbVar30 + uVar18)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10079f;
          cVar7 = func_0x(0x1e93050);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1007a8;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1007c2;
              cVar7 = func_0x(0x1e93050);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1007de;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100804;
                (*_DAT_)(1,0x1782a5c,0x18a2b48,0x886);
              }
            }
          }
          uVar14 = *(undefined8 *)(psVar12 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100812;
          func_0x(uVar14,0x12);
          uVar25 = *(uint *)(psVar12 + 2);
        }
        if ((uVar25 == 0) || (0x3f3c < uVar25)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100832;
          cVar7 = func_0x(0x1e93050);
          if (cVar7 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10083b;
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100855;
              cVar7 = func_0x(0x1e93050);
              if (cVar7 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100871;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100897;
                (*_DAT_)(1,0x1782a5c,0x18a2b48,0x88b);
              }
            }
          }
          uVar14 = *(undefined8 *)(psVar12 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1008a5;
          func_0x(uVar14,5);
          uVar25 = *(uint *)(psVar12 + 2);
        }
      }
LAB_:
      if ((uVar25 < 9) &&
         (((**(byte **)(psVar12 + 4) & 0xe) == 0 || ((**(byte **)(psVar12 + 4) & 0xe) == 0xc)))) {
        uVar25 = 9;
      }
      *(undefined4 *)((longlong)&uStackX_8 + lVar11) = *(undefined4 *)(psVar12 + 8);
      *(ushort *)(&stack0xfffffffffffffffa + lVar11) = *puVar19;
      *(undefined4 *)(&stack0xfffffffffffffffc + lVar11) = *(undefined4 *)(psVar12 + 2);
      *(short *)((longlong)&uStackX_14 + lVar11) = psVar12[0xe];
      *(undefined4 *)((longlong)&uStackX_8 + lVar11 + 4) = *(undefined4 *)(psVar12 + 10);
      *(undefined4 *)((longlong)&uStackX_10 + lVar11) = *(undefined4 *)(psVar12 + 0xc);
      *(undefined4 *)(auStackX_1e + lVar11) = *(undefined4 *)(psVar12 + 0x13);
      uVar14 = *(undefined8 *)(psVar12 + 4);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10092a;
      func_0x(&stack0x000000b8 + lVar11,0x1f9e,uVar14,uVar25);
      *(undefined **)(auStackX_1e + lVar11 + -0x1e) = &stack0x000000b8 + lVar11;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100941;
      iVar26 = func_0x(&stack0xfffffffffffffffa + lVar11);
      if (iVar26 != 0) {
        lVar13 = *(longlong *)(auStackX_1e + lVar11 + -0x1e);
        puVar19 = (ushort *)((ulonglong)*(uint *)((longlong)&uStackX_8 + lVar11 + 4) + lVar13);
        uVar25 = *puVar19 - 1;
        if (((&stack0xfffffffffffffffa)[lVar11] & 1) == 0) {
          uVar25 = (uint)*puVar19;
        }
        uVar27 = *(uint *)((longlong)&uStackX_10 + lVar11);
        if (uVar25 != 1) {
          uVar27 = puVar19[(longlong)(int)uVar25 + -1] & 0x7fff;
        }
        uVar25 = puVar19[(int)uVar25] & 0x7fff;
        if (((uVar27 < *(uint *)((longlong)&uStackX_10 + lVar11)) || (uVar25 < uVar27)) ||
           (*(uint *)(&stack0xfffffffffffffffc + lVar11) < uVar25)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1009a3;
          func_0x(lVar13,7);
          lVar13 = *(longlong *)(auStackX_1e + lVar11 + -0x1e);
        }
        uVar20 = (ulonglong)(uVar27 & 0xffff);
        *(short *)(auStackX_1e + lVar11 + 4) = (short)uVar27;
        uVar18 = lVar13 + uVar20;
        uVar17 = *(ushort *)(auStackX_1e + lVar11 + 6);
        if ((*(ushort *)(uVar18 + 2) & 0x4000) == 0) {
          uVar17 = uVar17 & 0xc7ff;
        }
        else {
          uVar17 = uVar17 ^ (*(ushort *)(uVar18 + 2) ^ uVar17) & 0x3800;
        }
        *(ushort *)(auStackX_1e + lVar11 + 6) = uVar17;
        uVar29 = (uVar17 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar17;
        uVar33 = (ulonglong)uVar29;
        *(ushort *)(auStackX_1e + lVar11 + 6) = uVar29;
        uVar21 = (ulonglong)((uVar17 >> 0xb & 7) * 2) + 4 + lVar13 + (uVar33 & 0x7ff) * 2 + uVar20;
        if (uVar21 < uVar18) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a25;
          func_0x(uVar18,0x19);
          uVar33 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 6);
          uVar20 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 4);
          lVar13 = *(longlong *)(auStackX_1e + lVar11 + -0x1e);
        }
        if (uVar25 - uVar27 <
            (((*(uint *)(auStackX_1e + lVar11 + 6) & 0x7ff) * 2 - (int)uVar20) -
            *(int *)(auStackX_1e + lVar11 + -0x1e)) + (int)uVar21) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100a60;
          func_0x(uVar20 + lVar13,0x19);
          uVar33 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 6);
          uVar20 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 4);
          lVar13 = *(longlong *)(auStackX_1e + lVar11 + -0x1e);
        }
        if ((uVar33 & 0x3800) != 0) {
          puVar19 = (ushort *)(lVar13 + 4 + uVar20);
          iVar26 = 0;
          if ((uVar33 & 0x3800) != 0) {
            do {
              if (((ushort)uVar33 & 0x7ff) < (*puVar19 & 0x7ff)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100ac5;
                func_0x(uVar20 + lVar13,0x1a);
                uVar33 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 6);
                uVar20 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 4);
                lVar13 = *(longlong *)(auStackX_1e + lVar11 + -0x1e);
              }
              iVar26 = iVar26 + 1;
              puVar19 = puVar19 + 1;
            } while (iVar26 < (int)(*(uint *)(auStackX_1e + lVar11 + 6) >> 0xb & 7));
          }
        }
      }
    }
    else if (((*psVar12 == 0) || (*(longlong **)(psVar12 + 8) == (longlong *)0x0)) ||
            (**(longlong **)(psVar12 + 8) == 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b3b;
      func_0x(&stack0xfffffffffffffffa + lVar11,&stack0x000000b8 + lVar11,0x1f9e,psVar12 + 1
                     );
      if (*psVar12 == 0) {
        uVar14 = 0;
      }
      else {
        uVar14 = *(undefined8 *)(psVar12 + 8);
      }
      *(undefined8 *)((longlong)&uStackX_8 + lVar11) = uVar14;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b1d;
      func_0x(&stack0xfffffffffffffff8 + lVar11,&stack0x000000b8 + lVar11,0x1f9e,psVar12);
    }
    if (*(short *)(&stack0xfffffffffffffff8 + lVar11) == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b72;
      func_0x();
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100b79;
      func_0x(&stack0xfffffffffffffffa + lVar11);
    }
    pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
    uVar25 = *(uint *)(&stack0xfffffffffffffffc + lVar11);
    uVar18 = (ulonglong)uVar25;
    if (cVar8 == '\0') {
LAB_:
      if (*(short *)(&stack0xfffffffffffffff8 + lVar11) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101bb7;
        func_0x(&stack0xfffffffffffffffa + lVar11);
      }
      else if ((*pbVar30 & 2) != 0) {
        if (uVar25 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c6b;
          func_0x(&stack0xfffffffffffffffa + lVar11);
          pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
        }
        *pbVar30 = *pbVar30 & 0xfd;
        *(undefined4 *)(&stack0xfffffffffffffffc + lVar11) =
             *(undefined4 *)(&stack0x00000028 + lVar11);
        *(undefined4 *)(&stack0x00000028 + lVar11) = 0;
      }
    }
    else {
      if (*(short *)(&stack0xfffffffffffffff8 + lVar11) == 0) {
        if ((*pbVar30 & 0xe) != 2) {
          if (uVar25 == 0) {
            iVar26 = 0;
            *(undefined2 *)(&stack0xfffffffffffffffa + lVar11) = 0;
            uVar25 = *(uint *)((longlong)&uStackX_8 + lVar11);
            uVar18 = (ulonglong)uVar25;
            *(uint *)((longlong)&uStackX_8 + lVar11 + 4) = uVar25;
            if ((*pbVar30 & 0x10) != 0) {
              uVar25 = uVar25 + 2 + (*(ushort *)(pbVar30 + uVar18) + 7 >> 3);
              uVar18 = (ulonglong)uVar25;
              *(uint *)((longlong)&uStackX_8 + lVar11 + 4) = uVar25;
            }
            if ((*pbVar30 & 0x20) == 0) {
              *(int *)(&stack0xfffffffffffffffc + lVar11) = (int)uVar18;
              *(undefined2 *)((longlong)&uStackX_14 + lVar11) = 0;
              *(int *)((longlong)&uStackX_10 + lVar11) = (int)uVar18;
            }
            else {
              puVar19 = (ushort *)(pbVar30 + uVar18);
              uVar17 = *puVar19;
              *(ushort *)((longlong)&uStackX_14 + lVar11) = uVar17;
              if (uVar17 == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c0d;
                cVar8 = func_0x(0x1e93050);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c16;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c30;
                    cVar8 = func_0x(0x1e93050);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c4c;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c72;
                      (*_DAT_)(1,0x1782a5c,0x18a2b48,0x80f);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100c81;
                func_0x(uVar14,3);
                uVar17 = *(ushort *)((longlong)&uStackX_14 + lVar11);
                pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
              }
              uVar25 = *(int *)((longlong)&uStackX_8 + lVar11 + 4) + 2 + (uint)uVar17 * 2;
              *(uint *)((longlong)&uStackX_10 + lVar11) = uVar25;
              if (0x1f9e < uVar25) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cb8;
                cVar8 = func_0x(0x1e93050);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cc1;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cdb;
                    cVar8 = func_0x(0x1e93050);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100cf7;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d1d;
                      (*_DAT_)(1,0x1782a5c,0x18a2b48,0x816);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d2c;
                func_0x(uVar14,4);
                uVar17 = *(ushort *)((longlong)&uStackX_14 + lVar11);
                uVar25 = *(uint *)((longlong)&uStackX_10 + lVar11);
                pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
              }
              uVar20 = (ulonglong)uVar17;
              uVar27 = puVar19[uVar20] & 0x7fff;
              *(uint *)(&stack0xfffffffffffffffc + lVar11) = uVar27;
              if (uVar27 < uVar25) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d64;
                cVar8 = func_0x(0x1e93050);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d6d;
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100d87;
                    cVar8 = func_0x(0x1e93050);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100da3;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100dc9;
                      (*_DAT_)(1,0x1782a5c,0x18a2b48,0x81d);
                    }
                  }
                }
                uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100dd8;
                func_0x(uVar14,4);
                uVar20 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar11);
                uVar25 = *(uint *)((longlong)&uStackX_10 + lVar11);
                pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                uVar27 = *(uint *)(&stack0xfffffffffffffffc + lVar11);
              }
              uVar18 = (ulonglong)uVar27;
              puVar32 = puVar19;
              if ((short)uVar20 != 0) {
                do {
                  uVar27 = puVar32[1] & 0x7fff;
                  if ((uVar27 < uVar25) || ((uint)uVar18 < uVar27)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e23;
                    cVar8 = func_0x(0x1e93050);
                    if (cVar8 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e2c;
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e46;
                        cVar8 = func_0x(0x1e93050);
                        if (cVar8 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e62;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e88;
                          (*_DAT_)(1,0x1782a5c,0x18a2b48,0x82a);
                        }
                      }
                    }
                    uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100e97;
                    func_0x(uVar14,4);
                    uVar20 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar11);
                    pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                    uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
                  }
                  iVar26 = iVar26 + 1;
                  uVar25 = uVar27;
                  puVar32 = puVar32 + 1;
                } while (iVar26 < (int)uVar20);
                uVar25 = *(uint *)((longlong)&uStackX_10 + lVar11);
              }
              while( true ) {
                sVar16 = (short)uVar20;
                if (-1 < (short)puVar19[(ulonglong)((int)uVar20 - 1) + 1]) break;
                uVar27 = *(uint *)((longlong)&uStackX_8 + lVar11 + 4);
                uVar31 = uVar25;
                if ((int)uVar20 != 1) {
                  uVar31 = *(ushort *)(pbVar30 + uVar20 * 2 + ((ulonglong)uVar27 - 2)) & 0x7fff;
                }
                uVar27 = *(ushort *)(pbVar30 + uVar20 * 2 + (ulonglong)uVar27) & 0x7fff;
                if (((uVar31 < uVar25) || (uVar27 < uVar31)) || ((uint)uVar18 < uVar27)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x100f29;
                  func_0x(pbVar30,7);
                  sVar16 = *(short *)((longlong)&uStackX_14 + lVar11);
                  uVar25 = *(uint *)((longlong)&uStackX_10 + lVar11);
                  pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                  uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
                }
                if ((uVar31 < uVar25) || ((uint)uVar18 < uVar31)) goto LAB_;
                if (*(ushort *)(pbVar30 + uVar31) == 5) {
                  *(ushort *)(&stack0xfffffffffffffffa + lVar11) =
                       *(ushort *)(&stack0xfffffffffffffffa + lVar11) | 2;
                  *(short *)((longlong)&uStackX_14 + lVar11) = sVar16 + -1;
                  uVar20 = (ulonglong)uVar31 & 0xffff;
                  *(short *)(auStackX_1e + lVar11 + 4) = (short)uVar31;
                  pbVar2 = pbVar30 + uVar20;
                  uVar17 = *(ushort *)(auStackX_1e + lVar11 + 6);
                  if ((*(ushort *)(pbVar2 + 2) & 0x4000) == 0) {
                    uVar17 = uVar17 & 0xc7ff;
                  }
                  else {
                    uVar17 = uVar17 ^ (*(ushort *)(pbVar2 + 2) ^ uVar17) & 0x3800;
                  }
                  *(ushort *)(auStackX_1e + lVar11 + 6) = uVar17;
                  uVar29 = (uVar17 ^ *(ushort *)(pbVar2 + 2)) & 0x7ff ^ uVar17;
                  *(ushort *)(auStackX_1e + lVar11 + 6) = uVar29;
                  pbVar24 = pbVar30 + uVar20 + ((ulonglong)uVar29 & 0x7ff) * 2 +
                                               (ulonglong)((uVar17 >> 0xb & 7) * 2) + 4;
                  if (pbVar24 < pbVar2) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101013;
                    func_0x(pbVar2,0x19);
                    uVar29 = *(ushort *)(auStackX_1e + lVar11 + 6);
                    uVar20 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 4);
                    pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                    uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
                  }
                  if (uVar27 - uVar31 <
                      (((*(uint *)(auStackX_1e + lVar11 + 6) & 0x7ff) * 2 - (int)uVar20) -
                      *(int *)(auStackX_1e + lVar11 + -0x1e)) + (int)pbVar24) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101053;
                    func_0x(pbVar30 + uVar20,0x19);
                    uVar29 = *(ushort *)(auStackX_1e + lVar11 + 6);
                    uVar20 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 4);
                    pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                    uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
                  }
                  iVar26 = 0;
                  if (((uVar29 & 0x3800) != 0) &&
                     (puVar19 = (ushort *)(pbVar30 + uVar20 + 4), (uVar29 & 0x3800) != 0)) {
                    do {
                      if ((uVar29 & 0x7ff) < (*puVar19 & 0x7ff)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1010c5;
                        func_0x(pbVar30 + uVar20,0x1a);
                        uVar29 = *(ushort *)(auStackX_1e + lVar11 + 6);
                        uVar20 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 4);
                        pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                      }
                      iVar26 = iVar26 + 1;
                      puVar19 = puVar19 + 1;
                    } while (iVar26 < (int)(*(uint *)(auStackX_1e + lVar11 + 6) >> 0xb & 7));
                    uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
                  }
                  break;
                }
                if (*(ushort *)(pbVar30 + uVar31) < 0x400) break;
                *(ushort *)(&stack0xfffffffffffffffa + lVar11) =
                     *(ushort *)(&stack0xfffffffffffffffa + lVar11) | 1;
                uVar17 = sVar16 - 1;
                uVar20 = (ulonglong)uVar17;
                *(ushort *)((longlong)&uStackX_14 + lVar11) = uVar17;
                if (uVar17 == 0) break;
              }
            }
            if ((*pbVar30 & 0x40) == 0) {
              *(undefined4 *)(auStackX_1e + lVar11) = 0;
            }
            else {
              *(int *)(auStackX_1e + lVar11) = (int)uVar18;
              *(int *)(&stack0xfffffffffffffffc + lVar11) = (int)uVar18 + 0xe;
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101125;
              puVar15 = (ulonglong *)func_0x(&stack0xfffffffffffffffa + lVar11);
              uVar18 = *puVar15;
              iVar26 = 0;
              uVar17 = (ushort)(uVar18 >> 0x30);
              if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
                if ((uVar18 & 0x4000000000000000) == 0) {
                  uVar17 = uVar17 & 0xdfff;
                }
                else {
                  uVar17 = uVar17 | 0x2000;
                }
              }
              if (uVar17 == 0xfffc) {
                iVar26 = (int)((uVar18 >> 0x20 & 0xffff) >> 5);
              }
              uVar18 = (ulonglong)(uint)(*(int *)(&stack0xfffffffffffffffc + lVar11) + iVar26);
              *(int *)(&stack0xfffffffffffffffc + lVar11) =
                   *(int *)(&stack0xfffffffffffffffc + lVar11) + iVar26;
              pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
            }
            pbVar2 = *(byte **)((longlong)&uStackX_14 + lVar11 + 2);
            if ((pbVar2 != (byte *)0x0) && (pbVar2 < pbVar30 + uVar18)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1011c8;
              cVar8 = func_0x(0x1e93050);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1011d1;
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1011eb;
                  cVar8 = func_0x(0x1e93050);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101207;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10122d;
                    (*_DAT_)(1,0x1782a5c,0x18a2b48,0x886);
                  }
                }
              }
              uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10123c;
              func_0x(uVar14,0x12);
              pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
              uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
            }
            if (0x3f3b < (int)uVar18 - 1U) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101261;
              cVar8 = func_0x(0x1e93050);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10126a;
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101284;
                  cVar8 = func_0x(0x1e93050);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012a0;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012c6;
                    (*_DAT_)(1,0x1782a5c,0x18a2b48,0x88b);
                  }
                }
              }
              uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1012d5;
              func_0x(uVar14,5);
              pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
              uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
            }
          }
LAB_:
          uVar27 = (uint)uVar18;
          if ((uVar27 < 9) && (((*pbVar30 & 0xe) == 0 || ((*pbVar30 & 0xe) == 0xc)))) {
            uVar27 = 9;
            bVar34 = (*pbVar30 & 0x40) == 0;
            uVar31 = *(uint *)(auStackX_1e + lVar11);
          }
          else {
            bVar34 = (*pbVar30 & 0x40) == 0;
            uVar31 = *(uint *)(auStackX_1e + lVar11);
          }
LAB_:
          uVar25 = (uint)uVar18;
          if (bVar34) {
            uVar31 = uVar27;
          }
          uVar27 = 0x10;
          if (*(short *)(&stack0xfffffffffffffff8 + lVar11) == 0) {
            uVar27 = 0x16;
          }
          if (uVar27 <= uVar31) goto LAB_;
          goto LAB_;
        }
LAB_:
        if ((int)uVar18 == 0) {
          iVar26 = 0;
          *(undefined2 *)(&stack0xfffffffffffffffa + lVar11) = 0;
          uVar25 = *(uint *)((longlong)&uStackX_8 + lVar11);
          uVar18 = (ulonglong)uVar25;
          *(uint *)((longlong)&uStackX_8 + lVar11 + 4) = uVar25;
          if ((*pbVar30 & 0x10) != 0) {
            uVar25 = uVar25 + 2 + (*(ushort *)(pbVar30 + uVar18) + 7 >> 3);
            uVar18 = (ulonglong)uVar25;
            *(uint *)((longlong)&uStackX_8 + lVar11 + 4) = uVar25;
          }
          if ((*pbVar30 & 0x20) == 0) {
            *(int *)(&stack0xfffffffffffffffc + lVar11) = (int)uVar18;
            *(undefined2 *)((longlong)&uStackX_14 + lVar11) = 0;
            *(int *)((longlong)&uStackX_10 + lVar11) = (int)uVar18;
          }
          else {
            puVar19 = (ushort *)(pbVar30 + uVar18);
            *(ushort **)(&stack0x00000060 + lVar11) = puVar19;
            uVar17 = *puVar19;
            *(ushort *)((longlong)&uStackX_14 + lVar11) = uVar17;
            if (uVar17 == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101460;
              cVar8 = func_0x(0x1e93050);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101469;
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101482;
                  cVar8 = func_0x(0x1e93050);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10149e;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1014c4;
                    (*_DAT_)(1,0x1782a5c,0x18a2b48,0x80f);
                  }
                }
              }
              uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1014d3;
              func_0x(uVar14,3);
              uVar17 = *(ushort *)((longlong)&uStackX_14 + lVar11);
              pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
            }
            uVar25 = *(int *)((longlong)&uStackX_8 + lVar11 + 4) + 2 + (uint)uVar17 * 2;
            *(uint *)((longlong)&uStackX_10 + lVar11) = uVar25;
            if (0x1f9e < uVar25) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10150a;
              cVar8 = func_0x(0x1e93050);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101513;
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10152c;
                  cVar8 = func_0x(0x1e93050);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101548;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10156e;
                    (*_DAT_)(1,0x1782a5c,0x18a2b48,0x816);
                  }
                }
              }
              uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10157d;
              func_0x(uVar14,4);
              uVar17 = *(ushort *)((longlong)&uStackX_14 + lVar11);
              uVar25 = *(uint *)((longlong)&uStackX_10 + lVar11);
              pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
            }
            uVar20 = (ulonglong)uVar17;
            uVar27 = puVar19[uVar20] & 0x7fff;
            *(uint *)(&stack0xfffffffffffffffc + lVar11) = uVar27;
            if (uVar27 < uVar25) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1015b5;
              cVar8 = func_0x(0x1e93050);
              if (cVar8 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1015be;
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1015d7;
                  cVar8 = func_0x(0x1e93050);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1015f3;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101619;
                    (*_DAT_)(1,0x1782a5c,0x18a2b48,0x81d);
                  }
                }
              }
              uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101628;
              func_0x(uVar14,4);
              uVar20 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar11);
              uVar25 = *(uint *)((longlong)&uStackX_10 + lVar11);
              pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
              uVar27 = *(uint *)(&stack0xfffffffffffffffc + lVar11);
            }
            uVar18 = (ulonglong)uVar27;
            if ((short)uVar20 != 0) {
              do {
                puVar19 = puVar19 + 1;
                uVar27 = *puVar19 & 0x7fff;
                if ((uVar27 < uVar25) || ((uint)uVar18 < uVar27)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101673;
                  cVar8 = func_0x(0x1e93050);
                  if (cVar8 != '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x10167c;
                    lVar13 = func_0x();
                    if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101696;
                      cVar8 = func_0x(0x1e93050);
                      if (cVar8 == '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1016b2;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1016d8;
                        (*_DAT_)(1,0x1782a5c,0x18a2b48,0x82a);
                      }
                    }
                  }
                  uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1016e7;
                  func_0x(uVar14,4);
                  uVar20 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar11);
                  pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                  uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
                }
                iVar26 = iVar26 + 1;
                uVar25 = uVar27;
              } while (iVar26 < (int)uVar20);
              uVar25 = *(uint *)((longlong)&uStackX_10 + lVar11);
              puVar19 = *(ushort **)(&stack0x00000060 + lVar11);
            }
            while ((short)puVar19[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
              uVar27 = *(uint *)((longlong)&uStackX_8 + lVar11 + 4);
              uVar31 = uVar25;
              if ((int)uVar20 != 1) {
                uVar31 = *(ushort *)(pbVar30 + uVar20 * 2 + ((ulonglong)uVar27 - 2)) & 0x7fff;
              }
              uVar27 = *(ushort *)(pbVar30 + uVar20 * 2 + (ulonglong)uVar27) & 0x7fff;
              if (((uVar31 < uVar25) || (uVar27 < uVar31)) || ((uint)uVar18 < uVar27)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101779;
                func_0x(pbVar30,7);
                uVar20 = (ulonglong)*(ushort *)((longlong)&uStackX_14 + lVar11);
                uVar25 = *(uint *)((longlong)&uStackX_10 + lVar11);
                pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
              }
              if ((uVar31 < uVar25) || ((uint)uVar18 < uVar31)) goto LAB_;
              if (*(ushort *)(pbVar30 + uVar31) == 5) {
                *(ushort *)(&stack0xfffffffffffffffa + lVar11) =
                     *(ushort *)(&stack0xfffffffffffffffa + lVar11) | 2;
                *(short *)((longlong)&uStackX_14 + lVar11) = (short)uVar20 + -1;
                uVar20 = (ulonglong)uVar31 & 0xffff;
                *(short *)(auStackX_1e + lVar11 + 4) = (short)uVar31;
                pbVar2 = pbVar30 + uVar20;
                uVar17 = *(ushort *)(auStackX_1e + lVar11 + 6);
                if ((*(ushort *)(pbVar2 + 2) & 0x4000) == 0) {
                  uVar17 = uVar17 & 0xc7ff;
                }
                else {
                  uVar17 = uVar17 ^ (*(ushort *)(pbVar2 + 2) ^ uVar17) & 0x3800;
                }
                *(ushort *)(auStackX_1e + lVar11 + 6) = uVar17;
                uVar29 = (uVar17 ^ *(ushort *)(pbVar2 + 2)) & 0x7ff ^ uVar17;
                *(ushort *)(auStackX_1e + lVar11 + 6) = uVar29;
                pbVar24 = pbVar30 + uVar20 + ((ulonglong)uVar29 & 0x7ff) * 2 +
                                             (ulonglong)((uVar17 >> 0xb & 7) * 2) + 4;
                if (pbVar24 < pbVar2) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101870;
                  func_0x(pbVar2);
                  uVar29 = *(ushort *)(auStackX_1e + lVar11 + 6);
                  uVar20 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 4);
                  pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                  uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
                }
                if (uVar27 - uVar31 <
                    (((*(uint *)(auStackX_1e + lVar11 + 6) & 0x7ff) * 2 - (int)uVar20) -
                    *(int *)(auStackX_1e + lVar11 + -0x1e)) + (int)pbVar24) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1018b0;
                  func_0x(pbVar30 + uVar20);
                  uVar29 = *(ushort *)(auStackX_1e + lVar11 + 6);
                  uVar20 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 4);
                  pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                  uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
                }
                if ((uVar29 & 0x3800) != 0) {
                  puVar19 = (ushort *)(pbVar30 + uVar20 + 4);
                  iVar26 = 0;
                  if ((uVar29 & 0x3800) != 0) {
                    do {
                      if ((uVar29 & 0x7ff) < (*puVar19 & 0x7ff)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101915;
                        func_0x(pbVar30 + uVar20,0x1a);
                        uVar29 = *(ushort *)(auStackX_1e + lVar11 + 6);
                        uVar20 = (ulonglong)*(ushort *)(auStackX_1e + lVar11 + 4);
                        pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
                      }
                      iVar26 = iVar26 + 1;
                      puVar19 = puVar19 + 1;
                    } while (iVar26 < (int)(*(uint *)(auStackX_1e + lVar11 + 6) >> 0xb & 7));
                    uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
                  }
                }
                break;
              }
              if (*(ushort *)(pbVar30 + uVar31) < 0x400) break;
              *(ushort *)(&stack0xfffffffffffffffa + lVar11) =
                   *(ushort *)(&stack0xfffffffffffffffa + lVar11) | 1;
              uVar17 = (short)uVar20 - 1;
              uVar20 = (ulonglong)uVar17;
              *(ushort *)((longlong)&uStackX_14 + lVar11) = uVar17;
              if (uVar17 == 0) break;
            }
          }
          iVar26 = 0;
          if ((*pbVar30 & 0x40) == 0) {
            *(undefined4 *)(auStackX_1e + lVar11) = 0;
          }
          else {
            *(int *)(auStackX_1e + lVar11) = (int)uVar18;
            *(int *)(&stack0xfffffffffffffffc + lVar11) = (int)uVar18 + 0xe;
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101970;
            puVar15 = (ulonglong *)func_0x(&stack0xfffffffffffffffa + lVar11);
            uVar17 = (ushort)(*puVar15 >> 0x30);
            if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
              if ((uVar17 >> 0xe & 1) == 0) {
                uVar17 = uVar17 & 0xdfff;
              }
              else {
                uVar17 = uVar17 | 0x2000;
              }
            }
            if (uVar17 == 0xfffc) {
              iVar26 = (int)((*puVar15 >> 0x20 & 0xffff) >> 5);
            }
            uVar18 = (ulonglong)(uint)(*(int *)(&stack0xfffffffffffffffc + lVar11) + iVar26);
            *(int *)(&stack0xfffffffffffffffc + lVar11) =
                 *(int *)(&stack0xfffffffffffffffc + lVar11) + iVar26;
            pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
          }
          pbVar2 = *(byte **)((longlong)&uStackX_14 + lVar11 + 2);
          if ((pbVar2 != (byte *)0x0) && (pbVar2 < pbVar30 + uVar18)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1019ef;
            cVar8 = func_0x(0x1e93050);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x1019f8;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101a12;
                cVar8 = func_0x(0x1e93050);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101a2e;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101a54;
                  (*_DAT_)(1,0x1782a5c,0x18a2b48,0x886);
                }
              }
            }
            uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101a63;
            func_0x(uVar14,0x12);
            pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
            uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
          }
          if (0x3f3b < (int)uVar18 - 1U) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101a88;
            cVar8 = func_0x(0x1e93050);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101a91;
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101aab;
                cVar8 = func_0x(0x1e93050);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101ac7;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101aed;
                  (*_DAT_)(1,0x1782a5c,0x18a2b48,0x88b);
                }
              }
            }
            uVar14 = *(undefined8 *)(auStackX_1e + lVar11 + -0x1e);
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101afc;
            func_0x(uVar14,5);
            pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
            uVar18 = (ulonglong)*(uint *)(&stack0xfffffffffffffffc + lVar11);
          }
        }
LAB_:
        uVar25 = (uint)uVar18;
        if ((uVar25 < 9) && (((*pbVar30 & 0xe) == 0 || ((*pbVar30 & 0xe) == 0xc)))) {
          bVar34 = (*pbVar30 & 0x40) == 0;
          uVar31 = *(uint *)(auStackX_1e + lVar11);
          uVar27 = 9;
        }
        else {
          bVar34 = (*pbVar30 & 0x40) == 0;
          uVar31 = *(uint *)(auStackX_1e + lVar11);
          uVar27 = uVar25;
        }
      }
      else {
        if (((*pbVar30 & 0x1c) - 0x10 & 0xfffffffb) != 0) {
          if (uVar25 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101362;
            func_0x(&stack0xfffffffffffffffa + lVar11);
            uVar25 = *(uint *)(&stack0xfffffffffffffffc + lVar11);
            if (uVar25 == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101376;
              func_0x(&stack0xfffffffffffffffa + lVar11);
              uVar25 = *(uint *)(&stack0xfffffffffffffffc + lVar11);
            }
            uVar18 = (ulonglong)uVar25;
            pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
          }
          uVar27 = (uint)uVar18;
          if ((uVar27 < 9) && (((*pbVar30 & 0x1c) == 0 || ((*pbVar30 & 0x1c) == 0xc)))) {
            uVar27 = 9;
          }
          bVar34 = (*pbVar30 & 2) == 0;
          uVar31 = *(uint *)(&stack0x00000028 + lVar11);
          goto LAB_;
        }
LAB_:
        uVar25 = (uint)uVar18;
        if (*(short *)(&stack0xfffffffffffffff8 + lVar11) == 0) goto LAB_;
        if (uVar25 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101b43;
          func_0x(&stack0xfffffffffffffffa + lVar11);
          uVar25 = *(uint *)(&stack0xfffffffffffffffc + lVar11);
          if (uVar25 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101b57;
            func_0x(&stack0xfffffffffffffffa + lVar11);
            uVar25 = *(uint *)(&stack0xfffffffffffffffc + lVar11);
          }
          pbVar30 = *(byte **)(auStackX_1e + lVar11 + -0x1e);
        }
        uVar27 = uVar25;
        if ((uVar25 < 9) && (((*pbVar30 & 0x1c) == 0 || ((*pbVar30 & 0x1c) == 0xc)))) {
          uVar27 = 9;
        }
        bVar34 = (*pbVar30 & 2) == 0;
        uVar31 = *(uint *)(&stack0x00000028 + lVar11);
      }
      if (bVar34) {
        uVar31 = uVar27;
      }
      uVar27 = 0x18;
      if (*(short *)(&stack0xfffffffffffffff8 + lVar11) == 0) {
        uVar27 = 0x20;
      }
      if (uVar27 <= uVar31) goto LAB_;
    }
    param_3 = *(longlong **)(&stack0x00000080 + lVar11);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101bce;
    iVar26 = func_0x(param_3,0,0);
    if (iVar26 != 0) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101bf6;
      (*_DAT_)(1,0x190fbe8,0x19073e8,0x1d90);
    }
    uVar18 = (ulonglong)*(uint *)(&stack0x00000050 + lVar11);
    param_1 = *(longlong *)(&stack0x00000068 + lVar11);
    uVar25 = *(uint *)(&stack0x00000054 + lVar11);
    iVar26 = *(int *)(&stack0x00000034 + lVar11);
  }
  pcVar1 = *(code **)(*param_3 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c1a;
  (*pcVar1)(param_3);
  if ((uVar25 == 0) && ((uVar18 & 0x10) == 0)) {
    iVar9 = *(int *)(&stack0x00000058 + lVar11);
  }
  else {
    puVar3 = *(undefined8 **)(param_1 + 0x2e0);
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000038 + lVar11;
    uVar14 = *(undefined8 *)(param_1 + 0x1e8);
    uVar4 = *puVar3;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101c4b;
    func_0x(uVar4,uVar14,&stack0xfffffffffffffff8 + lVar11,uVar18);
    iVar9 = *(int *)(&stack0x00000038 + lVar11);
  }
  uVar14 = *(undefined8 *)(&stack0x00000048 + lVar11);
  if (iVar26 == 0) {
    iVar26 = *(int *)(&stack0x0000005c + lVar11);
  }
  else {
    *(undefined **)(&stack0xfffffffffffffff0 + lVar11) = &stack0x0000003c + lVar11;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar11) = uVar14;
    uVar4 = *(undefined8 *)(param_1 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101ccc;
    func_0x(uVar4,&stack0xfffffffffffffff8 + lVar11,
                    *(undefined8 *)(&stack0x00000078 + lVar11),
                    *(undefined8 *)(&stack0x00000070 + lVar11));
    iVar26 = *(int *)(&stack0x0000003c + lVar11);
  }
  if (((uint)uVar18 >> 8 & 1) == 0) {
    iVar10 = *(int *)(&stack0x00000044 + lVar11);
  }
  else {
    uVar4 = *(undefined8 *)(param_1 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101cf8;
    func_0x(uVar4,&stack0xfffffffffffffff8 + lVar11,uVar14,&stack0x00000040 + lVar11);
    iVar10 = *(int *)(&stack0x00000040 + lVar11);
  }
  if ((((iVar26 != 0) || (iVar9 != 0)) || (iVar10 != 0)) && ((uVar18 & 0x20) == 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d27;
    func_0x(param_3,&stack0xfffffffffffffff8 + lVar11,0,0);
  }
  if ((uVar18 & 4) != 0) {
    *(undefined4 *)(&stack0x00000044 + lVar11) = 0x1dcc;
    lVar22 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar13 = *(longlong *)(lVar22 + 0x100);
    if (lVar13 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d6b;
      (*_DAT_)(0);
      lVar13 = *(longlong *)(lVar22 + 0x100);
    }
    uVar14 = *(undefined8 *)(lVar13 + 1000);
    *(undefined8 *)(&stack0x00000078 + lVar11) = uVar14;
    (&stack0xffffffffffffffe8)[lVar11] = 5;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101d9e;
    lVar13 = (*_DAT_)(0x110,uVar14,0x178ce70,0x1dcc);
    *(longlong *)(&stack0x00000070 + lVar11) = lVar13;
    if (lVar13 == 0) {
      lVar13 = 0;
    }
    else {
      lVar23 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar22 = *(longlong *)(lVar23 + 0x100);
      if (lVar22 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101de1;
        (*_DAT_)(0);
        lVar22 = *(longlong *)(lVar23 + 0x100);
      }
      uVar14 = *(undefined8 *)(lVar22 + 1000);
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101df7;
      lVar13 = func_0x(lVar13,uVar14);
    }
    *(longlong *)(&stack0x00000048 + lVar11) = lVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e1a;
    func_0x(lVar13,0,0x110);
    *(undefined2 *)(lVar13 + 0xe) = 2;
    *(ushort *)(lVar13 + 0x38) = *(ushort *)(lVar13 + 0x38) | 2;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar11) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar11) = &stack0x00000068 + lVar11;
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e4a;
    func_0x(param_1,param_3,lVar13,0);
    *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e52;
    func_0x(lVar13);
    lVar22 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar13 = *(longlong *)(lVar22 + 0x100);
    if (lVar13 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e84;
      (*_DAT_)();
      lVar13 = *(longlong *)(lVar22 + 0x100);
    }
    if (*(int *)(lVar13 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101e9a;
      (*_DAT_)();
    }
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar11) = 0x101eaa;
  func_0x
            (*(ulonglong *)(&stack0x00002058 + lVar11) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar11));
  return;
code_r0x0010057e:
  uVar18 = (ulonglong)uVar17;
  uVar20 = (ulonglong)(uint)uVar17;
  if (-1 < (short)puVar32[(ulonglong)(uVar17 - 1) + 1]) goto LAB_;
  goto LAB_;
}

