
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2)

{
  ushort uVar1;
  undefined2 uVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  char cVar7;
  int iVar8;
  ushort *puVar9;
  undefined2 *puVar10;
  uint *puVar11;
  undefined8 uVar12;
  
  (*_DAT_)(param_2 + 0x268,param_2 + 0x530);
  func_0x(*(undefined8 *)(param_2 + 0x260));
  plVar5 = *(longlong **)(param_2 + 0x230);
  if (*plVar5 == 0) goto LAB_;
  puVar9 = (ushort *)(*plVar5 + 0x62);
  *(ushort **)(param_2 + 0x4b8) = puVar9;
  uVar1 = *puVar9;
  *(ushort *)(param_2 + 0xe8) = uVar1;
  if (((uVar1 >> 10 & 1) != 0) && (2 < *(short *)((longlong)plVar5 + 0xc))) {
    func_0x(plVar5);
    goto LAB_;
  }
  *(int *)(param_2 + 0x50) = (int)*(short *)((longlong)plVar5 + 0xc);
  lVar6 = *plVar5;
  *(longlong *)(param_2 + 0x60) = lVar6;
  puVar10 = (undefined2 *)(lVar6 + 0x62);
  *(undefined2 **)(param_2 + 0x4c0) = puVar10;
  uVar2 = *puVar10;
  *(undefined2 *)(param_2 + 0xf0) = uVar2;
  if (((byte)uVar2 >> 3 & 1) != 0) {
    if (*(int *)(param_2 + 0x50) == 3) {
      *(undefined4 *)(param_2 + 0x50) = 4;
    }
    else if (*(int *)(param_2 + 0x50) < 2) goto LAB_;
    puVar11 = (uint *)(*(longlong *)(param_2 + 0x60) + 100);
    *(uint **)(param_2 + 0x4c8) = puVar11;
    uVar3 = *puVar11;
    *(uint *)(param_2 + 0x210) = uVar3;
    if ((((uVar3 & 8) != 0) &&
        (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0x60) + 0x90), lVar6 != 0)) &&
       (*(longlong *)(param_2 + 0x4d0) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
      func_0x
                (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0x60),
                 *(undefined4 *)(param_2 + 0x50));
    }
  }
LAB_:
  cVar7 = DAT_ >> 7;
  *(char *)(param_2 + 0x48) = -cVar7;
  if (-cVar7 != '\0') {
    puVar11 = (uint *)(*(longlong *)(param_2 + 0x60) + 100);
    *(uint **)(param_2 + 0x4d8) = puVar11;
    uVar3 = *puVar11;
    *(uint *)(param_2 + 0x218) = uVar3;
    if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0x50))) {
      *(uint **)(param_2 + 0x4e0) = puVar11;
      uVar3 = *puVar11;
      *(uint *)(param_2 + 0x220) = uVar3;
      if (((uVar3 & 0xc0000000) != 0x40000000) && (**(longlong **)(param_2 + 0x60) != 0)) {
        iVar8 = (*_DAT_)(**(longlong **)(param_2 + 0x60),0x2000,2,param_2 + 0x228);
        if (iVar8 != 0) {
          LOCK();
          *puVar11 = *puVar11 & 0x3fffffff;
          UNLOCK();
          LOCK();
          *puVar11 = *puVar11 | 0x40000000;
          UNLOCK();
        }
      }
    }
  }
  lVar6 = *(longlong *)(param_2 + 0x60);
  uVar4 = *(undefined4 *)(param_2 + 0x50);
  func_0x(lVar6 + 0x98,uVar4);
  if ((_DAT_ != 0) && ((DAT_ >> 1 & 1) != 0)) {
    func_0x(lVar6,0,uVar4);
  }
  *(uint *)((longlong)plVar5 + 0xc) = *(uint *)((longlong)plVar5 + 0xc) & 0xffff0000;
  *plVar5 = 0;
LAB_:
  uVar12 = (*_DAT_)(param_2 + 0x268);
  (*_DAT_)(uVar12);
  (*_DAT_)(param_2 + 0x268);
  return 0xfffffffffed89773;
}

