
undefined8
FUN_(longlong param_1,undefined8 param_2,undefined8 param_3,uint param_4,uint *param_5,
            uint param_6)

{
  ushort uVar1;
  uint uVar2;
  undefined8 uVar3;
  uint uVar4;
  uint uVar5;
  ulonglong uVar6;
  ushort uVar7;
  short sVar8;
  ushort *puVar9;
  ulonglong uVar10;
  int iVar11;
  ushort uVar12;
  longlong lVar13;
  ulonglong uVar14;
  
  puVar9 = (ushort *)(*(longlong *)(param_1 + 6) + (ulonglong)*(ushort *)(param_1 + 0x1c) + 1);
  uVar14 = (ulonglong)param_4;
  uVar2 = func_0x();
  uVar10 = (ulonglong)*(ushort *)(param_1 + 0x1c);
  lVar13 = *(longlong *)(param_1 + 6);
  uVar7 = 0;
  uVar6 = (ulonglong)uVar2;
  uVar12 = *(ushort *)(uVar6 * 2 + 3 + uVar10 + lVar13) & 0x7fff;
  if (uVar2 != 0) {
    uVar7 = *(ushort *)(uVar10 + lVar13 + 3 + (ulonglong)(uVar2 - 1) * 2) & 0x7fff;
  }
  if (uVar12 < uVar7) {
    func_0x(lVar13,0x13);
    uVar10 = (ulonglong)*(ushort *)(param_1 + 0x1c);
    lVar13 = *(longlong *)(param_1 + 6);
  }
  uVar1 = *(ushort *)(param_1 + 0x22);
  uVar5 = (uint)uVar12 - (uint)uVar7;
  lVar13 = (ulonglong)uVar7 + uVar10 + lVar13 + (ulonglong)uVar1;
  if (param_4 == uVar5) {
    func_0x(lVar13,uVar14,param_3,uVar5);
    uVar3 = 1;
  }
  else {
    sVar8 = (short)param_4 - (short)uVar5;
    iVar11 = (int)sVar8;
    *param_5 = *param_5 + iVar11;
    if (param_6 < *param_5) {
      uVar3 = 0;
    }
    else {
      uVar4 = (uint)(ushort)((puVar9[uVar6 + 1] & 0x7fff) + uVar1 + (short)uVar10);
      if (uVar4 != *(uint *)(param_1 + 2)) {
        func_0x
                  (lVar13 + uVar14,(ulonglong)uVar5 + lVar13,*(uint *)(param_1 + 2) - uVar4);
      }
      func_0x(lVar13,uVar14,param_3,uVar14);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar11;
      if (*(int *)(param_1 + 0x2e) != 0) {
        *(int *)(param_1 + 0x2e) = *(int *)(param_1 + 0x2e) + iVar11;
      }
      if (uVar2 < *puVar9) {
        do {
          uVar7 = puVar9[uVar6 + 1];
          uVar2 = (int)uVar6 + 1;
          puVar9[uVar6 + 1] = (uVar7 + sVar8 ^ uVar7) & 0x7fff ^ uVar7;
          uVar6 = (ulonglong)uVar2;
        } while (uVar2 < *puVar9);
      }
      uVar3 = 1;
    }
  }
  return uVar3;
}

