
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,longlong **param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  ushort uVar5;
  int iVar6;
  code *UNRECOVERED_JUMPTABLE;
  int iVar7;
  undefined auStack_1e8 [32];
  uint uStack_1c8;
  undefined8 uStack_1a0;
  longlong lStack_190;
  undefined4 uStack_170;
  undefined2 uStack_16c;
  longlong lStack_168;
  longlong lStack_160;
  undefined8 uStack_150;
  undefined uStack_148;
  undefined4 uStack_144;
  undefined auStack_130 [4];
  undefined auStack_12c [4];
  undefined auStack_128 [4];
  undefined auStack_124 [20];
  longlong **pplStack_110;
  longlong **pplStack_108;
  undefined8 uStack_100;
  undefined2 uStack_f8;
  undefined4 uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  undefined4 uStack_c4;
  ulonglong uStack_40;
  
  uStack_100 = 0xfffffffffffffffe;
  uStack_40 = _DAT_ ^ (ulonglong)auStack_1e8;
  lVar1 = **param_2;
  lVar2 = **param_3;
  uStack_1a0 = *(undefined8 *)(param_1 + 0x28);
  lStack_190 = lVar1;
  lStack_168 = lVar2;
  lStack_160 = param_1;
  pplStack_110 = param_2;
  pplStack_108 = param_3;
  if (((*(char *)(lVar1 + 2) < '\0') || (*(char *)(lVar2 + 2) < '\0')) ||
     (uVar5 = (short)(1 << ((byte)*(undefined2 *)(lVar1 + 4) & 2)) - 1,
     *(ushort *)(lVar1 + 0x1c) < (ushort)((uVar5 - *(short *)(lVar2 + 0x1c)) + 0x1fa0 & ~uVar5))) {
    uStack_150 = 0;
    uStack_148 = 0;
    uStack_144 = 0;
    *(undefined4 *)(param_1 + 0xf54) = *(undefined4 *)(lVar2 + 0x20);
    *(undefined2 *)(param_1 + 0xf58) = *(undefined2 *)(lVar2 + 0x24);
    *(undefined4 *)(param_1 + 0xf5c) = *(undefined4 *)(lVar1 + 0x20);
    *(undefined2 *)(param_1 + 0xf60) = *(undefined2 *)(lVar1 + 0x24);
    func_0x(param_1,param_2,param_3,&uStack_150);
    if (*param_3 != (longlong *)0x0) {
      if (((*(ushort *)((longlong)*param_3 + 0x62) & 0x400) == 0) ||
         (*(short *)((longlong)param_3 + 0xc) < 3)) {
        iVar7 = (int)*(short *)((longlong)param_3 + 0xc);
        plVar3 = *param_3;
        if (((byte)*(undefined2 *)((longlong)plVar3 + 0x62) >> 3 & 1) != 0) {
          if (iVar7 == 3) {
            iVar7 = 4;
          }
          else if (iVar7 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plVar3 + 100) & 8) != 0) && (lVar1 = plVar3[0x12], lVar1 != 0))
             && (*(longlong *)(lVar1 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar1 + 0x758),plVar3,iVar7);
          }
        }
LAB_:
        if ((((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar3 + 100) & 8) != 0)) &&
             (2 < iVar7)) &&
            (((*(uint *)((longlong)plVar3 + 100) & 0xc0000000) != 0x40000000 && (*plVar3 != 0)))) &&
           (iVar6 = (*_DAT_)(*plVar3,0x2000,2,auStack_128), iVar6 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar3 + 0x13,iVar7);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar3,0,iVar7);
        }
        *(undefined2 *)((longlong)param_3 + 0xc) = 0;
        *param_3 = (longlong *)0x0;
      }
      else {
        func_0x(param_3);
      }
    }
    if (*param_2 != (longlong *)0x0) {
      if (((*(ushort *)((longlong)*param_2 + 0x62) & 0x400) == 0) ||
         (*(short *)((longlong)param_2 + 0xc) < 3)) {
        iVar7 = (int)*(short *)((longlong)param_2 + 0xc);
        plVar3 = *param_2;
        if (((byte)*(undefined2 *)((longlong)plVar3 + 0x62) >> 3 & 1) != 0) {
          if (iVar7 == 3) {
            iVar7 = 4;
          }
          else if (iVar7 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plVar3 + 100) & 8) != 0) && (lVar1 = plVar3[0x12], lVar1 != 0))
             && (*(longlong *)(lVar1 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar1 + 0x758),plVar3,iVar7);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar3 + 100) & 8) != 0)) &&
            ((2 < iVar7 &&
             (((*(uint *)((longlong)plVar3 + 100) & 0xc0000000) != 0x40000000 && (*plVar3 != 0))))))
           && (iVar6 = (*_DAT_)(*plVar3,0x2000,2,auStack_124), iVar6 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar3 + 0x13,iVar7);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar3,0,iVar7);
        }
        *(undefined2 *)((longlong)param_2 + 0xc) = 0;
        *param_2 = (longlong *)0x0;
      }
      else {
        func_0x(param_2);
      }
    }
    func_0x(&uStack_150);
    goto LAB_;
  }
  if ((*(char *)(lVar2 + 1) != '\x01') &&
     (((*(char *)(lVar2 + 1) != '\x02' || (*(char *)(lVar2 + 3) != '\0')) ||
      (*(ushort *)(lVar2 + 6) < 2)))) {
    uStack_f4 = 0;
    uStack_da = 0;
    uStack_d0 = 0;
    uStack_ce = 0;
    uStack_e8 = 0;
    uStack_c4 = 0;
    pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar2 + 0x1ffe) + lVar2);
    if ((*pbStack_f0 & 1) == 0) {
      uStack_f8 = 0;
      uStack_f4 = 0;
      uStack_d2 = 0;
      uStack_d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010029e */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_f0 & 0xe) * 4 + 0x1020c4) - 0x14f06c0
                ))((longlong)(int)(*pbStack_f0 & 0xe),0xfffffffffeb0f940,pbStack_f0);
      return;
    }
    uStack_f8 = 1;
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_f0 & 0x1c) + 0x1020a4) * 4
                           + 0x102094) - 0x14f06c0);
                    /* WARNING: Could not emulate address calculation at 0x0010014c */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
  uStack_1c8 = (uint)*(ushort *)(lVar2 + 0x16);
  func_0x(param_1,param_3,param_2,0);
  uStack_170 = *(undefined4 *)(lVar2 + 0x20);
  uStack_16c = *(undefined2 *)(lVar2 + 0x24);
  if (*param_3 != (longlong *)0x0) {
    if (((*(ushort *)((longlong)*param_3 + 0x62) & 0x400) == 0) ||
       (*(short *)((longlong)param_3 + 0xc) < 3)) {
      iVar7 = (int)*(short *)((longlong)param_3 + 0xc);
      plVar3 = *param_3;
      if (((byte)*(undefined2 *)((longlong)plVar3 + 0x62) >> 3 & 1) != 0) {
        if (iVar7 == 3) {
          iVar7 = 4;
        }
        else if (iVar7 < 2) goto LAB_;
        if ((((*(uint *)((longlong)plVar3 + 100) & 8) != 0) && (lVar2 = plVar3[0x12], lVar2 != 0))
           && (*(longlong *)(lVar2 + 0x758) != 0)) {
          func_0x(*(undefined8 *)(lVar2 + 0x758),plVar3,iVar7);
        }
      }
LAB_:
      if ((((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar3 + 100) & 8) != 0)) &&
           (2 < iVar7)) &&
          (((*(uint *)((longlong)plVar3 + 100) & 0xc0000000) != 0x40000000 && (*plVar3 != 0)))) &&
         (iVar6 = (*_DAT_)(*plVar3,0x2000,2,auStack_130), iVar6 != 0)) {
        LOCK();
        *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) & 0x3fffffff;
        UNLOCK();
        LOCK();
        *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) | 0x40000000;
        UNLOCK();
      }
      func_0x(plVar3 + 0x13,iVar7);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        func_0x(plVar3,0,iVar7);
      }
      *(undefined2 *)((longlong)param_3 + 0xc) = 0;
      *param_3 = (longlong *)0x0;
    }
    else {
      func_0x(param_3);
    }
  }
  lVar4 = lStack_160;
  lVar2 = *(longlong *)(lStack_160 + 0x60);
  *(undefined4 *)(lVar2 + 0x14) = *(undefined4 *)(lVar1 + 0x20);
  *(undefined2 *)(lVar2 + 0x18) = *(undefined2 *)(lVar1 + 0x24);
  *(undefined2 *)(lVar2 + 0x1a) = 0;
  if (*param_2 != (longlong *)0x0) {
    if (((*(ushort *)((longlong)*param_2 + 0x62) >> 10 & 1) != 0) &&
       (2 < *(short *)((longlong)param_2 + 0xc))) {
      func_0x(param_2);
      func_0x(lVar4,&uStack_170);
      goto LAB_;
    }
    iVar7 = (int)*(short *)((longlong)param_2 + 0xc);
    plVar3 = *param_2;
    if (((byte)*(undefined2 *)((longlong)plVar3 + 0x62) >> 3 & 1) != 0) {
      if (iVar7 == 3) {
        iVar7 = 4;
      }
      else if (iVar7 < 2) goto LAB_;
      if ((((*(uint *)((longlong)plVar3 + 100) & 8) != 0) && (lVar1 = plVar3[0x12], lVar1 != 0)) &&
         (*(longlong *)(lVar1 + 0x758) != 0)) {
        func_0x(*(undefined8 *)(lVar1 + 0x758),plVar3,iVar7);
      }
    }
LAB_:
    if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar3 + 100) & 8) != 0)) &&
        ((2 < iVar7 &&
         (((*(uint *)((longlong)plVar3 + 100) & 0xc0000000) != 0x40000000 && (*plVar3 != 0)))))) &&
       (iVar6 = (*_DAT_)(*plVar3,0x2000,2,auStack_12c), iVar6 != 0)) {
      LOCK();
      *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) & 0x3fffffff;
      UNLOCK();
      LOCK();
      *(uint *)((longlong)plVar3 + 100) = *(uint *)((longlong)plVar3 + 100) | 0x40000000;
      UNLOCK();
    }
    func_0x(plVar3 + 0x13,iVar7);
    if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
      func_0x(plVar3,0,iVar7);
    }
    *(undefined2 *)((longlong)param_2 + 0xc) = 0;
    *param_2 = (longlong *)0x0;
  }
  func_0x(lVar4,&uStack_170);
LAB_:
  func_0x(uStack_40 ^ (ulonglong)auStack_1e8);
  return;
}

