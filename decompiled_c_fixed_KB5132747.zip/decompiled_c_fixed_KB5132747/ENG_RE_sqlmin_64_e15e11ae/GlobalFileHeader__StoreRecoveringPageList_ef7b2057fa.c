
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2,ulonglong param_3)

{
  byte *pbVar1;
  undefined2 uVar2;
  longlong lVar3;
  code *pcVar4;
  ushort *puVar5;
  uint **ppuVar6;
  char cVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  longlong lVar11;
  longlong lVar12;
  uint *puVar13;
  longlong lVar14;
  undefined8 uVar15;
  ushort uVar16;
  ushort uVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  short *psVar20;
  uint uVar21;
  short sVar22;
  byte *pbVar23;
  longlong lVar24;
  longlong *plVar25;
  ulonglong uVar26;
  uint uVar27;
  ushort *puVar28;
  byte *pbVar29;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_4d0;
  undefined4 auStack_4c8 [8];
  undefined8 uStack_4a8;
  uint *apuStack_4a0 [3];
  undefined8 uStack_488;
  undefined uStack_480;
  uint uStack_47c;
  uint uStack_478;
  short sStack_470;
  ushort uStack_46e;
  uint uStack_46c;
  byte *pbStack_468;
  undefined8 uStack_460;
  uint uStack_458;
  ushort uStack_454;
  byte *pbStack_452;
  undefined2 uStack_44a;
  undefined2 uStack_448;
  ushort uStack_446;
  ushort uStack_444;
  undefined2 uStack_442;
  int iStack_438;
  short sStack_434;
  short asStack_430 [2];
  undefined8 uStack_42c;
  undefined4 uStack_424;
  uint auStack_420 [2];
  undefined8 uStack_418;
  ushort uStack_410;
  undefined8 uStack_408;
  ushort uStack_400;
  undefined auStack_3f8 [4];
  undefined4 uStack_3f4;
  int iStack_3f0;
  undefined4 uStack_3ec;
  undefined2 uStack_3e8;
  undefined4 uStack_3e4;
  undefined2 uStack_3e0;
  undefined4 uStack_3dc;
  undefined2 uStack_3d8;
  undefined8 uStack_3d0;
  undefined2 uStack_3c8;
  undefined8 uStack_3c0;
  undefined2 uStack_3b8;
  undefined8 uStack_3b0;
  undefined2 uStack_3a8;
  undefined8 uStack_3a0;
  ushort uStack_398;
  undefined auStack_390 [4];
  undefined auStack_38c [4];
  undefined auStack_388 [4];
  undefined auStack_384 [4];
  longlong lStack_380;
  undefined auStack_378 [8];
  longlong *plStack_370;
  uint uStack_368;
  undefined8 uStack_364;
  undefined8 uStack_350;
  undefined auStack_348 [8];
  undefined4 uStack_340;
  undefined4 uStack_338;
  uint **ppuStack_330;
  undefined *puStack_328;
  undefined8 uStack_320;
  uint *puStack_318;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  longlong lStack_308;
  undefined4 uStack_300;
  undefined4 uStack_2fc;
  longlong lStack_2f8;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  short *psStack_2e8;
  int iStack_2e0;
  undefined4 uStack_2dc;
  short *psStack_2d8;
  int iStack_2d0;
  undefined4 uStack_2cc;
  undefined8 uStack_2c8;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined auStack_2b8 [448];
  undefined8 uStack_f8;
  undefined8 uStack_f0;
  uint uStack_e8;
  short sStack_e4;
  int iStack_e2;
  undefined uStack_de;
  undefined uStack_dd;
  short asStack_a8 [24];
  short asStack_78 [24];
  ulonglong uStack_48;
  
  uStack_350 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&uStack_488;
  uStack_488 = (longlong *)0x0;
  uStack_480 = 0;
  uStack_47c = 0;
  sStack_470 = -1;
  pbStack_468 = (byte *)0x0;
  uStack_46c = 0;
  pbStack_452 = (byte *)0x0;
  uStack_448 = 0;
  uStack_446 = 0;
  uStack_444 = 0;
  uStack_442 = 0;
  uStack_460 = 0;
  uVar26 = (param_3 & 0xffffffff) * 4;
  plStack_370 = param_1;
  if (uVar26 < 0x100000000) {
    iVar8 = (int)uVar26;
    uVar27 = iVar8 + 4;
    if (uVar27 < 4) goto LAB_;
  }
  else {
    iVar8 = -1;
    uStack_4d0 = 0x1000c3;
    func_0x(0x80070216,param_3 & 0xffffffff,4);
LAB_:
    uStack_4d0 = 0x1000db;
    func_0x(0x80070216,4,iVar8);
    uVar27 = 0xffffffff;
  }
  uVar18 = (ulonglong)uVar27;
  uStack_4d0 = 0x1000fa;
  lVar11 = func_0x();
  lVar11 = -lVar11;
  lStack_380 = (longlong)&uStack_488 + lVar11;
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10011c;
  func_0x((longlong)&uStack_488 + lVar11 + 4,uVar18 - 4,param_2,uVar26);
  lVar14 = param_1[1];
  if (lVar14 == 0) {
    *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10014d;
    (*_DAT_)(1,0x1551c18,0x1521348,0xe67);
    lVar14 = param_1[1];
  }
  lVar12 = 0;
  sStack_434 = *(short *)(*param_1 + 0x20);
  iStack_438 = 0;
  uStack_364 = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar3 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar3 != 0) && (lVar3 = **(longlong **)(lVar3 + 0x38), lVar3 != 0)) {
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1001c1;
      iVar8 = (*_DAT_)(lVar3,0x337);
      if (iVar8 != 0) goto LAB_;
    }
    lVar3 = *(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8);
    if (lVar3 != 0) {
      lVar12 = *(longlong *)(lVar3 + 0x60);
    }
  }
LAB_:
  lVar3 = *(longlong *)(lVar14 + 0x728);
LAB_:
  plVar25 = uStack_488;
  auStack_420[0] = 0;
  if (uStack_488 != (longlong *)0x0) {
    iVar8 = (int)(short)uStack_47c;
    if (((*(ushort *)((longlong)uStack_488 + 0x62) & 0x400) == 0) || (iVar8 < 3)) {
      if (((byte)*(undefined2 *)((longlong)uStack_488 + 0x62) >> 3 & 1) != 0) {
        if (iVar8 == 3) {
          iVar8 = 4;
        }
        else if (iVar8 < 2) goto LAB_;
        if ((((*(uint *)((longlong)uStack_488 + 100) & 8) != 0) &&
            (lVar24 = uStack_488[0x12], lVar24 != 0)) && (*(longlong *)(lVar24 + 0x758) != 0)) {
          uVar15 = *(undefined8 *)(lVar24 + 0x758);
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10029c;
          func_0x(uVar15,plVar25,iVar8);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
         ((2 < iVar8 &&
          (((*(uint *)((longlong)plVar25 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar24 = *plVar25, lVar24 != 0)))))) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1002e0;
        iVar10 = (*_DAT_)(lVar24,0x2000,2,auStack_390);
        if (iVar10 != 0) {
          LOCK();
          *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100302;
      func_0x(plVar25 + 0x13,iVar8);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100321;
        func_0x(plVar25,0,iVar8);
      }
      uStack_47c = uStack_47c & 0xffff0000;
      uStack_488 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10023b;
      func_0x(&uStack_488);
    }
  }
  if (*(longlong *)(lVar14 + 0x728) != 0) {
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100351;
    func_0x(&uStack_488,&iStack_438,lVar14);
    plVar25 = uStack_488;
    if (uStack_488 != (longlong *)0x0) {
      iVar8 = (int)(short)uStack_47c;
      if (((*(ushort *)((longlong)uStack_488 + 0x62) & 0x400) == 0) || (iVar8 < 3)) {
        if (((byte)*(undefined2 *)((longlong)uStack_488 + 0x62) >> 3 & 1) != 0) {
          if (iVar8 == 3) {
            iVar8 = 4;
          }
          else if (iVar8 < 2) goto LAB_;
          if ((((*(uint *)((longlong)uStack_488 + 100) & 8) != 0) &&
              (lVar24 = uStack_488[0x12], lVar24 != 0)) && (*(longlong *)(lVar24 + 0x758) != 0)) {
            uVar15 = *(undefined8 *)(lVar24 + 0x758);
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1003da;
            func_0x(uVar15,plVar25,iVar8);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
           ((2 < iVar8 &&
            (((*(uint *)((longlong)plVar25 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar24 = *plVar25, lVar24 != 0)))))) {
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10041e;
          iVar10 = (*_DAT_)(lVar24,0x2000,2,auStack_38c);
          if (iVar10 != 0) {
            LOCK();
            *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100440;
        func_0x(plVar25 + 0x13,iVar8);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10045f;
          func_0x(plVar25,0,iVar8);
        }
        uStack_47c = uStack_47c & 0xffff0000;
        uStack_488 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100379;
        func_0x(&uStack_488);
      }
    }
  }
  iVar8 = 0;
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100478;
  func_0x(lVar14,&iStack_438);
  *(uint **)((longlong)apuStack_4a0 + lVar11) = &uStack_368;
  *(undefined4 *)((longlong)&uStack_4a8 + lVar11) = 4;
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1004a3;
  uStack_488 = (longlong *)func_0x(_DAT_,lVar14,&iStack_438,auStack_420);
  if (lVar12 != 0) {
    uVar26 = (ulonglong)(*(uint *)(lVar12 + 0x500) & 0xf);
    if (*(longlong *)(lVar12 + 0x508 + uVar26 * 8) != *uStack_488) {
      *(longlong *)(lVar12 + 0x508 + uVar26 * 8) = *uStack_488;
      *(longlong *)(lVar12 + 0x500) = *(longlong *)(lVar12 + 0x500) + 1;
    }
  }
  uStack_47c = (auStack_420[0] >> 3 & 1) << 0x18 | uStack_47c & 0xff0004 | 4;
  uStack_478 = auStack_420[0] >> 4 & 1 | uStack_478 & 0xffffff00;
  if (((lVar3 != 0) && (lVar12 != 0)) && (lVar12 == *(longlong *)(lVar14 + 0x1c38))) {
    *(longlong *)(lVar3 + 0x5b28) = *(longlong *)(lVar3 + 0x5b28) + 1;
    if ((int)uStack_364 != 0) {
      *(longlong *)(lVar3 + 0x5b30) = *(longlong *)(lVar3 + 0x5b30) + 1;
      *(longlong *)(lVar3 + 0x5b38) = *(longlong *)(lVar3 + 0x5b38) + (ulonglong)uStack_368;
      if (0xffffff < uStack_47c) {
        *(longlong *)(lVar3 + 0x5b40) = *(longlong *)(lVar3 + 0x5b40) + 1;
        *(longlong *)(lVar3 + 0x5b48) = *(longlong *)(lVar3 + 0x5b48) + (ulonglong)uStack_368;
      }
    }
  }
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100572;
  cVar7 = func_0x(lVar14);
  uVar26 = 9;
  iVar10 = 0;
  if (((cVar7 == '\0') || (*(char *)(lVar14 + 0x2050) == '\0')) ||
     ((iStack_438 == 0 || ((iStack_438 == 9 && (sStack_434 == 1)))))) goto LAB_;
  lVar24 = *uStack_488;
  if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
    uStack_408 = *(undefined8 *)(lVar24 + 0x28);
    uStack_400 = *(ushort *)(lVar24 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar24 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar24 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar24 + 0x18) != 99) goto LAB_;
    }
    uStack_3ec = *(undefined4 *)(lVar24 + 0x20);
    uStack_3e8 = *(undefined2 *)(lVar24 + 0x24);
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1005fb;
    cVar7 = func_0x(&uStack_3ec);
    if (cVar7 == '\0') goto LAB_;
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10060e;
    func_0x(lVar24,&uStack_408);
  }
  uVar27 = *(uint *)(lVar14 + 0x2108);
  do {
    uVar9 = uVar27 & 0xfffffffe;
    uStack_42c = *(undefined8 *)(lVar14 + 0x20fc);
    uStack_424 = *(undefined4 *)(lVar14 + 0x2104);
    LOCK();
    *(undefined4 *)((longlong)auStack_4c8 + lVar11) =
         *(undefined4 *)((longlong)auStack_4c8 + lVar11);
    UNLOCK();
    uVar27 = *(uint *)(lVar14 + 0x2108);
  } while (uVar9 != uVar27);
  if ((uint)uStack_408 <= (uint)uStack_42c) {
    if ((uint)uStack_42c != (uint)uStack_408) goto LAB_;
    uVar27 = (uint)((ulonglong)uStack_42c >> 0x20);
    if ((uStack_408._4_4_ <= uVar27) &&
       ((uVar27 != uStack_408._4_4_ || (uStack_400 <= (ushort)uStack_424)))) goto LAB_;
  }
  if ((*(char *)(lVar14 + 0x6ac8) == '\0') &&
     (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) != *(longlong *)(lVar14 + 0x2120))) {
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1006d3;
    cVar7 = func_0x(lVar14);
    if (cVar7 == '\0') {
      uVar27 = *(uint *)(lVar14 + 0x2108);
      do {
        uVar9 = uVar27 & 0xfffffffe;
        uVar15 = *(undefined8 *)(lVar14 + 0x20fc);
        uStack_42c = uVar15;
        uStack_424 = *(undefined4 *)(lVar14 + 0x2104);
        LOCK();
        *(undefined4 *)((longlong)auStack_4c8 + lVar11) =
             *(undefined4 *)((longlong)auStack_4c8 + lVar11);
        UNLOCK();
        uVar27 = *(uint *)(lVar14 + 0x2108);
      } while (uVar9 != uVar27);
      uVar16 = (ushort)uStack_424;
      uStack_398 = (ushort)uStack_424;
      lVar12 = *uStack_488;
      uStack_3a0 = uVar15;
      if (*(short *)(lVar12 + 0x24) == 0) {
LAB_:
        uStack_418 = *(undefined8 *)(lVar12 + 0x28);
        uStack_410 = *(ushort *)(lVar12 + 0x30);
      }
      else {
        cVar7 = *(char *)(lVar12 + 1);
        if (cVar7 == '\v') {
          if (*(int *)(lVar12 + 0x18) != 99) {
LAB_:
            if (cVar7 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar7 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar12 + 0x18) != 99) goto LAB_;
        }
        uStack_3dc = *(undefined4 *)(lVar12 + 0x20);
        uStack_3d8 = *(undefined2 *)(lVar12 + 0x24);
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1009b3;
        cVar7 = func_0x(&uStack_3dc);
        if (cVar7 == '\0') goto LAB_;
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1009c3;
        func_0x(lVar12,&uStack_418);
      }
      if ((uint)uStack_42c < (uint)uStack_418) {
LAB_:
        lVar12 = *(longlong *)(lVar14 + 0x6b0);
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100a28;
        func_0x(&uStack_418,asStack_a8,auStack_3f8);
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100a42;
        func_0x(&uStack_3a0,asStack_78,auStack_3f8);
        if ((_DAT_ & 0x10000) != 0) {
          uStack_340 = 0x60000;
          uStack_338 = 0;
          ppuStack_330 = &puStack_318;
          puStack_328 = auStack_2b8;
          uStack_f8 = 0;
          uStack_320 = 0;
          uStack_f0 = 0;
          puStack_318 = &uStack_e8;
          uStack_310 = 0x34;
          uStack_30c = 5;
          uStack_300 = 0x10;
          uStack_2fc = 5;
          uStack_2f0 = 0x10;
          uStack_2ec = 6;
          psStack_2e8 = (short *)0x0;
          iStack_2e0 = 0;
          uStack_2dc = 7;
          psStack_2d8 = (short *)0x0;
          iStack_2d0 = 0;
          uStack_2cc = 8;
          uStack_2c8 = 0;
          uStack_2c0 = 0;
          uStack_2bc = 9;
          uStack_e8 = (uint)*(ushort *)(lVar14 + 0x6b8);
          sStack_e4 = sStack_434;
          iStack_e2 = iStack_438;
          uStack_de = 0xff;
          uStack_dd = *(undefined *)(*uStack_488 + 1);
          lStack_308 = lVar12 + 0x254;
          lStack_2f8 = lVar12 + 0x244;
          lVar14 = -1;
          do {
            lVar14 = lVar14 + 1;
          } while (asStack_a8[lVar14] != 0);
          psStack_2e8 = asStack_a8;
          iStack_2e0 = (int)lVar14 * 2;
          lVar14 = -1;
          do {
            lVar14 = lVar14 + 1;
          } while (asStack_78[lVar14] != 0);
          iStack_2d0 = (int)lVar14 * 2;
          psStack_2d8 = asStack_78;
          uStack_3f4 = 0;
          pcVar4 = *(code **)(_DAT_ + 0x10);
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100c0a;
          puVar13 = (uint *)(*pcVar4)(lVar12,&uStack_3f4);
          ppuVar6 = ppuStack_330;
          if (puVar13 != (uint *)0x0) {
            lVar14 = -1;
            do {
              lVar14 = lVar14 + 1;
            } while (*(short *)((longlong)puVar13 + lVar14 * 2) != 0);
            iVar10 = (int)lVar14 * 2;
          }
          ppuStack_330[10] = puVar13;
          *(int *)(ppuVar6 + 0xb) = iVar10;
          *(undefined4 *)((longlong)ppuVar6 + 0x5c) = 9;
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100c4e;
          func_0x(auStack_348);
        }
      }
      else if ((uint)uStack_42c == (uint)uStack_418) {
        uVar27 = (uint)((ulonglong)uStack_418 >> 0x20);
        if ((uStack_42c._4_4_ < uVar27) || ((uStack_42c._4_4_ == uVar27 && (uVar16 < uStack_410))))
        goto LAB_;
      }
LAB_:
      plVar25 = uStack_488;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100c69;
      lVar14 = func_0x(_DAT_,plVar25,1,0);
      *(ushort *)(lVar14 + 4) = *(ushort *)(lVar14 + 4) & 0xedff;
      *(undefined4 *)(lVar14 + 0x40) = 1;
      lVar14 = *uStack_488;
      if ((1 < *(ushort *)(lVar14 + 0x16)) && (*(short *)(lVar14 + 0x1ffc) != 0)) {
        *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100ca3;
        func_0x(lVar14,1,0,0);
      }
      sStack_470 = 0;
      *(undefined *)((longlong)apuStack_4a0 + lVar11) = 0;
      *(undefined4 *)((longlong)&uStack_4a8 + lVar11) = 0;
      lVar12 = lStack_380;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100cc4;
      func_0x(&uStack_46e,lVar12);
      if (sStack_470 == 0) {
        uVar18 = (ulonglong)uStack_46c;
        pbVar23 = pbStack_468;
        if (uStack_46c == 0) {
          uStack_46e = 0;
          uVar18 = uStack_460 & 0xffffffff;
          uVar27 = (uint)uStack_460;
          if ((*pbStack_468 & 0x10) != 0) {
            uVar27 = (uint)uStack_460 + 2 + (*(ushort *)(pbStack_468 + uVar18) + 7 >> 3);
            uVar18 = (ulonglong)uVar27;
          }
          uStack_460 = CONCAT44(uVar27,(uint)uStack_460);
          uStack_458 = (uint)uVar18;
          if ((*pbStack_468 & 0x20) == 0) {
            uStack_454 = 0;
            uStack_46c = uStack_458;
          }
          else {
            puVar28 = (ushort *)(pbStack_468 + uVar18);
            uStack_454 = *puVar28;
            if (uStack_454 == 0) {
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100d31;
              cVar7 = func_0x(0x1aac5d0);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100d3a;
                cVar7 = func_0x();
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100d4a;
                  cVar7 = func_0x(0x1aac5d0);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100d66;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100d89;
                    (*_DAT_)(1,0x139bfdc,0x14bc0c8,0x80f);
                  }
                }
              }
              pbVar23 = pbStack_468;
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100d97;
              func_0x(pbVar23,3);
            }
            uStack_458 = uStack_460._4_4_ + 2 + (uint)uStack_454 * 2;
            if (0x1f9e < uStack_458) {
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100dc6;
              cVar7 = func_0x(0x1aac5d0);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100dcf;
                cVar7 = func_0x();
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100ddf;
                  cVar7 = func_0x(0x1aac5d0);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100dfb;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100e1e;
                    (*_DAT_)(1,0x139bfdc,0x14bc0c8,0x816);
                  }
                }
              }
              pbVar23 = pbStack_468;
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100e2c;
              func_0x(pbVar23,4);
            }
            uVar19 = (ulonglong)uStack_454;
            uStack_46c = puVar28[uVar19] & 0x7fff;
            if (uStack_46c < uStack_458) {
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100e60;
              cVar7 = func_0x(0x1aac5d0);
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100e69;
                cVar7 = func_0x();
                if (cVar7 != '\0') {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100e79;
                  cVar7 = func_0x(0x1aac5d0);
                  if (cVar7 == '\0') {
                    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100e95;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100eb8;
                    (*_DAT_)(1,0x139bfdc,0x14bc0c8,0x81d);
                  }
                }
              }
              pbVar23 = pbStack_468;
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100ec6;
              func_0x(pbVar23,4);
              uVar19 = (ulonglong)uStack_454;
            }
            uVar18 = (ulonglong)uStack_46c;
            iVar10 = 0;
            pbVar23 = pbStack_468;
            puVar5 = puVar28;
            uVar27 = uStack_458;
            uVar9 = uStack_458;
            if ((short)uVar19 != 0) {
              do {
                uVar9 = puVar5[1] & 0x7fff;
                if ((uVar9 < uVar27) || ((uint)uVar18 < uVar9)) {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100f13;
                  cVar7 = func_0x(0x1aac5d0);
                  if (cVar7 != '\0') {
                    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100f1c;
                    cVar7 = func_0x();
                    if (cVar7 != '\0') {
                      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100f2c;
                      cVar7 = func_0x(0x1aac5d0);
                      if (cVar7 == '\0') {
                        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100f48;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100f6e;
                        (*_DAT_)(1,0x139bfdc,0x14bc0c8,0x82a);
                      }
                    }
                  }
                  pbVar23 = pbStack_468;
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100f7c;
                  func_0x(pbVar23,4);
                  uVar19 = (ulonglong)uStack_454;
                  uVar18 = (ulonglong)uStack_46c;
                  pbVar23 = pbStack_468;
                }
                iVar8 = iVar8 + 1;
                puVar5 = puVar5 + 1;
                uVar27 = uVar9;
                uVar9 = uStack_458;
              } while (iVar8 < (int)uVar19);
            }
            while( true ) {
              if (-1 < (short)puVar28[(ulonglong)((int)uVar19 - 1) + 1]) break;
              uVar27 = uVar9;
              if ((int)uVar19 != 1) {
                uVar27 = *(ushort *)(pbVar23 + uVar19 * 2 + ((uStack_460 >> 0x20) - 2)) & 0x7fff;
              }
              uVar21 = *(ushort *)(pbVar23 + uVar19 * 2 + (uStack_460 >> 0x20)) & 0x7fff;
              if (((uVar27 < uVar9) || (uVar21 < uVar27)) ||
                 (uVar16 = (ushort)uVar19, (uint)uVar18 < uVar21)) {
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101007;
                func_0x(pbVar23,7);
                uVar18 = (ulonglong)uStack_46c;
                pbVar23 = pbStack_468;
                uVar16 = uStack_454;
                uVar9 = uStack_458;
              }
              if ((uVar27 < uVar9) || ((uint)uVar18 < uVar27)) goto LAB_;
              if (*(ushort *)(pbVar23 + uVar27) == 5) {
                uStack_46e = uStack_46e | 2;
                uStack_454 = uVar16 - 1;
                uVar19 = (ulonglong)(uVar27 & 0xffff);
                uStack_446 = (ushort)uVar27;
                pbVar1 = pbVar23 + uVar19;
                uVar16 = *(ushort *)(pbVar1 + 2);
                uVar17 = uStack_444 & 0xc7ff;
                if ((uVar16 >> 0xe & 1) != 0) {
                  uVar17 = (uStack_444 ^ uVar16) & 0x3800 ^ uStack_444;
                }
                uStack_444 = (uVar17 ^ uVar16) & 0x7ff ^ uVar17;
                pbVar29 = pbVar23 + uVar19 + (ulonglong)((uStack_444 & 0x7ff) * 2) + 4 +
                                             (ulonglong)((uVar17 >> 0xb & 7) * 2);
                if (pbVar29 < pbVar1) {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101139;
                  func_0x(pbVar1,0x19);
                  uVar19 = (ulonglong)uStack_446;
                  uVar18 = (ulonglong)uStack_46c;
                  pbVar23 = pbStack_468;
                }
                if (uVar21 - uVar27 <
                    (((uStack_444 & 0x7ff) * 2 - (int)uVar19) - (int)pbStack_468) + (int)pbVar29) {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101175;
                  func_0x(pbVar23 + uVar19,0x19);
                  uVar19 = (ulonglong)uStack_446;
                  uVar18 = (ulonglong)uStack_46c;
                  pbVar23 = pbStack_468;
                }
                if (((uStack_444 & 0x3800) != 0) &&
                   (puVar28 = (ushort *)(pbVar23 + uVar19 + 4), uVar16 = uStack_444,
                   (uStack_444 & 0x3800) != 0)) {
                  do {
                    if ((uVar16 & 0x7ff) < (*puVar28 & 0x7ff)) {
                      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1011e2;
                      func_0x(pbVar23 + uVar19,0x1a);
                      uVar19 = (ulonglong)uStack_446;
                      pbVar23 = pbStack_468;
                      uVar16 = uStack_444;
                    }
                    iVar10 = iVar10 + 1;
                    puVar28 = puVar28 + 1;
                  } while (iVar10 < (int)((uStack_444 & 0x3800) >> 0xb));
                  uVar18 = (ulonglong)uStack_46c;
                }
                break;
              }
              if (*(ushort *)(pbVar23 + uVar27) < 0x400) break;
              uStack_46e = uStack_46e | 1;
              uStack_454 = uVar16 - 1;
              uVar19 = (ulonglong)uStack_454;
              if (uStack_454 == 0) break;
            }
          }
          if ((*pbVar23 & 0x40) == 0) {
            uStack_44a = 0;
            uStack_448 = 0;
          }
          else {
            uStack_44a = (undefined2)uVar18;
            uStack_448 = (undefined2)(uVar18 >> 0x10);
            uStack_46c = (int)uVar18 + 0xe;
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101075;
            uVar15 = func_0x(&uStack_46e);
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101084;
            func_0x(uVar15,auStack_378);
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101090;
            iVar8 = func_0x(auStack_378);
            uStack_46c = uStack_46c + iVar8;
            uVar18 = (ulonglong)uStack_46c;
            pbVar23 = pbStack_468;
          }
          if ((pbStack_452 != (byte *)0x0) && (pbStack_452 < pbVar23 + uVar18)) {
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101248;
            cVar7 = func_0x(0x1aac5d0);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101251;
              cVar7 = func_0x();
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101261;
                cVar7 = func_0x(0x1aac5d0);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10127d;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1012a3;
                  (*_DAT_)(1,0x139bfdc,0x14bc0c8,0x886);
                }
              }
            }
            pbVar23 = pbStack_468;
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1012b1;
            func_0x(pbVar23,0x12);
            uVar18 = (ulonglong)uStack_46c;
            pbVar23 = pbStack_468;
          }
          if (0x3f3b < (int)uVar18 - 1U) {
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1012d4;
            cVar7 = func_0x(0x1aac5d0);
            if (cVar7 != '\0') {
              *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1012dd;
              cVar7 = func_0x();
              if (cVar7 != '\0') {
                *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1012ed;
                cVar7 = func_0x(0x1aac5d0);
                if (cVar7 == '\0') {
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101309;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
                  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10134c;
                  (*_DAT_)(1,0x139bfdc,0x14bc0c8,0x88b);
                }
              }
            }
            pbVar23 = pbStack_468;
            *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10131c;
            func_0x(pbVar23,5);
            uVar18 = (ulonglong)uStack_46c;
            pbVar23 = pbStack_468;
          }
        }
LAB_:
        if ((8 < (uint)uVar18) || (((*pbVar23 & 0xe) != 0 && ((*pbVar23 & 0xe) != 0xc)))) {
          uVar26 = uVar18;
        }
      }
      else {
        if (uStack_46c == 0) {
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10137b;
          func_0x(&uStack_46e);
        }
        if ((8 < uStack_46c) || (((*pbStack_468 & 0x1c) != 0 && ((*pbStack_468 & 0x1c) != 0xc)))) {
          uVar26 = (ulonglong)uStack_46c;
        }
      }
      *(short **)((longlong)apuStack_4a0 + lVar11 + 8) = asStack_430;
      *(int **)((longlong)apuStack_4a0 + lVar11) = &iStack_3f0;
      *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1013c1;
      iVar8 = func_0x(lVar14,1,uVar26,0);
      sVar22 = 0;
      if (iVar8 == 0) {
        if (asStack_430[0] != 0) {
          uVar16 = *(ushort *)(lVar14 + 0x16);
          lVar12 = (ulonglong)uVar16 - 1;
          if ((longlong)(ulonglong)(ushort)(uVar16 - asStack_430[0]) <= lVar12) {
            psVar20 = (short *)(lVar14 + (0xfff - lVar12) * 2);
            do {
              if (*psVar20 != 0) break;
              sVar22 = sVar22 + 1;
              lVar12 = lVar12 + -1;
              psVar20 = psVar20 + 1;
            } while ((longlong)(ulonglong)(ushort)(uVar16 - asStack_430[0]) <= lVar12);
          }
          *(ushort *)(lVar14 + 0x16) = uVar16 - sVar22;
          *(short *)(lVar14 + 0x1c) = *(short *)(lVar14 + 0x1c) + sVar22 * 2;
        }
        if (iStack_3f0 != 0) {
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10146e;
          func_0x(lVar14,0xffffffff);
        }
      }
      else {
        *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1013e6;
        (*_DAT_)(1,0x1551308,0x1521348,0xe88);
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1013fc;
        (*_DAT_)(0x24,0x18,0x14,100);
      }
      *(undefined8 *)((longlong)apuStack_4a0 + lVar11) = 0;
      *(undefined2 *)((longlong)&uStack_4a8 + lVar11) = 0;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101489;
      func_0x(lVar14,1,&sStack_470,0);
      plVar25 = uStack_488;
      uVar15 = *(undefined8 *)(plStack_370[1] + 0x758);
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1014a7;
      func_0x(uVar15,plVar25,0);
      plVar25 = uStack_488;
      uStack_3c0 = 0;
      uStack_3b8 = 0;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1014d3;
      func_0x(_DAT_,plVar25,0,&uStack_3c0);
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1014dc;
      func_0x(&uStack_488);
      plVar25 = uStack_488;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1014e7;
      func_0x(plVar25,0);
      plVar25 = uStack_488;
      lVar14 = uStack_488[0x12];
      if (lVar14 == 0) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1014ff;
        func_0x(plVar25);
        lVar14 = plVar25[0x12];
      }
      uVar2 = *(undefined2 *)((longlong)plVar25 + 0x74);
      uVar15 = *(undefined8 *)(lVar14 + 0x6a0);
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10151a;
      lVar14 = func_0x(uVar15,uVar2,0);
      if ((((_DAT_ != 0) || ((_DAT_ & 0x40) != 0)) && ((_DAT_ & 8) == 0)) &&
         (*(short *)(lVar14 + 0x60) != 2)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101545;
        func_0x(lVar14,1);
      }
      plVar25 = uStack_488;
      if (uStack_488 == (longlong *)0x0) goto LAB_;
      iVar8 = (int)(short)uStack_47c;
      if (((*(ushort *)((longlong)uStack_488 + 0x62) >> 10 & 1) != 0) && (2 < iVar8)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x10156f;
        func_0x(&uStack_488);
        goto LAB_;
      }
      if (((byte)*(undefined2 *)((longlong)uStack_488 + 0x62) >> 3 & 1) != 0) {
        if (iVar8 == 3) {
          iVar8 = 4;
        }
        else if (iVar8 < 2) goto LAB_;
        if ((((*(uint *)((longlong)uStack_488 + 100) & 8) != 0) &&
            (lVar14 = uStack_488[0x12], lVar14 != 0)) && (*(longlong *)(lVar14 + 0x758) != 0)) {
          uVar15 = *(undefined8 *)(lVar14 + 0x758);
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1015d0;
          func_0x(uVar15,plVar25,iVar8);
        }
      }
LAB_:
      if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
          (2 < iVar8)) &&
         (((*(uint *)((longlong)plVar25 + 100) & 0xc0000000) != 0x40000000 &&
          (lVar14 = *plVar25, lVar14 != 0)))) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101614;
        iVar10 = (*_DAT_)(lVar14,0x2000,2,auStack_384);
        if (iVar10 != 0) {
          LOCK();
          *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101636;
      func_0x(plVar25 + 0x13,iVar8);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101655;
        func_0x(plVar25,0,iVar8);
      }
      uStack_47c = uStack_47c & 0xffff0000;
      uStack_488 = (longlong *)0x0;
LAB_:
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101669;
      func_0x(&uStack_488);
      uVar26 = uStack_48 ^ (ulonglong)&uStack_488;
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x101678;
      func_0x(uVar26);
      return;
    }
  }
  if (*(longlong *)
       (*(longlong *)
         ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8)
       + 0x60) == *(longlong *)(lVar14 + 0x2120)) goto LAB_;
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100717;
  cVar7 = func_0x(lVar14);
  if (cVar7 != '\0') goto LAB_;
  if (lVar12 == 0) {
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100729;
    lVar12 = func_0x();
  }
  lVar24 = *uStack_488;
  if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
    uStack_3d0 = *(undefined8 *)(lVar24 + 0x28);
    uStack_3c8 = *(undefined2 *)(lVar24 + 0x30);
  }
  else {
    cVar7 = *(char *)(lVar24 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(lVar24 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar24 + 0x18) != 99) goto LAB_;
    }
    uStack_3e4 = *(undefined4 *)(lVar24 + 0x20);
    uStack_3e0 = *(undefined2 *)(lVar24 + 0x24);
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100781;
    cVar7 = func_0x(&uStack_3e4);
    if (cVar7 == '\0') goto LAB_;
    *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100794;
    func_0x(lVar24,&uStack_3d0);
  }
  plVar25 = uStack_488;
  if (uStack_488 != (longlong *)0x0) {
    iVar8 = (int)(short)uStack_47c;
    if (((*(ushort *)((longlong)uStack_488 + 0x62) & 0x400) == 0) || (iVar8 < 3)) {
      if (((byte)*(undefined2 *)((longlong)uStack_488 + 0x62) >> 3 & 1) != 0) {
        if (iVar8 == 3) {
          iVar8 = 4;
        }
        else if (iVar8 < 2) goto LAB_;
        if ((((*(uint *)((longlong)uStack_488 + 100) & 8) != 0) &&
            (lVar24 = uStack_488[0x12], lVar24 != 0)) && (*(longlong *)(lVar24 + 0x758) != 0)) {
          uVar15 = *(undefined8 *)(lVar24 + 0x758);
          *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100842;
          func_0x(uVar15,plVar25,iVar8);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar25 + 100) & 8) != 0)) &&
         ((2 < iVar8 &&
          (((*(uint *)((longlong)plVar25 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar24 = *plVar25, lVar24 != 0)))))) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100886;
        iVar10 = (*_DAT_)(lVar24,0x2000,2,auStack_388);
        if (iVar10 != 0) {
          LOCK();
          *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar25 + 100) = *(uint *)((longlong)plVar25 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1008a8;
      func_0x(plVar25 + 0x13,iVar8);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1008c7;
        func_0x(plVar25,0,iVar8);
      }
      uStack_47c = uStack_47c & 0xffff0000;
      uStack_488 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x1007e1;
      func_0x(&uStack_488);
    }
  }
  uStack_3b0 = uStack_3d0;
  uStack_3a8 = uStack_3c8;
  *(undefined8 *)((longlong)&uStack_4a8 + lVar11) = 0;
  uVar15 = *(undefined8 *)(lVar14 + 0x728);
  *(undefined8 *)((longlong)auStack_4c8 + lVar11 + -8) = 0x100918;
  func_0x(uVar15,&uStack_3b0,4);
  goto LAB_;
}

