
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x000ffe27) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8
FUN_(longlong param_1,int param_2,int param_3,longlong *param_4,short *param_5,
            undefined4 *param_6)

{
  ulonglong uVar1;
  byte bVar2;
  undefined4 uVar3;
  undefined8 *puVar4;
  ulonglong *puVar5;
  undefined8 *puVar6;
  short sVar7;
  undefined4 uVar8;
  longlong lVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  undefined8 uVar12;
  int iVar13;
  longlong unaff_GS_OFFSET;
  
  puVar4 = *(undefined8 **)(param_1 + 0x40);
  uVar3 = *(undefined4 *)(param_1 + 0x48);
  *param_4 = 0;
  *param_5 = 0;
  *param_6 = 0;
  if (param_2 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar9 = *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x18);
  puVar5 = *(ulonglong **)(lVar9 + 8);
  uVar12 = 1;
  if (param_3 == 1) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)puVar5 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  LOCK();
  uVar1 = *puVar5;
  if (uVar1 == 0) {
    *puVar5 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
  }
  UNLOCK();
  if (uVar1 != 0) {
    return;
  }
  puVar6 = *(undefined8 **)(param_1 + 0x38);
  bVar2 = *(byte *)((longlong)puVar6 + 0x37);
  if (((bVar2 & 1) != 0) || ((bVar2 & 2) == 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(puVar6 + 7) & 1) == 0) {
    if ((bVar2 & 4) == 0) {
      if ((*(byte *)(puVar6 + 7) & 2) != 0) {
        for (puVar11 = *(undefined8 **)(lVar9 + 0x50); puVar11 != (undefined8 *)0x0;
            puVar11 = (undefined8 *)*puVar11) {
          if ((*(byte *)((longlong)puVar11 + 0x37) & 1) == 0) {
            if (*(char *)((longlong)puVar11 + 0x36) != '\0') goto LAB_;
            lVar9 = puVar11[5];
            if ((*(byte *)((longlong)puVar11 + 0x37) & 2) != 0) {
              lVar9 = *(longlong *)(lVar9 + 0x38);
            }
            if (*(int *)(lVar9 + 0x50) != 7) goto LAB_;
          }
        }
        puVar11 = (undefined8 *)0x0;
        (*_DAT_)(1,0x29887e8,0x2956ff8,0x41d6,0);
LAB_:
        if (puVar11 == *(undefined8 **)(param_1 + 0x38)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
joined_r0x00100339:
        if (puVar4 == puVar11) {
          if (*_DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          uVar12 = 0;
          *puVar5 = 0;
          if (param_2 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined8 **)(param_1 + 0x40) = puVar4;
          *(undefined4 *)(param_1 + 0x48) = uVar3;
        }
        else {
          if (puVar11 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          plVar10 = (longlong *)0x0;
          bVar2 = *(byte *)((longlong)puVar11 + 0x37);
          if ((bVar2 & 0x40) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((*(byte *)(puVar11[3] + 0x5b) & 1) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if ((bVar2 & 1) == 0) {
            lVar9 = puVar11[5];
            if ((bVar2 & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
            func_0x(lVar9);
            plVar10 = *(longlong **)(lVar9 + 0x30);
            if (plVar10 != (longlong *)0x0) {
              (**(code **)(*plVar10 + 0x70))(plVar10);
            }
            func_0x();
          }
          if (param_2 == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (plVar10 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          if (*_DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *puVar5 = 0;
          lVar9 = (**(code **)*plVar10)(plVar10);
          *param_4 = lVar9;
          sVar7 = (**(code **)(*plVar10 + 0x80))(plVar10);
          *param_5 = sVar7;
          uVar8 = (**(code **)(*plVar10 + 0x40))(plVar10);
          *param_6 = uVar8;
          (**(code **)(*plVar10 + 0x78))(plVar10);
          if (*param_4 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
          *(undefined8 **)(param_1 + 0x40) = puVar11;
          *(undefined4 *)(param_1 + 0x48) = uVar3;
          if ((*param_4 == 0) && (*param_5 == 0)) {
            return 0;
          }
        }
        return uVar12;
      }
      puVar11 = *(undefined8 **)(lVar9 + 0x40);
      if (puVar11 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)((longlong)puVar11 + 0x37) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (*(char *)((longlong)puVar11 + 0x36) == '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if ((*(byte *)(puVar6 + 7) & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (puVar11 == (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (puVar11 != puVar6) goto joined_r0x00100339;
      if (*(longlong *)(lVar9 + 0x38) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
    }
    if (*(longlong *)(lVar9 + 0x30) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if (puVar4 != (undefined8 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar13 = 0;
  while( true ) {
    if (3 < iVar13) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(longlong *)(lVar9 + 0x10 + (longlong)iVar13 * 8) != 0) break;
    iVar13 = iVar13 + 1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

