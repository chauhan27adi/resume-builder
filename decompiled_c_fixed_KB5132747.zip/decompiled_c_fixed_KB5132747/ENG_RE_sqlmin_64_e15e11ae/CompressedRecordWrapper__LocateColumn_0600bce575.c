
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short **param_1,byte *param_2,uint *param_3,uint param_4,int param_5,uint *param_6
                 ,undefined4 *param_7,ulonglong *param_8,undefined4 param_9)

{
  ushort *puVar1;
  short *psVar2;
  longlong *plVar3;
  ulonglong *puVar4;
  ushort *puVar5;
  bool bVar6;
  undefined4 *puVar7;
  uint *puVar8;
  short **ppsVar9;
  byte bVar10;
  char cVar11;
  ushort uVar12;
  ushort uVar13;
  int iVar14;
  longlong lVar15;
  undefined8 uVar16;
  uint uVar17;
  ulonglong uVar18;
  byte *pbVar19;
  uint uVar20;
  ulonglong *puVar21;
  ulonglong uVar22;
  short sVar23;
  uint uVar24;
  ulonglong uVar25;
  byte bVar26;
  byte bVar27;
  ushort *puVar28;
  undefined auStack_138 [32];
  undefined8 uStack_118;
  undefined8 uStack_110;
  uint *puStack_108;
  uint uStack_100;
  uint uStack_f8;
  uint uStack_f4;
  uint uStack_f0;
  byte *pbStack_e8;
  undefined auStack_e0 [8];
  undefined4 *puStack_d8;
  uint *puStack_d0;
  short **ppsStack_c8;
  undefined auStack_c0 [56];
  undefined auStack_88 [56];
  ulonglong uStack_50;
  
  uStack_50 = _DAT_ ^ (ulonglong)auStack_138;
  psVar2 = *param_1;
  bVar6 = false;
  uVar12 = 0;
  puVar1 = (ushort *)(psVar2 + 1);
  puStack_d0 = param_6;
  uStack_f8 = 0;
  puStack_d8 = param_7;
  pbStack_e8 = param_2;
  ppsStack_c8 = param_1;
  if (*psVar2 == 0) {
    uVar20 = *param_3;
    if ((uVar20 & 0xc0000000) == 0x80000000) {
      iVar14 = func_0x(puVar1);
      if (iVar14 == 0) {
        puVar21 = (ulonglong *)0x0;
        uVar24 = uStack_f8;
      }
      else {
        puVar21 = (ulonglong *)func_0x(psVar2 + 0x15,param_3,&uStack_f8,&pbStack_e8);
        uVar24 = uStack_f8;
      }
    }
    else {
      if ((param_5 != 0) || ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0)) {
        pbVar19 = *(byte **)(psVar2 + 4);
        if ((*pbVar19 & 0x10) == 0) {
          if ((1 << (*pbVar19 & 0xe) & 0x1105U) == 0) {
            bVar6 = true;
          }
          else {
LAB_:
            uVar12 = ~(*(ushort *)((longlong)param_3 + 6) >> 4) & 1;
          }
LAB_:
          if (param_5 != 0) goto LAB_;
        }
        else {
          uVar24 = *(uint *)(psVar2 + 8);
          if ((int)uVar24 <= (int)uVar20) goto LAB_;
          if ((uint)*(ushort *)(pbVar19 + uVar24) < (uint)*(ushort *)(param_3 + 1)) {
            uVar12 = ~(*(ushort *)((longlong)param_3 + 6) >> 4) & 1;
            bVar6 = false;
            goto LAB_;
          }
          if (param_5 == 0) goto LAB_;
          uVar17 = *(ushort *)(param_3 + 1) - 1;
          bVar6 = true;
          uVar12 = pbVar19[(ulonglong)(uVar17 >> 3) + (ulonglong)uVar24 + 2] >> ((byte)uVar17 & 7) &
                   1;
LAB_:
          puVar21 = (ulonglong *)0x0;
          uVar24 = uStack_f8;
          if (uVar12 != 0) goto LAB_;
        }
        if ((!bVar6) && ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0)) {
          puVar21 = (ulonglong *)(*(uint **)(param_3 + 2) + 1);
          uVar24 = **(uint **)(param_3 + 2);
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar20 < 0) {
        if (*(int *)(psVar2 + 2) == 0) {
          pbVar19 = *(byte **)(psVar2 + 4);
          uVar24 = *(uint *)(psVar2 + 8);
          uVar18 = (ulonglong)uVar24;
          *puVar1 = 0;
          *(uint *)(psVar2 + 10) = uVar24;
          bVar10 = *pbVar19;
          if ((bVar10 & 0x10) != 0) {
            uVar24 = uVar24 + 2 + (*(ushort *)(pbVar19 + uVar18) + 7 >> 3);
            uVar18 = (ulonglong)uVar24;
            *(uint *)(psVar2 + 10) = uVar24;
            bVar10 = *pbVar19;
          }
          if ((bVar10 & 0x20) == 0) {
            *(int *)(psVar2 + 2) = (int)uVar18;
            psVar2[0xe] = 0;
            *(int *)(psVar2 + 0xc) = (int)uVar18;
          }
          else {
            puVar28 = (ushort *)(pbVar19 + uVar18);
            uVar12 = *puVar28;
            psVar2[0xe] = uVar12;
            if (uVar12 == 0) {
              cVar11 = func_0x(0x1103df0);
              if (((cVar11 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                 (*(char *)(lVar15 + 0x499) != '\0')) {
                cVar11 = func_0x(0x1103df0);
                if (cVar11 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_118 = (ulonglong *)0x0;
                  (*_DAT_)(1,0x9f37fc,0xb138e8,0x80f);
                }
              }
              func_0x(*(undefined8 *)(psVar2 + 4),3);
              uVar12 = psVar2[0xe];
              uVar18 = (ulonglong)*(uint *)(psVar2 + 10);
            }
            uVar24 = (int)uVar18 + (uVar12 + 1) * 2;
            *(uint *)(psVar2 + 0xc) = uVar24;
            if (0x1f9e < uVar24) {
              cVar11 = func_0x(0x1103df0);
              if (((cVar11 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                 (*(char *)(lVar15 + 0x499) != '\0')) {
                cVar11 = func_0x(0x1103df0);
                if (cVar11 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_118 = (ulonglong *)0x0;
                  (*_DAT_)(1,0x9f37fc,0xb138e8,0x816);
                }
              }
              func_0x(*(undefined8 *)(psVar2 + 4),4);
              uVar12 = psVar2[0xe];
              uVar24 = *(uint *)(psVar2 + 0xc);
            }
            uVar18 = (ulonglong)uVar12;
            uVar12 = puVar28[uVar18];
            *(uint *)(psVar2 + 2) = uVar12 & 0x7fff;
            if ((uVar12 & 0x7fff) < uVar24) {
              cVar11 = func_0x(0x1103df0);
              if (((cVar11 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                 (*(char *)(lVar15 + 0x499) != '\0')) {
                cVar11 = func_0x(0x1103df0);
                if (cVar11 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_118 = (ulonglong *)0x0;
                  (*_DAT_)(1,0x9f37fc,0xb138e8,0x81d);
                }
              }
              func_0x(*(undefined8 *)(psVar2 + 4),4);
              uVar24 = *(uint *)(psVar2 + 0xc);
              uVar18 = (ulonglong)(ushort)psVar2[0xe];
            }
            iVar14 = 0;
            puVar5 = puVar28;
            if ((short)uVar18 != 0) {
              do {
                uVar20 = puVar5[1] & 0x7fff;
                if ((uVar20 < uVar24) || (*(uint *)(psVar2 + 2) < uVar20)) {
                  cVar11 = func_0x(0x1103df0);
                  if ((cVar11 != '\0') &&
                     ((lVar15 = func_0x(), lVar15 != 0 &&
                      (*(char *)(lVar15 + 0x499) != '\0')))) {
                    cVar11 = func_0x(0x1103df0);
                    if (cVar11 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_118 = (ulonglong *)0x0;
                      (*_DAT_)(1,0x9f37fc,0xb138e8,0x82a);
                    }
                  }
                  func_0x(*(undefined8 *)(psVar2 + 4),4);
                }
                uVar18 = (ulonglong)(ushort)psVar2[0xe];
                iVar14 = iVar14 + 1;
                param_2 = pbStack_e8;
                puVar5 = puVar5 + 1;
                uVar24 = uVar20;
              } while (iVar14 < (int)(uint)(ushort)psVar2[0xe]);
            }
            if ((short)puVar28[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
              pbVar19 = *(byte **)(psVar2 + 4);
              do {
                uVar24 = *(ushort *)(pbVar19 + uVar18 * 2 + (ulonglong)*(uint *)(psVar2 + 10)) &
                         0x7fff;
                if ((int)uVar18 == 1) {
                  uVar20 = *(uint *)(psVar2 + 0xc);
                  uVar17 = uVar20;
LAB_:
                  if ((uVar24 < uVar20) || (*(uint *)(psVar2 + 2) < uVar24)) goto LAB_;
                }
                else {
                  uVar17 = *(uint *)(psVar2 + 0xc);
                  uVar20 = *(ushort *)
                            (pbVar19 + uVar18 * 2 + ((ulonglong)*(uint *)(psVar2 + 10) - 2)) &
                           0x7fff;
                  if (uVar17 <= uVar20) goto LAB_;
LAB_:
                  func_0x(pbVar19,7);
                  uVar17 = *(uint *)(psVar2 + 0xc);
                }
                if ((uVar20 < uVar17) || (*(uint *)(psVar2 + 2) < uVar20)) goto LAB_;
                pbVar19 = *(byte **)(psVar2 + 4);
                if (*(ushort *)(pbVar19 + uVar20) == 5) {
                  *puVar1 = *puVar1 | 2;
                  psVar2[0xe] = psVar2[0xe] + -1;
                  uVar25 = (ulonglong)(uVar20 & 0xffff);
                  psVar2[0x15] = (short)uVar20;
                  uVar18 = *(ulonglong *)(psVar2 + 4);
                  uVar12 = psVar2[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar25 + 2 + uVar18) >> 0xe & 1) != 0) {
                    uVar12 = *(ushort *)(uVar25 + 2 + uVar18) & 0x3800 | psVar2[0x16] & 0xc7ffU;
                  }
                  psVar2[0x16] = uVar12;
                  uVar13 = (uVar12 ^ *(ushort *)(uVar25 + 2 + uVar18)) & 0x7ff ^ uVar12;
                  psVar2[0x16] = uVar13;
                  uVar22 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 + uVar18 + (uVar12 >> 0xb & 7) * 2
                           + uVar25;
                  if (uVar22 < uVar25 + uVar18) {
                    func_0x(uVar25 + uVar18,0x19);
                    uVar13 = psVar2[0x16];
                    uVar25 = (ulonglong)(ushort)psVar2[0x15];
                    uVar18 = (ulonglong)*(uint *)(psVar2 + 4);
                  }
                  if (uVar24 - uVar20 <
                      (((uVar13 & 0x7ff) * 2 - (int)uVar25) - (int)uVar18) + (int)uVar22) {
                    func_0x(uVar25 + *(longlong *)(psVar2 + 4),0x19);
                    uVar13 = psVar2[0x16];
                  }
                  iVar14 = 0;
                  if (((uVar13 & 0x3800) != 0) &&
                     (puVar28 = (ushort *)
                                (*(longlong *)(psVar2 + 4) + 4 + (ulonglong)(ushort)psVar2[0x15]),
                     (uVar13 & 0x3800) != 0)) {
                    do {
                      if ((uVar13 & 0x7ff) < (*puVar28 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)psVar2[0x15] + *(longlong *)(psVar2 + 4),
                                        0x1a);
                        uVar13 = psVar2[0x16];
                      }
                      iVar14 = iVar14 + 1;
                      puVar28 = puVar28 + 1;
                    } while (iVar14 < (int)(uVar13 >> 0xb & 7));
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar19 + uVar20) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar12 = psVar2[0xe] - 1;
                psVar2[0xe] = uVar12;
                if (uVar12 == 0) goto LAB_;
                uVar18 = (ulonglong)uVar12;
              } while ((short)puVar28[(ulonglong)(uVar12 - 1) + 1] < 0);
              uVar18 = (ulonglong)*(uint *)(psVar2 + 2);
            }
            else {
LAB_:
              pbVar19 = *(byte **)(psVar2 + 4);
              uVar18 = (ulonglong)*(uint *)(psVar2 + 2);
            }
          }
          if ((*pbVar19 & 0x40) == 0) {
            *(undefined4 *)(psVar2 + 0x13) = 0;
          }
          else {
            *(int *)(psVar2 + 0x13) = (int)uVar18;
            *(int *)(psVar2 + 2) = (int)uVar18 + 0xe;
            uVar16 = func_0x(puVar1);
            func_0x(uVar16,auStack_e0);
            iVar14 = func_0x(auStack_e0);
            *(int *)(psVar2 + 2) = *(int *)(psVar2 + 2) + iVar14;
            uVar18 = (ulonglong)*(uint *)(psVar2 + 2);
          }
          iVar14 = (int)uVar18;
          if ((*(ulonglong *)(psVar2 + 0xf) != 0) &&
             (*(ulonglong *)(psVar2 + 0xf) < uVar18 + *(longlong *)(psVar2 + 4))) {
            cVar11 = func_0x(0x1103df0);
            if ((cVar11 != '\0') &&
               ((lVar15 = func_0x(), lVar15 != 0 &&
                (*(char *)(lVar15 + 0x499) != '\0')))) {
              cVar11 = func_0x(0x1103df0);
              if (cVar11 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_118 = (ulonglong *)0x0;
                (*_DAT_)(1,0x9f37fc,0xb138e8,0x886);
              }
            }
            func_0x(*(undefined8 *)(psVar2 + 4),0x12);
            iVar14 = *(int *)(psVar2 + 2);
          }
          if (0x3f3b < iVar14 - 1U) {
            cVar11 = func_0x(0x1103df0);
            if (((cVar11 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
               (*(char *)(lVar15 + 0x499) != '\0')) {
              cVar11 = func_0x(0x1103df0);
              if (cVar11 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_118 = (ulonglong *)0x0;
                (*_DAT_)(1,0x9f37fc,0xb138e8,0x88b);
              }
            }
            func_0x(*(undefined8 *)(psVar2 + 4),5);
          }
        }
LAB_:
        sVar23 = -*(short *)param_3;
        if ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0) {
          bVar10 = **(byte **)(psVar2 + 4);
          if ((bVar10 & 0x10) == 0) {
            if ((1 << (bVar10 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar21 = (ulonglong *)(*(uint **)(param_3 + 2) + 1);
              uVar24 = **(uint **)(param_3 + 2);
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(psVar2 + 8) <= (int)*param_3) ||
                  (*(ushort *)(*(byte **)(psVar2 + 4) + *(uint *)(psVar2 + 8)) <
                   *(ushort *)(param_3 + 1))) goto LAB_;
        }
        puVar21 = *(ulonglong **)(psVar2 + 4);
        lVar15 = (longlong)sVar23;
        uVar24 = uStack_f8;
        if ((uint)(int)sVar23 <= (uint)(ushort)psVar2[0xe]) {
          uVar24 = *(uint *)(psVar2 + 10);
          if (sVar23 == 1) {
            uVar20 = *(uint *)(psVar2 + 0xc);
            uVar24 = *(ushort *)((longlong)puVar21 + lVar15 * 2 + (ulonglong)uVar24) & 0x7fff;
LAB_:
            if ((uVar24 < uVar20) || (*(uint *)(psVar2 + 2) < uVar24)) goto LAB_;
          }
          else {
            puVar1 = (ushort *)((longlong)puVar21 + lVar15 * 2 + (ulonglong)uVar24);
            uVar20 = *(ushort *)((longlong)puVar21 + lVar15 * 2 + ((ulonglong)uVar24 - 2)) & 0x7fff;
            puVar21 = *(ulonglong **)(psVar2 + 4);
            uVar24 = *puVar1 & 0x7fff;
            if (*(uint *)(psVar2 + 0xc) <= uVar20) goto LAB_;
LAB_:
            func_0x(puVar21,7);
          }
          puVar21 = (ulonglong *)((ulonglong)uVar20 + *(longlong *)(psVar2 + 4));
          uVar24 = uVar24 - uVar20;
        }
      }
      else {
        uVar12 = *(ushort *)((longlong)param_3 + 6);
        if ((uVar12 & 8) == 0) {
          if ((uVar12 & 0x10) != 0) {
            bVar10 = **(byte **)(psVar2 + 4);
            if ((bVar10 & 0x10) == 0) {
              if ((1 << (bVar10 & 0xe) & 0x1105U) != 0) {
LAB_:
                uVar24 = **(uint **)(param_3 + 2);
                puVar21 = (ulonglong *)(*(uint **)(param_3 + 2) + 1);
                if ((param_4 != 0) && (uVar24 != param_4)) {
                  uStack_118 = (ulonglong *)0x0;
                  (*_DAT_)(1,0xba1c40,0xba05a8,0x381);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(psVar2 + 8) <= (int)uVar20) ||
                    (*(ushort *)(*(byte **)(psVar2 + 4) + *(uint *)(psVar2 + 8)) <
                     *(ushort *)(param_3 + 1))) goto LAB_;
          }
          puVar21 = (ulonglong *)((longlong)(int)uVar20 + *(longlong *)(psVar2 + 4));
          uVar24 = param_4;
        }
        else {
          puVar21 = (ulonglong *)0x778490;
          uStack_f8 = 1;
          uVar24 = uStack_f8;
          if ((*(byte *)(*(longlong *)(psVar2 + 4) + (longlong)(int)uVar20) &
              (byte)(1 << ((byte)uVar12 & 7))) == 0) {
            puVar21 = (ulonglong *)0x778491;
          }
        }
      }
    }
  }
  else {
    uStack_118 = (ulonglong *)&uStack_f0;
    uStack_f0 = 0;
    puVar21 = (ulonglong *)func_0x(puVar1,param_3,param_3,&uStack_f8);
    uVar24 = uStack_f8;
    if ((((*psVar2 != 0) && (plVar3 = *(longlong **)(psVar2 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) && (((*(byte *)((longlong)param_3 + 6) & 8) == 0 && ((uStack_f0 & 1) == 0)))
       ) {
      if ((puVar21 == (ulonglong *)0x0) || (puVar21 == (ulonglong *)0x778490)) {
        puVar21 = (ulonglong *)0x0;
        uStack_f8 = 0;
        uVar24 = uStack_f8;
      }
      else {
        uStack_100 = uStack_f0;
        puStack_108 = &uStack_f8;
        uStack_110 = (uint *)CONCAT44(uStack_110._4_4_,param_9);
        uStack_118 = param_8;
        puVar21 = (ulonglong *)func_0x(plVar3,param_3,puVar21,uStack_f8);
        uVar24 = uStack_f8;
      }
    }
  }
LAB_:
  uStack_f8 = uVar24;
  ppsVar9 = ppsStack_c8;
  puVar8 = puStack_d0;
  puVar7 = puStack_d8;
  uVar24 = uStack_f8;
  *puStack_d8 = 0;
  *puStack_d0 = uStack_f8;
  if ((puVar21 == (ulonglong *)0x0) ||
     (iVar14 = func_0x(*ppsStack_c8,param_2,param_3), iVar14 == 0)) goto LAB_;
  bVar10 = *param_2;
  uVar20 = *(uint *)(ppsVar9 + 2);
  if ((byte)(bVar10 + 0x10) < 2) {
    bVar26 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar10 + 0x778ab0) * 4 + 0x779bb3);
    if ((bVar10 == 0xf0) || (bVar10 == 0xf1)) {
      bVar27 = *(byte *)((ulonglong)*(byte *)((ulonglong)bVar10 + 0x778ab0) * 4 + 0x779bb2);
    }
    else {
      bVar27 = param_2[0x12];
    }
  }
  else {
    bVar26 = param_2[0x13];
    bVar27 = param_2[0x12];
  }
  puVar4 = (ulonglong *)ppsVar9[1];
  uStack_f4 = uVar20;
  switch(bVar10) {
  case 0x30:
    if (uVar24 == 0) {
      *(undefined *)puVar4 = 0;
      *puVar8 = 1;
      *puVar7 = 1;
    }
    else {
      *(byte *)puVar4 = *(byte *)puVar21;
      *puVar8 = 1;
      *puVar7 = 1;
    }
    break;
  case 0x34:
    if (uVar24 == 0) {
      *(undefined2 *)puVar4 = 0;
    }
    else {
      if (uVar24 == 1) {
        *(ushort *)puVar4 = (*(byte *)puVar21 >> 7) - 1;
        *(byte *)puVar4 = *(byte *)puVar21 ^ 0x80;
        *puVar8 = 2;
        *puVar7 = 1;
        break;
      }
      if (uVar24 == 2) {
        *(byte *)((longlong)puVar4 + 1) = *(byte *)puVar21 ^ 0x80;
        *(byte *)puVar4 = *(byte *)((longlong)puVar21 + 1);
        *puVar8 = 2;
        *puVar7 = 1;
        break;
      }
    }
    *puVar8 = 2;
    *puVar7 = 1;
    break;
  case 0x38:
  case 0x7a:
    if (uVar24 == 0) {
      *(undefined4 *)puVar4 = 0;
      *puVar8 = 4;
      *puVar7 = 1;
      break;
    }
    if (uVar24 == 1) {
      *(uint *)puVar4 = (*(byte *)puVar21 >> 7) - 1;
      *(byte *)puVar4 = *(byte *)puVar21 ^ 0x80;
      *puVar8 = 4;
      *puVar7 = 1;
      break;
    }
    if (uVar24 == 2) {
      *(uint *)puVar4 = (*(byte *)puVar21 >> 7) - 1;
      *(byte *)((longlong)puVar4 + 1) = *(byte *)puVar21 ^ 0x80;
      *(byte *)puVar4 = *(byte *)((longlong)puVar21 + 1);
      *puVar8 = 4;
      *puVar7 = 1;
      break;
    }
    if (uVar24 == 3) {
      *(uint *)puVar4 = (*(byte *)puVar21 >> 7) - 1;
      *(byte *)((longlong)puVar4 + 2) = *(byte *)puVar21 ^ 0x80;
      *(byte *)((longlong)puVar4 + 1) = *(byte *)((longlong)puVar21 + 1);
      *(byte *)puVar4 = *(byte *)((longlong)puVar21 + 2);
      *puVar8 = 4;
      *puVar7 = 1;
      break;
    }
    if (uVar24 == 4) {
      uVar24 = *(uint *)puVar21;
      *(uint *)puVar4 =
           uVar24 >> 0x18 | (uVar24 & 0xff0000) >> 8 | (uVar24 & 0xff00) << 8 | uVar24 << 0x18;
      *(byte *)((longlong)puVar4 + 3) = (byte)uVar24 ^ 0x80;
      *puVar8 = 4;
      *puVar7 = 1;
      break;
    }
    goto code_r0x00101005;
  case 0x3a:
    if (uVar24 == 4) {
code_r0x00100fb9:
      *(uint *)puVar4 = *(uint *)puVar21;
      *puVar8 = 4;
      *puVar7 = 1;
      break;
    }
    *(undefined2 *)puVar4 = 0;
code_r0x00100eb6:
    *(undefined2 *)((longlong)puVar4 + 2) = *(undefined2 *)puVar21;
    *puVar8 = 4;
    *puVar7 = 1;
    break;
  case 0x3b:
    *(undefined4 *)puVar4 = 0;
    if (uVar24 == 1) {
      *(byte *)((longlong)puVar4 + 3) = *(byte *)puVar21;
    }
    else {
      if (uVar24 == 2) goto code_r0x00100eb6;
      if (uVar24 == 3) {
        *(undefined2 *)((longlong)puVar4 + 1) = *(undefined2 *)puVar21;
        *(byte *)((longlong)puVar4 + 3) = *(byte *)((longlong)puVar21 + 2);
        *puVar8 = 4;
        *puVar7 = 1;
        break;
      }
      if (uVar24 == 4) goto code_r0x00100fb9;
    }
code_r0x00101005:
    *puVar8 = 4;
    *puVar7 = 1;
    break;
  case 0x3c:
  case 0x3d:
  case 0x7f:
    switch(uVar24) {
    case 0:
      *puVar4 = 0;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 1:
      *puVar4 = (ulonglong)(*(byte *)puVar21 >> 7) - 1;
      *(byte *)puVar4 = *(byte *)puVar21 ^ 0x80;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 2:
      *puVar4 = (ulonglong)(*(byte *)puVar21 >> 7) - 1;
      *(byte *)((longlong)puVar4 + 1) = *(byte *)puVar21 ^ 0x80;
      *(byte *)puVar4 = *(byte *)((longlong)puVar21 + 1);
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 3:
      *puVar4 = (ulonglong)(*(byte *)puVar21 >> 7) - 1;
      *(byte *)((longlong)puVar4 + 2) = *(byte *)puVar21 ^ 0x80;
      *(byte *)((longlong)puVar4 + 1) = *(byte *)((longlong)puVar21 + 1);
      *(byte *)puVar4 = *(byte *)((longlong)puVar21 + 2);
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 4:
      *puVar4 = (ulonglong)(*(byte *)puVar21 >> 7) - 1;
      uVar24 = *(uint *)puVar21;
      *(uint *)puVar4 =
           uVar24 >> 0x18 | (uVar24 & 0xff0000) >> 8 | (uVar24 & 0xff00) << 8 | uVar24 << 0x18;
      *(byte *)((longlong)puVar4 + 3) = *(byte *)puVar21 ^ 0x80;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 5:
      *puVar4 = (ulonglong)(*(byte *)puVar21 >> 7) - 1;
      *(byte *)((longlong)puVar4 + 4) = *(byte *)puVar21 ^ 0x80;
      uVar24 = *(uint *)((longlong)puVar21 + 1);
      *(uint *)puVar4 =
           uVar24 >> 0x18 | (uVar24 & 0xff0000) >> 8 | (uVar24 & 0xff00) << 8 | uVar24 << 0x18;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 6:
      *puVar4 = (ulonglong)(*(byte *)puVar21 >> 7) - 1;
      *(byte *)((longlong)puVar4 + 5) = *(byte *)puVar21 ^ 0x80;
      *(byte *)((longlong)puVar4 + 4) = *(byte *)((longlong)puVar21 + 1);
      uVar24 = *(uint *)((longlong)puVar21 + 2);
      *(uint *)puVar4 =
           uVar24 >> 0x18 | (uVar24 & 0xff0000) >> 8 | (uVar24 & 0xff00) << 8 | uVar24 << 0x18;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 7:
      *puVar4 = (ulonglong)(*(byte *)puVar21 >> 7) - 1;
      *(byte *)((longlong)puVar4 + 6) = *(byte *)puVar21 ^ 0x80;
      *(byte *)((longlong)puVar4 + 5) = *(byte *)((longlong)puVar21 + 1);
      *(byte *)((longlong)puVar4 + 4) = *(byte *)((longlong)puVar21 + 2);
      uVar24 = *(uint *)((longlong)puVar21 + 3);
      *(uint *)puVar4 =
           uVar24 >> 0x18 | (uVar24 & 0xff0000) >> 8 | (uVar24 & 0xff00) << 8 | uVar24 << 0x18;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 8:
      uVar18 = *puVar21;
      *puVar4 = uVar18 >> 0x38 | (uVar18 & 0xff000000000000) >> 0x28 |
                (uVar18 & 0xff0000000000) >> 0x18 | (uVar18 & 0xff00000000) >> 8 |
                (uVar18 & 0xff000000) << 8 | (uVar18 & 0xff0000) << 0x18 | (uVar18 & 0xff00) << 0x28
                | uVar18 << 0x38;
      *(byte *)((longlong)puVar4 + 7) = (byte)uVar18 ^ 0x80;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    default:
      goto code_r0x00101145;
    }
    break;
  case 0x3e:
    *puVar4 = 0;
    switch(uVar24) {
    case 1:
      *(byte *)((longlong)puVar4 + 7) = *(byte *)puVar21;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 2:
      *(undefined2 *)((longlong)puVar4 + 6) = *(undefined2 *)puVar21;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 3:
      *(undefined2 *)((longlong)puVar4 + 5) = *(undefined2 *)puVar21;
      *(byte *)((longlong)puVar4 + 7) = *(byte *)((longlong)puVar21 + 2);
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 4:
      *(uint *)((longlong)puVar4 + 4) = *(uint *)puVar21;
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 5:
      *(uint *)((longlong)puVar4 + 3) = *(uint *)puVar21;
      *(byte *)((longlong)puVar4 + 7) = *(byte *)((longlong)puVar21 + 4);
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 6:
      *(uint *)((longlong)puVar4 + 2) = *(uint *)puVar21;
      *(undefined2 *)((longlong)puVar4 + 6) = *(undefined2 *)((longlong)puVar21 + 4);
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 7:
      *(uint *)((longlong)puVar4 + 1) = *(uint *)puVar21;
      *(undefined2 *)((longlong)puVar4 + 5) = *(undefined2 *)((longlong)puVar21 + 4);
      *(byte *)((longlong)puVar4 + 7) = *(byte *)((longlong)puVar21 + 6);
      *puVar8 = 8;
      *puVar7 = 1;
      break;
    case 8:
      *puVar4 = *puVar21;
    default:
code_r0x00101145:
      *puVar8 = 8;
      *puVar7 = 1;
    }
    break;
  case 0x6a:
  case 0x6c:
    uStack_110 = &uStack_f4;
    uStack_118 = puVar4;
    cVar11 = (*pcRam000000000066f580)(puVar21,uVar24,bVar27,bVar26);
    if (cVar11 == '\0') {
      (*_DAT_)(6,0x54,0x16,1);
      *puVar8 = uStack_f4;
      *puVar7 = 1;
      break;
    }
    goto code_r0x00100ef3;
  case 0xad:
  case 0xaf:
    uStack_118 = (ulonglong *)CONCAT71(uStack_118._1_7_,bVar10);
    func_0x(puVar21,uStack_f8,puVar4,uVar20);
code_r0x00100ef3:
    *puVar8 = uStack_f4;
    *puVar7 = 1;
    break;
  case 0xbd:
    func_0x(puVar21,uVar24,puVar4);
    *puVar8 = 8;
    *puVar7 = 1;
    break;
  case 0xe7:
    uStack_118 = (ulonglong *)CONCAT44(uStack_118._4_4_,uVar20);
    uVar20 = (*pcRam000000000066f578)(auStack_88,puVar21,uVar24,puVar4);
  default:
    *puVar8 = uVar20;
    *puVar7 = 1;
    break;
  case 0xef:
    uStack_118 = (ulonglong *)CONCAT44(uStack_118._4_4_,uVar20);
    (*pcRam000000000066f588)(auStack_c0,puVar21,uVar24,puVar4);
    *puVar8 = uStack_f4;
    *puVar7 = 1;
  }
LAB_:
  func_0x(uStack_50 ^ (ulonglong)auStack_138);
  return;
}

