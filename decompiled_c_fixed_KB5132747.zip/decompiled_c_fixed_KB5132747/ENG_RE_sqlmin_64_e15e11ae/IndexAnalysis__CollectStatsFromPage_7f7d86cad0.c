
/* WARNING: Heritage AFTER dead removal. Example location: s0xffffffffffffff40 : 0x001003c9 */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_(longlong param_1,longlong param_2,longlong param_3)

{
  byte *pbVar1;
  ushort uVar2;
  undefined4 uVar3;
  longlong lVar4;
  char cVar5;
  longlong lVar6;
  uint uVar7;
  short *psVar8;
  code *UNRECOVERED_JUMPTABLE_00;
  uint uVar9;
  short sVar10;
  ulonglong uVar11;
  undefined auStack_198 [48];
  int iStack_168;
  longlong lStack_158;
  longlong lStack_150;
  undefined8 uStack_148;
  short sStack_140;
  undefined4 uStack_134;
  undefined2 uStack_130;
  undefined4 uStack_110;
  longlong lStack_108;
  longlong lStack_100;
  undefined2 uStack_f8;
  undefined4 uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_da;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  undefined6 uStack_ce;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [16];
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined8 uStack_88;
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [8];
  short sStack_58;
  int iStack_54;
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_198;
  *(longlong *)(param_2 + 0x68) = *(longlong *)(param_2 + 0x68) + 1;
  iStack_168 = -1;
  uStack_f8 = 0xffff;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_e8 = 0;
  iStack_c4 = 0xffffffff;
  if (*(char *)(param_3 + 2) < '\0') {
    *(longlong *)(param_2 + 0x48) = *(longlong *)(param_2 + 0x48) + 1;
  }
  if ((*(int *)(param_1 + 0x14e4) != 0) ||
     (((*(int *)(param_1 + 0xb74) == 0 && (*(int *)(param_1 + 0xbd4) == 1)) &&
      (*(int *)(param_1 + 0x960) == 1)))) {
    uVar7 = *(uint *)(param_3 + 0x20);
    uVar9 = *(uint *)(param_2 + 0x98) & 0xfffffff8;
    sVar10 = *(short *)(param_3 + 0x24);
    if (((uVar7 & 0xfffffff8) != uVar9) || (sVar10 != *(short *)(param_2 + 0x9c))) {
      *(longlong *)(param_2 + 0x88) = *(longlong *)(param_2 + 0x88) + 1;
      sVar10 = *(short *)(param_3 + 0x24);
      uVar7 = *(uint *)(param_3 + 0x20);
    }
    if (((*(uint *)(param_2 + 0x98) != 0) || (*(short *)(param_2 + 0x9c) != 0)) &&
       ((*(short *)(param_2 + 0x9c) == sVar10 &&
        ((uVar9 != (uVar7 & 0xfffffff8) && (uVar9 + 8 != (uVar7 & 0xfffffff8))))))) {
      *(longlong *)(param_2 + 0x90) = *(longlong *)(param_2 + 0x90) + 1;
    }
  }
  if (((*(int *)(param_1 + 0xbd4) == 1) &&
      ((*(int *)(param_2 + 0x98) + 1 != *(int *)(param_3 + 0x20) ||
       (*(short *)(param_2 + 0x9c) != *(short *)(param_3 + 0x24))))) &&
     ((*(int *)(param_1 + 0xbc4) == 0 || (param_2 != param_1 + 0x7e8)))) {
    *(longlong *)(param_2 + 0x58) = *(longlong *)(param_2 + 0x58) + 1;
  }
  if (((*(int *)(param_1 + 3000) != 0) && (param_2 != param_1 + 0x7e8)) &&
     ((*(int *)(param_3 + 8) != *(int *)(param_2 + 0x98) ||
      (*(short *)(param_3 + 0xc) != *(short *)(param_2 + 0x9c))))) {
    *(longlong *)(param_2 + 0x78) = *(longlong *)(param_2 + 0x78) + 1;
  }
  *(undefined4 *)(param_2 + 0x98) = *(undefined4 *)(param_3 + 0x20);
  *(undefined2 *)(param_2 + 0x9c) = *(undefined2 *)(param_3 + 0x24);
  uVar2 = *(ushort *)(param_3 + 0x16);
  uVar7 = (uint)uVar2;
  if (((*(byte *)(param_3 + 4) & 8) != 0) && (uVar11 = (ulonglong)(uint)uVar2, uVar2 != 0)) {
    psVar8 = (short *)(param_3 + 0x1ffe);
    do {
      sVar10 = *psVar8;
      psVar8 = psVar8 + -1;
      uVar9 = uVar7 - 1;
      if (sVar10 != 0) {
        uVar9 = uVar7;
      }
      uVar7 = uVar9;
      uVar11 = uVar11 - 1;
    } while (uVar11 != 0);
  }
  lStack_158 = -1;
  *(longlong *)(param_2 + 8) =
       *(longlong *)(param_2 + 8) + (longlong)(int)(uVar7 - *(ushort *)(param_3 + 0x3a));
  do {
    uVar2 = *(ushort *)(param_3 + 0x16);
    lStack_158 = lStack_158 + 1;
    iStack_168 = iStack_168 + 1;
    lStack_150 = param_1;
    lStack_108 = param_3;
    lStack_100 = param_2;
    if ((longlong)(ulonglong)uVar2 <= lStack_158) {
LAB_:
      lVar6 = 2;
      if (uVar2 != 0) {
        lVar6 = 0;
      }
      *(longlong *)(param_2 + 0x70) =
           *(longlong *)(param_2 + 0x70) + ((ulonglong)*(ushort *)(param_3 + 0x1c) - lVar6);
      func_0x(uStack_48 ^ (ulonglong)auStack_198);
      return;
    }
    psVar8 = (short *)(param_3 + (0xfff - lStack_158) * 2);
    while (*psVar8 == 0) {
      iStack_168 = iStack_168 + 1;
      lStack_158 = lStack_158 + 1;
      psVar8 = psVar8 + -1;
      if ((longlong)(ulonglong)uVar2 <= lStack_158) goto LAB_;
    }
    if (iStack_168 == -1) goto LAB_;
    lVar6 = 0xfff - lStack_158;
  } while (*(short *)(param_3 + lVar6 * 2) == 0);
  iStack_c4 = iStack_168;
  if (-1 < *(char *)(param_3 + 2)) goto LAB_;
  pbVar1 = (byte *)(param_3 + 0x60);
  auStack_b0 = ZEXT816(0);
  uStack_98 = 0;
  auStack_b0._0_2_ = 0xffff;
  uStack_8a = SUB162(ZEXT816(0),6);
  auStack_b0 = ZEXT416((uint)auStack_b0._0_4_);
  uStack_92 = 0;
  uStack_90 = 0;
  auStack_70 = ZEXT816(0);
  uStack_a0 = 0;
  auStack_c0 = ZEXT816(0);
  auStack_80 = ZEXT816(0);
  _auStack_60 = ZEXT812(0);
  iStack_54 = 0;
  uStack_50 = 0;
  uStack_50 = 0;
  uStack_88 = 0;
  uStack_8a = 0;
  uStack_90 = 0;
  uStack_92 = 0;
  uStack_98 = 0;
  uStack_a0 = 0;
  if (*(short *)(param_3 + 0x24) == 0) {
LAB_:
    uStack_148 = *(undefined8 *)(param_3 + 0x28);
    sStack_140 = *(short *)(param_3 + 0x30);
  }
  else {
    cVar5 = *(char *)(param_3 + 1);
    if (cVar5 == '\v') {
      if (*(int *)(param_3 + 0x18) != 99) {
LAB_:
        if (cVar5 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar5 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_3 + 0x18) != 99) goto LAB_;
    }
    uStack_134 = *(undefined4 *)(param_3 + 0x20);
    uStack_130 = *(undefined2 *)(param_3 + 0x24);
    cVar5 = func_0x(&uStack_134);
    if (cVar5 == '\0') goto LAB_;
    func_0x(param_3,&uStack_148);
  }
  if (((((pbVar1 != (byte *)auStack_c0._0_8_) || (sStack_140 != sStack_58)) ||
       ((int)uStack_148 != auStack_60._0_4_)) ||
      (((int)((ulonglong)uStack_148 >> 0x20) != auStack_60._4_4_ ||
       (*(int *)(param_3 + 0x20) != iStack_54)))) ||
     (*(short *)(param_3 + 0x24) != (short)uStack_50)) {
    lVar4 = auStack_c0._8_8_;
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_c0._0_8_ = pbVar1;
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_60._0_4_ = (int)uStack_148;
                    /* WARNING: Ignoring partial resolution of indirect */
    uStack_50._0_2_ = *(undefined2 *)(param_3 + 0x24);
    uVar3 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0xb14ab0);
    uVar11 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0xb14ab4);
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_b0._0_2_ = 0xffff;
    uStack_90 = 0;
    uStack_92 = 0;
    uStack_a0 = 0;
                    /* WARNING: Ignoring partial resolution of indirect */
    auStack_70._0_8_ = 0;
    uStack_110 = uVar3;
    if ((*pbVar1 & 2) != 0) {
      if ((pbVar1[uVar11] & 1) != 0) {
                    /* WARNING: Ignoring partial resolution of indirect */
        auStack_b0._0_2_ = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(pbVar1[uVar11] & 0x1c) + 0x1013f8) * 4 +
                               0x1013e8) - 0x1a84360);
                    /* WARNING: Could not emulate address calculation at 0x001004ab */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
                    /* WARNING: Ignoring partial resolution of indirect */
      auStack_b0._0_2_ = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010063a */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(pbVar1[uVar11] & 0xe) * 4 + 0x101418) -
                0x1a84360))();
      return;
    }
    if ((*pbVar1 & 4) != 0) {
      uStack_110._2_2_ = (short)((uint)uVar3 >> 0x10);
      if (uStack_110._2_2_ != 0) {
        uVar11 = (ulonglong)*(ushort *)(param_3 + 0x61 + (longlong)uStack_110._2_2_ * 2);
      }
                    /* WARNING: Ignoring partial resolution of indirect */
      auStack_70._0_8_ = pbVar1 + uVar11 + 2;
    }
    if (lVar4 != 0) {
      func_0x(lVar4,auStack_c0);
    }
  }
LAB_:
  pbStack_f0 = (byte *)((ulonglong)*(ushort *)(param_3 + lVar6 * 2) + param_3);
  if ((*pbStack_f0 & 1) != 0) {
    uStack_f8 = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_f0 & 0x1c) + 0x101464) * 4
                           + 0x101454) - 0x1a84360);
                    /* WARNING: Could not emulate address calculation at 0x00100738 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  uStack_f8 = 0;
  uStack_f4 = 0;
  uStack_d2 = 0;
  uStack_d0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001008ab */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_f0 & 0xe) * 4 + 0x101484) - 0x1a84360))()
  ;
  return;
}

