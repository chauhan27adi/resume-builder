
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,uint *param_3)

{
  uint *puVar1;
  ushort *puVar2;
  byte *pbVar3;
  longlong *plVar4;
  code *pcVar5;
  ushort *puVar6;
  char cVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  uint uVar11;
  longlong lVar12;
  undefined8 uVar13;
  longlong lVar14;
  byte bVar15;
  ulonglong uVar16;
  short sVar17;
  short *psVar18;
  undefined8 unaff_RBX;
  undefined *puVar19;
  ulonglong uVar20;
  undefined4 uVar21;
  uint uVar22;
  uint *puVar25;
  ushort *puVar26;
  uint uVar27;
  uint uStackX_8;
  uint uStackX_c;
  uint *puStackX_10;
  undefined auStackX_18 [8];
  short *psStackX_20;
  undefined8 uStack_40;
  uint *puVar23;
  ulonglong uVar24;
  
  uStack_40 = 0x100016;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar19 = &stack0xffffffffffffffc8 + lVar12;
  puVar1 = (uint *)((longlong)&uStackX_8 + lVar12);
  *(undefined8 *)(&stack0x00000048 + lVar12) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002750 + lVar12) = unaff_RBX;
  *(ulonglong *)(&stack0x000026e8 + lVar12) = _DAT_ ^ (ulonglong)puVar1;
  *(uint **)((longlong)&puStackX_10 + lVar12) = param_3;
  *(short **)((longlong)&psStackX_20 + lVar12) = param_2;
  *(longlong *)(&stack0x00000028 + lVar12) = param_1;
  uVar24 = 0;
  uVar21 = 0;
  puVar23 = (uint *)0x0;
  lVar14 = *(longlong *)(*(longlong *)(param_1 + 0x58) + 8);
  psVar18 = param_2;
  puVar25 = param_3;
  uVar20 = uVar24;
  if (*(int *)(lVar14 + 0x100) == 2) {
    if ((*(byte *)(lVar14 + 0x42) & 4) == 0) {
      uVar20 = (ulonglong)*(uint *)(lVar14 + 0xb0);
      if (0x1f9e < *(uint *)(lVar14 + 0xb0)) {
        uVar20 = 0x1f9e;
      }
    }
    else {
      uVar20 = 0x1f9e;
    }
    uVar21 = (undefined4)uVar20;
    uVar16 = uVar20 + 0xf;
    if (uVar16 <= uVar20) {
      uVar16 = 0xffffffffffffff0;
    }
    uVar16 = uVar16 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_40 + lVar12) = 0x1000aa;
    func_0x();
    puVar19 = &stack0xffffffffffffffc8 + -uVar16 + lVar12;
    uVar20 = (longlong)&uStackX_8 + -uVar16 + lVar12;
  }
  puVar2 = (ushort *)(psVar18 + 1);
  if (*psVar18 != 0) {
    *(undefined4 *)((longlong)&uStackX_c + lVar12) = 0;
    *(longlong *)(puVar19 + 0x20) = (longlong)&uStackX_c + lVar12;
    *(undefined8 *)(puVar19 + -8) = 0x1009c8;
    puVar23 = (uint *)func_0x(puVar2,param_3);
    if ((((*param_2 != 0) && (plVar4 = *(longlong **)(param_2 + 8), plVar4 != (longlong *)0x0)) &&
        (*plVar4 != 0)) &&
       (((*(byte *)((longlong)param_3 + 6) & 8) == 0 &&
        ((*(uint *)((longlong)&uStackX_c + lVar12) & 1) == 0)))) {
      if ((puVar23 == (uint *)0x0) || (puVar23 == (uint *)0x834470)) {
        puVar23 = (uint *)0x0;
        *puVar1 = 0;
      }
      else {
        *(uint *)(puVar19 + 0x38) = *(uint *)((longlong)&uStackX_c + lVar12);
        *(uint **)(puVar19 + 0x30) = puVar1;
        *(undefined4 *)(puVar19 + 0x28) = uVar21;
        *(ulonglong *)(puVar19 + 0x20) = uVar20;
        uVar11 = *puVar1;
        *(undefined8 *)(puVar19 + -8) = 0x100a22;
        puVar23 = (uint *)func_0x(plVar4,param_3,puVar23,uVar11);
      }
    }
    goto LAB_;
  }
  uVar11 = *puVar25;
  if ((uVar11 & 0xc0000000) == 0x80000000) {
    *(undefined8 *)(puVar19 + -8) = 0x100988;
    iVar10 = func_0x(puVar2);
    if (iVar10 == 0) {
      *puVar1 = 0;
    }
    else {
      *(undefined8 *)(puVar19 + -8) = 0x1009a0;
      puVar23 = (uint *)func_0x(psVar18 + 0x15,param_3,puVar1,
                                        (longlong)&puStackX_10 + lVar12);
    }
    goto LAB_;
  }
  uVar8 = *(ushort *)((longlong)puVar25 + 6);
  if ((uVar8 & 0x10) != 0) {
    bVar15 = **(byte **)(psVar18 + 4);
    if ((bVar15 & 0x10) == 0) {
      if ((1 << (bVar15 & 0xe) & 0x1105U) != 0) {
LAB_:
        puVar23 = *(uint **)(param_3 + 2) + 1;
        *puVar1 = **(uint **)(param_3 + 2);
        param_1 = *(longlong *)(&stack0x00000028 + lVar12);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(psVar18 + 8) <= (int)uVar11) ||
            (*(ushort *)(*(byte **)(psVar18 + 4) + *(uint *)(psVar18 + 8)) <
             *(ushort *)(param_3 + 1))) goto LAB_;
  }
  if (-1 < (int)uVar11) {
    if ((uVar8 & 8) != 0) {
      puVar23 = (uint *)0x834470;
      if ((*(byte *)((longlong)(int)uVar11 + *(longlong *)(psVar18 + 4)) &
          (byte)(1 << ((byte)uVar8 & 7))) == 0) {
        puVar23 = (uint *)0x834471;
      }
      *puVar1 = 1;
      param_1 = *(longlong *)(&stack0x00000028 + lVar12);
      goto LAB_;
    }
    if ((uVar8 & 0x10) != 0) {
      bVar15 = **(byte **)(psVar18 + 4);
      if ((bVar15 & 0x10) == 0) {
        if ((1 << (bVar15 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar23 = *(uint **)(param_3 + 2) + 1;
          uVar11 = **(uint **)(param_3 + 2);
          if (uVar11 != 0x1f9e) {
            *(undefined8 *)(puVar19 + 0x20) = 0;
            *(undefined8 *)(puVar19 + -8) = 0x1001d0;
            (*_DAT_)(1,0xc5dc20,0xc5c588,0x381);
            *puVar1 = uVar11;
            param_1 = *(longlong *)(&stack0x00000028 + lVar12);
            goto LAB_;
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(psVar18 + 8) <= (int)uVar11) ||
              (*(ushort *)(*(byte **)(psVar18 + 4) + *(uint *)(psVar18 + 8)) <
               *(ushort *)(param_3 + 1))) goto LAB_;
    }
    puVar23 = (uint *)((longlong)(int)uVar11 + *(longlong *)(psVar18 + 4));
    *puVar1 = 0x1f9e;
    param_1 = *(longlong *)(&stack0x00000028 + lVar12);
    goto LAB_;
  }
  if (*(int *)(psVar18 + 2) == 0) {
    *puVar2 = 0;
    uVar11 = *(uint *)(psVar18 + 8);
    uVar20 = (ulonglong)uVar11;
    *(uint *)(psVar18 + 10) = uVar11;
    pbVar3 = *(byte **)(psVar18 + 4);
    bVar15 = *pbVar3;
    if ((bVar15 & 0x10) != 0) {
      uVar11 = uVar11 + 2 + (*(ushort *)(pbVar3 + uVar20) + 7 >> 3);
      uVar20 = (ulonglong)uVar11;
      *(uint *)(psVar18 + 10) = uVar11;
      bVar15 = *pbVar3;
    }
    if ((bVar15 & 0x20) == 0) {
      *(int *)(psVar18 + 2) = (int)uVar20;
      psVar18[0xe] = 0;
      *(int *)(psVar18 + 0xc) = (int)uVar20;
    }
    else {
      puVar26 = (ushort *)(pbVar3 + uVar20);
      uVar8 = *puVar26;
      psVar18[0xe] = uVar8;
      if (uVar8 == 0) {
        *(undefined8 *)(puVar19 + -8) = 0x100278;
        cVar7 = func_0x(0x11bfdd0);
        if (cVar7 != '\0') {
          *(undefined8 *)(puVar19 + -8) = 0x100281;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)(puVar19 + -8) = 0x10029b;
            cVar7 = func_0x(0x11bfdd0);
            if (cVar7 == '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x1002b7;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)(puVar19 + 0x20) = 0;
              *(undefined8 *)(puVar19 + -8) = 0x1002db;
              (*_DAT_)(1,0xaaf7dc,0xbcf8c8,0x80f);
            }
          }
        }
        uVar13 = *(undefined8 *)(psVar18 + 4);
        *(undefined8 *)(puVar19 + -8) = 0x1002e9;
        func_0x(uVar13,3);
        uVar8 = psVar18[0xe];
        uVar20 = (ulonglong)*(uint *)(psVar18 + 10);
      }
      uVar11 = (int)uVar20 + (uVar8 + 1) * 2;
      *(uint *)(psVar18 + 0xc) = uVar11;
      if (0x1f9e < uVar11) {
        *(undefined8 *)(puVar19 + -8) = 0x100319;
        cVar7 = func_0x(0x11bfdd0);
        if (cVar7 != '\0') {
          *(undefined8 *)(puVar19 + -8) = 0x100322;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)(puVar19 + -8) = 0x10033c;
            cVar7 = func_0x(0x11bfdd0);
            if (cVar7 == '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x100358;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar19 + 0x20) = 0;
              *(undefined8 *)(puVar19 + -8) = 0x10037c;
              (*_DAT_)(1,0xaaf7dc,0xbcf8c8,0x816);
            }
          }
        }
        uVar13 = *(undefined8 *)(psVar18 + 4);
        *(undefined8 *)(puVar19 + -8) = 0x10038a;
        func_0x(uVar13,4);
        uVar8 = psVar18[0xe];
        uVar11 = *(uint *)(psVar18 + 0xc);
      }
      uVar20 = (ulonglong)uVar8;
      uVar8 = puVar26[uVar20];
      *(uint *)(psVar18 + 2) = uVar8 & 0x7fff;
      if ((uVar8 & 0x7fff) < uVar11) {
        *(undefined8 *)(puVar19 + -8) = 0x1003bc;
        cVar7 = func_0x(0x11bfdd0);
        if (cVar7 != '\0') {
          *(undefined8 *)(puVar19 + -8) = 0x1003c5;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)(puVar19 + -8) = 0x1003df;
            cVar7 = func_0x(0x11bfdd0);
            if (cVar7 == '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x1003fb;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)(puVar19 + 0x20) = 0;
              *(undefined8 *)(puVar19 + -8) = 0x10041f;
              (*_DAT_)(1,0xaaf7dc,0xbcf8c8,0x81d);
            }
          }
        }
        uVar13 = *(undefined8 *)(psVar18 + 4);
        *(undefined8 *)(puVar19 + -8) = 0x10042d;
        func_0x(uVar13,4);
        uVar11 = *(uint *)(psVar18 + 0xc);
        uVar20 = (ulonglong)(ushort)psVar18[0xe];
      }
      puVar6 = puVar26;
      if ((short)uVar20 != 0) {
        do {
          uVar22 = puVar6[1] & 0x7fff;
          if ((uVar22 < uVar11) || (*(uint *)(psVar18 + 2) < uVar22)) {
            *(undefined8 *)(puVar19 + -8) = 0x100470;
            cVar7 = func_0x(0x11bfdd0);
            if (cVar7 != '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x100479;
              lVar14 = func_0x();
              if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                *(undefined8 *)(puVar19 + -8) = 0x100493;
                cVar7 = func_0x(0x11bfdd0);
                if (cVar7 == '\0') {
                  *(undefined8 *)(puVar19 + -8) = 0x1004af;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(puVar19 + 0x20) = 0;
                  *(undefined8 *)(puVar19 + -8) = 0x1004d3;
                  (*_DAT_)(1,0xaaf7dc,0xbcf8c8,0x82a);
                }
              }
            }
            uVar13 = *(undefined8 *)(psVar18 + 4);
            *(undefined8 *)(puVar19 + -8) = 0x1004e1;
            func_0x(uVar13,4);
          }
          uVar27 = (int)uVar24 + 1;
          uVar24 = (ulonglong)uVar27;
          uVar20 = (ulonglong)(ushort)psVar18[0xe];
          puVar6 = puVar6 + 1;
          uVar11 = uVar22;
        } while ((int)uVar27 < (int)(uint)(ushort)psVar18[0xe]);
        param_3 = *(uint **)((longlong)&puStackX_10 + lVar12);
      }
      if ((short)puVar26[(ulonglong)((int)uVar20 - 1) + 1] < 0) {
        lVar14 = *(longlong *)(psVar18 + 4);
        do {
          uVar11 = *(ushort *)((ulonglong)*(uint *)(psVar18 + 10) + lVar14 + uVar20 * 2) & 0x7fff;
          if ((int)uVar20 == 1) {
            uVar22 = *(uint *)(psVar18 + 0xc);
            uVar20 = (ulonglong)uVar22;
LAB_:
            if ((uVar11 < (uint)uVar20) || (*(uint *)(psVar18 + 2) < uVar11)) goto LAB_;
          }
          else {
            uVar27 = *(ushort *)((ulonglong)*(uint *)(psVar18 + 10) + lVar14 + -2 + uVar20 * 2) &
                     0x7fff;
            uVar20 = (ulonglong)uVar27;
            uVar22 = *(uint *)(psVar18 + 0xc);
            if (uVar22 <= uVar27) goto LAB_;
LAB_:
            *(undefined8 *)(puVar19 + -8) = 0x100561;
            func_0x(lVar14,7);
            uVar22 = *(uint *)(psVar18 + 0xc);
          }
          uVar27 = (uint)uVar20;
          if ((uVar27 < uVar22) || (*(uint *)(psVar18 + 2) < uVar27)) goto LAB_;
          lVar14 = *(longlong *)(psVar18 + 4);
          if (*(ushort *)(uVar20 + lVar14) == 5) {
            *puVar2 = *puVar2 | 2;
            psVar18[0xe] = psVar18[0xe] + -1;
            uVar24 = uVar20 & 0xffff;
            psVar18[0x15] = (short)uVar20;
            uVar8 = psVar18[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar24 + 2 + lVar14) >> 0xe & 1) != 0) {
              uVar8 = *(ushort *)(uVar24 + 2 + lVar14) & 0x3800 | psVar18[0x16] & 0xc7ffU;
            }
            psVar18[0x16] = uVar8;
            uVar9 = (uVar8 ^ *(ushort *)(uVar24 + 2 + lVar14)) & 0x7ff ^ uVar8;
            psVar18[0x16] = uVar9;
            uVar20 = *(ulonglong *)(psVar18 + 4);
            uVar16 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar20 + (uVar8 >> 0xb & 7) * 2 + uVar24
            ;
            if (uVar16 < uVar24 + uVar20) {
              *(undefined8 *)(puVar19 + -8) = 0x10066c;
              func_0x(uVar24 + uVar20,0x19);
              uVar9 = psVar18[0x16];
              uVar24 = (ulonglong)(ushort)psVar18[0x15];
              uVar20 = (ulonglong)*(uint *)(psVar18 + 4);
            }
            if (uVar11 - uVar27 < (((uVar9 & 0x7ff) * 2 - (int)uVar24) - (int)uVar20) + (int)uVar16)
            {
              lVar14 = *(longlong *)(psVar18 + 4);
              *(undefined8 *)(puVar19 + -8) = 0x1006a4;
              func_0x(uVar24 + lVar14,0x19);
              uVar9 = psVar18[0x16];
            }
            if ((uVar9 & 0x3800) != 0) {
              puVar26 = (ushort *)
                        (*(longlong *)(psVar18 + 4) + (ulonglong)(ushort)psVar18[0x15] + 4);
              iVar10 = 0;
              if ((uVar9 & 0x3800) != 0) {
                do {
                  if ((uVar9 & 0x7ff) < (*puVar26 & 0x7ff)) {
                    uVar8 = psVar18[0x15];
                    lVar14 = *(longlong *)(psVar18 + 4);
                    *(undefined8 *)(puVar19 + -8) = 0x1006f7;
                    func_0x((ulonglong)uVar8 + lVar14,0x1a);
                    uVar9 = psVar18[0x16];
                  }
                  iVar10 = iVar10 + 1;
                  puVar26 = puVar26 + 1;
                } while (iVar10 < (int)(uVar9 >> 0xb & 7));
              }
            }
            goto LAB_;
          }
          if (*(ushort *)(uVar20 + lVar14) < 0x400) goto LAB_;
          *puVar2 = *puVar2 | 1;
          uVar8 = psVar18[0xe] - 1;
          psVar18[0xe] = uVar8;
          if (uVar8 == 0) goto LAB_;
          uVar20 = (ulonglong)uVar8;
        } while ((short)puVar26[(ulonglong)(uVar8 - 1) + 1] < 0);
        uVar20 = (ulonglong)*(uint *)(psVar18 + 2);
      }
      else {
LAB_:
        uVar20 = (ulonglong)*(uint *)(psVar18 + 2);
      }
    }
    if ((**(byte **)(psVar18 + 4) & 0x40) == 0) {
      *(undefined4 *)(psVar18 + 0x13) = 0;
    }
    else {
      *(int *)(psVar18 + 0x13) = (int)uVar20;
      *(int *)(psVar18 + 2) = (int)uVar20 + 0xe;
      *(undefined8 *)(puVar19 + -8) = 0x100742;
      uVar13 = func_0x(puVar2);
      *(undefined8 *)(puVar19 + -8) = 0x10074e;
      func_0x(uVar13,auStackX_18 + lVar12);
      *(undefined8 *)(puVar19 + -8) = 0x100757;
      iVar10 = func_0x(auStackX_18 + lVar12);
      *(int *)(psVar18 + 2) = *(int *)(psVar18 + 2) + iVar10;
      uVar20 = (ulonglong)*(uint *)(psVar18 + 2);
    }
    iVar10 = (int)uVar20;
    if ((*(ulonglong *)(psVar18 + 0xf) != 0) &&
       (*(ulonglong *)(psVar18 + 0xf) < uVar20 + *(longlong *)(psVar18 + 4))) {
      *(undefined8 *)(puVar19 + -8) = 0x10078f;
      cVar7 = func_0x(0x11bfdd0);
      if (cVar7 != '\0') {
        *(undefined8 *)(puVar19 + -8) = 0x100798;
        lVar14 = func_0x();
        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
          *(undefined8 *)(puVar19 + -8) = 0x1007b2;
          cVar7 = func_0x(0x11bfdd0);
          if (cVar7 == '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x1007ce;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)(puVar19 + 0x20) = 0;
            *(undefined8 *)(puVar19 + -8) = 0x1007f2;
            (*_DAT_)(1,0xaaf7dc,0xbcf8c8,0x886);
          }
        }
      }
      uVar13 = *(undefined8 *)(psVar18 + 4);
      *(undefined8 *)(puVar19 + -8) = 0x100800;
      func_0x(uVar13,0x12);
      iVar10 = *(int *)(psVar18 + 2);
    }
    if (0x3f3b < iVar10 - 1U) {
      *(undefined8 *)(puVar19 + -8) = 0x100819;
      cVar7 = func_0x(0x11bfdd0);
      if (cVar7 != '\0') {
        *(undefined8 *)(puVar19 + -8) = 0x100822;
        lVar14 = func_0x();
        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
          *(undefined8 *)(puVar19 + -8) = 0x10083c;
          cVar7 = func_0x(0x11bfdd0);
          if (cVar7 == '\0') {
            *(undefined8 *)(puVar19 + -8) = 0x100858;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)(puVar19 + 0x20) = 0;
            *(undefined8 *)(puVar19 + -8) = 0x10087c;
            (*_DAT_)(1,0xaaf7dc,0xbcf8c8,0x88b);
          }
        }
      }
      uVar13 = *(undefined8 *)(psVar18 + 4);
      *(undefined8 *)(puVar19 + -8) = 0x10088a;
      func_0x(uVar13,5);
    }
  }
LAB_:
  sVar17 = -*(short *)param_3;
  if ((*(byte *)((longlong)param_3 + 6) & 0x10) != 0) {
    bVar15 = **(byte **)(psVar18 + 4);
    if ((bVar15 & 0x10) == 0) {
      if ((1 << (bVar15 & 0xe) & 0x1105U) != 0) {
LAB_:
        puVar23 = *(uint **)(param_3 + 2) + 1;
        param_2 = *(short **)((longlong)&psStackX_20 + lVar12);
        *puVar1 = **(uint **)(param_3 + 2);
        param_1 = *(longlong *)(&stack0x00000028 + lVar12);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(psVar18 + 8) <= (int)*param_3) ||
            (*(ushort *)(*(byte **)(psVar18 + 4) + *(uint *)(psVar18 + 8)) <
             *(ushort *)(param_3 + 1))) goto LAB_;
  }
  lVar14 = (longlong)sVar17;
  puVar23 = *(uint **)(psVar18 + 4);
  if ((uint)(ushort)psVar18[0xe] < (uint)(int)sVar17) {
    uVar11 = 0;
    param_2 = *(short **)((longlong)&psStackX_20 + lVar12);
LAB_:
    *puVar1 = uVar11;
    param_1 = *(longlong *)(&stack0x00000028 + lVar12);
    goto LAB_;
  }
  uVar11 = *(uint *)(psVar18 + 10);
  if (sVar17 == 1) {
    uVar22 = *(uint *)(psVar18 + 0xc);
    uVar11 = *(ushort *)((longlong)puVar23 + lVar14 * 2 + (ulonglong)uVar11) & 0x7fff;
LAB_:
    if ((uVar11 < uVar22) || (*(uint *)(psVar18 + 2) < uVar11)) goto LAB_;
  }
  else {
    uVar22 = *(ushort *)((longlong)puVar23 + lVar14 * 2 + ((ulonglong)uVar11 - 2)) & 0x7fff;
    uVar11 = *(ushort *)((longlong)puVar23 + lVar14 * 2 + (ulonglong)uVar11) & 0x7fff;
    puVar23 = *(uint **)(psVar18 + 4);
    if (*(uint *)(psVar18 + 0xc) <= uVar22) goto LAB_;
LAB_:
    *(undefined8 *)(puVar19 + -8) = 0x10094f;
    func_0x(puVar23,7);
    puVar23 = *(uint **)(psVar18 + 4);
  }
  puVar23 = (uint *)((longlong)puVar23 + (ulonglong)uVar22);
  param_2 = *(short **)((longlong)&psStackX_20 + lVar12);
  *puVar1 = uVar11 - uVar22;
  param_1 = *(longlong *)(&stack0x00000028 + lVar12);
LAB_:
  if (*puVar1 != 0) {
    if ((*puVar1 < 0x30) || (*(short *)puVar23 != 3)) {
      *(undefined8 *)(puVar19 + -8) = 0x100bcc;
      func_0x(&stack0x00000648 + lVar12,&stack0x00000750 + lVar12);
      *(undefined8 *)(&stack0x00000648 + lVar12) = 0x84a408;
      *(undefined4 *)(puVar19 + 0x28) = 0;
      *(uint *)(puVar19 + 0x20) = *param_3;
      uVar11 = *puVar1;
      *(undefined8 *)(puVar19 + -8) = 0x100bfe;
      func_0x(&stack0x00000648 + lVar12,param_1,puVar23,uVar11);
      *(undefined8 *)(puVar19 + -8) = 0x100c0a;
      func_0x(&stack0x00000648 + lVar12);
      *(undefined8 *)(puVar19 + -8) = 0x100c16;
      func_0x(&stack0x00000648 + lVar12);
      *(undefined8 *)(puVar19 + -8) = 0x100c23;
      func_0x(&stack0x00000648 + lVar12);
    }
    else {
      uVar11 = *param_3;
      if ((int)uVar11 < 0) {
        if ((uVar11 & 0xc0000000) == 0x80000000) {
          uVar13 = **(undefined8 **)(*(longlong *)(*(longlong *)(param_1 + 0x58) + 8) + 0x160);
          *(undefined8 *)(puVar19 + -8) = 0x100a99;
          lVar14 = func_0x(uVar13,uVar11 & 0x1fffffff);
        }
        else {
          uVar13 = *(undefined8 *)(*(longlong *)(*(longlong *)(param_1 + 0x58) + 8) + 0x160);
          *(undefined8 *)(puVar19 + -8) = 0x100a7e;
          lVar14 = func_0x(uVar13);
        }
        if (lVar14 != 0) {
          *(undefined8 *)(puVar19 + -8) = 0x100aae;
          func_0x(&stack0x00000058 + lVar12);
          *(undefined4 *)(&stack0x00000030 + lVar12) = _DAT_;
          *(undefined4 *)(&stack0x00000034 + lVar12) = uRam00000000008348b4;
          *(undefined4 *)(&stack0x00000038 + lVar12) = uRam00000000008348b8;
          *(undefined4 *)(&stack0x0000003c + lVar12) = uRam00000000008348bc;
          *(undefined4 *)(&stack0x00000040 + lVar12) = 0;
          *(undefined **)(puVar19 + 0x38) = &stack0x00000030 + lVar12;
          *(undefined4 *)(puVar19 + 0x30) = *(undefined4 *)(lVar14 + 0x3c);
          *(undefined4 *)(puVar19 + 0x28) = 0x800;
          *(undefined4 *)(puVar19 + 0x20) = 0;
          *(undefined8 *)(puVar19 + -8) = 0x100aeb;
          func_0x(&stack0x00000058 + lVar12,param_1,puVar23);
          *(undefined8 *)(puVar19 + -8) = 0x100af4;
          func_0x(&stack0x00000058 + lVar12);
          bVar15 = (&stack0x00000308)[lVar12];
          if (((bVar15 & 2) != 0) && (((&stack0x00000064)[lVar12] & 8) != 0)) {
            *(undefined8 *)(puVar19 + -8) = 0x100b0f;
            func_0x(&stack0x00000058 + lVar12);
            uVar11 = *(uint *)(&stack0x00000064 + lVar12) & 0xfffffff7;
            *(uint *)(&stack0x00000064 + lVar12) = uVar11;
            if ((char)uVar11 < '\0') {
              *(undefined8 *)(puVar19 + -8) = 0x100b25;
              func_0x(&stack0x00000058 + lVar12);
              uVar11 = *(uint *)(&stack0x00000064 + lVar12);
            }
            bVar15 = (&stack0x00000308)[lVar12];
            if ((uVar11 & 2) != 0) {
              bVar15 = bVar15 & 0xfe;
              (&stack0x00000308)[lVar12] = bVar15;
              *(uint *)(&stack0x00000064 + lVar12) = uVar11 & 0xfffffffd;
            }
          }
          (&stack0x00000308)[lVar12] = bVar15 & 0xfd;
          *(undefined8 *)(puVar19 + -8) = 0x100b56;
          func_0x(&stack0x00000058 + lVar12,0);
          *(uint *)(&stack0x00000064 + lVar12) = *(uint *)(&stack0x00000064 + lVar12) | 4;
          if (*(longlong **)(&stack0x00000388 + lVar12) != (longlong *)0x0) {
            pcVar5 = *(code **)(**(longlong **)(&stack0x00000388 + lVar12) + 0x10);
            *(undefined8 *)(puVar19 + -8) = 0x100b6c;
            (*pcVar5)();
            *(undefined8 *)(&stack0x00000388 + lVar12) = 0;
          }
          *(undefined8 *)(&stack0x00000058 + lVar12) = 0xae1158;
          *(undefined4 *)(&stack0x00000060 + lVar12) = 0xfccccccf;
          *(undefined8 *)(puVar19 + -8) = 0x100b90;
          func_0x(&stack0x00000058 + lVar12,1);
          *(undefined8 *)(puVar19 + -8) = 0x100b9d;
          func_0x(&stack0x00000618 + lVar12);
          if (*(longlong **)(&stack0x00000388 + lVar12) != (longlong *)0x0) {
            pcVar5 = *(code **)(**(longlong **)(&stack0x00000388 + lVar12) + 0x10);
            *(undefined8 *)(puVar19 + -8) = 0x100bb0;
            (*pcVar5)();
            *(undefined8 *)(&stack0x00000388 + lVar12) = 0;
          }
        }
      }
    }
  }
  if (*param_2 == 0) {
    *(undefined8 *)(puVar19 + -8) = 0x100c39;
    func_0x(puVar2,param_3,0);
  }
  else {
    if (*(int *)(psVar18 + 2) == 0) {
      *(undefined8 *)(puVar19 + -8) = 0x100c49;
      func_0x(puVar2);
    }
    if (*(ushort *)(param_3 + 1) <= *puVar2) {
      uVar8 = psVar18[0xf];
      lVar14 = *(longlong *)(psVar18 + 4);
      *(undefined8 *)(puVar19 + -8) = 0x100c66;
      uVar11 = func_0x(puVar2);
      puVar2 = (ushort *)((ulonglong)uVar8 + lVar14 + 3 + (ulonglong)uVar11 * 2);
      *puVar2 = *puVar2 & 0x7fff;
    }
  }
  *(undefined8 *)(puVar19 + -8) = 0x100c83;
  func_0x(param_2,param_3,0,0);
  uVar20 = *(ulonglong *)(&stack0x000026e8 + lVar12);
  *(undefined8 *)(puVar19 + -8) = 0x100c92;
  func_0x(uVar20 ^ (ulonglong)puVar1);
  return;
}

