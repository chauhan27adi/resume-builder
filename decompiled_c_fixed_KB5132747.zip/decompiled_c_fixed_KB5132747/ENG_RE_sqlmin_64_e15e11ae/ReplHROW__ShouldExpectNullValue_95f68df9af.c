
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_(short *param_1,uint *param_2,byte *param_3)

{
  ushort *puVar1;
  uint uVar2;
  longlong *plVar3;
  ushort *puVar4;
  bool bVar5;
  bool bVar6;
  byte bVar7;
  char cVar8;
  ushort uVar9;
  ushort uVar10;
  uint uVar11;
  int iVar12;
  undefined4 uVar13;
  longlong lVar14;
  undefined8 uVar15;
  uint *puVar16;
  uint *puVar17;
  uint uVar18;
  ulonglong uVar19;
  uint *puVar20;
  uint uVar21;
  ulonglong uVar22;
  short sVar23;
  byte *pbVar24;
  ulonglong uVar25;
  ushort *puVar26;
  uint uVar27;
  undefined4 auStackX_8 [2];
  uint auStackX_18 [2];
  undefined auStackX_20 [8];
  
  puVar20 = (uint *)0x0;
  bVar5 = false;
  bVar6 = false;
  auStackX_8[0] = 0;
  if ((*(short *)(param_3 + 0x10) == -1) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*param_3 + 0x1813ce0) + 0x21cad78) != '\0')) {
    bVar6 = true;
  }
  uVar11 = func_0x(param_1);
  uVar21 = (uint)*(ushort *)(param_3 + 0x10);
  if ((*(ushort *)(param_3 + 0x10) == 0xffff) ||
     (*(char *)((ulonglong)*(byte *)((ulonglong)*param_3 + 0x1813ce0) + 0x21cad78) != '\0')) {
    uVar21 = 0x1fa4;
  }
  puVar1 = (ushort *)(param_1 + 1);
  if (*param_1 != 0) {
    auStackX_18[0] = 0;
    puVar17 = (uint *)func_0x(puVar1,param_2);
    puVar16 = puVar17;
    if ((((*param_1 != 0) && (plVar3 = *(longlong **)(param_1 + 8), plVar3 != (longlong *)0x0)) &&
        (*plVar3 != 0)) &&
       ((((*(byte *)((longlong)param_2 + 6) & 8) == 0 && ((auStackX_18[0] & 1) == 0)) &&
        ((puVar16 = puVar20, puVar17 != (uint *)0x0 && (puVar17 != (uint *)0x18136c0)))))) {
      puVar16 = (uint *)func_0x(plVar3,param_2,puVar17,auStackX_8[0],0,0,auStackX_8,
                                        auStackX_18[0]);
    }
    goto LAB_;
  }
  uVar27 = *param_2;
  auStackX_18[0] = uVar11;
  if ((uVar27 & 0xc0000000) == 0x80000000) {
    iVar12 = func_0x(puVar1);
    puVar16 = (uint *)0x0;
    if (iVar12 != 0) {
      puVar16 = (uint *)func_0x(param_1 + 0x15,param_2,auStackX_8,auStackX_18);
    }
    goto LAB_;
  }
  pbVar24 = *(byte **)(param_1 + 4);
  bVar7 = *pbVar24;
  if ((bVar7 & 0x10) == 0) {
    if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
      uVar9 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
      goto LAB_;
    }
  }
  else {
    uVar2 = *(uint *)(param_1 + 8);
    if ((int)uVar27 < (int)uVar2) {
      if ((uint)*(ushort *)(pbVar24 + uVar2) < (uint)*(ushort *)(param_2 + 1)) {
        bVar5 = false;
        uVar9 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
      }
      else {
        uVar18 = *(ushort *)(param_2 + 1) - 1;
        bVar5 = true;
        uVar9 = (ushort)(pbVar24[(ulonglong)uVar2 + (ulonglong)(uVar18 >> 3) + 2] >>
                        ((byte)uVar18 & 7));
      }
    }
    else {
      bVar5 = false;
      uVar9 = ~(*(ushort *)((longlong)param_2 + 6) >> 4);
    }
LAB_:
    puVar16 = puVar20;
    if ((uVar9 & 1) != 0) goto LAB_;
    if ((!bVar5) && ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0)) {
      puVar16 = (uint *)(*(longlong *)(param_2 + 2) + 4);
      goto LAB_;
    }
  }
  if (-1 < (int)uVar27) {
    uVar9 = *(ushort *)((longlong)param_2 + 6);
    if ((uVar9 & 8) != 0) {
      puVar16 = (uint *)0x18136c0;
      if ((pbVar24[(int)uVar27] & (byte)(1 << ((byte)uVar9 & 7))) == 0) {
        puVar16 = (uint *)0x18136c1;
      }
      goto LAB_;
    }
    if ((uVar9 & 0x10) != 0) {
      if ((bVar7 & 0x10) == 0) {
        if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar16 = *(uint **)(param_2 + 2) + 1;
          if ((uVar21 != 0) && (**(uint **)(param_2 + 2) != uVar21)) {
            (*_DAT_)(1,0x1c3ce70,0x1c3b7d8,0x381,0);
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uVar27) ||
              (*(ushort *)(pbVar24 + *(uint *)(param_1 + 8)) < *(ushort *)(param_2 + 1)))
      goto LAB_;
    }
    puVar16 = (uint *)(pbVar24 + (int)uVar27);
    goto LAB_;
  }
  if (*(int *)(param_1 + 2) == 0) {
    uVar11 = *(uint *)(param_1 + 8);
    uVar19 = (ulonglong)uVar11;
    *(uint *)(param_1 + 10) = uVar11;
    *puVar1 = 0;
    bVar7 = *pbVar24;
    if ((bVar7 & 0x10) != 0) {
      uVar11 = uVar11 + 2 + (*(ushort *)(pbVar24 + uVar19) + 7 >> 3);
      uVar19 = (ulonglong)uVar11;
      *(uint *)(param_1 + 10) = uVar11;
      bVar7 = *pbVar24;
    }
    if ((bVar7 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar19;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar19;
    }
    else {
      puVar26 = (ushort *)(pbVar24 + uVar19);
      uVar9 = *puVar26;
      param_1[0xe] = uVar9;
      if (uVar9 == 0) {
        cVar8 = func_0x(0x219f020);
        if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
           (*(char *)(lVar14 + 0x499) != '\0')) {
          cVar8 = func_0x(0x219f020);
          if (cVar8 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x1a8ea2c,0x1baeb18,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar19 = (ulonglong)*(uint *)(param_1 + 10);
        uVar9 = param_1[0xe];
      }
      uVar11 = (int)uVar19 + (uVar9 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar11;
      if (0x1f9e < uVar11) {
        cVar8 = func_0x(0x219f020);
        if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
           (*(char *)(lVar14 + 0x499) != '\0')) {
          cVar8 = func_0x(0x219f020);
          if (cVar8 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1a8ea2c,0x1baeb18,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar9 = param_1[0xe];
        uVar11 = *(uint *)(param_1 + 0xc);
      }
      uVar19 = (ulonglong)uVar9;
      uVar9 = puVar26[uVar19];
      *(uint *)(param_1 + 2) = uVar9 & 0x7fff;
      if ((uVar9 & 0x7fff) < uVar11) {
        cVar8 = func_0x(0x219f020);
        if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
           (*(char *)(lVar14 + 0x499) != '\0')) {
          cVar8 = func_0x(0x219f020);
          if (cVar8 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x1a8ea2c,0x1baeb18,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar11 = *(uint *)(param_1 + 0xc);
        uVar19 = (ulonglong)(ushort)param_1[0xe];
      }
      puVar16 = puVar20;
      puVar4 = puVar26;
      if ((short)uVar19 != 0) {
        do {
          uVar21 = puVar4[1] & 0x7fff;
          if ((uVar21 < uVar11) || (*(uint *)(param_1 + 2) < uVar21)) {
            cVar8 = func_0x(0x219f020);
            if ((cVar8 != '\0') &&
               ((lVar14 = func_0x(), lVar14 != 0 &&
                (*(char *)(lVar14 + 0x499) != '\0')))) {
              cVar8 = func_0x(0x219f020);
              if (cVar8 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x1a8ea2c,0x1baeb18,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
          }
          uVar19 = (ulonglong)(ushort)param_1[0xe];
          uVar27 = (int)puVar16 + 1;
          puVar16 = (uint *)(ulonglong)uVar27;
          puVar4 = puVar4 + 1;
          uVar11 = uVar21;
        } while ((int)uVar27 < (int)(uint)(ushort)param_1[0xe]);
      }
      if ((short)puVar26[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
        pbVar24 = *(byte **)(param_1 + 4);
        do {
          uVar11 = *(ushort *)(pbVar24 + uVar19 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff;
          if ((int)uVar19 == 1) {
            uVar21 = *(uint *)(param_1 + 0xc);
            uVar27 = uVar21;
LAB_:
            if ((uVar11 < uVar21) || (*(uint *)(param_1 + 2) < uVar11)) goto LAB_;
          }
          else {
            uVar27 = *(uint *)(param_1 + 0xc);
            uVar21 = *(ushort *)(pbVar24 + uVar19 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
                     0x7fff;
            if (uVar27 <= uVar21) goto LAB_;
LAB_:
            func_0x(pbVar24,7);
            uVar27 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar21 < uVar27) || (*(uint *)(param_1 + 2) < uVar21)) goto LAB_;
          pbVar24 = *(byte **)(param_1 + 4);
          if (*(ushort *)(pbVar24 + uVar21) == 5) {
            *puVar1 = *puVar1 | 2;
            param_1[0xe] = param_1[0xe] + -1;
            uVar25 = (ulonglong)(uVar21 & 0xffff);
            param_1[0x15] = (short)uVar21;
            uVar19 = *(ulonglong *)(param_1 + 4);
            uVar9 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar25 + 2 + uVar19) >> 0xe & 1) != 0) {
              uVar9 = *(ushort *)(uVar25 + 2 + uVar19) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar9;
            uVar10 = (uVar9 ^ *(ushort *)(uVar25 + 2 + uVar19)) & 0x7ff ^ uVar9;
            param_1[0x16] = uVar10;
            uVar22 = (ulonglong)((uVar10 & 0x7ff) * 2) + 4 + uVar19 + (uVar9 >> 0xb & 7) * 2 +
                     uVar25;
            if (uVar22 < uVar25 + uVar19) {
              func_0x(uVar25 + uVar19,0x19);
              uVar10 = param_1[0x16];
              uVar25 = (ulonglong)(ushort)param_1[0x15];
              uVar19 = (ulonglong)*(uint *)(param_1 + 4);
            }
            if (uVar11 - uVar21 < (((uVar10 & 0x7ff) * 2 - (int)uVar25) - (int)uVar19) + (int)uVar22
               ) {
              func_0x(uVar25 + *(longlong *)(param_1 + 4),0x19);
              uVar10 = param_1[0x16];
            }
            if (((uVar10 & 0x3800) != 0) &&
               (puVar26 = (ushort *)
                          (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
               (uVar10 & 0x3800) != 0)) {
              do {
                if ((uVar10 & 0x7ff) < (*puVar26 & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),0x1a
                                 );
                  uVar10 = param_1[0x16];
                }
                uVar11 = (int)puVar20 + 1;
                puVar20 = (uint *)(ulonglong)uVar11;
                puVar26 = puVar26 + 1;
              } while ((int)uVar11 < (int)(uVar10 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar24 + uVar21) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar9 = param_1[0xe] - 1;
          param_1[0xe] = uVar9;
          if (uVar9 == 0) goto LAB_;
          uVar19 = (ulonglong)uVar9;
        } while ((short)puVar26[(ulonglong)(uVar9 - 1) + 1] < 0);
        uVar19 = (ulonglong)*(uint *)(param_1 + 2);
      }
      else {
LAB_:
        pbVar24 = *(byte **)(param_1 + 4);
        uVar19 = (ulonglong)*(uint *)(param_1 + 2);
      }
    }
    if ((*pbVar24 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = (int)uVar19;
      *(int *)(param_1 + 2) = (int)uVar19 + 0xe;
      uVar15 = func_0x(puVar1);
      func_0x(uVar15,auStackX_20);
      iVar12 = func_0x(auStackX_20);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar12;
      uVar19 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar12 = (int)uVar19;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar19 + *(longlong *)(param_1 + 4))) {
      cVar8 = func_0x(0x219f020);
      if ((cVar8 != '\0') &&
         ((lVar14 = func_0x(), lVar14 != 0 && (*(char *)(lVar14 + 0x499) != '\0'))))
      {
        cVar8 = func_0x(0x219f020);
        if (cVar8 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x1a8ea2c,0x1baeb18,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar12 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar12 - 1U) {
      cVar8 = func_0x(0x219f020);
      if (((cVar8 != '\0') && (lVar14 = func_0x(), lVar14 != 0)) &&
         (*(char *)(lVar14 + 0x499) != '\0')) {
        cVar8 = func_0x(0x219f020);
        if (cVar8 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x1a8ea2c,0x1baeb18,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar23 = -*(short *)param_2;
  uVar11 = auStackX_18[0];
  if ((*(byte *)((longlong)param_2 + 6) & 0x10) != 0) {
    bVar7 = **(byte **)(param_1 + 4);
    if ((bVar7 & 0x10) == 0) {
      if ((1 << (bVar7 & 0xe) & 0x1105U) != 0) {
LAB_:
        puVar16 = (uint *)(*(longlong *)(param_2 + 2) + 4);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)*param_2) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) <
             *(ushort *)(param_2 + 1))) goto LAB_;
  }
  puVar16 = *(uint **)(param_1 + 4);
  lVar14 = (longlong)sVar23;
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar23) goto LAB_;
  uVar11 = *(uint *)(param_1 + 10);
  if (sVar23 == 1) {
    uVar9 = *(ushort *)((longlong)puVar16 + lVar14 * 2 + (ulonglong)uVar11);
    uVar11 = *(uint *)(param_1 + 0xc);
LAB_:
    if (((uVar9 & 0x7fff) < uVar11) || (*(uint *)(param_1 + 2) < (uVar9 & 0x7fff)))
    goto LAB_;
  }
  else {
    uVar9 = *(ushort *)((longlong)puVar16 + lVar14 * 2 + (ulonglong)uVar11);
    uVar11 = *(ushort *)((longlong)puVar16 + lVar14 * 2 + ((ulonglong)uVar11 - 2)) & 0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar11) goto LAB_;
LAB_:
    func_0x(puVar16,7);
    puVar16 = *(uint **)(param_1 + 4);
  }
  puVar16 = (uint *)((longlong)puVar16 + (ulonglong)uVar11);
  uVar11 = auStackX_18[0];
LAB_:
  if (((bVar6) || (uVar11 != 0)) || (puVar16 != (uint *)0x0)) {
    uVar13 = 0;
  }
  else {
    uVar13 = 1;
  }
  return uVar13;
}

