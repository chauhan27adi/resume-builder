
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2,longlong param_3,longlong param_4,
                 undefined8 param_5)

{
  byte *pbVar1;
  int *piVar2;
  byte *pbVar3;
  ushort uVar4;
  short sVar5;
  longlong lVar6;
  undefined auVar7 [16];
  char cVar8;
  int iVar9;
  longlong lVar10;
  uint uVar11;
  ulonglong uVar12;
  code *UNRECOVERED_JUMPTABLE_00;
  short *psVar13;
  uint uVar14;
  uint uVar15;
  ulonglong uVar16;
  ushort uVar17;
  undefined2 uVar18;
  longlong unaff_GS_OFFSET;
  undefined auStack_2a8 [32];
  longlong lStack_288;
  undefined8 *puStack_280;
  undefined4 uStack_278;
  undefined4 uStack_270;
  undefined4 uStack_268;
  undefined4 uStack_260;
  int iStack_258;
  undefined4 uStack_250;
  uint *puStack_248;
  undefined4 uStack_240;
  undefined8 uStack_238;
  undefined4 uStack_230;
  undefined8 uStack_228;
  undefined2 uStack_220;
  undefined4 uStack_218;
  undefined8 uStack_210;
  undefined4 uStack_208;
  undefined2 uStack_200;
  uint uStack_1c0;
  undefined4 uStack_1bc;
  undefined8 uStack_1b8;
  undefined4 uStack_1b0;
  undefined4 uStack_1a8;
  int iStack_1a4;
  undefined4 uStack_1a0;
  longlong lStack_198;
  uint uStack_190;
  undefined4 uStack_18c;
  undefined2 uStack_188;
  longlong lStack_180;
  longlong lStack_178;
  undefined8 uStack_170;
  undefined8 uStack_168;
  ulonglong uStack_160;
  undefined4 uStack_158;
  longlong lStack_140;
  undefined8 uStack_138;
  undefined2 uStack_130;
  undefined4 uStack_12c;
  byte *pbStack_128;
  undefined8 uStack_120;
  undefined8 uStack_112;
  undefined2 uStack_10a;
  undefined2 uStack_108;
  undefined6 uStack_106;
  int iStack_fc;
  undefined auStack_f8 [16];
  undefined auStack_e8 [8];
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  undefined6 uStack_d0;
  undefined2 uStack_ca;
  undefined6 uStack_c8;
  undefined2 uStack_c2;
  undefined2 uStack_c0;
  undefined6 uStack_be;
  undefined8 uStack_b8;
  short *psStack_b0;
  short *psStack_a8;
  short sStack_a0;
  undefined6 uStack_9e;
  undefined auStack_98 [8];
  undefined8 uStack_90;
  undefined8 uStack_88;
  uint uStack_80;
  uint uStack_7c;
  uint uStack_78;
  uint uStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_2a8;
  uVar12 = 0;
  uStack_170 = param_5;
  uStack_168 = 0;
  uStack_160 = 0;
  uStack_1a0 = 1;
  uStack_1a8 = 0;
  iStack_1a4 = 0;
  uStack_1bc = param_2;
  lStack_180 = param_4;
  lStack_178 = param_1;
  lStack_140 = param_3;
  if (1 < (ushort)(*(short *)(param_4 + 0x7a) - 4U)) {
    func_0x(param_2,param_3,4,*(undefined *)(param_3 + 1));
    func_0x(param_1,2,param_4 + 0x60);
    goto LAB_;
  }
  if ((*(byte *)(param_1 + 0xbc) & 0x20) != 0) goto LAB_;
  uStack_1c0 = 0;
  uVar15 = 0;
  if ((ulonglong)*(ushort *)(param_3 + 0x16) != 0) {
    psVar13 = (short *)(param_3 + 0x1ffe);
    uVar16 = uVar12;
    do {
      iVar9 = (int)uVar16;
      if (*psVar13 != 0) {
        uVar15 = 0;
        if (iVar9 != -1) {
          lStack_198 = (longlong)iVar9;
          goto LAB_;
        }
        break;
      }
      uStack_1c0 = iVar9 + 1;
      uVar16 = (ulonglong)uStack_1c0;
      uVar12 = uVar12 + 1;
      psVar13 = psVar13 + -1;
      uVar15 = 0;
    } while ((longlong)uVar12 < (longlong)(ulonglong)*(ushort *)(param_3 + 0x16));
  }
  goto LAB_;
LAB_:
  lVar6 = lStack_198;
  iVar9 = (int)uVar16;
  func_0x(param_4,param_3,uVar16);
  uStack_190 = func_0x(param_1,param_4,*(undefined *)(param_3 + 1));
  if ((uStack_190 & 4) == 0) {
    uStack_138 = *(undefined8 *)(param_4 + 0xa8);
    pbStack_128 = (byte *)0x0;
    uStack_130 = 0xffff;
    uStack_12c = 0;
    uStack_112 = 0;
    uStack_108 = 0;
    uStack_106 = 0;
    uStack_120 = 0;
    iStack_fc = iVar9;
    if (-1 < *(char *)(param_3 + 2)) goto LAB_;
    pbVar1 = (byte *)(param_3 + 0x60);
    stack0xffffffffffffff1a = SUB1614(ZEXT816(0),2);
    auStack_e8._0_2_ = 0xffff;
    uStack_d0 = 0;
    uStack_c2 = 0;
    uStack_e0 = 0;
    uStack_b8 = 0;
    uStack_ca = 0;
    uStack_c8 = 0;
    uStack_c0 = 0;
    uStack_be = 0;
    uStack_d8 = 0;
    psStack_b0 = (short *)0x0;
    _auStack_98 = ZEXT812(0);
    uStack_90._4_4_ = 0;
    auVar7 = _auStack_98;
    uStack_90 = 0;
    uStack_88 = 0;
    psStack_a8 = (short *)0x0;
    sStack_a0 = 0;
    uStack_9e = 0;
    auStack_f8 = ZEXT816(0);
    lVar10 = 0;
    if (*(short *)(param_3 + 0x24) == 0) {
LAB_:
      auStack_f8._8_8_ = lVar10;
      uStack_1b8 = *(undefined8 *)(param_3 + 0x28);
      uVar18 = *(undefined2 *)(param_3 + 0x30);
      uStack_1b0 = CONCAT22(uStack_1b0._2_2_,uVar18);
    }
    else {
      cVar8 = *(char *)(param_3 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(param_3 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(param_3 + 0x18) != 99) goto LAB_;
      }
      uStack_18c = *(undefined4 *)(param_3 + 0x20);
      uStack_188 = *(undefined2 *)(param_3 + 0x24);
      _auStack_98 = auVar7;
      cVar8 = func_0x(&uStack_18c);
      lVar10 = auStack_f8._8_8_;
      if (cVar8 == '\0') goto LAB_;
      func_0x(param_3,&uStack_1b8);
      uVar18 = (undefined2)uStack_1b0;
    }
    auStack_98 = (undefined  [8])uStack_1b8;
    uStack_90._4_4_ = *(undefined4 *)(param_3 + 0x20);
    auStack_f8._0_8_ = pbVar1;
    lVar10 = (ulonglong)*pbVar1 * 6;
    uStack_158 = *(undefined4 *)(lVar10 + 0xb87e60);
    uVar12 = (ulonglong)*(short *)(lVar10 + 0xb87e64);
    uStack_90._0_2_ = uVar18;
    auStack_e8._0_2_ = 0xffff;
    auStack_e8 = (undefined  [8])((ulonglong)auStack_e8 & 0xffffffff);
    uStack_e0 = 0;
    uStack_ca = 0;
    uStack_c8 = 0;
    uStack_c0 = 0;
    uStack_be = 0;
    uStack_d8 = 0;
    sStack_a0 = 0;
    psStack_b0 = (short *)0x0;
    psStack_a8 = (short *)0x0;
    if ((*pbVar1 & 2) != 0) {
      pbVar3 = pbVar1 + uVar12;
      uStack_e0 = pbVar3;
      if ((pbVar1[uVar12] & 1) == 0) {
        auVar7._14_2_ = 0;
        auVar7._0_14_ = stack0xffffffffffffff1a;
        _auStack_e8 = auVar7 << 0x10;
        uStack_c2 = 0;
        uStack_c0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010055d */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x1016b8) - 0x1a10fb0))
                  ();
        return;
      }
      auStack_e8._0_2_ = 1;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x101698) * 4 +
                             0x101688) - 0x1a10fb0);
                    /* WARNING: Could not emulate address calculation at 0x00100393 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    if ((*pbVar1 & 4) != 0) {
      uStack_158._2_2_ = (short)((uint)uStack_158 >> 0x10);
      if (uStack_158._2_2_ != 0) {
        uVar12 = (ulonglong)*(ushort *)(param_3 + 0x61 + (longlong)uStack_158._2_2_ * 2);
      }
      psStack_b0 = (short *)(pbVar1 + uVar12);
      psStack_a8 = psStack_b0 + 1;
      sStack_a0 = (*psStack_b0 + 1) * 2;
    }
    if (auStack_f8._8_8_ != 0) {
      func_0x(auStack_f8._8_8_,auStack_f8);
    }
LAB_:
    pbStack_128 = (byte *)((ulonglong)*(ushort *)((0xfff - lVar6) * 2 + param_3) + param_3);
    if ((*pbStack_128 & 1) == 0) {
      uStack_130 = 0;
      uStack_12c = 0;
      uStack_10a = 0;
      uStack_108 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001007eb */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_128 & 0xe) * 4 + 0x101724) -
                0x1a10fb0))();
      return;
    }
    uStack_130 = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_128 & 0x1c) + 0x101704) *
                            4 + 0x1016f4) - 0x1a10fb0);
                    /* WARNING: Could not emulate address calculation at 0x0010066f */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((uStack_190 & 0x10) == 0) {
    func_0x(&uStack_168,param_4 + 0xa0);
  }
  else {
    iStack_1a4 = 1;
  }
  lStack_198 = lVar6 + 1;
  uStack_1c0 = iVar9 + 1;
  if ((longlong)(ulonglong)*(ushort *)(param_3 + 0x16) <= lStack_198) goto LAB_;
  psVar13 = (short *)((0xfff - lStack_198) * 2 + param_3);
  while (uVar16 = (ulonglong)uStack_1c0, *psVar13 == 0) {
    uStack_1c0 = uStack_1c0 + 1;
    lStack_198 = lStack_198 + 1;
    psVar13 = psVar13 + -1;
    if ((longlong)(ulonglong)*(ushort *)(param_3 + 0x16) <= lStack_198) goto LAB_;
  }
  if (uStack_1c0 == 0xffffffff) goto LAB_;
  goto LAB_;
LAB_:
  uVar15 = (uint)uStack_168;
LAB_:
  lVar6 = lStack_178;
  if (*(char *)(param_3 + 1) == '\x03') {
    func_0x(lStack_178,uStack_1bc,param_3);
  }
  if (((uint)uStack_160 == *(ushort *)(param_3 + 0x3a)) || (iStack_1a4 != 0)) {
    uVar4 = *(ushort *)(param_3 + 0x16);
    uVar12 = (ulonglong)uVar4;
    uVar11 = (uint)uVar4;
    uVar17 = *(ushort *)(param_3 + 4) & 8;
    if ((uVar17 != 0) && (lVar10 = (longlong)(int)uVar11, uVar4 != 0)) {
      psVar13 = (short *)(param_3 + 0x1ffe);
      uVar14 = uVar11;
      do {
        sVar5 = *psVar13;
        psVar13 = psVar13 + -1;
        uVar11 = uVar14 - 1;
        if (sVar5 != 0) {
          uVar11 = uVar14;
        }
        lVar10 = lVar10 + -1;
        uVar14 = uVar11;
      } while (lVar10 != 0);
    }
    if ((uVar15 != uVar11) && (iStack_1a4 == 0)) {
      if ((uVar17 != 0) && (uVar4 != 0)) {
        psVar13 = (short *)(param_3 + 0x1ffe);
        uVar16 = uVar12;
        do {
          sVar5 = *psVar13;
          psVar13 = psVar13 + -1;
          uVar11 = (uint)uVar12 - 1;
          if (sVar5 != 0) {
            uVar11 = (uint)uVar12;
          }
          uVar12 = (ulonglong)uVar11;
          uVar16 = uVar16 - 1;
        } while (uVar16 != 0);
      }
      uStack_58 = (uint)*(byte *)(param_3 + 1);
      uStack_5c = (undefined4)uVar12;
      uStack_60 = uVar15;
      lVar10 = func_0x();
      uStack_1bc = *(undefined4 *)(lVar10 + 0x68);
      lVar10 = *(longlong *)(*(longlong *)(lVar6 + 0x168) + 8);
      LOCK();
      piVar2 = (int *)(lVar10 + 8);
      iStack_258 = *piVar2;
      *piVar2 = *piVar2 + 1;
      UNLOCK();
      puStack_248 = &uStack_60;
      uStack_260 = 2;
      uStack_270 = 0x22d7;
      goto LAB_;
    }
  }
  else {
    uStack_78 = (uint)*(byte *)(param_3 + 1);
    uStack_80 = (uint)uStack_160;
    uStack_7c = (uint)*(ushort *)(param_3 + 0x3a);
    lVar10 = func_0x();
    uStack_1bc = *(undefined4 *)(lVar10 + 0x68);
    lVar10 = *(longlong *)(*(longlong *)(lVar6 + 0x168) + 8);
    LOCK();
    piVar2 = (int *)(lVar10 + 8);
    iStack_258 = *piVar2;
    *piVar2 = *piVar2 + 1;
    UNLOCK();
    puStack_248 = &uStack_80;
    uStack_260 = 3;
    uStack_270 = 0x22df;
LAB_:
    iStack_258 = iStack_258 + 1;
    uStack_1b0 = 0;
    uStack_1b8 = 0;
    uStack_200 = 0;
    uStack_208 = 0;
    uStack_210 = 0;
    uStack_218 = 0;
    uStack_220 = 1;
    uStack_228 = 0;
    uStack_230 = 0;
    uStack_238 = 0;
    uStack_240 = 0;
    uStack_250 = 3;
    uStack_268 = 0x10;
    uStack_278 = 0;
    puStack_280 = &uStack_1b8;
    lStack_288 = param_4 + 0x60;
    func_0x(lVar10,&uStack_1bc,param_4 + 0x154);
    func_0x(lVar6,2,param_4 + 0x60);
  }
  if (((DAT_ & 4) != 0) ||
     (((lVar6 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar6 != 0 && (lVar6 = **(longlong **)(lVar6 + 0x38), lVar6 != 0)) &&
      (iVar9 = (*_DAT_)(lVar6,0x9d2), iVar9 != 0)))) {
    func_0x(*(undefined8 *)(param_4 + 0x88),uStack_160 & 0xffffffff);
  }
  if ((*(int *)(*(longlong *)(param_4 + 0x90) + 0x14) == 1) &&
     (*(int *)(*(longlong *)(param_4 + 0x98) + 800) != 0)) {
    func_0x(*(undefined8 *)(param_4 + 0x88),0);
  }
LAB_:
  func_0x(uStack_40 ^ (ulonglong)auStack_2a8);
  return;
}

