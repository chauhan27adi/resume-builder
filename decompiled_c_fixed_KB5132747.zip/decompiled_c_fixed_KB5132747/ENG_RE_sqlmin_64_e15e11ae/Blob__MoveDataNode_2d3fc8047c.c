
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 *param_2,undefined4 *param_3)

{
  byte *pbVar1;
  byte bVar2;
  undefined2 uVar3;
  undefined2 uVar4;
  longlong lVar5;
  ushort *puVar6;
  bool bVar7;
  undefined4 *puVar8;
  char cVar9;
  short sVar10;
  int iVar11;
  longlong lVar12;
  short *psVar13;
  undefined8 uVar14;
  ushort uVar15;
  undefined4 uVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  uint uVar19;
  longlong lVar20;
  undefined *puVar21;
  uint uVar22;
  longlong lVar23;
  uint uVar24;
  byte **ppbVar25;
  ulonglong uVar26;
  ulonglong uVar27;
  longlong *plVar28;
  int iVar29;
  byte *pbVar30;
  byte *pbVar31;
  ushort *puVar32;
  undefined8 uStack_450;
  undefined auStack_448 [32];
  undefined8 uStack_428;
  undefined uStack_420;
  longlong *plStack_418;
  undefined uStack_410;
  uint uStack_40c;
  longlong *plStack_400;
  undefined uStack_3f8;
  uint uStack_3f4;
  byte *pbStack_3e8;
  undefined4 *puStack_3e0;
  undefined8 uStack_3d8;
  undefined2 uStack_3d0;
  undefined2 auStack_3c8 [2];
  undefined4 uStack_3c4;
  undefined4 uStack_3bc;
  undefined2 uStack_3b8;
  undefined4 uStack_3b4;
  undefined2 uStack_3b0;
  undefined4 uStack_3a8;
  undefined2 uStack_3a4;
  undefined2 uStack_3a2;
  longlong lStack_3a0;
  undefined4 *puStack_398;
  undefined8 uStack_390;
  longlong lStack_388;
  undefined auStack_378 [8];
  undefined4 uStack_370;
  undefined4 uStack_368;
  longlong **pplStack_360;
  undefined *puStack_358;
  undefined8 uStack_350;
  longlong *plStack_348;
  undefined8 uStack_340;
  undefined auStack_338 [528];
  undefined8 uStack_128;
  undefined8 uStack_120;
  longlong lStack_118;
  longlong lStack_110;
  uint uStack_108;
  short sStack_f8;
  ushort uStack_f6;
  uint uStack_f4;
  byte *pbStack_f0;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  ushort uStack_dc;
  undefined2 uStack_da;
  undefined6 uStack_d8;
  undefined2 uStack_d2;
  undefined2 uStack_d0;
  ushort uStack_ce;
  ushort uStack_cc;
  undefined2 uStack_ca;
  uint uStack_c8;
  int iStack_c4;
  undefined auStack_c0 [16];
  undefined auStack_b0 [8];
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined6 uStack_98;
  undefined2 uStack_92;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined8 uStack_88;
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined auStack_60 [16];
  undefined8 uStack_50;
  ulonglong uStack_48;
  
  puVar21 = auStack_448;
  uStack_390 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&plStack_418;
  uVar16 = *param_3;
  uVar3 = *(undefined2 *)(param_3 + 1);
  uVar4 = *(undefined2 *)((longlong)param_3 + 6);
  plStack_418 = (longlong *)0x0;
  uStack_410 = 0;
  uStack_40c = 0;
  plStack_400 = (longlong *)0x0;
  uStack_3f8 = 0;
  uStack_3f4 = 0;
  sStack_f8 = -1;
  pbStack_f0 = (byte *)0x0;
  uStack_f4 = 0;
  uStack_da = 0;
  uStack_d8 = 0;
  uStack_d0 = 0;
  uStack_ce = 0;
  uStack_cc = 0;
  uStack_ca = 0;
  uStack_e8 = (byte **)0x0;
  sVar10 = *(short *)((longlong)param_3 + 6);
  pbVar31 = (byte *)(longlong)sVar10;
  uStack_3bc = *param_3;
  uStack_3b8 = *(undefined2 *)(param_3 + 1);
  uStack_450 = 0x1000f2;
  puStack_3e0 = param_2;
  lStack_3a0 = param_1;
  puStack_398 = param_3;
  lVar12 = func_0x(param_1,&plStack_418,&uStack_3bc,1);
  if (lVar12 == 0) {
    *param_2 = uVar16;
    *(undefined2 *)(param_2 + 1) = uVar3;
    *(undefined2 *)((longlong)param_2 + 6) = uVar4;
    uStack_450 = 0x10010e;
    func_0x(&plStack_400);
    puVar21 = auStack_448;
    goto LAB_;
  }
  if (*(char *)(*(longlong *)(param_1 + 0x20) + 0x1cde) != '\0') {
    uStack_3a8 = *param_3;
    uStack_3a4 = *(undefined2 *)(param_3 + 1);
    uStack_3a2 = *(undefined2 *)((longlong)param_3 + 6);
    uStack_420 = 0;
    uStack_428 = 0;
    uStack_450 = 0x100157;
    func_0x(param_1,&uStack_3a8,&plStack_418,1);
  }
  lVar12 = *plStack_418;
  if (((uint)*(ushort *)(lVar12 + 0x16) <= (uint)(int)sVar10) ||
     (pbStack_3e8 = pbVar31, *(short *)(lVar12 + (0xfff - (longlong)pbVar31) * 2) == 0)) {
    *param_2 = uVar16;
    *(undefined2 *)(param_2 + 1) = uVar3;
    *(undefined2 *)((longlong)param_2 + 6) = uVar4;
    uStack_450 = 0x101574;
    func_0x(&plStack_400);
    goto LAB_;
  }
  iStack_c4 = (int)sVar10;
  if (*(char *)(lVar12 + 2) < '\0') {
    pbVar31 = (byte *)(lVar12 + 0x60);
    if ((sStack_f8 == 0) || (ppbVar25 = uStack_e8, uStack_e8 == (byte **)0x0)) {
      uStack_98 = 0;
      uStack_8a = 0;
      auStack_70 = ZEXT816(0);
      auStack_c0 = ZEXT816(0);
      stack0xffffffffffffff52 = SUB1614(ZEXT816(0),2);
      auStack_b0._0_2_ = 0xffff;
      uStack_a8 = 0;
      uStack_92 = 0;
      uStack_90 = 0;
      uStack_88 = 0;
      uStack_a0 = 0;
      auStack_80 = ZEXT816(0);
      auStack_60._0_12_ = ZEXT812(0);
      auStack_60._12_4_ = 0;
      uStack_50 = 0;
      ppbVar25 = (byte **)auStack_c0;
    }
    if (*(short *)(lVar12 + 0x24) == 0) {
LAB_:
      uStack_3d8 = *(undefined8 *)(lVar12 + 0x28);
      uStack_3d0 = *(undefined2 *)(lVar12 + 0x30);
    }
    else {
      cVar9 = *(char *)(lVar12 + 1);
      if (cVar9 == '\v') {
        if (*(int *)(lVar12 + 0x18) != 99) {
LAB_:
          if (cVar9 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar9 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar12 + 0x18) != 99) goto LAB_;
      }
      uStack_3b4 = *(undefined4 *)(lVar12 + 0x20);
      uStack_3b0 = *(undefined2 *)(lVar12 + 0x24);
      uStack_450 = 0x1002b4;
      cVar9 = func_0x(&uStack_3b4);
      if (cVar9 == '\0') goto LAB_;
      uStack_450 = 0x1002c4;
      func_0x(lVar12,&uStack_3d8);
    }
    *ppbVar25 = pbVar31;
    *(undefined4 *)(ppbVar25 + 0xc) = (undefined4)uStack_3d8;
    *(int *)((longlong)ppbVar25 + 100) = (int)((ulonglong)uStack_3d8 >> 0x20);
    *(undefined2 *)(ppbVar25 + 0xd) = uStack_3d0;
    *(undefined4 *)((longlong)ppbVar25 + 0x6c) = *(undefined4 *)(lVar12 + 0x20);
    *(undefined2 *)(ppbVar25 + 0xe) = *(undefined2 *)(lVar12 + 0x24);
    *(undefined2 *)((longlong)ppbVar25 + 0x72) = 0;
    uStack_3c4 = *(undefined4 *)((ulonglong)*pbVar31 * 6 + 0x13671a0);
    uVar17 = (ulonglong)*(short *)((ulonglong)*pbVar31 * 6 + 0x13671a4);
    *(undefined2 *)(ppbVar25 + 2) = 0xffff;
    ppbVar25[3] = (byte *)0x0;
    uVar19 = 0;
    *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
    *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
    ppbVar25[7] = (byte *)0x0;
    ppbVar25[4] = (byte *)0x0;
    ppbVar25[9] = (byte *)0x0;
    ppbVar25[10] = (byte *)0x0;
    *(undefined2 *)(ppbVar25 + 0xb) = 0;
    if ((**ppbVar25 & 2) != 0) {
      pbVar1 = pbVar31 + uVar17;
      if ((*pbVar1 & 1) == 0) {
        *(undefined2 *)(ppbVar25 + 2) = 0;
        ppbVar25[3] = pbVar1;
        *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
        *(undefined4 *)((longlong)ppbVar25 + 0x36) = 0;
        switch(*pbVar1 & 0xe) {
        default:
          uVar19 = (uint)*(ushort *)(pbVar1 + 2);
          if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
            uStack_450 = 0x10054c;
            func_0x(pbVar1,6);
          }
          break;
        case 4:
          uVar19 = 9;
          break;
        case 6:
        case 10:
          break;
        case 0xe:
          uVar19 = 1;
        }
        *(uint *)(ppbVar25 + 4) = uVar19;
        *(undefined8 *)((longlong)ppbVar25 + 0x2e) = 0;
      }
      else {
        *(undefined2 *)(ppbVar25 + 2) = 1;
        ppbVar25[3] = pbVar1;
        bVar2 = *pbVar1;
        switch(bVar2 & 0x1c) {
        default:
          if ((char)pbVar1[1] < '\0') {
            uVar15 = *(ushort *)(pbVar1 + 1);
            *(ushort *)((longlong)ppbVar25 + 0x12) = uVar15;
            sVar10 = 3;
            uVar15 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
          }
          else {
            sVar10 = 2;
            uVar15 = (ushort)pbVar1[1];
          }
          *(ushort *)((longlong)ppbVar25 + 0x12) = uVar15;
          *(short *)(ppbVar25 + 5) = sVar10;
          uVar15 = *(ushort *)((longlong)ppbVar25 + 0x12);
          *(short *)((longlong)ppbVar25 + 0x2c) = (short)(uVar15 + 1 >> 1) + sVar10;
          if (uVar15 < 0x1f) {
            *(undefined2 *)((longlong)ppbVar25 + 0x2a) = 0;
            *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
            *(undefined4 *)(ppbVar25 + 8) = 0;
            ppbVar25[7] = (byte *)0x0;
            ppbVar25[4] = (byte *)0x0;
          }
          else {
            iVar29 = uVar15 - 1;
            *(short *)((longlong)ppbVar25 + 0x2a) =
                 ((short)(iVar29 / 0x1e) + (short)(iVar29 >> 0x1f)) -
                 (short)((longlong)iVar29 * 0x88888889 >> 0x3f);
            *(undefined4 *)((longlong)ppbVar25 + 0x14) = 0;
            *(undefined4 *)(ppbVar25 + 8) = 0;
            ppbVar25[7] = (byte *)0x0;
            ppbVar25[4] = (byte *)0x0;
          }
          break;
        case 4:
          if (((bVar2 & 0x1c) != 4) || (uVar22 = 1, (bVar2 & 2) == 0)) {
            uVar22 = uVar19;
          }
          if (uVar22 == 0) {
            uVar16 = 1;
          }
          else {
            *(undefined4 *)(ppbVar25 + 8) = 0;
            uVar16 = 0xf;
          }
          ppbVar25[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar25 + 0x12) = 0;
          ppbVar25[6] = (byte *)0x0;
          ppbVar25[4] = (byte *)0x0;
          ppbVar25[7] = (byte *)0x0;
          ppbVar25[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar25 + 0x14) = uVar16;
          *(uint *)(ppbVar25 + 8) = (uint)(uVar22 != 0);
          ppbVar25[7] = (byte *)0x0;
          ppbVar25[4] = (byte *)0x0;
          break;
        case 8:
          ppbVar25[5] = (byte *)0x0;
          *(undefined2 *)((longlong)ppbVar25 + 0x12) = 0;
          ppbVar25[6] = (byte *)0x0;
          ppbVar25[4] = (byte *)0x0;
          ppbVar25[7] = (byte *)0x0;
          ppbVar25[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar25 + 0x14) = 9;
          *(undefined4 *)(ppbVar25 + 8) = 0;
          ppbVar25[7] = (byte *)0x0;
          ppbVar25[4] = (byte *)0x0;
        }
      }
    }
    if ((**ppbVar25 & 4) != 0) {
      if (uStack_3c4._2_2_ != 0) {
        uVar17 = (ulonglong)*(ushort *)(lVar12 + 0x61 + (longlong)uStack_3c4._2_2_ * 2);
      }
      psVar13 = (short *)(pbVar31 + uVar17);
      ppbVar25[9] = (byte *)psVar13;
      sVar10 = *psVar13;
      ppbVar25[10] = (byte *)(psVar13 + 1);
      *(short *)(ppbVar25 + 0xb) = (sVar10 + 1) * 2;
    }
    param_2 = puStack_3e0;
    if (ppbVar25[1] != (byte *)0x0) {
      uStack_450 = 0x1005de;
      func_0x(ppbVar25[1],ppbVar25);
      param_2 = puStack_3e0;
    }
  }
  else {
    ppbVar25 = (byte **)0x0;
  }
  uVar19 = 9;
  pbStack_f0 = (byte *)((ulonglong)*(ushort *)(lVar12 + (0xfff - (longlong)pbStack_3e8) * 2) +
                       lVar12);
  if ((*pbStack_f0 & 1) == 0) {
    sStack_f8 = 0;
    uStack_f4 = 0;
    uStack_d2 = 0;
    uStack_d0 = 0;
    uVar22 = (uint)*(ushort *)(lVar12 + 0xe);
    switch(*pbStack_f0 & 0xe) {
    default:
      uVar15 = *(ushort *)(pbStack_f0 + 2);
      uVar22 = (uint)uVar15;
      if (0x1f9d < uVar15 - 1) {
        uStack_450 = 0x1008b4;
        func_0x(pbStack_f0,6);
      }
      break;
    case 4:
      uVar22 = uVar19;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar22 = 1;
    }
    uStack_e8 = (byte **)CONCAT44(uStack_e8._4_4_,uVar22);
    uStack_da = (undefined2)(lVar12 + 0x2000);
    uStack_d8 = (undefined6)((ulonglong)(lVar12 + 0x2000) >> 0x10);
    ppbVar25 = (byte **)(ulonglong)uVar22;
  }
  else {
    sStack_f8 = 1;
    bVar2 = *pbStack_f0;
    uStack_e8 = ppbVar25;
    switch(bVar2 & 0x1c) {
    default:
      if ((char)pbStack_f0[1] < '\0') {
        uStack_f6 = (*(ushort *)(pbStack_f0 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_f0 + 1) >> 8;
        uStack_e0._0_2_ = 3;
        sVar10 = 3;
      }
      else {
        uStack_f6 = (ushort)pbStack_f0[1];
        uStack_e0._0_2_ = 2;
        sVar10 = 2;
      }
      uStack_dc = (short)(uStack_f6 + 1 >> 1) + sVar10;
      if (uStack_f6 < 0x1f) {
        uStack_e0._2_2_ = 0;
        uStack_f4 = 0;
        uStack_c8 = 0;
        lVar12 = lVar12 + 0x2000;
        uStack_d0 = (undefined2)lVar12;
        uStack_ce = (ushort)((ulonglong)lVar12 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
      }
      else {
        iVar29 = uStack_f6 - 1;
        uStack_e0._2_2_ =
             ((short)(iVar29 / 0x1e) + (short)(iVar29 >> 0x1f)) -
             (short)((longlong)iVar29 * 0x88888889 >> 0x3f);
        uStack_f4 = 0;
        uStack_c8 = 0;
        lVar12 = lVar12 + 0x2000;
        uStack_d0 = (undefined2)lVar12;
        uStack_ce = (ushort)((ulonglong)lVar12 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
      }
      break;
    case 4:
      if (((bVar2 & 0x1c) == 4) && ((bVar2 & 2) != 0)) {
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_da = 0;
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_f4 = 0xf;
        uStack_c8 = 1;
        lVar12 = lVar12 + 0x2000;
        uStack_d0 = (undefined2)lVar12;
        uStack_ce = (ushort)((ulonglong)lVar12 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
      }
      else {
        uStack_e0._0_2_ = 0;
        uStack_e0._2_2_ = 0;
        uStack_dc = 0;
        uStack_da = 0;
        uStack_f6 = 0;
        uStack_d8 = 0;
        uStack_d2 = 0;
        uStack_f4 = 1;
        uStack_c8 = 0;
        lVar12 = lVar12 + 0x2000;
        uStack_d0 = (undefined2)lVar12;
        uStack_ce = (ushort)((ulonglong)lVar12 >> 0x10);
        uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
        uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
      }
      break;
    case 8:
      uStack_e0._0_2_ = 0;
      uStack_e0._2_2_ = 0;
      uStack_dc = 0;
      uStack_da = 0;
      uStack_f6 = 0;
      uStack_d8 = 0;
      uStack_d2 = 0;
      uStack_f4 = 9;
      uStack_c8 = 0;
      lVar12 = lVar12 + 0x2000;
      uStack_d0 = (undefined2)lVar12;
      uStack_ce = (ushort)((ulonglong)lVar12 >> 0x10);
      uStack_cc = (ushort)((ulonglong)lVar12 >> 0x20);
      uStack_ca = (undefined2)((ulonglong)lVar12 >> 0x30);
    }
  }
  pbStack_3e8 = pbStack_f0;
  if (sStack_f8 == 0) {
    pbVar31 = pbStack_f0;
    uVar19 = uStack_f4;
    if (uStack_f4 == 0) {
      uStack_f6 = 0;
      uVar19 = (uint)ppbVar25;
      uVar17 = (ulonglong)ppbVar25 & 0xffffffff;
      if ((*pbStack_f0 & 0x10) != 0) {
        uVar19 = uVar19 + 2 +
                 (*(ushort *)(pbStack_f0 + ((ulonglong)ppbVar25 & 0xffffffff)) + 7 >> 3);
        uVar17 = (ulonglong)uVar19;
      }
      uStack_e8 = (byte **)CONCAT44(uVar19,(undefined4)uStack_e8);
      if ((*pbStack_f0 & 0x20) == 0) {
        uStack_dc = 0;
        uStack_f4 = (uint)uVar17;
        uStack_e0 = (uint)uVar17;
      }
      else {
        puVar32 = (ushort *)(pbStack_f0 + uVar17);
        uStack_dc = *puVar32;
        if (uStack_dc == 0) {
          uStack_450 = 0x100990;
          cVar9 = func_0x(0x1c7d950);
          if (cVar9 != '\0') {
            uStack_450 = 0x100999;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              uStack_450 = 0x1009b3;
              cVar9 = func_0x(0x1c7d950);
              if (cVar9 == '\0') {
                uStack_450 = 0x1009cf;
                (*pcRam00000000011eb4d8)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_428 = 0;
                uStack_450 = 0x100a16;
                (*pcRam00000000011eb4d0)(1,0x156d35c,0x168d448,0x80f);
              }
            }
          }
          uStack_450 = 0x1009e2;
          func_0x(pbStack_f0,3);
        }
        uStack_e0 = uStack_e8._4_4_ + 2 + (uint)uStack_dc * 2;
        if (0x1f9e < uStack_e0) {
          uStack_450 = 0x100a4b;
          cVar9 = func_0x(0x1c7d950);
          if (cVar9 != '\0') {
            uStack_450 = 0x100a54;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              uStack_450 = 0x100a6e;
              cVar9 = func_0x(0x1c7d950);
              if (cVar9 == '\0') {
                uStack_450 = 0x100a8a;
                (*pcRam00000000011eb4d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_428 = 0;
                uStack_450 = 0x100aae;
                (*pcRam00000000011eb4d0)(1,0x156d35c,0x168d448,0x816);
              }
            }
          }
          uStack_450 = 0x100abf;
          func_0x(pbStack_f0,4);
        }
        uVar18 = (ulonglong)uStack_dc;
        uStack_f4 = puVar32[uVar18] & 0x7fff;
        if (uStack_f4 < uStack_e0) {
          uStack_450 = 0x100afd;
          cVar9 = func_0x(0x1c7d950);
          if (cVar9 != '\0') {
            uStack_450 = 0x100b06;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              uStack_450 = 0x100b20;
              cVar9 = func_0x(0x1c7d950);
              if (cVar9 == '\0') {
                uStack_450 = 0x100b3c;
                (*pcRam00000000011eb4d8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_428 = 0;
                uStack_450 = 0x100b60;
                (*pcRam00000000011eb4d0)(1,0x156d35c,0x168d448,0x81d);
              }
            }
          }
          uStack_450 = 0x100b71;
          func_0x(pbStack_f0,4);
          uVar18 = (ulonglong)uStack_dc;
        }
        uVar27 = (ulonglong)uStack_e0;
        uVar17 = (ulonglong)uStack_f4;
        iVar29 = 0;
        pbVar31 = pbStack_f0;
        puVar6 = puVar32;
        if ((short)uVar18 != 0) {
          do {
            uVar19 = puVar6[1] & 0x7fff;
            if ((uVar19 < (uint)uVar27) || ((uint)uVar17 < uVar19)) {
              uStack_450 = 0x100bd2;
              cVar9 = func_0x(0x1c7d950);
              if (cVar9 != '\0') {
                uStack_450 = 0x100bdb;
                lVar12 = func_0x();
                if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                  uStack_450 = 0x100bf5;
                  cVar9 = func_0x(0x1c7d950);
                  if (cVar9 == '\0') {
                    uStack_450 = 0x100c11;
                    (*pcRam00000000011eb4d8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_428 = 0;
                    uStack_450 = 0x100c35;
                    (*pcRam00000000011eb4d0)(1,0x156d35c,0x168d448,0x82a);
                  }
                }
              }
              uStack_450 = 0x100c46;
              func_0x(pbStack_f0,4);
              uVar18 = (ulonglong)uStack_dc;
              uVar17 = (ulonglong)uStack_f4;
              pbVar31 = pbStack_f0;
            }
            uVar27 = (ulonglong)uVar19;
            iVar29 = iVar29 + 1;
            puVar6 = puVar6 + 1;
          } while (iVar29 < (int)uVar18);
          uVar27 = (ulonglong)uStack_e0;
          param_2 = puStack_3e0;
        }
        while( true ) {
          if (-1 < (short)puVar32[(ulonglong)((int)uVar18 - 1) + 1]) break;
          uVar26 = uVar27;
          if ((int)uVar18 != 1) {
            uVar26 = (ulonglong)
                     (*(ushort *)(pbVar31 + uVar18 * 2 + (((ulonglong)uStack_e8 >> 0x20) - 2)) &
                     0x7fff);
          }
          uVar22 = *(ushort *)(pbVar31 + uVar18 * 2 + ((ulonglong)uStack_e8 >> 0x20)) & 0x7fff;
          uVar24 = (uint)uVar26;
          if (((uVar24 < (uint)uVar27) || (uVar22 < uVar24)) ||
             (uVar15 = (ushort)uVar18, (uint)uVar17 < uVar22)) {
            uStack_450 = 0x100cea;
            func_0x(pbVar31,7);
            uVar27 = (ulonglong)uStack_e0;
            uVar17 = (ulonglong)uStack_f4;
            pbVar31 = pbStack_f0;
            uVar15 = uStack_dc;
          }
          uVar19 = (uint)uVar17;
          if ((uVar24 < (uint)uVar27) || (uVar19 < uVar24)) goto code_r0x0010109f;
          if (*(ushort *)(pbVar31 + uVar26) == 5) {
            uStack_f6 = uStack_f6 | 2;
            uStack_dc = uVar15 - 1;
            uStack_ce = (ushort)uVar26;
            uVar26 = uVar26 & 0xffff;
            pbVar1 = pbVar31 + uVar26;
            if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
              uVar15 = uStack_cc & 0xc7ff;
            }
            else {
              uVar15 = uStack_cc ^ (uStack_cc ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
            }
            uStack_cc = (uVar15 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar15;
            pbVar30 = pbVar31 + (ulonglong)((uStack_cc & 0x7ff) * 2) + 4 +
                                (uVar15 >> 0xb & 7) * 2 + uVar26;
            if (pbVar30 < pbVar1) {
              uStack_450 = 0x100e01;
              func_0x(pbVar1,0x19);
              uVar26 = (ulonglong)uStack_ce;
              uVar17 = (ulonglong)uStack_f4;
              pbVar31 = pbStack_f0;
            }
            if (uVar22 - uVar24 <
                (((uStack_cc & 0x7ff) * 2 - (int)uVar26) - (int)pbStack_f0) + (int)pbVar30) {
              uStack_450 = 0x100e4d;
              func_0x(pbVar31 + uVar26,0x19);
              uVar26 = (ulonglong)uStack_ce;
              uVar17 = (ulonglong)uStack_f4;
              pbVar31 = pbStack_f0;
            }
            if ((uStack_cc & 0x3800) != 0) {
              puVar32 = (ushort *)(pbVar31 + uVar26 + 4);
              iVar29 = 0;
              uVar15 = uStack_cc;
              if ((uStack_cc & 0x3800) != 0) {
                do {
                  if ((uVar15 & 0x7ff) < (*puVar32 & 0x7ff)) {
                    uStack_450 = 0x100eb5;
                    func_0x(pbVar31 + uVar26,0x1a);
                    uVar26 = (ulonglong)uStack_ce;
                    pbVar31 = pbStack_f0;
                    uVar15 = uStack_cc;
                  }
                  iVar29 = iVar29 + 1;
                  puVar32 = puVar32 + 1;
                } while (iVar29 < (int)((uStack_cc & 0x3800) >> 0xb));
                uVar17 = (ulonglong)uStack_f4;
              }
            }
            break;
          }
          if (*(ushort *)(pbVar31 + uVar26) < 0x400) break;
          uStack_f6 = uStack_f6 | 1;
          uStack_dc = uVar15 - 1;
          uVar18 = (ulonglong)uStack_dc;
          if (uStack_dc == 0) break;
        }
      }
      if ((*pbVar31 & 0x40) == 0) {
        uStack_d2 = 0;
        uStack_d0 = 0;
      }
      else {
        uStack_d2 = (undefined2)uVar17;
        uStack_d0 = (undefined2)(uVar17 >> 0x10);
        uStack_f4 = (int)uVar17 + 0xe;
        uStack_450 = 0x100f22;
        uVar14 = func_0x(&uStack_f6);
        uStack_450 = 0x100f2e;
        func_0x(uVar14,&pbStack_3e8);
        uStack_450 = 0x100f37;
        iVar29 = func_0x(&pbStack_3e8);
        uStack_f4 = uStack_f4 + iVar29;
        uVar17 = (ulonglong)uStack_f4;
        pbVar31 = pbStack_f0;
      }
      uVar19 = (uint)uVar17;
      if (((byte *)CONCAT62(uStack_d8,uStack_da) != (byte *)0x0) &&
         ((byte *)CONCAT62(uStack_d8,uStack_da) < pbVar31 + uVar17)) {
        uStack_450 = 0x100f7f;
        cVar9 = func_0x(0x1c7d950);
        if (cVar9 != '\0') {
          uStack_450 = 0x100f88;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            uStack_450 = 0x100fa2;
            cVar9 = func_0x(0x1c7d950);
            if (cVar9 == '\0') {
              uStack_450 = 0x100fbe;
              (*pcRam00000000011eb4d8)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_428 = 0;
              uStack_450 = 0x100fe4;
              (*pcRam00000000011eb4d0)(1,0x156d35c,0x168d448,0x886);
            }
          }
        }
        uStack_450 = 0x100ff5;
        func_0x(pbStack_f0,0x12);
        pbVar31 = pbStack_f0;
        uVar19 = uStack_f4;
      }
      if (0x3f3b < uVar19 - 1) {
        uStack_450 = 0x10101c;
        cVar9 = func_0x(0x1c7d950);
        if (cVar9 != '\0') {
          uStack_450 = 0x101025;
          lVar12 = func_0x();
          if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
            uStack_450 = 0x10103f;
            cVar9 = func_0x(0x1c7d950);
            if (cVar9 == '\0') {
              uStack_450 = 0x10105b;
              (*pcRam00000000011eb4d8)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_428 = 0;
              uStack_450 = 0x101081;
              (*pcRam00000000011eb4d0)(1,0x156d35c,0x168d448,0x88b);
            }
          }
        }
        uStack_450 = 0x101092;
        func_0x(pbStack_f0,5);
        pbVar31 = pbStack_f0;
        uVar19 = uStack_f4;
      }
    }
code_r0x0010109f:
    if ((uVar19 < 9) && (((*pbVar31 & 0xe) == 0 || ((*pbVar31 & 0xe) == 0xc)))) {
      uVar22 = CONCAT22(uStack_d0,uStack_d2);
      if ((*pbVar31 & 0x40) == 0) {
        uVar22 = 9;
      }
    }
    else {
      uVar22 = CONCAT22(uStack_d0,uStack_d2);
      if ((*pbVar31 & 0x40) == 0) {
        uVar22 = uVar19;
      }
    }
  }
  else {
    if (uStack_f4 == 0) {
      uStack_450 = 0x1010e5;
      func_0x(&uStack_f6);
      if (uStack_f4 == 0) {
        uStack_450 = 0x1010fb;
        func_0x(&uStack_f6);
      }
    }
    if ((8 < uStack_f4) || (((*pbStack_f0 & 0x1c) != 0 && ((*pbStack_f0 & 0x1c) != 0xc)))) {
      uVar19 = uStack_f4;
    }
    uVar22 = uStack_c8;
    uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
    if ((*pbStack_f0 & 2) == 0) {
      uVar22 = uVar19;
      uStack_e0 = CONCAT22(uStack_e0._2_2_,(undefined2)uStack_e0);
    }
  }
  uStack_450 = 0x101153;
  lVar12 = func_0x();
  lVar12 = -lVar12;
  puVar21 = auStack_448 + lVar12;
  lVar23 = (longlong)(int)(uVar22 - 0xe);
  *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x10116e;
  func_0x((longlong)&plStack_418 + lVar12);
  plVar28 = plStack_418;
  if (plStack_418 != (longlong *)0x0) {
    iVar29 = (int)(short)uStack_40c;
    if (((*(ushort *)((longlong)plStack_418 + 0x62) >> 10 & 1) == 0) || (iVar29 < 3)) {
      if (((byte)*(undefined2 *)((longlong)plStack_418 + 0x62) >> 3 & 1) != 0) {
        if (iVar29 == 3) {
          iVar29 = 4;
        }
        else if (iVar29 < 2) goto code_r0x00101256;
        if ((((*(uint *)((longlong)plStack_418 + 100) & 8) != 0) &&
            (lVar20 = plStack_418[0x12], lVar20 != 0)) && (*(longlong *)(lVar20 + 0x758) != 0)) {
          uVar14 = *(undefined8 *)(lVar20 + 0x758);
          *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x101256;
          func_0x(uVar14,plVar28,iVar29);
        }
      }
code_r0x00101256:
      if ((((bRam0000000001c89ff5 & 0x80) != 0) && ((*(uint *)((longlong)plVar28 + 100) & 8) != 0))
         && ((2 < iVar29 &&
             (((*(uint *)((longlong)plVar28 + 100) & 0xc0000000) != 0x40000000 &&
              (lVar20 = *plVar28, lVar20 != 0)))))) {
        *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x101297;
        iVar11 = (*pcRam00000000011e85b8)(lVar20,0x2000,2,&puStack_3e0);
        if (iVar11 != 0) {
          LOCK();
          *(uint *)((longlong)plVar28 + 100) = *(uint *)((longlong)plVar28 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar28 + 100) = *(uint *)((longlong)plVar28 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x1012b9;
      func_0x(plVar28 + 0x13,iVar29);
      if ((iRam0000000001c90230 != 0) && ((bRam0000000001c8a15f & 2) != 0)) {
        *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x1012d8;
        func_0x(plVar28,0,iVar29);
      }
      uStack_40c = uStack_40c & 0xffff0000;
      plStack_418 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x101194;
      func_0x(&plStack_418);
    }
  }
  *(undefined4 *)(&uStack_420 + lVar12) = 2;
  *(uint *)(&uStack_420 + lVar12 + -8) = uVar22 - 0xe;
  lVar20 = lStack_3a0;
  *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x1011bb;
  func_0x(lVar20,&plStack_400,auStack_3c8,(longlong)&plStack_418 + lVar12);
  plVar28 = plStack_400;
  uVar16 = *(undefined4 *)(*plStack_400 + 0x20);
  uVar3 = *(undefined2 *)(*plStack_400 + 0x24);
  iVar29 = (int)(short)uStack_3f4;
  if (((*(ushort *)((longlong)plStack_400 + 0x62) >> 10 & 1) == 0) || (iVar29 < 3)) {
    if (((byte)*(undefined2 *)((longlong)plStack_400 + 0x62) >> 3 & 1) != 0) {
      if (iVar29 == 3) {
        iVar29 = 4;
      }
      else if (iVar29 < 2) goto code_r0x00101346;
      if ((((*(uint *)((longlong)plStack_400 + 100) & 8) != 0) &&
          (lVar20 = plStack_400[0x12], lVar20 != 0)) && (*(longlong *)(lVar20 + 0x758) != 0)) {
        uVar14 = *(undefined8 *)(lVar20 + 0x758);
        *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x101346;
        func_0x(uVar14,plVar28,iVar29);
      }
    }
code_r0x00101346:
    if ((((bRam0000000001c89ff5 & 0x80) != 0) && ((*(uint *)((longlong)plVar28 + 100) & 8) != 0)) &&
       ((2 < iVar29 &&
        (((*(uint *)((longlong)plVar28 + 100) & 0xc0000000) != 0x40000000 &&
         (lVar20 = *plVar28, lVar20 != 0)))))) {
      *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x101387;
      iVar11 = (*pcRam00000000011e85b8)(lVar20,0x2000,2,&uStack_3c4);
      if (iVar11 != 0) {
        LOCK();
        *(uint *)((longlong)plVar28 + 100) = *(uint *)((longlong)plVar28 + 100) & 0x3fffffff;
        UNLOCK();
        LOCK();
        *(uint *)((longlong)plVar28 + 100) = *(uint *)((longlong)plVar28 + 100) | 0x40000000;
        UNLOCK();
      }
    }
    *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x1013a9;
    func_0x(plVar28 + 0x13,iVar29);
    if ((iRam0000000001c90230 != 0) && ((bRam0000000001c8a15f & 2) != 0)) {
      *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x1013c8;
      func_0x(plVar28,0,iVar29);
    }
    uStack_3f4 = uStack_3f4 & 0xffff0000;
    plStack_400 = (longlong *)0x0;
    lVar20 = lStack_3a0;
  }
  else {
    *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x1011f5;
    func_0x(&plStack_400);
  }
  puVar8 = puStack_398;
  *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x1013ee;
  func_0x(lVar20,puVar8,0,0);
  if (*pcRam00000000011eacb0 != '\0') {
    uVar15 = *(ushort *)(*(longlong *)(lVar20 + 0x20) + 0x6b8);
    bVar7 = false;
    lVar5 = *(longlong *)((ulonglong)(uVar15 >> 8) * 8 + 0x1c9a090);
    if (((lVar5 != 0) &&
        (plVar28 = (longlong *)(lVar5 + ((ulonglong)(uVar15 & 0xff) + 0x500) * 8),
        plVar28 != (longlong *)0x0)) && (*plVar28 != 0)) {
      LOCK();
      plVar28 = (longlong *)(*plVar28 + 0x150);
      lStack_388 = *plVar28;
      *plVar28 = *plVar28 + lVar23;
      UNLOCK();
      lStack_388 = lStack_388 + lVar23;
      if ((bRam0000000001c9a890 & 0x20) != 0) {
        plVar28 = (longlong *)0x0;
        if (lRam0000000001c9a090 != 0) {
          plVar28 = (longlong *)(lRam0000000001c9a090 + 0x2800);
        }
        if ((plVar28 != (longlong *)0x0) && (*plVar28 != 0)) {
          LOCK();
          plVar28 = (longlong *)(*plVar28 + 0x150);
          *plVar28 = *plVar28 + lVar23;
          UNLOCK();
        }
      }
      bVar7 = true;
    }
    if (((uRam0000000001c8ec14 & 0x20000) != 0) && (bVar7)) {
      uStack_370 = 0x10000;
      uStack_368 = 0;
      pplStack_360 = &plStack_348;
      puStack_358 = auStack_338;
      uStack_128 = 0;
      uStack_350 = 0;
      uStack_120 = 0;
      plStack_348 = &lStack_118;
      uStack_340 = 0x14;
      uStack_108 = (uint)*(ushort *)(*(longlong *)(lVar20 + 0x20) + 0x6b8);
      lStack_118 = lStack_388;
      lStack_110 = lVar23;
      *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x101543;
      func_0x(auStack_378);
    }
  }
  *param_2 = uVar16;
  *(undefined2 *)(param_2 + 1) = uVar3;
  *(undefined2 *)((longlong)param_2 + 6) = auStack_3c8[0];
  *(undefined8 *)(auStack_448 + lVar12 + -8) = 0x10155a;
  func_0x(&plStack_400);
LAB_:
  *(undefined8 *)(puVar21 + -8) = 0x10157e;
  func_0x(&plStack_418);
  uVar17 = uStack_48 ^ (ulonglong)&plStack_418;
  *(undefined8 *)(puVar21 + -8) = 0x101590;
  func_0x(uVar17);
  return;
}

