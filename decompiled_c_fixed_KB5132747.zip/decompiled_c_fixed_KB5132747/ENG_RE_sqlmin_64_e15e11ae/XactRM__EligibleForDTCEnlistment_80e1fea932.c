
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(longlong param_1,longlong param_2)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  ulonglong uVar4;
  longlong unaff_GS_OFFSET;
  
  cVar2 = (**(code **)(**(longlong **)(param_1 + 0x290) + 0x3b0))();
  if ((cVar2 == '\0') && (*(int *)(*(longlong *)(param_2 + 0x2a8) + 0x15c) != 2)) {
    iVar3 = (**(code **)(**(longlong **)(param_1 + 0x290) + 400))();
    if (iVar3 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((DAT_ & 0x20) == 0) {
      uVar4 = (ulonglong)*_DAT_;
      lVar1 = *(longlong *)
               (uVar4 + *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
      if ((lVar1 != 0) && (uVar4 = **(ulonglong **)(lVar1 + 0x38), uVar4 != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      cVar2 = func_0x(uVar4,param_2);
      if (cVar2 != '\0') {
        return 1;
      }
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

