
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,int *param_2,ulonglong param_3,undefined8 param_4)

{
  byte *pbVar1;
  byte *pbVar2;
  byte bVar3;
  longlong *plVar4;
  undefined8 uVar5;
  code *pcVar6;
  uint **ppuVar7;
  char cVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  undefined4 uVar12;
  longlong lVar13;
  longlong *plVar14;
  longlong lVar15;
  longlong lVar16;
  uint *puVar17;
  ulonglong uVar18;
  short *psVar19;
  longlong *plVar20;
  ushort uVar21;
  short sVar22;
  uint uVar23;
  undefined8 unaff_RBX;
  byte **ppbVar24;
  longlong lVar25;
  longlong lVar26;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  short asStackX_10 [4];
  longlong *plStackX_18;
  undefined auStackX_20 [4];
  uint uStackX_24;
  int iStack_1348;
  int iStack_1344;
  undefined4 uStack_1340;
  undefined2 uStack_133c;
  undefined2 uStack_1338;
  ushort uStack_1336;
  undefined4 uStack_1334;
  byte *pbStack_1330;
  undefined8 uStack_1328;
  uint uStack_1320;
  short sStack_131c;
  undefined8 uStack_131a;
  undefined2 uStack_1312;
  undefined2 uStack_1310;
  undefined6 uStack_130e;
  undefined4 uStack_1308;
  uint uStack_1300;
  uint uStack_12fc;
  int *piStack_12f8;
  undefined8 uStack_12f0;
  ushort uStack_12e8;
  undefined8 uStack_12e0;
  ushort uStack_12d8;
  undefined8 uStack_12d0;
  ushort uStack_12c8;
  undefined8 uStack_12c0;
  ushort uStack_12b8;
  undefined auStack_12b0 [4];
  undefined4 uStack_12ac;
  undefined4 uStack_12a8;
  undefined2 uStack_12a4;
  undefined4 uStack_12a2;
  undefined2 uStack_129e;
  undefined4 uStack_129c;
  undefined2 uStack_1298;
  undefined4 uStack_1294;
  undefined2 uStack_1290;
  undefined4 uStack_128c;
  undefined2 uStack_1288;
  undefined4 uStack_1284;
  undefined2 uStack_1280;
  undefined4 uStack_127c;
  undefined2 uStack_1278;
  undefined4 uStack_1274;
  undefined2 uStack_1270;
  undefined4 uStack_126c;
  undefined2 uStack_1268;
  longlong *plStack_1260;
  undefined8 uStack_1258;
  undefined2 uStack_1250;
  undefined8 uStack_1248;
  undefined2 uStack_1240;
  undefined8 uStack_1238;
  undefined2 uStack_1230;
  undefined auStack_1228 [8];
  undefined8 uStack_1220;
  undefined2 uStack_1218;
  longlong lStack_1210;
  undefined8 uStack_1208;
  undefined2 uStack_1200;
  undefined8 uStack_11f8;
  ushort uStack_11f0;
  undefined8 uStack_11e8;
  undefined2 uStack_11e0;
  undefined8 uStack_11d8;
  ushort uStack_11d0;
  undefined auStack_11c8 [4];
  undefined auStack_11c4 [4];
  undefined auStack_11c0 [4];
  undefined auStack_11bc [4];
  undefined auStack_11b8 [4];
  undefined auStack_11b4 [4];
  uint uStack_11b0;
  undefined8 uStack_11ac;
  uint uStack_1198;
  undefined8 uStack_1194;
  undefined auStack_1180 [8];
  undefined8 uStack_1178;
  undefined auStack_1168 [8];
  undefined4 uStack_1160;
  undefined4 uStack_1158;
  uint **ppuStack_1150;
  undefined *puStack_1148;
  undefined8 uStack_1140;
  uint *puStack_1138;
  undefined4 uStack_1130;
  undefined4 uStack_112c;
  longlong lStack_1128;
  undefined4 uStack_1120;
  undefined4 uStack_111c;
  longlong lStack_1118;
  undefined4 uStack_1110;
  undefined4 uStack_110c;
  short *psStack_1108;
  int iStack_1100;
  undefined4 uStack_10fc;
  short *psStack_10f8;
  int iStack_10f0;
  undefined4 uStack_10ec;
  undefined8 uStack_10e8;
  undefined4 uStack_10e0;
  undefined4 uStack_10dc;
  undefined auStack_10d8 [448];
  undefined8 uStack_f18;
  undefined8 uStack_f10;
  uint uStack_f08;
  undefined2 uStack_f04;
  int iStack_f02;
  undefined uStack_efe;
  undefined uStack_efd;
  undefined auStack_ec8 [8];
  undefined4 uStack_ec0;
  undefined4 uStack_eb8;
  uint **ppuStack_eb0;
  undefined *puStack_ea8;
  undefined8 uStack_ea0;
  uint *puStack_e98;
  undefined4 uStack_e90;
  undefined4 uStack_e8c;
  longlong lStack_e88;
  undefined4 uStack_e80;
  undefined4 uStack_e7c;
  longlong lStack_e78;
  undefined4 uStack_e70;
  undefined4 uStack_e6c;
  short *psStack_e68;
  int iStack_e60;
  undefined4 uStack_e5c;
  short *psStack_e58;
  int iStack_e50;
  undefined4 uStack_e4c;
  undefined8 uStack_e48;
  undefined4 uStack_e40;
  undefined4 uStack_e3c;
  undefined auStack_e38 [448];
  undefined8 uStack_c78;
  undefined8 uStack_c70;
  uint uStack_c68;
  undefined2 uStack_c64;
  int iStack_c62;
  undefined uStack_c5e;
  undefined uStack_c5d;
  int iStack_c28;
  int iStack_c24;
  short sStack_c20;
  short sStack_c18;
  ushort uStack_c16;
  undefined4 uStack_c14;
  byte *pbStack_c10;
  undefined8 uStack_c08;
  undefined2 uStack_c00;
  short sStack_bfe;
  short sStack_bfc;
  undefined2 uStack_bfa;
  undefined6 uStack_bf8;
  undefined2 uStack_bf2;
  undefined2 uStack_bf0;
  undefined6 uStack_bee;
  undefined4 uStack_be8;
  int iStack_be4;
  undefined auStack_be0 [16];
  undefined auStack_bd0 [8];
  undefined8 uStack_bc8;
  undefined8 uStack_bc0;
  undefined6 uStack_bb8;
  undefined2 uStack_bb2;
  undefined6 uStack_bb0;
  undefined2 uStack_baa;
  undefined8 uStack_ba8;
  undefined auStack_ba0 [16];
  undefined auStack_b90 [16];
  undefined auStack_b80 [16];
  undefined8 uStack_b70;
  short asStack_b68 [24];
  short asStack_b38 [24];
  short asStack_b08 [24];
  short asStack_ad8 [24];
  undefined auStack_aa8 [2656];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  uStack_1178 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000013a8 + lVar13) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar13);
  *(undefined8 *)(&stack0x00000040 + lVar13) = param_4;
  *(char *)((longlong)asStackX_10 + lVar13) = (char)param_3;
  iStack_1348 = *(int *)(param_1 + 0x1b);
  lVar15 = 0;
  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
  piStack_12f8 = param_2;
  plStack_1260 = param_1;
  auStackX_20[lVar13 + -0x20] = 0;
  uVar23 = *(uint *)((longlong)&uStackX_24 + lVar13 + -0x20);
  *(uint *)((longlong)&uStackX_24 + lVar13 + -0x20) = uVar23 & 0xffff0000;
  *(uint *)((longlong)&uStackX_24 + lVar13 + -0x20) = uVar23 & 0xff000000;
  *(undefined4 *)((longlong)&uStackX_24 + lVar13 + -0x20) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1000a9;
  func_0x(auStack_aa8,0,0xa58);
  sStack_c18 = -1;
  pbStack_c10 = (byte *)0x0;
  uStack_c14 = 0;
  uStack_bfa = 0;
  uStack_bf8 = 0;
  uStack_bf0 = 0;
  uStack_bee = 0;
  uStack_c08 = (byte **)0x0;
  iStack_be4 = -1;
  uStack_1338 = 0xffff;
  pbStack_1330 = (byte *)0x0;
  uStack_1334 = 0;
  uStack_131a = 0;
  uStack_1310 = 0;
  uStack_130e = 0;
  uStack_1328 = 0;
  lStack_1210 = param_1[5];
  if ((*param_2 == 0) && (*(short *)(param_2 + 1) == 0)) {
    *(undefined8 *)((longlong)&plStackX_18 + lVar13) = 0;
    auStackX_20[lVar13] = 0;
    uVar23 = *(uint *)((longlong)&uStackX_24 + lVar13);
    *(uint *)((longlong)&uStackX_24 + lVar13) = uVar23 & 0xffff0000;
    *(uint *)((longlong)&uStackX_24 + lVar13) = uVar23 & 0xff000000;
    *(undefined4 *)((longlong)&uStackX_24 + lVar13) = 0;
    uStack_12a8 = 0;
    uStack_12a4 = 0;
    uStack_12a2 = 0;
    uStack_129e = 0;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar13) = param_4;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0xfffffffffffffff8 + lVar13;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100171;
    func_0x(param_1,param_3 & 0xff,&uStack_12a2,&uStack_12a8);
    lVar16 = **(longlong **)(&stack0xfffffffffffffff8 + lVar13);
    *(longlong *)(&stack0x00000040 + lVar13) = lVar16;
    *param_2 = *(int *)(lVar16 + 0x20);
    *(undefined2 *)(param_2 + 1) = *(undefined2 *)(lVar16 + 0x24);
    plVar20 = param_1 + 0x13;
    if ((*(int *)plVar20 == 0) && (*(short *)((longlong)param_1 + 0x9c) == 0)) {
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1001c3;
      (*_DAT_)(1,0x147ab20,0x1444830,0x4d4);
    }
    lVar16 = *(longlong *)(*param_1 + 0x30);
    uStack_11ac = 0;
    if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
      lVar25 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar25 != 0) && (lVar25 = **(longlong **)(lVar25 + 0x38), lVar25 != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100224;
        iVar9 = (*_DAT_)(lVar25,0x337);
        if (iVar9 != 0) goto LAB_;
      }
      lVar25 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
      lVar15 = 0;
      if (lVar25 != 0) {
        lVar15 = *(longlong *)(lVar25 + 0x60);
      }
    }
LAB_:
    lVar25 = *(longlong *)(lVar16 + 0x728);
    *(undefined4 *)(&stack0x0000003c + lVar13) = 2;
    do {
      uStack_1300 = 0;
      lVar26 = *(longlong *)((longlong)&plStackX_18 + lVar13);
      if (lVar26 != 0) {
        iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar13);
        if (((*(ushort *)(lVar26 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
          plVar14 = *(longlong **)((longlong)&plStackX_18 + lVar13);
          if (((byte)*(undefined2 *)(lVar26 + 0x62) >> 3 & 1) != 0) {
            if (iVar9 == 3) {
              iVar9 = 4;
            }
            else if (iVar9 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)((longlong)&plStackX_18 + lVar13) + 100) & 8) != 0) &&
                (lVar26 = *(longlong *)(*(longlong *)((longlong)&plStackX_18 + lVar13) + 0x90),
                lVar26 != 0)) && (*(longlong *)(lVar26 + 0x758) != 0)) {
              uVar5 = *(undefined8 *)(lVar26 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100307;
              func_0x(uVar5,*(undefined8 *)((longlong)&plStackX_18 + lVar13),iVar9);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar14 + 100) & 8) != 0)) &&
             ((2 < iVar9 &&
              (((*(uint *)((longlong)plVar14 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar26 = *plVar14, lVar26 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100348;
            iVar11 = (*_DAT_)(lVar26,0x2000,2,auStack_11b4);
            if (iVar11 != 0) {
              LOCK();
              *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10036a;
          func_0x(plVar14 + 0x13,iVar9);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100389;
            func_0x(plVar14,0,iVar9);
          }
          *(uint *)((longlong)&uStackX_24 + lVar13) =
               *(uint *)((longlong)&uStackX_24 + lVar13) & 0xffff0000;
          *(undefined8 *)((longlong)&plStackX_18 + lVar13) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1002a2;
          func_0x((longlong)&plStackX_18 + lVar13);
        }
      }
      if (*(longlong *)(lVar16 + 0x728) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1003bd;
        func_0x((longlong)&plStackX_18 + lVar13,plVar20,lVar16);
        lVar26 = *(longlong *)((longlong)&plStackX_18 + lVar13);
        if (lVar26 != 0) {
          iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar13);
          if (((*(ushort *)(lVar26 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
            plVar14 = *(longlong **)((longlong)&plStackX_18 + lVar13);
            if (((byte)*(undefined2 *)(lVar26 + 0x62) >> 3 & 1) != 0) {
              if (iVar9 == 3) {
                iVar9 = 4;
              }
              else if (iVar9 < 2) goto LAB_;
              if ((((*(uint *)(*(longlong *)((longlong)&plStackX_18 + lVar13) + 100) & 8) != 0) &&
                  (lVar26 = *(longlong *)(*(longlong *)((longlong)&plStackX_18 + lVar13) + 0x90),
                  lVar26 != 0)) && (*(longlong *)(lVar26 + 0x758) != 0)) {
                uVar5 = *(undefined8 *)(lVar26 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10044d;
                func_0x
                          (uVar5,*(undefined8 *)((longlong)&plStackX_18 + lVar13),iVar9);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar14 + 100) & 8) != 0)) &&
               ((2 < iVar9 &&
                (((*(uint *)((longlong)plVar14 + 100) & 0xc0000000) != 0x40000000 &&
                 (lVar26 = *plVar14, lVar26 != 0)))))) {
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10048e;
              iVar11 = (*_DAT_)(lVar26,0x2000,2,auStack_11b8);
              if (iVar11 != 0) {
                LOCK();
                *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1004b0;
            func_0x(plVar14 + 0x13,iVar9);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1004cf;
              func_0x(plVar14,0,iVar9);
            }
            *(uint *)((longlong)&uStackX_24 + lVar13) =
                 *(uint *)((longlong)&uStackX_24 + lVar13) & 0xffff0000;
            *(undefined8 *)((longlong)&plStackX_18 + lVar13) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1003e8;
            func_0x((longlong)&plStackX_18 + lVar13);
          }
        }
      }
      *(uint **)(&stack0xfffffffffffffff0 + lVar13) = &uStack_11b0;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) = 2;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100507;
      plVar14 = (longlong *)func_0x(_DAT_,lVar16,plVar20,&uStack_1300);
      *(longlong **)((longlong)&plStackX_18 + lVar13) = plVar14;
      uVar23 = *(uint *)((longlong)&uStackX_24 + lVar13) & 0xffff0002 | 2;
      *(uint *)((longlong)&uStackX_24 + lVar13) = uVar23;
      if (lVar15 != 0) {
        uVar18 = (ulonglong)(*(uint *)(lVar15 + 0x500) & 0xf);
        if (*(longlong *)(lVar15 + 0x508 + uVar18 * 8) != *plVar14) {
          *(longlong *)(lVar15 + 0x508 + uVar18 * 8) = *plVar14;
          *(longlong *)(lVar15 + 0x500) = *(longlong *)(lVar15 + 0x500) + 1;
          uVar23 = *(uint *)((longlong)&uStackX_24 + lVar13);
        }
      }
      uVar23 = (uStack_1300 >> 3 & 1) << 0x18 | uVar23 & 0xffffff;
      *(uint *)((longlong)&uStackX_24 + lVar13) = uVar23;
      *(uint *)(&stack0x00000028 + lVar13) =
           uStack_1300 >> 4 & 1 | *(uint *)(&stack0x00000028 + lVar13) & 0xffffff00;
      if (((lVar25 != 0) && (lVar15 != 0)) && (lVar15 == *(longlong *)(lVar16 + 0x1c38))) {
        *(longlong *)(lVar25 + 0x5b28) = *(longlong *)(lVar25 + 0x5b28) + 1;
        if ((int)uStack_11ac != 0) {
          *(longlong *)(lVar25 + 0x5b30) = *(longlong *)(lVar25 + 0x5b30) + 1;
          *(longlong *)(lVar25 + 0x5b38) = *(longlong *)(lVar25 + 0x5b38) + (ulonglong)uStack_11b0;
          if (0xffffff < uVar23) {
            *(longlong *)(lVar25 + 0x5b40) = *(longlong *)(lVar25 + 0x5b40) + 1;
            *(longlong *)(lVar25 + 0x5b48) = *(longlong *)(lVar25 + 0x5b48) + (ulonglong)uStack_11b0
            ;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1005dd;
      cVar8 = func_0x(lVar16);
      if (((cVar8 == '\0') || (*(char *)(lVar16 + 0x2050) == '\0')) ||
         ((*(int *)plVar20 == 0 ||
          ((*(int *)plVar20 == 9 && (*(short *)((longlong)param_1 + 0x9c) == 1))))))
      goto LAB_;
      lVar26 = **(longlong **)((longlong)&plStackX_18 + lVar13);
      if (*(short *)(lVar26 + 0x24) == 0) {
LAB_:
        uStack_12c0 = *(undefined8 *)(lVar26 + 0x28);
        uStack_12b8 = *(ushort *)(lVar26 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar26 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(lVar26 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar26 + 0x18) != 99) goto LAB_;
        }
        uStack_129c = *(undefined4 *)(lVar26 + 0x20);
        uStack_1298 = *(undefined2 *)(lVar26 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100661;
        cVar8 = func_0x(&uStack_129c);
        if (cVar8 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100671;
        func_0x(lVar26,&uStack_12c0);
      }
      uVar23 = *(uint *)(lVar16 + 0x2108);
      do {
        uVar10 = uVar23 & 0xfffffffe;
        *(undefined8 *)(&stack0x00000030 + lVar13) = *(undefined8 *)(lVar16 + 0x20fc);
        *(undefined4 *)(&stack0x00000038 + lVar13) = *(undefined4 *)(lVar16 + 0x2104);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13);
        UNLOCK();
        uVar23 = *(uint *)(lVar16 + 0x2108);
      } while (uVar10 != uVar23);
      if ((uint)uStack_12c0 <= *(uint *)(&stack0x00000030 + lVar13)) {
        if (*(uint *)(&stack0x00000030 + lVar13) != (uint)uStack_12c0) goto LAB_;
        uVar23 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000030 + lVar13) >> 0x20);
        if ((uStack_12c0._4_4_ <= uVar23) &&
           ((uVar23 != uStack_12c0._4_4_ || (uStack_12b8 <= *(ushort *)(&stack0x00000038 + lVar13)))
           )) goto LAB_;
      }
      if ((*(char *)(lVar16 + 0x6ac8) == '\0') &&
         (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) != *(longlong *)(lVar16 + 0x2120))) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10072f;
        cVar8 = func_0x(lVar16);
        if (cVar8 == '\0') {
          uVar23 = *(uint *)(lVar16 + 0x2108);
          do {
            uVar10 = uVar23 & 0xfffffffe;
            uStack_11f8 = *(undefined8 *)(lVar16 + 0x20fc);
            *(undefined8 *)(&stack0x00000030 + lVar13) = uStack_11f8;
            *(undefined4 *)(&stack0x00000038 + lVar13) = *(undefined4 *)(lVar16 + 0x2104);
            LOCK();
            *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13) =
                 *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13);
            UNLOCK();
            uVar23 = *(uint *)(lVar16 + 0x2108);
          } while (uVar10 != uVar23);
          uVar21 = *(ushort *)(&stack0x00000038 + lVar13);
          lVar15 = **(longlong **)((longlong)&plStackX_18 + lVar13);
          uStack_11f0 = uVar21;
          if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
            uStack_12e0 = *(undefined8 *)(lVar15 + 0x28);
            uStack_12d8 = *(ushort *)(lVar15 + 0x30);
          }
          else {
            cVar8 = *(char *)(lVar15 + 1);
            if (cVar8 == '\v') {
              if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
                if (cVar8 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar8 != '\b') goto LAB_;
LAB_:
              if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
            }
            uStack_128c = *(undefined4 *)(lVar15 + 0x20);
            uStack_1288 = *(undefined2 *)(lVar15 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a0b;
            cVar8 = func_0x(&uStack_128c);
            if (cVar8 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a1b;
            func_0x(lVar15,&uStack_12e0);
          }
          if ((*(uint *)(&stack0x00000030 + lVar13) < (uint)uStack_12e0) ||
             ((*(uint *)(&stack0x00000030 + lVar13) == (uint)uStack_12e0 &&
              ((uVar23 = (uint)((ulonglong)uStack_12e0 >> 0x20),
               *(uint *)(&stack0x00000034 + lVar13) < uVar23 ||
               ((*(uint *)(&stack0x00000034 + lVar13) == uVar23 && (uVar21 < uStack_12d8)))))))) {
            lVar15 = *(longlong *)(lVar16 + 0x6b0);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a82;
            func_0x(&uStack_12e0,asStack_b68,auStack_1228);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100a9c;
            func_0x(&uStack_11f8,asStack_b38,auStack_1228);
            if ((_DAT_ & 0x10000) != 0) {
              uStack_1160 = 0x60000;
              iVar9 = 0;
              uStack_1158 = 0;
              ppuStack_1150 = &puStack_1138;
              puStack_1148 = auStack_10d8;
              uStack_f18 = 0;
              uStack_1140 = 0;
              uStack_f10 = 0;
              puStack_1138 = &uStack_f08;
              uStack_1130 = 0x34;
              uStack_112c = 5;
              uStack_1120 = 0x10;
              uStack_111c = 5;
              uStack_1110 = 0x10;
              uStack_110c = 6;
              uStack_10fc = 7;
              uStack_10ec = 8;
              uStack_10e8 = 0;
              uStack_10e0 = 0;
              uStack_10dc = 9;
              uStack_f08 = (uint)*(ushort *)(lVar16 + 0x6b8);
              uStack_f04 = *(undefined2 *)((longlong)param_1 + 0x9c);
              iStack_f02 = *(int *)plVar20;
              uStack_efe = 0xff;
              uStack_efd = *(undefined *)(**(longlong **)((longlong)&plStackX_18 + lVar13) + 1);
              lStack_1128 = lVar15 + 0x254;
              lStack_1118 = lVar15 + 0x244;
              lVar16 = -1;
              do {
                lVar16 = lVar16 + 1;
              } while (asStack_b68[lVar16] != 0);
              iStack_1100 = (int)lVar16 * 2;
              psStack_1108 = asStack_b68;
              lVar16 = -1;
              do {
                lVar16 = lVar16 + 1;
              } while (asStack_b38[lVar16] != 0);
              iStack_10f0 = (int)lVar16 * 2;
              psStack_10f8 = asStack_b38;
              iStack_1344 = 0;
              pcVar6 = *(code **)(_DAT_ + 0x10);
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c63;
              puVar17 = (uint *)(*pcVar6)(lVar15,&iStack_1344);
              ppuVar7 = ppuStack_1150;
              if (puVar17 != (uint *)0x0) {
                lVar15 = -1;
                do {
                  lVar15 = lVar15 + 1;
                } while (*(short *)((longlong)puVar17 + lVar15 * 2) != 0);
                iVar9 = (int)lVar15 * 2;
              }
              ppuStack_1150[10] = puVar17;
              *(int *)(ppuVar7 + 0xb) = iVar9;
              *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100c9d;
              func_0x(auStack_1168);
            }
          }
LAB_:
          uVar5 = **(undefined8 **)((longlong)&plStackX_18 + lVar13);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100cbb;
          uVar12 = func_0x(plStack_1260,uVar5,auStack_aa8);
          lVar15 = *(longlong *)(&stack0x00000040 + lVar13);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100cd2;
          iStack_1344 = func_0x(lVar15,auStack_aa8,uVar12);
          lVar16 = lVar15;
          iStack_be4 = iStack_1344;
          if (*(char *)(lVar15 + 2) < '\0') {
            pbVar1 = (byte *)(lVar15 + 0x60);
            if ((sStack_c18 == 0) || (ppbVar24 = uStack_c08, uStack_c08 == (byte **)0x0)) {
              uStack_bb8 = 0;
              uStack_baa = 0;
              auStack_b90 = ZEXT816(0);
              auStack_be0 = ZEXT816(0);
              stack0xfffffffffffff432 = SUB1614(ZEXT816(0),2);
              auStack_bd0._0_2_ = 0xffff;
              uStack_bc8 = 0;
              uStack_bb2 = 0;
              uStack_bb0 = 0;
              uStack_ba8 = 0;
              uStack_bc0 = 0;
              auStack_ba0 = ZEXT816(0);
              auStack_b80._0_12_ = ZEXT812(0);
              auStack_b80._12_4_ = 0;
              uStack_b70 = 0;
              ppbVar24 = (byte **)auStack_be0;
            }
            if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
              uStack_1248 = *(undefined8 *)(lVar15 + 0x28);
              uStack_1240 = *(undefined2 *)(lVar15 + 0x30);
            }
            else {
              cVar8 = *(char *)(lVar15 + 1);
              if (cVar8 == '\v') {
                if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
                  if (cVar8 != '\t') goto LAB_;
                  goto LAB_;
                }
              }
              else {
                if (cVar8 != '\b') goto LAB_;
LAB_:
                if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
              }
              uStack_1284 = *(undefined4 *)(lVar15 + 0x20);
              uStack_1280 = *(undefined2 *)(lVar15 + 0x24);
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100df7;
              cVar8 = func_0x(&uStack_1284);
              if (cVar8 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100e0a;
              func_0x(lVar15,&uStack_1248);
            }
            *ppbVar24 = pbVar1;
            *(undefined4 *)(ppbVar24 + 0xc) = (undefined4)uStack_1248;
            *(int *)((longlong)ppbVar24 + 100) = (int)((ulonglong)uStack_1248 >> 0x20);
            *(undefined2 *)(ppbVar24 + 0xd) = uStack_1240;
            *(undefined4 *)((longlong)ppbVar24 + 0x6c) = *(undefined4 *)(lVar15 + 0x20);
            *(undefined2 *)(ppbVar24 + 0xe) = *(undefined2 *)(lVar15 + 0x24);
            *(undefined2 *)((longlong)ppbVar24 + 0x72) = 0;
            uStack_1340 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x10b9070);
            sVar22 = *(short *)((ulonglong)*pbVar1 * 6 + 0x10b9074);
            *(short *)((longlong)asStackX_10 + lVar13) = sVar22;
            *(undefined2 *)(ppbVar24 + 2) = 0xffff;
            ppbVar24[3] = (byte *)0x0;
            uVar23 = 0;
            *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
            *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
            ppbVar24[7] = (byte *)0x0;
            ppbVar24[4] = (byte *)0x0;
            ppbVar24[9] = (byte *)0x0;
            ppbVar24[10] = (byte *)0x0;
            *(undefined2 *)(ppbVar24 + 0xb) = 0;
            if ((**ppbVar24 & 2) != 0) {
              pbVar2 = pbVar1 + sVar22;
              if ((*pbVar2 & 1) == 0) {
                *(undefined2 *)(ppbVar24 + 2) = 0;
                ppbVar24[3] = pbVar2;
                *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
                switch(*pbVar2 & 0xe) {
                default:
                  uVar23 = (uint)*(ushort *)(pbVar2 + 2);
                  if (0x1f9d < *(ushort *)(pbVar2 + 2) - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10108a;
                    func_0x(pbVar2,6);
                  }
                  break;
                case 4:
                  uVar23 = 9;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar23 = 1;
                }
                *(uint *)(ppbVar24 + 4) = uVar23;
                *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
                lVar16 = *(longlong *)(&stack0x00000040 + lVar13);
              }
              else {
                *(undefined2 *)(ppbVar24 + 2) = 1;
                ppbVar24[3] = pbVar2;
                bVar3 = *pbVar2;
                switch(bVar3 & 0x1c) {
                default:
                  if ((char)pbVar2[1] < '\0') {
                    uVar21 = *(ushort *)(pbVar2 + 1);
                    *(ushort *)((longlong)ppbVar24 + 0x12) = uVar21;
                    sVar22 = 3;
                    uVar21 = (uVar21 & 0x7f) << 8 | uVar21 >> 8;
                  }
                  else {
                    sVar22 = 2;
                    uVar21 = (ushort)pbVar2[1];
                  }
                  *(ushort *)((longlong)ppbVar24 + 0x12) = uVar21;
                  *(short *)(ppbVar24 + 5) = sVar22;
                  uVar21 = *(ushort *)((longlong)ppbVar24 + 0x12);
                  *(short *)((longlong)ppbVar24 + 0x2c) = (short)(uVar21 + 1 >> 1) + sVar22;
                  if (uVar21 < 0x1f) {
                    *(undefined2 *)((longlong)ppbVar24 + 0x2a) = 0;
                    *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                    *(undefined4 *)(ppbVar24 + 8) = 0;
                    ppbVar24[7] = (byte *)0x0;
                    ppbVar24[4] = (byte *)0x0;
                  }
                  else {
                    iVar9 = uVar21 - 1;
                    *(short *)((longlong)ppbVar24 + 0x2a) =
                         ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                         (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
                    *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
                    *(undefined4 *)(ppbVar24 + 8) = 0;
                    ppbVar24[7] = (byte *)0x0;
                    ppbVar24[4] = (byte *)0x0;
                  }
                  break;
                case 4:
                  if (((bVar3 & 0x1c) != 4) || (uVar10 = 1, (bVar3 & 2) == 0)) {
                    uVar10 = uVar23;
                  }
                  if (uVar10 == 0) {
                    uVar12 = 1;
                  }
                  else {
                    *(undefined4 *)(ppbVar24 + 8) = 0;
                    uVar12 = 0xf;
                  }
                  ppbVar24[5] = (byte *)0x0;
                  *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
                  ppbVar24[6] = (byte *)0x0;
                  ppbVar24[4] = (byte *)0x0;
                  ppbVar24[7] = (byte *)0x0;
                  ppbVar24[3] = pbVar2;
                  *(undefined4 *)((longlong)ppbVar24 + 0x14) = uVar12;
                  *(uint *)(ppbVar24 + 8) = (uint)(uVar10 != 0);
                  ppbVar24[7] = (byte *)0x0;
                  ppbVar24[4] = (byte *)0x0;
                  break;
                case 8:
                  ppbVar24[5] = (byte *)0x0;
                  *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
                  ppbVar24[6] = (byte *)0x0;
                  ppbVar24[4] = (byte *)0x0;
                  ppbVar24[7] = (byte *)0x0;
                  ppbVar24[3] = pbVar2;
                  *(undefined4 *)((longlong)ppbVar24 + 0x14) = 9;
                  *(undefined4 *)(ppbVar24 + 8) = 0;
                  ppbVar24[7] = (byte *)0x0;
                  ppbVar24[4] = (byte *)0x0;
                }
              }
              sVar22 = *(short *)((longlong)asStackX_10 + lVar13);
            }
            if ((**ppbVar24 & 4) != 0) {
              if (uStack_1340._2_2_ == 0) {
                uVar18 = (ulonglong)sVar22;
              }
              else {
                uVar18 = (ulonglong)*(ushort *)(lVar15 + 0x61 + (longlong)uStack_1340._2_2_ * 2);
              }
              psVar19 = (short *)(pbVar1 + uVar18);
              ppbVar24[9] = (byte *)psVar19;
              sVar22 = *psVar19;
              ppbVar24[10] = (byte *)(psVar19 + 1);
              *(short *)(ppbVar24 + 0xb) = (sVar22 + 1) * 2;
            }
            pbVar1 = ppbVar24[1];
            if (pbVar1 != (byte *)0x0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10111d;
              func_0x(pbVar1,ppbVar24);
            }
          }
          else {
            ppbVar24 = (byte **)0x0;
          }
          uVar23 = (uint)*(ushort *)(lVar16 + 0xe);
          pbStack_c10 = (byte *)((ulonglong)
                                 *(ushort *)
                                  (*(longlong *)(&stack0x00000040 + lVar13) +
                                  (0xfff - (longlong)iStack_1344) * 2) +
                                *(longlong *)(&stack0x00000040 + lVar13));
          if ((*pbStack_c10 & 1) == 0) {
            sStack_c18 = 0;
            uStack_c14 = 0;
            uStack_bf2 = 0;
            uStack_bf0 = 0;
            switch(*pbStack_c10 & 0xe) {
            default:
              uVar23 = (uint)*(ushort *)(pbStack_c10 + 2);
              if (0x1f9d < *(ushort *)(pbStack_c10 + 2) - 1) {
                *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10135f;
                func_0x(pbStack_c10,6);
              }
              break;
            case 4:
              uVar23 = 9;
              break;
            case 6:
            case 10:
              break;
            case 0xe:
              uVar23 = 1;
            }
            uStack_c08 = (byte **)CONCAT44(uStack_c08._4_4_,uVar23);
            lVar15 = *(longlong *)(&stack0x00000040 + lVar13);
            uStack_bfa = (undefined2)(lVar15 + 0x2000);
            uStack_bf8 = (undefined6)((ulonglong)(lVar15 + 0x2000) >> 0x10);
          }
          else {
            sStack_c18 = 1;
            bVar3 = *pbStack_c10;
            switch(bVar3 & 0x1c) {
            default:
              if ((char)pbStack_c10[1] < '\0') {
                uStack_c16 = (*(ushort *)(pbStack_c10 + 1) & 0x7f) << 8 |
                             *(ushort *)(pbStack_c10 + 1) >> 8;
                uStack_c00 = 3;
                *(undefined2 *)(&stack0x0000003c + lVar13) = 3;
              }
              else {
                uStack_c16 = (ushort)pbStack_c10[1];
                uStack_c00 = 2;
              }
              sStack_bfc = (short)(uStack_c16 + 1 >> 1) +
                           (short)*(undefined4 *)(&stack0x0000003c + lVar13);
              if (uStack_c16 < 0x1f) {
                sStack_bfe = 0;
                uStack_c14 = 0;
                uStack_be8 = 0;
              }
              else {
                iVar9 = uStack_c16 - 1;
                sStack_bfe = ((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                             (short)((longlong)iVar9 * 0x88888889 >> 0x3f);
                uStack_c14 = 0;
                uStack_be8 = 0;
              }
              break;
            case 4:
              if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
                uStack_c00 = 0;
                sStack_bfe = 0;
                sStack_bfc = 0;
                uStack_bfa = 0;
                uStack_c16 = 0;
                uStack_bf8 = 0;
                uStack_bf2 = 0;
                uStack_c14 = 0xf;
                uStack_be8 = 1;
              }
              else {
                uStack_c00 = 0;
                sStack_bfe = 0;
                sStack_bfc = 0;
                uStack_bfa = 0;
                uStack_c16 = 0;
                uStack_bf8 = 0;
                uStack_bf2 = 0;
                uStack_c14 = 1;
                uStack_be8 = 0;
              }
              break;
            case 8:
              uStack_c00 = 0;
              sStack_bfe = 0;
              sStack_bfc = 0;
              uStack_bfa = 0;
              uStack_c16 = 0;
              uStack_bf8 = 0;
              uStack_bf2 = 0;
              uStack_c14 = 9;
              uStack_be8 = 0;
            }
            lVar15 = *(longlong *)(&stack0x00000040 + lVar13);
            uStack_bf0 = (undefined2)(lVar15 + 0x2000);
            uStack_bee = (undefined6)((ulonglong)(lVar15 + 0x2000) >> 0x10);
            uStack_c08 = ppbVar24;
          }
          plVar20 = plStack_1260;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1013d5;
          func_0x(&sStack_c18,lStack_1210 + 0x210,plStack_1260 + 0x13,6);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1013e8;
          func_0x(lVar15,(longlong)plVar20 + 0xdc,iStack_1348);
          *(int *)(plVar20 + 0x13) = *piStack_12f8;
          *(undefined2 *)((longlong)plVar20 + 0x9c) = *(undefined2 *)(piStack_12f8 + 1);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10140b;
          func_0x((longlong)&plStackX_18 + lVar13);
          goto code_r0x0010243f;
        }
      }
      if (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) == *(longlong *)(lVar16 + 0x2120)) goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100773;
      cVar8 = func_0x(lVar16);
      if (cVar8 != '\0') goto LAB_;
      if (lVar15 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100785;
        lVar15 = func_0x();
      }
      plVar14 = *(longlong **)((longlong)&plStackX_18 + lVar13);
      lVar26 = *plVar14;
      if (*(short *)(lVar26 + 0x24) == 0) {
LAB_:
        uStack_1258 = *(undefined8 *)(lVar26 + 0x28);
        uStack_1250 = *(undefined2 *)(lVar26 + 0x30);
      }
      else {
        cVar8 = *(char *)(lVar26 + 1);
        if (cVar8 == '\v') {
          if (*(int *)(lVar26 + 0x18) != 99) {
LAB_:
            if (cVar8 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar8 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar26 + 0x18) != 99) goto LAB_;
        }
        uStack_1294 = *(undefined4 *)(lVar26 + 0x20);
        uStack_1290 = *(undefined2 *)(lVar26 + 0x24);
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1007d5;
        cVar8 = func_0x(&uStack_1294);
        if (cVar8 == '\0') {
          plVar14 = *(longlong **)((longlong)&plStackX_18 + lVar13);
          goto LAB_;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1007e5;
        func_0x(lVar26,&uStack_1258);
        plVar14 = *(longlong **)((longlong)&plStackX_18 + lVar13);
      }
      if (plVar14 != (longlong *)0x0) {
        iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar13);
        if (((*(ushort *)((longlong)plVar14 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
          plVar4 = *(longlong **)((longlong)&plStackX_18 + lVar13);
          if (((byte)*(undefined2 *)((longlong)plVar14 + 0x62) >> 3 & 1) != 0) {
            if (iVar9 == 3) {
              iVar9 = 4;
            }
            else if (iVar9 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)((longlong)&plStackX_18 + lVar13) + 100) & 8) != 0) &&
                (lVar26 = *(longlong *)(*(longlong *)((longlong)&plStackX_18 + lVar13) + 0x90),
                lVar26 != 0)) && (*(longlong *)(lVar26 + 0x758) != 0)) {
              uVar5 = *(undefined8 *)(lVar26 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100895;
              func_0x(uVar5,*(undefined8 *)((longlong)&plStackX_18 + lVar13),iVar9);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar4 + 100) & 8) != 0)) &&
             ((2 < iVar9 &&
              (((*(uint *)((longlong)plVar4 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar26 = *plVar4, lVar26 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1008d9;
            iVar11 = (*_DAT_)(lVar26,0x2000,2,auStack_11bc);
            if (iVar11 != 0) {
              LOCK();
              *(uint *)((longlong)plVar4 + 100) = *(uint *)((longlong)plVar4 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar4 + 100) = *(uint *)((longlong)plVar4 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1008fb;
          func_0x(plVar4 + 0x13,iVar9);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10091a;
            func_0x(plVar4,0,iVar9);
          }
          *(uint *)((longlong)&uStackX_24 + lVar13) =
               *(uint *)((longlong)&uStackX_24 + lVar13) & 0xffff0000;
          *(undefined8 *)((longlong)&plStackX_18 + lVar13) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x100830;
          func_0x((longlong)&plStackX_18 + lVar13);
        }
      }
      uStack_1208 = uStack_1258;
      uStack_1200 = uStack_1250;
      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
      uVar5 = *(undefined8 *)(lVar16 + 0x728);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10096d;
      func_0x(uVar5,&uStack_1208,4);
    } while( true );
  }
  lVar16 = *(longlong *)(*param_1 + 0x30);
  uStack_1194 = 0;
  if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
    lVar25 = *(longlong *)
              ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar25 != 0) && (lVar25 = **(longlong **)(lVar25 + 0x38), lVar25 != 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101471;
      iVar9 = (*_DAT_)(lVar25,0x337);
      if (iVar9 != 0) goto LAB_;
    }
    lVar25 = *(longlong *)
              ((ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
              + 8);
    if (lVar25 != 0) {
      lVar15 = *(longlong *)(lVar25 + 0x60);
    }
  }
LAB_:
  lVar25 = *(longlong *)(lVar16 + 0x728);
  *(undefined4 *)(&stack0x0000003c + lVar13) = 2;
  do {
    uStack_12fc = 0;
    lVar26 = *(longlong *)(&stack0xfffffffffffffff8 + lVar13);
    if (lVar26 != 0) {
      iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar13 + -0x20);
      if (((*(ushort *)(lVar26 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
        plVar20 = *(longlong **)(&stack0xfffffffffffffff8 + lVar13);
        if (((byte)*(undefined2 *)(lVar26 + 0x62) >> 3 & 1) != 0) {
          if (iVar9 == 3) {
            iVar9 = 4;
          }
          else if (iVar9 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 100) & 8) != 0) &&
              (lVar26 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 0x90),
              lVar26 != 0)) && (*(longlong *)(lVar26 + 0x758) != 0)) {
            uVar5 = *(undefined8 *)(lVar26 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101554;
            func_0x(uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar13),iVar9);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar20 + 100) & 8) != 0)) &&
           ((2 < iVar9 &&
            (((*(uint *)((longlong)plVar20 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar26 = *plVar20, lVar26 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101595;
          iVar11 = (*_DAT_)(lVar26,0x2000,2,auStack_11c4);
          if (iVar11 != 0) {
            LOCK();
            *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1015b7;
        func_0x(plVar20 + 0x13,iVar9);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1015d6;
          func_0x(plVar20,0,iVar9);
        }
        puVar17 = (uint *)((longlong)&uStackX_24 + lVar13 + -0x20);
        *puVar17 = *puVar17 & 0xffff0000;
        *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
        param_2 = piStack_12f8;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1014ef;
        func_0x(&stack0xfffffffffffffff8 + lVar13);
      }
    }
    if (*(longlong *)(lVar16 + 0x728) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10160a;
      func_0x(&stack0xfffffffffffffff8 + lVar13,param_2,lVar16);
      lVar26 = *(longlong *)(&stack0xfffffffffffffff8 + lVar13);
      if (lVar26 != 0) {
        iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar13 + -0x20);
        if (((*(ushort *)(lVar26 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
          plVar20 = *(longlong **)(&stack0xfffffffffffffff8 + lVar13);
          if (((byte)*(undefined2 *)(lVar26 + 0x62) >> 3 & 1) != 0) {
            if (iVar9 == 3) {
              iVar9 = 4;
            }
            else if (iVar9 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 100) & 8) != 0) &&
                (lVar26 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 0x90),
                lVar26 != 0)) && (*(longlong *)(lVar26 + 0x758) != 0)) {
              uVar5 = *(undefined8 *)(lVar26 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10169a;
              func_0x
                        (uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar13),iVar9);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar20 + 100) & 8) != 0)) &&
             ((2 < iVar9 &&
              (((*(uint *)((longlong)plVar20 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar26 = *plVar20, lVar26 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1016db;
            iVar11 = (*_DAT_)(lVar26,0x2000,2,auStack_11c8);
            if (iVar11 != 0) {
              LOCK();
              *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar20 + 100) = *(uint *)((longlong)plVar20 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1016fd;
          func_0x(plVar20 + 0x13,iVar9);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10171c;
            func_0x(plVar20,0,iVar9);
          }
          puVar17 = (uint *)((longlong)&uStackX_24 + lVar13 + -0x20);
          *puVar17 = *puVar17 & 0xffff0000;
          *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
          param_2 = piStack_12f8;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101635;
          func_0x(&stack0xfffffffffffffff8 + lVar13);
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101738;
    func_0x(lVar16,param_2);
    *(uint **)(&stack0xfffffffffffffff0 + lVar13) = &uStack_1198;
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar13) = 4;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101762;
    plVar20 = (longlong *)func_0x(_DAT_,lVar16,param_2,&uStack_12fc);
    *(longlong **)(&stack0xfffffffffffffff8 + lVar13) = plVar20;
    uVar23 = *(uint *)((longlong)&uStackX_24 + lVar13 + -0x20) & 0xffff0004 | 4;
    *(uint *)((longlong)&uStackX_24 + lVar13 + -0x20) = uVar23;
    if (lVar15 != 0) {
      uVar18 = (ulonglong)(*(uint *)(lVar15 + 0x500) & 0xf);
      if (*(longlong *)(lVar15 + 0x508 + uVar18 * 8) != *plVar20) {
        *(longlong *)(lVar15 + 0x508 + uVar18 * 8) = *plVar20;
        *(longlong *)(lVar15 + 0x500) = *(longlong *)(lVar15 + 0x500) + 1;
        uVar23 = *(uint *)((longlong)&uStackX_24 + lVar13 + -0x20);
      }
    }
    uVar23 = (uStack_12fc >> 3 & 1) << 0x18 | uVar23 & 0xffffff;
    *(uint *)((longlong)&uStackX_24 + lVar13 + -0x20) = uVar23;
    *(uint *)((longlong)auStackX_8 + lVar13) =
         uStack_12fc >> 4 & 1 | *(uint *)((longlong)auStackX_8 + lVar13) & 0xffffff00;
    if (((lVar25 != 0) && (lVar15 != 0)) && (lVar15 == *(longlong *)(lVar16 + 0x1c38))) {
      *(longlong *)(lVar25 + 0x5b28) = *(longlong *)(lVar25 + 0x5b28) + 1;
      if ((int)uStack_1194 != 0) {
        *(longlong *)(lVar25 + 0x5b30) = *(longlong *)(lVar25 + 0x5b30) + 1;
        *(longlong *)(lVar25 + 0x5b38) = *(longlong *)(lVar25 + 0x5b38) + (ulonglong)uStack_1198;
        if (0xffffff < uVar23) {
          *(longlong *)(lVar25 + 0x5b40) = *(longlong *)(lVar25 + 0x5b40) + 1;
          *(longlong *)(lVar25 + 0x5b48) = *(longlong *)(lVar25 + 0x5b48) + (ulonglong)uStack_1198;
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101838;
    cVar8 = func_0x(lVar16);
    if (((cVar8 == '\0') || (*(char *)(lVar16 + 0x2050) == '\0')) ||
       ((*param_2 == 0 || ((*param_2 == 9 && (*(short *)(param_2 + 1) == 1)))))) goto LAB_;
    lVar26 = **(longlong **)(&stack0xfffffffffffffff8 + lVar13);
    if (*(short *)(lVar26 + 0x24) == 0) {
LAB_:
      uStack_12d0 = *(undefined8 *)(lVar26 + 0x28);
      uStack_12c8 = *(ushort *)(lVar26 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar26 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar26 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar26 + 0x18) != 99) goto LAB_;
      }
      uStack_127c = *(undefined4 *)(lVar26 + 0x20);
      uStack_1278 = *(undefined2 *)(lVar26 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1018bc;
      cVar8 = func_0x(&uStack_127c);
      if (cVar8 == '\0') goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1018cc;
      func_0x(lVar26,&uStack_12d0);
    }
    uVar23 = *(uint *)(lVar16 + 0x2108);
    do {
      uVar10 = uVar23 & 0xfffffffe;
      *(undefined8 *)(&stack0x00000030 + lVar13) = *(undefined8 *)(lVar16 + 0x20fc);
      *(undefined4 *)(&stack0x00000038 + lVar13) = *(undefined4 *)(lVar16 + 0x2104);
      LOCK();
      *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13) =
           *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13);
      UNLOCK();
      uVar23 = *(uint *)(lVar16 + 0x2108);
    } while (uVar10 != uVar23);
    if ((uint)uStack_12d0 <= *(uint *)(&stack0x00000030 + lVar13)) {
      if (*(uint *)(&stack0x00000030 + lVar13) != (uint)uStack_12d0) goto LAB_;
      uVar23 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000030 + lVar13) >> 0x20);
      if ((uStack_12d0._4_4_ <= uVar23) &&
         ((uVar23 != uStack_12d0._4_4_ || (uStack_12c8 <= *(ushort *)(&stack0x00000038 + lVar13)))))
      goto LAB_;
    }
    if ((*(char *)(lVar16 + 0x6ac8) == '\0') &&
       (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) != *(longlong *)(lVar16 + 0x2120))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10198f;
      cVar8 = func_0x(lVar16);
      if (cVar8 == '\0') {
        uVar23 = *(uint *)(lVar16 + 0x2108);
        do {
          uVar10 = uVar23 & 0xfffffffe;
          uStack_11d8 = *(undefined8 *)(lVar16 + 0x20fc);
          *(undefined8 *)(&stack0x00000030 + lVar13) = uStack_11d8;
          *(undefined4 *)(&stack0x00000038 + lVar13) = *(undefined4 *)(lVar16 + 0x2104);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar13);
          UNLOCK();
          uVar23 = *(uint *)(lVar16 + 0x2108);
        } while (uVar10 != uVar23);
        uVar21 = *(ushort *)(&stack0x00000038 + lVar13);
        lVar15 = **(longlong **)(&stack0xfffffffffffffff8 + lVar13);
        uStack_11d0 = uVar21;
        if (*(short *)(lVar15 + 0x24) == 0) {
LAB_:
          uStack_12f0 = *(undefined8 *)(lVar15 + 0x28);
          uStack_12e8 = *(ushort *)(lVar15 + 0x30);
        }
        else {
          cVar8 = *(char *)(lVar15 + 1);
          if (cVar8 == '\v') {
            if (*(int *)(lVar15 + 0x18) != 99) {
LAB_:
              if (cVar8 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar8 != '\b') goto LAB_;
LAB_:
            if (*(int *)(lVar15 + 0x18) != 99) goto LAB_;
          }
          uStack_126c = *(undefined4 *)(lVar15 + 0x20);
          uStack_1268 = *(undefined2 *)(lVar15 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101c7b;
          cVar8 = func_0x(&uStack_126c);
          if (cVar8 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101c8b;
          func_0x(lVar15,&uStack_12f0);
        }
        if ((*(uint *)(&stack0x00000030 + lVar13) < (uint)uStack_12f0) ||
           ((*(uint *)(&stack0x00000030 + lVar13) == (uint)uStack_12f0 &&
            ((uVar23 = (uint)((ulonglong)uStack_12f0 >> 0x20),
             *(uint *)(&stack0x00000034 + lVar13) < uVar23 ||
             ((*(uint *)(&stack0x00000034 + lVar13) == uVar23 && (uVar21 < uStack_12e8)))))))) {
          lVar15 = *(longlong *)(lVar16 + 0x6b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101cef;
          func_0x(&uStack_12f0,asStack_b08,auStack_12b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101d06;
          func_0x(&uStack_11d8,asStack_ad8,auStack_12b0);
          if ((_DAT_ & 0x10000) != 0) {
            iVar9 = 0;
            uStack_ec0 = 0x60000;
            uStack_eb8 = 0;
            ppuStack_eb0 = &puStack_e98;
            puStack_ea8 = auStack_e38;
            uStack_c78 = 0;
            uStack_ea0 = 0;
            uStack_c70 = 0;
            puStack_e98 = &uStack_c68;
            uStack_e90 = 0x34;
            uStack_e8c = 5;
            uStack_e80 = 0x10;
            uStack_e7c = 5;
            uStack_e70 = 0x10;
            uStack_e6c = 6;
            uStack_e5c = 7;
            uStack_e4c = 8;
            uStack_e48 = 0;
            uStack_e40 = 0;
            uStack_e3c = 9;
            uStack_c68 = (uint)*(ushort *)(lVar16 + 0x6b8);
            uStack_c64 = *(undefined2 *)(param_2 + 1);
            iStack_c62 = *param_2;
            uStack_c5e = 0xff;
            uStack_c5d = *(undefined *)(**(longlong **)(&stack0xfffffffffffffff8 + lVar13) + 1);
            lStack_e88 = lVar15 + 0x254;
            lStack_e78 = lVar15 + 0x244;
            lVar25 = -1;
            lVar16 = -1;
            do {
              lVar16 = lVar16 + 1;
            } while (asStack_b08[lVar16] != 0);
            iStack_e60 = (int)lVar16 * 2;
            psStack_e68 = asStack_b08;
            lVar16 = -1;
            do {
              lVar16 = lVar16 + 1;
            } while (asStack_ad8[lVar16] != 0);
            iStack_e50 = (int)lVar16 * 2;
            psStack_e58 = asStack_ad8;
            uStack_12ac = 0;
            pcVar6 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101ec3;
            puVar17 = (uint *)(*pcVar6)(lVar15,&uStack_12ac);
            ppuVar7 = ppuStack_eb0;
            if (puVar17 != (uint *)0x0) {
              do {
                lVar25 = lVar25 + 1;
              } while (*(short *)((longlong)puVar17 + lVar25 * 2) != 0);
              iVar9 = (int)lVar25 * 2;
            }
            ppuStack_eb0[10] = puVar17;
            *(int *)(ppuVar7 + 0xb) = iVar9;
            *(undefined4 *)((longlong)ppuVar7 + 0x5c) = 9;
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101efd;
            func_0x(auStack_ec8);
          }
        }
LAB_:
        plVar20 = plStack_1260;
        iVar9 = (1 << ((byte)*(undefined2 *)(plStack_1260[0x1be] + 4) & 2)) + -1;
        uVar10 = 0x2000 - *(int *)((longlong)plStack_1260 + 0xb3c);
        uVar23 = iVar9 + iStack_1348 & 0xffffU & (uint)(ushort)~(ushort)iVar9;
        if (uVar23 <= uVar10) {
          uVar23 = uVar10;
        }
        uVar10 = (uint)*(ushort *)(**(longlong **)(&stack0xfffffffffffffff8 + lVar13) + 0x1c);
        if (uVar10 < 3) {
          uVar10 = 0;
        }
        else {
          uVar10 = uVar10 - 2;
        }
        if ((uVar23 <= uVar10) ||
           (*(ushort *)(**(longlong **)(&stack0xfffffffffffffff8 + lVar13) + 0x16) < 2)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102304;
          lVar15 = func_0x
                             (_DAT_,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar13),1,0);
          *(ushort *)(lVar15 + 4) = *(ushort *)(lVar15 + 4) & 0xedff;
          *(undefined4 *)(lVar15 + 0x40) = 1;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102326;
          func_0x(lVar15,(longlong)plVar20 + 0xdc,iStack_1348);
          plVar14 = *(longlong **)(*(longlong *)(*plVar20 + 0x30) + 0x6c8);
          pcVar6 = *(code **)(*plVar14 + 0x28);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102342;
          (*pcVar6)(plVar14,&iStack_c28);
          if (((*(short *)(lVar15 + 0x30) != sStack_c20) || (*(int *)(lVar15 + 0x28) != iStack_c28))
             || (*(int *)(lVar15 + 0x2c) != iStack_c24)) {
            *(ulonglong *)(lVar15 + 0x28) = CONCAT44(iStack_c24,iStack_c28);
            *(short *)(lVar15 + 0x30) = sStack_c20;
            *(ushort *)(lVar15 + 4) = *(ushort *)(lVar15 + 4) & 0xffdf;
          }
          LOCK();
          *(ushort *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 0x62) =
               *(ushort *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 0x62) | 1;
          UNLOCK();
          lVar15 = *plVar20;
          lVar16 = *(longlong *)(*(longlong *)(lVar15 + 0x30) + 0x6b0);
          if ((((*(byte *)(lVar16 + 0x3c) & 1) != 0) && (*(longlong *)(lVar16 + 0x280) == 0)) &&
             ((*(short *)(*(longlong *)(&stack0x00000040 + lVar13) + 0x1c) < 1 ||
              ((lVar16 = *(longlong *)(*(longlong *)(&stack0x00000040 + lVar13) + 0x10),
               *(int *)(lVar16 + 0x70) != *param_2 ||
               (*(short *)(lVar16 + 0x74) != *(short *)(param_2 + 1))))))) {
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1023f4;
            (*_DAT_)(1,0x147ab40,0x1444830,0x52f);
            lVar15 = *plVar20;
          }
          uVar5 = *(undefined8 *)(*(longlong *)(lVar15 + 0x30) + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10240f;
          func_0x(uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar13),0);
          uStack_1220 = 0;
          uStack_1218 = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10243a;
          func_0x
                    (_DAT_,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar13),0,&uStack_1220
                    );
          goto code_r0x0010243f;
        }
        iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar13 + -0x20);
        if (((*(ushort *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 0x62) >> 10 & 1) == 0)
           || (iVar9 < 3)) {
          plVar14 = *(longlong **)(&stack0xfffffffffffffff8 + lVar13);
          if (((byte)*(undefined2 *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 0x62) >> 3 &
              1) != 0) {
            if (iVar9 == 3) {
              iVar9 = 4;
            }
            else if (iVar9 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 100) & 8) != 0) &&
                (lVar15 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 0x90),
                lVar15 != 0)) && (*(longlong *)(lVar15 + 0x758) != 0)) {
              uVar5 = *(undefined8 *)(lVar15 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101ffe;
              func_0x
                        (uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar13),iVar9);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar14 + 100) & 8) != 0)) &&
             ((2 < iVar9 &&
              (((*(uint *)((longlong)plVar14 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar15 = *plVar14, lVar15 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102042;
            iVar11 = (*_DAT_)(lVar15,0x2000,2,auStack_11c0);
            if (iVar11 != 0) {
              LOCK();
              *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102064;
          func_0x(plVar14 + 0x13,iVar9);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102083;
            func_0x(plVar14,0,iVar9);
          }
          puVar17 = (uint *)((longlong)&uStackX_24 + lVar13 + -0x20);
          *puVar17 = *puVar17 & 0xffff0000;
          *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101f98;
          func_0x(&stack0xfffffffffffffff8 + lVar13);
        }
        uStack_1340 = 0;
        uStack_133c = 0;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar13) =
             *(undefined8 *)(&stack0x00000040 + lVar13);
        *(undefined **)(&stack0xffffffffffffffe8 + lVar13) = &stack0xfffffffffffffff8 + lVar13;
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1020c4;
        func_0x(plVar20,*(undefined *)((longlong)asStackX_10 + lVar13),param_2,&uStack_1340)
        ;
        lVar15 = **(longlong **)(&stack0xfffffffffffffff8 + lVar13);
        *param_2 = *(int *)(lVar15 + 0x20);
        *(undefined2 *)(param_2 + 1) = *(undefined2 *)(lVar15 + 0x24);
        pbVar1 = (byte *)((longlong)plVar20 + 0xdc);
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1020eb;
        func_0x(lVar15,pbVar1,iStack_1348);
        uVar23 = *(uint *)(plVar20 + 0x168);
        bVar3 = *pbVar1;
        pbStack_1330 = pbVar1;
        if ((bVar3 & 1) == 0) {
          uStack_1338 = 0;
          uStack_1312 = 0;
          uStack_1310 = 0;
          switch(bVar3 & 0xe) {
          default:
            uVar23 = (uint)*(ushort *)((longlong)plVar20 + 0xde);
            if (0x1f9d < uVar23 - 1) {
              *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10228c;
              func_0x(pbVar1,6);
            }
            break;
          case 4:
            uVar23 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar23 = 1;
          }
          uStack_1328 = CONCAT44(uStack_1328._4_4_,uVar23);
        }
        else {
          uStack_1338 = 1;
          switch(bVar3 & 0x1c) {
          default:
            if ((char)*(byte *)((longlong)plVar20 + 0xdd) < '\0') {
              uStack_1336 = (*(ushort *)((longlong)plVar20 + 0xdd) & 0x7f) << 8 |
                            *(ushort *)((longlong)plVar20 + 0xdd) >> 8;
              uVar21 = 3;
              *(undefined2 *)(&stack0x0000003c + lVar13) = 3;
            }
            else {
              uStack_1336 = (ushort)*(byte *)((longlong)plVar20 + 0xdd);
              uVar21 = 2;
            }
            sStack_131c = (short)(uStack_1336 + 1 >> 1) +
                          (short)*(undefined4 *)(&stack0x0000003c + lVar13);
            if (uStack_1336 < 0x1f) {
              uStack_1320 = (uint)uVar21;
              uStack_1308 = 0;
            }
            else {
              iVar9 = uStack_1336 - 1;
              uStack_1320 = CONCAT22(((short)(iVar9 / 0x1e) + (short)(iVar9 >> 0x1f)) -
                                     (short)((longlong)iVar9 * 0x88888889 >> 0x3f),uVar21);
              uStack_1308 = 0;
            }
            break;
          case 4:
            if (((bVar3 & 0x1c) == 4) && ((bVar3 & 2) != 0)) {
              uStack_1320 = 0;
              uStack_1336 = 0;
              sStack_131c = 0;
              uStack_1312 = 0;
              uStack_1334 = 0xf;
              uStack_1308 = 1;
            }
            else {
              uStack_1320 = 0;
              uStack_1336 = 0;
              sStack_131c = 0;
              uStack_1312 = 0;
              uStack_1334 = 1;
              uStack_1308 = 0;
            }
            break;
          case 8:
            uStack_1320 = 0;
            uStack_1336 = 0;
            sStack_131c = 0;
            uStack_1312 = 0;
            uStack_1334 = 9;
            uStack_1308 = 0;
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1022e8;
        func_0x(&uStack_1338,lStack_1210 + 0x210,piStack_12f8,6);
code_r0x0010243f:
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x102449;
        func_0x(&stack0xfffffffffffffff8 + lVar13);
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x10245b;
        func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar13));
        return;
      }
    }
    if (*(longlong *)
         (*(longlong *)
           ((ulonglong)*_DAT_ +
            *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8
           ) + 0x60) == *(longlong *)(lVar16 + 0x2120)) goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1019d3;
    cVar8 = func_0x(lVar16);
    if (cVar8 != '\0') goto LAB_;
    if (lVar15 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x1019e5;
      lVar15 = func_0x();
    }
    plVar20 = *(longlong **)(&stack0xfffffffffffffff8 + lVar13);
    lVar26 = *plVar20;
    if (*(short *)(lVar26 + 0x24) == 0) {
LAB_:
      uStack_1238 = *(undefined8 *)(lVar26 + 0x28);
      uStack_1230 = *(undefined2 *)(lVar26 + 0x30);
    }
    else {
      cVar8 = *(char *)(lVar26 + 1);
      if (cVar8 == '\v') {
        if (*(int *)(lVar26 + 0x18) != 99) {
LAB_:
          if (cVar8 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar8 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar26 + 0x18) != 99) goto LAB_;
      }
      uStack_1274 = *(undefined4 *)(lVar26 + 0x20);
      uStack_1270 = *(undefined2 *)(lVar26 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a35;
      cVar8 = func_0x(&uStack_1274);
      if (cVar8 == '\0') {
        plVar20 = *(longlong **)(&stack0xfffffffffffffff8 + lVar13);
        goto LAB_;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a48;
      func_0x(lVar26,&uStack_1238);
      plVar20 = *(longlong **)(&stack0xfffffffffffffff8 + lVar13);
    }
    if (plVar20 != (longlong *)0x0) {
      iVar9 = (int)*(short *)((longlong)&uStackX_24 + lVar13 + -0x20);
      if (((*(ushort *)((longlong)plVar20 + 0x62) & 0x400) == 0) || (iVar9 < 3)) {
        plVar14 = *(longlong **)(&stack0xfffffffffffffff8 + lVar13);
        if (((byte)*(undefined2 *)((longlong)plVar20 + 0x62) >> 3 & 1) != 0) {
          if (iVar9 == 3) {
            iVar9 = 4;
          }
          else if (iVar9 < 2) goto LAB_;
          if ((((*(uint *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 100) & 8) != 0) &&
              (lVar26 = *(longlong *)(*(longlong *)(&stack0xfffffffffffffff8 + lVar13) + 0x90),
              lVar26 != 0)) && (*(longlong *)(lVar26 + 0x758) != 0)) {
            uVar5 = *(undefined8 *)(lVar26 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101b42;
            func_0x(uVar5,*(undefined8 *)(&stack0xfffffffffffffff8 + lVar13),iVar9);
          }
        }
LAB_:
        if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar14 + 100) & 8) != 0)) &&
           ((2 < iVar9 &&
            (((*(uint *)((longlong)plVar14 + 100) & 0xc0000000) != 0x40000000 &&
             (lVar26 = *plVar14, lVar26 != 0)))))) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101b86;
          iVar11 = (*_DAT_)(lVar26,0x2000,2,auStack_1180);
          if (iVar11 != 0) {
            LOCK();
            *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) & 0x3fffffff;
            UNLOCK();
            LOCK();
            *(uint *)((longlong)plVar14 + 100) = *(uint *)((longlong)plVar14 + 100) | 0x40000000;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101ba8;
        func_0x(plVar14 + 0x13,iVar9);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101bc7;
          func_0x(plVar14,0,iVar9);
        }
        puVar17 = (uint *)((longlong)&uStackX_24 + lVar13 + -0x20);
        *puVar17 = *puVar17 & 0xffff0000;
        *(undefined8 *)(&stack0xfffffffffffffff8 + lVar13) = 0;
        param_2 = piStack_12f8;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101a95;
        func_0x(&stack0xfffffffffffffff8 + lVar13);
      }
    }
    uStack_11e8 = uStack_1238;
    uStack_11e0 = uStack_1230;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar13) = 0;
    uVar5 = *(undefined8 *)(lVar16 + 0x728);
    *(undefined8 *)((longlong)&uStack_40 + lVar13) = 0x101ad7;
    func_0x(uVar5,&uStack_11e8,4);
  } while( true );
}

