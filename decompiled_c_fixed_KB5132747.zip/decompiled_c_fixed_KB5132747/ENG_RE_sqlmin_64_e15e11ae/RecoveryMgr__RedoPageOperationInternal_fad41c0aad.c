
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  undefined uVar1;
  ushort uVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  bool bVar6;
  bool bVar7;
  char cVar8;
  char cVar9;
  undefined uVar10;
  byte bVar11;
  byte bVar12;
  byte bVar13;
  short sVar14;
  undefined2 uVar15;
  ushort uVar16;
  int iVar17;
  uint uVar18;
  int iVar19;
  undefined4 uVar20;
  longlong lVar21;
  longlong lVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  longlong lVar25;
  longlong lVar26;
  longlong *plVar27;
  ulonglong uVar28;
  longlong lVar29;
  longlong lVar30;
  undefined8 *puVar31;
  undefined4 *puVar32;
  undefined8 uVar33;
  ulonglong uVar34;
  code *UNRECOVERED_JUMPTABLE;
  undefined *puVar35;
  longlong **pplVar36;
  longlong lVar37;
  longlong unaff_GS_OFFSET;
  longlong lStackX_8;
  undefined8 uStackX_10;
  longlong lStackX_18;
  undefined8 uStackX_20;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar21 = func_0x();
  lVar21 = -lVar21;
  *(undefined8 *)(&stack0x000008f0 + lVar21) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000079d0 + lVar21) = _DAT_ ^ (ulonglong)(&stack0x00000050 + lVar21)
  ;
  *(undefined8 *)(&stack0x00000090 + lVar21) = param_4;
  *(undefined8 *)(&stack0x000000a8 + lVar21) = param_3;
  *(longlong *)(&stack0x00000068 + lVar21) = param_2;
  *(longlong **)(&stack0x00000070 + lVar21) = param_1;
  cVar8 = (&stack0x00007a50)[lVar21];
  (&stack0x00000060)[lVar21] = cVar8;
  plVar3 = *(longlong **)(&stack0x00007a60 + lVar21);
  *(undefined4 *)(&stack0x000003d8 + lVar21) = *(undefined4 *)(param_2 + 0x18);
  *(undefined2 *)(&stack0x000003dc + lVar21) = *(undefined2 *)(param_2 + 0x1c);
  *(undefined **)(&stack0xffffffffffffffe0 + lVar21) = &stack0x000003d8 + lVar21;
  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10009f;
  func_0x(&stack0x000015e8 + lVar21,param_1 + 299);
  lVar30 = 0;
  *(undefined4 *)(&stack0x00000288 + lVar21) = 0;
  *(undefined4 *)(&stack0x00000320 + lVar21) = 0;
  *(undefined4 *)(&stack0x00000324 + lVar21) = 0;
  *(undefined4 *)(&stack0x000004c4 + lVar21) = 0;
  *(undefined4 *)(&stack0x000004c8 + lVar21) = 0;
  *(undefined4 *)(&stack0x00000284 + lVar21) = 0;
  *(undefined4 *)(&stack0x00000290 + lVar21) = 0;
  *(undefined4 *)(&stack0x0000026c + lVar21) = 0;
  *(undefined4 *)(&stack0x00000268 + lVar21) = 0;
  bVar7 = false;
  (&stack0x00000065)[lVar21] = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1000f5;
  func_0x();
  plVar27 = (longlong *)(&stack0x00000910 + lVar21);
  *(longlong **)(&stack0x00000088 + lVar21) = plVar27;
  (&stack0x00000064)[lVar21] = 0;
  (&stack0x00000066)[lVar21] = 0;
  (&stack0x00000080)[lVar21] = 0;
  if (plVar3 == (longlong *)0x0) {
    bVar6 = false;
  }
  else {
    if (cVar8 == '\0') {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar21) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10013c;
      (*_DAT_)(1,0x14b8350,0x1482e50,0x2a93);
    }
    *(longlong **)(&stack0x00000088 + lVar21) = plVar3;
    bVar6 = true;
    (&stack0x00000065)[lVar21] = 1;
    plVar27 = plVar3;
  }
  *(undefined8 *)(&stack0x000001d8 + lVar21) = 0;
  *(undefined4 *)(&stack0x00000078 + lVar21) = 1;
  if ((bVar6) && ((3 < *(short *)((longlong)plVar27 + 0xc) || (*plVar27 != 0)))) {
    bVar6 = true;
  }
  else {
    bVar6 = false;
  }
  if (param_1[0xbfd] != 0) {
    uVar15 = *(undefined2 *)(param_2 + 0x1c);
    uVar23 = *(undefined8 *)(*param_1 + 0x6a0);
    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10018f;
    lVar22 = func_0x(uVar23,uVar15,0);
    if (((*(byte *)(lVar22 + 0x7c) & 0x20) != 0) && ((*(byte *)(lVar22 + 0x1fc) & 4) != 0)) {
      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1001aa;
      func_0x(&stack0x000001e1 + lVar21);
      *(undefined4 *)(&stack0x00000288 + lVar21) = 1;
    }
  }
  if ((*(char *)(param_2 + 0x16) == '|') && ((*(byte *)(*param_1 + 0x1cd0) & 0x40) == 0)) {
    sVar14 = *(short *)(*(longlong *)(*param_1 + 0x6b0) + 0x28);
    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1001e1;
    cVar8 = func_0x(0x1a0df20);
    if (cVar8 != '\0') {
      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1001f0;
      lVar22 = func_0x();
      if ((((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) && (sVar14 != 1)) &&
         (sVar14 != 0x7ffb)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100215;
        cVar8 = func_0x(0x1a0df20);
        if (cVar8 == '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10022f;
          (*_DAT_)(0x22,0x44,0x15,0x26);
        }
        else {
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar21) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100252;
          (*_DAT_)(1,0x13377f8,0x1337690,0x2ac4);
        }
      }
    }
    if (bVar6) {
      pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
      if (*pplVar36 != (longlong *)0x0) {
        if (((*(ushort *)((longlong)*pplVar36 + 0x62) >> 10 & 1) == 0) ||
           (*(short *)((longlong)pplVar36 + 0xc) < 3)) {
          iVar17 = (int)*(short *)((longlong)pplVar36 + 0xc);
          plVar27 = *pplVar36;
          if (((byte)*(undefined2 *)((longlong)plVar27 + 0x62) >> 3 & 1) != 0) {
            if (iVar17 == 3) {
              iVar17 = 4;
            }
            else if (iVar17 < 2) goto LAB_;
            if ((((*(uint *)((longlong)plVar27 + 100) & 8) != 0) &&
                (lVar22 = plVar27[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0)) {
              uVar23 = *(undefined8 *)(lVar22 + 0x758);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1002e7;
              func_0x(uVar23,plVar27,iVar17);
            }
          }
LAB_:
          if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar27 + 100) & 8) != 0)) &&
              (2 < iVar17)) &&
             (((*(uint *)((longlong)plVar27 + 100) & 0xc0000000) != 0x40000000 && (*plVar27 != 0))))
          {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10031c;
            func_0x(plVar27,1);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10032b;
          func_0x(plVar27 + 0x13,iVar17);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10034a;
            func_0x(plVar27,0,iVar17);
          }
          *(undefined2 *)((longlong)pplVar36 + 0xc) = 0;
          *pplVar36 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100287;
          func_0x(pplVar36);
        }
      }
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10035f;
    iVar17 = func_0x();
    puVar4 = *(undefined8 **)(&stack0x000000a8 + lVar21);
    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100383;
    func_0x
              (*(undefined8 *)(&stack0x00000068 + lVar21),puVar4,iVar17 != 0 && sVar14 == 0x7ffb);
    lVar22 = *(longlong *)(&stack0x00007a68 + lVar21);
    if (lVar22 != 0) {
      *(longlong *)(lVar22 + 0x30) = *(longlong *)(lVar22 + 0x30) + 1;
    }
    plVar27 = (longlong *)param_1[0xbf0];
    lVar22 = *(longlong *)(&stack0x00000090 + lVar21);
    if (plVar27 != (longlong *)0x0) {
      lVar30 = *(longlong *)
                (*plVar27 +
                ((ulonglong)*(uint *)(lVar22 + 0x10) % (ulonglong)*(uint *)(plVar27 + 1)) * 8);
    }
    *(undefined8 *)(&stack0x00000368 + lVar21) = *puVar4;
    *(undefined2 *)(&stack0x00000370 + lVar21) = *(undefined2 *)(puVar4 + 1);
    *(undefined2 *)(lVar22 + 0x22) = 0xded0;
    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1003e5;
    iVar17 = func_0x(lVar22 + 0x24);
    *(undefined8 *)(lVar22 + 0x24) = *(undefined8 *)(&stack0x00000368 + lVar21);
    *(undefined2 *)(lVar22 + 0x2c) = *(undefined2 *)(&stack0x00000370 + lVar21);
    *(int *)(lVar22 + 0x30) = iVar17 + 2;
    *(undefined8 *)(&stack0x00000548 + lVar21) = *(undefined8 *)(&stack0x00000368 + lVar21);
    *(undefined2 *)(&stack0x00000550 + lVar21) = *(undefined2 *)(&stack0x00000370 + lVar21);
    puVar35 = &stack0x00000548 + lVar21;
  }
  else {
    uVar15 = *(undefined2 *)(param_2 + 0x1c);
    uVar23 = *(undefined8 *)(*param_1 + 0x6a0);
    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100448;
    lVar22 = func_0x(uVar23,uVar15,1);
    if ((*(byte *)(**(longlong **)(&stack0x00000070 + lVar21) + 0x1cd0) & 0x40) == 0) {
LAB_:
      if ((lVar22 != 0) && (*(uint *)(param_2 + 0x18) < *(uint *)(lVar22 + 0x80))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100544;
        func_0x(&stack0x000012d8 + lVar21,0,0,0);
        plVar27 = *(longlong **)(&stack0x00000070 + lVar21);
        lVar37 = *(longlong *)(*plVar27 + 0x6b0);
        if (((*(byte *)(lVar37 + 0x3c) & 1) != 0) && (*(longlong *)(lVar37 + 0x280) == 0)) {
          plVar27 = *(longlong **)(*plVar27 + 0x6c8);
          UNRECOVERED_JUMPTABLE = *(code **)(*plVar27 + 0x170);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100579;
          (*UNRECOVERED_JUMPTABLE)(plVar27,&stack0x000012d8 + lVar21);
          plVar27 = *(longlong **)(&stack0x00000070 + lVar21);
        }
        if (*(char *)(param_2 + 0x16) == '\x01') {
          if (bVar6) {
            pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
            if (*pplVar36 != (longlong *)0x0) {
              if (((*(ushort *)((longlong)*pplVar36 + 0x62) >> 10 & 1) == 0) ||
                 (*(short *)((longlong)pplVar36 + 0xc) < 3)) {
                iVar17 = (int)*(short *)((longlong)pplVar36 + 0xc);
                plVar27 = *pplVar36;
                if (((byte)*(undefined2 *)((longlong)plVar27 + 0x62) >> 3 & 1) != 0) {
                  if (iVar17 == 3) {
                    iVar17 = 4;
                  }
                  else if (iVar17 < 2) goto LAB_;
                  if ((((*(uint *)((longlong)plVar27 + 100) & 8) != 0) &&
                      (lVar37 = plVar27[0x12], lVar37 != 0)) && (*(longlong *)(lVar37 + 0x758) != 0)
                     ) {
                    uVar23 = *(undefined8 *)(lVar37 + 0x758);
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100617;
                    func_0x(uVar23,plVar27,iVar17);
                  }
                }
LAB_:
                if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar27 + 100) & 8) != 0)
                    ) && ((2 < iVar17 &&
                          (((*(uint *)((longlong)plVar27 + 100) & 0xc0000000) != 0x40000000 &&
                           (*plVar27 != 0)))))) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10064c;
                  func_0x(plVar27,1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10065b;
                func_0x(plVar27 + 0x13,iVar17);
                if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10067a;
                  func_0x(plVar27,0,iVar17);
                }
                *(undefined2 *)((longlong)pplVar36 + 0xc) = 0;
                *pplVar36 = (longlong *)0x0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1005b9;
                func_0x(pplVar36);
              }
            }
          }
          if ((&stack0x00000065)[lVar21] != '\0') {
            LOCK();
            iVar17 = *(int *)(*(longlong *)(&stack0x00000090 + lVar21) + 0x9c);
            if (iVar17 == 0) {
              *(int *)(*(longlong *)(&stack0x00000090 + lVar21) + 0x9c) = 0;
              iVar17 = 0;
            }
            UNLOCK();
            if (iVar17 == 0) {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar21) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1006bc;
              (*_DAT_)(1,0x14b8310,0x1482e50,0x2b0c);
            }
          }
          plVar27 = *(longlong **)(&stack0x00000070 + lVar21);
          lVar37 = *(longlong *)(&stack0x00000068 + lVar21);
          if ((*(int *)(plVar27 + 4) == 1) && (*(char *)(lVar37 + 0x33) == '\x01')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1006ed;
            func_0x(&stack0x00000790 + lVar21,0,0,0);
            puVar4 = *(undefined8 **)(&stack0x000000a8 + lVar21);
            *(undefined8 *)(&stack0x00000568 + lVar21) = *puVar4;
            *(undefined2 *)(&stack0x00000570 + lVar21) = *(undefined2 *)(puVar4 + 1);
            *(undefined *)((longlong)&lStackX_8 + lVar21) = 0;
            *(undefined *)((longlong)&uStackX_20 + lVar21 + -0x20) = 0;
            (&stack0xfffffffffffffff8)[lVar21] = 0;
            (&stack0xfffffffffffffff0)[lVar21] = (&stack0x00000066)[lVar21];
            (&stack0xffffffffffffffe8)[lVar21] = (&stack0x00000064)[lVar21];
            (&stack0xffffffffffffffe0)[lVar21] = 1;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100745;
            func_0x(plVar27,lVar37,&stack0x00000568 + lVar21,&stack0x00000790 + lVar21);
            lVar22 = *(longlong *)(&stack0x00007a68 + lVar21);
            if (lVar22 != 0) {
              *(longlong *)(lVar22 + 0x30) = *(longlong *)(lVar22 + 0x30) + 1;
            }
            plVar27 = (longlong *)plVar27[0xbf0];
            lVar22 = *(longlong *)(&stack0x00000090 + lVar21);
            if (plVar27 != (longlong *)0x0) {
              lVar30 = *(longlong *)
                        (*plVar27 +
                        ((ulonglong)*(uint *)(lVar22 + 0x10) % (ulonglong)*(uint *)(plVar27 + 1)) *
                        8);
            }
            *(undefined8 *)(&stack0x00000348 + lVar21) = *puVar4;
            *(undefined2 *)(&stack0x00000350 + lVar21) = *(undefined2 *)(puVar4 + 1);
            *(undefined2 *)(lVar22 + 0x22) = 0xfed0;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1007a7;
            iVar17 = func_0x(lVar22 + 0x24);
            *(undefined8 *)(lVar22 + 0x24) = *(undefined8 *)(&stack0x00000348 + lVar21);
            *(undefined2 *)(lVar22 + 0x2c) = *(undefined2 *)(&stack0x00000350 + lVar21);
            *(int *)(lVar22 + 0x30) = iVar17 + 2;
            *(undefined8 *)(&stack0x00000578 + lVar21) = *(undefined8 *)(&stack0x00000348 + lVar21);
            *(undefined2 *)(&stack0x00000580 + lVar21) = *(undefined2 *)(&stack0x00000350 + lVar21);
            puVar35 = &stack0x00000578 + lVar21;
            goto LAB_;
          }
          if (((*(byte *)(*(longlong *)(*plVar27 + 0x6b0) + 0x3c) & 1) == 0) ||
             (*(longlong *)(*(longlong *)(*plVar27 + 0x6b0) + 0x280) != 0)) {
            uVar10 = 0;
          }
          else {
            uVar20 = *(undefined4 *)(lVar37 + 0x18);
            uVar23 = *(undefined8 *)(&stack0x000000a8 + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100831;
            (*_DAT_)(lVar22,uVar23,&stack0x000012d8 + lVar21,uVar20);
            if ((&stack0x00007a58)[lVar21] == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10084a;
              cVar9 = func_0x(0x1a0df20);
              if (cVar9 == '\0') {
                uVar10 = 0;
                *(undefined **)(&stack0xffffffffffffffe8 + lVar21) = &stack0x00000066 + lVar21;
                *(undefined **)(&stack0xffffffffffffffe0 + lVar21) = &stack0x00000064 + lVar21;
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100877;
                iVar17 = func_0x(plVar27,lVar22,lVar37,uVar23);
                if (iVar17 != 0) {
                  plVar27 = (longlong *)plVar27[0xbf0];
                  lVar22 = *(longlong *)(&stack0x00000090 + lVar21);
                  if (plVar27 != (longlong *)0x0) {
                    lVar30 = *(longlong *)
                              (*plVar27 +
                              ((ulonglong)*(uint *)(lVar22 + 0x10) %
                              (ulonglong)*(uint *)(plVar27 + 1)) * 8);
                  }
                  *(undefined8 *)(&stack0x00000338 + lVar21) =
                       **(undefined8 **)(&stack0x000000a8 + lVar21);
                  *(undefined2 *)(&stack0x00000340 + lVar21) =
                       *(undefined2 *)(*(undefined8 **)(&stack0x000000a8 + lVar21) + 1);
                  *(undefined2 *)(lVar22 + 0x22) = 0x5ed0;
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1008d1;
                  iVar17 = func_0x(lVar22 + 0x24);
                  *(undefined8 *)(lVar22 + 0x24) = *(undefined8 *)(&stack0x00000338 + lVar21);
                  *(undefined2 *)(lVar22 + 0x2c) = *(undefined2 *)(&stack0x00000340 + lVar21);
                  *(int *)(lVar22 + 0x30) = iVar17 + 2;
                  *(undefined8 *)(&stack0x00000538 + lVar21) =
                       *(undefined8 *)(&stack0x00000338 + lVar21);
                  *(undefined2 *)(&stack0x00000540 + lVar21) =
                       *(undefined2 *)(&stack0x00000340 + lVar21);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100921;
                  func_0x(lVar22,&stack0x00000538 + lVar21,lVar30);
                  lVar30 = *(longlong *)(&stack0x00007a68 + lVar21);
                  if (lVar30 != 0) {
                    *(longlong *)(lVar30 + 0x18) = *(longlong *)(lVar30 + 0x18) + 1;
                  }
                  goto LAB_;
                }
                goto LAB_;
              }
            }
            uVar10 = 1;
          }
LAB_:
          *(undefined4 *)(&stack0x000003e0 + lVar21) = *(undefined4 *)(lVar37 + 0x18);
          *(undefined2 *)(&stack0x000003e4 + lVar21) = *(undefined2 *)(lVar37 + 0x1c);
          (&stack0xffffffffffffffe8)[lVar21] = cVar8;
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar21) = 0;
          lVar25 = *plVar27;
          pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100987;
          func_0x(_DAT_,pplVar36,lVar25,&stack0x000003e0 + lVar21);
          lVar25 = *(longlong *)(&stack0x00007a68 + lVar21);
          if (lVar25 != 0) {
            *(longlong *)(lVar25 + 0x10) = *(longlong *)(lVar25 + 0x10) + 1;
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1009af;
          func_0x(&stack0x000007b0 + lVar21,1);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1009bd;
          func_0x(pplVar36,0,0);
          plVar3 = *pplVar36;
          *(undefined4 *)(&stack0x000003e6 + lVar21) = *(undefined4 *)(lVar37 + 0x18);
          *(undefined2 *)(&stack0x000003ea + lVar21) = *(undefined2 *)(lVar37 + 0x1c);
          if (*(int *)(*(longlong *)(*plVar27 + 0x7a8) + 0x110) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1009fb;
            iVar17 = func_0x(&stack0x000003e6 + lVar21,8);
            if (iVar17 == 0) {
              *(undefined4 *)(&stack0x000003ec + lVar21) = *(undefined4 *)(lVar37 + 0x18);
              *(undefined2 *)(&stack0x000003f0 + lVar21) = *(undefined2 *)(lVar37 + 0x1c);
              uVar23 = *(undefined8 *)(*plVar27 + 0x7a8);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100a2c;
              func_0x(uVar23,&stack0x000003ec + lVar21);
            }
          }
          if ((*(short *)(lVar37 + 2) == 0x4c) || (*(short *)(lVar37 + 0x50) == 0)) {
            uVar15 = *(undefined2 *)(lVar37 + 0x2e);
            uVar20 = *(undefined4 *)(lVar37 + 0x20);
            *(undefined4 *)(&stack0x0000027c + lVar21) = *(undefined4 *)(lVar37 + 0x18);
            *(undefined2 *)(&stack0x00000280 + lVar21) = *(undefined2 *)(lVar37 + 0x1c);
            if ((*(uint *)(lVar22 + 100) >> 8 & 1) != 0) {
              *(undefined2 *)(&stack0x00000280 + lVar21) = *(undefined2 *)(lVar22 + 0x5f0);
            }
            *(undefined4 *)(&stack0x00000478 + lVar21) = uVar20;
            *(undefined2 *)(&stack0x0000047c + lVar21) = uVar15;
            *(undefined2 *)(&stack0x0000047e + lVar21) = 0;
            *(undefined8 *)((longlong)&uStackX_10 + lVar21) =
                 *(undefined8 *)(&stack0x000000a8 + lVar21);
            *(longlong *)((longlong)&lStackX_8 + lVar21) = lVar37 + 0x3c;
            *(longlong *)((longlong)&uStackX_20 + lVar21 + -0x20) = lVar37 + 0x34;
            (&stack0xfffffffffffffff8)[lVar21] = *(undefined *)(lVar37 + 0x32);
            *(undefined2 *)(&stack0xfffffffffffffff0 + lVar21) = *(undefined2 *)(lVar37 + 0x3a);
            (&stack0xffffffffffffffe8)[lVar21] = *(undefined *)(lVar37 + 0x31);
            *(undefined2 *)(&stack0xffffffffffffffe0 + lVar21) = *(undefined2 *)(lVar37 + 0x42);
            uVar1 = *(undefined *)(lVar37 + 0x30);
            lVar22 = *plVar3;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100b04;
            func_0x(lVar22,uVar1,&stack0x0000027c + lVar21,&stack0x00000478 + lVar21);
            lVar22 = *plVar3;
            cVar8 = *(char *)(lVar22 + 1);
            if (cVar8 == '\n') {
              uVar20 = *(undefined4 *)(lVar37 + 0x4c);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100b59;
              func_0x(lVar22,lVar37 + 0x44,uVar20);
            }
            else if (cVar8 == '\x10') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100b3b;
              uVar23 = func_0x();
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100b4a;
              func_0x(uVar23,&stack0x0000027c + lVar21);
            }
            else if (cVar8 == '\x11') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100b1f;
              uVar23 = func_0x();
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100b34;
              func_0x(uVar23,&stack0x0000027c + lVar21,0x11,0);
            }
          }
          else {
            lVar22 = *plVar3;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100a47;
            func_0x(lVar37,lVar22);
            lVar22 = *plVar3;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100a55;
            func_0x(plVar27,lVar37,lVar22);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100b6d;
          func_0x(&stack0x000007a0 + lVar21,0,0,0);
          *(undefined8 *)(&stack0x00000588 + lVar21) = **(undefined8 **)(&stack0x000000a8 + lVar21);
          *(undefined2 *)(&stack0x00000590 + lVar21) =
               *(undefined2 *)(*(undefined8 **)(&stack0x000000a8 + lVar21) + 1);
          *(undefined *)((longlong)&lStackX_8 + lVar21) = 0;
          *(undefined *)((longlong)&uStackX_20 + lVar21 + -0x20) = 0;
          (&stack0xfffffffffffffff8)[lVar21] = uVar10;
          (&stack0xfffffffffffffff0)[lVar21] = (&stack0x00000066)[lVar21];
          (&stack0xffffffffffffffe8)[lVar21] = (&stack0x00000064)[lVar21];
          (&stack0xffffffffffffffe0)[lVar21] = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100bc4;
          func_0x(plVar27,lVar37,&stack0x00000588 + lVar21,&stack0x000007a0 + lVar21);
          uVar15 = *(undefined2 *)((longlong)plVar3 + 0x62);
          *(undefined4 *)(&stack0x000003f4 + lVar21) = *(undefined4 *)(lVar37 + 0x18);
          *(undefined2 *)(&stack0x000003f8 + lVar21) = *(undefined2 *)(lVar37 + 0x1c);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100bf0;
          uVar10 = func_0x(&stack0x000003f4 + lVar21);
          puVar4 = *(undefined8 **)(&stack0x000000a8 + lVar21);
          lVar22 = *plVar3;
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100c07;
          func_0x(lVar22,puVar4,uVar10,(byte)uVar15 >> 3 & 1);
          plVar5 = (longlong *)plVar27[0xbf0];
          lVar22 = *(longlong *)(&stack0x00000090 + lVar21);
          if (plVar5 != (longlong *)0x0) {
            lVar30 = *(longlong *)
                      (*plVar5 +
                      ((ulonglong)*(uint *)(lVar22 + 0x10) % (ulonglong)*(uint *)(plVar5 + 1)) * 8);
          }
          *(undefined8 *)(&stack0x000003b8 + lVar21) = *puVar4;
          *(undefined2 *)(&stack0x000003c0 + lVar21) = *(undefined2 *)(puVar4 + 1);
          *(undefined2 *)(lVar22 + 0x22) = 0xfed0;
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100c53;
          iVar17 = func_0x(lVar22 + 0x24);
          *(undefined8 *)(lVar22 + 0x24) = *(undefined8 *)(&stack0x000003b8 + lVar21);
          *(undefined2 *)(lVar22 + 0x2c) = *(undefined2 *)(&stack0x000003c0 + lVar21);
          *(int *)(lVar22 + 0x30) = iVar17 + 2;
          *(undefined8 *)(&stack0x00000598 + lVar21) = *(undefined8 *)(&stack0x000003b8 + lVar21);
          *(undefined2 *)(&stack0x000005a0 + lVar21) = *(undefined2 *)(&stack0x000003c0 + lVar21);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100ca6;
          func_0x(lVar22,&stack0x00000598 + lVar21,lVar30);
          if (*(int *)(&stack0x00000288 + lVar21) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100cc0;
            func_0x(plVar3,1);
          }
          puVar4 = *(undefined8 **)(&stack0x00000088 + lVar21);
          if ((*(byte *)((longlong)plVar27 + 0x24) & 4) != 0) {
            uVar23 = *puVar4;
            uVar24 = *(undefined8 *)(*plVar27 + 0x758);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100ce2;
            func_0x(uVar24,uVar23,1);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100cf6;
          func_0x(&stack0x000014a0 + lVar21,0,0,0);
          uVar23 = *puVar4;
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100d0f;
          func_0x(_DAT_,uVar23,0,&stack0x000014a0 + lVar21);
          if (lVar25 != 0) {
            *(longlong *)(lVar25 + 0x30) = *(longlong *)(lVar25 + 0x30) + 1;
          }
          *(uint *)(*(longlong *)(&stack0x000007b8 + lVar21) + 0x268) =
               *(uint *)(*(longlong *)(&stack0x000007b8 + lVar21) + 0x268) &
               ~*(uint *)(&stack0x000007b0 + lVar21);
          goto LAB_;
        }
        uVar23 = *(undefined8 *)(*(longlong *)(*plVar27 + 0x6b0) + 0x1210);
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100d4f;
        iVar17 = func_0x(uVar23);
        if (((iVar17 == 1) && (*(char *)(param_2 + 0x16) == '\x04')) &&
           (*(char *)(param_2 + 0x17) == '\x14')) {
          if (bVar6) {
            pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
            if (*pplVar36 != (longlong *)0x0) {
              if (((*(ushort *)((longlong)*pplVar36 + 0x62) >> 10 & 1) == 0) ||
                 (*(short *)((longlong)pplVar36 + 0xc) < 3)) {
                iVar17 = (int)*(short *)((longlong)pplVar36 + 0xc);
                plVar27 = *pplVar36;
                if (((byte)*(undefined2 *)((longlong)plVar27 + 0x62) >> 3 & 1) != 0) {
                  if (iVar17 == 3) {
                    iVar17 = 4;
                  }
                  else if (iVar17 < 2) goto LAB_;
                  if ((((*(uint *)((longlong)plVar27 + 100) & 8) != 0) &&
                      (lVar37 = plVar27[0x12], lVar37 != 0)) && (*(longlong *)(lVar37 + 0x758) != 0)
                     ) {
                    uVar23 = *(undefined8 *)(lVar37 + 0x758);
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100df5;
                    func_0x(uVar23,plVar27,iVar17);
                  }
                }
LAB_:
                if (((((DAT_ & 0x80) != 0) &&
                     ((*(uint *)((longlong)plVar27 + 100) & 8) != 0)) && (2 < iVar17)) &&
                   (((*(uint *)((longlong)plVar27 + 100) & 0xc0000000) != 0x40000000 &&
                    (*plVar27 != 0)))) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100e29;
                  func_0x(plVar27,1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100e37;
                func_0x(plVar27 + 0x13,iVar17);
                if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100e56;
                  func_0x(plVar27,0,iVar17);
                }
                puVar4 = *(undefined8 **)(&stack0x00000088 + lVar21);
                *(undefined2 *)((longlong)puVar4 + 0xc) = 0;
                *puVar4 = 0;
                param_2 = *(longlong *)(&stack0x00000068 + lVar21);
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100d9b;
                func_0x();
              }
            }
          }
          if ((&stack0x00000065)[lVar21] != '\0') {
            LOCK();
            iVar17 = *(int *)(*(longlong *)(&stack0x00000090 + lVar21) + 0x9c);
            if (iVar17 == 0) {
              *(int *)(*(longlong *)(&stack0x00000090 + lVar21) + 0x9c) = 0;
              iVar17 = 0;
            }
            UNLOCK();
            if (iVar17 == 0) {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar21) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100ea0;
              (*_DAT_)(1,0x14b8310,0x1482e50,0x2c11);
            }
          }
          if (*(short *)(param_2 + 0x38) == 0x2fc) {
            (&stack0x000000a0)[lVar21] = 0;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100ec5;
            func_0x(param_2 + 0x3e,0,&stack0x00000660 + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100ed7;
            uVar24 = func_0x(param_2 + 0x3e,1,&stack0x00000664 + lVar21);
            uVar23 = *(undefined8 *)(**(longlong **)(&stack0x00000070 + lVar21) + 0x6b0);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100ef8;
            iVar17 = func_0x
                               (uVar23,uVar24,&stack0x000000a0 + lVar21,&stack0x000001e0 + lVar21);
            if (iVar17 < 0) {
              uVar23 = 0x13377e0;
              if ((&stack0x000001e0)[lVar21] != '\0') {
                uVar23 = 0x108eed8;
              }
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar21) = uVar23;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100f2f;
              (*_DAT_)(0x22,0x3d,0x15,1);
            }
            if ((&stack0x000000a0)[lVar21] != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100f3c;
              func_0x(0x9e);
            }
          }
        }
        plVar27 = *(longlong **)(&stack0x00000070 + lVar21);
        lVar37 = *(longlong *)(&stack0x00007a68 + lVar21);
        if (((*(byte *)(*(longlong *)(*plVar27 + 0x6b0) + 0x3c) & 1) != 0) &&
           (*(longlong *)(*(longlong *)(*plVar27 + 0x6b0) + 0x280) == 0)) {
          lVar25 = *(longlong *)(&stack0x00000068 + lVar21);
          if ((*(byte *)(lVar22 + 100) & 0x40) == 0) {
            uVar20 = *(undefined4 *)(lVar25 + 0x18);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100f8c;
            (*_DAT_)(lVar22,*(undefined8 *)(&stack0x000000a8 + lVar21),
                             &stack0x000012d8 + lVar21,uVar20);
          }
          if (*(short *)(*(longlong *)(&stack0x00000088 + lVar21) + 0xc) < 4) {
            if ((&stack0x00007a58)[lVar21] == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100fb3;
              cVar9 = func_0x(plVar27,lVar25);
              if (cVar9 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x100fc7;
                cVar9 = func_0x(0x1a0df20);
                if (cVar9 == '\0') {
                  (&stack0x00000080)[lVar21] = 0;
                  if (lVar37 != 0) {
                    *(longlong *)(lVar37 + 0x28) = *(longlong *)(lVar37 + 0x28) + 1;
                  }
                  *(undefined **)(&stack0xffffffffffffffe8 + lVar21) = &stack0x00000066 + lVar21;
                  *(undefined **)(&stack0xffffffffffffffe0 + lVar21) = &stack0x00000064 + lVar21;
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101006;
                  iVar17 = func_0x(plVar27,lVar22,lVar25,
                                           *(undefined8 *)(&stack0x000000a8 + lVar21));
                  if (iVar17 != 0) {
                    plVar3 = (longlong *)plVar27[0xbf0];
                    lVar25 = *(longlong *)(&stack0x00000090 + lVar21);
                    lVar26 = lVar30;
                    if (plVar3 != (longlong *)0x0) {
                      lVar26 = *(longlong *)
                                (*plVar3 +
                                ((ulonglong)*(uint *)(lVar25 + 0x10) %
                                (ulonglong)*(uint *)(plVar3 + 1)) * 8);
                    }
                    *(undefined8 *)(&stack0x000003a8 + lVar21) =
                         **(undefined8 **)(&stack0x000000a8 + lVar21);
                    *(undefined2 *)(&stack0x000003b0 + lVar21) =
                         *(undefined2 *)(*(undefined8 **)(&stack0x000000a8 + lVar21) + 1);
                    *(undefined2 *)(lVar25 + 0x22) = 0x5ed0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101062;
                    iVar17 = func_0x(lVar25 + 0x24);
                    *(undefined8 *)(lVar25 + 0x24) = *(undefined8 *)(&stack0x000003a8 + lVar21);
                    *(undefined2 *)(lVar25 + 0x2c) = *(undefined2 *)(&stack0x000003b0 + lVar21);
                    *(int *)(lVar25 + 0x30) = iVar17 + 2;
                    *(undefined8 *)(&stack0x000005a8 + lVar21) =
                         *(undefined8 *)(&stack0x000003a8 + lVar21);
                    *(undefined2 *)(&stack0x000005b0 + lVar21) =
                         *(undefined2 *)(&stack0x000003b0 + lVar21);
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1010b5;
                    func_0x(lVar25,&stack0x000005a8 + lVar21,lVar26);
                    if (((((*(byte *)(lVar22 + 100) & 0x40) == 0) &&
                         ((&stack0x00000065)[lVar21] != '\0')) && (plVar27[0x108a] != 0)) &&
                       ((*(byte *)(plVar27[0x108a] + 0x210) & 0x10) != 0)) {
                      LOCK();
                      iVar17 = *(int *)(lVar25 + 0x9c);
                      if (iVar17 == 0) {
                        *(int *)(lVar25 + 0x9c) = 0;
                        iVar17 = 0;
                      }
                      UNLOCK();
                      if (iVar17 == 0) {
                        *(undefined8 *)(&stack0x00000480 + lVar21) = 0;
                        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10111a;
                        func_0x(lVar25,&stack0x000012e8 + lVar21,&stack0x00000480 + lVar21);
                        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10112e;
                        func_0x(&stack0x00001490 + lVar21,0,0,0);
                        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101141;
                        iVar17 = func_0x
                                           (&stack0x000012e8 + lVar21,&stack0x00001490 + lVar21);
                        if (iVar17 == 0) {
                          LOCK();
                          iVar17 = *(int *)(lVar25 + 0x9c);
                          if (iVar17 == 0) {
                            *(int *)(lVar25 + 0x9c) = 0;
                            iVar17 = 0;
                          }
                          UNLOCK();
                          if (iVar17 == 0) {
                            if (*(longlong *)(&stack0x00000480 + lVar21) == 0) {
                              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar21) = 0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101186;
                              (*_DAT_)(1,0x14b8360,0x1482e50,0x2c8b);
                            }
                            uVar20 = *(undefined4 *)
                                      (*(longlong *)(&stack0x00000068 + lVar21) + 0x18);
                            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1011a5;
                            (*_DAT_)(lVar22,&stack0x000012e8 + lVar21,
                                             &stack0x000012d8 + lVar21,uVar20);
                            if (lVar37 != 0) {
                              *(longlong *)(lVar37 + 0x28) = *(longlong *)(lVar37 + 0x28) + 1;
                            }
                            *(undefined **)(&stack0xffffffffffffffe8 + lVar21) =
                                 &stack0x00000066 + lVar21;
                            *(undefined **)(&stack0xffffffffffffffe0 + lVar21) =
                                 &stack0x00000064 + lVar21;
                            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1011e0;
                            iVar17 = func_0x(plVar27,lVar22,
                                                     *(undefined8 *)(&stack0x00000480 + lVar21),
                                                     &stack0x000012e8 + lVar21);
                            if (iVar17 != 0) {
                              plVar27 = (longlong *)plVar27[0xbf0];
                              if (plVar27 != (longlong *)0x0) {
                                lVar30 = *(longlong *)
                                          (*plVar27 +
                                          ((ulonglong)*(uint *)(lVar25 + 0x10) %
                                          (ulonglong)*(uint *)(plVar27 + 1)) * 8);
                              }
                              *(undefined8 *)(&stack0x00000398 + lVar21) =
                                   *(undefined8 *)(&stack0x000012e8 + lVar21);
                              *(undefined2 *)(&stack0x000003a0 + lVar21) =
                                   *(undefined2 *)(&stack0x000012f0 + lVar21);
                              *(undefined2 *)(lVar25 + 0x22) = 0x5ed0;
                              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101237;
                              iVar17 = func_0x(lVar25 + 0x24);
                              *(undefined8 *)(lVar25 + 0x24) =
                                   *(undefined8 *)(&stack0x00000398 + lVar21);
                              *(undefined2 *)(lVar25 + 0x2c) =
                                   *(undefined2 *)(&stack0x000003a0 + lVar21);
                              *(int *)(lVar25 + 0x30) = iVar17 + 2;
                              *(undefined8 *)(&stack0x000005b8 + lVar21) =
                                   *(undefined8 *)(&stack0x00000398 + lVar21);
                              *(undefined2 *)(&stack0x000005c0 + lVar21) =
                                   *(undefined2 *)(&stack0x000003a0 + lVar21);
                              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10128a;
                              uVar18 = func_0x(lVar25,&stack0x000005b8 + lVar21,lVar30);
                              if (lVar37 != 0) {
                                *(ulonglong *)(lVar37 + 0x20) =
                                     *(longlong *)(lVar37 + 0x20) + (ulonglong)uVar18;
                                *(longlong *)(lVar37 + 0x18) = *(longlong *)(lVar37 + 0x18) + 1;
                              }
                              goto LAB_;
                            }
                          }
                        }
                      }
                    }
                    if (lVar37 != 0) {
                      *(longlong *)(lVar37 + 0x18) = *(longlong *)(lVar37 + 0x18) + 1;
                    }
                    goto LAB_;
                  }
                  goto LAB_;
                }
              }
            }
            (&stack0x00000080)[lVar21] = 1;
          }
          else {
            (&stack0x00000064)[lVar21] = 1;
          }
        }
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1012d8;
        lVar25 = func_0x();
        *(longlong *)(&stack0x00000098 + lVar21) = lVar25;
        if (lVar25 != 0) {
          *(undefined *)(lVar25 + 0x49e) = 0;
        }
        *(undefined8 *)(&stack0x000000f0 + lVar21) = 2;
        pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
        if (((&stack0x00000065)[lVar21] == '\0') || (*(short *)((longlong)pplVar36 + 0xc) < 4)) {
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101322;
          func_0x(&stack0x000015e8 + lVar21);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10132e;
          cVar9 = func_0x(0x1a0df20);
          if ((cVar9 == '\0') || ((*(uint *)((longlong)plVar27 + 0x24) >> 7 & 1) == 0)) {
            *(undefined4 *)(&stack0x000001ec + lVar21) =
                 *(undefined4 *)(*(longlong *)(&stack0x00000068 + lVar21) + 0x18);
            *(undefined2 *)(&stack0x000001f0 + lVar21) =
                 *(undefined2 *)(*(longlong *)(&stack0x00000068 + lVar21) + 0x1c);
            lVar25 = *plVar27;
            lVar26 = lVar30;
            if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
              lVar29 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
              if ((lVar29 != 0) && (lVar29 = **(longlong **)(lVar29 + 0x38), lVar29 != 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101405;
                iVar17 = (*_DAT_)(lVar29,0x337);
                if (iVar17 != 0) goto LAB_;
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10140e;
              lVar26 = func_0x();
            }
LAB_:
            *(undefined8 *)(&stack0x00000058 + lVar21) = *(undefined8 *)(lVar25 + 0x728);
            *(undefined4 *)(&stack0x00000278 + lVar21) = 0;
            if (*pplVar36 != (longlong *)0x0) {
              if (((*(ushort *)((longlong)*pplVar36 + 0x62) >> 10 & 1) == 0) ||
                 (*(short *)((longlong)pplVar36 + 0xc) < 3)) {
                iVar17 = (int)*(short *)((longlong)pplVar36 + 0xc);
                plVar27 = *pplVar36;
                if (((byte)*(undefined2 *)((longlong)plVar27 + 0x62) >> 3 & 1) != 0) {
                  if (iVar17 == 3) {
                    iVar17 = 4;
                  }
                  else if (iVar17 < 2) goto LAB_;
                  if ((((*(uint *)((longlong)plVar27 + 100) & 8) != 0) &&
                      (lVar29 = plVar27[0x12], lVar29 != 0)) && (*(longlong *)(lVar29 + 0x758) != 0)
                     ) {
                    uVar23 = *(undefined8 *)(lVar29 + 0x758);
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1014ac;
                    func_0x(uVar23,plVar27,iVar17);
                  }
                }
LAB_:
                if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar27 + 100) & 8) != 0)
                    ) && ((2 < iVar17 &&
                          (((*(uint *)((longlong)plVar27 + 100) & 0xc0000000) != 0x40000000 &&
                           (*plVar27 != 0)))))) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1014e4;
                  func_0x(plVar27,1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1014f3;
                func_0x(plVar27 + 0x13,iVar17);
                if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101512;
                  func_0x(plVar27,0,iVar17);
                }
                pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
                *(undefined2 *)((longlong)pplVar36 + 0xc) = 0;
                *pplVar36 = (longlong *)0x0;
                cVar8 = (&stack0x00000060)[lVar21];
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10144e;
                func_0x(pplVar36);
              }
            }
            if ((*(longlong *)(lVar25 + 0x728) != 0) && (cVar8 == '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10154c;
              func_0x(pplVar36,&stack0x000001ec + lVar21,lVar25);
              if (*pplVar36 != (longlong *)0x0) {
                if (((*(ushort *)((longlong)*pplVar36 + 0x62) >> 10 & 1) == 0) ||
                   (*(short *)((longlong)pplVar36 + 0xc) < 3)) {
                  iVar17 = (int)*(short *)((longlong)pplVar36 + 0xc);
                  plVar27 = *pplVar36;
                  if (((byte)*(undefined2 *)((longlong)plVar27 + 0x62) >> 3 & 1) != 0) {
                    if (iVar17 == 3) {
                      iVar17 = 4;
                    }
                    else if (iVar17 < 2) goto LAB_;
                    if ((((*(uint *)((longlong)plVar27 + 100) & 8) != 0) &&
                        (lVar29 = plVar27[0x12], lVar29 != 0)) &&
                       (*(longlong *)(lVar29 + 0x758) != 0)) {
                      uVar23 = *(undefined8 *)(lVar29 + 0x758);
                      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1015d0;
                      func_0x(uVar23,plVar27,iVar17);
                    }
                  }
LAB_:
                  if ((((DAT_ & 0x80) != 0) &&
                      ((*(uint *)((longlong)plVar27 + 100) & 8) != 0)) &&
                     ((2 < iVar17 &&
                      (((*(uint *)((longlong)plVar27 + 100) & 0xc0000000) != 0x40000000 &&
                       (*plVar27 != 0)))))) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101608;
                    func_0x(plVar27,1);
                  }
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101617;
                  func_0x(plVar27 + 0x13,iVar17);
                  if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101636;
                    func_0x(plVar27,0,iVar17);
                  }
                  pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
                  *(undefined2 *)((longlong)pplVar36 + 0xc) = 0;
                  *pplVar36 = (longlong *)0x0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101572;
                  func_0x(pplVar36);
                }
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101651;
            func_0x(lVar25,&stack0x000001ec + lVar21);
            *(undefined **)(&stack0xffffffffffffffe8 + lVar21) = &stack0x000004c0 + lVar21;
            *(undefined4 *)(&stack0xffffffffffffffe0 + lVar21) = 4;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101685;
            plVar27 = (longlong *)
                      func_0x
                                (_DAT_,lVar25,&stack0x000001ec + lVar21,
                                 &stack0x00000278 + lVar21);
            *pplVar36 = plVar27;
            *(undefined2 *)((longlong)pplVar36 + 0xc) = 4;
            if (lVar26 != 0) {
              uVar28 = (ulonglong)(*(uint *)(lVar26 + 0x500) & 0xf);
              if (*(longlong *)(lVar26 + 0x508 + uVar28 * 8) != *plVar27) {
                *(longlong *)(lVar26 + 0x508 + uVar28 * 8) = *plVar27;
                *(longlong *)(lVar26 + 0x500) = *(longlong *)(lVar26 + 0x500) + 1;
              }
            }
            *(byte *)((longlong)pplVar36 + 0xf) =
                 (byte)(*(uint *)(&stack0x00000278 + lVar21) >> 3) & 1;
            *(byte *)(pplVar36 + 2) = (byte)(*(uint *)(&stack0x00000278 + lVar21) >> 4) & 1;
            if (((*(longlong *)(&stack0x00000058 + lVar21) != 0) && (lVar26 != 0)) &&
               (lVar26 == *(longlong *)(lVar25 + 0x1c38))) {
              cVar8 = *(char *)((longlong)pplVar36 + 0xf);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101702;
              func_0x(*(longlong *)(&stack0x00000058 + lVar21) + 0x59b8,(int)cVar8,
                              &stack0x000004c0 + lVar21);
            }
            if (((((*(byte *)(*(longlong *)(lVar25 + 0x6b0) + 0x3c) & 1) == 0) ||
                 (*(longlong *)(*(longlong *)(lVar25 + 0x6b0) + 0x280) != 0)) ||
                ((*(char *)(lVar25 + 0x2050) == '\0' || (*(int *)(&stack0x000001ec + lVar21) == 0)))
                ) || ((*(int *)(&stack0x000001ec + lVar21) == 9 &&
                      (*(short *)(&stack0x000001f0 + lVar21) == 1)))) {
LAB_:
              plVar27 = *pplVar36;
            }
            else {
              lVar26 = **pplVar36;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101769;
              func_0x(&stack0x000013a0 + lVar21,0,0,0);
              *(undefined2 *)(&stack0x000013aa + lVar21) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101784;
              func_0x(lVar25 + 0x20fc,&stack0x000013a0 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101799;
              uVar23 = func_0x(lVar26,&stack0x000015c0 + lVar21,0,0);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1017a8;
              iVar17 = func_0x(&stack0x000013a0 + lVar21,uVar23);
              if (iVar17 == 0) {
LAB_:
                pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
                goto LAB_;
              }
              if (*(char *)(lVar25 + 0x6ac8) == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1017c5;
                cVar8 = func_0x(lVar25);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1017d5;
                  cVar8 = func_0x(lVar25);
                  if (cVar8 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1017f1;
                    func_0x(&stack0x00001380 + lVar21,0,0,0);
                    *(undefined2 *)(&stack0x0000138a + lVar21) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10180c;
                    func_0x(lVar25 + 0x20fc,&stack0x00001380 + lVar21);
                    *(undefined8 *)(&stack0x00001390 + lVar21) =
                         *(undefined8 *)(&stack0x00001380 + lVar21);
                    *(undefined2 *)(&stack0x00001398 + lVar21) =
                         *(undefined2 *)(&stack0x00001388 + lVar21);
                    pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
                    lVar26 = **pplVar36;
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101846;
                    func_0x(lVar26,&stack0x000013b0 + lVar21,0,0);
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101859;
                    iVar17 = func_0x
                                       (&stack0x00001390 + lVar21,&stack0x000013b0 + lVar21);
                    if (iVar17 == 0) goto LAB_;
                    lVar26 = *(longlong *)(lVar25 + 0x6b0);
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101882;
                    func_0x(&stack0x000013b0 + lVar21,&stack0x00001810 + lVar21,
                                    &stack0x00000460 + lVar21);
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10189c;
                    func_0x(&stack0x00001390 + lVar21,&stack0x000017e0 + lVar21,
                                    &stack0x00000460 + lVar21);
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1018a1;
                    iVar17 = func_0x();
                    if (iVar17 != 0) {
                      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1018b5;
                      func_0x(&stack0x00000cc0 + lVar21);
                      *(uint *)(&stack0x00000f20 + lVar21) = (uint)*(ushort *)(lVar25 + 0x6b8);
                      *(undefined2 *)(&stack0x00000f24 + lVar21) =
                           *(undefined2 *)(&stack0x000001f0 + lVar21);
                      *(undefined4 *)(&stack0x00000f26 + lVar21) =
                           *(undefined4 *)(&stack0x000001ec + lVar21);
                      (&stack0x00000f2a)[lVar21] = 0xff;
                      (&stack0x00000f2b)[lVar21] =
                           *(undefined *)(***(longlong ***)(&stack0x00000088 + lVar21) + 1);
                      *(undefined2 *)(&stack0xffffffffffffffe0 + lVar21) = 1;
                      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10191e;
                      func_0x(&stack0x00000cc8 + lVar21,lVar26 + 0x254,0x10);
                      *(undefined2 *)(&stack0xffffffffffffffe0 + lVar21) = 2;
                      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101945;
                      func_0x(&stack0x00000cc8 + lVar21,lVar26 + 0x244,0x10);
                      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101958;
                      func_0x(&stack0x00000cc0 + lVar21,&stack0x00001810 + lVar21);
                      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10196b;
                      func_0x(&stack0x00000cc0 + lVar21,&stack0x000017e0 + lVar21);
                      *(undefined4 *)(&stack0x00000464 + lVar21) = 0;
                      UNRECOVERED_JUMPTABLE = *(code **)(_DAT_ + 0x10);
                      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101986;
                      uVar23 = (*UNRECOVERED_JUMPTABLE)(lVar26,&stack0x00000464 + lVar21);
                      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101995;
                      func_0x(&stack0x00000cc0 + lVar21,uVar23);
                      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1019a1;
                      func_0x(&stack0x00000cc0 + lVar21);
                    }
                    goto LAB_;
                  }
                }
              }
              plVar27 = **(longlong ***)(&stack0x00000088 + lVar21);
            }
            lVar26 = *plVar27;
          }
          else {
            lVar25 = *(longlong *)(&stack0x00000068 + lVar21);
            *(undefined4 *)(&stack0x000003fc + lVar21) = *(undefined4 *)(lVar25 + 0x18);
            *(undefined2 *)(&stack0x00000400 + lVar21) = *(undefined2 *)(lVar25 + 0x1c);
            *(undefined *)((longlong)&uStackX_20 + lVar21 + -0x20) = 0;
            (&stack0xfffffffffffffff8)[lVar21] = cVar8;
            *(undefined **)(&stack0xfffffffffffffff0 + lVar21) = &stack0x000004c0 + lVar21;
            *(longlong *)(&stack0xffffffffffffffe8 + lVar21) = *plVar27;
            *(undefined4 *)(&stack0xffffffffffffffe0 + lVar21) = 4;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10138f;
            lVar26 = func_0x(pplVar36,lVar25,&stack0x000003fc + lVar21,0xff);
          }
          *(longlong *)(&stack0x00000058 + lVar21) = lVar26;
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1019bb;
          func_0x(&stack0x000015e8 + lVar21);
          if (lVar37 != 0) {
            *(longlong *)(lVar37 + 0x10) = *(longlong *)(lVar37 + 0x10) + 1;
          }
          bVar7 = true;
          lVar25 = *(longlong *)(&stack0x00000098 + lVar21);
        }
        else {
          lVar26 = **pplVar36;
          *(longlong *)(&stack0x00000058 + lVar21) = lVar26;
        }
        if (lVar37 != 0) {
          *(longlong *)(lVar37 + 0x30) = *(longlong *)(lVar37 + 0x30) + 1;
        }
        if ((lVar25 != 0) && (*(char *)(lVar25 + 0x49e) != '\0')) {
          lVar37 = *(longlong *)(**(longlong **)(&stack0x00000070 + lVar21) + 0x728);
          uVar10 = *(undefined *)(lVar26 + 1);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101a0e;
          func_0x(lVar37 + 0x88,uVar10);
          if (*(byte *)(*(longlong *)(&stack0x00000068 + lVar21) + 0x16) < 0x7f) {
            LOCK();
            plVar27 = (longlong *)
                      (lVar37 + 0x2e0 +
                      (ulonglong)*(byte *)(*(longlong *)(&stack0x00000068 + lVar21) + 0x16) * 8);
            *plVar27 = *plVar27 + 1;
            UNLOCK();
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101a3b;
        uVar23 = func_0x(lVar26,&stack0x000015b0 + lVar21,0,0);
        puVar4 = *(undefined8 **)(&stack0x000000a8 + lVar21);
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101a4a;
        iVar17 = func_0x(puVar4,uVar23);
        uVar15 = *(undefined2 *)(**(longlong **)(&stack0x00000088 + lVar21) + 0x62);
        *(undefined8 *)(&stack0x000005c8 + lVar21) = *puVar4;
        *(undefined2 *)(&stack0x000005d0 + lVar21) = *(undefined2 *)(puVar4 + 1);
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101a98;
        uVar23 = func_0x(lVar26,&stack0x000009a8 + lVar21,0,0);
        *(byte *)((longlong)&lStackX_8 + lVar21) = (byte)uVar15 >> 4 & 1;
        *(bool *)((longlong)&uStackX_20 + lVar21 + -0x20) = iVar17 == 0;
        (&stack0xfffffffffffffff8)[lVar21] = (&stack0x00000080)[lVar21];
        (&stack0xfffffffffffffff0)[lVar21] = (&stack0x00000066)[lVar21];
        (&stack0xffffffffffffffe8)[lVar21] = (&stack0x00000064)[lVar21];
        (&stack0xffffffffffffffe0)[lVar21] = iVar17 == 0;
        lVar37 = *(longlong *)(&stack0x00000068 + lVar21);
        plVar27 = *(longlong **)(&stack0x00000070 + lVar21);
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101adb;
        func_0x(plVar27,lVar37,&stack0x000005c8 + lVar21,uVar23);
        *(undefined4 *)(&stack0x00000402 + lVar21) = *(undefined4 *)(lVar37 + 0x18);
        *(undefined2 *)(&stack0x00000406 + lVar21) = *(undefined2 *)(lVar37 + 0x1c);
        if (*(int *)(*(longlong *)(*plVar27 + 0x7a8) + 0x110) != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101b13;
          iVar19 = func_0x(&stack0x00000402 + lVar21);
          if (iVar19 == 0) {
            *(undefined4 *)(&stack0x00000468 + lVar21) = *(undefined4 *)(lVar37 + 0x18);
            *(undefined2 *)(&stack0x0000046c + lVar21) = *(undefined2 *)(lVar37 + 0x1c);
            uVar23 = *(undefined8 *)(*plVar27 + 0x7a8);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101b41;
            func_0x(uVar23);
          }
        }
        if (bVar7) {
          plVar27 = *(longlong **)(&stack0x00000088 + lVar21);
          uVar18 = *(uint *)((longlong)plVar27 + 0xc);
          lVar25 = *(longlong *)(&stack0x00000090 + lVar21);
          if (((uVar18 & 0xff000000) != 0) || (lVar29 = lVar30, (*(byte *)(lVar25 + 0x16) & 8) == 0)
             ) {
            lVar29 = *(longlong *)(*plVar27 + 0x40);
            *(ushort *)(lVar25 + 0x16) = *(ushort *)(lVar25 + 0x16) | 8;
            uVar18 = *(uint *)((longlong)plVar27 + 0xc);
          }
          plVar27 = *(longlong **)(&stack0x00000070 + lVar21);
          *(longlong *)(&stack0xffffffffffffffe8 + lVar21) = lVar29;
          *(uint *)(&stack0xffffffffffffffe0 + lVar21) = (uint)(iVar17 == 0);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101bae;
          func_0x(plVar27 + 0xb37,(int)uVar18 >> 0x18,
                          *(undefined4 *)(&stack0x000004c4 + lVar21),
                          *(undefined4 *)(&stack0x000004c0 + lVar21));
          if (*(int *)(&stack0x000004c4 + lVar21) != 0) {
            if ((DAT_ & 8) != 0) {
LAB_:
              *(undefined4 *)(&stack0x00000470 + lVar21) = 0x5c;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101c2c;
              func_0x
                        (*(undefined8 *)(&stack0x000000a8 + lVar21),&stack0x000015d0 + lVar21);
              *(undefined4 *)(&stack0x000006a8 + lVar21) = 100;
              *(undefined **)(&stack0x000006a0 + lVar21) = &stack0x00001840 + lVar21;
              *(undefined4 *)(&stack0xffffffffffffffe0 + lVar21) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101c66;
              func_0x
                        (&stack0x000015d0 + lVar21,&stack0x00001840 + lVar21,
                         &stack0x000006a8 + lVar21,0);
              uVar18 = *(uint *)(&stack0x000006a8 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101c83;
              func_0x(*(undefined8 *)(&stack0x000000a8 + lVar21),&stack0x000019d0 + lVar21,
                              &stack0x00000470 + lVar21);
              uVar20 = *(undefined4 *)(lVar37 + 0x18);
              uVar16 = *(ushort *)(lVar37 + 0x1c);
              uVar2 = *(ushort *)(lVar37 + 0x14);
              *(int *)((longlong)&lStackX_8 + lVar21) =
                   (int)*(char *)(*(longlong *)(&stack0x00000088 + lVar21) + 0xf);
              *(undefined4 *)((longlong)&uStackX_20 + lVar21 + -0x20) = uVar20;
              *(uint *)(&stack0xfffffffffffffff8 + lVar21) = (uint)uVar16;
              *(undefined4 *)(&stack0xfffffffffffffff0 + lVar21) =
                   *(undefined4 *)(&stack0x000004c0 + lVar21);
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar21) = *(undefined4 *)(lVar37 + 0x10);
              *(uint *)(&stack0xffffffffffffffe0 + lVar21) = (uint)uVar2;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101cd9;
              func_0x(0x1337720,uVar18 >> 1,&stack0x00001840 + lVar21,
                              &stack0x000019d0 + lVar21);
              goto LAB_;
            }
            lVar29 = *(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
            if ((lVar29 != 0) && (**(longlong **)(lVar29 + 0x38) != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101c0a;
              iVar19 = (*_DAT_)();
              if (iVar19 != 0) goto LAB_;
            }
          }
        }
        else {
LAB_:
          lVar25 = *(longlong *)(&stack0x00000090 + lVar21);
        }
        if ((iVar17 == 0) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1021c9;
          uVar23 = func_0x(lVar37);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1021e1;
          uVar24 = func_0x(lVar26,&stack0x000014b0 + lVar21,0,0);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1021ec;
          iVar17 = func_0x(uVar24,uVar23);
          while (iVar17 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1021fc;
            cVar8 = func_0x(lVar37);
            if (cVar8 == '\x10') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102213;
              uVar23 = func_0x(lVar37,&stack0x000007e8 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10221b;
              uVar15 = func_0x(uVar23);
              lVar30 = *(longlong *)(&stack0x00000070 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10222a;
              uVar23 = func_0x(lVar30);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102238;
              uVar23 = func_0x(uVar23,uVar15,0);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102240;
              iVar17 = func_0x(uVar23);
              if (iVar17 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102259;
                uVar23 = func_0x(lVar26,&stack0x000015a0 + lVar21,0,0);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102265;
                iVar17 = func_0x(uVar23,*(undefined8 *)(&stack0x000000a8 + lVar21));
                if (iVar17 != 0) goto LAB_;
              }
              if (*(int *)(lVar30 + 0x20) == 2) {
                lVar30 = *(longlong *)(&stack0x00000090 + lVar21);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102289;
                uVar23 = func_0x(*(undefined8 *)(&stack0x00000070 + lVar21),lVar30 + 0x10);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1022a1;
                uVar24 = func_0x(lVar26,&stack0x00000998 + lVar21,0,0);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1022b3;
                func_0x(lVar30,uVar24,uVar23,0xded0);
                goto LAB_;
              }
            }
            else {
              lVar30 = *(longlong *)(&stack0x00000070 + lVar21);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1022c7;
            uVar23 = func_0x(lVar30);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1022cf;
            cVar8 = func_0x(uVar23);
            if (cVar8 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1022db;
              cVar8 = func_0x(lVar30);
              if (cVar8 != '\0') goto LAB_;
            }
            else {
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1022e7;
              cVar8 = func_0x(lVar37);
              if (cVar8 == '\x15') {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1022ff;
                uVar23 = func_0x(&stack0x000014c0 + lVar21,0,0,0);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10230a;
                uVar24 = func_0x(lVar37);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102315;
                iVar17 = func_0x(uVar24,uVar23);
                if (iVar17 != 0) goto LAB_;
              }
            }
            if (*_DAT_ != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10232e;
              uVar23 = func_0x();
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10233b;
              iVar17 = func_0x(uVar23,0x337);
              if (iVar17 == 0) {
                if (*(longlong *)
                     ((ulonglong)*_DAT_ +
                     *(longlong *)
                      (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) != 0)
                {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10236b;
                  uVar23 = func_0x();
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102373;
                  lVar22 = func_0x(uVar23);
                  if (lVar22 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102386;
                    iVar17 = (*_DAT_)(lVar22,0x337);
                    if (iVar17 != 0) goto LAB_;
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10238f;
                lVar22 = func_0x();
                if (lVar22 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10239c;
                  uVar23 = func_0x(lVar22);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1023a7;
                  func_0x(uVar23,lVar26);
                }
              }
            }
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1023af;
            uVar23 = func_0x(lVar37);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1023c7;
            uVar24 = func_0x(lVar26,&stack0x000014d0 + lVar21,0,0);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1023d2;
            iVar17 = func_0x(uVar24,uVar23);
            if (iVar17 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1023de;
              iVar17 = func_0x(lVar26);
              if (iVar17 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102880;
                uVar23 = func_0x(lVar26,&stack0x00001510 + lVar21,0,0);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102896;
                func_0x(uVar23,&stack0x00001970 + lVar21,&stack0x00000474 + lVar21);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1028ad;
                func_0x(*(undefined8 *)(&stack0x000000a8 + lVar21),&stack0x00001910 + lVar21
                                ,&stack0x00000474 + lVar21);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1028b2;
                iVar17 = func_0x();
                if (iVar17 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1028c6;
                  func_0x(&stack0x00000f60 + lVar21);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1028ce;
                  uVar23 = func_0x(lVar30);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1028d6;
                  uVar15 = func_0x(uVar23);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1028e5;
                  func_0x(&stack0x00000f60 + lVar21,uVar15);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1028f4;
                  uVar23 = func_0x(lVar37,&stack0x00000846 + lVar21);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1028fc;
                  uVar20 = func_0x(uVar23);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10290a;
                  func_0x(&stack0x00000f60 + lVar21,uVar20);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102919;
                  uVar23 = func_0x(lVar37,&stack0x0000084c + lVar21);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102921;
                  uVar15 = func_0x(uVar23);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102930;
                  func_0x(&stack0x00000f60 + lVar21,uVar15);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102943;
                  func_0x(&stack0x00000f60 + lVar21,&stack0x00001910 + lVar21);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102956;
                  func_0x(&stack0x00000f60 + lVar21,&stack0x00001970 + lVar21);
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102962;
                  func_0x(&stack0x00000f60 + lVar21);
                }
                goto LAB_;
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1023fb;
            uVar23 = func_0x(lVar26,&stack0x000014e0 + lVar21,0,0);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102411;
            func_0x(uVar23,&stack0x00001a90 + lVar21,&stack0x0000032c + lVar21);
            puVar4 = *(undefined8 **)(&stack0x000000a8 + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10242b;
            func_0x(puVar4,&stack0x00001a30 + lVar21,&stack0x0000032c + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102433;
            uVar23 = func_0x(lVar37);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102449;
            func_0x(uVar23,&stack0x000018b0 + lVar21,&stack0x0000032c + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10244e;
            iVar17 = func_0x();
            if (iVar17 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102462;
              func_0x(&stack0x00000a10 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102475;
              func_0x(&stack0x00000a10 + lVar21,&stack0x00001a30 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10247d;
              uVar23 = func_0x(lVar37);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102485;
              uVar23 = func_0x(uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102494;
              func_0x(&stack0x00000a10 + lVar21,uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1024a3;
              uVar23 = func_0x(lVar37,&stack0x000007ee + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1024ab;
              uVar20 = func_0x(uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1024b9;
              func_0x(&stack0x00000a10 + lVar21,uVar20);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1024c8;
              uVar23 = func_0x(lVar37,&stack0x000008f8 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1024d0;
              uVar23 = func_0x(uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1024df;
              func_0x(&stack0x00000a10 + lVar21,uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1024e7;
              uVar23 = func_0x(lVar30);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1024ef;
              uVar23 = func_0x(uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1024fe;
              func_0x(&stack0x00000a10 + lVar21,uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102506;
              uVar23 = func_0x(lVar30);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10250e;
              uVar15 = func_0x(uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10251d;
              func_0x(&stack0x00000a10 + lVar21,uVar15);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102530;
              func_0x(&stack0x00000a10 + lVar21,&stack0x00001a90 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10253c;
              func_0x(&stack0x00000488 + lVar21);
              *(undefined4 *)(&stack0x00000488 + lVar21) = *(undefined4 *)(lVar26 + 0x18);
              *(undefined2 *)(&stack0x0000048c + lVar21) = *(undefined2 *)(lVar26 + 6);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10255c;
              uVar23 = func_0x(&stack0x00000488 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10256b;
              func_0x(&stack0x00000a10 + lVar21,uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102573;
              uVar10 = func_0x(lVar26);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102582;
              func_0x(&stack0x00000a10 + lVar21,uVar10);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10258a;
              uVar10 = func_0x(lVar37);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102599;
              func_0x(&stack0x00000a10 + lVar21,uVar10);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1025a1;
              uVar10 = func_0x(lVar37);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1025b0;
              func_0x(&stack0x00000a10 + lVar21,uVar10);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1025c3;
              func_0x(&stack0x00000a10 + lVar21,&stack0x000018b0 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1025cf;
              func_0x(&stack0x00000a10 + lVar21);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1025d4;
            uVar23 = func_0x();
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1025e1;
            iVar17 = func_0x(uVar23,0xd85);
            if (iVar17 != 0) {
LAB_:
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102976;
              func_0x(0x1337890);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10297e;
              puVar31 = (undefined8 *)func_0x(lVar37);
              *(undefined8 *)(&stack0x00000620 + lVar21) = *puVar31;
              *(undefined2 *)(&stack0x00000628 + lVar21) = *(undefined2 *)(puVar31 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1029aa;
              puVar31 = (undefined8 *)func_0x(lVar26,&stack0x00001520 + lVar21,0,0);
              *(undefined8 *)(&stack0x00000630 + lVar21) = *puVar31;
              *(undefined2 *)(&stack0x00000638 + lVar21) = *(undefined2 *)(puVar31 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1029d0;
              puVar32 = (undefined4 *)func_0x(lVar37,&stack0x00000840 + lVar21);
              *(undefined4 *)(&stack0x00000430 + lVar21) = *puVar32;
              *(undefined2 *)(&stack0x00000434 + lVar21) = *(undefined2 *)(puVar32 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1029ee;
              puVar32 = (undefined4 *)func_0x(lVar37);
              *(undefined4 *)(&stack0x00000440 + lVar21) = *puVar32;
              *(undefined2 *)(&stack0x00000444 + lVar21) = *(undefined2 *)(puVar32 + 1);
              *(undefined8 *)(&stack0x00000640 + lVar21) = *puVar4;
              *(undefined2 *)(&stack0x00000648 + lVar21) = *(undefined2 *)(puVar4 + 1);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a27;
              func_0x(&stack0x00000498 + lVar21);
              *(undefined4 *)(&stack0x00000498 + lVar21) = *(undefined4 *)(lVar26 + 0x18);
              *(undefined2 *)(&stack0x0000049c + lVar21) = *(undefined2 *)(lVar26 + 6);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a43;
              bVar11 = func_0x(lVar37);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a4f;
              bVar12 = func_0x(lVar37);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a5b;
              bVar13 = func_0x(lVar26);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a6b;
              uVar23 = func_0x(&stack0x00000498 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a76;
              uVar24 = func_0x(lVar30);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a7e;
              uVar16 = func_0x(uVar24);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a89;
              uVar24 = func_0x(lVar30);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a91;
              uVar24 = func_0x(uVar24);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102a9d;
              uVar33 = func_0x(*(undefined8 *)(&stack0x00000070 + lVar21));
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102aa5;
              uVar20 = func_0x(uVar33);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102ab7;
              uVar33 = func_0x
                                 (*(undefined8 *)(&stack0x00000068 + lVar21),
                                  &stack0x00000908 + lVar21);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102abf;
              uVar33 = func_0x(uVar33);
              *(undefined **)(&stack0x00000028 + lVar21) = &stack0x00000620 + lVar21;
              *(uint *)((longlong)&uStackX_20 + lVar21) = (uint)bVar11;
              *(uint *)((longlong)&lStackX_18 + lVar21) = (uint)bVar12;
              *(uint *)((longlong)&uStackX_10 + lVar21) = (uint)bVar13;
              *(undefined8 *)((longlong)&lStackX_8 + lVar21) = uVar23;
              *(undefined **)((longlong)&uStackX_20 + lVar21 + -0x20) = &stack0x00000630 + lVar21;
              *(uint *)(&stack0xfffffffffffffff8 + lVar21) = (uint)uVar16;
              *(undefined8 *)(&stack0xfffffffffffffff0 + lVar21) = uVar24;
              *(undefined4 *)(&stack0xffffffffffffffe8 + lVar21) = uVar20;
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar21) = uVar33;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102b1c;
              func_0x(0xd80,&stack0x00000640 + lVar21,&stack0x00000440 + lVar21,
                              &stack0x00000430 + lVar21);
              lVar37 = *(longlong *)(&stack0x00000068 + lVar21);
              break;
            }
            if (*(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102615;
              uVar23 = func_0x();
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10261d;
              lVar22 = func_0x(uVar23);
              if (lVar22 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102630;
                iVar17 = (*_DAT_)(lVar22,0xd85);
                if (iVar17 != 0) goto LAB_;
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102640;
            uVar23 = func_0x(lVar30);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102648;
            cVar8 = func_0x(uVar23);
            if (cVar8 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102654;
              cVar8 = func_0x(lVar30);
              *(undefined4 *)(&stack0x0000007c + lVar21) = 0x15;
              if (cVar8 != '\0') goto LAB_;
            }
            else {
LAB_:
              *(undefined4 *)(&stack0x0000007c + lVar21) = 0x17;
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10266e;
            puVar31 = (undefined8 *)func_0x(lVar37);
            *(undefined8 *)(&stack0x000005f0 + lVar21) = *puVar31;
            *(undefined2 *)(&stack0x000005f8 + lVar21) = *(undefined2 *)(puVar31 + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10269a;
            puVar31 = (undefined8 *)func_0x(lVar26,&stack0x000014f0 + lVar21,0,0);
            *(undefined8 *)(&stack0x00000600 + lVar21) = *puVar31;
            *(undefined2 *)(&stack0x00000608 + lVar21) = *(undefined2 *)(puVar31 + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1026c0;
            puVar32 = (undefined4 *)func_0x(lVar37,&stack0x0000086e + lVar21);
            *(undefined4 *)(&stack0x00000410 + lVar21) = *puVar32;
            *(undefined2 *)(&stack0x00000414 + lVar21) = *(undefined2 *)(puVar32 + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1026de;
            puVar32 = (undefined4 *)func_0x(lVar37);
            *(undefined4 *)(&stack0x00000420 + lVar21) = *puVar32;
            *(undefined2 *)(&stack0x00000424 + lVar21) = *(undefined2 *)(puVar32 + 1);
            *(undefined8 *)(&stack0x00000610 + lVar21) = *puVar4;
            *(undefined2 *)(&stack0x00000618 + lVar21) = *(undefined2 *)(puVar4 + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102717;
            func_0x(&stack0x00000490 + lVar21);
            *(undefined4 *)(&stack0x00000490 + lVar21) = *(undefined4 *)(lVar26 + 0x18);
            *(undefined2 *)(&stack0x00000494 + lVar21) = *(undefined2 *)(lVar26 + 6);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102733;
            bVar11 = func_0x(lVar37);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10273f;
            bVar12 = func_0x(lVar37);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10274b;
            bVar13 = func_0x(lVar26);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10275b;
            uVar23 = func_0x(&stack0x00000490 + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102766;
            uVar24 = func_0x(lVar30);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10276e;
            uVar16 = func_0x(uVar24);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102779;
            uVar24 = func_0x(lVar30);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102781;
            uVar24 = func_0x(uVar24);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10278d;
            uVar33 = func_0x(*(undefined8 *)(&stack0x00000070 + lVar21));
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102795;
            uVar20 = func_0x(uVar33);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1027a7;
            uVar33 = func_0x
                               (*(undefined8 *)(&stack0x00000068 + lVar21),&stack0x00000900 + lVar21
                               );
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1027af;
            uVar33 = func_0x(uVar33);
            *(undefined **)(&stack0x00000040 + lVar21) = &stack0x000005f0 + lVar21;
            *(uint *)(&stack0x00000038 + lVar21) = (uint)bVar11;
            *(uint *)(&stack0x00000030 + lVar21) = (uint)bVar12;
            *(uint *)(&stack0x00000028 + lVar21) = (uint)bVar13;
            *(undefined8 *)((longlong)&uStackX_20 + lVar21) = uVar23;
            *(undefined **)((longlong)&lStackX_18 + lVar21) = &stack0x00000600 + lVar21;
            *(uint *)((longlong)&uStackX_10 + lVar21) = (uint)uVar16;
            *(undefined8 *)((longlong)&lStackX_8 + lVar21) = uVar24;
            *(undefined4 *)((longlong)&uStackX_20 + lVar21 + -0x20) = uVar20;
            *(undefined8 *)(&stack0xfffffffffffffff8 + lVar21) = uVar33;
            *(undefined **)(&stack0xfffffffffffffff0 + lVar21) = &stack0x00000410 + lVar21;
            *(undefined **)(&stack0xffffffffffffffe8 + lVar21) = &stack0x00000420 + lVar21;
            *(undefined **)(&stack0xffffffffffffffe0 + lVar21) = &stack0x00000610 + lVar21;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10282b;
            (*_DAT_)(0x22);
            lVar37 = *(longlong *)(&stack0x00000068 + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102837;
            func_0x(lVar37);
            lVar26 = *(longlong *)(&stack0x00000058 + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102853;
            uVar23 = func_0x(lVar26,&stack0x000014b0 + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10285e;
            iVar17 = func_0x(uVar23);
          }
          lVar30 = *(longlong *)(&stack0x00000070 + lVar21);
LAB_:
          lVar22 = 0;
          uVar28 = _DAT_;
          if (*_DAT_ != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102b40;
            (*_DAT_)(&stack0x00000698 + lVar21);
            uVar28 = *(ulonglong *)(&stack0x00000698 + lVar21);
          }
          uVar23 = *(undefined8 *)(&stack0x00000088 + lVar21);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102b62;
          uVar24 = func_0x(uVar23,0,0);
          *(undefined8 *)(&stack0x00000058 + lVar21) = uVar24;
          if (*(int *)(lVar30 + 0x20) == 3) {
            uVar34 = _DAT_;
            if (*_DAT_ != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102b88;
              (*_DAT_)(&stack0x00000678 + lVar21);
              uVar34 = *(ulonglong *)(&stack0x00000678 + lVar21);
            }
            if (uVar28 <= uVar34) {
              lVar22 = uVar34 - uVar28;
            }
            *(longlong *)(&stack0x00000688 + lVar21) = lVar22;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102bc0;
            func_0x(lVar30 + 0x59b8,&stack0x00000688 + lVar21);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102bc8;
          iVar17 = func_0x(lVar37);
          if (iVar17 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102bdd;
            iVar17 = func_0x(lVar37,1);
            uVar20 = 8;
            if (iVar17 != 0) {
              uVar20 = 10;
            }
            *(undefined4 *)(&stack0x00000078 + lVar21) = uVar20;
            *(longlong *)(&stack0x000001d8 + lVar21) = lVar37 + 0x10;
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102bfa;
          uVar33 = func_0x();
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102c07;
          iVar17 = func_0x(uVar33,0xe49);
          if (iVar17 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102c15;
            uVar20 = func_0x(0x10);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102c1f;
            lVar30 = func_0x(uVar23);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102c2a;
            func_0x(lVar30 + 100,uVar20);
          }
          *(uint *)(&stack0x00000078 + lVar21) = *(uint *)(&stack0x00000078 + lVar21) | 0x1000;
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102c4c;
          func_0x(&stack0x00000930 + lVar21,1);
          uVar18 = *(byte *)(lVar37 + 0x16) - 2;
          if (uVar18 < 0x7d) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((ulonglong)*(byte *)((longlong)(int)uVar18 + 0x10ecf0) * 4 +
                                   0x10eca0) - 0x14a16a0);
                    /* WARNING: Could not emulate address calculation at 0x00102c67 */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          *(undefined8 *)(&stack0xffffffffffffffe0 + lVar21) = 0x1078e90;
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e694;
          (*_DAT_)(1,0x147f220,0x1482e50,0x3590);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e6a0;
          lVar30 = func_0x(*(undefined8 *)(&stack0x00000088 + lVar21));
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e6ae;
          sVar14 = func_0x(lVar30 + 0x62,8);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e6c4;
          uVar23 = func_0x
                             (*(undefined8 *)(&stack0x00000068 + lVar21),&stack0x00000854 + lVar21);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e6cc;
          uVar10 = func_0x(uVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e6e0;
          func_0x
                    (uVar24,*(undefined8 *)(&stack0x000000a8 + lVar21),uVar10,sVar14 != 0);
          lVar30 = *(longlong *)(&stack0x00000090 + lVar21);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e6f6;
          uVar23 = func_0x(*(undefined8 *)(&stack0x00000070 + lVar21),lVar30 + 0x10);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e709;
          uVar24 = func_0x
                             (&stack0x00000958 + lVar21,*(undefined8 *)(&stack0x000000a8 + lVar21));
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e71b;
          func_0x(lVar30,uVar24,uVar23,0xded0);
          plVar27 = *(longlong **)(&stack0x00000088 + lVar21);
          if (*(int *)(&stack0x00000288 + lVar21) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e730;
            uVar23 = func_0x(plVar27);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e741;
            func_0x(uVar23,1);
          }
          lVar30 = *(longlong *)(&stack0x00000070 + lVar21);
          if ((*(byte *)(lVar30 + 0x24) & 4) != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e75b;
            uVar23 = func_0x(plVar27);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e766;
            uVar24 = func_0x(lVar30);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e774;
            func_0x(uVar24,uVar23,1);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e788;
          uVar23 = func_0x(&stack0x00001580 + lVar21,0,0,0);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e795;
          func_0x(plVar27,0,uVar23);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e79a;
          uVar23 = func_0x();
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e7a7;
          iVar17 = func_0x(uVar23,0xe49);
          if (iVar17 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e7b5;
            uVar20 = func_0x(0x10);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e7bf;
            lVar22 = func_0x(plVar27);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e7ca;
            func_0x(lVar22 + 100,uVar20);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e7d2;
            func_0x(plVar27);
          }
          if (*(int *)(&stack0x00000284 + lVar21) != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e7ec;
              lVar22 = func_0x(0x1a0e660);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e7f7;
              uVar24 = func_0x(lVar30);
              uVar23 = *(undefined8 *)(lVar22 + 0x20);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e807;
              cVar8 = func_0x(uVar23,uRam0000000000000024,uVar24);
            } while (cVar8 == '\0');
          }
          if (*(int *)(&stack0x00000290 + lVar21) != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e820;
              lVar22 = func_0x(0x1a0e660);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e82b;
              uVar24 = func_0x(lVar30);
              uVar23 = *(undefined8 *)(lVar22 + 0x20);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e83e;
              cVar8 = func_0x(uVar23,uRam0000000000000190,uVar24);
            } while (cVar8 == '\0');
          }
          if (*(int *)(&stack0x0000026c + lVar21) != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e85c;
              lVar22 = func_0x(0x1a0e660);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e867;
              uVar24 = func_0x(lVar30);
              uVar23 = *(undefined8 *)(lVar22 + 0x20);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e87a;
              cVar8 = func_0x(uVar23,uRam0000000000000188,uVar24);
            } while (cVar8 == '\0');
          }
          if (*(int *)(&stack0x00000268 + lVar21) != 0) {
            do {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e89c;
              lVar22 = func_0x(0x1a0e660);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e8a7;
              uVar24 = func_0x(lVar30);
              uVar23 = *(undefined8 *)(lVar22 + 0x20);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e8bb;
              cVar8 = func_0x(uVar23,uVar24,uRam000000000000013a);
            } while (cVar8 == '\0');
          }
          iVar17 = *(int *)(&stack0x00000320 + lVar21);
          if (iVar17 == 0) {
            if (*(int *)(&stack0x00000324 + lVar21) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e94e;
              uVar23 = func_0x(plVar27);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e959;
              func_0x(plVar27);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e963;
              func_0x(uVar23,0);
            }
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e8d3;
            func_0x(plVar27);
            uVar24 = _DAT_;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e8e6;
            puVar31 = (undefined8 *)func_0x(&stack0x000008e8 + lVar21);
            puVar4 = *(undefined8 **)(&stack0x00000070 + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e8f5;
            uVar33 = func_0x(puVar4);
            uVar23 = *puVar31;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e906;
            func_0x(uVar24,uVar23,uVar33,0);
            uVar23 = *puVar4;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e90e;
            cVar8 = func_0x(uVar23);
            if (((cVar8 != '\0') && (*(char *)(puVar4 + 0xbfb) != '\0')) && (iVar17 == 2)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e929;
              uVar23 = func_0x(puVar4);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e931;
              uVar23 = func_0x(uVar23);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e93b;
              func_0x(uVar23,0);
            }
          }
          if ((&stack0x00000065)[lVar21] != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e97c;
            iVar17 = func_0x(plVar27,4);
            if ((iVar17 == 0) && (lVar30 = *plVar27, lVar30 != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e99f;
              sVar14 = func_0x(lVar30 + 0x62,0x400);
              if ((sVar14 == 0) || (*(short *)((longlong)plVar27 + 0xc) < 3)) {
                iVar17 = (int)*(short *)((longlong)plVar27 + 0xc);
                lVar30 = *plVar27;
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e9d2;
                sVar14 = func_0x(lVar30 + 0x62,8);
                if ((sVar14 != 0) && ((iVar19 = 4, iVar17 == 3 || (iVar19 = iVar17, 1 < iVar17)))) {
                  iVar17 = iVar19;
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e9f3;
                  iVar19 = func_0x(lVar30 + 100,8);
                  if ((iVar19 != 0) && (*(longlong *)(lVar30 + 0x90) != 0)) {
                    uVar23 = *(undefined8 *)(lVar30 + 0x90);
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea16;
                    func_0x(uVar23,lVar30,iVar17);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea1b;
                uVar23 = func_0x();
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea28;
                iVar19 = func_0x(uVar23,0x32f);
                if (iVar19 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea3a;
                  iVar19 = func_0x(lVar30 + 100,8);
                  if ((iVar19 != 0) && (2 < iVar17)) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea4e;
                    func_0x(lVar30,1);
                  }
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea5c;
                func_0x(lVar30 + 0x98,iVar17);
                if (_DAT_ != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea6a;
                  uVar23 = func_0x();
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea77;
                  iVar19 = func_0x(uVar23,0xe79);
                  if (iVar19 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea88;
                    func_0x(lVar30,0,iVar17);
                  }
                }
                *(undefined2 *)((longlong)plVar27 + 0xc) = 0;
                *plVar27 = 0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10e9b5;
                func_0x(plVar27);
              }
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ea9e;
          func_0x(&stack0x00000930 + lVar21);
          goto LAB_;
        }
        *(undefined2 *)(lVar25 + 0x22) = 0xbed0;
        if ((((*(byte *)(*(longlong *)(*plVar27 + 0x6b0) + 0x3c) & 1) != 0) &&
            (*(longlong *)(*(longlong *)(*plVar27 + 0x6b0) + 0x280) == 0)) &&
           ((*(byte *)(lVar22 + 100) & 0x40) == 0)) {
          uVar20 = *(undefined4 *)(lVar37 + 0x18);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101d2e;
          uVar23 = func_0x(lVar26,&stack0x00001590 + lVar21,0,0);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101d44;
          (*_DAT_)(lVar22,uVar23,&stack0x000012d8 + lVar21,uVar20);
          lVar25 = *(longlong *)(&stack0x00000090 + lVar21);
        }
        plVar3 = *(longlong **)(&stack0x00000088 + lVar21);
        if (((*(uint *)(*plVar3 + 100) & 2) == 0) && (_DAT_ != 0)) {
          if ((*(ushort *)(*plVar3 + 0x62) & 0x10) == 0) {
            if ((*(uint *)((longlong)plVar27 + 0x24) >> 7 & 1) != 0) {
              uVar15 = *(undefined2 *)(*(longlong *)(*plVar27 + 0x6b0) + 0x28);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101d99;
              cVar8 = func_0x(uVar15);
              if (cVar8 != '\0') goto LAB_;
            }
          }
          else {
LAB_:
            if ((*(uint *)((longlong)plVar27 + 0x24) >> 7 & 1) != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101dbd;
              uVar23 = func_0x(lVar26,&stack0x00001570 + lVar21,0,0);
              lVar29 = *plVar27;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101dd0;
              func_0x(lVar29 + 0x6a40,uVar23);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101ddd;
            func_0x(plVar3,0,0);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101df1;
            func_0x(&stack0x00001480 + lVar21,0,0,0);
            lVar29 = *plVar3;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101e0b;
            func_0x(_DAT_,lVar29,0,&stack0x00001480 + lVar21);
            LOCK();
            *_DAT_ = *_DAT_ + 1;
            UNLOCK();
          }
        }
        if (*(char *)(lVar37 + 0x16) == '\x10') {
          if (*(longlong *)(*(longlong *)(*plVar27 + 0x6b0) + 0x280) == 0) {
            if ((*(int *)(plVar27 + 4) == 1) && (*(char *)(lVar22 + 0x5b) == '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101f04;
              func_0x(plVar27,lVar37);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101f10;
              uVar23 = func_0x(plVar27,lVar25 + 0x10);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101f28;
              uVar24 = func_0x(lVar26,&stack0x00000968 + lVar21,0,0);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101f3d;
              func_0x(*(undefined8 *)(&stack0x00000090 + lVar21),uVar24,uVar23,0xbed0);
            }
          }
          else {
            plVar27 = (longlong *)plVar27[0xbf0];
            if (plVar27 != (longlong *)0x0) {
              lVar30 = *(longlong *)
                        (*plVar27 +
                        ((ulonglong)*(uint *)(lVar25 + 0x10) % (ulonglong)*(uint *)(plVar27 + 1)) *
                        8);
            }
            *(undefined8 *)(&stack0x00000388 + lVar21) =
                 **(undefined8 **)(&stack0x000000a8 + lVar21);
            *(undefined2 *)(&stack0x00000390 + lVar21) =
                 *(undefined2 *)(*(undefined8 **)(&stack0x000000a8 + lVar21) + 1);
            *(undefined2 *)(lVar25 + 0x22) = 0xbed0;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101e8d;
            iVar17 = func_0x(lVar25 + 0x24);
            *(undefined8 *)(lVar25 + 0x24) = *(undefined8 *)(&stack0x00000388 + lVar21);
            *(undefined2 *)(lVar25 + 0x2c) = *(undefined2 *)(&stack0x00000390 + lVar21);
            lVar22 = *(longlong *)(&stack0x00000090 + lVar21);
            *(int *)(lVar22 + 0x30) = iVar17 + 2;
            *(undefined8 *)(&stack0x000005d8 + lVar21) = *(undefined8 *)(&stack0x00000388 + lVar21);
            *(undefined2 *)(&stack0x000005e0 + lVar21) = *(undefined2 *)(&stack0x00000390 + lVar21);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101ede;
            func_0x(lVar22,&stack0x000005d8 + lVar21,lVar30);
          }
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101f4a;
          cVar8 = func_0x(lVar37);
          if (cVar8 == '\x13') {
            lVar22 = *plVar27;
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101f5b;
            cVar8 = func_0x(lVar22);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101f6f;
              uVar23 = func_0x(plVar27,lVar25 + 0x10);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101f87;
              uVar24 = func_0x(lVar26,&stack0x00000978 + lVar21,0,0);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101f9c;
              func_0x(*(undefined8 *)(&stack0x00000090 + lVar21),uVar24,uVar23,0xbed0);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101fa8;
              iVar17 = func_0x(plVar27 + 0xb74);
              if (iVar17 != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101fb7;
                uVar23 = func_0x(lVar37);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101fc2;
                lVar22 = func_0x(plVar27,uVar23);
                if (lVar22 != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101fcf;
                  lVar30 = func_0x(lVar22);
                }
              }
              lVar22 = *plVar27;
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x101fe0;
              uVar23 = func_0x(lVar22);
              (&stack0xffffffffffffffe8)[lVar21] = 1;
              (&stack0xffffffffffffffe0)[lVar21] = *(undefined *)(plVar27 + 0xbfb);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102002;
              func_0x(uVar23,lVar37,lVar26,lVar30);
              goto LAB_;
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102013;
          uVar23 = func_0x(plVar27,lVar25 + 0x10);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10202b;
          uVar24 = func_0x(lVar26,&stack0x00000988 + lVar21,0,0);
          lVar30 = *(longlong *)(&stack0x00000090 + lVar21);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102043;
          func_0x(lVar30,uVar24,uVar23,0xbed0);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102058;
          uVar23 = func_0x(lVar26,&stack0x00001500 + lVar21,0,0);
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102064;
          iVar17 = func_0x(lVar30 + 0x18,uVar23);
          if (iVar17 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102070;
            lVar30 = func_0x(plVar3);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10207e;
            iVar17 = func_0x(lVar30 + 100,2);
            uVar23 = _DAT_;
            if (iVar17 == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102091;
              uVar24 = func_0x(plVar3);
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10209c;
              func_0x(uVar23,uVar24);
            }
          }
        }
LAB_:
        if (((&stack0x00000065)[lVar21] != '\0') || (lVar30 = *plVar3, lVar30 == 0))
        goto LAB_;
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1020c1;
        sVar14 = func_0x(lVar30 + 0x62,0x400);
        if ((sVar14 != 0) && (2 < *(short *)((longlong)plVar3 + 0xc))) {
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1020d7;
          func_0x(plVar3);
          goto LAB_;
        }
        iVar17 = (int)*(short *)((longlong)plVar3 + 0xc);
        lVar30 = *plVar3;
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1020f4;
        sVar14 = func_0x(lVar30 + 0x62,8);
        if (sVar14 != 0) {
          if (iVar17 == 3) {
            iVar17 = 4;
          }
          else if (iVar17 < 2) goto LAB_;
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102118;
          iVar19 = func_0x(lVar30 + 100,8);
          if ((iVar19 != 0) && (*(longlong *)(lVar30 + 0x90) != 0)) {
            uVar23 = *(undefined8 *)(lVar30 + 0x90);
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10213b;
            func_0x(uVar23,lVar30,iVar17);
          }
        }
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102140;
        uVar23 = func_0x();
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10214d;
        iVar19 = func_0x(uVar23,0x32f);
        if (iVar19 != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10215f;
          iVar19 = func_0x(lVar30 + 100,8);
          if ((iVar19 != 0) && (2 < iVar17)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102175;
            func_0x(lVar30,1);
          }
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102183;
        func_0x(lVar30 + 0x98,iVar17);
        if (_DAT_ != 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x102191;
          uVar23 = func_0x();
          *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10219e;
          iVar19 = func_0x(uVar23,0xe79);
          if (iVar19 != 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1021af;
            func_0x(lVar30,0,iVar17);
          }
        }
        *(undefined2 *)((longlong)plVar3 + 0xc) = 0;
        *plVar3 = 0;
        goto LAB_;
      }
      if (bVar6) {
        pplVar36 = *(longlong ***)(&stack0x00000088 + lVar21);
        if (*pplVar36 != (longlong *)0x0) {
          if (((*(ushort *)((longlong)*pplVar36 + 0x62) >> 10 & 1) == 0) ||
             (*(short *)((longlong)pplVar36 + 0xc) < 3)) {
            iVar17 = (int)*(short *)((longlong)pplVar36 + 0xc);
            plVar27 = *pplVar36;
            if (((byte)*(undefined2 *)((longlong)plVar27 + 0x62) >> 3 & 1) != 0) {
              if (iVar17 == 3) {
                iVar17 = 4;
              }
              else if (iVar17 < 2) goto LAB_;
              if ((((*(uint *)((longlong)plVar27 + 100) & 8) != 0) &&
                  (lVar22 = plVar27[0x12], lVar22 != 0)) && (*(longlong *)(lVar22 + 0x758) != 0)) {
                uVar23 = *(undefined8 *)(lVar22 + 0x758);
                *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10eb33;
                func_0x(uVar23,plVar27,iVar17);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar27 + 100) & 8) != 0)) &&
               ((2 < iVar17 &&
                (((*(uint *)((longlong)plVar27 + 100) & 0xc0000000) != 0x40000000 && (*plVar27 != 0)
                 ))))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10eb68;
              func_0x(plVar27,1);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10eb77;
            func_0x(plVar27 + 0x13);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10eb96;
              func_0x(plVar27,0,iVar17);
            }
            *(undefined2 *)((longlong)pplVar36 + 0xc) = 0;
            *pplVar36 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ead5;
            func_0x(pplVar36);
          }
        }
      }
      plVar27 = *(longlong **)(*(longlong *)(&stack0x00000070 + lVar21) + 0x5f80);
      lVar22 = *(longlong *)(&stack0x00000090 + lVar21);
      if (plVar27 != (longlong *)0x0) {
        lVar30 = *(longlong *)
                  (*plVar27 +
                  ((ulonglong)*(uint *)(lVar22 + 0x10) % (ulonglong)*(uint *)(plVar27 + 1)) * 8);
      }
      *(undefined8 *)(&stack0x00000378 + lVar21) = **(undefined8 **)(&stack0x000000a8 + lVar21);
      *(undefined2 *)(&stack0x00000380 + lVar21) =
           *(undefined2 *)(*(undefined8 **)(&stack0x000000a8 + lVar21) + 1);
      *(undefined2 *)(lVar22 + 0x22) = 0x5ed0;
      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ebf6;
      iVar17 = func_0x(lVar22 + 0x24);
      *(undefined8 *)(lVar22 + 0x24) = *(undefined8 *)(&stack0x00000378 + lVar21);
      *(undefined2 *)(lVar22 + 0x2c) = *(undefined2 *)(&stack0x00000380 + lVar21);
      *(int *)(lVar22 + 0x30) = iVar17 + 2;
      *(undefined8 *)(&stack0x00000650 + lVar21) = *(undefined8 *)(&stack0x00000378 + lVar21);
      *(undefined2 *)(&stack0x00000658 + lVar21) = *(undefined2 *)(&stack0x00000380 + lVar21);
      puVar35 = &stack0x00000650;
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10046a;
      iVar17 = func_0x(*(longlong **)(&stack0x00000070 + lVar21),lVar22,param_2);
      if (iVar17 == 0) goto LAB_;
      plVar27 = *(longlong **)(*(longlong *)(&stack0x00000070 + lVar21) + 0x5f80);
      lVar22 = *(longlong *)(&stack0x00000090 + lVar21);
      if (plVar27 != (longlong *)0x0) {
        lVar30 = *(longlong *)
                  (*plVar27 +
                  ((ulonglong)*(uint *)(lVar22 + 0x10) % (ulonglong)*(uint *)(plVar27 + 1)) * 8);
      }
      *(undefined8 *)(&stack0x00000358 + lVar21) = **(undefined8 **)(&stack0x000000a8 + lVar21);
      *(undefined2 *)(&stack0x00000360 + lVar21) =
           *(undefined2 *)(*(undefined8 **)(&stack0x000000a8 + lVar21) + 1);
      *(undefined2 *)(lVar22 + 0x22) = 0x5ed0;
      *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x1004ca;
      iVar17 = func_0x(lVar22 + 0x24);
      *(undefined8 *)(lVar22 + 0x24) = *(undefined8 *)(&stack0x00000358 + lVar21);
      *(undefined2 *)(lVar22 + 0x2c) = *(undefined2 *)(&stack0x00000360 + lVar21);
      *(int *)(lVar22 + 0x30) = iVar17 + 2;
      *(undefined8 *)(&stack0x00000558 + lVar21) = *(undefined8 *)(&stack0x00000358 + lVar21);
      *(undefined2 *)(&stack0x00000560 + lVar21) = *(undefined2 *)(&stack0x00000360 + lVar21);
      puVar35 = &stack0x00000558;
    }
    puVar35 = puVar35 + lVar21;
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ec4d;
  func_0x(lVar22,puVar35,lVar30);
LAB_:
  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ec5f;
  func_0x(&stack0x000001e1 + lVar21);
  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ec6c;
  func_0x(&stack0x00000910 + lVar21);
  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ec79;
  func_0x(&stack0x000015e8 + lVar21);
  *(undefined8 *)((longlong)&uStack_48 + lVar21) = 0x10ec8b;
  func_0x
            (*(ulonglong *)(&stack0x000079d0 + lVar21) ^ (ulonglong)(&stack0x00000050 + lVar21));
  return;
}

