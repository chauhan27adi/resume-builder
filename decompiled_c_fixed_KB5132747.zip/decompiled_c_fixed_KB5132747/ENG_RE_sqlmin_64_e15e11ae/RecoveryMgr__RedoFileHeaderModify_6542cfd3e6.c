
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong *param_3,undefined8 param_4)

{
  longlong lVar1;
  ushort uVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  uint uVar6;
  char cVar7;
  int iVar8;
  uint uVar9;
  code *UNRECOVERED_JUMPTABLE;
  bool bVar10;
  undefined auStack_1c8 [32];
  uint uStack_1a8;
  uint uStack_1a0;
  undefined4 uStack_188;
  undefined2 uStack_180;
  undefined4 uStack_17c;
  undefined8 uStack_178;
  undefined8 uStack_170;
  undefined8 uStack_162;
  undefined8 uStack_158;
  undefined2 uStack_148;
  undefined4 uStack_144;
  byte *pbStack_140;
  undefined8 uStack_138;
  undefined8 uStack_12a;
  undefined2 uStack_122;
  undefined2 uStack_120;
  undefined6 uStack_11e;
  longlong *plStack_110;
  undefined auStack_108 [8];
  longlong lStack_100;
  longlong lStack_f0;
  longlong *plStack_e0;
  undefined8 uStack_d8;
  longlong lStack_c0;
  uint uStack_a8;
  undefined8 uStack_90;
  undefined8 uStack_88;
  undefined2 uStack_80;
  ulonglong uStack_58;
  
  uStack_90 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)auStack_1c8;
  uStack_180 = 0xffff;
  uStack_178 = 0;
  uStack_17c = 0;
  uStack_162 = 0;
  uStack_158 = 0;
  uStack_170 = 0;
  uStack_148 = 0xffff;
  pbStack_140 = (byte *)0x0;
  uStack_144 = 0;
  uStack_12a = 0;
  uStack_120 = 0;
  uStack_11e = 0;
  uStack_138 = 0;
  uStack_88 = 0;
  uStack_80 = 1;
  uVar2 = *(ushort *)(param_2 + 0x1c);
  lVar5 = *(longlong *)(*param_1 + 0x6a0);
  if ((((uVar2 == 0) || (*(ushort *)(lVar5 + 0x74) < uVar2)) ||
      (lStack_100 = *(longlong *)(*(longlong *)(lVar5 + 0x50) + -8 + (ulonglong)uVar2 * 8),
      lStack_100 == 0)) || ((*(byte *)(lStack_100 + 100) & 4) != 0)) {
    lStack_100 = 0;
  }
  lVar5 = lStack_100;
  plStack_110 = param_3;
  lStack_f0 = param_2;
  plStack_e0 = param_1;
  uStack_d8 = param_4;
  if (((*(byte *)(*param_1 + 0x1cd0) & 0x40) != 0) &&
     (iVar8 = func_0x(param_1,lStack_100,param_2), iVar8 != 0)) {
    func_0x(uStack_58 ^ (ulonglong)auStack_1c8);
    return;
  }
  uVar3 = *(undefined2 *)(param_3 + 1);
  uVar4 = *(undefined4 *)((longlong)param_3 + 4);
  *(undefined4 *)((longlong)param_1 + 0x5674) = *(undefined4 *)param_3;
  *(undefined4 *)(param_1 + 0xacf) = uVar4;
  *(undefined2 *)((longlong)param_1 + 0x567c) = uVar3;
  lVar1 = *param_3;
  uStack_a8 = (uint)*(ushort *)(param_3 + 1);
  do {
    uVar6 = *(uint *)((longlong)param_1 + 0x568c);
    while ((uVar6 & 1) == 0) {
      LOCK();
      uVar9 = *(uint *)((longlong)param_1 + 0x568c);
      bVar10 = uVar6 == uVar9;
      if (bVar10) {
        *(uint *)((longlong)param_1 + 0x568c) = uVar6 | 1;
        uVar9 = uVar6;
      }
      UNLOCK();
      uVar6 = uVar9;
      if (bVar10) {
        param_1[0xad0] = lVar1;
        *(uint *)(param_1 + 0xad1) = uStack_a8;
        *(uint *)((longlong)param_1 + 0x568c) = uVar9 + 2;
        cVar7 = func_0x();
        if (cVar7 != '\0') {
          uStack_1a0 = (uint)*(ushort *)(lVar5 + 0x20);
          uStack_1a8 = (uint)*(ushort *)(param_3 + 1);
          func_0x(*param_1,0xfc5b40,*(undefined4 *)param_3,
                          *(undefined4 *)((longlong)param_3 + 4));
        }
        lStack_c0 = param_2 + 0x3e;
        pbStack_140 = (byte *)func_0x(lStack_c0,0,auStack_108);
        if ((*pbStack_140 & 1) == 0) {
          uStack_148 = 0;
          uStack_122 = 0;
          uStack_120 = 0;
          uStack_188 = 9;
                    /* WARNING: Could not emulate address calculation at 0x0010035c */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_140 & 0xe) * 4 + 0x101b10) -
                    0x1871b30))
                    ((longlong)(int)(*pbStack_140 & 0xe),0xfffffffffe78e4d0,pbStack_140,pbStack_140)
          ;
          return;
        }
        uStack_148 = 1;
        UNRECOVERED_JUMPTABLE =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_140 & 0x1c) + 0x101af0) * 4 +
                               0x101ae0) - 0x1871b30);
        uStack_188 = 9;
                    /* WARNING: Could not emulate address calculation at 0x001001ea */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
        return;
      }
    }
  } while( true );
}

