
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(undefined8 param_1,longlong param_2)

{
  ushort uVar1;
  undefined2 uVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  char cVar8;
  byte bVar9;
  int iVar10;
  undefined2 *puVar11;
  uint *puVar12;
  undefined8 uVar13;
  ushort *puVar14;
  
  (*_DAT_)(param_2 + 0xc28,param_2 + 0x1bc0);
  if (*(longlong *)(param_2 + 0x40) != 0) {
    puVar14 = (ushort *)(*(longlong *)(param_2 + 0x40) + 0x62);
    *(ushort **)(param_2 + 0x1798) = puVar14;
    uVar1 = *puVar14;
    *(ushort *)(param_2 + 0x6c8) = uVar1;
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)(param_2 + 0x4c) < 3)) {
      *(int *)(param_2 + 0xa8) = (int)*(short *)(param_2 + 0x4c);
      *(undefined8 *)(param_2 + 0x798) = *(undefined8 *)(param_2 + 0x40);
      *(ushort **)(param_2 + 0x17a0) = puVar14;
      uVar1 = *puVar14;
      *(ushort *)(param_2 + 0x6d0) = uVar1;
      if (((byte)uVar1 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xa8) == 3) {
          *(undefined4 *)(param_2 + 0xa8) = 4;
        }
        else if (*(int *)(param_2 + 0xa8) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x40) + 100);
        *(uint **)(param_2 + 0x17a8) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0xa90) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar5 = *(longlong *)(*(longlong *)(param_2 + 0x40) + 0x90), lVar5 != 0)) &&
           (*(longlong *)(param_2 + 0x17b0) = lVar5, *(longlong *)(lVar5 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar5 + 0x758),*(undefined8 *)(param_2 + 0x40),
                     *(undefined4 *)(param_2 + 0xa8));
        }
      }
LAB_:
      *(undefined4 *)(param_2 + 0xa98) = 0x32f;
      cVar8 = DAT_ >> 7;
      *(char *)(param_2 + 0x161) = -cVar8;
      if (-cVar8 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x798) + 100);
        *(uint **)(param_2 + 0x17b8) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0xaa0) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xa8))) {
          *(uint **)(param_2 + 0x17c0) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0xaa8) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) &&
             (lVar5 = **(longlong **)(param_2 + 0x798), lVar5 != 0)) {
            *(undefined4 *)(param_2 + 0xb08) = 2;
            iVar10 = (*_DAT_)(lVar5,0x2000,2,param_2 + 0xb78);
            if (iVar10 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar5 = *(longlong *)(param_2 + 0x798);
      uVar4 = *(undefined4 *)(param_2 + 0xa8);
      func_0x(lVar5 + 0x98,uVar4);
      if (_DAT_ != 0) {
        *(undefined4 *)(param_2 + 0xb80) = 0xe79;
        bVar9 = DAT_ >> 1;
        *(byte *)(param_2 + 0x162) = bVar9;
        if ((bVar9 & 1) != 0) {
          func_0x(lVar5,0,uVar4);
        }
      }
      *(uint *)(param_2 + 0x4c) = *(uint *)(param_2 + 0x4c) & 0xffff0000;
      *(undefined8 *)(param_2 + 0x40) = 0;
    }
    else {
      func_0x(param_2 + 0x40);
    }
  }
  lVar5 = *(longlong *)(param_2 + 0xb48);
  if (*(int *)(lVar5 + 0xd0) == 2) goto LAB_;
  *(longlong **)(param_2 + 0x7a0) = (longlong *)(lVar5 + 0x68);
  lVar6 = *(longlong *)(lVar5 + 0x68);
  if (lVar6 != 0) {
    puVar14 = (ushort *)(lVar6 + 0x62);
    *(ushort **)(param_2 + 0x17c8) = puVar14;
    uVar1 = *puVar14;
    *(ushort *)(param_2 + 0x6d8) = uVar1;
    plVar7 = *(longlong **)(param_2 + 0x7a0);
    if (((uVar1 >> 10 & 1) == 0) || (*(short *)((longlong)plVar7 + 0xc) < 3)) {
      *(int *)(param_2 + 0xb0) = (int)*(short *)((longlong)plVar7 + 0xc);
      lVar6 = *plVar7;
      *(longlong *)(param_2 + 0x2e0) = lVar6;
      puVar11 = (undefined2 *)(lVar6 + 0x62);
      *(undefined2 **)(param_2 + 0x17d0) = puVar11;
      uVar2 = *puVar11;
      *(undefined2 *)(param_2 + 0x6e0) = uVar2;
      if (((byte)uVar2 >> 3 & 1) != 0) {
        if (*(int *)(param_2 + 0xb0) == 3) {
          *(undefined4 *)(param_2 + 0xb0) = 4;
        }
        else if (*(int *)(param_2 + 0xb0) < 2) goto LAB_;
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x2e0) + 100);
        *(uint **)(param_2 + 0x17d8) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0xb90) = uVar3;
        if ((((uVar3 & 8) != 0) &&
            (lVar6 = *(longlong *)(*(longlong *)(param_2 + 0x2e0) + 0x90), lVar6 != 0)) &&
           (*(longlong *)(param_2 + 0x17e0) = lVar6, *(longlong *)(lVar6 + 0x758) != 0)) {
          func_0x
                    (*(undefined8 *)(lVar6 + 0x758),*(undefined8 *)(param_2 + 0x2e0),
                     *(undefined4 *)(param_2 + 0xb0));
        }
      }
LAB_:
      cVar8 = DAT_ >> 7;
      *(char *)(param_2 + 0x163) = -cVar8;
      if (-cVar8 != '\0') {
        puVar12 = (uint *)(*(longlong *)(param_2 + 0x2e0) + 100);
        *(uint **)(param_2 + 0x17e8) = puVar12;
        uVar3 = *puVar12;
        *(uint *)(param_2 + 0x990) = uVar3;
        if (((uVar3 & 8) != 0) && (2 < *(int *)(param_2 + 0xb0))) {
          *(uint **)(param_2 + 0x17f0) = puVar12;
          uVar3 = *puVar12;
          *(uint *)(param_2 + 0xba0) = uVar3;
          if (((uVar3 & 0xc0000000) != 0x40000000) && (**(longlong **)(param_2 + 0x2e0) != 0)) {
            iVar10 = (*_DAT_)(**(longlong **)(param_2 + 0x2e0),0x2000,2,param_2 + 0xba8);
            if (iVar10 != 0) {
              LOCK();
              *puVar12 = *puVar12 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar12 = *puVar12 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar6 = *(longlong *)(param_2 + 0x2e0);
      uVar4 = *(undefined4 *)(param_2 + 0xb0);
      func_0x(lVar6 + 0x98,uVar4);
      if ((_DAT_ != 0) && ((DAT_ >> 1 & 1) != 0)) {
        func_0x(lVar6,0,uVar4);
      }
      *(uint *)((longlong)plVar7 + 0xc) = *(uint *)((longlong)plVar7 + 0xc) & 0xffff0000;
      **(undefined8 **)(param_2 + 0x7a0) = 0;
    }
    else {
      func_0x(plVar7);
    }
  }
  *(undefined4 *)(lVar5 + 0x80) = 0xffffffff;
  if (*(int *)(lVar5 + 0x90) != 0) {
    func_0x(*(undefined8 *)(lVar5 + 0x88),*(undefined4 *)(lVar5 + 0x94));
    *(undefined4 *)(lVar5 + 0x90) = 0;
  }
  *(undefined4 *)(param_2 + 0x148) = 0;
  *(undefined2 *)(param_2 + 0x14c) = 0;
  *(undefined4 *)(lVar5 + 0x9c) = 0;
  *(undefined2 *)(lVar5 + 0xa0) = 0;
  *(undefined4 *)(param_2 + 0x800) = 0;
  *(undefined4 *)(param_2 + 0x804) = 0;
  *(undefined2 *)(param_2 + 0x808) = 0;
  *(undefined8 *)(lVar5 + 0xbc) = *(undefined8 *)(param_2 + 0x800);
  *(undefined2 *)(lVar5 + 0xc4) = 0;
  *(undefined4 *)(lVar5 + 0xd0) = 2;
LAB_:
  uVar13 = (*_DAT_)(param_2 + 0xc28);
  (*_DAT_)(uVar13);
  (*_DAT_)(param_2 + 0xc28);
  return 0xfffffffffefc62b3;
}

