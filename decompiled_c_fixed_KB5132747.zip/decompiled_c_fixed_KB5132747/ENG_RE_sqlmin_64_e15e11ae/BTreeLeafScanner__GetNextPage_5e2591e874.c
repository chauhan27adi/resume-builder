
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,undefined8 *param_3)

{
  longlong *plVar1;
  ushort *puVar2;
  byte *pbVar3;
  byte *pbVar4;
  undefined2 uVar5;
  longlong **pplVar6;
  longlong lVar7;
  int iVar8;
  byte **ppbVar9;
  undefined4 *puVar10;
  code *UNRECOVERED_JUMPTABLE_00;
  short sVar11;
  undefined4 uVar12;
  ulonglong uVar13;
  undefined auStack_1c8 [32];
  ulonglong uStack_1a8;
  longlong *plStack_1a0;
  undefined4 uStack_184;
  short sStack_180;
  int *piStack_168;
  longlong lStack_160;
  undefined4 uStack_158;
  ushort *puStack_140;
  undefined8 *puStack_130;
  undefined2 uStack_128;
  undefined4 uStack_124;
  byte *pbStack_120;
  undefined8 uStack_118;
  undefined8 uStack_10a;
  undefined2 uStack_102;
  undefined2 uStack_100;
  undefined6 uStack_fe;
  int iStack_f4;
  undefined auStack_f0 [16];
  undefined auStack_e0 [16];
  undefined auStack_d0 [16];
  undefined auStack_c0 [16];
  undefined auStack_b0 [16];
  undefined auStack_a0 [16];
  undefined auStack_90 [16];
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined2 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined2 uStack_64;
  undefined auStack_60 [24];
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_1c8;
  lStack_160 = param_1;
  puStack_130 = param_3;
  if ((*(byte *)(param_1 + 0x48) & 4) == 0) {
    uStack_1a8 = 0x1aea7d8;
    (*_DAT_)(1,0x1aea7b0,0x1ac0b38);
  }
  *(undefined8 *)((longlong)param_3 + 4) = 0;
  *(undefined8 *)((longlong)param_3 + 0xc) = 0;
  *(undefined4 *)param_3 = 0;
  *(undefined4 *)((longlong)param_3 + 0x1c) = 0;
  *(undefined4 *)((longlong)param_3 + 0x14) = 0;
  *(undefined2 *)(param_3 + 3) = 0;
  if ((*(byte *)(param_1 + 0x48) & 2) == 0) {
    plVar1 = (longlong *)(param_1 + 0x80);
    if (*plVar1 == 0) {
      uStack_1a8 = 0;
      plStack_1a0 = plVar1;
      func_0x(*(undefined8 *)(param_1 + 0x70),*(undefined8 *)(param_1 + 0x78),0);
    }
    else {
      func_0x(*(undefined8 *)(param_1 + 0x70),0,plVar1);
    }
    while (pplVar6 = *(longlong ***)(param_1 + 0x80), pplVar6 != (longlong **)0x0) {
      if (*(int *)(pplVar6 + 5) == 0) {
        iStack_f4 = *(int *)(pplVar6 + 3);
        lVar7 = **pplVar6;
        puVar2 = (ushort *)(lVar7 + (0xfff - (longlong)iStack_f4) * 2);
        piStack_168 = (int *)(*(longlong *)(**(longlong **)(*(longlong *)(param_1 + 0x70) + 8) + 8)
                             + 0x210);
        puStack_140 = puVar2;
        if ((*(byte *)((ulonglong)*puVar2 + lVar7) & 1) != 0) {
          uStack_128 = 0xffff;
          pbStack_120 = (byte *)0x0;
          uStack_124 = 0;
          uStack_10a = 0;
          uStack_100 = 0;
          uStack_fe = 0;
          uStack_118 = 0;
          if (*(char *)(lVar7 + 2) < '\0') {
            pbVar4 = (byte *)(lVar7 + 0x60);
            auStack_f0 = ZEXT816(0);
            uStack_80 = 0;
            auStack_e0 = ZEXT816(0);
            auStack_d0 = ZEXT816(0);
            auStack_c0 = ZEXT816(0);
            auStack_b0 = ZEXT816(0);
            auStack_a0 = ZEXT816(0);
            auStack_90 = ZEXT816(0);
            ppbVar9 = (byte **)func_0x(auStack_f0);
            puVar10 = (undefined4 *)func_0x(lVar7,auStack_60,0);
            if (pbVar4 == *ppbVar9) {
              func_0x(puVar10,ppbVar9 + 0xc);
            }
            *ppbVar9 = pbVar4;
            uVar12 = *puVar10;
            uVar5 = *(undefined2 *)(puVar10 + 2);
            *(undefined4 *)((longlong)ppbVar9 + 100) = puVar10[1];
            *(undefined2 *)(ppbVar9 + 0xd) = uVar5;
            *(undefined4 *)(ppbVar9 + 0xc) = uVar12;
            *(undefined4 *)((longlong)ppbVar9 + 0x6c) = *(undefined4 *)(lVar7 + 0x20);
            *(undefined2 *)(ppbVar9 + 0xe) = *(undefined2 *)(lVar7 + 0x24);
            *(undefined2 *)((longlong)ppbVar9 + 0x72) = 0;
            uStack_158 = *(undefined4 *)((ulonglong)*pbVar4 * 6 + 0x17360c0);
            uVar13 = (ulonglong)*(short *)((ulonglong)*pbVar4 * 6 + 0x17360c4);
            *(undefined2 *)(ppbVar9 + 2) = 0xffff;
            ppbVar9[3] = (byte *)0x0;
            *(undefined4 *)((longlong)ppbVar9 + 0x14) = 0;
            *(undefined8 *)((longlong)ppbVar9 + 0x2e) = 0;
            ppbVar9[7] = (byte *)0x0;
            ppbVar9[4] = (byte *)0x0;
            ppbVar9[9] = (byte *)0x0;
            ppbVar9[10] = (byte *)0x0;
            *(undefined2 *)(ppbVar9 + 0xb) = 0;
            if ((**ppbVar9 & 2) != 0) {
              pbVar3 = pbVar4 + uVar13;
              if ((pbVar4[uVar13] & 1) == 0) {
                *(undefined2 *)(ppbVar9 + 2) = 0;
                ppbVar9[3] = pbVar3;
                *(undefined4 *)((longlong)ppbVar9 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar9 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100433 */
                    /* WARNING: Treating indirect jump as call */
                (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar3 & 0xe) * 4 + 0x101164) -
                          0xe62d50))();
                return;
              }
              *(undefined2 *)(ppbVar9 + 2) = 1;
              ppbVar9[3] = pbVar3;
              UNRECOVERED_JUMPTABLE_00 =
                   (code *)((ulonglong)
                            *(uint *)((ulonglong)
                                      *(byte *)((longlong)(int)(*pbVar3 & 0x1c) + 0x101144) * 4 +
                                     0x101134) - 0xe62d50);
                    /* WARNING: Could not emulate address calculation at 0x0010028c */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
              return;
            }
            if ((**ppbVar9 & 4) != 0) {
              uStack_158._2_2_ = (short)((uint)uStack_158 >> 0x10);
              if (uStack_158._2_2_ != 0) {
                uVar13 = (ulonglong)*(ushort *)(lVar7 + 0x61 + (longlong)uStack_158._2_2_ * 2);
              }
              func_0x(ppbVar9 + 9,pbVar4 + uVar13);
            }
            if (ppbVar9[1] != (byte *)0x0) {
              func_0x(ppbVar9[1],ppbVar9);
            }
          }
          pbStack_120 = (byte *)((ulonglong)*puVar2 + lVar7);
          if ((*pbStack_120 & 1) == 0) {
            uStack_128 = 0;
            uStack_124 = 0;
            uStack_102 = 0;
            uStack_100 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100686 */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_120 & 0xe) * 4 + 0x1011d0) -
                      0xe62d50))();
            return;
          }
          uStack_128 = 1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)
                                  *(byte *)((longlong)(int)(*pbStack_120 & 0x1c) + 0x1011b0) * 4 +
                                 0x1011a0) - 0xe62d50);
                    /* WARNING: Could not emulate address calculation at 0x0010052e */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        puVar10 = (undefined4 *)((byte *)((ulonglong)*puVar2 + lVar7) + *piStack_168);
        uVar12 = *puVar10;
        sVar11 = *(short *)(puVar10 + 1);
      }
      else {
        uVar12 = *(undefined4 *)((longlong)pplVar6 + 0x34);
        sVar11 = *(short *)(pplVar6 + 7);
      }
      uStack_184 = uVar12;
      sStack_180 = sVar11;
      iVar8 = func_0x(*(undefined8 *)(param_1 + 0x88),&uStack_184);
      if ((iVar8 == 0) &&
         ((*(short *)(param_1 + 0x68) == 0 || (*(short *)(param_1 + 0x68) == sVar11)))) {
        *(undefined4 *)(puStack_130 + 1) = uVar12;
        *(short *)((longlong)puStack_130 + 0xc) = sVar11;
        *(undefined2 *)((longlong)puStack_130 + 0xe) = 0;
        *puStack_130 = 0;
        *(undefined4 *)((longlong)puStack_130 + 0x1c) = 0;
        puStack_130[2] = 0;
        *(undefined2 *)(puStack_130 + 3) = 0;
        break;
      }
      func_0x(*(undefined8 *)(param_1 + 0x70),0);
    }
    if ((*(longlong *)(param_1 + 0x80) != 0) &&
       (func_0x(*(undefined8 *)(param_1 + 0x70)), *(int *)(param_1 + 0x4c) == 0)) {
      if (*(int *)(param_1 + 0xa8) == 0) {
        plStack_1a0 = (longlong *)&uStack_78;
        uStack_1a8 = uStack_1a8 & 0xffffffff00000000;
        uStack_78 = 0;
        uStack_74 = 0;
        uStack_6c = 0;
        uStack_64 = 0;
        uStack_70 = 0xffffffff;
        func_0x(*(undefined8 *)(param_1 + 0x98),*(undefined8 *)(param_1 + 0x78),0,0)
        ;
        *(undefined4 *)(param_1 + 0xa8) = 1;
      }
      else {
        func_0x(*(undefined8 *)(param_1 + 0x98),1,0);
      }
    }
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_1c8);
  return;
}

