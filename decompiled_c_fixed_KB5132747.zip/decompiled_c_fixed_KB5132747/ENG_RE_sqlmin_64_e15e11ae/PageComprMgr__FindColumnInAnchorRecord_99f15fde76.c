
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_(longlong param_1,undefined (*param_2) [16],int *param_3)

{
  ushort *puVar1;
  longlong *plVar2;
  bool bVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  int iVar7;
  int *piVar8;
  longlong lVar9;
  undefined8 uVar10;
  longlong lVar11;
  short sVar12;
  uint uVar13;
  ulonglong uVar14;
  uint uVar15;
  ushort *puVar16;
  ushort *puVar17;
  ulonglong uVar18;
  uint uVar19;
  byte *pbVar20;
  longlong lVar21;
  ushort uVar22;
  ulonglong uVar23;
  int iVar24;
  ushort *puStackX_8;
  undefined auStackX_10 [8];
  undefined auStackX_20 [8];
  undefined auStack_48 [6];
  byte bStack_42;
  int *piStack_40;
  
  _auStack_48 = *param_2;
  iVar7 = 0;
  uVar22 = SUB162(_auStack_48,6);
  if ((SUB168(_auStack_48,0) >> 0x30 & 0x10) != 0) {
    uVar22 = 0;
    _auStack_48 = SUB168(_auStack_48,0) & 0xffefffffffffffff;
    piStack_40 = (int *)0x0;
  }
  if (*(longlong *)(param_1 + 8) != 0) {
    piVar8 = (int *)func_0x(*(longlong *)(param_1 + 8) + 0x18,auStack_48);
    return piVar8;
  }
  puVar1 = (ushort *)(param_1 + 0x12);
  bVar3 = false;
  if (*(short *)(param_1 + 0x10) != 0) {
    puStackX_8 = (ushort *)((ulonglong)puStackX_8 & 0xffffffff00000000);
    piVar8 = (int *)func_0x(puVar1,auStack_48,param_3,param_3,&puStackX_8);
    if (*(short *)(param_1 + 0x10) == 0) {
      return piVar8;
    }
    plVar2 = *(longlong **)(param_1 + 0x20);
    if (plVar2 == (longlong *)0x0) {
      return piVar8;
    }
    if (*plVar2 == 0) {
      return piVar8;
    }
    if ((_auStack_48 & (undefined  [16])0x8000000000000) != (undefined  [16])0x0) {
      return piVar8;
    }
    if (((ulonglong)puStackX_8 & 1) != 0) {
      return piVar8;
    }
    if ((piVar8 != (int *)0x0) && (piVar8 != (int *)0x7768f0)) {
      piVar8 = (int *)func_0x
                                (plVar2,auStack_48,piVar8,*param_3,0,0,param_3,puStackX_8._0_4_);
      return piVar8;
    }
LAB_:
    *param_3 = 0;
    return (int *)0x0;
  }
  if ((auStack_48._0_4_ & 0xc0000000) == 0x80000000) {
    iVar7 = func_0x(puVar1);
    if (iVar7 != 0) {
      piVar8 = (int *)func_0x(param_1 + 0x3a,auStack_48,param_3,auStackX_10);
      return piVar8;
    }
    goto LAB_;
  }
  pbVar20 = *(byte **)(param_1 + 0x18);
  bVar4 = *pbVar20;
  if ((bVar4 & 0x10) == 0) {
    if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
      uVar22 = ~(uVar22 >> 4);
      goto LAB_;
    }
  }
  else {
    uVar19 = *(uint *)(param_1 + 0x20);
    if ((int)auStack_48._0_4_ < (int)uVar19) {
      if ((uint)*(ushort *)(pbVar20 + uVar19) < (uint)(ushort)auStack_48._4_2_) {
        uVar22 = ~(uVar22 >> 4);
      }
      else {
        uVar15 = (ushort)auStack_48._4_2_ - 1;
        bVar3 = true;
        uVar22 = (ushort)(pbVar20[(ulonglong)uVar19 + (ulonglong)(uVar15 >> 3) + 2] >>
                         ((byte)uVar15 & 7));
      }
    }
    else {
      uVar22 = ~(uVar22 >> 4);
    }
LAB_:
    if ((uVar22 & 1) != 0) {
      *param_3 = 0;
      return (int *)0x0;
    }
    if ((!bVar3) && ((_auStack_48 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0))
    goto LAB_;
  }
  if (-1 < (int)auStack_48._0_4_) {
    if ((_auStack_48 & (undefined  [16])0x8000000000000) != (undefined  [16])0x0) {
      bVar4 = pbVar20[(int)auStack_48._0_4_];
      *param_3 = 1;
      if ((bVar4 & (byte)(1 << (bStack_42 & 7))) != 0) {
        return (int *)0x7768f0;
      }
      return (int *)0x7768f1;
    }
    if ((_auStack_48 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
          *param_3 = *piStack_40;
          return piStack_40 + 1;
        }
      }
      else if (((int)*(uint *)(param_1 + 0x20) <= (int)auStack_48._0_4_) ||
              (*(ushort *)(pbVar20 + *(uint *)(param_1 + 0x20)) < (ushort)auStack_48._4_2_))
      goto LAB_;
    }
    *param_3 = 0;
    return (int *)((longlong)(int)auStack_48._0_4_ + *(longlong *)(param_1 + 0x18));
  }
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar19 = *(uint *)(param_1 + 0x20);
    uVar14 = (ulonglong)uVar19;
    *(uint *)(param_1 + 0x24) = uVar19;
    *puVar1 = 0;
    bVar4 = *pbVar20;
    if ((bVar4 & 0x10) != 0) {
      uVar19 = uVar19 + 2 + (*(ushort *)(pbVar20 + uVar14) + 7 >> 3);
      uVar14 = (ulonglong)uVar19;
      *(uint *)(param_1 + 0x24) = uVar19;
      bVar4 = *pbVar20;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(param_1 + 0x14) = (int)uVar14;
      *(undefined2 *)(param_1 + 0x2c) = 0;
      *(int *)(param_1 + 0x28) = (int)uVar14;
    }
    else {
      puVar16 = (ushort *)(pbVar20 + uVar14);
      uVar22 = *puVar16;
      *(ushort *)(param_1 + 0x2c) = uVar22;
      puStackX_8 = puVar16;
      if (uVar22 == 0) {
        cVar5 = func_0x(0x1102250);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1102250);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9f1c5c,0xb11d48,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 0x18),3);
        uVar22 = *(ushort *)(param_1 + 0x2c);
        uVar14 = (ulonglong)*(uint *)(param_1 + 0x24);
      }
      uVar19 = (int)uVar14 + (uVar22 + 1) * 2;
      *(uint *)(param_1 + 0x28) = uVar19;
      if (0x1f9e < uVar19) {
        cVar5 = func_0x(0x1102250);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1102250);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9f1c5c,0xb11d48,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 0x18),4);
        uVar22 = *(ushort *)(param_1 + 0x2c);
        uVar19 = *(uint *)(param_1 + 0x28);
      }
      uVar14 = (ulonglong)uVar22;
      uVar22 = puVar16[uVar14];
      *(uint *)(param_1 + 0x14) = uVar22 & 0x7fff;
      if ((uVar22 & 0x7fff) < uVar19) {
        cVar5 = func_0x(0x1102250);
        if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
           (*(char *)(lVar9 + 0x499) != '\0')) {
          cVar5 = func_0x(0x1102250);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9f1c5c,0xb11d48,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 0x18),4);
        uVar19 = *(uint *)(param_1 + 0x28);
        uVar14 = (ulonglong)*(ushort *)(param_1 + 0x2c);
      }
      puVar17 = puVar16;
      iVar24 = iVar7;
      if ((short)uVar14 != 0) {
        do {
          puVar16 = puVar16 + 1;
          uVar15 = *puVar16 & 0x7fff;
          if ((uVar15 < uVar19) || (*(uint *)(param_1 + 0x14) < uVar15)) {
            cVar5 = func_0x(0x1102250);
            if ((cVar5 != '\0') &&
               ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x1102250);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9f1c5c,0xb11d48,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 0x18),4);
          }
          uVar14 = (ulonglong)*(ushort *)(param_1 + 0x2c);
          iVar24 = iVar24 + 1;
          puVar17 = puStackX_8;
          uVar19 = uVar15;
        } while (iVar24 < (int)(uint)*(ushort *)(param_1 + 0x2c));
      }
      puVar16 = puStackX_8;
      if ((short)puVar17[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
        pbVar20 = *(byte **)(param_1 + 0x18);
        do {
          uVar19 = *(ushort *)(pbVar20 + uVar14 * 2 + (ulonglong)*(uint *)(param_1 + 0x24)) & 0x7fff
          ;
          if ((int)uVar14 == 1) {
            uVar15 = *(uint *)(param_1 + 0x28);
            uVar13 = uVar15;
LAB_:
            if ((uVar19 < uVar15) || (*(uint *)(param_1 + 0x14) < uVar19)) goto LAB_;
          }
          else {
            uVar13 = *(uint *)(param_1 + 0x28);
            uVar15 = *(ushort *)(pbVar20 + uVar14 * 2 + ((ulonglong)*(uint *)(param_1 + 0x24) - 2))
                     & 0x7fff;
            if (uVar13 <= uVar15) goto LAB_;
LAB_:
            func_0x(pbVar20,7);
            uVar13 = *(uint *)(param_1 + 0x28);
          }
          if ((uVar15 < uVar13) || (*(uint *)(param_1 + 0x14) < uVar15)) goto LAB_;
          pbVar20 = *(byte **)(param_1 + 0x18);
          if (*(ushort *)(pbVar20 + uVar15) == 5) {
            *puVar1 = *puVar1 | 2;
            *(short *)(param_1 + 0x2c) = *(short *)(param_1 + 0x2c) + -1;
            uVar22 = *(ushort *)(param_1 + 0x3c) & 0xc7ff;
            uVar23 = (ulonglong)(uVar15 & 0xffff);
            *(short *)(param_1 + 0x3a) = (short)uVar15;
            uVar14 = *(ulonglong *)(param_1 + 0x18);
            if ((*(ushort *)(uVar23 + 2 + uVar14) >> 0xe & 1) != 0) {
              uVar22 = *(ushort *)(uVar23 + 2 + uVar14) & 0x3800 | uVar22;
            }
            *(ushort *)(param_1 + 0x3c) = uVar22;
            uVar6 = (uVar22 ^ *(ushort *)(uVar23 + 2 + uVar14)) & 0x7ff ^ uVar22;
            *(ushort *)(param_1 + 0x3c) = uVar6;
            uVar18 = (ulonglong)((uVar6 & 0x7ff) * 2) + 4 + uVar14 + (uVar22 >> 0xb & 7) * 2 +
                     uVar23;
            if (uVar18 < uVar23 + uVar14) {
              func_0x(uVar23 + uVar14,0x19);
              uVar6 = *(ushort *)(param_1 + 0x3c);
              uVar23 = (ulonglong)*(ushort *)(param_1 + 0x3a);
              uVar14 = (ulonglong)*(uint *)(param_1 + 0x18);
            }
            if (uVar19 - uVar15 < (((uVar6 & 0x7ff) * 2 - (int)uVar23) - (int)uVar14) + (int)uVar18)
            {
              func_0x(uVar23 + *(longlong *)(param_1 + 0x18),0x19);
              uVar6 = *(ushort *)(param_1 + 0x3c);
            }
            if (((uVar6 & 0x3800) != 0) &&
               (puVar16 = (ushort *)
                          (*(longlong *)(param_1 + 0x18) + 4 +
                          (ulonglong)*(ushort *)(param_1 + 0x3a)), (uVar6 & 0x3800) != 0)) {
              do {
                if ((uVar6 & 0x7ff) < (*puVar16 & 0x7ff)) {
                  func_0x((ulonglong)*(ushort *)(param_1 + 0x3a) +
                                  *(longlong *)(param_1 + 0x18),0x1a);
                  uVar6 = *(ushort *)(param_1 + 0x3c);
                }
                iVar7 = iVar7 + 1;
                puVar16 = puVar16 + 1;
              } while (iVar7 < (int)(uVar6 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar20 + uVar15) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar22 = *(short *)(param_1 + 0x2c) - 1;
          *(ushort *)(param_1 + 0x2c) = uVar22;
          if (uVar22 == 0) goto LAB_;
          uVar14 = (ulonglong)uVar22;
        } while ((short)puVar16[(ulonglong)(uVar22 - 1) + 1] < 0);
        uVar14 = (ulonglong)*(uint *)(param_1 + 0x14);
      }
      else {
LAB_:
        pbVar20 = *(byte **)(param_1 + 0x18);
        uVar14 = (ulonglong)*(uint *)(param_1 + 0x14);
      }
    }
    if ((*pbVar20 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x36) = 0;
    }
    else {
      *(int *)(param_1 + 0x36) = (int)uVar14;
      *(int *)(param_1 + 0x14) = (int)uVar14 + 0xe;
      uVar10 = func_0x(puVar1);
      func_0x(uVar10,auStackX_20);
      iVar7 = func_0x(auStackX_20);
      *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + iVar7;
      uVar14 = (ulonglong)*(uint *)(param_1 + 0x14);
    }
    iVar7 = (int)uVar14;
    if ((*(ulonglong *)(param_1 + 0x2e) != 0) &&
       (*(ulonglong *)(param_1 + 0x2e) < uVar14 + *(longlong *)(param_1 + 0x18))) {
      cVar5 = func_0x(0x1102250);
      if ((cVar5 != '\0') &&
         ((lVar9 = func_0x(), lVar9 != 0 && (*(char *)(lVar9 + 0x499) != '\0')))) {
        cVar5 = func_0x(0x1102250);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9f1c5c,0xb11d48,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 0x18),0x12);
      iVar7 = *(int *)(param_1 + 0x14);
    }
    if (0x3f3b < iVar7 - 1U) {
      cVar5 = func_0x(0x1102250);
      if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
         (*(char *)(lVar9 + 0x499) != '\0')) {
        cVar5 = func_0x(0x1102250);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9f1c5c,0xb11d48,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 0x18),5);
    }
  }
LAB_:
  sVar12 = -auStack_48._0_2_;
  if ((_auStack_48 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
    bVar4 = **(byte **)(param_1 + 0x18);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
        *param_3 = *piStack_40;
        return piStack_40 + 1;
      }
    }
    else if (((int)*(uint *)(param_1 + 0x20) <= (int)auStack_48._0_4_) ||
            (*(ushort *)(*(byte **)(param_1 + 0x18) + *(uint *)(param_1 + 0x20)) <
             (ushort)auStack_48._4_2_)) goto LAB_;
  }
  lVar9 = (longlong)sVar12;
  if ((uint)*(ushort *)(param_1 + 0x2c) < (uint)(int)sVar12) {
    *param_3 = 0;
    return *(int **)(param_1 + 0x18);
  }
  lVar21 = *(longlong *)(param_1 + 0x18);
  lVar11 = (ulonglong)*(uint *)(param_1 + 0x24) + lVar21;
  if (sVar12 == 1) {
    uVar19 = *(uint *)(param_1 + 0x28);
    uVar15 = *(ushort *)(lVar11 + lVar9 * 2) & 0x7fff;
LAB_:
    if ((uVar19 <= uVar15) && (uVar15 <= *(uint *)(param_1 + 0x14))) goto LAB_;
  }
  else {
    uVar19 = *(ushort *)(lVar11 + -2 + lVar9 * 2) & 0x7fff;
    lVar21 = *(longlong *)(param_1 + 0x18);
    uVar15 = *(ushort *)(lVar11 + lVar9 * 2) & 0x7fff;
    if (*(uint *)(param_1 + 0x28) <= uVar19) goto LAB_;
  }
  func_0x(lVar21,7);
LAB_:
  *param_3 = uVar15 - uVar19;
  return (int *)((ulonglong)uVar19 + *(longlong *)(param_1 + 0x18));
}

