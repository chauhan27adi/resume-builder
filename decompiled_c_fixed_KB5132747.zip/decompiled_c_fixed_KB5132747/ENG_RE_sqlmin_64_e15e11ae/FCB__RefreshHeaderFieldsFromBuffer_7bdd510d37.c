
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong param_3,undefined4 param_4)

{
  byte *pbVar1;
  byte *pbVar2;
  ushort uVar3;
  short sVar4;
  longlong lVar5;
  uint uVar6;
  char cVar7;
  int iVar8;
  short *psVar9;
  undefined8 uVar10;
  uint uVar11;
  code *UNRECOVERED_JUMPTABLE_00;
  byte **ppbVar12;
  ulonglong uVar13;
  longlong unaff_GS_OFFSET;
  undefined auStack_838 [32];
  longlong lStack_818;
  undefined8 uStack_810;
  undefined4 uStack_7f8;
  undefined4 uStack_4b4;
  undefined4 uStack_420;
  undefined2 uStack_41c;
  longlong lStack_380;
  longlong lStack_360;
  undefined8 uStack_1a0;
  undefined2 uStack_198;
  undefined auStack_150 [16];
  undefined4 uStack_140;
  undefined2 uStack_13c;
  ushort uStack_13a;
  undefined8 uStack_138;
  short sStack_f0;
  undefined4 uStack_ec;
  byte *pbStack_e8;
  byte **ppbStack_e0;
  undefined8 uStack_d2;
  undefined2 uStack_ca;
  undefined2 uStack_c8;
  undefined6 uStack_c6;
  undefined4 uStack_bc;
  undefined auStack_b8 [16];
  undefined auStack_a8 [8];
  undefined8 uStack_a0;
  undefined8 uStack_98;
  undefined6 uStack_90;
  undefined2 uStack_8a;
  undefined6 uStack_88;
  undefined2 uStack_82;
  undefined8 uStack_80;
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  undefined8 uStack_48;
  ulonglong uStack_40;
  
  uStack_40 = _DAT_ ^ (ulonglong)auStack_838;
  uStack_13a = uStack_13a & 0xffe0;
  sStack_f0 = -1;
  pbStack_e8 = (byte *)0x0;
  uStack_ec = 0;
  uStack_d2 = 0;
  uStack_c8 = 0;
  uStack_c6 = 0;
  ppbStack_e0 = (byte **)0x0;
  uStack_bc = 0xffffffff;
  uStack_140 = 0;
  uStack_13c = 0;
  uStack_138 = 0;
  uStack_4b4 = param_4;
  lStack_380 = param_3;
  lStack_360 = param_1;
  iVar8 = func_0x(param_3,1,3);
  if (iVar8 != 0) {
    if (((DAT_ & 0x40) != 0) ||
       (((lVar5 = *(longlong *)
                   ((ulonglong)*_DAT_ +
                   *(longlong *)
                    (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
         lVar5 != 0 && (lVar5 = **(longlong **)(lVar5 + 0x38), lVar5 != 0)) &&
        (iVar8 = (*_DAT_)(lVar5,0x279e), iVar8 != 0)))) {
      func_0x(0x14b15a0,0x14b1310,param_1,param_1 + 0x940);
    }
    lStack_818 = param_1 + 0x940;
    uStack_810 = 0x14b1580;
    (*_DAT_)(0x33,0x48,0x10,0xf);
  }
  uVar3 = *(ushort *)(param_3 + 0x16);
  uVar11 = (uint)uVar3;
  if ((*(byte *)(param_3 + 4) & 8) != 0) {
    uVar13 = (ulonglong)(uint)uVar3;
    if (uVar3 == 0) goto LAB_;
    psVar9 = (short *)(param_3 + 0x1ffe);
    do {
      sVar4 = *psVar9;
      psVar9 = psVar9 + -1;
      uVar6 = uVar11 - 1;
      if (sVar4 != 0) {
        uVar6 = uVar11;
      }
      uVar11 = uVar6;
      uVar13 = uVar13 - 1;
    } while (uVar13 != 0);
  }
  if ((int)uVar11 < 1) {
LAB_:
    if (((*(byte *)(param_1 + 100) & 0x40) != 0) && (*(short *)(param_1 + 0x84) != 0)) {
      *(undefined2 *)(param_1 + 0x84) = 0;
    }
    uVar10 = func_0x(param_3,auStack_150,0,0);
    func_0x(param_1 + 0x70,uVar10);
    func_0x(uStack_40 ^ (ulonglong)auStack_838);
    return;
  }
  uStack_bc = 0;
  if (-1 < *(char *)(param_3 + 2)) goto LAB_;
  pbVar1 = (byte *)(param_3 + 0x60);
  if ((sStack_f0 == 0) || (ppbVar12 = ppbStack_e0, ppbStack_e0 == (byte **)0x0)) {
    ppbVar12 = (byte **)auStack_b8;
    stack0xffffffffffffff5a = SUB1614(ZEXT816(0),2);
    auStack_a8._0_2_ = 0xffff;
    uStack_90 = 0;
    uStack_82 = 0;
    uStack_a0 = 0;
    uStack_8a = 0;
    uStack_88 = 0;
    uStack_80 = 0;
    auStack_b8 = ZEXT816(0);
    uStack_98 = 0;
    auStack_78 = ZEXT816(0);
    auStack_58._0_12_ = ZEXT812(0);
    auStack_58._12_4_ = 0;
    uStack_48 = 0;
    auStack_68 = ZEXT816(0);
  }
  if (*(short *)(param_3 + 0x24) == 0) {
LAB_:
    uStack_1a0 = *(undefined8 *)(param_3 + 0x28);
    uStack_198 = *(undefined2 *)(param_3 + 0x30);
  }
  else {
    cVar7 = *(char *)(param_3 + 1);
    if (cVar7 == '\v') {
      if (*(int *)(param_3 + 0x18) != 99) {
LAB_:
        if (cVar7 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar7 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_3 + 0x18) != 99) goto LAB_;
    }
    uStack_420 = *(undefined4 *)(param_3 + 0x20);
    uStack_41c = *(undefined2 *)(param_3 + 0x24);
    cVar7 = func_0x(&uStack_420);
    if (cVar7 == '\0') goto LAB_;
    func_0x(param_3,&uStack_1a0);
  }
  *ppbVar12 = pbVar1;
  *(undefined4 *)(ppbVar12 + 0xc) = (undefined4)uStack_1a0;
  *(int *)((longlong)ppbVar12 + 100) = (int)((ulonglong)uStack_1a0 >> 0x20);
  *(undefined2 *)(ppbVar12 + 0xd) = uStack_198;
  *(undefined4 *)((longlong)ppbVar12 + 0x6c) = *(undefined4 *)(param_3 + 0x20);
  *(undefined2 *)(ppbVar12 + 0xe) = *(undefined2 *)(param_3 + 0x24);
  *(undefined2 *)((longlong)ppbVar12 + 0x72) = 0;
  uStack_7f8 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x1288360);
  uVar13 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x1288364);
  *(undefined2 *)(ppbVar12 + 2) = 0xffff;
  ppbVar12[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar12 + 0x2e) = 0;
  ppbVar12[7] = (byte *)0x0;
  ppbVar12[4] = (byte *)0x0;
  ppbVar12[9] = (byte *)0x0;
  ppbVar12[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar12 + 0xb) = 0;
  if ((**ppbVar12 & 2) != 0) {
    pbVar2 = pbVar1 + uVar13;
    if ((pbVar1[uVar13] & 1) == 0) {
      *(undefined2 *)(ppbVar12 + 2) = 0;
      ppbVar12[3] = pbVar2;
      *(undefined4 *)((longlong)ppbVar12 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar12 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x001005b9 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x11f3b0) - 0x1310ab0))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar12 + 2) = 1;
    ppbVar12[3] = pbVar2;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x11f390) * 4 +
                           0x11f380) - 0x1310ab0);
                    /* WARNING: Could not emulate address calculation at 0x001003dc */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar12 & 4) != 0) {
    uStack_7f8._2_2_ = (short)((uint)uStack_7f8 >> 0x10);
    if (uStack_7f8._2_2_ != 0) {
      uVar13 = (ulonglong)*(ushort *)(param_3 + 0x61 + (longlong)uStack_7f8._2_2_ * 2);
    }
    psVar9 = (short *)(pbVar1 + uVar13);
    ppbVar12[9] = (byte *)psVar9;
    sVar4 = *psVar9;
    ppbVar12[10] = (byte *)(psVar9 + 1);
    *(short *)(ppbVar12 + 0xb) = (sVar4 + 1) * 2;
  }
  param_3 = lStack_380;
  if (ppbVar12[1] != (byte *)0x0) {
    func_0x(ppbVar12[1],ppbVar12);
    param_3 = lStack_380;
  }
LAB_:
  pbStack_e8 = (byte *)((ulonglong)*(ushort *)(param_3 + 0x1ffe) + param_3);
  if ((*pbStack_e8 & 1) == 0) {
    sStack_f0 = 0;
    uStack_ec = 0;
    uStack_ca = 0;
    uStack_c8 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100912 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_e8 & 0xe) * 4 + 0x11f41c) - 0x1310ab0))
              (0x1209a80,(longlong)(int)(*pbStack_e8 & 0xe),pbStack_e8,pbStack_e8);
    return;
  }
  sStack_f0 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_e8 & 0x1c) + 0x11f3fc) * 4 +
                         0x11f3ec) - 0x1310ab0);
                    /* WARNING: Could not emulate address calculation at 0x001006cf */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

