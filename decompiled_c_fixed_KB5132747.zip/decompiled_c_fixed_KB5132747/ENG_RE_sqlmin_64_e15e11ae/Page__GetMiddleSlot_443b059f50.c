
/* WARNING: Type propagation algorithm not settling */

int FUN_(longlong param_1)

{
  byte bVar1;
  ushort uVar2;
  ushort *puVar3;
  bool bVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  longlong lVar8;
  undefined8 *puVar9;
  ushort uVar10;
  ulonglong uVar11;
  uint uVar12;
  uint uVar13;
  byte *pbVar14;
  byte *pbVar15;
  uint uVar16;
  byte *pbVar17;
  byte *pbVar18;
  ulonglong uVar19;
  uint uVar20;
  ushort *puVar21;
  uint uStackX_8;
  longlong lStackX_18;
  undefined8 uStackX_20;
  ushort uStack_86;
  uint uStack_84;
  byte *pbStack_80;
  undefined8 uStack_78;
  uint uStack_70;
  ushort uStack_6c;
  byte *pbStack_6a;
  undefined2 uStack_62;
  undefined2 uStack_60;
  ushort uStack_5e;
  ushort uStack_5c;
  undefined2 uStack_5a;
  undefined4 uStack_58;
  
  if (*(char *)(param_1 + 2) < '\0') {
    iVar6 = func_0x(param_1 + 0x60);
    uVar12 = iVar6 + 0x60;
  }
  else {
    uVar12 = 0x60;
  }
  uVar2 = *(ushort *)(param_1 + 0x1c);
  iVar6 = 0;
  uStackX_8 = 0;
  if (*(short *)(param_1 + 0x16) == 0) {
    return 0;
  }
  lStackX_18 = 0;
  do {
    pbVar15 = (byte *)0x0;
    pbVar14 = (byte *)(ulonglong)*(ushort *)(param_1 + 0xe);
    uVar16 = 0;
    pbVar17 = (byte *)0x0;
    uStack_84 = 0;
    pbStack_6a = (byte *)0x0;
    pbStack_80 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - lStackX_18) * 2) + param_1);
    uStack_5e = 0;
    uStack_5c = 0;
    uStack_5a = 0;
    uStack_78 = 0;
    if ((*pbStack_80 & 1) == 0) {
      bVar4 = false;
      uStack_62 = 0;
      uStack_60 = 0;
      pbVar18 = pbVar15;
      switch(*pbStack_80 & 0xe) {
      default:
        pbVar14 = (byte *)(ulonglong)*(ushort *)(pbStack_80 + 2);
        pbVar18 = pbVar17;
        if (0x1f9d < *(ushort *)(pbStack_80 + 2) - 1) {
          func_0x(pbStack_80,6);
          pbVar18 = (byte *)(ulonglong)uStack_84;
        }
        break;
      case 4:
        pbVar14 = (byte *)0x9;
        pbVar18 = pbVar17;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        pbVar14 = (byte *)0x1;
        pbVar18 = pbVar17;
      }
      uVar16 = (uint)pbVar14;
      pbStack_6a = (byte *)(param_1 + 0x2000);
      if (param_1 == 0) {
        pbStack_6a = pbVar15;
      }
      uStack_78 = CONCAT44(uStack_78._4_4_,uVar16);
    }
    else {
      bVar4 = true;
      bVar1 = *pbStack_80;
      switch(bVar1 & 0x1c) {
      default:
        if ((char)pbStack_80[1] < '\0') {
          uVar10 = 3;
          uStack_86 = (*(ushort *)(pbStack_80 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_80 + 1) >> 8;
        }
        else {
          uStack_86 = (ushort)pbStack_80[1];
          uVar10 = 2;
        }
        uStack_70 = (uint)uVar10;
        uStack_6c = (short)(uStack_86 + 1 >> 1) + uVar10;
        if (uStack_86 < 0x1f) {
          uStack_58 = 0;
          pbVar17 = pbVar15;
        }
        else {
          iVar7 = uStack_86 - 1;
          uStack_58 = 0;
          uStack_70 = CONCAT22(((short)(iVar7 / 0x1e) + (short)(iVar7 >> 0x1f)) -
                               (short)((longlong)iVar7 * 0x88888889 >> 0x3f),uVar10);
        }
        break;
      case 4:
        if (((bVar1 & 0x1c) == 4) && ((bVar1 & 2) != 0)) {
          pbVar17 = (byte *)0xf;
          uStack_70 = 0;
          uStack_84 = 0xf;
          uStack_86 = 0;
          uStack_6c = 0;
          uStack_62 = 0;
          uStack_58 = 1;
        }
        else {
          uStack_70 = 0;
          pbVar17 = (byte *)0x1;
          uStack_86 = 0;
          uStack_6c = 0;
          uStack_62 = 0;
          uStack_84 = 1;
          uStack_58 = 0;
        }
        break;
      case 8:
        pbVar17 = (byte *)0x9;
        uStack_70 = 0;
        uStack_84 = 9;
        uStack_86 = 0;
        uStack_6c = 0;
        uStack_62 = 0;
        uStack_58 = 0;
      }
      uStack_78 = 0;
      pbVar14 = (byte *)(param_1 + 0x2000);
      if (param_1 == 0) {
        pbVar14 = pbVar15;
      }
      uStack_60 = SUB82(pbVar14,0);
      uStack_5e = (ushort)((ulonglong)pbVar14 >> 0x10);
      uStack_5c = (ushort)((ulonglong)pbVar14 >> 0x20);
      uStack_5a = (undefined2)((ulonglong)pbVar14 >> 0x30);
      pbVar14 = pbVar15;
      pbVar18 = pbVar17;
    }
    uVar13 = (uint)pbVar18;
    if (bVar4) {
      if (uVar13 == 0) {
        func_0x(&uStack_86);
        uVar13 = uStack_84;
      }
      if ((uVar13 < 9) && (((*pbStack_80 & 0x1c) == 0 || ((*pbStack_80 & 0x1c) == 0xc)))) {
        uVar13 = 9;
      }
    }
    else {
      pbVar17 = pbStack_80;
      if (uVar13 == 0) {
        uStack_86 = 0;
        uVar13 = (uint)pbVar14;
        if ((*pbStack_80 & 0x10) != 0) {
          if ((*pbStack_80 & 0x10) == 0) {
            uVar16 = 0;
          }
          else {
            uVar16 = (uint)*(ushort *)(pbStack_80 + uVar16);
          }
          uVar13 = uVar13 + 2 + (uVar16 + 7 >> 3);
          pbVar14 = (byte *)(ulonglong)uVar13;
        }
        uStack_78 = CONCAT44(uVar13,(int)uStack_78);
        if ((*pbStack_80 & 0x20) == 0) {
          uStack_6c = 0;
          pbVar18 = pbVar14;
          uStack_84 = (uint)pbVar14;
          uStack_70 = (uint)pbVar14;
        }
        else {
          puVar21 = (ushort *)(pbStack_80 + (longlong)pbVar14);
          uStack_6c = *puVar21;
          if (uStack_6c == 0) {
            cVar5 = func_0x(0x1a5a960);
            if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
               (*(char *)(lVar8 + 0x499) != '\0')) {
              cVar5 = func_0x(0x1a5a960);
              if (cVar5 == '\0') {
                (*pcRam0000000000fc84e8)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*pcRam0000000000fc84e0)(1,0x134a36c,0x146a458,0x80f,0);
              }
            }
            func_0x(pbStack_80,3);
            pbVar14 = (byte *)(uStack_78 >> 0x20);
          }
          uStack_70 = (int)pbVar14 + (uStack_6c + 1) * 2;
          if (0x1f9e < uStack_70) {
            cVar5 = func_0x(0x1a5a960);
            if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
               (*(char *)(lVar8 + 0x499) != '\0')) {
              cVar5 = func_0x(0x1a5a960);
              if (cVar5 == '\0') {
                (*pcRam0000000000fc84e8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*pcRam0000000000fc84e0)(1,0x134a36c,0x146a458,0x816,0);
              }
            }
            func_0x(pbStack_80,4);
            pbVar14 = (byte *)(uStack_78 >> 0x20);
          }
          uVar19 = (ulonglong)uStack_6c;
          uStack_84 = puVar21[uVar19] & 0x7fff;
          if (uStack_84 < uStack_70) {
            cVar5 = func_0x(0x1a5a960);
            if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
               (*(char *)(lVar8 + 0x499) != '\0')) {
              cVar5 = func_0x(0x1a5a960);
              if (cVar5 == '\0') {
                (*pcRam0000000000fc84e8)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*pcRam0000000000fc84e0)(1,0x134a36c,0x146a458,0x81d,0);
              }
            }
            func_0x(pbStack_80,4);
            uVar19 = (ulonglong)uStack_6c;
            pbVar14 = (byte *)(uStack_78 >> 0x20);
          }
          pbVar18 = (byte *)(ulonglong)uStack_84;
          pbVar17 = pbStack_80;
          uVar16 = uStack_70;
          puVar3 = puVar21;
          if ((short)uVar19 != 0) {
            do {
              uVar13 = puVar3[1] & 0x7fff;
              if ((uVar13 < uVar16) || ((uint)pbVar18 < uVar13)) {
                cVar5 = func_0x(0x1a5a960);
                if ((cVar5 != '\0') &&
                   ((lVar8 = func_0x(), lVar8 != 0 &&
                    (*(char *)(lVar8 + 0x499) != '\0')))) {
                  cVar5 = func_0x(0x1a5a960);
                  if (cVar5 == '\0') {
                    (*pcRam0000000000fc84e8)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*pcRam0000000000fc84e0)(1,0x134a36c,0x146a458,0x82a,0);
                  }
                }
                func_0x(pbStack_80,4);
                uVar19 = (ulonglong)uStack_6c;
                pbVar18 = (byte *)(ulonglong)uStack_84;
                pbVar17 = pbStack_80;
              }
              uVar20 = (int)pbVar15 + 1;
              pbVar15 = (byte *)(ulonglong)uVar20;
              uVar16 = uVar13;
              puVar3 = puVar3 + 1;
            } while ((int)uVar20 < (int)uVar19);
            pbVar14 = (byte *)(uStack_78 >> 0x20);
            uVar16 = uStack_70;
          }
          while ((short)puVar21[(ulonglong)((int)uVar19 - 1) + 1] < 0) {
            if ((int)uVar19 == 1) {
              uVar11 = 1;
              uVar13 = uVar16;
            }
            else {
              uVar13 = *(ushort *)(pbVar17 + (longlong)(pbVar14 + uVar19 * 2 + -2)) & 0x7fff;
              uVar11 = uVar19;
            }
            uVar20 = *(ushort *)(pbVar17 + (longlong)(pbVar14 + uVar11 * 2)) & 0x7fff;
            if (((uVar13 < uVar16) || (uVar20 < uVar13)) || ((uint)pbVar18 < uVar20)) {
              func_0x(pbVar17,7);
              uVar19 = (ulonglong)uStack_6c;
              pbVar18 = (byte *)(ulonglong)uStack_84;
              pbVar14 = (byte *)(uStack_78 >> 0x20);
              pbVar17 = pbStack_80;
              uVar16 = uStack_70;
            }
            if ((uVar13 < uVar16) || ((uint)pbVar18 < uVar13)) goto code_r0x001009a3;
            if (*(ushort *)(pbVar17 + uVar13) == 5) {
              uStack_86 = uStack_86 | 2;
              uStack_6c = (short)uVar19 - 1;
              uVar19 = (ulonglong)(uVar13 & 0xffff);
              pbVar14 = pbVar17 + uVar19;
              uStack_5e = (ushort)uVar13;
              if ((*(ushort *)(pbVar14 + 2) >> 0xe & 1) == 0) {
                uVar10 = uStack_5c & 0xc7ff;
              }
              else {
                uVar10 = uStack_5c ^ (uStack_5c ^ *(ushort *)(pbVar14 + 2)) & 0x3800;
              }
              uStack_5c = (uVar10 ^ *(ushort *)(pbVar14 + 2)) & 0x7ff ^ uVar10;
              uVar11 = (ulonglong)uStack_5c;
              pbVar15 = pbVar17 + uVar19 + (uVar11 & 0x7ff) * 2 +
                                           (ulonglong)((uVar10 >> 0xb & 7) * 2) + 4;
              if (pbVar15 < pbVar14) {
                func_0x(pbVar14,0x19);
                uVar11 = (ulonglong)uStack_5c;
                uVar19 = (ulonglong)uStack_5e;
                pbVar18 = (byte *)(ulonglong)uStack_84;
                pbVar17 = pbStack_80;
              }
              if (uVar20 - uVar13 <
                  (((uStack_5c & 0x7ff) * 2 - (int)uVar19) - (int)pbStack_80) + (int)pbVar15) {
                func_0x(pbVar17 + uVar19,0x19);
                uVar11 = (ulonglong)uStack_5c;
                uVar19 = (ulonglong)uStack_5e;
                pbVar18 = (byte *)(ulonglong)uStack_84;
                pbVar17 = pbStack_80;
              }
              if ((uVar11 & 0x3800) != 0) {
                puVar21 = (ushort *)(pbVar17 + uVar19 + 4);
                iVar7 = 0;
                if ((uVar11 & 0x3800) != 0) {
                  do {
                    if (((ushort)uVar11 & 0x7ff) < (*puVar21 & 0x7ff)) {
                      func_0x(pbVar17 + uVar19,0x1a);
                      uVar11 = (ulonglong)uStack_5c;
                      uVar19 = (ulonglong)uStack_5e;
                      pbVar17 = pbStack_80;
                    }
                    iVar7 = iVar7 + 1;
                    puVar21 = puVar21 + 1;
                  } while (iVar7 < (int)((uStack_5c & 0x3800) >> 0xb));
                  pbVar18 = (byte *)(ulonglong)uStack_84;
                }
              }
              break;
            }
            if (*(ushort *)(pbVar17 + uVar13) < 0x400) break;
            uStack_86 = uStack_86 | 1;
            uStack_6c = (short)uVar19 - 1;
            uVar19 = (ulonglong)uStack_6c;
            if (uStack_6c == 0) break;
          }
        }
        if ((*pbVar17 & 0x40) == 0) {
          uStack_62 = 0;
          uStack_60 = 0;
        }
        else {
          uStack_62 = SUB82(pbVar18,0);
          uStack_60 = (undefined2)((ulonglong)pbVar18 >> 0x10);
          uStack_84 = (int)pbVar18 + 0xe;
          puVar9 = (undefined8 *)func_0x(&uStack_86);
          uStackX_20 = *puVar9;
          iVar7 = func_0x(&uStackX_20);
          uStack_84 = uStack_84 + iVar7;
          pbVar18 = (byte *)(ulonglong)uStack_84;
          pbVar17 = pbStack_80;
        }
        if ((pbStack_6a != (byte *)0x0) && (pbStack_6a < pbVar18 + (longlong)pbVar17)) {
          cVar5 = func_0x(0x1a5a960);
          if ((cVar5 != '\0') &&
             ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))
             ) {
            cVar5 = func_0x(0x1a5a960);
            if (cVar5 == '\0') {
              (*pcRam0000000000fc84e8)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*pcRam0000000000fc84e0)(1,0x134a36c,0x146a458,0x886,0);
            }
          }
          func_0x(pbStack_80,0x12);
          pbVar18 = (byte *)(ulonglong)uStack_84;
          pbVar17 = pbStack_80;
        }
        if (0x3f3b < (int)pbVar18 - 1U) {
          cVar5 = func_0x(0x1a5a960);
          if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
             (*(char *)(lVar8 + 0x499) != '\0')) {
            cVar5 = func_0x(0x1a5a960);
            if (cVar5 == '\0') {
              (*pcRam0000000000fc84e8)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*pcRam0000000000fc84e0)(1,0x134a36c,0x146a458,0x88b,0);
            }
          }
          func_0x(pbStack_80,5);
          pbVar18 = (byte *)(ulonglong)uStack_84;
          pbVar17 = pbStack_80;
        }
      }
code_r0x001009a3:
      uVar13 = (uint)pbVar18;
      if ((uVar13 < 9) && (((*pbVar17 & 0xe) == 0 || ((*pbVar17 & 0xe) == 0xc)))) {
        uVar13 = 9;
      }
    }
    uStackX_8 = uStackX_8 + 2 + uVar13;
    if ((0x2000 - (uint)uVar2) - (uVar12 & 0xffff) >> 1 < uStackX_8) {
      return iVar6;
    }
    lStackX_18 = lStackX_18 + 1;
    iVar6 = iVar6 + 1;
    if ((int)(uint)*(ushort *)(param_1 + 0x16) <= iVar6) {
      return iVar6;
    }
  } while( true );
}

