
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,int *param_3,int param_4)

{
  longlong **pplVar1;
  byte *pbVar2;
  int *piVar3;
  undefined uVar4;
  short sVar5;
  ushort uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong *plVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 *puVar13;
  longlong *plVar14;
  undefined auVar15 [16];
  uint **ppuVar16;
  char cVar17;
  undefined2 uVar18;
  int iVar19;
  uint uVar20;
  int iVar21;
  longlong lVar22;
  short *psVar23;
  uint *puVar24;
  ulonglong uVar25;
  longlong *plVar26;
  longlong lVar27;
  longlong lVar28;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar29;
  int iVar30;
  byte **ppbVar31;
  longlong lVar32;
  longlong lVar33;
  uint uVar34;
  undefined4 uVar35;
  byte *pbVar36;
  int *piVar37;
  ulonglong uVar38;
  longlong unaff_GS_OFFSET;
  bool bVar39;
  undefined4 unaff_XMM6_Da;
  undefined4 unaff_XMM6_Db;
  undefined4 unaff_XMM6_Dc;
  undefined4 unaff_XMM6_Dd;
  undefined auStackX_8 [4];
  uint uStackX_c;
  uint auStackX_10 [2];
  longlong lStackX_18;
  undefined auStackX_20 [4];
  uint uStackX_24;
  longlong *plStack_1f78;
  undefined uStack_1f70;
  uint uStack_1f6c;
  longlong lStack_1f60;
  undefined4 uStack_1f58;
  undefined2 uStack_1f54;
  int *piStack_1f50;
  undefined8 uStack_1f40;
  undefined8 uStack_1f28;
  int iStack_1f20;
  longlong lStack_1f18;
  undefined8 uStack_1f10;
  undefined4 uStack_1f08;
  uint auStack_1ef8 [4];
  undefined8 uStack_1ee8;
  ushort uStack_1ee0;
  undefined8 uStack_1eb8;
  undefined2 uStack_1eb0;
  undefined8 uStack_1e98;
  ushort uStack_1e90;
  undefined auStack_1e2c [4];
  undefined4 auStack_1e28 [14];
  undefined4 uStack_1df0;
  undefined2 uStack_1dec;
  undefined2 uStack_1dea;
  int iStack_1de8;
  undefined2 uStack_1de4;
  undefined2 uStack_1de2;
  undefined8 uStack_1dd8;
  undefined2 uStack_1dd0;
  undefined4 uStack_1dc8;
  undefined2 uStack_1dc4;
  undefined4 uStack_1db8;
  undefined2 uStack_1db4;
  undefined4 uStack_1db0;
  undefined2 uStack_1dac;
  undefined4 uStack_1da8;
  undefined2 uStack_1da4;
  uint uStack_1cb0;
  undefined8 uStack_1cac;
  undefined8 uStack_1c18;
  undefined2 uStack_1c10;
  undefined8 uStack_1c08;
  ushort uStack_1c00;
  undefined auStack_1bf8 [8];
  undefined auStack_1bf0 [16];
  undefined auStack_1be0 [4];
  undefined auStack_1bdc [4];
  undefined auStack_1bd8 [4];
  undefined auStack_1bd4 [60];
  longlong **pplStack_1b98;
  undefined8 uStack_1b60;
  undefined auStack_1a78 [8];
  undefined4 uStack_1a70;
  undefined4 uStack_1a68;
  uint **ppuStack_1a60;
  undefined *puStack_1a58;
  undefined8 uStack_1a50;
  uint *puStack_1a48;
  undefined4 uStack_1a40;
  undefined4 uStack_1a3c;
  longlong lStack_1a38;
  undefined4 uStack_1a30;
  undefined4 uStack_1a2c;
  longlong lStack_1a28;
  undefined4 uStack_1a20;
  undefined4 uStack_1a1c;
  short *psStack_1a18;
  int iStack_1a10;
  undefined4 uStack_1a0c;
  short *psStack_1a08;
  int iStack_1a00;
  undefined4 uStack_19fc;
  undefined8 uStack_19f8;
  undefined4 uStack_19f0;
  undefined4 uStack_19ec;
  undefined auStack_19e8 [448];
  undefined8 uStack_1828;
  undefined8 uStack_1820;
  uint uStack_1818;
  undefined2 uStack_1814;
  int iStack_1812;
  undefined uStack_180e;
  undefined uStack_180d;
  short sStack_d58;
  undefined4 uStack_d54;
  byte *pbStack_d50;
  byte **ppbStack_d48;
  undefined8 uStack_d3a;
  undefined2 uStack_d32;
  undefined2 uStack_d30;
  undefined6 uStack_d2e;
  int iStack_d24;
  undefined auStack_d20 [16];
  undefined auStack_d10 [8];
  undefined8 uStack_d08;
  undefined8 uStack_d00;
  undefined6 uStack_cf8;
  undefined2 uStack_cf2;
  undefined6 uStack_cf0;
  undefined2 uStack_cea;
  undefined8 uStack_ce8;
  undefined auStack_ce0 [16];
  undefined auStack_cd0 [16];
  undefined auStack_cc0 [16];
  undefined8 uStack_cb0;
  undefined auStack_ca8 [20];
  undefined uStack_c94;
  short asStack_240 [24];
  short asStack_210 [216];
  ulonglong uStack_60;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar22 = func_0x();
  lVar22 = -lVar22;
  uStack_1b60 = 0xfffffffffffffffe;
  auVar15._4_4_ = unaff_XMM6_Db;
  auVar15._0_4_ = unaff_XMM6_Da;
  auVar15._8_4_ = unaff_XMM6_Dc;
  auVar15._12_4_ = unaff_XMM6_Dd;
  *(undefined (*) [16])(&stack0x00001f70 + lVar22) = auVar15;
  uStack_60 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar22);
  piStack_1f50 = param_3;
  lStack_1f18 = param_1;
  uStack_1f28 = (longlong *)CONCAT44(uStack_1f28._4_4_,10);
  uStack_c94 = 0;
  lVar28 = 0;
  *(undefined8 *)(auStackX_20 + lVar22 + -0x20) = 0;
  auStackX_8[lVar22] = 0;
  uVar34 = *(uint *)((longlong)&uStackX_c + lVar22);
  *(uint *)((longlong)&uStackX_c + lVar22) = uVar34 & 0xffff0000;
  *(uint *)((longlong)&uStackX_c + lVar22) = uVar34 & 0xff000000;
  *(undefined4 *)((longlong)&uStackX_c + lVar22) = 0;
  plStack_1f78 = (longlong *)0x0;
  uStack_1f70 = 0;
  uStack_1f6c = 0;
  *(undefined8 *)((longlong)&lStackX_18 + lVar22) = 0;
  auStackX_20[lVar22] = 0;
  uVar34 = *(uint *)((longlong)&uStackX_24 + lVar22);
  *(uint *)((longlong)&uStackX_24 + lVar22) = uVar34 & 0xffff0000;
  *(uint *)((longlong)&uStackX_24 + lVar22) = uVar34 & 0xff000000;
  *(undefined4 *)((longlong)&uStackX_24 + lVar22) = 0;
  *(undefined8 *)(&stack0x00000030 + lVar22) = 0;
  (&stack0x00000038)[lVar22] = 0;
  uVar34 = *(uint *)(&stack0x0000003c + lVar22);
  *(uint *)(&stack0x0000003c + lVar22) = uVar34 & 0xffff0000;
  *(uint *)(&stack0x0000003c + lVar22) = uVar34 & 0xff000000;
  *(undefined4 *)(&stack0x0000003c + lVar22) = 0;
  iStack_1f20 = 0xffffffff;
  uStack_1f58 = 0;
  uStack_1f54 = 0;
  pplVar1 = (longlong **)(param_1 + 0x18);
  *(undefined8 *)(&stack0xfffffffffffffff8 + lVar22) = 0;
  *(undefined **)(&stack0xfffffffffffffff0 + lVar22) = auStack_ca8;
  *(longlong ***)(&stack0xffffffffffffffe8 + lVar22) = pplVar1;
  *(int *)(&stack0xffffffffffffffe0 + lVar22) = param_4 + 1;
  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100134;
  pplStack_1b98 = pplVar1;
  func_0x(param_1);
  plVar26 = plStack_1f78;
  if (*pplVar1 == (longlong *)0x0) {
    if (*(int *)(param_1 + 0x40) == 0) {
LAB_:
      *(undefined4 *)(param_1 + 0x4c) = 0;
      *(undefined2 *)(param_1 + 0x50) = 0;
LAB_:
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x106013;
      func_0x(&stack0x00000030 + lVar22);
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10601e;
      func_0x((longlong)&lStackX_18 + lVar22);
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x106028;
      func_0x(&plStack_1f78);
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x106033;
      func_0x(auStackX_20 + lVar22 + -0x20);
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x106045;
      func_0x(uStack_60 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar22));
      return;
    }
    if ((*(int *)(param_1 + 0x4c) != 0) || (*(short *)(param_1 + 0x50) != 0)) {
      if (*(int *)(param_1 + 0x40) != 0) {
        uVar7 = *(undefined4 *)(param_1 + 0x44);
        uVar8 = *(undefined8 *)(param_1 + 0x38);
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105ff4;
        func_0x(uVar8,uVar7);
        *(undefined4 *)(param_1 + 0x40) = 0;
      }
      goto LAB_;
    }
    uStack_1f28 = *(longlong **)(param_1 + 8);
    lVar27 = **(longlong **)(param_1 + 8);
    lStack_1f60 = lVar27;
    if (*(int *)(param_1 + 0x44) != 4) {
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar22) = 0;
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104c36;
      (*_DAT_)(1,0x1b4d7b0,0x1b4d820,0x618);
      uStack_1f28 = *(longlong **)(param_1 + 8);
      lStack_1f60 = **(longlong **)(param_1 + 8);
    }
    lVar9 = *(longlong *)(param_1 + 0x10);
    lVar27 = *(longlong *)(lVar27 + 8);
    piVar37 = (int *)(lVar27 + 0x3d4);
    uStack_1cac = 0;
    lVar32 = *(longlong *)(lStack_1f60 + 0x20);
    lVar29 = (ulonglong)*(uint6 *)(lStack_1f60 + 0x14) * 0x10000;
    if (((*(longlong *)(lVar32 + 2000) != lVar29) ||
        ((*(longlong *)(lVar32 + 2000) + 1U & 0xfffffffffffffffe) == 0)) &&
       ((*(longlong *)(lVar32 + 0x7d8) != lVar29 ||
        ((*(longlong *)(lVar32 + 0x7d8) + 1U & 0xfffffffffffffffe) == 0)))) {
      lVar33 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar29 = *(longlong *)(lVar33 + 0x100);
      puVar24 = _DAT_;
      if (lVar29 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104cda;
        puVar24 = (uint *)(*_DAT_)(0);
        lVar29 = *(longlong *)(lVar33 + 0x100);
      }
      uVar38 = rdtsc();
      uVar25 = CONCAT44((int)((ulonglong)puVar24 >> 0x20),(int)uVar38) | uVar38 & 0xffffffff00000000
      ;
      uVar38 = *(ulonglong *)(lVar29 + 0x340);
      if ((uVar38 < uVar25) ||
         ((uVar38 != 0x7fffffffffffffff &&
          (*(ulonglong *)(*(longlong *)(lVar29 + 0x260) + 0xdf0) < uVar38 - uVar25)))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104d53;
        iVar30 = func_0x(0,0x20db598);
        bVar39 = iVar30 == 2;
      }
      else {
        if (((*(uint *)(*(longlong *)(lVar29 + 600) + 0xbc) & 4) == 0) ||
           (lVar29 = *(longlong *)(*(longlong *)(lVar29 + 600) + 0x98),
           (*(byte *)(lVar29 + 0x268) & 1) != 0)) goto LAB_;
        bVar39 = (*(uint *)(lVar29 + 800) & 0x180) == 0;
      }
      if (bVar39) {
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104d5f;
        func_0x(0x7c);
      }
    }
LAB_:
    if ((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) {
      lVar29 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar29 != 0) && (lVar29 = **(longlong **)(lVar29 + 0x38), lVar29 != 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104db2;
        iVar30 = (*_DAT_)(lVar29,0x337);
        if (iVar30 != 0) goto LAB_;
      }
      lVar29 = *(longlong *)
                ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) + 8);
      if (lVar29 != 0) {
        lVar28 = *(longlong *)(lVar29 + 0x60);
      }
    }
LAB_:
    uStack_1f40 = lVar28;
    lVar28 = *(longlong *)(lVar32 + 0x728);
    do {
      lVar33 = uStack_1f40;
      auStack_1ef8[0] = 0;
      lVar29 = *(longlong *)(auStackX_20 + lVar22 + -0x20);
      if (lVar29 != 0) {
        iVar30 = (int)*(short *)((longlong)&uStackX_c + lVar22);
        if (((*(ushort *)(lVar29 + 0x62) & 0x400) == 0) || (iVar30 < 3)) {
          plVar26 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
          if (((byte)*(undefined2 *)(lVar29 + 0x62) >> 3 & 1) != 0) {
            if (iVar30 == 3) {
              iVar30 = 4;
            }
            else if (iVar30 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 100) & 8) != 0) &&
                (lVar29 = *(longlong *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 0x90),
                lVar29 != 0)) && (*(longlong *)(lVar29 + 0x758) != 0)) {
              uVar8 = *(undefined8 *)(auStackX_20 + lVar22 + -0x20);
              uVar12 = *(undefined8 *)(lVar29 + 0x758);
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104e90;
              func_0x(uVar12,uVar8,iVar30);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar26 + 100) & 8) != 0)) &&
             ((2 < iVar30 &&
              (((*(uint *)((longlong)plVar26 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar29 = *plVar26, lVar29 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104ed4;
            iVar19 = (*_DAT_)(lVar29,0x2000,2,auStack_1be0);
            if (iVar19 != 0) {
              LOCK();
              *(uint *)((longlong)plVar26 + 100) = *(uint *)((longlong)plVar26 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar26 + 100) = *(uint *)((longlong)plVar26 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104ef6;
          func_0x(plVar26 + 0x13,iVar30);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104f15;
            func_0x(plVar26,0,iVar30);
          }
          *(uint *)((longlong)&uStackX_c + lVar22) =
               *(uint *)((longlong)&uStackX_c + lVar22) & 0xffff0000;
          *(undefined8 *)(auStackX_20 + lVar22 + -0x20) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104e2b;
          func_0x(auStackX_20 + lVar22 + -0x20);
        }
      }
      if (*(longlong *)(lVar32 + 0x728) != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104f47;
        func_0x(auStackX_20 + lVar22 + -0x20,piVar37,lVar32);
        lVar29 = *(longlong *)(auStackX_20 + lVar22 + -0x20);
        if (lVar29 != 0) {
          iVar30 = (int)*(short *)((longlong)&uStackX_c + lVar22);
          if (((*(ushort *)(lVar29 + 0x62) & 0x400) == 0) || (iVar30 < 3)) {
            plVar26 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
            if (((byte)*(undefined2 *)(lVar29 + 0x62) >> 3 & 1) != 0) {
              if (iVar30 == 3) {
                iVar30 = 4;
              }
              else if (iVar30 < 2) goto LAB_;
              if ((((*(uint *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 100) & 8) != 0) &&
                  (lVar29 = *(longlong *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 0x90),
                  lVar29 != 0)) && (*(longlong *)(lVar29 + 0x758) != 0)) {
                uVar8 = *(undefined8 *)(auStackX_20 + lVar22 + -0x20);
                uVar12 = *(undefined8 *)(lVar29 + 0x758);
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104fd7;
                func_0x(uVar12,uVar8,iVar30);
              }
            }
LAB_:
            if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar26 + 100) & 8) != 0)) &&
               ((2 < iVar30 &&
                (((*(uint *)((longlong)plVar26 + 100) & 0xc0000000) != 0x40000000 &&
                 (lVar29 = *plVar26, lVar29 != 0)))))) {
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10501b;
              iVar19 = (*_DAT_)(lVar29,0x2000,2,auStack_1bf8);
              if (iVar19 != 0) {
                LOCK();
                *(uint *)((longlong)plVar26 + 100) = *(uint *)((longlong)plVar26 + 100) & 0x3fffffff
                ;
                UNLOCK();
                LOCK();
                *(uint *)((longlong)plVar26 + 100) = *(uint *)((longlong)plVar26 + 100) | 0x40000000
                ;
                UNLOCK();
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10503d;
            func_0x(plVar26 + 0x13,iVar30);
            if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10505c;
              func_0x(plVar26,0,iVar30);
            }
            *(uint *)((longlong)&uStackX_c + lVar22) =
                 *(uint *)((longlong)&uStackX_c + lVar22) & 0xffff0000;
            *(undefined8 *)(auStackX_20 + lVar22 + -0x20) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x104f72;
            func_0x(auStackX_20 + lVar22 + -0x20);
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105076;
      func_0x(lVar32,piVar37);
      *(uint **)(&stack0xffffffffffffffe8 + lVar22) = &uStack_1cb0;
      *(undefined4 *)(&stack0xffffffffffffffe0 + lVar22) = 4;
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1050a0;
      plVar26 = (longlong *)func_0x(_DAT_,lVar32,piVar37,auStack_1ef8);
      *(longlong **)(auStackX_20 + lVar22 + -0x20) = plVar26;
      uVar34 = *(uint *)((longlong)&uStackX_c + lVar22) & 0xffff0004 | 4;
      *(uint *)((longlong)&uStackX_c + lVar22) = uVar34;
      if (lVar33 != 0) {
        uVar38 = (ulonglong)(*(uint *)(lVar33 + 0x500) & 0xf);
        if (*(longlong *)(lVar33 + 0x508 + uVar38 * 8) != *plVar26) {
          *(longlong *)(lVar33 + 0x508 + uVar38 * 8) = *plVar26;
          *(longlong *)(lVar33 + 0x500) = *(longlong *)(lVar33 + 0x500) + 1;
          uVar34 = *(uint *)((longlong)&uStackX_c + lVar22);
        }
      }
      uVar34 = (auStack_1ef8[0] >> 3 & 1) << 0x18 | uVar34 & 0xffffff;
      *(uint *)((longlong)&uStackX_c + lVar22) = uVar34;
      *(uint *)((longlong)auStackX_10 + lVar22) =
           auStack_1ef8[0] >> 4 & 1 | *(uint *)((longlong)auStackX_10 + lVar22) & 0xffffff00;
      if (((lVar28 != 0) && (lVar33 != 0)) && (lVar33 == *(longlong *)(lVar32 + 0x1c38))) {
        *(longlong *)(lVar28 + 0x5b28) = *(longlong *)(lVar28 + 0x5b28) + 1;
        if ((int)uStack_1cac != 0) {
          *(longlong *)(lVar28 + 0x5b30) = *(longlong *)(lVar28 + 0x5b30) + 1;
          *(longlong *)(lVar28 + 0x5b38) = *(longlong *)(lVar28 + 0x5b38) + (ulonglong)uStack_1cb0;
          if (0xffffff < uVar34) {
            *(longlong *)(lVar28 + 0x5b40) = *(longlong *)(lVar28 + 0x5b40) + 1;
            *(longlong *)(lVar28 + 0x5b48) = *(longlong *)(lVar28 + 0x5b48) + (ulonglong)uStack_1cb0
            ;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105176;
      cVar17 = func_0x(lVar32);
      if (((cVar17 == '\0') || (*(char *)(lVar32 + 0x2050) == '\0')) ||
         ((*piVar37 == 0 || ((*piVar37 == 9 && (*(short *)(lVar27 + 0x3d8) == 1))))))
      goto LAB_;
      lVar29 = **(longlong **)(auStackX_20 + lVar22 + -0x20);
      if (*(short *)(lVar29 + 0x24) == 0) {
LAB_:
        uStack_1e98 = *(undefined8 *)(lVar29 + 0x28);
        uStack_1e90 = *(ushort *)(lVar29 + 0x30);
      }
      else {
        cVar17 = *(char *)(lVar29 + 1);
        if (cVar17 == '\v') {
          if (*(int *)(lVar29 + 0x18) != 99) {
LAB_:
            if (cVar17 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar17 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar29 + 0x18) != 99) goto LAB_;
        }
        uStack_1db8 = *(undefined4 *)(lVar29 + 0x20);
        uStack_1db4 = *(undefined2 *)(lVar29 + 0x24);
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105202;
        cVar17 = func_0x(&uStack_1db8);
        if (cVar17 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105212;
        func_0x(lVar29,&uStack_1e98);
      }
      uVar34 = *(uint *)(lVar32 + 0x2108);
      do {
        uVar20 = uVar34 & 0xfffffffe;
        uStack_1f10 = *(undefined8 *)(lVar32 + 0x20fc);
        uVar8 = uStack_1f10;
        uStack_1f08 = *(undefined4 *)(lVar32 + 0x2104);
        uVar7 = uStack_1f08;
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc0 + lVar22) =
             *(undefined4 *)(&stack0xffffffffffffffc0 + lVar22);
        UNLOCK();
        uVar34 = *(uint *)(lVar32 + 0x2108);
      } while (uVar20 != uVar34);
      bVar39 = (uint)uStack_1f10 != (uint)uStack_1e98;
      if ((uint)uStack_1e98 <= (uint)uStack_1f10) {
        uStack_1f10 = uVar8;
        uStack_1f08 = uVar7;
        if (bVar39) goto LAB_;
        uVar34 = (uint)((ulonglong)uStack_1f10 >> 0x20);
        if ((uStack_1e98._4_4_ <= uVar34) &&
           ((uVar34 != uStack_1e98._4_4_ || (bVar39 = uStack_1e90 <= (ushort)uStack_1f08, bVar39))))
        goto LAB_;
      }
      uStack_1f10 = uVar8;
      uStack_1f08 = uVar7;
      if ((*(char *)(lVar32 + 0x6ac8) == '\0') &&
         (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) != *(longlong *)(lVar32 + 0x2120))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1052c8;
        cVar17 = func_0x(lVar32);
        if (cVar17 == '\0') {
          uVar34 = *(uint *)(lVar32 + 0x2108);
          do {
            uVar20 = uVar34 & 0xfffffffe;
            uStack_1f10 = *(undefined8 *)(lVar32 + 0x20fc);
            uStack_1f08 = *(undefined4 *)(lVar32 + 0x2104);
            uVar7 = uStack_1f08;
            LOCK();
            *(undefined4 *)(&stack0xffffffffffffffc0 + lVar22) =
                 *(undefined4 *)(&stack0xffffffffffffffc0 + lVar22);
            UNLOCK();
            uVar34 = *(uint *)(lVar32 + 0x2108);
          } while (uVar20 != uVar34);
          uStack_1c08 = uStack_1f10;
          uVar6 = (ushort)uStack_1f08;
          uStack_1c00 = (ushort)uStack_1f08;
          lVar28 = **(longlong **)(auStackX_20 + lVar22 + -0x20);
          uStack_1f08 = uVar7;
          if (*(short *)(lVar28 + 0x24) == 0) {
LAB_:
            uStack_1ee8 = *(undefined8 *)(lVar28 + 0x28);
            uStack_1ee0 = *(ushort *)(lVar28 + 0x30);
          }
          else {
            cVar17 = *(char *)(lVar28 + 1);
            if (cVar17 == '\v') {
              if (*(int *)(lVar28 + 0x18) != 99) {
LAB_:
                if (cVar17 != '\t') goto LAB_;
                goto LAB_;
              }
            }
            else {
              if (cVar17 != '\b') goto LAB_;
LAB_:
              if (*(int *)(lVar28 + 0x18) != 99) goto LAB_;
            }
            uStack_1da8 = *(undefined4 *)(lVar28 + 0x20);
            uStack_1da4 = *(undefined2 *)(lVar28 + 0x24);
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1055be;
            cVar17 = func_0x(&uStack_1da8);
            if (cVar17 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1055ce;
            func_0x(lVar28,&uStack_1ee8);
          }
          if ((uint)uStack_1f10 < (uint)uStack_1ee8) {
LAB_:
            lVar28 = *(longlong *)(lVar32 + 0x6b0);
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105633;
            func_0x(&uStack_1ee8,asStack_240,auStack_1e2c);
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10564d;
            func_0x(&uStack_1c08,asStack_210,auStack_1e2c);
            if ((_DAT_ & 0x10000) != 0) {
              uStack_1a70 = 0x60000;
              iVar30 = 0;
              uStack_1a68 = 0;
              ppuStack_1a60 = &puStack_1a48;
              puStack_1a58 = auStack_19e8;
              uStack_1828 = 0;
              uStack_1a50 = 0;
              uStack_1820 = 0;
              puStack_1a48 = &uStack_1818;
              uStack_1a40 = 0x34;
              uStack_1a3c = 5;
              lStack_1a38 = 0x18cb7f8;
              uStack_1a30 = 0x10;
              uStack_1a2c = 5;
              lStack_1a28 = 0x18cb7f8;
              uStack_1a20 = 0x10;
              uStack_1a1c = 6;
              psStack_1a18 = (short *)0x0;
              iStack_1a10 = 0;
              uStack_1a0c = 7;
              psStack_1a08 = (short *)0x0;
              iStack_1a00 = 0;
              uStack_19fc = 8;
              uStack_19f8 = 0;
              uStack_19f0 = 0;
              uStack_19ec = 9;
              uStack_1818 = (uint)*(ushort *)(lVar32 + 0x6b8);
              uStack_1814 = *(undefined2 *)(lVar27 + 0x3d8);
              iStack_1812 = *piVar37;
              uStack_180e = 2;
              uStack_180d = *(undefined *)(**(longlong **)(auStackX_20 + lVar22 + -0x20) + 1);
              lStack_1a38 = lVar28 + 0x254;
              lStack_1a28 = lVar28 + 0x244;
              lVar32 = -1;
              lVar27 = -1;
              do {
                lVar27 = lVar27 + 1;
              } while (asStack_240[lVar27] != 0);
              psStack_1a18 = asStack_240;
              iStack_1a10 = (int)lVar27 * 2;
              lVar27 = -1;
              do {
                lVar27 = lVar27 + 1;
              } while (asStack_210[lVar27] != 0);
              iStack_1a00 = (int)lVar27 * 2;
              psStack_1a08 = asStack_210;
              auStack_1e28[0] = 0;
              UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10581a;
              puVar24 = (uint *)(*UNRECOVERED_JUMPTABLE_00)(lVar28,auStack_1e28);
              ppuVar16 = ppuStack_1a60;
              if (puVar24 != (uint *)0x0) {
                do {
                  lVar32 = lVar32 + 1;
                } while (*(short *)((longlong)puVar24 + lVar32 * 2) != 0);
                iVar30 = (int)lVar32 * 2;
              }
              ppuStack_1a60[10] = puVar24;
              *(int *)(ppuVar16 + 0xb) = iVar30;
              *(undefined4 *)((longlong)ppuVar16 + 0x5c) = 9;
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105853;
              func_0x(auStack_1a78);
            }
          }
          else if ((uint)uStack_1f10 == (uint)uStack_1ee8) {
            uVar34 = (uint)((ulonglong)uStack_1ee8 >> 0x20);
            if ((uStack_1f10._4_4_ < uVar34) ||
               ((uStack_1f10._4_4_ == uVar34 && (uVar6 < uStack_1ee0)))) goto LAB_;
          }
LAB_:
          uVar38 = 8;
          if ((1 < *(short *)((longlong)&uStackX_c + lVar22)) &&
             (*(char *)(**(longlong **)(auStackX_20 + lVar22 + -0x20) + 1) != '\x02')) {
            if (lVar33 != 0) {
              *(longlong *)(lVar33 + 0x588) = **(longlong **)(auStackX_20 + lVar22 + -0x20);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105880;
            lVar28 = func_0x();
            if (lVar28 != 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10588a;
              lVar28 = func_0x();
              if (*(longlong *)(lVar28 + 0x30) != 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105896;
                lVar28 = func_0x();
                uVar34 = *(uint *)(*(longlong *)(lVar28 + 0x30) + 0xc);
                if ((uVar34 < 0xe) && ((0x2640U >> (uVar34 & 0x1f) & 1) != 0)) goto LAB_;
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1058b6;
            func_0x(0,uVar38 & 0xffffffff);
          }
LAB_:
          *(int *)(lVar9 + 4) = *(int *)(lVar9 + 4) + 1;
          if (*(longlong *)(lVar9 + 0x58) != 0) {
            piVar3 = (int *)(*(longlong *)(lVar9 + 0x58) + 4);
            *piVar3 = *piVar3 + 1;
          }
          if ((*(uint *)((longlong)&uStackX_c + lVar22) & 0xff000000) != 0) {
            *(int *)(lVar9 + 8) = *(int *)(lVar9 + 8) + 1;
            if (*(longlong *)(lVar9 + 0x58) != 0) {
              piVar3 = (int *)(*(longlong *)(lVar9 + 0x58) + 8);
              *piVar3 = *piVar3 + 1;
            }
            if (*(char *)((longlong)auStackX_10 + lVar22) != '\0') {
              *(int *)(lVar9 + 0xc) = *(int *)(lVar9 + 0xc) + 1;
              if (*(longlong *)(lVar9 + 0x58) != 0) {
                piVar3 = (int *)(*(longlong *)(lVar9 + 0x58) + 0xc);
                *piVar3 = *piVar3 + 1;
              }
            }
          }
          if ((int)uStack_1cac != 0) {
            uVar4 = *(undefined *)(**(longlong **)(auStackX_20 + lVar22 + -0x20) + 1);
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105928;
            func_0x(lStack_1f60,uVar4,&uStack_1cb0,0xffffffff);
          }
          plVar10 = uStack_1f28;
          puVar13 = (undefined8 *)*uStack_1f28;
          plVar26 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
          lVar28 = *plVar26;
          iVar30 = *(int *)(lVar28 + 0x18);
          if (iVar30 == *(int *)(puVar13[1] + 0x3c0)) {
            uVar6 = *(ushort *)(puVar13[1] + 0x3c4);
            if ((*(ushort *)(lVar28 + 6) != uVar6) && (1 < (uVar6 | *(ushort *)(lVar28 + 6))))
            goto LAB_;
          }
          else {
LAB_:
            uVar18 = *(undefined2 *)(lVar28 + 6);
            iVar19 = (int)*(short *)((longlong)&uStackX_c + lVar22);
            if (((*(ushort *)((longlong)plVar26 + 0x62) >> 10 & 1) == 0) || (iVar19 < 3)) {
              plVar14 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
              if (((byte)*(undefined2 *)((longlong)plVar26 + 0x62) >> 3 & 1) != 0) {
                if (iVar19 == 3) {
                  iVar19 = 4;
                }
                else if (iVar19 < 2) goto LAB_;
                if ((((*(uint *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 100) & 8) != 0) &&
                    (lVar28 = *(longlong *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 0x90),
                    lVar28 != 0)) && (*(longlong *)(lVar28 + 0x758) != 0)) {
                  uVar8 = *(undefined8 *)(auStackX_20 + lVar22 + -0x20);
                  uVar12 = *(undefined8 *)(lVar28 + 0x758);
                  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1059f8;
                  func_0x(uVar12,uVar8,iVar19);
                }
              }
LAB_:
              if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar14 + 100) & 8) != 0))
                 && ((2 < iVar19 &&
                     (((*(uint *)((longlong)plVar14 + 100) & 0xc0000000) != 0x40000000 &&
                      (lVar28 = *plVar14, lVar28 != 0)))))) {
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105a3c;
                iVar21 = (*_DAT_)(lVar28,0x2000,2,auStack_1bd8);
                if (iVar21 != 0) {
                  LOCK();
                  *(uint *)((longlong)plVar14 + 100) =
                       *(uint *)((longlong)plVar14 + 100) & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *(uint *)((longlong)plVar14 + 100) =
                       *(uint *)((longlong)plVar14 + 100) | 0x40000000;
                  UNLOCK();
                }
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105a5e;
              func_0x(plVar14 + 0x13,iVar19);
              if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105a7d;
                func_0x(plVar14,0,iVar19);
              }
              *(uint *)((longlong)&uStackX_c + lVar22) =
                   *(uint *)((longlong)&uStackX_c + lVar22) & 0xffff0000;
              *(undefined8 *)(auStackX_20 + lVar22 + -0x20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105991;
              func_0x();
            }
            uStack_1df0 = *(undefined4 *)(puVar13[1] + 0x3c0);
            uStack_1dec = *(undefined2 *)(puVar13[1] + 0x3c4);
            uStack_1dea = 0;
            uStack_1de2 = 0;
            UNRECOVERED_JUMPTABLE_00 = *(code **)*puVar13;
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105ad3;
            iStack_1de8 = iVar30;
            uStack_1de4 = uVar18;
            uVar18 = (*UNRECOVERED_JUMPTABLE_00)(puVar13);
            *(undefined4 *)(&stack0xffffffffffffffe0 + lVar22) = *(undefined4 *)(plVar10 + 2);
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105af6;
            func_0x(piVar37,&iStack_1de8,uVar18,&uStack_1df0);
            plVar26 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
          }
          lVar28 = lStack_1f18;
          if ((*(int *)(plVar26 + 0xe) == *piStack_1f50) &&
             (*(short *)((longlong)plVar26 + 0x74) == *(short *)(piStack_1f50 + 1))) {
            *(int *)(&stack0xffffffffffffffe8 + lVar22) = iStack_1f20;
            *(undefined **)(&stack0xffffffffffffffe0 + lVar22) = &stack0x00000030 + lVar22;
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105b7e;
            func_0x(lStack_1f18,auStackX_20 + lVar22 + -0x20,&plStack_1f78,
                            (longlong)&lStackX_18 + lVar22);
            lVar27 = *(longlong *)(&stack0x00000030 + lVar22);
            if ((lVar27 != 0) && (3 < *(short *)(&stack0x0000003c + lVar22))) {
              iVar30 = (int)*(short *)(&stack0x0000003c + lVar22);
              if (((*(ushort *)(lVar27 + 0x62) & 0x400) == 0) || (iVar30 < 3)) {
                lVar9 = *(longlong *)(&stack0x00000030 + lVar22);
                if (((byte)*(undefined2 *)(lVar27 + 0x62) >> 3 & 1) != 0) {
                  if (iVar30 == 3) {
                    iVar30 = 4;
                  }
                  else if (iVar30 < 2) goto LAB_;
                  if (((*(uint *)(*(longlong *)(&stack0x00000030 + lVar22) + 100) & 8) != 0) &&
                     (*(longlong *)(*(longlong *)(&stack0x00000030 + lVar22) + 0x90) != 0)) {
                    uVar8 = *(undefined8 *)(*(longlong *)(&stack0x00000030 + lVar22) + 0x90);
                    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105c0f;
                    func_0x(uVar8,*(undefined8 *)(&stack0x00000030 + lVar22),iVar30);
                  }
                }
LAB_:
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105c20;
                iVar19 = func_0x(0x20bc0f0,0x32f);
                if (((iVar19 != 0) && ((*(uint *)(lVar9 + 100) & 8) != 0)) && (2 < iVar30)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105c3d;
                  func_0x(lVar9,1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105c4b;
                func_0x(lVar9 + 0x98,iVar30);
                if (_DAT_ != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105c65;
                  iVar19 = func_0x(0x20bc0f0,0xe79);
                  if (iVar19 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105c76;
                    func_0x(lVar9,0,iVar30);
                  }
                }
                *(uint *)(&stack0x0000003c + lVar22) =
                     *(uint *)(&stack0x0000003c + lVar22) & 0xffff0000;
                *(undefined8 *)(&stack0x00000030 + lVar22) = 0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105bb6;
                func_0x(&stack0x00000030 + lVar22);
              }
            }
            lVar27 = *(longlong *)((longlong)&lStackX_18 + lVar22);
            if ((lVar27 != 0) && (3 < *(short *)((longlong)&uStackX_24 + lVar22))) {
              iVar30 = (int)*(short *)((longlong)&uStackX_24 + lVar22);
              if (((*(ushort *)(lVar27 + 0x62) & 0x400) == 0) || (iVar30 < 3)) {
                lVar9 = *(longlong *)((longlong)&lStackX_18 + lVar22);
                if (((byte)*(undefined2 *)(lVar27 + 0x62) >> 3 & 1) != 0) {
                  if (iVar30 == 3) {
                    iVar30 = 4;
                  }
                  else if (iVar30 < 2) goto LAB_;
                  if (((*(uint *)(*(longlong *)((longlong)&lStackX_18 + lVar22) + 100) & 8) != 0) &&
                     (*(longlong *)(*(longlong *)((longlong)&lStackX_18 + lVar22) + 0x90) != 0)) {
                    uVar8 = *(undefined8 *)(*(longlong *)((longlong)&lStackX_18 + lVar22) + 0x90);
                    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105d14;
                    func_0x(uVar8,*(undefined8 *)((longlong)&lStackX_18 + lVar22),iVar30);
                  }
                }
LAB_:
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105d25;
                iVar19 = func_0x(0x20bc0f0,0x32f);
                if (((iVar19 != 0) && ((*(uint *)(lVar9 + 100) & 8) != 0)) && (2 < iVar30)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105d42;
                  func_0x(lVar9,1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105d50;
                func_0x(lVar9 + 0x98,iVar30);
                if (_DAT_ != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105d6a;
                  iVar19 = func_0x(0x20bc0f0,0xe79);
                  if (iVar19 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105d7b;
                    func_0x(lVar9,0,iVar30);
                  }
                }
                *(uint *)((longlong)&uStackX_24 + lVar22) =
                     *(uint *)((longlong)&uStackX_24 + lVar22) & 0xffff0000;
                *(undefined8 *)((longlong)&lStackX_18 + lVar22) = 0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105cbb;
                func_0x((longlong)&lStackX_18 + lVar22);
              }
            }
            plVar26 = plStack_1f78;
            if ((plStack_1f78 == (longlong *)0x0) || ((short)uStack_1f6c < 4)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105e8e;
              func_0x(lVar28 + 0x38);
              *(undefined4 *)(lVar28 + 0x4c) = 0;
              *(undefined2 *)(lVar28 + 0x50) = 0;
            }
            else {
              iVar30 = (int)(short)uStack_1f6c;
              if (((*(ushort *)((longlong)plStack_1f78 + 0x62) & 0x400) == 0) || (iVar30 < 3)) {
                if (((byte)*(undefined2 *)((longlong)plStack_1f78 + 0x62) >> 3 & 1) != 0) {
                  if (iVar30 == 3) {
                    iVar30 = 4;
                  }
                  else if (iVar30 < 2) goto LAB_;
                  if (((*(uint *)((longlong)plStack_1f78 + 100) & 8) != 0) &&
                     (plStack_1f78[0x12] != 0)) {
                    lVar28 = plStack_1f78[0x12];
                    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105e11;
                    func_0x(lVar28,plStack_1f78,iVar30);
                  }
                }
LAB_:
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105e22;
                iVar19 = func_0x(0x20bc0f0,0x32f);
                if (((iVar19 != 0) && ((*(uint *)((longlong)plVar26 + 100) & 8) != 0)) &&
                   (2 < iVar30)) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105e3f;
                  func_0x(plVar26,1);
                }
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105e4d;
                func_0x(plVar26 + 0x13,iVar30);
                if (_DAT_ != 0) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105e67;
                  iVar19 = func_0x(0x20bc0f0,0xe79);
                  if (iVar19 != 0) {
                    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105e78;
                    func_0x(plVar26,0,iVar30);
                  }
                }
                uStack_1f6c = uStack_1f6c & 0xffff0000;
                plStack_1f78 = (longlong *)0x0;
              }
              else {
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105dbc;
                func_0x(&plStack_1f78);
              }
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105ea3;
            iVar30 = func_0x(pplStack_1b98);
            if (iVar30 == 0) {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar22) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105ecd;
              (*_DAT_)(1,0x1b4d500,0x1b23d68,0xbf9);
            }
            goto LAB_;
          }
          if (plVar26 != (longlong *)0x0) {
            iVar30 = (int)*(short *)((longlong)&uStackX_c + lVar22);
            if (((*(ushort *)((longlong)plVar26 + 0x62) >> 10 & 1) == 0) || (iVar30 < 3)) {
              plVar10 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
              if (((byte)*(undefined2 *)((longlong)plVar26 + 0x62) >> 3 & 1) != 0) {
                if (iVar30 == 3) {
                  iVar30 = 4;
                }
                else if (iVar30 < 2) goto LAB_;
                if ((((*(uint *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 100) & 8) != 0) &&
                    (lVar28 = *(longlong *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 0x90),
                    lVar28 != 0)) && (*(longlong *)(lVar28 + 0x758) != 0)) {
                  uVar8 = *(undefined8 *)(auStackX_20 + lVar22 + -0x20);
                  uVar12 = *(undefined8 *)(lVar28 + 0x758);
                  *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105f32;
                  func_0x(uVar12,uVar8,iVar30);
                }
              }
LAB_:
              if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar10 + 100) & 8) != 0))
                  && (2 < iVar30)) &&
                 (((*(uint *)((longlong)plVar10 + 100) & 0xc0000000) != 0x40000000 &&
                  (lVar28 = *plVar10, lVar28 != 0)))) {
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105f76;
                iVar19 = (*_DAT_)(lVar28,0x2000,2,auStack_1bf0);
                if (iVar19 != 0) {
                  LOCK();
                  *(uint *)((longlong)plVar10 + 100) =
                       *(uint *)((longlong)plVar10 + 100) & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *(uint *)((longlong)plVar10 + 100) =
                       *(uint *)((longlong)plVar10 + 100) | 0x40000000;
                  UNLOCK();
                }
              }
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105f98;
              func_0x(plVar10 + 0x13,iVar30);
              if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
                *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105fb7;
                func_0x(plVar10,0,iVar30);
              }
              *(uint *)((longlong)&uStackX_c + lVar22) =
                   *(uint *)((longlong)&uStackX_c + lVar22) & 0xffff0000;
              *(undefined8 *)(auStackX_20 + lVar22 + -0x20) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105b45;
              func_0x(auStackX_20 + lVar22 + -0x20);
            }
          }
          lVar28 = lStack_1f18;
          if (*(int *)(lStack_1f18 + 0x40) != 0) {
            uVar7 = *(undefined4 *)(lStack_1f18 + 0x44);
            uVar8 = *(undefined8 *)(lStack_1f18 + 0x38);
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105fda;
            func_0x(uVar8,uVar7);
            *(undefined4 *)(lVar28 + 0x40) = 0;
          }
          goto LAB_;
        }
      }
      if (*(longlong *)
           (*(longlong *)
             ((ulonglong)*_DAT_ +
              *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
             8) + 0x60) == *(longlong *)(lVar32 + 0x2120)) goto LAB_;
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10530c;
      cVar17 = func_0x(lVar32);
      if (cVar17 != '\0') goto LAB_;
      if (lVar33 == 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10531e;
        uStack_1f40 = func_0x();
      }
      plVar26 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
      lVar29 = *plVar26;
      if (*(short *)(lVar29 + 0x24) == 0) {
LAB_:
        uStack_1dd8 = *(undefined8 *)(lVar29 + 0x28);
        uStack_1dd0 = *(undefined2 *)(lVar29 + 0x30);
      }
      else {
        cVar17 = *(char *)(lVar29 + 1);
        if (cVar17 == '\v') {
          if (*(int *)(lVar29 + 0x18) != 99) {
LAB_:
            if (cVar17 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar17 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar29 + 0x18) != 99) goto LAB_;
        }
        uStack_1db0 = *(undefined4 *)(lVar29 + 0x20);
        uStack_1dac = *(undefined2 *)(lVar29 + 0x24);
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105378;
        cVar17 = func_0x(&uStack_1db0);
        if (cVar17 == '\0') {
          plVar26 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
          goto LAB_;
        }
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10538b;
        func_0x(lVar29,&uStack_1dd8);
        plVar26 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
      }
      uVar18 = uStack_1dd0;
      uVar8 = uStack_1dd8;
      if (plVar26 != (longlong *)0x0) {
        iVar30 = (int)*(short *)((longlong)&uStackX_c + lVar22);
        if (((*(ushort *)((longlong)plVar26 + 0x62) & 0x400) == 0) || (iVar30 < 3)) {
          plVar10 = *(longlong **)(auStackX_20 + lVar22 + -0x20);
          if (((byte)*(undefined2 *)((longlong)plVar26 + 0x62) >> 3 & 1) != 0) {
            if (iVar30 == 3) {
              iVar30 = 4;
            }
            else if (iVar30 < 2) goto LAB_;
            if ((((*(uint *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 100) & 8) != 0) &&
                (lVar29 = *(longlong *)(*(longlong *)(auStackX_20 + lVar22 + -0x20) + 0x90),
                lVar29 != 0)) && (*(longlong *)(lVar29 + 0x758) != 0)) {
              uVar12 = *(undefined8 *)(auStackX_20 + lVar22 + -0x20);
              uVar11 = *(undefined8 *)(lVar29 + 0x758);
              *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105455;
              func_0x(uVar11,uVar12,iVar30);
            }
          }
LAB_:
          if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar10 + 100) & 8) != 0)) &&
             ((2 < iVar30 &&
              (((*(uint *)((longlong)plVar10 + 100) & 0xc0000000) != 0x40000000 &&
               (lVar29 = *plVar10, lVar29 != 0)))))) {
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x105499;
            iVar19 = (*_DAT_)(lVar29,0x2000,2,auStack_1bdc);
            if (iVar19 != 0) {
              LOCK();
              *(uint *)((longlong)plVar10 + 100) = *(uint *)((longlong)plVar10 + 100) & 0x3fffffff;
              UNLOCK();
              LOCK();
              *(uint *)((longlong)plVar10 + 100) = *(uint *)((longlong)plVar10 + 100) | 0x40000000;
              UNLOCK();
            }
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1054bb;
          func_0x(plVar10 + 0x13,iVar30);
          if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
            *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1054da;
            func_0x(plVar10,0,iVar30);
          }
          *(uint *)((longlong)&uStackX_c + lVar22) =
               *(uint *)((longlong)&uStackX_c + lVar22) & 0xffff0000;
          *(undefined8 *)(auStackX_20 + lVar22 + -0x20) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1053f0;
          func_0x(auStackX_20 + lVar22 + -0x20);
        }
      }
      *(undefined8 *)(&stack0xffffffffffffffe0 + lVar22) = 0;
      uVar12 = *(undefined8 *)(lVar32 + 0x728);
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10551f;
      uStack_1c18 = uVar8;
      uStack_1c10 = uVar18;
      func_0x(uVar12,&uStack_1c18,4);
    } while( true );
  }
  sStack_d58 = -1;
  pbStack_d50 = (byte *)0x0;
  uStack_d54 = 0;
  uStack_d3a = 0;
  uStack_d30 = 0;
  uStack_d2e = 0;
  ppbStack_d48 = (byte **)0x0;
  lStack_1f60 = *(undefined8 *)(**(longlong **)(param_1 + 8) + 8);
  if (plStack_1f78 != (longlong *)0x0) {
    iVar30 = (int)(short)uStack_1f6c;
    if (((*(ushort *)((longlong)plStack_1f78 + 0x62) >> 10 & 1) == 0) || (iVar30 < 3)) {
      if (((byte)*(undefined2 *)((longlong)plStack_1f78 + 0x62) >> 3 & 1) != 0) {
        if (iVar30 == 3) {
          iVar30 = 4;
        }
        else if (iVar30 < 2) goto LAB_;
        if ((((*(uint *)((longlong)plStack_1f78 + 100) & 8) != 0) &&
            (lVar28 = plStack_1f78[0x12], lVar28 != 0)) && (*(longlong *)(lVar28 + 0x758) != 0)) {
          uVar8 = *(undefined8 *)(lVar28 + 0x758);
          *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10020b;
          func_0x(uVar8,plStack_1f78,iVar30);
        }
      }
LAB_:
      if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar26 + 100) & 8) != 0)) &&
         ((2 < iVar30 &&
          (((*(uint *)((longlong)plVar26 + 100) & 0xc0000000) != 0x40000000 &&
           (lVar28 = *plVar26, lVar28 != 0)))))) {
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10024c;
        iVar19 = (*_DAT_)(lVar28,0x2000,2,auStack_1bd4);
        if (iVar19 != 0) {
          LOCK();
          *(uint *)((longlong)plVar26 + 100) = *(uint *)((longlong)plVar26 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar26 + 100) = *(uint *)((longlong)plVar26 + 100) | 0x40000000;
          UNLOCK();
        }
      }
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10026e;
      func_0x(plVar26 + 0x13,iVar30);
      if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x10028d;
        func_0x(plVar26,0,iVar30);
      }
      uStack_1f6c = uStack_1f6c & 0xffff0000;
    }
    else {
      *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1001a8;
      func_0x(&plStack_1f78);
    }
  }
  pbVar36 = (byte *)0x0;
  plStack_1f78 = *pplVar1;
  uStack_1f6c = uStack_1f6c & 0xffff0000 | (uint)*(ushort *)(param_1 + 0x24);
  *pplVar1 = (longlong *)0x0;
  *(undefined2 *)(param_1 + 0x24) = 0;
  iStack_1f20 = *(int *)(param_1 + 0x30);
  *(undefined4 *)(param_1 + 0x30) = 0xffffffff;
  lVar28 = *plStack_1f78;
  iStack_d24 = iStack_1f20;
  if (-1 < *(char *)(lVar28 + 2)) goto LAB_;
  pbVar2 = (byte *)(lVar28 + 0x60);
  if ((sStack_d58 == 0) || (ppbVar31 = ppbStack_d48, ppbStack_d48 == (byte **)0x0)) {
    uStack_cf8 = 0;
    uStack_cea = 0;
    auStack_cd0 = ZEXT816(0);
    auStack_d20 = ZEXT816(0);
    stack0xfffffffffffff2f2 = SUB1614(ZEXT816(0),2);
    auStack_d10._0_2_ = 0xffff;
    uStack_d08 = 0;
    uStack_cf2 = 0;
    uStack_cf0 = 0;
    uStack_ce8 = 0;
    uStack_d00 = 0;
    auStack_ce0 = ZEXT816(0);
    auStack_cc0._0_12_ = ZEXT812(0);
    auStack_cc0._12_4_ = 0;
    uStack_cb0 = 0;
    ppbVar31 = (byte **)auStack_d20;
  }
  if (*(short *)(lVar28 + 0x24) == 0) {
LAB_:
    uStack_1eb8 = *(undefined8 *)(lVar28 + 0x28);
    uStack_1eb0 = *(undefined2 *)(lVar28 + 0x30);
  }
  else {
    cVar17 = *(char *)(lVar28 + 1);
    if (cVar17 == '\v') {
      if (*(int *)(lVar28 + 0x18) != 99) {
LAB_:
        if (cVar17 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar17 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar28 + 0x18) != 99) goto LAB_;
    }
    uStack_1dc8 = *(undefined4 *)(lVar28 + 0x20);
    uStack_1dc4 = *(undefined2 *)(lVar28 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x1003f5;
    cVar17 = func_0x(&uStack_1dc8);
    if (cVar17 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100405;
    func_0x(lVar28,&uStack_1eb8);
  }
  *ppbVar31 = pbVar2;
  *(undefined4 *)(ppbVar31 + 0xc) = (undefined4)uStack_1eb8;
  *(int *)((longlong)ppbVar31 + 100) = (int)((ulonglong)uStack_1eb8 >> 0x20);
  *(undefined2 *)(ppbVar31 + 0xd) = uStack_1eb0;
  *(undefined4 *)((longlong)ppbVar31 + 0x6c) = *(undefined4 *)(lVar28 + 0x20);
  *(undefined2 *)(ppbVar31 + 0xe) = *(undefined2 *)(lVar28 + 0x24);
  uVar18 = SUB82(pbVar36,0);
  *(undefined2 *)((longlong)ppbVar31 + 0x72) = uVar18;
  uVar7 = *(undefined4 *)((ulonglong)*pbVar2 * 6 + 0x1799300);
  uStack_1f40 = CONCAT44(uStack_1f40._4_4_,uVar7);
  lVar27 = uStack_1f40;
  uVar38 = (ulonglong)*(short *)((ulonglong)*pbVar2 * 6 + 0x1799304);
  *(undefined2 *)(ppbVar31 + 2) = 0xffff;
  ppbVar31[3] = pbVar36;
  uVar35 = SUB84(pbVar36,0);
  *(undefined4 *)((longlong)ppbVar31 + 0x14) = uVar35;
  *(byte **)((longlong)ppbVar31 + 0x2e) = pbVar36;
  ppbVar31[7] = pbVar36;
  ppbVar31[4] = pbVar36;
  ppbVar31[9] = pbVar36;
  ppbVar31[10] = pbVar36;
  *(undefined2 *)(ppbVar31 + 0xb) = uVar18;
  if ((**ppbVar31 & 2) != 0) {
    pbVar2 = pbVar2 + uVar38;
    if ((*pbVar2 & 1) == 0) {
      *(undefined2 *)(ppbVar31 + 2) = uVar18;
      ppbVar31[3] = pbVar2;
      *(undefined4 *)((longlong)ppbVar31 + 0x14) = uVar35;
      *(undefined4 *)((longlong)ppbVar31 + 0x36) = uVar35;
                    /* WARNING: Could not emulate address calculation at 0x00100684 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x106094) - 0xdffb10))();
      return;
    }
    *(undefined2 *)(ppbVar31 + 2) = 1;
    ppbVar31[3] = pbVar2;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x106074) * 4 +
                           0x106064) - 0xdffb10);
                    /* WARNING: Could not emulate address calculation at 0x001004cc */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar31 & 4) != 0) {
    uStack_1f40._2_2_ = (short)((uint)uVar7 >> 0x10);
    if (uStack_1f40._2_2_ != 0) {
      uVar38 = (ulonglong)*(ushort *)(lVar28 + 0x61 + (longlong)uStack_1f40._2_2_ * 2);
    }
    psVar23 = (short *)(pbVar2 + uVar38);
    ppbVar31[9] = (byte *)psVar23;
    sVar5 = *psVar23;
    ppbVar31[10] = (byte *)(psVar23 + 1);
    *(short *)(ppbVar31 + 0xb) = (sVar5 + 1) * 2;
  }
  pbVar2 = ppbVar31[1];
  uStack_1f40 = lVar27;
  if (pbVar2 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar22) = 0x100738;
    func_0x(pbVar2,ppbVar31);
    pbVar36 = (byte *)0x0;
  }
LAB_:
  pbStack_d50 = (byte *)((ulonglong)*(ushort *)(lVar28 + (0xfff - (longlong)iStack_1f20) * 2) +
                        lVar28);
  if ((*pbStack_d50 & 1) == 0) {
    sStack_d58 = (short)pbVar36;
    uStack_d54 = SUB84(pbVar36,0);
    uStack_d30 = (undefined2)((ulonglong)pbVar36 >> 0x10);
    uStack_d32 = sStack_d58;
                    /* WARNING: Could not emulate address calculation at 0x0010097d */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_d50 & 0xe) * 4 + 0x106100) - 0xdffb10))
              ();
    return;
  }
  sStack_d58 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_d50 & 0x1c) + 0x1060e0) * 4
                         + 0x1060d0) - 0xdffb10);
                    /* WARNING: Could not emulate address calculation at 0x00100790 */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

