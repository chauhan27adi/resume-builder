
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined4 *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  longlong lVar8;
  ulonglong uVar9;
  longlong unaff_GS_OFFSET;
  undefined auStack_2e8 [32];
  undefined8 uStack_2c8;
  undefined8 uStack_2c0;
  undefined8 uStack_2b8;
  undefined8 uStack_2b0;
  ulonglong uStack_2a8;
  int aiStack_298 [2];
  longlong lStack_290;
  undefined8 uStack_288;
  undefined4 uStack_280;
  undefined auStack_278 [16];
  undefined8 uStack_268;
  undefined2 uStack_260;
  undefined8 uStack_258;
  longlong lStack_248;
  undefined2 uStack_240;
  undefined8 uStack_238;
  int iStack_230;
  undefined auStack_228 [16];
  undefined auStack_218 [16];
  undefined auStack_208 [16];
  undefined auStack_1f8 [16];
  longlong lStack_1e8;
  uint uStack_1e0;
  undefined8 uStack_1d8;
  undefined8 uStack_1d0;
  undefined2 auStack_1c8 [2];
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined auStack_b8 [144];
  ulonglong uStack_28;
  ulonglong uVar7;
  
  uStack_258 = 0xfffffffffffffffe;
  uStack_28 = _DAT_ ^ (ulonglong)auStack_2e8;
  uVar7 = 0;
  uStack_288 = 0;
  uStack_280 = 1;
  auStack_278._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_278._8_8_ = 0;
  cVar1 = (**(code **)(*(longlong *)auStack_278._0_8_ + 0x1d0))();
  if (cVar1 == '\0') {
    uStack_2a8 = uStack_2a8 & 0xffffffff00000000;
    uStack_2b0 = 0;
    uStack_2b8 = (undefined8 *)((ulonglong)uStack_2b8 & 0xffffffffffffff00);
    uStack_2c0 = CONCAT44(uStack_2c0._4_4_,2);
    uStack_2c8 = CONCAT44(uStack_2c8._4_4_,1);
    (**(code **)(*(longlong *)auStack_278._0_8_ + 8))(auStack_278._0_8_,0x1aea748,0x2a);
    uStack_288 = CONCAT44(uStack_288._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_278._0_8_ + 0xe8))
              (auStack_278._0_8_,1,1,(longlong)&uStack_288 + 4);
    uStack_280 = 1;
    uStack_288 = CONCAT44(uStack_288._4_4_,4);
  }
  iVar2 = func_0x(*(undefined2 *)((longlong)param_1 + 0x106),0x1aea6b0);
  if (iVar2 == 0) {
    uStack_2a8 = 0x1aea6b0;
    uStack_2b0 = CONCAT44(uStack_2b0._4_4_,1);
    uStack_2b8 = (undefined8 *)CONCAT44(uStack_2b8._4_4_,0x10);
    uStack_2c0 = CONCAT44(uStack_2c0._4_4_,0x58c3);
    uStack_2c8 = 0;
    func_0x(1,param_1,0,0);
  }
  else {
    uStack_238 = (**(code **)(*(longlong *)auStack_278._0_8_ + 0x1b0))();
    uStack_240 = *(undefined2 *)((longlong)param_1 + 0x106);
    lStack_248 = 0;
    auStack_228 = ZEXT816(0);
    auStack_218 = ZEXT816(0);
    auStack_208 = ZEXT816(0);
    auStack_1f8 = ZEXT816(0);
    lStack_1e8 = 0;
    uStack_1e0 = 0;
    uStack_1d8 = 0;
    uStack_1d0 = 0;
    lStack_290 = 0;
    aiStack_298[0] = 0;
    iStack_230 = iVar2;
    iVar2 = func_0x(&lStack_248,3,1);
    if (iVar2 == 0) {
      uStack_2a8 = 0x1aea6b0;
      uStack_2b0 = CONCAT44(uStack_2b0._4_4_,0xb);
      uStack_2b8 = (undefined8 *)CONCAT44(uStack_2b8._4_4_,0x10);
      uStack_2c0 = CONCAT44(uStack_2c0._4_4_,0x49aa);
      uStack_2c8 = 0;
      func_0x(1,param_1,0);
    }
    else {
      uStack_2c0 = lStack_248;
      uStack_2c8 = uStack_1d8;
      iVar2 = (**(code **)(*(longlong *)auStack_228._8_8_ + 0x18))(auStack_228._8_8_,0,1,0);
      if (iVar2 == 0) {
        auStack_1c8[0] = 0;
        uStack_1c4 = _DAT_;
        uStack_1c0 = uRam0000000001880c04;
        uStack_1bc = uRam0000000001880c08;
        uStack_1b8 = uRam0000000001880c0c;
        uStack_1b4 = *param_1;
        uStack_1b0 = param_1[1];
        uStack_1ac = param_1[2];
        uStack_1a8 = param_1[3];
        uStack_1a4 = _DAT_;
        uStack_1a0 = uRam0000000001880c04;
        uStack_19c = uRam0000000001880c08;
        uStack_198 = uRam0000000001880c0c;
        func_0x(auStack_1c8,0);
        (*_DAT_)(auStack_b8,0x41,0x1ae9230);
        func_0x(auStack_1c8,param_1);
        puVar4 = (undefined4 *)func_0x(&lStack_248,0x1aea6f0,&lStack_290,aiStack_298);
        if (puVar4 == (undefined4 *)0x0) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1ca5e10,0x1c7fe40,0x256);
        }
        if (lStack_290 != 4) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1ca5df0,0x1c7fe40,0x259);
        }
        if (aiStack_298[0] == 3) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1ca5e20,0x1c7fe40,0x25b);
        }
        param_1[0x53] = *puVar4;
        piVar5 = (int *)func_0x(&lStack_248,0x1aea5a8,&lStack_290,aiStack_298);
        if (piVar5 == (int *)0x0) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1ca5e10,0x1c7fe40,0x256);
        }
        if (lStack_290 != 4) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1ca5df0,0x1c7fe40,0x259);
        }
        if (aiStack_298[0] == 3) {
          uStack_2c8 = 0;
          (*_DAT_)(1,0x1ca5e20,0x1c7fe40,0x25b);
        }
        iVar2 = *piVar5;
        param_1[0x54] = iVar2;
        if (iVar2 < 5) {
          param_1[0x54] = 5;
          func_0x(auStack_1c8,0x1aea5d0);
        }
        aiStack_298[0] = 0;
        if (((lStack_248 != 0) && (lStack_1e8 != 0)) && (uStack_1e0 != 0)) {
          uVar3 = func_0x(&lStack_248,0x1aea580,aiStack_298);
          uVar9 = uVar7;
          if (((lStack_1e8 != 0) && (uVar3 - 1 < 0xfffffffe)) && (uStack_1e0 != 0)) {
            do {
              if (*(ulonglong *)(uVar7 * 0x58 + lStack_1e8) == (ulonglong)uVar3) {
                uVar9 = uVar7 * 0x58 + lStack_1e8;
                if (uVar9 != 0) goto LAB_;
                break;
              }
              uVar6 = (int)uVar7 + 1;
              uVar7 = (ulonglong)uVar6;
              uVar9 = 0;
            } while (uVar6 < uStack_1e0);
          }
          uStack_2c8 = CONCAT44(uStack_2c8._4_4_,iStack_230);
          (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
          lVar8 = *(longlong *)(uVar9 + 8) + lStack_248;
          if (((lVar8 != 0) && (*(longlong *)(lStack_248 + *(longlong *)(uVar9 + 0x10)) == 10)) &&
             (*(int *)(lStack_248 + *(longlong *)(uVar9 + 0x18)) != 3)) {
            puVar4 = param_1 + 0x4f;
            func_0x(puVar4,lVar8,10);
            *puVar4 = CONCAT31(CONCAT21(CONCAT11(*(undefined *)puVar4,
                                                 *(undefined *)((longlong)param_1 + 0x13d)),
                                        *(undefined *)((longlong)param_1 + 0x13e)),
                               *(undefined *)((longlong)param_1 + 0x13f));
            param_1[0x50] =
                 CONCAT31(CONCAT21(CONCAT11(*(undefined *)(param_1 + 0x50),
                                            *(undefined *)((longlong)param_1 + 0x141)),
                                   *(undefined *)((longlong)param_1 + 0x142)),
                          *(undefined *)((longlong)param_1 + 0x143));
            *(ushort *)(param_1 + 0x51) =
                 CONCAT11(*(undefined *)(param_1 + 0x51),*(undefined *)((longlong)param_1 + 0x145));
          }
        }
        uStack_268 = *(undefined8 *)(param_1 + 0x4f);
        uStack_260 = *(undefined2 *)(param_1 + 0x51);
        uStack_2b8 = &uStack_268;
        uStack_2c0 = 0x1aea590;
        uStack_2c8 = CONCAT44(uStack_2c8._4_4_,param_1[0x54]);
        func_0x(auStack_1c8,0x1aea530,param_1[0x53],0x1aea508);
      }
    }
    func_0x(&lStack_248);
  }
  func_0x(&uStack_288,0);
  if ((int)uStack_288 != 0) {
    func_0x(&uStack_288,0);
  }
  func_0x(uStack_28 ^ (ulonglong)auStack_2e8);
  return;
}

