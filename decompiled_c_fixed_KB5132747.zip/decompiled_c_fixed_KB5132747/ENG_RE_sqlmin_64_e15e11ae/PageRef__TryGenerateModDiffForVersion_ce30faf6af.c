
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,longlong param_3,undefined8 param_4,
                 short *param_5,short *param_6)

{
  byte *pbVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  ushort uVar5;
  longlong lVar6;
  ulonglong *puVar7;
  uint uVar8;
  byte bVar9;
  uint uVar10;
  uint uVar11;
  ulonglong uVar12;
  uint uVar13;
  int iVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ushort *puVar17;
  int iVar18;
  ushort *puVar19;
  ushort *puVar20;
  uint uStack_348;
  undefined uStack_344;
  int iStack_340;
  int iStack_33c;
  int iStack_338;
  ulonglong uStack_330;
  uint uStack_328;
  ushort uStack_324;
  short *psStack_320;
  undefined uStack_318;
  uint uStack_314;
  short *psStack_310;
  int iStack_308;
  int iStack_304;
  int iStack_300;
  int iStack_2fc;
  int iStack_2f8;
  uint uStack_2e8;
  ushort uStack_2e4;
  undefined auStack_2d8 [8];
  undefined auStack_2d0 [16];
  uint uStack_2c0;
  ushort uStack_2bc;
  uint uStack_2b0;
  undefined8 uStack_2a8;
  undefined8 uStack_2a0;
  undefined8 uStack_298;
  longlong lStack_290;
  undefined8 uStack_288;
  undefined8 uStack_280;
  ulonglong uStack_278;
  ulonglong uStack_270;
  undefined auStack_240 [40];
  undefined8 uStack_218;
  undefined4 uStack_210;
  undefined2 uStack_20c;
  undefined8 uStack_138;
  undefined4 uStack_130;
  undefined2 uStack_12c;
  ulonglong uStack_58;
  
  uStack_280 = 0xfffffffffffffffe;
  uStack_58 = _DAT_ ^ (ulonglong)&uStack_348;
  psStack_320 = param_5;
  psStack_310 = param_6;
  uStack_218 = 0;
  uStack_210 = 0;
  uStack_20c = 0;
  uStack_330 = 0;
  uStack_138 = 0;
  uStack_130 = 0;
  uStack_12c = 0;
  if (*param_6 == 0) {
    bVar9 = **(byte **)(param_6 + 4) >> 6;
  }
  else {
    bVar9 = **(byte **)(param_6 + 4) >> 1;
  }
  uStack_344 = 0;
  uStack_314 = bVar9 & 1;
  uStack_2a8 = param_4;
  uStack_2a0 = param_1;
  uStack_298 = param_2;
  lStack_290 = param_3;
  uStack_288 = param_1;
  func_0x(auStack_240,0,0,0,_DAT_,0);
  func_0x(auStack_2d0,1);
  if (*param_5 == 0) {
    bVar2 = **(byte **)(param_5 + 4) >> 6;
  }
  else {
    bVar2 = **(byte **)(param_5 + 4) >> 1;
  }
  if ((bVar2 & 1) != 0) {
    if (*param_5 == 0) {
      func_0x();
    }
    else {
      func_0x(param_5 + 1,&uStack_328);
    }
    uVar5 = uStack_324;
    uVar10 = uStack_328;
    uStack_2c0 = uStack_328;
    uStack_2bc = uStack_324;
    uStack_328 = 0;
    uStack_324 = 0;
    func_0x(param_3 + 0x19c8,&uStack_328);
    uStack_330 = uStack_330 & 0xffff000000000000;
    if ((uVar5 != 0) || (uVar10 != 0)) {
      uStack_2e8 = uVar10;
      uStack_2e4 = uVar5;
      if (*param_5 == 0) {
        func_0x();
      }
      else {
        func_0x(param_5 + 1,auStack_2d8);
      }
      cVar3 = func_0x(*(undefined8 *)(param_3 + 0x6b0),&uStack_2e8,auStack_2d8);
      if ((cVar3 != '\0') ||
         ((uStack_324 <= uVar5 && ((uStack_324 != uVar5 || (uStack_328 <= uVar10))))))
      goto LAB_;
    }
    uStack_344 = 1;
    uStack_318 = 1;
    if (*param_5 == 0) {
      func_0x();
    }
    else {
      func_0x(param_5 + 1,&uStack_330);
    }
    if (*param_5 == 0) {
      func_0x();
    }
    else {
      func_0x(param_5 + 1,&uStack_138);
    }
  }
LAB_:
  iVar18 = 0;
  if ((char)(bVar9 & 1) != '\0') {
    if (*param_6 == 0) {
      func_0x();
    }
    else {
      func_0x(param_6 + 1,&uStack_218);
    }
  }
  puVar17 = (ushort *)(param_5 + 1);
  if (*param_5 == 0) {
    if (*(int *)(param_5 + 2) == 0) {
      iStack_340 = 0;
      *puVar17 = 0;
      uVar10 = *(uint *)(param_5 + 8);
      uVar15 = (ulonglong)uVar10;
      *(uint *)(param_5 + 10) = uVar10;
      pbVar1 = *(byte **)(param_5 + 4);
      bVar9 = *pbVar1;
      if ((bVar9 & 0x10) != 0) {
        uVar10 = uVar10 + 2 + (*(ushort *)(pbVar1 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar10;
        *(uint *)(param_5 + 10) = uVar10;
        bVar9 = *pbVar1;
      }
      if ((bVar9 & 0x20) == 0) {
        *(int *)(param_5 + 2) = (int)uVar15;
        param_5[0xe] = 0;
        *(uint *)(param_5 + 0xc) = uVar10;
      }
      else {
        puVar19 = (ushort *)(pbVar1 + uVar15);
        uVar5 = *puVar19;
        param_5[0xe] = uVar5;
        if (uVar5 == 0) {
          iVar18 = 1;
          iStack_340 = 1;
          cVar3 = func_0x(0x1a33640);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x1a33640);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x132304c,0x1443138,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_5 + 4),3);
          uVar5 = param_5[0xe];
          uVar10 = *(uint *)(param_5 + 10);
        }
        uVar10 = uVar10 + (uVar5 + 1) * 2;
        *(uint *)(param_5 + 0xc) = uVar10;
        if (0x1f9e < uVar10) {
          iVar18 = iVar18 + 1;
          iStack_340 = iVar18;
          cVar3 = func_0x(0x1a33640);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x1a33640);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x132304c,0x1443138,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_5 + 4),4);
          uVar5 = param_5[0xe];
          uVar10 = *(uint *)(param_5 + 0xc);
        }
        uVar5 = puVar19[uVar5];
        *(uint *)(param_5 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar10) {
          iVar18 = iVar18 + 1;
          iStack_340 = iVar18;
          cVar3 = func_0x(0x1a33640);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x1a33640);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x132304c,0x1443138,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_5 + 4),4);
          uVar10 = *(uint *)(param_5 + 0xc);
        }
        iStack_308 = 0;
        while (iVar14 = iStack_308, uVar5 = param_5[0xe], iStack_308 < (int)(uint)uVar5) {
          uVar13 = puVar19[(longlong)iStack_308 + 1] & 0x7fff;
          if ((uVar13 < uVar10) || (*(uint *)(param_5 + 2) < uVar13)) {
            iVar18 = iVar18 + 1;
            iStack_340 = iVar18;
            cVar3 = func_0x(0x1a33640);
            if ((cVar3 != '\0') &&
               ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0')
                ))) {
              cVar3 = func_0x(0x1a33640);
              if (cVar3 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x132304c,0x1443138,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_5 + 4),4);
          }
          uVar10 = uVar13;
          iStack_308 = iVar14 + 1;
        }
        do {
          if (-1 < (short)puVar19[(ulonglong)(uVar5 - 1) + 1]) break;
          lVar6 = (ulonglong)*(uint *)(param_5 + 10) + *(longlong *)(param_5 + 4);
          uVar10 = *(ushort *)(lVar6 + (ulonglong)uVar5 * 2) & 0x7fff;
          if (uVar5 == 1) {
            uVar13 = *(uint *)(param_5 + 0xc);
            uVar15 = (ulonglong)uVar13;
LAB_:
            if ((uVar10 < (uint)uVar15) || (*(uint *)(param_5 + 2) < uVar10)) goto LAB_;
          }
          else {
            uVar11 = *(ushort *)(lVar6 + -2 + (ulonglong)uVar5 * 2) & 0x7fff;
            uVar15 = (ulonglong)uVar11;
            uVar13 = *(uint *)(param_5 + 0xc);
            if (uVar13 <= uVar11) goto LAB_;
LAB_:
            func_0x(*(longlong *)(param_5 + 4),7);
            uVar13 = *(uint *)(param_5 + 0xc);
          }
          uStack_348 = (uint)uVar15;
          uVar10 = uVar10 - uStack_348;
          if ((uStack_348 < uVar13) || (*(uint *)(param_5 + 2) < uStack_348)) {
            param_6 = psStack_310;
            iStack_340 = iVar18 + 1;
            goto LAB_;
          }
          if (*(ushort *)(uVar15 + *(longlong *)(param_5 + 4)) == 5) {
            *puVar17 = *puVar17 | 2;
            param_5[0xe] = param_5[0xe] + -1;
            param_5[0x15] = (short)uVar15;
            uVar12 = *(ulonglong *)(param_5 + 4);
            uVar5 = *(ushort *)((uVar15 & 0xffff) + 2 + uVar12);
            uVar4 = param_5[0x16] & 0xc7ff;
            if ((uVar5 & 0x4000) == 0) {
              param_5[0x16] = uVar4;
            }
            else {
              uVar4 = uVar5 & 0x3800 | uVar4;
              param_5[0x16] = uVar4;
            }
            uVar5 = (uVar4 ^ *(ushort *)((uVar15 & 0xffff) + 2 + uVar12)) & 0x7ff ^ uVar4;
            param_5[0x16] = uVar5;
            uVar16 = (ulonglong)(ushort)param_5[0x15];
            uVar15 = uVar12 + 4 + (ulonglong)((uVar5 & 0x7ff) * 2) + uVar16 + (uVar4 >> 0xb & 7) * 2
            ;
            if (uVar15 < uVar16 + uVar12) {
              func_0x(uVar16 + uVar12,0x19);
              uVar5 = param_5[0x16];
              uVar16 = (ulonglong)(ushort)param_5[0x15];
              uVar12 = (ulonglong)*(uint *)(param_5 + 4);
            }
            if (uVar10 < (((uVar5 & 0x7ff) * 2 - (int)uVar16) - (int)uVar12) + (int)uVar15) {
              func_0x(uVar16 + *(longlong *)(param_5 + 4),0x19);
              uVar5 = param_5[0x16];
            }
            if ((uVar5 & 0x3800) != 0) {
              uVar5 = param_5[0x15];
              lVar6 = *(longlong *)(param_5 + 4);
              for (iVar14 = 0; iStack_304 = iVar14, iVar14 < (int)((ushort)param_5[0x16] >> 0xb & 7)
                  ; iVar14 = iVar14 + 1) {
                if ((param_5[0x16] & 0x7ffU) <
                    (*(ushort *)((ulonglong)uVar5 + lVar6 + 4 + (longlong)iVar14 * 2) & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_5[0x15] + *(longlong *)(param_5 + 4),0x1a
                                 );
                }
              }
            }
            break;
          }
          if (*(ushort *)(uVar15 + *(longlong *)(param_5 + 4)) < 0x400) break;
          *puVar17 = *puVar17 | 1;
          uVar5 = param_5[0xe] - 1;
          param_5[0xe] = uVar5;
        } while (uVar5 != 0);
      }
      if ((**(byte **)(param_5 + 4) & 0x40) == 0) {
        *(undefined4 *)(param_5 + 0x13) = 0;
      }
      else {
        *(int *)(param_5 + 0x13) = *(int *)(param_5 + 2);
        *(int *)(param_5 + 2) = *(int *)(param_5 + 2) + 0xe;
        puVar7 = (ulonglong *)func_0x(puVar17);
        uStack_278 = *puVar7;
        iVar14 = 0;
        uVar5 = (ushort)(uStack_278 >> 0x30);
        if ((((uint)(int)(short)uVar5 >> 1 ^ (int)(short)uVar5) & 0x2000) != 0) {
          if ((uStack_278 & 0x4000000000000000) == 0) {
            uVar5 = uVar5 & 0xdfff;
          }
          else {
            uVar5 = uVar5 | 0x2000;
          }
        }
        if (uVar5 == 0xfffc) {
          iVar14 = (int)((uStack_278 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_5 + 2) = *(int *)(param_5 + 2) + iVar14;
      }
      uVar10 = *(uint *)(param_5 + 2);
      if ((*(ulonglong *)(param_5 + 0xf) != 0) &&
         (*(ulonglong *)(param_5 + 0xf) < (ulonglong)uVar10 + *(longlong *)(param_5 + 4))) {
        iVar18 = iVar18 + 1;
        iStack_340 = iVar18;
        cVar3 = func_0x(0x1a33640);
        if ((cVar3 != '\0') &&
           ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))))
        {
          cVar3 = func_0x(0x1a33640);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x132304c,0x1443138,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_5 + 4),0x12);
        uVar10 = *(uint *)(param_5 + 2);
      }
      param_6 = psStack_310;
      iStack_340 = iVar18;
      if (0x3f3b < uVar10 - 1) {
        iStack_340 = iVar18 + 1;
        cVar3 = func_0x(0x1a33640);
        if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
           (*(char *)(lVar6 + 0x499) != '\0')) {
          cVar3 = func_0x(0x1a33640);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x132304c,0x1443138,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_5 + 4),5);
        param_6 = psStack_310;
        iStack_340 = iVar18 + 1;
      }
    }
LAB_:
    uVar10 = *(uint *)(param_5 + 2);
    if ((uVar10 < 9) &&
       (((**(byte **)(param_5 + 4) & 0xe) == 0 || ((**(byte **)(param_5 + 4) & 0xe) == 0xc)))) {
      uVar10 = 9;
    }
  }
  else {
    uVar10 = *(uint *)(param_5 + 2);
    if (uVar10 == 0) {
      func_0x();
      uVar10 = *(uint *)(param_5 + 2);
    }
    if ((uVar10 < 9) &&
       (((**(byte **)(param_5 + 4) & 0x1c) == 0 || ((**(byte **)(param_5 + 4) & 0x1c) == 0xc)))) {
      uVar10 = 9;
    }
  }
  uStack_348 = 9;
  puVar19 = (ushort *)(param_6 + 1);
  if (*param_6 == 0) {
    if (*(int *)(param_6 + 2) == 0) {
      iVar18 = 0;
      iStack_33c = 0;
      *puVar19 = 0;
      uVar13 = *(uint *)(param_6 + 8);
      uVar15 = (ulonglong)uVar13;
      *(uint *)(param_6 + 10) = uVar13;
      pbVar1 = *(byte **)(param_6 + 4);
      bVar9 = *pbVar1;
      if ((bVar9 & 0x10) != 0) {
        uVar13 = uVar13 + (*(ushort *)(pbVar1 + uVar15) + 7 >> 3) + 2;
        uVar15 = (ulonglong)uVar13;
        *(uint *)(param_6 + 10) = uVar13;
        bVar9 = *pbVar1;
      }
      if ((bVar9 & 0x20) == 0) {
        *(int *)(param_6 + 2) = (int)uVar15;
        param_6[0xe] = 0;
        *(uint *)(param_6 + 0xc) = uVar13;
      }
      else {
        puVar20 = (ushort *)(pbVar1 + uVar15);
        uVar5 = *puVar20;
        param_6[0xe] = uVar5;
        if (uVar5 == 0) {
          iVar18 = 1;
          iStack_33c = 1;
          cVar3 = func_0x(0x1a33640);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x1a33640);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0x132304c,0x1443138,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_6 + 4),3);
          uVar5 = param_6[0xe];
          uVar13 = *(uint *)(param_6 + 10);
        }
        uVar13 = uVar13 + (uVar5 + 1) * 2;
        *(uint *)(param_6 + 0xc) = uVar13;
        if (0x1f9e < uVar13) {
          iVar18 = iVar18 + 1;
          iStack_33c = iVar18;
          cVar3 = func_0x(0x1a33640);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x1a33640);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x132304c,0x1443138,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_6 + 4),4);
          uVar5 = param_6[0xe];
          uVar13 = *(uint *)(param_6 + 0xc);
        }
        uVar5 = puVar20[uVar5];
        *(uint *)(param_6 + 2) = uVar5 & 0x7fff;
        if ((uVar5 & 0x7fff) < uVar13) {
          iVar18 = iVar18 + 1;
          iStack_33c = iVar18;
          cVar3 = func_0x(0x1a33640);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x1a33640);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0x132304c,0x1443138,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_6 + 4),4);
          uVar13 = *(uint *)(param_6 + 0xc);
        }
        iStack_300 = 0;
        while (iVar14 = iStack_300, uVar5 = param_6[0xe], iStack_300 < (int)(uint)uVar5) {
          uVar11 = puVar20[(longlong)iStack_300 + 1] & 0x7fff;
          if ((uVar11 < uVar13) || (*(uint *)(param_6 + 2) < uVar11)) {
            iVar18 = iVar18 + 1;
            iStack_33c = iVar18;
            cVar3 = func_0x(0x1a33640);
            if ((cVar3 != '\0') &&
               ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0')
                ))) {
              cVar3 = func_0x(0x1a33640);
              if (cVar3 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x132304c,0x1443138,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_6 + 4),4);
          }
          uVar13 = uVar11;
          iStack_300 = iVar14 + 1;
        }
        do {
          if (-1 < (short)puVar20[(ulonglong)(uVar5 - 1) + 1]) break;
          lVar6 = (ulonglong)*(uint *)(param_6 + 10) + *(longlong *)(param_6 + 4);
          uVar13 = *(ushort *)(lVar6 + (ulonglong)uVar5 * 2) & 0x7fff;
          if (uVar5 == 1) {
            uVar11 = *(uint *)(param_6 + 0xc);
            uVar8 = uVar11;
LAB_:
            if ((uVar13 < uVar11) || (*(uint *)(param_6 + 2) < uVar13)) goto LAB_;
          }
          else {
            uVar11 = *(ushort *)(lVar6 + -2 + (ulonglong)uVar5 * 2) & 0x7fff;
            uVar8 = *(uint *)(param_6 + 0xc);
            if (uVar8 <= uVar11) goto LAB_;
LAB_:
            func_0x(*(longlong *)(param_6 + 4),7);
            uVar8 = *(uint *)(param_6 + 0xc);
          }
          uStack_2b0 = uVar11;
          if ((uVar11 < uVar8) || (*(uint *)(param_6 + 2) < uVar11)) {
            iStack_33c = iVar18 + 1;
            goto LAB_;
          }
          if (*(ushort *)((ulonglong)uVar11 + *(longlong *)(param_6 + 4)) == 5) {
            *puVar19 = *puVar19 | 2;
            param_6[0xe] = param_6[0xe] + -1;
            param_6[0x15] = (short)uVar11;
            uVar15 = *(ulonglong *)(param_6 + 4);
            uVar5 = *(ushort *)((ulonglong)(uVar11 & 0xffff) + 2 + uVar15);
            uVar4 = param_6[0x16] & 0xc7ff;
            if ((uVar5 >> 0xe & 1) == 0) {
              param_6[0x16] = uVar4;
            }
            else {
              uVar4 = uVar5 & 0x3800 | uVar4;
              param_6[0x16] = uVar4;
            }
            uVar5 = (uVar4 ^ *(ushort *)((ulonglong)(uVar11 & 0xffff) + 2 + uVar15)) & 0x7ff ^ uVar4
            ;
            param_6[0x16] = uVar5;
            uVar16 = (ulonglong)(ushort)param_6[0x15];
            uVar12 = (ulonglong)((uVar5 & 0x7ff) * 2) + 4 + uVar16 + (uVar4 >> 0xb & 7) * 2 + uVar15
            ;
            if (uVar12 < uVar16 + uVar15) {
              func_0x(uVar16 + uVar15,0x19);
              uVar5 = param_6[0x16];
              uVar16 = (ulonglong)(ushort)param_6[0x15];
              uVar15 = (ulonglong)*(uint *)(param_6 + 4);
            }
            if (uVar13 - uVar11 < (((uVar5 & 0x7ff) * 2 - (int)uVar16) - (int)uVar15) + (int)uVar12)
            {
              func_0x(uVar16 + *(longlong *)(param_6 + 4),0x19);
              uVar5 = param_6[0x16];
            }
            if ((uVar5 & 0x3800) != 0) {
              uVar5 = param_6[0x15];
              lVar6 = *(longlong *)(param_6 + 4);
              iStack_2fc = 0;
              while (iVar14 = iStack_2fc, iStack_2fc < (int)((ushort)param_6[0x16] >> 0xb & 7)) {
                if ((param_6[0x16] & 0x7ffU) <
                    (*(ushort *)((ulonglong)uVar5 + lVar6 + 4 + (longlong)iStack_2fc * 2) & 0x7ff))
                {
                  func_0x((ulonglong)(ushort)param_6[0x15] + *(longlong *)(param_6 + 4),0x1a
                                 );
                }
                iStack_2fc = iVar14 + 1;
              }
            }
            break;
          }
          if (*(ushort *)((ulonglong)uVar11 + *(longlong *)(param_6 + 4)) < 0x400) break;
          *puVar19 = *puVar19 | 1;
          uVar5 = param_6[0xe] - 1;
          param_6[0xe] = uVar5;
        } while (uVar5 != 0);
      }
      if ((**(byte **)(param_6 + 4) & 0x40) == 0) {
        *(undefined4 *)(param_6 + 0x13) = 0;
      }
      else {
        *(int *)(param_6 + 0x13) = *(int *)(param_6 + 2);
        *(int *)(param_6 + 2) = *(int *)(param_6 + 2) + 0xe;
        puVar7 = (ulonglong *)func_0x(puVar19);
        uStack_270 = *puVar7;
        uVar13 = 0;
        uVar5 = (ushort)(uStack_270 >> 0x30);
        if ((((uint)(int)(short)uVar5 >> 1 ^ (int)(short)uVar5) & 0x2000) != 0) {
          if ((uStack_270 & 0x4000000000000000) == 0) {
            uVar5 = uVar5 & 0xdfff;
          }
          else {
            uVar5 = uVar5 | 0x2000;
          }
        }
        if (uVar5 == 0xfffc) {
          uVar13 = ((uint)(uStack_270 >> 0x20) & 0xffff) >> 5;
        }
        *(uint *)(param_6 + 2) = *(int *)(param_6 + 2) + uVar13;
      }
      uVar13 = *(uint *)(param_6 + 2);
      if ((*(ulonglong *)(param_6 + 0xf) != 0) &&
         (*(ulonglong *)(param_6 + 0xf) < (ulonglong)uVar13 + *(longlong *)(param_6 + 4))) {
        iVar18 = iVar18 + 1;
        iStack_33c = iVar18;
        cVar3 = func_0x(0x1a33640);
        if ((cVar3 != '\0') &&
           ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))))
        {
          cVar3 = func_0x(0x1a33640);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0x132304c,0x1443138,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_6 + 4),0x12);
        uVar13 = *(uint *)(param_6 + 2);
      }
      iStack_33c = iVar18;
      if (0x3f3b < uVar13 - 1) {
        iStack_33c = iVar18 + 1;
        cVar3 = func_0x(0x1a33640);
        if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
           (*(char *)(lVar6 + 0x499) != '\0')) {
          cVar3 = func_0x(0x1a33640);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0x132304c,0x1443138,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_6 + 4),5);
        iStack_33c = iVar18 + 1;
      }
    }
LAB_:
    uVar13 = *(uint *)(param_6 + 2);
    if (8 < uVar13) goto LAB_;
    bVar9 = **(byte **)(param_6 + 4) & 0xe;
  }
  else {
    uVar13 = *(uint *)(param_6 + 2);
    if (uVar13 == 0) {
      func_0x(puVar19);
      uVar13 = *(uint *)(param_6 + 2);
    }
    if (8 < uVar13) goto LAB_;
    bVar9 = **(byte **)(param_6 + 4) & 0x1c;
  }
  if ((bVar9 == 0) || (bVar9 == 0xc)) {
    uVar13 = 9;
  }
LAB_:
  if (uVar10 <= uVar13) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*psStack_320 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_5 + 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  iVar18 = 0;
  *puVar17 = 0;
  uVar10 = *(uint *)(param_5 + 8);
  uVar15 = (ulonglong)uVar10;
  *(uint *)(param_5 + 10) = uVar10;
  pbVar1 = *(byte **)(param_5 + 4);
  bVar9 = *pbVar1;
  if ((bVar9 & 0x10) != 0) {
    uVar10 = uVar10 + 2 + (*(ushort *)(pbVar1 + uVar15) + 7 >> 3);
    uVar15 = (ulonglong)uVar10;
    *(uint *)(param_5 + 10) = uVar10;
    bVar9 = *pbVar1;
  }
  if ((bVar9 & 0x20) != 0) {
    puVar17 = (ushort *)(pbVar1 + uVar15);
    uVar5 = *puVar17;
    param_5[0xe] = uVar5;
    if (uVar5 == 0) {
      iVar18 = 1;
      iStack_338 = 1;
      cVar3 = func_0x(0x1a33640);
      if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
         (*(char *)(lVar6 + 0x499) != '\0')) {
        cVar3 = func_0x(0x1a33640);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3eb);
        }
        else {
          (*_DAT_)(1,0x132304c,0x1443138,0x80f,0);
        }
      }
      func_0x(*(undefined8 *)(param_5 + 4),3);
      uVar5 = param_5[0xe];
      uVar10 = *(uint *)(param_5 + 10);
    }
    uVar10 = uVar10 + (uVar5 + 1) * 2;
    *(uint *)(param_5 + 0xc) = uVar10;
    if (0x1f9e < uVar10) {
      iVar18 = iVar18 + 1;
      iStack_338 = iVar18;
      cVar3 = func_0x(0x1a33640);
      if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
         (*(char *)(lVar6 + 0x499) != '\0')) {
        cVar3 = func_0x(0x1a33640);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ec);
        }
        else {
          (*_DAT_)(1,0x132304c,0x1443138,0x816,0);
        }
      }
      func_0x(*(undefined8 *)(param_5 + 4),4);
      uVar5 = param_5[0xe];
      uVar10 = *(uint *)(param_5 + 0xc);
    }
    uVar5 = puVar17[uVar5];
    *(uint *)(param_5 + 2) = uVar5 & 0x7fff;
    if ((uVar5 & 0x7fff) < uVar10) {
      iVar18 = iVar18 + 1;
      iStack_338 = iVar18;
      cVar3 = func_0x(0x1a33640);
      if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
         (*(char *)(lVar6 + 0x499) != '\0')) {
        cVar3 = func_0x(0x1a33640);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ec);
        }
        else {
          (*_DAT_)(1,0x132304c,0x1443138,0x81d,0);
        }
      }
      func_0x(*(undefined8 *)(param_5 + 4),4);
      uVar10 = *(uint *)(param_5 + 0xc);
    }
    iStack_2f8 = 0;
    while (iVar14 = iStack_2f8, iStack_2f8 < (int)(uint)(ushort)param_5[0xe]) {
      uVar13 = puVar17[(longlong)iStack_2f8 + 1] & 0x7fff;
      if ((uVar13 < uVar10) || (*(uint *)(param_5 + 2) < uVar13)) {
        iVar18 = iVar18 + 1;
        iStack_338 = iVar18;
        cVar3 = func_0x(0x1a33640);
        if ((cVar3 != '\0') &&
           ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))))
        {
          cVar3 = func_0x(0x1a33640);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x132304c,0x1443138,0x82a,0);
          }
        }
        func_0x(*(undefined8 *)(param_5 + 4),4);
      }
      uVar10 = uVar13;
      iStack_2f8 = iVar14 + 1;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

