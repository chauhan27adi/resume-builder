
/* WARNING: Control flow encountered bad instruction data */

ulonglong FUN_(short *param_1)

{
  uint uVar1;
  code *pcVar2;
  ulonglong uVar3;
  
  uVar1 = *(uint *)(param_1 + 2);
  if (*param_1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (uVar1 != 0) {
    if (8 < uVar1) {
      return (ulonglong)uVar1;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  pcVar2 = (code *)swi(3);
  uVar3 = (*pcVar2)();
  return uVar3;
}

