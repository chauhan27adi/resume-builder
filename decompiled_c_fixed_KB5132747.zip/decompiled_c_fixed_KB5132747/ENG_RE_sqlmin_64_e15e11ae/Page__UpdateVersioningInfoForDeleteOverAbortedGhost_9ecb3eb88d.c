
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,uint param_2,undefined8 param_3,undefined8 param_4,uint param_5,
                 undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  byte *pbVar1;
  byte *pbVar2;
  short sVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  char cVar6;
  undefined4 uVar7;
  longlong lVar8;
  short *psVar9;
  code *UNRECOVERED_JUMPTABLE_00;
  byte **ppbVar10;
  ulonglong uVar11;
  undefined8 uStackX_20;
  undefined8 uStack_21c0;
  undefined2 uStack_21b8;
  undefined4 uStack_21b0;
  uint uStack_21ac;
  longlong lStack_21a8;
  uint uStack_21a0;
  undefined8 uStack_2198;
  undefined8 uStack_2190;
  undefined8 uStack_2188;
  short sStack_2180;
  undefined4 uStack_217c;
  byte *pbStack_2178;
  byte **ppbStack_2170;
  undefined8 uStack_2162;
  undefined2 uStack_215a;
  undefined2 uStack_2158;
  undefined6 uStack_2156;
  uint uStack_214c;
  undefined auStack_2148 [16];
  undefined auStack_2138 [8];
  undefined8 uStack_2130;
  undefined8 uStack_2128;
  undefined6 uStack_2120;
  undefined2 uStack_211a;
  undefined6 uStack_2118;
  undefined2 uStack_2112;
  undefined8 uStack_2110;
  undefined auStack_2108 [16];
  undefined auStack_20f8 [16];
  undefined auStack_20e8 [16];
  undefined8 uStack_20d8;
  undefined8 uStack_20c8;
  undefined4 uStack_20c0;
  undefined2 uStack_20bc;
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x100022;
  uStack_214c = param_2;
  lVar8 = func_0x();
  lVar8 = -lVar8;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar8);
  uStack_2190 = param_8;
  uStack_20c8 = 0;
  uStack_21a0 = param_5 & 1;
  sStack_2180 = -1;
  pbStack_2178 = (byte *)0x0;
  uStack_217c = 0;
  uStack_2162 = 0;
  uStack_2158 = 0;
  uStack_2156 = 0;
  ppbStack_2170 = (byte **)0x0;
  *(undefined2 *)(&stack0x00000018 + lVar8) = 0xffff;
  *(undefined8 *)((longlong)&uStackX_20 + lVar8) = 0;
  *(undefined4 *)(&stack0x0000001c + lVar8) = 0;
  *(undefined8 *)((undefined *)((longlong)register0x00000020 + 0x36) + lVar8) = 0;
  *(undefined8 *)((longlong)&param_8 + lVar8) = 0;
  *(undefined8 *)((longlong)&param_5 + lVar8) = 0;
  uStack_21c0 = 0;
  uStack_20c0 = 0;
  uStack_20bc = 0;
  uStack_21ac = uStack_214c;
  lStack_21a8 = param_1;
  uStack_2198 = param_4;
  uStack_2188 = param_3;
  if ((uStack_21a0 == 0) &&
     ((*(ushort *)(param_1 + 0x16) <= uStack_214c ||
      (*(short *)(param_1 + (0xfff - (longlong)(int)uStack_214c) * 2) == 0)))) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar8) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100109;
    (*_DAT_)(1,0x1501be0,0x14ccb88);
  }
  uStack_21b0 = 9;
  if (-1 < *(char *)(param_1 + 2)) goto LAB_;
  pbVar1 = (byte *)(param_1 + 0x60);
  if ((sStack_2180 == 0) || (ppbVar10 = ppbStack_2170, ppbStack_2170 == (byte **)0x0)) {
    uStack_2120 = 0;
    stack0xffffffffffffdeca = SUB1614(ZEXT816(0),2);
    auStack_2138._0_2_ = 0xffff;
    uStack_2112 = 0;
    uStack_2130 = 0;
    uStack_211a = 0;
    uStack_2118 = 0;
    uStack_2110 = 0;
    uStack_2128 = 0;
    auStack_2108 = ZEXT816(0);
    auStack_20e8._0_12_ = ZEXT812(0);
    auStack_20e8._12_4_ = 0;
    uStack_20d8 = 0;
    auStack_20f8 = ZEXT816(0);
    auStack_2148 = ZEXT816(0);
    ppbVar10 = (byte **)auStack_2148;
  }
  if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
    uStack_21c0 = *(undefined8 *)(param_1 + 0x28);
    uStack_21b8 = *(undefined2 *)(param_1 + 0x30);
  }
  else {
    cVar6 = *(char *)(param_1 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
    }
    uStack_21c0 = CONCAT26(uStack_21c0._6_2_,*(undefined6 *)(param_1 + 0x20));
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1001ee;
    cVar6 = func_0x(&uStack_21c0);
    if (cVar6 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x1001fe;
    func_0x(param_1,&uStack_21c0);
  }
  *ppbVar10 = pbVar1;
  *(undefined4 *)(ppbVar10 + 0xc) = (undefined4)uStack_21c0;
  *(undefined2 *)(ppbVar10 + 0xd) = uStack_21b8;
  uVar7 = (undefined4)((ulonglong)uStack_21c0 >> 0x20);
  *(undefined4 *)((longlong)ppbVar10 + 100) = uVar7;
  *(undefined4 *)((longlong)ppbVar10 + 0x6c) = *(undefined4 *)(param_1 + 0x20);
  *(undefined2 *)(ppbVar10 + 0xe) = *(undefined2 *)(param_1 + 0x24);
  *(undefined2 *)((longlong)ppbVar10 + 0x72) = 0;
  uVar4 = *(undefined4 *)((ulonglong)*pbVar1 * 6 + 0x11414c0);
  uVar11 = (ulonglong)*(short *)((ulonglong)*pbVar1 * 6 + 0x11414c4);
  *(undefined2 *)(ppbVar10 + 2) = 0xffff;
  ppbVar10[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar10 + 0x2e) = 0;
  ppbVar10[7] = (byte *)0x0;
  ppbVar10[4] = (byte *)0x0;
  ppbVar10[9] = (byte *)0x0;
  ppbVar10[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar10 + 0xb) = 0;
  uStack_21c0 = CONCAT44(uVar7,uVar4);
  uVar5 = uStack_21c0;
  if ((**ppbVar10 & 2) != 0) {
    pbVar2 = pbVar1 + uVar11;
    if ((pbVar1[uVar11] & 1) == 0) {
      *(undefined2 *)(ppbVar10 + 2) = 0;
      ppbVar10[3] = pbVar2;
      *(undefined4 *)((longlong)ppbVar10 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbVar10 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100458 */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x102284) - 0x1457950))()
      ;
      return;
    }
    *(undefined2 *)(ppbVar10 + 2) = 1;
    ppbVar10[3] = pbVar2;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x102264) * 4 +
                           0x102254) - 0x1457950);
                    /* WARNING: Could not emulate address calculation at 0x001002c4 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbVar10 & 4) != 0) {
    uStack_21c0._2_2_ = (short)((uint)uVar4 >> 0x10);
    if (uStack_21c0._2_2_ != 0) {
      uVar11 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)uStack_21c0._2_2_ * 2);
    }
    psVar9 = (short *)(pbVar1 + uVar11);
    ppbVar10[9] = (byte *)psVar9;
    sVar3 = *psVar9;
    ppbVar10[10] = (byte *)(psVar9 + 1);
    *(short *)(ppbVar10 + 0xb) = (sVar3 + 1) * 2;
  }
  pbVar1 = ppbVar10[1];
  param_1 = lStack_21a8;
  uStack_21c0 = uVar5;
  if (pbVar1 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar8) = 0x100516;
    func_0x(pbVar1,ppbVar10);
    param_1 = lStack_21a8;
  }
LAB_:
  pbStack_2178 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)(int)uStack_21ac) * 2)
                         + param_1);
  if ((*pbStack_2178 & 1) == 0) {
    sStack_2180 = 0;
    uStack_217c = 0;
    uStack_215a = 0;
    uStack_2158 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001006e6 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_2178 & 0xe) * 4 + 0x1022f0) - 0x1457950
              ))(0x10c2be0);
    return;
  }
  sStack_2180 = 1;
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbStack_2178 & 0x1c) + 0x1022d0) * 4
                         + 0x1022c0) - 0x1457950);
                    /* WARNING: Could not emulate address calculation at 0x0010056c */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

