
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 param_2,longlong *param_3)

{
  longlong lVar1;
  undefined auVar2 [16];
  undefined2 uVar3;
  ulonglong uVar4;
  char cVar5;
  uint uVar6;
  int iVar7;
  longlong lVar8;
  ulonglong *puVar9;
  ulonglong *puVar10;
  undefined8 uVar11;
  ulonglong uVar12;
  uint uVar13;
  ulonglong uVar15;
  longlong lVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  longlong unaff_GS_OFFSET;
  undefined auStack_208 [32];
  undefined8 uStack_1e8;
  undefined8 uStack_1e0;
  ulonglong uStack_1d8;
  undefined8 uStack_1d0;
  undefined4 uStack_1c8;
  undefined4 uStack_1b8;
  undefined4 auStack_1b0 [2];
  ulonglong uStack_1a8;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined4 auStack_198 [2];
  undefined8 uStack_190;
  undefined4 uStack_188;
  undefined auStack_180 [24];
  undefined auStack_168 [16];
  undefined auStack_158 [16];
  undefined auStack_148 [16];
  undefined auStack_138 [16];
  undefined auStack_128 [16];
  undefined8 uStack_118;
  undefined8 uStack_108;
  undefined auStack_100 [16];
  undefined auStack_f0 [16];
  undefined auStack_e0 [24];
  longlong lStack_c8;
  undefined2 uStack_c0;
  undefined8 uStack_b8;
  int iStack_b0;
  undefined auStack_a8 [16];
  undefined auStack_98 [16];
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  longlong lStack_68;
  uint uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  ulonglong uStack_48;
  ulonglong *puVar14;
  
  uStack_108 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_208;
  lVar1 = *(longlong *)
           (*(longlong *)((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)) + 8
           + (ulonglong)*_DAT_);
  lVar16 = *(longlong *)((ulonglong)*_DAT_ * 8 + *(longlong *)(unaff_GS_OFFSET + 0x58)) +
           (ulonglong)*_DAT_;
  lVar8 = *(longlong *)(lVar16 + 0x100);
  auStack_1b0[0] = param_2;
  if (lVar8 == 0) {
    (*_DAT_)(0);
    lVar8 = *(longlong *)(lVar16 + 0x100);
  }
  uStack_1a8 = *(ulonglong *)(lVar8 + 600);
  puVar14 = (ulonglong *)0x0;
  uStack_190 = 0;
  uStack_188 = 1;
  auStack_180._0_16_ = ZEXT816(0);
  if ((lVar1 == 0) || (uStack_1a8 == 0)) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1c5eae8,0x1c39060,0x415);
  }
  if (*(longlong *)(param_1 + 0x28) != 0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1c5eb10,0x1c39060,0x416);
  }
  uStack_1b8 = CONCAT22(uStack_1b8._2_2_,
                        *(undefined2 *)
                         (*(longlong *)
                           (*(longlong *)
                             ((ulonglong)*_DAT_ +
                             *(longlong *)
                              (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8
                              )) + 0x50) + 8));
  if (param_1 + 0x280 == 0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1c5ed48,0x1c390e0,0xcc8);
  }
  if (param_3 == (longlong *)0x0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1c5ed50,0x1c390e0,0xcca);
  }
  uStack_1a0 = 0;
  if (((*param_3 == 0) || (param_3[0xc] == 0)) || (*(int *)(param_3 + 0xd) == 0)) {
LAB_:
    uVar17 = 0;
  }
  else {
    uVar6 = func_0x(param_3,0x1aaa188,&uStack_1a0);
    puVar9 = puVar14;
    if (((param_3[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) &&
       (puVar9 = (ulonglong *)0x0, *(uint *)(param_3 + 0xd) != 0)) {
      do {
        puVar9 = (ulonglong *)((longlong)puVar14 * 0x58 + param_3[0xc]);
        if (*puVar9 == (ulonglong)uVar6) {
          if (puVar9 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar13 = (int)puVar14 + 1;
        puVar14 = (ulonglong *)(ulonglong)uVar13;
        puVar9 = (ulonglong *)0x0;
      } while (uVar13 < *(uint *)(param_3 + 0xd));
    }
    uStack_1e8 = CONCAT44(uStack_1e8._4_4_,*(undefined4 *)(param_3 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
    lVar1 = *param_3;
    uVar17 = *(ulonglong *)(lVar1 + puVar9[2]);
    iVar7 = *(int *)(lVar1 + puVar9[3]);
    uVar12 = puVar9[1];
    if (0x202 < uVar17) {
      uStack_1e8 = 0;
      (*_DAT_)(1,0x1c5ed60,0x1c390e0,0xcd1);
    }
    if (((uVar12 + lVar1 == 0) || (uVar17 == 0)) || (iVar7 == 3)) goto LAB_;
    if (uVar17 < 0x203) {
      func_0x(param_1 + 0x280,uVar12 + lVar1,uVar17);
    }
  }
  puVar14 = (ulonglong *)0x0;
  *(undefined2 *)(param_1 + 0x280 + (uVar17 & 0xfffffffffffffffe)) = 0;
  if (param_1 + 0x500 == 0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1c5ed48,0x1c390e0,0xcc8);
  }
  uStack_19c = 0;
  if (((*param_3 == 0) || (param_3[0xc] == 0)) || (*(int *)(param_3 + 0xd) == 0)) {
LAB_:
    uVar17 = 0;
  }
  else {
    uVar6 = func_0x(param_3,0x1aaa198,&uStack_19c);
    if (((param_3[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) && (*(uint *)(param_3 + 0xd) != 0)) {
      puVar9 = puVar14;
      do {
        puVar10 = (ulonglong *)((longlong)puVar9 * 0x58 + param_3[0xc]);
        if (*puVar10 == (ulonglong)uVar6) {
          puVar14 = puVar10;
          if (puVar10 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar13 = (int)puVar9 + 1;
        puVar9 = (ulonglong *)(ulonglong)uVar13;
      } while (uVar13 < *(uint *)(param_3 + 0xd));
    }
    uStack_1e8 = CONCAT44(uStack_1e8._4_4_,*(undefined4 *)(param_3 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
    puVar10 = puVar14;
LAB_:
    lVar1 = *param_3;
    uVar17 = *(ulonglong *)(lVar1 + puVar10[2]);
    iVar7 = *(int *)(lVar1 + puVar10[3]);
    uVar12 = puVar10[1];
    if (0x202 < uVar17) {
      uStack_1e8 = 0;
      (*_DAT_)(1,0x1c5ed60,0x1c390e0,0xcd1);
    }
    if (((uVar12 + lVar1 == 0) || (uVar17 == 0)) || (iVar7 == 3)) goto LAB_;
    if (uVar17 < 0x203) {
      func_0x(param_1 + 0x500,uVar12 + lVar1,uVar17);
    }
  }
  puVar14 = (ulonglong *)0x0;
  *(undefined2 *)(param_1 + 0x500 + (uVar17 & 0xfffffffffffffffe)) = 0;
  if (param_1 + 0x710 == 0) {
    uStack_1e8 = 0;
    (*_DAT_)(1,0x1c5ed48,0x1c390e0,0xcc8);
  }
  auStack_198[0] = 0;
  if (((*param_3 != 0) && (param_3[0xc] != 0)) && (*(int *)(param_3 + 0xd) != 0)) {
    uVar6 = func_0x(param_3,0x1aaa150,auStack_198);
    if (((param_3[0xc] != 0) && (uVar6 - 1 < 0xfffffffe)) && (*(uint *)(param_3 + 0xd) != 0)) {
      puVar9 = puVar14;
      do {
        puVar10 = (ulonglong *)((longlong)puVar9 * 0x58 + param_3[0xc]);
        if (*puVar10 == (ulonglong)uVar6) {
          puVar14 = puVar10;
          if (puVar10 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar13 = (int)puVar9 + 1;
        puVar9 = (ulonglong *)(ulonglong)uVar13;
      } while (uVar13 < *(uint *)(param_3 + 0xd));
    }
    uStack_1e8 = CONCAT44(uStack_1e8._4_4_,*(undefined4 *)(param_3 + 3));
    (*_DAT_)(0xbb,0x38,0x10,0xd);
    puVar10 = puVar14;
LAB_:
    lVar1 = *param_3;
    uVar12 = *(ulonglong *)(lVar1 + puVar10[2]);
    iVar7 = *(int *)(lVar1 + puVar10[3]);
    uVar17 = puVar10[1];
    if (0x202 < uVar12) {
      uStack_1e8 = 0;
      (*_DAT_)(1,0x1c5ed60,0x1c390e0,0xcd1);
    }
    if (((uVar17 + lVar1 != 0) && (uVar12 != 0)) && (iVar7 != 3)) {
      if (uVar12 < 0x203) {
        func_0x(param_1 + 0x710,uVar17 + lVar1,uVar12);
      }
      goto LAB_;
    }
  }
  uVar12 = 0;
LAB_:
  uVar17 = 0;
  *(undefined2 *)(param_1 + 0x710 + (uVar12 & 0xfffffffffffffffe)) = 0;
  uStack_188 = 1;
  auStack_180._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  cVar5 = (**(code **)(*(longlong *)auStack_180._0_8_ + 0x1d0))();
  if (cVar5 == '\0') {
    uStack_1c8 = 0;
    uStack_1d0 = 0;
    uStack_1d8 = uStack_1d8 & 0xffffffffffffff00;
    uStack_1e0 = (undefined8 *)CONCAT44(uStack_1e0._4_4_,2);
    uStack_1e8 = CONCAT44(uStack_1e8._4_4_,1);
    (**(code **)(*(longlong *)auStack_180._0_8_ + 8))(auStack_180._0_8_,0x1aaa160,0xf,1);
    uStack_190 = CONCAT44(uStack_190._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_180._0_8_ + 0xe8))
              (auStack_180._0_8_,1,1,(longlong)&uStack_190 + 4);
    uStack_188 = 1;
    uStack_190 = CONCAT44(uStack_190._4_4_,4);
  }
  uVar3 = (undefined2)uStack_1b8;
  iVar7 = func_0x((undefined2)uStack_1b8,0x1aaa0f8);
  if (iVar7 == 0) {
    func_0x(0x4977,0x10,1,0x1aaa0f8);
  }
  else {
    uStack_b8 = (**(code **)(*(longlong *)auStack_180._0_8_ + 0x1b0))();
    lStack_c8 = 0;
    uStack_c0 = uVar3;
    auStack_a8 = ZEXT816(0);
    auStack_98 = ZEXT816(0);
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    lStack_68 = 0;
    uStack_60 = 0;
    uStack_58 = 0;
    uStack_50 = 0;
    iStack_b0 = iVar7;
    iVar7 = func_0x(&lStack_c8,3,1);
    if (iVar7 == 0) {
      func_0x(0x49aa,0x10,3,0x1aaa0f8);
    }
    else {
      uStack_1b8 = 4;
      auStack_e0._0_4_ = func_0x(&lStack_c8,0x18a9eb0,&uStack_1b8);
      auStack_100 = ZEXT816(0);
      auStack_f0 = ZEXT816(0);
      auStack_e0._4_12_ = SUB1612(ZEXT816(0),4);
      uStack_118 = 0;
      auStack_128 = ZEXT416(uStack_1b8) << 0x40;
      auStack_158 = ZEXT816(0);
      auStack_168 = ZEXT416((uint)auStack_e0._0_4_);
      auStack_138._0_12_ = ZEXT412(1) << 0x40;
      auStack_138._12_4_ = 0;
      auStack_148._8_8_ = 0;
      auStack_148._0_8_ = auStack_100;
      uStack_1d8 = 0;
      uStack_1e0 = &uStack_50;
      uStack_1e8 = 0;
      (**(code **)(*(longlong *)auStack_98._8_8_ + 0x20))(auStack_98._8_8_,2,1,auStack_168);
      uStack_1d8 = uStack_1d8 & 0xffffffff00000000;
      uStack_1e0 = (undefined8 *)auStack_1b0;
      uStack_1e8 = 1;
      (**(code **)(*(longlong *)auStack_88._8_8_ + 0x28))(auStack_88._8_8_,uStack_50,1,auStack_1b0);
      uStack_1e0 = (undefined8 *)lStack_c8;
      uStack_1e8 = uStack_58;
      iVar7 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1,0);
      uVar4 = uStack_1a8;
      while (iVar7 == 0) {
        if (((*(uint *)(uVar4 + 0xbc) & 4) != 0) &&
           ((iVar7 = func_0x(), iVar7 != 0 ||
            (((lVar1 = *(longlong *)
                        ((ulonglong)*_DAT_ +
                        *(longlong *)
                         (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
              lVar1 != 0 && (*(char *)(*(longlong *)(lVar1 + 0x38) + 8) != '\0')) &&
             (iVar7 = func_0x(), iVar7 == 0)))))) goto LAB_;
        *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
        uStack_1e0 = (undefined8 *)lStack_c8;
        uStack_1e8 = uStack_58;
        iVar7 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1,0);
      }
      auVar2 = ZEXT816(4) * ZEXT416(*(uint *)(param_1 + 0x24));
      uVar11 = auVar2._0_8_;
      if (auVar2._8_8_ != 0) {
        uVar11 = 0xffffffffffffffff;
      }
      uStack_1e0 = (undefined8 *)CONCAT71(uStack_1e0._1_7_,6);
      uStack_1e8 = CONCAT44(uStack_1e8._4_4_,0x442);
      uVar11 = (*_DAT_)(uVar11,_DAT_,1,0x1aaa2f8);
      *(undefined8 *)(param_1 + 0x28) = uVar11;
      uVar18 = (ulonglong)*(uint *)(param_1 + 0x24) * 4;
      if (0xffffffff < uVar18) {
        uVar18 = 0xffffffff;
        func_0x(0x80070216,4);
      }
      uStack_1e8 = 0;
      func_0x(uVar3,0x1f,uVar18 & 0xffffffff,1);
      if (*(longlong *)(param_1 + 0x28) == 0) {
        uStack_1e8 = 0;
        (*_DAT_)(1,0x1c5eaf8,0x1c39060,0x443);
      }
      iVar7 = (**(code **)(*(longlong *)auStack_88._0_8_ + 0x38))(auStack_88._0_8_,0);
      uVar18 = uVar17;
      if (iVar7 == 0) {
        while( true ) {
          uStack_1e0 = (undefined8 *)lStack_c8;
          uStack_1e8 = uStack_58;
          iVar7 = (**(code **)(*(longlong *)auStack_a8._8_8_ + 0x18))(auStack_a8._8_8_,0,1,0);
          if ((iVar7 != 0) ||
             (((*(uint *)(uVar4 + 0xbc) & 4) != 0 &&
              ((iVar7 = func_0x(), iVar7 != 0 ||
               (((lVar1 = *(longlong *)
                           ((ulonglong)*_DAT_ +
                           *(longlong *)
                            (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8))
                 , lVar1 != 0 && (*(char *)(*(longlong *)(lVar1 + 0x38) + 8) != '\0')) &&
                (iVar7 = func_0x(), iVar7 == 0)))))))) break;
          uStack_1a8 = uStack_1a8 & 0xffffffff00000000;
          uVar15 = uVar17;
          if (((lStack_c8 != 0) && (lStack_68 != 0)) && (uStack_60 != 0)) {
            uVar6 = func_0x(&lStack_c8,0x1845ae0,&uStack_1a8);
            if (((lStack_68 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uStack_60 != 0)) {
              uVar12 = uVar17;
              do {
                if (*(ulonglong *)(uVar12 * 0x58 + lStack_68) == (ulonglong)uVar6) {
                  uVar15 = lStack_68 + uVar12 * 0x58;
                  if (uVar15 != 0) goto LAB_;
                  break;
                }
                uVar13 = (int)uVar12 + 1;
                uVar12 = (ulonglong)uVar13;
              } while (uVar13 < uStack_60);
            }
            uStack_1e8 = CONCAT44(uStack_1e8._4_4_,iStack_b0);
            (*_DAT_)(0xbb);
LAB_:
            uVar12 = *(ulonglong *)(lStack_c8 + *(longlong *)(uVar15 + 0x10));
            uVar15 = *(longlong *)(uVar15 + 8) + lStack_c8;
          }
          *(undefined4 *)(uVar18 * 4 + *(longlong *)(param_1 + 0x28)) = 0;
          func_0x
                    (uVar18 * 4 + *(longlong *)(param_1 + 0x28),uVar15,uVar12 & 0xffffffff);
          uVar18 = (ulonglong)((int)uVar18 + 1);
        }
      }
      else {
        uStack_1e8 = CONCAT44(uStack_1e8._4_4_,iVar7);
        func_0x(0x497a,0x10,1,0x1aaa0f8);
      }
    }
LAB_:
    func_0x(&lStack_c8);
  }
  func_0x(&uStack_190,0);
  if ((int)uStack_190 != 0) {
    func_0x(&uStack_190,0);
  }
  func_0x(uStack_48 ^ (ulonglong)auStack_208);
  return;
}

