
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,int param_3)

{
  longlong lVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  short *psVar6;
  ulonglong uVar7;
  uint uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  longlong unaff_GS_OFFSET;
  undefined auStack_1d8 [32];
  undefined8 uStack_1b8;
  undefined8 uStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  undefined4 uStack_198;
  uint auStack_188 [2];
  int aiStack_180 [2];
  undefined4 auStack_178 [2];
  undefined8 uStack_170;
  undefined4 uStack_168;
  undefined auStack_160 [24];
  undefined auStack_148 [16];
  undefined auStack_138 [16];
  undefined auStack_128 [16];
  undefined auStack_118 [16];
  undefined auStack_108 [16];
  undefined8 uStack_f8;
  undefined8 uStack_e8;
  undefined auStack_e0 [16];
  undefined auStack_d0 [16];
  undefined auStack_c0 [24];
  longlong lStack_a8;
  undefined2 uStack_a0;
  undefined8 uStack_98;
  int iStack_90;
  undefined auStack_88 [16];
  undefined auStack_78 [16];
  undefined auStack_68 [16];
  undefined auStack_58 [16];
  longlong lStack_48;
  uint uStack_40;
  undefined8 uStack_38;
  undefined8 uStack_30;
  ulonglong uStack_28;
  
  uStack_e8 = 0xfffffffffffffffe;
  uStack_28 = _DAT_ ^ (ulonglong)auStack_1d8;
  aiStack_180[0] = param_3;
  if (param_2 == 0) {
    if (param_3 == 0) goto LAB_;
  }
  else if (param_2 - 0x25U < 2) goto LAB_;
  psVar6 = *(short **)(_DAT_ + 0xd8);
  if (psVar6 != (short *)0x0) {
    do {
      if (*psVar6 == *(short *)(param_1 + 0x128)) {
        for (lVar1 = *(longlong *)(psVar6 + 0x10); lVar1 != 0; lVar1 = *(longlong *)(lVar1 + 0x18))
        {
          for (lVar2 = *(longlong *)(lVar1 + 0x10); lVar2 != 0; lVar2 = *(longlong *)(lVar2 + 0xed0)
              ) {
            if (*(int *)(lVar2 + 0xc) == param_3) goto LAB_;
          }
        }
      }
      psVar6 = *(short **)(psVar6 + 0x14);
    } while (psVar6 != (short *)0x0);
  }
  uVar7 = 0;
  uStack_170 = 0;
  auStack_178[0] = 0;
  uStack_168 = 1;
  auStack_160._0_8_ =
       *(longlong **)
        (*(longlong *)
          ((ulonglong)*_DAT_ +
          *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
        0x90);
  auStack_160._8_8_ = 0;
  cVar3 = (**(code **)(*(longlong *)auStack_160._0_8_ + 0x1d0))();
  if (cVar3 == '\0') {
    uStack_198 = 0;
    uStack_1a0 = 0;
    uStack_1a8 = uStack_1a8 & 0xffffffffffffff00;
    uStack_1b0 = (undefined8 *)CONCAT44(uStack_1b0._4_4_,2);
    uStack_1b8 = CONCAT44(uStack_1b8._4_4_,1);
    (**(code **)(*(longlong *)auStack_160._0_8_ + 8))(auStack_160._0_8_,0x1ac5a78,0x14);
    uStack_170 = CONCAT44(uStack_170._4_4_,2);
  }
  else {
    (**(code **)(*(longlong *)auStack_160._0_8_ + 0xe8))
              (auStack_160._0_8_,1,1,(longlong)&uStack_170 + 4);
    uStack_168 = 1;
    uStack_170 = CONCAT44(uStack_170._4_4_,4);
  }
  iVar4 = func_0x(*(undefined2 *)(param_1 + 0x128),0x1ac54d8);
  if (iVar4 != 0) {
    uStack_98 = (**(code **)(*(longlong *)auStack_160._0_8_ + 0x1b0))();
    uStack_a0 = *(undefined2 *)(param_1 + 0x128);
    lStack_a8 = 0;
    auStack_88 = ZEXT816(0);
    auStack_78 = ZEXT816(0);
    auStack_68 = ZEXT816(0);
    auStack_58 = ZEXT816(0);
    lStack_48 = 0;
    uStack_40 = 0;
    uStack_38 = 0;
    uStack_30 = 0;
    iStack_90 = iVar4;
    iVar4 = func_0x(&lStack_a8,3,1);
    if (iVar4 != 0) {
      auStack_188[0] = 4;
      auStack_c0._0_4_ = func_0x(&lStack_a8,0x1ac59a8,auStack_188);
      auStack_e0 = ZEXT816(0);
      auStack_d0 = ZEXT816(0);
      auStack_c0._4_12_ = SUB1612(ZEXT816(0),4);
      uStack_f8 = 0;
      auStack_108 = ZEXT416(auStack_188[0]) << 0x40;
      auStack_138 = ZEXT816(0);
      auStack_148 = ZEXT416((uint)auStack_c0._0_4_);
      auStack_118._0_12_ = ZEXT412(1) << 0x40;
      auStack_118._12_4_ = 0;
      auStack_128._8_8_ = 0;
      auStack_128._0_8_ = auStack_e0;
      uStack_1a8 = 0;
      uStack_1b0 = &uStack_30;
      uStack_1b8 = 0;
      (**(code **)(*(longlong *)auStack_78._8_8_ + 0x20))(auStack_78._8_8_,2,1,auStack_148);
      uStack_1a8 = CONCAT44(uStack_1a8._4_4_,0x10);
      uStack_1b0 = (undefined8 *)aiStack_180;
      uStack_1b8 = 1;
      (**(code **)(*(longlong *)auStack_68._8_8_ + 0x28))(auStack_68._8_8_,uStack_30,1,aiStack_180);
      uStack_1b0 = (undefined8 *)lStack_a8;
      uStack_1b8 = uStack_38;
      (**(code **)(*(longlong *)auStack_88._8_8_ + 0x18))(auStack_88._8_8_,0,1);
      auStack_188[0] = 0;
      uVar9 = uVar7;
      if (((lStack_a8 != 0) && (lStack_48 != 0)) && (uStack_40 != 0)) {
        uVar5 = func_0x(&lStack_a8,0x1a20bb8,auStack_188);
        uVar10 = uVar7;
        if (((lStack_48 != 0) && (uVar5 - 1 < 0xfffffffe)) && (uVar10 = 0, uStack_40 != 0)) {
          do {
            if (*(ulonglong *)(uVar7 * 0x58 + lStack_48) == (ulonglong)uVar5) {
              uVar10 = uVar7 * 0x58 + lStack_48;
              if (uVar10 != 0) goto LAB_;
              break;
            }
            uVar8 = (int)uVar7 + 1;
            uVar7 = (ulonglong)uVar8;
          } while (uVar8 < uStack_40);
        }
        uStack_1b8 = CONCAT44(uStack_1b8._4_4_,iStack_90);
        (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
        uVar9 = *(ulonglong *)(lStack_a8 + *(longlong *)(uVar10 + 0x10));
        uVar7 = *(longlong *)(uVar10 + 8) + lStack_a8;
        if (4 < uVar9) goto LAB_;
      }
      func_0x(auStack_178,uVar7,uVar9);
    }
LAB_:
    func_0x(&lStack_a8);
  }
  func_0x(&uStack_170,0);
  if ((int)uStack_170 != 0) {
    func_0x(&uStack_170,0);
  }
LAB_:
  func_0x(uStack_28 ^ (ulonglong)auStack_1d8);
  return;
}

