
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_(short *param_1,int param_2,undefined8 param_3,uint *param_4)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  bool bVar4;
  bool bVar5;
  byte bVar6;
  char cVar7;
  ushort uVar8;
  ushort uVar9;
  int iVar10;
  longlong lVar11;
  undefined8 uVar12;
  uint *puVar13;
  short sVar14;
  uint uVar15;
  ulonglong uVar16;
  uint uVar17;
  ulonglong uVar18;
  byte *pbVar19;
  ulonglong uVar20;
  uint uVar21;
  ushort *puVar22;
  uint *puVar23;
  uint auStackX_8 [2];
  uint auStackX_10 [2];
  undefined8 uStackX_18;
  uint *puStackX_20;
  ulonglong in_stack_ffffffffffffff78;
  uint *puVar24;
  undefined auStack_68 [8];
  undefined auStack_60 [8];
  uint uStack_58;
  ushort uStack_54;
  ushort uStack_52;
  uint *puStack_50;
  
  puVar23 = (uint *)0x0;
  puVar24 = (uint *)(in_stack_ffffffffffffff78 & 0xffffffff00000000);
  uStackX_18 = param_3;
  puStackX_20 = param_4;
  func_0x(&uStack_58,-param_2,param_2,0,puVar24);
  puVar1 = (ushort *)(param_1 + 1);
  if (*param_1 != 0) {
    puVar24 = auStackX_8;
    auStackX_8[0] = 0;
    puVar13 = (uint *)func_0x(puVar1,&uStack_58);
    if ((((*param_1 != 0) && (plVar2 = *(longlong **)(param_1 + 8), plVar2 != (longlong *)0x0)) &&
        (*plVar2 != 0)) && (((uStack_52 & 8) == 0 && ((auStackX_8[0] & 1) == 0)))) {
      if ((puVar13 == (uint *)0x0) || (puVar13 == (uint *)0x11225e0)) {
        auStackX_10[0] = 0;
        puVar13 = puVar23;
      }
      else {
        puVar24 = (uint *)0x0;
        puVar13 = (uint *)func_0x
                                    (plVar2,&uStack_58,puVar13,auStackX_10[0],0,0,auStackX_10,
                                     auStackX_8[0]);
      }
    }
    goto LAB_;
  }
  if ((uStack_58 & 0xc0000000) == 0x80000000) {
    iVar10 = func_0x(puVar1);
    if (iVar10 == 0) {
      auStackX_10[0] = 0;
      puVar13 = (uint *)0x0;
    }
    else {
      puVar13 = (uint *)func_0x(param_1 + 0x15,&uStack_58,auStackX_10,auStack_68);
    }
    goto LAB_;
  }
  pbVar19 = *(byte **)(param_1 + 4);
  bVar4 = true;
  bVar6 = *pbVar19;
  bVar5 = false;
  if ((bVar6 & 0x10) == 0) {
    if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
      uVar8 = ~(uStack_52 >> 4);
      bVar4 = bVar5;
      goto LAB_;
    }
  }
  else {
    uVar15 = *(uint *)(param_1 + 8);
    if ((int)uStack_58 < (int)uVar15) {
      if ((uint)*(ushort *)(pbVar19 + uVar15) < (uint)uStack_54) {
        uVar8 = ~(uStack_52 >> 4);
        bVar4 = bVar5;
      }
      else {
        uVar17 = uStack_54 - 1;
        uVar8 = (ushort)(pbVar19[(ulonglong)uVar15 + (ulonglong)(uVar17 >> 3) + 2] >>
                        ((byte)uVar17 & 7));
      }
    }
    else {
      uVar8 = ~(uStack_52 >> 4);
      bVar4 = bVar5;
    }
LAB_:
    if ((uVar8 & 1) != 0) {
      auStackX_10[0] = 0;
      puVar13 = puVar23;
      goto LAB_;
    }
    if ((!bVar4) && ((uStack_52 & 0x10) != 0)) {
      auStackX_10[0] = *puStack_50;
      puVar13 = puStack_50 + 1;
      goto LAB_;
    }
  }
  if (-1 < (int)uStack_58) {
    if ((uStack_52 & 8) != 0) {
      auStackX_10[0] = 1;
      puVar13 = (uint *)0x11225e0;
      if ((pbVar19[(int)uStack_58] & (byte)(1 << ((byte)uStack_52 & 7))) == 0) {
        puVar13 = (uint *)0x11225e1;
      }
      goto LAB_;
    }
    if ((uStack_52 & 0x10) != 0) {
      if ((bVar6 & 0x10) == 0) {
        if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
          auStackX_10[0] = *puStack_50;
          puVar13 = puStack_50 + 1;
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_58) ||
              (*(ushort *)(pbVar19 + *(uint *)(param_1 + 8)) < uStack_54)) goto LAB_;
    }
    auStackX_10[0] = 0;
    puVar13 = (uint *)(pbVar19 + (int)uStack_58);
    goto LAB_;
  }
  if (*(int *)(param_1 + 2) == 0) {
    uVar15 = *(uint *)(param_1 + 8);
    uVar16 = (ulonglong)uVar15;
    *(uint *)(param_1 + 10) = uVar15;
    *puVar1 = 0;
    bVar6 = *pbVar19;
    if ((bVar6 & 0x10) != 0) {
      uVar15 = uVar15 + 2 + (*(ushort *)(pbVar19 + uVar16) + 7 >> 3);
      uVar16 = (ulonglong)uVar15;
      *(uint *)(param_1 + 10) = uVar15;
      bVar6 = *pbVar19;
    }
    if ((bVar6 & 0x20) == 0) {
      *(int *)(param_1 + 2) = (int)uVar16;
      param_1[0xe] = 0;
      *(int *)(param_1 + 0xc) = (int)uVar16;
    }
    else {
      puVar22 = (ushort *)(pbVar19 + uVar16);
      uVar8 = *puVar22;
      param_1[0xe] = uVar8;
      if (uVar8 == 0) {
        cVar7 = func_0x(0x1aadf40);
        if (((cVar7 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
           (*(char *)(lVar11 + 0x499) != '\0')) {
          cVar7 = func_0x(0x1aadf40);
          if (cVar7 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            puVar24 = (uint *)0x0;
            (*_DAT_)(1,0x139d94c,0x14bda38,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),3);
        uVar16 = (ulonglong)*(uint *)(param_1 + 10);
        uVar8 = param_1[0xe];
      }
      uVar15 = (int)uVar16 + (uVar8 + 1) * 2;
      *(uint *)(param_1 + 0xc) = uVar15;
      if (0x1f9e < uVar15) {
        cVar7 = func_0x(0x1aadf40);
        if (((cVar7 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
           (*(char *)(lVar11 + 0x499) != '\0')) {
          cVar7 = func_0x(0x1aadf40);
          if (cVar7 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puVar24 = (uint *)0x0;
            (*_DAT_)(1,0x139d94c,0x14bda38,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar8 = param_1[0xe];
        uVar15 = *(uint *)(param_1 + 0xc);
      }
      uVar16 = (ulonglong)uVar8;
      uVar8 = puVar22[uVar16];
      *(uint *)(param_1 + 2) = uVar8 & 0x7fff;
      if ((uVar8 & 0x7fff) < uVar15) {
        cVar7 = func_0x(0x1aadf40);
        if (((cVar7 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
           (*(char *)(lVar11 + 0x499) != '\0')) {
          cVar7 = func_0x(0x1aadf40);
          if (cVar7 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puVar24 = (uint *)0x0;
            (*_DAT_)(1,0x139d94c,0x14bda38,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),4);
        uVar15 = *(uint *)(param_1 + 0xc);
        uVar16 = (ulonglong)(ushort)param_1[0xe];
      }
      puVar13 = puVar23;
      puVar3 = puVar22;
      if ((short)uVar16 != 0) {
        do {
          uVar17 = puVar3[1] & 0x7fff;
          if ((uVar17 < uVar15) || (*(uint *)(param_1 + 2) < uVar17)) {
            cVar7 = func_0x(0x1aadf40);
            if ((cVar7 != '\0') &&
               ((lVar11 = func_0x(), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x1aadf40);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                puVar24 = (uint *)0x0;
                (*_DAT_)(1,0x139d94c,0x14bda38,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 4),4);
          }
          uVar16 = (ulonglong)(ushort)param_1[0xe];
          uVar21 = (int)puVar13 + 1;
          puVar13 = (uint *)(ulonglong)uVar21;
          puVar3 = puVar3 + 1;
          uVar15 = uVar17;
        } while ((int)uVar21 < (int)(uint)(ushort)param_1[0xe]);
      }
      if ((short)puVar22[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
        pbVar19 = *(byte **)(param_1 + 4);
        do {
          uVar15 = *(ushort *)(pbVar19 + uVar16 * 2 + (ulonglong)*(uint *)(param_1 + 10)) & 0x7fff;
          if ((int)uVar16 == 1) {
            uVar17 = *(uint *)(param_1 + 0xc);
            uVar21 = uVar17;
LAB_:
            if ((uVar15 < uVar17) || (*(uint *)(param_1 + 2) < uVar15)) goto LAB_;
          }
          else {
            uVar21 = *(uint *)(param_1 + 0xc);
            uVar17 = *(ushort *)(pbVar19 + uVar16 * 2 + ((ulonglong)*(uint *)(param_1 + 10) - 2)) &
                     0x7fff;
            if (uVar21 <= uVar17) goto LAB_;
LAB_:
            func_0x(pbVar19,7);
            uVar21 = *(uint *)(param_1 + 0xc);
          }
          if ((uVar17 < uVar21) || (*(uint *)(param_1 + 2) < uVar17)) goto LAB_;
          pbVar19 = *(byte **)(param_1 + 4);
          if (*(ushort *)(pbVar19 + uVar17) == 5) {
            *puVar1 = *puVar1 | 2;
            param_1[0xe] = param_1[0xe] + -1;
            uVar20 = (ulonglong)(uVar17 & 0xffff);
            param_1[0x15] = (short)uVar17;
            uVar16 = *(ulonglong *)(param_1 + 4);
            uVar8 = param_1[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar20 + 2 + uVar16) >> 0xe & 1) != 0) {
              uVar8 = *(ushort *)(uVar20 + 2 + uVar16) & 0x3800 | param_1[0x16] & 0xc7ffU;
            }
            param_1[0x16] = uVar8;
            uVar9 = (uVar8 ^ *(ushort *)(uVar20 + 2 + uVar16)) & 0x7ff ^ uVar8;
            param_1[0x16] = uVar9;
            uVar18 = (ulonglong)((uVar9 & 0x7ff) * 2) + 4 + uVar16 + (uVar8 >> 0xb & 7) * 2 + uVar20
            ;
            if (uVar18 < uVar20 + uVar16) {
              func_0x(uVar20 + uVar16,0x19);
              uVar9 = param_1[0x16];
              uVar20 = (ulonglong)(ushort)param_1[0x15];
              uVar16 = (ulonglong)*(uint *)(param_1 + 4);
            }
            if (uVar15 - uVar17 < (((uVar9 & 0x7ff) * 2 - (int)uVar20) - (int)uVar16) + (int)uVar18)
            {
              func_0x(uVar20 + *(longlong *)(param_1 + 4),0x19);
              uVar9 = param_1[0x16];
            }
            if (((uVar9 & 0x3800) != 0) &&
               (puVar22 = (ushort *)
                          (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
               (uVar9 & 0x3800) != 0)) {
              do {
                if ((uVar9 & 0x7ff) < (*puVar22 & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),0x1a
                                 );
                  uVar9 = param_1[0x16];
                }
                uVar15 = (int)puVar23 + 1;
                puVar23 = (uint *)(ulonglong)uVar15;
                puVar22 = puVar22 + 1;
              } while ((int)uVar15 < (int)(uVar9 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar19 + uVar17) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar8 = param_1[0xe] - 1;
          param_1[0xe] = uVar8;
          if (uVar8 == 0) goto LAB_;
          uVar16 = (ulonglong)uVar8;
        } while ((short)puVar22[(ulonglong)(uVar8 - 1) + 1] < 0);
        uVar16 = (ulonglong)*(uint *)(param_1 + 2);
      }
      else {
LAB_:
        pbVar19 = *(byte **)(param_1 + 4);
        uVar16 = (ulonglong)*(uint *)(param_1 + 2);
      }
    }
    if ((*pbVar19 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x13) = 0;
    }
    else {
      *(int *)(param_1 + 0x13) = (int)uVar16;
      *(int *)(param_1 + 2) = (int)uVar16 + 0xe;
      uVar12 = func_0x(puVar1);
      func_0x(uVar12,auStack_60);
      iVar10 = func_0x(auStack_60);
      *(int *)(param_1 + 2) = *(int *)(param_1 + 2) + iVar10;
      uVar16 = (ulonglong)*(uint *)(param_1 + 2);
    }
    iVar10 = (int)uVar16;
    if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
       (*(ulonglong *)(param_1 + 0xf) < uVar16 + *(longlong *)(param_1 + 4))) {
      cVar7 = func_0x(0x1aadf40);
      if ((cVar7 != '\0') &&
         ((lVar11 = func_0x(), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))))
      {
        cVar7 = func_0x(0x1aadf40);
        if (cVar7 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          puVar24 = (uint *)0x0;
          (*_DAT_)(1,0x139d94c,0x14bda38,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),0x12);
      iVar10 = *(int *)(param_1 + 2);
    }
    if (0x3f3b < iVar10 - 1U) {
      cVar7 = func_0x(0x1aadf40);
      if (((cVar7 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
         (*(char *)(lVar11 + 0x499) != '\0')) {
        cVar7 = func_0x(0x1aadf40);
        if (cVar7 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          puVar24 = (uint *)0x0;
          (*_DAT_)(1,0x139d94c,0x14bda38,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 4),5);
    }
  }
LAB_:
  sVar14 = -(short)uStack_58;
  param_4 = puStackX_20;
  param_3 = uStackX_18;
  if ((uStack_52 & 0x10) != 0) {
    bVar6 = **(byte **)(param_1 + 4);
    if ((bVar6 & 0x10) == 0) {
      if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
        auStackX_10[0] = *puStack_50;
        puVar13 = puStack_50 + 1;
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(param_1 + 8) <= (int)uStack_58) ||
            (*(ushort *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 8)) < uStack_54))
    goto LAB_;
  }
  puVar13 = *(uint **)(param_1 + 4);
  lVar11 = (longlong)sVar14;
  if ((uint)(ushort)param_1[0xe] < (uint)(int)sVar14) {
    auStackX_10[0] = 0;
    goto LAB_;
  }
  uVar15 = *(uint *)(param_1 + 10);
  if (sVar14 == 1) {
    uVar17 = *(uint *)(param_1 + 0xc);
    uVar15 = *(ushort *)((longlong)puVar13 + lVar11 * 2 + (ulonglong)uVar15) & 0x7fff;
LAB_:
    if ((uVar15 < uVar17) || (*(uint *)(param_1 + 2) < uVar15)) goto LAB_;
  }
  else {
    puVar1 = (ushort *)((longlong)puVar13 + lVar11 * 2 + (ulonglong)uVar15);
    uVar17 = *(ushort *)((longlong)puVar13 + lVar11 * 2 + ((ulonglong)uVar15 - 2)) & 0x7fff;
    puVar13 = *(uint **)(param_1 + 4);
    uVar15 = *puVar1 & 0x7fff;
    if (*(uint *)(param_1 + 0xc) <= uVar17) goto LAB_;
LAB_:
    func_0x(puVar13,7);
    puVar13 = *(uint **)(param_1 + 4);
  }
  auStackX_10[0] = uVar15 - uVar17;
  param_4 = puStackX_20;
  puVar13 = (uint *)((longlong)puVar13 + (ulonglong)uVar17);
  param_3 = uStackX_18;
LAB_:
  if (puVar13 == (uint *)0x0) {
    return 0x58d;
  }
  if (auStackX_10[0] <= *param_4) {
    func_0x(param_3,(longlong)(int)*param_4,puVar13,auStackX_10[0],puVar24);
    *param_4 = auStackX_10[0];
    return 0;
  }
  *param_4 = auStackX_10[0];
  return 0xea;
}

