
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,undefined8 param_2)

{
  byte *pbVar1;
  longlong lVar2;
  uint **ppuVar3;
  char cVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  uint *puVar11;
  short *psVar12;
  undefined8 uVar13;
  ulonglong *puVar14;
  ushort uVar15;
  ushort uVar16;
  ulonglong uVar17;
  undefined4 uVar18;
  uint uVar19;
  byte **ppbVar20;
  byte *pbVar21;
  ulonglong uVar22;
  byte *pbVar23;
  ulonglong uVar24;
  longlong lVar25;
  short sVar26;
  ulonglong uVar27;
  ushort *puVar28;
  longlong *plVar29;
  uint uVar30;
  longlong unaff_GS_OFFSET;
  undefined auStack_548 [32];
  undefined8 uStack_528;
  uint *puStack_520;
  longlong *plStack_518;
  undefined uStack_510;
  uint uStack_50c;
  uint uStack_508;
  uint uStack_500;
  int iStack_4fc;
  short sStack_4f8;
  undefined8 uStack_4f0;
  undefined4 uStack_4e8;
  longlong *plStack_4e0;
  uint auStack_4d8 [2];
  undefined8 uStack_4d0;
  undefined8 uStack_4c8;
  ushort uStack_4c0;
  undefined8 uStack_4b8;
  ushort uStack_4b0;
  undefined8 uStack_4a8;
  undefined2 uStack_4a0;
  undefined auStack_498 [4];
  undefined4 uStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined2 uStack_488;
  undefined4 uStack_484;
  undefined2 uStack_480;
  undefined4 uStack_47c;
  undefined2 uStack_478;
  undefined4 uStack_474;
  undefined2 uStack_470;
  undefined8 uStack_468;
  undefined2 uStack_460;
  undefined8 uStack_458;
  undefined2 uStack_450;
  ushort *puStack_448;
  ushort uStack_440;
  undefined auStack_438 [4];
  undefined auStack_434 [4];
  undefined auStack_430 [4];
  undefined auStack_42c [4];
  undefined auStack_428 [8];
  uint uStack_420;
  undefined8 uStack_41c;
  undefined8 uStack_408;
  undefined auStack_3f8 [8];
  undefined4 uStack_3f0;
  undefined4 uStack_3e8;
  uint **ppuStack_3e0;
  undefined *puStack_3d8;
  undefined8 uStack_3d0;
  uint *puStack_3c8;
  undefined4 uStack_3c0;
  undefined4 uStack_3bc;
  longlong lStack_3b8;
  undefined4 uStack_3b0;
  undefined4 uStack_3ac;
  longlong lStack_3a8;
  undefined4 uStack_3a0;
  undefined4 uStack_39c;
  short *psStack_398;
  int iStack_390;
  undefined4 uStack_38c;
  short *psStack_388;
  int iStack_380;
  undefined4 uStack_37c;
  undefined8 uStack_378;
  undefined4 uStack_370;
  undefined4 uStack_36c;
  undefined auStack_368 [448];
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  uint uStack_198;
  short sStack_194;
  int iStack_192;
  undefined uStack_18e;
  undefined uStack_18d;
  short sStack_158;
  ushort uStack_156;
  uint uStack_154;
  byte *pbStack_150;
  undefined8 uStack_148;
  undefined4 uStack_140;
  ushort uStack_13c;
  undefined2 uStack_13a;
  undefined6 uStack_138;
  undefined2 uStack_132;
  undefined2 uStack_130;
  ushort uStack_12e;
  ushort uStack_12c;
  undefined2 uStack_12a;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined auStack_120 [16];
  undefined auStack_110 [4];
  undefined4 uStack_10c;
  undefined8 uStack_108;
  byte **ppbStack_100;
  undefined6 uStack_f8;
  undefined2 uStack_f2;
  undefined6 uStack_f0;
  undefined2 uStack_ea;
  byte **ppbStack_e8;
  undefined auStack_e0 [16];
  undefined auStack_d0 [16];
  undefined auStack_c0 [16];
  longlong lStack_b0;
  short asStack_a8 [24];
  short asStack_78 [24];
  ulonglong uStack_48;
  
  uStack_408 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)auStack_548;
  lVar9 = 0;
  plStack_518 = (longlong *)0x0;
  uStack_510 = 0;
  uStack_50c = 0;
  sStack_158 = -1;
  pbStack_150 = (byte *)0x0;
  uStack_154 = 0;
  uStack_13a = 0;
  uStack_138 = 0;
  uStack_130 = 0;
  uStack_12e = 0;
  uStack_12c = 0;
  uStack_12a = 0;
  uStack_148 = (byte **)0x0;
  uStack_124 = 0xffffffff;
  uStack_490 = 0;
  plStack_4e0 = param_1;
  uStack_4d0 = param_2;
  if ((*(byte *)(*param_1 + 0x7c) & 1) == 0) {
LAB_:
    func_0x(&plStack_518);
    func_0x(uStack_48 ^ (ulonglong)auStack_548);
    return;
  }
  iStack_4fc = 0;
  sStack_4f8 = 2;
  lVar10 = param_1[1];
  uStack_41c = 0;
  if ((((*_DAT_ != '\0') && ((DAT_ & 0x80) == 0)) &&
      ((lVar2 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)),
       lVar2 == 0 ||
       ((lVar2 = **(longlong **)(lVar2 + 0x38), lVar2 == 0 ||
        (iVar6 = (*_DAT_)(lVar2,0x337), iVar6 == 0)))))) &&
     (lVar2 = *(longlong *)
               ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
               + 8), lVar2 != 0)) {
    lVar9 = *(longlong *)(lVar2 + 0x60);
  }
  lVar2 = *(longlong *)(lVar10 + 0x728);
  do {
    plVar29 = plStack_518;
    auStack_4d8[0] = 0;
    if (plStack_518 != (longlong *)0x0) {
      iVar6 = (int)(short)uStack_50c;
      if (((*(ushort *)((longlong)plStack_518 + 0x62) & 0x400) == 0) || (iVar6 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_518 + 0x62) >> 3 & 1) != 0) {
          if (iVar6 == 3) {
            iVar6 = 4;
          }
          else if (iVar6 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_518 + 100) & 8) != 0) &&
              (lVar25 = plStack_518[0x12], lVar25 != 0)) && (*(longlong *)(lVar25 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar25 + 0x758),plStack_518,iVar6);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
            ((2 < iVar6 &&
             (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 && (*plVar29 != 0))))
            )) && (iVar8 = (*_DAT_)(*plVar29,0x2000,2,auStack_438), iVar8 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar29 + 0x13,iVar6);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar29,0,iVar6);
        }
        uStack_50c = uStack_50c & 0xffff0000;
        plStack_518 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_518);
      }
    }
    if ((*(longlong *)(lVar10 + 0x728) != 0) &&
       (func_0x(&plStack_518,&iStack_4fc,lVar10), plVar29 = plStack_518,
       plStack_518 != (longlong *)0x0)) {
      iVar6 = (int)(short)uStack_50c;
      if (((*(ushort *)((longlong)plStack_518 + 0x62) & 0x400) == 0) || (iVar6 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_518 + 0x62) >> 3 & 1) != 0) {
          if (iVar6 == 3) {
            iVar6 = 4;
          }
          else if (iVar6 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_518 + 100) & 8) != 0) &&
              (lVar25 = plStack_518[0x12], lVar25 != 0)) && (*(longlong *)(lVar25 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar25 + 0x758),plStack_518,iVar6);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
            ((2 < iVar6 &&
             (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 && (*plVar29 != 0))))
            )) && (iVar8 = (*_DAT_)(*plVar29,0x2000,2,auStack_434), iVar8 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar29 + 0x13,iVar6);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar29,0,iVar6);
        }
        uStack_50c = uStack_50c & 0xffff0000;
        plStack_518 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_518);
      }
    }
    puStack_520 = &uStack_420;
    uStack_528 = CONCAT44(uStack_528._4_4_,2);
    plStack_518 = (longlong *)func_0x(_DAT_,lVar10,&iStack_4fc,auStack_4d8);
    if (lVar9 != 0) {
      uVar27 = (ulonglong)(*(uint *)(lVar9 + 0x500) & 0xf);
      if (*(longlong *)(lVar9 + 0x508 + uVar27 * 8) != *plStack_518) {
        *(longlong *)(lVar9 + 0x508 + uVar27 * 8) = *plStack_518;
        *(longlong *)(lVar9 + 0x500) = *(longlong *)(lVar9 + 0x500) + 1;
      }
    }
    uStack_50c = (auStack_4d8[0] >> 3 & 1) << 0x18 | uStack_50c & 0xff0002 | 2;
    uStack_508 = auStack_4d8[0] >> 4 & 1 | uStack_508 & 0xffffff00;
    if (((lVar2 != 0) && (lVar9 != 0)) && (lVar9 == *(longlong *)(lVar10 + 0x1c38))) {
      *(longlong *)(lVar2 + 0x5b28) = *(longlong *)(lVar2 + 0x5b28) + 1;
      if ((int)uStack_41c != 0) {
        *(longlong *)(lVar2 + 0x5b30) = *(longlong *)(lVar2 + 0x5b30) + 1;
        *(longlong *)(lVar2 + 0x5b38) = *(longlong *)(lVar2 + 0x5b38) + (ulonglong)uStack_420;
        if (0xffffff < uStack_50c) {
          *(longlong *)(lVar2 + 0x5b40) = *(longlong *)(lVar2 + 0x5b40) + 1;
          *(longlong *)(lVar2 + 0x5b48) = *(longlong *)(lVar2 + 0x5b48) + (ulonglong)uStack_420;
        }
      }
    }
    cVar4 = func_0x(lVar10);
    uStack_500 = 9;
    if (((cVar4 == '\0') || (*(char *)(lVar10 + 0x2050) == '\0')) ||
       ((iStack_4fc == 0 || ((iStack_4fc == 9 && (sStack_4f8 == 1)))))) goto LAB_;
    lVar25 = *plStack_518;
    if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
      uStack_4b8 = *(undefined8 *)(lVar25 + 0x28);
      uStack_4b0 = *(ushort *)(lVar25 + 0x30);
    }
    else {
      cVar4 = *(char *)(lVar25 + 1);
      if (cVar4 == '\v') {
        if (*(int *)(lVar25 + 0x18) != 99) {
LAB_:
          if (cVar4 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar4 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar25 + 0x18) != 99) goto LAB_;
      }
      uStack_48c = *(undefined4 *)(lVar25 + 0x20);
      uStack_488 = *(undefined2 *)(lVar25 + 0x24);
      cVar4 = func_0x(&uStack_48c);
      if (cVar4 == '\0') goto LAB_;
      func_0x(lVar25,&uStack_4b8);
    }
    uVar19 = *(uint *)(lVar10 + 0x2108);
    do {
      uVar7 = uVar19 & 0xfffffffe;
      uStack_4f0 = *(ushort **)(lVar10 + 0x20fc);
      uStack_4e8 = *(undefined4 *)(lVar10 + 0x2104);
      LOCK();
      UNLOCK();
      uVar19 = *(uint *)(lVar10 + 0x2108);
    } while (uVar7 != uVar19);
    if ((uint)uStack_4b8 <= (uint)uStack_4f0) {
      if ((uint)uStack_4f0 != (uint)uStack_4b8) goto LAB_;
      uVar19 = (uint)((ulonglong)uStack_4f0 >> 0x20);
      if ((uStack_4b8._4_4_ <= uVar19) &&
         ((uVar19 != uStack_4b8._4_4_ || (uStack_4b0 <= (ushort)uStack_4e8)))) goto LAB_;
    }
    if ((*(char *)(lVar10 + 0x6ac8) == '\0') &&
       ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) != *(longlong *)(lVar10 + 0x2120) &&
        (cVar4 = func_0x(lVar10), cVar4 == '\0')))) break;
    if ((*(longlong *)
          (*(longlong *)
            ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8) +
            8) + 0x60) == *(longlong *)(lVar10 + 0x2120)) ||
       (cVar4 = func_0x(lVar10), cVar4 != '\0')) goto LAB_;
    if (lVar9 == 0) {
      lVar9 = func_0x();
    }
    lVar25 = *plStack_518;
    if (*(short *)(lVar25 + 0x24) == 0) {
LAB_:
      uStack_468 = *(undefined8 *)(lVar25 + 0x28);
      uStack_460 = *(undefined2 *)(lVar25 + 0x30);
    }
    else {
      cVar4 = *(char *)(lVar25 + 1);
      if (cVar4 == '\v') {
        if (*(int *)(lVar25 + 0x18) != 99) {
LAB_:
          if (cVar4 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar4 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar25 + 0x18) != 99) goto LAB_;
      }
      uStack_484 = *(undefined4 *)(lVar25 + 0x20);
      uStack_480 = *(undefined2 *)(lVar25 + 0x24);
      cVar4 = func_0x(&uStack_484);
      if (cVar4 == '\0') goto LAB_;
      func_0x(lVar25,&uStack_468);
    }
    plVar29 = plStack_518;
    if (plStack_518 != (longlong *)0x0) {
      iVar6 = (int)(short)uStack_50c;
      if (((*(ushort *)((longlong)plStack_518 + 0x62) & 0x400) == 0) || (iVar6 < 3)) {
        if (((byte)*(undefined2 *)((longlong)plStack_518 + 0x62) >> 3 & 1) != 0) {
          if (iVar6 == 3) {
            iVar6 = 4;
          }
          else if (iVar6 < 2) goto LAB_;
          if ((((*(uint *)((longlong)plStack_518 + 100) & 8) != 0) &&
              (lVar25 = plStack_518[0x12], lVar25 != 0)) && (*(longlong *)(lVar25 + 0x758) != 0)) {
            func_0x(*(undefined8 *)(lVar25 + 0x758),plStack_518,iVar6);
          }
        }
LAB_:
        if (((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
            ((2 < iVar6 &&
             (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 && (*plVar29 != 0))))
            )) && (iVar8 = (*_DAT_)(*plVar29,0x2000,2,auStack_430), iVar8 != 0)) {
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) & 0x3fffffff;
          UNLOCK();
          LOCK();
          *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) | 0x40000000;
          UNLOCK();
        }
        func_0x(plVar29 + 0x13,iVar6);
        if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
          func_0x(plVar29,0,iVar6);
        }
        uStack_50c = uStack_50c & 0xffff0000;
        plStack_518 = (longlong *)0x0;
      }
      else {
        func_0x(&plStack_518);
      }
    }
    uStack_458 = uStack_468;
    uStack_450 = uStack_460;
    uStack_528 = 0;
    func_0x(*(undefined8 *)(lVar10 + 0x728),&uStack_458,4);
  } while( true );
  uVar19 = *(uint *)(lVar10 + 0x2108);
  do {
    uVar7 = uVar19 & 0xfffffffe;
    uStack_4f0 = *(ushort **)(lVar10 + 0x20fc);
    uStack_4e8 = *(undefined4 *)(lVar10 + 0x2104);
    LOCK();
    UNLOCK();
    uVar19 = *(uint *)(lVar10 + 0x2108);
  } while (uVar7 != uVar19);
  uVar15 = (ushort)uStack_4e8;
  uStack_440 = (ushort)uStack_4e8;
  lVar9 = *plStack_518;
  puStack_448 = uStack_4f0;
  if (*(short *)(lVar9 + 0x24) == 0) {
LAB_:
    uStack_4c8 = *(undefined8 *)(lVar9 + 0x28);
    uStack_4c0 = *(ushort *)(lVar9 + 0x30);
  }
  else {
    cVar4 = *(char *)(lVar9 + 1);
    if (cVar4 == '\v') {
      if (*(int *)(lVar9 + 0x18) != 99) {
LAB_:
        if (cVar4 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar4 != '\b') goto LAB_;
LAB_:
      if (*(int *)(lVar9 + 0x18) != 99) goto LAB_;
    }
    uStack_47c = *(undefined4 *)(lVar9 + 0x20);
    uStack_478 = *(undefined2 *)(lVar9 + 0x24);
    cVar4 = func_0x(&uStack_47c);
    if (cVar4 == '\0') goto LAB_;
    func_0x(lVar9,&uStack_4c8);
  }
  if ((uint)uStack_4f0 < (uint)uStack_4c8) {
LAB_:
    lVar9 = *(longlong *)(lVar10 + 0x6b0);
    func_0x(&uStack_4c8,asStack_a8,auStack_498);
    func_0x(&puStack_448,asStack_78,auStack_498);
    if ((_DAT_ & 0x10000) != 0) {
      uStack_3f0 = 0x60000;
      iVar6 = 0;
      uStack_3e8 = 0;
      ppuStack_3e0 = &puStack_3c8;
      puStack_3d8 = auStack_368;
      uStack_1a8 = 0;
      uStack_3d0 = 0;
      uStack_1a0 = 0;
      puStack_3c8 = &uStack_198;
      uStack_3c0 = 0x34;
      uStack_3bc = 5;
      uStack_3b0 = 0x10;
      uStack_3ac = 5;
      uStack_3a0 = 0x10;
      uStack_39c = 6;
      uStack_38c = 7;
      uStack_37c = 8;
      uStack_378 = 0;
      uStack_370 = 0;
      uStack_36c = 9;
      uStack_198 = (uint)*(ushort *)(lVar10 + 0x6b8);
      sStack_194 = sStack_4f8;
      iStack_192 = iStack_4fc;
      uStack_18e = 0xff;
      uStack_18d = *(undefined *)(*plStack_518 + 1);
      lStack_3b8 = lVar9 + 0x254;
      lStack_3a8 = lVar9 + 0x244;
      lVar10 = -1;
      do {
        lVar10 = lVar10 + 1;
      } while (asStack_a8[lVar10] != 0);
      iStack_390 = (int)lVar10 * 2;
      psStack_398 = asStack_a8;
      lVar10 = -1;
      do {
        lVar10 = lVar10 + 1;
      } while (asStack_78[lVar10] != 0);
      iStack_380 = (int)lVar10 * 2;
      psStack_388 = asStack_78;
      uStack_494 = 0;
      puVar11 = (uint *)(**(code **)(_DAT_ + 0x10))(lVar9,&uStack_494);
      ppuVar3 = ppuStack_3e0;
      if (puVar11 != (uint *)0x0) {
        lVar9 = -1;
        do {
          lVar9 = lVar9 + 1;
        } while (*(short *)((longlong)puVar11 + lVar9 * 2) != 0);
        iVar6 = (int)lVar9 * 2;
      }
      ppuStack_3e0[10] = puVar11;
      *(int *)(ppuVar3 + 0xb) = iVar6;
      *(undefined4 *)((longlong)ppuVar3 + 0x5c) = 9;
      func_0x(auStack_3f8);
    }
  }
  else if ((uint)uStack_4f0 == (uint)uStack_4c8) {
    uVar19 = (uint)((ulonglong)uStack_4c8 >> 0x20);
    if ((uStack_4f0._4_4_ < uVar19) || ((uStack_4f0._4_4_ == uVar19 && (uVar15 < uStack_4c0))))
    goto LAB_;
  }
LAB_:
  lVar9 = *plStack_518;
  uStack_140 = CONCAT22(uStack_140._2_2_,(undefined2)uStack_140);
  if ((1 < *(ushort *)(lVar9 + 0x16)) &&
     (uStack_140 = CONCAT22(uStack_140._2_2_,(undefined2)uStack_140),
     *(short *)(lVar9 + 0x1ffc) != 0)) {
    uStack_124 = 1;
    uVar18 = 0xf;
    uVar19 = 0xf;
    if (*(char *)(lVar9 + 2) < '\0') {
      pbVar23 = (byte *)(lVar9 + 0x60);
      ppbVar20 = (byte **)0x0;
      if ((sStack_158 == 0) || (ppbVar20 = uStack_148, uStack_148 == (byte **)0x0)) {
        uStack_f8 = 0;
        uStack_ea = 0;
        auStack_d0 = ZEXT816(0);
        auStack_120 = ZEXT816(0);
        stack0xfffffffffffffef2 = SUB1614(ZEXT816(0),2);
        auStack_110._0_2_ = 0xffff;
        uStack_10c = (int)ppbVar20;
        uStack_108 = ppbVar20;
        uStack_f2 = SUB82(ppbVar20,0);
        uStack_f0 = (undefined6)((ulonglong)ppbVar20 >> 0x10);
        ppbStack_e8 = ppbVar20;
        ppbStack_100 = ppbVar20;
        auStack_e0._8_8_ = 0;
        auStack_e0._0_8_ = ppbVar20;
        auStack_e0 = auStack_e0 << 0x40;
        auStack_c0._0_12_ = ZEXT812(0);
        auStack_c0._12_4_ = 0;
        lStack_b0 = ((ulonglong)ppbVar20 & 0xffff) << 0x10;
        ppbVar20 = (byte **)auStack_120;
      }
      if (*(short *)(lVar9 + 0x24) == 0) {
LAB_:
        uStack_4a8 = *(undefined8 *)(lVar9 + 0x28);
        uStack_4a0 = *(undefined2 *)(lVar9 + 0x30);
      }
      else {
        cVar4 = *(char *)(lVar9 + 1);
        if (cVar4 == '\v') {
          if (*(int *)(lVar9 + 0x18) != 99) {
LAB_:
            if (cVar4 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar4 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar9 + 0x18) != 99) goto LAB_;
        }
        uStack_474 = *(undefined4 *)(lVar9 + 0x20);
        uStack_470 = *(undefined2 *)(lVar9 + 0x24);
        cVar4 = func_0x(&uStack_474);
        if (cVar4 == '\0') goto LAB_;
        func_0x(lVar9,&uStack_4a8);
      }
      *ppbVar20 = pbVar23;
      *(undefined4 *)(ppbVar20 + 0xc) = (undefined4)uStack_4a8;
      *(int *)((longlong)ppbVar20 + 100) = (int)((ulonglong)uStack_4a8 >> 0x20);
      *(undefined2 *)(ppbVar20 + 0xd) = uStack_4a0;
      *(undefined4 *)((longlong)ppbVar20 + 0x6c) = *(undefined4 *)(lVar9 + 0x20);
      *(undefined2 *)(ppbVar20 + 0xe) = *(undefined2 *)(lVar9 + 0x24);
      *(undefined2 *)((longlong)ppbVar20 + 0x72) = 0;
      uStack_4f0 = (ushort *)
                   CONCAT44(uStack_4f0._4_4_,*(undefined4 *)((ulonglong)*pbVar23 * 6 + 0x119d030));
      uVar27 = (ulonglong)*(short *)((ulonglong)*pbVar23 * 6 + 0x119d034);
      *(undefined2 *)(ppbVar20 + 2) = 0xffff;
      ppbVar20[3] = (byte *)0x0;
      uVar7 = 0;
      *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
      ppbVar20[7] = (byte *)0x0;
      ppbVar20[4] = (byte *)0x0;
      ppbVar20[9] = (byte *)0x0;
      ppbVar20[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar20 + 0xb) = 0;
      if ((**ppbVar20 & 2) != 0) {
        pbVar1 = pbVar23 + uVar27;
        if ((*pbVar1 & 1) == 0) {
          *(undefined2 *)(ppbVar20 + 2) = 0;
          ppbVar20[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar20 + 0x36) = 0;
          switch(*pbVar1 & 0xe) {
          default:
            uVar7 = (uint)*(ushort *)(pbVar1 + 2);
            if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
              func_0x(pbVar1,6);
            }
            break;
          case 4:
            uVar7 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar7 = 1;
          }
          *(uint *)(ppbVar20 + 4) = uVar7;
          *(undefined8 *)((longlong)ppbVar20 + 0x2e) = 0;
        }
        else {
          *(undefined2 *)(ppbVar20 + 2) = 1;
          ppbVar20[3] = pbVar1;
          bVar5 = *pbVar1;
          switch(bVar5 & 0x1c) {
          default:
            if ((char)pbVar1[1] < '\0') {
              uVar15 = *(ushort *)(pbVar1 + 1);
              *(ushort *)((longlong)ppbVar20 + 0x12) = uVar15;
              sVar26 = 3;
              uVar15 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
            }
            else {
              sVar26 = 2;
              uVar15 = (ushort)pbVar1[1];
            }
            *(ushort *)((longlong)ppbVar20 + 0x12) = uVar15;
            *(short *)(ppbVar20 + 5) = sVar26;
            uVar15 = *(ushort *)((longlong)ppbVar20 + 0x12);
            *(short *)((longlong)ppbVar20 + 0x2c) = (short)(uVar15 + 1 >> 1) + sVar26;
            if (uVar15 < 0x1f) {
              *(undefined2 *)((longlong)ppbVar20 + 0x2a) = 0;
              *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
              *(undefined4 *)(ppbVar20 + 8) = 0;
              ppbVar20[7] = (byte *)0x0;
              ppbVar20[4] = (byte *)0x0;
            }
            else {
              iVar6 = uVar15 - 1;
              *(short *)((longlong)ppbVar20 + 0x2a) =
                   ((short)(iVar6 / 0x1e) + (short)(iVar6 >> 0x1f)) -
                   (short)((longlong)iVar6 * 0x88888889 >> 0x3f);
              *(undefined4 *)((longlong)ppbVar20 + 0x14) = 0;
              *(undefined4 *)(ppbVar20 + 8) = 0;
              ppbVar20[7] = (byte *)0x0;
              ppbVar20[4] = (byte *)0x0;
            }
            break;
          case 4:
            if (((bVar5 & 0x1c) != 4) || (uVar30 = 1, (bVar5 & 2) == 0)) {
              uVar30 = uVar7;
            }
            if (uVar30 == 0) {
              uVar18 = 1;
            }
            else {
              *(undefined4 *)(ppbVar20 + 8) = 0;
            }
            ppbVar20[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
            ppbVar20[6] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar20 + 0x14) = uVar18;
            *(uint *)(ppbVar20 + 8) = (uint)(uVar30 != 0);
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
            break;
          case 8:
            ppbVar20[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar20 + 0x12) = 0;
            ppbVar20[6] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar20 + 0x14) = 9;
            *(undefined4 *)(ppbVar20 + 8) = 0;
            ppbVar20[7] = (byte *)0x0;
            ppbVar20[4] = (byte *)0x0;
          }
        }
      }
      if ((**ppbVar20 & 4) != 0) {
        if (uStack_4f0._2_2_ != 0) {
          uVar27 = (ulonglong)*(ushort *)(lVar9 + 0x61 + (longlong)uStack_4f0._2_2_ * 2);
        }
        psVar12 = (short *)(pbVar23 + uVar27);
        ppbVar20[9] = (byte *)psVar12;
        sVar26 = *psVar12;
        ppbVar20[10] = (byte *)(psVar12 + 1);
        *(short *)(ppbVar20 + 0xb) = (sVar26 + 1) * 2;
      }
      if (ppbVar20[1] != (byte *)0x0) {
        func_0x(ppbVar20[1],ppbVar20);
      }
    }
    else {
      ppbVar20 = (byte **)0x0;
    }
    uVar7 = (uint)*(ushort *)(lVar9 + 0xe);
    pbStack_150 = (byte *)((ulonglong)*(ushort *)(lVar9 + 0x1ffc) + lVar9);
    if ((*pbStack_150 & 1) == 0) {
      sStack_158 = 0;
      uStack_154 = 0;
      uStack_132 = 0;
      uStack_130 = 0;
      switch(*pbStack_150 & 0xe) {
      default:
        uVar7 = (uint)*(ushort *)(pbStack_150 + 2);
        if (0x1f9d < *(ushort *)(pbStack_150 + 2) - 1) {
          func_0x(pbStack_150,6);
        }
        break;
      case 4:
        uVar7 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar7 = 1;
      }
      uStack_148 = (byte **)CONCAT44(uStack_148._4_4_,uVar7);
      uStack_13a = (undefined2)(lVar9 + 0x2000);
      uStack_138 = (undefined6)((ulonglong)(lVar9 + 0x2000) >> 0x10);
      ppbVar20 = (byte **)(ulonglong)uVar7;
      uVar19 = uStack_154;
    }
    else {
      sStack_158 = 1;
      bVar5 = *pbStack_150;
      switch(bVar5 & 0x1c) {
      default:
        if ((char)pbStack_150[1] < '\0') {
          uStack_156 = (*(ushort *)(pbStack_150 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_150 + 1) >> 8;
          sVar26 = 3;
          uStack_140._0_2_ = 3;
        }
        else {
          uStack_156 = (ushort)pbStack_150[1];
          uStack_140._0_2_ = 2;
          sVar26 = 2;
        }
        uStack_13c = (short)(uStack_156 + 1 >> 1) + sVar26;
        uVar19 = 0;
        if (uStack_156 < 0x1f) {
          uStack_140._2_2_ = 0;
          uStack_154 = 0;
          uStack_128 = 0;
        }
        else {
          uStack_140._2_2_ = (undefined2)((int)(uStack_156 - 1) / 0x1e);
          uStack_154 = 0;
          uStack_128 = 0;
        }
        break;
      case 4:
        if (((bVar5 & 0x1c) == 4) && ((bVar5 & 2) != 0)) {
          uStack_140._0_2_ = 0;
          uStack_140._2_2_ = 0;
          uStack_13c = 0;
          uStack_13a = 0;
          uStack_156 = 0;
          uStack_138 = 0;
          uStack_132 = 0;
          uStack_154 = 0xf;
          uStack_128 = 1;
        }
        else {
          uStack_140._0_2_ = 0;
          uStack_140._2_2_ = 0;
          uStack_13c = 0;
          uStack_13a = 0;
          uStack_156 = 0;
          uStack_138 = 0;
          uStack_132 = 0;
          uVar19 = 1;
          uStack_154 = 1;
          uStack_128 = 0;
        }
        break;
      case 8:
        uStack_140._0_2_ = 0;
        uStack_140._2_2_ = 0;
        uStack_13c = 0;
        uStack_13a = 0;
        uStack_156 = 0;
        uStack_138 = 0;
        uStack_132 = 0;
        uVar19 = 9;
        uStack_154 = 9;
        uStack_128 = 0;
      }
      lVar9 = lVar9 + 0x2000;
      uStack_130 = (undefined2)lVar9;
      uStack_12e = (ushort)((ulonglong)lVar9 >> 0x10);
      uStack_12c = (ushort)((ulonglong)lVar9 >> 0x20);
      uStack_12a = (undefined2)((ulonglong)lVar9 >> 0x30);
      uStack_148 = ppbVar20;
    }
    if (sStack_158 == 0) {
      pbVar23 = pbStack_150;
      uVar7 = uVar19;
      if (uVar19 == 0) {
        uStack_156 = 0;
        uVar19 = (uint)ppbVar20;
        uVar27 = (ulonglong)ppbVar20 & 0xffffffff;
        if ((*pbStack_150 & 0x10) != 0) {
          uVar19 = uVar19 + 2 +
                   (*(ushort *)(pbStack_150 + ((ulonglong)ppbVar20 & 0xffffffff)) + 7 >> 3);
          uVar27 = (ulonglong)uVar19;
        }
        uStack_148 = (byte **)CONCAT44(uVar19,(uint)uStack_148);
        if ((*pbStack_150 & 0x20) == 0) {
          uStack_13c = 0;
          uStack_154 = (uint)uVar27;
          uStack_140 = (uint)uVar27;
        }
        else {
          puVar28 = (ushort *)(pbStack_150 + uVar27);
          uStack_13c = *puVar28;
          uStack_4f0 = puVar28;
          if (uStack_13c == 0) {
            cVar4 = func_0x(0x1ab37e0);
            if ((cVar4 != '\0') && (cVar4 = func_0x(), cVar4 != '\0')) {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 == '\0') {
                (*pcRam0000000001021368)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_528 = 0;
                (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x80f);
              }
            }
            func_0x(pbStack_150,3);
          }
          uStack_140 = uStack_148._4_4_ + 2 + (uint)uStack_13c * 2;
          if (0x1f9e < uStack_140) {
            cVar4 = func_0x(0x1ab37e0);
            if (cVar4 != '\0') {
              cVar4 = func_0x();
              if (cVar4 != '\0') {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 == '\0') {
                  (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_528 = 0;
                  (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x816);
                }
              }
            }
            func_0x(pbStack_150,4);
          }
          uVar17 = (ulonglong)uStack_13c;
          uStack_154 = puVar28[uVar17] & 0x7fff;
          if (uStack_154 < uStack_140) {
            cVar4 = func_0x(0x1ab37e0);
            if (cVar4 != '\0') {
              cVar4 = func_0x();
              if (cVar4 != '\0') {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 == '\0') {
                  (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_528 = 0;
                  (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x81d);
                }
              }
            }
            func_0x(pbStack_150,4);
            uVar17 = (ulonglong)uStack_13c;
          }
          uVar24 = (ulonglong)uStack_140;
          uVar27 = (ulonglong)uStack_154;
          iVar6 = 0;
          pbVar23 = pbStack_150;
          if ((short)uVar17 != 0) {
            do {
              puVar28 = puVar28 + 1;
              uVar19 = *puVar28 & 0x7fff;
              if ((uVar19 < (uint)uVar24) || ((uint)uVar27 < uVar19)) {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 != '\0') {
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    cVar4 = func_0x(0x1ab37e0);
                    if (cVar4 == '\0') {
                      (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_528 = 0;
                      (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x82a);
                    }
                  }
                }
                func_0x(pbStack_150,4);
                uVar17 = (ulonglong)uStack_13c;
                uVar27 = (ulonglong)uStack_154;
                pbVar23 = pbStack_150;
              }
              uVar24 = (ulonglong)uVar19;
              iVar6 = iVar6 + 1;
            } while (iVar6 < (int)uVar17);
            uVar24 = (ulonglong)uStack_140;
            param_1 = plStack_4e0;
            puVar28 = uStack_4f0;
          }
          while ((short)puVar28[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
            uVar22 = uVar24;
            if ((int)uVar17 != 1) {
              uVar22 = (ulonglong)
                       (*(ushort *)(pbVar23 + uVar17 * 2 + (((ulonglong)uStack_148 >> 0x20) - 2)) &
                       0x7fff);
            }
            uVar30 = *(ushort *)(pbVar23 + uVar17 * 2 + ((ulonglong)uStack_148 >> 0x20)) & 0x7fff;
            uVar19 = (uint)uVar22;
            if (((uVar19 < (uint)uVar24) || (uVar30 < uVar19)) || ((uint)uVar27 < uVar30)) {
              func_0x(pbVar23,7);
              uVar17 = (ulonglong)uStack_13c;
              uVar24 = (ulonglong)uStack_140;
              uVar27 = (ulonglong)uStack_154;
              pbVar23 = pbStack_150;
            }
            uVar7 = (uint)uVar27;
            if ((uVar19 < (uint)uVar24) || (uVar7 < uVar19)) goto code_r0x00101a1c;
            if (*(ushort *)(pbVar23 + uVar22) == 5) {
              uStack_156 = uStack_156 | 2;
              uStack_13c = (short)uVar17 - 1;
              uStack_12e = (ushort)uVar22;
              uVar22 = uVar22 & 0xffff;
              pbVar1 = pbVar23 + uVar22;
              if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                uVar15 = uStack_12c & 0xc7ff;
              }
              else {
                uVar15 = uStack_12c ^ (uStack_12c ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
              }
              uStack_12c = (uVar15 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar15;
              pbVar21 = pbVar23 + uVar22 + (ulonglong)((uStack_12c & 0x7ff) * 2) + 4 +
                                           (ulonglong)((uVar15 >> 0xb & 7) * 2);
              if (pbVar21 < pbVar1) {
                func_0x(pbVar1,0x19);
                uVar22 = (ulonglong)uStack_12e;
                uVar27 = (ulonglong)uStack_154;
                pbVar23 = pbStack_150;
              }
              if (uVar30 - uVar19 <
                  (((uStack_12c & 0x7ff) * 2 - (int)uVar22) - (int)pbStack_150) + (int)pbVar21) {
                func_0x(pbVar23 + uVar22,0x19);
                uVar22 = (ulonglong)uStack_12e;
                uVar27 = (ulonglong)uStack_154;
                pbVar23 = pbStack_150;
              }
              iVar6 = 0;
              if (((uStack_12c & 0x3800) != 0) &&
                 (puVar28 = (ushort *)(pbVar23 + uVar22 + 4), uVar15 = uStack_12c,
                 (uStack_12c & 0x3800) != 0)) {
                do {
                  if ((uVar15 & 0x7ff) < (*puVar28 & 0x7ff)) {
                    func_0x(pbVar23 + uVar22,0x1a);
                    uVar22 = (ulonglong)uStack_12e;
                    pbVar23 = pbStack_150;
                    uVar15 = uStack_12c;
                  }
                  iVar6 = iVar6 + 1;
                  puVar28 = puVar28 + 1;
                } while (iVar6 < (int)((uStack_12c & 0x3800) >> 0xb));
                uVar27 = (ulonglong)uStack_154;
              }
              break;
            }
            if (*(ushort *)(pbVar23 + uVar22) < 0x400) break;
            uStack_156 = uStack_156 | 1;
            uStack_13c = (short)uVar17 - 1;
            uVar17 = (ulonglong)uStack_13c;
            if (uStack_13c == 0) break;
          }
        }
        if ((*pbVar23 & 0x40) == 0) {
          uStack_132 = 0;
          uStack_130 = 0;
        }
        else {
          uStack_132 = (undefined2)uVar27;
          uStack_130 = (undefined2)(uVar27 >> 0x10);
          uStack_154 = (int)uVar27 + 0xe;
          uVar13 = func_0x(&uStack_156);
          func_0x(uVar13,auStack_428);
          iVar6 = func_0x(auStack_428);
          uStack_154 = uStack_154 + iVar6;
          uVar27 = (ulonglong)uStack_154;
          pbVar23 = pbStack_150;
        }
        uVar7 = (uint)uVar27;
        if (((byte *)CONCAT62(uStack_138,uStack_13a) != (byte *)0x0) &&
           ((byte *)CONCAT62(uStack_138,uStack_13a) < pbVar23 + uVar27)) {
          cVar4 = func_0x(0x1ab37e0);
          if (cVar4 != '\0') {
            cVar4 = func_0x();
            if (cVar4 != '\0') {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 == '\0') {
                (*pcRam0000000001021368)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_528 = 0;
                (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x886);
              }
            }
          }
          func_0x(pbStack_150,0x12);
          pbVar23 = pbStack_150;
          uVar7 = uStack_154;
        }
        if (0x3f3b < uVar7 - 1) {
          cVar4 = func_0x(0x1ab37e0);
          if (cVar4 != '\0') {
            cVar4 = func_0x();
            if (cVar4 != '\0') {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 == '\0') {
                (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_528 = 0;
                (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x88b);
              }
            }
          }
          func_0x(pbStack_150,5);
          pbVar23 = pbStack_150;
          uVar7 = uStack_154;
        }
      }
code_r0x00101a1c:
      uVar19 = uVar7;
      if (uVar7 < 9) {
        bVar5 = *pbVar23 & 0xe;
joined_r0x00101a54:
        if ((bVar5 == 0) || (uVar19 = uVar7, bVar5 == 0xc)) {
          uVar19 = 9;
        }
      }
    }
    else {
      if (uVar19 == 0) {
        func_0x(&uStack_156);
        uVar19 = uStack_154;
      }
      pbVar23 = pbStack_150;
      uVar7 = uVar19;
      if (uVar19 < 9) {
        bVar5 = *pbStack_150 & 0x1c;
        goto joined_r0x00101a54;
      }
    }
    uVar13 = uStack_4d0;
    if (uVar19 < 0x6fb) {
      func_0x(uStack_4d0,0,0x6fa);
      if (sStack_158 == 0) {
        if (uVar7 == 0) {
          iVar6 = 0;
          uStack_156 = 0;
          uVar27 = (ulonglong)uStack_148 & 0xffffffff;
          uVar19 = (uint)uStack_148;
          if ((*pbVar23 & 0x10) != 0) {
            uVar19 = (uint)uStack_148 + 2 + (*(ushort *)(pbVar23 + uVar27) + 7 >> 3);
            uVar27 = (ulonglong)uVar19;
          }
          uStack_148 = (byte **)CONCAT44(uVar19,(uint)uStack_148);
          if ((*pbVar23 & 0x20) == 0) {
            uStack_13c = 0;
            uStack_154 = (uint)uVar27;
            uStack_140 = (uint)uVar27;
          }
          else {
            plVar29 = (longlong *)(pbVar23 + uVar27);
            uStack_13c = *(ushort *)plVar29;
            plStack_4e0 = plVar29;
            if (uStack_13c == 0) {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 != '\0') {
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 == '\0') {
                    (*pcRam0000000001021368)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_528 = 0;
                    (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x80f);
                  }
                }
              }
              func_0x(pbStack_150,3);
              pbVar23 = pbStack_150;
            }
            uStack_140 = uStack_148._4_4_ + 2 + (uint)uStack_13c * 2;
            if (0x1f9e < uStack_140) {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 != '\0') {
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 == '\0') {
                    (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_528 = 0;
                    (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x816);
                  }
                }
              }
              func_0x(pbStack_150,4);
              pbVar23 = pbStack_150;
            }
            uVar17 = (ulonglong)uStack_13c;
            uStack_154 = *(ushort *)((longlong)plVar29 + uVar17 * 2) & 0x7fff;
            if (uStack_154 < uStack_140) {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 != '\0') {
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 == '\0') {
                    (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_528 = 0;
                    (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x81d);
                  }
                }
              }
              func_0x(pbStack_150,4);
              uVar17 = (ulonglong)uStack_13c;
              pbVar23 = pbStack_150;
            }
            uVar24 = (ulonglong)uStack_140;
            uVar27 = (ulonglong)uStack_154;
            if ((short)uVar17 != 0) {
              do {
                plVar29 = (longlong *)((longlong)plVar29 + 2);
                uVar19 = *(ushort *)plVar29 & 0x7fff;
                if ((uVar19 < (uint)uVar24) || ((uint)uVar27 < uVar19)) {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 != '\0') {
                    cVar4 = func_0x();
                    if (cVar4 != '\0') {
                      cVar4 = func_0x(0x1ab37e0);
                      if (cVar4 == '\0') {
                        (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_528 = 0;
                        (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x82a);
                      }
                    }
                  }
                  func_0x(pbStack_150,4);
                  uVar17 = (ulonglong)uStack_13c;
                  uVar27 = (ulonglong)uStack_154;
                  pbVar23 = pbStack_150;
                }
                uVar24 = (ulonglong)uVar19;
                iVar6 = iVar6 + 1;
              } while (iVar6 < (int)uVar17);
              uVar24 = (ulonglong)uStack_140;
              uVar13 = uStack_4d0;
              plVar29 = plStack_4e0;
            }
            while( true ) {
              if (-1 < *(short *)((longlong)plVar29 + (ulonglong)((int)uVar17 - 1) * 2 + 2)) break;
              uVar22 = uVar24;
              if ((int)uVar17 != 1) {
                uVar22 = (ulonglong)
                         (*(ushort *)(pbVar23 + uVar17 * 2 + (((ulonglong)uStack_148 >> 0x20) - 2))
                         & 0x7fff);
              }
              uVar30 = *(ushort *)(pbVar23 + uVar17 * 2 + ((ulonglong)uStack_148 >> 0x20)) & 0x7fff;
              uVar19 = (uint)uVar22;
              if (((uVar19 < (uint)uVar24) || (uVar30 < uVar19)) ||
                 (uVar15 = (ushort)uVar17, (uint)uVar27 < uVar30)) {
                func_0x(pbVar23,7);
                uVar24 = (ulonglong)uStack_140;
                uVar27 = (ulonglong)uStack_154;
                pbVar23 = pbStack_150;
                uVar15 = uStack_13c;
              }
              uVar7 = (uint)uVar27;
              if ((uVar19 < (uint)uVar24) || (uVar7 < uVar19)) goto code_r0x00102215;
              if (*(ushort *)(pbVar23 + uVar22) == 5) {
                uStack_156 = uStack_156 | 2;
                uStack_13c = uVar15 - 1;
                uStack_12e = (ushort)uVar22;
                uVar22 = uVar22 & 0xffff;
                pbVar1 = pbVar23 + uVar22;
                if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                  uVar15 = uStack_12c & 0xc7ff;
                }
                else {
                  uVar15 = uStack_12c ^ (uStack_12c ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                }
                uStack_12c = (uVar15 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar15;
                pbVar21 = pbVar23 + (ulonglong)((uStack_12c & 0x7ff) * 2) + 4 +
                                    (uVar15 >> 0xb & 7) * 2 + uVar22;
                if (pbVar21 < pbVar1) {
                  func_0x(pbVar1,0x19);
                  uVar22 = (ulonglong)uStack_12e;
                  uVar27 = (ulonglong)uStack_154;
                  pbVar23 = pbStack_150;
                }
                if (uVar30 - uVar19 <
                    (((uStack_12c & 0x7ff) * 2 - (int)uVar22) - (int)pbStack_150) + (int)pbVar21) {
                  func_0x(pbVar23 + uVar22,0x19);
                  uVar22 = (ulonglong)uStack_12e;
                  uVar27 = (ulonglong)uStack_154;
                  pbVar23 = pbStack_150;
                }
                if ((uStack_12c & 0x3800) != 0) {
                  puVar28 = (ushort *)(pbVar23 + uVar22 + 4);
                  iVar6 = 0;
                  uVar15 = uStack_12c;
                  if ((uStack_12c & 0x3800) != 0) {
                    do {
                      if ((uVar15 & 0x7ff) < (*puVar28 & 0x7ff)) {
                        func_0x(pbVar23 + uVar22,0x1a);
                        uVar22 = (ulonglong)uStack_12e;
                        pbVar23 = pbStack_150;
                        uVar15 = uStack_12c;
                      }
                      iVar6 = iVar6 + 1;
                      puVar28 = puVar28 + 1;
                    } while (iVar6 < (int)((uStack_12c & 0x3800) >> 0xb));
                    uVar27 = (ulonglong)uStack_154;
                  }
                }
                break;
              }
              if (*(ushort *)(pbVar23 + uVar22) < 0x400) break;
              uStack_156 = uStack_156 | 1;
              uStack_13c = uVar15 - 1;
              uVar17 = (ulonglong)uStack_13c;
              if (uStack_13c == 0) break;
            }
          }
          iVar6 = 0;
          if ((*pbVar23 & 0x40) == 0) {
            uStack_132 = 0;
            uStack_130 = 0;
          }
          else {
            uStack_132 = (undefined2)uVar27;
            uStack_130 = (undefined2)(uVar27 >> 0x10);
            uStack_154 = (int)uVar27 + 0xe;
            puVar14 = (ulonglong *)func_0x(&uStack_156);
            uVar16 = (ushort)(*puVar14 >> 0x30);
            uVar15 = uVar16;
            if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
              uVar15 = uVar16 & 0xdfff;
              if ((uVar16 >> 0xe & 1) != 0) {
                uVar15 = uVar16 | 0x2000;
              }
            }
            if (uVar15 == 0xfffc) {
              iVar6 = (int)((*puVar14 >> 0x20 & 0xffff) >> 5);
            }
            uStack_154 = uStack_154 + iVar6;
            uVar27 = (ulonglong)uStack_154;
            pbVar23 = pbStack_150;
            uVar13 = uStack_4d0;
          }
          uVar7 = (uint)uVar27;
          if (((byte *)CONCAT62(uStack_138,uStack_13a) != (byte *)0x0) &&
             ((byte *)CONCAT62(uStack_138,uStack_13a) < pbVar23 + uVar27)) {
            cVar4 = func_0x(0x1ab37e0);
            if (cVar4 != '\0') {
              cVar4 = func_0x();
              if (cVar4 != '\0') {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 == '\0') {
                  (*pcRam0000000001021368)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  uStack_528 = 0;
                  (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x886);
                }
              }
            }
            func_0x(pbStack_150,0x12);
            pbVar23 = pbStack_150;
            uVar7 = uStack_154;
          }
          if (0x3f3b < uVar7 - 1) {
            cVar4 = func_0x(0x1ab37e0);
            if (cVar4 != '\0') {
              cVar4 = func_0x();
              if (cVar4 != '\0') {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 == '\0') {
                  (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  uStack_528 = 0;
                  (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x88b);
                }
              }
            }
            func_0x(pbStack_150,5);
            pbVar23 = pbStack_150;
            uVar7 = uStack_154;
          }
        }
code_r0x00102215:
        if ((8 < uVar7) || (((*pbVar23 & 0xe) != 0 && ((*pbVar23 & 0xe) != 0xc)))) {
code_r0x00102225:
          uStack_500 = uVar7;
        }
      }
      else {
        if (uVar7 == 0) {
          func_0x(&uStack_156);
          pbVar23 = pbStack_150;
          uVar7 = uStack_154;
        }
        if ((8 < uVar7) || (((*pbVar23 & 0x1c) != 0 && ((*pbVar23 & 0x1c) != 0xc))))
        goto code_r0x00102225;
        uStack_500 = 9;
      }
      func_0x(uVar13,0x6fa,pbVar23,uStack_500);
    }
    else if (*(char *)(param_1[1] + 0x241c) != '\0') {
      func_0x(uStack_4d0,0,0x6fa);
      if (sStack_158 == 0) {
        uVar19 = uVar7;
        if (uVar7 == 0) {
          iVar6 = 0;
          uStack_156 = 0;
          uVar27 = (ulonglong)uStack_148 & 0xffffffff;
          uVar19 = (uint)uStack_148;
          if ((*pbVar23 & 0x10) != 0) {
            uVar19 = (uint)uStack_148 + 2 + (*(ushort *)(pbVar23 + uVar27) + 7 >> 3);
            uVar27 = (ulonglong)uVar19;
          }
          uStack_148 = (byte **)CONCAT44(uVar19,(uint)uStack_148);
          if ((*pbVar23 & 0x20) == 0) {
            uStack_13c = 0;
            uStack_154 = (uint)uVar27;
            uStack_140 = (uint)uVar27;
          }
          else {
            plVar29 = (longlong *)(pbVar23 + uVar27);
            uStack_13c = *(ushort *)plVar29;
            plStack_4e0 = plVar29;
            if (uStack_13c == 0) {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 != '\0') {
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 == '\0') {
                    (*pcRam0000000001021368)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_528 = 0;
                    (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x80f);
                  }
                }
              }
              func_0x(pbStack_150,3);
              pbVar23 = pbStack_150;
            }
            uStack_140 = uStack_148._4_4_ + 2 + (uint)uStack_13c * 2;
            if (0x1f9e < uStack_140) {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 != '\0') {
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 == '\0') {
                    (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_528 = 0;
                    (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x816);
                  }
                }
              }
              func_0x(pbStack_150,4);
              pbVar23 = pbStack_150;
            }
            uVar17 = (ulonglong)uStack_13c;
            uStack_154 = *(ushort *)((longlong)plVar29 + uVar17 * 2) & 0x7fff;
            if (uStack_154 < uStack_140) {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 != '\0') {
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 == '\0') {
                    (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_528 = 0;
                    (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x81d);
                  }
                }
              }
              func_0x(pbStack_150,4);
              uVar17 = (ulonglong)uStack_13c;
              pbVar23 = pbStack_150;
            }
            uVar24 = (ulonglong)uStack_140;
            uVar27 = (ulonglong)uStack_154;
            if ((short)uVar17 != 0) {
              do {
                plVar29 = (longlong *)((longlong)plVar29 + 2);
                uVar19 = *(ushort *)plVar29 & 0x7fff;
                if ((uVar19 < (uint)uVar24) || ((uint)uVar27 < uVar19)) {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 != '\0') {
                    cVar4 = func_0x();
                    if (cVar4 != '\0') {
                      cVar4 = func_0x(0x1ab37e0);
                      if (cVar4 == '\0') {
                        (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_528 = 0;
                        (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x82a);
                      }
                    }
                  }
                  func_0x(pbStack_150,4);
                  uVar17 = (ulonglong)uStack_13c;
                  uVar27 = (ulonglong)uStack_154;
                  pbVar23 = pbStack_150;
                }
                uVar24 = (ulonglong)uVar19;
                iVar6 = iVar6 + 1;
              } while (iVar6 < (int)uVar17);
              uVar24 = (ulonglong)uStack_140;
              plVar29 = plStack_4e0;
            }
            while( true ) {
              if (-1 < *(short *)((longlong)plVar29 + (ulonglong)((int)uVar17 - 1) * 2 + 2)) break;
              uVar22 = uVar24;
              if ((int)uVar17 != 1) {
                uVar22 = (ulonglong)
                         (*(ushort *)(pbVar23 + uVar17 * 2 + (((ulonglong)uStack_148 >> 0x20) - 2))
                         & 0x7fff);
              }
              uVar30 = *(ushort *)(pbVar23 + uVar17 * 2 + ((ulonglong)uStack_148 >> 0x20)) & 0x7fff;
              uVar7 = (uint)uVar22;
              if (((uVar7 < (uint)uVar24) || (uVar30 < uVar7)) ||
                 (uVar15 = (ushort)uVar17, (uint)uVar27 < uVar30)) {
                func_0x(pbVar23,7);
                uVar24 = (ulonglong)uStack_140;
                uVar27 = (ulonglong)uStack_154;
                pbVar23 = pbStack_150;
                uVar15 = uStack_13c;
              }
              uVar19 = (uint)uVar27;
              if ((uVar7 < (uint)uVar24) || (uVar19 < uVar7)) goto code_r0x00102a46;
              if (*(ushort *)(pbVar23 + uVar22) == 5) {
                uStack_156 = uStack_156 | 2;
                uStack_13c = uVar15 - 1;
                uStack_12e = (ushort)uVar22;
                uVar22 = uVar22 & 0xffff;
                pbVar1 = pbVar23 + uVar22;
                if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                  uVar15 = uStack_12c & 0xc7ff;
                }
                else {
                  uVar15 = uStack_12c ^ (*(ushort *)(pbVar1 + 2) ^ uStack_12c) & 0x3800;
                }
                uStack_12c = (uVar15 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar15;
                pbVar21 = pbVar23 + uVar22 + (ulonglong)((uStack_12c & 0x7ff) * 2) + 4 +
                                             (ulonglong)((uVar15 >> 0xb & 7) * 2);
                if (pbVar21 < pbVar1) {
                  func_0x(pbVar1,0x19);
                  uVar22 = (ulonglong)uStack_12e;
                  uVar27 = (ulonglong)uStack_154;
                  pbVar23 = pbStack_150;
                }
                if (uVar30 - uVar7 <
                    (((uStack_12c & 0x7ff) * 2 - (int)uVar22) - (int)pbStack_150) + (int)pbVar21) {
                  func_0x(pbVar23 + uVar22,0x19);
                  uVar22 = (ulonglong)uStack_12e;
                  uVar27 = (ulonglong)uStack_154;
                  pbVar23 = pbStack_150;
                }
                if ((uStack_12c & 0x3800) != 0) {
                  puVar28 = (ushort *)(pbVar23 + uVar22 + 4);
                  iVar6 = 0;
                  uVar15 = uStack_12c;
                  if ((uStack_12c & 0x3800) != 0) {
                    do {
                      if ((uVar15 & 0x7ff) < (*puVar28 & 0x7ff)) {
                        func_0x(pbVar23 + uVar22,0x1a);
                        uVar22 = (ulonglong)uStack_12e;
                        pbVar23 = pbStack_150;
                        uVar15 = uStack_12c;
                      }
                      iVar6 = iVar6 + 1;
                      puVar28 = puVar28 + 1;
                    } while (iVar6 < (int)((uStack_12c & 0x3800) >> 0xb));
                    uVar27 = (ulonglong)uStack_154;
                  }
                }
                break;
              }
              if (*(ushort *)(pbVar23 + uVar22) < 0x400) break;
              uStack_156 = uStack_156 | 1;
              uStack_13c = uVar15 - 1;
              uVar17 = (ulonglong)uStack_13c;
              if (uStack_13c == 0) break;
            }
          }
          iVar6 = 0;
          if ((*pbVar23 & 0x40) == 0) {
            uStack_132 = 0;
            uStack_130 = 0;
          }
          else {
            uStack_132 = (undefined2)uVar27;
            uStack_130 = (undefined2)(uVar27 >> 0x10);
            uStack_154 = (int)uVar27 + 0xe;
            puVar14 = (ulonglong *)func_0x(&uStack_156);
            uVar16 = (ushort)(*puVar14 >> 0x30);
            uVar15 = uVar16;
            if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
              uVar15 = uVar16 & 0xdfff;
              if ((uVar16 >> 0xe & 1) != 0) {
                uVar15 = uVar16 | 0x2000;
              }
            }
            if (uVar15 == 0xfffc) {
              iVar6 = (int)((*puVar14 >> 0x20 & 0xffff) >> 5);
            }
            uStack_154 = uStack_154 + iVar6;
            uVar27 = (ulonglong)uStack_154;
            pbVar23 = pbStack_150;
          }
          uVar19 = (uint)uVar27;
          if (((byte *)CONCAT62(uStack_138,uStack_13a) != (byte *)0x0) &&
             ((byte *)CONCAT62(uStack_138,uStack_13a) < pbVar23 + uVar27)) {
            cVar4 = func_0x(0x1ab37e0);
            if (cVar4 != '\0') {
              cVar4 = func_0x();
              if (cVar4 != '\0') {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 == '\0') {
                  (*pcRam0000000001021368)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  uStack_528 = 0;
                  (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x886);
                }
              }
            }
            func_0x(pbStack_150,0x12);
            pbVar23 = pbStack_150;
            uVar19 = uStack_154;
          }
          if (0x3f3b < uVar19 - 1) {
            cVar4 = func_0x(0x1ab37e0);
            if (cVar4 != '\0') {
              cVar4 = func_0x();
              if (cVar4 != '\0') {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 == '\0') {
                  (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  uStack_528 = 0;
                  (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x88b);
                }
              }
            }
            func_0x(pbStack_150,5);
            pbVar23 = pbStack_150;
            uVar19 = uStack_154;
          }
        }
code_r0x00102a46:
        uVar7 = uVar19;
        if (uVar19 < 9) {
          bVar5 = *pbVar23 & 0xe;
joined_r0x00102a7e:
          if ((bVar5 == 0) || (uVar7 = uVar19, bVar5 == 0xc)) {
            uVar7 = 9;
          }
        }
      }
      else {
        if (uVar7 == 0) {
          func_0x(&uStack_156);
          pbVar23 = pbStack_150;
          uVar7 = uStack_154;
        }
        uVar19 = uVar7;
        if (uVar7 < 9) {
          bVar5 = *pbVar23 & 0x1c;
          goto joined_r0x00102a7e;
        }
      }
      if (uVar7 < 0x6fa) {
        if (sStack_158 == 0) {
          if (uVar19 == 0) {
            iVar6 = 0;
            uStack_156 = 0;
            uVar27 = (ulonglong)uStack_148 & 0xffffffff;
            uVar19 = (uint)uStack_148;
            if ((*pbVar23 & 0x10) != 0) {
              uVar19 = (uint)uStack_148 + 2 + (*(ushort *)(pbVar23 + uVar27) + 7 >> 3);
              uVar27 = (ulonglong)uVar19;
            }
            uStack_148 = (byte **)CONCAT44(uVar19,(uint)uStack_148);
            if ((*pbVar23 & 0x20) == 0) {
              uStack_13c = 0;
              uStack_154 = (uint)uVar27;
              uStack_140 = (uint)uVar27;
            }
            else {
              plVar29 = (longlong *)(pbVar23 + uVar27);
              uStack_13c = *(ushort *)plVar29;
              plStack_4e0 = plVar29;
              if (uStack_13c == 0) {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 != '\0') {
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    cVar4 = func_0x(0x1ab37e0);
                    if (cVar4 == '\0') {
                      (*pcRam0000000001021368)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_528 = 0;
                      (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x80f);
                    }
                  }
                }
                func_0x(pbStack_150,3);
                pbVar23 = pbStack_150;
              }
              uStack_140 = uStack_148._4_4_ + 2 + (uint)uStack_13c * 2;
              if (0x1f9e < uStack_140) {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 != '\0') {
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    cVar4 = func_0x(0x1ab37e0);
                    if (cVar4 == '\0') {
                      (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_528 = 0;
                      (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x816);
                    }
                  }
                }
                func_0x(pbStack_150,4);
                pbVar23 = pbStack_150;
              }
              uVar17 = (ulonglong)uStack_13c;
              uStack_154 = *(ushort *)((longlong)plVar29 + uVar17 * 2) & 0x7fff;
              if (uStack_154 < uStack_140) {
                cVar4 = func_0x(0x1ab37e0);
                if (cVar4 != '\0') {
                  cVar4 = func_0x();
                  if (cVar4 != '\0') {
                    cVar4 = func_0x(0x1ab37e0);
                    if (cVar4 == '\0') {
                      (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_528 = 0;
                      (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x81d);
                    }
                  }
                }
                func_0x(pbStack_150,4);
                uVar17 = (ulonglong)uStack_13c;
                pbVar23 = pbStack_150;
              }
              uVar24 = (ulonglong)uStack_140;
              uVar27 = (ulonglong)uStack_154;
              if ((short)uVar17 != 0) {
                do {
                  plVar29 = (longlong *)((longlong)plVar29 + 2);
                  uVar19 = *(ushort *)plVar29 & 0x7fff;
                  if ((uVar19 < (uint)uVar24) || ((uint)uVar27 < uVar19)) {
                    cVar4 = func_0x(0x1ab37e0);
                    if (cVar4 != '\0') {
                      cVar4 = func_0x();
                      if (cVar4 != '\0') {
                        cVar4 = func_0x(0x1ab37e0);
                        if (cVar4 == '\0') {
                          (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_528 = 0;
                          (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x82a);
                        }
                      }
                    }
                    func_0x(pbStack_150,4);
                    uVar17 = (ulonglong)uStack_13c;
                    uVar27 = (ulonglong)uStack_154;
                    pbVar23 = pbStack_150;
                  }
                  uVar24 = (ulonglong)uVar19;
                  iVar6 = iVar6 + 1;
                } while (iVar6 < (int)uVar17);
                uVar24 = (ulonglong)uStack_140;
                plVar29 = plStack_4e0;
              }
              while( true ) {
                if (-1 < *(short *)((longlong)plVar29 + (ulonglong)((int)uVar17 - 1) * 2 + 2))
                break;
                uVar22 = uVar24;
                if ((int)uVar17 != 1) {
                  uVar22 = (ulonglong)
                           (*(ushort *)
                             (pbVar23 + uVar17 * 2 + (((ulonglong)uStack_148 >> 0x20) - 2)) & 0x7fff
                           );
                }
                uVar30 = *(ushort *)(pbVar23 + uVar17 * 2 + ((ulonglong)uStack_148 >> 0x20)) &
                         0x7fff;
                uVar7 = (uint)uVar22;
                if (((uVar7 < (uint)uVar24) || (uVar30 < uVar7)) ||
                   (uVar15 = (ushort)uVar17, (uint)uVar27 < uVar30)) {
                  func_0x(pbVar23,7);
                  uVar24 = (ulonglong)uStack_140;
                  uVar27 = (ulonglong)uStack_154;
                  pbVar23 = pbStack_150;
                  uVar15 = uStack_13c;
                }
                uVar19 = (uint)uVar27;
                if ((uVar7 < (uint)uVar24) || (uVar19 < uVar7)) goto code_r0x0010321a;
                if (*(ushort *)(pbVar23 + uVar22) == 5) {
                  uStack_156 = uStack_156 | 2;
                  uStack_13c = uVar15 - 1;
                  uStack_12e = (ushort)uVar22;
                  uVar22 = uVar22 & 0xffff;
                  pbVar1 = pbVar23 + uVar22;
                  if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                    uVar15 = uStack_12c & 0xc7ff;
                  }
                  else {
                    uVar15 = uStack_12c ^ (uStack_12c ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                  }
                  uStack_12c = (uVar15 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar15;
                  pbVar21 = pbVar23 + uVar22 + (ulonglong)((uStack_12c & 0x7ff) * 2) + 4 +
                                               (ulonglong)((uVar15 >> 0xb & 7) * 2);
                  if (pbVar21 < pbVar1) {
                    func_0x(pbVar1,0x19);
                    uVar22 = (ulonglong)uStack_12e;
                    uVar27 = (ulonglong)uStack_154;
                    pbVar23 = pbStack_150;
                  }
                  if (uVar30 - uVar7 <
                      (((uStack_12c & 0x7ff) * 2 - (int)uVar22) - (int)pbStack_150) + (int)pbVar21)
                  {
                    func_0x(pbVar23 + uVar22,0x19);
                    uVar22 = (ulonglong)uStack_12e;
                    uVar27 = (ulonglong)uStack_154;
                    pbVar23 = pbStack_150;
                  }
                  if ((uStack_12c & 0x3800) != 0) {
                    puVar28 = (ushort *)(pbVar23 + uVar22 + 4);
                    iVar6 = 0;
                    uVar15 = uStack_12c;
                    if ((uStack_12c & 0x3800) != 0) {
                      do {
                        if ((uVar15 & 0x7ff) < (*puVar28 & 0x7ff)) {
                          func_0x(pbVar23 + uVar22,0x1a);
                          uVar22 = (ulonglong)uStack_12e;
                          pbVar23 = pbStack_150;
                          uVar15 = uStack_12c;
                        }
                        iVar6 = iVar6 + 1;
                        puVar28 = puVar28 + 1;
                      } while (iVar6 < (int)((uStack_12c & 0x3800) >> 0xb));
                      uVar27 = (ulonglong)uStack_154;
                    }
                  }
                  break;
                }
                if (*(ushort *)(pbVar23 + uVar22) < 0x400) break;
                uStack_156 = uStack_156 | 1;
                uStack_13c = uVar15 - 1;
                uVar17 = (ulonglong)uStack_13c;
                if (uStack_13c == 0) break;
              }
            }
            iVar6 = 0;
            if ((*pbVar23 & 0x40) == 0) {
              uStack_132 = 0;
              uStack_130 = 0;
            }
            else {
              uStack_132 = (undefined2)uVar27;
              uStack_130 = (undefined2)(uVar27 >> 0x10);
              uStack_154 = (int)uVar27 + 0xe;
              puVar14 = (ulonglong *)func_0x(&uStack_156);
              uVar16 = (ushort)(*puVar14 >> 0x30);
              uVar15 = uVar16;
              if ((((uint)(int)(short)uVar16 >> 1 ^ (int)(short)uVar16) & 0x2000) != 0) {
                uVar15 = uVar16 & 0xdfff;
                if ((uVar16 >> 0xe & 1) != 0) {
                  uVar15 = uVar16 | 0x2000;
                }
              }
              if (uVar15 == 0xfffc) {
                iVar6 = (int)((*puVar14 >> 0x20 & 0xffff) >> 5);
              }
              uStack_154 = uStack_154 + iVar6;
              uVar27 = (ulonglong)uStack_154;
              pbVar23 = pbStack_150;
            }
            uVar19 = (uint)uVar27;
            if (((byte *)CONCAT62(uStack_138,uStack_13a) != (byte *)0x0) &&
               ((byte *)CONCAT62(uStack_138,uStack_13a) < pbVar23 + uVar27)) {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 != '\0') {
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 == '\0') {
                    (*pcRam0000000001021368)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_528 = 0;
                    (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x886);
                  }
                }
              }
              func_0x(pbStack_150,0x12);
              pbVar23 = pbStack_150;
              uVar19 = uStack_154;
            }
            if (0x3f3b < uVar19 - 1) {
              cVar4 = func_0x(0x1ab37e0);
              if (cVar4 != '\0') {
                cVar4 = func_0x();
                if (cVar4 != '\0') {
                  cVar4 = func_0x(0x1ab37e0);
                  if (cVar4 == '\0') {
                    (*pcRam0000000001021368)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_528 = 0;
                    (*pcRam0000000001021360)(1,0x13a31ec,0x14c32d8,0x88b);
                  }
                }
              }
              func_0x(pbStack_150,5);
              pbVar23 = pbStack_150;
              uVar19 = uStack_154;
            }
          }
code_r0x0010321a:
          if ((8 < uVar19) ||
             ((uVar7 = uStack_500, (*pbVar23 & 0xe) != 0 && ((*pbVar23 & 0xe) != 0xc)))) {
code_r0x0010322a:
            uStack_500 = uVar19;
            uVar7 = uVar19;
          }
        }
        else {
          if (uVar19 == 0) {
            func_0x(&uStack_156);
            pbVar23 = pbStack_150;
            uVar19 = uStack_154;
          }
          if ((8 < uVar19) || (((*pbVar23 & 0x1c) != 0 && ((*pbVar23 & 0x1c) != 0xc))))
          goto code_r0x0010322a;
          uStack_500 = 9;
          uVar7 = 9;
        }
      }
      else {
        uVar7 = 0x6fa;
      }
      func_0x(uStack_4d0,0x6fa,pbVar23,uVar7);
    }
  }
  plVar29 = plStack_518;
  if (plStack_518 == (longlong *)0x0) goto LAB_;
  iVar6 = (int)(short)uStack_50c;
  if (((*(ushort *)((longlong)plStack_518 + 0x62) >> 10 & 1) != 0) && (2 < iVar6)) {
    func_0x(&plStack_518);
    goto LAB_;
  }
  if (((byte)*(undefined2 *)((longlong)plStack_518 + 0x62) >> 3 & 1) != 0) {
    if (iVar6 == 3) {
      iVar6 = 4;
    }
    else if (iVar6 < 2) goto LAB_;
    if ((((*(uint *)((longlong)plStack_518 + 100) & 8) != 0) &&
        (lVar9 = plStack_518[0x12], lVar9 != 0)) && (*(longlong *)(lVar9 + 0x758) != 0)) {
      func_0x(*(undefined8 *)(lVar9 + 0x758),plStack_518,iVar6);
    }
  }
LAB_:
  if ((((DAT_ & 0x80) != 0) && ((*(uint *)((longlong)plVar29 + 100) & 8) != 0)) &&
     ((2 < iVar6 &&
      (((*(uint *)((longlong)plVar29 + 100) & 0xc0000000) != 0x40000000 && (*plVar29 != 0)))))) {
    iVar8 = (*_DAT_)(*plVar29,0x2000,2,auStack_42c);
    if (iVar8 != 0) {
      LOCK();
      *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) & 0x3fffffff;
      UNLOCK();
      LOCK();
      *(uint *)((longlong)plVar29 + 100) = *(uint *)((longlong)plVar29 + 100) | 0x40000000;
      UNLOCK();
    }
  }
  func_0x(plVar29 + 0x13,iVar6);
  if ((_DAT_ != 0) && ((DAT_ & 2) != 0)) {
    func_0x(plVar29,0,iVar6);
  }
  uStack_50c = uStack_50c & 0xffff0000;
  plStack_518 = (longlong *)0x0;
  goto LAB_;
}

