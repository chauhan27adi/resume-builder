
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1)

{
  longlong lVar1;
  undefined4 *puVar2;
  longlong unaff_RSI;
  byte bStack0000000000000038;
  undefined4 uStack000000000000003c;
  undefined4 uStack0000000000000040;
  undefined4 uStack0000000000000044;
  short sStack0000000000000048;
  undefined4 uStack000000000000004c;
  undefined4 uStack0000000000000050;
  undefined4 uStack0000000000000054;
  
  lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x20) + 0x10);
  _bStack0000000000000038 = *(undefined4 *)(lVar1 + 0x18);
  uStack000000000000003c = *(undefined4 *)(lVar1 + 0x1c);
  uStack0000000000000040 = *(undefined4 *)(lVar1 + 0x20);
  uStack0000000000000044 = *(undefined4 *)(lVar1 + 0x24);
  _sStack0000000000000048 = *(undefined4 *)(lVar1 + 0x28);
  uStack000000000000004c = *(undefined4 *)(lVar1 + 0x2c);
  uStack0000000000000050 = *(undefined4 *)(lVar1 + 0x30);
  uStack0000000000000054 = *(undefined4 *)(lVar1 + 0x34);
  puVar2 = (undefined4 *)(*_DAT_)(0x20,_sStack0000000000000048,0x2539baf,0x527,1);
  if (puVar2 == (undefined4 *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  puVar2[1] = 0;
  *(undefined8 *)(puVar2 + 4) = 0;
  *(undefined8 *)(puVar2 + 6) = 0;
  *(undefined4 **)(unaff_RSI + 0x60) = puVar2;
  *puVar2 = 3;
  *(undefined8 *)(puVar2 + 2) = 0;
  *(undefined8 *)(puVar2 + 4) = 0;
  puVar2[6] = 0;
  if ((sStack0000000000000048 != -1) &&
     (*(char *)((ulonglong)*(byte *)((ulonglong)bStack0000000000000038 + 0x2515897) + 0x2ecc92f) ==
      '\0')) {
    (*_DAT_)(lVar1);
    (*_DAT_)(*(undefined8 *)(unaff_RSI + 0x60));
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

