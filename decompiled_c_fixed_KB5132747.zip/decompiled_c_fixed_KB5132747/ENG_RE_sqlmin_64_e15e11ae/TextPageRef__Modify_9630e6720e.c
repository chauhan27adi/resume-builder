
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong **param_1,ushort *param_2,undefined8 param_3,longlong *param_4,
                 int *param_5,uint param_6,byte **param_7,short *param_8)

{
  byte *pbVar1;
  undefined2 uVar2;
  uint *puVar3;
  ulonglong uVar4;
  char cVar5;
  short sVar6;
  ushort uVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  short *psVar11;
  undefined8 uVar12;
  longlong lVar13;
  byte bVar14;
  ushort uVar15;
  uint uVar16;
  undefined4 uVar17;
  uint uVar18;
  undefined8 *puVar19;
  longlong *plVar20;
  byte *pbVar21;
  longlong lVar22;
  uint uVar23;
  byte **ppbVar24;
  uint uVar25;
  uint uVar26;
  ulonglong uVar27;
  byte *pbVar28;
  ulonglong *puVar29;
  ulonglong uVar30;
  longlong *plVar31;
  ushort *puVar32;
  ushort *puVar33;
  ulonglong uVar34;
  int iVar35;
  ulonglong uVar36;
  ushort *puVar37;
  longlong unaff_GS_OFFSET;
  undefined auStack_2e8 [32];
  undefined8 uStack_2c8;
  uint uStack_2c0;
  uint uStack_2b8;
  undefined8 uStack_2b0;
  undefined8 uStack_2a8;
  uint uStack_2a0;
  longlong *plStack_298;
  int *piStack_290;
  undefined8 uStack_288;
  undefined8 uStack_280;
  undefined4 uStack_278;
  undefined4 uStack_270;
  undefined8 uStack_268;
  ushort *puStack_260;
  undefined4 uStack_258;
  short sStack_250;
  ushort uStack_24e;
  uint uStack_24c;
  byte *pbStack_248;
  undefined8 uStack_240;
  uint uStack_238;
  ushort uStack_234;
  byte *pbStack_232;
  undefined2 uStack_22a;
  undefined2 uStack_228;
  ushort uStack_226;
  ushort uStack_224;
  undefined2 uStack_222;
  undefined4 uStack_220;
  uint uStack_218;
  ushort *puStack_210;
  undefined4 uStack_208;
  uint uStack_200;
  short *psStack_1f8;
  longlong *plStack_1f0;
  longlong lStack_1e8;
  undefined8 uStack_1e0;
  ushort uStack_1d8;
  undefined8 uStack_1d0;
  ushort uStack_1c8;
  undefined8 uStack_1c0;
  undefined2 uStack_1b8;
  int iStack_1b0;
  uint uStack_1ac;
  int iStack_1a8;
  undefined4 uStack_1a4;
  undefined2 uStack_1a0;
  undefined4 uStack_19c;
  undefined2 uStack_198;
  undefined4 uStack_194;
  undefined2 uStack_190;
  longlong lStack_188;
  ushort *puStack_180;
  ushort *puStack_178;
  byte **ppbStack_168;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined8 uStack_158;
  undefined8 uStack_150;
  longlong lStack_148;
  longlong **pplStack_140;
  int *piStack_138;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  byte *pbStack_118;
  short sStack_108;
  ushort uStack_106;
  uint uStack_104;
  byte *pbStack_100;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  ushort uStack_ec;
  undefined2 uStack_ea;
  undefined6 uStack_e8;
  undefined2 uStack_e2;
  undefined2 uStack_e0;
  ushort uStack_de;
  ushort uStack_dc;
  undefined2 uStack_da;
  undefined4 uStack_d8;
  uint uStack_d4;
  undefined auStack_d0 [16];
  undefined auStack_c0 [8];
  undefined8 uStack_b8;
  undefined8 uStack_b0;
  undefined6 uStack_a8;
  undefined2 uStack_a2;
  undefined6 uStack_a0;
  undefined2 uStack_9a;
  undefined8 uStack_98;
  undefined auStack_90 [16];
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined8 uStack_60;
  ulonglong uStack_58;
  
  uStack_58 = _DAT_ ^ (ulonglong)auStack_2e8;
  lVar13 = param_4[6];
  piStack_138 = param_5;
  ppbStack_168 = param_7;
  bVar14 = *(byte *)(param_7 + 2);
  psStack_1f8 = param_8;
  uStack_1ac = bVar14 & 1;
  pbStack_100 = (byte *)0x0;
  uStack_104 = 0;
  uStack_ea = 0;
  uStack_e8 = 0;
  iStack_1a8 = (bVar14 & 2) << 0x15;
  sStack_108 = -1;
  uStack_d4 = 0xffffffff;
  uStack_e0 = 0;
  uStack_de = 0;
  uStack_dc = 0;
  uStack_da = 0;
  lStack_148 = (ulonglong)*(uint6 *)(param_2 + 10) << 0x10;
  uStack_f8 = (byte **)0x0;
  puStack_210 = (ushort *)0x0;
  plStack_1f0 = param_4;
  lStack_188 = lVar13;
  puStack_178 = param_2;
  uStack_150 = param_3;
  pplStack_140 = param_1;
  if ((bVar14 & 4) != 0) {
    uStack_2c8 = (short *)0x148b008;
    (*_DAT_)(1,0x1490a88,0x145ac50,0xcf);
  }
  lVar9 = _DAT_;
  plVar31 = *param_1;
  uVar2 = *(undefined2 *)(lVar13 + 0x6b8);
  uStack_200 = param_6;
  if (_DAT_ != 0) {
    LOCK();
    plVar20 = (longlong *)(_DAT_ + 0x10);
    lVar22 = *plVar20;
    *plVar20 = *plVar20 + 1;
    UNLOCK();
    puVar29 = (ulonglong *)
              (((ulonglong)*(uint *)(lVar9 + 4) & lVar22 + 1U & 0xffffffff) * 0x60 +
              *(longlong *)(lVar9 + 0x18));
    *puVar29 = lVar22 + 1U;
    *(undefined2 *)(puVar29 + 1) = uVar2;
    *(undefined4 *)((longlong)puVar29 + 10) = *(undefined4 *)(plVar31 + 0xe);
    *(undefined2 *)((longlong)puVar29 + 0xe) = *(undefined2 *)((longlong)plVar31 + 0x74);
    *(short *)(puVar29 + 2) = (short)param_6;
    *(undefined4 *)((longlong)puVar29 + 0x14) = 3;
    *(undefined4 *)(puVar29 + 3) = *(undefined4 *)(param_4 + 5);
    *(undefined2 *)((longlong)puVar29 + 0x1c) = *(undefined2 *)((longlong)param_4 + 0x2c);
    plVar31 = *param_1;
  }
  lVar9 = func_0x(_DAT_,plVar31,1,0);
  *(ushort *)(lVar9 + 4) = *(ushort *)(lVar9 + 4) & 0xedff;
  *(undefined4 *)(lVar9 + 0x40) = 1;
  plVar31 = *param_1;
  lStack_1e8 = lVar9;
  if (*(short *)((longlong)plVar31 + 0x2c) != 2) {
    lVar22 = plVar31[0x12];
    if (lVar22 == 0) {
      func_0x(plVar31);
      lVar22 = plVar31[0x12];
      plVar31 = *param_1;
    }
    if (((*(byte *)(*(longlong *)(lVar22 + 0x6b0) + 0x3c) & 1) != 0) &&
       (*(longlong *)(*(longlong *)(lVar22 + 0x6b0) + 0x280) == 0)) {
      lVar22 = plVar31[0x12];
      if (lVar22 == 0) {
        func_0x(plVar31);
        lVar22 = plVar31[0x12];
      }
      cVar5 = func_0x(lVar22);
      if (cVar5 == '\0') goto LAB_;
    }
    plVar31 = *param_1;
    lVar22 = plVar31[0x12];
    if (lVar22 == 0) {
      func_0x(plVar31);
      lVar22 = plVar31[0x12];
    }
    if ((*(byte *)(lVar22 + 0x1cd0) & 0x20) == 0) {
      lVar22 = **param_1;
      if (*(short *)(lVar22 + 0x24) == 0) {
LAB_:
        uStack_1e0 = *(undefined8 *)(lVar22 + 0x28);
        uStack_1d8 = *(ushort *)(lVar22 + 0x30);
      }
      else {
        cVar5 = *(char *)(lVar22 + 1);
        if (cVar5 == '\v') {
          if (*(int *)(lVar22 + 0x18) != 99) {
LAB_:
            if (cVar5 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar5 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar22 + 0x18) != 99) goto LAB_;
        }
        uStack_1a4 = *(undefined4 *)(lVar22 + 0x20);
        uStack_1a0 = *(undefined2 *)(lVar22 + 0x24);
        cVar5 = func_0x(&uStack_1a4);
        if (cVar5 == '\0') goto LAB_;
        func_0x(lVar22,&uStack_1e0);
      }
      uVar15 = uStack_1d8;
      plVar31 = *param_1;
      lVar22 = plVar31[0x12];
      if (lVar22 == 0) {
        func_0x(plVar31);
        lVar22 = plVar31[0x12];
      }
      lVar10 = func_0x
                         (*(undefined8 *)(lVar22 + 0x6a0),*(undefined2 *)((longlong)plVar31 + 0x74),
                          0);
      plVar31 = *param_1;
      lVar22 = plVar31[0x12];
      if (lVar22 == 0) {
        func_0x(plVar31);
        lVar22 = plVar31[0x12];
        plVar31 = *param_1;
      }
      if (*(int *)(*(longlong *)(lVar22 + 0x7a8) + 0x58) == 0) {
        if ((uint)uStack_1e0 < *(uint *)(lVar10 + 0x130)) goto LAB_;
        if (*(uint *)(lVar10 + 0x130) == (uint)uStack_1e0) {
          if ((uStack_1e0._4_4_ < *(uint *)(lVar10 + 0x134)) ||
             ((*(uint *)(lVar10 + 0x134) == uStack_1e0._4_4_ &&
              (uVar15 < *(ushort *)(lVar10 + 0x138))))) goto LAB_;
        }
      }
      else {
LAB_:
        lVar22 = plVar31[0x12];
        if (lVar22 == 0) {
          func_0x(plVar31);
          lVar22 = plVar31[0x12];
          plVar31 = *param_1;
        }
        if (((*(byte *)(*(longlong *)(lVar22 + 0x6b0) + 0x3c) & 1) == 0) ||
           (*(longlong *)(*(longlong *)(lVar22 + 0x6b0) + 0x280) != 0)) {
          lVar22 = plVar31[0x12];
          plVar20 = plVar31;
          if (lVar22 == 0) {
            func_0x(plVar31);
            plVar20 = *param_1;
            lVar22 = plVar31[0x12];
          }
          func_0x(lVar22,*plVar20 + 0x20);
          param_4 = plStack_1f0;
          goto LAB_;
        }
      }
      lVar22 = plVar31[0x12];
      if (lVar22 == 0) {
        func_0x(plVar31);
        lVar22 = plVar31[0x12];
        plVar31 = *param_1;
      }
      param_4 = plStack_1f0;
      if ((*(int *)(*(longlong *)(lVar22 + 0x7a8) + 0x110) != 0) &&
         (lVar22 = *plVar31, uVar16 = *(uint *)(lVar22 + 0x20) & 0xfffffff8,
         uVar16 != (uVar16 / 0x7cd00) * 0x7cd00)) {
        lVar10 = plVar31[0x12];
        if (lVar10 == 0) {
          func_0x(plVar31);
          lVar10 = plVar31[0x12];
          lVar22 = **param_1;
        }
        func_0x(*(undefined8 *)(lVar10 + 0x7a8),lVar22 + 0x20);
        param_4 = plStack_1f0;
      }
    }
  }
LAB_:
  lVar22 = **param_1;
  if ((*(ushort *)(lVar22 + 4) & 0x2000) != 0) {
    if (*(short *)(lVar22 + 0x24) == 0) {
LAB_:
      uStack_1d0 = *(undefined8 *)(lVar22 + 0x28);
      uStack_1c8 = *(ushort *)(lVar22 + 0x30);
    }
    else {
      cVar5 = *(char *)(lVar22 + 1);
      if (cVar5 == '\v') {
        if (*(int *)(lVar22 + 0x18) != 99) {
LAB_:
          if (cVar5 != '\t') goto LAB_;
          goto LAB_;
        }
      }
      else {
        if (cVar5 != '\b') goto LAB_;
LAB_:
        if (*(int *)(lVar22 + 0x18) != 99) goto LAB_;
      }
      uStack_19c = *(undefined4 *)(lVar22 + 0x20);
      uStack_198 = *(undefined2 *)(lVar22 + 0x24);
      cVar5 = func_0x(&uStack_19c);
      if (cVar5 == '\0') goto LAB_;
      func_0x(lVar22,&uStack_1d0);
    }
    uVar15 = uStack_1c8;
    plVar31 = *param_1;
    lVar22 = plVar31[0x12];
    if (lVar22 == 0) {
      func_0x(plVar31);
      lVar22 = plVar31[0x12];
    }
    puVar3 = *(uint **)(*(longlong *)(lVar22 + 0x6b0) + 0x2c0);
    if (((*(short *)((longlong)puVar3 + 10) != 2) || ((uint)uStack_1d0 != 0)) &&
       ((uint)uStack_1d0 <= *puVar3)) {
      if ((uint)uStack_1d0 == *puVar3) {
        if ((puVar3[1] < uStack_1d0._4_4_) ||
           ((uStack_1d0._4_4_ == puVar3[1] && (*(ushort *)(puVar3 + 2) < uVar15))))
        goto LAB_;
      }
      func_0x(param_1);
    }
  }
LAB_:
  cVar5 = (**(code **)*param_4)(param_4);
  if (cVar5 != '\0') {
    bVar14 = **(byte **)(param_8 + 4) >> 1;
    if (*param_8 == 0) {
      bVar14 = **(byte **)(param_8 + 4) >> 6;
    }
    if ((bVar14 & 1) != 0) {
      plVar31 = *param_1;
      lVar22 = plVar31[0x12];
      if (lVar22 == 0) {
        func_0x(plVar31);
        lVar22 = plVar31[0x12];
      }
      if (*(ushort *)(lVar22 + 0x67e) < 0x387) {
        uVar15 = (ushort)(byte)~(*(byte *)(*plVar31 + 2) >> 6);
      }
      else {
        uVar15 = (ushort)~*(ushort *)((longlong)plVar31 + 0x62) >> 8;
      }
      if ((uVar15 & 1) != 0) {
        func_0x(param_1,1,param_4);
      }
    }
  }
  uStack_128 = *(undefined4 *)ppbStack_168;
  uStack_124 = *(undefined4 *)((longlong)ppbStack_168 + 4);
  uStack_120 = *(undefined4 *)(ppbStack_168 + 1);
  uStack_11c = *(undefined4 *)((longlong)ppbStack_168 + 0xc);
  pbStack_118 = ppbStack_168[2];
  iVar8 = func_0x(param_1,param_4,&uStack_128);
  uVar16 = 9;
  uStack_218 = 9;
  ppbVar24 = ppbStack_168;
  psVar11 = psStack_1f8;
  if (iVar8 != 0) {
    plVar31 = *param_1;
    lVar22 = plVar31[0x12];
    if (lVar22 == 0) {
      func_0x(plVar31);
      lVar22 = plVar31[0x12];
    }
    if (*(ushort *)(lVar22 + 0x67e) < 0x387) {
      uVar15 = (ushort)(byte)~(*(byte *)(*plVar31 + 2) >> 6);
    }
    else {
      uVar15 = (ushort)~*(ushort *)((longlong)plVar31 + 0x62) >> 8;
    }
    if (((uVar15 & 1) != 0) && (cVar5 = (**(code **)(*param_4 + 0x88))(param_4), cVar5 == '\0')) {
      func_0x(param_1,1,param_4);
    }
    if ((*(byte *)(param_4 + 0x43) & 4) != 0) {
      param_4 = (longlong *)(**(code **)(*param_4 + 0x1e8))(param_4);
    }
    puVar37 = (ushort *)(psStack_1f8 + 1);
    puStack_210 = puVar37;
    if (*psStack_1f8 == 0) {
      func_0x();
    }
    else {
      func_0x(puVar37,param_4 + 5);
    }
    uStack_d4 = uStack_200;
    if (*(char *)(lVar9 + 2) < '\0') {
      pbVar21 = (byte *)(lVar9 + 0x60);
      if ((sStack_108 == 0) || (ppbVar24 = uStack_f8, uStack_f8 == (byte **)0x0)) {
        ppbVar24 = (byte **)auStack_d0;
        stack0xffffffffffffff42 = SUB1614(ZEXT816(0),2);
        auStack_c0._0_2_ = 0xffff;
        uStack_a8 = 0;
        uStack_9a = 0;
        uStack_b8 = 0;
        uStack_a2 = 0;
        uStack_a0 = 0;
        uStack_98 = 0;
        uStack_b0 = 0;
        auStack_90 = ZEXT816(0);
        auStack_70._0_12_ = ZEXT812(0);
        auStack_70._12_4_ = 0;
        uStack_60 = 0;
        auStack_80 = ZEXT816(0);
        auStack_d0 = ZEXT816(0);
      }
      if (*(short *)(lVar9 + 0x24) == 0) {
LAB_:
        uStack_1c0 = *(undefined8 *)(lVar9 + 0x28);
        uStack_1b8 = *(undefined2 *)(lVar9 + 0x30);
      }
      else {
        cVar5 = *(char *)(lVar9 + 1);
        if (cVar5 == '\v') {
          if (*(int *)(lVar9 + 0x18) != 99) {
LAB_:
            if (cVar5 != '\t') goto LAB_;
            goto LAB_;
          }
        }
        else {
          if (cVar5 != '\b') goto LAB_;
LAB_:
          if (*(int *)(lVar9 + 0x18) != 99) goto LAB_;
        }
        uStack_194 = *(undefined4 *)(lVar9 + 0x20);
        uStack_190 = *(undefined2 *)(lVar9 + 0x24);
        cVar5 = func_0x(&uStack_194);
        if (cVar5 == '\0') goto LAB_;
        func_0x(lVar9,&uStack_1c0);
      }
      *ppbVar24 = pbVar21;
      *(undefined4 *)(ppbVar24 + 0xc) = (undefined4)uStack_1c0;
      *(undefined2 *)(ppbVar24 + 0xd) = uStack_1b8;
      *(int *)((longlong)ppbVar24 + 100) = (int)((ulonglong)uStack_1c0 >> 0x20);
      *(undefined4 *)((longlong)ppbVar24 + 0x6c) = *(undefined4 *)(lVar9 + 0x20);
      *(undefined2 *)(ppbVar24 + 0xe) = *(undefined2 *)(lVar9 + 0x24);
      *(undefined2 *)((longlong)ppbVar24 + 0x72) = 0;
      uStack_208 = *(int *)((ulonglong)*pbVar21 * 6 + 0x10cf4b0);
      uVar36 = (ulonglong)*(short *)((ulonglong)*pbVar21 * 6 + 0x10cf4b4);
      *(undefined2 *)(ppbVar24 + 2) = 0xffff;
      ppbVar24[3] = (byte *)0x0;
      uVar18 = 0;
      *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
      *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
      ppbVar24[7] = (byte *)0x0;
      ppbVar24[4] = (byte *)0x0;
      ppbVar24[9] = (byte *)0x0;
      ppbVar24[10] = (byte *)0x0;
      *(undefined2 *)(ppbVar24 + 0xb) = 0;
      if ((**ppbVar24 & 2) != 0) {
        pbVar1 = pbVar21 + uVar36;
        if ((pbVar21[uVar36] & 1) == 0) {
          *(undefined2 *)(ppbVar24 + 2) = 0;
          ppbVar24[3] = pbVar1;
          *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
          *(undefined4 *)((longlong)ppbVar24 + 0x36) = 0;
          switch(*pbVar1 & 0xe) {
          default:
            uVar18 = (uint)*(ushort *)(pbVar1 + 2);
            if (0x1f9d < *(ushort *)(pbVar1 + 2) - 1) {
              func_0x(pbVar1,6);
            }
            break;
          case 4:
            uVar18 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar18 = 1;
          }
          *(uint *)(ppbVar24 + 4) = uVar18;
          *(undefined8 *)((longlong)ppbVar24 + 0x2e) = 0;
        }
        else {
          *(undefined2 *)(ppbVar24 + 2) = 1;
          ppbVar24[3] = pbVar1;
          bVar14 = *pbVar1;
          switch(bVar14 & 0x1c) {
          default:
            if ((char)pbVar1[1] < '\0') {
              uVar15 = *(ushort *)(pbVar1 + 1);
              sVar6 = 3;
              *(ushort *)((longlong)ppbVar24 + 0x12) = uVar15;
              uVar15 = (uVar15 & 0x7f) << 8 | uVar15 >> 8;
            }
            else {
              sVar6 = 2;
              uVar15 = (ushort)pbVar1[1];
            }
            *(ushort *)((longlong)ppbVar24 + 0x12) = uVar15;
            *(short *)(ppbVar24 + 5) = sVar6;
            uVar15 = *(ushort *)((longlong)ppbVar24 + 0x12);
            *(short *)((longlong)ppbVar24 + 0x2c) = (short)(uVar15 + 1 >> 1) + sVar6;
            if (uVar15 < 0x1f) {
              *(undefined2 *)((longlong)ppbVar24 + 0x2a) = 0;
              *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
              *(undefined4 *)(ppbVar24 + 8) = 0;
              ppbVar24[7] = (byte *)0x0;
              ppbVar24[4] = (byte *)0x0;
            }
            else {
              iVar8 = uVar15 - 1;
              *(short *)((longlong)ppbVar24 + 0x2a) =
                   ((short)(iVar8 / 0x1e) + (short)(iVar8 >> 0x1f)) -
                   (short)((longlong)iVar8 * 0x88888889 >> 0x3f);
              *(undefined4 *)((longlong)ppbVar24 + 0x14) = 0;
              *(undefined4 *)(ppbVar24 + 8) = 0;
              ppbVar24[7] = (byte *)0x0;
              ppbVar24[4] = (byte *)0x0;
            }
            break;
          case 4:
            if (((bVar14 & 0x1c) != 4) || (uVar23 = 1, (bVar14 & 2) == 0)) {
              uVar23 = uVar18;
            }
            if (uVar23 == 0) {
              uVar17 = 1;
            }
            else {
              *(undefined4 *)(ppbVar24 + 8) = 0;
              uVar17 = 0xf;
            }
            ppbVar24[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
            ppbVar24[6] = (byte *)0x0;
            ppbVar24[4] = (byte *)0x0;
            ppbVar24[7] = (byte *)0x0;
            ppbVar24[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar24 + 0x14) = uVar17;
            *(uint *)(ppbVar24 + 8) = (uint)(uVar23 != 0);
            ppbVar24[7] = (byte *)0x0;
            ppbVar24[4] = (byte *)0x0;
            break;
          case 8:
            ppbVar24[7] = (byte *)0x0;
            ppbVar24[7] = (byte *)0x0;
            ppbVar24[5] = (byte *)0x0;
            *(undefined2 *)((longlong)ppbVar24 + 0x12) = 0;
            ppbVar24[6] = (byte *)0x0;
            ppbVar24[4] = (byte *)0x0;
            ppbVar24[3] = pbVar1;
            *(undefined4 *)((longlong)ppbVar24 + 0x14) = 9;
            *(undefined4 *)(ppbVar24 + 8) = 0;
            ppbVar24[4] = (byte *)0x0;
          }
        }
      }
      if ((**ppbVar24 & 4) != 0) {
        if (uStack_208._2_2_ != 0) {
          uVar36 = (ulonglong)*(ushort *)(lVar9 + 0x61 + (longlong)uStack_208._2_2_ * 2);
        }
        psVar11 = (short *)(pbVar21 + uVar36);
        ppbVar24[9] = (byte *)psVar11;
        sVar6 = *psVar11;
        ppbVar24[10] = (byte *)(psVar11 + 1);
        *(short *)(ppbVar24 + 0xb) = (sVar6 + 1) * 2;
      }
      lVar9 = lStack_1e8;
      if (ppbVar24[1] != (byte *)0x0) {
        func_0x(ppbVar24[1],ppbVar24);
        lVar9 = lStack_1e8;
      }
    }
    else {
      ppbVar24 = (byte **)0x0;
    }
    uVar18 = (uint)*(ushort *)(lVar9 + 0xe);
    pbStack_100 = (byte *)((ulonglong)*(ushort *)(lVar9 + (0xfff - (longlong)(int)uStack_200) * 2) +
                          lVar9);
    if ((*pbStack_100 & 1) == 0) {
      sStack_108 = 0;
      uStack_104 = 0;
      uStack_e2 = 0;
      uStack_e0 = 0;
      uStack_258 = 0;
      switch(*pbStack_100 & 0xe) {
      default:
        uVar18 = (uint)*(ushort *)(pbStack_100 + 2);
        if (0x1f9d < *(ushort *)(pbStack_100 + 2) - 1) {
          func_0x(pbStack_100,6);
        }
        break;
      case 4:
        uVar18 = 9;
        break;
      case 6:
      case 10:
        break;
      case 0xe:
        uVar18 = 1;
      }
      uStack_f8 = (byte **)CONCAT44(uStack_f8._4_4_,uVar18);
      ppbVar24 = (byte **)(ulonglong)uVar18;
      uStack_ea = (undefined2)(lVar9 + 0x2000);
      uStack_e8 = (undefined6)((ulonglong)(lVar9 + 0x2000) >> 0x10);
      uStack_258 = uStack_104;
    }
    else {
      sStack_108 = 1;
      bVar14 = *pbStack_100;
      switch(bVar14 & 0x1c) {
      default:
        if ((char)pbStack_100[1] < '\0') {
          uStack_106 = (*(ushort *)(pbStack_100 + 1) & 0x7f) << 8 |
                       *(ushort *)(pbStack_100 + 1) >> 8;
          uStack_f0._0_2_ = 3;
          sVar6 = 3;
        }
        else {
          uStack_106 = (ushort)pbStack_100[1];
          uStack_f0._0_2_ = 2;
          sVar6 = 2;
        }
        uStack_ec = ((ushort)(uStack_106 + 1) >> 1) + sVar6;
        if (uStack_106 < 0x1f) {
          uStack_f0._2_2_ = 0;
        }
        else {
          iVar8 = uStack_106 - 1;
          uStack_f0._2_2_ =
               ((short)(iVar8 / 0x1e) + (short)(iVar8 >> 0x1f)) -
               (short)((longlong)iVar8 * 0x88888889 >> 0x3f);
        }
        uStack_258 = 0;
        uStack_104 = 0;
        uStack_d8 = 0;
        break;
      case 4:
        if (((bVar14 & 0x1c) == 4) && ((bVar14 & 2) != 0)) {
          uVar16 = 0xf;
          uStack_104 = 0xf;
          uStack_d8 = 1;
          goto code_r0x00100cad;
        }
        uStack_f0._0_2_ = 0;
        uStack_f0._2_2_ = 0;
        uStack_ec = 0;
        uStack_ea = 0;
        uStack_106 = 0;
        uStack_e8 = 0;
        uStack_e2 = 0;
        uStack_258 = 1;
        uStack_104 = 1;
        uStack_d8 = 0;
        break;
      case 8:
        uStack_104 = 9;
        uStack_d8 = 0;
code_r0x00100cad:
        uStack_e2 = 0;
        uStack_e8 = 0;
        uStack_ea = 0;
        uStack_ec = 0;
        uStack_f0._2_2_ = 0;
        uStack_f0._0_2_ = 0;
        uStack_106 = 0;
        uStack_258 = uVar16;
      }
      lVar9 = lVar9 + 0x2000;
      uStack_e0 = (undefined2)lVar9;
      uStack_de = (ushort)((ulonglong)lVar9 >> 0x10);
      uStack_dc = (ushort)((ulonglong)lVar9 >> 0x20);
      uStack_da = (undefined2)((ulonglong)lVar9 >> 0x30);
      uStack_f8 = ppbVar24;
    }
    uVar16 = uStack_258;
    if (sStack_108 == 0) {
      pbVar21 = pbStack_100;
      if (uStack_258 == 0) {
        uStack_106 = 0;
        uStack_258 = (uint)ppbVar24;
        uVar36 = (ulonglong)ppbVar24 & 0xffffffff;
        if ((*pbStack_100 & 0x10) != 0) {
          uStack_258 = uStack_258 + 2 +
                       (*(ushort *)(pbStack_100 + ((ulonglong)ppbVar24 & 0xffffffff)) + 7 >> 3);
          uVar36 = (ulonglong)uStack_258;
        }
        uStack_f8 = (byte **)CONCAT44(uStack_258,(undefined4)uStack_f8);
        if ((*pbStack_100 & 0x20) == 0) {
          uStack_ec = 0;
          uStack_104 = (uint)uVar36;
          uStack_f0 = (uint)uVar36;
        }
        else {
          puVar32 = (ushort *)(pbStack_100 + uVar36);
          uStack_ec = *puVar32;
          if (uStack_ec == 0) {
            cVar5 = func_0x(0x19e5c60);
            if (((cVar5 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
               (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x80f);
              }
            }
            func_0x(pbStack_100,3);
          }
          uStack_f0 = uStack_f8._4_4_ + 2 + (uint)uStack_ec * 2;
          if (0x1f9e < uStack_f0) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 != '\0') {
              lVar9 = func_0x();
              if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2c8 = (short *)0x0;
                  (*_DAT_)(1,0x12d566c,0x13f5758,0x816);
                }
              }
            }
            func_0x(pbStack_100,4);
          }
          uVar30 = (ulonglong)uStack_ec;
          uStack_258 = puVar32[uVar30] & 0x7fff;
          uStack_104 = uStack_258;
          if (uStack_258 < uStack_f0) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 != '\0') {
              lVar9 = func_0x();
              if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2c8 = (short *)0x0;
                  (*_DAT_)(1,0x12d566c,0x13f5758,0x81d);
                }
              }
            }
            func_0x(pbStack_100,4);
            uVar30 = (ulonglong)uStack_ec;
          }
          uVar34 = (ulonglong)uStack_f0;
          uVar36 = (ulonglong)uStack_104;
          iVar8 = 0;
          pbVar21 = pbStack_100;
          puVar33 = puVar32;
          uStack_258 = uStack_104;
          if ((short)uVar30 != 0) {
            do {
              uVar16 = puVar33[1] & 0x7fff;
              if ((uVar16 < (uint)uVar34) || ((uint)uVar36 < uVar16)) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 != '\0') {
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x19e5c60);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_2c8 = (short *)0x0;
                      (*_DAT_)(1,0x12d566c,0x13f5758,0x82a);
                    }
                  }
                }
                func_0x(pbStack_100,4);
                uVar30 = (ulonglong)uStack_ec;
                uVar36 = (ulonglong)uStack_104;
                pbVar21 = pbStack_100;
              }
              iVar8 = iVar8 + 1;
              uVar34 = (ulonglong)uVar16;
              puVar33 = puVar33 + 1;
            } while (iVar8 < (int)uVar30);
            uVar34 = (ulonglong)uStack_f0;
            uStack_258 = (uint)uVar36;
            lVar13 = lStack_188;
            puVar37 = puStack_210;
          }
          while( true ) {
            if (-1 < (short)puVar32[(ulonglong)((int)uVar30 - 1) + 1]) break;
            uVar27 = uVar34;
            if ((int)uVar30 != 1) {
              uVar27 = (ulonglong)
                       (*(ushort *)(pbVar21 + uVar30 * 2 + (((ulonglong)uStack_f8 >> 0x20) - 2)) &
                       0x7fff);
            }
            uVar18 = *(ushort *)(pbVar21 + uVar30 * 2 + ((ulonglong)uStack_f8 >> 0x20)) & 0x7fff;
            uVar23 = (uint)uVar27;
            if (((uVar23 < (uint)uVar34) || (uVar18 < uVar23)) ||
               (uVar15 = (ushort)uVar30, (uint)uVar36 < uVar18)) {
              func_0x(pbVar21,7);
              uVar36 = (ulonglong)uStack_104;
              uVar34 = (ulonglong)uStack_f0;
              uStack_258 = uStack_104;
              pbVar21 = pbStack_100;
              uVar15 = uStack_ec;
            }
            uVar16 = (uint)uVar36;
            if ((uVar23 < (uint)uVar34) || (uVar16 < uVar23)) goto code_r0x0010156c;
            if (*(ushort *)(pbVar21 + uVar27) == 5) {
              uStack_106 = uStack_106 | 2;
              uStack_ec = uVar15 - 1;
              uStack_de = (ushort)uVar27;
              uVar27 = uVar27 & 0xffff;
              pbVar1 = pbVar21 + uVar27;
              if ((*(ushort *)(pbVar1 + 2) >> 0xe & 1) == 0) {
                uVar15 = uStack_dc & 0xc7ff;
              }
              else {
                uVar15 = uStack_dc ^ (uStack_dc ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
              }
              uStack_dc = (uVar15 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar15;
              pbVar28 = pbVar21 + uVar27 + (ulonglong)((uStack_dc & 0x7ff) * 2) + 4 +
                                           (ulonglong)((uVar15 >> 0xb & 7) * 2);
              if (pbVar28 < pbVar1) {
                func_0x(pbVar1,0x19);
                uVar36 = (ulonglong)uStack_104;
                uVar27 = (ulonglong)uStack_de;
                uStack_258 = uStack_104;
                pbVar21 = pbStack_100;
              }
              if (uVar18 - uVar23 <
                  (((uStack_dc & 0x7ff) * 2 - (int)uVar27) - (int)pbStack_100) + (int)pbVar28) {
                func_0x(pbVar21 + uVar27,0x19);
                uVar36 = (ulonglong)uStack_104;
                uVar27 = (ulonglong)uStack_de;
                uStack_258 = uStack_104;
                pbVar21 = pbStack_100;
              }
              iVar8 = 0;
              if (((uStack_dc & 0x3800) != 0) &&
                 (puVar32 = (ushort *)(pbVar21 + uVar27 + 4), uVar15 = uStack_dc,
                 (uStack_dc & 0x3800) != 0)) {
                do {
                  if ((uVar15 & 0x7ff) < (*puVar32 & 0x7ff)) {
                    func_0x(pbVar21 + uVar27,0x1a);
                    uVar27 = (ulonglong)uStack_de;
                    pbVar21 = pbStack_100;
                    uVar15 = uStack_dc;
                  }
                  iVar8 = iVar8 + 1;
                  puVar32 = puVar32 + 1;
                } while (iVar8 < (int)((uStack_dc & 0x3800) >> 0xb));
                uVar36 = (ulonglong)uStack_104;
                uStack_258 = uStack_104;
              }
              break;
            }
            if (*(ushort *)(pbVar21 + uVar27) < 0x400) break;
            uStack_106 = uStack_106 | 1;
            uStack_ec = uVar15 - 1;
            uVar30 = (ulonglong)uStack_ec;
            if (uStack_ec == 0) break;
          }
        }
        if ((*pbVar21 & 0x40) == 0) {
          uStack_e2 = 0;
          uStack_e0 = 0;
        }
        else {
          uStack_e2 = (undefined2)uVar36;
          uStack_e0 = (undefined2)(uVar36 >> 0x10);
          uStack_104 = (int)uVar36 + 0xe;
          uVar12 = func_0x(&uStack_106);
          func_0x(uVar12,&puStack_180);
          iVar8 = func_0x(&puStack_180);
          uStack_258 = uStack_104 + iVar8;
          uVar36 = (ulonglong)uStack_258;
          pbVar21 = pbStack_100;
          uStack_104 = uStack_258;
        }
        uVar16 = (uint)uVar36;
        if (((byte *)CONCAT62(uStack_e8,uStack_ea) != (byte *)0x0) &&
           ((byte *)CONCAT62(uStack_e8,uStack_ea) < pbVar21 + uVar36)) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar9 = func_0x();
            if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x886);
              }
            }
          }
          func_0x(pbStack_100,0x12);
          uStack_258 = uStack_104;
          pbVar21 = pbStack_100;
          uVar16 = uStack_104;
        }
        if (0x3f3b < uVar16 - 1) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar9 = func_0x();
            if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x88b);
              }
            }
          }
          func_0x(pbStack_100,5);
          uStack_258 = uStack_104;
          pbVar21 = pbStack_100;
          uVar16 = uStack_104;
        }
      }
code_r0x0010156c:
      if (uVar16 < 9) {
        bVar14 = *pbVar21 & 0xe;
        goto joined_r0x00101578;
      }
    }
    else {
      if (uStack_258 == 0) {
        func_0x(&uStack_106);
        uVar16 = uStack_104;
      }
      uStack_258 = uVar16;
      if (uVar16 < 9) {
        bVar14 = *pbStack_100 & 0x1c;
        uStack_f0 = CONCAT22(uStack_f0._2_2_,(undefined2)uStack_f0);
joined_r0x00101578:
        if ((bVar14 == 0) || (bVar14 == 0xc)) {
          uVar16 = 9;
          uStack_258 = uVar16;
        }
      }
    }
    psVar11 = psStack_1f8;
    uVar18 = *(uint *)(puVar37 + 1);
    if (*psStack_1f8 == 0) {
      if (uVar18 == 0) {
        pbVar21 = *(byte **)(puVar37 + 3);
        iVar8 = 0;
        uVar18 = *(uint *)(puVar37 + 7);
        uVar36 = (ulonglong)uVar18;
        *puVar37 = 0;
        *(uint *)(puVar37 + 9) = uVar18;
        bVar14 = *pbVar21;
        if ((bVar14 & 0x10) != 0) {
          uVar18 = uVar18 + 2 + (*(ushort *)(pbVar21 + uVar36) + 7 >> 3);
          uVar36 = (ulonglong)uVar18;
          *(uint *)(puVar37 + 9) = uVar18;
          bVar14 = *pbVar21;
        }
        if ((bVar14 & 0x20) == 0) {
          *(int *)(puVar37 + 1) = (int)uVar36;
          puVar37[0xd] = 0;
          *(int *)(puVar37 + 0xb) = (int)uVar36;
        }
        else {
          puVar32 = (ushort *)(pbVar21 + uVar36);
          uVar15 = *puVar32;
          puVar37[0xd] = uVar15;
          puStack_210 = puVar32;
          if (uVar15 == 0) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 != '\0') {
              lVar9 = func_0x();
              if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_2c8 = (short *)0x0;
                  (*_DAT_)(1,0x12d566c,0x13f5758,0x80f);
                }
              }
            }
            func_0x(*(undefined8 *)(puVar37 + 3),3);
            uVar15 = puVar37[0xd];
            uVar36 = (ulonglong)*(uint *)(puVar37 + 9);
          }
          uVar23 = (uint)uVar15;
          uVar18 = (int)uVar36 + (uVar23 + 1) * 2;
          *(uint *)(puVar37 + 0xb) = uVar18;
          if (0x1f9e < uVar18) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 != '\0') {
              lVar9 = func_0x();
              if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2c8 = (short *)0x0;
                  (*_DAT_)(1,0x12d566c,0x13f5758,0x816);
                }
              }
            }
            func_0x(*(undefined8 *)(puVar37 + 3),4);
            uVar23 = (uint)puVar37[0xd];
            uVar18 = *(uint *)(puVar37 + 0xb);
          }
          uVar26 = puVar32[uVar23] & 0x7fff;
          *(uint *)(puVar37 + 1) = uVar26;
          if (uVar26 < uVar18) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 != '\0') {
              lVar9 = func_0x();
              if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_2c8 = (short *)0x0;
                  (*_DAT_)(1,0x12d566c,0x13f5758,0x81d);
                }
              }
            }
            func_0x(*(undefined8 *)(puVar37 + 3),4);
            uVar18 = *(uint *)(puVar37 + 0xb);
            uVar23 = (uint)puVar37[0xd];
            uVar26 = *(uint *)(puVar37 + 1);
          }
          psVar11 = psStack_1f8;
          puVar33 = puVar32;
          if ((short)uVar23 != 0) {
            do {
              puVar32 = puVar32 + 1;
              uVar25 = *puVar32 & 0x7fff;
              if ((uVar25 < uVar18) || (uVar26 = *(uint *)(puVar37 + 1), uVar26 < uVar25)) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 != '\0') {
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x19e5c60);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_2c8 = (short *)0x0;
                      (*_DAT_)(1,0x12d566c,0x13f5758,0x82a);
                    }
                  }
                }
                func_0x(*(undefined8 *)(puVar37 + 3),4);
                uVar26 = *(uint *)(psVar11 + 2);
              }
              uVar23 = (uint)puVar37[0xd];
              iVar8 = iVar8 + 1;
              lVar13 = lStack_188;
              puVar33 = puStack_210;
              uVar16 = uStack_258;
              uVar18 = uVar25;
            } while (iVar8 < (int)uVar23);
          }
          uVar36 = (ulonglong)uVar26;
          if ((short)puVar33[(ulonglong)(uVar23 - 1) + 1] < 0) {
            pbVar21 = *(byte **)(puVar37 + 3);
            do {
              uVar26 = *(ushort *)
                        (pbVar21 + (ulonglong)uVar23 * 2 + (ulonglong)*(uint *)(puVar37 + 9)) &
                       0x7fff;
              if (uVar23 == 1) {
                uVar25 = *(uint *)(puVar37 + 0xb);
                uVar30 = (ulonglong)uVar25;
code_r0x00101921:
                if ((uVar26 < (uint)uVar30) || (uVar18 = *(uint *)(puVar37 + 1), uVar18 < uVar26))
                goto code_r0x0010192c;
              }
              else {
                uVar25 = *(uint *)(puVar37 + 0xb);
                uVar30 = (ulonglong)
                         (*(ushort *)
                           (pbVar21 +
                           (ulonglong)uVar23 * 2 + ((ulonglong)*(uint *)(puVar37 + 9) - 2)) & 0x7fff
                         );
                if (uVar25 <= (*(ushort *)
                                (pbVar21 +
                                (ulonglong)uVar23 * 2 + ((ulonglong)*(uint *)(puVar37 + 9) - 2)) &
                              0x7fff)) goto code_r0x00101921;
code_r0x0010192c:
                func_0x(pbVar21,7);
                uVar25 = *(uint *)(puVar37 + 0xb);
                uVar18 = *(uint *)(puVar37 + 1);
              }
              uVar36 = (ulonglong)uVar18;
              uVar23 = (uint)uVar30;
              if ((uVar23 < uVar25) || (uVar18 < uVar23)) goto code_r0x00101cb6;
              pbVar21 = *(byte **)(puVar37 + 3);
              if (*(ushort *)(pbVar21 + uVar30) == 5) {
                *puVar37 = *puVar37 | 2;
                puVar37[0xd] = puVar37[0xd] - 1;
                uVar34 = uVar30 & 0xffff;
                puVar37[0x14] = (ushort)uVar30;
                uVar36 = *(ulonglong *)(puVar37 + 3);
                uVar15 = puVar37[0x15] & 0xc7ff;
                if ((*(ushort *)(uVar34 + 2 + uVar36) >> 0xe & 1) != 0) {
                  uVar15 = *(ushort *)(uVar34 + 2 + uVar36) & 0x3800 | puVar37[0x15] & 0xc7ff;
                }
                puVar37[0x15] = uVar15;
                uVar7 = (uVar15 ^ *(ushort *)(uVar34 + 2 + uVar36)) & 0x7ff ^ uVar15;
                puVar37[0x15] = uVar7;
                uVar30 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar34 + (uVar15 >> 0xb & 7) * 2 +
                         uVar36;
                if (uVar30 < uVar34 + uVar36) {
                  func_0x(uVar34 + uVar36,0x19);
                  uVar7 = puVar37[0x15];
                  uVar34 = (ulonglong)puVar37[0x14];
                  uVar36 = (ulonglong)*(uint *)(puVar37 + 3);
                }
                if (uVar26 - uVar23 <
                    (((uVar7 & 0x7ff) * 2 - (int)uVar34) - (int)uVar36) + (int)uVar30) {
                  func_0x(uVar34 + *(longlong *)(puVar37 + 3),0x19);
                  uVar7 = puVar37[0x15];
                }
                if ((uVar7 & 0x3800) != 0) {
                  puVar32 = (ushort *)(*(longlong *)(puVar37 + 3) + (ulonglong)puVar37[0x14] + 4);
                  iVar8 = 0;
                  if ((uVar7 & 0x3800) != 0) {
                    do {
                      if ((uVar7 & 0x7ff) < (*puVar32 & 0x7ff)) {
                        func_0x((ulonglong)puVar37[0x14] + *(longlong *)(puVar37 + 3),0x1a);
                        uVar7 = puVar37[0x15];
                      }
                      iVar8 = iVar8 + 1;
                      puVar32 = puVar32 + 1;
                    } while (iVar8 < (int)(uVar7 >> 0xb & 7));
                  }
                }
                uVar36 = (ulonglong)*(uint *)(puVar37 + 1);
                goto code_r0x00101af5;
              }
              if (*(ushort *)(pbVar21 + uVar30) < 0x400) goto code_r0x00101af5;
              *puVar37 = *puVar37 | 1;
              uVar15 = puVar37[0xd] - 1;
              puVar37[0xd] = uVar15;
              if (uVar15 == 0) goto code_r0x00101af5;
              uVar23 = (uint)uVar15;
            } while ((short)puVar33[(ulonglong)(uVar15 - 1) + 1] < 0);
          }
          else {
code_r0x00101af5:
            pbVar21 = *(byte **)(puVar37 + 3);
          }
        }
        iVar8 = 0;
        if ((*pbVar21 & 0x40) == 0) {
          *(undefined4 *)(puVar37 + 0x12) = 0;
        }
        else {
          *(int *)(puVar37 + 0x12) = *(int *)(puVar37 + 1);
          *(int *)(puVar37 + 1) = *(int *)(puVar37 + 1) + 0xe;
          puVar29 = (ulonglong *)func_0x(puVar37);
          uVar7 = (ushort)(*puVar29 >> 0x30);
          uVar15 = uVar7;
          if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
            uVar15 = uVar7 & 0xdfff;
            if ((uVar7 >> 0xe & 1) != 0) {
              uVar15 = uVar7 | 0x2000;
            }
          }
          if (uVar15 == 0xfffc) {
            iVar8 = (int)((*puVar29 >> 0x20 & 0xffff) >> 5);
          }
          *(int *)(puVar37 + 1) = *(int *)(puVar37 + 1) + iVar8;
          uVar36 = (ulonglong)*(uint *)(puVar37 + 1);
        }
        if ((*(ulonglong *)(puVar37 + 0xe) != 0) &&
           (*(ulonglong *)(puVar37 + 0xe) < uVar36 + *(longlong *)(puVar37 + 3))) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar9 = func_0x();
            if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x886);
              }
            }
          }
          func_0x(*(undefined8 *)(puVar37 + 3),0x12);
          uVar36 = (ulonglong)*(uint *)(puVar37 + 1);
        }
        uVar18 = (uint)uVar36;
        if ((uVar18 == 0) || (0x3f3c < uVar18)) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar9 = func_0x();
            if ((lVar9 != 0) && (*(char *)(lVar9 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x88b);
              }
            }
          }
          func_0x(*(undefined8 *)(puVar37 + 3),5);
          uVar18 = *(uint *)(puVar37 + 1);
        }
      }
code_r0x00101cb6:
      psVar11 = psStack_1f8;
      if ((uVar18 < 9) &&
         (((**(byte **)(puVar37 + 3) & 0xe) == 0 || ((**(byte **)(puVar37 + 3) & 0xe) == 0xc)))) {
        uVar18 = 9;
      }
    }
    else {
      if (uVar18 == 0) {
        func_0x(puVar37);
        uVar18 = *(uint *)(puVar37 + 1);
      }
      if ((uVar18 < 9) &&
         (((**(byte **)(puVar37 + 3) & 0x1c) == 0 || ((**(byte **)(puVar37 + 3) & 0x1c) == 0xc)))) {
        uVar18 = 9;
      }
    }
    if (uVar16 < uVar18) {
      iVar8 = func_0x(pplStack_140,plStack_1f0);
      uVar18 = *(uint *)(puVar37 + 1);
      uStack_208 = iVar8;
      if (*psVar11 == 0) {
        if (uVar18 == 0) {
          pbVar21 = *(byte **)(puVar37 + 3);
          iVar35 = 0;
          uVar18 = *(uint *)(puVar37 + 7);
          uVar36 = (ulonglong)uVar18;
          *puVar37 = 0;
          *(uint *)(puVar37 + 9) = uVar18;
          bVar14 = *pbVar21;
          if ((bVar14 & 0x10) != 0) {
            uVar18 = uVar18 + 2 + (*(ushort *)(pbVar21 + uVar36) + 7 >> 3);
            uVar36 = (ulonglong)uVar18;
            *(uint *)(puVar37 + 9) = uVar18;
            bVar14 = *pbVar21;
          }
          if ((bVar14 & 0x20) == 0) {
            *(int *)(puVar37 + 1) = (int)uVar36;
            puVar37[0xd] = 0;
            *(int *)(puVar37 + 0xb) = (int)uVar36;
          }
          else {
            puVar32 = (ushort *)(pbVar21 + uVar36);
            uVar15 = *puVar32;
            puVar37[0xd] = uVar15;
            puStack_210 = puVar32;
            if (uVar15 == 0) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 != '\0') {
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x19e5c60);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    uStack_2c8 = (short *)0x0;
                    (*_DAT_)(1,0x12d566c,0x13f5758,0x80f);
                  }
                }
              }
              func_0x(*(undefined8 *)(puVar37 + 3),3);
              uVar15 = puVar37[0xd];
              uVar36 = (ulonglong)*(uint *)(puVar37 + 9);
            }
            uVar23 = (uint)uVar15;
            uVar18 = (int)uVar36 + (uVar23 + 1) * 2;
            *(uint *)(puVar37 + 0xb) = uVar18;
            if (0x1f9e < uVar18) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 != '\0') {
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x19e5c60);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_2c8 = (short *)0x0;
                    (*_DAT_)(1,0x12d566c,0x13f5758,0x816);
                  }
                }
              }
              func_0x(*(undefined8 *)(puVar37 + 3),4);
              uVar23 = (uint)puVar37[0xd];
              uVar18 = *(uint *)(puVar37 + 0xb);
            }
            uVar26 = puVar32[uVar23] & 0x7fff;
            *(uint *)(puVar37 + 1) = uVar26;
            if (uVar26 < uVar18) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 != '\0') {
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x19e5c60);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_2c8 = (short *)0x0;
                    (*_DAT_)(1,0x12d566c,0x13f5758,0x81d);
                  }
                }
              }
              func_0x(*(undefined8 *)(puVar37 + 3),4);
              uVar18 = *(uint *)(puVar37 + 0xb);
              uVar23 = (uint)puVar37[0xd];
              uVar26 = *(uint *)(puVar37 + 1);
            }
            psVar11 = psStack_1f8;
            puVar33 = puVar32;
            if ((short)uVar23 != 0) {
              do {
                puVar32 = puVar32 + 1;
                uVar25 = *puVar32 & 0x7fff;
                if ((uVar25 < uVar18) || (uVar26 = *(uint *)(puVar37 + 1), uVar26 < uVar25)) {
                  cVar5 = func_0x(0x19e5c60);
                  if (cVar5 != '\0') {
                    lVar13 = func_0x();
                    if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                      cVar5 = func_0x(0x19e5c60);
                      if (cVar5 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        uStack_2c8 = (short *)0x0;
                        (*_DAT_)(1,0x12d566c,0x13f5758,0x82a);
                      }
                    }
                  }
                  func_0x(*(undefined8 *)(puVar37 + 3),4);
                  uVar26 = *(uint *)(psVar11 + 2);
                }
                uVar23 = (uint)puVar37[0xd];
                iVar35 = iVar35 + 1;
                puVar33 = puStack_210;
                iVar8 = uStack_208;
                uVar16 = uStack_258;
                uVar18 = uVar25;
              } while (iVar35 < (int)uVar23);
            }
            uVar36 = (ulonglong)uVar26;
            if ((short)puVar33[(ulonglong)(uVar23 - 1) + 1] < 0) {
              pbVar21 = *(byte **)(puVar37 + 3);
              do {
                uVar26 = *(ushort *)
                          (pbVar21 + (ulonglong)uVar23 * 2 + (ulonglong)*(uint *)(puVar37 + 9)) &
                         0x7fff;
                if (uVar23 == 1) {
                  uVar25 = *(uint *)(puVar37 + 0xb);
                  uVar30 = (ulonglong)uVar25;
code_r0x00102081:
                  if ((uVar26 < (uint)uVar30) || (uVar18 = *(uint *)(puVar37 + 1), uVar18 < uVar26))
                  goto code_r0x0010208c;
                }
                else {
                  uVar25 = *(uint *)(puVar37 + 0xb);
                  uVar30 = (ulonglong)
                           (*(ushort *)
                             (pbVar21 +
                             (ulonglong)uVar23 * 2 + ((ulonglong)*(uint *)(puVar37 + 9) - 2)) &
                           0x7fff);
                  if (uVar25 <= (*(ushort *)
                                  (pbVar21 +
                                  (ulonglong)uVar23 * 2 + ((ulonglong)*(uint *)(puVar37 + 9) - 2)) &
                                0x7fff)) goto code_r0x00102081;
code_r0x0010208c:
                  func_0x(pbVar21,7);
                  uVar25 = *(uint *)(puVar37 + 0xb);
                  uVar18 = *(uint *)(puVar37 + 1);
                }
                uVar36 = (ulonglong)uVar18;
                uVar23 = (uint)uVar30;
                if ((uVar23 < uVar25) || (uVar18 < uVar23)) goto code_r0x00102416;
                pbVar21 = *(byte **)(puVar37 + 3);
                if (*(ushort *)(pbVar21 + uVar30) == 5) {
                  *puVar37 = *puVar37 | 2;
                  puVar37[0xd] = puVar37[0xd] - 1;
                  uVar34 = uVar30 & 0xffff;
                  puVar37[0x14] = (ushort)uVar30;
                  uVar36 = *(ulonglong *)(puVar37 + 3);
                  uVar15 = puVar37[0x15] & 0xc7ff;
                  if ((*(ushort *)(uVar34 + 2 + uVar36) >> 0xe & 1) != 0) {
                    uVar15 = *(ushort *)(uVar34 + 2 + uVar36) & 0x3800 | puVar37[0x15] & 0xc7ff;
                  }
                  puVar37[0x15] = uVar15;
                  uVar7 = (uVar15 ^ *(ushort *)(uVar34 + 2 + uVar36)) & 0x7ff ^ uVar15;
                  puVar37[0x15] = uVar7;
                  uVar30 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar36 + (uVar15 >> 0xb & 7) * 2 +
                           uVar34;
                  if (uVar30 < uVar34 + uVar36) {
                    func_0x(uVar34 + uVar36,0x19);
                    uVar7 = puVar37[0x15];
                    uVar34 = (ulonglong)puVar37[0x14];
                    uVar36 = (ulonglong)*(uint *)(puVar37 + 3);
                  }
                  if (uVar26 - uVar23 <
                      (((uVar7 & 0x7ff) * 2 - (int)uVar34) - (int)uVar36) + (int)uVar30) {
                    func_0x(uVar34 + *(longlong *)(puVar37 + 3),0x19);
                    uVar7 = puVar37[0x15];
                  }
                  if ((uVar7 & 0x3800) != 0) {
                    puVar32 = (ushort *)(*(longlong *)(puVar37 + 3) + (ulonglong)puVar37[0x14] + 4);
                    iVar35 = 0;
                    if ((uVar7 & 0x3800) != 0) {
                      do {
                        if ((uVar7 & 0x7ff) < (*puVar32 & 0x7ff)) {
                          func_0x((ulonglong)puVar37[0x14] + *(longlong *)(puVar37 + 3),0x1a
                                         );
                          uVar7 = puVar37[0x15];
                        }
                        iVar35 = iVar35 + 1;
                        puVar32 = puVar32 + 1;
                      } while (iVar35 < (int)(uVar7 >> 0xb & 7));
                    }
                  }
                  uVar36 = (ulonglong)*(uint *)(puVar37 + 1);
                  goto code_r0x00102255;
                }
                if (*(ushort *)(pbVar21 + uVar30) < 0x400) goto code_r0x00102255;
                *puVar37 = *puVar37 | 1;
                uVar15 = puVar37[0xd] - 1;
                puVar37[0xd] = uVar15;
                if (uVar15 == 0) goto code_r0x00102255;
                uVar23 = (uint)uVar15;
              } while ((short)puVar33[(ulonglong)(uVar15 - 1) + 1] < 0);
            }
            else {
code_r0x00102255:
              pbVar21 = *(byte **)(puVar37 + 3);
            }
          }
          iVar35 = 0;
          if ((*pbVar21 & 0x40) == 0) {
            *(undefined4 *)(puVar37 + 0x12) = 0;
          }
          else {
            *(int *)(puVar37 + 0x12) = *(int *)(puVar37 + 1);
            *(int *)(puVar37 + 1) = *(int *)(puVar37 + 1) + 0xe;
            puVar29 = (ulonglong *)func_0x(puVar37);
            uVar7 = (ushort)(*puVar29 >> 0x30);
            uVar15 = uVar7;
            if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
              uVar15 = uVar7 & 0xdfff;
              if ((uVar7 >> 0xe & 1) != 0) {
                uVar15 = uVar7 | 0x2000;
              }
            }
            if (uVar15 == 0xfffc) {
              iVar35 = (int)((*puVar29 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)(puVar37 + 1) = *(int *)(puVar37 + 1) + iVar35;
            uVar36 = (ulonglong)*(uint *)(puVar37 + 1);
          }
          if ((*(ulonglong *)(puVar37 + 0xe) != 0) &&
             (*(ulonglong *)(puVar37 + 0xe) < uVar36 + *(longlong *)(puVar37 + 3))) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 != '\0') {
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  uStack_2c8 = (short *)0x0;
                  (*_DAT_)(1,0x12d566c,0x13f5758,0x886);
                }
              }
            }
            func_0x(*(undefined8 *)(puVar37 + 3),0x12);
            uVar36 = (ulonglong)*(uint *)(puVar37 + 1);
          }
          uVar18 = (uint)uVar36;
          if ((uVar18 == 0) || (0x3f3c < uVar18)) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 != '\0') {
              lVar13 = func_0x();
              if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  uStack_2c8 = (short *)0x0;
                  (*_DAT_)(1,0x12d566c,0x13f5758,0x88b);
                }
              }
            }
            func_0x(*(undefined8 *)(puVar37 + 3),5);
            uVar18 = *(uint *)(puVar37 + 1);
          }
        }
code_r0x00102416:
        psVar11 = psStack_1f8;
        if ((uVar18 < 9) &&
           (((**(byte **)(puVar37 + 3) & 0xe) == 0 || ((**(byte **)(puVar37 + 3) & 0xe) == 0xc)))) {
          uVar18 = 9;
        }
      }
      else {
        if (uVar18 == 0) {
          func_0x(puVar37);
          uVar18 = *(uint *)(puVar37 + 1);
        }
        if ((uVar18 < 9) &&
           (((**(byte **)(puVar37 + 3) & 0x1c) == 0 || ((**(byte **)(puVar37 + 3) & 0x1c) == 0xc))))
        {
          uVar18 = 9;
        }
      }
      lVar13 = lStack_188;
      if (iVar8 + uVar16 < uVar18) {
        if (*psVar11 == 0) {
          uVar16 = *(uint *)(puVar37 + 1);
          if (uVar16 == 0) {
            pbVar21 = *(byte **)(puVar37 + 3);
            iVar8 = 0;
            uVar16 = *(uint *)(puVar37 + 7);
            uVar36 = (ulonglong)uVar16;
            *puVar37 = 0;
            *(uint *)(puVar37 + 9) = uVar16;
            bVar14 = *pbVar21;
            if ((bVar14 & 0x10) != 0) {
              uVar16 = uVar16 + 2 + (*(ushort *)(pbVar21 + uVar36) + 7 >> 3);
              uVar36 = (ulonglong)uVar16;
              *(uint *)(puVar37 + 9) = uVar16;
              bVar14 = *pbVar21;
            }
            if ((bVar14 & 0x20) == 0) {
              *(int *)(puVar37 + 1) = (int)uVar36;
              puVar37[0xd] = 0;
              *(int *)(puVar37 + 0xb) = (int)uVar36;
            }
            else {
              puVar32 = (ushort *)(pbVar21 + uVar36);
              uVar15 = *puVar32;
              puVar37[0xd] = uVar15;
              puStack_180 = puVar32;
              if (uVar15 == 0) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 != '\0') {
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x19e5c60);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      uStack_2c8 = (short *)0x0;
                      (*_DAT_)(1,0x12d566c,0x13f5758,0x80f);
                    }
                  }
                }
                func_0x(*(undefined8 *)(puVar37 + 3),3);
                uVar15 = puVar37[0xd];
                uVar36 = (ulonglong)*(uint *)(puVar37 + 9);
              }
              uVar18 = (uint)uVar15;
              uVar16 = (int)uVar36 + (uVar18 + 1) * 2;
              *(uint *)(puVar37 + 0xb) = uVar16;
              if (0x1f9e < uVar16) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 != '\0') {
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x19e5c60);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_2c8 = (short *)0x0;
                      (*_DAT_)(1,0x12d566c,0x13f5758,0x816);
                    }
                  }
                }
                func_0x(*(undefined8 *)(puVar37 + 3),4);
                uVar18 = (uint)puVar37[0xd];
                uVar16 = *(uint *)(puVar37 + 0xb);
              }
              uVar23 = puVar32[uVar18] & 0x7fff;
              *(uint *)(puVar37 + 1) = uVar23;
              if (uVar23 < uVar16) {
                cVar5 = func_0x(0x19e5c60);
                if (cVar5 != '\0') {
                  lVar13 = func_0x();
                  if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                    cVar5 = func_0x(0x19e5c60);
                    if (cVar5 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_2c8 = (short *)0x0;
                      (*_DAT_)(1,0x12d566c,0x13f5758,0x81d);
                    }
                  }
                }
                func_0x(*(undefined8 *)(puVar37 + 3),4);
                uVar16 = *(uint *)(puVar37 + 0xb);
                uVar18 = (uint)puVar37[0xd];
                uVar23 = *(uint *)(puVar37 + 1);
              }
              psVar11 = psStack_1f8;
              puVar33 = puVar32;
              if ((short)uVar18 != 0) {
                do {
                  puVar32 = puVar32 + 1;
                  uVar26 = *puVar32 & 0x7fff;
                  if ((uVar26 < uVar16) || (uVar23 = *(uint *)(puVar37 + 1), uVar23 < uVar26)) {
                    cVar5 = func_0x(0x19e5c60);
                    if (cVar5 != '\0') {
                      lVar13 = func_0x();
                      if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                        cVar5 = func_0x(0x19e5c60);
                        if (cVar5 == '\0') {
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_2c8 = (short *)0x0;
                          (*_DAT_)(1,0x12d566c,0x13f5758,0x82a);
                        }
                      }
                    }
                    func_0x(*(undefined8 *)(puVar37 + 3),4);
                    uVar23 = *(uint *)(psVar11 + 2);
                  }
                  uVar18 = (uint)puVar37[0xd];
                  iVar8 = iVar8 + 1;
                  puVar33 = puStack_180;
                  uVar16 = uVar26;
                } while (iVar8 < (int)uVar18);
              }
              uVar36 = (ulonglong)uVar23;
              if ((short)puVar33[(ulonglong)(uVar18 - 1) + 1] < 0) {
                pbVar21 = *(byte **)(puVar37 + 3);
                do {
                  uVar23 = *(ushort *)
                            (pbVar21 + (ulonglong)uVar18 * 2 + (ulonglong)*(uint *)(puVar37 + 9)) &
                           0x7fff;
                  if (uVar18 == 1) {
                    uVar26 = *(uint *)(puVar37 + 0xb);
                    uVar30 = (ulonglong)uVar26;
code_r0x001027d1:
                    if ((uVar23 < (uint)uVar30) ||
                       (uVar16 = *(uint *)(puVar37 + 1), uVar16 < uVar23)) goto code_r0x001027dc;
                  }
                  else {
                    uVar26 = *(uint *)(puVar37 + 0xb);
                    uVar30 = (ulonglong)
                             (*(ushort *)
                               (pbVar21 +
                               (ulonglong)uVar18 * 2 + ((ulonglong)*(uint *)(puVar37 + 9) - 2)) &
                             0x7fff);
                    if (uVar26 <= (*(ushort *)
                                    (pbVar21 +
                                    (ulonglong)uVar18 * 2 + ((ulonglong)*(uint *)(puVar37 + 9) - 2))
                                  & 0x7fff)) goto code_r0x001027d1;
code_r0x001027dc:
                    func_0x(pbVar21,7);
                    uVar26 = *(uint *)(puVar37 + 0xb);
                    uVar16 = *(uint *)(puVar37 + 1);
                  }
                  uVar36 = (ulonglong)uVar16;
                  uVar18 = (uint)uVar30;
                  if ((uVar18 < uVar26) || (uVar16 < uVar18)) goto code_r0x00102b66;
                  pbVar21 = *(byte **)(puVar37 + 3);
                  if (*(ushort *)(pbVar21 + uVar30) == 5) {
                    *puVar37 = *puVar37 | 2;
                    puVar37[0xd] = puVar37[0xd] - 1;
                    uVar34 = uVar30 & 0xffff;
                    puVar37[0x14] = (ushort)uVar30;
                    uVar36 = *(ulonglong *)(puVar37 + 3);
                    uVar15 = puVar37[0x15] & 0xc7ff;
                    if ((*(ushort *)(uVar34 + 2 + uVar36) >> 0xe & 1) != 0) {
                      uVar15 = *(ushort *)(uVar34 + 2 + uVar36) & 0x3800 | puVar37[0x15] & 0xc7ff;
                    }
                    puVar37[0x15] = uVar15;
                    uVar7 = (uVar15 ^ *(ushort *)(uVar34 + 2 + uVar36)) & 0x7ff ^ uVar15;
                    puVar37[0x15] = uVar7;
                    uVar30 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar34 + (uVar15 >> 0xb & 7) * 2
                             + uVar36;
                    if (uVar30 < uVar34 + uVar36) {
                      func_0x(uVar34 + uVar36,0x19);
                      uVar7 = puVar37[0x15];
                      uVar34 = (ulonglong)puVar37[0x14];
                      uVar36 = (ulonglong)*(uint *)(puVar37 + 3);
                    }
                    if (uVar23 - uVar18 <
                        (((uVar7 & 0x7ff) * 2 - (int)uVar34) - (int)uVar36) + (int)uVar30) {
                      func_0x(uVar34 + *(longlong *)(puVar37 + 3),0x19);
                      uVar7 = puVar37[0x15];
                    }
                    if ((uVar7 & 0x3800) != 0) {
                      puVar32 = (ushort *)
                                (*(longlong *)(puVar37 + 3) + (ulonglong)puVar37[0x14] + 4);
                      iVar8 = 0;
                      if ((uVar7 & 0x3800) != 0) {
                        do {
                          if ((uVar7 & 0x7ff) < (*puVar32 & 0x7ff)) {
                            func_0x((ulonglong)puVar37[0x14] + *(longlong *)(puVar37 + 3),
                                            0x1a);
                            uVar7 = puVar37[0x15];
                          }
                          iVar8 = iVar8 + 1;
                          puVar32 = puVar32 + 1;
                        } while (iVar8 < (int)(uVar7 >> 0xb & 7));
                      }
                    }
                    uVar36 = (ulonglong)*(uint *)(puVar37 + 1);
                    goto code_r0x001029a5;
                  }
                  if (*(ushort *)(pbVar21 + uVar30) < 0x400) goto code_r0x001029a5;
                  *puVar37 = *puVar37 | 1;
                  uVar15 = puVar37[0xd] - 1;
                  puVar37[0xd] = uVar15;
                  if (uVar15 == 0) goto code_r0x001029a5;
                  uVar18 = (uint)uVar15;
                } while ((short)puVar33[(ulonglong)(uVar15 - 1) + 1] < 0);
              }
              else {
code_r0x001029a5:
                pbVar21 = *(byte **)(puVar37 + 3);
              }
            }
            iVar8 = 0;
            if ((*pbVar21 & 0x40) == 0) {
              *(undefined4 *)(puVar37 + 0x12) = 0;
            }
            else {
              *(int *)(puVar37 + 0x12) = *(int *)(puVar37 + 1);
              *(int *)(puVar37 + 1) = *(int *)(puVar37 + 1) + 0xe;
              puVar29 = (ulonglong *)func_0x(puVar37);
              uVar7 = (ushort)(*puVar29 >> 0x30);
              uVar15 = uVar7;
              if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
                uVar15 = uVar7 & 0xdfff;
                if ((uVar7 >> 0xe & 1) != 0) {
                  uVar15 = uVar7 | 0x2000;
                }
              }
              if (uVar15 == 0xfffc) {
                iVar8 = (int)((*puVar29 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)(puVar37 + 1) = *(int *)(puVar37 + 1) + iVar8;
              uVar36 = (ulonglong)*(uint *)(puVar37 + 1);
            }
            if ((*(ulonglong *)(puVar37 + 0xe) != 0) &&
               (*(ulonglong *)(puVar37 + 0xe) < uVar36 + *(longlong *)(puVar37 + 3))) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 != '\0') {
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x19e5c60);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    uStack_2c8 = (short *)0x0;
                    (*_DAT_)(1,0x12d566c,0x13f5758,0x886);
                  }
                }
              }
              func_0x(*(undefined8 *)(puVar37 + 3),0x12);
              uVar36 = (ulonglong)*(uint *)(puVar37 + 1);
            }
            uVar16 = (uint)uVar36;
            if ((uVar16 == 0) || (0x3f3c < uVar16)) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 != '\0') {
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x19e5c60);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    uStack_2c8 = (short *)0x0;
                    (*_DAT_)(1,0x12d566c,0x13f5758,0x88b);
                  }
                }
              }
              func_0x(*(undefined8 *)(puVar37 + 3),5);
              uVar16 = *(uint *)(puVar37 + 1);
            }
          }
code_r0x00102b66:
          if ((8 < uVar16) ||
             (((**(byte **)(puVar37 + 3) & 0xe) != 0 && ((**(byte **)(puVar37 + 3) & 0xe) != 0xc))))
          goto code_r0x00103f5d;
        }
        else {
          uVar16 = *(uint *)(puVar37 + 1);
          if (uVar16 == 0) {
            func_0x(puVar37);
            uVar16 = *(uint *)(puVar37 + 1);
          }
          uStack_218 = uVar16;
          if ((uVar16 < 9) &&
             (((**(byte **)(puVar37 + 3) & 0x1c) == 0 || ((**(byte **)(puVar37 + 3) & 0x1c) == 0xc))
             )) {
            uStack_218 = 9;
            uVar16 = uStack_218;
            goto code_r0x00103f5d;
          }
        }
        uVar16 = uStack_218;
        goto code_r0x00103f5d;
      }
    }
    ppbVar24 = ppbStack_168;
    if ((*(char *)(lVar13 + 0x1cde) != '\0') || (*(char *)(lVar13 + 0x1cd9) != '\0')) {
      *(longlong *)(lVar13 + 0x1a8) = *(longlong *)(lVar13 + 0x1a8) + 1;
    }
    if (((sStack_108 == 0) || (uStack_f8 == (byte **)0x0)) || (*uStack_f8 == (byte *)0x0)) {
      uVar17 = 0;
    }
    else {
      uVar17 = 1;
    }
    puVar19 = (undefined8 *)0x0;
    uStack_288 = &uStack_158;
    uStack_160 = *(undefined4 *)(ppbStack_168 + 1);
    uStack_15c = *(undefined4 *)((longlong)ppbStack_168 + 0xc);
    uStack_278 = 0;
    uStack_280 = 0;
    piStack_290 = &iStack_1b0;
    plStack_298 = (longlong *)((ulonglong)plStack_298 & 0xffffffff00000000);
    uStack_2a0 = 0;
    uStack_2a8 = 0;
    uStack_2b0 = CONCAT44(uStack_2b0._4_4_,uVar17);
    uStack_2b8 = 1;
    uStack_2c8 = &sStack_108;
    uStack_2c0 = 0;
    ppbStack_168 = (byte **)*ppbStack_168;
    func_0x(&ppbStack_168,lStack_148,plStack_1f0,lStack_1e8);
    if (*psVar11 == 0) {
      func_0x(puVar37,&uStack_158);
    }
    else {
      if (*(int *)(puVar37 + 1) == 0) {
        func_0x(puVar37);
      }
      func_0x(puVar37);
      if ((**(byte **)(puVar37 + 3) & 2) != 0) {
        puVar19 = (undefined8 *)(*(byte **)(puVar37 + 3) + *(uint *)(puVar37 + 0x17));
      }
      *puVar19 = uStack_158;
      *(undefined4 *)(puVar37 + 1) = 0;
      func_0x(puVar37);
    }
    if (*psVar11 == 0) {
      puStack_210 = (ushort *)func_0x();
    }
    else {
      func_0x(puVar37);
      if ((**(byte **)(puVar37 + 3) & 2) == 0) {
        puStack_210 = (ushort *)0x0;
      }
      else {
        puStack_210 = (ushort *)(*(byte **)(puVar37 + 3) + *(uint *)(puVar37 + 0x17));
      }
    }
    if (((iStack_1b0 == 2) &&
        (lVar13 = *(longlong *)(*(longlong *)(puStack_178 + 4) + 0x488), lVar13 != 0)) &&
       ((*pcRam0000000000f52fb8 != '\0' && ((bRam00000000019f22f0 & 2) == 0)))) {
      if (*(longlong *)(lVar13 + 0x20) != 0) {
        lVar22 = (ulonglong)*puRam0000000000f53850 +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam0000000000f53848 * 8);
        lVar9 = *(longlong *)(lVar22 + 0x100);
        if (lVar9 == 0) {
          (*pcRam0000000000f53860)(0);
          lVar9 = *(longlong *)(lVar22 + 0x100);
        }
        if (*(longlong *)(lVar9 + 0x260) == 0) {
          uVar36 = 0;
        }
        else {
          uVar36 = (ulonglong)*(uint *)(*(longlong *)(lVar9 + 0x260) + 0xe68);
        }
        if ((uint)uVar36 < *(uint *)(lRam0000000001a11728 + 8)) {
          lVar13 = *(longlong *)(*(longlong *)(lVar13 + 0x20) + uVar36 * 8);
          *(longlong *)(lVar13 + 0x140) = *(longlong *)(lVar13 + 0x140) + 1;
          goto code_r0x00102dfb;
        }
      }
      LOCK();
      plVar31 = (longlong *)(*(longlong *)(lVar13 + 0x18) + 0x140);
      *plVar31 = *plVar31 + 1;
      UNLOCK();
    }
  }
code_r0x00102dfb:
  puVar37 = (ushort *)(psVar11 + 1);
  uVar16 = *(uint *)(psVar11 + 2);
  iVar8 = ((byte)~*(byte *)ppbVar24 & 2) << 0x17;
  uStack_208 = iVar8;
  if (*psVar11 == 0) {
    if (uVar16 == 0) {
      pbVar21 = *(byte **)(psVar11 + 4);
      uVar16 = *(uint *)(psVar11 + 8);
      uVar36 = (ulonglong)uVar16;
      *puVar37 = 0;
      *(uint *)(psVar11 + 10) = uVar16;
      bVar14 = *pbVar21;
      if ((bVar14 & 0x10) != 0) {
        uVar16 = uVar16 + 2 + (*(ushort *)(pbVar21 + uVar36) + 7 >> 3);
        uVar36 = (ulonglong)uVar16;
        *(uint *)(psVar11 + 10) = uVar16;
        bVar14 = *pbVar21;
      }
      iVar35 = (int)uVar36;
      if ((bVar14 & 0x20) == 0) {
        *(int *)(psVar11 + 2) = iVar35;
        psVar11[0xe] = 0;
        *(int *)(psVar11 + 0xc) = iVar35;
      }
      else {
        puVar32 = (ushort *)(pbVar21 + uVar36);
        uVar15 = *puVar32;
        psVar11[0xe] = uVar15;
        puStack_178 = puVar32;
        if (uVar15 == 0) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x80f);
              }
            }
          }
          func_0x(*(undefined8 *)(psVar11 + 4),3);
          uVar15 = psVar11[0xe];
          iVar35 = *(int *)(psVar11 + 10);
        }
        uVar18 = (uint)uVar15;
        uVar16 = iVar35 + (uVar18 + 1) * 2;
        *(uint *)(psVar11 + 0xc) = uVar16;
        if (0x1f9e < uVar16) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x816);
              }
            }
          }
          func_0x(*(undefined8 *)(psVar11 + 4),4);
          uVar18 = (uint)(ushort)psVar11[0xe];
          uVar16 = *(uint *)(psVar11 + 0xc);
        }
        uVar23 = puVar32[uVar18] & 0x7fff;
        *(uint *)(psVar11 + 2) = uVar23;
        if (uVar23 < uVar16) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x81d);
              }
            }
          }
          func_0x(*(undefined8 *)(psVar11 + 4),4);
          uVar16 = *(uint *)(psVar11 + 0xc);
          uVar18 = (uint)(ushort)psVar11[0xe];
          uVar23 = *(uint *)(psVar11 + 2);
        }
        iVar35 = 0;
        puVar33 = puVar32;
        if ((short)uVar18 != 0) {
          do {
            puVar32 = puVar32 + 1;
            uVar26 = *puVar32 & 0x7fff;
            if ((uVar26 < uVar16) || (uVar23 = *(uint *)(psVar11 + 2), uVar23 < uVar26)) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 != '\0') {
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x19e5c60);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_2c8 = (short *)0x0;
                    (*_DAT_)(1,0x12d566c,0x13f5758,0x82a);
                  }
                }
              }
              func_0x(*(undefined8 *)(psVar11 + 4),4);
              uVar23 = *(uint *)(psVar11 + 2);
            }
            uVar18 = (uint)(ushort)psVar11[0xe];
            iVar35 = iVar35 + 1;
            puVar33 = puStack_178;
            iVar8 = uStack_208;
            uVar16 = uVar26;
          } while (iVar35 < (int)uVar18);
        }
        uVar36 = (ulonglong)uVar23;
        if ((short)puVar33[(ulonglong)(uVar18 - 1) + 1] < 0) {
          pbVar21 = *(byte **)(psVar11 + 4);
          do {
            uVar23 = *(ushort *)
                      (pbVar21 + (ulonglong)uVar18 * 2 + (ulonglong)*(uint *)(psVar11 + 10)) &
                     0x7fff;
            if (uVar18 == 1) {
              uVar26 = *(uint *)(psVar11 + 0xc);
              uVar30 = (ulonglong)uVar26;
LAB_:
              if ((uVar23 < (uint)uVar30) || (uVar16 = *(uint *)(psVar11 + 2), uVar16 < uVar23))
              goto LAB_;
            }
            else {
              uVar26 = *(uint *)(psVar11 + 0xc);
              uVar30 = (ulonglong)
                       (*(ushort *)
                         (pbVar21 + (ulonglong)uVar18 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)
                         ) & 0x7fff);
              if (uVar26 <= (*(ushort *)
                              (pbVar21 +
                              (ulonglong)uVar18 * 2 + ((ulonglong)*(uint *)(psVar11 + 10) - 2)) &
                            0x7fff)) goto LAB_;
LAB_:
              func_0x(pbVar21,7);
              uVar26 = *(uint *)(psVar11 + 0xc);
              uVar16 = *(uint *)(psVar11 + 2);
            }
            uVar36 = (ulonglong)uVar16;
            uVar18 = (uint)uVar30;
            if ((uVar18 < uVar26) || (uVar16 < uVar18)) goto LAB_;
            pbVar21 = *(byte **)(psVar11 + 4);
            if (*(ushort *)(pbVar21 + uVar30) == 5) {
              *puVar37 = *puVar37 | 2;
              psVar11[0xe] = psVar11[0xe] + -1;
              uVar34 = uVar30 & 0xffff;
              psVar11[0x15] = (short)uVar30;
              uVar36 = *(ulonglong *)(psVar11 + 4);
              uVar15 = psVar11[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar34 + 2 + uVar36) >> 0xe & 1) != 0) {
                uVar15 = *(ushort *)(uVar34 + 2 + uVar36) & 0x3800 | psVar11[0x16] & 0xc7ffU;
              }
              psVar11[0x16] = uVar15;
              uVar7 = (uVar15 ^ *(ushort *)(uVar34 + 2 + uVar36)) & 0x7ff ^ uVar15;
              psVar11[0x16] = uVar7;
              uVar30 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar34 + (uVar15 >> 0xb & 7) * 2 +
                       uVar36;
              if (uVar30 < uVar34 + uVar36) {
                func_0x(uVar34 + uVar36,0x19);
                uVar7 = psVar11[0x16];
                uVar34 = (ulonglong)(ushort)psVar11[0x15];
                uVar36 = (ulonglong)*(uint *)(psVar11 + 4);
              }
              if (uVar23 - uVar18 <
                  (((uVar7 & 0x7ff) * 2 - (int)uVar34) - (int)uVar36) + (int)uVar30) {
                func_0x(uVar34 + *(longlong *)(psVar11 + 4),0x19);
                uVar7 = psVar11[0x16];
              }
              if ((uVar7 & 0x3800) != 0) {
                puVar32 = (ushort *)
                          (*(longlong *)(psVar11 + 4) + (ulonglong)(ushort)psVar11[0x15] + 4);
                iVar35 = 0;
                if ((uVar7 & 0x3800) != 0) {
                  do {
                    if ((uVar7 & 0x7ff) < (*puVar32 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)psVar11[0x15] + *(longlong *)(psVar11 + 4),
                                      0x1a);
                      uVar7 = psVar11[0x16];
                    }
                    iVar35 = iVar35 + 1;
                    puVar32 = puVar32 + 1;
                  } while (iVar35 < (int)(uVar7 >> 0xb & 7));
                }
              }
              uVar36 = (ulonglong)*(uint *)(psVar11 + 2);
              goto LAB_;
            }
            if (*(ushort *)(pbVar21 + uVar30) < 0x400) goto LAB_;
            *puVar37 = *puVar37 | 1;
            uVar15 = psVar11[0xe] - 1;
            psVar11[0xe] = uVar15;
            if (uVar15 == 0) goto LAB_;
            uVar18 = (uint)uVar15;
          } while ((short)puVar33[(ulonglong)(uVar15 - 1) + 1] < 0);
        }
        else {
LAB_:
          pbVar21 = *(byte **)(psVar11 + 4);
        }
      }
      iVar35 = 0;
      if ((*pbVar21 & 0x40) == 0) {
        *(undefined4 *)(psVar11 + 0x13) = 0;
      }
      else {
        *(int *)(psVar11 + 0x13) = *(int *)(psVar11 + 2);
        *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + 0xe;
        puVar29 = (ulonglong *)func_0x(puVar37);
        uVar7 = (ushort)(*puVar29 >> 0x30);
        uVar15 = uVar7;
        if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
          uVar15 = uVar7 & 0xdfff;
          if ((uVar7 >> 0xe & 1) != 0) {
            uVar15 = uVar7 | 0x2000;
          }
        }
        if (uVar15 == 0xfffc) {
          iVar35 = (int)((*puVar29 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(psVar11 + 2) = *(int *)(psVar11 + 2) + iVar35;
        uVar36 = (ulonglong)*(uint *)(psVar11 + 2);
      }
      if ((*(ulonglong *)(psVar11 + 0xf) != 0) &&
         (*(ulonglong *)(psVar11 + 0xf) < uVar36 + *(longlong *)(psVar11 + 4))) {
        cVar5 = func_0x(0x19e5c60);
        if (cVar5 != '\0') {
          lVar13 = func_0x();
          if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_2c8 = (short *)0x0;
              (*_DAT_)(1,0x12d566c,0x13f5758,0x886);
            }
          }
        }
        func_0x(*(undefined8 *)(psVar11 + 4),0x12);
        uVar36 = (ulonglong)*(uint *)(psVar11 + 2);
      }
      uVar16 = (uint)uVar36;
      if ((uVar16 == 0) || (0x3f3c < uVar16)) {
        cVar5 = func_0x(0x19e5c60);
        if (cVar5 != '\0') {
          lVar13 = func_0x();
          if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_2c8 = (short *)0x0;
              (*_DAT_)(1,0x12d566c,0x13f5758,0x88b);
            }
          }
        }
        func_0x(*(undefined8 *)(psVar11 + 4),5);
        uVar16 = *(uint *)(psVar11 + 2);
      }
    }
LAB_:
    if (uVar16 < 9) {
      bVar14 = **(byte **)(psVar11 + 4) & 0xe;
joined_r0x00103519:
      if ((bVar14 == 0) || (bVar14 == 0xc)) {
        uVar16 = 9;
      }
    }
  }
  else {
    if (uVar16 == 0) {
      func_0x(puVar37);
      uVar16 = *(uint *)(psVar11 + 2);
    }
    if (uVar16 < 9) {
      bVar14 = **(byte **)(psVar11 + 4) & 0x1c;
      goto joined_r0x00103519;
    }
  }
  lVar13 = lStack_1e8;
  uVar27 = 0;
  uVar34 = (ulonglong)(int)uStack_200;
  uStack_24c = 0;
  pbStack_232 = (byte *)0x0;
  uVar30 = 0;
  uVar36 = (ulonglong)*(ushort *)(lStack_1e8 + 0xe);
  uStack_226 = 0;
  uStack_224 = 0;
  uStack_222 = 0;
  pbStack_248 = (byte *)((ulonglong)*(ushort *)(lStack_1e8 + (0xfff - uVar34) * 2) + lStack_1e8);
  uStack_240 = 0;
  if ((*pbStack_248 & 1) == 0) {
    sStack_250 = 0;
    uStack_22a = 0;
    uStack_228 = 0;
    uVar4 = uVar27;
    switch(*pbStack_248 & 0xe) {
    default:
      uVar36 = (ulonglong)*(ushort *)(pbStack_248 + 2);
      uVar4 = uVar30;
      if (0x1f9d < *(ushort *)(pbStack_248 + 2) - 1) {
        func_0x(pbStack_248,6);
        uVar4 = (ulonglong)uStack_24c;
      }
      break;
    case 4:
      uVar36 = 9;
      uVar4 = uVar30;
      break;
    case 6:
    case 10:
      break;
    case 0xe:
      uVar36 = 1;
      uVar4 = uVar30;
    }
    uVar30 = uVar4;
    pbStack_232 = (byte *)(lVar13 + 0x2000);
    uStack_240 = CONCAT44(uStack_240._4_4_,(int)uVar36);
  }
  else {
    sStack_250 = 1;
    bVar14 = *pbStack_248;
    switch(bVar14 & 0x1c) {
    default:
      if ((char)pbStack_248[1] < '\0') {
        uStack_24e = (*(ushort *)(pbStack_248 + 1) & 0x7f) << 8 | *(ushort *)(pbStack_248 + 1) >> 8;
        uStack_258 = CONCAT22(uStack_258._2_2_,3);
        uStack_238 = 3;
        uVar18 = uStack_258;
      }
      else {
        uStack_24e = (ushort)pbStack_248[1];
        uStack_238 = 2;
        uVar18 = 2;
      }
      uStack_234 = ((ushort)(uStack_24e + 1) >> 1) + (short)uVar18;
      if (uStack_24e < 0x1f) {
        lVar13 = lStack_1e8 + 0x2000;
        uStack_228 = (undefined2)lVar13;
        uStack_226 = (ushort)((ulonglong)lVar13 >> 0x10);
        uStack_224 = (ushort)((ulonglong)lVar13 >> 0x20);
        uStack_222 = (undefined2)((ulonglong)lVar13 >> 0x30);
        uStack_220 = 0;
        uVar36 = uVar27;
        uVar30 = uVar27;
      }
      else {
        iVar35 = uStack_24e - 1;
        uStack_220 = 0;
        uVar36 = 0;
        lVar13 = lStack_1e8 + 0x2000;
        uStack_228 = (undefined2)lVar13;
        uStack_226 = (ushort)((ulonglong)lVar13 >> 0x10);
        uStack_224 = (ushort)((ulonglong)lVar13 >> 0x20);
        uStack_222 = (undefined2)((ulonglong)lVar13 >> 0x30);
        uStack_238 = CONCAT22(((short)(iVar35 / 0x1e) + (short)(iVar35 >> 0x1f)) -
                              (short)((longlong)iVar35 * 0x88888889 >> 0x3f),(undefined2)uStack_238)
        ;
      }
      break;
    case 4:
      if (((bVar14 & 0x1c) == 4) && ((bVar14 & 2) != 0)) {
        uVar30 = 0xf;
        uStack_238 = 0;
        lVar13 = lStack_1e8 + 0x2000;
        uStack_24c = 0xf;
        uStack_228 = (undefined2)lVar13;
        uStack_226 = (ushort)((ulonglong)lVar13 >> 0x10);
        uStack_224 = (ushort)((ulonglong)lVar13 >> 0x20);
        uStack_222 = (undefined2)((ulonglong)lVar13 >> 0x30);
        uVar36 = 0;
        uStack_24e = 0;
        uStack_234 = 0;
        uStack_22a = 0;
        uStack_220 = 1;
      }
      else {
        lVar13 = lStack_1e8 + 0x2000;
        uStack_238 = 0;
        uStack_228 = (undefined2)lVar13;
        uStack_226 = (ushort)((ulonglong)lVar13 >> 0x10);
        uStack_224 = (ushort)((ulonglong)lVar13 >> 0x20);
        uStack_222 = (undefined2)((ulonglong)lVar13 >> 0x30);
        uVar30 = 1;
        uStack_24e = 0;
        uVar36 = 0;
        uStack_234 = 0;
        uStack_22a = 0;
        uStack_24c = 1;
        uStack_220 = 0;
      }
      break;
    case 8:
      uVar30 = 9;
      uStack_238 = 0;
      lVar13 = lStack_1e8 + 0x2000;
      uStack_24c = 9;
      uStack_228 = (undefined2)lVar13;
      uStack_226 = (ushort)((ulonglong)lVar13 >> 0x10);
      uStack_224 = (ushort)((ulonglong)lVar13 >> 0x20);
      uStack_222 = (undefined2)((ulonglong)lVar13 >> 0x30);
      uVar36 = 0;
      uStack_24e = 0;
      uStack_234 = 0;
      uStack_22a = 0;
      uStack_220 = 0;
    }
  }
  uVar18 = (uint)uVar30;
  if (sStack_250 == 0) {
    pbVar21 = pbStack_248;
    if (uVar18 == 0) {
      uStack_24e = 0;
      uVar18 = (uint)uVar36;
      uVar30 = uVar36;
      if ((*pbStack_248 & 0x10) != 0) {
        uVar18 = uVar18 + 2 + (*(ushort *)(pbStack_248 + uVar36) + 7 >> 3);
        uVar30 = (ulonglong)uVar18;
      }
      uStack_240 = CONCAT44(uVar18,(undefined4)uStack_240);
      if ((*pbStack_248 & 0x20) == 0) {
        uStack_234 = 0;
        uStack_24c = (uint)uVar30;
        uStack_238 = (uint)uVar30;
      }
      else {
        puVar37 = (ushort *)(pbStack_248 + uVar30);
        uStack_234 = *puVar37;
        if (uStack_234 == 0) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x80f);
              }
            }
          }
          func_0x(pbStack_248,3);
        }
        uStack_238 = uStack_240._4_4_ + 2 + (uint)uStack_234 * 2;
        if (0x1f9e < uStack_238) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x816);
              }
            }
          }
          func_0x(pbStack_248,4);
        }
        uVar36 = (ulonglong)uStack_234;
        uStack_24c = puVar37[uVar36] & 0x7fff;
        if (uStack_24c < uStack_238) {
          cVar5 = func_0x(0x19e5c60);
          if (cVar5 != '\0') {
            lVar13 = func_0x();
            if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                uStack_2c8 = (short *)0x0;
                (*_DAT_)(1,0x12d566c,0x13f5758,0x81d);
              }
            }
          }
          func_0x(pbStack_248,4);
          uVar36 = (ulonglong)uStack_234;
        }
        uVar30 = (ulonglong)uStack_24c;
        pbVar21 = pbStack_248;
        puVar32 = puVar37;
        uVar18 = uStack_238;
        if ((short)uVar36 != 0) {
          do {
            uVar23 = puVar32[1] & 0x7fff;
            if ((uVar23 < uVar18) || ((uint)uVar30 < uVar23)) {
              cVar5 = func_0x(0x19e5c60);
              if (cVar5 != '\0') {
                lVar13 = func_0x();
                if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x19e5c60);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    uStack_2c8 = (short *)0x0;
                    (*_DAT_)(1,0x12d566c,0x13f5758,0x82a);
                  }
                }
              }
              func_0x(pbStack_248,4);
              uVar36 = (ulonglong)uStack_234;
              uVar30 = (ulonglong)uStack_24c;
              pbVar21 = pbStack_248;
            }
            uVar26 = (int)uVar27 + 1;
            uVar27 = (ulonglong)uVar26;
            puVar32 = puVar32 + 1;
            uVar18 = uVar23;
          } while ((int)uVar26 < (int)uVar36);
          uVar34 = (ulonglong)uStack_200;
          uVar18 = uStack_238;
          iVar8 = uStack_208;
        }
        while( true ) {
          if (-1 < (short)puVar37[(ulonglong)((int)uVar36 - 1) + 1]) break;
          uVar23 = uVar18;
          if ((int)uVar36 != 1) {
            uVar23 = *(ushort *)(pbVar21 + uVar36 * 2 + ((uStack_240 >> 0x20) - 2)) & 0x7fff;
          }
          uVar26 = *(ushort *)(pbVar21 + uVar36 * 2 + (uStack_240 >> 0x20)) & 0x7fff;
          if (((uVar23 < uVar18) || (uVar26 < uVar23)) ||
             (uVar15 = (ushort)uVar36, (uint)uVar30 < uVar26)) {
            func_0x(pbVar21,7);
            uVar30 = (ulonglong)uStack_24c;
            pbVar21 = pbStack_248;
            uVar15 = uStack_234;
            uVar18 = uStack_238;
          }
          if ((uVar23 < uVar18) || ((uint)uVar30 < uVar23)) goto code_r0x00103ebe;
          if (*(ushort *)(pbVar21 + uVar23) == 5) {
            uStack_24e = uStack_24e | 2;
            uStack_234 = uVar15 - 1;
            uVar36 = (ulonglong)(uVar23 & 0xffff);
            pbVar1 = pbVar21 + uVar36;
            uStack_226 = (ushort)uVar23;
            uVar15 = *(ushort *)(pbVar1 + 2);
            uVar7 = uStack_224 & 0xc7ff;
            if ((uVar15 >> 0xe & 1) != 0) {
              uVar7 = (uStack_224 ^ uVar15) & 0x3800 ^ uStack_224;
            }
            uStack_224 = (uVar7 ^ uVar15) & 0x7ff ^ uVar7;
            lVar13 = uVar36 + (ulonglong)((uStack_224 & 0x7ff) * 2) + 4 +
                              (ulonglong)((uVar7 >> 0xb & 7) * 2);
            pbVar28 = pbVar21;
            if (pbVar21 + lVar13 < pbVar1) {
              func_0x(pbVar1,0x19);
              uVar36 = (ulonglong)uStack_226;
              uVar30 = (ulonglong)uStack_24c;
              pbVar28 = pbStack_248;
            }
            if (uVar26 - uVar23 <
                (((uStack_224 & 0x7ff) * 2 - (int)uVar36) - (int)pbStack_248) +
                (int)(pbVar21 + lVar13)) {
              func_0x(pbVar28 + uVar36,0x19);
              uVar36 = (ulonglong)uStack_226;
              uVar30 = (ulonglong)uStack_24c;
              pbVar28 = pbStack_248;
            }
            iVar35 = 0;
            pbVar21 = pbVar28;
            if (((uStack_224 & 0x3800) != 0) &&
               (puVar37 = (ushort *)(pbVar28 + uVar36 + 4), uVar15 = uStack_224,
               (uStack_224 & 0x3800) != 0)) {
              do {
                if ((uVar15 & 0x7ff) < (*puVar37 & 0x7ff)) {
                  func_0x(pbVar28 + uVar36,0x1a);
                  uVar36 = (ulonglong)uStack_226;
                  pbVar28 = pbStack_248;
                  uVar15 = uStack_224;
                }
                iVar35 = iVar35 + 1;
                puVar37 = puVar37 + 1;
              } while (iVar35 < (int)((uStack_224 & 0x3800) >> 0xb));
              uVar30 = (ulonglong)uStack_24c;
              pbVar21 = pbVar28;
            }
            break;
          }
          if (*(ushort *)(pbVar21 + uVar23) < 0x400) break;
          uStack_24e = uStack_24e | 1;
          uStack_234 = uVar15 - 1;
          uVar36 = (ulonglong)uStack_234;
          if (uStack_234 == 0) break;
        }
      }
      iVar35 = 0;
      if ((*pbVar21 & 0x40) == 0) {
        uStack_22a = 0;
        uStack_228 = 0;
      }
      else {
        uStack_22a = (undefined2)uVar30;
        uStack_228 = (undefined2)(uVar30 >> 0x10);
        uStack_24c = (int)uVar30 + 0xe;
        puVar29 = (ulonglong *)func_0x(&uStack_24e);
        uVar7 = (ushort)(*puVar29 >> 0x30);
        uVar15 = uVar7;
        if ((((uint)(int)(short)uVar7 >> 1 ^ (int)(short)uVar7) & 0x2000) != 0) {
          uVar15 = uVar7 & 0xdfff;
          if ((uVar7 >> 0xe & 1) != 0) {
            uVar15 = uVar7 | 0x2000;
          }
        }
        if (uVar15 == 0xfffc) {
          iVar35 = (int)((*puVar29 >> 0x20 & 0xffff) >> 5);
        }
        uStack_24c = uStack_24c + iVar35;
        uVar30 = (ulonglong)uStack_24c;
        pbVar21 = pbStack_248;
      }
      if ((pbStack_232 != (byte *)0x0) && (pbStack_232 < pbVar21 + uVar30)) {
        cVar5 = func_0x(0x19e5c60);
        if (cVar5 != '\0') {
          lVar13 = func_0x();
          if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              uStack_2c8 = (short *)0x0;
              (*_DAT_)(1,0x12d566c,0x13f5758,0x886);
            }
          }
        }
        func_0x(pbStack_248,0x12);
        uVar30 = (ulonglong)uStack_24c;
        pbVar21 = pbStack_248;
      }
      if (0x3f3b < (int)uVar30 - 1U) {
        cVar5 = func_0x(0x19e5c60);
        if (cVar5 != '\0') {
          lVar13 = func_0x();
          if ((lVar13 != 0) && (*(char *)(lVar13 + 0x499) != '\0')) {
            cVar5 = func_0x(0x19e5c60);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              uStack_2c8 = (short *)0x0;
              (*_DAT_)(1,0x12d566c,0x13f5758,0x88b);
            }
          }
        }
        func_0x(pbStack_248,5);
        uVar30 = (ulonglong)uStack_24c;
        pbVar21 = pbStack_248;
      }
    }
code_r0x00103ebe:
    uVar18 = (uint)uVar30;
    if ((8 < uVar18) || (((*pbVar21 & 0xe) != 0 && ((*pbVar21 & 0xe) != 0xc)))) {
code_r0x00103ed0:
      uStack_218 = uVar18;
    }
  }
  else {
    if (uVar18 == 0) {
      func_0x(&uStack_24e);
      uVar18 = uStack_24c;
    }
    if ((8 < uVar18) || (((*pbStack_248 & 0x1c) != 0 && ((*pbStack_248 & 0x1c) != 0xc))))
    goto code_r0x00103ed0;
    uStack_218 = 9;
  }
  puStack_260 = puStack_210;
  uStack_268 = 0;
  uStack_270 = 1;
  uStack_278 = 0;
  uStack_280 = 0;
  uStack_288 = (undefined8 *)CONCAT44(uStack_288._4_4_,iVar8);
  piStack_290 = piStack_138;
  plStack_298 = plStack_1f0;
  uStack_2a0 = uStack_1ac;
  uStack_2a8 = CONCAT44(uStack_2a8._4_4_,iStack_1a8);
  uStack_2b0 = *(undefined8 *)(psStack_1f8 + 4);
  uStack_2c0 = uStack_218;
  uStack_2c8 = (short *)((ulonglong)uStack_2c8._4_4_ << 0x20);
  uStack_2b8 = uVar16;
  func_0x(pplStack_140,lStack_148,uStack_150,uVar34 & 0xffffffff);
  uVar16 = uStack_218;
code_r0x00103f5d:
  uStack_218 = uVar16;
  func_0x(uStack_58 ^ (ulonglong)auStack_2e8);
  return;
}

