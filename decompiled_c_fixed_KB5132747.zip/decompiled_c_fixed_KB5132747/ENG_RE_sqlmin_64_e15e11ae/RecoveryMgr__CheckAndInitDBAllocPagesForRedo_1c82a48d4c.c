
void FUN_(longlong *param_1,longlong param_2)

{
  ushort uVar1;
  byte *pbVar2;
  code *UNRECOVERED_JUMPTABLE;
  undefined auStackX_8 [8];
  longlong lStackX_10;
  longlong lStackX_20;
  
  uVar1 = *(ushort *)(param_2 + 0x1c);
  if ((uVar1 != 0) && (uVar1 <= *(ushort *)(*(longlong *)(*param_1 + 0x6a0) + 0x74))) {
    lStackX_20 = *(longlong *)
                  (*(longlong *)(*(longlong *)(*param_1 + 0x6a0) + 0x50) + -8 + (ulonglong)uVar1 * 8
                  );
    if ((lStackX_20 != 0) && ((*(byte *)(lStackX_20 + 100) & 4) == 0)) goto LAB_;
  }
  lStackX_20 = 0;
LAB_:
  lStackX_10 = param_2 + 0x3e;
  pbVar2 = (byte *)func_0x(lStackX_10,0,auStackX_8);
  if ((*pbVar2 & 1) != 0) {
    UNRECOVERED_JUMPTABLE =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x101438) * 4 +
                           0x101428) - 0x18736f0);
                    /* WARNING: Could not emulate address calculation at 0x001000f4 */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
    return;
  }
                    /* WARNING: Could not emulate address calculation at 0x00100253 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x101458) - 0x18736f0))
            ((longlong)(int)(*pbVar2 & 0xe),0xca6e40,pbVar2,pbVar2);
  return;
}

