
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(longlong *param_1,longlong param_2,undefined8 *param_3,undefined4 *param_4)

{
  uint uVar1;
  ulonglong *puVar2;
  longlong lVar3;
  uint uVar4;
  undefined4 auStackX_8 [2];
  ulonglong *puVar5;
  
  puVar5 = (ulonglong *)0x0;
  auStackX_8[0] = 0;
  if (((((*param_1 == 0) || (param_2 == 0)) || (param_3 == (undefined8 *)0x0)) ||
      ((param_4 == (undefined4 *)0x0 || (param_1[0xc] == 0)))) || (*(int *)(param_1 + 0xd) == 0)) {
    lVar3 = 0;
  }
  else {
    *param_3 = 0;
    *param_4 = 0;
    uVar1 = func_0x(param_1,param_2,auStackX_8);
    puVar2 = puVar5;
    if (((param_1[0xc] != 0) && (uVar1 - 1 < 0xfffffffe)) && (*(uint *)(param_1 + 0xd) != 0)) {
      do {
        puVar2 = (ulonglong *)((longlong)puVar5 * 0x58 + param_1[0xc]);
        if (*puVar2 == (ulonglong)uVar1) {
          if (puVar2 != (ulonglong *)0x0) goto LAB_;
          break;
        }
        uVar4 = (int)puVar5 + 1;
        puVar5 = (ulonglong *)(ulonglong)uVar4;
        puVar2 = (ulonglong *)0x0;
      } while (uVar4 < *(uint *)(param_1 + 0xd));
    }
    (*_DAT_)(0xbb,0x38,0x10,0xd,*(undefined4 *)(param_1 + 3));
LAB_:
    *param_3 = *(undefined8 *)(puVar2[2] + *param_1);
    *param_4 = *(undefined4 *)(puVar2[3] + *param_1);
    lVar3 = puVar2[1] + *param_1;
  }
  return lVar3;
}

