
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_(ushort *param_1,undefined8 param_2,int *param_3)

{
  ushort *puVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  int iVar5;
  longlong lVar6;
  undefined8 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  uint uVar10;
  ulonglong uVar11;
  int iVar12;
  ushort uVar13;
  uint uVar14;
  ulonglong uVar15;
  byte *pbVar16;
  ulonglong uVar17;
  ushort *puVar18;
  undefined8 uStackX_8;
  
  iVar5 = 0;
  if (*(int *)(param_1 + 1) == 0) {
    pbVar16 = *(byte **)(param_1 + 3);
    uVar9 = *(uint *)(param_1 + 7);
    uVar11 = (ulonglong)uVar9;
    *param_1 = 0;
    *(uint *)(param_1 + 9) = uVar9;
    bVar2 = *pbVar16;
    if ((bVar2 & 0x10) != 0) {
      uVar9 = uVar9 + 2 + (*(ushort *)(pbVar16 + uVar11) + 7 >> 3);
      uVar11 = (ulonglong)uVar9;
      *(uint *)(param_1 + 9) = uVar9;
      bVar2 = *pbVar16;
    }
    if ((bVar2 & 0x20) == 0) {
      *(int *)(param_1 + 1) = (int)uVar11;
      param_1[0xd] = 0;
      *(int *)(param_1 + 0xb) = (int)uVar11;
    }
    else {
      puVar18 = (ushort *)(pbVar16 + uVar11);
      uVar4 = *puVar18;
      param_1[0xd] = uVar4;
      if (uVar4 == 0) {
        cVar3 = func_0x(0x10ffb30);
        if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
           (*(char *)(lVar6 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10ffb30);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0x9ef53c,0xb0f628,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),3);
        uVar11 = (ulonglong)*(uint *)(param_1 + 9);
        uVar4 = param_1[0xd];
      }
      uVar9 = (int)uVar11 + (uVar4 + 1) * 2;
      *(uint *)(param_1 + 0xb) = uVar9;
      if (0x1f9e < uVar9) {
        cVar3 = func_0x(0x10ffb30);
        if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
           (*(char *)(lVar6 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10ffb30);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ef53c,0xb0f628,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar4 = param_1[0xd];
        uVar9 = *(uint *)(param_1 + 0xb);
      }
      uVar11 = (ulonglong)uVar4;
      uVar4 = puVar18[uVar11];
      *(uint *)(param_1 + 1) = uVar4 & 0x7fff;
      if ((uVar4 & 0x7fff) < uVar9) {
        cVar3 = func_0x(0x10ffb30);
        if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
           (*(char *)(lVar6 + 0x499) != '\0')) {
          cVar3 = func_0x(0x10ffb30);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0x9ef53c,0xb0f628,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 3),4);
        uVar9 = *(uint *)(param_1 + 0xb);
        uVar11 = (ulonglong)param_1[0xd];
      }
      puVar1 = puVar18;
      iVar12 = iVar5;
      if ((short)uVar11 != 0) {
        do {
          uVar14 = puVar1[1] & 0x7fff;
          if ((uVar14 < uVar9) || (*(uint *)(param_1 + 1) < uVar14)) {
            cVar3 = func_0x(0x10ffb30);
            if ((cVar3 != '\0') &&
               ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0')
                ))) {
              cVar3 = func_0x(0x10ffb30);
              if (cVar3 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x9ef53c,0xb0f628,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_1 + 3),4);
          }
          uVar11 = (ulonglong)param_1[0xd];
          iVar12 = iVar12 + 1;
          puVar1 = puVar1 + 1;
          uVar9 = uVar14;
        } while (iVar12 < (int)(uint)param_1[0xd]);
      }
      if ((short)puVar18[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
        pbVar16 = *(byte **)(param_1 + 3);
        do {
          uVar9 = *(ushort *)(pbVar16 + uVar11 * 2 + (ulonglong)*(uint *)(param_1 + 9)) & 0x7fff;
          if ((int)uVar11 == 1) {
            uVar14 = *(uint *)(param_1 + 0xb);
            uVar10 = uVar14;
LAB_:
            if ((uVar9 < uVar14) || (*(uint *)(param_1 + 1) < uVar9)) goto LAB_;
          }
          else {
            uVar10 = *(uint *)(param_1 + 0xb);
            uVar14 = *(ushort *)(pbVar16 + uVar11 * 2 + ((ulonglong)*(uint *)(param_1 + 9) - 2)) &
                     0x7fff;
            if (uVar10 <= uVar14) goto LAB_;
LAB_:
            func_0x(pbVar16,7);
            uVar10 = *(uint *)(param_1 + 0xb);
          }
          if ((uVar14 < uVar10) || (*(uint *)(param_1 + 1) < uVar14)) goto LAB_;
          pbVar16 = *(byte **)(param_1 + 3);
          if (*(ushort *)(pbVar16 + uVar14) == 5) {
            *param_1 = *param_1 | 2;
            param_1[0xd] = param_1[0xd] - 1;
            uVar17 = (ulonglong)(uVar14 & 0xffff);
            param_1[0x14] = (ushort)uVar14;
            uVar11 = *(ulonglong *)(param_1 + 3);
            uVar4 = param_1[0x15] & 0xc7ff;
            if ((*(ushort *)(uVar17 + 2 + uVar11) >> 0xe & 1) != 0) {
              uVar4 = *(ushort *)(uVar17 + 2 + uVar11) & 0x3800 | param_1[0x15] & 0xc7ff;
            }
            param_1[0x15] = uVar4;
            uVar13 = (uVar4 ^ *(ushort *)(uVar17 + 2 + uVar11)) & 0x7ff ^ uVar4;
            param_1[0x15] = uVar13;
            uVar15 = uVar11 + 4 +
                     (ulonglong)((uVar13 & 0x7ff) * 2) + uVar17 + (uVar4 >> 0xb & 7) * 2;
            if (uVar15 < uVar17 + uVar11) {
              func_0x(uVar17 + uVar11,0x19);
              uVar13 = param_1[0x15];
              uVar17 = (ulonglong)param_1[0x14];
              uVar11 = (ulonglong)*(uint *)(param_1 + 3);
            }
            if (uVar9 - uVar14 < (((uVar13 & 0x7ff) * 2 - (int)uVar17) - (int)uVar11) + (int)uVar15)
            {
              func_0x(uVar17 + *(longlong *)(param_1 + 3),0x19);
              uVar13 = param_1[0x15];
            }
            if (((uVar13 & 0x3800) != 0) &&
               (puVar18 = (ushort *)(*(longlong *)(param_1 + 3) + 4 + (ulonglong)param_1[0x14]),
               (uVar13 & 0x3800) != 0)) {
              do {
                if ((uVar13 & 0x7ff) < (*puVar18 & 0x7ff)) {
                  func_0x((ulonglong)param_1[0x14] + *(longlong *)(param_1 + 3),0x1a);
                  uVar13 = param_1[0x15];
                }
                iVar5 = iVar5 + 1;
                puVar18 = puVar18 + 1;
              } while (iVar5 < (int)(uVar13 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar16 + uVar14) < 0x400) goto LAB_;
          *param_1 = *param_1 | 1;
          uVar4 = param_1[0xd] - 1;
          param_1[0xd] = uVar4;
          if (uVar4 == 0) goto LAB_;
          uVar11 = (ulonglong)uVar4;
        } while ((short)puVar18[(ulonglong)(uVar4 - 1) + 1] < 0);
        uVar11 = (ulonglong)*(uint *)(param_1 + 1);
      }
      else {
LAB_:
        pbVar16 = *(byte **)(param_1 + 3);
        uVar11 = (ulonglong)*(uint *)(param_1 + 1);
      }
    }
    if ((*pbVar16 & 0x40) == 0) {
      *(undefined4 *)(param_1 + 0x12) = 0;
    }
    else {
      *(int *)(param_1 + 0x12) = (int)uVar11;
      *(int *)(param_1 + 1) = (int)uVar11 + 0xe;
      puVar7 = (undefined8 *)func_0x(param_1);
      uStackX_8 = *puVar7;
      iVar5 = func_0x(&uStackX_8);
      *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + iVar5;
      uVar11 = (ulonglong)*(uint *)(param_1 + 1);
    }
    iVar5 = (int)uVar11;
    if ((*(ulonglong *)(param_1 + 0xe) != 0) &&
       (*(ulonglong *)(param_1 + 0xe) < uVar11 + *(longlong *)(param_1 + 3))) {
      cVar3 = func_0x(0x10ffb30);
      if ((cVar3 != '\0') &&
         ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0')))) {
        cVar3 = func_0x(0x10ffb30);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          (*_DAT_)(1,0x9ef53c,0xb0f628,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),0x12);
      iVar5 = *(int *)(param_1 + 1);
    }
    if (0x3f3b < iVar5 - 1U) {
      cVar3 = func_0x(0x10ffb30);
      if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
         (*(char *)(lVar6 + 0x499) != '\0')) {
        cVar3 = func_0x(0x10ffb30);
        if (cVar3 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          (*_DAT_)(1,0x9ef53c,0xb0f628,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_1 + 3),5);
    }
  }
LAB_:
  if ((*(byte *)param_1 & 1) == 0) {
    *param_3 = 0;
    return 0;
  }
  uVar4 = param_1[0xd];
  uVar13 = uVar4 + 1;
  iVar5 = func_0x(param_1);
  if (iVar5 != 0) {
    uVar13 = uVar4 + 2;
  }
  lVar6 = *(longlong *)(param_1 + 3);
  uVar9 = *(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar6 + (ulonglong)uVar13 * 2) & 0x7fff;
  if (uVar13 == 1) {
    uVar11 = (ulonglong)*(uint *)(param_1 + 0xb);
LAB_:
    if (((uint)uVar11 <= uVar9) && (uVar9 <= *(uint *)(param_1 + 1))) goto LAB_;
  }
  else {
    uVar14 = *(ushort *)((ulonglong)*(uint *)(param_1 + 9) + lVar6 + -2 + (ulonglong)uVar13 * 2) &
             0x7fff;
    uVar11 = (ulonglong)uVar14;
    if (*(uint *)(param_1 + 0xb) <= uVar14) goto LAB_;
  }
  func_0x(lVar6,7);
  lVar6 = *(longlong *)(param_1 + 3);
LAB_:
  if (lVar6 + uVar11 == 0) {
    puVar8 = (undefined4 *)(*_DAT_)();
    *puVar8 = 0x16;
    (*_DAT_)();
    lVar6 = *(longlong *)(param_1 + 3);
  }
  *param_3 = (uVar9 - (int)uVar11) + -2;
  return lVar6 + 2 + uVar11;
}

