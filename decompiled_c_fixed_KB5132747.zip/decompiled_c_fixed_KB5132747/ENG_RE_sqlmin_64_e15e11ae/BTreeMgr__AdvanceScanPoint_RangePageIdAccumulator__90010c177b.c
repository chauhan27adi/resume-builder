
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int *param_2,longlong *param_3)

{
  byte **ppbVar1;
  byte **ppbVar2;
  int *piVar3;
  byte *pbVar4;
  ushort uVar5;
  undefined2 uVar6;
  char cVar7;
  byte bVar8;
  undefined uVar9;
  undefined2 uVar10;
  int iVar11;
  undefined4 uVar12;
  uint uVar13;
  undefined4 uVar14;
  longlong lVar15;
  ushort *puVar16;
  undefined2 *puVar17;
  byte **ppbVar18;
  ulonglong uVar19;
  longlong lVar20;
  undefined8 uVar21;
  uint uVar22;
  uint *puVar23;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar24;
  undefined4 *puVar25;
  uint uVar26;
  uint uVar27;
  longlong *plVar28;
  longlong *plVar29;
  undefined8 *puVar30;
  int *piVar31;
  longlong **pplVar32;
  longlong lVar33;
  short sVar34;
  ushort uVar35;
  ulonglong uVar36;
  longlong **pplVar37;
  undefined8 uVar38;
  longlong unaff_GS_OFFSET;
  char acStackX_8 [8];
  longlong *plStackX_10;
  char acStackX_18 [4];
  uint uStackX_1c;
  uint auStackX_20 [2];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar15 = func_0x();
  lVar15 = -lVar15;
  *(undefined8 *)(&stack0x00001390 + lVar15) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002390 + lVar15) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar15);
  *(longlong **)(&stack0x00000208 + lVar15) = param_3;
  *(int **)(&stack0x00000328 + lVar15) = param_2;
  *(longlong *)(&stack0x000000c0 + lVar15) = param_1;
  *(longlong *)(&stack0x000008e8 + lVar15) = param_1;
  *(undefined4 *)(&stack0x00000044 + lVar15) = 0;
  *(undefined2 *)(&stack0x00000048 + lVar15) = 0;
  *(undefined8 *)((longlong)&plStackX_10 + lVar15) = 0;
  acStackX_18[lVar15] = '\0';
  uVar22 = *(uint *)((longlong)&uStackX_1c + lVar15);
  *(uint *)((longlong)&uStackX_1c + lVar15) = uVar22 & 0xffff0000;
  *(uint *)((longlong)&uStackX_1c + lVar15) = uVar22 & 0xff000000;
  *(undefined4 *)((longlong)&uStackX_1c + lVar15) = 0;
  acStackX_8[lVar15] = '\x01';
  if (*(int *)(param_1 + 0xd0) != 2) {
LAB_:
    if (acStackX_8[lVar15] != '\0') {
      *(undefined4 **)(&stack0x00001398 + lVar15) = (undefined4 *)(param_1 + 0x170);
      *(undefined4 **)(&stack0x000013a0 + lVar15) = (undefined4 *)(param_1 + 0x16c);
      *(undefined4 *)(param_1 + 0x16c) = 0;
      *(undefined4 *)(param_1 + 0x170) = 0;
      pplVar37 = (longlong **)(param_1 + 0x68);
      *(longlong ***)(&stack0x000013a8 + lVar15) = pplVar37;
      if (((*pplVar37 != (longlong *)0x0) && (*(short *)(param_1 + 0x74) != 1)) ||
         (*(int *)(param_1 + 0x90) != 0)) goto LAB_;
      lVar20 = **(longlong **)(param_1 + 8);
      *(longlong *)(&stack0x00000688 + lVar15) = lVar20;
      *(longlong ***)(&stack0x000013b0 + lVar15) = pplVar37;
      if ((*(int *)(param_1 + 0x80) == -1) && (*(int *)(param_1 + 0x90) == 0)) {
LAB_:
        (&stack0x000018dc)[lVar15] = 0;
        uVar22 = (uint)(*(short *)(*(longlong *)(lVar20 + 8) + 0x3c4) != 1);
        *(uint *)(&stack0x00000778 + lVar15) = uVar22;
        iVar11 = *(int *)(param_1 + 0xf4);
        *(undefined8 *)((longlong)auStackX_20 + lVar15 + -0x20) = 0;
        *(undefined **)(&stack0xfffffffffffffff8 + lVar15) = &stack0x000018c8 + lVar15;
        *(longlong ***)(&stack0xfffffffffffffff0 + lVar15) = pplVar37;
        *(uint *)(&stack0xffffffffffffffe8 + lVar15) = uVar22 + iVar11;
        uVar38 = *(undefined8 *)(param_1 + 0xa8);
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100680;
        func_0x(param_1,uVar38,0,0);
      }
      else {
        *(undefined4 *)(&stack0x00000964 + lVar15) = 0;
        *(undefined4 *)(&stack0x00000968 + lVar15) = 0;
        (&stack0xfffffffffffffff8)[lVar15] = 1;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) = 0;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10016f;
        func_0x(pplVar37,2,0xffffffff,&stack0x00000960 + lVar15);
        if (*(int *)(&stack0x00000964 + lVar15) != 0) {
          lVar33 = **pplVar37;
          *(longlong *)(&stack0x000013b8 + lVar15) = lVar33;
          uVar9 = *(undefined *)(lVar33 + 1);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1001a1;
          func_0x(lVar20,uVar9,&stack0x00000960 + lVar15,0xffffffff);
        }
        lVar33 = **pplVar37;
        *(longlong *)(&stack0x000013c0 + lVar15) = lVar33;
        *(int **)(&stack0x000013c8 + lVar15) = (int *)(param_1 + 0xbc);
        lVar24 = **(longlong **)(param_1 + 8);
        puVar23 = (uint *)(lVar24 + 0x14);
        *(uint **)(&stack0x000013d0 + lVar15) = puVar23;
        if (((*puVar23 & 0xe0000000) == 0x80000000) && (*(ushort *)(lVar24 + 0x18) < 0x100)) {
LAB_:
          *(undefined4 *)(&stack0x000005f0 + lVar15) = 1;
          *(longlong ***)(&stack0x00000558 + lVar15) = pplVar37;
          if (*pplVar37 != (longlong *)0x0) {
            puVar17 = (undefined2 *)((longlong)*pplVar37 + 0x62);
            *(undefined2 **)(&stack0x00001400 + lVar15) = puVar17;
            *(undefined2 *)(&stack0x000000f8 + lVar15) = *puVar17;
            plVar28 = *(longlong **)(&stack0x00000558 + lVar15);
            if (((*(ushort *)(&stack0x000000f8 + lVar15) & 0x400) == 0) ||
               (*(short *)((longlong)plVar28 + 0xc) < 3)) {
              *(int *)(&stack0x000000a8 + lVar15) = (int)*(short *)((longlong)plVar28 + 0xc);
              lVar20 = *plVar28;
              *(longlong *)(&stack0x00000218 + lVar15) = lVar20;
              puVar17 = (undefined2 *)(lVar20 + 0x62);
              *(undefined2 **)(&stack0x00001408 + lVar15) = puVar17;
              uVar10 = *puVar17;
              *(undefined2 *)(&stack0x00000100 + lVar15) = uVar10;
              if (((byte)uVar10 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000a8 + lVar15) == 3) {
                  *(undefined4 *)(&stack0x000000a8 + lVar15) = 4;
                }
                else if (*(int *)(&stack0x000000a8 + lVar15) < 2) goto LAB_;
                *(uint **)(&stack0x00001410 + lVar15) =
                     (uint *)(*(longlong *)(&stack0x00000218 + lVar15) + 100);
                uVar22 = *(uint *)(*(longlong *)(&stack0x00000218 + lVar15) + 100);
                *(uint *)(&stack0x000005f8 + lVar15) = uVar22;
                if ((((uVar22 & 8) != 0) &&
                    (lVar20 = *(longlong *)(*(longlong *)(&stack0x00000218 + lVar15) + 0x90),
                    lVar20 != 0)) &&
                   (*(longlong *)(&stack0x00001418 + lVar15) = lVar20,
                   *(longlong *)(lVar20 + 0x758) != 0)) {
                  uVar38 = *(undefined8 *)(lVar20 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100495;
                  func_0x
                            (uVar38,*(undefined8 *)(&stack0x00000218 + lVar15),
                             *(undefined4 *)(&stack0x000000a8 + lVar15));
                }
              }
LAB_:
              (&stack0x000001a8)[lVar15] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar23 = (uint *)(*(longlong *)(&stack0x00000218 + lVar15) + 100);
                *(uint **)(&stack0x00001420 + lVar15) = puVar23;
                uVar22 = *puVar23;
                *(uint *)(&stack0x00000600 + lVar15) = uVar22;
                if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000a8 + lVar15))) {
                  *(uint **)(&stack0x00001428 + lVar15) = puVar23;
                  uVar22 = *puVar23;
                  *(uint *)(&stack0x00000608 + lVar15) = uVar22;
                  if (((uVar22 & 0xc0000000) != 0x40000000) &&
                     (lVar20 = **(longlong **)(&stack0x00000218 + lVar15), lVar20 != 0)) {
                    *(undefined4 *)(&stack0x00000760 + lVar15) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100528;
                    iVar11 = (*_DAT_)(lVar20,0x2000,2,&stack0x00000764 + lVar15);
                    if (iVar11 != 0) {
                      LOCK();
                      *puVar23 = *puVar23 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar23 = *puVar23 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar20 = *(longlong *)(&stack0x00000218 + lVar15);
              uVar14 = *(undefined4 *)(&stack0x000000a8 + lVar15);
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100559;
              func_0x(lVar20 + 0x98,uVar14);
              if ((_DAT_ != 0) &&
                 ((&stack0x000001a9)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100583;
                func_0x(lVar20,0,uVar14);
              }
              *(uint *)((longlong)plVar28 + 0xc) = *(uint *)((longlong)plVar28 + 0xc) & 0xffff0000;
              **(undefined8 **)(&stack0x00000558 + lVar15) = 0;
              param_1 = *(longlong *)(&stack0x000000c0 + lVar15);
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1003d1;
              func_0x(plVar28);
            }
            lVar20 = *(longlong *)(&stack0x00000688 + lVar15);
          }
          *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
          iVar11 = *(int *)(param_1 + 0xcc);
          if (iVar11 != 0) {
            *(int *)(&stack0x00000768 + lVar15) = iVar11;
            lVar24 = (longlong)*(int *)(param_1 + 200);
            *(int *)(&stack0x00000770 + lVar15) = *(int *)(param_1 + 200);
            lVar33 = *(longlong *)(lVar20 + 0x20);
            *(longlong *)(&stack0x00001430 + lVar15) = lVar33;
            lVar33 = *(longlong *)(lVar33 + 0x6c10);
            *(longlong *)(&stack0x00001438 + lVar15) = lVar33;
            if (lVar33 != 0) {
              if (iVar11 == 1) {
                plVar28 = (longlong *)(lVar33 + lVar24 * 0x28);
                *plVar28 = *plVar28 + 1;
              }
              else if (iVar11 == 2) {
                plVar28 = (longlong *)(lVar33 + 8 + lVar24 * 0x28);
                *plVar28 = *plVar28 + 1;
              }
              else if (iVar11 == 3) {
                plVar28 = (longlong *)(lVar33 + 0x18 + lVar24 * 0x28);
                *plVar28 = *plVar28 + 1;
              }
            }
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
          goto LAB_;
        }
        (&stack0x00000034)[lVar15] = 0;
        if (*(short *)(lVar33 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x00000290 + lVar15) = *(undefined8 *)(lVar33 + 0x28);
          sVar34 = *(short *)(lVar33 + 0x30);
          *(short *)(&stack0x00000298 + lVar15) = sVar34;
        }
        else {
          cVar7 = *(char *)(lVar33 + 1);
          if ((((cVar7 == '\v') || (cVar7 == '\b')) || (cVar7 == '\t')) &&
             (*(int *)(lVar33 + 0x18) == 99)) {
            *(undefined **)(&stack0x000013d8 + lVar15) = &stack0x000002e0 + lVar15;
            *(undefined4 **)(&stack0x000013e0 + lVar15) = (undefined4 *)(lVar33 + 0x20);
            *(undefined4 *)(&stack0x000002e0 + lVar15) = *(undefined4 *)(lVar33 + 0x20);
            *(undefined2 *)(&stack0x000002e4 + lVar15) = *(undefined2 *)(lVar33 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100255;
            cVar7 = func_0x(&stack0x000002e0 + lVar15);
            if (cVar7 == '\0') goto LAB_;
            cVar7 = '\x01';
          }
          else {
LAB_:
            cVar7 = '\0';
          }
          (&stack0x00000034)[lVar15] = cVar7;
          if (cVar7 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100277;
          func_0x(lVar33,&stack0x00000290 + lVar15);
          sVar34 = *(short *)(&stack0x00000298 + lVar15);
        }
        *(undefined **)(&stack0x000013e8 + lVar15) = &stack0x00000290 + lVar15;
        if (((sVar34 != *(short *)(param_1 + 0xc4)) ||
            (*(int *)(&stack0x00000290 + lVar15) != *(int *)(param_1 + 0xbc))) ||
           (*(int *)(&stack0x00000294 + lVar15) != *(int *)(param_1 + 0xc0))) goto LAB_;
        *(undefined4 *)(&stack0x000005f0 + lVar15) = 0;
        iVar11 = *(int *)(param_1 + 0xcc);
        if (iVar11 == 0) goto LAB_;
        *(int *)(&stack0x00000750 + lVar15) = iVar11;
        lVar33 = (longlong)*(int *)(param_1 + 200);
        *(int *)(&stack0x00000758 + lVar15) = *(int *)(param_1 + 200);
        lVar20 = *(longlong *)(lVar20 + 0x20);
        *(longlong *)(&stack0x000013f0 + lVar15) = lVar20;
        lVar20 = *(longlong *)(lVar20 + 0x6c10);
        *(longlong *)(&stack0x000013f8 + lVar15) = lVar20;
        if (lVar20 == 0) {
LAB_:
          *(undefined4 *)(param_1 + 0xcc) = 0;
        }
        else {
          if (iVar11 == 1) {
            plVar28 = (longlong *)(lVar20 + 0x10 + lVar33 * 0x28);
            *plVar28 = *plVar28 + 1;
            goto LAB_;
          }
          if (iVar11 == 2) {
            plVar28 = (longlong *)(lVar20 + 8 + lVar33 * 0x28);
            *plVar28 = *plVar28 + 1;
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
          else {
            if (iVar11 != 3) goto LAB_;
            plVar28 = (longlong *)(lVar20 + 0x20 + lVar33 * 0x28);
            *plVar28 = *plVar28 + 1;
            *(undefined4 *)(param_1 + 0xcc) = 0;
          }
        }
      }
LAB_:
      if (*(int *)(param_1 + 0x90) == 0) {
        lVar20 = **pplVar37;
        *(longlong *)(&stack0x000000d0 + lVar15) = lVar20;
        *(longlong *)(&stack0x000006d8 + lVar15) = lVar20;
        *(uint *)(&stack0x00000268 + lVar15) = (uint)*(ushort *)(lVar20 + 0x16);
        iVar11 = *(int *)(*(longlong *)(&stack0x000000c0 + lVar15) + 0x80);
        *(int *)(&stack0x000000d8 + lVar15) = iVar11;
        *(int *)(&stack0x000001ec + lVar15) = iVar11;
        acStackX_8[lVar15] = '\0';
LAB_:
        do {
          uVar22 = 0;
          uVar5 = *(ushort *)(lVar20 + (0xfff - (longlong)iVar11) * 2);
          *(ushort *)(&stack0x000004a8 + lVar15) = uVar5;
          pbVar4 = (byte *)(lVar20 + (ulonglong)uVar5);
          *(byte **)(&stack0x00000a08 + lVar15) = pbVar4;
          bVar8 = *pbVar4;
          *(ushort *)(&stack0x000004ac + lVar15) = (ushort)(bVar8 & 1);
          if ((bVar8 & 1) != 0) {
            *(undefined2 *)(&stack0x00001718 + lVar15) = 0xffff;
            *(undefined8 *)(&stack0x00001720 + lVar15) = 0;
            *(undefined4 *)(&stack0x0000171c + lVar15) = 0;
            *(undefined8 *)(&stack0x00001736 + lVar15) = 0;
            *(undefined8 *)(&stack0x00001740 + lVar15) = 0;
            *(undefined8 *)(&stack0x00001728 + lVar15) = 0;
            *(undefined4 *)(&stack0x0000174c + lVar15) = 0xffffffff;
            *(int *)(&stack0x0000174c + lVar15) = iVar11;
            if (-1 < *(char *)(lVar20 + 2)) {
              *(undefined8 *)(&stack0x00000680 + lVar15) = 0;
              goto LAB_;
            }
            pbVar4 = (byte *)(lVar20 + 0x60);
            *(undefined8 *)(&stack0x00000a10 + lVar15) = 0;
            *(undefined8 *)(&stack0x00000680 + lVar15) = 0;
            *(undefined **)(&stack0x00000a18 + lVar15) = &stack0x00001750 + lVar15;
            *(undefined (*) [16])(&stack0x00001750 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00001760 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00001770 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00001780 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00001790 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000017a0 + lVar15) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000017b0 + lVar15) = ZEXT816(0);
            *(undefined8 *)(&stack0x000017c0 + lVar15) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100acc;
            ppbVar18 = (byte **)func_0x(&stack0x00001750 + lVar15);
            *(byte ***)(&stack0x00000680 + lVar15) = ppbVar18;
            (&stack0x00000035)[lVar15] = 0;
            if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
              *(undefined8 *)(&stack0x000017c8 + lVar15) = *(undefined8 *)(lVar20 + 0x28);
              sVar34 = *(short *)(lVar20 + 0x30);
              *(short *)(&stack0x000017d0 + lVar15) = sVar34;
            }
            else {
              cVar7 = *(char *)(lVar20 + 1);
              if ((((cVar7 == '\v') || (cVar7 == '\b')) || (cVar7 == '\t')) &&
                 (*(int *)(lVar20 + 0x18) == 99)) {
                *(undefined **)(&stack0x00000a20 + lVar15) = &stack0x000002e8 + lVar15;
                *(undefined4 **)(&stack0x00000a28 + lVar15) = (undefined4 *)(lVar20 + 0x20);
                *(undefined4 *)(&stack0x000002e8 + lVar15) = *(undefined4 *)(lVar20 + 0x20);
                *(undefined2 *)(&stack0x000002ec + lVar15) = *(undefined2 *)(lVar20 + 0x24);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100b3e;
                cVar7 = func_0x(&stack0x000002e8 + lVar15);
                if (cVar7 == '\0') goto LAB_;
                cVar7 = '\x01';
              }
              else {
LAB_:
                cVar7 = '\0';
              }
              (&stack0x00000035)[lVar15] = cVar7;
              if (cVar7 == '\0') goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100b60;
              func_0x(lVar20,&stack0x000017c8 + lVar15);
              sVar34 = *(short *)(&stack0x000017d0 + lVar15);
            }
            *(undefined **)(&stack0x00000a30 + lVar15) = &stack0x000017c8 + lVar15;
            *(longlong *)(&stack0x00000a38 + lVar15) = lVar20 + 0x20;
            *(byte **)(&stack0x00000a40 + lVar15) = pbVar4;
            *(byte ***)(&stack0x00000a48 + lVar15) = ppbVar18;
            if (pbVar4 == *ppbVar18) {
              *(byte ***)(&stack0x00000a50 + lVar15) = ppbVar18 + 0xc;
              if (((sVar34 == *(short *)(ppbVar18 + 0xd)) &&
                  (*(int *)(&stack0x000017c8 + lVar15) == *(int *)(ppbVar18 + 0xc))) &&
                 (*(int *)(&stack0x000017cc + lVar15) == *(int *)((longlong)ppbVar18 + 100))) {
                *(longlong *)(&stack0x00000a58 + lVar15) = (longlong)ppbVar18 + 0x6c;
              }
            }
            *ppbVar18 = pbVar4;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c03;
            func_0x(ppbVar18 + 0xc,&stack0x000017c8 + lVar15);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100c0f;
            func_0x((longlong)ppbVar18 + 0x6c);
            bVar8 = *pbVar4;
            *(ushort *)(&stack0x000004b0 + lVar15) = (ushort)bVar8;
            lVar33 = (ulonglong)bVar8 * 6;
            *(undefined4 *)(&stack0x000006e0 + lVar15) = *(undefined4 *)(lVar33 + 0x1543200);
            *(undefined2 *)(&stack0x000006e4 + lVar15) = *(undefined2 *)(lVar33 + 0x1543204);
            *(undefined4 *)(&stack0x000004d0 + lVar15) = *(undefined4 *)(lVar33 + 0x1543200);
            uVar36 = (ulonglong)*(short *)(lVar33 + 0x1543204);
            *(short *)(&stack0x000004d4 + lVar15) = *(short *)(lVar33 + 0x1543204);
            *(longlong *)(&stack0x00000a60 + lVar15) = lVar20 + 99;
            ppbVar1 = ppbVar18 + 2;
            *(byte ***)(&stack0x00000a68 + lVar15) = ppbVar1;
            *(undefined2 *)ppbVar1 = 0xffff;
            ppbVar18[3] = (byte *)0x0;
            *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
            *(undefined8 *)((longlong)ppbVar18 + 0x2e) = 0;
            ppbVar18[7] = (byte *)0x0;
            ppbVar18[4] = (byte *)0x0;
            ppbVar2 = ppbVar18 + 9;
            *(byte ***)(&stack0x00000a70 + lVar15) = ppbVar2;
            *ppbVar2 = (byte *)0x0;
            ppbVar18[10] = (byte *)0x0;
            *(undefined2 *)(ppbVar18 + 0xb) = 0;
            if ((**ppbVar18 & 2) != 0) {
              pbVar4 = pbVar4 + uVar36;
              *(byte **)(&stack0x00000a78 + lVar15) = pbVar4;
              *(byte ***)(&stack0x00000a80 + lVar15) = ppbVar1;
              bVar8 = *pbVar4 & 1;
              *(ushort *)(&stack0x000004b8 + lVar15) = (ushort)bVar8;
              *(ushort *)ppbVar1 = (ushort)bVar8;
              if (bVar8 != 0) {
                *(longlong *)(&stack0x00000a98 + lVar15) = (longlong)ppbVar18 + 0x12;
                ppbVar18[3] = pbVar4;
                *(byte **)(&stack0x00000aa0 + lVar15) = pbVar4;
                UNRECOVERED_JUMPTABLE_00 =
                     (code *)((ulonglong)
                              *(uint *)((ulonglong)
                                        *(byte *)((longlong)(int)(*pbVar4 & 0x1c) + 0x1063ac) * 4 +
                                       0x10639c) - 0x1055c10);
                    /* WARNING: Could not emulate address calculation at 0x00100def */
                    /* WARNING: Treating indirect jump as call */
                (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                return;
              }
              *(undefined4 *)(&stack0x000001b8 + lVar15) = 0;
              *(longlong *)(&stack0x00000a88 + lVar15) = (longlong)ppbVar18 + 0x12;
              ppbVar18[3] = pbVar4;
              *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar18 + 0x36) = 0;
              pbVar4 = ppbVar18[3];
              *(byte **)(&stack0x00000a90 + lVar15) = pbVar4;
                    /* WARNING: Could not emulate address calculation at 0x00100d1e */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar4 & 0xe) * 4 + 0x106360) -
                        0x1055c10))();
              return;
            }
            if ((**ppbVar18 & 4) != 0) {
              if (*(short *)(&stack0x000004d2 + lVar15) != 0) {
                uVar36 = (ulonglong)
                         *(ushort *)
                          (lVar20 + 0x61 + (longlong)*(short *)(&stack0x000004d2 + lVar15) * 2);
              }
              *(byte **)(&stack0x00000ac8 + lVar15) = pbVar4 + uVar36;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100f86;
              func_0x(ppbVar2);
            }
            pbVar4 = ppbVar18[1];
            if (pbVar4 != (byte *)0x0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100f97;
              func_0x(pbVar4,ppbVar18);
            }
            lVar20 = *(longlong *)(&stack0x000000d0 + lVar15);
LAB_:
            uVar5 = *(ushort *)(lVar20 + 0xe);
            *(uint *)(&stack0x00000794 + lVar15) = (uint)uVar5;
            uVar35 = *(ushort *)
                      (lVar20 + (0xfff - (longlong)*(int *)(&stack0x000000d8 + lVar15)) * 2);
            *(ushort *)(&stack0x000004ba + lVar15) = uVar35;
            pbVar4 = (byte *)((ulonglong)uVar35 + lVar20);
            *(byte **)(&stack0x00000ad0 + lVar15) = pbVar4;
            bVar8 = *pbVar4 & 1;
            *(ushort *)(&stack0x000004bc + lVar15) = (ushort)bVar8;
            *(ushort *)(&stack0x00001718 + lVar15) = (ushort)bVar8;
            if (bVar8 != 0) {
              *(undefined **)(&stack0x00000ae8 + lVar15) = &stack0x0000171a + lVar15;
              *(byte **)(&stack0x00001720 + lVar15) = pbVar4;
              *(byte **)(&stack0x00000af0 + lVar15) = pbVar4;
              UNRECOVERED_JUMPTABLE_00 =
                   (code *)((ulonglong)
                            *(uint *)((ulonglong)
                                      *(byte *)((longlong)(int)(*pbVar4 & 0x1c) + 0x106418) * 4 +
                                     0x106408) - 0x1055c10);
                    /* WARNING: Could not emulate address calculation at 0x00101117 */
                    /* WARNING: Treating indirect jump as call */
              (*UNRECOVERED_JUMPTABLE_00)
                        (UNRECOVERED_JUMPTABLE_00,*pbVar4,0xfffffffffefaa3f0,pbVar4);
              return;
            }
            *(uint *)(&stack0x000001c0 + lVar15) = (uint)uVar5;
            *(undefined **)(&stack0x00000ad8 + lVar15) = &stack0x0000171a + lVar15;
            *(byte **)(&stack0x00001720 + lVar15) = pbVar4;
            *(undefined4 *)(&stack0x0000171c + lVar15) = 0;
            *(undefined4 *)(&stack0x0000173e + lVar15) = 0;
            *(byte **)(&stack0x00000ae0 + lVar15) = pbVar4;
                    /* WARNING: Could not emulate address calculation at 0x0010104f */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar4 & 0xe) * 4 + 0x1063cc) -
                      0x1055c10))();
            return;
          }
          iVar11 = *param_2;
          *(int *)(&stack0x00000790 + lVar15) = iVar11;
          puVar25 = (undefined4 *)(pbVar4 + iVar11);
          *(undefined4 **)(&stack0x000006a0 + lVar15) = puVar25;
          uVar14 = *puVar25;
          *(undefined4 *)(&stack0x000006e8 + lVar15) = uVar14;
          uVar5 = *(ushort *)(puVar25 + 1);
          *(ushort *)(&stack0x000006ec + lVar15) = uVar5;
          iVar11 = *(int *)(param_3 + 1);
          if (iVar11 == 0) {
            *(ushort *)(&stack0x00000500 + lVar15) = uVar5;
            puVar23 = (uint *)param_3[5];
            *(uint **)(&stack0x00000c28 + lVar15) = puVar23;
            *(undefined4 *)(&stack0x0000038c + lVar15) = 0;
            uVar13 = *puVar23;
            *(uint *)(&stack0x00000390 + lVar15) = uVar13;
            uVar27 = uVar22;
            while (uVar13 != uVar27) {
              uVar26 = uVar13 + uVar27 >> 1;
              *(uint *)(&stack0x000007e8 + lVar15) = uVar26;
              puVar16 = (ushort *)(*(longlong *)(puVar23 + 2) + (ulonglong)uVar26 * 8);
              uVar35 = *puVar16;
              if (uVar35 == uVar5) {
                uVar12 = *(undefined4 *)(puVar16 + 2);
                goto LAB_;
              }
              if (uVar35 < uVar5) {
                *(uint *)(&stack0x0000038c + lVar15) = uVar26;
                uVar27 = uVar26;
              }
              else {
                if (uVar5 < uVar35) {
                  uVar13 = uVar26;
                }
                *(uint *)(&stack0x00000390 + lVar15) = uVar13;
              }
            }
            uVar12 = 0xffffffff;
LAB_:
            *(undefined4 *)(&stack0x000007ec + lVar15) = uVar12;
            *(undefined4 *)((longlong)param_3 + 0x1c) = uVar12;
          }
          puVar25 = (undefined4 *)(*param_3 + (longlong)iVar11 * 8);
          *(undefined4 **)(&stack0x00000c30 + lVar15) = puVar25;
          *puVar25 = uVar14;
          *(ushort *)(puVar25 + 1) = uVar5;
          *(undefined2 *)((longlong)puVar25 + 6) = 0;
          *(int *)(param_3 + 1) = *(int *)(param_3 + 1) + 1;
          iVar11 = *(int *)(param_3 + 1);
          if (iVar11 < *(int *)(param_3 + 2)) {
LAB_:
            *(undefined4 *)(&stack0x000001e8 + lVar15) = 0;
            param_1 = *(longlong *)(&stack0x000000c0 + lVar15);
          }
          else {
            if (iVar11 != *(int *)(param_3 + 2)) {
              *(ushort *)(&stack0x00000530 + lVar15) = uVar5;
              if (iVar11 < *(int *)((longlong)param_3 + 0x14)) {
                if (*(ushort *)(param_3 + 4) == uVar5) goto LAB_;
LAB_:
                *(ushort *)(&stack0x00000538 + lVar15) = uVar5;
                puVar23 = (uint *)param_3[5];
                *(uint **)(&stack0x00000f28 + lVar15) = puVar23;
                *(undefined4 *)(&stack0x000003b8 + lVar15) = 0;
                uVar13 = *puVar23;
                *(uint *)(&stack0x000003bc + lVar15) = uVar13;
                while (uVar13 != uVar22) {
                  uVar27 = uVar13 + uVar22 >> 1;
                  *(uint *)(&stack0x00000828 + lVar15) = uVar27;
                  puVar16 = (ushort *)(*(longlong *)(puVar23 + 2) + (ulonglong)uVar27 * 8);
                  uVar35 = *puVar16;
                  if (uVar35 == uVar5) {
                    iVar11 = *(int *)(puVar16 + 2);
                    goto LAB_;
                  }
                  if (uVar35 < uVar5) {
                    *(uint *)(&stack0x000003b8 + lVar15) = uVar27;
                    uVar22 = uVar27;
                  }
                  else {
                    if (uVar5 < uVar35) {
                      uVar13 = uVar27;
                    }
                    *(uint *)(&stack0x000003bc + lVar15) = uVar13;
                  }
                }
                iVar11 = -1;
LAB_:
                *(int *)(&stack0x0000082c + lVar15) = iVar11;
                if (iVar11 == *(int *)((longlong)param_3 + 0x1c)) {
                  if (*(ushort *)(param_3 + 4) != uVar5) {
                    *(ushort *)(param_3 + 4) = uVar5;
                  }
                  goto LAB_;
                }
              }
              else if (iVar11 != *(int *)((longlong)param_3 + 0x14)) goto LAB_;
              *(undefined4 *)(&stack0x000001e8 + lVar15) = 1;
              param_1 = *(longlong *)(&stack0x000000c0 + lVar15);
              goto LAB_;
            }
            *(ushort *)(&stack0x00000508 + lVar15) = uVar5;
            puVar23 = (uint *)param_3[5];
            *(uint **)(&stack0x00000c38 + lVar15) = puVar23;
            *(undefined4 *)(&stack0x00000394 + lVar15) = 0;
            uVar13 = *puVar23;
            *(uint *)(&stack0x00000398 + lVar15) = uVar13;
            while (uVar13 != uVar22) {
              uVar27 = uVar13 + uVar22 >> 1;
              *(uint *)(&stack0x000007f0 + lVar15) = uVar27;
              puVar16 = (ushort *)(*(longlong *)(puVar23 + 2) + (ulonglong)uVar27 * 8);
              uVar35 = *puVar16;
              if (uVar35 == uVar5) {
                uVar14 = *(undefined4 *)(puVar16 + 2);
                goto LAB_;
              }
              if (uVar5 <= uVar35) {
                if (uVar5 <= uVar35 && uVar35 != uVar5) {
                  uVar13 = uVar27;
                }
                *(uint *)(&stack0x00000398 + lVar15) = uVar13;
              }
              else {
                *(uint *)(&stack0x00000394 + lVar15) = uVar27;
                uVar22 = uVar27;
              }
            }
            uVar14 = 0xffffffff;
LAB_:
            *(undefined4 *)(&stack0x000007f4 + lVar15) = uVar14;
            *(undefined4 *)((longlong)param_3 + 0x1c) = uVar14;
            *(ushort *)(param_3 + 4) = uVar5;
            *(undefined4 *)(&stack0x000001e8 + lVar15) = 2;
            *(undefined2 *)(&stack0x000017f8 + lVar15) = 0xffff;
            *(undefined8 *)(&stack0x00001800 + lVar15) = 0;
            *(undefined4 *)(&stack0x000017fc + lVar15) = 0;
            *(undefined8 *)(&stack0x00001816 + lVar15) = 0;
            *(undefined8 *)(&stack0x00001820 + lVar15) = 0;
            *(undefined8 *)(&stack0x00001808 + lVar15) = 0;
            *(undefined4 *)(&stack0x0000182c + lVar15) = 0xffffffff;
            param_1 = *(longlong *)(&stack0x000000c0 + lVar15);
            pplVar37 = (longlong **)(param_1 + 0x68);
            *(longlong ***)(&stack0x000000e8 + lVar15) = pplVar37;
            lVar20 = **pplVar37;
            *(longlong *)(&stack0x00000c40 + lVar15) = lVar20;
            lVar33 = *(longlong *)(param_1 + 0xd8);
            *(longlong *)(&stack0x00000c48 + lVar15) = lVar33;
            if (*(int *)(lVar33 + 0x20) == 0) {
              lVar33 = *(longlong *)(lVar33 + 0x18);
            }
            else {
              lVar33 = *(longlong *)(lVar33 + 0x10);
            }
            *(longlong *)(&stack0x000000e0 + lVar15) = lVar33;
            *(longlong *)(&stack0x00000c50 + lVar15) = lVar33;
            lVar24 = **(longlong **)(param_1 + 8);
            *(longlong *)(&stack0x00000220 + lVar15) = lVar24;
            *(longlong *)(&stack0x00000c58 + lVar15) = lVar24;
            piVar3 = (int *)(param_1 + 0x118);
            *(int **)(&stack0x00000c60 + lVar15) = piVar3;
            piVar31 = (int *)(lVar20 + 0x20);
            *(int **)(&stack0x00000c68 + lVar15) = piVar31;
            if ((*piVar31 == *piVar3) && (*(short *)(lVar20 + 0x24) == *(short *)(param_1 + 0x11c)))
            {
              *(int **)(&stack0x00000c70 + lVar15) = (int *)(param_1 + 0x124);
              *(uint **)(&stack0x00000c78 + lVar15) = (uint *)(lVar24 + 0x14);
              if (((*(uint *)(lVar24 + 0x14) & 0xe0000000) == 0x80000000) &&
                 (*(ushort *)(lVar24 + 0x18) < 0x100)) {
LAB_:
                pplVar37 = *(longlong ***)(&stack0x000000e8 + lVar15);
                *(undefined4 *)(&stack0x00000254 + lVar15) = 1;
                goto LAB_;
              }
              (&stack0x00000036)[lVar15] = 0;
              if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x000002a0 + lVar15) = *(undefined8 *)(lVar20 + 0x28);
                sVar34 = *(short *)(lVar20 + 0x30);
                *(short *)(&stack0x000002a8 + lVar15) = sVar34;
              }
              else {
                cVar7 = *(char *)(lVar20 + 1);
                if ((((cVar7 == '\v') || (cVar7 == '\b')) || (cVar7 == '\t')) &&
                   (*(int *)(lVar20 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00000c80 + lVar15) = &stack0x000002f0 + lVar15;
                  *(int **)(&stack0x00000c88 + lVar15) = piVar31;
                  *(int *)(&stack0x000002f0 + lVar15) = *piVar31;
                  *(undefined2 *)(&stack0x000002f4 + lVar15) = *(undefined2 *)(lVar20 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1023f3;
                  cVar7 = func_0x(&stack0x000002f0 + lVar15);
                  if (cVar7 == '\0') goto LAB_;
                  cVar7 = '\x01';
                }
                else {
LAB_:
                  cVar7 = '\0';
                }
                (&stack0x00000036)[lVar15] = cVar7;
                if (cVar7 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102415;
                func_0x(lVar20,&stack0x000002a0 + lVar15);
                sVar34 = *(short *)(&stack0x000002a8 + lVar15);
              }
              *(undefined **)(&stack0x00000c90 + lVar15) = &stack0x000002a0 + lVar15;
              if (((sVar34 != *(short *)(param_1 + 300)) ||
                  (*(int *)(&stack0x000002a0 + lVar15) != *(int *)(param_1 + 0x124))) ||
                 (*(int *)(&stack0x000002a4 + lVar15) != *(int *)(param_1 + 0x128)))
              goto LAB_;
              *(undefined4 *)(&stack0x00000254 + lVar15) = 0;
            }
            else {
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102497;
              func_0x(piVar3);
              *(int **)(&stack0x00000c98 + lVar15) = piVar31;
              *(int **)(&stack0x00000ca0 + lVar15) = piVar3;
              *piVar3 = *piVar31;
              *(undefined2 *)(param_1 + 0x11c) = *(undefined2 *)(lVar20 + 0x24);
              (&stack0x00000037)[lVar15] = 0;
              if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
                uVar38 = *(undefined8 *)(lVar20 + 0x28);
                *(undefined8 *)(&stack0x00000340 + lVar15) = uVar38;
                *(undefined2 *)(&stack0x00000348 + lVar15) = *(undefined2 *)(lVar20 + 0x30);
              }
              else {
                cVar7 = *(char *)(lVar20 + 1);
                if ((((cVar7 == '\v') || (cVar7 == '\b')) || (cVar7 == '\t')) &&
                   (*(int *)(lVar20 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00000ca8 + lVar15) = &stack0x00000320 + lVar15;
                  *(int **)(&stack0x00000cb0 + lVar15) = piVar31;
                  *(int *)(&stack0x00000320 + lVar15) = *piVar31;
                  *(undefined2 *)(&stack0x00000324 + lVar15) = *(undefined2 *)(lVar20 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102513;
                  cVar7 = func_0x(&stack0x00000320 + lVar15);
                  if (cVar7 == '\0') goto LAB_;
                  cVar7 = '\x01';
                }
                else {
LAB_:
                  cVar7 = '\0';
                }
                (&stack0x00000037)[lVar15] = cVar7;
                if (cVar7 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102535;
                func_0x(lVar20,&stack0x00000340 + lVar15);
                uVar38 = *(undefined8 *)(&stack0x00000340 + lVar15);
              }
              *(undefined **)(&stack0x00000cb8 + lVar15) = &stack0x00000340 + lVar15;
              *(undefined8 *)(param_1 + 0x124) = uVar38;
              *(undefined2 *)(param_1 + 300) = *(undefined2 *)(&stack0x00000348 + lVar15);
              *(undefined4 *)(param_1 + 0x130) = 1;
              iVar11 = *(int *)(lVar33 + 0x10);
              *(int *)(&stack0x000007f8 + lVar15) = iVar11;
              if (iVar11 == 0) {
                lVar33 = **pplVar37;
                *(longlong *)(&stack0x00000cc0 + lVar15) = lVar33;
                iVar11 = *(ushort *)(lVar33 + 0x16) - 1;
                *(int *)(&stack0x00000090 + lVar15) = iVar11;
                *(int *)(&stack0x00000848 + lVar15) = iVar11;
                *(int *)(&stack0x0000182c + lVar15) = iVar11;
                if (-1 < *(char *)(lVar20 + 2)) {
                  *(undefined8 *)(&stack0x00000570 + lVar15) = 0;
                  goto LAB_;
                }
                pbVar4 = (byte *)(lVar20 + 0x60);
                if (*(short *)(&stack0x000017f8 + lVar15) == 0) {
                  *(undefined8 *)(&stack0x00000570 + lVar15) = 0;
LAB_:
                  *(undefined **)(&stack0x00000cd0 + lVar15) = &stack0x00001830 + lVar15;
                  *(undefined (*) [16])(&stack0x00001830 + lVar15) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001840 + lVar15) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001850 + lVar15) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001860 + lVar15) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001870 + lVar15) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001880 + lVar15) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x00001890 + lVar15) = ZEXT816(0);
                  *(undefined8 *)(&stack0x000018a0 + lVar15) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102681;
                  ppbVar18 = (byte **)func_0x(&stack0x00001830 + lVar15);
                  *(byte ***)(&stack0x00000570 + lVar15) = ppbVar18;
                }
                else {
                  ppbVar18 = *(byte ***)(&stack0x00001808 + lVar15);
                  *(byte ***)(&stack0x00000cc8 + lVar15) = ppbVar18;
                  *(byte ***)(&stack0x00000570 + lVar15) = ppbVar18;
                  if (ppbVar18 == (byte **)0x0) goto LAB_;
                }
                (&stack0x00000038)[lVar15] = 0;
                if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
                  *(undefined8 *)(&stack0x000017d8 + lVar15) = *(undefined8 *)(lVar20 + 0x28);
                  sVar34 = *(short *)(lVar20 + 0x30);
                  *(short *)(&stack0x000017e0 + lVar15) = sVar34;
                }
                else {
                  cVar7 = *(char *)(lVar20 + 1);
                  if ((((cVar7 == '\v') || (cVar7 == '\b')) || (cVar7 == '\t')) &&
                     (*(int *)(lVar20 + 0x18) == 99)) {
                    *(undefined **)(&stack0x00000cd8 + lVar15) = &stack0x000002f8 + lVar15;
                    *(int **)(&stack0x00000ce0 + lVar15) = piVar31;
                    *(int *)(&stack0x000002f8 + lVar15) = *piVar31;
                    *(undefined2 *)(&stack0x000002fc + lVar15) = *(undefined2 *)(lVar20 + 0x24);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1026f1;
                    cVar7 = func_0x(&stack0x000002f8 + lVar15);
                    if (cVar7 == '\0') goto LAB_;
                    cVar7 = '\x01';
                  }
                  else {
LAB_:
                    cVar7 = '\0';
                  }
                  (&stack0x00000038)[lVar15] = cVar7;
                  if (cVar7 == '\0') goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102713;
                  func_0x(lVar20,&stack0x000017d8 + lVar15);
                  sVar34 = *(short *)(&stack0x000017e0 + lVar15);
                }
                *(undefined **)(&stack0x00000ce8 + lVar15) = &stack0x000017d8 + lVar15;
                *(int **)(&stack0x00000cf0 + lVar15) = piVar31;
                *(byte **)(&stack0x00000cf8 + lVar15) = pbVar4;
                *(byte ***)(&stack0x00000d00 + lVar15) = ppbVar18;
                if (pbVar4 == *ppbVar18) {
                  *(byte ***)(&stack0x00000d08 + lVar15) = ppbVar18 + 0xc;
                  if (((sVar34 == *(short *)(ppbVar18 + 0xd)) &&
                      (*(int *)(&stack0x000017d8 + lVar15) == *(int *)(ppbVar18 + 0xc))) &&
                     (*(int *)(&stack0x000017dc + lVar15) == *(int *)((longlong)ppbVar18 + 100))) {
                    *(longlong *)(&stack0x00000d10 + lVar15) = (longlong)ppbVar18 + 0x6c;
                  }
                }
                *ppbVar18 = pbVar4;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1027b1;
                func_0x(ppbVar18 + 0xc,&stack0x000017d8 + lVar15);
                *(int **)(&stack0x00000d18 + lVar15) = (int *)((longlong)ppbVar18 + 0x6c);
                *(int *)((longlong)ppbVar18 + 0x6c) = *piVar31;
                *(undefined2 *)(ppbVar18 + 0xe) = *(undefined2 *)(lVar20 + 0x24);
                *(undefined2 *)((longlong)ppbVar18 + 0x72) = 0;
                uVar36 = (ulonglong)*pbVar4;
                *(ushort *)(&stack0x00000510 + lVar15) = (ushort)*pbVar4;
                *(undefined4 *)(&stack0x000006f0 + lVar15) = *(undefined4 *)(uVar36 * 6 + 0x1543200)
                ;
                *(undefined2 *)(&stack0x000006f4 + lVar15) = *(undefined2 *)(uVar36 * 6 + 0x1543204)
                ;
                *(undefined4 *)(&stack0x000004d8 + lVar15) = *(undefined4 *)(uVar36 * 6 + 0x1543200)
                ;
                sVar34 = *(short *)(uVar36 * 6 + 0x1543204);
                uVar36 = (ulonglong)sVar34;
                *(short *)(&stack0x000004dc + lVar15) = sVar34;
                *(longlong *)(&stack0x00000d20 + lVar15) = lVar20 + 99;
                ppbVar1 = ppbVar18 + 2;
                *(byte ***)(&stack0x00000d28 + lVar15) = ppbVar1;
                *(undefined2 *)ppbVar1 = 0xffff;
                ppbVar18[3] = (byte *)0x0;
                *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
                *(undefined8 *)((longlong)ppbVar18 + 0x2e) = 0;
                ppbVar18[7] = (byte *)0x0;
                ppbVar18[4] = (byte *)0x0;
                *(byte ***)(&stack0x00000d30 + lVar15) = ppbVar18 + 9;
                ppbVar18[9] = (byte *)0x0;
                ppbVar18[10] = (byte *)0x0;
                *(undefined2 *)(ppbVar18 + 0xb) = 0;
                if ((**ppbVar18 & 2) != 0) {
                  pbVar4 = pbVar4 + uVar36;
                  *(byte **)(&stack0x00000d38 + lVar15) = pbVar4;
                  *(byte ***)(&stack0x00000d40 + lVar15) = ppbVar1;
                  bVar8 = *pbVar4 & 1;
                  *(ushort *)(&stack0x00000518 + lVar15) = (ushort)bVar8;
                  *(ushort *)ppbVar1 = (ushort)bVar8;
                  if (bVar8 != 0) {
                    *(longlong *)(&stack0x00000d58 + lVar15) = (longlong)ppbVar18 + 0x12;
                    ppbVar18[3] = pbVar4;
                    *(byte **)(&stack0x00000d60 + lVar15) = pbVar4;
                    UNRECOVERED_JUMPTABLE_00 =
                         (code *)((ulonglong)
                                  *(uint *)((ulonglong)
                                            *(byte *)((longlong)(int)(*pbVar4 & 0x1c) + 0x106484) *
                                            4 + 0x106474) - 0x1055c10);
                    /* WARNING: Could not emulate address calculation at 0x001029ba */
                    /* WARNING: Treating indirect jump as call */
                    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                    return;
                  }
                  *(undefined4 *)(&stack0x000001c8 + lVar15) = 0;
                  *(longlong *)(&stack0x00000d48 + lVar15) = (longlong)ppbVar18 + 0x12;
                  ppbVar18[3] = pbVar4;
                  *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
                  *(undefined4 *)((longlong)ppbVar18 + 0x36) = 0;
                  pbVar4 = ppbVar18[3];
                  *(byte **)(&stack0x00000d50 + lVar15) = pbVar4;
                    /* WARNING: Could not emulate address calculation at 0x001028eb */
                    /* WARNING: Treating indirect jump as call */
                  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar4 & 0xe) * 4 + 0x106438) -
                            0x1055c10))();
                  return;
                }
                if ((**ppbVar18 & 4) != 0) {
                  if (*(short *)(&stack0x000004da + lVar15) != 0) {
                    uVar36 = (ulonglong)
                             *(ushort *)
                              (lVar20 + 0x61 + (longlong)*(short *)(&stack0x000004da + lVar15) * 2);
                  }
                  *(byte **)(&stack0x00000d88 + lVar15) = pbVar4 + uVar36;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102b5b;
                  func_0x();
                }
                pbVar4 = ppbVar18[1];
                if (pbVar4 != (byte *)0x0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102b6f;
                  func_0x(pbVar4,ppbVar18);
                }
LAB_:
                uVar5 = *(ushort *)(lVar20 + 0xe);
                *(uint *)(&stack0x00000800 + lVar15) = (uint)uVar5;
                uVar35 = *(ushort *)
                          (lVar20 + (0xfff - (longlong)*(int *)(&stack0x00000090 + lVar15)) * 2);
                *(ushort *)(&stack0x0000051a + lVar15) = uVar35;
                pbVar4 = (byte *)((ulonglong)uVar35 + lVar20);
                *(byte **)(&stack0x00000d90 + lVar15) = pbVar4;
                bVar8 = *pbVar4 & 1;
                *(ushort *)(&stack0x0000051c + lVar15) = (ushort)bVar8;
                *(ushort *)(&stack0x000017f8 + lVar15) = (ushort)bVar8;
                if (bVar8 != 0) {
                  *(undefined **)(&stack0x00000da8 + lVar15) = &stack0x000017fa + lVar15;
                  *(byte **)(&stack0x00001800 + lVar15) = pbVar4;
                  *(byte **)(&stack0x00000db0 + lVar15) = pbVar4;
                  UNRECOVERED_JUMPTABLE_00 =
                       (code *)((ulonglong)
                                *(uint *)((ulonglong)
                                          *(byte *)((longlong)(int)(*pbVar4 & 0x1c) + 0x1064f0) * 4
                                         + 0x1064e0) - 0x1055c10);
                    /* WARNING: Could not emulate address calculation at 0x00102cde */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                  return;
                }
                *(uint *)(&stack0x000001d0 + lVar15) = (uint)uVar5;
                *(undefined **)(&stack0x00000d98 + lVar15) = &stack0x000017fa + lVar15;
                *(byte **)(&stack0x00001800 + lVar15) = pbVar4;
                *(undefined4 *)(&stack0x000017fc + lVar15) = 0;
                *(undefined4 *)(&stack0x0000181e + lVar15) = 0;
                *(byte **)(&stack0x00000da0 + lVar15) = pbVar4;
                    /* WARNING: Could not emulate address calculation at 0x00102c1e */
                    /* WARNING: Treating indirect jump as call */
                (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar4 & 0xe) * 4 + 0x1064a4) -
                          0x1055c10))();
                return;
              }
            }
            if (*(int *)(param_1 + 0x130) == 0) {
              uVar14 = *(undefined4 *)(param_1 + 0x80);
              *(undefined4 *)(&stack0x00000090 + lVar15) = uVar14;
              *(undefined4 *)(&stack0x00000808 + lVar15) = uVar14;
              *(undefined4 *)(&stack0x0000182c + lVar15) = uVar14;
              if (-1 < *(char *)(lVar20 + 2)) {
                *(undefined8 *)(&stack0x00000578 + lVar15) = 0;
                goto LAB_;
              }
              pbVar4 = (byte *)(lVar20 + 0x60);
              if (*(short *)(&stack0x000017f8 + lVar15) == 0) {
                *(undefined8 *)(&stack0x00000578 + lVar15) = 0;
LAB_:
                *(undefined **)(&stack0x00000de0 + lVar15) = &stack0x00001830 + lVar15;
                *(undefined (*) [16])(&stack0x00001830 + lVar15) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00001840 + lVar15) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00001850 + lVar15) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00001860 + lVar15) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00001870 + lVar15) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00001880 + lVar15) = ZEXT816(0);
                *(undefined (*) [16])(&stack0x00001890 + lVar15) = ZEXT816(0);
                *(undefined8 *)(&stack0x000018a0 + lVar15) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x102fbe;
                ppbVar18 = (byte **)func_0x(&stack0x00001830 + lVar15);
                *(byte ***)(&stack0x00000578 + lVar15) = ppbVar18;
              }
              else {
                ppbVar18 = *(byte ***)(&stack0x00001808 + lVar15);
                *(byte ***)(&stack0x00000dd8 + lVar15) = ppbVar18;
                *(byte ***)(&stack0x00000578 + lVar15) = ppbVar18;
                if (ppbVar18 == (byte **)0x0) goto LAB_;
              }
              (&stack0x00000039)[lVar15] = 0;
              if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
                *(undefined8 *)(&stack0x000017e8 + lVar15) = *(undefined8 *)(lVar20 + 0x28);
                sVar34 = *(short *)(lVar20 + 0x30);
                *(short *)(&stack0x000017f0 + lVar15) = sVar34;
              }
              else {
                cVar7 = *(char *)(lVar20 + 1);
                if ((((cVar7 == '\v') || (cVar7 == '\b')) || (cVar7 == '\t')) &&
                   (*(int *)(lVar20 + 0x18) == 99)) {
                  *(undefined **)(&stack0x00000de8 + lVar15) = &stack0x00000310 + lVar15;
                  *(int **)(&stack0x00000df0 + lVar15) = piVar31;
                  *(int *)(&stack0x00000310 + lVar15) = *piVar31;
                  *(undefined2 *)(&stack0x00000314 + lVar15) = *(undefined2 *)(lVar20 + 0x24);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103027;
                  cVar7 = func_0x(&stack0x00000310 + lVar15);
                  if (cVar7 == '\0') goto LAB_;
                  cVar7 = '\x01';
                }
                else {
LAB_:
                  cVar7 = '\0';
                }
                (&stack0x00000039)[lVar15] = cVar7;
                if (cVar7 == '\0') goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103049;
                func_0x(lVar20,&stack0x000017e8 + lVar15);
                sVar34 = *(short *)(&stack0x000017f0 + lVar15);
              }
              *(undefined **)(&stack0x00000df8 + lVar15) = &stack0x000017e8 + lVar15;
              *(int **)(&stack0x00000e00 + lVar15) = piVar31;
              *(byte **)(&stack0x00000e08 + lVar15) = pbVar4;
              *(byte ***)(&stack0x00000e10 + lVar15) = ppbVar18;
              if (pbVar4 == *ppbVar18) {
                *(byte ***)(&stack0x00000e18 + lVar15) = ppbVar18 + 0xc;
                if (((sVar34 == *(short *)(ppbVar18 + 0xd)) &&
                    (*(int *)(&stack0x000017e8 + lVar15) == *(int *)(ppbVar18 + 0xc))) &&
                   (*(int *)(&stack0x000017ec + lVar15) == *(int *)((longlong)ppbVar18 + 100))) {
                  *(longlong *)(&stack0x00000e20 + lVar15) = (longlong)ppbVar18 + 0x6c;
                }
              }
              *ppbVar18 = pbVar4;
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1030e7;
              func_0x(ppbVar18 + 0xc,&stack0x000017e8 + lVar15);
              *(int **)(&stack0x00000e28 + lVar15) = (int *)((longlong)ppbVar18 + 0x6c);
              *(int *)((longlong)ppbVar18 + 0x6c) = *piVar31;
              *(undefined2 *)(ppbVar18 + 0xe) = *(undefined2 *)(lVar20 + 0x24);
              *(undefined2 *)((longlong)ppbVar18 + 0x72) = 0;
              uVar36 = (ulonglong)*pbVar4;
              *(ushort *)(&stack0x00000520 + lVar15) = (ushort)*pbVar4;
              *(undefined4 *)(&stack0x000006f6 + lVar15) = *(undefined4 *)(uVar36 * 6 + 0x1543200);
              *(undefined2 *)(&stack0x000006fa + lVar15) = *(undefined2 *)(uVar36 * 6 + 0x1543204);
              *(undefined4 *)(&stack0x000004e0 + lVar15) = *(undefined4 *)(uVar36 * 6 + 0x1543200);
              sVar34 = *(short *)(uVar36 * 6 + 0x1543204);
              uVar36 = (ulonglong)sVar34;
              *(short *)(&stack0x000004e4 + lVar15) = sVar34;
              *(longlong *)(&stack0x000006a8 + lVar15) = lVar20 + 99;
              ppbVar1 = ppbVar18 + 2;
              *(byte ***)(&stack0x00000e30 + lVar15) = ppbVar1;
              *(undefined2 *)ppbVar1 = 0xffff;
              ppbVar18[3] = (byte *)0x0;
              *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
              *(undefined8 *)((longlong)ppbVar18 + 0x2e) = 0;
              ppbVar18[7] = (byte *)0x0;
              ppbVar18[4] = (byte *)0x0;
              ppbVar2 = ppbVar18 + 9;
              *(byte ***)(&stack0x00000e38 + lVar15) = ppbVar2;
              *ppbVar2 = (byte *)0x0;
              ppbVar18[10] = (byte *)0x0;
              *(undefined2 *)(ppbVar18 + 0xb) = 0;
              if ((**ppbVar18 & 2) != 0) {
                pbVar4 = pbVar4 + uVar36;
                *(byte **)(&stack0x00000e40 + lVar15) = pbVar4;
                *(byte ***)(&stack0x00000e48 + lVar15) = ppbVar1;
                bVar8 = *pbVar4 & 1;
                *(ushort *)(&stack0x00000528 + lVar15) = (ushort)bVar8;
                *(ushort *)ppbVar1 = (ushort)bVar8;
                if (bVar8 != 0) {
                  *(longlong *)(&stack0x00000e60 + lVar15) = (longlong)ppbVar18 + 0x12;
                  ppbVar18[3] = pbVar4;
                  *(byte **)(&stack0x00000e68 + lVar15) = pbVar4;
                  UNRECOVERED_JUMPTABLE_00 =
                       (code *)((ulonglong)
                                *(uint *)((ulonglong)
                                          *(byte *)((longlong)(int)(*pbVar4 & 0x1c) + 0x10655c) * 4
                                         + 0x10654c) - 0x1055c10);
                    /* WARNING: Could not emulate address calculation at 0x001032db */
                    /* WARNING: Treating indirect jump as call */
                  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                  return;
                }
                *(undefined4 *)(&stack0x000001d8 + lVar15) = 0;
                *(longlong *)(&stack0x00000e50 + lVar15) = (longlong)ppbVar18 + 0x12;
                ppbVar18[3] = pbVar4;
                *(undefined4 *)((longlong)ppbVar18 + 0x14) = 0;
                *(undefined4 *)((longlong)ppbVar18 + 0x36) = 0;
                pbVar4 = ppbVar18[3];
                *(byte **)(&stack0x00000e58 + lVar15) = pbVar4;
                    /* WARNING: Could not emulate address calculation at 0x00103222 */
                    /* WARNING: Treating indirect jump as call */
                (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar4 & 0xe) * 4 + 0x106510) -
                          0x1055c10))();
                return;
              }
              if ((**ppbVar18 & 4) != 0) {
                if (*(short *)(&stack0x000004e2 + lVar15) != 0) {
                  uVar36 = (ulonglong)
                           *(ushort *)
                            (lVar20 + 0x61 + (longlong)*(short *)(&stack0x000004e2 + lVar15) * 2);
                }
                *(byte **)(&stack0x00000e90 + lVar15) = pbVar4 + uVar36;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103485;
                func_0x(ppbVar2);
              }
              pbVar4 = ppbVar18[1];
              if (pbVar4 != (byte *)0x0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103496;
                func_0x(pbVar4,ppbVar18);
              }
LAB_:
              uVar5 = *(ushort *)(lVar20 + 0xe);
              *(uint *)(&stack0x00000810 + lVar15) = (uint)uVar5;
              uVar35 = *(ushort *)
                        (lVar20 + (0xfff - (longlong)*(int *)(&stack0x00000090 + lVar15)) * 2);
              *(ushort *)(&stack0x0000052a + lVar15) = uVar35;
              pbVar4 = (byte *)((ulonglong)uVar35 + lVar20);
              *(byte **)(&stack0x00000e98 + lVar15) = pbVar4;
              bVar8 = *pbVar4 & 1;
              *(ushort *)(&stack0x0000052c + lVar15) = (ushort)bVar8;
              *(ushort *)(&stack0x000017f8 + lVar15) = (ushort)bVar8;
              if (bVar8 != 0) {
                *(undefined **)(&stack0x00000eb0 + lVar15) = &stack0x000017fa + lVar15;
                *(byte **)(&stack0x00001800 + lVar15) = pbVar4;
                *(byte **)(&stack0x00000eb8 + lVar15) = pbVar4;
                UNRECOVERED_JUMPTABLE_00 =
                     (code *)((ulonglong)
                              *(uint *)((ulonglong)
                                        *(byte *)((longlong)(int)(*pbVar4 & 0x1c) + 0x1065c8) * 4 +
                                       0x1065b8) - 0x1055c10);
                    /* WARNING: Could not emulate address calculation at 0x001035fe */
                    /* WARNING: Treating indirect jump as call */
                (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
                return;
              }
              *(uint *)(&stack0x000001e0 + lVar15) = (uint)uVar5;
              *(undefined **)(&stack0x00000ea0 + lVar15) = &stack0x000017fa + lVar15;
              *(byte **)(&stack0x00001800 + lVar15) = pbVar4;
              *(undefined4 *)(&stack0x000017fc + lVar15) = 0;
              *(undefined4 *)(&stack0x0000181e + lVar15) = 0;
              *(byte **)(&stack0x00000ea8 + lVar15) = pbVar4;
                    /* WARNING: Could not emulate address calculation at 0x0010353e */
                    /* WARNING: Treating indirect jump as call */
              (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar4 & 0xe) * 4 + 0x10657c) -
                        0x1055c10))();
              return;
            }
            *(undefined4 *)(&stack0x00000090 + lVar15) = 1;
            param_2 = *(int **)(&stack0x00000328 + lVar15);
            param_3 = *(longlong **)(&stack0x00000208 + lVar15);
          }
          uVar38 = 0;
          iVar11 = *(int *)(&stack0x000000d8 + lVar15) + 1;
          *(int *)(&stack0x000000d8 + lVar15) = iVar11;
          *(int *)(&stack0x000001ec + lVar15) = iVar11;
          if (iVar11 == *(int *)(&stack0x00000268 + lVar15)) {
            pplVar37 = (longlong **)(param_1 + 0x68);
            lVar20 = **pplVar37;
            *(longlong *)(&stack0x00000f30 + lVar15) = lVar20;
            *(int **)(&stack0x00000f38 + lVar15) = (int *)(lVar20 + 0x10);
            iVar11 = *(int *)(lVar20 + 0x10);
            *(int *)(&stack0x000006fc + lVar15) = iVar11;
            sVar34 = *(short *)(lVar20 + 0x14);
            *(short *)(&stack0x00000700 + lVar15) = sVar34;
            *(int *)(&stack0x00000044 + lVar15) = iVar11;
            *(short *)(&stack0x00000048 + lVar15) = sVar34;
            *(undefined4 *)(&stack0x00000702 + lVar15) = 0;
            *(undefined2 *)(&stack0x00000706 + lVar15) = 0;
            if ((iVar11 != 0) || (sVar34 != 0)) {
              *(undefined **)(&stack0x00000f88 + lVar15) = &stack0x000004e8 + lVar15;
              *(int *)(&stack0x000004e8 + lVar15) = iVar11;
              *(short *)(&stack0x000004ec + lVar15) = sVar34;
              *(longlong ***)(&stack0x000006c0 + lVar15) = pplVar37;
              plVar28 = *(longlong **)(param_1 + 8);
              *(longlong **)(&stack0x000006d0 + lVar15) = plVar28;
              *(undefined8 *)(&stack0x000005b0 + lVar15) = *(undefined8 *)(param_1 + 0x10);
              *(undefined4 *)(&stack0x00000350 + lVar15) = 0;
              *(undefined4 *)(&stack0x00000354 + lVar15) = 0;
              *(undefined2 *)(&stack0x00000358 + lVar15) = 0;
              lVar20 = *plVar28;
              *(longlong *)(&stack0x000006c8 + lVar15) = lVar20;
              *(undefined4 *)(&stack0x0000097c + lVar15) = 0;
              *(undefined4 *)(&stack0x00000980 + lVar15) = 0;
              lVar33 = *(longlong *)(lVar20 + 0x20);
              *(longlong *)(&stack0x000000c8 + lVar15) = lVar33;
              *(uint6 **)(&stack0x00000f90 + lVar15) = (uint6 *)(lVar20 + 0x14);
              lVar24 = (ulonglong)*(uint6 *)(lVar20 + 0x14) * 0x10000;
              *(longlong *)(&stack0x00000f98 + lVar15) = lVar24;
              lVar20 = *(longlong *)(lVar33 + 2000);
              if ((lVar20 == lVar24) && (lVar20 - 1U < 0xfffffffffffffffe)) {
                (&stack0x0000003a)[lVar15] = 1;
              }
              else {
                (&stack0x0000003a)[lVar15] = 0;
                if ((*(longlong *)(*(longlong *)(&stack0x000000c8 + lVar15) + 0x7d8) == lVar24) &&
                   (*(longlong *)(*(longlong *)(&stack0x000000c8 + lVar15) + 0x7d8) - 1U <
                    0xfffffffffffffffe)) {
                  (&stack0x0000003b)[lVar15] = 1;
                }
                else {
                  (&stack0x0000003b)[lVar15] = 0;
                  lVar20 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000fa0 + lVar15) = lVar20;
                  lVar33 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar20 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x00000fa8 + lVar15) = lVar33;
                  lVar20 = *(longlong *)(lVar33 + 0x100);
                  *(longlong *)(&stack0x000008a0 + lVar15) = lVar20;
                  puVar23 = _DAT_;
                  if (lVar20 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10409b;
                    puVar23 = (uint *)(*_DAT_)(0);
                    lVar20 = *(longlong *)(lVar33 + 0x100);
                    *(longlong *)(&stack0x000008a0 + lVar15) = lVar20;
                  }
                  *(longlong *)(&stack0x00000fb0 + lVar15) = lVar20;
                  uVar36 = rdtsc();
                  uVar19 = CONCAT44((int)((ulonglong)puVar23 >> 0x20),(int)uVar36) |
                           uVar36 & 0xffffffff00000000;
                  *(ulonglong *)(&stack0x00000fb8 + lVar15) = uVar19;
                  uVar36 = *(ulonglong *)(lVar20 + 0x340);
                  if ((uVar36 < uVar19) ||
                     ((uVar36 != 0x7fffffffffffffff &&
                      (*(ulonglong *)(*(longlong *)(lVar20 + 0x260) + 0xdf0) < uVar36 - uVar19)))) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10416a;
                    iVar11 = func_0x(0,0x1e85498);
                    *(int *)(&stack0x00000270 + lVar15) = iVar11;
                    if (iVar11 == 2) {
LAB_:
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10417d;
                      func_0x(0x7c);
                    }
                  }
                  else {
                    lVar20 = *(longlong *)(lVar20 + 600);
                    *(longlong *)(&stack0x000008a8 + lVar15) = lVar20;
                    puVar23 = (uint *)(lVar20 + 0xbc);
                    *(uint **)(&stack0x00000fc0 + lVar15) = puVar23;
                    if ((*puVar23 & 4) != 0) {
                      lVar20 = *(longlong *)(*(longlong *)(&stack0x000008a8 + lVar15) + 0x98);
                      *(longlong *)(&stack0x00000fc8 + lVar15) = lVar20;
                      if (((*(byte *)(lVar20 + 0x268) & 1) == 0) &&
                         ((*(uint *)(lVar20 + 800) & 0x180) == 0)) {
                        *(undefined4 *)(&stack0x00000270 + lVar15) = 2;
                        goto LAB_;
                      }
                    }
                    *(undefined4 *)(&stack0x00000270 + lVar15) = 0;
                  }
                }
              }
              *(undefined4 *)(&stack0x00000708 + lVar15) = 0;
              *(undefined4 *)(&stack0x0000070c + lVar15) = 0;
              *(undefined2 *)(&stack0x00000710 + lVar15) = 0;
              if (*(longlong *)(&stack0x000006c0 + lVar15) == 0) {
                (&stack0x00000028)[lVar15] = 0;
              }
              else {
                (&stack0x00000028)[lVar15] = 1;
                uVar9 = 0xff;
                if (*(char *)(*(longlong *)(&stack0x000000c8 + lVar15) + 0x2050) != '\0')
                goto LAB_;
              }
              uVar9 = 2;
LAB_:
              (&stack0x00000029)[lVar15] = uVar9;
              do {
                *(undefined **)(&stack0x000006b0 + lVar15) = &stack0x00000978 + lVar15;
                *(undefined4 *)(&stack0x000016ec + lVar15) = 0;
                *(undefined4 *)(&stack0x000016f0 + lVar15) = 0;
                cVar7 = *_DAT_;
                (&stack0x000001b0)[lVar15] = cVar7;
                uVar21 = uVar38;
                if ((cVar7 != '\0') &&
                   ((&stack0x000001f0)[lVar15] = DAT_ >> 7, -1 < (char)DAT_)) {
                  *(undefined4 *)(&stack0x000003d8 + lVar15) = 0;
                  lVar20 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000fd0 + lVar15) = lVar20;
                  plVar28 = (longlong *)
                            ((ulonglong)*_DAT_ +
                            *(longlong *)(lVar20 + (ulonglong)*_DAT_ * 8));
                  *(longlong **)(&stack0x00000fd8 + lVar15) = plVar28;
                  lVar20 = *plVar28;
                  *(longlong *)(&stack0x00000fe0 + lVar15) = lVar20;
                  if (lVar20 == 0) {
LAB_:
                    *(undefined8 *)(&stack0x00000918 + lVar15) = 0;
                  }
                  else {
                    lVar20 = **(longlong **)(lVar20 + 0x38);
                    *(longlong *)(&stack0x00000fe8 + lVar15) = lVar20;
                    if (lVar20 == 0) goto LAB_;
                    *(longlong *)(&stack0x00000918 + lVar15) = lVar20;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104298;
                    iVar11 = (*_DAT_)(lVar20,0x337);
                    *(int *)(&stack0x000003d8 + lVar15) = iVar11;
                    if (iVar11 != 0) goto LAB_;
                  }
                  lVar20 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00000ff0 + lVar15) = lVar20;
                  lVar20 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar20 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x00000ff8 + lVar15) = lVar20;
                  lVar20 = *(longlong *)(lVar20 + 8);
                  *(longlong *)(&stack0x00001000 + lVar15) = lVar20;
                  if (lVar20 != 0) {
                    uVar21 = *(undefined8 *)(lVar20 + 0x60);
                  }
                }
LAB_:
                *(undefined8 *)(&stack0x00000260 + lVar15) = uVar21;
                lVar20 = *(longlong *)(&stack0x000000c8 + lVar15);
                *(undefined8 *)(&stack0x000008b8 + lVar15) = *(undefined8 *)(lVar20 + 0x728);
LAB_:
                *(undefined4 *)(&stack0x00000280 + lVar15) = 0;
                if (*(longlong *)((longlong)&plStackX_10 + lVar15) != 0) {
                  puVar17 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 0x62);
                  *(undefined2 **)(&stack0x00001008 + lVar15) = puVar17;
                  *(undefined2 *)(&stack0x000001a0 + lVar15) = *puVar17;
                  if (((*(ushort *)(&stack0x000001a0 + lVar15) & 0x400) == 0) ||
                     (*(short *)((longlong)&uStackX_1c + lVar15) < 3)) {
                    *(int *)(&stack0x00000098 + lVar15) =
                         (int)*(short *)((longlong)&uStackX_1c + lVar15);
                    *(undefined8 *)(&stack0x00000590 + lVar15) =
                         *(undefined8 *)((longlong)&plStackX_10 + lVar15);
                    *(undefined2 **)(&stack0x00001010 + lVar15) = puVar17;
                    uVar10 = *puVar17;
                    *(undefined2 *)(&stack0x00000138 + lVar15) = uVar10;
                    if (((byte)uVar10 >> 3 & 1) != 0) {
                      if (*(int *)(&stack0x00000098 + lVar15) == 3) {
                        *(undefined4 *)(&stack0x00000098 + lVar15) = 4;
                      }
                      else if (*(int *)(&stack0x00000098 + lVar15) < 2) goto LAB_;
                      puVar23 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 100);
                      *(uint **)(&stack0x00001018 + lVar15) = puVar23;
                      uVar22 = *puVar23;
                      *(uint *)(&stack0x000003e0 + lVar15) = uVar22;
                      if ((((uVar22 & 8) != 0) &&
                          (lVar33 = *(longlong *)
                                     (*(longlong *)((longlong)&plStackX_10 + lVar15) + 0x90),
                          lVar33 != 0)) &&
                         (*(longlong *)(&stack0x00001020 + lVar15) = lVar33,
                         *(longlong *)(lVar33 + 0x758) != 0)) {
                        uVar21 = *(undefined8 *)(lVar33 + 0x758);
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104428;
                        func_0x
                                  (uVar21,*(undefined8 *)((longlong)&plStackX_10 + lVar15),
                                   *(undefined4 *)(&stack0x00000098 + lVar15));
                      }
                    }
LAB_:
                    (&stack0x000001f1)[lVar15] = DAT_ >> 7;
                    if ((char)DAT_ < '\0') {
                      puVar23 = (uint *)(*(longlong *)(&stack0x00000590 + lVar15) + 100);
                      *(uint **)(&stack0x00001028 + lVar15) = puVar23;
                      uVar22 = *puVar23;
                      *(uint *)(&stack0x000003e8 + lVar15) = uVar22;
                      if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000098 + lVar15))) {
                        *(uint **)(&stack0x00001030 + lVar15) = puVar23;
                        uVar22 = *puVar23;
                        *(uint *)(&stack0x000003f0 + lVar15) = uVar22;
                        if (((uVar22 & 0xc0000000) != 0x40000000) &&
                           (lVar33 = **(longlong **)(&stack0x00000590 + lVar15), lVar33 != 0)) {
                          *(undefined4 *)(&stack0x000008f0 + lVar15) = 2;
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1044b7;
                          iVar11 = (*_DAT_)(lVar33,0x2000,2,&stack0x000008f4 + lVar15);
                          if (iVar11 != 0) {
                            LOCK();
                            *puVar23 = *puVar23 & 0x3fffffff;
                            UNLOCK();
                            LOCK();
                            *puVar23 = *puVar23 | 0x40000000;
                            UNLOCK();
                          }
                        }
                      }
                    }
                    lVar33 = *(longlong *)(&stack0x00000590 + lVar15);
                    uVar14 = *(undefined4 *)(&stack0x00000098 + lVar15);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1044e6;
                    func_0x(lVar33 + 0x98,uVar14);
                    if ((_DAT_ != 0) &&
                       ((&stack0x000001f2)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0
                       )) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104510;
                      func_0x(lVar33,0,uVar14);
                    }
                    *(uint *)((longlong)&uStackX_1c + lVar15) =
                         *(uint *)((longlong)&uStackX_1c + lVar15) & 0xffff0000;
                    *(undefined8 *)((longlong)&plStackX_10 + lVar15) = 0;
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104321;
                    func_0x((longlong)&plStackX_10 + lVar15);
                  }
                }
                if (*(longlong *)(lVar20 + 0x728) != 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104547;
                  func_0x((longlong)&plStackX_10 + lVar15,&stack0x00000044 + lVar15,
                                  *(undefined8 *)(&stack0x000000c8 + lVar15));
                  if (*(longlong *)((longlong)&plStackX_10 + lVar15) != 0) {
                    puVar17 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 0x62);
                    *(undefined2 **)(&stack0x00001038 + lVar15) = puVar17;
                    *(undefined2 *)(&stack0x00000140 + lVar15) = *puVar17;
                    if (((*(ushort *)(&stack0x00000140 + lVar15) & 0x400) == 0) ||
                       (*(short *)((longlong)&uStackX_1c + lVar15) < 3)) {
                      *(int *)(&stack0x00000050 + lVar15) =
                           (int)*(short *)((longlong)&uStackX_1c + lVar15);
                      *(undefined8 *)(&stack0x00000598 + lVar15) =
                           *(undefined8 *)((longlong)&plStackX_10 + lVar15);
                      *(undefined2 **)(&stack0x00001040 + lVar15) = puVar17;
                      uVar10 = *puVar17;
                      *(undefined2 *)(&stack0x00000148 + lVar15) = uVar10;
                      if (((byte)uVar10 >> 3 & 1) != 0) {
                        if (*(int *)(&stack0x00000050 + lVar15) == 3) {
                          *(undefined4 *)(&stack0x00000050 + lVar15) = 4;
                        }
                        else if (*(int *)(&stack0x00000050 + lVar15) < 2) goto LAB_;
                        puVar23 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 100);
                        *(uint **)(&stack0x00001048 + lVar15) = puVar23;
                        uVar22 = *puVar23;
                        *(uint *)(&stack0x000003f8 + lVar15) = uVar22;
                        if ((((uVar22 & 8) != 0) &&
                            (lVar33 = *(longlong *)
                                       (*(longlong *)((longlong)&plStackX_10 + lVar15) + 0x90),
                            lVar33 != 0)) &&
                           (*(longlong *)(&stack0x00001050 + lVar15) = lVar33,
                           *(longlong *)(lVar33 + 0x758) != 0)) {
                          uVar21 = *(undefined8 *)(lVar33 + 0x758);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10463d;
                          func_0x
                                    (uVar21,*(undefined8 *)((longlong)&plStackX_10 + lVar15),
                                     *(undefined4 *)(&stack0x00000050 + lVar15));
                        }
                      }
LAB_:
                      (&stack0x000001f3)[lVar15] = DAT_ >> 7;
                      if ((char)DAT_ < '\0') {
                        puVar23 = (uint *)(*(longlong *)(&stack0x00000598 + lVar15) + 100);
                        *(uint **)(&stack0x00001058 + lVar15) = puVar23;
                        uVar22 = *puVar23;
                        *(uint *)(&stack0x00000400 + lVar15) = uVar22;
                        if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000050 + lVar15))) {
                          *(uint **)(&stack0x00001060 + lVar15) = puVar23;
                          uVar22 = *puVar23;
                          *(uint *)(&stack0x00000408 + lVar15) = uVar22;
                          if (((uVar22 & 0xc0000000) != 0x40000000) &&
                             (lVar33 = **(longlong **)(&stack0x00000598 + lVar15), lVar33 != 0)) {
                            *(undefined4 *)(&stack0x000008f8 + lVar15) = 2;
                            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1046cc;
                            iVar11 = (*_DAT_)(lVar33,0x2000,2,&stack0x000008fc + lVar15);
                            if (iVar11 != 0) {
                              LOCK();
                              *puVar23 = *puVar23 & 0x3fffffff;
                              UNLOCK();
                              LOCK();
                              *puVar23 = *puVar23 | 0x40000000;
                              UNLOCK();
                            }
                          }
                        }
                      }
                      lVar33 = *(longlong *)(&stack0x00000598 + lVar15);
                      uVar14 = *(undefined4 *)(&stack0x00000050 + lVar15);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1046fb;
                      func_0x(lVar33 + 0x98,uVar14);
                      if ((_DAT_ != 0) &&
                         ((&stack0x000001f4)[lVar15] = DAT_ >> 1,
                         (DAT_ >> 1 & 1) != 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104725;
                        func_0x(lVar33,0,uVar14);
                      }
                      *(uint *)((longlong)&uStackX_1c + lVar15) =
                           *(uint *)((longlong)&uStackX_1c + lVar15) & 0xffff0000;
                      *(undefined8 *)((longlong)&plStackX_10 + lVar15) = 0;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10458b;
                      func_0x((longlong)&plStackX_10 + lVar15);
                    }
                  }
                }
                *(undefined8 *)(&stack0xfffffffffffffff0 + lVar15) =
                     *(undefined8 *)(&stack0x000006b0 + lVar15);
                *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104765;
                plVar28 = (longlong *)
                          func_0x
                                    (_DAT_,*(undefined8 *)(&stack0x000000c8 + lVar15),
                                     &stack0x00000044 + lVar15);
                *(longlong **)((longlong)&plStackX_10 + lVar15) = plVar28;
                uVar22 = *(uint *)((longlong)&uStackX_1c + lVar15) & 0xffff0002 | 2;
                *(uint *)((longlong)&uStackX_1c + lVar15) = uVar22;
                if (*(longlong *)(&stack0x00000260 + lVar15) != 0) {
                  lVar33 = *plVar28;
                  *(longlong *)(&stack0x00001068 + lVar15) = lVar33;
                  plVar29 = (longlong *)(*(longlong *)(&stack0x00000260 + lVar15) + 0x500);
                  *(longlong **)(&stack0x00001070 + lVar15) = plVar29;
                  plVar28 = plVar29 + (ulonglong)(*(uint *)plVar29 & 0xf) + 1;
                  *(longlong **)(&stack0x00001078 + lVar15) = plVar28;
                  if (*plVar28 != lVar33) {
                    *plVar28 = lVar33;
                    *plVar29 = *plVar29 + 1;
                    uVar22 = *(uint *)((longlong)&uStackX_1c + lVar15);
                  }
                }
                uVar13 = *(uint *)(&stack0x00000280 + lVar15) >> 3 & 1;
                *(uint *)((longlong)&uStackX_1c + lVar15) = uVar13 << 0x18 | uVar22 & 0xffffff;
                *(uint *)((longlong)auStackX_20 + lVar15) =
                     *(uint *)(&stack0x00000280 + lVar15) >> 4 & 1 |
                     *(uint *)((longlong)auStackX_20 + lVar15) & 0xffffff00;
                lVar33 = *(longlong *)(&stack0x000008b8 + lVar15);
                if (((lVar33 != 0) && (*(longlong *)(&stack0x00000260 + lVar15) != 0)) &&
                   (*(longlong *)(&stack0x00000260 + lVar15) ==
                    *(longlong *)(*(longlong *)(&stack0x000000c8 + lVar15) + 0x1c38))) {
                  *(uint *)(&stack0x00000900 + lVar15) = uVar13;
                  *(longlong *)(&stack0x00001080 + lVar15) = lVar33 + 0x59b8;
                  *(longlong *)(lVar33 + 0x5b28) = *(longlong *)(lVar33 + 0x5b28) + 1;
                  puVar23 = *(uint **)(&stack0x000006b0 + lVar15);
                  if (puVar23[1] != 0) {
                    *(longlong *)(lVar33 + 0x5b30) = *(longlong *)(lVar33 + 0x5b30) + 1;
                    *(longlong *)(lVar33 + 0x5b38) =
                         *(longlong *)(lVar33 + 0x5b38) + (ulonglong)*puVar23;
                    if (uVar13 != 0) {
                      *(longlong *)(lVar33 + 0x5b40) = *(longlong *)(lVar33 + 0x5b40) + 1;
                      *(longlong *)(lVar33 + 0x5b48) =
                           *(longlong *)(lVar33 + 0x5b48) + (ulonglong)*puVar23;
                    }
                  }
                }
                lVar33 = *(longlong *)(&stack0x000000c8 + lVar15);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10488b;
                cVar7 = func_0x(lVar33);
                if ((cVar7 == '\0') || (*(char *)(lVar33 + 0x2050) == '\0')) goto LAB_;
                if (*(int *)(&stack0x00000044 + lVar15) == 0) {
LAB_:
                  (&stack0x0000003f)[lVar15] = 1;
                  goto LAB_;
                }
                *(undefined4 *)(&stack0x000000e0 + lVar15) = 9;
                *(undefined2 *)(&stack0x000000e4 + lVar15) = 1;
                if ((*(int *)(&stack0x00000044 + lVar15) == 9) &&
                   (*(short *)(&stack0x00000048 + lVar15) == 1)) goto LAB_;
                (&stack0x0000003f)[lVar15] = 0;
                lVar33 = **(longlong **)((longlong)&plStackX_10 + lVar15);
                *(longlong *)(&stack0x00001088 + lVar15) = lVar33;
                (&stack0x0000003c)[lVar15] = 0;
                if (*(short *)(lVar33 + 0x24) == 0) {
LAB_:
                  *(undefined8 *)(&stack0x000002b0 + lVar15) = *(undefined8 *)(lVar33 + 0x28);
                  *(undefined2 *)(&stack0x000002b8 + lVar15) = *(undefined2 *)(lVar33 + 0x30);
                }
                else {
                  cVar7 = *(char *)(lVar33 + 1);
                  if ((((cVar7 == '\v') || (cVar7 == '\b')) || (cVar7 == '\t')) &&
                     (*(int *)(lVar33 + 0x18) == 99)) {
                    *(undefined **)(&stack0x00001090 + lVar15) = &stack0x00000318 + lVar15;
                    *(undefined4 **)(&stack0x00001098 + lVar15) = (undefined4 *)(lVar33 + 0x20);
                    *(undefined4 *)(&stack0x00000318 + lVar15) = *(undefined4 *)(lVar33 + 0x20);
                    *(undefined2 *)(&stack0x0000031c + lVar15) = *(undefined2 *)(lVar33 + 0x24);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104951;
                    cVar7 = func_0x(&stack0x00000318 + lVar15);
                    if (cVar7 == '\0') goto LAB_;
                    cVar7 = '\x01';
                  }
                  else {
LAB_:
                    cVar7 = '\0';
                  }
                  (&stack0x0000003c)[lVar15] = cVar7;
                  if (cVar7 == '\0') goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104973;
                  func_0x(lVar33,&stack0x000002b0 + lVar15);
                }
                *(undefined **)(&stack0x000010a0 + lVar15) = &stack0x000002b0 + lVar15;
                lVar33 = *(longlong *)(&stack0x000000c8 + lVar15) + 0x20fc;
                *(longlong *)(&stack0x000008c0 + lVar15) = lVar33;
                *(undefined4 *)(&stack0x00000274 + lVar15) = 0;
                *(undefined4 *)(&stack0x00000278 + lVar15) = 0;
                *(undefined2 *)(&stack0x0000027c + lVar15) = 0;
                *(undefined2 *)(&stack0x0000027e + lVar15) = 0;
                puVar23 = (uint *)(*(longlong *)(&stack0x000000c8 + lVar15) + 0x2108);
                *(uint **)(&stack0x000010a8 + lVar15) = puVar23;
                uVar22 = *puVar23;
                *(uint *)(&stack0x00000284 + lVar15) = uVar22;
                *(uint **)(&stack0x000008c8 + lVar15) = puVar23;
                do {
                  *(uint *)(&stack0x00000410 + lVar15) = uVar22 & 0xfffffffe;
                  *(undefined8 *)(&stack0x00000274 + lVar15) =
                       **(undefined8 **)(&stack0x000008c0 + lVar15);
                  *(undefined4 *)(&stack0x0000027c + lVar15) =
                       *(undefined4 *)(*(undefined8 **)(&stack0x000008c0 + lVar15) + 1);
                  LOCK();
                  *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
                       *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
                  UNLOCK();
                  uVar22 = **(uint **)(&stack0x000008c8 + lVar15);
                  *(uint *)(&stack0x00000284 + lVar15) = uVar22;
                } while (*(uint *)(&stack0x00000410 + lVar15) != uVar22);
                if ((*(uint *)(&stack0x000002b0 + lVar15) <= *(uint *)(&stack0x00000274 + lVar15))
                   && ((*(uint *)(&stack0x00000274 + lVar15) != *(uint *)(&stack0x000002b0 + lVar15)
                       || ((uVar22 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000274 + lVar15) >>
                                           0x20), *(uint *)(&stack0x000002b4 + lVar15) <= uVar22 &&
                           ((uVar22 != *(uint *)(&stack0x000002b4 + lVar15) ||
                            (*(ushort *)(&stack0x000002b8 + lVar15) <=
                             *(ushort *)(&stack0x0000027c + lVar15))))))))) goto LAB_;
                if (*(char *)(*(longlong *)(&stack0x000000c8 + lVar15) + 0x6ac8) != '\0') {
LAB_:
                  if ((&stack0x00000028)[lVar15] != '\0') goto LAB_;
                  lVar33 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                  *(longlong *)(&stack0x00001178 + lVar15) = lVar33;
                  lVar33 = (ulonglong)*_DAT_ +
                           *(longlong *)(lVar33 + (ulonglong)*_DAT_ * 8);
                  *(longlong *)(&stack0x00001180 + lVar15) = lVar33;
                  lVar33 = *(longlong *)(lVar33 + 8);
                  *(longlong *)(&stack0x00001188 + lVar15) = lVar33;
                  lVar33 = *(longlong *)(lVar33 + 0x60);
                  *(longlong *)(&stack0x00001190 + lVar15) = lVar33;
                  if (lVar33 == *(longlong *)(*(longlong *)(&stack0x000000c8 + lVar15) + 0x2120))
                  goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10519e;
                  cVar7 = func_0x(*(longlong *)(&stack0x000000c8 + lVar15));
                  if (cVar7 != '\0') goto LAB_;
                  if (*(longlong *)(&stack0x00000260 + lVar15) == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1051b6;
                    uVar21 = func_0x();
                    *(undefined8 *)(&stack0x00000260 + lVar15) = uVar21;
                  }
                  *(undefined **)(&stack0x00001198 + lVar15) = &stack0x000002d0 + lVar15;
                  lVar33 = **(longlong **)((longlong)&plStackX_10 + lVar15);
                  *(longlong *)(&stack0x000011a0 + lVar15) = lVar33;
                  (&stack0x0000003e)[lVar15] = 0;
                  if (*(short *)(lVar33 + 0x24) == 0) {
LAB_:
                    uVar21 = *(undefined8 *)(lVar33 + 0x28);
                    *(undefined8 *)(&stack0x000002d0 + lVar15) = uVar21;
                    uVar10 = *(undefined2 *)(lVar33 + 0x30);
                    *(undefined2 *)(&stack0x000002d8 + lVar15) = uVar10;
                  }
                  else {
                    cVar7 = *(char *)(lVar33 + 1);
                    if ((((cVar7 == '\v') || (cVar7 == '\b')) || (cVar7 == '\t')) &&
                       (*(int *)(lVar33 + 0x18) == 99)) {
                      *(undefined **)(&stack0x000011a8 + lVar15) = &stack0x00000300 + lVar15;
                      *(undefined4 **)(&stack0x000011b0 + lVar15) = (undefined4 *)(lVar33 + 0x20);
                      *(undefined4 *)(&stack0x00000300 + lVar15) = *(undefined4 *)(lVar33 + 0x20);
                      *(undefined2 *)(&stack0x00000304 + lVar15) = *(undefined2 *)(lVar33 + 0x24);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105245;
                      cVar7 = func_0x(&stack0x00000300 + lVar15);
                      if (cVar7 == '\0') goto LAB_;
                      cVar7 = '\x01';
                    }
                    else {
LAB_:
                      cVar7 = '\0';
                    }
                    (&stack0x0000003e)[lVar15] = cVar7;
                    if (cVar7 == '\0') goto LAB_;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105267;
                    func_0x(lVar33,&stack0x000002d0 + lVar15);
                    uVar10 = *(undefined2 *)(&stack0x000002d8 + lVar15);
                    uVar21 = *(undefined8 *)(&stack0x000002d0 + lVar15);
                  }
                  *(undefined **)(&stack0x000011b8 + lVar15) = &stack0x000002d0 + lVar15;
                  *(undefined8 *)(&stack0x00000360 + lVar15) = uVar21;
                  *(undefined2 *)(&stack0x00000368 + lVar15) = uVar10;
                  *(undefined2 *)(&stack0x0000036a + lVar15) = 0;
                  if (*(longlong *)((longlong)&plStackX_10 + lVar15) != 0) {
                    puVar17 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 0x62);
                    *(undefined2 **)(&stack0x000011c0 + lVar15) = puVar17;
                    *(undefined2 *)(&stack0x00000150 + lVar15) = *puVar17;
                    if (((*(ushort *)(&stack0x00000150 + lVar15) & 0x400) == 0) ||
                       (*(short *)((longlong)&uStackX_1c + lVar15) < 3)) {
                      *(int *)(&stack0x00000058 + lVar15) =
                           (int)*(short *)((longlong)&uStackX_1c + lVar15);
                      *(undefined8 *)(&stack0x000005a0 + lVar15) =
                           *(undefined8 *)((longlong)&plStackX_10 + lVar15);
                      *(undefined2 **)(&stack0x000011c8 + lVar15) = puVar17;
                      uVar10 = *puVar17;
                      *(undefined2 *)(&stack0x00000158 + lVar15) = uVar10;
                      if (((byte)uVar10 >> 3 & 1) != 0) {
                        if (*(int *)(&stack0x00000058 + lVar15) == 3) {
                          *(undefined4 *)(&stack0x00000058 + lVar15) = 4;
                        }
                        else if (*(int *)(&stack0x00000058 + lVar15) < 2) goto LAB_;
                        puVar23 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 100);
                        *(uint **)(&stack0x000011d0 + lVar15) = puVar23;
                        uVar22 = *puVar23;
                        *(uint *)(&stack0x00000420 + lVar15) = uVar22;
                        if ((((uVar22 & 8) != 0) &&
                            (lVar33 = *(longlong *)
                                       (*(longlong *)((longlong)&plStackX_10 + lVar15) + 0x90),
                            lVar33 != 0)) &&
                           (*(longlong *)(&stack0x000011d8 + lVar15) = lVar33,
                           *(longlong *)(lVar33 + 0x758) != 0)) {
                          uVar21 = *(undefined8 *)(lVar33 + 0x758);
                          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1053be;
                          func_0x
                                    (uVar21,*(undefined8 *)((longlong)&plStackX_10 + lVar15),
                                     *(undefined4 *)(&stack0x00000058 + lVar15));
                        }
                      }
LAB_:
                      (&stack0x000001f5)[lVar15] = DAT_ >> 7;
                      if ((char)DAT_ < '\0') {
                        puVar23 = (uint *)(*(longlong *)(&stack0x000005a0 + lVar15) + 100);
                        *(uint **)(&stack0x000011e0 + lVar15) = puVar23;
                        uVar22 = *puVar23;
                        *(uint *)(&stack0x00000428 + lVar15) = uVar22;
                        if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000058 + lVar15))) {
                          *(uint **)(&stack0x000011e8 + lVar15) = puVar23;
                          uVar22 = *puVar23;
                          *(uint *)(&stack0x00000430 + lVar15) = uVar22;
                          if (((uVar22 & 0xc0000000) != 0x40000000) &&
                             (lVar33 = **(longlong **)(&stack0x000005a0 + lVar15), lVar33 != 0)) {
                            *(undefined4 *)(&stack0x00000958 + lVar15) = 2;
                            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10544d;
                            iVar11 = (*_DAT_)(lVar33,0x2000,2,&stack0x0000095c + lVar15);
                            if (iVar11 != 0) {
                              LOCK();
                              *puVar23 = *puVar23 & 0x3fffffff;
                              UNLOCK();
                              LOCK();
                              *puVar23 = *puVar23 | 0x40000000;
                              UNLOCK();
                            }
                          }
                        }
                      }
                      lVar33 = *(longlong *)(&stack0x000005a0 + lVar15);
                      uVar14 = *(undefined4 *)(&stack0x00000058 + lVar15);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10547c;
                      func_0x(lVar33 + 0x98,uVar14);
                      if ((_DAT_ != 0) &&
                         ((&stack0x000001f6)[lVar15] = DAT_ >> 1,
                         (DAT_ >> 1 & 1) != 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1054a6;
                        func_0x(lVar33,0,uVar14);
                      }
                      *(uint *)((longlong)&uStackX_1c + lVar15) =
                           *(uint *)((longlong)&uStackX_1c + lVar15) & 0xffff0000;
                      *(undefined8 *)((longlong)&plStackX_10 + lVar15) = 0;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10530c;
                      func_0x((longlong)&plStackX_10 + lVar15);
                    }
                    uVar21 = *(undefined8 *)(&stack0x00000360 + lVar15);
                    uVar10 = *(undefined2 *)(&stack0x00000368 + lVar15);
                  }
                  *(undefined **)(&stack0x000011f0 + lVar15) = &stack0x00000728 + lVar15;
                  *(undefined8 *)(&stack0x00000728 + lVar15) = uVar21;
                  *(undefined2 *)(&stack0x00000730 + lVar15) = uVar10;
                  *(undefined **)(&stack0x000011f8 + lVar15) = &stack0x00000660 + lVar15;
                  *(undefined8 *)(&stack0x00000660 + lVar15) = uVar21;
                  *(undefined2 *)(&stack0x00000668 + lVar15) = uVar10;
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = 0;
                  uVar21 = *(undefined8 *)(lVar20 + 0x728);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10552b;
                  func_0x(uVar21,&stack0x00000660 + lVar15,4);
                  goto LAB_;
                }
                lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
                *(longlong *)(&stack0x000010b0 + lVar15) = lVar24;
                lVar24 = (ulonglong)*_DAT_ +
                         *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8);
                *(longlong *)(&stack0x000010b8 + lVar15) = lVar24;
                lVar24 = *(longlong *)(lVar24 + 8);
                *(longlong *)(&stack0x000010c0 + lVar15) = lVar24;
                lVar24 = *(longlong *)(lVar24 + 0x60);
                *(longlong *)(&stack0x000010c8 + lVar15) = lVar24;
                if (lVar24 == *(longlong *)(*(longlong *)(&stack0x000000c8 + lVar15) + 0x2120))
                goto LAB_;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104b0a;
                cVar7 = func_0x(*(longlong *)(&stack0x000000c8 + lVar15));
                if (cVar7 != '\0') goto LAB_;
                *(longlong *)(&stack0x000006b8 + lVar15) = lVar33;
                *(undefined4 *)(&stack0x00000248 + lVar15) = 0;
                *(undefined4 *)(&stack0x0000024c + lVar15) = 0;
                *(undefined2 *)(&stack0x00000250 + lVar15) = 0;
                *(undefined2 *)(&stack0x00000252 + lVar15) = 0;
                *(uint **)(&stack0x000010d0 + lVar15) = puVar23;
                uVar22 = *puVar23;
                *(uint *)(&stack0x00000288 + lVar15) = uVar22;
                puVar30 = *(undefined8 **)(&stack0x000006b8 + lVar15);
                *(longlong *)(&stack0x000008d0 + lVar15) = (longlong)puVar30 + 0xc;
                while( true ) {
                  *(uint *)(&stack0x00000414 + lVar15) = uVar22 & 0xfffffffe;
                  *(undefined8 *)(&stack0x00000248 + lVar15) = *puVar30;
                  *(undefined4 *)(&stack0x00000250 + lVar15) = *(undefined4 *)(puVar30 + 1);
                  LOCK();
                  *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15) =
                       *(undefined4 *)(&stack0xffffffffffffffc8 + lVar15);
                  UNLOCK();
                  uVar22 = **(uint **)(&stack0x000008d0 + lVar15);
                  *(uint *)(&stack0x00000288 + lVar15) = uVar22;
                  if (*(uint *)(&stack0x00000414 + lVar15) == uVar22) break;
                  puVar30 = *(undefined8 **)(&stack0x000006b8 + lVar15);
                }
                *(undefined8 *)(&stack0x00000718 + lVar15) =
                     *(undefined8 *)(&stack0x00000248 + lVar15);
                uVar5 = *(ushort *)(&stack0x00000250 + lVar15);
                *(ushort *)(&stack0x00000720 + lVar15) = uVar5;
                lVar20 = **(longlong **)((longlong)&plStackX_10 + lVar15);
                *(longlong *)(&stack0x000010d8 + lVar15) = lVar20;
                (&stack0x0000003d)[lVar15] = 0;
                if (*(short *)(lVar20 + 0x24) == 0) {
LAB_:
                  *(undefined8 *)(&stack0x000002c0 + lVar15) = *(undefined8 *)(lVar20 + 0x28);
                  uVar35 = *(ushort *)(lVar20 + 0x30);
                  *(ushort *)(&stack0x000002c8 + lVar15) = uVar35;
                }
                else {
                  cVar7 = *(char *)(lVar20 + 1);
                  if ((((cVar7 == '\v') || (cVar7 == '\b')) || (cVar7 == '\t')) &&
                     (*(int *)(lVar20 + 0x18) == 99)) {
                    *(undefined **)(&stack0x000010e0 + lVar15) = &stack0x00000308 + lVar15;
                    *(undefined4 **)(&stack0x000010e8 + lVar15) = (undefined4 *)(lVar20 + 0x20);
                    *(undefined4 *)(&stack0x00000308 + lVar15) = *(undefined4 *)(lVar20 + 0x20);
                    *(undefined2 *)(&stack0x0000030c + lVar15) = *(undefined2 *)(lVar20 + 0x24);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104c44;
                    cVar7 = func_0x(&stack0x00000308 + lVar15);
                    if (cVar7 == '\0') goto LAB_;
                    cVar7 = '\x01';
                  }
                  else {
LAB_:
                    cVar7 = '\0';
                  }
                  (&stack0x0000003d)[lVar15] = cVar7;
                  if (cVar7 == '\0') goto LAB_;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104c66;
                  func_0x(lVar20,&stack0x000002c0 + lVar15);
                  uVar35 = *(ushort *)(&stack0x000002c8 + lVar15);
                }
                if ((*(uint *)(&stack0x00000248 + lVar15) < *(uint *)(&stack0x000002c0 + lVar15)) ||
                   ((*(uint *)(&stack0x00000248 + lVar15) == *(uint *)(&stack0x000002c0 + lVar15) &&
                    ((uVar22 = (uint)((ulonglong)*(undefined8 *)(&stack0x000002c0 + lVar15) >> 0x20)
                     , *(uint *)(&stack0x0000024c + lVar15) < uVar22 ||
                     ((*(uint *)(&stack0x0000024c + lVar15) == uVar22 && (uVar5 < uVar35)))))))) {
                  lVar20 = *(longlong *)(&stack0x000000c8 + lVar15);
                  lVar33 = *(longlong *)(lVar20 + 0x6b0);
                  *(longlong *)(&stack0x000010f0 + lVar15) = lVar33;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104cfd;
                  func_0x(&stack0x000002c0 + lVar15,&stack0x00002330 + lVar15,
                                  &stack0x00000418 + lVar15);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x104d1a;
                  func_0x(&stack0x00000718 + lVar15,&stack0x00002360 + lVar15,
                                  &stack0x00000418 + lVar15);
                  *(undefined4 *)(&stack0x000008d8 + lVar15) = 0x1d;
                  *(undefined4 *)(&stack0x000008dc + lVar15) = 0x10000;
                  if ((_DAT_ & 0x10000) != 0) {
                    *(undefined2 *)(&stack0x00000540 + lVar15) = 6;
                    *(undefined **)(&stack0x000010f8 + lVar15) = &stack0x00001450 + lVar15;
                    *(undefined2 *)(&stack0x00001450 + lVar15) = 0;
                    *(undefined2 *)(&stack0x00001452 + lVar15) = 6;
                    *(undefined4 *)(&stack0x00001458 + lVar15) = 0;
                    *(undefined **)(&stack0x00001460 + lVar15) = &stack0x00001478 + lVar15;
                    *(undefined **)(&stack0x00001468 + lVar15) = &stack0x000014d8 + lVar15;
                    *(undefined4 *)(&stack0x00001698 + lVar15) = 0;
                    *(undefined4 *)(&stack0x0000169c + lVar15) = 0;
                    *(undefined8 *)(&stack0x00001470 + lVar15) = 0;
                    *(undefined8 *)(&stack0x000016a0 + lVar15) = 0;
                    *(undefined **)(&stack0x00001100 + lVar15) = &stack0x00001478 + lVar15;
                    *(undefined **)(&stack0x00001478 + lVar15) = &stack0x000016a8 + lVar15;
                    *(undefined4 *)(&stack0x00001480 + lVar15) = 0x34;
                    *(undefined2 *)(&stack0x00001484 + lVar15) = 5;
                    *(undefined2 *)(&stack0x00001486 + lVar15) = 0;
                    *(undefined **)(&stack0x00001108 + lVar15) = &stack0x00001488 + lVar15;
                    *(undefined8 *)(&stack0x00001488 + lVar15) = 0x16756f8;
                    *(undefined4 *)(&stack0x00001490 + lVar15) = 0x10;
                    *(undefined2 *)(&stack0x00001494 + lVar15) = 5;
                    *(undefined2 *)(&stack0x00001496 + lVar15) = 0;
                    *(undefined **)(&stack0x00001110 + lVar15) = &stack0x00001498 + lVar15;
                    *(undefined8 *)(&stack0x00001498 + lVar15) = 0x16756f8;
                    *(undefined4 *)(&stack0x000014a0 + lVar15) = 0x10;
                    *(undefined2 *)(&stack0x000014a4 + lVar15) = 6;
                    *(undefined2 *)(&stack0x000014a6 + lVar15) = 0;
                    *(undefined **)(&stack0x00001118 + lVar15) = &stack0x000014a8 + lVar15;
                    *(undefined8 *)(&stack0x000014a8 + lVar15) = 0;
                    *(undefined4 *)(&stack0x000014b0 + lVar15) = 0;
                    *(undefined2 *)(&stack0x000014b4 + lVar15) = 7;
                    *(undefined2 *)(&stack0x000014b6 + lVar15) = 0;
                    *(undefined **)(&stack0x00001120 + lVar15) = &stack0x000014b8 + lVar15;
                    *(undefined8 *)(&stack0x000014b8 + lVar15) = 0;
                    *(undefined4 *)(&stack0x000014c0 + lVar15) = 0;
                    *(undefined2 *)(&stack0x000014c4 + lVar15) = 8;
                    *(undefined2 *)(&stack0x000014c6 + lVar15) = 0;
                    *(undefined **)(&stack0x00001128 + lVar15) = &stack0x000014c8 + lVar15;
                    *(undefined8 *)(&stack0x000014c8 + lVar15) = 0;
                    *(undefined4 *)(&stack0x000014d0 + lVar15) = 0;
                    *(undefined2 *)(&stack0x000014d4 + lVar15) = 9;
                    *(undefined2 *)(&stack0x000014d6 + lVar15) = 0;
                    *(uint *)(&stack0x000016a8 + lVar15) = (uint)*(ushort *)(lVar20 + 0x6b8);
                    *(undefined2 *)(&stack0x000016ac + lVar15) =
                         *(undefined2 *)(&stack0x00000048 + lVar15);
                    *(undefined4 *)(&stack0x000016ae + lVar15) =
                         *(undefined4 *)(&stack0x00000044 + lVar15);
                    (&stack0x000016b2)[lVar15] = (&stack0x00000029)[lVar15];
                    lVar20 = **(longlong **)((longlong)&plStackX_10 + lVar15);
                    *(longlong *)(&stack0x00001130 + lVar15) = lVar20;
                    (&stack0x000016b3)[lVar15] = *(undefined *)(lVar20 + 1);
                    *(undefined **)(&stack0x00001138 + lVar15) = &stack0x00001488 + lVar15;
                    *(longlong *)(&stack0x00001488 + lVar15) = lVar33 + 0x254;
                    *(undefined4 *)(&stack0x00001490 + lVar15) = 0x10;
                    *(undefined2 *)(&stack0x00001494 + lVar15) = 5;
                    *(undefined2 *)(&stack0x00001496 + lVar15) = 0;
                    *(undefined **)(&stack0x00001140 + lVar15) = &stack0x00001498 + lVar15;
                    *(longlong *)(&stack0x00001498 + lVar15) = lVar33 + 0x244;
                    *(undefined4 *)(&stack0x000014a0 + lVar15) = 0x10;
                    *(undefined2 *)(&stack0x000014a4 + lVar15) = 6;
                    *(undefined2 *)(&stack0x000014a6 + lVar15) = 0;
                    *(undefined **)(&stack0x00001148 + lVar15) = &stack0x00002330 + lVar15;
                    lVar20 = -1;
                    do {
                      lVar20 = lVar20 + 1;
                    } while (*(short *)(&stack0x00002330 + lVar20 * 2 + lVar15) != 0);
                    iVar11 = (int)lVar20 * 2;
                    *(int *)(&stack0x00000908 + lVar15) = iVar11;
                    *(undefined **)(&stack0x00001150 + lVar15) = &stack0x000014a8 + lVar15;
                    *(undefined **)(&stack0x000014a8 + lVar15) = &stack0x00002330 + lVar15;
                    *(int *)(&stack0x000014b0 + lVar15) = iVar11;
                    *(undefined2 *)(&stack0x000014b4 + lVar15) = 7;
                    *(undefined2 *)(&stack0x000014b6 + lVar15) = 0;
                    *(undefined **)(&stack0x00001158 + lVar15) = &stack0x00002360 + lVar15;
                    lVar20 = -1;
                    do {
                      lVar20 = lVar20 + 1;
                    } while (*(short *)(&stack0x00002360 + lVar20 * 2 + lVar15) != 0);
                    iVar11 = (int)lVar20 * 2;
                    *(int *)(&stack0x00000950 + lVar15) = iVar11;
                    *(undefined **)(&stack0x00001160 + lVar15) = &stack0x000014b8 + lVar15;
                    *(undefined **)(&stack0x000014b8 + lVar15) = &stack0x00002360 + lVar15;
                    *(int *)(&stack0x000014c0 + lVar15) = iVar11;
                    *(undefined2 *)(&stack0x000014c4 + lVar15) = 8;
                    *(undefined2 *)(&stack0x000014c6 + lVar15) = 0;
                    *(undefined4 *)(&stack0x0000041c + lVar15) = 0;
                    UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1050cf;
                    lVar20 = (*UNRECOVERED_JUMPTABLE_00)(lVar33,&stack0x0000041c + lVar15);
                    *(longlong *)(&stack0x00001168 + lVar15) = lVar20;
                    iVar11 = 0;
                    if (lVar20 != 0) {
                      lVar33 = -1;
                      do {
                        lVar33 = lVar33 + 1;
                      } while (*(short *)(lVar20 + lVar33 * 2) != 0);
                      iVar11 = (int)lVar33 * 2;
                    }
                    *(int *)(&stack0x00000954 + lVar15) = iVar11;
                    lVar33 = *(longlong *)(&stack0x00001460 + lVar15);
                    *(longlong **)(&stack0x00001170 + lVar15) = (longlong *)(lVar33 + 0x50);
                    *(longlong *)(lVar33 + 0x50) = lVar20;
                    *(int *)(lVar33 + 0x58) = iVar11;
                    *(undefined2 *)(lVar33 + 0x5c) = 9;
                    *(undefined2 *)(lVar33 + 0x5e) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10512a;
                    func_0x(&stack0x00001448 + lVar15);
                  }
                }
LAB_:
                if ((1 < *(short *)((longlong)&uStackX_1c + lVar15)) &&
                   ((&stack0x00000029)[lVar15] != -1)) {
                  lVar20 = **(longlong **)((longlong)&plStackX_10 + lVar15);
                  *(longlong *)(&stack0x00001200 + lVar15) = lVar20;
                  if (*(char *)(lVar20 + 1) != (&stack0x00000029)[lVar15]) {
                    if (*(longlong *)(&stack0x00000260 + lVar15) != 0) {
                      *(longlong *)(&stack0x00001208 + lVar15) = lVar20;
                      *(longlong *)(*(longlong *)(&stack0x00000260 + lVar15) + 0x588) = lVar20;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105585;
                    lVar20 = func_0x();
                    if (lVar20 == 0) {
LAB_:
                      *(undefined4 *)(&stack0x00000438 + lVar15) = 0;
                    }
                    else {
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10558f;
                      lVar20 = func_0x();
                      if (*(longlong *)(lVar20 + 0x30) == 0) goto LAB_;
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10559b;
                      lVar20 = func_0x();
                      uVar22 = *(uint *)(*(longlong *)(lVar20 + 0x30) + 0xc);
                      *(uint *)(&stack0x00000840 + lVar15) = uVar22;
                      if ((0xd < uVar22) || (iVar11 = 1, (0x2640U >> (uVar22 & 0x1f) & 1) == 0)) {
                        iVar11 = 0;
                      }
                      *(int *)(&stack0x00000438 + lVar15) = iVar11;
                      if (iVar11 != 0) goto LAB_;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1055e1;
                    func_0x(0,8);
                  }
                }
LAB_:
                *(undefined4 *)(&stack0x00000738 + lVar15) = 0;
                *(undefined4 *)(&stack0x0000073c + lVar15) = 0;
                *(undefined2 *)(&stack0x00000740 + lVar15) = 0;
                if (((*(short *)(&stack0x00000358 + lVar15) == 0) &&
                    (*(int *)(&stack0x00000350 + lVar15) == 0)) &&
                   (*(int *)(&stack0x00000354 + lVar15) == 0)) goto LAB_;
                lVar20 = **(longlong **)((longlong)&plStackX_10 + lVar15);
                *(longlong *)(&stack0x00001210 + lVar15) = lVar20;
                if ((*(byte *)(lVar20 + 4) & 1) == 0) goto LAB_;
                puVar17 = (undefined2 *)
                          ((longlong)*(longlong **)((longlong)&plStackX_10 + lVar15) + 0x62);
                *(undefined2 **)(&stack0x00001218 + lVar15) = puVar17;
                *(undefined2 *)(&stack0x00000160 + lVar15) = *puVar17;
                if (((*(ushort *)(&stack0x00000160 + lVar15) & 0x400) == 0) ||
                   (*(short *)((longlong)&uStackX_1c + lVar15) < 3)) {
                  *(int *)(&stack0x00000060 + lVar15) =
                       (int)*(short *)((longlong)&uStackX_1c + lVar15);
                  *(undefined8 *)(&stack0x000005a8 + lVar15) =
                       *(undefined8 *)((longlong)&plStackX_10 + lVar15);
                  *(undefined2 **)(&stack0x00001220 + lVar15) = puVar17;
                  uVar10 = *puVar17;
                  *(undefined2 *)(&stack0x00000168 + lVar15) = uVar10;
                  if (((byte)uVar10 >> 3 & 1) != 0) {
                    if (*(int *)(&stack0x00000060 + lVar15) == 3) {
                      *(undefined4 *)(&stack0x00000060 + lVar15) = 4;
                    }
                    else if (*(int *)(&stack0x00000060 + lVar15) < 2) goto LAB_;
                    puVar23 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 100);
                    *(uint **)(&stack0x00001228 + lVar15) = puVar23;
                    uVar22 = *puVar23;
                    *(uint *)(&stack0x00000440 + lVar15) = uVar22;
                    if ((((uVar22 & 8) != 0) &&
                        (lVar20 = *(longlong *)
                                   (*(longlong *)((longlong)&plStackX_10 + lVar15) + 0x90),
                        lVar20 != 0)) &&
                       (*(longlong *)(&stack0x00001230 + lVar15) = lVar20,
                       *(longlong *)(lVar20 + 0x758) != 0)) {
                      uVar21 = *(undefined8 *)(lVar20 + 0x758);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105726;
                      func_0x
                                (uVar21,*(undefined8 *)((longlong)&plStackX_10 + lVar15),
                                 *(undefined4 *)(&stack0x00000060 + lVar15));
                    }
                  }
LAB_:
                  (&stack0x000001f7)[lVar15] = DAT_ >> 7;
                  if ((char)DAT_ < '\0') {
                    puVar23 = (uint *)(*(longlong *)(&stack0x000005a8 + lVar15) + 100);
                    *(uint **)(&stack0x00001238 + lVar15) = puVar23;
                    uVar22 = *puVar23;
                    *(uint *)(&stack0x00000448 + lVar15) = uVar22;
                    if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000060 + lVar15))) {
                      *(uint **)(&stack0x00001240 + lVar15) = puVar23;
                      uVar22 = *puVar23;
                      *(uint *)(&stack0x00000450 + lVar15) = uVar22;
                      if (((uVar22 & 0xc0000000) != 0x40000000) &&
                         (lVar20 = **(longlong **)(&stack0x000005a8 + lVar15), lVar20 != 0)) {
                        *(undefined4 *)(&stack0x00000850 + lVar15) = 2;
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1057b5;
                        iVar11 = (*_DAT_)(lVar20,0x2000,2,&stack0x00000854 + lVar15);
                        if (iVar11 != 0) {
                          LOCK();
                          *puVar23 = *puVar23 & 0x3fffffff;
                          UNLOCK();
                          LOCK();
                          *puVar23 = *puVar23 | 0x40000000;
                          UNLOCK();
                        }
                      }
                    }
                  }
                  lVar20 = *(longlong *)(&stack0x000005a8 + lVar15);
                  uVar14 = *(undefined4 *)(&stack0x00000060 + lVar15);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1057e4;
                  func_0x(lVar20 + 0x98,uVar14);
                  if ((_DAT_ != 0) &&
                     ((&stack0x000001f8)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0))
                  {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10580e;
                    func_0x(lVar20,0,uVar14);
                  }
                  *(uint *)((longlong)&uStackX_1c + lVar15) =
                       *(uint *)((longlong)&uStackX_1c + lVar15) & 0xffff0000;
                  *(undefined8 *)((longlong)&plStackX_10 + lVar15) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105673;
                  func_0x((longlong)&plStackX_10 + lVar15);
                }
                *(undefined4 *)(&stack0x000009a0 + lVar15) = 0x400060;
                *(undefined8 *)(&stack0x000009a8 + lVar15) = 0;
                *(undefined8 *)(&stack0x000009b8 + lVar15) = 0;
                *(undefined8 *)(&stack0x000009b0 + lVar15) = 0;
                *(undefined8 *)(&stack0x000009c0 + lVar15) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105858;
                func_0x(10,&stack0x000009a0 + lVar15);
              } while( true );
            }
            if (*(int *)(param_1 + 0xd0) != 2) {
              *(longlong ***)(&stack0x00000588 + lVar15) = pplVar37;
              if (*pplVar37 != (longlong *)0x0) {
                puVar17 = (undefined2 *)((longlong)*pplVar37 + 0x62);
                *(undefined2 **)(&stack0x00000f40 + lVar15) = puVar17;
                *(undefined2 *)(&stack0x00000128 + lVar15) = *puVar17;
                plVar28 = *(longlong **)(&stack0x00000588 + lVar15);
                if (((*(ushort *)(&stack0x00000128 + lVar15) & 0x400) == 0) ||
                   (*(short *)((longlong)plVar28 + 0xc) < 3)) {
                  *(int *)(&stack0x000000a0 + lVar15) = (int)*(short *)((longlong)plVar28 + 0xc);
                  lVar20 = *plVar28;
                  *(longlong *)(&stack0x00000200 + lVar15) = lVar20;
                  puVar17 = (undefined2 *)(lVar20 + 0x62);
                  *(undefined2 **)(&stack0x00000f48 + lVar15) = puVar17;
                  uVar10 = *puVar17;
                  *(undefined2 *)(&stack0x00000130 + lVar15) = uVar10;
                  if (((byte)uVar10 >> 3 & 1) != 0) {
                    if (*(int *)(&stack0x000000a0 + lVar15) == 3) {
                      *(undefined4 *)(&stack0x000000a0 + lVar15) = 4;
                    }
                    else if (*(int *)(&stack0x000000a0 + lVar15) < 2) goto LAB_;
                    *(uint **)(&stack0x00000f50 + lVar15) =
                         (uint *)(*(longlong *)(&stack0x00000200 + lVar15) + 100);
                    uVar22 = *(uint *)(*(longlong *)(&stack0x00000200 + lVar15) + 100);
                    *(uint *)(&stack0x000003c0 + lVar15) = uVar22;
                    if ((((uVar22 & 8) != 0) &&
                        (lVar20 = *(longlong *)(*(longlong *)(&stack0x00000200 + lVar15) + 0x90),
                        lVar20 != 0)) &&
                       (*(longlong *)(&stack0x00000f58 + lVar15) = lVar20,
                       *(longlong *)(lVar20 + 0x758) != 0)) {
                      uVar38 = *(undefined8 *)(lVar20 + 0x758);
                      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103db0;
                      func_0x
                                (uVar38,*(undefined8 *)(&stack0x00000200 + lVar15),
                                 *(undefined4 *)(&stack0x000000a0 + lVar15));
                    }
                  }
LAB_:
                  (&stack0x000001ae)[lVar15] = DAT_ >> 7;
                  if ((char)DAT_ < '\0') {
                    puVar23 = (uint *)(*(longlong *)(&stack0x00000200 + lVar15) + 100);
                    *(uint **)(&stack0x00000f60 + lVar15) = puVar23;
                    uVar22 = *puVar23;
                    *(uint *)(&stack0x000003c8 + lVar15) = uVar22;
                    if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000a0 + lVar15))) {
                      *(uint **)(&stack0x00000f68 + lVar15) = puVar23;
                      uVar22 = *puVar23;
                      *(uint *)(&stack0x000003d0 + lVar15) = uVar22;
                      if (((uVar22 & 0xc0000000) != 0x40000000) &&
                         (lVar20 = **(longlong **)(&stack0x00000200 + lVar15), lVar20 != 0)) {
                        *(undefined4 *)(&stack0x00000830 + lVar15) = 2;
                        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103e43;
                        iVar11 = (*_DAT_)(lVar20,0x2000,2);
                        if (iVar11 != 0) {
                          LOCK();
                          *puVar23 = *puVar23 & 0x3fffffff;
                          UNLOCK();
                          LOCK();
                          *puVar23 = *puVar23 | 0x40000000;
                          UNLOCK();
                        }
                      }
                    }
                  }
                  lVar20 = *(longlong *)(&stack0x00000200 + lVar15);
                  uVar14 = *(undefined4 *)(&stack0x000000a0 + lVar15);
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103e72;
                  func_0x(lVar20 + 0x98,uVar14);
                  if ((_DAT_ != 0) &&
                     ((&stack0x000001af)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0))
                  {
                    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103e9c;
                    func_0x(lVar20,0,uVar14);
                  }
                  *(uint *)((longlong)plVar28 + 0xc) =
                       *(uint *)((longlong)plVar28 + 0xc) & 0xffff0000;
                  **(undefined8 **)(&stack0x00000588 + lVar15) = 0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103c3c;
                  func_0x(plVar28);
                }
              }
              *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
              *(undefined8 **)(&stack0x00000f70 + lVar15) = (undefined8 *)(param_1 + 0x88);
              if (*(int *)(param_1 + 0x90) != 0) {
                *(undefined4 *)(&stack0x00000838 + lVar15) = *(undefined4 *)(param_1 + 0x94);
                *(undefined8 *)(&stack0x00000f78 + lVar15) = *(undefined8 *)(param_1 + 0x88);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x103eeb;
                func_0x();
                *(undefined4 *)(param_1 + 0x90) = 0;
              }
              *(undefined4 *)(&stack0x00000220 + lVar15) = 0;
              *(undefined2 *)(&stack0x00000224 + lVar15) = 0;
              *(undefined4 **)(&stack0x00000f80 + lVar15) = (undefined4 *)(param_1 + 0x9c);
              *(undefined4 *)(param_1 + 0x9c) = 0;
              *(undefined2 *)(param_1 + 0xa0) = 0;
              *(undefined4 *)(&stack0x00000650 + lVar15) = 0;
              *(undefined4 *)(&stack0x00000654 + lVar15) = 0;
              *(undefined2 *)(&stack0x00000658 + lVar15) = 0;
              *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x00000650 + lVar15);
              *(undefined2 *)(param_1 + 0xc4) = 0;
              *(undefined4 *)(param_1 + 0xd0) = 2;
            }
            goto LAB_;
          }
          *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x80) + 1;
          lVar20 = *(longlong *)(&stack0x000000d0 + lVar15);
        } while( true );
      }
      if (*(int *)(param_1 + 0xd0) != 2) {
        *(longlong ***)(&stack0x00000560 + lVar15) = pplVar37;
        if (*pplVar37 != (longlong *)0x0) {
          puVar16 = (ushort *)((longlong)*pplVar37 + 0x62);
          *(ushort **)(&stack0x00001440 + lVar15) = puVar16;
          uVar5 = *puVar16;
          *(ushort *)(&stack0x00000108 + lVar15) = uVar5;
          plVar28 = *(longlong **)(&stack0x00000560 + lVar15);
          if (((uVar5 & 0x400) == 0) || (*(short *)((longlong)plVar28 + 0xc) < 3)) {
            *(int *)(&stack0x000000b0 + lVar15) = (int)*(short *)((longlong)plVar28 + 0xc);
            lVar20 = *plVar28;
            *(longlong *)(&stack0x00000228 + lVar15) = lVar20;
            puVar17 = (undefined2 *)(lVar20 + 0x62);
            *(undefined2 **)(&stack0x000009c8 + lVar15) = puVar17;
            uVar10 = *puVar17;
            *(undefined2 *)(&stack0x00000110 + lVar15) = uVar10;
            if (((byte)uVar10 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000b0 + lVar15) == 3) {
                *(undefined4 *)(&stack0x000000b0 + lVar15) = 4;
              }
              else if (*(int *)(&stack0x000000b0 + lVar15) < 2) goto LAB_;
              *(uint **)(&stack0x000009d0 + lVar15) =
                   (uint *)(*(longlong *)(&stack0x00000228 + lVar15) + 100);
              uVar22 = *(uint *)(*(longlong *)(&stack0x00000228 + lVar15) + 100);
              *(uint *)(&stack0x00000610 + lVar15) = uVar22;
              if ((((uVar22 & 8) != 0) &&
                  (lVar20 = *(longlong *)(*(longlong *)(&stack0x00000228 + lVar15) + 0x90),
                  lVar20 != 0)) &&
                 (*(longlong *)(&stack0x000009d8 + lVar15) = lVar20,
                 *(longlong *)(lVar20 + 0x758) != 0)) {
                uVar38 = *(undefined8 *)(lVar20 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1007b8;
                func_0x
                          (uVar38,*(undefined8 *)(&stack0x00000228 + lVar15),
                           *(undefined4 *)(&stack0x000000b0 + lVar15));
              }
            }
LAB_:
            (&stack0x000001aa)[lVar15] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar23 = (uint *)(*(longlong *)(&stack0x00000228 + lVar15) + 100);
              *(uint **)(&stack0x000009e0 + lVar15) = puVar23;
              uVar22 = *puVar23;
              *(uint *)(&stack0x00000618 + lVar15) = uVar22;
              if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x000000b0 + lVar15))) {
                *(uint **)(&stack0x000009e8 + lVar15) = puVar23;
                uVar22 = *puVar23;
                *(uint *)(&stack0x00000620 + lVar15) = uVar22;
                if (((uVar22 & 0xc0000000) != 0x40000000) &&
                   (lVar20 = **(longlong **)(&stack0x00000228 + lVar15), lVar20 != 0)) {
                  *(undefined4 *)(&stack0x0000077c + lVar15) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100846;
                  iVar11 = (*_DAT_)(lVar20,0x2000,2,&stack0x00000780 + lVar15);
                  if (iVar11 != 0) {
                    LOCK();
                    *puVar23 = *puVar23 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar23 = *puVar23 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar20 = *(longlong *)(&stack0x00000228 + lVar15);
            uVar14 = *(undefined4 *)(&stack0x000000b0 + lVar15);
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100875;
            func_0x(lVar20 + 0x98,uVar14);
            if ((_DAT_ != 0) &&
               ((&stack0x000001ab)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10089f;
              func_0x(lVar20,0,uVar14);
            }
            *(uint *)((longlong)plVar28 + 0xc) = *(uint *)((longlong)plVar28 + 0xc) & 0xffff0000;
            **(undefined8 **)(&stack0x00000560 + lVar15) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1006f4;
            func_0x(plVar28);
          }
        }
        *(undefined4 *)(param_1 + 0x80) = 0xffffffff;
        *(undefined8 **)(&stack0x000009f0 + lVar15) = (undefined8 *)(param_1 + 0x88);
        if (*(int *)(param_1 + 0x90) != 0) {
          *(undefined4 *)(&stack0x00000788 + lVar15) = *(undefined4 *)(param_1 + 0x94);
          *(undefined8 *)(&stack0x000009f8 + lVar15) = *(undefined8 *)(param_1 + 0x88);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1008ee;
          func_0x();
          *(undefined4 *)(param_1 + 0x90) = 0;
        }
        *(undefined4 *)(&stack0x000000d8 + lVar15) = 0;
        *(undefined2 *)(&stack0x000000dc + lVar15) = 0;
        *(undefined4 **)(&stack0x00000a00 + lVar15) = (undefined4 *)(param_1 + 0x9c);
        *(undefined4 *)(param_1 + 0x9c) = 0;
        *(undefined2 *)(param_1 + 0xa0) = 0;
        *(undefined4 *)(&stack0x00000640 + lVar15) = 0;
        *(undefined4 *)(&stack0x00000644 + lVar15) = 0;
        *(undefined2 *)(&stack0x00000648 + lVar15) = 0;
        *(undefined8 *)(param_1 + 0xbc) = *(undefined8 *)(&stack0x00000640 + lVar15);
        *(undefined2 *)(param_1 + 0xc4) = 0;
        *(undefined4 *)(param_1 + 0xd0) = 2;
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x100962;
      func_0x((longlong)&plStackX_10 + lVar15);
      goto LAB_;
    }
    lVar33 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar20 = *(longlong *)(lVar33 + 0x100);
    if (lVar20 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106319;
      (*_DAT_)();
      lVar20 = *(longlong *)(lVar33 + 0x100);
    }
    if (*(int *)(lVar20 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10632f;
      (*_DAT_)();
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10633a;
  func_0x((longlong)&plStackX_10 + lVar15);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10634a;
  func_0x
            (*(ulonglong *)(&stack0x00002390 + lVar15) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar15));
  return;
LAB_:
  lVar20 = *(longlong *)(&stack0x000005b0 + lVar15);
  *(int *)(lVar20 + 4) = *(int *)(lVar20 + 4) + 1;
  if (*(longlong *)(lVar20 + 0x58) != 0) {
    piVar31 = (int *)(*(longlong *)(lVar20 + 0x58) + 4);
    *piVar31 = *piVar31 + 1;
  }
  if ((*(uint *)((longlong)&uStackX_1c + lVar15) & 0xff000000) != 0) {
    *(int *)(*(longlong *)(&stack0x000005b0 + lVar15) + 8) =
         *(int *)(*(longlong *)(&stack0x000005b0 + lVar15) + 8) + 1;
    if (*(longlong *)(lVar20 + 0x58) != 0) {
      piVar31 = (int *)(*(longlong *)(lVar20 + 0x58) + 8);
      *piVar31 = *piVar31 + 1;
    }
    if (*(char *)((longlong)auStackX_20 + lVar15) != '\0') {
      *(int *)(*(longlong *)(&stack0x000005b0 + lVar15) + 0xc) =
           *(int *)(*(longlong *)(&stack0x000005b0 + lVar15) + 0xc) + 1;
      if (*(longlong *)(lVar20 + 0x58) != 0) {
        piVar31 = (int *)(*(longlong *)(lVar20 + 0x58) + 0xc);
        *piVar31 = *piVar31 + 1;
      }
    }
  }
  if (*(int *)(&stack0x0000097c + lVar15) != 0) {
    lVar20 = **(longlong **)((longlong)&plStackX_10 + lVar15);
    *(longlong *)(&stack0x00001248 + lVar15) = lVar20;
    uVar9 = *(undefined *)(lVar20 + 1);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1058ec;
    func_0x
              (*(undefined8 *)(&stack0x000006c8 + lVar15),uVar9,&stack0x00000978 + lVar15);
  }
  if ((*(longlong *)(&stack0x000006c0 + lVar15) == 0) ||
     (*(char *)(*(longlong *)(&stack0x000000c8 + lVar15) + 0x2050) == '\0')) {
    (&stack0x00000040)[lVar15] = 0;
    cVar7 = '\x01';
    (&stack0x00000041)[lVar15] = 1;
LAB_:
    *(undefined4 *)(&stack0x000000d0 + lVar15) = 0;
    *(undefined2 *)(&stack0x000000d4 + lVar15) = 0;
    *(undefined2 *)(&stack0x000000d6 + lVar15) = 0;
    lVar20 = **(longlong **)(&stack0x000006d0 + lVar15);
    *(longlong *)(&stack0x000008e0 + lVar15) = lVar20;
    lVar33 = **(longlong **)((longlong)&plStackX_10 + lVar15);
    *(longlong *)(&stack0x00001250 + lVar15) = lVar33;
    lVar24 = *(longlong *)(lVar20 + 8);
    piVar31 = (int *)(lVar24 + 0x3c0);
    *(int **)(&stack0x00001258 + lVar15) = piVar31;
    *(undefined4 *)(&stack0x00000458 + lVar15) = 0;
    if (*(int *)(lVar33 + 0x18) == *piVar31) {
      uVar5 = *(ushort *)(lVar24 + 0x3c4);
      if ((*(ushort *)(lVar33 + 6) == uVar5) || ((uVar5 | *(ushort *)(lVar33 + 6)) < 2)) {
        *(undefined4 *)(&stack0x00000458 + lVar15) = 1;
        goto LAB_;
      }
    }
    *(longlong *)(&stack0x00001260 + lVar15) = lVar33;
    *(undefined4 *)(&stack0x000000e8 + lVar15) = 0;
    *(undefined2 *)(&stack0x000000ec + lVar15) = 0;
    *(undefined2 *)(&stack0x000000ee + lVar15) = 0;
    uVar14 = *(undefined4 *)(lVar33 + 0x18);
    *(undefined4 *)(&stack0x000000e8 + lVar15) = uVar14;
    uVar10 = *(undefined2 *)(lVar33 + 6);
    *(undefined2 *)(&stack0x000000ec + lVar15) = uVar10;
    *(undefined4 *)(&stack0x000000d0 + lVar15) = uVar14;
    *(undefined2 *)(&stack0x000000d4 + lVar15) = uVar10;
    *(undefined2 *)(&stack0x000000d6 + lVar15) = 0;
    puVar17 = (undefined2 *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 0x62);
    *(undefined2 **)(&stack0x00001268 + lVar15) = puVar17;
    *(undefined2 *)(&stack0x00000170 + lVar15) = *puVar17;
    if (((*(ushort *)(&stack0x00000170 + lVar15) & 0x400) == 0) ||
       (*(short *)((longlong)&uStackX_1c + lVar15) < 3)) {
      *(int *)(&stack0x00000068 + lVar15) = (int)*(short *)((longlong)&uStackX_1c + lVar15);
      *(undefined8 *)(&stack0x000005b8 + lVar15) = *(undefined8 *)((longlong)&plStackX_10 + lVar15);
      *(undefined2 **)(&stack0x00001270 + lVar15) = puVar17;
      uVar6 = *puVar17;
      *(undefined2 *)(&stack0x00000178 + lVar15) = uVar6;
      if (((byte)uVar6 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000068 + lVar15) == 3) {
          *(undefined4 *)(&stack0x00000068 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x00000068 + lVar15) < 2) goto LAB_;
        puVar23 = (uint *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 100);
        *(uint **)(&stack0x00001278 + lVar15) = puVar23;
        uVar22 = *puVar23;
        *(uint *)(&stack0x00000460 + lVar15) = uVar22;
        if ((((uVar22 & 8) != 0) &&
            (lVar33 = *(longlong *)(*(longlong *)((longlong)&plStackX_10 + lVar15) + 0x90),
            lVar33 != 0)) &&
           (*(longlong *)(&stack0x00001280 + lVar15) = lVar33, *(longlong *)(lVar33 + 0x758) != 0))
        {
          uVar38 = *(undefined8 *)(lVar33 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105b26;
          func_0x
                    (uVar38,*(undefined8 *)((longlong)&plStackX_10 + lVar15),
                     *(undefined4 *)(&stack0x00000068 + lVar15));
        }
      }
LAB_:
      (&stack0x000001f9)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar23 = (uint *)(*(longlong *)(&stack0x000005b8 + lVar15) + 100);
        *(uint **)(&stack0x00001288 + lVar15) = puVar23;
        uVar22 = *puVar23;
        *(uint *)(&stack0x00000468 + lVar15) = uVar22;
        if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000068 + lVar15))) {
          *(uint **)(&stack0x00001290 + lVar15) = puVar23;
          uVar22 = *puVar23;
          *(uint *)(&stack0x00000470 + lVar15) = uVar22;
          if (((uVar22 & 0xc0000000) != 0x40000000) &&
             (lVar33 = **(longlong **)(&stack0x000005b8 + lVar15), lVar33 != 0)) {
            *(undefined4 *)(&stack0x00000858 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105bb9;
            iVar11 = (*_DAT_)(lVar33,0x2000,2,&stack0x0000085c + lVar15);
            if (iVar11 != 0) {
              LOCK();
              *puVar23 = *puVar23 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar23 = *puVar23 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar33 = *(longlong *)(&stack0x000005b8 + lVar15);
      uVar12 = *(undefined4 *)(&stack0x00000068 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105be8;
      func_0x(lVar33 + 0x98,uVar12);
      if ((_DAT_ != 0) &&
         ((&stack0x000001fa)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105c12;
        func_0x(lVar33,0,uVar12);
      }
      *(uint *)((longlong)&uStackX_1c + lVar15) =
           *(uint *)((longlong)&uStackX_1c + lVar15) & 0xffff0000;
      *(undefined8 *)((longlong)&plStackX_10 + lVar15) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105a74;
      func_0x((longlong)&plStackX_10 + lVar15);
    }
    *(undefined **)(&stack0x00001298 + lVar15) = &stack0x00000330 + lVar15;
    *(undefined **)(&stack0x000012a0 + lVar15) = &stack0x00000338 + lVar15;
    lVar20 = *(longlong *)(lVar20 + 8);
    puVar25 = (undefined4 *)(lVar20 + 0x3c0);
    *(undefined4 **)(&stack0x000012a8 + lVar15) = puVar25;
    *(undefined4 *)(&stack0x00000330 + lVar15) = *puVar25;
    *(undefined2 *)(&stack0x00000334 + lVar15) = *(undefined2 *)(lVar20 + 0x3c4);
    *(undefined2 *)(&stack0x00000336 + lVar15) = 0;
    *(undefined4 *)(&stack0x00000338 + lVar15) = uVar14;
    *(undefined2 *)(&stack0x0000033c + lVar15) = uVar10;
    *(undefined2 *)(&stack0x0000033e + lVar15) = 0;
    UNRECOVERED_JUMPTABLE_00 = *(code **)**(undefined8 **)(&stack0x000008e0 + lVar15);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105c9d;
    uVar10 = (*UNRECOVERED_JUMPTABLE_00)();
    *(undefined4 *)(&stack0xffffffffffffffe8 + lVar15) =
         *(undefined4 *)(*(longlong *)(&stack0x000006d0 + lVar15) + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105cca;
    func_0x(&stack0x00000044 + lVar15,&stack0x00000338 + lVar15,uVar10);
    param_1 = *(longlong *)(&stack0x000000c0 + lVar15);
  }
  else {
    (&stack0x00000040)[lVar15] = 1;
    (&stack0xfffffffffffffff8)[lVar15] = 0;
    *(longlong *)(&stack0xfffffffffffffff0 + lVar15) = *(longlong *)(&stack0x000006c0 + lVar15);
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar15) = *(undefined8 *)(&stack0x000006c8 + lVar15);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105937;
    cVar7 = func_0x((longlong)&plStackX_10 + lVar15);
    (&stack0x00000041)[lVar15] = cVar7;
    if (cVar7 != '\0') goto LAB_;
  }
LAB_:
  (&stack0x000000f0)[lVar15] = cVar7;
  if (cVar7 == '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105cf1;
    func_0x(param_1,param_1 + 0x68);
    acStackX_8[lVar15] = '\x01';
    lVar20 = **(longlong **)(param_1 + 8);
    *(longlong *)(&stack0x000012b0 + lVar15) = lVar20;
    uVar36 = *(ulonglong *)(lVar20 + 0x14);
    *(ulonglong *)(&stack0x000012b8 + lVar15) = uVar36;
    lVar20 = *(longlong *)(lVar20 + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105d3e;
    func_0x((longlong)&plStackX_10 + lVar15,lVar20 + 0xa0,
                    ((uVar36 >> 0x20 & 0xffff) << 0x20 | uVar36 & 0xffffffff) << 0x10);
    *(undefined4 *)(param_1 + 200) = 3;
    *(uint *)(param_1 + 0xcc) = 2 - (uint)(acStackX_18[lVar15] != '\0');
    goto LAB_;
  }
  lVar20 = **(longlong **)((longlong)&plStackX_10 + lVar15);
  *(longlong *)(&stack0x000012c0 + lVar15) = lVar20;
  if (((*(byte *)(lVar20 + 4) & 1) != 0) || (*(int *)(param_1 + 0x16c) != 0)) goto LAB_;
  pplVar37 = (longlong **)(param_1 + 0x68);
  *(longlong ***)(&stack0x000005c0 + lVar15) = pplVar37;
  if (*pplVar37 != (longlong *)0x0) {
    puVar16 = (ushort *)((longlong)*pplVar37 + 0x62);
    *(ushort **)(&stack0x000012c8 + lVar15) = puVar16;
    uVar5 = *puVar16;
    *(ushort *)(&stack0x00000180 + lVar15) = uVar5;
    plVar28 = *(longlong **)(&stack0x000005c0 + lVar15);
    if (((uVar5 & 0x400) == 0) || (*(short *)((longlong)plVar28 + 0xc) < 3)) {
      *(int *)(&stack0x00000070 + lVar15) = (int)*(short *)((longlong)plVar28 + 0xc);
      lVar20 = *plVar28;
      *(longlong *)(&stack0x00000230 + lVar15) = lVar20;
      puVar17 = (undefined2 *)(lVar20 + 0x62);
      *(undefined2 **)(&stack0x000012d0 + lVar15) = puVar17;
      uVar10 = *puVar17;
      *(undefined2 *)(&stack0x00000188 + lVar15) = uVar10;
      if (((byte)uVar10 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000070 + lVar15) == 3) {
          *(undefined4 *)(&stack0x00000070 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x00000070 + lVar15) < 2) goto LAB_;
        *(uint **)(&stack0x000012d8 + lVar15) =
             (uint *)(*(longlong *)(&stack0x00000230 + lVar15) + 100);
        uVar22 = *(uint *)(*(longlong *)(&stack0x00000230 + lVar15) + 100);
        *(uint *)(&stack0x00000478 + lVar15) = uVar22;
        if ((((uVar22 & 8) != 0) &&
            (lVar20 = *(longlong *)(*(longlong *)(&stack0x00000230 + lVar15) + 0x90), lVar20 != 0))
           && (*(longlong *)(&stack0x000012e0 + lVar15) = lVar20, *(longlong *)(lVar20 + 0x758) != 0
              )) {
          uVar38 = *(undefined8 *)(lVar20 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105e9e;
          func_0x
                    (uVar38,*(undefined8 *)(&stack0x00000230 + lVar15),
                     *(undefined4 *)(&stack0x00000070 + lVar15));
        }
      }
LAB_:
      (&stack0x000000f1)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar23 = (uint *)(*(longlong *)(&stack0x00000230 + lVar15) + 100);
        *(uint **)(&stack0x000012e8 + lVar15) = puVar23;
        uVar22 = *puVar23;
        *(uint *)(&stack0x00000480 + lVar15) = uVar22;
        if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000070 + lVar15))) {
          *(uint **)(&stack0x000012f0 + lVar15) = puVar23;
          uVar22 = *puVar23;
          *(uint *)(&stack0x00000488 + lVar15) = uVar22;
          if (((uVar22 & 0xc0000000) != 0x40000000) &&
             (lVar20 = **(longlong **)(&stack0x00000230 + lVar15), lVar20 != 0)) {
            *(undefined4 *)(&stack0x00000860 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105f2d;
            iVar11 = (*_DAT_)(lVar20,0x2000,2);
            if (iVar11 != 0) {
              LOCK();
              *puVar23 = *puVar23 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar23 = *puVar23 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar20 = *(longlong *)(&stack0x00000230 + lVar15);
      uVar14 = *(undefined4 *)(&stack0x00000070 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105f5c;
      func_0x(lVar20 + 0x98,uVar14);
      if ((_DAT_ != 0) &&
         ((&stack0x000000f2)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105f86;
        func_0x(lVar20,0,uVar14);
      }
      *(uint *)((longlong)plVar28 + 0xc) = *(uint *)((longlong)plVar28 + 0xc) & 0xffff0000;
      **(undefined8 **)(&stack0x000005c0 + lVar15) = 0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105dda;
      func_0x(plVar28);
    }
  }
  *(longlong ***)(&stack0x000005c8 + lVar15) = pplVar37;
  pplVar32 = pplVar37;
  if (*pplVar37 != (longlong *)0x0) {
    puVar16 = (ushort *)((longlong)*pplVar37 + 0x62);
    *(ushort **)(&stack0x000012f8 + lVar15) = puVar16;
    uVar5 = *puVar16;
    *(ushort *)(&stack0x00000190 + lVar15) = uVar5;
    pplVar32 = *(longlong ***)(&stack0x000005c8 + lVar15);
    if (((uVar5 & 0x400) == 0) || (*(short *)((longlong)pplVar32 + 0xc) < 3)) {
      *(int *)(&stack0x00000078 + lVar15) = (int)*(short *)((longlong)pplVar32 + 0xc);
      plVar28 = *pplVar32;
      *(longlong **)(&stack0x00000210 + lVar15) = plVar28;
      puVar17 = (undefined2 *)((longlong)plVar28 + 0x62);
      *(undefined2 **)(&stack0x00001300 + lVar15) = puVar17;
      uVar10 = *puVar17;
      *(undefined2 *)(&stack0x00000198 + lVar15) = uVar10;
      if (((byte)uVar10 >> 3 & 1) != 0) {
        if (*(int *)(&stack0x00000078 + lVar15) == 3) {
          *(undefined4 *)(&stack0x00000078 + lVar15) = 4;
        }
        else if (*(int *)(&stack0x00000078 + lVar15) < 2) goto LAB_;
        *(uint **)(&stack0x00001308 + lVar15) =
             (uint *)(*(longlong *)(&stack0x00000210 + lVar15) + 100);
        uVar22 = *(uint *)(*(longlong *)(&stack0x00000210 + lVar15) + 100);
        *(uint *)(&stack0x00000490 + lVar15) = uVar22;
        if ((((uVar22 & 8) != 0) &&
            (lVar20 = *(longlong *)(*(longlong *)(&stack0x00000210 + lVar15) + 0x90), lVar20 != 0))
           && (*(longlong *)(&stack0x00001310 + lVar15) = lVar20, *(longlong *)(lVar20 + 0x758) != 0
              )) {
          uVar38 = *(undefined8 *)(lVar20 + 0x758);
          *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1060ab;
          func_0x
                    (uVar38,*(undefined8 *)(&stack0x00000210 + lVar15),
                     *(undefined4 *)(&stack0x00000078 + lVar15));
        }
      }
LAB_:
      (&stack0x000000f3)[lVar15] = DAT_ >> 7;
      if ((char)DAT_ < '\0') {
        puVar23 = (uint *)(*(longlong *)(&stack0x00000210 + lVar15) + 100);
        *(uint **)(&stack0x00001318 + lVar15) = puVar23;
        uVar22 = *puVar23;
        *(uint *)(&stack0x00000498 + lVar15) = uVar22;
        if (((uVar22 & 8) != 0) && (2 < *(int *)(&stack0x00000078 + lVar15))) {
          *(uint **)(&stack0x00001320 + lVar15) = puVar23;
          uVar22 = *puVar23;
          *(uint *)(&stack0x000004a0 + lVar15) = uVar22;
          if (((uVar22 & 0xc0000000) != 0x40000000) &&
             (lVar20 = **(longlong **)(&stack0x00000210 + lVar15), lVar20 != 0)) {
            *(undefined4 *)(&stack0x00000868 + lVar15) = 2;
            *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x10613a;
            iVar11 = (*_DAT_)(lVar20,0x2000,2);
            if (iVar11 != 0) {
              LOCK();
              *puVar23 = *puVar23 & 0x3fffffff;
              UNLOCK();
              LOCK();
              *puVar23 = *puVar23 | 0x40000000;
              UNLOCK();
            }
          }
        }
      }
      lVar20 = *(longlong *)(&stack0x00000210 + lVar15);
      uVar14 = *(undefined4 *)(&stack0x00000078 + lVar15);
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106169;
      func_0x(lVar20 + 0x98,uVar14);
      if ((_DAT_ != 0) &&
         ((&stack0x000000f4)[lVar15] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106193;
        func_0x(lVar20,0,uVar14);
      }
      *(uint *)((longlong)pplVar32 + 0xc) = *(uint *)((longlong)pplVar32 + 0xc) & 0xffff0000;
      pplVar32 = *(longlong ***)(&stack0x000005c8 + lVar15);
      *pplVar32 = (longlong *)0x0;
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x105fe7;
      func_0x(pplVar32);
    }
  }
  *pplVar32 = *(longlong **)((longlong)&plStackX_10 + lVar15);
  *(uint *)((longlong)pplVar32 + 0xc) =
       *(uint *)((longlong)pplVar32 + 0xc) & 0xffff0000 |
       (uint)*(ushort *)((longlong)&uStackX_1c + lVar15);
  *(undefined8 *)((longlong)&plStackX_10 + lVar15) = 0;
  *(uint *)((longlong)&uStackX_1c + lVar15) = *(uint *)((longlong)&uStackX_1c + lVar15) & 0xffff0000
  ;
  *(undefined4 *)(*(longlong *)(&stack0x000000c0 + lVar15) + 0x80) = 0;
  lVar20 = **pplVar37;
  *(longlong *)(&stack0x000000d0 + lVar15) = lVar20;
  *(longlong *)(&stack0x000006d8 + lVar15) = lVar20;
  *(uint *)(&stack0x00000268 + lVar15) = (uint)*(ushort *)(lVar20 + 0x16);
  iVar11 = 0;
  *(undefined4 *)(&stack0x000000d8 + lVar15) = 0;
  *(undefined4 *)(&stack0x000001ec + lVar15) = 0;
  param_3 = *(longlong **)(&stack0x00000208 + lVar15);
  *(int *)((longlong)param_3 + 0xc) = *(int *)((longlong)param_3 + 0xc) + 1;
  goto LAB_;
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106235;
  func_0x((longlong)&plStackX_10 + lVar15);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106241;
  func_0x(param_1,param_1 + 0x68);
  *(undefined8 *)(&stack0x000018a8 + lVar15) = 0;
  *(undefined **)(&stack0x00001328 + lVar15) = &stack0x000018b0 + lVar15;
  (&stack0x000018be)[lVar15] = 1;
  (&stack0x000018bf)[lVar15] = 0;
  uVar38 = *(undefined8 *)(*(longlong *)(param_1 + 8) + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106286;
  uVar14 = func_0x(&stack0x000018a8 + lVar15,&stack0x00000044 + lVar15,uVar38);
  *(undefined4 *)(&stack0x00000870 + lVar15) = uVar14;
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x106296;
  func_0x(uVar14,0x15);
  *(undefined4 *)(param_1 + 200) = 3;
  *(undefined4 *)(param_1 + 0xcc) = 3;
  acStackX_8[lVar15] = '\x01';
  *(undefined8 *)((longlong)&uStack_40 + lVar15) = 0x1062bb;
  func_0x(&stack0x000018a8 + lVar15);
LAB_:
  param_3 = *(longlong **)(&stack0x00000208 + lVar15);
  goto LAB_;
}

