
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,undefined4 param_3)

{
  ushort uVar1;
  short sVar2;
  undefined auStack_2d8 [32];
  undefined8 uStack_2b8;
  undefined4 uStack_2a8;
  undefined4 uStack_290;
  undefined8 uStack_288;
  undefined4 uStack_280;
  ushort uStack_274;
  int iStack_270;
  undefined4 uStack_26c;
  longlong lStack_268;
  undefined4 uStack_260;
  int iStack_25c;
  undefined4 uStack_258;
  undefined2 uStack_190;
  undefined4 uStack_18c;
  byte *pbStack_188;
  undefined8 uStack_180;
  undefined8 uStack_172;
  undefined2 uStack_16a;
  undefined2 uStack_168;
  undefined6 uStack_166;
  undefined4 uStack_15c;
  ulonglong uStack_30;
  
  uStack_30 = _DAT_ ^ (ulonglong)auStack_2d8;
  uStack_190 = 0xffff;
  pbStack_188 = (byte *)0x0;
  uStack_18c = 0;
  uStack_172 = 0;
  uStack_168 = 0;
  uStack_166 = 0;
  uStack_180 = 0;
  uStack_15c = 0xffffffff;
  uStack_2a8 = 0;
  if (*(ushort *)(param_2 + 0x1c) < 3) {
    iStack_270 = 0;
  }
  else {
    iStack_270 = *(ushort *)(param_2 + 0x1c) - 2;
  }
  sVar2 = 1 << ((byte)*(undefined2 *)(param_2 + 4) & 2);
  uVar1 = *(ushort *)(param_2 + 0x16);
  uStack_274 = sVar2 + -1 + *(short *)(*(longlong *)(**(longlong **)(param_1 + 8) + 8) + 0xb4) &
               -sVar2;
  uStack_290 = param_3;
  lStack_268 = param_2;
  if (uVar1 < 3) {
    uStack_2b8 = 0;
    (*_DAT_)(1,0x28677f8,0x283e2e8,0x1727);
    uVar1 = *(ushort *)(param_2 + 0x16);
  }
  if (uVar1 == 3) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(byte *)(param_1 + 0x14c) & 1) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (-1 < *(char *)(param_2 + 2)) {
    uStack_280 = 0xfd0;
    uStack_260 = 0xffffffff;
    uStack_258 = 0xffffffff;
    iStack_25c = 0x1f9e - *(int *)(*(longlong *)(**(longlong **)(param_1 + 8) + 8) + 0xb4);
    uStack_26c = 0;
    if (*(short *)(param_2 + 0x16) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uStack_288 = 0;
    uStack_15c = 0;
    if (-1 < *(char *)(param_2 + 2)) {
      pbStack_188 = (byte *)((ulonglong)*(ushort *)(param_2 + 0x1ffe) + param_2);
      if ((*pbStack_188 & 1) == 0) {
        uStack_190 = 0;
        uStack_18c = 0;
        uStack_16a = 0;
        uStack_168 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001001ee */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_188 & 0xe) * 4 + 0xfef74) - 0xe5590
                  ))(0x2434fa0,(longlong)(int)(*pbStack_188 & 0xe),pbStack_188,0);
        return;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

