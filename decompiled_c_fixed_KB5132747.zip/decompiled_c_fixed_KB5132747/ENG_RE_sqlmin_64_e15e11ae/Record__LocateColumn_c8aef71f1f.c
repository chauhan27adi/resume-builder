
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x00eaa16e) */

longlong FUN_(short *param_1,uint *param_2,undefined4 param_3,int param_4,
                     undefined4 *param_5)

{
  uint uVar1;
  uint uVar2;
  byte *pbVar3;
  code *pcVar4;
  longlong lVar5;
  uint uVar6;
  
  if (*param_1 != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar1 = *param_2;
  if ((uVar1 & 0xc0000000) == 0x80000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (param_4 == 0) {
    pcVar4 = (code *)swi(3);
    lVar5 = (*pcVar4)();
    return lVar5;
  }
  pbVar3 = *(byte **)(param_1 + 4);
  if ((*pbVar3 & 0x10) != 0) {
    uVar2 = *(uint *)(param_1 + 8);
    if ((int)uVar1 < (int)uVar2) {
      if ((uint)*(ushort *)(param_2 + 1) <= (uint)*(ushort *)(pbVar3 + uVar2)) {
        if ((param_4 != 0) &&
           (uVar6 = *(ushort *)(param_2 + 1) - 1,
           (pbVar3[(ulonglong)(uVar6 >> 3) + (ulonglong)uVar2 + 2] >> ((byte)uVar6 & 7) & 1) != 0))
        {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        if ((int)uVar1 < 0) {
          pcVar4 = (code *)swi(3);
          lVar5 = (*pcVar4)();
          return lVar5;
        }
        if ((*(ushort *)((longlong)param_2 + 6) & 8) == 0) {
          if ((*(ushort *)((longlong)param_2 + 6) & 0x10) == 0) {
            *param_5 = param_3;
            return (longlong)(int)*param_2 + *(longlong *)(param_1 + 4);
          }
          pcVar4 = (code *)swi(3);
          lVar5 = (*pcVar4)();
          return lVar5;
        }
        pcVar4 = (code *)swi(3);
        lVar5 = (*pcVar4)();
        return lVar5;
      }
    }
    pcVar4 = (code *)swi(3);
    lVar5 = (*pcVar4)();
    return lVar5;
  }
  pcVar4 = (code *)swi(3);
  lVar5 = (*pcVar4)();
  return lVar5;
}

