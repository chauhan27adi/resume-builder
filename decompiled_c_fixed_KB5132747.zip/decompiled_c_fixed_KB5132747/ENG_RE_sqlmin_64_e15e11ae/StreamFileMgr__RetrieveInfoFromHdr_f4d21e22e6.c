
/* WARNING: Removing unreachable block (ram,0x00100a9b) */
/* WARNING: Removing unreachable block (ram,0x00100aa5) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(ulonglong param_1,short *param_2,undefined4 *param_3,int *param_4,
                 undefined4 *param_5,undefined (*param_6) [16],undefined8 *param_7,
                 undefined8 *param_8)

{
  ushort *puVar1;
  longlong *plVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  byte bVar6;
  char cVar7;
  char cVar8;
  ushort uVar9;
  ushort uVar10;
  int iVar11;
  longlong lVar12;
  undefined8 uVar13;
  int *piVar14;
  uint uVar15;
  ulonglong uVar16;
  int iVar17;
  short *psVar18;
  int *piVar19;
  ulonglong uVar20;
  ulonglong uVar21;
  undefined8 *puVar22;
  ushort *puVar23;
  short sVar24;
  uint uVar25;
  byte *pbVar26;
  undefined4 *puVar27;
  undefined4 *puVar28;
  undefined (*pauVar29) [16];
  undefined (*pauVar30) [16];
  undefined8 *puVar31;
  ulonglong uVar32;
  int iVar33;
  uint uVar34;
  undefined8 uStackX_8;
  short *psStackX_10;
  uint uStackX_18;
  int *piStackX_20;
  undefined auStack_a0 [8];
  undefined auStack_98 [8];
  undefined auStack_90 [8];
  undefined8 uStack_88;
  undefined2 uStack_80;
  undefined8 uStack_78;
  undefined2 uStack_70;
  undefined8 uStack_68;
  undefined2 uStack_60;
  int iStack_58;
  ushort uStack_54;
  ushort uStack_52;
  int *piStack_50;
  
  pauVar29 = param_6;
  puVar1 = (ushort *)(param_2 + 1);
  piVar19 = (int *)0x0;
  iVar33 = 0;
  *param_5 = 0;
  *param_4 = 0;
  *param_3 = 0;
  uVar5 = uRam0000000001165c6c;
  uVar4 = uRam0000000001165c68;
  uVar3 = uRam0000000001165c64;
  *(undefined4 *)*param_6 = _DAT_;
  *(undefined4 *)(*param_6 + 4) = uVar3;
  *(undefined4 *)(*param_6 + 8) = uVar4;
  *(undefined4 *)(*param_6 + 0xc) = uVar5;
  *param_7 = 0;
  *(undefined2 *)(param_7 + 1) = 0;
  uStack_54 = 0x18;
  uStack_52 = uStack_52 & 0xffe0;
  uStackX_8 = param_1 & 0xffffffff00000000;
  iStack_58 = -0x18;
  piStack_50 = (undefined4 *)0x0;
  iVar17 = 0;
  psStackX_10 = param_2;
  piStackX_20 = param_4;
  if (*param_2 == 0) {
    pbVar26 = *(byte **)(param_2 + 4);
    if ((*pbVar26 & 0x10) == 0) {
      uVar25 = 1 << (*pbVar26 & 0xe) & 0x1105;
LAB_:
      if (uVar25 == 0) {
        if (*(int *)(param_2 + 2) == 0) {
          uVar25 = *(uint *)(param_2 + 8);
          uVar16 = (ulonglong)uVar25;
          *(uint *)(param_2 + 10) = uVar25;
          *puVar1 = 0;
          bVar6 = *pbVar26;
          if ((bVar6 & 0x10) != 0) {
            uVar25 = uVar25 + 2 + (*(ushort *)(pbVar26 + uVar16) + 7 >> 3);
            uVar16 = (ulonglong)uVar25;
            *(uint *)(param_2 + 10) = uVar25;
            bVar6 = *pbVar26;
          }
          if ((bVar6 & 0x20) == 0) {
            *(int *)(param_2 + 2) = (int)uVar16;
            param_2[0xe] = 0;
            *(int *)(param_2 + 0xc) = (int)uVar16;
          }
          else {
            puVar27 = (undefined4 *)(pbVar26 + uVar16);
            uVar9 = *(ushort *)puVar27;
            param_2[0xe] = uVar9;
            param_5 = puVar27;
            if (uVar9 == 0) {
              cVar7 = func_0x(0x1af1180);
              if (((cVar7 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
                 (*(char *)(lVar12 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1af1180);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(1,0x13e0b8c,0x1500c78,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),3);
              uVar9 = param_2[0xe];
              uVar16 = (ulonglong)*(uint *)(param_2 + 10);
            }
            uVar25 = (int)uVar16 + (uVar9 + 1) * 2;
            *(uint *)(param_2 + 0xc) = uVar25;
            if (0x1f9e < uVar25) {
              cVar7 = func_0x(0x1af1180);
              if (((cVar7 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
                 (*(char *)(lVar12 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1af1180);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x13e0b8c,0x1500c78,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar9 = param_2[0xe];
              uVar25 = *(uint *)(param_2 + 0xc);
            }
            uVar16 = (ulonglong)uVar9;
            uVar15 = *(ushort *)((longlong)puVar27 + uVar16 * 2) & 0x7fff;
            *(uint *)(param_2 + 2) = uVar15;
            if (uVar15 < uVar25) {
              cVar7 = func_0x(0x1af1180);
              if (((cVar7 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
                 (*(char *)(lVar12 + 0x499) != '\0')) {
                cVar7 = func_0x(0x1af1180);
                if (cVar7 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0x13e0b8c,0x1500c78,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar25 = *(uint *)(param_2 + 0xc);
              uVar16 = (ulonglong)(ushort)param_2[0xe];
            }
            puVar28 = puVar27;
            piVar14 = piVar19;
            if ((short)uVar16 != 0) {
              do {
                puVar27 = (undefined4 *)((longlong)puVar27 + 2);
                uVar15 = *(ushort *)puVar27 & 0x7fff;
                if ((uVar15 < uVar25) || (*(uint *)(param_2 + 2) < uVar15)) {
                  cVar7 = func_0x(0x1af1180);
                  if ((cVar7 != '\0') &&
                     ((lVar12 = func_0x(), lVar12 != 0 &&
                      (*(char *)(lVar12 + 0x499) != '\0')))) {
                    cVar7 = func_0x(0x1af1180);
                    if (cVar7 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x13e0b8c,0x1500c78,0x82a,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 4),4);
                }
                uVar16 = (ulonglong)(ushort)param_2[0xe];
                uVar34 = (int)piVar14 + 1;
                puVar28 = param_5;
                piVar14 = (int *)(ulonglong)uVar34;
                uVar25 = uVar15;
              } while ((int)uVar34 < (int)(uint)(ushort)param_2[0xe]);
            }
            if (*(short *)((longlong)puVar28 + (ulonglong)((int)uVar16 - 1) * 2 + 2) < 0) {
              pbVar26 = *(byte **)(param_2 + 4);
              do {
                uVar25 = *(ushort *)(pbVar26 + uVar16 * 2 + (ulonglong)*(uint *)(param_2 + 10)) &
                         0x7fff;
                if ((int)uVar16 == 1) {
                  uVar15 = *(uint *)(param_2 + 0xc);
                  uVar34 = uVar15;
LAB_:
                  if ((uVar25 < uVar15) || (*(uint *)(param_2 + 2) < uVar25)) goto LAB_;
                }
                else {
                  uVar34 = *(uint *)(param_2 + 0xc);
                  uVar15 = *(ushort *)
                            (pbVar26 + uVar16 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                           0x7fff;
                  if (uVar34 <= uVar15) goto LAB_;
LAB_:
                  func_0x(pbVar26,7);
                  uVar34 = *(uint *)(param_2 + 0xc);
                }
                if ((uVar15 < uVar34) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
                pbVar26 = *(byte **)(param_2 + 4);
                if (*(ushort *)(pbVar26 + uVar15) == 5) {
                  *puVar1 = *puVar1 | 2;
                  param_2[0xe] = param_2[0xe] + -1;
                  uVar21 = (ulonglong)(uVar15 & 0xffff);
                  param_2[0x15] = (short)uVar15;
                  uVar16 = *(ulonglong *)(param_2 + 4);
                  uVar9 = param_2[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar21 + 2 + uVar16) >> 0xe & 1) != 0) {
                    uVar9 = *(ushort *)(uVar21 + 2 + uVar16) & 0x3800 | param_2[0x16] & 0xc7ffU;
                  }
                  param_2[0x16] = uVar9;
                  uVar10 = (uVar9 ^ *(ushort *)(uVar21 + 2 + uVar16)) & 0x7ff ^ uVar9;
                  param_2[0x16] = uVar10;
                  uVar20 = uVar16 + 4 +
                           (ulonglong)((uVar10 & 0x7ff) * 2) + uVar21 + (uVar9 >> 0xb & 7) * 2;
                  if (uVar20 < uVar21 + uVar16) {
                    func_0x(uVar21 + uVar16,0x19);
                    uVar10 = param_2[0x16];
                    uVar21 = (ulonglong)(ushort)param_2[0x15];
                    uVar16 = (ulonglong)*(uint *)(param_2 + 4);
                  }
                  if (uVar25 - uVar15 <
                      (((uVar10 & 0x7ff) * 2 - (int)uVar21) - (int)uVar16) + (int)uVar20) {
                    func_0x(uVar21 + *(longlong *)(param_2 + 4),0x19);
                    uVar10 = param_2[0x16];
                  }
                  if (((uVar10 & 0x3800) != 0) &&
                     (puVar23 = (ushort *)
                                (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                     piVar14 = piVar19, (uVar10 & 0x3800) != 0)) {
                    do {
                      if ((uVar10 & 0x7ff) < (*puVar23 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)param_2[0x15] +
                                        *(longlong *)(param_2 + 4),0x1a);
                        uVar10 = param_2[0x16];
                      }
                      uVar25 = (int)piVar14 + 1;
                      puVar23 = puVar23 + 1;
                      piVar14 = (int *)(ulonglong)uVar25;
                    } while ((int)uVar25 < (int)(uVar10 >> 0xb & 7));
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar26 + uVar15) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar9 = param_2[0xe] - 1;
                param_2[0xe] = uVar9;
                if (uVar9 == 0) goto LAB_;
                uVar16 = (ulonglong)uVar9;
              } while (*(short *)((longlong)puVar28 + (ulonglong)(uVar9 - 1) * 2 + 2) < 0);
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
            else {
LAB_:
              pbVar26 = *(byte **)(param_2 + 4);
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
          }
          if ((*pbVar26 & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0x13) = 0;
          }
          else {
            *(int *)(param_2 + 0x13) = (int)uVar16;
            *(int *)(param_2 + 2) = (int)uVar16 + 0xe;
            uVar13 = func_0x(puVar1);
            func_0x(uVar13,auStack_a0);
            iVar11 = func_0x(auStack_a0);
            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar11;
            uVar16 = (ulonglong)*(uint *)(param_2 + 2);
          }
          iVar11 = (int)uVar16;
          if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
             (*(ulonglong *)(param_2 + 0xf) < uVar16 + *(longlong *)(param_2 + 4))) {
            cVar7 = func_0x(0x1af1180);
            if ((cVar7 != '\0') &&
               ((lVar12 = func_0x(), lVar12 != 0 &&
                (*(char *)(lVar12 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x1af1180);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x13e0b8c,0x1500c78,0x886,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),0x12);
            iVar11 = *(int *)(param_2 + 2);
          }
          if (0x3f3b < iVar11 - 1U) {
            cVar7 = func_0x(0x1af1180);
            if (((cVar7 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
               (*(char *)(lVar12 + 0x499) != '\0')) {
              cVar7 = func_0x(0x1af1180);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x13e0b8c,0x1500c78,0x88b,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),5);
          }
        }
LAB_:
        sVar24 = -(short)iStack_58;
        pauVar29 = param_6;
        if ((uStack_52 & 0x10) != 0) {
          bVar6 = **(byte **)(param_2 + 4);
          if ((bVar6 & 0x10) == 0) {
            if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar27 = piStack_50 + 1;
              uStackX_8 = CONCAT44(uStackX_8._4_4_,*piStack_50);
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_2 + 8) <= iStack_58) ||
                  (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) < uStack_54))
          goto LAB_;
        }
        puVar27 = *(undefined4 **)(param_2 + 4);
        lVar12 = (longlong)sVar24;
        if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar24) {
          uStackX_8 = (ulonglong)uStackX_8._4_4_ << 0x20;
          goto LAB_;
        }
        uVar25 = *(uint *)(param_2 + 10);
        if (sVar24 == 1) {
          uVar15 = *(uint *)(psStackX_10 + 0xc);
          uVar25 = *(ushort *)((longlong)puVar27 + lVar12 * 2 + (ulonglong)uVar25) & 0x7fff;
LAB_:
          if ((uVar25 < uVar15) || (*(uint *)(param_2 + 2) < uVar25)) goto LAB_;
        }
        else {
          puVar23 = (ushort *)((longlong)puVar27 + lVar12 * 2 + (ulonglong)uVar25);
          uVar15 = *(ushort *)((longlong)puVar27 + lVar12 * 2 + ((ulonglong)uVar25 - 2)) & 0x7fff;
          puVar27 = *(undefined4 **)(param_2 + 4);
          uVar25 = *puVar23 & 0x7fff;
          if (*(uint *)(psStackX_10 + 0xc) <= uVar15) goto LAB_;
LAB_:
          func_0x(puVar27,7);
          puVar27 = *(undefined4 **)(param_2 + 4);
        }
        puVar27 = (undefined4 *)((longlong)puVar27 + (ulonglong)uVar15);
        uStackX_8 = CONCAT44(uStackX_8._4_4_,uVar25 - uVar15);
        pauVar29 = param_6;
        goto LAB_;
      }
    }
    else {
      uVar25 = *(uint *)(param_2 + 8);
      if ((-0x18 < (int)uVar25) && (0x17 < *(ushort *)(pbVar26 + uVar25))) {
        uVar25 = (uint)(pbVar26[(ulonglong)uVar25 + 4] >> 7);
        goto LAB_;
      }
    }
    uStackX_8 = param_1 & 0xffffffff00000000;
    puVar27 = (undefined4 *)0x0;
  }
  else {
    param_5 = (undefined4 *)((ulonglong)param_5 & 0xffffffff00000000);
    puVar27 = (undefined4 *)func_0x(puVar1,&iStack_58,param_3,&uStackX_8,&param_5);
    if ((((*psStackX_10 != 0) &&
         (plVar2 = *(longlong **)(psStackX_10 + 8), plVar2 != (longlong *)0x0)) && (*plVar2 != 0))
       && (((uStack_52 & 8) == 0 && (((ulonglong)param_5 & 1) == 0)))) {
      if ((puVar27 == (undefined4 *)0x0) || (puVar27 == (undefined4 *)0x1165820)) {
        uStackX_8 = uStackX_8 & 0xffffffff00000000;
        puVar27 = (undefined4 *)0x0;
      }
      else {
        puVar27 = (undefined4 *)
                  func_0x
                            (plVar2,&iStack_58,puVar27,uStackX_8 & 0xffffffff,0,0,&uStackX_8,
                             param_5._0_4_);
      }
    }
  }
LAB_:
  puVar31 = param_8;
  if ((puVar27 == (undefined4 *)0x0) || ((int)uStackX_8 != 0x10)) {
    uStack_80 = *(undefined2 *)(param_8 + 1);
    uStack_88 = *param_8;
    (*_DAT_)(0x5a,0xf,0x17,1,&uStack_88);
    if (puVar27 != (undefined4 *)0x0) goto LAB_;
    *pauVar29 = ZEXT816(0);
    puVar27 = (undefined4 *)(*_DAT_)();
    *puVar27 = 0x16;
    (*_DAT_)();
  }
  else {
LAB_:
    uVar3 = puVar27[1];
    uVar4 = puVar27[2];
    uVar5 = puVar27[3];
    *(undefined4 *)*pauVar29 = *puVar27;
    *(undefined4 *)(*pauVar29 + 4) = uVar3;
    *(undefined4 *)(*pauVar29 + 8) = uVar4;
    *(undefined4 *)(*pauVar29 + 0xc) = uVar5;
  }
  psVar18 = psStackX_10;
  uStack_54 = 0x14;
  uStack_52 = uStack_52 & 0xffe0;
  iStack_58 = -0x14;
  piStack_50 = (int *)0x0;
  if (*psStackX_10 == 0) {
    pbVar26 = *(byte **)(param_2 + 4);
    if ((*pbVar26 & 0x10) == 0) {
      if ((1 << (*pbVar26 & 0xe) & 0x1105U) == 0) goto LAB_;
LAB_:
      puVar22 = (undefined8 *)0x0;
      iVar17 = 0;
    }
    else {
      uVar25 = *(uint *)(param_2 + 8);
      if ((((int)uVar25 < -0x13) || (*(ushort *)(pbVar26 + uVar25) < 0x14)) ||
         ((pbVar26[(ulonglong)uVar25 + 4] >> 3 & 1) != 0)) goto LAB_;
LAB_:
      if (*(int *)(param_2 + 2) == 0) {
        uVar25 = *(uint *)(param_2 + 8);
        uVar16 = (ulonglong)uVar25;
        *(uint *)(param_2 + 10) = uVar25;
        *puVar1 = 0;
        bVar6 = *pbVar26;
        if ((bVar6 & 0x10) != 0) {
          uVar25 = uVar25 + 2 + (*(ushort *)(pbVar26 + uVar16) + 7 >> 3);
          uVar16 = (ulonglong)uVar25;
          *(uint *)(param_2 + 10) = uVar25;
          bVar6 = *pbVar26;
        }
        if ((bVar6 & 0x20) == 0) {
          *(int *)(param_2 + 2) = (int)uVar16;
          param_2[0xe] = 0;
          *(int *)(param_2 + 0xc) = (int)uVar16;
        }
        else {
          pauVar29 = (undefined (*) [16])(pbVar26 + uVar16);
          uVar9 = *(ushort *)*pauVar29;
          param_2[0xe] = uVar9;
          param_6 = pauVar29;
          if (uVar9 == 0) {
            cVar7 = func_0x(0x1af1180);
            if (((cVar7 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
               (*(char *)(lVar12 + 0x499) != '\0')) {
              cVar7 = func_0x(0x1af1180);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                (*_DAT_)(1,0x13e0b8c,0x1500c78,0x80f,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),3);
            uVar9 = param_2[0xe];
            uVar16 = (ulonglong)*(uint *)(param_2 + 10);
          }
          uVar25 = (int)uVar16 + (uVar9 + 1) * 2;
          *(uint *)(param_2 + 0xc) = uVar25;
          if (0x1f9e < uVar25) {
            cVar7 = func_0x(0x1af1180);
            if (((cVar7 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
               (*(char *)(lVar12 + 0x499) != '\0')) {
              cVar7 = func_0x(0x1af1180);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x13e0b8c,0x1500c78,0x816,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar9 = param_2[0xe];
            uVar25 = *(uint *)(param_2 + 0xc);
          }
          uVar16 = (ulonglong)uVar9;
          uVar15 = *(ushort *)(*pauVar29 + uVar16 * 2) & 0x7fff;
          *(uint *)(param_2 + 2) = uVar15;
          if (uVar15 < uVar25) {
            cVar7 = func_0x(0x1af1180);
            if (((cVar7 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
               (*(char *)(lVar12 + 0x499) != '\0')) {
              cVar7 = func_0x(0x1af1180);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0x13e0b8c,0x1500c78,0x81d,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
            uVar25 = *(uint *)(param_2 + 0xc);
            uVar16 = (ulonglong)(ushort)param_2[0xe];
          }
          pauVar30 = pauVar29;
          piVar14 = piVar19;
          if ((short)uVar16 != 0) {
            do {
              pauVar29 = (undefined (*) [16])(*pauVar29 + 2);
              uVar15 = *(ushort *)*pauVar29 & 0x7fff;
              if ((uVar15 < uVar25) || (*(uint *)(param_2 + 2) < uVar15)) {
                cVar7 = func_0x(0x1af1180);
                if ((cVar7 != '\0') &&
                   ((lVar12 = func_0x(), lVar12 != 0 &&
                    (*(char *)(lVar12 + 0x499) != '\0')))) {
                  cVar7 = func_0x(0x1af1180);
                  if (cVar7 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    (*_DAT_)(1,0x13e0b8c,0x1500c78,0x82a,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),4);
              }
              uVar16 = (ulonglong)(ushort)param_2[0xe];
              uVar34 = (int)piVar14 + 1;
              pauVar30 = param_6;
              piVar14 = (int *)(ulonglong)uVar34;
              uVar25 = uVar15;
            } while ((int)uVar34 < (int)(uint)(ushort)param_2[0xe]);
          }
          if (*(short *)(*pauVar30 + (ulonglong)((int)uVar16 - 1) * 2 + 2) < 0) {
            pbVar26 = *(byte **)(param_2 + 4);
            do {
              uVar25 = *(ushort *)(pbVar26 + uVar16 * 2 + (ulonglong)*(uint *)(param_2 + 10)) &
                       0x7fff;
              if ((int)uVar16 == 1) {
                uVar15 = *(uint *)(param_2 + 0xc);
                uVar34 = uVar15;
LAB_:
                if ((uVar25 < uVar15) || (*(uint *)(param_2 + 2) < uVar25)) goto LAB_;
              }
              else {
                uVar34 = *(uint *)(param_2 + 0xc);
                uVar15 = *(ushort *)
                          (pbVar26 + uVar16 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) & 0x7fff
                ;
                if (uVar34 <= uVar15) goto LAB_;
LAB_:
                func_0x(pbVar26,7);
                uVar34 = *(uint *)(param_2 + 0xc);
              }
              if ((uVar15 < uVar34) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
              pbVar26 = *(byte **)(param_2 + 4);
              if (*(ushort *)(pbVar26 + uVar15) == 5) {
                *puVar1 = *puVar1 | 2;
                param_2[0xe] = param_2[0xe] + -1;
                uVar21 = *(ulonglong *)(param_2 + 4);
                uVar20 = (ulonglong)(uVar15 & 0xffff);
                uVar9 = param_2[0x16] & 0xc7ff;
                uVar16 = uVar20 + uVar21;
                param_2[0x15] = (short)uVar15;
                if ((*(ushort *)(uVar16 + 2) >> 0xe & 1) != 0) {
                  uVar9 = *(ushort *)(uVar16 + 2) & 0x3800 | uVar9;
                }
                param_2[0x16] = uVar9;
                uVar10 = (uVar9 ^ *(ushort *)(uVar16 + 2)) & 0x7ff ^ uVar9;
                param_2[0x16] = uVar10;
                uVar32 = (ulonglong)((uVar10 & 0x7ff) * 2) + 4 + uVar21 + (uVar9 >> 0xb & 7) * 2 +
                         uVar20;
                if (uVar32 < uVar16) {
                  func_0x(uVar16,0x19);
                  uVar10 = param_2[0x16];
                  uVar20 = (ulonglong)(ushort)param_2[0x15];
                  uVar21 = (ulonglong)*(uint *)(param_2 + 4);
                }
                if (uVar25 - uVar15 <
                    (((uVar10 & 0x7ff) * 2 - (int)uVar20) - (int)uVar21) + (int)uVar32) {
                  func_0x(uVar20 + *(longlong *)(param_2 + 4),0x19);
                  uVar10 = param_2[0x16];
                }
                if (((uVar10 & 0x3800) != 0) &&
                   (puVar23 = (ushort *)
                              (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                   piVar14 = piVar19, (uVar10 & 0x3800) != 0)) {
                  do {
                    if ((uVar10 & 0x7ff) < (*puVar23 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),
                                      0x1a);
                      uVar10 = param_2[0x16];
                    }
                    uVar25 = (int)piVar14 + 1;
                    puVar23 = puVar23 + 1;
                    piVar14 = (int *)(ulonglong)uVar25;
                  } while ((int)uVar25 < (int)(uVar10 >> 0xb & 7));
                }
                goto LAB_;
              }
              if (*(ushort *)(pbVar26 + uVar15) < 0x400) goto LAB_;
              *puVar1 = *puVar1 | 1;
              uVar9 = param_2[0xe] - 1;
              param_2[0xe] = uVar9;
              if (uVar9 == 0) goto LAB_;
              uVar16 = (ulonglong)uVar9;
            } while (*(short *)(*pauVar30 + (ulonglong)(uVar9 - 1) * 2 + 2) < 0);
            uVar16 = (ulonglong)*(uint *)(param_2 + 2);
          }
          else {
LAB_:
            pbVar26 = *(byte **)(param_2 + 4);
            uVar16 = (ulonglong)*(uint *)(param_2 + 2);
          }
        }
        if ((*pbVar26 & 0x40) == 0) {
          *(undefined4 *)(param_2 + 0x13) = 0;
        }
        else {
          *(int *)(param_2 + 0x13) = (int)uVar16;
          *(int *)(param_2 + 2) = (int)uVar16 + 0xe;
          uVar13 = func_0x(puVar1);
          func_0x(uVar13,auStack_98);
          iVar11 = func_0x(auStack_98);
          *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar11;
          uVar16 = (ulonglong)*(uint *)(param_2 + 2);
        }
        iVar11 = (int)uVar16;
        if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
           (*(ulonglong *)(param_2 + 0xf) < uVar16 + *(longlong *)(param_2 + 4))) {
          cVar7 = func_0x(0x1af1180);
          if ((cVar7 != '\0') &&
             ((lVar12 = func_0x(), lVar12 != 0 &&
              (*(char *)(lVar12 + 0x499) != '\0')))) {
            cVar7 = func_0x(0x1af1180);
            if (cVar7 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              (*_DAT_)(1,0x13e0b8c,0x1500c78,0x886,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),0x12);
          iVar11 = *(int *)(param_2 + 2);
        }
        if (0x3f3b < iVar11 - 1U) {
          cVar7 = func_0x(0x1af1180);
          if (((cVar7 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
             (*(char *)(lVar12 + 0x499) != '\0')) {
            cVar7 = func_0x(0x1af1180);
            if (cVar7 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              (*_DAT_)(1,0x13e0b8c,0x1500c78,0x88b,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),5);
        }
      }
LAB_:
      sVar24 = -(short)iStack_58;
      puVar31 = param_8;
      if ((uStack_52 & 0x10) != 0) {
        bVar6 = **(byte **)(param_2 + 4);
        if ((bVar6 & 0x10) == 0) {
          if ((1 << (bVar6 & 0xe) & 0x1105U) != 0) {
LAB_:
            iVar17 = *piStack_50;
            puVar22 = (undefined8 *)(piStack_50 + 1);
            goto LAB_;
          }
        }
        else if (((int)*(uint *)(param_2 + 8) <= iStack_58) ||
                (*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8)) < uStack_54))
        goto LAB_;
      }
      puVar22 = *(undefined8 **)(param_2 + 4);
      lVar12 = (longlong)sVar24;
      if ((uint)(int)sVar24 <= (uint)(ushort)param_2[0xe]) {
        uVar25 = *(uint *)(param_2 + 10);
        if (sVar24 == 1) {
          uVar15 = *(uint *)(psStackX_10 + 0xc);
          uVar25 = *(ushort *)((longlong)puVar22 + lVar12 * 2 + (ulonglong)uVar25) & 0x7fff;
LAB_:
          if ((uVar25 < uVar15) || (*(uint *)(param_2 + 2) < uVar25)) goto LAB_;
        }
        else {
          puVar23 = (ushort *)((longlong)puVar22 + lVar12 * 2 + (ulonglong)uVar25);
          uVar15 = *(ushort *)((longlong)puVar22 + lVar12 * 2 + ((ulonglong)uVar25 - 2)) & 0x7fff;
          puVar22 = *(undefined8 **)(param_2 + 4);
          uVar25 = *puVar23 & 0x7fff;
          if (*(uint *)(psStackX_10 + 0xc) <= uVar15) goto LAB_;
LAB_:
          func_0x(puVar22,7);
          puVar22 = *(undefined8 **)(param_2 + 4);
        }
        puVar22 = (undefined8 *)((longlong)puVar22 + (ulonglong)uVar15);
        iVar17 = uVar25 - uVar15;
        puVar31 = param_8;
      }
    }
LAB_:
    uStackX_8 = CONCAT44(uStackX_8._4_4_,iVar17);
    psVar18 = psStackX_10;
  }
  else {
    uStackX_18 = 0;
    puVar22 = (undefined8 *)func_0x(puVar1,&iStack_58);
    if ((((*psVar18 != 0) && (plVar2 = *(longlong **)(psVar18 + 8), plVar2 != (longlong *)0x0)) &&
        (*plVar2 != 0)) && (((uStack_52 & 8) == 0 && ((uStackX_18 & 1) == 0)))) {
      if ((puVar22 == (undefined8 *)0x0) || (puVar22 == (undefined8 *)0x1165820)) {
        uStackX_8 = uStackX_8 & 0xffffffff00000000;
        puVar22 = (undefined8 *)0x0;
      }
      else {
        puVar22 = (undefined8 *)
                  func_0x
                            (plVar2,&iStack_58,puVar22,uStackX_8 & 0xffffffff,0,0,&uStackX_8,
                             uStackX_18);
      }
    }
  }
  if ((puVar22 == (undefined8 *)0x0) || ((int)uStackX_8 != 10)) {
    uStack_70 = *(undefined2 *)(puVar31 + 1);
    uStack_78 = *puVar31;
    (*_DAT_)(0x5a,0xf,0x17,2,&uStack_78);
    if (puVar22 != (undefined8 *)0x0) goto LAB_;
    *param_7 = 0;
    *(undefined2 *)(param_7 + 1) = 0;
    puVar27 = (undefined4 *)(*_DAT_)();
    *puVar27 = 0x16;
    (*_DAT_)();
  }
  else {
LAB_:
    *param_7 = *puVar22;
    *(undefined2 *)(param_7 + 1) = *(undefined2 *)(puVar22 + 1);
  }
  iStack_58 = -6;
  uStack_54 = 6;
  uStack_52 = uStack_52 & 0xffe0;
  piStack_50 = (int *)0x0;
  if (*psVar18 == 0) {
    pbVar26 = *(byte **)(param_2 + 4);
    if ((*pbVar26 & 0x10) == 0) {
      cVar7 = '\x01';
      if ((1 << (*pbVar26 & 0xe) & 0x1105U) == 0) {
LAB_:
        if (*(int *)(param_2 + 2) == 0) {
          uVar25 = *(uint *)(param_2 + 8);
          uVar16 = (ulonglong)uVar25;
          *(uint *)(param_2 + 10) = uVar25;
          *puVar1 = 0;
          bVar6 = *pbVar26;
          if ((bVar6 & 0x10) != 0) {
            uVar25 = uVar25 + 2 + (*(ushort *)(pbVar26 + uVar16) + 7 >> 3);
            uVar16 = (ulonglong)uVar25;
            *(uint *)(param_2 + 10) = uVar25;
            bVar6 = *pbVar26;
          }
          if ((bVar6 & 0x20) == 0) {
            *(int *)(param_2 + 2) = (int)uVar16;
            param_2[0xe] = 0;
            *(int *)(param_2 + 0xc) = (int)uVar16;
          }
          else {
            puVar31 = (undefined8 *)(pbVar26 + uVar16);
            uVar9 = *(ushort *)puVar31;
            param_2[0xe] = uVar9;
            param_7 = puVar31;
            if (uVar9 == 0) {
              cVar8 = func_0x(0x1af1180);
              if (((cVar8 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
                 (*(char *)(lVar12 + 0x499) != '\0')) {
                cVar8 = func_0x(0x1af1180);
                if (cVar8 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  (*_DAT_)(cVar7,0x13e0b8c,0x1500c78,0x80f,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),3);
              uVar9 = param_2[0xe];
              uVar16 = (ulonglong)*(uint *)(param_2 + 10);
            }
            uVar25 = (int)uVar16 + (uVar9 + 1) * 2;
            *(uint *)(param_2 + 0xc) = uVar25;
            if (0x1f9e < uVar25) {
              cVar8 = func_0x(0x1af1180);
              if (((cVar8 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
                 (*(char *)(lVar12 + 0x499) != '\0')) {
                cVar8 = func_0x(0x1af1180);
                if (cVar8 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(cVar7,0x13e0b8c,0x1500c78,0x816,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar9 = param_2[0xe];
              uVar25 = *(uint *)(param_2 + 0xc);
            }
            uVar16 = (ulonglong)uVar9;
            uVar15 = *(ushort *)((longlong)puVar31 + uVar16 * 2) & 0x7fff;
            *(uint *)(param_2 + 2) = uVar15;
            if (uVar15 < uVar25) {
              cVar8 = func_0x(0x1af1180);
              if (((cVar8 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
                 (*(char *)(lVar12 + 0x499) != '\0')) {
                cVar8 = func_0x(0x1af1180);
                if (cVar8 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(cVar7,0x13e0b8c,0x1500c78,0x81d,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
              uVar25 = *(uint *)(param_2 + 0xc);
              uVar16 = (ulonglong)(ushort)param_2[0xe];
            }
            puVar22 = puVar31;
            piVar14 = piVar19;
            if ((short)uVar16 != 0) {
              do {
                puVar31 = (undefined8 *)((longlong)puVar31 + 2);
                uVar15 = *(ushort *)puVar31 & 0x7fff;
                if ((uVar15 < uVar25) || (*(uint *)(param_2 + 2) < uVar15)) {
                  cVar7 = func_0x(0x1af1180);
                  if ((cVar7 != '\0') &&
                     ((lVar12 = func_0x(), lVar12 != 0 &&
                      (*(char *)(lVar12 + 0x499) != '\0')))) {
                    cVar7 = func_0x(0x1af1180);
                    if (cVar7 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      (*_DAT_)(1,0x13e0b8c,0x1500c78,0x82a,0);
                    }
                  }
                  func_0x(*(undefined8 *)(param_2 + 4),4);
                }
                uVar16 = (ulonglong)(ushort)param_2[0xe];
                uVar34 = (int)piVar14 + 1;
                puVar22 = param_7;
                piVar14 = (int *)(ulonglong)uVar34;
                uVar25 = uVar15;
              } while ((int)uVar34 < (int)(uint)(ushort)param_2[0xe]);
            }
            if (*(short *)((longlong)puVar22 + (ulonglong)((int)uVar16 - 1) * 2 + 2) < 0) {
              pbVar26 = *(byte **)(param_2 + 4);
              do {
                uVar25 = *(ushort *)(pbVar26 + uVar16 * 2 + (ulonglong)*(uint *)(param_2 + 10)) &
                         0x7fff;
                if ((int)uVar16 == 1) {
                  uVar15 = *(uint *)(param_2 + 0xc);
                  uVar34 = uVar15;
LAB_:
                  if ((uVar25 < uVar15) || (*(uint *)(param_2 + 2) < uVar25)) goto LAB_;
                }
                else {
                  uVar34 = *(uint *)(param_2 + 0xc);
                  uVar15 = *(ushort *)
                            (pbVar26 + uVar16 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                           0x7fff;
                  if (uVar34 <= uVar15) goto LAB_;
LAB_:
                  func_0x(pbVar26,7);
                  uVar34 = *(uint *)(param_2 + 0xc);
                }
                if ((uVar15 < uVar34) || (*(uint *)(param_2 + 2) < uVar15)) goto LAB_;
                pbVar26 = *(byte **)(param_2 + 4);
                if (*(ushort *)(pbVar26 + uVar15) == 5) {
                  *puVar1 = *puVar1 | 2;
                  param_2[0xe] = param_2[0xe] + -1;
                  uVar20 = (ulonglong)(uVar15 & 0xffff);
                  uVar21 = *(ulonglong *)(param_2 + 4);
                  uVar16 = uVar20 + uVar21;
                  param_2[0x15] = (short)uVar15;
                  uVar9 = param_2[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar16 + 2) & 0x4000) != 0) {
                    uVar9 = *(ushort *)(uVar16 + 2) & 0x3800 | param_2[0x16] & 0xc7ffU;
                  }
                  param_2[0x16] = uVar9;
                  uVar10 = (uVar9 ^ *(ushort *)(uVar16 + 2)) & 0x7ff ^ uVar9;
                  param_2[0x16] = uVar10;
                  uVar32 = uVar21 + 4 +
                           (ulonglong)((uVar10 & 0x7ff) * 2) + uVar20 + (uVar9 >> 0xb & 7) * 2;
                  if (uVar32 < uVar16) {
                    func_0x(uVar16,0x19);
                    uVar10 = param_2[0x16];
                    uVar20 = (ulonglong)(ushort)param_2[0x15];
                    uVar21 = (ulonglong)*(uint *)(param_2 + 4);
                  }
                  uVar34 = (uint)uVar10;
                  if (uVar25 - uVar15 <
                      (((uVar34 & 0x7ff) * 2 - (int)uVar20) - (int)uVar21) + (int)uVar32) {
                    func_0x(uVar20 + *(longlong *)(param_2 + 4),0x19);
                    uVar34 = (uint)(ushort)param_2[0x16];
                  }
                  if (((uVar34 & 0x3800) != 0) &&
                     (puVar23 = (ushort *)
                                (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                     (uVar34 & 0x3800) != 0)) {
                    do {
                      if (((ushort)uVar34 & 0x7ff) < (*puVar23 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)param_2[0x15] +
                                        *(longlong *)(param_2 + 4),0x1a);
                        uVar34 = (uint)(ushort)param_2[0x16];
                      }
                      uVar25 = (int)piVar19 + 1;
                      piVar19 = (int *)(ulonglong)uVar25;
                      puVar23 = puVar23 + 1;
                    } while ((int)uVar25 < (int)(uVar34 >> 0xb & 7));
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar26 + uVar15) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar9 = param_2[0xe] - 1;
                param_2[0xe] = uVar9;
                if (uVar9 == 0) goto LAB_;
                uVar16 = (ulonglong)uVar9;
              } while (*(short *)((longlong)puVar22 + (ulonglong)(uVar9 - 1) * 2 + 2) < 0);
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
            else {
LAB_:
              pbVar26 = *(byte **)(param_2 + 4);
              uVar16 = (ulonglong)*(uint *)(param_2 + 2);
            }
          }
          if ((*pbVar26 & 0x40) == 0) {
            *(undefined4 *)(param_2 + 0x13) = 0;
          }
          else {
            *(int *)(param_2 + 0x13) = (int)uVar16;
            *(int *)(param_2 + 2) = (int)uVar16 + 0xe;
            uVar13 = func_0x(puVar1);
            func_0x(uVar13,auStack_90);
            iVar17 = func_0x(auStack_90);
            *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar17;
            uVar16 = (ulonglong)*(uint *)(param_2 + 2);
          }
          iVar17 = (int)uVar16;
          if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
             (*(ulonglong *)(param_2 + 0xf) < uVar16 + *(longlong *)(param_2 + 4))) {
            cVar7 = func_0x(0x1af1180);
            if ((cVar7 != '\0') &&
               ((lVar12 = func_0x(), lVar12 != 0 &&
                (*(char *)(lVar12 + 0x499) != '\0')))) {
              cVar7 = func_0x(0x1af1180);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                (*_DAT_)(1,0x13e0b8c,0x1500c78,0x886,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),0x12);
            iVar17 = *(int *)(param_2 + 2);
          }
          if (0x3f3b < iVar17 - 1U) {
            cVar7 = func_0x(0x1af1180);
            if (((cVar7 != '\0') && (lVar12 = func_0x(), lVar12 != 0)) &&
               (*(char *)(lVar12 + 0x499) != '\0')) {
              cVar7 = func_0x(0x1af1180);
              if (cVar7 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                (*_DAT_)(1,0x13e0b8c,0x1500c78,0x88b,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),5);
          }
        }
LAB_:
        sVar24 = -(short)iStack_58;
        if ((uStack_52 & 0x10) == 0) {
LAB_:
          piVar19 = *(int **)(param_2 + 4);
          lVar12 = (longlong)sVar24;
          if ((uint)(int)sVar24 <= (uint)(ushort)param_2[0xe]) {
            uVar25 = *(uint *)(param_2 + 10);
            if (sVar24 == 1) {
              uVar15 = *(uint *)(psStackX_10 + 0xc);
              uVar25 = *(ushort *)((longlong)piVar19 + lVar12 * 2 + (ulonglong)uVar25) & 0x7fff;
LAB_:
              if ((uVar25 < uVar15) || (*(uint *)(param_2 + 2) < uVar25)) goto LAB_;
            }
            else {
              puVar1 = (ushort *)((longlong)piVar19 + lVar12 * 2 + (ulonglong)uVar25);
              uVar15 = *(ushort *)((longlong)piVar19 + lVar12 * 2 + ((ulonglong)uVar25 - 2)) &
                       0x7fff;
              piVar19 = *(int **)(param_2 + 4);
              uVar25 = *puVar1 & 0x7fff;
              if (*(uint *)(psStackX_10 + 0xc) <= uVar15) goto LAB_;
LAB_:
              func_0x(piVar19,7);
              piVar19 = *(int **)(param_2 + 4);
            }
            iVar33 = uVar25 - uVar15;
            piVar19 = (int *)((longlong)piVar19 + (ulonglong)uVar15);
          }
        }
        else {
          bVar6 = **(byte **)(param_2 + 4);
          if ((bVar6 & 0x10) == 0) {
            if ((1 << (bVar6 & 0xe) & 0x1105U) == 0) goto LAB_;
          }
          else if ((iStack_58 < (int)*(uint *)(param_2 + 8)) &&
                  (uStack_54 <= *(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8))))
          goto LAB_;
          iVar33 = *piStack_50;
          piVar19 = piStack_50 + 1;
        }
      }
    }
    else {
      uVar25 = *(uint *)(param_2 + 8);
      if (((-6 < (int)uVar25) && (5 < *(ushort *)(pbVar26 + uVar25))) &&
         ((pbVar26[(ulonglong)uVar25 + 2] >> 5 & 1) == 0)) {
        cVar7 = (pbVar26[(ulonglong)uVar25 + 2] >> 5 & 1) + 1;
        goto LAB_;
      }
    }
  }
  else {
    piVar14 = (int *)func_0x(puVar1,&iStack_58);
    if ((((*psVar18 == 0) || (plVar2 = *(longlong **)(psVar18 + 8), plVar2 == (longlong *)0x0)) ||
        (*plVar2 == 0)) || ((uStack_52 & 8) != 0)) goto LAB_;
    if ((piVar14 != (int *)0x0) && (piVar14 != (int *)0x1165820)) {
      piVar14 = (int *)func_0x
                                 (plVar2,&iStack_58,piVar14,uStackX_8 & 0xffffffff,0,0,&uStackX_8,0)
      ;
      goto LAB_;
    }
  }
  piVar14 = piVar19;
  uStackX_8 = CONCAT44(uStackX_8._4_4_,iVar33);
LAB_:
  if ((piVar14 == (int *)0x0) || ((int)uStackX_8 != 4)) {
    uStack_68 = *param_8;
    uStack_60 = *(undefined2 *)(param_8 + 1);
    (*_DAT_)(0x5a,0xf,0x17,3,&uStack_68);
  }
  *piStackX_20 = *piVar14;
  return;
}

