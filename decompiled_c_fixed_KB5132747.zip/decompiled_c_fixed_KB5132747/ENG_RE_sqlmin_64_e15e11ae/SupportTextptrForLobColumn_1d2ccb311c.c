
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,short *param_3,uint *param_4)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  bool bVar4;
  byte bVar5;
  char cVar6;
  ushort uVar7;
  ushort uVar8;
  int iVar9;
  undefined8 uVar10;
  longlong lVar11;
  undefined8 *puVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  undefined *puVar16;
  uint *puVar17;
  uint uVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  short sVar21;
  byte *pbVar22;
  uint *puVar23;
  ushort *puVar24;
  uint uVar25;
  short *psVar26;
  uint *puVar27;
  undefined auStack_b8 [8];
  undefined8 uStack_b0;
  undefined auStack_a8 [16];
  undefined8 uStack_98;
  undefined4 uStack_90;
  uint *puStack_88;
  uint uStack_80;
  uint auStack_78 [4];
  uint uStack_68;
  uint uStack_64;
  short *psStack_60;
  undefined auStack_58 [8];
  undefined auStack_50 [8];
  undefined8 uStack_48;
  longlong *plStack_40;
  longlong lStack_38;
  ulonglong uStack_30;
  
  uStack_30 = _DAT_ ^ (ulonglong)&uStack_68;
  puVar16 = auStack_a8;
  psStack_60 = param_3;
  plStack_40 = param_2;
  lStack_38 = param_1;
  if ((*(byte *)(*(longlong *)(param_1 + 8) + 0x107) & 0x40) == 0) goto LAB_;
  uStack_b0 = 0x10005f;
  iVar9 = func_0x(param_2[6]);
  puVar16 = auStack_a8;
  if ((((iVar9 == 0) ||
       (puVar16 = auStack_a8, (*(ushort *)(*(longlong *)(param_4 + 0x12) + 0xc) & 0x40) == 0)) ||
      (puVar16 = auStack_a8, *(short *)(param_4 + 0xf) != 0x10)) ||
     (puVar16 = auStack_a8, (*(ushort *)(*(longlong *)(param_4 + 0x12) + 0xc) & 2) == 0))
  goto LAB_;
  puVar16 = auStack_b8;
  puVar1 = (ushort *)(param_3 + 1);
  iVar9 = param_4[0x10] << 0xc;
  puVar17 = (uint *)0x0;
  bVar4 = false;
  psVar26 = param_3;
  if (*param_3 == 0) {
    uVar13 = *param_4;
    if ((uVar13 & 0xc0000000) == 0x80000000) {
      iVar9 = func_0x(puVar1);
      if (iVar9 == 0) {
        uStack_68 = 0;
        puVar23 = (uint *)0x0;
      }
      else {
        puVar23 = (uint *)func_0x(param_3 + 0x15,param_4,&uStack_68,auStack_58);
      }
    }
    else {
      if ((iVar9 < 0) || ((*(byte *)((longlong)param_4 + 6) & 0x10) != 0)) {
        pbVar22 = *(byte **)(param_3 + 4);
        if ((*pbVar22 & 0x10) == 0) {
          if ((1 << (*pbVar22 & 0xe) & 0x1105U) != 0) goto LAB_;
          bVar4 = true;
          uVar18 = 0;
LAB_:
          if (iVar9 < 0) goto LAB_;
        }
        else {
          uVar18 = *(uint *)(param_3 + 8);
          if ((int)uVar18 <= (int)uVar13) {
LAB_:
            uVar18 = ~(uint)(*(ushort *)((longlong)param_4 + 6) >> 4) & 1;
            goto LAB_;
          }
          if ((uint)*(ushort *)(pbVar22 + uVar18) < (uint)*(ushort *)(param_4 + 1))
          goto LAB_;
          if (-1 < iVar9) goto LAB_;
          uVar25 = *(ushort *)(param_4 + 1) - 1;
          bVar4 = true;
          uVar18 = pbVar22[(ulonglong)(uVar25 >> 3) + (ulonglong)uVar18 + 2] >> ((byte)uVar25 & 7) &
                   1;
LAB_:
          if (uVar18 != 0) {
            uStack_68 = 0;
            puVar23 = (uint *)0x0;
            goto LAB_;
          }
        }
        if ((!bVar4) && ((*(byte *)((longlong)param_4 + 6) & 0x10) != 0)) {
          puVar23 = *(uint **)(param_4 + 2) + 1;
          uStack_68 = **(uint **)(param_4 + 2);
          goto LAB_;
        }
      }
LAB_:
      if ((int)uVar13 < 0) {
        if (*(int *)(param_3 + 2) == 0) {
          pbVar22 = *(byte **)(param_3 + 4);
          uVar13 = *(uint *)(param_3 + 8);
          uVar15 = (ulonglong)uVar13;
          *puVar1 = 0;
          *(uint *)(param_3 + 10) = uVar13;
          bVar5 = *pbVar22;
          if ((bVar5 & 0x10) != 0) {
            uVar13 = uVar13 + 2 + (*(ushort *)(pbVar22 + uVar15) + 7 >> 3);
            uVar15 = (ulonglong)uVar13;
            *(uint *)(param_3 + 10) = uVar13;
            bVar5 = *pbVar22;
          }
          if ((bVar5 & 0x20) == 0) {
            *(int *)(param_3 + 2) = (int)uVar15;
            param_3[0xe] = 0;
            *(int *)(param_3 + 0xc) = (int)uVar15;
          }
          else {
            puVar24 = (ushort *)(pbVar22 + uVar15);
            uVar7 = *puVar24;
            param_3[0xe] = uVar7;
            if (uVar7 == 0) {
              cVar6 = func_0x(0x1e83bc0);
              if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
                 (*(char *)(lVar11 + 0x499) != '\0')) {
                cVar6 = func_0x(0x1e83bc0);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  uStack_98 = (uint *)0x0;
                  (*_DAT_)(1,0x17735cc,0x18936b8,0x80f);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),3);
              uVar15 = (ulonglong)*(uint *)(param_3 + 10);
              uVar7 = param_3[0xe];
            }
            uVar13 = (int)uVar15 + (uVar7 + 1) * 2;
            *(uint *)(param_3 + 0xc) = uVar13;
            if (0x1f9e < uVar13) {
              cVar6 = func_0x(0x1e83bc0);
              if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
                 (*(char *)(lVar11 + 0x499) != '\0')) {
                cVar6 = func_0x(0x1e83bc0);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_98 = (uint *)0x0;
                  (*_DAT_)(1,0x17735cc,0x18936b8,0x816);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),4);
              uVar7 = param_3[0xe];
              uVar13 = *(uint *)(param_3 + 0xc);
            }
            uVar15 = (ulonglong)uVar7;
            uVar7 = puVar24[uVar15];
            *(uint *)(param_3 + 2) = uVar7 & 0x7fff;
            if ((uVar7 & 0x7fff) < uVar13) {
              cVar6 = func_0x(0x1e83bc0);
              if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
                 (*(char *)(lVar11 + 0x499) != '\0')) {
                cVar6 = func_0x(0x1e83bc0);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_98 = (uint *)0x0;
                  (*_DAT_)(1,0x17735cc,0x18936b8,0x81d);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),4);
              uVar13 = *(uint *)(param_3 + 0xc);
              uVar15 = (ulonglong)(ushort)param_3[0xe];
            }
            puVar23 = puVar17;
            puVar3 = puVar24;
            if ((short)uVar15 != 0) {
              do {
                uVar18 = puVar3[1] & 0x7fff;
                if ((uVar18 < uVar13) || (*(uint *)(param_3 + 2) < uVar18)) {
                  cVar6 = func_0x(0x1e83bc0);
                  if ((cVar6 != '\0') &&
                     ((lVar11 = func_0x(), lVar11 != 0 &&
                      (*(char *)(lVar11 + 0x499) != '\0')))) {
                    cVar6 = func_0x(0x1e83bc0);
                    if (cVar6 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      uStack_98 = (uint *)0x0;
                      (*_DAT_)(1,0x17735cc,0x18936b8,0x82a);
                    }
                  }
                  func_0x(*(undefined8 *)(param_3 + 4),4);
                }
                uVar15 = (ulonglong)(ushort)param_3[0xe];
                uVar25 = (int)puVar23 + 1;
                puVar23 = (uint *)(ulonglong)uVar25;
                puVar3 = puVar3 + 1;
                uVar13 = uVar18;
              } while ((int)uVar25 < (int)(uint)(ushort)param_3[0xe]);
            }
            if ((short)puVar24[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
              pbVar22 = *(byte **)(param_3 + 4);
              do {
                uVar13 = *(ushort *)(pbVar22 + uVar15 * 2 + (ulonglong)*(uint *)(param_3 + 10)) &
                         0x7fff;
                if ((int)uVar15 == 1) {
                  uVar18 = *(uint *)(param_3 + 0xc);
                  uVar25 = uVar18;
LAB_:
                  if ((uVar13 < uVar18) || (*(uint *)(param_3 + 2) < uVar13)) goto LAB_;
                }
                else {
                  uVar25 = *(uint *)(param_3 + 0xc);
                  uVar18 = *(ushort *)
                            (pbVar22 + uVar15 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                           0x7fff;
                  if (uVar25 <= uVar18) goto LAB_;
LAB_:
                  func_0x(pbVar22,7);
                  uVar25 = *(uint *)(param_3 + 0xc);
                }
                if ((uVar18 < uVar25) || (*(uint *)(param_3 + 2) < uVar18)) goto LAB_;
                pbVar22 = *(byte **)(param_3 + 4);
                if (*(ushort *)(pbVar22 + uVar18) == 5) {
                  *puVar1 = *puVar1 | 2;
                  param_3[0xe] = param_3[0xe] + -1;
                  uVar20 = (ulonglong)(uVar18 & 0xffff);
                  param_3[0x15] = (short)uVar18;
                  uVar15 = *(ulonglong *)(param_3 + 4);
                  uVar7 = param_3[0x16] & 0xc7ffU;
                  if ((*(ushort *)(uVar20 + 2 + uVar15) >> 0xe & 1) != 0) {
                    uVar7 = *(ushort *)(uVar20 + 2 + uVar15) & 0x3800 | param_3[0x16] & 0xc7ffU;
                  }
                  param_3[0x16] = uVar7;
                  uVar8 = (uVar7 ^ *(ushort *)(uVar20 + 2 + uVar15)) & 0x7ff ^ uVar7;
                  param_3[0x16] = uVar8;
                  uVar19 = (ulonglong)((uVar8 & 0x7ff) * 2) + 4 + uVar15 + (uVar7 >> 0xb & 7) * 2 +
                           uVar20;
                  if (uVar19 < uVar20 + uVar15) {
                    func_0x(uVar20 + uVar15,0x19);
                    uVar8 = param_3[0x16];
                    uVar20 = (ulonglong)(ushort)param_3[0x15];
                    uVar15 = (ulonglong)*(uint *)(param_3 + 4);
                  }
                  if (uVar13 - uVar18 <
                      (((uVar8 & 0x7ff) * 2 - (int)uVar20) - (int)uVar15) + (int)uVar19) {
                    func_0x(uVar20 + *(longlong *)(param_3 + 4),0x19);
                    uVar8 = param_3[0x16];
                  }
                  if (((uVar8 & 0x3800) != 0) &&
                     (puVar24 = (ushort *)
                                (*(longlong *)(param_3 + 4) + 4 + (ulonglong)(ushort)param_3[0x15]),
                     puVar23 = puVar17, (uVar8 & 0x3800) != 0)) {
                    do {
                      if ((uVar8 & 0x7ff) < (*puVar24 & 0x7ff)) {
                        func_0x((ulonglong)(ushort)param_3[0x15] +
                                        *(longlong *)(param_3 + 4),0x1a);
                        uVar8 = param_3[0x16];
                      }
                      uVar13 = (int)puVar23 + 1;
                      puVar24 = puVar24 + 1;
                      puVar23 = (uint *)(ulonglong)uVar13;
                    } while ((int)uVar13 < (int)(uVar8 >> 0xb & 7));
                  }
                  goto LAB_;
                }
                if (*(ushort *)(pbVar22 + uVar18) < 0x400) goto LAB_;
                *puVar1 = *puVar1 | 1;
                uVar7 = param_3[0xe] - 1;
                param_3[0xe] = uVar7;
                if (uVar7 == 0) goto LAB_;
                uVar15 = (ulonglong)uVar7;
              } while ((short)puVar24[(ulonglong)(uVar7 - 1) + 1] < 0);
              uVar15 = (ulonglong)*(uint *)(param_3 + 2);
            }
            else {
LAB_:
              pbVar22 = *(byte **)(param_3 + 4);
              uVar15 = (ulonglong)*(uint *)(param_3 + 2);
            }
          }
          if ((*pbVar22 & 0x40) == 0) {
            *(undefined4 *)(param_3 + 0x13) = 0;
          }
          else {
            *(int *)(param_3 + 0x13) = (int)uVar15;
            *(int *)(param_3 + 2) = (int)uVar15 + 0xe;
            uVar10 = func_0x(puVar1);
            func_0x(uVar10,auStack_50);
            iVar9 = func_0x(auStack_50);
            *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar9;
            uVar15 = (ulonglong)*(uint *)(param_3 + 2);
          }
          iVar9 = (int)uVar15;
          if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
             (*(ulonglong *)(param_3 + 0xf) < uVar15 + *(longlong *)(param_3 + 4))) {
            cVar6 = func_0x(0x1e83bc0);
            if ((cVar6 != '\0') &&
               ((lVar11 = func_0x(), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              cVar6 = func_0x(0x1e83bc0);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                uStack_98 = (uint *)0x0;
                (*_DAT_)(1,0x17735cc,0x18936b8,0x886);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),0x12);
            iVar9 = *(int *)(param_3 + 2);
          }
          if (0x3f3b < iVar9 - 1U) {
            cVar6 = func_0x(0x1e83bc0);
            if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
               (*(char *)(lVar11 + 0x499) != '\0')) {
              cVar6 = func_0x(0x1e83bc0);
              if (cVar6 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                uStack_98 = (uint *)0x0;
                (*_DAT_)(1,0x17735cc,0x18936b8,0x88b);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),5);
          }
        }
LAB_:
        sVar21 = -*(short *)param_4;
        if ((*(byte *)((longlong)param_4 + 6) & 0x10) != 0) {
          bVar5 = **(byte **)(param_3 + 4);
          if ((bVar5 & 0x10) == 0) {
            if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
              puVar23 = *(uint **)(param_4 + 2) + 1;
              psVar26 = psStack_60;
              uStack_68 = **(uint **)(param_4 + 2);
              goto LAB_;
            }
          }
          else if (((int)*(uint *)(param_3 + 8) <= (int)*param_4) ||
                  (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                   *(ushort *)(param_4 + 1))) goto LAB_;
        }
        puVar23 = *(uint **)(param_3 + 4);
        lVar11 = (longlong)sVar21;
        psVar26 = psStack_60;
        uStack_68 = 0;
        if ((uint)(int)sVar21 <= (uint)(ushort)param_3[0xe]) {
          uVar13 = *(uint *)(param_3 + 10);
          if (sVar21 == 1) {
            uVar18 = *(uint *)(param_3 + 0xc);
            uVar13 = *(ushort *)((longlong)puVar23 + lVar11 * 2 + (ulonglong)uVar13) & 0x7fff;
LAB_:
            if ((uVar13 < uVar18) || (*(uint *)(param_3 + 2) < uVar13)) goto LAB_;
          }
          else {
            puVar24 = (ushort *)((longlong)puVar23 + lVar11 * 2 + (ulonglong)uVar13);
            uVar18 = *(ushort *)((longlong)puVar23 + lVar11 * 2 + ((ulonglong)uVar13 - 2)) & 0x7fff;
            puVar23 = *(uint **)(param_3 + 4);
            uVar13 = *puVar24 & 0x7fff;
            if (*(uint *)(param_3 + 0xc) <= uVar18) goto LAB_;
LAB_:
            func_0x(puVar23,7);
            puVar23 = *(uint **)(param_3 + 4);
          }
          puVar23 = (uint *)((longlong)puVar23 + (ulonglong)uVar18);
          psVar26 = psStack_60;
          uStack_68 = uVar13 - uVar18;
        }
      }
      else {
        uVar7 = *(ushort *)((longlong)param_4 + 6);
        if ((uVar7 & 8) == 0) {
          if ((uVar7 & 0x10) != 0) {
            bVar5 = **(byte **)(param_3 + 4);
            if ((bVar5 & 0x10) == 0) {
              if ((1 << (bVar5 & 0xe) & 0x1105U) != 0) {
LAB_:
                uStack_68 = **(uint **)(param_4 + 2);
                puVar23 = *(uint **)(param_4 + 2) + 1;
                if (uStack_68 != 0x10) {
                  uStack_98 = (uint *)0x0;
                  (*_DAT_)(1,0x1921a10,0x1920378,0x381);
                }
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_3 + 8) <= (int)uVar13) ||
                    (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) <
                     *(ushort *)(param_4 + 1))) goto LAB_;
          }
          uStack_68 = 0x10;
          puVar23 = (uint *)((longlong)(int)uVar13 + *(longlong *)(param_3 + 4));
        }
        else {
          puVar23 = (uint *)0x14f8260;
          uStack_68 = 1;
          if ((*(byte *)((longlong)(int)uVar13 + *(longlong *)(param_3 + 4)) &
              (byte)(1 << ((byte)uVar7 & 7))) == 0) {
            puVar23 = (uint *)0x14f8261;
          }
        }
      }
    }
  }
  else {
    uStack_98 = &uStack_64;
    uStack_64 = 0;
    puVar23 = (uint *)func_0x(puVar1,param_4,iVar9 >> 0x1f,&uStack_68);
    if (((*param_3 != 0) && (plVar2 = *(longlong **)(param_3 + 8), plVar2 != (longlong *)0x0)) &&
       ((*plVar2 != 0 && (((*(byte *)((longlong)param_4 + 6) & 8) == 0 && ((uStack_64 & 1) == 0)))))
       ) {
      if ((puVar23 == (uint *)0x0) || (puVar23 == (uint *)0x14f8260)) {
        uStack_68 = 0;
        puVar23 = puVar17;
      }
      else {
        uStack_80 = uStack_64;
        uStack_90 = 0x10;
        uStack_98 = auStack_78;
        puStack_88 = &uStack_68;
        puVar23 = (uint *)func_0x(plVar2,param_4,puVar23,uStack_68);
      }
    }
  }
LAB_:
  uVar13 = *(uint *)(param_3 + 2);
  if (*psVar26 == 0) {
    if (uVar13 == 0) {
      pbVar22 = *(byte **)(param_3 + 4);
      uVar13 = *(uint *)(param_3 + 8);
      uVar15 = (ulonglong)uVar13;
      *puVar1 = 0;
      *(uint *)(param_3 + 10) = uVar13;
      bVar5 = *pbVar22;
      if ((bVar5 & 0x10) != 0) {
        uVar13 = uVar13 + 2 + (*(ushort *)(pbVar22 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar13;
        *(uint *)(param_3 + 10) = uVar13;
        bVar5 = *pbVar22;
      }
      if ((bVar5 & 0x20) == 0) {
        *(int *)(param_3 + 2) = (int)uVar15;
        param_3[0xe] = 0;
        *(int *)(param_3 + 0xc) = (int)uVar15;
      }
      else {
        puVar24 = (ushort *)(pbVar22 + uVar15);
        uVar7 = *puVar24;
        param_3[0xe] = uVar7;
        if (uVar7 == 0) {
          cVar6 = func_0x(0x1e83bc0);
          if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
             (*(char *)(lVar11 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1e83bc0);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              uStack_98 = (uint *)0x0;
              (*_DAT_)(1,0x17735cc,0x18936b8,0x80f);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),3);
          uVar15 = (ulonglong)*(uint *)(param_3 + 10);
          uVar7 = param_3[0xe];
        }
        uVar13 = (int)uVar15 + (uVar7 + 1) * 2;
        *(uint *)(param_3 + 0xc) = uVar13;
        if (0x1f9e < uVar13) {
          cVar6 = func_0x(0x1e83bc0);
          if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
             (*(char *)(lVar11 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1e83bc0);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_98 = (uint *)0x0;
              (*_DAT_)(1,0x17735cc,0x18936b8,0x816);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),4);
          uVar7 = param_3[0xe];
          uVar13 = *(uint *)(param_3 + 0xc);
        }
        uVar15 = (ulonglong)uVar7;
        uVar7 = puVar24[uVar15];
        *(uint *)(param_3 + 2) = uVar7 & 0x7fff;
        if ((uVar7 & 0x7fff) < uVar13) {
          cVar6 = func_0x(0x1e83bc0);
          if (((cVar6 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
             (*(char *)(lVar11 + 0x499) != '\0')) {
            cVar6 = func_0x(0x1e83bc0);
            if (cVar6 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              uStack_98 = (uint *)0x0;
              (*_DAT_)(1,0x17735cc,0x18936b8,0x81d);
            }
          }
          func_0x(*(undefined8 *)(param_3 + 4),4);
          uVar13 = *(uint *)(param_3 + 0xc);
          uVar15 = (ulonglong)(ushort)param_3[0xe];
        }
        puVar27 = puVar17;
        puVar3 = puVar24;
        if ((short)uVar15 != 0) {
          do {
            uVar18 = puVar3[1] & 0x7fff;
            if ((uVar18 < uVar13) || (*(uint *)(param_3 + 2) < uVar18)) {
              cVar6 = func_0x(0x1e83bc0);
              if ((cVar6 != '\0') &&
                 ((lVar11 = func_0x(), lVar11 != 0 &&
                  (*(char *)(lVar11 + 0x499) != '\0')))) {
                cVar6 = func_0x(0x1e83bc0);
                if (cVar6 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  uStack_98 = (uint *)0x0;
                  (*_DAT_)(1,0x17735cc,0x18936b8,0x82a);
                }
              }
              func_0x(*(undefined8 *)(param_3 + 4),4);
            }
            uVar15 = (ulonglong)(ushort)param_3[0xe];
            uVar25 = (int)puVar27 + 1;
            puVar27 = (uint *)(ulonglong)uVar25;
            puVar3 = puVar3 + 1;
            uVar13 = uVar18;
          } while ((int)uVar25 < (int)(uint)(ushort)param_3[0xe]);
        }
        if ((short)puVar24[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          pbVar22 = *(byte **)(param_3 + 4);
          do {
            uVar18 = *(ushort *)(pbVar22 + uVar15 * 2 + (ulonglong)*(uint *)(param_3 + 10)) & 0x7fff
            ;
            if ((int)uVar15 == 1) {
              uVar25 = *(uint *)(param_3 + 0xc);
              uVar14 = uVar25;
LAB_:
              if ((uVar18 < uVar25) || (uVar13 = *(uint *)(param_3 + 2), uVar13 < uVar18))
              goto LAB_;
            }
            else {
              uVar14 = *(uint *)(param_3 + 0xc);
              uVar25 = *(ushort *)(pbVar22 + uVar15 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2))
                       & 0x7fff;
              if (uVar14 <= uVar25) goto LAB_;
LAB_:
              func_0x(pbVar22,7);
              uVar14 = *(uint *)(param_3 + 0xc);
              uVar13 = *(uint *)(param_3 + 2);
            }
            if ((uVar25 < uVar14) || (uVar13 < uVar25)) goto LAB_;
            pbVar22 = *(byte **)(param_3 + 4);
            if (*(ushort *)(pbVar22 + uVar25) == 5) {
              *puVar1 = *puVar1 | 2;
              param_3[0xe] = param_3[0xe] + -1;
              uVar15 = *(ulonglong *)(param_3 + 4);
              uVar20 = (ulonglong)(uVar25 & 0xffff);
              param_3[0x15] = (short)uVar25;
              uVar7 = param_3[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar20 + 2 + uVar15) >> 0xe & 1) != 0) {
                uVar7 = *(ushort *)(uVar20 + 2 + uVar15) & 0x3800 | param_3[0x16] & 0xc7ffU;
              }
              param_3[0x16] = uVar7;
              uVar19 = (ulonglong)(ushort)param_3[0x15];
              uVar8 = (uVar7 ^ *(ushort *)(uVar20 + 2 + uVar15)) & 0x7ff ^ uVar7;
              param_3[0x16] = uVar8;
              uVar20 = uVar19 + 4 +
                       (ulonglong)((uVar8 & 0x7ff) * 2) + uVar15 + (uVar7 >> 0xb & 7) * 2;
              if (uVar20 < uVar19 + uVar15) {
                func_0x(uVar19 + uVar15,0x19);
                uVar8 = param_3[0x16];
                uVar19 = (ulonglong)(ushort)param_3[0x15];
                uVar15 = (ulonglong)*(uint *)(param_3 + 4);
              }
              if (uVar18 - uVar25 <
                  (((uVar8 & 0x7ff) * 2 - (int)uVar19) - (int)uVar15) + (int)uVar20) {
                func_0x(uVar19 + *(longlong *)(param_3 + 4),0x19);
                uVar8 = param_3[0x16];
              }
              if (((uVar8 & 0x3800) != 0) &&
                 (puVar24 = (ushort *)
                            (*(longlong *)(param_3 + 4) + 4 + (ulonglong)(ushort)param_3[0x15]),
                 (uVar8 & 0x3800) != 0)) {
                do {
                  if ((uVar8 & 0x7ff) < (*puVar24 & 0x7ff)) {
                    func_0x((ulonglong)(ushort)param_3[0x15] + *(longlong *)(param_3 + 4),
                                    0x1a);
                    uVar8 = param_3[0x16];
                  }
                  uVar13 = (int)puVar17 + 1;
                  puVar17 = (uint *)(ulonglong)uVar13;
                  puVar24 = puVar24 + 1;
                } while ((int)uVar13 < (int)(uVar8 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar22 + uVar25) < 0x400) goto LAB_;
            *puVar1 = *puVar1 | 1;
            uVar7 = param_3[0xe] - 1;
            param_3[0xe] = uVar7;
            if (uVar7 == 0) goto LAB_;
            uVar15 = (ulonglong)uVar7;
          } while ((short)puVar24[(ulonglong)(uVar7 - 1) + 1] < 0);
          uVar15 = (ulonglong)*(uint *)(param_3 + 2);
        }
        else {
LAB_:
          pbVar22 = *(byte **)(param_3 + 4);
          uVar15 = (ulonglong)*(uint *)(param_3 + 2);
        }
      }
      if ((*pbVar22 & 0x40) == 0) {
        *(undefined4 *)(param_3 + 0x13) = 0;
      }
      else {
        *(int *)(param_3 + 0x13) = (int)uVar15;
        *(int *)(param_3 + 2) = (int)uVar15 + 0xe;
        puVar12 = (undefined8 *)func_0x(puVar1);
        uStack_48 = *puVar12;
        iVar9 = func_0x(&uStack_48);
        *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar9;
        uVar15 = (ulonglong)*(uint *)(param_3 + 2);
      }
      uVar13 = (uint)uVar15;
      if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
         (*(ulonglong *)(param_3 + 0xf) < uVar15 + *(longlong *)(param_3 + 4))) {
        cVar6 = func_0x(0x1e83bc0);
        if ((cVar6 != '\0') &&
           ((lVar11 = func_0x(), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))
           )) {
          cVar6 = func_0x(0x1e83bc0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            uStack_98 = (uint *)0x0;
            (*_DAT_)(1,0x17735cc,0x18936b8,0x886);
          }
        }
        func_0x(*(undefined8 *)(param_3 + 4),0x12);
        uVar13 = *(uint *)(param_3 + 2);
      }
      if ((uVar13 == 0) || (0x3f3c < uVar13)) {
        cVar6 = func_0x(0x1e83bc0);
        if ((cVar6 != '\0') &&
           ((lVar11 = func_0x(), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))
           )) {
          cVar6 = func_0x(0x1e83bc0);
          if (cVar6 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            uStack_98 = (uint *)0x0;
            (*_DAT_)(1,0x17735cc,0x18936b8,0x88b);
          }
        }
        func_0x(*(undefined8 *)(param_3 + 4),5);
        uVar13 = *(uint *)(param_3 + 2);
      }
    }
LAB_:
    psVar26 = psStack_60;
    if ((uVar13 < 9) &&
       (((**(byte **)(param_3 + 4) & 0xe) == 0 || ((**(byte **)(param_3 + 4) & 0xe) == 0xc)))) {
      uVar13 = 9;
    }
  }
  else {
    if (uVar13 == 0) {
      func_0x(puVar1);
      uVar13 = *(uint *)(param_3 + 2);
    }
    if ((uVar13 < 9) &&
       (((**(byte **)(param_3 + 4) & 0x1c) == 0 || ((**(byte **)(param_3 + 4) & 0x1c) == 0xc)))) {
      uVar13 = 9;
    }
  }
  uStack_98 = (uint *)CONCAT44(uStack_98._4_4_,uVar13);
  (**(code **)(*plStack_40 + 200))
            (plStack_40,(longlong)*(int *)(lStack_38 + 0x14),puVar23,*(undefined8 *)(psVar26 + 4));
LAB_:
  *(undefined8 *)(puVar16 + -8) = 0x101185;
  func_0x(uStack_30 ^ (ulonglong)&uStack_68);
  return;
}

