
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong **param_2,longlong param_3,uint *param_4,
                 longlong param_5)

{
  longlong **pplVar1;
  ulonglong *puVar2;
  ulonglong uVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  char cVar7;
  int iVar8;
  longlong lVar9;
  short sVar10;
  longlong unaff_GS_OFFSET;
  
  iVar4 = *(int *)(param_3 + 0x6b8);
  pplVar1 = (longlong **)
            (*param_1 +
            (param_1[1] &
            (ulonglong)((uint)*(ushort *)(param_4 + 1) + iVar4 * 0x100) * param_1[2] +
            (ulonglong)*param_4) * 8);
  puVar2 = (ulonglong *)
           (param_1 + (ulonglong)((uint)((longlong)pplVar1 - *param_1 >> 3) & 0x3ff) + 0xfb0);
  if ((*(byte *)(*(longlong *)(param_3 + 0x6b0) + 0x3a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((*(uint *)(*(longlong *)(param_3 + 0x6b0) + 0x278) & 0x2000) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*param_2 != (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)puVar2 == 0) {
    LOCK();
    uVar3 = *puVar2;
    if (uVar3 == 0) {
      *puVar2 = (ulonglong)*(uint *)(unaff_GS_OFFSET + 0x48);
    }
    UNLOCK();
    if (uVar3 == 0) {
      if (*pplVar1 != (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar5 = *param_2;
      if (plVar5 == (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      LOCK();
      *(uint *)((longlong)plVar5 + 100) = *(uint *)((longlong)plVar5 + 100) | 9;
      UNLOCK();
      if (*pplVar1 != (longlong *)0x0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar5[0xd] = 0;
      *pplVar1 = plVar5;
      if (*_DAT_ != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *puVar2 = 0;
      LOCK();
      param_1[(ulonglong)
              *(byte *)(((ulonglong)*(ushort *)((longlong)plVar5 + 0x76) <<
                        (*(byte *)((longlong)param_1 + 0x6c) & 0x3f)) + 0x18 + param_1[0xc]) * 0x80
              + 0x13de] =
           param_1[(ulonglong)
                   *(byte *)(((ulonglong)*(ushort *)((longlong)plVar5 + 0x76) <<
                             (*(byte *)((longlong)param_1 + 0x6c) & 0x3f)) + 0x18 + param_1[0xc]) *
                   0x80 + 0x13de] + 1;
      UNLOCK();
      lVar9 = *(longlong *)(param_3 + 0x6b0);
      if ((*(byte *)(lVar9 + 0x3a) & 0x10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      if (((*(uint *)(lVar9 + 0x278) & 0x2000) != 0) || (*(longlong *)(lVar9 + 0x280) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      plVar6 = *param_2;
      LOCK();
      *(ushort *)((longlong)plVar6 + 0x62) = *(ushort *)((longlong)plVar6 + 0x62) & 0xfffe;
      UNLOCK();
      LOCK();
      *(ushort *)((longlong)plVar6 + 0x62) = *(ushort *)((longlong)plVar6 + 0x62) & 0xfffd;
      UNLOCK();
      LOCK();
      *(ushort *)((longlong)plVar6 + 0x62) = *(ushort *)((longlong)plVar6 + 0x62) & 0xfffb;
      UNLOCK();
      LOCK();
      *(ushort *)((longlong)plVar6 + 0x62) = *(ushort *)((longlong)plVar6 + 0x62) & 0xfeff;
      UNLOCK();
      if (plVar6[9] != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(ushort *)(*plVar5 + 4) = *(ushort *)(*plVar5 + 4) & 0xfdff;
      lVar9 = func_0x(_DAT_,*param_2,1,1);
      *(ushort *)(lVar9 + 4) = *(ushort *)(lVar9 + 4) & 0xedff;
      *(undefined4 *)(lVar9 + 0x40) = 1;
      *(undefined4 *)((longlong)plVar5 + 0x5c) = 0;
      if ((*(uint *)(plVar5 + 0xe) == *param_4) &&
         (*(short *)((longlong)plVar5 + 0x74) == *(short *)(param_4 + 1))) {
        cVar7 = func_0x(param_3,plVar5);
        if (cVar7 != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        LOCK();
        *(ushort *)((longlong)plVar5 + 0x62) = *(ushort *)((longlong)plVar5 + 0x62) & 0xfff7;
        UNLOCK();
        LOCK();
        *(ushort *)((longlong)plVar5 + 0x62) = *(ushort *)((longlong)plVar5 + 0x62) & 0xfeff;
        UNLOCK();
        if ((param_5 == 0) &&
           ((iVar8 = (*(int *)((longlong)param_1 + 0x24) << 0x19) >> 0x1d, iVar8 == 2 ||
            (((iVar8 == 1 && (sVar10 = (short)iVar4, sVar10 != 2)) && (sVar10 != 0)))))) {
          func_0x(*plVar5,0x21,0x2000);
        }
        func_0x(param_1,plVar5);
        if ((DAT_ & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        lVar9 = *(longlong *)
                 ((ulonglong)*_DAT_ +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
        if ((lVar9 != 0) && (**(longlong **)(lVar9 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        (*param_2)[6] = (*param_2)[6] * 0x10 + 0xc;
        return;
      }
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

