
/* WARNING: Removing unreachable block (ram,0x00100e12) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,undefined8 param_2,ulonglong param_3,short *param_4)

{
  ushort *puVar1;
  uint *puVar2;
  uint *puVar3;
  undefined2 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined2 *puVar7;
  ushort *puVar8;
  undefined4 uVar9;
  byte bVar10;
  char cVar11;
  ushort uVar12;
  longlong lVar13;
  longlong lVar14;
  undefined8 uVar15;
  ulonglong uVar16;
  longlong lVar17;
  undefined8 *puVar18;
  byte bVar19;
  uint uVar20;
  ulonglong uVar21;
  code *UNRECOVERED_JUMPTABLE;
  longlong *plVar22;
  longlong *plVar23;
  byte *pbVar24;
  uint uVar25;
  uint uVar26;
  ushort *puVar27;
  uint uVar28;
  int iVar29;
  longlong *plVar30;
  undefined *puVar31;
  ushort uVar32;
  uint uVar33;
  short sVar34;
  ushort uVar35;
  ulonglong uVar36;
  int iVar37;
  ulonglong uVar38;
  longlong *plVar39;
  ushort *puVar40;
  longlong lVar41;
  undefined8 uStackX_8;
  undefined2 auStackX_10 [2];
  uint auStackX_14 [3];
  ushort uStackX_20;
  ushort auStackX_22 [3];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  puVar2 = (uint *)((longlong)&uStackX_20 + lVar13 + -0x20);
  *(undefined8 *)(&stack0x00000090 + lVar13) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002aa0 + lVar13) = _DAT_ ^ (ulonglong)puVar2;
  uVar21 = param_3 & 0xffffffff;
  *(int *)((longlong)auStackX_14 + lVar13 + 4) = (int)param_3;
  *(undefined8 *)((longlong)&uStackX_8 + lVar13) = param_2;
  *(short **)(&stack0x00000070 + lVar13) = param_1;
  puVar27 = (ushort *)(param_4 + 1);
  if ((((**(byte **)(param_4 + 4) & 0x1c) - 4 & 0xffffffeb) != 0) ||
     ((**(byte **)(param_4 + 4) & 0x1c) == 0x18)) {
    plVar30 = (longlong *)0x0;
    *(undefined4 *)(&stack0x00000038 + lVar13) = 0;
    *(undefined **)(&stack0x00000068 + lVar13) = &stack0x00000b00 + lVar13;
    uVar35 = *puVar27;
    uVar25 = (uint)uVar35;
    *(uint *)(&stack0x00000048 + lVar13) = (uint)uVar35;
    *(ushort *)(&stack0x0000002e + lVar13) = *(ushort *)(&stack0x0000002e + lVar13) & 0xffe0;
    *(undefined (*) [16])(&stack0x000000a0 + lVar13) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000000b0 + lVar13) = ZEXT816(0);
    *(undefined8 *)(&stack0x000000c0 + lVar13) = 0;
    *(undefined8 *)(&stack0x000000c8 + lVar13) = 0;
    *(undefined8 *)(&stack0x000000d0 + lVar13) = 0;
    *(undefined4 *)(&stack0x00000af8 + lVar13) = 0;
    *(undefined4 *)(&stack0x0000004c + lVar13) = 0;
    *(undefined8 *)(param_1 + 8) = 0;
    uVar16 = (ulonglong)(uint)uVar35 * 0x20;
    uVar21 = uVar16 + 0xf;
    if (uVar21 <= uVar16) {
      uVar21 = 0xffffffffffffff0;
    }
    uVar21 = uVar21 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100a58;
    func_0x();
    lVar14 = -uVar21;
    *(longlong *)(&stack0x00000058 + lVar13) = (longlong)&uStackX_20 + lVar14 + lVar13 + -0x20;
    *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100a75;
    func_0x((longlong)&uStackX_20 + lVar14 + lVar13 + -0x20,0,uVar25 << 5);
    uVar35 = 0;
    *(undefined2 *)((longlong)auStackX_10 + lVar13) = 0;
    *(ulonglong *)(&stack0x00000050 + lVar13) =
         (ulonglong)(ushort)param_4[0xe] + (ulonglong)(ushort)param_4[0xd] +
         *(longlong *)(param_4 + 4);
    plVar23 = plVar30;
    if (*param_4 != 0) {
      plVar23 = *(longlong **)(param_4 + 8);
    }
    *(longlong **)(&stack0x00000080 + lVar13) = plVar23;
    puVar18 = (undefined8 *)plVar23[1];
    if (puVar18 == (undefined8 *)0x0) {
      plVar23[1] = (longlong)(&stack0x000000a0 + lVar13);
      puVar18 = (undefined8 *)(&stack0x000000a0 + lVar13);
      if (*plVar23 != 0) {
        *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100ada;
        func_0x(&stack0x000000a0 + lVar13,plVar23);
        puVar18 = (undefined8 *)plVar23[1];
      }
      *(undefined4 *)(&stack0x0000004c + lVar13) = 1;
    }
    if (((**(byte **)*puVar18 & 2) != 0) && (*(int *)((longlong)puVar18 + 0x24) == 0)) {
      lVar17 = puVar18[3];
      if (*(short *)(lVar17 + 0x10) == -1) {
        *(undefined2 *)(lVar17 + 0x10) = 1;
      }
      uVar4 = *(undefined2 *)(puVar18 + 4);
      uVar15 = puVar18[5];
      *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100b15;
      func_0x(lVar17 + 0x12,uVar15,uVar4);
      uVar12 = *(ushort *)(puVar18 + 4);
      uVar15 = puVar18[6];
      *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100b2f;
      func_0x(uVar15,0xff,(uVar12 >> 3) + 1);
    }
    puVar7 = *(undefined2 **)(&stack0x00000070 + lVar13);
    *puVar7 = 1;
    *(undefined8 *)(puVar7 + 8) = 0;
    *(undefined4 *)(&stack0xffffffffffffffe0 + lVar14 + lVar13) =
         *(undefined4 *)(&stack0x00000048 + lVar13);
    uVar15 = *(undefined8 *)((longlong)&uStackX_8 + lVar13);
    *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100b52;
    func_0x(puVar7 + 1,uVar15);
    if (*(int *)(param_4 + 2) == 0) {
      *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100b61;
      func_0x(puVar27);
    }
    *(ushort *)((longlong)&uStackX_20 + lVar13) = *puVar27;
    *(undefined2 *)((longlong)&uStackX_20 + lVar13 + 2) = 0;
    *(undefined4 *)(&stack0x00000028 + lVar13) = 0;
    *(undefined2 *)(&stack0x0000002c + lVar13) = 0;
    *(ushort *)(&stack0x0000002e + lVar13) = *(ushort *)(&stack0x0000002e + lVar13) & 0xffe0;
    *(undefined8 *)(&stack0x00000030 + lVar13) = 0;
    plVar23 = plVar30;
    uVar12 = uVar35;
LAB_:
    lVar17 = *(longlong *)(&stack0x00000058 + lVar13);
    do {
      if (uVar12 == *(ushort *)((longlong)&uStackX_20 + lVar13)) {
        *(undefined **)(&stack0xffffffffffffffe8 + lVar14 + lVar13) = &stack0x00000088 + lVar13;
        *(longlong *)(&stack0xffffffffffffffe0 + lVar14 + lVar13) = lVar17;
        uVar5 = *(undefined4 *)(&stack0x00000048 + lVar13);
        uVar6 = *(undefined4 *)((longlong)auStackX_14 + lVar13 + 4);
        lVar17 = *(longlong *)(&stack0x00000070 + lVar13);
        lVar41 = lVar17 + 2;
        *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100e85;
        func_0x(lVar41,uVar6,uVar6,uVar5);
        uVar25 = (uint)**(byte **)(param_4 + 4);
        if (((uVar25 & 0x1c) - 0x10 & 0xfffffffb) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100ea3;
          uVar15 = func_0x(puVar27);
          *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100eae;
          func_0x(lVar41,uVar15);
          uVar25 = (uint)**(byte **)(param_4 + 4);
        }
        if ((uVar25 & 2) != 0) {
          if (*(int *)(param_4 + 2) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100ecd;
            func_0x(puVar27);
          }
          *(undefined8 *)((longlong)&uStackX_8 + lVar13) = 0;
          uVar12 = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100ee0;
          func_0x(puVar27);
          if (((**(byte **)(param_4 + 4) & 2) != 0) &&
             (puVar18 = (undefined8 *)(*(byte **)(param_4 + 4) + *(uint *)(param_4 + 0x18)),
             puVar18 != (undefined8 *)0x0)) {
            uVar15 = *puVar18;
            *(int *)((longlong)&uStackX_8 + lVar13) = (int)uVar15;
            uVar35 = (ushort)((ulonglong)uVar15 >> 0x20);
            *(ushort *)((longlong)auStackX_10 + lVar13 + -4) = uVar35;
            uVar12 = (ushort)((ulonglong)uVar15 >> 0x30);
            *(ushort *)((longlong)auStackX_10 + lVar13 + -2) = uVar12;
          }
          if (*(int *)(param_4 + 2) == 0) {
            *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100f1b;
            func_0x(puVar27);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100f23;
          func_0x(puVar27);
          if (((**(byte **)(param_4 + 4) & 2) == 0) ||
             (pbVar24 = *(byte **)(param_4 + 4) + *(uint *)(param_4 + 0x18), pbVar24 == (byte *)0x0)
             ) {
            *(undefined4 *)(&stack0x0000003c + lVar13) = 0;
            *(undefined2 *)(&stack0x00000040 + lVar13) = 0;
          }
          else {
            *(undefined4 *)(&stack0x0000003c + lVar13) = *(undefined4 *)(pbVar24 + 8);
            *(undefined2 *)(&stack0x00000040 + lVar13) = *(undefined2 *)(pbVar24 + 0xc);
          }
          *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100f58;
          func_0x(lVar41,&stack0x0000003c + lVar13);
          uVar32 = uVar12;
          if ((((uint)(int)(short)uVar12 >> 1 ^ (int)(short)uVar12) & 0x2000) != 0) {
            uVar32 = uVar12 & 0xdfff;
            if ((uVar12 >> 0xe & 1) != 0) {
              uVar32 = uVar12 | 0x2000;
            }
          }
          if ((uVar32 == 0xfffc) && (0x1f < uVar35)) {
            pbVar24 = *(byte **)(param_4 + 4);
            if ((*pbVar24 & 2) != 0) {
              if (*(int *)(param_4 + 2) == 0) {
                *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100fb5;
                func_0x(puVar27);
                pbVar24 = *(byte **)(param_4 + 4);
              }
              plVar30 = (longlong *)(pbVar24 + (ulonglong)*(uint *)(param_4 + 0x18) + 0xe);
            }
            if (*(int *)(lVar17 + 4) == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100fd8;
              func_0x(lVar41);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100fe0;
            func_0x(lVar41);
            pbVar24 = *(byte **)(lVar17 + 8);
            if ((*pbVar24 & 2) == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x10100d;
              func_0x(0,(longlong)&uStackX_8 + lVar13,plVar30);
            }
            else {
              uVar25 = *(uint *)(lVar17 + 0x30);
              *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100ffc;
              func_0x(pbVar24 + uVar25,(longlong)&uStackX_8 + lVar13,plVar30);
            }
          }
          else {
            if (*(int *)(lVar17 + 4) == 0) {
              *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x10101e;
              func_0x(lVar41);
            }
            *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x101026;
            func_0x(lVar41);
            if ((**(byte **)(lVar17 + 8) & 2) != 0) {
              plVar30 = (longlong *)(*(byte **)(lVar17 + 8) + *(uint *)(lVar17 + 0x30));
            }
            *plVar30 = *(longlong *)((longlong)&uStackX_8 + lVar13);
          }
          *(undefined4 *)(lVar17 + 4) = 0;
          *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x10104e;
          func_0x(lVar41);
        }
        if (((**(byte **)(param_4 + 4) & 0x1c) - 4 & 0xffffffe7) == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x10106b;
          func_0x(lVar41);
        }
        if (*(int *)(&stack0x0000004c + lVar13) != 0) {
          *(undefined8 *)(*(longlong *)(&stack0x00000080 + lVar13) + 8) = 0;
        }
        puVar31 = &stack0xffffffffffffffc0 + lVar14 + lVar13;
        if (*(short *)(&stack0x000000c2 + lVar13) != 0) {
          uVar15 = *(undefined8 *)(&stack0x000000c8 + lVar13);
          *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x101093;
          (*_DAT_)(uVar15);
          uVar15 = *(undefined8 *)(&stack0x000000d0 + lVar13);
          *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x1010a0;
          (*_DAT_)(uVar15);
          puVar31 = &stack0xffffffffffffffc0 + lVar14 + lVar13;
        }
        goto LAB_;
      }
      uVar32 = uVar12 + 1;
      *(ushort *)((longlong)&uStackX_20 + lVar13 + 2) = uVar32;
      *(ushort *)(&stack0x0000002c + lVar13) = uVar32;
      *(int *)(&stack0x00000028 + lVar13) = (int)(short)(*(short *)(&stack0x00000028 + lVar13) + -1)
      ;
      *(undefined4 *)(&stack0x00000044 + lVar13) = 0;
      plVar39 = plVar30;
      if (*puVar27 < uVar32) {
        if (((&stack0x0000002e)[lVar13] & 0x10) == 0) {
          *puVar2 = 0;
          plVar23 = plVar30;
        }
        else {
          uVar25 = *(uint *)plVar23;
          *puVar2 = uVar25;
          plVar39 = (longlong *)((longlong)plVar23 + 4);
          plVar23 = (longlong *)(ulonglong)uVar25;
        }
      }
      else {
        bVar10 = *(byte *)((longlong)
                           ((int)(*(ushort *)((longlong)&uStackX_20 + lVar13 + 2) - 1) / 2) +
                           (ulonglong)(ushort)param_4[0xc] + *(longlong *)(param_4 + 4));
        bVar19 = bVar10 >> 4;
        if ((*(byte *)((longlong)&uStackX_20 + lVar13 + 2) & 1) != 0) {
          bVar19 = bVar10 & 0xf;
        }
        if (bVar19 < 0xe) {
          UNRECOVERED_JUMPTABLE =
               (code *)((ulonglong)*(uint *)((longlong)(int)(uint)bVar19 * 4 + 0x1010c4) - 0x1da77d0
                       );
                    /* WARNING: Could not emulate address calculation at 0x00100c38 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
          return;
        }
        plVar23 = (longlong *)0x0;
        *puVar2 = 0;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar14 + lVar13) = 0x772d60;
        *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100d5d;
        (*_DAT_)(1,0xb790f0,0xb7f510,0x11f9);
        uVar12 = *(short *)(&stack0x0000002c + lVar13) - 1;
      }
      plVar22 = plVar30;
      if (*param_4 != 0) {
        plVar22 = *(longlong **)(param_4 + 8);
      }
      if ((plVar39 == (longlong *)0x0) || (plVar39 == (longlong *)0x77c490)) {
        *(undefined4 *)((longlong)auStackX_14 + lVar13) = 0;
      }
      else {
        iVar29 = *(int *)(&stack0x00000038 + lVar13);
        *(undefined4 *)(&stack0xfffffffffffffff8 + lVar14 + lVar13) = 0;
        *(longlong *)(&stack0xfffffffffffffff0 + lVar14 + lVar13) = (longlong)auStackX_14 + lVar13;
        *(int *)(&stack0xffffffffffffffe8 + lVar14 + lVar13) = 0x1f9e - iVar29;
        *(undefined8 *)(&stack0xffffffffffffffe0 + lVar14 + lVar13) =
             *(undefined8 *)(&stack0x00000068 + lVar13);
        *(undefined8 *)((longlong)&uStack_48 + lVar14 + lVar13) = 0x100dc6;
        lVar17 = func_0x(plVar22,&stack0x00000028 + lVar13,plVar39,plVar23);
        if (lVar17 != 0) goto code_r0x00100dce;
      }
      lVar17 = *(longlong *)(&stack0x00000058 + lVar13);
      puVar3 = (uint *)((ulonglong)uVar12 * 0x20 + 0xc + lVar17);
      *puVar3 = *puVar3 | 2;
      plVar23 = *(longlong **)(&stack0x00000030 + lVar13);
      uVar12 = *(ushort *)((longlong)&uStackX_20 + lVar13 + 2);
    } while( true );
  }
  sVar34 = *param_4;
  *param_1 = sVar34;
  puVar1 = (ushort *)(param_1 + 1);
  iVar29 = 0;
  if (sVar34 == 0) {
    uVar25 = *(uint *)(param_4 + 2);
    uVar28 = 0;
    if (uVar25 == 0) {
      *puVar27 = 0;
      uVar25 = *(uint *)(param_4 + 8);
      uVar21 = (ulonglong)uVar25;
      *(uint *)(param_4 + 10) = uVar25;
      pbVar24 = *(byte **)(param_4 + 4);
      bVar10 = *pbVar24;
      if ((bVar10 & 0x10) != 0) {
        uVar25 = uVar25 + 2 + (*(ushort *)(pbVar24 + uVar21) + 7 >> 3);
        uVar21 = (ulonglong)uVar25;
        *(uint *)(param_4 + 10) = uVar25;
        bVar10 = *pbVar24;
      }
      if ((bVar10 & 0x20) == 0) {
        *(int *)(param_4 + 2) = (int)uVar21;
        param_4[0xe] = 0;
        *(int *)(param_4 + 0xc) = (int)uVar21;
      }
      else {
        puVar40 = (ushort *)(pbVar24 + uVar21);
        uVar35 = *puVar40;
        param_4[0xe] = uVar35;
        if (uVar35 == 0) {
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1000ff;
          cVar11 = func_0x(0x1107df0);
          if (cVar11 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100108;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100122;
              cVar11 = func_0x(0x1107df0);
              if (cVar11 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10013c;
                (*_DAT_)(0x22,0x44,0x15,0x3eb);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10015f;
                (*_DAT_)(1,0x9f77fc,0xb178e8,0x80f);
              }
            }
          }
          uVar15 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10016d;
          func_0x(uVar15,3);
          uVar35 = param_4[0xe];
          uVar21 = (ulonglong)*(uint *)(param_4 + 10);
          pbVar24 = *(byte **)(param_4 + 4);
        }
        uVar25 = (int)uVar21 + (uVar35 + 1) * 2;
        *(uint *)(param_4 + 0xc) = uVar25;
        if (0x1f9e < uVar25) {
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10019d;
          cVar11 = func_0x(0x1107df0);
          if (cVar11 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1001a6;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1001c0;
              cVar11 = func_0x(0x1107df0);
              if (cVar11 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1001dc;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1001ff;
                (*_DAT_)(1,0x9f77fc,0xb178e8,0x816);
              }
            }
          }
          uVar15 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10020d;
          func_0x(uVar15,4);
          uVar35 = param_4[0xe];
          uVar25 = *(uint *)(param_4 + 0xc);
          pbVar24 = *(byte **)(param_4 + 4);
        }
        uVar16 = (ulonglong)uVar35;
        uVar26 = puVar40[uVar16] & 0x7fff;
        *(uint *)(param_4 + 2) = uVar26;
        if (uVar26 < uVar25) {
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100240;
          cVar11 = func_0x(0x1107df0);
          if (cVar11 != '\0') {
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100249;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100263;
              cVar11 = func_0x(0x1107df0);
              if (cVar11 == '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10027f;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
                *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1002a2;
                (*_DAT_)(1,0x9f77fc,0xb178e8,0x81d);
              }
            }
          }
          uVar15 = *(undefined8 *)(param_4 + 4);
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1002b0;
          func_0x(uVar15,4);
          uVar25 = *(uint *)(param_4 + 0xc);
          uVar16 = (ulonglong)(ushort)param_4[0xe];
          uVar26 = *(uint *)(param_4 + 2);
          pbVar24 = *(byte **)(param_4 + 4);
        }
        puVar8 = puVar40;
        iVar37 = iVar29;
        if ((short)uVar16 != 0) {
          do {
            uVar33 = puVar8[1] & 0x7fff;
            if ((uVar33 < uVar25) || (uVar26 = *(uint *)(param_4 + 2), uVar26 < uVar33)) {
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1002f5;
              cVar11 = func_0x(0x1107df0);
              if (cVar11 != '\0') {
                *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1002fe;
                lVar14 = func_0x();
                if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100318;
                  cVar11 = func_0x(0x1107df0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100334;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
                    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10035a;
                    (*_DAT_)(1,0x9f77fc,0xb178e8,0x82a);
                  }
                }
              }
              uVar15 = *(undefined8 *)(param_4 + 4);
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100368;
              func_0x(uVar15,4);
              uVar26 = *(uint *)(param_4 + 2);
            }
            iVar37 = iVar37 + 1;
            uVar16 = (ulonglong)(ushort)param_4[0xe];
            uVar25 = uVar33;
            puVar8 = puVar8 + 1;
          } while (iVar37 < (int)(uint)(ushort)param_4[0xe]);
          pbVar24 = *(byte **)(param_4 + 4);
        }
        uVar21 = (ulonglong)uVar26;
        uVar36 = uVar16;
        if ((short)puVar40[(ulonglong)((int)uVar16 - 1) + 1] < 0) {
LAB_:
          sVar34 = (short)uVar16;
          uVar26 = *(ushort *)(pbVar24 + uVar36 * 2 + (ulonglong)*(uint *)(param_4 + 10)) & 0x7fff;
          if ((int)uVar36 == 1) {
            uVar33 = *(uint *)(param_4 + 0xc);
            uVar20 = uVar33;
LAB_:
            if ((uVar26 < uVar33) || (uVar25 = *(uint *)(param_4 + 2), uVar25 < uVar26))
            goto LAB_;
          }
          else {
            uVar33 = *(ushort *)(pbVar24 + uVar36 * 2 + ((ulonglong)*(uint *)(param_4 + 10) - 2)) &
                     0x7fff;
            uVar20 = *(uint *)(param_4 + 0xc);
            if (uVar20 <= uVar33) goto LAB_;
LAB_:
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100401;
            func_0x(pbVar24,7);
            uVar20 = *(uint *)(param_4 + 0xc);
            uVar25 = *(uint *)(param_4 + 2);
            pbVar24 = *(byte **)(param_4 + 4);
            sVar34 = param_4[0xe];
          }
          uVar21 = (ulonglong)uVar25;
          if ((uVar20 <= uVar33) && (uVar33 <= uVar25)) {
            if (*(ushort *)(pbVar24 + uVar33) == 5) {
              *puVar27 = *puVar27 | 2;
              param_4[0xe] = sVar34 + -1;
              uVar36 = (ulonglong)(uVar33 & 0xffff);
              param_4[0x15] = (short)uVar33;
              uVar16 = *(ulonglong *)(param_4 + 4);
              uVar21 = uVar16 + uVar36;
              uVar35 = param_4[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar21 + 2) & 0x4000) != 0) {
                uVar35 = *(ushort *)(uVar21 + 2) & 0x3800 | param_4[0x16] & 0xc7ffU;
              }
              param_4[0x16] = uVar35;
              uVar12 = (uVar35 ^ *(ushort *)(uVar21 + 2)) & 0x7ff ^ uVar35;
              param_4[0x16] = uVar12;
              uVar38 = (ulonglong)((uVar12 & 0x7ff) * 2) + 4 + uVar16 + (uVar35 >> 0xb & 7) * 2 +
                       uVar36;
              if (uVar38 < uVar21) {
                *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10051e;
                func_0x(uVar21,0x19);
                uVar12 = param_4[0x16];
                uVar36 = (ulonglong)(ushort)param_4[0x15];
                uVar16 = (ulonglong)*(uint *)(param_4 + 4);
              }
              uVar25 = (uint)uVar12;
              if (uVar26 - uVar33 <
                  (((uVar25 & 0x7ff) * 2 - (int)uVar36) - (int)uVar16) + (int)uVar38) {
                lVar14 = *(longlong *)(param_4 + 4);
                *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10055a;
                func_0x(uVar36 + lVar14,0x19);
                uVar25 = (uint)(ushort)param_4[0x16];
              }
              if (((uVar25 & 0x3800) != 0) &&
                 (puVar40 = (ushort *)
                            (*(longlong *)(param_4 + 4) + 4 + (ulonglong)(ushort)param_4[0x15]),
                 iVar37 = iVar29, (uVar25 & 0x3800) != 0)) {
                do {
                  if (((ushort)uVar25 & 0x7ff) < (*puVar40 & 0x7ff)) {
                    uVar35 = param_4[0x15];
                    lVar14 = *(longlong *)(param_4 + 4);
                    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1005b6;
                    func_0x((ulonglong)uVar35 + lVar14,0x1a);
                    uVar25 = (uint)(ushort)param_4[0x16];
                  }
                  iVar37 = iVar37 + 1;
                  puVar40 = puVar40 + 1;
                } while (iVar37 < (int)(uVar25 >> 0xb & 7));
              }
              pbVar24 = *(byte **)(param_4 + 4);
              uVar21 = (ulonglong)*(uint *)(param_4 + 2);
            }
            else if (0x3ff < *(ushort *)(pbVar24 + uVar33)) {
              *puVar27 = *puVar27 | 1;
              uVar35 = sVar34 - 1;
              param_4[0xe] = uVar35;
              if (uVar35 != 0) goto code_r0x00100451;
            }
            goto LAB_;
          }
          goto LAB_;
        }
      }
LAB_:
      if ((*pbVar24 & 0x40) == 0) {
        *(undefined4 *)(param_4 + 0x13) = 0;
      }
      else {
        *(int *)(param_4 + 0x13) = *(int *)(param_4 + 2);
        *(int *)(param_4 + 2) = *(int *)(param_4 + 2) + 0xe;
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100613;
        uVar15 = func_0x(puVar27);
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10061f;
        func_0x(uVar15,&stack0x00000078 + lVar13);
        uVar35 = *(ushort *)(&stack0x0000007e + lVar13);
        uVar12 = uVar35;
        if ((((uint)(int)(short)uVar35 >> 1 ^ (int)(short)uVar35) & 0x2000) != 0) {
          uVar12 = uVar35 & 0xdfff;
          if ((uVar35 & 0x4000) != 0) {
            uVar12 = uVar35 | 0x2000;
          }
        }
        if (uVar12 == 0xfffc) {
          uVar28 = (uint)(*(ushort *)(&stack0x0000007c + lVar13) >> 5);
        }
        *(uint *)(param_4 + 2) = *(int *)(param_4 + 2) + uVar28;
        uVar21 = (ulonglong)*(uint *)(param_4 + 2);
        pbVar24 = *(byte **)(param_4 + 4);
      }
      if ((*(byte **)(param_4 + 0xf) != (byte *)0x0) &&
         (*(byte **)(param_4 + 0xf) < pbVar24 + uVar21)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10069b;
        cVar11 = func_0x(0x1107df0);
        if (cVar11 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1006a4;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1006be;
            cVar11 = func_0x(0x1107df0);
            if (cVar11 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1006da;
              (*_DAT_)(0x22,0x44,0x15,0x3fa);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1006fd;
              (*_DAT_)(1,0x9f77fc,0xb178e8,0x886);
            }
          }
        }
        uVar15 = *(undefined8 *)(param_4 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10070b;
        func_0x(uVar15,0x12);
        uVar21 = (ulonglong)*(uint *)(param_4 + 2);
      }
      uVar25 = (uint)uVar21;
      if ((uVar25 == 0) || (0x3f3c < uVar25)) {
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100726;
        cVar11 = func_0x(0x1107df0);
        if (cVar11 != '\0') {
          *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10072f;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100749;
            cVar11 = func_0x(0x1107df0);
            if (cVar11 == '\0') {
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100765;
              (*_DAT_)(0x22,0x44,0x15,0x3ed);
            }
            else {
              *(undefined8 *)(&stack0xffffffffffffffe0 + lVar13) = 0;
              *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100788;
              (*_DAT_)(1,0x9f77fc,0xb178e8,0x88b);
            }
          }
        }
        uVar15 = *(undefined8 *)(param_4 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100796;
        func_0x(uVar15,5);
        uVar25 = *(uint *)(param_4 + 2);
      }
LAB_:
      param_2 = *(undefined8 *)((longlong)&uStackX_8 + lVar13);
      uVar21 = (ulonglong)*(uint *)((longlong)auStackX_14 + lVar13 + 4);
    }
    if ((uVar25 < 9) &&
       (((**(byte **)(param_4 + 4) & 0xe) == 0 || ((**(byte **)(param_4 + 4) & 0xe) == 0xc)))) {
      uVar25 = 9;
    }
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_4 + 8);
    *puVar1 = *puVar27;
    *(undefined4 *)(param_1 + 2) = *(undefined4 *)(param_4 + 2);
    param_1[0xe] = param_4[0xe];
    *(undefined4 *)(param_1 + 10) = *(undefined4 *)(param_4 + 10);
    *(undefined4 *)(param_1 + 0xc) = *(undefined4 *)(param_4 + 0xc);
    *(undefined4 *)(param_1 + 0x13) = *(undefined4 *)(param_4 + 0x13);
    uVar15 = *(undefined8 *)(param_4 + 4);
    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100801;
    func_0x(param_2,uVar21,uVar15,uVar25);
    *(undefined8 *)(param_1 + 4) = param_2;
    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10080d;
    iVar37 = func_0x(puVar1);
    if (iVar37 != 0) {
      lVar14 = *(longlong *)(param_1 + 4);
      puVar27 = (ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar14);
      uVar25 = *puVar27 - 1;
      if ((*(byte *)puVar1 & 1) == 0) {
        uVar25 = (uint)*puVar27;
      }
      uVar28 = puVar27[(int)uVar25] & 0x7fff;
      if (uVar25 == 1) {
        uVar25 = *(uint *)(param_1 + 0xc);
LAB_:
        if ((uVar28 < uVar25) || (*(uint *)(param_1 + 2) < uVar28)) goto LAB_;
      }
      else {
        uVar25 = puVar27[(longlong)(int)uVar25 + -1] & 0x7fff;
        if (*(uint *)(param_1 + 0xc) <= uVar25) goto LAB_;
LAB_:
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10086d;
        func_0x(lVar14,7);
      }
      uVar36 = (ulonglong)(uVar25 & 0xffff);
      param_1[0x15] = (short)uVar25;
      uVar16 = *(ulonglong *)(param_1 + 4);
      uVar21 = uVar36 + uVar16;
      uVar35 = param_1[0x16] & 0xc7ff;
      if ((*(ushort *)(uVar21 + 2) >> 0xe & 1) != 0) {
        uVar35 = *(ushort *)(uVar21 + 2) & 0x3800 | uVar35;
      }
      param_1[0x16] = uVar35;
      uVar12 = (uVar35 ^ *(ushort *)(uVar21 + 2)) & 0x7ff ^ uVar35;
      param_1[0x16] = uVar12;
      uVar38 = uVar16 + 4 + (ulonglong)((uVar12 & 0x7ff) * 2) + (uVar35 >> 0xb & 7) * 2 + uVar36;
      if (uVar38 < uVar21) {
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100903;
        func_0x(uVar21,0x19);
        uVar12 = param_1[0x16];
        uVar36 = (ulonglong)(ushort)param_1[0x15];
        uVar16 = (ulonglong)*(uint *)(param_1 + 4);
      }
      if (uVar28 - uVar25 < (((uVar12 & 0x7ff) * 2 - (int)uVar36) - (int)uVar16) + (int)uVar38) {
        lVar14 = *(longlong *)(param_1 + 4);
        *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x10093c;
        func_0x(uVar36 + lVar14,0x19);
        uVar12 = param_1[0x16];
      }
      if (((uVar12 & 0x3800) != 0) &&
         (puVar27 = (ushort *)(*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]),
         (uVar12 & 0x3800) != 0)) {
        do {
          if ((uVar12 & 0x7ff) < (*puVar27 & 0x7ff)) {
            uVar35 = param_1[0x15];
            lVar14 = *(longlong *)(param_1 + 4);
            *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x100998;
            func_0x((ulonglong)uVar35 + lVar14,0x1a);
            uVar12 = param_1[0x16];
          }
          iVar29 = iVar29 + 1;
          puVar27 = puVar27 + 1;
        } while (iVar29 < (int)(uVar12 >> 0xb & 7));
        *(undefined8 *)(*(longlong *)(&stack0x00000070 + lVar13) + 0x10) = 0;
        puVar31 = &stack0xffffffffffffffc0 + lVar13;
        goto LAB_;
      }
    }
  }
  else {
    *(undefined8 *)((longlong)&uStack_48 + lVar13) = 0x1009cf;
    func_0x(puVar1);
  }
  *(undefined8 *)(*(longlong *)(&stack0x00000070 + lVar13) + 0x10) = 0;
  puVar31 = &stack0xffffffffffffffc0 + lVar13;
LAB_:
  uVar21 = *(ulonglong *)(&stack0x00002aa0 + lVar13);
  *(undefined8 *)(puVar31 + -8) = 0x1010af;
  func_0x(uVar21 ^ (ulonglong)puVar2);
  return;
code_r0x00100dce:
  if (lVar17 == *(longlong *)(&stack0x00000068 + lVar13)) {
    uVar25 = *(uint *)((longlong)auStackX_14 + lVar13);
    *(uint *)(&stack0x00000038 + lVar13) = *(int *)(&stack0x00000038 + lVar13) + uVar25;
    *(ulonglong *)(&stack0x00000068 + lVar13) =
         *(longlong *)(&stack0x00000068 + lVar13) + (ulonglong)uVar25;
  }
  else {
    uVar25 = *(uint *)((longlong)auStackX_14 + lVar13);
  }
  plVar23 = (longlong *)((ulonglong)uVar12 * 0x20 + *(longlong *)(&stack0x00000058 + lVar13));
  *plVar23 = lVar17;
  *(uint *)(plVar23 + 1) = uVar25;
  uVar25 = *(uint *)((longlong)plVar23 + 0xc);
  *(uint *)((longlong)plVar23 + 0xc) = uVar25 & 0xfffffffa;
  uVar5 = *(undefined4 *)(&stack0x0000002c + lVar13);
  uVar6 = *(undefined4 *)(&stack0x00000030 + lVar13);
  uVar9 = *(undefined4 *)(&stack0x00000034 + lVar13);
  *(undefined4 *)(plVar23 + 2) = *(undefined4 *)(&stack0x00000028 + lVar13);
  *(undefined4 *)((longlong)plVar23 + 0x14) = uVar5;
  *(undefined4 *)(plVar23 + 3) = uVar6;
  *(undefined4 *)((longlong)plVar23 + 0x1c) = uVar9;
  *(uint *)((longlong)plVar23 + 0xc) = uVar25 & 0xfffffff0;
  plVar23 = *(longlong **)(&stack0x00000030 + lVar13);
  uVar12 = *(ushort *)((longlong)&uStackX_20 + lVar13 + 2);
  goto LAB_;
code_r0x00100451:
  uVar16 = (ulonglong)uVar35;
  uVar36 = (ulonglong)(uint)uVar35;
  if (-1 < (short)puVar40[(ulonglong)(uVar35 - 1) + 1]) goto LAB_;
  goto LAB_;
}

