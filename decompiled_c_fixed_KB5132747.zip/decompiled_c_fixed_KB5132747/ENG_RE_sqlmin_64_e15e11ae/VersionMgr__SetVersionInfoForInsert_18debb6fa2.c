
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(short *param_1,longlong *param_2,char param_3,char param_4,char param_5)

{
  ushort *puVar1;
  longlong *plVar2;
  longlong lVar3;
  ushort *puVar4;
  char cVar5;
  byte bVar6;
  ushort uVar7;
  ushort uVar8;
  undefined4 uVar9;
  longlong lVar10;
  undefined8 uVar11;
  ulonglong *puVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  short *psVar16;
  uint uVar17;
  uint uVar18;
  ulonglong uVar19;
  byte *pbVar20;
  ulonglong uVar21;
  ushort *puVar22;
  longlong lVar23;
  int iVar24;
  short *psStackX_8;
  undefined8 uStackX_10;
  char cStackX_18;
  undefined8 uStack_58;
  undefined auStack_50 [4];
  ushort uStack_4c;
  ushort uStack_4a;
  longlong lStack_48;
  longlong lStack_40;
  
  lVar23 = param_2[0x1a];
  iVar24 = 0;
  psStackX_8 = param_1;
  cStackX_18 = param_3;
  if (((param_4 != '\0') || (lVar23 == 0)) ||
     ((*(int *)(lVar23 + 0x78) < 1 && (*(int *)(lVar23 + 0x74) < 1)))) {
    cVar5 = (**(code **)(*param_2 + 0x88))(param_2);
    if (cVar5 == '\0') {
      uVar9 = (**(code **)(*param_2 + 0x50))(param_2);
      uVar7 = 0xfffc;
      uStackX_10 = CONCAT44(0xfffc0003,uVar9);
    }
    else {
      uStackX_10 = 0;
      uVar7 = 0;
    }
    goto LAB_;
  }
  LOCK();
  plVar2 = (longlong *)(lVar23 + 0x128);
  lVar23 = *plVar2;
  *plVar2 = *plVar2 + 1;
  UNLOCK();
  lVar23 = lVar23 + 1;
  lStack_48 = lVar23;
  lStack_40 = lVar23;
  cVar5 = (**(code **)(*param_2 + 0x88))(param_2);
  if (cVar5 != '\0') {
    uVar7 = 0xfffe;
    uStackX_10 = CONCAT26(0xfffe,(int6)lVar23);
    goto LAB_;
  }
  puVar1 = (ushort *)(param_1 + 1);
  uVar13 = *(uint *)(param_1 + 2);
  if (*param_1 == 0) {
    if (uVar13 == 0) {
      pbVar20 = *(byte **)(param_1 + 4);
      uVar13 = *(uint *)(param_1 + 8);
      uVar15 = (ulonglong)uVar13;
      *puVar1 = 0;
      *(uint *)(param_1 + 10) = uVar13;
      bVar6 = *pbVar20;
      if ((bVar6 & 0x10) != 0) {
        uVar13 = uVar13 + 2 + (*(ushort *)(pbVar20 + uVar15) + 7 >> 3);
        uVar15 = (ulonglong)uVar13;
        *(uint *)(param_1 + 10) = uVar13;
        bVar6 = *pbVar20;
      }
      if ((bVar6 & 0x20) == 0) {
        *(int *)(param_1 + 2) = (int)uVar15;
        param_1[0xe] = 0;
        *(int *)(param_1 + 0xc) = (int)uVar15;
      }
      else {
        puVar22 = (ushort *)(pbVar20 + uVar15);
        uVar7 = *puVar22;
        param_1[0xe] = uVar7;
        if (uVar7 == 0) {
          cVar5 = func_0x(0x15df120);
          if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar5 = func_0x(0x15df120);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xeceb2c,0xfeec18,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),3);
          uVar15 = (ulonglong)*(uint *)(param_1 + 10);
          uVar7 = param_1[0xe];
        }
        uVar13 = (int)uVar15 + (uVar7 + 1) * 2;
        *(uint *)(param_1 + 0xc) = uVar13;
        if (0x1f9e < uVar13) {
          cVar5 = func_0x(0x15df120);
          if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar5 = func_0x(0x15df120);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xeceb2c,0xfeec18,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar7 = param_1[0xe];
          uVar13 = *(uint *)(param_1 + 0xc);
        }
        uVar15 = (ulonglong)uVar7;
        uVar7 = puVar22[uVar15];
        *(uint *)(param_1 + 2) = uVar7 & 0x7fff;
        if ((uVar7 & 0x7fff) < uVar13) {
          cVar5 = func_0x(0x15df120);
          if (((cVar5 != '\0') && (lVar10 = func_0x(), lVar10 != 0)) &&
             (*(char *)(lVar10 + 0x499) != '\0')) {
            cVar5 = func_0x(0x15df120);
            if (cVar5 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xeceb2c,0xfeec18,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_1 + 4),4);
          uVar13 = *(uint *)(param_1 + 0xc);
          uVar15 = (ulonglong)(ushort)param_1[0xe];
        }
        puVar4 = puVar22;
        if ((short)uVar15 != 0) {
          do {
            uVar17 = puVar4[1] & 0x7fff;
            if ((uVar17 < uVar13) || (*(uint *)(param_1 + 2) < uVar17)) {
              cVar5 = func_0x(0x15df120);
              if ((cVar5 != '\0') &&
                 ((lVar23 = func_0x(), lVar23 != 0 &&
                  (*(char *)(lVar23 + 0x499) != '\0')))) {
                cVar5 = func_0x(0x15df120);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0xeceb2c,0xfeec18,0x82a,0);
                }
              }
              func_0x(*(undefined8 *)(param_1 + 4),4);
            }
            uVar15 = (ulonglong)(ushort)param_1[0xe];
            iVar24 = iVar24 + 1;
            lVar23 = lStack_40;
            puVar4 = puVar4 + 1;
            uVar13 = uVar17;
          } while (iVar24 < (int)(uint)(ushort)param_1[0xe]);
        }
        if ((short)puVar22[(ulonglong)((int)uVar15 - 1) + 1] < 0) {
          lVar10 = *(longlong *)(param_1 + 4);
          do {
            uVar17 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar10 + uVar15 * 2) & 0x7fff;
            if ((int)uVar15 == 1) {
              uVar18 = *(uint *)(param_1 + 0xc);
              uVar14 = uVar18;
LAB_:
              if ((uVar17 < uVar18) || (uVar13 = *(uint *)(param_1 + 2), uVar13 < uVar17))
              goto LAB_;
            }
            else {
              uVar14 = *(uint *)(param_1 + 0xc);
              uVar18 = *(ushort *)((ulonglong)*(uint *)(param_1 + 10) + lVar10 + -2 + uVar15 * 2) &
                       0x7fff;
              if (uVar14 <= uVar18) goto LAB_;
LAB_:
              func_0x(lVar10,7);
              uVar14 = *(uint *)(param_1 + 0xc);
              uVar13 = *(uint *)(param_1 + 2);
            }
            if ((uVar18 < uVar14) || (uVar13 < uVar18)) goto LAB_;
            lVar10 = *(longlong *)(param_1 + 4);
            if (*(ushort *)(lVar10 + (ulonglong)uVar18) == 5) {
              *puVar1 = *puVar1 | 2;
              param_1[0xe] = param_1[0xe] + -1;
              uVar19 = (ulonglong)(uVar18 & 0xffff);
              param_1[0x15] = (short)uVar18;
              uVar15 = *(ulonglong *)(param_1 + 4);
              uVar7 = param_1[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar19 + 2 + uVar15) >> 0xe & 1) != 0) {
                uVar7 = *(ushort *)(uVar19 + 2 + uVar15) & 0x3800 | param_1[0x16] & 0xc7ffU;
              }
              param_1[0x16] = uVar7;
              uVar21 = (ulonglong)(ushort)param_1[0x15];
              uVar8 = (uVar7 ^ *(ushort *)(uVar19 + 2 + uVar15)) & 0x7ff ^ uVar7;
              param_1[0x16] = uVar8;
              uVar19 = uVar21 + 4 +
                       (ulonglong)((uVar8 & 0x7ff) * 2) + uVar15 + (uVar7 >> 0xb & 7) * 2;
              if (uVar19 < uVar21 + uVar15) {
                func_0x(uVar21 + uVar15,0x19);
                uVar8 = param_1[0x16];
                uVar21 = (ulonglong)(ushort)param_1[0x15];
                uVar15 = (ulonglong)*(uint *)(param_1 + 4);
              }
              if (uVar17 - uVar18 <
                  (((uVar8 & 0x7ff) * 2 - (int)uVar21) - (int)uVar15) + (int)uVar19) {
                func_0x(uVar21 + *(longlong *)(param_1 + 4),0x19);
                uVar8 = param_1[0x16];
              }
              if ((uVar8 & 0x3800) != 0) {
                iVar24 = 0;
                puVar22 = (ushort *)
                          (*(longlong *)(param_1 + 4) + 4 + (ulonglong)(ushort)param_1[0x15]);
                if ((uVar8 & 0x3800) != 0) {
                  do {
                    if ((uVar8 & 0x7ff) < (*puVar22 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)param_1[0x15] + *(longlong *)(param_1 + 4),
                                      0x1a);
                      uVar8 = param_1[0x16];
                    }
                    iVar24 = iVar24 + 1;
                    puVar22 = puVar22 + 1;
                  } while (iVar24 < (int)(uVar8 >> 0xb & 7));
                }
              }
              break;
            }
            if (*(ushort *)(lVar10 + (ulonglong)uVar18) < 0x400) break;
            *puVar1 = *puVar1 | 1;
            uVar7 = param_1[0xe] - 1;
            param_1[0xe] = uVar7;
            if ((uVar7 == 0) ||
               (uVar15 = (ulonglong)uVar7, -1 < (short)puVar22[(ulonglong)(uVar7 - 1) + 1])) break;
          } while( true );
        }
        pbVar20 = *(byte **)(param_1 + 4);
        uVar15 = (ulonglong)*(uint *)(param_1 + 2);
      }
      uVar13 = 0;
      if ((*pbVar20 & 0x40) == 0) {
        *(undefined4 *)(param_1 + 0x13) = 0;
      }
      else {
        *(int *)(param_1 + 0x13) = (int)uVar15;
        *(int *)(param_1 + 2) = (int)uVar15 + 0xe;
        uVar11 = func_0x(puVar1);
        func_0x(uVar11,auStack_50);
        uVar7 = uStack_4a;
        if ((((uint)(int)(short)uStack_4a >> 1 ^ (int)(short)uStack_4a) & 0x2000) != 0) {
          uVar7 = uStack_4a & 0xdfff;
          if ((uStack_4a >> 0xe & 1) != 0) {
            uVar7 = uStack_4a | 0x2000;
          }
        }
        if (uVar7 == 0xfffc) {
          uVar13 = (uint)(uStack_4c >> 5);
        }
        *(uint *)(param_1 + 2) = *(int *)(param_1 + 2) + uVar13;
        uVar15 = (ulonglong)*(uint *)(param_1 + 2);
      }
      uVar13 = (uint)uVar15;
      if ((*(ulonglong *)(param_1 + 0xf) != 0) &&
         (*(ulonglong *)(param_1 + 0xf) < uVar15 + *(longlong *)(param_1 + 4))) {
        cVar5 = func_0x(0x15df120);
        if ((cVar5 != '\0') &&
           ((lVar10 = func_0x(), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0'))
           )) {
          cVar5 = func_0x(0x15df120);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xeceb2c,0xfeec18,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),0x12);
        uVar13 = *(uint *)(param_1 + 2);
      }
      if ((uVar13 == 0) || (0x3f3c < uVar13)) {
        cVar5 = func_0x(0x15df120);
        if ((cVar5 != '\0') &&
           ((lVar10 = func_0x(), lVar10 != 0 && (*(char *)(lVar10 + 0x499) != '\0'))
           )) {
          cVar5 = func_0x(0x15df120);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0xeceb2c,0xfeec18,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_1 + 4),5);
        uVar13 = *(uint *)(param_1 + 2);
      }
    }
LAB_:
    psVar16 = psStackX_8;
    if ((uVar13 < 9) &&
       (((**(byte **)(param_1 + 4) & 0xe) == 0 || ((**(byte **)(param_1 + 4) & 0xe) == 0xc)))) {
      uVar13 = 9;
    }
  }
  else {
    if (uVar13 == 0) {
      func_0x(puVar1);
      uVar13 = *(uint *)(param_1 + 2);
    }
    psVar16 = param_1;
    if ((uVar13 < 9) &&
       (((**(byte **)(param_1 + 4) & 0x1c) == 0 || ((**(byte **)(param_1 + 4) & 0x1c) == 0xc)))) {
      uVar13 = 9;
    }
  }
  param_1 = psVar16;
  if (uVar13 < 0x1f74) {
    if (param_5 == '\0') {
      uVar9 = (**(code **)(*param_2 + 0x50))(param_2);
      uVar7 = 0xfffc;
      uStackX_10 = CONCAT44(0xfffc0103,uVar9);
      param_3 = cStackX_18;
      goto LAB_;
    }
LAB_:
    *(longlong *)(param_2[6] + 0x1a8) = *(longlong *)(param_2[6] + 0x1a8) + 1;
  }
  else if (param_5 != '\0') goto LAB_;
  uStack_58 = 0;
  psStackX_8 = (short *)((ulonglong)psStackX_8 & 0xffff000000000000);
  cVar5 = (**(code **)(*param_2 + 0x10))(param_2);
  if (cVar5 == '\0') {
    (*_DAT_)(1,0x109f528,0x10558f8,0x3fb,0);
  }
  lVar10 = param_2[6];
  lVar3 = *(longlong *)(lVar10 + 0x7c0);
  if (*(char *)(*(longlong *)(lVar3 + 8) + 0x2050) != '\0') {
    (*_DAT_)(1,0x109cef0,0x1055828,0x13e,0);
  }
  func_0x(*(undefined8 *)(lVar3 + 0x10),param_2,0,psVar16,0,lVar23,&psStackX_8,&uStack_58,
                  &uStackX_10);
  uVar7 = uStackX_10._6_2_;
  if ((((uint)(int)(short)uStackX_10._6_2_ >> 1 ^ (int)(short)uStackX_10._6_2_) & 0x2000) != 0) {
    uVar7 = uStackX_10._6_2_ & 0xdfff;
    if ((uStackX_10._6_2_ >> 0xe & 1) != 0) {
      uVar7 = uStackX_10._6_2_ | 0x2000;
    }
  }
  if (uVar7 == 0xfffc) {
    (*_DAT_)(1,0x10798c0,0x1053030,0x502,0);
  }
  plVar2 = (longlong *)(lVar10 + 0x68);
  *plVar2 = *plVar2 + 1;
  uVar7 = uStackX_10._6_2_ | 0x1000;
  uStackX_10 = uStackX_10 | 0x1000000080000000;
  param_3 = cStackX_18;
LAB_:
  puVar12 = (ulonglong *)0x0;
  if (param_3 != '\0') {
    if ((uVar7 & 0x4000) == 0) {
      uVar7 = uVar7 | 0x2000;
    }
    else {
      uVar7 = uVar7 & 0xdfff;
    }
    uStackX_10 = CONCAT26(uVar7,(undefined6)uStackX_10);
  }
  if ((*(byte *)(param_2 + 0x43) & 4) == 0) {
    param_2 = param_2 + 5;
  }
  else {
    lVar23 = (**(code **)(*param_2 + 0x1e8))(param_2);
    param_2 = (longlong *)(lVar23 + 0x28);
  }
  if (*param_1 == 0) {
    func_0x();
  }
  else {
    func_0x(param_1 + 1,param_2);
  }
  uVar13 = (uint)(short)uStackX_10._6_2_;
  uVar15 = (ulonglong)uVar13;
  uVar17 = uVar13 >> 0xd & 1;
  uVar13 = uVar13 >> 0xe & 1;
  uVar7 = uStackX_10._6_2_;
  if (uVar17 != uVar13) {
    uVar7 = uStackX_10._6_2_ & 0xdfff;
    if ((uStackX_10 & 0x4000000000000000) != 0) {
      uVar7 = uStackX_10._6_2_ | 0x2000;
    }
  }
  if (uVar7 == 0xfffc) {
    uVar7 = uStackX_10._6_2_;
    if (uVar17 != uVar13) {
      uVar7 = uStackX_10._6_2_ & 0xdfff;
      if ((uStackX_10 & 0x4000000000000000) != 0) {
        uVar7 = uStackX_10._6_2_ | 0x2000;
      }
    }
    if (uVar7 == 0xfffc) {
      uVar7 = uStackX_10._4_2_ & 0x1f;
    }
    else {
      (*_DAT_)(1,0x10594c8,0x1053030,0x4ba,0);
      uVar15 = uStackX_10 >> 0x30;
      uVar7 = uStackX_10._4_2_;
    }
    uVar8 = (ushort)uVar15;
    if (uVar7 == 3) {
      uVar7 = uVar8;
      if (((((uint)(int)(short)uVar8 >> 1 ^ (int)(short)uVar8) & 0x2000) != 0) &&
         (uVar7 = uVar8 & 0xdfff, (uVar15 & 0x4000) != 0)) {
        uVar7 = uVar8 | 0x2000;
      }
      if ((uVar7 == 0xfffc) && (uStackX_10._4_2_ >> 5 == 8)) {
        if (*param_1 == 0) {
          func_0x();
          return;
        }
        func_0x(param_1 + 1,&uStackX_10,&lStack_48);
        return;
      }
    }
  }
  if (*param_1 == 0) {
    func_0x(param_1 + 1,&uStackX_10);
  }
  else {
    if (*(int *)(param_1 + 2) == 0) {
      func_0x(param_1 + 1);
    }
    func_0x(param_1 + 1);
    if ((**(byte **)(param_1 + 4) & 2) != 0) {
      puVar12 = (ulonglong *)(*(byte **)(param_1 + 4) + *(uint *)(param_1 + 0x18));
    }
    *puVar12 = uStackX_10;
    *(undefined4 *)(param_1 + 2) = 0;
    func_0x(param_1 + 1);
  }
  return;
}

