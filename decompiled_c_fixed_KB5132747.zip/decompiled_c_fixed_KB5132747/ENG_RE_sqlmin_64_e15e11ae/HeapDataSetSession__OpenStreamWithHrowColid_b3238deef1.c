
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,ulonglong param_4,
                 uint param_5,longlong *param_6)

{
  longlong *plVar1;
  code *pcVar2;
  byte bVar3;
  bool bVar4;
  undefined8 uVar5;
  char cVar6;
  ushort uVar7;
  ushort uVar8;
  int iVar9;
  int iVar10;
  uint *puVar11;
  short *psVar12;
  longlong lVar13;
  longlong lVar14;
  undefined8 uVar15;
  longlong lVar16;
  byte *pbVar17;
  ulonglong uVar18;
  uint uVar19;
  ushort *puVar20;
  longlong lVar21;
  uint uVar22;
  uint uVar23;
  uint *puVar24;
  ushort *puVar25;
  ulonglong uVar26;
  longlong unaff_GS_OFFSET;
  undefined8 auStack_1c0 [5];
  uint *puStack_198;
  uint auStack_190 [2];
  uint *puStack_188;
  uint auStack_180 [2];
  longlong *plStack_178;
  undefined4 auStack_170 [2];
  longlong alStack_168 [2];
  uint uStack_158;
  uint uStack_154;
  byte bStack_150;
  uint uStack_14c;
  byte bStack_148;
  byte bStack_147;
  byte bStack_146;
  undefined4 uStack_144;
  uint auStack_140 [2];
  uint *apuStack_138 [2];
  undefined8 uStack_128;
  undefined4 uStack_118;
  undefined2 uStack_114;
  ushort uStack_110;
  ushort uStack_10c;
  ushort uStack_108;
  ushort uStack_104;
  short sStack_100;
  ushort uStack_fc;
  int iStack_f8;
  int iStack_f4;
  uint uStack_f0;
  uint uStack_e8;
  uint uStack_e0;
  int iStack_dc;
  uint *puStack_d8;
  uint uStack_d0;
  uint uStack_cc;
  uint uStack_c8;
  uint uStack_c0;
  undefined4 uStack_bc;
  uint uStack_b8;
  undefined4 uStack_b0;
  uint uStack_ac;
  undefined auStack_a8 [8];
  longlong lStack_a0;
  uint *puStack_98;
  ushort *puStack_90;
  short *psStack_88;
  ulonglong uStack_80;
  longlong lStack_78;
  undefined8 uStack_70;
  undefined8 uStack_58;
  ulonglong uStack_50;
  ulonglong uStack_30;
  
  uStack_58 = 0xfffffffffffffffe;
  uStack_30 = _DAT_ ^ (ulonglong)&uStack_158;
  puVar24 = (uint *)0x0;
  iVar10 = 0;
  uStack_144 = 0;
  uStack_e0 = param_5;
  uStack_80 = param_4;
  lStack_78 = param_1;
  uStack_70 = param_2;
  if (param_3 == (longlong *)0x0) {
    puStack_198 = (uint *)0x0;
    auStack_1c0[0] = 0x1000a0;
    (*_DAT_)(1,0x1965a90,0x1939388,0xbc0);
  }
  *param_6 = 0;
  auStack_1c0[0] = 0x1000ce;
  puVar11 = (uint *)func_0x
                              (*(undefined8 *)
                                (*(longlong *)(**(longlong **)(param_1 + 0x2e0) + 8) + 0x160),
                               param_4 & 0xffffffff);
  bStack_150 = *(byte *)((longlong)puVar11 + 0x21) & 4;
  iStack_dc = (bStack_150 != 0) + 1;
  auStack_1c0[0] = 0x1000f8;
  apuStack_138[0] = puVar11;
  iVar9 = func_0x(param_3,0,0);
  if (iVar9 == 0x40f02) {
    if ((param_3[8] != _DAT_) || (param_3[9] != _DAT_)) {
      if ((*(byte *)(param_3 + 0x14) & 2) != 0) {
        auStack_1c0[0] = 0x100133;
        iVar9 = func_0x(param_3 + 0x15);
        if (iVar9 != 0) {
          *(longlong *)(param_3[6] + 0x30) = *(longlong *)(param_3[6] + 0x30) + -1;
        }
      }
      *(undefined *)(param_3 + 0x14) = 0;
      *(undefined4 *)((longlong)param_3 + 0x9c) = 0;
      *(undefined4 *)(param_3 + 0x17) = 0;
    }
    if ((param_3[0x58] != _DAT_) || (param_3[0x59] != _DAT_)) {
      if ((*(byte *)(param_3 + 100) & 2) != 0) {
        auStack_1c0[0] = 0x10018b;
        iVar9 = func_0x(param_3 + 0x65);
        if (iVar9 != 0) {
          *(longlong *)(param_3[0x56] + 0x30) = *(longlong *)(param_3[0x56] + 0x30) + -1;
        }
      }
      *(undefined *)(param_3 + 100) = 0;
      *(undefined4 *)((longlong)param_3 + 0x31c) = 0;
      *(undefined4 *)(param_3 + 0x67) = 0;
    }
    *(undefined4 *)((longlong)param_3 + 0x634) = 0;
    *(undefined4 *)((longlong)param_3 + 0x634) = 1;
    auStack_1c0[0] = 0x1001d5;
    (*_DAT_)(0xdc,0x12,0x19,1);
  }
  auStack_1c0[0] = 0x1001e3;
  psVar12 = (short *)func_0x(param_3,1,0);
  puVar20 = (ushort *)(psVar12 + 1);
  psStack_88 = psVar12;
  if (*psVar12 == 0) {
    auStack_1c0[0] = 0x100203;
    func_0x();
  }
  else {
    auStack_1c0[0] = 0x10020a;
    func_0x(puVar20,&uStack_118);
  }
  uStack_bc = 0x1f9e;
  auStack_1c0[0] = 0x10021e;
  lVar13 = func_0x();
  lVar13 = -lVar13;
  bVar3 = *(byte *)(puVar11 + 8) >> 1;
  puStack_98 = puVar11;
  if (*psVar12 != 0) {
    auStack_140[0] = 0;
    *(uint **)((longlong)auStack_190 + lVar13 + -8) = auStack_140;
    *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100c60;
    puVar24 = (uint *)func_0x(puVar20,puVar11);
    puStack_d8 = puVar24;
    if ((((*psVar12 != 0) && (plVar1 = *(longlong **)(psVar12 + 8), plVar1 != (longlong *)0x0)) &&
        (*plVar1 != 0)) &&
       (((*(byte *)((longlong)puVar11 + 6) & 8) == 0 && ((auStack_140[0] & 1) == 0)))) {
      if ((puVar24 == (uint *)0x0) || (puVar24 == (uint *)0x1539690)) {
        puVar24 = (uint *)0x0;
        uStack_158 = 0;
        puStack_d8 = puVar24;
      }
      else {
        *(uint *)((longlong)auStack_180 + lVar13) = auStack_140[0];
        *(uint **)((longlong)&puStack_188 + lVar13) = &uStack_158;
        *(undefined4 *)((longlong)auStack_190 + lVar13) = 0x1f9e;
        *(longlong *)((longlong)auStack_190 + lVar13 + -8) = (longlong)&uStack_158 + lVar13;
        uVar19 = uStack_158;
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100cc8;
        puVar24 = (uint *)func_0x(plVar1,puVar11,puVar24,uVar19);
        puStack_d8 = puVar24;
      }
    }
    goto LAB_;
  }
  uVar19 = *puVar11;
  puStack_90 = puVar20;
  if ((uVar19 & 0xc0000000) == 0x80000000) {
    *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100c24;
    iVar10 = func_0x(puVar20);
    if (iVar10 != 0) {
      *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100c40;
      puVar24 = (uint *)func_0x(psVar12 + 0x15,puVar11,&uStack_158,apuStack_138);
      goto LAB_;
    }
LAB_:
    uStack_158 = 0;
    goto LAB_;
  }
  if (((bVar3 & 1) == 0) && ((*(byte *)((longlong)puVar11 + 6) & 0x10) == 0)) {
    uStack_14c = 0;
LAB_:
    bVar4 = true;
LAB_:
    if (((bVar3 & 1) != 0) && (uStack_14c != 0)) goto LAB_;
    if ((!bVar4) && ((*(byte *)((longlong)puVar11 + 6) & 0x10) != 0)) {
      puVar24 = *(uint **)(puVar11 + 2) + 1;
      uStack_158 = **(uint **)(puVar11 + 2);
      goto LAB_;
    }
  }
  else {
    pbVar17 = *(byte **)(psVar12 + 4);
    if ((*pbVar17 & 0x10) == 0) {
      bStack_148 = *pbVar17 & 0xe;
      if ((1 << bStack_148 & 0x1105U) == 0) {
        bVar4 = true;
        uStack_14c = 0;
      }
      else {
        bVar4 = false;
        uStack_14c = ~(uint)(*(ushort *)((longlong)puVar11 + 6) >> 4) & 1;
      }
      goto LAB_;
    }
    uVar23 = *(uint *)(psVar12 + 8);
    if ((int)uVar23 <= (int)uVar19) {
LAB_:
      uStack_14c = ~(uint)(*(ushort *)((longlong)puVar11 + 6) >> 4) & 1;
      bVar4 = false;
      goto LAB_;
    }
    if (*(ushort *)(pbVar17 + uVar23) < *(ushort *)(puVar11 + 1)) goto LAB_;
    if ((bVar3 & 1) != 0) {
      uStack_b8 = *(ushort *)(puVar11 + 1) - 1;
      bStack_147 = pbVar17[(ulonglong)(uStack_b8 >> 3) + (ulonglong)uVar23 + 2] >>
                   ((byte)uStack_b8 & 7);
      uStack_14c = bStack_147 & 1;
      goto LAB_;
    }
    uStack_14c = 0;
    uStack_b0 = 1;
  }
  if (-1 < (int)uVar19) {
    uVar8 = *(ushort *)((longlong)puVar11 + 6);
    if ((uVar8 & 8) != 0) {
      puVar24 = (uint *)0x1539690;
      if ((*(byte *)((longlong)(int)uVar19 + *(longlong *)(psVar12 + 4)) &
          (byte)(1 << ((byte)uVar8 & 7))) == 0) {
        puVar24 = (uint *)0x1539691;
      }
      uStack_158 = 1;
      goto LAB_;
    }
    if ((uVar8 & 0x10) != 0) {
      pbVar17 = *(byte **)(psVar12 + 4);
      if ((*pbVar17 & 0x10) == 0) {
        if ((1 << (*pbVar17 & 0xe) & 0x1105U) != 0) {
LAB_:
          puVar24 = *(uint **)(puVar11 + 2) + 1;
          uStack_158 = **(uint **)(puVar11 + 2);
          if (uStack_158 != 0x1f9e) {
            *(undefined8 *)((longlong)auStack_190 + lVar13 + -8) = 0;
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1003db;
            (*_DAT_)(1,0x1962e40,0x19617a8,0x381);
          }
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(psVar12 + 8) <= (int)uVar19) ||
              (*(ushort *)(pbVar17 + *(uint *)(psVar12 + 8)) < *(ushort *)(puVar11 + 1)))
      goto LAB_;
    }
    uStack_158 = 0x1f9e;
    puVar24 = (uint *)((longlong)(int)*puVar11 + *(longlong *)(psVar12 + 4));
    goto LAB_;
  }
  if (*(int *)(psVar12 + 2) == 0) {
    uStack_154 = 0;
    *puVar20 = 0;
    uVar19 = *(uint *)(psVar12 + 8);
    *(uint *)(psVar12 + 10) = uVar19;
    pbVar17 = *(byte **)(psVar12 + 4);
    if ((*pbVar17 & 0x10) != 0) {
      uVar19 = uVar19 + 2 + (*(ushort *)(pbVar17 + *(uint *)(psVar12 + 8)) + 7 >> 3);
      *(uint *)(psVar12 + 10) = uVar19;
      pbVar17 = *(byte **)(psVar12 + 4);
    }
    if ((*pbVar17 & 0x20) == 0) {
      *(uint *)(psVar12 + 2) = uVar19;
      psVar12[0xe] = 0;
      *(undefined4 *)(psVar12 + 0xc) = *(undefined4 *)(psVar12 + 10);
    }
    else {
      puVar25 = (ushort *)(pbVar17 + uVar19);
      uVar8 = *puVar25;
      psVar12[0xe] = uVar8;
      uStack_128 = puVar25;
      if (uVar8 == 0) {
        puVar24 = (uint *)0x1;
        uStack_154 = 1;
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100483;
        cVar6 = func_0x(0x1ec4ff0);
        if (cVar6 != '\0') {
          *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x10048c;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1004a6;
            cVar6 = func_0x(0x1ec4ff0);
            if (cVar6 == '\0') {
              *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1004c2;
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              *(undefined8 *)((longlong)auStack_190 + lVar13 + -8) = 0;
              *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1004fc;
              (*_DAT_)(1,0x17b49fc,0x18d4ae8,0x80f);
            }
          }
        }
        uVar15 = *(undefined8 *)(psVar12 + 4);
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1004d2;
        func_0x(uVar15,3);
        uVar8 = psVar12[0xe];
      }
      uVar19 = *(int *)(psVar12 + 10) + (uVar8 + 1) * 2;
      *(uint *)(psVar12 + 0xc) = uVar19;
      if (0x1f9e < uVar19) {
        uStack_154 = (int)puVar24 + 1;
        puVar24 = (uint *)(ulonglong)uStack_154;
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x10052e;
        cVar6 = func_0x(0x1ec4ff0);
        if (cVar6 != '\0') {
          *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100537;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100551;
            cVar6 = func_0x(0x1ec4ff0);
            if (cVar6 == '\0') {
              *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x10056d;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)auStack_190 + lVar13 + -8) = 0;
              *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100591;
              (*_DAT_)(1,0x17b49fc,0x18d4ae8,0x816);
            }
          }
        }
        uVar15 = *(undefined8 *)(psVar12 + 4);
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x10059f;
        func_0x(uVar15,4);
      }
      uStack_110 = puVar25[(ushort)psVar12[0xe]];
      *(uint *)(psVar12 + 2) = uStack_110 & 0x7fff;
      uVar19 = *(uint *)(psVar12 + 0xc);
      if ((uStack_110 & 0x7fff) < uVar19) {
        uStack_154 = (int)puVar24 + 1;
        puVar24 = (uint *)(ulonglong)uStack_154;
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1005d2;
        cVar6 = func_0x(0x1ec4ff0);
        if (cVar6 != '\0') {
          *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1005db;
          lVar14 = func_0x();
          if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1005f5;
            cVar6 = func_0x(0x1ec4ff0);
            if (cVar6 == '\0') {
              *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100611;
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              *(undefined8 *)((longlong)auStack_190 + lVar13 + -8) = 0;
              *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100635;
              (*_DAT_)(1,0x17b49fc,0x18d4ae8,0x81d);
            }
          }
        }
        uVar15 = *(undefined8 *)(psVar12 + 4);
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100643;
        func_0x(uVar15,4);
        uVar19 = *(uint *)(psVar12 + 0xc);
      }
      iStack_f8 = 0;
      while( true ) {
        iVar9 = iStack_f8;
        uVar8 = psVar12[0xe];
        iVar10 = (int)puVar24;
        if ((int)(uint)uVar8 <= iStack_f8) break;
        uStack_fc = puVar25[(longlong)iStack_f8 + 1];
        uVar23 = uStack_fc & 0x7fff;
        if ((uVar23 < uVar19) || (*(uint *)(psVar12 + 2) < uVar23)) {
          uStack_154 = iVar10 + 1;
          puVar24 = (uint *)(ulonglong)uStack_154;
          *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x10068e;
          cVar6 = func_0x(0x1ec4ff0);
          if (cVar6 != '\0') {
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100697;
            lVar14 = func_0x();
            if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1006b1;
              cVar6 = func_0x(0x1ec4ff0);
              if (cVar6 == '\0') {
                *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1006cd;
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                *(undefined8 *)((longlong)auStack_190 + lVar13 + -8) = 0;
                *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1006f3;
                (*_DAT_)(1,0x17b49fc,0x18d4ae8,0x82a);
              }
            }
          }
          uVar15 = *(undefined8 *)(psVar12 + 4);
          *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100701;
          func_0x(uVar15,4);
        }
        iStack_f8 = iVar9 + 1;
        puVar25 = uStack_128;
        uVar19 = uVar23;
      }
      do {
        if (-1 < (short)puVar25[(ulonglong)(uVar8 - 1) + 1]) break;
        lVar14 = *(longlong *)(psVar12 + 4);
        lVar16 = (ulonglong)*(uint *)(psVar12 + 10) + lVar14;
        if (uVar8 == 1) {
          uVar19 = *(uint *)(psVar12 + 0xc);
        }
        else {
          uStack_10c = *(ushort *)(lVar16 + 2 + (longlong)(int)(uVar8 - 2) * 2);
          uVar19 = uStack_10c & 0x7fff;
        }
        uStack_108 = *(ushort *)(lVar16 + 2 + (longlong)(int)(uVar8 - 1) * 2);
        uVar22 = uStack_108 & 0x7fff;
        uVar23 = *(uint *)(psVar12 + 0xc);
        uStack_d0 = uVar22;
        uStack_ac = uVar19;
        if (((uVar19 < uVar23) || (uVar22 < uVar19)) || (*(uint *)(psVar12 + 2) < uVar22)) {
          *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x10079c;
          func_0x(lVar14,7);
          uVar23 = *(uint *)(psVar12 + 0xc);
        }
        uVar22 = uVar22 - uVar19;
        uStack_cc = uVar19;
        if ((uVar19 < uVar23) || (*(uint *)(psVar12 + 2) < uVar19)) {
          uStack_154 = iVar10 + 1;
          goto LAB_;
        }
        uStack_104 = *(ushort *)((ulonglong)uVar19 + *(longlong *)(psVar12 + 4));
        if (uStack_104 == 5) {
          *puVar20 = *puVar20 | 2;
          psVar12[0xe] = psVar12[0xe] + -1;
          psVar12[0x15] = (short)uVar19;
          lVar14 = ((ulonglong)uVar19 & 0xffff) + *(longlong *)(psVar12 + 4);
          uVar8 = *(ushort *)(lVar14 + 2);
          psVar12[0x16] = psVar12[0x16] & 0xc7ff;
          if ((uVar8 >> 0xe & 1) != 0) {
            psVar12[0x16] = psVar12[0x16] | uVar8 & 0x3800;
          }
          uVar8 = psVar12[0x16];
          uVar7 = (uVar8 ^ *(ushort *)(lVar14 + 2)) & 0x7ff ^ uVar8;
          psVar12[0x16] = uVar7;
          uVar18 = (ulonglong)(ushort)psVar12[0x15];
          uVar26 = (ulonglong)((uVar8 >> 0xb & 7) * 2) + 4 + ((ulonglong)uVar7 & 0x7ff) * 2 +
                   *(longlong *)(psVar12 + 4) + uVar18;
          uStack_c8 = uVar22;
          uStack_50 = uVar26;
          if (uVar26 < *(longlong *)(psVar12 + 4) + uVar18) {
            lVar14 = *(longlong *)(psVar12 + 4);
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x10087a;
            func_0x(lVar14 + uVar18,0x19);
            uVar7 = psVar12[0x16];
          }
          uVar8 = psVar12[0x15];
          uStack_c0 = (((uVar7 & 0x7ff) * 2 - *(int *)(psVar12 + 4)) - (uint)uVar8) + (int)uVar26;
          if (uVar22 < uStack_c0) {
            lVar14 = *(longlong *)(psVar12 + 4);
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1008b7;
            func_0x((ulonglong)(uint)uVar8 + lVar14,0x19);
            uVar7 = psVar12[0x16];
          }
          puVar11 = apuStack_138[0];
          if ((uVar7 & 0x3800) != 0) {
            uVar8 = psVar12[0x15];
            lVar14 = *(longlong *)(psVar12 + 4);
            iStack_f4 = 0;
            while (iVar9 = iStack_f4, puVar11 = apuStack_138[0],
                  iStack_f4 < (int)((ushort)psVar12[0x16] >> 0xb & 7)) {
              if ((psVar12[0x16] & 0x7ffU) <
                  (*(ushort *)(lVar14 + (ulonglong)uVar8 + 4 + (longlong)iStack_f4 * 2) & 0x7ff)) {
                uVar7 = psVar12[0x15];
                lVar16 = *(longlong *)(psVar12 + 4);
                *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100917;
                func_0x((ulonglong)uVar7 + lVar16,0x1a);
              }
              iStack_f4 = iVar9 + 1;
            }
          }
          break;
        }
        if (uStack_104 < 0x400) break;
        *puVar20 = *puVar20 | 1;
        uVar8 = psVar12[0xe] - 1;
        psVar12[0xe] = uVar8;
        puVar25 = uStack_128;
      } while (uVar8 != 0);
    }
    if ((**(byte **)(psVar12 + 4) & 0x40) == 0) {
      *(undefined4 *)(psVar12 + 0x13) = 0;
    }
    else {
      *(undefined4 *)(psVar12 + 0x13) = *(undefined4 *)(psVar12 + 2);
      *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + 0xe;
      *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x10097d;
      uVar15 = func_0x(puVar20);
      *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x10098c;
      func_0x(uVar15,auStack_a8);
      *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100998;
      iVar9 = func_0x(auStack_a8);
      *(int *)(psVar12 + 2) = *(int *)(psVar12 + 2) + iVar9;
    }
    if ((*(ulonglong *)(psVar12 + 0xf) != 0) &&
       (*(ulonglong *)(psVar12 + 0xf) <
        (ulonglong)*(uint *)(psVar12 + 2) + *(longlong *)(psVar12 + 4))) {
      iVar10 = iVar10 + 1;
      uStack_154 = iVar10;
      *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1009d0;
      cVar6 = func_0x(0x1ec4ff0);
      if (cVar6 != '\0') {
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1009d9;
        lVar14 = func_0x();
        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
          *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x1009f3;
          cVar6 = func_0x(0x1ec4ff0);
          if (cVar6 == '\0') {
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100a0f;
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            *(undefined8 *)((longlong)auStack_190 + lVar13 + -8) = 0;
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100a33;
            (*_DAT_)(1,0x17b49fc,0x18d4ae8,0x886);
          }
        }
      }
      uVar15 = *(undefined8 *)(psVar12 + 4);
      *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100a41;
      func_0x(uVar15,0x12);
    }
    uStack_154 = iVar10;
    if (0x3f3b < *(int *)(psVar12 + 2) - 1U) {
      uStack_154 = iVar10 + 1;
      *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100a64;
      cVar6 = func_0x(0x1ec4ff0);
      if (cVar6 != '\0') {
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100a6d;
        lVar14 = func_0x();
        if ((lVar14 != 0) && (*(char *)(lVar14 + 0x499) != '\0')) {
          *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100a87;
          cVar6 = func_0x(0x1ec4ff0);
          if (cVar6 == '\0') {
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100aa3;
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            *(undefined8 *)((longlong)auStack_190 + lVar13 + -8) = 0;
            *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100ac7;
            (*_DAT_)(1,0x17b49fc,0x18d4ae8,0x88b);
          }
        }
      }
      uVar15 = *(undefined8 *)(psVar12 + 4);
      *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100ad5;
      func_0x(uVar15,5);
      uStack_154 = iVar10 + 1;
    }
  }
LAB_:
  sStack_100 = -*(short *)puVar11;
  if ((*(byte *)((longlong)puVar11 + 6) & 0x10) == 0) {
LAB_:
    uVar19 = (uint)sStack_100;
    if ((ushort)psVar12[0xe] < uVar19) {
      uStack_158 = 0;
      puVar24 = *(uint **)(psVar12 + 4);
      psVar12 = psStack_88;
    }
    else {
      plVar1 = (longlong *)(psVar12 + 4);
      lVar14 = *plVar1;
      lStack_a0 = (ulonglong)*(uint *)(psVar12 + 10) + lVar14;
      if (uVar19 == 1) {
        uVar23 = *(uint *)(psVar12 + 0xc);
      }
      else {
        uVar23 = *(ushort *)(lStack_a0 + 2 + (longlong)(int)(uVar19 - 2) * 2) & 0x7fff;
        lVar14 = *plVar1;
        param_5 = uStack_e0;
        apuStack_138[0] = puStack_98;
        puVar20 = puStack_90;
      }
      uVar22 = *(ushort *)(lStack_a0 + 2 + (longlong)(int)(uVar19 - 1) * 2) & 0x7fff;
      uStack_e8 = uVar19;
      if (((uVar23 < *(uint *)(puVar20 + 0xb)) || (uVar22 < uVar23)) ||
         (*(uint *)(puVar20 + 1) < uVar22)) {
        *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100bef;
        func_0x(lVar14,7);
      }
      puVar24 = (uint *)((ulonglong)uVar23 + *plVar1);
      psVar12 = psStack_88;
      puVar11 = apuStack_138[0];
      uStack_158 = uVar22 - uVar23;
    }
  }
  else {
    pbVar17 = *(byte **)(psVar12 + 4);
    if ((*pbVar17 & 0x10) == 0) {
      bStack_146 = *pbVar17 & 0xe;
      uVar19 = 1 << bStack_146 & 0x1105;
      uStack_f0 = (uint)(uVar19 == 0);
      if (uVar19 == 0) goto LAB_;
    }
    else if (((int)*puVar11 < (int)*(uint *)(psVar12 + 8)) &&
            (*(ushort *)(puVar11 + 1) <= *(ushort *)(pbVar17 + *(uint *)(psVar12 + 8)))) {
      uStack_f0 = 1;
      goto LAB_;
    }
    puVar24 = *(uint **)(puVar11 + 2) + 1;
    psVar12 = psStack_88;
    uStack_158 = **(uint **)(puVar11 + 2);
  }
LAB_:
  if (puVar24 == (uint *)0x0) {
    param_5 = param_5 | 8;
  }
  else {
    *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100cf7;
    iVar10 = func_0x(psVar12,puVar11);
    if (iVar10 == 0) {
      param_5 = param_5 | 0x200;
    }
  }
  *(undefined8 *)((longlong)auStack_1c0 + lVar13) = 0x100d24;
  lVar16 = func_0x();
  lVar16 = -lVar16;
  lVar14 = (longlong)&uStack_158 + lVar16 + lVar13;
  *(undefined8 *)((longlong)auStack_1c0 + lVar16 + lVar13) = 0x100d3a;
  func_0x(lVar14);
  pcVar2 = *(code **)(*param_3 + 8);
  *(undefined8 *)((longlong)auStack_1c0 + lVar16 + lVar13) = 0x100d43;
  (*pcVar2)(param_3);
  *(undefined8 **)((longlong)alStack_168 + lVar16 + lVar13) = &uStack_128;
  *(undefined4 *)((longlong)auStack_170 + lVar16 + lVar13) = 0;
  *(longlong **)((longlong)&plStack_178 + lVar16 + lVar13) = param_6;
  *(uint *)((longlong)auStack_180 + lVar16 + lVar13) = param_5;
  uVar18 = uStack_80;
  *(ulonglong *)((longlong)&puStack_188 + lVar16 + lVar13) = uStack_80;
  *(uint *)((longlong)auStack_190 + lVar16 + lVar13) = uStack_158;
  *(longlong *)((longlong)auStack_190 + lVar16 + lVar13 + -8) = lVar14;
  uVar5 = uStack_70;
  lVar14 = lStack_78;
  iVar10 = iStack_dc;
  uVar15 = *(undefined8 *)(lStack_78 + 0x1e8);
  *(undefined8 *)((longlong)auStack_1c0 + lVar16 + lVar13) = 0x100da6;
  uStack_144 = func_0x(lVar14,uVar5,uVar15,iVar10);
  lVar14 = *param_6;
  if (bStack_150 == 0) {
    *(int *)((longlong)param_3 + 0xc) = *(int *)((longlong)param_3 + 0xc) + 1;
    *(longlong **)(lVar14 + 0x150) = param_3;
    *(undefined4 *)(lVar14 + 0x158) = 2;
  }
  else {
    *(longlong **)(lVar14 + 0x38) = param_3;
    *(undefined4 *)(lVar14 + 0x40) = 2;
    *(ulonglong *)(lVar14 + 0x48) = uVar18;
  }
  lVar21 = (ulonglong)*_DAT_ +
           *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
  lVar14 = *(longlong *)(lVar21 + 0x100);
  if (lVar14 == 0) {
    *(undefined8 *)((longlong)auStack_1c0 + lVar16 + lVar13) = 0x100e09;
    (*_DAT_)();
    lVar14 = *(longlong *)(lVar21 + 0x100);
  }
  if (*(int *)(lVar14 + 0x22c) != 0) {
    *(undefined8 *)((longlong)auStack_1c0 + lVar16 + lVar13) = 0x100e1f;
    (*_DAT_)();
  }
  uVar18 = uStack_30 ^ (ulonglong)&uStack_158;
  *(undefined8 *)((longlong)auStack_1c0 + lVar16 + lVar13) = 0x100e31;
  func_0x(uVar18);
  return;
}

