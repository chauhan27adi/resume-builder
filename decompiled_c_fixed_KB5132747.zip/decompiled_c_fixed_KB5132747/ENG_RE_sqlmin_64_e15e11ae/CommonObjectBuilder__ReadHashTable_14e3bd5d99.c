
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,int *param_2,longlong *param_3,longlong *param_4,int *param_5,
                 longlong *param_6,int *param_7,int *param_8)

{
  longlong lVar1;
  ulonglong uVar2;
  int aiStackX_10 [2];
  
  aiStackX_10[0] = 0;
  if (*param_2 != 2) {
    (*_DAT_)(1,0x13d2ff0,0x139b758,0xb9,0);
  }
  *param_8 = 0;
  if (param_2[5] != 0) {
    uVar2 = (ulonglong)(uint)param_2[1] * (ulonglong)(uint)param_2[2];
    if (0xffffffff < uVar2) {
      uVar2 = 0xffffffff;
      (*_DAT_)(0x161,0x51,0x16,3);
    }
    *param_5 = (int)uVar2;
    lVar1 = (*_DAT_)(uVar2 & 0xffffffff,param_1,0x1257098,0xc6,5);
    if (*param_4 != lVar1) {
      (*_DAT_)(*param_4,0);
    }
    *param_4 = lVar1;
    (**(code **)(*param_3 + 8))(param_3,lVar1,*param_5,aiStackX_10);
    if (aiStackX_10[0] != *param_5) {
      (*_DAT_)(1,0x13d3028,0x139b758,0xcd,0);
    }
    *param_8 = *param_8 + aiStackX_10[0];
    uVar2 = (ulonglong)(uint)param_2[6] * (ulonglong)(uint)param_2[4];
    if (0xffffffff < uVar2) {
      uVar2 = 0xffffffff;
      (*_DAT_)(0x161,0x51,0x16,4);
    }
    *param_7 = (int)uVar2;
    lVar1 = (*_DAT_)(uVar2 & 0xffffffff,param_1,0x1257098,0xd6,5);
    if (*param_6 != lVar1) {
      (*_DAT_)(*param_6,0);
    }
    *param_6 = lVar1;
    (**(code **)(*param_3 + 8))(param_3,lVar1,*param_7,aiStackX_10);
    if (aiStackX_10[0] != *param_7) {
      (*_DAT_)(1,0x13d3048,0x139b758,0xdc,0);
    }
    *param_8 = *param_8 + aiStackX_10[0];
    return;
  }
  if ((param_2[2] != 0) || (param_2[6] != 0)) {
    (*_DAT_)(0x161,0x51,0x16,8);
  }
  *param_7 = 0;
  *param_5 = 0;
  if (*param_4 != 0) {
    (*_DAT_)(*param_4,0);
  }
  *param_4 = 0;
  if (*param_6 != 0) {
    (*_DAT_)(*param_6,0);
  }
  *param_6 = 0;
  return;
}

