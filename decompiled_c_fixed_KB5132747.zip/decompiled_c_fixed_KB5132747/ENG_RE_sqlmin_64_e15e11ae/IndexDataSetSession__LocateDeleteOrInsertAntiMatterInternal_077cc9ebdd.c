
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,ushort **param_2,undefined8 param_3)

{
  byte *pbVar1;
  short *psVar2;
  uint *puVar3;
  undefined4 uVar4;
  code *pcVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined8 uVar8;
  uint6 uVar9;
  bool bVar10;
  bool bVar11;
  char cVar12;
  undefined2 uVar13;
  int iVar14;
  undefined4 uVar15;
  longlong lVar16;
  longlong lVar17;
  undefined4 *puVar18;
  undefined8 uVar19;
  undefined8 *puVar20;
  short *psVar21;
  longlong lVar22;
  byte bVar23;
  byte bVar24;
  uint uVar25;
  undefined8 *puVar26;
  uint uVar27;
  int iVar28;
  byte *pbVar29;
  int *piVar30;
  undefined8 unaff_RBX;
  ushort *puVar31;
  uint *puVar32;
  undefined *puVar33;
  undefined *puVar34;
  uint uVar35;
  uint uVar36;
  ushort *puVar37;
  ulonglong uVar38;
  byte *pbVar39;
  ulonglong uVar40;
  uint uVar41;
  ushort *puVar42;
  longlong lVar43;
  ushort uVar44;
  ushort uVar45;
  undefined8 *puVar47;
  undefined uVar48;
  ushort *puVar49;
  ulonglong uVar50;
  longlong unaff_GS_OFFSET;
  bool bVar51;
  longlong *aplStackX_8 [2];
  ushort uStackX_18;
  ushort uStackX_1a;
  uint uStackX_1c;
  byte *pbStackX_20;
  undefined8 uStack_40;
  ulonglong uVar46;
  
  uStack_40 = 0x100016;
  lVar16 = func_0x();
  lVar16 = -lVar16;
  puVar33 = &stack0xffffffffffffffc8 + lVar16;
  puVar34 = &stack0xffffffffffffffc8 + lVar16;
  psVar2 = (short *)((longlong)&uStackX_18 + lVar16);
  *(undefined8 *)(&stack0x00000130 + lVar16) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000023e0 + lVar16) = unaff_RBX;
  *(ulonglong *)(&stack0x00002378 + lVar16) = _DAT_ ^ (ulonglong)psVar2;
  *(undefined8 *)(&stack0x00000110 + lVar16) = param_3;
  *(ushort ***)(&stack0x00000068 + lVar16) = param_2;
  *(longlong **)(&stack0x00000058 + lVar16) = param_1;
  *(longlong **)(&stack0x00000120 + lVar16) = param_1;
  *psVar2 = -1;
  puVar42 = (ushort *)0x0;
  *(undefined8 *)((longlong)&pbStackX_20 + lVar16) = 0;
  *(undefined4 *)((longlong)&uStackX_18 + lVar16 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar16) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar16) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar16) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100094;
  func_0x(&stack0x000003d8 + lVar16,0,0x1f9e);
  *(undefined8 *)(&stack0x00000088 + lVar16) = 1;
  *(ushort **)(&stack0x00000118 + lVar16) = *param_2;
  lVar22 = param_1[2];
  *(longlong *)(&stack0x000000d8 + lVar16) = lVar22;
  lVar17 = *(longlong *)(lVar22 + 8);
  bVar24 = *(byte *)(lVar17 + 0x108);
  uVar48 = 0;
  if (((bVar24 & 0x40) == 0) || (param_1[0x8c] != 0)) {
    (&stack0x00000050)[lVar16] = 0;
  }
  else {
    (&stack0x00000050)[lVar16] = 1;
    bVar23 = *(byte *)(lVar17 + 0x109) & 4;
    if ((((((bVar23 != 0) && ((bVar24 & 2) != 0)) && (0xdac01 < *(uint *)(lVar17 + 0xf4))) &&
         (*(uint *)(lVar17 + 0xf4) != 0xdacfe)) ||
        (((*(byte *)(lVar17 + 0x41) & 0x20) == 0 && (bVar23 == 0)))) && ((DAT_ & 0x10) == 0)
       ) {
      lVar17 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar17 != 0) && (lVar17 = **(longlong **)(lVar17 + 0x38), lVar17 != 0)) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100150;
        iVar14 = (*_DAT_)(lVar17,0xfc);
        if (iVar14 != 0) goto LAB_;
      }
      pcVar5 = *(code **)(*param_1 + 0x230);
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100166;
      (*pcVar5)(param_1,param_2,param_3);
      goto LAB_;
    }
  }
LAB_:
  bVar24 = (*(byte *)(*(longlong *)(lVar22 + 8) + 0x106) & 1) + 2;
  iVar14 = *(int *)(*(longlong *)(lVar22 + 8) + 0x100);
  bVar10 = false;
  if ((iVar14 != 0) && (iVar14 != 3 && iVar14 != 4)) {
    bVar10 = true;
  }
  puVar49 = *param_2;
  if ((*(byte *)(puVar49 + 0x1c) & 0x20) == 0) {
    uVar25 = *(uint *)((longlong)param_2 + 0x14) & 0x10;
    *(undefined8 *)(&stack0x00000090 + lVar16) = 0;
    if (bVar10) {
      puVar31 = puVar42;
      if (uVar25 != 0) {
        puVar31 = puVar49;
      }
      uVar25 = -*(int *)(puVar31 + 8);
      *(uint *)(&stack0x0000009c + lVar16) = uVar25;
      uVar15 = *(undefined4 *)(puVar31 + 0xc);
      uVar4 = *(undefined4 *)(puVar31 + 10);
      *(undefined2 *)(&stack0xfffffffffffffff0 + lVar16) = 1;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) = uVar15;
      if ((bVar24 & 1) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1021a1;
        func_0x(psVar2,&stack0x000003d8 + lVar16,0x1f9e,uVar4);
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10219a;
        func_0x();
      }
      puVar33 = &stack0xffffffffffffffc8 + lVar16;
      if (uVar25 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1021cb;
        lVar22 = func_0x();
        lVar22 = -lVar22;
        puVar33 = &stack0xffffffffffffffc8 + lVar22 + lVar16;
        puVar42 = (ushort *)((longlong)&uStackX_18 + lVar22 + lVar16);
        *(ushort **)(&stack0x00000090 + lVar16) = puVar42;
        *(undefined8 *)((longlong)&uStack_40 + lVar22 + lVar16) = 0x1021e1;
        func_0x(puVar42);
      }
      uVar44 = (*param_2)[0x31];
      *(undefined8 *)(&stack0x000000a8 + lVar16) = 0;
      puVar32 = (uint *)param_2[1];
      if (uVar44 != 0) {
        *(ulonglong *)(&stack0x000000a0 + lVar16) = (ulonglong)uVar44;
        lVar22 = *(longlong *)(&stack0x00000090 + lVar16);
        lVar17 = *(longlong *)(&stack0x00000068 + lVar16);
        do {
          uVar25 = *puVar32;
          *(undefined8 *)(puVar33 + -8) = 0x102223;
          func_0x(lVar17,puVar32,&stack0x00000071 + lVar16);
          if ((&stack0x00000071)[lVar16] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar32 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar32[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar33 + -8) = 0x10250c;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar33 + -8) = 0x10251e;
            func_0x(psVar2,puVar32,0,0);
            if ((int)uVar25 < 0) {
              puVar3 = (uint *)((longlong)(int)~uVar25 * 0x20 + 0xc + lVar22);
              *puVar3 = *puVar3 | 2;
            }
          }
          else {
            if (*(short *)(puVar32 + 1) != 0) {
              if (*psVar2 == 0) {
                *(undefined8 *)(puVar33 + -8) = 0x102247;
                func_0x();
              }
              else {
                *(undefined8 *)(puVar33 + -8) = 0x10224e;
                func_0x((longlong)&uStackX_18 + lVar16 + 2,puVar32);
              }
            }
            *(undefined8 *)(puVar33 + -8) = 0x102260;
            func_0x(lVar17,puVar32,&stack0x000000a8 + lVar16);
            cVar12 = *(char *)(puVar32 + 0x10);
            uVar36 = 0;
            if ((cVar12 == '\x01') || (cVar12 == '\x02')) {
              lVar43 = *(longlong *)(&stack0x000000a8 + lVar16);
              if ((puVar32[0x10] >> 8 & 1) != 0) {
                iVar14 = 0;
                if (((puVar32[0x10] >> 0xf & 1) == 0) || ((*(byte *)(lVar17 + 0x14) & 8) == 0)) {
                  if ((*(byte *)(*(longlong *)(puVar32 + 0x12) + 0x2a) & 0x10) == 0) {
                    lVar17 = *(longlong *)(lVar17 + 0x18);
                  }
                  else {
                    lVar17 = *(longlong *)(lVar17 + 0x20);
                  }
                  uVar25 = *(uint *)(*(longlong *)(*(longlong *)(puVar32 + 0x12) + 0x18) + lVar17);
                }
                else {
                  uVar25 = *(uint *)(*(longlong *)(lVar17 + 0x38) + (ulonglong)puVar32[0xe] * 8);
                }
                uVar36 = (uint)*(ushort *)(puVar32 + 0xf);
                if (uVar25 < uVar36) {
                  iVar14 = uVar36 - uVar25;
                }
                else if (uVar36 < uVar25) {
                  *(undefined8 *)(puVar33 + -8) = 0x10243c;
                  (*_DAT_)(6,0x5c,0x16);
                }
                uVar48 = *(undefined *)(*(longlong *)(puVar32 + 0x12) + 0x24);
                lVar17 = (longlong)(int)*puVar32 + *(longlong *)((longlong)&pbStackX_20 + lVar16);
                if ((lVar43 != 0) && (uVar25 != 0)) {
                  *(undefined8 *)(puVar33 + -8) = 0x102463;
                  func_0x(lVar17,lVar43,uVar25);
                }
                if (iVar14 != 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x102477;
                  func_0x((ulonglong)uVar25 + lVar17,uVar48,iVar14);
                }
                goto LAB_;
              }
              uVar25 = *puVar32;
              lVar6 = *(longlong *)((longlong)&pbStackX_20 + lVar16);
              uVar13 = *(undefined2 *)(puVar32 + 0xf);
              *(undefined8 *)(puVar33 + -8) = 0x1023d6;
              func_0x((int)uVar25 + lVar6,lVar43,uVar13);
            }
            else if ((cVar12 == '\x03') || (cVar12 == '\x04')) {
              uVar41 = puVar32[0x10];
              piVar30 = *(int **)(&stack0x000000a8 + lVar16);
              if (((uVar41 >> 0xd & 1) == 0) || (*piVar30 != 0)) {
                if (((uVar41 & 0x8000) == 0) || ((*(byte *)(lVar17 + 0x14) & 8) == 0)) {
                  lVar43 = *(longlong *)(puVar32 + 0x12);
                  if ((uVar41 >> 8 & 1) == 0) {
                    uVar36 = (uint)*(ushort *)(lVar43 + 2);
                  }
                  else if ((*(byte *)(lVar43 + 0x2a) & 0x10) == 0) {
                    uVar36 = *(uint *)(*(longlong *)(lVar43 + 0x18) + *(longlong *)(lVar17 + 0x18));
                  }
                  else {
                    uVar36 = *(uint *)(*(longlong *)(lVar43 + 0x18) + *(longlong *)(lVar17 + 0x20));
                  }
                }
                else {
                  uVar36 = *(uint *)(*(longlong *)(lVar17 + 0x38) + (ulonglong)puVar32[0xe] * 8);
                }
              }
              if (*(ushort *)(puVar32 + 0xf) < uVar36) {
                *(undefined8 *)(puVar33 + -8) = 0x102385;
                (*_DAT_)(6,0x52,0x16);
                piVar30 = *(int **)(&stack0x000000a8 + lVar16);
              }
              *(undefined4 *)(puVar33 + 0x28) = 0;
              *(uint **)(puVar33 + 0x20) = puVar32;
              *(undefined8 *)(puVar33 + -8) = 0x1023ad;
              func_0x((longlong)(int)~uVar25 * 0x20 + lVar22,piVar30,uVar36);
LAB_:
              lVar17 = *(longlong *)(&stack0x00000068 + lVar16);
            }
            else if (cVar12 == '\b') {
              if (*psVar2 == 0) {
                uVar19 = *(undefined8 *)(&stack0x000000a8 + lVar16);
                *(undefined8 *)(puVar33 + -8) = 0x1022d8;
                func_0x(psVar2,puVar32,uVar19);
              }
              else {
                *(undefined4 *)(puVar33 + 0x28) = 0;
                *(uint **)(puVar33 + 0x20) = puVar32;
                uVar19 = *(undefined8 *)(&stack0x000000a8 + lVar16);
                *(undefined8 *)(puVar33 + -8) = 0x102305;
                func_0x((longlong)(int)~uVar25 * 0x20 + lVar22,uVar19,1);
              }
            }
            else {
              *(undefined8 *)(puVar33 + 0x20) = 0x15b3c10;
              *(undefined8 *)(puVar33 + -8) = 0x1022b6;
              (*_DAT_)(1,0x19b9fa0,0x19e6968);
            }
          }
          puVar32 = puVar32 + 0x14;
          plVar7 = (longlong *)(&stack0x000000a0 + lVar16);
          *plVar7 = *plVar7 + -1;
        } while (*plVar7 != 0);
        uVar25 = *(uint *)(&stack0x0000009c + lVar16);
        puVar42 = *(ushort **)(&stack0x00000090 + lVar16);
      }
      puVar49 = (ushort *)0x0;
      if (uVar25 != 0) {
        if (*psVar2 == 0) {
LAB_:
          uVar40 = (ulonglong)uVar25;
          uVar36 = uVar25 - 1;
          if (*(int *)(puVar42 + (ulonglong)uVar36 * 0x10 + 4) == 0) goto code_r0x001024d4;
          *(ushort *)(&stack0x00000034 + lVar16) = (ushort)uVar25;
          iVar14 = *(int *)(&stack0x0000002c + lVar16) + 2 + uVar25 * 2;
          *(int *)(&stack0x00000030 + lVar16) = iVar14;
          *(int *)((longlong)&uStackX_18 + lVar16 + 4) = iVar14;
          **(byte **)((longlong)&pbStackX_20 + lVar16) =
               **(byte **)((longlong)&pbStackX_20 + lVar16) | 0x20;
          uVar36 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
          if (uVar36 < 0x1f7d) {
            puVar49 = (ushort *)
                      ((ulonglong)*(uint *)(&stack0x0000002c + lVar16) +
                      *(longlong *)((longlong)&pbStackX_20 + lVar16));
            *puVar49 = (ushort)uVar25;
            uVar36 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
          }
          if (uVar25 != 0) {
            puVar32 = (uint *)(puVar42 + 6);
            do {
              puVar49 = puVar49 + 1;
              uVar50 = (ulonglong)uVar36;
              lVar22 = *(longlong *)((longlong)&pbStackX_20 + lVar16);
              uVar25 = puVar32[-1];
              uVar36 = uVar36 + uVar25;
              *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar36;
              if (uVar36 < 0x1f7d) {
                *puVar49 = (ushort)((*puVar32 & 1) << 0xf) | (ushort)uVar36 & 0x7fff;
                uVar19 = *(undefined8 *)(puVar32 + -3);
                *(undefined8 *)(puVar33 + -8) = 0x1025b9;
                func_0x(uVar50 + lVar22,uVar25,uVar19,uVar25);
                uVar36 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
              }
              puVar32 = puVar32 + 8;
              uVar40 = uVar40 - 1;
            } while (uVar40 != 0);
          }
          *(uint *)(&stack0x000000c8 + lVar16) = uVar36;
          goto LAB_;
        }
        *(undefined **)(puVar33 + 0x28) = &stack0x000000c8 + lVar16;
        *(ushort **)(puVar33 + 0x20) = puVar42;
        *(undefined8 *)(puVar33 + -8) = 0x1025fb;
        func_0x((longlong)&uStackX_18 + lVar16 + 2,0x1f9e,0x1f7c,uVar25);
      }
    }
    else {
      *psVar2 = 0;
      puVar31 = puVar42;
      if (uVar25 != 0) {
        puVar31 = puVar49;
      }
      uVar25 = -*(int *)(puVar31 + 8);
      *(uint *)(&stack0x0000009c + lVar16) = uVar25;
      if ((bVar24 & 1) == 0) {
        uVar48 = 6;
      }
      iVar14 = 4;
      if ((bVar24 & 1) == 0) {
        iVar14 = 1;
      }
      iVar28 = *(int *)(puVar31 + 10);
      (&stack0xfffffffffffffff0)[lVar16] = uVar48;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) = *(undefined4 *)(puVar31 + 0xc);
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100219;
      func_0x
                ((longlong)&uStackX_18 + lVar16 + 2,&stack0x000003d8 + lVar16,0x1f9e,iVar28 - iVar14
                );
      if (uVar25 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100241;
        lVar17 = func_0x();
        lVar17 = -lVar17;
        puVar33 = &stack0xffffffffffffffc8 + lVar17 + lVar16;
        lVar22 = (longlong)&uStackX_18 + lVar17 + lVar16;
        *(longlong *)(&stack0x00000090 + lVar16) = lVar22;
        *(undefined8 *)((longlong)&uStack_40 + lVar17 + lVar16) = 0x100257;
        func_0x(lVar22);
      }
      uVar44 = (*param_2)[0x31];
      *(uint *)(&stack0x000000c4 + lVar16) = (uint)uVar44;
      *(undefined8 *)(&stack0x000000b8 + lVar16) = 0;
      *(undefined4 *)(&stack0x000000b0 + lVar16) = 0;
      puVar32 = (uint *)param_2[1];
      *(uint **)(&stack0x00000060 + lVar16) = puVar32;
      if (uVar44 != 0) {
        do {
          uVar25 = *puVar32;
          *(undefined8 *)(puVar33 + -8) = 0x1002a2;
          func_0x(param_2,puVar32,&stack0x00000070 + lVar16);
          if ((&stack0x00000070)[lVar16] == '\x03') {
            if (((*(ushort *)(*(longlong *)(puVar32 + 0x12) + 0xc) & 0x400) == 0) &&
               ((puVar32[0x10] & 0x4000) == 0)) {
              *(undefined8 *)(puVar33 + -8) = 0x102084;
              (*_DAT_)(6,0x51,0x10,3);
            }
            *(undefined8 *)(puVar33 + -8) = 0x102096;
            func_0x((longlong)&uStackX_18 + lVar16 + 2,puVar32,0,0);
            if ((int)uVar25 < 0) {
              puVar3 = (uint *)((longlong)(int)~uVar25 * 0x20 + 0xc +
                               *(longlong *)(&stack0x00000090 + lVar16));
              *puVar3 = *puVar3 | 2;
            }
          }
          else {
            if (*(short *)(puVar32 + 1) != 0) {
              *(undefined8 *)(puVar33 + -8) = 0x1002bf;
              func_0x((longlong)&uStackX_18 + lVar16 + 2,puVar32);
            }
            *(undefined8 *)(puVar33 + -8) = 0x1002d1;
            func_0x(param_2,puVar32,&stack0x000000b8 + lVar16);
            cVar12 = *(char *)(puVar32 + 0x10);
            uVar36 = 0;
            if ((cVar12 == '\x01') || (cVar12 == '\x02')) {
              lVar22 = *(longlong *)(&stack0x000000b8 + lVar16);
              if ((puVar32[0x10] >> 8 & 1) == 0) {
                uVar25 = *puVar32;
                lVar17 = *(longlong *)((longlong)&pbStackX_20 + lVar16);
                uVar13 = *(undefined2 *)(puVar32 + 0xf);
                *(undefined8 *)(puVar33 + -8) = 0x101fa2;
                func_0x((int)uVar25 + lVar17,lVar22,uVar13);
                goto LAB_;
              }
              if (((puVar32[0x10] >> 0xf & 1) == 0) ||
                 ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                if ((*(byte *)(*(longlong *)(puVar32 + 0x12) + 0x2a) & 0x10) == 0) {
                  puVar49 = param_2[3];
                }
                else {
                  puVar49 = param_2[4];
                }
                uVar25 = *(uint *)(*(longlong *)(*(longlong *)(puVar32 + 0x12) + 0x18) +
                                  (longlong)puVar49);
              }
              else {
                uVar25 = *(uint *)(param_2[7] + (ulonglong)puVar32[0xe] * 4);
              }
              uVar41 = (uint)*(ushort *)(puVar32 + 0xf);
              if (uVar25 < uVar41) {
                uVar36 = uVar41 - uVar25;
              }
              else if (uVar41 < uVar25) {
                *(undefined8 *)(puVar33 + -8) = 0x10200b;
                (*_DAT_)(6,0x5c,0x16);
              }
              uVar48 = *(undefined *)(*(longlong *)(puVar32 + 0x12) + 0x24);
              lVar17 = (longlong)**(int **)(&stack0x00000060 + lVar16) +
                       *(longlong *)((longlong)&pbStackX_20 + lVar16);
              if ((lVar22 != 0) && (uVar25 != 0)) {
                *(undefined8 *)(puVar33 + -8) = 0x102036;
                func_0x(lVar17,lVar22,uVar25);
              }
              if (uVar36 != 0) {
                *(undefined8 *)(puVar33 + -8) = 0x10204a;
                func_0x((ulonglong)uVar25 + lVar17,uVar48,uVar36);
              }
LAB_:
              puVar32 = *(uint **)(&stack0x00000060 + lVar16);
            }
            else {
              if ((cVar12 != '\x03') && (cVar12 != '\x04')) {
                if (cVar12 != '\b') {
                  *(undefined8 *)(puVar33 + 0x20) = 0x15b3c10;
                  *(undefined8 *)(puVar33 + -8) = 0x100328;
                  (*_DAT_)(1,0x19b9fa0,0x19e6968);
                  goto LAB_;
                }
                *(char **)(&stack0x000000a0 + lVar16) = *(char **)(&stack0x000000b8 + lVar16);
                uVar25 = *puVar32;
                if (-1 < (int)uVar25) {
                  bVar24 = (byte)*(ushort *)((longlong)puVar32 + 6);
                  if ((*(ushort *)((longlong)puVar32 + 6) & 8) == 0) {
                    if (*(int *)((longlong)&uStackX_18 + lVar16 + 4) == 0) {
                      *(undefined2 *)((longlong)&uStackX_18 + lVar16 + 2) = 0;
                      uVar25 = *(uint *)(&stack0x00000028 + lVar16);
                      *(uint *)(&stack0x0000002c + lVar16) = uVar25;
                      if ((**(byte **)((longlong)&pbStackX_20 + lVar16) & 0x10) != 0) {
                        *(uint *)(&stack0x0000002c + lVar16) =
                             uVar25 + 2 +
                             (*(ushort *)(*(byte **)((longlong)&pbStackX_20 + lVar16) + uVar25) + 7
                             >> 3);
                      }
                      if ((**(byte **)((longlong)&pbStackX_20 + lVar16) & 0x20) == 0) {
                        uVar25 = *(uint *)(&stack0x0000002c + lVar16);
                        *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25;
                        *(undefined2 *)(&stack0x00000034 + lVar16) = 0;
                        *(uint *)(&stack0x00000030 + lVar16) = uVar25;
                      }
                      else {
                        puVar49 = (ushort *)
                                  (*(byte **)((longlong)&pbStackX_20 + lVar16) +
                                  *(uint *)(&stack0x0000002c + lVar16));
                        uVar44 = *puVar49;
                        *(ushort *)(&stack0x00000034 + lVar16) = uVar44;
                        if (uVar44 == 0) {
                          *(undefined8 *)(puVar33 + -8) = 0x100429;
                          cVar12 = func_0x(0x1f48ca0);
                          if (cVar12 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100432;
                            lVar22 = func_0x();
                            if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x10044c;
                              cVar12 = func_0x(0x1f48ca0);
                              if (cVar12 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x100468;
                                (*_DAT_)(0x22,0x44,0x15,0x3eb);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x10048c;
                                (*_DAT_)(1,0x18386ac,0x1958798,0x80f);
                              }
                            }
                          }
                          uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                          *(undefined8 *)(puVar33 + -8) = 0x10049a;
                          func_0x(uVar19,3);
                          uVar44 = *(ushort *)(&stack0x00000034 + lVar16);
                        }
                        uVar36 = *(int *)(&stack0x0000002c + lVar16) + 2 + (uint)uVar44 * 2;
                        *(uint *)(&stack0x00000030 + lVar16) = uVar36;
                        if (0x1f9e < uVar36) {
                          *(undefined8 *)(puVar33 + -8) = 0x1004ca;
                          cVar12 = func_0x(0x1f48ca0);
                          if (cVar12 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x1004d3;
                            lVar22 = func_0x();
                            if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x1004ed;
                              cVar12 = func_0x(0x1f48ca0);
                              if (cVar12 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x100509;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x10052d;
                                (*_DAT_)(1,0x18386ac,0x1958798,0x816);
                              }
                            }
                          }
                          uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                          *(undefined8 *)(puVar33 + -8) = 0x10053b;
                          func_0x(uVar19,4);
                          uVar44 = *(ushort *)(&stack0x00000034 + lVar16);
                          uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                        }
                        uVar40 = (ulonglong)uVar44;
                        uVar25 = puVar49[uVar40] & 0x7fff;
                        *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25;
                        if (uVar25 < uVar36) {
                          *(undefined8 *)(puVar33 + -8) = 0x100569;
                          cVar12 = func_0x(0x1f48ca0);
                          if (cVar12 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100572;
                            lVar22 = func_0x();
                            if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x10058c;
                              cVar12 = func_0x(0x1f48ca0);
                              if (cVar12 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x1005a8;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x1005cc;
                                (*_DAT_)(1,0x18386ac,0x1958798,0x81d);
                              }
                            }
                          }
                          uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                          *(undefined8 *)(puVar33 + -8) = 0x1005da;
                          func_0x(uVar19,4);
                          uVar40 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar16);
                          uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                          uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                        }
                        puVar37 = puVar42;
                        puVar31 = puVar49;
                        if ((short)uVar40 != 0) {
                          do {
                            uVar41 = puVar31[1] & 0x7fff;
                            if ((uVar41 < uVar36) || (uVar25 < uVar41)) {
                              *(undefined8 *)(puVar33 + -8) = 0x100620;
                              cVar12 = func_0x(0x1f48ca0);
                              if (cVar12 != '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x100629;
                                lVar22 = func_0x();
                                if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                                  *(undefined8 *)(puVar33 + -8) = 0x100643;
                                  cVar12 = func_0x(0x1f48ca0);
                                  if (cVar12 == '\0') {
                                    *(undefined8 *)(puVar33 + -8) = 0x10065f;
                                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                  }
                                  else {
                                    *(undefined8 *)(puVar33 + 0x20) = 0;
                                    *(undefined8 *)(puVar33 + -8) = 0x100683;
                                    (*_DAT_)(1,0x18386ac,0x1958798,0x82a);
                                  }
                                }
                              }
                              uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                              *(undefined8 *)(puVar33 + -8) = 0x100691;
                              func_0x(uVar19,4);
                              uVar40 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar16);
                              uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                            }
                            uVar35 = (int)puVar37 + 1;
                            puVar37 = (ushort *)(ulonglong)uVar35;
                            puVar31 = puVar31 + 1;
                            uVar36 = uVar41;
                          } while ((int)uVar35 < (int)uVar40);
                          uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                        }
                        while ((short)puVar49[(ulonglong)((int)uVar40 - 1) + 1] < 0) {
                          lVar22 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16) +
                                   *(longlong *)((longlong)&pbStackX_20 + lVar16);
                          uVar41 = uVar36;
                          if ((int)uVar40 != 1) {
                            uVar41 = *(ushort *)(lVar22 + -2 + uVar40 * 2) & 0x7fff;
                          }
                          uVar35 = *(ushort *)(lVar22 + uVar40 * 2) & 0x7fff;
                          if (((uVar41 < uVar36) || (uVar35 < uVar41)) || (uVar25 < uVar35)) {
                            uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                            *(undefined8 *)(puVar33 + -8) = 0x10070f;
                            func_0x(uVar19,7);
                            uVar40 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar16);
                            uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                            uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                          }
                          if ((uVar41 < uVar36) || (uVar25 < uVar41)) {
                            puVar32 = *(uint **)(&stack0x00000060 + lVar16);
                            goto LAB_;
                          }
                          uVar44 = *(ushort *)
                                    ((ulonglong)uVar41 +
                                    *(longlong *)((longlong)&pbStackX_20 + lVar16));
                          if (uVar44 == 5) {
                            puVar49 = (ushort *)((longlong)&uStackX_18 + lVar16 + 2);
                            *puVar49 = *puVar49 | 2;
                            *(short *)(&stack0x00000034 + lVar16) = (short)uVar40 + -1;
                            uVar50 = (ulonglong)(uVar41 & 0xffff);
                            *(short *)(&stack0x00000042 + lVar16) = (short)uVar41;
                            uVar40 = *(longlong *)((longlong)&pbStackX_20 + lVar16) + uVar50;
                            uVar44 = *(ushort *)(&stack0x00000044 + lVar16);
                            if ((*(ushort *)(uVar40 + 2) & 0x4000) == 0) {
                              uVar44 = uVar44 & 0xc7ff;
                            }
                            else {
                              uVar44 = uVar44 ^ (*(ushort *)(uVar40 + 2) ^ uVar44) & 0x3800;
                            }
                            *(ushort *)(&stack0x00000044 + lVar16) = uVar44;
                            uVar45 = (uVar44 ^ *(ushort *)(uVar40 + 2)) & 0x7ff ^ uVar44;
                            uVar46 = (ulonglong)uVar45;
                            *(ushort *)(&stack0x00000044 + lVar16) = uVar45;
                            uVar38 = (ulonglong)((uVar44 >> 0xb & 7) * 2) + 4 + uVar50 +
                                     (uVar46 & 0x7ff) * 2 +
                                     *(longlong *)((longlong)&pbStackX_20 + lVar16);
                            if (uVar38 < uVar40) {
                              *(undefined8 *)(puVar33 + -8) = 0x100802;
                              func_0x(uVar40,0x19);
                              uVar46 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar16);
                              uVar50 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar16);
                              uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                            }
                            if (uVar35 - uVar41 <
                                (((*(uint *)(&stack0x00000044 + lVar16) & 0x7ff) * 2 - (int)uVar50)
                                - *(int *)((longlong)&pbStackX_20 + lVar16)) + (int)uVar38) {
                              lVar22 = *(longlong *)((longlong)&pbStackX_20 + lVar16);
                              *(undefined8 *)(puVar33 + -8) = 0x100839;
                              func_0x(uVar50 + lVar22,0x19);
                              uVar46 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar16);
                              uVar50 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar16);
                              uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                            }
                            if (((uVar46 & 0x3800) != 0) &&
                               (puVar31 = (ushort *)
                                          (*(longlong *)((longlong)&pbStackX_20 + lVar16) + 4 +
                                          uVar50), puVar49 = puVar42, (uVar46 & 0x3800) != 0)) {
                              do {
                                if (((ushort)uVar46 & 0x7ff) < (*puVar31 & 0x7ff)) {
                                  lVar22 = *(longlong *)((longlong)&pbStackX_20 + lVar16);
                                  *(undefined8 *)(puVar33 + -8) = 0x100897;
                                  func_0x(uVar50 + lVar22,0x1a);
                                  uVar46 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar16);
                                  uVar50 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar16);
                                }
                                uVar25 = (int)puVar49 + 1;
                                puVar49 = (ushort *)(ulonglong)uVar25;
                                puVar31 = puVar31 + 1;
                              } while ((int)uVar25 <
                                       (int)(*(uint *)(&stack0x00000044 + lVar16) >> 0xb & 7));
                              uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                            }
                            break;
                          }
                          if (uVar44 < 0x400) break;
                          puVar31 = (ushort *)((longlong)&uStackX_18 + lVar16 + 2);
                          *puVar31 = *puVar31 | 1;
                          uVar44 = (short)uVar40 - 1;
                          uVar40 = (ulonglong)uVar44;
                          *(ushort *)(&stack0x00000034 + lVar16) = uVar44;
                          if (uVar44 == 0) break;
                        }
                        puVar32 = *(uint **)(&stack0x00000060 + lVar16);
                      }
                      if ((**(byte **)((longlong)&pbStackX_20 + lVar16) & 0x40) == 0) {
                        *(undefined4 *)(&stack0x0000003e + lVar16) = 0;
                      }
                      else {
                        *(uint *)(&stack0x0000003e + lVar16) = uVar25;
                        *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25 + 0xe;
                        *(undefined8 *)(puVar33 + -8) = 0x1008f6;
                        uVar19 = func_0x((longlong)&uStackX_18 + lVar16 + 2);
                        *(undefined8 *)(puVar33 + -8) = 0x100905;
                        func_0x(uVar19,&stack0x000000f8 + lVar16);
                        *(undefined8 *)(puVar33 + -8) = 0x100911;
                        iVar14 = func_0x(&stack0x000000f8 + lVar16);
                        uVar25 = *(int *)((longlong)&uStackX_18 + lVar16 + 4) + iVar14;
                        *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25;
                      }
                      if ((*(ulonglong *)(&stack0x00000036 + lVar16) != 0) &&
                         (*(ulonglong *)(&stack0x00000036 + lVar16) <
                          (ulonglong)uVar25 + *(longlong *)((longlong)&pbStackX_20 + lVar16))) {
                        *(undefined8 *)(puVar33 + -8) = 0x10094b;
                        cVar12 = func_0x(0x1f48ca0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x100954;
                          lVar22 = func_0x();
                          if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x10096e;
                            cVar12 = func_0x(0x1f48ca0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x10098a;
                              (*_DAT_)(0x22,0x44,0x15,0x3fa);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x1009ae;
                              (*_DAT_)(1,0x18386ac,0x1958798,0x886);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                        *(undefined8 *)(puVar33 + -8) = 0x1009bc;
                        func_0x(uVar19,0x12);
                        uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                      }
                      if (0x3f3b < uVar25 - 1) {
                        *(undefined8 *)(puVar33 + -8) = 0x1009d7;
                        cVar12 = func_0x(0x1f48ca0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1009e0;
                          lVar22 = func_0x();
                          if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x1009fa;
                            cVar12 = func_0x(0x1f48ca0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x100a16;
                              (*_DAT_)(0x22,0x44,0x15,0x3ed);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x100a3a;
                              (*_DAT_)(1,0x18386ac,0x1958798,0x88b);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                        *(undefined8 *)(puVar33 + -8) = 0x100a48;
                        func_0x(uVar19,5);
                      }
                    }
LAB_:
                    uVar36 = *puVar32;
                    uVar25 = uVar36 + 1;
                    uVar41 = *(uint *)(&stack0x00000028 + lVar16);
                    if (uVar41 < uVar25) {
                      *(undefined8 *)(puVar33 + -8) = 0x100a6b;
                      func_0x((longlong)&uStackX_18 + lVar16 + 2,0,uVar25 - uVar41);
                      if ((1 << (**(byte **)((longlong)&pbStackX_20 + lVar16) & 0xe) & 0x1105U) != 0
                         ) {
                        *(short *)(*(byte **)((longlong)&pbStackX_20 + lVar16) + 2) = (short)uVar25;
                      }
                      *(uint *)(&stack0x00000028 + lVar16) = uVar25;
                      uVar36 = *puVar32;
                    }
                    if (*(undefined **)(&stack0x000000a0 + lVar16) != (undefined *)0x0) {
                      *(undefined *)
                       ((longlong)(int)uVar36 + *(longlong *)((longlong)&pbStackX_20 + lVar16)) =
                           **(undefined **)(&stack0x000000a0 + lVar16);
                    }
                  }
                  else {
                    cVar12 = **(char **)(&stack0x000000b8 + lVar16);
                    uVar41 = uVar25 + 1;
                    uVar36 = *(uint *)(&stack0x00000028 + lVar16);
                    if (uVar36 < uVar41) {
                      *(undefined8 *)(puVar33 + -8) = 0x100371;
                      func_0x((longlong)&uStackX_18 + lVar16 + 2,0,uVar41 - uVar36);
                      pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                      if ((1 << (*pbVar29 & 0xe) & 0x1105U) != 0) {
                        *(short *)(pbVar29 + 2) = (short)uVar41;
                        pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                      }
                      *(uint *)(&stack0x00000028 + lVar16) = uVar41;
                      bVar24 = *(byte *)((longlong)puVar32 + 6);
                    }
                    else {
                      pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                    }
                    if (cVar12 == '\0') {
                      pbVar29[(int)uVar25] = pbVar29[(int)uVar25] & ~(byte)(1 << (bVar24 & 7));
                    }
                    else {
                      pbVar29[(int)uVar25] = pbVar29[(int)uVar25] | (byte)(1 << (bVar24 & 7));
                    }
                  }
                  goto LAB_;
                }
                if ((uVar25 & 0xc0000000) == 0x80000000) {
                  *(undefined8 *)(puVar33 + -8) = 0x101511;
                  func_0x(&stack0x000002f8 + lVar16);
                  *(undefined4 *)(&stack0x00000098 + lVar16) = 0;
                  if (*(int *)((longlong)&uStackX_18 + lVar16 + 4) == 0) {
                    *(undefined2 *)((longlong)&uStackX_18 + lVar16 + 2) = 0;
                    uVar25 = *(uint *)(&stack0x00000028 + lVar16);
                    uVar40 = (ulonglong)uVar25;
                    *(uint *)(&stack0x0000002c + lVar16) = uVar25;
                    pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                    if ((*pbVar29 & 0x10) != 0) {
                      uVar25 = uVar25 + 2 + (*(ushort *)(pbVar29 + uVar40) + 7 >> 3);
                      uVar40 = (ulonglong)uVar25;
                      *(uint *)(&stack0x0000002c + lVar16) = uVar25;
                    }
                    uVar25 = (uint)uVar40;
                    if ((*pbVar29 & 0x20) == 0) {
                      *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25;
                      *(undefined2 *)(&stack0x00000034 + lVar16) = 0;
                      *(uint *)(&stack0x00000030 + lVar16) = uVar25;
                    }
                    else {
                      puVar49 = (ushort *)(pbVar29 + uVar40);
                      *(ushort **)(&stack0x000000e0 + lVar16) = puVar49;
                      uVar44 = *puVar49;
                      *(ushort *)(&stack0x00000034 + lVar16) = uVar44;
                      if (uVar44 == 0) {
                        *(undefined8 *)(puVar33 + -8) = 0x101585;
                        cVar12 = func_0x(0x1f48ca0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x10158e;
                          lVar22 = func_0x();
                          if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x1015a8;
                            cVar12 = func_0x(0x1f48ca0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x1015c4;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x1015ea;
                              (*_DAT_)(1,0x18386ac,0x1958798,0x80f);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                        *(undefined8 *)(puVar33 + -8) = 0x1015f8;
                        func_0x(uVar19,3);
                        uVar44 = *(ushort *)(&stack0x00000034 + lVar16);
                        uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                        pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                      }
                      uVar36 = (int)uVar40 + (uVar44 + 1) * 2;
                      *(uint *)(&stack0x00000030 + lVar16) = uVar36;
                      if (0x1f9e < uVar36) {
                        *(undefined8 *)(puVar33 + -8) = 0x10162d;
                        cVar12 = func_0x(0x1f48ca0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x101636;
                          lVar22 = func_0x();
                          if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x101650;
                            cVar12 = func_0x(0x1f48ca0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x10166c;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x101692;
                              (*_DAT_)(1,0x18386ac,0x1958798,0x816);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                        *(undefined8 *)(puVar33 + -8) = 0x1016a0;
                        func_0x(uVar19,4);
                        uVar44 = *(ushort *)(&stack0x00000034 + lVar16);
                        uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                        uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                        pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                      }
                      uVar50 = (ulonglong)uVar44;
                      uVar25 = puVar49[uVar50] & 0x7fff;
                      *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25;
                      if (uVar25 < uVar36) {
                        *(undefined8 *)(puVar33 + -8) = 0x1016d6;
                        cVar12 = func_0x(0x1f48ca0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1016df;
                          lVar22 = func_0x();
                          if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar33 + -8) = 0x1016f9;
                            cVar12 = func_0x(0x1f48ca0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x101715;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar33 + 0x20) = 0;
                              *(undefined8 *)(puVar33 + -8) = 0x10173b;
                              (*_DAT_)(1,0x18386ac,0x1958798,0x81d);
                            }
                          }
                        }
                        uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                        *(undefined8 *)(puVar33 + -8) = 0x101749;
                        func_0x(uVar19,4);
                        uVar50 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar16);
                        uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                        uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                        pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                        uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                      }
                      puVar31 = puVar42;
                      if ((short)uVar50 != 0) {
                        do {
                          puVar49 = puVar49 + 1;
                          uVar41 = *puVar49 & 0x7fff;
                          if ((uVar41 < uVar36) || (uVar25 < uVar41)) {
                            *(undefined8 *)(puVar33 + -8) = 0x101795;
                            cVar12 = func_0x(0x1f48ca0);
                            if (cVar12 != '\0') {
                              *(undefined8 *)(puVar33 + -8) = 0x10179e;
                              lVar22 = func_0x();
                              if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar33 + -8) = 0x1017b8;
                                cVar12 = func_0x(0x1f48ca0);
                                if (cVar12 == '\0') {
                                  *(undefined8 *)(puVar33 + -8) = 0x1017d4;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar33 + 0x20) = 0;
                                  *(undefined8 *)(puVar33 + -8) = 0x1017f8;
                                  (*_DAT_)(1,0x18386ac,0x1958798,0x82a);
                                }
                              }
                            }
                            uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                            *(undefined8 *)(puVar33 + -8) = 0x101806;
                            func_0x(uVar19,4);
                            uVar50 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar16);
                            pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                            uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                          }
                          uVar35 = (int)puVar31 + 1;
                          puVar31 = (ushort *)(ulonglong)uVar35;
                          uVar36 = uVar41;
                        } while ((int)uVar35 < (int)uVar50);
                        uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                        uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                        puVar49 = *(ushort **)(&stack0x000000e0 + lVar16);
                      }
                      while ((short)puVar49[(ulonglong)((int)uVar50 - 1) + 1] < 0) {
                        uVar41 = uVar36;
                        if ((int)uVar50 != 1) {
                          uVar41 = *(ushort *)(pbVar29 + uVar50 * 2 + (uVar40 - 2)) & 0x7fff;
                        }
                        uVar35 = *(ushort *)(pbVar29 + uVar50 * 2 + uVar40) & 0x7fff;
                        if (((uVar41 < uVar36) || (uVar35 < uVar41)) || (uVar25 < uVar35)) {
                          *(undefined8 *)(puVar33 + -8) = 0x10188d;
                          func_0x(pbVar29,7);
                          uVar50 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar16);
                          uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                          uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                          pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                          uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                        }
                        if ((uVar41 < uVar36) || (uVar25 < uVar41)) goto LAB_;
                        if (*(ushort *)(pbVar29 + uVar41) == 5) {
                          puVar49 = (ushort *)((longlong)&uStackX_18 + lVar16 + 2);
                          *puVar49 = *puVar49 | 2;
                          *(short *)(&stack0x00000034 + lVar16) = (short)uVar50 + -1;
                          uVar40 = (ulonglong)(uVar41 & 0xffff);
                          *(short *)(&stack0x00000042 + lVar16) = (short)uVar41;
                          pbVar1 = pbVar29 + uVar40;
                          uVar44 = *(ushort *)(&stack0x00000044 + lVar16);
                          if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                            uVar44 = uVar44 & 0xc7ff;
                          }
                          else {
                            uVar44 = uVar44 ^ (uVar44 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000044 + lVar16) = uVar44;
                          uVar45 = (uVar44 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar44;
                          uVar50 = (ulonglong)uVar45;
                          *(ushort *)(&stack0x00000044 + lVar16) = uVar45;
                          pbVar39 = pbVar29 + (ulonglong)((uVar44 >> 0xb & 7) * 2) + 4 + uVar40 +
                                              (uVar50 & 0x7ff) * 2;
                          if (pbVar39 < pbVar1) {
                            *(undefined8 *)(puVar33 + -8) = 0x1019cf;
                            func_0x(pbVar1,0x19);
                            uVar50 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar16);
                            uVar40 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar16);
                            pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                            uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                          }
                          if (uVar35 - uVar41 <
                              (((*(uint *)(&stack0x00000044 + lVar16) & 0x7ff) * 2 - (int)uVar40) -
                              *(int *)((longlong)&pbStackX_20 + lVar16)) + (int)pbVar39) {
                            *(undefined8 *)(puVar33 + -8) = 0x101a09;
                            func_0x(pbVar29 + uVar40,0x19);
                            uVar50 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar16);
                            uVar40 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar16);
                            pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                            uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                          }
                          if (((uVar50 & 0x3800) != 0) &&
                             (puVar31 = (ushort *)(pbVar29 + uVar40 + 4), puVar49 = puVar42,
                             (uVar50 & 0x3800) != 0)) {
                            do {
                              if (((ushort)uVar50 & 0x7ff) < (*puVar31 & 0x7ff)) {
                                *(undefined8 *)(puVar33 + -8) = 0x101a75;
                                func_0x(pbVar29 + uVar40,0x1a);
                                uVar50 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar16);
                                uVar40 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar16);
                                pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                              }
                              uVar25 = (int)puVar49 + 1;
                              puVar49 = (ushort *)(ulonglong)uVar25;
                              puVar31 = puVar31 + 1;
                            } while ((int)uVar25 <
                                     (int)(*(uint *)(&stack0x00000044 + lVar16) >> 0xb & 7));
                            uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                          }
                          break;
                        }
                        if (*(ushort *)(pbVar29 + uVar41) < 0x400) break;
                        puVar31 = (ushort *)((longlong)&uStackX_18 + lVar16 + 2);
                        *puVar31 = *puVar31 | 1;
                        uVar44 = (short)uVar50 - 1;
                        uVar50 = (ulonglong)uVar44;
                        *(ushort *)(&stack0x00000034 + lVar16) = uVar44;
                        if (uVar44 == 0) break;
                      }
                    }
                    if ((*pbVar29 & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000003e + lVar16) = 0;
                    }
                    else {
                      *(uint *)(&stack0x0000003e + lVar16) = uVar25;
                      *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25 + 0xe;
                      *(undefined8 *)(puVar33 + -8) = 0x101906;
                      uVar19 = func_0x((longlong)&uStackX_18 + lVar16 + 2);
                      *(undefined8 *)(puVar33 + -8) = 0x101915;
                      func_0x(uVar19,&stack0x00000108 + lVar16);
                      *(undefined8 *)(puVar33 + -8) = 0x101921;
                      iVar14 = func_0x(&stack0x00000108 + lVar16);
                      uVar25 = *(int *)((longlong)&uStackX_18 + lVar16 + 4) + iVar14;
                      *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25;
                      pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                    }
                    if ((*(byte **)(&stack0x00000036 + lVar16) != (byte *)0x0) &&
                       (*(byte **)(&stack0x00000036 + lVar16) < pbVar29 + uVar25)) {
                      *(undefined8 *)(puVar33 + -8) = 0x101ae0;
                      cVar12 = func_0x(0x1f48ca0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x101ae9;
                        lVar22 = func_0x();
                        if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar33 + -8) = 0x101b03;
                          cVar12 = func_0x(0x1f48ca0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x101b1f;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar33 + 0x20) = 0;
                            *(undefined8 *)(puVar33 + -8) = 0x101b43;
                            (*_DAT_)(1,0x18386ac,0x1958798,0x886);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                      *(undefined8 *)(puVar33 + -8) = 0x101b51;
                      func_0x(uVar19,0x12);
                      uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                    }
                    if (0x3f3b < uVar25 - 1) {
                      *(undefined8 *)(puVar33 + -8) = 0x101b6c;
                      cVar12 = func_0x(0x1f48ca0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x101b75;
                        lVar22 = func_0x();
                        if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar33 + -8) = 0x101b8f;
                          cVar12 = func_0x(0x1f48ca0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x101bab;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(puVar33 + 0x20) = 0;
                            *(undefined8 *)(puVar33 + -8) = 0x101bcf;
                            (*_DAT_)(1,0x18386ac,0x1958798,0x88b);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                      *(undefined8 *)(puVar33 + -8) = 0x101bdd;
                      func_0x(uVar19,5);
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar33 + -8) = 0x101be6;
                  func_0x((longlong)&uStackX_18 + lVar16 + 2);
                  bVar24 = **(byte **)((longlong)&pbStackX_20 + lVar16) >> 6;
                  if ((bVar24 & 1) != 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x101c08;
                    func_0x
                              ((longlong)&uStackX_18 + lVar16 + 2,&stack0x000002f8 + lVar16);
                  }
                  if ((*(byte *)((longlong)&uStackX_18 + lVar16 + 2) & 1) != 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x101c23;
                    puVar18 = (undefined4 *)
                              func_0x((longlong)&uStackX_18 + lVar16 + 2,0x400,
                                              &stack0x00000098 + lVar16);
                    *(undefined4 *)(&stack0x000000d0 + lVar16) = *puVar18;
                    *(undefined2 *)(&stack0x000000d4 + lVar16) = *(undefined2 *)(puVar18 + 1);
                    *(undefined2 *)(&stack0x000000d6 + lVar16) =
                         *(undefined2 *)((longlong)puVar18 + 6);
                  }
                  if ((**(byte **)((longlong)&pbStackX_20 + lVar16) & 0x20) == 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x101c53;
                    func_0x((longlong)&uStackX_18 + lVar16 + 2);
                  }
                  lVar17 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16) +
                           *(longlong *)((longlong)&pbStackX_20 + lVar16);
                  *(undefined8 *)(puVar33 + -8) = 0x101c63;
                  iVar14 = func_0x((longlong)&uStackX_18 + lVar16 + 2);
                  lVar22 = *(longlong *)((longlong)&pbStackX_20 + lVar16);
                  if (iVar14 == 0) {
                    uVar44 = *(ushort *)(&stack0x00000034 + lVar16);
                    uVar40 = (ulonglong)uVar44;
                    puVar49 = (ushort *)(lVar22 + (ulonglong)*(uint *)(&stack0x0000002c + lVar16));
                    uVar25 = *(uint *)(&stack0x0000002c + lVar16) + (uVar44 + 1) * 2;
                    puVar31 = puVar42;
                    if (*puVar49 != 0) {
                      do {
                        uVar45 = puVar49[(longlong)puVar31 + 1];
                        puVar49[((ulonglong)puVar31 & 0xffff) + 1] =
                             puVar49[((ulonglong)puVar31 & 0xffff) + 1] & 0x8000;
                        puVar49[((ulonglong)puVar31 & 0xffff) + 1] =
                             puVar49[((ulonglong)puVar31 & 0xffff) + 1] |
                             (uVar45 & 0x7fff) + 2 & 0x7fff;
                        uVar36 = (int)puVar31 + 1;
                        puVar31 = (ushort *)(ulonglong)uVar36;
                      } while (uVar36 < *puVar49);
                      lVar22 = *(longlong *)((longlong)&pbStackX_20 + lVar16);
                    }
                    iVar14 = *(int *)((longlong)&uStackX_18 + lVar16 + 4);
                    *(undefined8 *)(puVar33 + -8) = 0x101d4a;
                    func_0x
                              ((ulonglong)uVar25 + 2 + lVar22,(ulonglong)uVar25 + lVar22,
                               iVar14 - uVar25);
                    piVar30 = (int *)((longlong)&uStackX_18 + lVar16 + 4);
                    *piVar30 = *piVar30 + 2;
                    uVar25 = *(int *)(&stack0x00000030 + lVar16) + 2;
                    *(uint *)(&stack0x00000030 + lVar16) = uVar25;
                    if (uVar44 != 0) {
                      uVar25 = puVar49[(ulonglong)(uVar44 - 1) + 1] & 0x7fff;
                    }
                    if ((uint)uVar44 < uVar44 + 1) {
                      do {
                        puVar49[(uVar40 & 0xffff) + 1] = (ushort)uVar25 & 0x7fff;
                        uVar36 = (int)uVar40 + 1;
                        uVar40 = (ulonglong)uVar36;
                      } while (uVar36 < uVar44 + 1);
                    }
                    *puVar49 = *puVar49 + 1;
                    *(undefined8 *)(puVar33 + -8) = 0x101d8b;
                    func_0x((longlong)&uStackX_18 + lVar16 + 2);
                    uVar44 = *(ushort *)
                              (lVar17 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar16) * 2);
                    *(undefined8 *)(puVar33 + -8) = 0x101da3;
                    func_0x(&stack0x00000148 + lVar16);
                    *(undefined4 *)(puVar33 + 0x28) = 0;
                    *(undefined8 *)(puVar33 + 0x20) = *(undefined8 *)(&stack0x00000060 + lVar16);
                    uVar19 = *(undefined8 *)(&stack0x000000a0 + lVar16);
                    *(undefined8 *)(puVar33 + -8) = 0x101dd0;
                    func_0x(&stack0x00000138 + lVar16,uVar19,1,0);
                    *(undefined **)(puVar33 + 0x28) = &stack0x000000c0 + lVar16;
                    *(undefined **)(puVar33 + 0x20) = &stack0x00000138 + lVar16;
                    *(undefined8 *)(puVar33 + -8) = 0x101dff;
                    func_0x(&stack0x00000042 + lVar16,uVar44 & 0x7fff,0x1f9e);
                    iVar14 = *(int *)(&stack0x000000c0 + lVar16);
                    iVar28 = 0;
                  }
                  else {
                    uVar44 = *(ushort *)(&stack0x00000034 + lVar16);
                    uVar25 = *(uint *)(&stack0x00000030 + lVar16);
                    if (uVar44 != 0) {
                      uVar25 = *(ushort *)
                                ((ulonglong)*(uint *)(&stack0x0000002c + lVar16) + lVar22 +
                                (ulonglong)uVar44 * 2) & 0x7fff;
                    }
                    uVar36 = *(ushort *)
                              ((ulonglong)*(uint *)(&stack0x0000002c + lVar16) + lVar22 + 2 +
                              (ulonglong)uVar44 * 2) & 0x7fff;
                    if (((uVar25 < *(uint *)(&stack0x00000030 + lVar16)) || (uVar36 < uVar25)) ||
                       (*(uint *)((longlong)&uStackX_18 + lVar16 + 4) < uVar36)) {
                      *(undefined8 *)(puVar33 + -8) = 0x101cac;
                      func_0x(lVar22,7);
                    }
                    uVar19 = *(undefined8 *)(&stack0x000000a0 + lVar16);
                    uVar8 = *(undefined8 *)(&stack0x00000060 + lVar16);
                    *(undefined8 *)(puVar33 + -8) = 0x101ccb;
                    iVar14 = func_0x(&stack0x00000042 + lVar16,uVar8,uVar19);
                    iVar28 = uVar36 - uVar25;
                  }
                  iVar28 = (iVar14 - iVar28) + *(int *)((longlong)&uStackX_18 + lVar16 + 4);
                  *(int *)((longlong)&uStackX_18 + lVar16 + 4) = iVar28;
                  if ((*(byte *)((longlong)&uStackX_18 + lVar16 + 2) & 1) != 0) {
                    *(ushort *)
                     (lVar17 + 2 + (ulonglong)(*(ushort *)(&stack0x00000034 + lVar16) + 1) * 2) =
                         (ushort)iVar28 | 0x8000;
                    iVar28 = (*(int *)((longlong)&uStackX_18 + lVar16 + 4) -
                             *(int *)(&stack0x00000098 + lVar16)) + -2;
                  }
                  *(ushort *)(lVar17 + 2 + (ulonglong)*(ushort *)(&stack0x00000034 + lVar16) * 2) =
                       (ushort)iVar28 | 0x8000;
                  if (iVar14 == 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x101e5b;
                    func_0x();
                    if ((**(byte **)((longlong)&pbStackX_20 + lVar16) & 0x20) != 0) {
                      *(short *)(&stack0x00000034 + lVar16) =
                           *(short *)(&stack0x00000034 + lVar16) + 1;
                      puVar49 = (ushort *)((longlong)&uStackX_18 + lVar16 + 2);
                      *puVar49 = *puVar49 & 0xfffd;
                      *(undefined8 *)(puVar33 + -8) = 0x101e7a;
                      func_0x(&stack0x00000042 + lVar16);
                    }
                  }
                  else {
                    puVar49 = (ushort *)((longlong)&uStackX_18 + lVar16 + 2);
                    *puVar49 = *puVar49 | 2;
                    *(undefined8 *)(puVar33 + -8) = 0x101e8d;
                    uVar13 = func_0x((longlong)&uStackX_18 + lVar16 + 2);
                    *(undefined2 *)(&stack0x00000042 + lVar16) = uVar13;
                  }
                  if ((*(byte *)((longlong)&uStackX_18 + lVar16 + 2) & 1) != 0) {
                    uVar15 = *(undefined4 *)(&stack0x00000098 + lVar16);
                    *(undefined8 *)(puVar33 + -8) = 0x101eb3;
                    func_0x((longlong)&uStackX_18 + lVar16 + 2,0x400,uVar15);
                  }
                  if ((bVar24 & 1) != 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x101ecc;
                    func_0x((longlong)&uStackX_18 + lVar16 + 2);
                  }
                  goto LAB_;
                }
                if (*(int *)((longlong)&uStackX_18 + lVar16 + 4) == 0) {
                  *(undefined2 *)((longlong)&uStackX_18 + lVar16 + 2) = 0;
                  uVar25 = *(uint *)(&stack0x00000028 + lVar16);
                  uVar40 = (ulonglong)uVar25;
                  *(uint *)(&stack0x0000002c + lVar16) = uVar25;
                  pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                  if ((*pbVar29 & 0x10) != 0) {
                    uVar25 = uVar25 + 2 + (*(ushort *)(pbVar29 + uVar40) + 7 >> 3);
                    uVar40 = (ulonglong)uVar25;
                    *(uint *)(&stack0x0000002c + lVar16) = uVar25;
                  }
                  uVar25 = (uint)uVar40;
                  if ((*pbVar29 & 0x20) == 0) {
                    *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25;
                    *(undefined2 *)(&stack0x00000034 + lVar16) = 0;
                    *(uint *)(&stack0x00000030 + lVar16) = uVar25;
                  }
                  else {
                    puVar49 = (ushort *)(pbVar29 + uVar40);
                    *(ushort **)(&stack0x000000e0 + lVar16) = puVar49;
                    uVar44 = *puVar49;
                    *(ushort *)(&stack0x00000034 + lVar16) = uVar44;
                    if (uVar44 == 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x100b2b;
                      cVar12 = func_0x(0x1f48ca0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x100b34;
                        lVar22 = func_0x();
                        if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar33 + -8) = 0x100b4e;
                          cVar12 = func_0x(0x1f48ca0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100b6a;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar33 + 0x20) = 0;
                            *(undefined8 *)(puVar33 + -8) = 0x100b90;
                            (*_DAT_)(1,0x18386ac,0x1958798,0x80f);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                      *(undefined8 *)(puVar33 + -8) = 0x100b9e;
                      func_0x(uVar19,3);
                      uVar44 = *(ushort *)(&stack0x00000034 + lVar16);
                      uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                      pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                    }
                    uVar36 = (int)uVar40 + (uVar44 + 1) * 2;
                    *(uint *)(&stack0x00000030 + lVar16) = uVar36;
                    if (0x1f9e < uVar36) {
                      *(undefined8 *)(puVar33 + -8) = 0x100bd3;
                      cVar12 = func_0x(0x1f48ca0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x100bdc;
                        lVar22 = func_0x();
                        if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar33 + -8) = 0x100bf6;
                          cVar12 = func_0x(0x1f48ca0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100c12;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar33 + 0x20) = 0;
                            *(undefined8 *)(puVar33 + -8) = 0x100c38;
                            (*_DAT_)(1,0x18386ac,0x1958798,0x816);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                      *(undefined8 *)(puVar33 + -8) = 0x100c46;
                      func_0x(uVar19,4);
                      uVar44 = *(ushort *)(&stack0x00000034 + lVar16);
                      uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                      uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                      pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                    }
                    uVar50 = (ulonglong)uVar44;
                    uVar25 = puVar49[uVar50] & 0x7fff;
                    *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25;
                    if (uVar25 < uVar36) {
                      *(undefined8 *)(puVar33 + -8) = 0x100c7c;
                      cVar12 = func_0x(0x1f48ca0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar33 + -8) = 0x100c85;
                        lVar22 = func_0x();
                        if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar33 + -8) = 0x100c9f;
                          cVar12 = func_0x(0x1f48ca0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100cbb;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar33 + 0x20) = 0;
                            *(undefined8 *)(puVar33 + -8) = 0x100ce1;
                            (*_DAT_)(1,0x18386ac,0x1958798,0x81d);
                          }
                        }
                      }
                      uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                      *(undefined8 *)(puVar33 + -8) = 0x100cef;
                      func_0x(uVar19,4);
                      uVar50 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar16);
                      uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                      uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                      pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                      uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                    }
                    puVar31 = puVar42;
                    if ((short)uVar50 != 0) {
                      do {
                        puVar49 = puVar49 + 1;
                        uVar41 = *puVar49 & 0x7fff;
                        if ((uVar41 < uVar36) || (uVar25 < uVar41)) {
                          *(undefined8 *)(puVar33 + -8) = 0x100d40;
                          cVar12 = func_0x(0x1f48ca0);
                          if (cVar12 != '\0') {
                            *(undefined8 *)(puVar33 + -8) = 0x100d49;
                            lVar22 = func_0x();
                            if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar33 + -8) = 0x100d63;
                              cVar12 = func_0x(0x1f48ca0);
                              if (cVar12 == '\0') {
                                *(undefined8 *)(puVar33 + -8) = 0x100d7f;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar33 + 0x20) = 0;
                                *(undefined8 *)(puVar33 + -8) = 0x100da3;
                                (*_DAT_)(1,0x18386ac,0x1958798,0x82a);
                              }
                            }
                          }
                          uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                          *(undefined8 *)(puVar33 + -8) = 0x100db1;
                          func_0x(uVar19,4);
                          uVar50 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar16);
                          pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                          uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                        }
                        uVar35 = (int)puVar31 + 1;
                        puVar31 = (ushort *)(ulonglong)uVar35;
                        uVar36 = uVar41;
                      } while ((int)uVar35 < (int)uVar50);
                      uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                      uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                      puVar49 = *(ushort **)(&stack0x000000e0 + lVar16);
                    }
                    while ((short)puVar49[(ulonglong)((int)uVar50 - 1) + 1] < 0) {
                      uVar41 = uVar36;
                      if ((int)uVar50 != 1) {
                        uVar41 = *(ushort *)(pbVar29 + uVar50 * 2 + (uVar40 - 2)) & 0x7fff;
                      }
                      uVar35 = *(ushort *)(pbVar29 + uVar50 * 2 + uVar40) & 0x7fff;
                      if (((uVar41 < uVar36) || (uVar35 < uVar41)) || (uVar25 < uVar35)) {
                        *(undefined8 *)(puVar33 + -8) = 0x100e3d;
                        func_0x(pbVar29,7);
                        uVar50 = (ulonglong)*(ushort *)(&stack0x00000034 + lVar16);
                        uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                        uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                        pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                        uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                      }
                      if ((uVar41 < uVar36) || (uVar25 < uVar41)) goto LAB_;
                      if (*(ushort *)(pbVar29 + uVar41) == 5) {
                        puVar49 = (ushort *)((longlong)&uStackX_18 + lVar16 + 2);
                        *puVar49 = *puVar49 | 2;
                        *(short *)(&stack0x00000034 + lVar16) = (short)uVar50 + -1;
                        uVar40 = (ulonglong)(uVar41 & 0xffff);
                        *(short *)(&stack0x00000042 + lVar16) = (short)uVar41;
                        pbVar1 = pbVar29 + uVar40;
                        uVar44 = *(ushort *)(&stack0x00000044 + lVar16);
                        if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
                          uVar44 = uVar44 & 0xc7ff;
                        }
                        else {
                          uVar44 = uVar44 ^ (uVar44 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000044 + lVar16) = uVar44;
                        uVar45 = (uVar44 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar44;
                        uVar50 = (ulonglong)uVar45;
                        *(ushort *)(&stack0x00000044 + lVar16) = uVar45;
                        pbVar39 = pbVar29 + (ulonglong)((uVar44 >> 0xb & 7) * 2) + 4 + uVar40 +
                                            (uVar50 & 0x7ff) * 2;
                        if (pbVar39 < pbVar1) {
                          *(undefined8 *)(puVar33 + -8) = 0x100f81;
                          func_0x(pbVar1,0x19);
                          uVar50 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar16);
                          uVar40 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar16);
                          pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                          uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                        }
                        if (uVar35 - uVar41 <
                            (((*(uint *)(&stack0x00000044 + lVar16) & 0x7ff) * 2 - (int)uVar40) -
                            *(int *)((longlong)&pbStackX_20 + lVar16)) + (int)pbVar39) {
                          *(undefined8 *)(puVar33 + -8) = 0x100fbb;
                          func_0x(pbVar29 + uVar40,0x19);
                          uVar50 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar16);
                          uVar40 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar16);
                          pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                          uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                        }
                        if (((uVar50 & 0x3800) != 0) &&
                           (puVar31 = (ushort *)(pbVar29 + uVar40 + 4), puVar49 = puVar42,
                           (uVar50 & 0x3800) != 0)) {
                          do {
                            if (((ushort)uVar50 & 0x7ff) < (*puVar31 & 0x7ff)) {
                              *(undefined8 *)(puVar33 + -8) = 0x101025;
                              func_0x(pbVar29 + uVar40,0x1a);
                              uVar50 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar16);
                              uVar40 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar16);
                              pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                            }
                            uVar25 = (int)puVar49 + 1;
                            puVar31 = puVar31 + 1;
                            puVar49 = (ushort *)(ulonglong)uVar25;
                          } while ((int)uVar25 <
                                   (int)(*(uint *)(&stack0x00000044 + lVar16) >> 0xb & 7));
                          uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                        }
                        break;
                      }
                      if (*(ushort *)(pbVar29 + uVar41) < 0x400) break;
                      puVar31 = (ushort *)((longlong)&uStackX_18 + lVar16 + 2);
                      *puVar31 = *puVar31 | 1;
                      uVar44 = (short)uVar50 - 1;
                      uVar50 = (ulonglong)uVar44;
                      *(ushort *)(&stack0x00000034 + lVar16) = uVar44;
                      if (uVar44 == 0) break;
                    }
                  }
                  if ((*pbVar29 & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000003e + lVar16) = 0;
                  }
                  else {
                    *(uint *)(&stack0x0000003e + lVar16) = uVar25;
                    *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25 + 0xe;
                    *(undefined8 *)(puVar33 + -8) = 0x100eb6;
                    uVar19 = func_0x((longlong)&uStackX_18 + lVar16 + 2);
                    *(undefined8 *)(puVar33 + -8) = 0x100ec5;
                    func_0x(uVar19,&stack0x00000100 + lVar16);
                    *(undefined8 *)(puVar33 + -8) = 0x100ed1;
                    iVar14 = func_0x(&stack0x00000100 + lVar16);
                    uVar25 = *(int *)((longlong)&uStackX_18 + lVar16 + 4) + iVar14;
                    *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar25;
                    pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                  }
                  if ((*(byte **)(&stack0x00000036 + lVar16) != (byte *)0x0) &&
                     (*(byte **)(&stack0x00000036 + lVar16) < pbVar29 + uVar25)) {
                    *(undefined8 *)(puVar33 + -8) = 0x101090;
                    cVar12 = func_0x(0x1f48ca0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)(puVar33 + -8) = 0x101099;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar33 + -8) = 0x1010b3;
                        cVar12 = func_0x(0x1f48ca0);
                        if (cVar12 == '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x1010cf;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar33 + 0x20) = 0;
                          *(undefined8 *)(puVar33 + -8) = 0x1010f3;
                          (*_DAT_)(1,0x18386ac,0x1958798);
                        }
                      }
                    }
                    uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                    *(undefined8 *)(puVar33 + -8) = 0x101101;
                    func_0x(uVar19,0x12);
                    uVar25 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                  }
                  if (0x3f3b < uVar25 - 1) {
                    *(undefined8 *)(puVar33 + -8) = 0x10111c;
                    cVar12 = func_0x(0x1f48ca0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)(puVar33 + -8) = 0x101125;
                      lVar22 = func_0x();
                      if ((lVar22 != 0) && (*(char *)(lVar22 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar33 + -8) = 0x10113f;
                        cVar12 = func_0x(0x1f48ca0);
                        if (cVar12 == '\0') {
                          *(undefined8 *)(puVar33 + -8) = 0x10115b;
                          (*_DAT_)(0x22,0x44,0x15);
                        }
                        else {
                          *(undefined8 *)(puVar33 + 0x20) = 0;
                          *(undefined8 *)(puVar33 + -8) = 0x10117f;
                          (*_DAT_)(1,0x18386ac,0x1958798);
                        }
                      }
                    }
                    uVar19 = *(undefined8 *)((longlong)&pbStackX_20 + lVar16);
                    *(undefined8 *)(puVar33 + -8) = 0x10118d;
                    func_0x(uVar19,5);
                  }
LAB_:
                  puVar32 = *(uint **)(&stack0x00000060 + lVar16);
                }
                uVar25 = -*puVar32;
                *(undefined8 *)(puVar33 + -8) = 0x1011a3;
                func_0x(&stack0x00000218 + lVar16);
                pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                bVar24 = *pbVar29;
                if ((bVar24 >> 6 & 1) != 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x1011c5;
                  func_0x
                            ((longlong)&uStackX_18 + lVar16 + 2,&stack0x00000218 + lVar16);
                  pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                }
                if ((*pbVar29 & 0x20) == 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x1011d8;
                  func_0x((longlong)&uStackX_18 + lVar16 + 2);
                  pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                }
                uVar44 = *(ushort *)(&stack0x00000034 + lVar16);
                uVar41 = (uint)uVar44;
                uVar36 = (uint)uVar44;
                if (uVar36 < uVar25) {
                  puVar49 = (ushort *)(pbVar29 + *(uint *)(&stack0x0000002c + lVar16));
                  uVar41 = *(uint *)(&stack0x0000002c + lVar16) + 2 + uVar36 * 2;
                  uVar35 = (uVar25 - uVar44) * 2;
                  puVar31 = puVar42;
                  if (*puVar49 != 0) {
                    do {
                      uVar45 = puVar49[(longlong)puVar31 + 1];
                      puVar49[((ulonglong)puVar31 & 0xffff) + 1] =
                           puVar49[((ulonglong)puVar31 & 0xffff) + 1] & 0x8000;
                      puVar49[((ulonglong)puVar31 & 0xffff) + 1] =
                           puVar49[((ulonglong)puVar31 & 0xffff) + 1] |
                           (uVar45 & 0x7fff) + (short)uVar35 & 0x7fff;
                      uVar27 = (int)puVar31 + 1;
                      puVar31 = (ushort *)(ulonglong)uVar27;
                    } while (uVar27 < *puVar49);
                    pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                  }
                  iVar14 = *(int *)((longlong)&uStackX_18 + lVar16 + 4);
                  *(undefined8 *)(puVar33 + -8) = 0x10126a;
                  func_0x
                            (pbVar29 + (ulonglong)uVar35 + (ulonglong)uVar41,pbVar29 + uVar41,
                             iVar14 - uVar41);
                  piVar30 = (int *)((longlong)&uStackX_18 + lVar16 + 4);
                  *piVar30 = *piVar30 + uVar35;
                  uVar35 = *(int *)(&stack0x00000030 + lVar16) + uVar35;
                  *(uint *)(&stack0x00000030 + lVar16) = uVar35;
                  if (uVar44 != 0) {
                    uVar35 = puVar49[(ulonglong)(uVar36 - 1) + 1] & 0x7fff;
                  }
                  do {
                    puVar49[(ulonglong)(uVar36 & 0xffff) + 1] = (ushort)uVar35 & 0x7fff;
                    uVar36 = uVar36 + 1;
                  } while (uVar36 < uVar25);
                  *puVar49 = *puVar49 + (short)(uVar25 - uVar44);
                  *(undefined8 *)(puVar33 + -8) = 0x1012ab;
                  iVar14 = func_0x((longlong)&uStackX_18 + lVar16 + 2);
                  if (iVar14 != 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x1012bf;
                    uVar13 = func_0x
                                       ((longlong)&uStackX_18 + lVar16 + 2,&stack0x000000f0 + lVar16
                                       );
                    *(undefined2 *)(&stack0x00000042 + lVar16) = uVar13;
                  }
                  uVar41 = uVar25 & 0xffff;
                  *(short *)(&stack0x00000034 + lVar16) = (short)uVar25;
                  pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                }
                uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                if (uVar41 < uVar25) {
                  uVar50 = (ulonglong)
                           (*(ushort *)(pbVar29 + (ulonglong)uVar41 * 2 + uVar40) & 0x7fff);
                  iVar14 = 0;
LAB_:
                  puVar49 = (ushort *)(pbVar29 + uVar40);
                  uVar15 = *(undefined4 *)((longlong)&uStackX_18 + lVar16 + 4);
                  *(undefined8 *)(puVar33 + -8) = 0x101463;
                  uVar15 = func_0x(uVar15,iVar14 + (int)uVar50);
                  lVar22 = *(longlong *)((longlong)&pbStackX_20 + lVar16);
                  *(undefined8 *)(puVar33 + -8) = 0x10147f;
                  func_0x
                            (lVar22 + 1 + uVar50,(longlong)iVar14 + uVar50 + lVar22,uVar15);
                  uVar25 = uVar25 - 1;
                  if ((int)uVar25 < (int)(uint)*puVar49) {
                    do {
                      uVar44 = puVar49[(longlong)(int)uVar25 + 1];
                      puVar49[((ulonglong)uVar25 & 0xffff) + 1] =
                           puVar49[((ulonglong)uVar25 & 0xffff) + 1] & 0x8000;
                      puVar49[((ulonglong)uVar25 & 0xffff) + 1] =
                           puVar49[((ulonglong)uVar25 & 0xffff) + 1] |
                           ((uVar44 & 0x7fff) - (short)iVar14) + 1 & 0x7fff;
                      uVar25 = uVar25 + 1;
                    } while ((int)uVar25 < (int)(uint)*puVar49);
                  }
                  piVar30 = (int *)((longlong)&uStackX_18 + lVar16 + 4);
                  *piVar30 = *piVar30 + (1 - iVar14);
                  *(undefined8 *)(puVar33 + -8) = 0x1014e4;
                  iVar14 = func_0x((longlong)&uStackX_18 + lVar16 + 2);
                  if (iVar14 != 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x1014f8;
                    uVar13 = func_0x((longlong)&uStackX_18 + lVar16 + 2);
                    *(undefined2 *)(&stack0x00000042 + lVar16) = uVar13;
                  }
                  pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                }
                else {
                  uVar36 = *(uint *)(&stack0x00000030 + lVar16);
                  if (uVar25 != 1) {
                    uVar36 = *(ushort *)(pbVar29 + (longlong)(int)uVar25 * 2 + (uVar40 - 2)) &
                             0x7fff;
                  }
                  uVar50 = (ulonglong)uVar36;
                  uVar41 = *(ushort *)(pbVar29 + (longlong)(int)uVar25 * 2 + uVar40) & 0x7fff;
                  if (((uVar36 < *(uint *)(&stack0x00000030 + lVar16)) || (uVar41 < uVar36)) ||
                     (*(uint *)((longlong)&uStackX_18 + lVar16 + 4) < uVar41)) {
                    *(undefined8 *)(puVar33 + -8) = 0x101326;
                    func_0x(pbVar29);
                    uVar40 = (ulonglong)*(uint *)(&stack0x0000002c + lVar16);
                    pbVar29 = *(byte **)((longlong)&pbStackX_20 + lVar16);
                  }
                  iVar14 = uVar41 - uVar36;
                  if (uVar41 - uVar36 != 1) goto LAB_;
                }
                pbVar29[uVar50] = **(byte **)(&stack0x000000a0 + lVar16);
                if ((bVar24 >> 6 & 1) != 0) {
                  *(undefined8 *)(puVar33 + -8) = 0x101363;
                  func_0x((longlong)&uStackX_18 + lVar16 + 2);
                }
                goto LAB_;
              }
              uVar41 = puVar32[0x10];
              piVar30 = *(int **)(&stack0x000000b8 + lVar16);
              if (((uVar41 >> 0xd & 1) == 0) || (*piVar30 != 0)) {
                if (((uVar41 & 0x8000) == 0) || ((*(byte *)((longlong)param_2 + 0x14) & 8) == 0)) {
                  lVar22 = *(longlong *)(puVar32 + 0x12);
                  if ((uVar41 >> 8 & 1) == 0) {
                    uVar36 = (uint)*(ushort *)(lVar22 + 2);
                  }
                  else if ((*(byte *)(lVar22 + 0x2a) & 0x10) == 0) {
                    uVar36 = *(uint *)(*(longlong *)(lVar22 + 0x18) + (longlong)param_2[3]);
                  }
                  else {
                    uVar36 = *(uint *)(*(longlong *)(lVar22 + 0x18) + (longlong)param_2[4]);
                  }
                }
                else {
                  uVar36 = *(uint *)(param_2[7] + (ulonglong)puVar32[0xe] * 4);
                }
              }
              if (*(ushort *)(puVar32 + 0xf) < uVar36) {
                *(undefined8 *)(puVar33 + -8) = 0x101f4c;
                (*_DAT_)(6,0x52,0x16);
                piVar30 = *(int **)(&stack0x000000b8 + lVar16);
              }
              lVar22 = *(longlong *)(&stack0x00000090 + lVar16);
              *(undefined4 *)(puVar33 + 0x28) = 0;
              *(uint **)(puVar33 + 0x20) = puVar32;
              *(undefined8 *)(puVar33 + -8) = 0x101f78;
              func_0x((longlong)(int)~uVar25 * 0x20 + lVar22,piVar30,uVar36);
            }
LAB_:
            param_2 = *(ushort ***)(&stack0x00000068 + lVar16);
          }
LAB_:
          puVar32 = puVar32 + 0x14;
          *(uint **)(&stack0x00000060 + lVar16) = puVar32;
          iVar14 = *(int *)(&stack0x000000b0 + lVar16);
          *(uint *)(&stack0x000000b0 + lVar16) = iVar14 + 1U;
        } while (iVar14 + 1U < *(uint *)(&stack0x000000c4 + lVar16));
        uVar25 = *(uint *)(&stack0x0000009c + lVar16);
      }
      if (uVar25 != 0) {
        lVar22 = *(longlong *)(&stack0x00000090 + lVar16);
        do {
          uVar40 = (ulonglong)uVar25;
          uVar36 = uVar25 - 1;
          if (*(int *)((ulonglong)uVar36 * 0x20 + 8 + lVar22) != 0) {
            *(ushort *)(&stack0x00000034 + lVar16) = (ushort)uVar25;
            iVar14 = *(int *)(&stack0x0000002c + lVar16) + 2 + uVar25 * 2;
            *(int *)(&stack0x00000030 + lVar16) = iVar14;
            *(int *)((longlong)&uStackX_18 + lVar16 + 4) = iVar14;
            **(byte **)((longlong)&pbStackX_20 + lVar16) =
                 **(byte **)((longlong)&pbStackX_20 + lVar16) | 0x20;
            uVar36 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
            if (uVar36 < 0x1f7d) {
              puVar42 = (ushort *)
                        ((ulonglong)*(uint *)(&stack0x0000002c + lVar16) +
                        *(longlong *)((longlong)&pbStackX_20 + lVar16));
              *puVar42 = (ushort)uVar25;
              uVar36 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
            }
            if (uVar25 != 0) {
              puVar32 = (uint *)(lVar22 + 0xc);
              do {
                puVar42 = puVar42 + 1;
                uVar50 = (ulonglong)uVar36;
                lVar22 = *(longlong *)((longlong)&pbStackX_20 + lVar16);
                uVar25 = puVar32[-1];
                uVar36 = uVar36 + uVar25;
                *(uint *)((longlong)&uStackX_18 + lVar16 + 4) = uVar36;
                if (uVar36 < 0x1f7d) {
                  *puVar42 = (ushort)((*puVar32 & 1) << 0xf) | (ushort)uVar36 & 0x7fff;
                  uVar19 = *(undefined8 *)(puVar32 + -3);
                  *(undefined8 *)(puVar33 + -8) = 0x102138;
                  func_0x(uVar50 + lVar22,uVar25,uVar19,uVar25);
                  uVar36 = *(uint *)((longlong)&uStackX_18 + lVar16 + 4);
                }
                puVar32 = puVar32 + 8;
                uVar40 = uVar40 - 1;
              } while (uVar40 != 0);
            }
            break;
          }
          uVar25 = uVar36;
        } while (uVar36 != 0);
      }
    }
LAB_:
    param_1 = *(longlong **)(&stack0x00000058 + lVar16);
    puVar34 = puVar33;
  }
  else {
    if (bVar10) {
      lVar22 = 0x1ff46f0;
      lVar17 = 0x1fa3b18;
    }
    else {
      lVar22 = 0x1fbb158;
      lVar17 = 0x1fa3ae0;
    }
    if ((bVar24 & 1) == 0) {
      lVar22 = lVar17;
    }
    param_1[0x74] = lVar22;
    param_1[0x75] = 0;
    *(longlong **)((longlong)aplStackX_8 + lVar16) = param_1 + 0x52;
    *(undefined **)((longlong)&pbStackX_20 + lVar16 + -0x20) = &stack0x000000cc + lVar16;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar16) = 0x1f7c;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar16) = 0x1f9e;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar16) = &stack0x000003d8 + lVar16;
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102688;
    func_0x(param_1 + 0x77,param_2,2,psVar2);
    puVar34 = &stack0xffffffffffffffc8 + lVar16;
  }
  puVar26 = (undefined8 *)0x0;
  lVar22 = *(longlong *)(&stack0x000000d8 + lVar16);
  *(undefined8 *)(puVar34 + -8) = 0x1013dd;
  func_0x(lVar22);
  bVar24 = (&stack0x00000050)[lVar16];
  (&stack0x00000078)[lVar16] = (bVar24 ^ 1) * '\x02';
  lVar17 = *(longlong *)(lVar22 + 8);
  if ((((*(byte *)(lVar17 + 0x41) & 8) != 0) || ((*(byte *)(lVar17 + 0x108) & 0x40) != 0)) &&
     (*(longlong **)(lVar17 + 0x160) != (longlong *)0x0)) {
    lVar17 = **(longlong **)(lVar17 + 0x160);
    uVar25 = *(uint *)(lVar17 + 100);
    if (uVar25 != 0xffffffff) {
      puVar32 = *(uint **)(lVar17 + 8);
      if (uVar25 < *puVar32) {
        uVar36 = uVar25 / puVar32[9];
        uVar40 = (ulonglong)uVar25 % (ulonglong)puVar32[9];
        lVar17 = *(longlong *)(puVar32 + 4);
      }
      else {
        uVar36 = (uVar25 - *puVar32) / puVar32[0x11];
        uVar40 = (ulonglong)(uVar25 - *puVar32) % (ulonglong)puVar32[0x11];
        lVar17 = *(longlong *)(puVar32 + 0xc);
      }
      lVar17 = uVar40 * 0x1c0 + *(longlong *)(lVar17 + (ulonglong)uVar36 * 8);
      if (lVar17 != 0) {
        uVar13 = *(undefined2 *)(lVar17 + 0x38);
        *(undefined8 *)(puVar34 + -8) = 0x1026bd;
        func_0x(psVar2,lVar17,&stack0x00000078 + lVar16,uVar13);
      }
    }
  }
  if (param_1[0x8c] != 0) {
    *(undefined8 *)(puVar34 + -8) = 0x1026d3;
    uVar19 = func_0x();
    *(undefined8 *)(&stack0x000000e8 + lVar16) = uVar19;
    plVar7 = (longlong *)param_1[0x8c];
    lVar22 = param_1[0x8d];
    pcVar5 = *(code **)(*plVar7 + 0x18);
    *(undefined8 *)(puVar34 + -8) = 0x1026f2;
    iVar14 = (*pcVar5)(plVar7,lVar22);
    if (iVar14 == 0) {
      uVar8 = *(undefined8 *)(&stack0x00000068 + lVar16);
      pcVar5 = *(code **)(*param_1 + 0x220);
      *(undefined8 *)(puVar34 + -8) = 0x102708;
      iVar14 = (*pcVar5)(param_1,uVar8);
      if (iVar14 != 0) {
        *(undefined8 *)(puVar34 + 0x20) = 0;
        *(undefined8 *)(puVar34 + -8) = 0x102732;
        (*_DAT_)(1,0x19e9370,0x19bd020,0x1e76);
      }
    }
    *(undefined8 *)(puVar34 + -8) = 0x102741;
    (*_DAT_)(uVar19,1);
    goto LAB_;
  }
  *(undefined **)(puVar34 + 0x28) = &stack0x00000080 + lVar16;
  *(undefined8 *)(puVar34 + 0x20) = 0;
  *(undefined8 *)(puVar34 + -8) = 0x102761;
  iVar14 = func_0x(param_1,psVar2,0,0);
  if (iVar14 == 0) {
    if ((DAT_ & 1) == 0) {
      lVar17 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar17 != 0) && (**(longlong **)(lVar17 + 0x38) != 0)) {
        *(undefined8 *)(puVar34 + -8) = 0x1027b8;
        iVar14 = (*_DAT_)();
        if (iVar14 != 0) goto LAB_;
      }
    }
    else {
LAB_:
      lVar17 = *(longlong *)(param_1[3] + 0xd0);
      puVar20 = puVar26;
      puVar47 = puVar26;
      if (lVar17 != 0) {
        puVar20 = *(undefined8 **)(lVar17 + 0x40);
        puVar47 = *(undefined8 **)(lVar17 + 0xf8);
      }
      uVar9 = *(uint6 *)(lVar22 + 0x14);
      uVar13 = *(undefined2 *)(*(longlong *)(param_1[3] + 0x30) + 0x6b8);
      *(undefined8 **)(puVar34 + 0x20) = puVar20;
      *(undefined8 *)(puVar34 + -8) = 0x102812;
      func_0x(0x1842410,uVar13,(ulonglong)uVar9 << 0x10,puVar47);
      *(undefined8 *)(puVar34 + -8) = 0x10281f;
      (*_DAT_)(&stack0x00000158 + lVar16);
      *(undefined8 *)(puVar34 + -8) = 0x102826;
      uVar19 = (*_DAT_)();
      *(undefined8 *)(puVar34 + -8) = 0x102837;
      lVar17 = (*_DAT_)(uVar19,0,0x6c0);
      *(longlong *)(&stack0x00000120 + lVar16) = lVar17;
      puVar20 = puVar26;
      if (lVar17 != 0) {
        *(undefined8 *)(puVar34 + -8) = 0x10284d;
        puVar20 = (undefined8 *)func_0x(lVar17,0);
      }
      if (puVar20 != (undefined8 *)0x0) {
        *(undefined8 *)(puVar34 + -8) = 0x10286a;
        iVar14 = (*_DAT_)(&stack0x00000158 + lVar16,puVar20);
        if (iVar14 == 0) {
          pcVar5 = *(code **)*puVar20;
          *(undefined8 *)(puVar34 + -8) = 0x10287b;
          (*pcVar5)(puVar20,1);
        }
      }
      *(undefined8 *)(puVar34 + -8) = 0x10288b;
      func_0x(psVar2);
      *(undefined8 *)(puVar34 + -8) = 0x102899;
      (*_DAT_)(&stack0x00000158 + lVar16);
    }
LAB_:
    lVar17 = *(longlong *)(lVar22 + 8);
    if ((((*(byte *)(lVar17 + 0x41) & 8) != 0) || ((*(byte *)(lVar17 + 0x108) & 0x40) != 0)) &&
       (*(longlong **)(lVar17 + 0x160) != (longlong *)0x0)) {
      lVar43 = **(longlong **)(lVar17 + 0x160);
      uVar25 = *(uint *)(lVar43 + 100);
      if (uVar25 != 0xffffffff) {
        puVar32 = *(uint **)(lVar43 + 8);
        if (uVar25 < *puVar32) {
          uVar40 = (ulonglong)uVar25 / (ulonglong)puVar32[9];
          uVar25 = uVar25 % puVar32[9];
          lVar43 = *(longlong *)(puVar32 + 4);
        }
        else {
          uVar25 = uVar25 - *puVar32;
          uVar40 = (ulonglong)uVar25 / (ulonglong)puVar32[0x11];
          uVar25 = uVar25 % puVar32[0x11];
          lVar43 = *(longlong *)(puVar32 + 0xc);
        }
        if ((ulonglong)uVar25 * 0x1c0 + *(longlong *)(lVar43 + uVar40 * 8) != 0) {
          if ((((*(longlong *)(lVar17 + 0x90) == 0) || (DAT_ == '\0')) ||
              (*(longlong *)(*(longlong *)(*(longlong *)(lVar17 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
             (*(uint *)(lVar17 + 0xf4) < 2)) {
            if (*(int *)(lVar17 + 0x480) == 0) {
              *(undefined8 *)(puVar34 + -8) = 0x102e31;
              func_0x(lVar17);
              lVar17 = *(longlong *)(lVar22 + 8);
            }
            if (*(longlong *)(lVar17 + 0x150) != 0) {
              lVar43 = (ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
              lVar22 = *(longlong *)(lVar43 + 0x100);
              if (lVar22 == 0) {
                *(undefined8 *)(puVar34 + -8) = 0x102e72;
                (*_DAT_)(0);
                lVar22 = *(longlong *)(lVar43 + 0x100);
              }
              if (*(longlong *)(lVar22 + 0x260) != 0) {
                puVar26 = (undefined8 *)(ulonglong)*(uint *)(*(longlong *)(lVar22 + 0x260) + 0xe68);
              }
              if ((uint)puVar26 < *(uint *)(_DAT_ + 8)) {
                lVar22 = *(longlong *)(*(longlong *)(lVar17 + 0x150) + (longlong)puVar26 * 8);
                *(longlong *)(lVar22 + 8) = *(longlong *)(lVar22 + 8) + 1;
                goto LAB_;
              }
            }
            LOCK();
            plVar7 = (longlong *)(*(longlong *)(lVar17 + 0x148) + 8);
            *plVar7 = *plVar7 + 1;
            UNLOCK();
          }
LAB_:
          *(undefined4 *)(&stack0x00000088 + lVar16) = 2;
          if (bVar24 != 0) {
            uVar19 = *(undefined8 *)(&stack0x00000080 + lVar16);
            *(undefined8 *)(puVar34 + -8) = 0x102ee4;
            func_0x(param_1,uVar19,4);
            uVar19 = *(undefined8 *)(&stack0x00000080 + lVar16);
            *(undefined8 *)(puVar34 + -8) = 0x102ef0;
            func_0x(param_1,uVar19);
          }
          goto LAB_;
        }
      }
    }
    uVar19 = *(undefined8 *)(&stack0x00000080 + lVar16);
    *(undefined8 *)(puVar34 + -8) = 0x102efe;
    func_0x(param_1,uVar19);
    *(undefined4 *)(&stack0x00000088 + lVar16) = 4;
  }
  else {
    if (iVar14 != 1) goto LAB_;
    bVar10 = false;
    lVar17 = *(longlong *)(&stack0x00000080 + lVar16);
    uVar25 = *(uint *)(lVar17 + 0x10);
    uVar36 = uVar25 & 0xfffffeff;
    *(uint *)(lVar17 + 0x10) = uVar36;
    if (((char)uVar36 < '\0') || ((*(byte *)(lVar17 + 0x34) & 1) == 0)) {
      *(undefined8 *)(puVar34 + -8) = 0x10292f;
      psVar21 = (short *)func_0x(lVar17,0);
    }
    else if ((uVar25 >> 0xd & 1) == 0) {
      psVar21 = (short *)(lVar17 + 0x48);
    }
    else {
      psVar21 = *(short **)(lVar17 + 0x148);
    }
    pbVar29 = *(byte **)(psVar21 + 4);
    if (*psVar21 == 0) {
      bVar24 = *pbVar29 & 0xe;
      bVar51 = false;
      if (bVar24 == 2) {
        bVar51 = (pbVar29[1] & 1) != 0;
      }
      else if (((bVar24 - 10 & 0xf9) == 0) && (bVar24 != 0x10)) {
        bVar51 = true;
      }
    }
    else {
      bVar51 = ((*pbVar29 & 0x1c) - 4 & 0xffffffe7) == 0;
    }
    plVar7 = *(longlong **)(&stack0x00000058 + lVar16);
    if ((*(byte *)(*(longlong *)(&stack0x00000110 + lVar16) + 0x14) & 0x10) != 0) {
      uVar19 = *(undefined8 *)(&stack0x00000080 + lVar16);
      pcVar5 = *(code **)(*plVar7 + 0x1c0);
      *(undefined8 *)(puVar34 + -8) = 0x10299f;
      (*pcVar5)(plVar7,uVar19);
    }
    *(undefined8 *)(puVar34 + -8) = 0x1029aa;
    cVar12 = func_0x(lVar22,psVar21);
    if ((DAT_ & 1) == 0) {
      lVar22 = *(longlong *)
                ((ulonglong)*_DAT_ +
                *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)
                );
      if ((lVar22 != 0) && (lVar22 = **(longlong **)(lVar22 + 0x38), lVar22 != 0)) {
        *(undefined8 *)(puVar34 + -8) = 0x1029fd;
        iVar14 = (*_DAT_)(lVar22,600);
        if (iVar14 != 0) goto LAB_;
      }
    }
    else {
LAB_:
      lVar22 = *(longlong *)(plVar7[3] + 0xd0);
      puVar20 = puVar26;
      puVar47 = puVar26;
      if (lVar22 != 0) {
        puVar20 = *(undefined8 **)(lVar22 + 0x40);
        puVar47 = *(undefined8 **)(lVar22 + 0xf8);
      }
      uVar9 = *(uint6 *)(*(longlong *)(&stack0x000000d8 + lVar16) + 0x14);
      uVar13 = *(undefined2 *)(*(longlong *)(plVar7[3] + 0x30) + 0x6b8);
      *(undefined8 **)(puVar34 + 0x28) = puVar20;
      *(undefined8 **)(puVar34 + 0x20) = puVar47;
      *(undefined8 *)(puVar34 + -8) = 0x102a66;
      func_0x(0x18424c0,uVar13,(ulonglong)uVar9 << 0x10,cVar12);
      *(undefined8 *)(puVar34 + -8) = 0x102a73;
      (*_DAT_)(&stack0x000001b8 + lVar16);
      *(undefined8 *)(puVar34 + -8) = 0x102a7a;
      uVar19 = (*_DAT_)();
      *(undefined8 *)(puVar34 + -8) = 0x102a8b;
      lVar22 = (*_DAT_)(uVar19,0,0x6c0);
      *(longlong *)(&stack0x000000e8 + lVar16) = lVar22;
      puVar20 = puVar26;
      if (lVar22 != 0) {
        *(undefined8 *)(puVar34 + -8) = 0x102aa1;
        puVar20 = (undefined8 *)func_0x(lVar22,0);
      }
      if (puVar20 != (undefined8 *)0x0) {
        *(undefined8 *)(puVar34 + -8) = 0x102abe;
        iVar14 = (*_DAT_)(&stack0x000001b8 + lVar16,puVar20);
        if (iVar14 == 0) {
          pcVar5 = *(code **)*puVar20;
          *(undefined8 *)(puVar34 + -8) = 0x102acf;
          (*pcVar5)(puVar20,1);
        }
      }
      *(undefined8 *)(puVar34 + -8) = 0x102adf;
      func_0x(psVar2,&stack0x000001b8 + lVar16);
      *(undefined8 *)(puVar34 + -8) = 0x102aed;
      (*_DAT_)(&stack0x000001b8 + lVar16);
    }
    if ((cVar12 != '\x04') && (bVar51)) {
      *(undefined8 *)(puVar34 + 0x20) = 0;
      *(undefined8 *)(puVar34 + -8) = 0x102b1f;
      (*_DAT_)(1,0x19e9338,0x19bd020,0x1ec7);
    }
    bVar11 = bVar10;
    if ((&stack0x00000050)[lVar16] == '\0') {
      if (cVar12 == '\0') {
LAB_:
        *(undefined4 *)(&stack0x00000088 + lVar16) = 0;
        param_1 = *(longlong **)(&stack0x00000058 + lVar16);
        bVar11 = true;
        if (((*(uint *)param_1[0x21] & 0x800) == 0) || (*(int *)(param_1[0x5d] + 0x24) == 0)) {
          param_1 = *(longlong **)(&stack0x00000058 + lVar16);
        }
        else {
          param_1[0x36] = (longlong)psVar21;
          param_1[0x35] = lVar17;
          lVar22 = param_1[0x8a];
          if (lVar22 == 0) {
            *(undefined4 *)(&stack0x000000cc + lVar16) = 0x1f3c;
            puVar34[0x20] = 5;
            lVar22 = param_1[0x3e];
            *(undefined8 *)(puVar34 + -8) = 0x102c19;
            puVar20 = (undefined8 *)(*_DAT_)(0x28,lVar22,0x15cf540,0x1f3c);
            *(undefined8 **)(&stack0x000000e8 + lVar16) = puVar20;
            if (puVar20 != (undefined8 *)0x0) {
              *(undefined4 *)puVar20 = 0;
              puVar20[1] = 0;
              puVar20[2] = 0;
              puVar20[3] = 0;
              puVar20[4] = 0;
              puVar26 = puVar20;
            }
            param_1[0x8a] = (longlong)puVar26;
            lVar22 = param_1[0x5d];
            uVar19 = *(undefined8 *)(&stack0x00000068 + lVar16);
            *(undefined8 *)(puVar34 + 0x30) = uVar19;
            *(undefined8 *)(puVar34 + 0x28) = *(undefined8 *)(lVar22 + 0x28);
            *(undefined8 *)(puVar34 + 0x20) = *(undefined8 *)(&stack0x000000d8 + lVar16);
            lVar17 = param_1[3];
            uVar15 = *(undefined4 *)(lVar22 + 0x24);
            lVar22 = param_1[0x3e];
            *(undefined8 *)(puVar34 + -8) = 0x102d14;
            func_0x(puVar26,lVar22,uVar15,lVar17);
            lVar22 = param_1[0x8a];
          }
          else {
            uVar19 = *(undefined8 *)(&stack0x00000068 + lVar16);
          }
          lVar17 = param_1[0x5d];
          *(undefined8 *)(puVar34 + 0x30) = uVar19;
          *(undefined8 *)(puVar34 + 0x28) = *(undefined8 *)(lVar17 + 0x28);
          uVar15 = *(undefined4 *)(lVar17 + 0x24);
          *(undefined8 *)(puVar34 + -8) = 0x102d3f;
          func_0x(lVar22,lVar17,uVar15);
          uVar19 = *(undefined8 *)(param_1[0x8a] + 8);
          uVar8 = *(undefined8 *)(param_1[0x8a] + 0x10);
          *(undefined8 *)(puVar34 + -8) = 0x102d56;
          iVar14 = func_0x(param_1 + 0x32,uVar8,uVar19);
          if (iVar14 == 0) {
            uVar19 = *(undefined8 *)(&stack0x00000080 + lVar16);
            *(undefined8 *)(puVar34 + -8) = 0x102d69;
            func_0x(param_1,uVar19,1);
            *(undefined4 *)(&stack0x00000088 + lVar16) = 2;
            bVar11 = bVar10;
          }
        }
      }
      else if (cVar12 == '\x02') {
        param_1 = *(longlong **)(&stack0x00000058 + lVar16);
        if ((*(uint *)param_1[0x21] & 0x800) != 0) {
          *(undefined4 *)(&stack0x00000088 + lVar16) = 5;
        }
      }
      else {
        if (cVar12 != '\x01') {
          *(undefined8 *)(puVar34 + 0x20) = 0;
          *(undefined8 *)(puVar34 + -8) = 0x102c83;
          (*_DAT_)(1,0x19e92a0,0x19bd020,0x1ed4);
        }
        uVar19 = *(undefined8 *)(&stack0x00000080 + lVar16);
        param_1 = *(longlong **)(&stack0x00000058 + lVar16);
        *(undefined8 *)(puVar34 + -8) = 0x102c96;
        func_0x(param_1,uVar19,2);
        *(undefined4 *)(&stack0x00000088 + lVar16) = 3;
      }
    }
    else {
      if (cVar12 != '\x04') {
        if (cVar12 == '\0') {
          uVar19 = *(undefined8 *)(&stack0x00000080 + lVar16);
          uVar8 = *(undefined8 *)(&stack0x00000058 + lVar16);
          *(undefined8 *)(puVar34 + -8) = 0x102b9a;
          func_0x(uVar8,uVar19,4);
          goto LAB_;
        }
        *(undefined8 *)(puVar34 + 0x20) = 0;
        *(undefined8 *)(puVar34 + -8) = 0x102b60;
        (*_DAT_)(1,0x19e92c0,0x19bd020,0x1ec9);
      }
      param_1 = *(longlong **)(&stack0x00000058 + lVar16);
      if (bVar51) {
        *(uint *)(&stack0x00000088 + lVar16) = (*(uint *)param_1[0x21] & 0x800 | 0x200) >> 9;
      }
      else {
        *(undefined4 *)(&stack0x00000088 + lVar16) = 0;
        bVar11 = true;
      }
    }
    if (*(int *)((longlong)param_1 + 0x1cc) != 0) {
      param_1[0x74] = (longlong)psVar2;
      param_1[0x75] = 0;
      lVar22 = *(longlong *)(&stack0x00000118 + lVar16);
      *(undefined8 *)(puVar34 + -8) = 0x102dac;
      func_0x(param_1 + 0x77,lVar22 + 0x78);
    }
    if (bVar11) {
      uVar19 = *(undefined8 *)(&stack0x00000080 + lVar16);
      *(undefined8 *)(puVar34 + -8) = 0x102dc1;
      func_0x(param_1,uVar19);
    }
  }
LAB_:
  uVar19 = *(undefined8 *)(&stack0x00000080 + lVar16);
  pcVar5 = *(code **)(*param_1 + 0x20);
  *(undefined8 *)(puVar34 + -8) = 0x102f12;
  (*pcVar5)(param_1,uVar19);
LAB_:
  uVar40 = *(ulonglong *)(&stack0x00002378 + lVar16);
  *(undefined8 *)(puVar34 + -8) = 0x102f24;
  func_0x(uVar40 ^ (ulonglong)psVar2);
  return;
code_r0x001024d4:
  uVar25 = uVar36;
  if (uVar36 == 0) goto LAB_;
  goto LAB_;
}

