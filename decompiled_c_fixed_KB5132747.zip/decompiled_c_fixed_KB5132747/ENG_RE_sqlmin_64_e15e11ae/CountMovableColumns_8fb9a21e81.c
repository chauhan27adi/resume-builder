
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_(longlong param_1,short *param_2,longlong *param_3,int param_4)

{
  ushort *puVar1;
  longlong lVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  uint uVar7;
  longlong lVar8;
  undefined8 *puVar9;
  ushort uVar10;
  ushort uVar11;
  uint uVar12;
  ulonglong uVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  ulonglong uVar17;
  byte *pbVar18;
  ulonglong uVar19;
  int iVar20;
  int iVar21;
  ushort *puVar22;
  longlong lStackX_10;
  undefined8 uStack_50;
  longlong lStack_48;
  
  uVar15 = 0;
  iVar21 = 0;
  iVar20 = -1;
  if (param_3 != (longlong *)0x0) {
    param_2 = (short *)(**(code **)*param_3)(param_3);
  }
  puVar1 = (ushort *)(param_2 + 1);
  if (*param_2 == 0) {
    uVar7 = func_0x(puVar1);
  }
  else {
    uVar7 = (uint)*puVar1;
  }
  if (0 < (int)uVar7) {
    do {
      if ((~uVar15 & 0xc0000000) == 0x80000000) {
        lVar8 = func_0x
                          (**(undefined8 **)(*(longlong *)(param_1 + 8) + 0x160),
                           ~uVar15 & 0x1fffffff);
      }
      else {
        lVar8 = func_0x(*(undefined8 *)(*(longlong *)(param_1 + 8) + 0x160));
      }
      if ((lVar8 != 0) && ((*(byte *)(lVar8 + 0x21) & 0x10) != 0)) {
        iVar21 = iVar21 + 1;
      }
      uVar15 = uVar15 + 1;
    } while ((int)uVar15 < (int)uVar7);
  }
  if (param_4 == 0) {
    iVar14 = func_0x(param_2);
  }
  else {
    iVar14 = 0;
  }
  uVar15 = 0;
  lStack_48 = (longlong)iVar14;
  if (lStack_48 < 1) {
LAB_:
    if (param_3 != (longlong *)0x0) {
      (**(code **)(*param_3 + 8))();
    }
    return iVar21;
  }
  lStackX_10 = 0;
LAB_:
  iVar14 = 0;
  if (*(int *)(param_2 + 2) == 0) {
    pbVar18 = *(byte **)(param_2 + 4);
    uVar7 = *(uint *)(param_2 + 8);
    uVar13 = (ulonglong)uVar7;
    *puVar1 = 0;
    *(uint *)(param_2 + 10) = uVar7;
    bVar4 = *pbVar18;
    if ((bVar4 & 0x10) != 0) {
      uVar7 = uVar7 + 2 + (*(ushort *)(pbVar18 + uVar13) + 7 >> 3);
      uVar13 = (ulonglong)uVar7;
      *(uint *)(param_2 + 10) = uVar7;
      bVar4 = *pbVar18;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(param_2 + 2) = (int)uVar13;
      param_2[0xe] = 0;
      *(int *)(param_2 + 0xc) = (int)uVar13;
    }
    else {
      puVar22 = (ushort *)(pbVar18 + uVar13);
      uVar6 = *puVar22;
      param_2[0xe] = uVar6;
      if (uVar6 == 0) {
        cVar5 = func_0x(0x11cb4a0);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x11cb4a0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            (*_DAT_)(1,0xabaeac,0xbdaf98,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),3);
        uVar13 = (ulonglong)*(uint *)(param_2 + 10);
        uVar6 = param_2[0xe];
      }
      uVar7 = (int)uVar13 + (uVar6 + 1) * 2;
      *(uint *)(param_2 + 0xc) = uVar7;
      if (0x1f9e < uVar7) {
        cVar5 = func_0x(0x11cb4a0);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x11cb4a0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xabaeac,0xbdaf98,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),4);
        uVar6 = param_2[0xe];
        uVar7 = *(uint *)(param_2 + 0xc);
      }
      uVar13 = (ulonglong)uVar6;
      uVar6 = puVar22[uVar13];
      *(uint *)(param_2 + 2) = uVar6 & 0x7fff;
      if ((uVar6 & 0x7fff) < uVar7) {
        cVar5 = func_0x(0x11cb4a0);
        if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
           (*(char *)(lVar8 + 0x499) != '\0')) {
          cVar5 = func_0x(0x11cb4a0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            (*_DAT_)(1,0xabaeac,0xbdaf98,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),4);
        uVar7 = *(uint *)(param_2 + 0xc);
        uVar13 = (ulonglong)(ushort)param_2[0xe];
      }
      puVar3 = puVar22;
      if ((short)uVar13 != 0) {
        do {
          uVar16 = puVar3[1] & 0x7fff;
          if ((uVar16 < uVar7) || (*(uint *)(param_2 + 2) < uVar16)) {
            cVar5 = func_0x(0x11cb4a0);
            if ((cVar5 != '\0') &&
               ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')
                ))) {
              cVar5 = func_0x(0x11cb4a0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                (*_DAT_)(1,0xabaeac,0xbdaf98,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_2 + 4),4);
          }
          uVar13 = (ulonglong)(ushort)param_2[0xe];
          iVar14 = iVar14 + 1;
          puVar3 = puVar3 + 1;
          uVar7 = uVar16;
        } while (iVar14 < (int)(uint)(ushort)param_2[0xe]);
      }
      if ((short)puVar22[(ulonglong)((int)uVar13 - 1) + 1] < 0) {
        lVar8 = *(longlong *)(param_2 + 4);
        do {
          uVar7 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar8 + uVar13 * 2) & 0x7fff;
          if ((int)uVar13 == 1) {
            uVar16 = *(uint *)(param_2 + 0xc);
            uVar12 = uVar16;
LAB_:
            if ((uVar7 < uVar16) || (*(uint *)(param_2 + 2) < uVar7)) goto LAB_;
          }
          else {
            uVar12 = *(uint *)(param_2 + 0xc);
            uVar16 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar8 + -2 + uVar13 * 2) &
                     0x7fff;
            if (uVar12 <= uVar16) goto LAB_;
LAB_:
            func_0x(lVar8,7);
            uVar12 = *(uint *)(param_2 + 0xc);
          }
          if ((uVar16 < uVar12) || (*(uint *)(param_2 + 2) < uVar16)) goto LAB_;
          lVar8 = *(longlong *)(param_2 + 4);
          if (*(ushort *)(lVar8 + (ulonglong)uVar16) == 5) {
            *puVar1 = *puVar1 | 2;
            param_2[0xe] = param_2[0xe] + -1;
            uVar19 = (ulonglong)(uVar16 & 0xffff);
            param_2[0x15] = (short)uVar16;
            uVar13 = *(ulonglong *)(param_2 + 4);
            uVar6 = param_2[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar19 + 2 + uVar13) >> 0xe & 1) != 0) {
              uVar6 = *(ushort *)(uVar19 + 2 + uVar13) & 0x3800 | param_2[0x16] & 0xc7ffU;
            }
            param_2[0x16] = uVar6;
            uVar11 = (uVar6 ^ *(ushort *)(uVar19 + 2 + uVar13)) & 0x7ff ^ uVar6;
            param_2[0x16] = uVar11;
            uVar17 = (ulonglong)((uVar11 & 0x7ff) * 2) + 4 + uVar13 + (uVar6 >> 0xb & 7) * 2 +
                     uVar19;
            if (uVar17 < uVar19 + uVar13) {
              func_0x(uVar19 + uVar13,0x19);
              uVar11 = param_2[0x16];
              uVar19 = (ulonglong)(ushort)param_2[0x15];
              uVar13 = (ulonglong)*(uint *)(param_2 + 4);
            }
            if (uVar7 - uVar16 < (((uVar11 & 0x7ff) * 2 - (int)uVar19) - (int)uVar13) + (int)uVar17)
            {
              func_0x(uVar19 + *(longlong *)(param_2 + 4),0x19);
              uVar11 = param_2[0x16];
            }
            iVar14 = 0;
            if (((uVar11 & 0x3800) != 0) &&
               (puVar22 = (ushort *)
                          (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
               (uVar11 & 0x3800) != 0)) goto LAB_;
            break;
          }
          if (*(ushort *)(lVar8 + (ulonglong)uVar16) < 0x400) break;
          *puVar1 = *puVar1 | 1;
          uVar6 = param_2[0xe] - 1;
          param_2[0xe] = uVar6;
          if ((uVar6 == 0) ||
             (uVar13 = (ulonglong)uVar6, -1 < (short)puVar22[(ulonglong)(uVar6 - 1) + 1])) break;
        } while( true );
      }
      pbVar18 = *(byte **)(param_2 + 4);
      uVar13 = (ulonglong)*(uint *)(param_2 + 2);
    }
    goto LAB_;
  }
  goto LAB_;
LAB_:
  do {
    if ((uVar11 & 0x7ff) < (*puVar22 & 0x7ff)) {
      func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),0x1a);
      uVar11 = param_2[0x16];
    }
    iVar14 = iVar14 + 1;
    puVar22 = puVar22 + 1;
  } while (iVar14 < (int)(uVar11 >> 0xb & 7));
  pbVar18 = *(byte **)(param_2 + 4);
  uVar13 = (ulonglong)*(uint *)(param_2 + 2);
LAB_:
  if ((*pbVar18 & 0x40) == 0) {
    *(undefined4 *)(param_2 + 0x13) = 0;
  }
  else {
    *(int *)(param_2 + 0x13) = (int)uVar13;
    *(int *)(param_2 + 2) = (int)uVar13 + 0xe;
    puVar9 = (undefined8 *)func_0x(puVar1);
    uStack_50 = *puVar9;
    iVar14 = func_0x(&uStack_50);
    *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar14;
    uVar13 = (ulonglong)*(uint *)(param_2 + 2);
  }
  iVar14 = (int)uVar13;
  if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
     (*(ulonglong *)(param_2 + 0xf) < uVar13 + *(longlong *)(param_2 + 4))) {
    cVar5 = func_0x(0x11cb4a0);
    if ((cVar5 != '\0') &&
       ((lVar8 = func_0x(), lVar8 != 0 && (*(char *)(lVar8 + 0x499) != '\0')))) {
      cVar5 = func_0x(0x11cb4a0);
      if (cVar5 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3fa);
      }
      else {
        (*_DAT_)(1,0xabaeac,0xbdaf98,0x886,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),0x12);
    iVar14 = *(int *)(param_2 + 2);
  }
  if (0x3f3b < iVar14 - 1U) {
    cVar5 = func_0x(0x11cb4a0);
    if (((cVar5 != '\0') && (lVar8 = func_0x(), lVar8 != 0)) &&
       (*(char *)(lVar8 + 0x499) != '\0')) {
      cVar5 = func_0x(0x11cb4a0);
      if (cVar5 == '\0') {
        (*_DAT_)(0x22,0x44,0x15,0x3ed);
      }
      else {
        (*_DAT_)(1,0xabaeac,0xbdaf98,0x88b,0);
      }
    }
    func_0x(*(undefined8 *)(param_2 + 4),5);
  }
LAB_:
  iVar14 = func_0x(puVar1);
  if (iVar14 == 0) {
    iVar14 = func_0x(puVar1);
    if (iVar14 == 0) {
      (*_DAT_)(1,0xc76bc8,0xc67c58,0xd7a,0);
    }
  }
  else {
    uVar6 = param_2[0x16];
    lVar8 = 0;
    if (uVar15 < (uVar6 & 0x7ff)) {
      uVar11 = 0;
      lVar2 = *(longlong *)(param_2 + 4) + (ulonglong)(ushort)param_2[0x15];
      if ((uVar6 & 0x3800) == 0) {
        uVar10 = *(ushort *)(lVar2 + 2);
LAB_:
        uVar11 = uVar10 >> 0xb & 7;
      }
      else if ((uVar6 >> 0xb & 7) != 0) {
        do {
          if (((lVar8 == 0) || ((*(ushort *)(lVar2 + 2 + lVar8 * 2) & 0x7ff) <= uVar15)) &&
             (uVar10 = *(ushort *)(lVar2 + 4 + lVar8 * 2),
             (int)uVar15 <= (int)((uVar10 & 0x7ff) - 1))) goto LAB_;
          lVar8 = lVar8 + 1;
        } while (lVar8 < (longlong)(ulonglong)(uVar6 >> 0xb & 7));
      }
      iVar20 = (uint)*(ushort *)
                      ((ulonglong)((uVar6 >> 0xb & 7) * 2) + *(longlong *)(param_2 + 4) +
                       lStackX_10 * 2 + 4 + (ulonglong)(ushort)param_2[0x15]) +
               (uint)uVar11 * 0x10000;
    }
    else {
      (*_DAT_)(1,0xc76b98,0xc76b60,0x41a,0);
    }
  }
  lVar8 = func_0x(**(undefined8 **)(*(longlong *)(param_1 + 8) + 0x160),iVar20);
  if ((lVar8 != 0) && ((*(byte *)(lVar8 + 0x21) & 0x10) != 0)) {
    iVar21 = iVar21 + 1;
  }
  lStackX_10 = lStackX_10 + 1;
  uVar15 = uVar15 + 1;
  if (lStack_48 <= lStackX_10) goto LAB_;
  goto LAB_;
}

