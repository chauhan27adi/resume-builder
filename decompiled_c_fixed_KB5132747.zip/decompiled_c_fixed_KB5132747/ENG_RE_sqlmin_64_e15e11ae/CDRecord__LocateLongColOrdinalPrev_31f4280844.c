
uint FUN_(longlong param_1,ushort param_2)

{
  longlong lVar1;
  uint uVar2;
  byte bVar3;
  uint uVar4;
  ushort uVar5;
  ulonglong uVar6;
  uint uVar7;
  byte *pbVar9;
  ulonglong uVar10;
  uint uVar11;
  longlong lVar12;
  uint uVar13;
  int iVar14;
  uint uVar15;
  ulonglong uVar16;
  uint uVar17;
  uint uVar18;
  short sVar19;
  ulonglong uVar8;
  
  uVar6 = 0;
  uVar17 = 0;
  uVar18 = 0;
  uVar13 = 0;
  if (param_2 < 0x1f) {
    uVar5 = 1;
    lVar12 = (ulonglong)*(ushort *)(param_1 + 0x16) + *(longlong *)(param_1 + 6);
    uVar11 = uVar13;
  }
  else {
    lVar12 = *(longlong *)(param_1 + 6);
    uVar15 = (int)(param_2 - 1) / 0x1e;
    pbVar9 = (byte *)((ulonglong)*(ushort *)(param_1 + 0x1c) +
                     (ulonglong)*(ushort *)(param_1 + 0x20) + lVar12);
    sVar19 = (short)uVar15;
    uVar11 = uVar17;
    if (sVar19 != 0) {
      uVar10 = (ulonglong)(uVar15 & 0xffff);
      uVar8 = uVar6;
      do {
        bVar3 = *pbVar9;
        if (0x1e < bVar3) {
          func_0x(*(undefined8 *)(param_1 + 6),0x17);
          bVar3 = *pbVar9;
        }
        pbVar9 = pbVar9 + 1;
        uVar11 = (int)uVar8 + (uint)bVar3;
        uVar8 = (ulonglong)uVar11;
        uVar10 = uVar10 - 1;
      } while (uVar10 != 0);
      lVar12 = *(longlong *)(param_1 + 6);
    }
    uVar5 = sVar19 * 0x1e + 1;
    lVar12 = (ulonglong)*(ushort *)(param_1 + 0x16) + (ulonglong)(uVar5 >> 1) + lVar12;
  }
  param_2 = param_2 - uVar5;
  uVar15 = (uint)(param_2 >> 1);
  if (uVar15 < 2) {
    uVar7 = uVar13;
    uVar2 = 0;
    if (param_2 >> 1 == 0) goto LAB_;
  }
  else {
    uVar4 = (uVar15 - 2 >> 1) + 1;
    uVar16 = (ulonglong)uVar4;
    uVar8 = uVar6;
    uVar10 = uVar6;
    do {
      uVar18 = (int)uVar10 + (uint)*(byte *)((ulonglong)*(byte *)(lVar12 + uVar6) + 0x80a740);
      uVar10 = (ulonglong)uVar18;
      lVar1 = uVar6 + 1;
      uVar6 = uVar6 + 2;
      uVar7 = (int)uVar8 + (uint)*(byte *)((ulonglong)*(byte *)(lVar1 + lVar12) + 0x80a740);
      uVar8 = (ulonglong)uVar7;
      uVar16 = uVar16 - 1;
    } while (uVar16 != 0);
    uVar17 = uVar7;
    uVar2 = uVar18;
    if (uVar15 <= uVar4 * 2) goto LAB_;
  }
  uVar18 = uVar2;
  uVar13 = (uint)*(byte *)((ulonglong)*(byte *)(lVar12 + uVar6) + 0x80a740);
  uVar7 = uVar17;
LAB_:
  iVar14 = uVar13 + uVar7 + uVar18;
  if ((param_2 & 1) != 0) {
    iVar14 = iVar14 + (uint)*(byte *)((ulonglong)(*(byte *)((int)(param_2 - 1) / 2 + lVar12) & 0xf)
                                     + 0x80a740);
  }
  if ((uint)*(ushort *)(param_1 + 0x24) < uVar11 + iVar14) {
    func_0x(*(undefined8 *)(param_1 + 6),0x17);
  }
  return uVar11 + iVar14;
}

