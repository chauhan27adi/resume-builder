
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2)

{
  uint uVar1;
  ushort *puVar2;
  char cVar3;
  ushort uVar4;
  ushort uVar5;
  longlong lVar6;
  undefined8 uVar7;
  ulonglong *puVar8;
  undefined4 *puVar9;
  byte bVar10;
  uint uVar11;
  ulonglong uVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  ulonglong uVar17;
  byte *pbVar18;
  ulonglong uVar19;
  int iVar20;
  ushort *puVar21;
  undefined auStackX_10 [8];
  
  iVar14 = 0;
  iVar20 = 0;
  if (param_2 == (short *)0x0) {
    *(undefined *)(param_1 + 0x6e) = 0;
    *(undefined2 *)(param_1 + 0x50) = 0xad8;
    *(undefined4 *)(param_1 + 0x68) = 0;
    return;
  }
  *(undefined *)(param_1 + 0x6e) = 1;
  uVar11 = *(uint *)(param_2 + 2);
  if (*param_2 == 0) {
    if (uVar11 == 0) {
      pbVar18 = *(byte **)(param_2 + 4);
      param_2[1] = 0;
      uVar11 = *(uint *)(param_2 + 8);
      uVar12 = (ulonglong)uVar11;
      *(uint *)(param_2 + 10) = uVar11;
      bVar10 = *pbVar18;
      if ((bVar10 & 0x10) != 0) {
        uVar11 = uVar11 + 2 + (*(ushort *)(pbVar18 + uVar12) + 7 >> 3);
        uVar12 = (ulonglong)uVar11;
        *(uint *)(param_2 + 10) = uVar11;
        bVar10 = *pbVar18;
      }
      if ((bVar10 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar12;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar12;
      }
      else {
        puVar21 = (ushort *)(pbVar18 + uVar12);
        uVar4 = *puVar21;
        param_2[0xe] = uVar4;
        if (uVar4 == 0) {
          cVar3 = func_0x(0x14d7300);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x14d7300);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xdc6d0c,0xee6df8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar12 = (ulonglong)*(uint *)(param_2 + 10);
          uVar4 = param_2[0xe];
        }
        uVar11 = (int)uVar12 + (uVar4 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar11;
        if (0x1f9e < uVar11) {
          cVar3 = func_0x(0x14d7300);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x14d7300);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdc6d0c,0xee6df8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar4 = param_2[0xe];
          uVar11 = *(uint *)(param_2 + 0xc);
        }
        uVar12 = (ulonglong)uVar4;
        uVar4 = puVar21[uVar12];
        *(uint *)(param_2 + 2) = uVar4 & 0x7fff;
        if ((uVar4 & 0x7fff) < uVar11) {
          cVar3 = func_0x(0x14d7300);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x14d7300);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdc6d0c,0xee6df8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar11 = *(uint *)(param_2 + 0xc);
          uVar12 = (ulonglong)(ushort)param_2[0xe];
        }
        puVar2 = puVar21;
        iVar13 = iVar14;
        if ((short)uVar12 != 0) {
          do {
            uVar15 = puVar2[1] & 0x7fff;
            if ((uVar15 < uVar11) || (*(uint *)(param_2 + 2) < uVar15)) {
              cVar3 = func_0x(0x14d7300);
              if ((cVar3 != '\0') &&
                 ((lVar6 = func_0x(), lVar6 != 0 &&
                  (*(char *)(lVar6 + 0x499) != '\0')))) {
                cVar3 = func_0x(0x14d7300);
                if (cVar3 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0xdc6d0c,0xee6df8,0x82a,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
            }
            uVar12 = (ulonglong)(ushort)param_2[0xe];
            iVar13 = iVar13 + 1;
            puVar2 = puVar2 + 1;
            uVar11 = uVar15;
          } while (iVar13 < (int)(uint)(ushort)param_2[0xe]);
        }
        if ((short)puVar21[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
          pbVar18 = *(byte **)(param_2 + 4);
          do {
            uVar15 = *(ushort *)(pbVar18 + uVar12 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff
            ;
            if ((int)uVar12 == 1) {
              uVar16 = *(uint *)(param_2 + 0xc);
              uVar1 = uVar16;
LAB_:
              if ((uVar15 < uVar16) || (uVar11 = *(uint *)(param_2 + 2), uVar11 < uVar15))
              goto LAB_;
            }
            else {
              uVar1 = *(uint *)(param_2 + 0xc);
              uVar16 = *(ushort *)(pbVar18 + uVar12 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2))
                       & 0x7fff;
              if (uVar1 <= uVar16) goto LAB_;
LAB_:
              func_0x(pbVar18,7);
              uVar1 = *(uint *)(param_2 + 0xc);
              uVar11 = *(uint *)(param_2 + 2);
            }
            if ((uVar16 < uVar1) || (uVar11 < uVar16)) goto LAB_;
            pbVar18 = *(byte **)(param_2 + 4);
            if (*(ushort *)(pbVar18 + uVar16) == 5) {
              param_2[1] = param_2[1] | 2;
              param_2[0xe] = param_2[0xe] + -1;
              uVar19 = (ulonglong)(uVar16 & 0xffff);
              param_2[0x15] = (short)uVar16;
              uVar12 = *(ulonglong *)(param_2 + 4);
              uVar4 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar19 + 2 + uVar12) >> 0xe & 1) != 0) {
                uVar4 = *(ushort *)(uVar19 + 2 + uVar12) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar4;
              uVar5 = (uVar4 ^ *(ushort *)(uVar19 + 2 + uVar12)) & 0x7ff ^ uVar4;
              param_2[0x16] = uVar5;
              uVar17 = (ulonglong)((uVar5 & 0x7ff) * 2) + 4 + uVar12 + (uVar4 >> 0xb & 7) * 2 +
                       uVar19;
              if (uVar17 < uVar19 + uVar12) {
                func_0x(uVar19 + uVar12,0x19);
                uVar5 = param_2[0x16];
                uVar19 = (ulonglong)(ushort)param_2[0x15];
                uVar12 = (ulonglong)*(uint *)(param_2 + 4);
              }
              if (uVar15 - uVar16 <
                  (((uVar5 & 0x7ff) * 2 - (int)uVar19) - (int)uVar12) + (int)uVar17) {
                func_0x(uVar19 + *(longlong *)(param_2 + 4),0x19);
                uVar5 = param_2[0x16];
              }
              if (((uVar5 & 0x3800) != 0) &&
                 (puVar21 = (ushort *)
                            (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                 iVar13 = iVar14, (uVar5 & 0x3800) != 0)) {
                do {
                  if ((uVar5 & 0x7ff) < (*puVar21 & 0x7ff)) {
                    func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),
                                    0x1a);
                    uVar5 = param_2[0x16];
                  }
                  iVar13 = iVar13 + 1;
                  puVar21 = puVar21 + 1;
                } while (iVar13 < (int)(uVar5 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar18 + uVar16) < 0x400) goto LAB_;
            param_2[1] = param_2[1] | 1;
            uVar4 = param_2[0xe] - 1;
            param_2[0xe] = uVar4;
            if (uVar4 == 0) goto LAB_;
            uVar12 = (ulonglong)uVar4;
          } while ((short)puVar21[(ulonglong)(uVar4 - 1) + 1] < 0);
          uVar12 = (ulonglong)*(uint *)(param_2 + 2);
        }
        else {
LAB_:
          pbVar18 = *(byte **)(param_2 + 4);
          uVar12 = (ulonglong)*(uint *)(param_2 + 2);
        }
      }
      if ((*pbVar18 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar12;
        *(int *)(param_2 + 2) = (int)uVar12 + 0xe;
        uVar7 = func_0x(param_2 + 1);
        func_0x(uVar7,auStackX_10);
        iVar13 = func_0x(auStackX_10);
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar13;
        uVar12 = (ulonglong)*(uint *)(param_2 + 2);
      }
      uVar11 = (uint)uVar12;
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar12 + *(longlong *)(param_2 + 4))) {
        cVar3 = func_0x(0x14d7300);
        if ((cVar3 != '\0') &&
           ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))))
        {
          cVar3 = func_0x(0x14d7300);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xdc6d0c,0xee6df8,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        uVar11 = *(uint *)(param_2 + 2);
      }
      if ((uVar11 == 0) || (0x3f3c < uVar11)) {
        cVar3 = func_0x(0x14d7300);
        if ((cVar3 != '\0') &&
           ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))))
        {
          cVar3 = func_0x(0x14d7300);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0xdc6d0c,0xee6df8,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
        uVar11 = *(uint *)(param_2 + 2);
      }
    }
LAB_:
    if (uVar11 < 9) {
      bVar10 = **(byte **)(param_2 + 4) & 0xe;
joined_r0x0010075a:
      if ((bVar10 == 0) || (bVar10 == 0xc)) {
        uVar11 = 9;
      }
    }
  }
  else {
    if (uVar11 == 0) {
      func_0x(param_2 + 1);
      uVar11 = *(uint *)(param_2 + 2);
    }
    if (uVar11 < 9) {
      bVar10 = **(byte **)(param_2 + 4) & 0x1c;
      goto joined_r0x0010075a;
    }
  }
  *(short *)(param_1 + 0x50) = (short)uVar11 + 0xad8;
  if (*param_2 == 0) {
    iVar13 = *(int *)(param_2 + 8);
  }
  else if ((**(byte **)(param_2 + 4) & 0x1c) == 4) {
    iVar13 = 1;
  }
  else if ((**(byte **)(param_2 + 4) & 0x1c) == 0x10) {
    iVar13 = 9;
  }
  else {
    iVar13 = (uint)(ushort)param_2[0xe] + (uint)(ushort)param_2[0xd];
  }
  *(int *)(param_1 + 0x68) = iVar13;
  uVar11 = *(uint *)(param_2 + 2);
  if (*param_2 == 0) {
    if (uVar11 == 0) {
      pbVar18 = *(byte **)(param_2 + 4);
      uVar11 = *(uint *)(param_2 + 8);
      uVar12 = (ulonglong)uVar11;
      param_2[1] = 0;
      *(uint *)(param_2 + 10) = uVar11;
      bVar10 = *pbVar18;
      if ((bVar10 & 0x10) != 0) {
        uVar11 = uVar11 + 2 + (*(ushort *)(pbVar18 + uVar12) + 7 >> 3);
        uVar12 = (ulonglong)uVar11;
        *(uint *)(param_2 + 10) = uVar11;
        bVar10 = *pbVar18;
      }
      if ((bVar10 & 0x20) == 0) {
        *(int *)(param_2 + 2) = (int)uVar12;
        param_2[0xe] = 0;
        *(int *)(param_2 + 0xc) = (int)uVar12;
      }
      else {
        puVar21 = (ushort *)(pbVar18 + uVar12);
        uVar4 = *puVar21;
        param_2[0xe] = uVar4;
        if (uVar4 == 0) {
          cVar3 = func_0x(0x14d7300);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x14d7300);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              (*_DAT_)(1,0xdc6d0c,0xee6df8,0x80f,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),3);
          uVar12 = (ulonglong)*(uint *)(param_2 + 10);
          uVar4 = param_2[0xe];
        }
        uVar11 = (int)uVar12 + (uVar4 + 1) * 2;
        *(uint *)(param_2 + 0xc) = uVar11;
        if (0x1f9e < uVar11) {
          cVar3 = func_0x(0x14d7300);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x14d7300);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdc6d0c,0xee6df8,0x816,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar4 = param_2[0xe];
          uVar11 = *(uint *)(param_2 + 0xc);
        }
        uVar12 = (ulonglong)uVar4;
        uVar4 = puVar21[uVar12];
        *(uint *)(param_2 + 2) = uVar4 & 0x7fff;
        if ((uVar4 & 0x7fff) < uVar11) {
          cVar3 = func_0x(0x14d7300);
          if (((cVar3 != '\0') && (lVar6 = func_0x(), lVar6 != 0)) &&
             (*(char *)(lVar6 + 0x499) != '\0')) {
            cVar3 = func_0x(0x14d7300);
            if (cVar3 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              (*_DAT_)(1,0xdc6d0c,0xee6df8,0x81d,0);
            }
          }
          func_0x(*(undefined8 *)(param_2 + 4),4);
          uVar11 = *(uint *)(param_2 + 0xc);
          uVar12 = (ulonglong)(ushort)param_2[0xe];
        }
        puVar2 = puVar21;
        iVar13 = iVar14;
        if ((short)uVar12 != 0) {
          do {
            uVar15 = puVar2[1] & 0x7fff;
            if ((uVar15 < uVar11) || (*(uint *)(param_2 + 2) < uVar15)) {
              cVar3 = func_0x(0x14d7300);
              if ((cVar3 != '\0') &&
                 ((lVar6 = func_0x(), lVar6 != 0 &&
                  (*(char *)(lVar6 + 0x499) != '\0')))) {
                cVar3 = func_0x(0x14d7300);
                if (cVar3 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  (*_DAT_)(1,0xdc6d0c,0xee6df8,0x82a,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),4);
            }
            uVar12 = (ulonglong)(ushort)param_2[0xe];
            iVar13 = iVar13 + 1;
            puVar2 = puVar2 + 1;
            uVar11 = uVar15;
          } while (iVar13 < (int)(uint)(ushort)param_2[0xe]);
        }
        if ((short)puVar21[(ulonglong)((int)uVar12 - 1) + 1] < 0) {
          pbVar18 = *(byte **)(param_2 + 4);
          do {
            uVar15 = *(ushort *)(pbVar18 + uVar12 * 2 + (ulonglong)*(uint *)(param_2 + 10)) & 0x7fff
            ;
            if ((int)uVar12 == 1) {
              uVar16 = *(uint *)(param_2 + 0xc);
              uVar1 = uVar16;
LAB_:
              if ((uVar15 < uVar16) || (uVar11 = *(uint *)(param_2 + 2), uVar11 < uVar15))
              goto LAB_;
            }
            else {
              uVar1 = *(uint *)(param_2 + 0xc);
              uVar16 = *(ushort *)(pbVar18 + uVar12 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2))
                       & 0x7fff;
              if (uVar1 <= uVar16) goto LAB_;
LAB_:
              func_0x(pbVar18,7);
              uVar1 = *(uint *)(param_2 + 0xc);
              uVar11 = *(uint *)(param_2 + 2);
            }
            if ((uVar16 < uVar1) || (uVar11 < uVar16)) goto LAB_;
            pbVar18 = *(byte **)(param_2 + 4);
            if (*(ushort *)(pbVar18 + uVar16) == 5) {
              param_2[1] = param_2[1] | 2;
              param_2[0xe] = param_2[0xe] + -1;
              uVar19 = (ulonglong)(uVar16 & 0xffff);
              param_2[0x15] = (short)uVar16;
              uVar12 = *(ulonglong *)(param_2 + 4);
              uVar4 = param_2[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar19 + 2 + uVar12) >> 0xe & 1) != 0) {
                uVar4 = *(ushort *)(uVar19 + 2 + uVar12) & 0x3800 | param_2[0x16] & 0xc7ffU;
              }
              param_2[0x16] = uVar4;
              uVar5 = (uVar4 ^ *(ushort *)(uVar19 + 2 + uVar12)) & 0x7ff ^ uVar4;
              param_2[0x16] = uVar5;
              uVar17 = uVar12 + 4 +
                       (ulonglong)((uVar5 & 0x7ff) * 2) + uVar19 + (uVar4 >> 0xb & 7) * 2;
              if (uVar17 < uVar19 + uVar12) {
                func_0x(uVar19 + uVar12,0x19);
                uVar5 = param_2[0x16];
                uVar19 = (ulonglong)(ushort)param_2[0x15];
                uVar12 = (ulonglong)*(uint *)(param_2 + 4);
              }
              if (uVar15 - uVar16 <
                  (((uVar5 & 0x7ff) * 2 - (int)uVar19) - (int)uVar12) + (int)uVar17) {
                func_0x(uVar19 + *(longlong *)(param_2 + 4),0x19);
                uVar5 = param_2[0x16];
              }
              if (((uVar5 & 0x3800) != 0) &&
                 (puVar21 = (ushort *)
                            (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]),
                 (uVar5 & 0x3800) != 0)) {
                do {
                  if ((uVar5 & 0x7ff) < (*puVar21 & 0x7ff)) {
                    func_0x((ulonglong)(ushort)param_2[0x15] + *(longlong *)(param_2 + 4),
                                    0x1a);
                    uVar5 = param_2[0x16];
                  }
                  iVar14 = iVar14 + 1;
                  puVar21 = puVar21 + 1;
                } while (iVar14 < (int)(uVar5 >> 0xb & 7));
              }
              goto LAB_;
            }
            if (*(ushort *)(pbVar18 + uVar16) < 0x400) goto LAB_;
            param_2[1] = param_2[1] | 1;
            uVar4 = param_2[0xe] - 1;
            param_2[0xe] = uVar4;
            if (uVar4 == 0) goto LAB_;
            uVar12 = (ulonglong)uVar4;
          } while ((short)puVar21[(ulonglong)(uVar4 - 1) + 1] < 0);
          uVar12 = (ulonglong)*(uint *)(param_2 + 2);
        }
        else {
LAB_:
          pbVar18 = *(byte **)(param_2 + 4);
          uVar12 = (ulonglong)*(uint *)(param_2 + 2);
        }
      }
      if ((*pbVar18 & 0x40) == 0) {
        *(undefined4 *)(param_2 + 0x13) = 0;
      }
      else {
        *(int *)(param_2 + 0x13) = (int)uVar12;
        *(int *)(param_2 + 2) = (int)uVar12 + 0xe;
        puVar8 = (ulonglong *)func_0x(param_2 + 1);
        uVar5 = (ushort)(*puVar8 >> 0x30);
        uVar4 = uVar5;
        if ((((uint)(int)(short)uVar5 >> 1 ^ (int)(short)uVar5) & 0x2000) != 0) {
          uVar4 = uVar5 & 0xdfff;
          if ((uVar5 >> 0xe & 1) != 0) {
            uVar4 = uVar5 | 0x2000;
          }
        }
        if (uVar4 == 0xfffc) {
          iVar20 = (int)((*puVar8 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar20;
        uVar12 = (ulonglong)*(uint *)(param_2 + 2);
      }
      uVar11 = (uint)uVar12;
      if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
         (*(ulonglong *)(param_2 + 0xf) < uVar12 + *(longlong *)(param_2 + 4))) {
        cVar3 = func_0x(0x14d7300);
        if ((cVar3 != '\0') &&
           ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))))
        {
          cVar3 = func_0x(0x14d7300);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            (*_DAT_)(1,0xdc6d0c,0xee6df8,0x886,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),0x12);
        uVar11 = *(uint *)(param_2 + 2);
      }
      if ((uVar11 == 0) || (0x3f3c < uVar11)) {
        cVar3 = func_0x(0x14d7300);
        if ((cVar3 != '\0') &&
           ((lVar6 = func_0x(), lVar6 != 0 && (*(char *)(lVar6 + 0x499) != '\0'))))
        {
          cVar3 = func_0x(0x14d7300);
          if (cVar3 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            (*_DAT_)(1,0xdc6d0c,0xee6df8,0x88b,0);
          }
        }
        func_0x(*(undefined8 *)(param_2 + 4),5);
        uVar11 = *(uint *)(param_2 + 2);
      }
    }
LAB_:
    if (8 < uVar11) goto LAB_;
    bVar10 = **(byte **)(param_2 + 4) & 0xe;
joined_r0x00100edf:
    uVar15 = 9;
    if ((bVar10 != 0) && (bVar10 != 0xc)) goto LAB_;
  }
  else {
    if (uVar11 == 0) {
      func_0x(param_2 + 1);
      uVar11 = *(uint *)(param_2 + 2);
    }
    if (uVar11 < 9) {
      bVar10 = **(byte **)(param_2 + 4) & 0x1c;
      goto joined_r0x00100edf;
    }
LAB_:
    uVar15 = uVar11;
  }
  lVar6 = *(longlong *)(param_2 + 4);
  param_1 = param_1 + 0x7c;
  if (uVar15 == 0) {
    return;
  }
  if (param_1 != 0) {
    if ((lVar6 != 0) && (uVar15 < 0xa59)) {
      func_0x(param_1,lVar6,uVar15);
      return;
    }
    func_0x(param_1,0,0xa58);
    if (lVar6 != 0) {
      if (uVar15 < 0xa59) {
        return;
      }
      puVar9 = (undefined4 *)(*_DAT_)();
      *puVar9 = 0x22;
      goto LAB_;
    }
  }
  puVar9 = (undefined4 *)(*_DAT_)();
  *puVar9 = 0x16;
LAB_:
  (*_DAT_)();
  return;
}

