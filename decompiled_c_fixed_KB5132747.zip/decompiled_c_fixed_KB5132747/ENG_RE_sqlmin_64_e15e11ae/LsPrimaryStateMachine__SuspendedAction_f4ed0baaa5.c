
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,longlong param_2)

{
  longlong lVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  undefined auStack_168 [32];
  ulonglong uStack_148;
  undefined8 uStack_140;
  undefined8 uStack_138;
  longlong *plStack_130;
  undefined4 uStack_128;
  undefined2 uStack_124;
  ulonglong uStack_18;
  
  uStack_138 = 0xfffffffffffffffe;
  uStack_18 = _DAT_ ^ (ulonglong)auStack_168;
  switch(*(undefined4 *)(param_2 + 0x28)) {
  case 2000:
  case 0x7db:
  case 0x7df:
    break;
  case 0x7d2:
  case 0x7d3:
  case 0x7d6:
    func_0x(param_1[0x192]);
    break;
  case 0x7d4:
    lVar1 = param_1[0x192];
    if (*(int *)(lVar1 + 0x1780) == 0) {
      func_0x(lVar1,param_2);
    }
    else {
      uStack_128 = 0;
      uStack_124 = 0;
      plVar3 = (longlong *)func_0x(lVar1,0);
      plStack_130 = plVar3;
      if (plVar3 != (longlong *)0x0) {
        uStack_148 = uStack_148 & 0xffffffff00000000;
        func_0x(plVar3,0x586,0x62,&uStack_128);
        (**(code **)(*plVar3 + 0x10))(plVar3);
      }
    }
    break;
  case 0x7d5:
    func_0x(param_1,param_2);
    break;
  default:
    uVar4 = (**(code **)*param_1)(param_1,*(undefined4 *)(param_2 + 0x28));
    func_0x(param_1,0xbff5a0,uVar4);
    break;
  case 0x7d8:
    func_0x(param_1,param_2);
    break;
  case 0x7d9:
    goto code_r0x00100114;
  case 0x7dc:
    *(undefined4 *)(param_1 + 0x193) = 1;
    break;
  case 0x7dd:
    *(undefined4 *)(param_1 + 0x193) = 0;
  case 0x7d1:
    iVar2 = func_0x(param_1[0x192]);
    if (iVar2 == 0) {
code_r0x00100114:
      func_0x(param_1,0x13caf70,*(undefined8 *)(param_2 + 0x50));
    }
    break;
  case 0x7e0:
    uVar4 = param_1[0x192];
    iVar2 = func_0x(uVar4);
    if ((((iVar2 != 3) && (iVar2 = func_0x(uVar4), iVar2 != 0xd)) &&
        (iVar2 = func_0x(uVar4), iVar2 != 9)) &&
       (iVar2 = func_0x(uVar4), iVar2 != 0xe)) {
      func_0x(param_1,0x13cad30,*(undefined8 *)(param_2 + 0x50));
      uStack_140 = 0;
      uStack_148 = *(ulonglong *)(param_2 + 0x50);
      func_0x(param_1,0x7d2,param_1[0x192],0);
    }
  }
  func_0x(uStack_18 ^ (ulonglong)auStack_168);
  return;
}

