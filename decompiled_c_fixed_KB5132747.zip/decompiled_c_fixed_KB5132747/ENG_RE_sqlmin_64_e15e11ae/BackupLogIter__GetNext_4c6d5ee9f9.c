
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_(longlong param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  ushort uVar3;
  ulonglong uVar4;
  
  if (*(char *)(param_1 + 0x228) != '\x03') {
    uVar4 = 0;
    lVar2 = *(longlong *)(param_1 + 0x230);
    uVar1 = (ulonglong)*(ushort *)(param_1 + 0x218);
    do {
      uVar3 = (short)uVar1 + 1;
      *(ushort *)(param_1 + 0x218) = uVar3;
      if ((uint)uVar3 < *(ushort *)(lVar2 + 2) + 1) {
        uVar1 = func_0x(param_1 + 0x230);
        *(ulonglong *)(param_1 + 0x208) = uVar1;
        if (uVar1 != 0) {
          uVar3 = **(ushort **)(param_1 + 0x230);
          if (4 < uVar3) {
            return uVar1;
          }
          lVar2 = *(longlong *)(param_1 + 600);
          if (lVar2 == 0) {
            lVar2 = (*_DAT_)(0x6000,*(undefined8 *)(param_1 + 0x250),0x104ab40,0x54a,5);
            *(longlong *)(param_1 + 600) = lVar2;
            uVar3 = **(ushort **)(param_1 + 0x230);
          }
          if (uVar3 != 3) {
            if (uVar3 != 4) {
              (*_DAT_)(0x5a,0xe,0x15,4,*(undefined8 *)(param_1 + 0x248),uVar3,3,6);
              return *(ulonglong *)(param_1 + 600);
            }
            func_0x(param_1 + 0x210,uVar1);
            return *(ulonglong *)(param_1 + 600);
          }
          func_0x(param_1 + 0x210,uVar1,lVar2);
          uVar4 = *(ulonglong *)(param_1 + 600);
        }
        return uVar4;
      }
      *(undefined8 *)(param_1 + 0x208) = 0;
      func_0x(param_1);
      lVar2 = *(longlong *)(param_1 + 0x230);
      if (lVar2 == 0) {
        *(undefined *)(param_1 + 0x228) = 3;
        return 0;
      }
      *(undefined2 *)(param_1 + 0x218) = 0;
      uVar1 = uVar4;
    } while (*(char *)(param_1 + 0x228) != '\x03');
  }
  return 0;
}

