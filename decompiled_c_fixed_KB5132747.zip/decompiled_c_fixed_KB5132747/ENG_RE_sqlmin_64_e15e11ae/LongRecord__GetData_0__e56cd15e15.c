
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Removing unreachable block (ram,0x01ea0492) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong *param_2,longlong param_3,undefined4 *param_4)

{
  undefined *puVar1;
  byte bVar2;
  longlong lVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong lVar8;
  code *UNRECOVERED_JUMPTABLE;
  uint uVar9;
  ulonglong uVar10;
  undefined auStackX_20 [8];
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar6 = func_0x();
  lVar6 = -lVar6;
  puVar1 = auStackX_20 + lVar6;
  *(undefined8 *)(&stack0x000000f0 + lVar6) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000020e0 + lVar6) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined4 **)(&stack0x000000e0 + lVar6) = param_4;
  *(longlong *)(&stack0x00000080 + lVar6) = param_3;
  *(longlong **)(&stack0x00000050 + lVar6) = param_2;
  *(longlong *)(&stack0x00000040 + lVar6) = param_1;
  *(undefined8 *)(&stack0x000000a8 + lVar6) = *(undefined8 *)(&stack0x00002160 + lVar6);
  uVar10 = 0;
  *(undefined4 *)(&stack0x00000068 + lVar6) = 0;
  *(undefined4 *)(&stack0x0000007c + lVar6) = 0;
  *(undefined4 *)(&stack0x0000004c + lVar6) = 0;
  *(undefined8 *)(&stack0x00000100 + lVar6) = 0;
  *(undefined8 *)(&stack0x00000108 + lVar6) = 0;
  *(undefined4 *)(&stack0x00000110 + lVar6) = 0;
  *(undefined8 *)(&stack0x00000118 + lVar6) = 0;
  *(undefined4 *)(&stack0x00000120 + lVar6) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar6) = 0x1000ae;
  func_0x(&stack0x00000124 + lVar6,0,0x1f9e);
  *(undefined8 *)(&stack0x00000058 + lVar6) = 0;
  *(undefined8 *)(&stack0x00000060 + lVar6) = 0;
  lVar3 = *param_2;
  *(longlong *)(&stack0x000000e8 + lVar6) = lVar3;
  *(undefined4 *)(&stack0x00000034 + lVar6) = *(undefined4 *)(*(longlong *)(lVar3 + 0x80) + 0x14);
  *(undefined4 *)(&stack0x00000078 + lVar6) = 0;
  *(undefined8 *)(&stack0x000000b0 + lVar6) = 0;
  *(undefined4 *)(&stack0x00000090 + lVar6) = 0;
  *puVar1 = 0;
  (&stack0x00000030)[lVar6] = 0;
  *param_4 = 0;
  if (*(int *)(*(longlong *)(*(longlong *)(param_1 + 0x18) + 8) + 0x100) == 2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  lVar8 = *(longlong *)(param_1 + 8);
  puVar4 = *(undefined8 **)(lVar8 + 0x10);
  if (puVar4 != (undefined8 *)0x0) {
    UNRECOVERED_JUMPTABLE = *(code **)*puVar4;
    *(undefined8 *)((longlong)&uStack_48 + lVar6) = 0x10011f;
    uVar7 = (*UNRECOVERED_JUMPTABLE)(puVar4);
    *(undefined8 *)(*(longlong *)(param_1 + 8) + 8) = uVar7;
    lVar8 = *(longlong *)(param_1 + 8);
  }
  *(undefined8 *)(&stack0x00000028 + lVar6) = *(undefined8 *)(lVar8 + 8);
  *(undefined4 *)(&stack0x00000048 + lVar6) = 0;
  lVar3 = *(longlong *)(*(longlong *)(lVar3 + 0x80) + 0x18);
  *(longlong *)(&stack0x00000070 + lVar6) = lVar3;
  if (*(int *)(&stack0x00000034 + lVar6) != 0) {
    *(undefined8 *)(&stack0x000000a0 + lVar6) = 0;
    bVar2 = *(byte *)(lVar3 + 0x40);
    if (bVar2 < 0x1a) {
      UNRECOVERED_JUMPTABLE =
           (code *)((ulonglong)*(uint *)((longlong)(char)bVar2 * 4 + 0xffe40) + 0xa9830);
                    /* WARNING: Could not emulate address calculation at 0x00100181 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,0,0xa9830,0x800);
      return;
    }
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(longlong **)(lVar8 + 0x10) != (longlong *)0x0) {
    UNRECOVERED_JUMPTABLE = *(code **)(**(longlong **)(lVar8 + 0x10) + 8);
    *(undefined8 *)((longlong)&uStack_48 + lVar6) = 0x1002e4;
    (*UNRECOVERED_JUMPTABLE)();
  }
  if (*(int *)(&stack0x00000064 + lVar6) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((param_3 != 0) && (*(int *)(param_3 + 4) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 8) + 0x10);
  if (plVar5 != (longlong *)0x0) {
    UNRECOVERED_JUMPTABLE = *(code **)(*plVar5 + 8);
    *(undefined8 *)((longlong)&uStack_48 + lVar6) = 0x100314;
    (*UNRECOVERED_JUMPTABLE)();
  }
  if (((*(int *)(&stack0x00000068 + lVar6) == 0) && (*(int *)(&stack0x0000007c + lVar6) == 0)) &&
     (*(int *)(&stack0x0000004c + lVar6) == 0)) {
    **(undefined4 **)(&stack0x000000a8 + lVar6) = 1;
    if ((*(longlong *)(&stack0x00000108 + lVar6) != 0) && (*(uint *)(&stack0x00000100 + lVar6) != 0)
       ) {
      do {
        if ((*(byte *)(*(longlong *)(&stack0x00000108 + lVar6) + 0x18 + uVar10 * 0x40) & 4) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
          halt_baddata();
        }
        uVar9 = (int)uVar10 + 1;
        uVar10 = (ulonglong)uVar9;
      } while (uVar9 < *(uint *)(&stack0x00000100 + lVar6));
    }
    *(undefined8 *)((longlong)&uStack_48 + lVar6) = 0x100399;
    func_0x(*(ulonglong *)(&stack0x000020e0 + lVar6) ^ (ulonglong)puVar1);
    return;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

