
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined *
FUN_(byte **param_1,undefined (*param_2) [16],undefined *param_3,uint param_4,
            undefined *param_5,undefined4 param_6,uint *param_7,uint *param_8)

{
  longlong *plVar1;
  ushort *puVar2;
  byte bVar3;
  char cVar4;
  ushort uVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  longlong lVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  int *piVar12;
  uint uVar13;
  byte *pbVar14;
  ushort uVar15;
  short sVar16;
  uint uVar17;
  byte *pbVar18;
  ushort *puVar19;
  uint uVar20;
  undefined auStackX_8 [8];
  int iStack_68;
  uint uStack_64;
  undefined auStack_60 [8];
  undefined auStack_58 [8];
  undefined auStack_50 [6];
  byte bStack_4a;
  int *piStack_48;
  
  if ((**param_1 & 2) != 0) {
    _auStack_50 = *param_2;
    piVar12 = (int *)0x0;
    uVar15 = SUB162(_auStack_50,6);
    if ((SUB168(_auStack_50,0) >> 0x30 & 0x10) != 0) {
      uVar15 = uVar15 & 0xffef;
      _auStack_50 = SUB168(_auStack_50,0) & 0xffefffffffffffff;
      piStack_48 = (int *)0x0;
    }
    if (param_1[1] == (byte *)0x0) {
      iVar7 = 0;
      if (*(short *)(param_1 + 2) == 0) {
        if ((auStack_50._0_4_ & 0xc0000000) == 0x80000000) {
          iVar7 = func_0x((longlong)param_1 + 0x12);
          if (iVar7 == 0) {
            iStack_68 = 0;
            piVar8 = (int *)0x0;
          }
          else {
            piVar8 = (int *)func_0x((longlong)param_1 + 0x3a,auStack_50,&iStack_68,
                                            auStack_60);
          }
        }
        else {
          pbVar18 = param_1[3];
          bVar3 = *pbVar18;
          iVar6 = iVar7;
          if ((bVar3 & 0x10) == 0) {
            if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
              uVar15 = ~(uVar15 >> 4);
              goto LAB_;
            }
LAB_:
            if ((int)auStack_50._0_4_ < 0) {
              if (*(int *)((longlong)param_1 + 0x14) == 0) {
                uVar17 = *(uint *)(param_1 + 4);
                uVar11 = (ulonglong)uVar17;
                *(uint *)((longlong)param_1 + 0x24) = uVar17;
                *(undefined2 *)((longlong)param_1 + 0x12) = 0;
                bVar3 = *pbVar18;
                if ((bVar3 & 0x10) != 0) {
                  uVar17 = uVar17 + 2 + (*(ushort *)(pbVar18 + uVar11) + 7 >> 3);
                  uVar11 = (ulonglong)uVar17;
                  *(uint *)((longlong)param_1 + 0x24) = uVar17;
                  bVar3 = *pbVar18;
                }
                if ((bVar3 & 0x20) == 0) {
                  *(int *)((longlong)param_1 + 0x14) = (int)uVar11;
                  *(undefined2 *)((longlong)param_1 + 0x2c) = 0;
                  *(int *)(param_1 + 5) = (int)uVar11;
                }
                else {
                  puVar19 = (ushort *)(pbVar18 + uVar11);
                  uVar15 = *puVar19;
                  *(ushort *)((longlong)param_1 + 0x2c) = uVar15;
                  if (uVar15 == 0) {
                    cVar4 = func_0x(0x1e65990);
                    if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                       (*(char *)(lVar9 + 0x499) != '\0')) {
                      cVar4 = func_0x(0x1e65990);
                      if (cVar4 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3eb);
                      }
                      else {
                        (*_DAT_)(1,0x175539c,0x1875488,0x80f,0);
                      }
                    }
                    func_0x(param_1[3],3);
                    uVar15 = *(ushort *)((longlong)param_1 + 0x2c);
                    uVar11 = (ulonglong)*(uint *)((longlong)param_1 + 0x24);
                  }
                  uVar17 = (int)uVar11 + (uVar15 + 1) * 2;
                  *(uint *)(param_1 + 5) = uVar17;
                  if (0x1f9e < uVar17) {
                    cVar4 = func_0x(0x1e65990);
                    if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                       (*(char *)(lVar9 + 0x499) != '\0')) {
                      cVar4 = func_0x(0x1e65990);
                      if (cVar4 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        (*_DAT_)(1,0x175539c,0x1875488,0x816,0);
                      }
                    }
                    func_0x(param_1[3],4);
                    uVar15 = *(ushort *)((longlong)param_1 + 0x2c);
                    uVar17 = *(uint *)(param_1 + 5);
                  }
                  uVar11 = (ulonglong)uVar15;
                  uVar15 = puVar19[uVar11];
                  *(uint *)((longlong)param_1 + 0x14) = uVar15 & 0x7fff;
                  if ((uVar15 & 0x7fff) < uVar17) {
                    cVar4 = func_0x(0x1e65990);
                    if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                       (*(char *)(lVar9 + 0x499) != '\0')) {
                      cVar4 = func_0x(0x1e65990);
                      if (cVar4 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        (*_DAT_)(1,0x175539c,0x1875488,0x81d,0);
                      }
                    }
                    func_0x(param_1[3],4);
                    uVar17 = *(uint *)(param_1 + 5);
                    uVar11 = (ulonglong)*(ushort *)((longlong)param_1 + 0x2c);
                  }
                  piVar8 = piVar12;
                  puVar2 = puVar19;
                  if ((short)uVar11 != 0) {
                    do {
                      uVar13 = puVar2[1] & 0x7fff;
                      if ((uVar13 < uVar17) || (*(uint *)((longlong)param_1 + 0x14) < uVar13)) {
                        cVar4 = func_0x(0x1e65990);
                        if ((cVar4 != '\0') &&
                           ((lVar9 = func_0x(), lVar9 != 0 &&
                            (*(char *)(lVar9 + 0x499) != '\0')))) {
                          cVar4 = func_0x(0x1e65990);
                          if (cVar4 == '\0') {
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            (*_DAT_)(1,0x175539c,0x1875488,0x82a,0);
                          }
                        }
                        func_0x(param_1[3],4);
                      }
                      uVar11 = (ulonglong)*(ushort *)((longlong)param_1 + 0x2c);
                      uVar20 = (int)piVar8 + 1;
                      piVar8 = (int *)(ulonglong)uVar20;
                      puVar2 = puVar2 + 1;
                      uVar17 = uVar13;
                    } while ((int)uVar20 < (int)(uint)*(ushort *)((longlong)param_1 + 0x2c));
                  }
                  if ((short)puVar19[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
                    pbVar18 = param_1[3];
                    do {
                      uVar17 = *(ushort *)
                                (pbVar18 +
                                uVar11 * 2 + (ulonglong)*(uint *)((longlong)param_1 + 0x24)) &
                               0x7fff;
                      if ((int)uVar11 == 1) {
                        uVar13 = *(uint *)(param_1 + 5);
                        uVar20 = uVar13;
LAB_:
                        if ((uVar17 < uVar13) || (*(uint *)((longlong)param_1 + 0x14) < uVar17))
                        goto LAB_;
                      }
                      else {
                        uVar20 = *(uint *)(param_1 + 5);
                        uVar13 = *(ushort *)
                                  (pbVar18 +
                                  uVar11 * 2 + ((ulonglong)*(uint *)((longlong)param_1 + 0x24) - 2))
                                 & 0x7fff;
                        if (uVar20 <= uVar13) goto LAB_;
LAB_:
                        func_0x(pbVar18,7);
                        uVar20 = *(uint *)(param_1 + 5);
                      }
                      if ((uVar13 < uVar20) || (*(uint *)((longlong)param_1 + 0x14) < uVar13))
                      goto LAB_;
                      pbVar18 = param_1[3];
                      if (*(ushort *)(pbVar18 + uVar13) == 5) {
                        *(ushort *)((longlong)param_1 + 0x12) =
                             *(ushort *)((longlong)param_1 + 0x12) | 2;
                        *(short *)((longlong)param_1 + 0x2c) =
                             *(short *)((longlong)param_1 + 0x2c) + -1;
                        uVar15 = *(ushort *)((longlong)param_1 + 0x3c) & 0xc7ff;
                        uVar11 = (ulonglong)(uVar13 & 0xffff);
                        *(short *)((longlong)param_1 + 0x3a) = (short)uVar13;
                        pbVar18 = param_1[3];
                        if ((*(ushort *)(pbVar18 + uVar11 + 2) >> 0xe & 1) != 0) {
                          uVar15 = *(ushort *)(pbVar18 + uVar11 + 2) & 0x3800 | uVar15;
                        }
                        *(ushort *)((longlong)param_1 + 0x3c) = uVar15;
                        uVar5 = (uVar15 ^ *(ushort *)(pbVar18 + uVar11 + 2)) & 0x7ff ^ uVar15;
                        *(ushort *)((longlong)param_1 + 0x3c) = uVar5;
                        pbVar14 = pbVar18 + (ulonglong)((uVar5 & 0x7ff) * 2) +
                                            uVar11 + (uVar15 >> 0xb & 7) * 2 + 4;
                        if (pbVar14 < pbVar18 + uVar11) {
                          func_0x(pbVar18 + uVar11,0x19);
                          uVar5 = *(ushort *)((longlong)param_1 + 0x3c);
                          uVar11 = (ulonglong)*(ushort *)((longlong)param_1 + 0x3a);
                          pbVar18 = (byte *)(ulonglong)*(uint *)(param_1 + 3);
                        }
                        if (uVar17 - uVar13 <
                            (((uVar5 & 0x7ff) * 2 - (int)uVar11) - (int)pbVar18) + (int)pbVar14) {
                          func_0x(param_1[3] + uVar11,0x19);
                          uVar5 = *(ushort *)((longlong)param_1 + 0x3c);
                        }
                        if (((uVar5 & 0x3800) != 0) &&
                           (puVar19 = (ushort *)
                                      (param_1[3] +
                                      (ulonglong)*(ushort *)((longlong)param_1 + 0x3a) + 4),
                           (uVar5 & 0x3800) != 0)) {
                          do {
                            if ((uVar5 & 0x7ff) < (*puVar19 & 0x7ff)) {
                              func_0x(param_1[3] + *(ushort *)((longlong)param_1 + 0x3a),
                                              0x1a);
                              uVar5 = *(ushort *)((longlong)param_1 + 0x3c);
                            }
                            uVar17 = (int)piVar12 + 1;
                            piVar12 = (int *)(ulonglong)uVar17;
                            puVar19 = puVar19 + 1;
                          } while ((int)uVar17 < (int)(uVar5 >> 0xb & 7));
                        }
                        goto LAB_;
                      }
                      if (*(ushort *)(pbVar18 + uVar13) < 0x400) goto LAB_;
                      *(ushort *)((longlong)param_1 + 0x12) =
                           *(ushort *)((longlong)param_1 + 0x12) | 1;
                      uVar15 = *(short *)((longlong)param_1 + 0x2c) - 1;
                      *(ushort *)((longlong)param_1 + 0x2c) = uVar15;
                      if (uVar15 == 0) goto LAB_;
                      uVar11 = (ulonglong)uVar15;
                    } while ((short)puVar19[(ulonglong)(uVar15 - 1) + 1] < 0);
                    uVar11 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
                  }
                  else {
LAB_:
                    pbVar18 = param_1[3];
                    uVar11 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
                  }
                }
                if ((*pbVar18 & 0x40) == 0) {
                  *(undefined4 *)((longlong)param_1 + 0x36) = 0;
                }
                else {
                  *(int *)((longlong)param_1 + 0x36) = (int)uVar11;
                  *(int *)((longlong)param_1 + 0x14) = (int)uVar11 + 0xe;
                  uVar10 = func_0x((longlong)param_1 + 0x12);
                  func_0x(uVar10,auStack_58);
                  iVar6 = func_0x(auStack_58);
                  *(int *)((longlong)param_1 + 0x14) = *(int *)((longlong)param_1 + 0x14) + iVar6;
                  uVar11 = (ulonglong)*(uint *)((longlong)param_1 + 0x14);
                }
                iVar6 = (int)uVar11;
                if ((*(byte **)((longlong)param_1 + 0x2e) != (byte *)0x0) &&
                   (*(byte **)((longlong)param_1 + 0x2e) < param_1[3] + uVar11)) {
                  cVar4 = func_0x(0x1e65990);
                  if ((cVar4 != '\0') &&
                     ((lVar9 = func_0x(), lVar9 != 0 &&
                      (*(char *)(lVar9 + 0x499) != '\0')))) {
                    cVar4 = func_0x(0x1e65990);
                    if (cVar4 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3fa);
                    }
                    else {
                      (*_DAT_)(1,0x175539c,0x1875488,0x886,0);
                    }
                  }
                  func_0x(param_1[3],0x12);
                  iVar6 = *(int *)((longlong)param_1 + 0x14);
                }
                if (0x3f3b < iVar6 - 1U) {
                  cVar4 = func_0x(0x1e65990);
                  if (((cVar4 != '\0') && (lVar9 = func_0x(), lVar9 != 0)) &&
                     (*(char *)(lVar9 + 0x499) != '\0')) {
                    cVar4 = func_0x(0x1e65990);
                    if (cVar4 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ed);
                    }
                    else {
                      (*_DAT_)(1,0x175539c,0x1875488,0x88b,0);
                    }
                  }
                  func_0x(param_1[3],5);
                }
              }
LAB_:
              sVar16 = -auStack_50._0_2_;
              if ((_auStack_50 & (undefined  [16])0x10000000000000) == (undefined  [16])0x0) {
LAB_:
                piVar8 = (int *)param_1[3];
                lVar9 = (longlong)sVar16;
                iStack_68 = iVar7;
                if ((uint)(int)sVar16 <= (uint)*(ushort *)((longlong)param_1 + 0x2c)) {
                  uVar17 = *(uint *)((longlong)param_1 + 0x24);
                  if (sVar16 == 1) {
                    uVar13 = *(uint *)(param_1 + 5);
                    uVar17 = *(ushort *)((longlong)piVar8 + lVar9 * 2 + (ulonglong)uVar17) & 0x7fff;
LAB_:
                    if ((uVar17 < uVar13) || (*(uint *)((longlong)param_1 + 0x14) < uVar17))
                    goto LAB_;
                  }
                  else {
                    puVar19 = (ushort *)((longlong)piVar8 + lVar9 * 2 + (ulonglong)uVar17);
                    uVar13 = *(ushort *)((longlong)piVar8 + lVar9 * 2 + ((ulonglong)uVar17 - 2)) &
                             0x7fff;
                    piVar8 = (int *)param_1[3];
                    uVar17 = *puVar19 & 0x7fff;
                    if (*(uint *)(param_1 + 5) <= uVar13) goto LAB_;
LAB_:
                    func_0x(piVar8,7);
                    piVar8 = (int *)param_1[3];
                  }
                  piVar8 = (int *)((longlong)piVar8 + (ulonglong)uVar13);
                  iStack_68 = uVar17 - uVar13;
                }
              }
              else {
                bVar3 = *param_1[3];
                if ((bVar3 & 0x10) == 0) {
                  if ((1 << (bVar3 & 0xe) & 0x1105U) == 0) goto LAB_;
                }
                else if (((int)auStack_50._0_4_ < (int)*(uint *)(param_1 + 4)) &&
                        ((ushort)auStack_50._4_2_ <=
                         *(ushort *)(param_1[3] + *(uint *)(param_1 + 4)))) goto LAB_;
                piVar8 = piStack_48 + 1;
                iStack_68 = *piStack_48;
              }
            }
            else if ((_auStack_50 & (undefined  [16])0x8000000000000) == (undefined  [16])0x0) {
              if ((_auStack_50 & (undefined  [16])0x10000000000000) != (undefined  [16])0x0) {
                if ((bVar3 & 0x10) == 0) {
                  if ((1 << (bVar3 & 0xe) & 0x1105U) != 0) {
LAB_:
                    piVar8 = piStack_48 + 1;
                    iStack_68 = *piStack_48;
                    goto LAB_;
                  }
                }
                else if (((int)*(uint *)(param_1 + 4) <= (int)auStack_50._0_4_) ||
                        (*(ushort *)(pbVar18 + *(uint *)(param_1 + 4)) < (ushort)auStack_50._4_2_))
                goto LAB_;
              }
              iStack_68 = 0;
              piVar8 = (int *)(pbVar18 + (int)auStack_50._0_4_);
            }
            else {
              iStack_68 = 1;
              piVar8 = (int *)0x14da030;
              if ((pbVar18[(int)auStack_50._0_4_] & (byte)(1 << (bStack_4a & 7))) == 0) {
                piVar8 = (int *)0x14da031;
              }
            }
          }
          else {
            uVar17 = *(uint *)(param_1 + 4);
            if ((int)auStack_50._0_4_ < (int)uVar17) {
              if ((uint)*(ushort *)(pbVar18 + uVar17) < (uint)(ushort)auStack_50._4_2_) {
                uVar15 = ~(uVar15 >> 4);
              }
              else {
                uVar13 = (ushort)auStack_50._4_2_ - 1;
                iVar6 = 1;
                uVar15 = (ushort)(pbVar18[(ulonglong)uVar17 + (ulonglong)(uVar13 >> 3) + 2] >>
                                 ((byte)uVar13 & 7));
              }
            }
            else {
              uVar15 = ~(uVar15 >> 4);
            }
LAB_:
            if ((uVar15 & 1) == 0) {
              if ((iVar6 != 0) ||
                 ((_auStack_50 & (undefined  [16])0x10000000000000) == (undefined  [16])0x0))
              goto LAB_;
              piVar8 = piStack_48 + 1;
              iStack_68 = *piStack_48;
            }
            else {
              iStack_68 = 0;
              piVar8 = piVar12;
            }
          }
        }
      }
      else {
        uStack_64 = 0;
        piVar8 = (int *)func_0x((longlong)param_1 + 0x12,auStack_50,uVar15,&iStack_68,
                                        &uStack_64);
        if ((((*(short *)(param_1 + 2) != 0) &&
             (plVar1 = (longlong *)param_1[4], plVar1 != (longlong *)0x0)) && (*plVar1 != 0)) &&
           (((_auStack_50 & (undefined  [16])0x8000000000000) == (undefined  [16])0x0 &&
            ((uStack_64 & 1) == 0)))) {
          if ((piVar8 == (int *)0x0) || (piVar8 == (int *)0x14da030)) {
            iStack_68 = 0;
            piVar8 = piVar12;
          }
          else {
            piVar8 = (int *)func_0x
                                      (plVar1,auStack_50,piVar8,iStack_68,0,0,&iStack_68,uStack_64);
          }
        }
      }
    }
    else {
      piVar8 = (int *)func_0x(param_1[1] + 0x18,auStack_50,&iStack_68);
    }
LAB_:
    if (piVar8 != (int *)0x0) {
      param_3 = (undefined *)
                func_0x(param_3,param_4,piVar8,iStack_68,param_5,param_6,param_7);
      goto LAB_;
    }
  }
  *param_7 = param_4;
LAB_:
  if ((((**param_1 & 4) != 0) && (1 < *param_7)) &&
     (iVar7 = func_0x(param_1,param_3,*param_7,auStackX_8), iVar7 != 0)) {
    *param_7 = 1;
    *param_8 = *param_8 | 4;
    *param_5 = auStackX_8[0];
    return param_5;
  }
  return param_3;
}

