
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,short *param_2,short *param_3,longlong param_4)

{
  ushort *puVar1;
  longlong *plVar2;
  ushort *puVar3;
  byte bVar4;
  char cVar5;
  ushort uVar6;
  ushort uVar7;
  int iVar8;
  undefined8 uVar9;
  uint *puVar10;
  longlong lVar11;
  short sVar12;
  uint uVar13;
  ulonglong uVar14;
  uint *puVar15;
  uint uVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  byte *pbVar19;
  uint uVar20;
  ushort *puVar21;
  int iVar22;
  int iVar23;
  int aiStackX_10 [2];
  undefined8 uStackX_18;
  longlong lStackX_20;
  ulonglong in_stack_ffffffffffffff58;
  uint *puVar24;
  uint uStack_88;
  uint uStack_84;
  undefined auStack_80 [4];
  undefined auStack_7c [4];
  uint uStack_78;
  undefined2 uStack_74;
  undefined auStack_70 [8];
  undefined auStack_68 [8];
  uint uStack_60;
  ushort uStack_5c;
  ushort uStack_5a;
  int *piStack_58;
  
  puVar15 = (uint *)0x0;
  puVar24 = (uint *)(in_stack_ffffffffffffff58 & 0xffffffff00000000);
  uStackX_18 = param_3;
  lStackX_20 = param_4;
  func_0x(&uStack_60,0xfffffffb,5,0,puVar24);
  puVar1 = (ushort *)(param_2 + 1);
  iVar23 = 1;
  iVar22 = 0;
  if (*param_2 == 0) {
    if ((uStack_60 & 0xc0000000) == 0x80000000) {
      iVar8 = func_0x(puVar1);
      if (iVar8 == 0) {
LAB_:
        puVar10 = (uint *)0x0;
        aiStackX_10[0] = 0;
      }
      else {
        puVar10 = (uint *)func_0x(param_2 + 0x15,&uStack_60,aiStackX_10,auStack_80);
      }
    }
    else {
      pbVar19 = *(byte **)(param_2 + 4);
      bVar4 = *pbVar19;
      iVar8 = iVar22;
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
          uVar6 = ~(uStack_5a >> 4);
          goto LAB_;
        }
LAB_:
        if ((int)uStack_60 < 0) {
          if (*(int *)(param_2 + 2) == 0) {
            uVar13 = *(uint *)(param_2 + 8);
            uVar14 = (ulonglong)uVar13;
            *(uint *)(param_2 + 10) = uVar13;
            *puVar1 = 0;
            bVar4 = *pbVar19;
            if ((bVar4 & 0x10) != 0) {
              uVar13 = uVar13 + 2 + (*(ushort *)(pbVar19 + uVar14) + 7 >> 3);
              uVar14 = (ulonglong)uVar13;
              *(uint *)(param_2 + 10) = uVar13;
              bVar4 = *pbVar19;
            }
            if ((bVar4 & 0x20) == 0) {
              *(int *)(param_2 + 2) = (int)uVar14;
              param_2[0xe] = 0;
              *(int *)(param_2 + 0xc) = (int)uVar14;
            }
            else {
              puVar21 = (ushort *)(pbVar19 + uVar14);
              uVar6 = *puVar21;
              param_2[0xe] = uVar6;
              if (uVar6 == 0) {
                cVar5 = func_0x(0x2860ee0);
                if (((cVar5 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
                   (*(char *)(lVar11 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x2860ee0);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    puVar24 = (uint *)0x0;
                    (*_DAT_)(1,0x21508ec,0x22709d8,0x80f,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),3);
                uVar14 = (ulonglong)*(uint *)(param_2 + 10);
                uVar6 = param_2[0xe];
              }
              uVar13 = (int)uVar14 + (uVar6 + 1) * 2;
              *(uint *)(param_2 + 0xc) = uVar13;
              if (0x1f9e < uVar13) {
                cVar5 = func_0x(0x2860ee0);
                if (((cVar5 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
                   (*(char *)(lVar11 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x2860ee0);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puVar24 = (uint *)0x0;
                    (*_DAT_)(1,0x21508ec,0x22709d8,0x816,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),4);
                uVar6 = param_2[0xe];
                uVar13 = *(uint *)(param_2 + 0xc);
              }
              uVar14 = (ulonglong)uVar6;
              uVar6 = puVar21[uVar14];
              *(uint *)(param_2 + 2) = uVar6 & 0x7fff;
              if ((uVar6 & 0x7fff) < uVar13) {
                cVar5 = func_0x(0x2860ee0);
                if (((cVar5 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
                   (*(char *)(lVar11 + 0x499) != '\0')) {
                  cVar5 = func_0x(0x2860ee0);
                  if (cVar5 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puVar24 = (uint *)0x0;
                    (*_DAT_)(1,0x21508ec,0x22709d8,0x81d,0);
                  }
                }
                func_0x(*(undefined8 *)(param_2 + 4),4);
                uVar13 = *(uint *)(param_2 + 0xc);
                uVar14 = (ulonglong)(ushort)param_2[0xe];
              }
              puVar10 = puVar15;
              puVar3 = puVar21;
              if ((short)uVar14 != 0) {
                do {
                  uVar16 = puVar3[1] & 0x7fff;
                  if ((uVar16 < uVar13) || (*(uint *)(param_2 + 2) < uVar16)) {
                    cVar5 = func_0x(0x2860ee0);
                    if ((cVar5 != '\0') &&
                       ((lVar11 = func_0x(), lVar11 != 0 &&
                        (*(char *)(lVar11 + 0x499) != '\0')))) {
                      cVar5 = func_0x(0x2860ee0);
                      if (cVar5 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        puVar24 = (uint *)0x0;
                        (*_DAT_)(1,0x21508ec,0x22709d8,0x82a,0);
                      }
                    }
                    func_0x(*(undefined8 *)(param_2 + 4),4);
                  }
                  uVar14 = (ulonglong)(ushort)param_2[0xe];
                  uVar20 = (int)puVar10 + 1;
                  puVar10 = (uint *)(ulonglong)uVar20;
                  puVar3 = puVar3 + 1;
                  uVar13 = uVar16;
                } while ((int)uVar20 < (int)(uint)(ushort)param_2[0xe]);
              }
              if ((short)puVar21[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
                pbVar19 = *(byte **)(param_2 + 4);
                do {
                  uVar13 = *(ushort *)(pbVar19 + uVar14 * 2 + (ulonglong)*(uint *)(param_2 + 10)) &
                           0x7fff;
                  if ((int)uVar14 == 1) {
                    uVar16 = *(uint *)(param_2 + 0xc);
                    uVar20 = uVar16;
LAB_:
                    if ((uVar13 < uVar16) || (*(uint *)(param_2 + 2) < uVar13)) goto LAB_;
                  }
                  else {
                    uVar20 = *(uint *)(param_2 + 0xc);
                    uVar16 = *(ushort *)
                              (pbVar19 + uVar14 * 2 + ((ulonglong)*(uint *)(param_2 + 10) - 2)) &
                             0x7fff;
                    if (uVar20 <= uVar16) goto LAB_;
LAB_:
                    func_0x(pbVar19,7);
                    uVar20 = *(uint *)(param_2 + 0xc);
                  }
                  if ((uVar16 < uVar20) || (*(uint *)(param_2 + 2) < uVar16)) goto LAB_;
                  pbVar19 = *(byte **)(param_2 + 4);
                  if (*(ushort *)(pbVar19 + uVar16) == 5) {
                    *puVar1 = *puVar1 | 2;
                    param_2[0xe] = param_2[0xe] + -1;
                    uVar18 = (ulonglong)(uVar16 & 0xffff);
                    param_2[0x15] = (short)uVar16;
                    uVar14 = *(ulonglong *)(param_2 + 4);
                    uVar6 = param_2[0x16] & 0xc7ffU;
                    if ((*(ushort *)(uVar18 + 2 + uVar14) >> 0xe & 1) != 0) {
                      uVar6 = *(ushort *)(uVar18 + 2 + uVar14) & 0x3800 | param_2[0x16] & 0xc7ffU;
                    }
                    param_2[0x16] = uVar6;
                    uVar7 = (uVar6 ^ *(ushort *)(uVar18 + 2 + uVar14)) & 0x7ff ^ uVar6;
                    param_2[0x16] = uVar7;
                    uVar17 = uVar14 + 4 +
                             (ulonglong)((uVar7 & 0x7ff) * 2) + uVar18 + (uVar6 >> 0xb & 7) * 2;
                    if (uVar17 < uVar18 + uVar14) {
                      func_0x(uVar18 + uVar14,0x19);
                      uVar7 = param_2[0x16];
                      uVar18 = (ulonglong)(ushort)param_2[0x15];
                      uVar14 = (ulonglong)*(uint *)(param_2 + 4);
                    }
                    if (uVar13 - uVar16 <
                        (((uVar7 & 0x7ff) * 2 - (int)uVar18) - (int)uVar14) + (int)uVar17) {
                      func_0x(uVar18 + *(longlong *)(param_2 + 4),0x19);
                      uVar7 = param_2[0x16];
                    }
                    if (((uVar7 & 0x3800) != 0) &&
                       (puVar21 = (ushort *)
                                  (*(longlong *)(param_2 + 4) + 4 + (ulonglong)(ushort)param_2[0x15]
                                  ), puVar10 = puVar15, (uVar7 & 0x3800) != 0)) {
                      do {
                        if ((uVar7 & 0x7ff) < (*puVar21 & 0x7ff)) {
                          func_0x((ulonglong)(ushort)param_2[0x15] +
                                          *(longlong *)(param_2 + 4),0x1a);
                          uVar7 = param_2[0x16];
                        }
                        uVar13 = (int)puVar10 + 1;
                        puVar10 = (uint *)(ulonglong)uVar13;
                        puVar21 = puVar21 + 1;
                      } while ((int)uVar13 < (int)(uVar7 >> 0xb & 7));
                    }
                    goto LAB_;
                  }
                  if (*(ushort *)(pbVar19 + uVar16) < 0x400) goto LAB_;
                  *puVar1 = *puVar1 | 1;
                  uVar6 = param_2[0xe] - 1;
                  param_2[0xe] = uVar6;
                  if (uVar6 == 0) goto LAB_;
                  uVar14 = (ulonglong)uVar6;
                } while ((short)puVar21[(ulonglong)(uVar6 - 1) + 1] < 0);
                uVar14 = (ulonglong)*(uint *)(param_2 + 2);
              }
              else {
LAB_:
                pbVar19 = *(byte **)(param_2 + 4);
                uVar14 = (ulonglong)*(uint *)(param_2 + 2);
              }
            }
            if ((*pbVar19 & 0x40) == 0) {
              *(undefined4 *)(param_2 + 0x13) = 0;
            }
            else {
              *(int *)(param_2 + 0x13) = (int)uVar14;
              *(int *)(param_2 + 2) = (int)uVar14 + 0xe;
              uVar9 = func_0x(puVar1);
              func_0x(uVar9,auStack_70);
              iVar8 = func_0x(auStack_70);
              *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar8;
              uVar14 = (ulonglong)*(uint *)(param_2 + 2);
            }
            iVar8 = (int)uVar14;
            if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
               (*(ulonglong *)(param_2 + 0xf) < uVar14 + *(longlong *)(param_2 + 4))) {
              cVar5 = func_0x(0x2860ee0);
              if ((cVar5 != '\0') &&
                 ((lVar11 = func_0x(), lVar11 != 0 &&
                  (*(char *)(lVar11 + 0x499) != '\0')))) {
                cVar5 = func_0x(0x2860ee0);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  puVar24 = (uint *)0x0;
                  (*_DAT_)(1,0x21508ec,0x22709d8,0x886,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),0x12);
              iVar8 = *(int *)(param_2 + 2);
            }
            if (0x3f3b < iVar8 - 1U) {
              cVar5 = func_0x(0x2860ee0);
              if (((cVar5 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
                 (*(char *)(lVar11 + 0x499) != '\0')) {
                cVar5 = func_0x(0x2860ee0);
                if (cVar5 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  puVar24 = (uint *)0x0;
                  (*_DAT_)(1,0x21508ec,0x22709d8,0x88b,0);
                }
              }
              func_0x(*(undefined8 *)(param_2 + 4),5);
            }
          }
LAB_:
          sVar12 = -(short)uStack_60;
          param_3 = uStackX_18;
          if ((uStack_5a & 0x10) == 0) {
LAB_:
            puVar10 = *(uint **)(param_2 + 4);
            lVar11 = (longlong)sVar12;
            aiStackX_10[0] = iVar22;
            if ((uint)(int)sVar12 <= (uint)(ushort)param_2[0xe]) {
              uVar13 = *(uint *)(param_2 + 10);
              if (sVar12 == 1) {
                uVar16 = *(uint *)(param_2 + 0xc);
                uVar13 = *(ushort *)((longlong)puVar10 + lVar11 * 2 + (ulonglong)uVar13) & 0x7fff;
LAB_:
                if ((uVar13 < uVar16) || (*(uint *)(param_2 + 2) < uVar13)) goto LAB_;
              }
              else {
                puVar1 = (ushort *)((longlong)puVar10 + lVar11 * 2 + (ulonglong)uVar13);
                uVar16 = *(ushort *)((longlong)puVar10 + lVar11 * 2 + ((ulonglong)uVar13 - 2)) &
                         0x7fff;
                puVar10 = *(uint **)(param_2 + 4);
                uVar13 = *puVar1 & 0x7fff;
                if (*(uint *)(param_2 + 0xc) <= uVar16) goto LAB_;
LAB_:
                func_0x(puVar10,7);
                puVar10 = *(uint **)(param_2 + 4);
              }
              puVar10 = (uint *)((longlong)puVar10 + (ulonglong)uVar16);
              param_3 = uStackX_18;
              aiStackX_10[0] = uVar13 - uVar16;
            }
          }
          else {
            bVar4 = **(byte **)(param_2 + 4);
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) == 0) goto LAB_;
            }
            else if (((int)uStack_60 < (int)*(uint *)(param_2 + 8)) &&
                    (uStack_5c <= *(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8))))
            goto LAB_;
            puVar10 = (uint *)(piStack_58 + 1);
            aiStackX_10[0] = *piStack_58;
          }
        }
        else if ((uStack_5a & 8) == 0) {
          if ((uStack_5a & 0x10) != 0) {
            if ((bVar4 & 0x10) == 0) {
              if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
                puVar10 = (uint *)(piStack_58 + 1);
                aiStackX_10[0] = *piStack_58;
                goto LAB_;
              }
            }
            else if (((int)*(uint *)(param_2 + 8) <= (int)uStack_60) ||
                    (*(ushort *)(pbVar19 + *(uint *)(param_2 + 8)) < uStack_5c)) goto LAB_;
          }
          puVar10 = (uint *)(pbVar19 + (int)uStack_60);
          aiStackX_10[0] = 0;
        }
        else {
          puVar10 = (uint *)0x1ed5580;
          aiStackX_10[0] = 1;
          if ((pbVar19[(int)uStack_60] & (byte)(1 << ((byte)uStack_5a & 7))) == 0) {
            puVar10 = (uint *)0x1ed5581;
          }
        }
      }
      else {
        uVar13 = *(uint *)(param_2 + 8);
        if ((int)uStack_60 < (int)uVar13) {
          if ((uint)*(ushort *)(pbVar19 + uVar13) < (uint)uStack_5c) {
            uVar6 = ~(uStack_5a >> 4);
          }
          else {
            uVar16 = uStack_5c - 1;
            uVar6 = (ushort)(pbVar19[(ulonglong)uVar13 + (ulonglong)(uVar16 >> 3) + 2] >>
                            ((byte)uVar16 & 7));
            iVar8 = iVar23;
          }
        }
        else {
          uVar6 = ~(uStack_5a >> 4);
        }
LAB_:
        if ((uVar6 & 1) == 0) {
          if ((iVar8 != 0) || ((uStack_5a & 0x10) == 0)) goto LAB_;
          puVar10 = (uint *)(piStack_58 + 1);
          aiStackX_10[0] = *piStack_58;
        }
        else {
          aiStackX_10[0] = 0;
          puVar10 = puVar15;
        }
      }
    }
  }
  else {
    puVar24 = &uStack_88;
    uStack_88 = 0;
    puVar10 = (uint *)func_0x(puVar1,&uStack_60);
    if ((((*param_2 != 0) && (plVar2 = *(longlong **)(param_2 + 8), plVar2 != (longlong *)0x0)) &&
        (*plVar2 != 0)) && (((uStack_5a & 8) == 0 && ((uStack_88 & 1) == 0)))) {
      if ((puVar10 == (uint *)0x0) || (puVar10 == (uint *)0x1ed5580)) goto LAB_;
      puVar24 = (uint *)0x0;
      puVar10 = (uint *)func_0x(plVar2,&uStack_60,puVar10,aiStackX_10[0],0,0,aiStackX_10,
                                        uStack_88);
    }
  }
LAB_:
  puVar1 = (ushort *)(param_3 + 1);
  uVar13 = *puVar10;
  uStackX_18 = (short *)CONCAT44(uStackX_18._4_4_,uVar13);
  if (*param_3 != 0) {
    puVar24 = &uStack_84;
    uStack_84 = 0;
    puVar10 = (uint *)func_0x(puVar1,&uStack_60);
    if ((((*param_3 != 0) && (plVar2 = *(longlong **)(param_3 + 8), plVar2 != (longlong *)0x0)) &&
        (*plVar2 != 0)) && (((uStack_5a & 8) == 0 && ((uStack_84 & 1) == 0)))) {
      if ((puVar10 == (uint *)0x0) || (puVar10 == (uint *)0x1ed5580)) {
        aiStackX_10[0] = 0;
        puVar10 = puVar15;
      }
      else {
        puVar24 = (uint *)0x0;
        puVar10 = (uint *)func_0x(plVar2,&uStack_60,puVar10,aiStackX_10[0],0,0,aiStackX_10,
                                          uStack_84);
      }
    }
    goto LAB_;
  }
  if ((uStack_60 & 0xc0000000) == 0x80000000) {
    iVar23 = func_0x(puVar1);
    if (iVar23 == 0) {
      aiStackX_10[0] = 0;
      puVar10 = (uint *)0x0;
    }
    else {
      puVar10 = (uint *)func_0x(param_3 + 0x15,&uStack_60,aiStackX_10,auStack_7c,puVar24);
    }
    goto LAB_;
  }
  pbVar19 = *(byte **)(param_3 + 4);
  bVar4 = *pbVar19;
  if ((bVar4 & 0x10) == 0) {
    if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
      uVar6 = ~(uStack_5a >> 4);
      iVar23 = iVar22;
      goto LAB_;
    }
  }
  else {
    uVar16 = *(uint *)(param_3 + 8);
    if ((int)uStack_60 < (int)uVar16) {
      if ((uint)*(ushort *)(pbVar19 + uVar16) < (uint)uStack_5c) {
        uVar6 = ~(uStack_5a >> 4);
        iVar23 = iVar22;
      }
      else {
        uVar20 = uStack_5c - 1;
        uVar6 = (ushort)(pbVar19[(ulonglong)(uVar20 >> 3) + (ulonglong)uVar16 + 2] >>
                        ((byte)uVar20 & 7));
      }
    }
    else {
      uVar6 = ~(uStack_5a >> 4);
      iVar23 = iVar22;
    }
LAB_:
    if ((uVar6 & 1) != 0) {
      aiStackX_10[0] = 0;
      puVar10 = puVar15;
      goto LAB_;
    }
    if ((iVar23 == 0) && ((uStack_5a & 0x10) != 0)) {
      aiStackX_10[0] = *piStack_58;
      puVar10 = (uint *)(piStack_58 + 1);
      goto LAB_;
    }
  }
  if (-1 < (int)uStack_60) {
    if ((uStack_5a & 8) != 0) {
      aiStackX_10[0] = 1;
      puVar10 = (uint *)0x1ed5580;
      if ((pbVar19[(int)uStack_60] & (byte)(1 << ((byte)uStack_5a & 7))) == 0) {
        puVar10 = (uint *)0x1ed5581;
      }
      goto LAB_;
    }
    if ((uStack_5a & 0x10) != 0) {
      if ((bVar4 & 0x10) == 0) {
        if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
          aiStackX_10[0] = *piStack_58;
          puVar10 = (uint *)(piStack_58 + 1);
          goto LAB_;
        }
      }
      else if (((int)*(uint *)(param_3 + 8) <= (int)uStack_60) ||
              (*(ushort *)(pbVar19 + *(uint *)(param_3 + 8)) < uStack_5c)) goto LAB_;
    }
    aiStackX_10[0] = 0;
    puVar10 = (uint *)(pbVar19 + (int)uStack_60);
    goto LAB_;
  }
  if (*(int *)(param_3 + 2) == 0) {
    uVar13 = *(uint *)(param_3 + 8);
    uVar14 = (ulonglong)uVar13;
    *(uint *)(param_3 + 10) = uVar13;
    *puVar1 = 0;
    bVar4 = *pbVar19;
    if ((bVar4 & 0x10) != 0) {
      uVar13 = uVar13 + 2 + (*(ushort *)(pbVar19 + uVar14) + 7 >> 3);
      uVar14 = (ulonglong)uVar13;
      *(uint *)(param_3 + 10) = uVar13;
      bVar4 = *pbVar19;
    }
    if ((bVar4 & 0x20) == 0) {
      *(int *)(param_3 + 2) = (int)uVar14;
      param_3[0xe] = 0;
      *(int *)(param_3 + 0xc) = (int)uVar14;
    }
    else {
      puVar21 = (ushort *)(pbVar19 + uVar14);
      uVar6 = *puVar21;
      param_3[0xe] = uVar6;
      if (uVar6 == 0) {
        cVar5 = func_0x(0x2860ee0);
        if (((cVar5 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
           (*(char *)(lVar11 + 0x499) != '\0')) {
          cVar5 = func_0x(0x2860ee0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3eb);
          }
          else {
            puVar24 = (uint *)0x0;
            (*_DAT_)(1,0x21508ec,0x22709d8,0x80f,0);
          }
        }
        func_0x(*(undefined8 *)(param_3 + 4),3);
        uVar14 = (ulonglong)*(uint *)(param_3 + 10);
        uVar6 = param_3[0xe];
      }
      uVar13 = (int)uVar14 + (uVar6 + 1) * 2;
      *(uint *)(param_3 + 0xc) = uVar13;
      if (0x1f9e < uVar13) {
        cVar5 = func_0x(0x2860ee0);
        if (((cVar5 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
           (*(char *)(lVar11 + 0x499) != '\0')) {
          cVar5 = func_0x(0x2860ee0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puVar24 = (uint *)0x0;
            (*_DAT_)(1,0x21508ec,0x22709d8,0x816,0);
          }
        }
        func_0x(*(undefined8 *)(param_3 + 4),4);
        uVar6 = param_3[0xe];
        uVar13 = *(uint *)(param_3 + 0xc);
      }
      uVar14 = (ulonglong)uVar6;
      uVar6 = puVar21[uVar14];
      *(uint *)(param_3 + 2) = uVar6 & 0x7fff;
      if ((uVar6 & 0x7fff) < uVar13) {
        cVar5 = func_0x(0x2860ee0);
        if (((cVar5 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
           (*(char *)(lVar11 + 0x499) != '\0')) {
          cVar5 = func_0x(0x2860ee0);
          if (cVar5 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ec);
          }
          else {
            puVar24 = (uint *)0x0;
            (*_DAT_)(1,0x21508ec,0x22709d8,0x81d,0);
          }
        }
        func_0x(*(undefined8 *)(param_3 + 4),4);
        uVar13 = *(uint *)(param_3 + 0xc);
        uVar14 = (ulonglong)(ushort)param_3[0xe];
      }
      puVar10 = puVar15;
      puVar3 = puVar21;
      if ((short)uVar14 != 0) {
        do {
          uVar16 = puVar3[1] & 0x7fff;
          if ((uVar16 < uVar13) || (*(uint *)(param_3 + 2) < uVar16)) {
            cVar5 = func_0x(0x2860ee0);
            if ((cVar5 != '\0') &&
               ((lVar11 = func_0x(), lVar11 != 0 &&
                (*(char *)(lVar11 + 0x499) != '\0')))) {
              cVar5 = func_0x(0x2860ee0);
              if (cVar5 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ec);
              }
              else {
                puVar24 = (uint *)0x0;
                (*_DAT_)(1,0x21508ec,0x22709d8,0x82a,0);
              }
            }
            func_0x(*(undefined8 *)(param_3 + 4),4);
          }
          uVar14 = (ulonglong)(ushort)param_3[0xe];
          uVar20 = (int)puVar10 + 1;
          puVar10 = (uint *)(ulonglong)uVar20;
          puVar3 = puVar3 + 1;
          uVar13 = uVar16;
        } while ((int)uVar20 < (int)(uint)(ushort)param_3[0xe]);
      }
      if ((short)puVar21[(ulonglong)((int)uVar14 - 1) + 1] < 0) {
        pbVar19 = *(byte **)(param_3 + 4);
        do {
          uVar13 = *(ushort *)(pbVar19 + uVar14 * 2 + (ulonglong)*(uint *)(param_3 + 10)) & 0x7fff;
          if ((int)uVar14 == 1) {
            uVar16 = *(uint *)(param_3 + 0xc);
            uVar20 = uVar16;
LAB_:
            if ((uVar13 < uVar16) || (*(uint *)(param_3 + 2) < uVar13)) goto LAB_;
          }
          else {
            uVar20 = *(uint *)(param_3 + 0xc);
            uVar16 = *(ushort *)(pbVar19 + uVar14 * 2 + ((ulonglong)*(uint *)(param_3 + 10) - 2)) &
                     0x7fff;
            if (uVar20 <= uVar16) goto LAB_;
LAB_:
            func_0x(pbVar19,7);
            uVar20 = *(uint *)(param_3 + 0xc);
          }
          if ((uVar16 < uVar20) || (*(uint *)(param_3 + 2) < uVar16)) goto LAB_;
          pbVar19 = *(byte **)(param_3 + 4);
          if (*(ushort *)(pbVar19 + uVar16) == 5) {
            *puVar1 = *puVar1 | 2;
            param_3[0xe] = param_3[0xe] + -1;
            uVar14 = *(ulonglong *)(param_3 + 4);
            uVar18 = (ulonglong)(uVar16 & 0xffff);
            param_3[0x15] = (short)uVar16;
            uVar6 = param_3[0x16] & 0xc7ffU;
            if ((*(ushort *)(uVar18 + 2 + uVar14) >> 0xe & 1) != 0) {
              uVar6 = *(ushort *)(uVar18 + 2 + uVar14) & 0x3800 | param_3[0x16] & 0xc7ffU;
            }
            param_3[0x16] = uVar6;
            uVar17 = (ulonglong)(ushort)param_3[0x15];
            uVar7 = (uVar6 ^ *(ushort *)(uVar18 + 2 + uVar14)) & 0x7ff ^ uVar6;
            param_3[0x16] = uVar7;
            uVar18 = (ulonglong)((uVar7 & 0x7ff) * 2) + 4 + uVar17 + (uVar6 >> 0xb & 7) * 2 + uVar14
            ;
            if (uVar18 < uVar17 + uVar14) {
              func_0x(uVar17 + uVar14,0x19);
              uVar7 = param_3[0x16];
              uVar17 = (ulonglong)(ushort)param_3[0x15];
              uVar14 = (ulonglong)*(uint *)(param_3 + 4);
            }
            if (uVar13 - uVar16 < (((uVar7 & 0x7ff) * 2 - (int)uVar17) - (int)uVar14) + (int)uVar18)
            {
              func_0x(uVar17 + *(longlong *)(param_3 + 4),0x19);
              uVar7 = param_3[0x16];
            }
            if (((uVar7 & 0x3800) != 0) &&
               (puVar21 = (ushort *)
                          (*(longlong *)(param_3 + 4) + 4 + (ulonglong)(ushort)param_3[0x15]),
               (uVar7 & 0x3800) != 0)) {
              do {
                if ((uVar7 & 0x7ff) < (*puVar21 & 0x7ff)) {
                  func_0x((ulonglong)(ushort)param_3[0x15] + *(longlong *)(param_3 + 4),0x1a
                                 );
                  uVar7 = param_3[0x16];
                }
                uVar13 = (int)puVar15 + 1;
                puVar15 = (uint *)(ulonglong)uVar13;
                puVar21 = puVar21 + 1;
              } while ((int)uVar13 < (int)(uVar7 >> 0xb & 7));
            }
            goto LAB_;
          }
          if (*(ushort *)(pbVar19 + uVar16) < 0x400) goto LAB_;
          *puVar1 = *puVar1 | 1;
          uVar6 = param_3[0xe] - 1;
          param_3[0xe] = uVar6;
          if (uVar6 == 0) goto LAB_;
          uVar14 = (ulonglong)uVar6;
        } while ((short)puVar21[(ulonglong)(uVar6 - 1) + 1] < 0);
        uVar14 = (ulonglong)*(uint *)(param_3 + 2);
      }
      else {
LAB_:
        pbVar19 = *(byte **)(param_3 + 4);
        uVar14 = (ulonglong)*(uint *)(param_3 + 2);
      }
    }
    if ((*pbVar19 & 0x40) == 0) {
      *(undefined4 *)(param_3 + 0x13) = 0;
    }
    else {
      *(int *)(param_3 + 0x13) = (int)uVar14;
      *(int *)(param_3 + 2) = (int)uVar14 + 0xe;
      uVar9 = func_0x(puVar1);
      func_0x(uVar9,auStack_68);
      iVar23 = func_0x(auStack_68);
      *(int *)(param_3 + 2) = *(int *)(param_3 + 2) + iVar23;
      uVar14 = (ulonglong)*(uint *)(param_3 + 2);
    }
    iVar23 = (int)uVar14;
    if ((*(ulonglong *)(param_3 + 0xf) != 0) &&
       (*(ulonglong *)(param_3 + 0xf) < uVar14 + *(longlong *)(param_3 + 4))) {
      cVar5 = func_0x(0x2860ee0);
      if ((cVar5 != '\0') &&
         ((lVar11 = func_0x(), lVar11 != 0 && (*(char *)(lVar11 + 0x499) != '\0'))))
      {
        cVar5 = func_0x(0x2860ee0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          puVar24 = (uint *)0x0;
          (*_DAT_)(1,0x21508ec,0x22709d8,0x886,0);
        }
      }
      func_0x(*(undefined8 *)(param_3 + 4),0x12);
      iVar23 = *(int *)(param_3 + 2);
    }
    if (0x3f3b < iVar23 - 1U) {
      cVar5 = func_0x(0x2860ee0);
      if (((cVar5 != '\0') && (lVar11 = func_0x(), lVar11 != 0)) &&
         (*(char *)(lVar11 + 0x499) != '\0')) {
        cVar5 = func_0x(0x2860ee0);
        if (cVar5 == '\0') {
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          puVar24 = (uint *)0x0;
          (*_DAT_)(1,0x21508ec,0x22709d8,0x88b,0);
        }
      }
      func_0x(*(undefined8 *)(param_3 + 4),5);
    }
  }
LAB_:
  sVar12 = -(short)uStack_60;
  uVar13 = (uint)uStackX_18;
  if ((uStack_5a & 0x10) != 0) {
    bVar4 = **(byte **)(param_3 + 4);
    if ((bVar4 & 0x10) == 0) {
      if ((1 << (bVar4 & 0xe) & 0x1105U) != 0) {
LAB_:
        aiStackX_10[0] = *piStack_58;
        puVar10 = (uint *)(piStack_58 + 1);
        goto LAB_;
      }
    }
    else if (((int)*(uint *)(param_3 + 8) <= (int)uStack_60) ||
            (*(ushort *)(*(byte **)(param_3 + 4) + *(uint *)(param_3 + 8)) < uStack_5c))
    goto LAB_;
  }
  puVar10 = *(uint **)(param_3 + 4);
  lVar11 = (longlong)sVar12;
  if ((uint)(ushort)param_3[0xe] < (uint)(int)sVar12) {
    aiStackX_10[0] = 0;
    goto LAB_;
  }
  uVar13 = *(uint *)(param_3 + 10);
  if (sVar12 == 1) {
    uVar16 = *(uint *)(param_3 + 0xc);
    uVar13 = *(ushort *)((longlong)puVar10 + lVar11 * 2 + (ulonglong)uVar13) & 0x7fff;
LAB_:
    if ((uVar13 < uVar16) || (*(uint *)(param_3 + 2) < uVar13)) goto LAB_;
  }
  else {
    puVar1 = (ushort *)((longlong)puVar10 + lVar11 * 2 + (ulonglong)uVar13);
    uVar16 = *(ushort *)((longlong)puVar10 + lVar11 * 2 + ((ulonglong)uVar13 - 2)) & 0x7fff;
    puVar10 = *(uint **)(param_3 + 4);
    uVar13 = *puVar1 & 0x7fff;
    if (*(uint *)(param_3 + 0xc) <= uVar16) goto LAB_;
LAB_:
    func_0x(puVar10,7);
    puVar10 = *(uint **)(param_3 + 4);
  }
  aiStackX_10[0] = uVar13 - uVar16;
  puVar10 = (uint *)((longlong)puVar10 + (ulonglong)uVar16);
  uVar13 = (uint)uStackX_18;
LAB_:
  uVar16 = *puVar10;
  if (uVar16 < uVar13) {
    lVar11 = (***(code ***)*param_1)();
    uVar6 = *(ushort *)(lStackX_20 + 0x1c);
    if (((((uVar6 != 0) && (uVar6 <= *(ushort *)(*(longlong *)(lVar11 + 0x6a0) + 0x74))) &&
         (lVar11 = *(longlong *)
                    (*(longlong *)(*(longlong *)(lVar11 + 0x6a0) + 0x50) + -8 + (ulonglong)uVar6 * 8
                    ), lVar11 != 0)) &&
        (((*(uint *)(lVar11 + 100) & 4) == 0 && (uVar16 < *(uint *)(lVar11 + 0x80))))) &&
       ((*(uint *)(lVar11 + 100) & 0x40) == 0)) {
      uStack_74 = *(undefined2 *)(lStackX_20 + 0x1c);
      if (*(uint *)(lVar11 + 0x80) < uVar13) {
        uVar13 = *(uint *)(lVar11 + 0x80);
      }
      uStack_78 = uVar16;
      func_0x(param_1,uStack_74,&uStack_78,uVar13,puVar24);
    }
  }
  return;
}

