
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,short *param_2,longlong param_3,longlong param_4)

{
  ushort *puVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  byte *pbVar9;
  code *UNRECOVERED_JUMPTABLE;
  uint *puVar10;
  ulonglong uVar11;
  ushort uVar12;
  uint uVar13;
  uint uVar14;
  undefined *puVar15;
  short sVar16;
  int iVar17;
  uint uVar18;
  uint uVar19;
  uint *puVar20;
  uint *puVar21;
  ulonglong uVar22;
  byte *pbVar23;
  ulonglong uVar24;
  ushort *puVar25;
  ushort *puVar26;
  undefined8 uStack_430;
  undefined auStack_428 [32];
  undefined8 uStack_408;
  ushort auStack_3e8 [12];
  uint uStack_3d0;
  undefined4 uStack_3cc;
  undefined4 uStack_3c8;
  short *psStack_3c0;
  uint auStack_3b8 [6];
  undefined4 uStack_3a0;
  uint uStack_39c;
  uint *puStack_398;
  longlong lStack_390;
  ushort *puStack_388;
  longlong lStack_378;
  uint *puStack_370;
  uint uStack_368;
  uint uStack_364;
  longlong lStack_360;
  longlong lStack_358;
  undefined8 uStack_350;
  undefined4 uStack_348;
  undefined8 uStack_340;
  undefined8 uStack_338;
  undefined8 uStack_330;
  undefined8 uStack_320;
  int aiStack_318 [8];
  int iStack_2f8;
  int iStack_2f4;
  int iStack_2f0;
  uint uStack_2ec;
  int iStack_2e8;
  uint uStack_2e4;
  int aiStack_2e0 [18];
  uint uStack_298;
  undefined auStack_238 [4];
  undefined auStack_234 [4];
  undefined auStack_230 [4];
  undefined auStack_22c [4];
  int iStack_228;
  undefined auStack_224 [12];
  undefined auStack_218 [8];
  undefined auStack_210 [48];
  int aiStack_1e0 [10];
  undefined8 uStack_1b8;
  short *psStack_1b0;
  undefined8 uStack_1a8;
  undefined8 uStack_1a0;
  ulonglong uStack_48;
  
  uStack_48 = _DAT_ ^ (ulonglong)auStack_3e8;
  puVar20 = (uint *)0x0;
  uStack_1a0 = 0;
  uStack_350 = 0;
  uVar19 = 0;
  uStack_364 = 0;
  uStack_1b8 = 0x7aec60;
  uStack_348 = 0;
  puVar10 = puVar20;
  if (param_3 != 0) {
    uStack_368 = (uint)*(ushort *)(param_3 + 0x62);
    lStack_358 = 0;
    uStack_320 = 0;
    puStack_370 = *(uint **)(param_3 + 0x70);
    lStack_378 = param_3;
    lStack_360 = param_4;
    if ((*(ushort *)(param_3 + 0x38) & 0x400) == 0) {
      if (param_1 != -0x3b8) {
        lVar5 = **(longlong **)(*(longlong *)(param_1 + 0x3c0) + 0x160);
        uStack_350 = *(undefined8 *)(lVar5 + 0xa8);
        uStack_348 = *(undefined4 *)(lVar5 + 0xb0);
      }
      uStack_364 = 0x10;
      puVar10 = (uint *)0x10;
    }
    else {
      if (param_1 != -0x3b8) {
        lVar5 = **(longlong **)(*(longlong *)(param_1 + 0x3c0) + 0x160);
        uStack_350 = *(undefined8 *)(lVar5 + 0xa8);
        uStack_348 = *(undefined4 *)(lVar5 + 0xb0);
      }
      uStack_364 = 0x10;
      puVar10 = (uint *)0x10;
      if (param_4 != 0) {
        uStack_340 = 0;
        uStack_364 = 0x12;
        uStack_330 = 0;
        uStack_338 = 0;
        puVar10 = (uint *)0x12;
      }
    }
  }
  uVar13 = uStack_368;
  puVar21 = puStack_370;
  lStack_390 = param_1 + 0x3b8;
  psStack_3c0 = param_2;
  puStack_398 = puStack_370;
  if ((*(byte *)(lStack_378 + 0x30) & 1) != 0) {
    puVar1 = (ushort *)(param_2 + 1);
    if (*param_2 == 0) {
      if ((**(byte **)(param_2 + 4) & 0x10) != 0) {
        uVar19 = (uint)*(ushort *)(*(byte **)(param_2 + 4) + *(uint *)(param_2 + 8));
      }
    }
    else {
      uVar19 = (uint)*puVar1;
    }
    if (*(uint *)(lStack_378 + 0x18) <= uVar19) {
      *param_2 = 0;
      uStack_39c = 0;
      uStack_3d0 = (uint)*(ushort *)(lStack_378 + 0x62);
      puVar15 = auStack_428;
      puVar10 = puStack_370;
      if (uStack_3d0 != 0) {
        do {
          uVar19 = uStack_39c;
          puVar21 = (uint *)0x0;
          cVar3 = *(char *)(puVar10 + 0x10);
          if (cVar3 == '\x01') {
            if ((*(byte *)((longlong)puVar10 + 6) & 0x10) == 0) {
              uVar13 = *(byte *)((ulonglong)(*(ushort *)(puVar10 + 1) - 1 >> 3) +
                                 (ulonglong)*(uint *)(param_2 + 8) + 2 + *(longlong *)(param_2 + 4))
                       >> ((byte)(*(ushort *)(puVar10 + 1) - 1) & 7) & 1;
            }
            else {
              uStack_408 = &iStack_228;
              uStack_430 = 0x1013f4;
              func_0x(puVar1,puVar10,1,&uStack_2e4);
              uVar13 = uStack_2e4;
            }
            if (uVar13 == 0) goto LAB_;
LAB_:
            lVar5 = lStack_360;
            if ((*(byte *)(*(longlong *)(puVar10 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar5 = lStack_358;
            }
            *(undefined *)(lVar5 + *(longlong *)(puVar10 + 0xc)) = 3;
            puVar21 = puVar20;
          }
          else {
            if (cVar3 == '\x02') {
LAB_:
              uVar12 = *(ushort *)(puVar10 + 0xf);
              if ((*(byte *)((longlong)puVar10 + 6) & 0x10) == 0) {
LAB_:
                puVar21 = (uint *)((longlong)(int)*puVar10 + *(longlong *)(param_2 + 4));
                uVar13 = (uint)uVar12;
              }
              else {
                uStack_408 = aiStack_2e0;
                uStack_430 = 0x10147d;
                func_0x(puVar1,puVar10,0,auStack_224);
                if (aiStack_2e0[0] != 0) goto LAB_;
                uVar13 = **(uint **)(puVar10 + 2);
                puVar21 = *(uint **)(puVar10 + 2) + 1;
                if ((uVar12 != 0) && (uVar13 != uVar12)) {
                  uStack_408 = (int *)0x0;
                  uStack_430 = 0x1014be;
                  (*_DAT_)(1,0xbb77e0,0xbb6148,0x381);
                }
              }
              auStack_3b8[0] = uVar13;
              lVar5 = lStack_360;
              if ((*(byte *)(*(longlong *)(puVar10 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar5 = lStack_358;
              }
              *(undefined *)(lVar5 + *(longlong *)(puVar10 + 0xc)) = 0;
            }
            else {
              if (cVar3 == '\x03') {
                if ((*(byte *)((longlong)puVar10 + 6) & 0x10) == 0) {
                  uVar13 = *(byte *)((ulonglong)(*(ushort *)(puVar10 + 1) - 1 >> 3) +
                                     (ulonglong)*(uint *)(param_2 + 8) + 2 +
                                    *(longlong *)(param_2 + 4)) >>
                           ((byte)(*(ushort *)(puVar10 + 1) - 1) & 7) & 1;
                }
                else {
                  uStack_408 = aiStack_1e0;
                  uStack_430 = 0x100b95;
                  func_0x(puVar1,puVar10,1,&uStack_2ec);
                  uVar13 = uStack_2ec;
                }
                if (uVar13 != 0) goto LAB_;
              }
              else if (cVar3 != '\x04') {
                if (cVar3 == '\b') {
                  uVar12 = *(ushort *)(puVar10 + 0xf);
                  iVar17 = puVar10[0x10] << 0xc;
                  if ((*puVar10 & 0xc0000000) == 0x80000000) {
                    uStack_430 = 0x100af7;
                    iVar17 = func_0x(puVar1);
                    if (iVar17 != 0) {
                      uStack_430 = 0x100b12;
                      puVar21 = (uint *)func_0x(param_2 + 0x15,puVar10,auStack_3b8,
                                                        auStack_238);
                      uVar13 = auStack_3b8[0];
                      goto LAB_;
                    }
                    auStack_3b8[0] = 0;
                    uVar12 = *(ushort *)(*(longlong *)(puVar10 + 0x12) + 0x2a);
                  }
                  else {
                    if ((iVar17 < 0) || ((*(byte *)((longlong)puVar10 + 6) & 0x10) != 0)) {
                      uStack_408 = &iStack_2f8;
                      uStack_430 = 0x1002a9;
                      func_0x(puVar1,puVar10,iVar17 < 0,aiStack_318);
                      if ((iVar17 < 0) && (aiStack_318[0] != 0)) {
                        auStack_3b8[0] = 0;
                        puVar21 = (uint *)0x0;
                        uVar13 = auStack_3b8[0];
                        goto LAB_;
                      }
                    }
                    else {
                      aiStack_318[0] = 0;
                      iStack_2f8 = 1;
                    }
                    if ((iStack_2f8 == 0) && ((*(byte *)((longlong)puVar10 + 6) & 0x10) != 0)) {
                      puVar21 = *(uint **)(puVar10 + 2) + 1;
                      uVar13 = **(uint **)(puVar10 + 2);
                    }
                    else if ((int)*puVar10 < 0) {
                      if (*(int *)(param_2 + 2) == 0) {
                        *puVar1 = 0;
                        uVar13 = *(uint *)(param_2 + 8);
                        uVar11 = (ulonglong)uVar13;
                        *(uint *)(param_2 + 10) = uVar13;
                        pbVar23 = *(byte **)(param_2 + 4);
                        bVar2 = *pbVar23;
                        if ((bVar2 & 0x10) != 0) {
                          uVar13 = uVar13 + 2 + (*(ushort *)(pbVar23 + uVar11) + 7 >> 3);
                          uVar11 = (ulonglong)uVar13;
                          *(uint *)(param_2 + 10) = uVar13;
                          bVar2 = *pbVar23;
                        }
                        if ((bVar2 & 0x20) == 0) {
                          *(int *)(param_2 + 2) = (int)uVar11;
                          param_2[0xe] = 0;
                          *(uint *)(param_2 + 0xc) = uVar13;
                        }
                        else {
                          puVar25 = (ushort *)(pbVar23 + uVar11);
                          uVar12 = *puVar25;
                          param_2[0xe] = uVar12;
                          puStack_388 = puVar25;
                          if (uVar12 == 0) {
                            uStack_430 = 0x1003f5;
                            cVar3 = func_0x(0x1119990);
                            if (cVar3 != '\0') {
                              uStack_430 = 0x1003fe;
                              lVar5 = func_0x();
                              if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                uStack_430 = 0x100418;
                                cVar3 = func_0x(0x1119990);
                                if (cVar3 == '\0') {
                                  uStack_430 = 0x100434;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  uStack_408 = (int *)0x0;
                                  uStack_430 = 0x10045b;
                                  (*_DAT_)(1,0xa0939c,0xb29488,0x80f);
                                }
                              }
                            }
                            uStack_430 = 0x100469;
                            func_0x(*(undefined8 *)(param_2 + 4),3);
                            uVar12 = param_2[0xe];
                            uVar13 = *(uint *)(param_2 + 10);
                          }
                          uVar13 = uVar13 + (uVar12 + 1) * 2;
                          *(uint *)(param_2 + 0xc) = uVar13;
                          if (0x1f9e < uVar13) {
                            uStack_430 = 0x100498;
                            cVar3 = func_0x(0x1119990);
                            if (cVar3 != '\0') {
                              uStack_430 = 0x1004a1;
                              lVar5 = func_0x();
                              if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                uStack_430 = 0x1004bb;
                                cVar3 = func_0x(0x1119990);
                                if (cVar3 == '\0') {
                                  uStack_430 = 0x1004d7;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  uStack_408 = (int *)0x0;
                                  uStack_430 = 0x1004fe;
                                  (*_DAT_)(1,0xa0939c,0xb29488,0x816);
                                }
                              }
                            }
                            uStack_430 = 0x10050c;
                            func_0x(*(undefined8 *)(param_2 + 4),4);
                            uVar12 = param_2[0xe];
                            uVar13 = *(uint *)(param_2 + 0xc);
                          }
                          uVar11 = (ulonglong)uVar12;
                          uVar12 = puVar25[uVar11];
                          *(uint *)(param_2 + 2) = uVar12 & 0x7fff;
                          if ((uVar12 & 0x7fff) < uVar13) {
                            uStack_430 = 0x10053a;
                            cVar3 = func_0x(0x1119990);
                            if (cVar3 != '\0') {
                              uStack_430 = 0x100543;
                              lVar5 = func_0x();
                              if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                uStack_430 = 0x10055d;
                                cVar3 = func_0x(0x1119990);
                                if (cVar3 == '\0') {
                                  uStack_430 = 0x100579;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  uStack_408 = (int *)0x0;
                                  uStack_430 = 0x1005a0;
                                  (*_DAT_)(1,0xa0939c,0xb29488,0x81d);
                                }
                              }
                            }
                            uStack_430 = 0x1005ae;
                            func_0x(*(undefined8 *)(param_2 + 4),4);
                            uVar13 = *(uint *)(param_2 + 0xc);
                            uVar11 = (ulonglong)(ushort)param_2[0xe];
                          }
                          iVar17 = 0;
                          puVar26 = puVar25;
                          if ((short)uVar11 != 0) {
                            do {
                              puVar25 = puVar25 + 1;
                              uVar18 = *puVar25 & 0x7fff;
                              if ((uVar18 < uVar13) || (*(uint *)(param_2 + 2) < uVar18)) {
                                uStack_430 = 0x1005ef;
                                cVar3 = func_0x(0x1119990);
                                if (cVar3 != '\0') {
                                  uStack_430 = 0x1005f8;
                                  lVar5 = func_0x();
                                  if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                                    uStack_430 = 0x100612;
                                    cVar3 = func_0x(0x1119990);
                                    if (cVar3 == '\0') {
                                      uStack_430 = 0x10062e;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      uStack_408 = (int *)0x0;
                                      uStack_430 = 0x100652;
                                      (*_DAT_)(1,0xa0939c,0xb29488,0x82a);
                                    }
                                  }
                                }
                                uStack_430 = 0x100660;
                                func_0x(*(undefined8 *)(param_2 + 4),4);
                              }
                              uVar11 = (ulonglong)(ushort)param_2[0xe];
                              iVar17 = iVar17 + 1;
                              puVar26 = puStack_388;
                              uVar19 = uStack_39c;
                              uVar13 = uVar18;
                            } while (iVar17 < (int)(uint)(ushort)param_2[0xe]);
                          }
                          if ((short)puVar26[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
                            do {
                              lVar5 = (ulonglong)*(uint *)(param_2 + 10) +
                                      *(longlong *)(param_2 + 4);
                              uVar13 = *(ushort *)(lVar5 + uVar11 * 2) & 0x7fff;
                              if ((int)uVar11 == 1) {
                                uVar18 = *(uint *)(param_2 + 0xc);
                                uVar14 = uVar18;
LAB_:
                                if ((uVar13 < uVar18) || (*(uint *)(param_2 + 2) < uVar13))
                                goto LAB_;
                              }
                              else {
                                uVar14 = *(uint *)(param_2 + 0xc);
                                uVar18 = *(ushort *)(lVar5 + -2 + uVar11 * 2) & 0x7fff;
                                if (uVar14 <= uVar18) goto LAB_;
LAB_:
                                uStack_430 = 0x1006dc;
                                func_0x(*(longlong *)(param_2 + 4),7);
                                uVar14 = *(uint *)(param_2 + 0xc);
                              }
                              if ((uVar18 < uVar14) || (*(uint *)(param_2 + 2) < uVar18))
                              goto LAB_;
                              if (*(ushort *)((ulonglong)uVar18 + *(longlong *)(param_2 + 4)) == 5)
                              {
                                *puVar1 = *puVar1 | 2;
                                param_2[0xe] = param_2[0xe] + -1;
                                param_2[0x15] = (short)uVar18;
                                uVar11 = *(ulonglong *)(param_2 + 4);
                                uVar4 = param_2[0x16] & 0xc7ff;
                                uVar12 = *(ushort *)((ulonglong)(uVar18 & 0xffff) + 2 + uVar11);
                                if ((uVar12 >> 0xe & 1) != 0) {
                                  uVar4 = uVar12 & 0x3800 | uVar4;
                                }
                                param_2[0x16] = uVar4;
                                uVar12 = (uVar4 ^ *(ushort *)
                                                   ((ulonglong)(uVar18 & 0xffff) + 2 + uVar11)) &
                                         0x7ff ^ uVar4;
                                param_2[0x16] = uVar12;
                                uVar24 = (ulonglong)(ushort)param_2[0x15];
                                uVar22 = uVar11 + 4 +
                                         (ulonglong)((uVar12 & 0x7ff) * 2) +
                                         uVar24 + (uVar4 >> 0xb & 7) * 2;
                                if (uVar22 < uVar24 + uVar11) {
                                  uStack_430 = 0x1007ef;
                                  func_0x(uVar24 + uVar11,0x19);
                                  uVar12 = param_2[0x16];
                                  uVar24 = (ulonglong)(ushort)param_2[0x15];
                                  uVar11 = (ulonglong)*(uint *)(param_2 + 4);
                                }
                                if (uVar13 - uVar18 <
                                    (((uVar12 & 0x7ff) * 2 - (int)uVar24) - (int)uVar11) +
                                    (int)uVar22) {
                                  uStack_430 = 0x100827;
                                  func_0x(uVar24 + *(longlong *)(param_2 + 4),0x19);
                                  uVar12 = param_2[0x16];
                                }
                                if ((uVar12 & 0x3800) != 0) {
                                  puVar25 = (ushort *)
                                            (*(longlong *)(param_2 + 4) +
                                            (ulonglong)(ushort)param_2[0x15] + 4);
                                  iVar17 = 0;
                                  if ((uVar12 & 0x3800) != 0) {
                                    do {
                                      if ((uVar12 & 0x7ff) < (*puVar25 & 0x7ff)) {
                                        uStack_430 = 0x100887;
                                        func_0x((ulonglong)(ushort)param_2[0x15] +
                                                        *(longlong *)(param_2 + 4),0x1a);
                                        uVar12 = param_2[0x16];
                                      }
                                      iVar17 = iVar17 + 1;
                                      puVar25 = puVar25 + 1;
                                    } while (iVar17 < (int)(uVar12 >> 0xb & 7));
                                  }
                                }
                                goto LAB_;
                              }
                              if (*(ushort *)((ulonglong)uVar18 + *(longlong *)(param_2 + 4)) <
                                  0x400) goto LAB_;
                              *puVar1 = *puVar1 | 1;
                              uVar12 = param_2[0xe] - 1;
                              param_2[0xe] = uVar12;
                              if (uVar12 == 0) goto LAB_;
                              uVar11 = (ulonglong)uVar12;
                            } while ((short)puVar26[(ulonglong)(uVar12 - 1) + 1] < 0);
                            pbVar23 = *(byte **)(param_2 + 4);
                          }
                          else {
LAB_:
                            pbVar23 = *(byte **)(param_2 + 4);
                          }
                        }
                        if ((*pbVar23 & 0x40) == 0) {
                          *(undefined4 *)(param_2 + 0x13) = 0;
                        }
                        else {
                          *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
                          *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
                          uStack_430 = 0x1008d5;
                          uVar6 = func_0x(puVar1);
                          uStack_430 = 0x1008e4;
                          func_0x(uVar6,auStack_218);
                          uStack_430 = 0x1008f0;
                          iVar17 = func_0x(auStack_218);
                          *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar17;
                        }
                        uVar13 = *(uint *)(param_2 + 2);
                        if ((*(ulonglong *)(param_2 + 0xf) != 0) &&
                           (*(ulonglong *)(param_2 + 0xf) <
                            (ulonglong)uVar13 + *(longlong *)(param_2 + 4))) {
                          uStack_430 = 0x100920;
                          cVar3 = func_0x(0x1119990);
                          if (cVar3 != '\0') {
                            uStack_430 = 0x100929;
                            lVar5 = func_0x();
                            if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                              uStack_430 = 0x100943;
                              cVar3 = func_0x(0x1119990);
                              if (cVar3 == '\0') {
                                uStack_430 = 0x10095f;
                                (*_DAT_)(0x22,0x44,0x15,0x3fa);
                              }
                              else {
                                uStack_408 = (int *)0x0;
                                uStack_430 = 0x100982;
                                (*_DAT_)(1,0xa0939c,0xb29488,0x886);
                              }
                            }
                          }
                          uStack_430 = 0x100990;
                          func_0x(*(undefined8 *)(param_2 + 4),0x12);
                          uVar13 = *(uint *)(param_2 + 2);
                        }
                        if (0x3f3b < uVar13 - 1) {
                          uStack_430 = 0x1009a9;
                          cVar3 = func_0x(0x1119990);
                          if (cVar3 != '\0') {
                            uStack_430 = 0x1009b2;
                            lVar5 = func_0x();
                            if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                              uStack_430 = 0x1009cc;
                              cVar3 = func_0x(0x1119990);
                              if (cVar3 == '\0') {
                                uStack_430 = 0x1009e8;
                                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                              }
                              else {
                                uStack_408 = (int *)0x0;
                                uStack_430 = 0x100a0b;
                                (*_DAT_)(1,0xa0939c,0xb29488,0x88b);
                              }
                            }
                          }
                          uStack_430 = 0x100a19;
                          func_0x(*(undefined8 *)(param_2 + 4),5);
                        }
                      }
LAB_:
                      sVar16 = -*(short *)puVar10;
                      if ((*(byte *)((longlong)puVar10 + 6) & 0x10) != 0) {
                        uStack_408 = &iStack_2f0;
                        uStack_430 = 0x100a48;
                        func_0x(puVar1,puVar10,0,auStack_234);
                        if (iStack_2f0 == 0) {
                          puVar21 = *(uint **)(puVar10 + 2) + 1;
                          uVar13 = **(uint **)(puVar10 + 2);
                          goto LAB_;
                        }
                      }
                      lVar5 = (longlong)sVar16;
                      if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar16) {
                        auStack_3b8[0] = 0;
                        puVar21 = *(uint **)(param_2 + 4);
                        uVar13 = auStack_3b8[0];
                      }
                      else {
                        lVar8 = *(longlong *)(param_2 + 4);
                        lVar7 = (ulonglong)*(uint *)(param_2 + 10) + lVar8;
                        if (sVar16 == 1) {
                          uVar18 = *(ushort *)(lVar7 + lVar5 * 2) & 0x7fff;
                          uVar13 = *(uint *)(psStack_3c0 + 0xc);
LAB_:
                          if ((uVar18 < uVar13) || (*(uint *)(param_2 + 2) < uVar18))
                          goto LAB_;
                        }
                        else {
                          uVar13 = *(ushort *)(lVar7 + -2 + lVar5 * 2) & 0x7fff;
                          uVar18 = *(ushort *)(lVar7 + lVar5 * 2) & 0x7fff;
                          lVar8 = *(longlong *)(param_2 + 4);
                          if (*(uint *)(psStack_3c0 + 0xc) <= uVar13) goto LAB_;
LAB_:
                          uStack_430 = 0x100ad4;
                          func_0x(lVar8,7);
                          lVar8 = *(longlong *)(param_2 + 4);
                        }
                        puVar21 = (uint *)((ulonglong)uVar13 + lVar8);
                        uVar13 = uVar18 - uVar13;
                      }
                    }
                    else if ((*(ushort *)((longlong)puVar10 + 6) & 8) == 0) {
                      if ((*(ushort *)((longlong)puVar10 + 6) & 0x10) != 0) {
                        uStack_408 = &iStack_2f4;
                        uStack_430 = 0x10031d;
                        func_0x(puVar1,puVar10,0,auStack_230);
                        if (iStack_2f4 == 0) {
                          uVar13 = **(uint **)(puVar10 + 2);
                          puVar21 = *(uint **)(puVar10 + 2) + 1;
                          if ((uVar12 != 0) && (uVar13 != uVar12)) {
                            uStack_408 = (int *)0x0;
                            uStack_430 = 0x10035e;
                            (*_DAT_)(1,0xbb77e0,0xbb6148,0x381);
                          }
                          goto LAB_;
                        }
                      }
                      puVar21 = (uint *)((longlong)(int)*puVar10 + *(longlong *)(param_2 + 4));
                      uVar13 = (uint)uVar12;
                    }
                    else {
                      uStack_430 = 0x100385;
                      puVar21 = (uint *)func_0x(puVar1,puVar10);
                      uVar13 = auStack_3b8[0];
                    }
LAB_:
                    auStack_3b8[0] = uVar13;
                    uVar12 = *(ushort *)(*(longlong *)(puVar10 + 0x12) + 0x2a);
                    if (puVar21 != (uint *)0x0) {
                      lVar5 = lStack_360;
                      if ((uVar12 & 0x10) != 0) {
                        lVar5 = lStack_358;
                      }
                      *(undefined *)(lVar5 + *(longlong *)(puVar10 + 0xc)) = 0;
                      goto LAB_;
                    }
                  }
                  lVar5 = lStack_360;
                  if ((uVar12 & 0x10) != 0) {
                    lVar5 = lStack_358;
                  }
                  *(undefined *)(lVar5 + *(longlong *)(puVar10 + 0xc)) = 3;
                  goto LAB_;
                }
                uStack_408 = (int *)0x784900;
                uStack_430 = 0x10023f;
                (*_DAT_)(1,0xb8ac90,0xbb7658,0x27d);
                puVar21 = puVar20;
                goto LAB_;
              }
              if (*(int *)(param_2 + 2) == 0) {
                *puVar1 = 0;
                uVar13 = *(uint *)(param_2 + 8);
                uVar11 = (ulonglong)uVar13;
                *(uint *)(param_2 + 10) = uVar13;
                pbVar23 = *(byte **)(param_2 + 4);
                bVar2 = *pbVar23;
                pbVar9 = pbVar23;
                if ((bVar2 & 0x10) != 0) {
                  uVar13 = uVar13 + 2 + (*(ushort *)(pbVar23 + uVar11) + 7 >> 3);
                  uVar11 = (ulonglong)uVar13;
                  *(uint *)(param_2 + 10) = uVar13;
                  bVar2 = *pbVar23;
                  pbVar9 = *(byte **)(param_2 + 4);
                }
                if ((bVar2 & 0x20) == 0) {
                  *(int *)(param_2 + 2) = (int)uVar11;
                  param_2[0xe] = 0;
                  *(uint *)(param_2 + 0xc) = uVar13;
                }
                else {
                  puVar25 = (ushort *)(pbVar23 + uVar11);
                  uVar12 = *puVar25;
                  param_2[0xe] = uVar12;
                  puStack_388 = puVar25;
                  if (uVar12 == 0) {
                    uStack_430 = 0x100c45;
                    cVar3 = func_0x(0x1119990);
                    if (cVar3 != '\0') {
                      uStack_430 = 0x100c4e;
                      lVar5 = func_0x();
                      if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                        uStack_430 = 0x100c68;
                        cVar3 = func_0x(0x1119990);
                        if (cVar3 == '\0') {
                          uStack_430 = 0x100c84;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          uStack_408 = (int *)0x0;
                          uStack_430 = 0x100ca9;
                          (*_DAT_)(1,0xa0939c,0xb29488,0x80f);
                        }
                      }
                    }
                    uStack_430 = 0x100cb5;
                    func_0x(*(undefined8 *)(param_2 + 4),3);
                    uVar12 = param_2[0xe];
                    uVar13 = *(uint *)(param_2 + 10);
                  }
                  uVar13 = uVar13 + (uVar12 + 1) * 2;
                  *(uint *)(param_2 + 0xc) = uVar13;
                  if (0x1f9e < uVar13) {
                    uStack_430 = 0x100ce5;
                    cVar3 = func_0x(0x1119990);
                    if (cVar3 != '\0') {
                      uStack_430 = 0x100cee;
                      lVar5 = func_0x();
                      if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                        uStack_430 = 0x100d08;
                        cVar3 = func_0x(0x1119990);
                        if (cVar3 == '\0') {
                          uStack_430 = 0x100d24;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_408 = (int *)0x0;
                          uStack_430 = 0x100d49;
                          (*_DAT_)(1,0xa0939c,0xb29488,0x816);
                        }
                      }
                    }
                    uStack_430 = 0x100d57;
                    func_0x(*(undefined8 *)(param_2 + 4),4);
                    uVar12 = param_2[0xe];
                    uVar13 = *(uint *)(param_2 + 0xc);
                  }
                  uVar11 = (ulonglong)uVar12;
                  uVar12 = puVar25[uVar11];
                  *(uint *)(param_2 + 2) = uVar12 & 0x7fff;
                  if ((uVar12 & 0x7fff) < uVar13) {
                    uStack_430 = 0x100d85;
                    cVar3 = func_0x(0x1119990);
                    if (cVar3 != '\0') {
                      uStack_430 = 0x100d8e;
                      lVar5 = func_0x();
                      if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                        uStack_430 = 0x100da8;
                        cVar3 = func_0x(0x1119990);
                        if (cVar3 == '\0') {
                          uStack_430 = 0x100dc4;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          uStack_408 = (int *)0x0;
                          uStack_430 = 0x100de9;
                          (*_DAT_)(1,0xa0939c,0xb29488,0x81d);
                        }
                      }
                    }
                    uStack_430 = 0x100df7;
                    func_0x(*(undefined8 *)(param_2 + 4),4);
                    uVar13 = *(uint *)(param_2 + 0xc);
                    uVar11 = (ulonglong)(ushort)param_2[0xe];
                  }
                  iVar17 = 0;
                  puVar26 = puVar25;
                  if ((short)uVar11 != 0) {
                    do {
                      puVar25 = puVar25 + 1;
                      uVar18 = *puVar25 & 0x7fff;
                      if ((uVar18 < uVar13) || (*(uint *)(param_2 + 2) < uVar18)) {
                        uStack_430 = 0x100e3f;
                        cVar3 = func_0x(0x1119990);
                        if (cVar3 != '\0') {
                          uStack_430 = 0x100e48;
                          lVar5 = func_0x();
                          if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                            uStack_430 = 0x100e62;
                            cVar3 = func_0x(0x1119990);
                            if (cVar3 == '\0') {
                              uStack_430 = 0x100e7e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              uStack_408 = (int *)0x0;
                              uStack_430 = 0x100ea2;
                              (*_DAT_)(1,0xa0939c,0xb29488,0x82a);
                            }
                          }
                        }
                        uStack_430 = 0x100eb0;
                        func_0x(*(undefined8 *)(param_2 + 4),4);
                      }
                      uVar11 = (ulonglong)(ushort)param_2[0xe];
                      iVar17 = iVar17 + 1;
                      puVar26 = puStack_388;
                      uVar19 = uStack_39c;
                      uVar13 = uVar18;
                    } while (iVar17 < (int)(uint)(ushort)param_2[0xe]);
                  }
                  if ((short)puVar26[(ulonglong)((int)uVar11 - 1) + 1] < 0) {
                    do {
                      lVar5 = *(longlong *)(param_2 + 4);
                      uVar13 = *(ushort *)((ulonglong)*(uint *)(param_2 + 10) + lVar5 + uVar11 * 2)
                               & 0x7fff;
                      if ((int)uVar11 == 1) {
                        uVar18 = *(uint *)(param_2 + 0xc);
                        uVar14 = uVar18;
LAB_:
                        if ((uVar13 < uVar18) || (*(uint *)(param_2 + 2) < uVar13))
                        goto LAB_;
                      }
                      else {
                        uVar14 = *(uint *)(param_2 + 0xc);
                        uVar18 = *(ushort *)
                                  ((ulonglong)*(uint *)(param_2 + 10) + lVar5 + -2 + uVar11 * 2) &
                                 0x7fff;
                        if (uVar14 <= uVar18) goto LAB_;
LAB_:
                        uStack_430 = 0x100f2c;
                        func_0x(lVar5,7);
                        uVar14 = *(uint *)(param_2 + 0xc);
                        lVar5 = *(longlong *)(param_2 + 4);
                      }
                      if ((uVar18 < uVar14) || (*(uint *)(param_2 + 2) < uVar18)) goto LAB_;
                      if (*(ushort *)((ulonglong)uVar18 + lVar5) == 5) {
                        *puVar1 = *puVar1 | 2;
                        param_2[0xe] = param_2[0xe] + -1;
                        param_2[0x15] = (short)uVar18;
                        uVar11 = *(ulonglong *)(param_2 + 4);
                        uVar4 = param_2[0x16] & 0xc7ff;
                        uVar12 = *(ushort *)((ulonglong)(uVar18 & 0xffff) + 2 + uVar11);
                        if ((uVar12 >> 0xe & 1) != 0) {
                          uVar4 = uVar12 & 0x3800 | uVar4;
                        }
                        param_2[0x16] = uVar4;
                        uVar12 = (uVar4 ^ *(ushort *)((ulonglong)(uVar18 & 0xffff) + 2 + uVar11)) &
                                 0x7ff ^ uVar4;
                        param_2[0x16] = uVar12;
                        uVar24 = (ulonglong)(ushort)param_2[0x15];
                        uVar22 = uVar24 + 4 +
                                 (ulonglong)((uVar12 & 0x7ff) * 2) + uVar11 + (uVar4 >> 0xb & 7) * 2
                        ;
                        if (uVar22 < uVar24 + uVar11) {
                          uStack_430 = 0x101040;
                          func_0x(uVar24 + uVar11,0x19);
                          uVar12 = param_2[0x16];
                          uVar24 = (ulonglong)(ushort)param_2[0x15];
                          uVar11 = (ulonglong)*(uint *)(param_2 + 4);
                        }
                        if (uVar13 - uVar18 <
                            (((uVar12 & 0x7ff) * 2 - (int)uVar24) - (int)uVar11) + (int)uVar22) {
                          uStack_430 = 0x101078;
                          func_0x(uVar24 + *(longlong *)(param_2 + 4),0x19);
                          uVar12 = param_2[0x16];
                        }
                        if ((uVar12 & 0x3800) != 0) {
                          puVar25 = (ushort *)
                                    (*(longlong *)(param_2 + 4) +
                                    (ulonglong)(ushort)param_2[0x15] + 4);
                          iVar17 = 0;
                          if ((uVar12 & 0x3800) != 0) {
                            do {
                              if ((uVar12 & 0x7ff) < (*puVar25 & 0x7ff)) {
                                uStack_430 = 0x1010d7;
                                func_0x((ulonglong)(ushort)param_2[0x15] +
                                                *(longlong *)(param_2 + 4),0x1a);
                                uVar12 = param_2[0x16];
                              }
                              iVar17 = iVar17 + 1;
                              puVar25 = puVar25 + 1;
                            } while (iVar17 < (int)(uVar12 >> 0xb & 7));
                          }
                        }
                        goto LAB_;
                      }
                      if (*(ushort *)((ulonglong)uVar18 + lVar5) < 0x400) goto LAB_;
                      *puVar1 = *puVar1 | 1;
                      uVar12 = param_2[0xe] - 1;
                      param_2[0xe] = uVar12;
                      if (uVar12 == 0) goto LAB_;
                      uVar11 = (ulonglong)uVar12;
                    } while ((short)puVar26[(ulonglong)(uVar12 - 1) + 1] < 0);
                    pbVar9 = *(byte **)(param_2 + 4);
                  }
                  else {
LAB_:
                    pbVar9 = *(byte **)(param_2 + 4);
                  }
                }
                if ((*pbVar9 & 0x40) == 0) {
                  *(undefined4 *)(param_2 + 0x13) = 0;
                }
                else {
                  *(int *)(param_2 + 0x13) = *(int *)(param_2 + 2);
                  *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + 0xe;
                  uStack_430 = 0x101125;
                  uVar6 = func_0x(puVar1);
                  uStack_430 = 0x101134;
                  func_0x(uVar6,auStack_210);
                  uStack_430 = 0x101140;
                  iVar17 = func_0x(auStack_210);
                  *(int *)(param_2 + 2) = *(int *)(param_2 + 2) + iVar17;
                  pbVar9 = *(byte **)(param_2 + 4);
                }
                uVar13 = *(uint *)(param_2 + 2);
                if ((*(byte **)(param_2 + 0xf) != (byte *)0x0) &&
                   (*(byte **)(param_2 + 0xf) < pbVar9 + uVar13)) {
                  uStack_430 = 0x101173;
                  cVar3 = func_0x(0x1119990);
                  if (cVar3 != '\0') {
                    uStack_430 = 0x10117c;
                    lVar5 = func_0x();
                    if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                      uStack_430 = 0x101196;
                      cVar3 = func_0x(0x1119990);
                      if (cVar3 == '\0') {
                        uStack_430 = 0x1011b2;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        uStack_408 = (int *)0x0;
                        uStack_430 = 0x1011d5;
                        (*_DAT_)(1,0xa0939c,0xb29488,0x886);
                      }
                    }
                  }
                  uStack_430 = 0x1011e3;
                  func_0x(*(undefined8 *)(param_2 + 4),0x12);
                  uVar13 = *(uint *)(param_2 + 2);
                }
                if (0x3f3b < uVar13 - 1) {
                  uStack_430 = 0x1011fc;
                  cVar3 = func_0x(0x1119990);
                  if (cVar3 != '\0') {
                    uStack_430 = 0x101205;
                    lVar5 = func_0x();
                    if ((lVar5 != 0) && (*(char *)(lVar5 + 0x499) != '\0')) {
                      uStack_430 = 0x10121f;
                      cVar3 = func_0x(0x1119990);
                      if (cVar3 == '\0') {
                        uStack_430 = 0x10123b;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        uStack_408 = (int *)0x0;
                        uStack_430 = 0x10125e;
                        (*_DAT_)(1,0xa0939c,0xb29488,0x88b);
                      }
                    }
                  }
                  uStack_430 = 0x10126c;
                  func_0x(*(undefined8 *)(param_2 + 4),5);
                }
              }
LAB_:
              sVar16 = -*(short *)puVar10;
              if ((*(byte *)((longlong)puVar10 + 6) & 0x10) == 0) {
LAB_:
                lVar5 = (longlong)sVar16;
                if ((uint)(ushort)param_2[0xe] < (uint)(int)sVar16) {
                  auStack_3b8[0] = 0;
                  puVar21 = *(uint **)(param_2 + 4);
                }
                else {
                  lVar8 = *(longlong *)(param_2 + 4);
                  lVar7 = (ulonglong)*(uint *)(param_2 + 10) + lVar8;
                  if (sVar16 == 1) {
                    uVar13 = *(ushort *)(lVar7 + lVar5 * 2) & 0x7fff;
                    uVar11 = (ulonglong)*(uint *)(psStack_3c0 + 0xc);
LAB_:
                    if ((uVar13 < (uint)uVar11) || (*(uint *)(param_2 + 2) < uVar13))
                    goto LAB_;
                  }
                  else {
                    uVar18 = *(ushort *)(lVar7 + -2 + lVar5 * 2) & 0x7fff;
                    uVar11 = (ulonglong)uVar18;
                    uVar13 = *(ushort *)(lVar7 + lVar5 * 2) & 0x7fff;
                    lVar8 = *(longlong *)(param_2 + 4);
                    if (*(uint *)(psStack_3c0 + 0xc) <= uVar18) goto LAB_;
LAB_:
                    uStack_430 = 0x101327;
                    func_0x(lVar8,7);
                    lVar8 = *(longlong *)(param_2 + 4);
                  }
                  auStack_3b8[0] = uVar13 - (int)uVar11;
                  puVar21 = (uint *)(uVar11 + lVar8);
                }
              }
              else {
                uStack_408 = &iStack_2e8;
                uStack_430 = 0x10129b;
                func_0x(puVar1,puVar10,0,auStack_22c);
                if (iStack_2e8 != 0) goto LAB_;
                auStack_3b8[0] = **(uint **)(puVar10 + 2);
                puVar21 = *(uint **)(puVar10 + 2) + 1;
              }
              if (((puVar10[0x10] & 0x2000) != 0) && (auStack_3b8[0] == 0)) {
                auStack_3b8[0] = 4;
                puVar21 = (uint *)0x7aff64;
              }
              lVar5 = lStack_360;
              if ((*(byte *)(*(longlong *)(puVar10 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar5 = lStack_358;
              }
              *(undefined *)(lVar5 + *(longlong *)(puVar10 + 0xc)) = 0;
              if ((1 << (**(byte **)(param_2 + 4) & 0xe) & 0x440U) != 0) {
                uStack_430 = 0x10139b;
                iVar17 = func_0x(puVar10);
                if (iVar17 != 0) goto LAB_;
              }
              if (*(ushort *)(puVar10 + 0xf) < auStack_3b8[0]) {
                uStack_430 = 0x1013c7;
                (*_DAT_)(6,0x52,0x16,0x91);
              }
            }
LAB_:
            uVar11 = (ulonglong)auStack_3b8[0];
            lVar5 = *(longlong *)(puVar10 + 0x12);
            if ((puVar10[0x10] & 0x800) == 0) {
              lVar8 = lStack_360;
              if ((*(byte *)(lVar5 + 0x2a) & 0x10) != 0) {
                lVar8 = lStack_358;
              }
              uStack_430 = 0x101521;
              func_0x(lVar8 + *(longlong *)(puVar10 + 10),puVar21);
            }
            else {
              uVar12 = *(ushort *)(lVar5 + 0x2a) & 0x10;
              if (*(int *)(lVar5 + 0x10) == 10) {
                lVar5 = lStack_360;
                if (uVar12 != 0) {
                  lVar5 = lStack_358;
                }
                *(uint **)(lVar5 + *(longlong *)(puVar10 + 10)) = puVar21;
              }
              else {
                lVar5 = lStack_360;
                if (uVar12 != 0) {
                  lVar5 = lStack_358;
                }
                uStack_430 = 0x101553;
                func_0x
                          (*(undefined8 *)(*(longlong *)(puVar10 + 10) + lVar5),puVar21);
              }
            }
            if ((puVar10[0x10] & 0x100) != 0) {
              lVar5 = lStack_360;
              if ((*(byte *)(*(longlong *)(puVar10 + 0x12) + 0x2a) & 0x10) != 0) {
                lVar5 = lStack_358;
              }
              *(ulonglong *)(lVar5 + *(longlong *)(*(longlong *)(puVar10 + 0x12) + 0x18)) = uVar11;
            }
          }
LAB_:
          uStack_39c = uVar19 + 1;
          puVar15 = auStack_428;
          puVar20 = puVar21;
          puVar10 = puVar10 + 0x14;
        } while (uStack_39c < uStack_3d0);
      }
      goto LAB_;
    }
  }
  uStack_1a8 = 0;
  uStack_39c = uStack_368;
  psStack_1b0 = param_2;
  if (*param_2 == 0) {
    *param_2 = 0;
    puVar15 = auStack_428;
    puStack_398 = puStack_370;
    if ((uStack_364 & 0x10) != 0) {
      puStack_398 = puStack_370;
      uStack_3d0 = 0;
      puVar15 = auStack_428;
      puVar10 = puStack_370;
      if (uStack_368 != 0) {
        do {
          uVar19 = uStack_3d0;
          puStack_398 = puVar10;
          if (*(byte *)(puVar10 + 0x10) < 0x1c) {
            UNRECOVERED_JUMPTABLE =
                 (code *)((ulonglong)
                          *(uint *)((longlong)(char)*(byte *)(puVar10 + 0x10) * 4 + 0x107270) -
                         0x1d95c30);
                    /* WARNING: Could not emulate address calculation at 0x0010163f */
                    /* WARNING: Treating indirect jump as call */
            (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
            return;
          }
          uVar13 = puVar10[0x10];
          if ((uVar13 >> 10 & 1) != 0) {
            lVar5 = lStack_360;
            if ((*(byte *)(*(longlong *)(puVar10 + 0x12) + 0x2a) & 0x10) != 0) {
              lVar5 = lStack_358;
            }
            *(undefined *)(lVar5 + *(longlong *)(puVar10 + 0xc)) = 3;
            uVar13 = puVar10[0x10];
          }
          if ((uVar13 >> 9 & 1) != 0) {
            uStack_408 = (int *)CONCAT44(uStack_408._4_4_,uStack_3c8);
            uStack_430 = 0x101763;
            func_0x(&lStack_378,lStack_390,puVar10,0);
          }
          uStack_3d0 = uVar19 + 1;
          puStack_398 = puVar10 + 0x14;
          puVar15 = auStack_428;
          puVar10 = puStack_398;
        } while (uStack_3d0 < uStack_39c);
      }
    }
  }
  else if (*(int *)(*(longlong *)(param_1 + 0x3c0) + 0x100) == 2) {
    uStack_298 = *(uint *)(lStack_378 + 0x34);
    uVar11 = (ulonglong)uStack_298 + 0xf;
    if (uVar11 <= uStack_298) {
      uVar11 = 0xffffffffffffff0;
    }
    uVar11 = uVar11 & 0xfffffffffffffff0;
    uStack_430 = 0x104745;
    func_0x();
    lVar5 = -uVar11;
    puStack_388 = (ushort *)((longlong)auStack_3e8 + lVar5);
    puVar15 = auStack_428 + lVar5;
    if ((((ulonglong)puVar10 & 0x10) != 0) &&
       (uStack_3d0 = 0, puVar15 = auStack_428 + lVar5, uStack_39c != 0)) {
      do {
        lVar8 = lStack_390;
        uVar19 = uStack_3d0;
        if (*(byte *)(puVar21 + 0x10) < 0x1c) {
          UNRECOVERED_JUMPTABLE =
               (code *)((ulonglong)
                        *(uint *)((longlong)(char)*(byte *)(puVar21 + 0x10) * 4 + 0x1075c0) -
                       0x1d95c30);
                    /* WARNING: Could not emulate address calculation at 0x0010478e */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,0xfffffffffe26a3d0,1);
          return;
        }
        uVar13 = puVar21[0x10];
        if ((uVar13 >> 10 & 1) != 0) {
          lVar7 = lStack_360;
          if ((*(byte *)(*(longlong *)(puVar21 + 0x12) + 0x2a) & 0x10) != 0) {
            lVar7 = lStack_358;
          }
          *(undefined *)(lVar7 + *(longlong *)(puVar21 + 0xc)) = 3;
          uVar13 = puVar21[0x10];
        }
        if ((uVar13 >> 9 & 1) != 0) {
          *(undefined4 *)((longlong)&uStack_408 + lVar5) = uStack_3cc;
          *(undefined8 *)(auStack_428 + lVar5 + -8) = 0x1052df;
          func_0x(&lStack_378,lVar8,puVar21,0);
        }
        uStack_3d0 = uVar19 + 1;
        puVar21 = puVar21 + 0x14;
        puVar15 = auStack_428 + lVar5;
        puStack_398 = puVar21;
      } while (uStack_3d0 < uStack_39c);
    }
  }
  else {
    if (*param_2 == -1) {
      *param_2 = 1;
      puVar10 = (uint *)(ulonglong)uStack_364;
    }
    puVar15 = auStack_428;
    if ((((ulonglong)puVar10 & 0x10) != 0) &&
       (puVar15 = auStack_428, puVar10 = puStack_370, uStack_368 != 0)) {
      do {
        if (*(byte *)(puVar10 + 0x10) < 0x1c) {
          UNRECOVERED_JUMPTABLE =
               (code *)((ulonglong)
                        *(uint *)((longlong)(char)*(byte *)(puVar10 + 0x10) * 4 + 0x107418) -
                       0x1d95c30);
                    /* WARNING: Could not emulate address calculation at 0x00103e3e */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE);
          return;
        }
        uVar19 = puVar10[0x10];
        if ((uVar19 >> 10 & 1) != 0) {
          lVar5 = lStack_360;
          if ((*(byte *)(*(longlong *)(puVar10 + 0x12) + 0x2a) & 0x10) != 0) {
            lVar5 = lStack_358;
          }
          *(undefined *)(lVar5 + *(longlong *)(puVar10 + 0xc)) = 3;
          uVar19 = puVar10[0x10];
        }
        if ((uVar19 >> 9 & 1) != 0) {
          uStack_408 = (int *)CONCAT44(uStack_408._4_4_,uStack_3a0);
          uStack_430 = 0x104022;
          func_0x(&lStack_378,lStack_390,puVar10,0);
        }
        uVar19 = (int)puVar20 + 1;
        puVar20 = (uint *)(ulonglong)uVar19;
        puVar15 = auStack_428;
        puVar10 = puVar10 + 0x14;
      } while (uVar19 < uVar13);
    }
  }
LAB_:
  uVar11 = uStack_48 ^ (ulonglong)auStack_3e8;
  *(undefined8 *)(puVar15 + -8) = 0x105323;
  func_0x(uVar11);
  return;
}

