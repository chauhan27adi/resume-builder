
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong **param_2,undefined8 param_3,undefined4 param_4)

{
  byte **ppbVar1;
  short **ppsVar2;
  undefined uVar3;
  ushort uVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  longlong **pplVar7;
  longlong lVar8;
  bool bVar9;
  char cVar10;
  byte bVar11;
  short sVar12;
  undefined2 uVar13;
  int iVar14;
  int iVar15;
  longlong lVar16;
  ushort *puVar17;
  ulonglong uVar18;
  longlong *plVar19;
  undefined8 uVar20;
  ulonglong uVar21;
  short *psVar22;
  uint uVar23;
  longlong lVar24;
  undefined2 *puVar25;
  longlong *plVar26;
  longlong lVar27;
  undefined4 *puVar28;
  code *UNRECOVERED_JUMPTABLE_00;
  uint uVar29;
  longlong *plVar30;
  undefined8 *puVar31;
  int *piVar32;
  undefined4 uVar33;
  uint *puVar34;
  byte **ppbVar35;
  uint uVar36;
  byte *pbVar37;
  ushort uVar38;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar16 = func_0x();
  lVar16 = -lVar16;
  *(undefined8 *)(&stack0x00001218 + lVar16) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000024d8 + lVar16) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar16);
  *(undefined4 *)(&stack0x00000284 + lVar16) = param_4;
  *(undefined8 *)(&stack0x00000640 + lVar16) = param_3;
  *(longlong ***)(&stack0x00000868 + lVar16) = param_2;
  *(longlong *)(&stack0x00000568 + lVar16) = param_1;
  pplVar7 = *(longlong ***)(&stack0x00002548 + lVar16);
  *(longlong ***)(&stack0x00000878 + lVar16) = pplVar7;
  *(longlong *)(&stack0x00000880 + lVar16) = param_1;
  *(longlong ***)(&stack0x00000890 + lVar16) = param_2;
  *(longlong ***)(&stack0x00000888 + lVar16) = pplVar7;
  *(undefined8 *)(&stack0x00000038 + lVar16) = 0;
  (&stack0x00000040)[lVar16] = 0;
  uVar36 = *(uint *)(&stack0x00000044 + lVar16);
  *(uint *)(&stack0x00000044 + lVar16) = uVar36 & 0xffff0000;
  *(uint *)(&stack0x00000044 + lVar16) = uVar36 & 0xff000000;
  *(undefined4 *)(&stack0x00000044 + lVar16) = 0;
  puVar31 = (undefined8 *)**(longlong **)(param_1 + 8);
  *(ulonglong *)(&stack0x00000870 + lVar16) =
       (ulonglong)*(uint6 *)((longlong)puVar31 + 0x14) << 0x10;
  *(undefined2 *)(&stack0x00001900 + lVar16) = 0xffff;
  *(undefined8 *)(&stack0x00001908 + lVar16) = 0;
  *(undefined4 *)(&stack0x00001904 + lVar16) = 0;
  *(undefined8 *)(&stack0x0000191e + lVar16) = 0;
  *(undefined8 *)(&stack0x00001928 + lVar16) = 0;
  *(undefined8 *)(&stack0x00001910 + lVar16) = 0;
  *(undefined4 *)(&stack0x00001934 + lVar16) = 0xffffffff;
  *(undefined (*) [16])(&stack0x00001898 + lVar16) = ZEXT816(0);
  lVar24 = puVar31[1];
  *(undefined4 *)(&stack0x00000200 + lVar16) = *(undefined4 *)(lVar24 + 0x3c0);
  *(undefined2 *)(&stack0x00000204 + lVar16) = *(undefined2 *)(lVar24 + 0x3c4);
  *(undefined2 *)(&stack0x00000206 + lVar16) = 0;
  uVar33 = 2;
  if (*(int *)(param_1 + 0xfc) == 3) {
    uVar33 = 0;
  }
  *(undefined4 *)(&stack0x000009a0 + lVar16) = 0;
  *(undefined8 *)(&stack0x00000968 + lVar16) = 0;
  *(undefined8 **)(&stack0x00000970 + lVar16) = puVar31;
  UNRECOVERED_JUMPTABLE_00 = *(code **)*puVar31;
  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100178;
  sVar12 = (*UNRECOVERED_JUMPTABLE_00)(puVar31);
  if (sVar12 == 2) {
    uVar33 = 2;
  }
  *(undefined4 *)(&stack0x000009a4 + lVar16) = uVar33;
  (&stack0x00000052)[lVar16] = 1;
  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10019e;
  func_0x(param_1,0x1993690);
  *(undefined8 *)(&stack0x00000968 + lVar16) = *(undefined8 *)(param_1 + 0x110);
  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1001bd;
  func_0x(&stack0x00000968 + lVar16,param_3);
  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1001cd;
  func_0x(&stack0x00000968 + lVar16,param_2);
  if (*pplVar7 == (longlong *)0x0) {
    lVar24 = **param_2;
    *(longlong *)(&stack0x00001220 + lVar16) = lVar24;
    *(undefined4 **)(&stack0x00001228 + lVar16) = (undefined4 *)(lVar24 + 0x10);
    *(undefined4 *)(&stack0x000000fe + lVar16) = *(undefined4 *)(lVar24 + 0x10);
    *(undefined2 *)(&stack0x00000102 + lVar16) = *(undefined2 *)(lVar24 + 0x14);
    plVar30 = *(longlong **)(param_1 + 8);
    *(longlong **)(&stack0x00000620 + lVar16) = plVar30;
    *(undefined8 *)(&stack0x00000528 + lVar16) = *(undefined8 *)(param_1 + 0x10);
    *(undefined4 *)(&stack0x00000398 + lVar16) = 0;
    *(undefined4 *)(&stack0x0000039c + lVar16) = 0;
    *(undefined2 *)(&stack0x000003a0 + lVar16) = 0;
    lVar24 = *plVar30;
    *(longlong *)(&stack0x00000808 + lVar16) = lVar24;
    *(undefined4 *)(&stack0x00000924 + lVar16) = 0;
    *(undefined4 *)(&stack0x00000928 + lVar16) = 0;
    lVar27 = *(longlong *)(lVar24 + 0x20);
    *(longlong *)(&stack0x00000060 + lVar16) = lVar27;
    *(uint6 **)(&stack0x00001230 + lVar16) = (uint6 *)(lVar24 + 0x14);
    lVar24 = (ulonglong)*(uint6 *)(lVar24 + 0x14) * 0x10000;
    *(longlong *)(&stack0x00001238 + lVar16) = lVar24;
    if ((*(longlong *)(lVar27 + 2000) == lVar24) &&
       (*(longlong *)(lVar27 + 2000) - 1U < 0xfffffffffffffffe)) {
      (&stack0x00000068)[lVar16] = 1;
      goto LAB_;
    }
    (&stack0x00000068)[lVar16] = 0;
    if ((*(longlong *)(lVar27 + 0x7d8) == lVar24) &&
       (*(longlong *)(lVar27 + 0x7d8) - 1U < 0xfffffffffffffffe)) {
      (&stack0x00000069)[lVar16] = 1;
      goto LAB_;
    }
    (&stack0x00000069)[lVar16] = 0;
    lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
    *(longlong *)(&stack0x00001240 + lVar16) = lVar24;
    lVar27 = (ulonglong)*_DAT_ + *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8);
    *(longlong *)(&stack0x00001248 + lVar16) = lVar27;
    lVar24 = *(longlong *)(lVar27 + 0x100);
    *(longlong *)(&stack0x000007c8 + lVar16) = lVar24;
    puVar34 = _DAT_;
    if (lVar24 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100347;
      puVar34 = (uint *)(*_DAT_)(0);
      lVar24 = *(longlong *)(lVar27 + 0x100);
      *(longlong *)(&stack0x000007c8 + lVar16) = lVar24;
    }
    *(longlong *)(&stack0x00001250 + lVar16) = lVar24;
    uVar21 = rdtsc();
    uVar18 = CONCAT44((int)((ulonglong)puVar34 >> 0x20),(int)uVar21) | uVar21 & 0xffffffff00000000;
    *(ulonglong *)(&stack0x00001258 + lVar16) = uVar18;
    uVar21 = *(ulonglong *)(lVar24 + 0x340);
    if ((uVar21 < uVar18) ||
       ((uVar21 != 0x7fffffffffffffff &&
        (*(ulonglong *)(*(longlong *)(lVar24 + 0x260) + 0xdf0) < uVar21 - uVar18)))) {
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10040d;
      iVar14 = func_0x(0,0x20c6f18);
      *(int *)(&stack0x00000290 + lVar16) = iVar14;
      if (iVar14 == 2) {
LAB_:
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100420;
        func_0x(0x7c);
      }
    }
    else {
      lVar24 = *(longlong *)(lVar24 + 600);
      *(longlong *)(&stack0x000007d0 + lVar16) = lVar24;
      puVar34 = (uint *)(lVar24 + 0xbc);
      *(uint **)(&stack0x00001260 + lVar16) = puVar34;
      if ((*puVar34 & 4) != 0) {
        lVar24 = *(longlong *)(*(longlong *)(&stack0x000007d0 + lVar16) + 0x98);
        *(longlong *)(&stack0x00001268 + lVar16) = lVar24;
        if (((*(byte *)(lVar24 + 0x268) & 1) == 0) && ((*(uint *)(lVar24 + 800) & 0x180) == 0)) {
          *(undefined4 *)(&stack0x00000290 + lVar16) = 2;
          goto LAB_;
        }
      }
      *(undefined4 *)(&stack0x00000290 + lVar16) = 0;
    }
    lVar27 = *(longlong *)(&stack0x00000060 + lVar16);
LAB_:
    *(undefined4 *)(&stack0x00000670 + lVar16) = 0;
    *(undefined4 *)(&stack0x00000674 + lVar16) = 0;
    *(undefined2 *)(&stack0x00000678 + lVar16) = 0;
    (&stack0x0000006c)[lVar16] = 0;
    (&stack0x00000050)[lVar16] = 0xff;
    do {
      uVar20 = 0;
      *(undefined **)(&stack0x00000618 + lVar16) = &stack0x00000920 + lVar16;
      *(undefined4 *)(&stack0x0000186c + lVar16) = 0;
      *(undefined4 *)(&stack0x00001870 + lVar16) = 0;
      cVar10 = *_DAT_;
      (&stack0x00000104)[lVar16] = cVar10;
      if ((cVar10 != '\0') &&
         ((&stack0x00000105)[lVar16] = DAT_ >> 7, -1 < (char)DAT_)) {
        *(undefined4 *)(&stack0x00000508 + lVar16) = 0;
        lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001270 + lVar16) = lVar24;
        plVar30 = (longlong *)
                  ((ulonglong)*_DAT_ + *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8)
                  );
        *(longlong **)(&stack0x00001278 + lVar16) = plVar30;
        lVar24 = *plVar30;
        *(longlong *)(&stack0x00001280 + lVar16) = lVar24;
        if (lVar24 == 0) {
LAB_:
          *(undefined8 *)(&stack0x000007d8 + lVar16) = 0;
        }
        else {
          lVar24 = **(longlong **)(lVar24 + 0x38);
          *(longlong *)(&stack0x00001288 + lVar16) = lVar24;
          if (lVar24 == 0) goto LAB_;
          *(longlong *)(&stack0x000007d8 + lVar16) = lVar24;
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100525;
          iVar14 = (*_DAT_)(lVar24,0x337);
          *(int *)(&stack0x00000508 + lVar16) = iVar14;
          if (iVar14 != 0) {
            lVar27 = *(longlong *)(&stack0x00000060 + lVar16);
            goto LAB_;
          }
        }
        lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00001290 + lVar16) = lVar24;
        lVar24 = (ulonglong)*_DAT_ + *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00001298 + lVar16) = lVar24;
        lVar24 = *(longlong *)(lVar24 + 8);
        *(longlong *)(&stack0x000012a0 + lVar16) = lVar24;
        lVar27 = *(longlong *)(&stack0x00000060 + lVar16);
        if (lVar24 != 0) {
          uVar20 = *(undefined8 *)(lVar24 + 0x60);
        }
      }
LAB_:
      *(undefined8 *)(&stack0x000002c8 + lVar16) = uVar20;
      plVar30 = (longlong *)(lVar27 + 0x728);
      *(longlong *)(&stack0x000007e0 + lVar16) = *plVar30;
LAB_:
      *(undefined4 *)(&stack0x000002b4 + lVar16) = 0;
      if (*pplVar7 != (longlong *)0x0) {
        puVar17 = (ushort *)((longlong)*pplVar7 + 0x62);
        *(ushort **)(&stack0x000012a8 + lVar16) = puVar17;
        uVar4 = *puVar17;
        *(ushort *)(&stack0x00000130 + lVar16) = uVar4;
        if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)pplVar7 + 0xc) < 3)) {
          *(int *)(&stack0x000000b0 + lVar16) = (int)*(short *)((longlong)pplVar7 + 0xc);
          plVar19 = *pplVar7;
          *(longlong **)(&stack0x00000240 + lVar16) = plVar19;
          puVar25 = (undefined2 *)((longlong)plVar19 + 0x62);
          *(undefined2 **)(&stack0x000012b0 + lVar16) = puVar25;
          uVar13 = *puVar25;
          *(undefined2 *)(&stack0x00000138 + lVar16) = uVar13;
          if (((byte)uVar13 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x000000b0 + lVar16) == 3) {
              *(undefined4 *)(&stack0x000000b0 + lVar16) = 4;
            }
            else if (*(int *)(&stack0x000000b0 + lVar16) < 2) goto LAB_;
            *(uint **)(&stack0x000012b8 + lVar16) =
                 (uint *)(*(longlong *)(&stack0x00000240 + lVar16) + 100);
            uVar36 = *(uint *)(*(longlong *)(&stack0x00000240 + lVar16) + 100);
            *(uint *)(&stack0x000004a8 + lVar16) = uVar36;
            if ((((uVar36 & 8) != 0) &&
                (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000240 + lVar16) + 0x90),
                lVar24 != 0)) &&
               (*(longlong *)(&stack0x000012c0 + lVar16) = lVar24,
               *(longlong *)(lVar24 + 0x758) != 0)) {
              uVar20 = *(undefined8 *)(lVar24 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1006c7;
              func_0x
                        (uVar20,*(undefined8 *)(&stack0x00000240 + lVar16),
                         *(undefined4 *)(&stack0x000000b0 + lVar16));
            }
          }
LAB_:
          (&stack0x00000106)[lVar16] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar34 = (uint *)(*(longlong *)(&stack0x00000240 + lVar16) + 100);
            *(uint **)(&stack0x000012c8 + lVar16) = puVar34;
            uVar36 = *puVar34;
            *(uint *)(&stack0x000004a0 + lVar16) = uVar36;
            if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x000000b0 + lVar16))) {
              *(uint **)(&stack0x000012d0 + lVar16) = puVar34;
              uVar36 = *puVar34;
              *(uint *)(&stack0x00000498 + lVar16) = uVar36;
              if (((uVar36 & 0xc0000000) != 0x40000000) &&
                 (lVar24 = **(longlong **)(&stack0x00000240 + lVar16), lVar24 != 0)) {
                *(undefined4 *)(&stack0x000008c4 + lVar16) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10075a;
                iVar14 = (*_DAT_)(lVar24,0x2000,2,&stack0x000008c8 + lVar16);
                if (iVar14 != 0) {
                  LOCK();
                  *puVar34 = *puVar34 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar34 = *puVar34 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar24 = *(longlong *)(&stack0x00000240 + lVar16);
          uVar33 = *(undefined4 *)(&stack0x000000b0 + lVar16);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100789;
          func_0x(lVar24 + 0x98,uVar33);
          if ((_DAT_ != 0) &&
             ((&stack0x00000107)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1007b4;
            func_0x(lVar24,0,uVar33);
          }
          *(uint *)((longlong)pplVar7 + 0xc) = *(uint *)((longlong)pplVar7 + 0xc) & 0xffff0000;
          *pplVar7 = (longlong *)0x0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1005a2;
          func_0x(pplVar7);
        }
        lVar27 = *(longlong *)(&stack0x00000060 + lVar16);
      }
      if (*plVar30 != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1007e8;
        func_0x(pplVar7,&stack0x000000fe + lVar16,lVar27);
        if (*pplVar7 != (longlong *)0x0) {
          puVar17 = (ushort *)((longlong)*pplVar7 + 0x62);
          *(ushort **)(&stack0x000012d8 + lVar16) = puVar17;
          uVar4 = *puVar17;
          *(ushort *)(&stack0x00000140 + lVar16) = uVar4;
          if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)pplVar7 + 0xc) < 3)) {
            *(int *)(&stack0x000000b8 + lVar16) = (int)*(short *)((longlong)pplVar7 + 0xc);
            plVar19 = *pplVar7;
            *(longlong **)(&stack0x00000248 + lVar16) = plVar19;
            puVar25 = (undefined2 *)((longlong)plVar19 + 0x62);
            *(undefined2 **)(&stack0x000012e0 + lVar16) = puVar25;
            uVar13 = *puVar25;
            *(undefined2 *)(&stack0x00000148 + lVar16) = uVar13;
            if (((byte)uVar13 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000b8 + lVar16) == 3) {
                *(undefined4 *)(&stack0x000000b8 + lVar16) = 4;
              }
              else if (*(int *)(&stack0x000000b8 + lVar16) < 2) goto LAB_;
              *(uint **)(&stack0x000012e8 + lVar16) =
                   (uint *)(*(longlong *)(&stack0x00000248 + lVar16) + 100);
              uVar36 = *(uint *)(*(longlong *)(&stack0x00000248 + lVar16) + 100);
              *(uint *)(&stack0x00000478 + lVar16) = uVar36;
              if ((((uVar36 & 8) != 0) &&
                  (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000248 + lVar16) + 0x90),
                  lVar24 != 0)) &&
                 (*(longlong *)(&stack0x000012f0 + lVar16) = lVar24,
                 *(longlong *)(lVar24 + 0x758) != 0)) {
                uVar20 = *(undefined8 *)(lVar24 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1008eb;
                func_0x
                          (uVar20,*(undefined8 *)(&stack0x00000248 + lVar16),
                           *(undefined4 *)(&stack0x000000b8 + lVar16));
              }
            }
LAB_:
            (&stack0x00000108)[lVar16] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar34 = (uint *)(*(longlong *)(&stack0x00000248 + lVar16) + 100);
              *(uint **)(&stack0x000012f8 + lVar16) = puVar34;
              uVar36 = *puVar34;
              *(uint *)(&stack0x00000470 + lVar16) = uVar36;
              if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x000000b8 + lVar16))) {
                *(uint **)(&stack0x00001300 + lVar16) = puVar34;
                uVar36 = *puVar34;
                *(uint *)(&stack0x00000580 + lVar16) = uVar36;
                if (((uVar36 & 0xc0000000) != 0x40000000) &&
                   (lVar24 = **(longlong **)(&stack0x00000248 + lVar16), lVar24 != 0)) {
                  *(undefined4 *)(&stack0x000008cc + lVar16) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10097e;
                  iVar14 = (*_DAT_)(lVar24,0x2000,2,&stack0x000008d0 + lVar16);
                  if (iVar14 != 0) {
                    LOCK();
                    *puVar34 = *puVar34 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar34 = *puVar34 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar24 = *(longlong *)(&stack0x00000248 + lVar16);
            uVar33 = *(undefined4 *)(&stack0x000000b8 + lVar16);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1009ad;
            func_0x(lVar24 + 0x98,uVar33);
            if ((_DAT_ != 0) &&
               ((&stack0x00000109)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1009d8;
              func_0x(lVar24,0,uVar33);
            }
            *(uint *)((longlong)pplVar7 + 0xc) = *(uint *)((longlong)pplVar7 + 0xc) & 0xffff0000;
            *pplVar7 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100823;
            func_0x(pplVar7);
          }
          lVar27 = *(longlong *)(&stack0x00000060 + lVar16);
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1009ff;
      func_0x(lVar27,&stack0x000000fe + lVar16);
      *(undefined8 *)(&stack0xfffffffffffffff0 + lVar16) =
           *(undefined8 *)(&stack0x00000618 + lVar16);
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) = 4;
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100a33;
      plVar19 = (longlong *)
                func_0x
                          (_DAT_,lVar27,&stack0x000000fe + lVar16,&stack0x000002b4 + lVar16)
      ;
      *pplVar7 = plVar19;
      uVar36 = *(uint *)((longlong)pplVar7 + 0xc) & 0xffff0004 | 4;
      *(uint *)((longlong)pplVar7 + 0xc) = uVar36;
      if (*(longlong *)(&stack0x000002c8 + lVar16) != 0) {
        lVar24 = *plVar19;
        *(longlong *)(&stack0x00001308 + lVar16) = lVar24;
        plVar26 = (longlong *)(*(longlong *)(&stack0x000002c8 + lVar16) + 0x500);
        *(longlong **)(&stack0x00001310 + lVar16) = plVar26;
        plVar19 = plVar26 + (ulonglong)(*(uint *)plVar26 & 0xf) + 1;
        *(longlong **)(&stack0x00001318 + lVar16) = plVar19;
        if (*plVar19 != lVar24) {
          *plVar19 = lVar24;
          *plVar26 = *plVar26 + 1;
          uVar36 = *(uint *)((longlong)pplVar7 + 0xc);
        }
      }
      uVar29 = *(uint *)(&stack0x000002b4 + lVar16);
      uVar23 = uVar29 >> 3 & 1;
      *(uint *)((longlong)pplVar7 + 0xc) = uVar23 << 0x18 | uVar36 & 0xffffff;
      *(uint *)(pplVar7 + 2) = *(uint *)(pplVar7 + 2) & 0xffffff00;
      *(uint *)(pplVar7 + 2) = *(uint *)(pplVar7 + 2) | uVar29 >> 4 & 1;
      lVar24 = *(longlong *)(&stack0x000007e0 + lVar16);
      if (((lVar24 != 0) && (*(longlong *)(&stack0x000002c8 + lVar16) != 0)) &&
         (*(longlong *)(&stack0x000002c8 + lVar16) == *(longlong *)(lVar27 + 0x1c38))) {
        *(uint *)(&stack0x000008d8 + lVar16) = uVar23;
        *(longlong *)(&stack0x00000a30 + lVar16) = lVar24 + 0x59b8;
        *(longlong *)(lVar24 + 0x5b28) = *(longlong *)(lVar24 + 0x5b28) + 1;
        puVar34 = *(uint **)(&stack0x00000618 + lVar16);
        if (puVar34[1] != 0) {
          *(longlong *)(lVar24 + 0x5b30) = *(longlong *)(lVar24 + 0x5b30) + 1;
          *(longlong *)(lVar24 + 0x5b38) = *(longlong *)(lVar24 + 0x5b38) + (ulonglong)*puVar34;
          if (uVar23 != 0) {
            *(longlong *)(lVar24 + 0x5b40) = *(longlong *)(lVar24 + 0x5b40) + 1;
            *(longlong *)(lVar24 + 0x5b48) = *(longlong *)(lVar24 + 0x5b48) + (ulonglong)*puVar34;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100b4a;
      cVar10 = func_0x(lVar27);
      if ((cVar10 == '\0') || (*(char *)(lVar27 + 0x2050) == '\0')) goto LAB_;
      if (*(int *)(&stack0x000000fe + lVar16) == 0) {
LAB_:
        (&stack0x0000006e)[lVar16] = 1;
        goto LAB_;
      }
      *(undefined4 *)(&stack0x00000662 + lVar16) = 9;
      *(undefined2 *)(&stack0x00000666 + lVar16) = 1;
      if ((*(int *)(&stack0x000000fe + lVar16) == 9) && (*(short *)(&stack0x00000102 + lVar16) == 1)
         ) goto LAB_;
      (&stack0x0000006e)[lVar16] = 0;
      lVar24 = **pplVar7;
      *(longlong *)(&stack0x00000a38 + lVar16) = lVar24;
      (&stack0x0000006a)[lVar16] = 0;
      if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
        *(undefined8 *)(&stack0x000002d0 + lVar16) = *(undefined8 *)(lVar24 + 0x28);
        *(undefined2 *)(&stack0x000002d8 + lVar16) = *(undefined2 *)(lVar24 + 0x30);
      }
      else {
        cVar10 = *(char *)(lVar24 + 1);
        if ((((cVar10 == '\v') || (cVar10 == '\b')) || (cVar10 == '\t')) &&
           (*(int *)(lVar24 + 0x18) == 99)) {
          *(undefined **)(&stack0x00000a40 + lVar16) = &stack0x00000350 + lVar16;
          *(undefined4 **)(&stack0x00000a48 + lVar16) = (undefined4 *)(lVar24 + 0x20);
          *(undefined4 *)(&stack0x00000350 + lVar16) = *(undefined4 *)(lVar24 + 0x20);
          *(undefined2 *)(&stack0x00000354 + lVar16) = *(undefined2 *)(lVar24 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100c13;
          cVar10 = func_0x(&stack0x00000350 + lVar16);
          if (cVar10 == '\0') goto LAB_;
          cVar10 = '\x01';
        }
        else {
LAB_:
          cVar10 = '\0';
        }
        (&stack0x0000006a)[lVar16] = cVar10;
        if (cVar10 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100c3a;
        func_0x(lVar24,&stack0x000002d0 + lVar16);
      }
      *(undefined **)(&stack0x00000a50 + lVar16) = &stack0x000002d0 + lVar16;
      *(longlong *)(&stack0x000007e8 + lVar16) = lVar27 + 0x20fc;
      *(undefined4 *)(&stack0x0000029c + lVar16) = 0;
      *(undefined4 *)(&stack0x000002a0 + lVar16) = 0;
      *(undefined2 *)(&stack0x000002a4 + lVar16) = 0;
      *(undefined2 *)(&stack0x000002a6 + lVar16) = 0;
      puVar34 = (uint *)(lVar27 + 0x2108);
      *(uint **)(&stack0x00000a58 + lVar16) = puVar34;
      uVar36 = *puVar34;
      *(uint *)(&stack0x000002b8 + lVar16) = uVar36;
      *(uint **)(&stack0x000007f0 + lVar16) = puVar34;
      do {
        *(uint *)(&stack0x00000588 + lVar16) = uVar36 & 0xfffffffe;
        *(undefined8 *)(&stack0x0000029c + lVar16) = **(undefined8 **)(&stack0x000007e8 + lVar16);
        *(undefined4 *)(&stack0x000002a4 + lVar16) =
             *(undefined4 *)(*(undefined8 **)(&stack0x000007e8 + lVar16) + 1);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16);
        UNLOCK();
        uVar36 = **(uint **)(&stack0x000007f0 + lVar16);
        *(uint *)(&stack0x000002b8 + lVar16) = uVar36;
      } while (*(uint *)(&stack0x00000588 + lVar16) != uVar36);
      if ((*(uint *)(&stack0x000002d0 + lVar16) <= *(uint *)(&stack0x0000029c + lVar16)) &&
         ((*(uint *)(&stack0x0000029c + lVar16) != *(uint *)(&stack0x000002d0 + lVar16) ||
          ((uVar36 = (uint)((ulonglong)*(undefined8 *)(&stack0x0000029c + lVar16) >> 0x20),
           *(uint *)(&stack0x000002d4 + lVar16) <= uVar36 &&
           ((uVar36 != *(uint *)(&stack0x000002d4 + lVar16) ||
            (*(ushort *)(&stack0x000002d8 + lVar16) <= *(ushort *)(&stack0x000002a4 + lVar16))))))))
         ) goto LAB_;
      if (*(char *)(*(longlong *)(&stack0x00000060 + lVar16) + 0x6ac8) != '\0') {
LAB_:
        if ((&stack0x0000006c)[lVar16] != '\0') goto LAB_;
        lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00000b28 + lVar16) = lVar24;
        lVar24 = (ulonglong)*_DAT_ + *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00000b30 + lVar16) = lVar24;
        lVar24 = *(longlong *)(lVar24 + 8);
        *(longlong *)(&stack0x00000b38 + lVar16) = lVar24;
        lVar24 = *(longlong *)(lVar24 + 0x60);
        *(longlong *)(&stack0x00000b40 + lVar16) = lVar24;
        lVar27 = *(longlong *)(&stack0x00000060 + lVar16);
        if (lVar24 == *(longlong *)(lVar27 + 0x2120)) goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101460;
        cVar10 = func_0x(lVar27);
        if (cVar10 != '\0') goto LAB_;
        if (*(longlong *)(&stack0x000002c8 + lVar16) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101478;
          uVar20 = func_0x();
          *(undefined8 *)(&stack0x000002c8 + lVar16) = uVar20;
        }
        *(undefined **)(&stack0x00000b48 + lVar16) = &stack0x000002f0 + lVar16;
        lVar24 = **pplVar7;
        *(longlong *)(&stack0x00000b50 + lVar16) = lVar24;
        (&stack0x0000006d)[lVar16] = 0;
        if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
          uVar20 = *(undefined8 *)(lVar24 + 0x28);
          *(undefined8 *)(&stack0x000002f0 + lVar16) = uVar20;
          uVar13 = *(undefined2 *)(lVar24 + 0x30);
          *(undefined2 *)(&stack0x000002f8 + lVar16) = uVar13;
        }
        else {
          cVar10 = *(char *)(lVar24 + 1);
          if (((cVar10 == '\v') && (*(int *)(lVar24 + 0x18) == 99)) ||
             (((cVar10 == '\b' || (cVar10 == '\t')) && (*(int *)(lVar24 + 0x18) == 99)))) {
            *(undefined **)(&stack0x00000b58 + lVar16) = &stack0x00000338 + lVar16;
            *(undefined4 **)(&stack0x00000b60 + lVar16) = (undefined4 *)(lVar24 + 0x20);
            *(undefined4 *)(&stack0x00000338 + lVar16) = *(undefined4 *)(lVar24 + 0x20);
            *(undefined2 *)(&stack0x0000033c + lVar16) = *(undefined2 *)(lVar24 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101510;
            cVar10 = func_0x(&stack0x00000338 + lVar16);
            if (cVar10 == '\0') goto LAB_;
            cVar10 = '\x01';
          }
          else {
LAB_:
            cVar10 = '\0';
          }
          (&stack0x0000006d)[lVar16] = cVar10;
          if (cVar10 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101537;
          func_0x(lVar24,&stack0x000002f0 + lVar16);
          uVar13 = *(undefined2 *)(&stack0x000002f8 + lVar16);
          uVar20 = *(undefined8 *)(&stack0x000002f0 + lVar16);
        }
        *(undefined **)(&stack0x00000b68 + lVar16) = &stack0x000002f0 + lVar16;
        *(undefined8 *)(&stack0x000003b8 + lVar16) = uVar20;
        *(undefined2 *)(&stack0x000003c0 + lVar16) = uVar13;
        *(undefined2 *)(&stack0x000003c2 + lVar16) = 0;
        if (*pplVar7 != (longlong *)0x0) {
          puVar17 = (ushort *)((longlong)*pplVar7 + 0x62);
          *(ushort **)(&stack0x00000b70 + lVar16) = puVar17;
          uVar4 = *puVar17;
          *(ushort *)(&stack0x00000150 + lVar16) = uVar4;
          if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)pplVar7 + 0xc) < 3)) {
            *(int *)(&stack0x000000c0 + lVar16) = (int)*(short *)((longlong)pplVar7 + 0xc);
            plVar19 = *pplVar7;
            *(longlong **)(&stack0x00000250 + lVar16) = plVar19;
            puVar25 = (undefined2 *)((longlong)plVar19 + 0x62);
            *(undefined2 **)(&stack0x00000b78 + lVar16) = puVar25;
            uVar13 = *puVar25;
            *(undefined2 *)(&stack0x00000158 + lVar16) = uVar13;
            if (((byte)uVar13 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000c0 + lVar16) == 3) {
                *(undefined4 *)(&stack0x000000c0 + lVar16) = 4;
              }
              else if (*(int *)(&stack0x000000c0 + lVar16) < 2) goto LAB_;
              *(uint **)(&stack0x00000b80 + lVar16) =
                   (uint *)(*(longlong *)(&stack0x00000250 + lVar16) + 100);
              uVar36 = *(uint *)(*(longlong *)(&stack0x00000250 + lVar16) + 100);
              *(uint *)(&stack0x00000518 + lVar16) = uVar36;
              if ((((uVar36 & 8) != 0) &&
                  (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000250 + lVar16) + 0x90),
                  lVar24 != 0)) &&
                 (*(longlong *)(&stack0x00000b88 + lVar16) = lVar24,
                 *(longlong *)(lVar24 + 0x758) != 0)) {
                uVar20 = *(undefined8 *)(lVar24 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101696;
                func_0x
                          (uVar20,*(undefined8 *)(&stack0x00000250 + lVar16),
                           *(undefined4 *)(&stack0x000000c0 + lVar16));
              }
            }
LAB_:
            (&stack0x0000010a)[lVar16] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar34 = (uint *)(*(longlong *)(&stack0x00000250 + lVar16) + 100);
              *(uint **)(&stack0x00000b90 + lVar16) = puVar34;
              uVar36 = *puVar34;
              *(uint *)(&stack0x00000520 + lVar16) = uVar36;
              if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x000000c0 + lVar16))) {
                *(uint **)(&stack0x00000b98 + lVar16) = puVar34;
                uVar36 = *puVar34;
                *(uint *)(&stack0x00000560 + lVar16) = uVar36;
                if (((uVar36 & 0xc0000000) != 0x40000000) &&
                   (lVar24 = **(longlong **)(&stack0x00000250 + lVar16), lVar24 != 0)) {
                  *(undefined4 *)(&stack0x000008ec + lVar16) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101729;
                  iVar14 = (*_DAT_)(lVar24,0x2000,2,&stack0x000008f0 + lVar16);
                  if (iVar14 != 0) {
                    LOCK();
                    *puVar34 = *puVar34 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar34 = *puVar34 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar24 = *(longlong *)(&stack0x00000250 + lVar16);
            uVar33 = *(undefined4 *)(&stack0x000000c0 + lVar16);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101758;
            func_0x(lVar24 + 0x98,uVar33);
            if ((_DAT_ != 0) &&
               ((&stack0x0000010b)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101783;
              func_0x(lVar24,0,uVar33);
            }
            *(uint *)((longlong)pplVar7 + 0xc) = *(uint *)((longlong)pplVar7 + 0xc) & 0xffff0000;
            *pplVar7 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1015cf;
            func_0x(pplVar7);
          }
          uVar20 = *(undefined8 *)(&stack0x000003b8 + lVar16);
          uVar13 = *(undefined2 *)(&stack0x000003c0 + lVar16);
          lVar27 = *(longlong *)(&stack0x00000060 + lVar16);
        }
        *(undefined **)(&stack0x00000ba0 + lVar16) = &stack0x00000690 + lVar16;
        *(undefined8 *)(&stack0x00000690 + lVar16) = uVar20;
        *(undefined2 *)(&stack0x00000698 + lVar16) = uVar13;
        *(undefined **)(&stack0x00000ba8 + lVar16) = &stack0x000005f8 + lVar16;
        *(undefined8 *)(&stack0x000005f8 + lVar16) = uVar20;
        *(undefined2 *)(&stack0x00000600 + lVar16) = uVar13;
        *(undefined8 *)(&stack0xffffffffffffffe8 + lVar16) = 0;
        lVar24 = *plVar30;
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10180e;
        func_0x(lVar24,&stack0x000005f8 + lVar16,4);
        goto LAB_;
      }
      lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00000a60 + lVar16) = lVar24;
      lVar24 = (ulonglong)*_DAT_ + *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00000a68 + lVar16) = lVar24;
      lVar24 = *(longlong *)(lVar24 + 8);
      *(longlong *)(&stack0x00000a70 + lVar16) = lVar24;
      lVar24 = *(longlong *)(lVar24 + 0x60);
      *(longlong *)(&stack0x00000a78 + lVar16) = lVar24;
      if (lVar24 == *(longlong *)(*(longlong *)(&stack0x00000060 + lVar16) + 0x2120))
      goto LAB_;
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100dbe;
      cVar10 = func_0x(*(longlong *)(&stack0x00000060 + lVar16));
      if (cVar10 != '\0') goto LAB_;
      *(longlong *)(&stack0x00000648 + lVar16) = lVar27 + 0x20fc;
      bVar9 = false;
      *(undefined4 *)(&stack0x00000264 + lVar16) = 0;
      *(undefined4 *)(&stack0x00000268 + lVar16) = 0;
      *(undefined2 *)(&stack0x0000026c + lVar16) = 0;
      *(undefined2 *)(&stack0x0000026e + lVar16) = 0;
      *(uint **)(&stack0x00000a80 + lVar16) = puVar34;
      uVar36 = *puVar34;
      *(uint *)(&stack0x000002bc + lVar16) = uVar36;
      puVar31 = *(undefined8 **)(&stack0x00000648 + lVar16);
      *(longlong *)(&stack0x000007f8 + lVar16) = (longlong)puVar31 + 0xc;
      while( true ) {
        *(uint *)(&stack0x0000050c + lVar16) = uVar36 & 0xfffffffe;
        *(undefined8 *)(&stack0x00000264 + lVar16) = *puVar31;
        *(undefined4 *)(&stack0x0000026c + lVar16) = *(undefined4 *)(puVar31 + 1);
        LOCK();
        *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16) =
             *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16);
        UNLOCK();
        uVar36 = **(uint **)(&stack0x000007f8 + lVar16);
        *(uint *)(&stack0x000002bc + lVar16) = uVar36;
        if (*(uint *)(&stack0x0000050c + lVar16) == uVar36) break;
        puVar31 = *(undefined8 **)(&stack0x00000648 + lVar16);
      }
      *(undefined8 *)(&stack0x00000680 + lVar16) = *(undefined8 *)(&stack0x00000264 + lVar16);
      uVar4 = *(ushort *)(&stack0x0000026c + lVar16);
      *(ushort *)(&stack0x00000688 + lVar16) = uVar4;
      lVar24 = **pplVar7;
      *(longlong *)(&stack0x00000a88 + lVar16) = lVar24;
      (&stack0x0000006b)[lVar16] = 0;
      if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
        *(undefined8 *)(&stack0x000002e0 + lVar16) = *(undefined8 *)(lVar24 + 0x28);
        uVar38 = *(ushort *)(lVar24 + 0x30);
        *(ushort *)(&stack0x000002e8 + lVar16) = uVar38;
      }
      else {
        cVar10 = *(char *)(lVar24 + 1);
        if ((((cVar10 == '\v') || (cVar10 == '\b')) || (cVar10 == '\t')) &&
           (*(int *)(lVar24 + 0x18) == 99)) {
          *(undefined **)(&stack0x00000a90 + lVar16) = &stack0x00000360 + lVar16;
          *(undefined4 **)(&stack0x00000a98 + lVar16) = (undefined4 *)(lVar24 + 0x20);
          *(undefined4 *)(&stack0x00000360 + lVar16) = *(undefined4 *)(lVar24 + 0x20);
          *(undefined2 *)(&stack0x00000364 + lVar16) = *(undefined2 *)(lVar24 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100f03;
          cVar10 = func_0x(&stack0x00000360 + lVar16);
          if (cVar10 == '\0') goto LAB_;
          cVar10 = '\x01';
        }
        else {
LAB_:
          cVar10 = '\0';
        }
        (&stack0x0000006b)[lVar16] = cVar10;
        if (cVar10 == '\0') goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100f2a;
        func_0x(lVar24,&stack0x000002e0 + lVar16);
        uVar38 = *(ushort *)(&stack0x000002e8 + lVar16);
      }
      if ((*(uint *)(&stack0x00000264 + lVar16) < *(uint *)(&stack0x000002e0 + lVar16)) ||
         ((*(uint *)(&stack0x00000264 + lVar16) == *(uint *)(&stack0x000002e0 + lVar16) &&
          ((uVar36 = (uint)((ulonglong)*(undefined8 *)(&stack0x000002e0 + lVar16) >> 0x20),
           *(uint *)(&stack0x00000268 + lVar16) < uVar36 ||
           ((*(uint *)(&stack0x00000268 + lVar16) == uVar36 && (uVar4 < uVar38)))))))) {
        bVar9 = true;
      }
      if (bVar9) {
        lVar24 = *(longlong *)(&stack0x00000060 + lVar16);
        lVar27 = *(longlong *)(lVar24 + 0x6b0);
        *(longlong *)(&stack0x00000aa0 + lVar16) = lVar27;
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100fc4;
        func_0x(&stack0x000002e0 + lVar16,&stack0x000019b0 + lVar16,
                        &stack0x00000510 + lVar16);
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x100fe1;
        func_0x(&stack0x00000680 + lVar16,&stack0x000019e0 + lVar16,
                        &stack0x00000510 + lVar16);
        *(undefined4 *)(&stack0x00000800 + lVar16) = 0x1d;
        *(undefined4 *)(&stack0x00000804 + lVar16) = 0x10000;
        if ((_DAT_ & 0x10000) != 0) {
          *(undefined2 *)(&stack0x00000480 + lVar16) = 6;
          *(undefined **)(&stack0x00000aa8 + lVar16) = &stack0x00001330 + lVar16;
          *(undefined2 *)(&stack0x00001330 + lVar16) = 0;
          *(undefined2 *)(&stack0x00001332 + lVar16) = 6;
          *(undefined4 *)(&stack0x00001338 + lVar16) = 0;
          *(undefined **)(&stack0x00001340 + lVar16) = &stack0x00001358 + lVar16;
          *(undefined **)(&stack0x00001348 + lVar16) = &stack0x000013b8 + lVar16;
          *(undefined4 *)(&stack0x00001578 + lVar16) = 0;
          *(undefined4 *)(&stack0x0000157c + lVar16) = 0;
          *(undefined8 *)(&stack0x00001350 + lVar16) = 0;
          *(undefined8 *)(&stack0x00001580 + lVar16) = 0;
          *(undefined **)(&stack0x00000ab0 + lVar16) = &stack0x00001358 + lVar16;
          *(undefined **)(&stack0x00001358 + lVar16) = &stack0x00001588 + lVar16;
          *(undefined4 *)(&stack0x00001360 + lVar16) = 0x34;
          *(undefined2 *)(&stack0x00001364 + lVar16) = 5;
          *(undefined2 *)(&stack0x00001366 + lVar16) = 0;
          *(undefined **)(&stack0x00000ab8 + lVar16) = &stack0x00001368 + lVar16;
          *(undefined8 *)(&stack0x00001368 + lVar16) = 0x18b7178;
          *(undefined4 *)(&stack0x00001370 + lVar16) = 0x10;
          *(undefined2 *)(&stack0x00001374 + lVar16) = 5;
          *(undefined2 *)(&stack0x00001376 + lVar16) = 0;
          *(undefined **)(&stack0x00000ac0 + lVar16) = &stack0x00001378 + lVar16;
          *(undefined8 *)(&stack0x00001378 + lVar16) = 0x18b7178;
          *(undefined4 *)(&stack0x00001380 + lVar16) = 0x10;
          *(undefined2 *)(&stack0x00001384 + lVar16) = 6;
          *(undefined2 *)(&stack0x00001386 + lVar16) = 0;
          *(undefined **)(&stack0x00000ac8 + lVar16) = &stack0x00001388 + lVar16;
          *(undefined8 *)(&stack0x00001388 + lVar16) = 0;
          *(undefined4 *)(&stack0x00001390 + lVar16) = 0;
          *(undefined2 *)(&stack0x00001394 + lVar16) = 7;
          *(undefined2 *)(&stack0x00001396 + lVar16) = 0;
          *(undefined **)(&stack0x00000ad0 + lVar16) = &stack0x00001398 + lVar16;
          *(undefined8 *)(&stack0x00001398 + lVar16) = 0;
          *(undefined4 *)(&stack0x000013a0 + lVar16) = 0;
          *(undefined2 *)(&stack0x000013a4 + lVar16) = 8;
          *(undefined2 *)(&stack0x000013a6 + lVar16) = 0;
          *(undefined **)(&stack0x00000ad8 + lVar16) = &stack0x000013a8 + lVar16;
          *(undefined8 *)(&stack0x000013a8 + lVar16) = 0;
          *(undefined4 *)(&stack0x000013b0 + lVar16) = 0;
          *(undefined2 *)(&stack0x000013b4 + lVar16) = 9;
          *(undefined2 *)(&stack0x000013b6 + lVar16) = 0;
          *(uint *)(&stack0x00001588 + lVar16) = (uint)*(ushort *)(lVar24 + 0x6b8);
          *(undefined2 *)(&stack0x0000158c + lVar16) = *(undefined2 *)(&stack0x00000102 + lVar16);
          *(undefined4 *)(&stack0x0000158e + lVar16) = *(undefined4 *)(&stack0x000000fe + lVar16);
          (&stack0x00001592)[lVar16] = (&stack0x00000050)[lVar16];
          lVar24 = **pplVar7;
          *(longlong *)(&stack0x00000ae0 + lVar16) = lVar24;
          (&stack0x00001593)[lVar16] = *(undefined *)(lVar24 + 1);
          *(undefined **)(&stack0x00000ae8 + lVar16) = &stack0x00001368 + lVar16;
          *(longlong *)(&stack0x00001368 + lVar16) = lVar27 + 0x254;
          *(undefined4 *)(&stack0x00001370 + lVar16) = 0x10;
          *(undefined2 *)(&stack0x00001374 + lVar16) = 5;
          *(undefined2 *)(&stack0x00001376 + lVar16) = 0;
          *(undefined **)(&stack0x00000af0 + lVar16) = &stack0x00001378 + lVar16;
          *(longlong *)(&stack0x00001378 + lVar16) = lVar27 + 0x244;
          *(undefined4 *)(&stack0x00001380 + lVar16) = 0x10;
          *(undefined2 *)(&stack0x00001384 + lVar16) = 6;
          *(undefined2 *)(&stack0x00001386 + lVar16) = 0;
          *(undefined **)(&stack0x00000af8 + lVar16) = &stack0x000019b0 + lVar16;
          lVar24 = -1;
          do {
            lVar24 = lVar24 + 1;
          } while (*(short *)(&stack0x000019b0 + lVar24 * 2 + lVar16) != 0);
          iVar14 = (int)lVar24 * 2;
          *(int *)(&stack0x000008e0 + lVar16) = iVar14;
          *(undefined **)(&stack0x00000b00 + lVar16) = &stack0x00001388 + lVar16;
          *(undefined **)(&stack0x00001388 + lVar16) = &stack0x000019b0 + lVar16;
          *(int *)(&stack0x00001390 + lVar16) = iVar14;
          *(undefined2 *)(&stack0x00001394 + lVar16) = 7;
          *(undefined2 *)(&stack0x00001396 + lVar16) = 0;
          *(undefined **)(&stack0x00000b08 + lVar16) = &stack0x000019e0 + lVar16;
          lVar24 = -1;
          do {
            lVar24 = lVar24 + 1;
          } while (*(short *)(&stack0x000019e0 + lVar24 * 2 + lVar16) != 0);
          iVar14 = (int)lVar24 * 2;
          *(int *)(&stack0x000008e4 + lVar16) = iVar14;
          *(undefined **)(&stack0x00000b10 + lVar16) = &stack0x00001398 + lVar16;
          *(undefined **)(&stack0x00001398 + lVar16) = &stack0x000019e0 + lVar16;
          *(int *)(&stack0x000013a0 + lVar16) = iVar14;
          *(undefined2 *)(&stack0x000013a4 + lVar16) = 8;
          *(undefined2 *)(&stack0x000013a6 + lVar16) = 0;
          *(undefined4 *)(&stack0x00000514 + lVar16) = 0;
          UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10138e;
          lVar24 = (*UNRECOVERED_JUMPTABLE_00)(lVar27,&stack0x00000514 + lVar16);
          *(longlong *)(&stack0x00000b18 + lVar16) = lVar24;
          if (lVar24 == 0) {
            iVar14 = 0;
          }
          else {
            lVar27 = -1;
            do {
              lVar27 = lVar27 + 1;
            } while (*(short *)(lVar24 + lVar27 * 2) != 0);
            iVar14 = (int)lVar27 * 2;
          }
          *(int *)(&stack0x000008e8 + lVar16) = iVar14;
          lVar27 = *(longlong *)(&stack0x00001340 + lVar16);
          *(longlong **)(&stack0x00000b20 + lVar16) = (longlong *)(lVar27 + 0x50);
          *(longlong *)(lVar27 + 0x50) = lVar24;
          *(int *)(lVar27 + 0x58) = iVar14;
          *(undefined2 *)(lVar27 + 0x5c) = 9;
          *(undefined2 *)(lVar27 + 0x5e) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1013e9;
          func_0x(&stack0x00001328 + lVar16);
        }
      }
LAB_:
      if ((1 < *(short *)((longlong)pplVar7 + 0xc)) && ((&stack0x00000050)[lVar16] != -1)) {
        lVar24 = **pplVar7;
        *(longlong *)(&stack0x00000bb0 + lVar16) = lVar24;
        if (*(char *)(lVar24 + 1) != (&stack0x00000050)[lVar16]) {
          if (*(longlong *)(&stack0x000002c8 + lVar16) != 0) {
            *(longlong *)(&stack0x00000bb8 + lVar16) = lVar24;
            *(longlong *)(*(longlong *)(&stack0x000002c8 + lVar16) + 0x588) = lVar24;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10187e;
          lVar24 = func_0x();
          if (lVar24 == 0) {
LAB_:
            *(undefined4 *)(&stack0x0000058c + lVar16) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101888;
            lVar24 = func_0x();
            if (*(longlong *)(lVar24 + 0x30) == 0) goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101894;
            lVar24 = func_0x();
            uVar36 = *(uint *)(*(longlong *)(lVar24 + 0x30) + 0xc);
            *(uint *)(&stack0x000008f4 + lVar16) = uVar36;
            if ((0xd < uVar36) || (iVar14 = 1, (0x2640U >> (uVar36 & 0x1f) & 1) == 0)) {
              iVar14 = 0;
            }
            *(int *)(&stack0x0000058c + lVar16) = iVar14;
            if (iVar14 != 0) goto LAB_;
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1018d3;
          func_0x(0,8);
        }
      }
LAB_:
      *(undefined4 *)(&stack0x000006a0 + lVar16) = 0;
      *(undefined4 *)(&stack0x000006a4 + lVar16) = 0;
      *(undefined2 *)(&stack0x000006a8 + lVar16) = 0;
      if (((*(short *)(&stack0x000003a0 + lVar16) == 0) &&
          (*(int *)(&stack0x00000398 + lVar16) == 0)) && (*(int *)(&stack0x0000039c + lVar16) == 0))
      {
LAB_:
        lVar24 = *(longlong *)(&stack0x00000528 + lVar16);
        *(int *)(lVar24 + 4) = *(int *)(lVar24 + 4) + 1;
        if (*(longlong *)(lVar24 + 0x58) != 0) {
          piVar32 = (int *)(*(longlong *)(lVar24 + 0x58) + 4);
          *piVar32 = *piVar32 + 1;
        }
        if ((*(uint *)((longlong)pplVar7 + 0xc) & 0xff000000) != 0) {
          *(int *)(*(longlong *)(&stack0x00000528 + lVar16) + 8) =
               *(int *)(*(longlong *)(&stack0x00000528 + lVar16) + 8) + 1;
          if (*(longlong *)(lVar24 + 0x58) != 0) {
            piVar32 = (int *)(*(longlong *)(lVar24 + 0x58) + 8);
            *piVar32 = *piVar32 + 1;
          }
          if (*(char *)(pplVar7 + 2) != '\0') {
            *(int *)(*(longlong *)(&stack0x00000528 + lVar16) + 0xc) =
                 *(int *)(*(longlong *)(&stack0x00000528 + lVar16) + 0xc) + 1;
            if (*(longlong *)(lVar24 + 0x58) != 0) {
              piVar32 = (int *)(*(longlong *)(lVar24 + 0x58) + 0xc);
              *piVar32 = *piVar32 + 1;
            }
          }
        }
        if (*(int *)(&stack0x00000924 + lVar16) != 0) {
          lVar24 = **pplVar7;
          *(longlong *)(&stack0x00000bf8 + lVar16) = lVar24;
          uVar3 = *(undefined *)(lVar24 + 1);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101bf1;
          func_0x
                    (*(undefined8 *)(&stack0x00000808 + lVar16),uVar3,&stack0x00000920 + lVar16,
                     0xffffffff);
        }
        (&stack0x0000010e)[lVar16] = 0;
        (&stack0x0000010f)[lVar16] = 1;
        *(undefined4 *)(&stack0x00000278 + lVar16) = 0;
        *(undefined2 *)(&stack0x0000027c + lVar16) = 0;
        *(undefined2 *)(&stack0x0000027e + lVar16) = 0;
        lVar24 = **(longlong **)(&stack0x00000620 + lVar16);
        *(longlong *)(&stack0x00000810 + lVar16) = lVar24;
        plVar30 = *pplVar7;
        lVar27 = *plVar30;
        *(longlong *)(&stack0x00000c00 + lVar16) = lVar27;
        lVar8 = *(longlong *)(lVar24 + 8);
        piVar32 = (int *)(lVar8 + 0x3c0);
        *(int **)(&stack0x00000c08 + lVar16) = piVar32;
        *(undefined4 *)(&stack0x000005a8 + lVar16) = 0;
        if (*(int *)(lVar27 + 0x18) == *piVar32) {
          uVar4 = *(ushort *)(lVar8 + 0x3c4);
          if ((*(ushort *)(lVar27 + 6) != uVar4) && (1 < (uVar4 | *(ushort *)(lVar27 + 6))))
          goto LAB_;
          *(undefined4 *)(&stack0x000005a8 + lVar16) = 1;
          param_1 = *(longlong *)(&stack0x00000568 + lVar16);
        }
        else {
LAB_:
          *(longlong *)(&stack0x00000c10 + lVar16) = lVar27;
          *(undefined4 *)(&stack0x00000388 + lVar16) = 0;
          *(undefined2 *)(&stack0x0000038c + lVar16) = 0;
          *(undefined2 *)(&stack0x0000038e + lVar16) = 0;
          uVar33 = *(undefined4 *)(lVar27 + 0x18);
          *(undefined4 *)(&stack0x00000388 + lVar16) = uVar33;
          uVar13 = *(undefined2 *)(lVar27 + 6);
          *(undefined2 *)(&stack0x0000038c + lVar16) = uVar13;
          *(undefined4 *)(&stack0x00000278 + lVar16) = uVar33;
          *(undefined2 *)(&stack0x0000027c + lVar16) = uVar13;
          *(undefined2 *)(&stack0x0000027e + lVar16) = 0;
          puVar25 = (undefined2 *)((longlong)plVar30 + 0x62);
          *(undefined2 **)(&stack0x00000c18 + lVar16) = puVar25;
          *(undefined2 *)(&stack0x00000170 + lVar16) = *puVar25;
          if (((*(ushort *)(&stack0x00000170 + lVar16) & 0x400) == 0) ||
             (*(short *)((longlong)pplVar7 + 0xc) < 3)) {
            *(int *)(&stack0x000000d8 + lVar16) = (int)*(short *)((longlong)pplVar7 + 0xc);
            plVar30 = *pplVar7;
            *(longlong **)(&stack0x00000228 + lVar16) = plVar30;
            puVar25 = (undefined2 *)((longlong)plVar30 + 0x62);
            *(undefined2 **)(&stack0x00000c20 + lVar16) = puVar25;
            uVar5 = *puVar25;
            *(undefined2 *)(&stack0x00000178 + lVar16) = uVar5;
            if (((byte)uVar5 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000d8 + lVar16) == 3) {
                *(undefined4 *)(&stack0x000000d8 + lVar16) = 4;
              }
              else if (*(int *)(&stack0x000000d8 + lVar16) < 2) goto LAB_;
              *(uint **)(&stack0x00000c28 + lVar16) =
                   (uint *)(*(longlong *)(&stack0x00000228 + lVar16) + 100);
              uVar36 = *(uint *)(*(longlong *)(&stack0x00000228 + lVar16) + 100);
              *(uint *)(&stack0x000005b0 + lVar16) = uVar36;
              if ((((uVar36 & 8) != 0) &&
                  (lVar27 = *(longlong *)(*(longlong *)(&stack0x00000228 + lVar16) + 0x90),
                  lVar27 != 0)) &&
                 (*(longlong *)(&stack0x00000c30 + lVar16) = lVar27,
                 *(longlong *)(lVar27 + 0x758) != 0)) {
                uVar20 = *(undefined8 *)(lVar27 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101ddc;
                func_0x
                          (uVar20,*(undefined8 *)(&stack0x00000228 + lVar16),
                           *(undefined4 *)(&stack0x000000d8 + lVar16));
              }
            }
LAB_:
            (&stack0x00000110)[lVar16] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar34 = (uint *)(*(longlong *)(&stack0x00000228 + lVar16) + 100);
              *(uint **)(&stack0x00000c38 + lVar16) = puVar34;
              uVar36 = *puVar34;
              *(uint *)(&stack0x000005c0 + lVar16) = uVar36;
              if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x000000d8 + lVar16))) {
                *(uint **)(&stack0x00000c40 + lVar16) = puVar34;
                uVar36 = *puVar34;
                *(uint *)(&stack0x000005c8 + lVar16) = uVar36;
                if (((uVar36 & 0xc0000000) != 0x40000000) &&
                   (lVar27 = **(longlong **)(&stack0x00000228 + lVar16), lVar27 != 0)) {
                  *(undefined4 *)(&stack0x00000900 + lVar16) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101e71;
                  iVar14 = (*_DAT_)(lVar27,0x2000,2,&stack0x00000904 + lVar16);
                  if (iVar14 != 0) {
                    LOCK();
                    *puVar34 = *puVar34 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar34 = *puVar34 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar27 = *(longlong *)(&stack0x00000228 + lVar16);
            uVar6 = *(undefined4 *)(&stack0x000000d8 + lVar16);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101ea0;
            func_0x(lVar27 + 0x98,uVar6);
            if ((_DAT_ != 0) &&
               ((&stack0x00000111)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101eca;
              func_0x(lVar27,0,uVar6);
            }
            *(uint *)((longlong)pplVar7 + 0xc) = *(uint *)((longlong)pplVar7 + 0xc) & 0xffff0000;
            *pplVar7 = (longlong *)0x0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101d15;
            func_0x(pplVar7);
          }
          *(undefined **)(&stack0x00000c48 + lVar16) = &stack0x00000390 + lVar16;
          *(undefined **)(&stack0x00000c50 + lVar16) = &stack0x00000368 + lVar16;
          lVar24 = *(longlong *)(lVar24 + 8);
          puVar28 = (undefined4 *)(lVar24 + 0x3c0);
          *(undefined4 **)(&stack0x00000c58 + lVar16) = puVar28;
          *(undefined4 *)(&stack0x00000390 + lVar16) = *puVar28;
          *(undefined2 *)(&stack0x00000394 + lVar16) = *(undefined2 *)(lVar24 + 0x3c4);
          *(undefined2 *)(&stack0x00000396 + lVar16) = 0;
          *(undefined4 *)(&stack0x00000368 + lVar16) = uVar33;
          *(undefined2 *)(&stack0x0000036c + lVar16) = uVar13;
          *(undefined2 *)(&stack0x0000036e + lVar16) = 0;
          UNRECOVERED_JUMPTABLE_00 = *(code **)**(undefined8 **)(&stack0x00000810 + lVar16);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101f4e;
          uVar13 = (*UNRECOVERED_JUMPTABLE_00)();
          *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) =
               *(undefined4 *)(*(longlong *)(&stack0x00000620 + lVar16) + 0x10);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101f7e;
          func_0x(&stack0x000000fe + lVar16,&stack0x00000368 + lVar16,uVar13,
                          &stack0x00000390 + lVar16);
          param_1 = *(longlong *)(&stack0x00000568 + lVar16);
        }
        goto LAB_;
      }
      plVar30 = *pplVar7;
      lVar24 = *plVar30;
      *(longlong *)(&stack0x00000bc0 + lVar16) = lVar24;
      if ((*(byte *)(lVar24 + 4) & 1) == 0) goto LAB_;
      puVar17 = (ushort *)((longlong)plVar30 + 0x62);
      *(ushort **)(&stack0x00000bc8 + lVar16) = puVar17;
      uVar4 = *puVar17;
      *(ushort *)(&stack0x00000160 + lVar16) = uVar4;
      if (((uVar4 & 0x400) == 0) || (*(short *)((longlong)pplVar7 + 0xc) < 3)) {
        *(int *)(&stack0x000000c8 + lVar16) = (int)*(short *)((longlong)pplVar7 + 0xc);
        plVar30 = *pplVar7;
        *(longlong **)(&stack0x00000220 + lVar16) = plVar30;
        puVar25 = (undefined2 *)((longlong)plVar30 + 0x62);
        *(undefined2 **)(&stack0x00000bd0 + lVar16) = puVar25;
        uVar13 = *puVar25;
        *(undefined2 *)(&stack0x00000168 + lVar16) = uVar13;
        if (((byte)uVar13 >> 3 & 1) != 0) {
          if (*(int *)(&stack0x000000c8 + lVar16) == 3) {
            *(undefined4 *)(&stack0x000000c8 + lVar16) = 4;
          }
          else if (*(int *)(&stack0x000000c8 + lVar16) < 2) goto LAB_;
          *(uint **)(&stack0x00000bd8 + lVar16) =
               (uint *)(*(longlong *)(&stack0x00000220 + lVar16) + 100);
          uVar36 = *(uint *)(*(longlong *)(&stack0x00000220 + lVar16) + 100);
          *(uint *)(&stack0x00000590 + lVar16) = uVar36;
          if ((((uVar36 & 8) != 0) &&
              (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000220 + lVar16) + 0x90), lVar24 != 0)
              ) && (*(longlong *)(&stack0x00000be0 + lVar16) = lVar24,
                   *(longlong *)(lVar24 + 0x758) != 0)) {
            uVar20 = *(undefined8 *)(lVar24 + 0x758);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101a1b;
            func_0x
                      (uVar20,*(undefined8 *)(&stack0x00000220 + lVar16),
                       *(undefined4 *)(&stack0x000000c8 + lVar16));
          }
        }
LAB_:
        (&stack0x0000010c)[lVar16] = DAT_ >> 7;
        if ((char)DAT_ < '\0') {
          puVar34 = (uint *)(*(longlong *)(&stack0x00000220 + lVar16) + 100);
          *(uint **)(&stack0x00000be8 + lVar16) = puVar34;
          uVar36 = *puVar34;
          *(uint *)(&stack0x00000598 + lVar16) = uVar36;
          if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x000000c8 + lVar16))) {
            *(uint **)(&stack0x00000bf0 + lVar16) = puVar34;
            uVar36 = *puVar34;
            *(uint *)(&stack0x000005a0 + lVar16) = uVar36;
            if (((uVar36 & 0xc0000000) != 0x40000000) &&
               (lVar24 = **(longlong **)(&stack0x00000220 + lVar16), lVar24 != 0)) {
              *(undefined4 *)(&stack0x000008f8 + lVar16) = 2;
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101aae;
              iVar14 = (*_DAT_)(lVar24,0x2000,2,&stack0x000008fc + lVar16);
              if (iVar14 != 0) {
                LOCK();
                *puVar34 = *puVar34 & 0x3fffffff;
                UNLOCK();
                LOCK();
                *puVar34 = *puVar34 | 0x40000000;
                UNLOCK();
              }
            }
          }
        }
        lVar24 = *(longlong *)(&stack0x00000220 + lVar16);
        uVar33 = *(undefined4 *)(&stack0x000000c8 + lVar16);
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101add;
        func_0x(lVar24 + 0x98,uVar33);
        if ((_DAT_ != 0) &&
           ((&stack0x0000010d)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101b08;
          func_0x(lVar24,0,uVar33);
        }
        *(uint *)((longlong)pplVar7 + 0xc) = *(uint *)((longlong)pplVar7 + 0xc) & 0xffff0000;
        *pplVar7 = (longlong *)0x0;
      }
      else {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101953;
        func_0x(pplVar7);
      }
      *(undefined4 *)(&stack0x000009e0 + lVar16) = 0x400060;
      *(undefined8 *)(&stack0x000009e8 + lVar16) = 0;
      *(undefined8 *)(&stack0x000009f8 + lVar16) = 0;
      *(undefined8 *)(&stack0x000009f0 + lVar16) = 0;
      *(undefined8 *)(&stack0x00000a00 + lVar16) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101b54;
      func_0x(10,&stack0x000009e0 + lVar16);
      lVar27 = *(longlong *)(&stack0x00000060 + lVar16);
    } while( true );
  }
  (&stack0x00000052)[lVar16] = 0;
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101fa2;
  func_0x(&stack0x00000968 + lVar16,pplVar7);
  lVar24 = **pplVar7;
  *(longlong *)(&stack0x00000c60 + lVar16) = lVar24;
  if (*(short *)(lVar24 + 0x16) == 0) {
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar16) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x101fdc;
    (*_DAT_)(1,0x1b38d30,0x1b0f6e8,0x12f6);
    lVar24 = **pplVar7;
  }
  *(longlong *)(&stack0x00000c68 + lVar16) = lVar24;
  if (*(short *)(lVar24 + 0x16) == 1) {
    *(undefined4 *)(&stack0x00000668 + lVar16) = 0;
    *(undefined2 *)(&stack0x0000066c + lVar16) = 0;
    *(longlong *)(&stack0x00000c70 + lVar16) = lVar24;
    piVar32 = (int *)(lVar24 + 0x10);
    *(int **)(&stack0x00000c78 + lVar16) = piVar32;
    iVar14 = *piVar32;
    *(int *)(&stack0x00000650 + lVar16) = iVar14;
    sVar12 = *(short *)(lVar24 + 0x14);
    *(short *)(&stack0x00000654 + lVar16) = sVar12;
    if ((iVar14 != 0) || (sVar12 != 0)) {
      *(longlong *)(&stack0x00000c80 + lVar16) = lVar24;
      *(int **)(&stack0x00000c88 + lVar16) = piVar32;
      *(int *)(&stack0x000000f8 + lVar16) = iVar14;
      *(short *)(&stack0x000000fc + lVar16) = sVar12;
      plVar30 = *(longlong **)(param_1 + 8);
      *(longlong **)(&stack0x00000638 + lVar16) = plVar30;
      *(undefined8 *)(&stack0x00000550 + lVar16) = *(undefined8 *)(param_1 + 0x10);
      *(undefined4 *)(&stack0x000003a8 + lVar16) = 0;
      *(undefined4 *)(&stack0x000003ac + lVar16) = 0;
      *(undefined2 *)(&stack0x000003b0 + lVar16) = 0;
      lVar24 = *plVar30;
      *(longlong *)(&stack0x00000858 + lVar16) = lVar24;
      *(undefined4 *)(&stack0x0000093c + lVar16) = 0;
      *(undefined4 *)(&stack0x00000940 + lVar16) = 0;
      lVar27 = *(longlong *)(lVar24 + 0x20);
      *(longlong *)(&stack0x00000058 + lVar16) = lVar27;
      *(uint6 **)(&stack0x00000c90 + lVar16) = (uint6 *)(lVar24 + 0x14);
      lVar24 = (ulonglong)*(uint6 *)(lVar24 + 0x14) * 0x10000;
      *(longlong *)(&stack0x00000c98 + lVar16) = lVar24;
      if ((*(longlong *)(lVar27 + 2000) == lVar24) &&
         (*(longlong *)(lVar27 + 2000) - 1U < 0xfffffffffffffffe)) {
        (&stack0x0000006f)[lVar16] = 1;
        goto LAB_;
      }
      (&stack0x0000006f)[lVar16] = 0;
      if ((*(longlong *)(lVar27 + 0x7d8) == lVar24) &&
         (*(longlong *)(lVar27 + 0x7d8) - 1U < 0xfffffffffffffffe)) {
        (&stack0x00000070)[lVar16] = 1;
        goto LAB_;
      }
      (&stack0x00000070)[lVar16] = 0;
      lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
      *(longlong *)(&stack0x00000ca0 + lVar16) = lVar24;
      lVar27 = (ulonglong)*_DAT_ + *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8);
      *(longlong *)(&stack0x00000ca8 + lVar16) = lVar27;
      lVar24 = *(longlong *)(lVar27 + 0x100);
      *(longlong *)(&stack0x00000818 + lVar16) = lVar24;
      puVar34 = _DAT_;
      if (lVar24 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10217b;
        puVar34 = (uint *)(*_DAT_)(0);
        lVar24 = *(longlong *)(lVar27 + 0x100);
        *(longlong *)(&stack0x00000818 + lVar16) = lVar24;
      }
      *(longlong *)(&stack0x00000cb0 + lVar16) = lVar24;
      uVar21 = rdtsc();
      uVar18 = CONCAT44((int)((ulonglong)puVar34 >> 0x20),(int)uVar21) | uVar21 & 0xffffffff00000000
      ;
      *(ulonglong *)(&stack0x00000cb8 + lVar16) = uVar18;
      uVar21 = *(ulonglong *)(lVar24 + 0x340);
      if ((uVar21 < uVar18) ||
         ((uVar21 != 0x7fffffffffffffff &&
          (*(ulonglong *)(*(longlong *)(lVar24 + 0x260) + 0xdf0) < uVar21 - uVar18)))) {
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10223e;
        iVar14 = func_0x(0,0x20c6f18);
        *(int *)(&stack0x000002c0 + lVar16) = iVar14;
        if (iVar14 == 2) {
LAB_:
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102251;
          func_0x(0x7c);
        }
      }
      else {
        lVar24 = *(longlong *)(lVar24 + 600);
        *(longlong *)(&stack0x00000820 + lVar16) = lVar24;
        puVar34 = (uint *)(lVar24 + 0xbc);
        *(uint **)(&stack0x00000cc0 + lVar16) = puVar34;
        if ((*puVar34 & 4) != 0) {
          lVar24 = *(longlong *)(*(longlong *)(&stack0x00000820 + lVar16) + 0x98);
          *(longlong *)(&stack0x00000cc8 + lVar16) = lVar24;
          if (((*(byte *)(lVar24 + 0x268) & 1) == 0) && ((*(uint *)(lVar24 + 800) & 0x180) == 0)) {
            *(undefined4 *)(&stack0x000002c0 + lVar16) = 2;
            goto LAB_;
          }
        }
        *(undefined4 *)(&stack0x000002c0 + lVar16) = 0;
      }
      lVar27 = *(longlong *)(&stack0x00000058 + lVar16);
LAB_:
      *(undefined4 *)(&stack0x000006b0 + lVar16) = 0;
      *(undefined4 *)(&stack0x000006b4 + lVar16) = 0;
      *(undefined2 *)(&stack0x000006b8 + lVar16) = 0;
      (&stack0x00000073)[lVar16] = 0;
      (&stack0x00000051)[lVar16] = 0xff;
      do {
        *(undefined **)(&stack0x00000628 + lVar16) = &stack0x00000938 + lVar16;
        *(undefined4 *)(&stack0x00001884 + lVar16) = 0;
        *(undefined4 *)(&stack0x00001888 + lVar16) = 0;
        cVar10 = *_DAT_;
        (&stack0x00000112)[lVar16] = cVar10;
        if ((cVar10 == '\0') ||
           ((&stack0x00000113)[lVar16] = DAT_ >> 7, (char)DAT_ < '\0')) {
LAB_:
          uVar20 = 0;
        }
        else {
          *(undefined4 *)(&stack0x000005d0 + lVar16) = 0;
          lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          *(longlong *)(&stack0x00000cd0 + lVar16) = lVar24;
          plVar30 = (longlong *)
                    ((ulonglong)*_DAT_ +
                    *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8));
          *(longlong **)(&stack0x00000cd8 + lVar16) = plVar30;
          lVar24 = *plVar30;
          *(longlong *)(&stack0x00000ce0 + lVar16) = lVar24;
          if (lVar24 == 0) {
LAB_:
            *(undefined8 *)(&stack0x00000828 + lVar16) = 0;
          }
          else {
            lVar24 = **(longlong **)(lVar24 + 0x38);
            *(longlong *)(&stack0x00000ce8 + lVar16) = lVar24;
            if (lVar24 == 0) goto LAB_;
            *(longlong *)(&stack0x00000828 + lVar16) = lVar24;
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102358;
            iVar14 = (*_DAT_)(lVar24,0x337);
            *(int *)(&stack0x000005d0 + lVar16) = iVar14;
            if (iVar14 != 0) {
              lVar27 = *(longlong *)(&stack0x00000058 + lVar16);
              goto LAB_;
            }
          }
          lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          *(longlong *)(&stack0x00000cf0 + lVar16) = lVar24;
          lVar24 = (ulonglong)*_DAT_ + *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8)
          ;
          *(longlong *)(&stack0x00000cf8 + lVar16) = lVar24;
          lVar24 = *(longlong *)(lVar24 + 8);
          *(longlong *)(&stack0x00000d00 + lVar16) = lVar24;
          lVar27 = *(longlong *)(&stack0x00000058 + lVar16);
          if (lVar24 == 0) goto LAB_;
          uVar20 = *(undefined8 *)(lVar24 + 0x60);
        }
        *(undefined8 *)(&stack0x00000288 + lVar16) = uVar20;
        plVar30 = (longlong *)(lVar27 + 0x728);
        *(longlong *)(&stack0x00000830 + lVar16) = *plVar30;
LAB_:
        *(undefined4 *)(&stack0x00000274 + lVar16) = 0;
        if (*(longlong *)(&stack0x00000038 + lVar16) != 0) {
          puVar25 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar16) + 0x62);
          *(undefined2 **)(&stack0x00000d08 + lVar16) = puVar25;
          *(undefined2 *)(&stack0x00000180 + lVar16) = *puVar25;
          if (((*(ushort *)(&stack0x00000180 + lVar16) & 0x400) == 0) ||
             (*(short *)(&stack0x00000044 + lVar16) < 3)) {
            *(int *)(&stack0x000000e0 + lVar16) = (int)*(short *)(&stack0x00000044 + lVar16);
            *(undefined8 *)(&stack0x00000530 + lVar16) = *(undefined8 *)(&stack0x00000038 + lVar16);
            *(undefined2 **)(&stack0x00000d10 + lVar16) = puVar25;
            uVar13 = *puVar25;
            *(undefined2 *)(&stack0x00000188 + lVar16) = uVar13;
            if (((byte)uVar13 >> 3 & 1) != 0) {
              if (*(int *)(&stack0x000000e0 + lVar16) == 3) {
                *(undefined4 *)(&stack0x000000e0 + lVar16) = 4;
              }
              else if (*(int *)(&stack0x000000e0 + lVar16) < 2) goto LAB_;
              *(uint **)(&stack0x00000d18 + lVar16) =
                   (uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
              uVar36 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
              *(uint *)(&stack0x000005d8 + lVar16) = uVar36;
              if ((((uVar36 & 8) != 0) &&
                  (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar16) + 0x90),
                  lVar24 != 0)) &&
                 (*(longlong *)(&stack0x00000d20 + lVar16) = lVar24,
                 *(longlong *)(lVar24 + 0x758) != 0)) {
                uVar20 = *(undefined8 *)(lVar24 + 0x758);
                *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1024fc;
                func_0x
                          (uVar20,*(undefined8 *)(&stack0x00000038 + lVar16),
                           *(undefined4 *)(&stack0x000000e0 + lVar16));
              }
            }
LAB_:
            (&stack0x00000114)[lVar16] = DAT_ >> 7;
            if ((char)DAT_ < '\0') {
              puVar34 = (uint *)(*(longlong *)(&stack0x00000530 + lVar16) + 100);
              *(uint **)(&stack0x00000d28 + lVar16) = puVar34;
              uVar36 = *puVar34;
              *(uint *)(&stack0x000005e0 + lVar16) = uVar36;
              if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x000000e0 + lVar16))) {
                *(uint **)(&stack0x00000d30 + lVar16) = puVar34;
                uVar36 = *puVar34;
                *(uint *)(&stack0x000005e8 + lVar16) = uVar36;
                if (((uVar36 & 0xc0000000) != 0x40000000) &&
                   (lVar24 = **(longlong **)(&stack0x00000530 + lVar16), lVar24 != 0)) {
                  *(undefined4 *)(&stack0x00000908 + lVar16) = 2;
                  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10258f;
                  iVar14 = (*_DAT_)(lVar24,0x2000,2,&stack0x0000090c + lVar16);
                  if (iVar14 != 0) {
                    LOCK();
                    *puVar34 = *puVar34 & 0x3fffffff;
                    UNLOCK();
                    LOCK();
                    *puVar34 = *puVar34 | 0x40000000;
                    UNLOCK();
                  }
                }
              }
            }
            lVar24 = *(longlong *)(&stack0x00000530 + lVar16);
            uVar33 = *(undefined4 *)(&stack0x000000e0 + lVar16);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1025be;
            func_0x(lVar24 + 0x98,uVar33);
            if ((_DAT_ != 0) &&
               ((&stack0x00000115)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1025e8;
              func_0x(lVar24,0,uVar33);
            }
            *(uint *)(&stack0x00000044 + lVar16) = *(uint *)(&stack0x00000044 + lVar16) & 0xffff0000
            ;
            *(undefined8 *)(&stack0x00000038 + lVar16) = 0;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1023ed;
            func_0x(&stack0x00000038 + lVar16);
          }
          lVar27 = *(longlong *)(&stack0x00000058 + lVar16);
        }
        if (*plVar30 != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10261e;
          func_0x(&stack0x00000038 + lVar16,&stack0x000000f8 + lVar16,lVar27);
          if (*(longlong *)(&stack0x00000038 + lVar16) != 0) {
            puVar25 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar16) + 0x62);
            *(undefined2 **)(&stack0x00000d38 + lVar16) = puVar25;
            *(undefined2 *)(&stack0x00000190 + lVar16) = *puVar25;
            if (((*(ushort *)(&stack0x00000190 + lVar16) & 0x400) == 0) ||
               (*(short *)(&stack0x00000044 + lVar16) < 3)) {
              *(int *)(&stack0x000000e8 + lVar16) = (int)*(short *)(&stack0x00000044 + lVar16);
              *(undefined8 *)(&stack0x00000538 + lVar16) =
                   *(undefined8 *)(&stack0x00000038 + lVar16);
              *(undefined2 **)(&stack0x00000d40 + lVar16) = puVar25;
              uVar13 = *puVar25;
              *(undefined2 *)(&stack0x00000198 + lVar16) = uVar13;
              if (((byte)uVar13 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000e8 + lVar16) == 3) {
                  *(undefined4 *)(&stack0x000000e8 + lVar16) = 4;
                }
                else if (*(int *)(&stack0x000000e8 + lVar16) < 2) goto LAB_;
                *(uint **)(&stack0x00000d48 + lVar16) =
                     (uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
                uVar36 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
                *(uint *)(&stack0x000005f0 + lVar16) = uVar36;
                if ((((uVar36 & 8) != 0) &&
                    (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar16) + 0x90),
                    lVar24 != 0)) &&
                   (*(longlong *)(&stack0x00000d50 + lVar16) = lVar24,
                   *(longlong *)(lVar24 + 0x758) != 0)) {
                  uVar20 = *(undefined8 *)(lVar24 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102715;
                  func_0x
                            (uVar20,*(undefined8 *)(&stack0x00000038 + lVar16),
                             *(undefined4 *)(&stack0x000000e8 + lVar16));
                }
              }
LAB_:
              (&stack0x00000116)[lVar16] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar34 = (uint *)(*(longlong *)(&stack0x00000538 + lVar16) + 100);
                *(uint **)(&stack0x00000d58 + lVar16) = puVar34;
                uVar36 = *puVar34;
                *(uint *)(&stack0x000003d0 + lVar16) = uVar36;
                if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x000000e8 + lVar16))) {
                  *(uint **)(&stack0x00000d60 + lVar16) = puVar34;
                  uVar36 = *puVar34;
                  *(uint *)(&stack0x000003d8 + lVar16) = uVar36;
                  if (((uVar36 & 0xc0000000) != 0x40000000) &&
                     (lVar24 = **(longlong **)(&stack0x00000538 + lVar16), lVar24 != 0)) {
                    *(undefined4 *)(&stack0x00000910 + lVar16) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1027a8;
                    iVar14 = (*_DAT_)(lVar24,0x2000,2,&stack0x00000914 + lVar16);
                    if (iVar14 != 0) {
                      LOCK();
                      *puVar34 = *puVar34 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar34 = *puVar34 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar24 = *(longlong *)(&stack0x00000538 + lVar16);
              uVar33 = *(undefined4 *)(&stack0x000000e8 + lVar16);
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1027d7;
              func_0x(lVar24 + 0x98,uVar33);
              if ((_DAT_ != 0) &&
                 ((&stack0x00000117)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102801;
                func_0x(lVar24,0,uVar33);
              }
              *(uint *)(&stack0x00000044 + lVar16) =
                   *(uint *)(&stack0x00000044 + lVar16) & 0xffff0000;
              *(undefined8 *)(&stack0x00000038 + lVar16) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102663;
              func_0x(&stack0x00000038 + lVar16);
            }
            lVar27 = *(longlong *)(&stack0x00000058 + lVar16);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102828;
        func_0x(lVar27,&stack0x000000f8 + lVar16);
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar16) =
             *(undefined8 *)(&stack0x00000628 + lVar16);
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) = 4;
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10285c;
        plVar19 = (longlong *)
                  func_0x
                            (_DAT_,lVar27,&stack0x000000f8 + lVar16,
                             &stack0x00000274 + lVar16);
        *(longlong **)(&stack0x00000038 + lVar16) = plVar19;
        uVar36 = *(uint *)(&stack0x00000044 + lVar16) & 0xffff0004 | 4;
        *(uint *)(&stack0x00000044 + lVar16) = uVar36;
        if (*(longlong *)(&stack0x00000288 + lVar16) != 0) {
          lVar24 = *plVar19;
          *(longlong *)(&stack0x00000d68 + lVar16) = lVar24;
          plVar26 = (longlong *)(*(longlong *)(&stack0x00000288 + lVar16) + 0x500);
          *(longlong **)(&stack0x00000d70 + lVar16) = plVar26;
          plVar19 = plVar26 + (ulonglong)(*(uint *)plVar26 & 0xf) + 1;
          *(longlong **)(&stack0x00000d78 + lVar16) = plVar19;
          if (*plVar19 != lVar24) {
            *plVar19 = lVar24;
            *plVar26 = *plVar26 + 1;
            uVar36 = *(uint *)(&stack0x00000044 + lVar16);
          }
        }
        uVar29 = *(uint *)(&stack0x00000274 + lVar16) >> 3 & 1;
        *(uint *)(&stack0x00000044 + lVar16) = uVar29 << 0x18 | uVar36 & 0xffffff;
        *(uint *)(&stack0x00000048 + lVar16) =
             *(uint *)(&stack0x00000274 + lVar16) >> 4 & 1 |
             *(uint *)(&stack0x00000048 + lVar16) & 0xffffff00;
        lVar24 = *(longlong *)(&stack0x00000830 + lVar16);
        if (((lVar24 != 0) && (*(longlong *)(&stack0x00000288 + lVar16) != 0)) &&
           (*(longlong *)(&stack0x00000288 + lVar16) == *(longlong *)(lVar27 + 0x1c38))) {
          *(uint *)(&stack0x00000918 + lVar16) = uVar29;
          *(longlong *)(&stack0x00000d80 + lVar16) = lVar24 + 0x59b8;
          *(longlong *)(lVar24 + 0x5b28) = *(longlong *)(lVar24 + 0x5b28) + 1;
          puVar34 = *(uint **)(&stack0x00000628 + lVar16);
          if (puVar34[1] != 0) {
            *(longlong *)(lVar24 + 0x5b30) = *(longlong *)(lVar24 + 0x5b30) + 1;
            *(longlong *)(lVar24 + 0x5b38) = *(longlong *)(lVar24 + 0x5b38) + (ulonglong)*puVar34;
            if (uVar29 != 0) {
              *(longlong *)(lVar24 + 0x5b40) = *(longlong *)(lVar24 + 0x5b40) + 1;
              *(longlong *)(lVar24 + 0x5b48) = *(longlong *)(lVar24 + 0x5b48) + (ulonglong)*puVar34;
            }
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10297e;
        cVar10 = func_0x(lVar27);
        if ((cVar10 == '\0') || (*(char *)(lVar27 + 0x2050) == '\0')) goto LAB_;
        if (*(int *)(&stack0x000000f8 + lVar16) == 0) {
LAB_:
          (&stack0x00000075)[lVar16] = 1;
          goto LAB_;
        }
        *(undefined4 *)(&stack0x00000656 + lVar16) = 9;
        *(undefined2 *)(&stack0x0000065a + lVar16) = 1;
        if ((*(int *)(&stack0x000000f8 + lVar16) == 9) &&
           (*(short *)(&stack0x000000fc + lVar16) == 1)) goto LAB_;
        (&stack0x00000075)[lVar16] = 0;
        lVar24 = **(longlong **)(&stack0x00000038 + lVar16);
        *(longlong *)(&stack0x00000d88 + lVar16) = lVar24;
        (&stack0x00000071)[lVar16] = 0;
        if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x00000300 + lVar16) = *(undefined8 *)(lVar24 + 0x28);
          *(undefined2 *)(&stack0x00000308 + lVar16) = *(undefined2 *)(lVar24 + 0x30);
        }
        else {
          cVar10 = *(char *)(lVar24 + 1);
          if ((((cVar10 == '\v') || (cVar10 == '\b')) || (cVar10 == '\t')) &&
             (*(int *)(lVar24 + 0x18) == 99)) {
            *(undefined **)(&stack0x00000d90 + lVar16) = &stack0x00000358 + lVar16;
            *(undefined4 **)(&stack0x00000d98 + lVar16) = (undefined4 *)(lVar24 + 0x20);
            *(undefined4 *)(&stack0x00000358 + lVar16) = *(undefined4 *)(lVar24 + 0x20);
            *(undefined2 *)(&stack0x0000035c + lVar16) = *(undefined2 *)(lVar24 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102a46;
            cVar10 = func_0x(&stack0x00000358 + lVar16);
            if (cVar10 == '\0') goto LAB_;
            cVar10 = '\x01';
          }
          else {
LAB_:
            cVar10 = '\0';
          }
          (&stack0x00000071)[lVar16] = cVar10;
          if (cVar10 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102a6b;
          func_0x(lVar24,&stack0x00000300 + lVar16);
        }
        *(undefined **)(&stack0x00000da0 + lVar16) = &stack0x00000300 + lVar16;
        *(longlong *)(&stack0x00000838 + lVar16) = lVar27 + 0x20fc;
        *(undefined4 *)(&stack0x000002a8 + lVar16) = 0;
        *(undefined4 *)(&stack0x000002ac + lVar16) = 0;
        *(undefined2 *)(&stack0x000002b0 + lVar16) = 0;
        *(undefined2 *)(&stack0x000002b2 + lVar16) = 0;
        puVar34 = (uint *)(lVar27 + 0x2108);
        *(uint **)(&stack0x00000da8 + lVar16) = puVar34;
        uVar36 = *puVar34;
        *(uint *)(&stack0x00000270 + lVar16) = uVar36;
        *(uint **)(&stack0x00000840 + lVar16) = puVar34;
        do {
          *(uint *)(&stack0x000003e0 + lVar16) = uVar36 & 0xfffffffe;
          *(undefined8 *)(&stack0x000002a8 + lVar16) = **(undefined8 **)(&stack0x00000838 + lVar16);
          *(undefined4 *)(&stack0x000002b0 + lVar16) =
               *(undefined4 *)(*(undefined8 **)(&stack0x00000838 + lVar16) + 1);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16);
          UNLOCK();
          uVar36 = **(uint **)(&stack0x00000840 + lVar16);
          *(uint *)(&stack0x00000270 + lVar16) = uVar36;
        } while (*(uint *)(&stack0x000003e0 + lVar16) != uVar36);
        if ((*(uint *)(&stack0x00000300 + lVar16) <= *(uint *)(&stack0x000002a8 + lVar16)) &&
           ((*(uint *)(&stack0x000002a8 + lVar16) != *(uint *)(&stack0x00000300 + lVar16) ||
            ((uVar36 = (uint)((ulonglong)*(undefined8 *)(&stack0x000002a8 + lVar16) >> 0x20),
             *(uint *)(&stack0x00000304 + lVar16) <= uVar36 &&
             ((uVar36 != *(uint *)(&stack0x00000304 + lVar16) ||
              (*(ushort *)(&stack0x00000308 + lVar16) <= *(ushort *)(&stack0x000002b0 + lVar16))))))
            ))) goto LAB_;
        if (*(char *)(*(longlong *)(&stack0x00000058 + lVar16) + 0x6ac8) != '\0') {
LAB_:
          if ((&stack0x00000073)[lVar16] != '\0') goto LAB_;
          lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
          *(longlong *)(&stack0x00000e78 + lVar16) = lVar24;
          lVar24 = (ulonglong)*_DAT_ + *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8)
          ;
          *(longlong *)(&stack0x00000e80 + lVar16) = lVar24;
          lVar24 = *(longlong *)(lVar24 + 8);
          *(longlong *)(&stack0x00000e88 + lVar16) = lVar24;
          lVar24 = *(longlong *)(lVar24 + 0x60);
          *(longlong *)(&stack0x00000e90 + lVar16) = lVar24;
          lVar27 = *(longlong *)(&stack0x00000058 + lVar16);
          if (lVar24 == *(longlong *)(lVar27 + 0x2120)) goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10327d;
          cVar10 = func_0x(lVar27);
          if (cVar10 != '\0') goto LAB_;
          if (*(longlong *)(&stack0x00000288 + lVar16) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103295;
            uVar20 = func_0x();
            *(undefined8 *)(&stack0x00000288 + lVar16) = uVar20;
          }
          *(undefined **)(&stack0x00000e98 + lVar16) = &stack0x00000320 + lVar16;
          lVar24 = **(longlong **)(&stack0x00000038 + lVar16);
          *(longlong *)(&stack0x00000ea0 + lVar16) = lVar24;
          (&stack0x00000074)[lVar16] = 0;
          if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
            uVar20 = *(undefined8 *)(lVar24 + 0x28);
            *(undefined8 *)(&stack0x00000320 + lVar16) = uVar20;
            uVar13 = *(undefined2 *)(lVar24 + 0x30);
            *(undefined2 *)(&stack0x00000328 + lVar16) = uVar13;
          }
          else {
            cVar10 = *(char *)(lVar24 + 1);
            if ((((cVar10 == '\v') || (cVar10 == '\b')) || (cVar10 == '\t')) &&
               (*(int *)(lVar24 + 0x18) == 99)) {
              *(undefined **)(&stack0x00000ea8 + lVar16) = &stack0x00000348 + lVar16;
              *(undefined4 **)(&stack0x00000eb0 + lVar16) = (undefined4 *)(lVar24 + 0x20);
              *(undefined4 *)(&stack0x00000348 + lVar16) = *(undefined4 *)(lVar24 + 0x20);
              *(undefined2 *)(&stack0x0000034c + lVar16) = *(undefined2 *)(lVar24 + 0x24);
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103328;
              cVar10 = func_0x(&stack0x00000348 + lVar16);
              if (cVar10 == '\0') goto LAB_;
              cVar10 = '\x01';
            }
            else {
LAB_:
              cVar10 = '\0';
            }
            (&stack0x00000074)[lVar16] = cVar10;
            if (cVar10 == '\0') goto LAB_;
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10334d;
            func_0x(lVar24,&stack0x00000320 + lVar16);
            uVar13 = *(undefined2 *)(&stack0x00000328 + lVar16);
            uVar20 = *(undefined8 *)(&stack0x00000320 + lVar16);
          }
          *(undefined **)(&stack0x00000eb8 + lVar16) = &stack0x00000320 + lVar16;
          *(undefined8 *)(&stack0x000003c4 + lVar16) = uVar20;
          *(undefined2 *)(&stack0x000003cc + lVar16) = uVar13;
          *(undefined2 *)(&stack0x000003ce + lVar16) = 0;
          if (*(longlong *)(&stack0x00000038 + lVar16) != 0) {
            puVar25 = (undefined2 *)(*(longlong *)(&stack0x00000038 + lVar16) + 0x62);
            *(undefined2 **)(&stack0x00000ec0 + lVar16) = puVar25;
            *(undefined2 *)(&stack0x000001a0 + lVar16) = *puVar25;
            if (((*(ushort *)(&stack0x000001a0 + lVar16) & 0x400) == 0) ||
               (*(short *)(&stack0x00000044 + lVar16) < 3)) {
              *(int *)(&stack0x000000f0 + lVar16) = (int)*(short *)(&stack0x00000044 + lVar16);
              *(undefined8 *)(&stack0x00000540 + lVar16) =
                   *(undefined8 *)(&stack0x00000038 + lVar16);
              *(undefined2 **)(&stack0x00000ec8 + lVar16) = puVar25;
              uVar13 = *puVar25;
              *(undefined2 *)(&stack0x000001a8 + lVar16) = uVar13;
              if (((byte)uVar13 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000f0 + lVar16) == 3) {
                  *(undefined4 *)(&stack0x000000f0 + lVar16) = 4;
                }
                else if (*(int *)(&stack0x000000f0 + lVar16) < 2) goto LAB_;
                *(uint **)(&stack0x00000ed0 + lVar16) =
                     (uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
                uVar36 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
                *(uint *)(&stack0x000003f0 + lVar16) = uVar36;
                if ((((uVar36 & 8) != 0) &&
                    (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar16) + 0x90),
                    lVar24 != 0)) &&
                   (*(longlong *)(&stack0x00000ed8 + lVar16) = lVar24,
                   *(longlong *)(lVar24 + 0x758) != 0)) {
                  uVar20 = *(undefined8 *)(lVar24 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1034a1;
                  func_0x
                            (uVar20,*(undefined8 *)(&stack0x00000038 + lVar16),
                             *(undefined4 *)(&stack0x000000f0 + lVar16));
                }
              }
LAB_:
              (&stack0x00000118)[lVar16] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar34 = (uint *)(*(longlong *)(&stack0x00000540 + lVar16) + 100);
                *(uint **)(&stack0x00000ee0 + lVar16) = puVar34;
                uVar36 = *puVar34;
                *(uint *)(&stack0x000003f8 + lVar16) = uVar36;
                if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x000000f0 + lVar16))) {
                  *(uint **)(&stack0x00000ee8 + lVar16) = puVar34;
                  uVar36 = *puVar34;
                  *(uint *)(&stack0x00000400 + lVar16) = uVar36;
                  if (((uVar36 & 0xc0000000) != 0x40000000) &&
                     (lVar24 = **(longlong **)(&stack0x00000540 + lVar16), lVar24 != 0)) {
                    *(undefined4 *)(&stack0x000006fc + lVar16) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103534;
                    iVar14 = (*_DAT_)(lVar24,0x2000,2,&stack0x00000700 + lVar16);
                    if (iVar14 != 0) {
                      LOCK();
                      *puVar34 = *puVar34 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar34 = *puVar34 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar24 = *(longlong *)(&stack0x00000540 + lVar16);
              uVar33 = *(undefined4 *)(&stack0x000000f0 + lVar16);
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103563;
              func_0x(lVar24 + 0x98,uVar33);
              if ((_DAT_ != 0) &&
                 ((&stack0x00000119)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10358d;
                func_0x(lVar24,0,uVar33);
              }
              *(uint *)(&stack0x00000044 + lVar16) =
                   *(uint *)(&stack0x00000044 + lVar16) & 0xffff0000;
              *(undefined8 *)(&stack0x00000038 + lVar16) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1033ef;
              func_0x(&stack0x00000038 + lVar16);
            }
            uVar20 = *(undefined8 *)(&stack0x000003c4 + lVar16);
            uVar13 = *(undefined2 *)(&stack0x000003cc + lVar16);
            lVar27 = *(longlong *)(&stack0x00000058 + lVar16);
          }
          *(undefined **)(&stack0x00000ef0 + lVar16) = &stack0x000006d0 + lVar16;
          *(undefined8 *)(&stack0x000006d0 + lVar16) = uVar20;
          *(undefined2 *)(&stack0x000006d8 + lVar16) = uVar13;
          *(undefined **)(&stack0x00000ef8 + lVar16) = &stack0x00000608 + lVar16;
          *(undefined8 *)(&stack0x00000608 + lVar16) = uVar20;
          *(undefined2 *)(&stack0x00000610 + lVar16) = uVar13;
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar16) = 0;
          lVar24 = *plVar30;
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10361a;
          func_0x(lVar24,&stack0x00000608 + lVar16,4);
          goto LAB_;
        }
        lVar24 = *(longlong *)(unaff_GS_OFFSET + 0x58);
        *(longlong *)(&stack0x00000db0 + lVar16) = lVar24;
        lVar24 = (ulonglong)*_DAT_ + *(longlong *)(lVar24 + (ulonglong)*_DAT_ * 8);
        *(longlong *)(&stack0x00000db8 + lVar16) = lVar24;
        lVar24 = *(longlong *)(lVar24 + 8);
        *(longlong *)(&stack0x00000dc0 + lVar16) = lVar24;
        lVar24 = *(longlong *)(lVar24 + 0x60);
        *(longlong *)(&stack0x00000dc8 + lVar16) = lVar24;
        if (lVar24 == *(longlong *)(*(longlong *)(&stack0x00000058 + lVar16) + 0x2120))
        goto LAB_;
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102bef;
        cVar10 = func_0x(*(longlong *)(&stack0x00000058 + lVar16));
        if (cVar10 != '\0') goto LAB_;
        *(longlong *)(&stack0x00000630 + lVar16) = lVar27 + 0x20fc;
        iVar14 = 0;
        *(undefined4 *)(&stack0x00000258 + lVar16) = 0;
        *(undefined4 *)(&stack0x0000025c + lVar16) = 0;
        *(undefined2 *)(&stack0x00000260 + lVar16) = 0;
        *(undefined2 *)(&stack0x00000262 + lVar16) = 0;
        *(uint **)(&stack0x00000dd0 + lVar16) = puVar34;
        uVar36 = *puVar34;
        *(uint *)(&stack0x00000280 + lVar16) = uVar36;
        puVar31 = *(undefined8 **)(&stack0x00000630 + lVar16);
        *(longlong *)(&stack0x00000848 + lVar16) = (longlong)puVar31 + 0xc;
        while( true ) {
          *(uint *)(&stack0x000003e4 + lVar16) = uVar36 & 0xfffffffe;
          *(undefined8 *)(&stack0x00000258 + lVar16) = *puVar31;
          *(undefined4 *)(&stack0x00000260 + lVar16) = *(undefined4 *)(puVar31 + 1);
          LOCK();
          *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16) =
               *(undefined4 *)(&stack0xffffffffffffffc8 + lVar16);
          UNLOCK();
          uVar36 = **(uint **)(&stack0x00000848 + lVar16);
          *(uint *)(&stack0x00000280 + lVar16) = uVar36;
          if (*(uint *)(&stack0x000003e4 + lVar16) == uVar36) break;
          puVar31 = *(undefined8 **)(&stack0x00000630 + lVar16);
        }
        *(undefined8 *)(&stack0x000006c0 + lVar16) = *(undefined8 *)(&stack0x00000258 + lVar16);
        uVar4 = *(ushort *)(&stack0x00000260 + lVar16);
        *(ushort *)(&stack0x000006c8 + lVar16) = uVar4;
        lVar24 = **(longlong **)(&stack0x00000038 + lVar16);
        *(longlong *)(&stack0x00000dd8 + lVar16) = lVar24;
        (&stack0x00000072)[lVar16] = 0;
        if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
          *(undefined8 *)(&stack0x00000310 + lVar16) = *(undefined8 *)(lVar24 + 0x28);
          uVar38 = *(ushort *)(lVar24 + 0x30);
          *(ushort *)(&stack0x00000318 + lVar16) = uVar38;
        }
        else {
          cVar10 = *(char *)(lVar24 + 1);
          if ((((cVar10 == '\v') || (cVar10 == '\b')) || (cVar10 == '\t')) &&
             (*(int *)(lVar24 + 0x18) == 99)) {
            *(undefined **)(&stack0x00000de0 + lVar16) = &stack0x00000340 + lVar16;
            *(undefined4 **)(&stack0x00000de8 + lVar16) = (undefined4 *)(lVar24 + 0x20);
            *(undefined4 *)(&stack0x00000340 + lVar16) = *(undefined4 *)(lVar24 + 0x20);
            *(undefined2 *)(&stack0x00000344 + lVar16) = *(undefined2 *)(lVar24 + 0x24);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102d35;
            cVar10 = func_0x(&stack0x00000340 + lVar16);
            if (cVar10 == '\0') goto LAB_;
            cVar10 = '\x01';
          }
          else {
LAB_:
            cVar10 = '\0';
          }
          (&stack0x00000072)[lVar16] = cVar10;
          if (cVar10 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102d5a;
          func_0x(lVar24,&stack0x00000310 + lVar16);
          uVar38 = *(ushort *)(&stack0x00000318 + lVar16);
        }
        if ((*(uint *)(&stack0x00000258 + lVar16) < *(uint *)(&stack0x00000310 + lVar16)) ||
           ((iVar15 = iVar14,
            *(uint *)(&stack0x00000258 + lVar16) == *(uint *)(&stack0x00000310 + lVar16) &&
            ((uVar36 = (uint)((ulonglong)*(undefined8 *)(&stack0x00000310 + lVar16) >> 0x20),
             *(uint *)(&stack0x0000025c + lVar16) < uVar36 ||
             ((*(uint *)(&stack0x0000025c + lVar16) == uVar36 && (uVar4 < uVar38)))))))) {
          iVar15 = 1;
        }
        if (iVar15 != 0) {
          lVar24 = *(longlong *)(&stack0x00000058 + lVar16);
          lVar27 = *(longlong *)(lVar24 + 0x6b0);
          *(longlong *)(&stack0x00000df0 + lVar16) = lVar27;
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102df4;
          func_0x(&stack0x00000310 + lVar16,&stack0x00001a10 + lVar16,
                          &stack0x000003e8 + lVar16);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x102e11;
          func_0x(&stack0x000006c0 + lVar16,&stack0x00001a40 + lVar16,
                          &stack0x000003e8 + lVar16);
          *(undefined4 *)(&stack0x00000850 + lVar16) = 0x1d;
          *(undefined4 *)(&stack0x00000854 + lVar16) = 0x10000;
          if ((_DAT_ & 0x10000) != 0) {
            *(undefined2 *)(&stack0x000004b0 + lVar16) = 6;
            *(undefined **)(&stack0x00000df8 + lVar16) = &stack0x000015d0 + lVar16;
            *(undefined2 *)(&stack0x000015d0 + lVar16) = 0;
            *(undefined2 *)(&stack0x000015d2 + lVar16) = 6;
            *(undefined4 *)(&stack0x000015d8 + lVar16) = 0;
            *(undefined **)(&stack0x000015e0 + lVar16) = &stack0x000015f8 + lVar16;
            *(undefined **)(&stack0x000015e8 + lVar16) = &stack0x00001658 + lVar16;
            *(undefined4 *)(&stack0x00001818 + lVar16) = 0;
            *(undefined4 *)(&stack0x0000181c + lVar16) = 0;
            *(undefined8 *)(&stack0x000015f0 + lVar16) = 0;
            *(undefined8 *)(&stack0x00001820 + lVar16) = 0;
            *(undefined **)(&stack0x00000e00 + lVar16) = &stack0x000015f8 + lVar16;
            *(undefined **)(&stack0x000015f8 + lVar16) = &stack0x00001828 + lVar16;
            *(undefined4 *)(&stack0x00001600 + lVar16) = 0x34;
            *(undefined2 *)(&stack0x00001604 + lVar16) = 5;
            *(undefined2 *)(&stack0x00001606 + lVar16) = 0;
            *(undefined **)(&stack0x00000e08 + lVar16) = &stack0x00001608 + lVar16;
            *(undefined8 *)(&stack0x00001608 + lVar16) = 0x18b7178;
            *(undefined4 *)(&stack0x00001610 + lVar16) = 0x10;
            *(undefined2 *)(&stack0x00001614 + lVar16) = 5;
            *(undefined2 *)(&stack0x00001616 + lVar16) = 0;
            *(undefined **)(&stack0x00000e10 + lVar16) = &stack0x00001618 + lVar16;
            *(undefined8 *)(&stack0x00001618 + lVar16) = 0x18b7178;
            *(undefined4 *)(&stack0x00001620 + lVar16) = 0x10;
            *(undefined2 *)(&stack0x00001624 + lVar16) = 6;
            *(undefined2 *)(&stack0x00001626 + lVar16) = 0;
            *(undefined **)(&stack0x00000e18 + lVar16) = &stack0x00001628 + lVar16;
            *(undefined8 *)(&stack0x00001628 + lVar16) = 0;
            *(undefined4 *)(&stack0x00001630 + lVar16) = 0;
            *(undefined2 *)(&stack0x00001634 + lVar16) = 7;
            *(undefined2 *)(&stack0x00001636 + lVar16) = 0;
            *(undefined **)(&stack0x00000e20 + lVar16) = &stack0x00001638 + lVar16;
            *(undefined8 *)(&stack0x00001638 + lVar16) = 0;
            *(undefined4 *)(&stack0x00001640 + lVar16) = 0;
            *(undefined2 *)(&stack0x00001644 + lVar16) = 8;
            *(undefined2 *)(&stack0x00001646 + lVar16) = 0;
            *(undefined **)(&stack0x00000e28 + lVar16) = &stack0x00001648 + lVar16;
            *(undefined8 *)(&stack0x00001648 + lVar16) = 0;
            *(undefined4 *)(&stack0x00001650 + lVar16) = 0;
            *(undefined2 *)(&stack0x00001654 + lVar16) = 9;
            *(undefined2 *)(&stack0x00001656 + lVar16) = 0;
            *(uint *)(&stack0x00001828 + lVar16) = (uint)*(ushort *)(lVar24 + 0x6b8);
            *(undefined2 *)(&stack0x0000182c + lVar16) = *(undefined2 *)(&stack0x000000fc + lVar16);
            *(undefined4 *)(&stack0x0000182e + lVar16) = *(undefined4 *)(&stack0x000000f8 + lVar16);
            (&stack0x00001832)[lVar16] = (&stack0x00000051)[lVar16];
            lVar24 = **(longlong **)(&stack0x00000038 + lVar16);
            *(longlong *)(&stack0x00000e30 + lVar16) = lVar24;
            (&stack0x00001833)[lVar16] = *(undefined *)(lVar24 + 1);
            *(undefined **)(&stack0x00000e38 + lVar16) = &stack0x00001608 + lVar16;
            *(longlong *)(&stack0x00001608 + lVar16) = lVar27 + 0x254;
            *(undefined4 *)(&stack0x00001610 + lVar16) = 0x10;
            *(undefined2 *)(&stack0x00001614 + lVar16) = 5;
            *(undefined2 *)(&stack0x00001616 + lVar16) = 0;
            *(undefined **)(&stack0x00000e40 + lVar16) = &stack0x00001618 + lVar16;
            *(longlong *)(&stack0x00001618 + lVar16) = lVar27 + 0x244;
            *(undefined4 *)(&stack0x00001620 + lVar16) = 0x10;
            *(undefined2 *)(&stack0x00001624 + lVar16) = 6;
            *(undefined2 *)(&stack0x00001626 + lVar16) = 0;
            *(undefined **)(&stack0x00000e48 + lVar16) = &stack0x00001a10 + lVar16;
            lVar24 = -1;
            do {
              lVar24 = lVar24 + 1;
            } while (*(short *)(&stack0x00001a10 + lVar24 * 2 + lVar16) != 0);
            iVar15 = (int)lVar24 * 2;
            *(int *)(&stack0x000006f0 + lVar16) = iVar15;
            *(undefined **)(&stack0x00000e50 + lVar16) = &stack0x00001628 + lVar16;
            *(undefined **)(&stack0x00001628 + lVar16) = &stack0x00001a10 + lVar16;
            *(int *)(&stack0x00001630 + lVar16) = iVar15;
            *(undefined2 *)(&stack0x00001634 + lVar16) = 7;
            *(undefined2 *)(&stack0x00001636 + lVar16) = 0;
            *(undefined **)(&stack0x00000e58 + lVar16) = &stack0x00001a40 + lVar16;
            lVar24 = -1;
            do {
              lVar24 = lVar24 + 1;
            } while (*(short *)(&stack0x00001a40 + lVar24 * 2 + lVar16) != 0);
            iVar15 = (int)lVar24 * 2;
            *(int *)(&stack0x000006f4 + lVar16) = iVar15;
            *(undefined **)(&stack0x00000e60 + lVar16) = &stack0x00001638 + lVar16;
            *(undefined **)(&stack0x00001638 + lVar16) = &stack0x00001a40 + lVar16;
            *(int *)(&stack0x00001640 + lVar16) = iVar15;
            *(undefined2 *)(&stack0x00001644 + lVar16) = 8;
            *(undefined2 *)(&stack0x00001646 + lVar16) = 0;
            *(undefined4 *)(&stack0x000003ec + lVar16) = 0;
            UNRECOVERED_JUMPTABLE_00 = *(code **)(_DAT_ + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1031ac;
            lVar24 = (*UNRECOVERED_JUMPTABLE_00)(lVar27,&stack0x000003ec + lVar16);
            *(longlong *)(&stack0x00000e68 + lVar16) = lVar24;
            if (lVar24 != 0) {
              lVar27 = -1;
              do {
                lVar27 = lVar27 + 1;
              } while (*(short *)(lVar24 + lVar27 * 2) != 0);
              iVar14 = (int)lVar27 * 2;
            }
            *(int *)(&stack0x000006f8 + lVar16) = iVar14;
            lVar27 = *(longlong *)(&stack0x000015e0 + lVar16);
            *(longlong **)(&stack0x00000e70 + lVar16) = (longlong *)(lVar27 + 0x50);
            *(longlong *)(lVar27 + 0x50) = lVar24;
            *(int *)(lVar27 + 0x58) = iVar14;
            *(undefined2 *)(lVar27 + 0x5c) = 9;
            *(undefined2 *)(lVar27 + 0x5e) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103206;
            func_0x(&stack0x000015c8 + lVar16);
          }
        }
LAB_:
        if ((1 < *(short *)(&stack0x00000044 + lVar16)) && ((&stack0x00000051)[lVar16] != -1)) {
          lVar24 = **(longlong **)(&stack0x00000038 + lVar16);
          *(longlong *)(&stack0x00000f00 + lVar16) = lVar24;
          if (*(char *)(lVar24 + 1) != (&stack0x00000051)[lVar16]) {
            if (*(longlong *)(&stack0x00000288 + lVar16) != 0) {
              *(longlong *)(&stack0x00000f08 + lVar16) = lVar24;
              *(longlong *)(*(longlong *)(&stack0x00000288 + lVar16) + 0x588) = lVar24;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103682;
            lVar24 = func_0x();
            if (lVar24 == 0) {
LAB_:
              *(undefined4 *)(&stack0x00000408 + lVar16) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10368c;
              lVar24 = func_0x();
              if (*(longlong *)(lVar24 + 0x30) == 0) goto LAB_;
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103698;
              lVar24 = func_0x();
              uVar36 = *(uint *)(*(longlong *)(lVar24 + 0x30) + 0xc);
              *(uint *)(&stack0x00000704 + lVar16) = uVar36;
              if ((uVar36 < 0xe) && ((0x2640U >> (uVar36 & 0x1f) & 1) != 0)) {
                iVar14 = 1;
              }
              else {
                iVar14 = 0;
              }
              *(int *)(&stack0x00000408 + lVar16) = iVar14;
              if (iVar14 != 0) goto LAB_;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1036db;
            func_0x(0,8);
          }
        }
LAB_:
        *(undefined4 *)(&stack0x000006e0 + lVar16) = 0;
        *(undefined4 *)(&stack0x000006e4 + lVar16) = 0;
        *(undefined2 *)(&stack0x000006e8 + lVar16) = 0;
        if (((*(short *)(&stack0x000003b0 + lVar16) == 0) &&
            (*(int *)(&stack0x000003a8 + lVar16) == 0)) &&
           (*(int *)(&stack0x000003ac + lVar16) == 0)) {
LAB_:
          lVar24 = *(longlong *)(&stack0x00000550 + lVar16);
          *(int *)(lVar24 + 4) = *(int *)(lVar24 + 4) + 1;
          if (*(longlong *)(lVar24 + 0x58) != 0) {
            piVar32 = (int *)(*(longlong *)(lVar24 + 0x58) + 4);
            *piVar32 = *piVar32 + 1;
          }
          if ((*(uint *)(&stack0x00000044 + lVar16) & 0xff000000) != 0) {
            *(int *)(*(longlong *)(&stack0x00000550 + lVar16) + 8) =
                 *(int *)(*(longlong *)(&stack0x00000550 + lVar16) + 8) + 1;
            if (*(longlong *)(lVar24 + 0x58) != 0) {
              piVar32 = (int *)(*(longlong *)(lVar24 + 0x58) + 8);
              *piVar32 = *piVar32 + 1;
            }
            if ((&stack0x00000048)[lVar16] != '\0') {
              *(int *)(*(longlong *)(&stack0x00000550 + lVar16) + 0xc) =
                   *(int *)(*(longlong *)(&stack0x00000550 + lVar16) + 0xc) + 1;
              if (*(longlong *)(lVar24 + 0x58) != 0) {
                piVar32 = (int *)(*(longlong *)(lVar24 + 0x58) + 0xc);
                *piVar32 = *piVar32 + 1;
              }
            }
          }
          if (*(int *)(&stack0x0000093c + lVar16) != 0) {
            lVar24 = **(longlong **)(&stack0x00000038 + lVar16);
            *(longlong *)(&stack0x00000f48 + lVar16) = lVar24;
            uVar3 = *(undefined *)(lVar24 + 1);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1039f4;
            func_0x
                      (*(undefined8 *)(&stack0x00000858 + lVar16),uVar3,&stack0x00000938 + lVar16,
                       0xffffffff);
          }
          (&stack0x0000011c)[lVar16] = 0;
          (&stack0x0000011d)[lVar16] = 1;
          *(undefined4 *)(&stack0x00000294 + lVar16) = 0;
          *(undefined2 *)(&stack0x00000298 + lVar16) = 0;
          *(undefined2 *)(&stack0x0000029a + lVar16) = 0;
          lVar24 = **(longlong **)(&stack0x00000638 + lVar16);
          *(longlong *)(&stack0x00000860 + lVar16) = lVar24;
          lVar27 = **(longlong **)(&stack0x00000038 + lVar16);
          *(longlong *)(&stack0x00000f50 + lVar16) = lVar27;
          lVar8 = *(longlong *)(lVar24 + 8);
          piVar32 = (int *)(lVar8 + 0x3c0);
          *(int **)(&stack0x00000f58 + lVar16) = piVar32;
          *(undefined4 *)(&stack0x000004e0 + lVar16) = 0;
          if (*(int *)(lVar27 + 0x18) == *piVar32) {
            uVar4 = *(ushort *)(lVar8 + 0x3c4);
            if ((*(ushort *)(lVar27 + 6) != uVar4) && (1 < (uVar4 | *(ushort *)(lVar27 + 6))))
            goto LAB_;
            *(undefined4 *)(&stack0x000004e0 + lVar16) = 1;
          }
          else {
LAB_:
            *(longlong *)(&stack0x00000f60 + lVar16) = lVar27;
            *(undefined4 *)(&stack0x00000370 + lVar16) = 0;
            *(undefined2 *)(&stack0x00000374 + lVar16) = 0;
            *(undefined2 *)(&stack0x00000376 + lVar16) = 0;
            uVar33 = *(undefined4 *)(lVar27 + 0x18);
            *(undefined4 *)(&stack0x00000370 + lVar16) = uVar33;
            uVar13 = *(undefined2 *)(lVar27 + 6);
            *(undefined2 *)(&stack0x00000374 + lVar16) = uVar13;
            *(undefined4 *)(&stack0x00000294 + lVar16) = uVar33;
            *(undefined2 *)(&stack0x00000298 + lVar16) = uVar13;
            *(undefined2 *)(&stack0x0000029a + lVar16) = 0;
            puVar25 = (undefined2 *)((longlong)*(longlong **)(&stack0x00000038 + lVar16) + 0x62);
            *(undefined2 **)(&stack0x00000f68 + lVar16) = puVar25;
            *(undefined2 *)(&stack0x000001c0 + lVar16) = *puVar25;
            if (((*(ushort *)(&stack0x000001c0 + lVar16) & 0x400) == 0) ||
               (*(short *)(&stack0x00000044 + lVar16) < 3)) {
              *(int *)(&stack0x000000a0 + lVar16) = (int)*(short *)(&stack0x00000044 + lVar16);
              *(undefined8 *)(&stack0x00000558 + lVar16) =
                   *(undefined8 *)(&stack0x00000038 + lVar16);
              *(undefined2 **)(&stack0x00000f70 + lVar16) = puVar25;
              uVar5 = *puVar25;
              *(undefined2 *)(&stack0x000001c8 + lVar16) = uVar5;
              if (((byte)uVar5 >> 3 & 1) != 0) {
                if (*(int *)(&stack0x000000a0 + lVar16) == 3) {
                  *(undefined4 *)(&stack0x000000a0 + lVar16) = 4;
                }
                else if (*(int *)(&stack0x000000a0 + lVar16) < 2) goto LAB_;
                *(uint **)(&stack0x00000f78 + lVar16) =
                     (uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
                uVar36 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
                *(uint *)(&stack0x00000428 + lVar16) = uVar36;
                if ((((uVar36 & 8) != 0) &&
                    (lVar27 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar16) + 0x90),
                    lVar27 != 0)) &&
                   (*(longlong *)(&stack0x00000f80 + lVar16) = lVar27,
                   *(longlong *)(lVar27 + 0x758) != 0)) {
                  uVar20 = *(undefined8 *)(lVar27 + 0x758);
                  *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103bcb;
                  func_0x
                            (uVar20,*(undefined8 *)(&stack0x00000038 + lVar16),
                             *(undefined4 *)(&stack0x000000a0 + lVar16));
                }
              }
LAB_:
              (&stack0x0000011e)[lVar16] = DAT_ >> 7;
              if ((char)DAT_ < '\0') {
                puVar34 = (uint *)(*(longlong *)(&stack0x00000558 + lVar16) + 100);
                *(uint **)(&stack0x00000f88 + lVar16) = puVar34;
                uVar36 = *puVar34;
                *(uint *)(&stack0x00000430 + lVar16) = uVar36;
                if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x000000a0 + lVar16))) {
                  *(uint **)(&stack0x00000f90 + lVar16) = puVar34;
                  uVar36 = *puVar34;
                  *(uint *)(&stack0x00000438 + lVar16) = uVar36;
                  if (((uVar36 & 0xc0000000) != 0x40000000) &&
                     (lVar27 = **(longlong **)(&stack0x00000558 + lVar16), lVar27 != 0)) {
                    *(undefined4 *)(&stack0x00000710 + lVar16) = 2;
                    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103c60;
                    iVar14 = (*_DAT_)(lVar27,0x2000,2,&stack0x00000714 + lVar16);
                    if (iVar14 != 0) {
                      LOCK();
                      *puVar34 = *puVar34 & 0x3fffffff;
                      UNLOCK();
                      LOCK();
                      *puVar34 = *puVar34 | 0x40000000;
                      UNLOCK();
                    }
                  }
                }
              }
              lVar27 = *(longlong *)(&stack0x00000558 + lVar16);
              uVar6 = *(undefined4 *)(&stack0x000000a0 + lVar16);
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103c8f;
              func_0x(lVar27 + 0x98,uVar6);
              if ((_DAT_ != 0) &&
                 ((&stack0x0000011f)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103cb9;
                func_0x(lVar27,0,uVar6);
              }
              *(uint *)(&stack0x00000044 + lVar16) =
                   *(uint *)(&stack0x00000044 + lVar16) & 0xffff0000;
              *(undefined8 *)(&stack0x00000038 + lVar16) = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103b1a;
              func_0x(&stack0x00000038 + lVar16);
            }
            *(undefined **)(&stack0x00000f98 + lVar16) = &stack0x00000378 + lVar16;
            *(undefined **)(&stack0x00000fa0 + lVar16) = &stack0x00000380 + lVar16;
            lVar24 = *(longlong *)(lVar24 + 8);
            puVar28 = (undefined4 *)(lVar24 + 0x3c0);
            *(undefined4 **)(&stack0x00000fa8 + lVar16) = puVar28;
            *(undefined4 *)(&stack0x00000378 + lVar16) = *puVar28;
            *(undefined2 *)(&stack0x0000037c + lVar16) = *(undefined2 *)(lVar24 + 0x3c4);
            *(undefined2 *)(&stack0x0000037e + lVar16) = 0;
            *(undefined4 *)(&stack0x00000380 + lVar16) = uVar33;
            *(undefined2 *)(&stack0x00000384 + lVar16) = uVar13;
            *(undefined2 *)(&stack0x00000386 + lVar16) = 0;
            UNRECOVERED_JUMPTABLE_00 = *(code **)**(undefined8 **)(&stack0x00000860 + lVar16);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103d3e;
            uVar13 = (*UNRECOVERED_JUMPTABLE_00)();
            *(undefined4 *)(&stack0xffffffffffffffe8 + lVar16) =
                 *(undefined4 *)(*(longlong *)(&stack0x00000638 + lVar16) + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103d6e;
            func_0x(&stack0x000000f8 + lVar16,&stack0x00000380 + lVar16,uVar13,
                            &stack0x00000378 + lVar16);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103d80;
          func_0x(&stack0x00000968 + lVar16,&stack0x00000038 + lVar16);
          lVar24 = **pplVar7;
          break;
        }
        lVar24 = **(longlong **)(&stack0x00000038 + lVar16);
        *(longlong *)(&stack0x00000f10 + lVar16) = lVar24;
        if ((*(byte *)(lVar24 + 4) & 1) == 0) goto LAB_;
        puVar25 = (undefined2 *)((longlong)*(longlong **)(&stack0x00000038 + lVar16) + 0x62);
        *(undefined2 **)(&stack0x00000f18 + lVar16) = puVar25;
        *(undefined2 *)(&stack0x000001b0 + lVar16) = *puVar25;
        if (((*(ushort *)(&stack0x000001b0 + lVar16) & 0x400) == 0) ||
           (*(short *)(&stack0x00000044 + lVar16) < 3)) {
          *(int *)(&stack0x00000098 + lVar16) = (int)*(short *)(&stack0x00000044 + lVar16);
          *(undefined8 *)(&stack0x00000548 + lVar16) = *(undefined8 *)(&stack0x00000038 + lVar16);
          *(undefined2 **)(&stack0x00000f20 + lVar16) = puVar25;
          uVar13 = *puVar25;
          *(undefined2 *)(&stack0x000001b8 + lVar16) = uVar13;
          if (((byte)uVar13 >> 3 & 1) != 0) {
            if (*(int *)(&stack0x00000098 + lVar16) == 3) {
              *(undefined4 *)(&stack0x00000098 + lVar16) = 4;
            }
            else if (*(int *)(&stack0x00000098 + lVar16) < 2) goto LAB_;
            *(uint **)(&stack0x00000f28 + lVar16) =
                 (uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
            uVar36 = *(uint *)(*(longlong *)(&stack0x00000038 + lVar16) + 100);
            *(uint *)(&stack0x00000410 + lVar16) = uVar36;
            if ((((uVar36 & 8) != 0) &&
                (lVar24 = *(longlong *)(*(longlong *)(&stack0x00000038 + lVar16) + 0x90),
                lVar24 != 0)) &&
               (*(longlong *)(&stack0x00000f30 + lVar16) = lVar24,
               *(longlong *)(lVar24 + 0x758) != 0)) {
              uVar20 = *(undefined8 *)(lVar24 + 0x758);
              *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10381c;
              func_0x
                        (uVar20,*(undefined8 *)(&stack0x00000038 + lVar16),
                         *(undefined4 *)(&stack0x00000098 + lVar16));
            }
          }
LAB_:
          (&stack0x0000011a)[lVar16] = DAT_ >> 7;
          if ((char)DAT_ < '\0') {
            puVar34 = (uint *)(*(longlong *)(&stack0x00000548 + lVar16) + 100);
            *(uint **)(&stack0x00000f38 + lVar16) = puVar34;
            uVar36 = *puVar34;
            *(uint *)(&stack0x00000418 + lVar16) = uVar36;
            if (((uVar36 & 8) != 0) && (2 < *(int *)(&stack0x00000098 + lVar16))) {
              *(uint **)(&stack0x00000f40 + lVar16) = puVar34;
              uVar36 = *puVar34;
              *(uint *)(&stack0x00000420 + lVar16) = uVar36;
              if (((uVar36 & 0xc0000000) != 0x40000000) &&
                 (lVar24 = **(longlong **)(&stack0x00000548 + lVar16), lVar24 != 0)) {
                *(undefined4 *)(&stack0x00000708 + lVar16) = 2;
                *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1038af;
                iVar14 = (*_DAT_)(lVar24,0x2000,2,&stack0x0000070c + lVar16);
                if (iVar14 != 0) {
                  LOCK();
                  *puVar34 = *puVar34 & 0x3fffffff;
                  UNLOCK();
                  LOCK();
                  *puVar34 = *puVar34 | 0x40000000;
                  UNLOCK();
                }
              }
            }
          }
          lVar24 = *(longlong *)(&stack0x00000548 + lVar16);
          uVar33 = *(undefined4 *)(&stack0x00000098 + lVar16);
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x1038de;
          func_0x(lVar24 + 0x98,uVar33);
          if ((_DAT_ != 0) &&
             ((&stack0x0000011b)[lVar16] = DAT_ >> 1, (DAT_ >> 1 & 1) != 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103908;
            func_0x(lVar24,0,uVar33);
          }
          *(uint *)(&stack0x00000044 + lVar16) = *(uint *)(&stack0x00000044 + lVar16) & 0xffff0000;
          *(undefined8 *)(&stack0x00000038 + lVar16) = 0;
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x10376b;
          func_0x(&stack0x00000038 + lVar16);
        }
        *(undefined4 *)(&stack0x00000a08 + lVar16) = 0x400060;
        *(undefined8 *)(&stack0x00000a10 + lVar16) = 0;
        *(undefined8 *)(&stack0x00000a20 + lVar16) = 0;
        *(undefined8 *)(&stack0x00000a18 + lVar16) = 0;
        *(undefined8 *)(&stack0x00000a28 + lVar16) = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103952;
        func_0x(10,&stack0x00000a08 + lVar16);
        lVar27 = *(longlong *)(&stack0x00000058 + lVar16);
      } while( true );
    }
  }
  *(longlong *)(&stack0x00000fb0 + lVar16) = lVar24;
  *(undefined4 *)(&stack0x00001934 + lVar16) = 0;
  if (-1 < *(char *)(lVar24 + 2)) {
    *(undefined8 *)(&stack0x000005b8 + lVar16) = 0;
    goto LAB_;
  }
  if (*(short *)(&stack0x00001900 + lVar16) == 0) {
    *(undefined8 *)(&stack0x000005b8 + lVar16) = 0;
LAB_:
    *(undefined **)(&stack0x00000fb8 + lVar16) = &stack0x00001938 + lVar16;
    *(undefined (*) [16])(&stack0x00001938 + lVar16) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00001948 + lVar16) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00001958 + lVar16) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00001968 + lVar16) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00001978 + lVar16) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00001988 + lVar16) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x00001998 + lVar16) = ZEXT816(0);
    *(undefined8 *)(&stack0x000019a8 + lVar16) = 0;
    *(undefined **)(&stack0x00000fc0 + lVar16) = &stack0x00001938 + lVar16;
    *(undefined (*) [16])(&stack0x00001938 + lVar16) = ZEXT816(0);
    *(undefined **)(&stack0x00000fc8 + lVar16) = &stack0x00001948 + lVar16;
    *(undefined2 *)(&stack0x00001948 + lVar16) = 0xffff;
    *(undefined8 *)(&stack0x00001950 + lVar16) = 0;
    *(undefined4 *)(&stack0x0000194c + lVar16) = 0;
    *(undefined8 *)(&stack0x00001966 + lVar16) = 0;
    *(undefined8 *)(&stack0x00001970 + lVar16) = 0;
    *(undefined8 *)(&stack0x00001958 + lVar16) = 0;
    *(undefined **)(&stack0x00000fd0 + lVar16) = &stack0x00001980 + lVar16;
    *(undefined8 *)(&stack0x00001980 + lVar16) = 0;
    *(undefined **)(&stack0x00000fd8 + lVar16) = &stack0x00001998 + lVar16;
    *(undefined4 *)(&stack0x00001998 + lVar16) = 0;
    *(undefined4 *)(&stack0x0000199c + lVar16) = 0;
    *(undefined2 *)(&stack0x000019a0 + lVar16) = 0;
    *(undefined2 *)(&stack0x000019a2 + lVar16) = 0;
    *(undefined **)(&stack0x00000fe0 + lVar16) = &stack0x000019a4 + lVar16;
    *(undefined2 *)(&stack0x000019aa + lVar16) = 0;
    ppbVar35 = (byte **)(&stack0x00001938 + lVar16);
    *(byte ***)(&stack0x000005b8 + lVar16) = ppbVar35;
  }
  else {
    ppbVar35 = *(byte ***)(&stack0x00001910 + lVar16);
    *(byte ***)(&stack0x000005b8 + lVar16) = ppbVar35;
    if (ppbVar35 == (byte **)0x0) goto LAB_;
  }
  (&stack0x00000076)[lVar16] = 0;
  if (*(short *)(lVar24 + 0x24) == 0) {
LAB_:
    *(undefined8 *)(&stack0x00000208 + lVar16) = *(undefined8 *)(lVar24 + 0x28);
    sVar12 = *(short *)(lVar24 + 0x30);
    *(short *)(&stack0x00000210 + lVar16) = sVar12;
  }
  else {
    cVar10 = *(char *)(lVar24 + 1);
    if ((((cVar10 == '\v') || (cVar10 == '\b')) || (cVar10 == '\t')) &&
       (*(int *)(lVar24 + 0x18) == 99)) {
      *(undefined **)(&stack0x00000fe8 + lVar16) = &stack0x00000330 + lVar16;
      *(undefined4 **)(&stack0x00000ff0 + lVar16) = (undefined4 *)(lVar24 + 0x20);
      *(undefined4 *)(&stack0x00000330 + lVar16) = *(undefined4 *)(lVar24 + 0x20);
      *(undefined2 *)(&stack0x00000334 + lVar16) = *(undefined2 *)(lVar24 + 0x24);
      *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103f95;
      cVar10 = func_0x(&stack0x00000330 + lVar16);
      if (cVar10 == '\0') goto LAB_;
      cVar10 = '\x01';
    }
    else {
LAB_:
      cVar10 = '\0';
    }
    (&stack0x00000076)[lVar16] = cVar10;
    if (cVar10 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x103fba;
    func_0x(lVar24,&stack0x00000208 + lVar16);
    sVar12 = *(short *)(&stack0x00000210 + lVar16);
  }
  *(undefined **)(&stack0x00000ff8 + lVar16) = &stack0x00000208 + lVar16;
  *(undefined4 **)(&stack0x00001000 + lVar16) = (undefined4 *)(lVar24 + 0x20);
  pbVar37 = (byte *)(lVar24 + 0x60);
  *(byte **)(&stack0x00001008 + lVar16) = pbVar37;
  *(byte ***)(&stack0x00001010 + lVar16) = ppbVar35;
  if (pbVar37 == *ppbVar35) {
    *(byte ***)(&stack0x00001018 + lVar16) = ppbVar35 + 0xc;
    if (((sVar12 == *(short *)(ppbVar35 + 0xd)) &&
        (*(int *)(&stack0x00000208 + lVar16) == *(int *)(ppbVar35 + 0xc))) &&
       (*(int *)(&stack0x0000020c + lVar16) == *(int *)((longlong)ppbVar35 + 100))) {
      *(longlong *)(&stack0x00001020 + lVar16) = (longlong)ppbVar35 + 0x6c;
    }
  }
  *ppbVar35 = pbVar37;
  *(byte ***)(&stack0x00001028 + lVar16) = ppbVar35 + 0xc;
  uVar13 = *(undefined2 *)(&stack0x00000210 + lVar16);
  *(undefined2 *)(&stack0x000004b8 + lVar16) = uVar13;
  uVar33 = *(undefined4 *)(&stack0x0000020c + lVar16);
  *(undefined4 *)(&stack0x00000718 + lVar16) = uVar33;
  *(undefined4 *)(&stack0x00000720 + lVar16) = *(undefined4 *)(&stack0x00000208 + lVar16);
  *(undefined4 *)(ppbVar35 + 0xc) = *(undefined4 *)(&stack0x00000208 + lVar16);
  *(undefined4 *)((longlong)ppbVar35 + 100) = uVar33;
  *(undefined2 *)(ppbVar35 + 0xd) = uVar13;
  *(undefined4 **)(&stack0x00001030 + lVar16) = (undefined4 *)((longlong)ppbVar35 + 0x6c);
  *(undefined4 *)((longlong)ppbVar35 + 0x6c) = *(undefined4 *)(lVar24 + 0x20);
  *(undefined2 *)(ppbVar35 + 0xe) = *(undefined2 *)(lVar24 + 0x24);
  *(undefined2 *)((longlong)ppbVar35 + 0x72) = 0;
  uVar21 = (ulonglong)*pbVar37;
  *(ushort *)(&stack0x000004c0 + lVar16) = (ushort)*pbVar37;
  *(undefined4 *)(&stack0x0000065c + lVar16) = *(undefined4 *)(uVar21 * 6 + 0x1784c80);
  *(undefined2 *)(&stack0x00000660 + lVar16) = *(undefined2 *)(uVar21 * 6 + 0x1784c84);
  *(undefined4 *)(&stack0x00000488 + lVar16) = *(undefined4 *)(uVar21 * 6 + 0x1784c80);
  sVar12 = *(short *)(uVar21 * 6 + 0x1784c84);
  *(short *)(&stack0x00000078 + lVar16) = sVar12;
  *(short *)(&stack0x0000048c + lVar16) = sVar12;
  *(longlong *)(&stack0x00001038 + lVar16) = lVar24 + 99;
  ppbVar1 = ppbVar35 + 2;
  *(byte ***)(&stack0x00001040 + lVar16) = ppbVar1;
  *(undefined2 *)ppbVar1 = 0xffff;
  ppbVar35[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbVar35 + 0x2e) = 0;
  ppbVar35[7] = (byte *)0x0;
  ppbVar35[4] = (byte *)0x0;
  ppsVar2 = (short **)(ppbVar35 + 9);
  *(short ***)(&stack0x00001048 + lVar16) = ppsVar2;
  *ppsVar2 = (short *)0x0;
  ppbVar35[10] = (byte *)0x0;
  *(undefined2 *)(ppbVar35 + 0xb) = 0;
  if ((**ppbVar35 & 2) != 0) {
    pbVar37 = pbVar37 + sVar12;
    *(byte **)(&stack0x00001050 + lVar16) = pbVar37;
    *(byte ***)(&stack0x00001058 + lVar16) = ppbVar1;
    bVar11 = *pbVar37 & 1;
    *(ushort *)(&stack0x000004c8 + lVar16) = (ushort)bVar11;
    *(ushort *)ppbVar1 = (ushort)bVar11;
    if (bVar11 != 0) {
      *(longlong *)(&stack0x00001070 + lVar16) = (longlong)ppbVar35 + 0x12;
      ppbVar35[3] = pbVar37;
      UNRECOVERED_JUMPTABLE_00 =
           (code *)((ulonglong)
                    *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar37 & 0x1c) + 0x1051c0) * 4
                             + 0x1051b0) - 0xe14190);
                    /* WARNING: Could not emulate address calculation at 0x00104291 */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
      return;
    }
    *(undefined4 *)(&stack0x000001f0 + lVar16) = 0;
    *(longlong *)(&stack0x00001060 + lVar16) = (longlong)ppbVar35 + 0x12;
    ppbVar35[3] = pbVar37;
    *(undefined4 *)((longlong)ppbVar35 + 0x14) = 0;
    *(undefined4 *)((longlong)ppbVar35 + 0x36) = 0;
    pbVar37 = ppbVar35[3];
    *(byte **)(&stack0x00001068 + lVar16) = pbVar37;
                    /* WARNING: Could not emulate address calculation at 0x001041cf */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar37 & 0xe) * 4 + 0x105174) - 0xe14190))();
    return;
  }
  if ((**ppbVar35 & 4) != 0) {
    if (*(short *)(&stack0x0000048a + lVar16) == 0) {
      uVar21 = (ulonglong)sVar12;
    }
    else {
      uVar21 = (ulonglong)
               *(ushort *)(lVar24 + 0x61 + (longlong)*(short *)(&stack0x0000048a + lVar16) * 2);
    }
    psVar22 = (short *)(pbVar37 + uVar21);
    *(short **)(&stack0x00001098 + lVar16) = psVar22;
    *(short ***)(&stack0x000010a0 + lVar16) = ppsVar2;
    *ppsVar2 = psVar22;
    sVar12 = *psVar22;
    *(short *)(&stack0x000004cc + lVar16) = sVar12;
    ppbVar35[10] = (byte *)(psVar22 + 1);
    *(short *)(ppbVar35 + 0xb) = (sVar12 + 1) * 2;
  }
  pbVar37 = ppbVar35[1];
  if (pbVar37 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar16) = 0x104560;
    func_0x(pbVar37,ppbVar35);
  }
LAB_:
  uVar4 = *(ushort *)(lVar24 + 0xe);
  *(uint *)(&stack0x00000728 + lVar16) = (uint)uVar4;
  pbVar37 = (byte *)((ulonglong)*(ushort *)(lVar24 + 0x1ffe) + lVar24);
  *(byte **)(&stack0x000010a8 + lVar16) = pbVar37;
  bVar11 = *pbVar37 & 1;
  *(ushort *)(&stack0x00000078 + lVar16) = (ushort)bVar11;
  *(ushort *)(&stack0x00001900 + lVar16) = (ushort)bVar11;
  if (bVar11 != 0) {
    *(undefined **)(&stack0x000010c0 + lVar16) = &stack0x00001902 + lVar16;
    *(byte **)(&stack0x00001908 + lVar16) = pbVar37;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar37 & 0x1c) + 0x10522c) * 4 +
                           0x10521c) - 0xe14190);
                    /* WARNING: Could not emulate address calculation at 0x0010468d */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  *(uint *)(&stack0x000001f8 + lVar16) = (uint)uVar4;
  *(undefined **)(&stack0x000010b0 + lVar16) = &stack0x00001902 + lVar16;
  *(byte **)(&stack0x00001908 + lVar16) = pbVar37;
  *(undefined4 *)(&stack0x00001904 + lVar16) = 0;
  *(undefined4 *)(&stack0x00001926 + lVar16) = 0;
  *(byte **)(&stack0x000010b8 + lVar16) = pbVar37;
                    /* WARNING: Could not emulate address calculation at 0x001045e1 */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar37 & 0xe) * 4 + 0x1051e0) - 0xe14190))();
  return;
}

