
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,int param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8)

{
  byte *pbVar1;
  longlong lVar2;
  byte bVar3;
  short sVar4;
  undefined auVar5 [16];
  char cVar6;
  longlong lVar7;
  code *UNRECOVERED_JUMPTABLE_00;
  byte *pbVar8;
  undefined2 uVar9;
  ulonglong uVar10;
  undefined8 uStackX_18;
  undefined2 auStackX_20 [4];
  undefined auStack_20b0 [16];
  undefined auStack_20a0 [8];
  undefined8 uStack_2098;
  undefined8 uStack_2090;
  undefined6 uStack_2088;
  undefined2 uStack_2082;
  undefined6 uStack_2080;
  undefined2 uStack_207a;
  undefined2 uStack_2078;
  undefined6 uStack_2076;
  undefined8 uStack_2070;
  short *psStack_2068;
  short *psStack_2060;
  short sStack_2058;
  undefined6 uStack_2056;
  undefined auStack_2050 [8];
  undefined8 uStack_2048;
  undefined8 uStack_2040;
  undefined2 uStack_2038;
  undefined4 uStack_2034;
  undefined8 uStack_2030;
  undefined8 uStack_2028;
  undefined8 uStack_201a;
  undefined8 uStack_2010;
  undefined *puStack_2000;
  undefined4 uStack_1ff8;
  undefined auStack_1fe8 [8096];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x100022;
  lVar7 = func_0x();
  lVar7 = -lVar7;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar7);
  *(undefined8 *)((longlong)&param_6 + lVar7) = param_8;
  *(undefined4 *)((longlong)&param_5 + lVar7) = param_5;
  *(undefined8 *)((longlong)&param_7 + lVar7) = param_6;
  puStack_2000 = auStack_1fe8;
  *(undefined4 *)(&stack0xfffffffffffffff8 + lVar7) = param_3;
  *(undefined4 *)(&stack0x00000010 + lVar7) = param_4;
  *(longlong *)((longlong)&param_8 + lVar7) = param_1;
  uStack_2038 = 0xffff;
  uStack_2030 = 0;
  uStack_2034 = 0;
  uStack_201a = 0;
  uStack_2010 = 0;
  uStack_2028 = 0;
  uStack_1ff8 = 0x1f9e;
  if (-1 < *(char *)(param_1 + 2)) goto LAB_;
  pbVar8 = (byte *)(param_1 + 0x60);
  stack0xffffffffffffdf62 = SUB1614(ZEXT816(0),2);
  auStack_20a0._0_2_ = 0xffff;
  uStack_2088 = 0;
  uStack_207a = 0;
  uStack_2098 = 0;
  uStack_2070 = 0;
  uStack_2082 = 0;
  uStack_2080 = 0;
  uStack_2078 = 0;
  uStack_2076 = 0;
  uStack_2090 = 0;
  psStack_2068 = (short *)0x0;
  _auStack_2050 = ZEXT812(0);
  uStack_2048._4_4_ = 0;
  auVar5 = _auStack_2050;
  uStack_2048 = 0;
  uStack_2040 = 0;
  psStack_2060 = (short *)0x0;
  sStack_2058 = 0;
  uStack_2056 = 0;
  auStack_20b0 = ZEXT816(0);
  lVar2 = 0;
  if (*(short *)(param_1 + 0x24) == 0) {
LAB_:
    auStack_20b0._8_8_ = lVar2;
    uVar9 = *(undefined2 *)(param_1 + 0x30);
    *(undefined8 *)((longlong)&uStackX_18 + lVar7) = *(undefined8 *)(param_1 + 0x28);
  }
  else {
    cVar6 = *(char *)(param_1 + 1);
    if (cVar6 == '\v') {
      if (*(int *)(param_1 + 0x18) != 99) {
LAB_:
        if (cVar6 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar6 != '\b') goto LAB_;
LAB_:
      if (*(int *)(param_1 + 0x18) != 99) goto LAB_;
    }
    _auStack_2050 = auVar5;
    *(undefined4 *)((longlong)auStackX_20 + lVar7 + -0x20) = *(undefined4 *)(param_1 + 0x20);
    *(undefined2 *)((longlong)auStackX_20 + lVar7 + -0x1c) = *(undefined2 *)(param_1 + 0x24);
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100184;
    cVar6 = func_0x((longlong)auStackX_20 + lVar7 + -0x20,0xfffffffffeb96800,2);
    lVar2 = auStack_20b0._8_8_;
    if (cVar6 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100195;
    func_0x(param_1,(longlong)&uStackX_18 + lVar7);
    uVar9 = *(undefined2 *)((longlong)auStackX_20 + lVar7);
  }
  bVar3 = *pbVar8;
  auStack_2050._4_4_ = (int)((ulonglong)*(undefined8 *)((longlong)&uStackX_18 + lVar7) >> 0x20);
  auStack_2050._0_4_ = *(undefined4 *)((longlong)&uStackX_18 + lVar7);
  uStack_2048._4_4_ = *(undefined4 *)(param_1 + 0x20);
  lVar2 = (ulonglong)bVar3 * 6;
  auStack_20a0._0_2_ = 0xffff;
  uVar10 = (ulonglong)*(short *)(lVar2 + 0x112f614);
  *(undefined4 *)((longlong)auStackX_20 + lVar7 + -0x20) = *(undefined4 *)(lVar2 + 0x112f610);
  auStack_20b0._0_8_ = pbVar8;
  uStack_2048._0_2_ = uVar9;
  auStack_20a0 = (undefined  [8])((ulonglong)auStack_20a0 & 0xffffffff);
  uStack_2098 = 0;
  uStack_2082 = 0;
  uStack_2080 = 0;
  uStack_2078 = 0;
  uStack_2076 = 0;
  uStack_2090 = 0;
  sStack_2058 = 0;
  psStack_2068 = (short *)0x0;
  psStack_2060 = (short *)0x0;
  if ((bVar3 & 2) != 0) {
    pbVar1 = pbVar8 + uVar10;
    uStack_2098 = pbVar1;
    if ((pbVar8[uVar10] & 1) == 0) {
      auVar5._14_2_ = 0;
      auVar5._0_14_ = stack0xffffffffffffdf62;
      _auStack_20a0 = auVar5 << 0x10;
      uStack_207a = 0;
      uStack_2078 = 0;
                    /* WARNING: Could not emulate address calculation at 0x001003ad */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x104080) - 0x1469800))()
      ;
      return;
    }
    auStack_20a0._0_2_ = 1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x104060) * 4 +
                           0x104050) - 0x1469800);
                    /* WARNING: Could not emulate address calculation at 0x0010025b */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((*pbVar8 & 4) != 0) {
    sVar4 = *(short *)((longlong)auStackX_20 + lVar7 + -0x1e);
    if (sVar4 != 0) {
      uVar10 = (ulonglong)*(ushort *)(param_1 + 0x61 + (longlong)sVar4 * 2);
    }
    psStack_2068 = (short *)(pbVar8 + uVar10);
    psStack_2060 = psStack_2068 + 1;
    sStack_2058 = (*psStack_2068 + 1) * 2;
  }
  if (auStack_20b0._8_8_ != 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar7) = 0x100468;
    func_0x(auStack_20b0._8_8_,auStack_20b0);
  }
LAB_:
  pbVar8 = (byte *)((ulonglong)*(ushort *)(param_1 + (0xfff - (longlong)param_2) * 2) + param_1);
  if ((*pbVar8 & 1) == 0) {
                    /* WARNING: Could not emulate address calculation at 0x00100645 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar8 & 0xe) * 4 + 0x1040ec) - 0x1469800))
              ((longlong)(int)(*pbVar8 & 0xe),0xfffffffffeb96800,0);
    return;
  }
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar8 & 0x1c) + 0x1040cc) * 4 +
                         0x1040bc) - 0x1469800);
                    /* WARNING: Could not emulate address calculation at 0x001004bd */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00,*pbVar8,2);
  return;
}

