
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined4 *param_2,undefined8 param_3,undefined8 param_4)

{
  uint *puVar1;
  byte bVar2;
  undefined2 uVar3;
  undefined2 uVar4;
  undefined4 uVar5;
  code *pcVar6;
  int *piVar7;
  longlong *plVar8;
  ushort *puVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  char cVar12;
  byte bVar13;
  char cVar14;
  undefined uVar15;
  short sVar16;
  ushort uVar17;
  ushort uVar18;
  int iVar19;
  uint uVar20;
  int iVar21;
  int iVar22;
  int iVar23;
  undefined4 uVar24;
  longlong lVar25;
  byte **ppbVar26;
  undefined8 uVar27;
  undefined8 *puVar28;
  undefined4 *puVar29;
  short *psVar30;
  longlong lVar31;
  undefined8 *puVar32;
  ulonglong *puVar33;
  longlong lVar34;
  longlong lVar35;
  undefined4 *puVar36;
  undefined4 *puVar37;
  longlong lVar38;
  byte bVar39;
  short sVar40;
  short sVar41;
  ushort *puVar42;
  longlong *plVar43;
  undefined8 unaff_RBX;
  byte *pbVar44;
  undefined *puVar45;
  uint uVar46;
  uint uVar47;
  byte *pbVar48;
  ulonglong uVar49;
  short *psVar50;
  ulonglong uVar51;
  uint uVar52;
  byte *pbVar53;
  undefined2 *puVar54;
  longlong *plVar55;
  ulonglong uVar56;
  ushort *puVar57;
  longlong *plVar58;
  ulonglong uVar59;
  longlong *plVar60;
  bool bVar61;
  undefined8 uStackX_8;
  undefined8 uStackX_16;
  undefined8 uStackX_20;
  undefined auStack_f8 [112];
  undefined auStack_88 [8];
  undefined8 uStack_80;
  undefined2 auStack_78 [2];
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_5a;
  undefined8 uStack_50;
  undefined auStack_48 [8];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar25 = func_0x();
  lVar25 = -lVar25;
  puVar45 = &stack0xffffffffffffffc8 + lVar25;
  puVar1 = (uint *)(&stack0x00000038 + lVar25);
  *(undefined8 *)(&stack0x00000258 + lVar25) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002980 + lVar25) = unaff_RBX;
  *(ulonglong *)(&stack0x00002928 + lVar25) = _DAT_ ^ (ulonglong)puVar1;
  *(undefined8 *)(&stack0x00000238 + lVar25) = param_4;
  *(undefined8 *)(&stack0x00000110 + lVar25) = param_3;
  *(longlong *)(&stack0x00000118 + lVar25) = param_1;
  *(longlong *)(&stack0x000001d0 + lVar25) = param_1;
  puVar28 = *(undefined8 **)(&stack0x00002998 + lVar25);
  *(undefined8 **)(&stack0x00000240 + lVar25) = puVar28;
  *(undefined2 *)(&stack0x00000058 + lVar25) = 0xffff;
  uVar49 = 0;
  *(undefined8 *)(&stack0x00000060 + lVar25) = 0;
  *(undefined4 *)(&stack0x0000005c + lVar25) = 0;
  *(undefined8 *)(&stack0x00000076 + lVar25) = 0;
  *(undefined8 *)(&stack0x00000080 + lVar25) = 0;
  *(undefined8 *)(&stack0x00000068 + lVar25) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1000a7;
  func_0x(&stack0x00000988 + lVar25,0,0x1f9e);
  *(undefined2 *)(&stack0x00000772 + lVar25) = 0;
  *(undefined4 *)(&stack0x000001d8 + lVar25) = _DAT_;
  *(undefined4 *)(&stack0x000001dc + lVar25) = uRam0000000001ed926c;
  *(undefined4 *)(&stack0x000001e0 + lVar25) = _DAT_;
  *(undefined4 *)(&stack0x000001e4 + lVar25) = uRam0000000001ed9274;
  *(undefined4 *)(&stack0x00000094 + lVar25) = 0xffffffff;
  *(undefined4 *)(&stack0x00000048 + lVar25) = 1;
  *(undefined8 *)(&stack0x00000120 + lVar25) =
       *(undefined8 *)(*(longlong *)(*(longlong *)(param_1 + 0x2e0) + 8) + 0x30);
  *puVar28 = 0;
  lVar31 = *(longlong *)(param_1 + 0xae8);
  if (lVar31 == param_1 + 0xae0) {
LAB_:
    *(undefined4 *)(&stack0x000000a8 + lVar25) = 0x75f;
    (&stack0xffffffffffffffe8)[lVar25] = 5;
    uVar27 = *(undefined8 *)(param_1 + 0x1f0);
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100152;
    lVar31 = (*_DAT_)(0x638,uVar27,0x17a7818,0x75f);
    *(longlong *)(&stack0x000000e8 + lVar25) = lVar31;
    uVar51 = uVar49;
    if (lVar31 != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100166;
      uVar51 = func_0x(lVar31);
    }
    *(ulonglong *)(&stack0x000000b8 + lVar25) = uVar51;
    uVar27 = *(undefined8 *)(param_1 + 0x2d8);
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100184;
    func_0x(uVar51,uVar27);
  }
  else {
    uVar51 = uVar49;
    if (lVar31 != 0) {
      uVar51 = lVar31 - 0x10;
    }
    *(ulonglong *)(&stack0x000000b8 + lVar25) = uVar51;
    if (uVar51 == 0) goto LAB_;
    plVar58 = *(longlong **)(uVar51 + 0x18);
    lVar31 = *(longlong *)(uVar51 + 0x10);
    *(longlong **)(lVar31 + 8) = plVar58;
    *plVar58 = lVar31;
    *(undefined8 *)(uVar51 + 0x18) = 0;
    *(undefined8 *)(uVar51 + 0x10) = 0;
  }
  plVar58 = (longlong *)(uVar51 + 0x10);
  *(undefined8 *)(uVar51 + 0x18) = *(undefined8 *)(param_1 + 0xaf8);
  **(longlong ***)(param_1 + 0xaf8) = plVar58;
  *(longlong **)(param_1 + 0xaf8) = plVar58;
  *plVar58 = param_1 + 0xaf0;
  uVar20 = **(uint **)(param_1 + 0x108);
  puVar28 = *(undefined8 **)(param_1 + 0x2e0);
  *(undefined4 *)(&stack0x000000a8 + lVar25) = 0x10;
  if (*(int *)(uVar51 + 0x630) == 1) {
    *(undefined8 **)(uVar51 + 0x28) = puVar28;
    *(undefined8 **)(uVar51 + 0x38) = puVar28;
    *(longlong *)(uVar51 + 0x100) = *(longlong *)(*(longlong *)(uVar51 + 0x30) + 0x48) + 0x28;
    *(undefined4 *)(uVar51 + 0xf0) = 2;
    if (*(int *)(*(longlong *)(*(longlong *)(uVar51 + 0x20) + 0x48) + 0x18) != 1) {
      uVar27 = *puVar28;
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10021e;
      func_0x(uVar51 + 0x538,uVar27,uVar20 >> 0x1b & 1);
      lVar31 = *(longlong *)(uVar51 + 0x20);
      bVar39 = 0;
      bVar13 = bVar39;
      if (*(int *)(lVar31 + 0x40) == 3) {
        bVar13 = 8;
      }
      bVar2 = *(byte *)(uVar51 + 0x530);
      *(byte *)(uVar51 + 0x530) = bVar13 | bVar2 & 0xf7;
      if (*(int *)(lVar31 + 0x40) == 4) {
        bVar39 = 0x10;
      }
      bVar39 = bVar39 | bVar13 | bVar2 & 0xe7;
      *(byte *)(uVar51 + 0x530) = bVar39;
      *(byte *)(uVar51 + 0x530) =
           ((char)((*(int *)(*(longlong *)(lVar31 + 0x10) + 0x50) << 0x1f) >> 0x1f) << 5 ^ bVar39) &
           0x20 ^ bVar39;
      *(undefined4 *)(uVar51 + 0x548) = *(undefined4 *)(*(longlong *)(lVar31 + 0x48) + 0x188);
      *(undefined4 *)(uVar51 + 0x54c) = *(undefined4 *)(puVar28 + 4);
    }
    *(undefined4 *)(uVar51 + 0x630) = 2;
  }
  *(ulonglong *)(&stack0x000001d0 + lVar25) = uVar51;
  *(undefined4 *)(&stack0x00000760 + lVar25) = *param_2;
  *(undefined2 *)(&stack0x00000764 + lVar25) = *(undefined2 *)(param_2 + 1);
  *(undefined2 *)(&stack0x00000766 + lVar25) = 0;
  *(undefined8 *)(&stack0x00000758 + lVar25) = 0;
  *(undefined4 *)(&stack0x00000774 + lVar25) = 0;
  *(undefined8 *)(&stack0x00000768 + lVar25) = 0;
  *(undefined2 *)(&stack0x00000770 + lVar25) = 0;
  puVar28 = *(undefined8 **)(*(longlong *)(&stack0x00000118 + lVar25) + 0x2d8);
  *(undefined **)(&stack0xffffffffffffffe8 + lVar25) = &stack0x000001d8 + lVar25;
  uVar27 = *puVar28;
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10030e;
  iVar19 = func_0x(uVar27,&stack0x00000758 + lVar25,3,2);
  if (iVar19 != 0) {
    *(uint *)(uVar51 + 0x634) = *(uint *)(uVar51 + 0x634) & 0xfffffffe;
    plVar58 = (longlong *)(uVar51 + 0x30);
    (&stack0x00000746)[lVar25] = 1;
    uVar27 = *(undefined8 *)*plVar58;
    plVar60 = *(longlong **)(*(longlong *)(uVar51 + 0x38) + 8);
    uVar24 = *(undefined4 *)(&stack0x000001dc + lVar25);
    uVar5 = *(undefined4 *)(&stack0x000001e0 + lVar25);
    uVar10 = *(undefined4 *)(&stack0x000001e4 + lVar25);
    *(undefined4 *)(uVar51 + 0x40) = *(undefined4 *)(&stack0x000001d8 + lVar25);
    *(undefined4 *)(uVar51 + 0x44) = uVar24;
    *(undefined4 *)(uVar51 + 0x48) = uVar5;
    *(undefined4 *)(uVar51 + 0x4c) = uVar10;
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100350;
    func_0x(uVar27,uVar51 + 0x40,uVar51 + 0x58);
    *(undefined8 *)(uVar51 + 0x288) = **(undefined8 **)(uVar51 + 0x58);
    *(undefined4 *)(uVar51 + 0x88) = 3;
    *(undefined4 *)(uVar51 + 0x29c) = 0;
    lVar31 = *(longlong *)(*plVar58 + 0x18);
    uVar20 = *(uint *)(*(longlong *)(uVar51 + 0x100) + 0x10);
    if (((((uVar20 & 1) != 0) && ((uVar20 & 0x40) == 0)) &&
        (lVar35 = plVar60[6], *(char *)(lVar35 + 0x1cd2) != '\0')) &&
       (*(char *)(lVar35 + 0x2050) == '\0')) {
      uVar24 = *(undefined4 *)(*(longlong *)(uVar51 + 0x40) + 0x90);
      uVar3 = *(undefined2 *)(*(longlong *)(uVar51 + 0x40) + 0x94);
      uVar4 = *(undefined2 *)(lVar35 + 0x6b8);
      (&stack0x00000746)[lVar25] = 6;
      *(undefined2 *)(&stack0x00000744 + lVar25) = uVar4;
      *(undefined8 *)(&stack0x0000073c + lVar25) = 0;
      *(undefined4 *)(&stack0x00000738 + lVar25) = uVar24;
      *(undefined2 *)(&stack0x0000073c + lVar25) = uVar3;
      uVar27 = *(undefined8 *)(*(longlong *)(uVar51 + 0x38) + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100406;
      cVar12 = func_0x(uVar27,CONCAT71((uint7)(byte)((ushort)uVar3 >> 8),6),
                               &stack0x00000738 + lVar25,1);
      if (cVar12 == '\0') {
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100412;
        func_0x(plVar58);
        lVar35 = *(longlong *)(*plVar58 + 0x18);
        lVar34 = *(longlong *)(uVar51 + 0x38);
        (&stack0xffffffffffffffe8)[lVar25] = 1;
        uVar24 = *(undefined4 *)(lVar35 + 0x18);
        uVar27 = *(undefined8 *)(lVar34 + 8);
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100438;
        func_0x(uVar27,6,uVar24,&stack0x00000738 + lVar25);
      }
    }
    uVar59 = uVar51;
    if (*(char *)(lVar31 + 2) != '\0') {
      pcVar6 = *(code **)(*plVar60 + 0x28);
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10044c;
      cVar12 = (*pcVar6)(plVar60);
      if (cVar12 == '\0') {
        uVar24 = *(undefined4 *)(*(longlong *)(uVar51 + 0x40) + 0x90);
        uVar3 = *(undefined2 *)(*(longlong *)(uVar51 + 0x40) + 0x94);
        uVar4 = *(undefined2 *)
                 (*(longlong *)(*(longlong *)(*(longlong *)(uVar51 + 0x38) + 8) + 0x30) + 0x6b8);
        (&stack0x00000746)[lVar25] = 6;
        *(undefined2 *)(&stack0x00000744 + lVar25) = uVar4;
        *(undefined8 *)(&stack0x0000073c + lVar25) = 0;
        *(undefined4 *)(&stack0x00000738 + lVar25) = uVar24;
        *(undefined2 *)(&stack0x0000073c + lVar25) = uVar3;
        *(undefined4 *)((longlong)&uStackX_20 + lVar25 + -0x20) = 1;
        *(undefined4 *)(&stack0xfffffffffffffff8 + lVar25) = 1;
        *(undefined4 *)(&stack0xfffffffffffffff0 + lVar25) = 1;
        *(ulonglong *)(&stack0xffffffffffffffe8 + lVar25) = uVar51 + 0xc0;
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1004d5;
        iVar19 = func_0x(plVar58,&stack0x00000738 + lVar25,2,lVar31);
        if (iVar19 < 0) {
          if ((*(longlong *)(uVar51 + 0x40) != CONCAT44(uRam0000000001ed926c,_DAT_)) ||
             (*(longlong *)(uVar51 + 0x48) != CONCAT44(uRam0000000001ed9274,_DAT_))) {
            if ((*(byte *)(uVar51 + 0xa0) & 2) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100510;
              iVar19 = func_0x(uVar51 + 0xa8);
              if (iVar19 != 0) {
                *(longlong *)(*plVar58 + 0x30) = *(longlong *)(*plVar58 + 0x30) + -1;
              }
            }
            *(undefined *)(uVar51 + 0xa0) = 0;
            *(undefined4 *)(uVar51 + 0x9c) = 0;
            *(undefined4 *)(uVar51 + 0xb8) = 0;
            if ((*(byte *)(uVar51 + 0xd0) & 2) != 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100549;
              iVar19 = func_0x(uVar51 + 0xd8);
              if (iVar19 != 0) {
                *(longlong *)(*plVar58 + 0x30) = *(longlong *)(*plVar58 + 0x30) + -1;
              }
            }
            *(undefined *)(uVar51 + 0xd0) = 0;
            *(undefined4 *)(uVar51 + 0xcc) = 0;
            *(undefined4 *)(uVar51 + 0xe8) = 0;
            if (*(longlong *)(uVar51 + 0x58) != 0) {
              if (*(longlong *)(uVar51 + 0x58) != 0) {
                *(undefined *)(uVar51 + 0x66) = 0;
                *(undefined8 *)(uVar51 + 0x58) = 0;
                *(undefined2 *)(uVar51 + 100) = 0;
              }
              *(undefined4 *)(*(longlong *)(uVar51 + 0x40) + 0x48) = 0;
            }
            uVar27 = *(undefined8 *)*plVar58;
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10059f;
            func_0x(uVar27,uVar51 + 0x40);
            uVar10 = uRam0000000001ed9274;
            uVar5 = _DAT_;
            uVar24 = uRam0000000001ed926c;
            *(undefined4 *)(uVar51 + 0x40) = _DAT_;
            *(undefined4 *)(uVar51 + 0x44) = uVar24;
            *(undefined4 *)(uVar51 + 0x48) = uVar5;
            *(undefined4 *)(uVar51 + 0x4c) = uVar10;
            *(undefined4 *)(uVar51 + 0x50) = 0xffffffff;
            *(undefined4 *)(uVar51 + 0x270) = 0;
            *(undefined8 *)(uVar51 + 0x288) = 0;
            *(undefined8 *)(uVar51 + 0x280) = 0;
            *(undefined8 *)(uVar51 + 0x290) = 0;
            *(undefined4 *)(uVar51 + 0x2a0) = 0xffffffff;
            *(undefined2 *)(uVar51 + 0x2a4) = 0xffff;
            *(undefined8 *)(uVar51 + 0x2a6) = 0;
            *(undefined4 *)(uVar51 + 0xf0) = 2;
          }
          goto LAB_;
        }
      }
    }
    *(undefined4 *)(uVar51 + 0xf0) = 3;
    if (*(longlong *)(uVar51 + 0x58) != 0) {
LAB_:
      uVar20 = *(uint *)(uVar51 + 0x634) | 1;
      *(uint *)(uVar51 + 0x634) = uVar20;
      iVar19 = *(int *)(&stack0x000000a8 + lVar25);
LAB_:
      lVar31 = 0;
      lVar35 = *(longlong *)(uVar59 + 0x288);
      if (*(longlong *)(uVar59 + 0x288) == 0) {
        *(uint *)(uVar59 + 0x634) = uVar20 & 0xfffffffe;
        if (*(int *)(uVar59 + 0x370) == 4) {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1006bc;
          func_0x(uVar59 + 0x2b0);
        }
        if (*(longlong **)(uVar51 + 0x58) == (longlong *)0x0) {
          if (*(int *)(uVar51 + 0xf0) != 2) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1006e1;
            func_0x(plVar58,1);
            if (*(int *)(uVar51 + 0xf0) != 2) {
              lVar31 = **(longlong **)(uVar51 + 0x58);
            }
          }
        }
        else {
          lVar31 = **(longlong **)(uVar51 + 0x58);
        }
        lVar35 = lVar31;
        if (*(char *)(*(longlong *)(uVar59 + 0x28) + 0xb5) == '\0') {
          *(uint *)(uVar59 + 0x634) = *(uint *)(uVar59 + 0x634) | 1;
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100716;
      iVar21 = func_0x(lVar35,*(undefined4 *)(&stack0x00000094 + lVar25));
      *(int *)(&stack0x00000094 + lVar25) = iVar21;
      *(uint *)(uVar59 + 0x634) = *(uint *)(uVar59 + 0x634) & 0xfffffffe;
      if (iVar21 != -1) {
        iVar21 = 0;
        *(undefined4 *)(&stack0x000000ac + lVar25) = 0;
        uVar24 = *(undefined4 *)(&stack0x00000048 + lVar25);
LAB_:
        *(undefined4 *)(&stack0x00000048 + lVar25) = uVar24;
        *puVar1 = (uint)uVar49;
        if ((*(int *)(uVar59 + 0x370) == 4) &&
           ((*(longlong *)(uVar59 + 0x2c0) != CONCAT44(uRam0000000001ed926c,_DAT_) ||
            (*(longlong *)(uVar59 + 0x2c8) != CONCAT44(uRam0000000001ed9274,_DAT_))))) {
          if ((*(byte *)(uVar59 + 800) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10078f;
            iVar22 = func_0x();
            if (iVar22 != 0) {
              plVar60 = (longlong *)(*(longlong *)(uVar59 + 0x2b0) + 0x30);
              *plVar60 = *plVar60 + -1;
            }
          }
          *(undefined *)(uVar59 + 800) = 0;
          *(undefined4 *)(uVar59 + 0x31c) = 0;
          *(undefined4 *)(uVar59 + 0x338) = 0;
          if ((*(byte *)(uVar59 + 0x350) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1007cc;
            iVar22 = func_0x();
            if (iVar22 != 0) {
              plVar60 = (longlong *)(*(longlong *)(uVar59 + 0x2b0) + 0x30);
              *plVar60 = *plVar60 + -1;
            }
          }
          *(undefined *)(uVar59 + 0x350) = 0;
          *(undefined4 *)(uVar59 + 0x34c) = 0;
          *(undefined4 *)(uVar59 + 0x368) = 0;
          if (*(longlong *)(uVar59 + 0x2d8) != 0) {
            *(undefined *)(uVar59 + 0x2e6) = 0;
            *(undefined8 *)(uVar59 + 0x2d8) = 0;
            *(undefined2 *)(uVar59 + 0x2e4) = 0;
            *(undefined4 *)(*(longlong *)(uVar59 + 0x2c0) + 0x48) = 0;
          }
          uVar27 = **(undefined8 **)(uVar59 + 0x2b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100834;
          func_0x(uVar27,uVar59 + 0x2c0);
          uVar11 = uRam0000000001ed9274;
          uVar10 = _DAT_;
          uVar5 = uRam0000000001ed926c;
          *(undefined4 *)(uVar59 + 0x2c0) = _DAT_;
          *(undefined4 *)(uVar59 + 0x2c4) = uVar5;
          *(undefined4 *)(uVar59 + 0x2c8) = uVar10;
          *(undefined4 *)(uVar59 + 0x2cc) = uVar11;
          *(undefined4 *)(uVar59 + 0x2d0) = 0xffffffff;
          *(undefined4 *)(uVar59 + 0x4f0) = 0;
          *(undefined8 *)(uVar59 + 0x508) = 0;
          *(undefined8 *)(uVar59 + 0x500) = 0;
          *(undefined8 *)(uVar59 + 0x510) = 0;
          *(undefined4 *)(uVar59 + 0x520) = 0xffffffff;
          *(undefined2 *)(uVar59 + 0x524) = 0xffff;
          *(undefined8 *)(uVar59 + 0x526) = 0;
          *(undefined4 *)(uVar59 + 0x370) = 2;
        }
        if (iVar21 < 1) {
          if (iVar21 == 0) goto LAB_;
        }
        else {
          if (*(longlong *)(uVar51 + 0x58) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1008ad;
            func_0x(plVar58,0);
          }
          if (*(int *)(uVar51 + 0x270) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1008c4;
            func_0x(plVar58,1);
          }
          uVar49 = (ulonglong)*(uint *)(uVar51 + 0x268);
          *puVar1 = *(uint *)(uVar51 + 0x268);
          uVar24 = *(undefined4 *)(uVar51 + 0x26c);
          *(undefined4 *)(&stack0x00000048 + lVar25) = uVar24;
        }
        if (*(char *)(*(longlong *)(uVar59 + 0x28) + 0x29) != '\0') {
LAB_:
          lVar35 = *(longlong *)(*(longlong *)(uVar51 + 0x38) + 8);
          *(longlong *)(&stack0x00000108 + lVar25) = lVar35;
          *(undefined2 *)(&stack0x000007a8 + lVar25) = 0xffff;
          *(undefined8 *)(&stack0x000007b0 + lVar25) = 0;
          *(undefined4 *)(&stack0x000007ac + lVar25) = 0;
          *(undefined8 *)(&stack0x000007c6 + lVar25) = 0;
          *(undefined8 *)(&stack0x000007d0 + lVar25) = 0;
          *(undefined8 *)(&stack0x000007b8 + lVar25) = 0;
          *(undefined4 *)(&stack0x000007dc + lVar25) = 0xffffffff;
          *(undefined4 *)(&stack0x000000c8 + lVar25) = 0;
          *(undefined2 *)(&stack0x000000cc + lVar25) = 0;
          lVar31 = *(longlong *)(*plVar58 + 0x18);
          *(longlong *)(&stack0x00000100 + lVar25) = lVar31;
          (&stack0x0000003c)[lVar25] = 0;
          if ((*(byte *)(uVar51 + 0xa0) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100b61;
            iVar19 = func_0x(uVar51 + 0xa8);
            if (iVar19 != 0) {
              *(longlong *)(*plVar58 + 0x30) = *(longlong *)(*plVar58 + 0x30) + -1;
            }
          }
          *(undefined *)(uVar51 + 0xa0) = 0;
          *(undefined4 *)(uVar51 + 0x9c) = 0;
          *(undefined4 *)(uVar51 + 0xb8) = 0;
          *(undefined4 *)(uVar51 + 0x50) = *(undefined4 *)(&stack0x00000094 + lVar25);
          uVar20 = *(uint *)(*(longlong *)(uVar51 + 0x100) + 0x10);
          if (((((uVar20 & 1) != 0) && ((uVar20 & 0x40) == 0)) &&
              (*(char *)(*(longlong *)(lVar35 + 0x30) + 0x1cd2) != '\0')) &&
             (*(char *)(*(longlong *)(lVar35 + 0x30) + 0x2050) == '\0')) {
            (&stack0x00000916)[lVar25] = 1;
            lVar34 = **(longlong **)(uVar51 + 0x58);
            uVar5 = *(undefined4 *)(uVar51 + 0x50);
            *(undefined4 *)(&stack0x00000198 + lVar25) = *(undefined4 *)(lVar34 + 0x20);
            *(undefined2 *)(&stack0x0000019c + lVar25) = *(undefined2 *)(lVar34 + 0x24);
            *(short *)(&stack0x0000019e + lVar25) = (short)uVar5;
            uVar3 = *(undefined2 *)(*(longlong *)(lVar35 + 0x30) + 0x6b8);
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100c0b;
            func_0x(&stack0x00000908 + lVar25,uVar3,&stack0x00000198 + lVar25);
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100c1f;
            cVar12 = func_0x(lVar35,3,&stack0x00000908 + lVar25,1);
            if (cVar12 == '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100c2b;
              func_0x(plVar58);
              lVar34 = *(longlong *)(*plVar58 + 0x18);
              (&stack0xffffffffffffffe8)[lVar25] = 1;
              uVar5 = *(undefined4 *)(lVar34 + 0x18);
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100c4c;
              func_0x(lVar35,3,uVar5,&stack0x00000908 + lVar25);
              if (*(longlong *)(uVar51 + 0x58) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100c5d;
                func_0x(plVar58,0);
              }
            }
          }
          *(int *)(&stack0x000000c0 + lVar25) = _DAT_;
          *(undefined2 *)(&stack0x00000090 + lVar25) = _DAT_;
          do {
            ppbVar26 = (byte **)0x0;
            *(int *)(&stack0x00000098 + lVar25) = (int)uVar49;
            if (((*(char *)(*(longlong *)(uVar51 + 0x38) + 0x29) != '\0') &&
                ((*(uint *)(lVar31 + 4) & 0x140) == 0)) &&
               (lVar34 = *(longlong *)(uVar51 + 0x288),
               *(ushort *)(uVar51 + 0x50) < *(ushort *)(lVar34 + 0x16))) {
              iVar19 = *(int *)(uVar51 + 0x50);
              *(longlong *)(&stack0x000000e8 + lVar25) = (longlong)iVar19;
              if (*(short *)(lVar34 + (0xfff - (longlong)iVar19) * 2) != 0) {
                *(int *)(&stack0x000007dc + lVar25) = iVar19;
                if (*(char *)(lVar34 + 2) < '\0') {
                  pbVar48 = (byte *)(lVar34 + 0x60);
                  if ((*(short *)(&stack0x000007a8 + lVar25) == 0) ||
                     (ppbVar26 = *(byte ***)(&stack0x000007b8 + lVar25), ppbVar26 == (byte **)0x0))
                  {
                    *(undefined (*) [16])(&stack0x000007e0 + lVar25) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x000007f0 + lVar25) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000800 + lVar25) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000810 + lVar25) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000820 + lVar25) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000830 + lVar25) = ZEXT816(0);
                    *(undefined (*) [16])(&stack0x00000840 + lVar25) = ZEXT816(0);
                    *(undefined8 *)(&stack0x00000850 + lVar25) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100d55;
                    ppbVar26 = (byte **)func_0x(&stack0x000007e0 + lVar25);
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100d6d;
                  puVar29 = (undefined4 *)
                            func_0x(lVar34,&stack0x00000948 + lVar25,0,0);
                  if (pbVar48 == *ppbVar26) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100d81;
                    func_0x(puVar29,ppbVar26 + 0xc);
                  }
                  *ppbVar26 = pbVar48;
                  uVar3 = *(undefined2 *)(puVar29 + 2);
                  uVar5 = puVar29[1];
                  *(undefined4 *)(ppbVar26 + 0xc) = *puVar29;
                  *(undefined4 *)((longlong)ppbVar26 + 100) = uVar5;
                  *(undefined2 *)(ppbVar26 + 0xd) = uVar3;
                  *(undefined4 *)((longlong)ppbVar26 + 0x6c) = *(undefined4 *)(lVar34 + 0x20);
                  *(undefined2 *)(ppbVar26 + 0xe) = *(undefined2 *)(lVar34 + 0x24);
                  sVar40 = 0;
                  *(undefined2 *)((longlong)ppbVar26 + 0x72) = 0;
                  bVar13 = *pbVar48;
                  *(undefined4 *)(&stack0x000000f0 + lVar25) =
                       *(undefined4 *)((ulonglong)bVar13 * 6 + 0x1597010);
                  sVar16 = *(short *)((ulonglong)bVar13 * 6 + 0x1597014);
                  *(short *)(&stack0x00000040 + lVar25) = sVar16;
                  *(undefined2 *)(ppbVar26 + 2) = 0xffff;
                  ppbVar26[3] = (byte *)0x0;
                  uVar20 = 0;
                  *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                  *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
                  ppbVar26[7] = (byte *)0x0;
                  ppbVar26[4] = (byte *)0x0;
                  ppbVar26[9] = (byte *)0x0;
                  ppbVar26[10] = (byte *)0x0;
                  *(undefined2 *)(ppbVar26 + 0xb) = 0;
                  if ((**ppbVar26 & 2) != 0) {
                    pbVar53 = pbVar48 + sVar16;
                    if ((*pbVar53 & 1) == 0) {
                      *(undefined2 *)(ppbVar26 + 2) = 0;
                      ppbVar26[3] = pbVar53;
                      *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                      *(undefined4 *)((longlong)ppbVar26 + 0x36) = 0;
                      switch(*pbVar53 & 0xe) {
                      default:
                        uVar20 = (uint)*(ushort *)(pbVar53 + 2);
                        if (0x1f9d < *(ushort *)(pbVar53 + 2) - 1) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101013;
                          func_0x(pbVar53,6);
                        }
                        break;
                      case 4:
                        uVar20 = 9;
                        break;
                      case 6:
                      case 10:
                        break;
                      case 0xe:
                        uVar20 = 1;
                      }
                      *(uint *)(ppbVar26 + 4) = uVar20;
                      *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
                      *puVar1 = *puVar1;
                      *(undefined4 *)(&stack0x00000048 + lVar25) =
                           *(undefined4 *)(&stack0x00000048 + lVar25);
                    }
                    else {
                      *(undefined2 *)(ppbVar26 + 2) = 1;
                      *(undefined4 *)(&stack0x00000048 + lVar25) = uVar24;
                      uVar20 = *(uint *)(&stack0x00000098 + lVar25);
                      *puVar1 = uVar20;
                      ppbVar26[3] = pbVar53;
                      bVar13 = *pbVar53;
                      switch(bVar13 & 0x1c) {
                      default:
                        if ((char)pbVar53[1] < '\0') {
                          uVar17 = *(ushort *)(pbVar53 + 1);
                          *(ushort *)((longlong)ppbVar26 + 0x12) = uVar17;
                          sVar16 = 3;
                          uVar17 = (uVar17 & 0x7f) << 8 | uVar17 >> 8;
                        }
                        else {
                          sVar16 = 2;
                          uVar17 = (ushort)pbVar53[1];
                        }
                        *(ushort *)((longlong)ppbVar26 + 0x12) = uVar17;
                        *(short *)(ppbVar26 + 5) = sVar16;
                        *(short *)((longlong)ppbVar26 + 0x2c) =
                             (short)(*(ushort *)((longlong)ppbVar26 + 0x12) + 1 >> 1) + sVar16;
                        if (0x1e < *(ushort *)((longlong)ppbVar26 + 0x12)) {
                          iVar19 = *(ushort *)((longlong)ppbVar26 + 0x12) - 1;
                          sVar40 = ((short)(iVar19 / 0x1e) + (short)(iVar19 >> 0x1f)) -
                                   (short)((longlong)iVar19 * 0x88888889 >> 0x3f);
                        }
                        *(short *)((longlong)ppbVar26 + 0x2a) = sVar40;
                        *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                        *(undefined4 *)(ppbVar26 + 8) = 0;
                        *puVar1 = uVar20;
                        *(undefined4 *)(&stack0x00000048 + lVar25) = uVar24;
                        ppbVar26[7] = (byte *)0x0;
                        ppbVar26[4] = (byte *)0x0;
                        break;
                      case 4:
                        if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100f1f;
                          func_0x((longlong)ppbVar26 + 0x12);
                          ppbVar26[3] = pbVar53;
                          *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0xf;
                          *(undefined4 *)(ppbVar26 + 8) = 0;
                          *(undefined4 *)(ppbVar26 + 8) = 1;
                          ppbVar26[7] = (byte *)0x0;
                          ppbVar26[4] = (byte *)0x0;
                        }
                        else {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100f53;
                          func_0x((longlong)ppbVar26 + 0x12);
                          ppbVar26[3] = pbVar53;
                          *(undefined4 *)((longlong)ppbVar26 + 0x14) = 1;
                          *puVar1 = *(uint *)(&stack0x00000098 + lVar25);
                          *(undefined4 *)(&stack0x00000048 + lVar25) = uVar24;
                          *(undefined4 *)(ppbVar26 + 8) = 0;
                          ppbVar26[7] = (byte *)0x0;
                          ppbVar26[4] = (byte *)0x0;
                        }
                        break;
                      case 8:
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100ef1;
                        func_0x((longlong)ppbVar26 + 0x12);
                        ppbVar26[3] = pbVar53;
                        *(undefined4 *)((longlong)ppbVar26 + 0x14) = 9;
                        *(undefined4 *)(ppbVar26 + 8) = 0;
                        *puVar1 = *(uint *)(&stack0x00000098 + lVar25);
                        *(undefined4 *)(&stack0x00000048 + lVar25) = uVar24;
                        ppbVar26[7] = (byte *)0x0;
                        ppbVar26[4] = (byte *)0x0;
                      }
                    }
                    sVar16 = *(short *)(&stack0x00000040 + lVar25);
                  }
                  if ((**ppbVar26 & 4) != 0) {
                    if (*(short *)(&stack0x000000f2 + lVar25) == 0) {
                      uVar49 = (ulonglong)sVar16;
                    }
                    else {
                      uVar49 = (ulonglong)
                               *(ushort *)
                                (lVar34 + 0x61 + (longlong)*(short *)(&stack0x000000f2 + lVar25) * 2
                                );
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10109c;
                    func_0x(ppbVar26 + 9,pbVar48 + uVar49);
                  }
                  pbVar48 = ppbVar26[1];
                  if (pbVar48 != (byte *)0x0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1010b0;
                    func_0x(pbVar48,ppbVar26);
                  }
                  uVar49 = (ulonglong)*puVar1;
                }
                uVar20 = (uint)*(ushort *)(lVar34 + 0xe);
                pbVar48 = (byte *)((ulonglong)
                                   *(ushort *)
                                    (lVar34 + (0xfff - *(longlong *)(&stack0x000000e8 + lVar25)) * 2
                                    ) + lVar34);
                bVar13 = *pbVar48;
                *(byte **)(&stack0x000007b0 + lVar25) = pbVar48;
                if ((bVar13 & 1) == 0) {
                  *(undefined2 *)(&stack0x000007a8 + lVar25) = 0;
                  *(undefined4 *)(&stack0x000007ac + lVar25) = 0;
                  *(undefined4 *)(&stack0x000007ce + lVar25) = 0;
                  switch(*pbVar48 & 0xe) {
                  default:
                    uVar20 = (uint)*(ushort *)(pbVar48 + 2);
                    if (0x1f9d < *(ushort *)(pbVar48 + 2) - 1) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101304;
                      func_0x(pbVar48,6);
                    }
                    break;
                  case 4:
                    uVar20 = 9;
                    break;
                  case 6:
                  case 10:
                    break;
                  case 0xe:
                    uVar20 = 1;
                  }
                  *(uint *)(&stack0x000007b8 + lVar25) = uVar20;
                  *(longlong *)(&stack0x000007c6 + lVar25) = lVar34 + 0x2000;
                }
                else {
                  *(undefined2 *)(&stack0x000007a8 + lVar25) = 1;
                  bVar13 = *pbVar48;
                  switch(bVar13 & 0x1c) {
                  default:
                    if ((char)pbVar48[1] < '\0') {
                      uVar17 = (*(ushort *)(pbVar48 + 1) & 0x7f) << 8 |
                               *(ushort *)(pbVar48 + 1) >> 8;
                      *(ushort *)(&stack0x000007aa + lVar25) = uVar17;
                      sVar16 = 3;
                      *(undefined2 *)(&stack0x000007c0 + lVar25) = 3;
                    }
                    else {
                      uVar17 = (ushort)pbVar48[1];
                      *(ushort *)(&stack0x000007aa + lVar25) = uVar17;
                      sVar16 = 2;
                      *(undefined2 *)(&stack0x000007c0 + lVar25) = 2;
                    }
                    *(short *)(&stack0x000007c4 + lVar25) = (short)(uVar17 + 1 >> 1) + sVar16;
                    if (uVar17 < 0x1f) {
                      *(undefined2 *)(&stack0x000007c2 + lVar25) = 0;
                      *(undefined4 *)(&stack0x000007ac + lVar25) = 0;
                      *(undefined4 *)(&stack0x000007d8 + lVar25) = 0;
                    }
                    else {
                      iVar19 = uVar17 - 1;
                      *(short *)(&stack0x000007c2 + lVar25) =
                           ((short)(iVar19 / 0x1e) + (short)(iVar19 >> 0x1f)) -
                           (short)((longlong)iVar19 * 0x88888889 >> 0x3f);
                      *(undefined4 *)(&stack0x000007ac + lVar25) = 0;
                      *(undefined4 *)(&stack0x000007d8 + lVar25) = 0;
                    }
code_r0x0010129b:
                    *(longlong *)(&stack0x000007d0 + lVar25) = lVar34 + 0x2000;
                    *(byte ***)(&stack0x000007b8 + lVar25) = ppbVar26;
                    break;
                  case 4:
                    if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10121f;
                      func_0x(&stack0x000007aa + lVar25);
                      *(byte **)(&stack0x000007b0 + lVar25) = pbVar48;
                      *(undefined4 *)(&stack0x000007ac + lVar25) = 0xf;
                      *(undefined4 *)(&stack0x000007d8 + lVar25) = 1;
                      goto code_r0x0010129b;
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101244;
                    func_0x(&stack0x000007aa + lVar25);
                    *(byte **)(&stack0x000007b0 + lVar25) = pbVar48;
                    *(undefined4 *)(&stack0x000007ac + lVar25) = 1;
                    *(undefined4 *)(&stack0x000007d8 + lVar25) = 0;
                    *(longlong *)(&stack0x000007d0 + lVar25) = lVar34 + 0x2000;
                    *(byte ***)(&stack0x000007b8 + lVar25) = ppbVar26;
                    break;
                  case 8:
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1011d2;
                    func_0x(&stack0x000007aa + lVar25);
                    *(byte **)(&stack0x000007b0 + lVar25) = pbVar48;
                    *(undefined4 *)(&stack0x000007ac + lVar25) = 9;
                    *(undefined4 *)(&stack0x000007d8 + lVar25) = 0;
                    *(longlong *)(&stack0x000007d0 + lVar25) = lVar34 + 0x2000;
                    *(byte ***)(&stack0x000007b8 + lVar25) = ppbVar26;
                  }
                }
                if (*(short *)(&stack0x000007a8 + lVar25) == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101372;
                  func_0x();
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101379;
                  func_0x(&stack0x000007aa + lVar25,&stack0x00000148 + lVar25);
                }
                iVar19 = *(int *)(&stack0x00000148 + lVar25);
                *(int *)(&stack0x000000c8 + lVar25) = iVar19;
                sVar16 = *(short *)(&stack0x0000014c + lVar25);
                *(short *)(&stack0x000000cc + lVar25) = sVar16;
                if ((sVar16 != *(short *)(&stack0x00000090 + lVar25)) ||
                   (iVar19 != *(int *)(&stack0x000000c0 + lVar25))) {
                  *(int *)(&stack0x00000188 + lVar25) = iVar19;
                  *(short *)(&stack0x0000018c + lVar25) = sVar16;
                  lVar35 = *(longlong *)(&stack0x00000108 + lVar25);
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1013c4;
                  iVar19 = func_0x(lVar35,&stack0x00000188 + lVar25);
                  if (iVar19 != 3) {
                    *(undefined4 *)(&stack0x000000c0 + lVar25) =
                         *(undefined4 *)(&stack0x000000c8 + lVar25);
                    *(undefined2 *)(&stack0x00000090 + lVar25) =
                         *(undefined2 *)(&stack0x000000cc + lVar25);
                    uVar24 = *(undefined4 *)(&stack0x00000048 + lVar25);
                    lVar31 = *(longlong *)(&stack0x00000100 + lVar25);
                    goto LAB_;
                  }
                  iVar19 = 1;
                  uVar59 = *(ulonglong *)(&stack0x000000b8 + lVar25);
                  goto code_r0x001008ff;
                }
                uVar24 = *(undefined4 *)(&stack0x00000048 + lVar25);
                lVar31 = *(longlong *)(&stack0x00000100 + lVar25);
              }
              lVar35 = *(longlong *)(&stack0x00000108 + lVar25);
            }
LAB_:
            *(undefined4 *)(&stack0x00000040 + lVar25) = uVar24;
            *(int *)(&stack0x00000098 + lVar25) = (int)uVar49;
            if ((&stack0x0000003c)[lVar25] != '\0') goto LAB_;
            (&stack0x00000946)[lVar25] = 1;
            lVar34 = **(longlong **)(uVar51 + 0x58);
            uVar5 = *(undefined4 *)(uVar51 + 0x50);
            *(undefined4 *)(&stack0x000001a0 + lVar25) = *(undefined4 *)(lVar34 + 0x20);
            *(undefined2 *)(&stack0x000001a4 + lVar25) = *(undefined2 *)(lVar34 + 0x24);
            *(short *)(&stack0x000001a6 + lVar25) = (short)uVar5;
            uVar3 = *(undefined2 *)(*(longlong *)(lVar35 + 0x30) + 0x6b8);
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101461;
            func_0x(&stack0x00000938 + lVar25,uVar3,&stack0x000001a0 + lVar25);
            *(undefined4 *)((longlong)&uStackX_20 + lVar25 + -0x20) = 1;
            *(undefined4 *)(&stack0xfffffffffffffff8 + lVar25) = 0;
            *(undefined4 *)(&stack0xfffffffffffffff0 + lVar25) = 1;
            *(ulonglong *)(&stack0xffffffffffffffe8 + lVar25) = uVar51 + 0x90;
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101492;
            iVar21 = func_0x(plVar58,&stack0x00000938 + lVar25);
            iVar19 = 1;
            if (iVar21 < 0) {
              *(undefined4 *)(uVar51 + 0xf0) = 3;
              *(undefined4 *)(uVar51 + 0x50) = 0xffffffff;
              uVar59 = *(ulonglong *)(&stack0x000000b8 + lVar25);
              goto code_r0x001008ff;
            }
            if (iVar21 != 1) goto LAB_;
            (&stack0x0000003c)[lVar25] = 1;
          } while( true );
        }
        if (iVar19 == 0) goto LAB_;
        goto code_r0x001008ff;
      }
      if (*(int *)(uVar59 + 0x370) == 4) {
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x107f20;
        func_0x(uVar59 + 0x2b0);
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x107f2d;
      func_0x(plVar58,0,0);
      *(uint *)(uVar59 + 0x634) = *(uint *)(uVar59 + 0x634) | 1;
      goto LAB_;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10065c;
    func_0x(plVar58,1);
    if (*(int *)(uVar51 + 0xf0) == 3) goto LAB_;
    *(uint *)(uVar51 + 0x634) = *(uint *)(uVar51 + 0x634) | 1;
  }
  goto LAB_;
LAB_:
  *(undefined4 *)(uVar59 + 0xf0) = 4;
  lVar31 = *(longlong *)(lVar31 + 0x30);
  if (*(longlong *)(lVar31 + 0x1b28) != 0) {
    uVar20 = *(uint *)(*(longlong *)(uVar59 + 0x100) + 0x10);
    if (((((uVar20 & 1) == 0) || ((uVar20 & 0x40) != 0)) || (*(char *)(lVar31 + 0x1cd2) == '\0')) ||
       (*(char *)(lVar31 + 0x2050) != '\0')) {
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102ead;
      cVar12 = func_0x(lVar35);
      if (cVar12 != '\0') goto LAB_;
    }
    lVar31 = *(longlong *)(uVar59 + 0x288);
    if (*(ushort *)(uVar59 + 0x50) < *(ushort *)(lVar31 + 0x16)) {
      lVar35 = 0xfff - (longlong)*(int *)(uVar59 + 0x50);
      if (*(short *)(lVar31 + lVar35 * 2) != 0) {
        *(int *)(&stack0x0000088c + lVar25) = *(int *)(uVar59 + 0x50);
        if (*(char *)(lVar31 + 2) < '\0') {
          pbVar48 = (byte *)(lVar31 + 0x60);
          if ((*(short *)(&stack0x00000858 + lVar25) == 0) ||
             (ppbVar26 = *(byte ***)(&stack0x00000868 + lVar25), ppbVar26 == (byte **)0x0)) {
            *(undefined (*) [16])(&stack0x00000890 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000008a0 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000008b0 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000008c0 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000008d0 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000008e0 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000008f0 + lVar25) = ZEXT816(0);
            *(undefined8 *)(&stack0x00000900 + lVar25) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102f65;
            ppbVar26 = (byte **)func_0x(&stack0x00000890 + lVar25);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102f7d;
          puVar29 = (undefined4 *)func_0x(lVar31,&stack0x00000978 + lVar25,0);
          if (pbVar48 == *ppbVar26) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102f91;
            func_0x(puVar29,ppbVar26 + 0xc);
          }
          *ppbVar26 = pbVar48;
          uVar3 = *(undefined2 *)(puVar29 + 2);
          uVar24 = puVar29[1];
          *(undefined4 *)(ppbVar26 + 0xc) = *puVar29;
          *(undefined4 *)((longlong)ppbVar26 + 100) = uVar24;
          *(undefined2 *)(ppbVar26 + 0xd) = uVar3;
          *(undefined4 *)((longlong)ppbVar26 + 0x6c) = *(undefined4 *)(lVar31 + 0x20);
          *(undefined2 *)(ppbVar26 + 0xe) = *(undefined2 *)(lVar31 + 0x24);
          *(undefined2 *)((longlong)ppbVar26 + 0x72) = 0;
          bVar13 = *pbVar48;
          *(undefined4 *)(&stack0x000000f0 + lVar25) =
               *(undefined4 *)((ulonglong)bVar13 * 6 + 0x1597010);
          sVar16 = *(short *)((ulonglong)bVar13 * 6 + 0x1597014);
          *(short *)(&stack0x00000040 + lVar25) = sVar16;
          *(undefined2 *)(ppbVar26 + 2) = 0xffff;
          ppbVar26[3] = (byte *)0x0;
          uVar20 = 0;
          *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
          ppbVar26[7] = (byte *)0x0;
          ppbVar26[4] = (byte *)0x0;
          ppbVar26[9] = (byte *)0x0;
          ppbVar26[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar26 + 0xb) = 0;
          if ((**ppbVar26 & 2) != 0) {
            pbVar53 = pbVar48 + sVar16;
            if ((*pbVar53 & 1) == 0) {
              *(undefined2 *)(ppbVar26 + 2) = 0;
              *puVar1 = 0;
              ppbVar26[3] = pbVar53;
              *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar26 + 0x36) = 0;
              switch(*pbVar53 & 0xe) {
              default:
                uVar17 = *(ushort *)(pbVar53 + 2);
                *puVar1 = (uint)uVar17;
                if (uVar17 - 1 < 0x1f9e) {
                  uVar20 = *puVar1;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103224;
                  func_0x(pbVar53,6);
                  uVar20 = *puVar1;
                  sVar16 = *(short *)(&stack0x00000040 + lVar25);
                }
                break;
              case 4:
                uVar20 = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar20 = 1;
              }
              *(uint *)(ppbVar26 + 4) = uVar20;
              *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
            }
            else {
              *(undefined2 *)(ppbVar26 + 2) = 1;
              ppbVar26[3] = pbVar53;
              bVar13 = *pbVar53;
              switch(bVar13 & 0x1c) {
              default:
                if ((char)pbVar53[1] < '\0') {
                  uVar17 = *(ushort *)(pbVar53 + 1);
                  *(ushort *)((longlong)ppbVar26 + 0x12) = uVar17;
                  sVar40 = 3;
                  uVar17 = (uVar17 & 0x7f) << 8 | uVar17 >> 8;
                }
                else {
                  sVar40 = 2;
                  uVar17 = (ushort)pbVar53[1];
                }
                *(ushort *)((longlong)ppbVar26 + 0x12) = uVar17;
                *(short *)(ppbVar26 + 5) = sVar40;
                *(short *)((longlong)ppbVar26 + 0x2c) =
                     (short)(*(ushort *)((longlong)ppbVar26 + 0x12) + 1 >> 1) + sVar40;
                if (*(ushort *)((longlong)ppbVar26 + 0x12) < 0x1f) {
                  *(undefined2 *)((longlong)ppbVar26 + 0x2a) = 0;
                  *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                  *(undefined4 *)(ppbVar26 + 8) = 0;
                  ppbVar26[7] = (byte *)0x0;
                  ppbVar26[4] = (byte *)0x0;
                }
                else {
                  iVar19 = *(ushort *)((longlong)ppbVar26 + 0x12) - 1;
                  *(short *)((longlong)ppbVar26 + 0x2a) =
                       ((short)(iVar19 / 0x1e) + (short)(iVar19 >> 0x1f)) -
                       (short)((longlong)iVar19 * 0x88888889 >> 0x3f);
                  *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                  *(undefined4 *)(ppbVar26 + 8) = 0;
                  ppbVar26[7] = (byte *)0x0;
                  ppbVar26[4] = (byte *)0x0;
                }
                break;
              case 4:
                if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103142;
                  func_0x((longlong)ppbVar26 + 0x12);
                  ppbVar26[3] = pbVar53;
                  *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0xf;
                  *(undefined4 *)(ppbVar26 + 8) = 0;
                  *(undefined4 *)(ppbVar26 + 8) = 1;
                  sVar16 = *(short *)(&stack0x00000040 + lVar25);
                  ppbVar26[7] = (byte *)0x0;
                  ppbVar26[4] = (byte *)0x0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103177;
                  func_0x((longlong)ppbVar26 + 0x12);
                  ppbVar26[3] = pbVar53;
                  *(undefined4 *)((longlong)ppbVar26 + 0x14) = 1;
                  *(undefined4 *)(ppbVar26 + 8) = 0;
                  sVar16 = *(short *)(&stack0x00000040 + lVar25);
                  ppbVar26[7] = (byte *)0x0;
                  ppbVar26[4] = (byte *)0x0;
                }
                break;
              case 8:
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103107;
                func_0x((longlong)ppbVar26 + 0x12);
                ppbVar26[3] = pbVar53;
                *(undefined4 *)((longlong)ppbVar26 + 0x14) = 9;
                *(undefined4 *)(ppbVar26 + 8) = 0;
                sVar16 = *(short *)(&stack0x00000040 + lVar25);
                ppbVar26[7] = (byte *)0x0;
                ppbVar26[4] = (byte *)0x0;
              }
            }
          }
          if ((**ppbVar26 & 4) != 0) {
            uVar49 = (ulonglong)sVar16;
            if (*(short *)(&stack0x000000f2 + lVar25) != 0) {
              uVar49 = (ulonglong)
                       *(ushort *)
                        (lVar31 + 0x61 + (longlong)*(short *)(&stack0x000000f2 + lVar25) * 2);
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1032b1;
            func_0x(ppbVar26 + 9,pbVar48 + uVar49);
          }
          pbVar48 = ppbVar26[1];
          if (pbVar48 != (byte *)0x0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1032c5;
            func_0x(pbVar48,ppbVar26);
          }
        }
        else {
          ppbVar26 = (byte **)0x0;
        }
        uVar20 = (uint)*(ushort *)(lVar31 + 0xe);
        pbVar48 = (byte *)((ulonglong)*(ushort *)(lVar31 + lVar35 * 2) + lVar31);
        bVar13 = *pbVar48;
        *(byte **)(&stack0x00000860 + lVar25) = pbVar48;
        if ((bVar13 & 1) == 0) {
          *(undefined2 *)(&stack0x00000858 + lVar25) = 0;
          *(undefined4 *)(&stack0x0000085c + lVar25) = 0;
          *(undefined4 *)(&stack0x0000087e + lVar25) = 0;
          switch(*pbVar48 & 0xe) {
          default:
            uVar20 = (uint)*(ushort *)(pbVar48 + 2);
            if (0x1f9d < *(ushort *)(pbVar48 + 2) - 1) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103549;
              func_0x(pbVar48,6);
            }
            break;
          case 4:
            uVar20 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar20 = 1;
          }
          *(uint *)(&stack0x00000868 + lVar25) = uVar20;
          *(longlong *)(&stack0x00000876 + lVar25) = lVar31 + 0x2000;
        }
        else {
          *(undefined2 *)(&stack0x00000858 + lVar25) = 1;
          bVar13 = *pbVar48;
          switch(bVar13 & 0x1c) {
          default:
            if ((char)pbVar48[1] < '\0') {
              uVar17 = (*(ushort *)(pbVar48 + 1) & 0x7f) << 8 | *(ushort *)(pbVar48 + 1) >> 8;
              *(ushort *)(&stack0x0000085a + lVar25) = uVar17;
              sVar16 = 3;
              *(undefined2 *)(&stack0x00000870 + lVar25) = 3;
            }
            else {
              uVar17 = (ushort)pbVar48[1];
              *(ushort *)(&stack0x0000085a + lVar25) = uVar17;
              sVar16 = 2;
              *(undefined2 *)(&stack0x00000870 + lVar25) = 2;
            }
            *(short *)(&stack0x00000874 + lVar25) = (short)(uVar17 + 1 >> 1) + sVar16;
            if (uVar17 < 0x1f) {
              *(undefined2 *)(&stack0x00000872 + lVar25) = 0;
              *(undefined4 *)(&stack0x0000085c + lVar25) = 0;
              *(undefined4 *)(&stack0x00000888 + lVar25) = 0;
              *(longlong *)(&stack0x00000880 + lVar25) = lVar31 + 0x2000;
              *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
            }
            else {
              iVar19 = uVar17 - 1;
              *(short *)(&stack0x00000872 + lVar25) =
                   ((short)(iVar19 / 0x1e) + (short)(iVar19 >> 0x1f)) -
                   (short)((longlong)iVar19 * 0x88888889 >> 0x3f);
              *(undefined4 *)(&stack0x0000085c + lVar25) = 0;
              *(undefined4 *)(&stack0x00000888 + lVar25) = 0;
              *(longlong *)(&stack0x00000880 + lVar25) = lVar31 + 0x2000;
              *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
            }
            break;
          case 4:
            if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10344e;
              func_0x(&stack0x0000085a + lVar25);
              *(byte **)(&stack0x00000860 + lVar25) = pbVar48;
              *(undefined4 *)(&stack0x0000085c + lVar25) = 0xf;
              *(undefined4 *)(&stack0x00000888 + lVar25) = 1;
              *(longlong *)(&stack0x00000880 + lVar25) = lVar31 + 0x2000;
              *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10348b;
              func_0x(&stack0x0000085a + lVar25);
              *(byte **)(&stack0x00000860 + lVar25) = pbVar48;
              *(undefined4 *)(&stack0x0000085c + lVar25) = 1;
              *(undefined4 *)(&stack0x00000888 + lVar25) = 0;
              *(longlong *)(&stack0x00000880 + lVar25) = lVar31 + 0x2000;
              *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
            }
            break;
          case 8:
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103401;
            func_0x(&stack0x0000085a + lVar25);
            *(byte **)(&stack0x00000860 + lVar25) = pbVar48;
            *(undefined4 *)(&stack0x0000085c + lVar25) = 9;
            *(undefined4 *)(&stack0x00000888 + lVar25) = 0;
            *(longlong *)(&stack0x00000880 + lVar25) = lVar31 + 0x2000;
            *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
          }
        }
        if (*(short *)(&stack0x00000858 + lVar25) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1035b5;
          func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1035bc;
          func_0x(&stack0x0000085a + lVar25,&stack0x00000154 + lVar25);
        }
        *(undefined4 *)(&stack0x000000d0 + lVar25) = *(undefined4 *)(&stack0x00000154 + lVar25);
        *(undefined2 *)(&stack0x000000d4 + lVar25) = *(undefined2 *)(&stack0x00000158 + lVar25);
        *(undefined4 *)(&stack0x00000048 + lVar25) = *(undefined4 *)(&stack0x00000154 + lVar25);
        *(undefined2 *)(&stack0x0000004c + lVar25) = *(undefined2 *)(&stack0x00000158 + lVar25);
        lVar31 = *(longlong *)(&stack0x00000108 + lVar25);
        uVar27 = *(undefined8 *)(lVar31 + 0x30);
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1035f1;
        cVar12 = func_0x(uVar27,&stack0x00000048 + lVar25);
        if (cVar12 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103606;
          cVar12 = func_0x(lVar31,3,&stack0x000000d0 + lVar25);
          if (cVar12 == '\0') {
LAB_:
            *(undefined4 *)(uVar59 + 0xf0) = 3;
            *(undefined4 *)(uVar59 + 0x50) = 0xffffffff;
code_r0x0010371d:
            *(uint *)(*(longlong *)(&stack0x000000b8 + lVar25) + 0x634) =
                 *(uint *)(*(longlong *)(&stack0x000000b8 + lVar25) + 0x634) | 1;
            goto LAB_;
          }
        }
      }
    }
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10361b;
  func_0x(plVar58,1);
  uVar49 = (ulonglong)*(uint *)(uVar59 + 0x268);
  iVar19 = 0;
  uVar59 = *(ulonglong *)(&stack0x000000b8 + lVar25);
  iVar21 = *(int *)(&stack0x000000ac + lVar25);
  iVar22 = *(int *)(&stack0x000000c0 + lVar25);
LAB_:
  if ((int)uVar49 != 3) goto LAB_;
  bVar61 = false;
  if (*(char *)(*(longlong *)(uVar59 + 0x28) + 0x29) == '\0') {
    lVar31 = *(longlong *)(*(longlong *)(uVar59 + 0x20) + 0x18);
    if ((*(int *)(lVar31 + 0x1c) != 0) &&
       ((((*(char *)(lVar31 + 1) != '\x01' && (*(char *)(lVar31 + 1) != '\b')) ||
         (*(char *)(lVar31 + 2) != '\0')) || (*(char *)(lVar31 + 3) != '\0')))) {
      *(undefined8 *)(&stack0x000000d8 + lVar25) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103754;
      func_0x(uVar59,1,0,&stack0x000000d8 + lVar25);
LAB_:
      if (*(longlong *)(uVar59 + 0x2d8) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103773;
        func_0x(uVar59 + 0x2b0,0);
      }
      if (*(int *)(uVar59 + 0x4f0) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10378b;
        func_0x(uVar59 + 0x2b0,1);
      }
LAB_:
      *(uint *)(uVar59 + 0x634) = *(uint *)(uVar59 + 0x634) | 1;
      if (iVar19 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1037ad;
        uVar27 = func_0x(uVar59,1,0);
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1037b5;
        puVar28 = (undefined8 *)func_0x(uVar27);
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1037cb;
        (*_DAT_)(6,0x55,0x10,1);
        if (puVar28 == (undefined8 *)0x0) {
          *(undefined8 *)(&stack0x00000160 + lVar25) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1037eb;
          puVar29 = (undefined4 *)(*_DAT_)();
          *puVar29 = 0x16;
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1037f8;
          (*_DAT_)();
          uVar27 = *(undefined8 *)(&stack0x00000160 + lVar25);
        }
        else {
          uVar27 = *puVar28;
          *(undefined8 *)(&stack0x00000160 + lVar25) = uVar27;
        }
        piVar7 = *(int **)(&stack0x00000110 + lVar25);
        if (((*piVar7 != (int)uVar27) ||
            (*(short *)(piVar7 + 1) != *(short *)(&stack0x00000164 + lVar25))) ||
           (*(short *)((longlong)piVar7 + 6) != *(short *)(&stack0x00000166 + lVar25))) {
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103852;
          (*_DAT_)(1,0x194e550,0x1921b58,0x13b1);
        }
LAB_:
        iVar19 = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10386a;
        psVar30 = (short *)func_0x(uVar59,1,0);
        *(short **)(&stack0x000000e8 + lVar25) = psVar30;
        sVar16 = *psVar30;
        *(short *)(&stack0x00000058 + lVar25) = sVar16;
        if (sVar16 == 0) {
          puVar42 = (ushort *)(psVar30 + 1);
          if (*(int *)(psVar30 + 2) == 0) {
            *puVar42 = 0;
            uVar20 = *(uint *)(psVar30 + 8);
            uVar49 = (ulonglong)uVar20;
            *(uint *)(psVar30 + 10) = uVar20;
            pbVar48 = *(byte **)(psVar30 + 4);
            bVar13 = *pbVar48;
            pbVar53 = pbVar48;
            if ((bVar13 & 0x10) != 0) {
              uVar20 = uVar20 + (*(ushort *)(pbVar48 + uVar49) + 7 >> 3) + 2;
              uVar49 = (ulonglong)uVar20;
              *(uint *)(psVar30 + 10) = uVar20;
              bVar13 = *pbVar48;
              pbVar53 = *(byte **)(psVar30 + 4);
            }
            psVar50 = psVar30;
            if ((bVar13 & 0x20) == 0) {
              *(int *)(psVar30 + 2) = (int)uVar49;
              psVar30[0xe] = 0;
              *(uint *)(psVar30 + 0xc) = uVar20;
            }
            else {
              puVar57 = (ushort *)(pbVar48 + uVar49);
              uVar17 = *puVar57;
              psVar30[0xe] = uVar17;
              if (uVar17 == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1038ff;
                cVar12 = func_0x(0x1ead7c0);
                if (cVar12 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103908;
                  lVar31 = func_0x();
                  if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103922;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10393e;
                      (*_DAT_)(0x22,0x44,0x15,0x3eb);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103964;
                      (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x80f);
                    }
                  }
                }
                uVar27 = *(undefined8 *)(psVar30 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103972;
                func_0x(uVar27,3);
                uVar17 = psVar30[0xe];
                uVar20 = *(uint *)(psVar30 + 10);
              }
              uVar20 = uVar20 + (uVar17 + 1) * 2;
              *(uint *)(psVar30 + 0xc) = uVar20;
              if (0x1f9e < uVar20) {
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1039a4;
                cVar12 = func_0x(0x1ead7c0);
                if (cVar12 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1039ad;
                  lVar31 = func_0x();
                  if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1039c7;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1039e3;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103a09;
                      (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x816);
                    }
                  }
                }
                uVar27 = *(undefined8 *)(psVar30 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103a17;
                func_0x(uVar27,4);
                uVar17 = psVar30[0xe];
                uVar20 = *(uint *)(psVar30 + 0xc);
              }
              uVar49 = (ulonglong)uVar17;
              uVar17 = puVar57[uVar49];
              *(uint *)(psVar30 + 2) = uVar17 & 0x7fff;
              if ((uVar17 & 0x7fff) < uVar20) {
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103a45;
                cVar12 = func_0x(0x1ead7c0);
                if (cVar12 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103a4e;
                  lVar31 = func_0x();
                  if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103a68;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103a84;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103aaa;
                      (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x81d);
                    }
                  }
                }
                uVar27 = *(undefined8 *)(psVar30 + 4);
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103ab8;
                func_0x(uVar27,4);
                uVar20 = *(uint *)(psVar30 + 0xc);
                uVar49 = (ulonglong)(ushort)psVar30[0xe];
              }
              puVar9 = puVar57;
              if ((short)uVar49 != 0) {
                do {
                  uVar47 = puVar9[1] & 0x7fff;
                  if ((uVar47 < uVar20) || (*(uint *)(psVar30 + 2) < uVar47)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103aff;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103b08;
                      lVar31 = func_0x();
                      if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103b22;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103b3e;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103b62;
                          (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x82a);
                        }
                      }
                    }
                    uVar27 = *(undefined8 *)(psVar30 + 4);
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103b70;
                    func_0x(uVar27,4);
                  }
                  iVar19 = iVar19 + 1;
                  uVar49 = (ulonglong)(ushort)psVar30[0xe];
                  puVar9 = puVar9 + 1;
                  uVar20 = uVar47;
                } while (iVar19 < (int)(uint)(ushort)psVar30[0xe]);
                psVar50 = *(short **)(&stack0x000000e8 + lVar25);
                uVar59 = *(ulonglong *)(&stack0x000000b8 + lVar25);
              }
              if ((short)puVar57[(ulonglong)((int)uVar49 - 1) + 1] < 0) {
                do {
                  lVar31 = *(longlong *)(psVar30 + 4);
                  uVar20 = *(ushort *)((ulonglong)*(uint *)(psVar30 + 10) + lVar31 + uVar49 * 2) &
                           0x7fff;
                  if ((int)uVar49 == 1) {
                    uVar47 = *(uint *)(psVar30 + 0xc);
                    uVar49 = (ulonglong)uVar47;
LAB_:
                    if ((uVar20 < (uint)uVar49) ||
                       (uVar52 = *(uint *)(psVar30 + 2), uVar52 < uVar20)) goto LAB_;
                  }
                  else {
                    uVar52 = *(ushort *)
                              ((ulonglong)*(uint *)(psVar30 + 10) + lVar31 + -2 + uVar49 * 2) &
                             0x7fff;
                    uVar49 = (ulonglong)uVar52;
                    uVar47 = *(uint *)(psVar50 + 0xc);
                    if (uVar47 <= uVar52) goto LAB_;
LAB_:
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103bfe;
                    func_0x(lVar31,7);
                    uVar47 = *(uint *)(psVar50 + 0xc);
                    uVar52 = *(uint *)(psVar50 + 2);
                    lVar31 = *(longlong *)(psVar50 + 4);
                  }
                  uVar46 = (uint)uVar49;
                  if ((uVar46 < uVar47) || (uVar52 < uVar46)) goto LAB_;
                  if (*(ushort *)(uVar49 + lVar31) == 5) {
                    *puVar42 = *puVar42 | 2;
                    psVar30[0xe] = psVar30[0xe] + -1;
                    psVar30[0x15] = (short)uVar49;
                    uVar51 = *(ulonglong *)(psVar30 + 4);
                    uVar17 = *(ushort *)((uVar49 & 0xffff) + 2 + uVar51);
                    uVar18 = psVar30[0x16] & 0xc7ff;
                    if ((uVar17 >> 0xe & 1) != 0) {
                      uVar18 = uVar17 & 0x3800 | uVar18;
                    }
                    psVar30[0x16] = uVar18;
                    uVar17 = (uVar18 ^ *(ushort *)((uVar49 & 0xffff) + 2 + uVar51)) & 0x7ff ^ uVar18
                    ;
                    psVar30[0x16] = uVar17;
                    uVar56 = (ulonglong)(ushort)psVar30[0x15];
                    uVar49 = (ulonglong)((uVar17 & 0x7ff) * 2) + 4 +
                             uVar56 + (uVar18 >> 0xb & 7) * 2 + uVar51;
                    if (uVar49 < uVar56 + uVar51) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103d0f;
                      func_0x(uVar56 + uVar51,0x19);
                      uVar17 = psVar30[0x16];
                      uVar56 = (ulonglong)(ushort)psVar30[0x15];
                      uVar51 = (ulonglong)*(uint *)(psVar30 + 4);
                    }
                    if (uVar20 - uVar46 <
                        (((uVar17 & 0x7ff) * 2 - (int)uVar56) - (int)uVar51) + (int)uVar49) {
                      lVar31 = *(longlong *)(psVar30 + 4);
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103d47;
                      func_0x(uVar56 + lVar31,0x19);
                      uVar17 = psVar30[0x16];
                    }
                    if ((uVar17 & 0x3800) != 0) {
                      puVar57 = (ushort *)
                                (*(longlong *)(psVar30 + 4) + (ulonglong)(ushort)psVar30[0x15] + 4);
                      iVar19 = 0;
                      if ((uVar17 & 0x3800) != 0) {
                        do {
                          if ((uVar17 & 0x7ff) < (*puVar57 & 0x7ff)) {
                            uVar17 = psVar30[0x15];
                            lVar31 = *(longlong *)(psVar30 + 4);
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103da7;
                            func_0x((ulonglong)uVar17 + lVar31,0x1a);
                            uVar17 = psVar30[0x16];
                          }
                          iVar19 = iVar19 + 1;
                          puVar57 = puVar57 + 1;
                        } while (iVar19 < (int)(uVar17 >> 0xb & 7));
                      }
                    }
                    goto LAB_;
                  }
                  if (*(ushort *)(uVar49 + lVar31) < 0x400) goto LAB_;
                  *puVar42 = *puVar42 | 1;
                  uVar17 = psVar30[0xe] - 1;
                  psVar30[0xe] = uVar17;
                  if (uVar17 == 0) goto LAB_;
                  uVar49 = (ulonglong)uVar17;
                } while ((short)puVar57[(ulonglong)(uVar17 - 1) + 1] < 0);
                pbVar53 = *(byte **)(psVar30 + 4);
                uVar49 = (ulonglong)*(uint *)(psVar30 + 2);
              }
              else {
LAB_:
                pbVar53 = *(byte **)(psVar30 + 4);
                uVar49 = (ulonglong)*(uint *)(psVar30 + 2);
              }
            }
            if ((*pbVar53 & 0x40) == 0) {
              *(undefined4 *)(psVar30 + 0x13) = 0;
              uVar20 = *(uint *)(psVar50 + 2);
            }
            else {
              *(int *)(psVar30 + 0x13) = (int)uVar49;
              *(int *)(psVar30 + 2) = (int)uVar49 + 0xe;
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103dee;
              uVar27 = func_0x(puVar42);
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103dfd;
              func_0x(uVar27,&stack0x000000e8 + lVar25);
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103e09;
              iVar19 = func_0x(&stack0x000000e8 + lVar25);
              *(int *)(psVar30 + 2) = *(int *)(psVar30 + 2) + iVar19;
              uVar20 = *(uint *)(psVar30 + 2);
              pbVar53 = *(byte **)(psVar30 + 4);
            }
            if ((*(byte **)(psVar30 + 0xf) != (byte *)0x0) &&
               (*(byte **)(psVar30 + 0xf) < pbVar53 + uVar20)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103e43;
              cVar12 = func_0x(0x1ead7c0);
              if (cVar12 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103e4c;
                lVar31 = func_0x();
                if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103e66;
                  cVar12 = func_0x(0x1ead7c0);
                  if (cVar12 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103e82;
                    (*_DAT_)(0x22,0x44,0x15,0x3fa);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103ea8;
                    (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x886);
                  }
                }
              }
              uVar27 = *(undefined8 *)(psVar30 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103eb6;
              func_0x(uVar27,0x12);
              uVar20 = *(uint *)(psVar50 + 2);
            }
            if ((uVar20 == 0) || (0x3f3c < uVar20)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103ed6;
              cVar12 = func_0x(0x1ead7c0);
              if (cVar12 != '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103edf;
                lVar31 = func_0x();
                if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103ef9;
                  cVar12 = func_0x(0x1ead7c0);
                  if (cVar12 == '\0') {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103f15;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
                  else {
                    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103f3b;
                    (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x88b);
                  }
                }
              }
              uVar27 = *(undefined8 *)(psVar30 + 4);
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103f49;
              func_0x(uVar27,5);
            }
          }
LAB_:
          *(undefined4 *)(&stack0x00000068 + lVar25) = *(undefined4 *)(psVar30 + 8);
          *(ushort *)(&stack0x0000005a + lVar25) = *puVar42;
          *(undefined4 *)(&stack0x0000005c + lVar25) = *(undefined4 *)(psVar30 + 2);
          *(short *)(&stack0x00000074 + lVar25) = psVar30[0xe];
          *(undefined4 *)(&stack0x0000006c + lVar25) = *(undefined4 *)(psVar30 + 10);
          *(undefined4 *)(&stack0x00000070 + lVar25) = *(undefined4 *)(psVar30 + 0xc);
          *(undefined4 *)(&stack0x0000007e + lVar25) = *(undefined4 *)(psVar30 + 0x13);
          uVar27 = *(undefined8 *)(psVar30 + 4);
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103fad;
          func_0x(&stack0x00000988 + lVar25,0x1f9e,uVar27);
          *(undefined **)(&stack0x00000060 + lVar25) = &stack0x00000988 + lVar25;
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103fc1;
          iVar19 = func_0x(&stack0x0000005a + lVar25);
          pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
          if (iVar19 != 0) {
            puVar42 = (ushort *)(pbVar48 + *(uint *)(&stack0x0000006c + lVar25));
            uVar20 = *puVar42 - 1;
            if (((&stack0x0000005a)[lVar25] & 1) == 0) {
              uVar20 = (uint)*puVar42;
            }
            uVar47 = *(uint *)(&stack0x00000070 + lVar25);
            if (uVar20 != 1) {
              uVar47 = puVar42[(longlong)(int)uVar20 + -1] & 0x7fff;
            }
            uVar20 = puVar42[(int)uVar20] & 0x7fff;
            if (((uVar47 < *(uint *)(&stack0x00000070 + lVar25)) || (uVar20 < uVar47)) ||
               (*(uint *)(&stack0x0000005c + lVar25) < uVar20)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104021;
              func_0x(pbVar48,7);
              pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
            }
            uVar49 = (ulonglong)(uVar47 & 0xffff);
            *(short *)(&stack0x00000082 + lVar25) = (short)uVar47;
            pbVar53 = pbVar48 + uVar49;
            uVar17 = *(ushort *)(&stack0x00000084 + lVar25);
            if ((*(ushort *)(pbVar53 + 2) >> 0xe & 1) == 0) {
              uVar17 = uVar17 & 0xc7ff;
            }
            else {
              uVar17 = uVar17 ^ (uVar17 ^ *(ushort *)(pbVar53 + 2)) & 0x3800;
            }
            *(ushort *)(&stack0x00000084 + lVar25) = uVar17;
            uVar18 = (uVar17 ^ *(ushort *)(pbVar53 + 2)) & 0x7ff ^ uVar17;
            *(ushort *)(&stack0x00000084 + lVar25) = uVar18;
            pbVar44 = pbVar48 + (ulonglong)((uVar18 & 0x7ff) * 2) + 4 +
                                uVar49 + (uVar17 >> 0xb & 7) * 2;
            if (pbVar44 < pbVar53) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1040b8;
              func_0x(pbVar53,0x19);
              uVar18 = *(ushort *)(&stack0x00000084 + lVar25);
              uVar49 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar25);
              pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
            }
            if (uVar20 - uVar47 <
                (((*(uint *)(&stack0x00000084 + lVar25) & 0x7ff) * 2 - (int)uVar49) -
                *(int *)(&stack0x00000060 + lVar25)) + (int)pbVar44) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1040ee;
              func_0x(pbVar48 + uVar49,0x19);
              uVar18 = *(ushort *)(&stack0x00000084 + lVar25);
              uVar49 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar25);
              pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
            }
            iVar19 = 0;
            if (((uVar18 & 0x3800) != 0) &&
               (puVar42 = (ushort *)(pbVar48 + uVar49 + 4), (uVar18 & 0x3800) != 0)) {
              do {
                if ((uVar18 & 0x7ff) < (*puVar42 & 0x7ff)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104155;
                  func_0x(pbVar48 + uVar49,0x1a);
                  uVar18 = *(ushort *)(&stack0x00000084 + lVar25);
                  uVar49 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar25);
                  pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                }
                iVar19 = iVar19 + 1;
                puVar42 = puVar42 + 1;
              } while (iVar19 < (int)(*(uint *)(&stack0x00000084 + lVar25) >> 0xb & 7));
            }
          }
        }
        else {
          if (((*psVar30 == 0) || (*(longlong **)(psVar30 + 8) == (longlong *)0x0)) ||
             (**(longlong **)(psVar30 + 8) == 0)) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1041d0;
            func_0x(&stack0x0000005a + lVar25,&stack0x00000988 + lVar25,0x1f9e);
            if (*psVar30 == 0) {
              uVar27 = 0;
            }
            else {
              uVar27 = *(undefined8 *)(psVar30 + 8);
            }
            *(undefined8 *)(&stack0x00000068 + lVar25) = uVar27;
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1041b1;
            func_0x(&stack0x00000058 + lVar25,&stack0x00000988 + lVar25,0x1f9e);
          }
          pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
        }
        puVar28 = (undefined8 *)0x0;
        lVar31 = *(longlong *)(&stack0x00000120 + lVar25);
        uVar20 = 0;
        if (*(char *)(lVar31 + 0x1cde) == '\0') {
          if (*(short *)(&stack0x00000058 + lVar25) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1051d7;
            func_0x(&stack0x0000005a + lVar25);
          }
          else if ((*pbVar48 & 2) != 0) {
            if (*(int *)(&stack0x0000005c + lVar25) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1051ee;
              func_0x(&stack0x0000005a + lVar25);
              pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
            }
            *pbVar48 = *pbVar48 & 0xfd;
LAB_:
            uVar24 = *(undefined4 *)(&stack0x00000088 + lVar25);
            *(undefined4 *)(&stack0x00000088 + lVar25) = 0;
            *(undefined4 *)(&stack0x0000005c + lVar25) = uVar24;
          }
        }
        else {
          if (*(short *)(&stack0x00000058 + lVar25) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104216;
            func_0x();
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10421d;
            func_0x(&stack0x0000005a + lVar25,&stack0x000000ac + lVar25);
          }
          *(undefined4 *)(&stack0x000000c0 + lVar25) = *(undefined4 *)(&stack0x000000ac + lVar25);
          *(undefined2 *)(&stack0x000000c4 + lVar25) = *(undefined2 *)(&stack0x000000b0 + lVar25);
          if (*(short *)(&stack0x00000058 + lVar25) == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104248;
            func_0x();
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10424f;
            func_0x(&stack0x0000005a + lVar25,&stack0x000001c0 + lVar25);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104269;
          iVar19 = func_0x(lVar31 + 0x19c8,&stack0x000000c0 + lVar25,
                                   &stack0x000001c0 + lVar25);
          if (iVar19 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10429f;
            cVar12 = func_0x(lVar31 + 0x19c8,&stack0x000000c0 + lVar25);
            if (cVar12 == '\0') {
              pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
              uVar47 = *(uint *)(&stack0x0000005c + lVar25);
              uVar49 = (ulonglong)uVar47;
              if (*(short *)(&stack0x00000058 + lVar25) == 0) {
                if ((*pbVar48 & 0xe) == 2) goto LAB_;
                if (uVar47 == 0) {
                  *(undefined2 *)(&stack0x0000005a + lVar25) = 0;
                  uVar47 = *(uint *)(&stack0x00000068 + lVar25);
                  uVar49 = (ulonglong)uVar47;
                  *(uint *)(&stack0x0000006c + lVar25) = uVar47;
                  if ((*pbVar48 & 0x10) != 0) {
                    uVar47 = uVar47 + 2 + (*(ushort *)(pbVar48 + uVar49) + 7 >> 3);
                    uVar49 = (ulonglong)uVar47;
                    *(uint *)(&stack0x0000006c + lVar25) = uVar47;
                  }
                  if ((*pbVar48 & 0x20) == 0) {
                    *(int *)(&stack0x0000005c + lVar25) = (int)uVar49;
                    *(undefined2 *)(&stack0x00000074 + lVar25) = 0;
                    *(int *)(&stack0x00000070 + lVar25) = (int)uVar49;
                  }
                  else {
                    puVar42 = (ushort *)(pbVar48 + uVar49);
                    uVar17 = *puVar42;
                    *(ushort *)(&stack0x00000074 + lVar25) = uVar17;
                    if (uVar17 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104327;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104330;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10434a;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104366;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10438c;
                            (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x80f);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10439a;
                      func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),3);
                      uVar17 = *(ushort *)(&stack0x00000074 + lVar25);
                      pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                    }
                    uVar47 = *(int *)(&stack0x0000006c + lVar25) + 2 + (uint)uVar17 * 2;
                    *(uint *)(&stack0x00000070 + lVar25) = uVar47;
                    if (0x1f9e < uVar47) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1043cd;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1043d6;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1043f0;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10440c;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104432;
                            (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x816);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104440;
                      func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),4);
                      uVar17 = *(ushort *)(&stack0x00000074 + lVar25);
                      uVar47 = *(uint *)(&stack0x00000070 + lVar25);
                      pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                    }
                    uVar51 = (ulonglong)uVar17;
                    uVar52 = puVar42[uVar51] & 0x7fff;
                    *(uint *)(&stack0x0000005c + lVar25) = uVar52;
                    if (uVar52 < uVar47) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104474;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10447d;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104497;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1044b3;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1044d9;
                            (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x81d);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1044e7;
                      func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),4);
                      uVar51 = (ulonglong)*(ushort *)(&stack0x00000074 + lVar25);
                      uVar47 = *(uint *)(&stack0x00000070 + lVar25);
                      pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                      uVar52 = *(uint *)(&stack0x0000005c + lVar25);
                    }
                    uVar49 = (ulonglong)uVar52;
                    puVar32 = puVar28;
                    puVar57 = puVar42;
                    if ((short)uVar51 != 0) {
                      do {
                        uVar52 = puVar57[1] & 0x7fff;
                        if ((uVar52 < uVar47) || ((uint)uVar49 < uVar52)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104533;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 != '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10453c;
                            lVar31 = func_0x();
                            if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104556;
                              cVar12 = func_0x(0x1ead7c0);
                              if (cVar12 == '\0') {
                                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104572;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104596;
                                (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x82a);
                              }
                            }
                          }
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1045a4;
                          func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),4);
                          uVar51 = (ulonglong)*(ushort *)(&stack0x00000074 + lVar25);
                          pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                          uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                        }
                        uVar46 = (int)puVar32 + 1;
                        puVar32 = (undefined8 *)(ulonglong)uVar46;
                        uVar47 = uVar52;
                        puVar57 = puVar57 + 1;
                      } while ((int)uVar46 < (int)uVar51);
                      uVar47 = *(uint *)(&stack0x00000070 + lVar25);
                    }
                    while( true ) {
                      sVar16 = (short)uVar51;
                      if (-1 < (short)puVar42[(ulonglong)((int)uVar51 - 1) + 1]) break;
                      uVar52 = uVar47;
                      if ((int)uVar51 != 1) {
                        uVar52 = *(ushort *)
                                  (pbVar48 +
                                  uVar51 * 2 + ((ulonglong)*(uint *)(&stack0x0000006c + lVar25) - 2)
                                  ) & 0x7fff;
                      }
                      uVar46 = *(ushort *)
                                (pbVar48 +
                                uVar51 * 2 + (ulonglong)*(uint *)(&stack0x0000006c + lVar25)) &
                               0x7fff;
                      if (((uVar52 < uVar47) || (uVar46 < uVar52)) || ((uint)uVar49 < uVar46)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104638;
                        func_0x(pbVar48,7);
                        sVar16 = *(short *)(&stack0x00000074 + lVar25);
                        uVar47 = *(uint *)(&stack0x00000070 + lVar25);
                        pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                        uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                      }
                      if ((uVar52 < uVar47) || ((uint)uVar49 < uVar52)) goto LAB_;
                      if (*(ushort *)(pbVar48 + uVar52) == 5) {
                        *(ushort *)(&stack0x0000005a + lVar25) =
                             *(ushort *)(&stack0x0000005a + lVar25) | 2;
                        *(short *)(&stack0x00000074 + lVar25) = sVar16 + -1;
                        uVar51 = (ulonglong)(uVar52 & 0xffff);
                        *(short *)(&stack0x00000082 + lVar25) = (short)uVar52;
                        pbVar53 = pbVar48 + uVar51;
                        uVar17 = *(ushort *)(&stack0x00000084 + lVar25);
                        if ((*(ushort *)(pbVar53 + 2) >> 0xe & 1) == 0) {
                          uVar17 = uVar17 & 0xc7ff;
                        }
                        else {
                          uVar17 = uVar17 ^ (*(ushort *)(pbVar53 + 2) ^ uVar17) & 0x3800;
                        }
                        *(ushort *)(&stack0x00000084 + lVar25) = uVar17;
                        uVar18 = (uVar17 ^ *(ushort *)(pbVar53 + 2)) & 0x7ff ^ uVar17;
                        *(ushort *)(&stack0x00000084 + lVar25) = uVar18;
                        pbVar44 = pbVar48 + (ulonglong)((uVar18 & 0x7ff) * 2) + 4 +
                                            uVar51 + (uVar17 >> 0xb & 7) * 2;
                        if (pbVar44 < pbVar53) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104720;
                          func_0x(pbVar53,0x19);
                          uVar18 = *(ushort *)(&stack0x00000084 + lVar25);
                          uVar51 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar25);
                          pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                          uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                        }
                        if (uVar46 - uVar52 <
                            (((*(uint *)(&stack0x00000084 + lVar25) & 0x7ff) * 2 - (int)uVar51) -
                            *(int *)(&stack0x00000060 + lVar25)) + (int)pbVar44) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10475a;
                          func_0x(pbVar48 + uVar51,0x19);
                          uVar18 = *(ushort *)(&stack0x00000084 + lVar25);
                          uVar51 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar25);
                          pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                          uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                        }
                        if (((uVar18 & 0x3800) != 0) &&
                           (puVar42 = (ushort *)(pbVar48 + uVar51 + 4), puVar32 = puVar28,
                           (uVar18 & 0x3800) != 0)) {
                          do {
                            if ((uVar18 & 0x7ff) < (*puVar42 & 0x7ff)) {
                              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1047b5;
                              func_0x(pbVar48 + uVar51,0x1a);
                              uVar18 = *(ushort *)(&stack0x00000084 + lVar25);
                              uVar51 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar25);
                              pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                            }
                            uVar47 = (int)puVar32 + 1;
                            puVar32 = (undefined8 *)(ulonglong)uVar47;
                            puVar42 = puVar42 + 1;
                          } while ((int)uVar47 <
                                   (int)(*(uint *)(&stack0x00000084 + lVar25) >> 0xb & 7));
                          uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                        }
                        break;
                      }
                      if (*(ushort *)(pbVar48 + uVar52) < 0x400) break;
                      *(ushort *)(&stack0x0000005a + lVar25) =
                           *(ushort *)(&stack0x0000005a + lVar25) | 1;
                      uVar17 = sVar16 - 1;
                      uVar51 = (ulonglong)uVar17;
                      *(ushort *)(&stack0x00000074 + lVar25) = uVar17;
                      if (uVar17 == 0) break;
                    }
                  }
                  if ((*pbVar48 & 0x40) == 0) {
                    *(undefined4 *)(&stack0x0000007e + lVar25) = 0;
                  }
                  else {
                    *(int *)(&stack0x0000007e + lVar25) = (int)uVar49;
                    *(int *)(&stack0x0000005c + lVar25) = (int)uVar49 + 0xe;
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104804;
                    puVar32 = (undefined8 *)func_0x(&stack0x0000005a + lVar25);
                    *(undefined8 *)(&stack0x00000120 + lVar25) = *puVar32;
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10481a;
                    iVar19 = func_0x(&stack0x00000120 + lVar25);
                    uVar49 = (ulonglong)(uint)(*(int *)(&stack0x0000005c + lVar25) + iVar19);
                    *(int *)(&stack0x0000005c + lVar25) =
                         *(int *)(&stack0x0000005c + lVar25) + iVar19;
                    pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                  }
                  if ((*(byte **)(&stack0x00000076 + lVar25) != (byte *)0x0) &&
                     (*(byte **)(&stack0x00000076 + lVar25) < pbVar48 + uVar49)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104857;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104860;
                      lVar31 = func_0x();
                      if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10487a;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104896;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1048bc;
                          (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x886);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1048ca;
                    func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),0x12);
                    pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                    uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                  }
                  if (0x3f3b < (int)uVar49 - 1U) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1048ed;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1048f6;
                      lVar31 = func_0x();
                      if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104910;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 == '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10492c;
                          (*_DAT_)(0x22,0x44,0x15,0x3ed);
                        }
                        else {
                          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104952;
                          (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x88b);
                        }
                      }
                    }
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104960;
                    func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),5);
                    pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                    uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                  }
                }
LAB_:
                uVar47 = (uint)uVar49;
                if ((uVar47 < 9) && (((*pbVar48 & 0xe) == 0 || ((*pbVar48 & 0xe) == 0xc)))) {
                  uVar47 = 9;
                  bVar13 = *pbVar48;
                  bVar61 = (bVar13 & 0x40) == 0;
                  uVar52 = *(uint *)(&stack0x0000007e + lVar25);
                }
                else {
                  bVar13 = *pbVar48;
                  bVar61 = (bVar13 & 0x40) == 0;
                  uVar52 = *(uint *)(&stack0x0000007e + lVar25);
                }
LAB_:
                uVar46 = (uint)uVar49;
                if (bVar61) {
                  uVar52 = uVar47;
                }
                uVar47 = 0x10;
                if (*(short *)(&stack0x00000058 + lVar25) == 0) {
                  uVar47 = 0x16;
                }
                if (uVar52 < uVar47) goto LAB_;
              }
              else {
                if (((*pbVar48 & 0x1c) - 0x10 & 0xfffffffb) != 0) {
                  if (uVar47 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1049b9;
                    func_0x(&stack0x0000005a + lVar25);
                    uVar47 = *(uint *)(&stack0x0000005c + lVar25);
                    if (uVar47 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1049cb;
                      func_0x(&stack0x0000005a + lVar25);
                      uVar47 = *(uint *)(&stack0x0000005c + lVar25);
                    }
                    uVar49 = (ulonglong)uVar47;
                    pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                  }
                  uVar47 = (uint)uVar49;
                  if ((uVar47 < 9) && (((*pbVar48 & 0x1c) == 0 || ((*pbVar48 & 0x1c) == 0xc)))) {
                    uVar47 = 9;
                  }
                  bVar13 = *pbVar48;
                  bVar61 = (bVar13 & 2) == 0;
                  uVar52 = *(uint *)(&stack0x00000088 + lVar25);
                  goto LAB_;
                }
LAB_:
                uVar46 = (uint)uVar49;
                if (*(short *)(&stack0x00000058 + lVar25) == 0) {
LAB_:
                  if ((int)uVar49 == 0) {
                    *(undefined2 *)(&stack0x0000005a + lVar25) = 0;
                    uVar47 = *(uint *)(&stack0x00000068 + lVar25);
                    uVar49 = (ulonglong)uVar47;
                    *(uint *)(&stack0x0000006c + lVar25) = uVar47;
                    if ((*pbVar48 & 0x10) != 0) {
                      uVar47 = uVar47 + 2 + (*(ushort *)(pbVar48 + uVar49) + 7 >> 3);
                      uVar49 = (ulonglong)uVar47;
                      *(uint *)(&stack0x0000006c + lVar25) = uVar47;
                    }
                    if ((*pbVar48 & 0x20) == 0) {
                      *(int *)(&stack0x0000005c + lVar25) = (int)uVar49;
                      *(undefined2 *)(&stack0x00000074 + lVar25) = 0;
                      *(int *)(&stack0x00000070 + lVar25) = (int)uVar49;
                    }
                    else {
                      puVar42 = (ushort *)(pbVar48 + uVar49);
                      uVar17 = *puVar42;
                      *(ushort *)(&stack0x00000074 + lVar25) = uVar17;
                      if (uVar17 == 0) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104a84;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104a8d;
                          lVar31 = func_0x();
                          if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104aa7;
                            cVar12 = func_0x(0x1ead7c0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104ac3;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104ae9;
                              (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x80f);
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104af7;
                        func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),3);
                        uVar17 = *(ushort *)(&stack0x00000074 + lVar25);
                        pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                      }
                      uVar47 = *(int *)(&stack0x0000006c + lVar25) + 2 + (uint)uVar17 * 2;
                      *(uint *)(&stack0x00000070 + lVar25) = uVar47;
                      if (0x1f9e < uVar47) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104b2a;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104b33;
                          lVar31 = func_0x();
                          if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104b4d;
                            cVar12 = func_0x(0x1ead7c0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104b69;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104b8f;
                              (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x816);
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104b9d;
                        func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),4);
                        uVar17 = *(ushort *)(&stack0x00000074 + lVar25);
                        uVar47 = *(uint *)(&stack0x00000070 + lVar25);
                        pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                      }
                      uVar51 = (ulonglong)uVar17;
                      uVar52 = puVar42[uVar51] & 0x7fff;
                      *(uint *)(&stack0x0000005c + lVar25) = uVar52;
                      if (uVar52 < uVar47) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104bd1;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104bda;
                          lVar31 = func_0x();
                          if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104bf4;
                            cVar12 = func_0x(0x1ead7c0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104c10;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104c36;
                              (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x81d);
                            }
                          }
                        }
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104c44;
                        func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),4);
                        uVar51 = (ulonglong)*(ushort *)(&stack0x00000074 + lVar25);
                        uVar47 = *(uint *)(&stack0x00000070 + lVar25);
                        pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                        uVar52 = *(uint *)(&stack0x0000005c + lVar25);
                      }
                      uVar49 = (ulonglong)uVar52;
                      puVar32 = puVar28;
                      puVar57 = puVar42;
                      if ((short)uVar51 != 0) {
                        do {
                          uVar52 = puVar57[1] & 0x7fff;
                          if ((uVar52 < uVar47) || ((uint)uVar49 < uVar52)) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104c93;
                            cVar12 = func_0x(0x1ead7c0);
                            if (cVar12 != '\0') {
                              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104c9c;
                              lVar31 = func_0x();
                              if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104cb6;
                                cVar12 = func_0x(0x1ead7c0);
                                if (cVar12 == '\0') {
                                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104cd2;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104cf6;
                                  (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x82a);
                                }
                              }
                            }
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104d04;
                            func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),4);
                            uVar51 = (ulonglong)*(ushort *)(&stack0x00000074 + lVar25);
                            pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                            uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                          }
                          uVar46 = (int)puVar32 + 1;
                          puVar32 = (undefined8 *)(ulonglong)uVar46;
                          uVar47 = uVar52;
                          puVar57 = puVar57 + 1;
                        } while ((int)uVar46 < (int)uVar51);
                        uVar47 = *(uint *)(&stack0x00000070 + lVar25);
                      }
                      while( true ) {
                        sVar16 = (short)uVar51;
                        if (-1 < (short)puVar42[(ulonglong)((int)uVar51 - 1) + 1]) break;
                        uVar52 = uVar47;
                        if ((int)uVar51 != 1) {
                          uVar52 = *(ushort *)
                                    (pbVar48 +
                                    uVar51 * 2 +
                                    ((ulonglong)*(uint *)(&stack0x0000006c + lVar25) - 2)) & 0x7fff;
                        }
                        uVar46 = *(ushort *)
                                  (pbVar48 +
                                  uVar51 * 2 + (ulonglong)*(uint *)(&stack0x0000006c + lVar25)) &
                                 0x7fff;
                        if (((uVar52 < uVar47) || (uVar46 < uVar52)) || ((uint)uVar49 < uVar46)) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104d98;
                          func_0x(pbVar48,7);
                          sVar16 = *(short *)(&stack0x00000074 + lVar25);
                          uVar47 = *(uint *)(&stack0x00000070 + lVar25);
                          pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                          uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                        }
                        if ((uVar52 < uVar47) || ((uint)uVar49 < uVar52)) goto LAB_;
                        if (*(ushort *)(pbVar48 + uVar52) == 5) {
                          *(ushort *)(&stack0x0000005a + lVar25) =
                               *(ushort *)(&stack0x0000005a + lVar25) | 2;
                          *(short *)(&stack0x00000074 + lVar25) = sVar16 + -1;
                          uVar51 = (ulonglong)(uVar52 & 0xffff);
                          *(short *)(&stack0x00000082 + lVar25) = (short)uVar52;
                          pbVar53 = pbVar48 + uVar51;
                          uVar17 = *(ushort *)(&stack0x00000084 + lVar25);
                          if ((*(ushort *)(pbVar53 + 2) >> 0xe & 1) == 0) {
                            uVar17 = uVar17 & 0xc7ff;
                          }
                          else {
                            uVar17 = uVar17 ^ (*(ushort *)(pbVar53 + 2) ^ uVar17) & 0x3800;
                          }
                          *(ushort *)(&stack0x00000084 + lVar25) = uVar17;
                          uVar18 = (uVar17 ^ *(ushort *)(pbVar53 + 2)) & 0x7ff ^ uVar17;
                          *(ushort *)(&stack0x00000084 + lVar25) = uVar18;
                          pbVar44 = pbVar48 + (ulonglong)((uVar18 & 0x7ff) * 2) + 4 +
                                              uVar51 + (uVar17 >> 0xb & 7) * 2;
                          if (pbVar44 < pbVar53) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104e80;
                            func_0x(pbVar53,0x19);
                            uVar18 = *(ushort *)(&stack0x00000084 + lVar25);
                            uVar51 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar25);
                            pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                            uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                          }
                          if (uVar46 - uVar52 <
                              (((*(uint *)(&stack0x00000084 + lVar25) & 0x7ff) * 2 - (int)uVar51) -
                              *(int *)(&stack0x00000060 + lVar25)) + (int)pbVar44) {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104eba;
                            func_0x(pbVar48 + uVar51,0x19);
                            uVar18 = *(ushort *)(&stack0x00000084 + lVar25);
                            uVar51 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar25);
                            pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                            uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                          }
                          if (((uVar18 & 0x3800) != 0) &&
                             (puVar42 = (ushort *)(pbVar48 + uVar51 + 4), puVar32 = puVar28,
                             (uVar18 & 0x3800) != 0)) {
                            do {
                              if ((uVar18 & 0x7ff) < (*puVar42 & 0x7ff)) {
                                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104f15;
                                func_0x(pbVar48 + uVar51,0x1a);
                                uVar18 = *(ushort *)(&stack0x00000084 + lVar25);
                                uVar51 = (ulonglong)*(ushort *)(&stack0x00000082 + lVar25);
                                pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                              }
                              uVar47 = (int)puVar32 + 1;
                              puVar32 = (undefined8 *)(ulonglong)uVar47;
                              puVar42 = puVar42 + 1;
                            } while ((int)uVar47 <
                                     (int)(*(uint *)(&stack0x00000084 + lVar25) >> 0xb & 7));
                            uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                          }
                          break;
                        }
                        if (*(ushort *)(pbVar48 + uVar52) < 0x400) break;
                        *(ushort *)(&stack0x0000005a + lVar25) =
                             *(ushort *)(&stack0x0000005a + lVar25) | 1;
                        uVar17 = sVar16 - 1;
                        uVar51 = (ulonglong)uVar17;
                        *(ushort *)(&stack0x00000074 + lVar25) = uVar17;
                        if (uVar17 == 0) break;
                      }
                    }
                    if ((*pbVar48 & 0x40) == 0) {
                      *(undefined4 *)(&stack0x0000007e + lVar25) = 0;
                    }
                    else {
                      *(int *)(&stack0x0000007e + lVar25) = (int)uVar49;
                      *(int *)(&stack0x0000005c + lVar25) = (int)uVar49 + 0xe;
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104f64;
                      puVar33 = (ulonglong *)func_0x(&stack0x0000005a + lVar25);
                      uVar17 = (ushort)(*puVar33 >> 0x30);
                      if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
                        if ((uVar17 >> 0xe & 1) == 0) {
                          uVar17 = uVar17 & 0xdfff;
                        }
                        else {
                          uVar17 = uVar17 | 0x2000;
                        }
                      }
                      uVar47 = uVar20;
                      if (uVar17 == 0xfffc) {
                        uVar47 = (uint)((*puVar33 >> 0x20 & 0xffff) >> 5);
                      }
                      uVar49 = (ulonglong)(*(int *)(&stack0x0000005c + lVar25) + uVar47);
                      *(uint *)(&stack0x0000005c + lVar25) =
                           *(int *)(&stack0x0000005c + lVar25) + uVar47;
                      pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                    }
                    if ((*(byte **)(&stack0x00000076 + lVar25) != (byte *)0x0) &&
                       (*(byte **)(&stack0x00000076 + lVar25) < pbVar48 + uVar49)) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104fea;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104ff3;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10500d;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x105029;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10504f;
                            (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x886);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10505d;
                      func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),0x12);
                      pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                      uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                    }
                    if (0x3f3b < (int)uVar49 - 1U) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x105080;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x105089;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1050a3;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1050bf;
                            (*_DAT_)(0x22,0x44,0x15,0x3ed);
                          }
                          else {
                            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar25) = 0;
                            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1050e5;
                            (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x88b);
                          }
                        }
                      }
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1050f3;
                      func_0x(*(undefined8 *)(&stack0x00000060 + lVar25),5);
                      pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                      uVar49 = (ulonglong)*(uint *)(&stack0x0000005c + lVar25);
                    }
                  }
LAB_:
                  uVar46 = (uint)uVar49;
                  if ((uVar46 < 9) && (((*pbVar48 & 0xe) == 0 || ((*pbVar48 & 0xe) == 0xc)))) {
                    bVar13 = *pbVar48;
                    bVar61 = (bVar13 & 0x40) == 0;
                    uVar52 = *(uint *)(&stack0x0000007e + lVar25);
                    uVar47 = 9;
                  }
                  else {
                    bVar13 = *pbVar48;
                    bVar61 = (bVar13 & 0x40) == 0;
                    uVar52 = *(uint *)(&stack0x0000007e + lVar25);
                    uVar47 = uVar46;
                  }
                }
                else {
                  if (uVar46 == 0) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10513b;
                    func_0x(&stack0x0000005a + lVar25);
                    uVar46 = *(uint *)(&stack0x0000005c + lVar25);
                    if (uVar46 == 0) {
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10514d;
                      func_0x(&stack0x0000005a + lVar25);
                      uVar46 = *(uint *)(&stack0x0000005c + lVar25);
                    }
                    pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                  }
                  uVar47 = uVar46;
                  if ((uVar46 < 9) && (((*pbVar48 & 0x1c) == 0 || ((*pbVar48 & 0x1c) == 0xc)))) {
                    uVar47 = 9;
                  }
                  bVar13 = *pbVar48;
                  bVar61 = (bVar13 & 2) == 0;
                  uVar52 = *(uint *)(&stack0x00000088 + lVar25);
                }
                if (bVar61) {
                  uVar52 = uVar47;
                }
                uVar47 = 0x18;
                if (*(short *)(&stack0x00000058 + lVar25) == 0) {
                  uVar47 = 0x20;
                }
                if (uVar52 < uVar47) goto LAB_;
              }
              if (*(short *)(&stack0x00000058 + lVar25) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1051a8;
                func_0x(&stack0x0000005a + lVar25);
              }
              else if ((bVar13 & 2) != 0) {
                if (uVar46 == 0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1051bd;
                  func_0x(&stack0x0000005a + lVar25);
                  pbVar48 = *(byte **)(&stack0x00000060 + lVar25);
                }
                *pbVar48 = *pbVar48 & 0xfd;
                goto LAB_;
              }
            }
          }
          else {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x104283;
            func_0x(lVar31 + 0x1b30,&stack0x000000ac + lVar25);
          }
        }
LAB_:
        if (*(short *)(&stack0x00000058 + lVar25) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x105210;
          func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x105217;
          func_0x(&stack0x0000005a + lVar25);
        }
        lVar31 = *(longlong *)(&stack0x00000118 + lVar25);
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10522f;
        func_0x(lVar31,uVar59,0);
        plVar58 = (longlong *)(uVar59 + 0x30);
        *(longlong **)(&stack0x00000100 + lVar25) = plVar58;
        lVar35 = CONCAT44(uRam0000000001ed926c,_DAT_);
        if ((*(longlong *)(uVar59 + 0x40) != lVar35) ||
           (lVar34 = CONCAT44(uRam0000000001ed9274,_DAT_),
           *(longlong *)(uVar59 + 0x48) != lVar34)) {
          if ((*(byte *)(uVar59 + 0xa0) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10526c;
            iVar19 = func_0x(uVar59 + 0xa8);
            if (iVar19 != 0) {
              *(longlong *)(*plVar58 + 0x30) = *(longlong *)(*plVar58 + 0x30) + -1;
            }
          }
          *(undefined *)(uVar59 + 0xa0) = 0;
          *(undefined4 *)(uVar59 + 0x9c) = 0;
          *(undefined4 *)(uVar59 + 0xb8) = 0;
          if ((*(byte *)(uVar59 + 0xd0) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1052a3;
            iVar19 = func_0x(uVar59 + 0xd8);
            if (iVar19 != 0) {
              *(longlong *)(*plVar58 + 0x30) = *(longlong *)(*plVar58 + 0x30) + -1;
            }
          }
          *(undefined *)(uVar59 + 0xd0) = 0;
          *(undefined4 *)(uVar59 + 0xcc) = 0;
          *(undefined4 *)(uVar59 + 0xe8) = 0;
          if (*(longlong *)(uVar59 + 0x58) != 0) {
            *(undefined *)(uVar59 + 0x66) = 0;
            *(undefined8 *)(uVar59 + 0x58) = 0;
            *(undefined2 *)(uVar59 + 100) = 0;
            *(undefined4 *)(*(longlong *)(uVar59 + 0x40) + 0x48) = 0;
          }
          uVar27 = *(undefined8 *)*plVar58;
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1052fb;
          func_0x(uVar27,uVar59 + 0x40);
          uVar10 = uRam0000000001ed9274;
          uVar5 = _DAT_;
          uVar24 = uRam0000000001ed926c;
          *(undefined4 *)(uVar59 + 0x40) = _DAT_;
          *(undefined4 *)(uVar59 + 0x44) = uVar24;
          *(undefined4 *)(uVar59 + 0x48) = uVar5;
          *(undefined4 *)(uVar59 + 0x4c) = uVar10;
          *(undefined4 *)(uVar59 + 0x50) = 0xffffffff;
          *(undefined4 *)(uVar59 + 0x270) = 0;
          *(undefined8 *)(uVar59 + 0x288) = 0;
          *(undefined8 *)(uVar59 + 0x280) = 0;
          *(undefined8 *)(uVar59 + 0x290) = 0;
          *(undefined4 *)(uVar59 + 0x2a0) = 0xffffffff;
          *(undefined2 *)(uVar59 + 0x2a4) = 0xffff;
          *(undefined8 *)(uVar59 + 0x2a6) = 0;
          *(undefined4 *)(uVar59 + 0xf0) = 2;
          lVar34 = CONCAT44(uRam0000000001ed9274,_DAT_);
          lVar35 = CONCAT44(uRam0000000001ed926c,_DAT_);
        }
        if ((*(longlong *)(uVar59 + 0x2c0) != lVar35) || (*(longlong *)(uVar59 + 0x2c8) != lVar34))
        {
          if ((*(byte *)(uVar59 + 800) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1053b2;
            iVar19 = func_0x(uVar59 + 0x328);
            if (iVar19 != 0) {
              plVar60 = (longlong *)(*(longlong *)(uVar59 + 0x2b0) + 0x30);
              *plVar60 = *plVar60 + -1;
            }
          }
          *(undefined *)(uVar59 + 800) = 0;
          *(undefined4 *)(uVar59 + 0x31c) = 0;
          *(undefined4 *)(uVar59 + 0x338) = 0;
          if ((*(byte *)(uVar59 + 0x350) & 2) != 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1053ed;
            iVar19 = func_0x(uVar59 + 0x358);
            if (iVar19 != 0) {
              plVar60 = (longlong *)(*(longlong *)(uVar59 + 0x2b0) + 0x30);
              *plVar60 = *plVar60 + -1;
            }
          }
          *(undefined *)(uVar59 + 0x350) = 0;
          *(undefined4 *)(uVar59 + 0x34c) = 0;
          *(undefined4 *)(uVar59 + 0x368) = 0;
          if (*(longlong *)(uVar59 + 0x2d8) != 0) {
            *(undefined *)(uVar59 + 0x2e6) = 0;
            *(undefined8 *)(uVar59 + 0x2d8) = 0;
            *(undefined2 *)(uVar59 + 0x2e4) = 0;
            *(undefined4 *)(*(longlong *)(uVar59 + 0x2c0) + 0x48) = 0;
          }
          uVar27 = **(undefined8 **)(uVar59 + 0x2b0);
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x105454;
          func_0x(uVar27,uVar59 + 0x2c0);
          uVar10 = uRam0000000001ed9274;
          uVar5 = _DAT_;
          uVar24 = uRam0000000001ed926c;
          *(undefined4 *)(uVar59 + 0x2c0) = _DAT_;
          *(undefined4 *)(uVar59 + 0x2c4) = uVar24;
          *(undefined4 *)(uVar59 + 0x2c8) = uVar5;
          *(undefined4 *)(uVar59 + 0x2cc) = uVar10;
          *(undefined4 *)(uVar59 + 0x2d0) = 0xffffffff;
          *(undefined4 *)(uVar59 + 0x4f0) = 0;
          *(undefined8 *)(uVar59 + 0x508) = 0;
          *(undefined8 *)(uVar59 + 0x500) = 0;
          *(undefined8 *)(uVar59 + 0x510) = 0;
          *(undefined4 *)(uVar59 + 0x520) = 0xffffffff;
          *(undefined2 *)(uVar59 + 0x524) = 0xffff;
          *(undefined8 *)(uVar59 + 0x526) = 0;
          *(undefined4 *)(uVar59 + 0x370) = 2;
        }
        *(undefined4 *)(uVar59 + 0x634) = 0;
        if (((*(byte *)(*(longlong *)(**(longlong **)(*(uint **)(lVar31 + 0x108) + 8) + 8) + 0x107)
             & 0x40) == 0) || ((**(uint **)(lVar31 + 0x108) & 0x1000000) != 0)) {
          bVar13 = 0;
        }
        else {
          bVar13 = 4;
        }
        lVar35 = **(longlong **)(lVar31 + 0x2e0);
        plVar60 = *(longlong **)(*(longlong *)(uVar59 + 0x28) + 8);
        *(undefined8 *)(&stack0x00000208 + lVar25) = 0;
        *(undefined4 *)(&stack0x000000ac + lVar25) = 0;
        *(undefined **)(&stack0x00000200 + lVar25) = &stack0x00000058 + lVar25;
        puVar45 = &stack0xffffffffffffffc8 + lVar25;
        if (*(int *)(*(longlong *)(lVar35 + 8) + 0x100) == 2) {
          puVar54 = (undefined2 *)(&stack0xfffffffffffffff8 + lVar25);
          *puVar54 = 0xffff;
          *(undefined8 *)((longlong)&uStackX_20 + lVar25 + -0x20) = 0;
          *(undefined4 *)(&stack0xfffffffffffffffc + lVar25) = 0;
          *(undefined8 *)((longlong)&uStackX_16 + lVar25) = 0;
          *(undefined8 *)((longlong)&uStackX_20 + lVar25) = 0;
          *(undefined8 *)((longlong)&uStackX_8 + lVar25) = 0;
          *(undefined8 *)((longlong)&uStack_80 + lVar25) = 0x10554d;
          lVar35 = func_0x();
          lVar35 = -lVar35;
          puVar45 = auStack_f8 + lVar35 + lVar25;
          *(undefined (*) [16])(auStack_88 + lVar35 + lVar25) = ZEXT816(0);
          *(undefined (*) [16])((longlong)auStack_78 + lVar35 + lVar25) = ZEXT816(0);
          *(undefined (*) [16])((longlong)&uStack_68 + lVar35 + lVar25) = ZEXT816(0);
          *(undefined (*) [16])((longlong)&uStack_5a + lVar35 + lVar25 + 2) = ZEXT816(0);
          *(undefined (*) [16])(auStack_48 + lVar35 + lVar25) = ZEXT816(0);
          *(undefined (*) [16])(&stack0xffffffffffffffc8 + lVar35 + lVar25) = ZEXT816(0);
          *(undefined (*) [16])(&stack0xffffffffffffffd8 + lVar35 + lVar25) = ZEXT816(0);
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar35 + lVar25) = 0;
          *(undefined2 *)((longlong)auStack_78 + lVar35 + lVar25) = 0xffff;
          *(undefined8 *)((longlong)&uStack_70 + lVar35 + lVar25) = 0;
          *(undefined4 *)((longlong)&uStack_74 + lVar35 + lVar25) = 0;
          *(undefined8 *)((longlong)&uStack_5a + lVar35 + lVar25) = 0;
          *(undefined8 *)((longlong)&uStack_50 + lVar35 + lVar25) = 0;
          *(undefined8 *)((longlong)&uStack_68 + lVar35 + lVar25) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar35 + lVar25) = 0;
          *(undefined8 *)(&stack0xffffffffffffffd8 + lVar35 + lVar25) = 0;
          *(undefined4 *)(&stack0xffffffffffffffe0 + lVar35 + lVar25) = 0;
          *(undefined2 *)(&stack0xffffffffffffffea + lVar35 + lVar25) = 0;
          *(undefined2 **)(&stack0x00000208 + lVar25) = puVar54;
          *(undefined **)(&stack0x00000210 + lVar25) = &stack0xfffffffffffffff8 + lVar35 + lVar25;
          *(undefined4 *)(&stack0x00000218 + lVar25) = 0x239e;
          *(undefined (**) [16])(&stack0x00000220 + lVar25) =
               (undefined (*) [16])(auStack_88 + lVar35 + lVar25);
        }
        plVar8 = *(longlong **)(uVar59 + 0x28);
        plVar43 = (longlong *)plVar8[3];
        plVar55 = plVar8;
        if (plVar43 == (longlong *)0x0) {
          plVar43 = (longlong *)(plVar8[1] + 0x208);
          plVar8[3] = (longlong)plVar43;
          plVar55 = *(longlong **)(uVar59 + 0x28);
        }
        if ((*plVar43 == (ulonglong)*(uint6 *)(*plVar8 + 0x14) * 0x10000) &&
           (*(int *)(plVar43 + 1) != 0)) {
          *(undefined4 *)(&stack0x000000ac + lVar25) = 1;
          *(undefined4 *)(&stack0x00000094 + lVar25) = 0;
          iVar19 = *(int *)(uVar59 + 0x548);
          *(int *)(&stack0x00000098 + lVar25) = iVar19;
          if (iVar19 == 0) {
            *(undefined4 *)(&stack0x00000098 + lVar25) = *(undefined4 *)(&stack0x000000a8 + lVar25);
            *puVar1 = *(uint *)(&stack0x000000a8 + lVar25);
          }
          else {
            *(undefined4 *)(&stack0x00000094 + lVar25) = 1;
            *puVar1 = *(uint *)(uVar59 + 0x54c);
            lVar35 = plVar55[3];
            iVar19 = *(int *)(lVar35 + 8);
            if ((iVar19 == 0) || (*(int *)(lVar35 + 0xc) != 0)) {
              puVar32 = puVar28;
              if (iVar19 != 0) goto LAB_;
            }
            else {
              puVar32 = (undefined8 *)0x2;
LAB_:
              uVar20 = (uint)puVar32;
              if (*(int *)(lVar35 + 0xc) == iVar19 + -1) {
                uVar20 = uVar20 | 1;
              }
            }
            *(uint *)(uVar59 + 0x548) = uVar20;
            *(undefined4 *)(uVar59 + 0x54c) = *(undefined4 *)(plVar55 + 4);
          }
        }
        else {
          *(undefined4 *)(&stack0x00000094 + lVar25) = *(undefined4 *)(&stack0x000000a8 + lVar25);
          *(undefined4 *)(&stack0x00000098 + lVar25) = *(undefined4 *)(&stack0x000000a8 + lVar25);
          *puVar1 = *(uint *)(&stack0x000000a8 + lVar25);
        }
        *(uint *)(uVar59 + 0x634) = *(uint *)(uVar59 + 0x634) & 0xfffffffe;
        puVar29 = (undefined4 *)(uVar59 + 0x530);
        *(byte *)puVar29 = (*(byte *)puVar29 & 0xfa | bVar13) & 0x7f;
        *(undefined4 *)(uVar59 + 0x54c) = *(undefined4 *)(*(longlong *)(uVar59 + 0x28) + 0x20);
        if (*(int *)(*(longlong *)(uVar59 + 0x20) + 0x40) != 1) {
          pcVar6 = *(code **)(*plVar60 + 0x270);
          *(undefined8 *)(puVar45 + -8) = 0x1056e5;
          (*pcVar6)(plVar60);
        }
        *(byte *)(uVar59 + 0x531) = *(byte *)(uVar59 + 0x531) & 0xfb;
        lVar35 = 2;
        puVar36 = puVar29;
        puVar37 = (undefined4 *)(&stack0x00000338 + lVar25);
        do {
          uVar24 = puVar36[1];
          uVar5 = puVar36[2];
          uVar10 = puVar36[3];
          *puVar37 = *puVar36;
          puVar37[1] = uVar24;
          puVar37[2] = uVar5;
          puVar37[3] = uVar10;
          uVar24 = puVar36[5];
          uVar5 = puVar36[6];
          uVar10 = puVar36[7];
          puVar37[4] = puVar36[4];
          puVar37[5] = uVar24;
          puVar37[6] = uVar5;
          puVar37[7] = uVar10;
          uVar24 = puVar36[9];
          uVar5 = puVar36[10];
          uVar10 = puVar36[0xb];
          puVar37[8] = puVar36[8];
          puVar37[9] = uVar24;
          puVar37[10] = uVar5;
          puVar37[0xb] = uVar10;
          uVar24 = puVar36[0xd];
          uVar5 = puVar36[0xe];
          uVar10 = puVar36[0xf];
          puVar37[0xc] = puVar36[0xc];
          puVar37[0xd] = uVar24;
          puVar37[0xe] = uVar5;
          puVar37[0xf] = uVar10;
          uVar24 = puVar36[0x11];
          uVar5 = puVar36[0x12];
          uVar10 = puVar36[0x13];
          puVar37[0x10] = puVar36[0x10];
          puVar37[0x11] = uVar24;
          puVar37[0x12] = uVar5;
          puVar37[0x13] = uVar10;
          uVar24 = puVar36[0x15];
          uVar5 = puVar36[0x16];
          uVar10 = puVar36[0x17];
          puVar37[0x14] = puVar36[0x14];
          puVar37[0x15] = uVar24;
          puVar37[0x16] = uVar5;
          puVar37[0x17] = uVar10;
          uVar24 = puVar36[0x19];
          uVar5 = puVar36[0x1a];
          uVar10 = puVar36[0x1b];
          puVar37[0x18] = puVar36[0x18];
          puVar37[0x19] = uVar24;
          puVar37[0x1a] = uVar5;
          puVar37[0x1b] = uVar10;
          uVar24 = puVar36[0x1d];
          uVar5 = puVar36[0x1e];
          uVar10 = puVar36[0x1f];
          puVar37[0x1c] = puVar36[0x1c];
          puVar37[0x1d] = uVar24;
          puVar37[0x1e] = uVar5;
          puVar37[0x1f] = uVar10;
          puVar36 = puVar36 + 0x20;
          lVar35 = lVar35 + -1;
          puVar37 = puVar37 + 0x20;
        } while (lVar35 != 0);
        pcVar6 = *(code **)(*plVar60 + 0x28);
        *(undefined8 *)(puVar45 + -8) = 0x10575b;
        cVar12 = (*pcVar6)(plVar60);
        puVar32 = (undefined8 *)(lVar31 + 0xa40);
        if (cVar12 != '\0') {
          puVar32 = puVar28;
        }
        *(undefined8 **)(&stack0x000000f0 + lVar25) = puVar32;
        bVar13 = (&stack0x00000339)[lVar25];
        if ((puVar32 != (undefined8 *)0x0) &&
           (((*(int *)(puVar32 + 1) != 0 || (*(short *)((longlong)puVar32 + 0xc) != 0)) &&
            ((bVar13 & 4) == 0)))) {
          puVar28 = (undefined8 *)*plVar58;
          *(undefined **)(puVar45 + 0x20) = &stack0x00000268 + lVar25;
          uVar27 = *puVar28;
          *(undefined8 *)(puVar45 + -8) = 0x1057bd;
          iVar19 = func_0x(uVar27,puVar32,3,2);
          if (iVar19 != 0) {
            puVar36 = (undefined4 *)(&stack0x00000338 + lVar25);
            lVar31 = 2;
            puVar37 = (undefined4 *)(&stack0x00000438 + lVar25);
            do {
              uVar24 = puVar36[1];
              uVar5 = puVar36[2];
              uVar10 = puVar36[3];
              *puVar37 = *puVar36;
              puVar37[1] = uVar24;
              puVar37[2] = uVar5;
              puVar37[3] = uVar10;
              uVar24 = puVar36[5];
              uVar5 = puVar36[6];
              uVar10 = puVar36[7];
              puVar37[4] = puVar36[4];
              puVar37[5] = uVar24;
              puVar37[6] = uVar5;
              puVar37[7] = uVar10;
              uVar24 = puVar36[9];
              uVar5 = puVar36[10];
              uVar10 = puVar36[0xb];
              puVar37[8] = puVar36[8];
              puVar37[9] = uVar24;
              puVar37[10] = uVar5;
              puVar37[0xb] = uVar10;
              uVar24 = puVar36[0xd];
              uVar5 = puVar36[0xe];
              uVar10 = puVar36[0xf];
              puVar37[0xc] = puVar36[0xc];
              puVar37[0xd] = uVar24;
              puVar37[0xe] = uVar5;
              puVar37[0xf] = uVar10;
              uVar24 = puVar36[0x11];
              uVar5 = puVar36[0x12];
              uVar10 = puVar36[0x13];
              puVar37[0x10] = puVar36[0x10];
              puVar37[0x11] = uVar24;
              puVar37[0x12] = uVar5;
              puVar37[0x13] = uVar10;
              uVar24 = puVar36[0x15];
              uVar5 = puVar36[0x16];
              uVar10 = puVar36[0x17];
              puVar37[0x14] = puVar36[0x14];
              puVar37[0x15] = uVar24;
              puVar37[0x16] = uVar5;
              puVar37[0x17] = uVar10;
              uVar24 = puVar36[0x19];
              uVar5 = puVar36[0x1a];
              uVar10 = puVar36[0x1b];
              puVar37[0x18] = puVar36[0x18];
              puVar37[0x19] = uVar24;
              puVar37[0x1a] = uVar5;
              puVar37[0x1b] = uVar10;
              uVar24 = puVar36[0x1d];
              uVar5 = puVar36[0x1e];
              uVar10 = puVar36[0x1f];
              puVar37[0x1c] = puVar36[0x1c];
              puVar37[0x1d] = uVar24;
              puVar37[0x1e] = uVar5;
              puVar37[0x1f] = uVar10;
              puVar36 = puVar36 + 0x20;
              lVar31 = lVar31 + -1;
              puVar37 = puVar37 + 0x20;
            } while (lVar31 != 0);
            *(undefined4 *)(puVar45 + 0x30) = 0;
            *(undefined **)(puVar45 + 0x28) = &stack0x00000438 + lVar25;
            *(undefined8 *)(puVar45 + 0x20) = 0;
            *(undefined8 *)(puVar45 + -8) = 0x105861;
            func_0x(plVar58,&stack0x00000268 + lVar25,&stack0x00000200 + lVar25,0);
          }
        }
        if (*(int *)(uVar59 + 0xf0) != 4) {
          if ((bVar13 & 4) == 0) {
            *(undefined4 *)(&stack0x000002b8 + lVar25) = 0;
            (&stack0x000002c8)[lVar25] = 0;
            *(undefined8 *)(&stack0x00000790 + lVar25) = 0;
            *(undefined8 *)(&stack0x0000077c + lVar25) = 0;
            *(undefined8 *)(&stack0x00000784 + lVar25) = 0;
            *(undefined4 *)(&stack0x00000778 + lVar25) = 0;
            *(undefined4 *)(&stack0x0000078c + lVar25) = 0;
            *(undefined8 *)(&stack0x000002fc + lVar25) = 0;
            *(undefined4 *)(&stack0x0000030c + lVar25) = 0;
            plVar60 = *(longlong **)(uVar59 + 0x38);
            lVar31 = *plVar60;
            *(longlong *)(&stack0x00000118 + lVar25) = lVar31;
            *(longlong *)(&stack0x00000120 + lVar25) = *(longlong *)(lVar31 + 8) + 0x3c0;
            plVar60 = (longlong *)plVar60[1];
            *(longlong **)(&stack0x00000110 + lVar25) = plVar60;
            pcVar6 = *(code **)(*plVar60 + 0x58);
            *(undefined8 *)(puVar45 + -8) = 0x1058fd;
            (*pcVar6)(plVar60);
            (&stack0x000007a6)[lVar25] = 1;
            (&stack0x000001e8)[lVar25] = (&stack0x000001e8)[lVar25] & 0xfc;
            *(undefined8 *)(puVar45 + -8) = 0x105917;
            func_0x(&stack0x000001f0 + lVar25);
            *(undefined4 *)(&stack0x000001f0 + lVar25) = *(undefined4 *)(&stack0x00000340 + lVar25);
            *(undefined4 *)(&stack0x000001f4 + lVar25) = *(undefined4 *)(&stack0x00000344 + lVar25);
            *(undefined4 *)(&stack0x000001f8 + lVar25) = *(undefined4 *)(&stack0x00000348 + lVar25);
            *(undefined4 *)(&stack0x000001fc + lVar25) = *(undefined4 *)(&stack0x0000034c + lVar25);
            (&stack0x000001e8)[lVar25] =
                 (byte)(&stack0x00000338)[lVar25] >> 6 & 2 | (&stack0x000001e8)[lVar25] & 0xfc |
                 (&stack0x00000338)[lVar25] & 1;
            *(undefined4 *)(&stack0x00000128 + lVar25) = *(undefined4 *)(&stack0x000001e8 + lVar25);
            *(undefined4 *)(&stack0x0000012c + lVar25) = *(undefined4 *)(&stack0x000001ec + lVar25);
            *(undefined4 *)(&stack0x00000130 + lVar25) = *(undefined4 *)(&stack0x000001f0 + lVar25);
            *(undefined4 *)(&stack0x00000134 + lVar25) = *(undefined4 *)(&stack0x000001f4 + lVar25);
            *(undefined4 *)(&stack0x00000140 + lVar25) = *(undefined4 *)(&stack0x00000348 + lVar25);
            *(undefined4 *)(&stack0x00000144 + lVar25) = *(undefined4 *)(&stack0x0000034c + lVar25);
            psVar30 = *(short **)(&stack0x00000200 + lVar25);
            *(short **)(&stack0x000000f8 + lVar25) = psVar30;
            puVar42 = (ushort *)(psVar30 + 1);
            uVar20 = *(uint *)(psVar30 + 2);
            psVar50 = psVar30;
            if (*psVar30 == 0) {
              if (uVar20 == 0) {
                iVar19 = 0;
                *puVar42 = 0;
                uVar20 = *(uint *)(psVar30 + 8);
                uVar49 = (ulonglong)uVar20;
                *(uint *)(psVar30 + 10) = uVar20;
                pbVar48 = *(byte **)(psVar30 + 4);
                bVar13 = *pbVar48;
                if ((bVar13 & 0x10) != 0) {
                  uVar20 = uVar20 + 2 + (*(ushort *)(pbVar48 + uVar49) + 7 >> 3);
                  uVar49 = (ulonglong)uVar20;
                  *(uint *)(psVar30 + 10) = uVar20;
                  bVar13 = *pbVar48;
                }
                if ((bVar13 & 0x20) == 0) {
                  *(int *)(psVar30 + 2) = (int)uVar49;
                  psVar30[0xe] = 0;
                  *(undefined4 *)(psVar30 + 0xc) = *(undefined4 *)(psVar30 + 10);
                }
                else {
                  puVar57 = (ushort *)(pbVar48 + uVar49);
                  uVar17 = *puVar57;
                  psVar30[0xe] = uVar17;
                  if (uVar17 == 0) {
                    *(undefined8 *)(puVar45 + -8) = 0x1059e9;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x1059f2;
                      lVar31 = func_0x();
                      if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x105a0c;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x105a28;
                          (*_DAT_)(0x22,0x44,0x15,0x3eb);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x105a4e;
                          (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x80f);
                        }
                      }
                    }
                    uVar27 = *(undefined8 *)(psVar30 + 4);
                    *(undefined8 *)(puVar45 + -8) = 0x105a5c;
                    func_0x(uVar27,3);
                    uVar17 = psVar30[0xe];
                  }
                  uVar20 = *(int *)(psVar30 + 10) + 2 + (uint)uVar17 * 2;
                  *(uint *)(psVar30 + 0xc) = uVar20;
                  if (0x1f9e < uVar20) {
                    *(undefined8 *)(puVar45 + -8) = 0x105a83;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x105a8c;
                      lVar31 = func_0x();
                      if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x105aa6;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x105ac2;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x105ae8;
                          (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x816);
                        }
                      }
                    }
                    uVar27 = *(undefined8 *)(psVar30 + 4);
                    *(undefined8 *)(puVar45 + -8) = 0x105af6;
                    func_0x(uVar27,4);
                  }
                  uVar17 = puVar57[(ushort)psVar30[0xe]];
                  *(uint *)(psVar30 + 2) = uVar17 & 0x7fff;
                  uVar20 = *(uint *)(psVar30 + 0xc);
                  if ((uVar17 & 0x7fff) < uVar20) {
                    *(undefined8 *)(puVar45 + -8) = 0x105b1f;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x105b28;
                      lVar31 = func_0x();
                      if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x105b42;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x105b5e;
                          (*_DAT_)(0x22,0x44,0x15,0x3ec);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x105b84;
                          (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x81d);
                        }
                      }
                    }
                    uVar27 = *(undefined8 *)(psVar30 + 4);
                    *(undefined8 *)(puVar45 + -8) = 0x105b92;
                    func_0x(uVar27,4);
                    uVar20 = *(uint *)(psVar30 + 0xc);
                  }
                  uVar17 = psVar30[0xe];
                  puVar9 = puVar57;
                  if (uVar17 != 0) {
                    do {
                      uVar47 = puVar9[1] & 0x7fff;
                      if ((uVar47 < uVar20) || (*(uint *)(psVar30 + 2) < uVar47)) {
                        *(undefined8 *)(puVar45 + -8) = 0x105bce;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x105bd7;
                          lVar31 = func_0x();
                          if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar45 + -8) = 0x105bf1;
                            cVar12 = func_0x(0x1ead7c0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)(puVar45 + -8) = 0x105c0d;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar45 + 0x20) = 0;
                              *(undefined8 *)(puVar45 + -8) = 0x105c31;
                              (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x82a);
                            }
                          }
                        }
                        uVar27 = *(undefined8 *)(psVar30 + 4);
                        *(undefined8 *)(puVar45 + -8) = 0x105c3f;
                        func_0x(uVar27,4);
                      }
                      iVar19 = iVar19 + 1;
                      uVar17 = psVar30[0xe];
                      uVar20 = uVar47;
                      puVar9 = puVar9 + 1;
                    } while (iVar19 < (int)(uint)uVar17);
                    plVar58 = *(longlong **)(&stack0x00000100 + lVar25);
                    uVar59 = *(ulonglong *)(&stack0x000000b8 + lVar25);
                  }
                  uVar20 = (uint)uVar17;
                  if ((short)puVar57[(ulonglong)(uVar20 - 1) + 1] < 0) {
                    do {
                      lVar31 = *(longlong *)(psVar30 + 4);
                      uVar47 = *(ushort *)
                                ((ulonglong)*(uint *)(psVar30 + 10) + lVar31 + (ulonglong)uVar20 * 2
                                ) & 0x7fff;
                      if (uVar20 == 1) {
                        uVar52 = *(uint *)(psVar30 + 0xc);
                        uVar46 = uVar52;
LAB_:
                        if ((uVar47 < uVar52) || (uVar20 = *(uint *)(psVar30 + 2), uVar20 < uVar47))
                        goto LAB_;
                      }
                      else {
                        uVar52 = *(ushort *)
                                  ((ulonglong)*(uint *)(psVar30 + 10) + lVar31 + -2 +
                                  (ulonglong)uVar20 * 2) & 0x7fff;
                        uVar46 = *(uint *)(psVar30 + 0xc);
                        if (uVar46 <= uVar52) goto LAB_;
LAB_:
                        *(undefined8 *)(puVar45 + -8) = 0x105ccf;
                        func_0x(lVar31,7);
                        uVar46 = *(uint *)(psVar30 + 0xc);
                        uVar20 = *(uint *)(psVar30 + 2);
                        lVar31 = *(longlong *)(psVar30 + 4);
                      }
                      if ((uVar52 < uVar46) || (uVar20 < uVar52)) goto LAB_;
                      if (*(ushort *)((ulonglong)uVar52 + lVar31) == 5) {
                        *puVar42 = *puVar42 | 2;
                        psVar30[0xe] = psVar30[0xe] + -1;
                        psVar30[0x15] = (short)uVar52;
                        uVar49 = *(ulonglong *)(psVar30 + 4);
                        uVar17 = *(ushort *)((ulonglong)(uVar52 & 0xffff) + 2 + uVar49);
                        uVar18 = psVar30[0x16] & 0xc7ff;
                        if ((uVar17 >> 0xe & 1) != 0) {
                          uVar18 = uVar17 & 0x3800 | uVar18;
                        }
                        psVar30[0x16] = uVar18;
                        uVar17 = (uVar18 ^ *(ushort *)((ulonglong)(uVar52 & 0xffff) + 2 + uVar49)) &
                                 0x7ff ^ uVar18;
                        psVar30[0x16] = uVar17;
                        uVar56 = (ulonglong)(ushort)psVar30[0x15];
                        uVar51 = uVar49 + 4 +
                                 (ulonglong)((uVar17 & 0x7ff) * 2) +
                                 uVar56 + (uVar18 >> 0xb & 7) * 2;
                        if (uVar51 < uVar56 + uVar49) {
                          *(undefined8 *)(puVar45 + -8) = 0x105e2e;
                          func_0x(uVar56 + uVar49,0x19);
                          uVar17 = psVar30[0x16];
                          uVar56 = (ulonglong)(ushort)psVar30[0x15];
                          uVar49 = (ulonglong)*(uint *)(psVar30 + 4);
                        }
                        if (uVar47 - uVar52 <
                            (((uVar17 & 0x7ff) * 2 - (int)uVar56) - (int)uVar49) + (int)uVar51) {
                          lVar31 = *(longlong *)(psVar30 + 4);
                          *(undefined8 *)(puVar45 + -8) = 0x105e66;
                          func_0x(uVar56 + lVar31,0x19);
                          uVar17 = psVar30[0x16];
                        }
                        iVar19 = 0;
                        if (((uVar17 & 0x3800) != 0) &&
                           (puVar57 = (ushort *)
                                      (*(longlong *)(psVar30 + 4) + 4 +
                                      (ulonglong)(ushort)psVar30[0x15]), (uVar17 & 0x3800) != 0)) {
                          do {
                            if ((uVar17 & 0x7ff) < (*puVar57 & 0x7ff)) {
                              uVar17 = psVar30[0x15];
                              lVar31 = *(longlong *)(psVar30 + 4);
                              *(undefined8 *)(puVar45 + -8) = 0x105ec7;
                              func_0x((ulonglong)uVar17 + lVar31,0x1a);
                              uVar17 = psVar30[0x16];
                            }
                            iVar19 = iVar19 + 1;
                            puVar57 = puVar57 + 1;
                          } while (iVar19 < (int)(uVar17 >> 0xb & 7));
                        }
                        break;
                      }
                      if (*(ushort *)((ulonglong)uVar52 + lVar31) < 0x400) break;
                      *puVar42 = *puVar42 | 1;
                      uVar17 = psVar30[0xe] - 1;
                      psVar30[0xe] = uVar17;
                      if ((uVar17 == 0) ||
                         (uVar20 = (uint)uVar17, -1 < (short)puVar57[(ulonglong)(uVar17 - 1) + 1]))
                      break;
                    } while( true );
                  }
                }
                iVar19 = 0;
                if ((**(byte **)(psVar30 + 4) & 0x40) == 0) {
                  *(undefined4 *)(psVar30 + 0x13) = 0;
                }
                else {
                  *(undefined4 *)(psVar30 + 0x13) = *(undefined4 *)(psVar30 + 2);
                  *(int *)(psVar30 + 2) = *(int *)(psVar30 + 2) + 0xe;
                  *(undefined8 *)(puVar45 + -8) = 0x105d51;
                  puVar33 = (ulonglong *)func_0x(puVar42);
                  uVar17 = (ushort)(*puVar33 >> 0x30);
                  if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
                    if ((uVar17 >> 0xe & 1) == 0) {
                      uVar17 = uVar17 & 0xdfff;
                    }
                    else {
                      uVar17 = uVar17 | 0x2000;
                    }
                  }
                  if (uVar17 == 0xfffc) {
                    iVar19 = (int)((*puVar33 >> 0x20 & 0xffff) >> 5);
                  }
                  *(int *)(psVar30 + 2) = *(int *)(psVar30 + 2) + iVar19;
                }
                uVar20 = *(uint *)(psVar30 + 2);
                if ((*(ulonglong *)(psVar30 + 0xf) != 0) &&
                   (*(ulonglong *)(psVar30 + 0xf) < (ulonglong)uVar20 + *(longlong *)(psVar30 + 4)))
                {
                  *(undefined8 *)(puVar45 + -8) = 0x105f4a;
                  cVar12 = func_0x(0x1ead7c0);
                  if (cVar12 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x105f53;
                    lVar31 = func_0x();
                    if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar45 + -8) = 0x105f6d;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 == '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x105f89;
                        (*_DAT_)(0x22,0x44,0x15,0x3fa);
                      }
                      else {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x105faf;
                        (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x886);
                      }
                    }
                  }
                  uVar27 = *(undefined8 *)(psVar30 + 4);
                  *(undefined8 *)(puVar45 + -8) = 0x105fbd;
                  func_0x(uVar27,0x12);
                  uVar20 = *(uint *)(psVar30 + 2);
                }
                if ((uVar20 == 0) || (0x3f3c < uVar20)) {
                  *(undefined8 *)(puVar45 + -8) = 0x105fdf;
                  cVar12 = func_0x(0x1ead7c0);
                  if (cVar12 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x105fe8;
                    lVar31 = func_0x();
                    if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar45 + -8) = 0x106002;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 == '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x10601e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ed);
                      }
                      else {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x106044;
                        (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x88b);
                      }
                    }
                  }
                  uVar27 = *(undefined8 *)(psVar30 + 4);
                  *(undefined8 *)(puVar45 + -8) = 0x106052;
                  func_0x(uVar27,5);
                  uVar20 = *(uint *)(psVar30 + 2);
                }
LAB_:
                psVar50 = *(short **)(&stack0x000000f8 + lVar25);
              }
              if (uVar20 < 9) {
                bVar13 = **(byte **)(psVar30 + 4);
                if (((bVar13 & 0xe) != 0) && ((bVar13 & 0xe) != 0xc)) goto LAB_;
                uVar20 = 9;
              }
              else {
LAB_:
                bVar13 = **(byte **)(psVar30 + 4);
              }
              if ((bVar13 & 0x40) != 0) {
                uVar20 = *(uint *)(psVar30 + 0x13);
              }
              plVar60 = *(longlong **)(&stack0x00000110 + lVar25);
            }
            else {
              if (uVar20 == 0) {
                *(undefined8 *)(puVar45 + -8) = 0x1060a3;
                func_0x(puVar42);
                uVar20 = *(uint *)(psVar30 + 2);
                if (uVar20 == 0) {
                  *(undefined8 *)(puVar45 + -8) = 0x1060b4;
                  func_0x(puVar42);
                  uVar20 = *(uint *)(psVar30 + 2);
                }
              }
              if (uVar20 < 9) {
                bVar13 = **(byte **)(psVar30 + 4);
                if (((bVar13 & 0x1c) != 0) && ((bVar13 & 0x1c) != 0xc)) goto LAB_;
                uVar20 = 9;
              }
              else {
LAB_:
                bVar13 = **(byte **)(psVar30 + 4);
              }
              if ((bVar13 & 2) != 0) {
                uVar20 = *(uint *)(psVar30 + 0x18);
              }
            }
            pcVar6 = *(code **)*plVar60;
            *(undefined8 *)(puVar45 + -8) = 0x1060f1;
            cVar12 = (*pcVar6)(plVar60);
            if (cVar12 == '\0') {
              if (((&stack0x00000128)[lVar25] & 1) == 0) {
LAB_:
                lVar31 = plVar60[0x1a];
                if (((&stack0x00000130)[lVar25] & 1) != 0) goto LAB_;
                pcVar6 = *(code **)*plVar60;
                *(undefined8 *)(puVar45 + -8) = 0x106805;
                cVar12 = (*pcVar6)(plVar60);
                if (cVar12 != '\0') goto LAB_;
                pcVar6 = *(code **)(*plVar60 + 0x88);
                *(undefined8 *)(puVar45 + -8) = 0x106819;
                cVar12 = (*pcVar6)(plVar60);
                if (cVar12 != '\0') {
                  if ((&stack0x00000131)[lVar25] != '\0') goto LAB_;
                  if (lVar31 == 0) {
                    pcVar6 = *(code **)(*plVar60 + 0x18);
                    *(undefined8 *)(puVar45 + -8) = 0x10683c;
                    cVar12 = (*pcVar6)(plVar60);
                    if (cVar12 == '\0') goto LAB_;
                  }
                  if ((*(byte *)(plVar60 + 0x4a) & 4) == 0) {
                    if ((*(byte *)(plVar60 + 0x4a) & 0x5a) == 0) {
                      if ((*(byte *)(plVar60 + 0x43) & 1) != 0) {
                        if (plVar60[0x1a] == 0) {
                          pcVar6 = *(code **)(*plVar60 + 0x88);
                          *(undefined8 *)(puVar45 + -8) = 0x106880;
                          cVar12 = (*pcVar6)(plVar60);
                          if (cVar12 != '\0') {
                            pcVar6 = *(code **)(*plVar60 + 0x18);
                            *(undefined8 *)(puVar45 + -8) = 0x10688d;
                            cVar12 = (*pcVar6)(plVar60);
                            if (cVar12 == '\0') {
                              *(byte *)(plVar60 + 0x4a) = *(byte *)(plVar60 + 0x4a) | 4;
                              goto LAB_;
                            }
                          }
                        }
                        *(undefined8 *)(puVar45 + -8) = 0x1068a6;
                        iVar19 = func_0x(plVar60);
                        if (iVar19 == 0) {
                          pcVar6 = *(code **)(*plVar60 + 0x270);
                          *(undefined8 *)(puVar45 + -8) = 0x1068b6;
                          (*pcVar6)(plVar60);
                        }
                        if ((*(byte *)(plVar60 + 0x43) & 4) == 0) {
                          if ((*(byte *)(plVar60 + 0x4a) & 0x52) == 2) {
                            lVar35 = plVar60[0x1a];
                            *(undefined8 *)(puVar45 + -8) = 0x1068f0;
                            cVar12 = func_0x(lVar35);
                            if (((cVar12 != '\0') && (*(char *)(plVar60[0x1a] + 0x130) == '\0')) &&
                               (*(undefined *)(plVar60[0x1a] + 0x130) = 1, *_DAT_ != '\0'))
                            {
                              *(undefined8 *)(puVar45 + 0x20) = 0;
                              *(undefined8 *)(puVar45 + -8) = 0x106935;
                              func_0x(0x1eadf00,0x1c,0x10,1);
                            }
                          }
                          uVar47 = (uint)((*(byte *)(plVar60 + 0x4a) & 0x5a) != 0);
                        }
                        else {
                          pcVar6 = *(code **)(*plVar60 + 0x1e8);
                          *(undefined8 *)(puVar45 + -8) = 0x1068cc;
                          uVar27 = (*pcVar6)(plVar60);
                          *(undefined8 *)(puVar45 + -8) = 0x1068d4;
                          uVar47 = func_0x(uVar27);
                        }
                        if (uVar47 != 0) goto LAB_;
                      }
                    }
                    else {
LAB_:
                      if (((*(byte *)(plVar60 + 0x4a) & 0x40) != 0) &&
                         ((&stack0x00000132)[lVar25] != '\0')) goto LAB_;
                    }
                  }
                }
LAB_:
                if (((&stack0x00000130)[lVar25] & 0x1c) == 0) {
                  lVar35 = *(longlong *)(&stack0x00000138 + lVar25);
                  if (lVar35 != 0) {
                    iVar19 = *(int *)(*(longlong *)(lVar35 + 8) + 0x68);
                    bVar61 = iVar19 < 0;
                    if (bVar61) {
                      *(undefined8 *)(puVar45 + 0x20) = 0;
                      *(undefined8 *)(puVar45 + -8) = 0x1069ab;
                      (*_DAT_)(1,0x194c1a8,0x194a858,0xc9d);
                      iVar19 = *(int *)(*(longlong *)(lVar35 + 8) + 0x68);
                      bVar61 = iVar19 < 0;
                    }
                    if (((iVar19 != 0 && !bVar61) &&
                        (iVar19 = *(int *)(*(longlong *)
                                            (*(longlong *)(&stack0x00000138 + lVar25) + 8) + 0x100),
                        iVar19 != 0)) && (1 < iVar19 - 3U)) {
                      *(undefined8 *)(puVar45 + 0x20) = 0;
                      *(undefined8 *)(puVar45 + -8) = 0x1069f6;
                      (*_DAT_)(1,0x194c1d0,0x194c220,0x116);
                    }
                    uVar27 = *(undefined8 *)(&stack0x00000138 + lVar25);
                    *(undefined8 *)(puVar45 + -8) = 0x106a06;
                    iVar19 = func_0x(uVar27);
                    if ((((iVar19 != 0) &&
                         ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000138 + lVar25) + 8) +
                                    0x109) & 1) == 0)) &&
                        (iVar19 = *(int *)(*(longlong *)
                                            (*(longlong *)(&stack0x00000138 + lVar25) + 8) + 0x100),
                        iVar19 != 0)) && (1 < iVar19 - 3U)) {
                      *(undefined8 *)(puVar45 + 0x20) = 0;
                      *(undefined8 *)(puVar45 + -8) = 0x106a56;
                      (*_DAT_)(1,0x194c250,0x194c220,0x119);
                    }
                  }
                  if ((lVar31 != 0) &&
                     ((0 < *(int *)(lVar31 + 0x78) || (0 < *(int *)(lVar31 + 0x74)))))
                  goto LAB_;
                  if ((*(byte *)(plVar60 + 0x4a) & 4) != 0) goto LAB_;
                  if ((*(byte *)(plVar60 + 0x4a) & 0x5a) != 0) goto LAB_;
                  if ((*(byte *)(plVar60 + 0x43) & 1) == 0) goto LAB_;
                  if (plVar60[0x1a] != 0) {
LAB_:
                    *(undefined8 *)(puVar45 + -8) = 0x106acf;
                    iVar19 = func_0x(plVar60);
                    if (iVar19 == 0) {
                      pcVar6 = *(code **)(*plVar60 + 0x270);
                      *(undefined8 *)(puVar45 + -8) = 0x106adf;
                      (*pcVar6)(plVar60);
                    }
                    if ((*(byte *)(plVar60 + 0x43) & 4) == 0) {
                      if ((*(byte *)(plVar60 + 0x4a) & 0x52) == 2) {
                        lVar35 = plVar60[0x1a];
                        *(undefined8 *)(puVar45 + -8) = 0x106b19;
                        cVar12 = func_0x(lVar35);
                        if (((cVar12 != '\0') && (*(char *)(plVar60[0x1a] + 0x130) == '\0')) &&
                           (*(undefined *)(plVar60[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x106b5d;
                          func_0x(0x1eadf00,0x1c,0x10,1);
                        }
                      }
                      uVar47 = (uint)((*(byte *)(plVar60 + 0x4a) & 0x5a) != 0);
                    }
                    else {
                      pcVar6 = *(code **)(*plVar60 + 0x1e8);
                      *(undefined8 *)(puVar45 + -8) = 0x106af5;
                      uVar27 = (*pcVar6)(plVar60);
                      *(undefined8 *)(puVar45 + -8) = 0x106afd;
                      uVar47 = func_0x(uVar27);
                    }
                    if (uVar47 == 0) goto LAB_;
                    goto LAB_;
                  }
                  pcVar6 = *(code **)(*plVar60 + 0x88);
                  *(undefined8 *)(puVar45 + -8) = 0x106ab2;
                  cVar12 = (*pcVar6)(plVar60);
                  if (cVar12 == '\0') goto LAB_;
                  pcVar6 = *(code **)(*plVar60 + 0x18);
                  *(undefined8 *)(puVar45 + -8) = 0x106abf;
                  cVar12 = (*pcVar6)(plVar60);
                  if (cVar12 != '\0') goto LAB_;
LAB_:
                  *(byte *)(plVar60 + 0x4a) = *(byte *)(plVar60 + 0x4a) | 4;
                  goto LAB_;
                }
LAB_:
                if (lVar31 != 0) {
LAB_:
                  if (((&stack0x00000130)[lVar25] & 0x1c) == 0) {
                    lVar35 = *(longlong *)(&stack0x00000138 + lVar25);
                    if (lVar35 != 0) {
                      iVar19 = *(int *)(*(longlong *)(lVar35 + 8) + 0x68);
                      bVar61 = iVar19 < 0;
                      if (bVar61) {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x106bc9;
                        (*_DAT_)(1,0x194c1a8,0x194a858,0xc9d);
                        iVar19 = *(int *)(*(longlong *)(lVar35 + 8) + 0x68);
                        bVar61 = iVar19 < 0;
                      }
                      if (((iVar19 != 0 && !bVar61) &&
                          (iVar19 = *(int *)(*(longlong *)
                                              (*(longlong *)(&stack0x00000138 + lVar25) + 8) + 0x100
                                            ), iVar19 != 0)) && (1 < iVar19 - 3U)) {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x106c14;
                        (*_DAT_)(1,0x194c1d0,0x194c220,0x116);
                      }
                      uVar27 = *(undefined8 *)(&stack0x00000138 + lVar25);
                      *(undefined8 *)(puVar45 + -8) = 0x106c24;
                      iVar19 = func_0x(uVar27);
                      if (((iVar19 != 0) &&
                          ((*(byte *)(*(longlong *)(*(longlong *)(&stack0x00000138 + lVar25) + 8) +
                                     0x109) & 1) == 0)) &&
                         ((iVar19 = *(int *)(*(longlong *)
                                              (*(longlong *)(&stack0x00000138 + lVar25) + 8) + 0x100
                                            ), iVar19 != 0 && (1 < iVar19 - 3U)))) {
                        *(undefined8 *)(puVar45 + 0x20) = 0;
                        *(undefined8 *)(puVar45 + -8) = 0x106c74;
                        (*_DAT_)(1,0x194c250,0x194c220,0x119);
                      }
                    }
                    if ((*(int *)(lVar31 + 0x78) < 1) && (*(int *)(lVar31 + 0x74) < 1)) {
                      if ((*(byte *)(plVar60 + 0x4a) & 4) == 0) {
                        if ((*(byte *)(plVar60 + 0x4a) & 0x5a) == 0) {
                          if ((*(byte *)(plVar60 + 0x43) & 1) != 0) {
                            if (plVar60[0x1a] == 0) {
                              pcVar6 = *(code **)(*plVar60 + 0x88);
                              *(undefined8 *)(puVar45 + -8) = 0x106ccb;
                              cVar12 = (*pcVar6)(plVar60);
                              if (cVar12 != '\0') {
                                pcVar6 = *(code **)(*plVar60 + 0x18);
                                *(undefined8 *)(puVar45 + -8) = 0x106cd8;
                                cVar12 = (*pcVar6)(plVar60);
                                if (cVar12 == '\0') {
                                  *(byte *)(plVar60 + 0x4a) = *(byte *)(plVar60 + 0x4a) | 4;
                                  goto LAB_;
                                }
                              }
                            }
                            *(undefined8 *)(puVar45 + -8) = 0x106cf1;
                            iVar19 = func_0x(plVar60);
                            if (iVar19 == 0) {
                              pcVar6 = *(code **)(*plVar60 + 0x270);
                              *(undefined8 *)(puVar45 + -8) = 0x106d01;
                              (*pcVar6)(plVar60);
                            }
                            if ((*(byte *)(plVar60 + 0x43) & 4) == 0) {
                              if ((*(byte *)(plVar60 + 0x4a) & 0x52) == 2) {
                                lVar35 = plVar60[0x1a];
                                *(undefined8 *)(puVar45 + -8) = 0x106d3b;
                                cVar12 = func_0x(lVar35);
                                if (((cVar12 != '\0') && (*(char *)(plVar60[0x1a] + 0x130) == '\0'))
                                   && (*(undefined *)(plVar60[0x1a] + 0x130) = 1,
                                      *_DAT_ != '\0')) {
                                  *(undefined8 *)(puVar45 + 0x20) = 0;
                                  *(undefined8 *)(puVar45 + -8) = 0x106d7f;
                                  func_0x(0x1eadf00,0x1c,0x10,1);
                                }
                              }
                              uVar47 = (uint)((*(byte *)(plVar60 + 0x4a) & 0x5a) != 0);
                            }
                            else {
                              pcVar6 = *(code **)(*plVar60 + 0x1e8);
                              *(undefined8 *)(puVar45 + -8) = 0x106d17;
                              uVar27 = (*pcVar6)(plVar60);
                              *(undefined8 *)(puVar45 + -8) = 0x106d1f;
                              uVar47 = func_0x(uVar27);
                            }
                            if (uVar47 != 0) goto LAB_;
                          }
                        }
                        else {
LAB_:
                          if ((*(byte *)(plVar60 + 0x4a) & 0x10) != 0) goto LAB_;
                        }
                      }
LAB_:
                      if ((*(byte *)(plVar60 + 0x4a) & 4) == 0) {
                        if ((*(byte *)(plVar60 + 0x4a) & 0x5a) == 0) {
                          if ((*(byte *)(plVar60 + 0x43) & 1) != 0) {
                            if (plVar60[0x1a] == 0) {
                              pcVar6 = *(code **)(*plVar60 + 0x88);
                              *(undefined8 *)(puVar45 + -8) = 0x106ddd;
                              cVar12 = (*pcVar6)(plVar60);
                              if (cVar12 != '\0') {
                                pcVar6 = *(code **)(*plVar60 + 0x18);
                                *(undefined8 *)(puVar45 + -8) = 0x106dea;
                                cVar12 = (*pcVar6)(plVar60);
                                if (cVar12 == '\0') {
                                  *(byte *)(plVar60 + 0x4a) = *(byte *)(plVar60 + 0x4a) | 4;
                                  goto LAB_;
                                }
                              }
                            }
                            *(undefined8 *)(puVar45 + -8) = 0x106e03;
                            iVar19 = func_0x(plVar60);
                            if (iVar19 == 0) {
                              pcVar6 = *(code **)(*plVar60 + 0x270);
                              *(undefined8 *)(puVar45 + -8) = 0x106e13;
                              (*pcVar6)(plVar60);
                            }
                            if ((*(byte *)(plVar60 + 0x43) & 4) == 0) {
                              if ((*(byte *)(plVar60 + 0x4a) & 0x52) == 2) {
                                lVar35 = plVar60[0x1a];
                                *(undefined8 *)(puVar45 + -8) = 0x106e4d;
                                cVar12 = func_0x(lVar35);
                                if (((cVar12 != '\0') && (*(char *)(plVar60[0x1a] + 0x130) == '\0'))
                                   && (*(undefined *)(plVar60[0x1a] + 0x130) = 1,
                                      *_DAT_ != '\0')) {
                                  *(undefined8 *)(puVar45 + 0x20) = 0;
                                  *(undefined8 *)(puVar45 + -8) = 0x106e91;
                                  func_0x(0x1eadf00,0x1c,0x10,1);
                                }
                              }
                              uVar47 = (uint)((*(byte *)(plVar60 + 0x4a) & 0x5a) != 0);
                            }
                            else {
                              pcVar6 = *(code **)(*plVar60 + 0x1e8);
                              *(undefined8 *)(puVar45 + -8) = 0x106e29;
                              uVar27 = (*pcVar6)(plVar60);
                              *(undefined8 *)(puVar45 + -8) = 0x106e31;
                              uVar47 = func_0x(uVar27);
                            }
                            if (uVar47 != 0) goto LAB_;
                          }
                        }
                        else {
LAB_:
                          if ((*(byte *)(plVar60 + 0x4a) & 0x40) != 0) goto LAB_;
                        }
                      }
                    }
                  }
LAB_:
                  *(undefined8 *)(puVar45 + -8) = 0x106eb9;
                  func_0x(lVar31,0);
                }
LAB_:
                *(undefined8 *)(puVar45 + -8) = 0x106ec1;
                iVar19 = func_0x(plVar60);
                if (iVar19 == 0) {
                  pcVar6 = *(code **)(*plVar60 + 0x270);
                  *(undefined8 *)(puVar45 + -8) = 0x106ed1;
                  (*pcVar6)(plVar60);
                }
                lVar31 = plVar60[0x1a];
                if (((&stack0x00000130)[lVar25] & 0x24) == 0) {
                  if ((*(byte *)(plVar60 + 0x4a) & 4) == 0) {
                    if ((*(byte *)(plVar60 + 0x4a) & 0x5a) != 0) goto LAB_;
                    if ((*(byte *)(plVar60 + 0x43) & 1) != 0) {
                      if (lVar31 == 0) {
                        pcVar6 = *(code **)(*plVar60 + 0x88);
                        *(undefined8 *)(puVar45 + -8) = 0x106f1c;
                        cVar12 = (*pcVar6)(plVar60);
                        if (cVar12 != '\0') {
                          pcVar6 = *(code **)(*plVar60 + 0x18);
                          *(undefined8 *)(puVar45 + -8) = 0x106f29;
                          cVar12 = (*pcVar6)(plVar60);
                          if (cVar12 == '\0') goto LAB_;
                        }
                      }
                      *(undefined8 *)(puVar45 + -8) = 0x106f39;
                      iVar19 = func_0x(plVar60);
                      if (iVar19 == 0) {
                        pcVar6 = *(code **)(*plVar60 + 0x270);
                        *(undefined8 *)(puVar45 + -8) = 0x106f49;
                        (*pcVar6)(plVar60);
                      }
                      if ((*(byte *)(plVar60 + 0x43) & 4) == 0) {
                        if ((*(byte *)(plVar60 + 0x4a) & 0x52) == 2) {
                          lVar35 = plVar60[0x1a];
                          *(undefined8 *)(puVar45 + -8) = 0x106f83;
                          cVar12 = func_0x(lVar35);
                          if (((cVar12 != '\0') && (*(char *)(plVar60[0x1a] + 0x130) == '\0')) &&
                             (*(undefined *)(plVar60[0x1a] + 0x130) = 1, *_DAT_ != '\0')) {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x106fc8;
                            func_0x(0x1eadf00,0x1c,0x10,1);
                          }
                        }
                        uVar47 = (uint)((*(byte *)(plVar60 + 0x4a) & 0x5a) != 0);
                      }
                      else {
                        pcVar6 = *(code **)(*plVar60 + 0x1e8);
                        *(undefined8 *)(puVar45 + -8) = 0x106f5f;
                        uVar27 = (*pcVar6)(plVar60);
                        *(undefined8 *)(puVar45 + -8) = 0x106f67;
                        uVar47 = func_0x(uVar27);
                      }
                      if (uVar47 != 0) goto LAB_;
                    }
                  }
                  if ((lVar31 == 0) || (*(int *)(lVar31 + 0x74) < 1)) goto LAB_;
                }
LAB_:
                psVar30 = *(short **)(&stack0x000000f8 + lVar25);
                *(undefined8 *)(puVar45 + -8) = 0x106ffe;
                iVar19 = func_0x(psVar30);
                if (iVar19 != 0) {
                  if (*psVar30 == 0) {
                    *(undefined8 *)(puVar45 + -8) = 0x107017;
                    func_0x();
                  }
                  else {
                    *(undefined8 *)(puVar45 + -8) = 0x10701e;
                    func_0x(puVar42,&stack0x000001b8 + lVar25);
                  }
                  uVar47 = 0;
                  uVar17 = *(ushort *)(&stack0x000001be + lVar25);
                  if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
                    if ((uVar17 >> 0xe & 1) == 0) {
                      uVar17 = uVar17 & 0xdfff;
                    }
                    else {
                      uVar17 = uVar17 | 0x2000;
                    }
                  }
                  if (uVar17 == 0xfffc) {
                    uVar47 = (uint)(*(ushort *)(&stack0x000001bc + lVar25) >> 5);
                  }
                  uVar20 = uVar20 + uVar47;
                }
                lVar31 = plVar60[0x1a];
                pcVar6 = *(code **)(*plVar60 + 0x88);
                *(undefined8 *)(puVar45 + -8) = 0x107079;
                cVar12 = (*pcVar6)(plVar60);
                if ((((cVar12 == '\0') && (lVar31 != 0)) &&
                    ((0 < *(int *)(lVar31 + 0x78) || (0 < *(int *)(lVar31 + 0x74))))) &&
                   (uVar20 < 0x1f74)) {
                  uVar20 = uVar20 + 8;
                }
                uVar20 = uVar20 + 0xe;
              }
              else {
                pcVar6 = *(code **)(*plVar60 + 0x88);
                *(undefined8 *)(puVar45 + -8) = 0x1067d4;
                cVar12 = (*pcVar6)(plVar60);
                if (cVar12 == '\0') goto LAB_;
                pcVar6 = *(code **)(*plVar60 + 0x18);
                *(undefined8 *)(puVar45 + -8) = 0x1067e1;
                cVar12 = (*pcVar6)(plVar60);
                if (cVar12 != '\0') goto LAB_;
LAB_:
                psVar50 = *(short **)(&stack0x000000f8 + lVar25);
                *(undefined8 *)(puVar45 + -8) = 0x1070bb;
                iVar19 = func_0x(psVar50);
                if (iVar19 != 0) {
                  uVar20 = *(uint *)(psVar30 + 2);
                  if (*psVar50 != 0) goto LAB_;
                  if (uVar20 == 0) {
                    iVar19 = 0;
                    *puVar42 = 0;
                    uVar20 = *(uint *)(psVar30 + 8);
                    uVar49 = (ulonglong)uVar20;
                    *(uint *)(psVar30 + 10) = uVar20;
                    pbVar48 = *(byte **)(psVar30 + 4);
                    bVar13 = *pbVar48;
                    if ((bVar13 & 0x10) != 0) {
                      uVar20 = uVar20 + 2 + (*(ushort *)(pbVar48 + uVar49) + 7 >> 3);
                      uVar49 = (ulonglong)uVar20;
                      *(uint *)(psVar30 + 10) = uVar20;
                      bVar13 = *pbVar48;
                    }
                    if ((bVar13 & 0x20) == 0) {
                      *(int *)(psVar30 + 2) = (int)uVar49;
                      psVar30[0xe] = 0;
                      *(undefined4 *)(psVar30 + 0xc) = *(undefined4 *)(psVar30 + 10);
                    }
                    else {
                      puVar57 = (ushort *)(pbVar48 + uVar49);
                      uVar17 = *puVar57;
                      psVar30[0xe] = uVar17;
                      if (uVar17 == 0) {
                        *(undefined8 *)(puVar45 + -8) = 0x107135;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x10713e;
                          lVar31 = func_0x();
                          if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar45 + -8) = 0x107158;
                            cVar12 = func_0x(0x1ead7c0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)(puVar45 + -8) = 0x107174;
                              (*_DAT_)(0x22,0x44,0x15,0x3eb);
                            }
                            else {
                              *(undefined8 *)(puVar45 + 0x20) = 0;
                              *(undefined8 *)(puVar45 + -8) = 0x10719a;
                              (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x80f);
                            }
                          }
                        }
                        uVar27 = *(undefined8 *)(psVar30 + 4);
                        *(undefined8 *)(puVar45 + -8) = 0x1071a8;
                        func_0x(uVar27,3);
                        uVar17 = psVar30[0xe];
                      }
                      uVar20 = *(int *)(psVar30 + 10) + 2 + (uint)uVar17 * 2;
                      *(uint *)(psVar30 + 0xc) = uVar20;
                      if (0x1f9e < uVar20) {
                        *(undefined8 *)(puVar45 + -8) = 0x1071cf;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x1071d8;
                          lVar31 = func_0x();
                          if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar45 + -8) = 0x1071f2;
                            cVar12 = func_0x(0x1ead7c0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)(puVar45 + -8) = 0x10720e;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar45 + 0x20) = 0;
                              *(undefined8 *)(puVar45 + -8) = 0x107234;
                              (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x816);
                            }
                          }
                        }
                        uVar27 = *(undefined8 *)(psVar30 + 4);
                        *(undefined8 *)(puVar45 + -8) = 0x107242;
                        func_0x(uVar27,4);
                      }
                      uVar17 = puVar57[(ushort)psVar30[0xe]];
                      *(uint *)(psVar30 + 2) = uVar17 & 0x7fff;
                      uVar20 = *(uint *)(psVar30 + 0xc);
                      if ((uVar17 & 0x7fff) < uVar20) {
                        *(undefined8 *)(puVar45 + -8) = 0x10726b;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 != '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x107274;
                          lVar31 = func_0x();
                          if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                            *(undefined8 *)(puVar45 + -8) = 0x10728e;
                            cVar12 = func_0x(0x1ead7c0);
                            if (cVar12 == '\0') {
                              *(undefined8 *)(puVar45 + -8) = 0x1072aa;
                              (*_DAT_)(0x22,0x44,0x15,0x3ec);
                            }
                            else {
                              *(undefined8 *)(puVar45 + 0x20) = 0;
                              *(undefined8 *)(puVar45 + -8) = 0x1072d0;
                              (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x81d);
                            }
                          }
                        }
                        uVar27 = *(undefined8 *)(psVar30 + 4);
                        *(undefined8 *)(puVar45 + -8) = 0x1072de;
                        func_0x(uVar27,4);
                        uVar20 = *(uint *)(psVar30 + 0xc);
                      }
                      uVar17 = psVar30[0xe];
                      puVar9 = puVar57;
                      if (uVar17 != 0) {
                        do {
                          uVar47 = puVar9[1] & 0x7fff;
                          if ((uVar47 < uVar20) || (*(uint *)(psVar30 + 2) < uVar47)) {
                            *(undefined8 *)(puVar45 + -8) = 0x10731e;
                            cVar12 = func_0x(0x1ead7c0);
                            if (cVar12 != '\0') {
                              *(undefined8 *)(puVar45 + -8) = 0x107327;
                              lVar31 = func_0x();
                              if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar45 + -8) = 0x107341;
                                cVar12 = func_0x(0x1ead7c0);
                                if (cVar12 == '\0') {
                                  *(undefined8 *)(puVar45 + -8) = 0x10735d;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar45 + 0x20) = 0;
                                  *(undefined8 *)(puVar45 + -8) = 0x107381;
                                  (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x82a);
                                }
                              }
                            }
                            uVar27 = *(undefined8 *)(psVar30 + 4);
                            *(undefined8 *)(puVar45 + -8) = 0x10738f;
                            func_0x(uVar27,4);
                          }
                          iVar19 = iVar19 + 1;
                          uVar17 = psVar30[0xe];
                          uVar20 = uVar47;
                          puVar9 = puVar9 + 1;
                        } while (iVar19 < (int)(uint)uVar17);
                        plVar58 = *(longlong **)(&stack0x00000100 + lVar25);
                        uVar59 = *(ulonglong *)(&stack0x000000b8 + lVar25);
                      }
                      uVar20 = (uint)uVar17;
                      if ((short)puVar57[(ulonglong)(uVar20 - 1) + 1] < 0) {
                        do {
                          lVar31 = *(longlong *)(psVar30 + 4);
                          lVar35 = (ulonglong)*(uint *)(psVar30 + 10) + lVar31;
                          uVar47 = *(ushort *)(lVar35 + (ulonglong)uVar20 * 2) & 0x7fff;
                          if (uVar20 == 1) {
                            uVar52 = *(uint *)(psVar30 + 0xc);
                            uVar46 = uVar52;
LAB_:
                            if ((uVar47 < uVar52) ||
                               (uVar20 = *(uint *)(psVar30 + 2), uVar20 < uVar47))
                            goto LAB_;
                          }
                          else {
                            uVar52 = *(ushort *)(lVar35 + -2 + (ulonglong)uVar20 * 2) & 0x7fff;
                            uVar46 = *(uint *)(psVar30 + 0xc);
                            if (uVar46 <= uVar52) goto LAB_;
LAB_:
                            *(undefined8 *)(puVar45 + -8) = 0x10741f;
                            func_0x(lVar31,7);
                            uVar46 = *(uint *)(psVar30 + 0xc);
                            uVar20 = *(uint *)(psVar30 + 2);
                          }
                          if ((uVar52 < uVar46) || (uVar20 < uVar52)) goto LAB_;
                          if (*(ushort *)((ulonglong)uVar52 + *(longlong *)(psVar30 + 4)) == 5) {
                            *puVar42 = *puVar42 | 2;
                            psVar30[0xe] = psVar30[0xe] + -1;
                            psVar30[0x15] = (short)uVar52;
                            uVar49 = *(ulonglong *)(psVar30 + 4);
                            uVar17 = *(ushort *)((ulonglong)(uVar52 & 0xffff) + 2 + uVar49);
                            uVar18 = psVar30[0x16] & 0xc7ff;
                            if ((uVar17 >> 0xe & 1) != 0) {
                              uVar18 = uVar17 & 0x3800 | uVar18;
                            }
                            psVar30[0x16] = uVar18;
                            uVar17 = (uVar18 ^ *(ushort *)
                                                ((ulonglong)(uVar52 & 0xffff) + 2 + uVar49)) & 0x7ff
                                     ^ uVar18;
                            psVar30[0x16] = uVar17;
                            uVar56 = (ulonglong)(ushort)psVar30[0x15];
                            uVar51 = uVar49 + 4 +
                                     (ulonglong)((uVar17 & 0x7ff) * 2) +
                                     uVar56 + (uVar18 >> 0xb & 7) * 2;
                            if (uVar51 < uVar56 + uVar49) {
                              *(undefined8 *)(puVar45 + -8) = 0x10757d;
                              func_0x(uVar56 + uVar49,0x19);
                              uVar17 = psVar30[0x16];
                              uVar56 = (ulonglong)(ushort)psVar30[0x15];
                              uVar49 = (ulonglong)*(uint *)(psVar30 + 4);
                            }
                            if (uVar47 - uVar52 <
                                (((uVar17 & 0x7ff) * 2 - (int)uVar56) - (int)uVar49) + (int)uVar51)
                            {
                              lVar31 = *(longlong *)(psVar30 + 4);
                              *(undefined8 *)(puVar45 + -8) = 0x1075b5;
                              func_0x(uVar56 + lVar31,0x19);
                              uVar17 = psVar30[0x16];
                            }
                            iVar19 = 0;
                            if (((uVar17 & 0x3800) != 0) &&
                               (puVar57 = (ushort *)
                                          (*(longlong *)(psVar30 + 4) + 4 +
                                          (ulonglong)(ushort)psVar30[0x15]), (uVar17 & 0x3800) != 0)
                               ) {
                              do {
                                if ((uVar17 & 0x7ff) < (*puVar57 & 0x7ff)) {
                                  uVar17 = psVar30[0x15];
                                  lVar31 = *(longlong *)(psVar30 + 4);
                                  *(undefined8 *)(puVar45 + -8) = 0x107617;
                                  func_0x((ulonglong)uVar17 + lVar31,0x1a);
                                  uVar17 = psVar30[0x16];
                                }
                                iVar19 = iVar19 + 1;
                                puVar57 = puVar57 + 1;
                              } while (iVar19 < (int)(uVar17 >> 0xb & 7));
                            }
                            break;
                          }
                          if (*(ushort *)((ulonglong)uVar52 + *(longlong *)(psVar30 + 4)) < 0x400)
                          break;
                          *puVar42 = *puVar42 | 1;
                          uVar17 = psVar30[0xe] - 1;
                          psVar30[0xe] = uVar17;
                          if ((uVar17 == 0) ||
                             (uVar20 = (uint)uVar17,
                             -1 < (short)puVar57[(ulonglong)(uVar17 - 1) + 1])) break;
                        } while( true );
                      }
                    }
                    iVar19 = 0;
                    if ((**(byte **)(psVar30 + 4) & 0x40) == 0) {
                      *(undefined4 *)(psVar30 + 0x13) = 0;
                    }
                    else {
                      *(undefined4 *)(psVar30 + 0x13) = *(undefined4 *)(psVar30 + 2);
                      *(int *)(psVar30 + 2) = *(int *)(psVar30 + 2) + 0xe;
                      *(undefined8 *)(puVar45 + -8) = 0x1074a0;
                      puVar33 = (ulonglong *)func_0x(puVar42);
                      uVar17 = (ushort)(*puVar33 >> 0x30);
                      if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
                        if ((uVar17 >> 0xe & 1) == 0) {
                          uVar17 = uVar17 & 0xdfff;
                        }
                        else {
                          uVar17 = uVar17 | 0x2000;
                        }
                      }
                      if (uVar17 == 0xfffc) {
                        iVar19 = (int)((*puVar33 >> 0x20 & 0xffff) >> 5);
                      }
                      *(int *)(psVar30 + 2) = *(int *)(psVar30 + 2) + iVar19;
                    }
                    uVar20 = *(uint *)(psVar30 + 2);
                    if ((*(ulonglong *)(psVar30 + 0xf) != 0) &&
                       (*(ulonglong *)(psVar30 + 0xf) <
                        (ulonglong)uVar20 + *(longlong *)(psVar30 + 4))) {
                      *(undefined8 *)(puVar45 + -8) = 0x10769a;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x1076a3;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x1076bd;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x1076d9;
                            (*_DAT_)(0x22,0x44,0x15,0x3fa);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x1076ff;
                            (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x886);
                          }
                        }
                      }
                      uVar27 = *(undefined8 *)(psVar30 + 4);
                      *(undefined8 *)(puVar45 + -8) = 0x10770d;
                      func_0x(uVar27,0x12);
                      uVar20 = *(uint *)(psVar30 + 2);
                    }
                    if ((uVar20 == 0) || (0x3f3c < uVar20)) {
                      *(undefined8 *)(puVar45 + -8) = 0x10772f;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x107738;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x107752;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') goto LAB_;
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x107794;
                          (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x88b);
                        }
                      }
                      goto LAB_;
                    }
                  }
                  goto LAB_;
                }
              }
            }
            else {
              uVar20 = *(uint *)(psVar30 + 2);
              if (*psVar50 == 0) {
                if (uVar20 == 0) {
                  iVar19 = 0;
                  *puVar42 = 0;
                  uVar20 = *(uint *)(psVar30 + 8);
                  uVar49 = (ulonglong)uVar20;
                  *(uint *)(psVar30 + 10) = uVar20;
                  pbVar48 = *(byte **)(psVar30 + 4);
                  bVar13 = *pbVar48;
                  if ((bVar13 & 0x10) != 0) {
                    uVar20 = uVar20 + 2 + (*(ushort *)(pbVar48 + uVar49) + 7 >> 3);
                    uVar49 = (ulonglong)uVar20;
                    *(uint *)(psVar30 + 10) = uVar20;
                    bVar13 = *pbVar48;
                  }
                  if ((bVar13 & 0x20) == 0) {
                    *(int *)(psVar30 + 2) = (int)uVar49;
                    psVar30[0xe] = 0;
                    *(undefined4 *)(psVar30 + 0xc) = *(undefined4 *)(psVar30 + 10);
                  }
                  else {
                    puVar57 = (ushort *)(pbVar48 + uVar49);
                    uVar17 = *puVar57;
                    psVar30[0xe] = uVar17;
                    if (uVar17 == 0) {
                      *(undefined8 *)(puVar45 + -8) = 0x10616b;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x106174;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x10618e;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x1061aa;
                            (*_DAT_)(0x22,0x44,0x15,0x3eb);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x1061d0;
                            (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x80f);
                          }
                        }
                      }
                      uVar27 = *(undefined8 *)(psVar30 + 4);
                      *(undefined8 *)(puVar45 + -8) = 0x1061de;
                      func_0x(uVar27,3);
                      uVar17 = psVar30[0xe];
                    }
                    uVar20 = *(int *)(psVar30 + 10) + 2 + (uint)uVar17 * 2;
                    *(uint *)(psVar30 + 0xc) = uVar20;
                    if (0x1f9e < uVar20) {
                      *(undefined8 *)(puVar45 + -8) = 0x106205;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x10620e;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x106228;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x106244;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x10626a;
                            (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x816);
                          }
                        }
                      }
                      uVar27 = *(undefined8 *)(psVar30 + 4);
                      *(undefined8 *)(puVar45 + -8) = 0x106278;
                      func_0x(uVar27,4);
                    }
                    uVar17 = puVar57[(ushort)psVar30[0xe]];
                    *(uint *)(psVar30 + 2) = uVar17 & 0x7fff;
                    uVar20 = *(uint *)(psVar30 + 0xc);
                    if ((uVar17 & 0x7fff) < uVar20) {
                      *(undefined8 *)(puVar45 + -8) = 0x1062a1;
                      cVar12 = func_0x(0x1ead7c0);
                      if (cVar12 != '\0') {
                        *(undefined8 *)(puVar45 + -8) = 0x1062aa;
                        lVar31 = func_0x();
                        if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                          *(undefined8 *)(puVar45 + -8) = 0x1062c4;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 == '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x1062e0;
                            (*_DAT_)(0x22,0x44,0x15,0x3ec);
                          }
                          else {
                            *(undefined8 *)(puVar45 + 0x20) = 0;
                            *(undefined8 *)(puVar45 + -8) = 0x106306;
                            (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x81d);
                          }
                        }
                      }
                      uVar27 = *(undefined8 *)(psVar30 + 4);
                      *(undefined8 *)(puVar45 + -8) = 0x106314;
                      func_0x(uVar27,4);
                      uVar20 = *(uint *)(psVar30 + 0xc);
                    }
                    uVar17 = psVar30[0xe];
                    puVar9 = puVar57;
                    if (uVar17 != 0) {
                      do {
                        uVar47 = puVar9[1] & 0x7fff;
                        if ((uVar47 < uVar20) || (*(uint *)(psVar30 + 2) < uVar47)) {
                          *(undefined8 *)(puVar45 + -8) = 0x106350;
                          cVar12 = func_0x(0x1ead7c0);
                          if (cVar12 != '\0') {
                            *(undefined8 *)(puVar45 + -8) = 0x106359;
                            lVar31 = func_0x();
                            if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar45 + -8) = 0x106373;
                              cVar12 = func_0x(0x1ead7c0);
                              if (cVar12 == '\0') {
                                *(undefined8 *)(puVar45 + -8) = 0x10638f;
                                (*_DAT_)(0x22,0x44,0x15,0x3ec);
                              }
                              else {
                                *(undefined8 *)(puVar45 + 0x20) = 0;
                                *(undefined8 *)(puVar45 + -8) = 0x1063b3;
                                (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x82a);
                              }
                            }
                          }
                          uVar27 = *(undefined8 *)(psVar30 + 4);
                          *(undefined8 *)(puVar45 + -8) = 0x1063c1;
                          func_0x(uVar27,4);
                        }
                        iVar19 = iVar19 + 1;
                        uVar17 = psVar30[0xe];
                        uVar20 = uVar47;
                        puVar9 = puVar9 + 1;
                      } while (iVar19 < (int)(uint)uVar17);
                      uVar59 = *(ulonglong *)(&stack0x000000b8 + lVar25);
                      plVar58 = (longlong *)(uVar59 + 0x30);
                    }
                    uVar20 = (uint)uVar17;
                    if ((short)puVar57[(ulonglong)(uVar20 - 1) + 1] < 0) {
                      do {
                        lVar31 = *(longlong *)(psVar30 + 4);
                        lVar35 = (ulonglong)*(uint *)(psVar30 + 10) + lVar31;
                        uVar47 = *(ushort *)(lVar35 + (ulonglong)uVar20 * 2) & 0x7fff;
                        if (uVar20 == 1) {
                          uVar52 = *(uint *)(psVar30 + 0xc);
                          uVar46 = uVar52;
LAB_:
                          if ((uVar47 < uVar52) ||
                             (uVar20 = *(uint *)(psVar30 + 2), uVar20 < uVar47)) goto LAB_;
                        }
                        else {
                          uVar52 = *(ushort *)(lVar35 + -2 + (ulonglong)uVar20 * 2) & 0x7fff;
                          uVar46 = *(uint *)(psVar30 + 0xc);
                          if (uVar46 <= uVar52) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar45 + -8) = 0x10644f;
                          func_0x(lVar31,7);
                          uVar46 = *(uint *)(psVar30 + 0xc);
                          uVar20 = *(uint *)(psVar30 + 2);
                        }
                        if ((uVar52 < uVar46) || (uVar20 < uVar52)) goto LAB_;
                        if (*(ushort *)((ulonglong)uVar52 + *(longlong *)(psVar30 + 4)) == 5) {
                          *puVar42 = *puVar42 | 2;
                          psVar30[0xe] = psVar30[0xe] + -1;
                          psVar30[0x15] = (short)uVar52;
                          uVar49 = *(ulonglong *)(psVar30 + 4);
                          uVar17 = *(ushort *)((ulonglong)(uVar52 & 0xffff) + 2 + uVar49);
                          uVar18 = psVar30[0x16] & 0xc7ff;
                          if ((uVar17 >> 0xe & 1) != 0) {
                            uVar18 = uVar17 & 0x3800 | uVar18;
                          }
                          psVar30[0x16] = uVar18;
                          uVar17 = (uVar18 ^ *(ushort *)((ulonglong)(uVar52 & 0xffff) + 2 + uVar49))
                                   & 0x7ff ^ uVar18;
                          psVar30[0x16] = uVar17;
                          uVar56 = (ulonglong)(ushort)psVar30[0x15];
                          uVar51 = uVar56 + 4 +
                                   (ulonglong)((uVar17 & 0x7ff) * 2) +
                                   uVar49 + (uVar18 >> 0xb & 7) * 2;
                          if (uVar51 < uVar56 + uVar49) {
                            *(undefined8 *)(puVar45 + -8) = 0x1065ad;
                            func_0x(uVar56 + uVar49,0x19);
                            uVar17 = psVar30[0x16];
                            uVar56 = (ulonglong)(ushort)psVar30[0x15];
                            uVar49 = (ulonglong)*(uint *)(psVar30 + 4);
                          }
                          if (uVar47 - uVar52 <
                              (((uVar17 & 0x7ff) * 2 - (int)uVar56) - (int)uVar49) + (int)uVar51) {
                            lVar31 = *(longlong *)(psVar30 + 4);
                            *(undefined8 *)(puVar45 + -8) = 0x1065e5;
                            func_0x(uVar56 + lVar31,0x19);
                            uVar17 = psVar30[0x16];
                          }
                          iVar19 = 0;
                          if (((uVar17 & 0x3800) != 0) &&
                             (puVar57 = (ushort *)
                                        (*(longlong *)(psVar30 + 4) + 4 +
                                        (ulonglong)(ushort)psVar30[0x15]), (uVar17 & 0x3800) != 0))
                          {
                            do {
                              if ((uVar17 & 0x7ff) < (*puVar57 & 0x7ff)) {
                                uVar17 = psVar30[0x15];
                                lVar31 = *(longlong *)(psVar30 + 4);
                                *(undefined8 *)(puVar45 + -8) = 0x106647;
                                func_0x((ulonglong)uVar17 + lVar31,0x1a);
                                uVar17 = psVar30[0x16];
                              }
                              iVar19 = iVar19 + 1;
                              puVar57 = puVar57 + 1;
                            } while (iVar19 < (int)(uVar17 >> 0xb & 7));
                          }
                          break;
                        }
                        if (*(ushort *)((ulonglong)uVar52 + *(longlong *)(psVar30 + 4)) < 0x400)
                        break;
                        *puVar42 = *puVar42 | 1;
                        uVar17 = psVar30[0xe] - 1;
                        psVar30[0xe] = uVar17;
                        if ((uVar17 == 0) ||
                           (uVar20 = (uint)uVar17, -1 < (short)puVar57[(ulonglong)(uVar17 - 1) + 1])
                           ) break;
                      } while( true );
                    }
                  }
                  iVar19 = 0;
                  if ((**(byte **)(psVar30 + 4) & 0x40) == 0) {
                    *(undefined4 *)(psVar30 + 0x13) = 0;
                  }
                  else {
                    *(undefined4 *)(psVar30 + 0x13) = *(undefined4 *)(psVar30 + 2);
                    *(int *)(psVar30 + 2) = *(int *)(psVar30 + 2) + 0xe;
                    *(undefined8 *)(puVar45 + -8) = 0x1064d0;
                    puVar33 = (ulonglong *)func_0x(puVar42);
                    uVar17 = (ushort)(*puVar33 >> 0x30);
                    if ((((uint)(int)(short)uVar17 >> 1 ^ (int)(short)uVar17) & 0x2000) != 0) {
                      if ((uVar17 >> 0xe & 1) == 0) {
                        uVar17 = uVar17 & 0xdfff;
                      }
                      else {
                        uVar17 = uVar17 | 0x2000;
                      }
                    }
                    if (uVar17 == 0xfffc) {
                      iVar19 = (int)((*puVar33 >> 0x20 & 0xffff) >> 5);
                    }
                    *(int *)(psVar30 + 2) = *(int *)(psVar30 + 2) + iVar19;
                  }
                  uVar20 = *(uint *)(psVar30 + 2);
                  if ((*(ulonglong *)(psVar30 + 0xf) != 0) &&
                     (*(ulonglong *)(psVar30 + 0xf) < (ulonglong)uVar20 + *(longlong *)(psVar30 + 4)
                     )) {
                    *(undefined8 *)(puVar45 + -8) = 0x1066ca;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)(puVar45 + -8) = 0x1066d3;
                      lVar31 = func_0x();
                      if ((lVar31 != 0) && (*(char *)(lVar31 + 0x499) != '\0')) {
                        *(undefined8 *)(puVar45 + -8) = 0x1066ed;
                        cVar12 = func_0x(0x1ead7c0);
                        if (cVar12 == '\0') {
                          *(undefined8 *)(puVar45 + -8) = 0x106709;
                          (*_DAT_)(0x22,0x44,0x15,0x3fa);
                        }
                        else {
                          *(undefined8 *)(puVar45 + 0x20) = 0;
                          *(undefined8 *)(puVar45 + -8) = 0x10672f;
                          (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x886);
                        }
                      }
                    }
                    uVar27 = *(undefined8 *)(psVar30 + 4);
                    *(undefined8 *)(puVar45 + -8) = 0x10673d;
                    func_0x(uVar27,0x12);
                    uVar20 = *(uint *)(psVar30 + 2);
                  }
                  if ((uVar20 != 0) && (uVar20 < 0x3f3d)) goto LAB_;
                  *(undefined8 *)(puVar45 + -8) = 0x10675f;
                  cVar12 = func_0x(0x1ead7c0);
                  if (cVar12 != '\0') {
                    *(undefined8 *)(puVar45 + -8) = 0x10676c;
                    lVar31 = func_0x();
                    if ((lVar31 == 0) || (*(char *)(lVar31 + 0x499) == '\0')) goto LAB_;
                    *(undefined8 *)(puVar45 + -8) = 0x10678e;
                    cVar12 = func_0x(0x1ead7c0);
                    if (cVar12 != '\0') {
                      *(undefined8 *)(puVar45 + 0x20) = 0;
                      *(undefined8 *)(puVar45 + -8) = 0x1067ba;
                      (*_DAT_)(1,0x179d1cc,0x18bd2b8,0x88b);
                      goto LAB_;
                    }
LAB_:
                    *(undefined8 *)(puVar45 + -8) = 0x10776e;
                    (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  }
LAB_:
                  uVar27 = *(undefined8 *)(psVar30 + 4);
                  *(undefined8 *)(puVar45 + -8) = 0x1077a2;
                  func_0x(uVar27,5);
                  uVar20 = *(uint *)(psVar30 + 2);
                }
LAB_:
                if ((uVar20 < 9) &&
                   (((**(byte **)(psVar30 + 4) & 0xe) == 0 ||
                    ((**(byte **)(psVar30 + 4) & 0xe) == 0xc)))) {
                  uVar20 = 9;
                }
                plVar60 = *(longlong **)(&stack0x00000110 + lVar25);
              }
              else {
LAB_:
                if (uVar20 == 0) {
                  *(undefined8 *)(puVar45 + -8) = 0x1077d9;
                  func_0x(puVar42);
                  uVar20 = *(uint *)(psVar30 + 2);
                }
                if ((uVar20 < 9) &&
                   (((**(byte **)(psVar30 + 4) & 0x1c) == 0 ||
                    ((**(byte **)(psVar30 + 4) & 0x1c) == 0xc)))) {
                  uVar20 = 9;
                }
              }
            }
            lVar31 = *plVar58;
            lVar35 = *(longlong *)(&stack0x00000118 + lVar25);
            bVar13 = *(byte *)(*(longlong *)(lVar35 + 8) + 0x107);
            iVar19 = *(int *)(lVar31 + 0x40);
            *(undefined8 *)(puVar45 + -8) = 0x10782e;
            uVar27 = func_0x(lVar35,&stack0x00000250 + lVar25);
            *(undefined8 *)(puVar45 + 0x40) = *(undefined8 *)(lVar31 + 0x10);
            lVar31 = *(longlong *)(&stack0x00000120 + lVar25);
            *(undefined2 *)(puVar45 + 0x38) = *(undefined2 *)(lVar31 + 8);
            *(longlong *)(puVar45 + 0x30) = lVar31;
            *(uint *)(puVar45 + 0x28) = bVar13 >> 6 & 1;
            *(uint *)(puVar45 + 0x20) = (uint)(iVar19 != 1);
            lVar31 = *(longlong *)(&stack0x00000118 + lVar25);
            *(undefined8 *)(puVar45 + -8) = 0x107870;
            func_0x(&stack0x000002d8 + lVar25,plVar60,uVar27,lVar31);
            *(undefined *)((longlong)plVar58 + 0x27e) = 0;
            if (*(char *)(*(longlong *)(lVar31 + 0x20) + 0x1cdf) == '\0') {
              bVar39 = 0;
              bVar13 = 0;
            }
            else if (*(char *)(*(longlong *)(lVar31 + 0x20) + 0x1cdc) == '\0') {
              bVar39 = 0;
              bVar13 = 0;
            }
            else {
              bVar39 = *(byte *)(*(longlong *)(lVar31 + 8) + 0x109) >> 6 & 1;
              bVar13 = *(byte *)(*(longlong *)(lVar31 + 8) + 0x109) >> 6 & 1;
            }
            lVar35 = *plVar58;
            *(uint *)(puVar45 + 0x28) = (uint)bVar39 * 2;
            *(uint *)(puVar45 + 0x20) = (uint)bVar13;
            uVar27 = *(undefined8 *)(lVar35 + 0x20);
            *(undefined8 *)(puVar45 + -8) = 0x1078f2;
            func_0x(&stack0x000002a8 + lVar25,&stack0x000002d8 + lVar25,uVar27,uVar20);
            *(undefined8 *)(&stack0x00000248 + lVar25) = *(undefined8 *)(lVar31 + 0x14);
            *(undefined8 *)(puVar45 + -8) = 0x10790c;
            uVar27 = func_0x(&stack0x00000248 + lVar25);
            lVar35 = plVar60[6];
            *(undefined8 *)(puVar45 + -8) = 0x107918;
            cVar12 = func_0x(lVar35,uVar27);
            if (cVar12 != '\0') {
              *(undefined4 *)(&stack0x000000a8 + lVar25) = 1;
            }
            uVar20 = 0;
            do {
              *(undefined8 *)(puVar45 + -8) = 0x107943;
              func_0x(&stack0x000002a8 + lVar25);
              if ((*(int *)(&stack0x00000780 + lVar25) == 0) &&
                 (*(short *)(&stack0x00000784 + lVar25) == 0)) goto LAB_;
              if (*(char *)(*(longlong *)(*plVar58 + 0x20) + 1) == '\x05') {
LAB_:
                puVar28 = (undefined8 *)*plVar58;
                *(undefined **)(puVar45 + 0x20) = &stack0x00000278 + lVar25;
                uVar27 = *puVar28;
                *(undefined8 *)(puVar45 + -8) = 0x107ae2;
                iVar19 = func_0x(uVar27,&stack0x00000778 + lVar25,3,2);
                if (iVar19 == 0) {
                  if ((*(char *)(*(longlong *)(*plVar58 + 0x20) + 1) != '\x05') &&
                     (*(char *)(*(longlong *)(*plVar58 + 0x20) + 2) != '\0')) {
                    if ((*(byte *)(plVar58 + 0x14) & 2) != 0) {
                      *(undefined8 *)(puVar45 + -8) = 0x107bc9;
                      iVar19 = func_0x(plVar58 + 0x15);
                      if (iVar19 != 0) {
                        *(longlong *)(*plVar58 + 0x30) = *(longlong *)(*plVar58 + 0x30) + -1;
                      }
                    }
                    *(undefined *)(plVar58 + 0x14) = 0;
                    *(undefined4 *)((longlong)plVar58 + 0x9c) = 0;
                    *(undefined4 *)(plVar58 + 0x17) = 0;
                    goto LAB_;
                  }
                }
                else {
                  puVar29 = (undefined4 *)(&stack0x00000338 + lVar25);
                  puVar36 = (undefined4 *)(&stack0x00000538 + lVar25);
                  lVar35 = 2;
                  do {
                    uVar24 = puVar29[1];
                    uVar5 = puVar29[2];
                    uVar10 = puVar29[3];
                    *puVar36 = *puVar29;
                    puVar36[1] = uVar24;
                    puVar36[2] = uVar5;
                    puVar36[3] = uVar10;
                    uVar24 = puVar29[5];
                    uVar5 = puVar29[6];
                    uVar10 = puVar29[7];
                    puVar36[4] = puVar29[4];
                    puVar36[5] = uVar24;
                    puVar36[6] = uVar5;
                    puVar36[7] = uVar10;
                    uVar24 = puVar29[9];
                    uVar5 = puVar29[10];
                    uVar10 = puVar29[0xb];
                    puVar36[8] = puVar29[8];
                    puVar36[9] = uVar24;
                    puVar36[10] = uVar5;
                    puVar36[0xb] = uVar10;
                    uVar24 = puVar29[0xd];
                    uVar5 = puVar29[0xe];
                    uVar10 = puVar29[0xf];
                    puVar36[0xc] = puVar29[0xc];
                    puVar36[0xd] = uVar24;
                    puVar36[0xe] = uVar5;
                    puVar36[0xf] = uVar10;
                    uVar24 = puVar29[0x11];
                    uVar5 = puVar29[0x12];
                    uVar10 = puVar29[0x13];
                    puVar36[0x10] = puVar29[0x10];
                    puVar36[0x11] = uVar24;
                    puVar36[0x12] = uVar5;
                    puVar36[0x13] = uVar10;
                    uVar24 = puVar29[0x15];
                    uVar5 = puVar29[0x16];
                    uVar10 = puVar29[0x17];
                    puVar36[0x14] = puVar29[0x14];
                    puVar36[0x15] = uVar24;
                    puVar36[0x16] = uVar5;
                    puVar36[0x17] = uVar10;
                    uVar24 = puVar29[0x19];
                    uVar5 = puVar29[0x1a];
                    uVar10 = puVar29[0x1b];
                    puVar36[0x18] = puVar29[0x18];
                    puVar36[0x19] = uVar24;
                    puVar36[0x1a] = uVar5;
                    puVar36[0x1b] = uVar10;
                    uVar24 = puVar29[0x1d];
                    uVar5 = puVar29[0x1e];
                    uVar10 = puVar29[0x1f];
                    puVar36[0x1c] = puVar29[0x1c];
                    puVar36[0x1d] = uVar24;
                    puVar36[0x1e] = uVar5;
                    puVar36[0x1f] = uVar10;
                    puVar29 = puVar29 + 0x20;
                    lVar35 = lVar35 + -1;
                    puVar36 = puVar36 + 0x20;
                  } while (lVar35 != 0);
                  *(undefined4 *)(puVar45 + 0x30) = 1;
                  *(undefined **)(puVar45 + 0x28) = &stack0x00000538 + lVar25;
                  *(undefined8 *)(puVar45 + 0x20) = 0;
                  *(undefined8 *)(puVar45 + -8) = 0x107b87;
                  func_0x
                            (plVar58,&stack0x00000278 + lVar25,&stack0x00000200 + lVar25,0);
                }
                if (*(int *)(plVar58 + 0x18) == 4) {
                  *(undefined8 *)(puVar45 + -8) = 0x107bfe;
                  uVar15 = func_0x(&stack0x000002a8 + lVar25);
                  *(undefined *)((longlong)plVar58 + 0x27e) = uVar15;
                  break;
                }
              }
              else {
                pcVar6 = *(code **)(*plVar60 + 0x28);
                *(undefined8 *)(puVar45 + -8) = 0x107975;
                cVar14 = (*pcVar6)(plVar60);
                if ((cVar14 != '\0') ||
                   (((*(uint *)(lVar31 + 0x14) & 0xe0000000) == 0x80000000 &&
                    (*(ushort *)(lVar31 + 0x18) < 0x100)))) goto LAB_;
                uVar3 = *(undefined2 *)(plVar60[6] + 0x6b8);
                (&stack0x000007a6)[lVar25] = 6;
                *(undefined2 *)(&stack0x000007a4 + lVar25) = uVar3;
                *(undefined8 *)(&stack0x0000079c + lVar25) = 0;
                *(undefined4 *)(&stack0x00000798 + lVar25) =
                     *(undefined4 *)(&stack0x00000780 + lVar25);
                *(undefined2 *)(&stack0x0000079c + lVar25) =
                     *(undefined2 *)(&stack0x00000784 + lVar25);
                if ((*(char *)(*(longlong *)(*plVar58 + 0x20) + 2) == '\0') &&
                   (((*(char *)(*(longlong *)(lVar31 + 0x20) + 0x1cdf) == '\0' ||
                     (*(char *)(*(longlong *)(lVar31 + 0x20) + 0x1cdc) == '\0')) ||
                    ((*(byte *)(*(longlong *)(lVar31 + 8) + 0x109) & 0x40) == 0)))) {
                  uVar27 = *(undefined8 *)(lVar31 + 0x14);
                  if (((int)uVar27 == 8) && ((short)((ulonglong)uVar27 >> 0x20) == 0))
                  goto LAB_;
                  *(undefined8 *)(&stack0x00000228 + lVar25) = uVar27;
                  lVar35 = plVar58[1];
                  *(undefined8 *)(puVar45 + 0x60) = 0;
                  *(longlong **)(puVar45 + 0x58) = plVar58 + 0x12;
                  *(undefined **)(puVar45 + 0x50) = &stack0x00000228 + lVar25;
                  *(undefined8 *)(puVar45 + 0x48) = 0;
                  *(undefined4 *)(puVar45 + 0x40) = 0;
                  puVar45[0x38] = 0;
                  *(undefined4 *)(puVar45 + 0x30) = 0;
                  *(undefined4 *)(puVar45 + 0x28) = 1;
                  *(undefined4 *)(puVar45 + 0x20) = 1;
                  uVar27 = *(undefined8 *)(lVar35 + 8);
                  *(undefined8 *)(puVar45 + -8) = 0x107a81;
                  iVar19 = func_0x(uVar27,&stack0x00000798 + lVar25,8,1);
                }
                else {
                  *(undefined4 *)(puVar45 + 0x38) = 1;
                  *(undefined4 *)(puVar45 + 0x30) = 0;
                  *(undefined4 *)(puVar45 + 0x28) = 0;
                  *(longlong **)(puVar45 + 0x20) = plVar58 + 0x12;
                  *(undefined8 *)(puVar45 + -8) = 0x107ab2;
                  iVar19 = func_0x(plVar58,&stack0x00000798 + lVar25,2);
                }
                if (-1 < iVar19) goto LAB_;
              }
LAB_:
              uVar20 = uVar20 + 1;
            } while (uVar20 < *(uint *)(&stack0x000000a8 + lVar25));
            if (((cVar12 == '\0') || (*(int *)(plVar58 + 0x18) == 4)) ||
               ((*(int *)(&stack0x00000780 + lVar25) == 0 &&
                (*(short *)(&stack0x00000784 + lVar25) == 0)))) {
LAB_:
              puVar32 = *(undefined8 **)(&stack0x000000f0 + lVar25);
              puVar29 = (undefined4 *)(uVar59 + 0x530);
            }
            else {
              *(undefined8 *)(puVar45 + -8) = 0x107c41;
              func_0x(&stack0x000001c8 + lVar25);
              lVar31 = *(longlong *)(lVar31 + 8);
              *(undefined8 *)(puVar45 + -8) = 0x107c58;
              func_0x(&stack0x000001c8 + lVar25,lVar31 + 0x3c0);
              *(undefined4 *)(&stack0x00000178 + lVar25) =
                   *(undefined4 *)(&stack0x00000780 + lVar25);
              *(undefined2 *)(&stack0x0000017c + lVar25) =
                   *(undefined2 *)(&stack0x00000784 + lVar25);
              *(undefined8 *)(puVar45 + -8) = 0x107c85;
              func_0x(&stack0x00000230 + lVar25,&stack0x00000178 + lVar25);
              (&stack0x000000b4)[lVar25] = 4;
              *(undefined8 *)(puVar45 + -8) = 0x107c98;
              uVar24 = func_0x(4,1);
              *(undefined8 *)(puVar45 + -8) = 0x107ca2;
              uVar24 = func_0x(uVar24,2);
              *(undefined8 *)(puVar45 + -8) = 0x107cac;
              uVar24 = func_0x(uVar24,0x20);
              *(undefined8 *)(puVar45 + -8) = 0x107cba;
              func_0x(&stack0x00000288 + lVar25,uVar24);
              *(longlong **)(puVar45 + 0x30) = plVar60;
              puVar45[0x28] = 1;
              *(undefined4 *)(puVar45 + 0x20) = 1;
              lVar31 = plVar60[6];
              *(undefined8 *)(puVar45 + -8) = 0x107ce3;
              func_0x
                        (lVar31,&stack0x000001c8 + lVar25,&stack0x00000230 + lVar25,
                         &stack0x000000b4 + lVar25);
              *(undefined8 *)(puVar45 + -8) = 0x107cf0;
              func_0x(&stack0x00000288 + lVar25);
              puVar29 = (undefined4 *)(uVar59 + 0x530);
              puVar32 = *(undefined8 **)(&stack0x000000f0 + lVar25);
            }
          }
          lVar35 = 2;
          lVar31 = 0;
          if (*(int *)(plVar58 + 0x18) != 4) {
            puVar36 = (undefined4 *)(&stack0x00000338 + lVar25);
            puVar37 = (undefined4 *)(&stack0x00000638 + lVar25);
            do {
              uVar24 = puVar36[1];
              uVar5 = puVar36[2];
              uVar10 = puVar36[3];
              *puVar37 = *puVar36;
              puVar37[1] = uVar24;
              puVar37[2] = uVar5;
              puVar37[3] = uVar10;
              uVar24 = puVar36[5];
              uVar5 = puVar36[6];
              uVar10 = puVar36[7];
              puVar37[4] = puVar36[4];
              puVar37[5] = uVar24;
              puVar37[6] = uVar5;
              puVar37[7] = uVar10;
              uVar24 = puVar36[9];
              uVar5 = puVar36[10];
              uVar10 = puVar36[0xb];
              puVar37[8] = puVar36[8];
              puVar37[9] = uVar24;
              puVar37[10] = uVar5;
              puVar37[0xb] = uVar10;
              uVar24 = puVar36[0xd];
              uVar5 = puVar36[0xe];
              uVar10 = puVar36[0xf];
              puVar37[0xc] = puVar36[0xc];
              puVar37[0xd] = uVar24;
              puVar37[0xe] = uVar5;
              puVar37[0xf] = uVar10;
              uVar24 = puVar36[0x11];
              uVar5 = puVar36[0x12];
              uVar10 = puVar36[0x13];
              puVar37[0x10] = puVar36[0x10];
              puVar37[0x11] = uVar24;
              puVar37[0x12] = uVar5;
              puVar37[0x13] = uVar10;
              uVar24 = puVar36[0x15];
              uVar5 = puVar36[0x16];
              uVar10 = puVar36[0x17];
              puVar37[0x14] = puVar36[0x14];
              puVar37[0x15] = uVar24;
              puVar37[0x16] = uVar5;
              puVar37[0x17] = uVar10;
              uVar24 = puVar36[0x19];
              uVar5 = puVar36[0x1a];
              uVar10 = puVar36[0x1b];
              puVar37[0x18] = puVar36[0x18];
              puVar37[0x19] = uVar24;
              puVar37[0x1a] = uVar5;
              puVar37[0x1b] = uVar10;
              uVar24 = puVar36[0x1d];
              uVar5 = puVar36[0x1e];
              uVar10 = puVar36[0x1f];
              puVar37[0x1c] = puVar36[0x1c];
              puVar37[0x1d] = uVar24;
              puVar37[0x1e] = uVar5;
              puVar37[0x1f] = uVar10;
              puVar36 = puVar36 + 0x20;
              lVar35 = lVar35 + -1;
              puVar37 = puVar37 + 0x20;
            } while (lVar35 != 0);
            *(undefined **)(puVar45 + 0x20) = &stack0x00000638 + lVar25;
            *(undefined8 *)(puVar45 + -8) = 0x107db3;
            func_0x(plVar58,&stack0x00000200 + lVar25,0,0);
          }
          if (puVar32 != (undefined8 *)0x0) {
            if ((longlong *)plVar58[5] == (longlong *)0x0) {
              if (*(int *)(plVar58 + 0x18) != 2) {
                *(undefined8 *)(puVar45 + -8) = 0x107dde;
                func_0x(plVar58,1);
                if (*(int *)(plVar58 + 0x18) != 2) {
                  lVar31 = *(longlong *)plVar58[5];
                }
              }
            }
            else {
              lVar31 = *(longlong *)plVar58[5];
            }
            *(undefined4 *)(puVar32 + 1) = *(undefined4 *)(lVar31 + 0x20);
            *(undefined2 *)((longlong)puVar32 + 0xc) = *(undefined2 *)(lVar31 + 0x24);
            *(undefined2 *)((longlong)puVar32 + 0xe) = 0;
            *puVar32 = 0;
            *(undefined4 *)((longlong)puVar32 + 0x1c) = 1;
            puVar32[2] = 0;
            *(undefined2 *)(puVar32 + 3) = 0;
          }
        }
        lVar31 = 2;
        puVar36 = (undefined4 *)(&stack0x00000338 + lVar25);
        do {
          uVar24 = puVar29[1];
          uVar5 = puVar29[2];
          uVar10 = puVar29[3];
          *puVar36 = *puVar29;
          puVar36[1] = uVar24;
          puVar36[2] = uVar5;
          puVar36[3] = uVar10;
          uVar24 = puVar29[5];
          uVar5 = puVar29[6];
          uVar10 = puVar29[7];
          puVar36[4] = puVar29[4];
          puVar36[5] = uVar24;
          puVar36[6] = uVar5;
          puVar36[7] = uVar10;
          uVar24 = puVar29[9];
          uVar5 = puVar29[10];
          uVar10 = puVar29[0xb];
          puVar36[8] = puVar29[8];
          puVar36[9] = uVar24;
          puVar36[10] = uVar5;
          puVar36[0xb] = uVar10;
          uVar24 = puVar29[0xd];
          uVar5 = puVar29[0xe];
          uVar10 = puVar29[0xf];
          puVar36[0xc] = puVar29[0xc];
          puVar36[0xd] = uVar24;
          puVar36[0xe] = uVar5;
          puVar36[0xf] = uVar10;
          uVar24 = puVar29[0x11];
          uVar5 = puVar29[0x12];
          uVar10 = puVar29[0x13];
          puVar36[0x10] = puVar29[0x10];
          puVar36[0x11] = uVar24;
          puVar36[0x12] = uVar5;
          puVar36[0x13] = uVar10;
          uVar24 = puVar29[0x15];
          uVar5 = puVar29[0x16];
          uVar10 = puVar29[0x17];
          puVar36[0x14] = puVar29[0x14];
          puVar36[0x15] = uVar24;
          puVar36[0x16] = uVar5;
          puVar36[0x17] = uVar10;
          uVar24 = puVar29[0x19];
          uVar5 = puVar29[0x1a];
          uVar10 = puVar29[0x1b];
          puVar36[0x18] = puVar29[0x18];
          puVar36[0x19] = uVar24;
          puVar36[0x1a] = uVar5;
          puVar36[0x1b] = uVar10;
          uVar24 = puVar29[0x1d];
          uVar5 = puVar29[0x1e];
          uVar10 = puVar29[0x1f];
          puVar36[0x1c] = puVar29[0x1c];
          puVar36[0x1d] = uVar24;
          puVar36[0x1e] = uVar5;
          puVar36[0x1f] = uVar10;
          puVar29 = puVar29 + 0x20;
          lVar31 = lVar31 + -1;
          puVar36 = puVar36 + 0x20;
        } while (lVar31 != 0);
        *(undefined8 *)(puVar45 + 0x20) = 0;
        *(undefined8 *)(puVar45 + -8) = 0x107ea5;
        func_0x(plVar58,&stack0x00000200 + lVar25,&stack0x00000338 + lVar25,1);
        *(uint *)(uVar59 + 0x634) = *(uint *)(uVar59 + 0x634) | 1;
        if (*(int *)(&stack0x000000ac + lVar25) != 0) {
          puVar28 = *(undefined8 **)(*(longlong *)(uVar59 + 0x28) + 0x18);
          *(int *)((longlong)puVar28 + 0xc) = *(int *)((longlong)puVar28 + 0xc) + 1;
          if (*(uint *)(puVar28 + 1) <= *(uint *)((longlong)puVar28 + 0xc)) {
            *(undefined4 *)(puVar28 + 1) = 0;
            *puVar28 = 0;
          }
          if (*(int *)(&stack0x00000094 + lVar25) != 0) {
            *(undefined4 *)(uVar59 + 0x548) = *(undefined4 *)(&stack0x00000098 + lVar25);
            *(uint *)(uVar59 + 0x54c) = *puVar1;
          }
        }
        uVar27 = *(undefined8 *)(&stack0x00000238 + lVar25);
        *(undefined8 *)(puVar45 + -8) = 0x107efb;
        func_0x(uVar59,uVar27,0,1);
        **(ulonglong **)(&stack0x00000240 + lVar25) = uVar59;
        goto LAB_;
      }
      goto LAB_;
    }
    if (iVar21 < 3) {
      *(undefined8 *)(&stack0x000000d8 + lVar25) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103704;
      iVar23 = func_0x(uVar59);
      goto LAB_;
    }
  }
  else {
    bVar61 = iVar21 < 0x32;
  }
  *(undefined8 *)(&stack0x000000d8 + lVar25) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103677;
  iVar23 = func_0x(uVar59);
  if (!bVar61) goto LAB_;
LAB_:
  if (1 < iVar23 - 1U) goto LAB_;
  iVar21 = iVar21 + 1;
  *(int *)(&stack0x000000ac + lVar25) = iVar21;
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x103698;
  func_0x(uVar59 + 0x30);
  if (*(char *)(*(longlong *)(uVar59 + 0x28) + 0x29) == '\0') {
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1036b0;
    func_0x(10);
  }
  goto LAB_;
LAB_:
  *(undefined4 *)(uVar51 + 0xf0) = 4;
  lVar35 = *(longlong *)(lVar35 + 0x30);
  if (*(longlong *)(lVar35 + 0x1b28) != 0) {
    uVar20 = *(uint *)(*(longlong *)(uVar51 + 0x100) + 0x10);
    if (((((uVar20 & 1) == 0) || ((uVar20 & 0x40) != 0)) || (*(char *)(lVar35 + 0x1cd2) == '\0')) ||
       (*(char *)(lVar35 + 0x2050) != '\0')) {
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1014f6;
      cVar12 = func_0x(lVar31);
      if (cVar12 != '\0') goto LAB_;
    }
    lVar31 = *(longlong *)(uVar51 + 0x288);
    if (*(ushort *)(uVar51 + 0x50) < *(ushort *)(lVar31 + 0x16)) {
      iVar19 = *(int *)(uVar51 + 0x50);
      lVar35 = 0xfff - (longlong)iVar19;
      *(longlong *)(&stack0x000000e8 + lVar25) = lVar35;
      if (*(short *)(lVar31 + lVar35 * 2) != 0) {
        *(int *)(&stack0x000007dc + lVar25) = iVar19;
        if (*(char *)(lVar31 + 2) < '\0') {
          pbVar48 = (byte *)(lVar31 + 0x60);
          if ((*(short *)(&stack0x000007a8 + lVar25) == 0) ||
             (ppbVar26 = *(byte ***)(&stack0x000007b8 + lVar25), ppbVar26 == (byte **)0x0)) {
            *(undefined (*) [16])(&stack0x000007e0 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x000007f0 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000800 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000810 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000820 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000830 + lVar25) = ZEXT816(0);
            *(undefined (*) [16])(&stack0x00000840 + lVar25) = ZEXT816(0);
            *(undefined8 *)(&stack0x00000850 + lVar25) = 0;
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1015b5;
            ppbVar26 = (byte **)func_0x(&stack0x000007e0 + lVar25);
          }
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1015cd;
          puVar29 = (undefined4 *)func_0x(lVar31,&stack0x00000958 + lVar25,0,0);
          if (pbVar48 == *ppbVar26) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1015e1;
            func_0x(puVar29,ppbVar26 + 0xc);
          }
          *ppbVar26 = pbVar48;
          uVar3 = *(undefined2 *)(puVar29 + 2);
          uVar24 = puVar29[1];
          *(undefined4 *)(ppbVar26 + 0xc) = *puVar29;
          *(undefined4 *)((longlong)ppbVar26 + 100) = uVar24;
          *(undefined2 *)(ppbVar26 + 0xd) = uVar3;
          *(undefined4 *)((longlong)ppbVar26 + 0x6c) = *(undefined4 *)(lVar31 + 0x20);
          *(undefined2 *)(ppbVar26 + 0xe) = *(undefined2 *)(lVar31 + 0x24);
          sVar40 = 0;
          *(undefined2 *)((longlong)ppbVar26 + 0x72) = 0;
          bVar13 = *pbVar48;
          *(undefined4 *)(&stack0x000000f8 + lVar25) =
               *(undefined4 *)((ulonglong)bVar13 * 6 + 0x1597010);
          sVar16 = *(short *)((ulonglong)bVar13 * 6 + 0x1597014);
          *(short *)(&stack0x0000003c + lVar25) = sVar16;
          *(undefined2 *)(ppbVar26 + 2) = 0xffff;
          ppbVar26[3] = (byte *)0x0;
          uVar20 = 0;
          *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
          *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
          ppbVar26[7] = (byte *)0x0;
          ppbVar26[4] = (byte *)0x0;
          ppbVar26[9] = (byte *)0x0;
          ppbVar26[10] = (byte *)0x0;
          *(undefined2 *)(ppbVar26 + 0xb) = 0;
          if ((**ppbVar26 & 2) != 0) {
            pbVar53 = pbVar48 + sVar16;
            if ((*pbVar53 & 1) == 0) {
              *(undefined2 *)(ppbVar26 + 2) = 0;
              ppbVar26[3] = pbVar53;
              *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
              *(undefined4 *)((longlong)ppbVar26 + 0x36) = 0;
              switch(*pbVar53 & 0xe) {
              default:
                uVar20 = (uint)*(ushort *)(pbVar53 + 2);
                if (0x1f9d < *(ushort *)(pbVar53 + 2) - 1) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101890;
                  func_0x(pbVar53,6);
                  sVar16 = *(short *)(&stack0x0000003c + lVar25);
                }
                break;
              case 4:
                uVar20 = 9;
                break;
              case 6:
              case 10:
                break;
              case 0xe:
                uVar20 = 1;
              }
              *(uint *)(ppbVar26 + 4) = uVar20;
              *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
              *puVar1 = *puVar1;
              *(undefined4 *)(&stack0x00000048 + lVar25) =
                   *(undefined4 *)(&stack0x00000048 + lVar25);
              lVar35 = *(longlong *)(&stack0x000000e8 + lVar25);
            }
            else {
              *(undefined2 *)(ppbVar26 + 2) = 1;
              uVar24 = *(undefined4 *)(&stack0x00000040 + lVar25);
              *(undefined4 *)(&stack0x00000048 + lVar25) = uVar24;
              uVar20 = *(uint *)(&stack0x00000098 + lVar25);
              *puVar1 = uVar20;
              ppbVar26[3] = pbVar53;
              bVar13 = *pbVar53;
              switch(bVar13 & 0x1c) {
              default:
                if ((char)pbVar53[1] < '\0') {
                  uVar17 = *(ushort *)(pbVar53 + 1);
                  *(ushort *)((longlong)ppbVar26 + 0x12) = uVar17;
                  sVar41 = 3;
                  uVar17 = (uVar17 & 0x7f) << 8 | uVar17 >> 8;
                }
                else {
                  sVar41 = 2;
                  uVar17 = (ushort)pbVar53[1];
                }
                *(ushort *)((longlong)ppbVar26 + 0x12) = uVar17;
                *(short *)(ppbVar26 + 5) = sVar41;
                *(short *)((longlong)ppbVar26 + 0x2c) =
                     (short)(*(ushort *)((longlong)ppbVar26 + 0x12) + 1 >> 1) + sVar41;
                if (0x1e < *(ushort *)((longlong)ppbVar26 + 0x12)) {
                  iVar19 = *(ushort *)((longlong)ppbVar26 + 0x12) - 1;
                  sVar40 = ((short)(iVar19 / 0x1e) + (short)(iVar19 >> 0x1f)) -
                           (short)((longlong)iVar19 * 0x88888889 >> 0x3f);
                }
                *(short *)((longlong)ppbVar26 + 0x2a) = sVar40;
                *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                *(undefined4 *)(ppbVar26 + 8) = 0;
                *puVar1 = uVar20;
                *(undefined4 *)(&stack0x00000048 + lVar25) = uVar24;
                ppbVar26[7] = (byte *)0x0;
                ppbVar26[4] = (byte *)0x0;
                break;
              case 4:
                if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101796;
                  func_0x((longlong)ppbVar26 + 0x12);
                  ppbVar26[3] = pbVar53;
                  *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0xf;
                  *(undefined4 *)(ppbVar26 + 8) = 0;
                  *(undefined4 *)(ppbVar26 + 8) = 1;
                  sVar16 = *(short *)(&stack0x0000003c + lVar25);
                  ppbVar26[7] = (byte *)0x0;
                  ppbVar26[4] = (byte *)0x0;
                }
                else {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1017cb;
                  func_0x((longlong)ppbVar26 + 0x12);
                  ppbVar26[3] = pbVar53;
                  *(undefined4 *)((longlong)ppbVar26 + 0x14) = 1;
                  *puVar1 = *(uint *)(&stack0x00000098 + lVar25);
                  *(undefined4 *)(&stack0x00000048 + lVar25) =
                       *(undefined4 *)(&stack0x00000040 + lVar25);
                  *(undefined4 *)(ppbVar26 + 8) = 0;
                  sVar16 = *(short *)(&stack0x0000003c + lVar25);
                  ppbVar26[7] = (byte *)0x0;
                  ppbVar26[4] = (byte *)0x0;
                }
                break;
              case 8:
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101768;
                func_0x((longlong)ppbVar26 + 0x12);
                ppbVar26[3] = pbVar53;
                *(undefined4 *)((longlong)ppbVar26 + 0x14) = 9;
                *(undefined4 *)(ppbVar26 + 8) = 0;
                *puVar1 = *(uint *)(&stack0x00000098 + lVar25);
                *(undefined4 *)(&stack0x00000048 + lVar25) =
                     *(undefined4 *)(&stack0x00000040 + lVar25);
                sVar16 = *(short *)(&stack0x0000003c + lVar25);
                ppbVar26[7] = (byte *)0x0;
                ppbVar26[4] = (byte *)0x0;
              }
            }
          }
          if ((**ppbVar26 & 4) != 0) {
            if (*(short *)(&stack0x000000fa + lVar25) == 0) {
              uVar49 = (ulonglong)sVar16;
            }
            else {
              uVar49 = (ulonglong)
                       *(ushort *)
                        (lVar31 + 0x61 + (longlong)*(short *)(&stack0x000000fa + lVar25) * 2);
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10191e;
            func_0x(ppbVar26 + 9,pbVar48 + uVar49);
          }
          pbVar48 = ppbVar26[1];
          if (pbVar48 != (byte *)0x0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101932;
            func_0x(pbVar48,ppbVar26);
          }
          uVar49 = (ulonglong)*puVar1;
        }
        else {
          ppbVar26 = (byte **)0x0;
        }
        uVar20 = (uint)*(ushort *)(lVar31 + 0xe);
        pbVar48 = (byte *)((ulonglong)*(ushort *)(lVar31 + lVar35 * 2) + lVar31);
        bVar13 = *pbVar48;
        *(byte **)(&stack0x000007b0 + lVar25) = pbVar48;
        if ((bVar13 & 1) == 0) {
          *(undefined2 *)(&stack0x000007a8 + lVar25) = 0;
          *(undefined4 *)(&stack0x000007ac + lVar25) = 0;
          *(undefined4 *)(&stack0x000007ce + lVar25) = 0;
          switch(*pbVar48 & 0xe) {
          default:
            uVar20 = (uint)*(ushort *)(pbVar48 + 2);
            if (0x1f9d < *(ushort *)(pbVar48 + 2) - 1) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101bba;
              func_0x(pbVar48,6);
            }
            break;
          case 4:
            uVar20 = 9;
            break;
          case 6:
          case 10:
            break;
          case 0xe:
            uVar20 = 1;
          }
          *(uint *)(&stack0x000007b8 + lVar25) = uVar20;
          *(longlong *)(&stack0x000007c6 + lVar25) = lVar31 + 0x2000;
        }
        else {
          *(undefined2 *)(&stack0x000007a8 + lVar25) = 1;
          bVar13 = *pbVar48;
          switch(bVar13 & 0x1c) {
          default:
            if ((char)pbVar48[1] < '\0') {
              uVar17 = (*(ushort *)(pbVar48 + 1) & 0x7f) << 8 | *(ushort *)(pbVar48 + 1) >> 8;
              *(ushort *)(&stack0x000007aa + lVar25) = uVar17;
              sVar16 = 3;
              *(undefined2 *)(&stack0x000007c0 + lVar25) = 3;
            }
            else {
              uVar17 = (ushort)pbVar48[1];
              *(ushort *)(&stack0x000007aa + lVar25) = uVar17;
              sVar16 = 2;
              *(undefined2 *)(&stack0x000007c0 + lVar25) = 2;
            }
            *(short *)(&stack0x000007c4 + lVar25) = (short)(uVar17 + 1 >> 1) + sVar16;
            if (uVar17 < 0x1f) {
              *(undefined2 *)(&stack0x000007c2 + lVar25) = 0;
              *(undefined4 *)(&stack0x000007ac + lVar25) = 0;
              *(undefined4 *)(&stack0x000007d8 + lVar25) = 0;
              *(longlong *)(&stack0x000007d0 + lVar25) = lVar31 + 0x2000;
              *(byte ***)(&stack0x000007b8 + lVar25) = ppbVar26;
            }
            else {
              iVar19 = uVar17 - 1;
              *(short *)(&stack0x000007c2 + lVar25) =
                   ((short)(iVar19 / 0x1e) + (short)(iVar19 >> 0x1f)) -
                   (short)((longlong)iVar19 * 0x88888889 >> 0x3f);
              *(undefined4 *)(&stack0x000007ac + lVar25) = 0;
              *(undefined4 *)(&stack0x000007d8 + lVar25) = 0;
              *(longlong *)(&stack0x000007d0 + lVar25) = lVar31 + 0x2000;
              *(byte ***)(&stack0x000007b8 + lVar25) = ppbVar26;
            }
            break;
          case 4:
            if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101abf;
              func_0x(&stack0x000007aa + lVar25);
              *(byte **)(&stack0x000007b0 + lVar25) = pbVar48;
              *(undefined4 *)(&stack0x000007ac + lVar25) = 0xf;
              *(undefined4 *)(&stack0x000007d8 + lVar25) = 1;
              *(longlong *)(&stack0x000007d0 + lVar25) = lVar31 + 0x2000;
              *(byte ***)(&stack0x000007b8 + lVar25) = ppbVar26;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101afc;
              func_0x(&stack0x000007aa + lVar25);
              *(byte **)(&stack0x000007b0 + lVar25) = pbVar48;
              *(undefined4 *)(&stack0x000007ac + lVar25) = 1;
              *(undefined4 *)(&stack0x000007d8 + lVar25) = 0;
              *(longlong *)(&stack0x000007d0 + lVar25) = lVar31 + 0x2000;
              *(byte ***)(&stack0x000007b8 + lVar25) = ppbVar26;
            }
            break;
          case 8:
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101a72;
            func_0x(&stack0x000007aa + lVar25);
            *(byte **)(&stack0x000007b0 + lVar25) = pbVar48;
            *(undefined4 *)(&stack0x000007ac + lVar25) = 9;
            *(undefined4 *)(&stack0x000007d8 + lVar25) = 0;
            *(longlong *)(&stack0x000007d0 + lVar25) = lVar31 + 0x2000;
            *(byte ***)(&stack0x000007b8 + lVar25) = ppbVar26;
          }
        }
        iVar19 = 1;
        if (*(short *)(&stack0x000007a8 + lVar25) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101c2b;
          func_0x();
        }
        else {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101c32;
          func_0x(&stack0x000007aa + lVar25,&stack0x0000014e + lVar25);
        }
        *(undefined4 *)(&stack0x000000c8 + lVar25) = *(undefined4 *)(&stack0x0000014e + lVar25);
        *(undefined2 *)(&stack0x000000cc + lVar25) = *(undefined2 *)(&stack0x00000152 + lVar25);
        *(undefined4 *)(&stack0x00000168 + lVar25) = *(undefined4 *)(&stack0x0000014e + lVar25);
        *(undefined2 *)(&stack0x0000016c + lVar25) = *(undefined2 *)(&stack0x00000152 + lVar25);
        lVar31 = *(longlong *)(&stack0x00000108 + lVar25);
        uVar27 = *(undefined8 *)(lVar31 + 0x30);
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101c70;
        cVar12 = func_0x(uVar27,&stack0x00000168 + lVar25);
        if (cVar12 != '\0') {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101c85;
          cVar12 = func_0x(lVar31,3);
          if (cVar12 == '\0') {
            *(undefined4 *)(uVar51 + 0xf0) = 3;
            *(undefined4 *)(uVar51 + 0x50) = 0xffffffff;
            uVar59 = *(ulonglong *)(&stack0x000000b8 + lVar25);
            goto code_r0x001008ff;
          }
        }
      }
    }
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101c9a;
  func_0x(plVar58);
  uVar49 = (ulonglong)*(uint *)(uVar51 + 0x268);
  uVar24 = *(undefined4 *)(uVar51 + 0x26c);
  *(undefined4 *)(&stack0x00000048 + lVar25) = uVar24;
  iVar19 = 0;
  uVar59 = *(ulonglong *)(&stack0x000000b8 + lVar25);
  iVar21 = *(int *)(&stack0x000000ac + lVar25);
LAB_:
  if ((int)uVar49 != 3) {
code_r0x001008ff:
    iVar21 = *(int *)(&stack0x00000048 + lVar25);
    goto LAB_;
  }
  bVar61 = false;
  if (*(char *)(*(longlong *)(uVar59 + 0x28) + 0x29) != '\0') {
    bVar61 = iVar21 < 0x32;
LAB_:
    *(undefined8 *)(&stack0x000000e0 + lVar25) = 0;
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101cf9;
    iVar22 = func_0x(uVar59);
    if (!bVar61) goto LAB_;
LAB_:
    if (1 < iVar22 - 1U) goto LAB_;
    iVar21 = iVar21 + 1;
    *(int *)(&stack0x000000ac + lVar25) = iVar21;
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101d1b;
    func_0x(plVar58);
    if (*(char *)(*(longlong *)(uVar59 + 0x28) + 0x29) == '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101d38;
      func_0x();
    }
    goto LAB_;
  }
  lVar31 = *(longlong *)(*(longlong *)(uVar59 + 0x20) + 0x18);
  if ((*(int *)(lVar31 + 0x1c) == 0) ||
     ((((*(char *)(lVar31 + 1) == '\x01' || (*(char *)(lVar31 + 1) == '\b')) &&
       (*(char *)(lVar31 + 2) == '\0')) && (*(char *)(lVar31 + 3) == '\0')))) {
    if (iVar21 < 3) {
      *(undefined8 *)(&stack0x000000e0 + lVar25) = 0;
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101d9b;
      iVar22 = func_0x(uVar59);
      goto LAB_;
    }
    goto LAB_;
  }
  *(undefined8 *)(&stack0x000000e0 + lVar25) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101e23;
  func_0x(uVar59,1);
LAB_:
  if (*(longlong *)(uVar59 + 0x2d8) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101e43;
    func_0x(uVar59 + 0x2b0,0);
  }
  if (*(int *)(uVar59 + 0x4f0) == 0) {
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101e5c;
    func_0x(uVar59 + 0x2b0,1);
  }
  iVar21 = *(int *)(uVar59 + 0x4ec);
  *(int *)(&stack0x00000048 + lVar25) = iVar21;
LAB_:
  *(uint *)(uVar59 + 0x634) = *(uint *)(uVar59 + 0x634) | 1;
  uVar20 = *(uint *)(uVar59 + 0x634);
  if (((iVar19 != 0) || ((int)uVar49 == 1)) || (iVar21 == 0)) goto LAB_;
  puVar29 = *(undefined4 **)(&stack0x00000110 + lVar25);
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100943;
  func_0x(uVar59,puVar29,0,1);
  if ((int)uVar49 != 4) goto LAB_;
  *(undefined4 *)(&stack0x00000760 + lVar25) = *puVar29;
  *(undefined2 *)(&stack0x00000764 + lVar25) = *(undefined2 *)(puVar29 + 1);
  *(undefined2 *)(&stack0x00000766 + lVar25) = 0;
  *(undefined8 *)(&stack0x00000758 + lVar25) = 0;
  *(undefined4 *)(&stack0x00000774 + lVar25) = 0;
  *(undefined8 *)(&stack0x00000768 + lVar25) = 0;
  *(undefined2 *)(&stack0x00000770 + lVar25) = 0;
  puVar28 = *(undefined8 **)(*(longlong *)(&stack0x00000118 + lVar25) + 0x2d8);
  *(undefined **)(&stack0xffffffffffffffe8 + lVar25) = &stack0x000001d8 + lVar25;
  uVar27 = *puVar28;
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1009bd;
  iVar19 = func_0x(uVar27,&stack0x00000758 + lVar25,3);
  if (iVar19 == 0) goto LAB_;
  lVar31 = CONCAT44(uRam0000000001ed926c,_DAT_);
  if ((*(longlong *)(uVar59 + 0x40) != lVar31) ||
     (lVar35 = CONCAT44(uRam0000000001ed9274,_DAT_), *(longlong *)(uVar59 + 0x48) != lVar35)
     ) {
    if ((*(byte *)(uVar59 + 0xa0) & 2) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1009f8;
      iVar19 = func_0x(uVar59 + 0xa8);
      if (iVar19 != 0) {
        plVar58 = (longlong *)(*(longlong *)(uVar59 + 0x30) + 0x30);
        *plVar58 = *plVar58 + -1;
      }
    }
    *(undefined *)(uVar59 + 0xa0) = 0;
    *(undefined4 *)(uVar59 + 0x9c) = 0;
    *(undefined4 *)(uVar59 + 0xb8) = 0;
    if ((*(byte *)(uVar59 + 0xd0) & 2) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100a2e;
      iVar19 = func_0x(uVar59 + 0xd8);
      if (iVar19 != 0) {
        plVar58 = (longlong *)(*(longlong *)(uVar59 + 0x30) + 0x30);
        *plVar58 = *plVar58 + -1;
      }
    }
    *(undefined *)(uVar59 + 0xd0) = 0;
    *(undefined4 *)(uVar59 + 0xcc) = 0;
    *(undefined4 *)(uVar59 + 0xe8) = 0;
    if (*(longlong *)(uVar59 + 0x58) != 0) {
      *(undefined *)(uVar59 + 0x66) = 0;
      *(undefined8 *)(uVar59 + 0x58) = 0;
      *(undefined2 *)(uVar59 + 100) = 0;
      *(undefined4 *)(*(longlong *)(uVar59 + 0x40) + 0x48) = 0;
    }
    uVar27 = **(undefined8 **)(uVar59 + 0x30);
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100a7a;
    func_0x(uVar27,uVar59 + 0x40);
    uVar10 = uRam0000000001ed9274;
    uVar5 = _DAT_;
    uVar24 = uRam0000000001ed926c;
    *(undefined4 *)(uVar59 + 0x40) = _DAT_;
    *(undefined4 *)(uVar59 + 0x44) = uVar24;
    *(undefined4 *)(uVar59 + 0x48) = uVar5;
    *(undefined4 *)(uVar59 + 0x4c) = uVar10;
    *(undefined4 *)(uVar59 + 0x50) = 0xffffffff;
    *(undefined4 *)(uVar59 + 0x270) = 0;
    *(undefined8 *)(uVar59 + 0x288) = 0;
    *(undefined8 *)(uVar59 + 0x280) = 0;
    *(undefined8 *)(uVar59 + 0x290) = 0;
    *(undefined4 *)(uVar59 + 0x2a0) = 0xffffffff;
    *(undefined2 *)(uVar59 + 0x2a4) = 0xffff;
    *(undefined8 *)(uVar59 + 0x2a6) = 0;
    *(undefined4 *)(uVar59 + 0xf0) = 2;
    lVar35 = CONCAT44(uRam0000000001ed9274,_DAT_);
    lVar31 = CONCAT44(uRam0000000001ed926c,_DAT_);
  }
  if ((*(longlong *)(uVar59 + 0x2c0) != lVar31) || (*(longlong *)(uVar59 + 0x2c8) != lVar35)) {
    if ((*(byte *)(uVar59 + 800) & 2) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101e9e;
      iVar19 = func_0x(uVar59 + 0x328);
      if (iVar19 != 0) {
        plVar58 = (longlong *)(*(longlong *)(uVar59 + 0x2b0) + 0x30);
        *plVar58 = *plVar58 + -1;
      }
    }
    *(undefined *)(uVar59 + 800) = 0;
    *(undefined4 *)(uVar59 + 0x31c) = 0;
    *(undefined4 *)(uVar59 + 0x338) = 0;
    if ((*(byte *)(uVar59 + 0x350) & 2) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101ed7;
      iVar19 = func_0x(uVar59 + 0x358);
      if (iVar19 != 0) {
        plVar58 = (longlong *)(*(longlong *)(uVar59 + 0x2b0) + 0x30);
        *plVar58 = *plVar58 + -1;
      }
    }
    *(undefined *)(uVar59 + 0x350) = 0;
    *(undefined4 *)(uVar59 + 0x34c) = 0;
    *(undefined4 *)(uVar59 + 0x368) = 0;
    if (*(longlong *)(uVar59 + 0x2d8) != 0) {
      *(undefined *)(uVar59 + 0x2e6) = 0;
      *(undefined8 *)(uVar59 + 0x2d8) = 0;
      *(undefined2 *)(uVar59 + 0x2e4) = 0;
      *(undefined4 *)(*(longlong *)(uVar59 + 0x2c0) + 0x48) = 0;
    }
    uVar27 = **(undefined8 **)(uVar59 + 0x2b0);
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101f3b;
    func_0x(uVar27,uVar59 + 0x2c0);
    uVar10 = uRam0000000001ed9274;
    uVar5 = _DAT_;
    uVar24 = uRam0000000001ed926c;
    *(undefined4 *)(uVar59 + 0x2c0) = _DAT_;
    *(undefined4 *)(uVar59 + 0x2c4) = uVar24;
    *(undefined4 *)(uVar59 + 0x2c8) = uVar5;
    *(undefined4 *)(uVar59 + 0x2cc) = uVar10;
    *(undefined4 *)(uVar59 + 0x2d0) = 0xffffffff;
    *(undefined4 *)(uVar59 + 0x4f0) = 0;
    *(undefined8 *)(uVar59 + 0x508) = 0;
    *(undefined8 *)(uVar59 + 0x500) = 0;
    *(undefined8 *)(uVar59 + 0x510) = 0;
    *(undefined4 *)(uVar59 + 0x520) = 0xffffffff;
    *(undefined2 *)(uVar59 + 0x524) = 0xffff;
    *(undefined8 *)(uVar59 + 0x526) = 0;
    *(undefined4 *)(uVar59 + 0x370) = 2;
  }
  *(undefined4 *)(uVar59 + 0x634) = 0;
  (&stack0x00000756)[lVar25] = 1;
  uVar27 = **(undefined8 **)(uVar59 + 0x30);
  plVar58 = *(longlong **)(*(longlong *)(uVar59 + 0x38) + 8);
  uVar24 = *(undefined4 *)(&stack0x000001dc + lVar25);
  uVar5 = *(undefined4 *)(&stack0x000001e0 + lVar25);
  uVar10 = *(undefined4 *)(&stack0x000001e4 + lVar25);
  *(undefined4 *)(uVar59 + 0x40) = *(undefined4 *)(&stack0x000001d8 + lVar25);
  *(undefined4 *)(uVar59 + 0x44) = uVar24;
  *(undefined4 *)(uVar59 + 0x48) = uVar5;
  *(undefined4 *)(uVar59 + 0x4c) = uVar10;
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x101fc9;
  func_0x(uVar27,uVar59 + 0x40,uVar59 + 0x58);
  *(undefined8 *)(uVar59 + 0x288) = **(undefined8 **)(uVar59 + 0x58);
  *(undefined4 *)(uVar59 + 0x88) = 3;
  *(undefined4 *)(uVar59 + 0x29c) = 0;
  lVar31 = *(longlong *)(*(longlong *)(uVar59 + 0x30) + 0x18);
  uVar20 = *(uint *)(*(longlong *)(uVar59 + 0x100) + 0x10);
  if (((((uVar20 & 1) != 0) && ((uVar20 & 0x40) == 0)) &&
      (lVar35 = plVar58[6], *(char *)(lVar35 + 0x1cd2) != '\0')) &&
     (*(char *)(lVar35 + 0x2050) == '\0')) {
    uVar24 = *(undefined4 *)(*(longlong *)(uVar59 + 0x40) + 0x90);
    uVar3 = *(undefined2 *)(*(longlong *)(uVar59 + 0x40) + 0x94);
    uVar4 = *(undefined2 *)(lVar35 + 0x6b8);
    (&stack0x00000756)[lVar25] = 6;
    *(undefined2 *)(&stack0x00000754 + lVar25) = uVar4;
    *(undefined8 *)(&stack0x0000074c + lVar25) = 0;
    *(undefined4 *)(&stack0x00000748 + lVar25) = uVar24;
    *(undefined2 *)(&stack0x0000074c + lVar25) = uVar3;
    uVar27 = *(undefined8 *)(*(longlong *)(uVar59 + 0x38) + 8);
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102083;
    cVar12 = func_0x(uVar27,CONCAT71((uint7)(byte)((ushort)uVar3 >> 8),6),
                             &stack0x00000748 + lVar25);
    if (cVar12 == '\0') {
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102090;
      func_0x(uVar59 + 0x30);
      lVar35 = *(longlong *)(*(longlong *)(uVar59 + 0x30) + 0x18);
      lVar34 = *(longlong *)(uVar59 + 0x38);
      (&stack0xffffffffffffffe8)[lVar25] = 1;
      uVar24 = *(undefined4 *)(lVar35 + 0x18);
      uVar27 = *(undefined8 *)(lVar34 + 8);
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1020b7;
      func_0x(uVar27,6,uVar24);
    }
  }
  if (*(char *)(lVar31 + 2) == '\0') {
LAB_:
    *(undefined4 *)(uVar59 + 0xf0) = 3;
    if (*(longlong *)(uVar59 + 0x58) != 0) {
LAB_:
      uVar20 = *(uint *)(uVar59 + 0x634);
      *(uint *)(uVar59 + 0x634) = uVar20 | 1;
      iVar22 = (int)*(short *)((longlong)puVar29 + 6);
      *(int *)(&stack0x000000c0 + lVar25) = iVar22;
      iVar21 = 0;
      *(undefined4 *)(&stack0x000000ac + lVar25) = 0;
      *(uint *)(uVar59 + 0x634) = uVar20 & 0xfffffffe;
      iVar19 = *(int *)(&stack0x000000a8 + lVar25);
LAB_:
      if ((*(int *)(uVar59 + 0x370) == 4) &&
         ((*(longlong *)(uVar59 + 0x2c0) != CONCAT44(uRam0000000001ed926c,_DAT_) ||
          (*(longlong *)(uVar59 + 0x2c8) != CONCAT44(uRam0000000001ed9274,_DAT_))))) {
        if ((*(byte *)(uVar59 + 800) & 2) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102338;
          iVar23 = func_0x(uVar59 + 0x328);
          if (iVar23 != 0) {
            plVar58 = (longlong *)(*(longlong *)(uVar59 + 0x2b0) + 0x30);
            *plVar58 = *plVar58 + -1;
          }
        }
        *(undefined *)(uVar59 + 800) = 0;
        *(undefined4 *)(uVar59 + 0x31c) = 0;
        *(undefined4 *)(uVar59 + 0x338) = 0;
        if ((*(byte *)(uVar59 + 0x350) & 2) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102373;
          iVar23 = func_0x(uVar59 + 0x358);
          if (iVar23 != 0) {
            plVar58 = (longlong *)(*(longlong *)(uVar59 + 0x2b0) + 0x30);
            *plVar58 = *plVar58 + -1;
          }
        }
        *(undefined *)(uVar59 + 0x350) = 0;
        *(undefined4 *)(uVar59 + 0x34c) = 0;
        *(undefined4 *)(uVar59 + 0x368) = 0;
        if (*(longlong *)(uVar59 + 0x2d8) != 0) {
          *(undefined *)(uVar59 + 0x2e6) = 0;
          *(undefined8 *)(uVar59 + 0x2d8) = 0;
          *(undefined2 *)(uVar59 + 0x2e4) = 0;
          *(undefined4 *)(*(longlong *)(uVar59 + 0x2c0) + 0x48) = 0;
        }
        uVar27 = **(undefined8 **)(uVar59 + 0x2b0);
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1023da;
        func_0x(uVar27,uVar59 + 0x2c0);
        uVar10 = uRam0000000001ed9274;
        uVar5 = _DAT_;
        uVar24 = uRam0000000001ed926c;
        *(undefined4 *)(uVar59 + 0x2c0) = _DAT_;
        *(undefined4 *)(uVar59 + 0x2c4) = uVar24;
        *(undefined4 *)(uVar59 + 0x2c8) = uVar5;
        *(undefined4 *)(uVar59 + 0x2cc) = uVar10;
        *(undefined4 *)(uVar59 + 0x2d0) = 0xffffffff;
        *(undefined4 *)(uVar59 + 0x4f0) = 0;
        *(undefined8 *)(uVar59 + 0x508) = 0;
        *(undefined8 *)(uVar59 + 0x500) = 0;
        *(undefined8 *)(uVar59 + 0x510) = 0;
        *(undefined4 *)(uVar59 + 0x520) = 0xffffffff;
        *(undefined2 *)(uVar59 + 0x524) = 0xffff;
        *(undefined8 *)(uVar59 + 0x526) = 0;
        *(undefined4 *)(uVar59 + 0x370) = 2;
      }
      if (iVar21 < 1) {
        if (iVar21 == 0) goto LAB_;
      }
      else {
        if (*(longlong *)(uVar59 + 0x58) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102455;
          func_0x(uVar59 + 0x30,0);
        }
        if (*(int *)(uVar59 + 0x270) == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10246d;
          func_0x(uVar59 + 0x30,1);
        }
        uVar49 = (ulonglong)*(uint *)(uVar59 + 0x268);
      }
      if (*(char *)(*(longlong *)(uVar59 + 0x28) + 0x29) != '\0') {
LAB_:
        plVar58 = (longlong *)(uVar59 + 0x30);
        lVar31 = *(longlong *)(*(longlong *)(uVar59 + 0x38) + 8);
        *(longlong *)(&stack0x00000108 + lVar25) = lVar31;
        *(undefined2 *)(&stack0x00000858 + lVar25) = 0xffff;
        *(undefined8 *)(&stack0x00000860 + lVar25) = 0;
        *(undefined4 *)(&stack0x0000085c + lVar25) = 0;
        *(undefined8 *)(&stack0x00000876 + lVar25) = 0;
        *(undefined8 *)(&stack0x00000880 + lVar25) = 0;
        *(undefined8 *)(&stack0x00000868 + lVar25) = 0;
        *(undefined4 *)(&stack0x0000088c + lVar25) = 0xffffffff;
        *(undefined4 *)(&stack0x000000d0 + lVar25) = 0;
        *(undefined2 *)(&stack0x000000d4 + lVar25) = 0;
        lVar35 = *(longlong *)(*plVar58 + 0x18);
        *(longlong *)(&stack0x00000100 + lVar25) = lVar35;
        (&stack0x0000003c)[lVar25] = 0;
        if ((*(byte *)(uVar59 + 0xa0) & 2) != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102512;
          iVar19 = func_0x(uVar59 + 0xa8);
          if (iVar19 != 0) {
            *(longlong *)(*plVar58 + 0x30) = *(longlong *)(*plVar58 + 0x30) + -1;
          }
        }
        *(undefined *)(uVar59 + 0xa0) = 0;
        *(undefined4 *)(uVar59 + 0x9c) = 0;
        *(undefined4 *)(uVar59 + 0xb8) = 0;
        *(int *)(uVar59 + 0x50) = iVar22;
        uVar20 = *(uint *)(*(longlong *)(uVar59 + 0x100) + 0x10);
        if ((((uVar20 & 1) != 0) && ((uVar20 & 0x40) == 0)) &&
           ((*(char *)(*(longlong *)(lVar31 + 0x30) + 0x1cd2) != '\0' &&
            (*(char *)(*(longlong *)(lVar31 + 0x30) + 0x2050) == '\0')))) {
          (&stack0x00000926)[lVar25] = 1;
          lVar34 = **(longlong **)(uVar59 + 0x58);
          uVar24 = *(undefined4 *)(uVar59 + 0x50);
          *(undefined4 *)(&stack0x000001a8 + lVar25) = *(undefined4 *)(lVar34 + 0x20);
          *(undefined2 *)(&stack0x000001ac + lVar25) = *(undefined2 *)(lVar34 + 0x24);
          *(short *)(&stack0x000001ae + lVar25) = (short)uVar24;
          uVar3 = *(undefined2 *)(*(longlong *)(lVar31 + 0x30) + 0x6b8);
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1025b9;
          func_0x(&stack0x00000918 + lVar25,uVar3,&stack0x000001a8 + lVar25);
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1025cd;
          cVar12 = func_0x(lVar31,3,&stack0x00000918 + lVar25);
          if (cVar12 == '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1025d9;
            func_0x(plVar58);
            lVar34 = *(longlong *)(*plVar58 + 0x18);
            (&stack0xffffffffffffffe8)[lVar25] = 1;
            uVar24 = *(undefined4 *)(lVar34 + 0x18);
            *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1025fa;
            func_0x(lVar31,3,uVar24);
            if (*(longlong *)(uVar59 + 0x58) == 0) {
              *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10260b;
              func_0x(plVar58,0);
            }
          }
        }
        *(int *)(&stack0x00000094 + lVar25) = _DAT_;
        *(undefined2 *)(&stack0x00000090 + lVar25) = _DAT_;
        iVar19 = _DAT_;
        do {
          ppbVar26 = (byte **)0x0;
          if (((*(char *)(*(longlong *)(uVar59 + 0x38) + 0x29) != '\0') &&
              ((*(uint *)(lVar35 + 4) & 0x140) == 0)) &&
             (lVar34 = *(longlong *)(uVar59 + 0x288),
             *(ushort *)(uVar59 + 0x50) < *(ushort *)(lVar34 + 0x16))) {
            iVar21 = *(int *)(uVar59 + 0x50);
            lVar38 = (longlong)iVar21;
            *(longlong *)(&stack0x000000e8 + lVar25) = lVar38;
            if (*(short *)(lVar34 + (0xfff - lVar38) * 2) != 0) {
              *(int *)(&stack0x0000088c + lVar25) = iVar21;
              if (*(char *)(lVar34 + 2) < '\0') {
                pbVar48 = (byte *)(lVar34 + 0x60);
                if ((*(short *)(&stack0x00000858 + lVar25) == 0) ||
                   (ppbVar26 = *(byte ***)(&stack0x00000868 + lVar25), ppbVar26 == (byte **)0x0)) {
                  *(undefined (*) [16])(&stack0x00000890 + lVar25) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000008a0 + lVar25) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000008b0 + lVar25) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000008c0 + lVar25) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000008d0 + lVar25) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000008e0 + lVar25) = ZEXT816(0);
                  *(undefined (*) [16])(&stack0x000008f0 + lVar25) = ZEXT816(0);
                  *(undefined8 *)(&stack0x00000900 + lVar25) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102701;
                  ppbVar26 = (byte **)func_0x(&stack0x00000890 + lVar25);
                }
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102719;
                puVar29 = (undefined4 *)func_0x(lVar34,&stack0x00000968 + lVar25,0);
                if (pbVar48 == *ppbVar26) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x10272d;
                  func_0x(puVar29,ppbVar26 + 0xc);
                }
                *ppbVar26 = pbVar48;
                uVar3 = *(undefined2 *)(puVar29 + 2);
                uVar24 = puVar29[1];
                *(undefined4 *)(ppbVar26 + 0xc) = *puVar29;
                *(undefined4 *)((longlong)ppbVar26 + 100) = uVar24;
                *(undefined2 *)(ppbVar26 + 0xd) = uVar3;
                *(undefined4 *)((longlong)ppbVar26 + 0x6c) = *(undefined4 *)(lVar34 + 0x20);
                *(undefined2 *)(ppbVar26 + 0xe) = *(undefined2 *)(lVar34 + 0x24);
                *(undefined2 *)((longlong)ppbVar26 + 0x72) = 0;
                bVar13 = *pbVar48;
                *(undefined4 *)(&stack0x000000f8 + lVar25) =
                     *(undefined4 *)((ulonglong)bVar13 * 6 + 0x1597010);
                sVar16 = *(short *)((ulonglong)bVar13 * 6 + 0x1597014);
                *(short *)(&stack0x00000040 + lVar25) = sVar16;
                *(undefined2 *)(ppbVar26 + 2) = 0xffff;
                ppbVar26[3] = (byte *)0x0;
                uVar20 = 0;
                *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
                ppbVar26[7] = (byte *)0x0;
                ppbVar26[4] = (byte *)0x0;
                ppbVar26[9] = (byte *)0x0;
                ppbVar26[10] = (byte *)0x0;
                *(undefined2 *)(ppbVar26 + 0xb) = 0;
                if ((**ppbVar26 & 2) != 0) {
                  pbVar53 = pbVar48 + sVar16;
                  if ((*pbVar53 & 1) == 0) {
                    *(undefined2 *)(ppbVar26 + 2) = 0;
                    ppbVar26[3] = pbVar53;
                    *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                    *(undefined4 *)((longlong)ppbVar26 + 0x36) = 0;
                    switch(*pbVar53 & 0xe) {
                    default:
                      uVar20 = (uint)*(ushort *)(pbVar53 + 2);
                      if (0x1f9d < *(ushort *)(pbVar53 + 2) - 1) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1029bf;
                        func_0x(pbVar53,6);
                        sVar16 = *(short *)(&stack0x00000040 + lVar25);
                      }
                      break;
                    case 4:
                      uVar20 = 9;
                      break;
                    case 6:
                    case 10:
                      break;
                    case 0xe:
                      uVar20 = 1;
                    }
                    *(uint *)(ppbVar26 + 4) = uVar20;
                    *(undefined8 *)((longlong)ppbVar26 + 0x2e) = 0;
                    lVar38 = *(longlong *)(&stack0x000000e8 + lVar25);
                  }
                  else {
                    *(undefined2 *)(ppbVar26 + 2) = 1;
                    ppbVar26[3] = pbVar53;
                    bVar13 = *pbVar53;
                    switch(bVar13 & 0x1c) {
                    default:
                      if ((char)pbVar53[1] < '\0') {
                        uVar17 = *(ushort *)(pbVar53 + 1);
                        *(ushort *)((longlong)ppbVar26 + 0x12) = uVar17;
                        sVar40 = 3;
                        uVar17 = (uVar17 & 0x7f) << 8 | uVar17 >> 8;
                      }
                      else {
                        sVar40 = 2;
                        uVar17 = (ushort)pbVar53[1];
                      }
                      *(ushort *)((longlong)ppbVar26 + 0x12) = uVar17;
                      *(short *)(ppbVar26 + 5) = sVar40;
                      *(short *)((longlong)ppbVar26 + 0x2c) =
                           (short)(*(ushort *)((longlong)ppbVar26 + 0x12) + 1 >> 1) + sVar40;
                      if (*(ushort *)((longlong)ppbVar26 + 0x12) < 0x1f) {
                        *(undefined2 *)((longlong)ppbVar26 + 0x2a) = 0;
                        *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                        *(undefined4 *)(ppbVar26 + 8) = 0;
                        ppbVar26[7] = (byte *)0x0;
                        ppbVar26[4] = (byte *)0x0;
                      }
                      else {
                        iVar19 = *(ushort *)((longlong)ppbVar26 + 0x12) - 1;
                        *(short *)((longlong)ppbVar26 + 0x2a) =
                             ((short)(iVar19 / 0x1e) + (short)(iVar19 >> 0x1f)) -
                             (short)((longlong)iVar19 * 0x88888889 >> 0x3f);
                        *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0;
                        *(undefined4 *)(ppbVar26 + 8) = 0;
                        ppbVar26[7] = (byte *)0x0;
                        ppbVar26[4] = (byte *)0x0;
                      }
                      break;
                    case 4:
                      if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1028de;
                        func_0x((longlong)ppbVar26 + 0x12);
                        ppbVar26[3] = pbVar53;
                        *(undefined4 *)((longlong)ppbVar26 + 0x14) = 0xf;
                        *(undefined4 *)(ppbVar26 + 8) = 0;
                        *(undefined4 *)(ppbVar26 + 8) = 1;
                        sVar16 = *(short *)(&stack0x00000040 + lVar25);
                        ppbVar26[7] = (byte *)0x0;
                        ppbVar26[4] = (byte *)0x0;
                      }
                      else {
                        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102913;
                        func_0x((longlong)ppbVar26 + 0x12);
                        ppbVar26[3] = pbVar53;
                        *(undefined4 *)((longlong)ppbVar26 + 0x14) = 1;
                        *(undefined4 *)(ppbVar26 + 8) = 0;
                        sVar16 = *(short *)(&stack0x00000040 + lVar25);
                        ppbVar26[7] = (byte *)0x0;
                        ppbVar26[4] = (byte *)0x0;
                      }
                      break;
                    case 8:
                      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1028a3;
                      func_0x((longlong)ppbVar26 + 0x12);
                      ppbVar26[3] = pbVar53;
                      *(undefined4 *)((longlong)ppbVar26 + 0x14) = 9;
                      *(undefined4 *)(ppbVar26 + 8) = 0;
                      sVar16 = *(short *)(&stack0x00000040 + lVar25);
                      ppbVar26[7] = (byte *)0x0;
                      ppbVar26[4] = (byte *)0x0;
                    }
                  }
                }
                if ((**ppbVar26 & 4) != 0) {
                  uVar49 = (ulonglong)sVar16;
                  if (*(short *)(&stack0x000000fa + lVar25) != 0) {
                    uVar49 = (ulonglong)
                             *(ushort *)
                              (lVar34 + 0x61 + (longlong)*(short *)(&stack0x000000fa + lVar25) * 2);
                  }
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102a3e;
                  func_0x(ppbVar26 + 9,pbVar48 + uVar49);
                }
                pbVar48 = ppbVar26[1];
                if (pbVar48 != (byte *)0x0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102a52;
                  func_0x(pbVar48,ppbVar26);
                }
                iVar19 = *(int *)(&stack0x00000094 + lVar25);
              }
              uVar20 = (uint)*(ushort *)(lVar34 + 0xe);
              pbVar48 = (byte *)((ulonglong)*(ushort *)(lVar34 + (0xfff - lVar38) * 2) + lVar34);
              bVar13 = *pbVar48;
              *(byte **)(&stack0x00000860 + lVar25) = pbVar48;
              if ((bVar13 & 1) == 0) {
                *(undefined2 *)(&stack0x00000858 + lVar25) = 0;
                *(undefined4 *)(&stack0x0000085c + lVar25) = 0;
                *(undefined4 *)(&stack0x0000087e + lVar25) = 0;
                switch(*pbVar48 & 0xe) {
                default:
                  uVar20 = (uint)*(ushort *)(pbVar48 + 2);
                  if (0x1f9d < *(ushort *)(pbVar48 + 2) - 1) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102ce2;
                    func_0x(pbVar48,6);
                  }
                  break;
                case 4:
                  uVar20 = 9;
                  break;
                case 6:
                case 10:
                  break;
                case 0xe:
                  uVar20 = 1;
                }
                *(uint *)(&stack0x00000868 + lVar25) = uVar20;
                *(longlong *)(&stack0x00000876 + lVar25) = lVar34 + 0x2000;
              }
              else {
                *(undefined2 *)(&stack0x00000858 + lVar25) = 1;
                bVar13 = *pbVar48;
                switch(bVar13 & 0x1c) {
                default:
                  if ((char)pbVar48[1] < '\0') {
                    uVar17 = (*(ushort *)(pbVar48 + 1) & 0x7f) << 8 | *(ushort *)(pbVar48 + 1) >> 8;
                    *(ushort *)(&stack0x0000085a + lVar25) = uVar17;
                    sVar16 = 3;
                    *(undefined2 *)(&stack0x00000870 + lVar25) = 3;
                  }
                  else {
                    uVar17 = (ushort)pbVar48[1];
                    *(ushort *)(&stack0x0000085a + lVar25) = uVar17;
                    sVar16 = 2;
                    *(undefined2 *)(&stack0x00000870 + lVar25) = 2;
                  }
                  *(short *)(&stack0x00000874 + lVar25) = (short)(uVar17 + 1 >> 1) + sVar16;
                  if (uVar17 < 0x1f) {
                    *(undefined2 *)(&stack0x00000872 + lVar25) = 0;
                    *(undefined4 *)(&stack0x0000085c + lVar25) = 0;
                    *(undefined4 *)(&stack0x00000888 + lVar25) = 0;
                    *(longlong *)(&stack0x00000880 + lVar25) = lVar34 + 0x2000;
                    *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
                  }
                  else {
                    iVar21 = uVar17 - 1;
                    *(short *)(&stack0x00000872 + lVar25) =
                         ((short)(iVar21 / 0x1e) + (short)(iVar21 >> 0x1f)) -
                         (short)((longlong)iVar21 * 0x88888889 >> 0x3f);
                    *(undefined4 *)(&stack0x0000085c + lVar25) = 0;
                    *(undefined4 *)(&stack0x00000888 + lVar25) = 0;
                    *(longlong *)(&stack0x00000880 + lVar25) = lVar34 + 0x2000;
                    *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
                  }
                  break;
                case 4:
                  if (((bVar13 & 0x1c) == 4) && ((bVar13 & 2) != 0)) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102be7;
                    func_0x(&stack0x0000085a + lVar25);
                    *(byte **)(&stack0x00000860 + lVar25) = pbVar48;
                    *(undefined4 *)(&stack0x0000085c + lVar25) = 0xf;
                    *(undefined4 *)(&stack0x00000888 + lVar25) = 1;
                    *(longlong *)(&stack0x00000880 + lVar25) = lVar34 + 0x2000;
                    *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
                  }
                  else {
                    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102c24;
                    func_0x(&stack0x0000085a + lVar25);
                    *(byte **)(&stack0x00000860 + lVar25) = pbVar48;
                    *(undefined4 *)(&stack0x0000085c + lVar25) = 1;
                    *(undefined4 *)(&stack0x00000888 + lVar25) = 0;
                    *(longlong *)(&stack0x00000880 + lVar25) = lVar34 + 0x2000;
                    *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
                  }
                  break;
                case 8:
                  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102b9a;
                  func_0x(&stack0x0000085a + lVar25);
                  *(byte **)(&stack0x00000860 + lVar25) = pbVar48;
                  *(undefined4 *)(&stack0x0000085c + lVar25) = 9;
                  *(undefined4 *)(&stack0x00000888 + lVar25) = 0;
                  *(longlong *)(&stack0x00000880 + lVar25) = lVar34 + 0x2000;
                  *(byte ***)(&stack0x00000868 + lVar25) = ppbVar26;
                }
              }
              if (*(short *)(&stack0x00000858 + lVar25) == 0) {
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102d4e;
                func_0x();
              }
              else {
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102d55;
                func_0x(&stack0x0000085a + lVar25,&stack0x0000015a + lVar25);
              }
              iVar21 = *(int *)(&stack0x0000015a + lVar25);
              *(int *)(&stack0x000000d0 + lVar25) = iVar21;
              sVar16 = *(short *)(&stack0x0000015e + lVar25);
              *(short *)(&stack0x000000d4 + lVar25) = sVar16;
              if ((sVar16 == *(short *)(&stack0x00000090 + lVar25)) && (iVar21 == iVar19)) {
                lVar31 = *(longlong *)(&stack0x00000108 + lVar25);
              }
              else {
                *(int *)(&stack0x00000098 + lVar25) = iVar21;
                *(short *)(&stack0x0000009c + lVar25) = sVar16;
                lVar31 = *(longlong *)(&stack0x00000108 + lVar25);
                *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102d94;
                iVar19 = func_0x(lVar31,&stack0x00000098 + lVar25);
                if (iVar19 == 3) goto code_r0x0010371d;
                iVar19 = *(int *)(&stack0x000000d0 + lVar25);
                *(int *)(&stack0x00000094 + lVar25) = iVar19;
                *(undefined2 *)(&stack0x00000090 + lVar25) =
                     *(undefined2 *)(&stack0x000000d4 + lVar25);
              }
              lVar35 = *(longlong *)(&stack0x00000100 + lVar25);
            }
          }
          if ((&stack0x0000003c)[lVar25] != '\0') goto LAB_;
          (&stack0x00000936)[lVar25] = 1;
          lVar34 = **(longlong **)(uVar59 + 0x58);
          uVar24 = *(undefined4 *)(uVar59 + 0x50);
          *(undefined4 *)(&stack0x000001b0 + lVar25) = *(undefined4 *)(lVar34 + 0x20);
          *(undefined2 *)(&stack0x000001b4 + lVar25) = *(undefined2 *)(lVar34 + 0x24);
          *(short *)(&stack0x000001b6 + lVar25) = (short)uVar24;
          uVar3 = *(undefined2 *)(*(longlong *)(lVar31 + 0x30) + 0x6b8);
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102e1c;
          func_0x(&stack0x00000928 + lVar25,uVar3,&stack0x000001b0 + lVar25);
          *(undefined4 *)((longlong)&uStackX_20 + lVar25 + -0x20) = 1;
          *(undefined4 *)(&stack0xfffffffffffffff8 + lVar25) = 0;
          *(undefined4 *)(&stack0xfffffffffffffff0 + lVar25) = 1;
          *(ulonglong *)(&stack0xffffffffffffffe8 + lVar25) = uVar59 + 0x90;
          *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102e4a;
          iVar21 = func_0x(plVar58,&stack0x00000928 + lVar25);
          if (iVar21 < 0) goto LAB_;
          if (iVar21 != 1) goto LAB_;
          (&stack0x0000003c)[lVar25] = 1;
        } while( true );
      }
      if (iVar19 == 0) goto LAB_;
      goto LAB_;
    }
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1022a5;
    func_0x(uVar59 + 0x30,1);
    if (*(int *)(uVar59 + 0xf0) == 3) goto LAB_;
  }
  else {
    pcVar6 = *(code **)(*plVar58 + 0x28);
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1020cb;
    cVar12 = (*pcVar6)(plVar58);
    if (cVar12 != '\0') goto LAB_;
    uVar24 = *(undefined4 *)(*(longlong *)(uVar59 + 0x40) + 0x90);
    uVar3 = *(undefined2 *)(*(longlong *)(uVar59 + 0x40) + 0x94);
    uVar4 = *(undefined2 *)
             (*(longlong *)(*(longlong *)(*(longlong *)(uVar59 + 0x38) + 8) + 0x30) + 0x6b8);
    (&stack0x00000756)[lVar25] = 6;
    *(undefined2 *)(&stack0x00000754 + lVar25) = uVar4;
    *(undefined8 *)(&stack0x0000074c + lVar25) = 0;
    *(undefined4 *)(&stack0x00000748 + lVar25) = uVar24;
    *(undefined2 *)(&stack0x0000074c + lVar25) = uVar3;
    *(undefined4 *)((longlong)&uStackX_20 + lVar25 + -0x20) = 1;
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar25) = 1;
    *(undefined4 *)(&stack0xfffffffffffffff0 + lVar25) = 1;
    *(ulonglong *)(&stack0xffffffffffffffe8 + lVar25) = uVar59 + 0xc0;
    *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102150;
    iVar19 = func_0x(uVar59 + 0x30,&stack0x00000748 + lVar25,2);
    if (-1 < iVar19) goto LAB_;
    if ((*(longlong *)(uVar59 + 0x40) != CONCAT44(uRam0000000001ed926c,_DAT_)) ||
       (*(longlong *)(uVar59 + 0x48) != CONCAT44(uRam0000000001ed9274,_DAT_))) {
      if ((*(byte *)(uVar59 + 0xa0) & 2) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102191;
        iVar19 = func_0x(uVar59 + 0xa8);
        if (iVar19 != 0) {
          plVar58 = (longlong *)(*(longlong *)(uVar59 + 0x30) + 0x30);
          *plVar58 = *plVar58 + -1;
        }
      }
      *(undefined *)(uVar59 + 0xa0) = 0;
      *(undefined4 *)(uVar59 + 0x9c) = 0;
      *(undefined4 *)(uVar59 + 0xb8) = 0;
      if ((*(byte *)(uVar59 + 0xd0) & 2) != 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x1021d1;
        iVar19 = func_0x(uVar59 + 0xd8);
        if (iVar19 != 0) {
          plVar58 = (longlong *)(*(longlong *)(uVar59 + 0x30) + 0x30);
          *plVar58 = *plVar58 + -1;
        }
      }
      *(undefined *)(uVar59 + 0xd0) = 0;
      *(undefined4 *)(uVar59 + 0xcc) = 0;
      *(undefined4 *)(uVar59 + 0xe8) = 0;
      if (*(longlong *)(uVar59 + 0x58) != 0) {
        if (*(longlong *)(uVar59 + 0x58) != 0) {
          *(undefined *)(uVar59 + 0x66) = 0;
          *(undefined8 *)(uVar59 + 0x58) = 0;
          *(undefined2 *)(uVar59 + 100) = 0;
        }
        *(undefined4 *)(*(longlong *)(uVar59 + 0x40) + 0x48) = 0;
      }
      uVar27 = **(undefined8 **)(uVar59 + 0x30);
      *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x102229;
      func_0x(uVar27,uVar59 + 0x40);
      uVar10 = uRam0000000001ed9274;
      uVar5 = _DAT_;
      uVar24 = uRam0000000001ed926c;
      *(undefined4 *)(uVar59 + 0x40) = _DAT_;
      *(undefined4 *)(uVar59 + 0x44) = uVar24;
      *(undefined4 *)(uVar59 + 0x48) = uVar5;
      *(undefined4 *)(uVar59 + 0x4c) = uVar10;
      *(undefined4 *)(uVar59 + 0x50) = 0xffffffff;
      *(undefined4 *)(uVar59 + 0x270) = 0;
      *(undefined8 *)(uVar59 + 0x288) = 0;
      *(undefined8 *)(uVar59 + 0x280) = 0;
      *(undefined8 *)(uVar59 + 0x290) = 0;
      *(undefined4 *)(uVar59 + 0x2a0) = 0xffffffff;
      *(undefined2 *)(uVar59 + 0x2a4) = 0xffff;
      *(undefined8 *)(uVar59 + 0x2a6) = 0;
      *(undefined4 *)(uVar59 + 0xf0) = 2;
    }
  }
LAB_:
  *(uint *)(uVar59 + 0x634) = *(uint *)(uVar59 + 0x634) | 1;
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar25) = 0x100610;
  func_0x(*(undefined8 *)(&stack0x00000118 + lVar25),&stack0x000001d0 + lVar25);
  puVar45 = &stack0xffffffffffffffc8 + lVar25;
LAB_:
  uVar49 = *(ulonglong *)(&stack0x00002928 + lVar25);
  *(undefined8 *)(puVar45 + -8) = 0x10061f;
  func_0x(uVar49 ^ (ulonglong)puVar1);
  return;
}

