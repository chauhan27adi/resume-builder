
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,ulonglong param_2,longlong *param_3,undefined8 param_4)

{
  byte *pbVar1;
  code *pcVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  char *pcVar5;
  ushort *puVar6;
  byte bVar7;
  char cVar8;
  int iVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong lVar12;
  undefined8 *puVar13;
  longlong lVar14;
  short sVar15;
  ushort uVar16;
  ulonglong uVar17;
  byte *pbVar18;
  longlong lVar19;
  uint uVar20;
  uint uVar21;
  undefined4 uVar22;
  byte *pbVar23;
  ushort uVar24;
  ulonglong uVar25;
  uint uVar27;
  int iVar28;
  uint uVar29;
  ushort *puVar30;
  ulonglong uVar31;
  int iVar32;
  longlong unaff_GS_OFFSET;
  undefined auStackX_8 [4];
  uint auStackX_c [3];
  short sStackX_18;
  short sStackX_1a;
  uint uStackX_1c;
  byte *pbStackX_20;
  undefined8 uStack_40;
  ulonglong uVar26;
  
  uStack_40 = 0x100016;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  *(undefined8 *)(&stack0x000000c8 + lVar10) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x00002088 + lVar10) =
       _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar10);
  *(undefined8 *)(&stack0x00000068 + lVar10) = param_4;
  *(longlong **)(&stack0x00000070 + lVar10) = param_3;
  uVar27 = (uint)param_2;
  uVar17 = param_2 & 0xffffffff;
  *(uint *)((longlong)auStackX_c + lVar10) = uVar27;
  *(longlong *)(&stack0x00000080 + lVar10) = param_1;
  lVar12 = *(longlong *)(&stack0x000020f8 + lVar10);
  *(longlong *)(&stack0x000000a0 + lVar10) = lVar12;
  *(undefined8 *)(&stack0x00000098 + lVar10) = *(undefined8 *)(&stack0x00002100 + lVar10);
  iVar32 = 0;
  *(undefined8 *)(&stack0x000000c0 + lVar10) = 0;
  *(undefined (*) [16])(&stack0x000000b0 + lVar10) = ZEXT816(0);
  *(undefined2 *)((longlong)&sStackX_18 + lVar10) = 0xffff;
  *(undefined8 *)((longlong)&pbStackX_20 + lVar10) = 0;
  *(undefined4 *)((longlong)&sStackX_18 + lVar10 + 4) = 0;
  *(undefined8 *)(&stack0x00000036 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000040 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000028 + lVar10) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1000ca;
  func_0x(&stack0x000000e8 + lVar10,0,0x1f9e);
  *(undefined4 *)(&stack0x0000007c + lVar10) = 0;
  *(undefined4 *)(&stack0x00000058 + lVar10) = 0;
  *(undefined4 *)(&stack0x00000078 + lVar10) = 0;
  *(undefined4 *)(&stack0x00000054 + lVar10) = 0;
  *(undefined4 *)(&stack0x00000060 + lVar10) = 0;
  *(undefined4 *)(&stack0x0000005c + lVar10) = 0;
  lVar14 = *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x30);
  if (((*(byte *)(*(longlong *)(**(longlong **)(*(uint **)(param_1 + 0x108) + 8) + 8) + 0x107) &
       0x40) == 0) ||
     (uVar20 = **(uint **)(param_1 + 0x108), auStackX_8[lVar10] = 1, (uVar20 & 0x1000000) != 0)) {
    auStackX_8[lVar10] = 0;
  }
  uVar20 = uVar27 & 0xc2;
  *(uint *)((longlong)auStackX_c + lVar10 + 4) = uVar20;
  if ((lVar12 != 0) && ((param_2 & 8) != 0)) {
    iVar32 = 1;
  }
  *(int *)(&stack0x00000050 + lVar10) = iVar32;
  *(uint *)(param_3 + 2) = *(uint *)(param_3 + 2) & 0xfffffeff;
  if (((char)*(uint *)(param_3 + 2) < '\0') || ((*(byte *)((longlong)param_3 + 0x34) & 1) == 0)) {
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100187;
    plVar11 = (longlong *)func_0x(param_3,0);
  }
  else if ((*(uint *)(param_3 + 2) >> 0xd & 1) == 0) {
    plVar11 = param_3 + 9;
  }
  else {
    plVar11 = (longlong *)param_3[0x29];
  }
  if (*(char *)(lVar14 + 0x1cde) != '\0') {
    lVar12 = *(longlong *)(param_1 + 0x108);
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1001b7;
    func_0x(param_3,lVar12 + 0x90,auStackX_8[lVar10],&stack0x000000a8 + lVar10);
    *(uint *)(param_3 + 2) = *(uint *)(param_3 + 2) & 0xfffffeff;
    if (((char)*(uint *)(param_3 + 2) < '\0') || ((*(byte *)((longlong)param_3 + 0x34) & 1) == 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1001ed;
      plVar11 = (longlong *)func_0x(param_3,0);
    }
    else if ((*(uint *)(param_3 + 2) >> 0xd & 1) == 0) {
      plVar11 = param_3 + 9;
    }
    else {
      plVar11 = (longlong *)param_3[0x29];
    }
    if (plVar11 == (longlong *)0x0) {
      *(uint *)(param_3 + 2) = *(uint *)(param_3 + 2) | 0x100;
      goto LAB_;
    }
  }
  if (((((param_2 & 0x10) != 0) || (iVar32 != 0)) || ((param_2 & 0xc2) != 0)) ||
     (iVar32 = 0, (uVar27 >> 8 & 1) != 0)) {
    sVar15 = *(short *)plVar11;
    *(short *)((longlong)&sStackX_18 + lVar10) = sVar15;
    if (sVar15 == 0) {
      uVar27 = *(uint *)((longlong)plVar11 + 4);
      if (uVar27 == 0) {
        iVar32 = 0;
        *(short *)((longlong)plVar11 + 2) = 0;
        uVar27 = *(uint *)(plVar11 + 2);
        uVar17 = (ulonglong)uVar27;
        *(uint *)((longlong)plVar11 + 0x14) = uVar27;
        pbVar23 = (byte *)plVar11[1];
        bVar7 = *pbVar23;
        if ((bVar7 & 0x10) != 0) {
          uVar27 = uVar27 + 2 + (*(ushort *)(pbVar23 + uVar17) + 7 >> 3);
          uVar17 = (ulonglong)uVar27;
          *(uint *)((longlong)plVar11 + 0x14) = uVar27;
          bVar7 = *pbVar23;
        }
        iVar28 = (int)uVar17;
        if ((bVar7 & 0x20) == 0) {
          *(int *)((longlong)plVar11 + 4) = iVar28;
          *(short *)((longlong)plVar11 + 0x1c) = 0;
          *(int *)(plVar11 + 3) = iVar28;
        }
        else {
          puVar30 = (ushort *)(pbVar23 + uVar17);
          uVar16 = *puVar30;
          *(ushort *)((longlong)plVar11 + 0x1c) = uVar16;
          if (uVar16 == 0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10029c;
            cVar8 = func_0x(0x1f1dce0);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1002a5;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1002bf;
                cVar8 = func_0x(0x1f1dce0);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1002db;
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100301;
                  (*_DAT_)(1,0x180d6ec,0x192d7d8,0x80f);
                }
              }
            }
            lVar12 = plVar11[1];
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10030f;
            func_0x(lVar12,3);
            iVar28 = *(int *)((longlong)plVar11 + 0x14);
            pbVar23 = (byte *)plVar11[1];
            uVar16 = *(ushort *)((longlong)plVar11 + 0x1c);
          }
          uVar27 = iVar28 + (uVar16 + 1) * 2;
          *(uint *)(plVar11 + 3) = uVar27;
          if (0x1f9e < uVar27) {
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100344;
            cVar8 = func_0x(0x1f1dce0);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10034d;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100367;
                cVar8 = func_0x(0x1f1dce0);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100383;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1003a9;
                  (*_DAT_)(1,0x180d6ec,0x192d7d8,0x816);
                }
              }
            }
            lVar12 = plVar11[1];
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1003b7;
            func_0x(lVar12,4);
            uVar16 = *(ushort *)((longlong)plVar11 + 0x1c);
            pbVar23 = (byte *)plVar11[1];
            uVar27 = *(uint *)(plVar11 + 3);
          }
          uVar17 = (ulonglong)uVar16;
          uVar16 = puVar30[uVar17];
          *(uint *)((longlong)plVar11 + 4) = uVar16 & 0x7fff;
          if ((uVar16 & 0x7fff) < uVar27) {
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1003eb;
            cVar8 = func_0x(0x1f1dce0);
            if (cVar8 != '\0') {
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1003f4;
              lVar12 = func_0x();
              if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10040e;
                cVar8 = func_0x(0x1f1dce0);
                if (cVar8 == '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10042a;
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100450;
                  (*_DAT_)(1,0x180d6ec,0x192d7d8,0x81d);
                }
              }
            }
            lVar12 = plVar11[1];
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10045e;
            func_0x(lVar12,4);
            uVar27 = *(uint *)(plVar11 + 3);
            uVar17 = (ulonglong)*(ushort *)((longlong)plVar11 + 0x1c);
            pbVar23 = (byte *)plVar11[1];
          }
          puVar6 = puVar30;
          if ((short)uVar17 != 0) {
            do {
              uVar20 = puVar6[1] & 0x7fff;
              if ((uVar20 < uVar27) || (*(uint *)((longlong)plVar11 + 4) < uVar20)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1004a0;
                cVar8 = func_0x(0x1f1dce0);
                if (cVar8 != '\0') {
                  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1004a9;
                  lVar12 = func_0x();
                  if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
                    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1004c3;
                    cVar8 = func_0x(0x1f1dce0);
                    if (cVar8 == '\0') {
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1004df;
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100505;
                      (*_DAT_)(1,0x180d6ec,0x192d7d8,0x82a);
                    }
                  }
                }
                lVar12 = plVar11[1];
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100513;
                func_0x(lVar12,4);
              }
              iVar32 = iVar32 + 1;
              uVar17 = (ulonglong)*(ushort *)((longlong)plVar11 + 0x1c);
              puVar6 = puVar6 + 1;
              uVar27 = uVar20;
            } while (iVar32 < (int)(uint)*(ushort *)((longlong)plVar11 + 0x1c));
            pbVar23 = (byte *)plVar11[1];
          }
          uVar26 = uVar17;
          if ((short)puVar30[(ulonglong)((int)uVar17 - 1) + 1] < 0) {
LAB_:
            sVar15 = (short)uVar17;
            uVar20 = *(ushort *)
                      (pbVar23 + uVar26 * 2 + (ulonglong)*(uint *)((longlong)plVar11 + 0x14)) &
                     0x7fff;
            if ((int)uVar26 == 1) {
              uVar21 = *(uint *)(plVar11 + 3);
              uVar29 = uVar21;
LAB_:
              if ((uVar20 < uVar21) || (uVar27 = *(uint *)((longlong)plVar11 + 4), uVar27 < uVar20))
              goto LAB_;
            }
            else {
              uVar21 = *(ushort *)
                        (pbVar23 + uVar26 * 2 + ((ulonglong)*(uint *)((longlong)plVar11 + 0x14) - 2)
                        ) & 0x7fff;
              uVar29 = *(uint *)(plVar11 + 3);
              if (uVar29 <= uVar21) goto LAB_;
LAB_:
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1005a3;
              func_0x(pbVar23,7);
              uVar29 = *(uint *)(plVar11 + 3);
              uVar27 = *(uint *)((longlong)plVar11 + 4);
              pbVar23 = (byte *)plVar11[1];
              sVar15 = *(short *)((longlong)plVar11 + 0x1c);
            }
            if ((uVar21 < uVar29) || (uVar27 < uVar21)) goto LAB_;
            if (*(ushort *)(pbVar23 + uVar21) == 5) {
              *(ushort *)((longlong)plVar11 + 2) = *(ushort *)((longlong)plVar11 + 2) | 2;
              *(short *)((longlong)plVar11 + 0x1c) = sVar15 + -1;
              uVar25 = (ulonglong)(uVar21 & 0xffff);
              *(short *)((longlong)plVar11 + 0x2a) = (short)uVar21;
              uVar26 = plVar11[1];
              uVar17 = uVar26 + uVar25;
              uVar16 = *(ushort *)((longlong)plVar11 + 0x2c) & 0xc7ff;
              if ((*(ushort *)(uVar17 + 2) >> 0xe & 1) != 0) {
                uVar16 = *(ushort *)(uVar17 + 2) & 0x3800 | uVar16;
              }
              *(ushort *)((longlong)plVar11 + 0x2c) = uVar16;
              uVar24 = (uVar16 ^ *(ushort *)(uVar17 + 2)) & 0x7ff ^ uVar16;
              *(ushort *)((longlong)plVar11 + 0x2c) = uVar24;
              uVar31 = (ulonglong)((uVar24 & 0x7ff) * 2) + 4 + uVar26 + (uVar16 >> 0xb & 7) * 2 +
                       uVar25;
              if (uVar31 < uVar17) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1006bc;
                func_0x(uVar17,0x19);
                uVar24 = *(ushort *)((longlong)plVar11 + 0x2c);
                uVar25 = (ulonglong)*(ushort *)((longlong)plVar11 + 0x2a);
                uVar26 = (ulonglong)*(uint *)(plVar11 + 1);
              }
              if (uVar20 - uVar21 <
                  (((uVar24 & 0x7ff) * 2 - (int)uVar25) - (int)uVar26) + (int)uVar31) {
                lVar12 = plVar11[1];
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1006f4;
                func_0x(uVar25 + lVar12,0x19);
                uVar24 = *(ushort *)((longlong)plVar11 + 0x2c);
              }
              if ((uVar24 & 0x3800) != 0) {
                puVar30 = (ushort *)
                          (plVar11[1] + (ulonglong)*(ushort *)((longlong)plVar11 + 0x2a) + 4);
                iVar32 = 0;
                if ((uVar24 & 0x3800) != 0) {
                  do {
                    if ((uVar24 & 0x7ff) < (*puVar30 & 0x7ff)) {
                      uVar16 = *(ushort *)((longlong)plVar11 + 0x2a);
                      lVar12 = plVar11[1];
                      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100748;
                      func_0x((ulonglong)uVar16 + lVar12,0x1a);
                      uVar24 = *(ushort *)((longlong)plVar11 + 0x2c);
                    }
                    iVar32 = iVar32 + 1;
                    puVar30 = puVar30 + 1;
                  } while (iVar32 < (int)(uVar24 >> 0xb & 7));
                }
              }
              pbVar23 = (byte *)plVar11[1];
              uVar17 = (ulonglong)*(uint *)((longlong)plVar11 + 4);
              goto LAB_;
            }
            if (0x3ff < *(ushort *)(pbVar23 + uVar21)) {
              *(ushort *)((longlong)plVar11 + 2) = *(ushort *)((longlong)plVar11 + 2) | 1;
              uVar16 = sVar15 - 1;
              *(ushort *)((longlong)plVar11 + 0x1c) = uVar16;
              if (uVar16 != 0) goto code_r0x001005ee;
            }
          }
LAB_:
          uVar17 = (ulonglong)*(uint *)((longlong)plVar11 + 4);
        }
LAB_:
        if ((*pbVar23 & 0x40) == 0) {
          *(undefined4 *)((longlong)plVar11 + 0x26) = 0;
        }
        else {
          *(int *)((longlong)plVar11 + 0x26) = (int)uVar17;
          *(int *)((longlong)plVar11 + 4) = (int)uVar17 + 0xe;
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1007b2;
          puVar13 = (undefined8 *)func_0x((short *)((longlong)plVar11 + 2));
          *(undefined8 *)(&stack0x00000090 + lVar10) = *puVar13;
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1007ca;
          iVar32 = func_0x(&stack0x00000090 + lVar10);
          *(int *)((longlong)plVar11 + 4) = *(int *)((longlong)plVar11 + 4) + iVar32;
          uVar17 = (ulonglong)*(uint *)((longlong)plVar11 + 4);
          pbVar23 = (byte *)plVar11[1];
        }
        uVar27 = (uint)uVar17;
        if ((*(byte **)((longlong)plVar11 + 0x1e) != (byte *)0x0) &&
           (*(byte **)((longlong)plVar11 + 0x1e) < pbVar23 + uVar17)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10080b;
          cVar8 = func_0x(0x1f1dce0);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100814;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10082e;
              cVar8 = func_0x(0x1f1dce0);
              if (cVar8 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10084a;
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100870;
                (*_DAT_)(1,0x180d6ec,0x192d7d8,0x886);
              }
            }
          }
          lVar12 = plVar11[1];
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10087e;
          func_0x(lVar12,0x12);
          uVar27 = *(uint *)((longlong)plVar11 + 4);
        }
        if ((uVar27 == 0) || (0x3f3c < uVar27)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10089e;
          cVar8 = func_0x(0x1f1dce0);
          if (cVar8 != '\0') {
            *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1008a7;
            lVar12 = func_0x();
            if ((lVar12 != 0) && (*(char *)(lVar12 + 0x499) != '\0')) {
              *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1008c1;
              cVar8 = func_0x(0x1f1dce0);
              if (cVar8 == '\0') {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1008dd;
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100903;
                (*_DAT_)(1,0x180d6ec,0x192d7d8,0x88b);
              }
            }
          }
          lVar12 = plVar11[1];
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100911;
          func_0x(lVar12,5);
          uVar27 = *(uint *)((longlong)plVar11 + 4);
        }
      }
LAB_:
      if ((uVar27 < 9) &&
         (((*(byte *)plVar11[1] & 0xe) == 0 || ((*(byte *)plVar11[1] & 0xe) == 0xc)))) {
        uVar27 = 9;
      }
      *(undefined4 *)(&stack0x00000028 + lVar10) = *(undefined4 *)(plVar11 + 2);
      *(short *)((longlong)&sStackX_18 + lVar10 + 2) = *(short *)((longlong)plVar11 + 2);
      *(undefined4 *)((longlong)&sStackX_18 + lVar10 + 4) = *(undefined4 *)((longlong)plVar11 + 4);
      *(short *)(&stack0x00000034 + lVar10) = *(short *)((longlong)plVar11 + 0x1c);
      *(undefined4 *)(&stack0x0000002c + lVar10) = *(undefined4 *)((longlong)plVar11 + 0x14);
      *(undefined4 *)(&stack0x00000030 + lVar10) = *(undefined4 *)(plVar11 + 3);
      *(undefined4 *)(&stack0x0000003e + lVar10) = *(undefined4 *)((longlong)plVar11 + 0x26);
      lVar12 = plVar11[1];
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x10099e;
      func_0x(&stack0x000000e8 + lVar10,0x1f9e,lVar12,uVar27);
      *(undefined **)((longlong)&pbStackX_20 + lVar10) = &stack0x000000e8 + lVar10;
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1009b5;
      iVar32 = func_0x((longlong)&sStackX_18 + lVar10 + 2);
      pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar10);
      if (iVar32 != 0) {
        puVar30 = (ushort *)(pbVar23 + *(uint *)(&stack0x0000002c + lVar10));
        uVar27 = *puVar30 - 1;
        if ((*(byte *)((longlong)&sStackX_18 + lVar10 + 2) & 1) == 0) {
          uVar27 = (uint)*puVar30;
        }
        uVar20 = *(uint *)(&stack0x00000030 + lVar10);
        if (uVar27 != 1) {
          uVar20 = puVar30[(longlong)(int)uVar27 + -1] & 0x7fff;
        }
        uVar27 = puVar30[(int)uVar27] & 0x7fff;
        if (((uVar20 < *(uint *)(&stack0x00000030 + lVar10)) || (uVar27 < uVar20)) ||
           (*(uint *)((longlong)&sStackX_18 + lVar10 + 4) < uVar27)) {
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100a17;
          func_0x(pbVar23,7);
          pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar10);
        }
        uVar17 = (ulonglong)(uVar20 & 0xffff);
        *(short *)(&stack0x00000042 + lVar10) = (short)uVar20;
        pbVar1 = pbVar23 + uVar17;
        uVar16 = *(ushort *)(&stack0x00000044 + lVar10);
        if ((*(ushort *)(pbVar1 + 2) & 0x4000) == 0) {
          uVar16 = uVar16 & 0xc7ff;
        }
        else {
          uVar16 = uVar16 ^ (uVar16 ^ *(ushort *)(pbVar1 + 2)) & 0x3800;
        }
        *(ushort *)(&stack0x00000044 + lVar10) = uVar16;
        uVar24 = (uVar16 ^ *(ushort *)(pbVar1 + 2)) & 0x7ff ^ uVar16;
        uVar26 = (ulonglong)uVar24;
        *(ushort *)(&stack0x00000044 + lVar10) = uVar24;
        pbVar18 = pbVar23 + uVar17 + (uVar26 & 0x7ff) * 2 + (ulonglong)((uVar16 >> 0xb & 7) * 2) + 4
        ;
        if (pbVar18 < pbVar1) {
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100a9d;
          func_0x(pbVar1,0x19);
          uVar26 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar10);
          uVar17 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar10);
          pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar10);
        }
        if (uVar27 - uVar20 <
            (((*(uint *)(&stack0x00000044 + lVar10) & 0x7ff) * 2 - (int)uVar17) -
            *(int *)((longlong)&pbStackX_20 + lVar10)) + (int)pbVar18) {
          *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100ad7;
          func_0x(pbVar23 + uVar17,0x19);
          uVar26 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar10);
          uVar17 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar10);
          pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar10);
        }
        if ((uVar26 & 0x3800) != 0) {
          puVar30 = (ushort *)(pbVar23 + uVar17 + 4);
          iVar32 = 0;
          if ((uVar26 & 0x3800) != 0) {
            do {
              if (((ushort)uVar26 & 0x7ff) < (*puVar30 & 0x7ff)) {
                *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100b33;
                func_0x(pbVar23 + uVar17,0x1a);
                uVar26 = (ulonglong)*(ushort *)(&stack0x00000044 + lVar10);
                uVar17 = (ulonglong)*(ushort *)(&stack0x00000042 + lVar10);
                pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar10);
              }
              iVar32 = iVar32 + 1;
              puVar30 = puVar30 + 1;
            } while (iVar32 < (int)(*(uint *)(&stack0x00000044 + lVar10) >> 0xb & 7));
          }
        }
      }
      uVar20 = *(uint *)((longlong)auStackX_c + lVar10 + 4);
      uVar17 = (ulonglong)*(uint *)((longlong)auStackX_c + lVar10);
      param_1 = *(longlong *)(&stack0x00000080 + lVar10);
      param_3 = *(longlong **)(&stack0x00000070 + lVar10);
    }
    else if (((*(short *)plVar11 == 0) || ((longlong *)plVar11[2] == (longlong *)0x0)) ||
            (*(longlong *)plVar11[2] == 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100be7;
      func_0x((longlong)&sStackX_18 + lVar10 + 2,&stack0x000000e8 + lVar10,0x1f9e,
                      (short *)((longlong)plVar11 + 2));
      if (*(short *)plVar11 == 0) {
        *(undefined8 *)(&stack0x00000028 + lVar10) = 0;
        pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar10);
      }
      else {
        *(longlong *)(&stack0x00000028 + lVar10) = plVar11[2];
        pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar10);
      }
    }
    else {
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100bc1;
      func_0x((longlong)&sStackX_18 + lVar10,&stack0x000000e8 + lVar10,0x1f9e,plVar11);
      pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar10);
    }
    if (*(short *)((longlong)&sStackX_18 + lVar10) == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100b86;
      func_0x((longlong)&sStackX_18 + lVar10 + 2);
    }
    else if ((*pbVar23 & 2) != 0) {
      if (*(int *)((longlong)&sStackX_18 + lVar10 + 4) == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100c30;
        func_0x((longlong)&sStackX_18 + lVar10 + 2);
        pbVar23 = *(byte **)((longlong)&pbStackX_20 + lVar10);
      }
      *pbVar23 = *pbVar23 & 0xfd;
      *(undefined4 *)((longlong)&sStackX_18 + lVar10 + 4) =
           *(undefined4 *)(&stack0x00000048 + lVar10);
      *(undefined4 *)(&stack0x00000048 + lVar10) = 0;
    }
    lVar12 = *(longlong *)(param_1 + 0x108);
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100c70;
    func_0x(param_3,lVar12 + 0x90,auStackX_8[lVar10],&stack0x000000a8 + lVar10);
    iVar32 = *(int *)(&stack0x00000050 + lVar10);
  }
  pcVar2 = *(code **)(*param_3 + 8);
  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100c81;
  (*pcVar2)(param_3);
  if ((uVar20 == 0) && ((uVar17 & 0x10) == 0)) {
    iVar28 = *(int *)(&stack0x00000078 + lVar10);
  }
  else {
    *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000054 + lVar10;
    uVar3 = *(undefined8 *)(param_1 + 0x1e8);
    uVar4 = *(undefined8 *)(param_1 + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100cb0;
    func_0x(uVar4,uVar3,(longlong)&sStackX_18 + lVar10,uVar17);
    iVar28 = *(int *)(&stack0x00000054 + lVar10);
  }
  uVar3 = *(undefined8 *)(&stack0x00000068 + lVar10);
  if (iVar32 == 0) {
    iVar32 = *(int *)(&stack0x0000007c + lVar10);
  }
  else {
    *(undefined **)(&stack0xfffffffffffffff0 + lVar10) = &stack0x00000058 + lVar10;
    *(undefined8 *)(&stack0xffffffffffffffe8 + lVar10) = uVar3;
    uVar4 = *(undefined8 *)(param_1 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100d00;
    func_0x(uVar4,(longlong)&sStackX_18 + lVar10,*(undefined8 *)(&stack0x000000a0 + lVar10),
                    *(undefined8 *)(&stack0x00000098 + lVar10));
    iVar32 = *(int *)(&stack0x00000058 + lVar10);
  }
  if (((uint)uVar17 >> 8 & 1) == 0) {
    iVar9 = *(int *)(&stack0x00000060 + lVar10);
  }
  else {
    uVar4 = *(undefined8 *)(param_1 + 0x1e8);
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100d32;
    func_0x(uVar4,(longlong)&sStackX_18 + lVar10,uVar3,&stack0x0000005c + lVar10);
    iVar9 = *(int *)(&stack0x0000005c + lVar10);
  }
  if ((((iVar32 != 0) || (iVar28 != 0)) || (iVar9 != 0)) && ((uVar17 & 0x20) == 0)) {
    pcVar5 = *(char **)(param_1 + 0x380);
    if ((((pcVar5 == (char *)0x0) || (pcVar5[3] == '\0')) || (*pcVar5 == '\0')) ||
       (pcVar5[1] == '\0')) {
      uVar22 = *(undefined4 *)(param_1 + 0x2f0);
    }
    else {
      uVar22 = 2;
    }
    *(uint *)((longlong)&pbStackX_20 + lVar10 + -0x20) = **(uint **)(param_1 + 0x108) >> 0x1b & 1;
    *(undefined8 *)(&stack0xfffffffffffffff8 + lVar10) = 0;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar10) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x000000a8 + lVar10;
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100dc4;
    func_0x(param_3,(longlong)&sStackX_18 + lVar10,uVar22,0);
  }
  lVar12 = 0;
  if ((uVar17 & 4) != 0) {
    *(undefined4 *)(&stack0x00000060 + lVar10) = 0x3d51;
    lVar19 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar14 = *(longlong *)(lVar19 + 0x100);
    if (lVar14 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100e16;
      (*_DAT_)(0);
      lVar14 = *(longlong *)(lVar19 + 0x100);
    }
    uVar3 = *(undefined8 *)(lVar14 + 1000);
    *(undefined8 *)(&stack0x000000a0 + lVar10) = uVar3;
    (&stack0xffffffffffffffe8)[lVar10] = 5;
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100e49;
    lVar14 = (*_DAT_)(0x110,uVar3,0x15a4580,0x3d51);
    *(longlong *)(&stack0x00000098 + lVar10) = lVar14;
    if (lVar14 != 0) {
      lVar19 = (ulonglong)*_DAT_ +
               *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
      lVar12 = *(longlong *)(lVar19 + 0x100);
      if (lVar12 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100e8c;
        (*_DAT_)(0);
        lVar12 = *(longlong *)(lVar19 + 0x100);
      }
      uVar3 = *(undefined8 *)(lVar12 + 1000);
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100ea2;
      lVar12 = func_0x(lVar14,uVar3);
    }
    *(longlong *)(&stack0x00000068 + lVar10) = lVar12;
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100ec2;
    func_0x(lVar12,0,0x110);
    *(undefined2 *)(lVar12 + 0xe) = 2;
    *(ushort *)(lVar12 + 0x38) = *(ushort *)(lVar12 + 0x38) | 2;
    *(undefined8 *)(&stack0xfffffffffffffff0 + lVar10) = 0;
    *(undefined **)(&stack0xffffffffffffffe8 + lVar10) = &stack0x00000090 + lVar10;
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100eee;
    func_0x(param_1,param_3,lVar12,0);
    *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100ef6;
    func_0x(lVar12);
    lVar14 = (ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
    lVar12 = *(longlong *)(lVar14 + 0x100);
    if (lVar12 == 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f28;
      (*_DAT_)();
      lVar12 = *(longlong *)(lVar14 + 0x100);
    }
    if (*(int *)(lVar12 + 0x22c) != 0) {
      *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f3e;
      (*_DAT_)();
    }
  }
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x100f4e;
  func_0x
            (*(ulonglong *)(&stack0x00002088 + lVar10) ^
             (ulonglong)(&stack0xffffffffffffffc8 + lVar10));
  return;
code_r0x001005ee:
  uVar17 = (ulonglong)uVar16;
  uVar26 = (ulonglong)(uint)uVar16;
  if (-1 < (short)puVar30[(ulonglong)(uVar16 - 1) + 1]) goto LAB_;
  goto LAB_;
}

