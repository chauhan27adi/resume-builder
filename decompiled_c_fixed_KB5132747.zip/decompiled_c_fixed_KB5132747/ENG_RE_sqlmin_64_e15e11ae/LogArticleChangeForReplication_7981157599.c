
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,ulonglong param_2,int param_3,ulonglong param_4,
                 longlong param_5)

{
  longlong *plVar1;
  code *pcVar2;
  longlong lVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  longlong lVar9;
  uint uVar10;
  uint uVar11;
  longlong lVar12;
  undefined8 unaff_RBX;
  uint uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  undefined8 uVar16;
  longlong lVar17;
  longlong unaff_GS_OFFSET;
  uint auStackX_8 [2];
  undefined8 uStackX_10;
  int iStackX_18;
  undefined auStackX_1c [12];
  short asStack_3248 [320];
  short asStack_2fc8 [264];
  short asStack_2db8 [1008];
  longlong lStack_25d8;
  undefined2 uStack_25d0;
  undefined8 uStack_25c8;
  int iStack_25c0;
  undefined auStack_25b8 [16];
  undefined auStack_25a8 [16];
  undefined auStack_2598 [16];
  undefined auStack_2588 [16];
  longlong lStack_2578;
  uint uStack_2570;
  undefined8 uStack_2568;
  undefined8 uStack_2560;
  longlong lStack_2558;
  undefined8 uStack_2550;
  undefined auStack_2548 [16];
  undefined8 uStack_2538;
  undefined4 uStack_2530;
  undefined auStack_252c [1024];
  undefined8 uStack_212c;
  undefined2 uStack_2124;
  undefined4 uStack_2018;
  longlong lStack_78;
  int iStack_70;
  undefined auStack_68 [8];
  undefined8 uStack_60;
  int iStack_58;
  longlong *plStack_50;
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  lVar9 = func_0x();
  lVar9 = -lVar9;
  *(undefined8 *)((longlong)&uStackX_10 + lVar9) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x000034e8 + lVar9) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9);
  iVar4 = (int)param_4;
  param_4 = param_4 & 0xffffffff;
  *(int *)((longlong)auStackX_8 + lVar9) = iVar4;
  *(int *)((longlong)auStackX_8 + lVar9 + 4) = param_3;
  *(short *)(&stack0xfffffffffffffff8 + lVar9) = (short)param_2;
  uVar14 = 0;
  uStack_2550 = 0;
  auStack_2548 = ZEXT816(0);
  uStack_2530 = 0;
  uStack_212c = 0;
  uStack_2124 = 0;
  uStack_2018 = 1;
  lStack_78 = 0;
  iStack_70 = 0;
  lStack_2558 = 0x1a72f08;
  plStack_50 = (longlong *)0x0;
  _auStack_68 = ZEXT816(0);
  iStack_58 = 1;
  uStack_2538 = 0;
  *(undefined4 *)(&stack0xfffffffffffffffc + lVar9) = 0;
  *(undefined4 *)(auStackX_1c + lVar9 + -0x18) = 0;
  if (param_3 == 0) {
    uVar16 = 0x1a6fa78;
  }
  else if (iVar4 == 0) {
    uVar16 = 0x1872d40;
  }
  else {
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10012e;
    func_0x(auStackX_1c + lVar9,0,0xeec);
    *(int *)((longlong)&iStackX_18 + lVar9) = iVar4;
    if (*(char *)(param_5 + 1) == '8') {
      *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10017a;
      iVar4 = func_0x(param_2 & 0xffff,0x1a73170);
      if (iVar4 == 0) {
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100198;
        func_0x(0x4977,0x10,3,0x1a73170);
      }
      else {
        pcVar2 = *(code **)(**(longlong **)
                              (*(longlong *)
                                ((ulonglong)*_DAT_ +
                                *(longlong *)
                                 (*(longlong *)(unaff_GS_OFFSET + 0x58) +
                                 (ulonglong)*_DAT_ * 8)) + 0x90) + 0x1b0);
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1001cf;
        uStack_25c8 = (*pcVar2)();
        lStack_25d8 = 0;
        auStack_25b8 = ZEXT816(0);
        auStack_25a8 = ZEXT816(0);
        auStack_2598 = ZEXT816(0);
        auStack_2588 = ZEXT816(0);
        lStack_2578 = 0;
        uStack_2570 = 0;
        uStack_2568 = 0;
        uStack_2560 = 0;
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100243;
        uStack_25d0 = (short)param_2;
        iStack_25c0 = iVar4;
        iVar4 = func_0x(&lStack_25d8,3,1);
        if (iVar4 == 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10025f;
          func_0x(0x49aa,0x10,9,0x1a73170);
        }
        else {
          lVar12 = *(longlong *)auStack_25b8._8_8_;
          *(longlong *)(&stack0xfffffffffffffff0 + lVar9) = lStack_25d8;
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = uStack_2568;
          pcVar2 = *(code **)(lVar12 + 0x18);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100293;
          iVar5 = (*pcVar2)(auStack_25b8._8_8_,0,1);
          iVar4 = *(int *)(&stack0xfffffffffffffffc + lVar9);
          while (iVar5 == 0) {
            *(undefined4 *)(auStackX_1c + lVar9 + -0x1c) = 0;
            if (((lStack_25d8 == 0) || (lStack_2578 == 0)) || (uStack_2570 == 0)) {
              lVar12 = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1002fe;
              uVar6 = func_0x(&lStack_25d8,0x180f1d8,auStackX_1c + lVar9 + -0x1c);
              lVar12 = 0;
              if (((lStack_2578 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uVar10 = 0, uStack_2570 != 0)
                 ) {
                do {
                  if (*(ulonglong *)((ulonglong)uVar10 * 0x58 + lStack_2578) == (ulonglong)uVar6) {
                    lVar12 = (ulonglong)uVar10 * 0x58 + lStack_2578;
                    if (lVar12 != 0) goto LAB_;
                    break;
                  }
                  uVar10 = uVar10 + 1;
                  lVar12 = 0;
                } while (uVar10 < uStack_2570);
              }
              *(int *)(&stack0xffffffffffffffe8 + lVar9) = iStack_25c0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100363;
              (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
              uVar14 = *(ulonglong *)(*(longlong *)(lVar12 + 0x10) + lStack_25d8);
              lVar12 = *(longlong *)(lVar12 + 8) + lStack_25d8;
              param_4 = (ulonglong)*(uint *)((longlong)auStackX_8 + lVar9);
            }
            uVar6 = uStack_2570;
            lVar3 = lStack_2578;
            lVar17 = lStack_25d8;
            if (uVar14 < 5) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003a2;
              func_0x(&stack0xfffffffffffffffc + lVar9,lVar12,uVar14);
              iVar4 = *(int *)(&stack0xfffffffffffffffc + lVar9);
            }
            *(undefined4 *)(auStackX_1c + lVar9 + -0x1c) = 0;
            if (((lVar17 == 0) || (lVar3 == 0)) || (uVar6 == 0)) {
              lVar12 = 0;
            }
            else {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1003dd;
              uVar6 = func_0x(&lStack_25d8,0x1872d40,auStackX_1c + lVar9 + -0x1c);
              lVar12 = 0;
              if (((lStack_2578 != 0) && (uVar6 - 1 < 0xfffffffe)) && (uVar10 = 0, uStack_2570 != 0)
                 ) {
                do {
                  if (*(ulonglong *)((ulonglong)uVar10 * 0x58 + lStack_2578) == (ulonglong)uVar6) {
                    lVar12 = (ulonglong)uVar10 * 0x58 + lStack_2578;
                    if (lVar12 != 0) goto LAB_;
                    break;
                  }
                  uVar10 = uVar10 + 1;
                  lVar12 = 0;
                } while (uVar10 < uStack_2570);
              }
              *(int *)(&stack0xffffffffffffffe8 + lVar9) = iStack_25c0;
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100444;
              (*_DAT_)(0xbb,0x38,0x10,0xd);
LAB_:
              uVar14 = *(ulonglong *)(*(longlong *)(lVar12 + 0x10) + lStack_25d8);
              lVar12 = *(longlong *)(lVar12 + 8) + lStack_25d8;
              lVar17 = lStack_25d8;
            }
            if (uVar14 < 5) {
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100471;
              func_0x(auStackX_1c + lVar9 + -0x18,lVar12,uVar14);
            }
            if ((iVar4 == *(int *)((longlong)auStackX_8 + lVar9 + 4)) &&
               (*(int *)(auStackX_1c + lVar9 + -0x18) == (int)param_4)) goto LAB_;
            lVar12 = *(longlong *)auStack_25b8._8_8_;
            *(longlong *)(&stack0xfffffffffffffff0 + lVar9) = lVar17;
            *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = uStack_2568;
            pcVar2 = *(code **)(lVar12 + 0x18);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004a7;
            iVar5 = (*pcVar2)(auStack_25b8._8_8_,0,1);
          }
          *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004d6;
          (*_DAT_)(1,0x1c28508,0x1c01fb0,0x220);
LAB_:
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1004ef;
          iVar5 = func_0x((longlong)&iStackX_18 + lVar9,param_4,&lStack_25d8);
          if (iVar5 == 0) {
            *(int *)(&stack0xffffffffffffffe8 + lVar9) = iVar4;
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10050e;
            (*_DAT_)(0xbb,0x38,0x10,5);
          }
          auStack_68._4_4_ = (int)param_4;
          auStack_68._0_4_ = iVar4;
          uStack_60 = 0x33;
          iStack_58 = 0;
          plVar1 = *(longlong **)
                    (*(longlong *)
                      ((ulonglong)*_DAT_ +
                      *(longlong *)
                       (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8)) +
                    0x90);
          pcVar2 = *(code **)(*plVar1 + 0x288);
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100565;
          plStack_50 = (longlong *)
                       (*pcVar2)(plVar1,*(undefined2 *)(&stack0xfffffffffffffff8 + lVar9));
          *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100574;
          iVar4 = func_0x(plStack_50);
          if (iVar4 == 0) {
            pcVar2 = *(code **)(*plStack_50 + 0x270);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100588;
            (*pcVar2)();
          }
          lVar17 = -1;
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_3248[lVar12] != 0);
          uVar6 = (int)lVar12 * 2;
          *(uint *)(&stack0xfffffffffffffff8 + lVar9) = uVar6;
          iVar4 = 1;
          uVar14 = 0;
          uVar15 = uStack_212c & 0xffffffff;
          do {
            uVar10 = (uint)uVar14;
            if (3 < uVar10) break;
            uVar7 = 0x400 - (int)uVar15;
            uVar13 = 4 - uVar10;
            if (uVar7 <= 4 - uVar10) {
              uVar13 = uVar7;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1005ff;
            func_0x
                      (auStack_252c + uVar15,&stack0xfffffffffffffff8 + uVar14 + lVar9,uVar13);
            uVar14 = (ulonglong)(uVar10 + uVar13);
            uVar7 = (uint)uStack_212c + uVar13;
            uStack_212c = CONCAT44(uStack_212c._4_4_,uVar7);
            if (uVar10 + uVar13 != 4) {
              if (iStack_58 == 0) {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100646;
                (*_DAT_)(1,0x1c27908,0x1c01ee0,0x18c);
              }
              pcVar2 = *(code **)(lStack_2558 + 0x78);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100659;
              iVar4 = (*pcVar2)(&lStack_2558,0);
              uVar7 = (uint)uStack_212c;
            }
            uVar15 = (ulonglong)uVar7;
          } while (iVar4 != 0);
          iVar4 = 1;
          if (uVar6 != 0) {
            uVar14 = 0;
            do {
              uVar10 = (uint)uVar14;
              if (uVar6 <= uVar10) break;
              uVar7 = 0x400 - (int)uVar15;
              uVar13 = uVar6 - uVar10;
              if (uVar7 <= uVar6 - uVar10) {
                uVar13 = uVar7;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1006bc;
              func_0x(auStack_252c + uVar15,(longlong)asStack_3248 + uVar14,uVar13);
              uVar14 = (ulonglong)(uVar10 + uVar13);
              uVar7 = (uint)uStack_212c + uVar13;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar7);
              if (uVar6 != uVar10 + uVar13) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100700;
                  (*_DAT_)(1,0x1c27908,0x1c01ee0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100713;
                iVar4 = (*pcVar2)(&lStack_2558,0);
                uVar7 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar7;
            } while (iVar4 != 0);
          }
          lVar12 = -1;
          do {
            lVar12 = lVar12 + 1;
          } while (asStack_2fc8[lVar12] != 0);
          uVar10 = (int)lVar12 * 2;
          *(uint *)(&stack0xfffffffffffffff8 + lVar9) = uVar10;
          iVar4 = 1;
          uVar14 = 0;
          do {
            uVar13 = (uint)uVar14;
            if (3 < uVar13) break;
            uVar8 = 0x400 - (int)uVar15;
            uVar7 = 4 - uVar13;
            if (uVar8 <= 4 - uVar13) {
              uVar7 = uVar8;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100791;
            func_0x
                      (auStack_252c + uVar15,&stack0xfffffffffffffff8 + uVar14 + lVar9,uVar7);
            uVar14 = (ulonglong)(uVar13 + uVar7);
            uVar8 = (uint)uStack_212c + uVar7;
            uStack_212c = CONCAT44(uStack_212c._4_4_,uVar8);
            if (uVar13 + uVar7 != 4) {
              if (iStack_58 == 0) {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1007da;
                (*_DAT_)(1,0x1c27908,0x1c01ee0,0x18c);
              }
              pcVar2 = *(code **)(lStack_2558 + 0x78);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1007ed;
              iVar4 = (*pcVar2)(&lStack_2558,0);
              uVar8 = (uint)uStack_212c;
            }
            uVar15 = (ulonglong)uVar8;
          } while (iVar4 != 0);
          iVar4 = 1;
          if (uVar10 != 0) {
            uVar14 = 0;
            do {
              uVar13 = (uint)uVar14;
              if (uVar10 <= uVar13) break;
              uVar8 = 0x400 - (int)uVar15;
              uVar7 = uVar10 - uVar13;
              if (uVar8 <= uVar10 - uVar13) {
                uVar7 = uVar8;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100850;
              func_0x(auStack_252c + uVar15,(longlong)asStack_2fc8 + uVar14,uVar7);
              uVar14 = (ulonglong)(uVar13 + uVar7);
              uVar8 = (uint)uStack_212c + uVar7;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar8);
              if (uVar10 != uVar13 + uVar7) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100896;
                  (*_DAT_)(1,0x1c27908,0x1c01ee0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1008a9;
                iVar4 = (*pcVar2)(&lStack_2558,0);
                uVar8 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar8;
            } while (iVar4 != 0);
          }
          do {
            lVar17 = lVar17 + 1;
          } while (asStack_2db8[lVar17] != 0);
          uVar13 = (int)lVar17 * 2;
          *(uint *)(&stack0xfffffffffffffff8 + lVar9) = uVar13;
          iVar4 = 1;
          uVar14 = 0;
          do {
            uVar7 = (uint)uVar14;
            if (3 < uVar7) break;
            uVar11 = 0x400 - (int)uVar15;
            uVar8 = 4 - uVar7;
            if (uVar11 <= 4 - uVar7) {
              uVar8 = uVar11;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x10091f;
            func_0x
                      (auStack_252c + uVar15,&stack0xfffffffffffffff8 + uVar14 + lVar9,uVar8);
            uVar14 = (ulonglong)(uVar7 + uVar8);
            uVar11 = (uint)uStack_212c + uVar8;
            uStack_212c = CONCAT44(uStack_212c._4_4_,uVar11);
            if (uVar7 + uVar8 != 4) {
              if (iStack_58 == 0) {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100966;
                (*_DAT_)(1,0x1c27908,0x1c01ee0,0x18c);
              }
              pcVar2 = *(code **)(lStack_2558 + 0x78);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100979;
              iVar4 = (*pcVar2)(&lStack_2558,0);
              uVar11 = (uint)uStack_212c;
            }
            uVar15 = (ulonglong)uVar11;
          } while (iVar4 != 0);
          iVar4 = 1;
          if (uVar13 != 0) {
            uVar14 = 0;
            do {
              uVar7 = (uint)uVar14;
              if (uVar13 <= uVar7) break;
              uVar11 = 0x400 - (int)uVar15;
              uVar8 = uVar13 - uVar7;
              if (uVar11 <= uVar13 - uVar7) {
                uVar8 = uVar11;
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x1009de;
              func_0x(auStack_252c + uVar15,(longlong)asStack_2db8 + uVar14,uVar8);
              uVar14 = (ulonglong)(uVar7 + uVar8);
              uVar11 = (uint)uStack_212c + uVar8;
              uStack_212c = CONCAT44(uStack_212c._4_4_,uVar11);
              if (uVar13 != uVar7 + uVar8) {
                if (iStack_58 == 0) {
                  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a23;
                  (*_DAT_)(1,0x1c27908,0x1c01ee0,0x18c);
                }
                pcVar2 = *(code **)(lStack_2558 + 0x78);
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a36;
                iVar4 = (*pcVar2)(&lStack_2558,0);
                uVar11 = (uint)uStack_212c;
              }
              uVar15 = (ulonglong)uVar11;
            } while (iVar4 != 0);
          }
          iVar4 = 1;
          uVar14 = 0;
          do {
            uVar7 = (uint)uVar14;
            if (3 < uVar7) break;
            uVar11 = 0x400 - (int)uVar15;
            uVar8 = 4 - uVar7;
            if (uVar11 <= 4 - uVar7) {
              uVar8 = uVar11;
            }
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100a93;
            func_0x(auStack_252c + uVar15,&stack0x0000003c + uVar14 + lVar9,uVar8);
            uVar14 = (ulonglong)(uVar7 + uVar8);
            uVar11 = (uint)uStack_212c + uVar8;
            uStack_212c = CONCAT44(uStack_212c._4_4_,uVar11);
            if (uVar7 + uVar8 != 4) {
              if (iStack_58 == 0) {
                *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = 0;
                *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100ada;
                (*_DAT_)(1,0x1c27908,0x1c01ee0,0x18c);
              }
              pcVar2 = *(code **)(lStack_2558 + 0x78);
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100aed;
              iVar4 = (*pcVar2)(&lStack_2558,0);
              uVar11 = (uint)uStack_212c;
            }
            uVar15 = (ulonglong)uVar11;
          } while (iVar4 != 0);
          uVar13 = uVar6 + uVar10 + 0x10 + uVar13;
          if (*(uint *)(&stack0x0000003c + lVar9) != 0) {
            lVar12 = *(longlong *)(&stack0x00000040 + lVar9);
            uVar14 = (ulonglong)*(uint *)(&stack0x0000003c + lVar9);
            do {
              if (0x400 < (ulonglong)uVar13 + 4) {
                uVar13 = 0;
                if (plStack_50 == (longlong *)0x0) {
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b52;
                  func_0x(0x4956,0x10,2,0x1a72ee8);
                }
                else {
                  pcVar2 = *(code **)(lStack_2558 + 0x78);
                  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b6a;
                  (*pcVar2)(&lStack_2558,1);
                }
              }
              *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100b82;
              func_0x(&lStack_2558,lVar12,4);
              uVar13 = uVar13 + 4;
              lVar12 = lVar12 + 4;
              uVar14 = uVar14 - 1;
            } while (uVar14 != 0);
          }
          if (plStack_50 == (longlong *)0x0) {
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100bb3;
            func_0x(0x4956,0x10,2,0x1a72ee8);
          }
          else {
            pcVar2 = *(code **)(lStack_2558 + 0x78);
            *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100bcb;
            (*pcVar2)(&lStack_2558,1);
          }
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100be5;
        func_0x(&lStack_25d8);
      }
      goto LAB_;
    }
    uVar16 = 0x1949630;
  }
  *(undefined8 *)(&stack0xffffffffffffffe8 + lVar9) = uVar16;
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100166;
  func_0x(0x493e,0x10,2,0x1a76260);
LAB_:
  lStack_2558 = 0x1a700b8;
  if ((iStack_70 != 0) && (lStack_78 != 0)) {
    pcVar2 = *(code **)(*_DAT_ + 0x28);
    *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c16;
    (*pcVar2)();
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar9) = 0x100c25;
  func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar9));
  return;
}

