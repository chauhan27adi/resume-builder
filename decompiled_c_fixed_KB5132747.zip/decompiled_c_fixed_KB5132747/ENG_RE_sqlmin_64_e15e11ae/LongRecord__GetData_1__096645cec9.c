
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 *param_1,longlong *param_2,longlong param_3,undefined4 *param_4)

{
  char *pcVar1;
  undefined4 *puVar2;
  ushort *puVar3;
  undefined8 *puVar4;
  code *pcVar5;
  undefined8 uVar6;
  ushort *puVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  byte bVar10;
  char cVar11;
  ushort uVar12;
  ushort uVar13;
  undefined4 uVar14;
  int iVar15;
  uint uVar16;
  longlong lVar17;
  undefined8 uVar18;
  uint *puVar19;
  byte bVar20;
  uint uVar21;
  ulonglong uVar22;
  uint *puVar23;
  ulonglong uVar24;
  short sVar25;
  byte *pbVar26;
  longlong lVar27;
  uint uVar28;
  undefined *puVar29;
  undefined *puVar30;
  short *psVar31;
  short *psVar32;
  longlong lVar33;
  undefined *puVar34;
  undefined4 *puVar35;
  ulonglong uVar36;
  longlong *plVar37;
  uint *puVar38;
  longlong lVar39;
  uint *puVar40;
  int iVar41;
  uint uVar42;
  ulonglong uVar43;
  ushort *puVar44;
  longlong unaff_GS_OFFSET;
  undefined4 extraout_XMM0_Da;
  char acStackX_20 [4];
  uint uStackX_24;
  undefined8 uStack_48;
  
  uStack_48 = 0x100017;
  lVar17 = func_0x();
  lVar17 = -lVar17;
  puVar30 = &stack0xffffffffffffffc0 + lVar17;
  pcVar1 = acStackX_20 + lVar17;
  *(undefined8 *)(&stack0x000000f0 + lVar17) = 0xfffffffffffffffe;
  *(ulonglong *)(&stack0x000020e0 + lVar17) = _DAT_ ^ (ulonglong)pcVar1;
  *(undefined4 **)(&stack0x000000e0 + lVar17) = param_4;
  *(longlong *)(&stack0x00000048 + lVar17) = param_3;
  *(longlong **)(&stack0x00000040 + lVar17) = param_2;
  *(undefined8 **)(&stack0x00000090 + lVar17) = param_1;
  *(undefined8 *)(&stack0x000000a8 + lVar17) = *(undefined8 *)(&stack0x00002160 + lVar17);
  uVar24 = 0;
  *(undefined4 *)(&stack0x00000088 + lVar17) = 0;
  *(undefined4 *)(&stack0x0000006c + lVar17) = 0;
  *(undefined4 *)(&stack0x00000070 + lVar17) = 0;
  *(undefined8 *)(&stack0x00000100 + lVar17) = 0;
  *(undefined8 *)(&stack0x00000108 + lVar17) = 0;
  *(undefined4 *)(&stack0x00000110 + lVar17) = 0;
  *(undefined8 *)(&stack0x00000118 + lVar17) = 0;
  *(undefined4 *)(&stack0x00000120 + lVar17) = 0;
  *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x1000ae;
  func_0x(&stack0x00000124 + lVar17,0,0x1f9e);
  *(undefined8 *)(&stack0x00000058 + lVar17) = 0;
  *(undefined8 *)(&stack0x00000060 + lVar17) = 0;
  lVar39 = param_2[1];
  *(longlong *)(&stack0x000000e8 + lVar17) = lVar39;
  *(undefined4 *)(&stack0x00000034 + lVar17) = *(undefined4 *)(*(longlong *)(lVar39 + 0x80) + 0x14);
  *(undefined4 *)(&stack0x00000068 + lVar17) = 0;
  *(undefined8 *)(&stack0x000000b0 + lVar17) = 0;
  cVar11 = '\0';
  *pcVar1 = '\0';
  (&stack0x00000030)[lVar17] = 0;
  *param_4 = 0;
  lVar27 = *(longlong *)(param_1[3] + 8);
  if (*(int *)(lVar27 + 0x100) == 2) {
    if ((*(byte *)(lVar27 + 0x42) & 4) == 0) {
      uVar36 = (ulonglong)*(uint *)(lVar27 + 0xb0);
      if (0x1f9e < *(uint *)(lVar27 + 0xb0)) {
        uVar36 = 0x1f9e;
      }
    }
    else {
      uVar36 = 0x1f9e;
    }
    *(int *)(&stack0x00000068 + lVar17) = (int)uVar36;
    uVar22 = uVar36 + 0xf;
    if (uVar22 <= uVar36) {
      uVar22 = 0xffffffffffffff0;
    }
    uVar22 = uVar22 & 0xfffffffffffffff0;
    *(undefined8 *)((longlong)&uStack_48 + lVar17) = 0x100143;
    func_0x();
    puVar30 = &stack0xffffffffffffffc0 + -uVar22 + lVar17;
    *(char **)(&stack0x000000b0 + lVar17) = acStackX_20 + -uVar22 + lVar17;
  }
  lVar27 = param_1[1];
  puVar4 = *(undefined8 **)(lVar27 + 0x10);
  if (puVar4 != (undefined8 *)0x0) {
    pcVar5 = *(code **)*puVar4;
    *(undefined8 *)(puVar30 + -8) = 0x100167;
    uVar18 = (*pcVar5)(puVar4);
    *(undefined8 *)(param_1[1] + 8) = uVar18;
    lVar27 = param_1[1];
  }
  psVar32 = *(short **)(lVar27 + 8);
  *(short **)(&stack0x00000028 + lVar17) = psVar32;
  *(undefined4 *)(&stack0x0000003c + lVar17) = 0;
  puVar38 = *(uint **)(*(longlong *)(lVar39 + 0x80) + 0x18);
  *(uint **)(&stack0x00000050 + lVar17) = puVar38;
  uVar28 = *(uint *)(&stack0x00000034 + lVar17);
  if (uVar28 != 0) {
    *(undefined8 *)(&stack0x00000078 + lVar17) = 0;
    lVar39 = -0x1cf6dd0;
    puVar29 = puVar30;
    uVar36 = uVar24;
LAB_:
    uVar14 = (undefined4)uVar24;
    puVar19 = (uint *)0x0;
    puVar40 = (uint *)0x0;
    puVar30 = puVar29;
    if (0x19 < *(byte *)(puVar38 + 0x10)) {
LAB_:
      *(undefined8 *)(puVar29 + 0x20) = 0x823760;
      *(undefined8 *)(puVar29 + -8) = 0x102aed;
      (*_DAT_)(1,0xc29af0,0xc2fdf0,0x203);
      puVar40 = puVar19;
      goto code_r0x00100b07;
    }
    uVar12 = 0;
    switch((ulonglong)*(uint *)(lVar39 + 0x1df9b6c + (longlong)(char)*(byte *)(puVar38 + 0x10) * 4)
           + lVar39) {
    case 0x1001ce:
      iVar15 = puVar38[0x10] << 0xc;
      uVar28 = (uint)*(ushort *)(puVar38 + 0xf);
      if (*psVar32 != 0) {
        *(undefined4 *)(&stack0x00000080 + lVar17) = 0;
        *(undefined **)(puVar29 + 0x20) = &stack0x00000080 + lVar17;
        *(undefined8 *)(puVar29 + -8) = 0x100bc2;
        puVar40 = (uint *)func_0x(psVar32 + 1,puVar38);
        if ((((*psVar32 != 0) && (plVar37 = *(longlong **)(psVar32 + 8), plVar37 != (longlong *)0x0)
             ) && (*plVar37 != 0)) &&
           (((*(byte *)((longlong)puVar38 + 6) & 8) == 0 &&
            ((*(uint *)(&stack0x00000080 + lVar17) & 1) == 0)))) {
          if ((puVar40 == (uint *)0x0) || (puVar40 == (uint *)0x82ce90)) {
            *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 0;
            puVar40 = (uint *)0x0;
          }
          else {
            *(uint *)(puVar29 + 0x38) = *(uint *)(&stack0x00000080 + lVar17);
            *(longlong *)(puVar29 + 0x30) = (longlong)&uStackX_24 + lVar17;
            *(undefined4 *)(puVar29 + 0x28) = 0;
            *(undefined8 *)(puVar29 + 0x20) = 0;
            uVar14 = *(undefined4 *)((longlong)&uStackX_24 + lVar17);
            *(undefined8 *)(puVar29 + -8) = 0x100c33;
            puVar40 = (uint *)func_0x(plVar37,puVar38,puVar40,uVar14);
          }
        }
        break;
      }
      puVar3 = (ushort *)(psVar32 + 1);
      uVar16 = *puVar38;
      if ((uVar16 & 0xc0000000) == 0x80000000) {
        *(undefined8 *)(puVar29 + -8) = 0x100b79;
        iVar15 = func_0x(puVar3);
        if (iVar15 == 0) {
          *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 0;
          puVar40 = puVar19;
        }
        else {
          *(undefined8 *)(puVar29 + -8) = 0x100b94;
          puVar40 = (uint *)func_0x(psVar32 + 0x15,puVar38,(longlong)&uStackX_24 + lVar17,
                                            &stack0x000000b8 + lVar17);
        }
        goto code_r0x00100afd;
      }
      if ((iVar15 < 0) || ((*(byte *)((longlong)puVar38 + 6) & 0x10) != 0)) {
        pbVar26 = *(byte **)(psVar32 + 4);
        if ((*pbVar26 & 0x10) == 0) {
          if ((1 << (*pbVar26 & 0xe) & 0x1105U) != 0) goto code_r0x00100251;
          puVar40 = puVar19;
          puVar23 = (uint *)0x1;
code_r0x00100261:
          iVar41 = (int)puVar23;
          uVar42 = (uint)puVar40;
          if (iVar15 < 0) goto code_r0x0010028c;
code_r0x00100294:
          if ((iVar41 != 0) || ((*(byte *)((longlong)puVar38 + 6) & 0x10) == 0))
          goto code_r0x001002ae;
          puVar19 = *(uint **)(puVar38 + 2) + 1;
          uVar16 = **(uint **)(puVar38 + 2);
          goto code_r0x00100afa;
        }
        uVar42 = *(uint *)(psVar32 + 8);
        if ((int)uVar42 <= (int)uVar16) {
code_r0x00100251:
          puVar40 = (uint *)(ulonglong)(~(uint)(*(ushort *)((longlong)puVar38 + 6) >> 4) & 1);
          puVar23 = puVar19;
          goto code_r0x00100261;
        }
        if ((uint)*(ushort *)(pbVar26 + uVar42) < (uint)*(ushort *)(puVar38 + 1))
        goto code_r0x00100251;
        if (-1 < iVar15) goto code_r0x001002ae;
        uVar21 = *(ushort *)(puVar38 + 1) - 1;
        uVar42 = pbVar26[(ulonglong)(uVar21 >> 3) + (ulonglong)uVar42 + 2] >> ((byte)uVar21 & 7) & 1
        ;
        iVar41 = 1;
code_r0x0010028c:
        if (uVar42 == 0) goto code_r0x00100294;
        goto code_r0x00100af7;
      }
code_r0x001002ae:
      if ((int)uVar16 < 0) {
        if (*(int *)(psVar32 + 2) == 0) {
          *puVar3 = 0;
          uVar28 = *(uint *)(psVar32 + 8);
          uVar24 = (ulonglong)uVar28;
          *(uint *)(psVar32 + 10) = uVar28;
          pbVar26 = *(byte **)(psVar32 + 4);
          bVar10 = *pbVar26;
          if ((bVar10 & 0x10) != 0) {
            uVar28 = uVar28 + 2 + (*(ushort *)(pbVar26 + uVar24) + 7 >> 3);
            uVar24 = (ulonglong)uVar28;
            *(uint *)(psVar32 + 10) = uVar28;
            bVar10 = *pbVar26;
          }
          psVar31 = psVar32;
          if ((bVar10 & 0x20) == 0) {
            *(int *)(psVar32 + 2) = (int)uVar24;
            psVar32[0xe] = 0;
            *(int *)(psVar32 + 0xc) = (int)uVar24;
          }
          else {
            puVar44 = (ushort *)(pbVar26 + uVar24);
            uVar12 = *puVar44;
            psVar32[0xe] = uVar12;
            if (uVar12 == 0) {
              *(undefined8 *)(puVar29 + -8) = 0x1003e6;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x1003ef;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x100409;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x100425;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x10044b;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x80f);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x100459;
              func_0x(uVar18,3);
              uVar24 = (ulonglong)*(uint *)(psVar32 + 10);
              uVar12 = psVar32[0xe];
            }
            uVar28 = (int)uVar24 + (uint)uVar12 * 2 + 2;
            *(uint *)(psVar32 + 0xc) = uVar28;
            if (0x1f9e < uVar28) {
              *(undefined8 *)(puVar29 + -8) = 0x10048a;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x100493;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x1004ad;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x1004c9;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x1004ef;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x816);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x1004fd;
              func_0x(uVar18,4);
              uVar12 = psVar32[0xe];
              uVar28 = *(uint *)(psVar32 + 0xc);
            }
            uVar24 = (ulonglong)uVar12;
            uVar12 = puVar44[uVar24];
            *(uint *)(psVar32 + 2) = uVar12 & 0x7fff;
            if ((uVar12 & 0x7fff) < uVar28) {
              *(undefined8 *)(puVar29 + -8) = 0x10052b;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x100534;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x10054e;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x10056a;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x100590;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x81d);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x10059e;
              func_0x(uVar18,4);
              uVar28 = *(uint *)(psVar32 + 0xc);
              uVar24 = (ulonglong)(ushort)psVar32[0xe];
            }
            puVar38 = puVar19;
            puVar7 = puVar44;
            if ((short)uVar24 != 0) {
              do {
                uVar16 = puVar7[1] & 0x7fff;
                if ((uVar16 < uVar28) || (*(uint *)(psVar32 + 2) < uVar16)) {
                  *(undefined8 *)(puVar29 + -8) = 0x1005df;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x1005e8;
                    lVar39 = func_0x();
                    if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar29 + -8) = 0x100602;
                      cVar11 = func_0x(0x11b87f0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x10061e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar29 + 0x20) = 0;
                        *(undefined8 *)(puVar29 + -8) = 0x100644;
                        (*_DAT_)(1,0xaa81fc,0xbc82e8,0x82a);
                      }
                    }
                  }
                  uVar18 = *(undefined8 *)(psVar32 + 4);
                  *(undefined8 *)(puVar29 + -8) = 0x100652;
                  func_0x(uVar18,4);
                }
                uVar42 = (int)puVar38 + 1;
                uVar24 = (ulonglong)(ushort)psVar32[0xe];
                puVar38 = (uint *)(ulonglong)uVar42;
                puVar7 = puVar7 + 1;
                uVar28 = uVar16;
              } while ((int)uVar42 < (int)(uint)(ushort)psVar32[0xe]);
              psVar31 = *(short **)(&stack0x00000028 + lVar17);
            }
            if ((short)puVar44[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
              lVar39 = *(longlong *)(psVar32 + 4);
code_r0x00100690:
              lVar27 = (ulonglong)*(uint *)(psVar32 + 10) + lVar39;
              if ((int)uVar24 == 1) {
                uVar28 = *(uint *)(psVar32 + 0xc);
                uVar42 = *(ushort *)(lVar27 + uVar24 * 2) & 0x7fff;
                uVar16 = uVar28;
code_r0x001006cb:
                if ((uVar42 < uVar28) || (*(uint *)(psVar32 + 2) < uVar42)) goto code_r0x001006d4;
                lVar39 = *(longlong *)(&stack0x00000028 + lVar17);
              }
              else {
                uVar28 = *(ushort *)(lVar27 + -2 + uVar24 * 2) & 0x7fff;
                uVar16 = *(uint *)(psVar31 + 0xc);
                uVar42 = *(ushort *)(lVar27 + uVar24 * 2) & 0x7fff;
                if (uVar16 <= uVar28) goto code_r0x001006cb;
code_r0x001006d4:
                *(undefined8 *)(puVar29 + -8) = 0x1006e1;
                func_0x(lVar39,7);
                lVar39 = *(longlong *)(&stack0x00000028 + lVar17);
                uVar16 = *(uint *)(lVar39 + 0x18);
              }
              if ((uVar28 < uVar16) || (*(uint *)(psVar32 + 2) < uVar28)) {
                puVar38 = *(uint **)(&stack0x00000050 + lVar17);
                goto code_r0x00100a36;
              }
              lVar39 = *(longlong *)(psVar32 + 4);
              if (*(ushort *)((ulonglong)uVar28 + lVar39) != 5) {
                if (*(ushort *)((ulonglong)uVar28 + lVar39) < 0x400) goto code_r0x001008a2;
                *puVar3 = *puVar3 | 1;
                uVar12 = psVar32[0xe] - 1;
                psVar32[0xe] = uVar12;
                psVar31 = *(short **)(&stack0x00000028 + lVar17);
                if (uVar12 == 0) goto code_r0x001008a6;
                uVar24 = (ulonglong)uVar12;
                if (-1 < (short)puVar44[(ulonglong)(uVar12 - 1) + 1]) goto code_r0x00100750;
                goto code_r0x00100690;
              }
              *puVar3 = *puVar3 | 2;
              psVar32[0xe] = psVar32[0xe] + -1;
              uVar24 = (ulonglong)(uVar28 & 0xffff);
              psVar32[0x15] = (short)uVar28;
              uVar12 = psVar32[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar24 + 2 + lVar39) >> 0xe & 1) != 0) {
                uVar12 = *(ushort *)(uVar24 + 2 + lVar39) & 0x3800 | psVar32[0x16] & 0xc7ffU;
              }
              psVar32[0x16] = uVar12;
              uVar13 = (uVar12 ^ *(ushort *)(uVar24 + 2 + lVar39)) & 0x7ff ^ uVar12;
              psVar32[0x16] = uVar13;
              uVar36 = *(ulonglong *)(psVar32 + 4);
              uVar22 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 + uVar36 + (uVar12 >> 0xb & 7) * 2 +
                       uVar24;
              if (uVar22 < uVar24 + uVar36) {
                *(undefined8 *)(puVar29 + -8) = 0x1007fb;
                func_0x(uVar24 + uVar36,0x19);
                uVar13 = psVar32[0x16];
                uVar24 = (ulonglong)(ushort)psVar32[0x15];
                uVar36 = (ulonglong)*(uint *)(psVar32 + 4);
              }
              if (uVar42 - uVar28 <
                  (((uVar13 & 0x7ff) * 2 - (int)uVar24) - (int)uVar36) + (int)uVar22) {
                lVar39 = *(longlong *)(psVar32 + 4);
                *(undefined8 *)(puVar29 + -8) = 0x100833;
                func_0x(uVar24 + lVar39,0x19);
                uVar13 = psVar32[0x16];
              }
              if (((uVar13 & 0x3800) != 0) &&
                 (puVar44 = (ushort *)
                            (*(longlong *)(psVar32 + 4) + 4 + (ulonglong)(ushort)psVar32[0x15]),
                 (uVar13 & 0x3800) != 0)) {
                do {
                  if ((uVar13 & 0x7ff) < (*puVar44 & 0x7ff)) {
                    uVar12 = psVar32[0x15];
                    lVar39 = *(longlong *)(psVar32 + 4);
                    *(undefined8 *)(puVar29 + -8) = 0x100887;
                    func_0x((ulonglong)uVar12 + lVar39,0x1a);
                    uVar13 = psVar32[0x16];
                  }
                  uVar28 = (int)puVar19 + 1;
                  puVar19 = (uint *)(ulonglong)uVar28;
                  puVar44 = puVar44 + 1;
                } while ((int)uVar28 < (int)(uVar13 >> 0xb & 7));
              }
code_r0x001008a2:
              psVar31 = *(short **)(&stack0x00000028 + lVar17);
            }
code_r0x001008a6:
            uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
            puVar38 = *(uint **)(&stack0x00000050 + lVar17);
          }
          goto code_r0x001008bd;
        }
        goto code_r0x00100a2c;
      }
      uVar12 = *(ushort *)((longlong)puVar38 + 6);
      if ((uVar12 & 8) != 0) {
        puVar19 = (uint *)0x82ce90;
        if ((*(byte *)((longlong)(int)uVar16 + *(longlong *)(psVar32 + 4)) &
            (byte)(1 << ((byte)uVar12 & 7))) == 0) {
          puVar19 = (uint *)0x82ce91;
        }
        uVar16 = 1;
        goto code_r0x00100afa;
      }
      if ((uVar12 & 0x10) != 0) {
        bVar10 = **(byte **)(psVar32 + 4);
        if ((bVar10 & 0x10) == 0) {
          if ((1 << (bVar10 & 0xe) & 0x1105U) != 0) {
code_r0x00100309:
            puVar19 = *(uint **)(puVar38 + 2) + 1;
            uVar16 = **(uint **)(puVar38 + 2);
            if ((uVar28 != 0) && (uVar16 != uVar28)) {
              *(undefined8 *)(puVar29 + 0x20) = 0;
              *(undefined8 *)(puVar29 + -8) = 0x100349;
              (*_DAT_)(1,0xc56640,0xc54fa8,0x381);
            }
            goto code_r0x00100afa;
          }
        }
        else if (((int)*(uint *)(psVar32 + 8) <= (int)uVar16) ||
                (*(ushort *)(*(byte **)(psVar32 + 4) + *(uint *)(psVar32 + 8)) <
                 *(ushort *)(puVar38 + 1))) goto code_r0x00100309;
      }
      puVar19 = (uint *)((longlong)(int)uVar16 + *(longlong *)(psVar32 + 4));
      uVar16 = uVar28;
      goto code_r0x00100afa;
    case 0x100c47:
      if ((puVar38[0x10] & 0x80000) != 0) {
        if (*psVar32 == 0) {
          pbVar26 = *(byte **)(psVar32 + 4);
          if ((*pbVar26 & 0x10) == 0) {
            if ((1 << (*pbVar26 & 0xe) & 0x1105U) != 0) {
code_r0x00100caa:
              uVar12 = ~(*(ushort *)((longlong)puVar38 + 6) >> 4) & 1;
            }
          }
          else {
            uVar28 = *(uint *)(psVar32 + 8);
            if ((int)*puVar38 < (int)uVar28) {
              if ((uint)*(ushort *)(pbVar26 + uVar28) < (uint)*(ushort *)(puVar38 + 1))
              goto code_r0x00100caa;
              uVar16 = *(ushort *)(puVar38 + 1) - 1;
              uVar12 = pbVar26[(ulonglong)uVar28 + (ulonglong)(uVar16 >> 3) + 2] >>
                       ((byte)uVar16 & 7) & 1;
            }
            else {
              uVar12 = ~(*(ushort *)((longlong)puVar38 + 6) >> 4) & 1;
            }
          }
        }
        else {
          uVar12 = *(ushort *)(puVar38 + 1);
          if ((ushort)psVar32[1] < uVar12) {
            uVar12 = ~(*(ushort *)((longlong)puVar38 + 6) >> 4) & 1;
          }
          else {
            bVar10 = *(byte *)((longlong)((int)(uVar12 - 1) / 2) + (ulonglong)(ushort)psVar32[0xc] +
                              *(longlong *)(psVar32 + 4));
            bVar20 = bVar10 >> 4;
            if ((uVar12 & 1) != 0) {
              bVar20 = bVar10 & 0xf;
            }
            uVar12 = (ushort)(bVar20 == 0);
          }
        }
        if (uVar12 != 0) {
          *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 0;
          break;
        }
      }
    case 0x100d37:
      uVar12 = *(ushort *)(puVar38 + 0xf);
      if ((*(byte *)((longlong)puVar38 + 6) & 0x10) == 0) {
code_r0x00100d61:
        puVar40 = (uint *)((longlong)(int)*puVar38 + *(longlong *)(psVar32 + 4));
        uVar28 = (uint)uVar12;
code_r0x00100d6a:
        *(uint *)((longlong)&uStackX_24 + lVar17) = uVar28;
      }
      else {
        bVar10 = **(byte **)(psVar32 + 4);
        if ((bVar10 & 0x10) == 0) {
          if ((1 << (bVar10 & 0xe) & 0x1105U) == 0) goto code_r0x00100d61;
        }
        else if (((int)*puVar38 < (int)*(uint *)(psVar32 + 8)) &&
                (*(ushort *)(puVar38 + 1) <=
                 *(ushort *)(*(byte **)(psVar32 + 4) + *(uint *)(psVar32 + 8))))
        goto code_r0x00100d61;
        puVar40 = *(uint **)(puVar38 + 2) + 1;
        uVar28 = **(uint **)(puVar38 + 2);
        if ((uVar12 == 0) || (uVar28 == uVar12)) goto code_r0x00100d6a;
        *(undefined8 *)(puVar29 + 0x20) = 0;
        *(undefined8 *)(puVar29 + -8) = 0x100dbe;
        (*_DAT_)(1,0xc56640,0xc54fa8,0x381);
        *(uint *)((longlong)&uStackX_24 + lVar17) = uVar28;
      }
      goto code_r0x00100afd;
    case 0x100dc6:
      if ((puVar38[0x10] & 0x80000) != 0) {
        if (*psVar32 == 0) {
          pbVar26 = *(byte **)(psVar32 + 4);
          if ((*pbVar26 & 0x10) == 0) {
            if ((1 << (*pbVar26 & 0xe) & 0x1105U) != 0) {
code_r0x00100e29:
              uVar12 = ~(*(ushort *)((longlong)puVar38 + 6) >> 4) & 1;
            }
          }
          else {
            uVar16 = *(uint *)(psVar32 + 8);
            if ((int)*puVar38 < (int)uVar16) {
              if ((uint)*(ushort *)(pbVar26 + uVar16) < (uint)*(ushort *)(puVar38 + 1))
              goto code_r0x00100e29;
              uVar42 = *(ushort *)(puVar38 + 1) - 1;
              uVar12 = pbVar26[(ulonglong)uVar16 + (ulonglong)(uVar42 >> 3) + 2] >>
                       ((byte)uVar42 & 7) & 1;
            }
            else {
              uVar12 = ~(*(ushort *)((longlong)puVar38 + 6) >> 4) & 1;
            }
          }
        }
        else {
          uVar12 = *(ushort *)(puVar38 + 1);
          if ((ushort)psVar32[1] < uVar12) {
            uVar12 = ~(*(ushort *)((longlong)puVar38 + 6) >> 4) & 1;
          }
          else {
            bVar10 = *(byte *)((longlong)((int)(uVar12 - 1) / 2) + (ulonglong)(ushort)psVar32[0xc] +
                              *(longlong *)(psVar32 + 4));
            bVar20 = bVar10 >> 4;
            if ((uVar12 & 1) != 0) {
              bVar20 = bVar10 & 0xf;
            }
            uVar12 = (ushort)(bVar20 == 0);
          }
        }
        if (uVar12 != 0) {
          *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 0;
          lVar39 = *(longlong *)(puVar38 + 0x12);
          if (((*(int *)(lVar39 + 0x10) != 10) && ((*(byte *)(lVar39 + 0xc) & 0x40) != 0)) &&
             (plVar37 = *(longlong **)(&stack0x00002168 + lVar17), plVar37 != (longlong *)0x0)) {
            uVar16 = *(uint *)(lVar39 + 8);
            do {
              uVar42 = *(uint *)(plVar37 + 1);
              if ((ulonglong)uVar16 < (ulonglong)uVar42 + 0x100) {
                if ((uVar42 <= uVar16) &&
                   ((*(uint *)((longlong)plVar37 + (ulonglong)(uVar16 - uVar42 >> 5) * 4 + 0xc) &
                    1 << ((byte)(uVar16 - uVar42) & 0x1f)) != 0)) {
                  puVar35 = (undefined4 *)(uVar36 * 0x50 + param_2[2]);
                  iVar15 = *(int *)(*(longlong *)(puVar35 + 0x12) + 0x10);
                  if (((*(byte *)(*(longlong *)(puVar35 + 0x12) + 0xc) & 0x40) != 0) &&
                     (0x10 < *(ushort *)(puVar35 + 0xf))) {
                    if (iVar15 == 3) {
                      uVar18 = param_1[3];
                      *(undefined8 *)(puVar29 + -8) = 0x102d77;
                      func_0x(uVar18);
                      *(undefined8 *)(puVar29 + -8) = 0x102d7c;
                      func_0x();
                      pcVar5 = (code *)swi(3);
                      (*pcVar5)();
                      return;
                    }
                    if (iVar15 == 6) goto code_r0x00102d7d;
                  }
                  if (iVar15 == 7) {
code_r0x00102d7d:
                    *(undefined8 *)(puVar29 + -8) = 0x102d82;
                    func_0x();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                  }
                  if (iVar15 == 2) {
                    lVar39 = (ulonglong)*(uint *)(param_3 + 4) * 0x40;
                    uVar14 = puVar35[1];
                    uVar8 = puVar35[2];
                    uVar9 = puVar35[3];
                    puVar2 = (undefined4 *)(lVar39 + 8 + *(longlong *)(param_3 + 8));
                    *puVar2 = *puVar35;
                    puVar2[1] = uVar14;
                    puVar2[2] = uVar8;
                    puVar2[3] = uVar9;
                    *(undefined4 *)(lVar39 + *(longlong *)(param_3 + 8)) =
                         *(undefined4 *)(&stack0x0000003c + lVar17);
                    pbVar26 = (byte *)(lVar39 + 0x18 + *(longlong *)(param_3 + 8));
                    *pbVar26 = *pbVar26 | 1;
                    pbVar26 = (byte *)(lVar39 + 0x18 + *(longlong *)(param_3 + 8));
                    *pbVar26 = *pbVar26 & 0xfb;
                    pbVar26 = (byte *)(lVar39 + 0x18 + *(longlong *)(param_3 + 8));
                    *pbVar26 = *pbVar26 & 0xfd;
                    lVar39 = lVar39 + *(longlong *)(param_3 + 8);
                    *(undefined8 *)(lVar39 + 0x20) = 0;
                    *(undefined4 *)(lVar39 + 0x28) = 0;
                    *(uint *)(lVar39 + 0x2c) = *(uint *)(lVar39 + 0x2c) & 0xfffffffa;
                    uVar14 = puVar35[1];
                    uVar8 = puVar35[2];
                    uVar9 = puVar35[3];
                    *(undefined4 *)(lVar39 + 0x30) = *puVar35;
                    *(undefined4 *)(lVar39 + 0x34) = uVar14;
                    *(undefined4 *)(lVar39 + 0x38) = uVar8;
                    *(undefined4 *)(lVar39 + 0x3c) = uVar9;
                    *(uint *)(lVar39 + 0x2c) = *(uint *)(lVar39 + 0x2c) & 0xfffffff5;
                    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
                    goto code_r0x00102b28;
                  }
                }
                break;
              }
              plVar37 = (longlong *)*plVar37;
            } while (plVar37 != (longlong *)0x0);
          }
          break;
        }
      }
    case 0x100fd6:
      puVar3 = (ushort *)(psVar32 + 1);
      if (*psVar32 == 0) {
        uVar28 = *puVar38;
        if (*(int *)(psVar32 + 2) == 0) {
          iVar15 = 0;
          *puVar3 = 0;
          uVar16 = *(uint *)(psVar32 + 8);
          uVar24 = (ulonglong)uVar16;
          *(uint *)(psVar32 + 10) = uVar16;
          pbVar26 = *(byte **)(psVar32 + 4);
          bVar10 = *pbVar26;
          if ((bVar10 & 0x10) != 0) {
            uVar16 = uVar16 + 2 + (*(ushort *)(pbVar26 + uVar24) + 7 >> 3);
            uVar24 = (ulonglong)uVar16;
            *(uint *)(psVar32 + 10) = uVar16;
            bVar10 = *pbVar26;
          }
          if ((bVar10 & 0x20) == 0) {
            *(int *)(psVar32 + 2) = (int)uVar24;
            psVar32[0xe] = 0;
            *(int *)(psVar32 + 0xc) = (int)uVar24;
          }
          else {
            puVar44 = (ushort *)(pbVar26 + uVar24);
            uVar12 = *puVar44;
            psVar32[0xe] = uVar12;
            if (uVar12 == 0) {
              *(undefined8 *)(puVar29 + -8) = 0x10104f;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x101058;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x101072;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x10108e;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x1010b4;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x80f);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x1010c2;
              func_0x(uVar18,3);
              uVar24 = (ulonglong)*(uint *)(psVar32 + 10);
              uVar12 = psVar32[0xe];
            }
            uVar16 = (int)uVar24 + (uint)uVar12 * 2 + 2;
            *(uint *)(psVar32 + 0xc) = uVar16;
            if (0x1f9e < uVar16) {
              *(undefined8 *)(puVar29 + -8) = 0x1010f3;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x1010fc;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x101116;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x101132;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x101158;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x816);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x101166;
              func_0x(uVar18,4);
              uVar12 = psVar32[0xe];
              uVar16 = *(uint *)(psVar32 + 0xc);
            }
            uVar24 = (ulonglong)uVar12;
            uVar12 = puVar44[uVar24];
            *(uint *)(psVar32 + 2) = uVar12 & 0x7fff;
            if ((uVar12 & 0x7fff) < uVar16) {
              *(undefined8 *)(puVar29 + -8) = 0x101194;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x10119d;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x1011b7;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x1011d3;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x1011f9;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x81d);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x101207;
              func_0x(uVar18,4);
              uVar16 = *(uint *)(psVar32 + 0xc);
              uVar24 = (ulonglong)(ushort)psVar32[0xe];
            }
            puVar7 = puVar44;
            iVar41 = iVar15;
            if ((short)uVar24 != 0) {
              do {
                uVar42 = puVar7[1] & 0x7fff;
                if ((uVar42 < uVar16) || (*(uint *)(psVar32 + 2) < uVar42)) {
                  *(undefined8 *)(puVar29 + -8) = 0x10123f;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x101248;
                    lVar39 = func_0x();
                    if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar29 + -8) = 0x101262;
                      cVar11 = func_0x(0x11b87f0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x10127e;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar29 + 0x20) = 0;
                        *(undefined8 *)(puVar29 + -8) = 0x1012a4;
                        (*_DAT_)(1,0xaa81fc,0xbc82e8,0x82a);
                      }
                    }
                  }
                  uVar18 = *(undefined8 *)(psVar32 + 4);
                  *(undefined8 *)(puVar29 + -8) = 0x1012b2;
                  func_0x(uVar18,4);
                }
                iVar41 = iVar41 + 1;
                uVar24 = (ulonglong)(ushort)psVar32[0xe];
                puVar7 = puVar7 + 1;
                uVar16 = uVar42;
              } while (iVar41 < (int)(uint)(ushort)psVar32[0xe]);
            }
            if ((short)puVar44[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
              pbVar26 = *(byte **)(psVar32 + 4);
              do {
                uVar16 = *(ushort *)(pbVar26 + uVar24 * 2 + (ulonglong)*(uint *)(psVar32 + 10)) &
                         0x7fff;
                if ((int)uVar24 == 1) {
                  uVar42 = *(uint *)(psVar32 + 0xc);
                  uVar21 = uVar42;
code_r0x0010130f:
                  if ((uVar16 < uVar42) || (*(uint *)(psVar32 + 2) < uVar16)) goto code_r0x00101318;
                }
                else {
                  uVar42 = *(ushort *)
                            (pbVar26 + uVar24 * 2 + ((ulonglong)*(uint *)(psVar32 + 10) - 2)) &
                           0x7fff;
                  uVar21 = *(uint *)(psVar32 + 0xc);
                  if (uVar21 <= uVar42) goto code_r0x0010130f;
code_r0x00101318:
                  *(undefined8 *)(puVar29 + -8) = 0x101325;
                  func_0x(pbVar26,7);
                  uVar21 = *(uint *)(psVar32 + 0xc);
                }
                if ((uVar42 < uVar21) || (*(uint *)(psVar32 + 2) < uVar42)) {
                  puVar38 = *(uint **)(&stack0x00000050 + lVar17);
                  goto code_r0x00101680;
                }
                pbVar26 = *(byte **)(psVar32 + 4);
                if (*(ushort *)(pbVar26 + uVar42) == 5) {
                  *puVar3 = *puVar3 | 2;
                  psVar32[0xe] = psVar32[0xe] + -1;
                  uVar22 = (ulonglong)(uVar42 & 0xffff);
                  psVar32[0x15] = (short)uVar42;
                  uVar36 = *(ulonglong *)(psVar32 + 4);
                  uVar24 = uVar36 + uVar22;
                  uVar12 = psVar32[0x16] & 0xc7ff;
                  if ((*(ushort *)(uVar24 + 2) >> 0xe & 1) != 0) {
                    uVar12 = *(ushort *)(uVar24 + 2) & 0x3800 | uVar12;
                  }
                  psVar32[0x16] = uVar12;
                  uVar13 = (uVar12 ^ *(ushort *)(uVar24 + 2)) & 0x7ff ^ uVar12;
                  psVar32[0x16] = uVar13;
                  uVar43 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 + uVar36 + (uVar12 >> 0xb & 7) * 2
                           + uVar22;
                  if (uVar43 < uVar24) {
                    *(undefined8 *)(puVar29 + -8) = 0x101433;
                    func_0x(uVar24,0x19);
                    uVar13 = psVar32[0x16];
                    uVar22 = (ulonglong)(ushort)psVar32[0x15];
                    uVar36 = (ulonglong)*(uint *)(psVar32 + 4);
                  }
                  if (uVar16 - uVar42 <
                      (((uVar13 & 0x7ff) * 2 - (int)uVar22) - (int)uVar36) + (int)uVar43) {
                    lVar39 = *(longlong *)(psVar32 + 4);
                    *(undefined8 *)(puVar29 + -8) = 0x10146c;
                    func_0x(uVar22 + lVar39,0x19);
                    uVar13 = psVar32[0x16];
                  }
                  if (((uVar13 & 0x3800) != 0) &&
                     (puVar44 = (ushort *)
                                (*(longlong *)(psVar32 + 4) + 4 + (ulonglong)(ushort)psVar32[0x15]),
                     (uVar13 & 0x3800) != 0)) {
                    do {
                      if ((uVar13 & 0x7ff) < (*puVar44 & 0x7ff)) {
                        uVar12 = psVar32[0x15];
                        lVar39 = *(longlong *)(psVar32 + 4);
                        *(undefined8 *)(puVar29 + -8) = 0x1014c7;
                        func_0x((ulonglong)uVar12 + lVar39,0x1a);
                        uVar13 = psVar32[0x16];
                      }
                      iVar15 = iVar15 + 1;
                      puVar44 = puVar44 + 1;
                    } while (iVar15 < (int)(uVar13 >> 0xb & 7));
                  }
                  goto code_r0x001014e2;
                }
                if (*(ushort *)(pbVar26 + uVar42) < 0x400) goto code_r0x001014e2;
                *puVar3 = *puVar3 | 1;
                uVar12 = psVar32[0xe] - 1;
                psVar32[0xe] = uVar12;
                if (uVar12 == 0) goto code_r0x001014e2;
                uVar24 = (ulonglong)uVar12;
              } while ((short)puVar44[(ulonglong)(uVar12 - 1) + 1] < 0);
              uVar24 = (ulonglong)*(uint *)(psVar32 + 2);
              puVar38 = *(uint **)(&stack0x00000050 + lVar17);
            }
            else {
code_r0x001014e2:
              pbVar26 = *(byte **)(psVar32 + 4);
              uVar24 = (ulonglong)*(uint *)(psVar32 + 2);
              puVar38 = *(uint **)(&stack0x00000050 + lVar17);
            }
          }
          if ((*pbVar26 & 0x40) == 0) {
            *(undefined4 *)(psVar32 + 0x13) = 0;
          }
          else {
            *(int *)(psVar32 + 0x13) = (int)uVar24;
            *(int *)(psVar32 + 2) = (int)uVar24 + 0xe;
            *(undefined8 *)(puVar29 + -8) = 0x101515;
            uVar18 = func_0x(puVar3);
            *(undefined8 *)(puVar29 + -8) = 0x101524;
            func_0x(uVar18,&stack0x000000c8 + lVar17);
            *(undefined8 *)(puVar29 + -8) = 0x101530;
            iVar15 = func_0x(&stack0x000000c8 + lVar17);
            *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + iVar15;
            uVar24 = (ulonglong)*(uint *)(psVar32 + 2);
          }
          iVar15 = (int)uVar24;
          if ((*(ulonglong *)(psVar32 + 0xf) != 0) &&
             (*(ulonglong *)(psVar32 + 0xf) < uVar24 + *(longlong *)(psVar32 + 4))) {
            *(undefined8 *)(puVar29 + -8) = 0x101569;
            cVar11 = func_0x(0x11b87f0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar29 + -8) = 0x101572;
              lVar39 = func_0x();
              if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                *(undefined8 *)(puVar29 + -8) = 0x10158c;
                cVar11 = func_0x(0x11b87f0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar29 + -8) = 0x1015a8;
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  *(undefined8 *)(puVar29 + 0x20) = 0;
                  *(undefined8 *)(puVar29 + -8) = 0x1015ce;
                  (*_DAT_)(1,0xaa81fc,0xbc82e8,0x886);
                }
              }
            }
            uVar18 = *(undefined8 *)(psVar32 + 4);
            *(undefined8 *)(puVar29 + -8) = 0x1015dc;
            func_0x(uVar18,0x12);
            iVar15 = *(int *)(psVar32 + 2);
          }
          if (0x3f3b < iVar15 - 1U) {
            *(undefined8 *)(puVar29 + -8) = 0x1015f9;
            cVar11 = func_0x(0x11b87f0);
            if (cVar11 != '\0') {
              *(undefined8 *)(puVar29 + -8) = 0x101602;
              lVar39 = func_0x();
              if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                *(undefined8 *)(puVar29 + -8) = 0x10161c;
                cVar11 = func_0x(0x11b87f0);
                if (cVar11 == '\0') {
                  *(undefined8 *)(puVar29 + -8) = 0x101638;
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                  uVar18 = *(undefined8 *)(psVar32 + 4);
                  *(undefined8 *)(puVar29 + -8) = 0x101646;
                  func_0x(uVar18,5);
                  goto code_r0x00101680;
                }
                *(undefined8 *)(puVar29 + 0x20) = 0;
                *(undefined8 *)(puVar29 + -8) = 0x10166c;
                (*_DAT_)(1,0xaa81fc,0xbc82e8,0x88b);
              }
            }
            uVar18 = *(undefined8 *)(psVar32 + 4);
            *(undefined8 *)(puVar29 + -8) = 0x10167a;
            func_0x(uVar18,5);
          }
        }
code_r0x00101680:
        if ((*(byte *)((longlong)puVar38 + 6) & 0x10) != 0) {
          bVar10 = **(byte **)(psVar32 + 4);
          if ((bVar10 & 0x10) == 0) {
            if ((1 << (bVar10 & 0xe) & 0x1105U) == 0) goto code_r0x001016a4;
code_r0x001016ed:
            puVar19 = *(undefined4 **)(puVar38 + 2) + 1;
            *(undefined4 *)((longlong)&uStackX_24 + lVar17) = **(undefined4 **)(puVar38 + 2);
            *(undefined4 *)(&stack0x00000038 + lVar17) = 0;
            psVar32 = *(short **)(&stack0x00000028 + lVar17);
            goto code_r0x0010183b;
          }
          if (((int)*(uint *)(psVar32 + 8) <= (int)*puVar38) ||
             (*(ushort *)(*(byte **)(psVar32 + 4) + *(uint *)(psVar32 + 8)) <
              *(ushort *)(puVar38 + 1))) goto code_r0x001016ed;
        }
code_r0x001016a4:
        uVar28 = -uVar28;
        puVar19 = *(uint **)(psVar32 + 4);
        if ((ushort)psVar32[0xe] < uVar28) {
          *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 0;
          *(undefined4 *)(&stack0x00000038 + lVar17) = 0;
          psVar32 = *(short **)(&stack0x00000028 + lVar17);
        }
        else {
          uVar16 = *(uint *)(psVar32 + 10);
          lVar39 = (longlong)(int)uVar28;
          if (uVar28 == 1) {
            uVar42 = *(uint *)(psVar32 + 0xc);
            uVar21 = *(ushort *)((longlong)puVar19 + lVar39 * 2 + (ulonglong)uVar16) & 0x7fff;
            puVar40 = puVar19;
code_r0x0010172f:
            if ((uVar21 < uVar42) || (*(uint *)(psVar32 + 2) < uVar21)) goto code_r0x00101738;
          }
          else {
            uVar42 = *(ushort *)((longlong)puVar19 + lVar39 * 2 + ((ulonglong)uVar16 - 2)) & 0x7fff;
            uVar21 = *(ushort *)((longlong)puVar19 + lVar39 * 2 + (ulonglong)uVar16) & 0x7fff;
            puVar40 = *(uint **)(psVar32 + 4);
            if (*(uint *)(psVar32 + 0xc) <= uVar42) goto code_r0x0010172f;
code_r0x00101738:
            *(undefined8 *)(puVar29 + -8) = 0x101745;
            func_0x(puVar40,7);
            puVar40 = *(uint **)(psVar32 + 4);
          }
          *(uint *)((longlong)&uStackX_24 + lVar17) = uVar21 - uVar42;
          if (uVar21 - uVar42 == 0) {
            puVar19 = (uint *)((longlong)puVar40 + (ulonglong)uVar42);
            *(undefined4 *)(&stack0x00000038 + lVar17) = 0;
            psVar32 = *(short **)(&stack0x00000028 + lVar17);
          }
          else {
            puVar3 = (ushort *)
                     ((longlong)puVar19 + (ulonglong)(uVar28 - 1) * 2 + (ulonglong)uVar16 + 2);
            puVar19 = (uint *)((longlong)puVar40 + (ulonglong)uVar42);
            *(uint *)(&stack0x00000038 + lVar17) = (uint)(*puVar3 >> 0xf);
            psVar32 = *(short **)(&stack0x00000028 + lVar17);
          }
        }
      }
      else {
        *(undefined4 *)(&stack0x00000084 + lVar17) = 0;
        *(undefined **)(puVar29 + 0x20) = &stack0x00000084 + lVar17;
        *(undefined8 *)(puVar29 + -8) = 0x1017ba;
        puVar19 = (uint *)func_0x(puVar3,puVar38);
        uVar28 = *(uint *)(&stack0x00000084 + lVar17);
        if (((*psVar32 == 0) || (plVar37 = *(longlong **)(psVar32 + 8), plVar37 == (longlong *)0x0))
           || ((*plVar37 == 0 ||
               (((*(byte *)((longlong)puVar38 + 6) & 8) != 0 || ((uVar28 & 1) != 0)))))) {
code_r0x0010182c:
          *(uint *)(&stack0x00000038 + lVar17) = uVar28 & 1;
          if (puVar19 != (uint *)0x0) goto code_r0x0010183b;
        }
        else {
          if ((puVar19 != (uint *)0x0) && (puVar19 != (uint *)0x82ce90)) {
            *(uint *)(puVar29 + 0x38) = uVar28;
            *(longlong *)(puVar29 + 0x30) = (longlong)&uStackX_24 + lVar17;
            *(undefined4 *)(puVar29 + 0x28) = *(undefined4 *)(&stack0x00000068 + lVar17);
            *(undefined8 *)(puVar29 + 0x20) = *(undefined8 *)(&stack0x000000b0 + lVar17);
            uVar14 = *(undefined4 *)((longlong)&uStackX_24 + lVar17);
            *(undefined8 *)(puVar29 + -8) = 0x101829;
            puVar19 = (uint *)func_0x(plVar37,puVar38,puVar19,uVar14);
            goto code_r0x0010182c;
          }
          *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 0;
          *(uint *)(&stack0x00000038 + lVar17) = uVar28 & 1;
        }
        puVar19 = *(uint **)(psVar32 + 4);
      }
code_r0x0010183b:
      puVar23 = (uint *)0x0;
      if ((*(ushort *)(*(longlong *)(puVar38 + 0x12) + 0xc) & 0x400) != 0) {
        puVar3 = (ushort *)(psVar32 + 1);
        if (*(int *)(psVar32 + 2) == 0) {
          *puVar3 = 0;
          uVar28 = *(uint *)(psVar32 + 8);
          uVar24 = (ulonglong)uVar28;
          *(uint *)(psVar32 + 10) = uVar28;
          pbVar26 = *(byte **)(psVar32 + 4);
          bVar10 = *pbVar26;
          if ((bVar10 & 0x10) != 0) {
            uVar28 = uVar28 + 2 + (*(ushort *)(pbVar26 + uVar24) + 7 >> 3);
            uVar24 = (ulonglong)uVar28;
            *(uint *)(psVar32 + 10) = uVar28;
            bVar10 = *pbVar26;
          }
          psVar31 = psVar32;
          if ((bVar10 & 0x20) == 0) {
            *(int *)(psVar32 + 2) = (int)uVar24;
            psVar32[0xe] = 0;
            *(int *)(psVar32 + 0xc) = (int)uVar24;
          }
          else {
            puVar44 = (ushort *)(pbVar26 + uVar24);
            uVar12 = *puVar44;
            psVar32[0xe] = uVar12;
            if (uVar12 == 0) {
              *(undefined8 *)(puVar29 + -8) = 0x1018ba;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x1018c3;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x1018dd;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x1018f9;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x10192e;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x80f);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x10193c;
              func_0x(uVar18,3);
              uVar24 = (ulonglong)*(uint *)(psVar32 + 10);
              uVar12 = psVar32[0xe];
            }
            uVar28 = (int)uVar24 + (uint)uVar12 * 2 + 2;
            *(uint *)(psVar32 + 0xc) = uVar28;
            if (0x1f9e < uVar28) {
              *(undefined8 *)(puVar29 + -8) = 0x10196d;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x101976;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x101990;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x1019ac;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x1019d2;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x816);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x1019e0;
              func_0x(uVar18,4);
              uVar12 = psVar32[0xe];
              uVar28 = *(uint *)(psVar32 + 0xc);
            }
            uVar24 = (ulonglong)uVar12;
            uVar12 = puVar44[uVar24];
            *(uint *)(psVar32 + 2) = uVar12 & 0x7fff;
            if ((uVar12 & 0x7fff) < uVar28) {
              *(undefined8 *)(puVar29 + -8) = 0x101a0e;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x101a17;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x101a31;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x101a4d;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x101a73;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x81d);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x101a81;
              func_0x(uVar18,4);
              uVar28 = *(uint *)(psVar32 + 0xc);
              uVar24 = (ulonglong)(ushort)psVar32[0xe];
            }
            puVar38 = puVar23;
            puVar7 = puVar44;
            if ((short)uVar24 != 0) {
              do {
                uVar16 = puVar7[1] & 0x7fff;
                if ((uVar16 < uVar28) || (*(uint *)(psVar32 + 2) < uVar16)) {
                  *(undefined8 *)(puVar29 + -8) = 0x101abf;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x101ac8;
                    lVar39 = func_0x();
                    if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar29 + -8) = 0x101ae2;
                      cVar11 = func_0x(0x11b87f0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x101afe;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar29 + 0x20) = 0;
                        *(undefined8 *)(puVar29 + -8) = 0x101b24;
                        (*_DAT_)(1,0xaa81fc,0xbc82e8,0x82a);
                      }
                    }
                  }
                  uVar18 = *(undefined8 *)(psVar32 + 4);
                  *(undefined8 *)(puVar29 + -8) = 0x101b32;
                  func_0x(uVar18,4);
                }
                uVar42 = (int)puVar38 + 1;
                uVar24 = (ulonglong)(ushort)psVar32[0xe];
                puVar38 = (uint *)(ulonglong)uVar42;
                puVar7 = puVar7 + 1;
                uVar28 = uVar16;
              } while ((int)uVar42 < (int)(uint)(ushort)psVar32[0xe]);
              psVar31 = *(short **)(&stack0x00000028 + lVar17);
            }
            if ((short)puVar44[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
              uVar36 = *(ulonglong *)(psVar32 + 4);
code_r0x00101b70:
              lVar39 = *(uint *)(psVar32 + 10) + uVar36;
              if ((int)uVar24 == 1) {
                uVar28 = *(uint *)(psVar32 + 0xc);
                uVar42 = *(ushort *)(lVar39 + uVar24 * 2) & 0x7fff;
                uVar16 = uVar28;
code_r0x00101bab:
                if ((uVar42 < uVar28) || (*(uint *)(psVar32 + 2) < uVar42)) goto code_r0x00101bb4;
              }
              else {
                uVar28 = *(ushort *)(lVar39 + -2 + uVar24 * 2) & 0x7fff;
                uVar16 = *(uint *)(psVar31 + 0xc);
                uVar42 = *(ushort *)(lVar39 + uVar24 * 2) & 0x7fff;
                if (uVar16 <= uVar28) goto code_r0x00101bab;
code_r0x00101bb4:
                *(undefined8 *)(puVar29 + -8) = 0x101bc1;
                func_0x(uVar36,7);
                uVar16 = *(uint *)(*(longlong *)(&stack0x00000028 + lVar17) + 0x18);
              }
              if ((uVar28 < uVar16) || (*(uint *)(psVar32 + 2) < uVar28)) goto code_r0x00101f08;
              uVar36 = *(ulonglong *)(psVar32 + 4);
              if (*(ushort *)(uVar28 + uVar36) != 5) {
                if (*(ushort *)(uVar28 + uVar36) < 0x400) goto code_r0x00101d82;
                *puVar3 = *puVar3 | 1;
                uVar12 = psVar32[0xe] - 1;
                psVar32[0xe] = uVar12;
                psVar31 = *(short **)(&stack0x00000028 + lVar17);
                if (uVar12 == 0) goto code_r0x00101d86;
                uVar24 = (ulonglong)uVar12;
                if (-1 < (short)puVar44[(ulonglong)(uVar12 - 1) + 1]) goto code_r0x00101c2a;
                goto code_r0x00101b70;
              }
              *puVar3 = *puVar3 | 2;
              psVar32[0xe] = psVar32[0xe] + -1;
              uVar22 = (ulonglong)(uVar28 & 0xffff);
              psVar32[0x15] = (short)uVar28;
              uVar24 = uVar22 + uVar36;
              uVar12 = psVar32[0x16] & 0xc7ff;
              if ((*(ushort *)(uVar24 + 2) >> 0xe & 1) != 0) {
                uVar12 = *(ushort *)(uVar24 + 2) & 0x3800 | uVar12;
              }
              psVar32[0x16] = uVar12;
              uVar13 = (uVar12 ^ *(ushort *)(uVar24 + 2)) & 0x7ff ^ uVar12;
              psVar32[0x16] = uVar13;
              uVar43 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 + uVar22 + (uVar12 >> 0xb & 7) * 2 +
                       uVar36;
              if (uVar43 < uVar24) {
                *(undefined8 *)(puVar29 + -8) = 0x101cd5;
                func_0x(uVar24,0x19);
                uVar13 = psVar32[0x16];
                uVar22 = (ulonglong)(ushort)psVar32[0x15];
                uVar36 = (ulonglong)*(uint *)(psVar32 + 4);
              }
              if (uVar42 - uVar28 <
                  (((uVar13 & 0x7ff) * 2 - (int)uVar22) - (int)uVar36) + (int)uVar43) {
                lVar39 = *(longlong *)(psVar32 + 4);
                *(undefined8 *)(puVar29 + -8) = 0x101d0e;
                func_0x(uVar22 + lVar39,0x19);
                uVar13 = psVar32[0x16];
              }
              if (((uVar13 & 0x3800) != 0) &&
                 (puVar44 = (ushort *)
                            (*(longlong *)(psVar32 + 4) + 4 + (ulonglong)(ushort)psVar32[0x15]),
                 puVar38 = puVar23, (uVar13 & 0x3800) != 0)) {
                do {
                  if ((uVar13 & 0x7ff) < (*puVar44 & 0x7ff)) {
                    uVar12 = psVar32[0x15];
                    lVar39 = *(longlong *)(psVar32 + 4);
                    *(undefined8 *)(puVar29 + -8) = 0x101d67;
                    func_0x((ulonglong)uVar12 + lVar39,0x1a);
                    uVar13 = psVar32[0x16];
                  }
                  uVar28 = (int)puVar38 + 1;
                  puVar38 = (uint *)(ulonglong)uVar28;
                  puVar44 = puVar44 + 1;
                } while ((int)uVar28 < (int)(uVar13 >> 0xb & 7));
              }
code_r0x00101d82:
              psVar31 = *(short **)(&stack0x00000028 + lVar17);
            }
code_r0x00101d86:
            pbVar26 = *(byte **)(psVar31 + 4);
            uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
          }
          goto code_r0x00101d9d;
        }
        goto code_r0x00101f08;
      }
      if (*(int *)((longlong)&uStackX_24 + lVar17) == 0) goto code_r0x00101f6a;
      goto code_r0x00101f87;
    case 0x10183b:
      goto code_r0x0010183b;
    case 0x102241:
      puVar40 = *(uint **)(psVar32 + 4);
      if (*psVar32 == 0) {
        puVar3 = (ushort *)(psVar32 + 1);
        uVar28 = *(uint *)(psVar32 + 2);
        if (uVar28 == 0) {
          *puVar3 = 0;
          uVar28 = *(uint *)(psVar32 + 8);
          uVar24 = (ulonglong)uVar28;
          *(uint *)(psVar32 + 10) = uVar28;
          pbVar26 = *(byte **)(psVar32 + 4);
          bVar10 = *pbVar26;
          if ((bVar10 & 0x10) != 0) {
            uVar28 = uVar28 + 2 + (*(ushort *)(pbVar26 + uVar24) + 7 >> 3);
            uVar24 = (ulonglong)uVar28;
            *(uint *)(psVar32 + 10) = uVar28;
            bVar10 = *pbVar26;
          }
          psVar31 = psVar32;
          if ((bVar10 & 0x20) == 0) {
            *(int *)(psVar32 + 2) = (int)uVar24;
            psVar32[0xe] = 0;
            *(int *)(psVar32 + 0xc) = (int)uVar24;
          }
          else {
            puVar44 = (ushort *)(pbVar26 + uVar24);
            uVar12 = *puVar44;
            psVar32[0xe] = uVar12;
            if (uVar12 == 0) {
              *(undefined8 *)(puVar29 + -8) = 0x1022b9;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x1022c2;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x1022dc;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x1022f8;
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x10231e;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x80f);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x10232c;
              func_0x(uVar18,3);
              uVar24 = (ulonglong)*(uint *)(psVar32 + 10);
              uVar12 = psVar32[0xe];
            }
            uVar28 = (int)uVar24 + (uint)uVar12 * 2 + 2;
            *(uint *)(psVar32 + 0xc) = uVar28;
            if (0x1f9e < uVar28) {
              *(undefined8 *)(puVar29 + -8) = 0x10235d;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x102366;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x102380;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x10239c;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x1023c2;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x816);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x1023d0;
              func_0x(uVar18,4);
              uVar12 = psVar32[0xe];
              uVar28 = *(uint *)(psVar32 + 0xc);
            }
            uVar24 = (ulonglong)uVar12;
            uVar12 = puVar44[uVar24];
            *(uint *)(psVar32 + 2) = uVar12 & 0x7fff;
            if ((uVar12 & 0x7fff) < uVar28) {
              *(undefined8 *)(puVar29 + -8) = 0x1023fe;
              cVar11 = func_0x(0x11b87f0);
              if (cVar11 != '\0') {
                *(undefined8 *)(puVar29 + -8) = 0x102407;
                lVar39 = func_0x();
                if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                  *(undefined8 *)(puVar29 + -8) = 0x102421;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 == '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x10243d;
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    *(undefined8 *)(puVar29 + 0x20) = 0;
                    *(undefined8 *)(puVar29 + -8) = 0x102463;
                    (*_DAT_)(1,0xaa81fc,0xbc82e8,0x81d);
                  }
                }
              }
              uVar18 = *(undefined8 *)(psVar32 + 4);
              *(undefined8 *)(puVar29 + -8) = 0x102471;
              func_0x(uVar18,4);
              uVar28 = *(uint *)(psVar32 + 0xc);
              uVar24 = (ulonglong)(ushort)psVar32[0xe];
            }
            puVar38 = puVar19;
            puVar7 = puVar44;
            if ((short)uVar24 != 0) {
              do {
                uVar16 = puVar7[1] & 0x7fff;
                if ((uVar16 < uVar28) || (*(uint *)(psVar32 + 2) < uVar16)) {
                  *(undefined8 *)(puVar29 + -8) = 0x1024af;
                  cVar11 = func_0x(0x11b87f0);
                  if (cVar11 != '\0') {
                    *(undefined8 *)(puVar29 + -8) = 0x1024b8;
                    lVar39 = func_0x();
                    if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
                      *(undefined8 *)(puVar29 + -8) = 0x1024d2;
                      cVar11 = func_0x(0x11b87f0);
                      if (cVar11 == '\0') {
                        *(undefined8 *)(puVar29 + -8) = 0x1024ee;
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        *(undefined8 *)(puVar29 + 0x20) = 0;
                        *(undefined8 *)(puVar29 + -8) = 0x102514;
                        (*_DAT_)(1,0xaa81fc,0xbc82e8,0x82a);
                      }
                    }
                  }
                  uVar18 = *(undefined8 *)(psVar32 + 4);
                  *(undefined8 *)(puVar29 + -8) = 0x102522;
                  func_0x(uVar18,4);
                }
                uVar42 = (int)puVar38 + 1;
                uVar24 = (ulonglong)(ushort)psVar32[0xe];
                puVar38 = (uint *)(ulonglong)uVar42;
                puVar7 = puVar7 + 1;
                uVar28 = uVar16;
              } while ((int)uVar42 < (int)(uint)(ushort)psVar32[0xe]);
              psVar31 = *(short **)(&stack0x00000028 + lVar17);
            }
            if ((short)puVar44[(ulonglong)((int)uVar24 - 1) + 1] < 0) {
              uVar36 = *(ulonglong *)(psVar32 + 4);
code_r0x00102560:
              lVar39 = *(uint *)(psVar32 + 10) + uVar36;
              if ((int)uVar24 == 1) {
                uVar16 = *(uint *)(psVar32 + 0xc);
                uVar21 = *(ushort *)(lVar39 + uVar24 * 2) & 0x7fff;
                uVar42 = uVar16;
code_r0x0010259b:
                if ((uVar21 < uVar16) || (uVar28 = *(uint *)(psVar32 + 2), uVar28 < uVar21))
                goto code_r0x001025a6;
              }
              else {
                uVar16 = *(ushort *)(lVar39 + -2 + uVar24 * 2) & 0x7fff;
                uVar42 = *(uint *)(psVar31 + 0xc);
                uVar21 = *(ushort *)(lVar39 + uVar24 * 2) & 0x7fff;
                if (uVar42 <= uVar16) goto code_r0x0010259b;
code_r0x001025a6:
                *(undefined8 *)(puVar29 + -8) = 0x1025b3;
                func_0x(uVar36,7);
                uVar42 = *(uint *)(*(longlong *)(&stack0x00000028 + lVar17) + 0x18);
                uVar28 = *(uint *)(*(longlong *)(&stack0x00000028 + lVar17) + 4);
              }
              if ((uVar16 < uVar42) || (uVar28 < uVar16)) goto code_r0x00102911;
              uVar36 = *(ulonglong *)(psVar32 + 4);
              if (*(ushort *)(uVar16 + uVar36) != 5) {
                if (*(ushort *)(uVar16 + uVar36) < 0x400) goto code_r0x00102782;
                *puVar3 = *puVar3 | 1;
                uVar12 = psVar32[0xe] - 1;
                psVar32[0xe] = uVar12;
                psVar31 = *(short **)(&stack0x00000028 + lVar17);
                if (uVar12 == 0) goto code_r0x00102786;
                uVar24 = (ulonglong)uVar12;
                if (-1 < (short)puVar44[(ulonglong)(uVar12 - 1) + 1]) goto code_r0x0010261f;
                goto code_r0x00102560;
              }
              *puVar3 = *puVar3 | 2;
              psVar32[0xe] = psVar32[0xe] + -1;
              uVar22 = (ulonglong)(uVar16 & 0xffff);
              psVar32[0x15] = (short)uVar16;
              uVar24 = uVar22 + uVar36;
              uVar12 = psVar32[0x16] & 0xc7ff;
              if ((*(ushort *)(uVar24 + 2) >> 0xe & 1) != 0) {
                uVar12 = *(ushort *)(uVar24 + 2) & 0x3800 | uVar12;
              }
              psVar32[0x16] = uVar12;
              uVar13 = (uVar12 ^ *(ushort *)(uVar24 + 2)) & 0x7ff ^ uVar12;
              psVar32[0x16] = uVar13;
              uVar43 = (ulonglong)((uVar13 & 0x7ff) * 2) + 4 + uVar36 + (uVar12 >> 0xb & 7) * 2 +
                       uVar22;
              if (uVar43 < uVar24) {
                *(undefined8 *)(puVar29 + -8) = 0x1026ca;
                func_0x(uVar24,0x19);
                uVar13 = psVar32[0x16];
                uVar22 = (ulonglong)(ushort)psVar32[0x15];
                uVar36 = (ulonglong)*(uint *)(psVar32 + 4);
              }
              if (uVar21 - uVar16 <
                  (((uVar13 & 0x7ff) * 2 - (int)uVar22) - (int)uVar36) + (int)uVar43) {
                lVar39 = *(longlong *)(psVar32 + 4);
                *(undefined8 *)(puVar29 + -8) = 0x102703;
                func_0x(uVar22 + lVar39,0x19);
                uVar13 = psVar32[0x16];
              }
              if (((uVar13 & 0x3800) != 0) &&
                 (puVar44 = (ushort *)
                            (*(longlong *)(psVar32 + 4) + 4 + (ulonglong)(ushort)psVar32[0x15]),
                 (uVar13 & 0x3800) != 0)) {
                do {
                  if ((uVar13 & 0x7ff) < (*puVar44 & 0x7ff)) {
                    uVar12 = psVar32[0x15];
                    lVar39 = *(longlong *)(psVar32 + 4);
                    *(undefined8 *)(puVar29 + -8) = 0x102767;
                    func_0x((ulonglong)uVar12 + lVar39,0x1a);
                    uVar13 = psVar32[0x16];
                  }
                  uVar28 = (int)puVar19 + 1;
                  puVar19 = (uint *)(ulonglong)uVar28;
                  puVar44 = puVar44 + 1;
                } while ((int)uVar28 < (int)(uVar13 >> 0xb & 7));
              }
code_r0x00102782:
              psVar31 = *(short **)(&stack0x00000028 + lVar17);
            }
code_r0x00102786:
            pbVar26 = *(byte **)(psVar31 + 4);
            uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
          }
          goto code_r0x0010279d;
        }
        goto code_r0x00102911;
      }
      uVar28 = *(uint *)(psVar32 + 2);
      if (uVar28 == 0) {
        *(undefined8 *)(puVar29 + -8) = 0x102948;
        func_0x(psVar32 + 1);
        uVar28 = *(uint *)(psVar32 + 2);
      }
      if ((uVar28 < 9) &&
         (((**(byte **)(psVar32 + 4) & 0x1c) == 0 || ((**(byte **)(psVar32 + 4) & 0x1c) == 0xc)))) {
        uVar28 = 9;
      }
      *(uint *)((longlong)&uStackX_24 + lVar17) = uVar28;
      goto code_r0x00100afd;
    case 0x10296e:
code_r0x0010296e:
      if (*(longlong *)(&stack0x00000058 + lVar17) == 0) {
        uVar24 = (ulonglong)uVar28 * 4 + 0xf;
        if (uVar24 <= (ulonglong)uVar28 * 4) {
          uVar24 = 0xffffffffffffff0;
        }
        uVar24 = uVar24 & 0xfffffffffffffff0;
        *(undefined8 *)(puVar29 + -8) = 0x10299b;
        func_0x();
        puVar30 = puVar29 + -uVar24;
        *(undefined **)(&stack0x00000058 + lVar17) = puVar29 + -uVar24 + 0x60;
        uVar28 = *(uint *)(&stack0x00000034 + lVar17);
        *(uint *)(&stack0x00000060 + lVar17) = uVar28;
        *(undefined4 *)(&stack0x00000064 + lVar17) = 0;
        uVar36 = *(ulonglong *)(&stack0x00000078 + lVar17);
      }
      *(undefined4 *)
       (*(longlong *)(&stack0x00000058 + lVar17) +
       (ulonglong)*(uint *)(&stack0x00000064 + lVar17) * 4) = uVar14;
      *(int *)(&stack0x00000064 + lVar17) = *(int *)(&stack0x00000064 + lVar17) + 1;
      goto code_r0x00102b2f;
    case 0x1029c9:
      plVar37 = (longlong *)param_1[1];
      pcVar5 = *(code **)(*plVar37 + 0x18);
      *(undefined8 *)(puVar29 + -8) = 0x1029e4;
      (*pcVar5)(plVar37,&stack0x000020d0 + lVar17,8,(longlong)&uStackX_24 + lVar17);
      puVar40 = (uint *)(&stack0x000020d0 + lVar17);
      break;
    case 0x1029f0:
      pcVar5 = *(code **)(*(longlong *)param_1[1] + 0x10);
      *(undefined8 *)(puVar29 + -8) = 0x1029fa;
      uVar14 = (*pcVar5)();
      *(undefined4 *)(&stack0x00000098 + lVar17) = uVar14;
      *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 4;
      puVar40 = (uint *)(&stack0x00000098 + lVar17);
      break;
    case 0x102a0d:
      if (*(int *)(*(longlong *)(puVar38 + 0x12) + 0x10) != 10) goto code_r0x0010296e;
      goto code_r0x00102b2f;
    case 0x102a20:
      *(undefined8 *)(puVar29 + -8) = 0x102a28;
      iVar15 = func_0x(psVar32);
      if (0 < iVar15) {
        *(undefined8 *)(puVar29 + -8) = 0x102d6d;
        func_0x(extraout_XMM0_Da,puVar38);
        pcVar5 = (code *)swi(3);
        (*pcVar5)();
        return;
      }
      *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 0;
      puVar40 = puVar19;
      break;
    case 0x102a39:
      pcVar5 = *(code **)(**pplRam0000000000725780 + 0x1f8);
      *(undefined8 *)(puVar29 + -8) = 0x102a4c;
      lVar39 = (*pcVar5)();
      iVar15 = 1;
      if (*(int *)(lVar39 + 0x34) != 0) {
        iVar15 = *(int *)(lVar39 + 0x34);
      }
      *(int *)(&stack0x0000009c + lVar17) = iVar15;
      *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 4;
      puVar40 = (uint *)(&stack0x0000009c + lVar17);
      break;
    case 0x102a6c:
      *(undefined4 *)(&stack0x000000a0 + lVar17) =
           *(undefined4 *)(*(longlong *)(param_1[3] + 0x20) + 0x664);
      *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 4;
      puVar40 = (uint *)(&stack0x000000a0 + lVar17);
      break;
    case 0x102a93:
      plVar37 = (longlong *)param_1[1];
      pcVar5 = *(code **)(*plVar37 + 0x20);
      *(undefined8 *)(puVar29 + -8) = 0x102aae;
      (*pcVar5)(plVar37,&stack0x000020d8 + lVar17,0xa59,(longlong)&uStackX_24 + lVar17);
      puVar40 = (uint *)(&stack0x000020d8 + lVar17);
      if (*(int *)((longlong)&uStackX_24 + lVar17) == 0) {
        puVar40 = puVar19;
      }
      break;
    case 0x102ac2:
      goto LAB_;
    }
    goto code_r0x00100b07;
  }
LAB_:
  uVar24 = 0;
  if (*(longlong **)(lVar27 + 0x10) != (longlong *)0x0) {
    pcVar5 = *(code **)(**(longlong **)(lVar27 + 0x10) + 8);
    *(undefined8 *)(puVar30 + -8) = 0x102b6e;
    (*pcVar5)();
  }
  if (*(int *)(&stack0x00000064 + lVar17) != 0) {
    *(undefined **)(puVar30 + 0x28) = &stack0x00000070 + lVar17;
    *(undefined **)(puVar30 + 0x20) = &stack0x0000006c + lVar17;
    *(undefined8 *)(puVar30 + -8) = 0x102b99;
    func_0x(param_1,param_2,&stack0x00000058 + lVar17,&stack0x00000088 + lVar17);
  }
  if ((param_3 != 0) && (*(int *)(param_3 + 4) != 0)) {
    uVar18 = *(undefined8 *)(&stack0x00000040 + lVar17);
    lVar39 = *(longlong *)(&stack0x000000e8 + lVar17);
    do {
      puVar38 = (uint *)(uVar24 * 0x40 + *(longlong *)(param_3 + 8));
      lVar27 = (ulonglong)*puVar38 * 0x50 + *(longlong *)(*(longlong *)(lVar39 + 0x80) + 0x18);
      iVar15 = *(int *)(*(longlong *)(lVar27 + 0x48) + 0x10);
      if (iVar15 != 2) {
        if (iVar15 == 9) {
          uVar28 = puVar38[0xb];
          *(undefined **)(puVar30 + 0x38) = &stack0x00000030 + lVar17;
          *(undefined8 *)(puVar30 + 0x30) = uVar18;
          *(uint *)(puVar30 + 0x28) = uVar28 & 1;
          *(undefined8 *)(puVar30 + 0x20) = *(undefined8 *)(puVar38 + 8);
          uVar28 = puVar38[10];
          uVar6 = *param_1;
          *(undefined8 *)(puVar30 + -8) = 0x102c47;
          func_0x(&stack0x00000030 + lVar17,lVar27,uVar6,uVar28);
          if ((cVar11 != '\0') || ((&stack0x00000030)[lVar17] != '\0')) {
            cVar11 = '\x01';
          }
        }
        else {
          *(undefined8 *)(puVar30 + 0x20) = 0x823760;
          *(undefined8 *)(puVar30 + -8) = 0x102c17;
          (*_DAT_)(1,0xc29af0,0xc2fdf0,0x265);
        }
      }
      uVar28 = (int)uVar24 + 1;
      uVar24 = (ulonglong)uVar28;
    } while (uVar28 < *(uint *)(param_3 + 4));
  }
  uVar24 = 0;
  if (*(longlong **)(param_1[1] + 0x10) != (longlong *)0x0) {
    pcVar5 = *(code **)(**(longlong **)(param_1[1] + 0x10) + 8);
    *(undefined8 *)(puVar30 + -8) = 0x102c76;
    (*pcVar5)();
  }
  if (cVar11 == '\0') {
    iVar15 = *(int *)(&stack0x0000006c + lVar17);
    iVar41 = *(int *)(&stack0x00000088 + lVar17);
    if (((iVar41 == 0) && (iVar15 == 0)) && (*(int *)(&stack0x00000070 + lVar17) == 0)) {
      **(undefined4 **)(&stack0x000000a8 + lVar17) = 1;
    }
    else {
      **(undefined4 **)(&stack0x000000a8 + lVar17) = 0;
      if (iVar41 != 0) {
        uVar18 = *param_1;
        *(undefined8 *)(puVar30 + -8) = 0x102cc7;
        func_0x(uVar18,1);
        iVar15 = *(int *)(&stack0x0000006c + lVar17);
      }
      if (iVar15 != 0) {
        uVar18 = *param_1;
        *(undefined8 *)(puVar30 + -8) = 0x102cd8;
        func_0x(uVar18,0);
      }
      if (*(int *)(&stack0x00000070 + lVar17) != 0) {
        uVar18 = *param_1;
        *(undefined8 *)(puVar30 + -8) = 0x102ceb;
        func_0x(uVar18,2);
      }
    }
  }
  else {
    **(undefined4 **)(&stack0x000000a8 + lVar17) = 2;
  }
  lVar39 = *(longlong *)(&stack0x00000108 + lVar17);
  if ((lVar39 != 0) && (uVar28 = *(uint *)(&stack0x00000100 + lVar17), uVar28 != 0)) {
    do {
      lVar27 = uVar24 * 0x40;
      if ((*(byte *)(lVar39 + 0x18 + lVar27) & 4) != 0) {
        uVar18 = *(undefined8 *)(lVar39 + 0x20 + lVar27);
        *(undefined8 *)(puVar30 + -8) = 0x102d1b;
        (*_DAT_)(uVar18);
        pbVar26 = (byte *)(*(longlong *)(&stack0x00000108 + lVar17) + 0x18 + lVar27);
        *pbVar26 = *pbVar26 & 0xfb;
        lVar39 = *(longlong *)(&stack0x00000108 + lVar17);
        uVar28 = *(uint *)(&stack0x00000100 + lVar17);
      }
      uVar16 = (int)uVar24 + 1;
      uVar24 = (ulonglong)uVar16;
    } while (uVar16 < uVar28);
  }
  uVar24 = *(ulonglong *)(&stack0x000020e0 + lVar17);
  *(undefined8 *)(puVar30 + -8) = 0x102d4b;
  func_0x(uVar24 ^ (ulonglong)pcVar1);
  return;
code_r0x00100750:
  uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
  puVar38 = *(uint **)(&stack0x00000050 + lVar17);
code_r0x001008bd:
  if ((**(byte **)(psVar32 + 4) & 0x40) == 0) {
    *(undefined4 *)(psVar32 + 0x13) = 0;
  }
  else {
    *(int *)(psVar32 + 0x13) = (int)uVar24;
    *(int *)(psVar32 + 2) = (int)uVar24 + 0xe;
    *(undefined8 *)(puVar29 + -8) = 0x1008d9;
    uVar18 = func_0x(puVar3);
    *(undefined8 *)(puVar29 + -8) = 0x1008e8;
    func_0x(uVar18,&stack0x000000c0 + lVar17);
    *(undefined8 *)(puVar29 + -8) = 0x1008f4;
    iVar15 = func_0x(&stack0x000000c0 + lVar17);
    *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + iVar15;
    uVar24 = (ulonglong)*(uint *)(psVar32 + 2);
  }
  iVar15 = (int)uVar24;
  if ((*(ulonglong *)(psVar32 + 0xf) != 0) &&
     (*(ulonglong *)(psVar32 + 0xf) < uVar24 + *(longlong *)(psVar32 + 4))) {
    *(undefined8 *)(puVar29 + -8) = 0x10092d;
    cVar11 = func_0x(0x11b87f0);
    if (cVar11 != '\0') {
      *(undefined8 *)(puVar29 + -8) = 0x100936;
      lVar39 = func_0x();
      if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
        *(undefined8 *)(puVar29 + -8) = 0x100950;
        cVar11 = func_0x(0x11b87f0);
        if (cVar11 == '\0') {
          *(undefined8 *)(puVar29 + -8) = 0x10096c;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(puVar29 + 0x20) = 0;
          *(undefined8 *)(puVar29 + -8) = 0x100992;
          (*_DAT_)(1,0xaa81fc,0xbc82e8,0x886);
        }
      }
    }
    uVar18 = *(undefined8 *)(psVar32 + 4);
    *(undefined8 *)(puVar29 + -8) = 0x1009a0;
    func_0x(uVar18,0x12);
    iVar15 = *(int *)(psVar31 + 2);
  }
  if (0x3f3b < iVar15 - 1U) {
    *(undefined8 *)(puVar29 + -8) = 0x1009b9;
    cVar11 = func_0x(0x11b87f0);
    if (cVar11 != '\0') {
      *(undefined8 *)(puVar29 + -8) = 0x1009c2;
      lVar39 = func_0x();
      if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
        *(undefined8 *)(puVar29 + -8) = 0x1009dc;
        cVar11 = func_0x(0x11b87f0);
        if (cVar11 == '\0') {
          *(undefined8 *)(puVar29 + -8) = 0x1009f8;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(puVar29 + 0x20) = 0;
          *(undefined8 *)(puVar29 + -8) = 0x100a1e;
          (*_DAT_)(1,0xaa81fc,0xbc82e8,0x88b);
        }
      }
    }
    uVar18 = *(undefined8 *)(psVar32 + 4);
    *(undefined8 *)(puVar29 + -8) = 0x100a2c;
    func_0x(uVar18,5);
  }
code_r0x00100a2c:
  lVar39 = *(longlong *)(&stack0x00000028 + lVar17);
code_r0x00100a36:
  sVar25 = -*(short *)puVar38;
  if ((*(byte *)((longlong)puVar38 + 6) & 0x10) == 0) {
code_r0x00100a62:
    lVar27 = (longlong)sVar25;
    puVar19 = *(uint **)(psVar32 + 4);
    if ((uint)(ushort)psVar32[0xe] < (uint)(int)sVar25) {
code_r0x00100af7:
      uVar16 = 0;
    }
    else {
      uVar28 = *(uint *)(psVar32 + 10);
      if (sVar25 == 1) {
        uVar42 = *(uint *)(psVar32 + 0xc);
        uVar16 = *(ushort *)((longlong)puVar19 + lVar27 * 2 + (ulonglong)uVar28) & 0x7fff;
code_r0x00100ad4:
        if ((uVar16 < uVar42) || (*(uint *)(psVar32 + 2) < uVar16)) goto code_r0x00100add;
      }
      else {
        uVar42 = *(ushort *)((longlong)puVar19 + lVar27 * 2 + ((ulonglong)uVar28 - 2)) & 0x7fff;
        uVar16 = *(ushort *)((longlong)puVar19 + lVar27 * 2 + (ulonglong)uVar28) & 0x7fff;
        puVar19 = *(uint **)(lVar39 + 8);
        if (*(uint *)(lVar39 + 0x18) <= uVar42) goto code_r0x00100ad4;
code_r0x00100add:
        *(undefined8 *)(puVar29 + -8) = 0x100aea;
        func_0x(puVar19,7);
        puVar19 = *(uint **)(lVar39 + 8);
      }
      puVar19 = (uint *)((longlong)puVar19 + (ulonglong)uVar42);
      uVar16 = uVar16 - uVar42;
    }
  }
  else {
    bVar10 = **(byte **)(psVar32 + 4);
    if ((bVar10 & 0x10) == 0) {
      if ((1 << (bVar10 & 0xe) & 0x1105U) == 0) goto code_r0x00100a62;
    }
    else if (((int)*puVar38 < (int)*(uint *)(psVar32 + 8)) &&
            (*(ushort *)(puVar38 + 1) <=
             *(ushort *)(*(byte **)(psVar32 + 4) + *(uint *)(psVar32 + 8)))) goto code_r0x00100a62;
    puVar19 = *(uint **)(puVar38 + 2) + 1;
    uVar16 = **(uint **)(puVar38 + 2);
  }
code_r0x00100afa:
  *(uint *)((longlong)&uStackX_24 + lVar17) = uVar16;
  puVar40 = puVar19;
  goto code_r0x00100afd;
code_r0x0010261f:
  pbVar26 = *(byte **)(psVar31 + 4);
  uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
code_r0x0010279d:
  if ((*pbVar26 & 0x40) == 0) {
    *(undefined4 *)(psVar32 + 0x13) = 0;
  }
  else {
    *(int *)(psVar32 + 0x13) = (int)uVar24;
    *(int *)(psVar32 + 2) = (int)uVar24 + 0xe;
    *(undefined8 *)(puVar29 + -8) = 0x1027b5;
    uVar18 = func_0x(puVar3);
    *(undefined8 *)(puVar29 + -8) = 0x1027c4;
    func_0x(uVar18,&stack0x000000d8 + lVar17);
    *(undefined8 *)(puVar29 + -8) = 0x1027d0;
    iVar15 = func_0x(&stack0x000000d8 + lVar17);
    *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + iVar15;
    uVar24 = (ulonglong)*(uint *)(psVar32 + 2);
  }
  uVar28 = (uint)uVar24;
  if ((*(ulonglong *)(psVar32 + 0xf) != 0) &&
     (*(ulonglong *)(psVar32 + 0xf) < uVar24 + *(longlong *)(psVar32 + 4))) {
    *(undefined8 *)(puVar29 + -8) = 0x102809;
    cVar11 = func_0x(0x11b87f0);
    if (cVar11 != '\0') {
      *(undefined8 *)(puVar29 + -8) = 0x102812;
      lVar39 = func_0x();
      if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
        *(undefined8 *)(puVar29 + -8) = 0x10282c;
        cVar11 = func_0x(0x11b87f0);
        if (cVar11 == '\0') {
          *(undefined8 *)(puVar29 + -8) = 0x102848;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(puVar29 + 0x20) = 0;
          *(undefined8 *)(puVar29 + -8) = 0x10286e;
          (*_DAT_)(1,0xaa81fc,0xbc82e8,0x886);
        }
      }
    }
    uVar18 = *(undefined8 *)(psVar32 + 4);
    *(undefined8 *)(puVar29 + -8) = 0x10287c;
    func_0x(uVar18,0x12);
    uVar28 = *(uint *)(psVar31 + 2);
  }
  if ((uVar28 == 0) || (0x3f3c < uVar28)) {
    *(undefined8 *)(puVar29 + -8) = 0x10289b;
    cVar11 = func_0x(0x11b87f0);
    if (cVar11 != '\0') {
      *(undefined8 *)(puVar29 + -8) = 0x1028a4;
      lVar39 = func_0x();
      if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
        *(undefined8 *)(puVar29 + -8) = 0x1028be;
        cVar11 = func_0x(0x11b87f0);
        if (cVar11 == '\0') {
          *(undefined8 *)(puVar29 + -8) = 0x1028da;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(puVar29 + 0x20) = 0;
          *(undefined8 *)(puVar29 + -8) = 0x102900;
          (*_DAT_)(1,0xaa81fc,0xbc82e8,0x88b);
        }
      }
    }
    uVar18 = *(undefined8 *)(psVar32 + 4);
    *(undefined8 *)(puVar29 + -8) = 0x10290e;
    func_0x(uVar18,5);
    uVar28 = *(uint *)(psVar31 + 2);
  }
code_r0x00102911:
  if ((uVar28 < 9) &&
     (((**(byte **)(psVar32 + 4) & 0xe) == 0 || ((**(byte **)(psVar32 + 4) & 0xe) == 0xc)))) {
    uVar28 = 9;
  }
  puVar38 = *(uint **)(&stack0x00000050 + lVar17);
  *(uint *)((longlong)&uStackX_24 + lVar17) = uVar28;
  goto code_r0x00100afd;
code_r0x00101c2a:
  pbVar26 = *(byte **)(psVar31 + 4);
  uVar24 = (ulonglong)*(uint *)(psVar31 + 2);
code_r0x00101d9d:
  if ((*pbVar26 & 0x40) == 0) {
    *(undefined4 *)(psVar32 + 0x13) = 0;
  }
  else {
    *(int *)(psVar32 + 0x13) = (int)uVar24;
    *(int *)(psVar32 + 2) = (int)uVar24 + 0xe;
    *(undefined8 *)(puVar29 + -8) = 0x101db5;
    uVar18 = func_0x(puVar3);
    *(undefined8 *)(puVar29 + -8) = 0x101dc4;
    func_0x(uVar18,&stack0x000000d0 + lVar17);
    *(undefined8 *)(puVar29 + -8) = 0x101dd0;
    iVar15 = func_0x(&stack0x000000d0 + lVar17);
    *(int *)(psVar32 + 2) = *(int *)(psVar32 + 2) + iVar15;
    uVar24 = (ulonglong)*(uint *)(psVar32 + 2);
  }
  iVar15 = (int)uVar24;
  if ((*(ulonglong *)(psVar32 + 0xf) != 0) &&
     (*(ulonglong *)(psVar32 + 0xf) < uVar24 + *(longlong *)(psVar32 + 4))) {
    *(undefined8 *)(puVar29 + -8) = 0x101e09;
    cVar11 = func_0x(0x11b87f0);
    if (cVar11 != '\0') {
      *(undefined8 *)(puVar29 + -8) = 0x101e12;
      lVar39 = func_0x();
      if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
        *(undefined8 *)(puVar29 + -8) = 0x101e2c;
        cVar11 = func_0x(0x11b87f0);
        if (cVar11 == '\0') {
          *(undefined8 *)(puVar29 + -8) = 0x101e48;
          (*_DAT_)(0x22,0x44,0x15,0x3fa);
        }
        else {
          *(undefined8 *)(puVar29 + 0x20) = 0;
          *(undefined8 *)(puVar29 + -8) = 0x101e6e;
          (*_DAT_)(1,0xaa81fc,0xbc82e8,0x886);
        }
      }
    }
    uVar18 = *(undefined8 *)(psVar32 + 4);
    *(undefined8 *)(puVar29 + -8) = 0x101e7c;
    func_0x(uVar18,0x12);
    iVar15 = *(int *)(psVar31 + 2);
  }
  if (0x3f3b < iVar15 - 1U) {
    *(undefined8 *)(puVar29 + -8) = 0x101e95;
    cVar11 = func_0x(0x11b87f0);
    if (cVar11 != '\0') {
      *(undefined8 *)(puVar29 + -8) = 0x101e9e;
      lVar39 = func_0x();
      if ((lVar39 != 0) && (*(char *)(lVar39 + 0x499) != '\0')) {
        *(undefined8 *)(puVar29 + -8) = 0x101eb8;
        cVar11 = func_0x(0x11b87f0);
        if (cVar11 == '\0') {
          *(undefined8 *)(puVar29 + -8) = 0x101ed4;
          (*_DAT_)(0x22,0x44,0x15,0x3ed);
        }
        else {
          *(undefined8 *)(puVar29 + 0x20) = 0;
          *(undefined8 *)(puVar29 + -8) = 0x101efa;
          (*_DAT_)(1,0xaa81fc,0xbc82e8,0x88b);
        }
      }
    }
    uVar18 = *(undefined8 *)(psVar32 + 4);
    *(undefined8 *)(puVar29 + -8) = 0x101f08;
    func_0x(uVar18,5);
  }
code_r0x00101f08:
  *(undefined8 *)(puVar29 + -8) = 0x101f10;
  iVar15 = func_0x(puVar3);
  puVar38 = *(uint **)(&stack0x00000050 + lVar17);
  if (iVar15 == 0) {
    *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 0;
    puVar19 = puVar23;
  }
  else {
    *(undefined8 *)(puVar29 + -8) = 0x101f2c;
    puVar19 = (uint *)func_0x(psVar32 + 0x15,puVar38,(longlong)&uStackX_24 + lVar17,
                                      &stack0x00000038 + lVar17);
  }
  if (*(int *)((longlong)&uStackX_24 + lVar17) != 0) {
code_r0x00101f87:
    puVar40 = puVar19;
    if (*(int *)(*(longlong *)(puVar38 + 0x12) + 0x10) == 10) goto code_r0x00100afd;
    puVar34 = *(undefined **)(&stack0x00000048 + lVar17);
    if ((*(int *)(*(longlong *)(puVar38 + 0x12) + 0x10) == 9) && (puVar34 == (undefined *)0x0)) {
      puVar34 = &stack0x00000100 + lVar17;
      *(undefined **)(&stack0x00000048 + lVar17) = puVar34;
      *(undefined4 *)(&stack0x00000100 + lVar17) = *(undefined4 *)(&stack0x00000034 + lVar17);
      *(undefined4 *)(&stack0x00000120 + lVar17) = 0x1f9e;
      *(undefined **)(&stack0x00000118 + lVar17) = &stack0x00000124 + lVar17;
      *(undefined8 *)(puVar29 + -8) = 0x101ff3;
      lVar39 = func_0x();
      lVar39 = -lVar39;
      puVar30 = puVar29 + lVar39;
      *(undefined **)(&stack0x00000108 + lVar17) = puVar29 + lVar39 + 0x60;
      *(undefined8 *)(puVar29 + lVar39 + -8) = 0x102009;
      func_0x(puVar29 + lVar39 + 0x60,0);
    }
    uVar28 = *(uint *)((longlong)&uStackX_24 + lVar17);
    (&stack0x00000030)[lVar17] = 0;
    lVar39 = *(longlong *)(&stack0x00000040 + lVar17);
    puVar35 = (undefined4 *)
              (*(longlong *)(&stack0x00000078 + lVar17) * 0x50 + *(longlong *)(lVar39 + 0x10));
    switch(*(undefined4 *)(*(longlong *)(puVar35 + 0x12) + 0x10)) {
    case 2:
code_r0x001020df:
      lVar39 = (ulonglong)*(uint *)(puVar34 + 4) * 0x40;
      pbVar26 = (byte *)(*(longlong *)(puVar34 + 8) + 0x18 + lVar39);
      *pbVar26 = *pbVar26 & 0xfb;
      if (*(uint *)(puVar34 + 0x20) < *(int *)(puVar34 + 0x10) + uVar28) {
        lVar33 = (ulonglong)*puRam00000000007263e0 +
                 *(longlong *)
                  (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*puRam00000000007263d8 * 8);
        lVar27 = *(longlong *)(lVar33 + 0x100);
        if (lVar27 == 0) {
          *(undefined8 *)(puVar30 + -8) = 0x102131;
          (*pcRam00000000007263f0)(0);
          lVar27 = *(longlong *)(lVar33 + 0x100);
        }
        puVar30[0x20] = 5;
        uVar18 = *(undefined8 *)(lVar27 + 1000);
        *(undefined8 *)(puVar30 + -8) = 0x10215c;
        puVar40 = (uint *)(*pcRam0000000000726348)(0x1f9e,uVar18,0xbc6858,0xda);
        if (puVar40 != (uint *)0x0) {
          *(undefined8 *)(puVar30 + -8) = 0x102174;
          func_0x(puVar40,0,0x1f9e);
          puVar23 = puVar40;
        }
        puVar34 = *(undefined **)(&stack0x00000048 + lVar17);
        *(uint **)(puVar34 + 0x18) = puVar23;
        *(undefined4 *)(puVar34 + 0x10) = 0;
        pbVar26 = (byte *)(*(longlong *)(puVar34 + 8) + 0x18 + lVar39);
        *pbVar26 = *pbVar26 | 4;
        *(undefined4 *)(puVar34 + 0x20) = 0x1f9e;
      }
      uVar14 = puVar35[1];
      uVar8 = puVar35[2];
      uVar9 = puVar35[3];
      puVar2 = (undefined4 *)(*(longlong *)(puVar34 + 8) + 8 + lVar39);
      *puVar2 = *puVar35;
      puVar2[1] = uVar14;
      puVar2[2] = uVar8;
      puVar2[3] = uVar9;
      *(undefined4 *)(lVar39 + *(longlong *)(puVar34 + 8)) =
           *(undefined4 *)(&stack0x0000003c + lVar17);
      pbVar26 = (byte *)(*(longlong *)(puVar34 + 8) + 0x18 + lVar39);
      *pbVar26 = *pbVar26 & 0xfe;
      pbVar26 = (byte *)(*(longlong *)(puVar34 + 8) + 0x18 + lVar39);
      *pbVar26 = *pbVar26 & 0xfd;
      lVar39 = *(longlong *)(puVar34 + 8) + lVar39;
      *(ulonglong *)(lVar39 + 0x20) =
           (ulonglong)*(uint *)(puVar34 + 0x10) + *(longlong *)(puVar34 + 0x18);
      uVar16 = *(uint *)(&stack0x00000038 + lVar17);
      uVar42 = *(uint *)(lVar39 + 0x2c);
      *(uint *)(lVar39 + 0x28) = uVar28;
      *(uint *)(lVar39 + 0x2c) = uVar42 & 0xfffffffa | uVar16 & 1;
      uVar14 = puVar35[1];
      uVar8 = puVar35[2];
      uVar9 = puVar35[3];
      *(undefined4 *)(lVar39 + 0x30) = *puVar35;
      *(undefined4 *)(lVar39 + 0x34) = uVar14;
      *(undefined4 *)(lVar39 + 0x38) = uVar8;
      *(undefined4 *)(lVar39 + 0x3c) = uVar9;
      *(uint *)(lVar39 + 0x2c) = uVar42 & 0xfffffff0 | uVar16 & 1;
      uVar16 = *(uint *)(puVar34 + 0x10);
      iVar15 = *(int *)(puVar34 + 0x20);
      lVar39 = *(longlong *)(puVar34 + 0x18);
      *(undefined8 *)(puVar30 + -8) = 0x10220e;
      func_0x((ulonglong)uVar16 + lVar39,iVar15 - uVar16,puVar19,uVar28);
      *(int *)(puVar34 + 4) = *(int *)(puVar34 + 4) + 1;
      *(uint *)(puVar34 + 0x10) = *(int *)(puVar34 + 0x10) + uVar28;
      break;
    case 3:
    case 4:
    case 5:
      uVar18 = *(undefined8 *)(*(longlong *)(&stack0x00000090 + lVar17) + 0x18);
      *(undefined8 *)(puVar30 + -8) = 0x102d90;
      func_0x(uVar18);
      *(undefined8 *)(puVar30 + -8) = 0x102d95;
      func_0x();
      pcVar5 = (code *)swi(3);
      (*pcVar5)();
      return;
    case 6:
      *(undefined8 *)(puVar30 + -8) = 0x102d9b;
      func_0x();
      pcVar5 = (code *)swi(3);
      (*pcVar5)();
      return;
    case 9:
      if (*(int *)(&stack0x00000038 + lVar17) != 0) goto code_r0x001020df;
      if (*(ushort *)(puVar35 + 0xf) < uVar28) {
        uVar14 = *(undefined4 *)(*(longlong *)(puVar35 + 0x12) + 4);
        uVar18 = **(undefined8 **)
                   (*(longlong *)
                     (*(longlong *)(**(longlong **)(&stack0x00000090 + lVar17) + 0x58) + 8) + 0x160)
        ;
        *(undefined8 *)(puVar30 + -8) = 0x102082;
        lVar27 = func_0x(uVar18,uVar14);
        if ((*(byte *)(lVar27 + 0x34) != 0xf1) &&
           ((*(char *)((ulonglong)*(byte *)((ulonglong)*(byte *)(lVar27 + 0x34) + 0x82d4b0) +
                      0x13b4298) == '\0' || (*(short *)(lVar27 + 0x38) != -1)))) {
          *(undefined8 *)(puVar30 + -8) = 0x1020c7;
          (*_DAT_)(6,0x52,0x16,0x8f);
        }
      }
      *(uint *)(puVar30 + 0x20) = uVar28;
      *(undefined8 *)(puVar30 + -8) = 0x1020da;
      func_0x(lVar39);
    }
    lVar39 = -0x1cf6dd0;
    cVar11 = *pcVar1 != '\0';
    *pcVar1 = cVar11;
    psVar32 = *(short **)(&stack0x00000028 + lVar17);
    param_3 = *(longlong *)(&stack0x00000048 + lVar17);
    param_1 = *(undefined8 **)(&stack0x00000090 + lVar17);
    uVar28 = *(uint *)(&stack0x00000034 + lVar17);
    uVar36 = *(ulonglong *)(&stack0x00000078 + lVar17);
    goto code_r0x00102b34;
  }
  puVar40 = puVar19;
  if (puVar19 == (uint *)0x0) {
code_r0x00100afd:
    param_2 = *(longlong **)(&stack0x00000040 + lVar17);
  }
  else {
    if ((*(int *)(*(longlong *)(puVar38 + 0x12) + 0x10) != 10) ||
       ((*(ushort *)(*(longlong *)(puVar38 + 0x12) + 0xc) & 0x800) != 0)) {
code_r0x00101f6a:
      if ((puVar38[0x10] & 0x2000) == 0) goto code_r0x00101f87;
      *(undefined4 *)((longlong)&uStackX_24 + lVar17) = 4;
      puVar40 = (uint *)0x890420;
      goto code_r0x00100afd;
    }
    param_2 = *(longlong **)(&stack0x00000040 + lVar17);
  }
code_r0x00100b07:
  uVar28 = puVar38[0x10];
  if (((uVar28 >> 10 & 1) != 0) && (puVar40 == (uint *)0x0)) {
    *(undefined8 *)
     (*(longlong *)(*(longlong *)(*param_2 + 0x18) + (ulonglong)puVar38[10] * 8) +
     (longlong)*(int *)(*param_2 + 0x40) * 8) = 1;
    uVar28 = puVar38[0x10];
  }
  if ((uVar28 >> 9 & 1) != 0) {
    if ((uVar28 & 0x800) == 0) {
      if ((uint)*(ushort *)(puVar38 + 0xf) < *(uint *)((longlong)&uStackX_24 + lVar17)) {
        *(undefined8 *)(puVar29 + -8) = 0x100b6c;
        (*_DAT_)(6,0x52,0x16,0x95);
      }
    }
    else {
      **(undefined4 **)(&stack0x000000e0 + lVar17) = 1;
    }
    *(undefined4 *)(puVar29 + 0x20) = *(undefined4 *)((longlong)&uStackX_24 + lVar17);
    *(undefined8 *)(puVar29 + -8) = 0x102b14;
    func_0x(param_2);
  }
  uVar36 = *(ulonglong *)(&stack0x00000078 + lVar17);
  uVar28 = *(uint *)(&stack0x00000034 + lVar17);
  param_1 = *(undefined8 **)(&stack0x00000090 + lVar17);
  param_3 = *(longlong *)(&stack0x00000048 + lVar17);
  psVar32 = *(short **)(&stack0x00000028 + lVar17);
code_r0x00102b28:
  lVar39 = -0x1cf6dd0;
code_r0x00102b2f:
  cVar11 = *pcVar1;
code_r0x00102b34:
  uVar16 = *(int *)(&stack0x0000003c + lVar17) + 1;
  *(uint *)(&stack0x0000003c + lVar17) = uVar16;
  uVar36 = uVar36 + 1;
  *(ulonglong *)(&stack0x00000078 + lVar17) = uVar36;
  puVar38 = puVar38 + 0x14;
  *(uint **)(&stack0x00000050 + lVar17) = puVar38;
  param_2 = *(longlong **)(&stack0x00000040 + lVar17);
  if (uVar28 <= uVar16) goto LAB_;
  uVar24 = (ulonglong)uVar16;
  puVar29 = puVar30;
  goto LAB_;
LAB_:
  lVar27 = param_1[1];
  goto LAB_;
}

