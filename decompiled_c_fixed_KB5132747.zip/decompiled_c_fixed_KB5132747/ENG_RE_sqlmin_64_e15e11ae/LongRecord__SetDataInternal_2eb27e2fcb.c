
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong *param_2,undefined4 param_3,undefined8 param_4)

{
  byte *pbVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  int iVar9;
  longlong lVar10;
  longlong lVar11;
  uint uVar12;
  undefined8 unaff_RBX;
  undefined8 uVar13;
  undefined *puVar14;
  undefined *puVar15;
  undefined *puVar16;
  longlong *plVar17;
  longlong *plVar18;
  longlong *plVar19;
  longlong unaff_GS_OFFSET;
  undefined8 uStack_50;
  undefined auStack_48 [8];
  undefined8 uStack_40;
  
  uStack_40 = 0x100016;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  puVar14 = &stack0xffffffffffffffc8 + lVar10;
  puVar16 = &stack0xffffffffffffffc8 + lVar10;
  puVar2 = &stack0x000000b8 + lVar10;
  *(undefined8 *)(&stack0x00000170 + lVar10) = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00004198 + lVar10) = unaff_RBX;
  *(ulonglong *)(&stack0x00004138 + lVar10) = _DAT_ ^ (ulonglong)puVar2;
  *(undefined8 *)(&stack0x00000128 + lVar10) = param_4;
  *(undefined4 *)(&stack0x00000140 + lVar10) = param_3;
  *(longlong **)(&stack0x00000120 + lVar10) = param_2;
  *(longlong **)(&stack0x00000168 + lVar10) = param_1;
  *(undefined8 *)(&stack0x00000148 + lVar10) = *(undefined8 *)(&stack0x000041a8 + lVar10);
  uVar13 = *(undefined8 *)(&stack0x000041c8 + lVar10);
  *(undefined8 *)(&stack0x000000c8 + lVar10) = uVar13;
  plVar18 = (longlong *)0x0;
  *(undefined8 *)(&stack0x000000c0 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000d8 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000130 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000dc + lVar10) = 0;
  *(undefined8 *)(&stack0x00000158 + lVar10) = 0;
  *(undefined8 *)(&stack0x00000198 + lVar10) = 0;
  *(undefined8 *)(&stack0x000001a0 + lVar10) = 0;
  *(undefined4 *)(&stack0x000001a8 + lVar10) = 0;
  *(undefined8 *)(&stack0x000001b0 + lVar10) = 0;
  *(undefined4 *)(&stack0x000001b8 + lVar10) = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar10) = 0x1000ca;
  func_0x(&stack0x000001bc + lVar10,0,0x1f9e);
  *(undefined4 *)(&stack0x000000e8 + lVar10) = 1;
  *(undefined4 *)(&stack0x000000f0 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000e0 + lVar10) = 0;
  lVar5 = *param_2;
  *(longlong *)(&stack0x00000160 + lVar10) = lVar5 + 0x78;
  *(undefined8 *)(&stack0x00000150 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000e4 + lVar10) = 0;
  *(undefined4 *)(&stack0x000000f4 + lVar10) = 0;
  lVar11 = *(longlong *)(param_1[3] + 8);
  *(uint *)(&stack0x000000f8 + lVar10) = (uint)*(ushort *)(lVar11 + 0xb8);
  *(uint *)(&stack0x000000fc + lVar10) = (uint)*(ushort *)(lVar11 + 0xcc);
  *(undefined4 *)(&stack0x000000d4 + lVar10) = **(undefined4 **)(lVar5 + 0x80);
  lVar11 = *(longlong *)(lVar5 + 0x80);
  iVar9 = *(int *)(lVar11 + 0x14);
  plVar17 = plVar18;
  if (iVar9 != 0) {
    if ((*(byte *)((longlong)param_1 + 0x34) & 3) != 0) {
      plVar17 = (longlong *)(&stack0x000000a8 + lVar10);
      *(longlong **)(&stack0x00000130 + lVar10) = plVar17;
      uVar12 = iVar9 + 7U >> 3;
      if (uVar12 + 0xf <= uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined8 *)((longlong)&uStack_50 + lVar10) = 0x100174;
      lVar11 = func_0x();
      lVar11 = -lVar11;
      puVar14 = auStack_48 + lVar11 + lVar10;
      *plVar17 = (longlong)(&stack0x000000a8 + lVar11 + lVar10);
      *(int *)(&stack0x000000b4 + lVar10) = iVar9;
      *(uint *)(&stack0x000000b0 + lVar10) = uVar12;
      *(undefined8 *)((longlong)&uStack_50 + lVar11 + lVar10) = 0x100190;
      func_0x(&stack0x000000a8 + lVar11 + lVar10,0);
      lVar11 = *(longlong *)(lVar5 + 0x80);
    }
    puVar15 = puVar14;
    plVar19 = plVar18;
    if ((*(byte *)(lVar5 + 0x90) & 1) != 0) {
      plVar19 = (longlong *)(puVar14 + 0xe0);
      *(longlong **)(&stack0x000000c0 + lVar10) = plVar19;
      iVar9 = *(int *)(lVar11 + 0x14);
      uVar12 = iVar9 + 7U >> 3;
      if (uVar12 + 0xf <= uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      *(undefined8 *)(puVar14 + -0x18) = 0x1001e1;
      lVar11 = func_0x();
      lVar11 = -lVar11;
      puVar15 = puVar14 + lVar11 + -0x10;
      *plVar19 = (longlong)(puVar14 + lVar11 + 0xe0);
      *(int *)(puVar14 + 0xec) = iVar9;
      *(uint *)(puVar14 + 0xe8) = uVar12;
      *(undefined8 *)(puVar14 + lVar11 + -0x18) = 0x1001fe;
      func_0x(puVar14 + lVar11 + 0xe0,0);
      lVar11 = *(longlong *)(lVar5 + 0x80);
    }
    iVar9 = *(int *)(lVar11 + 0x14);
    *(int *)(&stack0x00000198 + lVar10) = iVar9;
    *(undefined4 *)(&stack0x000001b8 + lVar10) = 0x1f9e;
    *(undefined **)(&stack0x000001b0 + lVar10) = &stack0x000001bc + lVar10;
    uVar12 = iVar9 << 6;
    if ((ulonglong)uVar12 + 0xf <= (ulonglong)uVar12) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *(undefined8 *)(puVar15 + -8) = 0x100240;
    lVar11 = func_0x();
    lVar11 = -lVar11;
    puVar16 = puVar15 + lVar11;
    *(undefined **)(&stack0x000001a0 + lVar10) = puVar15 + lVar11 + 0xf0;
    *(undefined8 *)(puVar15 + lVar11 + -8) = 0x100259;
    func_0x(puVar15 + lVar11 + 0xf0,0);
    *(undefined4 *)(puVar15 + lVar11 + 0x30) = *(undefined4 *)(&stack0x000041c0 + lVar10);
    *(undefined **)(puVar15 + lVar11 + 0x28) = &stack0x000000e8 + lVar10;
    *(longlong **)(puVar15 + lVar11 + 0x20) = plVar19;
    uVar3 = *(undefined4 *)(param_1 + 2);
    *(undefined8 *)(puVar15 + lVar11 + -8) = 0x100287;
    func_0x(param_1,param_2,uVar3,&stack0x00000198 + lVar10);
    if (*(int *)(&stack0x000000e8 + lVar10) == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    uVar13 = *(undefined8 *)(&stack0x000000c8 + lVar10);
  }
  pbVar1 = (byte *)((longlong)param_1 + 0x34);
  if (((*pbVar1 & 3) != 0) &&
     ((lVar11 = *(longlong *)(*(longlong *)(*param_1 + 0x58) + 8), *(char *)(lVar11 + 0x41) < '\0'
      || ((*(byte *)(lVar11 + 0x109) & 1) != 0)))) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  uVar6 = *(undefined8 *)(&stack0x00000120 + lVar10);
  lVar5 = *(longlong *)(lVar5 + 0x80);
  uVar7 = *(undefined8 *)(lVar5 + 0x18);
  uVar3 = *(undefined4 *)(lVar5 + 0x14);
  lVar11 = param_1[1];
  *(undefined4 *)(puVar16 + 0xe8) = 0;
  *(undefined8 *)(puVar16 + 0xe0) = 0;
  *(undefined8 *)(puVar16 + 0xd8) = 0;
  *(undefined **)(puVar16 + 0xd0) = &stack0x000000e0 + lVar10;
  *(undefined4 *)(puVar16 + 200) = *(undefined4 *)(&stack0x000041c0 + lVar10);
  *(undefined **)(puVar16 + 0xc0) = &stack0x00000178 + lVar10;
  *(undefined **)(puVar16 + 0xb8) = &stack0x000000dc + lVar10;
  *(undefined8 *)(puVar16 + 0xb0) = 0;
  *(undefined4 *)(puVar16 + 0xa8) = 0;
  *(undefined **)(puVar16 + 0xa0) = puVar2;
  *(undefined8 *)(puVar16 + 0x98) = uVar13;
  *(undefined4 *)(puVar16 + 0x90) = *(undefined4 *)(&stack0x000041b8 + lVar10);
  *(undefined4 *)(puVar16 + 0x88) = *(undefined4 *)(&stack0x000041b0 + lVar10);
  *(undefined8 *)(puVar16 + 0x80) = *(undefined8 *)(&stack0x00000148 + lVar10);
  *(undefined8 *)(puVar16 + 0x78) = *(undefined8 *)(&stack0x00000128 + lVar10);
  *(undefined **)(puVar16 + 0x70) = &stack0x000000d8 + lVar10;
  *(longlong **)(puVar16 + 0x68) = plVar17;
  *(undefined **)(puVar16 + 0x60) = &stack0x00000198 + lVar10;
  *(undefined8 *)(puVar16 + 0x58) = 0;
  *(undefined8 *)(puVar16 + 0x50) = 0;
  *(undefined8 *)(puVar16 + 0x48) = uVar6;
  *(undefined8 *)(puVar16 + 0x40) = *(undefined8 *)(lVar11 + 0x10);
  *(undefined8 *)(puVar16 + 0x38) = *(undefined8 *)(lVar11 + 8);
  *(undefined4 *)(puVar16 + 0x30) = *(undefined4 *)(&stack0x000000f8 + lVar10);
  *(undefined4 *)(puVar16 + 0x28) = *(undefined4 *)(&stack0x000000fc + lVar10);
  *(undefined4 *)(puVar16 + 0x20) = *(undefined4 *)(&stack0x000000d4 + lVar10);
  uVar4 = *(undefined4 *)(lVar5 + 0xc);
  *(undefined8 *)(puVar16 + -8) = 0x1003d3;
  iVar9 = func_0x(param_1,uVar3,uVar7,uVar4);
  if (iVar9 == 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if ((DAT_ & 1) == 0) {
    lVar5 = *(longlong *)
             ((ulonglong)*_DAT_ +
             *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8));
    if ((lVar5 != 0) && (**(longlong **)(lVar5 + 0x38) != 0)) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*(uint *)(param_1[3] + 0x14) & 0xe0000000) == 0x80000000) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if ((*pbVar1 & 2) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if ((*pbVar1 & 3) != 0) {
    if (*(int *)(&stack0x000000d8 + lVar10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(&stack0x000000dc + lVar10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(&stack0x000041c0 + lVar10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    if (*(int *)(&stack0x000000e4 + lVar10) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  if ((*(longlong *)(&stack0x000001a0 + lVar10) != 0) && (*(uint *)(&stack0x00000198 + lVar10) != 0)
     ) {
    do {
      if ((*(byte *)(*(longlong *)(&stack0x000001a0 + lVar10) + 0x18 + (longlong)plVar18 * 0x40) & 4
          ) != 0) {
                    /* WARNING: Bad instruction - Truncating control flow here */
        halt_baddata();
      }
      uVar12 = (int)plVar18 + 1;
      plVar18 = (longlong *)(ulonglong)uVar12;
    } while (uVar12 < *(uint *)(&stack0x00000198 + lVar10));
  }
  uVar8 = *(ulonglong *)(&stack0x00004138 + lVar10);
  *(undefined8 *)(puVar16 + -8) = 0x1004c6;
  func_0x(uVar8 ^ (ulonglong)puVar2);
  return;
}

