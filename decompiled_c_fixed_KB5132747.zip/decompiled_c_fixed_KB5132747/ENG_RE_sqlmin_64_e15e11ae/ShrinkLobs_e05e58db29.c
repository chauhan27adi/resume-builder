
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong *param_1,longlong param_2,longlong param_3,longlong *param_4,
                 longlong param_5,undefined4 param_6,longlong param_7,longlong *param_8)

{
  longlong *plVar1;
  short *psVar2;
  uint uVar3;
  longlong lVar4;
  uint *puVar5;
  ushort *puVar6;
  byte bVar7;
  bool bVar8;
  double dVar9;
  char cVar10;
  ushort uVar11;
  ushort uVar12;
  int iVar13;
  short *psVar14;
  longlong lVar15;
  undefined8 uVar16;
  ulonglong *puVar17;
  ulonglong uVar18;
  longlong lVar19;
  byte *pbVar20;
  ulonglong uVar21;
  longlong lVar22;
  uint uVar23;
  uint uVar24;
  longlong lVar25;
  longlong lVar26;
  ulonglong uVar27;
  uint uVar28;
  byte bVar29;
  short sVar30;
  ushort uVar31;
  uint uVar32;
  longlong *plVar33;
  uint uVar34;
  longlong lVar35;
  uint uVar36;
  longlong *plVar37;
  ushort *puVar38;
  int iVar39;
  int iVar40;
  ulonglong uVar41;
  ushort *puVar42;
  longlong **pplVar43;
  longlong unaff_GS_OFFSET;
  bool bVar44;
  undefined auStack_138 [32];
  undefined *puStack_118;
  char cStack_108;
  short sStack_106;
  undefined4 uStack_104;
  longlong *plStack_100;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  longlong lStack_f0;
  undefined *puStack_e8;
  longlong *plStack_e0;
  longlong lStack_d8;
  longlong *plStack_d0;
  longlong lStack_c8;
  undefined auStack_c0 [8];
  undefined auStack_b8 [2];
  undefined2 uStack_b6;
  undefined2 uStack_aa;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [12];
  undefined4 uStack_94;
  undefined auStack_90 [16];
  ulonglong uStack_80;
  undefined auStack_78 [16];
  ulonglong uStack_68;
  
  uStack_68 = _DAT_ ^ (ulonglong)auStack_138;
  cVar10 = *(char *)(param_4[6] + 0x1cde);
  sStack_106 = *(short *)(*(longlong *)(param_3 + 8) + 200);
  lStack_d8 = param_5;
  plStack_100 = param_8;
  cStack_108 = cVar10;
  lStack_f0 = param_3;
  plStack_e0 = param_1;
  plStack_d0 = param_4;
  lStack_c8 = param_2;
  psVar14 = (short *)(**(code **)*param_1)();
  uVar18 = 0;
  uStack_104 = 0x7fff;
  sVar30 = *psVar14;
  *(short *)param_8 = sVar30;
  if (sVar30 == 0) {
    uVar23 = *(uint *)(psVar14 + 2);
    psVar2 = (short *)((longlong)param_8 + 2);
    if (uVar23 == 0) {
      uVar23 = *(uint *)(psVar14 + 8);
      uVar41 = (ulonglong)uVar23;
      pbVar20 = *(byte **)(psVar14 + 4);
      psVar14[1] = 0;
      *(uint *)(psVar14 + 10) = uVar23;
      bVar29 = *pbVar20;
      if ((bVar29 & 0x10) != 0) {
        uVar23 = uVar23 + 2 + (*(ushort *)(pbVar20 + uVar41) + 7 >> 3);
        uVar41 = (ulonglong)uVar23;
        *(uint *)(psVar14 + 10) = uVar23;
        bVar29 = *pbVar20;
      }
      if ((bVar29 & 0x20) == 0) {
        *(int *)(psVar14 + 2) = (int)uVar41;
        psVar14[0xe] = 0;
        *(int *)(psVar14 + 0xc) = (int)uVar41;
      }
      else {
        puVar38 = (ushort *)(pbVar20 + uVar41);
        uVar31 = *puVar38;
        psVar14[0xe] = uVar31;
        if (uVar31 == 0) {
          cVar10 = func_0x(0x11bda20);
          if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
             (*(char *)(lVar15 + 0x499) != '\0')) {
            cVar10 = func_0x(0x11bda20);
            if (cVar10 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xaad42c,0xbcd518,0x80f);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),3);
          uVar31 = psVar14[0xe];
          uVar41 = (ulonglong)*(uint *)(psVar14 + 10);
          pbVar20 = *(byte **)(psVar14 + 4);
        }
        uVar23 = (int)uVar41 + (uVar31 + 1) * 2;
        *(uint *)(psVar14 + 0xc) = uVar23;
        if (0x1f9e < uVar23) {
          cVar10 = func_0x(0x11bda20);
          if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
             (*(char *)(lVar15 + 0x499) != '\0')) {
            cVar10 = func_0x(0x11bda20);
            if (cVar10 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xaad42c,0xbcd518,0x816);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),4);
          uVar31 = psVar14[0xe];
          uVar23 = *(uint *)(psVar14 + 0xc);
          pbVar20 = *(byte **)(psVar14 + 4);
        }
        uVar21 = (ulonglong)uVar31;
        uVar24 = puVar38[uVar21] & 0x7fff;
        *(uint *)(psVar14 + 2) = uVar24;
        if (uVar24 < uVar23) {
          cVar10 = func_0x(0x11bda20);
          if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
             (*(char *)(lVar15 + 0x499) != '\0')) {
            cVar10 = func_0x(0x11bda20);
            if (cVar10 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xaad42c,0xbcd518,0x81d);
            }
          }
          func_0x(*(undefined8 *)(psVar14 + 4),4);
          uVar23 = *(uint *)(psVar14 + 0xc);
          uVar21 = (ulonglong)(ushort)psVar14[0xe];
          uVar24 = *(uint *)(psVar14 + 2);
          pbVar20 = *(byte **)(psVar14 + 4);
        }
        puVar42 = puVar38;
        if ((short)uVar21 != 0) {
          do {
            uVar24 = puVar42[1] & 0x7fff;
            if ((uVar24 < uVar23) || (*(uint *)(psVar14 + 2) < uVar24)) {
              cVar10 = func_0x(0x11bda20);
              if ((cVar10 != '\0') &&
                 ((lVar15 = func_0x(), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                cVar10 = func_0x(0x11bda20);
                if (cVar10 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xaad42c,0xbcd518,0x82a);
                }
              }
              func_0x(*(undefined8 *)(psVar14 + 4),4);
            }
            uVar21 = (ulonglong)(ushort)psVar14[0xe];
            uVar36 = (int)uVar18 + 1;
            uVar18 = (ulonglong)uVar36;
            uVar23 = uVar24;
            puVar42 = puVar42 + 1;
          } while ((int)uVar36 < (int)(uint)(ushort)psVar14[0xe]);
          pbVar20 = *(byte **)(psVar14 + 4);
          uVar24 = *(uint *)(psVar14 + 2);
        }
        uVar41 = (ulonglong)uVar24;
        uVar18 = uVar21;
        if ((short)puVar38[(ulonglong)((int)uVar21 - 1) + 1] < 0) {
LAB_:
          sVar30 = (short)uVar21;
          uVar31 = *(ushort *)(pbVar20 + uVar18 * 2 + (ulonglong)*(uint *)(psVar14 + 10));
          if ((int)uVar18 == 1) {
            uVar24 = *(uint *)(psVar14 + 0xc);
            uVar36 = uVar24;
LAB_:
            uVar28 = uVar31 & 0x7fff;
            if ((uVar28 < uVar24) || (uVar23 = *(uint *)(psVar14 + 2), uVar23 < uVar28))
            goto LAB_;
          }
          else {
            uVar36 = *(uint *)(psVar14 + 0xc);
            uVar24 = *(ushort *)(pbVar20 + uVar18 * 2 + ((ulonglong)*(uint *)(psVar14 + 10) - 2)) &
                     0x7fff;
            if (uVar36 <= uVar24) goto LAB_;
LAB_:
            func_0x(pbVar20,7);
            uVar36 = *(uint *)(psVar14 + 0xc);
            uVar23 = *(uint *)(psVar14 + 2);
            pbVar20 = *(byte **)(psVar14 + 4);
            sVar30 = psVar14[0xe];
          }
          uVar41 = (ulonglong)uVar23;
          if ((uVar36 <= uVar24) && (uVar24 <= uVar23)) {
            if (*(ushort *)(pbVar20 + uVar24) == 5) {
              psVar14[1] = psVar14[1] | 2;
              psVar14[0xe] = sVar30 + -1;
              uVar41 = *(ulonglong *)(psVar14 + 4);
              uVar21 = (ulonglong)(uVar24 & 0xffff);
              uVar18 = uVar21 + uVar41;
              psVar14[0x15] = (short)uVar24;
              uVar11 = psVar14[0x16] & 0xc7ffU;
              if ((*(ushort *)(uVar18 + 2) & 0x4000) != 0) {
                uVar11 = *(ushort *)(uVar18 + 2) & 0x3800 | psVar14[0x16] & 0xc7ffU;
              }
              psVar14[0x16] = uVar11;
              uVar12 = (uVar11 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar11;
              psVar14[0x16] = uVar12;
              uVar27 = (ulonglong)((uVar12 & 0x7ff) * 2) + 4 + uVar41 + (uVar11 >> 0xb & 7) * 2 +
                       uVar21;
              if (uVar27 < uVar18) {
                func_0x(uVar18,0x19);
                uVar12 = psVar14[0x16];
                uVar21 = (ulonglong)(ushort)psVar14[0x15];
                uVar41 = (ulonglong)*(uint *)(psVar14 + 4);
              }
              if ((uVar31 & 0x7fff) - uVar24 <
                  (((uVar12 & 0x7ff) * 2 - (int)uVar21) - (int)uVar41) + (int)uVar27) {
                func_0x(uVar21 + *(longlong *)(psVar14 + 4),0x19);
                uVar12 = psVar14[0x16];
              }
              if ((uVar12 & 0x3800) != 0) {
                puVar38 = (ushort *)
                          (*(longlong *)(psVar14 + 4) + (ulonglong)(ushort)psVar14[0x15] + 4);
                iVar13 = 0;
                if ((uVar12 & 0x3800) != 0) {
                  do {
                    if ((uVar12 & 0x7ff) < (*puVar38 & 0x7ff)) {
                      func_0x((ulonglong)(ushort)psVar14[0x15] + *(longlong *)(psVar14 + 4),
                                      0x1a);
                      uVar12 = psVar14[0x16];
                    }
                    iVar13 = iVar13 + 1;
                    puVar38 = puVar38 + 1;
                  } while (iVar13 < (int)(uVar12 >> 0xb & 7));
                }
              }
              pbVar20 = *(byte **)(psVar14 + 4);
              uVar41 = (ulonglong)*(uint *)(psVar14 + 2);
            }
            else if (0x3ff < *(ushort *)(pbVar20 + uVar24)) {
              psVar14[1] = psVar14[1] | 1;
              uVar31 = sVar30 - 1;
              psVar14[0xe] = uVar31;
              if (uVar31 != 0) goto code_r0x0010047c;
            }
            goto LAB_;
          }
          goto LAB_;
        }
      }
LAB_:
      if ((*pbVar20 & 0x40) == 0) {
        *(undefined4 *)(psVar14 + 0x13) = 0;
      }
      else {
        *(int *)(psVar14 + 0x13) = (int)uVar41;
        *(int *)(psVar14 + 2) = (int)uVar41 + 0xe;
        uVar16 = func_0x(psVar14 + 1);
        func_0x(uVar16,auStack_c0);
        iVar13 = func_0x(auStack_c0);
        *(int *)(psVar14 + 2) = *(int *)(psVar14 + 2) + iVar13;
        uVar41 = (ulonglong)*(uint *)(psVar14 + 2);
        pbVar20 = *(byte **)(psVar14 + 4);
      }
      if ((*(byte **)(psVar14 + 0xf) != (byte *)0x0) &&
         (*(byte **)(psVar14 + 0xf) < pbVar20 + uVar41)) {
        cVar10 = func_0x(0x11bda20);
        if ((cVar10 != '\0') &&
           ((lVar15 = func_0x(), lVar15 != 0 && (*(char *)(lVar15 + 0x499) != '\0'))
           )) {
          cVar10 = func_0x(0x11bda20);
          if (cVar10 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_118 = (undefined *)0x0;
            (*_DAT_)(1,0xaad42c,0xbcd518,0x886);
          }
        }
        func_0x(*(undefined8 *)(psVar14 + 4),0x12);
        uVar41 = (ulonglong)*(uint *)(psVar14 + 2);
      }
      uVar23 = (uint)uVar41;
      if ((uVar23 == 0) || (0x3f3c < uVar23)) {
        cVar10 = func_0x(0x11bda20);
        if ((cVar10 != '\0') &&
           ((lVar15 = func_0x(), lVar15 != 0 && (*(char *)(lVar15 + 0x499) != '\0'))
           )) {
          cVar10 = func_0x(0x11bda20);
          if (cVar10 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_118 = (undefined *)0x0;
            (*_DAT_)(1,0xaad42c,0xbcd518,0x88b);
          }
        }
        func_0x(*(undefined8 *)(psVar14 + 4),5);
        uVar23 = *(uint *)(psVar14 + 2);
      }
    }
LAB_:
    if ((uVar23 < 9) &&
       (((**(byte **)(psVar14 + 4) & 0xe) == 0 || ((**(byte **)(psVar14 + 4) & 0xe) == 0xc)))) {
      uVar23 = 9;
    }
    *(undefined4 *)(param_8 + 2) = *(undefined4 *)(psVar14 + 8);
    *psVar2 = psVar14[1];
    *(undefined4 *)((longlong)param_8 + 4) = *(undefined4 *)(psVar14 + 2);
    *(short *)((longlong)param_8 + 0x1c) = psVar14[0xe];
    *(undefined4 *)((longlong)param_8 + 0x14) = *(undefined4 *)(psVar14 + 10);
    *(undefined4 *)(param_8 + 3) = *(undefined4 *)(psVar14 + 0xc);
    *(undefined4 *)((longlong)param_8 + 0x26) = *(undefined4 *)(psVar14 + 0x13);
    func_0x(param_7,param_6,*(undefined8 *)(psVar14 + 4),uVar23);
    param_8[1] = param_7;
    iVar13 = func_0x(psVar2);
    plVar37 = plStack_100;
    cVar10 = cStack_108;
    if (iVar13 != 0) {
      puVar38 = (ushort *)((ulonglong)*(uint *)((longlong)param_8 + 0x14) + param_8[1]);
      uVar23 = *puVar38 - 1;
      if ((*(byte *)psVar2 & 1) == 0) {
        uVar23 = (uint)*puVar38;
      }
      uVar31 = puVar38[(int)uVar23];
      if (uVar23 == 1) {
        uVar23 = *(uint *)(param_8 + 3);
LAB_:
        uVar24 = uVar31 & 0x7fff;
        if ((uVar24 < uVar23) || (*(uint *)((longlong)param_8 + 4) < uVar24)) goto LAB_;
      }
      else {
        uVar23 = puVar38[(longlong)(int)uVar23 + -1] & 0x7fff;
        if (*(uint *)(param_8 + 3) <= uVar23) goto LAB_;
LAB_:
        func_0x(param_8[1],7);
      }
      uVar41 = param_8[1];
      uVar21 = (ulonglong)(uVar23 & 0xffff);
      uVar11 = *(ushort *)((longlong)param_8 + 0x2c) & 0xc7ff;
      uVar18 = uVar41 + uVar21;
      *(short *)((longlong)param_8 + 0x2a) = (short)uVar23;
      if ((*(ushort *)(uVar18 + 2) >> 0xe & 1) != 0) {
        uVar11 = *(ushort *)(uVar18 + 2) & 0x3800 | uVar11;
      }
      *(ushort *)((longlong)param_8 + 0x2c) = uVar11;
      uVar12 = (uVar11 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar11;
      *(ushort *)((longlong)param_8 + 0x2c) = uVar12;
      uVar27 = uVar41 + 4 + (ulonglong)((uVar12 & 0x7ff) * 2) + uVar21 + (uVar11 >> 0xb & 7) * 2;
      if (uVar27 < uVar18) {
        func_0x(uVar18,0x19);
        uVar12 = *(ushort *)((longlong)param_8 + 0x2c);
        uVar21 = (ulonglong)*(ushort *)((longlong)param_8 + 0x2a);
        uVar41 = (ulonglong)*(uint *)(param_8 + 1);
      }
      if ((uVar31 & 0x7fff) - uVar23 <
          (((uVar12 & 0x7ff) * 2 - (int)uVar21) - (int)uVar41) + (int)uVar27) {
        func_0x(uVar21 + param_8[1],0x19);
        uVar12 = *(ushort *)((longlong)param_8 + 0x2c);
      }
      iVar13 = 0;
      plVar37 = plStack_100;
      cVar10 = cStack_108;
      if (((uVar12 & 0x3800) != 0) &&
         (puVar38 = (ushort *)(param_8[1] + 4 + (ulonglong)*(ushort *)((longlong)param_8 + 0x2a)),
         (uVar12 & 0x3800) != 0)) {
        do {
          if ((uVar12 & 0x7ff) < (*puVar38 & 0x7ff)) {
            func_0x((ulonglong)*(ushort *)((longlong)param_8 + 0x2a) + param_8[1],0x1a);
            uVar12 = *(ushort *)((longlong)param_8 + 0x2c);
          }
          iVar13 = iVar13 + 1;
          puVar38 = puVar38 + 1;
          plVar37 = plStack_100;
          cVar10 = cStack_108;
        } while (iVar13 < (int)(uVar12 >> 0xb & 7));
      }
    }
  }
  else {
    plVar37 = param_8;
    if (((*psVar14 == 0) || (*(longlong **)(psVar14 + 8) == (longlong *)0x0)) ||
       (**(longlong **)(psVar14 + 8) == 0)) {
      func_0x((short *)((longlong)param_8 + 2),param_7,param_6,psVar14 + 1);
      if (*psVar14 != 0) {
        uVar18 = *(ulonglong *)(psVar14 + 8);
      }
      param_8[2] = uVar18;
    }
    else {
      func_0x(param_8,param_7,param_6,psVar14);
    }
  }
  iVar13 = 0;
  puVar38 = (ushort *)((longlong)plVar37 + 2);
  if (*(short *)plVar37 == 0) {
    func_0x();
  }
  else {
    func_0x(puVar38);
  }
  sVar30 = *(short *)plVar37;
  bVar29 = *(byte *)plVar37[1];
  bVar7 = bVar29 >> 1;
  if (sVar30 == 0) {
    bVar7 = bVar29 >> 6;
  }
  if ((bVar7 & 1) != 0) {
    if (cVar10 != '\0') {
      if (sVar30 == 0) {
        if ((bVar29 & 0xe) != 2) {
          uVar23 = *(uint *)((longlong)plVar37 + 4);
          if (uVar23 == 0) {
            pbVar20 = (byte *)plVar37[1];
            uVar23 = *(uint *)(plVar37 + 2);
            uVar18 = (ulonglong)uVar23;
            *puVar38 = 0;
            *(uint *)((longlong)plVar37 + 0x14) = uVar23;
            bVar29 = *pbVar20;
            if ((bVar29 & 0x10) != 0) {
              uVar23 = uVar23 + 2 + (*(ushort *)(pbVar20 + uVar18) + 7 >> 3);
              uVar18 = (ulonglong)uVar23;
              *(uint *)((longlong)plVar37 + 0x14) = uVar23;
              bVar29 = *pbVar20;
            }
            if ((bVar29 & 0x20) == 0) {
              *(int *)((longlong)plVar37 + 4) = (int)uVar18;
              *(short *)((longlong)plVar37 + 0x1c) = 0;
              *(int *)(plVar37 + 3) = (int)uVar18;
            }
            else {
              puVar42 = (ushort *)(pbVar20 + uVar18);
              uVar31 = *puVar42;
              *(ushort *)((longlong)plVar37 + 0x1c) = uVar31;
              if (uVar31 == 0) {
                cVar10 = func_0x(0x11bda20);
                if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                   (*(char *)(lVar15 + 0x499) != '\0')) {
                  cVar10 = func_0x(0x11bda20);
                  if (cVar10 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3eb);
                  }
                  else {
                    puStack_118 = (undefined *)0x0;
                    (*_DAT_)(1,0xaad42c,0xbcd518,0x80f);
                  }
                }
                func_0x(plVar37[1],3);
                uVar31 = *(ushort *)((longlong)plVar37 + 0x1c);
                uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 0x14);
                pbVar20 = (byte *)plVar37[1];
              }
              uVar24 = (uint)uVar31;
              uVar23 = (int)uVar18 + (uVar24 + 1) * 2;
              *(uint *)(plVar37 + 3) = uVar23;
              if (0x1f9e < uVar23) {
                cVar10 = func_0x(0x11bda20);
                if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                   (*(char *)(lVar15 + 0x499) != '\0')) {
                  cVar10 = func_0x(0x11bda20);
                  if (cVar10 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puStack_118 = (undefined *)0x0;
                    (*_DAT_)(1,0xaad42c,0xbcd518,0x816);
                  }
                }
                func_0x(plVar37[1],4);
                uVar24 = (uint)*(ushort *)((longlong)plVar37 + 0x1c);
                uVar23 = *(uint *)(plVar37 + 3);
                pbVar20 = (byte *)plVar37[1];
              }
              uVar36 = puVar42[uVar24] & 0x7fff;
              *(uint *)((longlong)plVar37 + 4) = uVar36;
              if (uVar36 < uVar23) {
                cVar10 = func_0x(0x11bda20);
                if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                   (*(char *)(lVar15 + 0x499) != '\0')) {
                  cVar10 = func_0x(0x11bda20);
                  if (cVar10 == '\0') {
                    (*_DAT_)(0x22,0x44,0x15,0x3ec);
                  }
                  else {
                    puStack_118 = (undefined *)0x0;
                    (*_DAT_)(1,0xaad42c,0xbcd518,0x81d);
                  }
                }
                func_0x(plVar37[1],4);
                uVar23 = *(uint *)(plVar37 + 3);
                uVar24 = (uint)*(ushort *)((longlong)plVar37 + 0x1c);
                uVar36 = *(uint *)((longlong)plVar37 + 4);
                pbVar20 = (byte *)plVar37[1];
              }
              puVar6 = puVar42;
              if ((short)uVar24 != 0) {
                do {
                  uVar28 = puVar6[1] & 0x7fff;
                  if ((uVar28 < uVar23) ||
                     (uVar36 = *(uint *)((longlong)plVar37 + 4), uVar36 < uVar28)) {
                    cVar10 = func_0x(0x11bda20);
                    if ((cVar10 != '\0') &&
                       ((lVar15 = func_0x(), lVar15 != 0 &&
                        (*(char *)(lVar15 + 0x499) != '\0')))) {
                      cVar10 = func_0x(0x11bda20);
                      if (cVar10 == '\0') {
                        (*_DAT_)(0x22,0x44,0x15,0x3ec);
                      }
                      else {
                        puStack_118 = (undefined *)0x0;
                        (*_DAT_)(1,0xaad42c,0xbcd518,0x82a);
                      }
                    }
                    func_0x(plVar37[1],4);
                    uVar36 = *(uint *)((longlong)plVar37 + 4);
                  }
                  uVar24 = (uint)*(ushort *)((longlong)plVar37 + 0x1c);
                  iVar13 = iVar13 + 1;
                  puVar6 = puVar6 + 1;
                  uVar23 = uVar28;
                } while (iVar13 < (int)uVar24);
                pbVar20 = (byte *)plVar37[1];
              }
              uVar18 = (ulonglong)uVar36;
              if ((short)puVar42[(ulonglong)(uVar24 - 1) + 1] < 0) {
LAB_:
                uVar36 = *(ushort *)
                          (pbVar20 +
                          (ulonglong)uVar24 * 2 + (ulonglong)*(uint *)((longlong)plVar37 + 0x14)) &
                         0x7fff;
                if (uVar24 == 1) {
                  uVar28 = *(uint *)(plVar37 + 3);
                  uVar41 = (ulonglong)uVar28;
LAB_:
                  if ((uVar36 < (uint)uVar41) ||
                     (uVar23 = *(uint *)((longlong)plVar37 + 4), uVar23 < uVar36))
                  goto LAB_;
                }
                else {
                  uVar28 = *(uint *)(plVar37 + 3);
                  uVar41 = (ulonglong)
                           (*(ushort *)
                             (pbVar20 +
                             (ulonglong)uVar24 * 2 +
                             ((ulonglong)*(uint *)((longlong)plVar37 + 0x14) - 2)) & 0x7fff);
                  if (uVar28 <= (*(ushort *)
                                  (pbVar20 +
                                  (ulonglong)uVar24 * 2 +
                                  ((ulonglong)*(uint *)((longlong)plVar37 + 0x14) - 2)) & 0x7fff))
                  goto LAB_;
LAB_:
                  func_0x(pbVar20,7);
                  uVar28 = *(uint *)(plVar37 + 3);
                  uVar23 = *(uint *)((longlong)plVar37 + 4);
                  pbVar20 = (byte *)plVar37[1];
                }
                uVar18 = (ulonglong)uVar23;
                uVar24 = (uint)uVar41;
                if ((uVar28 <= uVar24) && (uVar24 <= uVar23)) {
                  if (*(ushort *)(pbVar20 + uVar41) == 5) {
                    *puVar38 = *puVar38 | 2;
                    *(short *)((longlong)plVar37 + 0x1c) = *(short *)((longlong)plVar37 + 0x1c) + -1
                    ;
                    uVar21 = plVar37[1];
                    uVar27 = uVar41 & 0xffff;
                    uVar18 = uVar27 + uVar21;
                    *(short *)((longlong)plVar37 + 0x2a) = (short)uVar41;
                    uVar31 = *(ushort *)((longlong)plVar37 + 0x2c) & 0xc7ff;
                    if ((*(ushort *)(uVar18 + 2) & 0x4000) != 0) {
                      uVar31 = *(ushort *)(uVar18 + 2) & 0x3800 | uVar31;
                    }
                    *(ushort *)((longlong)plVar37 + 0x2c) = uVar31;
                    uVar11 = (uVar31 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar31;
                    *(ushort *)((longlong)plVar37 + 0x2c) = uVar11;
                    uVar41 = (ulonglong)((uVar11 & 0x7ff) * 2) + 4 +
                             uVar27 + (uVar31 >> 0xb & 7) * 2 + uVar21;
                    if (uVar41 < uVar18) {
                      func_0x(uVar18,0x19);
                      uVar11 = *(ushort *)((longlong)plVar37 + 0x2c);
                      uVar27 = (ulonglong)*(ushort *)((longlong)plVar37 + 0x2a);
                      uVar21 = (ulonglong)*(uint *)(plVar37 + 1);
                    }
                    if (uVar36 - uVar24 <
                        (((uVar11 & 0x7ff) * 2 - (int)uVar27) - (int)uVar21) + (int)uVar41) {
                      func_0x(uVar27 + plVar37[1],0x19);
                      uVar11 = *(ushort *)((longlong)plVar37 + 0x2c);
                    }
                    if ((uVar11 & 0x3800) != 0) {
                      puVar42 = (ushort *)
                                (plVar37[1] + (ulonglong)*(ushort *)((longlong)plVar37 + 0x2a) + 4);
                      iVar13 = 0;
                      if ((uVar11 & 0x3800) != 0) {
                        do {
                          if ((uVar11 & 0x7ff) < (*puVar42 & 0x7ff)) {
                            func_0x((ulonglong)*(ushort *)((longlong)plVar37 + 0x2a) +
                                            plVar37[1],0x1a);
                            uVar11 = *(ushort *)((longlong)plVar37 + 0x2c);
                          }
                          iVar13 = iVar13 + 1;
                          puVar42 = puVar42 + 1;
                        } while (iVar13 < (int)(uVar11 >> 0xb & 7));
                      }
                    }
                    pbVar20 = (byte *)plVar37[1];
                    uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
                  }
                  else if (0x3ff < *(ushort *)(pbVar20 + uVar41)) goto code_r0x00100e33;
                  goto LAB_;
                }
                goto LAB_;
              }
            }
LAB_:
            iVar13 = 0;
            if ((*pbVar20 & 0x40) == 0) {
              *(undefined4 *)((longlong)plVar37 + 0x26) = 0;
            }
            else {
              *(int *)((longlong)plVar37 + 0x26) = *(int *)((longlong)plVar37 + 4);
              *(int *)((longlong)plVar37 + 4) = *(int *)((longlong)plVar37 + 4) + 0xe;
              puVar17 = (ulonglong *)func_0x(puVar38);
              uVar11 = (ushort)(*puVar17 >> 0x30);
              uVar31 = uVar11;
              if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
                uVar31 = uVar11 & 0xdfff;
                if ((uVar11 >> 0xe & 1) != 0) {
                  uVar31 = uVar11 | 0x2000;
                }
              }
              if (uVar31 == 0xfffc) {
                iVar13 = (int)((*puVar17 >> 0x20 & 0xffff) >> 5);
              }
              *(int *)((longlong)plVar37 + 4) = *(int *)((longlong)plVar37 + 4) + iVar13;
              uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
              pbVar20 = (byte *)plVar37[1];
            }
            if ((*(byte **)((longlong)plVar37 + 0x1e) != (byte *)0x0) &&
               (*(byte **)((longlong)plVar37 + 0x1e) < pbVar20 + uVar18)) {
              cVar10 = func_0x(0x11bda20);
              if ((cVar10 != '\0') &&
                 ((lVar15 = func_0x(), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                cVar10 = func_0x(0x11bda20);
                if (cVar10 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3fa);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xaad42c,0xbcd518,0x886);
                }
              }
              func_0x(plVar37[1],0x12);
              uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
            }
            uVar23 = (uint)uVar18;
            if ((uVar23 == 0) || (0x3f3c < uVar23)) {
              cVar10 = func_0x(0x11bda20);
              if ((cVar10 != '\0') &&
                 ((lVar15 = func_0x(), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                cVar10 = func_0x(0x11bda20);
                if (cVar10 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ed);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xaad42c,0xbcd518,0x88b);
                }
              }
              func_0x(plVar37[1],5);
              uVar23 = *(uint *)((longlong)plVar37 + 4);
            }
          }
LAB_:
          if (uVar23 < 9) {
            bVar29 = *(byte *)plVar37[1];
            if (((bVar29 & 0xe) != 0) && ((bVar29 & 0xe) != 0xc)) goto LAB_;
            uVar23 = 9;
          }
          else {
LAB_:
            bVar29 = *(byte *)plVar37[1];
          }
          if ((bVar29 & 0x40) != 0) {
            uVar23 = *(uint *)((longlong)plVar37 + 0x26);
          }
          goto LAB_;
        }
      }
      else {
        if (((bVar29 & 0x1c) - 0x10 & 0xfffffffb) == 0) goto LAB_;
        uVar23 = *(uint *)((longlong)plVar37 + 4);
        if (uVar23 == 0) {
          func_0x(puVar38);
          uVar23 = *(uint *)((longlong)plVar37 + 4);
          if (uVar23 == 0) {
            func_0x(puVar38);
            uVar23 = *(uint *)((longlong)plVar37 + 4);
          }
        }
        if (uVar23 < 9) {
          bVar29 = *(byte *)plVar37[1];
          if (((bVar29 & 0x1c) != 0) && ((bVar29 & 0x1c) != 0xc)) goto LAB_;
          uVar23 = 9;
        }
        else {
LAB_:
          bVar29 = *(byte *)plVar37[1];
        }
        if ((bVar29 & 2) != 0) {
          uVar23 = *(uint *)(plVar37 + 6);
        }
LAB_:
        sVar30 = *(short *)plVar37;
        uVar24 = 0x16;
        if (sVar30 != 0) {
          uVar24 = 0x10;
        }
        if (uVar24 <= uVar23) goto LAB_;
      }
LAB_:
      if (sVar30 == 0) {
        uVar23 = *(uint *)((longlong)plVar37 + 4);
        if (uVar23 == 0) {
          pbVar20 = (byte *)plVar37[1];
          iVar13 = 0;
          uVar23 = *(uint *)(plVar37 + 2);
          uVar18 = (ulonglong)uVar23;
          *puVar38 = 0;
          *(uint *)((longlong)plVar37 + 0x14) = uVar23;
          bVar29 = *pbVar20;
          if ((bVar29 & 0x10) != 0) {
            uVar23 = uVar23 + 2 + (*(ushort *)(pbVar20 + uVar18) + 7 >> 3);
            uVar18 = (ulonglong)uVar23;
            *(uint *)((longlong)plVar37 + 0x14) = uVar23;
            bVar29 = *pbVar20;
          }
          if ((bVar29 & 0x20) == 0) {
            *(int *)((longlong)plVar37 + 4) = (int)uVar18;
            *(short *)((longlong)plVar37 + 0x1c) = 0;
            *(int *)(plVar37 + 3) = (int)uVar18;
          }
          else {
            puVar42 = (ushort *)(pbVar20 + uVar18);
            uVar31 = *puVar42;
            *(ushort *)((longlong)plVar37 + 0x1c) = uVar31;
            if (uVar31 == 0) {
              cVar10 = func_0x(0x11bda20);
              if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                 (*(char *)(lVar15 + 0x499) != '\0')) {
                cVar10 = func_0x(0x11bda20);
                if (cVar10 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xaad42c,0xbcd518,0x80f);
                }
              }
              func_0x(plVar37[1],3);
              uVar31 = *(ushort *)((longlong)plVar37 + 0x1c);
              uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 0x14);
              pbVar20 = (byte *)plVar37[1];
            }
            uVar24 = (uint)uVar31;
            uVar23 = (int)uVar18 + (uVar24 + 1) * 2;
            *(uint *)(plVar37 + 3) = uVar23;
            if (0x1f9e < uVar23) {
              cVar10 = func_0x(0x11bda20);
              if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                 (*(char *)(lVar15 + 0x499) != '\0')) {
                cVar10 = func_0x(0x11bda20);
                if (cVar10 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xaad42c,0xbcd518,0x816);
                }
              }
              func_0x(plVar37[1],4);
              uVar24 = (uint)*(ushort *)((longlong)plVar37 + 0x1c);
              uVar23 = *(uint *)(plVar37 + 3);
              pbVar20 = (byte *)plVar37[1];
            }
            uVar36 = puVar42[uVar24] & 0x7fff;
            *(uint *)((longlong)plVar37 + 4) = uVar36;
            if (uVar36 < uVar23) {
              cVar10 = func_0x(0x11bda20);
              if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
                 (*(char *)(lVar15 + 0x499) != '\0')) {
                cVar10 = func_0x(0x11bda20);
                if (cVar10 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xaad42c,0xbcd518,0x81d);
                }
              }
              func_0x(plVar37[1],4);
              uVar23 = *(uint *)(plVar37 + 3);
              uVar24 = (uint)*(ushort *)((longlong)plVar37 + 0x1c);
              uVar36 = *(uint *)((longlong)plVar37 + 4);
              pbVar20 = (byte *)plVar37[1];
            }
            puVar6 = puVar42;
            if ((short)uVar24 != 0) {
              do {
                uVar28 = puVar6[1] & 0x7fff;
                if ((uVar28 < uVar23) ||
                   (uVar36 = *(uint *)((longlong)plVar37 + 4), uVar36 < uVar28)) {
                  cVar10 = func_0x(0x11bda20);
                  if ((cVar10 != '\0') &&
                     ((lVar15 = func_0x(), lVar15 != 0 &&
                      (*(char *)(lVar15 + 0x499) != '\0')))) {
                    cVar10 = func_0x(0x11bda20);
                    if (cVar10 == '\0') {
                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                    }
                    else {
                      puStack_118 = (undefined *)0x0;
                      (*_DAT_)(1,0xaad42c,0xbcd518,0x82a);
                    }
                  }
                  func_0x(plVar37[1],4);
                  uVar36 = *(uint *)((longlong)plVar37 + 4);
                }
                uVar24 = (uint)*(ushort *)((longlong)plVar37 + 0x1c);
                iVar13 = iVar13 + 1;
                puVar6 = puVar6 + 1;
                uVar23 = uVar28;
              } while (iVar13 < (int)uVar24);
              pbVar20 = (byte *)plVar37[1];
            }
            uVar18 = (ulonglong)uVar36;
            if ((short)puVar42[(ulonglong)(uVar24 - 1) + 1] < 0) {
LAB_:
              uVar36 = *(ushort *)
                        (pbVar20 +
                        (ulonglong)uVar24 * 2 + (ulonglong)*(uint *)((longlong)plVar37 + 0x14)) &
                       0x7fff;
              if (uVar24 == 1) {
                uVar28 = *(uint *)(plVar37 + 3);
                uVar41 = (ulonglong)uVar28;
LAB_:
                if ((uVar36 < (uint)uVar41) ||
                   (uVar23 = *(uint *)((longlong)plVar37 + 4), uVar23 < uVar36)) goto LAB_;
              }
              else {
                uVar28 = *(uint *)(plVar37 + 3);
                uVar41 = (ulonglong)
                         (*(ushort *)
                           (pbVar20 +
                           (ulonglong)uVar24 * 2 +
                           ((ulonglong)*(uint *)((longlong)plVar37 + 0x14) - 2)) & 0x7fff);
                if (uVar28 <= (*(ushort *)
                                (pbVar20 +
                                (ulonglong)uVar24 * 2 +
                                ((ulonglong)*(uint *)((longlong)plVar37 + 0x14) - 2)) & 0x7fff))
                goto LAB_;
LAB_:
                func_0x(pbVar20,7);
                uVar28 = *(uint *)(plVar37 + 3);
                uVar23 = *(uint *)((longlong)plVar37 + 4);
                pbVar20 = (byte *)plVar37[1];
              }
              uVar18 = (ulonglong)uVar23;
              uVar24 = (uint)uVar41;
              if ((uVar28 <= uVar24) && (uVar24 <= uVar23)) {
                if (*(ushort *)(pbVar20 + uVar41) == 5) {
                  *puVar38 = *puVar38 | 2;
                  *(short *)((longlong)plVar37 + 0x1c) = *(short *)((longlong)plVar37 + 0x1c) + -1;
                  uVar21 = plVar37[1];
                  uVar27 = uVar41 & 0xffff;
                  uVar18 = uVar27 + uVar21;
                  *(short *)((longlong)plVar37 + 0x2a) = (short)uVar41;
                  uVar31 = *(ushort *)((longlong)plVar37 + 0x2c) & 0xc7ff;
                  if ((*(ushort *)(uVar18 + 2) & 0x4000) != 0) {
                    uVar31 = *(ushort *)(uVar18 + 2) & 0x3800 | uVar31;
                  }
                  *(ushort *)((longlong)plVar37 + 0x2c) = uVar31;
                  uVar11 = (uVar31 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar31;
                  *(ushort *)((longlong)plVar37 + 0x2c) = uVar11;
                  uVar41 = (ulonglong)((uVar11 & 0x7ff) * 2) + 4 + uVar27 + (uVar31 >> 0xb & 7) * 2
                           + uVar21;
                  if (uVar41 < uVar18) {
                    func_0x(uVar18,0x19);
                    uVar11 = *(ushort *)((longlong)plVar37 + 0x2c);
                    uVar27 = (ulonglong)*(ushort *)((longlong)plVar37 + 0x2a);
                    uVar21 = (ulonglong)*(uint *)(plVar37 + 1);
                  }
                  if (uVar36 - uVar24 <
                      (((uVar11 & 0x7ff) * 2 - (int)uVar27) - (int)uVar21) + (int)uVar41) {
                    func_0x(uVar27 + plVar37[1],0x19);
                    uVar11 = *(ushort *)((longlong)plVar37 + 0x2c);
                  }
                  if ((uVar11 & 0x3800) != 0) {
                    puVar42 = (ushort *)
                              (plVar37[1] + (ulonglong)*(ushort *)((longlong)plVar37 + 0x2a) + 4);
                    iVar13 = 0;
                    if ((uVar11 & 0x3800) != 0) {
                      do {
                        if ((uVar11 & 0x7ff) < (*puVar42 & 0x7ff)) {
                          func_0x((ulonglong)*(ushort *)((longlong)plVar37 + 0x2a) +
                                          plVar37[1],0x1a);
                          uVar11 = *(ushort *)((longlong)plVar37 + 0x2c);
                        }
                        iVar13 = iVar13 + 1;
                        puVar42 = puVar42 + 1;
                      } while (iVar13 < (int)(uVar11 >> 0xb & 7));
                    }
                  }
                  pbVar20 = (byte *)plVar37[1];
                  uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
                }
                else if (0x3ff < *(ushort *)(pbVar20 + uVar41)) goto code_r0x001015f3;
                goto LAB_;
              }
              goto LAB_;
            }
          }
LAB_:
          iVar13 = 0;
          if ((*pbVar20 & 0x40) == 0) {
            *(undefined4 *)((longlong)plVar37 + 0x26) = 0;
          }
          else {
            *(int *)((longlong)plVar37 + 0x26) = *(int *)((longlong)plVar37 + 4);
            *(int *)((longlong)plVar37 + 4) = *(int *)((longlong)plVar37 + 4) + 0xe;
            puVar17 = (ulonglong *)func_0x(puVar38);
            uVar11 = (ushort)(*puVar17 >> 0x30);
            uVar31 = uVar11;
            if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
              uVar31 = uVar11 & 0xdfff;
              if ((uVar11 >> 0xe & 1) != 0) {
                uVar31 = uVar11 | 0x2000;
              }
            }
            if (uVar31 == 0xfffc) {
              iVar13 = (int)((*puVar17 >> 0x20 & 0xffff) >> 5);
            }
            *(int *)((longlong)plVar37 + 4) = *(int *)((longlong)plVar37 + 4) + iVar13;
            uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
            pbVar20 = (byte *)plVar37[1];
          }
          if ((*(byte **)((longlong)plVar37 + 0x1e) != (byte *)0x0) &&
             (*(byte **)((longlong)plVar37 + 0x1e) < pbVar20 + uVar18)) {
            cVar10 = func_0x(0x11bda20);
            if ((cVar10 != '\0') &&
               ((lVar15 = func_0x(), lVar15 != 0 &&
                (*(char *)(lVar15 + 0x499) != '\0')))) {
              cVar10 = func_0x(0x11bda20);
              if (cVar10 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3fa);
              }
              else {
                puStack_118 = (undefined *)0x0;
                (*_DAT_)(1,0xaad42c,0xbcd518,0x886);
              }
            }
            func_0x(plVar37[1],0x12);
            uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
          }
          uVar23 = (uint)uVar18;
          if ((uVar23 == 0) || (0x3f3c < uVar23)) {
            cVar10 = func_0x(0x11bda20);
            if ((cVar10 != '\0') &&
               ((lVar15 = func_0x(), lVar15 != 0 &&
                (*(char *)(lVar15 + 0x499) != '\0')))) {
              cVar10 = func_0x(0x11bda20);
              if (cVar10 == '\0') {
                (*_DAT_)(0x22,0x44,0x15,0x3ed);
              }
              else {
                puStack_118 = (undefined *)0x0;
                (*_DAT_)(1,0xaad42c,0xbcd518,0x88b);
              }
            }
            func_0x(plVar37[1],5);
            uVar23 = *(uint *)((longlong)plVar37 + 4);
          }
        }
LAB_:
        if (uVar23 < 9) {
          bVar29 = *(byte *)plVar37[1];
          uVar24 = 9;
          if (((bVar29 & 0xe) != 0) && ((bVar29 & 0xe) != 0xc)) goto LAB_;
        }
        else {
LAB_:
          bVar29 = *(byte *)plVar37[1];
          uVar24 = uVar23;
        }
        if ((bVar29 & 0x40) != 0) {
          uVar24 = *(uint *)((longlong)plVar37 + 0x26);
        }
      }
      else {
        uVar23 = *(uint *)((longlong)plVar37 + 4);
        if (uVar23 == 0) {
          func_0x(puVar38);
          uVar23 = *(uint *)((longlong)plVar37 + 4);
          if (uVar23 == 0) {
            func_0x(puVar38);
            uVar23 = *(uint *)((longlong)plVar37 + 4);
          }
        }
        if (uVar23 < 9) {
          bVar29 = *(byte *)plVar37[1];
          uVar24 = 9;
          if (((bVar29 & 0x1c) != 0) && ((bVar29 & 0x1c) != 0xc)) goto LAB_;
        }
        else {
LAB_:
          bVar29 = *(byte *)plVar37[1];
          uVar24 = uVar23;
        }
        if ((bVar29 & 2) != 0) {
          uVar24 = *(uint *)(plVar37 + 6);
        }
      }
      sVar30 = *(short *)plVar37;
      uVar23 = 0x20;
      if (sVar30 != 0) {
        uVar23 = 0x18;
      }
      if (uVar24 < uVar23) goto LAB_;
    }
LAB_:
    if (sVar30 == 0) {
      func_0x(puVar38);
    }
    else {
      pbVar20 = (byte *)plVar37[1];
      bVar29 = *pbVar20;
      if ((bVar29 & 2) != 0) {
        if (*(int *)((longlong)plVar37 + 4) == 0) {
          func_0x(puVar38);
          pbVar20 = (byte *)plVar37[1];
          bVar29 = *pbVar20;
        }
        *pbVar20 = bVar29 & 0xfd;
        *(undefined4 *)((longlong)plVar37 + 4) = *(undefined4 *)(plVar37 + 6);
        *(undefined4 *)(plVar37 + 6) = 0;
      }
    }
  }
LAB_:
  (**(code **)(*plStack_e0 + 8))();
  func_0x(lStack_d8,plVar37);
  if (*(short *)plVar37 == 0) {
    if ((*(byte *)plVar37[1] & 0x10) == 0) goto LAB_;
    uVar31 = *(ushort *)((byte *)plVar37[1] + *(uint *)(plVar37 + 2));
  }
  else {
    uVar31 = *puVar38;
  }
  if ((uVar31 != 0) && (uVar23 = (uint)sStack_106, *(short *)plVar37 == 0)) {
    iVar40 = 0;
    iVar13 = 0;
    if (*(int *)((longlong)plVar37 + 4) == 0) {
      pbVar20 = (byte *)plVar37[1];
      uVar24 = *(uint *)(plVar37 + 2);
      uVar18 = (ulonglong)uVar24;
      *puVar38 = 0;
      *(uint *)((longlong)plVar37 + 0x14) = uVar24;
      bVar29 = *pbVar20;
      if ((bVar29 & 0x10) != 0) {
        uVar24 = uVar24 + 2 + (*(ushort *)(pbVar20 + uVar18) + 7 >> 3);
        uVar18 = (ulonglong)uVar24;
        *(uint *)((longlong)plVar37 + 0x14) = uVar24;
        bVar29 = *pbVar20;
      }
      if ((bVar29 & 0x20) == 0) {
        *(int *)((longlong)plVar37 + 4) = (int)uVar18;
        *(short *)((longlong)plVar37 + 0x1c) = 0;
        *(int *)(plVar37 + 3) = (int)uVar18;
      }
      else {
        puVar42 = (ushort *)(pbVar20 + uVar18);
        uVar31 = *puVar42;
        *(ushort *)((longlong)plVar37 + 0x1c) = uVar31;
        if (uVar31 == 0) {
          cVar10 = func_0x(0x11bda20);
          if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
             (*(char *)(lVar15 + 0x499) != '\0')) {
            cVar10 = func_0x(0x11bda20);
            if (cVar10 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3eb);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xaad42c,0xbcd518,0x80f);
            }
          }
          func_0x(plVar37[1],3);
          uVar31 = *(ushort *)((longlong)plVar37 + 0x1c);
          uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 0x14);
          pbVar20 = (byte *)plVar37[1];
        }
        uVar24 = (int)uVar18 + (uVar31 + 1) * 2;
        *(uint *)(plVar37 + 3) = uVar24;
        if (0x1f9e < uVar24) {
          cVar10 = func_0x(0x11bda20);
          if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
             (*(char *)(lVar15 + 0x499) != '\0')) {
            cVar10 = func_0x(0x11bda20);
            if (cVar10 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xaad42c,0xbcd518,0x816);
            }
          }
          func_0x(plVar37[1],4);
          uVar31 = *(ushort *)((longlong)plVar37 + 0x1c);
          uVar24 = *(uint *)(plVar37 + 3);
          pbVar20 = (byte *)plVar37[1];
        }
        uVar18 = (ulonglong)uVar31;
        uVar31 = puVar42[uVar18];
        *(uint *)((longlong)plVar37 + 4) = uVar31 & 0x7fff;
        if ((uVar31 & 0x7fff) < uVar24) {
          cVar10 = func_0x(0x11bda20);
          if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
             (*(char *)(lVar15 + 0x499) != '\0')) {
            cVar10 = func_0x(0x11bda20);
            if (cVar10 == '\0') {
              (*_DAT_)(0x22,0x44,0x15,0x3ec);
            }
            else {
              puStack_118 = (undefined *)0x0;
              (*_DAT_)(1,0xaad42c,0xbcd518,0x81d);
            }
          }
          func_0x(plVar37[1],4);
          uVar24 = *(uint *)(plVar37 + 3);
          uVar18 = (ulonglong)*(ushort *)((longlong)plVar37 + 0x1c);
          pbVar20 = (byte *)plVar37[1];
        }
        iVar39 = iVar40;
        puVar6 = puVar42;
        if ((short)uVar18 != 0) {
          do {
            uVar36 = puVar6[1] & 0x7fff;
            if ((uVar36 < uVar24) || (*(uint *)((longlong)plVar37 + 4) < uVar36)) {
              cVar10 = func_0x(0x11bda20);
              if ((cVar10 != '\0') &&
                 ((lVar15 = func_0x(), lVar15 != 0 &&
                  (*(char *)(lVar15 + 0x499) != '\0')))) {
                cVar10 = func_0x(0x11bda20);
                if (cVar10 == '\0') {
                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                }
                else {
                  puStack_118 = (undefined *)0x0;
                  (*_DAT_)(1,0xaad42c,0xbcd518,0x82a);
                }
              }
              func_0x(plVar37[1],4);
            }
            uVar18 = (ulonglong)*(ushort *)((longlong)plVar37 + 0x1c);
            iVar39 = iVar39 + 1;
            uVar24 = uVar36;
            puVar6 = puVar6 + 1;
          } while (iVar39 < (int)(uint)*(ushort *)((longlong)plVar37 + 0x1c));
          pbVar20 = (byte *)plVar37[1];
        }
        if ((short)puVar42[(ulonglong)((int)uVar18 - 1) + 1] < 0) {
          do {
            uVar24 = *(ushort *)
                      (pbVar20 + uVar18 * 2 + (ulonglong)*(uint *)((longlong)plVar37 + 0x14)) &
                     0x7fff;
            if ((int)uVar18 == 1) {
              uVar36 = *(uint *)(plVar37 + 3);
              uVar28 = uVar36;
LAB_:
              if ((uVar24 < uVar36) || (*(uint *)((longlong)plVar37 + 4) < uVar24))
              goto LAB_;
            }
            else {
              uVar28 = *(uint *)(plVar37 + 3);
              uVar36 = *(ushort *)
                        (pbVar20 + uVar18 * 2 + ((ulonglong)*(uint *)((longlong)plVar37 + 0x14) - 2)
                        ) & 0x7fff;
              if (uVar28 <= uVar36) goto LAB_;
LAB_:
              func_0x(pbVar20,7);
              uVar28 = *(uint *)(plVar37 + 3);
              pbVar20 = (byte *)plVar37[1];
            }
            if ((uVar36 < uVar28) || (*(uint *)((longlong)plVar37 + 4) < uVar36)) goto LAB_;
            if (*(ushort *)(pbVar20 + uVar36) == 5) {
              *puVar38 = *puVar38 | 2;
              *(short *)((longlong)plVar37 + 0x1c) = *(short *)((longlong)plVar37 + 0x1c) + -1;
              uVar41 = plVar37[1];
              uVar21 = (ulonglong)(uVar36 & 0xffff);
              uVar31 = *(ushort *)((longlong)plVar37 + 0x2c) & 0xc7ff;
              uVar18 = uVar21 + uVar41;
              *(short *)((longlong)plVar37 + 0x2a) = (short)uVar36;
              if ((*(ushort *)(uVar18 + 2) >> 0xe & 1) != 0) {
                uVar31 = *(ushort *)(uVar18 + 2) & 0x3800 | uVar31;
              }
              *(ushort *)((longlong)plVar37 + 0x2c) = uVar31;
              uVar11 = (uVar31 ^ *(ushort *)(uVar18 + 2)) & 0x7ff ^ uVar31;
              *(ushort *)((longlong)plVar37 + 0x2c) = uVar11;
              uVar27 = (ulonglong)((uVar11 & 0x7ff) * 2) + 4 + uVar41 + (uVar31 >> 0xb & 7) * 2 +
                       uVar21;
              if (uVar27 < uVar18) {
                func_0x(uVar18,0x19);
                uVar11 = *(ushort *)((longlong)plVar37 + 0x2c);
                uVar21 = (ulonglong)*(ushort *)((longlong)plVar37 + 0x2a);
                uVar41 = (ulonglong)*(uint *)(plVar37 + 1);
              }
              if (uVar24 - uVar36 <
                  (((uVar11 & 0x7ff) * 2 - (int)uVar21) - (int)uVar41) + (int)uVar27) {
                func_0x(uVar21 + plVar37[1],0x19);
                uVar11 = *(ushort *)((longlong)plVar37 + 0x2c);
              }
              if (((uVar11 & 0x3800) != 0) &&
                 (puVar42 = (ushort *)
                            (plVar37[1] + 4 + (ulonglong)*(ushort *)((longlong)plVar37 + 0x2a)),
                 (uVar11 & 0x3800) != 0)) {
                do {
                  if ((uVar11 & 0x7ff) < (*puVar42 & 0x7ff)) {
                    func_0x((ulonglong)*(ushort *)((longlong)plVar37 + 0x2a) + plVar37[1],
                                    0x1a);
                    uVar11 = *(ushort *)((longlong)plVar37 + 0x2c);
                  }
                  iVar40 = iVar40 + 1;
                  puVar42 = puVar42 + 1;
                } while (iVar40 < (int)(uVar11 >> 0xb & 7));
              }
              pbVar20 = (byte *)plVar37[1];
              goto LAB_;
            }
            if (*(ushort *)(pbVar20 + uVar36) < 0x400) goto LAB_;
            *puVar38 = *puVar38 | 1;
            uVar31 = *(short *)((longlong)plVar37 + 0x1c) - 1;
            *(ushort *)((longlong)plVar37 + 0x1c) = uVar31;
            if (uVar31 == 0) goto LAB_;
            uVar18 = (ulonglong)uVar31;
          } while ((short)puVar42[(ulonglong)(uVar31 - 1) + 1] < 0);
          uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
        }
        else {
LAB_:
          uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
        }
      }
      if ((*pbVar20 & 0x40) == 0) {
        *(undefined4 *)((longlong)plVar37 + 0x26) = 0;
      }
      else {
        *(int *)((longlong)plVar37 + 0x26) = (int)uVar18;
        *(int *)((longlong)plVar37 + 4) = (int)uVar18 + 0xe;
        puVar17 = (ulonglong *)func_0x(puVar38);
        uVar11 = (ushort)(*puVar17 >> 0x30);
        uVar31 = uVar11;
        if ((((uint)(int)(short)uVar11 >> 1 ^ (int)(short)uVar11) & 0x2000) != 0) {
          uVar31 = uVar11 & 0xdfff;
          if ((uVar11 >> 0xe & 1) != 0) {
            uVar31 = uVar11 | 0x2000;
          }
        }
        if (uVar31 == 0xfffc) {
          iVar13 = (int)((*puVar17 >> 0x20 & 0xffff) >> 5);
        }
        *(int *)((longlong)plVar37 + 4) = *(int *)((longlong)plVar37 + 4) + iVar13;
        uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
        pbVar20 = (byte *)plVar37[1];
      }
      if ((*(byte **)((longlong)plVar37 + 0x1e) != (byte *)0x0) &&
         (*(byte **)((longlong)plVar37 + 0x1e) < pbVar20 + uVar18)) {
        cVar10 = func_0x(0x11bda20);
        if ((cVar10 != '\0') &&
           ((lVar15 = func_0x(), lVar15 != 0 && (*(char *)(lVar15 + 0x499) != '\0'))
           )) {
          cVar10 = func_0x(0x11bda20);
          if (cVar10 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3fa);
          }
          else {
            puStack_118 = (undefined *)0x0;
            (*_DAT_)(1,0xaad42c,0xbcd518,0x886);
          }
        }
        func_0x(plVar37[1],0x12);
        uVar18 = (ulonglong)*(uint *)((longlong)plVar37 + 4);
      }
      if (0x3f3b < (int)uVar18 - 1U) {
        cVar10 = func_0x(0x11bda20);
        if (((cVar10 != '\0') && (lVar15 = func_0x(), lVar15 != 0)) &&
           (*(char *)(lVar15 + 0x499) != '\0')) {
          cVar10 = func_0x(0x11bda20);
          if (cVar10 == '\0') {
            (*_DAT_)(0x22,0x44,0x15,0x3ed);
          }
          else {
            puStack_118 = (undefined *)0x0;
            (*_DAT_)(1,0xaad42c,0xbcd518,0x88b);
          }
        }
        func_0x(plVar37[1],5);
      }
    }
LAB_:
    pbVar20 = (byte *)plVar37[1];
    bVar29 = *pbVar20 & 0x10;
    if (bVar29 == 0) {
      uVar24 = 0;
    }
    else {
      uVar24 = (uint)*(ushort *)(pbVar20 + *(uint *)(plVar37 + 2));
    }
    if (uVar24 < uVar23) {
      uVar36 = *(uint *)(plVar37 + 2);
      uVar28 = 0;
      if (bVar29 != 0) {
        uVar28 = (uVar24 + 7 >> 3) + 2;
      }
      uVar32 = (uVar23 + 7 >> 3) + 2;
      if (uVar28 < uVar32) {
        uVar3 = *(uint *)((longlong)plVar37 + 0x14);
        iVar13 = *(int *)((longlong)plVar37 + 4);
        iVar40 = uVar32 - uVar28;
        puVar42 = (ushort *)(pbVar20 + uVar3);
        if (((*pbVar20 & 0x20) != 0) && (uVar18 = 0, *puVar42 != 0)) {
          do {
            uVar34 = (int)uVar18 + 1;
            uVar31 = puVar42[uVar18 + 1];
            puVar42[uVar18 + 1] = (uVar31 + (short)iVar40 ^ uVar31) & (ushort)uStack_104 ^ uVar31;
            uVar18 = (ulonglong)uVar34;
          } while (uVar34 < *puVar42);
        }
        func_0x
                  ((byte *)((longlong)puVar42 + ((ulonglong)uVar32 - (ulonglong)uVar28)),puVar42,
                   iVar13 - uVar3);
        if (0 < iVar40) {
          func_0x(puVar42,0,(ulonglong)uVar32 - (ulonglong)uVar28);
        }
        *(int *)((longlong)plVar37 + 0x14) = *(int *)((longlong)plVar37 + 0x14) + iVar40;
        *(int *)(plVar37 + 3) = *(int *)(plVar37 + 3) + iVar40;
        *(int *)((longlong)plVar37 + 4) = *(int *)((longlong)plVar37 + 4) + iVar40;
        iVar13 = func_0x(puVar38);
        if (iVar13 != 0) {
          func_0x(puVar38);
        }
      }
      uVar31 = (ushort)uVar24;
      *(short *)(pbVar20 + uVar36) = sStack_106;
      while( true ) {
        uVar31 = uVar31 + 1;
        if (uVar23 < uVar31) break;
        uVar24 = uVar31 - 1;
        lVar15 = (ulonglong)(uVar24 >> 3) + (longlong)*(int *)(plVar37 + 2);
        *(byte *)(lVar15 + 2 + plVar37[1]) =
             *(byte *)(plVar37[1] + 2 + lVar15) | (byte)(1 << (uVar24 & 7));
      }
    }
  }
LAB_:
  dVar9 = _DAT_;
  if (((*(uint *)(lStack_f0 + 0x14) & 0xe0000000) != 0x80000000) ||
     (0xff < *(ushort *)(lStack_f0 + 0x18))) {
    uVar23 = 0;
    if (*(short *)(lStack_c8 + 0x62) != 0) {
      pplVar43 = (longlong **)(*(longlong *)(lStack_c8 + 0x70) + 0x18);
      lVar15 = lStack_f0;
      do {
        if ((*(uint *)(pplVar43 + 5) & 0x200000) == 0) {
          lVar19 = *(longlong *)(lVar15 + 8);
          plStack_100 = *pplVar43;
          uStack_f8 = *(undefined4 *)(pplVar43 + 1);
          uStack_f4 = *(undefined4 *)((longlong)pplVar43 + 0xc);
          if ((((*(longlong *)(lVar19 + 0x90) == 0) || (DAT_ == '\0')) ||
              (*(longlong *)(*(longlong *)(*(longlong *)(lVar19 + 0x90) + 0x6b0) + 0x14c8) == 0)) &&
             (*(uint *)(lVar19 + 0xf4) < 2)) {
            if (*(int *)(lVar19 + 0x480) == 0) {
              func_0x();
            }
            plVar37 = plStack_100;
            if (plStack_100[1] == 0) {
LAB_:
              uVar41 = CONCAT44(uStack_f4,uStack_f8);
              LOCK();
              plVar37 = (longlong *)(*plVar37 + uVar41 * 8);
              *plVar37 = *plVar37 + 1;
              UNLOCK();
            }
            else {
              lVar26 = (ulonglong)*_DAT_ +
                       *(longlong *)
                        (*(longlong *)(unaff_GS_OFFSET + 0x58) + (ulonglong)*_DAT_ * 8);
              lVar19 = *(longlong *)(lVar26 + 0x100);
              if (lVar19 == 0) {
                (*_DAT_)(0);
                lVar19 = *(longlong *)(lVar26 + 0x100);
              }
              if (*(longlong *)(lVar19 + 0x260) == 0) {
                uVar18 = 0;
              }
              else {
                uVar18 = (ulonglong)*(uint *)(*(longlong *)(lVar19 + 0x260) + 0xe68);
              }
              if (*(uint *)(_DAT_ + 8) <= (uint)uVar18) goto LAB_;
              uVar41 = CONCAT44(uStack_f4,uStack_f8);
              lVar19 = *(longlong *)(plVar37[1] + uVar18 * 8);
              *(longlong *)(lVar19 + uVar41 * 8) = *(longlong *)(lVar19 + uVar41 * 8) + 1;
            }
            if (*(char *)(plStack_d0[6] + 0x2068) != '\0') {
              lVar19 = *(longlong *)(lVar15 + 8);
              lVar26 = *(longlong *)(lVar19 + 0x160);
              func_0x();
              plVar37 = plStack_d0;
              lVar15 = lStack_f0;
              lVar25 = *(longlong *)(lVar26 + 8);
              bVar8 = false;
              uVar24 = (uint)uVar41;
              uVar18 = uVar41 & 0xffffffff;
              do {
                uVar21 = 0;
                plVar33 = *(longlong **)(*(longlong *)(lVar26 + 0x88) + uVar18 * 8);
                if ((*(longlong *)(lVar26 + 0x90) != 0) && (*(int *)(_DAT_ + 8) != 0)) {
                  do {
                    uVar36 = (int)uVar21 + 1;
                    plVar33 = (longlong *)
                              ((longlong)plVar33 +
                              *(longlong *)
                               (*(longlong *)(*(longlong *)(lVar26 + 0x90) + uVar21 * 8) +
                               uVar18 * 8));
                    uVar21 = (ulonglong)uVar36;
                  } while (uVar36 < *(uint *)(_DAT_ + 8));
                }
                uVar21 = 0;
                lVar4 = *(longlong *)(lVar25 + uVar18 * 8);
                if ((longlong)plVar33 <= lVar4) goto LAB_;
                lVar35 = **(longlong **)(lVar19 + 0x148);
                if ((*(longlong *)(lVar19 + 0x150) != 0) && (*(int *)(_DAT_ + 8) != 0)) {
                  do {
                    uVar36 = (int)uVar21 + 1;
                    lVar35 = lVar35 + **(longlong **)(*(longlong *)(lVar19 + 0x150) + uVar21 * 8);
                    uVar21 = (ulonglong)uVar36;
                  } while (uVar36 < *(uint *)(_DAT_ + 8));
                }
                lVar22 = 0x19;
                if (0x19 < (longlong)((double)lVar35 * dVar9)) {
                  lVar22 = (longlong)((double)lVar35 * dVar9);
                }
                plVar1 = (longlong *)(lVar25 + uVar18 * 8);
                LOCK();
                bVar44 = lVar4 == *plVar1;
                if (bVar44) {
                  *plVar1 = lVar22 + (longlong)plVar33;
                }
                UNLOCK();
              } while (!bVar44);
              bVar8 = true;
              plStack_e0 = plVar33;
              lStack_d8 = lVar4;
LAB_:
              lVar19 = lStack_d8;
              plVar33 = plStack_e0;
              if (bVar8) {
                lVar26 = *plStack_d0;
                uVar16 = func_0x(lStack_f0);
                (**(code **)(lVar26 + 0x2b8))(plVar37,uVar16);
                lVar25 = 0;
                uStack_a8 = 0;
                uStack_a4 = 0x8c0000;
                uStack_b6 = 0x40;
                uStack_aa = 0;
                lVar26 = **(longlong **)(*(longlong *)(lVar15 + 8) + 0x160);
                if (uVar24 < *(uint *)(lVar26 + 0x10)) {
                  puVar5 = *(uint **)(lVar26 + 8);
                  if (uVar24 < *puVar5) {
                    lVar25 = ((uVar41 & 0xffffffff) % (ulonglong)puVar5[9]) * 0x1c0 +
                             *(longlong *)
                              (*(longlong *)(puVar5 + 4) +
                              ((uVar41 & 0xffffffff) / (ulonglong)puVar5[9]) * 8);
                  }
                  else {
                    lVar25 = ((ulonglong)(uVar24 - *puVar5) % (ulonglong)puVar5[0x11]) * 0x1c0 +
                             *(longlong *)
                              (*(longlong *)(puVar5 + 0xc) +
                              ((ulonglong)(uVar24 - *puVar5) / (ulonglong)puVar5[0x11]) * 8);
                  }
                }
                uStack_80 = (ulonglong)*(uint *)(lVar25 + 0x3c);
                puStack_e8 = auStack_b8;
                auStack_a0._0_8_ = (ulonglong)*(uint6 *)(lVar15 + 0x14) << 0x10;
                auStack_a0._8_4_ = 4;
                uStack_94 = 0;
                auStack_90._8_8_ = lVar19;
                auStack_90._0_8_ = plVar33;
                uStack_104 = 0x40;
                iVar13 = func_0x(plVar37);
                if (iVar13 == 0) {
                  (**(code **)(*plVar37 + 0x270))(plVar37);
                }
                puStack_118 = auStack_78;
                (**(code **)(*plVar37 + 0x288))(plVar37,1,&uStack_104,&puStack_e8);
              }
            }
          }
        }
        uVar23 = uVar23 + 1;
        pplVar43 = pplVar43 + 10;
      } while (uVar23 < *(ushort *)(lStack_c8 + 0x62));
    }
  }
  func_0x(uStack_68 ^ (ulonglong)auStack_138);
  return;
code_r0x0010047c:
  uVar21 = (ulonglong)uVar31;
  uVar18 = (ulonglong)(uint)uVar31;
  if (-1 < (short)puVar38[(ulonglong)(uVar31 - 1) + 1]) goto LAB_;
  goto LAB_;
code_r0x00100e33:
  *puVar38 = *puVar38 | 1;
  uVar31 = *(short *)((longlong)plVar37 + 0x1c) - 1;
  *(ushort *)((longlong)plVar37 + 0x1c) = uVar31;
  if ((uVar31 == 0) || (uVar24 = (uint)uVar31, -1 < (short)puVar42[(ulonglong)(uVar31 - 1) + 1]))
  goto LAB_;
  goto LAB_;
code_r0x001015f3:
  *puVar38 = *puVar38 | 1;
  uVar31 = *(short *)((longlong)plVar37 + 0x1c) - 1;
  *(ushort *)((longlong)plVar37 + 0x1c) = uVar31;
  if ((uVar31 == 0) || (uVar24 = (uint)uVar31, -1 < (short)puVar42[(ulonglong)(uVar31 - 1) + 1]))
  goto LAB_;
  goto LAB_;
}

