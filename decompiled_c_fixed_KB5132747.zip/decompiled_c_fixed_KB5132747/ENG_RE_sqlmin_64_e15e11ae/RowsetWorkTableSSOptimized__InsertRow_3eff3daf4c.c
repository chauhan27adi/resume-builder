
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,undefined8 param_2,longlong *param_3,longlong param_4,
                 longlong **param_5)

{
  ushort *puVar1;
  undefined8 *puVar2;
  uint *puVar3;
  ushort uVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  longlong lVar7;
  ushort *puVar8;
  bool bVar9;
  uint *puVar10;
  longlong *plVar11;
  int *piVar12;
  longlong **pplVar13;
  char cVar14;
  short sVar15;
  ushort uVar16;
  ushort uVar17;
  undefined4 uVar18;
  longlong lVar19;
  longlong lVar20;
  undefined8 uVar21;
  ulonglong *puVar22;
  byte *pbVar23;
  longlong *plVar24;
  undefined uVar25;
  int iVar26;
  ulonglong uVar27;
  uint uVar28;
  int iVar29;
  longlong *plVar30;
  undefined *puVar31;
  undefined *puVar32;
  undefined *puVar33;
  uint uVar34;
  ulonglong uVar35;
  uint *puVar36;
  ulonglong uVar37;
  byte bVar38;
  ushort *puVar39;
  uint uVar40;
  uint uVar41;
  uint uVar42;
  longlong *plVar43;
  uint uVar44;
  undefined8 uStack_330;
  undefined auStack_328 [32];
  longlong *plStack_308;
  undefined8 uStack_300;
  longlong lStack_2d8;
  uint *puStack_2d0;
  undefined uStack_2c8;
  longlong *plStack_2c0;
  longlong *plStack_2b8;
  int *piStack_2b0;
  int iStack_2a8;
  uint uStack_2a4;
  uint uStack_2a0;
  uint uStack_29c;
  ulonglong uStack_298;
  longlong lStack_290;
  int iStack_288;
  uint uStack_280;
  undefined auStack_27c [4];
  int *apiStack_278 [2];
  longlong *plStack_268;
  uint *puStack_260;
  uint uStack_258;
  uint uStack_254;
  longlong lStack_250;
  longlong lStack_248;
  undefined8 uStack_240;
  undefined4 uStack_238;
  longlong lStack_230;
  undefined *puStack_218;
  undefined8 uStack_210;
  longlong **pplStack_208;
  int iStack_200;
  uint uStack_1f8;
  uint uStack_1f4;
  uint uStack_1f0;
  int iStack_1ec;
  longlong lStack_1e8;
  undefined auStack_1e0 [4];
  undefined auStack_1dc [4];
  undefined8 uStack_1d8;
  undefined auStack_1d0 [8];
  undefined auStack_1c8 [8];
  undefined auStack_1c0 [8];
  undefined auStack_1b8 [4];
  short sStack_1b4;
  ushort uStack_1b2;
  longlong lStack_1b0;
  longlong lStack_1a8;
  undefined8 uStack_190;
  undefined auStack_188 [16];
  undefined auStack_178 [16];
  undefined auStack_168 [64];
  undefined auStack_128 [224];
  ulonglong uStack_48;
  
  puVar31 = auStack_328;
  uStack_190 = 0xfffffffffffffffe;
  uStack_48 = _DAT_ ^ (ulonglong)&lStack_2d8;
  pplStack_208 = param_5;
  lVar19 = *(longlong *)(param_1 + 0x3f0);
  plVar43 = (longlong *)0x0;
  uVar40 = 0;
  lStack_1e8 = param_1;
  if (*(longlong *)(lVar19 + 0x10) == 0) {
    uStack_330 = 0x1001f9;
    lVar19 = func_0x(*(longlong *)(param_1 + 0x3b8) + 0xa0);
    if ((lVar19 == 0) &&
       (*(int *)(**(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160) + 0x18) == 0)) {
      puVar2 = (undefined8 *)(param_1 + 0x3b0);
      plVar24 = *(longlong **)(param_1 + 0x3f0);
      uStack_330 = 0x10023a;
      plStack_2b8 = plVar24;
      func_0x(auStack_168);
      lStack_290 = 0;
      iStack_288 = 0;
      uStack_254 = 0;
      uStack_240 = 0;
      uStack_238 = 0;
      uStack_330 = 0x100260;
      func_0x(auStack_1b8);
      bVar38 = *(byte *)(*(longlong *)(param_1 + 0x3b8) + 0x106) & 1;
      uVar16 = 0;
      puVar32 = auStack_328;
      uVar42 = uStack_254;
      if (param_3 != (longlong *)0x0) {
        if ((*(int *)(param_1 + 0x3d8) == *(int *)(param_3 + 1)) &&
           (*param_3 == (ulonglong)*(uint6 *)(param_1 + 0x3c4) * 0x10000)) {
          uStack_330 = 0x1002b0;
          sVar15 = (**(code **)*puVar2)(puVar2);
          if (*(short *)((longlong)param_3 + 0xc) != sVar15) goto LAB_;
          if (param_3[0x15] != 0) {
            LOCK();
            UNLOCK();
          }
        }
        else {
LAB_:
          uStack_330 = 0x1002d2;
          func_0x(param_3,puVar2);
        }
        uVar17 = *(ushort *)(param_3 + 7);
        uVar4 = *(ushort *)((longlong)param_3 + 0x62);
        plStack_268 = param_3;
        lStack_250 = param_4;
        if ((uVar17 >> 10 & 1) == 0) {
          lStack_248 = 0;
          uStack_210 = 0;
          puStack_260 = (uint *)param_3[0xe];
          if (puVar2 != (undefined8 *)0x0) {
            lVar19 = **(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160);
            uStack_240 = *(undefined8 *)(lVar19 + 0xa8);
            uStack_238 = *(undefined4 *)(lVar19 + 0xb0);
          }
          puVar32 = auStack_328;
          uStack_258 = (uint)uVar4;
          uVar42 = uStack_254 | 0x10;
        }
        else {
          if (uVar4 == 0) {
            piStack_2b0 = (int *)0x0;
            plVar30 = plVar43;
            uVar34 = uVar40;
          }
          else {
            uVar34 = (uint)uVar4 * 8;
            uStack_330 = 0x10037b;
            uVar16 = uVar4;
            lVar19 = func_0x(uVar4,uVar34,0xffffffffffffff0);
            lVar19 = -lVar19;
            plStack_2c0 = (longlong *)((longlong)&lStack_2d8 + lVar19);
            *(undefined8 *)(auStack_328 + lVar19 + -8) = 0x10039c;
            lVar20 = func_0x();
            lVar20 = -lVar20;
            puVar31 = auStack_328 + lVar20 + lVar19;
            piStack_2b0 = (int *)((longlong)&lStack_2d8 + lVar20 + lVar19);
            uVar4 = *(ushort *)(param_3 + 0xb);
            uVar42 = *(uint *)((longlong)param_3 + 0x54);
            uVar41 = 0x1f9e;
            if (uVar42 < 0x1f9f) {
LAB_:
              plVar24 = plStack_2b8;
              plVar30 = plStack_2c0;
              param_1 = lStack_1e8;
              uVar41 = uVar42;
              if (uVar42 == 0) goto LAB_;
            }
            else if (0x1f9d < uVar4) {
              uVar42 = (uint)uVar4;
              goto LAB_;
            }
            puStack_218 = auStack_1b8;
            *(undefined8 *)(auStack_328 + lVar20 + lVar19 + -8) = 0x1003e4;
            func_0x(auStack_1b8);
            uVar27 = (ulonglong)uVar41 + 0xf;
            if (uVar27 <= uVar41) {
              uVar27 = 0xffffffffffffff0;
            }
            uVar27 = uVar27 & 0xfffffffffffffff0;
            *(undefined8 *)(auStack_328 + lVar20 + lVar19 + -8) = 0x100405;
            func_0x();
            puVar31 = auStack_328 + -uVar27 + lVar20 + lVar19;
            lStack_1b0 = (longlong)&lStack_2d8 + -uVar27 + lVar20 + lVar19;
            sStack_1b4 = (short)uVar41 - uVar4;
            uVar16 = *(ushort *)((longlong)param_3 + 0x62);
            uVar17 = *(ushort *)(param_3 + 7);
            plVar24 = plStack_2b8;
            plVar30 = plStack_2c0;
            param_1 = lStack_1e8;
            uStack_1b2 = uVar4;
          }
LAB_:
          piVar12 = piStack_2b0;
          uVar41 = (uint)uVar16;
          lStack_248 = 0;
          uStack_210 = 0;
          puStack_260 = (uint *)param_3[0xe];
          if (param_1 != -0x3b0) {
            lVar19 = **(longlong **)(*(longlong *)(param_1 + 0x3b8) + 0x160);
            uStack_240 = *(undefined8 *)(lVar19 + 0xa8);
            uStack_238 = *(undefined4 *)(lVar19 + 0xb0);
          }
          puVar32 = puVar31;
          uStack_258 = uVar41;
          uVar42 = uStack_254 | 0x10;
          if (((uVar17 >> 10 & 1) != 0) && (param_4 != 0)) {
            uStack_254 = uStack_254 | 0x14;
            *(uint *)(puVar31 + 0x30) = uVar34;
            *(int **)(puVar31 + 0x28) = piVar12;
            *(uint *)(puVar31 + 0x20) = uVar34;
            *(undefined8 *)(puVar31 + -8) = 0x10050b;
            func_0x(&plStack_268,param_1 + 0x3b0,uVar41,plVar30);
            uVar42 = uStack_254;
          }
        }
      }
      uStack_254 = uVar42;
      plVar30 = plVar24 + 1;
      uVar42 = *(uint *)(plVar24 + 9);
      lVar19 = plVar24[8];
      uVar34 = *(uint *)(*(longlong *)(param_1 + 0x3b8) + 0xb0);
      iVar26 = *(int *)(*(longlong *)(param_1 + 0x3b8) + 0x100);
      if ((iVar26 == 0) || (iVar26 - 3U < 2)) {
        bVar9 = false;
      }
      else {
        bVar9 = true;
      }
      plStack_2c0 = plVar30;
      uStack_2a4 = uVar34;
      uStack_2a0 = uVar42;
      if ((*(byte *)(plStack_268 + 7) & 0x20) == 0) {
        plStack_2b8 = (longlong *)0x0;
        uVar41 = 0;
        if (bVar9) {
          plVar24 = plVar43;
          if ((uStack_254 & 0x10) != 0) {
            plVar24 = plStack_268;
          }
          uVar40 = -*(int *)(plVar24 + 2);
          uVar18 = *(undefined4 *)(plVar24 + 3);
          uVar6 = *(undefined4 *)((longlong)plVar24 + 0x14);
          uStack_29c = uVar40;
          *(undefined2 *)(puVar32 + 0x28) = 1;
          *(undefined4 *)(puVar32 + 0x20) = uVar18;
          if (bVar38 == 0) {
            *(undefined8 *)(puVar32 + -8) = 0x1024b2;
            func_0x(plVar30,lVar19,uVar42,uVar6);
          }
          else {
            *(undefined8 *)(puVar32 + -8) = 0x1024ab;
            func_0x();
          }
          puVar33 = puVar32;
          plVar24 = plVar43;
          if (uVar40 != 0) {
            *(undefined8 *)(puVar32 + -8) = 0x1024dc;
            lVar19 = func_0x();
            lVar19 = -lVar19;
            puVar33 = puVar32 + lVar19;
            plVar24 = (longlong *)(puVar32 + lVar19 + 0x50);
            plStack_2b8 = plVar24;
            *(undefined8 *)(puVar32 + lVar19 + -8) = 0x1024f2;
            func_0x(plVar24,0);
          }
          plVar11 = plStack_2b8;
          puStack_2d0 = (uint *)0x0;
          if (*(ushort *)((longlong)plStack_268 + 0x62) != 0) {
            puVar36 = puStack_260 + 0xe;
            uStack_298 = (ulonglong)*(ushort *)((longlong)plStack_268 + 0x62);
            do {
              puVar3 = puVar36 + -0xe;
              uVar40 = *puVar3;
              *(undefined8 *)(puVar33 + -8) = 0x102537;
              func_0x(&plStack_268,puVar3,&lStack_2d8);
              if ((char)lStack_2d8 == '\x03') {
                if (((*(ushort *)(*(longlong *)(puVar36 + 4) + 0xc) & 0x400) == 0) &&
                   ((puVar36[2] & 0x4000) == 0)) {
                  *(undefined8 *)(puVar33 + -8) = 0x10283b;
                  (*_DAT_)(6,0x51,0x10,3);
                }
                *(undefined8 *)(puVar33 + -8) = 0x10284c;
                func_0x(plVar30,puVar3,0,0);
                if ((int)uVar40 < 0) {
                  puVar3 = (uint *)((longlong)(int)~uVar40 * 0x20 + 0xc + (longlong)plVar11);
                  *puVar3 = *puVar3 | 2;
                }
              }
              else {
                if (*(short *)(puVar36 + -0xd) != 0) {
                  if (*(short *)plVar30 == 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x10255b;
                    func_0x();
                  }
                  else {
                    *(undefined8 *)(puVar33 + -8) = 0x102562;
                    func_0x((short *)((longlong)plVar30 + 2),puVar3);
                  }
                }
                *(undefined8 *)(puVar33 + -8) = 0x102572;
                func_0x(&plStack_268,puVar3,&puStack_2d0);
                puVar10 = puStack_2d0;
                cVar14 = *(char *)(puVar36 + 2);
                if ((cVar14 == '\x01') || (cVar14 == '\x02')) {
                  if ((puVar36[2] >> 8 & 1) == 0) {
                    uVar40 = *puVar3;
                    lVar19 = plVar30[1];
                    uVar5 = *(undefined2 *)(puVar36 + 1);
                    *(undefined8 *)(puVar33 + -8) = 0x1026e9;
                    func_0x((int)uVar40 + lVar19,puVar10,uVar5);
                  }
                  else {
                    if (((puVar36[2] >> 0xf & 1) == 0) || ((uStack_254 & 8) == 0)) {
                      lVar19 = lStack_250;
                      if ((*(byte *)(*(longlong *)(puVar36 + 4) + 0x2a) & 0x10) != 0) {
                        lVar19 = lStack_248;
                      }
                      uVar40 = *(uint *)(*(longlong *)(*(longlong *)(puVar36 + 4) + 0x18) + lVar19);
                    }
                    else {
                      uVar40 = *(uint *)(lStack_230 + (ulonglong)*puVar36 * 8);
                    }
                    uVar42 = (uint)*(ushort *)(puVar36 + 1);
                    if (uVar40 < uVar42) {
                      uVar34 = uVar42 - uVar40;
                    }
                    else {
                      uVar34 = uVar41;
                      if (uVar42 < uVar40) {
                        *(undefined8 *)(puVar33 + -8) = 0x10275d;
                        (*_DAT_)(6,0x5c,0x16);
                      }
                    }
                    uStack_2c8 = *(undefined *)(*(longlong *)(puVar36 + 4) + 0x24);
                    uVar42 = *puVar3;
                    lVar19 = plStack_2c0[1];
                    if ((puVar10 != (uint *)0x0) && (uVar40 != 0)) {
                      *(undefined8 *)(puVar33 + -8) = 0x10278b;
                      func_0x((int)uVar42 + lVar19,puVar10,uVar40);
                    }
                    uVar25 = uStack_2c8;
                    plVar30 = plStack_2c0;
                    if (uVar34 != 0) {
                      *(undefined8 *)(puVar33 + -8) = 0x1027a5;
                      func_0x
                                ((ulonglong)uVar40 + (int)uVar42 + lVar19,uVar25,uVar34);
                      plVar30 = plStack_2c0;
                    }
                  }
                }
                else if ((cVar14 == '\x03') || (cVar14 == '\x04')) {
                  uVar42 = puVar36[2];
                  if (((uVar42 >> 0xd & 1) == 0) || (uVar34 = uVar41, *puStack_2d0 != 0)) {
                    if (((uVar42 & 0x8000) == 0) || ((uStack_254 & 8) == 0)) {
                      lVar19 = *(longlong *)(puVar36 + 4);
                      if ((uVar42 >> 8 & 1) == 0) {
                        uVar34 = (uint)*(ushort *)(lVar19 + 2);
                      }
                      else {
                        lVar20 = lStack_250;
                        if ((*(byte *)(lVar19 + 0x2a) & 0x10) != 0) {
                          lVar20 = lStack_248;
                        }
                        uVar34 = *(uint *)(*(longlong *)(lVar19 + 0x18) + lVar20);
                      }
                    }
                    else {
                      uVar34 = *(uint *)(lStack_230 + (ulonglong)*puVar36 * 8);
                    }
                  }
                  if (*(ushort *)(puVar36 + 1) < uVar34) {
                    *(undefined8 *)(puVar33 + -8) = 0x10269b;
                    (*_DAT_)(6,0x52,0x16);
                  }
                  puVar10 = puStack_2d0;
                  *(undefined4 *)(puVar33 + 0x28) = 0;
                  *(uint **)(puVar33 + 0x20) = puVar3;
                  *(undefined8 *)(puVar33 + -8) = 0x1026c3;
                  func_0x(plVar11 + (longlong)(int)~uVar40 * 4,puVar10,uVar34);
                  plVar30 = plStack_2c0;
                }
                else if (cVar14 == '\b') {
                  if (*(short *)plVar30 == 0) {
                    *(undefined8 *)(puVar33 + -8) = 0x1025eb;
                    func_0x(plVar30,puVar3,puVar10);
                  }
                  else {
                    *(undefined4 *)(puVar33 + 0x28) = 0;
                    *(uint **)(puVar33 + 0x20) = puVar3;
                    puVar3 = puStack_2d0;
                    *(undefined8 *)(puVar33 + -8) = 0x102616;
                    func_0x(plVar11 + (longlong)(int)~uVar40 * 4,puVar3,1);
                  }
                }
                else {
                  *(undefined8 *)(puVar33 + 0x20) = 0x79d8e0;
                  *(undefined8 *)(puVar33 + -8) = 0x1025ca;
                  (*_DAT_)(1,0xba3c70,0xbd0638);
                }
              }
              puVar36 = puVar36 + 0x14;
              uStack_298 = uStack_298 - 1;
              plVar24 = plStack_2b8;
              uVar34 = uStack_2a4;
              uVar40 = uStack_29c;
            } while (uStack_298 != 0);
          }
          uVar42 = uStack_2a0;
          puVar32 = puVar33;
          if (uVar40 != 0) {
            if (*(short *)plVar30 == 0) {
              do {
                uVar27 = (ulonglong)uVar40;
                uVar41 = uVar40 - 1;
                if (*(int *)(plVar24 + (ulonglong)uVar41 * 4 + 1) != 0) {
                  *(short *)((longlong)plVar30 + 0x1c) = (short)uVar40;
                  iVar26 = *(int *)((longlong)plVar30 + 0x14) + 2 + uVar40 * 2;
                  *(int *)(plVar30 + 3) = iVar26;
                  *(int *)((longlong)plVar30 + 4) = iVar26;
                  *(byte *)plVar30[1] = *(byte *)plVar30[1] | 0x20;
                  if (*(uint *)((longlong)plVar30 + 4) <= uVar34) {
                    plVar43 = (longlong *)
                              ((ulonglong)*(uint *)((longlong)plVar30 + 0x14) + plVar30[1]);
                    *(short *)plVar43 = (short)uVar40;
                  }
                  if (uVar40 != 0) {
                    puVar36 = (uint *)((longlong)plVar24 + 0xc);
                    plVar24 = plStack_2c0;
                    do {
                      plVar43 = (longlong *)((longlong)plVar43 + 2);
                      uVar41 = *(uint *)((longlong)plVar24 + 4);
                      lVar19 = plVar24[1];
                      uVar44 = puVar36[-1];
                      uVar40 = uVar41 + uVar44;
                      *(uint *)((longlong)plVar24 + 4) = uVar40;
                      if ((uVar40 <= uVar34) && (uVar40 <= uVar42)) {
                        *(ushort *)plVar43 =
                             (ushort)((*puVar36 & 1) << 0xf) | (ushort)uVar40 & 0x7fff;
                        uVar21 = *(undefined8 *)(puVar36 + -3);
                        *(undefined8 *)(puVar33 + -8) = 0x102900;
                        func_0x((ulonglong)uVar41 + lVar19,uVar44,uVar21,uVar44);
                        plVar24 = plStack_2c0;
                      }
                      puVar36 = puVar36 + 8;
                      uVar27 = uVar27 - 1;
                    } while (uVar27 != 0);
                  }
                  break;
                }
                uVar40 = uVar41;
              } while (uVar41 != 0);
            }
            else {
              *(undefined **)(puVar33 + 0x28) = auStack_27c;
              *(longlong **)(puVar33 + 0x20) = plVar24;
              uVar42 = uStack_2a0;
              *(undefined8 *)(puVar33 + -8) = 0x102935;
              func_0x((short *)((longlong)plVar30 + 2),uVar42,uVar34,uVar40);
            }
          }
        }
        else {
          *(short *)plVar30 = 0;
          puVar1 = (ushort *)((longlong)plVar24 + 10);
          plVar30 = plVar43;
          if ((uStack_254 & 0x10) != 0) {
            plVar30 = plStack_268;
          }
          uVar34 = -*(int *)(plVar30 + 2);
          uVar25 = 0;
          if (bVar38 == 0) {
            uVar25 = 6;
          }
          iVar26 = 4;
          if (bVar38 == 0) {
            iVar26 = 1;
          }
          iVar29 = *(int *)((longlong)plVar30 + 0x14);
          uStack_29c = uVar34;
          puVar32[0x28] = uVar25;
          *(undefined4 *)(puVar32 + 0x20) = *(undefined4 *)(plVar30 + 3);
          *(undefined8 *)(puVar32 + -8) = 0x1005be;
          func_0x(puVar1,lVar19,uVar42,iVar29 - iVar26);
          plVar30 = plVar43;
          if (uVar34 != 0) {
            *(undefined8 *)(puVar32 + -8) = 0x1005e6;
            lVar19 = func_0x();
            lVar19 = -lVar19;
            plVar30 = (longlong *)(puVar32 + lVar19 + 0x50);
            plStack_2b8 = plVar30;
            *(undefined8 *)(puVar32 + lVar19 + -8) = 0x1005fc;
            func_0x(plVar30,0);
            puVar32 = puVar32 + lVar19;
          }
          uStack_1f0 = (uint)*(ushort *)((longlong)plStack_268 + 0x62);
          apiStack_278[0] = (int *)0x0;
          uStack_280 = 0;
          puStack_2d0 = puStack_260;
          puVar36 = puStack_260;
          if (uStack_1f0 != 0) {
            do {
              uVar42 = *puVar36;
              puStack_2d0 = puVar36;
              *(undefined8 *)(puVar32 + -8) = 0x100643;
              func_0x(&plStack_268,puVar36,&lStack_2d8);
              if ((char)lStack_2d8 == '\x03') {
                if (((*(ushort *)(*(longlong *)(puVar36 + 0x12) + 0xc) & 0x400) == 0) &&
                   ((puVar36[0x10] & 0x4000) == 0)) {
                  *(undefined8 *)(puVar32 + -8) = 0x102398;
                  (*_DAT_)(6,0x51,0x10,3);
                }
                *(undefined8 *)(puVar32 + -8) = 0x1023a9;
                func_0x(puVar1,puVar36,0,0);
                puStack_2d0 = puVar36;
                if ((int)uVar42 < 0) {
                  puVar3 = (uint *)((longlong)(int)~uVar42 * 0x20 + 0xc + (longlong)plVar30);
                  *puVar3 = *puVar3 | 2;
                }
              }
              else {
                if (*(short *)(puVar36 + 1) != 0) {
                  *(undefined8 *)(puVar32 + -8) = 0x100660;
                  func_0x(puVar1,puVar36);
                }
                *(undefined8 *)(puVar32 + -8) = 0x100670;
                func_0x(&plStack_268,puVar36,apiStack_278);
                piVar12 = apiStack_278[0];
                puVar3 = puStack_2d0;
                cVar14 = *(char *)(puVar36 + 0x10);
                if ((cVar14 == '\x01') || (cVar14 == '\x02')) {
                  if ((puVar36[0x10] >> 8 & 1) == 0) {
                    uVar42 = *puVar36;
                    lVar19 = plVar24[2];
                    uVar5 = *(undefined2 *)(puVar36 + 0xf);
                    *(undefined8 *)(puVar32 + -8) = 0x1022b0;
                    func_0x((int)uVar42 + lVar19,piVar12,uVar5);
                    puStack_2d0 = puVar36;
                  }
                  else {
                    if (((puVar36[0x10] & 0x8000) == 0) || ((uStack_254 & 8) == 0)) {
                      lVar19 = lStack_250;
                      if ((*(byte *)(*(longlong *)(puStack_2d0 + 0x12) + 0x2a) & 0x10) != 0) {
                        lVar19 = lStack_248;
                      }
                      uVar42 = *(uint *)(*(longlong *)(*(longlong *)(puStack_2d0 + 0x12) + 0x18) +
                                        lVar19);
                    }
                    else {
                      uVar42 = *(uint *)(lStack_230 + (ulonglong)puStack_2d0[0xe] * 8);
                    }
                    uVar34 = (uint)*(ushort *)(puStack_2d0 + 0xf);
                    if (uVar42 < uVar34) {
                      uVar44 = uVar34 - uVar42;
                    }
                    else {
                      uVar44 = uVar41;
                      if (uVar34 < uVar42) {
                        *(undefined8 *)(puVar32 + -8) = 0x102324;
                        (*_DAT_)(6,0x5c,0x16);
                      }
                    }
                    uVar25 = *(undefined *)(*(longlong *)(puVar3 + 0x12) + 0x24);
                    lVar19 = (longlong)(int)*puVar3 + plVar24[2];
                    if ((piVar12 != (int *)0x0) && (uVar42 != 0)) {
                      *(undefined8 *)(puVar32 + -8) = 0x10234b;
                      func_0x(lVar19,piVar12,uVar42);
                    }
                    if (uVar44 != 0) {
                      *(undefined8 *)(puVar32 + -8) = 0x102364;
                      func_0x((ulonglong)uVar42 + lVar19,uVar25,uVar44);
                    }
                  }
                }
                else if ((cVar14 == '\x03') || (cVar14 == '\x04')) {
                  uVar34 = puVar36[0x10];
                  if (((uVar34 >> 0xd & 1) == 0) || (uVar44 = uVar40, *apiStack_278[0] != 0)) {
                    if (((uVar34 & 0x8000) == 0) || ((uStack_254 & 8) == 0)) {
                      lVar19 = *(longlong *)(puVar36 + 0x12);
                      if ((uVar34 >> 8 & 1) == 0) {
                        uVar44 = (uint)*(ushort *)(lVar19 + 2);
                      }
                      else {
                        lVar20 = lStack_250;
                        if ((*(byte *)(lVar19 + 0x2a) & 0x10) != 0) {
                          lVar20 = lStack_248;
                        }
                        uVar44 = *(uint *)(*(longlong *)(lVar19 + 0x18) + lVar20);
                      }
                    }
                    else {
                      uVar44 = *(uint *)(lStack_230 + (ulonglong)puVar36[0xe] * 8);
                    }
                  }
                  if (*(ushort *)(puVar36 + 0xf) < uVar44) {
                    *(undefined8 *)(puVar32 + -8) = 0x102261;
                    (*_DAT_)(6,0x52,0x16);
                  }
                  piVar12 = apiStack_278[0];
                  *(undefined4 *)(puVar32 + 0x28) = 0;
                  *(uint **)(puVar32 + 0x20) = puVar36;
                  *(undefined8 *)(puVar32 + -8) = 0x102289;
                  func_0x(plVar30 + (longlong)(int)~uVar42 * 4,piVar12,uVar44);
                  puStack_2d0 = puVar36;
                }
                else if (cVar14 == '\b') {
                  piStack_2b0 = apiStack_278[0];
                  uVar42 = *puVar36;
                  lVar19 = (longlong)(int)uVar42;
                  if ((int)uVar42 < 0) {
                    if ((uVar42 & 0xc0000000) == 0x80000000) {
                      *(undefined8 *)(puVar32 + -8) = 0x10186d;
                      func_0x(auStack_128);
                      iStack_2a8 = 0;
                      if (*(int *)((longlong)plVar24 + 0xc) == 0) {
                        *puVar1 = 0;
                        uVar42 = *(uint *)(plVar24 + 3);
                        uVar27 = (ulonglong)uVar42;
                        *(uint *)((longlong)plVar24 + 0x1c) = uVar42;
                        pbVar23 = (byte *)plVar24[2];
                        bVar38 = *pbVar23;
                        if ((bVar38 & 0x10) != 0) {
                          uVar42 = uVar42 + (*(ushort *)(pbVar23 + uVar27) + 7 >> 3) + 2;
                          uVar27 = (ulonglong)uVar42;
                          *(uint *)((longlong)plVar24 + 0x1c) = uVar42;
                          bVar38 = *pbVar23;
                        }
                        if ((bVar38 & 0x20) == 0) {
                          *(int *)((longlong)plVar24 + 0xc) = (int)uVar27;
                          *(short *)((longlong)plVar24 + 0x24) = 0;
                          *(int *)(plVar24 + 4) = (int)uVar27;
                        }
                        else {
                          puVar39 = (ushort *)(pbVar23 + uVar27);
                          uVar16 = *puVar39;
                          *(ushort *)((longlong)plVar24 + 0x24) = uVar16;
                          if (uVar16 == 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x1018d8;
                            cVar14 = func_0x(0x1132970);
                            if (cVar14 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x1018e1;
                              lVar19 = func_0x();
                              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar32 + -8) = 0x1018fb;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x101917;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x10193d;
                                  (*_DAT_)(1,0xa2237c,0xb42468,0x80f);
                                }
                              }
                            }
                            lVar19 = plVar24[2];
                            *(undefined8 *)(puVar32 + -8) = 0x10194b;
                            func_0x(lVar19,3);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0x1c);
                            pbVar23 = (byte *)plVar24[2];
                            uVar16 = *(ushort *)((longlong)plVar24 + 0x24);
                          }
                          uVar42 = (int)uVar27 + (uVar16 + 1) * 2;
                          *(uint *)(plVar24 + 4) = uVar42;
                          if (0x1f9e < uVar42) {
                            *(undefined8 *)(puVar32 + -8) = 0x10197c;
                            cVar14 = func_0x(0x1132970);
                            if (cVar14 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x101985;
                              lVar19 = func_0x();
                              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar32 + -8) = 0x10199f;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x1019bb;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x1019e1;
                                  (*_DAT_)(1,0xa2237c,0xb42468,0x816);
                                }
                              }
                            }
                            lVar19 = plVar24[2];
                            *(undefined8 *)(puVar32 + -8) = 0x1019ef;
                            func_0x(lVar19,4);
                            uVar16 = *(ushort *)((longlong)plVar24 + 0x24);
                            pbVar23 = (byte *)plVar24[2];
                            uVar42 = *(uint *)(plVar24 + 4);
                          }
                          uVar27 = (ulonglong)uVar16;
                          uVar34 = puVar39[uVar27] & 0x7fff;
                          *(uint *)((longlong)plVar24 + 0xc) = uVar34;
                          if (uVar34 < uVar42) {
                            *(undefined8 *)(puVar32 + -8) = 0x101a1e;
                            cVar14 = func_0x(0x1132970);
                            if (cVar14 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x101a27;
                              lVar19 = func_0x();
                              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar32 + -8) = 0x101a41;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x101a5d;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x101a83;
                                  (*_DAT_)(1,0xa2237c,0xb42468,0x81d);
                                }
                              }
                            }
                            lVar19 = plVar24[2];
                            *(undefined8 *)(puVar32 + -8) = 0x101a91;
                            func_0x(lVar19,4);
                            uVar42 = *(uint *)(plVar24 + 4);
                            uVar27 = (ulonglong)*(ushort *)((longlong)plVar24 + 0x24);
                            pbVar23 = (byte *)plVar24[2];
                            uVar34 = *(uint *)((longlong)plVar24 + 0xc);
                          }
                          plVar30 = plVar43;
                          puVar8 = puVar39;
                          if ((short)uVar27 != 0) {
                            do {
                              uVar44 = puVar8[1] & 0x7fff;
                              if ((uVar44 < uVar42) ||
                                 (uVar34 = *(uint *)((longlong)plVar24 + 0xc), uVar34 < uVar44)) {
                                *(undefined8 *)(puVar32 + -8) = 0x101ad4;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x101add;
                                  lVar19 = func_0x();
                                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                    *(undefined8 *)(puVar32 + -8) = 0x101af7;
                                    cVar14 = func_0x(0x1132970);
                                    if (cVar14 == '\0') {
                                      *(undefined8 *)(puVar32 + -8) = 0x101b13;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      *(undefined8 *)(puVar32 + 0x20) = 0;
                                      *(undefined8 *)(puVar32 + -8) = 0x101b39;
                                      (*_DAT_)(1,0xa2237c,0xb42468,0x82a);
                                    }
                                  }
                                }
                                lVar19 = plVar24[2];
                                *(undefined8 *)(puVar32 + -8) = 0x101b47;
                                func_0x(lVar19,4);
                                uVar34 = *(uint *)((longlong)plVar24 + 0xc);
                              }
                              uVar28 = (int)plVar30 + 1;
                              uVar27 = (ulonglong)*(ushort *)((longlong)plVar24 + 0x24);
                              plVar30 = (longlong *)(ulonglong)uVar28;
                              uVar42 = uVar44;
                              puVar8 = puVar8 + 1;
                            } while ((int)uVar28 < (int)(uint)*(ushort *)((longlong)plVar24 + 0x24))
                            ;
                            pbVar23 = (byte *)plVar24[2];
                          }
                          uVar37 = uVar27;
                          if ((short)puVar39[(ulonglong)((int)uVar27 - 1) + 1] < 0) {
                            do {
                              sVar15 = (short)uVar37;
                              uVar42 = *(ushort *)
                                        (pbVar23 +
                                        uVar27 * 2 + (ulonglong)*(uint *)((longlong)plVar24 + 0x1c))
                                       & 0x7fff;
                              if ((int)uVar27 == 1) {
                                uVar34 = *(uint *)(plVar24 + 4);
                                uVar44 = uVar34;
LAB_:
                                if ((uVar42 < uVar34) ||
                                   (uVar28 = *(uint *)((longlong)plVar24 + 0xc), uVar28 < uVar42))
                                goto LAB_;
                              }
                              else {
                                uVar34 = *(ushort *)
                                          (pbVar23 +
                                          uVar27 * 2 +
                                          ((ulonglong)*(uint *)((longlong)plVar24 + 0x1c) - 2)) &
                                         0x7fff;
                                uVar44 = *(uint *)(plVar24 + 4);
                                if (uVar44 <= uVar34) goto LAB_;
LAB_:
                                *(undefined8 *)(puVar32 + -8) = 0x101bcc;
                                func_0x(pbVar23,7);
                                uVar44 = *(uint *)(plVar24 + 4);
                                uVar28 = *(uint *)((longlong)plVar24 + 0xc);
                                pbVar23 = (byte *)plVar24[2];
                                sVar15 = *(short *)((longlong)plVar24 + 0x24);
                              }
                              if ((uVar34 < uVar44) || (uVar28 < uVar34)) goto LAB_;
                              if (*(ushort *)(pbVar23 + uVar34) == 5) {
                                *puVar1 = *puVar1 | 2;
                                *(short *)((longlong)plVar24 + 0x24) = sVar15 + -1;
                                uVar37 = (ulonglong)(uVar34 & 0xffff);
                                *(short *)((longlong)plVar24 + 0x32) = (short)uVar34;
                                uVar27 = plVar24[2];
                                uVar16 = *(ushort *)(uVar27 + 2 + uVar37);
                                uVar17 = *(ushort *)((longlong)plVar24 + 0x34) & 0xc7ff;
                                if ((uVar16 >> 0xe & 1) != 0) {
                                  uVar17 = uVar16 & 0x3800 | uVar17;
                                }
                                *(ushort *)((longlong)plVar24 + 0x34) = uVar17;
                                uVar16 = (uVar17 ^ *(ushort *)(uVar37 + 2 + uVar27)) & 0x7ff ^
                                         uVar17;
                                *(ushort *)((longlong)plVar24 + 0x34) = uVar16;
                                uVar35 = (ulonglong)((uVar16 & 0x7ff) * 2) + 4 +
                                         uVar37 + (uVar17 >> 0xb & 7) * 2 + uVar27;
                                if (uVar35 < uVar37 + uVar27) {
                                  *(undefined8 *)(puVar32 + -8) = 0x101cdc;
                                  func_0x(uVar37 + uVar27,0x19);
                                  uVar16 = *(ushort *)((longlong)plVar24 + 0x34);
                                  uVar37 = (ulonglong)*(ushort *)((longlong)plVar24 + 0x32);
                                  uVar27 = (ulonglong)*(uint *)(plVar24 + 2);
                                }
                                if (uVar42 - uVar34 <
                                    (((uVar16 & 0x7ff) * 2 - (int)uVar37) - (int)uVar27) +
                                    (int)uVar35) {
                                  lVar19 = plVar24[2];
                                  *(undefined8 *)(puVar32 + -8) = 0x101d15;
                                  func_0x(uVar37 + lVar19,0x19);
                                  uVar16 = *(ushort *)((longlong)plVar24 + 0x34);
                                }
                                if (((uVar16 & 0x3800) != 0) &&
                                   (puVar39 = (ushort *)
                                              (plVar24[2] + 4 +
                                              (ulonglong)*(ushort *)((longlong)plVar24 + 0x32)),
                                   plVar30 = plVar43, (uVar16 & 0x3800) != 0)) {
                                  do {
                                    if ((uVar16 & 0x7ff) < (*puVar39 & 0x7ff)) {
                                      uVar16 = *(ushort *)((longlong)plVar24 + 0x32);
                                      lVar19 = plVar24[2];
                                      *(undefined8 *)(puVar32 + -8) = 0x101d67;
                                      func_0x((ulonglong)uVar16 + lVar19,0x1a);
                                      uVar16 = *(ushort *)((longlong)plVar24 + 0x34);
                                    }
                                    uVar42 = (int)plVar30 + 1;
                                    plVar30 = (longlong *)(ulonglong)uVar42;
                                    puVar39 = puVar39 + 1;
                                  } while ((int)uVar42 < (int)(uVar16 >> 0xb & 7));
                                }
                                uVar34 = *(uint *)((longlong)plStack_2c0 + 4);
                                goto LAB_;
                              }
                              if (*(ushort *)(pbVar23 + uVar34) < 0x400) break;
                              *puVar1 = *puVar1 | 1;
                              uVar16 = sVar15 - 1;
                              *(ushort *)((longlong)plVar24 + 0x24) = uVar16;
                              if (uVar16 == 0) break;
                              uVar27 = (ulonglong)(uint)uVar16;
                              uVar37 = (ulonglong)uVar16;
                            } while ((short)puVar39[(ulonglong)(uVar16 - 1) + 1] < 0);
                            uVar27 = (ulonglong)uVar28;
                            pbVar23 = (byte *)plVar24[2];
                          }
                          else {
LAB_:
                            uVar27 = (ulonglong)uVar34;
                            pbVar23 = (byte *)plVar24[2];
                          }
                        }
                        if ((*pbVar23 & 0x40) == 0) {
                          *(undefined4 *)((longlong)plVar24 + 0x2e) = 0;
                        }
                        else {
                          *(int *)((longlong)plVar24 + 0x2e) = (int)uVar27;
                          *(int *)((longlong)plVar24 + 0xc) = (int)uVar27 + 0xe;
                          *(undefined8 *)(puVar32 + -8) = 0x101db1;
                          uVar21 = func_0x(puVar1);
                          *(undefined8 *)(puVar32 + -8) = 0x101dc0;
                          func_0x(uVar21,auStack_1c0);
                          *(undefined8 *)(puVar32 + -8) = 0x101dcc;
                          iVar26 = func_0x(auStack_1c0);
                          *(int *)((longlong)plVar24 + 0xc) =
                               *(int *)((longlong)plVar24 + 0xc) + iVar26;
                          uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0xc);
                          pbVar23 = (byte *)plVar24[2];
                        }
                        if ((*(byte **)((longlong)plVar24 + 0x26) != (byte *)0x0) &&
                           (*(byte **)((longlong)plVar24 + 0x26) < pbVar23 + uVar27)) {
                          *(undefined8 *)(puVar32 + -8) = 0x101e05;
                          cVar14 = func_0x(0x1132970);
                          if (cVar14 != '\0') {
                            *(undefined8 *)(puVar32 + -8) = 0x101e0e;
                            lVar19 = func_0x();
                            if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar32 + -8) = 0x101e28;
                              cVar14 = func_0x(0x1132970);
                              if (cVar14 == '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x101e44;
                                (*_DAT_)(0x22,0x44,0x15,0x3fa);
                              }
                              else {
                                *(undefined8 *)(puVar32 + 0x20) = 0;
                                *(undefined8 *)(puVar32 + -8) = 0x101e6a;
                                (*_DAT_)(1,0xa2237c,0xb42468,0x886);
                              }
                            }
                          }
                          lVar19 = plVar24[2];
                          *(undefined8 *)(puVar32 + -8) = 0x101e78;
                          func_0x(lVar19,0x12);
                          uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0xc);
                        }
                        if (0x3f3b < (int)uVar27 - 1U) {
                          *(undefined8 *)(puVar32 + -8) = 0x101e93;
                          cVar14 = func_0x(0x1132970);
                          if (cVar14 != '\0') {
                            *(undefined8 *)(puVar32 + -8) = 0x101e9c;
                            lVar19 = func_0x();
                            if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar32 + -8) = 0x101eb6;
                              cVar14 = func_0x(0x1132970);
                              if (cVar14 == '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x101ed2;
                                (*_DAT_)(0x22,0x44,0x15,0x3ed);
                              }
                              else {
                                *(undefined8 *)(puVar32 + 0x20) = 0;
                                *(undefined8 *)(puVar32 + -8) = 0x101ef8;
                                (*_DAT_)(1,0xa2237c,0xb42468,0x88b);
                              }
                            }
                          }
                          lVar19 = plVar24[2];
                          *(undefined8 *)(puVar32 + -8) = 0x101f06;
                          func_0x(lVar19,5);
                        }
                      }
LAB_:
                      *(undefined8 *)(puVar32 + -8) = 0x101f0e;
                      func_0x(puVar1);
                      bVar38 = *(byte *)plVar24[2];
                      if ((bVar38 >> 6 & 1) != 0) {
                        *(undefined8 *)(puVar32 + -8) = 0x101f2f;
                        func_0x(puVar1,auStack_128);
                      }
                      if ((*(byte *)puVar1 & 1) != 0) {
                        *(undefined8 *)(puVar32 + -8) = 0x101f45;
                        puVar22 = (ulonglong *)func_0x(puVar1,0x400,&iStack_2a8);
                        uStack_298 = *puVar22;
                      }
                      pbVar23 = (byte *)plVar24[2];
                      if ((*pbVar23 & 0x20) == 0) {
                        *(undefined8 *)(puVar32 + -8) = 0x101f6b;
                        func_0x(puVar1);
                        pbVar23 = (byte *)plVar24[2];
                      }
                      uVar42 = *(uint *)((longlong)plVar24 + 0x1c);
                      *(undefined8 *)(puVar32 + -8) = 0x101f7e;
                      iVar26 = func_0x(puVar1);
                      lVar19 = plVar24[2];
                      uVar16 = *(ushort *)((longlong)plVar24 + 0x24);
                      uVar27 = (ulonglong)uVar16;
                      puVar39 = (ushort *)((ulonglong)*(uint *)((longlong)plVar24 + 0x1c) + lVar19);
                      uVar34 = (uint)uVar16;
                      if (iVar26 == 0) {
                        uVar44 = *(uint *)((longlong)plVar24 + 0x1c) + 2 + (uint)uVar16 * 2;
                        plVar30 = plVar43;
                        if (*puVar39 != 0) {
                          do {
                            uVar17 = puVar39[(longlong)plVar30 + 1];
                            puVar39[((ulonglong)plVar30 & 0xffff) + 1] =
                                 puVar39[((ulonglong)plVar30 & 0xffff) + 1] & 0x8000;
                            puVar39[((ulonglong)plVar30 & 0xffff) + 1] =
                                 puVar39[((ulonglong)plVar30 & 0xffff) + 1] |
                                 (uVar17 & 0x7fff) + 2 & 0x7fff;
                            uVar28 = (int)plVar30 + 1;
                            plVar30 = (longlong *)(ulonglong)uVar28;
                          } while (uVar28 < *puVar39);
                          lVar19 = plVar24[2];
                        }
                        lVar19 = (ulonglong)uVar44 + lVar19;
                        iVar26 = *(int *)((longlong)plVar24 + 0xc);
                        *(undefined8 *)(puVar32 + -8) = 0x102069;
                        func_0x(lVar19 + 2,lVar19,iVar26 - uVar44);
                        *(int *)((longlong)plVar24 + 0xc) = *(int *)((longlong)plVar24 + 0xc) + 2;
                        *(int *)(plVar24 + 4) = *(int *)(plVar24 + 4) + 2;
                        uVar17 = (ushort)*(undefined4 *)(plVar24 + 4);
                        if (uVar34 != 0) {
                          uVar17 = puVar39[(ulonglong)(uVar16 - 1) + 1] & 0x7fff;
                        }
                        if (uVar34 < uVar16 + 1) {
                          do {
                            puVar39[(uVar27 & 0xffff) + 1] = uVar17 & 0x7fff;
                            uVar34 = (int)uVar27 + 1;
                            uVar27 = (ulonglong)uVar34;
                          } while (uVar34 < uVar16 + 1);
                        }
                        *puVar39 = *puVar39 + 1;
                        *(undefined8 *)(puVar32 + -8) = 0x1020ab;
                        func_0x(puVar1);
                        uVar16 = *(ushort *)
                                  (pbVar23 +
                                  (ulonglong)*(ushort *)((longlong)plVar24 + 0x24) * 2 +
                                  (ulonglong)uVar42 + 2);
                        *(undefined8 *)(puVar32 + -8) = 0x1020c4;
                        func_0x(auStack_178);
                        *(undefined4 *)(puVar32 + 0x28) = 0;
                        *(uint **)(puVar32 + 0x20) = puStack_2d0;
                        piVar12 = piStack_2b0;
                        *(undefined8 *)(puVar32 + -8) = 0x1020e8;
                        func_0x(auStack_188,piVar12,1);
                        *(int **)(puVar32 + 0x28) = &iStack_1ec;
                        *(undefined **)(puVar32 + 0x20) = auStack_188;
                        *(undefined8 *)(puVar32 + -8) = 0x102123;
                        func_0x((short *)((longlong)plVar24 + 0x32),uVar16 & 0x7fff,0x1f9e);
                        uVar34 = uVar40;
                        iVar26 = iStack_1ec;
                      }
                      else {
                        if (uVar34 == 0) {
                          uVar34 = *(uint *)(plStack_2c0 + 3);
                          uVar44 = puVar39[uVar27 + 1] & 0x7fff;
LAB_:
                          if ((uVar44 < uVar34) || (*(uint *)((longlong)plVar24 + 0xc) < uVar44))
                          goto LAB_;
                        }
                        else {
                          uVar34 = puVar39[uVar27] & 0x7fff;
                          uVar44 = puVar39[uVar27 + 1] & 0x7fff;
                          if (*(uint *)(plStack_2c0 + 3) <= uVar34) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar32 + -8) = 0x101fde;
                          func_0x(lVar19,7);
                        }
                        piVar12 = piStack_2b0;
                        puVar36 = puStack_2d0;
                        *(undefined8 *)(puVar32 + -8) = 0x101ffb;
                        iVar26 = func_0x((short *)((longlong)plVar24 + 0x32),puVar36,piVar12
                                                );
                        uVar34 = uVar44 - uVar34;
                      }
                      iVar29 = (iVar26 - uVar34) + *(int *)((longlong)plVar24 + 0xc);
                      *(int *)((longlong)plVar24 + 0xc) = iVar29;
                      if ((*(byte *)puVar1 & 1) != 0) {
                        *(ushort *)
                         (pbVar23 +
                         (ulonglong)*(ushort *)((longlong)plVar24 + 0x24) * 2 +
                         (ulonglong)uVar42 + 4) = (ushort)iVar29 | 0x8000;
                        iVar29 = (*(int *)((longlong)plVar24 + 0xc) - iStack_2a8) + -2;
                      }
                      *(ushort *)
                       (pbVar23 +
                       (ulonglong)*(ushort *)((longlong)plVar24 + 0x24) * 2 + (ulonglong)uVar42 + 2)
                           = (ushort)iVar29 | 0x8000;
                      if (iVar26 == 0) {
                        uVar16 = *(ushort *)((longlong)plVar24 + 0x24);
                        *(undefined8 *)(puVar32 + -8) = 0x102176;
                        func_0x(puVar1,uVar16 + 1);
                        if ((*(byte *)plVar24[2] & 0x20) != 0) {
                          *(short *)((longlong)plVar24 + 0x24) =
                               *(short *)((longlong)plVar24 + 0x24) + 1;
                          *puVar1 = *puVar1 & 0xfffd;
                          *(undefined8 *)(puVar32 + -8) = 0x102193;
                          func_0x((short *)((longlong)plVar24 + 0x32));
                        }
                      }
                      else {
                        *puVar1 = *puVar1 | 2;
                        *(undefined8 *)(puVar32 + -8) = 0x1021a2;
                        sVar15 = func_0x(puVar1,auStack_27c);
                        *(short *)((longlong)plVar24 + 0x32) = sVar15;
                      }
                      iVar26 = iStack_2a8;
                      if ((*(byte *)puVar1 & 1) != 0) {
                        *(undefined8 *)(puVar32 + -8) = 0x1021c0;
                        func_0x(puVar1,0x400,iVar26);
                      }
                      if ((bVar38 >> 6 & 1) != 0) {
                        *(undefined8 *)(puVar32 + -8) = 0x1021d4;
                        func_0x(puVar1,auStack_128);
                      }
                    }
                    else {
                      if (*(int *)((longlong)plVar24 + 0xc) == 0) {
                        *puVar1 = 0;
                        uVar42 = *(uint *)(plVar24 + 3);
                        uVar27 = (ulonglong)uVar42;
                        *(uint *)((longlong)plVar24 + 0x1c) = uVar42;
                        pbVar23 = (byte *)plVar24[2];
                        bVar38 = *pbVar23;
                        if ((bVar38 & 0x10) != 0) {
                          uVar42 = uVar42 + (*(ushort *)(pbVar23 + uVar27) + 7 >> 3) + 2;
                          uVar27 = (ulonglong)uVar42;
                          *(uint *)((longlong)plVar24 + 0x1c) = uVar42;
                          bVar38 = *pbVar23;
                        }
                        if ((bVar38 & 0x20) == 0) {
                          *(int *)((longlong)plVar24 + 0xc) = (int)uVar27;
                          *(short *)((longlong)plVar24 + 0x24) = 0;
                          *(int *)(plVar24 + 4) = (int)uVar27;
                        }
                        else {
                          puVar39 = (ushort *)(pbVar23 + uVar27);
                          uVar16 = *puVar39;
                          *(ushort *)((longlong)plVar24 + 0x24) = uVar16;
                          if (uVar16 == 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x100ee7;
                            cVar14 = func_0x(0x1132970);
                            if (cVar14 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x100ef0;
                              lVar19 = func_0x();
                              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar32 + -8) = 0x100f0a;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x100f26;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x100f4c;
                                  (*_DAT_)(1,0xa2237c,0xb42468,0x80f);
                                }
                              }
                            }
                            lVar19 = plVar24[2];
                            *(undefined8 *)(puVar32 + -8) = 0x100f5a;
                            func_0x(lVar19,3);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0x1c);
                            uVar16 = *(ushort *)((longlong)plVar24 + 0x24);
                          }
                          uVar42 = (int)uVar27 + (uVar16 + 1) * 2;
                          *(uint *)(plVar24 + 4) = uVar42;
                          if (0x1f9e < uVar42) {
                            *(undefined8 *)(puVar32 + -8) = 0x100f8a;
                            cVar14 = func_0x(0x1132970);
                            if (cVar14 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x100f93;
                              lVar19 = func_0x();
                              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar32 + -8) = 0x100fad;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x100fc9;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x100fef;
                                  (*_DAT_)(1,0xa2237c,0xb42468,0x816);
                                }
                              }
                            }
                            lVar19 = plVar24[2];
                            *(undefined8 *)(puVar32 + -8) = 0x100ffd;
                            func_0x(lVar19,4);
                            uVar16 = *(ushort *)((longlong)plVar24 + 0x24);
                            uVar42 = *(uint *)(plVar24 + 4);
                          }
                          uVar27 = (ulonglong)uVar16;
                          uVar16 = puVar39[uVar27];
                          *(uint *)((longlong)plVar24 + 0xc) = uVar16 & 0x7fff;
                          if ((uVar16 & 0x7fff) < uVar42) {
                            *(undefined8 *)(puVar32 + -8) = 0x10102a;
                            cVar14 = func_0x(0x1132970);
                            if (cVar14 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x101033;
                              lVar19 = func_0x();
                              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar32 + -8) = 0x10104d;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x101069;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x10108f;
                                  (*_DAT_)(1,0xa2237c,0xb42468,0x81d);
                                }
                              }
                            }
                            lVar19 = plVar24[2];
                            *(undefined8 *)(puVar32 + -8) = 0x10109d;
                            func_0x(lVar19,4);
                            uVar42 = *(uint *)(plVar24 + 4);
                            uVar27 = (ulonglong)*(ushort *)((longlong)plVar24 + 0x24);
                          }
                          plVar30 = plVar43;
                          puVar8 = puVar39;
                          if ((short)uVar27 != 0) {
                            do {
                              uVar34 = puVar8[1] & 0x7fff;
                              if ((uVar34 < uVar42) || (*(uint *)((longlong)plVar24 + 0xc) < uVar34)
                                 ) {
                                *(undefined8 *)(puVar32 + -8) = 0x1010dd;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x1010e6;
                                  lVar19 = func_0x();
                                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                    *(undefined8 *)(puVar32 + -8) = 0x101100;
                                    cVar14 = func_0x(0x1132970);
                                    if (cVar14 == '\0') {
                                      *(undefined8 *)(puVar32 + -8) = 0x10111c;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      *(undefined8 *)(puVar32 + 0x20) = 0;
                                      *(undefined8 *)(puVar32 + -8) = 0x101142;
                                      (*_DAT_)(1,0xa2237c,0xb42468,0x82a);
                                    }
                                  }
                                }
                                lVar19 = plVar24[2];
                                *(undefined8 *)(puVar32 + -8) = 0x101150;
                                func_0x(lVar19,4);
                              }
                              uVar44 = (int)plVar30 + 1;
                              uVar27 = (ulonglong)*(ushort *)((longlong)plVar24 + 0x24);
                              plVar30 = (longlong *)(ulonglong)uVar44;
                              puVar8 = puVar8 + 1;
                              uVar42 = uVar34;
                            } while ((int)uVar44 < (int)(uint)*(ushort *)((longlong)plVar24 + 0x24))
                            ;
                          }
                          if ((short)puVar39[(ulonglong)((int)uVar27 - 1) + 1] < 0) {
                            pbVar23 = (byte *)plVar24[2];
                            do {
                              uVar42 = *(ushort *)
                                        (pbVar23 +
                                        uVar27 * 2 + (ulonglong)*(uint *)((longlong)plVar24 + 0x1c))
                                       & 0x7fff;
                              if ((int)uVar27 == 1) {
                                uVar34 = *(uint *)(plVar24 + 4);
                                uVar44 = uVar34;
LAB_:
                                if ((uVar42 < uVar34) ||
                                   (*(uint *)((longlong)plVar24 + 0xc) < uVar42)) goto LAB_;
                              }
                              else {
                                uVar34 = *(ushort *)
                                          (pbVar23 +
                                          uVar27 * 2 +
                                          ((ulonglong)*(uint *)((longlong)plVar24 + 0x1c) - 2)) &
                                         0x7fff;
                                uVar44 = *(uint *)(plVar24 + 4);
                                if (uVar44 <= uVar34) goto LAB_;
LAB_:
                                *(undefined8 *)(puVar32 + -8) = 0x1011c5;
                                func_0x(pbVar23,7);
                                uVar44 = *(uint *)(plVar24 + 4);
                              }
                              if ((uVar34 < uVar44) || (*(uint *)((longlong)plVar24 + 0xc) < uVar34)
                                 ) goto LAB_;
                              pbVar23 = (byte *)plVar24[2];
                              if (*(ushort *)(pbVar23 + uVar34) == 5) {
                                *puVar1 = *puVar1 | 2;
                                *(short *)((longlong)plVar24 + 0x24) =
                                     *(short *)((longlong)plVar24 + 0x24) + -1;
                                uVar27 = (ulonglong)(uVar34 & 0xffff);
                                *(short *)((longlong)plVar24 + 0x32) = (short)uVar34;
                                uVar16 = *(ushort *)((longlong)plVar24 + 0x34) & 0xc7ff;
                                if ((*(ushort *)(pbVar23 + uVar27 + 2) >> 0xe & 1) != 0) {
                                  uVar16 = *(ushort *)(pbVar23 + uVar27 + 2) & 0x3800 | uVar16;
                                }
                                *(ushort *)((longlong)plVar24 + 0x34) = uVar16;
                                uVar17 = (uVar16 ^ *(ushort *)(pbVar23 + uVar27 + 2)) & 0x7ff ^
                                         uVar16;
                                *(ushort *)((longlong)plVar24 + 0x34) = uVar17;
                                uVar37 = plVar24[2];
                                uVar35 = (ulonglong)((uVar17 & 0x7ff) * 2) + 4 +
                                         uVar37 + (uVar16 >> 0xb & 7) * 2 + uVar27;
                                if (uVar35 < uVar37 + uVar27) {
                                  *(undefined8 *)(puVar32 + -8) = 0x1012d0;
                                  func_0x(uVar37 + uVar27,0x19);
                                  uVar17 = *(ushort *)((longlong)plVar24 + 0x34);
                                  uVar27 = (ulonglong)*(ushort *)((longlong)plVar24 + 0x32);
                                  uVar37 = (ulonglong)*(uint *)(plVar24 + 2);
                                }
                                if (uVar42 - uVar34 <
                                    (((uVar17 & 0x7ff) * 2 - (int)uVar27) - (int)uVar37) +
                                    (int)uVar35) {
                                  lVar19 = plVar24[2];
                                  *(undefined8 *)(puVar32 + -8) = 0x101309;
                                  func_0x(uVar27 + lVar19,0x19);
                                  uVar17 = *(ushort *)((longlong)plVar24 + 0x34);
                                }
                                if (((uVar17 & 0x3800) != 0) &&
                                   (puVar39 = (ushort *)
                                              (plVar24[2] + 4 +
                                              (ulonglong)*(ushort *)((longlong)plVar24 + 0x32)),
                                   plVar30 = plVar43, (uVar17 & 0x3800) != 0)) {
                                  do {
                                    if ((uVar17 & 0x7ff) < (*puVar39 & 0x7ff)) {
                                      uVar16 = *(ushort *)((longlong)plVar24 + 0x32);
                                      lVar19 = plVar24[2];
                                      *(undefined8 *)(puVar32 + -8) = 0x101367;
                                      func_0x((ulonglong)uVar16 + lVar19,0x1a);
                                      uVar17 = *(ushort *)((longlong)plVar24 + 0x34);
                                    }
                                    uVar42 = (int)plVar30 + 1;
                                    puVar39 = puVar39 + 1;
                                    plVar30 = (longlong *)(ulonglong)uVar42;
                                  } while ((int)uVar42 < (int)(uVar17 >> 0xb & 7));
                                }
                                goto LAB_;
                              }
                              if (*(ushort *)(pbVar23 + uVar34) < 0x400) goto LAB_;
                              *puVar1 = *puVar1 | 1;
                              uVar16 = *(short *)((longlong)plVar24 + 0x24) - 1;
                              *(ushort *)((longlong)plVar24 + 0x24) = uVar16;
                              if (uVar16 == 0) goto LAB_;
                              uVar27 = (ulonglong)uVar16;
                            } while ((short)puVar39[(ulonglong)(uVar16 - 1) + 1] < 0);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0xc);
                          }
                          else {
LAB_:
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0xc);
                            pbVar23 = (byte *)plVar24[2];
                          }
                        }
                        if ((*pbVar23 & 0x40) == 0) {
                          *(undefined4 *)((longlong)plVar24 + 0x2e) = 0;
                        }
                        else {
                          *(int *)((longlong)plVar24 + 0x2e) = (int)uVar27;
                          *(int *)((longlong)plVar24 + 0xc) = (int)uVar27 + 0xe;
                          *(undefined8 *)(puVar32 + -8) = 0x1013ad;
                          uVar21 = func_0x(puVar1);
                          *(undefined8 *)(puVar32 + -8) = 0x1013bc;
                          func_0x(uVar21,auStack_1c8);
                          *(undefined8 *)(puVar32 + -8) = 0x1013c8;
                          iVar26 = func_0x(auStack_1c8);
                          *(int *)((longlong)plVar24 + 0xc) =
                               *(int *)((longlong)plVar24 + 0xc) + iVar26;
                          uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0xc);
                        }
                        iVar26 = (int)uVar27;
                        if ((*(ulonglong *)((longlong)plVar24 + 0x26) != 0) &&
                           (*(ulonglong *)((longlong)plVar24 + 0x26) < uVar27 + plVar24[2])) {
                          *(undefined8 *)(puVar32 + -8) = 0x1013fd;
                          cVar14 = func_0x(0x1132970);
                          if (cVar14 != '\0') {
                            *(undefined8 *)(puVar32 + -8) = 0x101406;
                            lVar19 = func_0x();
                            if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar32 + -8) = 0x101420;
                              cVar14 = func_0x(0x1132970);
                              if (cVar14 == '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x10143c;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar32 + 0x20) = 0;
                                *(undefined8 *)(puVar32 + -8) = 0x101462;
                                (*_DAT_)(1,0xa2237c,0xb42468);
                              }
                            }
                          }
                          lVar19 = plVar24[2];
                          *(undefined8 *)(puVar32 + -8) = 0x101470;
                          func_0x(lVar19,0x12);
                          iVar26 = *(int *)((longlong)plVar24 + 0xc);
                        }
                        if (0x3f3b < iVar26 - 1U) {
                          *(undefined8 *)(puVar32 + -8) = 0x101489;
                          cVar14 = func_0x(0x1132970);
                          if (cVar14 != '\0') {
                            *(undefined8 *)(puVar32 + -8) = 0x101492;
                            lVar19 = func_0x();
                            if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar32 + -8) = 0x1014ac;
                              cVar14 = func_0x(0x1132970);
                              if (cVar14 == '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x1014c8;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar32 + 0x20) = 0;
                                *(undefined8 *)(puVar32 + -8) = 0x1014ee;
                                (*_DAT_)(1,0xa2237c,0xb42468);
                              }
                            }
                          }
                          lVar19 = plVar24[2];
                          *(undefined8 *)(puVar32 + -8) = 0x1014fc;
                          func_0x(lVar19,5);
                        }
                      }
LAB_:
                      uVar42 = -*puStack_2d0;
                      uStack_1f8 = uVar42;
                      *(undefined8 *)(puVar32 + -8) = 0x101519;
                      func_0x(auStack_128);
                      pbVar23 = (byte *)plVar24[2];
                      bVar38 = *pbVar23;
                      uStack_1f4 = bVar38 >> 6 & 1;
                      if ((bVar38 >> 6 & 1) != 0) {
                        *(undefined8 *)(puVar32 + -8) = 0x101540;
                        func_0x(puVar1,auStack_128);
                        pbVar23 = (byte *)plVar24[2];
                        bVar38 = *pbVar23;
                      }
                      if ((bVar38 & 0x20) == 0) {
                        *(undefined8 *)(puVar32 + -8) = 0x101554;
                        func_0x(puVar1);
                        pbVar23 = (byte *)plVar24[2];
                      }
                      uVar16 = *(ushort *)((longlong)plVar24 + 0x24);
                      uVar27 = (ulonglong)uVar16;
                      if (uVar16 < uVar42) {
                        iVar26 = uVar42 - uVar16;
                        puVar39 = (ushort *)(pbVar23 + *(uint *)((longlong)plVar24 + 0x1c));
                        uVar44 = *(uint *)((longlong)plVar24 + 0x1c) + (uVar16 + 1) * 2;
                        uVar34 = iVar26 * 2;
                        plVar30 = plVar43;
                        if (*puVar39 != 0) {
                          do {
                            uVar17 = puVar39[(longlong)plVar30 + 1];
                            puVar39[((ulonglong)plVar30 & 0xffff) + 1] =
                                 puVar39[((ulonglong)plVar30 & 0xffff) + 1] & 0x8000;
                            puVar39[((ulonglong)plVar30 & 0xffff) + 1] =
                                 puVar39[((ulonglong)plVar30 & 0xffff) + 1] |
                                 (uVar17 & 0x7fff) + (short)uVar34 & 0x7fff;
                            uVar28 = (int)plVar30 + 1;
                            plVar30 = (longlong *)(ulonglong)uVar28;
                          } while (uVar28 < *puVar39);
                          pbVar23 = (byte *)plVar24[2];
                        }
                        iVar29 = *(int *)((longlong)plVar24 + 0xc);
                        *(undefined8 *)(puVar32 + -8) = 0x1015ef;
                        func_0x
                                  (pbVar23 + (ulonglong)uVar34 + (ulonglong)uVar44,pbVar23 + uVar44,
                                   iVar29 - uVar44);
                        *(int *)((longlong)plVar24 + 0xc) =
                             *(int *)((longlong)plVar24 + 0xc) + uVar34;
                        *(uint *)(plVar24 + 4) = *(int *)(plVar24 + 4) + uVar34;
                        uVar17 = (ushort)*(undefined4 *)(plVar24 + 4);
                        if (uVar16 != 0) {
                          uVar17 = puVar39[(ulonglong)(uVar16 - 1) + 1] & 0x7fff;
                        }
                        do {
                          puVar39[(uVar27 & 0xffff) + 1] = uVar17 & 0x7fff;
                          uVar34 = (int)uVar27 + 1;
                          uVar27 = (ulonglong)uVar34;
                        } while (uVar34 < uVar42);
                        *puVar39 = *puVar39 + (short)iVar26;
                        *(undefined8 *)(puVar32 + -8) = 0x10163c;
                        iVar26 = func_0x(puVar1);
                        if (iVar26 != 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x10164f;
                          sVar15 = func_0x(puVar1,auStack_1dc);
                          *(short *)((longlong)plVar24 + 0x32) = sVar15;
                        }
                        *(short *)((longlong)plVar24 + 0x24) = (short)uVar42;
                        uVar27 = (ulonglong)(uVar42 & 0xffff);
                        pbVar23 = (byte *)plVar24[2];
                      }
                      uVar34 = *(uint *)((longlong)plVar24 + 0x1c);
                      if ((uint)uVar27 < uVar42) {
                        uVar44 = *(ushort *)(pbVar23 + uVar27 * 2 + (ulonglong)uVar34) & 0x7fff;
                        uVar42 = uVar40;
LAB_:
                        puVar39 = (ushort *)(pbVar23 + *(uint *)((longlong)plVar24 + 0x1c));
                        lVar19 = plVar24[2];
                        uVar18 = *(undefined4 *)((longlong)plVar24 + 0xc);
                        *(undefined8 *)(puVar32 + -8) = 0x1016ff;
                        uVar18 = func_0x(uVar18,uVar42 + uVar44);
                        *(undefined8 *)(puVar32 + -8) = 0x101717;
                        func_0x
                                  ((ulonglong)uVar44 + 1 + lVar19,
                                   (int)uVar42 + lVar19 + (ulonglong)uVar44,uVar18);
                        uVar34 = uStack_1f8 - 1;
                        if ((int)uVar34 < (int)(uint)*puVar39) {
                          do {
                            uVar16 = puVar39[(longlong)(int)uVar34 + 1];
                            puVar39[((ulonglong)uVar34 & 0xffff) + 1] =
                                 puVar39[((ulonglong)uVar34 & 0xffff) + 1] & 0x8000;
                            puVar39[((ulonglong)uVar34 & 0xffff) + 1] =
                                 puVar39[((ulonglong)uVar34 & 0xffff) + 1] |
                                 ((uVar16 & 0x7fff) - (short)uVar42) + 1 & 0x7fff;
                            uVar34 = uVar34 + 1;
                          } while ((int)uVar34 < (int)(uint)*puVar39);
                        }
                        *(int *)((longlong)plVar24 + 0xc) =
                             *(int *)((longlong)plVar24 + 0xc) + (1 - uVar42);
                        *(undefined8 *)(puVar32 + -8) = 0x101777;
                        iVar26 = func_0x(puVar1);
                        if (iVar26 != 0) {
                          *(undefined8 *)(puVar32 + -8) = 0x10178a;
                          sVar15 = func_0x(puVar1,auStack_1e0);
                          *(short *)((longlong)plVar24 + 0x32) = sVar15;
                        }
                      }
                      else {
                        if (uVar42 == 1) {
                          uVar44 = *(uint *)(plStack_2c0 + 3);
                          uVar42 = *(ushort *)(pbVar23 + (ulonglong)uVar34 + 2) & 0x7fff;
LAB_:
                          if ((uVar42 < uVar44) || (*(uint *)((longlong)plVar24 + 0xc) < uVar42))
                          goto LAB_;
                        }
                        else {
                          uVar44 = *(ushort *)
                                    (pbVar23 + (longlong)(int)uVar42 * 2 + ((ulonglong)uVar34 - 2))
                                   & 0x7fff;
                          uVar42 = *(ushort *)
                                    (pbVar23 + (longlong)(int)uVar42 * 2 + (ulonglong)uVar34) &
                                   0x7fff;
                          if (*(uint *)(plStack_2c0 + 3) <= uVar44) goto LAB_;
LAB_:
                          *(undefined8 *)(puVar32 + -8) = 0x1016c7;
                          func_0x(pbVar23,7);
                          pbVar23 = (byte *)plVar24[2];
                        }
                        uVar42 = uVar42 - uVar44;
                        if (uVar42 != 1) goto LAB_;
                      }
                      *(char *)(plVar24[2] + (ulonglong)uVar44) = *(char *)piStack_2b0;
                      if (uStack_1f4 != 0) {
                        *(undefined8 *)(puVar32 + -8) = 0x1017b7;
                        func_0x(puVar1,auStack_128);
                      }
                    }
                  }
                  else {
                    uVar34 = (uint)*(ushort *)((longlong)puVar36 + 6);
                    if ((*(ushort *)((longlong)puVar36 + 6) & 8) == 0) {
                      if (*(int *)((longlong)plVar24 + 0xc) == 0) {
                        *puVar1 = 0;
                        uVar42 = *(uint *)(plVar24 + 3);
                        uVar27 = (ulonglong)uVar42;
                        *(uint *)((longlong)plVar24 + 0x1c) = uVar42;
                        pbVar23 = (byte *)plVar24[2];
                        bVar38 = *pbVar23;
                        if ((bVar38 & 0x10) != 0) {
                          uVar42 = uVar42 + 2 + (*(ushort *)(pbVar23 + uVar27) + 7 >> 3);
                          uVar27 = (ulonglong)uVar42;
                          *(uint *)((longlong)plVar24 + 0x1c) = uVar42;
                          bVar38 = *pbVar23;
                        }
                        if ((bVar38 & 0x20) == 0) {
                          *(int *)((longlong)plVar24 + 0xc) = (int)uVar27;
                          *(short *)((longlong)plVar24 + 0x24) = 0;
                          *(int *)(plVar24 + 4) = (int)uVar27;
                        }
                        else {
                          puVar39 = (ushort *)(pbVar23 + uVar27);
                          uVar16 = *puVar39;
                          *(ushort *)((longlong)plVar24 + 0x24) = uVar16;
                          if (uVar16 == 0) {
                            *(undefined8 *)(puVar32 + -8) = 0x1007c8;
                            cVar14 = func_0x(0x1132970);
                            if (cVar14 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x1007d1;
                              lVar19 = func_0x();
                              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar32 + -8) = 0x1007eb;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x100807;
                                  (*_DAT_)(0x22,0x44,0x15,0x3eb);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x10082d;
                                  (*_DAT_)(1,0xa2237c,0xb42468,0x80f);
                                }
                              }
                            }
                            lVar19 = plVar24[2];
                            *(undefined8 *)(puVar32 + -8) = 0x10083b;
                            func_0x(lVar19,3);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0x1c);
                            pbVar23 = (byte *)plVar24[2];
                            uVar16 = *(ushort *)((longlong)plVar24 + 0x24);
                          }
                          uVar42 = (int)uVar27 + (uVar16 + 1) * 2;
                          *(uint *)(plVar24 + 4) = uVar42;
                          if (0x1f9e < uVar42) {
                            *(undefined8 *)(puVar32 + -8) = 0x10086f;
                            cVar14 = func_0x(0x1132970);
                            if (cVar14 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x100878;
                              lVar19 = func_0x();
                              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar32 + -8) = 0x100892;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x1008ae;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x1008d4;
                                  (*_DAT_)(1,0xa2237c,0xb42468,0x816);
                                }
                              }
                            }
                            lVar19 = plVar24[2];
                            *(undefined8 *)(puVar32 + -8) = 0x1008e2;
                            func_0x(lVar19,4);
                            uVar16 = *(ushort *)((longlong)plVar24 + 0x24);
                            pbVar23 = (byte *)plVar24[2];
                            uVar42 = *(uint *)(plVar24 + 4);
                          }
                          uVar27 = (ulonglong)uVar16;
                          uVar16 = puVar39[uVar27];
                          *(uint *)((longlong)plVar24 + 0xc) = uVar16 & 0x7fff;
                          if ((uVar16 & 0x7fff) < uVar42) {
                            *(undefined8 *)(puVar32 + -8) = 0x100913;
                            cVar14 = func_0x(0x1132970);
                            if (cVar14 != '\0') {
                              *(undefined8 *)(puVar32 + -8) = 0x10091c;
                              lVar19 = func_0x();
                              if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                *(undefined8 *)(puVar32 + -8) = 0x100936;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 == '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x100952;
                                  (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                }
                                else {
                                  *(undefined8 *)(puVar32 + 0x20) = 0;
                                  *(undefined8 *)(puVar32 + -8) = 0x100978;
                                  (*_DAT_)(1,0xa2237c,0xb42468,0x81d);
                                }
                              }
                            }
                            lVar19 = plVar24[2];
                            *(undefined8 *)(puVar32 + -8) = 0x100986;
                            func_0x(lVar19,4);
                            uVar42 = *(uint *)(plVar24 + 4);
                            uVar27 = (ulonglong)*(ushort *)((longlong)plVar24 + 0x24);
                            pbVar23 = (byte *)plVar24[2];
                          }
                          plVar30 = plVar43;
                          puVar8 = puVar39;
                          if ((short)uVar27 != 0) {
                            do {
                              uVar34 = puVar8[1] & 0x7fff;
                              if ((uVar34 < uVar42) || (*(uint *)((longlong)plVar24 + 0xc) < uVar34)
                                 ) {
                                *(undefined8 *)(puVar32 + -8) = 0x1009cd;
                                cVar14 = func_0x(0x1132970);
                                if (cVar14 != '\0') {
                                  *(undefined8 *)(puVar32 + -8) = 0x1009d6;
                                  lVar19 = func_0x();
                                  if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                                    *(undefined8 *)(puVar32 + -8) = 0x1009f0;
                                    cVar14 = func_0x(0x1132970);
                                    if (cVar14 == '\0') {
                                      *(undefined8 *)(puVar32 + -8) = 0x100a0c;
                                      (*_DAT_)(0x22,0x44,0x15,0x3ec);
                                    }
                                    else {
                                      *(undefined8 *)(puVar32 + 0x20) = 0;
                                      *(undefined8 *)(puVar32 + -8) = 0x100a32;
                                      (*_DAT_)(1,0xa2237c,0xb42468,0x82a);
                                    }
                                  }
                                }
                                lVar19 = plVar24[2];
                                *(undefined8 *)(puVar32 + -8) = 0x100a40;
                                func_0x(lVar19,4);
                              }
                              uVar44 = (int)plVar30 + 1;
                              uVar27 = (ulonglong)*(ushort *)((longlong)plVar24 + 0x24);
                              plVar30 = (longlong *)(ulonglong)uVar44;
                              uVar42 = uVar34;
                              puVar8 = puVar8 + 1;
                            } while ((int)uVar44 < (int)(uint)*(ushort *)((longlong)plVar24 + 0x24))
                            ;
                            pbVar23 = (byte *)plVar24[2];
                          }
                          if ((short)puVar39[(ulonglong)((int)uVar27 - 1) + 1] < 0) {
                            do {
                              uVar42 = *(ushort *)
                                        (pbVar23 +
                                        uVar27 * 2 + (ulonglong)*(uint *)((longlong)plVar24 + 0x1c))
                                       & 0x7fff;
                              if ((int)uVar27 == 1) {
                                uVar34 = *(uint *)(plVar24 + 4);
                                uVar44 = uVar34;
LAB_:
                                if ((uVar42 < uVar34) ||
                                   (*(uint *)((longlong)plVar24 + 0xc) < uVar42)) goto LAB_;
                              }
                              else {
                                uVar34 = *(ushort *)
                                          (pbVar23 +
                                          uVar27 * 2 +
                                          ((ulonglong)*(uint *)((longlong)plVar24 + 0x1c) - 2)) &
                                         0x7fff;
                                uVar44 = *(uint *)(plVar24 + 4);
                                if (uVar44 <= uVar34) goto LAB_;
LAB_:
                                *(undefined8 *)(puVar32 + -8) = 0x100ab5;
                                func_0x(pbVar23,7);
                                uVar44 = *(uint *)(plVar24 + 4);
                                pbVar23 = (byte *)plVar24[2];
                              }
                              puVar36 = puStack_2d0;
                              if ((uVar34 < uVar44) || (*(uint *)((longlong)plVar24 + 0xc) < uVar34)
                                 ) goto LAB_;
                              if (*(ushort *)(pbVar23 + uVar34) == 5) {
                                *puVar1 = *puVar1 | 2;
                                *(short *)((longlong)plVar24 + 0x24) =
                                     *(short *)((longlong)plVar24 + 0x24) + -1;
                                uVar37 = (ulonglong)(uVar34 & 0xffff);
                                *(short *)((longlong)plVar24 + 0x32) = (short)uVar34;
                                uVar27 = plVar24[2];
                                uVar16 = *(ushort *)(uVar27 + 2 + uVar37);
                                uVar17 = *(ushort *)((longlong)plVar24 + 0x34) & 0xc7ff;
                                if ((uVar16 >> 0xe & 1) != 0) {
                                  uVar17 = uVar16 & 0x3800 | uVar17;
                                }
                                *(ushort *)((longlong)plVar24 + 0x34) = uVar17;
                                uVar16 = (uVar17 ^ *(ushort *)(uVar37 + 2 + uVar27)) & 0x7ff ^
                                         uVar17;
                                *(ushort *)((longlong)plVar24 + 0x34) = uVar16;
                                uVar35 = (ulonglong)((uVar16 & 0x7ff) * 2) + 4 +
                                         uVar37 + (uVar17 >> 0xb & 7) * 2 + uVar27;
                                if (uVar35 < uVar37 + uVar27) {
                                  *(undefined8 *)(puVar32 + -8) = 0x100bc5;
                                  func_0x(uVar37 + uVar27,0x19);
                                  uVar16 = *(ushort *)((longlong)plVar24 + 0x34);
                                  uVar37 = (ulonglong)*(ushort *)((longlong)plVar24 + 0x32);
                                  uVar27 = (ulonglong)*(uint *)(plVar24 + 2);
                                }
                                if (uVar42 - uVar34 <
                                    (((uVar16 & 0x7ff) * 2 - (int)uVar37) - (int)uVar27) +
                                    (int)uVar35) {
                                  lVar19 = plVar24[2];
                                  *(undefined8 *)(puVar32 + -8) = 0x100bfe;
                                  func_0x(uVar37 + lVar19,0x19);
                                  uVar16 = *(ushort *)((longlong)plVar24 + 0x34);
                                }
                                if (((uVar16 & 0x3800) != 0) &&
                                   (puVar39 = (ushort *)
                                              (plVar24[2] + 4 +
                                              (ulonglong)*(ushort *)((longlong)plVar24 + 0x32)),
                                   plVar30 = plVar43, (uVar16 & 0x3800) != 0)) {
                                  do {
                                    if ((uVar16 & 0x7ff) < (*puVar39 & 0x7ff)) {
                                      uVar16 = *(ushort *)((longlong)plVar24 + 0x32);
                                      lVar19 = plVar24[2];
                                      *(undefined8 *)(puVar32 + -8) = 0x100c57;
                                      func_0x((ulonglong)uVar16 + lVar19,0x1a);
                                      uVar16 = *(ushort *)((longlong)plVar24 + 0x34);
                                    }
                                    uVar42 = (int)plVar30 + 1;
                                    puVar39 = puVar39 + 1;
                                    plVar30 = (longlong *)(ulonglong)uVar42;
                                  } while ((int)uVar42 < (int)(uVar16 >> 0xb & 7));
                                }
                                goto LAB_;
                              }
                              if (*(ushort *)(pbVar23 + uVar34) < 0x400) goto LAB_;
                              *puVar1 = *puVar1 | 1;
                              uVar16 = *(short *)((longlong)plVar24 + 0x24) - 1;
                              *(ushort *)((longlong)plVar24 + 0x24) = uVar16;
                              if (uVar16 == 0) goto LAB_;
                              uVar27 = (ulonglong)uVar16;
                            } while ((short)puVar39[(ulonglong)(uVar16 - 1) + 1] < 0);
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0xc);
                            pbVar23 = (byte *)plVar24[2];
                          }
                          else {
LAB_:
                            uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0xc);
                            pbVar23 = (byte *)plVar24[2];
                            puVar36 = puStack_2d0;
                          }
                        }
                        if ((*pbVar23 & 0x40) == 0) {
                          *(undefined4 *)((longlong)plVar24 + 0x2e) = 0;
                        }
                        else {
                          *(int *)((longlong)plVar24 + 0x2e) = (int)uVar27;
                          *(int *)((longlong)plVar24 + 0xc) = (int)uVar27 + 0xe;
                          *(undefined8 *)(puVar32 + -8) = 0x100ca2;
                          uVar21 = func_0x(puVar1);
                          *(undefined8 *)(puVar32 + -8) = 0x100cb1;
                          func_0x(uVar21,auStack_1d0);
                          *(undefined8 *)(puVar32 + -8) = 0x100cbd;
                          iVar26 = func_0x(auStack_1d0);
                          *(int *)((longlong)plVar24 + 0xc) =
                               *(int *)((longlong)plVar24 + 0xc) + iVar26;
                          uVar27 = (ulonglong)*(uint *)((longlong)plVar24 + 0xc);
                          pbVar23 = (byte *)plVar24[2];
                        }
                        iVar26 = (int)uVar27;
                        if ((*(byte **)((longlong)plVar24 + 0x26) != (byte *)0x0) &&
                           (*(byte **)((longlong)plVar24 + 0x26) < pbVar23 + uVar27)) {
                          *(undefined8 *)(puVar32 + -8) = 0x100cf5;
                          cVar14 = func_0x(0x1132970);
                          if (cVar14 != '\0') {
                            *(undefined8 *)(puVar32 + -8) = 0x100cfe;
                            lVar19 = func_0x();
                            if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar32 + -8) = 0x100d18;
                              cVar14 = func_0x(0x1132970);
                              if (cVar14 == '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x100d34;
                                (*_DAT_)(0x22,0x44,0x15);
                              }
                              else {
                                *(undefined8 *)(puVar32 + 0x20) = 0;
                                *(undefined8 *)(puVar32 + -8) = 0x100d5a;
                                (*_DAT_)(1,0xa2237c,0xb42468);
                              }
                            }
                          }
                          lVar19 = plVar24[2];
                          *(undefined8 *)(puVar32 + -8) = 0x100d68;
                          func_0x(lVar19,0x12);
                          iVar26 = *(int *)((longlong)plVar24 + 0xc);
                        }
                        if (0x3f3b < iVar26 - 1U) {
                          *(undefined8 *)(puVar32 + -8) = 0x100d85;
                          cVar14 = func_0x(0x1132970);
                          if (cVar14 != '\0') {
                            *(undefined8 *)(puVar32 + -8) = 0x100d8e;
                            lVar19 = func_0x();
                            if ((lVar19 != 0) && (*(char *)(lVar19 + 0x499) != '\0')) {
                              *(undefined8 *)(puVar32 + -8) = 0x100da8;
                              cVar14 = func_0x(0x1132970);
                              if (cVar14 == '\0') {
                                *(undefined8 *)(puVar32 + -8) = 0x100dc4;
                                (*_DAT_)(0x22,0x44,0x15);
                                lVar19 = plVar24[2];
                                *(undefined8 *)(puVar32 + -8) = 0x100dd2;
                                func_0x(lVar19,5);
                                goto LAB_;
                              }
                              *(undefined8 *)(puVar32 + 0x20) = 0;
                              *(undefined8 *)(puVar32 + -8) = 0x100df8;
                              (*_DAT_)(1,0xa2237c,0xb42468);
                            }
                          }
                          lVar19 = plVar24[2];
                          *(undefined8 *)(puVar32 + -8) = 0x100e06;
                          func_0x(lVar19,5);
                        }
                      }
LAB_:
                      uVar34 = *puVar36;
                      uVar42 = uVar34 + 1;
                      uVar44 = *(uint *)(plVar24 + 3);
                      if (uVar44 < uVar42) {
                        *(undefined8 *)(puVar32 + -8) = 0x100e2c;
                        func_0x(puVar1,0,uVar42 - uVar44);
                        if ((1 << (*(byte *)plVar24[2] & 0xe) & 0x1105U) != 0) {
                          *(short *)((byte *)plVar24[2] + 2) = (short)uVar42;
                        }
                        *(uint *)(plVar24 + 3) = uVar42;
                        uVar34 = *puVar36;
                      }
                      puStack_2d0 = puVar36;
                      if (piStack_2b0 != (int *)0x0) {
                        *(char *)((longlong)(int)uVar34 + plVar24[2]) = *(char *)piStack_2b0;
                      }
                    }
                    else {
                      cVar14 = *(char *)apiStack_278[0];
                      uVar42 = uVar42 + 1;
                      uVar44 = *(uint *)(plVar24 + 3);
                      if (uVar44 < uVar42) {
                        *(undefined8 *)(puVar32 + -8) = 0x10070e;
                        func_0x(puVar1,0,uVar42 - uVar44);
                        if ((1 << (*(byte *)plVar24[2] & 0xe) & 0x1105U) != 0) {
                          *(short *)((byte *)plVar24[2] + 2) = (short)uVar42;
                        }
                        *(uint *)(plVar24 + 3) = uVar42;
                        uVar34 = (uint)*(byte *)((longlong)puStack_2d0 + 6);
                      }
                      lVar20 = plVar24[2];
                      if (cVar14 == '\0') {
                        *(byte *)(lVar19 + lVar20) =
                             *(byte *)(lVar20 + lVar19) & ~(byte)(1 << (uVar34 & 7));
                      }
                      else {
                        *(byte *)(lVar19 + lVar20) =
                             *(byte *)(lVar20 + lVar19) | (byte)(1 << (uVar34 & 7));
                      }
                    }
                  }
                }
                else {
                  *(undefined8 *)(puVar32 + 0x20) = 0x79d8e0;
                  *(undefined8 *)(puVar32 + -8) = 0x1006c9;
                  (*_DAT_)(1,0xba3c70,0xbd0638);
                  puStack_2d0 = puVar36;
                }
              }
              puStack_2d0 = puStack_2d0 + 0x14;
              uStack_280 = uStack_280 + 1;
              plVar30 = plStack_2b8;
              puVar36 = puStack_2d0;
              uVar34 = uStack_29c;
            } while (uStack_280 < uStack_1f0);
          }
          do {
            uVar40 = uVar34;
            uVar42 = uStack_2a0;
            if (uVar40 == 0) goto LAB_;
            uVar27 = (ulonglong)uVar40;
            uVar34 = uVar40 - 1;
          } while (*(int *)(plStack_2b8 + (ulonglong)(uVar40 - 1) * 4 + 1) == 0);
          *(short *)((longlong)plVar24 + 0x24) = (short)uVar40;
          iVar26 = *(int *)((longlong)plVar24 + 0x1c) + 2 + uVar40 * 2;
          *(int *)(plVar24 + 4) = iVar26;
          *(int *)((longlong)plVar24 + 0xc) = iVar26;
          *(byte *)plVar24[2] = *(byte *)plVar24[2] | 0x20;
          if (*(uint *)((longlong)plVar24 + 0xc) <= uStack_2a4) {
            plVar43 = (longlong *)((ulonglong)*(uint *)((longlong)plVar24 + 0x1c) + plVar24[2]);
            *(short *)plVar43 = (short)uVar40;
          }
          if (uVar40 != 0) {
            puVar36 = (uint *)((longlong)plStack_2b8 + 0xc);
            uVar40 = uStack_2a4;
            do {
              plVar43 = (longlong *)((longlong)plVar43 + 2);
              uVar41 = *(uint *)((longlong)plVar24 + 0xc);
              lVar19 = plVar24[2];
              uVar44 = puVar36[-1];
              uVar34 = uVar41 + uVar44;
              *(uint *)((longlong)plVar24 + 0xc) = uVar34;
              if ((uVar34 <= uVar40) && (uVar34 <= uVar42)) {
                *(ushort *)plVar43 = (ushort)((*puVar36 & 1) << 0xf) | (ushort)uVar34 & 0x7fff;
                uVar21 = *(undefined8 *)(puVar36 + -3);
                *(undefined8 *)(puVar32 + -8) = 0x102450;
                func_0x((ulonglong)uVar41 + lVar19,uVar44,uVar21,uVar44);
                uVar40 = uStack_2a4;
              }
              puVar36 = puVar36 + 8;
              uVar27 = uVar27 - 1;
            } while (uVar27 != 0);
          }
        }
      }
      else {
        *(undefined8 *)(puVar32 + 0x40) = 0;
        *(undefined **)(puVar32 + 0x38) = auStack_27c;
        *(uint *)(puVar32 + 0x30) = uVar34;
        *(uint *)(puVar32 + 0x28) = uVar42;
        *(longlong *)(puVar32 + 0x20) = lVar19;
        *(undefined8 *)(puVar32 + -8) = 0x102970;
        func_0x(auStack_168,&plStack_268,2,plVar30);
      }
LAB_:
      lVar19 = lStack_1e8;
      if (((*(uint *)(lStack_1e8 + 0x3c4) & 0xe0000000) != 0x80000000) ||
         (0xff < *(ushort *)(lStack_1e8 + 0x3c8))) {
        lVar20 = lStack_1e8 + 0x3b0;
        *(undefined8 *)(puVar32 + -8) = 0x10185c;
        func_0x(lVar20,1);
      }
      *(undefined8 *)(puVar32 + -8) = 0x102988;
      func_0x(&lStack_290,lVar19 + 0x3b0);
      lVar20 = lStack_290;
      uVar21 = *(undefined8 *)(lStack_290 + 8);
      *(undefined8 *)(puVar32 + -8) = 0x102995;
      func_0x(uVar21);
      uVar21 = *(undefined8 *)(lVar20 + 8);
      *(undefined8 *)(puVar32 + -8) = 0x1029a1;
      func_0x(uVar21,1);
      if (iStack_288 != 0) {
        lVar20 = *(longlong *)(lVar20 + 8);
        *(undefined8 *)(puVar32 + -8) = 0x1029bc;
        func_0x(lVar20 + 0x630,2);
        iStack_288 = 0;
      }
      lStack_290 = 0;
      lVar20 = lStack_1a8;
      while (lVar20 != 0) {
        lVar7 = *(longlong *)(lVar20 + 8000);
        *(undefined8 *)(puVar32 + -8) = 0x1029e2;
        (*_DAT_)(lVar20,0x1f48);
        lVar20 = lVar7;
      }
      *pplStack_208 = (longlong *)(*(longlong *)(lVar19 + 0x3f0) + 8);
      goto LAB_;
    }
  }
  else {
    if ((*(byte *)(param_1 + 0x438) & 4) == 0) {
      lStack_290 = *(longlong *)(param_1 + 0x430);
      iStack_288 = 0;
      uStack_300 = 0;
      plStack_308 = &lStack_290;
      uStack_330 = 0x1000a7;
      func_0x(param_1 + 8,*(undefined8 *)(param_1 + 0x428),0,0);
      *(uint *)(param_1 + 0x438) = *(uint *)(param_1 + 0x438) | 4;
      lVar19 = *(longlong *)(param_1 + 0x3f0);
    }
    uStack_330 = 0x1000c7;
    (**(code **)(**(longlong **)(param_1 + 0x38) + 0x28))
              (*(longlong **)(param_1 + 0x38),lVar19,&uStack_1d8);
    uStack_330 = 0x1000d8;
    (**(code **)(**(longlong **)(param_1 + 0x38) + 0x20))(*(longlong **)(param_1 + 0x38),uStack_1d8)
    ;
    lVar19 = *(longlong *)(param_1 + 0x3f0);
    pplStack_208 = (longlong **)0x0;
    iStack_200 = 0;
    *(undefined8 *)(lVar19 + 0x10) = 0;
    *(undefined8 *)(lVar19 + 8) = 0xffff;
    *(undefined8 *)(lVar19 + 0x20) = 0;
    *(undefined8 *)(lVar19 + 0x28) = 0;
    *(undefined8 *)(lVar19 + 0x18) = 0;
    *(undefined4 *)(lVar19 + 0x38) = 0;
    *(undefined8 *)(lVar19 + 0x30) = 0;
    uStack_330 = 0x100125;
    func_0x(&pplStack_208,param_1 + 0x3b0);
    pplVar13 = pplStack_208;
    uStack_330 = 0x100135;
    func_0x(pplStack_208[1]);
    uStack_330 = 0x100141;
    func_0x(pplVar13[1],0xffffffffffffffff);
    if (iStack_200 != 0) {
      uStack_330 = 0x10015f;
      func_0x(pplVar13[1] + 0xc6,2);
      iStack_200 = 0;
    }
    pplStack_208 = (longlong **)0x0;
  }
  if ((*(byte *)(param_1 + 0x438) & 4) == 0) {
    lStack_290 = *(longlong *)(param_1 + 0x430);
    iStack_288 = 0;
    uStack_300 = 0;
    plStack_308 = &lStack_290;
    uStack_330 = 0x1001a8;
    func_0x(param_1 + 8,*(undefined8 *)(param_1 + 0x428),0,0);
    *(uint *)(param_1 + 0x438) = *(uint *)(param_1 + 0x438) | 4;
  }
  plVar24 = (longlong *)(param_1 + 0x40);
  plStack_308 = (longlong *)0x0;
  uStack_330 = 0x1001cb;
  func_0x(*(undefined8 *)(param_1 + 0x38),param_3,param_4,plVar24);
  if (param_5 == (longlong **)0x0) {
    puVar32 = auStack_328;
    if (*plVar24 != 0) {
      uStack_330 = 0x102a10;
      (**(code **)(**(longlong **)(param_1 + 0x38) + 0x20))();
      puVar32 = auStack_328;
    }
  }
  else {
    if (*plVar24 == 0) {
      plVar24 = plVar43;
    }
    *param_5 = plVar24;
    puVar32 = auStack_328;
  }
LAB_:
  uVar27 = uStack_48 ^ (ulonglong)&lStack_2d8;
  *(undefined8 *)(puVar32 + -8) = 0x102a21;
  func_0x(uVar27);
  return;
}

