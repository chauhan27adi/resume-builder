
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(undefined8 param_1,undefined8 param_2,longlong param_3,undefined8 *param_4)

{
  byte *pbVar1;
  short sVar2;
  undefined4 uVar3;
  longlong **pplVar4;
  byte **ppbVar5;
  undefined8 uVar6;
  uint6 uVar7;
  undefined auVar8 [16];
  char cVar9;
  longlong lVar10;
  short *psVar11;
  code *UNRECOVERED_JUMPTABLE_00;
  byte **ppbVar12;
  ulonglong uVar13;
  int iVar14;
  byte **ppbVar15;
  byte *pbVar16;
  undefined2 uVar17;
  byte **ppbVar18;
  ulonglong uVar19;
  undefined8 uStackX_10;
  undefined2 auStackX_18 [4];
  undefined4 uStackX_20;
  undefined2 auStackX_24 [2];
  short sStack_20f6;
  short sStack_20c0;
  byte **ppbStack_20b0;
  undefined auStack_2088 [16];
  undefined auStack_2078 [16];
  byte **ppbStack_2068;
  undefined6 uStack_2060;
  undefined2 uStack_205a;
  undefined6 uStack_2058;
  undefined2 uStack_2052;
  byte **ppbStack_2050;
  undefined auStack_2048 [16];
  undefined auStack_2038 [16];
  undefined auStack_2028 [16];
  longlong lStack_2018;
  longlong lStack_2010;
  ulonglong uStack_58;
  undefined8 uStack_48;
  
  uStack_48 = 0x10001f;
  lVar10 = func_0x();
  lVar10 = -lVar10;
  uStack_58 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar10);
  uVar3 = *(undefined4 *)(uint6 *)(param_3 + 0x3c0);
  ppbVar18 = (byte **)0x0;
  uVar7 = *(uint6 *)(param_3 + 0x3c0);
  *(undefined2 *)(&stack0x0000002c + lVar10) = *(undefined2 *)(param_3 + 0x3c4);
  *(undefined4 *)(&stack0x00000028 + lVar10) = uVar3;
  pplVar4 = (longlong **)*param_4;
  *(longlong *)(&stack0x00000038 + lVar10) = param_3;
  sStack_20c0 = -1;
  ppbStack_20b0 = (byte **)0x0;
  *(undefined4 *)((longlong)&uStackX_20 + lVar10 + -0x20) = 0;
  *(undefined2 *)(&stack0x0000002e + lVar10) = 0;
  lStack_2010 = (ulonglong)uVar7 << 0x10;
  ppbVar5 = (byte **)*pplVar4;
  *(undefined4 *)((longlong)auStackX_24 + lVar10 + -0x20) = 0;
  ppbVar15 = ppbVar18;
  if (ppbVar5 != (byte **)0x0) {
    ppbVar15 = ppbVar5;
  }
  ppbVar12 = ppbVar18;
  if (ppbVar5 != (byte **)0x0) {
    ppbVar12 = ppbVar5 + 0x400;
  }
  if (ppbVar12 == (byte **)0x0) {
LAB_:
    *(undefined8 *)(&stack0xffffffffffffffe0 + lVar10) = 0x126be30;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101242;
    (*_DAT_)(1,0x122f8fc,0x122b918,0x73d);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x101251;
    func_0x(uStack_58 ^ (ulonglong)(&stack0xffffffffffffffc0 + lVar10));
    return;
  }
  do {
    ppbVar12 = (byte **)((longlong)ppbVar12 + -2);
    uVar13 = (ulonglong)ppbVar12 & 0xffffffffffffe000;
    iVar14 = (int)((longlong)((uVar13 - (longlong)ppbVar12) + 0x1ffe) >> 1);
    if ((int)(uint)*(ushort *)((longlong)ppbVar15 + 0x16) <= iVar14) goto LAB_;
  } while (*(short *)ppbVar12 == 0);
  if (ppbVar12 == (byte **)0x0) goto LAB_;
  if (-1 < *(char *)(uVar13 + 2)) goto LAB_;
  pbVar16 = (byte *)(uVar13 + 0x60);
  if ((sStack_20c0 == 0) || (ppbVar18 = ppbStack_20b0, ppbStack_20b0 == (byte **)0x0)) {
    uStack_2060 = 0;
    uStack_2052 = 0;
    auVar8._4_8_ = ppbVar18;
    auVar8._0_4_ = (int)ppbVar18;
    auVar8._12_4_ = 0;
    auStack_2078 = auVar8 << 0x20;
    uStack_205a = SUB82(ppbVar18,0);
    uStack_2058 = (undefined6)((ulonglong)ppbVar18 >> 0x10);
    ppbStack_2050 = ppbVar18;
    ppbStack_2068 = ppbVar18;
    auStack_2048._8_8_ = 0;
    auStack_2048._0_8_ = ppbVar18;
    auStack_2048 = auStack_2048 << 0x40;
    lStack_2018 = ((ulonglong)ppbVar18 & 0xffff) << 0x10;
    ppbStack_20b0 = (byte **)auStack_2088;
    auStack_2038 = ZEXT816(0);
    auStack_2078._0_2_ = 0xffff;
    auStack_2088 = ZEXT816(0);
    auStack_2028._0_12_ = ZEXT812(0);
    auStack_2028._12_4_ = 0;
  }
  if (*(short *)(uVar13 + 0x24) == 0) {
LAB_:
    uVar17 = *(undefined2 *)(uVar13 + 0x30);
    *(undefined8 *)((longlong)&uStackX_10 + lVar10) = *(undefined8 *)(uVar13 + 0x28);
    *(undefined2 *)((longlong)auStackX_18 + lVar10) = uVar17;
  }
  else {
    cVar9 = *(char *)(uVar13 + 1);
    if (cVar9 == '\v') {
      if (*(int *)(uVar13 + 0x18) != 99) {
LAB_:
        if (cVar9 != '\t') goto LAB_;
        goto LAB_;
      }
    }
    else {
      if (cVar9 != '\b') goto LAB_;
LAB_:
      if (*(int *)(uVar13 + 0x18) != 99) goto LAB_;
    }
    *(undefined4 *)((longlong)&uStackX_20 + lVar10) = *(undefined4 *)(uVar13 + 0x20);
    *(undefined2 *)((longlong)auStackX_24 + lVar10) = *(undefined2 *)(uVar13 + 0x24);
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1001e5;
    cVar9 = func_0x((longlong)&uStackX_20 + lVar10);
    if (cVar9 == '\0') goto LAB_;
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x1001f6;
    func_0x(uVar13,(longlong)&uStackX_10 + lVar10);
    uVar17 = *(undefined2 *)((longlong)auStackX_18 + lVar10);
  }
  uVar3 = *(undefined4 *)((longlong)&uStackX_10 + lVar10);
  *ppbStack_20b0 = pbVar16;
  *(undefined4 *)(ppbStack_20b0 + 0xc) = uVar3;
  uVar6 = *(undefined8 *)((longlong)&uStackX_10 + lVar10);
  *(undefined2 *)(ppbStack_20b0 + 0xd) = uVar17;
  *(int *)((longlong)ppbStack_20b0 + 100) = (int)((ulonglong)uVar6 >> 0x20);
  *(undefined4 *)((longlong)ppbStack_20b0 + 0x6c) = *(undefined4 *)(uVar13 + 0x20);
  *(undefined2 *)(ppbStack_20b0 + 0xe) = *(undefined2 *)(uVar13 + 0x24);
  *(undefined2 *)((longlong)ppbStack_20b0 + 0x72) = 0;
  uVar3 = *(undefined4 *)((ulonglong)*pbVar16 * 6 + 0xe9f580);
  uVar19 = (ulonglong)*(short *)((ulonglong)*pbVar16 * 6 + 0xe9f584);
  *(undefined2 *)(ppbStack_20b0 + 2) = 0xffff;
  ppbStack_20b0[3] = (byte *)0x0;
  *(undefined4 *)((longlong)ppbStack_20b0 + 0x14) = 0;
  *(undefined8 *)((longlong)ppbStack_20b0 + 0x2e) = 0;
  ppbStack_20b0[7] = (byte *)0x0;
  ppbStack_20b0[4] = (byte *)0x0;
  ppbStack_20b0[9] = (byte *)0x0;
  ppbStack_20b0[10] = (byte *)0x0;
  *(undefined2 *)(ppbStack_20b0 + 0xb) = 0;
  if ((**ppbStack_20b0 & 2) != 0) {
    pbVar1 = pbVar16 + uVar19;
    if ((pbVar16[uVar19] & 1) == 0) {
      *(undefined2 *)(ppbStack_20b0 + 2) = 0;
      ppbStack_20b0[3] = pbVar1;
      *(undefined4 *)((longlong)ppbStack_20b0 + 0x14) = 0;
      *(undefined4 *)((longlong)ppbStack_20b0 + 0x36) = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010046a */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar1 & 0xe) * 4 + 0x101298) - 0x16f9890))()
      ;
      return;
    }
    *(undefined2 *)(ppbStack_20b0 + 2) = 1;
    ppbStack_20b0[3] = pbVar1;
    UNRECOVERED_JUMPTABLE_00 =
         (code *)((ulonglong)
                  *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar1 & 0x1c) + 0x101278) * 4 +
                           0x101268) - 0x16f9890);
                    /* WARNING: Could not emulate address calculation at 0x001002cf */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
    return;
  }
  if ((**ppbStack_20b0 & 4) != 0) {
    sStack_20f6 = (short)((uint)uVar3 >> 0x10);
    if (sStack_20f6 != 0) {
      uVar19 = (ulonglong)*(ushort *)(uVar13 + 0x61 + (longlong)sStack_20f6 * 2);
    }
    psVar11 = (short *)(pbVar16 + uVar19);
    ppbStack_20b0[9] = (byte *)psVar11;
    sVar2 = *psVar11;
    ppbStack_20b0[10] = (byte *)(psVar11 + 1);
    *(short *)(ppbStack_20b0 + 0xb) = (sVar2 + 1) * 2;
  }
  pbVar16 = ppbStack_20b0[1];
  if (pbVar16 != (byte *)0x0) {
    *(undefined8 *)((longlong)&uStack_48 + lVar10) = 0x100528;
    func_0x(pbVar16,ppbStack_20b0);
  }
LAB_:
  pbVar16 = (byte *)(*(ushort *)(uVar13 + (0xfff - (longlong)iVar14) * 2) + uVar13);
  if ((*pbVar16 & 1) == 0) {
                    /* WARNING: Could not emulate address calculation at 0x001006e5 */
                    /* WARNING: Treating indirect jump as call */
    (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar16 & 0xe) * 4 + 0x101304) - 0x16f9890))();
    return;
  }
  UNRECOVERED_JUMPTABLE_00 =
       (code *)((ulonglong)
                *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar16 & 0x1c) + 0x1012e4) * 4 +
                         0x1012d4) - 0x16f9890);
                    /* WARNING: Could not emulate address calculation at 0x0010057c */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
  return;
}

