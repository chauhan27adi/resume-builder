
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_(longlong param_1,longlong param_2,int param_3,undefined8 param_4,
                 undefined8 param_5,undefined4 param_6,longlong *param_7,longlong *param_8)

{
  longlong **pplVar1;
  byte *pbVar2;
  int *piVar3;
  ushort uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined auVar9 [16];
  int iVar10;
  int *piVar11;
  longlong lVar12;
  char cVar13;
  int iVar14;
  int iVar15;
  uint uVar16;
  longlong lVar17;
  code *UNRECOVERED_JUMPTABLE_00;
  longlong lVar18;
  undefined8 unaff_RBX;
  int iVar19;
  longlong lVar20;
  ulonglong uVar21;
  undefined8 uVar22;
  undefined4 auStackX_8 [2];
  undefined8 uStackX_10;
  undefined auStackX_18 [16];
  undefined8 uStack_2c18;
  undefined2 auStack_2c10 [2];
  undefined4 uStack_2c0c;
  undefined8 uStack_2c08;
  undefined8 uStack_2c00;
  undefined8 uStack_2bf2;
  undefined8 uStack_2be8;
  int iStack_2bd8;
  int iStack_2bd4;
  undefined4 uStack_2bd0;
  int *piStack_2bc8;
  undefined8 uStack_2bc0;
  undefined2 uStack_2bb8;
  int iStack_2bb0;
  undefined4 uStack_2bac;
  undefined2 uStack_2ba8;
  undefined4 uStack_2ba4;
  undefined2 uStack_2ba0;
  longlong *plStack_2b98;
  longlong lStack_2b90;
  longlong *plStack_2b88;
  undefined4 uStack_2b80;
  int iStack_2b78;
  int iStack_2b74;
  int iStack_2b70;
  int iStack_2b6c;
  undefined auStack_2b60 [16];
  int *piStack_2b50;
  undefined8 uStack_2b48;
  undefined2 uStack_2b40;
  undefined4 uStack_2b3c;
  byte *pbStack_2b38;
  undefined8 uStack_2b30;
  undefined8 uStack_2b22;
  undefined2 uStack_2b1a;
  undefined2 uStack_2b18;
  undefined6 uStack_2b16;
  undefined4 uStack_2b0c;
  undefined auStack_2b08 [16];
  undefined auStack_2af8 [8];
  undefined8 uStack_2af0;
  undefined8 uStack_2ae8;
  undefined6 uStack_2ae0;
  undefined2 uStack_2ada;
  undefined6 uStack_2ad8;
  undefined2 uStack_2ad2;
  undefined2 uStack_2ad0;
  undefined6 uStack_2ace;
  undefined8 uStack_2ac8;
  short *psStack_2ac0;
  short *psStack_2ab8;
  short sStack_2ab0;
  undefined6 uStack_2aae;
  undefined auStack_2aa8 [10];
  undefined auStack_2a9e [6];
  undefined8 uStack_2a98;
  undefined8 uStack_2a88;
  undefined8 uStack_2a80;
  undefined auStack_2a78 [16];
  undefined auStack_2a68 [16];
  undefined4 uStack_2a58;
  undefined8 uStack_2a54;
  uint uStack_2a4c;
  undefined auStack_2a48 [20];
  undefined uStack_2a34;
  undefined auStack_1fe8 [8096];
  ulonglong uStack_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x10001e;
  iStack_2bb0 = param_3;
  lVar17 = func_0x();
  uVar22 = param_5;
  lVar17 = -lVar17;
  uStack_2b48 = 0xfffffffffffffffe;
  *(undefined8 *)(&stack0x00002c70 + lVar17) = unaff_RBX;
  uStack_48 = _DAT_ ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar17);
  *(undefined8 *)((longlong)&param_8 + lVar17) = param_4;
  *(longlong *)((longlong)&param_7 + lVar17) = param_1;
  uStack_2c18 = param_5;
  plStack_2b88 = param_7;
  plStack_2b98 = param_8;
  uStack_2bd0 = 0;
  iStack_2bd8 = 0;
  iStack_2b78 = _DAT_;
  iStack_2b74 = iRam0000000001f5b22c;
  iStack_2b70 = _DAT_;
  iStack_2b6c = iRam0000000001f5b234;
  piStack_2bc8 = (int *)0x0;
  auStack_2c10[0] = 0xffff;
  uStack_2c08 = 0;
  uStack_2c0c = 0;
  uStack_2bf2 = 0;
  uStack_2be8 = 0;
  uStack_2c00 = 0;
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1000c5;
  func_0x(auStack_1fe8,0,0x1f9e);
  auStack_2b60 = ZEXT816(0);
  piStack_2b50 = (int *)0x0;
  if (param_2 < 2) {
    param_2 = 8;
  }
  for (lVar20 = *(longlong *)(param_1 + 0x348);
      (lStack_2b90 = param_2, lVar20 != param_1 + 0x340 && (lVar20 != 0));
      lVar20 = *(longlong *)(lVar20 + 8)) {
    lVar18 = *(longlong *)(lVar20 + 0x10);
    if (*(int *)(lVar18 + 8) == 0) {
      if ((*(byte *)(lVar20 + 0x18) & 1) != 0) {
        *(undefined8 *)(lVar18 + 0x10) = *(undefined8 *)(param_1 + 0x370);
        *(undefined4 *)(lVar18 + 4) = 2;
        *(uint *)(lVar20 + 0x18) = *(uint *)(lVar20 + 0x18) & 0xfffffffe;
        lVar18 = *(longlong *)(lVar20 + 0x10);
      }
      *(int *)(lVar18 + 8) = *(int *)(lVar18 + 8) + 1;
      goto LAB_;
    }
  }
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100137;
  func_0x(param_1 + 0x340);
LAB_:
  *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100143;
  func_0x(&piStack_2bc8);
  piVar11 = piStack_2bc8;
LAB_:
  do {
    iVar15 = 0;
    lVar20 = 0;
    if (0xf < iStack_2bd8) {
LAB_:
      if (piVar11 != (int *)0x0) {
        piVar3 = piVar11 + 2;
        *piVar3 = *piVar3 + -1;
        if (*piVar3 == 0) {
          if (*piVar11 == 1) {
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d98;
            func_0x(piVar11,1);
          }
          else if ((piVar11[1] & 4U) != 0) {
            if ((piVar11[1] & 0x10U) == 0) {
              lVar20 = *(longlong *)(piVar11 + 0x12);
              if ((lVar20 != CONCAT44(iRam0000000001f5b22c,_DAT_)) ||
                 (*(longlong *)(piVar11 + 0x14) != CONCAT44(iRam0000000001f5b234,_DAT_))) {
                *(undefined4 *)(lVar20 + 0x48) = 0;
                *(undefined8 *)(lVar20 + 0x50) = 0;
                *(undefined *)((longlong)piVar11 + 0x3e) = 0;
                *(undefined8 *)(piVar11 + 0xc) = 0;
                *(undefined2 *)(piVar11 + 0xf) = 0;
              }
              iVar19 = iRam0000000001f5b234;
              iVar14 = _DAT_;
              iVar15 = iRam0000000001f5b22c;
              piVar11[0x12] = _DAT_;
              piVar11[0x13] = iVar15;
              piVar11[0x14] = iVar14;
              piVar11[0x15] = iVar19;
              *(undefined8 *)(piVar11 + 0x16) = 0;
            }
            uVar22 = *(undefined8 *)(*(longlong *)(piVar11 + 6) + 0x10);
            *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101df2;
            func_0x(uVar22,piVar11 + 8);
            piVar11[1] = piVar11[1] & 0xffffff6b;
          }
        }
      }
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101e0a;
      func_0x(uStack_48 ^ (ulonglong)(&stack0xffffffffffffffc8 + lVar17));
      return;
    }
    iStack_2bd4 = 0;
    uStack_2a34 = 0;
    iStack_2bd8 = iStack_2bd8 + 1;
    *(undefined4 *)((longlong)&param_5 + lVar17) = 0;
    *(undefined8 *)((longlong)&param_6 + lVar17) = 0;
    lVar18 = *(longlong *)(param_1 + 0x2e0);
    auStackX_18[lVar17] = 0;
    *(undefined8 *)((longlong)&uStackX_10 + lVar17) = 0;
    *(undefined4 *)((longlong)auStackX_8 + lVar17) = param_6;
    *(undefined8 *)(auStackX_18 + lVar17 + -0x18) = uVar22;
    *(undefined8 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
    *(undefined **)(&stack0xfffffffffffffff0 + lVar17) = auStack_2a48;
    *(int **)(&stack0xffffffffffffffe8 + lVar17) = &iStack_2b78;
    uVar6 = *(undefined8 *)(lVar18 + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1001c6;
    func_0x(uVar6,param_4,0,3);
  } while (param_2 < 1);
  pplVar1 = (longlong **)(piVar11 + 0xc);
  do {
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1001dc;
    func_0x(piVar11);
    if ((*pplVar1 == (longlong *)0x0) || (lVar18 = **pplVar1, lVar18 == 0)) {
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d60;
      func_0x(piVar11);
LAB_:
      lVar20 = *(longlong *)((longlong)&param_8 + lVar17);
      *(undefined8 *)(lVar20 + 0x10) = 2;
      *(undefined4 *)(lVar20 + 8) = 0;
      goto LAB_;
    }
    uVar22 = uStack_2c18;
    if (*(short *)(lVar18 + 0x3a) != 0) {
      uStack_2bac = *(undefined4 *)(lVar18 + 0x20);
      uStack_2ba8 = *(undefined2 *)(lVar18 + 0x24);
      iVar15 = 6;
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10021a;
      func_0x(piVar11);
      lVar20 = *(longlong *)(param_1 + 0x2e0);
      uStack_2a88 = 0;
      uStack_2a4c = uStack_2a4c & 0xfffffff8;
      uStack_2a54 = 0;
      uStack_2a80 = 0;
      auStack_2a78 = ZEXT816(0);
      auStack_2a68 = ZEXT816(0);
      uStack_2a58 = 0;
      *(undefined8 **)(&stack0xfffffffffffffff0 + lVar17) = &uStack_2a88;
      *(undefined4 **)(&stack0xffffffffffffffe8 + lVar17) = &uStack_2bac;
      uVar6 = *(undefined8 *)(lVar20 + 0x10);
      uVar7 = *(undefined8 *)(param_1 + 0x10);
      uVar8 = *(undefined8 *)(param_1 + 0x18);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10028e;
      iVar14 = func_0x(uVar8,uVar7,uVar6,param_1 + 0x340);
      iVar19 = uStack_2a4c << 0x1d;
      if (iVar14 == 0) {
LAB_:
        if (iVar19 < 0) {
          *plStack_2b98 = *plStack_2b98 + 1;
          param_4 = *(undefined8 *)((longlong)&param_8 + lVar17);
          goto LAB_;
        }
        if (iVar15 != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c87;
          func_0x(piVar11);
          param_4 = *(undefined8 *)((longlong)&param_8 + lVar17);
          goto LAB_;
        }
      }
      else {
        iVar15 = 6;
        if (iVar19 < 0) {
LAB_:
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002f3;
          func_0x(piVar11);
          goto LAB_;
        }
        piVar11[0x19] = 3;
        uVar6 = *(undefined8 *)(*(longlong *)(piVar11 + 6) + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002be;
        iVar15 = func_0x(uVar6,piVar11 + 8,3);
        if (iVar15 != 0) {
          piVar11[0x28] = piVar11[0x28] | 0x10;
        }
        uVar6 = *(undefined8 *)(*(longlong *)(piVar11 + 6) + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1002e3;
        func_0x(uVar6,piVar11 + 8,piVar11 + 0x18,pplVar1);
        piVar11[1] = piVar11[1] & 0xffffffef;
        if (iVar15 != 0) goto LAB_;
      }
      lVar20 = *(longlong *)((longlong)&param_6 + lVar17);
      iVar15 = *(int *)((longlong)&param_5 + lVar17);
      lVar18 = 0;
      if (*pplVar1 != (longlong *)0x0) {
        lVar18 = **pplVar1;
      }
    }
    lVar12 = lStack_2b90;
    if (*(short *)(lVar18 + 0x16) == 0) {
      lVar18 = *(longlong *)(param_1 + 0x108);
      *(undefined4 *)(&stack0xfffffffffffffff0 + lVar17) = 0;
      *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = 0;
      uVar5 = *(undefined4 *)(lVar18 + 0xa8);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100352;
      iVar14 = func_0x(piVar11,5,uVar5,0);
      if (iVar14 != 1) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x100369;
        iVar15 = func_0x(param_1);
        if (iVar15 == 0) {
          *plStack_2b98 = *plStack_2b98 + 1;
        }
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10037c;
        func_0x(piVar11);
        param_4 = *(undefined8 *)((longlong)&param_8 + lVar17);
        goto LAB_;
      }
    }
    else {
      lVar20 = lVar20 + 1;
      *(longlong *)((longlong)&param_6 + lVar17) = lVar20;
      uVar4 = *(ushort *)(lVar18 + 0x1c);
      if (lVar20 == 1) {
        iStack_2bd4 = uVar4 - 2;
        if (uVar4 < 3) {
          iStack_2bd4 = 0;
        }
        iStack_2bd4 = iStack_2bd4 - iStack_2bb0;
        param_1 = *(longlong *)((longlong)&param_7 + lVar17);
      }
      else if (lVar20 == 2) {
        uStack_2b40 = 0xffff;
        pbStack_2b38 = (byte *)0x0;
        uStack_2b3c = 0;
        uStack_2b22 = 0;
        uStack_2b18 = 0;
        uStack_2b16 = 0;
        uStack_2b30 = 0;
        uStack_2b0c = 0;
        if (-1 < *(char *)(lVar18 + 2)) goto LAB_;
        pbVar2 = (byte *)(lVar18 + 0x60);
        uStack_2ae0 = 0;
        uStack_2ad2 = 0;
        uStack_2ac8 = 0;
        psStack_2ab8 = (short *)0x0;
        sStack_2ab0 = 0;
        uStack_2aae = 0;
        auStack_2b08._8_8_ = 0;
        stack0xffffffffffffd50a = SUB1614(ZEXT816(0),2);
        auStack_2af8._0_2_ = 0xffff;
        uStack_2af0 = 0;
        uStack_2ada = 0;
        uStack_2ad8 = 0;
        uStack_2ad0 = 0;
        uStack_2ace = 0;
        uStack_2ae8 = 0;
        psStack_2ac0 = (short *)0x0;
        _auStack_2aa8 = ZEXT812(0);
        auStack_2a9e._2_4_ = 0;
        uStack_2a98 = 0;
        lVar20 = 0;
        if (*(short *)(lVar18 + 0x24) == 0) {
LAB_:
          auStack_2b08._8_8_ = lVar20;
          uStack_2bc0 = *(undefined8 *)(lVar18 + 0x28);
          uStack_2bb8 = *(undefined2 *)(lVar18 + 0x30);
        }
        else {
          cVar13 = *(char *)(lVar18 + 1);
          if (cVar13 == '\v') {
            if (*(int *)(lVar18 + 0x18) != 99) {
LAB_:
              if (cVar13 != '\t') goto LAB_;
              goto LAB_;
            }
          }
          else {
            if (cVar13 != '\b') goto LAB_;
LAB_:
            lVar20 = auStack_2b08._8_8_;
            if (*(int *)(lVar18 + 0x18) != 99) goto LAB_;
          }
          uStack_2ba4 = *(undefined4 *)(lVar18 + 0x20);
          uStack_2ba0 = *(undefined2 *)(lVar18 + 0x24);
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1004c5;
          auStack_2b08 = ZEXT816(0);
          cVar13 = func_0x(&uStack_2ba4);
          lVar20 = auStack_2b08._8_8_;
          if (cVar13 == '\0') goto LAB_;
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x1004d5;
          func_0x(lVar18,&uStack_2bc0);
        }
        auStack_2b08._0_8_ = pbVar2;
        auStack_2aa8._8_2_ = uStack_2bb8;
        auStack_2aa8._0_8_ = uStack_2bc0;
        auStack_2a9e._2_4_ = *(undefined4 *)(lVar18 + 0x20);
        lVar20 = (ulonglong)*pbVar2 * 6;
        uStack_2b80 = *(undefined4 *)(lVar20 + 0x1618fd0);
        uVar21 = (ulonglong)*(short *)(lVar20 + 0x1618fd4);
        auStack_2af8._0_2_ = 0xffff;
        auStack_2af8 = (undefined  [8])((ulonglong)auStack_2af8 & 0xffffffff);
        uStack_2af0 = 0;
        uStack_2ada = 0;
        uStack_2ad8 = 0;
        uStack_2ad0 = 0;
        uStack_2ace = 0;
        uStack_2ae8 = 0;
        psStack_2ac0 = (short *)0x0;
        psStack_2ab8 = (short *)0x0;
        sStack_2ab0 = 0;
        if ((*pbVar2 & 2) != 0) {
          pbVar2 = pbVar2 + uVar21;
          uStack_2af0 = pbVar2;
          if ((*pbVar2 & 1) == 0) {
            auVar9._14_2_ = 0;
            auVar9._0_14_ = stack0xffffffffffffd50a;
            _auStack_2af8 = auVar9 << 0x10;
            uStack_2ad2 = 0;
            uStack_2ad0 = 0;
                    /* WARNING: Could not emulate address calculation at 0x0010079b */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbVar2 & 0xe) * 4 + 0x101e58) -
                      0xf7fe40))();
            return;
          }
          auStack_2af8._0_2_ = 1;
          UNRECOVERED_JUMPTABLE_00 =
               (code *)((ulonglong)
                        *(uint *)((ulonglong)*(byte *)((longlong)(int)(*pbVar2 & 0x1c) + 0x101e38) *
                                  4 + 0x101e28) - 0xf7fe40);
                    /* WARNING: Could not emulate address calculation at 0x001005d1 */
                    /* WARNING: Treating indirect jump as call */
          (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
          return;
        }
        if ((*pbVar2 & 4) != 0) {
          uStack_2b80._2_2_ = (short)((uint)uStack_2b80 >> 0x10);
          if (uStack_2b80._2_2_ != 0) {
            uVar21 = (ulonglong)*(ushort *)(lVar18 + 0x61 + (longlong)uStack_2b80._2_2_ * 2);
          }
          psStack_2ac0 = (short *)(pbVar2 + uVar21);
          psStack_2ab8 = psStack_2ac0 + 1;
          sStack_2ab0 = (*psStack_2ac0 + 1) * 2;
        }
        if (auStack_2b08._8_8_ != 0) {
          *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x10086d;
          func_0x(auStack_2b08._8_8_,auStack_2b08);
        }
LAB_:
        pbStack_2b38 = (byte *)((ulonglong)*(ushort *)(lVar18 + 0x1ffe) + lVar18);
        if ((*pbStack_2b38 & 1) == 0) {
          uStack_2b40 = 0;
          uStack_2b3c = 0;
          uStack_2b1a = 0;
          uStack_2b18 = 0;
                    /* WARNING: Could not emulate address calculation at 0x00100a49 */
                    /* WARNING: Treating indirect jump as call */
          (*(code *)((ulonglong)*(uint *)((longlong)(int)(*pbStack_2b38 & 0xe) * 4 + 0x101ec4) -
                    0xf7fe40))
                    (0xffffffffff0801c0,(longlong)(int)(*pbStack_2b38 & 0xe),pbStack_2b38,0);
          return;
        }
        uStack_2b40 = 1;
        UNRECOVERED_JUMPTABLE_00 =
             (code *)((ulonglong)
                      *(uint *)((ulonglong)
                                *(byte *)((longlong)(int)(*pbStack_2b38 & 0x1c) + 0x101ea4) * 4 +
                               0x101e94) - 0xf7fe40);
                    /* WARNING: Could not emulate address calculation at 0x001008ac */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE_00)(UNRECOVERED_JUMPTABLE_00);
        return;
      }
      iVar15 = iVar15 + ((uint)uVar4 - iStack_2bb0);
      *(int *)((longlong)&param_5 + lVar17) = iVar15;
      if (0x2000 < iVar15) {
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d54;
        func_0x(piVar11);
        goto LAB_;
      }
      param_2 = lStack_2b90;
      if (lVar20 == lStack_2b90) {
        *(undefined4 *)(&stack0xfffffffffffffff8 + lVar17) = 0;
        *(undefined8 *)(&stack0xfffffffffffffff0 + lVar17) = uStack_2c18;
        *(undefined4 *)(&stack0xffffffffffffffe8 + lVar17) = param_6;
        param_4 = *(undefined8 *)((longlong)&param_8 + lVar17);
        uVar6 = *(undefined8 *)(param_1 + 0x10);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d2f;
        func_0x(uVar6,auStack_2c10,0,param_4);
        *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101d37;
        func_0x(piVar11);
        param_2 = lVar12;
        goto LAB_;
      }
    }
    piStack_2b50 = piVar11;
    lVar18 = *(longlong *)(param_1 + 0x2e0);
    *(undefined4 *)(&stack0xfffffffffffffff8 + lVar17) = 1;
    *(undefined **)(&stack0xfffffffffffffff0 + lVar17) = auStack_2b60;
    *(int **)(&stack0xffffffffffffffe8 + lVar17) = &iStack_2b78;
    uVar6 = *(undefined8 *)(lVar18 + 0x10);
    *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101bef;
    uVar16 = func_0x(uVar6);
    if (((byte)piVar11[1] & 0x14) == 4) {
      lVar18 = *(longlong *)(piVar11 + 0x12);
      if ((lVar18 != CONCAT44(iRam0000000001f5b22c,_DAT_)) ||
         (*(longlong *)(piVar11 + 0x14) != CONCAT44(iRam0000000001f5b234,_DAT_))) {
        *(undefined4 *)(lVar18 + 0x48) = 0;
        *(undefined8 *)(lVar18 + 0x50) = 0;
        *(undefined *)((longlong)piVar11 + 0x3e) = 0;
        *pplVar1 = (longlong *)0x0;
        *(undefined2 *)(piVar11 + 0xf) = 0;
      }
      iVar10 = iRam0000000001f5b234;
      iVar19 = _DAT_;
      iVar14 = iRam0000000001f5b22c;
      piVar11[0x12] = _DAT_;
      piVar11[0x13] = iVar14;
      piVar11[0x14] = iVar19;
      piVar11[0x15] = iVar10;
      *(undefined8 *)(piVar11 + 0x16) = 0;
      uVar6 = *(undefined8 *)(*(longlong *)(piVar11 + 6) + 0x10);
      *(undefined8 *)((longlong)&uStack_40 + lVar17) = 0x101c4e;
      func_0x(uVar6);
      piVar11[0x18] = 1;
      piVar11[1] = piVar11[1] | 0x10;
    }
    if (uVar16 == 4) {
      *plStack_2b88 = *plStack_2b88 + lVar20;
      goto LAB_;
    }
    param_4 = *(undefined8 *)((longlong)&param_8 + lVar17);
    if ((1 < uVar16) || (param_2 <= lVar20)) goto LAB_;
  } while( true );
}

